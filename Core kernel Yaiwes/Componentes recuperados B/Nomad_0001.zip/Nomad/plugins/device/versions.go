// Copyright IBM Corp. 2015, 2026
// SPDX-License-Identifier: MPL-2.0

package device

const (
	// ApiVersion010 is the initial API version for the device plugins
	ApiVersion010 = "v0.1.0"
)
