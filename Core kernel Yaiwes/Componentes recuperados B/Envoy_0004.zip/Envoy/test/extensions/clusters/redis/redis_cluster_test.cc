#include <bitset>
#include <chrono>
#include <memory>
#include <utility>
#include <vector>

#include "envoy/common/callback.h"
#include "envoy/config/cluster/v3/cluster.pb.h"
#include "envoy/extensions/clusters/redis/v3/redis_cluster.pb.h"
#include "envoy/extensions/clusters/redis/v3/redis_cluster.pb.validate.h"
#include "envoy/extensions/filters/network/redis_proxy/v3/redis_proxy.pb.h"
#include "envoy/extensions/filters/network/redis_proxy/v3/redis_proxy.pb.validate.h"
#include "envoy/stats/scope.h"

#include "source/common/network/utility.h"
#include "source/common/singleton/manager_impl.h"
#include "source/extensions/clusters/redis/redis_cluster.h"

#include "test/common/upstream/utility.h"
#include "test/extensions/clusters/redis/mocks.h"
#include "test/extensions/common/redis/mocks.h"
#include "test/extensions/filters/network/common/redis/mocks.h"
#include "test/mocks/common.h"
#include "test/mocks/protobuf/mocks.h"
#include "test/mocks/server/admin.h"
#include "test/mocks/server/server_factory_context.h"
#include "test/mocks/upstream/cluster_manager.h"
#include "test/mocks/upstream/cluster_priority_set.h"
#include "test/mocks/upstream/health_check_event_logger.h"
#include "test/mocks/upstream/health_checker.h"
#include "test/test_common/status_utility.h"

using ::Envoy::StatusHelpers::HasStatusMessage;
using testing::_;
using testing::ContainerEq;
using testing::DoAll;
using testing::Invoke;
using testing::InvokeWithoutArgs;
using testing::NiceMock;
using testing::Ref;
using testing::Return;
using testing::SaveArg;

namespace Envoy {
namespace Extensions {
namespace Clusters {
namespace Redis {

namespace {
const std::string BasicConfig = R"EOF(
  name: name
  connect_timeout: 0.25s
  dns_lookup_family: V4_ONLY
  load_assignment:
        endpoints:
          - lb_endpoints:
            - endpoint:
                address:
                  socket_address:
                    address: foo.bar.com
                    port_value: 22120
  cluster_type:
    name: envoy.clusters.redis
    typed_config:
      "@type": type.googleapis.com/google.protobuf.Struct
      value:
        cluster_refresh_rate: 4s
        cluster_refresh_timeout: 0.25s
  )EOF";

const std::string NoWarmupConfig = R"EOF(
  name: name
  connect_timeout: 0.25s
  dns_lookup_family: V4_ONLY
  wait_for_warm_on_init: false
  load_assignment:
        endpoints:
          - lb_endpoints:
            - endpoint:
                address:
                  socket_address:
                    address: foo.bar.com
                    port_value: 22120
  cluster_type:
    name: envoy.clusters.redis
    typed_config:
      "@type": type.googleapis.com/google.protobuf.Struct
      value:
        cluster_refresh_rate: 4s
        cluster_refresh_timeout: 0.25s
  )EOF";

const std::string ZoneDiscoveryConfig = R"EOF(
  name: name
  connect_timeout: 0.25s
  dns_lookup_family: V4_ONLY
  load_assignment:
        endpoints:
          - lb_endpoints:
            - endpoint:
                address:
                  socket_address:
                    address: foo.bar.com
                    port_value: 22120
  cluster_type:
    name: envoy.clusters.redis
    typed_config:
      "@type": type.googleapis.com/google.protobuf.Struct
      value:
        cluster_refresh_rate: 4s
        cluster_refresh_timeout: 0.25s
        enable_zone_discovery: true
  )EOF";
} // namespace

static const int ResponseFlagSize = 11;
static const int ResponseReplicaFlagSize = 4;
class RedisClusterTest : public testing::Test,
                         public Extensions::NetworkFilters::Common::Redis::Client::ClientFactory {
public:
  // ClientFactory
  Extensions::NetworkFilters::Common::Redis::Client::ClientPtr
  create(Upstream::HostConstSharedPtr host, Event::Dispatcher&,
         const Extensions::NetworkFilters::Common::Redis::Client::ConfigSharedPtr& config,
         const Extensions::NetworkFilters::Common::Redis::RedisCommandStatsSharedPtr&,
         Stats::Scope&, const std::string&, const std::string&, bool,
         std::optional<envoy::extensions::filters::network::redis_proxy::v3::AwsIam>,
         std::optional<
             NetworkFilters::Common::Redis::AwsIamAuthenticator::AwsIamAuthenticatorSharedPtr>,
         Extensions::NetworkFilters::Common::Redis::RespProtocolVersion,
         OptRef<Stats::Counter>) override {
    EXPECT_EQ(22120, host->address()->ip()->port());
    if (hold_client_configs_) {
      held_client_configs_.push_back(config);
    }
    return Extensions::NetworkFilters::Common::Redis::Client::ClientPtr{
        create_(host->address()->asString())};
  }

  MOCK_METHOD(Extensions::NetworkFilters::Common::Redis::Client::Client*, create_, (std::string));

protected:
  RedisClusterTest() : api_(Api::createApiForTest(stats_store_, random_)) {
    ON_CALL(server_context_, api()).WillByDefault(testing::ReturnRef(*api_));
  }

  std::list<std::string> hostListToAddresses(const Upstream::HostVector& hosts) {
    std::list<std::string> addresses;
    for (const Upstream::HostSharedPtr& host : hosts) {
      addresses.push_back(host->address()->asString());
    }

    return addresses;
  }

  void setupFromV3Yaml(const std::string& yaml) {
    expectRedisSessionCreated();
    envoy::config::cluster::v3::Cluster cluster_config = Upstream::parseClusterFromV3Yaml(yaml);
    NiceMock<Upstream::Outlier::EventLoggerSharedPtr> outlier_event_logger;

    Upstream::ClusterFactoryContextImpl cluster_factory_context(
        server_context_, [this]() -> Network::DnsResolverSharedPtr { return this->dns_resolver_; },
        std::move(outlier_event_logger), false);

    envoy::extensions::clusters::redis::v3::RedisClusterConfig config;
    THROW_IF_NOT_OK(Config::Utility::translateOpaqueConfig(
        cluster_config.cluster_type().typed_config(), ProtobufMessage::getStrictValidationVisitor(),
        config));
    cluster_callback_ = std::make_shared<NiceMock<MockClusterSlotUpdateCallBack>>();
    cluster_ = std::shared_ptr<RedisCluster>(*RedisCluster::create(
        cluster_config,
        TestUtility::downcastAndValidate<
            const envoy::extensions::clusters::redis::v3::RedisClusterConfig&>(config),
        cluster_factory_context, *this, dns_resolver_, cluster_callback_));
    // This allows us to create expectation on cluster slot response without waiting for
    // makeRequest.
    pool_callbacks_ = cluster_->redis_discovery_session_.get();
    priority_update_cb_ = cluster_->prioritySet().addPriorityUpdateCb(
        [&](uint32_t, const Upstream::HostVector&, const Upstream::HostVector&) {
          membership_updated_.ready();
          return absl::OkStatus();
        });
  }

  absl::Status setupFactoryFromV3Yaml(const std::string& yaml, bool allow_failure = false) {
    envoy::config::cluster::v3::Cluster cluster_config = Upstream::parseClusterFromV3Yaml(yaml);

    envoy::extensions::clusters::redis::v3::RedisClusterConfig config;
    RETURN_IF_NOT_OK(Config::Utility::translateOpaqueConfig(
        cluster_config.cluster_type().typed_config(), validation_visitor_, config));

    NiceMock<AccessLog::MockAccessLogManager> log_manager;
    NiceMock<Upstream::Outlier::EventLoggerSharedPtr> outlier_event_logger;
    NiceMock<Envoy::Api::MockApi> api;
    Upstream::ClusterFactoryContextImpl cluster_factory_context(
        server_context_, [this]() -> Network::DnsResolverSharedPtr { return this->dns_resolver_; },
        std::move(outlier_event_logger), false);

    RedisClusterFactory factory = RedisClusterFactory();
    auto status =
        factory.createClusterWithConfig(cluster_config, config, cluster_factory_context).status();
    ASSERT(allow_failure || status.ok());
    return status;
  }

  void expectResolveDiscovery(Network::DnsLookupFamily dns_lookup_family,
                              const std::string& expected_address,
                              const std::list<std::string>& resolved_addresses,
                              Network::DnsResolver::ResolutionStatus status =
                                  Network::DnsResolver::ResolutionStatus::Completed) {
    EXPECT_CALL(*dns_resolver_, resolve(expected_address, dns_lookup_family, _))
        .WillOnce(Invoke([status, resolved_addresses](
                             const std::string&, Network::DnsLookupFamily,
                             Network::DnsResolver::ResolveCb cb) -> Network::ActiveDnsQuery* {
          cb(status, "", TestUtility::makeDnsResponse(resolved_addresses));
          return nullptr;
        }));
  }

  void expectRedisSessionCreated() {
    resolve_timer_ = new Event::MockTimer(&server_context_.dispatcher_);
    EXPECT_CALL(*resolve_timer_, disableTimer());
    ON_CALL(random_, random()).WillByDefault(Return(0));
  }

  void expectRedisResolve(bool create_client = false) {
    if (create_client) {
      client_ = new Extensions::NetworkFilters::Common::Redis::Client::MockClient();
      EXPECT_CALL(*this, create_(_)).WillOnce(Return(client_));
      EXPECT_CALL(*client_, addConnectionCallbacks(_));
      EXPECT_CALL(*client_, close());
    }
    EXPECT_CALL(*client_, makeRequest_(Ref(RedisCluster::ClusterSlotsRequest::instance_), _))
        .WillOnce(Return(&pool_request_));
  }

  void expectClusterSlotResponse(NetworkFilters::Common::Redis::RespValuePtr&& response) {
    EXPECT_CALL(*resolve_timer_, enableTimer(_, _));
    pool_callbacks_->onResponse(std::move(response));
  }

  void expectClusterSlotFailure() {
    EXPECT_CALL(*resolve_timer_, enableTimer(_, _));
    pool_callbacks_->onFailure();
  }

  // Sets up a zone discovery test with two nodes (primary=127.0.0.1, replica=127.0.0.2).
  // Initializes the cluster, creates mock clients, sets up INFO expectations, and delivers
  // CLUSTER SLOTS. Returns the zone_client for the replica node so the caller can deliver
  // INFO responses via client_->client_callbacks_ and zone_client->client_callbacks_.
  Extensions::NetworkFilters::Common::Redis::Client::MockClient* setupZoneDiscoveryWithTwoNodes() {
    setupFromV3Yaml(ZoneDiscoveryConfig);
    const std::list<std::string> resolved_addresses{"127.0.0.1", "127.0.0.2"};
    expectResolveDiscovery(Network::DnsLookupFamily::V4Only, "foo.bar.com", resolved_addresses);
    expectRedisResolve(true);

    EXPECT_CALL(membership_updated_, ready());
    EXPECT_CALL(initialized_, ready());
    cluster_->initialize([&]() {
      initialized_.ready();
      return absl::OkStatus();
    });

    auto* zone_client = new Extensions::NetworkFilters::Common::Redis::Client::MockClient();
    EXPECT_CALL(*this, create_(_)).WillOnce(Return(zone_client));
    EXPECT_CALL(*zone_client, addConnectionCallbacks(_));
    EXPECT_CALL(*zone_client, close());

    EXPECT_CALL(*client_, makeRequest_(Ref(RedisCluster::InfoRequest::instance_), _))
        .WillOnce(Return(&pool_request_));
    EXPECT_CALL(*zone_client, makeRequest_(Ref(RedisCluster::InfoRequest::instance_), _))
        .WillOnce(Return(&pool_request_));

    EXPECT_CALL(*cluster_callback_, onClusterSlotUpdate(_, _));
    EXPECT_CALL(*resolve_timer_, enableTimer(_, _));

    pool_callbacks_->onResponse(singleSlotPrimaryReplica("127.0.0.1", "127.0.0.2", 22120));

    return zone_client;
  }

  NetworkFilters::Common::Redis::RespValuePtr singleSlotPrimary(const std::string& primary,
                                                                int64_t port) const {
    std::vector<NetworkFilters::Common::Redis::RespValue> primary_1(2);
    primary_1[0].type(NetworkFilters::Common::Redis::RespType::BulkString);
    primary_1[0].asString() = primary;
    primary_1[1].type(NetworkFilters::Common::Redis::RespType::Integer);
    primary_1[1].asInteger() = port;

    std::vector<NetworkFilters::Common::Redis::RespValue> slot_1(3);
    slot_1[0].type(NetworkFilters::Common::Redis::RespType::Integer);
    slot_1[0].asInteger() = 0;
    slot_1[1].type(NetworkFilters::Common::Redis::RespType::Integer);
    slot_1[1].asInteger() = 16383;
    slot_1[2].type(NetworkFilters::Common::Redis::RespType::Array);
    slot_1[2].asArray().swap(primary_1);

    std::vector<NetworkFilters::Common::Redis::RespValue> slots(1);
    slots[0].type(NetworkFilters::Common::Redis::RespType::Array);
    slots[0].asArray().swap(slot_1);

    NetworkFilters::Common::Redis::RespValuePtr response(
        new NetworkFilters::Common::Redis::RespValue());
    response->type(NetworkFilters::Common::Redis::RespType::Array);
    response->asArray().swap(slots);
    return response;
  }

  NetworkFilters::Common::Redis::RespValuePtr singleSlotPrimaryReplica(const std::string& primary,
                                                                       const std::string& replica,
                                                                       int64_t port) const {
    std::vector<NetworkFilters::Common::Redis::RespValue> primary_1(2);
    primary_1[0].type(NetworkFilters::Common::Redis::RespType::BulkString);
    primary_1[0].asString() = primary;
    primary_1[1].type(NetworkFilters::Common::Redis::RespType::Integer);
    primary_1[1].asInteger() = port;

    std::vector<NetworkFilters::Common::Redis::RespValue> replica_1(2);
    replica_1[0].type(NetworkFilters::Common::Redis::RespType::BulkString);
    replica_1[0].asString() = replica;
    replica_1[1].type(NetworkFilters::Common::Redis::RespType::Integer);
    replica_1[1].asInteger() = port;

    std::vector<NetworkFilters::Common::Redis::RespValue> slot_1(ResponseReplicaFlagSize);
    slot_1[0].type(NetworkFilters::Common::Redis::RespType::Integer);
    slot_1[0].asInteger() = 0;
    slot_1[1].type(NetworkFilters::Common::Redis::RespType::Integer);
    slot_1[1].asInteger() = 16383;
    slot_1[2].type(NetworkFilters::Common::Redis::RespType::Array);
    slot_1[2].asArray().swap(primary_1);
    slot_1[3].type(NetworkFilters::Common::Redis::RespType::Array);
    slot_1[3].asArray().swap(replica_1);

    std::vector<NetworkFilters::Common::Redis::RespValue> slots(1);
    slots[0].type(NetworkFilters::Common::Redis::RespType::Array);
    slots[0].asArray().swap(slot_1);

    NetworkFilters::Common::Redis::RespValuePtr response(
        new NetworkFilters::Common::Redis::RespValue());
    response->type(NetworkFilters::Common::Redis::RespType::Array);
    response->asArray().swap(slots);
    return response;
  }

  NetworkFilters::Common::Redis::RespValuePtr
  singleSlotPrimaryWithTwoReplicas(const std::string& primary, const std::string& replica_1,
                                   const std::string& replica_2, int64_t port) const {
    std::vector<NetworkFilters::Common::Redis::RespValue> primary_1(2);
    primary_1[0].type(NetworkFilters::Common::Redis::RespType::BulkString);
    primary_1[0].asString() = primary;
    primary_1[1].type(NetworkFilters::Common::Redis::RespType::Integer);
    primary_1[1].asInteger() = port;

    std::vector<NetworkFilters::Common::Redis::RespValue> repl_1(2);
    repl_1[0].type(NetworkFilters::Common::Redis::RespType::BulkString);
    repl_1[0].asString() = replica_1;
    repl_1[1].type(NetworkFilters::Common::Redis::RespType::Integer);
    repl_1[1].asInteger() = port;

    std::vector<NetworkFilters::Common::Redis::RespValue> repl_2(2);
    repl_2[0].type(NetworkFilters::Common::Redis::RespType::BulkString);
    repl_2[0].asString() = replica_2;
    repl_2[1].type(NetworkFilters::Common::Redis::RespType::Integer);
    repl_2[1].asInteger() = port;

    std::vector<NetworkFilters::Common::Redis::RespValue> slot_1(5);
    slot_1[0].type(NetworkFilters::Common::Redis::RespType::Integer);
    slot_1[0].asInteger() = 0;
    slot_1[1].type(NetworkFilters::Common::Redis::RespType::Integer);
    slot_1[1].asInteger() = 16383;
    slot_1[2].type(NetworkFilters::Common::Redis::RespType::Array);
    slot_1[2].asArray().swap(primary_1);
    slot_1[3].type(NetworkFilters::Common::Redis::RespType::Array);
    slot_1[3].asArray().swap(repl_1);
    slot_1[4].type(NetworkFilters::Common::Redis::RespType::Array);
    slot_1[4].asArray().swap(repl_2);

    std::vector<NetworkFilters::Common::Redis::RespValue> slots(1);
    slots[0].type(NetworkFilters::Common::Redis::RespType::Array);
    slots[0].asArray().swap(slot_1);

    NetworkFilters::Common::Redis::RespValuePtr response(
        new NetworkFilters::Common::Redis::RespValue());
    response->type(NetworkFilters::Common::Redis::RespType::Array);
    response->asArray().swap(slots);
    return response;
  }

  NetworkFilters::Common::Redis::RespValuePtr twoSlotsPrimaries() const {
    std::vector<NetworkFilters::Common::Redis::RespValue> primary_1(2);
    primary_1[0].type(NetworkFilters::Common::Redis::RespType::BulkString);
    primary_1[0].asString() = "127.0.0.1";
    primary_1[1].type(NetworkFilters::Common::Redis::RespType::Integer);
    primary_1[1].asInteger() = 22120;

    std::vector<NetworkFilters::Common::Redis::RespValue> primary_2(2);
    primary_2[0].type(NetworkFilters::Common::Redis::RespType::BulkString);
    primary_2[0].asString() = "127.0.0.2";
    primary_2[1].type(NetworkFilters::Common::Redis::RespType::Integer);
    primary_2[1].asInteger() = 22120;

    std::vector<NetworkFilters::Common::Redis::RespValue> slot_1(3);
    slot_1[0].type(NetworkFilters::Common::Redis::RespType::Integer);
    slot_1[0].asInteger() = 0;
    slot_1[1].type(NetworkFilters::Common::Redis::RespType::Integer);
    slot_1[1].asInteger() = 9999;
    slot_1[2].type(NetworkFilters::Common::Redis::RespType::Array);
    slot_1[2].asArray().swap(primary_1);

    std::vector<NetworkFilters::Common::Redis::RespValue> slot_2(3);
    slot_2[0].type(NetworkFilters::Common::Redis::RespType::Integer);
    slot_2[0].asInteger() = 10000;
    slot_2[1].type(NetworkFilters::Common::Redis::RespType::Integer);
    slot_2[1].asInteger() = 16383;
    slot_2[2].type(NetworkFilters::Common::Redis::RespType::Array);
    slot_2[2].asArray().swap(primary_2);

    std::vector<NetworkFilters::Common::Redis::RespValue> slots(2);
    slots[0].type(NetworkFilters::Common::Redis::RespType::Array);
    slots[0].asArray().swap(slot_1);
    slots[1].type(NetworkFilters::Common::Redis::RespType::Array);
    slots[1].asArray().swap(slot_2);

    NetworkFilters::Common::Redis::RespValuePtr response(
        new NetworkFilters::Common::Redis::RespValue());
    response->type(NetworkFilters::Common::Redis::RespType::Array);
    response->asArray().swap(slots);
    return response;
  }

  NetworkFilters::Common::Redis::RespValuePtr twoSlotsPrimariesWithReplica() const {
    std::vector<NetworkFilters::Common::Redis::RespValue> primary_1(2);
    primary_1[0].type(NetworkFilters::Common::Redis::RespType::BulkString);
    primary_1[0].asString() = "127.0.0.1";
    primary_1[1].type(NetworkFilters::Common::Redis::RespType::Integer);
    primary_1[1].asInteger() = 22120;

    std::vector<NetworkFilters::Common::Redis::RespValue> primary_2(2);
    primary_2[0].type(NetworkFilters::Common::Redis::RespType::BulkString);
    primary_2[0].asString() = "127.0.0.2";
    primary_2[1].type(NetworkFilters::Common::Redis::RespType::Integer);
    primary_2[1].asInteger() = 22120;

    std::vector<NetworkFilters::Common::Redis::RespValue> replica_1(2);
    replica_1[0].type(NetworkFilters::Common::Redis::RespType::BulkString);
    replica_1[0].asString() = "127.0.0.3";
    replica_1[1].type(NetworkFilters::Common::Redis::RespType::Integer);
    replica_1[1].asInteger() = 22120;

    std::vector<NetworkFilters::Common::Redis::RespValue> replica_2(2);
    replica_2[0].type(NetworkFilters::Common::Redis::RespType::BulkString);
    replica_2[0].asString() = "127.0.0.4";
    replica_2[1].type(NetworkFilters::Common::Redis::RespType::Integer);
    replica_2[1].asInteger() = 22120;

    std::vector<NetworkFilters::Common::Redis::RespValue> slot_1(ResponseReplicaFlagSize);
    slot_1[0].type(NetworkFilters::Common::Redis::RespType::Integer);
    slot_1[0].asInteger() = 0;
    slot_1[1].type(NetworkFilters::Common::Redis::RespType::Integer);
    slot_1[1].asInteger() = 9999;
    slot_1[2].type(NetworkFilters::Common::Redis::RespType::Array);
    slot_1[2].asArray().swap(primary_1);
    slot_1[3].type(NetworkFilters::Common::Redis::RespType::Array);
    slot_1[3].asArray().swap(replica_1);

    std::vector<NetworkFilters::Common::Redis::RespValue> slot_2(ResponseReplicaFlagSize);
    slot_2[0].type(NetworkFilters::Common::Redis::RespType::Integer);
    slot_2[0].asInteger() = 10000;
    slot_2[1].type(NetworkFilters::Common::Redis::RespType::Integer);
    slot_2[1].asInteger() = 16383;
    slot_2[2].type(NetworkFilters::Common::Redis::RespType::Array);
    slot_2[2].asArray().swap(primary_2);
    slot_2[3].type(NetworkFilters::Common::Redis::RespType::Array);
    slot_2[3].asArray().swap(replica_2);

    std::vector<NetworkFilters::Common::Redis::RespValue> slots(2);
    slots[0].type(NetworkFilters::Common::Redis::RespType::Array);
    slots[0].asArray().swap(slot_1);
    slots[1].type(NetworkFilters::Common::Redis::RespType::Array);
    slots[1].asArray().swap(slot_2);

    NetworkFilters::Common::Redis::RespValuePtr response(
        new NetworkFilters::Common::Redis::RespValue());
    response->type(NetworkFilters::Common::Redis::RespType::Array);
    response->asArray().swap(slots);
    return response;
  }

  NetworkFilters::Common::Redis::RespValuePtr
  twoSlotsPrimariesHostnames(const std::string& primary1, const std::string& primary2,
                             int64_t port) const {
    std::vector<NetworkFilters::Common::Redis::RespValue> primary_1(2);
    primary_1[0].type(NetworkFilters::Common::Redis::RespType::BulkString);
    primary_1[0].asString() = primary1;
    primary_1[1].type(NetworkFilters::Common::Redis::RespType::Integer);
    primary_1[1].asInteger() = port;

    std::vector<NetworkFilters::Common::Redis::RespValue> primary_2(2);
    primary_2[0].type(NetworkFilters::Common::Redis::RespType::BulkString);
    primary_2[0].asString() = primary2;
    primary_2[1].type(NetworkFilters::Common::Redis::RespType::Integer);
    primary_2[1].asInteger() = port;

    std::vector<NetworkFilters::Common::Redis::RespValue> slot_1(3);
    slot_1[0].type(NetworkFilters::Common::Redis::RespType::Integer);
    slot_1[0].asInteger() = 0;
    slot_1[1].type(NetworkFilters::Common::Redis::RespType::Integer);
    slot_1[1].asInteger() = 9999;
    slot_1[2].type(NetworkFilters::Common::Redis::RespType::Array);
    slot_1[2].asArray().swap(primary_1);

    std::vector<NetworkFilters::Common::Redis::RespValue> slot_2(3);
    slot_2[0].type(NetworkFilters::Common::Redis::RespType::Integer);
    slot_2[0].asInteger() = 10000;
    slot_2[1].type(NetworkFilters::Common::Redis::RespType::Integer);
    slot_2[1].asInteger() = 16383;
    slot_2[2].type(NetworkFilters::Common::Redis::RespType::Array);
    slot_2[2].asArray().swap(primary_2);

    std::vector<NetworkFilters::Common::Redis::RespValue> slots(2);
    slots[0].type(NetworkFilters::Common::Redis::RespType::Array);
    slots[0].asArray().swap(slot_1);
    slots[1].type(NetworkFilters::Common::Redis::RespType::Array);
    slots[1].asArray().swap(slot_2);

    NetworkFilters::Common::Redis::RespValuePtr response(
        new NetworkFilters::Common::Redis::RespValue());
    response->type(NetworkFilters::Common::Redis::RespType::Array);
    response->asArray().swap(slots);
    return response;
  }

  NetworkFilters::Common::Redis::RespValue
  createStringField(bool is_correct_type, const std::string& correct_value) const {
    NetworkFilters::Common::Redis::RespValue respValue;
    if (is_correct_type) {
      respValue.type(NetworkFilters::Common::Redis::RespType::BulkString);
      respValue.asString() = correct_value;
    } else {
      respValue.type(NetworkFilters::Common::Redis::RespType::Integer);
      respValue.asInteger() = ResponseFlagSize;
    }
    return respValue;
  }

  NetworkFilters::Common::Redis::RespValue createIntegerField(bool is_correct_type,
                                                              int64_t correct_value) const {
    NetworkFilters::Common::Redis::RespValue respValue;
    if (is_correct_type) {
      respValue.type(NetworkFilters::Common::Redis::RespType::Integer);
      respValue.asInteger() = correct_value;
    } else {
      respValue.type(NetworkFilters::Common::Redis::RespType::BulkString);
      respValue.asString() = "bad_value";
    }
    return respValue;
  }

  NetworkFilters::Common::Redis::RespValue
  createArrayField(bool is_correct_type,
                   std::vector<NetworkFilters::Common::Redis::RespValue>& correct_value) const {
    NetworkFilters::Common::Redis::RespValue respValue;
    if (is_correct_type) {
      respValue.type(NetworkFilters::Common::Redis::RespType::Array);
      respValue.asArray().swap(correct_value);
    } else {
      respValue.type(NetworkFilters::Common::Redis::RespType::BulkString);
      respValue.asString() = "bad value";
    }
    return respValue;
  }

  // Create a redis cluster slot response. If a bit is set in the bitset, then that part of
  // of the response is correct, otherwise it's incorrect.
  NetworkFilters::Common::Redis::RespValuePtr
  createResponse(std::bitset<ResponseFlagSize> flags,
                 std::bitset<ResponseReplicaFlagSize> replica_flags) const {
    int64_t idx(0);
    int64_t slots_type = idx++;
    int64_t slots_size = idx++;
    int64_t slot1_type = idx++;
    int64_t slot1_size = idx++;
    int64_t slot1_range_start_type = idx++;
    int64_t slot1_range_end_type = idx++;
    int64_t primary_type = idx++;
    int64_t primary_size = idx++;
    int64_t primary_ip_type = idx++;
    int64_t primary_ip_value = idx++;
    int64_t primary_port_type = idx++;
    idx = 0;
    int64_t replica_size = idx++;
    int64_t replica_ip_type = idx++;
    int64_t replica_ip_value = idx++;
    int64_t replica_port_type = idx++;

    std::vector<NetworkFilters::Common::Redis::RespValue> primary_1_array;
    if (flags.test(primary_size)) {
      // Ip field.
      if (flags.test(primary_ip_value)) {
        primary_1_array.push_back(createStringField(flags.test(primary_ip_type), "127.0.0.1"));
      } else {
        primary_1_array.push_back(createStringField(flags.test(primary_ip_type), ""));
      }
      // Port field.
      primary_1_array.push_back(createIntegerField(flags.test(primary_port_type), 22120));
    }

    std::vector<NetworkFilters::Common::Redis::RespValue> replica_1_array;
    if (replica_flags.any()) {
      // Ip field.
      if (replica_flags.test(replica_ip_value)) {
        replica_1_array.push_back(
            createStringField(replica_flags.test(replica_ip_type), "127.0.0.2"));
      } else {
        replica_1_array.push_back(createStringField(replica_flags.test(replica_ip_type), ""));
      }
      // Port field.
      replica_1_array.push_back(createIntegerField(replica_flags.test(replica_port_type), 22120));
    }

    std::vector<NetworkFilters::Common::Redis::RespValue> slot_1_array;
    if (flags.test(slot1_size)) {
      slot_1_array.push_back(createIntegerField(flags.test(slot1_range_start_type), 0));
      slot_1_array.push_back(createIntegerField(flags.test(slot1_range_end_type), 16383));
      slot_1_array.push_back(createArrayField(flags.test(primary_type), primary_1_array));
      if (replica_flags.any()) {
        slot_1_array.push_back(createArrayField(replica_flags.test(replica_size), replica_1_array));
      }
    }

    std::vector<NetworkFilters::Common::Redis::RespValue> slots_array;
    if (flags.test(slots_size)) {
      slots_array.push_back(createArrayField(flags.test(slot1_type), slot_1_array));
    }

    NetworkFilters::Common::Redis::RespValuePtr response{
        new NetworkFilters::Common::Redis::RespValue()};
    if (flags.test(slots_type)) {
      response->type(NetworkFilters::Common::Redis::RespType::Array);
      response->asArray().swap(slots_array);
    } else {
      response->type(NetworkFilters::Common::Redis::RespType::BulkString);
      response->asString() = "Pong";
    }

    return response;
  }

  void
  expectHealthyHosts(const std::list<std::string, std::allocator<std::string>>& healthy_hosts) {
    EXPECT_THAT(healthy_hosts, ContainerEq(hostListToAddresses(
                                   cluster_->prioritySet().hostSetsPerPriority()[0]->hosts())));
    EXPECT_THAT(healthy_hosts,
                ContainerEq(hostListToAddresses(
                    cluster_->prioritySet().hostSetsPerPriority()[0]->healthyHosts())));
    EXPECT_EQ(1UL,
              cluster_->prioritySet().hostSetsPerPriority()[0]->hostsPerLocality().get().size());
    EXPECT_EQ(
        1UL,
        cluster_->prioritySet().hostSetsPerPriority()[0]->healthyHostsPerLocality().get().size());
  }

  void testBasicSetup(const std::string& config, const std::string& expected_discovery_address) {
    setupFromV3Yaml(config);
    const std::list<std::string> resolved_addresses{"127.0.0.1", "127.0.0.2"};
    expectResolveDiscovery(Network::DnsLookupFamily::V4Only, expected_discovery_address,
                           resolved_addresses);
    expectRedisResolve(true);

    EXPECT_CALL(membership_updated_, ready());
    EXPECT_CALL(initialized_, ready());
    cluster_->initialize([&]() {
      initialized_.ready();
      return absl::OkStatus();
    });

    EXPECT_CALL(*cluster_callback_, onClusterSlotUpdate(_, _));
    expectClusterSlotResponse(singleSlotPrimaryReplica("127.0.0.1", "127.0.0.2", 22120));
    expectHealthyHosts(std::list<std::string>({"127.0.0.1:22120", "127.0.0.2:22120"}));

    // Promote replica to primary
    expectRedisResolve();
    EXPECT_CALL(membership_updated_, ready());
    resolve_timer_->invokeCallback();
    EXPECT_CALL(*cluster_callback_, onClusterSlotUpdate(_, _));
    expectClusterSlotResponse(twoSlotsPrimaries());
    expectHealthyHosts(std::list<std::string>({"127.0.0.1:22120", "127.0.0.2:22120"}));

    // No change.
    expectRedisResolve();
    resolve_timer_->invokeCallback();
    EXPECT_CALL(*cluster_callback_, onClusterSlotUpdate(_, _)).WillOnce(Return(false));
    expectClusterSlotResponse(twoSlotsPrimaries());
    expectHealthyHosts(std::list<std::string>({"127.0.0.1:22120", "127.0.0.2:22120"}));

    // Add replicas to primaries
    expectRedisResolve();
    EXPECT_CALL(membership_updated_, ready());
    resolve_timer_->invokeCallback();
    EXPECT_CALL(*cluster_callback_, onClusterSlotUpdate(_, _));
    expectClusterSlotResponse(twoSlotsPrimariesWithReplica());
    expectHealthyHosts(std::list<std::string>(
        {"127.0.0.1:22120", "127.0.0.3:22120", "127.0.0.2:22120", "127.0.0.4:22120"}));

    // No change.
    expectRedisResolve();
    resolve_timer_->invokeCallback();
    EXPECT_CALL(*cluster_callback_, onClusterSlotUpdate(_, _)).WillOnce(Return(false));
    expectClusterSlotResponse(twoSlotsPrimariesWithReplica());
    expectHealthyHosts(std::list<std::string>(
        {"127.0.0.1:22120", "127.0.0.3:22120", "127.0.0.2:22120", "127.0.0.4:22120"}));

    // Remove 2nd shard.
    expectRedisResolve();
    EXPECT_CALL(membership_updated_, ready());
    resolve_timer_->invokeCallback();
    EXPECT_CALL(*cluster_callback_, onClusterSlotUpdate(_, _));
    expectClusterSlotResponse(singleSlotPrimaryReplica("127.0.0.1", "127.0.0.2", 22120));
    expectHealthyHosts(std::list<std::string>({"127.0.0.1:22120", "127.0.0.2:22120"}));
  }

  void exerciseStubs() {
    EXPECT_CALL(server_context_.dispatcher_, createTimer_(_));
    RedisCluster::RedisDiscoverySession discovery_session(*cluster_, *this);
    EXPECT_FALSE(discovery_session.enableHashtagging());
    EXPECT_EQ(discovery_session.bufferFlushTimeoutInMs(), std::chrono::milliseconds(0));
    EXPECT_EQ(discovery_session.maxUpstreamUnknownConnections(), 0);

    NetworkFilters::Common::Redis::RespValuePtr dummy_value{
        new NetworkFilters::Common::Redis::RespValue()};
    dummy_value->type(NetworkFilters::Common::Redis::RespType::Error);
    dummy_value->asString() = "dummy text";
    discovery_session.onRedirection(std::move(dummy_value), "dummy ip", false);

    RedisCluster::RedisDiscoveryClient discovery_client(discovery_session);
    EXPECT_NO_THROW(discovery_client.onAboveWriteBufferHighWatermark());
    EXPECT_NO_THROW(discovery_client.onBelowWriteBufferLowWatermark());
  }

  void testDnsResolve(const char* const address, const int port) {
    RedisCluster::DnsDiscoveryResolveTarget resolver_target(*cluster_, address, port);
    EXPECT_CALL(*dns_resolver_, resolve(address, Network::DnsLookupFamily::V4Only, _))
        .WillOnce(Invoke([&](const std::string&, Network::DnsLookupFamily,
                             Network::DnsResolver::ResolveCb) -> Network::ActiveDnsQuery* {
          return &active_dns_query_;
        }));
    resolver_target.startResolveDns();

    EXPECT_CALL(active_dns_query_, cancel(Network::ActiveDnsQuery::CancelReason::QueryAbandoned));
  }

  NiceMock<Server::Configuration::MockServerFactoryContext> server_context_;
  Stats::TestUtil::TestStore& stats_store_ = server_context_.store_;
  NiceMock<Random::MockRandomGenerator> random_;
  Api::ApiPtr api_;

  std::shared_ptr<NiceMock<Network::MockDnsResolver>> dns_resolver_{
      new NiceMock<Network::MockDnsResolver>};
  Event::MockTimer* resolve_timer_;
  ReadyWatcher membership_updated_;
  ReadyWatcher initialized_;
  NiceMock<ProtobufMessage::MockValidationVisitor> validation_visitor_;
  std::shared_ptr<Upstream::MockClusterMockPrioritySet> hosts_;
  Upstream::MockHealthCheckEventLogger* event_logger_{};
  Event::MockTimer* interval_timer_{};
  Extensions::NetworkFilters::Common::Redis::Client::MockClient* client_{};
  Extensions::NetworkFilters::Common::Redis::Client::MockPoolRequest pool_request_;
  Extensions::NetworkFilters::Common::Redis::Client::ClientCallbacks* pool_callbacks_{};
  std::shared_ptr<RedisCluster> cluster_;
  std::shared_ptr<NiceMock<MockClusterSlotUpdateCallBack>> cluster_callback_;
  Network::MockActiveDnsQuery active_dns_query_;
  Envoy::Common::CallbackHandlePtr priority_update_cb_;
  NiceMock<AccessLog::MockAccessLogManager> access_log_manager_;
  // When set, create() keeps a copy of the session config shared_ptr, mirroring the production
  // ClientImpl which stores the config and thereby keeps the discovery session alive until the
  // client's deferred deletion runs. Declared last so the references are dropped first during
  // fixture teardown.
  bool hold_client_configs_{false};
  std::vector<Extensions::NetworkFilters::Common::Redis::Client::ConfigSharedPtr>
      held_client_configs_;
};

using RedisDnsConfigTuple = std::tuple<std::string, Network::DnsLookupFamily,
                                       std::list<std::string>, std::list<std::string>>;
std::vector<RedisDnsConfigTuple> generateRedisDnsParams() {
  std::vector<RedisDnsConfigTuple> dns_config;
  {
    std::string family_yaml("");
    Network::DnsLookupFamily family(Network::DnsLookupFamily::Auto);
    std::list<std::string> dns_response{"127.0.0.1", "127.0.0.2"};
    std::list<std::string> resolved_host{"127.0.0.1:22120", "127.0.0.2:22120"};
    dns_config.push_back(std::make_tuple(family_yaml, family, dns_response, resolved_host));
  }
  {
    std::string family_yaml(R"EOF(dns_lookup_family: V4_ONLY)EOF");
    Network::DnsLookupFamily family(Network::DnsLookupFamily::V4Only);
    std::list<std::string> dns_response{"127.0.0.1", "127.0.0.2"};
    std::list<std::string> resolved_host{"127.0.0.1:22120", "127.0.0.2:22120"};
    dns_config.push_back(std::make_tuple(family_yaml, family, dns_response, resolved_host));
  }
  {
    std::string family_yaml(R"EOF(dns_lookup_family: V6_ONLY)EOF");
    Network::DnsLookupFamily family(Network::DnsLookupFamily::V6Only);
    std::list<std::string> dns_response{"::1", "2001:0db8:85a3:0000:0000:8a2e:0370:7334"};
    std::list<std::string> resolved_host{"[::1]:22120", "[2001:db8:85a3::8a2e:370:7334]:22120"};
    dns_config.push_back(std::make_tuple(family_yaml, family, dns_response, resolved_host));
  }
  {
    std::string family_yaml(R"EOF(dns_lookup_family: AUTO)EOF");
    Network::DnsLookupFamily family(Network::DnsLookupFamily::Auto);
    std::list<std::string> dns_response{"::1", "2001:0db8:85a3:0000:0000:8a2e:0370:7334"};
    std::list<std::string> resolved_host{"[::1]:22120", "[2001:db8:85a3::8a2e:370:7334]:22120"};
    dns_config.push_back(std::make_tuple(family_yaml, family, dns_response, resolved_host));
  }
  return dns_config;
}

class RedisDnsParamTest : public RedisClusterTest,
                          public testing::WithParamInterface<RedisDnsConfigTuple> {};

INSTANTIATE_TEST_SUITE_P(DnsParam, RedisDnsParamTest, testing::ValuesIn(generateRedisDnsParams()));

// Validate that if the DNS and CLUSTER SLOT resolve immediately, we have the expected
// host state and initialization callback invocation.

TEST_P(RedisDnsParamTest, ImmediateResolveDns) {
  const std::string config = R"EOF(
  name: name
  connect_timeout: 0.25s
  )EOF" + std::get<0>(GetParam()) +
                             R"EOF(
  load_assignment:
        endpoints:
          - lb_endpoints:
            - endpoint:
                address:
                  socket_address:
                    address: foo.bar.com
                    port_value: 22120
  cluster_type:
    name: envoy.clusters.redis
    typed_config:
      "@type": type.googleapis.com/google.protobuf.Struct
      value:
        cluster_refresh_rate: 4s
        cluster_refresh_timeout: 0.25s
  )EOF";

  setupFromV3Yaml(config);

  expectRedisResolve(true);
  EXPECT_CALL(*dns_resolver_, resolve("foo.bar.com", std::get<1>(GetParam()), _))
      .WillOnce(Invoke([&](const std::string&, Network::DnsLookupFamily,
                           Network::DnsResolver::ResolveCb cb) -> Network::ActiveDnsQuery* {
        std::list<std::string> address_pair = std::get<2>(GetParam());
        cb(Network::DnsResolver::ResolutionStatus::Completed, "",
           TestUtility::makeDnsResponse(address_pair));
        EXPECT_CALL(*cluster_callback_, onClusterSlotUpdate(_, _));
        expectClusterSlotResponse(
            singleSlotPrimaryReplica(address_pair.front(), address_pair.back(), 22120));
        return nullptr;
      }));

  EXPECT_CALL(membership_updated_, ready());
  EXPECT_CALL(initialized_, ready());
  cluster_->initialize([&]() {
    initialized_.ready();
    return absl::OkStatus();
  });

  expectHealthyHosts(std::get<3>(GetParam()));
}

TEST_F(RedisClusterTest, AddressAsHostname) {
  setupFromV3Yaml(BasicConfig);
  const std::list<std::string> resolved_addresses{"127.0.0.1", "127.0.0.2"};
  const std::list<std::string> primary_resolved_addresses{"127.0.1.1"};
  const std::list<std::string> replica_resolved_addresses{"127.0.1.2"};
  expectResolveDiscovery(Network::DnsLookupFamily::V4Only, "foo.bar.com", resolved_addresses);
  expectResolveDiscovery(Network::DnsLookupFamily::V4Only, "replica.org",
                         replica_resolved_addresses);
  expectResolveDiscovery(Network::DnsLookupFamily::V4Only, "primary.com",
                         primary_resolved_addresses);
  expectRedisResolve(true);

  EXPECT_CALL(membership_updated_, ready());
  EXPECT_CALL(initialized_, ready());
  cluster_->initialize([&]() {
    initialized_.ready();
    return absl::OkStatus();
  });

  // 1. Single slot with primary and replica
  EXPECT_CALL(*cluster_callback_, onClusterSlotUpdate(_, _));
  expectClusterSlotResponse(singleSlotPrimaryReplica("primary.com", "replica.org", 22120));
  expectHealthyHosts(std::list<std::string>({"127.0.1.1:22120", "127.0.1.2:22120"}));
  EXPECT_EQ(0U, cluster_->info()->configUpdateStats().update_failure_.value());

  // 2. Single slot with just the primary hostname
  expectRedisResolve(true);
  EXPECT_CALL(membership_updated_, ready());
  resolve_timer_->invokeCallback();
  expectResolveDiscovery(Network::DnsLookupFamily::V4Only, "primary.com",
                         primary_resolved_addresses);
  EXPECT_CALL(*cluster_callback_, onClusterSlotUpdate(_, _));
  expectClusterSlotResponse(singleSlotPrimary("primary.com", 22120));
  expectHealthyHosts(std::list<std::string>({"127.0.1.1:22120"}));
  EXPECT_EQ(0U, cluster_->info()->configUpdateStats().update_failure_.value());

  // 2. Single slot with just the primary IP address and replica hostname
  expectRedisResolve();
  EXPECT_CALL(membership_updated_, ready());
  resolve_timer_->invokeCallback();
  expectResolveDiscovery(Network::DnsLookupFamily::V4Only, "replica.org",
                         replica_resolved_addresses);
  EXPECT_CALL(*cluster_callback_, onClusterSlotUpdate(_, _));
  expectClusterSlotResponse(singleSlotPrimaryReplica("127.0.1.1", "replica.org", 22120));
  expectHealthyHosts(std::list<std::string>({"127.0.1.1:22120", "127.0.1.2:22120"}));
  EXPECT_EQ(0U, cluster_->info()->configUpdateStats().update_failure_.value());
}

TEST_F(RedisClusterTest, AddressAsHostnameParallelResolution) {
  // This test specifically ensures that DNS resolution of different hostnames running parallel
  // works as expected.
  setupFromV3Yaml(BasicConfig);
  const std::list<std::string> resolved_addresses{"127.0.0.1", "127.0.0.2"};
  expectResolveDiscovery(Network::DnsLookupFamily::V4Only, "foo.bar.com", resolved_addresses);

  Network::DnsResolver::ResolveCb primary1_resolve_cb;
  Network::DnsResolver::ResolveCb primary2_resolve_cb;
  EXPECT_CALL(*dns_resolver_, resolve("primary1.com", Network::DnsLookupFamily::V4Only, _))
      .WillOnce(DoAll(SaveArg<2>(&primary1_resolve_cb), Return(&dns_resolver_->active_query_)));
  EXPECT_CALL(*dns_resolver_, resolve("primary2.com", Network::DnsLookupFamily::V4Only, _))
      .WillOnce(DoAll(SaveArg<2>(&primary2_resolve_cb), Return(&dns_resolver_->active_query_)));

  expectRedisResolve(true);

  EXPECT_CALL(membership_updated_, ready());
  EXPECT_CALL(initialized_, ready());
  EXPECT_CALL(*cluster_callback_, onClusterSlotUpdate(_, _));
  cluster_->initialize([&]() {
    initialized_.ready();
    return absl::OkStatus();
  });
  expectClusterSlotResponse(twoSlotsPrimariesHostnames("primary1.com", "primary2.com", 22120));
  primary1_resolve_cb(Network::DnsResolver::ResolutionStatus::Completed, "",
                      TestUtility::makeDnsResponse(std::list<std::string>{"127.0.1.1"}));
  primary2_resolve_cb(Network::DnsResolver::ResolutionStatus::Completed, "",
                      TestUtility::makeDnsResponse(std::list<std::string>{"127.0.1.2"}));
  expectHealthyHosts(std::list<std::string>({
      "127.0.1.1:22120",
      "127.0.1.2:22120",
  }));
  EXPECT_EQ(0U, cluster_->info()->configUpdateStats().update_failure_.value());
}

TEST_F(RedisClusterTest, AddressAsHostnameFailure) {
  setupFromV3Yaml(BasicConfig);
  const std::list<std::string> resolved_addresses{"127.0.0.1", "127.0.0.2"};
  const std::list<std::string> primary_resolved_addresses{"127.0.1.1"};
  const std::list<std::string> replica_resolved_addresses{"127.0.1.2"};

  expectResolveDiscovery(Network::DnsLookupFamily::V4Only, "foo.bar.com", resolved_addresses);

  // 1. Primary resolution is successful, but replica fails.
  // Expect cluster slot update to be successful, with just one healthy host, and failure counter to
  // be updated.
  expectResolveDiscovery(Network::DnsLookupFamily::V4Only, "primary.com",
                         primary_resolved_addresses);
  expectResolveDiscovery(Network::DnsLookupFamily::V4Only, "replica.org",
                         replica_resolved_addresses,
                         Network::DnsResolver::ResolutionStatus::Failure);
  expectRedisResolve(true);

  EXPECT_CALL(membership_updated_, ready());
  EXPECT_CALL(initialized_, ready());
  cluster_->initialize([&]() {
    initialized_.ready();
    return absl::OkStatus();
  });

  EXPECT_CALL(*cluster_callback_, onClusterSlotUpdate(_, _));
  expectClusterSlotResponse(singleSlotPrimaryReplica("primary.com", "replica.org", 22120));
  EXPECT_EQ(1UL, cluster_->prioritySet().hostSetsPerPriority()[0]->hosts().size());
  EXPECT_EQ(1UL, cluster_->prioritySet().hostSetsPerPriority()[0]->healthyHosts().size());
  expectHealthyHosts(std::list<std::string>({"127.0.1.1:22120"}));
  EXPECT_EQ(1UL, cluster_->info()->configUpdateStats().update_failure_.value());

  // 2. Primary resolution fails, so replica resolution is not even called.
  // Expect cluster slot update to be successful, with just one healthy host, and failure counter to
  // be updated.
  expectRedisResolve(true);
  resolve_timer_->invokeCallback();
  expectResolveDiscovery(Network::DnsLookupFamily::V4Only, "primary.com",
                         primary_resolved_addresses,
                         Network::DnsResolver::ResolutionStatus::Failure);
  // NOTE: Intentionally commented out. Replica DNS resolution should even reach. It's here for
  // illustrative purposes.

  // expectResolveDiscovery(Network::DnsLookupFamily::V4Only, "replica.org",
  // replica_resolved_addresses);
  expectClusterSlotResponse(singleSlotPrimaryReplica("primary.com", "replica.org", 22120));
  // healthy hosts is same as before, but failure count increases by 1
  EXPECT_EQ(1UL, cluster_->prioritySet().hostSetsPerPriority()[0]->hosts().size());
  EXPECT_EQ(1UL, cluster_->prioritySet().hostSetsPerPriority()[0]->healthyHosts().size());
  EXPECT_EQ(2UL, cluster_->info()->configUpdateStats().update_failure_.value());
}

TEST_F(RedisClusterTest, AddressAsHostnamePrimaryEmptyDnsResponse) {
  setupFromV3Yaml(BasicConfig);
  const std::list<std::string> resolved_addresses{"127.0.0.1", "127.0.0.2"};
  const std::list<std::string> primary_resolved_addresses;
  const std::list<std::string> primary_empty_addresses{};
  const std::list<std::string> replica_resolved_addresses{};

  expectResolveDiscovery(Network::DnsLookupFamily::V4Only, "foo.bar.com", resolved_addresses);

  // 1. Primary and replica resolutions are successful.
  expectResolveDiscovery(Network::DnsLookupFamily::V4Only, "primary.com", {"127.0.1.1"});
  expectResolveDiscovery(Network::DnsLookupFamily::V4Only, "replica.org", {"127.0.1.2"});
  expectRedisResolve(true);

  EXPECT_CALL(membership_updated_, ready());
  EXPECT_CALL(initialized_, ready());
  cluster_->initialize([&]() {
    initialized_.ready();
    return absl::OkStatus();
  });

  EXPECT_CALL(*cluster_callback_, onClusterSlotUpdate(_, _));
  expectClusterSlotResponse(singleSlotPrimaryReplica("primary.com", "replica.org", 22120));
  // Primary and replica hosts are healthy.
  expectHealthyHosts(std::list<std::string>({"127.0.1.1:22120", "127.0.1.2:22120"}));

  // 2. Primary resolution has empty DNS response, so replica resolution is not called.
  expectRedisResolve(true);
  resolve_timer_->invokeCallback();
  expectResolveDiscovery(Network::DnsLookupFamily::V4Only, "primary.com", {});
  expectClusterSlotResponse(singleSlotPrimaryReplica("primary.com", "replica.org", 22121));
  expectHealthyHosts(std::list<std::string>({"127.0.1.1:22120", "127.0.1.2:22120"}));
  // Empty DNS response.
  EXPECT_EQ(1UL, cluster_->info()->configUpdateStats().update_empty_.value());
}

TEST_F(RedisClusterTest, AddressAsHostnameReplicaEmptyDnsResponse) {
  setupFromV3Yaml(BasicConfig);
  const std::list<std::string> resolved_addresses{"127.0.0.1", "127.0.0.2"};
  const std::list<std::string> primary_resolved_addresses{"127.0.1.1"};
  const std::list<std::string> replica_resolved_addresses{};
  expectResolveDiscovery(Network::DnsLookupFamily::V4Only, "foo.bar.com", resolved_addresses);
  expectResolveDiscovery(Network::DnsLookupFamily::V4Only, "replica.org",
                         replica_resolved_addresses);
  expectResolveDiscovery(Network::DnsLookupFamily::V4Only, "primary.com",
                         primary_resolved_addresses);
  expectRedisResolve(true);

  EXPECT_CALL(membership_updated_, ready());
  EXPECT_CALL(initialized_, ready());
  cluster_->initialize([&]() {
    initialized_.ready();
    return absl::OkStatus();
  });

  EXPECT_CALL(*cluster_callback_, onClusterSlotUpdate(_, _));
  expectClusterSlotResponse(singleSlotPrimaryReplica("primary.com", "replica.org", 22120));
  // Only the primary host is healthy.
  expectHealthyHosts(std::list<std::string>({"127.0.1.1:22120"}));
  // Empty DNS response.
  EXPECT_EQ(1U, cluster_->info()->configUpdateStats().update_empty_.value());
}

TEST_F(RedisClusterTest, AddressAsHostnamePartialReplicaEmptyDnsResponse) {
  setupFromV3Yaml(BasicConfig);
  const std::list<std::string> resolved_addresses{"127.0.0.1", "127.0.0.2"};
  const std::list<std::string> primary_resolved_addresses{"127.0.1.1"};
  const std::list<std::string> replica1_resolved_addresses{"127.0.1.2"};
  const std::list<std::string> replica2_resolved_addresses{};
  expectResolveDiscovery(Network::DnsLookupFamily::V4Only, "foo.bar.com", resolved_addresses);
  expectResolveDiscovery(Network::DnsLookupFamily::V4Only, "replica1.org",
                         replica1_resolved_addresses);
  expectResolveDiscovery(Network::DnsLookupFamily::V4Only, "replica2.org",
                         replica2_resolved_addresses);
  expectResolveDiscovery(Network::DnsLookupFamily::V4Only, "primary.com",
                         primary_resolved_addresses);
  expectRedisResolve(true);

  EXPECT_CALL(membership_updated_, ready());
  EXPECT_CALL(initialized_, ready());
  cluster_->initialize([&]() {
    initialized_.ready();
    return absl::OkStatus();
  });

  EXPECT_CALL(*cluster_callback_, onClusterSlotUpdate(_, _));
  expectClusterSlotResponse(
      singleSlotPrimaryWithTwoReplicas("primary.com", "replica1.org", "replica2.org", 22120));
  // Only the primary host and one replica are healthy.
  expectHealthyHosts(std::list<std::string>({"127.0.1.1:22120", "127.0.1.2:22120"}));
  // Empty DNS response.
  EXPECT_EQ(1U, cluster_->info()->configUpdateStats().update_empty_.value());
}

TEST_F(RedisClusterTest, DontWaitForDNSOnInit) {
  setupFromV3Yaml(NoWarmupConfig);
  const std::list<std::string> resolved_addresses{"127.0.0.1", "127.0.0.2"};

  expectResolveDiscovery(Network::DnsLookupFamily::V4Only, "foo.bar.com", resolved_addresses);
  expectRedisResolve(true);

  // We should see cluster is initialized, even though redis cluster slot request fails.
  EXPECT_CALL(initialized_, ready());
  cluster_->initialize([&]() {
    initialized_.ready();
    return absl::OkStatus();
  });

  expectClusterSlotFailure();
  EXPECT_EQ(1U, cluster_->info()->configUpdateStats().update_attempt_.value());
  EXPECT_EQ(1U, cluster_->info()->configUpdateStats().update_failure_.value());
}

TEST_F(RedisClusterTest, AddressAsHostnamePartialReplicaFailure) {
  setupFromV3Yaml(BasicConfig);
  const std::list<std::string> resolved_addresses{"127.0.0.1", "127.0.0.2"};
  const std::list<std::string> primary_resolved_addresses{"127.0.1.1"};

  expectResolveDiscovery(Network::DnsLookupFamily::V4Only, "foo.bar.com", resolved_addresses);

  // 1. Primary resolution is successful, and one of the replica is successful, but the other fails.
  // Expect cluster slot update to be successful, with two healthy hosts, and expect failure counter
  // to be updated.
  expectResolveDiscovery(Network::DnsLookupFamily::V4Only, "primary.com",
                         primary_resolved_addresses);
  expectResolveDiscovery(Network::DnsLookupFamily::V4Only, "failed-replica.org",
                         std::list<std::string>{"127.0.1.2"},
                         Network::DnsResolver::ResolutionStatus::Failure);
  expectResolveDiscovery(Network::DnsLookupFamily::V4Only, "success-replica.org",
                         std::list<std::string>{"127.0.1.3"});

  expectRedisResolve(true);

  EXPECT_CALL(membership_updated_, ready());
  EXPECT_CALL(initialized_, ready());
  cluster_->initialize([&]() {
    initialized_.ready();
    return absl::OkStatus();
  });

  EXPECT_CALL(*cluster_callback_, onClusterSlotUpdate(_, _));
  expectClusterSlotResponse(singleSlotPrimaryWithTwoReplicas("primary.com", "failed-replica.org",
                                                             "success-replica.org", 22120));
  EXPECT_EQ(2UL, cluster_->prioritySet().hostSetsPerPriority()[0]->hosts().size());
  expectHealthyHosts(std::list<std::string>({"127.0.1.1:22120", "127.0.1.3:22120"}));
}

TEST_F(RedisClusterTest, EmptyDnsResponse) {
  Event::MockTimer* dns_timer = new NiceMock<Event::MockTimer>(&server_context_.dispatcher_);
  setupFromV3Yaml(BasicConfig);
  const std::list<std::string> resolved_addresses{};
  EXPECT_CALL(*dns_timer, enableTimer(_, _));
  expectResolveDiscovery(Network::DnsLookupFamily::V4Only, "foo.bar.com", resolved_addresses);

  EXPECT_CALL(initialized_, ready());
  cluster_->initialize([&]() {
    initialized_.ready();
    return absl::OkStatus();
  });

  EXPECT_EQ(0UL, cluster_->prioritySet().hostSetsPerPriority()[0]->hosts().size());
  EXPECT_EQ(0UL, cluster_->prioritySet().hostSetsPerPriority()[0]->healthyHosts().size());
  EXPECT_EQ(1U, cluster_->info()->configUpdateStats().update_empty_.value());

  // Does not recreate the timer on subsequent DNS resolve calls.
  EXPECT_CALL(*dns_timer, enableTimer(_, _));
  expectResolveDiscovery(Network::DnsLookupFamily::V4Only, "foo.bar.com", resolved_addresses);
  dns_timer->invokeCallback();

  EXPECT_EQ(0UL, cluster_->prioritySet().hostSetsPerPriority()[0]->hosts().size());
  EXPECT_EQ(0UL, cluster_->prioritySet().hostSetsPerPriority()[0]->healthyHosts().size());
  EXPECT_EQ(2U, cluster_->info()->configUpdateStats().update_empty_.value());
}

TEST_F(RedisClusterTest, FailedDnsResponse) {
  Event::MockTimer* dns_timer = new NiceMock<Event::MockTimer>(&server_context_.dispatcher_);
  setupFromV3Yaml(BasicConfig);
  const std::list<std::string> resolved_addresses{};
  EXPECT_CALL(*dns_timer, enableTimer(_, _));
  expectResolveDiscovery(Network::DnsLookupFamily::V4Only, "foo.bar.com", resolved_addresses,
                         Network::DnsResolver::ResolutionStatus::Failure);

  EXPECT_CALL(initialized_, ready());
  cluster_->initialize([&]() {
    initialized_.ready();
    return absl::OkStatus();
  });

  EXPECT_EQ(0UL, cluster_->prioritySet().hostSetsPerPriority()[0]->hosts().size());
  EXPECT_EQ(0UL, cluster_->prioritySet().hostSetsPerPriority()[0]->healthyHosts().size());
  EXPECT_EQ(0U, cluster_->info()->configUpdateStats().update_empty_.value());

  // Does not recreate the timer on subsequent DNS resolve calls.
  EXPECT_CALL(*dns_timer, enableTimer(_, _));
  expectResolveDiscovery(Network::DnsLookupFamily::V4Only, "foo.bar.com", resolved_addresses);
  dns_timer->invokeCallback();

  EXPECT_EQ(0UL, cluster_->prioritySet().hostSetsPerPriority()[0]->hosts().size());
  EXPECT_EQ(0UL, cluster_->prioritySet().hostSetsPerPriority()[0]->healthyHosts().size());
  EXPECT_EQ(1U, cluster_->info()->configUpdateStats().update_empty_.value());
}

TEST_F(RedisClusterTest, Basic) {
  // Using load assignment.
  const std::string basic_yaml_load_assignment = R"EOF(
  name: name
  connect_timeout: 0.25s
  dns_lookup_family: V4_ONLY
  load_assignment:
    cluster_name: name
    endpoints:
      - lb_endpoints:
        - endpoint:
            address:
              socket_address:
                address: foo.bar.com
                port_value: 22120
            health_check_config:
              port_value: 8000
  cluster_type:
    name: envoy.clusters.redis
    typed_config:
      "@type": type.googleapis.com/google.protobuf.Struct
      value:
        cluster_refresh_rate: 4s
        cluster_refresh_timeout: 0.25s
  )EOF";

  testBasicSetup(BasicConfig, "foo.bar.com");
  testBasicSetup(basic_yaml_load_assignment, "foo.bar.com");

  // Exercise stubbed out interfaces for coverage.
  exerciseStubs();
}

TEST_F(RedisClusterTest, RedisResolveFailure) {
  setupFromV3Yaml(BasicConfig);
  const std::list<std::string> resolved_addresses{"127.0.0.1", "127.0.0.2"};
  expectResolveDiscovery(Network::DnsLookupFamily::V4Only, "foo.bar.com", resolved_addresses);
  expectRedisResolve(true);

  cluster_->initialize([&]() {
    initialized_.ready();
    return absl::OkStatus();
  });

  // Initialization will wait til the redis cluster succeed.
  expectClusterSlotFailure();
  EXPECT_EQ(1U, cluster_->info()->configUpdateStats().update_attempt_.value());
  EXPECT_EQ(1U, cluster_->info()->configUpdateStats().update_failure_.value());

  expectRedisResolve(true);
  resolve_timer_->invokeCallback();
  EXPECT_CALL(membership_updated_, ready());
  EXPECT_CALL(initialized_, ready());
  EXPECT_CALL(*cluster_callback_, onClusterSlotUpdate(_, _));
  expectClusterSlotResponse(singleSlotPrimaryReplica("127.0.0.1", "127.0.0.2", 22120));
  expectHealthyHosts(std::list<std::string>({"127.0.0.1:22120", "127.0.0.2:22120"}));

  // Expect no change if resolve failed.
  expectRedisResolve();
  resolve_timer_->invokeCallback();
  expectClusterSlotFailure();
  expectHealthyHosts(std::list<std::string>({"127.0.0.1:22120", "127.0.0.2:22120"}));
  EXPECT_EQ(3U, cluster_->info()->configUpdateStats().update_attempt_.value());
  EXPECT_EQ(2U, cluster_->info()->configUpdateStats().update_failure_.value());
}

TEST_F(RedisClusterTest, FactoryInitNotRedisClusterTypeFailure) {
  const std::string basic_yaml_hosts = R"EOF(
  name: name
  connect_timeout: 0.25s
  dns_lookup_family: V4_ONLY
  load_assignment:
        endpoints:
          - lb_endpoints:
            - endpoint:
                address:
                  socket_address:
                    address: foo.bar.com
                    port_value: 22120
  cluster_type:
    name: envoy.clusters.memcached
    typed_config:
      "@type": type.googleapis.com/google.protobuf.Struct
      value:
        cluster_refresh_rate: 4s
        cluster_refresh_timeout: 0.25s
  )EOF";

  auto status = setupFactoryFromV3Yaml(basic_yaml_hosts, true);
  ASSERT_THAT(status, HasStatusMessage("Redis cluster can only created with redis cluster type."));
}

TEST_F(RedisClusterTest, FactoryInitRedisClusterTypeSuccess) {
  ASSERT_OK(setupFactoryFromV3Yaml(BasicConfig));
}

TEST_F(RedisClusterTest, RedisErrorResponse) {
  setupFromV3Yaml(BasicConfig);
  const std::list<std::string> resolved_addresses{"127.0.0.1", "127.0.0.2"};
  expectResolveDiscovery(Network::DnsLookupFamily::V4Only, "foo.bar.com", resolved_addresses);
  expectRedisResolve(true);

  cluster_->initialize([&]() {
    initialized_.ready();
    return absl::OkStatus();
  });

  // Initialization will wait til the redis cluster succeed.
  std::vector<NetworkFilters::Common::Redis::RespValue> hello_world(2);
  hello_world[0].type(NetworkFilters::Common::Redis::RespType::BulkString);
  hello_world[0].asString() = "hello";
  hello_world[1].type(NetworkFilters::Common::Redis::RespType::BulkString);
  hello_world[1].asString() = "world";

  NetworkFilters::Common::Redis::RespValuePtr hello_world_response(
      new NetworkFilters::Common::Redis::RespValue());
  hello_world_response->type(NetworkFilters::Common::Redis::RespType::Array);
  hello_world_response->asArray().swap(hello_world);

  EXPECT_CALL(*cluster_callback_, onClusterSlotUpdate(_, _)).Times(0);
  expectClusterSlotResponse(std::move(hello_world_response));
  EXPECT_EQ(1U, cluster_->info()->configUpdateStats().update_attempt_.value());
  EXPECT_EQ(1U, cluster_->info()->configUpdateStats().update_failure_.value());

  expectRedisResolve();
  resolve_timer_->invokeCallback();
  EXPECT_CALL(membership_updated_, ready());
  EXPECT_CALL(initialized_, ready());
  EXPECT_CALL(*cluster_callback_, onClusterSlotUpdate(_, _));
  std::bitset<ResponseFlagSize> single_slot_primary(0xfff);
  std::bitset<ResponseReplicaFlagSize> no_replica(0);
  expectClusterSlotResponse(createResponse(single_slot_primary, no_replica));
  expectHealthyHosts(std::list<std::string>({"127.0.0.1:22120"}));

  // Expect no change if resolve failed.
  uint64_t update_attempt = 2;
  uint64_t update_failure = 1;
  // Test every combination the cluster slots response.
  for (uint64_t i = 0; i < (1 << ResponseFlagSize); i++) {
    std::bitset<ResponseFlagSize> flags(i);
    expectRedisResolve();
    resolve_timer_->invokeCallback();
    if (flags.all()) {
      EXPECT_CALL(*cluster_callback_, onClusterSlotUpdate(_, _)).WillOnce(Return(false));
    }
    expectClusterSlotResponse(createResponse(flags, no_replica));
    expectHealthyHosts(std::list<std::string>({"127.0.0.1:22120"}));
    EXPECT_EQ(++update_attempt, cluster_->info()->configUpdateStats().update_attempt_.value());
    if (!flags.all()) {
      EXPECT_EQ(++update_failure, cluster_->info()->configUpdateStats().update_failure_.value());
    }
  }
}

TEST_F(RedisClusterTest, RedisReplicaErrorResponse) {
  setupFromV3Yaml(BasicConfig);
  const std::list<std::string> resolved_addresses{"127.0.0.1", "127.0.0.2"};
  expectResolveDiscovery(Network::DnsLookupFamily::V4Only, "foo.bar.com", resolved_addresses);
  expectRedisResolve(true);

  cluster_->initialize([&]() {
    initialized_.ready();
    return absl::OkStatus();
  });

  EXPECT_CALL(membership_updated_, ready());
  EXPECT_CALL(initialized_, ready());
  EXPECT_CALL(*cluster_callback_, onClusterSlotUpdate(_, _));
  std::bitset<ResponseFlagSize> single_slot_primary(0xfff);
  std::bitset<ResponseReplicaFlagSize> no_replica(0);
  expectClusterSlotResponse(createResponse(single_slot_primary, no_replica));
  expectHealthyHosts(std::list<std::string>({"127.0.0.1:22120"}));

  // Expect no change if resolve failed.
  uint64_t update_attempt = 1;
  uint64_t update_failure = 0;
  // Test every combination the replica error response.
  for (uint64_t i = 1; i < (1 << ResponseReplicaFlagSize); i++) {
    std::bitset<ResponseReplicaFlagSize> replica_flags(i);
    expectRedisResolve();
    resolve_timer_->invokeCallback();
    if (replica_flags.all()) {
      EXPECT_CALL(membership_updated_, ready());
      EXPECT_CALL(*cluster_callback_, onClusterSlotUpdate(_, _)).WillOnce(Return(false));
    }
    expectHealthyHosts(std::list<std::string>({"127.0.0.1:22120"}));
    expectClusterSlotResponse(createResponse(single_slot_primary, replica_flags));
    EXPECT_EQ(++update_attempt, cluster_->info()->configUpdateStats().update_attempt_.value());
    if (!(replica_flags.all() || replica_flags.none())) {
      EXPECT_EQ(++update_failure, cluster_->info()->configUpdateStats().update_failure_.value());
    }
  }
}

// Verify that a CLUSTER SLOTS response with port > 0xffff triggers validation failure.
TEST_F(RedisClusterTest, RedisErrorResponsePortOverflow) {
  setupFromV3Yaml(BasicConfig);
  const std::list<std::string> resolved_addresses{"127.0.0.1", "127.0.0.2"};
  expectResolveDiscovery(Network::DnsLookupFamily::V4Only, "foo.bar.com", resolved_addresses);
  expectRedisResolve(true);

  EXPECT_CALL(membership_updated_, ready());
  EXPECT_CALL(initialized_, ready());
  cluster_->initialize([&]() {
    initialized_.ready();
    return absl::OkStatus();
  });

  // First, a valid response to initialize.
  EXPECT_CALL(*cluster_callback_, onClusterSlotUpdate(_, _));
  std::bitset<ResponseFlagSize> single_slot_primary(0xfff);
  std::bitset<ResponseReplicaFlagSize> no_replica(0);
  expectClusterSlotResponse(createResponse(single_slot_primary, no_replica));
  expectHealthyHosts(std::list<std::string>({"127.0.0.1:22120"}));

  // Now send a response with port > 0xffff (65535). This should fail validation.
  expectRedisResolve();
  resolve_timer_->invokeCallback();
  EXPECT_CALL(*cluster_callback_, onClusterSlotUpdate(_, _)).Times(0);
  expectClusterSlotResponse(singleSlotPrimary("127.0.0.1", 70000));
  EXPECT_EQ(2U, cluster_->info()->configUpdateStats().update_attempt_.value());
  EXPECT_EQ(1U, cluster_->info()->configUpdateStats().update_failure_.value());
}

TEST_F(RedisClusterTest, DnsDiscoveryResolverBasic) {
  setupFromV3Yaml(BasicConfig);
  testDnsResolve("foo.bar.com", 22120);
}

TEST_F(RedisClusterTest, MultipleDnsDiscovery) {
  const std::string config = R"EOF(
  name: name
  connect_timeout: 0.25s
  dns_lookup_family: V4_ONLY
  load_assignment:
        endpoints:
          - lb_endpoints:
            - endpoint:
                address:
                  socket_address:
                    address: foo.bar.com
                    port_value: 22120
            - endpoint:
                address:
                  socket_address:
                    address: foo1.bar.com
                    port_value: 22120
  cluster_type:
    name: envoy.clusters.redis
    typed_config:
      "@type": type.googleapis.com/google.protobuf.Struct
      value:
        cluster_refresh_rate: 4s
        cluster_refresh_timeout: 0.25s
  )EOF";

  setupFromV3Yaml(config);

  // Only single in-flight "cluster slots" call.
  expectRedisResolve(true);

  ReadyWatcher dns_resolve_1;
  ReadyWatcher dns_resolve_2;

  EXPECT_CALL(*dns_resolver_, resolve("foo.bar.com", _, _))
      .WillOnce(Invoke([&](const std::string&, Network::DnsLookupFamily,
                           Network::DnsResolver::ResolveCb cb) -> Network::ActiveDnsQuery* {
        cb(Network::DnsResolver::ResolutionStatus::Completed, "",
           TestUtility::makeDnsResponse(std::list<std::string>({"127.0.0.1", "127.0.0.2"})));
        return nullptr;
      }));

  EXPECT_CALL(*dns_resolver_, resolve("foo1.bar.com", _, _))
      .WillOnce(Invoke([&](const std::string&, Network::DnsLookupFamily,
                           Network::DnsResolver::ResolveCb cb) -> Network::ActiveDnsQuery* {
        cb(Network::DnsResolver::ResolutionStatus::Completed, "",
           TestUtility::makeDnsResponse(std::list<std::string>({"127.0.0.3", "127.0.0.4"})));
        return nullptr;
      }));

  cluster_->initialize([&]() {
    initialized_.ready();
    return absl::OkStatus();
  });

  // Pending RedisResolve will call cancel in the destructor.
  EXPECT_CALL(pool_request_, cancel());
}

TEST_F(RedisClusterTest, HostRemovalAfterHcFail) {
  setupFromV3Yaml(BasicConfig);
  auto health_checker = std::make_shared<Upstream::MockHealthChecker>();
  EXPECT_CALL(*health_checker, start());
  EXPECT_CALL(*health_checker, addHostCheckCompleteCb(_)).Times(2);
  cluster_->setHealthChecker(health_checker);

  const std::list<std::string> resolved_addresses{"127.0.0.1", "127.0.0.2"};
  expectResolveDiscovery(Network::DnsLookupFamily::V4Only, "foo.bar.com", resolved_addresses);
  expectRedisResolve(true);

  EXPECT_CALL(membership_updated_, ready());
  EXPECT_CALL(initialized_, ready());
  cluster_->initialize([&]() {
    initialized_.ready();
    return absl::OkStatus();
  });

  EXPECT_CALL(*cluster_callback_, onClusterSlotUpdate(_, _));
  expectClusterSlotResponse(twoSlotsPrimariesWithReplica());

  // Verify that all hosts are initially marked with FAILED_ACTIVE_HC, then
  // clear the flag to simulate that these hosts have been successfully health
  // checked.
  {
    EXPECT_CALL(membership_updated_, ready());
    const auto& hosts = cluster_->prioritySet().hostSetsPerPriority()[0]->hosts();
    EXPECT_EQ(4UL, hosts.size());

    for (size_t i = 0; i < 4; ++i) {
      EXPECT_TRUE(hosts[i]->healthFlagGet(Upstream::Host::HealthFlag::FAILED_ACTIVE_HC));
      hosts[i]->healthFlagClear(Upstream::Host::HealthFlag::FAILED_ACTIVE_HC);
      hosts[i]->healthFlagClear(Upstream::Host::HealthFlag::PENDING_ACTIVE_HC);
      health_checker->runCallbacks(hosts[i], Upstream::HealthTransition::Changed,
                                   Upstream::HealthState::Healthy);
    }
    expectHealthyHosts(std::list<std::string>(
        {"127.0.0.1:22120", "127.0.0.3:22120", "127.0.0.2:22120", "127.0.0.4:22120"}));
  }

  // Fail a HC for one of the hosts
  {
    EXPECT_CALL(membership_updated_, ready());
    EXPECT_CALL(*cluster_callback_, onHostHealthUpdate());
    const auto& hosts = cluster_->prioritySet().hostSetsPerPriority()[0]->hosts();
    hosts[2]->healthFlagSet(Upstream::Host::HealthFlag::FAILED_ACTIVE_HC);
    health_checker->runCallbacks(hosts[2], Upstream::HealthTransition::Changed,
                                 Upstream::HealthState::Unhealthy);

    EXPECT_THAT(cluster_->prioritySet().hostSetsPerPriority()[0]->hosts().size(), 4U);
    EXPECT_THAT(cluster_->prioritySet().hostSetsPerPriority()[0]->healthyHosts().size(), 3U);
  }

  // Remove 2nd shard.
  {
    expectRedisResolve();
    EXPECT_CALL(membership_updated_, ready());
    resolve_timer_->invokeCallback();
    EXPECT_CALL(*cluster_callback_, onClusterSlotUpdate(_, _));
    expectClusterSlotResponse(singleSlotPrimaryReplica("127.0.0.1", "127.0.0.3", 22120));

    const auto& hosts = cluster_->prioritySet().hostSetsPerPriority()[0]->hosts();

    // We expect the host that failed health checks to be instantly removed,
    // but the other should remain until its health check fails too.
    EXPECT_THAT(cluster_->prioritySet().hostSetsPerPriority()[0]->hosts().size(), 3U);
    expectHealthyHosts(
        std::list<std::string>({"127.0.0.1:22120", "127.0.0.3:22120", "127.0.0.4:22120"}));
    EXPECT_TRUE(hosts[2]->healthFlagGet(Upstream::Host::HealthFlag::PENDING_DYNAMIC_REMOVAL));
  }

  /*
  // TODO(#14630) This part of the test doesn't pass, as removal of PENDING_DYNAMIC_REMOVAL hosts
  // does not seem to be implemented for redis clusters at present.

  // Fail the HC for the remaining removed host
  {
    EXPECT_CALL(membership_updated_, ready());
    EXPECT_CALL(*cluster_callback_, onHostHealthUpdate());
    const auto& hosts = cluster_->prioritySet().hostSetsPerPriority()[0]->hosts();
    EXPECT_TRUE(hosts[2]->healthFlagGet(Upstream::Host::HealthFlag::PENDING_DYNAMIC_REMOVAL));
    hosts[2]->healthFlagSet(Upstream::Host::HealthFlag::FAILED_ACTIVE_HC);
    health_checker->runCallbacks(hosts[2], Upstream::HealthTransition::Changed);

    // The pending removal host should also have been removed now
    EXPECT_THAT(cluster_->prioritySet().hostSetsPerPriority()[0]->hosts().size(), 2U);
    expectHealthyHosts(std::list<std::string>(
      {"127.0.0.1:22120", "127.0.0.3:22120"}));
  }
  */
}

// Test that verifies cluster destruction does not cause segfault when refresh manager
// triggers callback after cluster is destroyed. This reproduces the issue from #38585.
TEST_F(RedisClusterTest, NoSegfaultOnClusterDestructionWithPendingCallback) {
  // This test verifies that destroying the cluster properly cleans up resources
  // and doesn't cause a segfault. The key protection is the destructor shutting
  // down the discovery session before dropping it.

  // Create the cluster with basic configuration
  setupFromV3Yaml(BasicConfig);
  const std::list<std::string> resolved_addresses{"127.0.0.1"};
  expectResolveDiscovery(Network::DnsLookupFamily::V4Only, "foo.bar.com", resolved_addresses);
  expectRedisResolve(true);

  cluster_->initialize([&]() {
    initialized_.ready();
    return absl::OkStatus();
  });

  EXPECT_CALL(membership_updated_, ready());
  EXPECT_CALL(initialized_, ready());
  EXPECT_CALL(*cluster_callback_, onClusterSlotUpdate(_, _));
  std::bitset<ResponseFlagSize> single_slot_primary(0xfff);
  std::bitset<ResponseReplicaFlagSize> no_replica(0);
  expectClusterSlotResponse(createResponse(single_slot_primary, no_replica));
  expectHealthyHosts(std::list<std::string>({"127.0.0.1:22120"}));

  // Now destroy the cluster. With the fix in place (the destructor shutting down and
  // resetting redis_discovery_session_), this should not crash.
  // Without the fix, accessing resolve_timer_ after destruction would segfault.
  cluster_.reset();

  // If we reach here without crashing, the test passes.
}

// Discovery clients keep the discovery session alive past ~RedisCluster(): the production
// ClientImpl stores the session as its client Config (a shared_ptr) until the client's
// deferred deletion runs. Destroying the cluster while a discovery connection is open must
// close that connection and leave the surviving session inert. Before the explicit shutdown()
// teardown, the session leaked together with its clients and its still-armed resolve timer
// dereferenced the destroyed cluster on the next fire (use-after-free).
TEST_F(RedisClusterTest, DestructionWithHeldSessionClosesClientsAndDisarmsTimer) {
  hold_client_configs_ = true;
  setupFromV3Yaml(BasicConfig);
  const std::list<std::string> resolved_addresses{"127.0.0.1"};
  expectResolveDiscovery(Network::DnsLookupFamily::V4Only, "foo.bar.com", resolved_addresses);
  expectRedisResolve(true);

  EXPECT_CALL(membership_updated_, ready());
  EXPECT_CALL(initialized_, ready());
  cluster_->initialize([&]() {
    initialized_.ready();
    return absl::OkStatus();
  });

  EXPECT_CALL(*cluster_callback_, onClusterSlotUpdate(_, _));
  expectClusterSlotResponse(singleSlotPrimary("127.0.0.1", 22120));

  // Destroying the cluster closes the discovery connection (the close() expectation set by
  // expectRedisResolve) even though the held config reference keeps the session itself alive.
  cluster_.reset();

  // The surviving session must ignore a late timer fire instead of dereferencing the
  // destroyed cluster.
  EXPECT_CALL(*resolve_timer_, enableTimer(_, _));
  resolve_timer_->enableTimer(std::chrono::milliseconds(0), nullptr);
  resolve_timer_->invokeCallback();
}

// A CLUSTER SLOTS response can contain hostnames instead of IP addresses (e.g. AWS
// ElastiCache) whose DNS resolution is still in flight when the cluster is destroyed. The
// resolution must be cancelled at teardown; before the resolve() handles were tracked, the
// pending callback fired into the destroyed session (use-after-free).
TEST_F(RedisClusterTest, DestructionCancelsInFlightHostnameResolution) {
  hold_client_configs_ = true;
  setupFromV3Yaml(BasicConfig);
  const std::list<std::string> resolved_addresses{"127.0.0.1"};
  expectResolveDiscovery(Network::DnsLookupFamily::V4Only, "foo.bar.com", resolved_addresses);
  expectRedisResolve(true);

  cluster_->initialize([&]() {
    initialized_.ready();
    return absl::OkStatus();
  });

  // Deliver a CLUSTER SLOTS response whose primary is a hostname and leave its DNS
  // resolution in flight.
  Network::DnsResolver::ResolveCb hostname_resolve_cb;
  EXPECT_CALL(*dns_resolver_, resolve("primary.com", Network::DnsLookupFamily::V4Only, _))
      .WillOnce(DoAll(SaveArg<2>(&hostname_resolve_cb), Return(&active_dns_query_)));
  pool_callbacks_->onResponse(singleSlotPrimary("primary.com", 22120));

  // Destroying the cluster must cancel the outstanding query.
  EXPECT_CALL(active_dns_query_, cancel(Network::ActiveDnsQuery::CancelReason::QueryAbandoned));
  cluster_.reset();

  // The session survives via the held client config reference. A resolution that still
  // completes despite the cancellation request must be ignored by the shutdown guard instead
  // of dereferencing the destroyed cluster.
  hostname_resolve_cb(Network::DnsResolver::ResolutionStatus::Completed, "",
                      TestUtility::makeDnsResponse(resolved_addresses));
}

// Destroying the cluster while zone-discovery INFO requests are in flight must cancel them.
// Without the cancellation, closing the discovery clients fails the pending requests and
// re-enters finishZoneDiscovery() against a cluster that is mid-destruction.
TEST_F(RedisClusterTest, DestructionCancelsInFlightZoneDiscovery) {
  setupFromV3Yaml(ZoneDiscoveryConfig);
  const std::list<std::string> resolved_addresses{"127.0.0.1", "127.0.0.2"};
  expectResolveDiscovery(Network::DnsLookupFamily::V4Only, "foo.bar.com", resolved_addresses);
  expectRedisResolve(true);

  cluster_->initialize([&]() {
    initialized_.ready();
    return absl::OkStatus();
  });

  auto* zone_client = new Extensions::NetworkFilters::Common::Redis::Client::MockClient();
  EXPECT_CALL(*this, create_(_)).WillOnce(Return(zone_client));
  EXPECT_CALL(*zone_client, addConnectionCallbacks(_));
  EXPECT_CALL(*zone_client, close());
  Extensions::NetworkFilters::Common::Redis::Client::MockPoolRequest primary_info_request;
  Extensions::NetworkFilters::Common::Redis::Client::MockPoolRequest replica_info_request;
  EXPECT_CALL(*client_, makeRequest_(Ref(RedisCluster::InfoRequest::instance_), _))
      .WillOnce(Return(&primary_info_request));
  EXPECT_CALL(*zone_client, makeRequest_(Ref(RedisCluster::InfoRequest::instance_), _))
      .WillOnce(Return(&replica_info_request));

  pool_callbacks_->onResponse(singleSlotPrimaryReplica("127.0.0.1", "127.0.0.2", 22120));

  // Two INFO requests are outstanding. Destroying the cluster cancels each of them; zone
  // discovery must not complete (no further slot update, no timer re-arm).
  EXPECT_CALL(primary_info_request, cancel());
  EXPECT_CALL(replica_info_request, cancel());
  cluster_.reset();
}

// Tests for parseAvailabilityZone static method
TEST_F(RedisClusterTest, ParseAvailabilityZoneValidResponse) {
  EXPECT_EQ("us-east-1a",
            RedisCluster::parseAvailabilityZone(
                "# Server\nvalkey_version:8.0.0\navailability_zone:us-east-1a\nother:data\n"));
}

TEST_F(RedisClusterTest, ParseAvailabilityZoneNoZoneField) {
  EXPECT_EQ("", RedisCluster::parseAvailabilityZone("redis_version:7.0.0\nother:field\n"));
}

TEST_F(RedisClusterTest, ParseAvailabilityZoneAtEndOfResponse) {
  EXPECT_EQ("eu-west-1b", RedisCluster::parseAvailabilityZone(
                              "redis_version:7.0.0\navailability_zone:eu-west-1b"));
}

TEST_F(RedisClusterTest, ParseAvailabilityZoneEmptyValue) {
  EXPECT_EQ("", RedisCluster::parseAvailabilityZone(
                    "redis_version:7.0.0\navailability_zone:\nother:data\n"));
}

TEST_F(RedisClusterTest, ParseAvailabilityZoneWithCarriageReturn) {
  EXPECT_EQ("ap-northeast-1c", RedisCluster::parseAvailabilityZone(
                                   "# Server\r\navailability_zone:ap-northeast-1c\r\nother:data"));
}

TEST_F(RedisClusterTest, ParseAvailabilityZoneEmptyResponse) {
  EXPECT_EQ("", RedisCluster::parseAvailabilityZone(""));
}

// Zone discovery integration tests

TEST_F(RedisClusterTest, ZoneDiscoveryBasicFlow) {
  auto* zone_client = setupZoneDiscoveryWithTwoNodes();

  // Deliver INFO responses via captured callbacks.
  // client_ callbacks: [0]=CLUSTER SLOTS session, [1]=INFO zone discovery callback.
  NetworkFilters::Common::Redis::RespValuePtr info_resp_1(
      new NetworkFilters::Common::Redis::RespValue());
  info_resp_1->type(NetworkFilters::Common::Redis::RespType::BulkString);
  info_resp_1->asString() = "# Server\navailability_zone:us-east-1a\n";
  auto zone_cb_1 = std::next(client_->client_callbacks_.begin());
  (*zone_cb_1)->onResponse(std::move(info_resp_1));

  // zone_client callbacks: [0]=INFO zone discovery callback.
  NetworkFilters::Common::Redis::RespValuePtr info_resp_2(
      new NetworkFilters::Common::Redis::RespValue());
  info_resp_2->type(NetworkFilters::Common::Redis::RespType::BulkString);
  info_resp_2->asString() = "# Server\navailability_zone:us-east-1b\n";
  zone_client->client_callbacks_.front()->onResponse(std::move(info_resp_2));

  // Verify hosts exist with correct zones.
  EXPECT_EQ(2UL, cluster_->prioritySet().hostSetsPerPriority()[0]->hosts().size());
  EXPECT_EQ(2UL, cluster_->prioritySet().hostSetsPerPriority()[0]->healthyHosts().size());
  for (const auto& host : cluster_->prioritySet().hostSetsPerPriority()[0]->hosts()) {
    if (host->address()->asString() == "127.0.0.1:22120") {
      EXPECT_EQ("us-east-1a", host->locality().zone());
    } else {
      EXPECT_EQ("us-east-1b", host->locality().zone());
    }
  }
}

TEST_F(RedisClusterTest, ZoneDiscoveryPartialZones) {
  auto* zone_client = setupZoneDiscoveryWithTwoNodes();

  // First node returns zone.
  NetworkFilters::Common::Redis::RespValuePtr info_resp_1(
      new NetworkFilters::Common::Redis::RespValue());
  info_resp_1->type(NetworkFilters::Common::Redis::RespType::BulkString);
  info_resp_1->asString() = "# Server\navailability_zone:us-east-1a\n";
  auto zone_cb_1 = std::next(client_->client_callbacks_.begin());
  (*zone_cb_1)->onResponse(std::move(info_resp_1));

  // Second node returns INFO without availability_zone field.
  NetworkFilters::Common::Redis::RespValuePtr info_resp_2(
      new NetworkFilters::Common::Redis::RespValue());
  info_resp_2->type(NetworkFilters::Common::Redis::RespType::BulkString);
  info_resp_2->asString() = "redis_version:7.0.0\nother:field\n";
  zone_client->client_callbacks_.front()->onResponse(std::move(info_resp_2));

  EXPECT_EQ(2UL, cluster_->prioritySet().hostSetsPerPriority()[0]->hosts().size());
  for (const auto& host : cluster_->prioritySet().hostSetsPerPriority()[0]->hosts()) {
    if (host->address()->asString() == "127.0.0.1:22120") {
      EXPECT_EQ("us-east-1a", host->locality().zone());
    } else {
      EXPECT_TRUE(host->locality().zone().empty());
    }
  }
}

TEST_F(RedisClusterTest, ZoneDiscoveryResponseTypeMismatch) {
  auto* zone_client = setupZoneDiscoveryWithTwoNodes();

  // First node returns valid zone.
  NetworkFilters::Common::Redis::RespValuePtr info_resp_1(
      new NetworkFilters::Common::Redis::RespValue());
  info_resp_1->type(NetworkFilters::Common::Redis::RespType::BulkString);
  info_resp_1->asString() = "# Server\navailability_zone:us-east-1a\n";
  auto zone_cb_1 = std::next(client_->client_callbacks_.begin());
  (*zone_cb_1)->onResponse(std::move(info_resp_1));

  // Second node returns Error type instead of BulkString.
  NetworkFilters::Common::Redis::RespValuePtr info_resp_2(
      new NetworkFilters::Common::Redis::RespValue());
  info_resp_2->type(NetworkFilters::Common::Redis::RespType::Error);
  info_resp_2->asString() = "ERR unknown command";
  zone_client->client_callbacks_.front()->onResponse(std::move(info_resp_2));

  EXPECT_EQ(2UL, cluster_->prioritySet().hostSetsPerPriority()[0]->hosts().size());
  for (const auto& host : cluster_->prioritySet().hostSetsPerPriority()[0]->hosts()) {
    if (host->address()->asString() == "127.0.0.1:22120") {
      EXPECT_EQ("us-east-1a", host->locality().zone());
    } else {
      EXPECT_TRUE(host->locality().zone().empty());
    }
  }
}

TEST_F(RedisClusterTest, ZoneDiscoveryAllFailure) {
  auto* zone_client = setupZoneDiscoveryWithTwoNodes();

  // Both INFO requests fail.
  auto zone_cb_1 = std::next(client_->client_callbacks_.begin());
  (*zone_cb_1)->onFailure();
  zone_client->client_callbacks_.front()->onFailure();

  // Hosts should exist without zones.
  EXPECT_EQ(2UL, cluster_->prioritySet().hostSetsPerPriority()[0]->hosts().size());
  for (const auto& host : cluster_->prioritySet().hostSetsPerPriority()[0]->hosts()) {
    EXPECT_TRUE(host->locality().zone().empty());
  }
}

TEST_F(RedisClusterTest, ZoneDiscoveryMixedSuccessAndFailure) {
  auto* zone_client = setupZoneDiscoveryWithTwoNodes();

  // First node succeeds with zone.
  NetworkFilters::Common::Redis::RespValuePtr info_resp(
      new NetworkFilters::Common::Redis::RespValue());
  info_resp->type(NetworkFilters::Common::Redis::RespType::BulkString);
  info_resp->asString() = "# Server\navailability_zone:us-east-1a\n";
  auto zone_cb_1 = std::next(client_->client_callbacks_.begin());
  (*zone_cb_1)->onResponse(std::move(info_resp));

  // Second node fails.
  zone_client->client_callbacks_.front()->onFailure();

  EXPECT_EQ(2UL, cluster_->prioritySet().hostSetsPerPriority()[0]->hosts().size());
  for (const auto& host : cluster_->prioritySet().hostSetsPerPriority()[0]->hosts()) {
    if (host->address()->asString() == "127.0.0.1:22120") {
      EXPECT_EQ("us-east-1a", host->locality().zone());
    } else {
      EXPECT_TRUE(host->locality().zone().empty());
    }
  }
}

TEST_F(RedisClusterTest, ZoneDiscoveryMakeRequestReturnsNull) {
  setupFromV3Yaml(ZoneDiscoveryConfig);
  const std::list<std::string> resolved_addresses{"127.0.0.1", "127.0.0.2"};
  expectResolveDiscovery(Network::DnsLookupFamily::V4Only, "foo.bar.com", resolved_addresses);
  expectRedisResolve(true);

  EXPECT_CALL(membership_updated_, ready());
  EXPECT_CALL(initialized_, ready());
  cluster_->initialize([&]() {
    initialized_.ready();
    return absl::OkStatus();
  });

  // makeRequest returns null for the single node's INFO command.
  EXPECT_CALL(*client_, makeRequest_(Ref(RedisCluster::InfoRequest::instance_), _))
      .WillOnce(Return(nullptr));
  EXPECT_CALL(*cluster_callback_, onClusterSlotUpdate(_, _));
  EXPECT_CALL(*resolve_timer_, enableTimer(_, _));

  // Deliver single-primary CLUSTER SLOTS response.
  pool_callbacks_->onResponse(singleSlotPrimary("127.0.0.1", 22120));

  // finishZoneDiscovery was called immediately since the only request failed.
  EXPECT_EQ(1UL, cluster_->prioritySet().hostSetsPerPriority()[0]->hosts().size());
  EXPECT_TRUE(
      cluster_->prioritySet().hostSetsPerPriority()[0]->hosts()[0]->locality().zone().empty());
}

// A refresh (periodic resolve timer, DNS update) that arrives after CLUSTER
// SLOTS completes but before the zone-discovery INFO replies return must not
// start a second resolution. current_request_ is already null in that window,
// so without gating on pending_zone_requests_ the refresh starts another zone
// discovery and overwrites zone_callbacks_, freeing the callbacks that the
// in-flight INFO requests still reference (use-after-free).
TEST_F(RedisClusterTest, ZoneDiscoveryRefreshWhileInfoInFlightIsSkipped) {
  auto* zone_client = setupZoneDiscoveryWithTwoNodes();

  // Zone discovery is in flight (two INFO requests outstanding). A refresh in
  // this window must not issue another CLUSTER SLOTS request.
  EXPECT_CALL(*client_, makeRequest_(Ref(RedisCluster::ClusterSlotsRequest::instance_), _))
      .Times(0);
  EXPECT_CALL(*zone_client, makeRequest_(Ref(RedisCluster::ClusterSlotsRequest::instance_), _))
      .Times(0);
  // The session resolve timer is one-shot and stays disabled while the INFO
  // requests are outstanding. A refresh reaches this window only because the
  // refresh manager re-arms the timer to fire immediately (see registerCluster
  // in the RedisCluster constructor, which calls enableTimer(0ms)). Reproduce
  // that here: re-arm the timer, then fire it. This consumes the pending
  // enableTimer expectation set up by setupZoneDiscoveryWithTwoNodes.
  resolve_timer_->enableTimer(std::chrono::milliseconds(0), nullptr);
  resolve_timer_->invokeCallback();

  // Completing zone discovery re-arms the resolve timer again.
  EXPECT_CALL(*resolve_timer_, enableTimer(_, _));

  // The original in-flight INFO callbacks are still valid and complete normally.
  NetworkFilters::Common::Redis::RespValuePtr info_resp_1(
      new NetworkFilters::Common::Redis::RespValue());
  info_resp_1->type(NetworkFilters::Common::Redis::RespType::BulkString);
  info_resp_1->asString() = "# Server\navailability_zone:us-east-1a\n";
  auto zone_cb_1 = std::next(client_->client_callbacks_.begin());
  (*zone_cb_1)->onResponse(std::move(info_resp_1));

  NetworkFilters::Common::Redis::RespValuePtr info_resp_2(
      new NetworkFilters::Common::Redis::RespValue());
  info_resp_2->type(NetworkFilters::Common::Redis::RespType::BulkString);
  info_resp_2->asString() = "# Server\navailability_zone:us-east-1b\n";
  zone_client->client_callbacks_.front()->onResponse(std::move(info_resp_2));

  EXPECT_EQ(2UL, cluster_->prioritySet().hostSetsPerPriority()[0]->hosts().size());
  for (const auto& host : cluster_->prioritySet().hostSetsPerPriority()[0]->hosts()) {
    if (host->address()->asString() == "127.0.0.1:22120") {
      EXPECT_EQ("us-east-1a", host->locality().zone());
    } else {
      EXPECT_EQ("us-east-1b", host->locality().zone());
    }
  }
}

} // namespace Redis
} // namespace Clusters
} // namespace Extensions
} // namespace Envoy
