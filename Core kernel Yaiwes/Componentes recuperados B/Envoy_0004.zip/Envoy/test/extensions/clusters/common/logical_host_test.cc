#include "source/common/network/transport_socket_options_impl.h"
#include "source/common/network/utility.h"
#include "source/common/router/string_accessor_impl.h"
#include "source/common/stream_info/filter_state_impl.h"
#include "source/extensions/clusters/common/logical_host.h"

#include "test/mocks/event/mocks.h"
#include "test/mocks/network/mocks.h"
#include "test/mocks/network/transport_socket.h"
#include "test/mocks/upstream/cluster_info.h"
#include "test/mocks/upstream/host.h"
#include "test/mocks/upstream/transport_socket_match.h"
#include "test/test_common/status_utility.h"

#include "gmock/gmock.h"
#include "gtest/gtest.h"

using testing::_;
using testing::AnyNumber;
using testing::NiceMock;
using testing::Return;
using testing::ReturnRef;
using testing::StrictMock;

namespace Envoy {
namespace Extensions {
namespace Clusters {

class RealHostDescriptionTest : public testing::Test {
public:
  Network::Address::InstanceConstSharedPtr address_ = nullptr;
  Upstream::MockHost* mock_host_{new NiceMock<Upstream::MockHost>()};
  Upstream::HostConstSharedPtr host_{mock_host_};
  Upstream::RealHostDescription description_{address_, host_};
};

TEST_F(RealHostDescriptionTest, UnitTest) {
  // No-op unit tests.
  description_.canary();
  description_.metadata();
  description_.priority();
  EXPECT_EQ(nullptr, description_.healthCheckAddress());
  EXPECT_EQ(nullptr, description_.orcaReportingAddress());

  // Pass through functions.
  EXPECT_CALL(*mock_host_, transportSocketFactory());
  description_.transportSocketFactory();

  EXPECT_CALL(*mock_host_, canCreateConnection(_));
  description_.canCreateConnection(Upstream::ResourcePriority::Default);

  EXPECT_CALL(*mock_host_, loadMetricStats());
  description_.loadMetricStats();

  EXPECT_CALL(*mock_host_, addressListOrNull())
      .WillOnce(Return(std::make_shared<Upstream::HostDescription::AddressVector>()));
  description_.addressListOrNull();

  const envoy::config::core::v3::Metadata metadata;
  Network::MockTransportSocketFactory socket_factory;
  EXPECT_CALL(*mock_host_, resolveTransportSocketFactory(_, _, _))
      .WillOnce(ReturnRef(socket_factory));
  description_.resolveTransportSocketFactory(address_, &metadata, nullptr);

  EXPECT_CALL(*mock_host_, lbPolicyDataCount());
  description_.lbPolicyDataCount();

  EXPECT_CALL(*mock_host_, lbPolicyDataAt(0));
  description_.lbPolicyDataAt(0);

  description_.canary(false);
  description_.priority(0);
  description_.metadata(nullptr);
  description_.setLastHcPassTime(MonotonicTime());
  description_.addLbPolicyData(nullptr);

  Upstream::HealthCheckHostMonitorPtr heath_check_monitor;
  description_.setHealthChecker(std::move(heath_check_monitor));

  Upstream::Outlier::DetectorHostMonitorPtr detector_host;
  description_.setOutlierDetector(std::move(detector_host));
}

// Verifies that the happy eyeballs sorted address list is computed at construction and
// recomputed by setNewAddresses, while addressListOrNull() keeps the original order.
TEST(LogicalHostSortedAddressListTest, SortedListFollowsAddressUpdates) {
  auto cluster_info = std::make_shared<NiceMock<Upstream::MockClusterInfo>>();
  const Network::Address::InstanceConstSharedPtr v4_1 =
      *Network::Utility::resolveUrl("tcp://10.0.0.1:1234");
  const Network::Address::InstanceConstSharedPtr v4_2 =
      *Network::Utility::resolveUrl("tcp://10.0.0.2:1234");
  const Network::Address::InstanceConstSharedPtr v6_1 =
      *Network::Utility::resolveUrl("tcp://[1::1]:1234");

  auto host_or_error = Upstream::LogicalHost::create(
      cluster_info, /*hostname=*/"", v4_1, /*address_list=*/{v4_1, v4_2, v6_1},
      envoy::config::endpoint::v3::LocalityLbEndpoints(), envoy::config::endpoint::v3::LbEndpoint(),
      /*override_transport_socket_options=*/nullptr);
  ASSERT_TRUE(host_or_error.ok());
  auto host = std::shared_ptr<Upstream::LogicalHost>(std::move(*host_or_error));

  // The raw list keeps the original order while the sorted list interleaves address families.
  ASSERT_NE(host->addressListOrNull(), nullptr);
  EXPECT_EQ(*host->addressListOrNull(),
            (Upstream::HostDescription::AddressVector{v4_1, v4_2, v6_1}));
  ASSERT_NE(host->sortedAddressListOrNull(), nullptr);
  EXPECT_EQ(*host->sortedAddressListOrNull(),
            (Upstream::HostDescription::AddressVector{v4_1, v6_1, v4_2}));

  // setNewAddresses recomputes both lists.
  const Network::Address::InstanceConstSharedPtr v6_2 =
      *Network::Utility::resolveUrl("tcp://[1::2]:1234");
  const Network::Address::InstanceConstSharedPtr v6_3 =
      *Network::Utility::resolveUrl("tcp://[1::3]:1234");
  const Network::Address::InstanceConstSharedPtr v4_3 =
      *Network::Utility::resolveUrl("tcp://10.0.0.3:1234");
  host->setNewAddresses(v6_2, {v6_2, v6_3, v4_3}, envoy::config::endpoint::v3::LbEndpoint());
  ASSERT_NE(host->addressListOrNull(), nullptr);
  EXPECT_EQ(*host->addressListOrNull(),
            (Upstream::HostDescription::AddressVector{v6_2, v6_3, v4_3}));
  ASSERT_NE(host->sortedAddressListOrNull(), nullptr);
  EXPECT_EQ(*host->sortedAddressListOrNull(),
            (Upstream::HostDescription::AddressVector{v6_2, v4_3, v6_3}));

  // An update without an address list clears both lists.
  host->setNewAddresses(v4_1, {}, envoy::config::endpoint::v3::LbEndpoint());
  EXPECT_EQ(host->addressListOrNull(), nullptr);
  EXPECT_EQ(host->sortedAddressListOrNull(), nullptr);
}

// Test fixture for LogicalHost per-connection transport socket resolution.
class LogicalHostTransportSocketResolutionTest : public testing::Test {
public:
  void SetUp() override {
    cluster_info_ = std::make_shared<NiceMock<Upstream::MockClusterInfo>>();
    transport_socket_matcher_ = dynamic_cast<Upstream::MockTransportSocketMatcher*>(
        cluster_info_->transport_socket_matcher_.get());
    ASSERT_NE(transport_socket_matcher_, nullptr);
  }

  Network::TransportSocketOptionsConstSharedPtr
  createTransportSocketOptionsWithFilterState(const std::string& key, const std::string& value) {
    auto filter_state = std::make_shared<StreamInfo::FilterStateImpl>(
        StreamInfo::FilterState::LifeSpan::Connection);
    auto string_accessor = std::make_shared<Router::StringAccessorImpl>(value);
    filter_state->setData(key, string_accessor, StreamInfo::FilterState::LifeSpan::Connection,
                          StreamInfo::StreamSharingMayImpactPooling::SharedWithUpstreamConnection);
    auto shared_objects = filter_state->objectsSharedWithUpstreamConnection();
    return std::make_shared<Network::TransportSocketOptionsImpl>(
        "", std::vector<std::string>{}, std::vector<std::string>{}, std::vector<std::string>{},
        std::nullopt, std::move(shared_objects));
  }

  // Helper to compute the per-connection resolution condition as used in LogicalHost.
  bool needsPerConnectionResolution(Network::TransportSocketOptionsConstSharedPtr options) {
    return cluster_info_->transportSocketMatcher().usesFilterState() && options &&
           !options->downstreamSharedFilterStateObjects().empty();
  }

  std::shared_ptr<NiceMock<Upstream::MockClusterInfo>> cluster_info_;
  Upstream::MockTransportSocketMatcher* transport_socket_matcher_;
};

// Test that per-connection resolution is triggered when all conditions are met.
TEST_F(LogicalHostTransportSocketResolutionTest, PerConnectionResolutionWhenAllConditionsMet) {
  ON_CALL(*transport_socket_matcher_, usesFilterState()).WillByDefault(Return(true));
  auto options =
      createTransportSocketOptionsWithFilterState("envoy.network.namespace", "/run/netns/ns1");

  EXPECT_TRUE(needsPerConnectionResolution(options));
}

// Test that per-connection resolution is not triggered when usesFilterState returns false.
TEST_F(LogicalHostTransportSocketResolutionTest,
       NoPerConnectionResolutionWhenUsesFilterStateFalse) {
  ON_CALL(*transport_socket_matcher_, usesFilterState()).WillByDefault(Return(false));
  auto options =
      createTransportSocketOptionsWithFilterState("envoy.network.namespace", "/run/netns/ns1");

  EXPECT_FALSE(needsPerConnectionResolution(options));
}

// Test that per-connection resolution is not triggered when transport socket options are null.
TEST_F(LogicalHostTransportSocketResolutionTest, NoPerConnectionResolutionWhenOptionsNull) {
  ON_CALL(*transport_socket_matcher_, usesFilterState()).WillByDefault(Return(true));
  Network::TransportSocketOptionsConstSharedPtr options = nullptr;

  EXPECT_FALSE(needsPerConnectionResolution(options));
}

// Test that per-connection resolution is not triggered when filter state objects are empty.
TEST_F(LogicalHostTransportSocketResolutionTest,
       NoPerConnectionResolutionWhenFilterStateObjectsEmpty) {
  ON_CALL(*transport_socket_matcher_, usesFilterState()).WillByDefault(Return(true));
  auto options = std::make_shared<Network::TransportSocketOptionsImpl>(
      "", std::vector<std::string>{}, std::vector<std::string>{}, std::vector<std::string>{});

  EXPECT_FALSE(needsPerConnectionResolution(options));
}

// Test that override transport socket options takes precedence over passed options.
TEST_F(LogicalHostTransportSocketResolutionTest, OverrideTransportSocketOptionsTakesPrecedence) {
  ON_CALL(*transport_socket_matcher_, usesFilterState()).WillByDefault(Return(true));

  // Create override options with filter state.
  auto override_options =
      createTransportSocketOptionsWithFilterState("envoy.network.namespace", "/run/netns/ns1");

  // Create passed options without filter state.
  auto passed_options = std::make_shared<Network::TransportSocketOptionsImpl>(
      "", std::vector<std::string>{}, std::vector<std::string>{}, std::vector<std::string>{});

  // Simulate LogicalHost's effective_options logic: use override if not null.
  const auto& effective_options = override_options != nullptr ? override_options : passed_options;

  EXPECT_TRUE(needsPerConnectionResolution(effective_options));
}

// Test fixture for LogicalHost::createOrcaReportingConnection override. This validates that the
// override snapshots address state under the host's lock and uses the caller-resolved transport
// socket factory.
class LogicalHostOrcaReportingConnectionTest : public testing::Test {
protected:
  void SetUp() override {
    cluster_info_ = std::make_shared<NiceMock<Upstream::MockClusterInfo>>();
    address_ = *Network::Utility::resolveUrl("tcp://10.0.0.1:1234");
    auto host_or_error = Upstream::LogicalHost::create(
        cluster_info_, /*hostname=*/"", address_, /*address_list=*/{},
        /*locality_lb_endpoint=*/envoy::config::endpoint::v3::LocalityLbEndpoints(),
        /*lb_endpoint=*/envoy::config::endpoint::v3::LbEndpoint(),
        /*override_transport_socket_options=*/nullptr);
    ASSERT_OK(host_or_error);
    host_ = std::shared_ptr<Upstream::LogicalHost>(std::move(*host_or_error));
  }

  std::shared_ptr<NiceMock<Upstream::MockClusterInfo>> cluster_info_;
  Network::Address::InstanceConstSharedPtr address_;
  std::shared_ptr<Upstream::LogicalHost> host_;
};

TEST_F(LogicalHostOrcaReportingConnectionTest, DialsHostDataAddress) {
  Event::MockDispatcher dispatcher;
  StrictMock<Network::MockClientConnection>* connection =
      new StrictMock<Network::MockClientConnection>();
  EXPECT_CALL(dispatcher, createClientConnection_(address_, _, _, _)).WillOnce(Return(connection));
  EXPECT_CALL(*connection, setBufferLimits(_)).Times(AnyNumber());
  EXPECT_CALL(*connection, connectionInfoSetter()).Times(AnyNumber());
  EXPECT_CALL(*connection, streamInfo()).Times(AnyNumber());
  Upstream::Host::CreateConnectionData data = host_->createOrcaReportingConnection(
      dispatcher, nullptr, host_->transportSocketFactory(), host_->orcaReportingAddress());
  EXPECT_EQ(data.host_description_->address(), address_);
}

TEST_F(LogicalHostOrcaReportingConnectionTest, CallerOptionsPassThroughUnchanged) {
  // Matcher with a mock factory so createTransportSocket can capture the
  // options; must be in place before host creation resolves its factory.
  auto mock_factory = std::make_unique<NiceMock<Network::MockTransportSocketFactory>>();
  auto* factory = mock_factory.get();
  cluster_info_->transport_socket_matcher_ =
      std::make_unique<NiceMock<Upstream::MockTransportSocketMatcher>>(std::move(mock_factory));

  // Host constructed with override options carrying SNI and a non-h2 ALPN.
  auto override_options = std::make_shared<const Network::TransportSocketOptionsImpl>(
      "sni.example", std::vector<std::string>{}, std::vector<std::string>{"http/1.1"});
  auto host_or_error =
      Upstream::LogicalHost::create(cluster_info_, /*hostname=*/"", address_, /*address_list=*/{},
                                    envoy::config::endpoint::v3::LocalityLbEndpoints(),
                                    envoy::config::endpoint::v3::LbEndpoint(), override_options);
  ASSERT_OK(host_or_error);
  auto host = std::shared_ptr<Upstream::LogicalHost>(std::move(*host_or_error));

  Network::TransportSocketOptionsConstSharedPtr seen_options;
  EXPECT_CALL(*factory, createTransportSocket(_, _))
      .WillOnce(testing::Invoke([&](Network::TransportSocketOptionsConstSharedPtr options,
                                    std::shared_ptr<const Upstream::HostDescription>) {
        seen_options = options;
        return nullptr;
      }));

  auto caller_options = std::make_shared<const Network::TransportSocketOptionsImpl>(
      "", std::vector<std::string>{}, std::vector<std::string>{"h2"});
  Event::MockDispatcher dispatcher;
  StrictMock<Network::MockClientConnection>* connection =
      new StrictMock<Network::MockClientConnection>();
  EXPECT_CALL(dispatcher, createClientConnection_(address_, _, _, _)).WillOnce(Return(connection));
  EXPECT_CALL(*connection, setBufferLimits(_)).Times(AnyNumber());
  EXPECT_CALL(*connection, connectionInfoSetter()).Times(AnyNumber());
  EXPECT_CALL(*connection, streamInfo()).Times(AnyNumber());
  host->createOrcaReportingConnection(dispatcher, caller_options, host->transportSocketFactory(),
                                      host->orcaReportingAddress());

  // The caller's options reach the factory unchanged; the host's override
  // options are not consulted for ORCA connections (same as health checks).
  EXPECT_EQ(seen_options, caller_options);
}

TEST_F(LogicalHostOrcaReportingConnectionTest, CallerResolvedFactoryUsed) {
  auto* matcher = dynamic_cast<Upstream::MockTransportSocketMatcher*>(
      cluster_info_->transport_socket_matcher_.get());
  ASSERT_NE(matcher, nullptr);
  envoy::config::core::v3::Metadata md;
  // Caller resolves match metadata once; createOrcaReportingConnection must not resolve again.
  EXPECT_CALL(*matcher, resolve(&md, _, _))
      .WillOnce(Return(Upstream::TransportSocketMatcher::MatchData(*matcher->socket_factory_,
                                                                   matcher->stats_, "orca-md")));
  Network::UpstreamTransportSocketFactory& factory =
      host_->resolveTransportSocketFactory(host_->orcaReportingAddress(), &md, nullptr);
  Event::MockDispatcher dispatcher;
  StrictMock<Network::MockClientConnection>* connection =
      new StrictMock<Network::MockClientConnection>();
  EXPECT_CALL(dispatcher, createClientConnection_(address_, _, _, _)).WillOnce(Return(connection));
  EXPECT_CALL(*connection, setBufferLimits(_)).Times(AnyNumber());
  EXPECT_CALL(*connection, connectionInfoSetter()).Times(AnyNumber());
  EXPECT_CALL(*connection, streamInfo()).Times(AnyNumber());
  host_->createOrcaReportingConnection(dispatcher, nullptr, factory, host_->orcaReportingAddress());
}

} // namespace Clusters
} // namespace Extensions
} // namespace Envoy
