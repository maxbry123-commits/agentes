#include "envoy/extensions/filters/http/jwt_authn/v3/config.pb.h"

#include "source/extensions/filters/http/jwt_authn/filter_config.h"
#include "source/extensions/filters/http/jwt_authn/verifier.h"

#include "test/extensions/filters/http/jwt_authn/mock.h"
#include "test/extensions/filters/http/jwt_authn/test_common.h"
#include "test/mocks/server/factory_context.h"
#include "test/test_common/status_utility.h"
#include "test/test_common/utility.h"

#include "gmock/gmock.h"

using envoy::extensions::filters::http::jwt_authn::v3::JwtAuthentication;
using envoy::extensions::filters::http::jwt_authn::v3::JwtRequirement;
using ::testing::Eq;
using ::testing::NiceMock;

namespace Envoy {
namespace Extensions {
namespace HttpFilters {
namespace JwtAuthn {
namespace {

using StatusHelpers::HasStatus;

using JwtVerify::Status;

Protobuf::Struct getExpectedPayload(const std::string& name) {
  Protobuf::Struct expected_payload;
  TestUtility::loadFromJson(ExpectedPayloadJSON, expected_payload);

  Protobuf::Struct struct_obj;
  *(*struct_obj.mutable_fields())[name].mutable_struct_value() = expected_payload;
  return struct_obj;
}

class ProviderVerifierTest : public testing::Test {
public:
  ProviderVerifierTest() {
    mock_factory_ctx_.server_factory_context_.cluster_manager_.initializeThreadLocalClusters(
        {"pubkey_cluster"});
  }

  void createVerifier() {
    absl::Status creation_status = absl::OkStatus();
    filter_config_ = std::make_shared<FilterConfigImpl>(
        proto_config_, "", mock_factory_ctx_.server_factory_context_, mock_factory_ctx_.scope(),
        makeOptRef<Init::Manager>(mock_factory_ctx_.init_manager_), creation_status);
    ASSERT_TRUE(creation_status.ok());
    auto verifier_or = Verifier::create(proto_config_.rules(0).requires_(),
                                        proto_config_.providers(), *filter_config_);
    ASSERT_TRUE(verifier_or.ok());
    verifier_ = std::move(verifier_or).value();
  }

  JwtAuthentication proto_config_;
  NiceMock<Server::Configuration::MockFactoryContext> mock_factory_ctx_;
  std::shared_ptr<FilterConfigImpl> filter_config_;
  VerifierConstPtr verifier_;
  ContextSharedPtr context_;
  MockVerifierCallbacks mock_cb_;
  NiceMock<Tracing::MockSpan> parent_span_;
};

TEST_F(ProviderVerifierTest, TestOkJWT) {
  TestUtility::loadFromYaml(ExampleConfig, proto_config_);
  (*proto_config_.mutable_providers())[std::string(ProviderName)].set_payload_in_metadata(
      "my_payload");
  createVerifier();
  MockUpstream mock_pubkey(mock_factory_ctx_.server_factory_context_.cluster_manager_, PublicKey);

  EXPECT_CALL(mock_cb_, setExtractedData(_)).WillOnce(Invoke([](const Protobuf::Struct& payload) {
    EXPECT_TRUE(TestUtility::protoEqual(payload, getExpectedPayload("my_payload")));
  }));

  EXPECT_CALL(mock_cb_, onComplete(Status::Ok));

  auto headers = Http::TestRequestHeaderMapImpl{
      {"Authorization", "Bearer " + std::string(GoodToken)},
      {"sec-istio-auth-userinfo", ""},
      {"x-jwt-claim-sub", "value-to-be-replaced"},
      {"x-jwt-claim-nested", "header-to-be-deleted"},
  };
  context_ = Verifier::createContext(headers, parent_span_, &mock_cb_);
  verifier_->verify(context_);
  EXPECT_EQ(ExpectedPayloadValue, headers.get_("sec-istio-auth-userinfo"));
  EXPECT_EQ("test@example.com", headers.get_("x-jwt-claim-sub"));
  EXPECT_FALSE(headers.has("x-jwt-claim-nested"));
}

// Test to set the payload (hence dynamic metadata) with the header and payload extracted from the
// verified JWT.
TEST_F(ProviderVerifierTest, TestOkJWTWithExtractedHeaderAndPayload) {
  TestUtility::loadFromYaml(ExampleConfig, proto_config_);
  (*proto_config_.mutable_providers())[std::string(ProviderName)].set_payload_in_metadata(
      "my_payload");
  (*proto_config_.mutable_providers())[std::string(ProviderName)].set_header_in_metadata(
      "my_header");
  createVerifier();
  MockUpstream mock_pubkey(mock_factory_ctx_.server_factory_context_.cluster_manager_, PublicKey);

  EXPECT_CALL(mock_cb_, setExtractedData(_)).WillOnce(Invoke([](const Protobuf::Struct& payload) {
    // The expected payload is a merged struct of the extracted (from the JWT) payload and
    // header data with "my_payload" and "my_header" as the keys.
    Protobuf::Struct expected_payload;
    MessageUtil::loadFromJson(ExpectedPayloadAndHeaderJSON, expected_payload);
    EXPECT_TRUE(TestUtility::protoEqual(payload, expected_payload));
  }));

  EXPECT_CALL(mock_cb_, onComplete(Status::Ok));

  auto headers = Http::TestRequestHeaderMapImpl{
      {"Authorization", "Bearer " + std::string(GoodToken)},
      {"sec-istio-auth-userinfo", ""},
  };
  context_ = Verifier::createContext(headers, parent_span_, &mock_cb_);
  verifier_->verify(context_);
  EXPECT_EQ(ExpectedPayloadValue, headers.get_("sec-istio-auth-userinfo"));
}

// Test to set dynamic metadata with the status of a failed JWT verification.
TEST_F(ProviderVerifierTest, TestExpiredJWTWithFailedStatusInMetadata) {
  TestUtility::loadFromYaml(ExampleConfig, proto_config_);
  (*proto_config_.mutable_providers())[std::string(ProviderName)].set_failed_status_in_metadata(
      "my_payload");
  createVerifier();
  MockUpstream mock_pubkey(mock_factory_ctx_.server_factory_context_.cluster_manager_, PublicKey);

  EXPECT_CALL(mock_cb_, setExtractedData(_)).WillOnce(Invoke([](const Protobuf::Struct& payload) {
    Protobuf::Struct expected_payload;
    MessageUtil::loadFromJson(ExpectedJWTExpiredStatusJSON, expected_payload);

    EXPECT_TRUE(TestUtility::protoEqual(payload, expected_payload));
  }));

  EXPECT_CALL(mock_cb_, onComplete(Status::JwtExpired));

  auto headers =
      Http::TestRequestHeaderMapImpl{{"Authorization", "Bearer " + std::string(ExpiredToken)}};
  context_ = Verifier::createContext(headers, parent_span_, &mock_cb_);
  verifier_->verify(context_);
}

TEST_F(ProviderVerifierTest, TestSpanPassedDown) {
  TestUtility::loadFromYaml(ExampleConfig, proto_config_);
  (*proto_config_.mutable_providers())[std::string(ProviderName)].set_payload_in_metadata(
      "my_payload");
  createVerifier();
  MockUpstream mock_pubkey(mock_factory_ctx_.server_factory_context_.cluster_manager_, PublicKey);

  EXPECT_CALL(mock_cb_, setExtractedData(_)).WillOnce(Invoke([](const Protobuf::Struct& payload) {
    EXPECT_TRUE(TestUtility::protoEqual(payload, getExpectedPayload("my_payload")));
  }));

  EXPECT_CALL(mock_cb_, onComplete(Status::Ok));

  auto options = Http::AsyncClient::RequestOptions()
                     .setTimeout(std::chrono::milliseconds(5 * 1000))
                     .setParentSpan(parent_span_)
                     .setChildSpanName("JWT Remote PubKey Fetch");
  EXPECT_CALL(mock_factory_ctx_.server_factory_context_.cluster_manager_.thread_local_cluster_
                  .async_client_,
              send_(_, _, Eq(options)));

  auto headers = Http::TestRequestHeaderMapImpl{
      {"Authorization", "Bearer " + std::string(GoodToken)},
      {"sec-istio-auth-userinfo", ""},
  };
  context_ = Verifier::createContext(headers, parent_span_, &mock_cb_);
  verifier_->verify(context_);
}

TEST_F(ProviderVerifierTest, TestMissedJWT) {
  TestUtility::loadFromYaml(ExampleConfig, proto_config_);
  createVerifier();

  EXPECT_CALL(mock_cb_, onComplete(Status::JwtMissed));

  auto headers = Http::TestRequestHeaderMapImpl{
      {"sec-istio-auth-userinfo", ""}, {"x-jwt-claim-sub", ""}, {"x-jwt-claim-nested", ""}};
  context_ = Verifier::createContext(headers, parent_span_, &mock_cb_);
  verifier_->verify(context_);
  EXPECT_FALSE(headers.has("sec-istio-auth-userinfo"));
  EXPECT_FALSE(headers.has("x-jwt-claim-sub"));
  EXPECT_FALSE(headers.has("x-jwt-claim-nested"));
}

// Provider-scoped Extractors only sanitize headers for their own providers. The live filter path
// additionally sanitizes the union of every provider's payload/claim headers in
// Filter::decodeHeaders before verifier selection, so the spoofed headers below would already be
// gone on a real request; this test pins Extractor/requirement scoping in isolation.
TEST_F(ProviderVerifierTest, TestTokenRequirementProviderMismatch) {
  const char config[] = R"(
providers:
  example_provider:
    issuer: https://example.com
    audiences:
    - example_service
    - http://example_service1
    - https://example_service2/
    remote_jwks:
      http_uri:
        uri: https://pubkey-server/pubkey-path
        cluster: pubkey_cluster
    forward_payload_header: example-auth-userinfo
    claim_to_headers:
    - header_name: x-jwt-claim-sub
      claim_name: sub
  other_provider:
    issuer: other_issuer
    forward_payload_header: other-auth-userinfo
    claim_to_headers:
    - header_name: x-jwt-claim-issuer
      claim_name: iss
rules:
- match:
    path: "/"
  requires:
    provider_name: "other_provider"
)";
  TestUtility::loadFromYaml(config, proto_config_);
  createVerifier();

  EXPECT_CALL(mock_cb_, onComplete(Status::JwtUnknownIssuer));

  auto headers = Http::TestRequestHeaderMapImpl{
      {"Authorization", "Bearer " + std::string(GoodToken)},
      {"example-auth-userinfo", ""},
      {"other-auth-userinfo", ""},
      {"x-jwt-claim-sub", ""},
      {"x-jwt-claim-issuer", ""},
  };
  context_ = Verifier::createContext(headers, parent_span_, &mock_cb_);
  verifier_->verify(context_);
  EXPECT_TRUE(headers.has("example-auth-userinfo"));
  EXPECT_TRUE(headers.has("x-jwt-claim-sub"));
  EXPECT_FALSE(headers.has("x-jwt-claim-issuer"));
  EXPECT_FALSE(headers.has("other-auth-userinfo"));
}

// This test verifies that JWT requirement can override audiences
TEST_F(ProviderVerifierTest, TestRequiresProviderWithAudiences) {
  TestUtility::loadFromYaml(ExampleConfig, proto_config_);
  auto* provider_and_audiences =
      proto_config_.mutable_rules(0)->mutable_requires_()->mutable_provider_and_audiences();
  provider_and_audiences->set_provider_name("example_provider");
  provider_and_audiences->add_audiences("invalid_service");
  createVerifier();
  MockUpstream mock_pubkey(mock_factory_ctx_.server_factory_context_.cluster_manager_, PublicKey);

  EXPECT_CALL(mock_cb_, onComplete(_))
      .WillOnce(
          Invoke([](const Status& status) { ASSERT_EQ(status, Status::JwtAudienceNotAllowed); }))
      .WillOnce(Invoke([](const Status& status) { ASSERT_EQ(status, Status::Ok); }));

  auto headers =
      Http::TestRequestHeaderMapImpl{{"Authorization", "Bearer " + std::string(GoodToken)}};
  verifier_->verify(Verifier::createContext(headers, parent_span_, &mock_cb_));
  headers =
      Http::TestRequestHeaderMapImpl{{"Authorization", "Bearer " + std::string(InvalidAudToken)}};
  verifier_->verify(Verifier::createContext(headers, parent_span_, &mock_cb_));
}

// This test verifies that requirement referencing nonexistent provider will fail config creation.
TEST_F(ProviderVerifierTest, TestRequiresNonexistentProvider) {
  TestUtility::loadFromYaml(ExampleConfig, proto_config_);
  proto_config_.mutable_rules(0)->mutable_requires_()->set_provider_name("nosuchprovider");

  absl::Status creation_status = absl::OkStatus();
  FilterConfigImpl filter_config(
      proto_config_, "", mock_factory_ctx_.server_factory_context_, mock_factory_ctx_.scope(),
      makeOptRef<Init::Manager>(mock_factory_ctx_.init_manager_), creation_status);
  EXPECT_THAT(creation_status, HasStatus(absl::StatusCode::kInvalidArgument,
                                         ::testing::HasSubstr("Required provider")));
}

class ProviderVerifiersJwtCacheTest : public ProviderVerifierTest,
                                      public testing::WithParamInterface<bool> {};

// Bool is for jwt_cache: with jwt_cache and without jwt_cache.
INSTANTIATE_TEST_SUITE_P(ProviderVerifiersJwtCache, ProviderVerifiersJwtCacheTest,
                         ::testing::Bool());

// This test verifies that two JWT requirements with different audiences behave the same with
// jwt_cache and without. The first requirement is checking audiences specified in the provider
// which is "example_service". The second requirement is type "provider_and_audiences" and its
// specified audiences is "other_service". The audience in the JWT is "example_service". The
// first requirement should work and the second one should fail.
TEST_P(ProviderVerifiersJwtCacheTest, TestRequirementsWithAudiences) {
  TestUtility::loadFromYaml(ExampleConfig, proto_config_);
  // Turn on jwt_cache
  if (GetParam()) {
    (*proto_config_.mutable_providers())[std::string(ProviderName)]
        .mutable_jwt_cache_config()
        ->set_jwt_cache_size(1000);
  }
  createVerifier();

  JwtRequirement require2;
  auto* provider_and_audiences = require2.mutable_provider_and_audiences();
  provider_and_audiences->set_provider_name("example_provider");
  provider_and_audiences->add_audiences("other_service");
  auto verifier2_or = Verifier::create(require2, proto_config_.providers(), *filter_config_);
  ASSERT_TRUE(verifier2_or.ok()) << verifier2_or.status();
  auto verifier2 = std::move(verifier2_or).value();

  MockUpstream mock_pubkey(mock_factory_ctx_.server_factory_context_.cluster_manager_, PublicKey);

  {
    // First call, audience matched, so it is good.
    EXPECT_CALL(mock_cb_, onComplete(_)).WillOnce(Invoke([](const Status& status) {
      ASSERT_EQ(status, Status::Ok);
    }));

    auto headers =
        Http::TestRequestHeaderMapImpl{{"Authorization", "Bearer " + std::string(GoodToken)}};
    verifier_->verify(Verifier::createContext(headers, parent_span_, &mock_cb_));
  }

  {
    // Second call, audiences don't match, so it is rejected.
    MockVerifierCallbacks mock_cb2;
    EXPECT_CALL(mock_cb2, onComplete(_)).WillOnce(Invoke([](const Status& status) {
      ASSERT_EQ(status, Status::JwtAudienceNotAllowed);
    }));

    auto headers =
        Http::TestRequestHeaderMapImpl{{"Authorization", "Bearer " + std::string(GoodToken)}};
    verifier2->verify(Verifier::createContext(headers, parent_span_, &mock_cb2));
  }

  if (GetParam()) {
    EXPECT_EQ(1U, filter_config_->stats().jwt_cache_hit_.value());
    EXPECT_EQ(1U, filter_config_->stats().jwt_cache_miss_.value());
  } else {
    EXPECT_EQ(0U, filter_config_->stats().jwt_cache_hit_.value());
    EXPECT_EQ(2U, filter_config_->stats().jwt_cache_miss_.value());
  }
}

} // namespace
} // namespace JwtAuthn
} // namespace HttpFilters
} // namespace Extensions
} // namespace Envoy
