#include "envoy/extensions/filters/http/proto_api_scrubber/v3/matcher_actions.pb.h"

#include "source/common/matcher/matcher.h"
#include "source/extensions/filters/http/proto_api_scrubber/config.h"
#include "source/extensions/filters/http/proto_api_scrubber/filter_config.h"

#include "test/common/matcher/test_utility.h"
#include "test/mocks/http/mocks.h"
#include "test/mocks/server/factory_context.h"
#include "test/proto/apikeys.pb.h"
#include "test/test_common/environment.h"
#include "test/test_common/status_utility.h"
#include "test/test_common/utility.h"

#include "absl/status/status.h"
#include "gmock/gmock.h"
#include "gtest/gtest.h"
#include "xds/type/matcher/v3/cel.pb.h"
#include "xds/type/matcher/v3/http_inputs.pb.h"

namespace Envoy {
namespace Extensions {
namespace HttpFilters {
namespace ProtoApiScrubber {
namespace {
using ::envoy::extensions::filters::http::proto_api_scrubber::v3::MethodRestrictions;
using ::envoy::extensions::filters::http::proto_api_scrubber::v3::ProtoApiScrubberConfig;
using ::envoy::extensions::filters::http::proto_api_scrubber::v3::RestrictionConfig;
using Http::HttpMatchingData;
using xds::type::matcher::v3::HttpAttributesCelMatchInput;
using MatchTreeHttpMatchingDataSharedPtr = Matcher::MatchTreeSharedPtr<HttpMatchingData>;
using Matcher::HasActionWithType;
using Matcher::HasNoMatch;
using StatusHelpers::HasStatus;
using StatusHelpers::IsOk;
using testing::AllOf;
using testing::HasSubstr;
using testing::NiceMock;

inline constexpr const char kApiKeysDescriptorRelativePath[] = "test/proto/apikeys.descriptor";

// A class for testing filter config related capabilities eg, parsing and storing the filter
// config in internal data structures, etc.
class ProtoApiScrubberFilterConfigTest : public ::testing::Test {
protected:
  ProtoApiScrubberFilterConfigTest() : api_(Api::createApiForTest()) {
    setupMocks();
    initDefaultProtoConfig();
  }

  void initDefaultProtoConfig() {
    std::ignore = Protobuf::TextFormat::ParseFromString(getDefaultProtoConfig(), &proto_config_);
    *proto_config_.mutable_descriptor_set()->mutable_data_source()->mutable_inline_bytes() =
        api_->fileSystem()
            .fileReadToEnd(Envoy::TestEnvironment::runfilesPath(kApiKeysDescriptorRelativePath))
            .value();
  }

  void setupMocks() {
    // factory_context.serverFactoryContext().api() is used to read descriptor file during filter
    // config initialization. This mock setup ensures that test API is propagated properly to the
    // filter.
    ON_CALL(server_factory_context_, api()).WillByDefault(testing::ReturnRef(*api_));
    ON_CALL(factory_context_, serverFactoryContext())
        .WillByDefault(testing::ReturnRef(server_factory_context_));
  }

  std::string getDefaultProtoConfig() {
    return R"pb(
      descriptor_set: { }
      restrictions: {
        method_restrictions: {
          key: "/apikeys.ApiKeys/CreateApiKey"
          value: {
            request_field_restrictions: {
              key: "debug_info"
              value: {
                matcher: {
                  matcher_list: {
                    matchers: {
                      predicate: {
                        single_predicate: {
                          input: {
                            name: "http_attributes_cel_match_input"
                            typed_config: {
                              [type.googleapis.com/xds.type.matcher.v3.HttpAttributesCelMatchInput] { }
                            }
                          }
                          custom_match: {
                            name: "cel_matcher"
                            typed_config: {
                              [type.googleapis.com/xds.type.matcher.v3.CelMatcher] {
                                expr_match: {
                                  cel_expr_parsed: {
                                    expr: {
                                      id: 1
                                      const_expr: {
                                        bool_value: true
                                      }
                                    }
                                    source_info: {
                                      syntax_version: "cel1"
                                      location: "inline_expression"
                                      positions: {
                                        key: 1
                                        value: 0
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                      on_match: {
                        action: {
                          name: "remove_field_action"
                          typed_config: {
                            [type.googleapis.com/envoy.extensions.filters.http.proto_api_scrubber.v3.RemoveFieldAction] { }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
            response_field_restrictions: {
              key: "book.debug_info"
              value: {
                matcher: {
                  matcher_list: {
                    matchers: {
                      predicate: {
                        single_predicate: {
                          input: {
                            name: "http_attributes_cel_match_input"
                            typed_config: {
                              [type.googleapis.com/xds.type.matcher.v3.HttpAttributesCelMatchInput] { }
                            }
                          }
                          custom_match: {
                            name: "cel_matcher"
                            typed_config: {
                              [type.googleapis.com/xds.type.matcher.v3.CelMatcher] {
                                expr_match: {
                                  cel_expr_parsed: {
                                    expr: {
                                      id: 1
                                      const_expr: {
                                        bool_value: false
                                      }
                                    }
                                    source_info: {
                                      syntax_version: "cel1"
                                      location: "inline_expression"
                                      positions: {
                                        key: 1
                                        value: 0
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                      on_match: {
                        action: {
                          name: "remove_field_action"
                          typed_config: {
                            [type.googleapis.com/envoy.extensions.filters.http.proto_api_scrubber.v3.RemoveFieldAction] { }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    )pb";
  }

  ProtoApiScrubberConfig getConfigWithMethodName(absl::string_view method_name) {
    std::string filter_conf_string = absl::StrFormat(
        R"pb(
    restrictions: {
      method_restrictions: {
        key: "%s"
        value: { }
      }
    }
  )pb",
        method_name);
    ProtoApiScrubberConfig proto_config;
    std::ignore = Protobuf::TextFormat::ParseFromString(filter_conf_string, &proto_config);
    *proto_config.mutable_descriptor_set()->mutable_data_source()->mutable_inline_bytes() =
        api_->fileSystem()
            .fileReadToEnd(Envoy::TestEnvironment::runfilesPath(kApiKeysDescriptorRelativePath))
            .value();
    return proto_config;
  }

  ProtoApiScrubberConfig getConfigWithFieldMask(absl::string_view field_mask) {
    std::string filter_conf_string = absl::StrFormat(
        R"pb(
        restrictions: {
          method_restrictions: {
            key: "/apikeys.ApiKeys/CreateApiKey"
            value: {
              response_field_restrictions: {
                key: "%s"
                value: {}
              }
            }
          }
        }
  )pb",
        field_mask);
    ProtoApiScrubberConfig proto_config;
    std::ignore = Protobuf::TextFormat::ParseFromString(filter_conf_string, &proto_config);
    *proto_config.mutable_descriptor_set()->mutable_data_source()->mutable_inline_bytes() =
        api_->fileSystem()
            .fileReadToEnd(Envoy::TestEnvironment::runfilesPath(kApiKeysDescriptorRelativePath))
            .value();
    return proto_config;
  }

  ProtoApiScrubberConfig getConfigWithInputType(absl::string_view input_type) {
    std::string filter_conf_string = absl::StrFormat(R"pb(
      restrictions: {
        method_restrictions: {
          key: "/apikeys.ApiKeys/CreateApiKey"
          value: {
            request_field_restrictions: {
              key: "debug_info"
              value: {
                matcher: {
                  matcher_list: {
                    matchers: {
                      predicate: {
                        single_predicate: {
                          input: {
                            typed_config: {
                              [%s] { }
                            }
                          }
                          custom_match: {
                            typed_config: {
                              [type.googleapis.com/xds.type.matcher.v3.CelMatcher] {
                                expr_match: {
                                  cel_expr_parsed: {
                                    expr: {
                                      id: 1
                                      const_expr: {
                                        bool_value: true
                                      }
                                    }
                                    source_info: {
                                      syntax_version: "cel1"
                                      location: "inline_expression"
                                      positions: {
                                        key: 1
                                        value: 0
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                      on_match: {
                        action: {
                          name: "remove_field_action"
                          typed_config: {
                            [type.googleapis.com/envoy.extensions.filters.http.proto_api_scrubber.v3.RemoveFieldAction] { }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    )pb",
                                                     input_type);
    ProtoApiScrubberConfig proto_config;
    std::ignore = Protobuf::TextFormat::ParseFromString(filter_conf_string, &proto_config);
    *proto_config.mutable_descriptor_set()->mutable_data_source()->mutable_inline_bytes() =
        api_->fileSystem()
            .fileReadToEnd(Envoy::TestEnvironment::runfilesPath(kApiKeysDescriptorRelativePath))
            .value();
    return proto_config;
  }

  ProtoApiScrubberConfig getConfigWithMessageRestrictions() {
    std::string filter_conf_string = R"pb(
      descriptor_set: {}
      restrictions: {
        message_restrictions: {
          key: "package.MyMessage"
          value: {
            config: {
              matcher: {
                matcher_list: {
                  matchers: {
                    predicate: {
                      single_predicate: {
                        input: {
                          typed_config: {
                            [type.googleapis.com/xds.type.matcher.v3
                                 .HttpAttributesCelMatchInput] {}
                          }
                        }
                        custom_match: {
                          typed_config: {
                            [type.googleapis.com/xds.type.matcher.v3.CelMatcher] {
                              expr_match: {
                                parsed_expr: { expr: { const_expr: { bool_value: true } } }
                              }
                            }
                          }
                        }
                      }
                    }
                    on_match: {
                      action: {
                        typed_config: {
                          [type.googleapis.com/envoy.extensions.filters.http
                               .proto_api_scrubber.v3.RemoveFieldAction] {}
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
        message_restrictions: {
          key: "another.package.OtherMessage"
          value: {
            config: {
              matcher: {
                matcher_list: {
                  matchers: {
                    predicate: {
                      single_predicate: {
                        input: {
                          typed_config: {
                            [type.googleapis.com/xds.type.matcher.v3
                                 .HttpAttributesCelMatchInput] {}
                          }
                        }
                        custom_match: {
                          typed_config: {
                            [type.googleapis.com/xds.type.matcher.v3.CelMatcher] {
                              expr_match: {
                                parsed_expr: { expr: { const_expr: { bool_value: false } } }
                              }
                            }
                          }
                        }
                      }
                    }
                    on_match: {
                      action: {
                        typed_config: {
                          [type.googleapis.com/envoy.extensions.filters.http
                               .proto_api_scrubber.v3.RemoveFieldAction] {}
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    )pb";
    ProtoApiScrubberConfig proto_config;
    std::ignore = Protobuf::TextFormat::ParseFromString(filter_conf_string, &proto_config);
    *proto_config.mutable_descriptor_set()->mutable_data_source()->mutable_inline_bytes() =
        api_->fileSystem()
            .fileReadToEnd(Envoy::TestEnvironment::runfilesPath(kApiKeysDescriptorRelativePath))
            .value();
    return proto_config;
  }

  ProtoApiScrubberConfig getConfigWithMessageFieldRestrictions() {
    std::string filter_conf_string = R"pb(
      descriptor_set: {}
      restrictions: {
        message_restrictions: {
          key: "package.MyMessage"
          value: {
            field_restrictions: {
              key: "sensitive_data"
              value: {
                matcher: {
                  matcher_list: {
                    matchers: {
                      predicate: {
                        single_predicate: {
                          input: {
                            typed_config: {
                              [type.googleapis.com/xds.type.matcher.v3
                                   .HttpAttributesCelMatchInput] {}
                            }
                          }
                          custom_match: {
                            typed_config: {
                              [type.googleapis.com/xds.type.matcher.v3.CelMatcher] {
                                expr_match: {
                                  parsed_expr: { expr: { const_expr: { bool_value: true } } }
                                }
                              }
                            }
                          }
                        }
                      }
                      on_match: {
                        action: {
                          typed_config: {
                            [type.googleapis.com/envoy.extensions.filters.http
                                 .proto_api_scrubber.v3.RemoveFieldAction] {}
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    )pb";
    ProtoApiScrubberConfig proto_config;
    std::ignore = Protobuf::TextFormat::ParseFromString(filter_conf_string, &proto_config);
    *proto_config.mutable_descriptor_set()->mutable_data_source()->mutable_inline_bytes() =
        api_->fileSystem()
            .fileReadToEnd(Envoy::TestEnvironment::runfilesPath(kApiKeysDescriptorRelativePath))
            .value();
    return proto_config;
  }

  ProtoApiScrubberConfig getConfigWithMethodLevelRestriction() {
    std::string filter_conf_string = R"pb(
      descriptor_set : {}
      restrictions: {
        method_restrictions: {
          key: "/apikeys.ApiKeys/CreateApiKey"
          value: {
            method_restriction: {
              matcher: {
                matcher_list: {
                  matchers: {
                    predicate: {
                      single_predicate: {
                        input: {
                          typed_config: {
                            [type.googleapis.com/xds.type.matcher.v3.HttpAttributesCelMatchInput] {}
                          }
                        }
                        custom_match: {
                          typed_config: {
                            [type.googleapis.com/xds.type.matcher.v3.CelMatcher] {
                              expr_match: { parsed_expr: { expr: { const_expr: { bool_value: true } } } }
                            }
                          }
                        }
                      }
                    }
                    on_match: {
                      action: {
                        typed_config: {
                          [type.googleapis.com/envoy.extensions.filters.http.proto_api_scrubber.v3.RemoveFieldAction] {}
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    )pb";
    ProtoApiScrubberConfig proto_config;
    std::ignore = Protobuf::TextFormat::ParseFromString(filter_conf_string, &proto_config);
    *proto_config.mutable_descriptor_set()->mutable_data_source()->mutable_inline_bytes() =
        api_->fileSystem()
            .fileReadToEnd(Envoy::TestEnvironment::runfilesPath(kApiKeysDescriptorRelativePath))
            .value();
    return proto_config;
  }

  ProtoApiScrubberConfig getConfigWithMessageName(absl::string_view message_name) {
    std::string filter_conf_string = absl::StrFormat(
        R"pb(
          descriptor_set : {}
          restrictions: {
            message_restrictions: {
              key: "%s"
              value: {}
            }
          }
        )pb",
        message_name);
    ProtoApiScrubberConfig proto_config;
    std::ignore = Protobuf::TextFormat::ParseFromString(filter_conf_string, &proto_config);
    *proto_config.mutable_descriptor_set()->mutable_data_source()->mutable_inline_bytes() =
        api_->fileSystem()
            .fileReadToEnd(Envoy::TestEnvironment::runfilesPath(kApiKeysDescriptorRelativePath))
            .value();
    return proto_config;
  }

  // Helper to create a serialized file descriptor set with custom names.
  // define_messages: if true, adds message type definitions to the file.
  //                  if false, methods will refer to types that do not exist (for failure testing).
  std::string createGenericDescriptor(const std::string& package_name,
                                      const std::string& service_name,
                                      const std::string& method_name, const std::string& input_type,
                                      const std::string& output_type, bool define_messages = true) {
    Protobuf::FileDescriptorProto file_proto;
    file_proto.set_name("generic_test.proto");

    // Only set package if it's not empty to test root-level services
    if (!package_name.empty()) {
      file_proto.set_package(package_name);
    }
    file_proto.set_syntax("proto3");

    if (define_messages) {
      auto* req_msg = file_proto.add_message_type();
      req_msg->set_name(input_type);

      auto* resp_msg = file_proto.add_message_type();
      resp_msg->set_name(output_type);
    }

    auto* service = file_proto.add_service();
    service->set_name(service_name);

    auto* method = service->add_method();
    method->set_name(method_name);
    method->set_input_type(input_type);
    method->set_output_type(output_type);

    Envoy::Protobuf::FileDescriptorSet descriptor_set;
    descriptor_set.add_file()->CopyFrom(file_proto);

    std::string descriptor_bytes;
    std::ignore = descriptor_set.SerializeToString(&descriptor_bytes);
    return descriptor_bytes;
  }

  // Helper to create a serialized FileDescriptorSet containing a specific Enum.
  // Defines: enum test.TestEnum { UNKNOWN = 0; ACTIVE = 1; }
  std::string createDescriptorWithTestEnum() {
    Protobuf::FileDescriptorProto file_proto;
    file_proto.set_name("test_enum.proto");
    file_proto.set_package("test");
    file_proto.set_syntax("proto3");

    auto* enum_type = file_proto.add_enum_type();
    enum_type->set_name("TestEnum");

    auto* val0 = enum_type->add_value();
    val0->set_name("UNKNOWN");
    val0->set_number(0);

    auto* val1 = enum_type->add_value();
    val1->set_name("ACTIVE");
    val1->set_number(1);

    Envoy::Protobuf::FileDescriptorSet descriptor_set;
    descriptor_set.add_file()->CopyFrom(file_proto);

    std::string descriptor_bytes;
    std::ignore = descriptor_set.SerializeToString(&descriptor_bytes);
    return descriptor_bytes;
  }

  Api::ApiPtr api_;
  ProtoApiScrubberConfig proto_config_;
  std::shared_ptr<const ProtoApiScrubberFilterConfig> filter_config_;
  NiceMock<Server::Configuration::MockFactoryContext> factory_context_;
  NiceMock<Server::Configuration::MockServerFactoryContext> server_factory_context_;
};

TEST_F(ProtoApiScrubberFilterConfigTest, StatsInitialization) {
  auto config_or_status = ProtoApiScrubberFilterConfig::create(
      proto_config_, server_factory_context_, factory_context_.scope());
  ASSERT_THAT(config_or_status, IsOk());
  filter_config_ = std::move(config_or_status.value());

  // Verify that the stats were created in the store with the correct prefix.
  // The Counters are lazily instantiated in Envoy usually, but since the struct constructor
  // calls POOL_COUNTER_PREFIX, they should be present in the map.
  // Just verify we can access the stats object and it points to valid counters.
  EXPECT_NE(&filter_config_->stats().total_requests_checked_, nullptr);
  EXPECT_EQ(filter_config_->stats().total_requests_checked_.name(),
            "proto_api_scrubber.total_requests_checked");
}

// Verifies that the filter factory can be created from just a `ServerFactoryContext&`, which is
// used for route/vhost level factory support.
TEST_F(ProtoApiScrubberFilterConfigTest, CreateFilterWithServerContext) {
  FilterFactoryCreator factory;
  Server::Configuration::ExtraFactoryContext extra_context{
      server_factory_context_.messageValidationVisitor(), "stats"};
  Envoy::Http::FilterFactoryCb cb =
      factory
          .createHttpFilterFactoryFromProto(proto_config_, server_factory_context_, extra_context)
          .value();
  NiceMock<Http::MockFilterChainFactoryCallbacks> filter_callbacks;
  EXPECT_CALL(filter_callbacks, addStreamFilter(testing::_));
  cb(filter_callbacks);
}

// Tests whether the match trees are initialized properly for each field mask.
TEST_F(ProtoApiScrubberFilterConfigTest, MatchTreeValidation) {
  NiceMock<StreamInfo::MockStreamInfo> mock_stream_info;
  Http::Matching::HttpMatchingDataImpl http_matching_data_impl(mock_stream_info);
  MatchTreeHttpMatchingDataSharedPtr match_tree;

  absl::StatusOr<std::shared_ptr<const ProtoApiScrubberFilterConfig>> filter_config =
      ProtoApiScrubberFilterConfig::create(proto_config_, server_factory_context_,
                                           factory_context_.scope());
  ASSERT_EQ(filter_config.status().code(), absl::StatusCode::kOk);
  ASSERT_NE(filter_config.value(), nullptr);
  filter_config_ = std::move(filter_config.value());

  {
    // Testing the match_tree for the field_mask `debug_info`.
    // The match expression in hardcoded to `true` for `debug_info` which should result in a match
    // and a corresponding action named `RemoveFieldAction`.
    match_tree =
        filter_config_->getRequestFieldMatcher("/apikeys.ApiKeys/CreateApiKey", "debug_info");
    ASSERT_NE(match_tree, nullptr);
    EXPECT_THAT(
        match_tree->match(http_matching_data_impl),
        HasActionWithType("envoy.extensions.filters.http.proto_api_scrubber.v3.RemoveFieldAction"));
  }

  {
    // Testing the match_tree for the field_mask `book.debug_info`.
    // The match expression in hardcoded to `false` for `book.debug_info` which should result in
    // no match.
    match_tree =
        filter_config_->getResponseFieldMatcher("/apikeys.ApiKeys/CreateApiKey", "book.debug_info");
    ASSERT_NE(match_tree, nullptr);
    EXPECT_THAT(match_tree->match(http_matching_data_impl), HasNoMatch());
  }

  {
    // Validate invalid method name for request field matchers.
    match_tree = filter_config_->getRequestFieldMatcher("/non.existent.service/method", "book");
    ASSERT_EQ(match_tree, nullptr);
  }

  {
    // Validate invalid method name for response field matchers.
    match_tree =
        filter_config_->getResponseFieldMatcher("/non.existent.service/method", "book.debug_info");
    ASSERT_EQ(match_tree, nullptr);
  }

  {
    // Validate invalid field mask for request field matchers.
    match_tree = filter_config_->getRequestFieldMatcher("/apikeys.ApiKeys/CreateApiKey",
                                                        "non.existent.field.mask");
    ASSERT_EQ(match_tree, nullptr);
  }

  {
    // Validate invalid field mask for response field matchers.
    match_tree = filter_config_->getResponseFieldMatcher("/apikeys.ApiKeys/CreateApiKey",
                                                         "non.existent.field.mask");
    ASSERT_EQ(match_tree, nullptr);
  }
}

TEST_F(ProtoApiScrubberFilterConfigTest, DescriptorValidations) {
  absl::StatusOr<std::shared_ptr<const ProtoApiScrubberFilterConfig>> filter_config;

  {
    // Top level `descriptor_set` not defined.
    ProtoApiScrubberConfig config;
    filter_config = ProtoApiScrubberFilterConfig::create(config, server_factory_context_,
                                                         factory_context_.scope());
    EXPECT_EQ(filter_config.status().code(), absl::StatusCode::kInvalidArgument);
    EXPECT_EQ(filter_config.status().message(),
              "Error encountered during config initialization. Unsupported DataSource case `0` for "
              "configuring `descriptor_set`");
  }

  {
    // Invalid descriptor format (non-binary) from inline bytes.
    ProtoApiScrubberConfig config;
    *config.mutable_descriptor_set()->mutable_data_source()->mutable_inline_bytes() = "123";
    filter_config = ProtoApiScrubberFilterConfig::create(config, server_factory_context_,
                                                         factory_context_.scope());
    EXPECT_EQ(filter_config.status().code(), absl::StatusCode::kInvalidArgument);
    EXPECT_THAT(filter_config.status().message(),
                HasSubstr("Error encountered during config initialization. Unable to "
                          "parse proto descriptor from inline bytes"));
  }

  {
    // Invalid descriptor format but invalid descriptor (eg, duplicate message definition) from
    // inline bytes.
    Protobuf::FileDescriptorProto file_proto;
    file_proto.set_name("test_file.proto");
    file_proto.set_package("test_package");
    file_proto.set_syntax("proto3");

    // Add duplicate message types to make the descriptor invalid.
    file_proto.add_message_type()->set_name("TestMessage");
    file_proto.add_message_type()->set_name("TestMessage");

    std::string invalid_binary_descriptor;
    std::ignore = file_proto.SerializeToString(&invalid_binary_descriptor);

    ProtoApiScrubberConfig config;
    *config.mutable_descriptor_set()->mutable_data_source()->mutable_inline_bytes() =
        invalid_binary_descriptor;
    filter_config = ProtoApiScrubberFilterConfig::create(config, server_factory_context_,
                                                         factory_context_.scope());
    EXPECT_EQ(filter_config.status().code(), absl::StatusCode::kInvalidArgument);
    EXPECT_THAT(filter_config.status().message(),
                HasSubstr("Error encountered during config initialization. Unable to "
                          "parse proto descriptor from inline bytes"));
  }

  {
    // Invalid descriptor format but invalid descriptor (eg, duplicate message definition in two
    // separate files) from inline bytes.
    Envoy::Protobuf::FileDescriptorSet descriptor_set;

    Protobuf::FileDescriptorProto file1_proto;
    file1_proto.set_name("test_file1.proto");
    file1_proto.set_package("test_package");
    file1_proto.set_syntax("proto3");
    file1_proto.add_message_type()->set_name("TestMessage");

    Protobuf::FileDescriptorProto file2_proto;
    file2_proto.set_name("test_file2.proto");
    file2_proto.set_package("test_package");
    file2_proto.set_syntax("proto3");
    // Duplicate definition - TestMessage is already defined in test_file1.proto
    file2_proto.add_message_type()->set_name("TestMessage");

    descriptor_set.add_file()->CopyFrom(file1_proto);
    descriptor_set.add_file()->CopyFrom(file2_proto);

    std::string invalid_binary_descriptor;
    std::ignore = descriptor_set.SerializeToString(&invalid_binary_descriptor);

    ProtoApiScrubberConfig config;
    *config.mutable_descriptor_set()->mutable_data_source()->mutable_inline_bytes() =
        invalid_binary_descriptor;
    filter_config = ProtoApiScrubberFilterConfig::create(config, server_factory_context_,
                                                         factory_context_.scope());
    EXPECT_EQ(filter_config.status().code(), absl::StatusCode::kInvalidArgument);
    EXPECT_THAT(filter_config.status().message(),
                HasSubstr("Error encountered during config initialization. Error occurred in file "
                          "`test_file2.proto` while trying to build proto descriptors."));
  }

  {
    // Valid descriptors from inline bytes.
    ProtoApiScrubberConfig config;
    *config.mutable_descriptor_set()->mutable_data_source()->mutable_inline_bytes() =
        api_->fileSystem()
            .fileReadToEnd(Envoy::TestEnvironment::runfilesPath(kApiKeysDescriptorRelativePath))
            .value();
    filter_config = ProtoApiScrubberFilterConfig::create(config, server_factory_context_,
                                                         factory_context_.scope());
    EXPECT_EQ(filter_config.status().code(), absl::StatusCode::kOk);
    EXPECT_EQ(filter_config.status().message(), "");
  }

  {
    // Non-existent file path.
    ProtoApiScrubberConfig config;
    *config.mutable_descriptor_set()->mutable_data_source()->mutable_filename() =
        TestEnvironment::runfilesPath("path/to/non-existent-file.descriptor");
    filter_config = ProtoApiScrubberFilterConfig::create(config, server_factory_context_,
                                                         factory_context_.scope());
    EXPECT_EQ(filter_config.status().code(), absl::StatusCode::kInvalidArgument);
    EXPECT_THAT(
        filter_config.status().message(),
        HasSubstr("Error encountered during config initialization. Unable to read from file"));
    EXPECT_THAT(filter_config.status().message(),
                HasSubstr("path/to/non-existent-file.descriptor"));
  }

  {
    // Invalid descriptors from file.
    ProtoApiScrubberConfig config;
    *config.mutable_descriptor_set()->mutable_data_source()->mutable_filename() =
        TestEnvironment::runfilesPath("test/config/integration/certs/upstreamcacert.pem");
    filter_config = ProtoApiScrubberFilterConfig::create(config, server_factory_context_,
                                                         factory_context_.scope());
    EXPECT_EQ(filter_config.status().code(), absl::StatusCode::kInvalidArgument);
    EXPECT_THAT(filter_config.status().message(),
                HasSubstr("Error encountered during config initialization. Unable to "
                          "parse proto descriptor from file"));
    EXPECT_THAT(filter_config.status().message(),
                HasSubstr("test/config/integration/certs/upstreamcacert.pem"));
  }

  {
    // Valid descriptors from file.
    ProtoApiScrubberConfig config;
    *config.mutable_descriptor_set()->mutable_data_source()->mutable_filename() =
        TestEnvironment::runfilesPath(kApiKeysDescriptorRelativePath);
    filter_config = ProtoApiScrubberFilterConfig::create(config, server_factory_context_,
                                                         factory_context_.scope());
    EXPECT_EQ(filter_config.status().code(), absl::StatusCode::kOk);
    EXPECT_EQ(filter_config.status().message(), "");
  }

  {
    // Unsupported descriptor type - string.
    ProtoApiScrubberConfig config;
    *config.mutable_descriptor_set()->mutable_data_source()->mutable_inline_string() =
        api_->fileSystem()
            .fileReadToEnd(Envoy::TestEnvironment::runfilesPath(kApiKeysDescriptorRelativePath))
            .value();
    filter_config = ProtoApiScrubberFilterConfig::create(config, server_factory_context_,
                                                         factory_context_.scope());
    EXPECT_EQ(filter_config.status().code(), absl::StatusCode::kInvalidArgument);
    EXPECT_EQ(filter_config.status().message(),
              "Error encountered during config initialization. Unsupported DataSource case `3` for "
              "configuring `descriptor_set`");
  }
}

TEST_F(ProtoApiScrubberFilterConfigTest, MethodNameValidations) {
  absl::StatusOr<std::shared_ptr<const ProtoApiScrubberFilterConfig>> filter_config;

  {
    filter_config = ProtoApiScrubberFilterConfig::create(
        getConfigWithMethodName(""), server_factory_context_, factory_context_.scope());
    EXPECT_EQ(filter_config.status().code(), absl::StatusCode::kInvalidArgument);
    EXPECT_EQ(filter_config.status().message(), "Error encountered during config initialization. "
                                                "Invalid method name: ''. Method name is empty.");
  }

  {
    filter_config =
        ProtoApiScrubberFilterConfig::create(getConfigWithMethodName("/library.BookService/*"),
                                             server_factory_context_, factory_context_.scope());
    EXPECT_EQ(filter_config.status().code(), absl::StatusCode::kInvalidArgument);
    EXPECT_EQ(filter_config.status().message(),
              "Error encountered during config initialization. Invalid method name: "
              "'/library.BookService/*'. Method name contains '*' which is not supported.");
  }

  {
    filter_config = ProtoApiScrubberFilterConfig::create(
        getConfigWithMethodName("/library.*/*"), server_factory_context_, factory_context_.scope());
    EXPECT_EQ(filter_config.status().code(), absl::StatusCode::kInvalidArgument);
    EXPECT_EQ(
        filter_config.status().message(),
        "Error encountered during config initialization. Invalid method name: '/library.*/*'. "
        "Method name contains '*' which is not supported.");
  }

  {
    filter_config = ProtoApiScrubberFilterConfig::create(
        getConfigWithMethodName("*"), server_factory_context_, factory_context_.scope());
    EXPECT_EQ(filter_config.status().code(), absl::StatusCode::kInvalidArgument);
    EXPECT_EQ(
        filter_config.status().message(),
        "Error encountered during config initialization. Invalid method name: '*'. Method name "
        "contains '*' which is not supported.");
  }

  {
    filter_config = ProtoApiScrubberFilterConfig::create(
        getConfigWithMethodName("/library.BookService.GetBook"), server_factory_context_,
        factory_context_.scope());
    EXPECT_EQ(filter_config.status().code(), absl::StatusCode::kInvalidArgument);
    EXPECT_EQ(filter_config.status().message(),
              "Error encountered during config initialization. Invalid method name: "
              "'/library.BookService.GetBook'. Method name should follow the gRPC format "
              "('/package.ServiceName/MethodName').");
  }

  {
    filter_config =
        ProtoApiScrubberFilterConfig::create(getConfigWithMethodName("library.BookService/GetBook"),
                                             server_factory_context_, factory_context_.scope());
    EXPECT_EQ(filter_config.status().code(), absl::StatusCode::kInvalidArgument);
    EXPECT_EQ(filter_config.status().message(),
              "Error encountered during config initialization. Invalid method name: "
              "'library.BookService/GetBook'. Method name should follow the gRPC format "
              "('/package.ServiceName/MethodName').");
  }

  {
    filter_config =
        ProtoApiScrubberFilterConfig::create(getConfigWithMethodName("library.BookService.GetBook"),
                                             server_factory_context_, factory_context_.scope());
    EXPECT_EQ(filter_config.status().code(), absl::StatusCode::kInvalidArgument);
    EXPECT_EQ(filter_config.status().message(),
              "Error encountered during config initialization. Invalid method name: "
              "'library.BookService.GetBook'. Method name should follow the gRPC format "
              "('/package.ServiceName/MethodName').");
  }

  {
    filter_config = ProtoApiScrubberFilterConfig::create(
        getConfigWithMethodName("/library_BookService/GetBook"), server_factory_context_,
        factory_context_.scope());
    EXPECT_EQ(filter_config.status().code(), absl::StatusCode::kInvalidArgument);
    EXPECT_EQ(filter_config.status().message(),
              "Error encountered during config initialization. Invalid method name: "
              "'/library_BookService/GetBook'. Method name should follow the gRPC format "
              "('/package.ServiceName/MethodName').");
  }

  {
    filter_config = ProtoApiScrubberFilterConfig::create(
        getConfigWithMethodName("/library/BookService/GetBook"), server_factory_context_,
        factory_context_.scope());
    EXPECT_EQ(filter_config.status().code(), absl::StatusCode::kInvalidArgument);
    EXPECT_EQ(filter_config.status().message(),
              "Error encountered during config initialization. Invalid method name: "
              "'/library/BookService/GetBook'. Method name should follow the gRPC format "
              "('/package.ServiceName/MethodName').");
  }

  {
    filter_config =
        ProtoApiScrubberFilterConfig::create(getConfigWithMethodName("/library.BookService/"),
                                             server_factory_context_, factory_context_.scope());
    EXPECT_EQ(filter_config.status().code(), absl::StatusCode::kInvalidArgument);
    EXPECT_EQ(filter_config.status().message(),
              "Error encountered during config initialization. Invalid method name: "
              "'/library.BookService/'. Method name should follow the gRPC format "
              "('/package.ServiceName/MethodName').");
  }

  {
    filter_config = ProtoApiScrubberFilterConfig::create(
        getConfigWithMethodName("/./GetBook"), server_factory_context_, factory_context_.scope());
    EXPECT_EQ(filter_config.status().code(), absl::StatusCode::kInvalidArgument);
    EXPECT_EQ(filter_config.status().message(),
              "Error encountered during config initialization. Invalid method name: '/./GetBook'. "
              "Method name should follow the gRPC format ('/package.ServiceName/MethodName').");
  }

  {
    // Valid format, but method does not exist in the loaded descriptor.
    filter_config = ProtoApiScrubberFilterConfig::create(
        getConfigWithMethodName("/library.BookService/GetBook"), server_factory_context_,
        factory_context_.scope());
    EXPECT_EQ(filter_config.status().code(), absl::StatusCode::kInvalidArgument);
    EXPECT_THAT(filter_config.status().message(),
                HasSubstr("The method is not found in the descriptor pool."));
  }

  {
    // Valid format and method exists in descriptor.
    filter_config = ProtoApiScrubberFilterConfig::create(
        getConfigWithMethodName("/apikeys.ApiKeys/CreateApiKey"), server_factory_context_,
        factory_context_.scope());
    EXPECT_EQ(filter_config.status().code(), absl::StatusCode::kOk);
    EXPECT_EQ(filter_config.status().message(), "");
  }
}

TEST_F(ProtoApiScrubberFilterConfigTest, FieldMaskValidations) {
  absl::StatusOr<std::shared_ptr<const ProtoApiScrubberFilterConfig>> filter_config;

  {
    filter_config = ProtoApiScrubberFilterConfig::create(
        getConfigWithFieldMask(""), server_factory_context_, factory_context_.scope());
    EXPECT_EQ(filter_config.status().code(), absl::StatusCode::kInvalidArgument);
    EXPECT_EQ(filter_config.status().message(), "Error encountered during config initialization. "
                                                "Invalid field mask: ''. Field mask is empty.");
  }

  {
    filter_config = ProtoApiScrubberFilterConfig::create(
        getConfigWithFieldMask("*"), server_factory_context_, factory_context_.scope());
    EXPECT_EQ(filter_config.status().code(), absl::StatusCode::kInvalidArgument);
    EXPECT_EQ(filter_config.status().message(),
              "Error encountered during config initialization. Invalid field mask: '*'. Field mask "
              "contains '*' which is not supported.");
  }

  {
    filter_config = ProtoApiScrubberFilterConfig::create(
        getConfigWithFieldMask("book.*"), server_factory_context_, factory_context_.scope());
    EXPECT_EQ(filter_config.status().code(), absl::StatusCode::kInvalidArgument);
    EXPECT_EQ(filter_config.status().message(),
              "Error encountered during config initialization. Invalid field mask: 'book.*'. Field "
              "mask contains '*' which is not supported.");
  }

  {
    filter_config = ProtoApiScrubberFilterConfig::create(
        getConfigWithFieldMask("*.book"), server_factory_context_, factory_context_.scope());
    EXPECT_EQ(filter_config.status().code(), absl::StatusCode::kInvalidArgument);
    EXPECT_EQ(filter_config.status().message(),
              "Error encountered during config initialization. Invalid field mask: '*.book'. Field "
              "mask contains '*' which is not supported.");
  }

  {
    filter_config = ProtoApiScrubberFilterConfig::create(
        getConfigWithFieldMask("book"), server_factory_context_, factory_context_.scope());
    EXPECT_EQ(filter_config.status().code(), absl::StatusCode::kOk);
    EXPECT_EQ(filter_config.status().message(), "");
  }

  {
    filter_config =
        ProtoApiScrubberFilterConfig::create(getConfigWithFieldMask("book.inner_book"),
                                             server_factory_context_, factory_context_.scope());
    EXPECT_EQ(filter_config.status().code(), absl::StatusCode::kOk);
    EXPECT_EQ(filter_config.status().message(), "");
  }

  {
    filter_config =
        ProtoApiScrubberFilterConfig::create(getConfigWithFieldMask("book.inner_book.debug_info"),
                                             server_factory_context_, factory_context_.scope());
    EXPECT_EQ(filter_config.status().code(), absl::StatusCode::kOk);
    EXPECT_EQ(filter_config.status().message(), "");
  }
}

TEST_F(ProtoApiScrubberFilterConfigTest, FilteringModeValidations) {
  ProtoApiScrubberConfig proto_config;
  absl::StatusOr<std::shared_ptr<const ProtoApiScrubberFilterConfig>> filter_config;

  {
    ASSERT_TRUE(Protobuf::TextFormat::ParseFromString(R"pb(filtering_mode: 0)pb", &proto_config));
    *proto_config.mutable_descriptor_set()->mutable_data_source()->mutable_filename() =
        TestEnvironment::runfilesPath(kApiKeysDescriptorRelativePath);
    filter_config = ProtoApiScrubberFilterConfig::create(proto_config, server_factory_context_,
                                                         factory_context_.scope());
    EXPECT_EQ(filter_config.status().code(), absl::StatusCode::kOk);
    EXPECT_EQ(filter_config.status().message(), "");
    EXPECT_EQ(filter_config.value()->filteringMode(),
              FilteringMode::ProtoApiScrubberConfig_FilteringMode_OVERRIDE);
  }

  {
    ASSERT_TRUE(Protobuf::TextFormat::ParseFromString(R"pb(filtering_mode: 999)pb", &proto_config));
    *proto_config.mutable_descriptor_set()->mutable_data_source()->mutable_filename() =
        TestEnvironment::runfilesPath(kApiKeysDescriptorRelativePath);
    filter_config = ProtoApiScrubberFilterConfig::create(proto_config, server_factory_context_,
                                                         factory_context_.scope());
    EXPECT_EQ(filter_config.status().code(), absl::StatusCode::kInvalidArgument);
    EXPECT_EQ(filter_config.status().message(),
              "Error encountered during config initialization. Unsupported 'filtering_mode': .");
  }
}

TEST_F(ProtoApiScrubberFilterConfigTest, GetRequestType) {
  // 1. Initialize the config
  absl::StatusOr<std::shared_ptr<const ProtoApiScrubberFilterConfig>> config_or_status =
      ProtoApiScrubberFilterConfig::create(proto_config_, server_factory_context_,
                                           factory_context_.scope());
  ASSERT_EQ(config_or_status.status().code(), absl::StatusCode::kOk);
  filter_config_ = std::move(config_or_status.value());

  {
    // Case 1: Valid Method Name
    // The method name passed from headers usually has the format /Package.Service/Method
    std::string method_name = "/apikeys.ApiKeys/CreateApiKey";

    absl::StatusOr<const Protobuf::Type*> type_or_status =
        filter_config_->getRequestType(method_name);

    ASSERT_EQ(type_or_status.status().code(), absl::StatusCode::kOk);
    ASSERT_NE(type_or_status.value(), nullptr);

    // Verify the resolved input type is correct
    EXPECT_EQ(type_or_status.value()->name(), "apikeys.CreateApiKeyRequest");
  }

  {
    // Case 2: Invalid Method Name (Not in descriptor)
    std::string method_name = "/apikeys.ApiKeys/NonExistentMethod";

    absl::StatusOr<const Protobuf::Type*> type_or_status =
        filter_config_->getRequestType(method_name);

    EXPECT_EQ(type_or_status.status().code(), absl::StatusCode::kInvalidArgument);
    EXPECT_THAT(
        type_or_status.status().message(),
        HasSubstr("Method '/apikeys.ApiKeys/NonExistentMethod' not found in descriptor pool"));
  }
}

TEST_F(ProtoApiScrubberFilterConfigTest, GetResponseType) {
  // 1. Initialize the config
  absl::StatusOr<std::shared_ptr<const ProtoApiScrubberFilterConfig>> config_or_status =
      ProtoApiScrubberFilterConfig::create(proto_config_, server_factory_context_,
                                           factory_context_.scope());
  ASSERT_EQ(config_or_status.status().code(), absl::StatusCode::kOk);
  filter_config_ = std::move(config_or_status.value());

  {
    // Case 1: Valid Method Name
    // The method name passed from headers usually has the format /Package.Service/Method
    std::string method_name = "/apikeys.ApiKeys/CreateApiKey";

    absl::StatusOr<const Protobuf::Type*> type_or_status =
        filter_config_->getResponseType(method_name);

    ASSERT_EQ(type_or_status.status().code(), absl::StatusCode::kOk);
    ASSERT_NE(type_or_status.value(), nullptr);

    // Verify the resolved input type is correct
    EXPECT_EQ(type_or_status.value()->name(), "apikeys.ApiKey");
  }

  {
    // Case 2: Invalid Method Name (Not in descriptor)
    std::string method_name = "/apikeys.ApiKeys/NonExistentMethod";

    absl::StatusOr<const Protobuf::Type*> type_or_status =
        filter_config_->getResponseType(method_name);

    EXPECT_EQ(type_or_status.status().code(), absl::StatusCode::kInvalidArgument);
    EXPECT_THAT(
        type_or_status.status().message(),
        HasSubstr("Method '/apikeys.ApiKeys/NonExistentMethod' not found in descriptor pool"));
  }
}

// Tests that the type cache is correctly populated for descriptors with nested packages.
TEST_F(ProtoApiScrubberFilterConfigTest, PrecomputeTypeCacheWithNestedPackages) {
  const std::string package = "com.example.deeply.nested";
  const std::string service = "MyCriticalService";
  const std::string method = "ProcessData";
  const std::string input = "DataRequest";
  const std::string output = "DataResponse";

  // Create a config with the generic descriptor helper.
  ProtoApiScrubberConfig config;
  *config.mutable_descriptor_set()->mutable_data_source()->mutable_inline_bytes() =
      createGenericDescriptor(package, service, method, input, output);

  // Initialize the filter config (This triggers precomputeTypeCache).
  auto filter_config_or_status = ProtoApiScrubberFilterConfig::create(
      config, server_factory_context_, factory_context_.scope());
  ASSERT_THAT(filter_config_or_status, IsOk());
  auto filter_config = filter_config_or_status.value();

  // Construct the gRPC method path expected by the filter logic.
  // Format: /package.Service/Method
  std::string full_method_path = absl::StrCat("/", package, ".", service, "/", method);

  // Verify Request Type Lookup.
  {
    auto type_or_status = filter_config->getRequestType(full_method_path);
    ASSERT_THAT(type_or_status, IsOk());
    ASSERT_NE(type_or_status.value(), nullptr);
    // Fully qualified type name is package.TypeName
    EXPECT_EQ(type_or_status.value()->name(), absl::StrCat(package, ".", input));
  }

  // Verify Response Type Lookup.
  {
    auto type_or_status = filter_config->getResponseType(full_method_path);
    ASSERT_THAT(type_or_status, IsOk());
    ASSERT_NE(type_or_status.value(), nullptr);
    EXPECT_EQ(type_or_status.value()->name(), absl::StrCat(package, ".", output));
  }
}

// Tests that the type cache is correctly populated for descriptors defined at the root level (no
// package).
TEST_F(ProtoApiScrubberFilterConfigTest, PrecomputeTypeCacheNoPackage) {
  const std::string package = "";
  const std::string service = "RootService";
  const std::string method = "Ping";
  const std::string input = "PingReq";
  const std::string output = "PingRes";

  ProtoApiScrubberConfig config;
  *config.mutable_descriptor_set()->mutable_data_source()->mutable_inline_bytes() =
      createGenericDescriptor(package, service, method, input, output);

  auto filter_config_or_status = ProtoApiScrubberFilterConfig::create(
      config, server_factory_context_, factory_context_.scope());
  ASSERT_THAT(filter_config_or_status, IsOk());
  auto filter_config = filter_config_or_status.value();

  // If package is empty, path should be /Service/Method, not /.Service/Method
  std::string full_method_path = "/RootService/Ping";

  auto type_or_status = filter_config->getRequestType(full_method_path);
  ASSERT_THAT(type_or_status, IsOk());
  EXPECT_EQ(type_or_status.value()->name(), "PingReq");
}

// Tests handling of types defined with relative names (no leading dot) in the descriptor.
TEST_F(ProtoApiScrubberFilterConfigTest, PrecomputeCacheRelativeTypeNames) {
  std::string package = "rel.pkg";
  std::string service = "RelService";
  std::string method = "RelMethod";
  std::string input = "RelReq";
  std::string output = "RelResp";

  // Use helper but ensure it sets input_type/output_type exactly as passed strings
  // (which are relative names here).
  ProtoApiScrubberConfig config;
  *config.mutable_descriptor_set()->mutable_data_source()->mutable_inline_bytes() =
      createGenericDescriptor(package, service, method, input, output);

  auto filter_config_or_status = ProtoApiScrubberFilterConfig::create(
      config, server_factory_context_, factory_context_.scope());
  ASSERT_THAT(filter_config_or_status, IsOk());
  auto filter_config = filter_config_or_status.value();

  std::string full_method_path = "/rel.pkg.RelService/RelMethod";

  // Request Type.
  auto req_type = filter_config->getRequestType(full_method_path);
  ASSERT_THAT(req_type, IsOk());
  // The logic should have prepended "rel.pkg." to "RelReq".
  EXPECT_EQ(req_type.value()->name(), "rel.pkg.RelReq");

  // Response Type.
  auto resp_type = filter_config->getResponseType(full_method_path);
  ASSERT_THAT(resp_type, IsOk());
  // The logic should have prepended "rel.pkg." to "RelResp".
  EXPECT_EQ(resp_type.value()->name(), "rel.pkg.RelResp");
}

// Tests that appropriate errors are logged when types referenced by a method
// are missing from the descriptor pool.
TEST_F(ProtoApiScrubberFilterConfigTest, PrecomputeTypeCacheMissingTypes) {
  std::string package = "broken.pkg";
  std::string service = "BrokenService";
  std::string method = "BrokenMethod";
  std::string input = "MissingReq";
  std::string output = "MissingResp";

  // Create a descriptor that defines the service/method but NOT the message types.
  ProtoApiScrubberConfig config;
  *config.mutable_descriptor_set()->mutable_data_source()->mutable_inline_bytes() =
      createGenericDescriptor(package, service, method, input, output, /*define_messages=*/false);

  auto status_or_config = ProtoApiScrubberFilterConfig::create(config, server_factory_context_,
                                                               factory_context_.scope());

  // Expect failure because the descriptor pool builder will reject the file
  // due to missing dependency types.
  EXPECT_EQ(status_or_config.status().code(), absl::StatusCode::kInvalidArgument);
  EXPECT_THAT(
      status_or_config.status().message(),
      testing::HasSubstr(
          "Error occurred in file `generic_test.proto` while trying to build proto descriptors"));
}

TEST_F(ProtoApiScrubberFilterConfigTest, GetEnumName) {
  // Setup Config with the custom Enum descriptor
  ProtoApiScrubberConfig config;
  *config.mutable_descriptor_set()->mutable_data_source()->mutable_inline_bytes() =
      createDescriptorWithTestEnum();

  // Initialize filter config.
  auto filter_config_or_status = ProtoApiScrubberFilterConfig::create(
      config, server_factory_context_, factory_context_.scope());
  ASSERT_THAT(filter_config_or_status, IsOk());
  auto filter_config = filter_config_or_status.value();

  {
    // Case 1.1: Valid Lookup (Type and Value exist)
    auto result = filter_config->getEnumName("test.TestEnum", 1);
    ASSERT_THAT(result, IsOk());
    EXPECT_EQ(result.value(), "ACTIVE");
  }

  {
    // Case 1.2: Valid Lookup (Type and Value exist)
    auto result = filter_config->getEnumName("test.TestEnum", 0);
    ASSERT_THAT(result, IsOk());
    EXPECT_EQ(result.value(), "UNKNOWN");
  }

  {
    // Case 2: Invalid Value (Type exists, Value does not)
    auto result = filter_config->getEnumName("test.TestEnum", 999);
    EXPECT_THAT(result,
                HasStatus(absl::StatusCode::kNotFound,
                          HasSubstr("Enum value '999' not found in enum type 'test.TestEnum'")));
  }

  {
    // Case 3: Invalid Type Name (Type does not exist)
    auto result = filter_config->getEnumName("test.NonExistentEnum", 1);
    EXPECT_THAT(
        result,
        HasStatus(absl::StatusCode::kNotFound,
                  HasSubstr("Enum type 'test.NonExistentEnum' not found in descriptor pool")));
  }
}

TEST_F(ProtoApiScrubberFilterConfigTest, GetTypeFinder) {
  absl::StatusOr<std::shared_ptr<const ProtoApiScrubberFilterConfig>> config_or_status =
      ProtoApiScrubberFilterConfig::create(proto_config_, server_factory_context_,
                                           factory_context_.scope());
  ASSERT_EQ(config_or_status.status().code(), absl::StatusCode::kOk);
  filter_config_ = std::move(config_or_status.value());
  const auto& type_finder = filter_config_->getTypeFinder();

  {
    // Case 1: Resolve a known Type URL
    std::string valid_type_url = "type.googleapis.com/apikeys.CreateApiKeyRequest";
    const Protobuf::Type* type = type_finder(valid_type_url);

    ASSERT_NE(type, nullptr);
    EXPECT_EQ(type->name(), "apikeys.CreateApiKeyRequest");
  }

  {
    // Case 2: Resolve an unknown Type URL
    std::string invalid_type_url = "type.googleapis.com/apikeys.UnknownMessage";
    const Protobuf::Type* type = type_finder(invalid_type_url);

    EXPECT_EQ(type, nullptr);
  }
}

TEST_F(ProtoApiScrubberFilterConfigTest, ParseMessageRestrictions) {
  ProtoApiScrubberConfig proto_config = getConfigWithMessageRestrictions();
  auto filter_config_or_status = ProtoApiScrubberFilterConfig::create(
      proto_config, server_factory_context_, factory_context_.scope());
  ASSERT_THAT(filter_config_or_status, IsOk());
  filter_config_ = filter_config_or_status.value();
  ASSERT_NE(filter_config_, nullptr);

  NiceMock<StreamInfo::MockStreamInfo> mock_stream_info;
  Http::Matching::HttpMatchingDataImpl http_matching_data_impl(mock_stream_info);

  auto matcher1 = filter_config_->getMessageMatcher("package.MyMessage");
  ASSERT_NE(matcher1, nullptr);
  EXPECT_THAT(
      matcher1->match(http_matching_data_impl),
      HasActionWithType("envoy.extensions.filters.http.proto_api_scrubber.v3.RemoveFieldAction"));

  auto matcher2 = filter_config_->getMessageMatcher("another.package.OtherMessage");
  ASSERT_NE(matcher2, nullptr);
  EXPECT_THAT(matcher2->match(http_matching_data_impl), HasNoMatch());

  auto matcher3 = filter_config_->getMessageMatcher("non.existent.Message");
  EXPECT_EQ(matcher3, nullptr);
}

TEST_F(ProtoApiScrubberFilterConfigTest, ParseMessageFieldRestrictions) {
  ProtoApiScrubberConfig proto_config = getConfigWithMessageFieldRestrictions();
  auto filter_config_or_status = ProtoApiScrubberFilterConfig::create(
      proto_config, server_factory_context_, factory_context_.scope());
  ASSERT_THAT(filter_config_or_status, IsOk());
  filter_config_ = filter_config_or_status.value();
  ASSERT_NE(filter_config_, nullptr);

  NiceMock<StreamInfo::MockStreamInfo> mock_stream_info;
  Http::Matching::HttpMatchingDataImpl http_matching_data_impl(mock_stream_info);

  auto matcher1 = filter_config_->getMessageFieldMatcher("package.MyMessage", "sensitive_data");
  ASSERT_NE(matcher1, nullptr);
  EXPECT_THAT(
      matcher1->match(http_matching_data_impl),
      HasActionWithType("envoy.extensions.filters.http.proto_api_scrubber.v3.RemoveFieldAction"));

  auto matcher2 = filter_config_->getMessageFieldMatcher("package.MyMessage", "public_data");
  EXPECT_EQ(matcher2, nullptr);

  auto matcher3 = filter_config_->getMessageFieldMatcher("non.existent.Message", "any_field");
  EXPECT_EQ(matcher3, nullptr);
}

TEST_F(ProtoApiScrubberFilterConfigTest, ParseMethodLevelRestriction) {
  ProtoApiScrubberConfig proto_config = getConfigWithMethodLevelRestriction();
  auto filter_config_or_status = ProtoApiScrubberFilterConfig::create(
      proto_config, server_factory_context_, factory_context_.scope());
  ASSERT_THAT(filter_config_or_status, IsOk());
  filter_config_ = filter_config_or_status.value();
  ASSERT_NE(filter_config_, nullptr);

  NiceMock<StreamInfo::MockStreamInfo> mock_stream_info;
  Http::Matching::HttpMatchingDataImpl http_matching_data_impl(mock_stream_info);

  auto matcher1 = filter_config_->getMethodMatcher("/apikeys.ApiKeys/CreateApiKey");
  ASSERT_NE(matcher1, nullptr);
  EXPECT_THAT(
      matcher1->match(http_matching_data_impl),
      HasActionWithType("envoy.extensions.filters.http.proto_api_scrubber.v3.RemoveFieldAction"));

  auto matcher2 = filter_config_->getMethodMatcher("/non.existent.Service/Method");
  EXPECT_EQ(matcher2, nullptr);
}

TEST_F(ProtoApiScrubberFilterConfigTest, MessageNameValidations) {
  absl::StatusOr<std::shared_ptr<const ProtoApiScrubberFilterConfig>> filter_config;

  EXPECT_THAT(ProtoApiScrubberFilterConfig::create(
                  getConfigWithMessageName(""), server_factory_context_, factory_context_.scope()),
              HasStatus(absl::StatusCode::kInvalidArgument,
                        HasSubstr("Invalid message name: ''. Message name is empty.")));

  EXPECT_THAT(
      ProtoApiScrubberFilterConfig::create(getConfigWithMessageName("NoPackageMessage"),
                                           server_factory_context_, factory_context_.scope()),
      HasStatus(
          absl::StatusCode::kInvalidArgument,
          HasSubstr(
              "Invalid message name: 'NoPackageMessage'. Message name should be fully qualified")));
  EXPECT_THAT(
      ProtoApiScrubberFilterConfig::create(getConfigWithMessageName(".package.Message"),
                                           server_factory_context_, factory_context_.scope()),
      HasStatus(
          absl::StatusCode::kInvalidArgument,
          HasSubstr(
              "Invalid message name: '.package.Message'. Message name should be fully qualified")));
  EXPECT_THAT(
      ProtoApiScrubberFilterConfig::create(getConfigWithMessageName("package.Message."),
                                           server_factory_context_, factory_context_.scope()),
      HasStatus(
          absl::StatusCode::kInvalidArgument,
          HasSubstr(
              "Invalid message name: 'package.Message.'. Message name should be fully qualified")));
  EXPECT_THAT(
      ProtoApiScrubberFilterConfig::create(getConfigWithMessageName("package..Message"),
                                           server_factory_context_, factory_context_.scope()),
      HasStatus(
          absl::StatusCode::kInvalidArgument,
          HasSubstr(
              "Invalid message name: 'package..Message'. Message name should be fully qualified")));
  EXPECT_THAT(ProtoApiScrubberFilterConfig::create(getConfigWithMessageName("package.Message"),
                                                   server_factory_context_,
                                                   factory_context_.scope()),
              IsOk());
}

TEST_F(ProtoApiScrubberFilterConfigTest, UnsupportedActionType) {
  std::string filter_conf_string = R"pb(
    descriptor_set: {}
    restrictions: {
      method_restrictions: {
        key: "/apikeys.ApiKeys/CreateApiKey"
        value: {
          request_field_restrictions: {
            key: "debug_info"
            value: {
              matcher: {
                matcher_list: {
                  matchers: {
                    predicate: {
                      single_predicate: {
                        input: {
                          name: "request"
                          typed_config: {
                            [type.googleapis.com/xds.type.matcher.v3.HttpAttributesCelMatchInput] {}
                          }
                        }
                        custom_match: {
                           name: "cel"
                          typed_config: {
                            [type.googleapis.com/xds.type.matcher.v3.CelMatcher] {
                              expr_match: {
                                parsed_expr: { expr: { const_expr: { bool_value: true } } }
                              }
                            }
                          }
                        }
                      }
                    }
                    on_match: {
                      action: {
                        name: "some_unknown_action"
                        typed_config: {
                          # Using Google Protobuf Empty as a placeholder for an unknown action
                          [type.googleapis.com/google.protobuf.Empty] {}
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  )pb";
  ProtoApiScrubberConfig proto_config;
  std::ignore = Protobuf::TextFormat::ParseFromString(filter_conf_string, &proto_config);
  *proto_config.mutable_descriptor_set()->mutable_data_source()->mutable_inline_bytes() =
      api_->fileSystem()
          .fileReadToEnd(Envoy::TestEnvironment::runfilesPath(kApiKeysDescriptorRelativePath))
          .value();

  // Validate that creating the config throws an EnvoyException because the action
  // "some_unknown_action" is not registered.
  EXPECT_THAT_THROWS_MESSAGE(
      {
        auto _ = ProtoApiScrubberFilterConfig::create(proto_config, server_factory_context_,
                                                      factory_context_.scope());
      },
      EnvoyException,
      HasSubstr("Didn't find a registered implementation for 'some_unknown_action'"));
}

TEST_F(ProtoApiScrubberFilterConfigTest, FieldParentMapPopulation) {
  // Initialize config with the api keys descriptor.
  absl::StatusOr<std::shared_ptr<const ProtoApiScrubberFilterConfig>> config_or_status =
      ProtoApiScrubberFilterConfig::create(proto_config_, server_factory_context_,
                                           factory_context_.scope());
  ASSERT_EQ(config_or_status.status().code(), absl::StatusCode::kOk);
  filter_config_ = std::move(config_or_status.value());

  // Resolve a known message type (CreateApiKeyRequest).
  std::string type_url = "type.googleapis.com/apikeys.CreateApiKeyRequest";
  const Protobuf::Type* parent_type = filter_config_->getTypeFinder()(type_url);
  ASSERT_NE(parent_type, nullptr);

  // Find a field inside it (e.g., 'parent').
  const Protobuf::Field* parent_field = nullptr;
  for (const auto& field : parent_type->fields()) {
    if (field.name() == "parent") {
      parent_field = &field;
      break;
    }
  }
  ASSERT_NE(parent_field, nullptr);

  // Verify that getParentType returns the correct type for this field pointer.
  const Protobuf::Type* resolved_parent = filter_config_->getParentType(parent_field);
  ASSERT_NE(resolved_parent, nullptr);
  EXPECT_EQ(resolved_parent->name(), "apikeys.CreateApiKeyRequest");
  // Pointer equality check.
  EXPECT_EQ(resolved_parent, parent_type);

  // Verify negative case (unregistered field).
  Protobuf::Field dummy_field;
  EXPECT_EQ(filter_config_->getParentType(&dummy_field), nullptr);
}

// Verifies that identical matchers share the same pointer.
TEST_F(ProtoApiScrubberFilterConfigTest, MatcherDeduplication) {
  ProtoApiScrubberConfig config;
  *config.mutable_descriptor_set()->mutable_data_source()->mutable_inline_bytes() =
      api_->fileSystem()
          .fileReadToEnd(Envoy::TestEnvironment::runfilesPath(kApiKeysDescriptorRelativePath))
          .value();

  // Construct a shared Matcher configuration.
  xds::type::matcher::v3::Matcher matcher;
  auto* matcher_entry = matcher.mutable_matcher_list()->add_matchers();

  // Set Predicate (CEL: true).
  auto* single_predicate = matcher_entry->mutable_predicate()->mutable_single_predicate();
  single_predicate->mutable_input()->set_name("envoy.matching.inputs.cel_data_input");
  std::ignore = single_predicate->mutable_input()->mutable_typed_config()->PackFrom(
      xds::type::matcher::v3::HttpAttributesCelMatchInput());

  xds::type::matcher::v3::CelMatcher cel_matcher;
  cel_matcher.mutable_expr_match()
      ->mutable_parsed_expr()
      ->mutable_expr()
      ->mutable_const_expr()
      ->set_bool_value(true);
  std::ignore =
      single_predicate->mutable_custom_match()->mutable_typed_config()->PackFrom(cel_matcher);

  // Set Action (RemoveField).
  auto* action = matcher_entry->mutable_on_match()->mutable_action();
  action->set_name("remove");
  std::ignore = action->mutable_typed_config()->PackFrom(
      envoy::extensions::filters::http::proto_api_scrubber::v3::RemoveFieldAction());

  // Apply the same matcher to two different fields.
  auto& method_rules = (*config.mutable_restrictions()
                             ->mutable_method_restrictions())["/apikeys.ApiKeys/CreateApiKey"];
  *(*method_rules.mutable_request_field_restrictions())["field_a"].mutable_matcher() = matcher;
  *(*method_rules.mutable_request_field_restrictions())["field_b"].mutable_matcher() = matcher;

  auto config_or_status = ProtoApiScrubberFilterConfig::create(config, server_factory_context_,
                                                               factory_context_.scope());
  ASSERT_THAT(config_or_status, IsOk());
  filter_config_ = std::move(config_or_status.value());

  auto matcher_a =
      filter_config_->getRequestFieldMatcher("/apikeys.ApiKeys/CreateApiKey", "field_a");
  auto matcher_b =
      filter_config_->getRequestFieldMatcher("/apikeys.ApiKeys/CreateApiKey", "field_b");

  ASSERT_NE(matcher_a, nullptr);
  ASSERT_NE(matcher_b, nullptr);

  // Verify pointers are identical.
  EXPECT_EQ(matcher_a.get(), matcher_b.get());
}

} // namespace
} // namespace ProtoApiScrubber
} // namespace HttpFilters
} // namespace Extensions
} // namespace Envoy
