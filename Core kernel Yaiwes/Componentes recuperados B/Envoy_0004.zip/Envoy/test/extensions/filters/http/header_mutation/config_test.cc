#include "envoy/registry/registry.h"

#include "source/common/config/utility.h"
#include "source/extensions/filters/http/header_mutation/config.h"

#include "test/mocks/http/mocks.h"
#include "test/mocks/server/factory_context.h"
#include "test/test_common/status_utility.h"
#include "test/test_common/utility.h"

#include "gtest/gtest.h"

namespace Envoy {
namespace Extensions {
namespace HttpFilters {
namespace HeaderMutation {
namespace {

using ::Envoy::StatusHelpers::HasStatusMessage;

TEST(FactoryTest, FactoryTest) {
  testing::NiceMock<Server::Configuration::MockFactoryContext> mock_factory_context;
  auto* factory =
      Registry::FactoryRegistry<Server::Configuration::NamedHttpFilterConfigFactory>::getFactory(
          "envoy.filters.http.header_mutation");
  ASSERT_NE(factory, nullptr);

  {
    const std::string config = R"EOF(
  mutations:
    request_mutations:
    - remove: "flag-header"
    - append:
        header:
          key: "flag-header"
          value: "%REQ(ANOTHER-FLAG-HEADER)%"
        append_action: APPEND_IF_EXISTS_OR_ADD
    query_parameter_mutations:
    - remove: "flag-query"
    - append:
        record:
          key: "flag-query"
          value: "%REQ(ANOTHER-FLAG-QUERY)%"
        action: APPEND_IF_EXISTS_OR_ADD
    response_mutations:
    - remove: "flag-header"
    - append:
        header:
          key: "flag-header"
          value: "%REQ(ANOTHER-FLAG-HEADER)%"
        append_action: APPEND_IF_EXISTS_OR_ADD
    request_trailers_mutations:
    - remove: "request-trailer"
    - append:
        header:
          key: "request-trailer"
          value: "value"
        append_action: "APPEND_IF_EXISTS_OR_ADD"
    response_trailers_mutations:
    - remove: "flag-trailer"
    - append:
        header:
          key: "flag-trailer"
          value: "hardcoded-value"
        append_action: "APPEND_IF_EXISTS_OR_ADD"
  )EOF";

    PerRouteProtoConfig per_route_proto_config;
    TestUtility::loadFromYaml(config, per_route_proto_config);
    ProtoConfig proto_config;
    TestUtility::loadFromYaml(config, proto_config);

    auto cb =
        factory->createFilterFactoryFromProto(proto_config, "test", mock_factory_context).value();
    Http::MockFilterChainFactoryCallbacks filter_callbacks;
    EXPECT_CALL(filter_callbacks, addStreamFilter(_));
    cb(filter_callbacks);

    EXPECT_NE(nullptr, factory
                           ->createRouteSpecificFilterConfig(
                               per_route_proto_config, mock_factory_context.server_factory_context_,
                               mock_factory_context.messageValidationVisitor())
                           .value());
  }

  {
    const std::string config = R"EOF(
  mutations:
    query_parameter_mutations:
    - remove: ""
  )EOF";

    ProtoConfig proto_config;
    TestUtility::loadFromYaml(config, proto_config);

    auto cb_or_error =
        factory->createFilterFactoryFromProto(proto_config, "test", mock_factory_context);
    EXPECT_THAT(cb_or_error, HasStatusMessage("One of 'append'/'remove' must be specified."));
  }

  {
    const std::string config = R"EOF(
  mutations:
    query_parameter_mutations:
    - remove: "another-key"
      append:
        record:
          key: "key"
          value: "value"
  )EOF";

    ProtoConfig proto_config;
    TestUtility::loadFromYaml(config, proto_config);

    auto cb_or_error =
        factory->createFilterFactoryFromProto(proto_config, "test", mock_factory_context);
    EXPECT_THAT(cb_or_error, HasStatusMessage("Only one of 'append'/'remove can be specified."));
  }

  {
    const std::string config = R"EOF(
  mutations:
    query_parameter_mutations:
    - append: {}
  )EOF";

    ProtoConfig proto_config;
    TestUtility::loadFromYaml(config, proto_config);

    auto cb_or_error =
        factory->createFilterFactoryFromProto(proto_config, "test", mock_factory_context);
    EXPECT_THAT(cb_or_error, HasStatusMessage("No record specified for append mutation."));
  }
  {
    const std::string config = R"EOF(
  mutations:
    query_parameter_mutations:
    - append:
        record:
          key: "key"
          value: 123
  )EOF";

    ProtoConfig proto_config;
    TestUtility::loadFromYaml(config, proto_config);

    auto cb_or_error =
        factory->createFilterFactoryFromProto(proto_config, "test", mock_factory_context);
    EXPECT_THAT(cb_or_error, HasStatusMessage("Only string value is allowed for record value."));
  }
  {
    const std::string config = R"EOF(
  mutations:
    query_parameter_mutations:
    - append:
        record:
          key: "key"
  )EOF";

    ProtoConfig proto_config;
    TestUtility::loadFromYaml(config, proto_config);

    auto cb_or_error =
        factory->createFilterFactoryFromProto(proto_config, "test", mock_factory_context);
    EXPECT_THAT(cb_or_error, HasStatusMessage("Only string value is allowed for record value."));
  }
}

TEST(FactoryTest, UpstreamFactoryTest) {
  auto* factory =
      Registry::FactoryRegistry<Server::Configuration::UpstreamHttpFilterConfigFactory>::getFactory(
          "envoy.filters.http.header_mutation");
  ASSERT_NE(factory, nullptr);
}

TEST(FactoryTest, QueryParameterMutationsTest) {

  testing::NiceMock<Server::Configuration::MockFactoryContext> context;

  auto* factory =
      Registry::FactoryRegistry<Server::Configuration::NamedHttpFilterConfigFactory>::getFactory(
          "envoy.filters.http.header_mutation");
  ASSERT_NE(factory, nullptr);
}

TEST(FactoryTest, FactoryTestWithServerContext) {
  testing::NiceMock<Server::Configuration::MockServerFactoryContext> mock_server_context;
  auto* factory =
      Registry::FactoryRegistry<Server::Configuration::NamedHttpFilterConfigFactory>::getFactory(
          "envoy.filters.http.header_mutation");
  ASSERT_NE(factory, nullptr);

  const std::string config = R"EOF(
  mutations:
    request_mutations:
    - remove: "flag-header"
    - append:
        header:
          key: "flag-header"
          value: "%REQ(ANOTHER-FLAG-HEADER)%"
        append_action: APPEND_IF_EXISTS_OR_ADD
  )EOF";

  ProtoConfig proto_config;
  TestUtility::loadFromYaml(config, proto_config);

  // The typed createHttpFilterFactoryFromProto overload is only visible on the concrete factory
  // type (the base NamedHttpFilterConfigFactory pointer exposes only the Protobuf::Message
  // overload, which routes through the legacy path).
  HeaderMutationFactoryConfig header_mutation_factory;
  Server::Configuration::ExtraFactoryContext extra_context{
      mock_server_context.messageValidationVisitor(), "test"};
  auto cb = header_mutation_factory
                .createHttpFilterFactoryFromProto(proto_config, mock_server_context, extra_context)
                .value();
  Http::MockFilterChainFactoryCallbacks filter_callbacks;
  EXPECT_CALL(filter_callbacks, addStreamFilter(_));
  cb(filter_callbacks);
}

} // namespace
} // namespace HeaderMutation
} // namespace HttpFilters
} // namespace Extensions
} // namespace Envoy
