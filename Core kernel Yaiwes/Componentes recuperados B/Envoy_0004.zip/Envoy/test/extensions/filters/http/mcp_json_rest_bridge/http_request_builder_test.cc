#include "source/extensions/filters/http/mcp_json_rest_bridge/http_request_builder.h"

#include "test/test_common/status_utility.h"
#include "test/test_common/utility.h"

#include "gtest/gtest.h"

namespace Envoy {
namespace Extensions {
namespace HttpFilters {
namespace McpJsonRestBridge {
namespace {

using ::envoy::extensions::filters::http::mcp_json_rest_bridge::v3::HttpRule;
using ::Envoy::StatusHelpers::HasStatus;
using ::Envoy::StatusHelpers::StatusIs;
using ::nlohmann::json;
using ::testing::StrEq;

TEST(HttpRequestBuilderTest, WildCardHttpRuleBodyContainsAllArgumentsNotInPath) {
  HttpRule http_rule;
  TestUtility::loadFromYaml(R"yaml(
get: "/v1/{parent=projects/*}"
body: "*"
)yaml",
                            http_rule);

  json arguments = json::parse(R"json({
    "shelf": {
      "name": "science-fiction",
      "code": 3,
      "content": "Some random content",
      "active": true,
      "editions": ["kindle", "hardback", "audobook"],
      "authors": [
        {"name": "author1"},
        {"name": "author2"}
      ]
    },
    "parent": "projects/123456789",
    "theme": "Kids"
  })json");

  BridgeStatus status = BridgeStatus::Ok;
  absl::StatusOr<HttpRequest> http_request = buildHttpRequest(http_rule, arguments, status);
  ASSERT_OK(http_request);
  EXPECT_EQ(status, BridgeStatus::Ok);

  EXPECT_THAT(http_request->url, StrEq("/v1/projects/123456789"));
  EXPECT_THAT(http_request->method, StrEq("GET"));
  EXPECT_EQ(http_request->body, json::parse(R"json({
              "shelf": {
                "name": "science-fiction",
                "code": 3,
                "content": "Some random content",
                "active": true,
                "editions": ["kindle", "hardback", "audobook"],
                "authors": [
                  {"name": "author1"},
                  {"name": "author2"}
                ]
              },
              "theme": "Kids"
            })json"));
}

TEST(HttpRequestBuilderTest, ExtractHttpRuleBody) {
  HttpRule http_rule;
  TestUtility::loadFromYaml(R"yaml(
post: "/v1/{parent=projects/*}"
body: "shelf"
)yaml",
                            http_rule);

  json arguments = json::parse(R"json({
    "shelf": {
      "name": "science-fiction",
      "code": 3,
      "content": "Some random content",
      "active": true,
      "editions": ["kindle", "hardback", "audobook"],
      "authors": [
        {"name": "author1"},
        {"name": "author2"}
      ]
    },
    "parent": "projects/123456789",
    "theme": "Kids"
  })json");

  BridgeStatus status = BridgeStatus::Ok;
  absl::StatusOr<HttpRequest> http_request = buildHttpRequest(http_rule, arguments, status);
  ASSERT_OK(http_request);
  EXPECT_EQ(status, BridgeStatus::Ok);

  EXPECT_THAT(http_request->url, StrEq("/v1/projects/123456789?theme=Kids"));
  EXPECT_THAT(http_request->method, StrEq("POST"));
  EXPECT_EQ(http_request->body, json::parse(R"json({
              "name": "science-fiction",
              "code": 3,
              "content": "Some random content",
              "active": true,
              "editions": ["kindle", "hardback", "audobook"],
              "authors": [
                {"name": "author1"},
                {"name": "author2"}
              ]
            })json"));
}

TEST(HttpRequestBuilderTest, PrimitiveArrayInQueryParameters) {
  HttpRule http_rule;
  TestUtility::loadFromYaml(R"yaml(
put: "/v1/{parent=projects/*}/shelves/{shelf.name}"
)yaml",
                            http_rule);
  json arguments = json::parse(R"json({
    "shelf": {
      "name": "science-fiction",
      "editions": ["kindle", "hardback", "audobook"]
    },
    "parent": "projects/123456789"
  })json");

  BridgeStatus status = BridgeStatus::Ok;
  absl::StatusOr<HttpRequest> http_request = buildHttpRequest(http_rule, arguments, status);
  ASSERT_OK(http_request);
  EXPECT_EQ(status, BridgeStatus::Ok);

  EXPECT_THAT(
      http_request->url,
      StrEq(
          "/v1/projects/123456789/shelves/"
          "science-fiction?shelf.editions=kindle&shelf.editions=hardback&shelf.editions=audobook"));
  EXPECT_THAT(http_request->method, StrEq("PUT"));
  EXPECT_TRUE(http_request->body.is_null());
}

TEST(HttpRequestBuilderTest, ObjectArrayInQueryParameters) {
  HttpRule http_rule;
  TestUtility::loadFromYaml(R"yaml(
patch: "/v1/{parent=projects/*}/shelves/{shelf.name}"
)yaml",
                            http_rule);
  json arguments = json::parse(R"json({
    "shelf": {
      "name": "science-fiction",
      "authors": [
        {"name": "author1"},
        {"name": "author2"}
      ]
    },
    "parent": "projects/123456789"
  })json");

  BridgeStatus status = BridgeStatus::Ok;
  absl::StatusOr<HttpRequest> http_request = buildHttpRequest(http_rule, arguments, status);
  ASSERT_OK(http_request);
  EXPECT_EQ(status, BridgeStatus::Ok);

  EXPECT_THAT(http_request->url,
              StrEq("/v1/projects/123456789/shelves/"
                    "science-fiction?shelf.authors.name=author1&shelf.authors.name=author2"));
  EXPECT_THAT(http_request->method, StrEq("PATCH"));
  EXPECT_TRUE(http_request->body.is_null());
}

TEST(HttpRequestBuilderTest, PrimitiveTypeInQueryParameters) {
  HttpRule http_rule;
  TestUtility::loadFromYaml(R"yaml(
delete: "/v1/{parent=projects/*}"
)yaml",
                            http_rule);
  json arguments = json::parse(R"json({
    "integer": 123,
    "float": 123.456,
    "boolean": true,
    "null": null,
    "string": "test string",
    "parent": "projects/123456789"
  })json");

  BridgeStatus status = BridgeStatus::Ok;
  absl::StatusOr<HttpRequest> http_request = buildHttpRequest(http_rule, arguments, status);
  ASSERT_OK(http_request);
  EXPECT_EQ(status, BridgeStatus::Ok);

  EXPECT_THAT(http_request->url, StrEq("/v1/projects/123456789?boolean=true&float=123.456&"
                                       "integer=123&null=null&string=test%20string"));
  EXPECT_THAT(http_request->method, StrEq("DELETE"));
  EXPECT_TRUE(http_request->body.is_null());
}

TEST(HttpRequestBuilderTest, NestedPathInPathTemplate) {
  HttpRule http_rule;
  TestUtility::loadFromYaml(R"yaml(
get: "/v1/{parent=projects/*}/shelves/{shelf.name}"
body: "*"
)yaml",
                            http_rule);
  json arguments = json::parse(R"json({
    "shelf": {
      "name": "science-fiction",
      "editions": ["kindle", "hardback", "audobook"]
    },
    "parent": "projects/123456789",
    "theme": "Kids"
  })json");

  BridgeStatus status = BridgeStatus::Ok;
  absl::StatusOr<HttpRequest> http_request = buildHttpRequest(http_rule, arguments, status);
  ASSERT_OK(http_request);
  EXPECT_EQ(status, BridgeStatus::Ok);

  EXPECT_THAT(http_request->url, StrEq("/v1/projects/123456789/shelves/science-fiction"));
  EXPECT_THAT(http_request->method, StrEq("GET"));
  EXPECT_EQ(http_request->body, json::parse(R"json({
              "shelf": {
                "editions": ["kindle", "hardback", "audobook"]
              },
              "theme": "Kids"
            })json"));
}

// Regression for https://github.com/envoyproxy/envoy/issues/45931: a "simple" path-template
// variable such as {id} must not be able to inject '..' path-traversal segments into the
// constructed upstream path. Before the fix this returned "/v1/users/../../admin/secrets/profile".
TEST(HttpRequestBuilderTest, ConstructBaseUrlSimpleVariableRejectsPathTraversal) {
  json arguments = json::parse(R"json({"id": "../../admin/secrets"})json");
  BridgeStatus status = BridgeStatus::Ok;
  EXPECT_THAT(constructBaseUrl("/v1/users/{id}/profile", {"id"}, arguments, status),
              HasStatus(absl::StatusCode::kInvalidArgument,
                        "path template variable 'id' must not contain path traversal segments"));
  EXPECT_EQ(status, BridgeStatus::RequestToolsCallPathTraversalRejected);
}

// A simple variable's '/' is confined to a single segment (percent-encoded), not treated as a
// path separator that could bypass the intended route prefix.
TEST(HttpRequestBuilderTest, ConstructBaseUrlSimpleVariableEncodesSlash) {
  json arguments = json::parse(R"json({"id": "a/b"})json");
  BridgeStatus status = BridgeStatus::Ok;
  absl::StatusOr<std::string> url =
      constructBaseUrl("/v1/users/{id}/profile", {"id"}, arguments, status);
  ASSERT_TRUE(url.ok());
  EXPECT_EQ(status, BridgeStatus::Ok);
  EXPECT_THAT(*url, StrEq("/v1/users/a%2Fb/profile"));
}

// A benign single-segment value still substitutes unchanged.
TEST(HttpRequestBuilderTest, ConstructBaseUrlSimpleVariableAllowsSingleSegment) {
  json arguments = json::parse(R"json({"id": "alice"})json");
  BridgeStatus status = BridgeStatus::Ok;
  absl::StatusOr<std::string> url =
      constructBaseUrl("/v1/users/{id}/profile", {"id"}, arguments, status);
  ASSERT_TRUE(url.ok());
  EXPECT_EQ(status, BridgeStatus::Ok);
  EXPECT_THAT(*url, StrEq("/v1/users/alice/profile"));
}

// A wildcard variable ({var=pattern}) may legitimately span multiple segments, so its '/' is
// preserved and left as the operator's explicit choice.
TEST(HttpRequestBuilderTest, ConstructBaseUrlWildcardVariablePreservesSlash) {
  json arguments = json::parse(R"json({"parent": "projects/123456789"})json");
  BridgeStatus status = BridgeStatus::Ok;
  absl::StatusOr<std::string> url =
      constructBaseUrl("/v1/{parent=projects/*}/shelves", {"parent"}, arguments, status);
  ASSERT_TRUE(url.ok());
  EXPECT_EQ(status, BridgeStatus::Ok);
  EXPECT_THAT(*url, StrEq("/v1/projects/123456789/shelves"));
}

// #45931 defense-in-depth: a '..' traversal segment is rejected even for a wildcard variable, whose
// value is equally attacker-controlled. Before the broadened check this produced
// "/v1/../../admin/secrets/shelves".
TEST(HttpRequestBuilderTest, ConstructBaseUrlWildcardVariableRejectsPathTraversal) {
  json arguments = json::parse(R"json({"name": "../../admin/secrets"})json");
  BridgeStatus status = BridgeStatus::Ok;
  EXPECT_THAT(constructBaseUrl("/v1/{name=projects/*}/shelves", {"name"}, arguments, status),
              HasStatus(absl::StatusCode::kInvalidArgument,
                        "path template variable 'name' must not contain path traversal segments"));
  EXPECT_EQ(status, BridgeStatus::RequestToolsCallPathTraversalRejected);
}

// '\' is percent-encoded to %5C rather than reaching the upstream literally, but an upstream that
// decodes it and folds it to '/' would still see a traversal, so '\' is treated as a segment
// separator by the check as well.
TEST(HttpRequestBuilderTest, ConstructBaseUrlRejectsBackslashPathTraversal) {
  json arguments = json::parse(R"json({"id": "..\\.."})json");
  BridgeStatus status = BridgeStatus::Ok;
  EXPECT_THAT(constructBaseUrl("/v1/users/{id}/profile", {"id"}, arguments, status),
              HasStatus(absl::StatusCode::kInvalidArgument,
                        "path template variable 'id' must not contain path traversal segments"));
  EXPECT_EQ(status, BridgeStatus::RequestToolsCallPathTraversalRejected);
}

// A backslash that is not a traversal segment is still allowed through, percent-encoded.
TEST(HttpRequestBuilderTest, ConstructBaseUrlEncodesNonTraversalBackslash) {
  json arguments = json::parse(R"json({"id": "a\\b"})json");
  BridgeStatus status = BridgeStatus::Ok;
  absl::StatusOr<std::string> url =
      constructBaseUrl("/v1/users/{id}/profile", {"id"}, arguments, status);
  ASSERT_TRUE(url.ok());
  EXPECT_EQ(status, BridgeStatus::Ok);
  EXPECT_THAT(*url, StrEq("/v1/users/a%5Cb/profile"));
}

TEST(HttpRequestBuilderTest, PathTemplateNotInArgumentsReturnError) {
  HttpRule http_rule;
  TestUtility::loadFromYaml(R"yaml(
get: "/v1/{parent=projects/*}"
)yaml",
                            http_rule);
  json arguments = json::parse(R"json({
    "string": "test string"
  })json");

  BridgeStatus status = BridgeStatus::Ok;
  EXPECT_THAT(
      buildHttpRequest(http_rule, arguments, status),
      HasStatus(absl::StatusCode::kInvalidArgument, "Could not find value for path: parent"));
  EXPECT_EQ(status, BridgeStatus::RequestToolsCallMissingRequiredArg);
}

TEST(HttpRequestBuilderTest, FailToExtractBodyReturnError) {
  HttpRule http_rule;
  TestUtility::loadFromYaml(R"yaml(
get: "/v1"
body: "foo"
)yaml",
                            http_rule);
  json arguments = json::parse(R"json({})json");

  BridgeStatus status = BridgeStatus::Ok;
  EXPECT_THAT(buildHttpRequest(http_rule, arguments, status),
              HasStatus(absl::StatusCode::kInvalidArgument, "Could not find value for path: foo"));
  EXPECT_EQ(status, BridgeStatus::RequestToolsCallMissingRequiredArg);
}

TEST(HttpRequestBuilderTest, UnsupportedHttpMethodReturnInvalidHttpRuleError) {
  HttpRule http_rule;
  json arguments = json::parse(R"json({})json");

  BridgeStatus status = BridgeStatus::Ok;
  EXPECT_THAT(buildHttpRequest(http_rule, arguments, status),
              HasStatus(absl::StatusCode::kInvalidArgument, "HttpRule is malformed"));
  EXPECT_EQ(status, BridgeStatus::InternalToolsCallInvalidHttpRule);
}

TEST(HttpRequestBuilderTest, ConstructBaseUrlTest) {
  json arguments = json::parse(R"json({
    "parent": "projects/123456789",
    "tableId": "table_A",
    "datasetId": "dataset_B",
    "projectId": "project_C"
  })json");

  BridgeStatus status = BridgeStatus::Ok;
  // Single substitution.
  EXPECT_THAT(*constructBaseUrl("/v1/{parent=projects/*}", {"parent"}, arguments, status),
              StrEq("/v1/projects/123456789"));
  EXPECT_EQ(status, BridgeStatus::Ok);

  // Multiple substitutions.
  EXPECT_THAT(*constructBaseUrl(
                  "/test/v2/projects/{projectId}/datasets/{datasetId}/tables/{tableId}/insertAll",
                  {"projectId", "datasetId", "tableId"}, arguments, status),
              StrEq("/test/v2/projects/project_C/datasets/dataset_B/tables/table_A/insertAll"));
  EXPECT_EQ(status, BridgeStatus::Ok);

  // Missing argument.
  EXPECT_THAT(
      constructBaseUrl("/v1/{missing}", {"missing"}, arguments, status),
      HasStatus(absl::StatusCode::kInvalidArgument, "Could not find value for path: missing"));
  EXPECT_EQ(status, BridgeStatus::RequestToolsCallMissingRequiredArg);
}

// Substitution matches a whole `{name}` or `{name=pattern}` and nothing else. These cases pin the
// boundaries that the previous `\{name(?:=[^}]+)?\}` regex enforced.
TEST(HttpRequestBuilderTest, ConstructBaseUrlVariableMatchingIsExact) {
  json arguments = json::parse(R"json({"id": "7"})json");

  BridgeStatus status = BridgeStatus::Ok;
  // A longer name that merely starts with the variable name is left alone.
  EXPECT_THAT(*constructBaseUrl("/v1/{identifier}/{id}", {"id"}, arguments, status),
              StrEq("/v1/{identifier}/7"));
  EXPECT_EQ(status, BridgeStatus::Ok);

  // An explicit pattern needs at least one character, so `{id=}` is not a variable.
  EXPECT_THAT(*constructBaseUrl("/v1/{id=}", {"id"}, arguments, status), StrEq("/v1/{id=}"));
  EXPECT_EQ(status, BridgeStatus::Ok);

  // Every occurrence is substituted, not just the first.
  EXPECT_THAT(*constructBaseUrl("/v1/{id}/copy/{id}", {"id"}, arguments, status),
              StrEq("/v1/7/copy/7"));
  EXPECT_EQ(status, BridgeStatus::Ok);
}

TEST(HttpRequestBuilderTest, ConstructQueryParamsNestingDepthLimit) {
  HttpRule http_rule;
  TestUtility::loadFromYaml(R"yaml(
get: "/v1"
)yaml",
                            http_rule);

  json arguments = json::object();
  json* current = &arguments;
  for (int i = 0; i < 150; ++i) {
    (*current)["a"] = json::object();
    current = &((*current)["a"]);
  }

  BridgeStatus status = BridgeStatus::Ok;
  EXPECT_THAT(buildHttpRequest(http_rule, arguments, status),
              StatusIs(absl::StatusCode::kInvalidArgument));
  EXPECT_EQ(status, BridgeStatus::RequestToolsCallMissingRequiredArg);
}

TEST(HttpRequestBuilderTest, ConstructQueryParamsArrayNestingDepthLimit) {
  HttpRule http_rule;
  TestUtility::loadFromYaml(R"yaml(
get: "/v1"
)yaml",
                            http_rule);

  json arguments = json::array();
  json* current = &arguments;
  for (int i = 0; i < 150; ++i) {
    current->push_back(json::array());
    current = &((*current)[0]);
  }

  BridgeStatus status = BridgeStatus::Ok;
  EXPECT_THAT(buildHttpRequest(http_rule, arguments, status),
              StatusIs(absl::StatusCode::kInvalidArgument));
  EXPECT_EQ(status, BridgeStatus::RequestToolsCallMissingRequiredArg);
}

} // namespace
} // namespace McpJsonRestBridge
} // namespace HttpFilters
} // namespace Extensions
} // namespace Envoy
