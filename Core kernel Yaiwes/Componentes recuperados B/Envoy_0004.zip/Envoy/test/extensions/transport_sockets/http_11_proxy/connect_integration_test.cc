#include "envoy/config/common/key_value/v3/config.pb.h"
#include "envoy/config/core/v3/base.pb.h"
#include "envoy/config/core/v3/health_check.pb.h"
#include "envoy/extensions/key_value/file_based/v3/config.pb.h"
#include "envoy/extensions/transport_sockets/http_11_proxy/v3/upstream_http_11_connect.pb.h"
#include "envoy/extensions/transport_sockets/raw_buffer/v3/raw_buffer.pb.h"

#include "source/common/network/utility.h"

#include "test/integration/http_integration.h"
#include "test/integration/integration.h"

namespace Envoy {
namespace {

class Http11ConnectHttpIntegrationTest : public testing::TestWithParam<Network::Address::IpVersion>,
                                         public HttpIntegrationTest {
public:
  Http11ConnectHttpIntegrationTest()
      : HttpIntegrationTest(Http::CodecClient::Type::HTTP1, GetParam()) {
    upstream_tls_ = true;
  }

  void TearDown() override {
    test_server_.reset();
    fake_upstream_connection_.reset();
    fake_upstreams_.clear();
  }

  void addDfpConfig() {
    const std::string filter =
        R"EOF(name: dynamic_forward_proxy
typed_config:
  "@type": type.googleapis.com/envoy.extensions.filters.http.dynamic_forward_proxy.v3.FilterConfig
  dns_cache_config:
    name: foo
    typed_dns_resolver_config:
      name: envoy.network.dns_resolver.getaddrinfo
      typed_config:
        "@type": type.googleapis.com/envoy.extensions.network.dns_resolver.getaddrinfo.v3.GetAddrInfoDnsResolverConfig
)EOF";
    config_helper_.prependFilter(filter);

    config_helper_.addConfigModifier([&](envoy::config::bootstrap::v3::Bootstrap& bootstrap) {
      auto* cluster = bootstrap.mutable_static_resources()->mutable_clusters(0);
      const std::string cluster_type_config =
          R"EOF(
name: envoy.clusters.dynamic_forward_proxy
typed_config:
  "@type": type.googleapis.com/envoy.extensions.clusters.dynamic_forward_proxy.v3.ClusterConfig
  dns_cache_config:
    name: foo
    typed_dns_resolver_config:
      name: envoy.network.dns_resolver.getaddrinfo
      typed_config:
        "@type": type.googleapis.com/envoy.extensions.network.dns_resolver.getaddrinfo.v3.GetAddrInfoDnsResolverConfig
)EOF";
      TestUtility::loadFromYaml(cluster_type_config, *cluster->mutable_cluster_type());
      cluster->clear_load_assignment();
      cluster->set_lb_policy(envoy::config::cluster::v3::Cluster::CLUSTER_PROVIDED);
    });
  }

  void initialize() override {
    TestEnvironment::writeStringToFileForTest("alt_svc_cache.txt", "");
    config_helper_.addFilter(R"EOF(
    name: header-to-proxy-filter
    typed_config:
      "@type": type.googleapis.com/test.integration.filters.HeaderToProxyFilterConfig
    )EOF");
    if (try_http3_) {
      envoy::config::core::v3::AlternateProtocolsCacheOptions alt_cache;
      alt_cache.set_name("default_alternate_protocols_cache");
      const std::string filename = TestEnvironment::temporaryPath("alt_svc_cache.txt");
      envoy::extensions::key_value::file_based::v3::FileBasedKeyValueStoreConfig config;
      config.set_filename(filename);
      config.mutable_flush_interval()->set_nanos(0);
      envoy::config::common::key_value::v3::KeyValueStoreConfig kv_config;
      kv_config.mutable_config()->set_name("envoy.key_value.file_based");
      std::ignore = kv_config.mutable_config()->mutable_typed_config()->PackFrom(config);
      alt_cache.mutable_key_value_store_config()->set_name("envoy.common.key_value");
      std::ignore =
          alt_cache.mutable_key_value_store_config()->mutable_typed_config()->PackFrom(kv_config);

      config_helper_.configureUpstreamTls(use_alpn_, try_http3_, alt_cache);
    } else if (upstream_tls_) {
      config_helper_.configureUpstreamTls(use_alpn_, try_http3_);
    }

    if (pre_create_upstreams_) {
      setUpstreamCount(0);
      config_helper_.skipPortUsageValidation();
      if (upstream_tls_) {
        addFakeUpstream(createUpstreamTlsContext(upstreamConfig()), upstreamProtocol(), false);
        addFakeUpstream(createUpstreamTlsContext(upstreamConfig()), upstreamProtocol(), false);
      } else {
        addFakeUpstream(upstreamProtocol());
        addFakeUpstream(upstreamProtocol());
      }
      fake_upstreams_[1]->setDisableAllAndDoNotEnable(true);
      default_proxy_address_ = fake_upstreams_[1]->localAddress();
    }

    config_helper_.addConfigModifier([&](envoy::config::bootstrap::v3::Bootstrap& bootstrap) {
      auto* transport_socket =
          bootstrap.mutable_static_resources()->mutable_clusters(0)->mutable_transport_socket();
      envoy::config::core::v3::TransportSocket inner_socket;
      inner_socket.CopyFrom(*transport_socket);
      if (set_inner_transport_socket_ && inner_socket.name().empty()) {
        inner_socket.set_name("envoy.transport_sockets.raw_buffer");
        envoy::extensions::transport_sockets::raw_buffer::v3::RawBuffer raw_buffer_config;
        std::ignore = inner_socket.mutable_typed_config()->PackFrom(raw_buffer_config);
      }
      transport_socket->set_name("envoy.transport_sockets.http_11_proxy");
      envoy::extensions::transport_sockets::http_11_proxy::v3::Http11ProxyUpstreamTransport
          transport;
      if (default_proxy_address_ != nullptr) {
        Network::Utility::addressToProtobufAddress(*default_proxy_address_,
                                                   *transport.mutable_default_proxy_address());
      }
      transport.mutable_transport_socket()->MergeFrom(inner_socket);
      std::ignore = transport_socket->mutable_typed_config()->PackFrom(transport);

      auto* cluster = bootstrap.mutable_static_resources()->mutable_clusters(0);

      ConfigHelper::HttpProtocolOptions protocol_options;
      protocol_options.mutable_upstream_http_protocol_options()->set_auto_sni(true);
      protocol_options.mutable_upstream_http_protocol_options()->set_auto_san_validation(true);
      if (upstream_tls_) {
        protocol_options.mutable_auto_config();
      } else {
        protocol_options.mutable_explicit_http_config()->mutable_http_protocol_options();
      }
      ConfigHelper::setProtocolOptions(*cluster, protocol_options);
    });
    BaseIntegrationTest::initialize();
    if (upstream_tls_) {
      addFakeUpstream(createUpstreamTlsContext(upstreamConfig()), upstreamProtocol(), false);
      addFakeUpstream(createUpstreamTlsContext(upstreamConfig()), upstreamProtocol(), false);
      // Read disable the fake upstreams, so we can rawRead rather than read data and decrypt.
      fake_upstreams_[1]->setDisableAllAndDoNotEnable(true);
      fake_upstreams_[2]->setDisableAllAndDoNotEnable(true);
    } else {
      addFakeUpstream(upstreamProtocol());
      addFakeUpstream(upstreamProtocol());
    }

    if (try_http3_) {
      uint32_t port = fake_upstreams_[0]->localAddress()->ip()->port();
      std::string key = absl::StrCat("https://sni.lyft.com:", port);

      size_t seconds = std::chrono::duration_cast<std::chrono::seconds>(
                           timeSystem().monotonicTime().time_since_epoch())
                           .count();
      std::string value = absl::StrCat("h3=\":", port, "\"; ma=", 86400 + seconds, "|0|0");
      TestEnvironment::writeStringToFileForTest(
          "alt_svc_cache.txt", absl::StrCat(key.length(), "\n", key, value.length(), "\n", value));
    }
  }

  void stripConnectUpgradeAndRespond(bool include_content_length = false) {
    // Strip the CONNECT upgrade - expect RFC 9110 compliant request with Host header.
    std::string prefix_data;
    const std::string hostname(default_request_headers_.getHostValue());
    const std::string port = Http::HeaderUtility::hostHasPort(hostname) ? "" : ":443";
    ASSERT_TRUE(fake_upstream_connection_->waitForInexactRawData("\r\n\r\n", prefix_data));

    // Verify the CONNECT request format is RFC 9110 compliant with Host header.
    std::string expected_connect = absl::StrCat("CONNECT ", hostname, port, " HTTP/1.1\r\n",
                                                "Host: ", hostname, port, "\r\n\r\n");
    EXPECT_EQ(expected_connect, prefix_data);

    absl::string_view content_length = include_content_length ? "Content-Length: 0\r\n" : "";
    // Ship the CONNECT response.
    fake_upstream_connection_->writeRawData(
        absl::StrCat("HTTP/1.1 200 OK\r\n", content_length, "\r\n"));
  }
  bool use_alpn_ = false;
  bool try_http3_ = false;

  // If true, we'll explicitly set the inner "transport_socket" field to raw buffer if it is not
  // configured.
  bool set_inner_transport_socket_ = true;

  bool pre_create_upstreams_ = false;
  Network::Address::InstanceConstSharedPtr default_proxy_address_;
};

INSTANTIATE_TEST_SUITE_P(IpVersions, Http11ConnectHttpIntegrationTest,
                         testing::ValuesIn(TestEnvironment::getIpVersionsForTest()),
                         TestUtility::ipTestParamsToString);

// Test that request/response is successful via plaintext if the inner transport socket is not set.
TEST_P(Http11ConnectHttpIntegrationTest, NoInnerTransportSocketSet) {
  set_inner_transport_socket_ = false;
  initialize();

  codec_client_ = makeHttpConnection(lookupPort("http"));
  auto response =
      sendRequestAndWaitForResponse(default_request_headers_, 0, default_response_headers_, 0);
  ASSERT_TRUE(response->complete());
  EXPECT_EQ("200", response->headers().getStatusValue());
}

// Test that with no connect-proxy header, the transport socket is a no-op.
TEST_P(Http11ConnectHttpIntegrationTest, NoHeader) {
  initialize();

  // With no connect-proxy header, the original request gets proxied to fake upstream 0.
  default_request_headers_.setCopy(Envoy::Http::LowerCaseString("foo"), "bar");
  default_response_headers_.setCopy(Envoy::Http::LowerCaseString("foo"), "bar");
  codec_client_ = makeHttpConnection(lookupPort("http"));
  auto response =
      sendRequestAndWaitForResponse(default_request_headers_, 0, default_response_headers_, 0);

  ASSERT_TRUE(response->complete());
  EXPECT_EQ("200", response->headers().getStatusValue());
  ASSERT_FALSE(upstream_request_->headers().get(Http::LowerCaseString("foo")).empty());
  ASSERT_FALSE(response->headers().get(Http::LowerCaseString("foo")).empty());

  // Second request reuses the connection.
  sendRequestAndWaitForResponse(default_request_headers_, 0, default_response_headers_, 0);
}

// If sending to an HTTP upstream, no CONNECT header will be appended but a
// fully qualified URL will be sent.
TEST_P(Http11ConnectHttpIntegrationTest, CleartextRequestResponse) {
  upstream_tls_ = false;
  initialize();

  // Point at the second fake upstream. Envoy doesn't actually know about this one.
  absl::string_view second_upstream_address(fake_upstreams_[1]->localAddress()->asStringView());
  codec_client_ = makeHttpConnection(lookupPort("http"));
  // The connect-proxy header will be stripped by the header-to-proxy-filter and inserted as
  // metadata.
  default_request_headers_.setCopy(Envoy::Http::LowerCaseString("connect-proxy"),
                                   second_upstream_address);
  auto response = codec_client_->makeHeaderOnlyRequest(default_request_headers_);

  // The request should be sent to fake upstream 1, due to the connect-proxy header.
  FakeRawConnectionPtr fake_upstream_raw_connection_;
  ASSERT_TRUE(fake_upstreams_[1]->waitForRawConnection(fake_upstream_raw_connection_));
  std::string observed_data;
  ASSERT_TRUE(fake_upstream_raw_connection_->waitForData(
      FakeRawConnection::waitForInexactMatch("\r\n\r\n"), &observed_data));
  // There should be no CONNECT header.
  EXPECT_FALSE(absl::StrContains(observed_data, "CONNECT"));
  // The proxied request should use a fully qualified URL.
  EXPECT_TRUE(absl::StrContains(observed_data, "GET http://sni.lyft.com/test/long/url HTTP/1.1"))
      << observed_data;
  EXPECT_TRUE(absl::StrContains(observed_data, "host: sni.lyft.com"));

  // Send a response.
  auto response2 = "HTTP/1.1 200 OK\r\ncontent-length: 0\r\nbar: eep\r\n\r\n";
  ASSERT_TRUE(fake_upstream_raw_connection_->write(response2, false));

  // Wait for the response to be received.
  ASSERT_TRUE(response->waitForEndStream());
  EXPECT_EQ("200", response->headers().getStatusValue());
  ASSERT_FALSE(response->headers().get(Http::LowerCaseString("bar")).empty());
}

// Test sending 2 requests to one proxy
TEST_P(Http11ConnectHttpIntegrationTest, TestMultipleRequestsSignleEndpoint) {
  initialize();

  // Point at the second fake upstream. Envoy doesn't actually know about this one.
  absl::string_view second_upstream_address(fake_upstreams_[1]->localAddress()->asStringView());
  codec_client_ = makeHttpConnection(lookupPort("http"));
  // The connect-proxy header will be stripped by the header-to-proxy-filter and inserted as
  // metadata.
  default_request_headers_.setCopy(Envoy::Http::LowerCaseString("connect-proxy"),
                                   second_upstream_address);
  auto response = codec_client_->makeHeaderOnlyRequest(default_request_headers_);

  // The request should be sent to fake upstream 1, due to the connect-proxy header.
  ASSERT_TRUE(fake_upstreams_[1]->waitForHttpConnection(*dispatcher_, fake_upstream_connection_));

  stripConnectUpgradeAndRespond();

  // Enable reading on the new stream, and read the encapsulated request.
  ASSERT_TRUE(fake_upstream_connection_->readDisable(false));
  ASSERT_TRUE(fake_upstream_connection_->waitForNewStream(*dispatcher_, upstream_request_));
  ASSERT_TRUE(upstream_request_->waitForEndStream(*dispatcher_));

  // Send the encapsulated response.
  default_response_headers_.setCopy(Envoy::Http::LowerCaseString("bar"), "eep");
  upstream_request_->encodeHeaders(default_response_headers_, true);

  // Wait for the encapsulated response to be received.
  ASSERT_TRUE(response->waitForEndStream());
  EXPECT_EQ("200", response->headers().getStatusValue());
  // Make sure the upgrade headers were swallowed and the second were received.
  ASSERT_FALSE(response->headers().get(Http::LowerCaseString("bar")).empty());

  // Now send a second request, and make sure it goes to the same upstream.
  response = codec_client_->makeHeaderOnlyRequest(default_request_headers_);

  // The request should be sent to fake upstream 2, due to the connect-proxy header.
  ASSERT_TRUE(fake_upstream_connection_->waitForNewStream(*dispatcher_, upstream_request_));
  ASSERT_TRUE(upstream_request_->waitForEndStream(*dispatcher_));
  upstream_request_->encodeHeaders(default_response_headers_, true);

  // Wait for the encapsulated response to be received.
  ASSERT_TRUE(response->waitForEndStream());
  EXPECT_EQ("200", response->headers().getStatusValue());
}

// Test sending requests to different proxies.
TEST_P(Http11ConnectHttpIntegrationTest, TestMultipleRequestsAndEndpoints) {
  initialize();

  // Point at the second fake upstream. Envoy doesn't actually know about this one.
  absl::string_view second_upstream_address(fake_upstreams_[1]->localAddress()->asStringView());
  codec_client_ = makeHttpConnection(lookupPort("http"));
  // The connect-proxy header will be stripped by the header-to-proxy-filter and inserted as
  // metadata.
  default_request_headers_.setCopy(Envoy::Http::LowerCaseString("connect-proxy"),
                                   second_upstream_address);
  auto response = codec_client_->makeHeaderOnlyRequest(default_request_headers_);

  // The request should be sent to fake upstream 1, due to the connect-proxy header.
  ASSERT_TRUE(fake_upstreams_[1]->waitForHttpConnection(*dispatcher_, fake_upstream_connection_));

  stripConnectUpgradeAndRespond();

  // Enable reading on the new stream, and read the encapsulated request.
  ASSERT_TRUE(fake_upstream_connection_->readDisable(false));
  ASSERT_TRUE(fake_upstream_connection_->waitForNewStream(*dispatcher_, upstream_request_));
  ASSERT_TRUE(upstream_request_->waitForEndStream(*dispatcher_));

  // Send the encapsulated response.
  default_response_headers_.setCopy(Envoy::Http::LowerCaseString("bar"), "eep");
  upstream_request_->encodeHeaders(default_response_headers_, true);

  // Wait for the encapsulated response to be received.
  ASSERT_TRUE(response->waitForEndStream());
  EXPECT_EQ("200", response->headers().getStatusValue());
  // Make sure the upgrade headers were swallowed and the second were received.
  ASSERT_FALSE(response->headers().get(Http::LowerCaseString("bar")).empty());

  // Now send a second request, and make sure it goes to upstream 2.
  absl::string_view third_upstream_address(fake_upstreams_[2]->localAddress()->asStringView());
  default_request_headers_.setCopy(Envoy::Http::LowerCaseString("connect-proxy"),
                                   third_upstream_address);
  response = codec_client_->makeHeaderOnlyRequest(default_request_headers_);

  // The request should be sent to fake upstream 2, due to the connect-proxy header.
  ASSERT_TRUE(fake_upstreams_[2]->waitForHttpConnection(*dispatcher_, fake_upstream_connection_));
  stripConnectUpgradeAndRespond();

  ASSERT_TRUE(fake_upstream_connection_->readDisable(false));
  ASSERT_TRUE(fake_upstream_connection_->waitForNewStream(*dispatcher_, upstream_request_));
  ASSERT_TRUE(upstream_request_->waitForEndStream(*dispatcher_));
  upstream_request_->encodeHeaders(default_response_headers_, true);

  // Wait for the encapsulated response to be received.
  ASSERT_TRUE(response->waitForEndStream());
  EXPECT_EQ("200", response->headers().getStatusValue());
}

// Test sending requests to different proxies.
TEST_P(Http11ConnectHttpIntegrationTest, TestMultipleRequestsSingleEndpoint) {
  // Also make sure that alpn negotiation works.
  use_alpn_ = true;
  initialize();

  // Point at the second fake upstream. Envoy doesn't actually know about this one.
  absl::string_view second_upstream_address(fake_upstreams_[1]->localAddress()->asStringView());
  codec_client_ = makeHttpConnection(lookupPort("http"));
  // The connect-proxy header will be stripped by the header-to-proxy-filter and inserted as
  // metadata.
  default_request_headers_.setCopy(Envoy::Http::LowerCaseString("connect-proxy"),
                                   second_upstream_address);
  auto response = codec_client_->makeHeaderOnlyRequest(default_request_headers_);

  // The request should be sent to fake upstream 1, due to the connect-proxy header.
  ASSERT_TRUE(fake_upstreams_[1]->waitForHttpConnection(*dispatcher_, fake_upstream_connection_));
  stripConnectUpgradeAndRespond();

  ASSERT_TRUE(fake_upstream_connection_->readDisable(false));
  ASSERT_TRUE(fake_upstream_connection_->waitForNewStream(*dispatcher_, upstream_request_));
  ASSERT_TRUE(upstream_request_->waitForEndStream(*dispatcher_));
  upstream_request_->encodeHeaders(default_response_headers_, true);

  // Wait for the encapsulated response to be received.
  ASSERT_TRUE(response->waitForEndStream());
  EXPECT_EQ("200", response->headers().getStatusValue());

  // Now send a second request to the same fake upstream. Envoy will pipeline and reuse the
  // connection so no need to strip the connect.
  default_request_headers_.setCopy(Envoy::Http::LowerCaseString("request2"), "val2");
  response = codec_client_->makeHeaderOnlyRequest(default_request_headers_);
  ASSERT_TRUE(fake_upstream_connection_->waitForNewStream(*dispatcher_, upstream_request_));
  ASSERT_TRUE(upstream_request_->waitForEndStream(*dispatcher_));
  EXPECT_FALSE(upstream_request_->headers().get(Http::LowerCaseString("request2")).empty());

  upstream_request_->encodeHeaders(default_response_headers_, true);
  // Wait for the encapsulated response to be received.
  ASSERT_TRUE(response->waitForEndStream());
  EXPECT_EQ("200", response->headers().getStatusValue());

  // Now send a request without the connect-proxy header. Make sure it doesn't get pooled in.
  default_request_headers_.remove(Envoy::Http::LowerCaseString("connect-proxy"));
  response = codec_client_->makeHeaderOnlyRequest(default_request_headers_);

  // The request should be sent to fake upstream 0.
  ASSERT_TRUE(fake_upstreams_[0]->waitForHttpConnection(*dispatcher_, fake_upstream_connection_));
  ASSERT_TRUE(fake_upstream_connection_->waitForNewStream(*dispatcher_, upstream_request_));
  ASSERT_TRUE(upstream_request_->waitForEndStream(*dispatcher_));
  // No encapsulation.
  EXPECT_TRUE(upstream_request_->waitForEndStream(*dispatcher_));
  upstream_request_->encodeHeaders(default_response_headers_, true);
  ASSERT_TRUE(response->waitForEndStream());
  EXPECT_EQ("200", response->headers().getStatusValue());
}

// Test Http2 for the inner application layer.
TEST_P(Http11ConnectHttpIntegrationTest, TestHttp2) {
  setUpstreamProtocol(Http::CodecType::HTTP2);
  use_alpn_ = true;
  initialize();

  // Point at the second fake upstream. Envoy doesn't actually know about this one.
  absl::string_view second_upstream_address(fake_upstreams_[1]->localAddress()->asStringView());
  codec_client_ = makeHttpConnection(lookupPort("http"));
  // The connect-proxy header will be stripped by the header-to-proxy-filter and inserted as
  // metadata.
  default_request_headers_.setCopy(Envoy::Http::LowerCaseString("connect-proxy"),
                                   second_upstream_address);
  auto response = codec_client_->makeHeaderOnlyRequest(default_request_headers_);

  // The request should be sent to fake upstream 1, due to the connect-proxy header.
  ASSERT_TRUE(fake_upstreams_[1]->waitForHttpConnection(*dispatcher_, fake_upstream_connection_));
  stripConnectUpgradeAndRespond();

  ASSERT_TRUE(fake_upstream_connection_->readDisable(false));
  ASSERT_TRUE(fake_upstream_connection_->waitForNewStream(*dispatcher_, upstream_request_));
  ASSERT_TRUE(upstream_request_->waitForEndStream(*dispatcher_));
  upstream_request_->encodeHeaders(default_response_headers_, true);

  // Wait for the encapsulated response to be received.
  ASSERT_TRUE(response->waitForEndStream());
  EXPECT_EQ("200", response->headers().getStatusValue());
}

#ifdef ENVOY_ENABLE_QUIC

// Test Http3 failing to HTTP/2 if proxy settings are enabled.
TEST_P(Http11ConnectHttpIntegrationTest, TestHttp3Failover) {
  setUpstreamProtocol(Http::CodecType::HTTP2);
  use_alpn_ = true;
  try_http3_ = true;
  initialize();

  // Point at the second fake upstream. Envoy doesn't actually know about this one.
  absl::string_view second_upstream_address(fake_upstreams_[1]->localAddress()->asStringView());
  codec_client_ = makeHttpConnection(lookupPort("http"));
  // The connect-proxy header will be stripped by the header-to-proxy-filter and inserted as
  // metadata.
  default_request_headers_.setCopy(Envoy::Http::LowerCaseString("connect-proxy"),
                                   second_upstream_address);
  auto response = codec_client_->makeHeaderOnlyRequest(default_request_headers_);

  // The request should be sent to fake upstream 1, due to the connect-proxy header.
  ASSERT_TRUE(fake_upstreams_[1]->waitForHttpConnection(*dispatcher_, fake_upstream_connection_));
  stripConnectUpgradeAndRespond();

  ASSERT_TRUE(fake_upstream_connection_->readDisable(false));
  ASSERT_TRUE(fake_upstream_connection_->waitForNewStream(*dispatcher_, upstream_request_));
  ASSERT_TRUE(upstream_request_->waitForEndStream(*dispatcher_));
  upstream_request_->encodeHeaders(default_response_headers_, true);

  // Wait for the encapsulated response to be received.
  ASSERT_TRUE(response->waitForEndStream());
  EXPECT_EQ("200", response->headers().getStatusValue());
}

// Test HTTP/3 being used if proxy settings are not set.
TEST_P(Http11ConnectHttpIntegrationTest, TestHttp3) {
  setUpstreamProtocol(Http::CodecType::HTTP3);
  use_alpn_ = true;
  try_http3_ = true;
  initialize();

  codec_client_ = makeHttpConnection(lookupPort("http"));
  auto response = codec_client_->makeHeaderOnlyRequest(default_request_headers_);

  // The request should be sent to fake upstream 0.
  ASSERT_TRUE(fake_upstreams_[0]->waitForHttpConnection(*dispatcher_, fake_upstream_connection_));
  ASSERT_TRUE(fake_upstream_connection_->waitForNewStream(*dispatcher_, upstream_request_));
  ASSERT_TRUE(upstream_request_->waitForEndStream(*dispatcher_));
  upstream_request_->encodeHeaders(default_response_headers_, true);

  // Wait for the encapsulated response to be received.
  ASSERT_TRUE(response->waitForEndStream());
  EXPECT_EQ("200", response->headers().getStatusValue());
}

#endif

TEST_P(Http11ConnectHttpIntegrationTest, DfpNoProxyAddress) {
  useAccessLog("%RESPONSE_CODE_DETAILS%");
  addDfpConfig();
  initialize();

  codec_client_ = makeHttpConnection(lookupPort("http"));
  // Set the host to a domain which does not exist.
  default_request_headers_.setHost("doesnotexist.lyft.com");

  // Without the proxy header set, the filter will fail the request due to DNS resolution failure.
  auto response = codec_client_->makeHeaderOnlyRequest(default_request_headers_);
  ASSERT_TRUE(response->waitForEndStream());
  EXPECT_EQ("503", response->headers().getStatusValue());
  EXPECT_THAT(waitForAccessLog(access_log_name_), testing::HasSubstr("dns_resolution_failure"));
}

// Regression tests https://github.com/envoyproxy/envoy/issues/34096
TEST_P(Http11ConnectHttpIntegrationTest, DfpWithProxyAddressAndContentLength) {
  addDfpConfig();

  initialize();

  // Point at the second fake upstream. Envoy doesn't actually know about this one.
  absl::string_view second_upstream_address(fake_upstreams_[1]->localAddress()->asStringView());
  codec_client_ = makeHttpConnection(lookupPort("http"));
  // Set the host to a domain which does not exist.
  default_request_headers_.setHost("doesnotexist.lyft.com");
  // The connect-proxy header will be stripped by the header-to-proxy-filter and inserted as
  // metadata.
  default_request_headers_.setCopy(Envoy::Http::LowerCaseString("connect-proxy"),
                                   second_upstream_address);

  auto response = codec_client_->makeHeaderOnlyRequest(default_request_headers_);

  // The request should be sent to fake upstream 1, as DNS lookup is bypassed due to the
  // connect-proxy header.
  ASSERT_TRUE(fake_upstreams_[1]->waitForHttpConnection(*dispatcher_, fake_upstream_connection_));
  stripConnectUpgradeAndRespond(true);

  ASSERT_TRUE(fake_upstream_connection_->readDisable(false));
  ASSERT_TRUE(fake_upstream_connection_->waitForNewStream(*dispatcher_, upstream_request_));
  ASSERT_TRUE(upstream_request_->waitForEndStream(*dispatcher_));
  upstream_request_->encodeHeaders(default_response_headers_, true);

  // Wait for the encapsulated response to be received.
  ASSERT_TRUE(response->waitForEndStream());
  EXPECT_EQ("200", response->headers().getStatusValue());
}

TEST_P(Http11ConnectHttpIntegrationTest, DfpWithProxyAddressLegacy) {
  config_helper_.addRuntimeOverride(
      "envoy.reloadable_features.skip_dns_lookup_for_proxied_requests", "false");

  addDfpConfig();

  initialize();

  // Point at the second fake upstream. Envoy doesn't actually know about this one.
  absl::string_view second_upstream_address(fake_upstreams_[1]->localAddress()->asStringView());
  codec_client_ = makeHttpConnection(lookupPort("http"));
  // Set the host to a domain which does not exist.
  default_request_headers_.setHost("doesnotexist.lyft.com");
  // The connect-proxy header will be stripped by the header-to-proxy-filter and inserted as
  // metadata.
  default_request_headers_.setCopy(Envoy::Http::LowerCaseString("connect-proxy"),
                                   second_upstream_address);

  auto response = codec_client_->makeHeaderOnlyRequest(default_request_headers_);

  // Wait for the encapsulated response to be received.
  ASSERT_TRUE(response->waitForEndStream());
  EXPECT_EQ("503", response->headers().getStatusValue());
}

// Test sending a request to host with port.
TEST_P(Http11ConnectHttpIntegrationTest, HostWithPort) {
  initialize();

  absl::string_view second_upstream_address(fake_upstreams_[1]->localAddress()->asStringView());
  codec_client_ = makeHttpConnection(lookupPort("http"));
  // The connect-proxy header will be stripped by the header-to-proxy-filter and inserted as
  // metadata.
  default_request_headers_.setCopy(Envoy::Http::LowerCaseString("connect-proxy"),
                                   second_upstream_address);
  default_request_headers_.setHost("sni.lyft.com:443");
  auto response = codec_client_->makeHeaderOnlyRequest(default_request_headers_);

  ASSERT_TRUE(fake_upstreams_[1]->waitForHttpConnection(*dispatcher_, fake_upstream_connection_));

  stripConnectUpgradeAndRespond();

  // Enable reading on the new stream, and read the encapsulated request.
  ASSERT_TRUE(fake_upstream_connection_->readDisable(false));
  ASSERT_TRUE(fake_upstream_connection_->waitForNewStream(*dispatcher_, upstream_request_));
  ASSERT_TRUE(upstream_request_->waitForEndStream(*dispatcher_));

  upstream_request_->encodeHeaders(default_response_headers_, true);

  // Wait for the encapsulated response to be received.
  ASSERT_TRUE(response->waitForEndStream());
  EXPECT_EQ("200", response->headers().getStatusValue());
}

TEST_P(Http11ConnectHttpIntegrationTest, ConfiguredProxy) {
  pre_create_upstreams_ = true;
  initialize();

  // With a default proxy configured, the request gets proxied to fake upstream 1.
  default_request_headers_.setCopy(Envoy::Http::LowerCaseString("foo"), "bar");
  default_response_headers_.setCopy(Envoy::Http::LowerCaseString("foo"), "bar");
  codec_client_ = makeHttpConnection(lookupPort("http"));
  auto response = codec_client_->makeHeaderOnlyRequest(default_request_headers_);

  // The request should be sent to fake upstream 1, due to the default proxy address.
  ASSERT_TRUE(fake_upstreams_[1]->waitForHttpConnection(*dispatcher_, fake_upstream_connection_));

  // Verify the CONNECT request format. Since we are using a static cluster and
  // default_proxy_address, the CONNECT target is the physical address of the upstream.
  std::string prefix_data;
  ASSERT_TRUE(fake_upstream_connection_->waitForInexactRawData("\r\n\r\n", prefix_data));
  const std::string target = fake_upstreams_[0]->localAddress()->asString();
  std::string expected_connect =
      absl::StrCat("CONNECT ", target, " HTTP/1.1\r\n", "Host: ", target, "\r\n\r\n");
  EXPECT_EQ(expected_connect, prefix_data);

  // Ship the CONNECT response.
  fake_upstream_connection_->writeRawData("HTTP/1.1 200 OK\r\n\r\n");

  ASSERT_TRUE(fake_upstream_connection_->readDisable(false));
  ASSERT_TRUE(fake_upstream_connection_->waitForNewStream(*dispatcher_, upstream_request_));
  ASSERT_TRUE(upstream_request_->waitForEndStream(*dispatcher_));
  upstream_request_->encodeHeaders(default_response_headers_, true);

  ASSERT_TRUE(response->waitForEndStream());
  EXPECT_EQ("200", response->headers().getStatusValue());
  ASSERT_FALSE(upstream_request_->headers().get(Http::LowerCaseString("foo")).empty());
  ASSERT_FALSE(response->headers().get(Http::LowerCaseString("foo")).empty());
}

} // namespace
} // namespace Envoy
