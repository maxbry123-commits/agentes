#include <cstdint>
#include <fstream>
#include <memory>
#include <regex>
#include <string>
#include <vector>

#include "envoy/common/exception.h"

#include "source/common/common/c_smart_ptr.h"
#include "source/common/common/fmt.h"
#include "source/common/event/real_time_system.h"
#include "source/common/network/transport_socket_options_impl.h"
#include "source/common/router/string_accessor_impl.h"
#include "source/common/stream_info/filter_state_impl.h"
#include "source/common/tls/stats.h"
#include "source/extensions/transport_sockets/tls/cert_validator/spiffe/spiffe_validator.h"

#include "test/common/tls/cert_validator/test_common.h"
#include "test/common/tls/ssl_test_utility.h"
#include "test/common/tls/test_data/ca_cert_info.h"
#include "test/common/tls/test_data/intermediate_ca_cert_info.h"
#include "test/mocks/network/mocks.h"
#include "test/mocks/server/server_factory_context.h"
#include "test/test_common/environment.h"
#include "test/test_common/simulated_time_system.h"
#include "test/test_common/status_utility.h"
#include "test/test_common/test_runtime.h"
#include "test/test_common/utility.h"

#include "absl/status/status.h"
#include "gmock/gmock.h"
#include "gtest/gtest.h"
#include "include/nlohmann/json.hpp"
#include "openssl/ssl.h"
#include "openssl/x509v3.h"

namespace Envoy {
namespace Extensions {
namespace TransportSockets {
namespace Tls {

using ::Envoy::StatusHelpers::HasStatus;
using ::testing::HasSubstr;
using TestCertificateValidationContextConfigPtr =
    std::unique_ptr<TestCertificateValidationContextConfig>;
using SPIFFEValidatorPtr = std::unique_ptr<SPIFFEValidator>;
using ASN1IA5StringPtr = CSmartPtr<ASN1_IA5STRING, ASN1_IA5STRING_free>;
using GeneralNamesPtr = CSmartPtr<GENERAL_NAMES, GENERAL_NAMES_free>;
using X509StoreContextPtr = CSmartPtr<X509_STORE_CTX, X509_STORE_CTX_free>;
using X509Ptr = CSmartPtr<X509, X509_free>;
using SSLContextPtr = CSmartPtr<SSL_CTX, SSL_CTX_free>;

class TestSPIFFEValidator : public testing::Test {
public:
  TestSPIFFEValidator()
      : api_(Api::createApiForTest()), stats_(generateSslStats(*store_.rootScope())) {
    ON_CALL(factory_context_, api()).WillByDefault(testing::ReturnRef(*api_));
  }

  absl::Status initialize(std::string yaml, TimeSource& time_source) {
    envoy::config::core::v3::TypedExtensionConfig typed_conf;
    TestUtility::loadFromYaml(yaml, typed_conf);
    config_ = std::make_unique<TestCertificateValidationContextConfig>(
        typed_conf, allow_expired_certificate_, san_matchers_, /*ca_cert=*/"",
        /*verify_depth=*/std::nullopt, suppress_client_ca_list_);

    // Mocking time source
    ON_CALL(factory_context_, timeSource()).WillByDefault(testing::ReturnRef(time_source));

    // Initialize SPIFFEValidator with mocked context and stats
    absl::Status creation_status = absl::OkStatus();
    validator_ = std::make_unique<SPIFFEValidator>(config_.get(), stats_, factory_context_,
                                                   *store_.rootScope(), creation_status);
    return creation_status;
  }

  std::string compactJson(const std::string& json_string) {
    try {
      nlohmann::json j = nlohmann::json::parse(json_string);

      return j.dump();
    } catch (const nlohmann::json::parse_error& e) {
      std::cerr << "Error parsing JSON: " << e.what() << std::endl;
      return "";
    }
  }

  std::string escapeJson(const std::string& input) {
    std::ostringstream ss;
    for (char c : input) {
      switch (c) {
      case '\\':
        ss << "\\\\";
        break;
      case '"':
        ss << "\\\"";
        break;
      default:
        ss << c;
        break;
      }
    }
    return ss.str();
  }

  absl::Status initialize(std::string yaml, std::string trust_bundle_file = "") {
    envoy::config::core::v3::TypedExtensionConfig typed_conf;
    TestUtility::loadFromYaml(yaml, typed_conf);
    config_ = std::make_unique<TestCertificateValidationContextConfig>(
        typed_conf, allow_expired_certificate_, san_matchers_, /*ca_cert=*/"",
        /*verify_depth=*/std::nullopt, suppress_client_ca_list_);

    if (!trust_bundle_file.empty()) {
      EXPECT_CALL(factory_context_.dispatcher_, createFilesystemWatcher_())
          .WillRepeatedly(testing::Invoke([trust_bundle_file] {
            Filesystem::MockWatcher* mock_watcher = new NiceMock<Filesystem::MockWatcher>();
            EXPECT_CALL(*mock_watcher, addWatch(TestEnvironment::substitute(
                                                    "{{ test_rundir }}/test/common/tls/test_data/" +
                                                    trust_bundle_file),
                                                _, _))
                .WillRepeatedly(testing::Return(absl::OkStatus()));
            return mock_watcher;
          }));
    }

    absl::Status creation_status = absl::OkStatus();
    validator_ = std::make_unique<SPIFFEValidator>(config_.get(), stats_, factory_context_,
                                                   *store_.rootScope(), creation_status);
    return creation_status;
  }

  absl::Status initialize() {
    absl::Status creation_status = absl::OkStatus();
    validator_ = std::make_unique<SPIFFEValidator>(stats_, factory_context_);
    return creation_status;
  }

  // Getter.
  SPIFFEValidator& validator() { return *validator_; }
  SslStats& stats() { return stats_; }
  Stats::TestUtil::TestStore& store() { return store_; }

  // Setter.
  void setAllowExpiredCertificate(bool val) { allow_expired_certificate_ = val; }
  void setSuppressClientCaList(bool val) { suppress_client_ca_list_ = val; }
  void setSanMatchers(std::vector<envoy::type::matcher::v3::StringMatcher> san_matchers) {
    san_matchers_.clear();
    for (auto& matcher : san_matchers) {
      san_matchers_.emplace_back();
      san_matchers_.back().set_san_type(
          envoy::extensions::transport_sockets::tls::v3::SubjectAltNameMatcher::DNS);
      *san_matchers_.back().mutable_matcher() = matcher;

      san_matchers_.emplace_back();
      san_matchers_.back().set_san_type(
          envoy::extensions::transport_sockets::tls::v3::SubjectAltNameMatcher::URI);
      *san_matchers_.back().mutable_matcher() = matcher;

      san_matchers_.emplace_back();
      san_matchers_.back().set_san_type(
          envoy::extensions::transport_sockets::tls::v3::SubjectAltNameMatcher::EMAIL);
      *san_matchers_.back().mutable_matcher() = matcher;

      san_matchers_.emplace_back();
      san_matchers_.back().set_san_type(
          envoy::extensions::transport_sockets::tls::v3::SubjectAltNameMatcher::IP_ADDRESS);
      *san_matchers_.back().mutable_matcher() = matcher;
    }
  };

  void addSanMatcher(envoy::extensions::transport_sockets::tls::v3::SubjectAltNameMatcher matcher) {
    san_matchers_.push_back(std::move(matcher));
  }

  Api::ApiPtr api_;
  NiceMock<Server::Configuration::MockServerFactoryContext> factory_context_;
  NiceMock<Envoy::Event::MockDispatcher> dispatcher_;

private:
  bool allow_expired_certificate_{false};
  bool suppress_client_ca_list_{false};
  TestCertificateValidationContextConfigPtr config_;
  std::vector<envoy::extensions::transport_sockets::tls::v3::SubjectAltNameMatcher> san_matchers_;
  Stats::TestUtil::TestStore store_;
  SslStats stats_;
  Event::TestRealTimeSystem time_system_;
  SPIFFEValidatorPtr validator_;
};

TEST_F(TestSPIFFEValidator, InvalidCA) {
  // Invalid trust bundle.
  EXPECT_THAT(initialize(TestEnvironment::substitute(R"EOF(
name: envoy.tls.cert_validator.spiffe
typed_config:
  "@type": type.googleapis.com/envoy.extensions.transport_sockets.tls.v3.SPIFFECertValidatorConfig
  trust_domains:
    - name: hello.com
      trust_bundle:
        inline_string: "invalid"
  )EOF")),
              HasStatus(absl::StatusCode::kInvalidArgument,
                        HasSubstr("Failed to load trusted CA certificate for hello.com")));
}

// Multiple trust bundles are given for the same trust domain.
TEST_F(TestSPIFFEValidator, Constructor) {
  EXPECT_THAT(
      initialize(TestEnvironment::substitute(R"EOF(
name: envoy.tls.cert_validator.spiffe
typed_config:
  "@type": type.googleapis.com/envoy.extensions.transport_sockets.tls.v3.SPIFFECertValidatorConfig
  trust_domains:
    - name: hello.com
      trust_bundle:
        filename: "{{ test_rundir }}/test/common/tls/test_data/ca_cert_with_crl.pem"
    - name: hello.com
      trust_bundle:
        filename: "{{ test_rundir }}/test/common/tls/test_data/ca_cert_with_crl.pem"
  )EOF")),
      HasStatus(absl::StatusCode::kInvalidArgument,
                HasSubstr("Multiple trust bundles are given for one trust domain for hello.com")));

  // Single trust bundle.
  ASSERT_OK(initialize(TestEnvironment::substitute(R"EOF(
name: envoy.tls.cert_validator.spiffe
typed_config:
  "@type": type.googleapis.com/envoy.extensions.transport_sockets.tls.v3.SPIFFECertValidatorConfig
  trust_domains:
    - name: hello.com
      trust_bundle:
        filename: "{{ test_rundir }}/test/common/tls/test_data/ca_cert_with_crl.pem"
  )EOF")));

  EXPECT_EQ(1, validator().getSpiffeData()->trust_bundle_stores_.size());
  EXPECT_THAT(validator().getCaFileName(), HasSubstr("test_data/ca_cert_with_crl.pem"));
  EXPECT_THAT(validator().getCaFileName(), HasSubstr("hello.com"));

  // Multiple trust bundles.
  ASSERT_OK(initialize(TestEnvironment::substitute(R"EOF(
name: envoy.tls.cert_validator.spiffe
typed_config:
  "@type": type.googleapis.com/envoy.extensions.transport_sockets.tls.v3.SPIFFECertValidatorConfig
  trust_domains:
    - name: hello.com
      trust_bundle:
        filename: "{{ test_rundir }}/test/common/tls/test_data/ca_cert.pem"
    - name: k8s-west.example.com
      trust_bundle:
        filename: "{{ test_rundir }}/test/common/tls/test_data/keyusage_crl_sign_cert.pem"
  )EOF")));

  EXPECT_EQ(2, validator().getSpiffeData()->trust_bundle_stores_.size());
}

TEST(SPIFFEValidator, TestExtractTrustDomain) {
  EXPECT_EQ("", SPIFFEValidator::extractTrustDomain("foo"));
  EXPECT_EQ("", SPIFFEValidator::extractTrustDomain("abc.com/"));
  EXPECT_EQ("", SPIFFEValidator::extractTrustDomain("abc.com/workload/"));
  EXPECT_EQ("", SPIFFEValidator::extractTrustDomain("spiffe://"));
  EXPECT_EQ("abc.com", SPIFFEValidator::extractTrustDomain("spiffe://abc.com/"));
  EXPECT_EQ("dev.envoy.com",
            SPIFFEValidator::extractTrustDomain("spiffe://dev.envoy.com/workload1"));
  EXPECT_EQ("k8s-west.example.com", SPIFFEValidator::extractTrustDomain(
                                        "spiffe://k8s-west.example.com/ns/staging/sa/default"));
}

TEST(SPIFFEValidator, TestCertificatePrecheck) {
  bssl::UniquePtr<X509> cert = readCertFromFile(TestEnvironment::substitute(
      // basicConstraints: CA:True,
      "{{ test_rundir }}/test/common/tls/test_data/ca_cert.pem"));
  EXPECT_FALSE(SPIFFEValidator::certificatePrecheck(cert.get()));

  cert = readCertFromFile(TestEnvironment::substitute(
      // basicConstraints CA:False, keyUsage has keyCertSign
      "{{ test_rundir "
      "}}/test/common/tls/test_data/keyusage_cert_sign_cert.pem"));
  EXPECT_FALSE(SPIFFEValidator::certificatePrecheck(cert.get()));

  cert = readCertFromFile(TestEnvironment::substitute(
      // basicConstraints CA:False, keyUsage has cRLSign
      "{{ test_rundir "
      "}}/test/common/tls/test_data/keyusage_crl_sign_cert.pem"));
  EXPECT_FALSE(SPIFFEValidator::certificatePrecheck(cert.get()));

  cert = readCertFromFile(TestEnvironment::substitute(
      // basicConstraints CA:False, keyUsage does not have keyCertSign and cRLSign
      // should be considered valid (i.e. return 1).
      "{{ test_rundir }}/test/common/tls/test_data/extensions_cert.pem"));
  EXPECT_TRUE(SPIFFEValidator::certificatePrecheck(cert.get()));
}

TEST_F(TestSPIFFEValidator, TestInitializeSslContexts) {
  ASSERT_OK(initialize());
  Stats::TestUtil::TestStore store;
  EXPECT_EQ(SSL_VERIFY_PEER | SSL_VERIFY_FAIL_IF_NO_PEER_CERT,
            validator().initializeSslContexts({}, false, *store.rootScope()).value());
}

TEST_F(TestSPIFFEValidator, TestGetTrustBundleStore) {
  ASSERT_OK(initialize());

  // No SAN
  auto cert = readCertFromFile(TestEnvironment::substitute(
      "{{ test_rundir }}/test/common/tls/test_data/extensions_cert.pem"));
  EXPECT_FALSE(validator().getTrustBundleStore(cert.get(), ""));

  // Non-SPIFFE SAN
  cert = readCertFromFile(
      TestEnvironment::substitute("{{ test_rundir "
                                  "}}/test/common/tls/test_data/non_spiffe_san_cert.pem"));
  EXPECT_FALSE(validator().getTrustBundleStore(cert.get(), ""));

  // SPIFFE SAN
  cert = readCertFromFile(TestEnvironment::substitute(
      "{{ test_rundir }}/test/common/tls/test_data/spiffe_san_cert.pem"));

  // Trust bundle not provided.
  EXPECT_FALSE(validator().getTrustBundleStore(cert.get(), ""));

  // Trust bundle provided.
  validator().getSpiffeData()->trust_bundle_stores_["example.com"][""] =
      X509StorePtr(X509_STORE_new());
  EXPECT_TRUE(validator().getTrustBundleStore(cert.get(), ""));
  EXPECT_FALSE(validator().getTrustBundleStore(cert.get(), "mydomain.org"));
}

TEST_F(TestSPIFFEValidator, TestDoVerifyCertChainWithEmptyChain) {
  ASSERT_OK(initialize());
  TestSslExtendedSocketInfo info;
  SSLContextPtr ssl_ctx = SSL_CTX_new(TLS_method());
  bssl::UniquePtr<STACK_OF(X509)> cert_chain(sk_X509_new_null());
  ValidationResults results =
      validator().doVerifyCertChain(*cert_chain, info.createValidateResultCallback(),
                                    /*transport_socket_options=*/nullptr, *ssl_ctx, {}, false, "");
  EXPECT_EQ(ValidationResults::ValidationStatus::Failed, results.status);
  EXPECT_EQ(Envoy::Ssl::ClientValidationStatus::NotValidated, results.detailed_status);
  EXPECT_EQ(1, stats().fail_verify_error_.value());
}

TEST_F(TestSPIFFEValidator, TestDoVerifyCertChainPrecheckFailure) {
  ASSERT_OK(initialize());
  bssl::UniquePtr<X509> cert = readCertFromFile(TestEnvironment::substitute(
      // basicConstraints: CA:True
      "{{ test_rundir }}/test/common/tls/test_data/ca_cert.pem"));
  TestSslExtendedSocketInfo info;
  SSLContextPtr ssl_ctx = SSL_CTX_new(TLS_method());
  bssl::UniquePtr<STACK_OF(X509)> cert_chain(sk_X509_new_null());
  sk_X509_push(cert_chain.get(), cert.release());
  ValidationResults results =
      validator().doVerifyCertChain(*cert_chain, info.createValidateResultCallback(),
                                    /*transport_socket_options=*/nullptr, *ssl_ctx, {}, false, "");
  EXPECT_EQ(ValidationResults::ValidationStatus::Failed, results.status);
  EXPECT_EQ(Envoy::Ssl::ClientValidationStatus::Failed, results.detailed_status);
  EXPECT_EQ(1, stats().fail_verify_error_.value());
}

TEST_F(TestSPIFFEValidator, TestDoVerifyCertChainSingleTrustDomain) {
  ASSERT_OK(initialize(TestEnvironment::substitute(R"EOF(
name: envoy.tls.cert_validator.spiffe
typed_config:
  "@type": type.googleapis.com/envoy.extensions.transport_sockets.tls.v3.SPIFFECertValidatorConfig
  trust_domains:
    - name: lyft.com
      trust_bundle:
        filename: "{{ test_rundir }}/test/common/tls/test_data/ca_cert.pem"
  )EOF")));

  X509StorePtr store = X509_STORE_new();
  SSLContextPtr ssl_ctx = SSL_CTX_new(TLS_method());
  TestSslExtendedSocketInfo info;
  {
    // Trust domain matches so should be accepted.
    auto cert = readCertFromFile(TestEnvironment::substitute(
        "{{ test_rundir }}/test/common/tls/test_data/san_uri_cert.pem"));
    bssl::UniquePtr<STACK_OF(X509)> cert_chain(sk_X509_new_null());
    sk_X509_push(cert_chain.get(), cert.release());
    EXPECT_EQ(ValidationResults::ValidationStatus::Successful,
              validator()
                  .doVerifyCertChain(*cert_chain, info.createValidateResultCallback(),
                                     /*transport_socket_options=*/nullptr, *ssl_ctx, {}, false, "")
                  .status);
  }

  {
    // Different trust domain so should be rejected.
    auto cert = readCertFromFile(TestEnvironment::substitute(
        "{{ test_rundir }}/test/common/tls/test_data/spiffe_san_cert.pem"));
    bssl::UniquePtr<STACK_OF(X509)> cert_chain(sk_X509_new_null());
    sk_X509_push(cert_chain.get(), cert.release());
    EXPECT_EQ(ValidationResults::ValidationStatus::Failed,
              validator()
                  .doVerifyCertChain(*cert_chain, info.createValidateResultCallback(),
                                     /*transport_socket_options=*/nullptr, *ssl_ctx, {}, false, "")
                  .status);
  }
  {
    // Does not have san.
    auto cert = readCertFromFile(TestEnvironment::substitute(
        "{{ test_rundir }}/test/common/tls/test_data/extensions_cert.pem"));
    bssl::UniquePtr<STACK_OF(X509)> cert_chain(sk_X509_new_null());
    sk_X509_push(cert_chain.get(), cert.release());
    EXPECT_EQ(ValidationResults::ValidationStatus::Failed,
              validator()
                  .doVerifyCertChain(*cert_chain, info.createValidateResultCallback(),
                                     /*transport_socket_options=*/nullptr, *ssl_ctx, {}, false, "")
                  .status);
  }

  EXPECT_EQ(2, stats().fail_verify_error_.value());
}

TEST_F(TestSPIFFEValidator, TestDoVerifyCertChainMultipleTrustDomain) {
  ASSERT_OK(initialize(TestEnvironment::substitute(R"EOF(
name: envoy.tls.cert_validator.spiffe
typed_config:
  "@type": type.googleapis.com/envoy.extensions.transport_sockets.tls.v3.SPIFFECertValidatorConfig
  trust_domains:
    - name: lyft.com
      trust_bundle:
        filename: "{{ test_rundir }}/test/common/tls/test_data/ca_cert.pem"
    - name: example.com
      trust_bundle:
        filename: "{{ test_rundir }}/test/common/tls/test_data/ca_cert.pem"
  )EOF")));

  X509StorePtr store = X509_STORE_new();
  SSLContextPtr ssl_ctx = SSL_CTX_new(TLS_method());
  TestSslExtendedSocketInfo info;

  {
    // Trust domain matches so should be accepted.
    auto cert = readCertFromFile(TestEnvironment::substitute(
        "{{ test_rundir }}/test/common/tls/test_data/san_uri_cert.pem"));
    bssl::UniquePtr<STACK_OF(X509)> cert_chain(sk_X509_new_null());
    sk_X509_push(cert_chain.get(), cert.release());
    EXPECT_EQ(ValidationResults::ValidationStatus::Successful,
              validator()
                  .doVerifyCertChain(*cert_chain, info.createValidateResultCallback(),
                                     /*transport_socket_options=*/nullptr, *ssl_ctx, {}, false, "")
                  .status);
  }

  {
    auto cert = readCertFromFile(TestEnvironment::substitute(
        "{{ test_rundir }}/test/common/tls/test_data/spiffe_san_cert.pem"));
    bssl::UniquePtr<STACK_OF(X509)> cert_chain(sk_X509_new_null());
    sk_X509_push(cert_chain.get(), cert.release());
    EXPECT_EQ(ValidationResults::ValidationStatus::Successful,
              validator()
                  .doVerifyCertChain(*cert_chain, info.createValidateResultCallback(),
                                     /*transport_socket_options=*/nullptr, *ssl_ctx, {}, false, "")
                  .status);
  }

  {
    // Trust domain matches but it has expired.
    auto cert = readCertFromFile(
        TestEnvironment::substitute("{{ test_rundir "
                                    "}}/test/common/tls/test_data/expired_spiffe_san_cert.pem"));
    bssl::UniquePtr<STACK_OF(X509)> cert_chain(sk_X509_new_null());
    sk_X509_push(cert_chain.get(), cert.release());
    EXPECT_EQ(ValidationResults::ValidationStatus::Failed,
              validator()
                  .doVerifyCertChain(*cert_chain, info.createValidateResultCallback(),
                                     /*transport_socket_options=*/nullptr, *ssl_ctx, {}, false, "")
                  .status);
  }

  {
    // Does not have san.
    auto cert = readCertFromFile(TestEnvironment::substitute(
        "{{ test_rundir }}/test/common/tls/test_data/extensions_cert.pem"));
    bssl::UniquePtr<STACK_OF(X509)> cert_chain(sk_X509_new_null());
    sk_X509_push(cert_chain.get(), cert.release());
    EXPECT_EQ(ValidationResults::ValidationStatus::Failed,
              validator()
                  .doVerifyCertChain(*cert_chain, info.createValidateResultCallback(),
                                     /*transport_socket_options=*/nullptr, *ssl_ctx, {}, false, "")
                  .status);
  }

  EXPECT_EQ(2, stats().fail_verify_error_.value());
}

TEST_F(TestSPIFFEValidator, TestDoVerifyCertChainMultipleTrustDomainWithWorkloadTrustDomain) {
  ASSERT_OK(initialize(TestEnvironment::substitute(R"EOF(
name: envoy.tls.cert_validator.spiffe
typed_config:
  "@type": type.googleapis.com/envoy.extensions.transport_sockets.tls.v3.SPIFFECertValidatorConfig
  trust_domains:
    - name: lyft.com
      trust_bundle:
        filename: "{{ test_rundir }}/test/common/tls/test_data/ca_cert.pem"
      workload_trust_domain: "mydomain.org"
    - name: example.com
      trust_bundle:
        filename: "{{ test_rundir }}/test/common/tls/test_data/ca_cert.pem"
  )EOF")));

  X509StorePtr store = X509_STORE_new();
  SSLContextPtr ssl_ctx = SSL_CTX_new(TLS_method());
  TestSslExtendedSocketInfo info;
  NiceMock<Network::MockTransportSocketCallbacks> callbacks;

  {
    SCOPED_TRACE("Trust domain has workload_trust_domain but connection does not (client).");
    auto cert = readCertFromFile(TestEnvironment::substitute(
        "{{ test_rundir }}/test/common/tls/test_data/san_uri_cert.pem"));
    bssl::UniquePtr<STACK_OF(X509)> cert_chain(sk_X509_new_null());
    sk_X509_push(cert_chain.get(), cert.release());
    EXPECT_EQ(ValidationResults::ValidationStatus::Failed,
              validator()
                  .doVerifyCertChain(*cert_chain, info.createValidateResultCallback(),
                                     /*transport_socket_options=*/nullptr, *ssl_ctx,
                                     {.callbacks = &callbacks}, false, "")
                  .status);
  }

  {
    SCOPED_TRACE("Trust domain has workload_trust_domain but connection does not (server).");
    auto cert = readCertFromFile(TestEnvironment::substitute(
        "{{ test_rundir }}/test/common/tls/test_data/san_uri_cert.pem"));
    bssl::UniquePtr<STACK_OF(X509)> cert_chain(sk_X509_new_null());
    sk_X509_push(cert_chain.get(), cert.release());
    EXPECT_EQ(ValidationResults::ValidationStatus::Failed,
              validator()
                  .doVerifyCertChain(*cert_chain, info.createValidateResultCallback(),
                                     /*transport_socket_options=*/nullptr, *ssl_ctx,
                                     {.callbacks = &callbacks}, true, "")
                  .status);
  }

  callbacks.connection().streamInfo().filterState()->setData(
      "envoy.tls.cert_validator.spiffe.workload_trust_domain",
      std::make_shared<Router::StringAccessorImpl>("mydomain.org"),
      StreamInfo::FilterState::LifeSpan::Connection);

  {
    SCOPED_TRACE("Trust domain matches so should be accepted (server).");
    auto cert = readCertFromFile(TestEnvironment::substitute(
        "{{ test_rundir }}/test/common/tls/test_data/san_uri_cert.pem"));
    bssl::UniquePtr<STACK_OF(X509)> cert_chain(sk_X509_new_null());
    sk_X509_push(cert_chain.get(), cert.release());
    EXPECT_EQ(ValidationResults::ValidationStatus::Successful,
              validator()
                  .doVerifyCertChain(*cert_chain, info.createValidateResultCallback(),
                                     /*transport_socket_options=*/nullptr, *ssl_ctx,
                                     {.callbacks = &callbacks}, true, "")
                  .status);
  }

  {
    SCOPED_TRACE("Trust domain does not match because it's missing workload_trust_domain in the "
                 "definition (server).");
    auto cert = readCertFromFile(TestEnvironment::substitute(
        "{{ test_rundir }}/test/common/tls/test_data/spiffe_san_cert.pem"));
    bssl::UniquePtr<STACK_OF(X509)> cert_chain(sk_X509_new_null());
    sk_X509_push(cert_chain.get(), cert.release());
    EXPECT_EQ(ValidationResults::ValidationStatus::Failed,
              validator()
                  .doVerifyCertChain(*cert_chain, info.createValidateResultCallback(),
                                     /*transport_socket_options=*/nullptr, *ssl_ctx,
                                     {.callbacks = &callbacks}, true, "")
                  .status);
  }

  StreamInfo::FilterStateImpl filter_state(StreamInfo::FilterState::LifeSpan::Connection);
  filter_state.setData("envoy.tls.cert_validator.spiffe.workload_trust_domain",
                       std::make_shared<Router::StringAccessorImpl>("mydomain.org"),
                       StreamInfo::FilterState::LifeSpan::Connection,
                       StreamInfo::StreamSharingMayImpactPooling::SharedWithUpstreamConnection);
  auto socket_options = Network::TransportSocketOptionsUtility::fromFilterState(filter_state);

  {
    SCOPED_TRACE("Trust domain matches so should be accepted (client).");
    auto cert = readCertFromFile(TestEnvironment::substitute(
        "{{ test_rundir }}/test/common/tls/test_data/san_uri_cert.pem"));
    bssl::UniquePtr<STACK_OF(X509)> cert_chain(sk_X509_new_null());
    sk_X509_push(cert_chain.get(), cert.release());
    EXPECT_EQ(ValidationResults::ValidationStatus::Successful,
              validator()
                  .doVerifyCertChain(*cert_chain, info.createValidateResultCallback(),
                                     socket_options, *ssl_ctx, {}, false, "")
                  .status);
  }

  {
    SCOPED_TRACE("Trust domain does not match because it's missing workload_trust_domain in the "
                 "definition (client).");
    auto cert = readCertFromFile(TestEnvironment::substitute(
        "{{ test_rundir }}/test/common/tls/test_data/spiffe_san_cert.pem"));
    bssl::UniquePtr<STACK_OF(X509)> cert_chain(sk_X509_new_null());
    sk_X509_push(cert_chain.get(), cert.release());
    EXPECT_EQ(ValidationResults::ValidationStatus::Failed,
              validator()
                  .doVerifyCertChain(*cert_chain, info.createValidateResultCallback(),
                                     socket_options, *ssl_ctx, {}, false, "")
                  .status);
  }
}

TEST_F(TestSPIFFEValidator, TestDoVerifyCertChainMultipleTrustDomainAllowExpired) {
  setAllowExpiredCertificate(true);
  ASSERT_OK(initialize(TestEnvironment::substitute(R"EOF(
name: envoy.tls.cert_validator.spiffe
typed_config:
  "@type": type.googleapis.com/envoy.extensions.transport_sockets.tls.v3.SPIFFECertValidatorConfig
  trust_domains:
    - name: example.com
      trust_bundle:
        filename: "{{ test_rundir }}/test/common/tls/test_data/ca_cert.pem"
  )EOF")));

  X509StorePtr store = X509_STORE_new();
  SSLContextPtr ssl_ctx = SSL_CTX_new(TLS_method());
  TestSslExtendedSocketInfo info;
  // Trust domain matches and it has expired but allow_expired_certificate is true, so this
  // should be accepted.
  auto cert = readCertFromFile(
      TestEnvironment::substitute("{{ test_rundir "
                                  "}}/test/common/tls/test_data/expired_spiffe_san_cert.pem"));
  bssl::UniquePtr<STACK_OF(X509)> cert_chain(sk_X509_new_null());
  sk_X509_push(cert_chain.get(), cert.release());
  EXPECT_EQ(ValidationResults::ValidationStatus::Successful,
            validator()
                .doVerifyCertChain(*cert_chain, info.createValidateResultCallback(),
                                   /*transport_socket_options=*/nullptr, *ssl_ctx, {}, false, "")
                .status);

  EXPECT_EQ(0, stats().fail_verify_error_.value());
}

TEST_F(TestSPIFFEValidator, TestDoVerifyCertChainSANMatching) {
  const auto config = TestEnvironment::substitute(R"EOF(
name: envoy.tls.cert_validator.spiffe
typed_config:
  "@type": type.googleapis.com/envoy.extensions.transport_sockets.tls.v3.SPIFFECertValidatorConfig
  trust_domains:
    - name: lyft.com
      trust_bundle:
        filename: "{{ test_rundir }}/test/common/tls/test_data/ca_cert.pem"
  )EOF");

  X509StorePtr store = X509_STORE_new();
  SSLContextPtr ssl_ctx = SSL_CTX_new(TLS_method());
  // URI SAN = spiffe://lyft.com/test-team
  auto cert = readCertFromFile(
      TestEnvironment::substitute("{{ test_rundir }}/test/common/tls/test_data/san_uri_cert.pem"));
  X509StoreContextPtr store_ctx = X509_STORE_CTX_new();
  EXPECT_TRUE(X509_STORE_CTX_init(store_ctx.get(), store.get(), cert.get(), nullptr));
  bssl::UniquePtr<STACK_OF(X509)> cert_chain(sk_X509_new_null());
  sk_X509_push(cert_chain.get(), cert.release());
  TestSslExtendedSocketInfo info;
  info.setCertificateValidationStatus(Envoy::Ssl::ClientValidationStatus::NotValidated);
  {
    envoy::type::matcher::v3::StringMatcher matcher;
    matcher.set_prefix("spiffe://lyft.com/");
    setSanMatchers({matcher});
    ASSERT_OK(initialize(config));
    ValidationResults results = validator().doVerifyCertChain(
        *cert_chain, info.createValidateResultCallback(),
        /*transport_socket_options=*/nullptr, *ssl_ctx, {}, false, "");
    EXPECT_EQ(ValidationResults::ValidationStatus::Successful, results.status);
    EXPECT_EQ(Envoy::Ssl::ClientValidationStatus::Validated, results.detailed_status);
  }
  {
    envoy::type::matcher::v3::StringMatcher matcher;
    matcher.set_prefix("spiffe://example.com/");
    setSanMatchers({matcher});
    ASSERT_OK(initialize(config));
    ValidationResults results = validator().doVerifyCertChain(
        *cert_chain, info.createValidateResultCallback(),
        /*transport_socket_options=*/nullptr, *ssl_ctx, {}, false, "");
    EXPECT_EQ(ValidationResults::ValidationStatus::Failed, results.status);
    EXPECT_EQ(Envoy::Ssl::ClientValidationStatus::Failed, results.detailed_status);
    EXPECT_EQ(1, stats().fail_verify_san_.value());
    stats().fail_verify_san_.reset();
  }
}

TEST_F(TestSPIFFEValidator, TestDoVerifyCertChainWithSanOverride) {
  const auto config = TestEnvironment::substitute(R"EOF(
name: envoy.tls.cert_validator.spiffe
typed_config:
  "@type": type.googleapis.com/envoy.extensions.transport_sockets.tls.v3.SPIFFECertValidatorConfig
  trust_domains:
    - name: lyft.com
      trust_bundle:
        filename: "{{ test_rundir }}/test/common/tls/test_data/ca_cert.pem"
  )EOF");

  X509StorePtr store = X509_STORE_new();
  SSLContextPtr ssl_ctx = SSL_CTX_new(TLS_method());
  // URI SAN = spiffe://lyft.com/test-team
  auto cert = readCertFromFile(
      TestEnvironment::substitute("{{ test_rundir }}/test/common/tls/test_data/san_uri_cert.pem"));
  bssl::UniquePtr<STACK_OF(X509)> cert_chain(sk_X509_new_null());
  sk_X509_push(cert_chain.get(), cert.release());
  TestSslExtendedSocketInfo info;
  info.setCertificateValidationStatus(Envoy::Ssl::ClientValidationStatus::NotValidated);

  {
    // Override matches URI SAN.
    std::vector<std::string> expected_sans = {"spiffe://lyft.com/test-team"};
    auto socket_options =
        std::make_shared<Network::TransportSocketOptionsImpl>("", std::move(expected_sans));

    ASSERT_OK(initialize(config));
    EXPECT_EQ(ValidationResults::ValidationStatus::Successful,
              validator()
                  .doVerifyCertChain(*cert_chain, info.createValidateResultCallback(),
                                     socket_options, *ssl_ctx, {}, false, "")
                  .status);
  }

  {
    // Override does not match URI SAN.
    std::vector<std::string> expected_sans = {"spiffe://lyft.com/wrong-team"};
    auto socket_options =
        std::make_shared<Network::TransportSocketOptionsImpl>("", std::move(expected_sans));

    ASSERT_OK(initialize(config));
    auto results = validator().doVerifyCertChain(*cert_chain, info.createValidateResultCallback(),
                                                 socket_options, *ssl_ctx, {}, false, "");
    EXPECT_EQ(ValidationResults::ValidationStatus::Failed, results.status);
    EXPECT_TRUE(results.error_details.has_value());
    EXPECT_THAT(results.error_details.value(), HasSubstr("URI SAN peer identity mismatches"));
    EXPECT_EQ(1, stats().fail_verify_san_.value());
    stats().fail_verify_san_.reset();
  }
}

TEST_F(TestSPIFFEValidator, TestDoVerifyCertChainWithSanOverrideAndMatchers) {
  const auto config = TestEnvironment::substitute(R"EOF(
name: envoy.tls.cert_validator.spiffe
typed_config:
  "@type": type.googleapis.com/envoy.extensions.transport_sockets.tls.v3.SPIFFECertValidatorConfig
  trust_domains:
    - name: lyft.com
      trust_bundle:
        filename: "{{ test_rundir }}/test/common/tls/test_data/ca_cert.pem"
  )EOF");

  X509StorePtr store = X509_STORE_new();
  SSLContextPtr ssl_ctx = SSL_CTX_new(TLS_method());
  // URI SAN = spiffe://lyft.com/test-team
  auto cert = readCertFromFile(
      TestEnvironment::substitute("{{ test_rundir }}/test/common/tls/test_data/san_uri_cert.pem"));
  bssl::UniquePtr<STACK_OF(X509)> cert_chain(sk_X509_new_null());
  sk_X509_push(cert_chain.get(), cert.release());
  TestSslExtendedSocketInfo info;
  info.setCertificateValidationStatus(Envoy::Ssl::ClientValidationStatus::NotValidated);

  {
    // Both override and matcher match.
    envoy::type::matcher::v3::StringMatcher matcher;
    matcher.set_prefix("spiffe://lyft.com/");
    setSanMatchers({matcher});
    ASSERT_OK(initialize(config));

    std::vector<std::string> expected_sans = {"spiffe://lyft.com/test-team"};
    auto socket_options =
        std::make_shared<Network::TransportSocketOptionsImpl>("", std::move(expected_sans));

    EXPECT_EQ(ValidationResults::ValidationStatus::Successful,
              validator()
                  .doVerifyCertChain(*cert_chain, info.createValidateResultCallback(),
                                     socket_options, *ssl_ctx, {}, false, "")
                  .status);
  }

  {
    // Override matches, matcher does not match.
    envoy::type::matcher::v3::StringMatcher matcher;
    matcher.set_prefix("spiffe://example.com/");
    setSanMatchers({matcher});
    ASSERT_OK(initialize(config));

    std::vector<std::string> expected_sans = {"spiffe://lyft.com/test-team"};
    auto socket_options =
        std::make_shared<Network::TransportSocketOptionsImpl>("", std::move(expected_sans));

    auto results = validator().doVerifyCertChain(*cert_chain, info.createValidateResultCallback(),
                                                 socket_options, *ssl_ctx, {}, false, "");
    EXPECT_EQ(ValidationResults::ValidationStatus::Failed, results.status);
    EXPECT_TRUE(results.error_details.has_value());
    EXPECT_THAT(results.error_details.value(), HasSubstr("verify cert failed: SAN match"));
    EXPECT_EQ(1, stats().fail_verify_san_.value());
    stats().fail_verify_san_.reset();
  }

  {
    // Matcher matches, override does not match.
    envoy::type::matcher::v3::StringMatcher matcher;
    matcher.set_prefix("spiffe://lyft.com/");
    setSanMatchers({matcher});
    ASSERT_OK(initialize(config));

    std::vector<std::string> expected_sans = {"spiffe://lyft.com/wrong-team"};
    auto socket_options =
        std::make_shared<Network::TransportSocketOptionsImpl>("", std::move(expected_sans));

    auto results = validator().doVerifyCertChain(*cert_chain, info.createValidateResultCallback(),
                                                 socket_options, *ssl_ctx, {}, false, "");
    EXPECT_EQ(ValidationResults::ValidationStatus::Failed, results.status);
    EXPECT_TRUE(results.error_details.has_value());
    EXPECT_THAT(results.error_details.value(), HasSubstr("URI SAN peer identity mismatches"));
    EXPECT_EQ(1, stats().fail_verify_san_.value());
    stats().fail_verify_san_.reset();
  }
}

TEST_F(TestSPIFFEValidator, TestDoVerifyCertChainWithSanOverrideDisabled) {
  const auto config = TestEnvironment::substitute(R"EOF(
name: envoy.tls.cert_validator.spiffe
typed_config:
  "@type": type.googleapis.com/envoy.extensions.transport_sockets.tls.v3.SPIFFECertValidatorConfig
  trust_domains:
    - name: lyft.com
      trust_bundle:
        filename: "{{ test_rundir }}/test/common/tls/test_data/ca_cert.pem"
  )EOF");

  X509StorePtr store = X509_STORE_new();
  SSLContextPtr ssl_ctx = SSL_CTX_new(TLS_method());
  // URI SAN = spiffe://lyft.com/test-team
  auto cert = readCertFromFile(
      TestEnvironment::substitute("{{ test_rundir }}/test/common/tls/test_data/san_uri_cert.pem"));
  bssl::UniquePtr<STACK_OF(X509)> cert_chain(sk_X509_new_null());
  sk_X509_push(cert_chain.get(), cert.release());
  TestSslExtendedSocketInfo info;
  info.setCertificateValidationStatus(Envoy::Ssl::ClientValidationStatus::NotValidated);

  // Disable the runtime flag.
  TestScopedRuntime scoped_runtime;
  scoped_runtime.mergeValues(
      {{"envoy.reloadable_features.spiffe_validator_use_upstream_subject_alt_names", "false"}});

  // Even if override is wrong, it should succeed because override is ignored and there are no
  // config matchers.
  std::vector<std::string> expected_sans = {"spiffe://lyft.com/wrong-team"};
  auto socket_options =
      std::make_shared<Network::TransportSocketOptionsImpl>("", std::move(expected_sans));

  ASSERT_OK(initialize(config));
  EXPECT_EQ(ValidationResults::ValidationStatus::Successful,
            validator()
                .doVerifyCertChain(*cert_chain, info.createValidateResultCallback(), socket_options,
                                   *ssl_ctx, {}, false, "")
                .status);
}

TEST_F(TestSPIFFEValidator, TestDoVerifyCertChainIntermediateCerts) {
  ASSERT_OK(initialize(TestEnvironment::substitute(R"EOF(
name: envoy.tls.cert_validator.spiffe
typed_config:
  "@type": type.googleapis.com/envoy.extensions.transport_sockets.tls.v3.SPIFFECertValidatorConfig
  trust_domains:
    - name: example.com
      trust_bundle:
        filename: "{{ test_rundir }}/test/common/tls/test_data/ca_cert.pem"
  )EOF")));

  TestSslExtendedSocketInfo info;
  // Chain contains workload, intermediate, and ca cert, so it should be accepted.
  auto cert =
      readCertFromFile(TestEnvironment::substitute("{{ test_rundir }}/test/common/tls/test_data/"
                                                   "spiffe_san_signed_by_intermediate_cert.pem"));
  auto intermediate_ca_cert =
      readCertFromFile(TestEnvironment::substitute("{{ test_rundir }}/test/common/tls/test_data/"
                                                   "intermediate_ca_cert.pem"));

  SSLContextPtr ssl_ctx = SSL_CTX_new(TLS_method());
  bssl::UniquePtr<STACK_OF(X509)> cert_chain(sk_X509_new_null());
  sk_X509_push(cert_chain.get(), cert.release());
  sk_X509_push(cert_chain.get(), intermediate_ca_cert.release());
  EXPECT_EQ(ValidationResults::ValidationStatus::Successful,
            validator()
                .doVerifyCertChain(*cert_chain, info.createValidateResultCallback(),
                                   /*transport_socket_options=*/nullptr, *ssl_ctx, {}, false, "")
                .status);
}

void addIA5StringGenNameExt(X509* cert, int type, const std::string name) {
  GeneralNamesPtr gens = sk_GENERAL_NAME_new_null();
  GENERAL_NAME* gen = GENERAL_NAME_new(); // ownership taken by "gens"
  ASN1IA5StringPtr ia5 = ASN1_IA5STRING_new();
  EXPECT_TRUE(ASN1_STRING_set(ia5.get(), name.data(), name.length()));
  GENERAL_NAME_set0_value(gen, type, ia5.release());
  sk_GENERAL_NAME_push(gens.get(), gen);
  EXPECT_TRUE(X509_add1_ext_i2d(cert, NID_subject_alt_name, gens.get(), 0, X509V3_ADD_DEFAULT));
}

TEST_F(TestSPIFFEValidator, TestMatchSubjectAltNameWithURISan) {
  envoy::type::matcher::v3::StringMatcher exact_matcher, prefix_matcher, regex_matcher;
  exact_matcher.set_exact("spiffe://example.com/workload");
  prefix_matcher.set_prefix("spiffe://envoy.com");
  regex_matcher.mutable_safe_regex()->mutable_google_re2();
  regex_matcher.mutable_safe_regex()->set_regex("spiffe:\\/\\/([a-z]+)\\.myorg\\.com\\/.+");
  setSanMatchers({exact_matcher, prefix_matcher, regex_matcher});
  ASSERT_OK(initialize(TestEnvironment::substitute(R"EOF(
name: envoy.tls.cert_validator.spiffe
typed_config:
  "@type": type.googleapis.com/envoy.extensions.transport_sockets.tls.v3.SPIFFECertValidatorConfig
  trust_domains:
    - name: lyft.com
      trust_bundle:
        filename: "{{ test_rundir }}/test/common/tls/test_data/ca_cert.pem"
  )EOF")));

  {
    X509Ptr leaf = X509_new();
    addIA5StringGenNameExt(leaf.get(), GEN_URI, "spiffe://envoy.com/myapp");
    EXPECT_TRUE(validator().matchSubjectAltName(*leaf.get()));
  }
  {
    X509Ptr leaf = X509_new();
    addIA5StringGenNameExt(leaf.get(), GEN_URI, "spiffe://example.com/workload");
    EXPECT_TRUE(validator().matchSubjectAltName(*leaf.get()));
  }
  {
    X509Ptr leaf = X509_new();
    addIA5StringGenNameExt(leaf.get(), GEN_URI, "spiffe://example.com/otherworkload");
    EXPECT_FALSE(validator().matchSubjectAltName(*leaf.get()));
  }
  {
    X509Ptr leaf = X509_new();
    addIA5StringGenNameExt(leaf.get(), GEN_URI, "spiffe://foo.myorg.com/workload");
    EXPECT_TRUE(validator().matchSubjectAltName(*leaf.get()));
  }
  {
    X509Ptr leaf = X509_new();
    addIA5StringGenNameExt(leaf.get(), GEN_URI, "spiffe://bar.myorg.com/workload");
    EXPECT_TRUE(validator().matchSubjectAltName(*leaf.get()));
  }
}

// SPIFFE validator ignores any SANs other than URI.
TEST_F(TestSPIFFEValidator, TestMatchSubjectAltNameWithoutURISan) {
  envoy::type::matcher::v3::StringMatcher exact_matcher, prefix_matcher;
  exact_matcher.set_exact("spiffe://example.com/workload");
  prefix_matcher.set_prefix("envoy");
  setSanMatchers({exact_matcher, prefix_matcher});
  ASSERT_OK(initialize(TestEnvironment::substitute(R"EOF(
name: envoy.tls.cert_validator.spiffe
typed_config:
  "@type": type.googleapis.com/envoy.extensions.transport_sockets.tls.v3.SPIFFECertValidatorConfig
  trust_domains:
    - name: lyft.com
      trust_bundle:
        filename: "{{ test_rundir }}/test/common/tls/test_data/ca_cert.pem"
  )EOF")));

  {
    X509Ptr leaf = X509_new();
    addIA5StringGenNameExt(leaf.get(), GEN_DNS, "envoy.com/workload");
    EXPECT_FALSE(validator().matchSubjectAltName(*leaf.get()));
  }
  {
    X509Ptr leaf = X509_new();
    addIA5StringGenNameExt(leaf.get(), GEN_DNS, "spiffe://example.com/workload");
    EXPECT_FALSE(validator().matchSubjectAltName(*leaf.get()));
  }
  {
    X509Ptr leaf = X509_new();
    addIA5StringGenNameExt(leaf.get(), GEN_EMAIL, "envoy@example.co.jp");
    EXPECT_FALSE(validator().matchSubjectAltName(*leaf.get()));
  }
}

TEST_F(TestSPIFFEValidator, TestGetCaCertInformation) {
  ASSERT_OK(initialize());

  // No cert is set so this should be nullptr.
  EXPECT_FALSE(validator().getCaCertInformation());

  ASSERT_OK(initialize(TestEnvironment::substitute(R"EOF(
name: envoy.tls.cert_validator.spiffe
typed_config:
  "@type": type.googleapis.com/envoy.extensions.transport_sockets.tls.v3.SPIFFECertValidatorConfig
  trust_domains:
    - name: lyft.com
      trust_bundle:
        filename: "{{ test_rundir }}/test/common/tls/test_data/spiffe_san_cert.pem"
    - name: example.com
      trust_bundle:
        filename: "{{ test_rundir }}/test/common/tls/test_data/ca_cert.pem"
  )EOF")));

  auto actual = validator().getCaCertInformation();
  EXPECT_TRUE(actual);
}

TEST_F(TestSPIFFEValidator, TestDaysUntilFirstCertExpires) {
  ASSERT_OK(initialize());
  EXPECT_EQ(std::numeric_limits<uint32_t>::max(), validator().daysUntilFirstCertExpires().value());

  Event::SimulatedTimeSystem time_system;
  time_system.setSystemTime(std::chrono::milliseconds(0));

  ASSERT_OK(initialize(TestEnvironment::substitute(R"EOF(
name: envoy.tls.cert_validator.spiffe
typed_config:
  "@type": type.googleapis.com/envoy.extensions.transport_sockets.tls.v3.SPIFFECertValidatorConfig
  trust_domains:
    - name: lyft.com
      trust_bundle:
        filename: "{{ test_rundir }}/test/common/tls/test_data/spiffe_san_cert.pem"
    - name: example.com
      trust_bundle:
        filename: "{{ test_rundir }}/test/common/tls/test_data/intermediate_ca_cert.pem"
  )EOF"),
                       time_system));
  auto expiry_time =
      TestUtility::parseTime(TEST_INTERMEDIATE_CA_CERT_NOT_AFTER, "%b %d %H:%M:%S %Y GMT");
  int64_t expected_days = absl::ToInt64Hours(expiry_time - absl::UnixEpoch()) / 24;
  EXPECT_EQ(expected_days, validator().daysUntilFirstCertExpires().value());
  time_system.setSystemTime(std::chrono::milliseconds(864000000));
  EXPECT_EQ(expected_days - 10, validator().daysUntilFirstCertExpires().value());
}

TEST_F(TestSPIFFEValidator, TestDaysUntilFirstCertExpiresExpired) {
  Event::SimulatedTimeSystem time_system;
  // 2033-05-18 03:33:20 UTC
  const time_t known_date_time = 2000000000;
  time_system.setSystemTime(std::chrono::system_clock::from_time_t(known_date_time));

  ASSERT_OK(initialize(TestEnvironment::substitute(R"EOF(
name: envoy.tls.cert_validator.spiffe
typed_config:
  "@type": type.googleapis.com/envoy.extensions.transport_sockets.tls.v3.SPIFFECertValidatorConfig
  trust_domains:
    - name: example.com
      trust_bundle:
        filename: "{{ test_rundir }}/test/common/tls/test_data/spiffe_san_cert.pem"
  )EOF"),
                       time_system));

  EXPECT_EQ(std::nullopt, validator().daysUntilFirstCertExpires());
}

TEST_F(TestSPIFFEValidator, TestAddClientValidationContext) {
  Event::TestRealTimeSystem time_system;
  ASSERT_OK(initialize(TestEnvironment::substitute(R"EOF(
name: envoy.tls.cert_validator.spiffe
typed_config:
  "@type": type.googleapis.com/envoy.extensions.transport_sockets.tls.v3.SPIFFECertValidatorConfig
  trust_domains:
    - name: lyft.com
      trust_bundle:
        filename: "{{ test_rundir }}/test/common/tls/test_data/spiffe_san_cert.pem"
    - name: example.com
      trust_bundle:
        filename: "{{ test_rundir }}/test/common/tls/test_data/ca_cert.pem"
    - name: foo.com
      trust_bundle:
        filename: "{{ test_rundir }}/test/common/tls/test_data/ca_cert.pem"
  )EOF"),
                       time_system));

  bool foundTestServer = false;
  bool foundTestCA = false;
  SSLContextPtr ctx = SSL_CTX_new(TLS_method());
  ASSERT_OK(validator().addClientValidationContext(ctx.get(), false));
  for (const X509_NAME* name : SSL_CTX_get_client_CA_list(ctx.get())) {
    const int cn_index = X509_NAME_get_index_by_NID(name, NID_commonName, -1);
    EXPECT_TRUE(cn_index >= 0);
    const X509_NAME_ENTRY* cn_entry = X509_NAME_get_entry(name, cn_index);
    EXPECT_TRUE(cn_entry);
    const ASN1_STRING* cn_asn1 = X509_NAME_ENTRY_get_data(cn_entry);
    EXPECT_TRUE(cn_asn1);

    auto cn_str = std::string(reinterpret_cast<char const*>(ASN1_STRING_get0_data(cn_asn1)),
                              ASN1_STRING_length(cn_asn1));
    if (cn_str == "Test Server") {
      foundTestServer = true;
    } else if (cn_str == "Test CA") {
      foundTestCA = true;
    }
  }

  EXPECT_TRUE(foundTestServer);
  EXPECT_TRUE(foundTestCA);
}

// When suppress_client_ca_list is true, the SPIFFE validator must not populate
// the client CA list on the SSL_CTX so the CA names are not sent in the TLS
// CertificateRequest message.
TEST_F(TestSPIFFEValidator, SuppressClientCaListEnabled) {
  Event::TestRealTimeSystem time_system;
  setSuppressClientCaList(true);
  ASSERT_OK(initialize(TestEnvironment::substitute(R"EOF(
name: envoy.tls.cert_validator.spiffe
typed_config:
  "@type": type.googleapis.com/envoy.extensions.transport_sockets.tls.v3.SPIFFECertValidatorConfig
  trust_domains:
    - name: lyft.com
      trust_bundle:
        filename: "{{ test_rundir }}/test/common/tls/test_data/spiffe_san_cert.pem"
    - name: example.com
      trust_bundle:
        filename: "{{ test_rundir }}/test/common/tls/test_data/ca_cert.pem"
  )EOF"),
                       time_system));

  SSLContextPtr ctx = SSL_CTX_new(TLS_method());
  ASSERT_OK(validator().addClientValidationContext(ctx.get(), false));
  // Depending on BoringSSL version, SSL_CTX_new may leave the list as nullptr or
  // as an empty stack; both satisfy the guarantee that no CA names are advertised.
  STACK_OF(X509_NAME)* ca_list = SSL_CTX_get_client_CA_list(ctx.get());
  if (ca_list != nullptr) {
    EXPECT_EQ(sk_X509_NAME_num(ca_list), 0);
  }
}

// When suppress_client_ca_list is false (the default), the SPIFFE validator
// must continue to populate the client CA list as before.
TEST_F(TestSPIFFEValidator, SuppressClientCaListDisabled) {
  Event::TestRealTimeSystem time_system;
  setSuppressClientCaList(false);
  ASSERT_OK(initialize(TestEnvironment::substitute(R"EOF(
name: envoy.tls.cert_validator.spiffe
typed_config:
  "@type": type.googleapis.com/envoy.extensions.transport_sockets.tls.v3.SPIFFECertValidatorConfig
  trust_domains:
    - name: lyft.com
      trust_bundle:
        filename: "{{ test_rundir }}/test/common/tls/test_data/spiffe_san_cert.pem"
    - name: example.com
      trust_bundle:
        filename: "{{ test_rundir }}/test/common/tls/test_data/ca_cert.pem"
  )EOF"),
                       time_system));

  SSLContextPtr ctx = SSL_CTX_new(TLS_method());
  ASSERT_OK(validator().addClientValidationContext(ctx.get(), false));
  STACK_OF(X509_NAME)* ca_list = SSL_CTX_get_client_CA_list(ctx.get());
  ASSERT_NE(ca_list, nullptr);
  EXPECT_GT(sk_X509_NAME_num(ca_list), 0);
}

TEST_F(TestSPIFFEValidator, TestUpdateDigestForSessionId) {
  Event::TestRealTimeSystem time_system;
  ASSERT_OK(initialize(TestEnvironment::substitute(R"EOF(
name: envoy.tls.cert_validator.spiffe
typed_config:
  "@type": type.googleapis.com/envoy.extensions.transport_sockets.tls.v3.SPIFFECertValidatorConfig
  trust_domains:
    - name: lyft.com
      trust_bundle:
        filename: "{{ test_rundir }}/test/common/tls/test_data/spiffe_san_cert.pem"
    - name: example.com
      trust_bundle:
        filename: "{{ test_rundir }}/test/common/tls/test_data/ca_cert.pem"
  )EOF"),
                       time_system));
  uint8_t hash_buffer[EVP_MAX_MD_SIZE];
  bssl::ScopedEVP_MD_CTX md;
  EVP_DigestInit(md.get(), EVP_sha256());
  validator().updateDigestForSessionId(md, hash_buffer, SHA256_DIGEST_LENGTH);
}

namespace {

// Runs updateDigestForSessionId against the validator and returns the resulting
// digest bytes. Lets tests compare digests produced under different configs.
std::vector<uint8_t> computeSpiffeSessionIdDigest(SPIFFEValidator& validator) {
  bssl::ScopedEVP_MD_CTX md;
  int rc = EVP_DigestInit_ex(md.get(), EVP_sha256(), nullptr);
  RELEASE_ASSERT(rc == 1, "EVP_DigestInit_ex failed");
  uint8_t scratch[EVP_MAX_MD_SIZE];
  validator.updateDigestForSessionId(md, scratch, SHA256_DIGEST_LENGTH);
  std::vector<uint8_t> out(EVP_MAX_MD_SIZE);
  unsigned out_len = 0;
  rc = EVP_DigestFinal_ex(md.get(), out.data(), &out_len);
  RELEASE_ASSERT(rc == 1, "EVP_DigestFinal_ex failed");
  out.resize(out_len);
  return out;
}

} // namespace

// Session ID digest must differ when suppress_client_ca_list differs, to prevent
// session resumption across SPIFFE contexts with different wire behavior.
TEST_F(TestSPIFFEValidator, SuppressClientCaListSessionIdDiffers) {
  Event::TestRealTimeSystem time_system;
  const std::string yaml = TestEnvironment::substitute(R"EOF(
name: envoy.tls.cert_validator.spiffe
typed_config:
  "@type": type.googleapis.com/envoy.extensions.transport_sockets.tls.v3.SPIFFECertValidatorConfig
  trust_domains:
    - name: lyft.com
      trust_bundle:
        filename: "{{ test_rundir }}/test/common/tls/test_data/spiffe_san_cert.pem"
    - name: example.com
      trust_bundle:
        filename: "{{ test_rundir }}/test/common/tls/test_data/ca_cert.pem"
  )EOF");

  setSuppressClientCaList(true);
  ASSERT_OK(initialize(yaml, time_system));
  auto digest_suppressed = computeSpiffeSessionIdDigest(validator());

  setSuppressClientCaList(false);
  ASSERT_OK(initialize(yaml, time_system));
  auto digest_not_suppressed = computeSpiffeSessionIdDigest(validator());

  EXPECT_NE(digest_suppressed, digest_not_suppressed)
      << "Session ID digests must differ when suppress_client_ca_list differs";
}

TEST_F(TestSPIFFEValidator, InvalidTrustBundleMapConfig) {
  {
    EXPECT_THAT(initialize(TestEnvironment::substitute(R"EOF(
name: envoy.tls.cert_validator.spiffe
typed_config:
  "@type": type.googleapis.com/envoy.extensions.transport_sockets.tls.v3.SPIFFECertValidatorConfig
  trust_bundles:
    filename: "{{ test_rundir }}/test/extensions/transport_sockets/tls/cert_validator/spiffe/test_data/trust_bundles_empty_keys.json"
  )EOF")),
                HasStatus(absl::StatusCode::kInvalidArgument,
                          HasSubstr("No keys found in SPIFFE bundle for domain 'example.com'")));
  }
  {
    EXPECT_THAT(
        initialize(TestEnvironment::substitute(R"EOF(
name: envoy.tls.cert_validator.spiffe
typed_config:
  "@type": type.googleapis.com/envoy.extensions.transport_sockets.tls.v3.SPIFFECertValidatorConfig
  trust_bundles:
    filename: "{{ test_rundir }}/test/extensions/transport_sockets/tls/cert_validator/spiffe/test_data/trust_bundles_invalid_key.json"
  )EOF")),
        HasStatus(
            absl::StatusCode::kInvalidArgument,
            HasSubstr("Failed to create x509 object while loading certs in domain 'example.com'")));
  }
  {
    EXPECT_THAT(
        initialize(TestEnvironment::substitute(R"EOF(
name: envoy.tls.cert_validator.spiffe
typed_config:
  "@type": type.googleapis.com/envoy.extensions.transport_sockets.tls.v3.SPIFFECertValidatorConfig
  trust_bundles:
    filename: "{{ test_rundir }}/test/extensions/transport_sockets/tls/cert_validator/spiffe/test_data/trust_bundles_missing_use.json"
  )EOF")),
        HasStatus(
            absl::StatusCode::kInvalidArgument,
            HasSubstr("missing or invalid 'use' field found in cert for domain 'example.com'")));
  }
  {
    EXPECT_THAT(initialize(TestEnvironment::substitute(R"EOF(
name: envoy.tls.cert_validator.spiffe
typed_config:
  "@type": type.googleapis.com/envoy.extensions.transport_sockets.tls.v3.SPIFFECertValidatorConfig
  trust_bundles:
    filename: "{{ test_rundir }}/test/extensions/transport_sockets/tls/cert_validator/spiffe/test_data/trust_bundles_invalid_json.json"
  )EOF")),
                HasStatus(absl::StatusCode::kInvalidArgument,
                          HasSubstr("Invalid JSON found in SPIFFE bundle")));
  }
  {
    EXPECT_THAT(initialize(TestEnvironment::substitute(R"EOF(
name: envoy.tls.cert_validator.spiffe
typed_config:
  "@type": type.googleapis.com/envoy.extensions.transport_sockets.tls.v3.SPIFFECertValidatorConfig
  trust_bundles:
    filename: "{{ test_rundir }}/test/extensions/transport_sockets/tls/cert_validator/spiffe/test_data/trust_bundles_zero_domains.json"
  )EOF")),
                HasStatus(absl::StatusCode::kInvalidArgument,
                          HasSubstr("No trust domains found in SPIFFE bundle")));
  }
  {
    EXPECT_THAT(
        initialize(TestEnvironment::substitute(R"EOF(
name: envoy.tls.cert_validator.spiffe
typed_config:
  "@type": type.googleapis.com/envoy.extensions.transport_sockets.tls.v3.SPIFFECertValidatorConfig
  trust_bundles:
    filename: "{{ test_rundir }}/test/extensions/transport_sockets/tls/cert_validator/spiffe/test_data/trust_bundles_missing_x5c.json"
  )EOF")),
        HasStatus(
            absl::StatusCode::kInvalidArgument,
            HasSubstr("missing or empty 'x5c' field found in keys for domain: 'example.com'")));
  }
  {
    EXPECT_THAT(initialize(TestEnvironment::substitute(R"EOF(
name: envoy.tls.cert_validator.spiffe
typed_config:
  "@type": type.googleapis.com/envoy.extensions.transport_sockets.tls.v3.SPIFFECertValidatorConfig
  trust_bundles:
    filename: "{{ test_rundir }}/test/extensions/transport_sockets/tls/cert_validator/spiffe/test_data/trust_bundles_invalid_x5c.json"
  )EOF")),
                HasStatus(absl::StatusCode::kInvalidArgument,
                          HasSubstr("Invalid x509 object in certs for domain 'example.com'")));
  }
}

TEST_F(TestSPIFFEValidator, TestDoVerifyCertChainMultipleTrustDomainBundleMappingInline) {
  auto trust_bundle_path =
      TestEnvironment::substitute("{{ test_rundir }}/test/common/tls/test_data/trust_bundles.json");
  auto trust_bundle_str =
      escapeJson(compactJson(TestEnvironment::readFileToStringForTest(trust_bundle_path)));

  auto config_str = fmt::format(R"EOF(
name: envoy.tls.cert_validator.spiffe
typed_config:
  "@type": type.googleapis.com/envoy.extensions.transport_sockets.tls.v3.SPIFFECertValidatorConfig
  trust_bundles:
    inline_string: "{}"
  )EOF",
                                trust_bundle_str);

  ASSERT_OK(initialize(config_str));

  X509StorePtr store = X509_STORE_new();
  SSLContextPtr ssl_ctx = SSL_CTX_new(TLS_method());
  TestSslExtendedSocketInfo info;
  {
    // Trust domain matches so should be accepted.
    auto cert = readCertFromFile(TestEnvironment::substitute(
        "{{ test_rundir }}/test/common/tls/test_data/san_uri_cert.pem"));
    bssl::UniquePtr<STACK_OF(X509)> cert_chain(sk_X509_new_null());
    sk_X509_push(cert_chain.get(), cert.release());
    EXPECT_EQ(ValidationResults::ValidationStatus::Successful,
              validator()
                  .doVerifyCertChain(*cert_chain, info.createValidateResultCallback(),
                                     /*transport_socket_options=*/nullptr, *ssl_ctx, {}, false, "")
                  .status);
  }

  {
    auto cert = readCertFromFile(TestEnvironment::substitute(
        "{{ test_rundir }}/test/common/tls/test_data/spiffe_san_cert.pem"));
    bssl::UniquePtr<STACK_OF(X509)> cert_chain(sk_X509_new_null());
    sk_X509_push(cert_chain.get(), cert.release());
    EXPECT_EQ(ValidationResults::ValidationStatus::Successful,
              validator()
                  .doVerifyCertChain(*cert_chain, info.createValidateResultCallback(),
                                     /*transport_socket_options=*/nullptr, *ssl_ctx, {}, false, "")
                  .status);
  }

  {
    // Trust domain matches but it has expired.
    auto cert = readCertFromFile(
        TestEnvironment::substitute("{{ test_rundir "
                                    "}}/test/common/tls/test_data/expired_spiffe_san_cert.pem"));
    bssl::UniquePtr<STACK_OF(X509)> cert_chain(sk_X509_new_null());
    sk_X509_push(cert_chain.get(), cert.release());
    EXPECT_EQ(ValidationResults::ValidationStatus::Failed,
              validator()
                  .doVerifyCertChain(*cert_chain, info.createValidateResultCallback(),
                                     /*transport_socket_options=*/nullptr, *ssl_ctx, {}, false, "")
                  .status);
  }

  {
    // Does not have san.
    auto cert = readCertFromFile(TestEnvironment::substitute(
        "{{ test_rundir }}/test/common/tls/test_data/extensions_cert.pem"));
    bssl::UniquePtr<STACK_OF(X509)> cert_chain(sk_X509_new_null());
    sk_X509_push(cert_chain.get(), cert.release());
    EXPECT_EQ(ValidationResults::ValidationStatus::Failed,
              validator()
                  .doVerifyCertChain(*cert_chain, info.createValidateResultCallback(),
                                     /*transport_socket_options=*/nullptr, *ssl_ctx, {}, false, "")
                  .status);
  }

  EXPECT_EQ(2, stats().fail_verify_error_.value());
}

TEST_F(TestSPIFFEValidator, TestDoVerifyCertChainMultipleTrustDomainBundleMapping) {
  ASSERT_OK(initialize(TestEnvironment::substitute(R"EOF(
name: envoy.tls.cert_validator.spiffe
typed_config:
  "@type": type.googleapis.com/envoy.extensions.transport_sockets.tls.v3.SPIFFECertValidatorConfig
  trust_bundles:
    filename: "{{ test_rundir }}/test/common/tls/test_data/trust_bundles.json"
  )EOF"),
                       "trust_bundles.json"));

  X509StorePtr store = X509_STORE_new();
  SSLContextPtr ssl_ctx = SSL_CTX_new(TLS_method());
  TestSslExtendedSocketInfo info;
  {
    // Trust domain matches so should be accepted.
    auto cert = readCertFromFile(TestEnvironment::substitute(
        "{{ test_rundir }}/test/common/tls/test_data/san_uri_cert.pem"));
    bssl::UniquePtr<STACK_OF(X509)> cert_chain(sk_X509_new_null());
    sk_X509_push(cert_chain.get(), cert.release());
    EXPECT_EQ(ValidationResults::ValidationStatus::Successful,
              validator()
                  .doVerifyCertChain(*cert_chain, info.createValidateResultCallback(),
                                     /*transport_socket_options=*/nullptr, *ssl_ctx, {}, false, "")
                  .status);
  }

  {
    auto cert = readCertFromFile(TestEnvironment::substitute(
        "{{ test_rundir }}/test/common/tls/test_data/spiffe_san_cert.pem"));
    bssl::UniquePtr<STACK_OF(X509)> cert_chain(sk_X509_new_null());
    sk_X509_push(cert_chain.get(), cert.release());
    EXPECT_EQ(ValidationResults::ValidationStatus::Successful,
              validator()
                  .doVerifyCertChain(*cert_chain, info.createValidateResultCallback(),
                                     /*transport_socket_options=*/nullptr, *ssl_ctx, {}, false, "")
                  .status);
  }

  {
    // Trust domain matches but it has expired.
    auto cert = readCertFromFile(
        TestEnvironment::substitute("{{ test_rundir "
                                    "}}/test/common/tls/test_data/expired_spiffe_san_cert.pem"));
    bssl::UniquePtr<STACK_OF(X509)> cert_chain(sk_X509_new_null());
    sk_X509_push(cert_chain.get(), cert.release());
    EXPECT_EQ(ValidationResults::ValidationStatus::Failed,
              validator()
                  .doVerifyCertChain(*cert_chain, info.createValidateResultCallback(),
                                     /*transport_socket_options=*/nullptr, *ssl_ctx, {}, false, "")
                  .status);
  }

  {
    // Does not have san.
    auto cert = readCertFromFile(TestEnvironment::substitute(
        "{{ test_rundir }}/test/common/tls/test_data/extensions_cert.pem"));
    bssl::UniquePtr<STACK_OF(X509)> cert_chain(sk_X509_new_null());
    sk_X509_push(cert_chain.get(), cert.release());
    EXPECT_EQ(ValidationResults::ValidationStatus::Failed,
              validator()
                  .doVerifyCertChain(*cert_chain, info.createValidateResultCallback(),
                                     /*transport_socket_options=*/nullptr, *ssl_ctx, {}, false, "")
                  .status);
  }

  EXPECT_EQ(2, stats().fail_verify_error_.value());
}

TEST_F(TestSPIFFEValidator, TestDoVerifyCertChainIntermediateCertsBundleMapping) {
  ASSERT_OK(initialize(TestEnvironment::substitute(R"EOF(
name: envoy.tls.cert_validator.spiffe
typed_config:
  "@type": type.googleapis.com/envoy.extensions.transport_sockets.tls.v3.SPIFFECertValidatorConfig
  trust_bundles:
    filename: "{{ test_rundir }}/test/common/tls/test_data/trust_bundles.json"
  )EOF"),
                       "trust_bundles.json"));

  TestSslExtendedSocketInfo info;
  // Chain contains workload, intermediate, and ca cert, so it should be accepted.
  auto cert =
      readCertFromFile(TestEnvironment::substitute("{{ test_rundir }}/test/common/tls/test_data/"
                                                   "spiffe_san_signed_by_intermediate_cert.pem"));
  auto intermediate_ca_cert =
      readCertFromFile(TestEnvironment::substitute("{{ test_rundir }}/test/common/tls/test_data/"
                                                   "intermediate_ca_cert.pem"));

  SSLContextPtr ssl_ctx = SSL_CTX_new(TLS_method());
  bssl::UniquePtr<STACK_OF(X509)> cert_chain(sk_X509_new_null());
  sk_X509_push(cert_chain.get(), cert.release());
  sk_X509_push(cert_chain.get(), intermediate_ca_cert.release());
  EXPECT_EQ(ValidationResults::ValidationStatus::Successful,
            validator()
                .doVerifyCertChain(*cert_chain, info.createValidateResultCallback(),
                                   /*transport_socket_options=*/nullptr, *ssl_ctx, {}, false, "")
                .status);
}

TEST_F(TestSPIFFEValidator, TestDoVerifyCertChainSANMatchingTrustBundleMapping) {
  const auto config = TestEnvironment::substitute(R"EOF(
name: envoy.tls.cert_validator.spiffe
typed_config:
  "@type": type.googleapis.com/envoy.extensions.transport_sockets.tls.v3.SPIFFECertValidatorConfig
  trust_bundles:
    filename: "{{ test_rundir }}/test/common/tls/test_data/trust_bundles.json"
  )EOF");

  X509StorePtr store = X509_STORE_new();
  SSLContextPtr ssl_ctx = SSL_CTX_new(TLS_method());
  // URI SAN = spiffe://lyft.com/test-team
  auto cert = readCertFromFile(
      TestEnvironment::substitute("{{ test_rundir }}/test/common/tls/test_data/san_uri_cert.pem"));
  X509StoreContextPtr store_ctx = X509_STORE_CTX_new();
  EXPECT_TRUE(X509_STORE_CTX_init(store_ctx.get(), store.get(), cert.get(), nullptr));
  bssl::UniquePtr<STACK_OF(X509)> cert_chain(sk_X509_new_null());
  sk_X509_push(cert_chain.get(), cert.release());
  TestSslExtendedSocketInfo info;
  info.setCertificateValidationStatus(Envoy::Ssl::ClientValidationStatus::NotValidated);
  {
    envoy::type::matcher::v3::StringMatcher matcher;
    matcher.set_prefix("spiffe://lyft.com/");
    setSanMatchers({matcher});
    ASSERT_OK(initialize(config, "trust_bundles.json"));
    ValidationResults results = validator().doVerifyCertChain(
        *cert_chain, info.createValidateResultCallback(),
        /*transport_socket_options=*/nullptr, *ssl_ctx, {}, false, "");
    EXPECT_EQ(ValidationResults::ValidationStatus::Successful, results.status);
    EXPECT_EQ(Envoy::Ssl::ClientValidationStatus::Validated, results.detailed_status);
  }
  {
    envoy::type::matcher::v3::StringMatcher matcher;
    matcher.set_prefix("spiffe://example.com/");
    setSanMatchers({matcher});
    ASSERT_OK(initialize(config, "trust_bundles.json"));
    ValidationResults results = validator().doVerifyCertChain(
        *cert_chain, info.createValidateResultCallback(),
        /*transport_socket_options=*/nullptr, *ssl_ctx, {}, false, "");
    EXPECT_EQ(ValidationResults::ValidationStatus::Failed, results.status);
    EXPECT_EQ(Envoy::Ssl::ClientValidationStatus::Failed, results.detailed_status);
    EXPECT_EQ(1, stats().fail_verify_san_.value());
    stats().fail_verify_san_.reset();
  }
}

TEST_F(TestSPIFFEValidator, SpiffeCaExpirationMetrics) {
  ASSERT_OK(initialize(TestEnvironment::substitute(R"EOF(
name: envoy.tls.cert_validator.spiffe
typed_config:
  "@type": type.googleapis.com/envoy.extensions.transport_sockets.tls.v3.SPIFFECertValidatorConfig
  trust_domains:
    - name: example.com
      trust_bundle:
        filename: "{{ test_rundir }}/test/common/tls/test_data/ca_cert.pem"
  )EOF")));

  std::string expected_metric_name =
      "ssl.certificate.TEST_CA_CERT_NAME_0.expiration_unix_time_seconds";

  auto cert_expiry = TestUtility::parseTime(TEST_CA_CERT_NOT_AFTER, "%b %d %H:%M:%S %Y GMT");
  uint64_t expected_expiry = absl::ToUnixSeconds(cert_expiry);

  auto gauge_opt = store().findGaugeByString(expected_metric_name);
  EXPECT_TRUE(gauge_opt.has_value());
  EXPECT_EQ(gauge_opt->get().value(), expected_expiry);
}

// Verify that a URI SAN matcher with an unregistered custom string matcher extension
// fails during SPIFFE validator construction.
TEST_F(TestSPIFFEValidator, InvalidCustomMatcherInSanMatcher) {
  envoy::extensions::transport_sockets::tls::v3::SubjectAltNameMatcher san_matcher;
  san_matcher.set_san_type(
      envoy::extensions::transport_sockets::tls::v3::SubjectAltNameMatcher::URI);
  auto* custom = san_matcher.mutable_matcher()->mutable_custom();
  custom->set_name("unregistered_custom_matcher");
  custom->mutable_typed_config()->set_type_url("type.googleapis.com/nonexistent.Type");
  addSanMatcher(san_matcher);

  EXPECT_THROW_WITH_REGEX((void)initialize(TestEnvironment::substitute(R"EOF(
name: envoy.tls.cert_validator.spiffe
typed_config:
  "@type": type.googleapis.com/envoy.extensions.transport_sockets.tls.v3.SPIFFECertValidatorConfig
  trust_domains:
    - name: hello.com
      trust_bundle:
        filename: "{{ test_rundir }}/test/common/tls/test_data/ca_cert.pem"
  )EOF")),
                          EnvoyException, "Didn't find a registered implementation");
}

} // namespace Tls
} // namespace TransportSockets
} // namespace Extensions
} // namespace Envoy
