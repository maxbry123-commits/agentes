#include "envoy/config/core/v3/extension.pb.h"
#include "envoy/extensions/load_balancing_policies/ring_hash/v3/ring_hash.pb.h"
#include "envoy/extensions/load_balancing_policies/ring_hash/v3/ring_hash.pb.validate.h"

#include "source/extensions/load_balancing_policies/ring_hash/config.h"

#include "test/mocks/server/server_factory_context.h"
#include "test/mocks/upstream/cluster_info.h"
#include "test/mocks/upstream/priority_set.h"
#include "test/test_common/status_utility.h"

#include "gtest/gtest.h"

namespace Envoy {
namespace Extensions {
namespace LoadBalancingPolicies {
namespace RingHash {
namespace {

TEST(RingHashConfigTest, Validate) {
  NiceMock<Server::Configuration::MockServerFactoryContext> context;
  NiceMock<Upstream::MockClusterInfo> cluster_info;
  NiceMock<Upstream::MockPrioritySet> main_thread_priority_set;
  NiceMock<Upstream::MockPrioritySet> thread_local_priority_set;

  {
    envoy::config::core::v3::TypedExtensionConfig config;
    config.set_name("envoy.load_balancing_policies.ring_hash");
    envoy::extensions::load_balancing_policies::ring_hash::v3::RingHash config_msg;
    std::ignore = config.mutable_typed_config()->PackFrom(config_msg);

    auto& factory = Config::Utility::getAndCheckFactory<Upstream::TypedLoadBalancerFactory>(config);
    EXPECT_EQ("envoy.load_balancing_policies.ring_hash", factory.name());

    auto lb_config = factory.loadConfig(context, *factory.createEmptyConfigProto()).value();
    auto thread_aware_lb =
        factory.create(*lb_config, cluster_info, main_thread_priority_set, context.runtime_loader_,
                       context.api_.random_, context.time_system_);
    EXPECT_NE(nullptr, thread_aware_lb);

    ASSERT_OK(thread_aware_lb->initialize());

    auto thread_local_lb_factory = thread_aware_lb->factory();
    EXPECT_NE(nullptr, thread_local_lb_factory);

    auto thread_local_lb = thread_local_lb_factory->create({thread_local_priority_set, nullptr});
    EXPECT_NE(nullptr, thread_local_lb);
  }

  {
    envoy::config::core::v3::TypedExtensionConfig config;
    config.set_name("envoy.load_balancing_policies.ring_hash");
    envoy::extensions::load_balancing_policies::ring_hash::v3::RingHash config_msg;
    config_msg.mutable_minimum_ring_size()->set_value(4);
    config_msg.mutable_maximum_ring_size()->set_value(2);

    std::ignore = config.mutable_typed_config()->PackFrom(config_msg);

    auto& factory = Config::Utility::getAndCheckFactory<Upstream::TypedLoadBalancerFactory>(config);
    EXPECT_EQ("envoy.load_balancing_policies.ring_hash", factory.name());

    auto messsage_ptr = factory.createEmptyConfigProto();
    messsage_ptr->MergeFrom(config_msg);

    auto message_ptr = factory.createEmptyConfigProto();
    message_ptr->MergeFrom(config_msg);
    auto lb_config = factory.loadConfig(context, *message_ptr).value();

    EXPECT_THROW_WITH_MESSAGE(
        factory.create(*lb_config, cluster_info, main_thread_priority_set, context.runtime_loader_,
                       context.api_.random_, context.time_system_),
        EnvoyException, "ring hash: minimum_ring_size (4) > maximum_ring_size (2)");
  }

  {
    envoy::config::core::v3::TypedExtensionConfig config;
    config.set_name("envoy.load_balancing_policies.ring_hash");
    envoy::extensions::load_balancing_policies::ring_hash::v3::RingHash config_msg;
    config_msg.mutable_minimum_ring_size()->set_value(0);
    auto* hash_policy = config_msg.mutable_consistent_hashing_lb_config()->add_hash_policy();
    *hash_policy->mutable_cookie()->mutable_name() = "test-cookie-name";
    *hash_policy->mutable_cookie()->mutable_path() = "/test/path";
    hash_policy->mutable_cookie()->mutable_ttl()->set_seconds(1000);

    std::ignore = config.mutable_typed_config()->PackFrom(config_msg);

    std::string err;
    EXPECT_EQ(Validate(config_msg, &err), false);
    EXPECT_EQ(err, "RingHashValidationError.MinimumRingSize: value must be "
                   "inside range [1, 8388608]");
  }
}

} // namespace
} // namespace RingHash
} // namespace LoadBalancingPolicies
} // namespace Extensions
} // namespace Envoy
