#include <chrono>
#include <cstdint>
#include <numeric>

#include "envoy/config/endpoint/v3/endpoint_components.pb.h"

#include "source/common/common/base64.h"
#include "source/common/http/utility.h"
#include "source/common/protobuf/protobuf.h"
#include "source/extensions/load_balancing_policies/maglev/config.h"

#include "test/integration/http_integration.h"

#include "absl/strings/substitute.h"
#include "gtest/gtest.h"

namespace Envoy {
namespace Extensions {
namespace LoadBalancingPolicies {
namespace Maglev {
namespace {

class MaglevIntegrationTest
    : public testing::TestWithParam<std::tuple<Network::Address::IpVersion, uint32_t>>,
      public HttpIntegrationTest {
public:
  static Network::Address::IpVersion getIpVersion() { return std::get<0>(GetParam()); }
  static uint32_t getNumUpstreams() { return std::get<1>(GetParam()); }

  MaglevIntegrationTest() : HttpIntegrationTest(Http::CodecType::HTTP1, getIpVersion()) {
    // Create the desired number of upstream servers for the stateful session test.
    setUpstreamCount(getNumUpstreams());

    config_helper_.addConfigModifier(
        [](envoy::extensions::filters::network::http_connection_manager::v3::HttpConnectionManager&
               hcm) {
          hcm.mutable_route_config()
              ->mutable_virtual_hosts(0)
              ->mutable_routes(0)
              ->mutable_route()
              ->add_hash_policy()
              ->mutable_header()
              ->set_header_name("x-hash");
        });
  }

  void initializeConfig(bool legacy_api = false) {
    config_helper_.addConfigModifier(
        [legacy_api](envoy::config::bootstrap::v3::Bootstrap& bootstrap) {
          auto* cluster_0 = bootstrap.mutable_static_resources()->mutable_clusters()->Mutable(0);
          ASSERT(cluster_0->name() == "cluster_0");
          auto* endpoint = cluster_0->mutable_load_assignment()->mutable_endpoints()->Mutable(0);

          std::string endpoints_yaml = "lb_endpoints:";
          constexpr absl::string_view single_endpoint = R"EOF(
          - endpoint:
              address:
                socket_address:
                  address: $0
                  port_value: 0
          )EOF";
          for (uint32_t i = 0; i < getNumUpstreams(); ++i) {
            absl::StrAppend(&endpoints_yaml, single_endpoint);
          }

          const std::string local_address = Network::Test::getLoopbackAddressString(getIpVersion());
          TestUtility::loadFromYaml(absl::Substitute(endpoints_yaml, local_address), *endpoint);

          // If legacy API is used, set the LB policy by the old way.
          if (legacy_api) {
            cluster_0->set_lb_policy(envoy::config::cluster::v3::Cluster::MAGLEV);
            cluster_0->mutable_maglev_lb_config();
            return;
          }

          auto* policy = cluster_0->mutable_load_balancing_policy();

          const std::string policy_yaml = R"EOF(
          policies:
          - typed_extension_config:
              name: envoy.load_balancing_policies.maglev
              typed_config:
                "@type": type.googleapis.com/envoy.extensions.load_balancing_policies.maglev.v3.Maglev
                consistent_hashing_lb_config:
                  hash_policy:
                  - header:
                      header_name: x-hash
          )EOF";

          TestUtility::loadFromYaml(policy_yaml, *policy);
        });

    HttpIntegrationTest::initialize();
  }

  std::vector<uint64_t> range(uint64_t bound) {
    std::vector<uint64_t> v(bound);
    std::iota(v.begin(), v.end(), 0);
    return v;
  }

  void runNormalLoadBalancing() {
    std::optional<uint64_t> unique_upstream_index;

    for (uint64_t i = 0; i < 8; i++) {
      codec_client_ = makeHttpConnection(lookupPort("http"));

      Http::TestRequestHeaderMapImpl request_headers{
          {":method", "GET"}, {":path", "/"}, {":scheme", "http"}, {":authority", "example.com"},
          {"x-hash", "hash"},
      };

      auto response = codec_client_->makeRequestWithBody(request_headers, 0);

      auto upstream_index = waitForNextUpstreamRequest(range(getNumUpstreams()));
      ASSERT(upstream_index.has_value());

      if (unique_upstream_index.has_value()) {
        EXPECT_EQ(unique_upstream_index.value(), upstream_index.value());
      } else {
        unique_upstream_index = upstream_index.value();
      }

      upstream_request_->encodeHeaders(default_response_headers_, true);

      ASSERT_TRUE(response->waitForEndStream());

      EXPECT_TRUE(upstream_request_->complete());
      EXPECT_TRUE(response->complete());

      cleanupUpstreamAndDownstream();
    }
  }
};

INSTANTIATE_TEST_SUITE_P(
    IpVersions, MaglevIntegrationTest,
    testing::Combine(testing::ValuesIn(TestEnvironment::getIpVersionsForTest()),
                     testing::Values(1, 3)),
    [](const testing::TestParamInfo<std::tuple<Network::Address::IpVersion, uint32_t>>& params) {
      return absl::StrCat(TestUtility::ipVersionToString(std::get<0>(params.param)),
                          std::get<1>(params.param), "Upstreams");
    });

TEST_P(MaglevIntegrationTest, NormalLoadBalancing) {
  initializeConfig();
  runNormalLoadBalancing();
}

TEST_P(MaglevIntegrationTest, NormalLoadBalancingWithLegacyAPI) {
  initializeConfig(true);
  runNormalLoadBalancing();
}

} // namespace
} // namespace Maglev
} // namespace LoadBalancingPolicies
} // namespace Extensions
} // namespace Envoy
