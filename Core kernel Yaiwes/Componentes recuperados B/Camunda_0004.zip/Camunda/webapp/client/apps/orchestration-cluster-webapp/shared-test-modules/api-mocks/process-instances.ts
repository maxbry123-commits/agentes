/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

import type {CreateProcessInstanceResponseBody} from '@camunda/camunda-api-zod-schemas/8.10';

function createProcessInstanceResponse(
	overrides?: Partial<CreateProcessInstanceResponseBody>,
): CreateProcessInstanceResponseBody {
	return {
		processDefinitionId: 'my-process',
		processDefinitionVersion: 1,
		processDefinitionKey: '2251799813685279',
		processInstanceKey: '2251799813685280',
		tenantId: '<default>',
		variables: null,
		businessId: null,
		...overrides,
	};
}

export {createProcessInstanceResponse};
