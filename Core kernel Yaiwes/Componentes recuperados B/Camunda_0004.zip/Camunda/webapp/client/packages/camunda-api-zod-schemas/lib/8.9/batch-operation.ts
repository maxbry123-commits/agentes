/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

import {z} from 'zod';
import {
	API_VERSION,
	basicStringFilterSchema,
	getEnumFilterSchema,
	getQueryRequestBodySchema,
	getQueryResponseBodySchema,
	type Endpoint,
} from './common';

const batchOperationTypeSchema = z.enum([
	'CANCEL_PROCESS_INSTANCE',
	'RESOLVE_INCIDENT',
	'MIGRATE_PROCESS_INSTANCE',
	'MODIFY_PROCESS_INSTANCE',
	'DELETE_DECISION_DEFINITION',
	'DELETE_DECISION_INSTANCE',
	'DELETE_PROCESS_DEFINITION',
	'DELETE_PROCESS_INSTANCE',
	'ADD_VARIABLE',
	'UPDATE_VARIABLE',
]);
type BatchOperationType = z.infer<typeof batchOperationTypeSchema>;

const batchOperationStateSchema = z.enum([
	'CREATED',
	'ACTIVE',
	'SUSPENDED',
	'COMPLETED',
	'PARTIALLY_COMPLETED',
	'CANCELED',
	'FAILED',
]);
type BatchOperationState = z.infer<typeof batchOperationStateSchema>;

const batchOperationItemStateSchema = z.enum(['ACTIVE', 'COMPLETED', 'SKIPPED', 'CANCELED', 'FAILED']);
type BatchOperationItemState = z.infer<typeof batchOperationItemStateSchema>;

const batchOperationErrorTypeSchema = z.enum(['QUERY_FAILED', 'RESULT_BUFFER_SIZE_EXCEEDED']);
type BatchOperationErrorType = z.infer<typeof batchOperationErrorTypeSchema>;

const batchOperationErrorSchema = z.object({
	partitionId: z.number().int(),
	type: batchOperationErrorTypeSchema,
	message: z.string(),
});
type BatchOperationError = z.infer<typeof batchOperationErrorSchema>;

const batchOperationSchema = z.object({
	batchOperationKey: z.string(),
	state: batchOperationStateSchema,
	batchOperationType: batchOperationTypeSchema,
	startDate: z.string(),
	endDate: z.string().nullable(),
	actorType: z.string().nullable(),
	actorId: z.string().nullable(),
	operationsTotalCount: z.number().int(),
	operationsFailedCount: z.number().int(),
	operationsCompletedCount: z.number().int(),
	errors: z.array(batchOperationErrorSchema),
});
type BatchOperation = z.infer<typeof batchOperationSchema>;

const batchOperationItemSchema = z.object({
	batchOperationKey: z.string(),
	itemKey: z.string(),
	processInstanceKey: z.string(),
	rootProcessInstanceKey: z.string().nullable(),
	state: batchOperationItemStateSchema,
	processedDate: z.string().nullable(),
	errorMessage: z.string().nullable(),
	operationType: batchOperationTypeSchema,
});
type BatchOperationItem = z.infer<typeof batchOperationItemSchema>;

const queryBatchOperationsRequestBodySchema = getQueryRequestBodySchema({
	sortFields: ['batchOperationKey', 'operationType', 'state', 'startDate', 'endDate', 'actorId'] as const,
	filter: z
		.object({
			batchOperationKey: basicStringFilterSchema,
			operationType: getEnumFilterSchema(batchOperationTypeSchema),
			state: getEnumFilterSchema(batchOperationStateSchema),
		})
		.partial(),
});
type QueryBatchOperationsRequestBody = z.infer<typeof queryBatchOperationsRequestBodySchema>;

const queryBatchOperationsResponseBodySchema = getQueryResponseBodySchema(batchOperationSchema);
type QueryBatchOperationsResponseBody = z.infer<typeof queryBatchOperationsResponseBodySchema>;

const queryBatchOperationItemsRequestBodySchema = getQueryRequestBodySchema({
	sortFields: ['batchOperationKey', 'itemKey', 'processedDate', 'processInstanceKey', 'state'] as const,
	filter: z
		.object({
			batchOperationKey: basicStringFilterSchema,
			itemKey: basicStringFilterSchema,
			processInstanceKey: basicStringFilterSchema,
			state: getEnumFilterSchema(batchOperationItemStateSchema),
			operationType: getEnumFilterSchema(batchOperationTypeSchema),
		})
		.partial(),
});
type QueryBatchOperationItemsRequestBody = z.infer<typeof queryBatchOperationItemsRequestBodySchema>;

const queryBatchOperationItemsResponseBodySchema = getQueryResponseBodySchema(batchOperationItemSchema);
type QueryBatchOperationItemsResponseBody = z.infer<typeof queryBatchOperationItemsResponseBodySchema>;

const getBatchOperation = {
	method: 'GET',
	getUrl: ({batchOperationKey}) => `/${API_VERSION}/batch-operations/${batchOperationKey}` as const,
} as const satisfies Endpoint<{batchOperationKey: string}>;

const queryBatchOperations = {
	method: 'POST',
	getUrl: () => `/${API_VERSION}/batch-operations/search` as const,
} as const satisfies Endpoint;

const cancelBatchOperation = {
	method: 'POST',
	getUrl: ({batchOperationKey}) => `/${API_VERSION}/batch-operations/${batchOperationKey}/cancellation` as const,
} as const satisfies Endpoint<{batchOperationKey: string}>;

const suspendBatchOperation = {
	method: 'POST',
	getUrl: ({batchOperationKey}) => `/${API_VERSION}/batch-operations/${batchOperationKey}/suspension` as const,
} as const satisfies Endpoint<{batchOperationKey: string}>;

const resumeBatchOperation = {
	method: 'POST',
	getUrl: ({batchOperationKey}) => `/${API_VERSION}/batch-operations/${batchOperationKey}/resumption` as const,
} as const satisfies Endpoint<{batchOperationKey: string}>;

const queryBatchOperationItems = {
	method: 'POST',
	getUrl: () => `/${API_VERSION}/batch-operation-items/search` as const,
} as const satisfies Endpoint;

export {
	batchOperationTypeSchema,
	batchOperationStateSchema,
	batchOperationItemStateSchema,
	batchOperationErrorTypeSchema,
	batchOperationErrorSchema,
	batchOperationSchema,
	batchOperationItemSchema,
	queryBatchOperationsRequestBodySchema,
	queryBatchOperationsResponseBodySchema,
	queryBatchOperationItemsRequestBodySchema,
	queryBatchOperationItemsResponseBodySchema,
	getBatchOperation,
	queryBatchOperations,
	cancelBatchOperation,
	suspendBatchOperation,
	resumeBatchOperation,
	queryBatchOperationItems,
};

export type {
	BatchOperationType,
	BatchOperationState,
	BatchOperationItemState,
	BatchOperationErrorType,
	BatchOperationError,
	BatchOperation,
	BatchOperationItem,
	QueryBatchOperationsRequestBody,
	QueryBatchOperationsResponseBody,
	QueryBatchOperationItemsRequestBody,
	QueryBatchOperationItemsResponseBody,
};
