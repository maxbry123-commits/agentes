// Copyright IBM Corp. 2015, 2026
// SPDX-License-Identifier: BUSL-1.1

package feasible

import (
	"fmt"
	"maps"
	"testing"
	"time"

	"github.com/hashicorp/nomad/ci"
	"github.com/hashicorp/nomad/helper"
	"github.com/hashicorp/nomad/helper/testlog"
	"github.com/hashicorp/nomad/helper/uuid"
	"github.com/hashicorp/nomad/nomad/mock"
	"github.com/hashicorp/nomad/nomad/state"
	"github.com/hashicorp/nomad/nomad/structs"
	psstructs "github.com/hashicorp/nomad/plugins/shared/structs"
	"github.com/shoenig/test"
	"github.com/shoenig/test/must"
)

func TestStaticIterator_Reset(t *testing.T) {
	ci.Parallel(t)

	_, ctx := MockContext(t)
	var nodes []*structs.Node
	for range 3 {
		nodes = append(nodes, mock.Node())
	}
	static := NewStaticIterator(ctx, nodes)

	for i := range 6 {
		static.Reset()
		for j := 0; j < i; j++ {
			static.Next()
		}
		static.Reset()

		out := collectFeasible(static)
		if len(out) != len(nodes) {
			t.Fatalf("out: %#v missing nodes %d %#v", out, i, static)
		}

		ids := make(map[string]struct{})
		for _, o := range out {
			if _, ok := ids[o.ID]; ok {
				t.Fatalf("duplicate")
			}
			ids[o.ID] = struct{}{}
		}
	}
}

func TestStaticIterator_SetNodes(t *testing.T) {
	ci.Parallel(t)

	_, ctx := MockContext(t)
	var nodes []*structs.Node
	for range 3 {
		nodes = append(nodes, mock.Node())
	}
	static := NewStaticIterator(ctx, nodes)

	newNodes := []*structs.Node{mock.Node()}
	static.SetNodes(newNodes)

	out := collectFeasible(static)
	must.Eq(t, newNodes, out)

}

func TestRandomIterator(t *testing.T) {
	ci.Parallel(t)

	_, ctx := MockContext(t)
	var nodes []*structs.Node
	for range 10 {
		nodes = append(nodes, mock.Node())
	}

	nc := make([]*structs.Node, len(nodes))
	copy(nc, nodes)
	rand := NewRandomIterator(ctx, nc)

	out := collectFeasible(rand)
	if len(out) != len(nodes) {
		t.Fatalf("missing nodes")
	}
	must.NotEq(t, nodes, out)

}

func TestSecretsChecker(t *testing.T) {
	ci.Parallel(t)

	_, ctx := MockContext(t)
	nodes := []*structs.Node{
		mock.Node(),
		mock.Node(),
		mock.Node(),
	}
	nodes[1].Attributes["plugins.secrets.foo.version"] = "1.0.0"
	nodes[2].Attributes["plugins.secrets.bar.version"] = "1.0.0"

	m := map[string]struct{}{
		"foo": struct{}{},
	}
	checker := NewSecretsProviderChecker(ctx, m)

	cases := []struct {
		Node    *structs.Node
		Secrets map[string]struct{}
		Result  bool
	}{
		{
			Node: nodes[0],
			Secrets: map[string]struct{}{
				"foo": {},
			},
			Result: false,
		},
		{
			Node: nodes[1],
			Secrets: map[string]struct{}{
				"foo": {},
			},
			Result: true,
		},
		{
			Node: nodes[2],
			Secrets: map[string]struct{}{
				"foo": {},
			},
			Result: false,
		},
	}

	for i, c := range cases {
		checker.SetSecrets(c.Secrets)
		if act := checker.Feasible(c.Node); act != c.Result {
			t.Fatalf("case(%d) failed: got %v; want %v", i, act, c.Result)
		}
	}
}

func TestHostVolumeChecker_Static(t *testing.T) {
	ci.Parallel(t)

	_, ctx := MockContext(t)
	nodes := []*structs.Node{
		mock.Node(),
		mock.Node(),
		mock.Node(),
		mock.Node(),
		mock.Node(),
		mock.Node(),
	}
	nodes[1].HostVolumes = map[string]*structs.ClientHostVolumeConfig{"foo": {Name: "foo"}}
	nodes[2].HostVolumes = map[string]*structs.ClientHostVolumeConfig{
		"foo":              {},
		"bar":              {},
		"unique-volume[0]": {},
	}
	nodes[3].HostVolumes = map[string]*structs.ClientHostVolumeConfig{
		"foo": {},
		"bar": {},
	}
	nodes[4].HostVolumes = map[string]*structs.ClientHostVolumeConfig{
		"foo": {},
		"baz": {},
	}

	noVolumes := map[string]*structs.VolumeRequest{}

	volumes := map[string]*structs.VolumeRequest{
		"foo": {
			Type:   "host",
			Source: "foo",
		},
		"bar": {
			Type:   "host",
			Source: "bar",
		},
		"baz": {
			Type:   "nothost",
			Source: "baz",
		},
		"unique": {
			Type:     "host",
			Source:   "unique-volume[0]",
			PerAlloc: true,
		},
	}

	checker := NewHostVolumeChecker(ctx)
	cases := []struct {
		Node             *structs.Node
		RequestedVolumes map[string]*structs.VolumeRequest
		Result           bool
	}{
		{ // Nil Volumes, some requested
			Node:             nodes[0],
			RequestedVolumes: volumes,
			Result:           false,
		},
		{ // Mismatched set of volumes
			Node:             nodes[1],
			RequestedVolumes: volumes,
			Result:           false,
		},
		{ // Happy Path
			Node:             nodes[2],
			RequestedVolumes: volumes,
			Result:           true,
		},
		{ // No Volumes requested or available
			Node:             nodes[3],
			RequestedVolumes: noVolumes,
			Result:           true,
		},
		{ // No Volumes requested, some available
			Node:             nodes[4],
			RequestedVolumes: noVolumes,
			Result:           true,
		},
	}

	alloc := mock.Alloc()
	alloc.NodeID = nodes[2].ID

	job := mock.Job()
	taskGroup := job.TaskGroups[0]

	for i, c := range cases {
		checker.SetVolumes(alloc.Name, structs.DefaultNamespace, job.ID, taskGroup.Name, c.RequestedVolumes)
		if act := checker.Feasible(c.Node); act != c.Result {
			t.Fatalf("case(%d) failed: got %v; want %v", i, act, c.Result)
		}
	}
}

func TestHostVolumeChecker_StaticSticky(t *testing.T) {
	ci.Parallel(t)

	_, ctx := MockContext(t)

	node := mock.Node()
	node.HostVolumes = map[string]*structs.ClientHostVolumeConfig{
		"foo": {}, // static host volume: ID is empty
	}

	// sticky is only supported on dynamic host volumes, so requesting it on a
	// static host volume must fail feasibility regardless of ReadOnly.
	cases := []struct {
		name   string
		req    *structs.VolumeRequest
		result bool
	}{
		{
			name:   "sticky read-write",
			req:    &structs.VolumeRequest{Type: "host", Source: "foo", Sticky: true},
			result: false,
		},
		{
			name:   "sticky read-only",
			req:    &structs.VolumeRequest{Type: "host", Source: "foo", Sticky: true, ReadOnly: true},
			result: false,
		},
		{
			name:   "not sticky",
			req:    &structs.VolumeRequest{Type: "host", Source: "foo"},
			result: true,
		},
	}

	checker := NewHostVolumeChecker(ctx)
	alloc := mock.Alloc()
	alloc.NodeID = node.ID
	job := mock.Job()
	taskGroup := job.TaskGroups[0]

	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			checker.SetVolumes(alloc.Name, structs.DefaultNamespace, job.ID, taskGroup.Name,
				map[string]*structs.VolumeRequest{"foo": tc.req})
			must.Eq(t, tc.result, checker.Feasible(node))
		})
	}
}

func TestHostVolumeChecker_StaticStickyMultiVolume(t *testing.T) {
	ci.Parallel(t)

	store, ctx := MockContext(t)

	// the node has one dynamic host volume (ID set) and one static host volume
	// (ID empty)
	dhvID := uuid.Generate()
	node := mock.Node()
	node.HostVolumes = map[string]*structs.ClientHostVolumeConfig{
		"dyn":  {ID: dhvID},
		"stat": {},
	}
	must.NoError(t, store.UpsertNode(structs.MsgTypeTestSetup, 1000, node))

	dhv := &structs.HostVolume{
		Namespace: structs.DefaultNamespace,
		ID:        dhvID,
		Name:      "dyn",
		NodeID:    node.ID,
		RequestedCapabilities: []*structs.HostVolumeCapability{{
			AttachmentMode: structs.HostVolumeAttachmentModeFilesystem,
			AccessMode:     structs.HostVolumeAccessModeSingleNodeSingleWriter,
		}},
		State: structs.HostVolumeStateReady,
	}
	must.NoError(t, store.UpsertHostVolume(1000, dhv))

	// both volumes are requested sticky. The dynamic one is available with no
	// outstanding claims, so on its own it satisfies the per-request check; the
	// static one is invalid for sticky. The node must be infeasible no matter
	// which request is checked first.
	dynReq := &structs.VolumeRequest{
		Type:           "host",
		Source:         "dyn",
		Sticky:         true,
		AccessMode:     structs.HostVolumeAccessModeSingleNodeSingleWriter,
		AttachmentMode: structs.CSIVolumeAttachmentModeFilesystem,
	}
	statReq := &structs.VolumeRequest{Type: "host", Source: "stat", Sticky: true}

	checker := NewHostVolumeChecker(ctx)
	alloc := mock.Alloc()
	alloc.NodeID = node.ID
	job := mock.Job()
	taskGroup := job.TaskGroups[0]
	checker.SetVolumes(alloc.Name, structs.DefaultNamespace, job.ID, taskGroup.Name,
		map[string]*structs.VolumeRequest{"dyn": dynReq, "stat": statReq})

	// SetVolumes builds volumeReqs from a map, so set the order explicitly and
	// check both: a satisfied dynamic request must not let the static one slip
	// through whether it is checked first or second.
	checker.volumeReqs = []*structs.VolumeRequest{dynReq, statReq}
	must.False(t, checker.Feasible(node),
		must.Sprint("infeasible with the dynamic request checked first"))

	checker.volumeReqs = []*structs.VolumeRequest{statReq, dynReq}
	must.False(t, checker.Feasible(node),
		must.Sprint("infeasible with the static request checked first"))
}

func TestHostVolumeChecker_Dynamic(t *testing.T) {
	ci.Parallel(t)

	store, ctx := MockContext(t)

	nodes := []*structs.Node{
		mock.Node(),
		mock.Node(),
		mock.Node(),
		mock.Node(),
		mock.Node(),
	}

	hostVolCapsReadWrite := []*structs.HostVolumeCapability{
		{
			AttachmentMode: structs.HostVolumeAttachmentModeFilesystem,
			AccessMode:     structs.HostVolumeAccessModeSingleNodeReader,
		},
		{
			AttachmentMode: structs.HostVolumeAttachmentModeFilesystem,
			AccessMode:     structs.HostVolumeAccessModeSingleNodeWriter,
		},
	}
	hostVolCapsReadOnly := []*structs.HostVolumeCapability{{
		AttachmentMode: structs.HostVolumeAttachmentModeFilesystem,
		AccessMode:     structs.HostVolumeAccessModeSingleNodeReader,
	}}

	dhvNotReady := &structs.HostVolume{
		Namespace:             structs.DefaultNamespace,
		ID:                    uuid.Generate(),
		Name:                  "foo",
		NodeID:                nodes[2].ID,
		RequestedCapabilities: hostVolCapsReadOnly,
		State:                 structs.HostVolumeStateUnavailable,
	}
	dhvReadOnly := &structs.HostVolume{
		Namespace:             structs.DefaultNamespace,
		ID:                    uuid.Generate(),
		Name:                  "foo",
		NodeID:                nodes[3].ID,
		RequestedCapabilities: hostVolCapsReadOnly,
		State:                 structs.HostVolumeStateReady,
	}
	dhvReadWrite := &structs.HostVolume{
		Namespace:             structs.DefaultNamespace,
		ID:                    uuid.Generate(),
		Name:                  "foo",
		NodeID:                nodes[4].ID,
		RequestedCapabilities: hostVolCapsReadWrite,
		State:                 structs.HostVolumeStateReady,
	}

	nodes[0].HostVolumes = map[string]*structs.ClientHostVolumeConfig{
		"foo": {
			ReadOnly: true,
		},
	}
	nodes[1].HostVolumes = map[string]*structs.ClientHostVolumeConfig{
		"foo": {
			ReadOnly: false,
		},
	}
	nodes[2].HostVolumes = map[string]*structs.ClientHostVolumeConfig{}
	nodes[3].HostVolumes = map[string]*structs.ClientHostVolumeConfig{
		"foo": {ID: dhvReadOnly.ID},
	}
	nodes[4].HostVolumes = map[string]*structs.ClientHostVolumeConfig{
		"foo": {ID: dhvReadWrite.ID},
	}

	for _, node := range nodes {
		must.NoError(t, store.UpsertNode(structs.MsgTypeTestSetup, 1000, node))
	}

	must.NoError(t, store.UpsertHostVolume(1000, dhvNotReady))
	must.NoError(t, store.UpsertHostVolume(1000, dhvReadOnly))
	must.NoError(t, store.UpsertHostVolume(1000, dhvReadWrite))

	// reinsert unavailable node to set the correct state on the unavailable
	// volume
	must.NoError(t, store.UpsertNode(structs.MsgTypeTestSetup, 1000, nodes[2]))

	readwriteRequest := map[string]*structs.VolumeRequest{
		"foo": {
			Type:   "host",
			Source: "foo",
		},
	}

	readonlyRequest := map[string]*structs.VolumeRequest{
		"foo": {
			Type:     "host",
			Source:   "foo",
			ReadOnly: true,
		},
	}

	dhvReadOnlyRequest := map[string]*structs.VolumeRequest{
		"foo": {
			Type:           "host",
			Source:         "foo",
			ReadOnly:       true,
			AccessMode:     structs.CSIVolumeAccessModeSingleNodeReader,
			AttachmentMode: structs.CSIVolumeAttachmentModeFilesystem,
		},
	}
	dhvReadWriteRequest := map[string]*structs.VolumeRequest{
		"foo": {
			Type:           "host",
			Source:         "foo",
			AccessMode:     structs.CSIVolumeAccessModeSingleNodeWriter,
			AttachmentMode: structs.CSIVolumeAttachmentModeFilesystem,
		},
	}

	checker := NewHostVolumeChecker(ctx)
	cases := []struct {
		name             string
		node             *structs.Node
		requestedVolumes map[string]*structs.VolumeRequest
		expect           bool
	}{
		{
			name:             "read-write request / read-only host",
			node:             nodes[0],
			requestedVolumes: readwriteRequest,
			expect:           false,
		},
		{
			name:             "read-only request / read-only host",
			node:             nodes[0],
			requestedVolumes: readonlyRequest,
			expect:           true,
		},
		{
			name:             "read-only request / read-write host",
			node:             nodes[1],
			requestedVolumes: readonlyRequest,
			expect:           true,
		},
		{
			name:             "read-write request / read-write host",
			node:             nodes[1],
			requestedVolumes: readwriteRequest,
			expect:           true,
		},
		{
			name:             "dynamic single-reader request / host not ready",
			node:             nodes[2],
			requestedVolumes: dhvReadOnlyRequest,
			expect:           false,
		},
		{
			name:             "dynamic single-reader request / caps match",
			node:             nodes[3],
			requestedVolumes: dhvReadOnlyRequest,
			expect:           true,
		},
		{
			name:             "dynamic single-reader request / no matching cap",
			node:             nodes[4],
			requestedVolumes: dhvReadOnlyRequest,
			expect:           true,
		},
		{
			name:             "dynamic single-writer request / caps match",
			node:             nodes[4],
			requestedVolumes: dhvReadWriteRequest,
			expect:           true,
		},
	}

	alloc := mock.Alloc()
	alloc.NodeID = nodes[1].ID

	job := mock.Job()
	taskGroupName := job.TaskGroups[0].Name

	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			checker.SetVolumes(alloc.Name, structs.DefaultNamespace, job.ID, taskGroupName, tc.requestedVolumes)
			actual := checker.Feasible(tc.node)
			must.Eq(t, tc.expect, actual)
		})
	}
}

func TestHostVolumeChecker_Sticky(t *testing.T) {
	ci.Parallel(t)

	store := state.TestStateStore(t)

	nodes := []*structs.Node{
		mock.Node(), // claimed by good alloc
		mock.Node(), // claimed by failed alloc
		mock.Node(), // unclaimed
		mock.Node(), // no volume
	}
	// name these nodes to make it easier to understand assertions
	nodes[0].Name = "node0-claimed-by-good"
	nodes[1].Name = "node1-claimed-by-fail"
	nodes[2].Name = "node2-unclaimed"
	nodes[3].Name = "node3-infeasible"

	caps := []*structs.HostVolumeCapability{{
		AttachmentMode: structs.HostVolumeAttachmentModeFilesystem,
		AccessMode:     structs.HostVolumeAccessModeSingleNodeSingleWriter,
	}}

	// nodes 0, 1, 2 have volumes
	dhv0 := &structs.HostVolume{
		Namespace:             structs.DefaultNamespace,
		ID:                    uuid.Generate(),
		Name:                  "foo",
		NodeID:                nodes[0].ID,
		RequestedCapabilities: caps,
		State:                 structs.HostVolumeStateReady,
	}
	dhv1 := &structs.HostVolume{
		Namespace:             structs.DefaultNamespace,
		ID:                    uuid.Generate(),
		Name:                  "foo",
		NodeID:                nodes[1].ID,
		RequestedCapabilities: caps,
		State:                 structs.HostVolumeStateReady,
	}
	dhv2 := &structs.HostVolume{
		Namespace:             structs.DefaultNamespace,
		ID:                    uuid.Generate(),
		Name:                  "foo",
		NodeID:                nodes[2].ID,
		RequestedCapabilities: caps,
		State:                 structs.HostVolumeStateReady,
	}

	// node0 doesn't have the desired volume, but both node2 and node2 do
	nodes[0].HostVolumes = map[string]*structs.ClientHostVolumeConfig{
		"foo": {ID: dhv0.ID},
	}
	nodes[1].HostVolumes = map[string]*structs.ClientHostVolumeConfig{
		"foo": {ID: dhv1.ID},
	}
	nodes[2].HostVolumes = map[string]*structs.ClientHostVolumeConfig{
		"foo": {ID: dhv2.ID},
	}

	for _, node := range nodes {
		must.NoError(t, store.UpsertNode(structs.MsgTypeTestSetup, 1000, node))
	}
	must.NoError(t, store.UpsertHostVolume(1000, dhv0))
	must.NoError(t, store.UpsertHostVolume(1000, dhv1))
	must.NoError(t, store.UpsertHostVolume(1000, dhv2))

	stickyRequests := map[string]*structs.VolumeRequest{
		"foo": {
			Type:           "host",
			Source:         "foo",
			Sticky:         true,
			AccessMode:     structs.HostVolumeAccessModeSingleNodeSingleWriter,
			AttachmentMode: structs.CSIVolumeAttachmentModeFilesystem,
		},
	}
	stickyJob := mock.Job()
	stickyJob.ID = "sticky"
	stickyJob.TaskGroups[0].Count = 4
	stickyJob.TaskGroups[0].Volumes = stickyRequests
	ns := stickyJob.Namespace
	tgName := "web"

	goodAlloc := mock.MinAllocForJob(stickyJob)
	goodAlloc.ClientStatus = structs.AllocClientStatusRunning
	goodAlloc.NodeID = nodes[0].ID
	goodAlloc.Name = "web[0]"

	badAlloc := mock.MinAllocForJob(stickyJob)
	badAlloc.ClientStatus = structs.AllocClientStatusFailed
	badAlloc.NodeID = nodes[1].ID
	badAlloc.Name = "web[1]"

	must.NoError(t, store.UpsertJob(structs.MsgTypeTestSetup, 1000, nil, stickyJob))
	must.NoError(t, store.UpsertAllocs(structs.MsgTypeTestSetup, 1000,
		[]*structs.Allocation{goodAlloc, badAlloc}))

	proposed1 := mock.MinAllocForJob(stickyJob) // replaces badAlloc
	proposed1.Name = "web[1]"

	proposed2 := mock.MinAllocForJob(stickyJob) // expect placement
	proposed2.Name = "web[2]"

	proposed3 := mock.MinAllocForJob(stickyJob) // will never have room
	proposed3.Name = "web[3]"
	proposed := []*structs.Allocation{proposed1, proposed2, proposed3}

	existingClaims := []*structs.TaskGroupHostVolumeClaim{
		{ // claim by running alloc
			ID:            uuid.Generate(),
			Namespace:     ns,
			JobID:         stickyJob.ID,
			TaskGroupName: stickyJob.TaskGroups[0].Name,
			AllocID:       goodAlloc.ID,
			VolumeID:      dhv0.ID,
			VolumeName:    dhv0.Name,
		},
		{ // claim by failed alloc
			ID:            uuid.Generate(),
			Namespace:     ns,
			JobID:         stickyJob.ID,
			TaskGroupName: stickyJob.TaskGroups[0].Name,
			AllocID:       badAlloc.ID,
			VolumeID:      dhv1.ID,
			VolumeName:    dhv1.Name,
		},
	}

	for _, claim := range existingClaims {
		must.NoError(t, store.UpsertTaskGroupHostVolumeClaim(
			structs.MsgTypeTestSetup, 1000, claim))
	}

	cases := []struct {
		name             string
		nodes            []*structs.Node   // order of nodes to process
		expectPlacements map[string]string // expected alloc names -> node names
		expectUnmet      []string          // expected unmet claims
		expectUnplaced   []string          // expected unplaced alloc names
	}{
		{
			name:  "checking claimed first",
			nodes: []*structs.Node{nodes[0], nodes[1], nodes[2], nodes[3]},
			expectPlacements: map[string]string{
				"web[1]": nodes[1].Name,
				"web[2]": nodes[2].Name,
			},
			expectUnmet:    []string{},
			expectUnplaced: []string{"web[3]"},
		},
		{
			name:  "checking claimed last",
			nodes: []*structs.Node{nodes[2], nodes[3], nodes[0], nodes[1]},
			expectPlacements: map[string]string{
				"web[1]": nodes[1].Name,
				"web[2]": nodes[2].Name,
			},
			expectUnmet:    []string{},
			expectUnplaced: []string{"web[3]"},
		},
		{
			name:  "good claim checked before unclaimed",
			nodes: []*structs.Node{nodes[0], nodes[3], nodes[1], nodes[2]},
			expectPlacements: map[string]string{
				"web[1]": nodes[1].Name,
				"web[2]": nodes[2].Name,
			},
			expectUnmet:    []string{},
			expectUnplaced: []string{"web[3]"},
		},
		{
			name:             "unmet claim is not feasible",
			nodes:            []*structs.Node{nodes[2], nodes[3], nodes[0]},
			expectPlacements: map[string]string{},
			expectUnmet:      []string{existingClaims[1].ID},
			expectUnplaced:   []string{"web[1]", "web[2]", "web[3]"},
		},
	}

	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			plan := &structs.Plan{
				EvalID:          uuid.Generate(),
				NodeUpdate:      make(map[string][]*structs.Allocation),
				NodeAllocation:  make(map[string][]*structs.Allocation),
				NodePreemptions: make(map[string][]*structs.Allocation),
			}

			logger := testlog.HCLogger(t)
			ctx := NewEvalContext(nil, store, plan, logger)
			checker := NewHostVolumeChecker(ctx)
			plan.NodeAllocation[nodes[0].ID] = []*structs.Allocation{goodAlloc}

			out := map[string]string{} // alloc name -> node name
			unplaced := []string{}     //alloc name

		NEXT_ALLOC:
			for _, alloc := range proposed {
				checker.SetVolumes(alloc.Name, ns, stickyJob.ID, tgName, stickyRequests)
				for _, node := range tc.nodes {
					if checker.Feasible(node) {
						out[alloc.Name] = node.Name
						alloc.NodeID = node.ID
						plan.AppendAlloc(alloc, stickyJob)
						continue NEXT_ALLOC
					}
				}
				unplaced = append(unplaced, alloc.Name)
			}

			must.Eq(t, tc.expectPlacements, out, must.Sprint("expected placements"))
			unmet := helper.ConvertSlice(checker.unmetClaims,
				func(c *structs.TaskGroupHostVolumeClaim) string { return c.ID })
			must.Eq(t, tc.expectUnmet, unmet, must.Sprint("expected unmet claims"))
			must.Eq(t, tc.expectUnplaced, unplaced, must.Sprint("expected unplaced"))
		})
	}
}

// TestDynamicHostVolumeIsAvailable provides fine-grained coverage of the
// hostVolumeIsAvailable method
func TestDynamicHostVolumeIsAvailable(t *testing.T) {

	store, ctx := MockContext(t)

	allCaps := []*structs.HostVolumeCapability{}

	for _, accessMode := range []structs.VolumeAccessMode{
		structs.HostVolumeAccessModeSingleNodeReader,
		structs.HostVolumeAccessModeSingleNodeWriter,
		structs.HostVolumeAccessModeSingleNodeSingleWriter,
		structs.HostVolumeAccessModeSingleNodeMultiWriter,
	} {
		for _, attachMode := range []structs.VolumeAttachmentMode{
			structs.HostVolumeAttachmentModeFilesystem,
			structs.HostVolumeAttachmentModeBlockDevice,
		} {
			allCaps = append(allCaps, &structs.HostVolumeCapability{
				AttachmentMode: attachMode,
				AccessMode:     accessMode,
			})
		}
	}

	jobReader, jobWriter := mock.Job(), mock.Job()
	jobReader.TaskGroups[0].Volumes = map[string]*structs.VolumeRequest{
		"example": {
			Type:     structs.VolumeTypeHost,
			Source:   "example",
			ReadOnly: true,
		},
	}
	jobWriter.TaskGroups[0].Volumes = map[string]*structs.VolumeRequest{
		"example": {
			Type:   structs.VolumeTypeHost,
			Source: "example",
		},
	}
	index, _ := store.LatestIndex()
	index++
	must.NoError(t, store.UpsertJob(structs.MsgTypeTestSetup, index, nil, jobReader))
	index++
	must.NoError(t, store.UpsertJob(structs.MsgTypeTestSetup, index, nil, jobWriter))

	allocReader0, allocReader1 := mock.Alloc(), mock.Alloc()
	allocReader0.JobID = jobReader.ID
	allocReader1.JobID = jobReader.ID

	allocWriter0, allocWriter1 := mock.Alloc(), mock.Alloc()
	allocWriter0.JobID = jobWriter.ID
	allocWriter1.JobID = jobWriter.ID

	index++
	must.NoError(t, store.UpsertAllocs(structs.MsgTypeTestSetup, index,
		[]*structs.Allocation{allocReader0, allocReader1, allocWriter0, allocWriter1}))

	testCases := []struct {
		name        string
		hasProposed []*structs.Allocation
		hasCaps     []*structs.HostVolumeCapability
		wantAccess  structs.VolumeAccessMode
		wantAttach  structs.VolumeAttachmentMode
		readOnly    bool
		expect      bool
	}{
		{
			name: "enforce attachment mode",
			hasCaps: []*structs.HostVolumeCapability{{
				AttachmentMode: structs.HostVolumeAttachmentModeBlockDevice,
				AccessMode:     structs.HostVolumeAccessModeSingleNodeSingleWriter,
			}},
			wantAttach: structs.HostVolumeAttachmentModeFilesystem,
			wantAccess: structs.HostVolumeAccessModeSingleNodeSingleWriter,
			expect:     false,
		},
		{
			name:        "enforce read only",
			hasProposed: []*structs.Allocation{allocReader0, allocReader1},
			wantAttach:  structs.HostVolumeAttachmentModeFilesystem,
			wantAccess:  structs.HostVolumeAccessModeSingleNodeReader,
			expect:      false,
		},
		{
			name:        "enforce read only ok",
			hasProposed: []*structs.Allocation{allocReader0, allocReader1},
			wantAttach:  structs.HostVolumeAttachmentModeFilesystem,
			wantAccess:  structs.HostVolumeAccessModeSingleNodeReader,
			readOnly:    true,
			expect:      true,
		},
		{
			name:        "enforce single writer",
			hasProposed: []*structs.Allocation{allocReader0, allocReader1, allocWriter0},
			wantAttach:  structs.HostVolumeAttachmentModeFilesystem,
			wantAccess:  structs.HostVolumeAccessModeSingleNodeSingleWriter,
			expect:      false,
		},
		{
			name:        "enforce single writer ok",
			hasProposed: []*structs.Allocation{allocReader0, allocReader1},
			wantAttach:  structs.HostVolumeAttachmentModeFilesystem,
			wantAccess:  structs.HostVolumeAccessModeSingleNodeSingleWriter,
			expect:      true,
		},
		{
			name:        "multi writer is always ok",
			hasProposed: []*structs.Allocation{allocReader0, allocWriter0, allocWriter1},
			wantAttach:  structs.HostVolumeAttachmentModeFilesystem,
			wantAccess:  structs.HostVolumeAccessModeSingleNodeMultiWriter,
			expect:      true,
		},
		{
			name:   "default capabilities ok",
			expect: true,
		},
		{
			name:     "default capabilities fail",
			readOnly: true,
			hasCaps: []*structs.HostVolumeCapability{{
				AttachmentMode: structs.HostVolumeAttachmentModeBlockDevice,
				AccessMode:     structs.HostVolumeAccessModeSingleNodeSingleWriter,
			}},
			expect: false,
		},
	}

	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			vol := &structs.HostVolume{
				Name:  "example",
				State: structs.HostVolumeStateReady,
			}
			if len(tc.hasCaps) > 0 {
				vol.RequestedCapabilities = tc.hasCaps
			} else {
				vol.RequestedCapabilities = allCaps
			}
			checker := NewHostVolumeChecker(ctx)
			must.Eq(t, tc.expect, checker.hostVolumeIsAvailable(
				vol, tc.wantAccess, tc.wantAttach, tc.readOnly, tc.hasProposed))
		})
	}

}

func TestDynamicHostVolumeIsAvailable_PurgedJob(t *testing.T) {
	ci.Parallel(t)

	_, ctx := MockContext(t)
	checker := NewHostVolumeChecker(ctx)

	vol := &structs.HostVolume{
		Name:  "example",
		State: structs.HostVolumeStateReady,
		RequestedCapabilities: []*structs.HostVolumeCapability{{
			AttachmentMode: structs.HostVolumeAttachmentModeFilesystem,
			AccessMode:     structs.HostVolumeAccessModeSingleNodeSingleWriter,
		}},
	}

	// A proposed alloc whose job has been purged or garbage collected: JobByID
	// returns nil, nil. The checker cannot prove the alloc is not using the
	// volume, so it must report the volume unavailable rather than dereference
	// the nil job (#28301).
	orphan := mock.Alloc()

	must.False(t, checker.hostVolumeIsAvailable(
		vol,
		structs.HostVolumeAccessModeSingleNodeSingleWriter,
		structs.HostVolumeAttachmentModeFilesystem,
		false,
		[]*structs.Allocation{orphan},
	))
}

func TestCSIVolumeChecker(t *testing.T) {
	ci.Parallel(t)
	state, ctx := MockContext(t)
	nodes := []*structs.Node{
		mock.Node(),
		mock.Node(),
		mock.Node(),
		mock.Node(),
		mock.Node(),
		mock.Node(),
		mock.Node(),
	}

	// Register running plugins on some nodes
	nodes[0].CSIControllerPlugins = map[string]*structs.CSIInfo{
		"foo": {
			PluginID:       "foo",
			Healthy:        true,
			ControllerInfo: &structs.CSIControllerInfo{},
		},
	}
	nodes[0].CSINodePlugins = map[string]*structs.CSIInfo{
		"foo": {
			PluginID: "foo",
			Healthy:  true,
			NodeInfo: &structs.CSINodeInfo{
				MaxVolumes: 1,
				AccessibleTopology: &structs.CSITopology{
					Segments: map[string]string{"rack": "R1"},
				},
			},
		},
	}
	nodes[1].CSINodePlugins = map[string]*structs.CSIInfo{
		"foo": {
			PluginID: "foo",
			Healthy:  false,
			NodeInfo: &structs.CSINodeInfo{
				MaxVolumes: 1,
				AccessibleTopology: &structs.CSITopology{
					Segments: map[string]string{"rack": "R1"},
				},
			},
		},
	}
	nodes[2].CSINodePlugins = map[string]*structs.CSIInfo{
		"bar": {
			PluginID: "bar",
			Healthy:  true,
			NodeInfo: &structs.CSINodeInfo{
				MaxVolumes: 1,
				AccessibleTopology: &structs.CSITopology{
					Segments: map[string]string{"rack": "R1"},
				},
			},
		},
	}
	nodes[4].CSINodePlugins = map[string]*structs.CSIInfo{
		"foo": {
			PluginID: "foo",
			Healthy:  true,
			NodeInfo: &structs.CSINodeInfo{
				MaxVolumes: 1,
				AccessibleTopology: &structs.CSITopology{
					Segments: map[string]string{"rack": "R1"},
				},
			},
		},
	}
	nodes[5].CSINodePlugins = map[string]*structs.CSIInfo{
		"foo": {
			PluginID: "foo",
			Healthy:  true,
			NodeInfo: &structs.CSINodeInfo{
				MaxVolumes: 1,
				AccessibleTopology: &structs.CSITopology{
					Segments: map[string]string{"rack": "R4"},
				},
			},
		},
	}
	nodes[6].CSINodePlugins = map[string]*structs.CSIInfo{
		"foo": {
			PluginID: "foo",
			Healthy:  true,
			NodeInfo: &structs.CSINodeInfo{
				MaxVolumes: 1,
			},
		},
	}

	// Create the plugins in the state store
	index := uint64(999)
	for _, node := range nodes {
		err := state.UpsertNode(structs.MsgTypeTestSetup, index, node)
		must.NoError(t, err)
		index++
	}

	// Create the volume in the state store
	vid := "volume-id"
	vol := structs.NewCSIVolume(vid, index)
	vol.PluginID = "foo"
	vol.Namespace = structs.DefaultNamespace
	vol.AccessMode = structs.CSIVolumeAccessModeMultiNodeMultiWriter
	vol.AttachmentMode = structs.CSIVolumeAttachmentModeFilesystem
	vol.Topologies = []*structs.CSITopology{
		{Segments: map[string]string{"rack": "R1"}},
		{Segments: map[string]string{"rack": "R2"}},
	}
	err := state.UpsertCSIVolume(index, []*structs.CSIVolume{vol})
	must.NoError(t, err)
	index++

	// Create some other volumes in use on nodes[3] to trip MaxVolumes
	vid2 := uuid.Generate()
	vol2 := structs.NewCSIVolume(vid2, index)
	vol2.PluginID = "foo"
	vol2.Namespace = structs.DefaultNamespace
	vol2.AccessMode = structs.CSIVolumeAccessModeMultiNodeSingleWriter
	vol2.AttachmentMode = structs.CSIVolumeAttachmentModeFilesystem
	err = state.UpsertCSIVolume(index, []*structs.CSIVolume{vol2})
	must.NoError(t, err)
	index++

	vid3 := "volume-id[0]"
	vol3 := vol.Copy()
	vol3.ID = vid3
	err = state.UpsertCSIVolume(index, []*structs.CSIVolume{vol3})
	must.NoError(t, err)
	index++

	alloc := mock.Alloc()
	alloc.NodeID = nodes[4].ID
	alloc.Job.TaskGroups[0].Volumes = map[string]*structs.VolumeRequest{
		vid2: {
			Name:   vid2,
			Type:   "csi",
			Source: vid2,
		},
	}
	err = state.UpsertJob(structs.MsgTypeTestSetup, index, nil, alloc.Job)
	must.NoError(t, err)
	index++
	summary := mock.JobSummary(alloc.JobID)
	must.NoError(t, state.UpsertJobSummary(index, summary))
	index++
	err = state.UpsertAllocs(structs.MsgTypeTestSetup, index, []*structs.Allocation{alloc})
	must.NoError(t, err)
	index++

	// Create volume requests
	noVolumes := map[string]*structs.VolumeRequest{}

	volumes := map[string]*structs.VolumeRequest{
		"shared": {
			Type:   "csi",
			Name:   "baz",
			Source: "volume-id",
		},
		"unique": {
			Type:     "csi",
			Name:     "baz",
			Source:   "volume-id[0]",
			PerAlloc: true,
		},
		"nonsense": {
			Type:   "host",
			Name:   "nonsense",
			Source: "my-host-volume",
		},
	}

	checker := NewCSIVolumeChecker(ctx)
	checker.SetNamespace(structs.DefaultNamespace)

	cases := []struct {
		Name             string
		Node             *structs.Node
		RequestedVolumes map[string]*structs.VolumeRequest
		Result           bool
	}{
		{
			Name:             "ok",
			Node:             nodes[0],
			RequestedVolumes: volumes,
			Result:           true,
		},
		{
			Name:             "unhealthy node",
			Node:             nodes[1],
			RequestedVolumes: volumes,
			Result:           false,
		},
		{
			Name:             "wrong id",
			Node:             nodes[2],
			RequestedVolumes: volumes,
			Result:           false,
		},
		{
			Name:             "no volumes requested or available",
			Node:             nodes[3],
			RequestedVolumes: noVolumes,
			Result:           true,
		},
		{
			Name:             "no volumes requested, some available",
			Node:             nodes[0],
			RequestedVolumes: noVolumes,
			Result:           true,
		},
		{
			Name:             "volumes requested, none available",
			Node:             nodes[3],
			RequestedVolumes: volumes,
			Result:           false,
		},
		{
			Name:             "volumes requested, max volumes exceeded",
			Node:             nodes[4],
			RequestedVolumes: volumes,
			Result:           false,
		},
		{
			Name:             "no matching topology",
			Node:             nodes[5],
			RequestedVolumes: volumes,
			Result:           false,
		},
		{
			Name:             "nil topology",
			Node:             nodes[6],
			RequestedVolumes: volumes,
			Result:           false,
		},
	}

	for _, c := range cases {
		checker.SetVolumes(alloc.Name, c.RequestedVolumes)
		test.Eq(t, c.Result, checker.Feasible(c.Node), test.Sprint(c.Name))
	}

	// add a missing volume
	volumes["missing"] = &structs.VolumeRequest{
		Type:   "csi",
		Name:   "bar",
		Source: "does-not-exist",
	}

	checker = NewCSIVolumeChecker(ctx)
	checker.SetNamespace(structs.DefaultNamespace)

	for _, node := range nodes {
		checker.SetVolumes(alloc.Name, volumes)
		act := checker.Feasible(node)
		must.False(t, act, must.Sprint("request with missing volume should never be feasible"))
	}

}

func TestCSIVolumeChecker_PerAllocBlocking(t *testing.T) {
	ci.Parallel(t)
	state, ctx := MockContext(t)

	nodes := []*structs.Node{
		mock.Node(),
		mock.Node(),
		mock.Node(),
	}

	nodes[0].CSINodePlugins = map[string]*structs.CSIInfo{
		"foo": {
			PluginID: "foo",
			Healthy:  true,
			NodeInfo: &structs.CSINodeInfo{
				MaxVolumes: 1,
				AccessibleTopology: &structs.CSITopology{
					Segments: map[string]string{"rack": "R1"},
				},
			},
		},
	}
	nodes[1].CSINodePlugins = maps.Clone(nodes[0].CSINodePlugins)
	nodes[2].CSINodePlugins = maps.Clone(nodes[0].CSINodePlugins)

	// Create the plugins in the state store
	index := uint64(999)
	for _, node := range nodes {
		err := state.UpsertNode(structs.MsgTypeTestSetup, index, node)
		must.NoError(t, err)
		index++
	}

	vid2 := "test-volume"
	reqs := map[string]*structs.VolumeRequest{
		vid2: {
			Name:     vid2,
			Type:     "csi",
			Source:   vid2,
			PerAlloc: true,
		},
	}

	job := mock.MinJob()
	job.TaskGroups[0].Count = 2
	job.TaskGroups[0].Volumes = reqs
	allocName0 := job.TaskGroups[0].Name + "[0]"
	allocName1 := job.TaskGroups[0].Name + "[1]"

	err := state.UpsertJob(structs.MsgTypeTestSetup, index, nil, job)
	must.NoError(t, err)
	index++
	summary := mock.JobSummary(job.ID)
	must.NoError(t, state.UpsertJobSummary(index, summary))
	index++

	checker := NewCSIVolumeChecker(ctx)
	checker.SetNamespace(structs.DefaultNamespace)

	for _, node := range nodes {
		checker.SetVolumes(allocName0, reqs)
		act := checker.Feasible(node)
		must.False(t, act, must.Sprint("request with missing volume should never be feasible"))

		checker.SetVolumes(allocName1, reqs)
		act = checker.Feasible(node)
		must.False(t, act, must.Sprint("request with missing volume should never be feasible"))
	}

	must.Eq(t, []string{
		"csi-volume:default:test-volume[0]",
		"csi-volume:default:test-volume[1]",
	}, ctx.Eligibility().MissingResources())

	// Create the volume in the state store
	vid := "test-volume[1]"
	vol := structs.NewCSIVolume(vid, index)
	vol.PluginID = "foo"
	vol.Namespace = structs.DefaultNamespace
	vol.AccessMode = structs.CSIVolumeAccessModeMultiNodeMultiWriter
	vol.AttachmentMode = structs.CSIVolumeAttachmentModeFilesystem
	err = state.UpsertCSIVolume(index, []*structs.CSIVolume{vol})
	must.NoError(t, err)
	index++

	ctx.Reset()
	ctx.Eligibility().Reset()
	checker = NewCSIVolumeChecker(ctx)
	checker.SetNamespace(structs.DefaultNamespace)

	for _, node := range nodes {
		checker.SetVolumes(allocName0, reqs)
		act := checker.Feasible(node)
		must.False(t, act, must.Sprint("request with missing volume should never be feasible"))

		checker.SetVolumes(allocName1, reqs)
		act = checker.Feasible(node)
		must.True(t, act, must.Sprint("request with missing volume should never be feasible"))
	}

	must.Eq(t, []string{
		"csi-volume:default:test-volume[0]",
	}, ctx.Eligibility().MissingResources())
}

func TestNetworkChecker(t *testing.T) {
	ci.Parallel(t)

	_, ctx := MockContext(t)

	node := func(mode string) *structs.Node {
		n := mock.Node()
		n.NodeResources.Networks = append(n.NodeResources.Networks, &structs.NetworkResource{Mode: mode})
		if mode == "bridge" {
			n.NodeResources.NodeNetworks = []*structs.NodeNetworkResource{
				{
					Addresses: []structs.NodeNetworkAddress{
						{
							Alias: "public",
						}, {
							Alias: "private",
						},
					},
				},
			}
		}
		n.Attributes["nomad.version"] = "0.12.0" // mock version is 0.5.0
		n.Meta["public_network"] = "public"
		n.Meta["private_network"] = "private"
		n.Meta["wrong_network"] = "empty"
		return n
	}

	nodes := []*structs.Node{
		node("bridge"),
		node("bridge"),
		node("cni/mynet"),
	}

	checker := NewNetworkChecker(ctx)
	cases := []struct {
		network *structs.NetworkResource
		results []bool
	}{
		{
			network: &structs.NetworkResource{Mode: "host"},
			results: []bool{true, true, true},
		},
		{
			network: &structs.NetworkResource{Mode: "bridge"},
			results: []bool{true, true, false},
		},
		{
			network: &structs.NetworkResource{
				Mode:          "bridge",
				ReservedPorts: []structs.Port{},
				DynamicPorts: []structs.Port{
					{
						Label:       "http",
						Value:       8080,
						To:          8080,
						HostNetwork: "${meta.public_network}",
					},
					{
						Label:       "metrics",
						Value:       9090,
						To:          9090,
						HostNetwork: "${meta.private_network}",
					},
				},
			},
			results: []bool{true, true, false},
		},
		{
			network: &structs.NetworkResource{
				Mode:          "bridge",
				ReservedPorts: []structs.Port{},
				DynamicPorts: []structs.Port{
					{
						Label:       "metrics",
						Value:       9090,
						To:          9090,
						HostNetwork: "${meta.wrong_network}",
					},
				},
			},
			results: []bool{false, false, false},
		},
		{
			network: &structs.NetworkResource{
				Mode:          "bridge",
				ReservedPorts: []structs.Port{},
				DynamicPorts: []structs.Port{
					{
						Label:       "metrics",
						Value:       9090,
						To:          9090,
						HostNetwork: "${meta.nonetwork}",
					},
				},
			},
			results: []bool{false, false, false},
		},
		{
			network: &structs.NetworkResource{
				Mode:          "bridge",
				ReservedPorts: []structs.Port{},
				DynamicPorts: []structs.Port{
					{
						Label:       "metrics",
						Value:       9090,
						To:          9090,
						HostNetwork: "public",
					},
				},
			},
			results: []bool{true, true, false},
		},
		{
			network: &structs.NetworkResource{
				Mode:          "bridge",
				ReservedPorts: []structs.Port{},
				DynamicPorts: []structs.Port{
					{
						Label:       "metrics",
						Value:       9090,
						To:          9090,
						HostNetwork: "${meta.private_network}-nonexisting",
					},
				},
			},
			results: []bool{false, false, false},
		},
		{
			network: &structs.NetworkResource{Mode: "cni/mynet"},
			results: []bool{false, false, true},
		},
		{
			network: &structs.NetworkResource{Mode: "cni/nonexistent"},
			results: []bool{false, false, false},
		},
	}

	for _, c := range cases {
		checker.SetNetwork(c.network)
		for i, node := range nodes {
			must.Eq(t, c.results[i], checker.Feasible(node), must.Sprintf("mode=%q, idx=%d", c.network.Mode, i))
		}
	}
}

func TestNetworkChecker_bridge_upgrade_path(t *testing.T) {
	ci.Parallel(t)

	_, ctx := MockContext(t)

	t.Run("older client", func(t *testing.T) {
		// Create a client that is still on v0.11, which does not have the bridge
		// network finger-printer (and thus no bridge network resource)
		oldClient := mock.Node()
		oldClient.Attributes["nomad.version"] = "0.11.0"

		checker := NewNetworkChecker(ctx)
		checker.SetNetwork(&structs.NetworkResource{Mode: "bridge"})

		ok := checker.Feasible(oldClient)
		must.True(t, ok)
	})

	t.Run("updated client", func(t *testing.T) {
		// Create a client that is updated to 0.12, but did not detect a bridge
		// network resource.
		oldClient := mock.Node()
		oldClient.Attributes["nomad.version"] = "0.12.0"

		checker := NewNetworkChecker(ctx)
		checker.SetNetwork(&structs.NetworkResource{Mode: "bridge"})

		ok := checker.Feasible(oldClient)
		must.False(t, ok)
	})
}

func TestDriverChecker_DriverInfo(t *testing.T) {
	ci.Parallel(t)

	_, ctx := MockContext(t)
	nodes := []*structs.Node{
		mock.Node(),
		mock.Node(),
		mock.Node(),
	}
	nodes[0].Drivers["foo"] = &structs.DriverInfo{
		Detected: true,
		Healthy:  true,
	}
	nodes[1].Drivers["foo"] = &structs.DriverInfo{
		Detected: true,
		Healthy:  false,
	}
	nodes[2].Drivers["foo"] = &structs.DriverInfo{
		Detected: false,
		Healthy:  false,
	}

	drivers := map[string]struct{}{
		"exec": {},
		"foo":  {},
	}
	checker := NewDriverChecker(ctx, drivers)
	cases := []struct {
		Node   *structs.Node
		Result bool
	}{
		{
			Node:   nodes[0],
			Result: true,
		},
		{
			Node:   nodes[1],
			Result: false,
		},
		{
			Node:   nodes[2],
			Result: false,
		},
	}

	for i, c := range cases {
		if act := checker.Feasible(c.Node); act != c.Result {
			t.Fatalf("case(%d) failed: got %v; want %v", i, act, c.Result)
		}
	}
}
func TestDriverChecker_Compatibility(t *testing.T) {
	ci.Parallel(t)

	_, ctx := MockContext(t)
	nodes := []*structs.Node{
		mock.Node(),
		mock.Node(),
		mock.Node(),
		mock.Node(),
	}
	for _, n := range nodes {
		// force compatibility mode
		n.Drivers = nil
	}
	nodes[0].Attributes["driver.foo"] = "1"
	nodes[1].Attributes["driver.foo"] = "0"
	nodes[2].Attributes["driver.foo"] = "true"
	nodes[3].Attributes["driver.foo"] = "False"

	drivers := map[string]struct{}{
		"exec": {},
		"foo":  {},
	}
	checker := NewDriverChecker(ctx, drivers)
	cases := []struct {
		Node   *structs.Node
		Result bool
	}{
		{
			Node:   nodes[0],
			Result: true,
		},
		{
			Node:   nodes[1],
			Result: false,
		},
		{
			Node:   nodes[2],
			Result: true,
		},
		{
			Node:   nodes[3],
			Result: false,
		},
	}

	for i, c := range cases {
		if act := checker.Feasible(c.Node); act != c.Result {
			t.Fatalf("case(%d) failed: got %v; want %v", i, act, c.Result)
		}
	}
}

func Test_HealthChecks(t *testing.T) {
	ci.Parallel(t)

	_, ctx := MockContext(t)

	nodes := []*structs.Node{
		mock.Node(),
		mock.Node(),
		mock.Node(),
	}
	for _, e := range nodes {
		e.Drivers = make(map[string]*structs.DriverInfo)
	}
	nodes[0].Attributes["driver.foo"] = "1"
	nodes[0].Drivers["foo"] = &structs.DriverInfo{
		Detected:          true,
		Healthy:           true,
		HealthDescription: "running",
		UpdateTime:        time.Now(),
	}
	nodes[1].Attributes["driver.bar"] = "1"
	nodes[1].Drivers["bar"] = &structs.DriverInfo{
		Detected:          true,
		Healthy:           false,
		HealthDescription: "not running",
		UpdateTime:        time.Now(),
	}
	nodes[2].Attributes["driver.baz"] = "0"
	nodes[2].Drivers["baz"] = &structs.DriverInfo{
		Detected:          false,
		Healthy:           false,
		HealthDescription: "not running",
		UpdateTime:        time.Now(),
	}

	testDrivers := []string{"foo", "bar", "baz"}
	cases := []struct {
		Node   *structs.Node
		Result bool
	}{
		{
			Node:   nodes[0],
			Result: true,
		},
		{
			Node:   nodes[1],
			Result: false,
		},
		{
			Node:   nodes[2],
			Result: false,
		},
	}

	for i, c := range cases {
		drivers := map[string]struct{}{
			testDrivers[i]: {},
		}
		checker := NewDriverChecker(ctx, drivers)
		act := checker.Feasible(c.Node)
		must.Eq(t, act, c.Result)
	}
}

func TestConstraintChecker(t *testing.T) {
	ci.Parallel(t)

	_, ctx := MockContext(t)
	nodes := []*structs.Node{
		mock.Node(),
		mock.Node(),
		mock.Node(),
		mock.Node(),
	}

	nodes[0].Attributes["kernel.name"] = "freebsd"
	nodes[1].Datacenter = "dc2"
	nodes[2].NodeClass = "large"
	nodes[2].Attributes["foo"] = "bar"
	nodes[3].NodePool = "prod"

	constraints := []*structs.Constraint{
		{
			Operand: "=",
			LTarget: "${node.datacenter}",
			RTarget: "dc1",
		},
		{
			Operand: "is",
			LTarget: "${attr.kernel.name}",
			RTarget: "linux",
		},
		{
			Operand: "!=",
			LTarget: "${node.class}",
			RTarget: "linux-medium-pci",
		},
		{
			Operand: "!=",
			LTarget: "${node.pool}",
			RTarget: "prod",
		},
		{
			Operand: "is_set",
			LTarget: "${attr.foo}",
		},
	}
	checker := NewConstraintChecker(ctx, constraints)
	cases := []struct {
		Node   *structs.Node
		Result bool
	}{
		{
			Node:   nodes[0],
			Result: false,
		},
		{
			Node:   nodes[1],
			Result: false,
		},
		{
			Node:   nodes[2],
			Result: true,
		},
		{
			Node:   nodes[3],
			Result: false,
		},
	}

	for i, c := range cases {
		if act := checker.Feasible(c.Node); act != c.Result {
			t.Fatalf("case(%d) failed: got %v; want %v", i, act, c.Result)
		}
	}
}

func TestResolveConstraintTarget(t *testing.T) {
	ci.Parallel(t)

	type tcase struct {
		target string
		node   *structs.Node
		val    string
		result bool
	}
	node := mock.Node()
	cases := []tcase{
		{
			target: "${node.unique.id}",
			node:   node,
			val:    node.ID,
			result: true,
		},
		{
			target: "${node.datacenter}",
			node:   node,
			val:    node.Datacenter,
			result: true,
		},
		{
			target: "${node.unique.name}",
			node:   node,
			val:    node.Name,
			result: true,
		},
		{
			target: "${node.class}",
			node:   node,
			val:    node.NodeClass,
			result: true,
		},
		{
			target: "${node.foo}",
			node:   node,
			result: false,
		},
		{
			target: "${attr.kernel.name}",
			node:   node,
			val:    node.Attributes["kernel.name"],
			result: true,
		},
		{
			target: "${attr.rand}",
			node:   node,
			val:    "",
			result: false,
		},
		{
			target: "${meta.pci-dss}",
			node:   node,
			val:    node.Meta["pci-dss"],
			result: true,
		},
		{
			target: "${meta.rand}",
			node:   node,
			val:    "",
			result: false,
		},
	}

	for _, tc := range cases {
		res, ok := resolveTarget(tc.target, tc.node)
		must.Eq(t, ok, tc.result)
		if ok {
			must.Eq(t, res, tc.val)
		}
	}
}

func TestCheckConstraint(t *testing.T) {
	ci.Parallel(t)

	type tcase struct {
		op         string
		lVal, rVal any
		result     bool
	}
	cases := []tcase{
		{
			op:   "=",
			lVal: "foo", rVal: "foo",
			result: true,
		},
		{
			op:   "is",
			lVal: "foo", rVal: "foo",
			result: true,
		},
		{
			op:   "==",
			lVal: "foo", rVal: "foo",
			result: true,
		},
		{
			op:   "==",
			lVal: "foo", rVal: nil,
			result: false,
		},
		{
			op:   "==",
			lVal: nil, rVal: "foo",
			result: false,
		},
		{
			op:   "==",
			lVal: nil, rVal: nil,
			result: false,
		},
		{
			op:   "!=",
			lVal: "foo", rVal: "foo",
			result: false,
		},
		{
			op:   "!=",
			lVal: "foo", rVal: "bar",
			result: true,
		},
		{
			op:   "!=",
			lVal: nil, rVal: "foo",
			result: true,
		},
		{
			op:   "!=",
			lVal: "foo", rVal: nil,
			result: true,
		},
		{
			op:   "!=",
			lVal: nil, rVal: nil,
			result: false,
		},
		{
			op:   "not",
			lVal: "foo", rVal: "bar",
			result: true,
		},
		{
			op:   structs.ConstraintVersion,
			lVal: "1.2.3", rVal: "~> 1.0",
			result: true,
		},
		{
			op:   structs.ConstraintVersion,
			lVal: nil, rVal: "~> 1.0",
			result: false,
		},
		{
			op:   structs.ConstraintRegex,
			lVal: "foobarbaz", rVal: "[\\w]+",
			result: true,
		},
		{
			op:   structs.ConstraintRegex,
			lVal: nil, rVal: "[\\w]+",
			result: false,
		},
		{
			op:   "<",
			lVal: "foo", rVal: "bar",
			result: false,
		},
		{
			op:   "<",
			lVal: nil, rVal: "bar",
			result: false,
		},
		{
			op:   structs.ConstraintSetContains,
			lVal: "foo,bar,baz", rVal: "foo,  bar  ",
			result: true,
		},
		{
			op:   structs.ConstraintSetContains,
			lVal: "foo,bar,baz", rVal: "foo,bam",
			result: false,
		},
		{
			op:     structs.ConstraintAttributeIsSet,
			lVal:   "foo",
			result: true,
		},
		{
			op:     structs.ConstraintAttributeIsSet,
			lVal:   nil,
			result: false,
		},
		{
			op:     structs.ConstraintAttributeIsNotSet,
			lVal:   nil,
			result: true,
		},
		{
			op:     structs.ConstraintAttributeIsNotSet,
			lVal:   "foo",
			result: false,
		},
	}

	for _, tc := range cases {
		_, ctx := MockContext(t)
		if res := checkConstraint(ctx, tc.op, tc.lVal, tc.rVal, tc.lVal != nil, tc.rVal != nil); res != tc.result {
			t.Fatalf("TC: %#v, Result: %v", tc, res)
		}
	}
}

func TestCheckOrder(t *testing.T) {
	ci.Parallel(t)

	cases := []struct {
		op         string
		lVal, rVal any
		exp        bool
	}{
		{
			op:   "<",
			lVal: "bar", rVal: "foo",
			exp: true,
		},
		{
			op:   "<=",
			lVal: "foo", rVal: "foo",
			exp: true,
		},
		{
			op:   ">",
			lVal: "bar", rVal: "foo",
			exp: false,
		},
		{
			op:   ">=",
			lVal: "bar", rVal: "bar",
			exp: true,
		},
		{
			op:   ">",
			lVal: "1", rVal: "foo",
			exp: false,
		},
		{
			op:   "<",
			lVal: "10", rVal: "1",
			exp: false,
		},
		{
			op:   "<",
			lVal: "1", rVal: "10",
			exp: true,
		},
		{
			op:   "<",
			lVal: "10.5", rVal: "1.5",
			exp: false,
		},
		{
			op:   "<",
			lVal: "1.5", rVal: "10.5",
			exp: true,
		},
	}
	for _, tc := range cases {
		name := fmt.Sprintf("%v %s %v", tc.lVal, tc.op, tc.rVal)
		t.Run(name, func(t *testing.T) {
			must.Eq(t, tc.exp, checkOrder(tc.op, tc.lVal, tc.rVal))
		})
	}
}

func TestCheckVersionConstraint(t *testing.T) {
	ci.Parallel(t)

	type tcase struct {
		lVal, rVal any
		result     bool
	}
	cases := []tcase{
		{
			lVal: "1.2.3", rVal: "~> 1.0",
			result: true,
		},
		{
			lVal: "1.2.3", rVal: ">= 1.0, < 1.4",
			result: true,
		},
		{
			lVal: "2.0.1", rVal: "~> 1.0",
			result: false,
		},
		{
			lVal: "1.4", rVal: ">= 1.0, < 1.4",
			result: false,
		},
		{
			lVal: 1, rVal: "~> 1.0",
			result: true,
		},
		{
			// Prereleases are never > final releases
			lVal: "1.3.0-beta1", rVal: ">= 0.6.1",
			result: false,
		},
		{
			// Prerelease X.Y.Z must match
			lVal: "1.7.0-alpha1", rVal: ">= 1.6.0-beta1",
			result: false,
		},
		{
			// Meta is ignored
			lVal: "1.3.0-beta1+ent", rVal: "= 1.3.0-beta1",
			result: true,
		},
	}
	for _, tc := range cases {
		_, ctx := MockContext(t)
		p := newVersionConstraintParser(ctx)
		if res := checkVersionMatch(p, tc.lVal, tc.rVal); res != tc.result {
			t.Fatalf("TC: %#v, Result: %v", tc, res)
		}
	}
}

func TestCheckSemverConstraint(t *testing.T) {
	ci.Parallel(t)

	type tcase struct {
		name       string
		lVal, rVal any
		result     bool
	}
	cases := []tcase{
		{
			name: "Pessimistic operator always fails 1",
			lVal: "1.2.3", rVal: "~> 1.0",
			result: false,
		},
		{
			name: "1.2.3 does satisfy >= 1.0, < 1.4",
			lVal: "1.2.3", rVal: ">= 1.0, < 1.4",
			result: true,
		},
		{
			name: "Pessimistic operator always fails 2",
			lVal: "2.0.1", rVal: "~> 1.0",
			result: false,
		},
		{
			name: "1.4 does not satisfy >= 1.0, < 1.4",
			lVal: "1.4", rVal: ">= 1.0, < 1.4",
			result: false,
		},
		{
			name: "Pessimistic operator always fails 3",
			lVal: 1, rVal: "~> 1.0",
			result: false,
		},
		{
			name: "Prereleases are handled according to semver 1",
			lVal: "1.3.0-beta1", rVal: ">= 0.6.1",
			result: true,
		},
		{
			name: "Prereleases are handled according to semver 2",
			lVal: "1.7.0-alpha1", rVal: ">= 1.6.0-beta1",
			result: true,
		},
		{
			name: "Prereleases of same version handled according to semver",
			lVal: "1.7.0-beta", rVal: ">= 1.7.0",
			result: false,
		},
		{
			name: "Prereleases constraints allow GA version according to semver",
			lVal: "1.7.0", rVal: ">= 1.7.0-dev",
			result: true,
		},
		{
			name: "Prereleases constraints allow beta according to semver",
			lVal: "1.7.0-beta.1", rVal: ">= 1.7.0-a",
			result: true,
		},
		{
			name: "Prereleases constraints allow RC version according to semver",
			lVal: "1.7.0-rc.1", rVal: ">= 1.7.0-dev",
			result: true,
		},
		{
			name: "Meta is ignored according to semver",
			lVal: "1.3.0-beta1+ent", rVal: "= 1.3.0-beta1",
			result: true,
		},
	}

	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			_, ctx := MockContext(t)
			p := newSemverConstraintParser(ctx)
			actual := checkVersionMatch(p, tc.lVal, tc.rVal)
			must.Eq(t, tc.result, actual)
		})
	}
}

func TestCheckRegexpConstraint(t *testing.T) {
	ci.Parallel(t)

	type tcase struct {
		lVal, rVal any
		result     bool
	}
	cases := []tcase{
		{
			lVal: "foobar", rVal: "bar",
			result: true,
		},
		{
			lVal: "foobar", rVal: "^foo",
			result: true,
		},
		{
			lVal: "foobar", rVal: "^bar",
			result: false,
		},
		{
			lVal: "zipzap", rVal: "foo",
			result: false,
		},
		{
			lVal: 1, rVal: "foo",
			result: false,
		},
	}
	for _, tc := range cases {
		_, ctx := MockContext(t)
		if res := checkRegexpMatch(ctx, tc.lVal, tc.rVal); res != tc.result {
			t.Fatalf("TC: %#v, Result: %v", tc, res)
		}
	}
}

// This test puts allocations on the node to test if it detects infeasibility of
// nodes correctly and picks the only feasible one
func TestDistinctHostsIterator_JobDistinctHosts(t *testing.T) {
	ci.Parallel(t)

	_, ctx := MockContext(t)
	nodes := []*structs.Node{
		mock.Node(),
		mock.Node(),
		mock.Node(),
	}
	static := NewStaticIterator(ctx, nodes)

	// Create a job with a distinct_hosts constraint and two task groups.
	tg1 := &structs.TaskGroup{Name: "bar"}
	tg2 := &structs.TaskGroup{Name: "baz"}

	job := &structs.Job{
		ID:          "foo",
		Namespace:   structs.DefaultNamespace,
		Constraints: []*structs.Constraint{{Operand: structs.ConstraintDistinctHosts}},
		TaskGroups:  []*structs.TaskGroup{tg1, tg2},
	}

	// Add allocs placing tg1 on node1 and tg2 on node2. This should make the
	// job unsatisfiable on all nodes but node3
	plan := ctx.Plan()
	plan.NodeAllocation[nodes[0].ID] = []*structs.Allocation{
		{
			Namespace: structs.DefaultNamespace,
			TaskGroup: tg1.Name,
			JobID:     job.ID,
			Job:       job,
			ID:        uuid.Generate(),
		},

		// Should be ignored as it is a different job.
		{
			Namespace: structs.DefaultNamespace,
			TaskGroup: tg2.Name,
			JobID:     "ignore 2",
			Job:       job,
			ID:        uuid.Generate(),
		},
	}
	plan.NodeAllocation[nodes[1].ID] = []*structs.Allocation{
		{
			Namespace: structs.DefaultNamespace,
			TaskGroup: tg2.Name,
			JobID:     job.ID,
			Job:       job,
			ID:        uuid.Generate(),
		},

		// Should be ignored as it is a different job.
		{
			Namespace: structs.DefaultNamespace,
			TaskGroup: tg1.Name,
			JobID:     "ignore 2",
			Job:       job,
			ID:        uuid.Generate(),
		},
	}

	proposed := NewDistinctHostsIterator(ctx, static)
	proposed.SetTaskGroup(tg1)
	proposed.SetJob(job)

	out := collectFeasible(proposed)
	if len(out) != 1 {
		t.Fatalf("Bad: %#v", out)
	}

	if out[0].ID != nodes[2].ID {
		t.Fatalf("wrong node picked")
	}
}

func TestDistinctHostsIterator_JobDistinctHosts_Table(t *testing.T) {
	ci.Parallel(t)

	// Create a job with a distinct_hosts constraint and a task group.
	tg1 := &structs.TaskGroup{Name: "bar"}
	job := &structs.Job{
		ID:        "foo",
		Namespace: structs.DefaultNamespace,
		Constraints: []*structs.Constraint{{
			Operand: structs.ConstraintDistinctHosts,
		}},
		TaskGroups: []*structs.TaskGroup{tg1},
	}
	makeJobAllocs := func(js []*structs.Job) []*structs.Allocation {
		na := make([]*structs.Allocation, len(js))
		for i, j := range js {
			allocID := uuid.Generate()
			ns := structs.DefaultNamespace
			if j.Namespace != "" {
				ns = j.Namespace
			}
			na[i] = &structs.Allocation{
				Namespace: ns,
				TaskGroup: j.TaskGroups[0].Name,
				JobID:     j.ID,
				Job:       j,
				ID:        allocID,
			}
		}
		return na
	}

	n1 := mock.Node()
	n2 := mock.Node()
	n3 := mock.Node()

	testCases := []struct {
		name        string
		RTarget     string
		expectLen   int
		expectNodes []*structs.Node
	}{
		{
			name:        "unset",
			RTarget:     "",
			expectLen:   1,
			expectNodes: []*structs.Node{n3},
		},
		{
			name:        "true",
			RTarget:     "true",
			expectLen:   1,
			expectNodes: []*structs.Node{n3},
		},
		{
			name:        "false",
			RTarget:     "false",
			expectLen:   3,
			expectNodes: []*structs.Node{n1, n2, n3},
		},
		{
			name:        "unparsable",
			RTarget:     "not_a_bool",
			expectLen:   1,
			expectNodes: []*structs.Node{n3},
		},
	}
	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			tc := tc
			ci.Parallel(t)

			_, ctx := MockContext(t)
			static := NewStaticIterator(ctx, []*structs.Node{n1, n2, n3})

			j := job.Copy()
			j.Constraints[0].RTarget = tc.RTarget

			// This job has all the same identifiers as the first; however, it is
			// placed in a different namespace to ensure that it doesn't interact
			// with the feasibility of this placement.
			oj := j.Copy()
			oj.Namespace = "different"

			plan := ctx.Plan()
			// Add allocations so that some of the nodes will be ineligible
			// to receive the job when the distinct_hosts constraint
			// is active. This will require the job be placed on n3.
			//
			// Another job (oj) is placed on all of the nodes to ensure that
			// there are no unexpected interactions between namespaces.

			plan.NodeAllocation[n1.ID] = makeJobAllocs([]*structs.Job{j, oj})
			plan.NodeAllocation[n2.ID] = makeJobAllocs([]*structs.Job{j, oj})
			plan.NodeAllocation[n3.ID] = makeJobAllocs([]*structs.Job{oj})

			proposed := NewDistinctHostsIterator(ctx, static)
			proposed.SetTaskGroup(tg1)
			proposed.SetJob(j)

			out := collectFeasible(proposed)
			must.Len(t, tc.expectLen, out, must.Sprintf("Bad: %v", out))
			must.SliceContainsAll(t, tc.expectNodes, out)
		})
	}
}

func TestDistinctHostsIterator_JobDistinctHosts_InfeasibleCount(t *testing.T) {
	ci.Parallel(t)

	_, ctx := MockContext(t)
	nodes := []*structs.Node{
		mock.Node(),
		mock.Node(),
	}
	static := NewStaticIterator(ctx, nodes)

	// Create a job with a distinct_hosts constraint and three task groups.
	tg1 := &structs.TaskGroup{Name: "bar"}
	tg2 := &structs.TaskGroup{Name: "baz"}
	tg3 := &structs.TaskGroup{Name: "bam"}

	job := &structs.Job{
		ID:          "foo",
		Namespace:   structs.DefaultNamespace,
		Constraints: []*structs.Constraint{{Operand: structs.ConstraintDistinctHosts}},
		TaskGroups:  []*structs.TaskGroup{tg1, tg2, tg3},
	}

	// Add allocs placing tg1 on node1 and tg2 on node2. This should make the
	// job unsatisfiable for tg3
	plan := ctx.Plan()
	plan.NodeAllocation[nodes[0].ID] = []*structs.Allocation{
		{
			Namespace: structs.DefaultNamespace,
			TaskGroup: tg1.Name,
			JobID:     job.ID,
			ID:        uuid.Generate(),
		},
	}
	plan.NodeAllocation[nodes[1].ID] = []*structs.Allocation{
		{
			Namespace: structs.DefaultNamespace,
			TaskGroup: tg2.Name,
			JobID:     job.ID,
			ID:        uuid.Generate(),
		},
	}

	proposed := NewDistinctHostsIterator(ctx, static)
	proposed.SetTaskGroup(tg3)
	proposed.SetJob(job)

	// It should not be able to place 3 tasks with only two nodes.
	out := collectFeasible(proposed)
	if len(out) != 0 {
		t.Fatalf("Bad: %#v", out)
	}
}

func TestDistinctHostsIterator_TaskGroupDistinctHosts(t *testing.T) {
	ci.Parallel(t)

	_, ctx := MockContext(t)
	nodes := []*structs.Node{
		mock.Node(),
		mock.Node(),
	}
	static := NewStaticIterator(ctx, nodes)

	// Create a task group with a distinct_hosts constraint.
	tg1 := &structs.TaskGroup{
		Name: "example",
		Constraints: []*structs.Constraint{
			{Operand: structs.ConstraintDistinctHosts},
		},
	}
	tg2 := &structs.TaskGroup{Name: "baz"}

	// Add a planned alloc to node1.
	plan := ctx.Plan()
	plan.NodeAllocation[nodes[0].ID] = []*structs.Allocation{
		{
			Namespace: structs.DefaultNamespace,
			TaskGroup: tg1.Name,
			JobID:     "foo",
		},
	}

	// Add a planned alloc to node2 with the same task group name but a
	// different job.
	plan.NodeAllocation[nodes[1].ID] = []*structs.Allocation{
		{
			Namespace: structs.DefaultNamespace,
			TaskGroup: tg1.Name,
			JobID:     "bar",
		},
	}

	proposed := NewDistinctHostsIterator(ctx, static)
	proposed.SetTaskGroup(tg1)
	proposed.SetJob(&structs.Job{
		ID:        "foo",
		Namespace: structs.DefaultNamespace,
	})

	out := collectFeasible(proposed)
	if len(out) != 1 {
		t.Fatalf("Bad: %#v", out)
	}

	// Expect it to skip the first node as there is a previous alloc on it for
	// the same task group.
	if out[0] != nodes[1] {
		t.Fatalf("Bad: %v", out)
	}

	// Since the other task group doesn't have the constraint, both nodes should
	// be feasible.
	proposed.Reset()
	proposed.SetTaskGroup(tg2)
	out = collectFeasible(proposed)
	if len(out) != 2 {
		t.Fatalf("Bad: %#v", out)
	}
}

// This test puts creates allocations across task groups that use a property
// value to detect if the constraint at the job level properly considers all
// task groups.
func TestDistinctPropertyIterator_JobDistinctProperty(t *testing.T) {
	ci.Parallel(t)

	state, ctx := MockContext(t)
	nodes := []*structs.Node{
		mock.Node(),
		mock.Node(),
		mock.Node(),
		mock.Node(),
		mock.Node(),
	}

	for i, n := range nodes {
		n.Meta["rack"] = fmt.Sprintf("%d", i)

		// Add to state store
		if err := state.UpsertNode(structs.MsgTypeTestSetup, uint64(100+i), n); err != nil {
			t.Fatalf("failed to upsert node: %v", err)
		}
	}

	static := NewStaticIterator(ctx, nodes)

	// Create a job with a distinct_property constraint and a task groups.
	tg1 := &structs.TaskGroup{Name: "bar"}
	tg2 := &structs.TaskGroup{Name: "baz"}

	job := mock.Job()
	job.Constraints = []*structs.Constraint{
		{
			Operand: structs.ConstraintDistinctProperty,
			LTarget: "${meta.rack}",
		},
	}
	job.TaskGroups = []*structs.TaskGroup{tg1, tg2}

	// Add allocs placing tg1 on node1 and 2 and tg2 on node3 and 4. This should make the
	// job unsatisfiable on all nodes but node5. Also mix the allocations
	// existing in the plan and the state store.
	plan := ctx.Plan()
	alloc1ID := uuid.Generate()
	plan.NodeAllocation[nodes[0].ID] = []*structs.Allocation{
		{
			Namespace: structs.DefaultNamespace,
			TaskGroup: tg1.Name,
			JobID:     job.ID,
			Job:       job,
			ID:        alloc1ID,
			NodeID:    nodes[0].ID,
		},

		// Should be ignored as it is a different job.
		{
			Namespace: structs.DefaultNamespace,
			TaskGroup: tg2.Name,
			JobID:     "ignore 2",
			Job:       job,
			ID:        uuid.Generate(),
			NodeID:    nodes[0].ID,
		},
	}
	plan.NodeAllocation[nodes[2].ID] = []*structs.Allocation{
		{
			Namespace: structs.DefaultNamespace,
			TaskGroup: tg2.Name,
			JobID:     job.ID,
			Job:       job,
			ID:        uuid.Generate(),
			NodeID:    nodes[2].ID,
		},

		// Should be ignored as it is a different job.
		{
			Namespace: structs.DefaultNamespace,
			TaskGroup: tg1.Name,
			JobID:     "ignore 2",
			Job:       job,
			ID:        uuid.Generate(),
			NodeID:    nodes[2].ID,
		},
	}

	// Put an allocation on Node 5 but make it stopped in the plan
	stoppingAllocID := uuid.Generate()
	plan.NodeUpdate[nodes[4].ID] = []*structs.Allocation{
		{
			Namespace: structs.DefaultNamespace,
			TaskGroup: tg2.Name,
			JobID:     job.ID,
			Job:       job,
			ID:        stoppingAllocID,
			NodeID:    nodes[4].ID,
		},
	}

	upserting := []*structs.Allocation{
		// Have one of the allocations exist in both the plan and the state
		// store. This resembles an allocation update
		{
			Namespace: structs.DefaultNamespace,
			TaskGroup: tg1.Name,
			JobID:     job.ID,
			Job:       job,
			ID:        alloc1ID,
			EvalID:    uuid.Generate(),
			NodeID:    nodes[0].ID,
		},

		{
			Namespace: structs.DefaultNamespace,
			TaskGroup: tg1.Name,
			JobID:     job.ID,
			Job:       job,
			ID:        uuid.Generate(),
			EvalID:    uuid.Generate(),
			NodeID:    nodes[1].ID,
		},

		// Should be ignored as it is a different job.
		{
			Namespace: structs.DefaultNamespace,
			TaskGroup: tg2.Name,
			JobID:     "ignore 2",
			Job:       job,
			ID:        uuid.Generate(),
			EvalID:    uuid.Generate(),
			NodeID:    nodes[1].ID,
		},
		{
			Namespace: structs.DefaultNamespace,
			TaskGroup: tg2.Name,
			JobID:     job.ID,
			Job:       job,
			ID:        uuid.Generate(),
			EvalID:    uuid.Generate(),
			NodeID:    nodes[3].ID,
		},

		// Should be ignored as it is a different job.
		{
			Namespace: structs.DefaultNamespace,
			TaskGroup: tg1.Name,
			JobID:     "ignore 2",
			Job:       job,
			ID:        uuid.Generate(),
			EvalID:    uuid.Generate(),
			NodeID:    nodes[3].ID,
		},
		{
			Namespace: structs.DefaultNamespace,
			TaskGroup: tg2.Name,
			JobID:     job.ID,
			Job:       job,
			ID:        stoppingAllocID,
			EvalID:    uuid.Generate(),
			NodeID:    nodes[4].ID,
		},
	}

	for _, alloc := range upserting {
		must.NoError(t, state.UpsertJob(structs.MsgTypeTestSetup, 999, nil, alloc.Job))
	}

	if err := state.UpsertAllocs(structs.MsgTypeTestSetup, 1000, upserting); err != nil {
		t.Fatalf("failed to UpsertAllocs: %v", err)
	}

	proposed := NewDistinctPropertyIterator(ctx, static)
	proposed.SetJob(job)
	proposed.SetTaskGroup(tg2)
	proposed.Reset()

	out := collectFeasible(proposed)
	if len(out) != 1 {
		t.Fatalf("Bad: %#v", out)
	}
	if out[0].ID != nodes[4].ID {
		t.Fatalf("wrong node picked")
	}
}

// This test creates allocations across task groups that use a property value to
// detect if the constraint at the job level properly considers all task groups
// when the constraint allows a count greater than one
func TestDistinctPropertyIterator_JobDistinctProperty_Count(t *testing.T) {
	ci.Parallel(t)

	state, ctx := MockContext(t)
	nodes := []*structs.Node{
		mock.Node(),
		mock.Node(),
		mock.Node(),
	}

	for i, n := range nodes {
		n.Meta["rack"] = fmt.Sprintf("%d", i)

		// Add to state store
		if err := state.UpsertNode(structs.MsgTypeTestSetup, uint64(100+i), n); err != nil {
			t.Fatalf("failed to upsert node: %v", err)
		}
	}

	static := NewStaticIterator(ctx, nodes)

	// Create a job with a distinct_property constraint and a task groups.
	tg1 := &structs.TaskGroup{Name: "bar"}
	tg2 := &structs.TaskGroup{Name: "baz"}

	job := &structs.Job{
		ID:        "foo",
		Namespace: structs.DefaultNamespace,
		Constraints: []*structs.Constraint{
			{
				Operand: structs.ConstraintDistinctProperty,
				LTarget: "${meta.rack}",
				RTarget: "2",
			},
		},
		TaskGroups: []*structs.TaskGroup{tg1, tg2},
	}

	// Add allocs placing two allocations on both node 1 and 2 and only one on
	// node 3. This should make the job unsatisfiable on all nodes but node5.
	// Also mix the allocations existing in the plan and the state store.
	plan := ctx.Plan()
	alloc1ID := uuid.Generate()
	plan.NodeAllocation[nodes[0].ID] = []*structs.Allocation{
		{
			Namespace: structs.DefaultNamespace,
			TaskGroup: tg1.Name,
			JobID:     job.ID,
			Job:       job,
			ID:        alloc1ID,
			NodeID:    nodes[0].ID,
		},

		{
			Namespace: structs.DefaultNamespace,
			TaskGroup: tg2.Name,
			JobID:     job.ID,
			Job:       job,
			ID:        alloc1ID,
			NodeID:    nodes[0].ID,
		},

		// Should be ignored as it is a different job.
		{
			Namespace: structs.DefaultNamespace,
			TaskGroup: tg2.Name,
			JobID:     "ignore 2",
			Job:       job,
			ID:        uuid.Generate(),
			NodeID:    nodes[0].ID,
		},
	}
	plan.NodeAllocation[nodes[1].ID] = []*structs.Allocation{
		{
			Namespace: structs.DefaultNamespace,
			TaskGroup: tg1.Name,
			JobID:     job.ID,
			Job:       job,
			ID:        uuid.Generate(),
			NodeID:    nodes[1].ID,
		},

		{
			Namespace: structs.DefaultNamespace,
			TaskGroup: tg2.Name,
			JobID:     job.ID,
			Job:       job,
			ID:        uuid.Generate(),
			NodeID:    nodes[1].ID,
		},

		// Should be ignored as it is a different job.
		{
			Namespace: structs.DefaultNamespace,
			TaskGroup: tg1.Name,
			JobID:     "ignore 2",
			Job:       job,
			ID:        uuid.Generate(),
			NodeID:    nodes[1].ID,
		},
	}
	plan.NodeAllocation[nodes[2].ID] = []*structs.Allocation{
		{
			Namespace: structs.DefaultNamespace,
			TaskGroup: tg1.Name,
			JobID:     job.ID,
			Job:       job,
			ID:        uuid.Generate(),
			NodeID:    nodes[2].ID,
		},

		// Should be ignored as it is a different job.
		{
			Namespace: structs.DefaultNamespace,
			TaskGroup: tg1.Name,
			JobID:     "ignore 2",
			Job:       job,
			ID:        uuid.Generate(),
			NodeID:    nodes[2].ID,
		},
	}

	// Put an allocation on Node 3 but make it stopped in the plan
	stoppingAllocID := uuid.Generate()
	plan.NodeUpdate[nodes[2].ID] = []*structs.Allocation{
		{
			Namespace: structs.DefaultNamespace,
			TaskGroup: tg2.Name,
			JobID:     job.ID,
			Job:       job,
			ID:        stoppingAllocID,
			NodeID:    nodes[2].ID,
		},
	}

	upserting := []*structs.Allocation{
		// Have one of the allocations exist in both the plan and the state
		// store. This resembles an allocation update
		{
			Namespace: structs.DefaultNamespace,
			TaskGroup: tg1.Name,
			JobID:     job.ID,
			Job:       job,
			ID:        alloc1ID,
			EvalID:    uuid.Generate(),
			NodeID:    nodes[0].ID,
		},

		{
			Namespace: structs.DefaultNamespace,
			TaskGroup: tg1.Name,
			JobID:     job.ID,
			Job:       job,
			ID:        uuid.Generate(),
			EvalID:    uuid.Generate(),
			NodeID:    nodes[1].ID,
		},

		{
			Namespace: structs.DefaultNamespace,
			TaskGroup: tg2.Name,
			JobID:     job.ID,
			Job:       job,
			ID:        uuid.Generate(),
			EvalID:    uuid.Generate(),
			NodeID:    nodes[0].ID,
		},

		// Should be ignored as it is a different job.
		{
			Namespace: structs.DefaultNamespace,
			TaskGroup: tg1.Name,
			JobID:     "ignore 2",
			Job:       job,
			ID:        uuid.Generate(),
			EvalID:    uuid.Generate(),
			NodeID:    nodes[1].ID,
		},
		{
			Namespace: structs.DefaultNamespace,
			TaskGroup: tg2.Name,
			JobID:     "ignore 2",
			Job:       job,
			ID:        uuid.Generate(),
			EvalID:    uuid.Generate(),
			NodeID:    nodes[1].ID,
		},
	}
	if err := state.UpsertAllocs(structs.MsgTypeTestSetup, 1000, upserting); err != nil {
		t.Fatalf("failed to UpsertAllocs: %v", err)
	}

	proposed := NewDistinctPropertyIterator(ctx, static)
	proposed.SetJob(job)
	proposed.SetTaskGroup(tg2)
	proposed.Reset()

	out := collectFeasible(proposed)
	if len(out) != 1 {
		t.Fatalf("Bad: %#v", out)
	}
	if out[0].ID != nodes[2].ID {
		t.Fatalf("wrong node picked")
	}
}

// This test checks that if a node has an allocation on it that gets stopped,
// there is a plan to re-use that for a new allocation, that the next select
// won't select that node.
func TestDistinctPropertyIterator_JobDistinctProperty_RemoveAndReplace(t *testing.T) {
	ci.Parallel(t)

	state, ctx := MockContext(t)
	nodes := []*structs.Node{
		mock.Node(),
	}

	nodes[0].Meta["rack"] = "1"

	// Add to state store
	if err := state.UpsertNode(structs.MsgTypeTestSetup, uint64(100), nodes[0]); err != nil {
		t.Fatalf("failed to upsert node: %v", err)
	}

	static := NewStaticIterator(ctx, nodes)

	// Create a job with a distinct_property constraint and a task groups.
	job := mock.Job()
	job.Constraints = []*structs.Constraint{
		{
			Operand: structs.ConstraintDistinctProperty,
			LTarget: "${meta.rack}",
		},
	}
	job.TaskGroups = []*structs.TaskGroup{{Name: "bar"}}

	must.NoError(t, state.UpsertJob(structs.MsgTypeTestSetup, 999, nil, job))

	plan := ctx.Plan()
	plan.NodeAllocation[nodes[0].ID] = []*structs.Allocation{
		{
			Namespace: structs.DefaultNamespace,
			TaskGroup: job.TaskGroups[0].Name,
			JobID:     job.ID,
			Job:       job,
			ID:        uuid.Generate(),
			NodeID:    nodes[0].ID,
		},
	}

	stoppingAllocID := uuid.Generate()
	plan.NodeUpdate[nodes[0].ID] = []*structs.Allocation{
		{
			Namespace: structs.DefaultNamespace,
			TaskGroup: job.TaskGroups[0].Name,
			JobID:     job.ID,
			Job:       job,
			ID:        stoppingAllocID,
			NodeID:    nodes[0].ID,
		},
	}

	upserting := []*structs.Allocation{
		{
			Namespace: structs.DefaultNamespace,
			TaskGroup: job.TaskGroups[0].Name,
			JobID:     job.ID,
			Job:       job,
			ID:        stoppingAllocID,
			EvalID:    uuid.Generate(),
			NodeID:    nodes[0].ID,
		},
	}
	if err := state.UpsertAllocs(structs.MsgTypeTestSetup, 1000, upserting); err != nil {
		t.Fatalf("failed to UpsertAllocs: %v", err)
	}

	proposed := NewDistinctPropertyIterator(ctx, static)
	proposed.SetJob(job)
	proposed.SetTaskGroup(job.TaskGroups[0])
	proposed.Reset()

	out := collectFeasible(proposed)
	if len(out) != 0 {
		t.Fatalf("Bad: %#v", out)
	}
}

// This test creates previous allocations selecting certain property values to
// test if it detects infeasibility of property values correctly and picks the
// only feasible one
func TestDistinctPropertyIterator_JobDistinctProperty_Infeasible(t *testing.T) {
	ci.Parallel(t)

	state, ctx := MockContext(t)
	nodes := []*structs.Node{
		mock.Node(),
		mock.Node(),
	}

	for i, n := range nodes {
		n.Meta["rack"] = fmt.Sprintf("%d", i)

		// Add to state store
		if err := state.UpsertNode(structs.MsgTypeTestSetup, uint64(100+i), n); err != nil {
			t.Fatalf("failed to upsert node: %v", err)
		}
	}

	static := NewStaticIterator(ctx, nodes)

	// Create a job with a distinct_property constraint and a task groups.
	tg1 := &structs.TaskGroup{Name: "bar"}
	tg2 := &structs.TaskGroup{Name: "baz"}
	tg3 := &structs.TaskGroup{Name: "bam"}

	job := mock.Job()
	job.Constraints = []*structs.Constraint{
		{
			Operand: structs.ConstraintDistinctProperty,
			LTarget: "${meta.rack}",
		},
	}
	job.TaskGroups = []*structs.TaskGroup{tg1, tg2, tg3}

	must.NoError(t, state.UpsertJob(structs.MsgTypeTestSetup, 999, nil, job))

	// Add allocs placing tg1 on node1 and tg2 on node2. This should make the
	// job unsatisfiable for tg3.
	plan := ctx.Plan()
	plan.NodeAllocation[nodes[0].ID] = []*structs.Allocation{
		{
			Namespace: structs.DefaultNamespace,
			TaskGroup: tg1.Name,
			JobID:     job.ID,
			Job:       job,
			ID:        uuid.Generate(),
			NodeID:    nodes[0].ID,
		},
	}
	upserting := []*structs.Allocation{
		{
			Namespace: structs.DefaultNamespace,
			TaskGroup: tg2.Name,
			JobID:     job.ID,
			Job:       job,
			ID:        uuid.Generate(),
			EvalID:    uuid.Generate(),
			NodeID:    nodes[1].ID,
		},
	}
	if err := state.UpsertAllocs(structs.MsgTypeTestSetup, 1000, upserting); err != nil {
		t.Fatalf("failed to UpsertAllocs: %v", err)
	}

	proposed := NewDistinctPropertyIterator(ctx, static)
	proposed.SetJob(job)
	proposed.SetTaskGroup(tg3)
	proposed.Reset()

	out := collectFeasible(proposed)
	if len(out) != 0 {
		t.Fatalf("Bad: %#v", out)
	}
}

// This test creates previous allocations selecting certain property values to
// test if it detects infeasibility of property values correctly and picks the
// only feasible one
func TestDistinctPropertyIterator_JobDistinctProperty_Infeasible_Count(t *testing.T) {
	ci.Parallel(t)

	state, ctx := MockContext(t)
	nodes := []*structs.Node{
		mock.Node(),
		mock.Node(),
	}

	for i, n := range nodes {
		n.Meta["rack"] = fmt.Sprintf("%d", i)

		// Add to state store
		if err := state.UpsertNode(structs.MsgTypeTestSetup, uint64(100+i), n); err != nil {
			t.Fatalf("failed to upsert node: %v", err)
		}
	}

	static := NewStaticIterator(ctx, nodes)

	// Create a job with a distinct_property constraint and a task groups.
	tg1 := &structs.TaskGroup{Name: "bar"}
	tg2 := &structs.TaskGroup{Name: "baz"}
	tg3 := &structs.TaskGroup{Name: "bam"}

	job := mock.Job()
	job.Constraints = []*structs.Constraint{
		{
			Operand: structs.ConstraintDistinctProperty,
			LTarget: "${meta.rack}",
			RTarget: "2",
		},
	}
	job.TaskGroups = []*structs.TaskGroup{tg1, tg2, tg3}

	must.NoError(t, state.UpsertJob(structs.MsgTypeTestSetup, 999, nil, job))

	// Add allocs placing two tg1's on node1 and two tg2's on node2. This should
	// make the job unsatisfiable for tg3.
	plan := ctx.Plan()
	plan.NodeAllocation[nodes[0].ID] = []*structs.Allocation{
		{
			Namespace: structs.DefaultNamespace,
			TaskGroup: tg1.Name,
			JobID:     job.ID,
			Job:       job,
			ID:        uuid.Generate(),
			NodeID:    nodes[0].ID,
		},
		{
			Namespace: structs.DefaultNamespace,
			TaskGroup: tg2.Name,
			JobID:     job.ID,
			Job:       job,
			ID:        uuid.Generate(),
			NodeID:    nodes[0].ID,
		},
	}
	upserting := []*structs.Allocation{
		{
			Namespace: structs.DefaultNamespace,
			TaskGroup: tg1.Name,
			JobID:     job.ID,
			Job:       job,
			ID:        uuid.Generate(),
			EvalID:    uuid.Generate(),
			NodeID:    nodes[1].ID,
		},
		{
			Namespace: structs.DefaultNamespace,
			TaskGroup: tg2.Name,
			JobID:     job.ID,
			Job:       job,
			ID:        uuid.Generate(),
			EvalID:    uuid.Generate(),
			NodeID:    nodes[1].ID,
		},
	}
	if err := state.UpsertAllocs(structs.MsgTypeTestSetup, 1000, upserting); err != nil {
		t.Fatalf("failed to UpsertAllocs: %v", err)
	}

	proposed := NewDistinctPropertyIterator(ctx, static)
	proposed.SetJob(job)
	proposed.SetTaskGroup(tg3)
	proposed.Reset()

	out := collectFeasible(proposed)
	if len(out) != 0 {
		t.Fatalf("Bad: %#v", out)
	}
}

// This test creates previous allocations selecting certain property values to
// test if it detects infeasibility of property values correctly and picks the
// only feasible one when the constraint is at the task group.
func TestDistinctPropertyIterator_TaskGroupDistinctProperty(t *testing.T) {
	ci.Parallel(t)

	state, ctx := MockContext(t)
	nodes := []*structs.Node{
		mock.Node(),
		mock.Node(),
		mock.Node(),
	}

	for i, n := range nodes {
		n.Meta["rack"] = fmt.Sprintf("%d", i)

		// Add to state store
		if err := state.UpsertNode(structs.MsgTypeTestSetup, uint64(100+i), n); err != nil {
			t.Fatalf("failed to upsert node: %v", err)
		}
	}

	static := NewStaticIterator(ctx, nodes)

	// Create a job with a task group with the distinct_property constraint
	tg1 := &structs.TaskGroup{
		Name: "example",
		Constraints: []*structs.Constraint{
			{
				Operand: structs.ConstraintDistinctProperty,
				LTarget: "${meta.rack}",
			},
		},
	}
	tg2 := &structs.TaskGroup{Name: "baz"}

	job := mock.Job()
	job.TaskGroups = []*structs.TaskGroup{tg1, tg2}

	must.NoError(t, state.UpsertJob(structs.MsgTypeTestSetup, 999, nil, job))

	job2 := mock.Job()
	job2.ID = "ignore 2"
	job2.TaskGroups = []*structs.TaskGroup{tg1.Copy()}
	must.NoError(t, state.UpsertJob(structs.MsgTypeTestSetup, 999, nil, job2))

	// Add allocs placing tg1 on node1 and 2. This should make the
	// job unsatisfiable on all nodes but node3. Also mix the allocations
	// existing in the plan and the state store.
	plan := ctx.Plan()
	plan.NodeAllocation[nodes[0].ID] = []*structs.Allocation{
		{
			Namespace: structs.DefaultNamespace,
			TaskGroup: tg1.Name,
			JobID:     job.ID,
			Job:       job,
			ID:        uuid.Generate(),
			NodeID:    nodes[0].ID,
		},
	}

	// Put an allocation on Node 3 but make it stopped in the plan
	stoppingAllocID := uuid.Generate()
	plan.NodeUpdate[nodes[2].ID] = []*structs.Allocation{
		{
			Namespace: structs.DefaultNamespace,
			TaskGroup: tg1.Name,
			JobID:     job.ID,
			Job:       job,
			ID:        stoppingAllocID,
			NodeID:    nodes[2].ID,
		},
	}

	upserting := []*structs.Allocation{
		{
			Namespace: structs.DefaultNamespace,
			TaskGroup: tg1.Name,
			JobID:     job.ID,
			Job:       job,
			ID:        uuid.Generate(),
			EvalID:    uuid.Generate(),
			NodeID:    nodes[1].ID,
		},

		// Should be ignored as it is a different job.
		{
			Namespace: structs.DefaultNamespace,
			TaskGroup: tg1.Name,
			JobID:     "ignore 2",
			Job:       job2,
			ID:        uuid.Generate(),
			EvalID:    uuid.Generate(),
			NodeID:    nodes[2].ID,
		},

		{
			Namespace: structs.DefaultNamespace,
			TaskGroup: tg1.Name,
			JobID:     job.ID,
			Job:       job,
			ID:        stoppingAllocID,
			EvalID:    uuid.Generate(),
			NodeID:    nodes[2].ID,
		},
	}
	if err := state.UpsertAllocs(structs.MsgTypeTestSetup, 1000, upserting); err != nil {
		t.Fatalf("failed to UpsertAllocs: %v", err)
	}

	proposed := NewDistinctPropertyIterator(ctx, static)
	proposed.SetJob(job)
	proposed.SetTaskGroup(tg1)
	proposed.Reset()

	out := collectFeasible(proposed)
	if len(out) != 1 {
		t.Fatalf("Bad: %#v", out)
	}
	if out[0].ID != nodes[2].ID {
		t.Fatalf("wrong node picked")
	}

	// Since the other task group doesn't have the constraint, both nodes should
	// be feasible.
	proposed.SetTaskGroup(tg2)
	proposed.Reset()

	out = collectFeasible(proposed)
	if len(out) != 3 {
		t.Fatalf("Bad: %#v", out)
	}
}

func collectFeasible(iter FeasibleIterator) (out []*structs.Node) {
	for {
		next := iter.Next()
		if next == nil {
			break
		}
		out = append(out, next)
	}
	return
}

// mockFeasibilityChecker is a FeasibilityChecker that returns predetermined
// feasibility values.
type mockFeasibilityChecker struct {
	retVals []bool
	i       int
}

func newMockFeasibilityChecker(values ...bool) *mockFeasibilityChecker {
	return &mockFeasibilityChecker{retVals: values}
}

func (c *mockFeasibilityChecker) Feasible(*structs.Node) bool {
	if c.i >= len(c.retVals) {
		c.i++
		return false
	}

	f := c.retVals[c.i]
	c.i++
	return f
}

// calls returns how many times the checker was called.
func (c *mockFeasibilityChecker) calls() int { return c.i }

func TestFeasibilityWrapper_JobIneligible(t *testing.T) {
	ci.Parallel(t)

	_, ctx := MockContext(t)
	nodes := []*structs.Node{mock.Node()}
	static := NewStaticIterator(ctx, nodes)
	mocked := newMockFeasibilityChecker(false)
	wrapper := NewFeasibilityWrapper(ctx, static, []FeasibilityChecker{mocked}, nil, nil)

	// Set the job to ineligible
	ctx.Eligibility().SetJobEligibility(false, nodes[0].ComputedClass)

	// Run the wrapper.
	out := collectFeasible(wrapper)

	if out != nil || mocked.calls() != 0 {
		t.Fatalf("bad: %#v %d", out, mocked.calls())
	}
}

func TestFeasibilityWrapper_JobEscapes(t *testing.T) {
	ci.Parallel(t)

	_, ctx := MockContext(t)
	nodes := []*structs.Node{mock.Node()}
	static := NewStaticIterator(ctx, nodes)
	mocked := newMockFeasibilityChecker(false)
	wrapper := NewFeasibilityWrapper(ctx, static, []FeasibilityChecker{mocked}, nil, nil)

	// Set the job to escaped
	cc := nodes[0].ComputedClass
	ctx.Eligibility().job[cc] = EvalComputedClassEscaped

	// Run the wrapper.
	out := collectFeasible(wrapper)

	if out != nil || mocked.calls() != 1 {
		t.Fatalf("bad: %#v", out)
	}

	// Ensure that the job status didn't change from escaped even though the
	// option failed.
	if status := ctx.Eligibility().JobStatus(cc); status != EvalComputedClassEscaped {
		t.Fatalf("job status is %v; want %v", status, EvalComputedClassEscaped)
	}
}

func TestFeasibilityWrapper_JobAndTg_Eligible(t *testing.T) {
	ci.Parallel(t)

	_, ctx := MockContext(t)
	nodes := []*structs.Node{mock.Node()}
	static := NewStaticIterator(ctx, nodes)
	jobMock := newMockFeasibilityChecker(true)
	tgMock := newMockFeasibilityChecker(false)
	wrapper := NewFeasibilityWrapper(ctx, static, []FeasibilityChecker{jobMock}, []FeasibilityChecker{tgMock}, nil)

	// Set the job to escaped
	cc := nodes[0].ComputedClass
	ctx.Eligibility().job[cc] = EvalComputedClassEligible
	ctx.Eligibility().SetTaskGroupEligibility(true, "foo", cc)
	wrapper.SetTaskGroup("foo")

	// Run the wrapper.
	out := collectFeasible(wrapper)

	if out == nil || tgMock.calls() != 0 {
		t.Fatalf("bad: %#v %v", out, tgMock.calls())
	}
}

func TestFeasibilityWrapper_JobEligible_TgIneligible(t *testing.T) {
	ci.Parallel(t)

	_, ctx := MockContext(t)
	nodes := []*structs.Node{mock.Node()}
	static := NewStaticIterator(ctx, nodes)
	jobMock := newMockFeasibilityChecker(true)
	tgMock := newMockFeasibilityChecker(false)
	wrapper := NewFeasibilityWrapper(ctx, static, []FeasibilityChecker{jobMock}, []FeasibilityChecker{tgMock}, nil)

	// Set the job to escaped
	cc := nodes[0].ComputedClass
	ctx.Eligibility().job[cc] = EvalComputedClassEligible
	ctx.Eligibility().SetTaskGroupEligibility(false, "foo", cc)
	wrapper.SetTaskGroup("foo")

	// Run the wrapper.
	out := collectFeasible(wrapper)

	if out != nil || tgMock.calls() != 0 {
		t.Fatalf("bad: %#v %v", out, tgMock.calls())
	}
}

func TestFeasibilityWrapper_JobEligible_TgEscaped(t *testing.T) {
	ci.Parallel(t)

	_, ctx := MockContext(t)
	nodes := []*structs.Node{mock.Node()}
	static := NewStaticIterator(ctx, nodes)
	jobMock := newMockFeasibilityChecker(true)
	tgMock := newMockFeasibilityChecker(true)
	wrapper := NewFeasibilityWrapper(ctx, static, []FeasibilityChecker{jobMock}, []FeasibilityChecker{tgMock}, nil)

	// Set the job to escaped
	cc := nodes[0].ComputedClass
	ctx.Eligibility().job[cc] = EvalComputedClassEligible
	ctx.Eligibility().taskGroups["foo"] =
		map[string]ComputedClassFeasibility{cc: EvalComputedClassEscaped}
	wrapper.SetTaskGroup("foo")

	// Run the wrapper.
	out := collectFeasible(wrapper)

	if out == nil || tgMock.calls() != 1 {
		t.Fatalf("bad: %#v %v", out, tgMock.calls())
	}

	if e, ok := ctx.Eligibility().taskGroups["foo"][cc]; !ok || e != EvalComputedClassEscaped {
		t.Fatalf("bad: %v %v", e, ok)
	}
}

func TestSetContainsAny(t *testing.T) {
	ci.Parallel(t)

	must.True(t, checkSetContainsAny("a", "a"))
	must.True(t, checkSetContainsAny("a,b", "a"))
	must.True(t, checkSetContainsAny("  a,b  ", "a "))
	must.True(t, checkSetContainsAny("a", "a"))
	must.False(t, checkSetContainsAny("b", "a"))
}

func TestDeviceChecker(t *testing.T) {
	ci.Parallel(t)

	getTg := func(devices ...*structs.RequestedDevice) *structs.TaskGroup {
		return &structs.TaskGroup{
			Name: "example",
			Tasks: []*structs.Task{
				{
					Resources: &structs.Resources{
						Devices: devices,
					},
				},
			},
		}
	}

	// Just type
	gpuTypeReq := &structs.RequestedDevice{
		Name:  "gpu",
		Count: 1,
	}
	fpgaTypeReq := &structs.RequestedDevice{
		Name:  "fpga",
		Count: 1,
	}

	// vendor/type
	gpuVendorTypeReq := &structs.RequestedDevice{
		Name:  "nvidia/gpu",
		Count: 1,
	}
	fpgaVendorTypeReq := &structs.RequestedDevice{
		Name:  "nvidia/fpga",
		Count: 1,
	}

	// vendor/type/model
	gpuFullReq := &structs.RequestedDevice{
		Name:  "nvidia/gpu/1080ti",
		Count: 1,
	}
	fpgaFullReq := &structs.RequestedDevice{
		Name:  "nvidia/fpga/F100",
		Count: 1,
	}

	// Just type but high count
	gpuTypeHighCountReq := &structs.RequestedDevice{
		Name:  "gpu",
		Count: 3,
	}

	getNode := func(devices ...*structs.NodeDeviceResource) *structs.Node {
		n := mock.Node()
		n.NodeResources.Devices = devices
		return n
	}

	nvidia_A := &structs.NodeDeviceResource{
		Vendor: "nvidia",
		Type:   "gpu",
		Name:   "1080ti",
		Attributes: map[string]*psstructs.Attribute{
			"memory":        psstructs.NewIntAttribute(4, psstructs.UnitGiB),
			"pci_bandwidth": psstructs.NewIntAttribute(995, psstructs.UnitMiBPerS),
			"cores_clock":   psstructs.NewIntAttribute(800, psstructs.UnitMHz),
		},
		Instances: []*structs.NodeDevice{
			{
				ID:      uuid.Generate(),
				Healthy: true,
			},
			{
				ID:      uuid.Generate(),
				Healthy: true,
			},
		},
	}

	nvidia_B := &structs.NodeDeviceResource{
		Vendor: "nvidia",
		Type:   "gpu",
		Name:   "2080ti",
		Attributes: map[string]*psstructs.Attribute{
			"memory":        psstructs.NewIntAttribute(4, psstructs.UnitGiB),
			"pci_bandwidth": psstructs.NewIntAttribute(995, psstructs.UnitMiBPerS),
			"cores_clock":   psstructs.NewIntAttribute(800, psstructs.UnitMHz),
		},
		Instances: []*structs.NodeDevice{
			{
				ID:      uuid.Generate(),
				Healthy: true,
			},
			{
				ID:      uuid.Generate(),
				Healthy: true,
			},
		},
	}

	nvidiaUnhealthy := &structs.NodeDeviceResource{
		Vendor: "nvidia",
		Type:   "gpu",
		Name:   "1080ti",
		Instances: []*structs.NodeDevice{
			{
				ID:      uuid.Generate(),
				Healthy: false,
			},
			{
				ID:      uuid.Generate(),
				Healthy: false,
			},
		},
	}

	cases := []struct {
		Name             string
		Result           bool
		NodeDevices      []*structs.NodeDeviceResource
		RequestedDevices []*structs.RequestedDevice
	}{
		{
			Name:             "no devices on node",
			Result:           false,
			NodeDevices:      nil,
			RequestedDevices: []*structs.RequestedDevice{gpuTypeReq},
		},
		{
			Name:             "no requested devices on empty node",
			Result:           true,
			NodeDevices:      nil,
			RequestedDevices: nil,
		},
		{
			Name:             "gpu devices by type",
			Result:           true,
			NodeDevices:      []*structs.NodeDeviceResource{nvidia_A},
			RequestedDevices: []*structs.RequestedDevice{gpuTypeReq},
		},
		{
			Name:             "wrong devices by type",
			Result:           false,
			NodeDevices:      []*structs.NodeDeviceResource{nvidia_A},
			RequestedDevices: []*structs.RequestedDevice{fpgaTypeReq},
		},
		{
			Name:             "devices by type unhealthy node",
			Result:           false,
			NodeDevices:      []*structs.NodeDeviceResource{nvidiaUnhealthy},
			RequestedDevices: []*structs.RequestedDevice{gpuTypeReq},
		},
		{
			Name:             "gpu devices by vendor/type",
			Result:           true,
			NodeDevices:      []*structs.NodeDeviceResource{nvidia_A},
			RequestedDevices: []*structs.RequestedDevice{gpuVendorTypeReq},
		},
		{
			Name:             "wrong devices by vendor/type",
			Result:           false,
			NodeDevices:      []*structs.NodeDeviceResource{nvidia_A},
			RequestedDevices: []*structs.RequestedDevice{fpgaVendorTypeReq},
		},
		{
			Name:             "gpu devices by vendor/type/model",
			Result:           true,
			NodeDevices:      []*structs.NodeDeviceResource{nvidia_A},
			RequestedDevices: []*structs.RequestedDevice{gpuFullReq},
		},
		{
			Name:             "wrong devices by vendor/type/model",
			Result:           false,
			NodeDevices:      []*structs.NodeDeviceResource{nvidia_A},
			RequestedDevices: []*structs.RequestedDevice{fpgaFullReq},
		},
		{
			Name:             "too many requested",
			Result:           false,
			NodeDevices:      []*structs.NodeDeviceResource{nvidia_A},
			RequestedDevices: []*structs.RequestedDevice{gpuTypeHighCountReq},
		},
		{
			Name:        "meets constraints requirement",
			Result:      true,
			NodeDevices: []*structs.NodeDeviceResource{nvidia_A},
			RequestedDevices: []*structs.RequestedDevice{
				{
					Name:  "nvidia/gpu",
					Count: 1,
					Constraints: []*structs.Constraint{
						{
							Operand: "=",
							LTarget: "${device.model}",
							RTarget: "1080ti",
						},
						{
							Operand: ">",
							LTarget: "${device.attr.memory}",
							RTarget: "1320.5 MB",
						},
						{
							Operand: "<=",
							LTarget: "${device.attr.pci_bandwidth}",
							RTarget: ".98   GiB/s",
						},
						{
							Operand: "=",
							LTarget: "${device.attr.cores_clock}",
							RTarget: "800MHz",
						},
						{
							Operand: "set_contains",
							LTarget: "${device.ids}",
							RTarget: nvidia_A.Instances[0].ID,
						},
					},
				},
			},
		},
		{
			Name:        "meets constraints requirement multiple count",
			Result:      true,
			NodeDevices: []*structs.NodeDeviceResource{nvidia_A},
			RequestedDevices: []*structs.RequestedDevice{
				{
					Name:  "nvidia/gpu",
					Count: 2,
					Constraints: []*structs.Constraint{
						{
							Operand: "=",
							LTarget: "${device.model}",
							RTarget: "1080ti",
						},
						{
							Operand: ">",
							LTarget: "${device.attr.memory}",
							RTarget: "1320.5 MB",
						},
						{
							Operand: "<=",
							LTarget: "${device.attr.pci_bandwidth}",
							RTarget: ".98   GiB/s",
						},
						{
							Operand: "=",
							LTarget: "${device.attr.cores_clock}",
							RTarget: "800MHz",
						},
						{
							Operand: "set_contains",
							LTarget: "${device.ids}",
							RTarget: fmt.Sprintf("%s,%s", nvidia_A.Instances[1].ID, nvidia_A.Instances[0].ID),
						},
					},
				},
			},
		},
		{
			Name:        "meets constraints requirement over count",
			Result:      false,
			NodeDevices: []*structs.NodeDeviceResource{nvidia_A},
			RequestedDevices: []*structs.RequestedDevice{
				{
					Name:  "nvidia/gpu",
					Count: 5,
					Constraints: []*structs.Constraint{
						{
							Operand: "=",
							LTarget: "${device.model}",
							RTarget: "1080ti",
						},
						{
							Operand: ">",
							LTarget: "${device.attr.memory}",
							RTarget: "1320.5 MB",
						},
						{
							Operand: "<=",
							LTarget: "${device.attr.pci_bandwidth}",
							RTarget: ".98   GiB/s",
						},
						{
							Operand: "=",
							LTarget: "${device.attr.cores_clock}",
							RTarget: "800MHz",
						},
					},
				},
			},
		},
		{
			Name:        "does not meet first constraint",
			Result:      false,
			NodeDevices: []*structs.NodeDeviceResource{nvidia_A},
			RequestedDevices: []*structs.RequestedDevice{
				{
					Name:  "nvidia/gpu",
					Count: 1,
					Constraints: []*structs.Constraint{
						{
							Operand: "=",
							LTarget: "${device.model}",
							RTarget: "2080ti",
						},
						{
							Operand: ">",
							LTarget: "${device.attr.memory}",
							RTarget: "1320.5 MB",
						},
						{
							Operand: "<=",
							LTarget: "${device.attr.pci_bandwidth}",
							RTarget: ".98   GiB/s",
						},
						{
							Operand: "=",
							LTarget: "${device.attr.cores_clock}",
							RTarget: "800MHz",
						},
					},
				},
			},
		},
		{
			Name:        "does not meet second constraint",
			Result:      false,
			NodeDevices: []*structs.NodeDeviceResource{nvidia_A},
			RequestedDevices: []*structs.RequestedDevice{
				{
					Name:  "nvidia/gpu",
					Count: 1,
					Constraints: []*structs.Constraint{
						{
							Operand: "=",
							LTarget: "${device.model}",
							RTarget: "1080ti",
						},
						{
							Operand: "<",
							LTarget: "${device.attr.memory}",
							RTarget: "1320.5 MB",
						},
						{
							Operand: "<=",
							LTarget: "${device.attr.pci_bandwidth}",
							RTarget: ".98   GiB/s",
						},
						{
							Operand: "=",
							LTarget: "${device.attr.cores_clock}",
							RTarget: "800MHz",
						},
					},
				},
			},
		},
		{
			Name:        "does not meet ID constraint",
			Result:      false,
			NodeDevices: []*structs.NodeDeviceResource{nvidia_A},
			RequestedDevices: []*structs.RequestedDevice{
				{
					Name:  "nvidia/gpu",
					Count: 1,
					Constraints: []*structs.Constraint{
						{
							Operand: "set_contains",
							LTarget: "${device.ids}",
							RTarget: "not_valid",
						},
					},
				},
			},
		},
		{
			Name:        "different model GPU's meets device request",
			Result:      true,
			NodeDevices: []*structs.NodeDeviceResource{nvidia_A, nvidia_B},
			RequestedDevices: []*structs.RequestedDevice{
				{
					Name:  "nvidia/gpu",
					Count: 2,
				},
			},
		},
	}

	for _, c := range cases {
		t.Run(c.Name, func(t *testing.T) {
			_, ctx := MockContext(t)
			checker := NewDeviceChecker(ctx)
			checker.SetTaskGroup(getTg(c.RequestedDevices...))
			if act := checker.Feasible(getNode(c.NodeDevices...)); act != c.Result {
				t.Fatalf("got %v; want %v", act, c.Result)
			}
		})
	}
}

func TestCheckAttributeConstraint(t *testing.T) {
	ci.Parallel(t)

	type tcase struct {
		op         string
		lVal, rVal *psstructs.Attribute
		result     bool
	}
	cases := []tcase{
		{
			op:     "=",
			lVal:   psstructs.NewStringAttribute("foo"),
			rVal:   psstructs.NewStringAttribute("foo"),
			result: true,
		},
		{
			op:     "=",
			lVal:   nil,
			rVal:   nil,
			result: false,
		},
		{
			op:     "is",
			lVal:   psstructs.NewStringAttribute("foo"),
			rVal:   psstructs.NewStringAttribute("foo"),
			result: true,
		},
		{
			op:     "==",
			lVal:   psstructs.NewStringAttribute("foo"),
			rVal:   psstructs.NewStringAttribute("foo"),
			result: true,
		},
		{
			op:     "!=",
			lVal:   psstructs.NewStringAttribute("foo"),
			rVal:   psstructs.NewStringAttribute("foo"),
			result: false,
		},
		{
			op:     "!=",
			lVal:   nil,
			rVal:   psstructs.NewStringAttribute("foo"),
			result: true,
		},
		{
			op:     "!=",
			lVal:   psstructs.NewStringAttribute("foo"),
			rVal:   nil,
			result: true,
		},
		{
			op:     "!=",
			lVal:   psstructs.NewStringAttribute("foo"),
			rVal:   psstructs.NewStringAttribute("bar"),
			result: true,
		},
		{
			op:     "not",
			lVal:   psstructs.NewStringAttribute("foo"),
			rVal:   psstructs.NewStringAttribute("bar"),
			result: true,
		},
		{
			op:     structs.ConstraintVersion,
			lVal:   psstructs.NewStringAttribute("1.2.3"),
			rVal:   psstructs.NewStringAttribute("~> 1.0"),
			result: true,
		},
		{
			op:     structs.ConstraintRegex,
			lVal:   psstructs.NewStringAttribute("foobarbaz"),
			rVal:   psstructs.NewStringAttribute("[\\w]+"),
			result: true,
		},
		{
			op:     "<",
			lVal:   psstructs.NewStringAttribute("foo"),
			rVal:   psstructs.NewStringAttribute("bar"),
			result: false,
		},
		{
			op:     structs.ConstraintSetContains,
			lVal:   psstructs.NewStringAttribute("foo,bar,baz"),
			rVal:   psstructs.NewStringAttribute("foo,  bar  "),
			result: true,
		},
		{
			op:     structs.ConstraintSetContainsAll,
			lVal:   psstructs.NewStringAttribute("foo,bar,baz"),
			rVal:   psstructs.NewStringAttribute("foo,  bar  "),
			result: true,
		},
		{
			op:     structs.ConstraintSetContains,
			lVal:   psstructs.NewStringAttribute("foo,bar,baz"),
			rVal:   psstructs.NewStringAttribute("foo,bam"),
			result: false,
		},
		{
			op:     structs.ConstraintSetContainsAny,
			lVal:   psstructs.NewStringAttribute("foo,bar,baz"),
			rVal:   psstructs.NewStringAttribute("foo,bam"),
			result: true,
		},
		{
			op:     structs.ConstraintAttributeIsSet,
			lVal:   psstructs.NewStringAttribute("foo,bar,baz"),
			result: true,
		},
		{
			op:     structs.ConstraintAttributeIsSet,
			lVal:   nil,
			result: false,
		},
		{
			op:     structs.ConstraintAttributeIsNotSet,
			lVal:   psstructs.NewStringAttribute("foo,bar,baz"),
			result: false,
		},
		{
			op:     structs.ConstraintAttributeIsNotSet,
			lVal:   nil,
			result: true,
		},
	}

	for _, tc := range cases {
		_, ctx := MockContext(t)
		if res := checkAttributeConstraint(ctx, tc.op, tc.lVal, tc.rVal, tc.lVal != nil, tc.rVal != nil); res != tc.result {
			t.Fatalf("TC: %#v, Result: %v", tc, res)
		}
	}
}

func TestHostVolume_ProposedAllocMeetsClaim(t *testing.T) {
	ci.Parallel(t)

	allocID := uuid.Generate()
	volID0, volID1 := uuid.Generate(), uuid.Generate()
	nodeID0, nodeID1 := uuid.Generate(), uuid.Generate()

	makeAlloc := func(id, job, tg, desiredStatus, clientStatus string) *structs.Allocation {
		alloc := &structs.Allocation{
			Namespace:     structs.DefaultNamespace,
			ID:            id,
			JobID:         job,
			TaskGroup:     tg,
			DesiredStatus: desiredStatus,
			ClientStatus:  clientStatus,
			NodeID:        nodeID0,
		}
		return alloc
	}

	makeClaim := func(allocID, volID string) *structs.TaskGroupHostVolumeClaim {
		return &structs.TaskGroupHostVolumeClaim{
			ID:            uuid.Generate(),
			AllocID:       allocID,
			VolumeID:      volID,
			Namespace:     structs.DefaultNamespace,
			JobID:         "job0",
			TaskGroupName: "tg0",
			VolumeName:    "database",
		}
	}

	vol0 := &structs.HostVolume{Namespace: structs.DefaultNamespace, ID: volID0, NodeID: nodeID0}
	vol1 := &structs.HostVolume{Namespace: structs.DefaultNamespace, ID: volID1, NodeID: nodeID1}

	testCases := []struct {
		name     string
		proposed *structs.Allocation
		claim    *structs.TaskGroupHostVolumeClaim
		vol      *structs.HostVolume
		nodeID   string
		expect   bool
	}{
		{
			name: "terminal alloc fails claim",
			proposed: makeAlloc(allocID, "job0", "tg0",
				structs.AllocDesiredStatusStop, structs.AllocClientStatusComplete),
			claim:  makeClaim(allocID, volID0),
			vol:    vol0,
			nodeID: nodeID0,
			expect: false,
		},
		{
			name: "exact alloc ID matches claim",
			proposed: makeAlloc(allocID, "job0", "tg0",
				structs.AllocDesiredStatusRun, structs.AllocClientStatusRunning),
			claim:  makeClaim(allocID, volID0),
			vol:    vol0,
			nodeID: nodeID0,
			expect: true,
		},
		{
			name: "different alloc for task group matches claim",
			proposed: makeAlloc("different-alloc", "job0", "tg0",
				structs.AllocDesiredStatusRun, structs.AllocClientStatusRunning),
			claim:  makeClaim(allocID, volID0),
			vol:    vol0,
			nodeID: nodeID0,
			expect: true,
		},
		{
			name: "job mismatch fails claim",
			proposed: makeAlloc("different-alloc", "job1", "tg0",
				structs.AllocDesiredStatusRun, structs.AllocClientStatusRunning),
			claim:  makeClaim(allocID, volID0),
			vol:    vol0,
			nodeID: nodeID0,
			expect: false,
		},
		{
			name: "volume mismatch fails claim",
			proposed: makeAlloc("different-alloc", "job0", "tg0",
				structs.AllocDesiredStatusRun, structs.AllocClientStatusRunning),
			claim:  makeClaim(allocID, volID0),
			vol:    vol1,
			nodeID: nodeID1,
			expect: false,
		},
		{
			name: "node-volume mismatch fails claim",
			proposed: makeAlloc("different-alloc", "job0", "tg0",
				structs.AllocDesiredStatusRun, structs.AllocClientStatusRunning),
			claim:  makeClaim(allocID, volID0),
			vol:    vol0,
			nodeID: nodeID1, // note: should be impossible
			expect: false,
		},
		{
			name: "pending alloc with exact ID match returns true",
			proposed: makeAlloc(allocID, "job0", "tg0",
				structs.AllocDesiredStatusRun, structs.AllocClientStatusPending),
			claim:  makeClaim(allocID, volID0),
			vol:    vol0,
			nodeID: nodeID0,
			expect: true,
		},
		{
			name: "running alloc with all conditions matched returns true",
			proposed: makeAlloc("new-alloc", "job0", "tg0",
				structs.AllocDesiredStatusRun, structs.AllocClientStatusRunning),
			claim:  makeClaim("old-alloc", volID0),
			vol:    vol0,
			nodeID: nodeID0,
			expect: true,
		},
	}

	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			result := proposedAllocMeetsClaim(tc.proposed, tc.claim, tc.vol, tc.nodeID)
			must.Eq(t, tc.expect, result)
		})
	}
}
