// Copyright IBM Corp. 2015, 2026
// SPDX-License-Identifier: BUSL-1.1

// Package allocwatcher allows blocking until another allocation - whether
// running locally or remotely - completes and migrates the allocation
// directory if necessary.
package allocwatcher
