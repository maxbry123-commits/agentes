..
   Licensed to the Apache Software Foundation (ASF) under one
   or more contributor license agreements.  See the NOTICE file
   distributed with this work for additional information
   regarding copyright ownership.  The ASF licenses this file
   to you under the Apache License, Version 2.0 (the
   "License"); you may not use this file except in compliance
   with the License.  You may obtain a copy of the License at

     http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing,
   software distributed under the License is distributed on an
   "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
   KIND, either express or implied.  See the License for the
   specific language governing permissions and limitations
   under the License.


==============
Apache Burr
==============

Welcome to Apache Burr (Incubating)'s documentation.

For a quick overview of Apache Burr, watch `this walkthrough <https://www.loom.com/share/a10f163428b942fea55db1a84b1140d8?sid=1512863b-f533-4a42-a2f3-95b13deb07c9>`_
or read `our blog post <https://blog.dagworks.io/p/burr-develop-stateful-ai-applications?r=2cg5z1&utm_campaign=post&utm_medium=web>`_. The following video is
a longer demo of building a simple chatbot application with Apache Burr using `this notebook <https://github.com/apache/burr/blob/main/examples/conversational-rag/simple_example/notebook.ipynb>`_:

.. image:: _static/burr_video_thumbnail.jpg
   :target: https://www.youtube.com/watch?v=rEZ4oDN0GdU
   :alt: Apache Burr Demo Video
   :align: center
   :width: 600px

For more details about how Apache Burr works, what problems it solves, and how to use it, read on!

You'll find this documentation separated into three sections.

- If you don't know where to start, go to :ref:`getting started <gettingstarted>`.
- If you're looking to build a mental model/read more, go to :ref:`concepts <concepts>`.
- If you're looking for a specific piece of information, go to :ref:`reference <reference>`.

We also ask that you:

- Report any bugs, issues, or feature requests via `GitHub Issues <https://github.com/apache/burr/issues>`_ or \
  `GitHub Discussions <https://github.com/apache/burr/discussions>`_.
- Give us a star on `GitHub <https://github.com/apache/burr>`_ if you like the project!


Testimonials
============

.. raw:: html

    <link rel="stylesheet" type="text/css" href="_static/testimonials.css">
       <div class="testimonial-container">
               <div class="testimonial-card">
            <div class="testimonial-content">
                <p>"After evaluating several other obfuscating LLM frame-works, their elegant yet comprehensive state management solution proved to be the powerful answer to rolling out robots driven by AI decision making."</p>
                <h4>Ashish Ghosh</h4>
                <span>CTO, Peanut Robotics</span>
            </div>
        </div>

        <div class="testimonial-card">
            <div class="testimonial-content">
                <p>"Of course, you can use it [LangChain], but whether it's really production-ready and improves the time from 'code-to-prod' [...], we've been doing LLM apps for two years, and the answer is no [...] All these 'all-in-one' libs suffer from this [...].  Honestly, take a look at Burr. Thank me later."</p>
                <h4>Reddit User</h4>
                <span>LocalLlama, Subreddit</span>
            </div>
        </div>

        <div class="testimonial-card">
            <div class="testimonial-content">
                <p>"Using Burr is a no-brainer if you want to build a modular AI application. It is so easy to build with and I especially love their UI which makes debugging, a piece of cake. And the always ready to help team, is the cherry on top."</p>
                <h4>Ishita</h4>
                <span>Founder, Watto.ai</span>
            </div>
        </div>

        <div class="testimonial-card">
            <div class="testimonial-content">
                <p>"I just came across Burr and I'm like WOW, this seems like you guys predicted this exact need when building this. No weird esoteric concepts just because it's AI."</p>
                <h4>Matthew Rideout</h4>
                <span>Staff Software Engineer, Paxton AI</span>
            </div>
        </div>

        <div class="testimonial-card">
            <div class="testimonial-content">
                <p>"Burr's state management part is really helpful for creating state snapshots and build debugging, replaying and even building evaluation cases around that"</p>
                <h4>Rinat Gareev</h4>
                <span>Senior Solutions Architect, Provectus</span>
            </div>
        </div>

        <div class="testimonial-card">
            <div class="testimonial-content">
                <p>"I have been using Burr over the past few months, and compared to many agentic LLM platforms out there (e.g. LangChain, CrewAi, AutoGen, Agency Swarm, etc), Burr provides a more robust framework for designing complex behaviors."</p>
                <h4>Hadi Nayebi</h4>
                <span>Co-founder, CognitiveGraphs</span>
            </div>
        </div>

        <div class="testimonial-card">
            <div class="testimonial-content">
                <p>"Moving from LangChain to Burr was a game-changer! <br/>Time-Saving: It took me just a few hours to get started with Burr, compared to the days and weeks I spent trying to navigate LangChain. <br/>Cleaner Implementation: With Burr, I could finally have a cleaner, more sophisticated, and stable implementation. No more wrestling with complex codebases. <br/>Team Adoption: I pitched Burr to my teammates, and we pivoted our entire codebase to it. It's been a smooth ride ever since."</p>
                <h4>Aditya K.</h4>
                <span>DS Architect, TaskHuman</span>
            </div>
        </div>
    </div>
