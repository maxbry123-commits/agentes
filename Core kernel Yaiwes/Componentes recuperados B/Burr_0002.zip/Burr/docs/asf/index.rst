..
   Licensed to the Apache Software Foundation (ASF) under one
   or more contributor license agreements.  See the NOTICE file
   distributed with this work for additional information
   regarding copyright ownership.  The ASF licenses this file
   to you under the Apache License, Version 2.0 (the
   "License"); you may not use this file except in compliance
   with the License.  You may obtain a copy of the License at

     http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing,
   software distributed under the License is distributed on an
   "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
   KIND, either express or implied.  See the License for the
   specific language governing permissions and limitations
   under the License.


================
ASF
================

Apache Software Foundation links.

.. toctree::
   :maxdepth: 1
   :caption: ASF Links
   :glob:
   :hidden:

   Apache Software Foundation <https://www.apache.org/>
   License <https://www.apache.org/licenses/>
   Events <https://www.apache.org/events/current-event.html>
   Privacy <https://privacy.apache.org/policies/privacy-policy-public.html>
   Security <https://www.apache.org/security/>
   Sponsorship <https://www.apache.org/foundation/sponsorship.html>
   Thanks <https://www.apache.org/foundation/thanks.html>
   Code of Conduct <https://www.apache.org/foundation/policies/conduct.html>

- `Foundation <https://www.apache.org/>`_
- `License <https://www.apache.org/licenses/>`_
- `Events <https://www.apache.org/events/current-event.html>`_
- `Privacy <https://privacy.apache.org/policies/privacy-policy-public.html>`_
- `Security <https://www.apache.org/security/>`_
- `Sponsorship <https://www.apache.org/foundation/sponsorship.html>`_
- `Thanks <https://www.apache.org/foundation/thanks.html>`_
- `Code of Conduct <https://www.apache.org/foundation/policies/conduct.html>`_
