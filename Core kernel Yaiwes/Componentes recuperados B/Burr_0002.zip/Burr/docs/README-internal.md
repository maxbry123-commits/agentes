<!--
     Licensed to the Apache Software Foundation (ASF) under one
     or more contributor license agreements.  See the NOTICE file
     distributed with this work for additional information
     regarding copyright ownership.  The ASF licenses this file
     to you under the Apache License, Version 2.0 (the
     "License"); you may not use this file except in compliance
     with the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

     Unless required by applicable law or agreed to in writing,
     software distributed under the License is distributed on an
     "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
     KIND, either express or implied.  See the License for the
     specific language governing permissions and limitations
     under the License.
-->

# Internal README for docs

This documentation aims to follow the [diataxis](diataxis.fr) approach to documentation. This outlines:

1. Tutorials [getting_started](./getting_started)
2. How-to guides (examples in the repo)
3. References [reference](./reference)
4. Explanation [concepts](./concepts)

TODO:

- [ ] fill in all docs todos
- [ ] Add examples for Hamilton integration, streamlit integration
