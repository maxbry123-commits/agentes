---
weight: 300
title: Long-term support releases
description: "Long-term support release lines for enterprise customers."
menu:
  docs:
    parent: 'victoriametrics'
    weight: 300
tags:
  - metrics
  - enterprise
aliases:
- /LTS-releases.html
- /lts-releases/index.html
- /lts-releases/
---
[Enterprise version of VictoriaMetrics](https://docs.victoriametrics.com/victoriametrics/enterprise/) provides long-term support lines of releases (aka LTS releases).
Every LTS line receives bugfixes and [security fixes](https://github.com/VictoriaMetrics/VictoriaMetrics/blob/master/SECURITY.md) for 12 months after
the initial release. New LTS lines are published every 6 months, so the latest two LTS lines are supported at any given moment. This gives up to 6 months
for the migration to new LTS lines for [VictoriaMetrics Enterprise](https://docs.victoriametrics.com/victoriametrics/enterprise/) users.

LTS releases are published for [Enterprise versions of VictoriaMetrics](https://docs.victoriametrics.com/victoriametrics/enterprise/) only.
When a new LTS line is created, the new LTS release might be publicly available for everyone until the new major OS release will be published.

All the bugfixes and security fixes, which are included in LTS releases, are also available in [the latest release](https://github.com/VictoriaMetrics/VictoriaMetrics/releases/latest),
so non-enterprise users are advised to regularly [upgrade](https://docs.victoriametrics.com/victoriametrics/single-server-victoriametrics/#how-to-upgrade-victoriametrics) VictoriaMetrics products
to [the latest available releases](https://docs.victoriametrics.com/victoriametrics/changelog/).

## Currently supported LTS release lines

- v1.148.x - the latest one is [v1.148.3 LTS release](https://github.com/VictoriaMetrics/VictoriaMetrics/releases/tag/v1.148.3)
- v1.136.x - the latest one is [v1.136.17 LTS release](https://github.com/VictoriaMetrics/VictoriaMetrics/releases/tag/v1.136.17)
