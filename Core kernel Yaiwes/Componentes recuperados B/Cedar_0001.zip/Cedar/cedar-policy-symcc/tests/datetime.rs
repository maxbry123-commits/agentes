/*
 * Copyright Cedar Contributors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
use cedar_policy::{Schema, Validator};
use cedar_policy_symcc::{solver::LocalSolver, CedarSymCompiler};

use crate::utils::{
    assert_does_not_always_allow, assert_does_not_imply, assert_implies, Environments,
};
mod utils;

fn sample_schema() -> Schema {
    utils::schema_from_cedarstr(
        r#"
        entity User;
        entity Thing;
        action View appliesTo {
          principal: [User],
          resource: [Thing],
          context: {
            x: datetime,
            y: datetime,
            d1: duration,
            d2: duration,
          }
        };
    "#,
    )
}

fn env_for_sample_schema<'a>(schema: &'a Schema) -> Environments<'a> {
    Environments::new(schema, "User", "Action::\"View\"", "Thing")
}

#[tokio::test]
async fn x_max_offset() {
    let validator = Validator::new(sample_schema());
    let pset1 = utils::pset_from_text(
        r#"permit(principal, action, resource) when {
            context.x >= datetime("1970-01-01") &&
            context.x.offset(duration("9223372036854775807ms")) == context.x.offset(duration("9223372036854775807ms"))};
        "#,
        &validator,
    );
    let pset2 = utils::pset_from_text(
        r#"permit(principal, action, resource) when {context.x == datetime("1970-01-01")};"#,
        &validator,
    );
    let pset3 = utils::pset_from_text(
        r#"permit(principal, action, resource) when {context.x != datetime("1970-01-01")};"#,
        &validator,
    );
    let mut compiler = CedarSymCompiler::new(LocalSolver::cvc5().unwrap()).unwrap();
    let schema = sample_schema();
    let envs = env_for_sample_schema(&schema);
    assert_implies(&mut compiler, &pset1, &pset2, &envs).await;
    assert_does_not_imply(&mut compiler, &pset1, &pset3, &envs).await;
}

#[tokio::test]
async fn x_min_offset() {
    let validator = Validator::new(sample_schema());
    let pset1 = utils::pset_from_text(
        r#"permit(principal, action, resource) when {
            context.x <= datetime("1970-01-01") &&
            context.x.offset(duration("-9223372036854775808ms")) == context.x.offset(duration("-9223372036854775808ms"))};
        "#,
        &validator,
    );
    let pset2 = utils::pset_from_text(
        r#"permit(principal, action, resource) when {context.x == datetime("1970-01-01")};"#,
        &validator,
    );
    let pset3 = utils::pset_from_text(
        r#"permit(principal, action, resource) when {context.x != datetime("1970-01-01")};"#,
        &validator,
    );
    let mut compiler = CedarSymCompiler::new(LocalSolver::cvc5().unwrap()).unwrap();
    let schema = sample_schema();
    let envs = env_for_sample_schema(&schema);
    assert_implies(&mut compiler, &pset1, &pset2, &envs).await;
    assert_does_not_imply(&mut compiler, &pset1, &pset3, &envs).await;
}

/// Test reproducing PBT symcc failure for counter-example validation. The issue was
/// Term interpretation was missing a case for `bvsrem`.
#[tokio::test]
async fn pbt_cex_failure() {
    let schema = utils::schema_from_cedarstr(
        r#"
        entity a = {
                A: __cedar::datetime
                };
        action "action" appliesTo {
                principal: [a],
                resource: [a],
                context: {}
                };
    "#,
    );
    let validator = Validator::new(schema);
    let pset1 = utils::pset_from_text(
        r#"
        permit(
          principal == a::"",
          action in [Action::"action"],
          resource == a::""
        ) when {
          resource.A.toDate() == datetime("4224-11-03").toDate() && false
        };

    "#,
        &validator,
    );

    let pset2 = utils::pset_from_text(
        r#"
        permit(
          principal == a::"",
          action in [Action::"action"],
          resource == a::""
        ) when {
          resource.A.toTime() == datetime("4224-11-03").toTime() && false
        };

    "#,
        &validator,
    );

    let mut compiler = CedarSymCompiler::new(LocalSolver::cvc5().unwrap()).unwrap();
    let envs = Environments::new(validator.schema(), "a", "Action::\"action\"", "a");

    // The policies never allow anything.
    assert_does_not_always_allow(&mut compiler, &pset1, &envs).await;
    assert_does_not_always_allow(&mut compiler, &pset2, &envs).await;
}

/// Exercise decoding models with `datetime` type annotation, forced by requiring a counterexample with an empty set.
#[tokio::test]
async fn decode_datetime_type() {
    let schema = utils::schema_from_cedarstr( "entity E; action A appliesTo { principal: [E], resource: [E], context: {x: Set<datetime>} };");
    let validator = Validator::new(schema);
    let pset1 = utils::pset_from_text(
        "permit(principal, action, resource) when { !context.x.isEmpty() };",
        &validator,
    );

    let mut compiler = CedarSymCompiler::new(LocalSolver::cvc5().unwrap()).unwrap();
    let envs = Environments::new(validator.schema(), "E", r#"Action::"A""#, "E");

    assert_does_not_always_allow(&mut compiler, &pset1, &envs).await;
}

/// Exercise decoding models with `duration` type annotation, forced by requiring a counterexample with an empty set.
#[tokio::test]
async fn decode_duration_type() {
    let schema = utils::schema_from_cedarstr( "entity E; action A appliesTo { principal: [E], resource: [E], context: {x: Set<duration>} };");
    let validator = Validator::new(schema);
    let pset1 = utils::pset_from_text(
        "permit(principal, action, resource) when { !context.x.isEmpty() };",
        &validator,
    );

    let mut compiler = CedarSymCompiler::new(LocalSolver::cvc5().unwrap()).unwrap();
    let envs = Environments::new(validator.schema(), "E", r#"Action::"A""#, "E");

    assert_does_not_always_allow(&mut compiler, &pset1, &envs).await;
}
