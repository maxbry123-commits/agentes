# Changelog

All notable changes to crate `cedar-policy-symcc` will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

Cedar Language Version: TBD

## [0.6.0] - 2026-07-28

Cedar Language Version: 4.5

### Added

- `CompiledSchema` type that precomputes symbolic entities once per schema and produces
  `SymEnv` instances via `sym_env()`, avoiding expensive per-environment rebuilds.

### Fixed

- Fix errors decoding models from Z3. The model decoder now accepts hexadecimal bitvectors
  in solver output (e.g., `#xff`). It also handles an option literal `none`
  without an explicit type annotation, as long as it can infer the type. Finally, it accepts
  models for UUFs with equality operands in either order.
- Fix errors decoding models for entities with `Bool` typed tags.

## [0.5.3] - 2026-06-09
Cedar Language Version: 4.5

## [0.5.2] - 2026-06-09
Cedar Language Version: 4.5

## [0.5.1] - 2026-06-01
Cedar Language Version: 4.5

### Fixed

- Model decoder now skips unknown `define-fun` entries in solver output, improving compatibility with Z3 and other solvers that include intermediate terms in `(get-model)` responses.

## [0.5.0] - 2026-05-18
Cedar Language Version: 4.5

## [0.4.0] - 2026-04-23
Cedar Language Version: 4.5

### Changed

- Refactored `Solver` trait to include `check_sat_with_model()` instead of `get_model()`,
to make the API easier to use with fewer implicit ordering constraints (#2190)
- Added `enable_models()` as a required method for the `Solver` trait, to allow
some implementors of `Solver` to perform other initialization/configuration as
required when models are being enabled (#2192)
- Performance optimization for analysis of policies containing `.toDate()` (#2234)

## [0.3.2] - 2026-04-06
Cedar Language Version: 4.4

### Fixed

- Return an error when attempting to create a `CompiledPolicySet` from a policy
 set containing template-linked policies instead of silently dropping them. (#2276)

## [0.3.1] - 2026-03-09
Cedar Language Version: 4.4

### Added

- `Display` impl for `Env` (#2182)

### Fixed

- Fixed bug in `Term::interpret` caused by missing `bvsrem` case (#2185, #2203)

## [0.3.0] - 2026-02-17
Cedar Language Version: 4.4

### Added

- `matches_equivalent`, `matches_implies`, and `matches_disjoint` primitives
for single policies (#2047)
- `.effect()` for `CompiledPolicy` (#2047)
- `CompiledPolicy::compile_with_custom_symenv()` and
`CompiledPolicySet::compile_with_custom_symenv()` experimental APIs -- note the
documented caveats and use at your own risk (#2102)
- `Display` impl for `Term` (#2125)
- Performance optimizations (#2070, #2073, #2079, #2093, #2094)
- Add `SolverPool` for query pooling (#2111)

### Changed

- Renamed `CompiledPolicies` to `CompiledPolicySet`
- Deprecated the unoptimized interface on `CedarSymCompiler` in favor of the
optimized interface (`*_opt` methods) introduced in 0.2.0 (#2095)
- Also deprecated the `WellTypedPolicy` and `WellTypedPolicies` types associated
with the unoptimized `CedarSymCompiler` interface (#2129)
- Experimental functions `compile_always_matches()` and friends were refactored
and renamed to `always_matches_asserts()` and friends. Under the hood, these now
use the performance-optimized primitives introduced in 0.2.0. (#2102)
- Changed the declaration order of variants for `Term`, `TermPrim`, and `TermType` (#2139).

### Fixed

- Bug where returned counterexamples could occasionally be invalid by containing
cycles in the entity data for entities irrelevant to the given policies (#2089)

### Removed

- Experimental `WellFormedAsserts::from_asserts_unchecked()` API. But note the
addition of `CedarSymCompiler::check_unsat_raw()` as an experimental API. (#2102)

## [0.2.1] - 2026-04-06
Cedar Language Version: 4.4

### Fixed

- Return an error when attempting to create a `CompiledPolicySet` from a policy
 set containing template-linked policies instead of silently dropping them. (#2277)

## [0.2.0] - 2025-12-12
Cedar Language Version: 4.4

### Added

- New optimized interface (`*_opt` methods on `CedarSymCompiler`) allowing you
to precompile policies (see `CompiledPolicy` and `CompiledPolicies`) and reuse
them across many queries. (#2013, #2019)
- `always_matches` and `never_matches` primitives for single policies (#2014)
- Performance optimizations (#1947, #1970, #2017, #2020, #2021)

## [0.1.4] - 2026-04-06
Cedar Language Version: 4.4

### Fixed

- Return an error when attempting to create a `CompiledPolicySet` from a policy
 set containing template-linked policies instead of silently dropping them. (#2278)

## [0.1.3] - 2025-12-12
Cedar Language Version: 4.4

### Fixed
- Ensured that this crate depends on compatible versions of `cedar-policy` and
`cedar-policy-core` (#1954)

## [0.1.2] - 2025-11-26
Cedar Language Version: 4.4

### Fixed
- Fixed parsing of small negative decimal literals. (#1964)

## [0.1.1] - 2025-11-20
Cedar Language Version: 4.4

### Changed

- Lock `cedar-policy-core` version to 4.7.0

## [0.1.0] - 2025-11-10
Cedar Language Version: 4.4

- Initial release
