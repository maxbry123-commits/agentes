import os
import socket
import threading
from collections.abc import AsyncIterable, Iterator
from contextlib import contextmanager

import pytest
from posthog.test.base import BaseTest
from unittest.mock import MagicMock, call, patch

import pyarrow as pa
from clickhouse_connect.driver.exceptions import ClickHouseError, OperationalError, ProgrammingError
from parameterized import parameterized

from products.warehouse_sources.backend.models.external_data_schema import ExternalDataSchema
from products.warehouse_sources.backend.models.external_data_source import ExternalDataSource
from products.warehouse_sources.backend.temporal.data_imports.sources.clickhouse import clickhouse as ch_module
from products.warehouse_sources.backend.temporal.data_imports.sources.clickhouse.clickhouse import (
    _MAX_CONNECT_ATTEMPTS,
    NOT_A_CLICKHOUSE_HTTP_RESPONSE,
    YIELD_TARGET_ROWS,
    ClickHouseColumn,
    ClickHouseConnectionError,
    _build_query,
    _get_client,
    _get_incremental_row_count,
    _get_partition_settings,
    _has_duplicate_primary_keys,
    _is_rate_limited,
    _is_too_many_queries,
    _is_transient_connect_drop,
    _parse_mv_target,
    _project_columns,
    _quote_identifier,
    _strip_type_modifiers,
    filter_clickhouse_incremental_fields,
    get_primary_keys_for_schemas,
)
from products.warehouse_sources.backend.temporal.data_imports.sources.clickhouse.source import (
    _REDIRECTED,
    _TEMPORARILY_UNAVAILABLE,
    GENERIC_CONNECTION_ERROR,
    ClickHouseSource,
)
from products.warehouse_sources.backend.temporal.data_imports.sources.common.schema import SourceSchema
from products.warehouse_sources.backend.temporal.data_imports.sources.common.sql.predicates import (
    ColumnTypeCategory,
    ValidatedRowFilter,
)
from products.warehouse_sources.backend.types import ExternalDataSourceType, IncrementalFieldType


class TestQuoteIdentifier:
    @pytest.mark.parametrize(
        "name,expected",
        [
            ("users", "`users`"),
            ("user_id", "`user_id`"),
            ("CamelCase", "`CamelCase`"),
            ("with space", "`with space`"),
            ("with`backtick", "`with``backtick`"),
            ("123starts_with_digit", "`123starts_with_digit`"),
        ],
    )
    def test_quotes_and_escapes(self, name, expected):
        assert _quote_identifier(name) == expected

    def test_rejects_null_byte(self):
        with pytest.raises(ValueError, match="null byte"):
            _quote_identifier("bad\x00name")


class TestStripTypeModifiers:
    @pytest.mark.parametrize(
        "raw,expected_inner,expected_nullable",
        [
            ("Int64", "Int64", False),
            ("Nullable(Int64)", "Int64", True),
            ("LowCardinality(String)", "String", False),
            ("Nullable(LowCardinality(String))", "String", True),
            ("LowCardinality(Nullable(String))", "String", True),
            ("Nullable(DateTime64(6, 'UTC'))", "DateTime64(6, 'UTC')", True),
            ("Decimal(18, 4)", "Decimal(18, 4)", False),
            ("  Nullable(Int32)  ", "Int32", True),
        ],
    )
    def test_strips(self, raw, expected_inner, expected_nullable):
        inner, nullable = _strip_type_modifiers(raw)
        assert inner == expected_inner
        assert nullable is expected_nullable


class TestFilterClickHouseIncrementalFields:
    @pytest.mark.parametrize(
        "type_name,expected_type",
        [
            ("Int8", IncrementalFieldType.Integer),
            ("Int16", IncrementalFieldType.Integer),
            ("Int32", IncrementalFieldType.Integer),
            ("Int64", IncrementalFieldType.Integer),
            ("Int128", IncrementalFieldType.Integer),
            ("Int256", IncrementalFieldType.Integer),
            ("UInt8", IncrementalFieldType.Integer),
            ("UInt16", IncrementalFieldType.Integer),
            ("UInt32", IncrementalFieldType.Integer),
            ("UInt64", IncrementalFieldType.Integer),
            ("Date", IncrementalFieldType.Date),
            ("Date32", IncrementalFieldType.Date),
            ("DateTime", IncrementalFieldType.Timestamp),
            ("DateTime('UTC')", IncrementalFieldType.Timestamp),
            ("DateTime64(3)", IncrementalFieldType.Timestamp),
            ("DateTime64(6, 'UTC')", IncrementalFieldType.Timestamp),
            ("Nullable(Int64)", IncrementalFieldType.Integer),
            ("Nullable(DateTime)", IncrementalFieldType.Timestamp),
            ("LowCardinality(Int32)", IncrementalFieldType.Integer),
        ],
    )
    def test_supported_types(self, type_name, expected_type):
        result = filter_clickhouse_incremental_fields([("col", type_name, False)])
        assert result == [("col", expected_type, False)]

    @pytest.mark.parametrize(
        "type_name",
        [
            "String",
            "FixedString(8)",
            "Float32",
            "Float64",
            "Decimal(18, 4)",
            "UUID",
            "Bool",
            "Array(Int64)",
            "Map(String, Int64)",
            "Tuple(Int64, String)",
            "Enum8('a' = 1, 'b' = 2)",
            "IPv4",
            "JSON",
        ],
    )
    def test_unsupported_types_excluded(self, type_name):
        result = filter_clickhouse_incremental_fields([("col", type_name, False)])
        assert result == []

    def test_preserves_nullable_flag(self):
        result = filter_clickhouse_incremental_fields([("col", "Nullable(Int64)", True)])
        assert result == [("col", IncrementalFieldType.Integer, True)]

    def test_multiple_columns(self):
        columns = [
            ("id", "UInt64", False),
            ("name", "String", False),
            ("created_at", "DateTime64(6, 'UTC')", True),
            ("amount", "Decimal(18, 4)", False),
            ("event_date", "Date", False),
        ]
        result = filter_clickhouse_incremental_fields(columns)
        assert result == [
            ("id", IncrementalFieldType.Integer, False),
            ("created_at", IncrementalFieldType.Timestamp, True),
            ("event_date", IncrementalFieldType.Date, False),
        ]


class TestBuildQuery:
    @staticmethod
    def _cols(*specs: tuple[str, str]) -> list[ClickHouseColumn]:
        return [ClickHouseColumn(name=n, data_type=t, nullable=False) for n, t in specs]

    @staticmethod
    def _filter(column: str, operator: str, value: object, category: ColumnTypeCategory) -> ValidatedRowFilter:
        return ValidatedRowFilter(column=column, operator=operator, value=value, category=category)

    def test_full_refresh(self):
        query, params = _build_query(
            database="default",
            table_name="events",
            columns=self._cols(("id", "Int64"), ("name", "String")),
            should_use_incremental_field=False,
            incremental_field=None,
        )
        assert query == "SELECT `id`, `name` FROM `default`.`events`"
        assert params == {}

    def test_incremental(self):
        query, params = _build_query(
            database="default",
            table_name="events",
            columns=self._cols(("id", "Int64"), ("created_at", "DateTime64(6)")),
            should_use_incremental_field=True,
            incremental_field="created_at",
        )
        assert "SELECT `id`, `created_at` FROM `default`.`events`" in query
        assert "WHERE `created_at` > %(last_value)s" in query
        assert "ORDER BY `created_at` ASC" in query
        assert params == {}

    def test_incremental_casts_date_last_value_through_todate32(self):
        # A `Date` cursor can come back from storage as a raw day-count integer
        # (ClickHouse's own on-disk representation), which `greater(Date, UInt16)`
        # rejects when bound directly. toDate32 accepts both an integer day-count
        # and a date string, so the comparison always type-checks.
        query, _ = _build_query(
            database="default",
            table_name="events",
            columns=self._cols(("id", "Int64"), ("day", "Date")),
            should_use_incremental_field=True,
            incremental_field="day",
            incremental_field_type=IncrementalFieldType.Date,
        )
        assert "WHERE `day` > toDate32(%(last_value)s)" in query

    def test_incremental_quotes_field_with_special_chars(self):
        query, _ = _build_query(
            database="my-db",
            table_name="weird table",
            columns=self._cols(("event time", "DateTime")),
            should_use_incremental_field=True,
            incremental_field="event time",
        )
        assert "`my-db`.`weird table`" in query
        assert "`event time`" in query

    def test_incremental_raises_without_field(self):
        with pytest.raises(ValueError, match="incremental_field can't be None"):
            _build_query(
                database="default",
                table_name="events",
                columns=self._cols(("id", "Int64")),
                should_use_incremental_field=True,
                incremental_field=None,
            )

    def test_wraps_arrow_unsupported_types_in_to_string(self):
        query, _ = _build_query(
            database="default",
            table_name="events",
            columns=[
                ClickHouseColumn(name="id", data_type="Int64", nullable=False),
                ClickHouseColumn(name="user_id", data_type="UUID", nullable=False),
                ClickHouseColumn(name="ip", data_type="Nullable(IPv4)", nullable=True),
                ClickHouseColumn(name="tags", data_type="Array(String)", nullable=False),
                ClickHouseColumn(name="status", data_type="LowCardinality(Enum8('a' = 1))", nullable=False),
            ],
            should_use_incremental_field=False,
            incremental_field=None,
        )
        assert "`id`" in query
        assert "toString(`user_id`) AS `user_id`" in query
        assert "toString(`ip`) AS `ip`" in query
        assert "toString(`tags`) AS `tags`" in query
        assert "toString(`status`) AS `status`" in query

    def test_full_refresh_with_row_filters_binds_values_as_params(self):
        query, params = _build_query(
            database="default",
            table_name="events",
            columns=self._cols(("id", "Int64"), ("name", "String")),
            should_use_incremental_field=False,
            incremental_field=None,
            row_filters=[
                self._filter("id", ">", 21, ColumnTypeCategory.INTEGER),
                self._filter("name", "=", "x'; DROP TABLE y; --", ColumnTypeCategory.STRING),
            ],
        )
        assert query == (
            "SELECT `id`, `name` FROM `default`.`events` WHERE `id` > %(row_filter_0)s AND `name` = %(row_filter_1)s"
        )
        assert params == {"row_filter_0": 21, "row_filter_1": "x'; DROP TABLE y; --"}
        # The value binds as a param, so the injection payload never reaches the SQL string.
        assert "DROP TABLE" not in query

    def test_incremental_ands_row_filters_after_cursor(self):
        query, params = _build_query(
            database="default",
            table_name="events",
            columns=self._cols(("id", "Int64"), ("created_at", "DateTime64(6)")),
            should_use_incremental_field=True,
            incremental_field="created_at",
            row_filters=[self._filter("id", ">=", 100, ColumnTypeCategory.INTEGER)],
        )
        assert "WHERE `created_at` > %(last_value)s AND `id` >= %(row_filter_0)s" in query
        assert "ORDER BY `created_at` ASC" in query
        assert params == {"row_filter_0": 100}

    def test_row_filter_in_operator_expands_to_placeholders(self):
        query, params = _build_query(
            database="default",
            table_name="events",
            columns=self._cols(("country", "String")),
            should_use_incremental_field=False,
            incremental_field=None,
            row_filters=[self._filter("country", "IN", ["US", "CA"], ColumnTypeCategory.STRING)],
        )
        assert "WHERE `country` IN (%(row_filter_0_0)s, %(row_filter_0_1)s)" in query
        assert params == {"row_filter_0_0": "US", "row_filter_0_1": "CA"}


class TestProjectColumns:
    @staticmethod
    def _cols(*names: str) -> list[ClickHouseColumn]:
        return [ClickHouseColumn(name=n, data_type="String", nullable=False) for n in names]

    @staticmethod
    def _names(cols: list[ClickHouseColumn]) -> list[str]:
        return [c.name for c in cols]

    def test_none_enabled_returns_all_columns(self):
        cols = self._cols("a", "b", "c")
        assert _project_columns(cols, None, ["a"], "b") == cols

    def test_subset_keeps_only_enabled(self):
        cols = self._cols("a", "b", "c", "d")
        assert self._names(_project_columns(cols, ["b", "c"], None, None)) == ["b", "c"]

    def test_always_includes_primary_keys_and_incremental(self):
        cols = self._cols("id", "name", "created_at", "extra")
        result = _project_columns(cols, ["name"], ["id"], "created_at")
        assert set(self._names(result)) == {"name", "id", "created_at"}

    def test_empty_enabled_selects_pk_and_incremental_only(self):
        cols = self._cols("id", "name", "created_at")
        result = _project_columns(cols, [], ["id"], "created_at")
        assert set(self._names(result)) == {"id", "created_at"}

    def test_unknown_enabled_names_are_ignored(self):
        cols = self._cols("a", "b")
        assert self._names(_project_columns(cols, ["a", "does_not_exist"], None, None)) == ["a"]

    def test_empty_projection_falls_back_to_all_columns(self):
        cols = self._cols("a", "b")
        # enabled=[] with no PK/cursor resolves to nothing — never select zero columns.
        assert _project_columns(cols, [], None, None) == cols


class TestParseMvTarget:
    def test_qualified_target(self):
        q = "CREATE MATERIALIZED VIEW default.mv TO other_db.target_tbl AS SELECT * FROM default.src"
        assert _parse_mv_target(q) == ("other_db", "target_tbl")

    def test_backticked_target(self):
        q = "CREATE MATERIALIZED VIEW default.mv TO `weird db`.`weird.tbl` AS SELECT 1"
        assert _parse_mv_target(q) == ("weird db", "weird.tbl")

    def test_unqualified_target(self):
        q = "CREATE MATERIALIZED VIEW default.mv TO target AS SELECT 1"
        assert _parse_mv_target(q) == ("", "target")

    def test_no_target(self):
        q = "CREATE MATERIALIZED VIEW default.mv (a UInt64) ENGINE = MergeTree ORDER BY a AS SELECT a FROM src"
        assert _parse_mv_target(q) is None

    def test_empty(self):
        assert _parse_mv_target(None) is None
        assert _parse_mv_target("") is None


class TestGetClickhouseRowCount:
    def _mock_client(self, query_side_effect):
        client = MagicMock()
        client.query.side_effect = query_side_effect
        return client

    def _result(self, rows):
        r = MagicMock()
        r.result_rows = rows
        return r

    def _run(self, responses):
        """responses: list of (expected_substring_in_query_or_None, result_rows)."""
        from products.warehouse_sources.backend.temporal.data_imports.sources.clickhouse import clickhouse as ch_module

        calls = list(responses)

        def side_effect(query, **_kwargs):
            _, rows = calls.pop(0)
            if isinstance(rows, Exception):
                raise rows
            return self._result(rows)

        client = MagicMock()
        client.query.side_effect = side_effect

        with patch.object(ch_module, "_get_client", return_value=client):
            return ch_module.get_clickhouse_row_count(
                host="h",
                port=1,
                database="default",
                user="u",
                password="p",
                secure=True,
                verify=True,
                names=None,
            )

    def test_mergetree_uses_total_rows(self):
        counts = self._run(
            [
                (None, [("events", 100, "MergeTree", "u1", "CREATE ...")]),
            ]
        )
        assert counts == {"events": 100}

    def test_distributed_falls_back_to_count(self):
        counts = self._run(
            [
                (None, [("dist_events", None, "Distributed", "u1", "CREATE ...")]),
                (None, [(42_000,)]),
            ]
        )
        assert counts == {"dist_events": 42_000}

    def test_mv_with_to_target_resolves_target(self):
        counts = self._run(
            [
                (
                    None,
                    [
                        (
                            "events_mv",
                            None,
                            "MaterializedView",
                            "u1",
                            "CREATE MATERIALIZED VIEW default.events_mv TO default.events_target AS SELECT * FROM src",
                        )
                    ],
                ),
                (None, [("default", "events_target", 999)]),
            ]
        )
        assert counts == {"events_mv": 999}

    def test_mv_without_to_uses_inner_id(self):
        counts = self._run(
            [
                (
                    None,
                    [
                        (
                            "mv",
                            None,
                            "MaterializedView",
                            "abc-uuid",
                            "CREATE MATERIALIZED VIEW default.mv (a UInt64) ENGINE = MergeTree ORDER BY a AS SELECT a FROM src",
                        )
                    ],
                ),
                (None, [(".inner_id.abc-uuid", 55)]),
            ]
        )
        assert counts == {"mv": 55}

    def test_plain_view_skipped(self):
        counts = self._run(
            [
                (None, [("v", None, "View", "u1", "CREATE VIEW ...")]),
            ]
        )
        assert counts == {}


class TestGetPrimaryKeysForSchemas:
    def _mock_client_returning(self, per_table_rows: dict[str, list[tuple]]):
        """MagicMock client whose `query` returns sorting-key rows based on the
        `table` parameter passed to `_get_primary_keys`."""
        client = MagicMock()

        def side_effect(query, parameters=None, **_kwargs):
            table = str((parameters or {}).get("table", ""))
            result = MagicMock()
            result.result_rows = per_table_rows.get(table, [])
            return result

        client.query.side_effect = side_effect
        return client

    def _run(self, client, table_names):
        from products.warehouse_sources.backend.temporal.data_imports.sources.clickhouse import clickhouse as ch_module

        with patch.object(ch_module, "_get_client", return_value=client):
            return get_primary_keys_for_schemas(
                host="h",
                port=1,
                database="default",
                user="u",
                password="p",
                secure=True,
                verify=True,
                table_names=table_names,
            )

    def test_returns_keys_per_table(self):
        client = self._mock_client_returning(
            {
                "events": [("timestamp",), ("id",)],
                "users": [("id",)],
                "logs": [],  # no sorting key
            }
        )
        result = self._run(client, ["events", "users", "logs"])
        assert result == {"events": ["timestamp", "id"], "users": ["id"], "logs": None}

    def test_empty_input(self):
        client = MagicMock()
        assert self._run(client, []) == {}
        client.query.assert_not_called()

    def test_continues_past_per_table_error(self):
        client = MagicMock()

        calls = {"n": 0}

        def side_effect(query, parameters=None, **_kwargs):
            calls["n"] += 1
            if parameters["table"] == "broken":
                raise ClickHouseError("boom")
            r = MagicMock()
            r.result_rows = [("id",)]
            return r

        client.query.side_effect = side_effect
        result = self._run(client, ["good", "broken", "other"])
        assert result["good"] == ["id"]
        assert result["broken"] is None
        assert result["other"] == ["id"]


class TestClickHouseColumnToArrowField:
    @pytest.mark.parametrize(
        "data_type,expected_arrow_type",
        [
            ("Int8", pa.int8()),
            ("Int16", pa.int16()),
            ("Int32", pa.int32()),
            ("Int64", pa.int64()),
            ("UInt8", pa.uint8()),
            ("UInt16", pa.uint16()),
            ("UInt32", pa.uint32()),
            ("UInt64", pa.uint64()),
            ("Float32", pa.float32()),
            ("Float64", pa.float64()),
            ("Bool", pa.bool_()),
            ("String", pa.string()),
            ("UUID", pa.string()),
            ("Date", pa.date32()),
            ("Date32", pa.date32()),
            ("IPv4", pa.string()),
            ("IPv6", pa.string()),
            ("Int128", pa.string()),
            ("Int256", pa.string()),
            ("UInt128", pa.string()),
            ("UInt256", pa.string()),
            ("FixedString(16)", pa.string()),
            ("Enum8('a' = 1, 'b' = 2)", pa.string()),
            ("Enum16('long_label' = 1)", pa.string()),
            ("Array(Int64)", pa.string()),
            ("Map(String, Int64)", pa.string()),
            ("Tuple(Int64, String)", pa.string()),
            ("JSON", pa.string()),
        ],
    )
    def test_simple_type_mappings(self, data_type, expected_arrow_type):
        col = ClickHouseColumn("test_col", data_type, nullable=True)
        field = col.to_arrow_field()
        assert field.type == expected_arrow_type
        assert field.name == "test_col"
        assert field.nullable is True

    def test_datetime_no_tz(self):
        col = ClickHouseColumn("ts", "DateTime", nullable=False)
        field = col.to_arrow_field()
        assert field.type == pa.timestamp("s")

    def test_datetime_with_tz(self):
        col = ClickHouseColumn("ts", "DateTime('UTC')", nullable=False)
        field = col.to_arrow_field()
        assert field.type == pa.timestamp("s", tz="UTC")

    @pytest.mark.parametrize(
        "data_type,expected_unit",
        [
            ("DateTime64(0)", "s"),
            ("DateTime64(3)", "ms"),
            ("DateTime64(6)", "us"),
            ("DateTime64(9)", "ns"),
        ],
    )
    def test_datetime64_precision(self, data_type, expected_unit):
        col = ClickHouseColumn("ts", data_type, nullable=False)
        field = col.to_arrow_field()
        assert field.type == pa.timestamp(expected_unit)

    def test_datetime64_with_tz(self):
        col = ClickHouseColumn("ts", "DateTime64(6, 'America/New_York')", nullable=False)
        field = col.to_arrow_field()
        assert field.type == pa.timestamp("us", tz="America/New_York")

    @pytest.mark.parametrize(
        "data_type,expected_precision,expected_scale",
        [
            ("Decimal(10, 2)", 10, 2),
            ("Decimal(18)", 18, 0),
            # DecimalN(S): N fixes precision (9/18/38/76), lone arg is scale.
            ("Decimal32(4)", 9, 4),
            ("Decimal64(8)", 18, 8),
            ("Decimal128(20)", 38, 20),
            ("Decimal256(40)", 76, 40),
        ],
    )
    def test_decimal_types(self, data_type, expected_precision, expected_scale):
        col = ClickHouseColumn("amt", data_type, nullable=False)
        field = col.to_arrow_field()
        assert isinstance(field.type, (pa.Decimal128Type, pa.Decimal256Type))
        assert field.type.precision == expected_precision
        assert field.type.scale == expected_scale

    def test_nullable_wrapper(self):
        col = ClickHouseColumn("id", "Nullable(Int64)", nullable=True)
        field = col.to_arrow_field()
        assert field.type == pa.int64()
        assert field.nullable is True

    def test_low_cardinality_wrapper(self):
        col = ClickHouseColumn("name", "LowCardinality(String)", nullable=False)
        field = col.to_arrow_field()
        assert field.type == pa.string()
        assert field.nullable is False

    def test_nullable_low_cardinality(self):
        col = ClickHouseColumn("name", "LowCardinality(Nullable(String))", nullable=True)
        field = col.to_arrow_field()
        assert field.type == pa.string()
        assert field.nullable is True

    def test_unknown_type_maps_to_string(self):
        col = ClickHouseColumn("mystery", "AggregateFunction(uniq, UInt64)", nullable=True)
        field = col.to_arrow_field()
        assert field.type == pa.string()


class TestClickHouseSourceNonRetryableErrors:
    @pytest.fixture
    def source(self):
        return ClickHouseSource()

    @pytest.mark.parametrize(
        "error_msg",
        [
            "Code: 516. DB::Exception: default: Authentication failed",
            "Code: 81. DB::Exception: Database `does_not_exist` doesn't exist",
            "Code: 60. DB::Exception: Table default.foo doesn't exist",
            "Could not resolve the ClickHouse host",
            "Connection refused",
            "certificate verify failed",
            "HTTPDriver for https://example.ngrok-free.dev:443 returned response code 404",
            # MEMORY_LIMIT_EXCEEDED (code 241) — server-wide OvercommitTracker kill
            "HTTPDriver for https://host:8443 received ClickHouse error code 241\n Code: 241. "
            "DB::Exception: (total) memory limit exceeded: would use 108.01 GiB, maximum: 108.00 GiB. "
            "OvercommitTracker decision: Query was selected to stop by OvercommitTracker "
            "(while reading column properties). (MEMORY_LIMIT_EXCEEDED)",
            # MEMORY_LIMIT_EXCEEDED (code 241) — per-query `max_memory_usage` budget
            "Code: 241. DB::Exception: Query memory limit exceeded: would use 3.73 GiB "
            "(attempt to allocate chunk of 4.60 MiB), maximum: 3.73 GiB. (MEMORY_LIMIT_EXCEEDED)",
            # NOT_ENOUGH_SPACE (code 243) — source server couldn't reserve disk for a
            # temporary file (filesystem cache full while buffering query output to disk).
            "HTTPDriver for https://host:8443 received ClickHouse error code 243\n Code: 243. "
            "DB::Exception: Failed to reserve 1048576 bytes for temporary file: reason cannot evict "
            "enough space: While executing BufferingToFileSink. (NOT_ENOUGH_SPACE)",
            # Source table no longer exists at sync time — dropped/renamed, or a materialized
            # view's `.inner_id.<uuid>` inner table whose UUID changed when the view was recreated.
            "Table soax_stage..inner_id.8c612ff0-b72c-4b20-8ea5-405ed002c2f6 not found or has no columns",
            "Table default.some_dropped_table not found or has no columns",
            # UNKNOWN_TYPE (code 50) — a column type ClickHouse can't serialize to Arrow,
            # e.g. an AggregateFunction state column on an aggregating materialized view.
            "HTTPDriver for https://host:8443 received ClickHouse error code 50\n Code: 50. "
            "DB::Exception: The type 'AggregateFunction(uniq, String)' of a column 'profile_id' "
            "is not supported for conversion into Arrow data format: While executing Arrow. (UNKNOWN_TYPE)",
            # SSH tunnel to the customer's bastion couldn't be brought up — the import path only
            # checks this per-source dict, so the entry must be here to stop it retrying forever.
            "Could not establish session to SSH gateway",
            # Host answered 2xx with a non-ClickHouse body — `_get_client` wraps the driver's
            # "too many values to unpack" probe error into this message.
            NOT_A_CLICKHOUSE_HTTP_RESPONSE,
        ],
    )
    def test_permanent_errors_are_non_retryable(self, source, error_msg):
        non_retryable = source.get_non_retryable_errors()
        is_non_retryable = any(pattern in error_msg for pattern in non_retryable)
        assert is_non_retryable, f"Permanent error should be non-retryable: {error_msg}"

    @pytest.mark.parametrize(
        "error_msg",
        [
            "Code: 159. DB::Exception: Timeout exceeded",  # query timeout — could be retried
            "Code: 999. DB::Exception: Keeper exception",  # transient zookeeper-style errors
            "Code: 209. DB::Exception: Socket timeout",
            # Transient gateway errors must stay retryable — only 404 is permanent.
            "HTTPDriver for https://example.ngrok-free.dev:443 returned response code 502",
            "HTTPDriver for https://example.ngrok-free.dev:443 returned response code 503",
            # 429 Too Many Requests is a rate-limit ("retry later"), not a permanent error.
            "HTTPDriver for https://example.ngrok-free.dev:443 returned response code 429",
        ],
    )
    def test_transient_errors_are_retryable(self, source, error_msg):
        non_retryable = source.get_non_retryable_errors()
        is_non_retryable = any(pattern in error_msg for pattern in non_retryable)
        assert not is_non_retryable, f"Transient error should be retryable: {error_msg}"


class TestClickHouseSourceRetryableErrors:
    @pytest.fixture
    def source(self):
        return ClickHouseSource()

    @pytest.mark.parametrize(
        "error_msg",
        [
            # The exact wrapped message that reached error tracking: a bare HTTP 502
            # from clickhouse-connect's HTTPDriver (no proxy CONNECT tunnel involved).
            "HTTPDriver for https://example.ngrok-free.dev:443 returned response code 502",
            "HTTPDriver for https://example.ngrok-free.dev:443 returned response code 503",
            "HTTPDriver for https://example.ngrok-free.dev:443 returned response code 504",
            "HTTPDriver for https://example.ngrok-free.dev:443 returned response code 429",
            "Tunnel connection failed: 502 Bad gateway",
            "Tunnel connection failed: 503 Service Unavailable",
            "Tunnel connection failed: 504 Gateway Timeout",
            "EOF occurred in violation of protocol",
            "Connection reset by peer",
            # The source dropped the connection mid-stream while reading Arrow batches
            # (urllib3 ProtocolError wrapping http.client.IncompleteRead). Byte counts vary.
            "('Connection broken: IncompleteRead(0 bytes read)', IncompleteRead(0 bytes read))",
            "('Connection broken: IncompleteRead(12345 bytes read, 67 more expected)', "
            "IncompleteRead(12345 bytes read, 67 more expected))",
            # The server accepted the connection but never answered within our timeout —
            # typically ClickHouse Cloud still cold-resuming past our allowance.
            "Error HTTPSConnectionPool(host='play.clickhouse.com', port=8443): Read timed out. "
            "(read timeout=120) executing HTTP request attempt 1 (https://play.clickhouse.com:8443)",
            # The source server was already at its concurrent-query limit when the
            # client-construction probe ran; the exact wrapped message reached error tracking.
            "HTTPDriver for https://play.clickhouse.com:8443 received ClickHouse error code 202\n "
            "Code: 202. DB::Exception: Too many simultaneous queries for all users. Current: 500, "
            "maximum: 500. (TOO_MANY_SIMULTANEOUS_QUERIES) (version 24.8.1.1 (official build))",
            # The exact wrapped message that reached error tracking: our own egress proxy was
            # unreachable past all of `_get_client`'s in-process connect retries.
            "Error HTTPSConnectionPool(host='play.clickhouse.com', port=8443): Max retries exceeded "
            "with url: /? (Caused by ProxyError('Cannot connect to proxy.', TimeoutError('timed out'))) "
            "executing HTTP request attempt 1 (https://play.clickhouse.com:8443)",
        ],
    )
    def test_transient_errors_are_retryable(self, source, error_msg):
        retryable = source.get_retryable_errors()
        assert any(pattern in error_msg for pattern in retryable), (
            f"Transient, self-recovering error should be classified as retryable (kept out of "
            f"error tracking): {error_msg}"
        )

    def test_permanent_errors_are_not_classified_as_retryable(self, source):
        # A 404 is a deterministic failure (already asserted non-retryable above) — it must not
        # also be misclassified as a benign retryable error, or `_handle_import_error` would log
        # it at `warning` and mask the real cause.
        error_msg = "HTTPDriver for https://example.ngrok-free.dev:443 returned response code 404"
        retryable = source.get_retryable_errors()
        assert not any(pattern in error_msg for pattern in retryable)

    def test_proxy_auth_failure_is_not_classified_as_retryable(self, source):
        # A 407 wraps the same "Cannot connect to proxy." prefix as the TCP-connect timeout above,
        # but it's a deterministic proxy-auth misconfiguration, not a transient blip.
        error_msg = (
            "Error HTTPSConnectionPool(host='play.clickhouse.com', port=8443): Max retries exceeded "
            "with url: /? (Caused by ProxyError('Cannot connect to proxy.', OSError('Tunnel connection "
            "failed: 407 Proxy Authentication Required')))"
        )
        retryable = source.get_retryable_errors()
        assert not any(pattern in error_msg for pattern in retryable)


class TestIsTransientConnectDrop:
    @pytest.mark.parametrize(
        "message",
        [
            # The exact wrapped message that reached error tracking from ClickHouse Cloud.
            "Error HTTPSConnectionPool(host='h', port=8443): Max retries exceeded with url: /? "
            "(Caused by SSLError(SSLEOFError(8, '[SSL: UNEXPECTED_EOF_WHILE_READING] EOF occurred "
            "in violation of protocol (_ssl.c:1032)'))) executing HTTP request attempt 1",
            "EOF occurred in violation of protocol",
            "Connection reset by peer",
            "('Connection aborted.', RemoteDisconnected('Remote end closed connection without response'))",
            # The exact wrapped message that reached error tracking: the egress proxy
            # returned a 502 while opening the CONNECT tunnel to a ClickHouse host.
            "Error HTTPSConnectionPool(host='h', port=8443): Max retries exceeded with url: /? "
            "(Caused by ProxyError('Cannot connect to proxy.', OSError('Tunnel connection failed: "
            "502 Bad gateway'))) executing HTTP request attempt 1",
            "Tunnel connection failed: 503 Service Unavailable",
            "Tunnel connection failed: 504 Gateway Timeout",
            # HTTP 429 rate-limit at connect time — clickhouse-connect doesn't
            # retry the client-construction probe, so we retry it in-process.
            "HTTPDriver for https://host:8443 returned response code 429",
            # The exact wrapped message that reached error tracking: urllib3 couldn't open a
            # TCP connection to our own egress proxy before ever attempting a CONNECT tunnel.
            "Error HTTPSConnectionPool(host='h', port=8443): Max retries exceeded with url: /? "
            "(Caused by ProxyError('Cannot connect to proxy.', TimeoutError('timed out'))) "
            "executing HTTP request attempt 1",
        ],
    )
    def test_matches_transient_drops(self, message):
        assert _is_transient_connect_drop(message)

    @pytest.mark.parametrize(
        "message",
        [
            "certificate verify failed",
            "[SSL: WRONG_VERSION_NUMBER] wrong version number (_ssl.c:2657)",
            "Code: 516. DB::Exception: Authentication failed",
            "HTTPDriver for https://host:8443 returned response code 404",
            # A proxy 407 is a deterministic auth-config failure, not a transient gateway blip.
            "Tunnel connection failed: 407 Proxy Authentication Required",
            # A 407 reaches us wrapped in the same "Cannot connect to proxy." prefix as the TCP-connect
            # timeout above — it must not become transient just because it shares that prefix.
            "(Caused by ProxyError('Cannot connect to proxy.', OSError('Tunnel connection failed: "
            "407 Proxy Authentication Required')))",
        ],
    )
    def test_does_not_match_deterministic_failures(self, message):
        assert not _is_transient_connect_drop(message)


class TestIsRateLimited:
    @pytest.mark.parametrize(
        "message",
        [
            "HTTPDriver for https://host:8443 returned response code 429",
            "Error ... HTTPDriver for https://host:443 returned response code 429 executing HTTP request",
        ],
    )
    def test_matches_429(self, message):
        assert _is_rate_limited(message)

    @pytest.mark.parametrize(
        "message",
        [
            # Other response codes have their own handling and must not match 429.
            "HTTPDriver for https://host:8443 returned response code 404",
            "HTTPDriver for https://host:8443 returned response code 502",
            "Code: 516. DB::Exception: Authentication failed",
        ],
    )
    def test_does_not_match_other_codes(self, message):
        assert not _is_rate_limited(message)


class TestIsTooManyQueries:
    @pytest.mark.parametrize(
        "message",
        [
            "Code: 202. DB::Exception: Too many simultaneous queries for all users. Current: 500, "
            "maximum: 500. (TOO_MANY_SIMULTANEOUS_QUERIES)",
            "HTTPDriver for https://host:8443 received ClickHouse error code 202\n "
            "Code: 202. DB::Exception: Too many simultaneous queries for all users. Current: 100, "
            "maximum: 100. (TOO_MANY_SIMULTANEOUS_QUERIES) (version 24.8.1.1 (official build))",
        ],
    )
    def test_matches_too_many_queries(self, message):
        assert _is_too_many_queries(message)

    @pytest.mark.parametrize(
        "message",
        [
            "Code: 241. DB::Exception: Memory limit exceeded",
            "HTTPDriver for https://host:8443 returned response code 429",
            "Code: 516. DB::Exception: Authentication failed",
        ],
    )
    def test_does_not_match_other_codes(self, message):
        assert not _is_too_many_queries(message)


class TestGetClientTransientRetry:
    """`_get_client` retries a transient connection drop during connect in-process."""

    def _connect(self):
        return _get_client(
            host="h", port=8443, database="default", user="default", password=None, secure=True, verify=True
        )

    def test_retries_transient_drop_then_succeeds(self):
        client = MagicMock()
        ssl_eof = ClickHouseError("[SSL: UNEXPECTED_EOF_WHILE_READING] EOF occurred in violation of protocol")
        with (
            patch.object(ch_module.time, "sleep"),
            patch.object(ch_module, "get_client", side_effect=[ssl_eof, client]) as mock_get_client,
        ):
            assert self._connect() is client
        assert mock_get_client.call_count == 2

    def test_retries_connect_time_429_then_succeeds(self):
        # clickhouse-connect raises OperationalError for a 429 exhausted at the
        # client-construction probe (which runs with retries=0). We retry it.
        client = MagicMock()
        rate_limited = OperationalError("HTTPDriver for https://host:8443 returned response code 429")
        with (
            patch.object(ch_module.time, "sleep"),
            patch.object(ch_module, "get_client", side_effect=[rate_limited, client]) as mock_get_client,
        ):
            assert self._connect() is client
        assert mock_get_client.call_count == 2

    def test_gives_up_after_max_attempts(self):
        ssl_eof = ClickHouseError("[SSL: UNEXPECTED_EOF_WHILE_READING] EOF occurred in violation of protocol")
        with (
            patch.object(ch_module.time, "sleep"),
            patch.object(ch_module, "get_client", side_effect=ssl_eof) as mock_get_client,
        ):
            with pytest.raises(ClickHouseConnectionError):
                self._connect()
        assert mock_get_client.call_count == _MAX_CONNECT_ATTEMPTS

    def test_rate_limit_backs_off_exponentially(self):
        # A 429 backs off exponentially (base 2) to give the rate limit room to
        # clear, unlike a connect drop which just re-dials on a short linear wait.
        client = MagicMock()
        rate_limited = OperationalError("HTTPDriver for https://host:8443 returned response code 429")
        with (
            patch.object(ch_module.time, "sleep") as mock_sleep,
            patch.object(ch_module, "get_client", side_effect=[rate_limited, rate_limited, client]) as mock_get_client,
        ):
            assert self._connect() is client
        assert mock_get_client.call_count == 3
        mock_sleep.assert_has_calls([call(2), call(4)])

    def test_retries_connect_time_too_many_queries_then_succeeds(self):
        # The client-construction probe itself can be rejected when the source server is
        # already at its concurrent-query limit; we retry it with the same backoff as a 429.
        client = MagicMock()
        too_many_queries = OperationalError(
            "Code: 202. DB::Exception: Too many simultaneous queries for all users. Current: 500, "
            "maximum: 500. (TOO_MANY_SIMULTANEOUS_QUERIES)"
        )
        with (
            patch.object(ch_module.time, "sleep") as mock_sleep,
            patch.object(
                ch_module, "get_client", side_effect=[too_many_queries, too_many_queries, client]
            ) as mock_get_client,
        ):
            assert self._connect() is client
        assert mock_get_client.call_count == 3
        mock_sleep.assert_has_calls([call(2), call(4)])

    def test_does_not_retry_deterministic_failure(self):
        cert_error = ClickHouseError("certificate verify failed")
        with (
            patch.object(ch_module.time, "sleep") as mock_sleep,
            patch.object(ch_module, "get_client", side_effect=cert_error) as mock_get_client,
        ):
            with pytest.raises(ClickHouseConnectionError):
                self._connect()
        assert mock_get_client.call_count == 1
        mock_sleep.assert_not_called()

    def test_wraps_non_clickhouse_response_probe_error(self):
        # clickhouse-connect's construction-time probe unpacks the reply into two values;
        # a non-ClickHouse 2xx body raises a bare ValueError. We wrap it as a connection
        # error (deterministic, no retry) instead of leaking the cryptic ValueError.
        probe_error = ValueError("too many values to unpack (expected 2)")
        with (
            patch.object(ch_module.time, "sleep") as mock_sleep,
            patch.object(ch_module, "get_client", side_effect=probe_error) as mock_get_client,
        ):
            with pytest.raises(ClickHouseConnectionError, match="did not return a valid ClickHouse response"):
                self._connect()
        assert mock_get_client.call_count == 1
        mock_sleep.assert_not_called()


class TestGetClientSessionSettings:
    """`_get_client` applies tuning settings after connect, tolerating a
    readonly source profile that rejects them instead of failing the sync."""

    def _connect(self, settings):
        return _get_client(
            host="h",
            port=8443,
            database="default",
            user="default",
            password=None,
            secure=True,
            verify=True,
            settings=settings,
        )

    def test_readonly_setting_does_not_fail_connection(self):
        client = MagicMock()

        def set_setting(key, _value):
            if key == "max_block_size":
                raise ProgrammingError("Setting max_block_size is unknown or readonly")

        client.set_client_setting.side_effect = set_setting
        with patch.object(ch_module, "get_client", return_value=client):
            result = self._connect({"max_block_size": 20000, "optimize_read_in_order": 1})

        assert result is client
        # The rejected setting is skipped; the accepted one is still applied.
        client.set_client_setting.assert_any_call("optimize_read_in_order", 1)

    def test_settings_applied_after_connect_not_at_construction(self):
        client = MagicMock()
        with patch.object(ch_module, "get_client", return_value=client) as mock_get_client:
            self._connect({"max_block_size": 20000})

        assert "settings" not in mock_get_client.call_args.kwargs
        client.set_client_setting.assert_called_once_with("max_block_size", 20000)


class TestTranslateError:
    def test_matches_substring_inside_long_error(self):
        msg = "Code: 516. DB::Exception: Authentication failed for user 'default'"
        assert ClickHouseSource._translate_error(msg) == "Invalid user or password"

    def test_returns_none_for_unrecognised_error(self):
        assert ClickHouseSource._translate_error("Some random error") is None

    def test_404_maps_to_wrong_interface_message(self):
        # A wrong port/proxy answers with 404; the message must name that cause
        # rather than fall through to the generic "check your details".
        msg = "HTTPDriver for https://host:8443 returned response code 404"
        translated = ClickHouseSource._translate_error(msg)
        assert translated is not None
        assert "404" in translated

    def test_non_clickhouse_response_maps_to_actionable_message(self):
        # The wrapped probe error must surface the actionable "not serving ClickHouse"
        # message during onboarding, not fall through to the generic one.
        assert ClickHouseSource._translate_error(NOT_A_CLICKHOUSE_HTTP_RESPONSE) == NOT_A_CLICKHOUSE_HTTP_RESPONSE

    @pytest.mark.parametrize("code", ["429", "502", "503", "504"])
    def test_transient_gateway_responses_ask_to_retry(self, code):
        # A busy/waking server (survived connect retries) must not be reported as
        # bad credentials — it should tell the user to retry.
        msg = f"HTTPDriver for https://host:8443 returned response code {code}"
        assert ClickHouseSource._translate_error(msg) == _TEMPORARILY_UNAVAILABLE

    @pytest.mark.parametrize("code", ["301", "302", "307", "308"])
    def test_redirect_responses_name_the_redirect(self, code):
        # Proxy-bypassing connections don't follow redirects, so the 3xx reaches the user.
        msg = f"HTTPDriver for https://host:8443 returned response code {code}"
        assert ClickHouseSource._translate_error(msg) == _REDIRECTED

    def test_certificate_hostname_mismatch_names_the_certificate_not_the_toggles(self):
        # Verification runs against the configured host even over a tunnel, so a mismatch is
        # a real certificate problem. Matching the generic "ssl" entry first would tell the
        # user to disable HTTPS, and the message must not suggest turning verification off.
        msg = (
            "[SSL: CERTIFICATE_VERIFY_FAILED] certificate verify failed: Hostname mismatch, "
            "certificate is not valid for '127.0.0.1'"
        )
        translated = ClickHouseSource._translate_error(msg)
        assert translated is not None
        assert "certificate" in translated
        assert "HTTPS" not in translated
        assert "Verify SSL" not in translated


class TestGetSchemas:
    """Tests `get_schemas` with a fully mocked ClickHouse client."""

    def _make_mock_client(self, rows):
        client = MagicMock()
        result = MagicMock()
        result.result_rows = rows
        client.query.return_value = result
        return client

    def test_groups_columns_by_table(self):
        from products.warehouse_sources.backend.temporal.data_imports.sources.clickhouse import clickhouse as ch_module

        rows = [
            ("events", "id", "UInt64"),
            ("events", "created_at", "DateTime64(6, 'UTC')"),
            ("events", "name", "Nullable(String)"),
            ("users", "id", "UInt64"),
            ("users", "email", "String"),
        ]
        mock_client = self._make_mock_client(rows)

        with patch.object(ch_module, "_get_client", return_value=mock_client):
            schemas = ch_module.get_schemas(
                host="localhost",
                port=8443,
                database="default",
                user="default",
                password="",
                secure=True,
                verify=True,
            )

        assert set(schemas.keys()) == {"events", "users"}
        assert len(schemas["events"]) == 3
        # Nullable detection
        events_cols = {c[0]: (c[1], c[2]) for c in schemas["events"]}
        assert events_cols["id"] == ("UInt64", False)
        assert events_cols["name"] == ("Nullable(String)", True)

    def test_discovery_query_excludes_alias_and_ephemeral_columns(self):
        # A native `SELECT *` skips ALIAS/EPHEMERAL columns, but our `SELECT *` expands to an
        # explicit column list — an included ALIAS whose expression can't resolve breaks the whole
        # query with UNKNOWN_IDENTIFIER (code 47). The filter must stay in the discovery query.
        from products.warehouse_sources.backend.temporal.data_imports.sources.clickhouse import clickhouse as ch_module

        mock_client = self._make_mock_client([("events", "id", "UInt64")])
        with patch.object(ch_module, "_get_client", return_value=mock_client):
            ch_module.get_schemas(
                host="localhost",
                port=8443,
                database="default",
                user="default",
                password="",
                secure=True,
                verify=True,
            )

        queries = [str(call.args[0]) for call in mock_client.query.call_args_list]
        assert any("default_kind NOT IN ('ALIAS', 'EPHEMERAL')" in q for q in queries)

    def test_excludes_materialized_view_inner_tables(self):
        from products.warehouse_sources.backend.temporal.data_imports.sources.clickhouse import clickhouse as ch_module

        rows = [
            ("events", "id", "UInt64"),
            (".inner_id.8c612ff0-b72c-4b20-8ea5-405ed002c2f6", "id", "UInt64"),
            (".inner_id.8c612ff0-b72c-4b20-8ea5-405ed002c2f6", "count", "UInt64"),
            (".inner.my_legacy_mv", "value", "String"),
        ]
        mock_client = self._make_mock_client(rows)

        with patch.object(ch_module, "_get_client", return_value=mock_client):
            schemas = ch_module.get_schemas(
                host="localhost",
                port=8443,
                database="default",
                user="default",
                password="",
                secure=True,
                verify=True,
            )

        assert set(schemas.keys()) == {"events"}


class TestGetTable:
    """Tests `_get_table`, used by the sync path to build the SELECT column list."""

    def _make_mock_client(self, cols_rows, engine: str | None = "MergeTree"):
        client = MagicMock()
        cols_result = MagicMock()
        cols_result.result_rows = cols_rows
        engine_result = MagicMock()
        engine_result.result_rows = [(engine,)] if engine is not None else []
        client.query.side_effect = [cols_result, engine_result]
        return client

    def test_excludes_alias_and_ephemeral_columns_from_query(self):
        from products.warehouse_sources.backend.temporal.data_imports.sources.clickhouse import clickhouse as ch_module

        client = self._make_mock_client([("id", "UInt64")])
        ch_module._get_table(client, "default", "events")

        cols_query = client.query.call_args_list[0].args[0]
        assert "default_kind NOT IN ('ALIAS', 'EPHEMERAL')" in cols_query


class TestSourceClassValidateCredentials:
    """High-level checks on validate_credentials error mapping."""

    def test_returns_error_when_clickhouse_connection_fails(self):
        from products.warehouse_sources.backend.temporal.data_imports.sources.clickhouse import source as source_module
        from products.warehouse_sources.backend.temporal.data_imports.sources.clickhouse.clickhouse import (
            ClickHouseConnectionError,
        )

        source = source_module.ClickHouseSource()

        config = MagicMock()
        config.host = "play.clickhouse.com"
        config.ssh_tunnel = None

        with patch.object(source, "ssh_tunnel_is_valid", return_value=(True, None)):
            with patch.object(source, "is_database_host_valid", return_value=(True, None)):
                with patch.object(
                    source,
                    "get_schemas",
                    side_effect=ClickHouseConnectionError("Code: 516. Authentication failed"),
                ):
                    valid, msg = source.validate_credentials(config, team_id=1)

        assert valid is False
        assert msg == "Invalid user or password"

    def test_url_in_host_field_returns_actionable_message_without_reflecting_input(self):
        from products.warehouse_sources.backend.temporal.data_imports.sources.clickhouse import source as source_module

        source = source_module.ClickHouseSource()

        config = MagicMock()
        config.host = "https://secret.clickhouse.cloud"
        config.ssh_tunnel = None

        with patch.object(source, "ssh_tunnel_is_valid", return_value=(True, None)):
            with patch.object(source, "is_database_host_valid") as host_valid:
                valid, msg = source.validate_credentials(config, team_id=1)

        assert valid is False
        assert "Enter just the hostname" in (msg or "")
        # The pasted value can embed credentials — it must never be echoed back.
        assert "secret.clickhouse.cloud" not in (msg or "")
        # Short-circuits before we attempt DNS resolution of the bad host.
        host_valid.assert_not_called()

    def test_returns_generic_message_for_unknown_error(self):
        from products.warehouse_sources.backend.temporal.data_imports.sources.clickhouse import source as source_module
        from products.warehouse_sources.backend.temporal.data_imports.sources.clickhouse.clickhouse import (
            ClickHouseConnectionError,
        )

        source = source_module.ClickHouseSource()

        config = MagicMock()
        config.host = "play.clickhouse.com"
        config.ssh_tunnel = None

        with patch.object(source, "ssh_tunnel_is_valid", return_value=(True, None)):
            with patch.object(source, "is_database_host_valid", return_value=(True, None)):
                with patch.object(
                    source,
                    "get_schemas",
                    side_effect=ClickHouseConnectionError("something weird happened"),
                ):
                    valid, msg = source.validate_credentials(config, team_id=1)

        assert valid is False
        assert msg == GENERIC_CONNECTION_ERROR


class TestHasDuplicatePrimaryKeys:
    def _logger(self):
        return MagicMock()

    def test_returns_false_when_no_primary_keys(self):
        client = MagicMock()
        assert _has_duplicate_primary_keys(client, "db", "t", None, self._logger()) is False
        assert _has_duplicate_primary_keys(client, "db", "t", [], self._logger()) is False
        client.query.assert_not_called()

    def test_fails_safe_to_true_on_clickhouse_error(self):
        client = MagicMock()
        client.query.side_effect = ClickHouseError("Code: 62. DB::Exception: Syntax error")
        # On error we must assume duplicates exist so the incremental merge is
        # blocked. Returning False here would silently corrupt the Delta table.
        assert _has_duplicate_primary_keys(client, "db", "t", ["id"], self._logger()) is True

    def test_captures_unexpected_clickhouse_error(self):
        from products.warehouse_sources.backend.temporal.data_imports.sources.clickhouse import clickhouse as ch_module

        client = MagicMock()
        client.query.side_effect = ClickHouseError("Code: 62. DB::Exception: Syntax error")

        with patch.object(ch_module, "capture_exception") as mock_capture:
            assert _has_duplicate_primary_keys(client, "db", "t", ["id"], self._logger()) is True

        mock_capture.assert_called_once()

    @pytest.mark.parametrize(
        "error_msg",
        [
            # max_memory_usage cap (code 241)
            "HTTPDriver received ClickHouse error code 241\n Code: 241. DB::Exception: Query memory limit "
            "exceeded: would use 958.14 MiB, maximum: 953.67 MiB: While executing AggregatingInOrderTransform. "
            "(MEMORY_LIMIT_EXCEEDED)\n",
            # max_execution_time cap (code 159)
            "HTTPDriver received ClickHouse error code 159\n Code: 159. DB::Exception: Timeout exceeded: "
            "elapsed 53343.4 ms, maximum: 30000 ms. (TIMEOUT_EXCEEDED)\n",
        ],
    )
    def test_probe_budget_exhaustion_not_captured(self, error_msg):
        from products.warehouse_sources.backend.temporal.data_imports.sources.clickhouse import clickhouse as ch_module

        client = MagicMock()
        client.query.side_effect = ClickHouseError(error_msg)

        with patch.object(ch_module, "capture_exception") as mock_capture:
            # Still assumes duplicates (safe append mode), but the probe hitting
            # its own memory/time budget is the designed fallback — not error
            # tracking noise.
            assert _has_duplicate_primary_keys(client, "db", "t", ["id"], self._logger()) is True

        mock_capture.assert_not_called()

    def test_passes_bounded_settings(self):
        client = MagicMock()
        result = MagicMock()
        result.result_rows = []
        client.query.return_value = result

        _has_duplicate_primary_keys(client, "db", "t", ["id", "ts"], self._logger())

        _, kwargs = client.query.call_args
        settings = kwargs["settings"]
        assert settings["optimize_aggregation_in_order"] == 1
        # Bounded-prefix probe: read at most 10M rows, truncate silently
        # instead of throwing. Keeps the check O(budget) regardless of
        # table size.
        assert settings["max_rows_to_read"] == 10_000_000
        assert settings["read_overflow_mode"] == "break"
        assert settings["max_execution_time"] == 30
        assert settings["max_memory_usage"] == 1_000_000_000

    @pytest.mark.parametrize(
        "error_msg",
        [
            # clickhouse-connect rejects readonly/unknown session settings
            # client-side (ClickHouse Cloud, readonly user profiles).
            "Setting max_memory_usage is unknown or readonly",
            "Setting optimize_aggregation_in_order is unknown or readonly",
            # Server-side memory cap below our probe's max_memory_usage.
            "Code: 241. DB::Exception: Query memory limit exceeded ... (MEMORY_LIMIT_EXCEEDED)",
            # HTTP client read timeout firing before the server-side
            # max_execution_time cap does (e.g. ClickHouse Cloud cold-resume).
            "Error HTTPSConnectionPool(host='example.clickhouse.cloud', port=8443): Read timed out. (read timeout=120)",
        ],
    )
    def test_expected_probe_failures_not_captured(self, error_msg):
        client = MagicMock()
        client.query.side_effect = ClickHouseError(error_msg)

        with patch(
            "products.warehouse_sources.backend.temporal.data_imports.sources.clickhouse.clickhouse.capture_exception"
        ) as mock_capture:
            # Still fails safe to True (force append mode), just without noise.
            assert _has_duplicate_primary_keys(client, "db", "t", ["id"], self._logger()) is True

        mock_capture.assert_not_called()

    def test_unexpected_probe_failures_are_captured(self):
        client = MagicMock()
        client.query.side_effect = ClickHouseError("Code: 999. DB::Exception: Keeper exception")

        with patch(
            "products.warehouse_sources.backend.temporal.data_imports.sources.clickhouse.clickhouse.capture_exception"
        ) as mock_capture:
            assert _has_duplicate_primary_keys(client, "db", "t", ["id"], self._logger()) is True

        mock_capture.assert_called_once()


class TestGetIncrementalRowCount:
    def _logger(self):
        return MagicMock()

    def test_returns_count_from_query(self):
        client = MagicMock()
        result = MagicMock()
        result.result_rows = [(42,)]
        client.query.return_value = result

        count = _get_incremental_row_count(client, "db", "t", "created_at", "2024-01-01", self._logger())
        assert count == 42

        args, kwargs = client.query.call_args
        assert "`created_at` > %(last_value)s" in args[0]
        assert kwargs["parameters"] == {"last_value": "2024-01-01"}
        assert kwargs["settings"] == {"max_execution_time": 30}

    def test_casts_date_last_value_through_todate32(self):
        client = MagicMock()
        result = MagicMock()
        result.result_rows = [(7,)]
        client.query.return_value = result

        count = _get_incremental_row_count(
            client, "db", "t", "day", 20657, self._logger(), incremental_field_type=IncrementalFieldType.Date
        )
        assert count == 7

        args, _ = client.query.call_args
        assert "`day` > toDate32(%(last_value)s)" in args[0]

    def test_returns_none_on_error(self):
        client = MagicMock()
        client.query.side_effect = ClickHouseError("timeout")
        assert _get_incremental_row_count(client, "db", "t", "id", 0, self._logger()) is None

    def test_returns_none_when_count_is_null(self):
        client = MagicMock()
        result = MagicMock()
        result.result_rows = [(None,)]
        client.query.return_value = result
        assert _get_incremental_row_count(client, "db", "t", "id", 0, self._logger()) is None


class TestGetPartitionSettings:
    def _logger(self):
        return MagicMock()

    @pytest.mark.parametrize(
        "error_msg",
        [
            "HTTPDriver for https://example.invalid:443 returned response code 429",
            "HTTPDriver for https://example.invalid:443 returned response code 502",
            "HTTPDriver for https://example.invalid:443 returned response code 503",
            "HTTPDriver for https://example.invalid:443 returned response code 504",
        ],
    )
    def test_transient_http_response_not_captured(self, error_msg):
        client = MagicMock()
        client.query.side_effect = ClickHouseError(error_msg)

        with patch.object(ch_module, "capture_exception") as mock_capture:
            # Falls back to default partitioning without adding error-tracking
            # noise — the source rate-limiting us isn't actionable on our side.
            assert _get_partition_settings(client, "db", "t", self._logger()) is None

        mock_capture.assert_not_called()

    def test_unexpected_error_is_captured(self):
        client = MagicMock()
        client.query.side_effect = ClickHouseError("Code: 62. DB::Exception: Syntax error")

        with patch.object(ch_module, "capture_exception") as mock_capture:
            assert _get_partition_settings(client, "db", "t", self._logger()) is None

        mock_capture.assert_called_once()


class TestGetRowsBatching:
    """The source accumulates small Arrow blocks into larger pa.Tables before
    yielding so Delta gets fewer, larger commits. Verify the accumulation
    boundaries."""

    def _stream_context(self, blocks):
        """Build a fake `query_arrow_stream(...)` that returns `blocks`."""
        cm = MagicMock()
        cm.__enter__.return_value = iter(blocks)
        cm.__exit__.return_value = False
        return cm

    def _run_get_rows(self, blocks):
        """Invoke `clickhouse_source(...).items()` against a stream of `blocks`."""
        from contextlib import contextmanager

        from products.warehouse_sources.backend.temporal.data_imports.sources.clickhouse import clickhouse as ch_module

        # Minimal discovery stubs so clickhouse_source builds a SourceResponse.
        mock_client = MagicMock()
        mock_table = MagicMock()
        mock_table.to_arrow_schema.return_value = pa.schema([pa.field("id", pa.int64())])

        stream_client = MagicMock()
        stream_client.query_arrow_stream.return_value = self._stream_context(blocks)

        @contextmanager
        def fake_tunnel():
            yield ("localhost", 8443)

        clients = [mock_client, stream_client]

        def fake_get_client(**_kwargs):
            return clients.pop(0)

        with (
            patch.object(ch_module, "_get_client", side_effect=fake_get_client),
            patch.object(ch_module, "_get_table", return_value=mock_table),
            patch.object(ch_module, "_get_primary_keys", return_value=["id"]),
            patch.object(ch_module, "_has_duplicate_primary_keys", return_value=False),
            patch.object(ch_module, "_get_partition_settings", return_value=None),
            patch.object(ch_module, "get_clickhouse_row_count", return_value={}),
        ):
            response = ch_module.clickhouse_source(
                tunnel=fake_tunnel,
                user="u",
                password="p",
                database="db",
                secure=True,
                verify=True,
                table_names=["events"],
                should_use_incremental_field=False,
                logger=MagicMock(),
                db_incremental_field_last_value=None,
            )
            items = response.items()
            assert not isinstance(items, AsyncIterable)
            return list(items)

    def _block(self, rows):
        return pa.RecordBatch.from_arrays([pa.array(list(range(rows)), type=pa.int64())], names=["id"])

    def test_accumulates_until_row_target(self):
        # 5 blocks × 30k rows = 150k total > YIELD_TARGET_ROWS (100k).
        # Expect 2 yielded tables: one at/after 100k rows, one with the rest.
        blocks = [self._block(30_000) for _ in range(5)]
        yielded = self._run_get_rows(blocks)
        assert len(yielded) == 2
        assert sum(t.num_rows for t in yielded) == 150_000
        # First yield must have crossed the row target.
        assert yielded[0].num_rows >= YIELD_TARGET_ROWS

    def test_single_batch_below_target(self):
        # Small blocks below row/byte targets must still flush on stream end.
        blocks = [self._block(100), self._block(200)]
        yielded = self._run_get_rows(blocks)
        assert len(yielded) == 1
        assert yielded[0].num_rows == 300

    def test_skips_empty_blocks(self):
        blocks = [self._block(0), self._block(50), self._block(0)]
        yielded = self._run_get_rows(blocks)
        assert len(yielded) == 1
        assert yielded[0].num_rows == 50

    def test_empty_stream_yields_nothing(self):
        assert self._run_get_rows([]) == []


class TestClickHouseReconcileSchemaMetadata(BaseTest):
    """The ClickHouse-specific override that routes through the shared reconcile helper."""

    def test_persists_schema_metadata_for_clickhouse_source(self) -> None:
        source = ExternalDataSource.objects.create(team=self.team, source_type=ExternalDataSourceType.CLICKHOUSE)
        schema = ExternalDataSchema.objects.create(team=self.team, source=source, name="events")

        result = ClickHouseSource().reconcile_schema_metadata(
            source=source,
            source_schemas=[
                SourceSchema(
                    name="events",
                    supports_incremental=False,
                    supports_append=False,
                    columns=[("uuid", "UUID", False), ("timestamp", "DateTime64(6)", False)],
                )
            ],
            team_id=self.team.pk,
        )

        assert result == []
        schema.refresh_from_db()
        metadata = schema.schema_metadata
        assert metadata is not None
        assert [column["name"] for column in metadata["columns"]] == ["uuid", "timestamp"]


class TestBypassEnvProxy:
    """The proxy bypass for PostHog-internal direct connections.

    `bypass_env_proxy=True` must hand clickhouse-connect a pool manager, which
    stops it consulting HTTP(S)_PROXY env vars; `False` must leave the default
    (proxy-honouring) behaviour intact.
    """

    @pytest.mark.parametrize("verify", [True, False])
    def test_no_env_proxy_pool_manager_ignores_proxy_env(self, verify):
        from urllib3 import PoolManager, ProxyManager

        from products.warehouse_sources.backend.temporal.data_imports.sources.clickhouse.clickhouse import (
            _no_env_proxy_pool_manager,
        )

        with patch.dict("os.environ", {"HTTPS_PROXY": "http://egress-proxy:4750"}):
            manager = _no_env_proxy_pool_manager(verify)
        assert isinstance(manager, PoolManager)
        assert not isinstance(manager, ProxyManager)
        # Cached: streaming clients must share the manager (they don't own it).
        assert _no_env_proxy_pool_manager(verify) is manager

    @pytest.mark.parametrize(
        "bypass,expected_pool_mgr_factory",
        [
            ("internal_team", lambda: ch_module._no_env_proxy_pool_manager(True, None)),
            (None, lambda: None),
        ],
    )
    def test_get_client_forwards_pool_manager_only_when_bypassing(self, bypass, expected_pool_mgr_factory):
        with patch.object(ch_module, "get_client") as mock_get_client:
            _get_client(
                host="ch.example.com",
                port=8443,
                database="default",
                user="reader",
                password="secret",
                secure=True,
                verify=True,
                bypass_env_proxy=bypass,
            )
        assert mock_get_client.call_count == 1
        assert mock_get_client.call_args.kwargs["pool_mgr"] is expected_pool_mgr_factory()

    def test_eviction_releases_the_manager_everywhere_it_is_retained(self):
        # The cache key contains the user-controlled hostname, so it must be bounded — and a
        # bounded cache only helps if eviction also drops the manager from clickhouse-connect's
        # process-global registry, the other place that would retain it for the worker's life.
        from clickhouse_connect.driver.httputil import all_managers

        with patch.object(ch_module, "_POOL_MANAGER_CACHE_MAX", 2):
            first = ch_module._no_env_proxy_pool_manager(True, "evict-me.example")
            assert first in all_managers
            for n in range(2):
                ch_module._no_env_proxy_pool_manager(True, f"filler-{n}.example")

        assert first not in all_managers
        assert ch_module._no_env_proxy_pool_manager(True, "evict-me.example") is not first


class TestInternalHostTeamAllowlist:
    @pytest.mark.parametrize(
        "region,team_id,expected",
        [
            ("US", 2, True),
            ("US", 1, False),
            ("US", 12345, False),
            ("EU", 1, True),
            ("EU", 2, False),
            ("EU", 12345, False),
            (None, 2, False),
            ("DEV", 2, False),
        ],
    )
    def test_allowlist(self, region, team_id, expected):
        from products.warehouse_sources.backend.temporal.data_imports.sources.common import mixins

        with patch.object(mixins, "get_instance_region", return_value=region):
            assert mixins.is_team_allowlisted_for_internal_hosts(team_id) is expected


_FORBIDDEN_RESPONSE = b"HTTP/1.1 403 Forbidden\r\nContent-Length: 0\r\nConnection: close\r\n\r\n"


@contextmanager
def _recording_server(response: bytes = _FORBIDDEN_RESPONSE) -> Iterator[tuple[int, list[str]]]:
    server = socket.create_server(("127.0.0.1", 0))
    server.settimeout(0.1)
    requests: list[str] = []
    stop = threading.Event()

    def serve() -> None:
        while not stop.is_set():
            try:
                conn, _ = server.accept()
            except (TimeoutError, OSError):
                continue
            with conn:
                requests.append(conn.recv(8192).decode("latin-1").split("\r\n")[0])
                conn.sendall(response)

    thread = threading.Thread(target=serve, daemon=True)
    thread.start()
    try:
        yield server.getsockname()[1], requests
    finally:
        stop.set()
        thread.join(timeout=5)
        server.close()


def _connect_to(*, port: int, bypass_env_proxy: "ch_module.BypassEnvProxy") -> None:
    _get_client(
        host="127.0.0.1",
        port=port,
        database="default",
        user="default",
        password=None,
        secure=False,
        verify=True,
        bypass_env_proxy=bypass_env_proxy,
    )


class TestGetClientEgressProxyRouting:
    """Where the connection actually goes, which is what decides whether a tunnel works.

    PostHog's runtime points HTTP_PROXY at the Smokescreen egress proxy, and Smokescreen blocks
    loopback. Routing a tunneled connection through it means the request never reaches the SSH
    tunnel's local forwarded port, so the tunnel opens no channel to the customer's ClickHouse
    and the source fails with a generic connection error. The stub servers answer with a
    deterministic 403 rather than dropping the connection so that `_get_client` raises on the
    first attempt instead of entering its transient-retry backoff.
    """

    @parameterized.expand([("tunneled", "tunnel_loopback"), ("internal", "internal_team"), ("proxied", None)])
    def test_only_a_proxied_connection_goes_through_the_egress_proxy(self, _name: str, reason) -> None:
        with _recording_server() as (proxy_port, proxy_requests):
            with _recording_server() as (bound_port, bound_requests):
                proxy_url = f"http://127.0.0.1:{proxy_port}"
                env = {"HTTP_PROXY": proxy_url, "http_proxy": proxy_url}
                with patch.dict(os.environ, env):
                    os.environ.pop("NO_PROXY", None)
                    os.environ.pop("no_proxy", None)

                    with pytest.raises(ClickHouseConnectionError):
                        _connect_to(port=bound_port, bypass_env_proxy=reason)

        bypassed = reason is not None
        assert bool(bound_requests) == bypassed
        assert bool(proxy_requests) == (not bypassed)

    def test_redirect_away_from_the_target_is_not_followed(self) -> None:
        # A bypassing connection skips the egress proxy, so following a redirect would let the
        # host we reached send us to an address the proxy would have denied.
        with _recording_server() as (elsewhere_port, elsewhere_requests):
            redirect = (
                f"HTTP/1.1 302 Found\r\nLocation: http://127.0.0.1:{elsewhere_port}/\r\n"
                "Content-Length: 0\r\nConnection: close\r\n\r\n"
            ).encode()
            with _recording_server(response=redirect) as (bound_port, bound_requests):
                with pytest.raises(ClickHouseConnectionError):
                    _connect_to(port=bound_port, bypass_env_proxy="tunnel_loopback")

        assert bound_requests
        assert elsewhere_requests == []

    def test_tunneled_https_verifies_against_the_database_hostname(self) -> None:
        # We dial the tunnel's loopback bind, so SNI and hostname validation must run against
        # the database's own hostname or a valid certificate can never match — and the
        # workaround users would reach for is disabling verification, which invites MITM
        # between the SSH server and ClickHouse.
        with patch.object(ch_module, "get_client") as mock_get_client:
            _get_client(
                host="127.0.0.1",
                port=8443,
                database="default",
                user="default",
                password=None,
                secure=True,
                verify=True,
                bypass_env_proxy="tunnel_loopback",
                server_hostname="clickhouse.internal",
            )
        manager = mock_get_client.call_args.kwargs["pool_mgr"]
        pool = manager.connection_from_host("127.0.0.1", 8443, scheme="https")
        assert pool.assert_hostname == "clickhouse.internal"
        assert pool.conn_kw["server_hostname"] == "clickhouse.internal"
        # Plain-HTTP tunnels must not share the hostname-pinned manager.
        assert manager is not ch_module._no_env_proxy_pool_manager(True, None)

    def test_tunnel_claim_with_non_loopback_host_is_refused(self) -> None:
        # The flag and the host reach `_get_client` independently; a caller pairing the
        # tunnel claim with a host that didn't come from a tunnel must fail loudly, before
        # any connection is attempted with the proxy-bypassing manager.
        with patch.object(ch_module, "get_client") as mock_get_client:
            with pytest.raises(Exception, match="non-loopback"):
                _get_client(
                    host="ch.example.com",
                    port=8443,
                    database="default",
                    user="default",
                    password=None,
                    secure=True,
                    verify=True,
                    bypass_env_proxy="tunnel_loopback",
                )
        mock_get_client.assert_not_called()


class TestDirectQueryClientBypassEnvProxy:
    """`direct_query_client` backs the HogQL direct-SQL adapter, and unlike every other
    `_get_client` call site on `ClickHouseSource` it once omitted `bypass_env_proxy` entirely —
    an allowlisted internal team's direct query silently routed through the egress proxy and
    failed to reach the PostHog-internal host it was pointed at.

    A tunneled connection must bypass for a different reason: the address is our own loopback
    bind, which the proxy blocks, so a customer team with a tunnel never reached its ClickHouse.
    """

    @pytest.mark.parametrize(
        "region,team_id,tunneled,expected_bypass",
        [
            ("US", 2, False, "internal_team"),
            ("US", 12345, False, None),
            ("US", 12345, True, "tunnel_loopback"),
        ],
    )
    def test_forwards_bypass_env_proxy_from_team_allowlist(self, region, team_id, tunneled, expected_bypass):
        from products.warehouse_sources.backend.temporal.data_imports.sources.clickhouse import source as source_module
        from products.warehouse_sources.backend.temporal.data_imports.sources.common import mixins

        source = ClickHouseSource()
        config = MagicMock()
        config.host = "db.example.com"
        config.database = "default"
        config.user = "default"
        config.password = None
        config.secure = True
        config.verify = True
        config.ssh_tunnel = MagicMock(enabled=True) if tunneled else None

        with patch.object(mixins, "get_instance_region", return_value=region):
            with patch.object(source, "with_ssh_tunnel") as mock_with_ssh_tunnel:
                mock_with_ssh_tunnel.return_value.__enter__.return_value = ("host", 8443)
                with patch.object(source_module, "_get_client") as mock_get_client:
                    with source.direct_query_client(config, team_id, query_timeout=60):
                        pass

        assert mock_get_client.call_args.kwargs["bypass_env_proxy"] == expected_bypass
        # The configured host always rides along; `_get_client` only applies it to TLS when
        # the bypass reason is the tunnel.
        assert mock_get_client.call_args.kwargs["server_hostname"] == "db.example.com"
