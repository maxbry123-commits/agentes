import pytest
from unittest import mock

from products.warehouse_sources.backend.temporal.data_imports.sources.assemblyai.settings import (
    ENDPOINTS,
    INCREMENTAL_FIELDS,
)
from products.warehouse_sources.backend.temporal.data_imports.sources.assemblyai.source import AssemblyAISource
from products.warehouse_sources.backend.temporal.data_imports.sources.generated_configs.assemblyai import (
    AssemblyAISourceConfig,
)


class TestAssemblyAISource:
    def setup_method(self):
        self.source = AssemblyAISource()
        self.team_id = 123
        self.config = AssemblyAISourceConfig(api_key="key", region="us")

    def test_connection_host_fields_includes_region(self):
        # `region` selects the host the stored API key is sent to, so editing it must re-require the secret.
        assert self.source.connection_host_fields == ["region"]

    def test_lists_tables_without_credentials(self):
        # get_schemas iterates a static endpoint catalog with no I/O, so the public docs catalog renders.
        assert self.source.lists_tables_without_credentials is True
        documented = self.source.get_documented_tables()
        assert [t["name"] for t in documented] == ["transcripts"]
        assert documented[0]["sync_methods"] == ["Full refresh"]

    def test_get_schemas_is_full_refresh_only(self):
        schemas = {s.name: s for s in self.source.get_schemas(self.config, self.team_id)}

        assert set(schemas) == set(ENDPOINTS)
        transcripts = schemas["transcripts"]
        # AssemblyAI exposes no server-side `created >= X` filter, so we never advertise incremental.
        assert transcripts.supports_incremental is False
        assert transcripts.supports_append is False
        assert transcripts.incremental_fields == INCREMENTAL_FIELDS["transcripts"]

    @pytest.mark.parametrize(
        "observed_error",
        [
            "401 Client Error: Unauthorized for url: https://api.assemblyai.com/v2/transcript?limit=200",
            "401 Client Error: Unauthorized for url: https://api.eu.assemblyai.com/v2/transcript/abc",
        ],
    )
    def test_non_retryable_errors_match_auth_failures(self, observed_error):
        non_retryable_errors = self.source.get_non_retryable_errors()
        assert any(key in observed_error for key in non_retryable_errors)

    @pytest.mark.parametrize(
        "other_error",
        [
            "500 Server Error: Internal Server Error for url: https://api.assemblyai.com/v2/transcript",
            "429 Client Error: Too Many Requests for url: https://api.assemblyai.com/v2/transcript",
            "401 Client Error: Unauthorized for url: https://api.stripe.com/v1/customers",
        ],
    )
    def test_non_retryable_errors_does_not_match_transient_or_unrelated(self, other_error):
        non_retryable_errors = self.source.get_non_retryable_errors()
        assert not any(key in other_error for key in non_retryable_errors)

    @pytest.mark.parametrize(
        "mock_return, expected_valid, expected_message",
        [
            (True, True, None),
            (False, False, "Invalid AssemblyAI API key"),
        ],
    )
    @mock.patch(
        "products.warehouse_sources.backend.temporal.data_imports.sources.assemblyai.source.validate_assemblyai_credentials"
    )
    def test_validate_credentials(self, mock_validate, mock_return, expected_valid, expected_message):
        mock_validate.return_value = mock_return

        is_valid, error_message = self.source.validate_credentials(self.config, self.team_id)

        assert is_valid is expected_valid
        assert error_message == expected_message
        mock_validate.assert_called_once_with(self.config.api_key, self.config.region)
