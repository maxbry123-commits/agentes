from collections.abc import Callable, Iterator
from datetime import datetime
from typing import Any, Optional, cast

import pytest
from unittest.mock import MagicMock, patch

from parameterized import parameterized

from products.warehouse_sources.backend.temporal.data_imports.sources.common.integration_accounts import (
    IntegrationAccountListingError,
)
from products.warehouse_sources.backend.temporal.data_imports.sources.common.resumable import ResumableSourceManager
from products.warehouse_sources.backend.temporal.data_imports.sources.snapchat_ads.settings import (
    SNAPCHAT_ADS_CONFIG,
    EndpointType,
)
from products.warehouse_sources.backend.temporal.data_imports.sources.snapchat_ads.snapchat_ads import (
    SnapchatResumeConfig,
    _iter_rows,
)
from products.warehouse_sources.backend.temporal.data_imports.sources.snapchat_ads.source import SnapchatAdsSource
from products.warehouse_sources.backend.temporal.data_imports.sources.snapchat_ads.utils import (
    AD_ACCOUNTS_PAGE_LIMIT,
    MAX_AD_ACCOUNT_PAGES,
    SnapchatAdsPaginator,
    SnapchatDateRangeManager,
    SnapchatStatsResource,
    format_stats_day_boundary,
    list_ad_accounts,
)


class _FakeResource:
    """Iterable stand-in for a ``rest_api_resource`` that drives ``resume_hook``
    the way the real REST client does: one call per page, with the next-page
    cursor when available and ``None`` after the last page."""

    def __init__(
        self,
        pages: list[list[dict[str, Any]]],
        resume_hook: Optional[Callable[[Optional[dict[str, Any]]], None]],
        next_link_prefix: str = "https://adsapi.snapchat.com/v1/next?cursor=page",
    ) -> None:
        self._pages = pages
        self._resume_hook = resume_hook
        self._next_link_prefix = next_link_prefix

    def __iter__(self) -> Iterator[list[dict[str, Any]]]:
        total = len(self._pages)
        for index, page in enumerate(self._pages):
            yield page
            if self._resume_hook is None:
                continue
            if index < total - 1:
                next_state: Optional[dict[str, Any]] = {"next_link": f"{self._next_link_prefix}{index + 1}"}
            else:
                next_state = None
            self._resume_hook(next_state)


def _mock_resumable_manager(*, can_resume: bool = False, saved: Optional[SnapchatResumeConfig] = None) -> MagicMock:
    manager = MagicMock(spec=ResumableSourceManager)
    manager.can_resume.return_value = can_resume
    manager.load_state.return_value = saved
    return manager


class TestIterRowsFreshRun:
    def test_calls_rest_api_resource_without_initial_state(self) -> None:
        captured_kwargs: dict[str, Any] = {}

        def _fake_rest_api_resource(*args: Any, **kwargs: Any) -> _FakeResource:
            captured_kwargs.update(kwargs)
            return _FakeResource(
                pages=[[{"id": "c1"}], [{"id": "c2"}]],
                resume_hook=kwargs["resume_hook"],
            )

        manager = _mock_resumable_manager(can_resume=False)

        with patch(
            "products.warehouse_sources.backend.temporal.data_imports.sources.snapchat_ads.snapchat_ads.rest_api_resource",
            side_effect=_fake_rest_api_resource,
        ):
            batches = list(
                _iter_rows(
                    ad_account_id="acct",
                    endpoint="campaigns",
                    team_id=1,
                    job_id="job",
                    access_token="token",
                    resumable_source_manager=manager,
                    db_incremental_field_last_value=None,
                    should_use_incremental_field=False,
                )
            )

        assert batches == [[{"id": "c1"}], [{"id": "c2"}]]
        assert captured_kwargs["initial_paginator_state"] is None
        manager.load_state.assert_not_called()

    def test_saves_checkpoint_with_next_link_after_each_page(self) -> None:
        def _fake_rest_api_resource(*args: Any, **kwargs: Any) -> _FakeResource:
            return _FakeResource(
                pages=[[{"id": "c1"}], [{"id": "c2"}], [{"id": "c3"}]],
                resume_hook=kwargs["resume_hook"],
            )

        manager = _mock_resumable_manager(can_resume=False)

        with patch(
            "products.warehouse_sources.backend.temporal.data_imports.sources.snapchat_ads.snapchat_ads.rest_api_resource",
            side_effect=_fake_rest_api_resource,
        ):
            list(
                _iter_rows(
                    ad_account_id="acct",
                    endpoint="campaigns",
                    team_id=1,
                    job_id="job",
                    access_token="token",
                    resumable_source_manager=manager,
                    db_incremental_field_last_value=None,
                    should_use_incremental_field=False,
                )
            )

        saved_configs = [call.args[0] for call in manager.save_state.call_args_list]
        # Only concrete next_link cursors are persisted — the final None call
        # from the resume_hook is a no-op, matching mailchimp/reddit_ads.
        assert saved_configs == [
            SnapchatResumeConfig(
                chunk_index=0,
                next_link="https://adsapi.snapchat.com/v1/next?cursor=page1",
            ),
            SnapchatResumeConfig(
                chunk_index=0,
                next_link="https://adsapi.snapchat.com/v1/next?cursor=page2",
            ),
        ]


class TestIterRowsResume:
    @parameterized.expand(
        [
            (
                "valid_state_seeds_paginator",
                SnapchatResumeConfig(
                    chunk_index=0,
                    next_link="https://adsapi.snapchat.com/v1/campaigns?cursor=page1&limit=1000",
                ),
                {"next_link": "https://adsapi.snapchat.com/v1/campaigns?cursor=page1&limit=1000"},
            ),
            (
                "stale_chunk_index_falls_back_to_start",
                SnapchatResumeConfig(chunk_index=5, next_link="https://example.com/cursor=x"),
                None,
            ),
        ]
    )
    def test_initial_paginator_state_from_resume(
        self,
        _name: str,
        saved: SnapchatResumeConfig,
        expected_initial_state: Optional[dict[str, Any]],
    ) -> None:
        captured_kwargs: dict[str, Any] = {}

        def _fake_rest_api_resource(*args: Any, **kwargs: Any) -> _FakeResource:
            captured_kwargs.update(kwargs)
            return _FakeResource(pages=[[{"id": "c1"}]], resume_hook=kwargs["resume_hook"])

        manager = _mock_resumable_manager(can_resume=True, saved=saved)

        with patch(
            "products.warehouse_sources.backend.temporal.data_imports.sources.snapchat_ads.snapchat_ads.rest_api_resource",
            side_effect=_fake_rest_api_resource,
        ):
            batches = list(
                _iter_rows(
                    ad_account_id="acct",
                    endpoint="campaigns",
                    team_id=1,
                    job_id="job",
                    access_token="token",
                    resumable_source_manager=manager,
                    db_incremental_field_last_value=None,
                    should_use_incremental_field=False,
                )
            )

        assert batches == [[{"id": "c1"}]]
        assert captured_kwargs["initial_paginator_state"] == expected_initial_state


class TestIterRowsEmptyPages:
    def test_empty_pages_are_not_yielded(self) -> None:
        def _fake_rest_api_resource(*args: Any, **kwargs: Any) -> _FakeResource:
            return _FakeResource(pages=[[], [{"id": "c1"}], []], resume_hook=kwargs["resume_hook"])

        manager = _mock_resumable_manager(can_resume=False)

        with patch(
            "products.warehouse_sources.backend.temporal.data_imports.sources.snapchat_ads.snapchat_ads.rest_api_resource",
            side_effect=_fake_rest_api_resource,
        ):
            batches = list(
                _iter_rows(
                    ad_account_id="acct",
                    endpoint="campaigns",
                    team_id=1,
                    job_id="job",
                    access_token="token",
                    resumable_source_manager=manager,
                    db_incremental_field_last_value=None,
                    should_use_incremental_field=False,
                )
            )

        assert batches == [[{"id": "c1"}]]


def _fake_stats_chunks(count: int) -> list[dict[str, Any]]:
    """Stand-in for ``SnapchatStatsResource.setup_stats_resources`` output.

    Only the structural bits ``_build_chunk_resources`` inspects are needed:
    an ``endpoint`` dict that the paginator can be written into.
    """
    return [{"name": f"stats_chunk_{i}", "endpoint": {"path": "/stats"}} for i in range(count)]


def _stats_page(entity_id: str) -> list[dict[str, Any]]:
    """Minimal page payload shaped the way ``transform_stats_reports`` expects."""
    return [
        {
            "timeseries_stat": {
                "id": entity_id,
                "type": "CAMPAIGN",
                "timeseries": [
                    {
                        "start_time": "2026-04-01T00:00:00Z",
                        "end_time": "2026-04-02T00:00:00Z",
                        "stats": {"impressions": 1},
                    }
                ],
            }
        }
    ]


class TestIterRowsMultiChunkStats:
    """STATS endpoints fan out across date chunks; these tests drive
    ``_iter_rows`` through a 2-chunk fake fan-out to exercise chunk
    advancement and resume-across-chunks behavior."""

    def test_fresh_run_iterates_all_chunks_and_advances_checkpoint(self) -> None:
        captured_calls: list[dict[str, Any]] = []

        def _fake_rest_api_resource(*args: Any, **kwargs: Any) -> _FakeResource:
            captured_calls.append(dict(kwargs))
            chunk_idx = len(captured_calls) - 1
            return _FakeResource(
                pages=[_stats_page(f"entity-{chunk_idx}")],
                resume_hook=kwargs["resume_hook"],
                next_link_prefix=f"https://adsapi.snapchat.com/v1/stats?chunk={chunk_idx}&cursor=page",
            )

        manager = _mock_resumable_manager(can_resume=False)

        with (
            patch(
                "products.warehouse_sources.backend.temporal.data_imports.sources.snapchat_ads.snapchat_ads.rest_api_resource",
                side_effect=_fake_rest_api_resource,
            ),
            patch(
                "products.warehouse_sources.backend.temporal.data_imports.sources.snapchat_ads.snapchat_ads.SnapchatStatsResource.setup_stats_resources",
                return_value=_fake_stats_chunks(2),
            ),
            patch(
                "products.warehouse_sources.backend.temporal.data_imports.sources.snapchat_ads.snapchat_ads.fetch_account_metadata",
                return_value=("USD", "America/Los_Angeles"),
            ),
        ):
            list(
                _iter_rows(
                    ad_account_id="acct",
                    endpoint="campaign_stats_daily",
                    team_id=1,
                    job_id="job",
                    access_token="token",
                    resumable_source_manager=manager,
                    db_incremental_field_last_value=None,
                    should_use_incremental_field=False,
                )
            )

        assert len(captured_calls) == 2
        assert captured_calls[0]["initial_paginator_state"] is None
        assert captured_calls[1]["initial_paginator_state"] is None

        saved_configs = [call.args[0] for call in manager.save_state.call_args_list]
        # The resume_hook only persists concrete cursors, so single-page
        # chunks never trigger a save from the hook. The only persisted
        # state is the explicit advance to chunk_index=1 before chunk 1
        # starts. The last chunk has no successor, so no trailing advance.
        assert saved_configs == [
            SnapchatResumeConfig(chunk_index=1, next_link=None),
        ]

    def test_resume_from_second_chunk_skips_first_and_seeds_cursor(self) -> None:
        captured_calls: list[dict[str, Any]] = []

        def _fake_rest_api_resource(*args: Any, **kwargs: Any) -> _FakeResource:
            captured_calls.append(dict(kwargs))
            return _FakeResource(pages=[_stats_page("entity-resumed")], resume_hook=kwargs["resume_hook"])

        saved = SnapchatResumeConfig(
            chunk_index=1,
            next_link="https://adsapi.snapchat.com/v1/stats?chunk=1&cursor=midchunk",
        )
        manager = _mock_resumable_manager(can_resume=True, saved=saved)

        with (
            patch(
                "products.warehouse_sources.backend.temporal.data_imports.sources.snapchat_ads.snapchat_ads.rest_api_resource",
                side_effect=_fake_rest_api_resource,
            ),
            patch(
                "products.warehouse_sources.backend.temporal.data_imports.sources.snapchat_ads.snapchat_ads.SnapchatStatsResource.setup_stats_resources",
                return_value=_fake_stats_chunks(2),
            ),
            patch(
                "products.warehouse_sources.backend.temporal.data_imports.sources.snapchat_ads.snapchat_ads.fetch_account_metadata",
                return_value=("USD", "America/Los_Angeles"),
            ),
        ):
            list(
                _iter_rows(
                    ad_account_id="acct",
                    endpoint="campaign_stats_daily",
                    team_id=1,
                    job_id="job",
                    access_token="token",
                    resumable_source_manager=manager,
                    db_incremental_field_last_value=None,
                    should_use_incremental_field=False,
                )
            )

        # The first chunk is skipped entirely — only one rest_api_resource call.
        assert len(captured_calls) == 1
        assert captured_calls[0]["initial_paginator_state"] == {
            "next_link": "https://adsapi.snapchat.com/v1/stats?chunk=1&cursor=midchunk",
        }


class TestStatsDayBoundaryTimezone:
    """Snapchat's DAY-granularity stats reject date boundaries that aren't the
    start of a day in the ad account's timezone (with the correct DST offset).
    These tests pin the localization that prevents the 400."""

    @parameterized.expand(
        [
            ("summer_pdt", datetime(2025, 7, 15), "America/Los_Angeles", "2025-07-15T00:00:00-07:00"),
            ("winter_pst", datetime(2025, 1, 15), "America/Los_Angeles", "2025-01-15T00:00:00-08:00"),
            ("utc", datetime(2025, 7, 15), "UTC", "2025-07-15T00:00:00+00:00"),
            ("no_timezone_stays_naive", datetime(2025, 7, 15), None, "2025-07-15T00:00:00"),
            ("invalid_timezone_falls_back", datetime(2025, 7, 15), "Not/AZone", "2025-07-15T00:00:00"),
        ]
    )
    def test_format_stats_day_boundary(
        self, _name: str, dt: datetime, account_timezone: Optional[str], expected: str
    ) -> None:
        assert format_stats_day_boundary(dt, account_timezone) == expected

    def test_generate_chunks_localizes_each_boundary_across_dst(self) -> None:
        # A range straddling the spring-forward boundary: each chunk must carry the
        # offset that aligns it to local midnight on its own date, not one fixed
        # offset for the whole range.
        chunks = SnapchatDateRangeManager.generate_chunks(
            "2025-01-01T00:00:00", "2025-08-01T00:00:00", account_timezone="America/Los_Angeles"
        )
        starts = [start for start, _ in chunks]

        assert chunks[0][0] == "2025-01-01T00:00:00-08:00"
        assert any(s.endswith("-08:00") for s in starts)
        assert any(s.endswith("-07:00") for s in starts)
        assert all("T00:00:00" in s for s in starts)

    def test_generate_chunks_naive_without_timezone(self) -> None:
        chunks = SnapchatDateRangeManager.generate_chunks(
            "2025-01-01T00:00:00", "2025-02-01T00:00:00", account_timezone=None
        )
        assert chunks == [("2025-01-01T00:00:00", "2025-02-01T00:00:00")]


class TestNonRetryableErrors:
    _patterns = SnapchatAdsSource().get_non_retryable_errors()

    @parameterized.expand(
        [
            # Real requests HTTPError strings from Snapchat's Marketing API.
            "404 Client Error: Not Found for url: https://adsapi.snapchat.com/v1/adaccounts/abc/stats",
            "401 Client Error: Unauthorized for url: https://adsapi.snapchat.com/v1/adaccounts/abc/stats",
            "403 Client Error: Forbidden for url: https://adsapi.snapchat.com/v1/adaccounts/abc/stats",
        ]
    )
    def test_permanent_client_errors_are_non_retryable(self, error_msg: str) -> None:
        assert any(pattern in error_msg for pattern in self._patterns), (
            f"Snapchat error '{error_msg}' did not match any non-retryable pattern"
        )

    @parameterized.expand(
        [
            "500 Server Error: Internal Server Error for url: https://adsapi.snapchat.com/v1/stats",
            "429 Client Error: Too Many Requests for url: https://adsapi.snapchat.com/v1/stats",
        ]
    )
    def test_transient_errors_stay_retryable(self, error_msg: str) -> None:
        assert not any(pattern in error_msg for pattern in self._patterns), (
            f"Snapchat error '{error_msg}' should remain retryable"
        )


class TestListAdAccounts:
    _MODULE = "products.warehouse_sources.backend.temporal.data_imports.sources.snapchat_ads.utils"

    def test_flattens_accounts_and_pairs_with_organization_name(self) -> None:
        body = {
            "organizations": [
                {
                    "sub_request_status": "SUCCESS",
                    "organization": {
                        "name": "PostHog",
                        "ad_accounts": [
                            {"id": "acc-1", "name": "PostHog Self Service", "status": "PENDING"},
                            {"id": "acc-2", "name": "PostHog", "status": "ACTIVE"},
                        ],
                    },
                },
                # A failed sub-request contributes no accounts.
                {"sub_request_status": "ERROR", "organization": {"name": "Broken", "ad_accounts": [{"id": "x"}]}},
            ]
        }
        response = MagicMock()
        response.json.return_value = body
        session = MagicMock()
        session.get.return_value = response

        with patch(f"{self._MODULE}.make_tracked_session", return_value=session):
            result = list_ad_accounts("token")

        assert [(account["id"], org_name) for account, org_name in result] == [
            ("acc-1", "PostHog"),
            ("acc-2", "PostHog"),
        ]
        assert session.get.call_args.kwargs["params"] == {
            "with_ad_accounts": "true",
            "limit": AD_ACCOUNTS_PAGE_LIMIT,
        }

    @staticmethod
    def _organizations_page(name: str, account_id: str, next_link: str | None = None) -> dict:
        page: dict = {
            "request_status": "SUCCESS",
            "organizations": [
                {
                    "sub_request_status": "SUCCESS",
                    "organization": {"name": name, "ad_accounts": [{"id": account_id, "name": account_id}]},
                }
            ],
        }
        if next_link:
            page["paging"] = {"next_link": next_link}
        return page

    def _session_returning(self, *bodies: dict) -> MagicMock:
        responses = []
        for body in bodies:
            response = MagicMock()
            response.json.return_value = body
            responses.append(response)
        session = MagicMock()
        session.get.side_effect = responses
        return session

    def test_follows_next_link_until_exhausted(self) -> None:
        # A single page would silently truncate the picker for an org with more accounts than fit
        # in one page — the user's account just wouldn't be there, with no error.
        next_link = "https://adsapi.snapchat.com/v1/me/organizations?with_ad_accounts=true&cursor=page-2"
        session = self._session_returning(
            self._organizations_page("PostHog", "acc-1", next_link=next_link),
            self._organizations_page("Agency", "acc-2"),
        )

        with patch(f"{self._MODULE}.make_tracked_session", return_value=session):
            result = list_ad_accounts("token")

        assert [(account["id"], org_name) for account, org_name in result] == [
            ("acc-1", "PostHog"),
            ("acc-2", "Agency"),
        ]
        assert session.get.call_count == 2
        # The second request follows next_link verbatim: it already carries the cursor and the query.
        assert session.get.call_args_list[1].args[0] == next_link
        assert session.get.call_args_list[1].kwargs["params"] is None

    def test_in_body_failure_raises_actionable_error(self) -> None:
        # A 200 whose body reports failure would otherwise fall through to an empty picker.
        session = self._session_returning(
            {"request_status": "ERROR", "debug_message": "Invalid scope", "display_message": "Something went wrong"}
        )

        with (
            patch(f"{self._MODULE}.make_tracked_session", return_value=session),
            pytest.raises(IntegrationAccountListingError, match="Invalid scope"),
        ):
            list_ad_accounts("token")

    def test_all_organizations_failing_raises_instead_of_returning_empty(self) -> None:
        session = self._session_returning(
            {
                "request_status": "SUCCESS",
                "organizations": [
                    {"sub_request_status": "ERROR", "organization": {"name": "Broken", "ad_accounts": []}}
                ],
            }
        )

        with (
            patch(f"{self._MODULE}.make_tracked_session", return_value=session),
            pytest.raises(IntegrationAccountListingError),
        ):
            list_ad_accounts("token")

    def test_no_organizations_returns_empty_list(self) -> None:
        session = self._session_returning({"request_status": "SUCCESS", "organizations": []})

        with patch(f"{self._MODULE}.make_tracked_session", return_value=session):
            assert list_ad_accounts("token") == []

    def test_page_cap_raises_instead_of_returning_partial(self) -> None:
        # A looping/oversized next_link must fail closed rather than return the accounts collected so
        # far as if complete — that would silently present a truncated (or cursor-duplicated) picker.
        response = MagicMock()
        response.json.return_value = self._organizations_page(
            "PostHog", "acc-1", next_link="https://adsapi.snapchat.com/v1/me/organizations?cursor=loop"
        )
        session = MagicMock()
        session.get.return_value = response

        with (
            patch(f"{self._MODULE}.make_tracked_session", return_value=session),
            pytest.raises(IntegrationAccountListingError, match="too many pages"),
        ):
            list_ad_accounts("token")

        assert session.get.call_count == MAX_AD_ACCOUNT_PAGES

    @parameterized.expand(
        [
            ("cross_origin_host", "https://evil.example.com/v1/me/organizations?with_ad_accounts=true&cursor=page-2"),
            (
                "non_https_same_host",
                "http://adsapi.snapchat.com/v1/me/organizations?with_ad_accounts=true&cursor=page-2",
            ),
        ]
    )
    def test_rejects_untrusted_pagination_link_without_following_it(self, _name: str, next_link: str) -> None:
        # The bearer token rides on each pagination request, so a next_link off Snapchat's HTTPS API
        # host must be rejected before we re-attach the token to it.
        session = self._session_returning(
            self._organizations_page("PostHog", "acc-1", next_link=next_link),
            self._organizations_page("Agency", "acc-2"),
        )

        with (
            patch(f"{self._MODULE}.make_tracked_session", return_value=session),
            pytest.raises(IntegrationAccountListingError),
        ):
            list_ad_accounts("token")

        # The token-bearing request to the untrusted host is never made.
        assert session.get.call_count == 1


def _breakdown_page(entity_id: str, breakdown_key: str, entries: list[dict[str, Any]]) -> list[dict[str, Any]]:
    return [
        {
            "timeseries_stat": {
                "breakdown_stats": {
                    breakdown_key: [
                        {
                            "id": entity_id,
                            "type": breakdown_key.upper(),
                            "start_time": "2026-04-01T00:00:00-07:00",
                            "end_time": "2026-04-03T00:00:00-07:00",
                            "timeseries": entries,
                        }
                    ]
                }
            }
        }
    ]


class TestStatsDimensionTransform:
    def test_dimension_stats_expand_to_one_row_per_dimension_value(self) -> None:
        # A `report_dimension` response replaces the day's `stats` object with a
        # `dimension_stats` array. Reading only `stats` would sync the breakdown tables empty.
        page = _breakdown_page(
            "campaign-1",
            "campaign",
            [
                {
                    "start_time": "2026-04-01T00:00:00-07:00",
                    "end_time": "2026-04-02T00:00:00-07:00",
                    "dimension_stats": [
                        {"impressions": 10, "swipes": 1, "country": "us"},
                        {"impressions": 4, "swipes": 0, "country": "gb"},
                    ],
                },
                {
                    "start_time": "2026-04-02T00:00:00-07:00",
                    "end_time": "2026-04-03T00:00:00-07:00",
                    "dimension_stats": [{"impressions": 7, "swipes": 2, "country": "us"}],
                },
            ],
        )

        rows = SnapchatStatsResource.transform_stats_reports(page, currency="USD")

        assert rows == [
            {
                "id": "campaign-1",
                "type": "CAMPAIGN",
                "start_time": "2026-04-01T00:00:00-07:00",
                "end_time": "2026-04-02T00:00:00-07:00",
                "impressions": 10,
                "swipes": 1,
                "country": "us",
                "currency": "USD",
            },
            {
                "id": "campaign-1",
                "type": "CAMPAIGN",
                "start_time": "2026-04-01T00:00:00-07:00",
                "end_time": "2026-04-02T00:00:00-07:00",
                "impressions": 4,
                "swipes": 0,
                "country": "gb",
                "currency": "USD",
            },
            {
                "id": "campaign-1",
                "type": "CAMPAIGN",
                "start_time": "2026-04-02T00:00:00-07:00",
                "end_time": "2026-04-03T00:00:00-07:00",
                "impressions": 7,
                "swipes": 2,
                "country": "us",
                "currency": "USD",
            },
        ]

    def test_totals_rows_still_read_the_stats_object(self) -> None:
        # The existing totals tables must keep flattening `stats` unchanged.
        page = _breakdown_page(
            "adsquad-1",
            "adsquad",
            [
                {
                    "start_time": "2026-04-01T00:00:00-07:00",
                    "end_time": "2026-04-02T00:00:00-07:00",
                    "stats": {"impressions": 21, "spend": 500},
                }
            ],
        )

        assert SnapchatStatsResource.transform_stats_reports(page) == [
            {
                "id": "adsquad-1",
                "type": "ADSQUAD",
                "start_time": "2026-04-01T00:00:00-07:00",
                "end_time": "2026-04-02T00:00:00-07:00",
                "impressions": 21,
                "spend": 500,
            }
        ]

    def test_entity_level_dimension_stats_are_kept_and_dated_from_the_entity(self) -> None:
        # Snapchat only documents delivery insights at TOTAL granularity, where the breakdown
        # hangs off the entity with no `timeseries`. Those rows must not be silently dropped.
        page = _breakdown_page("ad-1", "ad", [])
        page[0]["timeseries_stat"]["breakdown_stats"]["ad"][0]["dimension_stats"] = [
            {"impressions": 9, "age_bucket": "25-34", "gender": "female"}
        ]

        assert SnapchatStatsResource.transform_stats_reports(page) == [
            {
                "id": "ad-1",
                "type": "AD",
                "start_time": "2026-04-01T00:00:00-07:00",
                "end_time": "2026-04-03T00:00:00-07:00",
                "impressions": 9,
                "age_bucket": "25-34",
                "gender": "female",
            }
        ]


class TestEntityUnwrapping:
    @parameterized.expand(
        [
            ("creative", "creatives"),
            ("media", "media"),
            ("segment", "audience_segments"),
            ("pixel", "pixels"),
            ("adaccount", "ad_accounts"),
        ]
    )
    def test_configured_entity_key_unwraps_the_object(self, wrapper_key: str, endpoint: str) -> None:
        # Snapchat wraps each list item in a singular key that differs per endpoint. Without the
        # configured key these tables would store the wrapper instead of the object.
        assert SNAPCHAT_ADS_CONFIG[endpoint].entity_key == wrapper_key

        rows = SnapchatStatsResource.apply_stream_transformations(
            EndpointType.ENTITY,
            [{"sub_request_status": "SUCCESS", wrapper_key: {"id": "obj-1", "name": "Object"}}],
            entity_key=wrapper_key,
        )

        assert rows == [{"id": "obj-1", "name": "Object"}]

    def test_campaign_style_wrappers_still_unwrap_without_a_configured_key(self) -> None:
        rows = SnapchatStatsResource.apply_stream_transformations(
            EndpointType.ENTITY,
            [{"sub_request_status": "SUCCESS", "campaign": {"id": "c-1"}}],
        )

        assert rows == [{"id": "c-1"}]


class TestBreakdownEndpointConfig:
    _DIMENSION_COLUMNS = {"country": ["country"], "age,gender": ["age_bucket", "gender"]}

    @parameterized.expand(
        [
            "campaign_stats_daily_country",
            "campaign_stats_daily_demographics",
            "ad_stats_daily_country",
            "ad_stats_daily_demographics",
        ]
    )
    def test_primary_key_covers_the_requested_dimension(self, endpoint: str) -> None:
        # A breakdown row is only unique per entity, day, and dimension value. Dropping the
        # dimension from the key collapses every country (or age/gender) onto one row on merge.
        config = SNAPCHAT_ADS_CONFIG[endpoint]
        params = cast(dict[str, Any], config.resource["endpoint"])["params"]
        report_dimension = cast(str, params["report_dimension"])

        assert config.resource["primary_key"] == [
            "id",
            "start_time",
            *self._DIMENSION_COLUMNS[report_dimension],
        ]


class TestSchemaDefaults:
    def test_breakdown_tables_are_opt_in_and_the_rest_stay_on(self) -> None:
        # Breakdown tables multiply every day by its dimension values, so they must not be
        # pre-selected for every new connection.
        schemas = SnapchatAdsSource().get_schemas(config=MagicMock(), team_id=1)
        by_name = {schema.name: schema.should_sync_default for schema in schemas}

        assert by_name == {
            "campaigns": True,
            "ad_squads": True,
            "ads": True,
            "ad_accounts": True,
            "creatives": True,
            "media": True,
            "audience_segments": True,
            "pixels": True,
            "campaign_stats_daily": True,
            "ad_squad_stats_daily": True,
            "ad_stats_daily": True,
            "campaign_stats_daily_country": False,
            "campaign_stats_daily_demographics": False,
            "ad_stats_daily_country": False,
            "ad_stats_daily_demographics": False,
        }


class TestPaginatorRequestStatus:
    @parameterized.expand(["SUCCESS", "success"])
    def test_next_link_is_followed_whatever_the_case_of_request_status(self, request_status: str) -> None:
        # Snapchat's docs show this status in both cases across endpoints; a case-sensitive
        # check would fail the sync on the endpoints that report it lowercase.
        response = MagicMock()
        response.status_code = 200
        response.json.return_value = {
            "request_status": request_status,
            "paging": {"next_link": "https://adsapi.snapchat.com/v1/adaccounts/a/creatives?cursor=abc"},
        }

        paginator = SnapchatAdsPaginator()
        paginator.update_state(response)

        assert paginator.get_resume_state() == {
            "next_link": "https://adsapi.snapchat.com/v1/adaccounts/a/creatives?cursor=abc"
        }
