from typing import Optional, cast

from posthog.schema import (
    DataWarehouseSourceCategory,
    ExternalDataSourceType as SchemaExternalDataSourceType,
    ReleaseStatus,
    SourceConfig,
    SourceFieldInputConfig,
    SourceFieldInputConfigType,
)

from products.warehouse_sources.backend.temporal.data_imports.sources.common.base import FieldType, ResumableSource
from products.warehouse_sources.backend.temporal.data_imports.sources.common.canonical_descriptions import (
    CanonicalDescriptions,
)
from products.warehouse_sources.backend.temporal.data_imports.sources.common.registry import SourceRegistry
from products.warehouse_sources.backend.temporal.data_imports.sources.common.resumable import ResumableSourceManager
from products.warehouse_sources.backend.temporal.data_imports.sources.common.schema import SourceSchema
from products.warehouse_sources.backend.temporal.data_imports.sources.common.typings import SourceInputs, SourceResponse
from products.warehouse_sources.backend.temporal.data_imports.sources.generated_configs.oncehub import (
    OncehubSourceConfig,
)
from products.warehouse_sources.backend.temporal.data_imports.sources.oncehub.oncehub import (
    OncehubResumeConfig,
    oncehub_source,
    validate_credentials,
)
from products.warehouse_sources.backend.temporal.data_imports.sources.oncehub.settings import (
    ENDPOINTS,
    ONCEHUB_ENDPOINTS,
)
from products.warehouse_sources.backend.types import ExternalDataSourceType


@SourceRegistry.register
class OncehubSource(ResumableSource[OncehubSourceConfig, OncehubResumeConfig]):
    lists_tables_without_credentials = True  # static endpoint catalog — safe for public docs
    supported_versions = ("v2",)
    default_version = "v2"
    api_docs_url = "https://developers.oncehub.com/reference/booking-calendars"

    @property
    def source_type(self) -> ExternalDataSourceType:
        return ExternalDataSourceType.ONCEHUB

    @property
    def get_source_config(self) -> SourceConfig:
        return SourceConfig(
            name=SchemaExternalDataSourceType.ONCEHUB,
            category=DataWarehouseSourceCategory.PRODUCTIVITY,
            label="OnceHub",
            releaseStatus=ReleaseStatus.ALPHA,
            keywords=["scheduleonce", "scheduling", "booking"],
            caption="""Enter your OnceHub API key to pull your scheduling and booking data into the PostHog Data warehouse.

You can generate an API key in [OnceHub](https://app.oncehub.com) under **Settings → API & Webhooks**. The key is shown only once at creation, so copy it right away. It grants read access to your bookings, booking calendars, contacts, users, and teams.
""",
            iconPath="/static/services/oncehub.png",
            docsUrl="https://posthog.com/docs/cdp/sources/oncehub",
            fields=cast(
                list[FieldType],
                [
                    SourceFieldInputConfig(
                        name="api_key",
                        label="API key",
                        type=SourceFieldInputConfigType.PASSWORD,
                        required=True,
                        placeholder="",
                        secret=True,
                    ),
                ],
            ),
        )

    def get_canonical_descriptions(self) -> CanonicalDescriptions:
        from products.warehouse_sources.backend.temporal.data_imports.sources.oncehub.canonical_descriptions import (  # noqa: PLC0415
            CANONICAL_DESCRIPTIONS,
        )

        return CANONICAL_DESCRIPTIONS

    def get_non_retryable_errors(self) -> dict[str, str | None]:
        return {
            "401 Client Error: Unauthorized for url: https://api.oncehub.com": "Your OnceHub API key is invalid or has been revoked. Generate a new key under Settings → API & Webhooks, then reconnect.",
            "403 Client Error: Forbidden for url: https://api.oncehub.com": "Your OnceHub API key does not have access to this data. Check the key's permissions, then reconnect.",
        }

    def get_schemas(
        self,
        config: OncehubSourceConfig,
        team_id: int,
        with_counts: bool = False,
        names: list[str] | None = None,
        force_refresh: bool = False,
        api_version: str | None = None,
    ) -> list[SourceSchema]:
        # Every endpoint is full refresh only — OnceHub's `last_updated_time.gt` filters are
        # date-granular and cursor pagination returns newest-first, so there is no reliable
        # server-side incremental cursor to advance.
        schemas = [
            SourceSchema(
                name=endpoint,
                supports_incremental=False,
                supports_append=False,
                incremental_fields=[],
            )
            for endpoint in ENDPOINTS
        ]
        if names is not None:
            names_set = set(names)
            schemas = [s for s in schemas if s.name in names_set]
        return schemas

    def validate_credentials(
        self,
        config: OncehubSourceConfig,
        team_id: int,
        schema_name: Optional[str] = None,
        api_version: str | None = None,
    ) -> tuple[bool, str | None]:
        # The API key is account-wide, so a single probe validates access to every schema.
        return validate_credentials(config.api_key)

    def get_resumable_source_manager(self, inputs: SourceInputs) -> ResumableSourceManager[OncehubResumeConfig]:
        return ResumableSourceManager[OncehubResumeConfig](inputs, OncehubResumeConfig)

    def source_for_pipeline(
        self,
        config: OncehubSourceConfig,
        resumable_source_manager: ResumableSourceManager[OncehubResumeConfig],
        inputs: SourceInputs,
    ) -> SourceResponse:
        if inputs.schema_name not in ONCEHUB_ENDPOINTS:
            raise ValueError(f"Unknown OnceHub schema '{inputs.schema_name}'")

        return oncehub_source(
            api_key=config.api_key,
            endpoint=inputs.schema_name,
            team_id=inputs.team_id,
            job_id=inputs.job_id,
            resumable_source_manager=resumable_source_manager,
            db_incremental_field_last_value=None,  # every OnceHub endpoint is full refresh
        )
