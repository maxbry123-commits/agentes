from types import SimpleNamespace

import pytest
from freezegun import freeze_time
from unittest import mock

from dateutil import parser
from google.api_core.exceptions import (
    BadRequest,
    DeadlineExceeded,
    Forbidden,
    InternalServerError,
    InvalidArgument,
    NotFound,
    PermissionDenied,
    ServiceUnavailable,
)
from google.auth.exceptions import RefreshError

from products.warehouse_sources.backend.temporal.data_imports.sources.bigquery import bigquery as bq_module
from products.warehouse_sources.backend.temporal.data_imports.sources.bigquery.bigquery import (
    BIGQUERY_CREATE_READ_SESSION_RETRY,
    BIGQUERY_CREDENTIALS_REJECTED_ERROR,
    BIGQUERY_DATASET_NOT_FOUND_ERROR,
    BIGQUERY_INVALID_IDENTIFIER_ERROR,
    BIGQUERY_INVALID_KEY_FILE_ERROR,
    BIGQUERY_MISSING_KEY_FILE_FIELDS_ERROR,
    BIGQUERY_QUERY_CREATE_RETRY,
    BIGQUERY_QUERY_JOB_RETRY,
    BIGQUERY_READ_ROWS_RETRY,
    BIGQUERY_TOKEN_RESPONSE_ERROR,
    BIGQUERY_VALIDATION_GENERIC_ERROR,
    BIGQUERY_VALIDATION_PERMISSION_DENIED_ERROR,
    BigQueryCredentialsRejectedError,
    BigQueryDatasetNotFoundError,
    BigQueryImplementation,
    BigQueryInvalidIdentifierError,
    BigQueryTokenRefreshError,
    _bq_select_clause,
    _get_primary_keys_for_table,
    _get_query,
    _get_rows_to_sync,
    _has_duplicate_primary_keys,
    _is_transient_job_not_found,
    _query_result_with_job_retry,
    _resolve_dataset_id,
    _resolve_dataset_project_id,
    _resolve_project_id,
    _resolve_query_project,
    _resolve_region,
    _run_destination_query_with_job_retry,
    delete_all_temp_destination_tables,
    validate_bigquery_credentials,
)
from products.warehouse_sources.backend.temporal.data_imports.sources.bigquery.source import BigQuerySource
from products.warehouse_sources.backend.temporal.data_imports.sources.common.sql.identifiers import (
    InvalidIdentifierError,
)
from products.warehouse_sources.backend.temporal.data_imports.sources.common.sql.predicates import (
    ColumnTypeCategory,
    ValidatedRowFilter,
)
from products.warehouse_sources.backend.temporal.data_imports.sources.common.typings import SourceInputs
from products.warehouse_sources.backend.temporal.data_imports.sources.generated_configs.bigquery import (
    BigQueryDatasetProjectConfig,
    BigQueryKeyFileConfig,
    BigQuerySourceConfig,
    BigQueryTemporaryDatasetConfig,
    BigQueryUseCustomRegionConfig,
)
from products.warehouse_sources.backend.types import IncrementalFieldType


def _make_inputs(**overrides) -> SourceInputs:
    defaults: dict = {
        "schema_name": "schema",
        "schema_id": "schema-id",
        "source_id": "source-id",
        "team_id": 1,
        "should_use_incremental_field": False,
        "db_incremental_field_last_value": None,
        "db_incremental_field_earliest_value": None,
        "incremental_field": None,
        "incremental_field_type": None,
        "job_id": "job-id",
        "logger": mock.MagicMock(),
        "reset_pipeline": False,
    }
    defaults.update(overrides)
    return SourceInputs(**defaults)


def _make_config(
    *,
    project_id: str = "project-id",
    dataset_id: str = "dataset-id",
    dataset_project: BigQueryDatasetProjectConfig | None = None,
    temporary_dataset: BigQueryTemporaryDatasetConfig | None = None,
    use_custom_region: BigQueryUseCustomRegionConfig | None = None,
) -> BigQuerySourceConfig:
    return BigQuerySourceConfig(
        key_file=BigQueryKeyFileConfig(
            project_id=project_id,
            private_key="private-key",
            private_key_id="private-key-id",
            client_email="client-email",
            token_uri="token-uri",
        ),
        dataset_id=dataset_id,
        dataset_project=dataset_project,
        temporary_dataset=temporary_dataset,
        use_custom_region=use_custom_region,
    )


def test_bigquery_get_columns_filters_existing_destination_tables():
    """`get_columns` strips `__posthog_import_*` tables before returning."""
    fake_client = mock.MagicMock()
    fake_row_keep = mock.MagicMock(table_name="table", column_name="c", data_type="STRING", is_nullable="NO")
    fake_row_skip = mock.MagicMock(
        table_name="__posthog_import_0000_0000", column_name="c", data_type="STRING", is_nullable="NO"
    )
    fake_client.query.return_value.result.return_value = [fake_row_keep, fake_row_skip]

    columns = BigQueryImplementation().get_columns(fake_client, _make_config(), names=None)
    assert list(columns.keys()) == ["table"]


def test_bigquery_get_columns_returns_empty_when_job_create_forbidden():
    """A service account without `bigquery.jobs.create` raises `Forbidden` from
    `client.query()` (which eagerly creates the job), not from `result()`. That must
    degrade to no schemas rather than crashing schema discovery."""
    fake_client = mock.MagicMock()
    fake_client.query.side_effect = Forbidden(
        "Access Denied: Project p: User does not have bigquery.jobs.create permission in project p."
    )

    columns = BigQueryImplementation().get_columns(fake_client, _make_config(), names=None)
    assert columns == {}


@pytest.mark.parametrize(
    "error_message,expected_type,is_token_refresh",
    [
        # A bad OAuth token endpoint makes google-auth raise this opaque `TypeError` during the
        # lazy token refresh — `get_columns` must surface a clear, non-retryable error instead.
        ("string indices must be integers, not 'str'", BigQueryTokenRefreshError, True),
        # Any other `TypeError` indicates a genuine bug and must propagate unchanged.
        ("unrelated bug", TypeError, False),
    ],
)
def test_bigquery_get_columns_typeerror_handling(error_message, expected_type, is_token_refresh):
    """Token-refresh `TypeError`s are wrapped as `BigQueryTokenRefreshError`; others propagate."""
    fake_client = mock.MagicMock()
    fake_client.query.side_effect = TypeError(error_message)

    with pytest.raises(expected_type) as exc_info:
        BigQueryImplementation().get_columns(fake_client, _make_config(), names=None)

    assert isinstance(exc_info.value, BigQueryTokenRefreshError) == is_token_refresh
    if is_token_refresh:
        # The raised message must carry the stable marker registered as non-retryable.
        assert BIGQUERY_TOKEN_RESPONSE_ERROR in str(exc_info.value)
        assert BIGQUERY_TOKEN_RESPONSE_ERROR in BigQuerySource().get_non_retryable_errors()
    else:
        assert error_message in str(exc_info.value)


def test_bigquery_get_columns_raises_friendly_error_when_dataset_not_found():
    """A missing dataset/table surfaces as a raw google `NotFound` from `client.query()`. Schema
    discovery must re-raise it with actionable wording instead of leaking BigQuery job internals,
    and that wording must stay registered as non-retryable."""
    fake_client = mock.MagicMock()
    fake_client.query.side_effect = NotFound(
        "404 Not found: Dataset prj:ds was not found in location US Job ID: b3abc342-16a7"
    )

    with pytest.raises(BigQueryDatasetNotFoundError) as exc_info:
        BigQueryImplementation().get_columns(fake_client, _make_config(), names=None)

    assert str(exc_info.value) == BIGQUERY_DATASET_NOT_FOUND_ERROR
    # The raw 404 (job id, location internals) must not survive into the message.
    assert "Job ID" not in str(exc_info.value)
    assert BIGQUERY_DATASET_NOT_FOUND_ERROR in BigQuerySource().get_non_retryable_errors()


@pytest.mark.parametrize(
    "phrase", ['Invalid dataset ID "(default)"', 'Invalid project ID "bad id"', "ProjectId must be non-empty"]
)
def test_bigquery_get_columns_raises_friendly_error_for_invalid_identifier(phrase):
    """A syntactically invalid project/dataset ID surfaces as a raw 400 `BadRequest` from
    `client.query()`. Schema discovery must re-raise it with actionable wording instead of leaking
    the offending value and BigQuery job internals, and that wording must stay non-retryable."""
    fake_client = mock.MagicMock()
    fake_client.query.side_effect = BadRequest(
        f"400 {phrase}. Dataset IDs must be alphanumeric. Location: US Job ID: f2bf3ba8-4c4b"
    )

    with pytest.raises(BigQueryInvalidIdentifierError) as exc_info:
        BigQueryImplementation().get_columns(fake_client, _make_config(), names=None)

    assert str(exc_info.value) == BIGQUERY_INVALID_IDENTIFIER_ERROR
    # The raw 400 (offending id, job id) must not survive into the message.
    assert "Job ID" not in str(exc_info.value)
    assert "(default)" not in str(exc_info.value)
    assert BIGQUERY_INVALID_IDENTIFIER_ERROR in BigQuerySource().get_non_retryable_errors()


def test_bigquery_get_columns_propagates_unrelated_bad_request():
    """A BadRequest that isn't an invalid-identifier error (e.g. a malformed query) must propagate
    unchanged rather than being mislabeled as an invalid project/dataset ID."""
    fake_client = mock.MagicMock()
    fake_client.query.side_effect = BadRequest("400 Syntax error: Unexpected keyword SELECT")

    with pytest.raises(BadRequest):
        BigQueryImplementation().get_columns(fake_client, _make_config(), names=None)


@pytest.mark.parametrize(
    "error_message,expected_type,is_rejected",
    [
        # An `invalid_grant` RefreshError means Google rejected the service-account grant (rotated
        # key, deleted account). `get_columns` must surface a clear message instead of the tuple repr.
        (
            "('invalid_grant: Invalid JWT Signature.', {'error': 'invalid_grant', 'error_description': 'Invalid JWT Signature.'})",
            BigQueryCredentialsRejectedError,
            True,
        ),
        # Transient/other RefreshErrors carry their own diagnoses and must propagate unchanged.
        ("('Failed to retrieve token', {'error': 'internal_failure'})", RefreshError, False),
    ],
)
def test_bigquery_get_columns_refresh_error_handling(error_message, expected_type, is_rejected):
    """`invalid_grant` RefreshErrors are wrapped as `BigQueryCredentialsRejectedError`; others propagate."""
    fake_client = mock.MagicMock()
    fake_client.query.side_effect = RefreshError(error_message)

    with pytest.raises(expected_type) as exc_info:
        BigQueryImplementation().get_columns(fake_client, _make_config(), names=None)

    assert isinstance(exc_info.value, BigQueryCredentialsRejectedError) == is_rejected
    if is_rejected:
        # The wizard shows this str() directly, and it must keep the `invalid_grant` marker so the
        # sync schema-discovery path still recognises it as non-retryable.
        assert "invalid_grant" in str(exc_info.value)
        assert "rejected by Google" in str(exc_info.value)
        assert any(key in str(exc_info.value) for key in BigQuerySource().get_non_retryable_errors())


@pytest.mark.parametrize(
    "dataset_project,temporary_dataset,expected_dataset_project_id,expected_destination_dataset_id",
    [
        # default — no dataset_project, no temporary_dataset
        (None, None, None, "dataset-id"),
        # dataset_project enabled — propagated through both delete_all and _build_source_response
        (
            BigQueryDatasetProjectConfig(dataset_project_id="other-project-id", enabled=True),
            None,
            "other-project-id",
            "dataset-id",
        ),
        # temporary_dataset enabled — overrides destination_table_dataset_id
        (
            None,
            BigQueryTemporaryDatasetConfig(temporary_dataset_id="some-other-dataset-id", enabled=True),
            None,
            "some-other-dataset-id",
        ),
        # both set — temporary_dataset wins for destination, dataset_project still resolved
        (
            BigQueryDatasetProjectConfig(dataset_project_id="other-project-id", enabled=True),
            BigQueryTemporaryDatasetConfig(temporary_dataset_id="some-other-dataset-id", enabled=True),
            "other-project-id",
            "some-other-dataset-id",
        ),
    ],
)
def test_bigquery_build_pipeline_resolves_dataset_routing(
    dataset_project, temporary_dataset, expected_dataset_project_id, expected_destination_dataset_id
):
    config = _make_config(dataset_project=dataset_project, temporary_dataset=temporary_dataset)
    expected_table_id = (
        f"project-id.{expected_destination_dataset_id}.__posthog_import_schema_id_job_id_"
        f"{str(parser.parse('2025-01-01T12:00:00.000Z').timestamp()).replace('.', '')}"
    )

    with (
        freeze_time("2025-01-01T12:00:00.000Z"),
        mock.patch(
            "products.warehouse_sources.backend.temporal.data_imports.sources.bigquery.bigquery.delete_all_temp_destination_tables",
        ) as mock_delete_all,
        mock.patch.object(
            BigQueryImplementation, "_build_source_response", return_value=mock.MagicMock()
        ) as mock_build,
        mock.patch(
            "products.warehouse_sources.backend.temporal.data_imports.sources.bigquery.bigquery.delete_table",
        ) as mock_delete,
    ):
        BigQuerySource().source_for_pipeline(config, _make_inputs())

    assert mock_delete_all.call_args.kwargs["dataset_id"] == expected_destination_dataset_id
    assert mock_delete_all.call_args.kwargs["dataset_project_id"] == expected_dataset_project_id
    assert mock_delete_all.call_args.kwargs["table_prefix"] == "__posthog_import_schema_id"

    assert mock_build.call_args.kwargs["dataset_project_id"] == expected_dataset_project_id
    assert mock_build.call_args.kwargs["bq_destination_table_id"] == expected_table_id

    assert mock_delete.call_args.kwargs["table_id"] == expected_table_id


def test_bigquery_build_pipeline_swallows_transient_cleanup_refresh_error():
    """A transient token-refresh failure (e.g. a 502 from Google's OAuth endpoint) while deleting
    the run's own destination table must not turn an otherwise-successful sync into a failure —
    retrying the whole sync just to retry this delete is wasteful."""
    config = _make_config()
    logger = mock.MagicMock()
    inputs = _make_inputs(logger=logger)
    build_result = mock.MagicMock()

    with (
        mock.patch(
            "products.warehouse_sources.backend.temporal.data_imports.sources.bigquery.bigquery.delete_all_temp_destination_tables",
        ),
        mock.patch.object(BigQueryImplementation, "_build_source_response", return_value=build_result),
        mock.patch(
            "products.warehouse_sources.backend.temporal.data_imports.sources.bigquery.bigquery.delete_table",
            side_effect=RefreshError(
                "<!DOCTYPE html><html><head><title>Error 502 (Server Error)</title></head></html>"
            ),
        ),
    ):
        result = BigQuerySource().source_for_pipeline(config, inputs)

    assert result is build_result
    logger.warning.assert_called_once()


@pytest.mark.parametrize(
    "exception",
    [
        # A genuine permission denial must keep propagating: this table holds a real materialized
        # copy of the customer's data, so swallowing it here would let readable copies accumulate
        # on every run instead of the sync failing via the "Access Denied:" non-retryable key.
        Forbidden("Access Denied: Permission bigquery.tables.delete denied on table"),
        # `invalid_grant` (rejected credentials) is not transient and must reach the sync-path
        # classifier rather than being silently swallowed as a routine refresh hiccup.
        RefreshError(("invalid_grant: Invalid JWT Signature.", {"error": "invalid_grant"})),
        RuntimeError("boom"),
    ],
)
def test_bigquery_build_pipeline_propagates_unexpected_cleanup_errors(exception):
    """Only a transient (non-`invalid_grant`) `RefreshError` is treated as best-effort during
    destination-table cleanup — anything else, including permission denials and rejected
    credentials, must still surface."""
    config = _make_config()
    inputs = _make_inputs()

    with (
        mock.patch(
            "products.warehouse_sources.backend.temporal.data_imports.sources.bigquery.bigquery.delete_all_temp_destination_tables",
        ),
        mock.patch.object(BigQueryImplementation, "_build_source_response", return_value=mock.MagicMock()),
        mock.patch(
            "products.warehouse_sources.backend.temporal.data_imports.sources.bigquery.bigquery.delete_table",
            side_effect=exception,
        ),
        pytest.raises(type(exception)),
    ):
        BigQuerySource().source_for_pipeline(config, inputs)


@pytest.mark.parametrize(
    "enabled_columns,primary_keys,incremental_field,expected",
    [
        (None, ["id"], None, "*"),
        (["email"], ["id"], None, "`email`, `id`"),
        (["email"], ["id"], "created_at", "`email`, `id`, `created_at`"),
        ([], None, None, "*"),
        ([], ["id"], None, "`id`"),
    ],
)
def test_bigquery_select_clause(enabled_columns, primary_keys, incremental_field, expected):
    assert _bq_select_clause(enabled_columns, primary_keys, incremental_field) == expected


def test_bigquery_get_query_projects_enabled_columns():
    bq_table = mock.MagicMock(dataset_id="ds", table_id="t")
    query, params = _get_query(
        should_use_incremental_field=False,
        db_incremental_field_last_value=None,
        bq_table=bq_table,
        enabled_columns=["email"],
        primary_keys=["id"],
    )
    assert "SELECT `email`, `id` FROM" in query
    assert params == []


def test_bigquery_get_query_keeps_incremental_field_in_projection():
    bq_table = mock.MagicMock(dataset_id="ds", table_id="t")
    query, params = _get_query(
        should_use_incremental_field=True,
        db_incremental_field_last_value=42,
        bq_table=bq_table,
        incremental_field="updated_at",
        incremental_field_type=IncrementalFieldType.Integer,
        enabled_columns=["email"],
        primary_keys=["id"],
    )
    assert "SELECT `email`, `id`, `updated_at` FROM" in query
    assert "WHERE `updated_at` > 42" in query
    assert params == []


def test_bigquery_get_query_binds_row_filters_as_parameters():
    bq_table = mock.MagicMock(dataset_id="ds", table_id="t")
    bq_table.schema = [
        SimpleNamespace(name="age", field_type="INTEGER"),
        SimpleNamespace(name="name", field_type="STRING"),
    ]
    query, params = _get_query(
        should_use_incremental_field=False,
        db_incremental_field_last_value=None,
        bq_table=bq_table,
        row_filters=[
            ValidatedRowFilter(column="age", operator=">", value=21, category=ColumnTypeCategory.INTEGER),
            ValidatedRowFilter(
                column="name", operator="=", value="x'; DROP TABLE y; --", category=ColumnTypeCategory.STRING
            ),
        ],
    )
    # Values are bound as @params, never inlined.
    assert "WHERE `age` > @row_filter_0 AND `name` = @row_filter_1" in query
    assert "DROP TABLE" not in query
    assert [(p.name, p.type_, p.value) for p in params] == [
        ("row_filter_0", "INT64", 21),
        ("row_filter_1", "STRING", "x'; DROP TABLE y; --"),
    ]


def test_bigquery_get_rows_to_sync_runs_count_query_when_filtered():
    # With row filters present the whole-table `num_rows` shortcut is invalid, so a COUNT(*)
    # query with bound parameters runs instead.
    table = mock.MagicMock(project="proj", dataset_id="ds", table_id="t")
    table.schema = [SimpleNamespace(name="age", field_type="INTEGER")]
    client = mock.MagicMock()
    job = mock.MagicMock()
    job.result.return_value = iter([[123]])
    client.query.return_value = job

    result = _get_rows_to_sync(
        table=table,
        client=client,
        should_use_incremental_field=False,
        db_incremental_field_last_value=None,
        logger=mock.MagicMock(),
        row_filters=[
            ValidatedRowFilter(column="age", operator="IN", value=[21, 30], category=ColumnTypeCategory.INTEGER)
        ],
    )

    assert result == 123
    client.get_table.assert_not_called()  # num_rows shortcut skipped when filtered
    count_query = client.query.call_args.args[0]
    assert "COUNT(*)" in count_query
    job_config = client.query.call_args.kwargs["job_config"]
    assert [p.name for p in job_config.query_parameters] == ["row_filter_0_0", "row_filter_0_1"]


@mock.patch("products.warehouse_sources.backend.temporal.data_imports.sources.bigquery.bigquery.time.sleep")
def test_bigquery_get_rows_to_sync_retries_transient_job_not_found(mock_sleep):
    # The COUNT query hits BigQuery's job-metadata race; it must be retried and yield the real
    # count, not swallowed into the catch-all that returns 0 and captures error-tracking noise.
    table = mock.MagicMock(project="proj", dataset_id="ds", table_id="t")
    table.schema = [SimpleNamespace(name="age", field_type="INTEGER")]
    client = mock.MagicMock()
    job = mock.MagicMock()
    job.result.side_effect = [NotFound("404 Not found: Job proj:US.job_abc123"), iter([[123]])]
    client.query.return_value = job

    with mock.patch(
        "products.warehouse_sources.backend.temporal.data_imports.sources.bigquery.bigquery.capture_exception"
    ) as mock_capture:
        result = _get_rows_to_sync(
            table=table,
            client=client,
            should_use_incremental_field=False,
            db_incremental_field_last_value=None,
            logger=mock.MagicMock(),
            row_filters=[
                ValidatedRowFilter(column="age", operator="IN", value=[21, 30], category=ColumnTypeCategory.INTEGER)
            ],
        )

    assert result == 123
    assert client.query.call_count == 2
    mock_sleep.assert_called_once()
    mock_capture.assert_not_called()


def test_bigquery_get_rows_to_sync_skips_capture_when_table_missing():
    # A table deleted/renamed after schema discovery (or absent from the queried region) makes the
    # COUNT query raise a terminal NotFound. The main read path already surfaces this non-retryably,
    # so the best-effort probe must fall back to 0 without capturing error-tracking noise.
    table = mock.MagicMock(project="proj", dataset_id="ds", table_id="t")
    table.schema = [SimpleNamespace(name="age", field_type="INTEGER")]
    client = mock.MagicMock()
    job = mock.MagicMock()
    job.result.side_effect = NotFound("404 Not found: Table proj:ds.t was not found in location EU")
    client.query.return_value = job

    with mock.patch(
        "products.warehouse_sources.backend.temporal.data_imports.sources.bigquery.bigquery.capture_exception"
    ) as mock_capture:
        result = _get_rows_to_sync(
            table=table,
            client=client,
            should_use_incremental_field=False,
            db_incremental_field_last_value=None,
            logger=mock.MagicMock(),
            row_filters=[
                ValidatedRowFilter(column="age", operator="IN", value=[21, 30], category=ColumnTypeCategory.INTEGER)
            ],
        )

    assert result == 0
    mock_capture.assert_not_called()


def test_bigquery_get_rows_to_sync_captures_unexpected_error():
    # A NotFound is only skipped for the missing-table/region wording; an unrelated failure must
    # still be captured so genuine bugs stay visible.
    table = mock.MagicMock(project="proj", dataset_id="ds", table_id="t")
    table.schema = [SimpleNamespace(name="age", field_type="INTEGER")]
    client = mock.MagicMock()
    job = mock.MagicMock()
    job.result.side_effect = ValueError("something unexpected")
    client.query.return_value = job

    with mock.patch(
        "products.warehouse_sources.backend.temporal.data_imports.sources.bigquery.bigquery.capture_exception"
    ) as mock_capture:
        result = _get_rows_to_sync(
            table=table,
            client=client,
            should_use_incremental_field=False,
            db_incremental_field_last_value=None,
            logger=mock.MagicMock(),
            row_filters=[
                ValidatedRowFilter(column="age", operator="IN", value=[21, 30], category=ColumnTypeCategory.INTEGER)
            ],
        )

    assert result == 0
    mock_capture.assert_called_once()


def test_bigquery_get_query_in_filter_expands_to_one_param_per_value():
    bq_table = mock.MagicMock(dataset_id="ds", table_id="t")
    bq_table.schema = [SimpleNamespace(name="age", field_type="INTEGER")]
    query, params = _get_query(
        should_use_incremental_field=False,
        db_incremental_field_last_value=None,
        bq_table=bq_table,
        row_filters=[
            ValidatedRowFilter(column="age", operator="IN", value=[21, 30], category=ColumnTypeCategory.INTEGER)
        ],
    )
    assert "WHERE `age` IN (@row_filter_0_0, @row_filter_0_1)" in query
    assert [(p.name, p.type_, p.value) for p in params] == [
        ("row_filter_0_0", "INT64", 21),
        ("row_filter_0_1", "INT64", 30),
    ]


def test_bigquery_get_query_row_filters_compose_with_incremental():
    bq_table = mock.MagicMock(dataset_id="ds", table_id="t")
    bq_table.schema = [SimpleNamespace(name="age", field_type="INTEGER")]
    query, params = _get_query(
        should_use_incremental_field=True,
        db_incremental_field_last_value=42,
        bq_table=bq_table,
        incremental_field="updated_at",
        incremental_field_type=IncrementalFieldType.Integer,
        row_filters=[ValidatedRowFilter(column="age", operator=">", value=21, category=ColumnTypeCategory.INTEGER)],
    )
    assert "WHERE `updated_at` > 42 AND `age` > @row_filter_0 ORDER BY `updated_at` ASC" in query
    assert [(p.name, p.value) for p in params] == [("row_filter_0", 21)]


@pytest.mark.parametrize(
    "field_type,column_bq_type,last_value,expected_clause,offset_present",
    [
        # DATETIME columns are timezone-naive — a tz-aware literal can't be cast and BigQuery rejects it
        # with "Could not cast literal ... to type DATETIME". On the first incremental sync the cursor
        # defaults to the 1970-01-01 UTC initial value, whose isoformat carries a '+00:00' offset; for a
        # DATETIME field the literal must be naive.
        (IncrementalFieldType.DateTime, "DATETIME", None, "WHERE `cursor` > '1970-01-01T00:00:00'", False),
        # A tz-aware value carried over from a previous sync is also rendered naive for DATETIME fields.
        (
            IncrementalFieldType.DateTime,
            "DATETIME",
            parser.parse("2024-03-11T09:26:04+00:00"),
            "WHERE `cursor` > '2024-03-11T09:26:04'",
            False,
        ),
        # TIMESTAMP columns are timezone-aware, so the offset must be preserved in the literal.
        (IncrementalFieldType.Timestamp, "TIMESTAMP", None, "WHERE `cursor` > '1970-01-01T00:00:00+00:00'", True),
    ],
)
def test_bigquery_get_query_datetime_cursor_timezone_offset(
    field_type, column_bq_type, last_value, expected_clause, offset_present
):
    bq_table = mock.MagicMock(dataset_id="ds", table_id="t")
    bq_table.schema = [SimpleNamespace(name="cursor", field_type=column_bq_type)]
    sql, _ = _get_query(
        should_use_incremental_field=True,
        db_incremental_field_last_value=last_value,
        bq_table=bq_table,
        incremental_field="cursor",
        incremental_field_type=field_type,
    )
    assert expected_clause in sql
    assert ("+00:00" in sql) is offset_present


@pytest.mark.parametrize(
    "field_type,last_value,expected_clause",
    [
        (IncrementalFieldType.DateTime, None, "WHERE `cursor` > '1970-01-01'"),
        (IncrementalFieldType.Timestamp, None, "WHERE `cursor` > '1970-01-01'"),
        (
            IncrementalFieldType.DateTime,
            parser.parse("2024-03-11T09:26:04+00:00"),
            "WHERE `cursor` > '2024-03-11'",
        ),
    ],
)
def test_bigquery_get_query_date_column_with_datetime_cursor(field_type, last_value, expected_clause):
    # A column retyped to DATE in BigQuery after discovery still carries a DateTime/Timestamp cursor
    # here, whose datetime-shaped literal ("1970-01-01T00:00:00") BigQuery refuses to cast to DATE
    # ("Could not cast literal ... to type DATE"). The literal must follow the column's live type.
    bq_table = mock.MagicMock(dataset_id="ds", table_id="t")
    bq_table.schema = [SimpleNamespace(name="cursor", field_type="DATE")]
    sql, _ = _get_query(
        should_use_incremental_field=True,
        db_incremental_field_last_value=last_value,
        bq_table=bq_table,
        incremental_field="cursor",
        incremental_field_type=field_type,
    )
    assert expected_clause in sql
    assert "T00:00:00" not in sql
    assert "+00:00" not in sql


@pytest.mark.parametrize(
    "malicious_column",
    [
        "x` FROM `other.private` --",
        "id; DROP TABLE customers",
        "email`, `secret",
        "name with space",
        "col\x00null",
    ],
)
def test_bigquery_select_clause_rejects_injection_attempts(malicious_column):
    """`enabled_columns` flows from user config — must be allowlisted before backtick quoting."""
    with pytest.raises(InvalidIdentifierError):
        _bq_select_clause([malicious_column], primary_keys=None, incremental_field=None)


@pytest.mark.parametrize(
    "observed_error",
    [
        # Rotated/revoked service account private key.
        "('invalid_grant: Invalid JWT Signature.', {'error': 'invalid_grant', 'error_description': 'Invalid JWT Signature.'})",
        # Deleted service account.
        "('invalid_grant: Invalid grant: account not found', {'error': 'invalid_grant', 'error_description': 'Invalid grant: account not found'})",
    ],
)
def test_non_retryable_errors_match_rejected_credentials(observed_error):
    """A `RefreshError` carrying the OAuth2 `invalid_grant` code means Google rejected the
    service account grant — retrying can't recover, so the sync must be disabled."""
    non_retryable_errors = BigQuerySource().get_non_retryable_errors()
    assert any(key in observed_error for key in non_retryable_errors)


@pytest.mark.parametrize(
    "observed_error",
    [
        # Raised when the Dataset ID is `project.dataset`, so we build a 4-component table id.
        'table_id must be a fully-qualified ID in standard SQL format, e.g., "project.dataset.table_id", '
        "got immortal-407108.immortal-407108.analytics_529249625.events_20260325",
        'table_id must be a fully-qualified ID in standard SQL format, e.g., "project.dataset.table_id", '
        "got immortal-407108.immortal-407108.analytics_529249625.__posthog_import_abc_def_123",
    ],
)
def test_bigquery_malformed_table_id_is_non_retryable(observed_error):
    non_retryable_errors = BigQuerySource().get_non_retryable_errors()
    matching = [key for key in non_retryable_errors if key in observed_error]
    assert matching, "Malformed table id error should be recognised as non-retryable"
    assert all(non_retryable_errors[key] is not None for key in matching)


@pytest.mark.parametrize(
    "observed_error",
    [
        # Offline ngrok tunnel — the subdomain varies but the stable error code does not.
        "RefreshError: <!DOCTYPE html> <html> ... "
        "<noscript>The endpoint tetrarchical-coercibly-norine.ngrok-free.dev is offline. (ERR_NGROK_3200)</noscript>",
        # Different tunnel subdomain — the match must not rely on the volatile host part.
        "RefreshError: <!DOCTYPE html> <html> ... "
        "<noscript>The endpoint other-tunnel-name.ngrok-free.dev is offline. (ERR_NGROK_3200)</noscript>",
    ],
)
def test_non_retryable_errors_match_offline_token_uri_endpoint(observed_error):
    """A service account whose `token_uri` points at an offline ngrok tunnel makes google-auth
    raise a `RefreshError` carrying ngrok's HTML error page — a misconfigured key the user must
    fix, so the sync must be disabled rather than retried forever."""
    non_retryable_errors = BigQuerySource().get_non_retryable_errors()
    matching = [key for key in non_retryable_errors if key in observed_error]
    assert matching, "Offline token_uri endpoint error should be recognised as non-retryable"
    assert all(non_retryable_errors[key] is not None for key in matching)


@pytest.mark.parametrize(
    "observed_error",
    [
        # token_uri pointed at the cloud metadata endpoint — PostHog's egress proxy denies it.
        "RefreshError: Egress proxying is denied to host '169.254.169.254': no valid IP found "
        "among resolved addresses - 169.254.169.254 denied by rule 'Deny: Not Global Unicast'. .",
        # Different denied host — the match must not rely on the volatile host/IP.
        "RefreshError: Egress proxying is denied to host '10.0.0.5': no valid IP found "
        "among resolved addresses - 10.0.0.5 denied by rule 'Deny: Not Global Unicast'. .",
    ],
)
def test_non_retryable_errors_match_egress_denied_token_uri_endpoint(observed_error):
    """A service account whose `token_uri` points at a non-globally-routable address (e.g. a
    cloud metadata endpoint) makes our egress proxy deny the request, and google-auth surfaces
    that denial as a `RefreshError` — a misconfigured key the user must fix, so the sync must be
    disabled rather than retried forever."""
    non_retryable_errors = BigQuerySource().get_non_retryable_errors()
    matching = [key for key in non_retryable_errors if key in observed_error]
    assert matching, "Egress-denied token_uri endpoint error should be recognised as non-retryable"
    assert all(non_retryable_errors[key] is not None for key in matching)


@pytest.mark.parametrize(
    "observed_error",
    [
        # Corrupted/truncated private key body in the uploaded service account JSON.
        "Unable to load PEM file. See https://cryptography.io/en/latest/faq/#why-can-t-i-import-my-pem-file for more details. InvalidData(InvalidPadding)",
        "ValueError: Unable to load PEM file. InvalidData(InvalidByte(1, 45))",
    ],
)
def test_bigquery_unparseable_private_key_is_non_retryable(observed_error):
    non_retryable_errors = BigQuerySource().get_non_retryable_errors()
    matching = [key for key in non_retryable_errors if key in observed_error]
    assert matching, "Unparseable private key error should be recognised as non-retryable"
    assert all(non_retryable_errors[key] is not None for key in matching)


@pytest.mark.parametrize(
    "observed_error",
    [
        # Column collision surfaced with the raw BigQuery [row:col] location.
        "400 Column name organization is ambiguous at [1:113]; reason: invalidQuery, location: query, "
        "message: Column name organization is ambiguous at [1:113]\n\nLocation: us-west1\nJob ID: cc9e1e07-9d3a-4fcc-a51c-09b2f4237894\n",
        # Different column name and location — the match must not rely on either.
        "400 Column name id is ambiguous at [2:45]; reason: invalidQuery, location: query, "
        "message: Column name id is ambiguous at [2:45]",
    ],
)
def test_bigquery_ambiguous_column_is_non_retryable(observed_error):
    """A view/table whose own definition yields a colliding column name (e.g. a join of tables
    sharing a column, or two columns differing only by case) makes every retry fail identically."""
    non_retryable_errors = BigQuerySource().get_non_retryable_errors()
    matching = [key for key in non_retryable_errors if key in observed_error]
    assert matching, "Ambiguous column error should be recognised as non-retryable"
    assert all(non_retryable_errors[key] is not None for key in matching)


@pytest.mark.parametrize(
    "observed_error",
    [
        # Incremental field (or an enabled column) renamed/dropped from the source table.
        "400 Unrecognized name: ingested_at at [1:37]; reason: invalidQuery, location: query, "
        "message: Unrecognized name: ingested_at at [1:37]\n\nLocation: europe-north1\nJob ID: "
        "f50c015b-4295-4b95-a361-2503e9c936f7\n",
        # Different column name and location — the match must not rely on either.
        "400 Unrecognized name: legacy_status at [2:10]; reason: invalidQuery, location: query, "
        "message: Unrecognized name: legacy_status at [2:10]",
    ],
)
def test_bigquery_unrecognized_column_name_is_non_retryable(observed_error):
    """A column referenced by our query (the incremental field, an enabled column, or a row
    filter) that was renamed or dropped from the source table makes every retry fail identically."""
    non_retryable_errors = BigQuerySource().get_non_retryable_errors()
    matching = [key for key in non_retryable_errors if key in observed_error]
    assert matching, "Unrecognized column name error should be recognised as non-retryable"
    assert all(non_retryable_errors[key] is not None for key in matching)


@pytest.mark.parametrize(
    "observed_error",
    [
        # A single enabled column renamed/dropped from the source table (direct-read path).
        "request failed: The following selected fields do not exist in the table schema: FOO",
        # Multiple columns — the match must not rely on the specific field names or their count.
        "request failed: The following selected fields do not exist in the table schema: FOO, BAR, BAZ",
    ],
)
def test_bigquery_missing_selected_fields_is_non_retryable(observed_error):
    """A column selected for syncing via the Storage Read API's direct-read path that was renamed
    or dropped from the live table makes every retry fail identically."""
    non_retryable_errors = BigQuerySource().get_non_retryable_errors()
    matching = [key for key in non_retryable_errors if key in observed_error]
    assert matching, "Missing selected-fields error should be recognised as non-retryable"
    assert all(non_retryable_errors[key] is not None for key in matching)


@pytest.mark.parametrize(
    "transient_error",
    [
        # A token refresh that failed for a transient reason must stay retryable.
        "RefreshError: ('Failed to retrieve token', {'error': 'internal_failure'})",
        "RefreshError: HTTPError 503 Service Unavailable",
        "Connection reset by peer",
        "ReadTimeout: The read operation timed out",
        "503 Service Unavailable",
    ],
)
def test_non_retryable_errors_does_not_match_transient_refresh_failures(transient_error):
    """Transient errors must not match any non-retryable key, so they stay retryable. Mirrors the
    real matching mechanism (substring against every key) to guard against an overly broad key."""
    non_retryable_errors = BigQuerySource().get_non_retryable_errors()
    matching = [key for key in non_retryable_errors if key in transient_error]
    assert not matching, f"Transient error should remain retryable, but matched keys: {matching}"


def _run_delete_all_temp_destination_tables(side_effect, logger):
    bq = mock.MagicMock()
    bq.list_tables.side_effect = side_effect
    client_cm = mock.MagicMock()
    client_cm.__enter__.return_value = bq

    with (
        mock.patch(
            "products.warehouse_sources.backend.temporal.data_imports.sources.bigquery.bigquery.bigquery_client",
            return_value=client_cm,
        ),
        mock.patch(
            "products.warehouse_sources.backend.temporal.data_imports.sources.bigquery.bigquery.capture_exception"
        ) as mock_capture,
    ):
        delete_all_temp_destination_tables(
            dataset_id="dataset-id",
            table_prefix="prefix_",
            project_id="project-id",
            location=None,
            dataset_project_id=None,
            private_key="private-key",
            private_key_id="private-key-id",
            client_email="client-email",
            token_uri="token-uri",
            logger=logger,
        )
    return mock_capture


@pytest.mark.parametrize(
    "exception",
    [
        Forbidden("Access Denied: Permission bigquery.tables.list denied on dataset"),
        NotFound("Dataset not found (or it may not exist)"),
        RefreshError(("invalid_grant: Invalid JWT Signature.", {"error": "invalid_grant"})),
    ],
)
def test_delete_all_temp_destination_tables_swallows_expected_errors_quietly(exception):
    """Lost permissions, a deleted dataset, or rejected credentials during best-effort cleanup
    must NOT be captured to error tracking — it's expected and fires on every sync otherwise."""
    logger = mock.MagicMock()

    mock_capture = _run_delete_all_temp_destination_tables(exception, logger)

    mock_capture.assert_not_called()
    logger.warning.assert_called_once()


def test_delete_all_temp_destination_tables_captures_unexpected_errors():
    """Genuinely unexpected errors are still captured so we don't lose visibility."""
    logger = mock.MagicMock()

    mock_capture = _run_delete_all_temp_destination_tables(RuntimeError("boom"), logger)

    mock_capture.assert_called_once()


# Regression: a stray leading/trailing space in a hand-entered project or dataset ID made
# every BigQuery request fail with an opaque `BadRequest: Invalid project ID ' ...'` /
# `Invalid dataset ID ' ...'`. The identifiers must be trimmed before reaching BigQuery.


@pytest.mark.parametrize(
    "resolver,field,raw,expected",
    [
        (_resolve_project_id, "project_id", " 524098457564", "524098457564"),
        (_resolve_project_id, "project_id", "project-id\n", "project-id"),
        (_resolve_dataset_id, "dataset_id", " bigquery_aloalo ", "bigquery_aloalo"),
        (_resolve_dataset_id, "dataset_id", "\tdataset-id", "dataset-id"),
    ],
)
def test_bigquery_resolvers_trim_whitespace(resolver, field, raw, expected):
    config = _make_config(**{field: raw})
    assert resolver(config) == expected


def test_bigquery_resolve_region_trims_and_treats_whitespace_as_unset():
    assert (
        _resolve_region(_make_config(dataset_project=None)) is None  # no custom region configured
    )

    config = _make_config()
    config.use_custom_region = BigQueryUseCustomRegionConfig(region="  us-east1 ", enabled=True)
    assert _resolve_region(config) == "us-east1"

    config.use_custom_region = BigQueryUseCustomRegionConfig(region="   ", enabled=True)
    assert _resolve_region(config) is None


# Regression: credentials validate with a region-agnostic `list_tables`, but a discovery query
# job created without a location defaults to the US multi-region — so a dataset in another region
# passed validation yet failed schema discovery with "... was not found in location US". `connect`
# auto-resolves the dataset's real location so discovery runs where the data lives.


def _patch_bigquery_client(fake_bq):
    client_cm = mock.MagicMock()
    client_cm.__enter__.return_value = fake_bq
    return mock.patch(
        "products.warehouse_sources.backend.temporal.data_imports.sources.bigquery.bigquery.bigquery_client",
        return_value=client_cm,
    )


def test_connect_auto_detects_dataset_region_when_unset():
    """No custom region configured: connect must pin the discovery client to the dataset's real
    location (read via the region-agnostic `get_dataset`) instead of defaulting to US."""
    fake_bq = mock.MagicMock()
    fake_bq.get_dataset.return_value.location = "europe-west1"

    with _patch_bigquery_client(fake_bq) as mock_client:
        with BigQueryImplementation().connect(_make_config()) as conn:
            assert conn is fake_bq

    # The region must come from an actual dataset-location lookup, not a hardcoded default.
    fake_bq.get_dataset.assert_called_once()
    # The last client built is the one discovery queries run on; its location is positional arg 1.
    assert mock_client.call_args_list[-1][0][1] == "europe-west1"


def test_connect_uses_configured_region_without_probing():
    """A configured custom region is used as-is — no dataset-location probe is performed."""
    config = _make_config()
    config.use_custom_region = BigQueryUseCustomRegionConfig(region="us-east1", enabled=True)
    fake_bq = mock.MagicMock()

    with _patch_bigquery_client(fake_bq) as mock_client:
        with BigQueryImplementation().connect(config):
            pass

    fake_bq.get_dataset.assert_not_called()
    assert mock_client.call_count == 1
    assert mock_client.call_args_list[-1][0][1] == "us-east1"


def test_connect_falls_back_to_unset_location_when_detection_fails():
    """If the dataset-location probe fails (e.g. the dataset really doesn't exist), connect leaves
    the location unset so `get_columns` still surfaces the actionable not-found error."""
    fake_bq = mock.MagicMock()
    fake_bq.get_dataset.side_effect = NotFound("Not found: Dataset prj:ds")

    with _patch_bigquery_client(fake_bq) as mock_client:
        with BigQueryImplementation().connect(_make_config()):
            pass

    assert mock_client.call_args_list[-1][0][1] is None


def test_bigquery_resolve_dataset_project_id_trims_and_treats_whitespace_as_unset():
    config = _make_config(
        dataset_project=BigQueryDatasetProjectConfig(dataset_project_id="  other-project ", enabled=True)
    )
    assert _resolve_dataset_project_id(config) == "other-project"

    config = _make_config(dataset_project=BigQueryDatasetProjectConfig(dataset_project_id="   ", enabled=True))
    assert _resolve_dataset_project_id(config) is None


def test_bigquery_resolve_query_project_prefers_dataset_project():
    config = _make_config(
        project_id=" service-account-project ",
        dataset_project=BigQueryDatasetProjectConfig(dataset_project_id=" dataset-project ", enabled=True),
    )
    assert _resolve_query_project(config) == "dataset-project"

    config = _make_config(project_id=" service-account-project ")
    assert _resolve_query_project(config) == "service-account-project"


def test_bigquery_get_columns_trims_whitespace_in_identifiers():
    """`get_columns` must not embed a leading space into the INFORMATION_SCHEMA query
    or the `project` it runs against."""
    fake_client = mock.MagicMock()
    fake_client.query.return_value.result.return_value = []

    config = _make_config(project_id=" 524098457564", dataset_id=" bigquery_aloalo ")
    BigQueryImplementation().get_columns(fake_client, config, names=None)

    sql = fake_client.query.call_args.args[0]
    assert "`524098457564.bigquery_aloalo`.INFORMATION_SCHEMA.COLUMNS" in sql
    assert " bigquery_aloalo" not in sql
    assert " 524098457564" not in sql
    assert fake_client.query.call_args.kwargs["project"] == "524098457564"


def test_bigquery_get_columns_qualifies_information_schema_with_dataset_project():
    """When the dataset lives in a different project (`dataset_project`), the INFORMATION_SCHEMA
    reference must carry that project — an unqualified `dataset.INFORMATION_SCHEMA.*` makes BigQuery
    reject the job with "ProjectId must be non-empty". The backtick-quoted identifier must close
    after the dataset (matching `get_primary_keys`/`get_leading_index_columns`) rather than wrapping
    `INFORMATION_SCHEMA.COLUMNS` inside it too — quoting the whole path as one identifier stops
    BigQuery from resolving it as the INFORMATION_SCHEMA view and raises the same error again."""
    fake_client = mock.MagicMock()
    fake_client.query.return_value.result.return_value = []

    config = _make_config(
        project_id="service-account-project",
        dataset_id="posthog_export",
        dataset_project=BigQueryDatasetProjectConfig(dataset_project_id="dataset-project", enabled=True),
    )
    BigQueryImplementation().get_columns(fake_client, config, names=None)

    sql = fake_client.query.call_args.args[0]
    assert "`dataset-project.posthog_export`.INFORMATION_SCHEMA.COLUMNS" in sql
    assert "INFORMATION_SCHEMA.COLUMNS`" not in sql
    assert fake_client.query.call_args.kwargs["project"] == "dataset-project"


@pytest.mark.parametrize("method_name", ["get_primary_keys", "get_leading_index_columns"])
def test_bigquery_discovery_qualifies_information_schema_with_dataset_project(method_name):
    """`get_primary_keys` and `get_leading_index_columns` share the same unqualified-reference
    defect as `get_columns`, but swallow the error and silently lose PK/index detection. Their
    INFORMATION_SCHEMA references must carry the dataset project too."""
    config = _make_config(
        project_id="service-account-project",
        dataset_id="posthog_export",
        dataset_project=BigQueryDatasetProjectConfig(dataset_project_id="dataset-project", enabled=True),
    )

    fake_client = mock.MagicMock()
    fake_client.query.return_value.result.return_value = []

    getattr(BigQueryImplementation(), method_name)(fake_client, config, tables=["t"])

    sql = fake_client.query.call_args.args[0]
    assert "`dataset-project.posthog_export`.INFORMATION_SCHEMA" in sql
    assert fake_client.query.call_args.kwargs["project"] == "dataset-project"


def test_bigquery_get_primary_keys_trims_whitespace_in_identifiers():
    fake_client = mock.MagicMock()
    fake_client.query.return_value.result.return_value = []

    config = _make_config(project_id=" my-project ", dataset_id=" my_dataset ")
    BigQueryImplementation().get_primary_keys(fake_client, config, tables=["t"])

    sql = fake_client.query.call_args.args[0]
    assert "`my-project.my_dataset`.INFORMATION_SCHEMA.TABLE_CONSTRAINTS" in sql
    assert " my_dataset" not in sql
    assert " my-project" not in sql
    assert fake_client.query.call_args.kwargs["project"] == "my-project"


def test_bigquery_validate_credentials_trims_whitespace_before_calling_bigquery():
    bq = mock.MagicMock()
    client_cm = mock.MagicMock()
    client_cm.__enter__.return_value = bq

    with mock.patch(
        "products.warehouse_sources.backend.temporal.data_imports.sources.bigquery.bigquery.bigquery_client",
        return_value=client_cm,
    ) as mock_client:
        validate_bigquery_credentials(
            dataset_id=" my_dataset ",
            key_file={
                "project_id": " 524098457564",
                "private_key": "private-key",
                "private_key_id": "private-key-id",
                "client_email": "client-email",
                "token_uri": "token-uri",
            },
            dataset_project_id=None,
            location=None,
        )

    assert mock_client.call_args.args[0] == "524098457564"
    bq.dataset.assert_called_once_with("my_dataset", project="524098457564")


def _valid_key_file() -> dict[str, str]:
    return {
        "project_id": "my-project",
        "private_key": "private-key",
        "private_key_id": "private-key-id",
        "client_email": "client-email",
        "token_uri": "token-uri",
    }


def test_bigquery_validate_credentials_missing_fields_reports_actionable_message():
    key_file = _valid_key_file()
    del key_file["private_key"]

    with mock.patch.object(bq_module, "bigquery_client") as mock_client:
        ok, message = validate_bigquery_credentials(
            dataset_id="my_dataset", key_file=key_file, dataset_project_id=None, location=None
        )

    assert ok is False
    assert message == BIGQUERY_MISSING_KEY_FILE_FIELDS_ERROR
    # A malformed key file must be caught before we try to reach BigQuery.
    mock_client.assert_not_called()


@pytest.mark.parametrize(
    "exception,expected_message,should_capture",
    [
        (
            ValueError("Unable to load PEM file. ... InvalidData(InvalidPadding)"),
            BIGQUERY_INVALID_KEY_FILE_ERROR,
            False,
        ),
        (RefreshError("('invalid_grant: Invalid JWT Signature.', {})"), BIGQUERY_CREDENTIALS_REJECTED_ERROR, False),
        (BadRequest('Invalid dataset ID "(default)"'), BIGQUERY_INVALID_IDENTIFIER_ERROR, False),
        (BadRequest("400 ProjectId must be non-empty"), BIGQUERY_INVALID_IDENTIFIER_ERROR, False),
        (
            NotFound("404 Not found: Dataset my-project:my_dataset was not found in location US"),
            BIGQUERY_DATASET_NOT_FOUND_ERROR,
            False,
        ),
        (
            Forbidden("403 Access Denied: Table my-project:my_dataset.t"),
            BIGQUERY_VALIDATION_PERMISSION_DENIED_ERROR,
            False,
        ),
        (RuntimeError("something unexpected"), BIGQUERY_VALIDATION_GENERIC_ERROR, True),
    ],
)
def test_bigquery_validate_credentials_maps_failures_to_actionable_messages(
    exception, expected_message, should_capture
):
    # Validation consumes the first page of `list_tables`, and that page fetch is where the request
    # actually runs, so surface each failure from page consumption — the real request site. This
    # also guards the regression: an inert validation that never consumes a page would return
    # `(True, None)` and fail these assertions.
    bq = mock.MagicMock()
    bq.list_tables.return_value.pages.__next__.side_effect = exception
    client_cm = mock.MagicMock()
    client_cm.__enter__.return_value = bq

    with (
        mock.patch.object(bq_module, "bigquery_client", return_value=client_cm),
        mock.patch.object(bq_module, "capture_exception") as mock_capture,
    ):
        ok, message = validate_bigquery_credentials(
            dataset_id="my_dataset", key_file=_valid_key_file(), dataset_project_id=None, location=None
        )

    assert ok is False
    assert message == expected_message
    # Expected user/config errors must not be reported to error tracking as noise; only genuinely
    # unexpected failures are captured.
    assert mock_capture.called is should_capture


@pytest.mark.parametrize(
    "use_custom_region,expected_region",
    [
        (None, None),
        (BigQueryUseCustomRegionConfig(enabled=False, region="europe-west2"), None),
        (BigQueryUseCustomRegionConfig(enabled=True, region=""), None),
        (BigQueryUseCustomRegionConfig(enabled=True, region="europe-west2"), "europe-west2"),
    ],
)
def test_bigquery_source_validate_credentials_wires_config_and_region(use_custom_region, expected_region):
    config = _make_config(use_custom_region=use_custom_region)

    with mock.patch(
        "products.warehouse_sources.backend.temporal.data_imports.sources.bigquery.source.validate_bigquery_credentials",
        return_value=(True, None),
    ) as mock_validate:
        result = BigQuerySource().validate_credentials(config, team_id=1)

    assert result == (True, None)
    dataset_id, key_file, dataset_project_id, region = mock_validate.call_args.args
    assert dataset_id == "dataset-id"
    assert key_file["project_id"] == "project-id"
    assert key_file["token_uri"] == "token-uri"
    assert dataset_project_id is None
    # A custom region only flows through when the toggle is enabled and non-empty.
    assert region == expected_region


def test_bigquery_build_pipeline_trims_whitespace_in_destination_table():
    """Whitespace in project/dataset IDs must not leak into the fully-qualified
    destination table name passed to BigQuery during a sync."""
    config = _make_config(project_id=" 524098457564", dataset_id=" bigquery_aloalo ")
    expected_table_id = (
        f"524098457564.bigquery_aloalo.__posthog_import_schema_id_job_id_"
        f"{str(parser.parse('2025-01-01T12:00:00.000Z').timestamp()).replace('.', '')}"
    )

    with (
        freeze_time("2025-01-01T12:00:00.000Z"),
        mock.patch(
            "products.warehouse_sources.backend.temporal.data_imports.sources.bigquery.bigquery.delete_all_temp_destination_tables",
        ) as mock_delete_all,
        mock.patch.object(BigQueryImplementation, "_build_source_response", return_value=mock.MagicMock()),
        mock.patch(
            "products.warehouse_sources.backend.temporal.data_imports.sources.bigquery.bigquery.delete_table",
        ) as mock_delete,
    ):
        BigQuerySource().source_for_pipeline(config, _make_inputs())

    assert mock_delete_all.call_args.kwargs["project_id"] == "524098457564"
    assert mock_delete_all.call_args.kwargs["dataset_id"] == "bigquery_aloalo"
    assert mock_delete.call_args.kwargs["table_id"] == expected_table_id


@pytest.mark.parametrize(
    "observed_error",
    [
        # Storage Read API permission failure — `str(PermissionDenied)` is "403 Access Denied: ..."
        str(
            PermissionDenied(
                "Access Denied: Table prj:ds.fct__conversions: Permission bigquery.tables.getData "
                "denied on table prj:ds.fct__conversions (or it may not exist)."
            )
        ),
        # Permission to list tables in a dataset is also denied with the same prefix
        str(Forbidden("Access Denied: Permission bigquery.tables.list denied on dataset prj:ds.")),
        # Storage Read API `create_read_session` denial — `str(PermissionDenied)` is "403 request
        # failed: the user does not have 'bigquery.readsessions.create' permission for 'projects/...'",
        # which the "Access Denied:" / "PermissionDenied: 403 request failed" keys don't cover.
        str(
            PermissionDenied(
                "request failed: the user does not have 'bigquery.readsessions.create' "
                "permission for 'projects/some-project'"
            )
        ),
        # Storage Read API stream-read denial — the session can be created but the account lacks
        # `bigquery.readsessions.getData`. `str(PermissionDenied)` is "there was an error operating
        # on '.../streams/...': the user does not have 'bigquery.readsessions.getData' permission for
        # '...'", which neither the "Access Denied:" / "403 request failed" nor the readsessions.create
        # keys cover.
        str(
            PermissionDenied(
                "there was an error operating on 'projects/some-project/locations/us/sessions/sess/"
                "streams/strm': the user does not have 'bigquery.readsessions.getData' permission for "
                "'projects/some-project/locations/us/sessions/sess/streams/strm'"
            )
        ),
    ],
)
def test_non_retryable_errors_match_permission_denied(observed_error):
    non_retryable_errors = BigQuerySource().get_non_retryable_errors()
    assert any(key in observed_error for key in non_retryable_errors)


@pytest.mark.parametrize(
    "observed_error,expected_key,expected_word",
    [
        # Overwriting a PostHog temp table — denied with bigquery.tables.update on the table.
        (
            str(
                Forbidden(
                    "Access Denied: Table prj:ds.__posthog_import_abc_123: Permission bigquery.tables.update "
                    "denied on table prj:ds.__posthog_import_abc_123 (or it may not exist)."
                )
            ),
            "bigquery.tables.update",
            "write access",
        ),
        # Creating a PostHog temp table — denied with bigquery.tables.create on the dataset.
        (
            str(
                Forbidden(
                    "Access Denied: Dataset prj:ds: Permission bigquery.tables.create denied on dataset "
                    "prj:ds (or it may not exist)."
                )
            ),
            "bigquery.tables.create",
            "create",
        ),
        # Querying a table/view that reads through a BigQuery connection (federated query or
        # BigLake) the service account isn't authorized to use — denied with
        # bigquery.connections.use on the connection resource, not the table/dataset.
        (
            str(
                Forbidden(
                    "Access Denied: Connection projects/proj/locations/us/connections/conn: User does not "
                    "have bigquery.connections.use permission for connection "
                    "projects/proj/locations/us/connections/conn."
                )
            ),
            "bigquery.connections.use",
            "connection",
        ),
    ],
)
def test_specific_permission_denial_outranks_generic_access_denied(observed_error, expected_key, expected_word):
    # Each of these denials also contains "Access Denied:", so both the generic key and the
    # more specific key match. external_data_job surfaces the first matching key's message, so the
    # specific key must sit above "Access Denied:" — otherwise the customer is told to grant table
    # read access to fix a failure that read access can't resolve.
    non_retryable_errors = BigQuerySource().get_non_retryable_errors()
    first_key, friendly = next((key, msg) for key, msg in non_retryable_errors.items() if key in observed_error)
    assert first_key == expected_key
    assert friendly is not None
    assert expected_word in friendly


def test_job_create_denial_surfaces_job_permission_guidance():
    # A bigquery.jobs.create denial also contains "Access Denied:", so both keys match.
    # external_data_job surfaces the first matching key's message, so the job-creation key must sit
    # above "Access Denied:" — otherwise the customer is told to grant read access to fix a failure
    # that read access can't resolve.
    observed_error = str(
        Forbidden(
            "POST https://bigquery.googleapis.com/bigquery/v2/projects/p/jobs?prettyPrint=false: "
            "Access Denied: Project p: User does not have bigquery.jobs.create permission in project p."
        )
    )
    non_retryable_errors = BigQuerySource().get_non_retryable_errors()
    first_key, friendly = next((key, msg) for key, msg in non_retryable_errors.items() if key in observed_error)
    assert first_key == "bigquery.jobs.create"
    assert friendly is not None
    assert "run query jobs" in friendly


@pytest.mark.parametrize(
    "observed_error",
    [
        # Federated table backed by a Cloud SQL PostgreSQL server — BigQuery wraps the upstream
        # ACL failure in a 400 BadRequest while reading query results.
        str(
            BadRequest(
                "GET https://bigquery.googleapis.com/bigquery/v2/projects/p/queries/j?maxResults=0"
                "&location=us-central1: Error while reading data, error message: Failed to fetch row "
                "from PostgreSQL server. Error: ERROR:  permission denied for table GroupParticipant"
            )
        ),
    ],
)
def test_non_retryable_errors_match_federated_upstream_permission_denied(observed_error):
    non_retryable_errors = BigQuerySource().get_non_retryable_errors()
    assert any(key in observed_error for key in non_retryable_errors)


@pytest.mark.parametrize(
    "observed_error",
    [
        # Federated EXTERNAL_QUERY view whose upstream schema drifted — a column the view selects was
        # renamed/dropped in the source database, so BigQuery can't compile the view.
        str(
            BadRequest(
                "GET https://bigquery.googleapis.com/bigquery/v2/projects/p/queries/j?maxResults=0"
                "&location=us-central1: Invalid table-valued function EXTERNAL_QUERY; failed to parse "
                "view 'analytics.SurveyResponse'\nFailed to get query schema from PostgreSQL server, "
                'prepare statement failed. Error: ERROR:  column "participantId" does not exist'
            )
        ),
    ],
)
def test_non_retryable_errors_match_unparseable_view(observed_error):
    """A view whose definition no longer matches the underlying data (e.g. a federated query
    references a dropped column) can't be recovered by retrying — the user must fix the view."""
    non_retryable_errors = BigQuerySource().get_non_retryable_errors()
    assert any(key in observed_error for key in non_retryable_errors)


@pytest.mark.parametrize(
    "observed_error",
    [
        # A NaN in a NUMERIC-typed column, surfaced from `jobs.getQueryResults` while polling a query
        # job — BigQuery's NUMERIC type can't represent NaN the way FLOAT64 can.
        str(
            BadRequest(
                "GET https://bigquery.googleapis.com/bigquery/v2/projects/p/queries/j?maxResults=0"
                "&location=EU&prettyPrint=false: Invalid NUMERIC value: NaN\n\nLocation: EU\nJob ID: j"
            )
        ),
    ],
)
def test_non_retryable_errors_match_numeric_nan(observed_error):
    """A NUMERIC-typed column holding NaN traces back to the customer's source view/data, and the
    same query keeps producing it on every retry — the user must fix the underlying view/column."""
    non_retryable_errors = BigQuerySource().get_non_retryable_errors()
    assert any(key in observed_error for key in non_retryable_errors)


@pytest.mark.parametrize(
    "observed_error",
    [
        # Administrator-set custom cost control on the customer's BigQuery project — surfaced as a
        # `Forbidden` whose str() is "403 Custom quota exceeded: ...".
        str(
            Forbidden(
                "Custom quota exceeded: Your usage exceeded the custom quota for QueryUsagePerDay, "
                "which is set by your administrator. For more information, see "
                "https://docs.cloud.google.com/bigquery/cost-controls.; reason: quotaExceeded"
            )
        ),
        # Per-user variant of the same custom cost control.
        str(
            Forbidden(
                "Custom quota exceeded: Your usage exceeded the custom quota for "
                "QueryUsagePerUserPerDay, which is set by your administrator.; reason: quotaExceeded"
            )
        ),
    ],
)
def test_non_retryable_errors_match_custom_quota_exceeded(observed_error):
    """An administrator-set custom cost control (e.g. QueryUsagePerDay) can't be recovered by
    retrying within the sync's window — the user must raise the quota or sync less data."""
    non_retryable_errors = BigQuerySource().get_non_retryable_errors()
    assert any(key in observed_error for key in non_retryable_errors)


@pytest.mark.parametrize(
    "other_error",
    [
        # Transient server / connection errors must stay retryable
        "503 Service unavailable, please retry",
        "500 Internal error encountered",
        "Connection reset by peer",
        # A federated-read failure that isn't a permission problem must stay retryable
        "Error while reading data, error message: Failed to fetch row from PostgreSQL server. "
        "Error: ERROR:  connection to server timed out",
        # Transient rate-limit quota errors ("Quota exceeded" / `rateLimitExceeded`) are NOT the
        # administrator-set custom cost control and must stay retryable — the "Custom quota
        # exceeded" key must not catch them.
        "403 Quota exceeded: Your project exceeded quota for concurrent queries; reason: quotaExceeded",
        "403 Exceeded rate limits: too many concurrent queries for this project; reason: rateLimitExceeded",
    ],
)
def test_non_retryable_errors_does_not_match_transient(other_error):
    non_retryable_errors = BigQuerySource().get_non_retryable_errors()
    assert not any(key in other_error for key in non_retryable_errors)


def _run_has_duplicate_primary_keys(side_effect):
    table = mock.MagicMock()
    table.dataset_id = "dataset"
    table.table_id = "table"
    table.project = "project"

    client = mock.MagicMock()
    job = mock.MagicMock()
    job.result.side_effect = side_effect
    client.query.return_value = job

    with mock.patch(
        "products.warehouse_sources.backend.temporal.data_imports.sources.bigquery.bigquery.capture_exception"
    ) as mock_capture:
        result = _has_duplicate_primary_keys(table, client, ["id"])
    return result, mock_capture


@pytest.mark.parametrize(
    "exception",
    [
        BadRequest(
            "Resources exceeded during query execution: The query could not be executed in the allotted memory."
        ),
        BadRequest("query failed", errors=[{"reason": "resourcesExceeded", "message": "out of memory"}]),
    ],
)
def test_has_duplicate_primary_keys_skips_resource_exceeded_quietly(exception):
    """A `resourcesExceeded` BigQuery error during the best-effort duplicate-key probe must NOT
    be captured to error tracking — it's a non-actionable data-volume limit that otherwise fires
    on every sync of a large table."""
    result, mock_capture = _run_has_duplicate_primary_keys(exception)

    assert result is False
    mock_capture.assert_not_called()


@pytest.mark.parametrize(
    "exception",
    [
        BadRequest(
            "Name is_qualified not found inside visit; failed to parse view 'my_dataset.my_view' at [5:19]; "
            "reason: invalidQuery, location: query, message: Name is_qualified not found inside visit; "
            "failed to parse view 'my_dataset.my_view' at [5:19]"
        ),
        BadRequest("Invalid table-valued function EXTERNAL_QUERY; failed to parse view 'my_dataset.my_view' at [1:1]"),
    ],
)
def test_has_duplicate_primary_keys_skips_view_parse_failure_quietly(exception):
    """A `failed to parse view` BigQuery error during the best-effort duplicate-key probe must NOT
    be captured to error tracking — the probed table is itself a broken view, a customer-side
    problem that otherwise fires on every sync of that table."""
    result, mock_capture = _run_has_duplicate_primary_keys(exception)

    assert result is False
    mock_capture.assert_not_called()


def test_has_duplicate_primary_keys_captures_unexpected_bad_request():
    """A non-resource BadRequest (e.g. a genuinely malformed probe query) is still captured so we
    don't lose visibility into real bugs."""
    result, mock_capture = _run_has_duplicate_primary_keys(BadRequest("Syntax error in query"))

    assert result is False
    mock_capture.assert_called_once()


def test_has_duplicate_primary_keys_captures_unexpected_errors():
    """Genuinely unexpected errors are still captured so we don't lose visibility."""
    result, mock_capture = _run_has_duplicate_primary_keys(RuntimeError("boom"))

    assert result is False
    mock_capture.assert_called_once()


@pytest.mark.parametrize(
    "exc",
    [
        # The transient `jobInternalError` from `jobs.getQueryResults` (volatile project/job id redacted).
        BadRequest(
            "GET https://bigquery.googleapis.com/bigquery/v2/projects/<redacted>/queries/<redacted>"
            "?maxResults=0&location=US&prettyPrint=false: The job encountered an error during execution. "
            "Retrying the job may solve the problem."
        ),
        # A second wording for the same transient `jobInternalError` condition, with no
        # retry-recommendation suffix (volatile project/job id redacted).
        BadRequest(
            "GET https://bigquery.googleapis.com/bigquery/v2/projects/<redacted>/queries/<redacted>"
            "?maxResults=0&location=US&prettyPrint=false: The job encountered an internal error during "
            "execution and was unable to complete successfully."
        ),
        # The library default's own retryable reasons must still be honoured.
        BadRequest("query failed", errors=[{"reason": "backendError", "message": "internal error"}]),
        BadRequest("query failed", errors=[{"reason": "rateLimitExceeded", "message": "slow down"}]),
        # A per-second rate quota (reason `quotaExceeded`, which the library's own predicates don't
        # retry) is transient — the quota window resets each second — so it must be retried in place
        # rather than crashing the sync. Volatile project/job ids redacted.
        Forbidden(
            "GET https://bigquery.googleapis.com/bigquery/v2/projects/<redacted>/queries/<redacted>"
            "?maxResults=0&location=US&prettyPrint=false: Quota exceeded: Your project:<redacted> "
            "exceeded quota for tabledata.list bytes per second per project. For more information, "
            "see https://cloud.google.com/bigquery/docs/troubleshoot-quotas"
        ),
        # The queued-jobs quota (reason `quotaExceeded`, location `max_queued_jobs`) is transient —
        # the queue drains as running jobs finish — so it must be retried rather than crashing the
        # sync. Volatile ids redacted.
        Forbidden(
            "Quota exceeded: Your project_and_region exceeded quota for max number of jobs that can "
            "be queued per project. For more information, see "
            "https://cloud.google.com/bigquery/docs/troubleshoot-quotas"
        ),
    ],
)
def test_bigquery_query_job_retry_retries_transient_job_errors(exc):
    assert BIGQUERY_QUERY_JOB_RETRY._predicate(exc) is True


@pytest.mark.parametrize(
    "exc",
    [
        # A genuinely malformed query is deterministic — retrying never helps, so it must surface.
        BadRequest("Syntax error: Unexpected keyword SELECT"),
        BadRequest("query failed", errors=[{"reason": "invalidQuery", "message": "bad SQL"}]),
        # The administrator-set "Custom quota exceeded" daily cost cap resets only on Google's daily
        # schedule — the per-second rate-quota retry must not catch it and hammer the endpoint.
        Forbidden(
            "Custom quota exceeded: Your usage exceeded the custom quota for QueryUsagePerDay, "
            "which is set by your administrator.; reason: quotaExceeded"
        ),
    ],
)
def test_bigquery_query_job_retry_does_not_retry_deterministic_errors(exc):
    assert BIGQUERY_QUERY_JOB_RETRY._predicate(exc) is False


def test_bigquery_query_create_retry_retries_queued_jobs_quota():
    """The queued-jobs quota is rejected at `jobs.insert`, which `job_retry` never wraps — only the
    `retry` on `client.query()` can wait it out — so the create retry must cover it while still
    leaving the administrator-set daily cost cap to surface non-retryably."""
    queued_jobs = Forbidden(
        "Quota exceeded: Your project_and_region exceeded quota for max number of jobs that can be "
        "queued per project. For more information, see https://cloud.google.com/bigquery/docs/troubleshoot-quotas"
    )
    custom_quota = Forbidden(
        "Custom quota exceeded: Your usage exceeded the custom quota for QueryUsagePerDay, "
        "which is set by your administrator.; reason: quotaExceeded"
    )
    assert BIGQUERY_QUERY_CREATE_RETRY._predicate(queued_jobs) is True
    assert BIGQUERY_QUERY_CREATE_RETRY._predicate(custom_quota) is False


@pytest.mark.parametrize(
    "exc",
    [
        # The observed transient: a dropped Storage Read stream surfaced as a gRPC INTERNAL. The
        # library default only reconnects on ServiceUnavailable, so this escaped and crashed the read.
        InternalServerError("Received RST_STREAM with error code 2"),
        ServiceUnavailable("503 The service is currently unavailable."),
    ],
)
def test_bigquery_read_rows_retry_reconnects_on_transient_stream_errors(exc):
    assert BIGQUERY_READ_ROWS_RETRY._predicate(exc) is True


@pytest.mark.parametrize(
    "exc",
    [
        # Deterministic failures must surface rather than reconnect forever.
        NotFound("404 Requested stream was not found."),
        BadRequest("400 request failed"),
    ],
)
def test_bigquery_read_rows_retry_does_not_reconnect_on_deterministic_errors(exc):
    assert BIGQUERY_READ_ROWS_RETRY._predicate(exc) is False


@pytest.mark.parametrize(
    "exc",
    [
        # The observed production failure: `create_read_session` itself returning a transient
        # gRPC INTERNAL before any stream exists. The library default only retries
        # DeadlineExceeded/ServiceUnavailable, so this escaped and crashed the import activity.
        InternalServerError("request failed: internal error"),
        ServiceUnavailable("503 The service is currently unavailable."),
        DeadlineExceeded("504 Deadline Exceeded"),
    ],
)
def test_bigquery_create_read_session_retry_retries_transient_errors(exc):
    assert BIGQUERY_CREATE_READ_SESSION_RETRY._predicate(exc) is True


@pytest.mark.parametrize(
    "exc",
    [
        # Deterministic failures must surface rather than retry forever.
        NotFound("404 Requested table was not found."),
        BadRequest("400 request failed"),
    ],
)
def test_bigquery_create_read_session_retry_does_not_retry_deterministic_errors(exc):
    assert BIGQUERY_CREATE_READ_SESSION_RETRY._predicate(exc) is False


def test_bigquery_get_primary_keys_for_table_passes_job_retry():
    """The primary-key probe must run under the extended job retry so a transient BigQuery job
    error is re-tried in place instead of crashing the import."""
    table = mock.MagicMock()
    table.schema = []
    table.dataset_id = "dataset"
    table.table_id = "table"
    table.project = "project"

    client = mock.MagicMock()
    client.query.return_value.result.return_value = []

    _get_primary_keys_for_table(table, client)

    assert client.query.return_value.result.call_args.kwargs["job_retry"] is BIGQUERY_QUERY_JOB_RETRY
    assert client.query.call_args.kwargs["retry"] is BIGQUERY_QUERY_CREATE_RETRY


@mock.patch("products.warehouse_sources.backend.temporal.data_imports.sources.bigquery.bigquery.time.sleep")
def test_bigquery_get_primary_keys_for_table_retries_transient_job_not_found(mock_sleep):
    """The primary-key probe hits BigQuery's job-metadata race the same as the other queries in this
    file; it must retry with a fresh job instead of crashing the whole sync."""
    table = mock.MagicMock()
    table.schema = [SimpleNamespace(name="id")]
    table.dataset_id = "dataset"
    table.table_id = "table"
    table.project = "project"

    client = mock.MagicMock()
    ok_job = mock.MagicMock()
    ok_job.result.return_value = iter([{"column_name": "id"}])
    client.query.side_effect = [NotFound("404 Not found: Job prj:US.abc"), ok_job]

    primary_keys = _get_primary_keys_for_table(table, client)

    assert primary_keys == ["id"]
    assert client.query.call_count == 2
    mock_sleep.assert_called_once()


def test_run_destination_query_passes_job_retry():
    """The copy-into-temp-table query — where the production sync crashed on a transient per-second
    rate quota — must run under the extended job retry so it waits the rate limit out in place
    instead of aborting the import."""
    client = mock.MagicMock()

    _run_destination_query_with_job_retry(
        client, "SELECT 1", destination_table=mock.MagicMock(), query_parameters=[], project="prj"
    )

    assert client.query.return_value.result.call_args.kwargs["job_retry"] is BIGQUERY_QUERY_JOB_RETRY
    assert client.query.call_args.kwargs["retry"] is BIGQUERY_QUERY_CREATE_RETRY


def test_query_result_passes_job_retry():
    """The read/count query must likewise run under the extended job retry so a transient per-second
    rate quota is retried in place rather than surfacing."""
    client = mock.MagicMock()

    _query_result_with_job_retry(client, "SELECT COUNT(*)", job_config=mock.MagicMock(), project="prj")

    assert client.query.return_value.result.call_args.kwargs["job_retry"] is BIGQUERY_QUERY_JOB_RETRY
    assert client.query.call_args.kwargs["retry"] is BIGQUERY_QUERY_CREATE_RETRY


@pytest.mark.parametrize(
    "message",
    [
        "404 GET https://bigquery.googleapis.com/.../jobs/abc?projection=full: Not found: Job prj:US.abc",
        "Not found: Job prj:EU.job_xyz",
        "Job not found: job_xyz",
    ],
)
def test_is_transient_job_not_found_matches_job_race(message):
    assert _is_transient_job_not_found(NotFound(message)) is True


@pytest.mark.parametrize(
    "message",
    [
        # A missing dataset/table (or a dataset absent from the queried region) is genuinely
        # non-retryable and must not be mistaken for the job race, even though the raw dataset 404
        # can carry a trailing "Job ID:".
        "404 Not found: Dataset prj:ds was not found in location US Job ID: b3abc342-16a7",
        "404 Not found: Table prj:ds.tbl",
    ],
)
def test_is_transient_job_not_found_ignores_other_not_found(message):
    assert _is_transient_job_not_found(NotFound(message)) is False


@mock.patch("products.warehouse_sources.backend.temporal.data_imports.sources.bigquery.bigquery.time.sleep")
def test_run_destination_query_retries_transient_job_not_found(mock_sleep):
    """The copy-into-temp-table query is where the production sync crashed on BigQuery's job-metadata
    race; a transient job-not-found must be retried with a fresh job instead of aborting the import."""
    client = mock.MagicMock()
    ok_job = mock.MagicMock()
    client.query.side_effect = [NotFound("404 Not found: Job prj:US.abc"), ok_job]

    _run_destination_query_with_job_retry(
        client, "SELECT 1", destination_table=mock.MagicMock(), query_parameters=[], project="prj"
    )

    assert client.query.call_count == 2
    ok_job.result.assert_called_once()
    mock_sleep.assert_called_once()
    # WRITE_TRUNCATE keeps the re-run idempotent against a temp table a lost first attempt populated.
    assert client.query.call_args.kwargs["job_config"].write_disposition == "WRITE_TRUNCATE"


@mock.patch("products.warehouse_sources.backend.temporal.data_imports.sources.bigquery.bigquery.time.sleep")
def test_run_destination_query_does_not_retry_genuine_not_found(mock_sleep):
    """A genuine `NotFound` (missing dataset/table) is not the job race, so it surfaces immediately
    rather than looping until the attempt cap."""
    client = mock.MagicMock()
    client.query.side_effect = NotFound("404 Not found: Table prj:ds.tbl")

    with pytest.raises(NotFound):
        _run_destination_query_with_job_retry(
            client, "SELECT 1", destination_table=mock.MagicMock(), query_parameters=[], project="prj"
        )

    assert client.query.call_count == 1
    mock_sleep.assert_not_called()


@mock.patch(
    "products.warehouse_sources.backend.temporal.data_imports.sources.bigquery.bigquery._JOB_NOT_FOUND_MAX_ATTEMPTS",
    4,
)
@mock.patch("products.warehouse_sources.backend.temporal.data_imports.sources.bigquery.bigquery.time.sleep")
def test_run_destination_query_gives_up_after_max_attempts(mock_sleep):
    """The race almost always clears within moments, but a persistent job-not-found must still stop
    at the attempt cap and surface the error instead of retrying forever."""
    client = mock.MagicMock()
    client.query.side_effect = [NotFound("404 Not found: Job prj:US.abc") for _ in range(4)]

    with pytest.raises(NotFound):
        _run_destination_query_with_job_retry(
            client, "SELECT 1", destination_table=mock.MagicMock(), query_parameters=[], project="prj"
        )

    assert client.query.call_count == 4
    # No back-off after the final, failed attempt.
    assert mock_sleep.call_count == 3


@pytest.mark.parametrize(
    "location",
    ["US", "EU", "asia-northeast1"],
)
def test_bigquery_dataset_not_found_in_location_is_non_retryable(location):
    """A deleted/renamed dataset (or one in a region we don't query) surfaces from schema
    discovery as a google-api-core NotFound. Its str() is "404 Not found: Dataset ... was
    not found in location <X>", which must be recognised as non-retryable via the
    "was not found in location" pattern instead of retrying forever."""
    error = NotFound(
        f"Not found: Dataset my-proj:my_dataset was not found in location {location}; "
        f"reason: notFound, message: Not found: Dataset my-proj:my_dataset was not found in location {location}"
    )

    # Mirror the substring match in `sync_new_schemas_activity` / `update_external_data_job_model`.
    error_msg = str(error)
    non_retryable_errors = BigQuerySource().get_non_retryable_errors()

    assert any(pattern in error_msg for pattern in non_retryable_errors)


@pytest.mark.parametrize(
    "location",
    ["ua", "us-fake1", "EU "],
)
def test_bigquery_unsupported_region_is_non_retryable(location):
    """A custom/auto-detected region BigQuery can't run query jobs in surfaces from job creation as
    a 400 BadRequest whose str() is "... Location <X> does not support this operation.". It's a
    deterministic config error — retrying the same location always fails — so it must be recognised
    as non-retryable via the "does not support this operation" pattern rather than retrying forever.
    The volatile location code must not be part of the match."""
    error_msg = str(
        BadRequest(
            f"POST https://bigquery.googleapis.com/bigquery/v2/projects/my-proj/jobs?prettyPrint=false: "
            f"Location {location} does not support this operation."
        )
    )

    non_retryable_errors = BigQuerySource().get_non_retryable_errors()
    matching = [key for key in non_retryable_errors if key in error_msg]

    assert matching, "an unsupported-region 400 should be recognised as non-retryable"
    assert all(non_retryable_errors[key] is not None for key in matching)
    assert all(location not in key for key in matching), "match must not depend on the volatile location"


def test_bigquery_dataset_not_found_during_sync_is_non_retryable():
    """A dataset deleted/renamed after schema discovery surfaces from `get_table()` at sync time as a
    google NotFound whose str() is "... Not found: Dataset <project>:<dataset>" — this REST GET path
    carries no "was not found in location" suffix, unlike the query-job path covered by that pattern,
    so it must be recognised as non-retryable via the "Not found: Dataset" pattern instead of retrying
    a dataset that can't reappear within the run."""
    error = NotFound(
        "GET https://bigquery.googleapis.com/bigquery/v2/projects/my-proj/datasets/my_dataset/"
        "tables/my_table?prettyPrint=false: Not found: Dataset my-proj:my_dataset"
    )

    # Mirror the substring match in `update_external_data_job_model`.
    error_msg = str(error)
    non_retryable_errors = BigQuerySource().get_non_retryable_errors()
    matching = [key for key in non_retryable_errors if key in error_msg]

    assert matching, "a dataset-not-found 404 during sync should be recognised as non-retryable"
    assert all(non_retryable_errors[key] is not None for key in matching)
    assert "was not found in location" not in error_msg


def test_bigquery_table_not_found_during_sync_is_non_retryable():
    """A table deleted/renamed after schema discovery surfaces from `get_table()` at sync time as a
    google NotFound whose str() is "... Not found: Table <project>:<dataset>.<table>" — distinct from
    the dataset-region "was not found in location" wording. It must be recognised as non-retryable via
    the "Not found: Table" pattern instead of retrying a table that can't reappear within the run."""
    error = NotFound(
        "GET https://bigquery.googleapis.com/bigquery/v2/projects/my-proj/datasets/my_dataset/"
        "tables/my_table?prettyPrint=false: Not found: Table my-proj:my_dataset.my_table"
    )

    # Mirror the substring match in `update_external_data_job_model`.
    error_msg = str(error)
    non_retryable_errors = BigQuerySource().get_non_retryable_errors()
    matching = [key for key in non_retryable_errors if key in error_msg]

    assert matching, "a table-not-found 404 during sync should be recognised as non-retryable"
    assert all(non_retryable_errors[key] is not None for key in matching)
    assert "was not found in location" not in error_msg


def test_bigquery_project_not_found_during_sync_is_non_retryable():
    """A source referencing a deleted or mistyped GCP project surfaces from `get_table()` at sync time
    as a google NotFound whose str() is "... Project <id> is not found. Make sure it references valid
    GCP project that hasn't been deleted." — distinct from the table/dataset "Not found" wording. It
    must be recognised as non-retryable instead of retrying a project that can't reappear within the run."""
    error = NotFound(
        "GET https://bigquery.googleapis.com/bigquery/v2/projects/my-proj/datasets/my_dataset/"
        "tables/my_table?prettyPrint=false: Project my-proj is not found. Make sure it references "
        "valid GCP project that hasn't been deleted.; Project id: my-proj"
    )

    error_msg = str(error)
    non_retryable_errors = BigQuerySource().get_non_retryable_errors()
    matching = [key for key in non_retryable_errors if key in error_msg]

    assert matching, "a project-not-found 404 during sync should be recognised as non-retryable"
    assert all(non_retryable_errors[key] is not None for key in matching)
    assert "Not found: Table" not in error_msg
    assert "was not found in location" not in error_msg


def test_bigquery_storage_read_client_disables_grpc_message_size_limit():
    """Regression: the Storage Read API streams Arrow ReadRowsResponse messages that can
    exceed gRPC's default 4 MiB client receive limit (wide rows / large string columns like
    GeoJSON), which surfaced as `_MultiThreadedRendezvous` RESOURCE_EXHAUSTED "Received
    message larger than max". Because we build the channel ourselves, we must pass the same
    unlimited message-length options the transport sets on its own default channel."""
    with (
        mock.patch.object(bq_module.service_account.Credentials, "from_service_account_info", return_value=mock.Mock()),
        mock.patch.object(bq_module, "make_tracked_channel", return_value=mock.Mock()),
        mock.patch.object(bq_module, "BigQueryReadGrpcTransport") as mock_transport_cls,
        mock.patch.object(bq_module.bigquery_storage, "BigQueryReadClient"),
    ):
        with bq_module.bigquery_storage_read_client(
            project_id="project-id",
            private_key="private-key",
            private_key_id="private-key-id",
            client_email="client-email",
            token_uri="token-uri",
        ):
            pass

    mock_transport_cls.create_channel.assert_called_once()
    options = dict(mock_transport_cls.create_channel.call_args.kwargs["options"])
    assert options["grpc.max_receive_message_length"] == -1
    assert options["grpc.max_send_message_length"] == -1


def test_bigquery_billing_not_enabled_is_non_retryable():
    # A `billingNotEnabled` Forbidden 403 is a customer config issue — retrying never helps.
    # Representative message from a real failed job (the `reason: billingNotEnabled` 403 raised
    # by `job.result()` when the source project has BigQuery billing disabled / is in sandbox mode).
    internal_error = (
        "Forbidden: 403 Billing has not been enabled for this project. Enable billing at "
        "https://console.cloud.google.com/billing. Datasets must have a default expiration time "
        "and default partition expiration time of less than 60 days while in sandbox mode.; "
        "reason: billingNotEnabled, message: Billing has not been enabled for this project."
    )

    non_retryable_errors = BigQuerySource().get_non_retryable_errors()

    billing_key = "Billing has not been enabled for this project"
    assert billing_key in non_retryable_errors, "expected billing key to be non-retryable"
    # Mirror the substring match used by `update_external_data_job_model`.
    assert billing_key in internal_error


def test_bigquery_cdc_staleness_is_non_retryable():
    """A CDC table whose pending upserts are staler than its max_staleness can't be read via the
    Storage Read API (it never applies CDC changes), so the read fails as an InvalidArgument.
    Retrying within the sync's window can't recover it — the apply happens on BigQuery's schedule —
    so it must be recognised as non-retryable instead of hammering the Read API every attempt."""
    error_msg = str(
        InvalidArgument(
            "request failed: The table has un-applied upsert data that is not fresh enough to meet "
            "table's max_staleness."
        )
    )

    non_retryable_errors = BigQuerySource().get_non_retryable_errors()
    matching = [key for key in non_retryable_errors if key in error_msg]

    assert matching, "CDC max_staleness read failure should be recognised as non-retryable"
    assert all(non_retryable_errors[key] is not None for key in matching)


@pytest.mark.parametrize(
    "other_error",
    [
        # A genuine config error about max_staleness must not be swallowed by the freshness key.
        "400 Invalid value for max_staleness: must be a valid INTERVAL",
        # Transient server errors must stay retryable.
        "503 Service unavailable, please retry",
    ],
)
def test_bigquery_cdc_staleness_key_does_not_match_unrelated_errors(other_error):
    non_retryable_errors = BigQuerySource().get_non_retryable_errors()
    assert "un-applied upsert data that is not fresh enough" not in other_error
    assert not any(key in other_error for key in non_retryable_errors)


def test_bigquery_resources_exceeded_is_non_retryable():
    """A `resourcesExceeded` query failure exceeds a worker's memory deterministically (heavy sorts /
    analytic OVER() clauses over a large table or view), so retrying the identical temp-table copy in
    `_run_destination_query_with_job_retry` always fails — it must be recognised as non-retryable
    rather than retried on every attempt."""
    error_msg = str(
        BadRequest(
            "GET https://bigquery.googleapis.com/bigquery/v2/projects/<redacted>/queries/<redacted>"
            "?maxResults=0&location=us-central1&prettyPrint=false: Resources exceeded during query "
            "execution: The query could not be executed in the allotted memory. Peak usage: 122% of limit."
        )
    )

    non_retryable_errors = BigQuerySource().get_non_retryable_errors()
    matching = [key for key in non_retryable_errors if key in error_msg]

    assert matching, "resourcesExceeded query failure should be recognised as non-retryable"
    assert all(non_retryable_errors[key] is not None for key in matching)


def test_bigquery_on_demand_ratio_exceeded_is_non_retryable():
    """A query whose CPU-second usage relative to billed bytes exceeds the on-demand pricing
    model's ratio fails deterministically for the same query shape and billing tier, so retrying
    the identical temp-table copy in `_run_destination_query_with_job_retry` always fails — it must
    be recognised as non-retryable rather than retried on every attempt."""
    error_msg = str(
        BadRequest(
            "GET https://bigquery.googleapis.com/bigquery/v2/projects/<redacted>/queries/<redacted>"
            "?maxResults=0&location=us-central1&prettyPrint=false: Query exceeded resource limits. "
            "This query used 553474 CPU seconds but would charge only 1031M Analysis bytes. This "
            "exceeds the ratio supported by the on-demand pricing model, which does not have this "
            "limit. 553474 CPU seconds were used, and this query must use less than 263900 CPU seconds."
        )
    )

    non_retryable_errors = BigQuerySource().get_non_retryable_errors()
    matching = [key for key in non_retryable_errors if key in error_msg]

    assert matching, "on-demand pricing ratio failure should be recognised as non-retryable"
    assert all(non_retryable_errors[key] is not None for key in matching)


def test_bigquery_source_declares_v2_as_default():
    # The core of this PR: v2 is a supported version and the default for new sources, while the
    # legacy label stays supported so existing pins keep resolving. Guards a revert of the default
    # bump or an accidental drop of a supported label (base-class pin resolution itself is already
    # covered by the registry-invariant suite).
    source = BigQuerySource()
    assert source.supported_versions == ("v1", "v2")
    assert source.default_version == "v2"


@pytest.mark.parametrize("pin,expected_segment", [("v1", "v2"), ("v2", "v2"), (None, "v2"), ("v99", "v2")])
def test_bigquery_rest_api_version_maps_labels_to_v2(pin, expected_segment):
    # Both supported labels (and any fallback) resolve to BigQuery's single stable REST path
    # segment — a wrong mapping would point the client at a nonexistent /bigquery/<x>/ endpoint.
    assert bq_module._bigquery_rest_api_version(pin) == expected_segment


@pytest.mark.parametrize("pin", ["v1", "v2"])
def test_bigquery_build_pipeline_threads_resolved_rest_api_version(pin):
    # The source's version pin must reach the request layer (the REST segment the read/query
    # clients run under); dropping it would stop a future version from dispatching.
    with (
        mock.patch(
            "products.warehouse_sources.backend.temporal.data_imports.sources.bigquery.bigquery.delete_all_temp_destination_tables",
        ),
        mock.patch.object(
            BigQueryImplementation, "_build_source_response", return_value=mock.MagicMock()
        ) as mock_build,
        mock.patch(
            "products.warehouse_sources.backend.temporal.data_imports.sources.bigquery.bigquery.delete_table",
        ),
    ):
        BigQuerySource().source_for_pipeline(_make_config(), _make_inputs(api_version=pin))

    assert mock_build.call_args.kwargs["rest_api_version"] == "v2"
