import copy
from collections.abc import Iterable
from datetime import date, datetime, timedelta
from typing import Any, Optional
from urllib.parse import urlsplit
from zoneinfo import ZoneInfo

import structlog
from dateutil import parser
from requests import Request, Response
from requests.exceptions import HTTPError, RequestException, Timeout

from products.warehouse_sources.backend.temporal.data_imports.sources.common.http import make_tracked_session
from products.warehouse_sources.backend.temporal.data_imports.sources.common.integration_accounts import (
    IntegrationAccountListingError,
)
from products.warehouse_sources.backend.temporal.data_imports.sources.common.rest_source.paginators import BasePaginator
from products.warehouse_sources.backend.temporal.data_imports.sources.snapchat_ads.settings import (
    BASE_URL,
    MAX_SNAPCHAT_DAYS_TO_QUERY,
    EndpointType,
)

logger = structlog.get_logger(__name__)

SNAPCHAT_DATE_FORMAT = "%Y-%m-%dT00:00:00"

# HTTP status codes that should trigger a retry
# https://developers.snap.com/api/marketing-api/Ads-API/errors
RETRYABLE_STATUS_CODES = [429, 500, 503]


AD_ACCOUNTS_PAGE_LIMIT = 50
# Guards against a malformed/looping `next_link`; far above any real org count.
MAX_AD_ACCOUNT_PAGES = 100

# Every pagination request carries the bearer token, so we only ever follow a `next_link`
# that stays on Snapchat's API host over HTTPS.
_EXPECTED_API_HOST = urlsplit(BASE_URL).hostname


def _validate_pagination_url(url: str) -> None:
    """Reject a `next_link` that isn't HTTPS on Snapchat's API host.

    Each pagination request attaches the OAuth bearer token, so a cross-origin
    `next_link` would leak it to another host. Defense-in-depth behind the egress
    proxy: fail closed rather than follow an unexpected origin.
    """
    parts = urlsplit(url)
    if parts.scheme != "https" or parts.hostname != _EXPECTED_API_HOST:
        raise IntegrationAccountListingError(
            "Snapchat returned an unexpected pagination link while listing ad accounts. Please try again."
        )


def _raise_for_in_body_failure(body: dict) -> None:
    """Snapchat can report failure in a 200 body via `request_status`, so `raise_for_status()` alone
    would let it through and leave the user with a silently empty picker."""
    request_status = body.get("request_status")
    if request_status is None or request_status == "SUCCESS":
        return
    message = body.get("debug_message") or body.get("display_message") or "Unknown API error"
    raise IntegrationAccountListingError(f"Snapchat could not list your ad accounts: {message}")


def list_ad_accounts(access_token: str) -> list[tuple[dict, str | None]]:
    """Snapchat nests them: `organizations[].organization.ad_accounts[]`, with a per-organization
    `sub_request_status` we skip unless it succeeded.
    """
    session = make_tracked_session(allow_redirects=False)
    url = f"{BASE_URL}/me/organizations"
    params: dict | None = {"with_ad_accounts": "true", "limit": AD_ACCOUNTS_PAGE_LIMIT}

    accounts: list[tuple[dict, str | None]] = []
    saw_organization = False
    saw_successful_organization = False

    for _ in range(MAX_AD_ACCOUNT_PAGES):
        response = session.get(
            url,
            headers={"Authorization": f"Bearer {access_token}"},
            params=params,
            timeout=30,
        )
        response.raise_for_status()
        body = response.json()
        _raise_for_in_body_failure(body)

        for wrapper in body.get("organizations") or []:
            saw_organization = True
            if wrapper.get("sub_request_status") != "SUCCESS":
                continue
            saw_successful_organization = True
            organization = wrapper.get("organization") or {}
            organization_name = organization.get("name")
            for account in organization.get("ad_accounts") or []:
                accounts.append((account, organization_name))

        next_link = (body.get("paging") or {}).get("next_link")
        if not next_link:
            break
        # next_link is an absolute URL that already carries the cursor and the original query.
        # Validate its origin before re-attaching the bearer token to it.
        _validate_pagination_url(next_link)
        url, params = next_link, None
    else:
        # Hitting the cap means a looping/oversized result set; returning the accounts gathered so
        # far would silently present a truncated (or cursor-duplicated) picker as complete.
        raise IntegrationAccountListingError(
            "Snapchat returned too many pages while listing ad accounts. Please try again."
        )

    if saw_organization and not saw_successful_organization:
        # Every org failed, so an empty list here means "we couldn't read them", not "you have none".
        raise IntegrationAccountListingError(
            "Snapchat could not return the ad accounts for any of your organizations. "
            "Please make sure the connected account can access them and try again."
        )

    return accounts


def fetch_account_metadata(ad_account_id: str, access_token: str) -> tuple[str | None, str | None]:
    """Fetch the currency and timezone configured on the Snapchat ad account.

    Snapchat stats don't include currency per row (unlike Meta), so we fetch it
    from the ad account endpoint once per sync. The account timezone is needed to
    align DAY-granularity stats date boundaries to the account's local midnight.
    """
    try:
        response = make_tracked_session().get(
            f"{BASE_URL}/adaccounts/{ad_account_id}",
            headers={"Authorization": f"Bearer {access_token}"},
            timeout=30,
        )
        response.raise_for_status()
        data = response.json()
        adaccounts = data.get("adaccounts", [])
        if adaccounts:
            account = adaccounts[0].get("adaccount", {})
            currency = account.get("currency")
            timezone = account.get("timezone")
            if currency:
                logger.info("snapchat_ads_account_currency", ad_account_id=ad_account_id, currency=currency)
            return (str(currency) if currency else None, str(timezone) if timezone else None)
    except Exception as e:
        logger.warning("snapchat_ads_account_metadata_fetch_failed", ad_account_id=ad_account_id, error=str(e))
    return (None, None)


def format_stats_day_boundary(dt: datetime, account_timezone: str | None) -> str:
    """Render a stats date boundary the way Snapchat's DAY granularity requires.

    Snapchat rejects the request with a 400 unless start_time/end_time fall on the
    start of a day in the ad account's timezone, including the correct (DST-aware)
    UTC offset. A naive timestamp gets misaligned whenever the account isn't in UTC
    or the range crosses a DST change, so localize each boundary to the account
    timezone before formatting.
    """
    if account_timezone:
        try:
            return dt.replace(tzinfo=ZoneInfo(account_timezone)).isoformat()
        except Exception:
            logger.warning("snapchat_ads_invalid_account_timezone", timezone=account_timezone)
    return dt.strftime(SNAPCHAT_DATE_FORMAT)


class SnapchatAdsAPIError(Exception):
    """Custom exception for Snapchat Ads API errors that should trigger retries."""

    def __init__(self, message: str, error_code: str | None = None, response: Optional[Response] = None):
        super().__init__(message)
        self.error_code = error_code
        self.response = response


class SnapchatErrorHandler:
    """Centralized error handling for Snapchat API."""

    @staticmethod
    def is_retryable(exception: Exception) -> bool:
        """Determine if exception should trigger a retry."""
        if isinstance(exception, SnapchatAdsAPIError):
            return True

        if isinstance(exception, HTTPError) and hasattr(exception, "response") and exception.response is not None:
            return exception.response.status_code in RETRYABLE_STATUS_CODES

        if isinstance(exception, Timeout | RequestException):
            return True

        return False


class SnapchatDateRangeManager:
    """Handles date range calculations and chunking for Snapchat API requests."""

    DEFAULT_LOOKBACK_DAYS = 365

    @staticmethod
    def get_incremental_range(
        should_use_incremental_field: bool, db_incremental_field_last_value: Optional[Any] = None
    ) -> tuple[str, str]:
        """Calculate date range for incremental sync based on last synced value."""
        ends_at = (datetime.now() + timedelta(days=1)).strftime(SNAPCHAT_DATE_FORMAT)

        if should_use_incremental_field and db_incremental_field_last_value:
            try:
                if isinstance(db_incremental_field_last_value, datetime):
                    last_datetime = db_incremental_field_last_value
                elif isinstance(db_incremental_field_last_value, date):
                    last_datetime = datetime.combine(db_incremental_field_last_value, datetime.min.time())
                elif isinstance(db_incremental_field_last_value, str):
                    last_datetime = parser.parse(db_incremental_field_last_value)
                else:
                    last_datetime = datetime.fromisoformat(str(db_incremental_field_last_value))

                starts_at = last_datetime.strftime(SNAPCHAT_DATE_FORMAT)

            except Exception:
                starts_at = (datetime.now() - timedelta(days=SnapchatDateRangeManager.DEFAULT_LOOKBACK_DAYS)).strftime(
                    SNAPCHAT_DATE_FORMAT
                )
        else:
            starts_at = (datetime.now() - timedelta(days=SnapchatDateRangeManager.DEFAULT_LOOKBACK_DAYS)).strftime(
                SNAPCHAT_DATE_FORMAT
            )

        return starts_at, ends_at

    @staticmethod
    def generate_chunks(
        start_date: str,
        end_date: str,
        chunk_days: int = MAX_SNAPCHAT_DAYS_TO_QUERY,
        account_timezone: str | None = None,
    ) -> list[tuple[str, str]]:
        """
        Generate date chunks that respect Snapchat's 31-day limit.
        Returns list of (start_date, end_date) tuples for sequential API calls.

        Day arithmetic stays on naive calendar dates so each chunk spans whole
        days; the boundaries are localized to ``account_timezone`` only at the
        formatting step so every boundary picks up its own DST-correct offset.
        """
        start_dt = datetime.fromisoformat(start_date)
        end_dt = datetime.fromisoformat(end_date)

        chunks = []
        current_start = start_dt

        while current_start < end_dt:
            chunk_end = current_start + timedelta(days=chunk_days - 1)

            if chunk_end >= end_dt:
                chunk_end = end_dt - timedelta(days=1)

            # Snapchat requires end_time to be at the beginning of an hour
            # So we use the next day at 00:00:00 instead of 23:59:59
            chunk_end_for_api = chunk_end + timedelta(days=1)

            chunks.append(
                (
                    format_stats_day_boundary(current_start, account_timezone),
                    format_stats_day_boundary(chunk_end_for_api, account_timezone),
                )
            )

            current_start = chunk_end + timedelta(days=1)

        return chunks


class SnapchatStatsResource:
    """Handles stats-specific operations like flattening and date chunking."""

    @staticmethod
    def _stat_rows(entry: dict[str, Any], base: dict[str, Any], currency: str | None) -> list[dict[str, Any]]:
        """Turn one stats entry into rows: one per dimension value, or a single totals row.

        A `report_dimension` request replaces the entry's `stats` object with a
        `dimension_stats` array, where each element carries the metrics plus the dimension
        columns it is broken down by (`country`, or `age_bucket` + `gender`).
        """
        dimension_stats = entry.get("dimension_stats")
        if dimension_stats is None:
            rows = [{**base, **entry.get("stats", {})}]
        else:
            rows = [{**base, **dimension_stat} for dimension_stat in dimension_stats]

        if currency:
            for row in rows:
                row["currency"] = currency
        return rows

    @classmethod
    def transform_stats_reports(
        cls, reports: list[dict[str, Any]], currency: str | None = None
    ) -> list[dict[str, Any]]:
        """Flatten nested timeseries_stat structure to individual daily records.

        Handles the breakdown response format where stats are nested inside
        breakdown_stats.<breakdown_key>[].timeseries rather than directly
        in timeseries_stat.timeseries.
        """
        processed_reports = []

        for report in reports:
            timeseries_stat = report.get("timeseries_stat", report)
            breakdown_stats = timeseries_stat.get("breakdown_stats")

            if breakdown_stats:
                entities = [entity for entities in breakdown_stats.values() for entity in entities]
            else:
                entities = [timeseries_stat]

            for entity in entities:
                base = {"id": entity.get("id"), "type": entity.get("type")}
                timeseries = entity.get("timeseries", [])

                for ts_entry in timeseries:
                    entry_base = {
                        **base,
                        "start_time": ts_entry.get("start_time"),
                        "end_time": ts_entry.get("end_time"),
                    }
                    processed_reports.extend(cls._stat_rows(ts_entry, entry_base, currency))

                # Delivery-insights responses are only documented at TOTAL granularity, where
                # the breakdown hangs off the entity itself rather than a per-day entry. Keep
                # those rows instead of dropping them, dated with the entity's own range.
                if not timeseries and entity.get("dimension_stats") is not None:
                    entity_base = {
                        **base,
                        "start_time": entity.get("start_time"),
                        "end_time": entity.get("end_time"),
                    }
                    processed_reports.extend(cls._stat_rows(entity, entity_base, currency))

        return processed_reports

    @staticmethod
    def transform_entity_reports(reports: list[dict[str, Any]], entity_key: str | None = None) -> list[dict[str, Any]]:
        """Extract inner objects from wrapped entity responses (campaign/adsquad/ad/...)."""
        processed_reports = []

        for report in reports:
            # Each item is wrapped: {"campaign": {...}} or {"adsquad": {...}} or {"ad": {...}}
            inner_keys = [entity_key] if entity_key else ["campaign", "adsquad", "ad"]
            for key in inner_keys:
                if key in report:
                    processed_reports.append(report[key])
                    break
            else:
                # No wrapper found, use as-is
                processed_reports.append(report)

        return processed_reports

    @classmethod
    def apply_stream_transformations(
        cls,
        endpoint_type: EndpointType,
        reports: Iterable[Any],
        currency: str | None = None,
        entity_key: str | None = None,
    ) -> list[dict[str, Any]]:
        """Apply transformations based on endpoint type."""
        reports_list = list(reports)

        match endpoint_type:
            case EndpointType.STATS:
                return cls.transform_stats_reports(reports_list, currency=currency)
            case EndpointType.ENTITY:
                return cls.transform_entity_reports(reports_list, entity_key=entity_key)
            case EndpointType.ACCOUNT:
                return reports_list

    @classmethod
    def create_chunked_resources(
        cls,
        base_resource_config: dict,
        start_date: str,
        end_date: str,
        ad_account_id: str,
        chunk_days: int = MAX_SNAPCHAT_DAYS_TO_QUERY,
        account_timezone: str | None = None,
    ) -> list[dict]:
        """Create chunked resources for date range queries."""
        date_chunks = SnapchatDateRangeManager.generate_chunks(start_date, end_date, chunk_days, account_timezone)
        resources = []

        for i, (chunk_start, chunk_end) in enumerate(date_chunks):
            resource_config = copy.deepcopy(base_resource_config)

            resource_name = f"{base_resource_config['name']}_chunk_{i}"
            resource_config["name"] = resource_name
            resource_config["table_name"] = base_resource_config.get("table_name", base_resource_config["name"])

            endpoint = resource_config["endpoint"]
            params = endpoint.get("params", {})

            # Replace placeholders in params
            params = {
                key: (
                    value.format(ad_account_id=ad_account_id, start_time=chunk_start, end_time=chunk_end)
                    if isinstance(value, str)
                    else value
                )
                for key, value in params.items()
            }

            # Replace path placeholder
            endpoint["path"] = endpoint["path"].format(ad_account_id=ad_account_id)
            endpoint["params"] = params

            if "incremental" in endpoint:
                del endpoint["incremental"]

            resource_config["endpoint"] = endpoint
            resources.append(resource_config)

        return resources

    @classmethod
    def process_resources(cls, dlt_resources: list) -> Iterable[Any]:
        """
        Process and flatten DLT resources from stats endpoints.
        Handles both single and multiple chunked resources.
        """
        result = []

        for resource in dlt_resources:
            result.extend(cls._flatten_single_resource(resource))

        return result

    @classmethod
    def _flatten_single_resource(cls, resource: Any) -> list[dict[str, Any]]:
        result = []
        for item in resource:
            if isinstance(item, list):
                result.extend(item)
            elif isinstance(item, dict):
                result.append(item)
            else:
                result.append(item)
        return result

    @classmethod
    def setup_stats_resources(
        cls,
        base_resource_config: dict,
        ad_account_id: str,
        should_use_incremental_field: bool,
        db_incremental_field_last_value: Optional[Any],
        account_timezone: str | None = None,
    ) -> list[dict]:
        """
        Setup stats resources with proper date chunking.
        Calculates date ranges and creates chunked resources.
        """
        starts_at, ends_at = SnapchatDateRangeManager.get_incremental_range(
            should_use_incremental_field, db_incremental_field_last_value
        )

        return cls.create_chunked_resources(
            base_resource_config, starts_at, ends_at, ad_account_id, account_timezone=account_timezone
        )


class SnapchatAdsPaginator(BasePaginator):
    """Cursor-based paginator using next_link from paging object."""

    def __init__(self):
        super().__init__()
        self._has_next_page = False
        self._next_link: Optional[str] = None

    def update_state(self, response: Response, data: Optional[Any] = None) -> None:
        """Update pagination state from Snapchat API response."""
        try:
            json_data = response.json()
            # Snapchat documents this status in both cases across endpoints, so compare case-insensitively.
            request_status = str(json_data.get("request_status", "")).upper()

            if request_status == "SUCCESS":
                paging = json_data.get("paging", {})
                self._next_link = paging.get("next_link")
                self._has_next_page = bool(self._next_link)
            else:
                self._has_next_page = False
                error_message = json_data.get("debug_message", json_data.get("display_message", "Unknown API error"))
                error_code = json_data.get("error_code")

                logger.error(
                    "snapchat_ads_api_error",
                    error_code=error_code,
                    message=error_message,
                    response_status=response.status_code,
                )

                if response.status_code in RETRYABLE_STATUS_CODES:
                    raise SnapchatAdsAPIError(
                        f"Snapchat API error: {error_message} (code: {error_code})",
                        error_code=error_code,
                        response=response,
                    )
                else:
                    raise ValueError(f"Snapchat API client error (non-retryable): {error_message} (code: {error_code})")

        except SnapchatAdsAPIError:
            raise
        except ValueError:
            raise
        except Exception as e:
            self._has_next_page = False
            logger.exception("snapchat_ads_paginator_error", error=str(e))
            raise SnapchatAdsAPIError(f"Failed to parse Snapchat API response: {str(e)}", response=response)

    def _apply_next_link_cursor(self, request: Request) -> None:
        """Extract cursor from next_link and add to request params."""
        if not self._next_link:
            return

        from urllib.parse import parse_qs, urlparse

        parsed = urlparse(self._next_link)
        query_params = parse_qs(parsed.query)
        cursor = query_params.get("cursor")
        if not cursor:
            return

        if request.params is None:
            request.params = {}
        request.params["cursor"] = cursor[0]

    def init_request(self, request: Request) -> None:
        # When seeded via set_resume_state the paginator already knows the
        # next_link for the resumed page — inject its cursor into the initial
        # request so we don't re-issue the first page.
        self._apply_next_link_cursor(request)

    def update_request(self, request: Request) -> None:
        self._apply_next_link_cursor(request)

    def get_resume_state(self) -> Optional[dict[str, Any]]:
        if self._next_link and self._has_next_page:
            return {"next_link": self._next_link}
        return None

    def set_resume_state(self, state: dict[str, Any]) -> None:
        next_link = state.get("next_link")
        if next_link:
            self._next_link = next_link
            self._has_next_page = True
