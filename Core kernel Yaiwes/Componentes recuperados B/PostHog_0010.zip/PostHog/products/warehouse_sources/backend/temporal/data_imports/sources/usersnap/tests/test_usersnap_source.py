import pytest
from unittest import mock

from products.warehouse_sources.backend.temporal.data_imports.sources.generated_configs.usersnap import (
    UsersnapSourceConfig,
)
from products.warehouse_sources.backend.temporal.data_imports.sources.usersnap.settings import (
    ENDPOINTS,
    INCREMENTAL_FIELDS,
)
from products.warehouse_sources.backend.temporal.data_imports.sources.usersnap.source import UsersnapSource


class TestUsersnapSource:
    def setup_method(self):
        self.source = UsersnapSource()
        self.team_id = 123
        self.config = UsersnapSourceConfig(jwt_secret="shared-secret", jwt_id="jwt-id-123")

    @pytest.mark.parametrize(
        "observed_error",
        [
            "401 Client Error: Unauthorized for url: https://platform.usersnap.com/v0.1/projects",
            "403 Client Error: Forbidden for url: https://platform.usersnap.com/v0.1/projects/p1/feedbacks/filter?limit=100",
        ],
    )
    def test_non_retryable_errors_match_auth_failures(self, observed_error):
        non_retryable_errors = self.source.get_non_retryable_errors()
        assert any(key in observed_error for key in non_retryable_errors)

    @pytest.mark.parametrize(
        "other_vendor_error",
        [
            "401 Client Error: Unauthorized for url: https://api.stripe.com/v1/customers",
            "500 Server Error for url: https://platform.usersnap.com/v0.1/projects",
        ],
    )
    def test_non_retryable_errors_does_not_match_unrelated(self, other_vendor_error):
        non_retryable_errors = self.source.get_non_retryable_errors()
        assert not any(key in other_vendor_error for key in non_retryable_errors)

    def test_get_schemas(self):
        schemas = self.source.get_schemas(self.config, self.team_id)

        assert {schema.name for schema in schemas} == set(ENDPOINTS)
        incremental = {schema.name for schema in schemas if schema.supports_incremental}
        # Only the feedbacks/filter endpoint exposes a server-side created_at filter.
        assert incremental == {"feedbacks"}
        # The gte filter re-pulls the watermark row, so every table is merge/full-refresh only.
        assert all(schema.supports_append is False for schema in schemas)

    def test_incremental_schema_advertises_created_at(self):
        schemas = {schema.name: schema for schema in self.source.get_schemas(self.config, self.team_id)}

        assert schemas["feedbacks"].incremental_fields == INCREMENTAL_FIELDS["feedbacks"]
        assert schemas["projects"].incremental_fields == []

    def test_get_schemas_filtered_by_names(self):
        schemas = self.source.get_schemas(self.config, self.team_id, names=["feedbacks"])
        assert len(schemas) == 1
        assert schemas[0].name == "feedbacks"

    def test_get_schemas_filtered_unknown_name_returns_empty(self):
        assert self.source.get_schemas(self.config, self.team_id, names=["nope"]) == []

    @pytest.mark.parametrize(
        "mock_return, expected_valid",
        [
            (True, True),
            (False, False),
        ],
    )
    @mock.patch(
        "products.warehouse_sources.backend.temporal.data_imports.sources.usersnap.source.validate_usersnap_credentials"
    )
    def test_validate_credentials(self, mock_validate, mock_return, expected_valid):
        mock_validate.return_value = mock_return

        is_valid, error_message = self.source.validate_credentials(self.config, self.team_id)

        assert is_valid is expected_valid
        assert (error_message is None) is expected_valid
        mock_validate.assert_called_once_with(self.config.jwt_secret, self.config.jwt_id)
