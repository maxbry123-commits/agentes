#!/usr/bin/env node

import { appendFileSync } from 'node:fs';

class TagGenerator {
	constructor() {
		this.githubOwner = process.env.GITHUB_REPOSITORY_OWNER || 'n8n-io';
		this.dockerUsername = process.env.DOCKER_USERNAME || 'n8nio';
		this.githubOutput = process.env.GITHUB_OUTPUT || null;
	}

	generate({ image, version, platform, includeDockerHub = false, sha = '', date = '' }) {
		let imageName = image;
		let versionSuffix = '';

		if (image === 'runners-distroless') {
			imageName = 'runners';
			versionSuffix = '-distroless';
		}

		if (image === 'n8n-pc') {
			imageName = 'n8n';
			versionSuffix = '-pc';
		}

		const platformSuffix = platform ? `-${platform.split('/').pop()}` : '';
		const fullVersion = `${version}${versionSuffix}${platformSuffix}`;

		const tags = {
			ghcr: [`ghcr.io/${this.githubOwner}/${imageName}:${fullVersion}`],
			docker: includeDockerHub ? [`${this.dockerUsername}/${imageName}:${fullVersion}`] : [],
		};

		tags.all = [...tags.ghcr, ...tags.docker];

		// Generate additional SHA-based tags for immutable references
		if (sha) {
			const shaVersion = `${version}-${sha}`;
			const shaPlatformTag = `${shaVersion}${versionSuffix}${platformSuffix}`;
			const shaGhcr = [`ghcr.io/${this.githubOwner}/${imageName}:${shaPlatformTag}`];
			const shaDocker = includeDockerHub
				? [`${this.dockerUsername}/${imageName}:${shaPlatformTag}`]
				: [];
			tags.all = [...tags.all, ...shaGhcr, ...shaDocker];
			tags.ghcr = [...tags.ghcr, ...shaGhcr];
			tags.docker = [...tags.docker, ...shaDocker];
			tags.shaPrimaryTag = shaGhcr[0].replace(/-amd64$|-arm64$/, '');
		}

		// Generate additional date-based tags (e.g. v3-nightly-20260625) for nightly builds
		if (date) {
			const dateVersion = `${version}-${date}`;
			const datePlatformTag = `${dateVersion}${versionSuffix}${platformSuffix}`;
			const dateGhcr = [`ghcr.io/${this.githubOwner}/${imageName}:${datePlatformTag}`];
			const dateDocker = includeDockerHub
				? [`${this.dockerUsername}/${imageName}:${datePlatformTag}`]
				: [];
			tags.all = [...tags.all, ...dateGhcr, ...dateDocker];
			tags.ghcr = [...tags.ghcr, ...dateGhcr];
			tags.docker = [...tags.docker, ...dateDocker];
			tags.datePrimaryTag = dateGhcr[0].replace(/-amd64$|-arm64$/, '');
		}

		return tags;
	}

	output(tags, prefix = '') {
		if (this.githubOutput) {
			const prefixStr = prefix ? `${prefix}_` : '';
			const primaryTag = tags.ghcr[0] ? tags.ghcr[0].replace(/-amd64$|-arm64$/, '') : '';
			const outputs = [
				`${prefixStr}tags=${tags.all.join(',')}`,
				`${prefixStr}ghcr_tag=${tags.ghcr[0] || ''}`,
				`${prefixStr}docker_tag=${tags.docker[0] || ''}`,
				`${prefixStr}primary_tag=${primaryTag}`,
			];
			if (tags.shaPrimaryTag) {
				outputs.push(`${prefixStr}sha_primary_tag=${tags.shaPrimaryTag}`);
			}
			if (tags.datePrimaryTag) {
				outputs.push(`${prefixStr}date_primary_tag=${tags.datePrimaryTag}`);
			}
			appendFileSync(this.githubOutput, outputs.join('\n') + '\n');
		} else {
			console.log(JSON.stringify(tags, null, 2));
		}
	}

	generateAll({ version, platform, includeDockerHub = false, sha = '', date = '' }) {
		const images = ['n8n', 'n8n-pc', 'runners', 'runners-distroless'];
		const results = {};

		for (const image of images) {
			const tags = this.generate({ image, version, platform, includeDockerHub, sha, date });
			const prefix = image.replaceAll('-', '_');
			results[prefix] = tags;

			if (this.githubOutput) {
				this.output(tags, prefix);
			}
		}

		return results;
	}
}

if (import.meta.url === `file://${process.argv[1]}`) {
	const args = process.argv.slice(2);
	const getArg = (name) => {
		const index = args.indexOf(`--${name}`);
		return index !== -1 && args[index + 1] ? args[index + 1] : undefined;
	};
	const hasFlag = (name) => args.includes(`--${name}`);

	try {
		const generator = new TagGenerator();
		const version = getArg('version');

		if (!version) {
			console.error('Error: --version is required');
			process.exit(1);
		}

		if (hasFlag('all')) {
			const results = generator.generateAll({
				version,
				platform: getArg('platform'),
				includeDockerHub: hasFlag('include-docker'),
				sha: getArg('sha') || '',
				date: getArg('date') || '',
			});
			if (!generator.githubOutput) {
				console.log(JSON.stringify(results, null, 2));
			}
		} else {
			const image = getArg('image');
			if (!image) {
				console.error('Error: Either --image or --all is required');
				process.exit(1);
			}
			const tags = generator.generate({
				image,
				version,
				platform: getArg('platform'),
				includeDockerHub: hasFlag('include-docker'),
				sha: getArg('sha') || '',
				date: getArg('date') || '',
			});
			generator.output(tags);
		}
	} catch (error) {
		console.error(`Error: ${error.message}`);
		process.exit(1);
	}
}

export default TagGenerator;
