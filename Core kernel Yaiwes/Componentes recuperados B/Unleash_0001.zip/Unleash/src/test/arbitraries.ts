import fc, { type Arbitrary } from 'fast-check';

import {
    DATE_OPERATORS,
    NUM_OPERATORS,
    REGEX,
    SEMVER_OPERATORS,
    STRING_OPERATORS,
} from '../lib/util/constants.js';
import type { ClientFeatureSchema } from '../lib/openapi/spec/client-feature-schema.js';
import { type IVariant, WeightType } from '../lib/types/model.js';
import type { FeatureStrategySchema } from '../lib/openapi/spec/feature-strategy-schema.js';
import type { ConstraintSchema } from '../lib/openapi/spec/constraint-schema.js';
import type { SegmentSchema } from '../lib/openapi/spec/segment-schema.js';

type ConstraintOperator = ConstraintSchema['operator'];

const constraintOperator = (
    operators: readonly string[],
): Arbitrary<ConstraintOperator> =>
    fc.constantFrom(...(operators as ConstraintOperator[]));

const emptyValues = (): Arbitrary<string[]> => fc.constant([] as string[]);

export const urlFriendlyString = (): Arbitrary<string> =>
    fc
        .array(
            fc.oneof(
                fc.integer({ min: 0x30, max: 0x39 }).map(String.fromCharCode), // numbers
                fc.integer({ min: 0x41, max: 0x5a }).map(String.fromCharCode), // UPPERCASE LETTERS
                fc.integer({ min: 0x61, max: 0x7a }).map(String.fromCharCode), // lowercase letters
                fc.constantFrom('-', '_', '~', '.'), // rest
                fc.lorem({ maxCount: 1 }), // random words for more 'realistic' names
            ),
            { minLength: 1 },
        )
        .map((arr) => arr.join(''))
        // filter out strings that are only dots because they mess with url parsing
        .filter((string) => ![...string].every((char) => char === '.'));

export const commonISOTimestamp = (): Arbitrary<string> =>
    fc
        .date({
            min: new Date('1900-01-01T00:00:00.000Z'),
            max: new Date('9999-12-31T23:59:59.999Z'),
            noInvalidDate: true,
        })
        .map((timestamp) => timestamp.toISOString());

const nonEmptyString = (): Arbitrary<string> =>
    fc.string({ minLength: 1, maxLength: 100 });

const semverString = (): Arbitrary<string> =>
    fc
        .tuple(fc.nat({ max: 999 }), fc.nat({ max: 999 }), fc.nat({ max: 999 }))
        .map(([major, minor, patch]) => `${major}.${minor}.${patch}`);

const regexString = (): Arbitrary<string> =>
    fc.constantFrom('.*', 'a', '[a-z]+', '^test$');

export const strategyConstraint = (): Arbitrary<ConstraintSchema> =>
    fc.oneof(
        fc.record({
            contextName: urlFriendlyString(),
            operator: constraintOperator(STRING_OPERATORS),
            caseInsensitive: fc.boolean(),
            inverted: fc.boolean(),
            values: fc.array(nonEmptyString(), { minLength: 1 }),
        }),
        fc.record({
            contextName: urlFriendlyString(),
            operator: constraintOperator(NUM_OPERATORS),
            caseInsensitive: fc.boolean(),
            inverted: fc.boolean(),
            values: emptyValues(),
            value: fc.integer().map(String),
        }),
        fc.record({
            contextName: urlFriendlyString(),
            operator: constraintOperator(DATE_OPERATORS),
            caseInsensitive: fc.boolean(),
            inverted: fc.boolean(),
            values: emptyValues(),
            value: commonISOTimestamp(),
        }),
        fc.record({
            contextName: urlFriendlyString(),
            operator: constraintOperator(SEMVER_OPERATORS),
            caseInsensitive: fc.boolean(),
            inverted: fc.boolean(),
            values: emptyValues(),
            value: semverString(),
        }),
        fc.record({
            contextName: urlFriendlyString(),
            operator: fc.constant(REGEX as ConstraintOperator),
            caseInsensitive: fc.boolean(),
            inverted: fc.constant(false),
            values: emptyValues(),
            value: regexString(),
        }),
    );

const strategyConstraints = (): Arbitrary<ConstraintSchema[]> =>
    fc.array(strategyConstraint());

export const strategy = (
    name: string,
    parameters?: Arbitrary<Record<string, string>>,
): Arbitrary<FeatureStrategySchema> =>
    parameters
        ? fc.record(
              {
                  name: fc.constant(name),
                  id: fc.uuid(),
                  parameters,
                  segments: fc.uniqueArray(fc.integer({ min: 1 })),
                  constraints: strategyConstraints(),
              },
              { requiredKeys: ['name', 'parameters', 'id'] },
          )
        : fc.record(
              {
                  id: fc.uuid(),
                  name: fc.constant(name),
                  segments: fc.uniqueArray(fc.integer({ min: 1 })),
                  constraints: strategyConstraints(),
              },
              { requiredKeys: ['name', 'id'] },
          );

export const segment = (): Arbitrary<SegmentSchema> =>
    fc.record({
        id: fc.integer({ min: 1 }),
        name: urlFriendlyString(),
        constraints: strategyConstraints(),
    });

export const strategies = (): Arbitrary<FeatureStrategySchema[]> =>
    fc.uniqueArray(
        fc.oneof(
            strategy('default'),
            strategy(
                'flexibleRollout',
                fc.record({
                    groupId: fc.lorem({ maxCount: 1 }),
                    rollout: fc.nat({ max: 100 }).map(String),
                    stickiness: fc.constantFrom(
                        'default',
                        'userId',
                        'sessionId',
                    ),
                }),
            ),
            strategy(
                'applicationHostname',
                fc.record({
                    hostNames: fc
                        .uniqueArray(fc.domain())
                        .map((domains) => domains.join(',')),
                }),
            ),

            strategy(
                'remoteAddress',
                fc.record({
                    IPs: fc.uniqueArray(fc.ipV4()).map((ips) => ips.join(',')),
                }),
            ),
            strategy(
                'custom-strategy',
                fc.record({
                    customParam: fc
                        .uniqueArray(fc.lorem())
                        .map((words) => words.join(',')),
                }),
            ),
        ),
        { selector: (generatedStrategy) => generatedStrategy.id },
    );

export const variant = (): Arbitrary<IVariant> =>
    fc.record(
        {
            name: urlFriendlyString(),
            weight: fc.nat({ max: 1000 }),
            weightType: fc.constant(WeightType.VARIABLE),
            stickiness: fc.constant('default'),
            payload: fc.option(
                fc.oneof(
                    fc.record({
                        type: fc.constant('json' as const),
                        value: fc.json(),
                    }),
                    fc.record({
                        type: fc.constant('csv' as const),
                        value: fc
                            .array(fc.lorem())
                            .map((words) => words.join(',')),
                    }),
                    fc.record({
                        type: fc.constant('string' as const),
                        value: fc.string(),
                    }),
                ),
                { nil: undefined },
            ),
        },
        { requiredKeys: ['name', 'weight', 'weightType', 'stickiness'] },
    );

export const variants = (): Arbitrary<IVariant[]> =>
    fc
        .uniqueArray(variant(), {
            maxLength: 1000,
            selector: (variantInstance) => variantInstance.name,
        })
        .map((allVariants) =>
            allVariants.map((variantInstance) => ({
                ...variantInstance,
                weight: Math.round(1000 / allVariants.length),
            })),
        );

export const clientFeature = (name?: string): Arbitrary<ClientFeatureSchema> =>
    fc.record(
        {
            name: name ? fc.constant(name) : urlFriendlyString(),
            type: fc.constantFrom(
                'release',
                'kill-switch',
                'experiment',
                'operational',
                'permission',
                'sunset',
            ),
            description: fc.lorem(),
            project: urlFriendlyString(),
            enabled: fc.boolean(),
            createdAt: commonISOTimestamp(),
            lastSeenAt: commonISOTimestamp(),
            stale: fc.boolean(),
            impressionData: fc.option(fc.boolean(), { nil: undefined }),
            strategies: strategies(),
            variants: variants(),
        },
        { requiredKeys: ['name', 'enabled', 'project', 'strategies'] },
    );

export const clientFeatures = (constraints?: {
    minLength?: number;
}): Arbitrary<ClientFeatureSchema[]> =>
    fc.uniqueArray(clientFeature(), {
        ...constraints,
        selector: (v) => v.name,
    });

export const clientFeaturesAndSegments = (featureConstraints?: {
    minLength?: number;
}): Arbitrary<{
    features: ClientFeatureSchema[];
    segments: SegmentSchema[];
}> => {
    const segments = () =>
        fc.uniqueArray(segment(), {
            selector: (generatedSegment) => generatedSegment.id,
        });

    // create segments and make sure that all strategies reference segments that
    // exist
    return fc
        .tuple(segments(), clientFeatures(featureConstraints))
        .map(([generatedSegments, generatedFeatures]) => {
            const renumberedSegments = generatedSegments.map(
                (generatedSegment, index) => ({
                    ...generatedSegment,
                    id: index + 1,
                }),
            );

            const features: ClientFeatureSchema[] = generatedFeatures.map(
                (feature) => ({
                    ...feature,
                    ...(feature.strategies && {
                        strategies: feature.strategies.map(
                            (generatedStrategy) => ({
                                ...generatedStrategy,
                                ...(generatedStrategy.segments && {
                                    segments:
                                        renumberedSegments.length > 0
                                            ? [
                                                  ...new Set(
                                                      generatedStrategy.segments.map(
                                                          (generatedSegment) =>
                                                              (generatedSegment %
                                                                  renumberedSegments.length) +
                                                              1,
                                                      ),
                                                  ),
                                              ]
                                            : [],
                                }),
                            }),
                        ),
                    }),
                }),
            );

            return {
                features,
                segments: renumberedSegments,
            };
        });
};
