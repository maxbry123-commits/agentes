import { Client, useQuery, type UseQueryResponse } from 'urql';

import { useEnvironment } from '@/components/Environments/environment-context';
import { graphql } from '@/gql';
import type { GetFunctionQuery } from '@/gql/graphql';
import { useGraphQLQuery } from '@/utils/useGraphQLQuery';

const GetFunctionsUsageDocument = graphql(`
  query GetFunctionsUsage($environmentID: ID!, $page: Int, $archived: Boolean, $pageSize: Int) {
    workspace(id: $environmentID) {
      workflows(archived: $archived) @paginated(perPage: $pageSize, page: $page) {
        page {
          page
          perPage
          totalItems
          totalPages
        }
        data {
          app {
            name
            externalID
          }
          id
          slug
          name
          isPaused
          isArchived
          triggers {
            type
            value
          }
          dailyStarts: usage(opts: { period: "hour", range: "day" }, event: "started") {
            total
            data {
              slot
              count
            }
          }
          dailyCompleted: usage(opts: { period: "hour", range: "day" }, event: "completed") {
            total
            data {
              count
            }
          }
          dailyCancelled: usage(opts: { period: "hour", range: "day" }, event: "cancelled") {
            total
            data {
              count
            }
          }
          dailyFailures: usage(opts: { period: "hour", range: "day" }, event: "errored") {
            total
            data {
              count
            }
          }
        }
      }
    }
  }
`);

const GetFunctionsDocument = graphql(`
  query GetFunctions(
    $environmentID: ID!
    $page: Int
    $archived: Boolean
    $search: String
    $appIDs: [UUID!]
    $pageSize: Int
  ) {
    workspace(id: $environmentID) {
      workflows(archived: $archived, search: $search, appIDs: $appIDs) @paginated(perPage: $pageSize, page: $page) {
        page {
          page
          perPage
          totalItems
          totalPages
        }
        data {
          app {
            name
            externalID
          }
          id
          slug
          name
          isPaused
          isArchived
          triggers {
            type
            value
          }
        }
      }
    }
  }
`);

export function useFunctionsPage({
  archived,
  search,
  appIDs,
  envID,
  page,
}: {
  archived: boolean;
  search: string;
  appIDs?: string[] | null;
  envID: string;
  page: number;
}) {
  const pageSize = 50;
  const res = useGraphQLQuery({
    query: GetFunctionsDocument,
    variables: {
      archived,
      search,
      appIDs: appIDs ?? null,
      environmentID: envID,
      page,
      pageSize,
    },
  });
  if (!res.data) {
    return {
      ...res,
      data: undefined,
    };
  }

  return {
    ...res,
    data: {
      functions: res.data.workspace.workflows.data.map((fn) => {
        return {
          ...fn,
          failureRate: undefined,
          triggers: fn.triggers,
          usage: undefined,
        };
      }),
      page: {
        ...res.data.workspace.workflows.page,
        hasNextPage: res.data.workspace.workflows.data.length === pageSize,
      },
    },
  };
}

// TODO: remove current.triggers from this query after new FunctionConfiguration is fully rolled out
const GetFunctionDocument = graphql(`
  query GetFunction($slug: String!, $environmentID: ID!) {
    workspace(id: $environmentID) {
      id
      workflow: workflowBySlug(slug: $slug) {
        id
        name
        slug
        isPaused
        isArchived
        app {
          externalID
          name
          latestSync {
            lastSyncedAt
          }
        }
        triggers {
          type
          value
          condition
        }
        failureHandler {
          slug
          name
        }
        configuration {
          cancellations {
            event
            timeout
            condition
          }
          retries {
            value
            isDefault
          }
          priority
          eventsBatch {
            maxSize
            timeout
            key
          }
          concurrency {
            scope
            limit {
              value
              isPlanLimit
            }
            key
          }
          rateLimit {
            limit
            period
            key
          }
          debounce {
            period
            key
          }
          throttle {
            burst
            key
            limit
            period
          }
          singleton {
            key
            mode
          }
        }
        keyQueuesEnabled
      }
    }
  }
`);

type UseFunctionParams = {
  functionSlug: string;
};

export const useFunction = ({
  functionSlug,
}: UseFunctionParams): UseQueryResponse<
  GetFunctionQuery,
  { environmentID: string; slug: string }
> => {
  const environment = useEnvironment();
  const [result, refetch] = useQuery({
    query: GetFunctionDocument,
    variables: {
      environmentID: environment.id,
      slug: functionSlug,
    },
  });

  return [{ ...result, fetching: result.fetching }, refetch];
};

const GetFunctionUsageDocument = graphql(`
  query GetFunctionUsage($id: ID!, $environmentID: ID!, $startTime: Time!, $endTime: Time!) {
    workspace(id: $environmentID) {
      workflow(id: $id) {
        concurrencyLimitReached: metrics(
          opts: {
            name: "concurrency_limit_reached_total"
            from: $startTime
            to: $endTime
          }
        ) {
          data {
            bucket
            value
          }
        }
        dailyStarts: usage(opts: { from: $startTime, to: $endTime }, event: "started") {
          period
          total
          data {
            slot
            count
          }
        }
        dailyCancelled: usage(opts: { from: $startTime, to: $endTime }, event: "cancelled") {
          period
          total
          data {
            slot
            count
          }
        }
        dailyCompleted: usage(opts: { from: $startTime, to: $endTime }, event: "completed") {
          period
          total
          data {
            slot
            count
          }
        }
        dailyFailures: usage(opts: { from: $startTime, to: $endTime }, event: "errored") {
          period
          total
          data {
            slot
            count
          }
        }
      }
    }
  }
`);

export async function getFunctionUsagesPage(args: {
  archived: boolean;
  client: Client;
  envID: string;
  page: number;
}) {
  const pageSize = 50;

  const res = await args.client
    .query(GetFunctionsUsageDocument, {
      environmentID: args.envID,
      archived: args.archived,
      page: args.page,
      pageSize,
    })
    .toPromise();
  if (res.error) {
    throw res.error;
  }
  if (!res.data) {
    throw new Error('no data returned');
  }

  res.data.workspace;

  return {
    ...res,
    data: {
      functions: res.data.workspace.workflows.data.map((fn) => {
        const dailyFailureCount = fn.dailyFailures.total;
        const dailyFinishedCount =
          fn.dailyCompleted.total + fn.dailyCancelled.total + dailyFailureCount;

        // Calculates the daily failure rate percentage and rounds it up to 2 decimal places
        const failureRate = dailyFinishedCount
          ? Math.round((dailyFailureCount / dailyFinishedCount) * 10000) / 100
          : 0;

        // Creates an array of objects containing the start and failure count for each usage slot (1 hour)
        const slots = fn.dailyStarts.data.map((usageSlot, index) => ({
          startCount: usageSlot.count,
          failureCount: fn.dailyFailures.data[index]?.count ?? 0,
        }));

        const usage = {
          slots,
          total: dailyFinishedCount,
        };

        return {
          failureRate,
          slug: fn.slug,
          usage,
        };
      }),
      page: res.data.workspace.workflows.page,
    },
  };
}

type UsageItem = {
  name: string;
  values: {
    totalRuns: number;
    totalFinished: number;
    successes: number;
    failures: number;
  };
};

type UseFunctionUsageParams = {
  functionSlug: string;
  startTime: string;
  endTime: string;
};

export const useFunctionUsage = ({
  functionSlug,
  startTime,
  endTime,
}: UseFunctionUsageParams): UseQueryResponse<UsageItem[]> => {
  const environment = useEnvironment();
  const [{ data: functionData }] = useFunction({ functionSlug });
  const functionId = functionData?.workspace.workflow?.id;

  const [{ data, ...rest }, refetch] = useQuery({
    query: GetFunctionUsageDocument,
    variables: {
      environmentID: environment.id,
      id: functionId!,
      startTime,
      endTime,
    },
    pause: !functionId,
  });

  // Combine usage arrays into single array
  let usage: UsageItem[] = [];

  const started = data?.workspace.workflow?.dailyStarts;
  const completed = data?.workspace.workflow?.dailyCompleted;
  const cancelled = data?.workspace.workflow?.dailyCancelled;
  const failed = data?.workspace.workflow?.dailyFailures;

  if (started && completed && cancelled && failed) {
    usage = started.data.map((d, idx) => {
      const failureCount = failed.data[idx]?.count || 0;
      const finishedCount =
        (completed.data[idx]?.count || 0) +
        (cancelled.data[idx]?.count || 0) +
        failureCount;

      return {
        name: d.slot,
        values: {
          totalRuns: d.count,
          totalFinished: finishedCount,
          successes: finishedCount - failureCount,
          failures: failureCount,
        },
      };
    });
  }

  return [{ ...rest, data: usage, fetching: rest.fetching }, refetch];
};
