import SendEventButton from '@/components/Event/SendEventButton';
import { useGetTrigger } from '@/hooks/useGetTrigger';
import { client } from '@/store/baseApi';
import { useInfoQuery } from '@/store/devApi';
import {
  useGetAppsQuery,
  GetRunsQuery,
  GetRunsDocument,
  CountRunsQuery,
  CountRunsDocument,
} from '@/store/generated';
import { Header } from '@inngest/components/Header/Header';
import { useCalculatedStartTime } from '@inngest/components/hooks/useCalculatedStartTime';
import {
  useBooleanSearchParam,
  useStringArraySearchParam,
  useValidatedArraySearchParam,
  useValidatedSearchParam,
  useSearchParam,
} from '@inngest/components/hooks/useSearchParams';
import { InfiniteScrollTrigger } from '@inngest/components/InfiniteScrollTrigger/InfiniteScrollTrigger';
import { RunsActionMenu } from '@inngest/components/RunsPage/ActionMenu';
import { RunsPage } from '@inngest/components/RunsPage/RunsPage';
import { useBooleanFlag } from '@inngest/components/SharedContext/useBooleanFlag';
import {
  isFunctionRunStatus,
  FunctionRunTimeField,
  isFunctionTimeField,
} from '@inngest/components/types/functionRun';
import { toMaybeDate } from '@inngest/components/utils/date';
import { parseCelSearchError } from '@inngest/components/utils/searchErrorParser';
import { useInfiniteQuery } from '@tanstack/react-query';
import { createFileRoute } from '@tanstack/react-router';
import { useState, useEffect, useCallback, useMemo } from 'react';

// Dev mode polls aggressively so iterations feel instant; serve (single-node
// production) polls every 10s to keep query load off Postgres.
const DEV_POLL_INTERVAL = 400;
const SERVE_POLL_INTERVAL = 10_000;

export const Route = createFileRoute('/_dashboard/runs/')({
  component: RunsComponent,
});

function RunsComponent() {
  const { data: info } = useInfoQuery();
  // While info is loading, default to the safer (slower) interval so we don't
  // hammer a serve-mode deployment before we know which mode we're in.
  const isDevMode = info !== undefined && !info.isSingleNodeService;
  const pollInterval = isDevMode ? DEV_POLL_INTERVAL : SERVE_POLL_INTERVAL;

  const { booleanFlag } = useBooleanFlag();
  const { value: pollingDisabled, isReady: pollingFlagReady } = booleanFlag(
    'polling-disabled',
    false,
  );
  const { value: tracesPreviewEnabled, isReady: tracesPreviewFlagReady } =
    booleanFlag('traces-preview', true, true);

  const [autoRefresh, setAutoRefresh] = useState(true);
  const [preview, setPreview] = useState(false);

  const [filterApp] = useStringArraySearchParam('filterApp');
  const [totalCount, setTotalCount] = useState<number>();
  const [filteredStatus] = useValidatedArraySearchParam(
    'filterStatus',
    isFunctionRunStatus,
  );
  const [timeField = FunctionRunTimeField.QueuedAt] = useValidatedSearchParam(
    'timeField',
    isFunctionTimeField,
  );
  const [excludeDeferred] = useBooleanSearchParam('excludeDeferred');
  const [lastDays] = useSearchParam('last');
  const [startTime] = useSearchParam('start');
  const [endTime] = useSearchParam('end');
  const [search] = useSearchParam('search');
  const calculatedStartTime = useCalculatedStartTime({ lastDays, startTime });
  const appsRes = useGetAppsQuery();

  useEffect(() => {
    if (pollingFlagReady && pollingDisabled) {
      setAutoRefresh(false);
    }
  }, [pollingDisabled, pollingFlagReady]);

  useEffect(() => {
    setPreview(tracesPreviewEnabled);
  }, [tracesPreviewEnabled, tracesPreviewFlagReady]);

  const queryFn = useCallback(
    async ({ pageParam }: { pageParam: string | null }) => {
      const data: GetRunsQuery = await client.request(GetRunsDocument, {
        appIDs: filterApp,
        functionRunCursor: pageParam,
        startTime: calculatedStartTime,
        endTime: endTime,
        status: filteredStatus,
        timeField,
        celQuery: search,
        preview,
        isDeferred: excludeDeferred ? false : null,
      });

      const edges = data.runs.edges.map((edge) => {
        let durationMS: number | null = null;
        const startedAt = toMaybeDate(edge.node.startedAt);
        if (startedAt) {
          const endedAt = toMaybeDate(edge.node.endedAt);
          durationMS = (endedAt ?? new Date()).getTime() - startedAt.getTime();
        }

        return {
          ...edge.node,
          durationMS,
        };
      });
      return {
        ...data.runs,
        edges,
      };
    },
    [
      filterApp,
      filteredStatus,
      calculatedStartTime,
      timeField,
      search,
      preview,
      excludeDeferred,
    ],
  );

  const { data, error, fetchNextPage, isFetching, hasNextPage } =
    useInfiniteQuery({
      queryKey: [
        'runs',
        {
          filterApp,
          filteredStatus,
          calculatedStartTime,
          endTime,
          timeField,
          search,
          preview,
          excludeDeferred,
        },
      ],
      queryFn,
      enabled: tracesPreviewFlagReady,
      refetchInterval: autoRefresh ? pollInterval : false,
      initialPageParam: null,
      getNextPageParam: (lastPage) => {
        if (!lastPage) {
          return undefined;
        }

        return lastPage.pageInfo.endCursor;
      },
    });

  const searchError = parseCelSearchError(error);

  const getTotalCount = useCallback(async () => {
    setTotalCount(undefined);
    (async () => {
      const data: CountRunsQuery = await client.request(CountRunsDocument, {
        startTime: calculatedStartTime,
        endTime,
        status: filteredStatus,
        timeField,
        celQuery: search,
        preview,
        isDeferred: excludeDeferred ? false : null,
      });
      setTotalCount(data.runs.totalCount);
    })();
  }, [
    calculatedStartTime,
    endTime,
    filteredStatus,
    timeField,
    search,
    preview,
    excludeDeferred,
  ]);

  useEffect(() => {
    getTotalCount();
  }, [getTotalCount]);

  const onRefresh = useCallback(() => {
    fetchNextPage();
    getTotalCount();
  }, [fetchNextPage, getTotalCount]);

  const runs = useMemo(() => {
    if (!data?.pages) {
      return undefined;
    }
    if (data.pages.length === 0) {
      return [];
    }

    const out = [];
    for (const page of data.pages) {
      out.push(...page.edges);
    }
    return out;
  }, [data?.pages]);

  const getTrigger = useGetTrigger();

  const onScrollToTop = useCallback(() => {
    // TODO: What should this do?
  }, []);

  return (
    <>
      <Header
        breadcrumb={[{ text: 'Runs' }]}
        action={
          <div className="flex flex-row items-center gap-x-1">
            <SendEventButton
              label="Send test event"
              data={JSON.stringify({
                name: '',
                data: {},
                user: {},
              })}
            />
            <RunsActionMenu
              setAutoRefresh={() => setAutoRefresh((v) => !v)}
              setPreview={() => setPreview((p) => !p)}
              autoRefresh={autoRefresh}
              intervalSeconds={pollInterval / 1000}
            />
          </div>
        }
      />
      <RunsPage
        apps={appsRes.data?.apps || []}
        data={runs ?? []}
        defaultVisibleColumns={[
          'status',
          'id',
          'trigger',
          'function',
          'queuedAt',
          'endedAt',
        ]}
        features={{
          history: Number.MAX_SAFE_INTEGER,
          tracesPreview: tracesPreviewEnabled,
          isDeferred: true,
        }}
        hasMore={hasNextPage ?? false}
        isLoadingInitial={isFetching && runs === undefined}
        isLoadingMore={isFetching && runs !== undefined}
        onScrollToTop={onScrollToTop}
        onRefresh={onRefresh}
        getTrigger={getTrigger}
        pollInterval={pollInterval}
        scope="env"
        totalCount={totalCount}
        searchError={searchError}
        searchLimit={1000}
        infiniteScrollTrigger={(containerRef) => (
          <InfiniteScrollTrigger
            onIntersect={fetchNextPage}
            hasMore={hasNextPage ?? false}
            isLoading={isFetching}
            root={containerRef}
          />
        )}
      />
    </>
  );
}
