import React, { forwardRef, type ButtonHTMLAttributes, type ReactNode } from 'react';
import { Tooltip, TooltipContent, TooltipTrigger } from '@inngest/components/Tooltip';
import { IconSpinner } from '@inngest/components/icons/Spinner';
import { Link, type LinkComponentProps } from '@tanstack/react-router';

import { cn } from '../utils/classNames';
import {
  getButtonColors,
  getButtonSizeStyles,
  getIconSizeStyles,
  getSpinnerStyles,
} from './buttonStyles';

export type ButtonKind = 'primary' | 'secondary' | 'danger';
export type ButtonAppearance = 'solid' | 'outlined' | 'ghost';
export type ButtonSize = 'small' | 'medium' | 'large';
type RouterTo = LinkComponentProps['to'] | string;

export interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  kind?: ButtonKind;
  appearance?: ButtonAppearance;
  size?: ButtonSize;
  loading?: boolean;
  href?: LinkComponentProps['href'];
  to?: RouterTo;
  target?: string;
  rel?: string;
  tooltip?: ReactNode;
  label?: ReactNode;
  icon?: ReactNode;
  iconSide?: 'right' | 'left';
  keys?: string[];
  prefetch?: false | 'intent' | 'viewport' | 'render';
  scroll?: boolean;
  raw?: boolean;
}

type LinkWrapperProps = {
  children: ReactNode;
  href?: LinkComponentProps['href'];
  to?: RouterTo;
  target?: string;
  rel?: string;
  prefetch?: false | 'intent' | 'viewport' | 'render';
  scroll?: boolean;
} & Omit<LinkComponentProps, 'href' | 'to'>;

export const LinkWrapper = forwardRef<HTMLAnchorElement, LinkWrapperProps>(
  ({ children, href, to, target, rel, prefetch = false, scroll = true, ...props }, ref) =>
    href ? (
      <a href={href} target={target} rel={rel} {...props}>
        {children}
      </a>
    ) : to ? (
      <Link
        to={to as LinkComponentProps['to']}
        target={target}
        preload={prefetch}
        resetScroll={scroll}
        ref={ref}
        {...props}
      >
        {children}
      </Link>
    ) : (
      children
    )
);
LinkWrapper.displayName = 'LinkWrapper';

export const TooltipWrapper = ({
  children,
  tooltip,
}: {
  children: ReactNode;
  tooltip?: ReactNode;
}) =>
  tooltip ? (
    <Tooltip>
      <TooltipTrigger asChild>{children}</TooltipTrigger>
      <TooltipContent>{tooltip}</TooltipContent>
    </Tooltip>
  ) : (
    children
  );

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(
  (
    {
      kind = 'primary',
      appearance = 'solid',
      size = 'medium',
      label,
      icon,
      iconSide,
      loading = false,
      href,
      to,
      type = 'button',
      keys,
      className,
      tooltip,
      disabled,
      target,
      rel,
      prefetch = false,
      scroll = true,
      raw = false,
      ...props
    }: ButtonProps,
    ref
  ) => {
    const buttonColors = getButtonColors({ kind, appearance, loading });
    const buttonSizes = getButtonSizeStyles({ size, icon, label });
    const spinnerStyles = getSpinnerStyles({ kind, appearance });
    const iconSizes = getIconSizeStyles({ size });

    const iconElement = React.isValidElement(icon)
      ? React.cloneElement(icon as React.ReactElement, {
          className: cn(iconSizes, icon.props.className, loading && 'invisible'),
        })
      : null;

    const children = (
      <>
        {loading && (
          <IconSpinner className={cn(spinnerStyles, iconSizes, 'top-50% left-50% absolute')} />
        )}
        {icon && iconSide === 'left' && (
          <span className={cn(size === 'small' ? 'pr-1' : 'pr-1.5')}>{iconElement}</span>
        )}
        {label ? (
          <span className={loading ? 'invisible' : 'visible'}>{label}</span>
        ) : (
          icon && !iconSide && iconElement
        )}
        {icon && iconSide === 'right' && (
          <span className={cn(size === 'small' ? 'pl-1' : 'pl-1.5')}>{iconElement}</span>
        )}
      </>
    );

    const buttonElement = (
      <button
        ref={ref}
        className={cn(
          buttonColors,
          buttonSizes,
          'relative flex items-center justify-center justify-items-center whitespace-nowrap rounded-md disabled:cursor-not-allowed',
          className
        )}
        type={type}
        disabled={disabled}
        {...props}
      >
        {children}
      </button>
    );

    if (raw) {
      return buttonElement;
    }

    return (
      <TooltipWrapper tooltip={tooltip}>
        <LinkWrapper
          href={href}
          to={to}
          target={target}
          rel={rel}
          prefetch={prefetch}
          scroll={scroll}
        >
          {buttonElement}
        </LinkWrapper>
      </TooltipWrapper>
    );
  }
);
