package executor

import (
	"testing"

	"github.com/inngest/inngest/pkg/enums"
	"github.com/inngest/inngest/pkg/execution/state"
	"github.com/oklog/ulid/v2"
	"github.com/stretchr/testify/require"
)

func TestOpGroups(t *testing.T) {
	input := []*state.GeneratorOpcode{
		{
			Op: enums.OpcodeSleep,
			ID: "1",
		},
		{
			Op: enums.OpcodeWaitForEvent,
			ID: "2",
		},
		{
			Op: enums.OpcodeStepRun,
			ID: "3",
		},
		{
			Op: enums.OpcodeSleep,
			ID: "4",
		},
		{
			Op: enums.OpcodeWaitForEvent,
			ID: "5",
		},
	}

	expected := OpcodeGroups{
		PriorityGroup: OpcodeGroup{
			Opcodes: []*state.GeneratorOpcode{
				{
					Op: enums.OpcodeWaitForEvent,
					ID: "2",
				},
				{
					Op: enums.OpcodeWaitForEvent,
					ID: "5",
				},
			},
			ShouldStartHistoryGroup: true,
		},
		OtherGroup: OpcodeGroup{
			Opcodes: []*state.GeneratorOpcode{
				{
					Op: enums.OpcodeSleep,
					ID: "1",
				},
				{
					Op: enums.OpcodeStepRun,
					ID: "3",
				},
				{
					Op: enums.OpcodeSleep,
					ID: "4",
				},
			},
			ShouldStartHistoryGroup: true,
		},
	}
	actual := opGroups(input)

	require.EqualValues(t, expected, actual)
}

func TestOpGroupsNoInput(t *testing.T) {
	input := []*state.GeneratorOpcode{}

	expected := OpcodeGroups{
		PriorityGroup: OpcodeGroup{
			Opcodes:                 []*state.GeneratorOpcode{},
			ShouldStartHistoryGroup: false,
		},
		OtherGroup: OpcodeGroup{
			Opcodes:                 []*state.GeneratorOpcode{},
			ShouldStartHistoryGroup: false,
		},
	}
	actual := opGroups(input)

	require.EqualValues(t, expected, actual)
}

func TestParseBatchID(t *testing.T) {
	expected := ulid.Make()

	parsed, err := parseBatchID(expected.String())
	require.NoError(t, err)
	require.Equal(t, expected, parsed)

	_, err = parseBatchID("")
	require.ErrorContains(t, err, "batch append returned empty batch ID")

	_, err = parseBatchID("not-a-ulid")
	require.ErrorContains(t, err, "invalid batch ID")
}

func TestOpGroupsSingleInput(t *testing.T) {
	input := []*state.GeneratorOpcode{
		{
			Op: enums.OpcodeSleep,
			ID: "1",
		},
	}

	expected := OpcodeGroups{
		PriorityGroup: OpcodeGroup{
			Opcodes:                 []*state.GeneratorOpcode{},
			ShouldStartHistoryGroup: false,
		},
		OtherGroup: OpcodeGroup{
			Opcodes: []*state.GeneratorOpcode{
				{
					Op: enums.OpcodeSleep,
					ID: "1",
				},
			},
			ShouldStartHistoryGroup: false,
		},
	}
	actual := opGroups(input)

	require.EqualValues(t, expected, actual)
}

func TestOpcodeGroupsAllWithMixedInput(t *testing.T) {
	input := []*state.GeneratorOpcode{
		{Op: enums.OpcodeWaitForEvent, ID: "1"},
		{Op: enums.OpcodeStepRun, ID: "2"},
	}
	groups := opGroups(input)

	expected := []OpcodeGroup{
		groups.PriorityGroup,
		groups.OtherGroup,
	}
	actual := groups.All()

	require.EqualValues(t, expected, actual)
}

func TestOpcodeGroupsAllWithEmptyInput(t *testing.T) {
	input := []*state.GeneratorOpcode{}
	groups := opGroups(input)

	expected := []OpcodeGroup{
		groups.PriorityGroup,
		groups.OtherGroup,
	}
	actual := groups.All()

	require.EqualValues(t, expected, actual)
}

// TestOpGroups_DeferOpsArePriority asserts that DeferAdd and DeferAbort are
// routed into the priority group so they drain before non-lazy ops in the same
// SDK response — fixing the [DeferAdd, RunComplete] race where Finalize would
// delete state before SaveDefer ran.
func TestOpGroups_DeferOpsArePriority(t *testing.T) {
	cases := []struct {
		name     string
		input    []*state.GeneratorOpcode
		expected OpcodeGroups
	}{
		{
			name: "lone DeferAdd",
			input: []*state.GeneratorOpcode{
				{Op: enums.OpcodeDeferAdd, ID: "1"},
			},
			expected: OpcodeGroups{
				PriorityGroup: OpcodeGroup{
					Opcodes: []*state.GeneratorOpcode{
						{Op: enums.OpcodeDeferAdd, ID: "1"},
					},
					ShouldStartHistoryGroup: false,
				},
				OtherGroup: OpcodeGroup{
					Opcodes:                 []*state.GeneratorOpcode{},
					ShouldStartHistoryGroup: false,
				},
			},
		},
		{
			name: "StepRun with DeferAdd piggyback",
			input: []*state.GeneratorOpcode{
				{Op: enums.OpcodeStepRun, ID: "1"},
				{Op: enums.OpcodeDeferAdd, ID: "2"},
			},
			expected: OpcodeGroups{
				PriorityGroup: OpcodeGroup{
					Opcodes: []*state.GeneratorOpcode{
						{Op: enums.OpcodeDeferAdd, ID: "2"},
					},
					ShouldStartHistoryGroup: false,
				},
				OtherGroup: OpcodeGroup{
					Opcodes: []*state.GeneratorOpcode{
						{Op: enums.OpcodeStepRun, ID: "1"},
					},
					ShouldStartHistoryGroup: false,
				},
			},
		},
		{
			name: "DeferAdd before RunComplete",
			input: []*state.GeneratorOpcode{
				{Op: enums.OpcodeDeferAdd, ID: "1"},
				{Op: enums.OpcodeRunComplete, ID: "2"},
			},
			expected: OpcodeGroups{
				PriorityGroup: OpcodeGroup{
					Opcodes: []*state.GeneratorOpcode{
						{Op: enums.OpcodeDeferAdd, ID: "1"},
					},
					ShouldStartHistoryGroup: false,
				},
				OtherGroup: OpcodeGroup{
					Opcodes: []*state.GeneratorOpcode{
						{Op: enums.OpcodeRunComplete, ID: "2"},
					},
					ShouldStartHistoryGroup: false,
				},
			},
		},
		{
			name: "WaitForEvent and DeferAdd both priority",
			input: []*state.GeneratorOpcode{
				{Op: enums.OpcodeWaitForEvent, ID: "1"},
				{Op: enums.OpcodeDeferAdd, ID: "2"},
			},
			expected: OpcodeGroups{
				PriorityGroup: OpcodeGroup{
					Opcodes: []*state.GeneratorOpcode{
						{Op: enums.OpcodeWaitForEvent, ID: "1"},
						{Op: enums.OpcodeDeferAdd, ID: "2"},
					},
					ShouldStartHistoryGroup: false,
				},
				OtherGroup: OpcodeGroup{
					Opcodes:                 []*state.GeneratorOpcode{},
					ShouldStartHistoryGroup: false,
				},
			},
		},
		{
			name: "lone DeferAbort",
			input: []*state.GeneratorOpcode{
				{Op: enums.OpcodeDeferAbort, ID: "1"},
			},
			expected: OpcodeGroups{
				PriorityGroup: OpcodeGroup{
					Opcodes: []*state.GeneratorOpcode{
						{Op: enums.OpcodeDeferAbort, ID: "1"},
					},
					ShouldStartHistoryGroup: false,
				},
				OtherGroup: OpcodeGroup{
					Opcodes:                 []*state.GeneratorOpcode{},
					ShouldStartHistoryGroup: false,
				},
			},
		},
		{
			name: "StepRun with DeferAbort piggyback",
			input: []*state.GeneratorOpcode{
				{Op: enums.OpcodeStepRun, ID: "1"},
				{Op: enums.OpcodeDeferAbort, ID: "2"},
			},
			expected: OpcodeGroups{
				PriorityGroup: OpcodeGroup{
					Opcodes: []*state.GeneratorOpcode{
						{Op: enums.OpcodeDeferAbort, ID: "2"},
					},
					ShouldStartHistoryGroup: false,
				},
				OtherGroup: OpcodeGroup{
					Opcodes: []*state.GeneratorOpcode{
						{Op: enums.OpcodeStepRun, ID: "1"},
					},
					ShouldStartHistoryGroup: false,
				},
			},
		},
	}

	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			actual := opGroups(tc.input)
			require.EqualValues(t, tc.expected, actual)
		})
	}
}

// TestNonLazyOpCount asserts that lazy ops (DeferAdd/DeferAbort) don't count
// toward the parallel-step gating signals (ForceStepPlan, history grouping,
// per-step trace emission). They piggyback on a host op and aren't standalone
// steps.
func TestNonLazyOpCount(t *testing.T) {
	cases := []struct {
		name  string
		input []*state.GeneratorOpcode
		want  int
	}{
		{"empty", []*state.GeneratorOpcode{}, 0},
		{"single StepRun", []*state.GeneratorOpcode{{Op: enums.OpcodeStepRun}}, 1},
		{"single DeferAdd", []*state.GeneratorOpcode{{Op: enums.OpcodeDeferAdd}}, 0},
		{"single DeferAbort", []*state.GeneratorOpcode{{Op: enums.OpcodeDeferAbort}}, 0},
		{"all lazy", []*state.GeneratorOpcode{{Op: enums.OpcodeDeferAdd}, {Op: enums.OpcodeDeferAbort}}, 0},
		{"StepRun + DeferAdd", []*state.GeneratorOpcode{{Op: enums.OpcodeStepRun}, {Op: enums.OpcodeDeferAdd}}, 1},
		{"DeferAdd + RunComplete", []*state.GeneratorOpcode{{Op: enums.OpcodeDeferAdd}, {Op: enums.OpcodeRunComplete}}, 1},
		{"WaitForEvent + StepRun (both non-lazy)", []*state.GeneratorOpcode{{Op: enums.OpcodeWaitForEvent}, {Op: enums.OpcodeStepRun}}, 2},
		{"WaitForEvent + DeferAdd", []*state.GeneratorOpcode{{Op: enums.OpcodeWaitForEvent}, {Op: enums.OpcodeDeferAdd}}, 1},
		{"StepRun + DeferAdd + DeferAbort", []*state.GeneratorOpcode{{Op: enums.OpcodeStepRun}, {Op: enums.OpcodeDeferAdd}, {Op: enums.OpcodeDeferAbort}}, 1},
		{"nil entries skipped", []*state.GeneratorOpcode{nil, {Op: enums.OpcodeStepRun}, nil}, 1},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			require.Equal(t, tc.want, nonLazyOpCount(tc.input))
		})
	}
}

func TestOpcodeGroups_IDs_ExcludesLazyOps(t *testing.T) {
	cases := []struct {
		name  string
		input []*state.GeneratorOpcode
		want  []string
	}{
		{
			name:  "all lazy yields no IDs",
			input: []*state.GeneratorOpcode{{Op: enums.OpcodeDeferAdd, ID: "1"}, {Op: enums.OpcodeDeferAbort, ID: "2"}},
			want:  []string{},
		},
		{
			name:  "StepRun + DeferAdd drops the lazy ID",
			input: []*state.GeneratorOpcode{{Op: enums.OpcodeStepRun, ID: "step-1"}, {Op: enums.OpcodeDeferAdd, ID: "defer-1"}},
			want:  []string{"step-1"},
		},
		{
			name: "StepPlanned + DeferAdd + DeferAbort drops both lazy IDs",
			input: []*state.GeneratorOpcode{
				{Op: enums.OpcodeStepPlanned, ID: "plan-1"},
				{Op: enums.OpcodeDeferAdd, ID: "defer-add-1"},
				{Op: enums.OpcodeDeferAbort, ID: "defer-abort-1"},
			},
			want: []string{"plan-1"},
		},
		{
			name: "WaitForEvent (priority) + DeferAdd (other) drops the lazy ID",
			input: []*state.GeneratorOpcode{
				{Op: enums.OpcodeWaitForEvent, ID: "wait-1"},
				{Op: enums.OpcodeDeferAdd, ID: "defer-1"},
			},
			want: []string{"wait-1"},
		},
		{
			name: "no lazy ops: all IDs returned in priority-then-other order",
			input: []*state.GeneratorOpcode{
				{Op: enums.OpcodeStepRun, ID: "step-1"},
				{Op: enums.OpcodeWaitForEvent, ID: "wait-1"},
			},
			want: []string{"wait-1", "step-1"},
		},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			got := opGroups(tc.input).NonLazyIDs()
			require.ElementsMatch(t, tc.want, got)
		})
	}
}

func TestComputeParallelCoalesceKey(t *testing.T) {
	t.Run("deterministic", func(t *testing.T) {
		a := computeParallelCoalesceKey("run-1", []string{"step-a", "step-b"})
		b := computeParallelCoalesceKey("run-1", []string{"step-a", "step-b"})
		require.Equal(t, a, b)
	})

	t.Run("order independent", func(t *testing.T) {
		a := computeParallelCoalesceKey("run-1", []string{"step-a", "step-b"})
		b := computeParallelCoalesceKey("run-1", []string{"step-b", "step-a"})
		require.Equal(t, a, b)
	})

	t.Run("different step sets produce different keys", func(t *testing.T) {
		a := computeParallelCoalesceKey("run-1", []string{"step-a", "step-b"})
		b := computeParallelCoalesceKey("run-1", []string{"step-a", "step-c"})
		require.NotEqual(t, a, b)
	})

	t.Run("different run IDs produce different keys", func(t *testing.T) {
		a := computeParallelCoalesceKey("run-1", []string{"step-a"})
		b := computeParallelCoalesceKey("run-2", []string{"step-a"})
		require.NotEqual(t, a, b)
	})

	t.Run("no length extension collision", func(t *testing.T) {
		a := computeParallelCoalesceKey("run-1", []string{"ab", "c"})
		b := computeParallelCoalesceKey("run-1", []string{"a", "bc"})
		require.NotEqual(t, a, b)
	})
}

func TestAllEmptyNoneOps(t *testing.T) {
	tests := []struct {
		name string
		in   []*state.GeneratorOpcode
		want bool
	}{
		{
			name: "all zero-value none ops",
			in:   []*state.GeneratorOpcode{{}, {}},
			want: true,
		},
		{
			name: "explicit none ops with empty ids",
			in:   []*state.GeneratorOpcode{{Op: enums.OpcodeNone}, {Op: enums.OpcodeNone}},
			want: true,
		},
		{
			name: "nil entries are ignored",
			in:   []*state.GeneratorOpcode{nil, {Op: enums.OpcodeNone}},
			want: true,
		},
		{
			name: "none op with a step id is not corruption",
			in:   []*state.GeneratorOpcode{{Op: enums.OpcodeNone, ID: "step-1"}},
			want: false,
		},
		{
			name: "real step op",
			in:   []*state.GeneratorOpcode{{Op: enums.OpcodeStepRun, ID: "step-1"}},
			want: false,
		},
		{
			name: "mixed none and real op",
			in:   []*state.GeneratorOpcode{{Op: enums.OpcodeNone}, {Op: enums.OpcodeStepRun, ID: "step-1"}},
			want: false,
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			require.Equal(t, tc.want, allEmptyNoneOps(tc.in))
		})
	}
}
