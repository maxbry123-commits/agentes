package resolvers

import (
	"context"
	"database/sql"
	"encoding/json"
	"fmt"
	"math"
	"strconv"
	"strings"
	"time"

	"github.com/google/uuid"
	"github.com/inngest/inngest/pkg/consts"
	"github.com/inngest/inngest/pkg/coreapi/graph/models"
	"github.com/inngest/inngest/pkg/cqrs"
	"github.com/inngest/inngest/pkg/deploy"
	"github.com/inngest/inngest/pkg/event"
	"github.com/inngest/inngest/pkg/inngest"
	"github.com/inngest/inngest/pkg/run"
	"github.com/inngest/inngest/pkg/util"
	"github.com/oklog/ulid/v2"
	"go.opentelemetry.io/otel/attribute"
)

func (r *mutationResolver) CreateApp(ctx context.Context, input models.CreateAppInput) (*cqrs.App, error) {
	// URLs must contain a protocol. If not, add http since very few apps use
	// https during development
	if !strings.Contains(input.URL, "://") {
		input.URL = "http://" + input.URL
	}

	// Normalize the URL so that default ports and localhost variants are
	// unified before deriving the placeholder app ID.
	input.URL = util.NormalizeAppURL(input.URL, false)

	// This ID will not match the app ID after the sync process succeeds. That's
	// because the eventual app ID will use the app name, rather than the URL.
	// But we still need to create a placeholder app with a deterministic ID in
	// the meantime.
	//
	// Ideally the app ID would be the same before and after the SDK ping, but
	// we don't know the app name until after the SDK ping
	appID := inngest.DeterministicAppUUID(input.URL)

	// Create a new app which holds the error message.
	params := cqrs.UpsertAppParams{
		ID:  appID,
		Url: input.URL,
		Error: sql.NullString{
			Valid:  true,
			String: deploy.DeployErrUnreachable.Error(),
		},
	}
	app, _ := r.Data.UpsertApp(ctx, params)

	if res := deploy.Ping(ctx, input.URL, r.ServerKind, r.LocalSigningKey, r.RequireKeys); res.Err != nil {
		return app, res.Err
	}

	<-time.After(100 * time.Millisecond)
	apps, err := r.Data.GetAllApps(ctx, consts.DevServerEnvID)
	if err != nil {
		return nil, err
	}
	for _, app := range apps {
		if app.Url == input.URL {
			return app, nil
		}
	}
	return nil, fmt.Errorf("There was an error creating your app")
}

func (r *mutationResolver) UpdateApp(ctx context.Context, input models.UpdateAppInput) (*cqrs.App, error) {
	return r.Data.UpdateAppURL(ctx, cqrs.UpdateAppURLParams{
		ID:  uuid.MustParse(input.ID),
		Url: input.URL,
	})
}

func (r *mutationResolver) DeleteApp(ctx context.Context, idstr string) (string, error) {
	id, err := uuid.Parse(idstr)
	if err != nil {
		return "", err
	}
	if err = r.Data.DeleteApp(ctx, id); err != nil {
		return "", err
	}
	return idstr, nil
}

func (r *mutationResolver) DeleteAppByName(
	ctx context.Context,
	name string,
) (bool, error) {
	apps, err := r.Data.GetApps(ctx, consts.DevServerEnvID, nil)
	if err != nil {
		return false, err
	}

	for _, app := range apps {
		if app.Name == name {
			return true, r.Data.DeleteApp(ctx, app.ID)
		}
	}

	return false, nil
}

func (r *mutationResolver) InvokeFunction(
	ctx context.Context,
	data map[string]any,
	functionSlug string,
	meta map[string]any,
	user map[string]any,
	debugSessionID *ulid.ULID,
	debugRunID *ulid.ULID,
) (*bool, error) {
	eventMeta, err := eventMetaFromMap(meta)
	if err != nil {
		return nil, err
	}

	evt := event.NewInvocationEvent(event.NewInvocationEventOpts{
		Event: event.Event{
			Data: data,
			Meta: eventMeta,
			User: user,
		},
		FnID:           functionSlug,
		DebugSessionID: debugSessionID,
		DebugRunID:     debugRunID,
	})

	ctx, span := run.NewSpan(ctx,
		run.WithName(consts.OtelSpanInvoke),
		run.WithScope(consts.OtelScopeInvoke),
		run.WithNewRoot(),
		run.WithSpanAttributes(
			attribute.String(consts.OtelSysFunctionSlug, functionSlug),
		),
	)
	defer span.End()

	sent := false
	_, err = r.EventHandler(ctx, &evt.Event, nil)
	if err != nil {
		return &sent, err
	}

	sent = true
	return &sent, nil
}

func eventMetaFromMap(input map[string]any) (event.EventMeta, error) {
	if len(input) == 0 {
		return event.EventMeta{}, nil
	}

	for key := range input {
		if key != "sessions" {
			return event.EventMeta{}, fmt.Errorf("event meta %q is not supported", key)
		}
	}

	rawSessions, ok := input["sessions"]
	if !ok || rawSessions == nil {
		return event.EventMeta{}, nil
	}

	sessions, ok := rawSessions.(map[string]any)
	if !ok {
		return event.EventMeta{}, fmt.Errorf("event meta sessions must be an object")
	}

	eventSessions, err := eventSessionsFromMap(sessions)
	if err != nil {
		return event.EventMeta{}, err
	}

	return event.EventMeta{Sessions: eventSessions}, nil
}

func eventSessionsFromMap(input map[string]any) (event.Sessions, error) {
	if len(input) == 0 {
		return nil, nil
	}

	sessions := make(event.Sessions, len(input))
	for key, value := range input {
		id, err := eventSessionIDFromValue(key, value)
		if err != nil {
			return nil, err
		}

		sessions[key] = id
	}

	if err := sessions.Validate(); err != nil {
		return nil, fmt.Errorf("invalid sessions: %w", err)
	}

	return sessions, nil
}

func eventSessionIDFromValue(key string, value any) (string, error) {
	switch v := value.(type) {
	case string:
		return v, nil
	case json.Number:
		return v.String(), nil
	case int:
		return strconv.Itoa(v), nil
	case int64:
		return strconv.FormatInt(v, 10), nil
	case float64:
		if math.IsNaN(v) || math.IsInf(v, 0) {
			return "", fmt.Errorf("session %q must be a finite number", key)
		}
		return strconv.FormatFloat(v, 'f', -1, 64), nil
	default:
		return "", fmt.Errorf("session %q must be a string or number", key)
	}
}
