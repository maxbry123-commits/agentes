--
-- Acquire
-- - checks idempotency to allow retries
-- - checks constraint capacity given constraints and the current configuration
-- - determines exhausted constraints, constraints without capacity before or after granting leases
-- - rejects request if one or more constraints are exhausted (there is no capacity)
-- - updates constraint state if leases can be granted
-- - stores lease details and link to request state
-- - sets idempotency keys
--

---@module 'cjson'
local cjson = cjson

---@param command string
---@param ... string
local function call(command, ...)
	return redis.call(command, ...)
end

---@type string[]
local KEYS = KEYS

---@type string[]
local ARGV = ARGV

local keyRequestState = KEYS[1]
local keyOperationIdempotency = KEYS[2]
local keyConstraintCheckIdempotency = KEYS[3]
local keyScavengerShard = KEYS[4]
local keyAccountLeases = KEYS[5]

---@type { k: string, e: string, f: string, s: {}[], cv: integer?, r: integer?, g: integer?, a: integer?, l: integer?, lik: string[]?, lri: table<string, string>?, m: { ss: integer?, sl: integer?, sm: integer? }? }
local requestDetails = cjson.decode(ARGV[1])
local requestID = ARGV[2]
local accountID = ARGV[3]
local nowMS = tonumber(ARGV[4]) --[[@as integer]]
local nowNS = tonumber(ARGV[5]) --[[@as integer]]
local leaseExpiryMS = tonumber(ARGV[6])
local scopedKeyPrefix = ARGV[7]
---@type string[]
local initialLeaseIDs = cjson.decode(ARGV[8])
if not initialLeaseIDs then
	return redis.error_reply("ERR initialLeaseIDs is nil after JSON decode")
end
local operationIdempotencyTTL = tonumber(ARGV[9])--[[@as integer]]
local constraintCheckIdempotencyTTL = tonumber(ARGV[10])--[[@as integer]]
local enableDebugLogs = tonumber(ARGV[11]) == 1
local cacheMinTTL = tonumber(ARGV[12]) or 0
local cacheMaxTTL = tonumber(ARGV[13]) or 0
local cacheKeyOffset = 14

if not requestDetails.lik then
	return redis.error_reply("ERR requestDetails.lik is nil during update")
end

if not initialLeaseIDs then
	return redis.error_reply("ERR initialLeaseIDs is nil during update")
end

---@type string[]
local debugLogs = {}
---@param ... string
local function debug(...)
	if enableDebugLogs then
		local args = { ... }
		table.insert(debugLogs, table.concat(args, " "))
	end
end

---@param key string
local function getConcurrencyCount(key)
	local count = call("ZCOUNT", key, tostring(nowMS), "+inf")
	if count == nil then
		return 0
	end
	return count
end

--- toInteger ensures a value is stored as an integer to prevent Redis scientific notation serialization
---@param value number
---@return integer
local function toInteger(value)
	return math.floor(value + 0.5) -- Round to nearest integer
end

local function addConstraintUsage(target, index, limit, used)
	local usage = {}
	usage["i"] = index
	usage["l"] = toInteger(limit or 0)
	usage["u"] = toInteger(math.max(used or 0, 0))
	table.insert(target, usage)
end

-- $include(helper/gcra.lua)

---@type integer
local requested = requestDetails.r

---@type integer
local configVersion = requestDetails.cv

---@type { k: integer, c: { m: integer?, s: integer?, h: string?, eh: string?, l: integer?, ilk: string?, ra: integer? }?, t: { s: integer?, h: string?, k: string, eh: string?, l: integer, b: integer, p: integer }?, r: { s: integer?, h: string, eh: string, l: integer, p: integer, k: string, b: integer }? }[]
local constraints = requestDetails.s
if not constraints then
	return redis.error_reply("ERR constraints array is nil")
end

-- Get operation idempotency and check existing request state in a single call
local results = call("MGET", keyOperationIdempotency, keyRequestState)
local opIdempotency = results[1]
local existingRequestState = results[2]

if opIdempotency ~= nil and opIdempotency ~= false then
	-- Return idempotency state to user (same as initial response)
	return { 1, opIdempotency }
end

-- If the same request state is still in progress (active leases), we cannot acquire more leases for the same request
-- This should never happen, as we generate a new ID for each request
if existingRequestState ~= nil and existingRequestState ~= false and existingRequestState ~= "" then
	local res = {}
	res["s"] = 4
	res["d"] = debugLogs

	return { 0, cjson.encode(res) }
end

-- TODO: Is the operation related to a single idempotency key that is still valid? Return that
-- TODO: This is basically the key queues case: What if the existing lease is still valid? And if it expired, can the
-- lease idempotency key be safely reused (should be fine)

-- TODO: Verify no far newer config was seen (reduce driftt)

-- Compute constraint capacity
local availableCapacity = requested

-- limitingConstraints tracks the indices of constraints reducing the
-- requested capacity. A constraint is only limiting if the number of
-- requested resources strictly exceeds its capacity.
---@type integer[]
local limitingConstraints = {}

-- exhaustedConstraints tracks all constraints that had no available
-- capacity. These will cause the Acquire request to produce no leases.
---@type integer[]
local exhaustedConstraints = {}

---@type table<integer, boolean>
local exhaustedSet = {}

-- NOTE: retry at is always the maximum retry time for exhausted constraints.
-- We do not include merely limiting constraints as more capacity is available.
-- The retry time MUST be recomputed after updating state to account for constraints
-- that have been exhausted.
local retryAt = 0

-- Cache concurrency usage from the first pass to avoid redundant ZCOUNT in the
-- update pass. Redis Lua is atomic, and Acquire uses freshly generated lease IDs,
-- so post-ZADD usage is the first-pass usage plus the granted amount.
---@type table<integer, integer>
local concurrencyUsageCache = {}

---@type { i: integer, l: integer, u: integer }[]
local constraintUsage = {}

-- Skip GCRA if constraint check idempotency key is present
local skipGCRA = call("EXISTS", keyConstraintCheckIdempotency) == 1

-- Check centralized constraint cache using individual ARGV entries.
-- Cache keys are only present in ARGV when caching is enabled (cacheMaxTTL > 0).
-- When disabled, skip entirely for zero overhead.
local cacheEnabled = cacheMaxTTL > 0
local constraintCacheKeys = {}
local cacheHit = false

if cacheEnabled then
	local mgetKeys = {}
	local mgetIndices = {}
	for i = 1, #constraints do
		local ck = ARGV[cacheKeyOffset + i - 1] or ""
		constraintCacheKeys[i] = ck
		if ck ~= "" then
			table.insert(mgetKeys, ck)
			table.insert(mgetIndices, i)
		end
	end

	if #mgetKeys > 0 then
		local cacheValues = call("MGET", unpack(mgetKeys))
		for j, val in ipairs(cacheValues) do
			if val ~= nil and val ~= false then
				cacheHit = true
				local idx = mgetIndices[j]
				local cachedRetryAt = tonumber(val) or 0

				if not exhaustedSet[idx] then
					table.insert(exhaustedConstraints, idx)
					exhaustedSet[idx] = true
				end
				table.insert(limitingConstraints, idx)

				if cachedRetryAt > retryAt then
					retryAt = cachedRetryAt
				end
				availableCapacity = 0
			end
		end
	end

	-- If cache hit, short-circuit immediately without evaluating constraints
	if cacheHit then
		local res = {}
		res["s"] = 2
		res["lc"] = limitingConstraints
		res["ec"] = exhaustedConstraints
		res["ra"] = retryAt
		res["d"] = debugLogs
		res["fr"] = 0
		res["ch"] = 1
		return { 0, cjson.encode(res) }
	end
end

for index, value in ipairs(constraints) do
	-- Retrieve constraint capacity
	local constraintCapacity = 0
	local constraintRetryAt = 0
	if skipGCRA and (value.k == 1 or value.k == 3) then
		-- skip constraint, don't mark as exhausted
		constraintCapacity = math.max(availableCapacity, 1)
	elseif value.k == 1 then
		-- rate limit
		local rlRes = rateLimit(value.r.k, nowNS, value.r.p, value.r.l, value.r.b, 0)
		constraintCapacity = rlRes["remaining"] or 0
		constraintRetryAt = toInteger(rlRes["retry_at"] / 1000000) -- convert from ns to ms
		addConstraintUsage(constraintUsage, index, value.r.l, rlRes["u"])
	elseif value.k == 2 then
		-- concurrency
		local inProgressLeases = getConcurrencyCount(value.c.ilk)
		constraintCapacity = value.c.l - inProgressLeases
		constraintRetryAt = toInteger(nowMS + value.c.ra)
		addConstraintUsage(constraintUsage, index, value.c.l, inProgressLeases)
		concurrencyUsageCache[index] = inProgressLeases
	elseif value.k == 3 then
		-- throttle
		-- allow consuming all capacity in one request (for generating multiple leases)
		local maxBurst = (value.t.l or 0) + (value.t.b or 0) - 1
		local throttleRes = throttle(value.t.k, nowMS, value.t.p, value.t.l, maxBurst, 0)
		constraintCapacity = throttleRes["remaining"] or 0
		constraintRetryAt = toInteger(throttleRes["retry_at"]) -- already in ms
		addConstraintUsage(constraintUsage, index, value.t.l, throttleRes["u"])
	elseif value.k == 4 then
		-- semaphore
		local usage = tonumber(call("GET", value.sem.k)) or 0
		local capacity = tonumber(call("GET", value.sem.ck)) or 0
		local weight = toInteger(value.sem.w)
		if not weight or weight <= 0 then
			weight = 1
		end
		local remaining = capacity - usage
		if remaining < weight then
			constraintCapacity = 0
		else
			constraintCapacity = math.floor(remaining / weight)
		end
		addConstraintUsage(constraintUsage, index, capacity, usage)
	end

	-- Track if constraint is exhausted before granting
	if constraintCapacity <= 0 then
		if not exhaustedSet[index] then
			table.insert(exhaustedConstraints, index)
			exhaustedSet[index] = true
		end

		-- if the constraint must be retried later than the initial/last constraint, update retryAfter
		if constraintRetryAt > retryAt then
			retryAt = constraintRetryAt
		end

		-- Write cache entry for exhausted constraint (skip if retryAt is not in the future)
		if cacheEnabled then
			local ck = constraintCacheKeys[index]
			if ck ~= nil and ck ~= "" and constraintRetryAt > nowMS then
				local cacheTTLSec =
					math.max(math.min(math.ceil((constraintRetryAt - nowMS) / 1000), cacheMaxTTL), cacheMinTTL)
				if cacheTTLSec > 0 then
					call("SET", ck, tostring(constraintRetryAt), "EX", tostring(cacheTTLSec))
				end
			end
		end
	end

	-- If index ends up limiting capacity, reduce available capacity and remember current constraint
	-- NOTE: If requested capacity is >= constraint capacity, the current constraint does not
	-- strictly limit lease generation, so we do not consider it a limiting constraint.
	if constraintCapacity < availableCapacity then
		availableCapacity = constraintCapacity
		table.insert(limitingConstraints, index)
	end
end

-- TODO: Handle fairness between other lease sources! Don't allow consuming entire capacity unfairly
local fairnessReduction = 0
-- TODO: How can we track and gracefully handle end to end that we ran out of capacity because for fairness?
availableCapacity = availableCapacity - fairnessReduction

-- TODO: If missing capacity, exit early (return limiting constraint and details)
if availableCapacity <= 0 then
	local res = {}
	res["s"] = 2
	res["lc"] = limitingConstraints
	res["ec"] = exhaustedConstraints
	res["ra"] = retryAt
	res["d"] = debugLogs
	res["fr"] = fairnessReduction
	res["ch"] = 0
	res["cu"] = constraintUsage

	return { 0, cjson.encode(res) }
end

local granted = availableCapacity

---@type { lid: string, lik: string }[]
local grantedLeases = {}

-- Collect arguments for batched ZADD to keyAccountLeases
local accountLeasesArgs = {}

-- Pre-compute key prefixes to avoid repeated string.format calls
local keyPrefixLeaseDetails = scopedKeyPrefix .. ":ld:"
local keyPrefixConstraintCheck = scopedKeyPrefix .. ":ik:cc:"

-- Update constraints

-- NOTE: We have to reset retryAt to reflect post-update state.
-- Again, this ONLY includes retry times for exhausted constraints.
retryAt = 0

-- Update constraint state
constraintUsage = {}
for i, value in ipairs(constraints) do
	local constraintRetryAt = 0
	local constraintCapacity = 0
	if skipGCRA and (value.k == 1 or value.k == 3) then
		-- skip constraint and don't mark as exhausted
		constraintCapacity = 1
	elseif value.k == 1 then
		-- rate limit
		local rlRes = rateLimit(value.r.k, nowNS, value.r.p, value.r.l, value.r.b, granted)
		constraintRetryAt = toInteger(rlRes["retry_at"] / 1000000)
		constraintCapacity = rlRes["remaining"] or 0
		addConstraintUsage(constraintUsage, i, value.r.l, rlRes["u"])
	elseif value.k == 2 then
		-- concurrency
		local updates = {}
		for j = 1, granted, 1 do
			local initialLeaseID = initialLeaseIDs[j]
			updates[(j - 1) * 2 + 1] = tostring(leaseExpiryMS)
			updates[(j - 1) * 2 + 2] = initialLeaseID
		end

		-- batch-update concurrency
		call("ZADD", value.c.ilk, unpack(updates))

		local inProgressLeases = (concurrencyUsageCache[i] or 0) + granted
		constraintCapacity = value.c.l - inProgressLeases
		constraintRetryAt = toInteger(nowMS + value.c.ra)
		addConstraintUsage(constraintUsage, i, value.c.l, inProgressLeases)
	elseif value.k == 3 then
		-- update throttle: consume 1 unit
		-- allow consuming all capacity in one request (for generating multiple leases)
		local maxBurst = (value.t.l or 0) + (value.t.b or 0) - 1
		local throttleRes = throttle(value.t.k, nowMS, value.t.p, value.t.l, maxBurst, granted)
		constraintRetryAt = toInteger(throttleRes["retry_at"])
		constraintCapacity = throttleRes["remaining"] or 0
		addConstraintUsage(constraintUsage, i, value.t.l, throttleRes["u"])
	elseif value.k == 4 then
		-- semaphore: increment usage counter
		local weight = value.sem.w
		if not weight or weight <= 0 then
			weight = 1
		end
		local newUsage = call("INCRBY", value.sem.k, toInteger(weight * granted))
		local capacity = tonumber(call("GET", value.sem.ck)) or 0
		local remaining = capacity - newUsage
		if remaining < weight then
			constraintCapacity = 0
		else
			constraintCapacity = math.floor(remaining / weight)
		end
		addConstraintUsage(constraintUsage, i, capacity, newUsage)
	end

	-- If we used up capacity after the update,
	-- add constraint to exhausted constraints
	if constraintCapacity <= 0 then
		if not exhaustedSet[i] then
			exhaustedSet[i] = true
			table.insert(exhaustedConstraints, i)
		end

		-- Use retryAt _after_ constraint update to reflect
		-- potentially changed state
		if constraintRetryAt > retryAt then
			retryAt = constraintRetryAt
		end

		-- Write cache entry for constraint exhausted after granting (skip if retryAt is not in the future)
		if cacheEnabled then
			local ck = constraintCacheKeys[i]
			if ck ~= nil and ck ~= "" and constraintRetryAt > nowMS then
				local cacheTTLSec =
					math.max(math.min(math.ceil((constraintRetryAt - nowMS) / 1000), cacheMaxTTL), cacheMinTTL)
				if cacheTTLSec > 0 then
					call("SET", ck, tostring(constraintRetryAt), "EX", tostring(cacheTTLSec))
				end
			end
		end
	end
end

-- Account for generated leases
for i = 1, granted, 1 do
	local hashedLeaseIdempotencyKey = requestDetails.lik[i]
	local leaseRunID = (requestDetails.lri ~= nil and requestDetails.lri[hashedLeaseIdempotencyKey]) or ""
	local initialLeaseID = initialLeaseIDs[i]

	local keyLeaseDetails = keyPrefixLeaseDetails .. initialLeaseID

	-- Store lease details (hashed lease idempotency key, associated run ID, operation idempotency key for request details)
	call("HSET", keyLeaseDetails, "lik", hashedLeaseIdempotencyKey, "rid", leaseRunID, "req", requestID)

	-- Collect arguments for batched ZADD to account leases (executed after loop)
	accountLeasesArgs[(i - 1) * 2 + 1] = tostring(leaseExpiryMS)
	accountLeasesArgs[(i - 1) * 2 + 2] = initialLeaseID

	-- Add constraint check idempotency for each lease (for graceful handling in rate limit, Lease, BacklogRefill, as well as Acquire in case lease expired)
	local keyLeaseConstraintCheckIdempotency = keyPrefixConstraintCheck .. hashedLeaseIdempotencyKey
	call("SET", keyLeaseConstraintCheckIdempotency, tostring(nowMS), "EX", tostring(constraintCheckIdempotencyTTL))

	---@type { lid: string, lik: string }
	local leaseObject = {}
	leaseObject["lid"] = initialLeaseID
	leaseObject["lik"] = hashedLeaseIdempotencyKey

	grantedLeases[i] = leaseObject
end

-- Batch add all leases to account leases sorted set
if #accountLeasesArgs > 0 then
	call("ZADD", keyAccountLeases, unpack(accountLeasesArgs))
end

call("SET", keyConstraintCheckIdempotency, tostring(nowMS), "EX", tostring(constraintCheckIdempotencyTTL))

-- For step concurrency, add the lease idempotency keys to the new in progress leases sets using the lease expiry as score
-- For run concurrency, add the runID to the in progress runs set and the lease idempotency key to the dynamic run in progress leases set

-- Populate request details
requestDetails.g = availableCapacity
requestDetails.a = availableCapacity

-- Store request details
call("SET", keyRequestState, cjson.encode(requestDetails))

-- Update pointer to account leases
local accountScore = call("ZSCORE", keyScavengerShard, accountID)
if accountScore == nil or accountScore == false or tonumber(accountScore) > leaseExpiryMS then
	call("ZADD", keyScavengerShard, tonumber(leaseExpiryMS), accountID)
end

-- Construct result

---@type { s: integer, lc: integer[], ec: integer[], fr: integer, r: integer, g: integer, l: { lid: string, lik: string }[] }
local result = {}

result["s"] = 3
result["r"] = requested
result["g"] = granted
result["l"] = grantedLeases
result["lc"] = limitingConstraints
result["ec"] = exhaustedConstraints
result["ra"] = retryAt -- include retryAt to hint when next capacity is available
result["d"] = debugLogs
result["fr"] = fairnessReduction
result["ch"] = 0
result["cu"] = constraintUsage

local encoded = cjson.encode(result)

-- Set operation idempotency TTL
call("SET", keyOperationIdempotency, encoded, "EX", tostring(operationIdempotencyTTL))

return { 0, encoded }
