package apiv1

import (
	"encoding/json"
	"fmt"
	"net/http"
	"time"

	"github.com/go-chi/chi/v5"
	"github.com/go-chi/chi/v5/middleware"
	"github.com/inngest/inngest/pkg/api"
	"github.com/inngest/inngest/pkg/api/apiv1/apiv1auth"
	"github.com/inngest/inngest/pkg/consts"
	"github.com/inngest/inngest/pkg/cqrs"
	"github.com/inngest/inngest/pkg/event"
	"github.com/inngest/inngest/pkg/execution"
	"github.com/inngest/inngest/pkg/execution/queue"
	"github.com/inngest/inngest/pkg/execution/realtime"
	"github.com/inngest/inngest/pkg/execution/state/v2"
	"github.com/inngest/inngest/pkg/headers"
	"github.com/inngest/inngest/pkg/tracing"
	"golang.org/x/sync/semaphore"
)

// Opts represents options for the APIv1 router.
type Opts struct {
	// AuthMiddleware authenticates the incoming API request.
	AuthMiddleware func(http.Handler) http.Handler
	// CachingMiddleware caches API responses, if the handler specifies
	// a max-age.
	CachingMiddleware CachingMiddleware[[]byte]
	// RateLimiter is called within an API endpoint with a route to determine whether
	// the route is rate limited.  If so, this should write a rate limit response
	// via publicerr.
	RateLimited func(r *http.Request, w http.ResponseWriter, route string) bool
	// WorkspaceFinder returns the authenticated workspace given the current context.
	AuthFinder apiv1auth.AuthFinder

	// Executor is required to cancel and manage function executions.
	Executor execution.Executor
	// QueueProducer allows checkpointing to continue runs by enqueueing items.
	QueueProducer queue.Producer
	// RunQueueReader supports run-job reads.
	RunQueueReader queue.RunQueueReader
	// QueueItemReader supports async dispatch validation.
	QueueItemReader queue.QueueItemReader
	// AttemptResetter resets attempts after successful async checkpoints.
	AttemptResetter queue.AttemptResetter
	// FunctionReader reads functions from a backing store.
	FunctionReader cqrs.FunctionReader
	// CancellationReadWriter reads and writes cancellations to/from a backing store.
	CancellationReadWriter cqrs.CancellationReadWriter
	// QueueShards exposes the shard topology and selector for the API.
	QueueShards queue.ShardRegistry
	// Broadcaster is used to handle realtime via APIv1
	Broadcaster realtime.Broadcaster
	// TraceReader reads traces from a backing store.
	TraceReader cqrs.TraceReader
	// MetricsMiddleware is used to instrument the APIv1 endpoints.
	MetricsMiddleware api.MetricsMiddleware
	// LoggingMiddleware, if set, is applied immediately after the auth
	// middleware so the request-scoped logger it reads already carries the
	// authenticated account/user attributes. Callers (e.g. cloud) supply the
	// implementation; the dev server leaves it nil.
	LoggingMiddleware api.LoggingMiddleware

	// ExtendedTraceCapCheck is consulted after /v1/traces/userland reads and
	// parses a valid payload, but before it writes spans. Implementations return
	// a decision, not an immediate rejection: over-cap payloads are parsed so
	// callers can account for rejected bytes/spans before the handler returns
	// 429. Nil hook means "always accept" — the right default for self-host,
	// which has no billing relationship.
	ExtendedTraceCapCheck ExtendedTraceCapChecker
	// ExtendedTraceRejectedRecorder is called after an over-cap payload is
	// successfully parsed, before the handler returns 429. Cloud uses this to
	// record customer_execution_metrics and Redis overage counters without
	// writing rejected spans to ClickHouse/Kafka. Nil hook is a no-op.
	ExtendedTraceRejectedRecorder ExtendedTraceRejectedRecorder

	// AppCreator is used with HTTP/API-based functions to create apps on the fly via checkpointing.
	AppCreator cqrs.AppCreator
	// FunctionCreator is used with HTTP/API-based functions to create functions on the fly via checkpointing.
	FunctionCreator cqrs.FunctionCreator
	// EventPublisher publishes events via HTTP/API-based functions
	EventPublisher event.Publisher
	// TracerProvider is used to create spans within the APIv1 endpoints and allows the checkpointing API to write traces.
	TracerProvider tracing.TracerProvider
	// State allows loading and mutating state from various checkpointing APIs.
	State state.RunService

	// RealtimeJWTSecret is the realtime JWT secret for the V1 API
	RealtimeJWTSecret []byte

	// CheckpointOpts represents required opts for the checkpoint API
	CheckpointOpts CheckpointAPIOpts

	// MetadataOpts represents the required opts for the metadadata API
	MetadataOpts MetadataOpts
}

type checkpointQueue struct {
	queue.Producer
	queue.QueueItemReader
	queue.AttemptResetter
}

func noopRateChecker(r *http.Request, w http.ResponseWriter, route string) bool {
	return false
}

// AddRoutes adds a new API handler to the given router.
func AddRoutes(r chi.Router, o Opts) http.Handler {
	if o.RateLimited == nil {
		o.RateLimited = noopRateChecker
	}

	if o.AuthFinder == nil {
		o.AuthFinder = apiv1auth.NilAuthFinder
	}

	// Create the HTTP implementation, which wraps the handler.  We do ths to code
	// share and split the HTTP concerns from the actual logic, eg. to share to GQL.
	impl := &API{
		opts:                     o,
		rejectedTraceRecorderSem: semaphore.NewWeighted(consts.MaxConcurrentRejectedTraceRecorders),
	}

	instance := &router{
		Router: r,
		API:    impl,
	}

	instance.setup()
	return instance
}

type API struct {
	opts Opts

	// rejectedTraceRecorderSem bounds the goroutine pool that runs the
	// ExtendedTraceRejectedRecorder, capping concurrent calls. Initialized by
	// AddRoutes.
	rejectedTraceRecorderSem *semaphore.Weighted
}

type router struct {
	*API
	chi.Router
}

func (a *router) setup() {
	a.Group(func(r chi.Router) {
		r.Use(middleware.Recoverer)

		if len(a.opts.RealtimeJWTSecret) > 0 {
			// Only enable realtime if secrets are set.
			r.Group(func(r chi.Router) {
				rt := realtime.NewAPI(realtime.APIOpts{
					JWTSecret:      a.opts.RealtimeJWTSecret,
					Broadcaster:    a.opts.Broadcaster,
					AuthMiddleware: a.opts.AuthMiddleware,
					AuthFinder:     a.opts.AuthFinder,
				})
				r.Mount("/", rt)
			})
		}

		// Checkpoint output API does its own auth (using query params), so
		// should not be wrapped with the general auth middleware.
		{
			api := NewCheckpointAPI(a.opts)
			for _, prefix := range CheckpointRoutePrefixes {
				r.Get(prefix+"/{runID}/output", api.Output)
			}
		}

		r.Group(func(r chi.Router) {
			if a.opts.AuthMiddleware != nil {
				r.Use(a.opts.AuthMiddleware)
			}

			if a.opts.CachingMiddleware != nil {
				r.Use(a.opts.CachingMiddleware.Middleware)
			}

			if a.opts.MetricsMiddleware != nil {
				r.Use(a.opts.MetricsMiddleware.Middleware)
			}

			if a.opts.LoggingMiddleware != nil {
				r.Use(a.opts.LoggingMiddleware.Middleware)
			}

			r.Use(headers.ContentTypeJsonResponse())

			// Add the HTTP-based checkpointing API.  Note that for backcompat,
			// this exists at two URLs.
			{
				api := NewCheckpointAPI(a.opts)
				for _, prefix := range CheckpointRoutePrefixes {
					r.Route(prefix, func(sub chi.Router) {
						sub.Mount("/", api)
					})
				}
			}

			r.Post("/signals", a.receiveSignal)

			r.Get("/events", a.getEvents)
			r.Get("/events/{eventID}", a.getEvent)
			r.Get("/events/{eventID}/runs", a.getEventRuns)
			r.Get("/runs/{runID}", a.GetFunctionRun)
			r.Delete("/runs/{runID}", a.cancelFunctionRun)
			r.Get("/runs/{runID}/jobs", a.GetFunctionRunJobs)
			r.Post("/runs/{runID}/metadata", a.addRunMetadata)

			r.Get("/apps/{appName}/functions", a.GetAppFunctions) // Returns an app and all of its functions.

			r.Post("/cancellations", a.createCancellation)
			r.Get("/cancellations", a.getCancellations)
			r.Delete("/cancellations/{id}", a.deleteCancellation)

			r.Get("/prom/{env}", a.promScrape)

			r.Post("/traces/userland", a.traces)
		})
	})
}

func WriteResponse[T any](w http.ResponseWriter, data T) error {
	return WriteCachedResponse(w, data, 0)
}

func WriteCachedResponse[T any](w http.ResponseWriter, data T, cachePeriod time.Duration) error {
	resp := Response[T]{
		Data: data,
		Metadata: ResponseMetadata{
			FetchedAt: time.Now(),
		},
	}

	if cachePeriod.Seconds() > 0 {
		cachedUntil := time.Now().Add(cachePeriod)
		resp.Metadata.CachedUntil = &cachedUntil
		// Set a max-age header if the response is cacheable.  This instructs
		// our caching middleware to cache the result for this period of time.
		w.Header().Set("Cache-Control", fmt.Sprintf("private, max-age=%d", int(cachePeriod.Seconds())))
	}

	return json.NewEncoder(w).Encode(resp)
}

// Response represents
type Response[T any] struct {
	Data     T                `json:"data"`
	Metadata ResponseMetadata `json:"metadata"`
}

// ResponseMetadata represents metadata regarding the response.
type ResponseMetadata struct {
	FetchedAt   time.Time  `json:"fetched_at,omitzero,omitempty"`
	CachedUntil *time.Time `json:"cached_until,omitempty"`
}
