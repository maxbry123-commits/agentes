// Copyright 2019 The gVisor Authors.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package systrap

import (
	"gvisor.dev/gvisor/pkg/sentry/arch"
)

func stackPointer(r *arch.Registers) uintptr {
	return uintptr(r.Rsp)
}

// nominalTSCFreq is the assumed frequency in Hz of the x86 TSC read by
// cputicks(). The TSC is invariant (it ticks at a fixed reference rate
// independent of the core clock), but its exact frequency is not cheaply
// discoverable, so cputicksFreq() assumes this nominal ~2GHz.
const nominalTSCFreq = 2 * 1000 * 1000 * 1000

// cputicksFreq returns the frequency in Hz of the counter read by cputicks().
func cputicksFreq() uint64 {
	return nominalTSCFreq
}

// x86 use the fs_base register to store the TLS pointer which can be
// get/set in "func (t *thread) get/setRegs(regs *arch.Registers)".
// So both of the get/setTLS() operations are noop here.

// getTLS gets the thread local storage register.
func (t *thread) getTLS(tls *uint64) error {
	return nil
}

// setTLS sets the thread local storage register.
func (t *thread) setTLS(tls *uint64) error {
	return nil
}

// configureSystrapAddressSpace is a no-op on amd64.
//
// On ARM64, this function overrides the default 48-bit address space
// parameters to support 39-bit and 52-bit VA widths. On amd64, the
// address space layout is fixed and does not require dynamic
// configuration, so this is intentionally empty.
func configureSystrapAddressSpace() {}
