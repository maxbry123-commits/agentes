import { api } from 'lib/api.mock'

import { router } from 'kea-router'
import { expectLogic } from 'kea-test-utils'

import { lemonToast } from 'lib/lemon-ui/LemonToast/LemonToast'
import { NEW_FLAG } from 'scenes/feature-flags/featureFlagLogic'
import { urls } from 'scenes/urls'

import { resumeKeaLoadersErrors, silenceKeaLoadersErrors } from '~/initKea'
import { initKeaTests } from '~/test/init'
import { Experiment, ExperimentStatus, ExperimentsTabs, FeatureFlagType } from '~/types'

import {
    getExperimentStatus,
    hasEnded,
    isExperimentExposureFrozen,
    isExperimentPaused,
} from 'products/experiments/frontend/experimentStatus'
import {
    experimentsLogic,
    getExperimentStatusColor,
    getExperimentStatusLabel,
} from 'products/experiments/frontend/scenes/experimentsLogic'

const createMockExperiment = (overrides: any = {}): Experiment =>
    ({
        id: 1,
        name: 'Test Experiment',
        feature_flag_key: 'test-experiment',
        start_date: '2023-01-01T00:00:00Z',
        end_date: '2023-01-07T00:00:00Z',
        status: ExperimentStatus.Stopped,
        archived: false,
        ...overrides,
    }) as Experiment

const mockExperiment = createMockExperiment()

const mockRunningExperiment = createMockExperiment({
    id: 2,
    name: 'Running Experiment',
    start_date: '2023-01-01T00:00:00Z',
    end_date: null,
    status: ExperimentStatus.Running,
})

const mockDraftExperiment = createMockExperiment({
    id: 3,
    name: 'Draft Experiment',
    start_date: null,
    end_date: null,
    status: ExperimentStatus.Draft,
})

const mkFlag = (id: number, key: string): FeatureFlagType => ({ ...NEW_FLAG, id, key })

describe('experimentsLogic', () => {
    afterEach(resumeKeaLoadersErrors)
    let logic: ReturnType<typeof experimentsLogic.build>

    beforeEach(() => {
        initKeaTests()
        jest.spyOn(api, 'get')
        jest.spyOn(api, 'update')
        jest.spyOn(api, 'create')
        api.get.mockClear()
        api.update.mockClear()
        api.create.mockClear()
        logic = experimentsLogic()
        logic.mount()
    })

    describe('feature flag modal filters', () => {
        it('updates filters and triggers new API call', async () => {
            api.get.mockClear()

            await expectLogic(logic, () => {
                logic.actions.setFeatureFlagModalFilters({ search: 'test', page: 1 })
            })
                .toMatchValues({
                    featureFlagModalFilters: expect.objectContaining({
                        search: 'test',
                        page: 1,
                    }),
                })
                .delay(350) // Wait for debounce
                .toFinishAllListeners()

            expect(api.get).toHaveBeenCalledWith(expect.stringContaining('search=test'))
        })

        // we use expectLogic for assertions
        // eslint-disable-next-line jest/expect-expect
        it('resets filters to defaults', async () => {
            await expectLogic(logic, () => {
                logic.actions.setFeatureFlagModalFilters({ search: 'test' })
                logic.actions.resetFeatureFlagModalFilters()
            }).toMatchValues({
                featureFlagModalFilters: {
                    active: undefined,
                    created_by_id: undefined,
                    search: undefined,
                    order: undefined,
                    page: 1,
                    evaluation_runtime: undefined,
                },
            })
        })

        it('resets filters and reloads feature flags', async () => {
            api.get.mockClear()

            await expectLogic(logic, () => {
                logic.actions.setFeatureFlagModalFilters({ search: 'test' })
            })
                .delay(350) // Wait for debounce
                .toFinishAllListeners()

            api.get.mockClear()

            await expectLogic(logic, () => {
                logic.actions.resetFeatureFlagModalFilters()
            })
                .toMatchValues({
                    featureFlagModalFilters: {
                        active: undefined,
                        created_by_id: undefined,
                        search: undefined,
                        order: undefined,
                        page: 1,
                        evaluation_runtime: undefined,
                    },
                })
                .toFinishAllListeners()

            expect(api.get).toHaveBeenCalledWith(expect.stringMatching(/api\/projects\/\d+\/feature_flags\/\?/))
        })

        it('hides pagination when insufficient results', () => {
            // Set up a scenario with few results (less than FLAGS_PER_PAGE)
            logic.actions.loadFeatureFlagModalFeatureFlagsSuccess({
                results: [mkFlag(1, 'flag1'), mkFlag(2, 'flag2')],
                count: 2,
            })

            expect(logic.values.featureFlagModalPagination.onForward).toBe(undefined)
            expect(logic.values.featureFlagModalPagination.onBackward).toBe(undefined)
        })

        it('shows pagination when results exceed page size', () => {
            // Set up a scenario with many results (more than FLAGS_PER_PAGE = 100)
            const manyResults = Array.from({ length: 50 }, (_, i) => mkFlag(i, `flag${i}`))
            logic.actions.loadFeatureFlagModalFeatureFlagsSuccess({
                results: manyResults,
                count: 150, // Total count is more than one page
            })

            expect(logic.values.featureFlagModalPagination.onForward).toBeTruthy()
            expect(logic.values.featureFlagModalPagination.onBackward).toBe(undefined) // First page, no backward
        })

        it('shows backward pagination on non-first page', () => {
            logic.actions.setFeatureFlagModalFilters({ page: 2 })

            const manyResults = Array.from({ length: 50 }, (_, i) => mkFlag(i, `flag${i}`))
            logic.actions.loadFeatureFlagModalFeatureFlagsSuccess({
                results: manyResults,
                count: 250, // Total count spans multiple pages
            })

            expect(logic.values.featureFlagModalPagination.onForward).toBeTruthy()
            expect(logic.values.featureFlagModalPagination.onBackward).toBeTruthy()
        })

        it('hides pagination when on page 2+ but filtered results are insufficient', () => {
            // User navigates to page 2
            logic.actions.setFeatureFlagModalFilters({ page: 2 })

            // Then applies filter that results in very few results (less than FLAGS_PER_PAGE)
            logic.actions.loadFeatureFlagModalFeatureFlagsSuccess({
                results: [mkFlag(1, 'filtered-flag1'), mkFlag(2, 'filtered-flag2')],
                count: 2, // Only 2 total results, not enough for pagination
            })

            // Pagination should be hidden since total results don't warrant it
            expect(logic.values.featureFlagModalPagination.onForward).toBe(undefined)
            expect(logic.values.featureFlagModalPagination.onBackward).toBe(undefined)
        })

        it('resets page to 1 when search filter is applied from page 2', () => {
            // User navigates to page 2
            logic.actions.setFeatureFlagModalFilters({ page: 2 })
            expect(logic.values.featureFlagModalFilters.page).toBe(2)

            // User applies a search filter (simulating what FeatureFlagFiltersSection does)
            logic.actions.setFeatureFlagModalFilters({ search: 'test', page: 1 })

            // Should reset to page 1
            expect(logic.values.featureFlagModalFilters.page).toBe(1)
            expect(logic.values.featureFlagModalFilters.search).toBe('test')
        })

        it('removes ff_page URL parameter when page is reset to 1 via filters', () => {
            // Mock router to capture URL changes (uses replace, not push, to avoid polluting browser history)
            const mockReplace = jest.fn()
            router.actions.replace = mockReplace

            // User navigates to page 2 first
            logic.actions.setFeatureFlagModalFilters({ page: 2 })

            // This should add ff_page=2 to URL
            expect(mockReplace).toHaveBeenLastCalledWith(expect.stringContaining('ff_page=2'))

            mockReplace.mockClear()

            // User applies a search filter which includes page: 1
            logic.actions.setFeatureFlagModalFilters({ search: 'test', page: 1 })

            // This should remove ff_page from URL (since page is 1)
            expect(mockReplace).toHaveBeenLastCalledWith(expect.not.stringContaining('ff_page'))
        })

        // we use expectLogic for assertions
        // eslint-disable-next-line jest/expect-expect
        it('constructs API params correctly', async () => {
            logic.actions.setFeatureFlagModalFilters({
                search: 'test',
                active: 'true',
                page: 2,
            })

            await expectLogic(logic).toMatchValues({
                featureFlagModalParamsFromFilters: {
                    search: 'test',
                    active: 'true',
                    page: 2,
                    limit: 100,
                    offset: 100,
                },
            })
        })
    })

    describe('experiments filtering and loading', () => {
        beforeEach(() => {
            api.get.mockClear()
        })

        it('loads experiments on mount', async () => {
            api.get.mockClear()

            await expectLogic(logic, () => {
                logic.actions.loadExperiments()
            }).toFinishAllListeners()

            expect(api.get).toHaveBeenCalledWith(expect.stringMatching(/api\/projects\/\d+\/experiments\?/))
        })

        it('updates filters and triggers API call with debounce', async () => {
            api.get.mockClear()

            await expectLogic(logic, () => {
                logic.actions.setExperimentsFilters({ search: 'test experiment' })
            })
                .delay(350)
                .toFinishAllListeners()

            expect(api.get).toHaveBeenCalledWith(expect.stringContaining('search=test%20experiment'))
        })

        it('filters archived experiments', async () => {
            api.get.mockClear()

            await expectLogic(logic, () => {
                logic.actions.setExperimentsFilters({ archived: true })
            })
                .delay(350)
                .toFinishAllListeners()

            expect(api.get).toHaveBeenCalledWith(expect.stringContaining('archived=true'))
        })

        it('discards a stale search response that resolves after a newer one', async () => {
            api.get.mockClear()

            const staleExperiment = createMockExperiment({ id: 10, name: 'wat' })
            const freshExperiment = createMockExperiment({ id: 20, name: 'watermark' })

            let resolveStale: (value: unknown) => void = () => {}
            api.get.mockImplementationOnce(
                () =>
                    new Promise((resolve) => {
                        resolveStale = resolve
                    })
            )
            api.get.mockResolvedValueOnce({ results: [freshExperiment], count: 1 })

            await expectLogic(logic, () => {
                logic.actions.loadExperiments() // slow request, e.g. search for "wat"
                logic.actions.loadExperiments() // fast request, e.g. search for "watermark"
            }).toDispatchActions(['loadExperimentsSuccess'])

            expect(logic.values.experiments.results).toEqual([freshExperiment])

            // The slow, stale response arrives after the newer one — it must be discarded
            resolveStale({ results: [staleExperiment], count: 1 })
            await expectLogic(logic).toFinishAllListeners()

            expect(logic.values.experiments.results).toEqual([freshExperiment])
        })

        it('constructs correct params from filters', () => {
            logic.actions.setExperimentsFilters({
                search: 'test',
                status: ExperimentStatus.Running,
                page: 2,
            })

            expect(logic.values.paramsFromFilters).toEqual({
                search: 'test',
                status: ExperimentStatus.Running,
                page: 2,
                limit: 100,
                offset: 100,
                archived: false,
            })
        })
    })

    describe('experiment CRUD operations', () => {
        beforeEach(() => {
            router.actions.push = jest.fn()
        })

        it('archives experiment', async () => {
            const initialExperiments = { results: [mockExperiment], count: 1 }
            logic.actions.loadExperimentsSuccess(initialExperiments)

            api.create.mockResolvedValue({})

            await expectLogic(logic, () => {
                logic.actions.archiveExperiment({ id: mockExperiment.id as number, disableFeatureFlag: false })
            })
                .toFinishAllListeners()
                .toMatchValues({
                    experiments: expect.objectContaining({
                        results: [],
                        count: 0,
                    }),
                })

            expect(api.create).toHaveBeenCalledWith(
                expect.stringContaining(`/experiments/${mockExperiment.id}/archive`),
                { disable_feature_flag: false }
            )
        })

        it('duplicates experiment and navigates to it', async () => {
            const duplicatedExperiment = createMockExperiment({ id: 999 })
            api.create.mockResolvedValue(duplicatedExperiment)

            const initialExperiments = { results: [mockExperiment], count: 1 }
            logic.actions.loadExperimentsSuccess(initialExperiments)

            await expectLogic(logic, () => {
                logic.actions.duplicateExperiment({ id: mockExperiment.id as number, featureFlagKey: 'new-flag' })
            }).toFinishAllListeners()

            expect(api.create).toHaveBeenCalledWith(
                expect.stringContaining(`/experiments/${mockExperiment.id}/duplicate`),
                { feature_flag_key: 'new-flag' }
            )
            expect(router.actions.push).toHaveBeenCalledWith(expect.stringContaining('/999'))
        })

        it('copies experiment to the selected target team', async () => {
            const copiedExperiment = createMockExperiment({ id: 999 })
            api.create.mockResolvedValue(copiedExperiment)

            await expectLogic(logic, () => {
                logic.actions.copyExperimentToProject({
                    id: mockExperiment.id as number,
                    targetProjectId: 123,
                    targetTeamId: 456,
                    featureFlagKey: 'new-flag',
                })
            }).toFinishAllListeners()

            expect(api.create).toHaveBeenCalledWith(
                expect.stringContaining(`/experiments/${mockExperiment.id}/copy_to_project`),
                { target_team_id: 456, feature_flag_key: 'new-flag' }
            )
        })

        it('uses the target project id in the copy success link', async () => {
            const copiedExperiment = createMockExperiment({ id: 999 })
            api.create.mockResolvedValue(copiedExperiment)

            const toastSpy = jest.spyOn(lemonToast, 'success').mockImplementation(jest.fn())
            const projectSpy = jest.spyOn(urls, 'project').mockImplementation(() => {
                throw new Error('navigation-called')
            })

            await expectLogic(logic, () => {
                logic.actions.copyExperimentToProject({
                    id: mockExperiment.id as number,
                    targetProjectId: 123,
                    targetTeamId: 456,
                })
            }).toFinishAllListeners()

            const toastOptions = toastSpy.mock.calls.at(-1)?.[1] as { button?: { action?: () => void } } | undefined

            expect(toastOptions?.button?.action).not.toBeUndefined()
            expect(() => toastOptions?.button?.action?.()).toThrow('navigation-called')
            expect(projectSpy).toHaveBeenCalledWith(123, expect.stringContaining('/999'))
        })

        it('runs the copy success callback only after a successful copy', async () => {
            const copiedExperiment = createMockExperiment({ id: 999 })
            const onSuccess = jest.fn()
            api.create.mockResolvedValue(copiedExperiment)

            await expectLogic(logic, () => {
                logic.actions.copyExperimentToProject({
                    id: mockExperiment.id as number,
                    targetProjectId: 123,
                    targetTeamId: 456,
                    onSuccess,
                })
            }).toFinishAllListeners()

            expect(onSuccess).toHaveBeenCalledTimes(1)
        })

        it('does not run the copy success callback when the copy fails', async () => {
            silenceKeaLoadersErrors()
            const onSuccess = jest.fn()
            api.create.mockRejectedValue(new Error('Permission denied'))

            await expectLogic(logic, () => {
                logic.actions.copyExperimentToProject({
                    id: mockExperiment.id as number,
                    targetProjectId: 123,
                    targetTeamId: 456,
                    onSuccess,
                })
            }).toFinishAllListeners()

            expect(onSuccess).not.toHaveBeenCalled()
        })

        it('adds experiment to list', () => {
            const initialExperiments = { results: [mockExperiment], count: 1 }
            logic.actions.loadExperimentsSuccess(initialExperiments)

            logic.actions.addToExperiments(mockRunningExperiment)

            expect(logic.values.experiments).toEqual({
                results: [mockExperiment, mockRunningExperiment],
                count: 2,
            })
        })

        it('updates experiment in list', () => {
            const initialExperiments = { results: [mockExperiment], count: 1 }
            logic.actions.loadExperimentsSuccess(initialExperiments)

            const updatedExperiment = createMockExperiment({ name: 'Updated Name' })
            logic.actions.updateExperiments(updatedExperiment)

            expect(logic.values.experiments).toEqual({
                results: [updatedExperiment],
                count: 1,
            })
        })
    })

    describe('activity deep-link', () => {
        it('preserves the activity deep-link param when staying on the history tab', async () => {
            router.actions.push(urls.experiments(), { tab: 'history', activity: 'some-uuid' })
            await expectLogic(logic, () => {
                logic.actions.setExperimentsTab(ExperimentsTabs.History)
            })
            expect(router.values.searchParams['activity']).toEqual('some-uuid')
        })

        it('drops the activity deep-link param when switching away from the history tab', async () => {
            router.actions.push(urls.experiments(), { tab: 'history', activity: 'some-uuid' })
            await expectLogic(logic, () => {
                logic.actions.setExperimentsTab(ExperimentsTabs.All)
            })
            expect(router.values.searchParams['activity']).toBeUndefined()
        })
    })

    describe('selectors', () => {
        it('calculates pagination correctly', () => {
            logic.actions.setExperimentsFilters({ page: 2 })
            logic.actions.loadExperimentsSuccess({ results: [], count: 150 })

            expect(logic.values.pagination).toEqual({
                controlled: true,
                pageSize: 100,
                currentPage: 2,
                entryCount: 150,
            })
        })
    })
})

describe('utility functions', () => {
    describe('getExperimentStatus', () => {
        it('returns Draft for experiments without start date', () => {
            expect(getExperimentStatus(mockDraftExperiment)).toBe(ExperimentStatus.Draft)
        })

        it('returns Running for experiments with start date but no end date', () => {
            expect(getExperimentStatus(mockRunningExperiment)).toBe(ExperimentStatus.Running)
        })

        it('returns Stopped for experiments with both start and end dates', () => {
            expect(getExperimentStatus(mockExperiment)).toBe(ExperimentStatus.Stopped)
        })

        it('returns Running when feature flag is active', () => {
            const runningExperiment = createMockExperiment({
                start_date: '2024-01-01',
                end_date: null,
                status: ExperimentStatus.Running,
                feature_flag: { active: true },
            })
            expect(getExperimentStatus(runningExperiment)).toBe(ExperimentStatus.Running)
        })
    })

    describe('isExperimentPaused', () => {
        it('returns true when the API status is paused', () => {
            const pausedExperiment = createMockExperiment({
                start_date: '2024-01-01',
                end_date: null,
                status: ExperimentStatus.Paused,
                feature_flag: { active: false },
            })

            expect(isExperimentPaused(pausedExperiment)).toBe(true)
        })

        it('returns false when the experiment is running', () => {
            const runningExperiment = createMockExperiment({
                start_date: '2024-01-01',
                end_date: null,
                status: ExperimentStatus.Running,
                feature_flag: { active: true },
            })

            expect(isExperimentPaused(runningExperiment)).toBe(false)
        })
    })

    describe('getExperimentStatus', () => {
        it('returns ExposureFrozen when the API status is exposure_frozen', () => {
            const frozenExperiment = createMockExperiment({
                start_date: '2024-01-01',
                end_date: null,
                status: ExperimentStatus.ExposureFrozen,
                feature_flag: { active: true },
            })
            expect(getExperimentStatus(frozenExperiment)).toBe(ExperimentStatus.ExposureFrozen)
            expect(isExperimentExposureFrozen(frozenExperiment)).toBe(true)
        })
    })

    describe('getExperimentStatusColor', () => {
        it('returns correct colors for each status', () => {
            expect(getExperimentStatusColor(ExperimentStatus.Draft)).toBe('default')
            expect(getExperimentStatusColor(ExperimentStatus.Running)).toBe('success')
            expect(getExperimentStatusColor(ExperimentStatus.Paused)).toBe('warning')
            expect(getExperimentStatusColor(ExperimentStatus.ExposureFrozen)).toBe('highlight')
            expect(getExperimentStatusColor(ExperimentStatus.Stopped)).toBe('completion')
        })
    })

    describe('getExperimentStatusLabel', () => {
        it('labels exposure_frozen as Exposure frozen', () => {
            expect(getExperimentStatusLabel(ExperimentStatus.ExposureFrozen)).toBe('Exposure frozen')
        })
    })

    describe('hasEnded', () => {
        it.each([
            { status: ExperimentStatus.Running, expected: false, desc: 'running experiment' },
            { status: ExperimentStatus.Draft, expected: false, desc: 'draft experiment' },
            { status: ExperimentStatus.Stopped, expected: true, desc: 'stopped experiment' },
            {
                end_date: '2099-01-01T00:00:00Z',
                status: undefined,
                expected: true,
                desc: 'legacy fallback still treats any saved end date as stopped',
            },
        ])('returns $expected when $desc', ({ end_date, status, expected }) => {
            expect(hasEnded(createMockExperiment({ end_date, status }))).toBe(expected)
        })
    })
})
