import dataclasses
from typing import Final, Literal

# Shared by the workflow definition, the schedule, and the management command.
CANARY_WORKFLOW_NAME = "experiment-precompute-canary"

CanaryOutcome = Literal["pass", "divergence", "path_flip", "error", "skipped"]

OUTCOME_PASS: Final = "pass"
OUTCOME_DIVERGENCE: Final = "divergence"
OUTCOME_PATH_FLIP: Final = "path_flip"
OUTCOME_ERROR: Final = "error"
OUTCOME_SKIPPED: Final = "skipped"
ALL_OUTCOMES: tuple[CanaryOutcome, ...] = (
    OUTCOME_PASS,
    OUTCOME_DIVERGENCE,
    OUTCOME_PATH_FLIP,
    OUTCOME_ERROR,
    OUTCOME_SKIPPED,
)

# Cap CanaryMetricResult.detail so a pathological error message can't bloat the Temporal payload.
MAX_CANARY_DETAIL_LENGTH = 1000

# Max attempts per metric before it's marked failed on the recalculation workflow.
MAX_METRIC_ATTEMPTS = 8

# Retry delay for a calc attempt that bounced off the per-org ClickHouse concurrency limiter or the cluster's
# at-capacity guard, applied via ApplicationError(next_retry_delay=...) instead of the retry policy's 5s
# exponential schedule.
CONCURRENCY_LIMIT_RETRY_DELAY_SECONDS = 60

RECALCULATION_RETRY_INITIAL_INTERVAL_SECONDS = 5
RECALCULATION_RETRY_BACKOFF_COEFFICIENT = 2.0
RECALCULATION_RETRY_MAX_INTERVAL_SECONDS = 60

# classify_experiment_query_error classes that are deterministic for a fixed query and data window: retrying
# burns a full ClickHouse query per attempt without changing the outcome, so the activity fails non-retryable
# and persists immediately. timeout is deliberately absent — the class conflates TIMEOUT_EXCEEDED with
# SOCKET_TIMEOUT (a transient network blip), and recalc timeouts are rare enough to keep the retry budget.
NON_RETRYABLE_ERROR_TYPES = frozenset({"out_of_memory", "byte_limit", "validation_error"})

# Per-attempt ceiling for the calc activity (its start_to_close_timeout). The activity has no heartbeat, so
# this is the real per-attempt limit — when it fires, Temporal kills the attempt from the outside and nothing
# inside the activity (result persistence, the terminal error event) runs.
METRIC_CALC_ACTIVITY_TIMEOUT_SECONDS = 300

# ClickHouse max_execution_time for the recalc metric query. Deliberately below
# METRIC_CALC_ACTIVITY_TIMEOUT_SECONDS (minus headroom for metric build, stats, and persistence) so a slow
# query fails INSIDE the activity with a typed ClickHouse error (159 TIMEOUT_EXCEEDED) instead of the activity
# being killed by Temporal — which would lose the error type, the FAILED result row, and the terminal event.
# A query needing more than this was already doomed to lose its attempt at the 5-minute kill; failing fast
# also stops the orphaned query from burning ClickHouse for the full default 600s.
METRIC_CALC_MAX_EXECUTION_TIME_SECONDS = 270

RECALCULATION_PROGRESS_ACTIVITY_TIMEOUT_SECONDS = 90


@dataclasses.dataclass
class ExperimentMetricsRecalculationWorkflowInputs:
    """Input to the batch metrics recalculation workflow."""

    recalculation_id: str  # UUID as string
    # Task-queue fairness key for the calc activities (the org id, matching the app_per_org limiter scope).
    # None falls back to default dispatch order.
    fairness_key: str | None = None


@dataclasses.dataclass
class ExperimentMetricToRecalculate:
    """A single metric to recalculate.

    The recalc fingerprint is derived inside the calculate activity from the recalculation_id,
    so it is intentionally not carried here.
    """

    experiment_id: int
    metric_uuid: str
    metric_type: str  # "primary" or "secondary"


@dataclasses.dataclass
class MetricRecalculationResult:
    """Result from calculating a single metric.

    Lightweight by design: carries only success/error metadata, never the computed result blob. The blob is
    written to ExperimentMetricResult (Postgres) inside the activity and read back by the API, so it never
    crosses the Temporal payload boundary (~2 MiB cap). error_message is capped by the activity before being set.
    """

    metric_uuid: str
    success: bool
    error_step: str | None = None
    error_message: str | None = None


@dataclasses.dataclass
class ExperimentPrecomputeCanaryInputs:
    """Input to the precompute canary workflow.

    Scheduled runs use the defaults (quota sampling across eligible experiments). On-demand forensics runs
    set experiment_id to canary one specific experiment — all of its eligible metrics, quotas ignored —
    optionally narrowed via metric_uuids. triggered_manually skips the Prometheus push (manual runs would
    distort the scheduled-canary health signal) but still posts to Slack.
    """

    experiment_id: int | None = None
    metric_uuids: list[str] | None = None
    funnel_quota: int = 12
    # Bake-in level for the new mean metric-events precompute path: ~40% of sampled means are
    # CUPED/breakdown/DW-ineligible and exercise nothing new, so 20 nominal ≈ 12 effective.
    # Drop back toward ~10 once the mean table has a few clean weeks of canary history.
    mean_quota: int = 20
    ratio_quota: int = 4
    # Bake-in level for the retention metric-events precompute path. Most retention metrics are
    # eligible (breakdowns and data warehouse sources are rare on them), so nominal stays close
    # to effective. Drop toward ~5 once retention has a few clean weeks of canary history.
    retention_quota: int = 15
    per_experiment_cap: int = 3
    time_budget_seconds: int = 5400
    triggered_manually: bool = False


@dataclasses.dataclass
class CanaryMetricTarget:
    """One sampled (experiment, metric) pair. Carries only the uuid — the definition is re-resolved inside
    the run activity so a metric edited/deleted between sampling and execution is seen as it currently is."""

    team_id: int
    experiment_id: int
    metric_uuid: str
    metric_type: str  # "funnel" | "mean" | "ratio"


@dataclasses.dataclass
class CanaryVariantStats:
    sum: float
    number_of_samples: int


@dataclasses.dataclass
class CanaryRunSnapshot:
    """Per-variant aggregates from one execution of the metric query."""

    label: str  # "a" | "b" (forced precomputed) | "c" (forced direct scan)
    query_id: str  # client_query_id, for system.query_log forensics
    is_precomputed: bool
    variants: dict[str, CanaryVariantStats]


@dataclasses.dataclass(frozen=False)
class CanaryMetricResult:
    """Verdict for one metric: outcome plus everything needed to investigate without re-running."""

    target: CanaryMetricTarget
    outcome: CanaryOutcome
    stability_deviation: float | None = None  # max relative deviation, run a vs b
    correctness_deviation: float | None = None  # max relative deviation, run b vs c
    runs: list[CanaryRunSnapshot] = dataclasses.field(default_factory=list)
    detail: str | None = None


@dataclasses.dataclass
class CanaryReportInputs:
    results: list[CanaryMetricResult]
    triggered_manually: bool = False


@dataclasses.dataclass
class RecalculationProgressUpdate:
    """Input for the start and finish lifecycle steps.

    Start step: status=in_progress, total_metrics, metric_uuids, mark_started=True. The activity itself
    stamps query_to and started_at under a first-write-wins guard.

    Finish step: status=completed|failed, mark_completed=True. The activity stamps completed_at, also
    first-write-wins.

    Per-metric counters and error entries are not carried here — they're written by the calculate activity
    in the same transaction as the result row.
    """

    recalculation_id: str
    status: str | None = None
    total_metrics: int | None = None
    metric_uuids: list[str] | None = None
    mark_started: bool = False
    mark_completed: bool = False
    # Run-level outcome carried on the finish step so the activity can emit the
    # 'experiment results refresh completed' analytics event with real counts.
    succeeded_metrics: int | None = None
    failed_metrics: int | None = None


ENROLLMENT_CENSUS_WORKFLOW_NAME = "experiment-precompute-enrollment-census"


@dataclasses.dataclass(frozen=True)
class ExperimentPrecomputeEnrollmentCensusInputs:
    """Input to the enrollment census workflow. Report-only: the census logs which teams
    would qualify for precomputation enrollment; it never enrolls anyone."""

    window_days: int = 14
