from contextlib import contextmanager
from datetime import datetime, timedelta

import pytest
from freezegun import freeze_time
from posthog.test.base import BaseTest
from unittest.mock import patch

from django.utils import timezone

from clickhouse_driver.errors import ServerException
from parameterized import parameterized
from rest_framework.exceptions import ValidationError
from temporalio.exceptions import ApplicationError

from posthog.clickhouse.client.limit import ConcurrencyLimitExceeded
from posthog.exceptions import ClickHouseAtCapacity, ClickHouseQueryMemoryLimitExceeded, ClickHouseQueryTimeOut

from products.experiments.backend.hogql_queries.experiment_metric_fingerprint import compute_metric_fingerprint
from products.experiments.backend.hogql_queries.utils import get_experiment_stats_method
from products.experiments.backend.models.experiment import (
    Experiment,
    ExperimentMetricResult,
    ExperimentMetricsRecalculation,
    ExperimentSavedMetric,
    ExperimentToSavedMetric,
)
from products.experiments.backend.temporal.models import (
    CONCURRENCY_LIMIT_RETRY_DELAY_SECONDS,
    MAX_METRIC_ATTEMPTS,
    RecalculationProgressUpdate,
)
from products.experiments.backend.temporal.recalc_fingerprint import compute_recalc_fingerprint
from products.experiments.backend.temporal.recalculation_logic import (
    _calculate_experiment_metric_for_recalculation_sync,
    _discover_experiment_metrics_sync,
    _store_result,
    _update_recalculation_progress_sync,
)
from products.experiments.stats.shared.statistics import StatisticError
from products.feature_flags.backend.models.feature_flag import FeatureFlag

_discover_raw = _discover_experiment_metrics_sync.func  # type: ignore[attr-defined]
_update_raw = _update_recalculation_progress_sync.func  # type: ignore[attr-defined]
_calculate_raw = _calculate_experiment_metric_for_recalculation_sync.func  # type: ignore[attr-defined]


def _discover(recalculation_id: str):
    with patch("products.experiments.backend.temporal.recalculation_logic.close_old_connections"):
        return _discover_raw(recalculation_id)


def _update(update: RecalculationProgressUpdate):
    with patch("products.experiments.backend.temporal.recalculation_logic.close_old_connections"):
        return _update_raw(update)


def _calculate(
    experiment_id: int,
    metric_uuid: str,
    recalculation_id: str,
    query_to: str,
    metric_type: str = "primary",
    is_final_attempt: bool = True,
    attempt: int = 1,
):
    with patch("products.experiments.backend.temporal.recalculation_logic.close_old_connections"):
        return _calculate_raw(
            experiment_id, metric_uuid, recalculation_id, query_to, metric_type, is_final_attempt, attempt
        )


@pytest.mark.django_db(transaction=True)
class TestRecalculationActivities(BaseTest):
    def _flag(self, key: str) -> FeatureFlag:
        return FeatureFlag.objects.create(
            team=self.team,
            created_by=self.user,
            key=key,
            name=f"Flag for {key}",
            filters={
                "groups": [{"properties": [], "rollout_percentage": 100}],
                "multivariate": {
                    "variants": [
                        {"key": "control", "name": "Control", "rollout_percentage": 50},
                        {"key": "test", "name": "Test", "rollout_percentage": 50},
                    ]
                },
            },
        )

    def _experiment(self, flag_key: str) -> Experiment:
        return Experiment.objects.create(
            team=self.team, created_by=self.user, feature_flag=self._flag(flag_key), name="exp"
        )

    def _recalc(
        self, exp: Experiment, trigger: str = ExperimentMetricsRecalculation.Trigger.MANUAL
    ) -> ExperimentMetricsRecalculation:
        return ExperimentMetricsRecalculation.objects.create(team=self.team, experiment=exp, trigger=trigger)

    def _attach_saved_metric(self, exp: Experiment, uuid: str, metric_type: str) -> None:
        saved = ExperimentSavedMetric.objects.create(
            team=self.team,
            name=f"saved-{uuid}",
            query={"uuid": uuid, "kind": "ExperimentMetric", "metric_type": "mean"},
        )
        ExperimentToSavedMetric.objects.create(experiment=exp, saved_metric=saved, metadata={"type": metric_type})

    @parameterized.expand(
        [
            (
                "primary_and_secondary",
                [{"uuid": "m1", "metric_type": "mean", "kind": "ExperimentMetric"}],
                [{"uuid": "m2", "metric_type": "mean", "kind": "ExperimentMetric"}],
                [],
                {"m1", "m2"},
                {"primary", "secondary"},
            ),
            ("no_metrics", [], [], [], set(), set()),
            (
                "primary_only",
                [{"uuid": "m1", "metric_type": "mean", "kind": "ExperimentMetric"}],
                [],
                [],
                {"m1"},
                {"primary"},
            ),
            (
                "saved_metrics_only",
                [],
                [],
                [("s1", "primary"), ("s2", "secondary")],
                {"s1", "s2"},
                {"primary", "secondary"},
            ),
            (
                "inline_and_saved_mixed",
                [{"uuid": "m1", "metric_type": "mean", "kind": "ExperimentMetric"}],
                [],
                [("s1", "secondary")],
                {"m1", "s1"},
                {"primary", "secondary"},
            ),
        ]
    )
    def test_discover_persists_metric_uuids(self, name: str, primary, secondary, saved, expected_uuids, expected_types):
        exp = self._experiment(flag_key=f"discover-{name}")
        exp.metrics = primary
        exp.metrics_secondary = secondary
        exp.save()
        for uuid, metric_type in saved:
            self._attach_saved_metric(exp, uuid, metric_type)
        recalc = self._recalc(exp)

        metrics = _discover(str(recalc.id))

        recalc.refresh_from_db()
        assert set(recalc.metric_uuids) == expected_uuids
        assert {m.metric_uuid for m in metrics} == expected_uuids
        assert {m.metric_type for m in metrics} == expected_types

    @parameterized.expand(
        [
            (
                "start",
                {
                    "status": "in_progress",
                    "total_metrics": 3,
                    "metric_uuids": ["m1", "m2", "m3"],
                    "mark_started": True,
                },
                "in_progress",
                True,  # expects query_to set + returned
            ),
            (
                "finish",
                {"status": "completed", "mark_completed": True},
                "completed",
                False,  # finish does not set/return query_to
            ),
        ]
    )
    def test_update_progress(self, name: str, update_kwargs: dict, expected_status: str, expects_query_to: bool):
        recalc = self._recalc(self._experiment(flag_key=f"progress-{name}"))
        returned = _update(RecalculationProgressUpdate(recalculation_id=str(recalc.id), **update_kwargs))

        recalc.refresh_from_db()
        assert recalc.status == expected_status

        if expects_query_to:
            assert recalc.started_at is not None
            assert recalc.total_metrics == update_kwargs["total_metrics"]
            assert recalc.metric_uuids == update_kwargs["metric_uuids"]
            assert recalc.query_to is not None
            # Returns the query_to it set (ISO string) so the workflow can thread it into calc activities.
            assert returned == recalc.query_to.isoformat()
        else:
            assert recalc.completed_at is not None
            assert returned is None

    def test_mark_started_is_first_write_wins_on_retry(self):
        # Temporal retries the start activity (network blip, worker crash) — the second attempt must NOT move
        # query_to/started_at forward. If it did, any calc activity already in flight from the first attempt
        # would persist ExperimentMetricResult rows with the old query_to, while the recalc row points at the
        # new one — orphaning those rows from the API's perspective.
        recalc = self._recalc(self._experiment(flag_key="progress-retry-start"))

        def _start() -> str | None:
            return _update(
                RecalculationProgressUpdate(
                    recalculation_id=str(recalc.id),
                    status="in_progress",
                    total_metrics=3,
                    metric_uuids=["m1", "m2", "m3"],
                    mark_started=True,
                )
            )

        first = _start()
        recalc.refresh_from_db()
        first_query_to = recalc.query_to
        first_started_at = recalc.started_at
        assert first_query_to is not None  # mark_started=True populates it

        second = _start()
        recalc.refresh_from_db()

        # DB state unchanged after retry — the conditional UPDATE matched zero rows.
        assert recalc.query_to == first_query_to
        assert recalc.started_at == first_started_at
        # Both attempts return the same canonical query_to so the workflow threads the same value either way.
        assert first == second == first_query_to.isoformat()

    @parameterized.expand(
        [
            # name, set_completed_at — both force-fail shapes leave query_to NULL while discovery runs.
            # admin "Mark as failed" stamps completed_at; the staleness sweep deliberately leaves it NULL, so
            # a completed_at-only guard would miss the sweep. The status guard catches both.
            ("admin_sets_completed_at", True),
            ("sweep_leaves_completed_at_null", False),
        ]
    )
    @freeze_time("2026-06-23T05:00:00Z")
    def test_mark_started_does_not_revive_a_force_failed_run(self, name: str, set_completed_at: bool):
        recalc = self._recalc(self._experiment(flag_key=f"progress-start-force-failed-{name}"))
        completed_at = timezone.now() if set_completed_at else None
        ExperimentMetricsRecalculation.objects.filter(id=recalc.id).update(
            status=ExperimentMetricsRecalculation.Status.FAILED, completed_at=completed_at
        )

        returned = _update(
            RecalculationProgressUpdate(
                recalculation_id=str(recalc.id),
                status="in_progress",
                total_metrics=3,
                metric_uuids=["m1", "m2", "m3"],
                mark_started=True,
            )
        )

        recalc.refresh_from_db()
        # The run stays terminal: no revival, no started_at, query_to left NULL.
        assert recalc.status == ExperimentMetricsRecalculation.Status.FAILED
        assert recalc.completed_at == completed_at
        assert recalc.started_at is None
        assert recalc.query_to is None
        # query_to was never pinned, so the read-back returns None; the workflow's isinstance(str) check then
        # fails the run non-retryably instead of proceeding to calc activities on a dead run.
        assert returned is None

    @freeze_time("2026-06-23T05:00:00Z")
    def test_mark_started_returns_none_when_force_failed_after_query_to_pinned(self):
        # mark_started ran first and pinned query_to (run went IN_PROGRESS), then an admin force-failed it.
        # A retried mark_started loses the guard, but the read-back must NOT hand back the pinned query_to as a
        # string: that would pass the workflow's isinstance(str) check and let calc activities run ClickHouse
        # queries and persist results for a terminal, superseded run (they don't re-check terminal status).
        recalc = self._recalc(self._experiment(flag_key="progress-start-pinned-then-failed"))
        pinned_query_to = timezone.now()
        ExperimentMetricsRecalculation.objects.filter(id=recalc.id).update(
            status=ExperimentMetricsRecalculation.Status.FAILED,
            completed_at=timezone.now(),
            query_to=pinned_query_to,
            started_at=timezone.now(),
        )

        returned = _update(
            RecalculationProgressUpdate(
                recalculation_id=str(recalc.id),
                status="in_progress",
                total_metrics=3,
                metric_uuids=["m1", "m2", "m3"],
                mark_started=True,
            )
        )

        # Terminal read-back returns None despite query_to being pinned, so the workflow fails the run.
        assert returned is None
        recalc.refresh_from_db()
        assert recalc.status == ExperimentMetricsRecalculation.Status.FAILED
        assert recalc.query_to == pinned_query_to

    @parameterized.expand(
        [
            # name, end_date_offset_days (None = running experiment), expect query_to == end_date
            ("running_uses_now", None, False),
            ("stopped_uses_end_date", -5, True),
            ("future_end_uses_now", 5, False),
        ]
    )
    @freeze_time("2026-06-23T05:00:00Z")
    def test_mark_started_query_to_is_data_window_end(self, name: str, end_date_offset_days, expect_end_date: bool):
        # query_to is the data-window end (experiment_window_end), not bare now. For a stopped experiment it
        # resolves to end_date — a fixed value — so reruns reuse the same result row instead of appending a
        # redundant post-end timeseries point. Running / future-dated experiments still advance with now.
        now = timezone.now()
        exp = self._experiment(flag_key=f"window-end-{name}")
        if end_date_offset_days is not None:
            exp.end_date = now + timedelta(days=end_date_offset_days)
            exp.save(update_fields=["end_date"])
        recalc = self._recalc(exp)

        _update(
            RecalculationProgressUpdate(
                recalculation_id=str(recalc.id),
                status="in_progress",
                total_metrics=1,
                metric_uuids=["m1"],
                mark_started=True,
            )
        )

        recalc.refresh_from_db()
        assert recalc.query_to is not None
        if expect_end_date:
            assert recalc.query_to == now + timedelta(days=end_date_offset_days)
        else:
            assert recalc.query_to == now

    @parameterized.expand(
        [
            # trigger, expect_reuse: only a metric-scoped change reuses the prior completed window.
            (ExperimentMetricsRecalculation.Trigger.METRIC_CONFIG_CHANGE, True),
            (ExperimentMetricsRecalculation.Trigger.EXPERIMENT_CONFIG_CHANGE, False),
            (ExperimentMetricsRecalculation.Trigger.MANUAL, False),
            (ExperimentMetricsRecalculation.Trigger.AUTO_REFRESH, False),
        ]
    )
    @freeze_time("2026-06-23T05:00:00Z")
    def test_mark_started_reuses_prior_window_only_for_metric_config_change(self, trigger: str, expect_reuse: bool):
        # A running experiment has no end_date, so advancing triggers pin now while metric_config_change copies
        # the latest completed run's query_to — the signal that keeps unchanged metrics on the cache.
        now = timezone.now()
        prior_window = now - timedelta(hours=6)
        exp = self._experiment(flag_key=f"reuse-{trigger}")
        ExperimentMetricsRecalculation.objects.create(
            team=self.team,
            experiment=exp,
            status=ExperimentMetricsRecalculation.Status.COMPLETED,
            query_to=prior_window,
            completed_at=prior_window,
        )
        recalc = self._recalc(exp, trigger=trigger)

        _update(
            RecalculationProgressUpdate(
                recalculation_id=str(recalc.id),
                status="in_progress",
                total_metrics=1,
                metric_uuids=["m1"],
                mark_started=True,
            )
        )

        recalc.refresh_from_db()
        assert recalc.query_to == (prior_window if expect_reuse else now)

    @freeze_time("2026-06-23T05:00:00Z")
    def test_mark_started_reuses_partial_failure_window(self):
        # A run where one metric failed is marked FAILED but stamps completed_at and holds result rows for the
        # metrics that succeeded. Reuse must anchor on that newest terminal window, not fall back to an older
        # fully-completed one — otherwise the good metrics' displayed results move backward.
        now = timezone.now()
        older_completed = now - timedelta(hours=12)
        newer_partial = now - timedelta(hours=2)
        exp = self._experiment(flag_key="reuse-partial-failure")
        ExperimentMetricsRecalculation.objects.create(
            team=self.team,
            experiment=exp,
            status=ExperimentMetricsRecalculation.Status.COMPLETED,
            query_to=older_completed,
            completed_at=older_completed,
        )
        ExperimentMetricsRecalculation.objects.create(
            team=self.team,
            experiment=exp,
            status=ExperimentMetricsRecalculation.Status.FAILED,
            query_to=newer_partial,
            completed_at=newer_partial,
        )
        recalc = self._recalc(exp, trigger=ExperimentMetricsRecalculation.Trigger.METRIC_CONFIG_CHANGE)

        _update(
            RecalculationProgressUpdate(
                recalculation_id=str(recalc.id),
                status="in_progress",
                total_metrics=1,
                metric_uuids=["m1"],
                mark_started=True,
            )
        )

        recalc.refresh_from_db()
        assert recalc.query_to == newer_partial

    @freeze_time("2026-06-23T05:00:00Z")
    def test_mark_started_does_not_reuse_window_before_start_date(self):
        # After a reset and relaunch the prior run's rows survive with a query_to from before the new start_date.
        # Reusing that cutoff would begin the window before the experiment exists, so advance to now instead.
        now = timezone.now()
        exp = self._experiment(flag_key="reuse-before-start")
        exp.start_date = now - timedelta(hours=1)
        exp.save(update_fields=["start_date"])
        ExperimentMetricsRecalculation.objects.create(
            team=self.team,
            experiment=exp,
            status=ExperimentMetricsRecalculation.Status.COMPLETED,
            query_to=now - timedelta(days=3),
            completed_at=now - timedelta(days=3),
        )
        recalc = self._recalc(exp, trigger=ExperimentMetricsRecalculation.Trigger.METRIC_CONFIG_CHANGE)

        _update(
            RecalculationProgressUpdate(
                recalculation_id=str(recalc.id),
                status="in_progress",
                total_metrics=1,
                metric_uuids=["m1"],
                mark_started=True,
            )
        )

        recalc.refresh_from_db()
        assert recalc.query_to == now

    @freeze_time("2026-06-23T05:00:00Z")
    def test_mark_started_metric_config_change_clamps_to_end_date_when_stopped(self):
        # A stopped experiment has a fixed window: even metric_config_change resolves to end_date, so a stale
        # prior window (recorded before the stop) can never push the recompute window past end_date.
        now = timezone.now()
        exp = self._experiment(flag_key="reuse-stopped")
        exp.end_date = now - timedelta(days=2)
        exp.save(update_fields=["end_date"])
        ExperimentMetricsRecalculation.objects.create(
            team=self.team,
            experiment=exp,
            status=ExperimentMetricsRecalculation.Status.COMPLETED,
            query_to=now - timedelta(days=1),
            completed_at=now - timedelta(days=1),
        )
        recalc = self._recalc(exp, trigger=ExperimentMetricsRecalculation.Trigger.METRIC_CONFIG_CHANGE)

        _update(
            RecalculationProgressUpdate(
                recalculation_id=str(recalc.id),
                status="in_progress",
                total_metrics=1,
                metric_uuids=["m1"],
                mark_started=True,
            )
        )

        recalc.refresh_from_db()
        assert recalc.query_to == exp.end_date

    @freeze_time("2026-06-23T05:00:00Z")
    def test_mark_started_metric_config_change_advances_when_no_prior_window(self):
        # First metric-scoped run: nothing to reuse, so it falls back to now rather than leaving query_to unset.
        now = timezone.now()
        exp = self._experiment(flag_key="reuse-no-prior")
        recalc = self._recalc(exp, trigger=ExperimentMetricsRecalculation.Trigger.METRIC_CONFIG_CHANGE)

        _update(
            RecalculationProgressUpdate(
                recalculation_id=str(recalc.id),
                status="in_progress",
                total_metrics=1,
                metric_uuids=["m1"],
                mark_started=True,
            )
        )

        recalc.refresh_from_db()
        assert recalc.query_to == now

    def test_mark_completed_is_first_write_wins_on_retry(self):
        # Symmetric to mark_started: a retried finish activity must not re-stamp completed_at.
        recalc = self._recalc(self._experiment(flag_key="progress-retry-finish"))
        # A hard-killed final attempt can orphan a retry entry; finishing the run must sweep it.
        recalc.metric_retries = {"m1": {"attempt": 7, "max_attempts": 8}}
        recalc.save(update_fields=["metric_retries"])

        def _finish() -> str | None:
            return _update(
                RecalculationProgressUpdate(
                    recalculation_id=str(recalc.id),
                    status="completed",
                    mark_completed=True,
                )
            )

        _finish()
        recalc.refresh_from_db()
        assert recalc.metric_retries == {}
        first_completed_at = recalc.completed_at
        first_status = recalc.status

        _finish()
        recalc.refresh_from_db()

        assert recalc.completed_at == first_completed_at
        assert recalc.status == first_status

    @parameterized.expand(
        [
            # Contract: exactly one of mark_started / mark_completed must be true. Both-true or neither-true
            # is a workflow bug — fail non-retryable so Temporal terminates promptly.
            ("both_true", {"mark_started": True, "mark_completed": True}),
            ("neither", {}),
        ]
    )
    def test_progress_update_requires_exactly_one_lifecycle_flag(self, name: str, flags: dict):
        recalc = self._recalc(self._experiment(flag_key=f"progress-mutex-{name}"))

        with pytest.raises(ApplicationError) as exc_info:
            _update(RecalculationProgressUpdate(recalculation_id=str(recalc.id), **flags))

        assert "exactly one of mark_started or mark_completed" in str(exc_info.value)
        assert exc_info.value.non_retryable is True


_QUERY_TO = "2026-05-29T12:00:00+00:00"


def _mean_metric(uuid: str) -> dict:
    # ExperimentMeanMetric requires a `source`; a bare {uuid, metric_type} dict fails pydantic validation.
    return {
        "uuid": uuid,
        "kind": "ExperimentMetric",
        "metric_type": "mean",
        "source": {"kind": "EventsNode", "event": "purchase"},
    }


@pytest.mark.django_db(transaction=True)
class TestCalculateActivity(BaseTest):
    def _flag(self, key: str) -> FeatureFlag:
        return FeatureFlag.objects.create(
            team=self.team,
            created_by=self.user,
            key=key,
            name=f"Flag for {key}",
            filters={
                "groups": [{"properties": [], "rollout_percentage": 100}],
                "multivariate": {
                    "variants": [
                        {"key": "control", "name": "Control", "rollout_percentage": 50},
                        {"key": "test", "name": "Test", "rollout_percentage": 50},
                    ]
                },
            },
        )

    def _experiment(self, flag_key: str, *, with_start_date: bool = True, metrics=None) -> Experiment:
        exp = Experiment.objects.create(
            team=self.team,
            created_by=self.user,
            feature_flag=self._flag(flag_key),
            name="exp",
            start_date=timezone.now() if with_start_date else None,
        )
        if metrics is not None:
            exp.metrics = metrics
            exp.save()
        return exp

    def _recalc(
        self, exp: Experiment, *, metric_uuids: list[str], total: int | None = None
    ) -> ExperimentMetricsRecalculation:
        """Create a recalc row in the post-discovery + post-start state, so the calculate activity's
        input-validation guards (metric_uuids membership, query_to set) are satisfied as the workflow
        would have set them."""
        return ExperimentMetricsRecalculation.objects.create(
            team=self.team,
            experiment=exp,
            metric_uuids=metric_uuids,
            total_metrics=total if total is not None else len(metric_uuids),
            query_to=datetime.fromisoformat(_QUERY_TO),
        )

    def test_metric_disappeared_between_discovery_and_calc(self):
        # Discovery included m1 in the recalc's metric set (so input validation passes), but the experiment
        # was edited and m1 is no longer present — the calc activity's inner lookup must surface this as a
        # discovery-step failure rather than crashing.
        exp = self._experiment(flag_key="calc-missing", metrics=[])
        recalc = self._recalc(exp, metric_uuids=["m1"])

        result = _calculate(exp.id, "m1", str(recalc.id), _QUERY_TO)

        assert result.success is False
        assert result.error_step == "discovery"
        recalc.refresh_from_db()
        assert len(recalc.metric_errors) == 1
        assert "m1" in recalc.metric_errors

    def test_bad_metric_type_fails_at_calculation(self):
        # Legacy metrics never reach this workflow, so there's no discovery-time type guard; an unexpected
        # metric_type raises while building the metric. The activity records the failure to metric_errors
        # and re-raises so Temporal's retry policy can handle potentially transient errors.
        exp = self._experiment(
            flag_key="calc-badtype",
            metrics=[{"uuid": "m-bad", "metric_type": "nonsense", "kind": "ExperimentMetric"}],
        )
        recalc = self._recalc(exp, metric_uuids=["m-bad"])

        with pytest.raises(KeyError):
            _calculate(exp.id, "m-bad", str(recalc.id), _QUERY_TO)

        recalc.refresh_from_db()
        assert len(recalc.metric_errors) == 1
        assert "m-bad" in recalc.metric_errors

    def test_missing_start_date_fails(self):
        exp = self._experiment(flag_key="calc-no-start", with_start_date=False, metrics=[_mean_metric("m1")])
        recalc = self._recalc(exp, metric_uuids=["m1"])

        result = _calculate(exp.id, "m1", str(recalc.id), _QUERY_TO)

        assert result.success is False
        recalc.refresh_from_db()
        assert len(recalc.metric_errors) == 1

    def test_saved_metric_is_resolvable(self):
        # A saved/shared metric (uuid only on saved_metric.query) must be found by the calc lookup; otherwise it
        # would wrongly fail at the discovery step. We force a calculation error so the run reaches the metric via
        # the saved-metric branch but fails for a non-lookup reason. The runtime error is re-raised so Temporal
        # can retry; the failure is recorded to metric_errors first.
        exp = self._experiment(flag_key="calc-saved")
        saved = ExperimentSavedMetric.objects.create(
            team=self.team,
            name="saved-s1",
            query=_mean_metric("s1"),
        )
        ExperimentToSavedMetric.objects.create(experiment=exp, saved_metric=saved, metadata={"type": "primary"})
        recalc = self._recalc(exp, metric_uuids=["s1"])

        with patch("products.experiments.backend.temporal.recalculation_logic.ExperimentQueryRunner") as mock_runner:
            mock_runner.return_value.run.side_effect = RuntimeError("kaboom")
            with pytest.raises(RuntimeError, match="kaboom"):
                _calculate(exp.id, "s1", str(recalc.id), _QUERY_TO)

        # Found the saved metric (did not fail at discovery), failure was recorded before re-raise.
        recalc.refresh_from_db()
        assert "s1" in recalc.metric_errors

    def test_transient_failure_is_not_persisted_until_the_final_attempt(self):
        # A retryable (transient) failure on a non-final attempt re-raises for Temporal to retry but must NOT
        # persist a FAILED row or a metric_errors entry, so the frontend keeps the metric loading instead of
        # flashing an error for a failure that may still succeed. The final attempt persists it.
        exp = self._experiment(flag_key="calc-transient", metrics=[_mean_metric("m1")])
        recalc = self._recalc(exp, metric_uuids=["m1"])

        with patch("products.experiments.backend.temporal.recalculation_logic.ExperimentQueryRunner") as mock_runner:
            mock_runner.return_value.run.side_effect = RuntimeError("transient blip")

            # Non-final attempt: re-raises, but nothing is recorded.
            with pytest.raises(RuntimeError, match="transient blip"):
                _calculate(exp.id, "m1", str(recalc.id), _QUERY_TO, is_final_attempt=False)
            recalc.refresh_from_db()
            assert recalc.metric_errors == {}
            assert not ExperimentMetricResult.objects.filter(experiment=exp, metric_uuid="m1").exists()

            # Final attempt: now the failure is persisted for the UI.
            with pytest.raises(RuntimeError, match="transient blip"):
                _calculate(exp.id, "m1", str(recalc.id), _QUERY_TO, is_final_attempt=True)
            recalc.refresh_from_db()
            assert "m1" in recalc.metric_errors

    @parameterized.expand(
        [
            # (name, exc, expected_error_type, expected_delay_seconds, expected_message) — backpressure uses
            # the explicit next_retry_delay; a generic transient on attempt 2 follows the policy backoff
            # (5 * 2^1). The generic exception carries a fake credential to lock in that raw exception text
            # (which can embed the executed query, warehouse secrets included) never reaches the API field.
            (
                "backpressure",
                ConcurrencyLimitExceeded("quota"),
                "rate_limited",
                60,
                "The query was deferred because the cluster is at capacity.",
            ),
            (
                "generic_transient",
                RuntimeError("blip aws_access_key_id=AKIAFAKESECRET"),
                "server_error",
                10,
                "The query failed with a server error.",
            ),
        ]
    )
    @freeze_time("2026-05-29T13:00:00Z")
    def test_transient_attempt_records_retry_state_and_success_clears_it(
        self, name: str, exc: Exception, expected_error_type: str, expected_delay_seconds: int, expected_message: str
    ):
        # The retry entry is what the UI shows between attempts; without it the metric looks stuck. It must
        # carry the attempt counters and a next_retry_at estimate, and vanish once the metric resolves.
        exp = self._experiment(flag_key=f"calc-retry-{name}", metrics=[_mean_metric("m1")])
        recalc = self._recalc(exp, metric_uuids=["m1"])

        with patch("products.experiments.backend.temporal.recalculation_logic.ExperimentQueryRunner") as mock_runner:
            mock_runner.return_value.run.side_effect = exc
            with pytest.raises((type(exc), ApplicationError)):
                _calculate(exp.id, "m1", str(recalc.id), _QUERY_TO, is_final_attempt=False, attempt=2)

        recalc.refresh_from_db()
        entry = recalc.metric_retries["m1"]
        assert entry["attempt"] == 2
        assert entry["max_attempts"] == MAX_METRIC_ATTEMPTS
        assert entry["error_type"] == expected_error_type
        assert entry["message"] == expected_message
        assert "AKIAFAKESECRET" not in entry["message"]
        next_retry_at = datetime.fromisoformat(entry["next_retry_at"])
        assert (next_retry_at - timezone.now()).total_seconds() == expected_delay_seconds

        with patch("products.experiments.backend.temporal.recalculation_logic.ExperimentQueryRunner") as mock_runner:
            mock_runner.return_value.run.return_value.model_dump.return_value = {}
            result = _calculate(exp.id, "m1", str(recalc.id), _QUERY_TO, attempt=3)

        assert result.success is True
        recalc.refresh_from_db()
        assert recalc.metric_retries == {}

    def test_terminal_failure_clears_retry_state(self):
        # A metric that retried and then failed for good must not keep a stale "retrying" entry alongside
        # its terminal error.
        exp = self._experiment(flag_key="calc-retry-terminal", metrics=[_mean_metric("m1")])
        recalc = self._recalc(exp, metric_uuids=["m1"])

        with patch("products.experiments.backend.temporal.recalculation_logic.ExperimentQueryRunner") as mock_runner:
            mock_runner.return_value.run.side_effect = RuntimeError("transient blip")
            with pytest.raises(RuntimeError):
                _calculate(exp.id, "m1", str(recalc.id), _QUERY_TO, is_final_attempt=False, attempt=2)
            recalc.refresh_from_db()
            assert "m1" in recalc.metric_retries

            with pytest.raises(RuntimeError):
                _calculate(exp.id, "m1", str(recalc.id), _QUERY_TO, is_final_attempt=True, attempt=8)

        recalc.refresh_from_db()
        assert recalc.metric_retries == {}
        assert "m1" in recalc.metric_errors

    @parameterized.expand(
        [
            ("org_quota", ConcurrencyLimitExceeded("org quota saturated")),
            ("cluster_at_capacity", ClickHouseAtCapacity()),
        ]
    )
    def test_backpressure_bounce_defers_with_retry_delay_and_no_capture(self, name: str, exc: Exception):
        # A query bouncing off the per-org ClickHouse limiter or the cluster's at-capacity guard is
        # backpressure, not a fault: it must re-raise as an ApplicationError carrying next_retry_delay
        # (overriding the retry policy's 5s exponential schedule with the flat quota-wait delay), must never
        # reach capture_exception (a saturated org would spam error tracking with expected bounces), and must
        # persist nothing before the final attempt.
        exp = self._experiment(flag_key=f"calc-quota-{name}", metrics=[_mean_metric("m1")])
        recalc = self._recalc(exp, metric_uuids=["m1"])

        with (
            patch("products.experiments.backend.temporal.recalculation_logic.ExperimentQueryRunner") as mock_runner,
            patch("products.experiments.backend.temporal.recalculation_logic.capture_exception") as mock_capture,
        ):
            mock_runner.return_value.run.side_effect = exc

            with pytest.raises(ApplicationError) as exc_info:
                _calculate(exp.id, "m1", str(recalc.id), _QUERY_TO, is_final_attempt=False)
            assert exc_info.value.type == type(exc).__name__
            assert exc_info.value.next_retry_delay == timedelta(seconds=CONCURRENCY_LIMIT_RETRY_DELAY_SECONDS)
            mock_capture.assert_not_called()
            recalc.refresh_from_db()
            assert recalc.metric_errors == {}
            assert not ExperimentMetricResult.objects.filter(experiment=exp, metric_uuid="m1").exists()

            # Final attempt: the failure is persisted for the UI, still without exception capture.
            with pytest.raises(ApplicationError):
                _calculate(exp.id, "m1", str(recalc.id), _QUERY_TO, is_final_attempt=True)
            mock_capture.assert_not_called()
            recalc.refresh_from_db()
            assert "m1" in recalc.metric_errors
            row = ExperimentMetricResult.objects.get(experiment=exp, metric_uuid="m1")
            assert row.status == ExperimentMetricResult.Status.FAILED

    @parameterized.expand(
        [
            ("out_of_memory", ClickHouseQueryMemoryLimitExceeded(), "out_of_memory"),
            ("byte_limit", ServerException("too many bytes", code=307), "byte_limit"),
            ("validation_error", ValidationError("bad metric config"), "validation_error"),
            ("config_value_error", ValueError("No control variant found"), "server_error"),
        ]
    )
    def test_permanent_error_fails_non_retryable_and_persists_on_first_attempt(
        self, name: str, exc: Exception, expected_type: str
    ):
        # Deterministic failures (out-of-memory, byte limits, invalid config) can't succeed on retry, so
        # even a NON-final attempt must persist the FAILED row immediately and raise non_retryable — every
        # retry would burn a full ClickHouse query without changing the outcome.
        exp = self._experiment(flag_key=f"calc-permanent-{name}", metrics=[_mean_metric("m1")])
        recalc = self._recalc(exp, metric_uuids=["m1"])

        with patch("products.experiments.backend.temporal.recalculation_logic.ExperimentQueryRunner") as mock_runner:
            mock_runner.return_value.run.side_effect = exc

            with pytest.raises(ApplicationError) as exc_info:
                _calculate(exp.id, "m1", str(recalc.id), _QUERY_TO, is_final_attempt=False)

        assert exc_info.value.non_retryable is True
        assert exc_info.value.type == expected_type
        recalc.refresh_from_db()
        assert "m1" in recalc.metric_errors
        row = ExperimentMetricResult.objects.get(experiment=exp, metric_uuid="m1")
        assert row.status == ExperimentMetricResult.Status.FAILED

    def test_query_to_is_passed_as_as_of_to_runner(self):
        # The run's shared query_to MUST be threaded into the ClickHouse query bounds via the runner's
        # as_of, not just stored on the result row. Without as_of the runner falls back to its own now(),
        # so every metric in the run queries a slightly different time window — silently violating the
        # "one query_to for the whole run" guarantee. Stored value would look correct; actual query bounds
        # would not. Reference: workflow #3's backfill activity does the same thing.
        exp = self._experiment(flag_key="calc-as-of", metrics=[_mean_metric("m1")])
        recalc = self._recalc(exp, metric_uuids=["m1"])

        with patch("products.experiments.backend.temporal.recalculation_logic.ExperimentQueryRunner") as mock_runner:
            mock_runner.return_value.run.return_value.model_dump.return_value = {}
            _calculate(exp.id, "m1", str(recalc.id), _QUERY_TO)

        mock_runner.assert_called_once()
        kwargs = mock_runner.call_args.kwargs
        assert kwargs["as_of"] == datetime.fromisoformat(_QUERY_TO)

    def test_query_from_matches_experiment_start_date_on_result_row(self):
        # Companion to test_query_to_is_passed_as_as_of_to_runner: the lower bound of the run's
        # time window is experiment.start_date, threaded into the runner via the experiment object it
        # constructs and stored on the result row via _store_result(query_from=experiment.start_date).
        # This test pins the stored-row side. If the runner ever changes how it derives query_from, or if a
        # future refactor decouples the stored value from what the runner actually queries, the same class
        # of silent-miscalculation bug we just fixed for query_to could reappear here.
        exp = self._experiment(flag_key="calc-query-from", metrics=[_mean_metric("m1")])
        recalc = self._recalc(exp, metric_uuids=["m1"])

        with patch("products.experiments.backend.temporal.recalculation_logic.ExperimentQueryRunner") as mock_runner:
            mock_runner.return_value.run.return_value.model_dump.return_value = {}
            _calculate(exp.id, "m1", str(recalc.id), _QUERY_TO)

        # Runner gets the experiment whose start_date is the source of truth for the lower bound.
        mock_runner.assert_called_once()
        assert mock_runner.call_args.kwargs["team"] == exp.team
        # And the persisted row's query_from matches that same start_date — so reader and writer agree.
        row = ExperimentMetricResult.objects.get(experiment=exp, metric_uuid="m1")
        assert row.query_from == exp.start_date

    def test_query_id_is_persisted_on_result_row(self):
        # The deterministic client_query_id is stamped into ClickHouse's query_id and stored on the row so a
        # metric's executions are greppable in system.query_log by the `{team}_{client_query_id}_` prefix.
        exp = self._experiment(flag_key="calc-query-id", metrics=[_mean_metric("m1")])
        recalc = self._recalc(exp, metric_uuids=["m1"])

        with patch("products.experiments.backend.temporal.recalculation_logic.ExperimentQueryRunner") as mock_runner:
            mock_runner.return_value.run.return_value.model_dump.return_value = {}
            _calculate(exp.id, "m1", str(recalc.id), _QUERY_TO)

        row = ExperimentMetricResult.objects.get(experiment=exp, metric_uuid="m1")
        assert row.query_id == f"experiment_metric_recalc_{recalc.id}_m1"

    def test_multiple_failures_accumulate_in_metric_errors(self):
        # Two metrics fail in sequence (not in parallel — that would need threads + a real Postgres). Pins the
        # merge-into-dict behavior: each failure writes its own entry keyed by metric_uuid, no overwriting.
        # The select_for_update guard against concurrent writers is exercised by the production code, not here.
        exp = self._experiment(flag_key="calc-accumulate", metrics=[])
        recalc = self._recalc(exp, metric_uuids=["missing-a", "missing-b"])

        _calculate(exp.id, "missing-a", str(recalc.id), _QUERY_TO)
        _calculate(exp.id, "missing-b", str(recalc.id), _QUERY_TO)

        recalc.refresh_from_db()
        assert len(recalc.metric_errors) == 2
        assert set(recalc.metric_errors.keys()) == {"missing-a", "missing-b"}

    def test_skips_query_when_completed_result_already_exists_for_this_fingerprint(self):
        # Speed optimization: if a COMPLETED row already exists at this (experiment, metric_uuid, query_to)
        # under THIS run's recalc fingerprint, the metric is unchanged and already computed for this window, so
        # the activity returns success without re-running the ClickHouse query. The fingerprint is the
        # correctness gate: a config change produces a different fingerprint, so no match, and it recomputes.
        metric = _mean_metric("m1")
        exp = self._experiment(flag_key="calc-skip-existing", metrics=[metric])
        query_to = datetime.fromisoformat(_QUERY_TO)
        recalc_fp = compute_recalc_fingerprint(
            compute_metric_fingerprint(
                metric,
                exp.start_date,
                get_experiment_stats_method(exp),
                exp.exposure_criteria,
                only_count_matured_users=exp.only_count_matured_users,
            )
        )
        existing = ExperimentMetricResult.objects.create(
            experiment=exp,
            metric_uuid="m1",
            fingerprint=recalc_fp,
            query_from=query_to,
            query_to=query_to,
            status=ExperimentMetricResult.Status.COMPLETED,
            result={"already": "computed"},
        )
        recalc = self._recalc(exp, metric_uuids=["m1"])
        # A crash between a prior attempt's result write and retry cleanup lands on this path; the skip
        # must still clear the entry so a completed metric can't keep reporting as retrying.
        recalc.metric_retries = {"m1": {"attempt": 3, "max_attempts": 8}}
        recalc.save(update_fields=["metric_retries"])

        with patch("products.experiments.backend.temporal.recalculation_logic.ExperimentQueryRunner") as mock_runner:
            result = _calculate(exp.id, "m1", str(recalc.id), _QUERY_TO)

        mock_runner.assert_not_called()
        assert result.success is True
        recalc.refresh_from_db()
        assert recalc.metric_retries == {}
        # The existing row is left untouched: same id, same result.
        rows = ExperimentMetricResult.objects.filter(experiment=exp, metric_uuid="m1", query_to=query_to)
        assert rows.count() == 1
        row = rows.get()
        assert row.id == existing.id
        assert row.result == {"already": "computed"}

    def test_recomputes_when_existing_result_has_a_different_fingerprint(self):
        # A config change yields a different recalc fingerprint, so the existing row does not match and the
        # activity must recompute rather than reuse a stale result.
        metric = _mean_metric("m1")
        exp = self._experiment(flag_key="calc-skip-stale", metrics=[metric])
        query_to = datetime.fromisoformat(_QUERY_TO)
        ExperimentMetricResult.objects.create(
            experiment=exp,
            metric_uuid="m1",
            fingerprint="stale-fingerprint-from-old-config",
            query_from=query_to,
            query_to=query_to,
            status=ExperimentMetricResult.Status.COMPLETED,
            result={"stale": True},
        )
        recalc = self._recalc(exp, metric_uuids=["m1"])

        with patch("products.experiments.backend.temporal.recalculation_logic.ExperimentQueryRunner") as mock_runner:
            mock_runner.return_value.run.return_value.model_dump.return_value = {}
            _calculate(exp.id, "m1", str(recalc.id), _QUERY_TO)

        mock_runner.assert_called_once()

    def test_excluded_variants_change_recomputes(self):
        # A cached row computed before a variant was excluded must not satisfy the skip check: the exclusion
        # set feeds the fingerprint, so the stale row's fingerprint no longer matches and the query re-runs.
        metric = _mean_metric("m1")
        exp = self._experiment(flag_key="calc-excluded", metrics=[metric])
        query_to = datetime.fromisoformat(_QUERY_TO)
        recalc_fp = compute_recalc_fingerprint(
            compute_metric_fingerprint(
                metric,
                exp.start_date,
                get_experiment_stats_method(exp),
                exp.exposure_criteria,
                only_count_matured_users=exp.only_count_matured_users,
            )
        )
        ExperimentMetricResult.objects.create(
            experiment=exp,
            metric_uuid="m1",
            fingerprint=recalc_fp,
            query_from=query_to,
            query_to=query_to,
            status=ExperimentMetricResult.Status.COMPLETED,
            result={"stale": True},
        )
        exp.excluded_variants = ["test"]
        exp.save(update_fields=["excluded_variants"])
        recalc = self._recalc(exp, metric_uuids=["m1"])

        with patch("products.experiments.backend.temporal.recalculation_logic.ExperimentQueryRunner") as mock_runner:
            mock_runner.return_value.run.return_value.model_dump.return_value = {}
            _calculate(exp.id, "m1", str(recalc.id), _QUERY_TO)

        mock_runner.assert_called_once()

    def test_store_result_updates_existing_row_with_different_fingerprint_in_place(self):
        # The unique constraint is (experiment, metric_uuid, query_to); fingerprint is not part of it. A row may
        # already occupy that key under a different fingerprint (an earlier run written under the old per-run
        # scheme, or the timeseries workflow). _store_result must update that row in place, not insert a second
        # one and crash with IntegrityError. This is what unsticks experiments already collided in production.
        exp = self._experiment(flag_key="store-upsert-key", metrics=[_mean_metric("m1")])
        query_to = datetime.fromisoformat(_QUERY_TO)
        ExperimentMetricResult.objects.create(
            experiment=exp,
            metric_uuid="m1",
            fingerprint="legacy-fingerprint-from-a-prior-run",
            query_from=query_to,
            query_to=query_to,
            status=ExperimentMetricResult.Status.COMPLETED,
            result={"stale": True},
        )

        _store_result(
            experiment_id=exp.id,
            metric_uuid="m1",
            recalc_fp="new-deterministic-fingerprint",
            query_from=query_to,
            query_to=query_to,
            status=ExperimentMetricResult.Status.COMPLETED,
            result={"fresh": True},
            error_message=None,
        )

        rows = ExperimentMetricResult.objects.filter(experiment=exp, metric_uuid="m1", query_to=query_to)
        assert rows.count() == 1
        row = rows.get()
        assert row.fingerprint == "new-deterministic-fingerprint"
        assert row.result == {"fresh": True}

    @parameterized.expand(
        [
            # (name, metric_uuid, metrics_on_experiment, run_with_mocked_failure, expected_result_rows)
            # Discovery-step failure: m1 in the recalc's discovered set but absent from the experiment (deleted
            # between discovery and calc). No result row written, only metric_errors.
            ("discovery_failure", "m1", [], False, 0),
            # Calculation-step failure: m1 resolves, runner raises, writes both metric_errors and exactly one
            # FAILED result row (update_or_create overwrites on retry rather than inserting).
            ("calculation_failure", "m1", [_mean_metric("m1")], True, 1),
        ]
    )
    def test_retry_does_not_double_count(
        self, name: str, metric_uuid: str, metrics: list, mock_runner_failure: bool, expected_result_rows: int
    ):
        # Temporal retries the whole activity on transient failure. _store_result is idempotent (update_or_create
        # keyed on fingerprint + query_to) and metric_errors is keyed by metric_uuid, so a second run must leave
        # state identical to the first — no inflated counts, no duplicate result rows.
        exp = self._experiment(flag_key=f"retry-{name}", metrics=metrics)
        recalc = self._recalc(exp, metric_uuids=[metric_uuid])

        def _run() -> None:
            if mock_runner_failure:
                with patch(
                    "products.experiments.backend.temporal.recalculation_logic.ExperimentQueryRunner"
                ) as mock_runner:
                    mock_runner.return_value.run.side_effect = RuntimeError("kaboom")
                    # Calc-step failures now re-raise so Temporal can retry transient errors. The record is
                    # written before the re-raise, so the assertions below still hold across attempts.
                    with pytest.raises(RuntimeError, match="kaboom"):
                        _calculate(exp.id, metric_uuid, str(recalc.id), _QUERY_TO)
            else:
                _calculate(exp.id, metric_uuid, str(recalc.id), _QUERY_TO)

        _run()
        _run()  # simulated Temporal retry

        recalc.refresh_from_db()
        assert len(recalc.metric_errors) == 1
        assert metric_uuid in recalc.metric_errors
        # Exact count per case: 0 for discovery failures (no _store_result call), 1 for calc failures
        # (one FAILED row, overwritten on retry rather than duplicated).
        assert (
            ExperimentMetricResult.objects.filter(experiment=exp, metric_uuid=metric_uuid).count()
            == expected_result_rows
        )

    @parameterized.expand(
        [
            # (name, build_kwargs, expected_error_fragment)
            # The workflow constructs all four args from its own state, so any mismatch here means a workflow
            # bug. The activity must fail non-retryable (no point in retrying a deterministic failure).
            (
                "experiment_id_mismatch",
                {"experiment_id_offset": 9999},
                "does not match recalc.experiment_id",
            ),
            (
                "metric_uuid_not_in_set",
                {"metric_uuid_override": "not-in-recalc-set"},
                "is not in recalc",
            ),
            (
                "query_to_mismatch",
                {"query_to_override": "2030-01-01T00:00:00+00:00"},
                "does not match recalc.query_to",
            ),
            (
                "query_to_unset_on_recalc",
                {"clear_query_to": True},
                "has no query_to set",
            ),
            # Parse failure before the cross-checks even run — without explicit handling this would escape as a
            # bare ValueError, hit Temporal's broad retry policy, and burn slots on a deterministic parse error.
            (
                "query_to_unparseable",
                {"query_to_override": "not-an-iso-string"},
                "is not a valid ISO datetime string",
            ),
        ]
    )
    def test_input_validation_fails_non_retryable(self, name: str, build_kwargs: dict, expected_fragment: str):
        exp = self._experiment(flag_key=f"validation-{name}", metrics=[_mean_metric("m1")])
        recalc = self._recalc(exp, metric_uuids=["m1"])
        if build_kwargs.get("clear_query_to"):
            recalc.query_to = None
            recalc.save(update_fields=["query_to"])

        call_experiment_id = exp.id + build_kwargs.get("experiment_id_offset", 0)
        call_metric_uuid = build_kwargs.get("metric_uuid_override", "m1")
        call_query_to = build_kwargs.get("query_to_override", _QUERY_TO)

        with pytest.raises(ApplicationError) as exc_info:
            _calculate(call_experiment_id, call_metric_uuid, str(recalc.id), call_query_to)

        assert expected_fragment in str(exc_info.value)
        assert exc_info.value.non_retryable is True

    def test_unexpected_error_calls_capture_exception_and_caps_message(self):
        # Unexpected exceptions get captured to Sentry and re-raised for Temporal retry. The stored result row
        # carries the capped error message so the UI sees what happened even though the activity re-raised.
        exp = self._experiment(flag_key="calc-capture", metrics=[_mean_metric("m1")])
        recalc = self._recalc(exp, metric_uuids=["m1"])

        with (
            patch("products.experiments.backend.temporal.recalculation_logic.ExperimentQueryRunner") as mock_runner,
            patch("products.experiments.backend.temporal.recalculation_logic.capture_exception") as mock_capture,
        ):
            mock_runner.return_value.run.side_effect = RuntimeError("x" * 5000)
            with pytest.raises(RuntimeError):
                _calculate(exp.id, "m1", str(recalc.id), _QUERY_TO)

        assert mock_capture.called
        row = ExperimentMetricResult.objects.get(experiment=exp, metric_uuid="m1")
        assert row.status == ExperimentMetricResult.Status.FAILED
        assert row.error_message is not None
        assert len(row.error_message) <= 2000


@pytest.mark.django_db(transaction=True)
class TestMissingRecalcRow:
    # All three activities go through _get_recalc_state at the top. A missing row is deterministic
    # (bogus id, manual delete, or cascade from team/experiment) — every activity must fail non-retryable
    # so Temporal terminates instead of burning retries.
    @parameterized.expand(
        [
            ("discover", lambda bogus_id: _discover(bogus_id)),
            # mark_started satisfies the XOR guard so the call reaches _get_recalc_state.
            (
                "update_progress",
                lambda bogus_id: _update(RecalculationProgressUpdate(recalculation_id=bogus_id, mark_started=True)),
            ),
            ("calculate", lambda bogus_id: _calculate(1, "m1", bogus_id, _QUERY_TO)),
        ]
    )
    def test_fails_non_retryable(self, name: str, call_activity):
        bogus_id = "019e9af0-0000-7000-8000-000000000000"

        with pytest.raises(ApplicationError) as exc_info:
            call_activity(bogus_id)

        assert bogus_id in str(exc_info.value)
        assert "not found" in str(exc_info.value)
        assert exc_info.value.non_retryable is True


@contextmanager
def _record_captures():
    """Patch the global posthoganalytics client so the analytics tests can assert the exact event
    name + properties without sending anything. Yields the list of captured capture(...) kwargs."""
    captured: list[dict] = []

    def _fake_capture(*args, **kwargs) -> None:
        captured.append(kwargs)

    with patch(
        "products.experiments.backend.temporal.recalculation_logic.posthoganalytics.capture",
        _fake_capture,
    ):
        yield captured


@pytest.mark.django_db(transaction=True)
class TestRecalculationAnalytics(BaseTest):
    """Product analytics emitted by the recalculation activities. Names mirror the legacy client-side
    events; execution_mode='recalculation' distinguishes the backend-driven flow."""

    def _flag(self, key: str) -> FeatureFlag:
        return FeatureFlag.objects.create(
            team=self.team,
            created_by=self.user,
            key=key,
            name=f"Flag for {key}",
            filters={"groups": [{"properties": [], "rollout_percentage": 100}]},
        )

    def _experiment(self, flag_key: str, *, metrics=None, secondary=None) -> Experiment:
        exp = Experiment.objects.create(
            team=self.team,
            created_by=self.user,
            feature_flag=self._flag(flag_key),
            name="exp",
            start_date=timezone.now(),
        )
        if metrics is not None:
            exp.metrics = metrics
        if secondary is not None:
            exp.metrics_secondary = secondary
        exp.save()
        return exp

    def _recalc(self, exp: Experiment, *, metric_uuids: list[str]) -> ExperimentMetricsRecalculation:
        return ExperimentMetricsRecalculation.objects.create(
            team=self.team,
            experiment=exp,
            metric_uuids=metric_uuids,
            total_metrics=len(metric_uuids),
            query_to=datetime.fromisoformat(_QUERY_TO),
        )

    def test_metric_finished_event_on_success(self):
        exp = self._experiment(flag_key="an-success", metrics=[_mean_metric("m1")])
        recalc = self._recalc(exp, metric_uuids=["m1"])

        with _record_captures() as captured:
            with patch(
                "products.experiments.backend.temporal.recalculation_logic.ExperimentQueryRunner"
            ) as mock_runner:
                mock_runner.return_value.run.return_value.model_dump.return_value = {}
                _calculate(exp.id, "m1", str(recalc.id), _QUERY_TO)

        assert len(captured) == 1
        props = captured[0]["properties"]
        assert captured[0]["event"] == "experiment metric finished"
        assert captured[0]["distinct_id"] == self.user.distinct_id
        assert props["experiment_id"] == exp.id
        assert props["team_id"] == self.team.id
        assert props["metric_uuid"] == "m1"
        assert props["metric_kind"] == "mean"
        assert props["is_primary"] is True
        assert props["execution_mode"] == "recalculation"
        assert "duration_ms" in props

    def test_metric_error_event_on_insufficient_data(self):
        exp = self._experiment(flag_key="an-error", metrics=[_mean_metric("m1")])
        recalc = self._recalc(exp, metric_uuids=["m1"])

        with _record_captures() as captured:
            with patch(
                "products.experiments.backend.temporal.recalculation_logic.ExperimentQueryRunner"
            ) as mock_runner:
                mock_runner.return_value.run.side_effect = StatisticError("not enough data")
                _calculate(exp.id, "m1", str(recalc.id), _QUERY_TO)

        assert len(captured) == 1
        props = captured[0]["properties"]
        assert captured[0]["event"] == "experiment metric error"
        assert props["error_type"] == "insufficient_data"
        assert props["error_message"] == "not enough data"
        assert props["execution_mode"] == "recalculation"

    def test_secondary_metric_is_not_marked_primary(self):
        # metric_type is now threaded through from the workflow's discovery output rather than re-derived
        # from a fresh DB lookup. The activity's caller (workflow) reads the value from
        # ExperimentMetricToRecalculate; tests pass it explicitly to exercise the same path.
        exp = self._experiment(flag_key="an-secondary", secondary=[_mean_metric("s1")])
        recalc = self._recalc(exp, metric_uuids=["s1"])

        with _record_captures() as captured:
            with patch(
                "products.experiments.backend.temporal.recalculation_logic.ExperimentQueryRunner"
            ) as mock_runner:
                mock_runner.return_value.run.return_value.model_dump.return_value = {}
                _calculate(exp.id, "s1", str(recalc.id), _QUERY_TO, metric_type="secondary")

        assert captured[0]["properties"]["is_primary"] is False

    @parameterized.expand(
        [
            # (name, exc, expected_error_type, expected_delay_seconds, expected_message) — backpressure uses
            # the explicit concurrency delay; a generic transient on attempt 2 follows the policy backoff
            # (5 * 2^1). The generic exception carries a fake credential to lock in that raw exception text
            # (which can embed the executed query, warehouse secrets included) never reaches analytics.
            (
                "backpressure",
                ConcurrencyLimitExceeded("quota"),
                "rate_limited",
                60,
                "The query was deferred because the cluster is at capacity.",
            ),
            (
                "generic_transient",
                RuntimeError("blip aws_access_key_id=AKIAFAKESECRET"),
                "server_error",
                10,
                "The query failed with a server error.",
            ),
        ]
    )
    def test_non_final_failure_emits_retry_event(
        self,
        name: str,
        exc: Exception,
        expected_error_type: str,
        expected_delay_seconds: int,
        expected_message: str,
    ):
        # A non-final attempt re-raises for Temporal to retry. It emits 'experiment metric retry' (not
        # 'experiment metric error', which is reserved for the terminal attempt) so retries that later
        # succeed are still countable. Guards against dropping the retry emit, double-counting a
        # non-terminal failure as an error, and leaking the raw exception (secrets included) into analytics.
        exp = self._experiment(flag_key=f"an-retry-{name}", metrics=[_mean_metric("m1")])
        recalc = self._recalc(exp, metric_uuids=["m1"])

        with _record_captures() as captured:
            with patch(
                "products.experiments.backend.temporal.recalculation_logic.ExperimentQueryRunner"
            ) as mock_runner:
                mock_runner.return_value.run.side_effect = exc
                with pytest.raises((type(exc), ApplicationError)):
                    _calculate(exp.id, "m1", str(recalc.id), _QUERY_TO, is_final_attempt=False, attempt=2)

        assert len(captured) == 1
        assert captured[0]["event"] == "experiment metric retry"
        props = captured[0]["properties"]
        assert props["error_type"] == expected_error_type
        assert props["error_message"] == expected_message
        assert "AKIAFAKESECRET" not in props["error_message"]
        assert props["attempt"] == 2
        assert props["max_attempts"] == MAX_METRIC_ATTEMPTS
        assert props["next_retry_delay_seconds"] == expected_delay_seconds
        assert props["execution_mode"] == "recalculation"
        assert props["mechanism"] == "orchestrated"

    @parameterized.expand(
        [
            # name, exc, expected_error_type, raises_application_error
            # Permanent classes (oom/byte_limit/validation) and backpressure (at_capacity) re-raise as
            # ApplicationError; genuinely transient classes re-raise the original exception for Temporal.
            ("wrapped_oom", ClickHouseQueryMemoryLimitExceeded(), "out_of_memory", True),
            ("wrapped_timeout", ClickHouseQueryTimeOut(), "timeout", False),
            ("wrapped_at_capacity", ClickHouseAtCapacity(), "rate_limited", True),
            ("ch_timeout_code", ServerException("timed out", code=159), "timeout", False),
            ("ch_socket_timeout_code", ServerException("socket timed out", code=209), "timeout", False),
            ("ch_memory_limit_code", ServerException("memory limit exceeded", code=241), "out_of_memory", True),
            ("ch_too_many_bytes_code", ServerException("too many bytes", code=307), "byte_limit", True),
            ("ch_too_many_queries_code", ServerException("too many queries", code=202), "rate_limited", False),
            ("other", RuntimeError("kaboom"), "server_error", False),
        ]
    )
    def test_terminal_failure_emits_metric_error_event(self, name, exc, expected_error_type, raises_application_error):
        # On the terminal attempt (retries exhausted) an infra failure emits 'experiment metric error'
        # with the shared backend error_type taxonomy — including byte_limit (307) and rate_limited (202),
        # the two real failure modes that used to collapse into server_error and stay invisible.
        exp = self._experiment(flag_key=f"an-terminal-{name}", metrics=[_mean_metric("m1")])
        recalc = self._recalc(exp, metric_uuids=["m1"])

        with _record_captures() as captured:
            with patch(
                "products.experiments.backend.temporal.recalculation_logic.ExperimentQueryRunner"
            ) as mock_runner:
                mock_runner.return_value.run.side_effect = exc
                with pytest.raises(ApplicationError if raises_application_error else type(exc)):
                    _calculate(exp.id, "m1", str(recalc.id), _QUERY_TO, is_final_attempt=True)

        assert len(captured) == 1
        assert captured[0]["event"] == "experiment metric error"
        props = captured[0]["properties"]
        assert props["error_type"] == expected_error_type
        assert props["execution_mode"] == "recalculation"
        assert props["context"] == "ui"
        assert props["mechanism"] == "orchestrated"
        assert props["trigger"] == "manual"

    def test_results_refresh_completed_event_on_finish(self):
        exp = self._experiment(flag_key="an-finish", metrics=[_mean_metric("m1")])
        recalc = self._recalc(exp, metric_uuids=["m1"])

        with _record_captures() as captured:
            _update(
                RecalculationProgressUpdate(
                    recalculation_id=str(recalc.id),
                    status="completed",
                    mark_completed=True,
                    succeeded_metrics=3,
                    failed_metrics=1,
                )
            )

        assert len(captured) == 1
        props = captured[0]["properties"]
        assert captured[0]["event"] == "experiment results refresh completed"
        assert captured[0]["distinct_id"] == self.user.distinct_id
        assert props["experiment_id"] == exp.id
        assert props["team_id"] == self.team.id
        assert props["recalculation_id"] == str(recalc.id)
        assert props["status"] == "completed"
        assert props["succeeded_metrics"] == 3
        assert props["failed_metrics"] == 1
        assert props["execution_mode"] == "recalculation"
        assert "total_duration_ms" in props

    def test_results_refresh_completed_not_re_emitted_on_retry(self):
        # mark_completed is first-write-wins; a retried finish activity must not re-fire the run-level event.
        exp = self._experiment(flag_key="an-finish-retry", metrics=[_mean_metric("m1")])
        recalc = self._recalc(exp, metric_uuids=["m1"])

        update = RecalculationProgressUpdate(
            recalculation_id=str(recalc.id), status="completed", mark_completed=True, succeeded_metrics=1
        )
        with _record_captures() as captured:
            _update(update)
            _update(update)  # simulated Temporal retry

        assert len(captured) == 1
