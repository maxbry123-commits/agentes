from collections.abc import Sequence
from datetime import datetime
from typing import cast

from freezegun import freeze_time
from posthog.test.base import _create_event, _create_person, flush_persons_and_events, snapshot_clickhouse_queries

from django.test import override_settings

from parameterized import parameterized

from posthog.schema import (
    EventsNode,
    ExperimentMeanMetric,
    ExperimentMetricMathType,
    ExperimentQuery,
    ExperimentQueryResponse,
    FunnelConversionWindowTimeUnit,
)

from posthog.test.test_journeys import journeys_for

from products.experiments.backend.hogql_queries.experiment_query_runner import ExperimentQueryRunner
from products.experiments.backend.hogql_queries.test.experiment_query_runner.base import ExperimentQueryRunnerBaseTest


@override_settings(IN_UNIT_TESTING=True)
class TestExperimentMeanMetric(ExperimentQueryRunnerBaseTest):
    snapshot_replace_all_numbers = True

    @parameterized.expand(
        [
            ("direct", False),
            ("precomputed", True),
        ]
    )
    @freeze_time("2020-01-01T12:00:00Z")
    @snapshot_clickhouse_queries
    def test_property_sum_metric(self, name, use_precomputation):
        self._setup_precomputation_test(use_precomputation)

        feature_flag = self.create_feature_flag()
        experiment = self.create_experiment(feature_flag=feature_flag)
        experiment.stats_config = {"method": "frequentist"}
        experiment.save()

        metric = ExperimentMeanMetric(
            source=EventsNode(
                event="purchase",
                math=ExperimentMetricMathType.SUM,
                math_property="amount",
            ),
        )

        experiment_query = ExperimentQuery(
            experiment_id=experiment.id,
            kind="ExperimentQuery",
            metric=metric,
        )

        experiment.metrics = [metric.model_dump(mode="json")]
        self._save_experiment_with_precomputation(experiment, use_precomputation)

        # Create events with different amounts for control vs test to provide variance
        feature_flag_property = f"$feature/{feature_flag.key}"

        # Control: 6 purchases with amount 10 (total 60)
        for i in range(10):
            _create_person(distinct_ids=[f"user_control_{i}"], team_id=self.team.pk)
            _create_event(
                team=self.team,
                event="$feature_flag_called",
                distinct_id=f"user_control_{i}",
                timestamp="2020-01-02T12:00:00Z",
                properties={
                    feature_flag_property: "control",
                    "$feature_flag_response": "control",
                    "$feature_flag": feature_flag.key,
                },
            )
            if i < 6:  # First 6 users make purchases
                _create_event(
                    team=self.team,
                    event="purchase",
                    distinct_id=f"user_control_{i}",
                    timestamp="2020-01-02T12:01:00Z",
                    properties={feature_flag_property: "control", "amount": 10},
                )

        # Test: 8 purchases with amount 15 (total 120)
        for i in range(10):
            _create_person(distinct_ids=[f"user_test_{i}"], team_id=self.team.pk)
            _create_event(
                team=self.team,
                event="$feature_flag_called",
                distinct_id=f"user_test_{i}",
                timestamp="2020-01-02T12:00:00Z",
                properties={
                    feature_flag_property: "test",
                    "$feature_flag_response": "test",
                    "$feature_flag": feature_flag.key,
                },
            )
            if i < 8:  # First 8 users make purchases
                _create_event(
                    team=self.team,
                    event="purchase",
                    distinct_id=f"user_test_{i}",
                    timestamp="2020-01-02T12:01:00Z",
                    properties={feature_flag_property: "test", "amount": 15},
                )

        flush_persons_and_events()

        query_runner = ExperimentQueryRunner(query=experiment_query, team=self.team)
        result = cast(ExperimentQueryResponse, query_runner.calculate())

        assert result.baseline is not None
        assert result.variant_results is not None
        self.assertEqual(len(result.variant_results), 1)

        control_variant = result.baseline
        test_variant = result.variant_results[0]

        self.assertEqual(control_variant.sum, 60)
        self.assertEqual(test_variant.sum, 120)
        self.assertEqual(control_variant.number_of_samples, 10)
        self.assertEqual(test_variant.number_of_samples, 10)

    @parameterized.expand(
        [
            ("direct", False),
            ("precomputed", True),
        ]
    )
    @freeze_time("2020-01-10T12:00:00Z")
    @snapshot_clickhouse_queries
    def test_conversion_window_anchored_on_first_exposure(self, name, use_precomputation):
        self._setup_precomputation_test(use_precomputation)

        feature_flag = self.create_feature_flag()
        experiment = self.create_experiment(
            feature_flag=feature_flag,
            start_date=datetime(2020, 1, 1, 0, 0, 0),
            end_date=datetime(2020, 1, 10, 0, 0, 0),
        )
        experiment.stats_config = {"method": "frequentist"}
        experiment.save()

        metric = ExperimentMeanMetric(
            source=EventsNode(
                event="purchase",
                math=ExperimentMetricMathType.SUM,
                math_property="amount",
            ),
            conversion_window=1,
            conversion_window_unit=FunnelConversionWindowTimeUnit.DAY,
        )

        experiment_query = ExperimentQuery(
            experiment_id=experiment.id,
            kind="ExperimentQuery",
            metric=metric,
        )

        experiment.metrics = [metric.model_dump(mode="json")]
        self._save_experiment_with_precomputation(experiment, use_precomputation)

        feature_flag_property = f"$feature/{feature_flag.key}"
        distinct_id = "user_control_window"
        _create_person(distinct_ids=[distinct_id], team_id=self.team.pk)

        # Re-exposed on Jan 5, but the conversion window is measured from first exposure (Jan 2).
        for timestamp in ["2020-01-02T00:00:00Z", "2020-01-05T00:00:00Z"]:
            _create_event(
                team=self.team,
                event="$feature_flag_called",
                distinct_id=distinct_id,
                timestamp=timestamp,
                properties={
                    feature_flag_property: "control",
                    "$feature_flag_response": "control",
                    "$feature_flag": feature_flag.key,
                },
            )

        # Purchase sits inside first_exposure + window, so it counts.
        _create_event(
            team=self.team,
            event="purchase",
            distinct_id=distinct_id,
            timestamp="2020-01-02T12:00:00Z",
            properties={feature_flag_property: "control", "amount": 25},
        )

        # Purchase sits outside first_exposure + window (but inside last_exposure + window),
        # so it must not count once inclusion is anchored on first exposure.
        _create_event(
            team=self.team,
            event="purchase",
            distinct_id=distinct_id,
            timestamp="2020-01-05T12:00:00Z",
            properties={feature_flag_property: "control", "amount": 100},
        )

        flush_persons_and_events()

        query_runner = ExperimentQueryRunner(query=experiment_query, team=self.team)
        result = cast(ExperimentQueryResponse, query_runner.calculate())

        assert result.baseline is not None
        self.assertEqual(result.baseline.sum, 25)
        self.assertEqual(result.baseline.number_of_samples, 1)

    @parameterized.expand(
        [
            ("direct", False),
            ("precomputed", True),
        ]
    )
    def test_matured_user_value_stable_across_re_exposure(self, name, use_precomputation):
        self._setup_precomputation_test(use_precomputation)

        feature_flag = self.create_feature_flag()
        experiment = self.create_experiment(
            feature_flag=feature_flag,
            start_date=datetime(2020, 1, 1, 0, 0, 0),
            end_date=datetime(2020, 1, 15, 0, 0, 0),
        )
        experiment.stats_config = {"method": "frequentist"}

        metric = ExperimentMeanMetric(
            source=EventsNode(
                event="purchase",
                math=ExperimentMetricMathType.SUM,
                math_property="amount",
            ),
            conversion_window=1,
            conversion_window_unit=FunnelConversionWindowTimeUnit.DAY,
        )

        experiment_query = ExperimentQuery(
            experiment_id=experiment.id,
            kind="ExperimentQuery",
            metric=metric,
        )

        experiment.only_count_matured_users = True
        experiment.metrics = [metric.model_dump(mode="json")]
        self._save_experiment_with_precomputation(experiment, use_precomputation)

        feature_flag_property = f"$feature/{feature_flag.key}"
        distinct_id = "user_re_exposed"
        _create_person(distinct_ids=[distinct_id], team_id=self.team.pk)

        # First exposure Jan 2; the user matures at Jan 3 (first_exposure + 1 day).
        _create_event(
            team=self.team,
            event="$feature_flag_called",
            distinct_id=distinct_id,
            timestamp="2020-01-02T00:00:00Z",
            properties={
                feature_flag_property: "control",
                "$feature_flag_response": "control",
                "$feature_flag": feature_flag.key,
            },
        )
        # Purchase inside the first-exposure window is the entity's whole value.
        _create_event(
            team=self.team,
            event="purchase",
            distinct_id=distinct_id,
            timestamp="2020-01-02T12:00:00Z",
            properties={feature_flag_property: "control", "amount": 25},
        )
        # Backend flag re-evaluated Jan 5, with another purchase in its wake.
        _create_event(
            team=self.team,
            event="$feature_flag_called",
            distinct_id=distinct_id,
            timestamp="2020-01-05T00:00:00Z",
            properties={
                feature_flag_property: "control",
                "$feature_flag_response": "control",
                "$feature_flag": feature_flag.key,
            },
        )
        _create_event(
            team=self.team,
            event="purchase",
            distinct_id=distinct_id,
            timestamp="2020-01-05T12:00:00Z",
            properties={feature_flag_property: "control", "amount": 100},
        )

        flush_persons_and_events()

        # Re-run right after the user matures, then again after the re-exposure. The
        # matured user's value must not grow just because the flag was re-evaluated.
        with freeze_time("2020-01-04T00:00:00Z"):
            early = cast(
                ExperimentQueryResponse,
                ExperimentQueryRunner(query=experiment_query, team=self.team).calculate(),
            )
        with freeze_time("2020-01-07T00:00:00Z"):
            late = cast(
                ExperimentQueryResponse,
                ExperimentQueryRunner(query=experiment_query, team=self.team).calculate(),
            )

        assert early.baseline is not None
        assert late.baseline is not None
        self.assertEqual(early.baseline.sum, 25)
        self.assertEqual(late.baseline.sum, 25)

    @parameterized.expand(
        [
            ("direct", False),
            ("precomputed", True),
        ]
    )
    @freeze_time("2024-01-01T12:00:00Z")
    @snapshot_clickhouse_queries
    def test_outlier_handling_for_sum_metric(self, name, use_precomputation):
        self._setup_precomputation_test(use_precomputation)

        feature_flag = self.create_feature_flag()
        experiment = self.create_experiment(feature_flag=feature_flag)
        experiment.stats_config = {"method": "frequentist"}
        experiment.save()

        ff_property = f"$feature/{feature_flag.key}"

        def _create_events_for_user(variant: str, amount: int) -> list[dict]:
            return [
                {
                    "event": "$feature_flag_called",
                    "timestamp": "2024-01-02T12:00:00",
                    "properties": {
                        "$feature_flag_response": variant,
                        ff_property: variant,
                        "$feature_flag": feature_flag.key,
                    },
                },
                {
                    "event": "purchase",
                    "timestamp": "2024-01-02T12:01:00",
                    "properties": {
                        ff_property: variant,
                        "amount": amount,
                    },
                },
            ]

        journeys_for(
            {
                "control_1": _create_events_for_user("control", 1),
                "control_2": _create_events_for_user("control", 102),
                "control_3": _create_events_for_user("control", 103),
                "control_4": _create_events_for_user("control", 104),
                "control_5": _create_events_for_user("control", 105),
                "control_6": _create_events_for_user("control", 106),
                "control_7": _create_events_for_user("control", 107),
                "control_8": _create_events_for_user("control", 108),
                "control_9": _create_events_for_user("control", 109),
                "control_10": _create_events_for_user("control", 1110),
                "test_1": _create_events_for_user("test", 101),
                "test_2": _create_events_for_user("test", 102),
                "test_3": _create_events_for_user("test", 103),
                "test_4": _create_events_for_user("test", 104),
                "test_5": _create_events_for_user("test", 105),
                "test_6": _create_events_for_user("test", 106),
                "test_7": _create_events_for_user("test", 107),
                "test_8": _create_events_for_user("test", 108),
                "test_9": _create_events_for_user("test", 109),
                "test_10": _create_events_for_user("test", 110),
            },
            self.team,
        )

        flush_persons_and_events()

        metric = ExperimentMeanMetric(
            source=EventsNode(
                event="purchase",
                math=ExperimentMetricMathType.SUM,
                math_property="amount",
            ),
            lower_bound_percentile=0.1,
            upper_bound_percentile=0.9,
        )

        experiment_query = ExperimentQuery(
            experiment_id=experiment.id,
            kind="ExperimentQuery",
            metric=metric,
        )

        experiment.metrics = [metric.model_dump(mode="json")]
        self._save_experiment_with_precomputation(experiment, use_precomputation)

        query_runner = ExperimentQueryRunner(query=experiment_query, team=self.team)
        result = cast(ExperimentQueryResponse, query_runner.calculate())

        assert result.baseline is not None
        assert result.variant_results is not None
        self.assertEqual(len(result.variant_results), 1)

        control_variant = result.baseline
        test_variant = result.variant_results[0]

        self.assertEqual(control_variant.sum, 1056)
        self.assertEqual(test_variant.sum, 1056)
        self.assertEqual(control_variant.number_of_samples, 10)
        self.assertEqual(test_variant.number_of_samples, 10)

    @parameterized.expand(
        [
            ("direct", False),
            ("precomputed", True),
        ]
    )
    @freeze_time("2024-01-01T12:00:00Z")
    @snapshot_clickhouse_queries
    def test_outlier_handling_for_count_metric(self, name, use_precomputation):
        self._setup_precomputation_test(use_precomputation)

        feature_flag = self.create_feature_flag()
        experiment = self.create_experiment(feature_flag=feature_flag)
        experiment.stats_config = {"method": "frequentist"}
        experiment.save()

        ff_property = f"$feature/{feature_flag.key}"

        def _create_events_for_user(variant: str, count: int) -> list[dict]:
            purchase_events = [
                {
                    "event": "purchase",
                    "timestamp": f"2024-01-02T12:01:{i:02d}",
                    "properties": {
                        ff_property: variant,
                    },
                }
                for i in range(count)
            ]
            return [
                {
                    "event": "$feature_flag_called",
                    "timestamp": "2024-01-02T12:00:00",
                    "properties": {
                        "$feature_flag_response": variant,
                        ff_property: variant,
                        "$feature_flag": feature_flag.key,
                    },
                },
                *purchase_events,
            ]

        journeys_for(
            {
                "control_1": _create_events_for_user("control", 1),
                "control_2": _create_events_for_user("control", 3),
                "control_3": _create_events_for_user("control", 3),
                "control_4": _create_events_for_user("control", 3),
                "control_5": _create_events_for_user("control", 3),
                "control_6": _create_events_for_user("control", 3),
                "control_7": _create_events_for_user("control", 3),
                "control_8": _create_events_for_user("control", 3),
                "control_9": _create_events_for_user("control", 3),
                "control_10": _create_events_for_user("control", 100),
                "test_1": _create_events_for_user("test", 2),
                "test_2": _create_events_for_user("test", 4),
                "test_3": _create_events_for_user("test", 4),
                "test_4": _create_events_for_user("test", 4),
                "test_5": _create_events_for_user("test", 4),
                "test_6": _create_events_for_user("test", 4),
                "test_7": _create_events_for_user("test", 4),
                "test_8": _create_events_for_user("test", 4),
                "test_9": _create_events_for_user("test", 4),
                "test_10": _create_events_for_user("test", 4),
            },
            self.team,
        )

        flush_persons_and_events()

        metric = ExperimentMeanMetric(
            source=EventsNode(
                event="purchase",
                math=ExperimentMetricMathType.TOTAL,
            ),
            lower_bound_percentile=0.1,
            upper_bound_percentile=0.9,
        )

        experiment_query = ExperimentQuery(
            experiment_id=experiment.id,
            kind="ExperimentQuery",
            metric=metric,
        )

        experiment.metrics = [metric.model_dump(mode="json")]
        self._save_experiment_with_precomputation(experiment, use_precomputation)

        query_runner = ExperimentQueryRunner(query=experiment_query, team=self.team)
        result = cast(ExperimentQueryResponse, query_runner.calculate())

        assert result.baseline is not None
        assert result.variant_results is not None
        self.assertEqual(len(result.variant_results), 1)

        control_variant = result.baseline
        test_variant = result.variant_results[0]

        self.assertEqual(control_variant.sum, 31)
        self.assertEqual(test_variant.sum, 39)
        self.assertEqual(control_variant.number_of_samples, 10)
        self.assertEqual(test_variant.number_of_samples, 10)

    @parameterized.expand(
        [
            ("direct", False),
            ("precomputed", True),
        ]
    )
    @freeze_time("2024-01-01T12:00:00Z")
    @snapshot_clickhouse_queries
    def test_unique_sessions_math_type(self, name, use_precomputation):
        self._setup_precomputation_test(use_precomputation)

        feature_flag = self.create_feature_flag()
        experiment = self.create_experiment(feature_flag=feature_flag)
        experiment.stats_config = {"method": "frequentist"}
        experiment.save()

        ff_property = f"$feature/{feature_flag.key}"

        def _create_events_for_user(variant: str, count: int, session_id: str) -> list[dict]:
            pageview_events = [
                {
                    "event": "$pageview",
                    "timestamp": f"2024-01-02T12:01:{i:02d}",
                    "properties": {
                        ff_property: variant,
                        "$session_id": session_id,
                    },
                }
                for i in range(count)
            ]
            return [
                {
                    "event": "$feature_flag_called",
                    "timestamp": "2024-01-02T12:00:00",
                    "properties": {
                        "$feature_flag_response": variant,
                        ff_property: variant,
                        "$feature_flag": feature_flag.key,
                        "$session_id": session_id,
                    },
                },
                *pageview_events,
            ]

        journeys_for(
            {
                # 3 unique sessions in control
                "control_1": [
                    *_create_events_for_user("control", 3, "c_1_a"),
                    *_create_events_for_user("control", 3, "c_1_b"),
                ],
                "control_2": _create_events_for_user("control", 3, "c_2_a"),
                # Control 3 has zero pageviews, so this session should not be included in the session metric count
                "control_3": _create_events_for_user("control", 0, "c_3_a"),
                # 5 unique sessions in test
                "test_1": [
                    *_create_events_for_user("test", 3, "t_1_a"),
                    *_create_events_for_user("test", 3, "t_1_b"),
                ],
                "test_2": [
                    *_create_events_for_user("test", 3, "t_2_a"),
                    *_create_events_for_user("test", 3, "t_2_b"),
                    *_create_events_for_user("test", 3, "t_2_c"),
                ],
            },
            self.team,
        )

        flush_persons_and_events()

        metric = ExperimentMeanMetric(
            source=EventsNode(
                event="$pageview",
                math=ExperimentMetricMathType.UNIQUE_SESSION,
            ),
        )

        experiment_query = ExperimentQuery(
            experiment_id=experiment.id,
            kind="ExperimentQuery",
            metric=metric,
        )

        experiment.metrics = [metric.model_dump(mode="json")]
        self._save_experiment_with_precomputation(experiment, use_precomputation)

        query_runner = ExperimentQueryRunner(query=experiment_query, team=self.team)
        result = cast(ExperimentQueryResponse, query_runner.calculate())

        assert result.baseline is not None
        assert result.variant_results is not None
        self.assertEqual(len(result.variant_results), 1)

        control_variant = result.baseline
        test_variant = result.variant_results[0]

        self.assertEqual(control_variant.sum, 3)
        self.assertEqual(test_variant.sum, 5)
        self.assertEqual(control_variant.number_of_samples, 3)
        self.assertEqual(test_variant.number_of_samples, 2)

    @parameterized.expand(
        [
            ("max_direct", False, ExperimentMetricMathType.MAX, 55, 160),
            ("max_precomputed", True, ExperimentMetricMathType.MAX, 55, 160),
            ("min_direct", False, ExperimentMetricMathType.MIN, 15, 90),
            ("min_precomputed", True, ExperimentMetricMathType.MIN, 15, 90),
            ("avg_direct", False, ExperimentMetricMathType.AVG, 35, 130),
            ("avg_precomputed", True, ExperimentMetricMathType.AVG, 35, 130),
        ]
    )
    @freeze_time("2024-01-01T12:00:00Z")
    @snapshot_clickhouse_queries
    def test_property_aggregation_metric(
        self, name, use_precomputation, math_type, expected_control_sum, expected_test_sum
    ):
        self._setup_precomputation_test(use_precomputation)

        feature_flag = self.create_feature_flag()
        experiment = self.create_experiment(feature_flag=feature_flag)
        experiment.stats_config = {"method": "frequentist"}
        experiment.save()

        ff_property = f"$feature/{feature_flag.key}"

        def _create_events_for_user(variant: str, amounts: list[int]) -> list[dict]:
            purchase_events = [
                {
                    "event": "purchase",
                    "timestamp": f"2024-01-02T12:01:{i:02d}",
                    "properties": {
                        ff_property: variant,
                        "amount": amount,
                    },
                }
                for i, amount in enumerate(amounts)
            ]
            return [
                {
                    "event": "$feature_flag_called",
                    "timestamp": "2024-01-02T12:00:00",
                    "properties": {
                        "$feature_flag_response": variant,
                        ff_property: variant,
                        "$feature_flag": feature_flag.key,
                    },
                },
                *purchase_events,
            ]

        journeys_for(
            {
                "control_1": _create_events_for_user("control", [10, 20, 30]),
                "control_2": _create_events_for_user("control", [5, 15, 25]),
                "test_1": _create_events_for_user("test", [50, 60, 70]),
                "test_2": _create_events_for_user("test", [40, 80, 90]),
            },
            self.team,
        )

        flush_persons_and_events()

        metric = ExperimentMeanMetric(
            source=EventsNode(
                event="purchase",
                math=math_type,
                math_property="amount",
            ),
        )

        experiment_query = ExperimentQuery(
            experiment_id=experiment.id,
            kind="ExperimentQuery",
            metric=metric,
        )

        experiment.metrics = [metric.model_dump(mode="json")]
        self._save_experiment_with_precomputation(experiment, use_precomputation)

        query_runner = ExperimentQueryRunner(query=experiment_query, team=self.team)
        result = cast(ExperimentQueryResponse, query_runner.calculate())

        assert result.baseline is not None
        assert result.variant_results is not None
        self.assertEqual(len(result.variant_results), 1)

        control_variant = result.baseline
        test_variant = result.variant_results[0]

        self.assertEqual(control_variant.sum, expected_control_sum)
        self.assertEqual(test_variant.sum, expected_test_sum)
        self.assertEqual(control_variant.number_of_samples, 2)
        self.assertEqual(test_variant.number_of_samples, 2)

    @parameterized.expand(
        [
            ("direct", False),
            ("precomputed", True),
        ]
    )
    @freeze_time("2020-01-01T12:00:00Z")
    @snapshot_clickhouse_queries
    def test_outlier_handling_with_ignore_zeros(self, name, use_precomputation):
        self._setup_precomputation_test(use_precomputation)

        feature_flag = self.create_feature_flag()
        experiment = self.create_experiment(feature_flag=feature_flag)
        experiment.stats_config = {"method": "frequentist"}
        experiment.save()

        metric = ExperimentMeanMetric(
            source=EventsNode(
                event="purchase",
                math=ExperimentMetricMathType.SUM,
                math_property="amount",
            ),
            upper_bound_percentile=0.9,
            ignore_zeros=True,
        )

        experiment_query = ExperimentQuery(
            experiment_id=experiment.id,
            kind="ExperimentQuery",
            metric=metric,
        )

        experiment.metrics = [metric.model_dump(mode="json")]
        self._save_experiment_with_precomputation(experiment, use_precomputation)

        feature_flag_property = f"$feature/{feature_flag.key}"

        for i in range(10):
            _create_person(distinct_ids=[f"user_control_{i}"], team_id=self.team.pk)
            _create_event(
                team=self.team,
                event="$feature_flag_called",
                distinct_id=f"user_control_{i}",
                timestamp="2020-01-02T12:00:00Z",
                properties={
                    feature_flag_property: "control",
                    "$feature_flag_response": "control",
                    "$feature_flag": feature_flag.key,
                },
            )
            if i < 5:
                amount = 0
            elif i < 8:
                amount = 100
            else:
                amount = 1000

            _create_event(
                team=self.team,
                event="purchase",
                distinct_id=f"user_control_{i}",
                timestamp="2020-01-02T12:01:00Z",
                properties={feature_flag_property: "control", "amount": amount},
            )

        for i in range(10):
            _create_person(distinct_ids=[f"user_test_{i}"], team_id=self.team.pk)
            _create_event(
                team=self.team,
                event="$feature_flag_called",
                distinct_id=f"user_test_{i}",
                timestamp="2020-01-02T12:00:00Z",
                properties={
                    feature_flag_property: "test",
                    "$feature_flag_response": "test",
                    "$feature_flag": feature_flag.key,
                },
            )
            if i < 5:
                amount = 0
            elif i < 8:
                amount = 150
            else:
                amount = 2000

            _create_event(
                team=self.team,
                event="purchase",
                distinct_id=f"user_test_{i}",
                timestamp="2020-01-02T12:01:00Z",
                properties={feature_flag_property: "test", "amount": amount},
            )

        flush_persons_and_events()

        query_runner = ExperimentQueryRunner(query=experiment_query, team=self.team)
        result = cast(ExperimentQueryResponse, query_runner.calculate())

        assert result.baseline is not None
        assert result.variant_results is not None
        self.assertEqual(len(result.variant_results), 1)

        control_variant = result.baseline
        test_variant = result.variant_results[0]

        self.assertEqual(control_variant.number_of_samples, 10)
        self.assertEqual(test_variant.number_of_samples, 10)
        self.assertEqual(control_variant.sum, 2300)
        self.assertEqual(test_variant.sum, 4450)

    @parameterized.expand(
        [
            ("direct", False),
            ("precomputed", True),
        ]
    )
    @freeze_time("2024-01-01T12:00:00Z")
    @snapshot_clickhouse_queries
    def test_count_unique_property_values_via_hogql(self, name, use_precomputation):
        self._setup_precomputation_test(use_precomputation)

        feature_flag = self.create_feature_flag()
        experiment = self.create_experiment(feature_flag=feature_flag)
        experiment.stats_config = {"method": "frequentist"}
        experiment.save()

        ff_property = f"$feature/{feature_flag.key}"

        def _create_events_for_user(variant: str, categories: list[str]) -> list[dict]:
            purchase_events = [
                {
                    "event": "purchase",
                    "timestamp": f"2024-01-02T12:01:{i:02d}",
                    "properties": {
                        ff_property: variant,
                        "category": category,
                    },
                }
                for i, category in enumerate(categories)
            ]
            return [
                {
                    "event": "$feature_flag_called",
                    "timestamp": "2024-01-02T12:00:00",
                    "properties": {
                        "$feature_flag_response": variant,
                        ff_property: variant,
                        "$feature_flag": feature_flag.key,
                    },
                },
                *purchase_events,
            ]

        journeys_for(
            {
                # control_1: 3 events, 2 unique categories
                "control_1": _create_events_for_user("control", ["electronics", "clothing", "electronics"]),
                # control_2: 2 events, 2 unique categories
                "control_2": _create_events_for_user("control", ["food", "clothing"]),
                # control_3: exposed but no purchases → 0 unique categories
                "control_3": _create_events_for_user("control", []),
                # test_1: 4 events, 3 unique categories
                "test_1": _create_events_for_user("test", ["electronics", "clothing", "food", "electronics"]),
                # test_2: 3 events, 1 unique category
                "test_2": _create_events_for_user("test", ["food", "food", "food"]),
            },
            self.team,
        )

        flush_persons_and_events()

        metric = ExperimentMeanMetric(
            source=EventsNode(
                event="purchase",
                math=ExperimentMetricMathType.HOGQL,
                math_hogql="uniqExact(properties.category)",
            ),
        )

        experiment_query = ExperimentQuery(
            experiment_id=experiment.id,
            kind="ExperimentQuery",
            metric=metric,
        )

        experiment.metrics = [metric.model_dump(mode="json")]
        self._save_experiment_with_precomputation(experiment, use_precomputation)

        query_runner = ExperimentQueryRunner(query=experiment_query, team=self.team)
        result = cast(ExperimentQueryResponse, query_runner.calculate())

        assert result.baseline is not None
        assert result.variant_results is not None
        self.assertEqual(len(result.variant_results), 1)

        control_variant = result.baseline
        test_variant = result.variant_results[0]

        # control_1: 2 unique, control_2: 2 unique, control_3: 0 unique → sum = 4
        self.assertEqual(control_variant.sum, 4)
        self.assertEqual(control_variant.number_of_samples, 3)
        # test_1: 3 unique, test_2: 1 unique → sum = 4
        self.assertEqual(test_variant.sum, 4)
        self.assertEqual(test_variant.number_of_samples, 2)

    @parameterized.expand(
        [
            ("direct", False),
            ("precomputed", True),
        ]
    )
    @freeze_time("2020-01-15T12:00:00Z")
    @snapshot_clickhouse_queries
    def test_only_count_matured_users(self, name, use_precomputation):
        self._setup_precomputation_test(use_precomputation)

        feature_flag = self.create_feature_flag()
        experiment = self.create_experiment(
            feature_flag=feature_flag,
            start_date=datetime(2020, 1, 1, 0, 0, 0),
            end_date=datetime(2020, 1, 15, 0, 0, 0),
        )

        metric = ExperimentMeanMetric(
            source=EventsNode(
                event="purchase",
                math=ExperimentMetricMathType.SUM,
                math_property="amount",
            ),
            conversion_window=7,
            conversion_window_unit=FunnelConversionWindowTimeUnit.DAY,
        )

        experiment_query = ExperimentQuery(
            experiment_id=experiment.id,
            kind="ExperimentQuery",
            metric=metric,
        )

        experiment.only_count_matured_users = True
        experiment.metrics = [metric.model_dump(mode="json")]
        self._save_experiment_with_precomputation(experiment, use_precomputation)

        feature_flag_property = f"$feature/{feature_flag.key}"

        # Mature user: exposed Jan 2, conversion window ends Jan 9 (before now=Jan 15)
        _create_person(distinct_ids=["user_mature_control"], team_id=self.team.pk)
        _create_event(
            team=self.team,
            event="$feature_flag_called",
            distinct_id="user_mature_control",
            timestamp="2020-01-02T12:00:00Z",
            properties={
                feature_flag_property: "control",
                "$feature_flag_response": "control",
                "$feature_flag": feature_flag.key,
            },
        )
        _create_event(
            team=self.team,
            event="purchase",
            distinct_id="user_mature_control",
            timestamp="2020-01-03T12:00:00Z",
            properties={feature_flag_property: "control", "amount": 50},
        )

        # Immature user: exposed Jan 10, conversion window ends Jan 17 (after now=Jan 15)
        _create_person(distinct_ids=["user_immature_control"], team_id=self.team.pk)
        _create_event(
            team=self.team,
            event="$feature_flag_called",
            distinct_id="user_immature_control",
            timestamp="2020-01-10T12:00:00Z",
            properties={
                feature_flag_property: "control",
                "$feature_flag_response": "control",
                "$feature_flag": feature_flag.key,
            },
        )
        _create_event(
            team=self.team,
            event="purchase",
            distinct_id="user_immature_control",
            timestamp="2020-01-10T13:00:00Z",
            properties={feature_flag_property: "control", "amount": 100},
        )

        # Mature test user
        _create_person(distinct_ids=["user_mature_test"], team_id=self.team.pk)
        _create_event(
            team=self.team,
            event="$feature_flag_called",
            distinct_id="user_mature_test",
            timestamp="2020-01-02T12:00:00Z",
            properties={
                feature_flag_property: "test",
                "$feature_flag_response": "test",
                "$feature_flag": feature_flag.key,
            },
        )
        _create_event(
            team=self.team,
            event="purchase",
            distinct_id="user_mature_test",
            timestamp="2020-01-03T12:00:00Z",
            properties={feature_flag_property: "test", "amount": 75},
        )

        flush_persons_and_events()

        query_runner = ExperimentQueryRunner(query=experiment_query, team=self.team)
        result = cast(ExperimentQueryResponse, query_runner.calculate())

        # Only mature users should be counted (1 control, 1 test)
        assert result.baseline is not None
        self.assertEqual(result.baseline.number_of_samples, 1)
        self.assertEqual(result.baseline.sum, 50)

        assert result.variant_results is not None
        assert len(result.variant_results) == 1
        self.assertEqual(result.variant_results[0].number_of_samples, 1)
        self.assertEqual(result.variant_results[0].sum, 75)

    @parameterized.expand(
        [
            ("direct", False),
            ("precomputed", True),
        ]
    )
    @freeze_time("2024-01-01T12:00:00Z")
    @snapshot_clickhouse_queries
    def test_hogql_count_metric_with_winsorization(self, name, use_precomputation):
        self._setup_precomputation_test(use_precomputation)

        feature_flag = self.create_feature_flag()
        experiment = self.create_experiment(feature_flag=feature_flag)
        experiment.stats_config = {"method": "frequentist"}
        experiment.save()

        ff_property = f"$feature/{feature_flag.key}"

        def _create_events_for_user(variant: str, count: int) -> list[dict]:
            purchase_events = [
                {
                    "event": "purchase",
                    "timestamp": f"2024-01-02T12:01:{i:02d}",
                    "properties": {
                        ff_property: variant,
                        "category": f"cat_{i}",
                    },
                }
                for i in range(count)
            ]
            return [
                {
                    "event": "$feature_flag_called",
                    "timestamp": "2024-01-02T12:00:00",
                    "properties": {
                        "$feature_flag_response": variant,
                        ff_property: variant,
                        "$feature_flag": feature_flag.key,
                    },
                },
                *purchase_events,
            ]

        journeys_for(
            {
                "control_1": _create_events_for_user("control", 1),
                "control_2": _create_events_for_user("control", 3),
                "control_3": _create_events_for_user("control", 3),
                "control_4": _create_events_for_user("control", 3),
                "control_5": _create_events_for_user("control", 3),
                "control_6": _create_events_for_user("control", 3),
                "control_7": _create_events_for_user("control", 3),
                "control_8": _create_events_for_user("control", 3),
                "control_9": _create_events_for_user("control", 3),
                "control_10": _create_events_for_user("control", 100),
                "test_1": _create_events_for_user("test", 2),
                "test_2": _create_events_for_user("test", 4),
                "test_3": _create_events_for_user("test", 4),
                "test_4": _create_events_for_user("test", 4),
                "test_5": _create_events_for_user("test", 4),
                "test_6": _create_events_for_user("test", 4),
                "test_7": _create_events_for_user("test", 4),
                "test_8": _create_events_for_user("test", 4),
                "test_9": _create_events_for_user("test", 4),
                "test_10": _create_events_for_user("test", 4),
            },
            self.team,
        )

        flush_persons_and_events()

        # HOGQL count() with winsorization - this should not fail with
        # "There is no supertype for types Float64, UInt64" because count()
        # returns UInt64 while quantile() returns Float64
        metric = ExperimentMeanMetric(
            source=EventsNode(
                event="purchase",
                math=ExperimentMetricMathType.HOGQL,
                math_hogql="count(properties.category)",
            ),
            lower_bound_percentile=0.1,
            upper_bound_percentile=0.9,
        )

        experiment_query = ExperimentQuery(
            experiment_id=experiment.id,
            kind="ExperimentQuery",
            metric=metric,
        )

        experiment.metrics = [metric.model_dump(mode="json")]
        self._save_experiment_with_precomputation(experiment, use_precomputation)

        query_runner = ExperimentQueryRunner(query=experiment_query, team=self.team)
        result = cast(ExperimentQueryResponse, query_runner.calculate())

        assert result.baseline is not None
        assert result.variant_results is not None
        self.assertEqual(len(result.variant_results), 1)
        self.assertEqual(result.baseline.number_of_samples, 10)
        self.assertEqual(result.variant_results[0].number_of_samples, 10)

    def _create_threshold_users(
        self,
        feature_flag,
        variant: str,
        per_user_purchases: Sequence[Sequence[float]],
    ) -> None:
        """Create one user per entry in per_user_purchases, each making the listed purchase amounts."""
        feature_flag_property = f"$feature/{feature_flag.key}"
        for i, amounts in enumerate(per_user_purchases):
            distinct_id = f"user_{variant}_{i}"
            _create_person(distinct_ids=[distinct_id], team_id=self.team.pk)
            _create_event(
                team=self.team,
                event="$feature_flag_called",
                distinct_id=distinct_id,
                timestamp="2020-01-02T12:00:00Z",
                properties={
                    feature_flag_property: variant,
                    "$feature_flag_response": variant,
                    "$feature_flag": feature_flag.key,
                },
            )
            for amount in amounts:
                _create_event(
                    team=self.team,
                    event="purchase",
                    distinct_id=distinct_id,
                    timestamp="2020-01-02T12:01:00Z",
                    properties={feature_flag_property: variant, "amount": amount},
                )

    @parameterized.expand(
        [
            ("direct", False),
            ("precomputed", True),
        ]
    )
    @freeze_time("2020-01-01T12:00:00Z")
    @snapshot_clickhouse_queries
    def test_threshold_sum_metric_counts_users_crossing(self, name, use_precomputation):
        self._setup_precomputation_test(use_precomputation)

        feature_flag = self.create_feature_flag()
        experiment = self.create_experiment(feature_flag=feature_flag)

        metric = ExperimentMeanMetric(
            source=EventsNode(
                event="purchase",
                math=ExperimentMetricMathType.SUM,
                math_property="amount",
            ),
            threshold=100,
        )

        experiment_query = ExperimentQuery(
            experiment_id=experiment.id,
            kind="ExperimentQuery",
            metric=metric,
        )

        experiment.metrics = [metric.model_dump(mode="json")]
        self._save_experiment_with_precomputation(experiment, use_precomputation)

        # Control: 4 users cross (sum 120), 6 do not (sum 50)
        self._create_threshold_users(
            feature_flag,
            "control",
            [[60, 60]] * 4 + [[50]] * 6,
        )
        # Test: 7 users cross (sum 120), 3 do not (sum 50)
        self._create_threshold_users(
            feature_flag,
            "test",
            [[60, 60]] * 7 + [[50]] * 3,
        )

        flush_persons_and_events()

        query_runner = ExperimentQueryRunner(query=experiment_query, team=self.team)
        result = cast(ExperimentQueryResponse, query_runner.calculate())

        assert result.baseline is not None
        assert result.variant_results is not None
        self.assertEqual(len(result.variant_results), 1)

        control_variant = result.baseline
        test_variant = result.variant_results[0]

        # sum becomes the count of users whose per-user sum reached the threshold
        self.assertEqual(control_variant.sum, 4)
        self.assertEqual(test_variant.sum, 7)
        self.assertEqual(control_variant.number_of_samples, 10)
        self.assertEqual(test_variant.number_of_samples, 10)

    @freeze_time("2020-01-01T12:00:00Z")
    def test_threshold_is_inclusive_and_zero_for_users_without_events(self):
        """A user whose sum exactly equals the threshold crosses; a user with no events does not."""
        feature_flag = self.create_feature_flag()
        experiment = self.create_experiment(feature_flag=feature_flag)

        metric = ExperimentMeanMetric(
            source=EventsNode(
                event="purchase",
                math=ExperimentMetricMathType.SUM,
                math_property="amount",
            ),
            threshold=100,
        )

        experiment_query = ExperimentQuery(experiment_id=experiment.id, kind="ExperimentQuery", metric=metric)
        experiment.metrics = [metric.model_dump(mode="json")]
        experiment.save()

        # Control: 1 user exactly at threshold (crosses), 1 user with no purchases (does not cross)
        self._create_threshold_users(feature_flag, "control", [[100], []])
        # Test: 1 user just below threshold (does not cross), 1 user above (crosses)
        self._create_threshold_users(feature_flag, "test", [[99], [101]])

        flush_persons_and_events()

        query_runner = ExperimentQueryRunner(query=experiment_query, team=self.team)
        result = cast(ExperimentQueryResponse, query_runner.calculate())

        assert result.baseline is not None
        assert result.variant_results is not None

        self.assertEqual(result.baseline.sum, 1)
        self.assertEqual(result.baseline.number_of_samples, 2)
        self.assertEqual(result.variant_results[0].sum, 1)
        self.assertEqual(result.variant_results[0].number_of_samples, 2)

    @freeze_time("2020-01-01T12:00:00Z")
    def test_threshold_count_metric_counts_users_with_enough_events(self):
        """With TOTAL math the per-user value is the event count; threshold compares against it."""
        feature_flag = self.create_feature_flag()
        experiment = self.create_experiment(feature_flag=feature_flag)

        metric = ExperimentMeanMetric(
            source=EventsNode(event="purchase", math=ExperimentMetricMathType.TOTAL),
            threshold=3,
        )

        experiment_query = ExperimentQuery(experiment_id=experiment.id, kind="ExperimentQuery", metric=metric)
        experiment.metrics = [metric.model_dump(mode="json")]
        experiment.save()

        # Control: 1 user with 3 purchases (crosses), 1 user with 2 (does not)
        self._create_threshold_users(feature_flag, "control", [[1, 1, 1], [1, 1]])
        # Test: 2 users with 5 purchases each (both cross)
        self._create_threshold_users(feature_flag, "test", [[1, 1, 1, 1, 1], [1, 1, 1, 1, 1]])

        flush_persons_and_events()

        query_runner = ExperimentQueryRunner(query=experiment_query, team=self.team)
        result = cast(ExperimentQueryResponse, query_runner.calculate())

        assert result.baseline is not None
        assert result.variant_results is not None

        self.assertEqual(result.baseline.sum, 1)
        self.assertEqual(result.variant_results[0].sum, 2)
