import uuid
from datetime import UTC, datetime, timedelta
from functools import cached_property
from typing import Any, Optional

from django.db.models import Q

import structlog
import posthoganalytics
from pydantic import BaseModel
from rest_framework.exceptions import ValidationError

from posthog.schema import (
    ActionsNode,
    CachedExperimentQueryResponse,
    EventsNode,
    ExperimentActorsQuery,
    ExperimentBreakdownResult,
    ExperimentDataWarehouseNode,
    ExperimentFunnelMetric,
    ExperimentMeanMetric,
    ExperimentMetricMathType,
    ExperimentQuery,
    ExperimentQueryResponse,
    ExperimentRatioMetric,
    ExperimentRetentionMetric,
    ExperimentStatsBase,
    IntervalType,
    MultipleVariantHandling,
    PrecomputationMode,
)

from posthog.hogql import ast
from posthog.hogql.constants import HogQLGlobalSettings
from posthog.hogql.modifiers import create_default_modifiers_for_team
from posthog.hogql.query import execute_hogql_query

from posthog.clickhouse.query_tagging import Product, tag_queries, tags_context
from posthog.constants import EXPERIMENTS_RETENTION_METRIC_EVENTS_PREAGGREGATION_FEATURE_FLAG_KEY
from posthog.exceptions_capture import capture_exception
from posthog.hogql_queries.query_runner import QueryRunner
from posthog.hogql_queries.utils.query_date_range import QueryDateRange
from posthog.models.team.extensions import get_or_create_team_extension
from posthog.models.team.team import Team

from products.analytics_platform.backend.lazy_computation.lazy_computation_executor import (
    LazyComputationResult,
    LazyComputationTable,
    TtlSchedule,
    ensure_precomputed,
    parse_ttl_schedule,
)
from products.cohorts.backend.models.cohort import Cohort
from products.experiments.backend.hogql_queries import MULTIPLE_VARIANT_KEY, get_baseline_variant_key
from products.experiments.backend.hogql_queries.base_query_utils import (
    conversion_window_to_seconds,
    experiment_window,
    experiment_window_end,
    is_session_property_metric,
)
from products.experiments.backend.hogql_queries.cuped_config import get_cuped_config
from products.experiments.backend.hogql_queries.error_handling import experiment_error_handler
from products.experiments.backend.hogql_queries.experiment_metric_values import get_conversion_window_seconds
from products.experiments.backend.hogql_queries.experiment_query_builder import (
    ExperimentQueryBuilder,
    get_exposure_config_params_for_builder,
    resolve_exposure_config_for_builder,
)
from products.experiments.backend.hogql_queries.experiment_query_context import ExperimentPrecomputationContext
from products.experiments.backend.hogql_queries.exposure_query_logic import (
    get_entity_key,
    get_multiple_variant_handling_from_experiment,
    has_activation_config,
)
from products.experiments.backend.hogql_queries.utils import (
    aggregate_variants_across_breakdowns,
    get_bayesian_experiment_result,
    get_experiment_query_debug,
    get_experiment_stats_method,
    get_frequentist_experiment_result,
    get_variant_results,
    split_baseline_and_test_variants,
)
from products.experiments.backend.metric_utils import get_default_metric_title
from products.experiments.backend.models.experiment import Experiment
from products.experiments.backend.models.team_experiments_config import TeamExperimentsConfig

logger = structlog.get_logger(__name__)

# Variable TTL for experiment exposure lazy computation. Days 2-4 stay
# recomputable (18h, just under the ~24h warmer cadence) so the daily warmer
# folds in late-arriving exposure events before a window freezes. Freezing too
# early keeps a stale first_exposure_time and undercounts the metric window.
DEFAULT_EXPOSURE_TTL_SECONDS = {
    "0d": 15 * 60,  # 15 min
    "1d": 60 * 60,  # 1 hour
    "4d": 18 * 60 * 60,  # 18 hours; covers windows 2-4 days old
    "default": 60 * 24 * 60 * 60,  # 60 days - data frozen
}

# Cap on merged precompute job width. Without it, the frozen band (everything
# older than 4 days, one uniform TTL) merges into a single INSERT, so a cold or
# TTL-expired long-running experiment scans hundreds of days in one query. For
# high-volume teams that deterministically exceeds the per-query bytes-to-read
# cap or the 600s timeout and can never succeed. Seven days keeps the worst
# observed per-day scan rates comfortably under both limits, while creating far
# fewer jobs (and fewer rows per user to re-aggregate at read time) than daily
# chunks. Completed chunks persist, so a wide backfill converges across runs
# instead of failing atomically on every attempt.
PRECOMPUTE_MAX_WINDOW_DAYS = 7

# Upper bound on how far past the experiment end a metric-events build may scan.
# retention_window_end is an unrestricted user-supplied integer; without a cap, a huge
# window would stretch the precompute horizon into thousands of daily jobs before the
# executor's timeout check. Past the cap the metric falls back to the direct scan.
METRIC_EVENTS_MAX_WINDOW_EXTENSION_SECONDS = 90 * 24 * 60 * 60  # 90 days


def experiment_precompute_ttl_schedule(team_timezone: str) -> TtlSchedule:
    """The experiment TTL schedule with job width capped at PRECOMPUTE_MAX_WINDOW_DAYS."""
    return parse_ttl_schedule(
        DEFAULT_EXPOSURE_TTL_SECONDS,
        team_timezone,
        max_window_days=PRECOMPUTE_MAX_WINDOW_DAYS,
    )


# Minimum experiment runtime before auto-enabling precomputation. The
# today-window TTL (DEFAULT_EXPOSURE_TTL_SECONDS["0d"], 15 min) caches the
# entire current-day result, so for very young experiments freshly arriving
# exposures stay invisible until that TTL elapses. The gate scopes that
# trade-off to experiments where most of the data is already in past
# (frozen) windows. Bypassed by an explicit PrecomputationMode.PRECOMPUTED
# query override.
#
# Why 12h: covers the workday in which users launch experiments — that's
# when they refresh the results page most often and the 15-min cache lag
# would be most noticeable. Past that, refreshes drop off and the cost
# saving from precomputation matters more than the freshness gap. Short
# enough that experiments still hit the precomputed (fast) path on day two.
MIN_PRECOMPUTATION_DURATION_SECONDS = 12 * 60 * 60  # 12 hours

MAX_EXECUTION_TIME = 600
MAX_BYTES_BEFORE_EXTERNAL_GROUP_BY = 37 * 1024 * 1024 * 1024  # 37 GB


def experiment_has_min_runtime_for_precomputation(
    start_date: Optional[datetime],
    end_date: Optional[datetime],
) -> bool:
    """Return True when the experiment has been running for at least
    MIN_PRECOMPUTATION_DURATION_SECONDS.

    For running experiments, elapsed time is measured against now. For
    completed experiments (end_date in the past), the actual run length is
    used. A future end_date (planned end) is ignored so we don't credit
    runtime that hasn't happened yet.

    Note: this is elapsed *runtime*, a different concept from the analysis
    window. It deliberately clamps to min(now, end_date) — the opposite of
    experiment_window_end, which lets a future end_date win for the query
    window (no events exist beyond now anyway). Keep the two rules separate;
    do not fold this into the window primitive.
    """
    if start_date is None:
        return False
    now = datetime.now(UTC)
    effective_end = end_date if (end_date is not None and end_date <= now) else now
    return (effective_end - start_date).total_seconds() >= MIN_PRECOMPUTATION_DURATION_SECONDS


def _collect_cohort_ids(obj: Any) -> set[int]:
    """Cohort IDs referenced anywhere in a filter/criteria/metric JSON structure."""
    ids: set[int] = set()
    if isinstance(obj, dict):
        if obj.get("type") in ("cohort", "static-cohort", "precalculated-cohort"):
            value = obj.get("value")
            if isinstance(value, int | str):
                try:
                    ids.add(int(value))
                except ValueError:
                    pass
        for nested in obj.values():
            ids |= _collect_cohort_ids(nested)
    elif isinstance(obj, list):
        for item in obj:
            ids |= _collect_cohort_ids(item)
    return ids


def has_uncalculated_cohorts(team: Team, *filter_sources: Any) -> bool:
    """True when any cohort referenced in the given filter structures hasn't finished its
    first materialization (dynamic: no completed version; static: initial population running).

    Queries against such a cohort read its partially-inserted membership — they load fine
    but undercount, and with a skew determined by insertion order. A precompute build in
    that window freezes the torn snapshot for the frozen-band TTL (60 days), so precompute
    must be skipped until the first calculation lands. Cohorts with a completed version are
    safe even mid-recalculation: reads pin the last complete version, and cohorts recalculate
    every ~15 minutes, so gating on is_calculating would disable precompute permanently.
    """
    ids: set[int] = set()
    for source in filter_sources:
        if source is None:
            continue
        if isinstance(source, BaseModel):
            source = source.model_dump()
        ids |= _collect_cohort_ids(source)
    if not ids:
        return False
    return Cohort.objects.filter(
        Q(is_static=False, version__isnull=True) | Q(is_static=True, is_calculating=True),
        team__project_id=team.project_id,
        pk__in=ids,
        deleted=False,
    ).exists()


class ExperimentQueryRunner(QueryRunner):
    query: ExperimentQuery
    cached_response: CachedExperimentQueryResponse
    actors_query: Optional[ExperimentActorsQuery] = None

    def __init__(
        self,
        *args,
        as_of: Optional[datetime] = None,
        user_facing: bool = True,
        max_execution_time: Optional[int] = None,
        bypass_warehouse_access_control: bool = False,
        error_event_context: Optional[str] = "ui",
        **kwargs,
    ):
        super().__init__(*args, **kwargs)
        self.user_facing = user_facing
        self.max_execution_time = max_execution_time if max_execution_time is not None else MAX_EXECUTION_TIME
        self.bypass_warehouse_access_control = bypass_warehouse_access_control
        # Tags the terminal `experiment metric error` event with where the load came from. Defaults to "ui"
        # because the generic /query API path constructs runners without kwargs; internal callers that own
        # their own retries/telemetry (recalc, warming, canary, backfills) must pass None or user_facing=False
        # so the error boundary stays silent for them. See error_handling._emit_runner_terminal_error_event.
        self.error_event_context = error_event_context

        if not self.query.experiment_id:
            raise ValidationError("experiment_id is required")

        try:
            self.experiment = Experiment.objects.get(id=self.query.experiment_id, team=self.team)
        except Experiment.DoesNotExist:
            raise ValidationError(f"Experiment with id {self.query.experiment_id} not found")

        # Evaluation point for the analysis window; experiment_window_end caps it at end_date. An
        # explicit as_of is a recalc's frozen run snapshot or a timeseries backfill's per-day point.
        # The default — end_date for a stopped experiment, else now — makes a plain results query
        # cover the full [start, end_date] window (or [start, now] while running).
        self.as_of = as_of if as_of is not None else (self.experiment.end_date or datetime.now(UTC))
        self.feature_flag = self.experiment.feature_flag
        self.feature_flag_key = self.feature_flag.key_without_tombstone()
        self.group_type_index = self.feature_flag.aggregation_group_type_index
        self.entity_key = get_entity_key(self.group_type_index)

        # Holdout is intentionally not appended: holdout users were never exposed to
        # the experiment, so they don't belong in the metric scorecard.
        # self.experiment.holdout is still readable for code paths that need it
        # (e.g. the Distribution table on the Variants tab).
        excluded_variants = set(self.experiment.excluded_variants or [])
        self.variants = [
            variant["key"] for variant in self.feature_flag.variants if variant["key"] not in excluded_variants
        ]

        stats_config = self.experiment.stats_config or {}
        self.baseline_variant_key = get_baseline_variant_key(stats_config, self.variants)

        self.date_range = experiment_window(self.experiment, self.team, self.as_of)
        self.date_range_query = QueryDateRange(
            date_range=self.date_range,
            team=self.team,
            interval=IntervalType.DAY,
            now=datetime.now(),
        )
        # Check if this is a data warehouse query
        if isinstance(self.query.metric, ExperimentMeanMetric):
            self.is_data_warehouse_query = self.query.metric.source.kind == "ExperimentDataWarehouseNode"
        elif isinstance(self.query.metric, ExperimentFunnelMetric):
            # For funnel metrics, check if any step uses data warehouse
            self.is_data_warehouse_query = any(
                isinstance(step, ExperimentDataWarehouseNode) for step in self.query.metric.series
            )
        elif isinstance(self.query.metric, ExperimentRatioMetric):
            # For ratio metrics, check if either numerator or denominator uses data warehouse
            numerator_is_dw = isinstance(self.query.metric.numerator, ExperimentDataWarehouseNode)
            denominator_is_dw = isinstance(self.query.metric.denominator, ExperimentDataWarehouseNode)
            self.is_data_warehouse_query = numerator_is_dw or denominator_is_dw
        elif isinstance(self.query.metric, ExperimentRetentionMetric):
            # For retention metrics, check if either start_event or completion_event uses data warehouse
            start_is_dw = isinstance(self.query.metric.start_event, ExperimentDataWarehouseNode)
            completion_is_dw = isinstance(self.query.metric.completion_event, ExperimentDataWarehouseNode)
            self.is_data_warehouse_query = start_is_dw or completion_is_dw
        self.is_ratio_metric = isinstance(self.query.metric, ExperimentRatioMetric)

        self.stats_method = get_experiment_stats_method(self.experiment)

        self.multiple_variant_handling = get_multiple_variant_handling_from_experiment(
            self.experiment.exposure_criteria
        )

        # Just to simplify access
        self.metric = self.query.metric
        self.cuped_config = get_cuped_config(
            self.experiment.stats_config,
            self.metric,
            team_default_enabled=self._team_experiments_config.default_cuped_enabled,
            team_default_lookback_days=self._team_experiments_config.default_cuped_lookback_days,
        )

        self.clickhouse_sql: str | None = None
        self.hogql: str | None = None
        self._is_precomputed: bool = False  # exposures precompute
        self._metric_events_precomputed: bool = False

    def _get_breakdowns_for_builder(self) -> list | None:
        """Extract and validate breakdowns from metric configuration."""
        breakdown_filter = getattr(self.metric, "breakdownFilter", None)
        if not breakdown_filter:
            return None

        breakdowns = getattr(breakdown_filter, "breakdowns", None)
        if not breakdowns or len(breakdowns) == 0:
            return None

        if len(breakdowns) > 3:
            raise ValidationError("Maximum of 3 breakdowns are supported for experiment metrics")

        return breakdowns

    def _ensure_exposures_precomputed(self, builder: ExperimentQueryBuilder) -> LazyComputationResult:
        """
        Ensures lazy-computed exposure data exists for this experiment.

        Gets the exposure query from the builder and passes it to the lazy computation
        system, which will compute and store the exposure data if not already cached.

        Returns:
            LazyComputationResult with job_ids that can be used to query the data
        """
        query_string, placeholders = builder.get_exposure_query_for_precomputation()

        if not self.experiment.start_date:
            raise ValidationError("Experiment must have a start date for lazy computation")

        date_from = self.experiment.start_date
        date_to = experiment_window_end(self.experiment, self.as_of)

        return ensure_precomputed(
            team=self.team,
            insert_query=query_string,
            time_range_start=date_from,
            time_range_end=date_to,
            ttl_seconds=experiment_precompute_ttl_schedule(self.team.timezone),
            table=LazyComputationTable.EXPERIMENT_EXPOSURES_PREAGGREGATED,
            placeholders=placeholders,
            sentinel_placeholders={"experiment_date_to"},
            # High-volume teams' builds OOM even at capped window widths; spilling the
            # GROUP BY to disk degrades gracefully instead of failing the build.
            spill_to_disk=True,
        )

    def _ensure_metric_events_precomputed(self, builder: ExperimentQueryBuilder) -> LazyComputationResult:
        """
        Ensures lazy-computed metric event data exists for this experiment.

        Stores one row per matching event in the experiment_metric_events_preaggregated
        table: funnel metrics store step indicators, mean metrics the per-event value.
        """
        query_string, placeholders = builder.get_metric_events_query_for_precomputation()

        if not self.experiment.start_date:
            raise ValidationError("Experiment must have a start date for lazy computation")

        date_from = self.experiment.start_date
        date_to = experiment_window_end(self.experiment, self.as_of)

        # Extend time range past experiment end — metric events can occur after it: within
        # the conversion window, plus for retention the retention window (a completion can
        # land up to retention_window_end after a start event that itself lands up to
        # conversion_window after the last exposure).
        extension_seconds = builder.get_metric_events_window_extension_seconds()
        if extension_seconds > 0:
            date_to = date_to + timedelta(seconds=extension_seconds)

        return ensure_precomputed(
            team=self.team,
            insert_query=query_string,
            time_range_start=date_from,
            time_range_end=date_to,
            ttl_seconds=experiment_precompute_ttl_schedule(self.team.timezone),
            table=LazyComputationTable.EXPERIMENT_METRIC_EVENTS_PREAGGREGATED,
            placeholders=placeholders,
            sentinel_placeholders={"experiment_date_to"},
            spill_to_disk=True,
        )

    @cached_property
    def _team_experiments_config(self) -> TeamExperimentsConfig:
        return get_or_create_team_extension(self.team, TeamExperimentsConfig)

    def _should_precompute(self) -> bool:
        """Resolve whether to use precomputation: query-level override > team-level default + duration gate."""
        if self.query.precomputation_mode == PrecomputationMode.PRECOMPUTED:
            return True
        if self.query.precomputation_mode == PrecomputationMode.DIRECT:
            return False

        if not self._team_experiments_config.experiment_precomputation_enabled:
            return False

        if not experiment_has_min_runtime_for_precomputation(
            self.experiment.start_date,
            self.experiment.end_date,
        ):
            return False

        # Activation-mode exposures can't be cached per day: the flag→activation ordering
        # crosses bucket boundaries.
        if has_activation_config(self.experiment.exposure_criteria):
            return False

        return not has_uncalculated_cohorts(self.team, self.experiment.exposure_criteria, self.metric)

    def _precompute_skip_reason(self) -> Optional[str]:
        """Why precompute was not used, for the query-performance UI. None when it was attempted."""
        if self.query.precomputation_mode == PrecomputationMode.PRECOMPUTED:
            return None
        if self.query.precomputation_mode == PrecomputationMode.DIRECT:
            return "override_direct"
        if not self._team_experiments_config.experiment_precomputation_enabled:
            return "team_disabled"
        if not experiment_has_min_runtime_for_precomputation(
            self.experiment.start_date,
            self.experiment.end_date,
        ):
            return "min_runtime"
        if has_activation_config(self.experiment.exposure_criteria):
            return "activation_config"
        if has_uncalculated_cohorts(self.team, self.experiment.exposure_criteria, self.metric):
            return "cohort_not_calculated"
        if self.is_data_warehouse_query:
            return "data_warehouse"
        if self.group_type_index is not None:
            return "group_aggregation"
        return None  # precompute was attempted; a direct path means the build failed / wasn't ready

    def _retention_metric_events_precomputation_enabled(self) -> bool:
        """Kill switch for retention metric-events pre-aggregation, independent of funnel/mean.

        Default-off and fail-safe: returns False unless the flag is explicitly enabled, so a
        flag-eval failure (or the flag not existing yet) leaves retention metric events on the
        direct-scan path while funnel/mean metric events and exposures keep using their
        precomputed tables.
        """
        return bool(
            posthoganalytics.feature_enabled(
                EXPERIMENTS_RETENTION_METRIC_EVENTS_PREAGGREGATION_FEATURE_FLAG_KEY,
                str(self.team.uuid),
                groups={"organization": str(self.team.organization_id), "project": str(self.team.id)},
                group_properties={
                    "organization": {"id": str(self.team.organization_id)},
                    "project": {"id": str(self.team.id), "uuid": str(self.team.uuid)},
                },
                only_evaluate_locally=True,
                send_feature_flag_events=False,
            )
        )

    def _metric_events_precompute_applicable(self) -> bool:
        """
        Metric-events precompute supports ordered funnels, count/sum-style mean
        metrics, and retention metrics, in all cases without breakdowns, CUPED,
        or data warehouse sources.
        """
        if self._get_breakdowns_for_builder() or self.cuped_config.enabled or self.is_data_warehouse_query:
            return False
        if isinstance(self.metric, ExperimentFunnelMetric):
            return (self.metric.funnel_order_type or "ordered") == "ordered"
        if isinstance(self.metric, ExperimentMeanMetric):
            source = self.metric.source
            if not isinstance(source, (EventsNode, ActionsNode)):
                return False
            # Session-property means aggregate via a per-session dedup CTE that the
            # precomputed table can't feed; ID-valued math (unique session/DAU/group)
            # and HogQL expressions don't fit the Float64 numeric_value column.
            if is_session_property_metric(source):
                return False
            math_type = getattr(source, "math", None) or ExperimentMetricMathType.TOTAL
            return math_type in (ExperimentMetricMathType.TOTAL, ExperimentMetricMathType.SUM)
        if isinstance(self.metric, ExperimentRetentionMetric):
            if not isinstance(self.metric.start_event, (EventsNode, ActionsNode)) or not isinstance(
                self.metric.completion_event, (EventsNode, ActionsNode)
            ):
                return False
            extension_seconds = get_conversion_window_seconds(self.metric) + conversion_window_to_seconds(
                self.metric.retention_window_end, self.metric.retention_window_unit
            )
            if extension_seconds > METRIC_EVENTS_MAX_WINDOW_EXTENSION_SECONDS:
                return False
            return self._retention_metric_events_precomputation_enabled()
        return False

    def _get_experiment_query(self) -> ast.SelectQuery:
        """
        Returns the main experiment query.
        """
        assert isinstance(
            self.metric,
            ExperimentFunnelMetric | ExperimentMeanMetric | ExperimentRatioMetric | ExperimentRetentionMetric,
        )

        # Get the "missing" (not directly accessible) parameters required for the builder
        exposure_params = get_exposure_config_params_for_builder(
            self.experiment.exposure_criteria, self.team, self.experiment.start_date
        )

        builder = ExperimentQueryBuilder(
            team=self.team,
            feature_flag_key=self.feature_flag_key,
            exposure_config=exposure_params.exposure_config,
            filter_test_accounts=exposure_params.filter_test_accounts,
            multiple_variant_handling=exposure_params.multiple_variant_handling,
            variants=self.variants,
            date_range_query=self.date_range_query,
            entity_key=self.entity_key,
            metric=self.metric,
            breakdowns=self._get_breakdowns_for_builder(),
            only_count_matured_users=self.experiment.only_count_matured_users,
            cuped_config=self.cuped_config,
            activation_config=exposure_params.activation_config,
        )

        should_precompute = self._should_precompute()

        exposure_job_ids: list[str] | None = None
        metric_events_job_ids: list[str] | None = None

        # Skip precomputation for data warehouse metrics because the precomputed table
        # doesn't include the join keys needed to link exposures to data warehouse tables.
        # Group-aggregated experiments are excluded too: their build INSERT references
        # $group_N, which the INSERT ... SELECT analysis path can't resolve (MATERIALIZED
        # on sharded_events), so every build fails with UNKNOWN_IDENTIFIER.
        if should_precompute and not self.is_data_warehouse_query and self.group_type_index is None:
            try:
                with tags_context(experiment_query_surface="precompute_build", experiment_precompute_table="exposures"):
                    result = self._ensure_exposures_precomputed(builder)
                if result.ready:
                    exposure_job_ids = [str(job_id) for job_id in result.job_ids]
                    self._is_precomputed = True
                else:
                    logger.warning("exposure_lazy_computation_not_ready", experiment_id=self.experiment.id)
            except Exception as e:
                # Swallowed: the direct-scan fallback below still returns results, which would
                # otherwise hide a broken precomputation path. Report so it isn't silent.
                capture_exception(
                    e,
                    additional_properties={
                        "tag": "exposure_lazy_computation_failed",
                        "experiment_id": self.experiment.id,
                        "precomputation_path": "exposure",
                        "metric_type": self.metric.metric_type,
                    },
                )

            # Precompute metric events for eligible metrics (ordered funnels, count/sum
            # means). CUPED extends the metric scan back by `lookback_days` to source the
            # pre-exposure covariate; the precomputed metric_events table only covers the
            # experiment window, so skip precomputation here and let the builder issue a
            # fresh scan.
            if self._metric_events_precompute_applicable():
                try:
                    with tags_context(
                        experiment_query_surface="precompute_build", experiment_precompute_table="metric_events"
                    ):
                        metric_result = self._ensure_metric_events_precomputed(builder)
                    if metric_result.ready:
                        metric_events_job_ids = [str(job_id) for job_id in metric_result.job_ids]
                        self._metric_events_precomputed = True
                    else:
                        logger.warning("metric_events_lazy_computation_not_ready", experiment_id=self.experiment.id)
                except Exception as e:
                    capture_exception(
                        e,
                        additional_properties={
                            "tag": "metric_events_lazy_computation_failed",
                            "experiment_id": self.experiment.id,
                            "precomputation_path": "metric_events",
                            "metric_type": self.metric.metric_type,
                        },
                    )

        return builder.build_query(
            precomputation_context=ExperimentPrecomputationContext(
                exposure_job_ids=exposure_job_ids,
                metric_events_job_ids=metric_events_job_ids,
            )
        )

    def _evaluate_experiment_query(
        self,
    ) -> tuple[list[tuple], list[str]]:
        # Adding experiment specific tags to the tag collection
        # This will be available as labels in Prometheus
        metric_name = self.metric.name or get_default_metric_title(self.metric.model_dump())
        tag_queries(
            product=Product.EXPERIMENTS,
            experiment_query_surface="metric",
            # Generated before _get_experiment_query() runs the precompute builds, so those build
            # sub-queries inherit this id via the tag context and can be grouped under this read.
            experiment_query_group_id=uuid.uuid4(),
            experiment_id=self.experiment.id,
            experiment_name=self.experiment.name,
            experiment_feature_flag_key=self.feature_flag_key,
            experiment_is_data_warehouse_query=self.is_data_warehouse_query,
            experiment_metric_uuid=self.metric.uuid,
            experiment_metric_name=metric_name,
            experiment_metric_type=self.metric.metric_type,
        )
        if isinstance(self.metric, ExperimentFunnelMetric):
            tag_queries(experiment_funnel_order_type=self.metric.funnel_order_type or "ordered")

        experiment_query_ast = self._get_experiment_query()

        # Tag after _get_experiment_query() which sets the precompute flags
        exposures_path = "precomputed" if self._is_precomputed else "direct_scan"
        if not self._metric_events_precompute_applicable():
            metric_events_path = "not_applicable"
        else:
            metric_events_path = "precomputed" if self._metric_events_precomputed else "direct_scan"
        tag_queries(
            experiment_exposures_path=exposures_path,
            experiment_metric_events_path=metric_events_path,
            experiment_execution_path=exposures_path,
            experiment_precompute_skip_reason=self._precompute_skip_reason(),
            experiment_scan_date_from=self.date_range.date_from,
            experiment_scan_date_to=self.date_range.date_to,
        )
        experiment_query_debug = get_experiment_query_debug(
            experiment_query_ast,
            self.team,
            user=self.user,
            bypass_warehouse_access_control=self.bypass_warehouse_access_control,
        )
        self.hogql = experiment_query_debug[0]
        self.clickhouse_sql = experiment_query_debug[1]

        modifiers = create_default_modifiers_for_team(self.team)
        if posthoganalytics.feature_enabled(
            "hogql-session-id-pushdown",
            str(self.team.id),
            groups={"project": str(self.team.id)},
            group_properties={"project": {"id": str(self.team.id)}},
            only_evaluate_locally=True,
            send_feature_flag_events=False,
        ):
            modifiers.sessionIdPushdown = True

        settings = HogQLGlobalSettings(
            max_execution_time=self.max_execution_time,
            max_bytes_before_external_group_by=MAX_BYTES_BEFORE_EXTERNAL_GROUP_BY,
        )
        # Mean metric queries join exposures with a potentially large metric-events table and
        # can exceed memory with the default hash join. grace_hash spills to disk when needed.
        if isinstance(self.metric, ExperimentMeanMetric):
            settings.join_algorithm = "grace_hash"
            settings.grace_hash_join_initial_buckets = 2

        response = execute_hogql_query(
            query_type="ExperimentQuery",
            query=experiment_query_ast,
            team=self.team,
            user=self.user,
            bypass_warehouse_access_control=self.bypass_warehouse_access_control,
            timings=self.timings,
            modifiers=modifiers,
            settings=settings,
            workload=self.workload,
        )

        # Remove the $multiple variant only when using exclude handling
        if self.multiple_variant_handling == MultipleVariantHandling.EXCLUDE:
            response.results = [result for result in response.results if result[0] != MULTIPLE_VARIANT_KEY]

        sorted_results = sorted(response.results, key=lambda x: self.variants.index(x[0]))

        return sorted_results, response.columns or []

    @experiment_error_handler
    def _calculate(self) -> ExperimentQueryResponse:
        # Prepare variant data
        variant_results = self._prepare_variant_results()

        # Process breakdowns or extract variants
        if self._has_breakdown(variant_results):
            breakdown_results, variants = self._process_breakdown_results(variant_results)
        else:
            breakdown_results = None
            variants = [v for _, v in variant_results]

        # Calculate final statistics
        result = self._calculate_statistics_for_variants(variants)

        # Attach breakdown data if present
        if breakdown_results is not None:
            result.breakdown_results = breakdown_results

        result.clickhouse_sql = self.clickhouse_sql
        result.hogql = self.hogql
        result.is_precomputed = self._is_precomputed

        return result

    def _prepare_variant_results(self) -> list[tuple[tuple[str, ...] | None, ExperimentStatsBase]]:
        """Fetch and prepare variant results with missing variants added."""
        sorted_results, columns = self._evaluate_experiment_query()
        variant_results = get_variant_results(sorted_results, columns)
        return self._add_missing_variants(variant_results)

    def _has_breakdown(self, variant_results: list[tuple[tuple[str, ...] | None, ExperimentStatsBase]]) -> bool:
        """Check if results contain breakdown data."""
        return any(bv is not None for bv, _ in variant_results)

    def _calculate_statistics_for_variants(self, variants: list[ExperimentStatsBase]) -> ExperimentQueryResponse:
        """Calculate statistical analysis results for a set of variants."""
        control_variant, test_variants = split_baseline_and_test_variants(variants, self.baseline_variant_key)

        if self.stats_method == "frequentist":
            return get_frequentist_experiment_result(
                metric=self.metric,
                control_variant=control_variant,
                test_variants=test_variants,
                stats_config=self.experiment.stats_config,
                cuped_config=self.cuped_config,
                team_default_sequential_testing_enabled=self._team_experiments_config.default_sequential_testing_enabled,
                team_default_sequential_tuning_parameter=self._team_experiments_config.default_sequential_tuning_parameter,
            )

        return get_bayesian_experiment_result(
            metric=self.metric,
            control_variant=control_variant,
            test_variants=test_variants,
            stats_config=self.experiment.stats_config,
            cuped_config=self.cuped_config,
        )

    def _process_breakdown_results(
        self, variant_results: list[tuple[tuple[str, ...] | None, ExperimentStatsBase]]
    ) -> tuple[list[ExperimentBreakdownResult], list[ExperimentStatsBase]]:
        """Compute per-breakdown statistics and aggregate across breakdowns."""
        breakdown_tuples = sorted({bv for bv, _ in variant_results if bv is not None})

        breakdown_results = [
            self._compute_breakdown_statistics(breakdown_tuple, variant_results) for breakdown_tuple in breakdown_tuples
        ]

        aggregated_variants = aggregate_variants_across_breakdowns(variant_results)

        return breakdown_results, aggregated_variants

    def _compute_breakdown_statistics(
        self,
        breakdown_tuple: tuple[str, ...],
        variant_results: list[tuple[tuple[str, ...] | None, ExperimentStatsBase]],
    ) -> ExperimentBreakdownResult:
        """Compute statistics for a single breakdown combination."""
        breakdown_variants = [v for bv, v in variant_results if bv == breakdown_tuple]

        # Ensure all expected variants are present in this breakdown group
        # Some breakdown groups may not have data for all variants (e.g., no control users with specific browser)
        variants_present = {v.key for v in breakdown_variants}
        for expected_variant in self.variants:
            if expected_variant not in variants_present:
                # Add missing variant with zero stats to avoid "No control variant found" error
                breakdown_variants.append(
                    ExperimentStatsBase(
                        key=expected_variant,
                        number_of_samples=0,
                        sum=0,
                        sum_squares=0,
                    )
                )

        stats = self._calculate_statistics_for_variants(breakdown_variants)

        return ExperimentBreakdownResult(
            breakdown_value=list(breakdown_tuple),
            baseline=stats.baseline,
            variants=stats.variant_results,
        )

    def _add_missing_variants(
        self, variants: list[tuple[tuple[str, ...] | None, ExperimentStatsBase]]
    ) -> list[tuple[tuple[str, ...] | None, ExperimentStatsBase]]:
        """
        Check if the variants configured in the experiment is seen in the collected data.
        If not, add them to the result set with values set to 0.
        Preserves the tuple structure with breakdown values.
        """
        variants_seen = [v.key for _, v in variants]

        # Fan out over the breakdown combinations actually present in the results, not over the
        # metric's breakdown config: a metric can declare breakdowns and still come back with no
        # rows at all (no data yet), and there is then nothing to fan out over — fall back to the
        # single breakdown-less zero row so the baseline variant still exists.
        breakdown_tuples = {bv for bv, _ in variants if bv is not None}

        # Type annotation required for empty list so mypy knows the expected element type:
        # list of tuples containing (breakdown_values, stats) where breakdown_values can be None
        variants_missing: list[tuple[tuple[str, ...] | None, ExperimentStatsBase]] = []
        for key in self.variants:
            if key not in variants_seen:
                if breakdown_tuples:
                    # Use extend to add MULTIPLE tuples - one for each breakdown combination
                    # Each missing variant needs to appear across ALL breakdown values to maintain consistency
                    variants_missing.extend(
                        [
                            (bv, ExperimentStatsBase(key=key, number_of_samples=0, sum=0, sum_squares=0))
                            for bv in breakdown_tuples
                        ]
                    )
                else:
                    # Use append to add a SINGLE tuple with None as the breakdown value
                    # Without breakdowns, we only need one entry per missing variant
                    variants_missing.append(
                        (None, ExperimentStatsBase(key=key, number_of_samples=0, sum=0, sum_squares=0))
                    )

        return variants + variants_missing

    def to_actors_query(self) -> ast.SelectQuery:
        """
        Generate actors query for experiment funnels with exposure filtering.

        This method builds an actors query that applies the SAME temporal filtering
        as the main experiment query by including exposure as step 0.

        Key differences from main query:
        - Returns individual users instead of aggregate statistics
        - Filters to specific step and variant
        - Includes matched recordings when requested

        The query structure mirrors the main experiment query:
        - Step 0: Exposure event (filters events to only those AFTER exposure)
        - Step 1-N: Metric events from funnel.series

        This ensures counts match between funnel visualization and PersonModal.
        """
        # Ensure actors_query is set
        if self.actors_query is None:
            raise ValidationError("actors_query must be set before calling to_actors_query()")

        # Only support funnel metrics for now
        if not isinstance(self.metric, ExperimentFunnelMetric):
            raise ValidationError("Actors query only supported for funnel experiment metrics")

        # Validate funnelStep
        funnel_step = self.actors_query.funnelStep
        if funnel_step is None:
            raise ValidationError("funnelStep is required for experiment actors query")

        num_metric_steps = len(self.metric.series)

        # funnelStep=-1 is a valid drop-off: "exposed but never reached the first metric step".
        # step_reached is 0-indexed with exposure as step 0, so the WHERE clause resolves it to
        # step_reached == 0 — the exposed users who did not validly enter the funnel.
        if funnel_step < 0:
            max_drop_off = -(num_metric_steps + 1)
            if funnel_step < max_drop_off:
                raise ValidationError(
                    f"Invalid drop-off step {funnel_step} for experiment with {num_metric_steps} metric steps. "
                    f"Valid drop-off steps: -1 (exposed, did not reach first metric step) to {max_drop_off}."
                )

        if funnel_step > num_metric_steps:
            raise ValidationError(
                f"Invalid conversion step {funnel_step} for experiment with {num_metric_steps} metric steps. "
                f"Valid conversion steps: 0 (exposure step) to {num_metric_steps}."
            )

        # Extract exposure configuration from actors query
        # Fall back to experiment exposure_criteria if not provided
        from posthog.schema import ActionsNode, ExperimentEventExposureConfig

        exposure_config: ExperimentEventExposureConfig | ActionsNode
        activation_config: ExperimentEventExposureConfig | ActionsNode | None = None
        if self.actors_query.exposureConfig is not None:
            # An explicit override replaces the whole exposure definition, including any
            # stored activation event.
            exposure_config = resolve_exposure_config_for_builder(
                self.actors_query.exposureConfig, self.team, self.experiment.start_date
            )
        else:
            # Same resolution as the main experiment query, so the actor list matches the counts.
            exposure_params = get_exposure_config_params_for_builder(
                self.experiment.exposure_criteria, self.team, self.experiment.start_date
            )
            exposure_config = exposure_params.exposure_config
            activation_config = exposure_params.activation_config

        # Get multiple variant handling
        if self.actors_query.multipleVariantHandling is not None:
            multiple_variant_handling = self.actors_query.multipleVariantHandling
        else:
            multiple_variant_handling = self.multiple_variant_handling

        # Get feature flag key
        if self.actors_query.featureFlagKey:
            feature_flag_key = self.actors_query.featureFlagKey
        else:
            feature_flag_key = self.feature_flag_key

        # Import builder here to avoid circular dependencies
        from products.experiments.backend.hogql_queries.experiment_funnel_actors_query_builder import (
            ExperimentFunnelActorsQueryBuilder,
        )

        # Extract funnel_step_breakdown and ensure it's a simple type
        funnel_step_breakdown_raw = self.actors_query.funnelStepBreakdown
        if funnel_step_breakdown_raw is None:
            funnel_step_breakdown: str | int | float = ""
        elif isinstance(funnel_step_breakdown_raw, list):
            # If it's a list, take the first element
            funnel_step_breakdown = funnel_step_breakdown_raw[0] if funnel_step_breakdown_raw else ""
        else:
            funnel_step_breakdown = funnel_step_breakdown_raw

        # Add experiment-specific tags for monitoring and alerting
        metric_name = self.metric.name or get_default_metric_title(self.metric.model_dump())
        tag_queries(
            product=Product.EXPERIMENTS,
            experiment_query_surface="actors",
            # No sub-queries here, but tag for a consistent group id per top-level query.
            experiment_query_group_id=uuid.uuid4(),
            experiment_exposures_path="direct_scan",
            experiment_metric_events_path="not_applicable",
            experiment_id=self.experiment.id,
            experiment_name=self.experiment.name,
            experiment_feature_flag_key=feature_flag_key,
            experiment_metric_uuid=self.metric.uuid,
            experiment_metric_name=metric_name,
            experiment_actors_query_step=funnel_step,
            experiment_actors_query_variant=str(funnel_step_breakdown) if funnel_step_breakdown else "",
            experiment_actors_query_includes_recordings=self.actors_query.includeRecordings or False,
        )

        # Build the actors query using the same infrastructure as main query
        builder = ExperimentFunnelActorsQueryBuilder(
            team=self.team,
            feature_flag_key=feature_flag_key,
            exposure_config=exposure_config,
            filter_test_accounts=self.experiment.exposure_criteria.get("filterTestAccounts", True)
            if self.experiment.exposure_criteria
            else False,
            multiple_variant_handling=multiple_variant_handling,
            variants=self.variants,
            date_range_query=self.date_range_query,
            entity_key=self.entity_key,
            metric=self.metric,
            funnel_step=funnel_step,
            funnel_step_breakdown=funnel_step_breakdown,
            include_recordings=self.actors_query.includeRecordings or False,
            activation_config=activation_config,
        )

        # Step 0 is the exposure step: return everyone exposed to the variant,
        # without funnel evaluation.
        if funnel_step == 0:
            return builder.build_exposure_actors_query()

        return builder.build_actors_query()

    def to_query(self) -> ast.SelectQuery:
        raise ValidationError(f"Cannot convert source query of type {self.query.metric.kind} to query")

    # Cache results for 24 hours
    def cache_target_age(self, last_refresh: Optional[datetime], lazy: bool = False) -> Optional[datetime]:
        if last_refresh is None:
            return None
        return last_refresh + timedelta(hours=24)

    def get_cache_payload(self) -> dict:
        payload = super().get_cache_payload()
        payload["experiment_response_version"] = 2
        payload["stats_method"] = self.stats_method
        return payload

    def _is_stale(self, last_refresh: Optional[datetime], lazy: bool = False) -> bool:
        if not last_refresh:
            return True
        return (datetime.now(UTC) - last_refresh) > timedelta(hours=24)
