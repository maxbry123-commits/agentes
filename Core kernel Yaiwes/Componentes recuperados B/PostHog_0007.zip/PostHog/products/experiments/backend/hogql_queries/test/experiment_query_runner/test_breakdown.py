from typing import cast

from freezegun import freeze_time
from posthog.test.base import _create_event, _create_person, flush_persons_and_events, snapshot_clickhouse_queries

from django.test import override_settings

from parameterized import parameterized

from posthog.schema import (
    Breakdown,
    BreakdownFilter,
    EventsNode,
    ExperimentFunnelMetric,
    ExperimentMeanMetric,
    ExperimentMetricMathType,
    ExperimentQuery,
    ExperimentQueryResponse,
    ExperimentRatioMetric,
    ExperimentRetentionMetric,
    FunnelConversionWindowTimeUnit,
    StartHandling,
    StepOrderValue,
)

from posthog.hogql_queries.utils.breakdowns import BREAKDOWN_NULL_STRING_LABEL

from products.experiments.backend.hogql_queries.experiment_query_runner import ExperimentQueryRunner
from products.experiments.backend.hogql_queries.test.experiment_query_runner.base import ExperimentQueryRunnerBaseTest


@override_settings(IN_UNIT_TESTING=True)
class TestExperimentBreakdown(ExperimentQueryRunnerBaseTest):
    @freeze_time("2020-01-01T12:00:00Z")
    @snapshot_clickhouse_queries
    def test_mean_metric_with_breakdown(self):
        feature_flag = self.create_feature_flag()
        experiment = self.create_experiment(feature_flag=feature_flag)
        experiment.stats_config = {"method": "frequentist"}
        experiment.save()

        metric = ExperimentMeanMetric(
            source=EventsNode(
                event="purchase",
                math=ExperimentMetricMathType.SUM,
                math_property="amount",
            ),
            breakdownFilter=BreakdownFilter(breakdowns=[Breakdown(property="$browser")]),
        )

        experiment_query = ExperimentQuery(
            experiment_id=experiment.id,
            kind="ExperimentQuery",
            metric=metric,
        )

        experiment.metrics = [metric.model_dump(mode="json")]
        experiment.save()

        feature_flag_property = f"$feature/{feature_flag.key}"

        # Control group - 2 users x 2 browsers
        for i in range(4):
            browser = "Chrome" if i < 2 else "Safari"
            _create_person(distinct_ids=[f"user_control_{i}"], team_id=self.team.pk)
            _create_event(
                team=self.team,
                event="$feature_flag_called",
                distinct_id=f"user_control_{i}",
                timestamp="2020-01-02T12:00:00Z",
                properties={
                    feature_flag_property: "control",
                    "$feature_flag_response": "control",
                    "$feature_flag": feature_flag.key,
                    "$browser": browser,
                },
            )
            _create_event(
                team=self.team,
                event="purchase",
                distinct_id=f"user_control_{i}",
                timestamp="2020-01-02T12:01:00Z",
                properties={
                    feature_flag_property: "control",
                    "amount": 10 if browser == "Chrome" else 20,
                    "$browser": browser,
                },
            )

        # Test group - 2 users x 2 browsers
        for i in range(4):
            browser = "Chrome" if i < 2 else "Safari"
            _create_person(distinct_ids=[f"user_test_{i}"], team_id=self.team.pk)
            _create_event(
                team=self.team,
                event="$feature_flag_called",
                distinct_id=f"user_test_{i}",
                timestamp="2020-01-02T12:00:00Z",
                properties={
                    feature_flag_property: "test",
                    "$feature_flag_response": "test",
                    "$feature_flag": feature_flag.key,
                    "$browser": browser,
                },
            )
            _create_event(
                team=self.team,
                event="purchase",
                distinct_id=f"user_test_{i}",
                timestamp="2020-01-02T12:01:00Z",
                properties={
                    feature_flag_property: "test",
                    "amount": 15 if browser == "Chrome" else 25,
                    "$browser": browser,
                },
            )

        flush_persons_and_events()

        query_runner = ExperimentQueryRunner(query=experiment_query, team=self.team)
        result = cast(ExperimentQueryResponse, query_runner.calculate())

        # Verify results are grouped by breakdown
        # We should get results for each variant x breakdown combination
        self.assertIsNotNone(result.baseline)
        self.assertIsNotNone(result.variant_results)

        # Verify breakdown_results is populated with per-breakdown statistics
        self.assertIsNotNone(result.breakdown_results)
        assert result.breakdown_results is not None
        self.assertEqual(len(result.breakdown_results), 2)

        # Verify each breakdown has correct structure (breakdown_value is now a list)
        for breakdown_result in result.breakdown_results:
            self.assertIn(breakdown_result.breakdown_value, [["Chrome"], ["Safari"]])
            self.assertIsNotNone(breakdown_result.baseline)
            self.assertIsNotNone(breakdown_result.variants)
            self.assertGreater(len(breakdown_result.variants), 0)

            # Verify each variant has statistical comparisons
            for variant in breakdown_result.variants:
                self.assertIsNotNone(variant.key)
                self.assertIsNotNone(variant.number_of_samples)

    @parameterized.expand([("new_query_builder", True)])
    @freeze_time("2020-01-01T12:00:00Z")
    @snapshot_clickhouse_queries
    def test_mean_metric_breakdown_with_changing_property_values(self, name, use_new_query_builder):
        """
        Regression test for bug where users with different breakdown values across exposures
        were counted multiple times (once per unique breakdown value).

        Tests that users with multiple exposure events having different breakdown property
        values are attributed to the breakdown value from their FIRST exposure only.
        """
        feature_flag = self.create_feature_flag()
        experiment = self.create_experiment(feature_flag=feature_flag)
        experiment.stats_config = {"method": "frequentist", "use_new_query_builder": use_new_query_builder}
        experiment.save()

        metric = ExperimentMeanMetric(
            source=EventsNode(
                event="purchase",
                math=ExperimentMetricMathType.SUM,
                math_property="amount",
            ),
            breakdownFilter=BreakdownFilter(breakdowns=[Breakdown(property="$browser")]),
        )

        experiment_query = ExperimentQuery(
            experiment_id=experiment.id,
            kind="ExperimentQuery",
            metric=metric,
        )

        experiment.metrics = [metric.model_dump(mode="json")]
        experiment.save()

        feature_flag_property = f"$feature/{feature_flag.key}"

        # Control user who changes browser between exposures
        _create_person(distinct_ids=["user_control_changing"], team_id=self.team.pk)

        # First exposure with Chrome at 12:00
        _create_event(
            team=self.team,
            event="$feature_flag_called",
            distinct_id="user_control_changing",
            timestamp="2020-01-02T12:00:00Z",
            properties={
                feature_flag_property: "control",
                "$feature_flag_response": "control",
                "$feature_flag": feature_flag.key,
                "$browser": "Chrome",
            },
        )

        # Second exposure with Safari at 13:00 (user switched browser)
        _create_event(
            team=self.team,
            event="$feature_flag_called",
            distinct_id="user_control_changing",
            timestamp="2020-01-02T13:00:00Z",
            properties={
                feature_flag_property: "control",
                "$feature_flag_response": "control",
                "$feature_flag": feature_flag.key,
                "$browser": "Safari",
            },
        )

        # Purchase event at 14:00
        _create_event(
            team=self.team,
            event="purchase",
            distinct_id="user_control_changing",
            timestamp="2020-01-02T14:00:00Z",
            properties={
                feature_flag_property: "control",
                "amount": 100,
                "$browser": "Safari",
            },
        )

        # Control user with consistent browser
        _create_person(distinct_ids=["user_control_consistent"], team_id=self.team.pk)

        _create_event(
            team=self.team,
            event="$feature_flag_called",
            distinct_id="user_control_consistent",
            timestamp="2020-01-02T12:00:00Z",
            properties={
                feature_flag_property: "control",
                "$feature_flag_response": "control",
                "$feature_flag": feature_flag.key,
                "$browser": "Firefox",
            },
        )

        _create_event(
            team=self.team,
            event="purchase",
            distinct_id="user_control_consistent",
            timestamp="2020-01-02T14:00:00Z",
            properties={
                feature_flag_property: "control",
                "amount": 50,
                "$browser": "Firefox",
            },
        )

        flush_persons_and_events()

        query_runner = ExperimentQueryRunner(query=experiment_query, team=self.team)
        result = cast(ExperimentQueryResponse, query_runner.calculate())

        # Verify results
        self.assertIsNotNone(result.breakdown_results)
        assert result.breakdown_results is not None

        # Should have 2 breakdown categories (Chrome and Firefox)
        # NOT 3 (Chrome, Safari, Firefox) even though changing user had Safari exposure
        # The user should be attributed to Chrome (first exposure)
        self.assertEqual(len(result.breakdown_results), 2)

        breakdown_values = [br.breakdown_value for br in result.breakdown_results]
        self.assertIn(["Chrome"], breakdown_values)
        self.assertIn(["Firefox"], breakdown_values)
        # Safari should NOT appear as a breakdown
        self.assertNotIn(["Safari"], breakdown_values)

        # Find Chrome breakdown (has the changing user)
        chrome_breakdown = next(br for br in result.breakdown_results if br.breakdown_value == ["Chrome"])
        self.assertIsNotNone(chrome_breakdown.baseline)

        # Should have exactly 1 user in Chrome (the changing user, attributed to first exposure)
        self.assertEqual(chrome_breakdown.baseline.number_of_samples, 1)
        self.assertEqual(chrome_breakdown.baseline.sum, 100)  # Their purchase amount

        # Find Firefox breakdown (has the consistent user)
        firefox_breakdown = next(br for br in result.breakdown_results if br.breakdown_value == ["Firefox"])
        self.assertEqual(firefox_breakdown.baseline.number_of_samples, 1)
        self.assertEqual(firefox_breakdown.baseline.sum, 50)

    @parameterized.expand([("new_query_builder", True)])
    @freeze_time("2020-01-01T12:00:00Z")
    @snapshot_clickhouse_queries
    def test_funnel_metric_with_breakdown(self, name, use_new_query_builder):
        feature_flag = self.create_feature_flag()
        experiment = self.create_experiment(feature_flag=feature_flag)
        experiment.stats_config = {"method": "frequentist"}
        experiment.save()

        metric = ExperimentFunnelMetric(
            series=[
                EventsNode(event="purchase"),
            ],
            breakdownFilter=BreakdownFilter(breakdowns=[Breakdown(property="$browser")]),
        )

        experiment_query = ExperimentQuery(
            experiment_id=experiment.id,
            kind="ExperimentQuery",
            metric=metric,
        )

        experiment.metrics = [metric.model_dump(mode="json")]
        experiment.save()

        feature_flag_property = f"$feature/{feature_flag.key}"

        # Control group - Chrome users complete funnel, Safari users don't
        for i in range(6):
            browser = "Chrome" if i < 3 else "Safari"
            completes_funnel = browser == "Chrome"
            _create_person(distinct_ids=[f"user_control_{i}"], team_id=self.team.pk)
            _create_event(
                team=self.team,
                event="$feature_flag_called",
                distinct_id=f"user_control_{i}",
                timestamp="2020-01-02T12:00:00Z",
                properties={
                    feature_flag_property: "control",
                    "$feature_flag_response": "control",
                    "$feature_flag": feature_flag.key,
                    "$browser": browser,
                },
            )
            if completes_funnel:
                _create_event(
                    team=self.team,
                    event="purchase",
                    distinct_id=f"user_control_{i}",
                    timestamp="2020-01-02T12:01:00Z",
                    properties={
                        feature_flag_property: "control",
                        "$browser": browser,
                    },
                )

        # Test group - Safari users complete funnel, Chrome users don't
        for i in range(6):
            browser = "Chrome" if i < 3 else "Safari"
            completes_funnel = browser == "Safari"
            _create_person(distinct_ids=[f"user_test_{i}"], team_id=self.team.pk)
            _create_event(
                team=self.team,
                event="$feature_flag_called",
                distinct_id=f"user_test_{i}",
                timestamp="2020-01-02T12:00:00Z",
                properties={
                    feature_flag_property: "test",
                    "$feature_flag_response": "test",
                    "$feature_flag": feature_flag.key,
                    "$browser": browser,
                },
            )
            if completes_funnel:
                _create_event(
                    team=self.team,
                    event="purchase",
                    distinct_id=f"user_test_{i}",
                    timestamp="2020-01-02T12:01:00Z",
                    properties={
                        feature_flag_property: "test",
                        "$browser": browser,
                    },
                )

        flush_persons_and_events()

        query_runner = ExperimentQueryRunner(query=experiment_query, team=self.team)
        result = cast(ExperimentQueryResponse, query_runner.calculate())

        self.assertIsNotNone(result.baseline)
        self.assertIsNotNone(result.variant_results)

        # Verify breakdown_results is populated with per-breakdown statistics
        self.assertIsNotNone(result.breakdown_results)
        assert result.breakdown_results is not None
        self.assertEqual(len(result.breakdown_results), 2)

        # Verify each breakdown has correct structure (breakdown_value is now a list)
        for breakdown_result in result.breakdown_results:
            self.assertIn(breakdown_result.breakdown_value, [["Chrome"], ["Safari"]])
            self.assertIsNotNone(breakdown_result.baseline)
            self.assertIsNotNone(breakdown_result.variants)
            self.assertGreater(len(breakdown_result.variants), 0)

    @freeze_time("2020-01-01T12:00:00Z")
    @snapshot_clickhouse_queries
    def test_ratio_metric_with_breakdown(self):
        feature_flag = self.create_feature_flag()
        experiment = self.create_experiment(feature_flag=feature_flag)
        experiment.stats_config = {"method": "frequentist"}
        experiment.save()

        metric = ExperimentRatioMetric(
            numerator=EventsNode(
                event="purchase",
                math=ExperimentMetricMathType.SUM,
                math_property="amount",
            ),
            denominator=EventsNode(
                event="view_item",
                math=ExperimentMetricMathType.TOTAL,
            ),
            breakdownFilter=BreakdownFilter(breakdowns=[Breakdown(property="$browser")]),
        )

        experiment_query = ExperimentQuery(
            experiment_id=experiment.id,
            kind="ExperimentQuery",
            metric=metric,
        )

        experiment.metrics = [metric.model_dump(mode="json")]
        experiment.save()

        feature_flag_property = f"$feature/{feature_flag.key}"

        # Control group - different ratios per browser
        for i in range(4):
            browser = "Chrome" if i < 2 else "Safari"
            _create_person(distinct_ids=[f"user_control_{i}"], team_id=self.team.pk)
            _create_event(
                team=self.team,
                event="$feature_flag_called",
                distinct_id=f"user_control_{i}",
                timestamp="2020-01-02T12:00:00Z",
                properties={
                    feature_flag_property: "control",
                    "$feature_flag_response": "control",
                    "$feature_flag": feature_flag.key,
                    "$browser": browser,
                },
            )
            # Numerator
            _create_event(
                team=self.team,
                event="purchase",
                distinct_id=f"user_control_{i}",
                timestamp="2020-01-02T12:01:00Z",
                properties={
                    feature_flag_property: "control",
                    "amount": 100,
                    "$browser": browser,
                },
            )
            # Denominator - Chrome gets 2 views, Safari gets 5 views
            view_count = 2 if browser == "Chrome" else 5
            for _ in range(view_count):
                _create_event(
                    team=self.team,
                    event="view_item",
                    distinct_id=f"user_control_{i}",
                    timestamp="2020-01-02T12:02:00Z",
                    properties={
                        feature_flag_property: "control",
                        "$browser": browser,
                    },
                )

        # Test group
        for i in range(4):
            browser = "Chrome" if i < 2 else "Safari"
            _create_person(distinct_ids=[f"user_test_{i}"], team_id=self.team.pk)
            _create_event(
                team=self.team,
                event="$feature_flag_called",
                distinct_id=f"user_test_{i}",
                timestamp="2020-01-02T12:00:00Z",
                properties={
                    feature_flag_property: "test",
                    "$feature_flag_response": "test",
                    "$feature_flag": feature_flag.key,
                    "$browser": browser,
                },
            )
            # Numerator
            _create_event(
                team=self.team,
                event="purchase",
                distinct_id=f"user_test_{i}",
                timestamp="2020-01-02T12:01:00Z",
                properties={
                    feature_flag_property: "test",
                    "amount": 150,
                    "$browser": browser,
                },
            )
            # Denominator
            view_count = 3 if browser == "Chrome" else 4
            for _ in range(view_count):
                _create_event(
                    team=self.team,
                    event="view_item",
                    distinct_id=f"user_test_{i}",
                    timestamp="2020-01-02T12:02:00Z",
                    properties={
                        feature_flag_property: "test",
                        "$browser": browser,
                    },
                )

        flush_persons_and_events()

        query_runner = ExperimentQueryRunner(query=experiment_query, team=self.team)
        result = cast(ExperimentQueryResponse, query_runner.calculate())

        self.assertIsNotNone(result.baseline)
        self.assertIsNotNone(result.variant_results)

        # Verify breakdown_results is populated with per-breakdown statistics
        self.assertIsNotNone(result.breakdown_results)
        assert result.breakdown_results is not None
        self.assertEqual(len(result.breakdown_results), 2)

        # Verify each breakdown has correct structure (breakdown_value is now a list)
        for breakdown_result in result.breakdown_results:
            self.assertIn(breakdown_result.breakdown_value, [["Chrome"], ["Safari"]])
            self.assertIsNotNone(breakdown_result.baseline)
            self.assertIsNotNone(breakdown_result.variants)
            self.assertGreater(len(breakdown_result.variants), 0)

    @freeze_time("2020-01-01T12:00:00Z")
    @snapshot_clickhouse_queries
    def test_mean_metric_with_null_breakdown_values(self):
        """Test that NULL breakdown values are handled correctly"""
        feature_flag = self.create_feature_flag()
        experiment = self.create_experiment(feature_flag=feature_flag)
        experiment.stats_config = {"method": "frequentist"}
        experiment.save()

        metric = ExperimentMeanMetric(
            source=EventsNode(
                event="purchase",
                math=ExperimentMetricMathType.TOTAL,
            ),
            breakdownFilter=BreakdownFilter(breakdowns=[Breakdown(property="$browser")]),
        )

        experiment_query = ExperimentQuery(
            experiment_id=experiment.id,
            kind="ExperimentQuery",
            metric=metric,
        )

        experiment.metrics = [metric.model_dump(mode="json")]
        experiment.save()

        feature_flag_property = f"$feature/{feature_flag.key}"

        # Control group - some users with browser, some without
        for i in range(4):
            has_browser = i < 2
            _create_person(distinct_ids=[f"user_control_{i}"], team_id=self.team.pk)
            exposure_props = {
                feature_flag_property: "control",
                "$feature_flag_response": "control",
                "$feature_flag": feature_flag.key,
            }
            if has_browser:
                exposure_props["$browser"] = "Chrome"

            _create_event(
                team=self.team,
                event="$feature_flag_called",
                distinct_id=f"user_control_{i}",
                timestamp="2020-01-02T12:00:00Z",
                properties=exposure_props,
            )

            purchase_props = {feature_flag_property: "control"}
            if has_browser:
                purchase_props["$browser"] = "Chrome"

            _create_event(
                team=self.team,
                event="purchase",
                distinct_id=f"user_control_{i}",
                timestamp="2020-01-02T12:01:00Z",
                properties=purchase_props,
            )

        flush_persons_and_events()

        query_runner = ExperimentQueryRunner(query=experiment_query, team=self.team)
        result = cast(ExperimentQueryResponse, query_runner.calculate())

        # Should have breakdown values including the NULL label
        self.assertIsNotNone(result.baseline)

        # Verify breakdown_results is populated with per-breakdown statistics
        self.assertIsNotNone(result.breakdown_results)
        assert result.breakdown_results is not None
        self.assertEqual(len(result.breakdown_results), 2)

        # Verify each breakdown has correct structure (breakdown_value is now a list)
        for breakdown_result in result.breakdown_results:
            self.assertIn(breakdown_result.breakdown_value, [[BREAKDOWN_NULL_STRING_LABEL], ["Chrome"]])
            self.assertIsNotNone(breakdown_result.baseline)
            self.assertIsNotNone(breakdown_result.variants)
            # variants can be empty if no test variants exist for this breakdown
            self.assertIsInstance(breakdown_result.variants, list)

    @freeze_time("2020-01-01T12:00:00Z")
    @snapshot_clickhouse_queries
    def test_mean_metric_with_winsorization_and_breakdown(self):
        """Test that winsorization computes per-breakdown percentiles, not global percentiles"""
        feature_flag = self.create_feature_flag()
        experiment = self.create_experiment(feature_flag=feature_flag)
        experiment.stats_config = {"method": "frequentist"}
        experiment.save()

        # Use winsorization with p5 and p95 bounds
        metric = ExperimentMeanMetric(
            source=EventsNode(
                event="purchase",
                math=ExperimentMetricMathType.SUM,
                math_property="amount",
            ),
            breakdownFilter=BreakdownFilter(breakdowns=[Breakdown(property="$browser")]),
            lower_bound_percentile=0.05,
            upper_bound_percentile=0.95,
        )

        experiment_query = ExperimentQuery(
            experiment_id=experiment.id,
            kind="ExperimentQuery",
            metric=metric,
        )

        experiment.metrics = [metric.model_dump(mode="json")]
        experiment.save()

        feature_flag_property = f"$feature/{feature_flag.key}"

        # Control group - Chrome users have low values, Safari users have high values
        # This tests that percentiles are computed per-breakdown, not globally
        for i in range(4):
            browser = "Chrome" if i < 2 else "Safari"
            _create_person(distinct_ids=[f"user_control_{i}"], team_id=self.team.pk)
            _create_event(
                team=self.team,
                event="$feature_flag_called",
                distinct_id=f"user_control_{i}",
                timestamp="2020-01-02T12:00:00Z",
                properties={
                    feature_flag_property: "control",
                    "$feature_flag_response": "control",
                    "$feature_flag": feature_flag.key,
                    "$browser": browser,
                },
            )
            _create_event(
                team=self.team,
                event="purchase",
                distinct_id=f"user_control_{i}",
                timestamp="2020-01-02T12:01:00Z",
                properties={
                    feature_flag_property: "control",
                    # Chrome: values 10, 20; Safari: values 100, 200
                    # If percentiles were computed globally, Safari values would be capped at Chrome's p95
                    "amount": 10 + (i * 10) if browser == "Chrome" else 100 + (i - 2) * 100,
                    "$browser": browser,
                },
            )

        # Test group - similar pattern
        for i in range(4):
            browser = "Chrome" if i < 2 else "Safari"
            _create_person(distinct_ids=[f"user_test_{i}"], team_id=self.team.pk)
            _create_event(
                team=self.team,
                event="$feature_flag_called",
                distinct_id=f"user_test_{i}",
                timestamp="2020-01-02T12:00:00Z",
                properties={
                    feature_flag_property: "test",
                    "$feature_flag_response": "test",
                    "$feature_flag": feature_flag.key,
                    "$browser": browser,
                },
            )
            _create_event(
                team=self.team,
                event="purchase",
                distinct_id=f"user_test_{i}",
                timestamp="2020-01-02T12:01:00Z",
                properties={
                    feature_flag_property: "test",
                    "amount": 15 + (i * 10) if browser == "Chrome" else 110 + (i - 2) * 100,
                    "$browser": browser,
                },
            )

        flush_persons_and_events()

        query_runner = ExperimentQueryRunner(query=experiment_query, team=self.team)
        result = cast(ExperimentQueryResponse, query_runner.calculate())

        # Verify breakdown structure exists

        self.assertIsNotNone(result.breakdown_results)
        assert result.breakdown_results is not None
        self.assertEqual(len(result.breakdown_results), 2)

        # Verify each breakdown has stats
        # The key validation is that Safari's high values aren't capped at Chrome's percentiles
        for breakdown_result in result.breakdown_results:
            self.assertIn(breakdown_result.breakdown_value, [["Chrome"], ["Safari"]])
            self.assertIsNotNone(breakdown_result.baseline)
            self.assertIsNotNone(breakdown_result.variants)
            self.assertGreater(len(breakdown_result.variants), 0)

    @freeze_time("2020-01-01T12:00:00Z")
    @snapshot_clickhouse_queries
    def test_mean_metric_with_two_breakdowns(self):
        """Test mean metric calculations work correctly with 2 breakdown dimensions"""
        feature_flag = self.create_feature_flag()
        experiment = self.create_experiment(feature_flag=feature_flag)
        experiment.stats_config = {"method": "frequentist"}
        experiment.save()

        metric = ExperimentMeanMetric(
            source=EventsNode(
                event="purchase",
                math=ExperimentMetricMathType.SUM,
                math_property="amount",
            ),
            breakdownFilter=BreakdownFilter(breakdowns=[Breakdown(property="$browser"), Breakdown(property="$os")]),
        )

        experiment_query = ExperimentQuery(
            experiment_id=experiment.id,
            kind="ExperimentQuery",
            metric=metric,
        )

        experiment.metrics = [metric.model_dump(mode="json")]
        experiment.save()

        feature_flag_property = f"$feature/{feature_flag.key}"

        # Control group - 8 users (2 per combination)
        for i in range(8):
            browser = "Chrome" if i < 4 else "Safari"
            os = "Windows" if i % 2 == 0 else "Mac"
            amount = {
                ("Chrome", "Windows"): 10,
                ("Chrome", "Mac"): 15,
                ("Safari", "Windows"): 20,
                ("Safari", "Mac"): 25,
            }[(browser, os)]

            _create_person(distinct_ids=[f"user_control_{i}"], team_id=self.team.pk)
            _create_event(
                team=self.team,
                event="$feature_flag_called",
                distinct_id=f"user_control_{i}",
                timestamp="2020-01-02T12:00:00Z",
                properties={
                    feature_flag_property: "control",
                    "$feature_flag_response": "control",
                    "$feature_flag": feature_flag.key,
                    "$browser": browser,
                    "$os": os,
                },
            )
            _create_event(
                team=self.team,
                event="purchase",
                distinct_id=f"user_control_{i}",
                timestamp="2020-01-02T12:01:00Z",
                properties={
                    feature_flag_property: "control",
                    "amount": amount,
                    "$browser": browser,
                    "$os": os,
                },
            )

        # Test group - 8 users (2 per combination)
        for i in range(8):
            browser = "Chrome" if i < 4 else "Safari"
            os = "Windows" if i % 2 == 0 else "Mac"
            amount = {
                ("Chrome", "Windows"): 12,
                ("Chrome", "Mac"): 18,
                ("Safari", "Windows"): 22,
                ("Safari", "Mac"): 28,
            }[(browser, os)]

            _create_person(distinct_ids=[f"user_test_{i}"], team_id=self.team.pk)
            _create_event(
                team=self.team,
                event="$feature_flag_called",
                distinct_id=f"user_test_{i}",
                timestamp="2020-01-02T12:00:00Z",
                properties={
                    feature_flag_property: "test",
                    "$feature_flag_response": "test",
                    "$feature_flag": feature_flag.key,
                    "$browser": browser,
                    "$os": os,
                },
            )
            _create_event(
                team=self.team,
                event="purchase",
                distinct_id=f"user_test_{i}",
                timestamp="2020-01-02T12:01:00Z",
                properties={
                    feature_flag_property: "test",
                    "amount": amount,
                    "$browser": browser,
                    "$os": os,
                },
            )

        flush_persons_and_events()

        query_runner = ExperimentQueryRunner(query=experiment_query, team=self.team)
        result = cast(ExperimentQueryResponse, query_runner.calculate())

        # Basic structure
        self.assertIsNotNone(result.baseline)
        self.assertIsNotNone(result.variant_results)

        # Verify breakdown_results structure
        self.assertIsNotNone(result.breakdown_results)
        assert result.breakdown_results is not None
        self.assertEqual(len(result.breakdown_results), 4)

        # Verify each breakdown has correct structure
        for breakdown_result in result.breakdown_results:
            self.assertIsNotNone(breakdown_result.baseline)
            self.assertIsNotNone(breakdown_result.variants)
            self.assertGreater(len(breakdown_result.variants), 0)

            # Each variant has statistical data
            for variant in breakdown_result.variants:
                self.assertIsNotNone(variant.key)
                self.assertIsNotNone(variant.number_of_samples)
                self.assertEqual(variant.number_of_samples, 2)  # 2 users per combination

    @freeze_time("2020-01-01T12:00:00Z")
    @snapshot_clickhouse_queries
    def test_funnel_metric_with_two_breakdowns(self):
        """Test funnel metrics work with 2 breakdown dimensions"""
        feature_flag = self.create_feature_flag()
        experiment = self.create_experiment(feature_flag=feature_flag)
        experiment.stats_config = {"method": "frequentist"}
        experiment.save()

        metric = ExperimentFunnelMetric(
            series=[EventsNode(event="purchase")],
            breakdownFilter=BreakdownFilter(breakdowns=[Breakdown(property="$browser"), Breakdown(property="$os")]),
        )

        experiment_query = ExperimentQuery(
            experiment_id=experiment.id,
            kind="ExperimentQuery",
            metric=metric,
        )

        experiment.metrics = [metric.model_dump(mode="json")]
        experiment.save()

        feature_flag_property = f"$feature/{feature_flag.key}"

        # Control group - 12 users total (3 per combination)
        for i in range(12):
            browser = "Chrome" if i < 6 else "Safari"
            os = "Windows" if i % 6 < 3 else "Mac"
            # Vary completion: Chrome+Windows: 2/3, Chrome+Mac: 1/3, Safari+Windows: 3/3, Safari+Mac: 0/3
            completes_funnel = (
                (browser == "Chrome" and os == "Windows" and i % 3 < 2)
                or (browser == "Chrome" and os == "Mac" and i % 3 == 0)
                or (browser == "Safari" and os == "Windows")
            )

            _create_person(distinct_ids=[f"user_control_{i}"], team_id=self.team.pk)
            _create_event(
                team=self.team,
                event="$feature_flag_called",
                distinct_id=f"user_control_{i}",
                timestamp="2020-01-02T12:00:00Z",
                properties={
                    feature_flag_property: "control",
                    "$feature_flag_response": "control",
                    "$feature_flag": feature_flag.key,
                    "$browser": browser,
                    "$os": os,
                },
            )
            if completes_funnel:
                _create_event(
                    team=self.team,
                    event="purchase",
                    distinct_id=f"user_control_{i}",
                    timestamp="2020-01-02T12:01:00Z",
                    properties={feature_flag_property: "control", "$browser": browser, "$os": os},
                )

        # Test group - inverse pattern
        for i in range(12):
            browser = "Chrome" if i < 6 else "Safari"
            os = "Windows" if i % 6 < 3 else "Mac"
            completes_funnel = (
                (browser == "Chrome" and os == "Windows" and i % 3 == 0)
                or (browser == "Chrome" and os == "Mac" and i % 3 < 2)
                or (browser == "Safari" and os == "Mac")
            )

            _create_person(distinct_ids=[f"user_test_{i}"], team_id=self.team.pk)
            _create_event(
                team=self.team,
                event="$feature_flag_called",
                distinct_id=f"user_test_{i}",
                timestamp="2020-01-02T12:00:00Z",
                properties={
                    feature_flag_property: "test",
                    "$feature_flag_response": "test",
                    "$feature_flag": feature_flag.key,
                    "$browser": browser,
                    "$os": os,
                },
            )
            if completes_funnel:
                _create_event(
                    team=self.team,
                    event="purchase",
                    distinct_id=f"user_test_{i}",
                    timestamp="2020-01-02T12:01:00Z",
                    properties={feature_flag_property: "test", "$browser": browser, "$os": os},
                )

        flush_persons_and_events()

        query_runner = ExperimentQueryRunner(query=experiment_query, team=self.team)
        result = cast(ExperimentQueryResponse, query_runner.calculate())

        self.assertIsNotNone(result.baseline)
        assert result.breakdown_results is not None
        self.assertEqual(len(result.breakdown_results), 4)

    @freeze_time("2020-01-01T12:00:00Z")
    def test_funnel_metric_breakdown_query_builds_without_ambiguity_error(self):
        """
        Regression test for ambiguous query error with UNORDERED funnel breakdowns.
        Tests that the query can be built and printed to HogQL without
        "Ambiguous query. Found multiple sources for field: breakdown_value_1" error.

        The error occurs during to_printed_hogql() when the resolver tries to resolve
        breakdown_value_1 and finds it in multiple CTEs (metric_events and exposures).

        This specifically tests UNORDERED funnels (funnel_order_type=StepOrderValue.UNORDERED)
        which use the exposures CTE and are where the ambiguity error occurs.
        """
        feature_flag = self.create_feature_flag()
        experiment = self.create_experiment(feature_flag=feature_flag)

        metric = ExperimentFunnelMetric(
            series=[EventsNode(event="purchase")],
            breakdownFilter=BreakdownFilter(breakdowns=[Breakdown(property="$browser")]),
            funnel_order_type=StepOrderValue.UNORDERED,  # This is the key - unordered funnels trigger the bug
        )

        experiment_query = ExperimentQuery(
            experiment_id=experiment.id,
            kind="ExperimentQuery",
            metric=metric,
        )

        query_runner = ExperimentQueryRunner(query=experiment_query, team=self.team)

        # The error happens during _evaluate_experiment_query when it calls to_printed_hogql
        # This should NOT raise: "ResolutionError: Ambiguous query. Found multiple sources for field: breakdown_value_1"
        # If it does, that means the breakdown field references are not properly qualified
        query_runner._evaluate_experiment_query()

    @freeze_time("2020-01-01T12:00:00Z")
    @snapshot_clickhouse_queries
    def test_ratio_metric_with_two_breakdowns(self):
        """Test ratio metrics work with 2 breakdown dimensions"""
        feature_flag = self.create_feature_flag()
        experiment = self.create_experiment(feature_flag=feature_flag)
        experiment.stats_config = {"method": "frequentist"}
        experiment.save()

        metric = ExperimentRatioMetric(
            numerator=EventsNode(event="purchase", math=ExperimentMetricMathType.SUM, math_property="amount"),
            denominator=EventsNode(event="view_item", math=ExperimentMetricMathType.TOTAL),
            breakdownFilter=BreakdownFilter(breakdowns=[Breakdown(property="$browser"), Breakdown(property="$os")]),
        )

        experiment_query = ExperimentQuery(
            experiment_id=experiment.id,
            kind="ExperimentQuery",
            metric=metric,
        )

        experiment.metrics = [metric.model_dump(mode="json")]
        experiment.save()

        feature_flag_property = f"$feature/{feature_flag.key}"

        # Control group - 8 users (2 per combination)
        for i in range(8):
            browser = "Chrome" if i < 4 else "Safari"
            os = "Windows" if i % 2 == 0 else "Mac"
            view_count = {
                ("Chrome", "Windows"): 2,
                ("Chrome", "Mac"): 3,
                ("Safari", "Windows"): 4,
                ("Safari", "Mac"): 5,
            }[(browser, os)]

            _create_person(distinct_ids=[f"user_control_{i}"], team_id=self.team.pk)
            _create_event(
                team=self.team,
                event="$feature_flag_called",
                distinct_id=f"user_control_{i}",
                timestamp="2020-01-02T12:00:00Z",
                properties={
                    feature_flag_property: "control",
                    "$feature_flag_response": "control",
                    "$feature_flag": feature_flag.key,
                    "$browser": browser,
                    "$os": os,
                },
            )
            _create_event(
                team=self.team,
                event="purchase",
                distinct_id=f"user_control_{i}",
                timestamp="2020-01-02T12:01:00Z",
                properties={feature_flag_property: "control", "amount": 100, "$browser": browser, "$os": os},
            )
            for _ in range(view_count):
                _create_event(
                    team=self.team,
                    event="view_item",
                    distinct_id=f"user_control_{i}",
                    timestamp="2020-01-02T12:02:00Z",
                    properties={feature_flag_property: "control", "$browser": browser, "$os": os},
                )

        # Test group
        for i in range(8):
            browser = "Chrome" if i < 4 else "Safari"
            os = "Windows" if i % 2 == 0 else "Mac"
            view_count = {
                ("Chrome", "Windows"): 3,
                ("Chrome", "Mac"): 2,
                ("Safari", "Windows"): 5,
                ("Safari", "Mac"): 4,
            }[(browser, os)]

            _create_person(distinct_ids=[f"user_test_{i}"], team_id=self.team.pk)
            _create_event(
                team=self.team,
                event="$feature_flag_called",
                distinct_id=f"user_test_{i}",
                timestamp="2020-01-02T12:00:00Z",
                properties={
                    feature_flag_property: "test",
                    "$feature_flag_response": "test",
                    "$feature_flag": feature_flag.key,
                    "$browser": browser,
                    "$os": os,
                },
            )
            _create_event(
                team=self.team,
                event="purchase",
                distinct_id=f"user_test_{i}",
                timestamp="2020-01-02T12:01:00Z",
                properties={feature_flag_property: "test", "amount": 150, "$browser": browser, "$os": os},
            )
            for _ in range(view_count):
                _create_event(
                    team=self.team,
                    event="view_item",
                    distinct_id=f"user_test_{i}",
                    timestamp="2020-01-02T12:02:00Z",
                    properties={feature_flag_property: "test", "$browser": browser, "$os": os},
                )

        flush_persons_and_events()

        query_runner = ExperimentQueryRunner(query=experiment_query, team=self.team)
        result = cast(ExperimentQueryResponse, query_runner.calculate())

        assert result.breakdown_results is not None
        self.assertEqual(len(result.breakdown_results), 4)

        # Verify ratio-specific fields exist
        for breakdown_result in result.breakdown_results:
            baseline = breakdown_result.baseline
            self.assertIsNotNone(baseline.sum)
            self.assertIsNotNone(baseline.denominator_sum)

            for variant in breakdown_result.variants:
                self.assertIsNotNone(variant.sum)
                self.assertIsNotNone(variant.denominator_sum)

    def test_breakdown_validation_raises_error_for_more_than_three(self):
        """Verify that using more than 3 breakdowns raises a ValidationError"""
        from pydantic import ValidationError as PydanticValidationError

        # Pydantic validates at schema level, so creating the BreakdownFilter should fail
        with self.assertRaises(PydanticValidationError) as context:
            BreakdownFilter(
                breakdowns=[
                    Breakdown(property="$browser"),
                    Breakdown(property="$os"),
                    Breakdown(property="$device_type"),
                    Breakdown(property="$country"),  # 4th breakdown - should fail
                ]
            )

        # Verify error message mentions too many items
        self.assertIn("at most 3 items", str(context.exception))

    @freeze_time("2020-01-01T12:00:00Z")
    @snapshot_clickhouse_queries
    def test_missing_variants_across_breakdown_combinations(self):
        """Verify correct handling when control has all breakdown combinations but test is missing some"""
        feature_flag = self.create_feature_flag()
        experiment = self.create_experiment(feature_flag=feature_flag)
        experiment.stats_config = {"method": "frequentist"}
        experiment.save()

        metric = ExperimentMeanMetric(
            source=EventsNode(event="purchase", math=ExperimentMetricMathType.SUM, math_property="amount"),
            breakdownFilter=BreakdownFilter(breakdowns=[Breakdown(property="$browser"), Breakdown(property="$os")]),
        )

        experiment_query = ExperimentQuery(
            experiment_id=experiment.id,
            kind="ExperimentQuery",
            metric=metric,
        )

        experiment.metrics = [metric.model_dump(mode="json")]
        experiment.save()

        feature_flag_property = f"$feature/{feature_flag.key}"

        # Control group - ALL 4 combinations present
        for i in range(8):
            browser = "Chrome" if i < 4 else "Safari"
            os = "Windows" if i % 2 == 0 else "Mac"

            _create_person(distinct_ids=[f"user_control_{i}"], team_id=self.team.pk)
            _create_event(
                team=self.team,
                event="$feature_flag_called",
                distinct_id=f"user_control_{i}",
                timestamp="2020-01-02T12:00:00Z",
                properties={
                    feature_flag_property: "control",
                    "$feature_flag_response": "control",
                    "$feature_flag": feature_flag.key,
                    "$browser": browser,
                    "$os": os,
                },
            )
            _create_event(
                team=self.team,
                event="purchase",
                distinct_id=f"user_control_{i}",
                timestamp="2020-01-02T12:01:00Z",
                properties={feature_flag_property: "control", "amount": 10, "$browser": browser, "$os": os},
            )

        # Test group - ONLY 2 combinations present (Chrome+Windows, Safari+Mac)
        for i in range(4):
            browser = "Chrome" if i < 2 else "Safari"
            os = "Windows" if i < 2 else "Mac"

            _create_person(distinct_ids=[f"user_test_{i}"], team_id=self.team.pk)
            _create_event(
                team=self.team,
                event="$feature_flag_called",
                distinct_id=f"user_test_{i}",
                timestamp="2020-01-02T12:00:00Z",
                properties={
                    feature_flag_property: "test",
                    "$feature_flag_response": "test",
                    "$feature_flag": feature_flag.key,
                    "$browser": browser,
                    "$os": os,
                },
            )
            _create_event(
                team=self.team,
                event="purchase",
                distinct_id=f"user_test_{i}",
                timestamp="2020-01-02T12:01:00Z",
                properties={feature_flag_property: "test", "amount": 15, "$browser": browser, "$os": os},
            )

        flush_persons_and_events()

        query_runner = ExperimentQueryRunner(query=experiment_query, team=self.team)
        result = cast(ExperimentQueryResponse, query_runner.calculate())

        # All 4 breakdown combinations should still appear
        assert result.breakdown_results is not None
        self.assertEqual(len(result.breakdown_results), 4)

        # Check that breakdown_results exist for all combinations
        chrome_mac_found = False
        safari_windows_found = False
        chrome_windows_found = False
        safari_mac_found = False

        for breakdown_result in result.breakdown_results:
            if breakdown_result.breakdown_value == ["Chrome", "Mac"]:
                chrome_mac_found = True
                # Control should have data
                self.assertIsNotNone(breakdown_result.baseline)
                self.assertEqual(breakdown_result.baseline.number_of_samples, 2)
                # Test variant may or may not be present for missing combinations

            if breakdown_result.breakdown_value == ["Safari", "Windows"]:
                safari_windows_found = True
                self.assertIsNotNone(breakdown_result.baseline)
                self.assertEqual(breakdown_result.baseline.number_of_samples, 2)

            if breakdown_result.breakdown_value == ["Chrome", "Windows"]:
                chrome_windows_found = True
                # This combination exists in both variants
                self.assertIsNotNone(breakdown_result.baseline)
                self.assertEqual(breakdown_result.baseline.number_of_samples, 2)
                self.assertGreater(len(breakdown_result.variants), 0)
                test_variant = breakdown_result.variants[0]
                self.assertEqual(test_variant.key, "test")
                self.assertEqual(test_variant.number_of_samples, 2)

            if breakdown_result.breakdown_value == ["Safari", "Mac"]:
                safari_mac_found = True
                # This combination exists in both variants
                self.assertIsNotNone(breakdown_result.baseline)
                self.assertEqual(breakdown_result.baseline.number_of_samples, 2)
                self.assertGreater(len(breakdown_result.variants), 0)
                test_variant = breakdown_result.variants[0]
                self.assertEqual(test_variant.key, "test")
                self.assertEqual(test_variant.number_of_samples, 2)

        self.assertTrue(chrome_mac_found, "Chrome+Mac breakdown should exist")
        self.assertTrue(safari_windows_found, "Safari+Windows breakdown should exist")
        self.assertTrue(chrome_windows_found, "Chrome+Windows breakdown should exist")
        self.assertTrue(safari_mac_found, "Safari+Mac breakdown should exist")

    @parameterized.expand([("new_query_builder", True)])
    @freeze_time("2020-01-01T12:00:00Z")
    @snapshot_clickhouse_queries
    def test_retention_metric_with_breakdown(self, name, use_new_query_builder):
        """
        Test retention metric with single breakdown dimension.

        Retention = (users who completed) / (users who started)
        Breakdown by $browser (Chrome/Safari)
        """
        feature_flag = self.create_feature_flag()
        experiment = self.create_experiment(feature_flag=feature_flag)
        experiment.stats_config = {"method": "frequentist", "use_new_query_builder": use_new_query_builder}
        experiment.save()

        metric = ExperimentRetentionMetric(
            start_event=EventsNode(
                event="signup",
                math=ExperimentMetricMathType.TOTAL,
            ),
            completion_event=EventsNode(
                event="login",
                math=ExperimentMetricMathType.TOTAL,
            ),
            retention_window_start=1,
            retention_window_end=7,
            retention_window_unit=FunnelConversionWindowTimeUnit.DAY,
            start_handling=StartHandling.FIRST_SEEN,
            breakdownFilter=BreakdownFilter(breakdowns=[Breakdown(property="$browser")]),
        )

        experiment_query = ExperimentQuery(
            experiment_id=experiment.id,
            kind="ExperimentQuery",
            metric=metric,
        )

        experiment.metrics = [metric.model_dump(mode="json")]
        experiment.save()

        feature_flag_property = f"$feature/{feature_flag.key}"

        # Control group - different retention rates per browser
        # Chrome: 2 users, 2 sign up, 2 return (100% retention)
        # Safari: 2 users, 2 sign up, 1 returns (50% retention)
        for i in range(4):
            browser = "Chrome" if i < 2 else "Safari"
            _create_person(distinct_ids=[f"user_control_{i}"], team_id=self.team.pk)

            # Exposure event with breakdown property
            _create_event(
                team=self.team,
                event="$feature_flag_called",
                distinct_id=f"user_control_{i}",
                timestamp="2020-01-02T12:00:00Z",
                properties={
                    feature_flag_property: "control",
                    "$feature_flag_response": "control",
                    "$feature_flag": feature_flag.key,
                    "$browser": browser,
                },
            )

            # All users sign up (start event)
            _create_event(
                team=self.team,
                event="signup",
                distinct_id=f"user_control_{i}",
                timestamp="2020-01-02T12:01:00Z",
                properties={feature_flag_property: "control"},
            )

            # Chrome users all return, Safari only first one returns
            if i < 2 or i == 2:
                _create_event(
                    team=self.team,
                    event="login",
                    distinct_id=f"user_control_{i}",
                    timestamp="2020-01-05T12:00:00Z",  # Day 3 after signup
                    properties={feature_flag_property: "control"},
                )

        # Test group
        # Chrome: 2 users, 2 sign up, 1 returns (50% retention)
        # Safari: 2 users, 2 sign up, 2 return (100% retention)
        for i in range(4):
            browser = "Chrome" if i < 2 else "Safari"
            _create_person(distinct_ids=[f"user_test_{i}"], team_id=self.team.pk)

            # Exposure event with breakdown property
            _create_event(
                team=self.team,
                event="$feature_flag_called",
                distinct_id=f"user_test_{i}",
                timestamp="2020-01-02T12:00:00Z",
                properties={
                    feature_flag_property: "test",
                    "$feature_flag_response": "test",
                    "$feature_flag": feature_flag.key,
                    "$browser": browser,
                },
            )

            # All users sign up (start event)
            _create_event(
                team=self.team,
                event="signup",
                distinct_id=f"user_test_{i}",
                timestamp="2020-01-02T12:01:00Z",
                properties={feature_flag_property: "test"},
            )

            # Safari users all return, Chrome only first one returns
            if i >= 2 or i == 0:
                _create_event(
                    team=self.team,
                    event="login",
                    distinct_id=f"user_test_{i}",
                    timestamp="2020-01-05T12:00:00Z",  # Day 3 after signup
                    properties={feature_flag_property: "test"},
                )

        flush_persons_and_events()

        query_runner = ExperimentQueryRunner(query=experiment_query, team=self.team)
        result = cast(ExperimentQueryResponse, query_runner.calculate())

        self.assertIsNotNone(result.baseline)
        self.assertIsNotNone(result.variant_results)

        # Verify breakdown_results is populated with per-breakdown statistics
        self.assertIsNotNone(result.breakdown_results)
        assert result.breakdown_results is not None
        self.assertEqual(len(result.breakdown_results), 2)

        # Verify each breakdown has correct structure (breakdown_value is a list)
        for breakdown_result in result.breakdown_results:
            self.assertIn(breakdown_result.breakdown_value, [["Chrome"], ["Safari"]])
            self.assertIsNotNone(breakdown_result.baseline)
            self.assertIsNotNone(breakdown_result.variants)
            self.assertGreater(len(breakdown_result.variants), 0)

            baseline = breakdown_result.baseline
            self.assertIsNotNone(baseline.number_of_samples)
            self.assertIsNotNone(baseline.sum)

            for variant in breakdown_result.variants:
                self.assertIsNotNone(variant.number_of_samples)
                self.assertIsNotNone(variant.sum)

    @parameterized.expand([("new_query_builder", True)])
    @freeze_time("2020-01-01T12:00:00Z")
    @snapshot_clickhouse_queries
    def test_retention_metric_with_two_breakdowns(self, name, use_new_query_builder):
        """
        Test retention metric with two breakdown dimensions.

        Breakdown by $browser × $os
        """
        feature_flag = self.create_feature_flag()
        experiment = self.create_experiment(feature_flag=feature_flag)
        experiment.stats_config = {"method": "frequentist", "use_new_query_builder": use_new_query_builder}
        experiment.save()

        metric = ExperimentRetentionMetric(
            start_event=EventsNode(
                event="signup",
                math=ExperimentMetricMathType.TOTAL,
            ),
            completion_event=EventsNode(
                event="login",
                math=ExperimentMetricMathType.TOTAL,
            ),
            retention_window_start=1,
            retention_window_end=7,
            retention_window_unit=FunnelConversionWindowTimeUnit.DAY,
            start_handling=StartHandling.FIRST_SEEN,
            breakdownFilter=BreakdownFilter(breakdowns=[Breakdown(property="$browser"), Breakdown(property="$os")]),
        )

        experiment_query = ExperimentQuery(
            experiment_id=experiment.id,
            kind="ExperimentQuery",
            metric=metric,
        )

        experiment.metrics = [metric.model_dump(mode="json")]
        experiment.save()

        feature_flag_property = f"$feature/{feature_flag.key}"

        # Control group - 4 breakdown combinations: Chrome×Mac, Chrome×Windows, Safari×Mac, Safari×Windows
        for i in range(8):
            browser = "Chrome" if i < 4 else "Safari"
            os = "Mac" if i % 2 == 0 else "Windows"
            _create_person(distinct_ids=[f"user_control_{i}"], team_id=self.team.pk)

            # Exposure event with breakdown properties
            _create_event(
                team=self.team,
                event="$feature_flag_called",
                distinct_id=f"user_control_{i}",
                timestamp="2020-01-02T12:00:00Z",
                properties={
                    feature_flag_property: "control",
                    "$feature_flag_response": "control",
                    "$feature_flag": feature_flag.key,
                    "$browser": browser,
                    "$os": os,
                },
            )

            # All users sign up
            _create_event(
                team=self.team,
                event="signup",
                distinct_id=f"user_control_{i}",
                timestamp="2020-01-02T12:01:00Z",
                properties={feature_flag_property: "control"},
            )

            # First user of each combination returns (50% retention per combination)
            if i % 2 == 0:
                _create_event(
                    team=self.team,
                    event="login",
                    distinct_id=f"user_control_{i}",
                    timestamp="2020-01-05T12:00:00Z",
                    properties={feature_flag_property: "control"},
                )

        # Test group
        for i in range(8):
            browser = "Chrome" if i < 4 else "Safari"
            os = "Mac" if i % 2 == 0 else "Windows"
            _create_person(distinct_ids=[f"user_test_{i}"], team_id=self.team.pk)

            # Exposure event with breakdown properties
            _create_event(
                team=self.team,
                event="$feature_flag_called",
                distinct_id=f"user_test_{i}",
                timestamp="2020-01-02T12:00:00Z",
                properties={
                    feature_flag_property: "test",
                    "$feature_flag_response": "test",
                    "$feature_flag": feature_flag.key,
                    "$browser": browser,
                    "$os": os,
                },
            )

            # All users sign up
            _create_event(
                team=self.team,
                event="signup",
                distinct_id=f"user_test_{i}",
                timestamp="2020-01-02T12:01:00Z",
                properties={feature_flag_property: "test"},
            )

            # All users return (100% retention)
            _create_event(
                team=self.team,
                event="login",
                distinct_id=f"user_test_{i}",
                timestamp="2020-01-05T12:00:00Z",
                properties={feature_flag_property: "test"},
            )

        flush_persons_and_events()

        query_runner = ExperimentQueryRunner(query=experiment_query, team=self.team)
        result = cast(ExperimentQueryResponse, query_runner.calculate())

        self.assertIsNotNone(result.baseline)
        self.assertIsNotNone(result.variant_results)

        # Verify breakdown_results has all 4 combinations
        self.assertIsNotNone(result.breakdown_results)
        assert result.breakdown_results is not None
        self.assertEqual(len(result.breakdown_results), 4)

        # Verify each breakdown has correct structure (breakdown_value is a list of 2 elements)
        breakdown_values = [br.breakdown_value for br in result.breakdown_results]
        expected_combinations = [
            ["Chrome", "Mac"],
            ["Chrome", "Windows"],
            ["Safari", "Mac"],
            ["Safari", "Windows"],
        ]
        for expected in expected_combinations:
            self.assertIn(expected, breakdown_values)

        for breakdown_result in result.breakdown_results:
            self.assertIsNotNone(breakdown_result.baseline)
            self.assertIsNotNone(breakdown_result.variants)
            self.assertGreater(len(breakdown_result.variants), 0)

    @freeze_time("2020-01-01T12:00:00Z")
    def test_retention_metric_breakdown_with_missing_control_variant(self):
        """
        Regression test: Retention metrics with breakdowns should handle cases where
        some breakdown groups have no data for certain variants (including control).

        This reproduces the "ValueError: No control variant found" bug that occurs
        when a breakdown group (e.g., specific browser type) has data for test variants
        but not for the control variant.
        """
        feature_flag = self.create_feature_flag()
        experiment = self.create_experiment(feature_flag=feature_flag)
        experiment.stats_config = {"method": "frequentist", "use_new_query_builder": True}
        experiment.save()

        metric = ExperimentRetentionMetric(
            start_event=EventsNode(event="signup"),
            completion_event=EventsNode(event="login"),
            retention_window_start=1,
            retention_window_end=7,
            retention_window_unit=FunnelConversionWindowTimeUnit.DAY,
            start_handling=StartHandling.FIRST_SEEN,
            breakdownFilter=BreakdownFilter(breakdowns=[Breakdown(property="$browser")]),
        )

        experiment_query = ExperimentQuery(
            experiment_id=experiment.id,
            kind="ExperimentQuery",
            metric=metric,
        )
        experiment.metrics = [metric.model_dump(mode="json")]
        experiment.save()

        feature_flag_property = f"$feature/{feature_flag.key}"

        # Create control users with Chrome only
        for i in range(2):
            _create_person(distinct_ids=[f"user_control_{i}"], team_id=self.team.pk)
            _create_event(
                team=self.team,
                event="$feature_flag_called",
                distinct_id=f"user_control_{i}",
                timestamp="2020-01-02T12:00:00Z",
                properties={
                    feature_flag_property: "control",
                    "$feature_flag_response": "control",
                    "$feature_flag": feature_flag.key,
                    "$browser": "Chrome",
                },
            )
            _create_event(
                team=self.team,
                event="signup",
                distinct_id=f"user_control_{i}",
                timestamp="2020-01-02T12:01:00Z",
                properties={feature_flag_property: "control"},
            )
            _create_event(
                team=self.team,
                event="login",
                distinct_id=f"user_control_{i}",
                timestamp="2020-01-05T12:00:00Z",
                properties={feature_flag_property: "control"},
            )

        # Create test users with both Chrome AND Safari
        for browser in ["Chrome", "Safari"]:
            for i in range(2):
                _create_person(distinct_ids=[f"user_test_{browser}_{i}"], team_id=self.team.pk)
                _create_event(
                    team=self.team,
                    event="$feature_flag_called",
                    distinct_id=f"user_test_{browser}_{i}",
                    timestamp="2020-01-02T12:00:00Z",
                    properties={
                        feature_flag_property: "test",
                        "$feature_flag_response": "test",
                        "$feature_flag": feature_flag.key,
                        "$browser": browser,
                    },
                )
                _create_event(
                    team=self.team,
                    event="signup",
                    distinct_id=f"user_test_{browser}_{i}",
                    timestamp="2020-01-02T12:01:00Z",
                    properties={feature_flag_property: "test"},
                )
                _create_event(
                    team=self.team,
                    event="login",
                    distinct_id=f"user_test_{browser}_{i}",
                    timestamp="2020-01-05T12:00:00Z",
                    properties={feature_flag_property: "test"},
                )

        flush_persons_and_events()

        query_runner = ExperimentQueryRunner(query=experiment_query, team=self.team)

        # This should NOT raise "ValueError: No control variant found"
        # Safari breakdown has no control variant data, but should be handled gracefully
        result = query_runner._calculate()

        # Verify we got breakdown results for both browsers
        self.assertIsNotNone(result.breakdown_results)
        assert result.breakdown_results is not None
        self.assertEqual(len(result.breakdown_results), 2)  # Chrome and Safari

        # Chrome breakdown should have real control data
        chrome_breakdown = next((br for br in result.breakdown_results if br.breakdown_value == ["Chrome"]), None)
        self.assertIsNotNone(chrome_breakdown)
        assert chrome_breakdown is not None
        self.assertIsNotNone(chrome_breakdown.baseline)
        self.assertGreater(chrome_breakdown.baseline.number_of_samples, 0)

        # Safari breakdown should have zero-filled control data
        safari_breakdown = next((br for br in result.breakdown_results if br.breakdown_value == ["Safari"]), None)
        self.assertIsNotNone(safari_breakdown)
        assert safari_breakdown is not None
        self.assertIsNotNone(safari_breakdown.baseline)
        self.assertEqual(safari_breakdown.baseline.number_of_samples, 0)  # No control users with Safari

    @freeze_time("2020-01-01T12:00:00Z")
    @snapshot_clickhouse_queries
    def test_mean_metric_with_person_property_breakdown(self):
        """Test that mean metrics can be broken down by person properties"""
        feature_flag = self.create_feature_flag()
        experiment = self.create_experiment(feature_flag=feature_flag)
        experiment.stats_config = {"method": "frequentist"}
        experiment.save()

        metric = ExperimentMeanMetric(
            source=EventsNode(
                event="purchase",
                math=ExperimentMetricMathType.SUM,
                math_property="amount",
            ),
            breakdownFilter=BreakdownFilter(breakdowns=[Breakdown(property="country", type="person")]),
        )

        experiment_query = ExperimentQuery(
            experiment_id=experiment.id,
            kind="ExperimentQuery",
            metric=metric,
        )

        experiment.metrics = [metric.model_dump(mode="json")]
        experiment.save()

        feature_flag_property = f"$feature/{feature_flag.key}"

        # Control group - 2 users from US, 2 from UK
        for i in range(4):
            country = "US" if i < 2 else "UK"
            _create_person(distinct_ids=[f"user_control_{i}"], team_id=self.team.pk, properties={"country": country})
            _create_event(
                team=self.team,
                event="$feature_flag_called",
                distinct_id=f"user_control_{i}",
                timestamp="2020-01-02T12:00:00Z",
                properties={
                    feature_flag_property: "control",
                    "$feature_flag_response": "control",
                    "$feature_flag": feature_flag.key,
                },
            )
            _create_event(
                team=self.team,
                event="purchase",
                distinct_id=f"user_control_{i}",
                timestamp="2020-01-02T12:01:00Z",
                properties={
                    feature_flag_property: "control",
                    "amount": 10 if country == "US" else 20,
                },
            )

        # Test group - 2 users from US, 2 from UK
        for i in range(4):
            country = "US" if i < 2 else "UK"
            _create_person(distinct_ids=[f"user_test_{i}"], team_id=self.team.pk, properties={"country": country})
            _create_event(
                team=self.team,
                event="$feature_flag_called",
                distinct_id=f"user_test_{i}",
                timestamp="2020-01-02T12:00:00Z",
                properties={
                    feature_flag_property: "test",
                    "$feature_flag_response": "test",
                    "$feature_flag": feature_flag.key,
                },
            )
            _create_event(
                team=self.team,
                event="purchase",
                distinct_id=f"user_test_{i}",
                timestamp="2020-01-02T12:01:00Z",
                properties={
                    feature_flag_property: "test",
                    "amount": 15 if country == "US" else 25,
                },
            )

        flush_persons_and_events()

        query_runner = ExperimentQueryRunner(query=experiment_query, team=self.team)
        result = cast(ExperimentQueryResponse, query_runner.calculate())

        # Verify results are grouped by person property breakdown
        self.assertIsNotNone(result.baseline)
        self.assertIsNotNone(result.variant_results)

        # Verify breakdown_results is populated
        self.assertIsNotNone(result.breakdown_results)
        assert result.breakdown_results is not None
        self.assertEqual(len(result.breakdown_results), 2)  # US and UK

        # Verify each breakdown has correct structure
        for breakdown_result in result.breakdown_results:
            self.assertIn(breakdown_result.breakdown_value, [["US"], ["UK"]])
            self.assertIsNotNone(breakdown_result.baseline)
            self.assertIsNotNone(breakdown_result.variants)
            self.assertGreater(len(breakdown_result.variants), 0)

            # Verify each variant has data
            for variant in breakdown_result.variants:
                self.assertIsNotNone(variant.key)
                self.assertIsNotNone(variant.number_of_samples)
                self.assertEqual(variant.number_of_samples, 2)  # 2 users per country per variant

    @freeze_time("2020-01-01T12:00:00Z")
    @snapshot_clickhouse_queries
    def test_mean_metric_with_null_person_property_breakdown(self):
        """Test that NULL person properties are handled correctly with BREAKDOWN_NULL_STRING_LABEL"""
        feature_flag = self.create_feature_flag()
        experiment = self.create_experiment(feature_flag=feature_flag)
        experiment.stats_config = {"method": "frequentist"}
        experiment.save()

        metric = ExperimentMeanMetric(
            source=EventsNode(
                event="purchase",
                math=ExperimentMetricMathType.SUM,
                math_property="amount",
            ),
            breakdownFilter=BreakdownFilter(breakdowns=[Breakdown(property="country", type="person")]),
        )

        experiment_query = ExperimentQuery(
            experiment_id=experiment.id,
            kind="ExperimentQuery",
            metric=metric,
        )

        experiment.metrics = [metric.model_dump(mode="json")]
        experiment.save()

        feature_flag_property = f"$feature/{feature_flag.key}"

        # Control group - 1 user with country, 1 without
        _create_person(distinct_ids=["user_control_with_country"], team_id=self.team.pk, properties={"country": "US"})
        _create_event(
            team=self.team,
            event="$feature_flag_called",
            distinct_id="user_control_with_country",
            timestamp="2020-01-02T12:00:00Z",
            properties={
                feature_flag_property: "control",
                "$feature_flag_response": "control",
                "$feature_flag": feature_flag.key,
            },
        )
        _create_event(
            team=self.team,
            event="purchase",
            distinct_id="user_control_with_country",
            timestamp="2020-01-02T12:01:00Z",
            properties={
                feature_flag_property: "control",
                "amount": 10,
            },
        )

        _create_person(
            distinct_ids=["user_control_no_country"],
            team_id=self.team.pk,
            properties={},  # No country property
        )
        _create_event(
            team=self.team,
            event="$feature_flag_called",
            distinct_id="user_control_no_country",
            timestamp="2020-01-02T12:00:00Z",
            properties={
                feature_flag_property: "control",
                "$feature_flag_response": "control",
                "$feature_flag": feature_flag.key,
            },
        )
        _create_event(
            team=self.team,
            event="purchase",
            distinct_id="user_control_no_country",
            timestamp="2020-01-02T12:01:00Z",
            properties={
                feature_flag_property: "control",
                "amount": 20,
            },
        )

        flush_persons_and_events()

        query_runner = ExperimentQueryRunner(query=experiment_query, team=self.team)
        result = cast(ExperimentQueryResponse, query_runner.calculate())

        # Verify breakdown_results includes both US and NULL
        self.assertIsNotNone(result.breakdown_results)
        assert result.breakdown_results is not None
        self.assertEqual(len(result.breakdown_results), 2)  # US and NULL

        breakdown_values = [br.breakdown_value for br in result.breakdown_results]
        self.assertIn(["US"], breakdown_values)
        self.assertIn([BREAKDOWN_NULL_STRING_LABEL], breakdown_values)

    @freeze_time("2020-01-01T12:00:00Z")
    @snapshot_clickhouse_queries
    def test_funnel_metric_with_person_property_breakdown(self):
        """Test that funnel metrics can be broken down by person properties"""
        feature_flag = self.create_feature_flag()
        experiment = self.create_experiment(feature_flag=feature_flag)
        experiment.stats_config = {"method": "frequentist"}
        experiment.save()

        metric = ExperimentFunnelMetric(
            series=[
                EventsNode(event="$pageview"),
                EventsNode(event="purchase"),
            ],
            conversion_window=14,
            conversion_window_unit=FunnelConversionWindowTimeUnit.DAY,
            funnel_order_type=StepOrderValue.ORDERED,
            breakdownFilter=BreakdownFilter(breakdowns=[Breakdown(property="country", type="person")]),
        )

        experiment_query = ExperimentQuery(
            experiment_id=experiment.id,
            kind="ExperimentQuery",
            metric=metric,
        )

        experiment.metrics = [metric.model_dump(mode="json")]
        experiment.save()

        feature_flag_property = f"$feature/{feature_flag.key}"

        # Control group - users from different countries
        for i in range(4):
            country = "US" if i < 2 else "UK"
            _create_person(distinct_ids=[f"user_control_{i}"], team_id=self.team.pk, properties={"country": country})
            _create_event(
                team=self.team,
                event="$feature_flag_called",
                distinct_id=f"user_control_{i}",
                timestamp="2020-01-02T12:00:00Z",
                properties={
                    feature_flag_property: "control",
                    "$feature_flag_response": "control",
                    "$feature_flag": feature_flag.key,
                },
            )
            _create_event(
                team=self.team,
                event="$pageview",
                distinct_id=f"user_control_{i}",
                timestamp="2020-01-02T12:01:00Z",
                properties={feature_flag_property: "control"},
            )
            # Only first user in each country completes funnel
            if i % 2 == 0:
                _create_event(
                    team=self.team,
                    event="purchase",
                    distinct_id=f"user_control_{i}",
                    timestamp="2020-01-02T12:02:00Z",
                    properties={feature_flag_property: "control"},
                )

        flush_persons_and_events()

        query_runner = ExperimentQueryRunner(query=experiment_query, team=self.team)
        result = cast(ExperimentQueryResponse, query_runner.calculate())

        # Verify breakdown_results is populated
        self.assertIsNotNone(result.breakdown_results)
        assert result.breakdown_results is not None
        self.assertEqual(len(result.breakdown_results), 2)  # US and UK

        # Verify each breakdown has correct conversion rates
        for breakdown_result in result.breakdown_results:
            self.assertIn(breakdown_result.breakdown_value, [["US"], ["UK"]])
            self.assertIsNotNone(breakdown_result.baseline)
            # 1 out of 2 users converted in each country
            self.assertEqual(breakdown_result.baseline.number_of_samples, 2)

    @freeze_time("2020-01-01T12:00:00Z")
    @snapshot_clickhouse_queries
    def test_mean_metric_with_null_type_defaults_to_event_breakdown(self):
        """Test backward compatibility: type=None defaults to event property"""
        feature_flag = self.create_feature_flag()
        experiment = self.create_experiment(feature_flag=feature_flag)
        experiment.stats_config = {"method": "frequentist"}
        experiment.save()

        # One breakdown with explicit type="event", one with type=None (should default to event)
        metric = ExperimentMeanMetric(
            source=EventsNode(
                event="purchase",
                math=ExperimentMetricMathType.SUM,
                math_property="amount",
            ),
            breakdownFilter=BreakdownFilter(
                breakdowns=[
                    Breakdown(property="$browser", type="event"),
                    Breakdown(property="$current_url", type=None),  # Should default to event
                ]
            ),
        )

        experiment_query = ExperimentQuery(
            experiment_id=experiment.id,
            kind="ExperimentQuery",
            metric=metric,
        )

        experiment.metrics = [metric.model_dump(mode="json")]
        experiment.save()

        feature_flag_property = f"$feature/{feature_flag.key}"

        # Create test data
        _create_person(distinct_ids=["user_1"], team_id=self.team.pk)
        _create_event(
            team=self.team,
            event="$feature_flag_called",
            distinct_id="user_1",
            timestamp="2020-01-02T12:00:00Z",
            properties={
                feature_flag_property: "control",
                "$feature_flag_response": "control",
                "$feature_flag": feature_flag.key,
                "$browser": "Chrome",
                "$current_url": "https://example.com",
            },
        )
        _create_event(
            team=self.team,
            event="purchase",
            distinct_id="user_1",
            timestamp="2020-01-02T12:01:00Z",
            properties={
                feature_flag_property: "control",
                "amount": 10,
                "$browser": "Chrome",
                "$current_url": "https://example.com",
            },
        )

        flush_persons_and_events()

        query_runner = ExperimentQueryRunner(query=experiment_query, team=self.team)
        result = cast(ExperimentQueryResponse, query_runner.calculate())

        # Query should complete successfully
        self.assertIsNotNone(result.baseline)
        self.assertIsNotNone(result.breakdown_results)
        assert result.breakdown_results is not None
        # Should have breakdown combinations for browser x url
        self.assertGreater(len(result.breakdown_results), 0)

    @freeze_time("2020-01-01T12:00:00Z")
    @snapshot_clickhouse_queries
    def test_ratio_metric_with_person_property_breakdown(self):
        """Test that ratio metrics can be broken down by person properties"""
        feature_flag = self.create_feature_flag()
        experiment = self.create_experiment(feature_flag=feature_flag)
        experiment.stats_config = {"method": "frequentist"}
        experiment.save()

        metric = ExperimentRatioMetric(
            numerator=EventsNode(event="purchase"),
            denominator=EventsNode(event="$pageview"),
            breakdownFilter=BreakdownFilter(breakdowns=[Breakdown(property="country", type="person")]),
        )

        experiment_query = ExperimentQuery(
            experiment_id=experiment.id,
            kind="ExperimentQuery",
            metric=metric,
        )

        experiment.metrics = [metric.model_dump(mode="json")]
        experiment.save()

        feature_flag_property = f"$feature/{feature_flag.key}"

        # Control group - users from different countries with different conversion rates
        for i in range(4):
            country = "US" if i < 2 else "UK"
            _create_person(distinct_ids=[f"user_control_{i}"], team_id=self.team.pk, properties={"country": country})
            _create_event(
                team=self.team,
                event="$feature_flag_called",
                distinct_id=f"user_control_{i}",
                timestamp="2020-01-02T12:00:00Z",
                properties={
                    feature_flag_property: "control",
                    "$feature_flag_response": "control",
                    "$feature_flag": feature_flag.key,
                },
            )
            # All users see pageviews
            _create_event(
                team=self.team,
                event="$pageview",
                distinct_id=f"user_control_{i}",
                timestamp="2020-01-02T12:01:00Z",
                properties={feature_flag_property: "control"},
            )
            # Only first user in each country makes a purchase
            if i % 2 == 0:
                _create_event(
                    team=self.team,
                    event="purchase",
                    distinct_id=f"user_control_{i}",
                    timestamp="2020-01-02T12:02:00Z",
                    properties={feature_flag_property: "control"},
                )

        # Test group - users from different countries
        for i in range(4):
            country = "US" if i < 2 else "UK"
            _create_person(distinct_ids=[f"user_test_{i}"], team_id=self.team.pk, properties={"country": country})
            _create_event(
                team=self.team,
                event="$feature_flag_called",
                distinct_id=f"user_test_{i}",
                timestamp="2020-01-02T12:00:00Z",
                properties={
                    feature_flag_property: "test",
                    "$feature_flag_response": "test",
                    "$feature_flag": feature_flag.key,
                },
            )
            # All users see pageviews
            _create_event(
                team=self.team,
                event="$pageview",
                distinct_id=f"user_test_{i}",
                timestamp="2020-01-02T12:01:00Z",
                properties={feature_flag_property: "test"},
            )
            # Both users in each country make a purchase
            _create_event(
                team=self.team,
                event="purchase",
                distinct_id=f"user_test_{i}",
                timestamp="2020-01-02T12:02:00Z",
                properties={feature_flag_property: "test"},
            )

        flush_persons_and_events()

        query_runner = ExperimentQueryRunner(query=experiment_query, team=self.team)
        result = cast(ExperimentQueryResponse, query_runner.calculate())

        # Verify breakdown_results is populated
        self.assertIsNotNone(result.breakdown_results)
        assert result.breakdown_results is not None
        self.assertEqual(len(result.breakdown_results), 2)  # US and UK

        # Verify each breakdown has correct structure
        for breakdown_result in result.breakdown_results:
            self.assertIn(breakdown_result.breakdown_value, [["US"], ["UK"]])
            self.assertIsNotNone(breakdown_result.baseline)
            self.assertIsNotNone(breakdown_result.variants)
            self.assertGreater(len(breakdown_result.variants), 0)

    @freeze_time("2020-01-01T12:00:00Z")
    @snapshot_clickhouse_queries
    def test_retention_metric_with_person_property_breakdown(self):
        """Test that retention metrics can be broken down by person properties"""
        feature_flag = self.create_feature_flag()
        experiment = self.create_experiment(feature_flag=feature_flag)
        experiment.stats_config = {"method": "frequentist"}
        experiment.save()

        metric = ExperimentRetentionMetric(
            start_event=EventsNode(event="signup"),
            completion_event=EventsNode(event="login"),
            retention_window_start=1,
            retention_window_end=7,
            retention_window_unit=FunnelConversionWindowTimeUnit.DAY,
            start_handling=StartHandling.FIRST_SEEN,
            breakdownFilter=BreakdownFilter(breakdowns=[Breakdown(property="country", type="person")]),
        )

        experiment_query = ExperimentQuery(
            experiment_id=experiment.id,
            kind="ExperimentQuery",
            metric=metric,
        )

        experiment.metrics = [metric.model_dump(mode="json")]
        experiment.save()

        feature_flag_property = f"$feature/{feature_flag.key}"

        # Control group - users from different countries with different retention
        for i in range(4):
            country = "US" if i < 2 else "UK"
            _create_person(distinct_ids=[f"user_control_{i}"], team_id=self.team.pk, properties={"country": country})
            # Exposure
            _create_event(
                team=self.team,
                event="$feature_flag_called",
                distinct_id=f"user_control_{i}",
                timestamp="2020-01-02T12:00:00Z",
                properties={
                    feature_flag_property: "control",
                    "$feature_flag_response": "control",
                    "$feature_flag": feature_flag.key,
                },
            )
            # Start event (day 0)
            _create_event(
                team=self.team,
                event="signup",
                distinct_id=f"user_control_{i}",
                timestamp="2020-01-02T12:01:00Z",
                properties={feature_flag_property: "control"},
            )
            # Return event (day 1) - only first user in each country returns
            if i % 2 == 0:
                _create_event(
                    team=self.team,
                    event="login",
                    distinct_id=f"user_control_{i}",
                    timestamp="2020-01-03T12:01:00Z",
                    properties={feature_flag_property: "control"},
                )

        # Test group - users from different countries
        for i in range(4):
            country = "US" if i < 2 else "UK"
            _create_person(distinct_ids=[f"user_test_{i}"], team_id=self.team.pk, properties={"country": country})
            # Exposure
            _create_event(
                team=self.team,
                event="$feature_flag_called",
                distinct_id=f"user_test_{i}",
                timestamp="2020-01-02T12:00:00Z",
                properties={
                    feature_flag_property: "test",
                    "$feature_flag_response": "test",
                    "$feature_flag": feature_flag.key,
                },
            )
            # Start event (day 0)
            _create_event(
                team=self.team,
                event="signup",
                distinct_id=f"user_test_{i}",
                timestamp="2020-01-02T12:01:00Z",
                properties={feature_flag_property: "test"},
            )
            # Return event (day 1) - all test users return
            _create_event(
                team=self.team,
                event="login",
                distinct_id=f"user_test_{i}",
                timestamp="2020-01-03T12:01:00Z",
                properties={feature_flag_property: "test"},
            )

        flush_persons_and_events()

        query_runner = ExperimentQueryRunner(query=experiment_query, team=self.team)
        result = cast(ExperimentQueryResponse, query_runner.calculate())

        # Verify breakdown_results is populated
        self.assertIsNotNone(result.breakdown_results)
        assert result.breakdown_results is not None
        self.assertEqual(len(result.breakdown_results), 2)  # US and UK

        # Verify each breakdown has correct structure
        for breakdown_result in result.breakdown_results:
            self.assertIn(breakdown_result.breakdown_value, [["US"], ["UK"]])
            self.assertIsNotNone(breakdown_result.baseline)
            self.assertIsNotNone(breakdown_result.variants)
            self.assertGreater(len(breakdown_result.variants), 0)

    @freeze_time("2020-01-01T12:00:00Z")
    @snapshot_clickhouse_queries
    def test_person_property_breakdown_attribution_at_exposure(self):
        """
        Test that person properties are attributed from the PERSON at exposure time,
        not from the event. This is critical because person properties can change over time.
        """
        feature_flag = self.create_feature_flag()
        experiment = self.create_experiment(feature_flag=feature_flag)
        experiment.stats_config = {"method": "frequentist"}
        experiment.save()

        metric = ExperimentMeanMetric(
            source=EventsNode(
                event="purchase",
                math=ExperimentMetricMathType.SUM,
                math_property="amount",
            ),
            breakdownFilter=BreakdownFilter(breakdowns=[Breakdown(property="country", type="person")]),
        )

        experiment_query = ExperimentQuery(
            experiment_id=experiment.id,
            kind="ExperimentQuery",
            metric=metric,
        )

        experiment.metrics = [metric.model_dump(mode="json")]
        experiment.save()

        feature_flag_property = f"$feature/{feature_flag.key}"

        # Control user with country = "US"
        _create_person(
            distinct_ids=["user_control"],
            team_id=self.team.pk,
            properties={"country": "US"},
        )

        # Exposure event
        _create_event(
            team=self.team,
            event="$feature_flag_called",
            distinct_id="user_control",
            timestamp="2020-01-02T12:00:00Z",
            properties={
                feature_flag_property: "control",
                "$feature_flag_response": "control",
                "$feature_flag": feature_flag.key,
            },
        )

        # Purchase event - should be attributed to US
        _create_event(
            team=self.team,
            event="purchase",
            distinct_id="user_control",
            timestamp="2020-01-02T12:02:00Z",
            properties={
                feature_flag_property: "control",
                "amount": 100,
            },
        )

        # Test user with country = "UK"
        _create_person(
            distinct_ids=["user_test"],
            team_id=self.team.pk,
            properties={"country": "UK"},
        )

        # Exposure event
        _create_event(
            team=self.team,
            event="$feature_flag_called",
            distinct_id="user_test",
            timestamp="2020-01-02T12:00:00Z",
            properties={
                feature_flag_property: "test",
                "$feature_flag_response": "test",
                "$feature_flag": feature_flag.key,
            },
        )

        # Purchase event - should be attributed to UK
        _create_event(
            team=self.team,
            event="purchase",
            distinct_id="user_test",
            timestamp="2020-01-02T12:02:00Z",
            properties={
                feature_flag_property: "test",
                "amount": 150,
            },
        )

        flush_persons_and_events()

        query_runner = ExperimentQueryRunner(query=experiment_query, team=self.team)
        result = cast(ExperimentQueryResponse, query_runner.calculate())

        # Should have both US and UK breakdowns
        self.assertIsNotNone(result.breakdown_results)
        assert result.breakdown_results is not None
        self.assertEqual(len(result.breakdown_results), 2)

        breakdown_values = [br.breakdown_value for br in result.breakdown_results]
        self.assertIn(["US"], breakdown_values)
        self.assertIn(["UK"], breakdown_values)

        # Verify US breakdown (control user)
        us_breakdown = next((br for br in result.breakdown_results if br.breakdown_value == ["US"]), None)
        self.assertIsNotNone(us_breakdown)
        assert us_breakdown is not None
        self.assertIsNotNone(us_breakdown.baseline)
        self.assertEqual(us_breakdown.baseline.number_of_samples, 1)

        # Verify UK breakdown (test user)
        uk_breakdown = next((br for br in result.breakdown_results if br.breakdown_value == ["UK"]), None)
        self.assertIsNotNone(uk_breakdown)
        assert uk_breakdown is not None
        self.assertIsNotNone(uk_breakdown.variants)
        self.assertEqual(len(uk_breakdown.variants), 1)
        self.assertEqual(uk_breakdown.variants[0].number_of_samples, 1)
