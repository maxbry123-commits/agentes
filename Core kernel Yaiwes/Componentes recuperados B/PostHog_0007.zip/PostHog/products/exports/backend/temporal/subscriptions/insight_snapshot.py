"""Build JSON-serializable insight payloads for subscription delivery history.

``SubscriptionDelivery.content_snapshot`` is built in two layers so the shape
lives here only:

1. :func:`build_initial_content_snapshot` — top-level ``dashboard`` / ``insights`` /
   ``total_insight_count`` when the delivery row is created (minimal per-insight
   rows: ``id``, ``short_id``, ``name``).
2. :func:`build_insight_delivery_snapshot` — per-exported-insight payload (same
   core keys plus ``dashboard_tile_id``, ``query_hash``, cache/results fields).
   The workflow merges these into ``content_snapshot`` on finalize; keep the
   overlapping keys aligned when changing either builder.
"""

from __future__ import annotations

from typing import Any

import orjson
import structlog
from pydantic_core import to_jsonable_python

from posthog.api.services.query import ExecutionMode
from posthog.caching.calculate_results import calculate_cache_key, calculate_for_query_based_insight
from posthog.caching.insight_result import InsightResult, NothingInCacheResult
from posthog.models import Team, User

from products.dashboards.backend.models.dashboard import Dashboard
from products.dashboards.backend.models.dashboard_tile import DashboardTile
from products.exports.backend.models.subscription import Subscription
from products.exports.backend.temporal.subscriptions.delivery_common import strip_null_bytes
from products.exports.backend.temporal.subscriptions.types import safe_error_message
from products.product_analytics.backend.facade.models import Insight

logger = structlog.get_logger(__name__)


def _json_safe_value(val: Any) -> Any:
    """Coerce to JSONField-safe Python (dict/list/scalars); unknown types use fallback, not pass-through."""
    return to_jsonable_python(val, fallback=lambda x: str(x))


def build_initial_content_snapshot(subscription: Subscription) -> dict[str, Any]:
    """Skeleton ``content_snapshot`` persisted when a delivery row is created.

    Must stay consistent with the keys :func:`build_insight_delivery_snapshot`
    sets for each insight (``id``, ``short_id``, ``name``).
    """
    content_snapshot: dict[str, Any] = {
        "dashboard": None,
        "insights": [],
        "total_insight_count": 0,
    }
    if subscription.dashboard:
        content_snapshot["dashboard"] = {
            "id": subscription.dashboard.id,
            "name": subscription.dashboard.name,
        }
    if subscription.insight:
        content_snapshot["insights"] = [
            {
                "id": subscription.insight.id,
                "short_id": str(subscription.insight.short_id),
                "name": subscription.insight.name or subscription.insight.derived_name or "",
                "description": subscription.insight.description or "",
            }
        ]
    return content_snapshot


def _serialize_insight_result(result: InsightResult) -> dict[str, Any]:
    # Coerce NaN / ±Inf to null via orjson — Postgres JSONB rejects the bare tokens that stdlib
    # json.dumps (Django JSONField's default encoder) emits for non-finite floats.
    # `default=str` covers types orjson doesn't serialize natively (notably Decimal) the way
    # DjangoJSONEncoder would have, so switching encoders is a no-op for non-finite-float payloads.
    dumped = orjson.dumps(
        {
            "result": result.result,
            "columns": result.columns,
            "types": result.types,
            "resolved_date_range": _json_safe_value(result.resolved_date_range),
            "last_refresh": result.last_refresh.isoformat() if result.last_refresh else None,
            "is_cached": result.is_cached,
            "timezone": result.timezone,
            "has_more": result.has_more,
            "query_status": _json_safe_value(result.query_status),
        },
        default=str,
    )
    parsed = orjson.loads(dumped)
    # Query results can carry NUL bytes from upstream data, and Django's JSONField serializes a NUL
    # to a unicode escape that Postgres text/jsonb columns reject — failing the whole delivery write
    # with a DataError. So we strip NUL before returning, but only when one is actually present:
    #
    # - Cost: result.result is arbitrary ClickHouse output and can reach several MB; strip_null_bytes
    #   rebuilds the entire dict/list tree, so running it on every delivery (nearly none carry a NUL)
    #   would be pure waste. The gate is a single byte scan over the buffer we already serialized.
    # - Correctness: orjson always emits a real NUL as an escape sequence (JSON forbids a raw control
    #   byte), including inside object keys, so the check never misses a genuine NUL. It can only
    #   over-trigger on literal escape text in the data, which is harmless — the walk then finds none.
    #
    # The AI-report path scrubs unconditionally instead, since those payloads are small (see
    # delivery_common.strip_null_bytes callers).
    if b"\\u0000" in dumped:
        parsed = strip_null_bytes(parsed)
    return parsed


def _insight_snapshot_base_metadata(*, insight: Insight, tile: DashboardTile | None) -> dict[str, Any]:
    return {
        "id": insight.id,
        "short_id": str(insight.short_id),
        "name": insight.name or insight.derived_name or "",
        "description": insight.description or "",
        "dashboard_tile_id": tile.id if tile is not None else None,
    }


def _default_query_hash(*, tile: DashboardTile | None, insight: Insight) -> str | None:
    """Best-effort hash from layout target before execution (may be replaced by ``cache_key`` later)."""
    cache_target: DashboardTile | Insight = tile if tile is not None else insight
    query_hash = calculate_cache_key(cache_target)
    if query_hash is None:
        query_hash = insight.filters_hash
    return query_hash


def _resolve_effective_query_json(insight: Insight, dashboard: Dashboard | None) -> Any | None:
    query_json = insight.get_effective_query(dashboard=dashboard)
    if query_json is None:
        query_json = insight.query
    if query_json is None:
        query_json = insight.query_from_filters
    return query_json


def _extract_value_format(query_json: Any) -> dict[str, Any] | None:
    """Pull the trends Y-axis format (duration, percentage, prefix/postfix) from a query.

    The summarizer uses this to render metric values the way the chart does, so the AI
    summary reads "4d 4h" instead of a raw "360000". Returns None when no non-default
    format is configured. Mirrors the trendsFilter fields read by
    frontend/src/scenes/insights/aggregationAxisFormat.ts.
    """
    if not isinstance(query_json, dict):
        return None
    source = query_json.get("source", query_json)
    if not isinstance(source, dict):
        return None
    trends_filter = source.get("trendsFilter")
    if not isinstance(trends_filter, dict):
        return None

    axis_format = trends_filter.get("aggregationAxisFormat")
    prefix = trends_filter.get("aggregationAxisPrefix")
    postfix = trends_filter.get("aggregationAxisPostfix")
    value_format: dict[str, Any] = {}
    if axis_format:
        value_format["format"] = axis_format
    if prefix:
        value_format["prefix"] = prefix
    if postfix:
        value_format["postfix"] = postfix
    return value_format or None


def _has_comparison_enabled(query_json: Any) -> bool:
    """True if the insight has 'Compare to previous period' turned on.

    Used to help the AI summary suggest enabling the overlay when it would
    make the insight easier to interpret, without nagging when it is already
    configured. Handles TrendsQuery / LifecycleQuery / StickinessQuery and
    the DataVisualizationNode wrapper shape.
    """
    if not isinstance(query_json, dict):
        return False
    source = query_json.get("source", query_json)
    if not isinstance(source, dict):
        return False
    compare_filter = source.get("compareFilter")
    return bool(isinstance(compare_filter, dict) and compare_filter.get("compare"))


def _execute_and_serialize_insight_query(
    *,
    insight: Insight,
    team: Team,
    dashboard: Dashboard | None,
    user: User | None,
    query_json: Any,
) -> dict[str, Any]:
    """Run cache/calculate path and return snapshot fields to merge (``query_*`` / ``cache_key`` only)."""
    try:
        insight_result = calculate_for_query_based_insight(
            insight,
            team=team,
            dashboard=dashboard,
            execution_mode=ExecutionMode.RECENT_CACHE_CALCULATE_BLOCKING_IF_STALE,
            user=user,
            query_override=query_json,
        )
    except Exception as e:
        logger.exception(
            "subscription_insight_snapshot.query_failed",
            insight_id=insight.id,
            team_id=team.id,
        )
        return {
            "query_results": None,
            "cache_key": None,
            # str(e) can echo offending query data, so scrub it like the result payload. The UI
            # renders human_readable_error (safe subset) instead of message.
            "query_error": {
                "type": type(e).__name__,
                "message": strip_null_bytes(str(e)),
                "human_readable_error": safe_error_message(e),
            },
        }

    if isinstance(insight_result, NothingInCacheResult):
        out: dict[str, Any] = {
            "query_results": None,
            "query_error": {
                "type": "cache_miss",
                "message": "No synchronous result (async or cache-only response)",
                # Static, audience-safe: a cold cache is a routine condition, not an internal error.
                "human_readable_error": "No cached result was available for this insight.",
            },
        }
        if insight_result.cache_key:
            out["query_hash"] = insight_result.cache_key
            out["cache_key"] = insight_result.cache_key
        else:
            out["cache_key"] = None
        return out

    ck = insight_result.cache_key
    out = {
        "query_results": _serialize_insight_result(insight_result),
        "cache_key": ck,
    }
    if ck:
        out["query_hash"] = ck
    return out


def build_insight_delivery_snapshot(
    *,
    insight: Insight,
    team: Team,
    dashboard: Dashboard | None,
    tile: DashboardTile | None,
    user: User | None,
) -> dict[str, Any]:
    """Metadata + query hash + serialized query results for one exported insight.

    Core fields (``id``, ``short_id``, ``name``) match :func:`build_initial_content_snapshot`
    so workflow merges do not contradict the row created at delivery start.
    """
    base = _insight_snapshot_base_metadata(insight=insight, tile=tile)
    base["query_hash"] = _default_query_hash(tile=tile, insight=insight)

    query_json = _resolve_effective_query_json(insight, dashboard)
    if query_json is None:
        base["query_results"] = None
        base["cache_key"] = None
        base["query_error"] = {
            "type": "missing_query",
            "message": "Insight has no query or convertible filters",
            "human_readable_error": "This insight has no query to run.",
        }
        base["comparison_enabled"] = False
        base["value_format"] = None
        return base

    base["comparison_enabled"] = _has_comparison_enabled(query_json)
    base["value_format"] = _extract_value_format(query_json)
    base.update(
        _execute_and_serialize_insight_query(
            insight=insight,
            team=team,
            dashboard=dashboard,
            user=user,
            query_json=query_json,
        )
    )
    return base
