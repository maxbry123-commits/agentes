import os
from collections.abc import Generator
from datetime import datetime
from io import BytesIO
from typing import Any, Optional

import pytest
from freezegun import freeze_time
from posthog.test.base import APIBaseTest, _create_event, _create_person, flush_persons_and_events
from unittest import mock
from unittest.mock import ANY, MagicMock, Mock, patch

from django.test import override_settings
from django.utils.timezone import now

import jwt
from boto3 import resource
from botocore.client import Config
from dateutil.relativedelta import relativedelta
from openpyxl import load_workbook
from requests.exceptions import HTTPError

from posthog.hogql.constants import CSV_EXPORT_BREAKDOWN_LIMIT_INITIAL

from posthog.jwt import PosthogJwtAudience, decode_jwt
from posthog.models.personal_api_key import PersonalAPIKey
from posthog.models.utils import UUIDT, generate_random_token_personal, hash_key_value
from posthog.security.spreadsheet_safety import sanitize_formula_injection
from posthog.settings import (
    OBJECT_STORAGE_ACCESS_KEY_ID,
    OBJECT_STORAGE_BUCKET,
    OBJECT_STORAGE_ENDPOINT,
    OBJECT_STORAGE_SECRET_ACCESS_KEY,
)
from posthog.storage import object_storage
from posthog.storage.object_storage import ObjectStorageError
from posthog.test.test_journeys import journeys_for
from posthog.utils import absolute_uri

from products.actions.backend.models.action import Action
from products.exports.backend.models.exported_asset import ExportedAsset
from products.exports.backend.source_authentication import assert_export_authorization
from products.exports.backend.tasks import csv_exporter
from products.exports.backend.tasks.csv_exporter import (
    CsvWriter,
    ExcelWriter,
    UnexpectedEmptyJsonResponse,
    _convert_response_to_csv_data,
    _format_breakdown_value,
    add_query_params,
    sanitize_value_for_excel,
)
from products.exports.backend.tasks.failure_handler import ExcelColumnLimitExceeded

TEST_PREFIX = "Test-Exports"

# see GitHub issue #11204
regression_11204 = "api/projects/6642/insights/trend/?events=%5B%7B%22id%22%3A%22product%20viewed%22%2C%22name%22%3A%22product%20viewed%22%2C%22type%22%3A%22events%22%2C%22order%22%3A0%7D%5D&actions=%5B%5D&display=ActionsTable&insight=TRENDS&interval=day&breakdown=productName&new_entity=%5B%5D&properties=%5B%5D&step_limit=5&funnel_filter=%7B%7D&breakdown_type=event&exclude_events=%5B%5D&path_groupings=%5B%5D&include_event_types=%5B%22%24pageview%22%5D&filter_test_accounts=false&local_path_cleaning_filters=%5B%5D&date_from=-14d&offset=50"


@override_settings(SITE_URL="http://testserver")
class TestCSVExporter(APIBaseTest):
    @pytest.fixture(autouse=True)
    def patched_request(self) -> Generator[Any]:
        with patch("products.exports.backend.tasks.csv_exporter.requests.request") as patched_request:
            mock_response = Mock()
            mock_response.status_code = 200
            # API responses copied from https://github.com/PostHog/posthog/runs/7221634689?check_suite_focus=true
            mock_response.json.side_effect = [
                {
                    "next": "http://testserver/api/projects/169/events?orderBy=%5B%22-timestamp%22%5D&properties=%5B%7B%22key%22%3A%22%24browser%22%2C%22value%22%3A%5B%22Safari%22%5D%2C%22operator%22%3A%22exact%22%2C%22type%22%3A%22event%22%7D%5D&after=2022-07-06T19%3A27%3A43.206326&limit=1&before=2022-07-06T19%3A37%3A43.095295%2B00%3A00",
                    "results": [
                        {
                            "id": "e9ca132e-400f-4854-a83c-16c151b2f145",
                            "distinct_id": "2",
                            "properties": {"$browser": "Safari"},
                            "event": "event_name",
                            "timestamp": "2022-07-06T19:37:43.095295+00:00",
                            "person": None,
                            "elements": [],
                            "elements_chain": "",
                        }
                    ],
                },
                {
                    "next": "http://testserver/api/projects/169/events?orderBy=%5B%22-timestamp%22%5D&properties=%5B%7B%22key%22%3A%22%24browser%22%2C%22value%22%3A%5B%22Safari%22%5D%2C%22operator%22%3A%22exact%22%2C%22type%22%3A%22event%22%7D%5D&after=2022-07-06T19%3A27%3A43.206326&limit=1&before=2022-07-06T19%3A37%3A43.095279%2B00%3A00",
                    "results": [
                        {
                            "id": "1624228e-a4f1-48cd-aabc-6baa3ddb22e4",
                            "distinct_id": "2",
                            "properties": {"$browser": "Safari"},
                            "event": "event_name",
                            "timestamp": "2022-07-06T19:37:43.095279+00:00",
                            "person": None,
                            "elements": [],
                            "elements_chain": "",
                        }
                    ],
                },
                {
                    "next": None,
                    "results": [
                        {
                            "id": "66d45914-bdf5-4980-a54a-7dc699bdcce9",
                            "distinct_id": "2",
                            "properties": {"$browser": "Safari"},
                            "event": "event_name",
                            "timestamp": "2022-07-06T19:37:43.095262+00:00",
                            "person": None,
                            "elements": [],
                            "elements_chain": "",
                        }
                    ],
                },
            ]
            patched_request.return_value = mock_response
            yield patched_request

    def _create_asset(self, extra_context: Optional[dict] = None) -> ExportedAsset:
        extra_context = extra_context or {}

        asset = ExportedAsset(
            team=self.team,
            created_by=self.user,
            export_format=ExportedAsset.ExportFormat.CSV,
            export_context={"path": "/api/literally/anything", **extra_context},
            source_authentication=ExportedAsset.SourceAuthentication.SESSION,
        )
        asset.save()
        return asset

    def _split_to_dict(self, url: str) -> dict[str, Any]:
        first_split_parts = url.split("?")
        assert len(first_split_parts) == 2
        return {bits[0]: bits[1] for bits in [param.split("=") for param in first_split_parts[1].split("&")]}

    def teardown_method(self, method: Any) -> None:
        s3 = resource(
            "s3",
            endpoint_url=OBJECT_STORAGE_ENDPOINT,
            aws_access_key_id=OBJECT_STORAGE_ACCESS_KEY_ID,
            aws_secret_access_key=OBJECT_STORAGE_SECRET_ACCESS_KEY,
            config=Config(signature_version="s3v4"),
            region_name="us-east-1",
        )
        bucket = s3.Bucket(OBJECT_STORAGE_BUCKET)
        bucket.objects.filter(Prefix=TEST_PREFIX).delete()

    def test_csv_exporter_writes_to_asset_when_object_storage_is_disabled(self) -> None:
        exported_asset = self._create_asset()
        with self.settings(OBJECT_STORAGE_ENABLED=False):
            csv_exporter.export_tabular(exported_asset)

            assert (
                exported_asset.content
                == b"id,distinct_id,properties.$browser,event,timestamp,person,elements_chain\r\ne9ca132e-400f-4854-a83c-16c151b2f145,2,Safari,event_name,2022-07-06T19:37:43.095295+00:00,,\r\n1624228e-a4f1-48cd-aabc-6baa3ddb22e4,2,Safari,event_name,2022-07-06T19:37:43.095279+00:00,,\r\n66d45914-bdf5-4980-a54a-7dc699bdcce9,2,Safari,event_name,2022-07-06T19:37:43.095262+00:00,,\r\n"
            )
            assert exported_asset.content_location is None

    @patch("products.exports.backend.models.exported_asset.UUIDT")
    def test_csv_exporter_writes_to_object_storage_when_object_storage_is_enabled(self, mocked_uuidt: Any) -> None:
        exported_asset = self._create_asset()
        mocked_uuidt.return_value = "a-guid"

        with self.settings(OBJECT_STORAGE_ENABLED=True, OBJECT_STORAGE_EXPORTS_FOLDER="Test-Exports"):
            csv_exporter.export_tabular(exported_asset)

            assert (
                exported_asset.content_location
                == f"{TEST_PREFIX}/csv/team-{self.team.id}/task-{exported_asset.id}/a-guid"
            )

            assert exported_asset.content_location is not None
            content = object_storage.read(exported_asset.content_location)
            assert (
                content
                == "id,distinct_id,properties.$browser,event,timestamp,person,elements_chain\r\ne9ca132e-400f-4854-a83c-16c151b2f145,2,Safari,event_name,2022-07-06T19:37:43.095295+00:00,,\r\n1624228e-a4f1-48cd-aabc-6baa3ddb22e4,2,Safari,event_name,2022-07-06T19:37:43.095279+00:00,,\r\n66d45914-bdf5-4980-a54a-7dc699bdcce9,2,Safari,event_name,2022-07-06T19:37:43.095262+00:00,,\r\n"
            )

            assert exported_asset.content is None

    @patch("products.exports.backend.models.exported_asset.UUIDT")
    @patch("products.exports.backend.models.exported_asset.object_storage.write_from_file")
    def test_csv_exporter_writes_to_asset_when_object_storage_write_fails(
        self, mocked_object_storage_write_from_file: Any, mocked_uuidt: Any
    ) -> None:
        exported_asset = self._create_asset()
        mocked_uuidt.return_value = "a-guid"
        mocked_object_storage_write_from_file.side_effect = ObjectStorageError("mock write failed")

        with self.settings(OBJECT_STORAGE_ENABLED=True, OBJECT_STORAGE_EXPORTS_FOLDER="Test-Exports"):
            csv_exporter.export_tabular(exported_asset)

            assert exported_asset.content_location is None

            assert (
                exported_asset.content
                == b"id,distinct_id,properties.$browser,event,timestamp,person,elements_chain\r\ne9ca132e-400f-4854-a83c-16c151b2f145,2,Safari,event_name,2022-07-06T19:37:43.095295+00:00,,\r\n1624228e-a4f1-48cd-aabc-6baa3ddb22e4,2,Safari,event_name,2022-07-06T19:37:43.095279+00:00,,\r\n66d45914-bdf5-4980-a54a-7dc699bdcce9,2,Safari,event_name,2022-07-06T19:37:43.095262+00:00,,\r\n"
            )

    @patch("products.exports.backend.models.exported_asset.UUIDT")
    @patch("products.exports.backend.models.exported_asset.object_storage.write_from_file")
    def test_csv_exporter_does_not_filter_columns_on_empty_param(
        self, mocked_object_storage_write_from_file: Any, mocked_uuidt: Any
    ) -> None:
        exported_asset = self._create_asset({"columns": []})
        mocked_uuidt.return_value = "a-guid"
        mocked_object_storage_write_from_file.side_effect = ObjectStorageError("mock write failed")

        with self.settings(OBJECT_STORAGE_ENABLED=True, OBJECT_STORAGE_EXPORTS_FOLDER="Test-Exports"):
            csv_exporter.export_tabular(exported_asset)

            assert exported_asset.content_location is None

            assert (
                exported_asset.content
                == b"id,distinct_id,properties.$browser,event,timestamp,person,elements_chain\r\ne9ca132e-400f-4854-a83c-16c151b2f145,2,Safari,event_name,2022-07-06T19:37:43.095295+00:00,,\r\n1624228e-a4f1-48cd-aabc-6baa3ddb22e4,2,Safari,event_name,2022-07-06T19:37:43.095279+00:00,,\r\n66d45914-bdf5-4980-a54a-7dc699bdcce9,2,Safari,event_name,2022-07-06T19:37:43.095262+00:00,,\r\n"
            )

    @patch("products.exports.backend.models.exported_asset.UUIDT")
    @patch("products.exports.backend.models.exported_asset.object_storage.write_from_file")
    def test_csv_exporter_does_filter_columns(
        self, mocked_object_storage_write_from_file: Any, mocked_uuidt: Any
    ) -> None:
        # NB these columns are not in the "natural" order
        exported_asset = self._create_asset({"columns": ["distinct_id", "properties.$browser", "event"]})
        mocked_uuidt.return_value = "a-guid"
        mocked_object_storage_write_from_file.side_effect = ObjectStorageError("mock write failed")

        with self.settings(OBJECT_STORAGE_ENABLED=True, OBJECT_STORAGE_EXPORTS_FOLDER="Test-Exports"):
            csv_exporter.export_tabular(exported_asset)

            assert exported_asset.content_location is None

            assert (
                exported_asset.content
                == b"distinct_id,properties.$browser,event\r\n2,Safari,event_name\r\n2,Safari,event_name\r\n2,Safari,event_name\r\n"
            )

    @patch("products.exports.backend.models.exported_asset.UUIDT")
    @patch("products.exports.backend.models.exported_asset.object_storage.write_from_file")
    def test_csv_exporter_includes_whole_dict(
        self, mocked_object_storage_write_from_file: Any, mocked_uuidt: Any
    ) -> None:
        exported_asset = self._create_asset({"columns": ["distinct_id", "properties"]})
        mocked_uuidt.return_value = "a-guid"
        mocked_object_storage_write_from_file.side_effect = ObjectStorageError("mock write failed")

        with self.settings(OBJECT_STORAGE_ENABLED=True, OBJECT_STORAGE_EXPORTS_FOLDER="Test-Exports"):
            csv_exporter.export_tabular(exported_asset)

            assert exported_asset.content_location is None

            assert exported_asset.content == b"distinct_id,properties.$browser\r\n2,Safari\r\n2,Safari\r\n2,Safari\r\n"

    @patch("products.exports.backend.models.exported_asset.UUIDT")
    @patch("products.exports.backend.models.exported_asset.object_storage.write_from_file")
    def test_csv_exporter_includes_whole_dict_alternative_order(
        self, mocked_object_storage_write_from_file: Any, mocked_uuidt: Any
    ) -> None:
        exported_asset = self._create_asset({"columns": ["properties", "distinct_id"]})
        mocked_uuidt.return_value = "a-guid"
        mocked_object_storage_write_from_file.side_effect = ObjectStorageError("mock write failed")

        with self.settings(OBJECT_STORAGE_ENABLED=True, OBJECT_STORAGE_EXPORTS_FOLDER="Test-Exports"):
            csv_exporter.export_tabular(exported_asset)

            assert exported_asset.content_location is None

            assert exported_asset.content == b"properties.$browser,distinct_id\r\nSafari,2\r\nSafari,2\r\nSafari,2\r\n"

    @patch("products.exports.backend.models.exported_asset.UUIDT")
    @patch("products.exports.backend.models.exported_asset.object_storage.write_from_file")
    def test_csv_exporter_does_filter_columns_and_can_handle_unexpected_columns(
        self, mocked_object_storage_write_from_file: Any, mocked_uuidt: Any
    ) -> None:
        # NB these columns are not in the "natural" order
        exported_asset = self._create_asset({"columns": ["distinct_id", "properties.$browser", "event", "tomato"]})
        mocked_uuidt.return_value = "a-guid"
        mocked_object_storage_write_from_file.side_effect = ObjectStorageError("mock write failed")

        with self.settings(OBJECT_STORAGE_ENABLED=True, OBJECT_STORAGE_EXPORTS_FOLDER="Test-Exports"):
            csv_exporter.export_tabular(exported_asset)

            assert exported_asset.content_location is None

            assert (
                exported_asset.content
                == b"distinct_id,properties.$browser,event,tomato\r\n2,Safari,event_name,\r\n2,Safari,event_name,\r\n2,Safari,event_name,\r\n"
            )

    @patch("products.exports.backend.models.exported_asset.UUIDT")
    @patch("products.exports.backend.models.exported_asset.object_storage.write_from_file")
    def test_csv_exporter_excel(self, mocked_object_storage_write_from_file: Any, mocked_uuidt: Any) -> None:
        exported_asset = self._create_asset({"columns": ["distinct_id", "properties.$browser", "event", "tomato"]})
        exported_asset.export_format = ExportedAsset.ExportFormat.XLSX
        mocked_uuidt.return_value = "a-guid"
        mocked_object_storage_write_from_file.side_effect = ObjectStorageError("mock write failed")

        with self.settings(OBJECT_STORAGE_ENABLED=True, OBJECT_STORAGE_EXPORTS_FOLDER="Test-Exports"):
            csv_exporter.export_tabular(exported_asset)

            created_date = exported_asset.created_at.strftime("%Y-%m-%d-%H%M%S")
            assert exported_asset.filename == f"export-{created_date}.xlsx"
            assert exported_asset.content_location is None
            assert exported_asset.content is not None

            wb = load_workbook(filename=BytesIO(exported_asset.content))
            ws = wb.active
            data = list(ws.iter_rows(values_only=True))
            assert data == [
                ("distinct_id", "properties.$browser", "event", "tomato"),
                ("2", "Safari", "event_name", None),
                ("2", "Safari", "event_name", None),
                ("2", "Safari", "event_name", None),
            ]

    @patch("products.exports.backend.models.exported_asset.UUIDT")
    @patch("products.exports.backend.models.exported_asset.object_storage.write")
    @patch("products.exports.backend.tasks.csv_exporter.requests.request")
    def test_csv_exporter_limits_breakdown_insights_correctly(
        self, mocked_request: Any, mocked_object_storage_write: Any, mocked_uuidt: Any
    ) -> None:
        path = "api/projects/1/insights/trend/?insight=TRENDS&breakdown=email&date_from=-7d"
        exported_asset = self._create_asset({"path": path})
        mock_response = Mock()
        mock_response.status_code = 200
        mocked_request.return_value = mock_response

        with self.settings(OBJECT_STORAGE_ENABLED=True, OBJECT_STORAGE_EXPORTS_FOLDER="Test-Exports"):
            csv_exporter.export_tabular(exported_asset)

        mocked_request.assert_called_with(
            method="get",
            url="http://testserver/" + path + f"&breakdown_limit={CSV_EXPORT_BREAKDOWN_LIMIT_INITIAL}&is_csv_export=1",
            timeout=60,
            json=None,
            headers=ANY,
        )

    @patch("products.exports.backend.tasks.csv_exporter.logger")
    def test_failing_export_api_is_reported(self, _mock_logger: MagicMock) -> None:
        with patch("products.exports.backend.tasks.csv_exporter.requests.request") as patched_request:
            exported_asset = self._create_asset()
            mock_response = MagicMock()
            mock_response.status_code = 403
            mock_response.raise_for_status.side_effect = Exception("HTTP 403 Forbidden")
            mock_response.ok = False
            patched_request.return_value = mock_response

            with pytest.raises(Exception, match="HTTP 403 Forbidden"):
                csv_exporter.export_tabular(exported_asset)

    @patch("products.exports.backend.tasks.csv_exporter.make_api_call")
    def test_path_based_export_delegates_source_personal_api_key(self, patched_api_call: MagicMock) -> None:
        exported_asset = self._create_asset()
        exported_asset.source_authentication = ExportedAsset.SourceAuthentication.PERSONAL_API_KEY
        exported_asset.source_credential_id = "source-key-id"
        response = Mock()
        response.json.return_value = {"next": None, "results": []}
        patched_api_call.return_value = response

        csv_exporter.export_tabular(exported_asset)

        access_token = patched_api_call.call_args.args[0]
        claims = decode_jwt(access_token, PosthogJwtAudience.DELEGATED_USER)
        assert claims["personal_api_key_id"] == "source-key-id"
        with pytest.raises(jwt.InvalidAudienceError):
            decode_jwt(access_token, PosthogJwtAudience.IMPERSONATED_USER)

    def test_path_based_export_rejects_missing_authentication_source(self) -> None:
        exported_asset = self._create_asset()
        exported_asset.source_authentication = None

        with pytest.raises(ValueError, match="could not verify its original authorization"):
            csv_exporter.export_tabular(exported_asset)

    @patch("products.exports.backend.tasks.csv_exporter.make_api_call")
    def test_path_based_session_export_uses_impersonated_user_audience(self, patched_api_call: MagicMock) -> None:
        response = Mock()
        response.json.return_value = {"next": None, "results": []}
        patched_api_call.return_value = response

        csv_exporter.export_tabular(self._create_asset())

        access_token = patched_api_call.call_args.args[0]
        decode_jwt(access_token, PosthogJwtAudience.IMPERSONATED_USER)
        with pytest.raises(jwt.InvalidAudienceError):
            decode_jwt(access_token, PosthogJwtAudience.DELEGATED_USER)
        authentication_response = self.client.get(
            f"/api/projects/{self.team.id}/persons/",
            HTTP_AUTHORIZATION=f"Bearer {access_token}",
        )
        assert authentication_response.status_code == 200

    def test_query_export_rechecks_source_personal_api_key(self) -> None:
        personal_api_key = PersonalAPIKey.objects.create(
            user=self.user,
            label="query export key",
            secure_value=hash_key_value(generate_random_token_personal()),
            scopes=["export:write", "query:read"],
            scoped_teams=[self.team.id],
        )
        exported_asset = ExportedAsset.objects.create(
            team=self.team,
            created_by=self.user,
            export_format=ExportedAsset.ExportFormat.CSV,
            export_context={"source": {"kind": "HogQLQuery", "query": "select 1"}},
            source_authentication=ExportedAsset.SourceAuthentication.PERSONAL_API_KEY,
            source_credential_id=personal_api_key.id,
        )

        assert_export_authorization(exported_asset)

        personal_api_key.scopes = ["export:write"]
        personal_api_key.save(update_fields=["scopes"])
        with pytest.raises(ValueError, match="could not verify its original authorization"):
            assert_export_authorization(exported_asset)

        personal_api_key.scopes = ["export:write", "query:read"]
        personal_api_key.scoped_teams = [self.team.id + 1]
        personal_api_key.save(update_fields=["scopes", "scoped_teams"])
        with pytest.raises(ValueError, match="could not verify its original authorization"):
            assert_export_authorization(exported_asset)

        personal_api_key.delete()
        with pytest.raises(ValueError, match="could not verify its original authorization"):
            assert_export_authorization(exported_asset)

    @patch("products.exports.backend.tasks.csv_exporter.logger")
    def test_failing_export_api_is_reported_query_size_exceeded(self, _mock_logger: MagicMock) -> None:
        with patch("products.exports.backend.tasks.csv_exporter.make_api_call") as patched_make_api_call:
            exported_asset = self._create_asset()
            mock_error = HTTPError("Query size exceeded")  # type: ignore[call-arg]
            mock_error.response = Mock()
            mock_error.response.text = "Query size exceeded"
            patched_make_api_call.side_effect = mock_error

            csv_exporter.export_tabular(exported_asset)

            assert patched_make_api_call.call_count == 4
            patched_make_api_call.assert_called_with(mock.ANY, mock.ANY, 64, mock.ANY, mock.ANY, mock.ANY)

    @patch("products.exports.backend.tasks.csv_exporter.logger")
    def test_404_mid_export_returns_rows_already_fetched(self, _mock_logger: MagicMock) -> None:
        # A cohort can be deleted mid-export, surfacing as a 404 partway through pagination.
        # We should return what we already fetched rather than failing the whole export.
        with patch("products.exports.backend.tasks.csv_exporter.make_api_call") as patched_make_api_call:
            exported_asset = self._create_asset()

            first_page = Mock()
            first_page.json.return_value = {
                "next": "http://testserver/api/cohort/1/persons?offset=512",
                "results": [{"id": "abc", "distinct_id": "1"}],
            }

            not_found_error = HTTPError("404 Client Error")  # type: ignore[call-arg]
            not_found_error.response = Mock()
            not_found_error.response.status_code = 404
            not_found_error.response.text = "Not found."

            patched_make_api_call.side_effect = [first_page, not_found_error]

            with self.settings(OBJECT_STORAGE_ENABLED=False):
                csv_exporter.export_tabular(exported_asset)

            assert patched_make_api_call.call_count == 2
            assert exported_asset.content is not None
            assert b"abc" in exported_asset.content

    @patch("products.exports.backend.tasks.csv_exporter.logger")
    def test_non_404_http_error_still_raises(self, _mock_logger: MagicMock) -> None:
        with patch("products.exports.backend.tasks.csv_exporter.make_api_call") as patched_make_api_call:
            exported_asset = self._create_asset()

            server_error = HTTPError("500 Server Error")  # type: ignore[call-arg]
            server_error.response = Mock()
            server_error.response.status_code = 500
            server_error.response.text = "Internal server error"
            patched_make_api_call.side_effect = server_error

            with pytest.raises(HTTPError):
                csv_exporter.export_tabular(exported_asset)

    def test_limiting_query_as_expected(self) -> None:
        with self.settings(SITE_URL="https://app.posthog.com"):
            modified_url = add_query_params(absolute_uri(regression_11204), {"limit": "3500"})
            actual_bits = self._split_to_dict(modified_url)
            expected_bits = {
                **self._split_to_dict(regression_11204),
                **{"limit": "3500"},
            }
            assert expected_bits == actual_bits

    def test_limiting_existing_limit_query_as_expected(self) -> None:
        with self.settings(SITE_URL="https://app.posthog.com"):
            url_with_existing_limit = regression_11204 + "&limit=100000"
            modified_url = add_query_params(absolute_uri(url_with_existing_limit), {"limit": "3500"})
            actual_bits = self._split_to_dict(modified_url)
            expected_bits = {
                **self._split_to_dict(regression_11204),
                **{"limit": "3500"},
            }
            assert expected_bits == actual_bits

    @patch("products.exports.backend.tasks.csv_exporter.make_api_call")
    def test_raises_expected_error_when_json_is_none(self, patched_api_call: Any) -> None:
        mock_response = Mock()
        mock_response.json.return_value = None
        mock_response.status_code = 200
        mock_response.text = "i am the text"
        patched_api_call.return_value = mock_response

        with pytest.raises(UnexpectedEmptyJsonResponse, match="JSON is None when calling API for data"):
            csv_exporter.export_tabular(self._create_asset())

    @patch("posthog.hogql.constants.CSV_EXPORT_LIMIT", 10)
    @patch("posthog.hogql.constants.DEFAULT_RETURNED_ROWS", 5)
    @patch("products.exports.backend.models.exported_asset.UUIDT")
    def test_csv_exporter_hogql_query(
        self, mocked_uuidt: Any, DEFAULT_RETURNED_ROWS: int = 5, CSV_EXPORT_LIMIT: int = 10
    ) -> None:
        random_uuid = f"RANDOM_TEST_ID::{UUIDT()}"
        for i in range(15):
            _create_event(
                event="$pageview",
                distinct_id=random_uuid,
                team=self.team,
                timestamp=now() - relativedelta(hours=1),
                properties={"prop": i},
            )
        flush_persons_and_events()

        exported_asset = ExportedAsset(
            team=self.team,
            export_format=ExportedAsset.ExportFormat.CSV,
            export_context={
                "source": {
                    "kind": "HogQLQuery",
                    "query": f"select event from events where distinct_id = '{random_uuid}'",
                }
            },
        )
        exported_asset.save()
        mocked_uuidt.return_value = "a-guid"

        with self.settings(OBJECT_STORAGE_ENABLED=True, OBJECT_STORAGE_EXPORTS_FOLDER="Test-Exports"):
            csv_exporter.export_tabular(exported_asset)
            assert exported_asset.content_location is not None

            assert (
                exported_asset.content_location
                == f"{TEST_PREFIX}/csv/team-{self.team.id}/task-{exported_asset.id}/a-guid"
            )

            content = object_storage.read(exported_asset.content_location)
            assert (
                content
                == "event\r\n$pageview\r\n$pageview\r\n$pageview\r\n$pageview\r\n$pageview\r\n$pageview\r\n$pageview\r\n$pageview\r\n$pageview\r\n$pageview\r\n"
            )

            assert exported_asset.content is None

    @patch("posthog.hogql.constants.CSV_EXPORT_LIMIT", 10)
    @patch("products.exports.backend.models.exported_asset.UUIDT")
    def test_csv_exporter_events_query(self, mocked_uuidt: Any, CSV_EXPORT_LIMIT: int = 10) -> None:
        random_uuid = f"RANDOM_TEST_ID::{UUIDT()}"
        for i in range(15):
            _create_event(
                event="$pageview",
                distinct_id=random_uuid,
                team=self.team,
                timestamp=now() - relativedelta(hours=1),
                properties={"prop": i},
            )
        flush_persons_and_events()

        exported_asset = ExportedAsset(
            team=self.team,
            export_format=ExportedAsset.ExportFormat.CSV,
            export_context={
                "source": {
                    "kind": "EventsQuery",
                    "select": ["event", "*"],
                    "where": [f"distinct_id = '{random_uuid}'"],
                }
            },
        )
        exported_asset.save()
        mocked_uuidt.return_value = "a-guid"

        with self.settings(OBJECT_STORAGE_ENABLED=True, OBJECT_STORAGE_EXPORTS_FOLDER="Test-Exports"):
            csv_exporter.export_tabular(exported_asset)
            assert exported_asset.content_location is not None
            content = object_storage.read(exported_asset.content_location)
            lines = (content or "").split("\r\n")
            self.assertEqual(len(lines), 12)
            self.assertEqual(
                lines[0],
                "event,*.uuid,*.event,*.properties.prop,*.timestamp,*.team_id,*.distinct_id,*.elements_chain,*.created_at,*.person_mode",
            )
            self.assertEqual(lines[11], "")
            first_row = lines[1].split(",")
            self.assertEqual(first_row[0], "$pageview")
            self.assertEqual(first_row[2], "$pageview")
            self.assertEqual(first_row[5], str(self.team.pk))

    @patch("posthog.hogql.constants.CSV_EXPORT_LIMIT", 10)
    @patch("products.exports.backend.models.exported_asset.UUIDT")
    def test_csv_exporter_events_query_with_columns(self, mocked_uuidt: Any, CSV_EXPORT_LIMIT: int = 10) -> None:
        random_uuid = f"RANDOM_TEST_ID::{UUIDT()}"
        for i in range(15):
            _create_event(
                event="$pageview",
                distinct_id=random_uuid,
                team=self.team,
                timestamp=now() - relativedelta(hours=1),
                properties={"prop": i},
            )
        flush_persons_and_events()

        exported_asset = ExportedAsset(
            team=self.team,
            export_format=ExportedAsset.ExportFormat.CSV,
            export_context={
                "columns": ["*"],
                "source": {
                    "kind": "EventsQuery",
                    "select": ["event", "*"],
                    "where": [f"distinct_id = '{random_uuid}'"],
                },
            },
        )
        exported_asset.save()
        mocked_uuidt.return_value = "a-guid"

        with self.settings(OBJECT_STORAGE_ENABLED=True, OBJECT_STORAGE_EXPORTS_FOLDER="Test-Exports"):
            csv_exporter.export_tabular(exported_asset)
            assert exported_asset.content_location is not None
            content = object_storage.read(exported_asset.content_location)
            lines = (content or "").split("\r\n")
            self.assertEqual(len(lines), 12)
            self.assertEqual(
                lines[0],
                "*.uuid,*.event,*.properties.prop,*.timestamp,*.team_id,*.distinct_id,*.elements_chain,*.created_at,*.person_mode",
            )
            self.assertEqual(lines[11], "")
            first_row = lines[1].split(",")
            self.assertEqual(first_row[1], "$pageview")
            self.assertEqual(first_row[4], str(self.team.pk))

    @patch("posthog.hogql.constants.MAX_SELECT_RETURNED_ROWS", 10)
    @patch("products.exports.backend.models.exported_asset.UUIDT")
    def test_csv_exporter_funnels_query(self, mocked_uuidt: Any, MAX_SELECT_RETURNED_ROWS: int = 10) -> None:
        _create_person(
            distinct_ids=[f"user_1"],
            team=self.team,
        )

        events_by_person = {
            "user_1": [
                {
                    "event": "$pageview",
                    "timestamp": datetime(2024, 3, 22, 13, 46),
                    "properties": {"utm_medium": "test''123"},
                },
                {
                    "event": "$pageview",
                    "timestamp": datetime(2024, 3, 22, 13, 47),
                    "properties": {"utm_medium": "test''123"},
                },
            ],
        }
        journeys_for(events_by_person, self.team)
        flush_persons_and_events()

        exported_asset = ExportedAsset(
            team=self.team,
            export_format=ExportedAsset.ExportFormat.CSV,
            export_context={
                "source": {
                    "kind": "FunnelsQuery",
                    "series": [
                        {"kind": "EventsNode", "name": "$pageview", "event": "$pageview"},
                        {"kind": "EventsNode", "name": "$pageview", "event": "$pageview"},
                    ],
                    "interval": "day",
                    "dateRange": {"date_to": "2024-03-22", "date_from": "2024-03-22"},
                    "funnelsFilter": {"funnelVizType": "steps"},
                    "breakdownFilter": {"breakdown": "utm_medium", "breakdown_type": "event"},
                }
            },
        )
        exported_asset.save()
        mocked_uuidt.return_value = "a-guid"

        with self.settings(OBJECT_STORAGE_ENABLED=True, OBJECT_STORAGE_EXPORTS_FOLDER="Test-Exports"):
            csv_exporter.export_tabular(exported_asset)
            assert exported_asset.content_location is not None
            content = object_storage.read(exported_asset.content_location)
            lines = (content or "").strip().split("\r\n")
            self.assertEqual(
                lines,
                [
                    "name,breakdown_value,action_id,count,median_conversion_time (seconds),average_conversion_time (seconds)",
                    "$pageview,test'123,$pageview,1,,",
                    "$pageview,test'123,$pageview,1,60.0,60.0",
                ],
            )

    @patch("products.exports.backend.models.exported_asset.object_storage.write_from_file")
    @patch("products.exports.backend.tasks.csv_exporter.process_query_dict")
    @patch("products.exports.backend.tasks.csv_exporter._query_supports_limit")
    def test_skips_limit_when_query_does_not_support_it(
        self, mock_supports_limit: MagicMock, mock_process_query: MagicMock, mock_write: MagicMock
    ) -> None:
        """Verify that when schema validation shows limit is not supported, we don't add it."""
        mock_supports_limit.return_value = False
        mock_process_query.return_value = {
            "results": [["value1"], ["value2"]],
            "columns": ["col"],
            "types": ["String"],
        }
        mock_write.side_effect = ObjectStorageError("mock write failed")

        exported_asset = ExportedAsset(
            team=self.team,
            export_format=ExportedAsset.ExportFormat.CSV,
            export_context={"source": {"kind": "SomeQuery"}},
        )
        exported_asset.save()

        with self.settings(OBJECT_STORAGE_ENABLED=True, OBJECT_STORAGE_EXPORTS_FOLDER="Test-Exports"):
            csv_exporter.export_tabular(exported_asset)

            # Verify only one call made, without limit
            self.assertEqual(mock_process_query.call_count, 1)
            query_json = mock_process_query.call_args_list[0].kwargs["query_json"]
            self.assertNotIn("limit", query_json)

            # Verify content fell back to DB storage
            content = exported_asset.content
            lines = (bytes(content) if content else b"").decode("utf-8").strip().split("\r\n")
            self.assertEqual(lines, ["col", "value1", "value2"])

    @patch("products.exports.backend.models.exported_asset.object_storage.write_from_file")
    @patch("products.exports.backend.tasks.csv_exporter.process_query_dict")
    @patch("products.exports.backend.tasks.csv_exporter._query_supports_limit")
    def test_adds_limit_when_query_supports_it(
        self, mock_supports_limit: MagicMock, mock_process_query: MagicMock, mock_write: MagicMock
    ) -> None:
        """Verify that when schema validation shows limit is supported, we add it."""
        from products.exports.backend.tasks.csv_exporter import QUERY_PAGE_SIZE

        mock_supports_limit.return_value = True
        mock_process_query.return_value = {
            "results": [["value1"], ["value2"]],
            "columns": ["col"],
            "types": ["String"],
            "hasMore": False,
        }
        mock_write.side_effect = ObjectStorageError("mock write failed")

        exported_asset = ExportedAsset(
            team=self.team,
            export_format=ExportedAsset.ExportFormat.CSV,
            export_context={"source": {"kind": "SomeQuery"}},
        )
        exported_asset.save()

        with self.settings(OBJECT_STORAGE_ENABLED=True, OBJECT_STORAGE_EXPORTS_FOLDER="Test-Exports"):
            csv_exporter.export_tabular(exported_asset)

            self.assertEqual(mock_process_query.call_count, 1)
            query_json = mock_process_query.call_args_list[0].kwargs["query_json"]
            self.assertEqual(query_json.get("limit"), QUERY_PAGE_SIZE)

    def test_funnel_time_to_convert(self) -> None:
        bins = [
            [1, 1],
            [2, 3],
            [3, 5],
            [4, 17],
            [5, 29],
            [6, 44],
            [7, 38],
            [8, 24],
            [9, 10],
            [10, 7],
            [11, 3],
            [12, 1],
            [13, 1],
            [14, 1],
            [15, 0],
            [16, 0],
            [17, 0],
            [18, 0],
            [19, 0],
            [20, 0],
            [21, 1],
            [22, 0],
            [23, 1],
            [24, 0],
            [25, 0],
            [26, 0],
        ]
        data = {
            "results": {
                "average_conversion_time": 1.45,
                "bins": bins,
            }
        }
        csv_list = list(_convert_response_to_csv_data(data))
        assert len(bins) == len(csv_list)
        for bin, csv in zip(bins, csv_list):
            assert bin[0] == csv["bin"]
            assert bin[1] == csv["value"]

    @patch("products.exports.backend.models.exported_asset.UUIDT")
    def test_csv_exporter_empty_result(self, mocked_uuidt: Any) -> None:
        exported_asset = ExportedAsset(
            team=self.team,
            export_format=ExportedAsset.ExportFormat.CSV,
            export_context={
                "source": {
                    "kind": "FunnelsQuery",
                    "series": [
                        {"kind": "EventsNode", "name": "$pageview", "event": "$pageview"},
                        {"kind": "EventsNode", "name": "$pageview", "event": "$pageview"},
                    ],
                    "interval": "day",
                    "dateRange": {"date_to": "2024-03-22", "date_from": "2024-03-22"},
                    "funnelsFilter": {"funnelVizType": "steps"},
                    "breakdownFilter": {"breakdown": "utm_medium", "breakdown_type": "event"},
                }
            },
        )
        exported_asset.save()
        mocked_uuidt.return_value = "a-guid"

        with patch("products.exports.backend.tasks.csv_exporter.get_from_query") as mocked_get_from_query:
            mocked_get_from_query.return_value = iter([])

            with self.settings(OBJECT_STORAGE_ENABLED=True, OBJECT_STORAGE_EXPORTS_FOLDER="Test-Exports"):
                csv_exporter.export_tabular(exported_asset)
                assert exported_asset.content_location is not None
                content = object_storage.read(exported_asset.content_location)
                lines = (content or "").split("\r\n")
                self.assertEqual(lines[0], "error")
                self.assertEqual(lines[1], "No data available or unable to format for export.")

    @patch("posthog.hogql.constants.MAX_SELECT_RETURNED_ROWS", 10)
    @patch("products.exports.backend.models.exported_asset.UUIDT")
    def test_csv_exporter_trends_query_with_none_action(
        self, mocked_uuidt: Any, MAX_SELECT_RETURNED_ROWS: int = 10
    ) -> None:
        _create_person(
            distinct_ids=[f"user_1"],
            team=self.team,
        )

        events_by_person = {
            "user_1": [
                {
                    "event": "$pageview",
                    "timestamp": datetime(2024, 3, 22, 13, 46),
                },
                {
                    "event": "$pageview",
                    "timestamp": datetime(2024, 3, 22, 13, 47),
                },
            ],
        }
        journeys_for(events_by_person, self.team)
        flush_persons_and_events()

        exported_asset = ExportedAsset(
            team=self.team,
            export_format=ExportedAsset.ExportFormat.CSV,
            export_context={
                "source": {
                    "kind": "TrendsQuery",
                    "dateRange": {"date_to": "2024-03-22", "date_from": "2024-03-22"},
                    "series": [
                        {
                            "kind": "EventsNode",
                            "event": None,
                            "name": "All events",
                            "math": "dau",
                        },
                        {
                            "kind": "EventsNode",
                            "event": "$pageview",
                            "name": "$pageview",
                            "math": "dau",
                        },
                    ],
                    "interval": "day",
                    "trendsFilter": {"showLegend": True, "aggregationAxisFormat": "percentage", "formula": "(B/A)*100"},
                }
            },
        )
        exported_asset.save()
        mocked_uuidt.return_value = "a-guid"

        with self.settings(OBJECT_STORAGE_ENABLED=True, OBJECT_STORAGE_EXPORTS_FOLDER="Test-Exports"):
            csv_exporter.export_tabular(exported_asset)
            assert exported_asset.content_location is not None
            content = object_storage.read(exported_asset.content_location)
            lines = (content or "").strip().split("\r\n")
            self.assertEqual(
                lines,
                ["series,22-Mar-2024", "Formula ((B/A)*100),100.0"],
            )

    def test_csv_exporter_trends_query_with_compare_previous_option(
        self,
    ) -> None:
        _create_person(distinct_ids=[f"user_1"], team=self.team)

        date = datetime(2023, 3, 21, 13, 46)
        date_next_week = date + relativedelta(days=7)

        _create_event(
            event="$pageview",
            distinct_id="1",
            team=self.team,
            timestamp=date,
            properties={"$browser": "Safari"},
        )
        _create_event(
            event="$pageview",
            distinct_id="1",
            team=self.team,
            timestamp=date,
            properties={"$browser": "Chrome"},
        )
        _create_event(
            event="$pageview",
            distinct_id="1",
            team=self.team,
            timestamp=date,
            properties={"$browser": "Chrome"},
        )
        _create_event(
            event="$pageview",
            distinct_id="1",
            team=self.team,
            timestamp=date,
            properties={"$browser": "Firefox"},
        )

        _create_event(
            event="$pageview",
            distinct_id="1",
            team=self.team,
            timestamp=date_next_week,
            properties={"$browser": "Chrome"},
        )
        _create_event(
            event="$pageview",
            distinct_id="1",
            team=self.team,
            timestamp=date_next_week,
            properties={"$browser": "Chrome"},
        )
        _create_event(
            event="$pageview",
            distinct_id="1",
            team=self.team,
            timestamp=date_next_week,
            properties={"$browser": "Chrome"},
        )
        _create_event(
            event="$pageview",
            distinct_id="1",
            team=self.team,
            timestamp=date_next_week,
            properties={"$browser": "Firefox"},
        )
        _create_event(
            event="$pageview",
            distinct_id="1",
            team=self.team,
            timestamp=date_next_week,
            properties={"$browser": "Firefox"},
        )

        flush_persons_and_events()

        exported_asset = ExportedAsset(
            team=self.team,
            export_format=ExportedAsset.ExportFormat.CSV,
            export_context={
                "source": {
                    "kind": "TrendsQuery",
                    "dateRange": {
                        "date_from": date.strftime("%Y-%m-%d"),
                        "date_to": date_next_week.strftime("%Y-%m-%d"),
                    },
                    "series": [
                        {
                            "kind": "EventsNode",
                            "event": "$pageview",
                            "name": "$pageview",
                            "math": "total",
                        },
                    ],
                    "interval": "day",
                    "compareFilter": {"compare": True, "compare_to": "-1w"},
                    "breakdownFilter": {"breakdown": "$browser", "breakdown_type": "event"},
                }
            },
        )
        exported_asset.save()

        with self.settings(OBJECT_STORAGE_ENABLED=True, OBJECT_STORAGE_EXPORTS_FOLDER="Test-Exports"):
            csv_exporter.export_tabular(exported_asset)
            content = object_storage.read(exported_asset.content_location)  # type: ignore

            lines = (content or "").strip().splitlines()

            expected_lines = [
                "series,$browser,21-Mar-2023,22-Mar-2023,23-Mar-2023,24-Mar-2023,25-Mar-2023,26-Mar-2023,27-Mar-2023,28-Mar-2023",
                "$pageview - current,Chrome,2.0,0.0,0.0,0.0,0.0,0.0,0.0,3.0",
                "$pageview - current,Firefox,1.0,0.0,0.0,0.0,0.0,0.0,0.0,2.0",
                "$pageview - current,Safari,1.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0",
                "$pageview - previous,Chrome,0.0,0.0,0.0,0.0,0.0,0.0,0.0,2.0",
                "$pageview - previous,Firefox,0.0,0.0,0.0,0.0,0.0,0.0,0.0,1.0",
                "$pageview - previous,Safari,0.0,0.0,0.0,0.0,0.0,0.0,0.0,1.0",
            ]

            self.assertEqual(lines, expected_lines)

    def test_csv_exporter_trends_actors(
        self,
    ) -> None:
        with freeze_time("2022-06-01T12:00:00.000Z"):
            _create_person(distinct_ids=[f"user_1"], team=self.team, uuid="725f10a7-26dd-fa38-f973-757866a10ad4")

        events_by_person = {
            "user_1": [
                {
                    "event": "$pageview",
                    "timestamp": datetime(2020, 3, 22, 13, 46),
                },
                {
                    "event": "$pageview",
                    "timestamp": datetime(2020, 3, 22, 13, 47),
                },
            ],
        }
        journeys_for(events_by_person, self.team)
        _create_event(
            event="$pageview",
            distinct_id="user_2",  # personless user
            person_id="d0780d6b-ccd0-44fa-a227-47efe4f3f30d",
            timestamp=datetime(2020, 3, 22, 13, 48),
            team=self.team,
        )
        flush_persons_and_events()

        exported_asset = ExportedAsset(
            team=self.team,
            export_format=ExportedAsset.ExportFormat.CSV,
            export_context={
                "source": {
                    "kind": "ActorsQuery",
                    "search": "",
                    "select": ["actor", "event_count"],
                    "source": {
                        "day": "2020-03-22T00:00:00Z",
                        "kind": "InsightActorsQuery",
                        "series": 0,
                        "source": {
                            "kind": "TrendsQuery",
                            "series": [
                                {"kind": "EventsNode", "math": "total", "name": "$pageview", "event": "$pageview"}
                            ],
                            "trendsFilter": {},
                        },
                        "includeRecordings": False,
                    },
                    "orderBy": ["event_count DESC, actor_id DESC"],
                }
            },
        )
        exported_asset.save()

        with self.settings(OBJECT_STORAGE_ENABLED=True, OBJECT_STORAGE_EXPORTS_FOLDER="Test-Exports"):
            csv_exporter.export_tabular(exported_asset)
            content = object_storage.read(exported_asset.content_location)  # type: ignore
            lines = (content or "").strip().split("\r\n")
            self.assertEqual(
                lines,
                [
                    "actor.id,actor.is_identified,actor.created_at,actor.last_seen_at,actor.distinct_ids.0,actor.is_unresolved,event_count,event_distinct_ids.0",
                    "725f10a7-26dd-fa38-f973-757866a10ad4,False,2022-06-01 12:00:00+00:00,,user_1,,2,user_1",
                    "d0780d6b-ccd0-44fa-a227-47efe4f3f30d,,,,user_2,True,1,user_2",
                ],
            )

    @patch("products.exports.backend.models.exported_asset.UUIDT")
    def test_csv_exporter_trends_query_with_formula(
        self, mocked_uuidt: Any, MAX_SELECT_RETURNED_ROWS: int = 10
    ) -> None:
        with freeze_time("2024-05-15T12:00:00.000Z"):
            _create_person(distinct_ids=["formula_test_user_xyz"], team=self.team)

        events_by_person = {
            "formula_test_user_xyz": [
                {"event": "formula_test_event_a", "timestamp": datetime(2024, 5, 15, 13, 46)},
                {"event": "formula_test_event_b", "timestamp": datetime(2024, 5, 15, 13, 47)},
            ],
        }
        journeys_for(events_by_person, self.team)
        flush_persons_and_events()

        exported_asset = ExportedAsset(
            team=self.team,
            export_format=ExportedAsset.ExportFormat.CSV,
            export_context={
                "source": {
                    "kind": "TrendsQuery",
                    "dateRange": {"date_to": "2024-05-15", "date_from": "2024-05-15"},
                    "series": [
                        {"kind": "EventsNode", "event": "formula_test_event_a", "name": "Event A", "math": "total"},
                        {"kind": "EventsNode", "event": "formula_test_event_b", "name": "Event B", "math": "total"},
                    ],
                    "interval": "day",
                    "trendsFilter": {
                        "showLegend": True,
                        "display": "ActionsTable",
                        "formula": "A+B",
                    },
                }
            },
        )
        exported_asset.save()
        mocked_uuidt.return_value = "a-guid"

        with self.settings(OBJECT_STORAGE_ENABLED=True, OBJECT_STORAGE_EXPORTS_FOLDER="Test-Exports"):
            csv_exporter.export_tabular(exported_asset)

            assert (
                exported_asset.content_location
                == f"{TEST_PREFIX}/csv/team-{self.team.id}/task-{exported_asset.id}/a-guid"
            )

            content = object_storage.read(exported_asset.content_location)
            lines = (content or "").strip().split("\r\n")
            self.assertEqual(
                lines,
                [
                    "series,Total Sum",
                    "Formula (A+B),2.0",
                ],
            )

    @patch("products.exports.backend.models.exported_asset.UUIDT")
    def test_csv_exporter_trends_query_with_formula_and_single_breakdown(
        self, mocked_uuidt: Any, MAX_SELECT_RETURNED_ROWS: int = 10
    ) -> None:
        with freeze_time("2024-06-10T12:00:00.000Z"):
            _create_person(distinct_ids=["breakdown_user_single"], team=self.team)

        _create_event(
            event="breakdown_single_event_a",
            distinct_id="breakdown_user_single",
            team=self.team,
            timestamp=datetime(2024, 6, 10, 13, 46),
            properties={"country": "USA"},
        )
        _create_event(
            event="breakdown_single_event_b",
            distinct_id="breakdown_user_single",
            team=self.team,
            timestamp=datetime(2024, 6, 10, 13, 47),
            properties={"country": "USA"},
        )
        flush_persons_and_events()

        exported_asset = ExportedAsset(
            team=self.team,
            export_format=ExportedAsset.ExportFormat.CSV,
            export_context={
                "source": {
                    "kind": "TrendsQuery",
                    "dateRange": {"date_to": "2024-06-10", "date_from": "2024-06-10"},
                    "series": [
                        {
                            "kind": "EventsNode",
                            "event": "breakdown_single_event_a",
                            "name": "Event A",
                            "math": "total",
                        },
                        {
                            "kind": "EventsNode",
                            "event": "breakdown_single_event_b",
                            "name": "Event B",
                            "math": "total",
                        },
                    ],
                    "interval": "day",
                    "trendsFilter": {
                        "showLegend": True,
                        "display": "ActionsTable",
                        "formula": "A+B",
                    },
                    "breakdownFilter": {
                        "breakdown": "country",
                        "breakdown_type": "event",
                    },
                }
            },
        )
        exported_asset.save()
        mocked_uuidt.return_value = "a-guid"

        with self.settings(OBJECT_STORAGE_ENABLED=True, OBJECT_STORAGE_EXPORTS_FOLDER="Test-Exports"):
            csv_exporter.export_tabular(exported_asset)

            assert (
                exported_asset.content_location
                == f"{TEST_PREFIX}/csv/team-{self.team.id}/task-{exported_asset.id}/a-guid"
            )

            content = object_storage.read(exported_asset.content_location)
            lines = (content or "").strip().split("\r\n")
            self.assertEqual(
                lines,
                [
                    "series,country,Total Sum",
                    "Formula (A+B),USA,2.0",
                ],
            )

    @patch("products.exports.backend.models.exported_asset.UUIDT")
    def test_csv_exporter_trends_query_with_formula_and_multiple_breakdowns(
        self, mocked_uuidt: Any, MAX_SELECT_RETURNED_ROWS: int = 10
    ) -> None:
        with freeze_time("2024-07-20T12:00:00.000Z"):
            _create_person(distinct_ids=["multi_breakdown_user_1"], team=self.team)
            _create_person(distinct_ids=["multi_breakdown_user_2"], team=self.team)

        _create_event(
            event="multi_breakdown_event_a",
            distinct_id="multi_breakdown_user_1",
            team=self.team,
            timestamp=datetime(2024, 7, 20, 13, 46),
            properties={"$browser": "Chrome"},
        )
        _create_event(
            event="multi_breakdown_event_b",
            distinct_id="multi_breakdown_user_1",
            team=self.team,
            timestamp=datetime(2024, 7, 20, 13, 47),
            properties={"$browser": "Chrome"},
        )
        _create_event(
            event="multi_breakdown_event_a",
            distinct_id="multi_breakdown_user_2",
            team=self.team,
            timestamp=datetime(2024, 7, 20, 13, 48),
            properties={"$browser": "Firefox"},
        )
        flush_persons_and_events()

        exported_asset = ExportedAsset(
            team=self.team,
            export_format=ExportedAsset.ExportFormat.CSV,
            export_context={
                "source": {
                    "kind": "TrendsQuery",
                    "dateRange": {"date_to": "2024-07-20", "date_from": "2024-07-20"},
                    "series": [
                        {
                            "kind": "EventsNode",
                            "event": "multi_breakdown_event_a",
                            "name": "Event A",
                            "math": "total",
                        },
                        {
                            "kind": "EventsNode",
                            "event": "multi_breakdown_event_b",
                            "name": "Event B",
                            "math": "total",
                        },
                    ],
                    "interval": "day",
                    "trendsFilter": {
                        "showLegend": True,
                        "display": "ActionsTable",
                        "formula": "A+B",
                    },
                    "breakdownFilter": {
                        "breakdowns": [
                            {"property": "distinct_id", "type": "event_metadata"},
                            {"property": "$browser", "type": "event"},
                        ]
                    },
                }
            },
        )
        exported_asset.save()
        mocked_uuidt.return_value = "a-guid"

        with self.settings(OBJECT_STORAGE_ENABLED=True, OBJECT_STORAGE_EXPORTS_FOLDER="Test-Exports"):
            csv_exporter.export_tabular(exported_asset)

            assert (
                exported_asset.content_location
                == f"{TEST_PREFIX}/csv/team-{self.team.id}/task-{exported_asset.id}/a-guid"
            )

            content = object_storage.read(exported_asset.content_location)
            lines = (content or "").strip().split("\r\n")

            # Sort data lines for consistent comparison (order may vary)
            data_lines = sorted(lines[1:])

            self.assertEqual(
                lines[0:1] + data_lines,
                [
                    "series,distinct_id,$browser,Total Sum",
                    "Formula (A+B),multi_breakdown_user_1,Chrome,2.0",
                    "Formula (A+B),multi_breakdown_user_2,Firefox,1.0",
                ],
            )

    @patch("products.exports.backend.models.exported_asset.UUIDT")
    def test_csv_exporter_trends_with_breakdown(self, mocked_uuidt: Any) -> None:
        with freeze_time("2025-05-22T12:00:00.000Z"):
            _create_person(distinct_ids=["user_1"], team=self.team)
            _create_person(distinct_ids=["user_2"], team=self.team)

        events_by_person = {
            "user_1": [
                {
                    "event": "test_event",
                    "timestamp": datetime(2025, 5, 22, 13, 0),
                    "properties": {"$browser": "Chrome"},
                },
            ],
            "user_2": [
                {
                    "event": "test_event",
                    "timestamp": datetime(2025, 5, 22, 13, 1),
                    "properties": {"$browser": "Firefox"},
                },
            ],
        }
        journeys_for(events_by_person, self.team)
        flush_persons_and_events()

        exported_asset = ExportedAsset(
            team=self.team,
            export_format=ExportedAsset.ExportFormat.CSV,
            export_context={
                "source": {
                    "kind": "TrendsQuery",
                    "dateRange": {"date_to": "2025-05-22", "date_from": "2025-05-22"},
                    "series": [
                        {"kind": "EventsNode", "event": "test_event", "name": "test_event", "math": "total"},
                    ],
                    "interval": "day",
                    "trendsFilter": {
                        "display": "ActionsTable",
                    },
                    "breakdownFilter": {
                        "breakdown": "$browser",
                        "breakdown_type": "event",
                    },
                }
            },
        )
        exported_asset.save()
        mocked_uuidt.return_value = "a-guid"

        with self.settings(OBJECT_STORAGE_ENABLED=True, OBJECT_STORAGE_EXPORTS_FOLDER="Test-Exports"):
            csv_exporter.export_tabular(exported_asset)

            assert (
                exported_asset.content_location
                == f"{TEST_PREFIX}/csv/team-{self.team.id}/task-{exported_asset.id}/a-guid"
            )

            content = object_storage.read(exported_asset.content_location)
            lines = (content or "").strip().split("\r\n")
            data_lines = sorted(lines[1:])

            self.assertEqual(
                lines[0:1] + data_lines,
                [
                    "series,$browser,Total Sum",
                    "test_event,Chrome,1",
                    "test_event,Firefox,1",
                ],
            )

    @patch("products.exports.backend.models.exported_asset.UUIDT")
    def test_csv_exporter_trends_with_breakdown_and_action(self, mocked_uuidt: Any) -> None:
        with freeze_time("2025-05-22T12:00:00.000Z"):
            _create_person(distinct_ids=["user_1"], team=self.team)
            _create_person(distinct_ids=["user_2"], team=self.team)

        action = Action.objects.create(
            team=self.team,
            name="Test Action",
            steps_json=[{"event": "test_action_event"}],
        )

        events_by_person = {
            "user_1": [
                {
                    "event": "test_action_event",
                    "timestamp": datetime(2025, 5, 22, 13, 0),
                    "properties": {"$browser": "Chrome"},
                },
            ],
            "user_2": [
                {
                    "event": "test_action_event",
                    "timestamp": datetime(2025, 5, 22, 13, 1),
                    "properties": {"$browser": "Firefox"},
                },
            ],
        }
        journeys_for(events_by_person, self.team)
        flush_persons_and_events()

        exported_asset = ExportedAsset(
            team=self.team,
            export_format=ExportedAsset.ExportFormat.CSV,
            export_context={
                "source": {
                    "kind": "TrendsQuery",
                    "dateRange": {"date_to": "2025-05-22", "date_from": "2025-05-22"},
                    "series": [
                        {"kind": "ActionsNode", "id": action.id, "math": "total"},
                    ],
                    "interval": "day",
                    "trendsFilter": {
                        "display": "ActionsTable",
                    },
                    "breakdownFilter": {
                        "breakdown": "$browser",
                        "breakdown_type": "event",
                    },
                }
            },
        )
        exported_asset.save()
        mocked_uuidt.return_value = "a-guid"

        with self.settings(OBJECT_STORAGE_ENABLED=True, OBJECT_STORAGE_EXPORTS_FOLDER="Test-Exports"):
            csv_exporter.export_tabular(exported_asset)

            assert (
                exported_asset.content_location
                == f"{TEST_PREFIX}/csv/team-{self.team.id}/task-{exported_asset.id}/a-guid"
            )

            content = object_storage.read(exported_asset.content_location)
            lines = (content or "").strip().split("\r\n")
            data_lines = sorted(lines[1:])

            self.assertEqual(
                lines[0:1] + data_lines,
                [
                    "series,$browser,Total Sum",
                    "Test Action,Chrome,1",
                    "Test Action,Firefox,1",
                ],
            )

    @patch("posthog.hogql.constants.CSV_EXPORT_LIMIT", 10)
    @patch("products.exports.backend.models.exported_asset.UUIDT")
    def test_excel_streaming_saves_to_object_storage(self, mocked_uuidt: Any) -> None:
        """Test that Excel streaming export saves to object storage and handles complex types."""
        random_uuid = f"RANDOM_TEST_ID::{UUIDT()}"
        query_limit = 5
        for i in range(15):
            _create_event(
                event="$pageview",
                distinct_id=random_uuid,
                team=self.team,
                timestamp=now() - relativedelta(hours=1),
                properties={"prop": i, "tags": ["tag1", "tag2"], "meta": {"key": "value"}},
            )
        flush_persons_and_events()

        exported_asset = ExportedAsset(
            team=self.team,
            export_format=ExportedAsset.ExportFormat.XLSX,
            export_context={
                "source": {
                    "kind": "HogQLQuery",
                    "query": f"select event, properties.prop as prop, properties.tags as tags, properties.meta as meta from events where distinct_id = '{random_uuid}' order by prop limit {query_limit}",
                }
            },
        )
        exported_asset.save()
        mocked_uuidt.return_value = "a-guid"

        with self.settings(OBJECT_STORAGE_ENABLED=True, OBJECT_STORAGE_EXPORTS_FOLDER="Test-Exports"):
            csv_exporter.export_tabular(exported_asset)

            assert (
                exported_asset.content_location
                == f"{TEST_PREFIX}/vnd.openxmlformats-officedocument.spreadsheetml.sheet/team-{self.team.id}/task-{exported_asset.id}/a-guid"
            )

            content = object_storage.read_bytes(exported_asset.content_location)
            assert content is not None

            workbook = load_workbook(filename=BytesIO(content))
            worksheet = workbook.active
            rows = list(worksheet.iter_rows(values_only=True))

            header_row = 1
            assert rows[0] == ("event", "prop", "tags", "meta")
            assert len(rows) == query_limit + header_row
            assert all(row[0] == "$pageview" for row in rows[1:])
            # Complex types (arrays, objects) are converted to strings without crashing
            assert all(row[2] is not None and "tag1" in str(row[2]) for row in rows[1:])

    @patch("posthog.hogql.constants.CSV_EXPORT_LIMIT", 10)
    @patch("products.exports.backend.models.exported_asset.UUIDT")
    def test_csv_streaming_saves_to_object_storage(self, mocked_uuidt: Any, csv_export_limit: int = 10) -> None:
        """Test that CSV streaming export saves to object storage and handles complex types."""
        random_uuid = f"RANDOM_TEST_ID::{UUIDT()}"
        for i in range(15):
            _create_event(
                event="$pageview",
                distinct_id=random_uuid,
                team=self.team,
                timestamp=now() - relativedelta(hours=1),
                properties={"prop": i, "tags": ["tag1", "tag2"], "meta": {"key": "value"}},
            )
        flush_persons_and_events()

        exported_asset = ExportedAsset(
            team=self.team,
            export_format=ExportedAsset.ExportFormat.CSV,
            export_context={
                "source": {
                    "kind": "HogQLQuery",
                    "query": f"select event, properties.tags as tags, properties.meta as meta from events where distinct_id = '{random_uuid}'",
                }
            },
        )
        exported_asset.save()
        mocked_uuidt.return_value = "a-guid"

        with self.settings(OBJECT_STORAGE_ENABLED=True, OBJECT_STORAGE_EXPORTS_FOLDER="Test-Exports"):
            csv_exporter.export_tabular(exported_asset)

            assert exported_asset.content_location is not None
            assert exported_asset.content is None

            content = object_storage.read(exported_asset.content_location)
            lines = (content or "").strip().split("\r\n")
            header_row = 1
            assert lines[0] == "event,tags,meta"
            assert len(lines) == csv_export_limit + header_row
            # Complex types (arrays, objects) are handled without crashing
            assert "tag1" in lines[1]

    @patch("posthog.hogql.constants.CSV_EXPORT_LIMIT", 10)
    def test_csv_streaming_uses_temp_file(self) -> None:
        """Test that CSV streaming export writes to temp files and cleans them up."""
        import tempfile

        original_temp_file = tempfile.NamedTemporaryFile
        temp_file_paths: list[str] = []

        def tracking_temp_file(*args: Any, **kwargs: Any) -> Any:
            tmp = original_temp_file(*args, **kwargs)
            temp_file_paths.append(tmp.name)
            return tmp

        random_uuid = f"RANDOM_TEST_ID::{UUIDT()}"
        _create_event(
            event="$pageview",
            distinct_id=random_uuid,
            team=self.team,
            timestamp=now() - relativedelta(hours=1),
        )
        flush_persons_and_events()

        exported_asset = ExportedAsset(
            team=self.team,
            export_format=ExportedAsset.ExportFormat.CSV,
            export_context={
                "source": {
                    "kind": "HogQLQuery",
                    "query": f"select event from events where distinct_id = '{random_uuid}'",
                }
            },
        )
        exported_asset.save()

        with patch("products.exports.backend.tasks.csv_exporter.tempfile.NamedTemporaryFile", tracking_temp_file):
            csv_exporter.export_tabular(exported_asset)

        # Two temp files: jsonl (phase 1) + csv (phase 2)
        assert len(temp_file_paths) == 2
        assert any(p.endswith(".jsonl") for p in temp_file_paths)
        assert any(p.endswith(".csv") for p in temp_file_paths)
        for path in temp_file_paths:
            assert not os.path.exists(path), f"Temp file {path} should be cleaned up after export"

    @patch("posthog.hogql.constants.CSV_EXPORT_LIMIT", 10)
    def test_excel_streaming_uses_temp_file(self) -> None:
        """Test that Excel streaming export writes to temp files and cleans them up."""
        import tempfile

        original_temp_file = tempfile.NamedTemporaryFile
        temp_file_paths: list[str] = []

        def tracking_temp_file(*args: Any, **kwargs: Any) -> Any:
            tmp = original_temp_file(*args, **kwargs)
            temp_file_paths.append(tmp.name)
            return tmp

        random_uuid = f"RANDOM_TEST_ID::{UUIDT()}"
        _create_event(
            event="$pageview",
            distinct_id=random_uuid,
            team=self.team,
            timestamp=now() - relativedelta(hours=1),
        )
        flush_persons_and_events()

        exported_asset = ExportedAsset(
            team=self.team,
            export_format=ExportedAsset.ExportFormat.XLSX,
            export_context={
                "source": {
                    "kind": "HogQLQuery",
                    "query": f"select event from events where distinct_id = '{random_uuid}'",
                }
            },
        )
        exported_asset.save()

        with patch("products.exports.backend.tasks.csv_exporter.tempfile.NamedTemporaryFile", tracking_temp_file):
            csv_exporter.export_tabular(exported_asset)

        # Two temp files: jsonl (phase 1) + xlsx (phase 2)
        assert len(temp_file_paths) == 2
        assert any(p.endswith(".jsonl") for p in temp_file_paths)
        assert any(p.endswith(".xlsx") for p in temp_file_paths)
        for path in temp_file_paths:
            assert not os.path.exists(path), f"Temp file {path} should be cleaned up after export"

    def test_sanitize_value_for_excel(self) -> None:
        test_cases = [
            ("normal text", "normal text"),
            ("text with\ttab", "text with\ttab"),  # Tab is allowed
            ("text with\nnewline", "text with\nnewline"),  # Newline is allowed
            ("text with\rcarriage return", "text with\rcarriage return"),  # CR is allowed
            ("has\x00null char", "hasnull char"),  # NULL removed
            ("has\x07bell char", "hasbell char"),  # Bell removed
            ("has\x0bvertical tab", "hasvertical tab"),  # Vertical tab removed
            ("has\x1bescape char", "hasescape char"),  # ESC removed (start of ANSI codes)
            ("\x1b[1;31mred text\x1b[0m", "[1;31mred text[0m"),  # ANSI: ESC removed, rest preserved
            (123, 123),  # Non-strings pass through
            (None, None),  # None passes through
            (12.34, 12.34),  # Float passes through
            (True, True),  # Bool passes through
        ]
        for input_value, expected in test_cases:
            assert sanitize_value_for_excel(input_value) == expected, f"Failed for input: {repr(input_value)}"

    @patch("products.exports.backend.models.exported_asset.UUIDT")
    @patch("products.exports.backend.models.exported_asset.object_storage.write_from_file")
    def test_excel_export_with_illegal_characters(
        self, mocked_object_storage_write_from_file: Any, mocked_uuidt: Any
    ) -> None:
        """Test that Excel export handles data with illegal XML characters without crashing."""
        with patch("products.exports.backend.tasks.csv_exporter.requests.request") as patched_request:
            mock_response = Mock()
            mock_response.status_code = 200
            # Data containing control characters that would normally crash openpyxl
            mock_response.json.return_value = {
                "next": None,
                "results": [
                    {
                        "id": "1",
                        "data_with_null": "before\x00after",
                        "data_with_bell": "before\x07after",
                        "data_with_escape": "before\x1b[31mred\x1b[0mafter",
                        "normal_data": "just normal text",
                    }
                ],
            }
            patched_request.return_value = mock_response

            exported_asset = ExportedAsset(
                team=self.team,
                export_format=ExportedAsset.ExportFormat.XLSX,
                export_context={"path": "/api/test/endpoint"},
                source_authentication=ExportedAsset.SourceAuthentication.SESSION,
            )
            exported_asset.save()
            mocked_uuidt.return_value = "a-guid"
            mocked_object_storage_write_from_file.side_effect = ObjectStorageError("mock write failed")

            with self.settings(OBJECT_STORAGE_ENABLED=True, OBJECT_STORAGE_EXPORTS_FOLDER="Test-Exports"):
                # This should not raise IllegalCharacterError
                csv_exporter.export_tabular(exported_asset)

                # Verify content was generated
                assert exported_asset.content is not None

                # Verify the Excel file can be loaded and contains sanitized data
                wb = load_workbook(filename=BytesIO(exported_asset.content))
                ws = wb.active
                data = list(ws.iter_rows(values_only=True))

                # Header row + 1 data row
                assert len(data) == 2

                # Find the data row values
                data_row = data[1]

                # Control characters should be stripped, but visible parts preserved
                assert "beforeafter" in str(data_row)  # NULL stripped
                assert "[31mred[0mafter" in str(data_row)  # ANSI: ESC stripped, rest preserved

    def test_format_breakdown_value(self) -> None:
        """Test _format_breakdown_value handles None."""
        # None was causing TypeError: can only join an iterable
        assert _format_breakdown_value(None) == ""

        # Normal list behavior unchanged
        assert _format_breakdown_value([]) == ""
        assert _format_breakdown_value(["a", "b", "c"]) == "a::b::c"
        assert _format_breakdown_value(["single"]) == "single"

    def test_excel_writer_raises_column_limit_exceeded(self) -> None:
        writer = ExcelWriter()
        # Create more columns than openpyxl supports (18,278 max)
        # See: https://foss.heptapod.net/openpyxl/openpyxl/-/blob/a345f3975f06450193646a53a5caaf081730e9ea/openpyxl/utils/cell.py#L93
        columns = [f"col_{i}" for i in range(18300)]

        with pytest.raises(ExcelColumnLimitExceeded) as exc_info:
            writer.write_header(columns)

        assert "18,278 columns" in str(exc_info.value)
        assert "CSV format" in str(exc_info.value)

    def test_excel_writer_normal_column_count_works(self) -> None:
        writer = ExcelWriter()
        columns = ["col_a", "col_b", "col_c"]
        writer.write_header(columns)
        writer.write_row({"col_a": "1", "col_b": "2", "col_c": "3"})
        path = writer.finish()

        assert os.path.exists(path)
        os.unlink(path)


@override_settings(SITE_URL="http://testserver")
class TestNestedColumnExport(APIBaseTest):
    """
    Test CSV export handles mixed null/nested data correctly.
    """

    @patch("products.exports.backend.models.exported_asset.UUIDT")
    @patch("products.exports.backend.models.exported_asset.object_storage.write_from_file")
    @patch("products.exports.backend.tasks.csv_exporter.get_from_query")
    def test_nested_columns_included_when_some_rows_are_null(
        self,
        mocked_get_from_query: Any,
        mocked_object_storage_write_from_file: Any,
        mocked_uuidt: Any,
    ) -> None:
        """
        When some rows have null inputState and others have nested objects,
        the export should include the nested column keys (not just 'inputState').
        """
        mocked_get_from_query.return_value = iter(
            [
                {
                    "id": "trace-with-state",
                    "inputState": {"messages": [{"role": "user", "content": "Hello world"}]},
                    "outputState": {"messages": [{"role": "assistant", "content": "Hi there!"}]},
                },
                {
                    "id": "trace-without-state",
                    "inputState": None,
                    "outputState": None,
                },
            ]
        )

        exported_asset = ExportedAsset(
            team=self.team,
            export_format=ExportedAsset.ExportFormat.CSV,
            export_context={
                "columns": ["id", "inputState", "outputState"],
                "source": {"kind": "TracesQuery"},
            },
        )
        exported_asset.save()
        mocked_uuidt.return_value = "test-guid"
        mocked_object_storage_write_from_file.side_effect = ObjectStorageError("mock write failed")

        with self.settings(OBJECT_STORAGE_ENABLED=True, OBJECT_STORAGE_EXPORTS_FOLDER="Test-Exports"):
            csv_exporter.export_tabular(exported_asset)

            assert exported_asset.content is not None
            assert b"Hello world" in exported_asset.content, f"Nested input content missing"
            assert b"Hi there!" in exported_asset.content, f"Nested output content missing"

    @patch("products.exports.backend.models.exported_asset.UUIDT")
    @patch("products.exports.backend.models.exported_asset.object_storage.write_from_file")
    @patch("products.exports.backend.tasks.csv_exporter.get_from_query")
    def test_null_rows_first_still_includes_nested_columns(
        self,
        mocked_get_from_query: Any,
        mocked_object_storage_write_from_file: Any,
        mocked_uuidt: Any,
    ) -> None:
        """
        Even when null rows come first (adding base key to seen_keys),
        nested keys from later rows should still be included.
        """
        mocked_get_from_query.return_value = iter(
            [
                {"id": "null-first", "inputState": None},
                {"id": "nested-second", "inputState": {"messages": [{"role": "user", "content": "Test message"}]}},
            ]
        )

        exported_asset = ExportedAsset(
            team=self.team,
            export_format=ExportedAsset.ExportFormat.CSV,
            export_context={
                "columns": ["id", "inputState"],
                "source": {"kind": "TracesQuery"},
            },
        )
        exported_asset.save()
        mocked_uuidt.return_value = "test-guid"
        mocked_object_storage_write_from_file.side_effect = ObjectStorageError("mock write failed")

        with self.settings(OBJECT_STORAGE_ENABLED=True, OBJECT_STORAGE_EXPORTS_FOLDER="Test-Exports"):
            csv_exporter.export_tabular(exported_asset)

            assert exported_asset.content is not None
            assert b"Test message" in exported_asset.content, f"Nested content missing when null row came first"

    @patch("products.exports.backend.models.exported_asset.UUIDT")
    @patch("products.exports.backend.models.exported_asset.object_storage.write_from_file")
    @patch("products.exports.backend.tasks.csv_exporter.get_from_query")
    def test_all_null_rows_still_includes_requested_column(
        self,
        mocked_get_from_query: Any,
        mocked_object_storage_write_from_file: Any,
        mocked_uuidt: Any,
    ) -> None:
        """When all rows have null for a requested column, the column header should still appear."""
        mocked_get_from_query.return_value = iter(
            [
                {"id": "trace-1", "inputState": None},
                {"id": "trace-2", "inputState": None},
            ]
        )

        exported_asset = ExportedAsset(
            team=self.team,
            export_format=ExportedAsset.ExportFormat.CSV,
            export_context={
                "columns": ["id", "inputState"],
                "source": {"kind": "TracesQuery"},
            },
        )
        exported_asset.save()
        mocked_uuidt.return_value = "test-guid"
        mocked_object_storage_write_from_file.side_effect = ObjectStorageError("mock write failed")

        with self.settings(OBJECT_STORAGE_ENABLED=True, OBJECT_STORAGE_EXPORTS_FOLDER="Test-Exports"):
            csv_exporter.export_tabular(exported_asset)

            assert exported_asset.content is not None
            # Header should contain inputState column even when all values are null
            assert b"inputState" in exported_asset.content
            # Verify both data rows are present
            assert b"trace-1" in exported_asset.content
            assert b"trace-2" in exported_asset.content

    @patch("products.exports.backend.models.exported_asset.UUIDT")
    @patch("products.exports.backend.models.exported_asset.object_storage.write_from_file")
    @patch("products.exports.backend.tasks.csv_exporter.get_from_query")
    def test_deeply_nested_objects_are_flattened(
        self,
        mocked_get_from_query: Any,
        mocked_object_storage_write_from_file: Any,
        mocked_uuidt: Any,
    ) -> None:
        """Deeply nested objects should be flattened to dot-notation columns."""
        mocked_get_from_query.return_value = iter(
            [
                {
                    "id": "trace-1",
                    "inputState": {
                        "messages": [
                            {"role": "user", "content": "First message"},
                            {"role": "user", "content": "Second message"},
                        ],
                        "metadata": {"source": "web"},
                    },
                },
            ]
        )

        exported_asset = ExportedAsset(
            team=self.team,
            export_format=ExportedAsset.ExportFormat.CSV,
            export_context={
                "columns": ["id", "inputState"],
                "source": {"kind": "TracesQuery"},
            },
        )
        exported_asset.save()
        mocked_uuidt.return_value = "test-guid"
        mocked_object_storage_write_from_file.side_effect = ObjectStorageError("mock write failed")

        with self.settings(OBJECT_STORAGE_ENABLED=True, OBJECT_STORAGE_EXPORTS_FOLDER="Test-Exports"):
            csv_exporter.export_tabular(exported_asset)

            assert exported_asset.content is not None
            assert b"First message" in exported_asset.content
            assert b"Second message" in exported_asset.content
            assert b"web" in exported_asset.content
            # Nested objects should be flattened to dot-notation columns
            assert b"inputState.messages.0.content" in exported_asset.content
            assert b"inputState.messages.1.content" in exported_asset.content


class TestSanitizeFormulaInjection:
    @pytest.mark.parametrize(
        "input_value,expected",
        [
            ("=SUM(A1:A10)", "'=SUM(A1:A10)"),
            ("+SUM(A1:A10)", "'+SUM(A1:A10)"),
            ("-SUM(A1:A10)", "'-SUM(A1:A10)"),
            ("@SUM(A1:A10)", "'@SUM(A1:A10)"),
            ("\tSUM(A1:A10)", "'\tSUM(A1:A10)"),
            ("\rSUM(A1:A10)", "'\rSUM(A1:A10)"),
            ('=CMD("cmd /C calc")', '\'=CMD("cmd /C calc")'),
        ],
    )
    def test_prefixes_dangerous_strings(self, input_value: str, expected: str) -> None:
        assert sanitize_formula_injection(input_value) == expected

    @pytest.mark.parametrize(
        "input_value",
        [
            "hello",
            "normal text",
            "123",
            "",
            42,
            -5,
            3.14,
            -2.5,
            None,
            True,
            False,
        ],
    )
    def test_passes_through_safe_values(self, input_value: Any) -> None:
        assert sanitize_formula_injection(input_value) == input_value

    def test_csv_writer_sanitizes_values(self) -> None:
        writer = CsvWriter()
        writer.write_header(["name", "value"])
        writer.write_row({"name": "=evil", "value": "safe"})
        path = writer.finish()
        try:
            with open(path) as f:
                content = f.read()
            assert "'=evil" in content
            assert ",safe" in content
        finally:
            os.unlink(path)

    def test_excel_writer_sanitizes_values(self) -> None:
        writer = ExcelWriter()
        writer.write_header(["name", "value"])
        writer.write_row({"name": "=evil", "value": "+dangerous"})
        path = writer.finish()
        try:
            wb = load_workbook(path)
            ws = wb.active
            rows = list(ws.iter_rows(min_row=2, values_only=True))
            assert rows[0][0] == "'=evil"
            assert rows[0][1] == "'+dangerous"
        finally:
            os.unlink(path)

    def test_csv_writer_sanitizes_headers(self) -> None:
        writer = CsvWriter()
        writer.write_header(["=formula", "safe"])
        writer.write_row({"=formula": "val1", "safe": "val2"})
        path = writer.finish()
        try:
            with open(path) as f:
                header_line = f.readline()
            assert "'=formula" in header_line
            assert ",safe" in header_line
        finally:
            os.unlink(path)

    def test_excel_writer_sanitizes_headers(self) -> None:
        writer = ExcelWriter()
        writer.write_header(["=formula", "safe"])
        writer.write_row({"=formula": "val1", "safe": "val2"})
        path = writer.finish()
        try:
            wb = load_workbook(path)
            ws = wb.active
            headers = next(ws.iter_rows(min_row=1, max_row=1, values_only=True))
            assert headers[0] == "'=formula"
            assert headers[1] == "safe"
        finally:
            os.unlink(path)

    def test_excel_writer_illegal_char_bypass(self) -> None:
        writer = ExcelWriter()
        writer.write_header(["col"])
        writer.write_row({"col": "\x01=SUM(A1:B1)"})
        path = writer.finish()
        try:
            wb = load_workbook(path)
            ws = wb.active
            rows = list(ws.iter_rows(min_row=2, values_only=True))
            assert rows[0][0] == "'=SUM(A1:B1)"
        finally:
            os.unlink(path)
