import ipaddress
from contextlib import nullcontext
from datetime import datetime, timedelta
from typing import Literal, Optional

import pytest
from freezegun import freeze_time
from posthog.test.base import APIBaseTest, _create_event, flush_persons_and_events
from unittest.mock import ANY, AsyncMock, patch

from django.http import HttpResponse
from django.utils.timezone import now

import requests.exceptions
from boto3 import resource
from botocore.client import Config
from parameterized import parameterized
from prometheus_client import CollectorRegistry, Counter
from rest_framework import status

from posthog.hogql.errors import QueryError

from posthog.exceptions import ClickHouseAtCapacity
from posthog.models.activity_logging.activity_log import ActivityLog
from posthog.models.filters.filter import Filter
from posthog.models.personal_api_key import PersonalAPIKey
from posthog.models.team import Team
from posthog.models.user import User
from posthog.models.utils import generate_random_token_personal, hash_key_value
from posthog.settings import (
    HOGQL_INCREASED_MAX_EXECUTION_TIME,
    OBJECT_STORAGE_ACCESS_KEY_ID,
    OBJECT_STORAGE_BUCKET,
    OBJECT_STORAGE_ENDPOINT,
    OBJECT_STORAGE_SECRET_ACCESS_KEY,
)
from posthog.tasks import exporter
from posthog.temporal.session_replay.rasterize_recording.types import RASTERIZE_WORKFLOW_TIMEOUT

from products.access_control.backend.models.access_control import AccessControl
from products.dashboards.backend.models.dashboard import Dashboard
from products.dashboards.backend.models.dashboard_tile import DashboardTile
from products.exports.backend.facade.api import EXPORT_WORKFLOW_TIMEOUT
from products.exports.backend.models.exported_asset import DATASET_EXPORT_KIND, ExportedAsset
from products.exports.backend.source_authentication import required_scopes_for_export_target
from products.exports.backend.tasks.failure_handler import FAILURE_TYPE_SYSTEM, FAILURE_TYPE_USER
from products.exports.backend.tasks.image_exporter import export_image
from products.product_analytics.backend.facade.models import Insight
from products.product_analytics.backend.presentation.insight import InsightSerializer

TEST_ROOT_BUCKET = "test_exports"


def get_counter_value(counter: Counter, labels: dict) -> float:
    """Get counter value using the _metrics dict directly (works across threads)."""
    label_values = tuple(str(labels.get(label, "")) for label in counter._labelnames)
    metric = counter._metrics.get(label_values)
    if metric is None:
        return 0.0
    value_container = getattr(metric, "_value", None)
    return value_container.get() if value_container else 0.0


class TestExports(APIBaseTest):
    exported_asset: ExportedAsset
    dashboard: Dashboard
    insight: Insight
    tile: DashboardTile

    def teardown_method(self, method) -> None:
        s3 = resource(
            "s3",
            endpoint_url=OBJECT_STORAGE_ENDPOINT,
            aws_access_key_id=OBJECT_STORAGE_ACCESS_KEY_ID,
            aws_secret_access_key=OBJECT_STORAGE_SECRET_ACCESS_KEY,
            config=Config(signature_version="s3v4"),
            region_name="us-east-1",
        )
        bucket = s3.Bucket(OBJECT_STORAGE_BUCKET)
        bucket.objects.filter(Prefix=TEST_ROOT_BUCKET).delete()

    def test_heatmap_export_requires_heatmap_scope(self) -> None:
        assert required_scopes_for_export_target(
            insight_id=None,
            dashboard_id=None,
            export_context={"heatmap_url": "https://example.com/page"},
        ) == ["export:write", "heatmap:read"]

    @parameterized.expand(
        [
            (
                "us_same_origin",
                "https://us.posthog.com",
                "https://us.posthog.com/api/environments/1/heatmap_screenshots/2/content/",
                201,
            ),
            (
                "eu_same_origin",
                "https://eu.posthog.com",
                "https://eu.posthog.com/api/environments/1/heatmap_screenshots/2/content/",
                201,
            ),
            ("cross_origin", "https://us.posthog.com", "https://example.com/collect", 400),
        ]
    )
    @patch("products.exports.backend.api.exports.ExportedAssetSerializer._start_export_workflow")
    def test_screenshot_heatmap_export_requires_same_origin_url(
        self, _name: str, site_url: str, heatmap_url: str, expected_status: int, mock_exporter_task
    ) -> None:
        with self.settings(SITE_URL=site_url):
            response = self.client.post(
                f"/api/projects/{self.team.id}/exports/",
                {
                    "export_format": ExportedAsset.ExportFormat.PNG,
                    "export_context": {
                        "heatmap_url": heatmap_url,
                        "heatmap_data_url": "https://example.com/page",
                        "heatmap_type": "screenshot",
                    },
                },
            )

        assert response.status_code == expected_status
        if expected_status == status.HTTP_201_CREATED:
            mock_exporter_task.assert_called_once()
        else:
            mock_exporter_task.assert_not_called()

    insight_filter_dict = {
        "events": [{"id": "$pageview"}],
        "properties": [{"key": "$browser", "value": "Mac OS X"}],
    }

    @classmethod
    def setUpTestData(cls):
        super().setUpTestData()

        cls.dashboard = Dashboard.objects.create(team=cls.team, name="example dashboard", created_by=cls.user)
        cls.insight = Insight.objects.create(
            filters=Filter(data=cls.insight_filter_dict).to_dict(),
            team=cls.team,
            created_by=cls.user,
            name="example insight",
        )
        cls.tile = DashboardTile.objects.create(dashboard=cls.dashboard, insight=cls.insight)
        cls.exported_asset = ExportedAsset.objects.create(
            team=cls.team, dashboard_id=cls.dashboard.id, export_format="image/png", created_by=cls.user
        )

    @patch("products.exports.backend.api.exports.ExportedAssetSerializer._start_export_workflow")
    def test_api_path_export_rejects_mutating_requests(self, mock_exporter_task) -> None:
        response = self.client.post(
            f"/api/projects/{self.team.id}/exports/",
            {
                "export_format": "text/csv",
                "export_context": {
                    "path": f"/api/organizations/{self.organization.id}/invites/",
                    "method": "POST",
                    "body": {"target_email": "security-test@example.com", "level": 8},
                },
            },
        )

        assert response.status_code == status.HTTP_400_BAD_REQUEST
        mock_exporter_task.assert_not_called()

    @parameterized.expand(
        [
            ("missing_query_scope", ["export:write"], status.HTTP_403_FORBIDDEN),
            ("query_scope", ["export:write", "query:read"], status.HTTP_201_CREATED),
        ]
    )
    @patch("products.exports.backend.api.exports.ExportedAssetSerializer._start_export_workflow")
    def test_query_export_requires_query_scope(
        self, _name: str, scopes: list[str], expected_status: int, mock_exporter_task
    ) -> None:
        token = generate_random_token_personal()
        personal_api_key = PersonalAPIKey.objects.create(
            user=self.user,
            label="query export key",
            secure_value=hash_key_value(token),
            scopes=scopes,
            scoped_teams=[self.team.id],
        )

        response = self.client.post(
            f"/api/projects/{self.team.id}/exports/",
            {
                "export_format": "text/csv",
                "export_context": {"source": {"kind": "HogQLQuery", "query": "select 1"}},
            },
            HTTP_AUTHORIZATION=f"Bearer {token}",
        )

        assert response.status_code == expected_status
        if expected_status == status.HTTP_201_CREATED:
            exported_asset = ExportedAsset.objects.get(id=response.json()["id"])
            assert exported_asset.source_authentication == ExportedAsset.SourceAuthentication.PERSONAL_API_KEY
            assert exported_asset.source_credential_id == personal_api_key.id
            mock_exporter_task.assert_called_once()
        else:
            mock_exporter_task.assert_not_called()

    @parameterized.expand(
        [
            ("insight_missing_scope", "insight", ["export:write"], status.HTTP_403_FORBIDDEN),
            (
                "insight_read_scope",
                "insight",
                ["export:write", "insight:read"],
                status.HTTP_201_CREATED,
            ),
            ("dashboard_missing_scope", "dashboard", ["export:write"], status.HTTP_403_FORBIDDEN),
            (
                "dashboard_read_scope",
                "dashboard",
                ["export:write", "dashboard:read"],
                status.HTTP_201_CREATED,
            ),
            ("recording_missing_scope", "recording", ["export:write"], status.HTTP_403_FORBIDDEN),
            (
                "recording_read_scope",
                "recording",
                ["export:write", "session_recording:read"],
                status.HTTP_201_CREATED,
            ),
        ]
    )
    @patch("products.exports.backend.api.exports.ExportedAssetSerializer._start_export_workflow")
    def test_typed_export_requires_resource_read_scope(
        self,
        _name: str,
        target: Literal["insight", "dashboard", "recording"],
        scopes: list[str],
        expected_status: int,
        mock_exporter_task,
    ) -> None:
        token = generate_random_token_personal()
        PersonalAPIKey.objects.create(
            user=self.user,
            label="typed export key",
            secure_value=hash_key_value(token),
            scopes=scopes,
            scoped_teams=[self.team.id],
        )
        payload: dict[str, object] = {"export_format": ExportedAsset.ExportFormat.PNG}
        if target == "insight":
            payload["insight"] = self.insight.id
        elif target == "dashboard":
            payload["dashboard"] = self.dashboard.id
        else:
            payload["export_context"] = {"session_recording_id": "typed-export-recording"}

        response = self.client.post(
            f"/api/projects/{self.team.id}/exports/",
            payload,
            HTTP_AUTHORIZATION=f"Bearer {token}",
        )

        assert response.status_code == expected_status
        if expected_status == status.HTTP_201_CREATED:
            mock_exporter_task.assert_called_once()
        else:
            mock_exporter_task.assert_not_called()

    @patch("products.exports.backend.api.exports.ExportedAssetSerializer._start_export_workflow")
    def test_can_create_new_valid_export_dashboard(self, mock_exporter_task) -> None:
        # add filter to dashboard
        self.dashboard.filters = {"properties": [{"key": "$browser_version", "value": "1.0"}]}
        self.dashboard.save()

        response = self.client.post(
            f"/api/projects/{self.team.id}/exports",
            {"export_format": "image/png", "dashboard": self.dashboard.id},
        )
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        data = response.json()
        created_date = datetime.fromisoformat(data["created_at"]).strftime("%Y-%m-%d-%H%M%S")
        assert data == {
            "id": data["id"],
            "created_at": data["created_at"],
            "dashboard": self.dashboard.id,
            "exception": None,
            "export_format": "image/png",
            "filename": f"export-example-dashboard-{created_date}.png",
            "has_content": False,
            "insight": None,
            "export_context": None,
            # PNG format gets 180 days (6 months) expiry
            "expires_after": (now() + timedelta(days=180))
            .replace(hour=0, minute=0, second=0, microsecond=0)
            .isoformat()
            .replace("+00:00", "Z"),
            "user_access_level": "manager",
        }

        mock_exporter_task.assert_called_once()
        assert mock_exporter_task.call_args[0][0].id == data["id"]

    @patch("products.exports.backend.api.exports.ExportedAssetSerializer._start_export_workflow")
    def test_can_create_export_with_ttl(self, mock_exporter_task) -> None:
        one_week_from_now = datetime.now() + timedelta(weeks=1)
        response = self.client.post(
            f"/api/projects/{self.team.id}/exports",
            {
                "export_format": "image/png",
                "dashboard": self.dashboard.id,
                "expires_after": one_week_from_now.isoformat(),
            },
        )
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        data = response.json()

        # Expiry is determined by format (PNG = 180 days), not the provided value
        expected_expiry = (
            (now() + timedelta(days=180))
            .replace(hour=0, minute=0, second=0, microsecond=0)
            .isoformat()
            .replace("+00:00", "Z")
        )

        created_date = datetime.fromisoformat(data["created_at"]).strftime("%Y-%m-%d-%H%M%S")
        assert data == {
            "id": data["id"],
            "created_at": data["created_at"],
            "dashboard": self.dashboard.id,
            "exception": None,
            "export_format": "image/png",
            "filename": f"export-example-dashboard-{created_date}.png",
            "has_content": False,
            "insight": None,
            "export_context": None,
            "expires_after": expected_expiry,
            "user_access_level": "manager",
        }

        mock_exporter_task.assert_called_once()
        assert mock_exporter_task.call_args[0][0].id == data["id"]

    @patch("products.exports.backend.api.exports.ExportedAssetSerializer._start_export_workflow")
    def test_accepts_legacy_insight_api_path_export(self, mock_exporter_task) -> None:
        response = self.client.post(
            f"/api/projects/{self.team.id}/exports",
            {
                "export_format": "text/csv",
                "export_context": {
                    "path": f"api/projects/{self.team.id}/insights/trend/?insight=TRENDS&events=%5B%7B%22id%22%3A%22search%20filtered%22%2C%22name%22%3A%22search%20filtered%22%2C%22type%22%3A%22events%22%2C%22order%22%3A0%7D%5D&actions=%5B%5D&display=ActionsTable&interval=day&breakdown=filters&new_entity=%5B%5D&properties=%5B%5D&breakdown_type=event&filter_test_accounts=false&date_from=-14d"
                },
            },
        )
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        mock_exporter_task.assert_called_once()

    @patch("products.exports.backend.tasks.image_exporter._export_to_png")
    @patch("products.exports.backend.api.exports.ExportedAssetSerializer._start_export_workflow")
    @freeze_time("2021-08-25T22:09:14.252Z")
    def test_can_create_new_valid_export_insight(self, mock_exporter_task, mock_export_to_png) -> None:
        response = self.client.post(
            f"/api/projects/{self.team.id}/exports",
            {"export_format": "image/png", "insight": self.insight.id},
        )
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        data = response.json()
        self.assertEqual(
            data,
            {
                "id": data["id"],
                "created_at": data["created_at"],
                "insight": self.insight.id,
                "export_format": "image/png",
                "filename": "export-example-insight-2021-08-25-220914.png",
                "has_content": False,
                "dashboard": None,
                "exception": None,
                "export_context": None,
                # PNG format gets 180 days (6 months) expiry
                "expires_after": (now() + timedelta(days=180))
                .replace(hour=0, minute=0, second=0, microsecond=0)
                .isoformat()
                .replace("+00:00", "Z"),
                "user_access_level": "manager",
            },
        )

        self._assert_logs_the_activity(
            insight_id=self.insight.id,
            expected=[
                {
                    "user": {
                        "first_name": self.user.first_name,
                        "email": self.user.email,
                    },
                    "activity": "exported",
                    "created_at": "2021-08-25T22:09:14.252000Z",
                    "scope": "Insight",
                    "item_id": str(self.insight.id),
                    "detail": {
                        "changes": [
                            {
                                "action": "exported",
                                "after": "image/png",
                                "before": None,
                                "field": "export_format",
                                "type": "Insight",
                            }
                        ],
                        "trigger": None,
                        "type": None,
                        "name": self.insight.name,
                        "short_id": self.insight.short_id,
                    },
                }
            ],
        )

        mock_exporter_task.assert_called_once()
        assert mock_exporter_task.call_args[0][0].id == data["id"]

        # look at the page the screenshot will be taken of
        exported_asset = ExportedAsset.objects.get(pk=data["id"])

        with patch("products.exports.backend.tasks.image_exporter.calculate_for_query_based_insight") as mock_calculate:
            # Request does not calculate the result and cache is not warmed up
            context = {"is_shared": True}
            InsightSerializer(self.insight, many=False, context=context)

            mock_calculate.assert_not_called()

            # Should warm up the cache
            export_image(exported_asset)
            mock_export_to_png.assert_called_once_with(exported_asset, max_height_pixels=None, insight_cache_keys=ANY)

            mock_calculate.assert_called_once()

    @patch("products.exports.backend.api.exports.ExportedAssetSerializer._start_export_workflow")
    def test_logs_exported_asset_activity_for_sql_export(self, _mock_exporter_task) -> None:
        response = self.client.post(
            f"/api/projects/{self.team.id}/exports",
            {
                "export_format": "text/csv",
                "export_context": {"source": {"kind": "HogQLQuery", "query": "select 1"}},
            },
            format="json",
        )
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        asset_id = response.json()["id"]

        logs = ActivityLog.objects.filter(scope="ExportedAsset", item_id=str(asset_id))
        self.assertEqual(logs.count(), 1)
        log = logs.first()
        assert log is not None
        assert log.detail is not None
        self.assertEqual(log.activity, "exported")
        self.assertEqual(log.team_id, self.team.id)
        self.assertEqual(log.user_id, self.user.id)
        self.assertEqual(log.detail["name"], "SQL query results")
        self.assertEqual(log.detail["changes"][0]["after"], "text/csv")

    @patch("products.exports.backend.api.exports.ExportedAssetSerializer._start_export_workflow")
    def test_logs_exported_asset_activity_for_dashboard_export(self, _mock_exporter_task) -> None:
        response = self.client.post(
            f"/api/projects/{self.team.id}/exports",
            {"export_format": "image/png", "dashboard": self.dashboard.id},
        )
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        asset_id = response.json()["id"]

        logs = ActivityLog.objects.filter(scope="ExportedAsset", item_id=str(asset_id))
        self.assertEqual(logs.count(), 1)
        log = logs.first()
        assert log is not None
        assert log.detail is not None
        self.assertEqual(log.detail["name"], self.dashboard.name)

    @patch("products.exports.backend.tasks.image_exporter._export_to_png")
    @patch("products.exports.backend.api.exports.ExportedAssetSerializer._start_export_workflow")
    def test_insight_export_does_not_create_duplicate_exported_asset_activity(
        self, _mock_exporter_task, _mock_export_to_png
    ) -> None:
        response = self.client.post(
            f"/api/projects/{self.team.id}/exports",
            {"export_format": "image/png", "insight": self.insight.id},
        )
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        asset_id = response.json()["id"]

        # Insight exports are recorded once under the Insight scope, never duplicated under ExportedAsset.
        self.assertFalse(ActivityLog.objects.filter(scope="ExportedAsset", item_id=str(asset_id)).exists())
        self.assertTrue(
            ActivityLog.objects.filter(scope="Insight", item_id=str(self.insight.id), activity="exported").exists()
        )

    def test_errors_if_missing_related_instance(self) -> None:
        response = self.client.post(f"/api/projects/{self.team.id}/exports", {"export_format": "image/png"})
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertEqual(
            response.json(),
            {
                "attr": None,
                "code": "invalid_input",
                "detail": "Either dashboard, insight or export_context is required for an export.",
                "type": "validation_error",
            },
        )

    def test_errors_if_the_request_picks_its_own_limit_context(self) -> None:
        response = self.client.post(
            f"/api/projects/{self.team.id}/exports",
            {
                "export_format": "image/png",
                "export_context": {
                    "source": {"kind": "HogQLQuery", "query": "SELECT 1"},
                    "limit_context": "posthog_ai",
                },
            },
            format="json",
        )
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertEqual(response.json()["attr"], "export_context")
        self.assertEqual(response.json()["detail"], "limit_context is not supported for exports.")

    @parameterized.expand(["not/allowed", ExportedAsset.ExportFormat.JSONL])
    def test_errors_if_bad_format(self, export_format: str) -> None:
        response = self.client.post(f"/api/projects/{self.team.id}/exports", {"export_format": export_format})
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertEqual(
            response.json(),
            {
                "attr": "export_format",
                "code": "invalid_choice",
                "detail": f'"{export_format}" is not a valid choice.',
                "type": "validation_error",
            },
        )

    @patch("products.exports.backend.api.exports.ExportedAssetSerializer._start_export_workflow")
    def test_will_error_if_export_unsupported(self, mock_exporter_task) -> None:
        response = self.client.post(
            f"/api/projects/{self.team.id}/exports",
            {"export_format": "image/jpeg", "insight": self.insight.id},
        )
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertEqual(
            response.json(),
            {
                "attr": "export_format",
                "code": "invalid_choice",
                "detail": '"image/jpeg" is not a valid choice.',
                "type": "validation_error",
            },
        )

    def test_will_error_if_dashboard_missing(self) -> None:
        response = self.client.post(
            f"/api/projects/{self.team.id}/exports",
            {"export_format": "application/pdf", "dashboard": 54321},
        )
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertEqual(
            response.json(),
            {
                "attr": "dashboard",
                "code": "does_not_exist",
                "detail": 'Invalid pk "54321" - object does not exist.',
                "type": "validation_error",
            },
        )

    def test_will_error_if_export_contains_other_team_dashboard(self) -> None:
        other_team = Team.objects.create(
            organization=self.organization,
            api_token=self.CONFIG_API_TOKEN + "2",
            test_account_filters=[
                {
                    "key": "email",
                    "value": "@posthog.com",
                    "operator": "not_icontains",
                    "type": "person",
                }
            ],
        )
        other_dashboard = Dashboard.objects.create(
            team=other_team, name="example dashboard other", created_by=self.user
        )

        response = self.client.post(
            f"/api/projects/{self.team.id}/exports",
            {"export_format": "application/pdf", "dashboard": other_dashboard.id},
        )
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertEqual(
            response.json(),
            {
                "attr": "dashboard",
                "code": "invalid_input",
                "detail": "This dashboard does not belong to your team.",
                "type": "validation_error",
            },
        )

    def test_will_error_if_export_contains_other_team_insight(self) -> None:
        other_team = Team.objects.create(
            organization=self.organization,
            api_token=self.CONFIG_API_TOKEN + "2",
            test_account_filters=[
                {
                    "key": "email",
                    "value": "@posthog.com",
                    "operator": "not_icontains",
                    "type": "person",
                }
            ],
        )
        other_insight = Insight.objects.create(
            filters=Filter(data=self.insight_filter_dict).to_dict(),
            team=other_team,
            created_by=self.user,
        )

        response = self.client.post(
            f"/api/projects/{self.team.id}/exports",
            {"export_format": "application/pdf", "insight": other_insight.id},
        )
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertEqual(
            response.json(),
            {
                "attr": "insight",
                "code": "invalid_input",
                "detail": "This insight does not belong to your team.",
                "type": "validation_error",
            },
        )

    @patch("products.exports.backend.tasks.csv_exporter.requests.request")
    def test_can_download_a_csv(self, patched_request) -> None:
        with self.settings(SITE_URL="http://testserver", OBJECT_STORAGE_ENABLED=False):
            _create_event(
                event="event_name",
                team=self.team,
                distinct_id="2",
                properties={"$browser": "Chrome"},
            )
            expected_event_id = _create_event(
                event="event_name",
                team=self.team,
                distinct_id="2",
                properties={"$browser": "Safari"},
            )
            second_expected_event_id = _create_event(
                event="event_name",
                team=self.team,
                distinct_id="2",
                properties={"$browser": "Safari"},
            )
            third_expected_event_id = _create_event(
                event="event_name",
                team=self.team,
                distinct_id="2",
                properties={"$browser": "Safari"},
            )
            flush_persons_and_events()

            after = (datetime.now() - timedelta(minutes=10)).isoformat()

            def requests_side_effect(*args, **kwargs):
                response = self.client.get(kwargs["url"], kwargs["json"], **kwargs["headers"])

                def raise_for_status():
                    if 400 <= response.status_code < 600:
                        raise requests.exceptions.HTTPError(response=response)  # type: ignore[arg-type]

                response.raise_for_status = raise_for_status  # type: ignore[attr-defined]
                return response

            patched_request.side_effect = requests_side_effect

            path = "&".join(
                [
                    f"/api/projects/{self.team.id}/events?orderBy=%5B%22-timestamp%22%5D",
                    "properties=%5B%7B%22key%22%3A%22%24browser%22%2C%22value%22%3A%5B%22Safari%22%5D%2C%22operator%22%3A%22exact%22%2C%22type%22%3A%22event%22%7D%5D",
                    f"after={after}",
                ]
            )
            instance = ExportedAsset.objects.create(
                team=self.team,
                created_by=self.user,
                export_format=ExportedAsset.ExportFormat.CSV,
                export_context={"path": path},
                source_authentication=ExportedAsset.SourceAuthentication.SESSION,
            )

            # limit the query to force it to page against the API
            exporter.export_asset(instance.id, limit=1)

            download_response: Optional[HttpResponse] = None
            attempt_count = 0
            while attempt_count < 10 and not download_response:
                download_response = self.client.get(
                    f"/api/projects/{self.team.id}/exports/{instance.id}/content?download=true"
                )
                attempt_count += 1

            if not download_response:
                self.fail("must have a response by this point")  # hi mypy

            self.assertEqual(download_response.status_code, status.HTTP_200_OK)
            self.assertIsNotNone(download_response.content)
            file_content = download_response.content.decode("utf-8")
            file_lines = file_content.split("\n")
            # has a header row and at least two other rows
            # don't care if the DB hasn't been reset before the test
            self.assertTrue(len(file_lines) > 3)
            self.assertIn(expected_event_id, file_content)
            self.assertIn(second_expected_event_id, file_content)
            self.assertIn(third_expected_event_id, file_content)
            for line in file_lines[1:]:  # every result has to match the filter though
                if line != "":  # skip the final empty line of the file
                    self.assertIn("Safari", line)

    def _get_insight_activity(self, insight_id: int, expected_status: int = status.HTTP_200_OK):
        url = f"/api/projects/{self.team.id}/insights/{insight_id}/activity"
        activity = self.client.get(url)
        self.assertEqual(activity.status_code, expected_status)
        return activity.json()

    def _assert_logs_the_activity(self, insight_id: int, expected: list[dict]) -> None:
        activity_response = self._get_insight_activity(insight_id)

        activity: list[dict] = activity_response["results"]
        for item in activity:
            item.pop("id", None)
            for envelope_key in ("is_system", "was_impersonated", "client"):
                item.pop(envelope_key, None)

        self.maxDiff = None
        self.assertEqual(activity, expected)

    def test_can_list_exports(self) -> None:
        response = self.client.get(f"/api/projects/{self.team.id}/exports")
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.json()["results"]), 1)

        ExportedAsset.objects.create(
            team=self.team, dashboard_id=self.dashboard.id, export_format="image/png", created_by=self.user
        )

        # Also crete an unrelated export in the db
        ExportedAsset.objects.create(
            team=self.team, dashboard_id=self.dashboard.id, export_format="image/png", created_by=None
        )

        response = self.client.get(f"/api/projects/{self.team.id}/exports")
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.json()["results"]), 2)

    def test_dataset_exports_are_visible_to_their_creator_in_the_export_list(self) -> None:
        dataset_export = ExportedAsset.objects.create(
            team=self.team,
            export_format=ExportedAsset.ExportFormat.JSONL,
            export_context={
                "kind": DATASET_EXPORT_KIND,
                "dataset_id": "302b0ee8-18a2-45d1-91a9-1a347853f6e5",
                "dataset_revision": 1,
            },
            created_by=self.user,
        )
        other_user = User.objects.create_and_join(self.organization, "dataset-export-peer@posthog.com", "password")
        other_dataset_export = ExportedAsset.objects.create(
            team=self.team,
            export_format=ExportedAsset.ExportFormat.JSONL,
            export_context={
                "kind": DATASET_EXPORT_KIND,
                "dataset_id": "c5a78135-2418-42ab-b721-e493a6743d3b",
                "dataset_revision": 1,
            },
            created_by=other_user,
        )

        response = self.client.get(f"/api/projects/{self.team.id}/exports")

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        results_by_id = {result["id"]: result for result in response.json()["results"]}
        self.assertEqual(results_by_id[dataset_export.id]["export_format"], ExportedAsset.ExportFormat.JSONL)
        self.assertNotIn(other_dataset_export.id, results_by_id)

    def test_dataset_exports_are_hidden_from_generic_retrieve(self) -> None:
        dataset_export = ExportedAsset.objects.create(
            team=self.team,
            export_format=ExportedAsset.ExportFormat.JSONL,
            export_context={
                "kind": DATASET_EXPORT_KIND,
                "dataset_id": "302b0ee8-18a2-45d1-91a9-1a347853f6e5",
                "dataset_revision": 1,
            },
            created_by=self.user,
            content=b"{}\n",
        )

        response = self.client.get(f"/api/projects/{self.team.id}/exports/{dataset_export.id}")

        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)

    def test_dataset_export_content_redirects_to_dataset_endpoint(self) -> None:
        dataset_id = "302b0ee8-18a2-45d1-91a9-1a347853f6e5"
        dataset_export = ExportedAsset.objects.create(
            team=self.team,
            export_format=ExportedAsset.ExportFormat.JSONL,
            export_context={
                "kind": DATASET_EXPORT_KIND,
                "dataset_id": dataset_id,
                "dataset_revision": 1,
            },
            created_by=self.user,
            content=b"{}\n",
        )

        response = self.client.get(f"/api/projects/{self.team.id}/exports/{dataset_export.id}/content")

        self.assertRedirects(
            response,
            f"/api/projects/{self.team.id}/datasets/{dataset_id}/exports/{dataset_export.id}/content",
            fetch_redirect_response=False,
        )

    def test_dataset_id_metadata_does_not_hide_an_ordinary_export(self) -> None:
        ordinary_export = ExportedAsset.objects.create(
            team=self.team,
            export_format=ExportedAsset.ExportFormat.PNG,
            export_context={"dataset_id": "caller-metadata"},
            created_by=self.user,
            content=b"png",
        )

        retrieve_response = self.client.get(f"/api/projects/{self.team.id}/exports/{ordinary_export.id}")
        list_response = self.client.get(f"/api/projects/{self.team.id}/exports")

        self.assertEqual(retrieve_response.status_code, status.HTTP_200_OK)
        self.assertIn(ordinary_export.id, {result["id"] for result in list_response.json()["results"]})

    def test_list_shows_stuck_exports_as_failed_in_response(self) -> None:
        with freeze_time(now() - timedelta(seconds=2 * HOGQL_INCREASED_MAX_EXECUTION_TIME)):
            # Create an export that's older than HOGQL_INCREASED_MAX_EXECUTION_TIME
            stuck_export = ExportedAsset.objects.create(
                team=self.team,
                dashboard_id=self.dashboard.id,
                export_format="image/png",
                created_by=self.user,
                content=None,
                content_location=None,
                exception=None,
            )

            # Create an export that already has content - should not be marked as failed
            completed_export = ExportedAsset.objects.create(
                team=self.team,
                dashboard_id=self.dashboard.id,
                export_format="image/png",
                created_by=self.user,
                created_at=now() - timedelta(seconds=HOGQL_INCREASED_MAX_EXECUTION_TIME + 100),
                content=b"some content",
                exception=None,
            )

            # Create an export that has an exception - should not be overridden
            errored_export = ExportedAsset.objects.create(
                team=self.team,
                dashboard_id=self.dashboard.id,
                export_format="image/png",
                created_by=self.user,
                created_at=now() - timedelta(seconds=HOGQL_INCREASED_MAX_EXECUTION_TIME + 100),
                content=None,
                exception="exception",
            )

        # Create a recent export that should not be marked as failed
        recent_export = ExportedAsset.objects.create(
            team=self.team,
            dashboard_id=self.dashboard.id,
            export_format="image/png",
            created_by=self.user,
            content=None,
            content_location=None,
            exception=None,
        )

        response = self.client.get(f"/api/projects/{self.team.id}/exports")
        self.assertEqual(response.status_code, status.HTTP_200_OK)

        results = response.json()["results"]
        results_by_id = {result["id"]: result for result in results}

        stuck_result = results_by_id[stuck_export.id]
        self.assertIsNotNone(stuck_result["exception"])
        self.assertIn(f"Export failed without throwing an exception", stuck_result["exception"])

        recent_result = results_by_id[recent_export.id]
        self.assertIsNone(recent_result["exception"])

        completed_result = results_by_id[completed_export.id]
        self.assertIsNone(completed_result["exception"])

        completed_result = results_by_id[errored_export.id]
        self.assertEqual("exception", completed_result["exception"])

        # Verify that the database wasn't actually modified
        stuck_export.refresh_from_db()
        recent_export.refresh_from_db()
        completed_export.refresh_from_db()
        self.assertIsNone(stuck_export.exception)
        self.assertIsNone(recent_export.exception)
        self.assertIsNone(completed_export.exception)

    DATASET_EXPORT_CONTEXT = {
        "kind": DATASET_EXPORT_KIND,
        "dataset_id": "302b0ee8-18a2-45d1-91a9-1a347853f6e5",
        "dataset_revision": 1,
    }
    VIDEO_EXPORT_CONTEXT = {"session_recording_id": "01890a0e-0000-0000-0000-000000000000"}

    @parameterized.expand(
        [
            # A png still answers to the HogQL query timeout it inherits from the Celery exporter.
            (
                "png_past_query_timeout",
                ExportedAsset.ExportFormat.PNG,
                None,
                timedelta(seconds=HOGQL_INCREASED_MAX_EXECUTION_TIME + 31),
                True,
            ),
            (
                "dataset_within_workflow_timeout",
                ExportedAsset.ExportFormat.JSONL,
                DATASET_EXPORT_CONTEXT,
                timedelta(seconds=HOGQL_INCREASED_MAX_EXECUTION_TIME + 31),
                False,
            ),
            (
                "dataset_past_workflow_timeout",
                ExportedAsset.ExportFormat.JSONL,
                DATASET_EXPORT_CONTEXT,
                EXPORT_WORKFLOW_TIMEOUT + timedelta(seconds=31),
                True,
            ),
            # A video render legitimately runs well past the query timeout, so measuring it against
            # that timeout reports long recordings as failed while they are still rendering.
            (
                "video_within_workflow_timeout",
                ExportedAsset.ExportFormat.MP4,
                VIDEO_EXPORT_CONTEXT,
                timedelta(seconds=HOGQL_INCREASED_MAX_EXECUTION_TIME + 31),
                False,
            ),
            (
                "video_past_workflow_timeout",
                ExportedAsset.ExportFormat.MP4,
                VIDEO_EXPORT_CONTEXT,
                RASTERIZE_WORKFLOW_TIMEOUT + timedelta(seconds=31),
                True,
            ),
        ]
    )
    def test_stuck_threshold_matches_the_rendering_pipeline(
        self,
        _name,
        export_format: str,
        export_context: Optional[dict],
        age: timedelta,
        expected_failed: bool,
    ) -> None:
        with freeze_time(now() - age):
            export = ExportedAsset.objects.create(
                team=self.team,
                export_format=export_format,
                export_context=export_context,
                created_by=self.user,
            )

        response = self.client.get(f"/api/projects/{self.team.id}/exports")

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        results_by_id = {result["id"]: result for result in response.json()["results"]}
        self.assertEqual(results_by_id[export.id]["exception"] is not None, expected_failed)

    def test_listing_stuck_exports_emits_no_analytics_events(self) -> None:
        """Reporting stuck exports is a read path, so polling the list must not emit events.

        An event emitted while serializing fires once per asset per request for as long as the row
        stays incomplete, so the count reflects how often clients poll rather than how many exports
        failed.
        """
        with freeze_time(now() - RASTERIZE_WORKFLOW_TIMEOUT - timedelta(minutes=1)):
            ExportedAsset.objects.create(
                team=self.team,
                export_format=ExportedAsset.ExportFormat.MP4,
                export_context=self.VIDEO_EXPORT_CONTEXT,
                created_by=self.user,
            )

        with patch("posthoganalytics.capture") as mock_capture:
            response = self.client.get(f"/api/projects/{self.team.id}/exports")

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual([call for call in mock_capture.call_args_list if "export" in str(call)], [])

    def test_retrieve_shows_stuck_export_as_failed_in_response(self) -> None:
        with freeze_time(now() - timedelta(seconds=2 * HOGQL_INCREASED_MAX_EXECUTION_TIME)):
            # Create an export that's older than HOGQL_INCREASED_MAX_EXECUTION_TIME
            stuck_export = ExportedAsset.objects.create(
                team=self.team,
                dashboard_id=self.dashboard.id,
                export_format="image/png",
                created_by=self.user,
                created_at=now() - timedelta(seconds=HOGQL_INCREASED_MAX_EXECUTION_TIME + 100),
                content=None,
                content_location=None,
                exception=None,
            )

        response = self.client.get(f"/api/projects/{self.team.id}/exports/{stuck_export.id}")
        self.assertEqual(response.status_code, status.HTTP_200_OK)

        result = response.json()

        # Check that the stuck export appears to have an exception in the response
        self.assertIsNotNone(result["exception"])
        self.assertIn(f"Export failed without throwing an exception", result["exception"])

        # Verify that the database wasn't actually modified
        stuck_export.refresh_from_db()
        self.assertIsNone(stuck_export.exception)

    @parameterized.expand(
        [
            ("retrieve", "/api/projects/{team_id}/exports/{export_id}"),
            ("content", "/api/projects/{team_id}/exports/{export_id}/content"),
        ]
    )
    def test_teammate_blocked_from_other_users_non_session_recording_export(self, _name, url_template) -> None:
        export = ExportedAsset.objects.create(
            team=self.team,
            dashboard_id=self.dashboard.id,
            export_format="image/png",
            created_by=self.user,
            content=b"fakepng-bytes-for-content",
        )

        other_user = User.objects.create_and_join(self.organization, "other@posthog.com", "password")
        self.client.force_login(other_user)

        response = self.client.get(url_template.format(team_id=self.team.id, export_id=export.id))
        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)

    @parameterized.expand(
        [
            ("retrieve", "/api/projects/{team_id}/exports/{export_id}"),
            ("content", "/api/projects/{team_id}/exports/{export_id}/content"),
        ]
    )
    def test_teammate_can_access_session_recording_png_export_by_other_user(self, _name, url_template) -> None:
        from posthog.session_recordings.models.session_recording import SessionRecording

        owner = self.user
        teammate = User.objects.create_and_join(self.organization, "session-png-peer@posthog.com", "password")
        SessionRecording.objects.create(team=self.team, session_id="sess-png-shared")

        export = ExportedAsset.objects.create(
            team=self.team,
            export_format="image/png",
            export_context={"session_recording_id": "sess-png-shared"},
            created_by=owner,
            content=b"png-bytes",
        )

        self.client.force_login(teammate)
        response = self.client.get(url_template.format(team_id=self.team.id, export_id=export.id))
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        if "/content" in url_template:
            self.assertEqual(response.content, b"png-bytes")

    @parameterized.expand(
        [
            ("traversal", "../../2/recordings/other-session"),
            ("slash", "abc/def"),
            ("backslash", "abc\\def"),
            ("percent_encoded", "%2e%2e%2f2"),
            ("not_a_string", 12345),
            ("dot_segment", ".."),
            ("trailing_newline", "abc\n"),
        ]
    )
    def test_cannot_create_export_with_unsafe_session_recording_id(self, _name, session_recording_id) -> None:
        response = self.client.post(
            f"/api/projects/{self.team.id}/exports",
            {
                "export_format": "image/png",
                "export_context": {"session_recording_id": session_recording_id},
            },
        )
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertIn("session_recording_id", str(response.json()))

    @parameterized.expand(
        [
            ("retrieve", "/api/projects/{team_id}/exports/{export_id}"),
            ("content", "/api/projects/{team_id}/exports/{export_id}/content"),
        ]
    )
    def test_cannot_access_export_pairing_allowed_dashboard_with_denied_insight(self, _name, url_template) -> None:
        other_user = User.objects.create_and_join(self.organization, "rbac-pairing@posthog.com", "password")

        export = ExportedAsset.objects.create(
            team=self.team,
            dashboard_id=self.dashboard.id,
            insight_id=self.insight.id,
            export_format="image/png",
            created_by=other_user,
        )

        self.organization.available_product_features = [{"key": "access_control", "name": "Access control"}]
        self.organization.save()

        # The dashboard stays reachable, so only checking it would authorize the private insight.
        AccessControl.objects.create(
            resource="insight",
            resource_id=str(self.insight.id),
            team=self.team,
            access_level="none",
        )

        self.client.force_login(other_user)
        response = self.client.get(url_template.format(team_id=self.team.id, export_id=export.id))
        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)

    @parameterized.expand(
        [
            ("retrieve", "/api/projects/{team_id}/exports/{export_id}"),
            ("content", "/api/projects/{team_id}/exports/{export_id}/content"),
        ]
    )
    def test_cannot_access_export_pairing_allowed_dashboard_with_denied_recording(self, _name, url_template) -> None:
        from posthog.session_recordings.models.session_recording import SessionRecording

        other_user = User.objects.create_and_join(self.organization, "rbac-mixed@posthog.com", "password")
        recording = SessionRecording.objects.create(team=self.team, session_id="mixed-asset-recording")

        export = ExportedAsset.objects.create(
            team=self.team,
            dashboard_id=self.dashboard.id,
            export_format="image/png",
            export_context={"session_recording_id": recording.session_id},
            created_by=other_user,
        )

        self.organization.available_product_features = [{"key": "access_control", "name": "Access control"}]
        self.organization.save()

        AccessControl.objects.create(
            resource="session_recording",
            resource_id=str(recording.id),
            team=self.team,
            access_level="none",
        )

        self.client.force_login(other_user)
        response = self.client.get(url_template.format(team_id=self.team.id, export_id=export.id))
        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)

    def test_cannot_create_session_recording_export_without_recording_access(self) -> None:
        self.organization.available_product_features = [{"key": "access_control", "name": "Access control"}]
        self.organization.save()

        AccessControl.objects.create(
            resource="session_recording",
            team=self.team,
            access_level="none",
        )

        member = User.objects.create_and_join(self.organization, "rbac-no-replay@posthog.com", "password")
        self.client.force_login(member)

        response = self.client.post(
            f"/api/projects/{self.team.id}/exports",
            {
                "export_format": "image/png",
                "export_context": {"session_recording_id": "some-session-id"},
            },
        )
        self.assertEqual(response.status_code, status.HTTP_403_FORBIDDEN)

    @parameterized.expand(
        [
            ("retrieve", "/api/projects/{team_id}/exports/{export_id}"),
            ("content", "/api/projects/{team_id}/exports/{export_id}/content"),
        ]
    )
    def test_cannot_access_export_after_losing_resource_access(self, _name, url_template) -> None:
        other_user = User.objects.create_and_join(self.organization, "rbac-test@posthog.com", "password")

        export = ExportedAsset.objects.create(
            team=self.team,
            dashboard_id=self.dashboard.id,
            export_format="image/png",
            created_by=other_user,
        )

        self.organization.available_product_features = [{"key": "access_control", "name": "Access control"}]
        self.organization.save()

        AccessControl.objects.create(
            resource="dashboard",
            resource_id=str(self.dashboard.id),
            team=self.team,
            access_level="none",
        )

        self.client.force_login(other_user)
        response = self.client.get(url_template.format(team_id=self.team.id, export_id=export.id))
        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)

    @parameterized.expand(
        [
            ("retrieve", "/api/projects/{team_id}/exports/{export_id}"),
            ("content", "/api/projects/{team_id}/exports/{export_id}/content"),
        ]
    )
    def test_cannot_access_session_recording_export_after_losing_access(self, _name, url_template) -> None:
        from posthog.session_recordings.models.session_recording import SessionRecording

        other_user = User.objects.create_and_join(self.organization, "rbac-recording@posthog.com", "password")
        recording = SessionRecording.objects.create(team=self.team, session_id="test-session-123")

        export = ExportedAsset.objects.create(
            team=self.team,
            export_format="video/mp4",
            export_context={"session_recording_id": "test-session-123"},
            created_by=other_user,
        )

        self.organization.available_product_features = [{"key": "access_control", "name": "Access control"}]
        self.organization.save()

        AccessControl.objects.create(
            resource="session_recording",
            resource_id=str(recording.id),
            team=self.team,
            access_level="none",
        )

        self.client.force_login(other_user)
        response = self.client.get(url_template.format(team_id=self.team.id, export_id=export.id))
        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)

    @parameterized.expand(
        [
            ("retrieve", "/api/projects/{team_id}/exports/{export_id}"),
            ("content", "/api/projects/{team_id}/exports/{export_id}/content"),
        ]
    )
    def test_teammate_can_access_system_session_video_export(self, _name, url_template) -> None:
        from posthog.session_recordings.models.session_recording import SessionRecording

        owner = self.user
        teammate = User.objects.create_and_join(self.organization, "signal-session-viewer@posthog.com", "password")
        SessionRecording.objects.create(team=self.team, session_id="signal-sess-shared")

        export = ExportedAsset.objects.create(
            team=self.team,
            export_format="video/mp4",
            export_context={"session_recording_id": "signal-sess-shared"},
            created_by=owner,
            is_system=True,
            content=b"videobytes",
        )

        self.client.force_login(teammate)
        response = self.client.get(url_template.format(team_id=self.team.id, export_id=export.id))
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        if "/content" in url_template:
            self.assertEqual(response.content, b"videobytes")

    @parameterized.expand(
        [
            ("retrieve", "/api/projects/{team_id}/exports/{export_id}"),
            ("content", "/api/projects/{team_id}/exports/{export_id}/content"),
        ]
    )
    def test_teammate_blocked_from_system_video_export_when_no_session_access(self, _name, url_template) -> None:
        """Session recording RBAC still gates system (signals pipeline) video exports."""
        from posthog.session_recordings.models.session_recording import SessionRecording

        owner = self.user
        teammate = User.objects.create_and_join(self.organization, "signal-session-blocked@posthog.com", "password")
        recording = SessionRecording.objects.create(team=self.team, session_id="signal-sess-private")

        export = ExportedAsset.objects.create(
            team=self.team,
            export_format="video/mp4",
            export_context={"session_recording_id": "signal-sess-private"},
            created_by=owner,
            is_system=True,
            content=b"videobytes",
        )

        self.organization.available_product_features = [{"key": "access_control", "name": "Access control"}]
        self.organization.save()

        AccessControl.objects.create(
            resource="session_recording",
            resource_id=str(recording.id),
            team=self.team,
            access_level="none",
        )

        self.client.force_login(teammate)
        response = self.client.get(url_template.format(team_id=self.team.id, export_id=export.id))
        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)

    @parameterized.expand(
        [
            ("retrieve", "/api/projects/{team_id}/exports/{export_id}"),
            ("content", "/api/projects/{team_id}/exports/{export_id}/content"),
        ]
    )
    def test_cannot_access_session_video_export_when_session_recording_row_missing_and_resource_denied(
        self, _name, url_template
    ) -> None:
        """
        Without a SessionRecording row, object-level RBAC cannot run; resource-level session_recording
        access must still apply so exports are not fail-open for all project members.
        """
        from posthog.models.organization import OrganizationMembership

        owner = self.user
        teammate = User.objects.create_and_join(self.organization, "ghost-session-blocked@posthog.com", "password")
        membership = OrganizationMembership.objects.get(user=teammate, organization=self.organization)

        export = ExportedAsset.objects.create(
            team=self.team,
            export_format="video/mp4",
            export_context={"session_recording_id": "no-session-recording-row"},
            created_by=owner,
            is_system=True,
            content=b"videobytes",
        )

        self.organization.available_product_features = [{"key": "access_control", "name": "Access control"}]
        self.organization.save()

        AccessControl.objects.create(
            resource="session_recording",
            resource_id=None,
            team=self.team,
            access_level="none",
            organization_member=membership,
        )

        self.client.force_login(teammate)
        response = self.client.get(url_template.format(team_id=self.team.id, export_id=export.id))
        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)

    @parameterized.expand(
        [
            ("retrieve", "/api/projects/{team_id}/exports/{export_id}"),
            ("content", "/api/projects/{team_id}/exports/{export_id}/content"),
        ]
    )
    def test_creator_can_access_own_session_recording_export_when_row_missing_and_resource_denied(
        self, _name, url_template
    ) -> None:
        """
        The user who created a session recording export must always be able to retrieve it — retrieval
        cannot be stricter than creation. Otherwise the create call succeeds (firing an "Export complete!"
        toast) and the immediate content fetch 404s, rendering as a blank page. This is the mirror of the
        teammate case above: same denied resource default, but the creator is allowed through.
        """
        from posthog.models.organization import OrganizationMembership

        owner = self.user
        membership = OrganizationMembership.objects.get(user=owner, organization=self.organization)

        export = ExportedAsset.objects.create(
            team=self.team,
            export_format="image/png",
            export_context={"session_recording_id": "no-session-recording-row"},
            created_by=owner,
            content=b"png-bytes",
        )

        self.organization.available_product_features = [{"key": "access_control", "name": "Access control"}]
        self.organization.save()

        AccessControl.objects.create(
            resource="session_recording",
            resource_id=None,
            team=self.team,
            access_level="none",
            organization_member=membership,
        )

        response = self.client.get(url_template.format(team_id=self.team.id, export_id=export.id))
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        if "/content" in url_template:
            self.assertEqual(response.content, b"png-bytes")

    def test_list_exports_with_session_recording_only_shows_own_matching_exports(self) -> None:
        from posthog.session_recordings.models.session_recording import SessionRecording

        owner = self.user
        teammate = User.objects.create_and_join(self.organization, "signal-session-lister@posthog.com", "password")
        SessionRecording.objects.create(team=self.team, session_id="lookup-sess-filter")

        export = ExportedAsset.objects.create(
            team=self.team,
            export_format="video/mp4",
            export_context={"session_recording_id": "lookup-sess-filter"},
            created_by=owner,
            is_system=True,
            content=b"x",
        )

        self.client.force_login(teammate)
        url = f"/api/projects/{self.team.id}/exports/?session_recording_id=lookup-sess-filter&export_format=video/mp4"
        response = self.client.get(url)
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        ids = {r["id"] for r in response.json().get("results", [])}
        self.assertNotIn(export.id, ids)

    def test_list_exports_without_session_filter_hides_others_system_exports(self) -> None:
        owner = self.user
        teammate = User.objects.create_and_join(self.organization, "solo-exports@posthog.com", "password")
        system_export = ExportedAsset.objects.create(
            team=self.team,
            export_format="video/mp4",
            export_context={"session_recording_id": "nosy-sess"},
            created_by=owner,
            is_system=True,
        )

        self.client.force_login(teammate)
        response = self.client.get(f"/api/projects/{self.team.id}/exports/")
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        ids = {r["id"] for r in response.json().get("results", [])}
        self.assertNotIn(system_export.id, ids)

    @parameterized.expand(
        [
            ("image/png", 2, "png_export"),  # PNG format with 2 expected results
            ("text/csv", 1, "csv_export"),  # CSV format with 1 expected result
            ("image/jpeg", 3, None),  # Unsupported format returns all (3)
            (None, 3, None),  # No filter returns all (3)
        ]
    )
    def test_can_filter_exports_by_format(self, export_format, expected_count, expected_export_var):
        png_export = ExportedAsset.objects.create(
            team=self.team, dashboard_id=self.dashboard.id, export_format="image/png", created_by=self.user
        )
        csv_export = ExportedAsset.objects.create(
            team=self.team, insight_id=self.insight.id, export_format="text/csv", created_by=self.user
        )

        url = f"/api/projects/{self.team.id}/exports"
        if export_format:
            url += f"?export_format={export_format}"

        response = self.client.get(url)
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        results = response.json()["results"]

        assert len(results) == expected_count

        if expected_export_var == "png_export":
            # Should return PNG exports only (including the one from setUpTestData)
            png_export_ids = {png_export.id, self.exported_asset.id}
            returned_ids = {result["id"] for result in results}
            assert returned_ids == png_export_ids
            for result in results:
                assert result["export_format"] == "image/png"
        elif expected_export_var == "csv_export":
            # Should return CSV export only
            assert results[0]["id"] == csv_export.id
            assert results[0]["export_format"] == "text/csv"

    @parameterized.expand(
        [
            ("image/png", timedelta(days=180)),
            ("text/csv", timedelta(days=7)),
            ("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", timedelta(days=7)),
            ("video/mp4", timedelta(days=365)),
            ("video/webm", timedelta(days=365)),
            ("image/gif", timedelta(days=365)),
            ("application/pdf", timedelta(days=180)),
        ]
    )
    @patch("products.exports.backend.api.exports.async_to_sync")
    @patch("products.exports.backend.api.exports.async_connect")
    def test_export_expiry_varies_by_format(
        self, export_format, expected_delta, mock_async_connect, mock_async_to_sync
    ) -> None:
        is_video_format = export_format in ("video/mp4", "video/webm", "image/gif")

        if is_video_format:
            payload = {
                "export_format": export_format,
                "export_context": {
                    "session_recording_id": "test_session_123",
                    "timestamp": 100,
                    "duration": 5,
                },
            }
        else:
            payload = {"export_format": export_format, "dashboard": self.dashboard.id}

        response = self.client.post(f"/api/projects/{self.team.id}/exports", payload)
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        data = response.json()

        expected_expiry = (
            (now() + expected_delta)
            .replace(hour=0, minute=0, second=0, microsecond=0)
            .isoformat()
            .replace("+00:00", "Z")
        )

        self.assertEqual(data["expires_after"], expected_expiry)

    @parameterized.expand(["video/mp4", "video/webm", "image/gif"])
    @patch("products.exports.backend.api.exports.async_connect", new_callable=AsyncMock)
    def test_video_export_is_fire_and_forget(self, export_format, mock_async_connect) -> None:
        mock_client = AsyncMock()
        mock_async_connect.return_value = mock_client

        response = self.client.post(
            f"/api/projects/{self.team.id}/exports",
            {
                "export_format": export_format,
                "export_context": {"session_recording_id": "session_abc"},
            },
        )

        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertFalse(response.json()["has_content"])
        mock_client.start_workflow.assert_awaited_once()
        mock_client.execute_workflow.assert_not_awaited()

    @patch("products.exports.backend.api.exports.async_to_sync")
    @patch("products.exports.backend.api.exports.async_connect")
    def test_video_export_monthly_limit(self, mock_async_connect, mock_async_to_sync) -> None:
        """Test that video exports are limited to 10 per calendar month"""
        # Create 9 video exports this month (we're at the limit - 1)
        for i in range(9):
            ExportedAsset.objects.create(
                team=self.team,
                export_format="video/mp4",
                export_context={"session_recording_id": f"session_{i}"},
                created_by=self.user,
            )

        # The 10th video export should succeed
        response = self.client.post(
            f"/api/projects/{self.team.id}/exports",
            {
                "export_format": "video/mp4",
                "export_context": {
                    "session_recording_id": "session_10",
                },
            },
        )
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)

        # The 11th video export should fail with limit exceeded error
        response = self.client.post(
            f"/api/projects/{self.team.id}/exports",
            {
                "export_format": "video/mp4",
                "export_context": {
                    "session_recording_id": "session_11",
                },
            },
        )
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        error_data = response.json()
        self.assertEqual(error_data["type"], "validation_error")
        self.assertEqual(error_data["attr"], "export_limit_exceeded")
        self.assertIn("reached the limit of 10 full video exports this month", error_data["detail"])

    @patch("products.exports.backend.api.exports.async_to_sync")
    @patch("products.exports.backend.api.exports.async_connect")
    def test_video_export_limit_applies_to_all_video_formats(self, mock_async_connect, mock_async_to_sync) -> None:
        """Test that the limit applies to both MP4 and WebM session recording exports"""
        # Create 5 MP4 and 5 WebM exports this month (at the limit)
        for i in range(5):
            ExportedAsset.objects.create(
                team=self.team,
                export_format="video/mp4",
                export_context={"session_recording_id": f"session_mp4_{i}"},
                created_by=self.user,
            )
            ExportedAsset.objects.create(
                team=self.team,
                export_format="video/webm",
                export_context={"session_recording_id": f"session_webm_{i}"},
                created_by=self.user,
            )

        # MP4 video export should fail
        response = self.client.post(
            f"/api/projects/{self.team.id}/exports",
            {
                "export_format": "video/mp4",
                "export_context": {
                    "session_recording_id": "session_over_limit",
                },
            },
        )
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

        # WebM video export should also fail (shared limit)
        response = self.client.post(
            f"/api/projects/{self.team.id}/exports",
            {
                "export_format": "video/webm",
                "export_context": {
                    "session_recording_id": "session_webm_over_limit",
                },
            },
        )
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

    @patch("products.exports.backend.api.exports.async_to_sync")
    @patch("products.exports.backend.api.exports.async_connect")
    @freeze_time("2024-01-15T12:00:00Z")
    def test_video_export_limit_resets_monthly(self, mock_async_connect, mock_async_to_sync) -> None:
        """Test that the video export limit resets at the beginning of each month"""

        # Create 10 video exports in January (at the limit)
        for i in range(10):
            ExportedAsset.objects.create(
                team=self.team,
                export_format="video/mp4",
                export_context={"session_recording_id": f"session_jan_{i}"},
                created_by=self.user,
            )

        # Should fail in January
        response = self.client.post(
            f"/api/projects/{self.team.id}/exports",
            {
                "export_format": "video/mp4",
                "export_context": {
                    "session_recording_id": "session_jan_fail",
                },
            },
        )
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

        # Move to February 1st
        with freeze_time("2024-02-01T12:00:00Z"):
            # Should succeed in February (limit reset)
            response = self.client.post(
                f"/api/projects/{self.team.id}/exports",
                {
                    "export_format": "video/mp4",
                    "export_context": {
                        "session_recording_id": "session_feb_success",
                    },
                },
            )
            self.assertEqual(response.status_code, status.HTTP_201_CREATED)

    @parameterized.expand(
        [
            # name, available_product_features, expected_limit
            ("free", [], 10),
            (
                "paid",
                [{"key": "recordings_file_export", "name": "Recordings file export"}],
                15,
            ),
            (
                "enterprise_via_role_based_access",
                [
                    {"key": "recordings_file_export", "name": "Recordings file export"},
                    {"key": "role_based_access", "name": "Role based access"},
                ],
                25,
            ),
            (
                "enterprise_via_saml",
                [
                    {"key": "recordings_file_export", "name": "Recordings file export"},
                    {"key": "saml", "name": "SAML"},
                ],
                25,
            ),
            (
                "enterprise_via_saml_only",
                [{"key": "saml", "name": "SAML"}],
                25,
            ),
        ]
    )
    @patch("products.exports.backend.api.exports.async_to_sync")
    @patch("products.exports.backend.api.exports.async_connect")
    def test_video_export_limit_varies_by_plan_tier(
        self,
        _name: str,
        available_product_features: list[dict],
        expected_limit: int,
        mock_async_connect,
        mock_async_to_sync,
    ) -> None:
        """The monthly video export limit scales with the organization's plan tier."""
        self.organization.available_product_features = available_product_features
        self.organization.save()

        for i in range(expected_limit):
            ExportedAsset.objects.create(
                team=self.team,
                export_format="video/mp4",
                export_context={"session_recording_id": f"session_{i}"},
                created_by=self.user,
            )

        response = self.client.post(
            f"/api/projects/{self.team.id}/exports",
            {
                "export_format": "video/mp4",
                "export_context": {
                    "session_recording_id": "session_over_limit",
                },
            },
        )
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        error_data = response.json()
        self.assertEqual(error_data["attr"], "export_limit_exceeded")
        self.assertIn(f"reached the limit of {expected_limit} full video exports this month", error_data["detail"])

    @parameterized.expand(
        [
            # (name, available_product_features, override, effective_limit)
            # Override bumps above tier → effective limit is the override.
            (
                "paid_override_above_tier_wins",
                [{"key": "recordings_file_export", "name": "Recordings file export"}],
                20,
                20,
            ),
            # Override below tier default is a no-op — tier default wins, so legacy
            # flat-10 overrides can't silently downgrade enterprise orgs post-deploy.
            (
                "enterprise_override_below_tier_is_floored",
                [
                    {"key": "recordings_file_export", "name": "Recordings file export"},
                    {"key": "saml", "name": "SAML"},
                ],
                10,
                25,
            ),
            # Free tier with an override-bump also works.
            ("free_override_above_tier_wins", [], 30, 30),
        ]
    )
    @patch("products.exports.backend.api.exports.async_to_sync")
    @patch("products.exports.backend.api.exports.async_connect")
    def test_video_export_extra_settings_override_acts_as_floor_above_plan_tier(
        self,
        _name: str,
        available_product_features: list[dict],
        override: int,
        effective_limit: int,
        mock_async_connect,
        mock_async_to_sync,
    ) -> None:
        """The per-team override bumps the limit *above* the tier default but never below it.

        Preserves the "support bump" purpose without silently downgrading orgs whose tier
        default is now higher than a legacy override set during the flat-10 era.
        """
        self.organization.available_product_features = available_product_features
        self.organization.save()
        self.team.extra_settings = {"full_video_exports_limit": override}
        self.team.save()

        for i in range(effective_limit):
            ExportedAsset.objects.create(
                team=self.team,
                export_format="video/mp4",
                export_context={"session_recording_id": f"session_{i}"},
                created_by=self.user,
            )

        response = self.client.post(
            f"/api/projects/{self.team.id}/exports",
            {
                "export_format": "video/mp4",
                "export_context": {
                    "session_recording_id": "session_over_limit",
                },
            },
        )
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertIn(
            f"reached the limit of {effective_limit} full video exports this month", response.json()["detail"]
        )

    @parameterized.expand(
        [
            # (name, is_system, should_succeed)
            ("system_assets_dont_count", True, True),
            ("user_assets_count", False, False),
        ]
    )
    @patch("products.exports.backend.api.exports.async_to_sync")
    @patch("products.exports.backend.api.exports.async_connect")
    def test_video_export_limit_excludes_system_assets(
        self,
        _name: str,
        is_system: bool,
        should_succeed: bool,
        mock_async_connect,
        mock_async_to_sync,
    ) -> None:
        for i in range(50):
            ExportedAsset.objects.create(
                team=self.team,
                export_format="video/webm",
                export_context={"session_recording_id": f"session_{i}"},
                created_by=self.user,
                is_system=is_system,
            )

        response = self.client.post(
            f"/api/projects/{self.team.id}/exports",
            {
                "export_format": "video/mp4",
                "export_context": {"session_recording_id": "new_user_export"},
            },
        )

        if should_succeed:
            self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        else:
            self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
            self.assertEqual(response.json()["attr"], "export_limit_exceeded")

    @patch("products.exports.backend.tasks.image_exporter.export_image")
    def test_export_records_failure_on_query_error(self, mock_export_direct) -> None:
        """Test that export_asset records failure info on the asset when a QueryError occurs.

        The actual export now runs inside a Temporal workflow (tested in
        test_export_workflow.py). This test verifies the underlying exporter
        still records structured failure metadata on the ExportedAsset model.
        """
        from posthog.hogql.errors import QueryError

        mock_export_direct.side_effect = QueryError("Unknown table 'nonexistent_table'")

        asset = ExportedAsset.objects.create(
            team=self.team,
            export_format="image/png",
            insight=self.insight,
            created_by=self.user,
        )
        exporter.export_asset(asset.id)

        asset.refresh_from_db()
        self.assertEqual(asset.exception, "Unknown table 'nonexistent_table'")
        self.assertEqual(asset.exception_type, "QueryError")
        self.assertEqual(asset.failure_type, "user")

    @patch("products.exports.backend.api.exports.async_connect")
    def test_workflow_failure_returns_201_with_failed_asset(self, mock_async_connect) -> None:
        mock_client = AsyncMock()
        mock_client.execute_workflow.side_effect = Exception("workflow failed")
        mock_async_connect.return_value = mock_client

        response = self.client.post(
            f"/api/projects/{self.team.id}/exports",
            {"export_format": "text/csv", "insight": self.insight.id},
        )

        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertFalse(response.json()["has_content"])


class TestExportHeatmapSSRFValidation(APIBaseTest):
    @parameterized.expand(
        [
            ("metadata_endpoint", "http://169.254.169.254/latest/meta-data/"),
            ("localhost", "http://localhost/admin"),
            ("loopback_ip", "http://127.0.0.1:8080/secret"),
            ("private_ip_10", "http://10.0.0.1/internal"),
            ("private_ip_192", "http://192.168.1.1/internal"),
            ("internal_domain", "http://service.cluster.local/api"),
            ("file_scheme", "file:///etc/passwd"),
            ("protocol_relative", "//evil.com/steal-data"),
            ("relative_api_path", "/api/environments/1/heatmap_screenshots/42/content/?width=1400"),
        ]
    )
    def test_rejects_ssrf_heatmap_url(self, _name: str, url: str) -> None:
        response = self.client.post(
            f"/api/projects/{self.team.id}/exports",
            {
                "export_format": "image/png",
                "export_context": {
                    "heatmap_url": url,
                },
            },
        )
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

    @parameterized.expand(
        [
            ("external_url", "https://example.com/page"),
            (
                "screenshot_api_url",
                "https://us.posthog.com/api/environments/1/heatmap_screenshots/42/content/?width=1400",
            ),
        ]
    )
    def test_accepts_valid_heatmap_url(self, _name: str, url: str) -> None:
        with (
            patch("posthog.security.url_validation.resolve_host_ips") as mock_resolve,
            patch("products.exports.backend.api.exports.ExportedAssetSerializer._start_export_workflow"),
        ):
            mock_resolve.return_value = {ipaddress.ip_address("93.184.216.34")}
            response = self.client.post(
                f"/api/projects/{self.team.id}/exports",
                {
                    "export_format": "image/png",
                    "export_context": {"heatmap_url": url},
                },
            )
            self.assertEqual(response.status_code, status.HTTP_201_CREATED)

    @parameterized.expand(
        [
            ("http", "http://app.example.com:80", "http://app.example.com/heatmap"),
            ("https", "https://app.example.com:443", "https://app.example.com/heatmap"),
        ]
    )
    def test_accepts_screenshot_url_with_default_site_port(self, _name: str, site_url: str, heatmap_url: str) -> None:
        with (
            self.settings(SITE_URL=site_url),
            patch("posthog.security.url_validation.resolve_host_ips") as mock_resolve,
            patch("products.exports.backend.api.exports.ExportedAssetSerializer._start_export_workflow"),
        ):
            mock_resolve.return_value = {ipaddress.ip_address("93.184.216.34")}
            response = self.client.post(
                f"/api/projects/{self.team.id}/exports",
                {
                    "export_format": "image/png",
                    "export_context": {"heatmap_url": heatmap_url, "heatmap_type": "screenshot"},
                },
            )

        self.assertEqual(response.status_code, status.HTTP_201_CREATED)


class TestExportMixin(APIBaseTest):
    def _get_export_output(self, path: str) -> list[str]:
        """
        Use this function to test the CSV output of exports in other tests
        """
        path = "/" + path.lstrip("/")
        with self.settings(SITE_URL="http://testserver", OBJECT_STORAGE_ENABLED=False):
            with patch("products.exports.backend.tasks.csv_exporter.requests.request") as patched_request:

                def requests_side_effect(*args, **kwargs):
                    response = self.client.get(kwargs["url"], kwargs["json"], **kwargs["headers"])

                    def raise_for_status():
                        if 400 <= response.status_code < 600:
                            raise requests.exceptions.HTTPError(response=response)  # type: ignore[arg-type]

                    response.raise_for_status = raise_for_status  # type: ignore[attr-defined]
                    return response

                patched_request.side_effect = requests_side_effect

                asset = ExportedAsset.objects.create(
                    team=self.team,
                    created_by=self.user,
                    export_context={"path": path},
                    export_format=ExportedAsset.ExportFormat.CSV,
                    source_authentication=ExportedAsset.SourceAuthentication.SESSION,
                )
                exporter.export_asset(asset.id)

                download_response = self.client.get(
                    f"/api/projects/{self.team.id}/exports/{asset.id}/content?download=true"
                )
                return [str(x) for x in download_response.content.splitlines()]


class TestExportAssetCounters(APIBaseTest):
    def setUp(self) -> None:
        super().setUp()
        self.registry = CollectorRegistry()
        self.success_counter = Counter("test_success", "Test", labelnames=["type"], registry=self.registry)
        self.failed_counter = Counter(
            "test_failed", "Test", labelnames=["type", "failure_type"], registry=self.registry
        )
        self.asset = ExportedAsset.objects.create(
            team=self.team,
            export_format=ExportedAsset.ExportFormat.PNG,
        )

    @parameterized.expand(
        [
            # (error, failure_type, expected_success, expected_failure, expects_exception)
            # Success case
            (None, FAILURE_TYPE_USER, 1.0, 0.0, False),
            # User error: recorded but not raised
            (QueryError("Invalid query"), FAILURE_TYPE_USER, 0.0, 1.0, False),
            # System error: retried by tenacity, then recorded (not raised, swallowed by export_asset)
            (ClickHouseAtCapacity(), FAILURE_TYPE_SYSTEM, 0.0, 1.0, False),
        ],
        name_func=lambda func, num, params: f"{func.__name__}_{['success', 'user_error', 'system_error'][int(num)]}",
    )
    def test_export_counter_behavior(
        self,
        error: Exception | None,
        failure_type: str,
        expected_success: float,
        expected_failure: float,
        expects_exception: bool,
    ) -> None:
        exception_context = pytest.raises(type(error)) if expects_exception and error else nullcontext()

        with (
            patch("products.exports.backend.tasks.image_exporter.export_image", side_effect=error),
            patch.object(exporter, "EXPORT_SUCCEEDED_COUNTER", self.success_counter),
            patch.object(exporter, "EXPORT_FAILED_COUNTER", self.failed_counter),
            patch("time.sleep"),  # Avoid real tenacity backoff waits
            exception_context,
        ):
            exporter.export_asset(self.asset.id)

        assert get_counter_value(self.success_counter, {"type": ExportedAsset.ExportFormat.PNG}) == expected_success
        assert (
            get_counter_value(
                self.failed_counter, {"type": ExportedAsset.ExportFormat.PNG, "failure_type": failure_type}
            )
            == expected_failure
        )


class TestExportsResourceAccessControl(APIBaseTest):
    """Resource- and object-level access control for the exports feature."""

    def setUp(self) -> None:
        super().setUp()
        self.organization.available_product_features = [{"key": "access_control", "name": "Access control"}]
        self.organization.save()
        self.member = User.objects.create_and_join(self.organization, "export-member@posthog.com", "password")
        self.dashboard = Dashboard.objects.create(team=self.team, name="example dashboard", created_by=self.user)
        self.client.force_login(self.member)

    def _set_export_resource_level(self, access_level: str) -> None:
        AccessControl.objects.create(resource="export", team=self.team, access_level=access_level)

    def test_member_with_none_resource_access_cannot_list_exports(self) -> None:
        self._set_export_resource_level("none")
        response = self.client.get(f"/api/projects/{self.team.id}/exports")
        self.assertEqual(response.status_code, status.HTTP_403_FORBIDDEN)

    def test_member_with_viewer_resource_access_can_list_but_not_create(self) -> None:
        self._set_export_resource_level("viewer")

        list_response = self.client.get(f"/api/projects/{self.team.id}/exports")
        self.assertEqual(list_response.status_code, status.HTTP_200_OK)

        create_response = self.client.post(
            f"/api/projects/{self.team.id}/exports",
            {"export_format": "image/png", "dashboard": self.dashboard.id},
        )
        self.assertEqual(create_response.status_code, status.HTTP_403_FORBIDDEN)

    @patch("products.exports.backend.api.exports.ExportedAssetSerializer._start_export_workflow")
    def test_member_with_editor_resource_access_can_create(self, _mock_workflow) -> None:
        self._set_export_resource_level("editor")
        response = self.client.post(
            f"/api/projects/{self.team.id}/exports",
            {"export_format": "image/png", "dashboard": self.dashboard.id},
        )
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)

    def test_creator_sees_highest_user_access_level(self) -> None:
        self._set_export_resource_level("editor")
        asset = ExportedAsset.objects.create(
            team=self.team, dashboard_id=self.dashboard.id, export_format="image/png", created_by=self.member
        )
        response = self.client.get(f"/api/projects/{self.team.id}/exports/{asset.id}")
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        # The member created this export, so they have the highest level for it.
        self.assertEqual(response.json()["user_access_level"], "manager")

    def test_non_creator_sees_resource_level_user_access_level(self) -> None:
        # Session-recording exports are retrievable by non-creators, so this exercises the
        # non-creator branch of the serializer field (which resolves to the resource level).
        from posthog.session_recordings.models.session_recording import SessionRecording

        SessionRecording.objects.create(team=self.team, session_id="export-rbac-session")
        asset = ExportedAsset.objects.create(
            team=self.team,
            export_format="video/mp4",
            export_context={"session_recording_id": "export-rbac-session"},
            created_by=self.user,
        )
        self._set_export_resource_level("viewer")
        response = self.client.get(f"/api/projects/{self.team.id}/exports/{asset.id}")
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.json()["user_access_level"], "viewer")

    def test_access_controls_endpoint_route_exists(self) -> None:
        asset = ExportedAsset.objects.create(
            team=self.team, dashboard_id=self.dashboard.id, export_format="image/png", created_by=self.user
        )
        self.client.force_login(self.user)
        response = self.client.get(f"/api/projects/{self.team.id}/exports/{asset.id}/access_controls")
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_non_manager_member_cannot_modify_object_access_controls(self) -> None:
        # A session-recording export the member can retrieve (non-creator path), with the member
        # granted editor (so the request passes resource-level write checks) but not manager.
        from posthog.session_recordings.models.session_recording import SessionRecording

        SessionRecording.objects.create(team=self.team, session_id="export-acl-session")
        asset = ExportedAsset.objects.create(
            team=self.team,
            export_format="video/mp4",
            export_context={"session_recording_id": "export-acl-session"},
            created_by=self.user,
        )
        self._set_export_resource_level("editor")
        response = self.client.put(
            f"/api/projects/{self.team.id}/exports/{asset.id}/access_controls",
            {"access_level": "viewer"},
        )
        # Modifying an object's access controls requires manager access to that object.
        self.assertEqual(response.status_code, status.HTTP_403_FORBIDDEN)
