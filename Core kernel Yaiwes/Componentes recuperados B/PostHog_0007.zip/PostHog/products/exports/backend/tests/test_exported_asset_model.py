from datetime import UTC, datetime, timedelta
from tempfile import NamedTemporaryFile

from freezegun import freeze_time
from posthog.test.base import APIBaseTest
from unittest.mock import patch

from parameterized import parameterized

from posthog.storage.object_storage import ObjectStorageError

from products.exports.backend.models.exported_asset import (
    SEVEN_DAYS,
    SIX_MONTHS,
    TWELVE_MONTHS,
    ExportedAsset,
    get_content_response,
    save_content_from_file,
)


class TestExportedAssetModel(APIBaseTest):
    def test_large_content_preserves_object_storage_failure(self) -> None:
        asset = ExportedAsset.objects.create(
            team=self.team,
            created_by=self.user,
            export_format=ExportedAsset.ExportFormat.JSONL,
        )
        with NamedTemporaryFile() as content_file:
            content_file.write(b"large")
            content_file.flush()
            storage_error = ObjectStorageError("storage unavailable")
            with (
                self.settings(OBJECT_STORAGE_ENABLED=True, OBJECT_STORAGE_EXPORTS_FOLDER="Test-Exports"),
                patch(
                    "products.exports.backend.models.exported_asset.object_storage.write_from_file",
                    side_effect=storage_error,
                ),
                self.assertRaises(ObjectStorageError) as error,
            ):
                save_content_from_file(asset, content_file.name, max_database_bytes=1)

        self.assertIs(error.exception, storage_error)

    def test_exported_asset_inside_ttl_is_visible_to_both_managers(self) -> None:
        asset = ExportedAsset.objects.create(
            team=self.team,
            created_by=self.user,
            expires_after=datetime.now() + timedelta(seconds=100),
        )

        assert list(ExportedAsset.objects.filter(id=asset.id)) == [asset]
        assert list(ExportedAsset.objects_including_ttl_deleted.filter(id=asset.id)) == [asset]

    def test_exported_asset_without_ttl_is_visible_to_both_managers(self) -> None:
        asset = ExportedAsset.objects.create(
            team=self.team,
            created_by=self.user,
        )

        assert list(ExportedAsset.objects.filter(id=asset.id)) == [asset]
        assert list(ExportedAsset.objects_including_ttl_deleted.filter(id=asset.id)) == [asset]

    def test_exported_asset_outside_ttl_is_not_visible_to_both_managers(self) -> None:
        with freeze_time("2021-01-01T12:00:00Z") as frozen_time:
            asset = ExportedAsset.objects.create(
                team=self.team,
                created_by=self.user,
                expires_after=datetime.now() + timedelta(seconds=100),
            )

            frozen_time.tick(delta=timedelta(seconds=101))

            assert list(ExportedAsset.objects.filter(id=asset.id)) == []
            assert list(ExportedAsset.objects_including_ttl_deleted.filter(id=asset.id)) == [asset]

    def test_delete_expired_assets(self) -> None:
        assert ExportedAsset.objects.count() == 0

        ExportedAsset.objects.create(
            team=self.team,
            created_by=self.user,
            # expires in the past, should be deleted
            expires_after=datetime.now() - timedelta(days=1),
        )
        asset_that_is_not_expired = ExportedAsset.objects.create(
            team=self.team,
            created_by=self.user,
            # expires in the future should not be deleted
            expires_after=datetime.now() + timedelta(days=1),
        )

        asset_that_has_no_expiry = ExportedAsset.objects.create(
            team=self.team,
            created_by=self.user,
        )

        assert ExportedAsset.objects.count() == 2
        assert ExportedAsset.objects_including_ttl_deleted.count() == 3

        ExportedAsset.delete_expired_assets()

        assert list(ExportedAsset.objects.all()) == [
            asset_that_is_not_expired,
            asset_that_has_no_expiry,
        ]
        assert list(ExportedAsset.objects_including_ttl_deleted.all()) == [
            asset_that_is_not_expired,
            asset_that_has_no_expiry,
        ]


class TestExportedAssetExpiresAfter(APIBaseTest):
    @parameterized.expand(
        [
            (ExportedAsset.ExportFormat.PNG, SIX_MONTHS),
            (ExportedAsset.ExportFormat.PDF, SIX_MONTHS),
            (ExportedAsset.ExportFormat.CSV, SEVEN_DAYS),
            (ExportedAsset.ExportFormat.XLSX, SEVEN_DAYS),
            (ExportedAsset.ExportFormat.MP4, TWELVE_MONTHS),
            (ExportedAsset.ExportFormat.WEBM, TWELVE_MONTHS),
            (ExportedAsset.ExportFormat.GIF, TWELVE_MONTHS),
            (ExportedAsset.ExportFormat.JSON, SIX_MONTHS),
            (ExportedAsset.ExportFormat.JSONL, SEVEN_DAYS),
        ]
    )
    @freeze_time("2024-06-15T10:30:00Z")
    def test_auto_sets_expires_after_based_on_format(self, export_format: str, expected_delta: timedelta) -> None:
        asset = ExportedAsset.objects.create(
            team=self.team,
            export_format=export_format,
        )

        expected_expiry = (datetime(2024, 6, 15, tzinfo=UTC) + expected_delta).replace(
            hour=0, minute=0, second=0, microsecond=0
        )
        assert asset.expires_after == expected_expiry

    @freeze_time("2024-06-15T10:30:00Z")
    def test_respects_explicit_expires_after(self) -> None:
        custom_expiry = datetime(2025, 1, 1, 0, 0, 0, tzinfo=UTC)
        asset = ExportedAsset.objects.create(
            team=self.team,
            export_format=ExportedAsset.ExportFormat.PNG,
            expires_after=custom_expiry,
        )

        assert asset.expires_after == custom_expiry

    @freeze_time("2024-06-15T10:30:00Z")
    def test_partial_save_does_not_overwrite_existing_expires_after(self) -> None:
        custom_expiry = datetime(2025, 12, 22, 0, 0, 0, tzinfo=UTC)
        asset = ExportedAsset.objects.create(
            team=self.team,
            export_format=ExportedAsset.ExportFormat.PNG,
            expires_after=custom_expiry,
        )

        asset.exception = "some error"
        asset.save(update_fields=["exception"])

        asset.refresh_from_db()
        assert asset.expires_after == custom_expiry

    @freeze_time("2024-06-15T10:30:00Z")
    def test_explicitly_updating_expires_after_field(self) -> None:
        custom_expiry = datetime(2025, 1, 1, 0, 0, 0, tzinfo=UTC)
        asset = ExportedAsset.objects.create(
            team=self.team,
            export_format=ExportedAsset.ExportFormat.PNG,
            expires_after=custom_expiry,
        )
        assert asset.expires_after == custom_expiry

        new_expiry = datetime(2025, 12, 22, 0, 0, 0, tzinfo=UTC)
        asset.expires_after = new_expiry
        asset.save(update_fields=["expires_after"])
        asset.refresh_from_db()
        assert asset.expires_after == new_expiry


class TestExportedAssetFilename(APIBaseTest):
    @freeze_time("2024-06-15T10:30:00Z")
    def test_filename_includes_timestamp(self) -> None:
        asset = ExportedAsset.objects.create(
            team=self.team,
            export_format=ExportedAsset.ExportFormat.CSV,
        )
        assert asset.filename == "export-2024-06-15-103000.csv"

    @freeze_time("2024-06-15T10:30:00Z")
    def test_filename_uses_custom_name_with_timestamp(self) -> None:
        asset = ExportedAsset.objects.create(
            team=self.team,
            export_format=ExportedAsset.ExportFormat.CSV,
            export_context={"filename": "My Cohort Name"},
        )
        assert asset.filename == "my-cohort-name-2024-06-15-103000.csv"

    @freeze_time("2024-06-15T10:30:00Z")
    def test_filename_slugifies_special_characters(self) -> None:
        asset = ExportedAsset.objects.create(
            team=self.team,
            export_format=ExportedAsset.ExportFormat.CSV,
            export_context={"filename": "Power Users @ 50% Rollout"},
        )
        assert asset.filename == "power-users-50-rollout-2024-06-15-103000.csv"

    @parameterized.expand(
        [
            (ExportedAsset.ExportFormat.XLSX, "xlsx"),
            (ExportedAsset.ExportFormat.JSONL, "jsonl"),
        ]
    )
    @freeze_time("2024-06-15T10:30:00Z")
    def test_tabular_format_extension(self, export_format: str, expected_extension: str) -> None:
        asset = ExportedAsset.objects.create(
            team=self.team,
            export_format=export_format,
            export_context={"filename": "cohort-test"},
        )
        assert asset.filename == f"cohort-test-2024-06-15-103000.{expected_extension}"


class TestDirectContentResponse(APIBaseTest):
    def test_serves_empty_content(self) -> None:
        asset = ExportedAsset.objects.create(
            team=self.team,
            export_format=ExportedAsset.ExportFormat.JSONL,
            content=b"",
        )

        response = get_content_response(asset)

        assert response.status_code == 200
        assert response.content == b""

    @parameterized.expand(
        [
            ("bounded_png_serves_bytes", ExportedAsset.ExportFormat.PNG, 200),
            ("unbounded_video_redirects", ExportedAsset.ExportFormat.MP4, 302),
        ]
    )
    def test_direct_mode_only_buffers_bounded_formats(
        self, _name: str, export_format: str, expected_status: int
    ) -> None:
        asset = ExportedAsset.objects.create(
            team=self.team,
            export_format=export_format,
            content=b"bytes" if expected_status == 200 else None,
            content_location="exports/some/key" if expected_status == 302 else None,
        )
        with patch(
            "products.exports.backend.models.exported_asset.object_storage.get_presigned_url",
            return_value="https://storage.example.com/presigned",
        ):
            response = get_content_response(asset, direct=True)
        assert response.status_code == expected_status
