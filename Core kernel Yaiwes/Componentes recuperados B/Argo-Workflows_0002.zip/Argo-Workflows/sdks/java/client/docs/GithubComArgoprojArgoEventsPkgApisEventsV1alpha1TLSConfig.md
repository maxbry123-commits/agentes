

# GithubComArgoprojArgoEventsPkgApisEventsV1alpha1TLSConfig

TLSConfig refers to TLS configuration for a client.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**caCertSecret** | [**io.kubernetes.client.openapi.models.V1SecretKeySelector**](io.kubernetes.client.openapi.models.V1SecretKeySelector.md) |  |  [optional]
**clientCertSecret** | [**io.kubernetes.client.openapi.models.V1SecretKeySelector**](io.kubernetes.client.openapi.models.V1SecretKeySelector.md) |  |  [optional]
**clientKeySecret** | [**io.kubernetes.client.openapi.models.V1SecretKeySelector**](io.kubernetes.client.openapi.models.V1SecretKeySelector.md) |  |  [optional]
**enabled** | **Boolean** |  |  [optional]
**insecureSkipVerify** | **Boolean** |  |  [optional]



