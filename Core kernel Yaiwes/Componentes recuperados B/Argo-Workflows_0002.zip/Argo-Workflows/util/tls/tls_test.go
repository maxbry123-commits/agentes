package tls

import (
	cryptotls "crypto/tls"
	"crypto/x509"
	"os"
	"path/filepath"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestGenerate(t *testing.T) {
	t.Run("Create certificate with default options", func(t *testing.T) {
		certBytes, privKey, err := generate()
		require.NoError(t, err)
		assert.NotNil(t, privKey)
		cert, err := x509.ParseCertificate(certBytes)
		require.NoError(t, err)
		assert.NotNil(t, cert)
		assert.Len(t, cert.DNSNames, 1)
		assert.Equal(t, "localhost", cert.DNSNames[0])
		assert.Empty(t, cert.IPAddresses)
		assert.LessOrEqual(t, int64(time.Since(cert.NotBefore)), int64(10*time.Second))
	})
}

func TestGeneratePEM(t *testing.T) {
	t.Run("Create PEM from certificate options", func(t *testing.T) {
		cert, key, err := generatePEM()
		require.NoError(t, err)
		assert.NotNil(t, cert)
		assert.NotNil(t, key)
	})

	t.Run("Create X509KeyPair", func(t *testing.T) {
		cert, err := GenerateX509KeyPair()
		require.NoError(t, err)
		assert.NotNil(t, cert)
	})
}

func TestGetClientTLSConfig(t *testing.T) {
	certPEM, keyPEM, err := generatePEM()
	require.NoError(t, err)
	tmpDir := t.TempDir()
	clientCert := filepath.Join(tmpDir, "client.crt")
	clientKey := filepath.Join(tmpDir, "client.key")
	invalidCACert := filepath.Join(tmpDir, "invalid-ca.crt")
	require.NoError(t, os.WriteFile(clientCert, certPEM, 0o600))
	require.NoError(t, os.WriteFile(clientKey, keyPEM, 0o600))
	require.NoError(t, os.WriteFile(invalidCACert, []byte("not a certificate"), 0o600))

	tests := []struct {
		name               string
		clientCert         string
		clientKey          string
		caCert             string
		insecureSkipVerify bool
		wantErr            bool
		wantErrContains    string
	}{
		{
			name:               "Valid certificate, key, and certificate authority",
			clientCert:         clientCert,
			clientKey:          clientKey,
			caCert:             clientCert,
			insecureSkipVerify: false,
			wantErr:            false,
		},
		{
			name:               "Empty certificate and key",
			clientCert:         "",
			clientKey:          "",
			insecureSkipVerify: true,
			wantErr:            false,
		},
		{
			name:       "Invalid certificate and key",
			clientCert: "testdata/empty_tls.crt",
			clientKey:  "testdata/empty_tls.key",
			wantErr:    true,
		},
		{
			name:       "Missing key file",
			clientCert: clientCert,
			clientKey:  "testdata/nonexistent.key",
			wantErr:    true,
		},
		{
			name:            "Missing key for certificate",
			clientCert:      clientCert,
			wantErr:         true,
			wantErrContains: "requires both clientCert and clientKey",
		},
		{
			name:            "Missing certificate for key",
			clientKey:       clientKey,
			wantErr:         true,
			wantErrContains: "requires both clientCert and clientKey",
		},
		{
			name:            "Missing certificate authority file",
			caCert:          "testdata/nonexistent-ca.crt",
			wantErr:         true,
			wantErrContains: "failed to read certificate authority",
		},
		{
			name:            "Invalid certificate authority",
			caCert:          invalidCACert,
			wantErr:         true,
			wantErrContains: "failed to parse certificate authority",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			config, err := GetClientTLSConfig(tt.clientCert, tt.clientKey, tt.caCert, tt.insecureSkipVerify)

			if tt.wantErr {
				require.Error(t, err)
				if tt.wantErrContains != "" {
					require.ErrorContains(t, err, tt.wantErrContains)
				}
				assert.Nil(t, config)
				return
			}

			require.NoError(t, err)
			require.NotNil(t, config)
			assert.Equal(t, tt.insecureSkipVerify, config.InsecureSkipVerify)
			assert.Equal(t, uint16(cryptotls.VersionTLS12), config.MinVersion)

			if tt.clientCert != "" && tt.clientKey != "" {
				assert.Len(t, config.Certificates, 1)
			} else {
				assert.Empty(t, config.Certificates)
			}
			if tt.caCert != "" {
				assert.NotNil(t, config.RootCAs)
			} else {
				assert.Nil(t, config.RootCAs)
			}
		})
	}
}
