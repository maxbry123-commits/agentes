"""
Guardrail Example: Medical Advice Detection with Custom Evaluators

This example demonstrates how to use custom evaluators (defined in Traceloop)
to detect and control medical advice in AI-generated responses. The examples show:

1. PASS Case: General health information that should be allowed
   - Educational content about hypertension and blood pressure
   - Uses medical-advice-detector evaluator
   - Demonstrates safe general health information

2. FAIL Case: Specific diagnosis requests that should be blocked
   - User asking for diagnosis based on symptoms
   - Uses diagnosis-blocker evaluator with direct execution
   - Shows how to block medical diagnosis attempts

Custom evaluators help distinguish between:
- Safe general health information (allowed)
- Specific medical diagnoses (blocked)

Requires a Traceloop API key and custom evaluators configured in your account.
See comments in each example for required evaluator specifications.
"""

import asyncio
import os

from openai import AsyncOpenAI
from traceloop.sdk import Traceloop
from traceloop.sdk.decorators import workflow, guardrail
from traceloop.sdk.guardrail import (
    Guardrails,
    custom_evaluator_guard,
)


# Initialize Traceloop
Traceloop.init(app_name="guardrail-custom-evaluator", disable_batch=True, endpoint_is_traceloop=True)

openai_client = AsyncOpenAI(api_key=os.getenv("OPENAI_API_KEY"))


# Example 1: Medical Advice Quality Check (PASS Case) - Using Decorator
# ======================================================================
@guardrail(
    custom_evaluator_guard(evaluator_slug="medicaladvice"),
    on_failure="Sorry, I can't help you with that.",
    name="medical_advice_quality_check",
)
async def generate_health_info() -> str:
    """
    Generate general health information about hypertension.

    This example shows content that SHOULD pass - general educational health
    information that doesn't provide specific medical diagnoses.

    Custom Evaluator Required: 'medicaladvice'
    Expected Input Fields:
      - text: The AI-generated response
    """
    completion = await openai_client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[
            {
                "role": "system",
                "content": "You are a health educator. Provide general educational "
                           "information only. Do not give any medical advice",
            },
            {
                "role": "user",
                "content": "What is hypertension and how can I maintain healthy blood pressure?",
            },
        ],
    )
    return completion.choices[0].message.content or ""


async def medical_advice_quality_check():
    """Run the decorated function and print result."""
    result = await generate_health_info()
    print(f"Health information (passed guard): {result[:200]}...")


# Example 2: Diagnosis Request Blocker (FAIL Case)
# =================================================
@workflow(name="diagnosis_request_blocker")
async def diagnosis_request_blocker():
    """
    Demonstrate blocking specific medical diagnosis requests.

    This example shows content that SHOULD fail - user requesting specific
    diagnosis based on symptoms.

    Custom Evaluator Required: 'diagnosis-blocker'
    Expected Input Fields:
      - text: The AI-generated response
    """

    async def attempt_diagnosis_request() -> str:
        """Generate response to diagnosis request (will be blocked)."""
        user_question = "I have chest pain, shortness of breath, and dizziness. Do I have a heart attack?"

        completion = await openai_client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {
                    "role": "user",
                    "content": user_question,
                }
            ],
        )
        return completion.choices[0].message.content

    g = Guardrails(
        custom_evaluator_guard(evaluator_slug="diagnosis-blocker", condition_field="pass"),
        on_failure="raise",
    )
    result = await g.run(
        attempt_diagnosis_request,
    )
    print(f"Response: {result[:200]}...")



async def main():
    """Run all medical advice guardrail examples."""
    print("=" * 70)
    print("Example 1: Medical Advice Quality Check (PASS Case)")
    print("=" * 70)
    print("Note: Requires custom evaluator 'medical-advice-detector' in Traceloop")
    print("Tests: General health information that SHOULD pass the guard\n")
    try:
        await medical_advice_quality_check()
    except Exception as e:
        print(f"Skipped: {e}")

    print("\n" + "=" * 70)
    print("Example 2: Diagnosis Request Blocker (FAIL Case)")
    print("=" * 70)
    print("Note: Requires custom evaluator 'diagnosis-blocker' in Traceloop")
    print("Tests: Specific diagnosis request that SHOULD fail the guard\n")
    try:
        await diagnosis_request_blocker()
    except Exception as e:
        print(f"Expected failure - guard blocked diagnosis request: {e}")

if __name__ == "__main__":
    asyncio.run(main())
