/*
Copyright 2021 The Kubernetes Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package main

import (
	"bufio"
	"bytes"
	"runtime"
	"strings"
	"testing"

	"github.com/stretchr/testify/assert"
)

func TestPruneXML(t *testing.T) {
	sourceXML := `<?xml version="1.0" encoding="UTF-8"?>
<testsuites>
	<testsuite tests="4" failures="2" time="271.610000" name="k8s.io/kubernetes/test/integration/apiserver" timestamp="">
		<properties>
			<property name="go.version" value="go1.18 linux/amd64"></property>
		</properties>
		<testcase classname="k8s.io/kubernetes/test/integration/apimachinery" name="TestWatchRestartsIfTimeoutNotReached/group/InformerWatcher_survives_closed_watches" time="30.050000"></testcase>
		<testcase classname="k8s.io/kubernetes/test/integration/apiserver" name="TestMaxResourceSize/JSONPatchType_should_handle_a_patch_just_under_the_max_limit" time="0.000000">
			<skipped message="=== RUN   TestMaxResourceSize/JSONPatchType_should_handle_a_patch_just_under_the_max_limit&#xA;    max_request_body_bytes_test.go:89: skipping expensive test&#xA;    --- SKIP: TestMaxResourceSize/JSONPatchType_should_handle_a_patch_just_under_the_max_limit (0.00s)&#xA;"></skipped>
		</testcase>
		<testcase classname="k8s.io/kubernetes/test/integration/apimachinery" name="TestSchedulerInformers" time="-0.000000">
			<failure message="Failed" type="">&#xA;&#x9;/home/prow/go/src/k8s.io/kubernetes/_output/local/go/src/k8s.io/kubernetes/vendor/google.golang.org/grpc/internal/transport/transport.go:169 +0x147&#xA;k8s.io/kubernetes/vendor/google.golang.org/grpc/internal/transport.(*transportReader).Read(0xc0e5f8edb0, {0xc0efe16f88?, 0xc1169d3a88?, 0x1804787?})&#xA;&#x9;/home/prow/go/src/k8s.io/kubernetes/_output/local/go/src/k8s.io/kubernetes/vendor/google.golang.org/grpc/internal/transport/transport.go:483 +0x32&#xA;io.ReadAtLeast({0x55c5720, 0xc0e5f8edb0}, {0xc0efe16f88, 0x5, 0x5}, 0x5)&#xA;&#x9;/usr/local/go/src/io/io.go:331 +0x9a&#xA;io.ReadFull(...)&#xA;&#x9;/usr/local/go/src/io/io.go:350&#xA;k8s.io/kubernetes/vendor/google.golang.org/grpc/internal/transport.(*Stream).Read(0xc0f3cd67e0, {0xc0efe16f88, 0x5, 0x5})&#xA;&#x9;/home/prow/go/src/k8s.io/kubernetes/_output/local/go/src/k8s.io/kubernetes/vendor/google.golang.org/grpc/internal/transport/transport.go:467 +0xa5&#xA;k8s.io/kubernetes/vendor/google.golang.org/grpc.(*parser).recvMsg(0xc0efe16f78, 0x7fffffff)&#xA;&#x9;/home/prow/go/src/k8s.io/kubernetes/_output/local/go/src/k8s.io/kubernetes/vendor/google.golang.org/grpc/rpc_util.go:559 +0x47&#xA;k8s.io/kubernetes/vendor/google.golang.org/grpc.recvAndDecompress(0xc1169d3c58?, 0xc0f3cd67e0, {0x0, 0x0}, 0x7fffffff, 0x0, {0x0, 0x0})&#xA;&#x9;/home/prow/go/src/k8s.io/kubernetes/_output/local/go/src/k8s.io/kubernetes/vendor/google.golang.org/grpc/rpc_util.go:690 +0x66&#xA;k8s.io/kubernetes/vendor/google.golang.org/grpc.recv(0x172b28f?, {0x7f837c291d58, 0x7f84350}, 0x6f5a274d6e8f284c?, {0x0?, 0x0?}, {0x4be7d40, 0xc0f8c01d50}, 0x0?, 0x0, ...)&#xA;&#x9;/home/prow/go/src/k8s.io/kubernetes/_output/local/go/src/k8s.io/kubernetes/vendor/google.golang.org/grpc/rpc_util.go:758 +0x6e&#xA;k8s.io/kubernetes/vendor/google.golang.org/grpc.(*csAttempt).recvMsg(0xc0eb72d800, {0x4be7d40?, 0xc0f8c01d50}, 0x2?)&#xA;&#x9;/home/prow/go/src/k8s.io/kubernetes/_output/local/go/src/k8s.io/kubernetes/vendor/google.golang.org/grpc/stream.go:970 +0x2b0&#xA;k8s.io/kubernetes/vendor/google.golang.org/grpc.(*clientStream).RecvMsg.func1(0x4be7d40?)&#xA;&#x9;/home/prow/go/src/k8s.io/kubernetes/_output/local/go/src/k8s.io/kubernetes/vendor/google.golang.org/grpc/stream.go:821 +0x25&#xA;k8s.io/kubernetes/vendor/google.golang.org/grpc.(*clientStream).withRetry(0xc0f3cd65a0, 0xc1169d3e78, 0xc1169d3e48)&#xA;&#x9;/home/prow/go/src/k8s.io/kubernetes/_output/local/go/src/k8s.io/kubernetes/vendor/google.golang.org/grpc/stream.go:675 +0x2f6&#xA;k8s.io/kubernetes/vendor/google.golang.org/grpc.(*clientStream).RecvMsg(0xc0f3cd65a0, {0x4be7d40?, 0xc0f8c01d50?})&#xA;&#x9;/home/prow/go/src/k8s.io/kubernetes/_output/local/go/src/k8s.io/kubernetes/vendor/google.golang.org/grpc/stream.go:820 +0x11f&#xA;k8s.io/kubernetes/vendor/github.com/grpc-ecosystem/go-grpc-prometheus.(*monitoredClientStream).RecvMsg(0xc0efe16f90, {0x4be7d40?, 0xc0f8c01d50?})&#xA;&#x9;/home/prow/go/src/k8s.io/kubernetes/_output/local/go/src/k8s.io/kubernetes/vendor/github.com/grpc-ecosystem/go-grpc-prometheus/client_metrics.go:160</failure>
		</testcase>
		<testcase classname="k8s.io/kubernetes/test/integration/apimachinery" name="TestLog" time="-0.000000">
			<failure message="Failed" type="">logparse_test.go:29: I1007 13:28:21.909085] klog output&#xA;FAIL: fake failure&#xA;</failure>
		</testcase>
	</testsuite>
</testsuites>`

	outputXML := `<?xml version="1.0" encoding="UTF-8"?>
<testsuites>
	<testsuite tests="4" failures="2" time="271.610000" name="k8s.io/kubernetes/test/integration/apiserver" timestamp="">
		<properties>
			<property name="go.version" value="go1.18 linux/amd64"></property>
		</properties>
		<testcase classname="k8s.io/kubernetes/test/integration/apimachinery" name="TestWatchRestartsIfTimeoutNotReached/group/InformerWatcher_survives_closed_watches" time="30.050000"></testcase>
		<testcase classname="k8s.io/kubernetes/test/integration/apiserver" name="TestMaxResourceSize/JSONPatchType_should_handle_a_patch_just_under_the_max_limit" time="0.000000">
			<skipped message="=== RUN   TestMa[...clipped...]x_limit (0.00s)&#xA;"></skipped>
		</testcase>
		<testcase classname="k8s.io/kubernetes/test/integration/apimachinery" name="TestSchedulerInformers" time="-0.000000">
			<failure message="Failed" type="">&#xA;&#x9;/home/prow/go/[...clipped...]t_metrics.go:160</failure>
		</testcase>
		<testcase classname="k8s.io/kubernetes/test/integration/apimachinery" name="TestLog" time="-0.000000">
			<failure message="Failed" type="">FAIL: fake failure&#xA;</failure>
			<system-out>logparse_test.go[...clipped...]L: fake failure&#xA;</system-out>
		</testcase>
	</testsuite>
</testsuites>`
	suites, _ := fetchXML(strings.NewReader(sourceXML))
	pruneXML(suites, 32)
	var output bytes.Buffer
	writer := bufio.NewWriter(&output)
	_ = streamXML(writer, suites)
	_ = writer.Flush()
	assert.Equal(t, outputXML, output.String(), "xml was not pruned correctly")
}

func TestPruneTESTS(t *testing.T) {
	sourceXML := `<?xml version="1.0" encoding="UTF-8"?>
<testsuites>
	<testsuite tests="6" failures="0" time="5.50000" name="k8s.io/kubernetes/cluster/gce/gci" timestamp="">
		<properties>
			<property name="go.version" value="go1.18 linux/amd64"></property>
		</properties>
		<testcase classname="k8s.io/kubernetes/cluster/gce/gci" name="TestServerOverride/ETCD-SERVERS_is_not_set_-_default_override" time="0.950000"></testcase>
		<testcase classname="k8s.io/kubernetes/cluster/gce/gci" name="TestServerOverride/ETCD-SERVERS_and_ETCD_SERVERS_OVERRIDES_are_set" time="0.660000"></testcase>
		<testcase classname="k8s.io/kubernetes/cluster/gce/gci" name="TestServerOverride" time="1.610000"></testcase>
		<testcase classname="k8s.io/kubernetes/cluster/gce/gci" name="TestStorageOptions/storage_options_are_supplied" time="0.860000"></testcase>
		<testcase classname="k8s.io/kubernetes/cluster/gce/gci" name="TestStorageOptions/storage_options_are_not_supplied" time="0.280000"></testcase>
		<testcase classname="k8s.io/kubernetes/cluster/gce/gci" name="TestStorageOptions" time="1.140000"></testcase>
	</testsuite>
	<testsuite tests="2" failures="1" time="30.050000" name="k8s.io/kubernetes/test/integration/apimachinery" timestamp="">
		<properties>
			<property name="go.version" value="go1.18 linux/amd64"></property>
		</properties>
		<testcase classname="k8s.io/kubernetes/test/integration/apimachinery" name="TestWatchRestartsIfTimeoutNotReached/group/InformerWatcher_survives_closed_watches" time="30.050000"></testcase>
		<testcase classname="k8s.io/kubernetes/test/integration/apimachinery" name="TestSchedulerInformers" time="-0.000000">
			<failure message="Failed" type="">FailureContent</failure>
		</testcase>
	</testsuite>
	<testsuite tests="3" failures="2" time="30.050000" name="k8s.io/kubernetes/test/integration/apimachinery2" timestamp="">
		<properties>
			<property name="go.version" value="go1.18 linux/amd64"></property>
		</properties>
		<testcase classname="k8s.io/kubernetes/test/integration/apimachinery2" name="TestWatchRestartsIfTimeoutNotReached/group/InformerWatcher_survives_closed_watches" time="30.050000">
			<system-out>out A</system-out>
			<system-err>err B</system-err>
                </testcase>
		<testcase classname="k8s.io/kubernetes/test/integration/apimachinery2" name="TestSchedulerInformers" time="-0.000000">
			<failure message="FailedA" type="">FailureContentA</failure>
		</testcase>
		<testcase classname="k8s.io/kubernetes/test/integration/apimachinery2" name="TestSchedulerInformers2" time="-0.000000">
			<failure message="FailedB" type="">FailureContentB</failure>
		</testcase>
	</testsuite>
	<testsuite tests="3" failures="3" time="40.050000" name="k8s.io/kubernetes/test/integration/apimachinery3" timestamp="">
		<properties>
			<property name="go.version" value="go1.18 linux/amd64"></property>
		</properties>
		<testcase classname="k8s.io/kubernetes/test/integration/apimachinery3" name="TestWatchRestartsIfTimeoutNotReached/group/InformerWatcher_survives_closed_watches" time="40.050000">
			<failure message="Failed" type="">RUNNING TestWatchRestartsIfTimeoutNotReached/group/InformerWatcher_survives_closed_watchesA&#xA;expected foo, got bar</failure>
			<system-out>out A</system-out>
			<system-err>err A</system-err>
                </testcase>
		<testcase classname="k8s.io/kubernetes/test/integration/apimachinery3" name="TestWatchRestartsIfTimeoutNotReached/group" time="40.050000">
			<failure message="Failed" type="">sub-test failed</failure>
			<system-out>out B</system-out>
			<system-err>err B</system-err>
		</testcase>
		<testcase classname="k8s.io/kubernetes/test/integration/apimachinery3" name="TestWatchRestartsIfTimeoutNotReached" time="40.050000">
			<failure message="Failed" type="">sub-test failed</failure>
		</testcase>
	</testsuite>
	<testsuite tests="1" failures="0" time="30.050000" name="k8s.io/client-go/tools/cache" timestamp="">
                <properties></properties>
		<testcase classname="k8s.io/client-go/tools/cache" name="foobar" time="30.050000"></testcase>
	</testsuite>
</testsuites>`

	// This test uses the real OWNERS files from k/k because those exist.
	// The downside it that OWNERS changes (not unlikely in the case of cluster/gce)
	// imply changing this test data.
	//
	// Fake packages have no source and thus no OWNERS.
	outputXML := `<?xml version="1.0" encoding="UTF-8"?>
<testsuites>
	<testsuite tests="6" failures="0" time="5.50000" name="[sig-cloud-provider] k8s.io/kubernetes/cluster/gce" timestamp="">
		<properties>
			<property name="go.version" value="go1.18 linux/amd64"></property>
		</properties>
		<testcase classname="[sig-cloud-provider] k8s.io/kubernetes/cluster/gce" name="gci" time="5.50000"></testcase>
	</testsuite>
	<testsuite tests="2" failures="1" time="30.050000" name="[sig-api-machinery] k8s.io/kubernetes/test/integration" timestamp="">
		<properties>
			<property name="go.version" value="go1.18 linux/amd64"></property>
		</properties>
		<testcase classname="[sig-api-machinery] k8s.io/kubernetes/test/integration" name="apimachinery" time="30.050000">
			<failure message="Failed" type="">FailureContent</failure>
		</testcase>
	</testsuite>
	<testsuite tests="3" failures="2" time="30.050000" name="k8s.io/kubernetes/test/integration" timestamp="">
		<properties>
			<property name="go.version" value="go1.18 linux/amd64"></property>
		</properties>
		<testcase classname="k8s.io/kubernetes/test/integration" name="apimachinery2" time="30.050000">
			<failure message="FailedA&#xA;&#xA;FailedB" type="">FailureContentA&#xA;&#xA;FailureContentB</failure>
		</testcase>
	</testsuite>
	<testsuite tests="3" failures="3" time="40.050000" name="k8s.io/kubernetes/test/integration" timestamp="">
		<properties>
			<property name="go.version" value="go1.18 linux/amd64"></property>
		</properties>
		<testcase classname="k8s.io/kubernetes/test/integration" name="apimachinery3" time="40.050000">
			<failure message="Failed" type="">RUNNING TestWatchRestartsIfTimeoutNotReached/group/InformerWatcher_survives_closed_watchesA&#xA;expected foo, got bar&#xA;&#xA;sub-test failed</failure>
			<system-out>out A&#xA;&#xA;out B</system-out>
			<system-err>err A&#xA;&#xA;err B</system-err>
		</testcase>
	</testsuite>
	<testsuite tests="1" failures="0" time="30.050000" name="[sig-api-machinery] k8s.io/client-go/tools" timestamp="">
		<properties></properties>
		<testcase classname="[sig-api-machinery] k8s.io/client-go/tools" name="cache" time="30.050000"></testcase>
	</testsuite>
</testsuites>`
	suites, _ := fetchXML(strings.NewReader(sourceXML))
	pruneTESTS(suites, newPackageOwners(true))
	var output bytes.Buffer
	writer := bufio.NewWriter(&output)
	_ = streamXML(writer, suites)
	_ = writer.Flush()
	assert.Equal(t, outputXML, output.String(), "tests in xml was not pruned correctly")
}

func TestAddOwner(t *testing.T) {
	// Use packages in k/k so we can validate addOwner() directory walking
	// on both Linux and Windows for directories returned by "go list".
	tests := []struct {
		name       string
		pkg        string
		wantPrefix string
	}{
		{
			name:       "finds sig-api-machinery for apimachinery package",
			pkg:        "k8s.io/kubernetes/test/integration/apimachinery",
			wantPrefix: "[sig-api-machinery] ",
		},
		{
			name:       "finds sig-cloud-provider for gce package",
			pkg:        "k8s.io/kubernetes/cluster/gce/gci",
			wantPrefix: "[sig-cloud-provider] ",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			pkgs := newPackageOwners(true)
			result := pkgs.addOwner(tt.pkg)
			assert.Equal(t, tt.wantPrefix+tt.pkg, result)
		})
	}
}

func TestAddOwnerUNCPath(t *testing.T) {
	if runtime.GOOS != "windows" {
		t.Skip("UNC paths are Windows-only")
	}

	// Validate the directory walking loop in addOwner terminates for Windows UNC paths.
	pkgs := newPackageOwners(true)
	pkgName := "k8s.iofake/pkg"
	pkgs.pkgs[pkgName] = `\\server\share\some\path`

	result := pkgs.addOwner(pkgName)
	// No OWNERS file will be found, so name should be unchanged.
	assert.Equal(t, pkgName, result, "walk over UNC path should terminate and return name unchanged")
}
