/*
Copyright The Kubernetes Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package app

import (
	"context"
	"fmt"

	utilfeature "k8s.io/apiserver/pkg/util/feature"
	"k8s.io/component-base/featuregate"
	"k8s.io/klog/v2"

	"k8s.io/kubernetes/cmd/kube-controller-manager/names"
	"k8s.io/kubernetes/pkg/controller/scheduling/podgroupprotection"
	"k8s.io/kubernetes/pkg/features"
)

func newPodGroupProtectionControllerDescriptor() *ControllerDescriptor {
	return &ControllerDescriptor{
		name:        names.PodGroupProtectionController,
		constructor: newPodGroupProtectionController,
		requiredFeatureGates: []featuregate.Feature{
			features.GenericWorkload,
		},
	}
}

func newPodGroupProtectionController(ctx context.Context, controllerContext ControllerContext, controllerName string) (Controller, error) {
	if !utilfeature.DefaultFeatureGate.Enabled(features.GenericWorkload) {
		return nil, nil
	}
	client, err := controllerContext.NewClient(controllerName)
	if err != nil {
		return nil, err
	}

	pgProtectionController, err := podgroupprotection.NewPodGroupProtectionController(
		klog.FromContext(ctx),
		controllerContext.InformerFactory.Scheduling().V1beta1().PodGroups(),
		controllerContext.InformerFactory.Core().V1().Pods(),
		client,
	)
	if err != nil {
		return nil, fmt.Errorf("failed to init %s: %w", controllerName, err)
	}

	return newControllerLoop(func(ctx context.Context) {
		pgProtectionController.Run(ctx, 1)
	}, controllerName), nil
}
