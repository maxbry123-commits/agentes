/*
Copyright 2019 The Kubernetes Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package clientgo

import (
	_ "k8s.io/component-base/metrics/prometheus/clientgo/fifo"           // load fifo metrics
	_ "k8s.io/component-base/metrics/prometheus/clientgo/leaderelection" // load leaderelection metrics
	_ "k8s.io/component-base/metrics/prometheus/restclient"              // load restclient metrics
	_ "k8s.io/component-base/metrics/prometheus/workqueue"               // load the workqueue metrics
)
