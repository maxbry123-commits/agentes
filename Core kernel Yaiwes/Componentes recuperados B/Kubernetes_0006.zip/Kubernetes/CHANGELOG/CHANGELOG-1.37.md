<!-- BEGIN MUNGE: GENERATED_TOC -->

- [v1.37.0](#v1370)
  - [Downloads for v1.37.0](#downloads-for-v1370)
    - [Source Code](#source-code)
    - [Client Binaries](#client-binaries)
    - [Server Binaries](#server-binaries)
    - [Node Binaries](#node-binaries)
    - [Container Images](#container-images)
  - [Changelog since v1.36.0](#changelog-since-v1360)
  - [Urgent Upgrade Notes](#urgent-upgrade-notes)
    - [(No, really, you MUST read this before you upgrade)](#no-really-you-must-read-this-before-you-upgrade)
  - [Changes by Kind](#changes-by-kind)
    - [Dependency](#dependency)
    - [Deprecation](#deprecation)
    - [API Change](#api-change)
    - [Feature](#feature)
    - [Documentation](#documentation)
    - [Failing Test](#failing-test)
    - [Bug or Regression](#bug-or-regression)
    - [Other (Cleanup or Flake)](#other-cleanup-or-flake)
  - [Dependencies](#dependencies)
    - [Added](#added)
    - [Changed](#changed)
    - [Removed](#removed)
- [v1.37.0-rc.1](#v1370-rc1)
  - [Downloads for v1.37.0-rc.1](#downloads-for-v1370-rc1)
    - [Source Code](#source-code-1)
    - [Client Binaries](#client-binaries-1)
    - [Server Binaries](#server-binaries-1)
    - [Node Binaries](#node-binaries-1)
    - [Container Images](#container-images-1)
  - [Changelog since v1.37.0-rc.0](#changelog-since-v1370-rc0)
  - [Dependencies](#dependencies-1)
    - [Added](#added-1)
    - [Changed](#changed-1)
    - [Removed](#removed-1)
- [v1.37.0-rc.0](#v1370-rc0)
  - [Downloads for v1.37.0-rc.0](#downloads-for-v1370-rc0)
    - [Source Code](#source-code-2)
    - [Client Binaries](#client-binaries-2)
    - [Server Binaries](#server-binaries-2)
    - [Node Binaries](#node-binaries-2)
    - [Container Images](#container-images-2)
  - [Changelog since v1.37.0-beta.0](#changelog-since-v1370-beta0)
  - [Changes by Kind](#changes-by-kind-1)
    - [Dependency](#dependency-1)
    - [API Change](#api-change-1)
    - [Feature](#feature-1)
    - [Bug or Regression](#bug-or-regression-1)
    - [Other (Cleanup or Flake)](#other-cleanup-or-flake-1)
  - [Dependencies](#dependencies-2)
    - [Added](#added-2)
    - [Changed](#changed-2)
    - [Removed](#removed-2)
- [v1.37.0-beta.0](#v1370-beta0)
  - [Downloads for v1.37.0-beta.0](#downloads-for-v1370-beta0)
    - [Source Code](#source-code-3)
    - [Client Binaries](#client-binaries-3)
    - [Server Binaries](#server-binaries-3)
    - [Node Binaries](#node-binaries-3)
    - [Container Images](#container-images-3)
  - [Changelog since v1.37.0-alpha.3](#changelog-since-v1370-alpha3)
  - [Changes by Kind](#changes-by-kind-2)
    - [Dependency](#dependency-2)
    - [API Change](#api-change-2)
    - [Feature](#feature-2)
    - [Documentation](#documentation-1)
    - [Bug or Regression](#bug-or-regression-2)
    - [Other (Cleanup or Flake)](#other-cleanup-or-flake-2)
  - [Dependencies](#dependencies-3)
    - [Added](#added-3)
    - [Changed](#changed-3)
    - [Removed](#removed-3)
- [v1.37.0-alpha.3](#v1370-alpha3)
  - [Downloads for v1.37.0-alpha.3](#downloads-for-v1370-alpha3)
    - [Source Code](#source-code-4)
    - [Client Binaries](#client-binaries-4)
    - [Server Binaries](#server-binaries-4)
    - [Node Binaries](#node-binaries-4)
    - [Container Images](#container-images-4)
  - [Changelog since v1.37.0-alpha.2](#changelog-since-v1370-alpha2)
  - [Urgent Upgrade Notes](#urgent-upgrade-notes-1)
    - [(No, really, you MUST read this before you upgrade)](#no-really-you-must-read-this-before-you-upgrade-1)
  - [Changes by Kind](#changes-by-kind-3)
    - [Dependency](#dependency-3)
    - [API Change](#api-change-3)
    - [Feature](#feature-3)
    - [Documentation](#documentation-2)
    - [Bug or Regression](#bug-or-regression-3)
    - [Other (Cleanup or Flake)](#other-cleanup-or-flake-3)
  - [Dependencies](#dependencies-4)
    - [Added](#added-4)
    - [Changed](#changed-4)
    - [Removed](#removed-4)
- [v1.37.0-alpha.2](#v1370-alpha2)
  - [Downloads for v1.37.0-alpha.2](#downloads-for-v1370-alpha2)
    - [Source Code](#source-code-5)
    - [Client Binaries](#client-binaries-5)
    - [Server Binaries](#server-binaries-5)
    - [Node Binaries](#node-binaries-5)
    - [Container Images](#container-images-5)
  - [Changelog since v1.37.0-alpha.1](#changelog-since-v1370-alpha1)
  - [Changes by Kind](#changes-by-kind-4)
    - [Deprecation](#deprecation-1)
    - [API Change](#api-change-4)
    - [Feature](#feature-4)
    - [Failing Test](#failing-test-1)
    - [Bug or Regression](#bug-or-regression-4)
    - [Other (Cleanup or Flake)](#other-cleanup-or-flake-4)
  - [Dependencies](#dependencies-5)
    - [Added](#added-5)
    - [Changed](#changed-5)
    - [Removed](#removed-5)
- [v1.37.0-alpha.1](#v1370-alpha1)
  - [Downloads for v1.37.0-alpha.1](#downloads-for-v1370-alpha1)
    - [Source Code](#source-code-6)
    - [Client Binaries](#client-binaries-6)
    - [Server Binaries](#server-binaries-6)
    - [Node Binaries](#node-binaries-6)
    - [Container Images](#container-images-6)
  - [Changelog since v1.36.0](#changelog-since-v1360-1)
  - [Urgent Upgrade Notes](#urgent-upgrade-notes-2)
    - [(No, really, you MUST read this before you upgrade)](#no-really-you-must-read-this-before-you-upgrade-2)
  - [Changes by Kind](#changes-by-kind-5)
    - [Dependency](#dependency-4)
    - [Deprecation](#deprecation-2)
    - [API Change](#api-change-5)
    - [Feature](#feature-5)
    - [Documentation](#documentation-3)
    - [Failing Test](#failing-test-2)
    - [Bug or Regression](#bug-or-regression-5)
    - [Other (Cleanup or Flake)](#other-cleanup-or-flake-5)
  - [Dependencies](#dependencies-6)
    - [Added](#added-6)
    - [Changed](#changed-6)
    - [Removed](#removed-6)

<!-- END MUNGE: GENERATED_TOC -->

# v1.37.0

[Documentation](https://docs.k8s.io)

## Downloads for v1.37.0

### Source Code

filename | sha512 hash
-------- | -----------
[kubernetes.tar.gz](https://dl.k8s.io/v1.37.0/kubernetes.tar.gz) | `840eab917c60a35306cfbfa40b3b6a70c10723f4326e5a0aa45084a83d3e45ca5def613e7fbd0dd53955ef091ed672c3035f5f42be5540099992f8723874a80b`
[kubernetes-src.tar.gz](https://dl.k8s.io/v1.37.0/kubernetes-src.tar.gz) | `639781033f79b2a795f0557cbd19013e630ab26b00aad6762d9a94100e87ac4dd5aaa3a08513948ed564bf71f8fb170404310612b3454c9ed1021c8333ed3525`

### Client Binaries

filename | sha512 hash
-------- | -----------
[kubernetes-client-darwin-amd64.tar.gz](https://dl.k8s.io/v1.37.0/kubernetes-client-darwin-amd64.tar.gz) | `6f9a612f4bd379b049b744a64e94eefc7a952fdf9b4097e09c74f8a0c9e7d3c6bd8645aea678079d4208d34ec33f200c10ce90812f08bae3c439f982dd5f0015`
[kubernetes-client-darwin-arm64.tar.gz](https://dl.k8s.io/v1.37.0/kubernetes-client-darwin-arm64.tar.gz) | `199721e27425b1de3e95f260da1e61d76dc7185ad7cba55e219b9e9a6b133fe6a92590b81d784752f08e3b7d03676d024a92b742e48628d0f6a87f9fec7f8047`
[kubernetes-client-linux-386.tar.gz](https://dl.k8s.io/v1.37.0/kubernetes-client-linux-386.tar.gz) | `a42ba1f363d1afb89f61ee09250faf60a754cbea733aa346296b5a35504c6375d656162d16bd534cb442e2b93a314c3b77de82121268f5bff30aec3f8ae8125c`
[kubernetes-client-linux-amd64.tar.gz](https://dl.k8s.io/v1.37.0/kubernetes-client-linux-amd64.tar.gz) | `ff61f94cf73281e24b8b7f16bd7ae15a928ef886399a2e8a360c170828babade73aeb284d37c596fc6c7dc68876b1550b714c1fc3ac4263adb8aef9e30a7c42f`
[kubernetes-client-linux-arm.tar.gz](https://dl.k8s.io/v1.37.0/kubernetes-client-linux-arm.tar.gz) | `a93e9c857ac63d30fb08a59afc22630f65c2ab65db0b840056b1c2fb7d8c54c0e42c862e2215f4bbba03d954f90b66fe1323d6a9b77585499f54838e90bd4b84`
[kubernetes-client-linux-arm64.tar.gz](https://dl.k8s.io/v1.37.0/kubernetes-client-linux-arm64.tar.gz) | `28167564b99d2440c3be873aff2f6bb2726ba55b58a3af3994f877f3d680e539d632e5162f96838d9efd06b87f5e1dbc811782f01f86a221afd90bf7fa9d0328`
[kubernetes-client-linux-ppc64le.tar.gz](https://dl.k8s.io/v1.37.0/kubernetes-client-linux-ppc64le.tar.gz) | `c40251ca9c0944c748e510feabce024a5e822c5868bb4922223415c7979589482702db22a0fd8976bb19dd5652bec41ce69c037daf2fe2cb3290ca8733149a4b`
[kubernetes-client-linux-s390x.tar.gz](https://dl.k8s.io/v1.37.0/kubernetes-client-linux-s390x.tar.gz) | `9bdab3d71a426a4b5371f7a8e99621ec9f6c92bb83700006b705b3a32ea33d6792fc5506fd08fc09479b91f1fa195c3d1c74765957e41b67a906b7f4b1317453`
[kubernetes-client-windows-386.tar.gz](https://dl.k8s.io/v1.37.0/kubernetes-client-windows-386.tar.gz) | `483b14fe5a980c975d8c3dcd558eaf72937f827b3a844792baff30cf2201600eacf7fa8b6c1986d6699b8bcccd1e6c9aa057f2eb54c2b87444055d786927919b`
[kubernetes-client-windows-amd64.tar.gz](https://dl.k8s.io/v1.37.0/kubernetes-client-windows-amd64.tar.gz) | `e9368652abca1590083b67be9d8f763aa27a4025d2a30a56d779ebb3150f062dc21d6673ed6ebbe04afe2a4ab4345276de67dac8e01081e9d0d199b7a492801f`
[kubernetes-client-windows-arm64.tar.gz](https://dl.k8s.io/v1.37.0/kubernetes-client-windows-arm64.tar.gz) | `7e31107af1763d0acf2eaea083e4a64c42d524205827ea3f7005043c9aeed61b2197d5c0021d3679f05530f03907c8a241eea4dcde19038492609bda0ebfc044`

### Server Binaries

filename | sha512 hash
-------- | -----------
[kubernetes-server-linux-amd64.tar.gz](https://dl.k8s.io/v1.37.0/kubernetes-server-linux-amd64.tar.gz) | `f537143ccadab75bce7cfa97ae29999ec4fa5e09405ad65cb9b1dcd3b132a0eefde4fcc8653e0059113b1ffb163255df26cd4a725b07601a261c94e17cbcfc6e`
[kubernetes-server-linux-arm64.tar.gz](https://dl.k8s.io/v1.37.0/kubernetes-server-linux-arm64.tar.gz) | `09d9be33f71a93704da6684e0c88872d3140e55c4ad9ae87a92045ac0423ce3770b282b6d5f13fbdb5e49dd817385d0e261ba5f22637eb14712f5301d39f8795`
[kubernetes-server-linux-ppc64le.tar.gz](https://dl.k8s.io/v1.37.0/kubernetes-server-linux-ppc64le.tar.gz) | `56e56d0bfa217a40987d0cb6a181ffaed35bf7efcb13856fe681dc507728b3d71f39c42e021e20732c0f751cedfb61b00077f388f26273d4c4007a5e0952dbcd`
[kubernetes-server-linux-s390x.tar.gz](https://dl.k8s.io/v1.37.0/kubernetes-server-linux-s390x.tar.gz) | `a31dc4c535a2a064581604c82ce7086c79fe4826b1cdf276ce714b9607d682514f3ed7c1059b6f1feae9111ebdef534b34b571cce3b5c165447385074ba6f659`

### Node Binaries

filename | sha512 hash
-------- | -----------
[kubernetes-node-linux-amd64.tar.gz](https://dl.k8s.io/v1.37.0/kubernetes-node-linux-amd64.tar.gz) | `f2b47175d2a2844ae1673d239b7b8be18b7dc2363077925bba654802aa9f35aedafb7086aae9005545267aef21518986177fd7ca4b25edfe6e400102adfccad2`
[kubernetes-node-linux-arm64.tar.gz](https://dl.k8s.io/v1.37.0/kubernetes-node-linux-arm64.tar.gz) | `3c7d592a9da9466c41ae0f913215bbbe7e62704e83b1c5c38c0bbcf9ae20de4c62186e4ab638bcb2cd0d4c1a658d945dbb634413409fb601da0231f47bed219c`
[kubernetes-node-linux-ppc64le.tar.gz](https://dl.k8s.io/v1.37.0/kubernetes-node-linux-ppc64le.tar.gz) | `7c0a1d8aed394884e15b6e50701237fdd6664aa6fe302f34bce3341918cb3acc29df38084794d6f4d08b42bde073da84371550b2b444d40e746a3be63653ceda`
[kubernetes-node-linux-s390x.tar.gz](https://dl.k8s.io/v1.37.0/kubernetes-node-linux-s390x.tar.gz) | `71d4ee0c4cfac965cfa9054bd3ccc1030dfbc454af6e56c8ca63e83d6327fff10e5561d39c69cc16ef875cd499f30673fbec3aa770d51ef6d1f4414b1040b9b9`
[kubernetes-node-windows-amd64.tar.gz](https://dl.k8s.io/v1.37.0/kubernetes-node-windows-amd64.tar.gz) | `50ce08d0cac9fe0c772cc87a8097f0bdc1866ddbf25cc2842d91e929f079b984836b0a2bb427b0b34e33eec44502afacbfde74d06acbc421ebe85287ae7df1b4`

### Container Images

All container images are available as manifest lists and support the described
architectures. It is also possible to pull a specific architecture directly by
adding the "-$ARCH" suffix  to the container image name.
name | architectures
---- | -------------
[registry.k8s.io/conformance:v1.37.0](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/conformance) | [amd64](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/conformance-amd64), [arm64](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/conformance-arm64), [ppc64le](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/conformance-ppc64le), [s390x](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/conformance-s390x)
[registry.k8s.io/kube-apiserver:v1.37.0](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-apiserver) | [amd64](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-apiserver-amd64), [arm64](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-apiserver-arm64), [ppc64le](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-apiserver-ppc64le), [s390x](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-apiserver-s390x)
[registry.k8s.io/kube-controller-manager:v1.37.0](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-controller-manager) | [amd64](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-controller-manager-amd64), [arm64](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-controller-manager-arm64), [ppc64le](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-controller-manager-ppc64le), [s390x](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-controller-manager-s390x)
[registry.k8s.io/kube-proxy:v1.37.0](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-proxy) | [amd64](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-proxy-amd64), [arm64](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-proxy-arm64), [ppc64le](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-proxy-ppc64le), [s390x](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-proxy-s390x)
[registry.k8s.io/kube-scheduler:v1.37.0](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-scheduler) | [amd64](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-scheduler-amd64), [arm64](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-scheduler-arm64), [ppc64le](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-scheduler-ppc64le), [s390x](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-scheduler-s390x)
[registry.k8s.io/kubectl:v1.37.0](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kubectl) | [amd64](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kubectl-amd64), [arm64](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kubectl-arm64), [ppc64le](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kubectl-ppc64le), [s390x](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kubectl-s390x)

## Changelog since v1.36.0

## Urgent Upgrade Notes 

### (No, really, you MUST read this before you upgrade)

- ACTION REQUIRED: Graduated the `SELinuxMount` feature gate to GA. The feature is enabled by default in `v1.37`, which may break existing workloads in clusters with SELinux enabled. Please see [the Kubernetes blog post](https://kubernetes.io/blog/2026/04/22/breaking-changes-in-selinux-volume-labeling/) to identify potentially problematic workloads in a `v1.36` cluster and how to fix them or opt out of `SELinuxMount` changes before upgrading to `v1.37`. Admins of clusters without SELinux enabled can ignore this release note. ([#139956](https://github.com/kubernetes/kubernetes/pull/139956), [@jsafrane](https://github.com/jsafrane)) [SIG API Machinery, Apps and Node]
- ACTION REQUIRED: Converted the `DisruptionMode` enum field to a struct to support future extensibility. Promoted the `scheduling.k8s.io` API group from `v1alpha2` to `v1alpha3` and dropped `v1alpha2` entirely.
  Remove all `v1alpha2` objects from the `kube-apiserver` before performing the cluster update. ([#138572](https://github.com/kubernetes/kubernetes/pull/138572), [@dom4ha](https://github.com/dom4ha)) [SIG API Machinery, Apps, CLI, Etcd, Node, Scheduling and Testing]
- ACTION REQUIRED: Fixed `eventRecordQPS` handling in `kubelet` configuration to treat 0 as unlimited (no rate limit), aligning behavior with the documentation. Users relying on the previous default behavior should explicitly set a non-zero value (for example, 50). ([#117119](https://github.com/kubernetes/kubernetes/pull/117119), [@HirazawaUi](https://github.com/HirazawaUi)) [SIG API Machinery, Auth and Node]
- ACTION REQUIRED: Updated the `kubelet` to log its effective configuration at startup. Because these logs can expose configuration details, cluster administrators should restrict the `nodes/logs` ClusterRole to trusted users. This is largely a reminder of an existing best practice, since most effective configuration values can already be inferred from other log messages or `kubelet` behavior. ([#139837](https://github.com/kubernetes/kubernetes/pull/139837), [@SergeyKanzhelev](https://github.com/SergeyKanzhelev)) [SIG Node]
 
## Changes by Kind

### Dependency

- Updated `google.golang.org/grpc` to `v1.82.1`, which adds a server-side limit on HTTP/2 control frame flooding. It also removes the `GRPC_GO_EXPERIMENTAL_DISABLE_STRICT_PATH_CHECKING` environment variable, so strict path checking is always on. ([#140740](https://github.com/kubernetes/kubernetes/pull/140740), [@dims](https://github.com/dims)) [SIG API Machinery, Architecture, Auth, CLI, Cloud Provider, Network, Node and Scheduling]
- Updated the `kubelet`'s embedded `cAdvisor` to use the leaner `github.com/google/cadvisor/lib` module, which removes three long-deprecated or legacy surfaces:
  - Deprecated `cAdvisor` flags are no longer accepted and the `kubelet` will fail to start if any are set (only `--housekeeping-interval` is kept): `--application-metrics-count-limit`, `--boot-id-file`, `--container-hints`, `--containerd`, `--containerd-namespace`, `--enable-load-reader`, `--event-storage-age-limit`, `--event-storage-event-limit`, `--global-housekeeping-interval`, `--log-cadvisor-usage`, `--machine-id-file`, `--storage-driver-user`, `--storage-driver-password`, `--storage-driver-host`, `--storage-driver-db`, `--storage-driver-table`, `--storage-driver-secure`, `--storage-driver-buffer-duration`. Remove these from your `kubelet` configuration.
  - `cAdvisor` application/custom metrics are no longer collected: the `userDefinedMetrics` field in `/stats/summary` and the custom `container_application_*` families in `/metrics/cadvisor`.
  - The `/metrics/cadvisor` series `container_cpu_load_average_10s`, `container_cpu_load_d_average_10s`, and `container_tasks_state` are no longer exported. ([#139870](https://github.com/kubernetes/kubernetes/pull/139870), [@dims](https://github.com/dims)) [SIG API Machinery, Auth, Instrumentation, Network, Node and Testing]
- Updated the default etcd version to `v3.7.0-rc.0`. ([#139427](https://github.com/kubernetes/kubernetes/pull/139427), [@Jefftree](https://github.com/Jefftree)) [SIG API Machinery, Cloud Provider, Cluster Lifecycle, Etcd and Testing]
- Updated the default etcd version to `v3.7.0`. ([#140333](https://github.com/kubernetes/kubernetes/pull/140333), [@Jefftree](https://github.com/Jefftree)) [SIG API Machinery, Auth, Cloud Provider, Cluster Lifecycle, Etcd, Node, Scheduling and Testing]
- Updated the etcd client library to `v3.6.10`. ([#138393](https://github.com/kubernetes/kubernetes/pull/138393), [@humblec](https://github.com/humblec)) [SIG API Machinery, Architecture, Auth, CLI, Cloud Provider, Cluster Lifecycle, Etcd, Instrumentation, Network, Node, Scheduling and Storage]

### Deprecation

- Changed `kubeadm` to explicitly set `KubeProxyConfiguration.mode` to iptables when `KubeProxyConfiguration` is not provided or when the `mode` field is empty. In `v1.37`, `kube-proxy` will warn if the field is not explicitly set as part of the planned transition to nftables as the default mode in a future release. ([#139777](https://github.com/kubernetes/kubernetes/pull/139777), [@neolit123](https://github.com/neolit123)) [SIG Cluster Lifecycle]
- Deprecated the ignored `--filename`/`-f` flag on `kubectl run`. ([#138671](https://github.com/kubernetes/kubernetes/pull/138671), [@Suknna](https://github.com/Suknna)) [SIG CLI]
- Locked the deprecated `DeclarativeValidationTakeover` feature gate to its default value; it can no longer be set. ([#139212](https://github.com/kubernetes/kubernetes/pull/139212), [@yongruilin](https://github.com/yongruilin)) [SIG API Machinery]
- `kubeadm`: Added a (delayed) warning that `kube-proxy`'s ipvs mode is deprecated since `v1.35` and users on newer Linux kernels should be using the nftables mode instead, which became GA in `v1.33`. For older kernel versions, users can use iptables, which is still the default. ([#139067](https://github.com/kubernetes/kubernetes/pull/139067), [@neolit123](https://github.com/neolit123)) [SIG Cluster Lifecycle]

### API Change

- Added Alpha support for DRA device compatibility groups, guarded by the `DRADeviceCompatibilityGroups` feature gate (disabled by default). DRA drivers can declare opaque `compatibilityGroups` on each `device.consumesCounters[]` entry of a ResourceSlice, and the scheduler only co-allocates devices drawing from the same counter set when their declared groups intersect. This moves detection of incompatible co-allocation from preparation-time failure to scheduling-time rejection. ([#139795](https://github.com/kubernetes/kubernetes/pull/139795), [@omeryahud](https://github.com/omeryahud)) [SIG API Machinery, Node, Scheduling and Testing]
- Added Alpha support for binding service account tokens to webhook configurations with attestations, behind the `APIServerWebhookAuthenticationToken` feature gate. This enables API servers to authenticate to admission webhooks with scoped tokens. ([#140113](https://github.com/kubernetes/kubernetes/pull/140113), [@pmengelbert](https://github.com/pmengelbert)) [SIG API Machinery, Apps, Auth and Testing]
- Added Alpha support for defining the file owner of atomically written volume files, behind the `AtomicWriteVolumeUserFields` feature gate (disabled by default). ([#139764](https://github.com/kubernetes/kubernetes/pull/139764), [@gavinkflam](https://github.com/gavinkflam)) [SIG API Machinery, Apps, Auth, Storage and Testing]
- Added CompositePodGroup support to the building block APIs and the `workloadbuilder` library. ([#140717](https://github.com/kubernetes/kubernetes/pull/140717), [@helayoty](https://github.com/helayoty)) [SIG API Machinery, Apps, Auth, Scheduling and Testing]
- Added Workload-aware scheduling (WAS) support to the Job controller by integrating it with the `workloadbuilder` library and the Workload building block APIs. ([#140188](https://github.com/kubernetes/kubernetes/pull/140188), [@helayoty](https://github.com/helayoty)) [SIG API Machinery, Apps, Auth, Network, Node, Scheduling, Storage and Testing]
- Added `CheckpointPod` and `RestorePod` RPCs to the CRI `v1` RuntimeService API for Pod-level checkpoint and restore. ([#140366](https://github.com/kubernetes/kubernetes/pull/140366), [@rst0git](https://github.com/rst0git)) [SIG Node, Testing and Windows]
- Added a `PreemptionPolicy` field to PodGroup, allowing users to control how `kube-scheduler` preempts Pods that belong to a PodGroup during workload-aware preemption. ([#139240](https://github.com/kubernetes/kubernetes/pull/139240), [@ania-borowiec](https://github.com/ania-borowiec)) [SIG Scheduling]
- Added a `protocol` field to `httpGet` probes so that liveness, readiness, and startup probes can run over HTTP/2 cleartext (H2C). ([#139429](https://github.com/kubernetes/kubernetes/pull/139429), [@amritansh1502](https://github.com/amritansh1502)) [SIG API Machinery, Apps, Node and Testing]
- Added a defense-in-depth check to the `NodeRestriction` admission plugin for PodCertificateRequests. A node can only create a PodCertificateRequest referring to a particular signer name if the Pod actually mounts a `podCertificate` projected volume source that refers to that signer name, or if an authorization check for the user (with `verb=request-podcertificate-signer` and `resource=<signerName>`) succeeds. ([#140006](https://github.com/kubernetes/kubernetes/pull/140006), [@ahmedtd](https://github.com/ahmedtd)) [SIG Auth and Testing]
- Added a second Alpha of DRA resource availability visibility (KEP-5677), behind the `DRAResourcePoolStatus` feature gate (disabled by default). The ResourcePoolStatusRequest controller counts partitionable and consumable devices correctly, counting each device once, ignoring AdminAccess, and treating taints as unavailable. Optional fields describe partition and shareable availability. These accounting fixes change the numbers reported in `v1.36`. ([#140170](https://github.com/kubernetes/kubernetes/pull/140170), [@nmn3m](https://github.com/nmn3m)) [SIG API Machinery, Apps, Auth, Node and Testing]
- Added an opt-in userspace TCP proxy to the nftables `kube-proxy` backend to serve localhost NodePort Services on IPv4 and IPv6. ([#138427](https://github.com/kubernetes/kubernetes/pull/138427), [@AustinAbro321](https://github.com/AustinAbro321)) [SIG Instrumentation, Network and Testing]
- Added dry-run support to unsafe corrupt object deletion, letting administrators test deletion operations safely before running them. ([#134037](https://github.com/kubernetes/kubernetes/pull/134037), [@ibihim](https://github.com/ibihim)) [SIG API Machinery and Testing]
- Added generated declarative validation functions for Go consumers of the DRA device metadata `v1alpha1` API. ([#140687](https://github.com/kubernetes/kubernetes/pull/140687), [@alaypatel07](https://github.com/alaypatel07)) [SIG Node]
- Added scheduler support for preempting lower-priority Pods to make room for `Deferred` in-place Pod resizes of higher-priority Pods when the `InPlacePodVerticalScalingSchedulerPreemption` Alpha feature gate is enabled. ([#140000](https://github.com/kubernetes/kubernetes/pull/140000), [@natasha41575](https://github.com/natasha41575)) [SIG API Machinery, Apps, Node, Scheduling, Storage and Testing]
- Added support for derived attributes in DRA, allowing claims to define virtual attributes using CEL expressions and use them in device constraints. This enables co-allocation of devices across different domains, for example GPUs and NICs on the same NUMA node, even if their drivers publish physical attributes differently. ([#140029](https://github.com/kubernetes/kubernetes/pull/140029), [@gauravkghildiyal](https://github.com/gauravkghildiyal)) [SIG API Machinery, Node, Scheduling and Testing]
- Added support for dynamically resizing memory-backed volumes behind the Alpha `InPlacePodVerticalScalingMemoryBackedVolumes` feature gate. ([#139425](https://github.com/kubernetes/kubernetes/pull/139425), [@natasha41575](https://github.com/natasha41575)) [SIG API Machinery, Apps, Autoscaling, CLI, Node, Scheduling, Storage and Testing]
- Added support for selecting ResourceSlices by pool name with the field selector `spec.pool.name`. ([#138456](https://github.com/kubernetes/kubernetes/pull/138456), [@yaroslavborbat](https://github.com/yaroslavborbat)) [SIG API Machinery, Node and Testing]
- Added support for setting Unix permission bits (0000-01777) through the `mode` field on emptyDir volume directories at creation time. ([#140244](https://github.com/kubernetes/kubernetes/pull/140244), [@nispriha](https://github.com/nispriha)) [SIG API Machinery, Apps, Node, Storage and Testing]
- Added support for specifying bind mount options (`noexec`, `nodev`, `nosuid`) per container volume mount. ([#140013](https://github.com/kubernetes/kubernetes/pull/140013), [@nispriha](https://github.com/nispriha)) [SIG API Machinery, Apps, Autoscaling, Node, Scheduling and Testing]
- Added the API changes required for reporting volume health. ([#140194](https://github.com/kubernetes/kubernetes/pull/140194), [@gnufied](https://github.com/gnufied)) [SIG API Machinery, Apps, Architecture, Auth, Etcd, Instrumentation, Node, Storage and Testing]
- Added the CompositePodGroup API to `scheduling.k8s.io/v1alpha3`. ([#139596](https://github.com/kubernetes/kubernetes/pull/139596), [@jdzikowski](https://github.com/jdzikowski)) [SIG API Machinery, Apps, Auth, Etcd, Node, Scheduling and Testing]
- Added the Recreate update strategy for StatefulSet, mirroring the Deployment Recreate strategy by deleting all Pods, waiting for them to terminate completely, and then creating Pods according to the `podManagementPolicy` field. ([#137187](https://github.com/kubernetes/kubernetes/pull/137187), [@galal-hussein](https://github.com/galal-hussein)) [SIG Apps and Testing]
- Added the `--concurrent-disruption-syncs` flag to `kube-controller-manager` to configure the number of concurrent disruption controller workers. ([#140014](https://github.com/kubernetes/kubernetes/pull/140014), [@xigang](https://github.com/xigang)) [SIG API Machinery, Apps, Auth and Testing]
- Added the `.spec.evictionResponders` Pod field, along with the EvictionRequest and Eviction resources. A set of requesters and responders can use these to coordinate graceful eviction of Pods. ([#137050](https://github.com/kubernetes/kubernetes/pull/137050), [@atiratree](https://github.com/atiratree)) [SIG API Machinery, Apps, Architecture, Auth, CLI, Etcd and Testing]
- Added the `DefaultPodSysctls` `kubelet` configuration field for default Pod sysctls on Linux nodes, behind the Alpha `DefaultPodSysctls` feature gate (disabled by default). ([#140052](https://github.com/kubernetes/kubernetes/pull/140052), [@VeraQin](https://github.com/VeraQin)) [SIG Node and Testing]
- Added the `DisruptionMode` and `PreemptionPolicy` fields to the Workload and CompositePodGroup APIs to support workload-aware preemption for CompositePodGroups. ([#140634](https://github.com/kubernetes/kubernetes/pull/140634), [@tosi3k](https://github.com/tosi3k)) [SIG API Machinery, Auth, Etcd, Node, Scheduling and Testing]
- Added the `GracefulNodeShutdownInProgress`, `DrainInProgress`, `Drained`, `MaintenancePlanned`, and `MaintenanceInProgress` Node lifecycle conditions. ([#139993](https://github.com/kubernetes/kubernetes/pull/139993), [@rthallisey](https://github.com/rthallisey)) [SIG Apps and Node]
- Added the `PodGroupPostFilter` extension point to the scheduling framework, replacing the internal hardcoding for `WorkloadAwarePreemption` with a configurable extension point for PodGroups. ([#139674](https://github.com/kubernetes/kubernetes/pull/139674), [@GFilipek](https://github.com/GFilipek)) [SIG Scheduling and Testing]
- Added the `PreemptionPolicy` field to PodGroupTemplate to define the policy for workload-aware preemption. ([#140312](https://github.com/kubernetes/kubernetes/pull/140312), [@ania-borowiec](https://github.com/ania-borowiec)) [SIG API Machinery, Apps, Scheduling and Testing]
- Added the `SchedulerPreQueueingHints` feature gate (Alpha, disabled by default). When enabled, scheduler plugins can provide a `PreQueueingHintFn` that narrows the set of Pods evaluated on cluster events, improving scheduling throughput. The DRA plugin implements this to optimize ResourceClaimTemplate-based workloads. ([#138916](https://github.com/kubernetes/kubernetes/pull/138916), [@geetasg](https://github.com/geetasg)) [SIG API Machinery, Apps, Architecture, Auth, CLI, Cloud Provider, Instrumentation, Network, Node, Scheduling, Storage, Testing and Windows]
- Added the core machinery for Conditional Authorization, which enables authorizers to allow requests conditionally based on the request's content, rather than only allowing or denying them outright. ([#137513](https://github.com/kubernetes/kubernetes/pull/137513), [@luxas](https://github.com/luxas)) [SIG API Machinery, Auth, Node and Testing]
- Allowed HorizontalPodAutoscaler conditions to optionally include the `observedGeneration` at the time the condition was recorded. ([#138653](https://github.com/kubernetes/kubernetes/pull/138653), [@adrianmoisey](https://github.com/adrianmoisey)) [SIG API Machinery, Apps, Autoscaling and Testing]
- Changed the `kube-apiserver` CBOR encoder to encode collections item by item instead of all at once. ([#138808](https://github.com/kubernetes/kubernetes/pull/138808), [@chenk008](https://github.com/chenk008)) [SIG API Machinery, Apps, Auth, Autoscaling, CLI, Cloud Provider, Cluster Lifecycle, Contributor Experience, Instrumentation, Network, Node, Release, Scalability, Scheduling, Storage, Testing and Windows]
- DRA: Added Alpha support for `DRAOptionalNodeOperations` (the `SkipNodeOperations` field in ResourceSlice and ResourceClaim), which allows skipping node-level preparation and cleanup operations. ([#139933](https://github.com/kubernetes/kubernetes/pull/139933), [@troychiu](https://github.com/troychiu)) [SIG API Machinery, Autoscaling, Instrumentation, Node, Release, Scheduling and Testing]
- Fixed CEL cost estimation for `metadata.name` and `metadata.generateName` in CRDs to correctly account for the default maximum length of 253 characters, unless additional validations are defined on those metadata fields. ([#139573](https://github.com/kubernetes/kubernetes/pull/139573), [@jpbetz](https://github.com/jpbetz)) [SIG API Machinery]
- Fixed DRA `CapacityRequestPolicyRange` to support fractional quantities in milli-scale. ([#140161](https://github.com/kubernetes/kubernetes/pull/140161), [@sunya-ch](https://github.com/sunya-ch)) [SIG API Machinery, Node and Scheduling]
- Fixed Pod status validation for reported Linux container user UIDs to accept values above 2147483647 and up to the unsigned 32-bit UID limit. ([#138574](https://github.com/kubernetes/kubernetes/pull/138574), [@Kunalbehbud](https://github.com/Kunalbehbud)) [SIG Apps and Node]
- Fixed a `v1.34`+ regression handling containers with environment values set from Secret API objects containing binary non-utf8 data. ([#139168](https://github.com/kubernetes/kubernetes/pull/139168), [@liggitt](https://github.com/liggitt)) [SIG Architecture, Node and Testing]
- Fixed a bug in DRA consumable capacity where the `DistinctAttribute` constraint was not correctly enforced for each device when a request allocated multiple devices. ([#140600](https://github.com/kubernetes/kubernetes/pull/140600), [@GunaKKIBM](https://github.com/GunaKKIBM)) [SIG API Machinery, Apps, CLI, Etcd, Network, Node, Release, Scheduling and Testing]
- Fixed the overestimation of a Pod's resource footprint during resize operations for multi-container Pods. ([#140047](https://github.com/kubernetes/kubernetes/pull/140047), [@natasha41575](https://github.com/natasha41575)) [SIG Node and Scheduling]
- Graduated Pod Certificates to GA, with the PodCertificateRequest feature gate enabled by default. The `PKIXPublicKey` and `ProofOfPossession` fields, deprecated in PodCertificateRequest `v1beta1`, are removed from the `v1` API. Update clients that still set these fields before upgrading. ([#139579](https://github.com/kubernetes/kubernetes/pull/139579), [@yt2985](https://github.com/yt2985)) [SIG API Machinery, Apps, Architecture, Auth, Etcd, Node, Scheduling and Testing]
- Graduated Pod hostname overrides to GA. The `HostnameOverride` feature gate is locked to enabled. ([#139116](https://github.com/kubernetes/kubernetes/pull/139116), [@HirazawaUi](https://github.com/HirazawaUi)) [SIG API Machinery, Apps, Node and Testing]
- Graduated the `ClusterTrustBundle` and `ClusterTrustBundleProjection` feature gates to GA and enabled them by default. ([#139437](https://github.com/kubernetes/kubernetes/pull/139437), [@stlaz](https://github.com/stlaz)) [SIG API Machinery, Apps, Architecture, Auth, Etcd, Node, Storage and Testing]
- Improved CEL error messages in Dynamic Resource Allocation to provide guidance when accessing non-existent device attributes. Error messages link to documentation on handling optional fields using `orValue()` and `has()`. ([#136709](https://github.com/kubernetes/kubernetes/pull/136709), [@gzb1128](https://github.com/gzb1128)) [SIG API Machinery, Node and Scheduling]
- Moved the `NodeSyncPeriod` field from `KubeCloudSharedConfiguration` to `CloudControllerManagerConfiguration.NodeLifecycleController.NodeMonitorPeriod`. ([#137964](https://github.com/kubernetes/kubernetes/pull/137964), [@niewysoki](https://github.com/niewysoki)) [SIG API Machinery, Apps, Cloud Provider, Instrumentation and Node]
- Promoted DRA Workload resource claims to Beta. The `DRAWorkloadResourceClaims` feature gate remains disabled by default. ([#140334](https://github.com/kubernetes/kubernetes/pull/140334), [@nojnhuh](https://github.com/nojnhuh)) [SIG API Machinery, Apps, Etcd, Node, Scheduling and Testing]
- Promoted `kubelet` volume metrics (`storage_operation_duration_seconds`, `volume_operation_total_seconds`) from Alpha to Beta stability, providing stronger API and label stability guarantees for metric consumers. ([#136189](https://github.com/kubernetes/kubernetes/pull/136189), [@bhope](https://github.com/bhope)) [SIG Instrumentation and Storage]
- Promoted the DRA Device Taints and Tolerations feature to GA, making it available via the `resource.k8s.io/v1` API. ([#138676](https://github.com/kubernetes/kubernetes/pull/138676), [@pohly](https://github.com/pohly)) [SIG API Machinery, Apps, Architecture, Auth, Etcd, Node, Scheduling, Storage and Testing]
- Promoted the DRA extended resource feature to GA in `v1.37`. ([#138488](https://github.com/kubernetes/kubernetes/pull/138488), [@yliaog](https://github.com/yliaog)) [SIG API Machinery, Apps, Node, Scheduling and Testing]
- Promoted the DRA metadata API to Beta. DRA driver authors that enable the feature must explicitly select which versions to support in their metadata output. ([#140722](https://github.com/kubernetes/kubernetes/pull/140722), [@pohly](https://github.com/pohly)) [SIG Node and Testing]
- Promoted the DRAResourceHealth `kubelet` gRPC API to `v1`; the schema is unchanged from `v1alpha1`. `DRAPlugin.WatchHealthStatus` is a mandatory method on the `DRAPlugin` interface in the `k8s.io/dynamic-resource-allocation/kubeletplugin` helper, replacing the optional versioned gRPC interface. This is a one-time Go API break: existing drivers must add the method to compile. Drivers without health support return `ErrHealthNotSupported` from it, or disable the service with `HealthService(false)`. The helper serves both `v1` and `v1alpha1` by default, so drivers report health on `kubelet` `v1.36` and older without extra configuration. The `kubelet` prefers `v1` and, for three releases of transition, still consumes `v1alpha1` from drivers that shipped before `v1` existed. The `v1alpha1` DRAResourceHealth API is deprecated and is planned to be removed in `v1.40`. The `kubelet` only opens the device health stream for plugins that advertise the service. ([#139477](https://github.com/kubernetes/kubernetes/pull/139477), [@harche](https://github.com/harche)) [SIG Node and Testing]
- Promoted the `HPAConfigurableTolerance` feature gate to GA. ([#140107](https://github.com/kubernetes/kubernetes/pull/140107), [@jm-franc](https://github.com/jm-franc)) [SIG API Machinery, Apps, Autoscaling and Testing]
- Promoted the `KubeletInUserNamespace` feature gate to Beta. ([#134639](https://github.com/kubernetes/kubernetes/pull/134639), [@AkihiroSuda](https://github.com/AkihiroSuda)) [SIG API Machinery, Apps, Node and Testing]
- Promoted the `MemoryQoS` feature gate to Beta. `memoryThrottlingFactor` defaults to nil, and `memory.high` is not set unless explicitly configured. ([#140007](https://github.com/kubernetes/kubernetes/pull/140007), [@QiWang19](https://github.com/QiWang19)) [SIG Node and Testing]
- Promoted the `NodeDeclaredFeatures` feature gate to GA. ([#139763](https://github.com/kubernetes/kubernetes/pull/139763), [@pravk03](https://github.com/pravk03)) [SIG Apps, Autoscaling, Node, Scheduling and Testing]
- Promoted the `PersistentVolumeClaimUnusedSinceTime` feature gate to Beta in `v1.37` and enabled it by default. PersistentVolumeClaims report the `Unused` condition, indicating how long a PersistentVolumeClaim has been unused to help identify candidates for cleanup. ([#139620](https://github.com/kubernetes/kubernetes/pull/139620), [@RomanBednar](https://github.com/RomanBednar)) [SIG Apps]
- Promoted the `StorageVersionMigration` feature gate to GA. The `storagemigration.k8s.io/v1` API group is enabled by default. ([#138560](https://github.com/kubernetes/kubernetes/pull/138560), [@michaelasp](https://github.com/michaelasp)) [SIG API Machinery, Apps, Architecture, Auth, Etcd and Testing]
- Promoted the `VolumeLimitScaling` feature gate, which adds the `preventPodSchedulingIfMissing` field to CSIDriver to prevent Pod scheduling on nodes missing a required CSI driver, to Beta. ([#140612](https://github.com/kubernetes/kubernetes/pull/140612), [@gnufied](https://github.com/gnufied)) [SIG API Machinery, Storage and Testing]
- Promoted the `metrics.k8s.io` API from `v1beta1` to `v1` without changes. ([#139223](https://github.com/kubernetes/kubernetes/pull/139223), [@tico88612](https://github.com/tico88612)) [SIG Instrumentation]
- Promoted the core Workload-Aware Scheduling (WAS) API types Workload and PodGroup to `scheduling.k8s.io/v1beta1`. Remove all `v1alpha2` objects from the `kube-apiserver` before upgrading from `v1.36` to `v1.37`. ([#140184](https://github.com/kubernetes/kubernetes/pull/140184), [@tosi3k](https://github.com/tosi3k)) [SIG API Machinery, Apps, Auth, Etcd, Node, Scheduling and Testing]
- Relaxed container security context validation so that updates to Pods may set `allowPrivilegeEscalation` together with `CAP_SYSADMIN`. Pod creation still rejects this combination. ([#138834](https://github.com/kubernetes/kubernetes/pull/138834), [@haircommander](https://github.com/haircommander)) [SIG Apps]
- Removed the `GangScheduling` and `WorkloadAwarePreemption` feature gates. Use the `GenericWorkload` feature gate to enable core workload-aware scheduling functionality. ([#139520](https://github.com/kubernetes/kubernetes/pull/139520), [@macsko](https://github.com/macsko)) [SIG API Machinery, Node, Scheduling and Testing]
- Removed the generally available feature gate `AnyVolumeDataSource`, which was locked and enabled since `v1.33`. ([#135336](https://github.com/kubernetes/kubernetes/pull/135336), [@carlory](https://github.com/carlory)) [SIG API Machinery, Apps, Storage and Testing]
- Removed the unused `PodStatusResult` type from the Kubernetes API. This type had no REST endpoint and has been unused since 2015. ([#136271](https://github.com/kubernetes/kubernetes/pull/136271), [@adityasharmawork](https://github.com/adityasharmawork)) [SIG API Machinery, Apps, Node and Testing]
- Renamed signal enum keys in `cri-api`, which are prefixed with `SIGNAL_` in the `api.proto` definition, to avoid conflicts with C++ macros. The wire format is unchanged. ([#139251](https://github.com/kubernetes/kubernetes/pull/139251), [@SergeyKanzhelev](https://github.com/SergeyKanzhelev)) [SIG Apps, Node and Testing]
- Renamed the PodGroup condition `PodGroupScheduled` to `PodGroupInitiallyScheduled` to clarify that the condition is set only after a PodGroup is first scheduled successfully and may not reflect the PodGroup's current scheduling state. ([#139743](https://github.com/kubernetes/kubernetes/pull/139743), [@antekjb](https://github.com/antekjb)) [SIG API Machinery, Scheduling and Testing]
- Switched the json tag for inlined `TypeMeta` fields in the API Go types from `",inline"` to `""`. `inline` was not a recognized json serializer option and did not modify marshal or unmarshal behavior. ([#138260](https://github.com/kubernetes/kubernetes/pull/138260), [@liggitt](https://github.com/liggitt)) [SIG API Machinery, Apps, Architecture, Auth, CLI, Cloud Provider, Cluster Lifecycle, Etcd, Instrumentation, Network, Node, Scheduling, Storage and Testing]
- Updated CDI spec version selection to be dynamic, preventing the generation of incompatible CDI specifications. ([#137699](https://github.com/kubernetes/kubernetes/pull/137699), [@alaypatel07](https://github.com/alaypatel07)) [SIG Apps, Node, Scheduling and Testing]
- Updated Pod-level resource handling so that Pod resources determine QoS only when they include a resource request or limit. Empty Pod resources (`{}`, `{requests:{}}`, or `{limits:{}}`) no longer affect QoS calculation. ([#137150](https://github.com/kubernetes/kubernetes/pull/137150), [@KevinTMtz](https://github.com/KevinTMtz)) [SIG Apps, CLI, Node and Scheduling]
- Updated PodGroup and PodGroupTemplate to allow modifying `minCount` after creation. Changes to a PodGroupTemplate do not affect existing PodGroups. ([#139279](https://github.com/kubernetes/kubernetes/pull/139279), [@antekjb](https://github.com/antekjb)) [SIG API Machinery, Scheduling and Testing]
- Updated the Alpha `DRANodeAllocatableResources` feature:
  - ResourceSlice mappings and PodStatus support direct allocations, for DRA drivers modeling CPU, memory, and hugepages as a resource, and overhead allocations, for accelerator host overhead.
  - The `kubelet` accounts for DRA allocated resources when configuring Pod and container cgroups, OOM scores, and Memory QoS thresholds.
  - Standard resource requests and limits can be resized in place for Pods that use DRA claims.
  - The scheduler supports unreferenced Pod-level claims, enforces resource limits with DRA, and enforces claim sharing rules, allowing claim sharing across Pods for overhead allocations.
  - Validation enforces constraints for the updated API and uses node declared features to confirm that target nodes have the `NodeAllocatableDRA` feature gate enabled. ([#140009](https://github.com/kubernetes/kubernetes/pull/140009), [@pravk03](https://github.com/pravk03)) [SIG API Machinery, Apps, Auth, Autoscaling, Node, Scheduling and Testing]
- Updated the PodGroup API to replace `PodGroupTemplateRef` with `WorkloadRef`, a simpler and more direct way to reference the workload a PodGroup belongs to. ([#140080](https://github.com/kubernetes/kubernetes/pull/140080), [@dom4ha](https://github.com/dom4ha)) [SIG API Machinery, Apps, Etcd, Node, Scheduling and Testing]
- `client-go`: Removed nearly all `context.TODO` calls by introducing APIs where the caller passes in the context. Log calls use the logger provided by the caller when available. ([#129125](https://github.com/kubernetes/kubernetes/pull/129125), [@pohly](https://github.com/pohly)) [SIG API Machinery, Apps, Architecture, Auth, CLI, Cloud Provider, Instrumentation, Network, Node, Storage and Testing]
- `kubelet`: Added TLS support for gRPC container probes (behind a feature gate). ([#137762](https://github.com/kubernetes/kubernetes/pull/137762), [@amritansh1502](https://github.com/amritansh1502)) [SIG API Machinery, Apps, Node and Testing]

### Feature

- Added Beta support for compressed responses to `WatchList` requests. When a client sends `Accept-Encoding: gzip`, the API server returns a gzip compressed response. This behavior is enabled by default and can be disabled using the `WatchListCompression` feature gate. Regular `watch` requests are unaffected. ([#140140](https://github.com/kubernetes/kubernetes/pull/140140), [@p0lyn0mial](https://github.com/p0lyn0mial)) [SIG API Machinery]
- Added GROUP, SCOPE, VERSIONS, and CREATED AT columns to `kubectl get crd` output, alongside the existing NAME column.
  The new columns provide additional information about the Custom Resource Definitions (CRDs) in a more concise and organized manner, making it easier for users to understand the details of their CRDs at a glance. ([#131599](https://github.com/kubernetes/kubernetes/pull/131599), [@jaehanbyun](https://github.com/jaehanbyun)) [SIG API Machinery]
- Added PodGroup methods to `PodGroupManager` and `SharedLister`, allowing scheduler plugins to obtain a consistent PodGroup state. ([#140077](https://github.com/kubernetes/kubernetes/pull/140077), [@macsko](https://github.com/macsko)) [SIG Node, Scheduling and Testing]
- Added Prometheus metrics for Windows kube-proxy (winkernel) load balancer operation failures: `kubeproxy_sync_proxy_rules_winkernel_lb_create_failures_total`, `kubeproxy_sync_proxy_rules_winkernel_lb_update_failures_total`, and `kubeproxy_sync_proxy_rules_winkernel_lb_delete_failures_total`. Each metric includes `ip_family`, `lb_type`, and `error` labels for fine-grained failure observability. ([#137767](https://github.com/kubernetes/kubernetes/pull/137767), [@princepereira](https://github.com/princepereira)) [SIG Instrumentation, Network and Windows]
- Added ServiceName, PodManagementPolicy, and PersistentVolumeClaimRetentionPolicy to `kubectl describe statefulset` output. ([#137547](https://github.com/kubernetes/kubernetes/pull/137547), [@kfess](https://github.com/kfess)) [SIG CLI]
- Added `AnnotatedEventf` method to the new events API (`EventRecorder` and `EventRecorderLogger` interfaces in `client-go/tools/events`), enabling callers to attach custom annotations to events at creation time. ([#138103](https://github.com/kubernetes/kubernetes/pull/138103), [@adri1197](https://github.com/adri1197)) [SIG API Machinery and Node]
- Added `cpu_ids` and `memory` fields at the pod level to the `PodResources` v1 API to report total allocated pod resources, while only returning container-level allocations for container-isolated containers. ([#138738](https://github.com/kubernetes/kubernetes/pull/138738), [@KevinTMtz](https://github.com/KevinTMtz)) [SIG Node and Testing]
- Added `metrics.k8s.io/v1` support to `kubectl top`. ([#139726](https://github.com/kubernetes/kubernetes/pull/139726), [@tico88612](https://github.com/tico88612)) [SIG CLI and Instrumentation]
- Added `net.ipv4.tcp_slow_start_after_idle` and `net.ipv4.tcp_notsent_lowat` to the allowed safe sysctls list. ([#138389](https://github.com/kubernetes/kubernetes/pull/138389), [@gheffern](https://github.com/gheffern)) [SIG Auth, Network and Node]
- Added a `--max-depth` flag to `kubectl explain --recursive` to limit the depth of nested fields displayed in the output. ([#138809](https://github.com/kubernetes/kubernetes/pull/138809), [@shady0503](https://github.com/shady0503)) [SIG CLI and Testing]
- Added a warning when `kube-proxy` is started without an explicitly specified proxy mode (such as `iptables`, `ipvs`, or `nftables`), because the default mode on Linux will switch from `iptables` to `nftables` in a future release. ([#139957](https://github.com/kubernetes/kubernetes/pull/139957), [@danwinship](https://github.com/danwinship)) [SIG Network]
- Added an Alpha feature gate, `ConsistentListFromCacheSkipTimeoutFallback`. When enabled, `kube-apiserver` returns HTTP 429 for consistent LIST requests that cannot be served from the watch cache within the timeout window, instead of falling back to storage. ([#138701](https://github.com/kubernetes/kubernetes/pull/138701), [@yedou37](https://github.com/yedou37)) [SIG API Machinery]
- Added an `error` outcome to the `route_sync_total` metric for failed route reconciles, alongside the existing `changed` and `noop` outcomes. ([#140824](https://github.com/kubernetes/kubernetes/pull/140824), [@lukasmetzner](https://github.com/lukasmetzner)) [SIG Cloud Provider and Instrumentation]
- Added context-aware APIs to `client-go` for REST mapping and discovery, replacing internal blocking API calls that used `context.TODO`. Consumers of `client-go` are encouraged to switch to the new APIs. The old APIs are marked as deprecated, but there is no plan to remove them. ([#129109](https://github.com/kubernetes/kubernetes/pull/129109), [@pohly](https://github.com/pohly)) [SIG API Machinery, Apps, Auth, Instrumentation, Node and Testing]
- Added metric `apiserver_watch_cache_initialization_duration_seconds` recording the duration of the most recent watch cache initialization, labeled by group and resource. ([#138767](https://github.com/kubernetes/kubernetes/pull/138767), [@Jefftree](https://github.com/Jefftree)) [SIG API Machinery and Instrumentation]
- Added metrics for informer activity in `kube-apiserver`. ([#139968](https://github.com/kubernetes/kubernetes/pull/139968), [@michaelasp](https://github.com/michaelasp)) [SIG API Machinery and Testing]
- Added progress reporting to StorageVersionMigration conditions, allowing users to see how many objects a migration has processed. ([#138875](https://github.com/kubernetes/kubernetes/pull/138875), [@michaelasp](https://github.com/michaelasp)) [SIG API Machinery and Apps]
- Added scheduler metrics for the topology-aware scheduling (TAS) placement phases, available when the `TopologyAwareWorkloadScheduling` feature gate is enabled: `scheduler_generated_placements_total`, `scheduler_placement_evaluations_total`, and `scheduler_placement_evaluation_duration_seconds`. ([#139604](https://github.com/kubernetes/kubernetes/pull/139604), [@alimaazamat](https://github.com/alimaazamat)) [SIG Instrumentation, Scheduling and Testing]
- Added scheduler performance benchmark suites comparing preemption behavior across standalone (non-PodGroup) Pods and PodGroups with `single` and `all` disruption modes, and reorganized the default preemption performance tests into a dedicated directory. ([#140651](https://github.com/kubernetes/kubernetes/pull/140651), [@vshkrabkov](https://github.com/vshkrabkov)) [SIG Scheduling and Testing]
- Added structured `CauseType` values to PodDisruptionBudget-related eviction `Forbidden` errors in the eviction API, allowing clients to programmatically distinguish PDB invalid-state errors from other forbidden errors without string-matching on the message. ([#138003](https://github.com/kubernetes/kubernetes/pull/138003), [@shady0503](https://github.com/shady0503)) [SIG Apps, Auth and Node]
- Added support for CBOR encoding in discovery endpoints and structured error responses when the `CBORServingAndStorage` feature gate is enabled. ([#139632](https://github.com/kubernetes/kubernetes/pull/139632), [@benluddy](https://github.com/benluddy)) [SIG API Machinery and Testing]
- Added support for testing invariant metrics in integration tests. ([#137883](https://github.com/kubernetes/kubernetes/pull/137883), [@lalitc375](https://github.com/lalitc375)) [SIG API Machinery, Auth and Testing]
- Added support in `client-go` certificate manager `Config` for specifying a custom `GenerateKey` function. ([#138999](https://github.com/kubernetes/kubernetes/pull/138999), [@neolit123](https://github.com/neolit123)) [SIG API Machinery and Auth]
- Added the 90s, 120s, 180s, and 300s buckets to the `watch_list_duration_seconds` metric. ([#140757](https://github.com/kubernetes/kubernetes/pull/140757), [@richabanker](https://github.com/richabanker)) [SIG API Machinery and Instrumentation]
- Added the Alpha `apiserver_watch_events_dispatch_duration_seconds` metric, recording the duration from when a watch event is decoded from etcd until it is written to the watcher's outgoing result channel. ([#140336](https://github.com/kubernetes/kubernetes/pull/140336), [@richabanker](https://github.com/richabanker)) [SIG API Machinery, Etcd and Instrumentation]
- Added the Alpha `kubelet` metric `kubelet_pod_deferred_resize_duration_seconds` histogram and the `priority_bucket` label on the `kubelet_pod_pending_resizes` gauge. ([#140122](https://github.com/kubernetes/kubernetes/pull/140122), [@natasha41575](https://github.com/natasha41575)) [SIG Instrumentation and Node]
- Added the Alpha `kubelet` metric `pod_level_resources_admission_total` to track adoption of Pod-Level Resources (KEP-2837) upon Pod admission, categorized by resource configuration mode and QoS class. ([#140463](https://github.com/kubernetes/kubernetes/pull/140463), [@ndixita](https://github.com/ndixita)) [SIG Instrumentation and Node]
- Added the `+k8s:dependentRequired("siblingJSONName")` declarative validation tag. When the tagged field is set, the named sibling must also be set. ([#139164](https://github.com/kubernetes/kubernetes/pull/139164), [@yongruilin](https://github.com/yongruilin)) [SIG API Machinery]
- Added the `--proxy-url` flag to `kubectl` to override the proxy URL configured in the kubeconfig. ([#139862](https://github.com/kubernetes/kubernetes/pull/139862), [@Mujib-Ahasan](https://github.com/Mujib-Ahasan)) [SIG CLI]
- Added the `CompositePodGroup` feature gate to enable Composite Pod Group functionality. ([#139407](https://github.com/kubernetes/kubernetes/pull/139407), [@jdzikowski](https://github.com/jdzikowski)) [SIG Scheduling]
- Added the `EtcdRangeStream` beta feature gate. The watch cache initializes by streaming objects from etcd in a single `RangeStream` RPC instead of paginated `Range` requests. ([#136915](https://github.com/kubernetes/kubernetes/pull/136915), [@Jefftree](https://github.com/Jefftree)) [SIG API Machinery, Architecture, Auth, CLI, Cloud Provider, Cluster Lifecycle, Etcd, Instrumentation, Network, Node, Scheduling, Storage and Testing]
- Added the `KubeProxyIPVS` feature gate in preparation for deactivating and then removing the `ipvs` mode of `kube-proxy`. ([#139397](https://github.com/kubernetes/kubernetes/pull/139397), [@adrianmoisey](https://github.com/adrianmoisey)) [SIG Network]
- Added the `PodGroup` field to the `PodGroupInfo` object in `kube-scheduler` to enable plugins to obtain a consistent state throughout the scheduling cycle. ([#140075](https://github.com/kubernetes/kubernetes/pull/140075), [@macsko](https://github.com/macsko)) [SIG Scheduling]
- Added the `WatchListCompression` feature gate (Beta, enabled by default) to compress `WatchList` responses with gzip for clients that send `Accept-Encoding: gzip`. Regular `Watch` requests are unaffected. ([#139308](https://github.com/kubernetes/kubernetes/pull/139308), [@p0lyn0mial](https://github.com/p0lyn0mial)) [SIG API Machinery]
- Added the `allocatedPods` `kubelet` endpoint, which surfaces the `kubelet`'s allocated Pod spec for debugging in-place Pod resizing and other Pod update issues. Requires the `KubeletAllocatedPodsEndpoint` feature gate. ([#140856](https://github.com/kubernetes/kubernetes/pull/140856), [@tallclair](https://github.com/tallclair)) [SIG Node and Testing]
- Added the `cache_to_watcher` stage to the Alpha `apiserver_watch_events_dispatch_duration_seconds` metric to measure the latency incurred when pushing events to a watcher's result channel. ([#140851](https://github.com/kubernetes/kubernetes/pull/140851), [@richabanker](https://github.com/richabanker)) [SIG API Machinery and Instrumentation]
- Added the `client-go` informer metrics `informer_store_resource_version`, `informer_queued_items`, and `informer_processing_latency_seconds` to `kube-scheduler`, labelled `name="kube-scheduler"`. ([#140511](https://github.com/kubernetes/kubernetes/pull/140511), [@Jefftree](https://github.com/Jefftree)) [SIG Scheduling and Testing]
- Added the `incompletePodGroupPods` data structure to the scheduling queue to store Pods waiting for their PodGroup object to be observed by `kube-scheduler`. ([#139952](https://github.com/kubernetes/kubernetes/pull/139952), [@macsko](https://github.com/macsko)) [SIG Node, Scheduling and Testing]
- Added the `owner_api_group` and `owner_api_kind` labels to the `dynamic_resource_allocation_resourceclaim_creates_total` metric to distinguish ResourceClaims created for Pods from those created for PodGroups under the `DRAWorkloadResourceClaims` feature gate. ([#140422](https://github.com/kubernetes/kubernetes/pull/140422), [@nojnhuh](https://github.com/nojnhuh)) [SIG API Machinery, Apps, Instrumentation, Node, Scheduling and Testing]
- Added the `queued_entities` and `queue_incoming_entities_total` scheduler metrics. `queued_entities` reports the current number of scheduling entities (Pods or PodGroups) in scheduler queues, and `queue_incoming_entities_total` reports the total number of scheduling entities added to scheduler queues. ([#139840](https://github.com/kubernetes/kubernetes/pull/139840), [@iomarsayed](https://github.com/iomarsayed)) [SIG Instrumentation, Network and Scheduling]
- Added the `storage_to_cache` stage to the Alpha `apiserver_watch_events_dispatch_duration_seconds` metric to track the latency from backend decode to watch cache ingestion. ([#140860](https://github.com/kubernetes/kubernetes/pull/140860), [@richabanker](https://github.com/richabanker)) [SIG API Machinery and Instrumentation]
- Added the `trigger` (`periodic` or `node_change`) and `outcome` (`changed` or `noop`) labels to the Alpha route controller metric `route_controller_route_sync_total`. This lets operators observe how often periodic reconciliation corrects route drift versus running as a no-op. ([#140147](https://github.com/kubernetes/kubernetes/pull/140147), [@lukasmetzner](https://github.com/lukasmetzner)) [SIG Cloud Provider and Instrumentation]
- Added the scheduler extension point `PlacementFeasible` to allow early termination of the PodGroup scheduling cycle. This extension point is used by the GangScheduling plugin to stop evaluating pods once `minCount` becomes unsatisfiable. ([#138643](https://github.com/kubernetes/kubernetes/pull/138643), [@brejman](https://github.com/brejman)) [SIG Scheduling and Testing]
- Added the standard device attribute `resource.kubernetes.io/numaNode` and sysfs-based helper functions for DRA drivers. ([#139929](https://github.com/kubernetes/kubernetes/pull/139929), [@johnahull](https://github.com/johnahull)) [SIG Node]
- Added validation to PodGroup scheduling that, when the `PodGroupPreemptionPolicy` feature gate is enabled, ensures that the preemption policies of Pods being evaluated for scheduling match the priority of the PodGroup. ([#140359](https://github.com/kubernetes/kubernetes/pull/140359), [@ania-borowiec](https://github.com/ania-borowiec)) [SIG Scheduling and Testing]
- Added validation to PodGroup scheduling which ensures priorities of the evaluated pods match the priority of the PodGroup. ([#139920](https://github.com/kubernetes/kubernetes/pull/139920), [@brejman](https://github.com/brejman)) [SIG Scheduling and Testing]
- Added workload preemption metrics in Alpha behind the `WorkloadAwarePreemption` feature gate. ([#139373](https://github.com/kubernetes/kubernetes/pull/139373), [@brejman](https://github.com/brejman)) [SIG Instrumentation and Scheduling]
- Applied `--field-selector` to pod metrics when invoking `kubectl top pod`. ([#139107](https://github.com/kubernetes/kubernetes/pull/139107), [@Mujib-Ahasan](https://github.com/Mujib-Ahasan)) [SIG CLI]
- Changed PodGroup preemption to run after a failed PodGroup scheduling attempt for PodGroups with scheduling constraints. ([#140683](https://github.com/kubernetes/kubernetes/pull/140683), [@Argh4k](https://github.com/Argh4k)) [SIG API Machinery, Scheduling and Testing]
- Changed `kube-apiserver` with `--enable-aggregator-routing=true` to evenly load-balance requests across admission webhook endpoints, preventing connection caching from routing all concurrent requests to a single backend endpoint. Cluster administrators can temporarily opt out of this behavior using the `WebhookRoundTripLoadBalancing` feature gate (Beta, default true). ([#139237](https://github.com/kubernetes/kubernetes/pull/139237), [@aojea](https://github.com/aojea)) [SIG API Machinery and Testing]
- Changed the `PatchPodStatus` API in the scheduler framework to accept a slice of Pod conditions (`[]*v1.PodCondition`) instead of a single condition (`*v1.PodCondition`). This allows scheduler plugins to update multiple Pod conditions in a single API call, preventing newer calls from overwriting older ones when multiple conditions need to be updated concurrently. ([#135160](https://github.com/kubernetes/kubernetes/pull/135160), [@KunWuLuan](https://github.com/KunWuLuan)) [SIG Scheduling]
- Demoted the `SchedulerPreQueueingHints` feature gate from Beta to Alpha, disabled by default, because of issues found shortly before release. ([#140959](https://github.com/kubernetes/kubernetes/pull/140959), [@sanposhiho](https://github.com/sanposhiho)) [SIG Scheduling]
- Enabled scaling to and from zero by default for the HorizontalPodAutoscaler (HPA). ([#139648](https://github.com/kubernetes/kubernetes/pull/139648), [@johanneswuerbach](https://github.com/johanneswuerbach)) [SIG Apps, Autoscaling and Testing]
- Enabled the `EtcdRangeStream` feature gate by default and promoted it to Beta. ([#140085](https://github.com/kubernetes/kubernetes/pull/140085), [@Jefftree](https://github.com/Jefftree)) [SIG API Machinery]
- Enhanced Pod-by-Pod preemption to support PodGroups as preemption victims. ([#137981](https://github.com/kubernetes/kubernetes/pull/137981), [@vshkrabkov](https://github.com/vshkrabkov)) [SIG Scheduling and Testing]
- Updated pod group preemption errors to be prefixed with `pod group preemption:` message. ([#139218](https://github.com/kubernetes/kubernetes/pull/139218), [@Argh4k](https://github.com/Argh4k)) [SIG Scheduling]
- Functions and structs that take in `authorizer.Authorizer` might choose to accept only a smaller interface, `authorizer.UnconditionalAuthorizer`, in case only the receiver only needs to perform unconditional authorization requests and wants to signal this in the code for clarity. Any authorizer implementation must still implement the full `authorizer.Authorizer` interface. ([#138801](https://github.com/kubernetes/kubernetes/pull/138801), [@luxas](https://github.com/luxas)) [SIG API Machinery, Auth, Node, Scheduling and Testing]
- Graduated `WatchCacheInitializationPostStartHook` to GA. ([#139452](https://github.com/kubernetes/kubernetes/pull/139452), [@serathius](https://github.com/serathius)) [SIG API Machinery]
- Graduated the `ConcurrentWatchObjectDecode` feature gate to Beta, enabled by default. ([#139679](https://github.com/kubernetes/kubernetes/pull/139679), [@Jefftree](https://github.com/Jefftree)) [SIG API Machinery and Etcd]
- Graduated the `ManifestBasedAdmissionControlConfig` feature gate to Beta and enabled it by default. ([#140559](https://github.com/kubernetes/kubernetes/pull/140559), [@BenTheElder](https://github.com/BenTheElder)) [SIG API Machinery]
- Graduated the `NativeHistograms` feature gate to Beta. ([#140124](https://github.com/kubernetes/kubernetes/pull/140124), [@richabanker](https://github.com/richabanker)) [SIG Architecture and Instrumentation]
- Graduated the `RelaxedServiceNameValidation` feature gate to GA. ([#139282](https://github.com/kubernetes/kubernetes/pull/139282), [@adrianmoisey](https://github.com/adrianmoisey)) [SIG Apps and Network]
- Graduated the `scheduler_plugin_execution_duration_seconds` and `scheduler_scheduling_algorithm_duration_seconds` metrics from Alpha to Beta. ([#138176](https://github.com/kubernetes/kubernetes/pull/138176), [@abhay1999](https://github.com/abhay1999)) [SIG Instrumentation, Scheduling and Testing]
- Improved node health checks by verifying lease staleness with a live `GET` before marking nodes unhealthy, avoiding false positives from stale cache. ([#138698](https://github.com/kubernetes/kubernetes/pull/138698), [@michaelasp](https://github.com/michaelasp)) [SIG Apps, Auth and Node]
- Improved scheduling performance for required Pod affinity and anti-affinity with `topologyKey: kubernetes.io/hostname`, behind the `InterPodAffinityHostnameFastPath` feature gate. ([#138198](https://github.com/kubernetes/kubernetes/pull/138198), [@tetianakh](https://github.com/tetianakh)) [SIG Apps, Node, Scheduling and Testing]
- Made it possible for authorizers to return conditional decisions in addition to unconditional (Allow/Deny/NoOpinion). ([#137204](https://github.com/kubernetes/kubernetes/pull/137204), [@luxas](https://github.com/luxas)) [SIG API Machinery, Auth, Node, Scheduling and Testing]
- Optimized CEL admission policy evaluation by adopting a lazy zero-allocation reflection-based utility for object traversal, significantly reducing CPU usage and garbage collection overhead during request processing. ([#138771](https://github.com/kubernetes/kubernetes/pull/138771), [@lalitc375](https://github.com/lalitc375)) [SIG API Machinery, Architecture, Auth, CLI, Cloud Provider, Cluster Lifecycle, Network, Node, Scheduling and Storage]
- Optimized `kube-scheduler` performance for Pods with PersistentVolumeClaim mounts by processing only delta counts between scheduling cycles. ([#139238](https://github.com/kubernetes/kubernetes/pull/139238), [@yue9944882](https://github.com/yue9944882)) [SIG Scheduling and Testing]
- Preserved data in the DRA-related Pod status fields `resourceClaimStatuses`, `extendedResourceClaimStatus`, and `nodeAllocatableResourceClaimStatuses` when handling Pod status updates that omit those fields. This prevents updates from older clients from unsetting these DRA fields, which could leave Pods permanently stuck in Terminating. ([#139876](https://github.com/kubernetes/kubernetes/pull/139876), [@ashishpatel26](https://github.com/ashishpatel26)) [SIG API Machinery, Auth, Node, Scheduling and Testing]
- Promoted `serviceaccount_legacy_tokens_total`, `serviceaccount_stale_tokens_total` and `serviceaccount_valid_tokens_total` to Beta. ([#137072](https://github.com/kubernetes/kubernetes/pull/137072), [@tico88612](https://github.com/tico88612)) [SIG Auth, Instrumentation and Testing]
- Promoted support for `kubectl get -o kyaml` to Stable. ([#140076](https://github.com/kubernetes/kubernetes/pull/140076), [@soltysh](https://github.com/soltysh)) [SIG CLI]
- Promoted the `AllowUnsafeMalformedObjectDeletion` feature gate to Beta, enabled by default. List errors for objects that cannot be read from storage include the first underlying cause in the error message. ([#140785](https://github.com/kubernetes/kubernetes/pull/140785), [@ibihim](https://github.com/ibihim)) [SIG API Machinery and Etcd]
- Promoted the `DRAResourceClaimDeviceStatus` feature gate to GA. ([#137546](https://github.com/kubernetes/kubernetes/pull/137546), [@LionelJouin](https://github.com/LionelJouin)) [SIG Node and Testing]
- Promoted the `InPlacePodVerticalScalingInitContainers` feature gate to GA. ([#140728](https://github.com/kubernetes/kubernetes/pull/140728), [@natasha41575](https://github.com/natasha41575)) [SIG Apps and Node]
- Promoted the `PLEGOnDemandRelist` feature gate to GA. ([#140805](https://github.com/kubernetes/kubernetes/pull/140805), [@tallclair](https://github.com/tallclair)) [SIG Node]
- Promoted the `PodAndContainerStatsFromCRI` feature gate to Beta, disabled by default. ([#140081](https://github.com/kubernetes/kubernetes/pull/140081), [@dgrisonnet](https://github.com/dgrisonnet)) [SIG Node]
- Promoted the `PodLevelResourceManagers` feature gate to Beta, enabled by default. ([#140573](https://github.com/kubernetes/kubernetes/pull/140573), [@KevinTMtz](https://github.com/KevinTMtz)) [SIG Node and Testing]
- Promoted the `PodReadyToStartContainers` condition to GA. ([#140488](https://github.com/kubernetes/kubernetes/pull/140488), [@Priyankasaggu11929](https://github.com/Priyankasaggu11929)) [SIG Node and Testing]
- Promoted the `kube-apiserver` webhook metrics `apiserver_webhooks_x509_missing_san_total` and `apiserver_webhooks_x509_insecure_sha1_total` to Beta and updated their documentation. ([#136894](https://github.com/kubernetes/kubernetes/pull/136894), [@LoginovIlia](https://github.com/LoginovIlia)) [SIG API Machinery, Instrumentation and Testing]
- Promoted the `kubelet` PodsAPI gRPC service to Beta. ([#140286](https://github.com/kubernetes/kubernetes/pull/140286), [@briansonnenberg](https://github.com/briansonnenberg)) [SIG Instrumentation, Node and Testing]
- Reduced the scope of `EventedPLEG` to only accelerate detection of unexpected container terminations. ([#139262](https://github.com/kubernetes/kubernetes/pull/139262), [@HirazawaUi](https://github.com/HirazawaUi)) [SIG Node]
- Retried binding API calls in `kube-scheduler` when a transient error occurs. ([#138855](https://github.com/kubernetes/kubernetes/pull/138855), [@antekjb](https://github.com/antekjb)) [SIG Scheduling]
- Set the `KUBECTL_PATH` environment variable to the path of the `kubectl` binary when it executes a plugin. ([#138694](https://github.com/kubernetes/kubernetes/pull/138694), [@brianpursley](https://github.com/brianpursley)) [SIG CLI and Testing]
- Set the `nominatedNodeName` field on pods from a PodGroup after a successful PodGroup preemption, consistent with single-pod preemption. ([#138967](https://github.com/kubernetes/kubernetes/pull/138967), [@antekjb](https://github.com/antekjb)) [SIG Scheduling and Testing]
- The `MaxUnavailableStatefulSet` feature is enabled by default. ([#139466](https://github.com/kubernetes/kubernetes/pull/139466), [@soltysh](https://github.com/soltysh)) [SIG Apps]
- Updated the `apiserver_storage_list_*` metrics to include `storage` and `index` labels to distinguish the storage backend and lookup path used to serve LIST requests. ([#139125](https://github.com/kubernetes/kubernetes/pull/139125), [@yedou37](https://github.com/yedou37)) [SIG API Machinery, Etcd and Instrumentation]
- Updated the scheduler to avoid redundant preemption attempts during PodGroup scheduling when terminating victim pods are already present on the nominated nodes. ([#138710](https://github.com/kubernetes/kubernetes/pull/138710), [@mm4tt](https://github.com/mm4tt)) [SIG Scheduling]
- Added three different subtypes of the cluster event resource "Pod": "AssignedPod", "UnscheduledPod", "TargetPod". Plugins can and are expected to register to specific pod events for better performance. ([#135905](https://github.com/kubernetes/kubernetes/pull/135905), [@iomarsayed](https://github.com/iomarsayed)) [SIG Node, Scheduling, Storage and Testing]
- Updated CoreDNS to `v1.14.3`. ([#138536](https://github.com/kubernetes/kubernetes/pull/138536), [@yashsingh74](https://github.com/yashsingh74)) [SIG Cloud Provider and Cluster Lifecycle]
- Updated CoreDNS to `v1.14.4`. ([#139735](https://github.com/kubernetes/kubernetes/pull/139735), [@yashsingh74](https://github.com/yashsingh74)) [SIG Cloud Provider and Cluster Lifecycle]
- Updated CoreDNS to `v1.14.6`. ([#140497](https://github.com/kubernetes/kubernetes/pull/140497), [@yashsingh74](https://github.com/yashsingh74)) [SIG Cloud Provider and Cluster Lifecycle]
- Updated PodGroup scheduling to requeue remaining unscheduled Pods directly to the active queue (rather than backoff queue) after successful PodGroup scheduling, preserving their original timestamps so they retain scheduling precedence unless a higher priority entity is added. ([#139613](https://github.com/kubernetes/kubernetes/pull/139613), [@iomarsayed](https://github.com/iomarsayed)) [SIG Scheduling and Testing]
- Updated PodGroup scheduling to skip PostFilter plugins for Pods in a PodGroup cycle. Instead, `PodGroupPostFilter` runs only when the entire PodGroup is unschedulable. ([#140412](https://github.com/kubernetes/kubernetes/pull/140412), [@Argh4k](https://github.com/Argh4k)) [SIG Scheduling and Testing]
- Updated PodGroup status to include the `pod group preemption found a placement for podgroup, preempting <victim_count> victims` message when workload-aware preemption finds a placement. ([#140311](https://github.com/kubernetes/kubernetes/pull/140311), [@Argh4k](https://github.com/Argh4k)) [SIG Scheduling and Testing]
- Updated admission webhooks to skip auth/authz virtual resources, such as `tokenreviews` and `subjectaccessreviews`, that ValidatingAdmissionPolicy and MutatingAdmissionPolicy already exclude. Added the `ExcludeAdmissionWebhookVirtualResources` feature gate in Beta, enabled by default, with an opt-out option to restore the previous behavior. ([#140019](https://github.com/kubernetes/kubernetes/pull/140019), [@BenTheElder](https://github.com/BenTheElder)) [SIG API Machinery and Testing]
- Updated cri-tools to v1.36.0. ([#138613](https://github.com/kubernetes/kubernetes/pull/138613), [@saschagrunert](https://github.com/saschagrunert)) [SIG Cloud Provider and Node]
- Updated default preemption to include the message `preemption: found a potential placement for pod on node <node_name>, preempting <victim_count> victims` in the `FailedScheduling` event and `PodScheduled` condition when it finds a potential Node for a Pod. ([#140180](https://github.com/kubernetes/kubernetes/pull/140180), [@Argh4k](https://github.com/Argh4k)) [SIG Scheduling]
- Updated the Go version used to build Kubernetes to `v1.26.3`. ([#138864](https://github.com/kubernetes/kubernetes/pull/138864), [@BenTheElder](https://github.com/BenTheElder)) [SIG Release]
- Updated the Go version used to build Kubernetes to `v1.26.4`. ([#139479](https://github.com/kubernetes/kubernetes/pull/139479), [@BenTheElder](https://github.com/BenTheElder)) [SIG Release]
- Updated the Go version used to build Kubernetes to `v1.26.4`. ([#139584](https://github.com/kubernetes/kubernetes/pull/139584), [@cpanato](https://github.com/cpanato)) [SIG Release]
- Updated the Go version used to build Kubernetes to `v1.26.5`. ([#140576](https://github.com/kubernetes/kubernetes/pull/140576), [@palnabarun](https://github.com/palnabarun)) [SIG Release]
- Updated the Go version used to build Kubernetes to `v1.26.6`. ([#141363](https://github.com/kubernetes/kubernetes/pull/141363), [@BenTheElder](https://github.com/BenTheElder)) [SIG Release]
- Updated the `WorkloadAwarePreemption` feature to perform a single scheduling attempt with all potential victims removed. This significantly improves performance but can result in a less optimal choice of preemption victims. ([#139980](https://github.com/kubernetes/kubernetes/pull/139980), [@Argh4k](https://github.com/Argh4k)) [SIG Scheduling and Testing]
- Updated volume mount host path type mismatch errors to log the actual path type alongside the expected one. ([#121873](https://github.com/kubernetes/kubernetes/pull/121873), [@skitt](https://github.com/skitt)) [SIG Storage]
- Updated workload-aware preemption to preempt victims so that as many as possible of the preemptor pods can be scheduled. ([#138757](https://github.com/kubernetes/kubernetes/pull/138757), [@jdzikowski](https://github.com/jdzikowski)) [SIG Scheduling and Testing]
- `kube-controller-manager`: Deferred syncing an HPA object in the HPA controller when the controller has not yet observed HPA status writes from the last time the object was synced. ([#139025](https://github.com/kubernetes/kubernetes/pull/139025), [@omerap12](https://github.com/omerap12)) [SIG Apps and Autoscaling]
- `kube-scheduler`: Added `PlacementCycleState` to the scheduling framework, providing per-placement state to `PlacementScore` plugins under the Alpha `TopologyAwareWorkloadScheduling` feature gate. ([#138274](https://github.com/kubernetes/kubernetes/pull/138274), [@wtravO](https://github.com/wtravO)) [SIG Scheduling]
- `kube-scheduler`: Added support for PodGroups in the scheduling queue. The active, backoff, and unschedulable queues were abstracted to store `QueuedEntityInfo` (handling either individual pods or pod groups). ([#138567](https://github.com/kubernetes/kubernetes/pull/138567), [@macsko](https://github.com/macsko)) [SIG Instrumentation, Scheduling and Testing]
- `kubeadm`: Added the `kubeproxydaemonset` patch target to allow patching the kube-proxy DaemonSet during `kubeadm init` and `kubeadm upgrade`, consistent with the existing `corednsdeployment` patch target. ([#138090](https://github.com/kubernetes/kubernetes/pull/138090), [@SataQiu](https://github.com/SataQiu)) [SIG Cluster Lifecycle]
- `kubeadm`: Changed the preflight `Port-xx` checks for `kube-apiserver`, `kube-scheduler`, `kube-controller-manager`, and etcd to bind to the address configured in the kubeadm config for the respective component (via the `localAPIEndpoint.address` field or the `--bind-address` extraArgs override), instead of calling `net.Listen()` without an address (which binds to all available unicast and anycast IP addresses for the port). ([#138250](https://github.com/kubernetes/kubernetes/pull/138250), [@lentzi90](https://github.com/lentzi90)) [SIG Cluster Lifecycle]
- `kubeadm`: Removed the `NodeLocalCRISocket` feature gate which graduated to GA and was locked to enabled by default in a previous release. ([#138645](https://github.com/kubernetes/kubernetes/pull/138645), [@neolit123](https://github.com/neolit123)) [SIG Cluster Lifecycle]
- `kubeadm`: The preflight check `ContainerRuntimeVersion` validates if the installed container runtime supports the `RuntimeConfig` gRPC method. For older kubelet versions than `v1.38`, it will return a preflight warning. ([#139122](https://github.com/kubernetes/kubernetes/pull/139122), [@carlory](https://github.com/carlory)) [SIG Cluster Lifecycle]
- `kubelet`: Deferred the deprecation removal timeline for the configuration flags (and the related fallback behavior) from `v1.37` to `v1.38` to align with containerd `v1.7` support. ([#139121](https://github.com/kubernetes/kubernetes/pull/139121), [@carlory](https://github.com/carlory)) [SIG Node and Testing]

### Documentation

- Corrected the `kube-proxy` `--metrics-bind-address` flag documentation by removing the incorrect statement that setting the flag to an empty string disables the metrics server. ([#138940](https://github.com/kubernetes/kubernetes/pull/138940), [@kairosci](https://github.com/kairosci)) [SIG Network]
- Fixed a nil pointer dereference in `client-go` event key generation by adding nil checks in `getEventKey`, `getSpamKey`, and `EventAggregatorByReasonFunc`, preventing panics when processing nil events. ([#135925](https://github.com/kubernetes/kubernetes/pull/135925), [@jianzhangbjz](https://github.com/jianzhangbjz)) [SIG API Machinery]
- Updated Japanese translation for `kubectl`. ([#131176](https://github.com/kubernetes/kubernetes/pull/131176), [@yude](https://github.com/yude)) [SIG CLI and Testing]
- Updated `client-go` and `apimachinery` to track Go API changes in a `Go-API/CHANGELOG.md` file. ([#138351](https://github.com/kubernetes/kubernetes/pull/138351), [@pohly](https://github.com/pohly)) [SIG API Machinery]
- Updated the `kubectl explain` long description to fix formatting in the generated documentation and improve consistency with other commands. ([#140357](https://github.com/kubernetes/kubernetes/pull/140357), [@ingyeoking13](https://github.com/ingyeoking13)) [SIG CLI]

### Failing Test

- Fixed a bug in `kube-scheduler` when the `DRADeviceTaintRules` feature gate is enabled that could cause scheduler panics when DeviceTaintRules exist and ResourceSlices change, or cause new DeviceTaintRules changes to be ignored. ([#139651](https://github.com/kubernetes/kubernetes/pull/139651), [@nojnhuh](https://github.com/nojnhuh)) [SIG Node and Testing]
- Fixed a bug where nomination of a gated pod wasn't preventing lower-priority pods from scheduling on the nominated space. ([#139057](https://github.com/kubernetes/kubernetes/pull/139057), [@macsko](https://github.com/macsko)) [SIG Scheduling]

### Bug or Regression

- Added `apiserver_storage_list_duration_seconds`, a metric measuring end-to-end apiserver list latency (etcd read plus object decode), labelled by whether etcd RangeStream was used, so streamed and non-streamed lists can be compared directly. ([#140697](https://github.com/kubernetes/kubernetes/pull/140697), [@Jefftree](https://github.com/Jefftree)) [SIG API Machinery, Etcd and Instrumentation]
- Added the `HPAOptimizedSelectorStore` feature gate in Beta, enabled by default, to reduce lock contention in the HorizontalPodAutoscaler controller's selector overlap detection and improve reconciliation throughput at high HorizontalPodAutoscaler counts and concurrency. ([#139142](https://github.com/kubernetes/kubernetes/pull/139142), [@hakuna-matatah](https://github.com/hakuna-matatah)) [SIG Apps and Autoscaling]
- Added the group name to the `kubectl` error message when a resource type is not found under the specified group, for example `the server doesn't have a resource type "pdb" in group "hpa"`. ([#140759](https://github.com/kubernetes/kubernetes/pull/140759), [@makeittotop](https://github.com/makeittotop)) [SIG CLI]
- Avoided costly comparisons during SELinux metric emission. ([#138981](https://github.com/kubernetes/kubernetes/pull/138981), [@gnufied](https://github.com/gnufied)) [SIG Apps and Storage]
- Changed `client-go` `RetryWatcher` to log 410 Gone (resource expired) errors at debug verbosity (`V(4)`) instead of ERROR level during watch establishment. ([#138295](https://github.com/kubernetes/kubernetes/pull/138295), [@kencochrane](https://github.com/kencochrane)) [SIG API Machinery]
- Changed `kube-apiserver` to validate the `--advertise-address` IP when using `--endpoint-reconciler-type` `master-count` or `lease`, ensuring the specified IP address can be persisted to an Endpoints API object successfully. ([#138102](https://github.com/kubernetes/kubernetes/pull/138102), [@kairosci](https://github.com/kairosci)) [SIG API Machinery]
- Changed `kube-proxy` to skip full-sync operations when operating in large-cluster mode (more than 1000 endpoints). ([#138571](https://github.com/kubernetes/kubernetes/pull/138571), [@aojea](https://github.com/aojea)) [SIG Network]
- Changed `kube-proxy` to truncate nftables comments to the kernel's 128-byte limit before programming service maps, avoiding sync failures for long Service names. ([#139516](https://github.com/kubernetes/kubernetes/pull/139516), [@Vinayak9769](https://github.com/Vinayak9769)) [SIG Network]
- Changed `kubectl get` to return an error when `--label-columns` is used with custom-columns output. ([#138094](https://github.com/kubernetes/kubernetes/pull/138094), [@ahmadmaha02](https://github.com/ahmadmaha02)) [SIG CLI]
- Changed image volume validation to reject empty `image.reference` fields in Pod templates (Deployment, StatefulSet, DaemonSet, Job, etc.). ([#135989](https://github.com/kubernetes/kubernetes/pull/135989), [@Okabe-Junya](https://github.com/Okabe-Junya)) [SIG Apps and Node]
- Changed the HPA controller to reconcile newly created and spec-changed HPAs immediately instead of waiting for the full resync period (default 15s). ([#138294](https://github.com/kubernetes/kubernetes/pull/138294), [@Fedosin](https://github.com/Fedosin)) [SIG Apps and Autoscaling]
- Changed the `kubelet` to enforce explicit HTTP method restrictions for logs-related endpoints. Read-only `kubelet` server endpoints reject non-GET methods with 405. NodeLogQuery allows only GET and POST and rejects other methods with 405. ([#138088](https://github.com/kubernetes/kubernetes/pull/138088), [@amritansh1502](https://github.com/amritansh1502)) [SIG Node]
- DRA: Fixed a bug where a rare missed informer update of a ResourceClaim could cause Pods to remain pending until the unschedulable queue was flushed. ([#140831](https://github.com/kubernetes/kubernetes/pull/140831), [@pohly](https://github.com/pohly)) [SIG Node and Scheduling]
- Disabled the `PodLevelResourceManagers` feature gate by default because of critical issues found before release. ([#141209](https://github.com/kubernetes/kubernetes/pull/141209), [@SergeyKanzhelev](https://github.com/SergeyKanzhelev)) [SIG Node]
- Enabled evaluation of list-type attributes, the `.includes` function, and CEL macros in `kube-scheduler` even when the `ListTypeAttributes` feature gate is disabled. This prevents errors during rolling upgrades or when the feature gate is toggled. ([#139395](https://github.com/kubernetes/kubernetes/pull/139395), [@everpeace](https://github.com/everpeace)) [SIG Node]
- Enabled netlink support by default in `kube-proxy` nftables mode. `kube-proxy` uses netlink directly to list rules and chains, improving performance by avoiding running and parsing the `nft` command-line binary. The `NFTablesNetlink` feature gate (Beta, enabled by default) can be disabled to restore the previous behavior. ([#137536](https://github.com/kubernetes/kubernetes/pull/137536), [@aojea](https://github.com/aojea)) [SIG Network and Testing]
- Fixed 409 Conflict errors between the PVC protection controller and the PV binder during initial PVC binding. The `Unused` condition is evaluated only after the PersistentVolumeClaim is bound. ([#140833](https://github.com/kubernetes/kubernetes/pull/140833), [@huww98](https://github.com/huww98)) [SIG Apps and Storage]
- Fixed CEL behavior for `set` and `map` lists. Equality (`==`) no longer matches lists containing duplicates, and concatenation (`+`) correctly applies set and map merge semantics to appended elements. ([#140293](https://github.com/kubernetes/kubernetes/pull/140293), [@jpbetz](https://github.com/jpbetz)) [SIG API Machinery]
- Fixed DRA scheduling bugs where the structured allocator incorrectly counted a device's shared counters while evaluating candidates. It could retain a counter reservation after rejecting or backtracking from a candidate, or clear a shared device's in-use marker, causing a later allocation to charge the counter twice. These issues could cause the allocator to incorrectly treat a counter set as exhausted and leave a Pod pending on a node that could satisfy its resource requirements. This affected the allocator used by the default feature configuration. ([#140431](https://github.com/kubernetes/kubernetes/pull/140431), [@thc1006](https://github.com/thc1006)) [SIG Node]
- Fixed Pod-level MemoryQoS memory protection (`memory.min` and `memory.low`) being silently dropped during in-place Pod resize, and added Pod-level `memory.high` enforcement when the `PodLevelResources` feature gate is enabled. ([#140262](https://github.com/kubernetes/kubernetes/pull/140262), [@sohankunkerkar](https://github.com/sohankunkerkar)) [SIG Node and Testing]
- Fixed VolumeAttachment validation to report the correct maximum message size (1024 bytes) in error messages. ([#136436](https://github.com/kubernetes/kubernetes/pull/136436), [@Okabe-Junya](https://github.com/Okabe-Junya)) [SIG Storage]
- Fixed Windows CPU affinity so that, when the CPU Manager `static` policy and the Memory Manager are both active under the `WindowsCPUAndMemoryAffinity` feature gate, containers are pinned to the CPU Manager's allocated set instead of the union of that set and every CPU on the selected NUMA node. The previous behavior could overlap CPUs exclusively allocated to other containers. ([#139684](https://github.com/kubernetes/kubernetes/pull/139684), [@zylxjtu](https://github.com/zylxjtu)) [SIG Node]
- Fixed `DecodeMetadataFromStream` to skip only entries with unknown API versions and return errors for decode failures or malformed metadata in supported versions, preventing silent data loss. ([#138530](https://github.com/kubernetes/kubernetes/pull/138530), [@alaypatel07](https://github.com/alaypatel07)) [SIG Node]
- Fixed `kube-apiserver` hanging indefinitely on `SIGTERM` when it could not create its identity Lease, for example, because the hostname exceeded 63 bytes. ([#140241](https://github.com/kubernetes/kubernetes/pull/140241), [@camilamacedo86](https://github.com/camilamacedo86)) [SIG API Machinery]
- Fixed `kube-proxy` to remove stale conntrack entries when a UDP Service no longer has any serving endpoints, for example after scaling to zero. This prevents previously established one-way UDP flows from being indefinitely blackholed to deleted Pod IPs. ([#139629](https://github.com/kubernetes/kubernetes/pull/139629), [@Bafff](https://github.com/Bafff)) [SIG Network]
- Fixed `kubectl cluster-info dump --output-directory` creating world-readable dump files. Files are created with mode 0600 and `kubectl`-created directories with mode 0700, because dumped Pod logs can contain sensitive data. ([#140189](https://github.com/kubernetes/kubernetes/pull/140189), [@ashvinctrl](https://github.com/ashvinctrl)) [SIG CLI and Security]
- Fixed `kubectl get storageclass` to show only the effective default StorageClass as "(default)" when multiple StorageClasses have the default annotation. ([#135964](https://github.com/kubernetes/kubernetes/pull/135964), [@jaehanbyun](https://github.com/jaehanbyun)) [SIG CLI and Storage]
- Fixed `kubelet` applying device health updates to the wrong Pod status when device plugins for different resources exposed devices with identical IDs. Affected Pods reflect device health changes immediately instead of waiting for the next periodic Pod sync. ([#140323](https://github.com/kubernetes/kubernetes/pull/140323), [@harche](https://github.com/harche)) [SIG Node]
- Fixed `kubelet` failure starting on ZFS due to missing `cadvisor` plugin. ([#138587](https://github.com/kubernetes/kubernetes/pull/138587), [@BenTheElder](https://github.com/BenTheElder)) [SIG Node]
- Fixed a DRA consumable-capacity scheduling bug where a device that consumes shared counters could have them counted twice when it already had a persisted shared allocation with no consumed capacity, wrongly rejecting a later claim for the same device and leaving the Pod pending. ([#140437](https://github.com/kubernetes/kubernetes/pull/140437), [@thc1006](https://github.com/thc1006)) [SIG Node and Scheduling]
- Fixed a DRA issue where drivers might not recreate ResourceSlices that were deleted externally, depending on timing between driver updates and deletions. ([#140063](https://github.com/kubernetes/kubernetes/pull/140063), [@pohly](https://github.com/pohly)) [SIG API Machinery, Apps, Node and Testing]
- Fixed a DRA partitionable devices issue where counters published by a DRA driver outside the valid `int64` range could be mutated in the informer cache, causing future Pod allocations to fail incorrectly. ([#140518](https://github.com/kubernetes/kubernetes/pull/140518), [@weizhoublue](https://github.com/weizhoublue)) [SIG Node]
- Fixed a DRA scheduling bug where the structured allocator keyed shared-counter caches by pool name only, causing two drivers with the same pool name on a node to use each other's counter definitions and incorrectly accept or reject device allocations in the second driver's pool. ([#140435](https://github.com/kubernetes/kubernetes/pull/140435), [@thc1006](https://github.com/thc1006)) [SIG Node]
- Fixed a Dynamic Resource Allocation (DRA) scheduler bug that could assign mutually exclusive device partitions to multiple Pods. This affected DRA drivers using `SharedCounters` (`DRAPartitionableDevices`) together with multi-allocatable devices (`DRAConsumableCapacity`). Depending on the device and driver, the incorrect double-allocation could cause workload failures, device conflicts, crashes, or data loss. ([#139040](https://github.com/kubernetes/kubernetes/pull/139040), [@ashvindeodhar](https://github.com/ashvindeodhar)) [SIG Node]
- Fixed a `kube-proxy` IPVS-mode performance bug where `syncProxyRules` could take tens of seconds in clusters with many Services because `GetAllLocalAddressesExcept` issued one full netlink address dump per interface. The function issues a single dump per address family, reducing `syncProxyRules` latency by orders of magnitude on large clusters. ([#138927](https://github.com/kubernetes/kubernetes/pull/138927), [@ytcisme](https://github.com/ytcisme)) [SIG Network]
- Fixed a `kube-proxy` issue on Windows where transient HNS downtime during restart or recovery could cause incorrect LoadBalancer state reconciliation, resulting in duplicate LoadBalancer creation failures with `Cannot create a file when that file already exists. (0xb7)` errors. ([#139503](https://github.com/kubernetes/kubernetes/pull/139503), [@princepereira](https://github.com/princepereira)) [SIG Network and Windows]
- Fixed a `kubelet` bug where init containers could be skipped when a Pod sandbox was recreated while a main container from the previous sandbox was still known to the container runtime. ([#138514](https://github.com/kubernetes/kubernetes/pull/138514), [@chez-shanpu](https://github.com/chez-shanpu)) [SIG Node]
- Fixed a `kubelet` issue where Pods with `subPath` mounts could become stuck in an error loop after FUSE or GlusterFS network filesystem disruptions. ([#139275](https://github.com/kubernetes/kubernetes/pull/139275), [@yuehaii](https://github.com/yuehaii)) [SIG Node, Storage and Testing]
- Fixed a `kubelet` memory leak regression in `v1.36` caused by leaked contexts on every Pod sync. ([#139850](https://github.com/kubernetes/kubernetes/pull/139850), [@compumike](https://github.com/compumike)) [SIG Node]
- Fixed a `kubelet` panic in image pull credential verification when `maxParallelImagePulls` is configured above 31. ([#138937](https://github.com/kubernetes/kubernetes/pull/138937), [@RajvardhanPatil07](https://github.com/RajvardhanPatil07)) [SIG Node]
- Fixed a `v1.33` regression that could cause a panic in the endpoint controller when processing services with empty IPFamilies field (pre-dual-stack services that were never spec-updated). ([#138736](https://github.com/kubernetes/kubernetes/pull/138736), [@rahulbabu95](https://github.com/rahulbabu95)) [SIG Apps and Network]
- Fixed a `v1.35` regression where exec readiness probes stopped executing (failing with "context canceled") once a pod began graceful termination, leaving the pod's Ready condition frozen during shutdown. ([#140882](https://github.com/kubernetes/kubernetes/pull/140882), [@karlkfi](https://github.com/karlkfi)) [SIG Node]
- Fixed a bug in CEL where `quantity.Add` mutated the receiver. ([#140556](https://github.com/kubernetes/kubernetes/pull/140556), [@jpbetz](https://github.com/jpbetz)) [SIG API Machinery]
- Fixed a bug in ImageLocality scoring where image volumes could receive a higher score than equivalent regular container images. ([#138951](https://github.com/kubernetes/kubernetes/pull/138951), [@sujoshua](https://github.com/sujoshua)) [SIG Scheduling]
- Fixed a bug in `kube-apiserver` where a request matching multiple ValidatingAdmissionPolicy bindings with audit actions only recorded the first validation failure in the audit annotation; all audit failures are published in a single annotation. ([#140001](https://github.com/kubernetes/kubernetes/pull/140001), [@lalitc375](https://github.com/lalitc375)) [SIG API Machinery]
- Fixed a bug in the DRA `kubelet` plugin helper where drivers with names longer than ~30 characters could not enable rolling updates because the plugin registration socket path exceeded the `AF_UNIX` path length limit. Rolling-update registration sockets pick the shortest basename that fits under the configured registry directory, preferring `<driver>-<Pod UID>-reg.sock`, then `<driver>-<hashed UID>-reg.sock`, then `dra-<hashed driver+UID>-reg.sock`. ([#139623](https://github.com/kubernetes/kubernetes/pull/139623), [@vishalanarase](https://github.com/vishalanarase)) [SIG Node and Testing]
- Fixed a bug that caused Pods in a PodGroup sharing a ResourceClaim to get stuck scheduling. ([#140269](https://github.com/kubernetes/kubernetes/pull/140269), [@nojnhuh](https://github.com/nojnhuh)) [SIG Node, Scheduling and Testing]
- Fixed a bug that could cause the admission controller to panic when evaluating CEL expressions against typed map lists with three keys. ([#140386](https://github.com/kubernetes/kubernetes/pull/140386), [@weizhoublue](https://github.com/weizhoublue)) [SIG API Machinery]
- Fixed a bug when the `GenericWorkload` feature gate is enabled that could prevent Pods in the same PodGroup sharing the same ResourceClaim from successfully scheduling. ([#139418](https://github.com/kubernetes/kubernetes/pull/139418), [@nojnhuh](https://github.com/nojnhuh)) [SIG Node and Scheduling]
- Fixed a bug where Burstable Pod `memory.low` soft protection was ineffective because the parent cgroup lacked the ancestor coverage required by the kernel's hierarchical protection model. ([#140267](https://github.com/kubernetes/kubernetes/pull/140267), [@sohankunkerkar](https://github.com/sohankunkerkar)) [SIG Node and Testing]
- Fixed a bug where Pod `.status.resourceClaimStatuses` could flap between partial lists of claims when multiple claims were used in the Pod. ([#138408](https://github.com/kubernetes/kubernetes/pull/138408), [@johnbelamaric](https://github.com/johnbelamaric)) [SIG Apps and Node]
- Fixed a bug where Pods in a PodGroup sharing a ResourceClaim could be scheduled to Nodes where the ResourceClaim is not available. ([#140089](https://github.com/kubernetes/kubernetes/pull/140089), [@nojnhuh](https://github.com/nojnhuh)) [SIG Node, Scheduling and Testing]
- Fixed a bug where Pods that share multi-node claims and also have per-node claims can get stuck in Pending. ([#139017](https://github.com/kubernetes/kubernetes/pull/139017), [@johnbelamaric](https://github.com/johnbelamaric)) [SIG Node and Scheduling]
- Fixed a bug where ResourceClaims using `allocationMode: All` with consumable capacity could be partially allocated when a matching device had insufficient remaining capacity. Such claims correctly fail to allocate until all matching devices can be satisfied. ([#140769](https://github.com/kubernetes/kubernetes/pull/140769), [@kiarashazarnia](https://github.com/kiarashazarnia)) [SIG Node]
- Fixed a bug where ValidatingAdmissionPolicy and MutatingAdmissionPolicy evaluation could observe subtle differences (particularly around quantity fields and type meta fields) in object representation. The bug could occur when a parameter object was loaded via an alternative path, due to a cache miss. CEL expressions behave deterministically against params. ([#140201](https://github.com/kubernetes/kubernetes/pull/140201), [@jpbetz](https://github.com/jpbetz)) [SIG API Machinery]
- Fixed a bug where `kubectl drain --disable-eviction --dry-run=server` hangs indefinitely. ([#137543](https://github.com/kubernetes/kubernetes/pull/137543), [@kfess](https://github.com/kfess)) [SIG CLI and Testing]
- Fixed a bug where a StatefulSet with the `OnDelete` update strategy never updated `Status.CurrentRevision` to match `Status.UpdateRevision` after all Pods were recreated with the new revision. ([#136833](https://github.com/kubernetes/kubernetes/pull/136833), [@zhijun42](https://github.com/zhijun42)) [SIG Apps]
- Fixed a bug where disabling the `MemoryQoS` feature gate did not clear per-container `memory.high` cgroup values, causing containers to remain throttled at stale limits. ([#139377](https://github.com/kubernetes/kubernetes/pull/139377), [@sohankunkerkar](https://github.com/sohankunkerkar)) [SIG Node and Testing]
- Fixed a bug where enabling the `DRAListTypeAttributes` feature gate could prevent device allocation even when a valid combination existed. This occurred when the allocator needed to backtrack while allocating multiple devices with a `matchAttribute` constraint using list-type attribute values. ([#140325](https://github.com/kubernetes/kubernetes/pull/140325), [@everpeace](https://github.com/everpeace)) [SIG Node and Scheduling]
- Fixed a bug where kubelet would generate an event once per second for every image volume in a pod. ([#138655](https://github.com/kubernetes/kubernetes/pull/138655), [@mdbooth](https://github.com/mdbooth)) [SIG Node]
- Fixed a bug where non-admitted Pods could briefly count against the allocated budget, causing spurious admission failures for reasonably sized Pods. ([#139522](https://github.com/kubernetes/kubernetes/pull/139522), [@haircommander](https://github.com/haircommander)) [SIG Node]
- Fixed a bug where pods with multiple subPath volume mounts on Windows would get stuck in Terminating state because file handles from subPath preparation were leaked, preventing volume cleanup. ([#138367](https://github.com/kubernetes/kubernetes/pull/138367), [@timmy-wright](https://github.com/timmy-wright)) [SIG Node, Testing and Windows]
- Fixed a bug where successfully scheduled Pods could be stuck with the `PodScheduled=False` condition. ([#139602](https://github.com/kubernetes/kubernetes/pull/139602), [@nojnhuh](https://github.com/nojnhuh)) [SIG Node and Scheduling]
- Fixed a bug where the `kubelet` node shutdown manager could leak D-Bus connections on repeated failures, eventually leading to thread exhaustion and crashes. ([#137141](https://github.com/kubernetes/kubernetes/pull/137141), [@harche](https://github.com/harche)) [SIG Node]
- Fixed a bug where the kubelet did not enforce per-container ephemeral-storage limits on restartable init containers (sidecar containers), allowing them to exceed their declared limit without triggering pod eviction. ([#138462](https://github.com/kubernetes/kubernetes/pull/138462), [@shachartal](https://github.com/shachartal)) [SIG Node and Testing]
- Fixed a case where Pods in a PodGroup that were successfully evaluated during a failed PodGroup scheduling cycle had `nominatedNodeName` set from that evaluation instead of from PodGroup preemption. ([#140590](https://github.com/kubernetes/kubernetes/pull/140590), [@Argh4k](https://github.com/Argh4k)) [SIG Scheduling]
- Fixed a concurrent map read/write data race in `handleSchedulingFailure` during scheduling failure handling. ([#140623](https://github.com/kubernetes/kubernetes/pull/140623), [@SparshGarg999](https://github.com/SparshGarg999)) [SIG Scheduling]
- Fixed a kube-scheduler panic when a DRA ResourceClaim using `allocationMode: All` selects a device that consumes shared counters. ([#138885](https://github.com/kubernetes/kubernetes/pull/138885), [@takonomura](https://github.com/takonomura)) [SIG Node]
- Fixed a metrics leak in the scheduler `PriorityQueue` by decrementing `UnschedulableReason` metrics when Pods were deleted from active or backoff queues, ensuring accurate reporting of unschedulable plugin reasons. ([#138482](https://github.com/kubernetes/kubernetes/pull/138482), [@vshkrabkov](https://github.com/vshkrabkov)) [SIG Scheduling]
- Fixed a panic caused by integer division by zero and incorrect ResourceSlice admission validation when a DRA consumable capacity `validRange` `step`, `min`, `max`, or `default` value is negative or greater than 9223372036854775807. ([#140666](https://github.com/kubernetes/kubernetes/pull/140666), [@thc1006](https://github.com/thc1006)) [SIG Node]
- Fixed a panic in ResourceSlice validation that could occur when the `DRAConsumableCapacity` feature gate was enabled and a capacity request policy set `validRange.step` to 0. ([#139698](https://github.com/kubernetes/kubernetes/pull/139698), [@wilmerdooley](https://github.com/wilmerdooley)) [SIG Node]
- Fixed a panic in `kube-controller-manager` that could occur when a StorageVersionMigration targeted a resource missing from the RESTMapper, for example, when a CRD was deleted while its migration was pending. ([#140586](https://github.com/kubernetes/kubernetes/pull/140586), [@zwindler](https://github.com/zwindler)) [SIG API Machinery and Apps]
- Fixed a race condition in preemption, where a preemptor pod could get stuck in unschedulable state. ([#139162](https://github.com/kubernetes/kubernetes/pull/139162), [@brejman](https://github.com/brejman)) [SIG Scheduling and Testing]
- Fixed a race in `kubelet` where `PrepareResources` could attach a Pod to a ResourceClaim that was concurrently being unprepared, leaving the Pod running with unprepared devices. ([#140527](https://github.com/kubernetes/kubernetes/pull/140527), [@bart0sh](https://github.com/bart0sh)) [SIG Node]
- Fixed a regression in Kubernetes `v1.35` where, with a Parallel Pod management policy, unavailable Pods from an older revision were incorrectly counted toward the `maxUnavailable` budget. ([#137666](https://github.com/kubernetes/kubernetes/pull/137666), [@soltysh](https://github.com/soltysh)) [SIG Apps]
- Fixed a regression in Server-Side Apply where patching a container type (list or map) could return `422 required` errors for apply requests that previously succeeded. ([#140294](https://github.com/kubernetes/kubernetes/pull/140294), [@jpbetz](https://github.com/jpbetz)) [SIG API Machinery, Architecture, Auth, CLI, Cloud Provider, Cluster Lifecycle, Instrumentation, Network, Node, Scheduling, Storage and Testing]
- Fixed a regression in `v1.36` where modifications to scheduling directives (`nodeSelector`, `tolerations`, `nodeAffinity`) on suspended Jobs were rejected if the `JobSuspended` condition had not yet been set by the job controller. ([#139287](https://github.com/kubernetes/kubernetes/pull/139287), [@kannon92](https://github.com/kannon92)) [SIG Apps and Testing]
- Fixed a regression in retrying deferred resizes caused by changes to Pod resource footprint calculation. ([#140646](https://github.com/kubernetes/kubernetes/pull/140646), [@natasha41575](https://github.com/natasha41575)) [SIG Node and Scheduling]
- Fixed a regression where the Job controller could report `status.active` as 0 while replacement Pod creation was deferred due to pod-failure backoff, causing the Job status update to be rejected by `kube-apiserver`. This could delay flushing uncounted terminated Pods, finalizer removal, and Job status updates, leaving Pods stuck in `Terminating` and the Job with stale status until the backoff elapsed. ([#139457](https://github.com/kubernetes/kubernetes/pull/139457), [@akhilsingh-git](https://github.com/akhilsingh-git)) [SIG Apps]
- Fixed a regression where the `kubelet` did not clear stale cgroup v2 `memory.min` and `memory.low` values when the `MemoryQoS` feature gate was disabled after being previously enabled. ([#138903](https://github.com/kubernetes/kubernetes/pull/138903), [@sohankunkerkar](https://github.com/sohankunkerkar)) [SIG Node and Testing]
- Fixed a scheduler bug in DRA consumable capacity where a ResourceSlice with a device capacity requirement stored as a high-precision decimal, such as a fine-grained fractional value or a value above the int64 range, could be mutated in the informer cache during allocation. This mutation could incorrectly cause allocation to fail for subsequent Pods. ([#140702](https://github.com/kubernetes/kubernetes/pull/140702), [@weizhoublue](https://github.com/weizhoublue)) [SIG Node]
- Fixed a scheduler bug where clearing `NominatedNodeName` could leave Pods tracked under an empty node key in the scheduler's nominator. ([#139904](https://github.com/kubernetes/kubernetes/pull/139904), [@pacoxu](https://github.com/pacoxu)) [SIG Scheduling]
- Fixed a scheduler cache bug where assumed Pods were not removed correctly from `PodGroupState` after receiving a deletion timestamp. ([#138445](https://github.com/kubernetes/kubernetes/pull/138445), [@iomarsayed](https://github.com/iomarsayed)) [SIG Scheduling]
- Fixed admission handling so that updates to namespaced objects that still exist after their namespace was deleted are allowed. ([#140661](https://github.com/kubernetes/kubernetes/pull/140661), [@sanchezl](https://github.com/sanchezl)) [SIG API Machinery and Testing]
- Fixed an issue in the CronJob controller where it failed to adopt existing Jobs by erroneously using the empty namespace from the `jobTemplate`. ([#136920](https://github.com/kubernetes/kubernetes/pull/136920), [@ysam12345](https://github.com/ysam12345)) [SIG Apps]
- Fixed an issue that could cause duplicate configuration entries to be reported in ResourceClaim status. ([#139732](https://github.com/kubernetes/kubernetes/pull/139732), [@LionelJouin](https://github.com/LionelJouin)) [SIG Node]
- Fixed an issue where PodGroup preemption that detected an ongoing preemption would clear `nominatedNodeName` on the PodGroup's Pods. ([#140641](https://github.com/kubernetes/kubernetes/pull/140641), [@Argh4k](https://github.com/Argh4k)) [SIG Scheduling and Testing]
- Fixed an issue where the StatefulSet controller's skip metrics were not properly registered. ([#138451](https://github.com/kubernetes/kubernetes/pull/138451), [@michaelasp](https://github.com/michaelasp)) [SIG API Machinery, Apps and Testing]
- Fixed an issue where the `kubelet` would delete the CSI mount directory when a periodic `NodePublishVolume` call (triggered by setting `CSIDriver.spec.requiresRepublish` to true) returned an error, leaving the Pod with stale volume contents that subsequent successful republishes could not repair. ([#139045](https://github.com/kubernetes/kubernetes/pull/139045), [@aramase](https://github.com/aramase)) [SIG Storage]
- Fixed audit logging of malformed patch request bodies. ([#139419](https://github.com/kubernetes/kubernetes/pull/139419), [@hoskeri](https://github.com/hoskeri)) [SIG API Machinery, Auth and Testing]
- Fixed capacity accounting in the DRA consumable-capacity allocator. A capacity request that a device's integer or milli-value range arithmetic cannot represent, or that resolves to a negative value, is rejected instead of being treated as satisfiable and wrongly allocating a device or capping it to a smaller value. ([#140442](https://github.com/kubernetes/kubernetes/pull/140442), [@thc1006](https://github.com/thc1006)) [SIG Node]
- Fixed duplicate logs when trying to attach to a pod fails. ([#139091](https://github.com/kubernetes/kubernetes/pull/139091), [@olamilekan000](https://github.com/olamilekan000)) [SIG CLI]
- Fixed duplicated mount arguments in log string output from `MakeMountArgsSensitiveWithMountFlags`. ([#138098](https://github.com/kubernetes/kubernetes/pull/138098), [@jeffbearer](https://github.com/jeffbearer)) [SIG Storage]
- Fixed handling of a certificate authority path outside the `.kube/config` directory on Windows, which was converted to a relative path instead of matching the behavior on other operating systems. ([#135735](https://github.com/kubernetes/kubernetes/pull/135735), [@bliles](https://github.com/bliles)) [SIG API Machinery]
- Fixed inconsistent `ephemeral-storage` formatting between capacity and allocatable values in Node status by using the `DecimalSI` format for `ephemeral-storage` capacity. ([#137652](https://github.com/kubernetes/kubernetes/pull/137652), [@0xMH](https://github.com/0xMH)) [SIG Node]
- Fixed incorrect error message formatting in the HPA controller when object metric retrieval fails. Error messages correctly display the metric name, object kind, namespace, object name, and the underlying error. Also improved error wrapping across the HPA controller to use `%w` instead of `%v`, enabling proper error chain inspection. ([#139029](https://github.com/kubernetes/kubernetes/pull/139029), [@Fedosin](https://github.com/Fedosin)) [SIG Apps and Autoscaling]
- Fixed inter-pod affinity, anti-affinity, and volume restriction evaluation in `kube-scheduler` during PodGroup scheduling cycles. The scheduler snapshot's `AssumePod` and `ForgetPod` methods correctly maintain affinity node lists and PVC usage tracking. ([#139054](https://github.com/kubernetes/kubernetes/pull/139054), [@net0pyr](https://github.com/net0pyr)) [SIG Scheduling and Testing]
- Fixed nil pointer dereference in Windows memory eviction threshold notifier when `GetPerformanceInfo()` fails. ([#138727](https://github.com/kubernetes/kubernetes/pull/138727), [@rzlink](https://github.com/rzlink)) [SIG Node]
- Fixed queue hint for inter-pod anti-affinity in case there are multiple terms, which might have caused delays in scheduling. ([#139161](https://github.com/kubernetes/kubernetes/pull/139161), [@brejman](https://github.com/brejman)) [SIG Scheduling]
- Fixed regression in `kubectl` resource printing on bigger data sets (100+ rows). ([#138550](https://github.com/kubernetes/kubernetes/pull/138550), [@rawkode](https://github.com/rawkode)) [SIG CLI]
- Fixed stale remote HNS endpoint cleanup on Windows when a pod IP is reused across nodes in L2Bridge networks, preventing DNS timeouts caused by traffic being routed to the wrong node. ([#138000](https://github.com/kubernetes/kubernetes/pull/138000), [@princepereira](https://github.com/princepereira)) [SIG Network and Windows]
- Fixed the DRA `kubelet` plugin helper repeating the listen error instead of reporting why removing a stale Unix domain socket failed when it could not start its listener. ([#141105](https://github.com/kubernetes/kubernetes/pull/141105), [@thc1006](https://github.com/thc1006)) [SIG Node]
- Fixed the ResourceClaim controller mutating the shared informer cache when creating a ResourceClaim from a ResourceClaimTemplate that has annotations. ([#141104](https://github.com/kubernetes/kubernetes/pull/141104), [@thc1006](https://github.com/thc1006)) [SIG Apps and Node]
- Fixed the `kube-apiserver` to create metadata fields for create-via-update and created-via-apply requests like they are for create requests. `UID` and `resourceVersion` preconditions are still honored. ([#138908](https://github.com/kubernetes/kubernetes/pull/138908), [@jpbetz](https://github.com/jpbetz)) [SIG API Machinery and Testing]
- Fixed the build for `test/images/glibc-dns-testing`. ([#138877](https://github.com/kubernetes/kubernetes/pull/138877), [@BenTheElder](https://github.com/BenTheElder)) [SIG Network and Testing]
- Fixed the error message from `PodGroupPostFilter` to contain the correct extension point name. ([#140747](https://github.com/kubernetes/kubernetes/pull/140747), [@Argh4k](https://github.com/Argh4k)) [SIG Scheduling]
- Fixed the inconsistency between opportunistic batching and PodGroups that made the batching hints always infeasible during PodGroup scheduling cycle. ([#138754](https://github.com/kubernetes/kubernetes/pull/138754), [@macsko](https://github.com/macsko)) [SIG Scheduling]
- Fixed the wrong cause of the UnexpectedJob event/warning by checking the owner reference of the job correctly in the cron job controller. ([#133313](https://github.com/kubernetes/kubernetes/pull/133313), [@kei01234kei](https://github.com/kei01234kei)) [SIG Apps]
- Generated `metadata.generation` and `status.observedGeneration` fields in HorizontalPodAutoscaler resources. ([#138228](https://github.com/kubernetes/kubernetes/pull/138228), [@adrianmoisey](https://github.com/adrianmoisey)) [SIG API Machinery, Apps, Autoscaling and Testing]
- Improved `kubeadm join` reliability by using the `KubernetesAPICall` timeout (default 1 minute) when fetching the `kubeadm-config` ConfigMap from the cluster, instead of the short 350ms retry previously used for optional component configs. A new `shortConfigMapGet` parameter was added to `FetchInitConfigurationFromCluster` so that callers like `kubeadm reset` can still use the short retry. ([#139667](https://github.com/kubernetes/kubernetes/pull/139667), [@damdo](https://github.com/damdo)) [SIG Cluster Lifecycle]
- Improved error reporting when invoking `kubectl exec`. ([#138214](https://github.com/kubernetes/kubernetes/pull/138214), [@hunshcn](https://github.com/hunshcn)) [SIG CLI and Testing]
- Improved scheduler handling of large PodGroups by reducing the likelihood of scheduling stalls when member Pods transiently fail to bind to Nodes, such as when many Pods share the same ResourceClaim. ([#140478](https://github.com/kubernetes/kubernetes/pull/140478), [@nojnhuh](https://github.com/nojnhuh)) [SIG Scheduling]
- Improved the logic in `kubeadm` around warnings when a user sets a non-default `bindAddress` in `KubeProxyConfiguration`. ([#139989](https://github.com/kubernetes/kubernetes/pull/139989), [@vinayakray19](https://github.com/vinayakray19)) [SIG Cluster Lifecycle]
- Improved the resilience of `kubeadm` etcd learner promotion by correctly handling cases where promotion succeeds but a transient client-side error is returned, preventing unnecessary etcd-join failures. ([#139842](https://github.com/kubernetes/kubernetes/pull/139842), [@jihyun-huh](https://github.com/jihyun-huh)) [SIG Cluster Lifecycle]
- Fixed `kubelet` to recover from corrupted subpath mount points (for example, stale NFS file handle) during container restart instead of leaving the pod stuck in `CreateContainerConfigError`. ([#138856](https://github.com/kubernetes/kubernetes/pull/138856), [@RomanBednar](https://github.com/RomanBednar)) [SIG Storage]
- Removed an edge case that could allow malformed object deletion to bypass admission and graceful deletion of well-formed objects. ([#137582](https://github.com/kubernetes/kubernetes/pull/137582), [@benluddy](https://github.com/benluddy)) [SIG API Machinery, Etcd and Testing]
- Removed the Alpha admission plugin that validated that PodGroup resources reference an existing Workload and match the declared PodGroupTemplate spec. ([#139008](https://github.com/kubernetes/kubernetes/pull/139008), [@wojtek-t](https://github.com/wojtek-t)) [SIG API Machinery, Etcd, Scheduling and Testing]
- Reverted the `cri-api` `KeyValue` value field to its pre-`v1.34` JSON encoding behavior for compatibility with earlier releases. ([#139964](https://github.com/kubernetes/kubernetes/pull/139964), [@liggitt](https://github.com/liggitt)) [SIG Node]
- Surfaced the error reason when invalid service CIDRs are configured. ([#139182](https://github.com/kubernetes/kubernetes/pull/139182), [@PseudoResonance](https://github.com/PseudoResonance)) [SIG Network]
- Updated `client-go` to preserve the source file's permissions when migrating a `kubeconfig` file (for example, `~/.kube/.kubeconfig` to `~/.kube/config`). Previously, the destination file was created with broader permissions, which could expose credentials to other users on the same system. ([#138142](https://github.com/kubernetes/kubernetes/pull/138142), [@brianpursley](https://github.com/brianpursley)) [SIG API Machinery]
- Updated `kube-proxy` to exit when the watched Node's IPs change or when the Node object is deleted, allowing it to restart with updated node networking state. ([#138183](https://github.com/kubernetes/kubernetes/pull/138183), [@abishekgiri](https://github.com/abishekgiri)) [SIG Network]
- Updated `kubectl run` error messages for invalid `--restart` and `--image-pull-policy` values to list the accepted values. ([#138188](https://github.com/kubernetes/kubernetes/pull/138188), [@ogormans-deptstack](https://github.com/ogormans-deptstack)) [SIG CLI]
- Updated `kubelet` eviction manager to exclude hugepage-reserved RAM from `AvailableBytes` in the calculation of `memory.available` on nodes with hugepages. This fixes delayed eviction and OOM kills caused by inflated available memory reporting. The `HugepageAwareEviction` feature gate (default: enabled) can be disabled to restore the previous behavior. ([#138127](https://github.com/kubernetes/kubernetes/pull/138127), [@jingczhang](https://github.com/jingczhang)) [SIG Node and Testing]
- Updated the PodGroup `status.conditions` field to reflect the failure reason when scheduling is rejected due to mismatched `.spec.schedulerName` across Pods in a group. ([#140183](https://github.com/kubernetes/kubernetes/pull/140183), [@Argh4k](https://github.com/Argh4k)) [SIG Scheduling]
- Updated the `PodReadyToStartContainers` condition to include a diagnostic message when `status` is `False`, explaining why the pod sandbox is not ready (for example, `pod sandbox has no IP address` or `no pod sandbox exists`). This improves debuggability for Pods stuck in `ContainerCreating` without requiring access to node logs. ([#135300](https://github.com/kubernetes/kubernetes/pull/135300), [@harche](https://github.com/harche)) [SIG Node]
- Updated the `kubelet` to emit `FailedToRetrieveImagePullSecret` events only when an image pull has failed. ([#138432](https://github.com/kubernetes/kubernetes/pull/138432), [@Jamstah](https://github.com/Jamstah)) [SIG Node]
- Updated the `kubelet` to no longer emit `V(4)` "Label not found" logs for missing optional container annotations. ([#140163](https://github.com/kubernetes/kubernetes/pull/140163), [@HirazawaUi](https://github.com/HirazawaUi)) [SIG Node]
- Updated the `pods/binding` subresource endpoint to validate the specified node name consistently. ([#136776](https://github.com/kubernetes/kubernetes/pull/136776), [@yakir-shriker](https://github.com/yakir-shriker)) [SIG Apps and Scheduling]
- Updated the version of the `nft` binary in the `kube-proxy` image to nftables `v1.0.6.1` to fix issues resyncing `kube-proxy` in nftables mode on systems containing rules created by recent versions of nftables. ([#140405](https://github.com/kubernetes/kubernetes/pull/140405), [@danwinship](https://github.com/danwinship)) [SIG Testing]
- Used a stable `curl` download for the Windows busybox testing image. ([#138879](https://github.com/kubernetes/kubernetes/pull/138879), [@BenTheElder](https://github.com/BenTheElder)) [SIG Testing and Windows]
- `client-go`: Added support for waiting for in-progress event handler runs to complete before closing the event handler. ([#139755](https://github.com/kubernetes/kubernetes/pull/139755), [@michaelasp](https://github.com/michaelasp)) [SIG API Machinery]
- `client-go`: Added the `Bookmark` and `LastStoreSyncResourceVersion` methods to `FakeCustomStore` so that it satisfies the `cache.Store` interface again, after those methods were added to the interface in `v0.36`. ([#140966](https://github.com/kubernetes/kubernetes/pull/140966), [@alancaldelas](https://github.com/alancaldelas)) [SIG API Machinery]
- `kubeadm`: Changed `kubeadm init` so that, when the default `admin.conf` and `super-admin.conf` paths are used, the files are loaded but in-memory kubeconfigs are constructed pointing to `InitConfiguration.localAPIEndpoint` instead of `ClusterConfiguration.controlPlaneEndpoint`. This resolved issues with delayed load balancers that are provisioned only after the first `kube-apiserver` instance starts. ([#138449](https://github.com/kubernetes/kubernetes/pull/138449), [@neolit123](https://github.com/neolit123)) [SIG Cluster Lifecycle]
- `kubeadm`: Changed `kubeadm join` to return a clear error message when the TLS bootstrap kubeconfig has a current-context that does not appear in the contexts list, instead of panicking with a nil pointer dereference. ([#138853](https://github.com/kubernetes/kubernetes/pull/138853), [@alexmchughdev](https://github.com/alexmchughdev)) [SIG Cluster Lifecycle]
- `kubeadm`: Changed cluster-info discovery over HTTPS to check the HTTP response status code, so a non-200 response produces a clear error instead of a confusing kubeconfig parse failure. ([#138852](https://github.com/kubernetes/kubernetes/pull/138852), [@alexmchughdev](https://github.com/alexmchughdev)) [SIG Cluster Lifecycle]
- `kubeadm`: Changed the etcd cluster status check to use a quorum approach instead of considering the health of all members, so the check no longer fails when there are sufficient healthy voting members. ([#138403](https://github.com/kubernetes/kubernetes/pull/138403), [@ahrtr](https://github.com/ahrtr)) [SIG Cluster Lifecycle]
- `kubeadm`: Fixed MemberPromote to skip the etcd promote API call when the member is already a voting member, avoiding unnecessary retries and timeout. ([#138390](https://github.com/kubernetes/kubernetes/pull/138390), [@wgkingk](https://github.com/wgkingk)) [SIG Cluster Lifecycle]
- `kubeadm`: Fixed a panic in `kubeadm` PKI key loading when the private key type and public key type mismatch. ([#138939](https://github.com/kubernetes/kubernetes/pull/138939), [@SataQiu](https://github.com/SataQiu)) [SIG Cluster Lifecycle]
- `kubeadm`: Fixed kubeadm init phase `certs --dry-run` to correctly copy existing CA files. ([#139339](https://github.com/kubernetes/kubernetes/pull/139339), [@ErikJiang](https://github.com/ErikJiang)) [SIG Cluster Lifecycle]
- `kubeadm`: Skipped LocalAPIEndpoint defaulting on `kubeadm join` for worker nodes. ([#138692](https://github.com/kubernetes/kubernetes/pull/138692), [@clwluvw](https://github.com/clwluvw)) [SIG Cluster Lifecycle]
- `kubeadm`: Used a dedicated ClusterRole `system:kubelet-api-admin` for the `kube-apiserver` `kubelet` client. ([#138957](https://github.com/kubernetes/kubernetes/pull/138957), [@neolit123](https://github.com/neolit123)) [SIG Cluster Lifecycle]
- `kubelet`/DRA: Fixed a bug where retrying a partially failed `PrepareResources` caused duplicate CDI device IDs to be passed to the CRI runtime, which could cause container start to fail. ([#140274](https://github.com/kubernetes/kubernetes/pull/140274), [@bart0sh](https://github.com/bart0sh)) [SIG Node]
- `kubelet`: Changed the `DefaultPodSysctls` feature to treat an unset `spec.hostUsers` as true when evaluating `user.*` sysctls. ([#140892](https://github.com/kubernetes/kubernetes/pull/140892), [@weizhoublue](https://github.com/weizhoublue)) [SIG Node]
- `kubelet`: Fixed a goroutine leak on shutdown by making the eviction manager's monitoring goroutine exit promptly when the `kubelet` context is cancelled. ([#138854](https://github.com/kubernetes/kubernetes/pull/138854), [@alexmchughdev](https://github.com/alexmchughdev)) [SIG Node]
- `kubelet`: Fixed incorrect Pod-level CPU requests reported in status from the cgroup v2 readback. ([#137660](https://github.com/kubernetes/kubernetes/pull/137660), [@pacoxu](https://github.com/pacoxu)) [SIG Node]
- `kubelet`: Populated `involvedObject.uid` on node events on a best-effort basis once the node is registered, so node events can be correlated by UID, for example in `kubectl describe node`. The UID is resolved once and not refreshed afterward. If a node is deleted and recreated with a new UID while the `kubelet` keeps running, its events continue to use the original UID until the `kubelet` restarts. ([#139921](https://github.com/kubernetes/kubernetes/pull/139921), [@harche](https://github.com/harche)) [SIG Node]
- `kubelet`: Set cgroup v2 `memory.high` for BestEffort containers when `MemoryQoS` is enabled (per KEP-2570). ([#138139](https://github.com/kubernetes/kubernetes/pull/138139), [@amritansh1502](https://github.com/amritansh1502)) [SIG Node]

### Other (Cleanup or Flake)

- Added the `HasValidationFunc` method to `runtime.Scheme` to report whether a declarative validation function is registered for a type. ([#140120](https://github.com/kubernetes/kubernetes/pull/140120), [@yongruilin](https://github.com/yongruilin)) [SIG API Machinery and Testing]
- Changed MutatingAdmissionPolicy and MutatingAdmissionPolicyBinding storage in etcd to use the `admissionregistration.k8s.io/v1` API version. ([#137375](https://github.com/kubernetes/kubernetes/pull/137375), [@Jefftree](https://github.com/Jefftree)) [SIG API Machinery, Etcd and Testing]
- Changed ResourceClaim config status to leave the `requests` field empty when the configuration applies to all requests. ([#139731](https://github.com/kubernetes/kubernetes/pull/139731), [@LionelJouin](https://github.com/LionelJouin)) [SIG Node]
- Changed `client-go` to request `v2` for aggregated discovery instead of falling back to `v2beta1`. ([#138271](https://github.com/kubernetes/kubernetes/pull/138271), [@Jefftree](https://github.com/Jefftree)) [SIG API Machinery]
- Changed the `kube-apiserver` `service/proxy` subresource to use EndpointSlices instead of Endpoints when proxying to a Service. This change only affects clusters that manually create Endpoints for a Service and have EndpointSlice mirroring disabled. ([#134860](https://github.com/kubernetes/kubernetes/pull/134860), [@danwinship](https://github.com/danwinship)) [SIG API Machinery and Network]
- Changed the scheduler's opportunistic batching to rescore the previously chosen node when it is still feasible, allowing it to compete with cached candidates for the next hint rather than always being skipped. ([#140289](https://github.com/kubernetes/kubernetes/pull/140289), [@romanbaron](https://github.com/romanbaron)) [SIG API Machinery, Etcd, Instrumentation, Scheduling and Testing]
- DRA: Fixed a potential crash in the scheduler, recovered after restart, when the ResourceSlice tracker encountered an OnDelete event for a DeviceTaintRule whose deleted object is unknown. ([#140193](https://github.com/kubernetes/kubernetes/pull/140193), [@pohly](https://github.com/pohly)) [SIG API Machinery and Node]
- DRA: Locked the `DRAPrioritizedList` feature gate to enabled by default. The Prioritized List feature reached GA in `v1.36` and can no longer be disabled. ([#139110](https://github.com/kubernetes/kubernetes/pull/139110), [@mortent](https://github.com/mortent)) [SIG Node, Scheduling and Testing]
- Deprecated `MultiLock`, `UnknownLeader`, and `ConcatRawRecord` in client-go leader election resourcelock package. ([#138070](https://github.com/kubernetes/kubernetes/pull/138070), [@Jefftree](https://github.com/Jefftree)) [SIG API Machinery]
- Fixed a bug in `kubelet` DRA where deleting a Pod could unprepare resources still in use by another Pod. ([#140212](https://github.com/kubernetes/kubernetes/pull/140212), [@bart0sh](https://github.com/bart0sh)) [SIG Node]
- Fixed a race condition where server-side apply requests for custom resources could observe an updated CustomResourceDefinition before the apply path was fully synchronized, causing inconsistent dry-run behavior. ([#140232](https://github.com/kubernetes/kubernetes/pull/140232), [@googs1025](https://github.com/googs1025)) [SIG API Machinery]
- Fixed a theoretical issue where nodes might have been denied access to synthesized ResourceClaims for pods using extended resources (for example, `nvidia.com/gpu`), causing containers to get stuck in `ContainerCreating`. Not observed in practice. ([#138792](https://github.com/kubernetes/kubernetes/pull/138792), [@dims](https://github.com/dims)) [SIG Auth and Node]
- Fixed server-side apply to correctly drop status changes when tracking field ownership for PodGroup, PodCompositeGroup, and PodCertificateRequest. ([#140654](https://github.com/kubernetes/kubernetes/pull/140654), [@jpbetz](https://github.com/jpbetz)) [SIG API Machinery, Auth, Scheduling and Testing]
- Improved `kubelet` Topology Manager error messages when the `prefer-closest-numa-nodes` policy option is enabled on Windows nodes that do not expose NUMA distance information, clarifying that the option is not supported on those nodes. ([#139760](https://github.com/kubernetes/kubernetes/pull/139760), [@zylxjtu](https://github.com/zylxjtu)) [SIG Node]
- Improved memory usage of `kube-proxy` by dropping the `.metadata.managedFields` field, which `kube-proxy` does not require. ([#140056](https://github.com/kubernetes/kubernetes/pull/140056), [@adrianmoisey](https://github.com/adrianmoisey)) [SIG Network]
- Logged a warning in the `kubelet` if a static Pod defines an invalid `priority` or `priorityClassName`. ([#136705](https://github.com/kubernetes/kubernetes/pull/136705), [@sreeram-venkitesh](https://github.com/sreeram-venkitesh)) [SIG Node]
- Promoted `apiserver_watch_events_total` and `apiserver_watch_events_sizes` to Beta. ([#137116](https://github.com/kubernetes/kubernetes/pull/137116), [@tico88612](https://github.com/tico88612)) [SIG API Machinery, Instrumentation and Testing]
- Removed `RelaxedDNSSearchValidation` feature gate. ([#139217](https://github.com/kubernetes/kubernetes/pull/139217), [@adrianmoisey](https://github.com/adrianmoisey)) [SIG Apps, Node and Testing]
- Removed locked GA feature gates `RetryGenerateName`, `BtreeWatchCache`, `OrderedNamespaceDeletion`, `StreamingCollectionEncodingToJSON`, `StreamingCollectionEncodingToProtobuf`, `APIServerTracing`, `ResilientWatchCacheInitialization`, and `ConsistentListFromCache`. ([#138907](https://github.com/kubernetes/kubernetes/pull/138907), [@Jefftree](https://github.com/Jefftree)) [SIG API Machinery, Apps, Etcd and Node]
- Removed the `--concurrent-service-syncs` kube-controller-manager flag (no-op since v1.31). ([#138002](https://github.com/kubernetes/kubernetes/pull/138002), [@Jefftree](https://github.com/Jefftree)) [SIG API Machinery]
- Removed the `KubeletMinVersion` label from the DRA e2e test covering multiple ResourceClaims. ([#138001](https://github.com/kubernetes/kubernetes/pull/138001), [@rogowski-piotr](https://github.com/rogowski-piotr)) [SIG Node and Testing]
- Removed the `PreventStaticPodAPIReferences` feature gate. Static Pods can no longer reference API resources, and this behavior can no longer be disabled. ([#140226](https://github.com/kubernetes/kubernetes/pull/140226), [@sreeram-venkitesh](https://github.com/sreeram-venkitesh)) [SIG Node]
- Stopped using maps for single-endpoint Services in `kube-proxy` nftables mode, increasing the speed of programming nftables. ([#140723](https://github.com/kubernetes/kubernetes/pull/140723), [@adrianmoisey](https://github.com/adrianmoisey)) [SIG Network]
- Switched StorageVersionMigration to use merge patch instead of SSA. ([#138874](https://github.com/kubernetes/kubernetes/pull/138874), [@michaelasp](https://github.com/michaelasp)) [SIG API Machinery, Apps and Auth]
- The `SidecarContainers` feature gate, unconditionally enabled since `v1.33`, is removed. ([#137755](https://github.com/kubernetes/kubernetes/pull/137755), [@HirazawaUi](https://github.com/HirazawaUi)) [SIG Apps, Node, Scheduling and Testing]
- The `kube-apiserver` `--enable-logs-handler` flag, deprecated in `v1.15`, is no longer marked deprecated. It remains off by default. ([#138915](https://github.com/kubernetes/kubernetes/pull/138915), [@BenTheElder](https://github.com/BenTheElder)) [SIG API Machinery]
- The deprecated Alpha metrics `apiserver_cache_list_total`, `apiserver_cache_list_fetched_objects_total`, and `apiserver_cache_list_returned_objects_total` are no longer exposed by default. Consumers should migrate to the unified `apiserver_storage_list_*` metrics with the `storage="watchcache"` label. ([#139154](https://github.com/kubernetes/kubernetes/pull/139154), [@yedou37](https://github.com/yedou37)) [SIG API Machinery and Instrumentation]
- Removed the no-op `DefaultWatchCacheSize` field of `k8s.io/apiserver/pkg/server/options.EtcdOptions`. ([#134151](https://github.com/kubernetes/kubernetes/pull/134151), [@ialidzhikov](https://github.com/ialidzhikov)) [SIG API Machinery]
- Updated DRA so that the ResourceClaim controller creates ResourceClaims from ResourceClaimTemplates referenced by a Pod that is a member of a PodGroup only when the `DRAWorkloadResourceClaims` feature gate is enabled. This prevents creating a ResourceClaim for an individual Pod when it is intended to be created for the PodGroup. ([#138363](https://github.com/kubernetes/kubernetes/pull/138363), [@nojnhuh](https://github.com/nojnhuh)) [SIG API Machinery, Apps, Node, Scheduling and Testing]
- Updated the etcd client library to `v3.6.11`. ([#138747](https://github.com/kubernetes/kubernetes/pull/138747), [@humblec](https://github.com/humblec)) [SIG API Machinery, Auth, Cloud Provider, Node and Scheduling]
- `kube-controller-manager` and `kube-scheduler` both expose `dynamic_resource_allocation_resourceclaim_creates_total` as a metric for the number of ResourceClaims created, replacing the differently named metrics in each component. The `kube-controller-manager` metric `resource_claims` was moved to the same `dynamic_resource_allocation` subsystem. ([#138542](https://github.com/kubernetes/kubernetes/pull/138542), [@pohly](https://github.com/pohly)) [SIG Apps, Instrumentation, Node, Release, Scheduling and Testing]
- `kubeadm`: Removed the `v1beta3` API which was deprecated since `v1.31`. The `v1.35` `kubeadm` binary can be used to migrate to `v1beta4` by using the command `kubeadm config migrate`. Additionally, removed the `PublicKeysECDSA` kubeadm-specific feature gate which was only kept for backwards compatibility with `v1beta3`. The support for ECDSA keys was added as part of the `v1beta4` field `ClusterConfiguration.EncryptionAlgorithm`. Added a placeholder `v1` API that is a copy of `v1beta4` and is flagged as experimental and cannot be used yet. ([#136016](https://github.com/kubernetes/kubernetes/pull/136016), [@neolit123](https://github.com/neolit123)) [SIG Cluster Lifecycle]
- `kubeadm`: Updated the supported etcd version to `v3.6.10` for supported control plane versions `v1.34`, `v1.35`, and `v1.36`. ([#138392](https://github.com/kubernetes/kubernetes/pull/138392), [@humblec](https://github.com/humblec)) [SIG API Machinery, Cloud Provider, Cluster Lifecycle, Etcd and Testing]
- `kubeadm`: Updated the supported etcd version to `v3.6.11` for supported control plane versions `v1.34`, `v1.35`, and `v1.36`. ([#138746](https://github.com/kubernetes/kubernetes/pull/138746), [@humblec](https://github.com/humblec)) [SIG API Machinery, Cloud Provider, Cluster Lifecycle, Etcd and Testing]

## Dependencies

### Added
- github.com/aclements/go-moremath: [f10218a](https://github.com/aclements/go-moremath/tree/f10218a)
- github.com/go-openapi/swag/cmdutils: [v0.27.1](https://github.com/go-openapi/swag/commit/c8a41f7226ee09d8f74ac3e9375d071041836b7c)
- github.com/go-openapi/swag/conv: [v0.27.1](https://github.com/go-openapi/swag/commit/c8a41f7226ee09d8f74ac3e9375d071041836b7c)
- github.com/go-openapi/swag/fileutils: [v0.27.1](https://github.com/go-openapi/swag/commit/c8a41f7226ee09d8f74ac3e9375d071041836b7c)
- github.com/go-openapi/swag/jsonutils: [v0.27.1](https://github.com/go-openapi/swag/commit/c8a41f7226ee09d8f74ac3e9375d071041836b7c)
- github.com/go-openapi/swag/jsonutils/fixtures_test: [v0.27.1](https://github.com/go-openapi/swag/commit/c8a41f7226ee09d8f74ac3e9375d071041836b7c)
- github.com/go-openapi/swag/loading: [v0.27.1](https://github.com/go-openapi/swag/commit/c8a41f7226ee09d8f74ac3e9375d071041836b7c)
- github.com/go-openapi/swag/mangling: [v0.27.1](https://github.com/go-openapi/swag/commit/c8a41f7226ee09d8f74ac3e9375d071041836b7c)
- github.com/go-openapi/swag/netutils: [v0.27.1](https://github.com/go-openapi/swag/commit/c8a41f7226ee09d8f74ac3e9375d071041836b7c)
- github.com/go-openapi/swag/pools: [v0.27.1](https://github.com/go-openapi/swag/commit/c8a41f7226ee09d8f74ac3e9375d071041836b7c)
- github.com/go-openapi/swag/stringutils: [v0.27.1](https://github.com/go-openapi/swag/commit/c8a41f7226ee09d8f74ac3e9375d071041836b7c)
- github.com/go-openapi/swag/typeutils: [v0.27.1](https://github.com/go-openapi/swag/commit/c8a41f7226ee09d8f74ac3e9375d071041836b7c)
- github.com/go-openapi/swag/yamlutils: [v0.27.1](https://github.com/go-openapi/swag/commit/c8a41f7226ee09d8f74ac3e9375d071041836b7c)
- github.com/go-openapi/testify/enable/yaml/v2: [v2.6.0](https://github.com/go-openapi/testify/commit/5376bc2556653f08cfefe95cf0beefa5b30b93ac)
- github.com/go-openapi/testify/v2: [v2.6.0](https://github.com/go-openapi/testify/commit/5376bc2556653f08cfefe95cf0beefa5b30b93ac)
- github.com/google/cadvisor/lib: [v0.60.5](https://github.com/google/cadvisor/commit/44b8e3062d678022939d40b2a2e9b259b07ebab0)
- github.com/google/nftables: [v0.3.0](https://github.com/google/nftables/commit/6f574e7fd1b4d07006d1c598cdb9b22789e5e541)
- github.com/mdlayher/netlink: [v1.11.2](https://github.com/mdlayher/netlink/commit/847c7b8181120b0e93dd7174b64914995edcfade)
- github.com/mdlayher/socket: [v0.6.1](https://github.com/mdlayher/socket/commit/c20d4c5139659b34b209af2556fef46e867eb62e)
- go.opentelemetry.io/otel/metric/x: [v0.66.0](https://github.com/open-telemetry/opentelemetry-go/commit/b62d92831b2dd142f5a0cc89c828270274196877)
- golang.org/x/perf: [2f7363a](https://go.googlesource.com/perf/+/2f7363a06fe1e84314f47158b693ef982b0c2255)
- tags.cncf.io/container-device-interface/specs-go: [v1.1.0](https://github.com/cncf-tags/container-device-interface/commit/98a7d735d9592c1ccca0130e06b0709f4b65ecbf)

### Changed
- cyphar.com/go-pathrs: [v0.2.2 → v0.2.5](https://github.com/cyphar/libpathrs.git/compare/go-pathrs/v0.2.2...go-pathrs/v0.2.5)
- github.com/Azure/go-ansiterm: [306776e → faa5f7b](https://github.com/Azure/go-ansiterm/compare/306776e...faa5f7b)
- github.com/GoogleCloudPlatform/opentelemetry-operations-go/detectors/gcp: [v1.30.0 → v1.32.0](https://github.com/GoogleCloudPlatform/opentelemetry-operations-go/compare/v1.30.0...v1.32.0)
- github.com/Microsoft/hnslib: [v0.1.2 → v0.1.3](https://github.com/Microsoft/hnslib/compare/v0.1.2...v0.1.3)
- github.com/antlr4-go/antlr/v4: [v4.13.0 → v4.13.1](https://github.com/antlr4-go/antlr/compare/v4.13.0...v4.13.1)
- github.com/cncf/xds/go: [ee656c7 → dba9d58](https://github.com/cncf/xds/compare/ee656c7534f5d7dc23d44dd611689568f72017a6...dba9d589def2cd10099a3a64887d859188c2f57a)
- github.com/container-storage-interface/spec: [v1.9.0 → cd9e7ad](https://github.com/container-storage-interface/spec/compare/v1.9.0...cd9e7ad1ae0915cabcad179f2b8a660c0cb6eb9f)
- github.com/containerd/containerd/api: [v1.10.0 → v1.11.1](https://github.com/containerd/containerd/compare/api/v1.10.0...api/v1.11.1)
- github.com/containerd/ttrpc: [v1.2.7 → v1.2.9](https://github.com/containerd/ttrpc/compare/v1.2.7...v1.2.9)
- github.com/containerd/typeurl/v2: [v2.2.3 → v2.3.0](https://github.com/containerd/typeurl/compare/v2.2.3...v2.3.0)
- github.com/coredns/corefile-migration: [v1.0.31 → v1.0.34](https://github.com/coredns/corefile-migration/compare/v1.0.31...v1.0.34)
- github.com/cyphar/filepath-securejoin: [v0.6.1 → v0.7.0](https://github.com/cyphar/filepath-securejoin/compare/v0.6.1...v0.7.0)
- github.com/envoyproxy/go-control-plane/envoy: [v1.36.0 → v1.37.0](https://github.com/envoyproxy/go-control-plane/compare/envoy/v1.36.0...envoy/v1.37.0)
- github.com/envoyproxy/protoc-gen-validate: [v1.3.0 → v1.3.3](https://github.com/envoyproxy/protoc-gen-validate/compare/v1.3.0...v1.3.3)
- github.com/fxamacker/cbor/v2: [v2.9.0 → v2.9.1](https://github.com/fxamacker/cbor/compare/v2.9.0...v2.9.1)
- github.com/go-jose/go-jose/v4: [v4.1.3 → v4.1.4](https://github.com/go-jose/go-jose/compare/v4.1.3...v4.1.4)
- github.com/go-openapi/jsonpointer: [v0.21.0 → v1.0.0](https://github.com/go-openapi/jsonpointer/compare/v0.21.0...v1.0.0)
- github.com/go-openapi/jsonreference: [v0.20.2 → v1.0.0](https://github.com/go-openapi/jsonreference/compare/v0.20.2...v1.0.0)
- github.com/go-openapi/swag: [v0.23.0 → v0.27.1](https://github.com/go-openapi/swag/compare/v0.23.0...v0.27.1)
- github.com/golang-jwt/jwt/v5: [v5.3.0 → v5.3.1](https://github.com/golang-jwt/jwt/compare/v5.3.0...v5.3.1)
- github.com/google/cel-go: [v0.26.0 → v0.29.2](https://github.com/google/cel-go/compare/v0.26.0...v0.29.2)
- github.com/google/pprof: [294ebfa → 545e8a4](https://github.com/google/pprof/compare/294ebfa9ad836ed3d00d43d54ea599339e403110...545e8a4df9364095d66e521b8f515f7af961e653)
- github.com/grpc-ecosystem/grpc-gateway/v2: [v2.27.7 → v2.29.0](https://github.com/grpc-ecosystem/grpc-gateway/compare/v2.27.7...v2.29.0)
- github.com/klauspost/compress: [v1.18.0 → v1.19.0](https://github.com/klauspost/compress/compare/v1.18.0...v1.19.0)
- github.com/moby/term: [v0.5.0 → v0.5.2](https://github.com/moby/term/compare/main...v0.5.2)
- github.com/onsi/ginkgo/v2: [v2.28.1 → v2.32.0](https://github.com/onsi/ginkgo/compare/v2.28.1...v2.32.0)
- github.com/onsi/gomega: [v1.39.1 → v1.40.0](https://github.com/onsi/gomega/compare/v1.39.1...v1.40.0)
- github.com/opencontainers/cgroups: [v0.0.6 → v0.0.7](https://github.com/opencontainers/cgroups/compare/v0.0.6...v0.0.7)
- github.com/opencontainers/selinux: [v1.13.1 → v1.15.1](https://github.com/opencontainers/selinux/compare/v1.13.1...v1.15.1)
- github.com/prometheus/client_golang: [v1.23.2 → v1.24.0](https://github.com/prometheus/client_golang/compare/v1.23.2...v1.24.0)
- github.com/prometheus/common: [v0.67.5 → v0.70.0](https://github.com/prometheus/common/compare/v0.67.5...v0.70.0)
- github.com/prometheus/procfs: [v0.19.2 → v0.21.1](https://github.com/prometheus/procfs/compare/v0.19.2...v0.21.1)
- github.com/sirupsen/logrus: [v1.9.3 → v1.9.4](https://github.com/sirupsen/logrus/compare/v1.9.3...v1.9.4)
- github.com/spf13/pflag: [v1.0.9 → v1.0.10](https://github.com/spf13/pflag/compare/v1.0.9...v1.0.10)
- github.com/stretchr/objx: [v0.5.2 → v0.5.3](https://github.com/stretchr/objx/compare/v0.5.2...v0.5.3)
- go.etcd.io/bbolt: [v1.4.3 → v1.5.0](https://github.com/etcd-io/bbolt/compare/v1.4.3...v1.5.0)
- go.etcd.io/etcd/api/v3: [v3.6.8 → v3.7.0](https://github.com/etcd-io/etcd/compare/api/v3.6.8...api/v3.7.0)
- go.etcd.io/etcd/client/pkg/v3: [v3.6.8 → v3.7.0](https://github.com/etcd-io/etcd/compare/client/pkg/v3.6.8...client/pkg/v3.7.0)
- go.etcd.io/etcd/client/v3: [v3.6.8 → v3.7.0](https://github.com/etcd-io/etcd/compare/client/v3.6.8...client/v3.7.0)
- go.etcd.io/etcd/pkg/v3: [v3.6.8 → v3.7.0](https://github.com/etcd-io/etcd/compare/pkg/v3.6.8...pkg/v3.7.0)
- go.etcd.io/etcd/server/v3: [v3.6.8 → v3.7.0](https://github.com/etcd-io/etcd/compare/server/v3.6.8...server/v3.7.0)
- go.etcd.io/raft/v3: [v3.6.0 → v3.7.0](https://github.com/etcd-io/raft/compare/v3.6.0...v3.7.0)
- go.opentelemetry.io/contrib/detectors/gcp: [v1.39.0 → v1.43.0](https://github.com/open-telemetry/opentelemetry-go-contrib/compare/detectors/gcp/v1.39.0...detectors/gcp/v1.43.0)
- go.opentelemetry.io/contrib/instrumentation/github.com/emicklei/go-restful/otelrestful: [v0.65.0 → v0.69.0](https://github.com/open-telemetry/opentelemetry-go-contrib/compare/instrumentation/github.com/emicklei/go-restful/otelrestful/v0.65.0...instrumentation/github.com/emicklei/go-restful/otelrestful/v0.69.0)
- go.opentelemetry.io/contrib/instrumentation/google.golang.org/grpc/otelgrpc: [v0.65.0 → v0.68.0](https://github.com/open-telemetry/opentelemetry-go-contrib/compare/instrumentation/google.golang.org/grpc/otelgrpc/v0.65.0...instrumentation/google.golang.org/grpc/otelgrpc/v0.68.0)
- go.opentelemetry.io/contrib/instrumentation/net/http/otelhttp: [v0.65.0 → v0.69.0](https://github.com/open-telemetry/opentelemetry-go-contrib/compare/instrumentation/net/http/otelhttp/v0.65.0...instrumentation/net/http/otelhttp/v0.69.0)
- go.opentelemetry.io/contrib/propagators/b3: [v1.40.0 → v1.44.0](https://github.com/open-telemetry/opentelemetry-go-contrib/compare/propagators/b3/v1.40.0...propagators/b3/v1.44.0)
- go.opentelemetry.io/otel: [v1.41.0 → v1.44.0](https://github.com/open-telemetry/opentelemetry-go/compare/v1.41.0...v1.44.0)
- go.opentelemetry.io/otel/exporters/otlp/otlptrace: [v1.40.0 → v1.44.0](https://github.com/open-telemetry/opentelemetry-go/compare/exporters/otlp/otlptrace/v1.40.0...exporters/otlp/otlptrace/v1.44.0)
- go.opentelemetry.io/otel/exporters/otlp/otlptrace/otlptracegrpc: [v1.40.0 → v1.44.0](https://github.com/open-telemetry/opentelemetry-go/compare/exporters/otlp/otlptrace/otlptracegrpc/v1.40.0...exporters/otlp/otlptrace/otlptracegrpc/v1.44.0)
- go.opentelemetry.io/otel/exporters/stdout/stdouttrace: [v1.40.0 → v1.44.0](https://github.com/open-telemetry/opentelemetry-go/compare/exporters/stdout/stdouttrace/v1.40.0...exporters/stdout/stdouttrace/v1.44.0)
- go.opentelemetry.io/otel/metric: [v1.41.0 → v1.44.0](https://github.com/open-telemetry/opentelemetry-go/compare/metric/v1.41.0...metric/v1.44.0)
- go.opentelemetry.io/otel/sdk: [v1.40.0 → v1.44.0](https://github.com/open-telemetry/opentelemetry-go/compare/sdk/v1.40.0...sdk/v1.44.0)
- go.opentelemetry.io/otel/sdk/metric: [v1.40.0 → v1.44.0](https://github.com/open-telemetry/opentelemetry-go/compare/sdk/metric/v1.40.0...sdk/metric/v1.44.0)
- go.opentelemetry.io/otel/trace: [v1.41.0 → v1.44.0](https://github.com/open-telemetry/opentelemetry-go/compare/trace/v1.41.0...trace/v1.44.0)
- go.opentelemetry.io/proto/otlp: [v1.9.0 → v1.10.0](https://github.com/open-telemetry/opentelemetry-proto-go/compare/otlp/v1.9.0...otlp/v1.10.0)
- go.yaml.in/yaml/v2: [v2.4.3 → v2.4.4](https://github.com/yaml/go-yaml/compare/v2.4.3...v2.4.4)
- golang.org/x/crypto: [v0.47.0 → v0.54.0](https://go.googlesource.com/crypto/+/506e022208b864bc3c9c4a416fe56be75d10ad24^1..cdce021fa6c7d9c7eb2743bfbe551f0a98fd5d62/)
- golang.org/x/exp: [944ab1f → 746e56f](https://go.googlesource.com/exp/+/944ab1f22d936eefb8f6260ecd2053101d8d7b2a^1..746e56fc9e2fafde18176275ce0b96b06ac53955/)
- golang.org/x/mod: [v0.32.0 → v0.37.0](https://go.googlesource.com/mod/+/4c04067938546e62fc0572259a68a6912726bcdd^1..deb1dfcdb7c7fd98fb5afddc3e95dd36d5880874/)
- golang.org/x/net: [v0.49.0 → v0.57.0](https://go.googlesource.com/net/+/d977772e17ccaa1903b2af736f6405ab3a9f05cc^1..b8f09f6f062ceb4531b7af4bd17a5c8fe9c4b2b5/)
- golang.org/x/oauth2: [v0.34.0 → v0.36.0](https://go.googlesource.com/oauth2/+/acc38155b7f6f36aefcb58faff6f36d314dd915c^1..4d954e69a88d9e1ccb8439f8d5b6cbef230c4ef9/)
- golang.org/x/sync: [v0.19.0 → v0.22.0](https://go.googlesource.com/sync/+/2a180e22fddcc336475e72aa950be958c1b68d33^1..1eb64d4bc0cde6da1bb8ebc7f178bb577508e5d0/)
- golang.org/x/sys: [v0.40.0 → v0.47.0](https://go.googlesource.com/sys/+/2f442297556c884f9b52fc6ef7280083f4d65023^1..9e7e939dcafac07e8ab4cffa6e5fc74908413f00/)
- golang.org/x/telemetry: [bd525da → 59b4966](https://go.googlesource.com/telemetry/+/bd525da824e2505db9e8ac44025316bf6f43a6f6^1..59b4966ccb57499277814ee2272936a2c01cfbcd/)
- golang.org/x/term: [v0.39.0 → v0.45.0](https://go.googlesource.com/term/+/a7e5b0437ffa3159709172efbe396bc546550e23^1..9f69229da31ca6a34b522f59dbe07cad5ea21587/)
- golang.org/x/text: [v0.33.0 → v0.40.0](https://go.googlesource.com/text/+/536231a9abc69feaab8d726b5ec75ee8d3620829^1..724af9c35838492dcaacc1ac51a8a0187c994c54/)
- golang.org/x/time: [v0.14.0 → v0.15.0](https://go.googlesource.com/time/+/2b4e43900c03fd6b77109b7b2b6d77583f48bc1c^1..812b343c8714c317b0dad633efa6d103e554c006/)
- golang.org/x/tools: [v0.41.0 → v0.47.0](https://go.googlesource.com/tools/+/2ad2b30edf98d0e3b67a7b3e8f6d1d6e41c963c3^1..fbf9f2e2c8124fbe1877f5ed2857111038d9fe12/)
- gonum.org/v1/gonum: [v0.16.0 → v0.17.0](https://github.com/gonum/gonum/compare/v0.16.0...v0.17.0)
- google.golang.org/genproto/googleapis/api: [8636f87 → 3dc84a4](https://github.com/googleapis/go-genproto/compare/8636f8732409467ddc8453f81f4429397739bb17...3dc84a4a5aaa87331e10f51e22e90d961f986894)
- google.golang.org/genproto/googleapis/rpc: [8636f87 → 3dc84a4](https://github.com/googleapis/go-genproto/compare/8636f8732409467ddc8453f81f4429397739bb17...3dc84a4a5aaa87331e10f51e22e90d961f986894)
- google.golang.org/grpc: [v1.79.3 → v1.82.1](https://github.com/grpc/grpc-go/compare/v1.79.3...v1.82.1)
- k8s.io/gengo/v2: [ec3ebc5 → 25e2208](https://github.com/kubernetes/gengo/compare/ec3ebc5fd46b84f44dfb135e9684c6567791dd8e...25e2208e0dc371a827289e7faced19a2dbcd480b)
- k8s.io/kube-openapi: [43fb72c → d427ff9](https://github.com/kubernetes/kube-openapi/compare/43fb72c5454a03ed83388cf20c070499ee359af8...d427ff9ee9ad05f5da435abbb7c5929cb713ac56)
- k8s.io/utils: [b8788ab → be93311](https://github.com/kubernetes/utils/compare/b8788abfbbc27cab6c8732274b5c2ae213868854...be93311217bd4e42d0aa42a5987d08e8f5581ec0)
- sigs.k8s.io/apiserver-network-proxy/konnectivity-client: [v0.34.0 → v0.36.0](https://github.com/kubernetes-sigs/apiserver-network-proxy/compare/konnectivity-client/v0.34.0...konnectivity-client/v0.36.0)
- sigs.k8s.io/knftables: [v0.0.21 → v0.0.22](https://github.com/kubernetes-sigs/knftables/compare/v0.0.21...v0.0.22)
- sigs.k8s.io/structured-merge-diff/v6: [v6.3.2 → v6.4.2](https://github.com/kubernetes-sigs/structured-merge-diff/compare/v6.3.2...v6.4.2)

### Removed
- github.com/aws/aws-sdk-go-v2: [v1.36.3](https://github.com/aws/aws-sdk-go-v2/commit/c33f3e8d6bd4acd3c33d7abf391c7040305d5f12)
- github.com/aws/aws-sdk-go-v2/config: [v1.29.14](https://github.com/aws/aws-sdk-go-v2/commit/2a0c73e76f5f06579a2cb24239ca054d60ced4c2)
- github.com/aws/aws-sdk-go-v2/credentials: [v1.17.67](https://github.com/aws/aws-sdk-go-v2/commit/2a0c73e76f5f06579a2cb24239ca054d60ced4c2)
- github.com/aws/aws-sdk-go-v2/feature/ec2/imds: [v1.16.30](https://github.com/aws/aws-sdk-go-v2/commit/c33f3e8d6bd4acd3c33d7abf391c7040305d5f12)
- github.com/aws/aws-sdk-go-v2/internal/configsources: [v1.3.34](https://github.com/aws/aws-sdk-go-v2/commit/c33f3e8d6bd4acd3c33d7abf391c7040305d5f12)
- github.com/aws/aws-sdk-go-v2/internal/endpoints/v2: [v2.6.34](https://github.com/aws/aws-sdk-go-v2/commit/c33f3e8d6bd4acd3c33d7abf391c7040305d5f12)
- github.com/aws/aws-sdk-go-v2/internal/ini: [v1.8.3](https://github.com/aws/aws-sdk-go-v2/commit/54aed732316b5162e5c4382a1f2d3891175d0254)
- github.com/aws/aws-sdk-go-v2/service/internal/accept-encoding: [v1.12.3](https://github.com/aws/aws-sdk-go-v2/commit/54aed732316b5162e5c4382a1f2d3891175d0254)
- github.com/aws/aws-sdk-go-v2/service/internal/presigned-url: [v1.12.15](https://github.com/aws/aws-sdk-go-v2/commit/c33f3e8d6bd4acd3c33d7abf391c7040305d5f12)
- github.com/aws/aws-sdk-go-v2/service/sso: [v1.25.3](https://github.com/aws/aws-sdk-go-v2/commit/bada51283b7ea361a15a4bb018b817e899b363ad)
- github.com/aws/aws-sdk-go-v2/service/ssooidc: [v1.30.1](https://github.com/aws/aws-sdk-go-v2/commit/bada51283b7ea361a15a4bb018b817e899b363ad)
- github.com/aws/aws-sdk-go-v2/service/sts: [v1.33.19](https://github.com/aws/aws-sdk-go-v2/commit/2a0c73e76f5f06579a2cb24239ca054d60ced4c2)
- github.com/aws/smithy-go: [v1.22.3](https://github.com/aws/smithy-go/commit/312566ce7f2e736333ce7cbca09328d766c92ce7)
- github.com/cenkalti/backoff/v4: [v4.3.0](https://github.com/cenkalti/backoff/commit/720b78985a65c0452fd37bb155c7cac4157a7c45)
- github.com/containerd/errdefs: [v1.0.0](https://github.com/containerd/errdefs/commit/4817405e4a3caeb7aee9dac68ed55339c59cb635)
- github.com/containerd/errdefs/pkg: [v0.3.0](https://github.com/containerd/errdefs/commit/4817405e4a3caeb7aee9dac68ed55339c59cb635)
- github.com/docker/go-connections: [v0.6.0](https://github.com/docker/go-connections/commit/42faf792bde28c414a060127d6351769408a675f)
- github.com/euank/go-kmsg-parser: [v2.0.0](https://github.com/euank/go-kmsg-parser/tree/v2.0.0)
- github.com/golang/groupcache: [41bb18b](https://github.com/golang/groupcache/tree/41bb18b)
- github.com/google/cadvisor: [v0.56.2](https://github.com/google/cadvisor/commit/7cbdee9260c4292d5d27d00416ce8a7dc1dc12a0)
- github.com/grpc-ecosystem/go-grpc-middleware: [v1.3.0](https://github.com/grpc-ecosystem/go-grpc-middleware/tree/v1.3.0)
- github.com/mistifyio/go-zfs: [f784269](https://github.com/mistifyio/go-zfs/tree/f784269)
- github.com/moby/docker-image-spec: [v1.3.1](https://github.com/moby/docker-image-spec/commit/f1d00ebd2d6d6805170d5543dbca4b850f35f9af)
- github.com/moby/moby/api: [v1.52.0](https://github.com/moby/moby/commit/1408c9ca4f4f0717b2d885fc87ae0ff000a91c40)
- github.com/moby/moby/client: [v0.2.1](https://github.com/moby/moby/commit/b6f067c0cfe38401c7fa7678efbbe383ebe134fb)
- github.com/opencontainers/runc: [v1.4.0](https://github.com/opencontainers/runc/commit/8bd78a9977e604c4d5f67a7415d7b8b8c109cdc4)



# v1.37.0-rc.1


## Downloads for v1.37.0-rc.1



### Source Code

filename | sha512 hash
-------- | -----------
[kubernetes.tar.gz](https://dl.k8s.io/v1.37.0-rc.1/kubernetes.tar.gz) | f8837cef9d21d5ab3260cfb0f8ec3b2d856bcebcbbcde2de45547ef4f34ad999371a13cd4f1356c8154f01ccee644c762f25286690cab64b9ca099c2fd055ccf
[kubernetes-src.tar.gz](https://dl.k8s.io/v1.37.0-rc.1/kubernetes-src.tar.gz) | 31ed9c00dd56f4e3d11a8a6ad8eb09c7224eef594d9bca4d5a7e8efde612cafeaeb185734f92d0278e5cb39cc16ecef3b1811857c4d23f0bd10d1fa0e25850a6

### Client Binaries

filename | sha512 hash
-------- | -----------
[kubernetes-client-darwin-amd64.tar.gz](https://dl.k8s.io/v1.37.0-rc.1/kubernetes-client-darwin-amd64.tar.gz) | d48f90d0c20cddd70627939a74cf0d68e6abb6a77186a1d754ec18c46224859d3213f3e1a89ecece4d5854df2102307d04a4e47694c79e7f63a223982949933b
[kubernetes-client-darwin-arm64.tar.gz](https://dl.k8s.io/v1.37.0-rc.1/kubernetes-client-darwin-arm64.tar.gz) | 97d6ce20c2210c19645eb5757f9ce98d02be82eb4bb9148d6595baaf912cef68ac4610b0478d0feeaa373fc954ab41a39e8e096cf597282c026ac24a2cc3d7d0
[kubernetes-client-linux-386.tar.gz](https://dl.k8s.io/v1.37.0-rc.1/kubernetes-client-linux-386.tar.gz) | b5db728a32e4c8033b078b4aadf407b674c5be71dac2d600f58c756d6cfb872c08933dafbeab80559304c757b36447d12c33311a589c4ab9d62e69ad3f665641
[kubernetes-client-linux-amd64.tar.gz](https://dl.k8s.io/v1.37.0-rc.1/kubernetes-client-linux-amd64.tar.gz) | c8049c73c840dd4c4c1be9df5b7e6cb2ad44c83fbf196f14138f0a33729fa75bf045d072b2a1d6ab4a942515b1a51cdda75e4d1e6842f5675d70253479607aec
[kubernetes-client-linux-arm.tar.gz](https://dl.k8s.io/v1.37.0-rc.1/kubernetes-client-linux-arm.tar.gz) | 52fd26bd88d43fc6b2db8369acdc4ee05222189a820015bfa3c134e00df742e1d38880f074b9b3b6a7e63cf44d77987376dbbbfaf37e3535ae649014806c04bf
[kubernetes-client-linux-arm64.tar.gz](https://dl.k8s.io/v1.37.0-rc.1/kubernetes-client-linux-arm64.tar.gz) | 17cad3988014cdfee6ded133d7ed8e67b7b9ee04abd765f49d7252355d55916a11502be1c179d2826e120ff4881633c62e22074564047d1965ae3e969ab373c9
[kubernetes-client-linux-ppc64le.tar.gz](https://dl.k8s.io/v1.37.0-rc.1/kubernetes-client-linux-ppc64le.tar.gz) | 0103bbe685d395caff22ab01bac99fd3576d412bc902a30bbbe88211a5d932d1b499da9be5d2fc9f307e9140bf768a4b791cd880340003839df7cd85026f58a2
[kubernetes-client-linux-s390x.tar.gz](https://dl.k8s.io/v1.37.0-rc.1/kubernetes-client-linux-s390x.tar.gz) | a12541887ae73ef59fcb0ea389d0ee48d8ff227d38ed86cc74f187ccabf2316eb5cf75bbbd32f2f996766b116b45289695340a0ec0566b533e187bb47bd9426c
[kubernetes-client-windows-386.tar.gz](https://dl.k8s.io/v1.37.0-rc.1/kubernetes-client-windows-386.tar.gz) | 0d1a09003128788d2a3903aed400a572037f54c749ead805ab8539a84b9f7d7c694009ec7a79d5438bbe809ab67e183880b2a1477c88d8b02cc244bad0c1edea
[kubernetes-client-windows-amd64.tar.gz](https://dl.k8s.io/v1.37.0-rc.1/kubernetes-client-windows-amd64.tar.gz) | 534fbed232ac50f08e7db88478160f9395f1c563b64b2627edf13e8ce3d771140cac66de65b1405a7f5b08a414f8d8dbb0a40d2873174e70b3ae3b99bf212528
[kubernetes-client-windows-arm64.tar.gz](https://dl.k8s.io/v1.37.0-rc.1/kubernetes-client-windows-arm64.tar.gz) | a5be672a45d7f9d8f32f81d23ee1a62e637b8f7f4942d3ca655b5fa6ae0c6a079f3bc883b7354e4765469a196575b0cbb447e71a0898b8c3f43f3f7e0cb2baf4

### Server Binaries

filename | sha512 hash
-------- | -----------
[kubernetes-server-linux-amd64.tar.gz](https://dl.k8s.io/v1.37.0-rc.1/kubernetes-server-linux-amd64.tar.gz) | 5ad130a94876651560e47d2788e0b0bc5920c6cd33136398548537bad822a69801217141e2258058ce254a3eeaea5c62d3b013c85d651619871dda0efa1f592b
[kubernetes-server-linux-arm64.tar.gz](https://dl.k8s.io/v1.37.0-rc.1/kubernetes-server-linux-arm64.tar.gz) | 25b0cd3910e38e441053766a1f1cbbfcc8703e676bc59dcff2511f67f3610e2ccfe3518efe34c59413159c15d4afef42e464f552e358a4601e751478eb8f9da2
[kubernetes-server-linux-ppc64le.tar.gz](https://dl.k8s.io/v1.37.0-rc.1/kubernetes-server-linux-ppc64le.tar.gz) | b1ce2ec1a116dc4afeea421ddb432a7d3110b71f799011ac71f8755ed637bb79c77362b3cc96890a08a212dcb20a002fed22c7507d4c5fc2a4a01efd63e8b729
[kubernetes-server-linux-s390x.tar.gz](https://dl.k8s.io/v1.37.0-rc.1/kubernetes-server-linux-s390x.tar.gz) | 45380c00def80c29c95bfa71812671779ca2d5961a2c88cd1c1f3c0479749e2c413ed52e45a67422ab420ef3c6f623eab906c83c7d0b8d4355c6d36b7e1609ca

### Node Binaries

filename | sha512 hash
-------- | -----------
[kubernetes-node-linux-amd64.tar.gz](https://dl.k8s.io/v1.37.0-rc.1/kubernetes-node-linux-amd64.tar.gz) | c00d86a7f17a2ba98387f807c99659839a36a0f1423f4daeadde3793ee898502018270782c3d9378c858af365ed850ba294643faf79faffe48785d6148e02369
[kubernetes-node-linux-arm64.tar.gz](https://dl.k8s.io/v1.37.0-rc.1/kubernetes-node-linux-arm64.tar.gz) | 66c6e2a2ec6a33fae491e90985969cecdc22bf9ea8e12fe1cf268e02badbdda2544b59c6436c88cd2ceff0964983cd81828c39805cb5a988a9f51735d45fe559
[kubernetes-node-linux-ppc64le.tar.gz](https://dl.k8s.io/v1.37.0-rc.1/kubernetes-node-linux-ppc64le.tar.gz) | 5af32217dd92c641cb9995de8c617b6799f12c0f0dc8e1d4429ec7e03d71a213ee862803c777abb7a97fbb25506377859b91c2ab07e12c601bd07aae6369f34f
[kubernetes-node-linux-s390x.tar.gz](https://dl.k8s.io/v1.37.0-rc.1/kubernetes-node-linux-s390x.tar.gz) | 8c01507e7bda46538729013dc1878d18e2f77706067eab2dfb8300be50142a8b8b1bb6ce5dee66104e4987946a17d5d4e00f1d2351d891612c0ebb80d0554649
[kubernetes-node-windows-amd64.tar.gz](https://dl.k8s.io/v1.37.0-rc.1/kubernetes-node-windows-amd64.tar.gz) | 9145c2b746b052e452b4c685bb6f736c5386f8edcc5f1366073e71d21b0d5cf29e7ddc51e018567ce51ad6a3348a2c4d52abcdef7654b2ce862735bfc071e5c6

### Container Images

All container images are available as manifest lists and support the described
architectures. It is also possible to pull a specific architecture directly by
adding the "-$ARCH" suffix  to the container image name.

name | architectures
---- | -------------
[registry.k8s.io/conformance:v1.37.0-rc.1](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/conformance) | [amd64](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/conformance-amd64), [arm64](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/conformance-arm64), [ppc64le](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/conformance-ppc64le), [s390x](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/conformance-s390x)
[registry.k8s.io/kube-apiserver:v1.37.0-rc.1](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-apiserver) | [amd64](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-apiserver-amd64), [arm64](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-apiserver-arm64), [ppc64le](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-apiserver-ppc64le), [s390x](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-apiserver-s390x)
[registry.k8s.io/kube-controller-manager:v1.37.0-rc.1](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-controller-manager) | [amd64](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-controller-manager-amd64), [arm64](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-controller-manager-arm64), [ppc64le](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-controller-manager-ppc64le), [s390x](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-controller-manager-s390x)
[registry.k8s.io/kube-proxy:v1.37.0-rc.1](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-proxy) | [amd64](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-proxy-amd64), [arm64](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-proxy-arm64), [ppc64le](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-proxy-ppc64le), [s390x](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-proxy-s390x)
[registry.k8s.io/kube-scheduler:v1.37.0-rc.1](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-scheduler) | [amd64](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-scheduler-amd64), [arm64](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-scheduler-arm64), [ppc64le](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-scheduler-ppc64le), [s390x](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-scheduler-s390x)
[registry.k8s.io/kubectl:v1.37.0-rc.1](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kubectl) | [amd64](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kubectl-amd64), [arm64](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kubectl-arm64), [ppc64le](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kubectl-ppc64le), [s390x](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kubectl-s390x)

## Changelog since v1.37.0-rc.0

## Dependencies

### Added
_Nothing has changed._

### Changed
_Nothing has changed._

### Removed
_Nothing has changed._



# v1.37.0-rc.0


## Downloads for v1.37.0-rc.0



### Source Code

filename | sha512 hash
-------- | -----------
[kubernetes.tar.gz](https://dl.k8s.io/v1.37.0-rc.0/kubernetes.tar.gz) | 39f45569d7bb0a3a931636d0794dfc851d7f0ceeefff54a6b6791d2e85034286f5bfbfe916f2c195f3a404fd7d5610744fb8b99de5bb36e9bd3d95a0ed91628c
[kubernetes-src.tar.gz](https://dl.k8s.io/v1.37.0-rc.0/kubernetes-src.tar.gz) | 67bfe4db5691ea960041aab7423446250272cbfee45fcb51e70a4b5da5acd64a9a7d358a8c709a10c3eb3f48d582c02af8de3bbc1a3a96a212b2ac8317b37e3e

### Client Binaries

filename | sha512 hash
-------- | -----------
[kubernetes-client-darwin-amd64.tar.gz](https://dl.k8s.io/v1.37.0-rc.0/kubernetes-client-darwin-amd64.tar.gz) | 04113bab71e6ec1507ca8a05234c9980a98e6682dc3238aa7eb32a08a077b3a11888e6e80851bdf8511c6ed3210900eb03824251d7c8ed9e1f67bb9e32bfda7e
[kubernetes-client-darwin-arm64.tar.gz](https://dl.k8s.io/v1.37.0-rc.0/kubernetes-client-darwin-arm64.tar.gz) | 4e53a67653df939e6aa788b3bcda7856b0ea53a33fd6740ece621f19d0c2e3f17885e9aa7b2e3782c13ccda583c2f8c183cdd633b1e0b2e75239c6e113f8e6ba
[kubernetes-client-linux-386.tar.gz](https://dl.k8s.io/v1.37.0-rc.0/kubernetes-client-linux-386.tar.gz) | 5ed80e707364dd7f3317b399155c215c16f32b0f1d062ea78494f5ab5477fbfab8f82e5cf586e27ed25a392bba846fe076c30cf29fefb4639f2f27e008d4c73a
[kubernetes-client-linux-amd64.tar.gz](https://dl.k8s.io/v1.37.0-rc.0/kubernetes-client-linux-amd64.tar.gz) | 32b3028b1323ef4f5c9c91ccafbc4f5a676399c95e3e4bcf2d12da517d280f642983ecd294062f60de91be5dca760a923124551a88cdcbf4b2a5c52022554e08
[kubernetes-client-linux-arm.tar.gz](https://dl.k8s.io/v1.37.0-rc.0/kubernetes-client-linux-arm.tar.gz) | 8915fd35b74e0ebe567ae3079eb354bc01c1e05b32bf6a3bb5e4ef25a5bfdb34e39317bbddd99194fb5db456b063609d74a88f414a52f420d9b97ade169c452b
[kubernetes-client-linux-arm64.tar.gz](https://dl.k8s.io/v1.37.0-rc.0/kubernetes-client-linux-arm64.tar.gz) | 6412b3ccc3c41e8dea6b36f59bb29852c2669398a156ec1505898e9941febc6bdee9be7c27916f21a50e01f5b43f4acc67aaba470fd44234d70a61efabf2d907
[kubernetes-client-linux-ppc64le.tar.gz](https://dl.k8s.io/v1.37.0-rc.0/kubernetes-client-linux-ppc64le.tar.gz) | 5137df83ad807c45768c9b4367bffe53cd94af7e5dfcc7d969309e13685414b45937726f9216d381f014eacd1a87b7c33d327baeedbc79e134eb20ae03a43edf
[kubernetes-client-linux-s390x.tar.gz](https://dl.k8s.io/v1.37.0-rc.0/kubernetes-client-linux-s390x.tar.gz) | 48fbfcfbe0d626a45f5ca2cba43ac166721634670957d4720b941f9151d29c24caac3c1ae141cf6c8ae64f1e4bf74aa3393f3af9aef09676cc1308e6c0826ba6
[kubernetes-client-windows-386.tar.gz](https://dl.k8s.io/v1.37.0-rc.0/kubernetes-client-windows-386.tar.gz) | 7aa98634bf21f22b4c336827a3b5a02c0e6d73906e15f932b76f24dea86d045633b981559ad84f56cb05bd3afa9c0e439d7630f37ace2052e02bfa77d3991cda
[kubernetes-client-windows-amd64.tar.gz](https://dl.k8s.io/v1.37.0-rc.0/kubernetes-client-windows-amd64.tar.gz) | 86dde8efb63c89a38109402acffb3a238a0c76082f94481f76efda4ea6c9c367efec6d9788ab075724eabc3121bdceb0155ff6166e809a98cd7136851fb91812
[kubernetes-client-windows-arm64.tar.gz](https://dl.k8s.io/v1.37.0-rc.0/kubernetes-client-windows-arm64.tar.gz) | f69812e0396eb34695ac0f072ce6f899e06761e87afc9e322d9872ed83b66acc25d47584a8f413d0557ebbdbab56c4c34e9249079da964bec3c2b1d46f4eb909

### Server Binaries

filename | sha512 hash
-------- | -----------
[kubernetes-server-linux-amd64.tar.gz](https://dl.k8s.io/v1.37.0-rc.0/kubernetes-server-linux-amd64.tar.gz) | 977b34e8e8d5cdf4450fb4e8ab9bac97e95076617b8c64415a27573a7cca338e915efc6bf0bb3677de2770a54028fb1a8bb7ed1c612b843cd65b5cc623fa54f9
[kubernetes-server-linux-arm64.tar.gz](https://dl.k8s.io/v1.37.0-rc.0/kubernetes-server-linux-arm64.tar.gz) | 0c57da9963c24b1cf9ce9eaff2a0aac1c2ccb358ceb5ade7014577486b70f288884373d0dea500fe2e545af547c215b9422765d334cc7fb5450f137a770ec2f0
[kubernetes-server-linux-ppc64le.tar.gz](https://dl.k8s.io/v1.37.0-rc.0/kubernetes-server-linux-ppc64le.tar.gz) | 9227e6c134f999b5b7676222e5cc10a7e82e3777443339cb231d1b7a0fbbf90607c13a5beec980e9c9c28e4a695c554ef7ab31631156bbff9327f962287c041f
[kubernetes-server-linux-s390x.tar.gz](https://dl.k8s.io/v1.37.0-rc.0/kubernetes-server-linux-s390x.tar.gz) | 119ea6d4971177052b3adb6a0e27fcb125c4471f9c210fb56cc6835667b12b411bd61525b8c4203259a5dbf54f205e55a38b06b5d9194ad1514e37958d65e646

### Node Binaries

filename | sha512 hash
-------- | -----------
[kubernetes-node-linux-amd64.tar.gz](https://dl.k8s.io/v1.37.0-rc.0/kubernetes-node-linux-amd64.tar.gz) | 2d913c9e47149585a93f6b8fc1fb059ca6d830b23ff0f0d404baee7cddb78f808c03245e35aa66a739726579b34ec21fad5af64a323ae80bb9289d4a36177649
[kubernetes-node-linux-arm64.tar.gz](https://dl.k8s.io/v1.37.0-rc.0/kubernetes-node-linux-arm64.tar.gz) | f9b7d6d46c22e2cb0a66243df88064279e3814e12d952d8af441be01a25b9c739d704dbffc99c99d9ed7034dabf420eaeedee975602bc7eb95c1e6445360387a
[kubernetes-node-linux-ppc64le.tar.gz](https://dl.k8s.io/v1.37.0-rc.0/kubernetes-node-linux-ppc64le.tar.gz) | be1abf3347f64107b4eb4899f3dfc9492c7014297e29b36e31086fe8367599902a4b3e324b242c6ca817eabf5481cab45e99797d2a210e5449c9e1dc4d93bbc6
[kubernetes-node-linux-s390x.tar.gz](https://dl.k8s.io/v1.37.0-rc.0/kubernetes-node-linux-s390x.tar.gz) | b16a9382d7446ac66f1214f44ccb26b25cc9acb9f874761c4b52dc101d157ec2cc69c0ed140cd9801f63ede41371785593546d81b370e0840c31f548a747cc8f
[kubernetes-node-windows-amd64.tar.gz](https://dl.k8s.io/v1.37.0-rc.0/kubernetes-node-windows-amd64.tar.gz) | 157346216be6264261e2cc9911d08bd4b8f72b4c50c42d2423591e558f9b88363adf97d8ed04bb35019e6cc3bfd7200e52b1a019b28bd0724d51aa6c8b939a61

### Container Images

All container images are available as manifest lists and support the described
architectures. It is also possible to pull a specific architecture directly by
adding the "-$ARCH" suffix  to the container image name.

name | architectures
---- | -------------
[registry.k8s.io/conformance:v1.37.0-rc.0](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/conformance) | [amd64](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/conformance-amd64), [arm64](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/conformance-arm64), [ppc64le](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/conformance-ppc64le), [s390x](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/conformance-s390x)
[registry.k8s.io/kube-apiserver:v1.37.0-rc.0](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-apiserver) | [amd64](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-apiserver-amd64), [arm64](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-apiserver-arm64), [ppc64le](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-apiserver-ppc64le), [s390x](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-apiserver-s390x)
[registry.k8s.io/kube-controller-manager:v1.37.0-rc.0](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-controller-manager) | [amd64](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-controller-manager-amd64), [arm64](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-controller-manager-arm64), [ppc64le](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-controller-manager-ppc64le), [s390x](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-controller-manager-s390x)
[registry.k8s.io/kube-proxy:v1.37.0-rc.0](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-proxy) | [amd64](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-proxy-amd64), [arm64](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-proxy-arm64), [ppc64le](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-proxy-ppc64le), [s390x](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-proxy-s390x)
[registry.k8s.io/kube-scheduler:v1.37.0-rc.0](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-scheduler) | [amd64](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-scheduler-amd64), [arm64](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-scheduler-arm64), [ppc64le](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-scheduler-ppc64le), [s390x](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-scheduler-s390x)
[registry.k8s.io/kubectl:v1.37.0-rc.0](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kubectl) | [amd64](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kubectl-amd64), [arm64](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kubectl-arm64), [ppc64le](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kubectl-ppc64le), [s390x](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kubectl-s390x)

## Changelog since v1.37.0-beta.0

## Changes by Kind

### Dependency

- Updated google.golang.org/grpc to v1.82.1. This adds a server-side limit on HTTP/2 control frame flooding. It also removes the GRPC_GO_EXPERIMENTAL_DISABLE_STRICT_PATH_CHECKING environment variable, so strict path checking is now always on. ([#140740](https://github.com/kubernetes/kubernetes/pull/140740), [@dims](https://github.com/dims)) [SIG API Machinery, Architecture, Auth, CLI, Cloud Provider, Network, Node and Scheduling]

### API Change

- Add a new .spec.evictionResponders Pod field, EvictionRequest and Eviction Resource. This can be used by a set of requesters and responders to coordinate graceful eviction of pods. ([#137050](https://github.com/kubernetes/kubernetes/pull/137050), [@atiratree](https://github.com/atiratree)) [SIG API Machinery, Apps, Architecture, Auth, CLI, Etcd and Testing]
- Add alpha support (behind APIServerWebhookAuthenticationToken feature gate) for
  binding service account tokens to webhook configurations with attestations,
  enabling API servers to authenticate to admission webhooks with scoped tokens. ([#140113](https://github.com/kubernetes/kubernetes/pull/140113), [@pmengelbert](https://github.com/pmengelbert)) [SIG API Machinery, Apps, Auth and Testing]
- Add supports for CompositePodGroup to building block APIs and `workloadbuilder` library. ([#140717](https://github.com/kubernetes/kubernetes/pull/140717), [@helayoty](https://github.com/helayoty)) [SIG API Machinery, Apps, Auth, Scheduling and Testing]
- Added Alpha support for users to define the desired file owner of atomically written volume files. This is behind the `AtomicWriteVolumeUserFields` feature gate (disabled by default). ([#139764](https://github.com/kubernetes/kubernetes/pull/139764), [@gavinkflam](https://github.com/gavinkflam)) [SIG API Machinery, Apps, Auth, Storage and Testing]
- Added CheckpointPod and RestorePod RPCs to the CRI v1 RuntimeService API for Pod-level checkpoint and restore. ([#140366](https://github.com/kubernetes/kubernetes/pull/140366), [@rst0git](https://github.com/rst0git)) [SIG Node, Testing and Windows]
- Added DisruptionMode and PreemptionPolicy fields to Workload and CompositePodGroup APIs to support workload-aware preemption for CompositePodGroups. ([#140634](https://github.com/kubernetes/kubernetes/pull/140634), [@tosi3k](https://github.com/tosi3k)) [SIG API Machinery, Auth, Etcd, Node, Scheduling and Testing]
- Added a new beta feature gate SchedulerPreQueueingHints (on by default). When enabled, scheduler plugins can provide a PreQueueingHintFn that narrows the set of pods evaluated on cluster events, improving scheduling throughput. The DRA plugin implements this to optimize ResourceClaimTemplate-based workloads. ([#138916](https://github.com/kubernetes/kubernetes/pull/138916), [@geetasg](https://github.com/geetasg)) [SIG API Machinery, Apps, Architecture, Auth, CLI, Cloud Provider, Instrumentation, Network, Node, Scheduling, Storage, Testing and Windows]
- Added a second alpha of DRA resource availability visibility (KEP-5677, feature gate `DRAResourcePoolStatus`, default off): the ResourcePoolStatusRequest controller now counts partitionable and consumable devices correctly (each device counted once, AdminAccess ignored, taints treated as unavailable), and new optional fields describe partition and shareable availability. The accounting fixes change the numbers reported by 1.36. ([#140170](https://github.com/kubernetes/kubernetes/pull/140170), [@nmn3m](https://github.com/nmn3m)) [SIG API Machinery, Apps, Auth, Node and Testing]
- Added alpha support for DRA device compatibility groups, guarded by the new 
  `DRADeviceCompatibilityGroups` feature gate (off by default). 
  DRA drivers can declare opaque `compatibilityGroups` on each `device.consumesCounters[]` 
  entry of a ResourceSlice, and the scheduler only co-allocates devices drawing from the same 
  counter set when their declared groups intersect, moving detection of incompatible co-allocation 
  from preparation-time failure to scheduling-time rejection. ([#139795](https://github.com/kubernetes/kubernetes/pull/139795), [@omeryahud](https://github.com/omeryahud)) [SIG API Machinery, Node, Scheduling and Testing]
- Added kubelet configuration field `DefaultPodSysctls` for default Pod sysctls on Linux nodes. This is Alpha and behind the off-by-default `DefaultPodSysctls` feature gate. ([#140052](https://github.com/kubernetes/kubernetes/pull/140052), [@VeraQin](https://github.com/VeraQin)) [SIG Node and Testing]
- Added support for derived attributes in DRA, allowing claims to define virtual attributes using CEL expressions and use them in device constraints. This enables co-allocation of devices across different domains (e.g. GPUs and NICs on the same NUMA node) even if their drivers publish physical attributes differently. ([#140029](https://github.com/kubernetes/kubernetes/pull/140029), [@gauravkghildiyal](https://github.com/gauravkghildiyal)) [SIG API Machinery, Node, Scheduling and Testing]
- Added support for selecting ResourceSlices by pool name with the field selector `spec.pool.name`. ([#138456](https://github.com/kubernetes/kubernetes/pull/138456), [@yaroslavborbat](https://github.com/yaroslavborbat)) [SIG API Machinery, Node and Testing]
- Adds protocol field to httpGet probes to run HTTP/2 cleartext (H2C) liveness, readiness, and startup probes. ([#139429](https://github.com/kubernetes/kubernetes/pull/139429), [@amritansh1502](https://github.com/amritansh1502)) [SIG API Machinery, Apps, Node and Testing]
- Allow API server CBOR encoder to encode collections item by item, instead of all at once. ([#138808](https://github.com/kubernetes/kubernetes/pull/138808), [@chenk008](https://github.com/chenk008)) [SIG API Machinery, Apps, Auth, Autoscaling, CLI, Cloud Provider, Cluster Lifecycle, Contributor Experience, Instrumentation, Network, Node, Release, Scalability, Scheduling, Storage, Testing and Windows]
- Client-go: with very few exceptions, context.TODO calls got removed by introducing new APIs where the caller passes in the context. Log calls use the logger provided by the caller when available. ([#129125](https://github.com/kubernetes/kubernetes/pull/129125), [@pohly](https://github.com/pohly)) [SIG API Machinery, Apps, Architecture, Auth, CLI, Cloud Provider, Instrumentation, Network, Node, Storage and Testing]
- DRA device metadata v1alpha1 now provides generated declarative validation functions for Go consumers. ([#140687](https://github.com/kubernetes/kubernetes/pull/140687), [@alaypatel07](https://github.com/alaypatel07)) [SIG Node]
- DRA metadata API: the feature is now beta. DRA driver authors must explicitly select which versions to support in their metadata output if they enable the feature. ([#140722](https://github.com/kubernetes/kubernetes/pull/140722), [@pohly](https://github.com/pohly)) [SIG Node and Testing]
- DRA: Introduced alpha support for `DRAOptionalNodeOperations` (`SkipNodeOperations` field in ResourceSlice and ResourceClaim) to allow skipping node-level preparation and cleanup operations. ([#139933](https://github.com/kubernetes/kubernetes/pull/139933), [@troychiu](https://github.com/troychiu)) [SIG API Machinery, Autoscaling, Instrumentation, Node, Release, Scheduling and Testing]
- Graduated _Pod hostname overrides_ to GA. The `HostnameOverride` feature gate is now locked to enabled. ([#139116](https://github.com/kubernetes/kubernetes/pull/139116), [@HirazawaUi](https://github.com/HirazawaUi)) [SIG API Machinery, Apps, Node and Testing]
- Implement APIs required for reporting volume health ([#140194](https://github.com/kubernetes/kubernetes/pull/140194), [@gnufied](https://github.com/gnufied)) [SIG API Machinery, Apps, Architecture, Auth, Etcd, Instrumentation, Node, Storage and Testing]
- KEP-2033: promote KubeletInUserNamespace feature to beta ([#134639](https://github.com/kubernetes/kubernetes/pull/134639), [@AkihiroSuda](https://github.com/AkihiroSuda)) [SIG API Machinery, Apps, Node and Testing]
- Kubelet: add support for TLS when using gRPC container probes (behind feature gate; see KEP-4939). ([#137762](https://github.com/kubernetes/kubernetes/pull/137762), [@amritansh1502](https://github.com/amritansh1502)) [SIG API Machinery, Apps, Node and Testing]
- Move prevention of pod scheduling to nodes without CSI driver beta ([#140612](https://github.com/kubernetes/kubernetes/pull/140612), [@gnufied](https://github.com/gnufied)) [SIG API Machinery, Storage and Testing]
- Opt-in userspace TCP proxy to the nftables kube-proxy backend to serve localhost NodePort services on IPv4 and IPv6. ([#138427](https://github.com/kubernetes/kubernetes/pull/138427), [@AustinAbro321](https://github.com/AustinAbro321)) [SIG Instrumentation, Network and Testing]
- Promote MemoryQoS to beta. memoryThrottlingFactor now defaults to nil; memory.high is not set unless explicitly configured. ([#140007](https://github.com/kubernetes/kubernetes/pull/140007), [@QiWang19](https://github.com/QiWang19)) [SIG Node and Testing]
- Promoted DRA Workload resource claims to Beta. The `DRAWorkloadResourceClaims` feature gate remains disabled by default. ([#140334](https://github.com/kubernetes/kubernetes/pull/140334), [@nojnhuh](https://github.com/nojnhuh)) [SIG API Machinery, Apps, Etcd, Node, Scheduling and Testing]
- Support Workload-aware scheduling (WAS) APIs by integrating Job controller with workloadbuilder library and the Workload building blocks APIs. ([#140188](https://github.com/kubernetes/kubernetes/pull/140188), [@helayoty](https://github.com/helayoty)) [SIG API Machinery, Apps, Auth, Network, Node, Scheduling, Storage and Testing]
- Support dynamically resizing memory-backed volumes behind the Alpha feature gate `InPlacePodVerticalScalingMemoryBackedVolumes`. ([#139425](https://github.com/kubernetes/kubernetes/pull/139425), [@natasha41575](https://github.com/natasha41575)) [SIG API Machinery, Apps, Autoscaling, CLI, Node, Scheduling, Storage and Testing]
- The DRAResourceHealth kubelet gRPC API has been promoted to v1; the schema is unchanged from v1alpha1. `DRAPlugin.WatchHealthStatus` is a new mandatory method on the `k8s.io/dynamic-resource-allocation/kubeletplugin` helper's `DRAPlugin` interface, replacing the optional versioned gRPC interface (one-time Go API break, existing drivers must add the method to compile). Drivers without health support return `ErrHealthNotSupported` from it or disable the service with `HealthService(false)`. The helper serves both v1 and v1alpha1 by default, so drivers report health on kubelets 1.36 and older without extra configuration. The kubelet prefers v1 and, for three releases of transition, still consumes v1alpha1 from drivers which shipped before v1 existed. The v1alpha1 DRAResourceHealth API is deprecated and gets removed in the 1.40 era. The kubelet only opens the device health stream for plugins that advertise the service. ([#139477](https://github.com/kubernetes/kubernetes/pull/139477), [@harche](https://github.com/harche)) [SIG Node and Testing]
- The Pod Certificates feature is moving to GA. The PodCertificateRequest feature gate is set true by default. Two fields PKIXPublicKey and ProofOfPossession which were deprecated in PodCertificateRequest v1beta1 are removed from the v1 API. ([#139579](https://github.com/kubernetes/kubernetes/pull/139579), [@yt2985](https://github.com/yt2985)) [SIG API Machinery, Apps, Architecture, Auth, Etcd, Node, Scheduling and Testing]
- The core Workload-Aware Scheduling (WAS) API types `Workload` and `PodGroup` are promoted to scheduling.k8s.io/v1beta1. If using the v1alpha2 version in 1.36, remember to remove all `v1alpha2` objects from the api-server before upgrading from 1.36 to 1.37. ([#140184](https://github.com/kubernetes/kubernetes/pull/140184), [@tosi3k](https://github.com/tosi3k)) [SIG API Machinery, Apps, Auth, Etcd, Node, Scheduling and Testing]
- The unsafe corrupt object deletion feature now supports dry-run mode, allowing administrators to test deletion operations safely before execution. ([#134037](https://github.com/kubernetes/kubernetes/pull/134037), [@ibihim](https://github.com/ibihim)) [SIG API Machinery and Testing]
- This change updates the DRANodeAllocatableResources alpha feature, which includes:
  
  - Updating ResourceSlice mappings and PodStatus to support direct allocations (for DRA drivers modeling CPU/memory/hugepages as a resource) and overhead allocations (for accelerator host overhead).
  - Updating kubelet to account for DRA allocated resources while configuring pod and container cgroups, OOM scores, and Memory QoS thresholds.
  - Allowing in-place resizing of standard resource requests and limits for pods utilizing DRA claims.
  - Updating the scheduler to support unreferenced pod-level claims, enforce resource limits with DRA, and enforce claim sharing rules (allowing claim sharing across pods for overhead allocations).
  - Updating validation to enforce constraints for the updated API and using node declared features to ensure target nodes have the NodeAllocatableDRA feature gate enabled. ([#140009](https://github.com/kubernetes/kubernetes/pull/140009), [@pravk03](https://github.com/pravk03)) [SIG API Machinery, Apps, Auth, Autoscaling, Node, Scheduling and Testing]
- Update validation logic for container security context to allow edits to pods to have allowPrivilegeEscalation and CAP_SYSADMIN. In the future, this relaxation will apply for pod creation as well. ([#138834](https://github.com/kubernetes/kubernetes/pull/138834), [@haircommander](https://github.com/haircommander)) [SIG Apps]
- Users can set Unix permission bits (0000-01777) through the 'mode' field on emptyDir volume directories at creation time. ([#140244](https://github.com/kubernetes/kubernetes/pull/140244), [@nispriha](https://github.com/nispriha)) [SIG API Machinery, Apps, Node, Storage and Testing]
- Users can specify bind mount options (noexec, nodev, nosuid) per container volume mount. ([#140013](https://github.com/kubernetes/kubernetes/pull/140013), [@nispriha](https://github.com/nispriha)) [SIG API Machinery, Apps, Autoscaling, Node, Scheduling and Testing]

### Feature

- A new `allocatedPods` kubelet endpoint surfaces the Kubelet's allocated pod spec. This can be used to debug in-place pod resizing and other issues with pod updates. Requires the `KubeletAllocatedPodsEndpoint` FeatureGate. ([#140856](https://github.com/kubernetes/kubernetes/pull/140856), [@tallclair](https://github.com/tallclair)) [SIG Node and Testing]
- Add `cpu_ids` and `memory` fields at the pod level to the `PodResources` v1 API to
  report total allocated pod resources, while only return container-level allocations for
  container-isolated containers. ([#138738](https://github.com/kubernetes/kubernetes/pull/138738), [@KevinTMtz](https://github.com/KevinTMtz)) [SIG Node and Testing]
- Add a --proxy-url flag to kubectl to override the proxy URL configured in kubeconfig. ([#139862](https://github.com/kubernetes/kubernetes/pull/139862), [@Mujib-Ahasan](https://github.com/Mujib-Ahasan)) [SIG CLI]
- Add alpha kubelet metric `kubelet_pod_deferred_resize_duration_seconds` histogram and add `priority_bucket` label to `kubelet_pod_pending_resizes` gauge. ([#140122](https://github.com/kubernetes/kubernetes/pull/140122), [@natasha41575](https://github.com/natasha41575)) [SIG Instrumentation and Node]
- Added a new alpha Kubelet metric, pod_level_resources_admission_total, to track feature adoption for KEP-2837 (Pod-Level Resources) upon pod admission, categorized by resource configuration mode and QoS class ([#140463](https://github.com/kubernetes/kubernetes/pull/140463), [@ndixita](https://github.com/ndixita)) [SIG Instrumentation and Node]
- Added scheduler performance benchmark suites comparing preemption behavior across standalone (non-PodGroup) pods and PodGroups with `single` and `all` disruption modes, and reorganized default preemption performance tests into a dedicated directory. ([#140651](https://github.com/kubernetes/kubernetes/pull/140651), [@vshkrabkov](https://github.com/vshkrabkov)) [SIG Scheduling and Testing]
- Added the `storage_to_cache` stage to `apiserver_watch_events_dispatch_duration_seconds` ALPHA metric to track the latency from backend decode to watch cache ingestion. ([#140860](https://github.com/kubernetes/kubernetes/pull/140860), [@richabanker](https://github.com/richabanker)) [SIG API Machinery and Instrumentation]
- Adds "cache_to_watcher" stage to apiserver_watch_events_dispatch_duration_seconds ALPHA metric to measure the latency incurred when pushing events to a watcher's result channel ([#140851](https://github.com/kubernetes/kubernetes/pull/140851), [@richabanker](https://github.com/richabanker)) [SIG API Machinery and Instrumentation]
- Adds apiserver_watch_events_dispatch_duration_seconds alpha metric to record the duration from when a watch event is decoded from etcd until it is successfully written to the watcher's outgoing result channel. ([#140336](https://github.com/kubernetes/kubernetes/pull/140336), [@richabanker](https://github.com/richabanker)) [SIG API Machinery, Etcd and Instrumentation]
- Adds new buckets for watch_list_duration_seconds metric- 90s, 120s, 180s, 300s ([#140757](https://github.com/kubernetes/kubernetes/pull/140757), [@richabanker](https://github.com/richabanker)) [SIG API Machinery and Instrumentation]
- Data in DRA-related fields in pod status (resourceClaimStatuses, extendedResourceClaimStatus, and nodeAllocatableResourceClaimStatuses) is now preserved when handling pod status updates that omit those fields. This prevents data loss due to updates from old clients accidentally unsetting these DRA fields, which could leave pods permanently stuck in Terminating. ([#139876](https://github.com/kubernetes/kubernetes/pull/139876), [@ashishpatel26](https://github.com/ashishpatel26)) [SIG API Machinery, Auth, Node, Scheduling and Testing]
- Improved scheduling performance for required pod (anti)affinity with topologyKey: kubernetes.io/hostname.
  
  The changes are guarded with the InterPodAffinityHostnameFastPath feature flag. ([#138198](https://github.com/kubernetes/kubernetes/pull/138198), [@tetianakh](https://github.com/tetianakh)) [SIG Apps, Node, Scheduling and Testing]
- Kube-scheduler now publishes the client-go informer metrics informer_store_resource_version, informer_queued_items and informer_processing_latency_seconds, labelled name="kube-scheduler". ([#140511](https://github.com/kubernetes/kubernetes/pull/140511), [@Jefftree](https://github.com/Jefftree)) [SIG Scheduling and Testing]
- Kubectl top support v1.metrics.k8s.io ([#139726](https://github.com/kubernetes/kubernetes/pull/139726), [@tico88612](https://github.com/tico88612)) [SIG CLI and Instrumentation]
- Kubelet PodsAPI gRPC service promoted to Beta. ([#140286](https://github.com/kubernetes/kubernetes/pull/140286), [@briansonnenberg](https://github.com/briansonnenberg)) [SIG Instrumentation, Node and Testing]
- Make SchedulerPreQueueingHints alpha for some known issues that were discovered at the last minutes. ([#140959](https://github.com/kubernetes/kubernetes/pull/140959), [@sanposhiho](https://github.com/sanposhiho)) [SIG Scheduling]
- PLEGOnDemandRelist is now GA ([#140805](https://github.com/kubernetes/kubernetes/pull/140805), [@tallclair](https://github.com/tallclair)) [SIG Node]
- Pod group preemption will now be run after a failed pod group scheduling attempt for pod groups with Scheduling Constraints. ([#140683](https://github.com/kubernetes/kubernetes/pull/140683), [@Argh4k](https://github.com/Argh4k)) [SIG API Machinery, Scheduling and Testing]
- Promote PodReadyToStartContainers condition to GA. ([#140488](https://github.com/kubernetes/kubernetes/pull/140488), [@Priyankasaggu11929](https://github.com/Priyankasaggu11929)) [SIG Node and Testing]
- Promote `InPlacePodVerticalScalingInitContainers` to GA. ([#140728](https://github.com/kubernetes/kubernetes/pull/140728), [@natasha41575](https://github.com/natasha41575)) [SIG Apps and Node]
- Promoted the `DRAResourceClaimDeviceStatus` feature gate to GA. ([#137546](https://github.com/kubernetes/kubernetes/pull/137546), [@LionelJouin](https://github.com/LionelJouin)) [SIG Node and Testing]
- Reduced the scope of `EventedPLEG` to only accelerate detection of unexpected container terminations. ([#139262](https://github.com/kubernetes/kubernetes/pull/139262), [@HirazawaUi](https://github.com/HirazawaUi)) [SIG Node]
- Scheduler metrics for the topology-aware scheduling (TAS) placement phases available when the TopologyAwareWorkloadScheduling feature gate is enabled: scheduler_generated_placements_total, scheduler_placement_evaluations_total, and scheduler_placement_evaluation_duration_seconds. ([#139604](https://github.com/kubernetes/kubernetes/pull/139604), [@alimaazamat](https://github.com/alimaazamat)) [SIG Instrumentation, Scheduling and Testing]
- The AllowUnsafeMalformedObjectDeletion feature is now beta and enabled by default. List errors for objects that cannot be read from the storage now include the first underlying cause in the error message. ([#140785](https://github.com/kubernetes/kubernetes/pull/140785), [@ibihim](https://github.com/ibihim)) [SIG API Machinery and Etcd]
- The `ConcurrentWatchObjectDecode` feature gate has graduated to beta and is enabled by default. ([#139679](https://github.com/kubernetes/kubernetes/pull/139679), [@Jefftree](https://github.com/Jefftree)) [SIG API Machinery and Etcd]
- The `PodLevelResourceManagers` feature is now enabled by default (Beta) in Kubernetes 1.37. ([#140573](https://github.com/kubernetes/kubernetes/pull/140573), [@KevinTMtz](https://github.com/KevinTMtz)) [SIG Node and Testing]
- The `dynamic_resource_allocation_resourceclaim_creates_total` metric has new `owner_api_group` and `owner_api_kind` labels to distinguish between ResourceClaims created for Pods with those created for PodGroups (using the DRAWorkloadResourceClaims feature). ([#140422](https://github.com/kubernetes/kubernetes/pull/140422), [@nojnhuh](https://github.com/nojnhuh)) [SIG API Machinery, Apps, Instrumentation, Node, Scheduling and Testing]
- The `route_sync_total` metric now records an `error` outcome when a route reconcile fails, in addition to the existing `changed` and `noop` outcomes. ([#140824](https://github.com/kubernetes/kubernetes/pull/140824), [@lukasmetzner](https://github.com/lukasmetzner)) [SIG Cloud Provider and Instrumentation]
- The route controller ALPHA metric `route_controller_route_sync_total` now carries two labels: `trigger` (`periodic` or `node_change`) and `outcome` (`changed` or `noop`). This lets operators observe how often periodic reconciliation is correcting route drift versus running as a no-op. ([#140147](https://github.com/kubernetes/kubernetes/pull/140147), [@lukasmetzner](https://github.com/lukasmetzner)) [SIG Cloud Provider and Instrumentation]
- Update PodAndContainerStatsFromCRI to off-by-default beta ([#140081](https://github.com/kubernetes/kubernetes/pull/140081), [@dgrisonnet](https://github.com/dgrisonnet)) [SIG Node]

### Bug or Regression

- Added `apiserver_storage_list_duration_seconds`, a metric measuring end-to-end apiserver list latency (etcd read plus object decode), labelled by whether etcd RangeStream was used, so streamed and non-streamed lists can be compared directly. ([#140697](https://github.com/kubernetes/kubernetes/pull/140697), [@Jefftree](https://github.com/Jefftree)) [SIG API Machinery, Etcd and Instrumentation]
- Client-go: FakeCustomStore implements the Bookmark and LastStoreSyncResourceVersion methods added to the cache.Store interface in v0.36, so it satisfies cache.Store again ([#140966](https://github.com/kubernetes/kubernetes/pull/140966), [@alancaldelas](https://github.com/alancaldelas)) [SIG API Machinery]
- DRA: fixed a bug where a (rare) missed informer update of a ResourceClaim could have caused pods to remain pending until the unschedulable queue gets flushed. ([#140831](https://github.com/kubernetes/kubernetes/pull/140831), [@pohly](https://github.com/pohly)) [SIG Node and Scheduling]
- Fix a bug where non-admitted pods can briefly count against allocated budget, causing spurious failures for reasonably sized pods. ([#139522](https://github.com/kubernetes/kubernetes/pull/139522), [@haircommander](https://github.com/haircommander)) [SIG Node]
- Fix a kubelet bug where init containers could be skipped when a pod sandbox is recreated while a previous-sandbox main container is still known to the container runtime. ([#138514](https://github.com/kubernetes/kubernetes/pull/138514), [@chez-shanpu](https://github.com/chez-shanpu)) [SIG Node]
- Fixed 409 Conflict errors between the PVC protection controller and the PV binder during initial PVC binding. The `Unused` condition is now evaluated only after the PVC is bound. ([#140833](https://github.com/kubernetes/kubernetes/pull/140833), [@huww98](https://github.com/huww98)) [SIG Apps and Storage]
- Fixed MemoryQoS pod-level memory protection (memory.min, memory.low) being silently dropped during in-place pod resize, and added pod-level memory.high enforcement when PodLevelResources is enabled. ([#140262](https://github.com/kubernetes/kubernetes/pull/140262), [@sohankunkerkar](https://github.com/sohankunkerkar)) [SIG Node and Testing]
- Fixed a DRA consumable-capacity scheduling bug: a device that consumes shared counters could have them counted twice when it already had a persisted shared allocation with no consumed capacity, wrongly rejecting a later claim for the same device and leaving the pod pending. ([#140437](https://github.com/kubernetes/kubernetes/pull/140437), [@thc1006](https://github.com/thc1006)) [SIG Node and Scheduling]
- Fixed a bug where ResourceClaims using `allocationMode: All` with consumable capacity could be partially allocated when a matching device had insufficient remaining capacity. Such claims now correctly fail to allocate until all matching devices can be satisfied. ([#140769](https://github.com/kubernetes/kubernetes/pull/140769), [@kiarashazarnia](https://github.com/kiarashazarnia)) [SIG Node]
- Fixed a v1.35 regression where exec readiness probes stopped executing (failing with "context canceled") once a pod began graceful termination, leaving the pod's Ready condition frozen during shutdown. ([#140882](https://github.com/kubernetes/kubernetes/pull/140882), [@karlkfi](https://github.com/karlkfi)) [SIG Node]
- Fixed an issue where a PodGroup preemption that detected ongoing preemption would clear NNN of pod group pods. ([#140641](https://github.com/kubernetes/kubernetes/pull/140641), [@Argh4k](https://github.com/Argh4k)) [SIG Scheduling and Testing]
- Fixed capacity accounting in the DRA consumable-capacity allocator. A capacity request that a device's integer or milli-value range arithmetic cannot represent, or that resolves to a negative value, is now rejected instead of being treated as satisfiable and wrongly allocating a device or capping it to a smaller value. ([#140442](https://github.com/kubernetes/kubernetes/pull/140442), [@thc1006](https://github.com/thc1006)) [SIG Node]
- Fixes handling of admission to allow updates to namespaced objects that exist after their namespace was deleted. ([#140661](https://github.com/kubernetes/kubernetes/pull/140661), [@sanchezl](https://github.com/sanchezl)) [SIG API Machinery and Testing]
- Kube-proxy enables netlink support by default in nftables mode. Kube-proxy will now use netlink directly for listing rules and chains, which improves performance by avoiding executing and parsing the `nft` command-line binary. This behavior can be disabled using the `NFTablesNetlink` feature gate (Beta, enabled by default). ([#137536](https://github.com/kubernetes/kubernetes/pull/137536), [@aojea](https://github.com/aojea)) [SIG Network and Testing]
- Kubectl now includes the group name in the error message when a resource type is not found under the specified group, e.g. "the server doesn't have a resource type \"pdb\" in group \"hpa\"". ([#140759](https://github.com/kubernetes/kubernetes/pull/140759), [@makeittotop](https://github.com/makeittotop)) [SIG CLI]
- Kubelet/DRA: fixed a bug where retrying a partially-failed PrepareResources caused duplicate CDI device IDs to be passed to the CRI runtime, which could cause container start to fail. ([#140274](https://github.com/kubernetes/kubernetes/pull/140274), [@bart0sh](https://github.com/bart0sh)) [SIG Node]
- Kubelet: The new DefaultPodSysctls feature treats an unset `spec.hostUsers` as true when evaluating `user.*` sysctls. ([#140892](https://github.com/kubernetes/kubernetes/pull/140892), [@weizhoublue](https://github.com/weizhoublue)) [SIG Node]
- Kubelet: fix wrong Pod-level CPU requests status from cgroup v2 readback ([#137660](https://github.com/kubernetes/kubernetes/pull/137660), [@pacoxu](https://github.com/pacoxu)) [SIG Node]
- Kubelet: node events recorded by the kubelet now populate `involvedObject.uid` on a best-effort basis once the node is registered, so node events can be correlated by UID (for example in `kubectl describe node`). The UID is resolved once and not refreshed afterward. If a node is deleted and recreated with a new UID while the kubelet keeps running, its events continue to use the original UID until the kubelet restarts. ([#139921](https://github.com/kubernetes/kubernetes/pull/139921), [@harche](https://github.com/harche)) [SIG Node]
- Setting a certificate authority path that is outside of the `.kube/config` folder on Windows will no longer result in a relative path being used to match the behavior on other OS. ([#135735](https://github.com/kubernetes/kubernetes/pull/135735), [@bliles](https://github.com/bliles)) [SIG API Machinery]
- The error message from PodGroupPostFilter now contains correct extension point name. ([#140747](https://github.com/kubernetes/kubernetes/pull/140747), [@Argh4k](https://github.com/Argh4k)) [SIG Scheduling]
- The feature gate `PodLevelResourceManagers` is disabled by default. ([#141209](https://github.com/kubernetes/kubernetes/pull/141209), [@SergeyKanzhelev](https://github.com/SergeyKanzhelev)) [SIG Node]

### Other (Cleanup or Flake)

- Avoid using a maps for single-endpoint services in kube-proxy's nftables mode to increase speed of programming nftables ([#140723](https://github.com/kubernetes/kubernetes/pull/140723), [@adrianmoisey](https://github.com/adrianmoisey)) [SIG Network]
- DRA: fixed a potential crash in the scheduler (recovered after restart) when the ResourceSlice tracker encounters an OnDelete event for DeviceTaintRule where the deleted object is unknown. ([#140193](https://github.com/kubernetes/kubernetes/pull/140193), [@pohly](https://github.com/pohly)) [SIG API Machinery and Node]
- DRA: the DRAPrioritizedList feature gate for the Prioritized List feature (GA in 1.36) is now locked to enabled-by-default and thus cannot be disabled anymore. ([#139110](https://github.com/kubernetes/kubernetes/pull/139110), [@mortent](https://github.com/mortent)) [SIG Node, Scheduling and Testing]
- The scheduler's opportunistic batching feature now rescores the previously                                                                                                                                                             
    chosen node when it is still feasible, allowing it to compete with cached                                                                                                                                                              
    candidates for the next hint rather than always skipping it. ([#140289](https://github.com/kubernetes/kubernetes/pull/140289), [@romanbaron](https://github.com/romanbaron)) [SIG API Machinery, Etcd, Instrumentation, Scheduling and Testing]

## Dependencies

### Added
- github.com/go-openapi/swag/pools: [v0.27.1](https://github.com/go-openapi/swag/commit/c8a41f7226ee09d8f74ac3e9375d071041836b7c)
- github.com/google/nftables: [v0.3.0](https://github.com/google/nftables/commit/6f574e7fd1b4d07006d1c598cdb9b22789e5e541)
- github.com/mdlayher/netlink: [v1.11.2](https://github.com/mdlayher/netlink/commit/847c7b8181120b0e93dd7174b64914995edcfade)
- github.com/mdlayher/socket: [v0.6.1](https://github.com/mdlayher/socket/commit/c20d4c5139659b34b209af2556fef46e867eb62e)

### Changed
- github.com/GoogleCloudPlatform/opentelemetry-operations-go/detectors/gcp: [v1.31.0 → v1.32.0](https://github.com/GoogleCloudPlatform/opentelemetry-operations-go/compare/v1.31.0...v1.32.0)
- github.com/container-storage-interface/spec: [v1.9.0 → cd9e7ad](https://github.com/container-storage-interface/spec/compare/v1.9.0...cd9e7ad1ae0915cabcad179f2b8a660c0cb6eb9f)
- github.com/go-openapi/jsonpointer: [v0.22.4 → v1.0.0](https://github.com/go-openapi/jsonpointer/compare/v0.22.4...v1.0.0)
- github.com/go-openapi/jsonreference: [v0.21.4 → v1.0.0](https://github.com/go-openapi/jsonreference/compare/v0.21.4...v1.0.0)
- github.com/go-openapi/swag: [v0.25.4 → v0.27.1](https://github.com/go-openapi/swag/compare/v0.25.4...v0.27.1)
- github.com/go-openapi/swag/cmdutils: [v0.25.4 → v0.27.1](https://github.com/go-openapi/swag/compare/cmdutils/v0.25.4...cmdutils/v0.27.1)
- github.com/go-openapi/swag/conv: [v0.25.4 → v0.27.1](https://github.com/go-openapi/swag/compare/conv/v0.25.4...conv/v0.27.1)
- github.com/go-openapi/swag/fileutils: [v0.25.4 → v0.27.1](https://github.com/go-openapi/swag/compare/fileutils/v0.25.4...fileutils/v0.27.1)
- github.com/go-openapi/swag/jsonutils: [v0.25.4 → v0.27.1](https://github.com/go-openapi/swag/compare/jsonutils/v0.25.4...jsonutils/v0.27.1)
- github.com/go-openapi/swag/jsonutils/fixtures_test: [v0.25.4 → v0.27.1](https://github.com/go-openapi/swag/compare/master...jsonutils/fixtures_test/v0.27.1)
- github.com/go-openapi/swag/loading: [v0.25.4 → v0.27.1](https://github.com/go-openapi/swag/compare/loading/v0.25.4...loading/v0.27.1)
- github.com/go-openapi/swag/mangling: [v0.25.4 → v0.27.1](https://github.com/go-openapi/swag/compare/mangling/v0.25.4...mangling/v0.27.1)
- github.com/go-openapi/swag/netutils: [v0.25.4 → v0.27.1](https://github.com/go-openapi/swag/compare/netutils/v0.25.4...netutils/v0.27.1)
- github.com/go-openapi/swag/stringutils: [v0.25.4 → v0.27.1](https://github.com/go-openapi/swag/compare/stringutils/v0.25.4...stringutils/v0.27.1)
- github.com/go-openapi/swag/typeutils: [v0.25.4 → v0.27.1](https://github.com/go-openapi/swag/compare/typeutils/v0.25.4...typeutils/v0.27.1)
- github.com/go-openapi/swag/yamlutils: [v0.25.4 → v0.27.1](https://github.com/go-openapi/swag/compare/yamlutils/v0.25.4...yamlutils/v0.27.1)
- github.com/go-openapi/testify/enable/yaml/v2: [v2.0.2 → v2.6.0](https://github.com/go-openapi/testify/compare/enable/yaml/v2.0.2...enable/yaml/v2.6.0)
- github.com/go-openapi/testify/v2: [v2.0.2 → v2.6.0](https://github.com/go-openapi/testify/compare/v2.0.2...v2.6.0)
- github.com/google/cadvisor/lib: [v0.60.4 → v0.60.5](https://github.com/google/cadvisor/compare/lib/v0.60.4...lib/v0.60.5)
- github.com/google/cel-go: [v0.27.0 → v0.29.2](https://github.com/google/cel-go/compare/v0.27.0...v0.29.2)
- github.com/klauspost/compress: [v1.18.0 → v1.19.0](https://github.com/klauspost/compress/compare/v1.18.0...v1.19.0)
- github.com/prometheus/client_golang: [v1.23.2 → v1.24.0](https://github.com/prometheus/client_golang/compare/v1.23.2...v1.24.0)
- github.com/prometheus/common: [v0.67.5 → v0.70.0](https://github.com/prometheus/common/compare/v0.67.5...v0.70.0)
- github.com/prometheus/procfs: [v0.19.2 → v0.21.1](https://github.com/prometheus/procfs/compare/v0.19.2...v0.21.1)
- go.opentelemetry.io/contrib/detectors/gcp: [v1.42.0 → v1.43.0](https://github.com/open-telemetry/opentelemetry-go-contrib/compare/detectors/gcp/v1.42.0...detectors/gcp/v1.43.0)
- google.golang.org/grpc: [v1.81.1 → v1.82.1](https://github.com/grpc/grpc-go/compare/v1.81.1...v1.82.1)
- k8s.io/kube-openapi: [bc653b6 → d427ff9](https://github.com/kubernetes/kube-openapi/compare/bc653b64f9748b1f57d580a5e57be90d295d9b46...d427ff9ee9ad05f5da435abbb7c5929cb713ac56)
- sigs.k8s.io/knftables: [v0.0.21 → v0.0.22](https://github.com/kubernetes-sigs/knftables/compare/v0.0.21...v0.0.22)

### Removed
- github.com/go-openapi/swag/jsonname: [v0.25.4](https://github.com/go-openapi/swag/commit/73525ad4f9d84ce7e4b15796f0d41a6cb32cc3cd)



# v1.37.0-beta.0


## Downloads for v1.37.0-beta.0



### Source Code

filename | sha512 hash
-------- | -----------
[kubernetes.tar.gz](https://dl.k8s.io/v1.37.0-beta.0/kubernetes.tar.gz) | f9d5a3e658affdbb2a238fccd85c8761386302ee46d262b4440fd2813f4676bac02f3549c09f29b9a598905d461ab559d41a349ce8c2fb3528e8760bd5969ffc
[kubernetes-src.tar.gz](https://dl.k8s.io/v1.37.0-beta.0/kubernetes-src.tar.gz) | 2e2ac730f6f5a2d63986e2939d353f10c10c44293e6cd0de53bcb2796ca7f89d3b0cf8363063241ddf1f1ef997f9e01433ba4e98e04886b2c9c9fa363361faff

### Client Binaries

filename | sha512 hash
-------- | -----------
[kubernetes-client-darwin-amd64.tar.gz](https://dl.k8s.io/v1.37.0-beta.0/kubernetes-client-darwin-amd64.tar.gz) | bb36f64627b9b851cf3bba0ce60d3577578c4757140e027085e02f13e30a9cc1a13fb90c29083b6ba1b4da1f4e2e698f70d0fdf0ff11827ce34b8b112646959f
[kubernetes-client-darwin-arm64.tar.gz](https://dl.k8s.io/v1.37.0-beta.0/kubernetes-client-darwin-arm64.tar.gz) | 725cf0cae1295786726be1c8b461248923afdcdedb8b83c4a457da3355dff66e7205c57ad9f721fde143e9f0f4b59fd4c4fd628e347f3ce2e55fc2fb2d08dbe0
[kubernetes-client-linux-386.tar.gz](https://dl.k8s.io/v1.37.0-beta.0/kubernetes-client-linux-386.tar.gz) | 307bcdab8a705384e1d5868d4aed8c318b72010f62818cc68812c51fb00f2e49ff3497f3a64cd56269cd669908525156cacc2076dd8d1d5c4892b137ccb740da
[kubernetes-client-linux-amd64.tar.gz](https://dl.k8s.io/v1.37.0-beta.0/kubernetes-client-linux-amd64.tar.gz) | b880a28e51d2ea2b253ae8e82e6f94072db7cadec88235ee06fcec989de09d06ad0ff3263c470d21406f0ee527d92b00131a82695860ec2e609d7619fe239af2
[kubernetes-client-linux-arm.tar.gz](https://dl.k8s.io/v1.37.0-beta.0/kubernetes-client-linux-arm.tar.gz) | 5bb4f9b63109a893c6a72b636be467a2c46dc90a5e7ff5d39e34aaa8950d6519bd8c371295f4819e66ff4cc120878afca03ee70360597bdd861a5882d3b66d18
[kubernetes-client-linux-arm64.tar.gz](https://dl.k8s.io/v1.37.0-beta.0/kubernetes-client-linux-arm64.tar.gz) | f490a05e9234ccc2d8237d877849796e8b60b7c0184d8c4eea117dabc719407a732b3081bee5771540df7ff41f463a780f7f9f13f54ed036904220339569e709
[kubernetes-client-linux-ppc64le.tar.gz](https://dl.k8s.io/v1.37.0-beta.0/kubernetes-client-linux-ppc64le.tar.gz) | 6b066f0837355174a3399f8c2552a34e67fa6d410a21e094ab444074fc263f82a5c890735576f79fc726d3fd3c9ba031fc463ace962d2ead6e2a5a03cf5065be
[kubernetes-client-linux-s390x.tar.gz](https://dl.k8s.io/v1.37.0-beta.0/kubernetes-client-linux-s390x.tar.gz) | aa8f6f9179a24eb1557840c23c5240210cd8c2125e700aa3293de45f90e2e2c971042e051a060c33b5bdf6bb656bbb8de38686ddb1aac53d210439602f46939e
[kubernetes-client-windows-386.tar.gz](https://dl.k8s.io/v1.37.0-beta.0/kubernetes-client-windows-386.tar.gz) | 661a31a0ed6f21f739dcb18444c19b64c7716ea87e273d56c7e19bbb17ceb29994943bb7f636c6728bb609061b039ad113a11d8f3808e947dc728cd28d0c8794
[kubernetes-client-windows-amd64.tar.gz](https://dl.k8s.io/v1.37.0-beta.0/kubernetes-client-windows-amd64.tar.gz) | 1370fe6493054554d4951569203fc9230f9f30c4843a111089792378f1f6932f2203b65b3338e43a3729cb428813d24462e9b25554e0f8a7bea2e67bd2a91189
[kubernetes-client-windows-arm64.tar.gz](https://dl.k8s.io/v1.37.0-beta.0/kubernetes-client-windows-arm64.tar.gz) | 6419aa5600a0fe4f8860ed7f126369aa5feed2860fa5b1cfdcb990df99154c00512dcd4c4198b343f5e1475f2d78fd59657b9f905e5bcf3f7e9724a42402fbcc

### Server Binaries

filename | sha512 hash
-------- | -----------
[kubernetes-server-linux-amd64.tar.gz](https://dl.k8s.io/v1.37.0-beta.0/kubernetes-server-linux-amd64.tar.gz) | a74d754bfa7e69493cdf1a0357306e8a5e5107f7eaff0c560677eff5fcb56d9a39192dbc227fc14148c7f48b61993c063bf90fcbd191a43455d2d85aa0a0f4ef
[kubernetes-server-linux-arm64.tar.gz](https://dl.k8s.io/v1.37.0-beta.0/kubernetes-server-linux-arm64.tar.gz) | 6d5961b97bba55d2a927acaba7fd327fc9a3916f1625e79b1a32229d3a8db669616b9adb0ba0a058e9ab1c8809893a20edee4355d6c5f4c8c670acd38de41b71
[kubernetes-server-linux-ppc64le.tar.gz](https://dl.k8s.io/v1.37.0-beta.0/kubernetes-server-linux-ppc64le.tar.gz) | d9956ea921a70bc1c75bb32b9390c3158a69e772ffbbf9f5bd3954975038c018b9bbd4417a8da59e0cbe0a9629b259ae3644e7ab73837e40d61495c620bee037
[kubernetes-server-linux-s390x.tar.gz](https://dl.k8s.io/v1.37.0-beta.0/kubernetes-server-linux-s390x.tar.gz) | 2441f5906fd18c072977082a1706292ca3431935e85ba3a65d0aa629afec4b5a470981f98ceb914d70759cd8560c5be695c176a40c776e0e9c946967f9a10380

### Node Binaries

filename | sha512 hash
-------- | -----------
[kubernetes-node-linux-amd64.tar.gz](https://dl.k8s.io/v1.37.0-beta.0/kubernetes-node-linux-amd64.tar.gz) | da044a30d92e9a3c15ee678a9e10a36b09188a117e6fccd67a3f993ee514f7a07e52a2768c02a90f7f9f8e78e8398b6033aa60628a126df48ece559dfef95381
[kubernetes-node-linux-arm64.tar.gz](https://dl.k8s.io/v1.37.0-beta.0/kubernetes-node-linux-arm64.tar.gz) | 31adffb8b051e742bbd8fcb54687aa9abbc6af4da597f9a6f589720beebfa091939fca81959b3c44c413ecdb3b5f549a7a7751df82f7085d156611332656011c
[kubernetes-node-linux-ppc64le.tar.gz](https://dl.k8s.io/v1.37.0-beta.0/kubernetes-node-linux-ppc64le.tar.gz) | 9a2d99718bc226b0ab6e47bfae3980d7e41678bb6c0eeb1d5fb8069f0f07a1229825b63bb979a19662c2efc07677cdc2df9b7fdbd255c9a8910c797f980e50c1
[kubernetes-node-linux-s390x.tar.gz](https://dl.k8s.io/v1.37.0-beta.0/kubernetes-node-linux-s390x.tar.gz) | b30bd77b2b72fd3ab4778242deddd55bfb580973adbf3bfecaed46e816824cdf536c201e60132036e409fbd653c12e79168871018427215a002f28fc591fd60e
[kubernetes-node-windows-amd64.tar.gz](https://dl.k8s.io/v1.37.0-beta.0/kubernetes-node-windows-amd64.tar.gz) | 0a404926c1017b06e3c7dd1c429031a3c51b0001256bfa77777a1c7198103938b814a54d76c93097abccf3276515ce0fc262354e7dd54ba67d2796e4d8e2e6a2

### Container Images

All container images are available as manifest lists and support the described
architectures. It is also possible to pull a specific architecture directly by
adding the "-$ARCH" suffix  to the container image name.

name | architectures
---- | -------------
[registry.k8s.io/conformance:v1.37.0-beta.0](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/conformance) | [amd64](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/conformance-amd64), [arm64](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/conformance-arm64), [ppc64le](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/conformance-ppc64le), [s390x](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/conformance-s390x)
[registry.k8s.io/kube-apiserver:v1.37.0-beta.0](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-apiserver) | [amd64](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-apiserver-amd64), [arm64](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-apiserver-arm64), [ppc64le](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-apiserver-ppc64le), [s390x](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-apiserver-s390x)
[registry.k8s.io/kube-controller-manager:v1.37.0-beta.0](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-controller-manager) | [amd64](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-controller-manager-amd64), [arm64](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-controller-manager-arm64), [ppc64le](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-controller-manager-ppc64le), [s390x](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-controller-manager-s390x)
[registry.k8s.io/kube-proxy:v1.37.0-beta.0](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-proxy) | [amd64](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-proxy-amd64), [arm64](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-proxy-arm64), [ppc64le](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-proxy-ppc64le), [s390x](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-proxy-s390x)
[registry.k8s.io/kube-scheduler:v1.37.0-beta.0](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-scheduler) | [amd64](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-scheduler-amd64), [arm64](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-scheduler-arm64), [ppc64le](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-scheduler-ppc64le), [s390x](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-scheduler-s390x)
[registry.k8s.io/kubectl:v1.37.0-beta.0](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kubectl) | [amd64](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kubectl-amd64), [arm64](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kubectl-arm64), [ppc64le](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kubectl-ppc64le), [s390x](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kubectl-s390x)

## Changelog since v1.37.0-alpha.3

## Changes by Kind

### Dependency

- Updated the default etcd version to 3.7.0 ([#140333](https://github.com/kubernetes/kubernetes/pull/140333), [@Jefftree](https://github.com/Jefftree)) [SIG API Machinery, Auth, Cloud Provider, Cluster Lifecycle, Etcd, Node, Scheduling and Testing]

### API Change

- Add PreemptionPolicy field to PodGroupTemplate to define policy for workload-aware preemption ([#140312](https://github.com/kubernetes/kubernetes/pull/140312), [@ania-borowiec](https://github.com/ania-borowiec)) [SIG API Machinery, Apps, Scheduling and Testing]
- Add a new Recreate update strategy for StatefulSets, mirroring Deployments' Recreate strategy, which deletes all pods and waits for full termination before creating new pods according to podManagementPolicy. ([#137187](https://github.com/kubernetes/kubernetes/pull/137187), [@galal-hussein](https://github.com/galal-hussein)) [SIG Apps and Testing]
- Added `--concurrent-disruption-syncs` to kube-controller-manager to configure the number of concurrent disruption controller workers. ([#140014](https://github.com/kubernetes/kubernetes/pull/140014), [@xigang](https://github.com/xigang)) [SIG API Machinery, Apps, Auth and Testing]
- Added the CompositePodGroup API into scheduling.k8s.io/v1alpha3. ([#139596](https://github.com/kubernetes/kubernetes/pull/139596), [@jdzikowski](https://github.com/jdzikowski)) [SIG API Machinery, Apps, Auth, Etcd, Node, Scheduling and Testing]
- DRA consumable capacity: when a request allocated multiple devices, the DistinctAttribute constraint was not checked properly for each device. ([#140600](https://github.com/kubernetes/kubernetes/pull/140600), [@GunaKKIBM](https://github.com/GunaKKIBM)) [SIG API Machinery, Apps, CLI, Etcd, Network, Node, Release, Scheduling and Testing]
- Fix DRA CapacityRequestPolicyRange to support fractional quantities in milli-scale. ([#140161](https://github.com/kubernetes/kubernetes/pull/140161), [@sunya-ch](https://github.com/sunya-ch)) [SIG API Machinery, Node and Scheduling]
- Fix the overestimation of the pod's resource footprint for multi-container pods undergoing a resize. ([#140047](https://github.com/kubernetes/kubernetes/pull/140047), [@natasha41575](https://github.com/natasha41575)) [SIG Node and Scheduling]
- Fixed pod status validation for reported Linux container user UIDs so values above 2147483647 and up to the unsigned 32-bit UID limit are accepted. ([#138574](https://github.com/kubernetes/kubernetes/pull/138574), [@Kunalbehbud](https://github.com/Kunalbehbud)) [SIG Apps and Node]
- Introduce new Node Lifecycle Conditions ([#139993](https://github.com/kubernetes/kubernetes/pull/139993), [@rthallisey](https://github.com/rthallisey)) [SIG Apps and Node]
- Introduces `PodGroupPostFilter` extension point to the scheduling framework. This replaces internal hardcoding for `WorkloadAwarePreemption` with a proper, configurable extension point for operating on PodGroups. ([#139674](https://github.com/kubernetes/kubernetes/pull/139674), [@GFilipek](https://github.com/GFilipek)) [SIG Scheduling and Testing]
- Kep-5304: make cdi spec version dynamic to avoid incompatible spec generation ([#137699](https://github.com/kubernetes/kubernetes/pull/137699), [@alaypatel07](https://github.com/alaypatel07)) [SIG Apps, Node, Scheduling and Testing]
- Pod-level resources only determine the QoS when they include a resource request or limit. Empty pod-level resources (`{}`, `{requests:{}}`, or `{limits:{}}`) no longer affect QoS calculation. ([#137150](https://github.com/kubernetes/kubernetes/pull/137150), [@KevinTMtz](https://github.com/KevinTMtz)) [SIG Apps, CLI, Node and Scheduling]
- Promoted the HPAConfigurableTolerance feature gate to GA. ([#140107](https://github.com/kubernetes/kubernetes/pull/140107), [@jm-franc](https://github.com/jm-franc)) [SIG API Machinery, Apps, Autoscaling and Testing]
- Promoted the `PersistentVolumeClaimUnusedSinceTime` feature gate to beta in v1.37 (enabled by default). PersistentVolumeClaims now report an `Unused` condition indicating how long a PVC has been unused, helping identify candidates for cleanup. ([#139620](https://github.com/kubernetes/kubernetes/pull/139620), [@RomanBednar](https://github.com/RomanBednar)) [SIG Apps]
- The ClusterTrustBundle and ClusterTrustBundleProjection features move to stable and enabled by default, along with the ClusterTrustBundle API. ([#139437](https://github.com/kubernetes/kubernetes/pull/139437), [@stlaz](https://github.com/stlaz)) [SIG API Machinery, Apps, Architecture, Auth, Etcd, Node, Storage and Testing]
- The `metrics.k8s.io` API is promoted from v1beta1 to v1 without any modifications ([#139223](https://github.com/kubernetes/kubernetes/pull/139223), [@tico88612](https://github.com/tico88612)) [SIG Instrumentation]
- The unsafe corrupt object deletion feature now supports dry-run mode, allowing administrators to test deletion operations safely before execution. ([#134037](https://github.com/kubernetes/kubernetes/pull/134037), [@ibihim](https://github.com/ibihim)) [SIG API Machinery and Testing]
- When the alpha feature gate InPlacePodVertifcalScalingSchedulerPreemption is enabled, the scheduler preempts lower-priority pods to make room for the `Deferred` in-place pod resizes of higher-priority pods. ([#140000](https://github.com/kubernetes/kubernetes/pull/140000), [@natasha41575](https://github.com/natasha41575)) [SIG API Machinery, Apps, Node, Scheduling, Storage and Testing]

### Feature

- Added a `--max-depth` flag to `kubectl explain --recursive` to limit the depth of nested fields displayed in the output. ([#138809](https://github.com/kubernetes/kubernetes/pull/138809), [@shady0503](https://github.com/shady0503)) [SIG CLI and Testing]
- Added metrics related to workload preemption in alpha stability behind WorkloadAwarePreemption feature gate. ([#139373](https://github.com/kubernetes/kubernetes/pull/139373), [@brejman](https://github.com/brejman)) [SIG Instrumentation and Scheduling]
- Added validation to PodGroup scheduling which, if the feature gate `PodGroupPreemptionPolicy` is enabled, ensures that preemption policies of the evaluated pods match the priority of the PodGroup. ([#140359](https://github.com/kubernetes/kubernetes/pull/140359), [@ania-borowiec](https://github.com/ania-borowiec)) [SIG Scheduling and Testing]
- Admission webhooks now skip the auth/authz virtual resources (e.g. `tokenreviews`, `subjectaccessreviews`) that ValidatingAdmissionPolicy/MutatingAdmissionPolicy already exclude, via the new `ExcludeAdmissionWebhookVirtualResources` feature gate (beta, on by default; opt out to restore the old behavior). ([#140019](https://github.com/kubernetes/kubernetes/pull/140019), [@BenTheElder](https://github.com/BenTheElder)) [SIG API Machinery and Testing]
- After successful scheduling of a podgroup, its remaining unscheduled pods are requeued directly to active queue rather than backoff queue. These pods preserve their old timestamp so they have precedence in scheduling unless a higher priority entity comes in between. ([#139613](https://github.com/kubernetes/kubernetes/pull/139613), [@iomarsayed](https://github.com/iomarsayed)) [SIG Scheduling and Testing]
- Bump coredns to 1.14.6 ([#140497](https://github.com/kubernetes/kubernetes/pull/140497), [@yashsingh74](https://github.com/yashsingh74)) [SIG Cloud Provider and Cluster Lifecycle]
- DRA: Add `resource.kubernetes.io/numaNode` as a standard device attribute with sysfs-based helper functions for DRA drivers (KEP-6072). ([#139929](https://github.com/kubernetes/kubernetes/pull/139929), [@johnahull](https://github.com/johnahull)) [SIG Node]
- Enhanced Pod-by-Pod preemption to support PodGroups as preemption victims. ([#137981](https://github.com/kubernetes/kubernetes/pull/137981), [@vshkrabkov](https://github.com/vshkrabkov)) [SIG Scheduling and Testing]
- Graduate scheduler metrics `scheduler_plugin_execution_duration_seconds` and `scheduler_scheduling_algorithm_duration_seconds` from ALPHA to BETA stability. ([#138176](https://github.com/kubernetes/kubernetes/pull/138176), [@abhay1999](https://github.com/abhay1999)) [SIG Instrumentation, Scheduling and Testing]
- Gradute NativeHistograms feature to beta ([#140124](https://github.com/kubernetes/kubernetes/pull/140124), [@richabanker](https://github.com/richabanker)) [SIG Architecture and Instrumentation]
- Kubernetes is now built with Go 1.26.5 ([#140576](https://github.com/kubernetes/kubernetes/pull/140576), [@palnabarun](https://github.com/palnabarun)) [SIG Release and Testing]
- PostFilter plugins are no longer run during PodGroup cycle for pods from PodGroup. Instead the PodGroupPostFilter is run if the whole PodGroup is unschedulable. ([#140412](https://github.com/kubernetes/kubernetes/pull/140412), [@Argh4k](https://github.com/Argh4k)) [SIG Scheduling and Testing]
- The EtcdRangeStream feature gate is now enabled by default (Beta). ([#140085](https://github.com/kubernetes/kubernetes/pull/140085), [@Jefftree](https://github.com/Jefftree)) [SIG API Machinery]
- The ManifestBasedAdmissionControlConfig feature is now beta and enabled by default. ([#140559](https://github.com/kubernetes/kubernetes/pull/140559), [@BenTheElder](https://github.com/BenTheElder)) [SIG API Machinery]
- We are adding two new metrics:
  
  "queued_entities": This metric tracks the current entities (individual pods or podgroups) in queues (active, backoff, etc..) of scheduler. 
   
  "queue_incoming_entities_total":  This metric tracks total number of entities (individual pods or podgroups) added to scheduling queues (active, backoff, etc..). ([#139840](https://github.com/kubernetes/kubernetes/pull/139840), [@iomarsayed](https://github.com/iomarsayed)) [SIG Instrumentation, Network and Scheduling]
- When workload aware preemption finds a placement for the PodGroup, the status of the PodGroup will contain "pod group preemption found a placement for podgroup, preempting <victim_count> victims" message. ([#140311](https://github.com/kubernetes/kubernetes/pull/140311), [@Argh4k](https://github.com/Argh4k)) [SIG Scheduling and Testing]
- Workload-Aware Preemption now runs only one scheduling attempt, on a cluster with all potential victims removed. This can lead to a suboptimal preemption victims choice at the cost of significant performance improvement. ([#139980](https://github.com/kubernetes/kubernetes/pull/139980), [@Argh4k](https://github.com/Argh4k)) [SIG Scheduling and Testing]

### Documentation

- Kube-proxy: Corrected the `--metrics-bind-address` flag documentation by removing the incorrect claim that setting it to an empty string disables the metrics server. ([#138940](https://github.com/kubernetes/kubernetes/pull/138940), [@kairosci](https://github.com/kairosci)) [SIG Network]

### Bug or Regression

- DRA consumable capacity: fixed a scheduler bug where a ResourceSlice with a device capacity requirement stored as a high-precision decimal (a fine-grained fractional value, or a value above the int64 range) could have that ResourceSlice mutated in place in the informer cache during allocation, which could then make allocation fail incorrectly for subsequent pods. ([#140702](https://github.com/kubernetes/kubernetes/pull/140702), [@weizhoublue](https://github.com/weizhoublue)) [SIG Node]
- DRA drivers might not have re-created ResourcSlices that were deleted by someone else, depending on timing (driver updates, then someone else shortly afterwards deletes them). ([#140063](https://github.com/kubernetes/kubernetes/pull/140063), [@pohly](https://github.com/pohly)) [SIG API Machinery, Apps, Node and Testing]
- DRA partitionable devices: if a DRA driver published counters which were outside of the normal int64 range, the counters in the informer cache got mutated and allocation may have failed  incorrectly for future pods. ([#140518](https://github.com/kubernetes/kubernetes/pull/140518), [@weizhoublue](https://github.com/weizhoublue)) [SIG Node]
- Fix bug in CEL where quantity.Add would mutate the receiver. ([#140556](https://github.com/kubernetes/kubernetes/pull/140556), [@jpbetz](https://github.com/jpbetz)) [SIG API Machinery]
- Fix: Prevent CEL Admission Panics on Three-Key Typed Map Lists ([#140386](https://github.com/kubernetes/kubernetes/pull/140386), [@weizhoublue](https://github.com/weizhoublue)) [SIG API Machinery]
- Fixed CEL for "set" and "map" lists: equality (`==`) no longer matches lists containing duplicates, and concatenation (`+`) now correctly applies set/map merge semantics to appended elements. ([#140293](https://github.com/kubernetes/kubernetes/pull/140293), [@jpbetz](https://github.com/jpbetz)) [SIG API Machinery]
- Fixed DRA scheduling bugs where the structured allocator mis-counted a device's shared counters while exploring candidates: it could keep a counter reserved after rejecting or backtracking a candidate, or drop a shared device's in-use marker so a later share was charged the counter twice. Either way the allocator could treat a counter set as exhausted and leave a pod pending on a node that could satisfy it. This affected the allocator used by the default feature configuration. ([#140431](https://github.com/kubernetes/kubernetes/pull/140431), [@thc1006](https://github.com/thc1006)) [SIG Node]
- Fixed `kubectl cluster-info dump --output-directory` creating world-readable dump files. Files are now created with mode 0600 and kubectl-created directories with mode 0700, since dumped pod logs can contain sensitive data. ([#140189](https://github.com/kubernetes/kubernetes/pull/140189), [@ashvinctrl](https://github.com/ashvinctrl)) [SIG CLI and Security]
- Fixed a DRA scheduling bug where the structured allocator keyed its shared-counter caches by pool name alone, so two drivers publishing a pool with the same name on a node could use each other's counter definitions and incorrectly accept or reject device allocations in the second driver's pool. ([#140435](https://github.com/kubernetes/kubernetes/pull/140435), [@thc1006](https://github.com/thc1006)) [SIG Node]
- Fixed a bug where burstable pod memory.low (soft protection) was ineffective because the parent cgroup lacked ancestor coverage required by the kernel's hierarchical protection model ([#140267](https://github.com/kubernetes/kubernetes/pull/140267), [@sohankunkerkar](https://github.com/sohankunkerkar)) [SIG Node and Testing]
- Fixed a case where Pods from PodGroup that evaluated successfully during the pod group cycle that eventually failed would have NNN set from this evaluation instead of from Pod Group preemption. ([#140590](https://github.com/kubernetes/kubernetes/pull/140590), [@Argh4k](https://github.com/Argh4k)) [SIG Scheduling]
- Fixed a concurrent map read/write data race condition in `handleSchedulingFailure` during scheduling failure handling. ([#140623](https://github.com/kubernetes/kubernetes/pull/140623), [@SparshGarg999](https://github.com/SparshGarg999)) [SIG Scheduling]
- Fixed a panic (integer divide by zero) and incorrect validation in ResourceSlice
  admission when a DRA consumable-capacity validRange step, min, max or default is
  negative or larger than 9223372036854775807. ([#140666](https://github.com/kubernetes/kubernetes/pull/140666), [@thc1006](https://github.com/thc1006)) [SIG Node]
- Fixed a panic in the kube-controller-manager that could crash it when a StorageVersionMigration targeted a resource not present in the RESTMapper (for example, a CRD deleted while its migration was pending). ([#140586](https://github.com/kubernetes/kubernetes/pull/140586), [@zwindler](https://github.com/zwindler)) [SIG API Machinery and Apps]
- Fixed kube-apiserver hanging forever on SIGTERM when its identity Lease cannot be created (e.g. hostname longer than 63 bytes). ([#140241](https://github.com/kubernetes/kubernetes/pull/140241), [@camilamacedo86](https://github.com/camilamacedo86)) [SIG API Machinery]
- Fixes a regression in the retry of deferred resizes that occurred due to a change in the way a pod resource footprint is calculated. ([#140646](https://github.com/kubernetes/kubernetes/pull/140646), [@natasha41575](https://github.com/natasha41575)) [SIG Node and Scheduling]
- KEP-5491: Fixed a bug where `DRAListTypeAttributes` feature gate enabled could fail to allocate devices even when a valid combination exists. This occurred when the allocator needed to backtrack during allocation of multiple devices with a `matchAttribute` constraint using list-type attribute values. ([#140325](https://github.com/kubernetes/kubernetes/pull/140325), [@everpeace](https://github.com/everpeace)) [SIG Node and Scheduling]
- Kube-proxy now exits when the watched Node's IPs change or when the Node object is deleted, allowing it to restart with updated node networking state. ([#138183](https://github.com/kubernetes/kubernetes/pull/138183), [@abishekgiri](https://github.com/abishekgiri)) [SIG Network]
- Kubectl run: error messages for invalid --restart and --image-pull-policy values now list the accepted values ([#138188](https://github.com/kubernetes/kubernetes/pull/138188), [@ogormans-deptstack](https://github.com/ogormans-deptstack)) [SIG CLI]
- Kubelet/DRA: fixed a race where PrepareResources could attach a pod to a ResourceClaim that was concurrently being unprepared, leaving the pod running with unprepared devices. ([#140527](https://github.com/kubernetes/kubernetes/pull/140527), [@bart0sh](https://github.com/bart0sh)) [SIG Node]
- Kubelet: fixed device health updates being applied to the wrong pod's status when device plugins for different resources expose devices with identical IDs. Affected pods now reflect device health changes immediately instead of waiting for the next periodic pod sync. ([#140323](https://github.com/kubernetes/kubernetes/pull/140323), [@harche](https://github.com/harche)) [SIG Node]
- The scheduler is less likely to get stuck scheduling large PodGroups when member Pods transiently fail to bind to Nodes (as is common when many Pods share the same ResourceClaim). ([#140478](https://github.com/kubernetes/kubernetes/pull/140478), [@nojnhuh](https://github.com/nojnhuh)) [SIG Scheduling]
- Updated the version of the nft binary in the kube-proxy image to nftables 1.0.6.1,
  to fix problems resyncing kube-proxy in nftables mode on systems containing
  rules created by recent versions of nftables. ([#140405](https://github.com/kubernetes/kubernetes/pull/140405), [@danwinship](https://github.com/danwinship)) [SIG Testing]

### Other (Cleanup or Flake)

- DRA: when a Pod is a member of a PodGroup, the ResourceClaim controller will no longer create ResourceClaims from ResourceClaimTemplates referenced by the Pod unless the DRAWorkloadResourceClaims feature gate is enabled. This prevents the controller from generating a ResourceClaim for the individual Pod in case it was intended to be generated for the PodGroup. ([#138363](https://github.com/kubernetes/kubernetes/pull/138363), [@nojnhuh](https://github.com/nojnhuh)) [SIG API Machinery, Apps, Node, Scheduling and Testing]
- Improve memory usage of kube-proxy by dropping the `.metadata.managedFields` field that kube-proxy doesn't require. ([#140056](https://github.com/kubernetes/kubernetes/pull/140056), [@adrianmoisey](https://github.com/adrianmoisey)) [SIG Network]
- MutatingAdmissionPolicy and MutatingAdmissionPolicyBinding are now stored in etcd as admissionregistration.k8s.io/v1 ([#137375](https://github.com/kubernetes/kubernetes/pull/137375), [@Jefftree](https://github.com/Jefftree)) [SIG API Machinery, Etcd and Testing]
- Server-side apply now correctly drops status changes when tracking field owership for PodGroup, PodCompositeGroup and PodCertificateRequest. ([#140654](https://github.com/kubernetes/kubernetes/pull/140654), [@jpbetz](https://github.com/jpbetz)) [SIG API Machinery, Auth, Scheduling and Testing]

## Dependencies

### Added
- tags.cncf.io/container-device-interface/specs-go: [v1.1.0](https://github.com/cncf-tags/container-device-interface/commit/98a7d735d9592c1ccca0130e06b0709f4b65ecbf)

### Changed
- cyphar.com/go-pathrs: [v0.2.2 → v0.2.5](https://github.com/cyphar/libpathrs.git/compare/go-pathrs/v0.2.2...go-pathrs/v0.2.5)
- github.com/containerd/containerd/api: [v1.11.0 → v1.11.1](https://github.com/containerd/containerd/compare/api/v1.11.0...api/v1.11.1)
- github.com/containerd/ttrpc: [v1.2.8 → v1.2.9](https://github.com/containerd/ttrpc/compare/v1.2.8...v1.2.9)
- github.com/containerd/typeurl/v2: [v2.2.3 → v2.3.0](https://github.com/containerd/typeurl/compare/v2.2.3...v2.3.0)
- github.com/coredns/corefile-migration: [v1.0.33 → v1.0.34](https://github.com/coredns/corefile-migration/compare/v1.0.33...v1.0.34)
- github.com/cyphar/filepath-securejoin: [v0.6.1 → v0.7.0](https://github.com/cyphar/filepath-securejoin/compare/v0.6.1...v0.7.0)
- github.com/google/cadvisor/lib: [v0.60.3 → v0.60.4](https://github.com/google/cadvisor/compare/lib/v0.60.3...lib/v0.60.4)
- github.com/onsi/ginkgo/v2: [v2.28.3 → v2.32.0](https://github.com/onsi/ginkgo/compare/v2.28.3...v2.32.0)
- github.com/opencontainers/cgroups: [v0.0.6 → v0.0.7](https://github.com/opencontainers/cgroups/compare/v0.0.6...v0.0.7)
- github.com/opencontainers/selinux: [v1.13.1 → v1.15.1](https://github.com/opencontainers/selinux/compare/v1.13.1...v1.15.1)
- go.etcd.io/bbolt: [v1.5.0-rc.0 → v1.5.0](https://github.com/etcd-io/bbolt/compare/v1.5.0-rc.0...v1.5.0)
- go.etcd.io/etcd/api/v3: [v3.7.0-rc.0 → v3.7.0](https://github.com/etcd-io/etcd/compare/api/v3.7.0-rc.0...api/v3.7.0)
- go.etcd.io/etcd/client/pkg/v3: [v3.7.0-rc.0 → v3.7.0](https://github.com/etcd-io/etcd/compare/client/pkg/v3.7.0-rc.0...client/pkg/v3.7.0)
- go.etcd.io/etcd/client/v3: [v3.7.0-rc.0 → v3.7.0](https://github.com/etcd-io/etcd/compare/client/v3.7.0-rc.0...client/v3.7.0)
- go.etcd.io/etcd/pkg/v3: [v3.7.0-rc.0 → v3.7.0](https://github.com/etcd-io/etcd/compare/pkg/v3.7.0-rc.0...pkg/v3.7.0)
- go.etcd.io/etcd/server/v3: [v3.7.0-rc.0 → v3.7.0](https://github.com/etcd-io/etcd/compare/server/v3.7.0-rc.0...server/v3.7.0)
- go.etcd.io/raft/v3: [v3.7.0-rc.1 → v3.7.0](https://github.com/etcd-io/raft/compare/v3.7.0-rc.1...v3.7.0)
- golang.org/x/crypto: [v0.52.0 → v0.54.0](https://go.googlesource.com/crypto/+/a1c0d9929856c8aba2b31f079340f00578eda803^1..cdce021fa6c7d9c7eb2743bfbe551f0a98fd5d62/)
- golang.org/x/mod: [v0.35.0 → v0.37.0](https://go.googlesource.com/mod/+/03901d351deb5bd95deb90714fb75bf8e232cb22^1..deb1dfcdb7c7fd98fb5afddc3e95dd36d5880874/)
- golang.org/x/net: [42abb85 → v0.57.0](https://go.googlesource.com/net/+/42abb857022cb79baacfa240bcf48588aa80bbee^1..b8f09f6f062ceb4531b7af4bd17a5c8fe9c4b2b5/)
- golang.org/x/sync: [v0.20.0 → v0.22.0](https://go.googlesource.com/sync/+/ec11c4a93de22cde2abe2bf74d70791033c2464c^1..1eb64d4bc0cde6da1bb8ebc7f178bb577508e5d0/)
- golang.org/x/sys: [v0.45.0 → v0.47.0](https://go.googlesource.com/sys/+/397d5f80920585bc27433d878aba498d062f81e1^1..9e7e939dcafac07e8ab4cffa6e5fc74908413f00/)
- golang.org/x/telemetry: [be6f6cb → 59b4966](https://go.googlesource.com/telemetry/+/be6f6cb8b1fafcb1c710a0666a79acac61139b7b^1..59b4966ccb57499277814ee2272936a2c01cfbcd/)
- golang.org/x/term: [v0.43.0 → v0.45.0](https://go.googlesource.com/term/+/3c3e4855f7d2eb06c3e48933554add9ec6b599b5^1..9f69229da31ca6a34b522f59dbe07cad5ea21587/)
- golang.org/x/text: [v0.37.0 → v0.40.0](https://go.googlesource.com/text/+/3ef517e623a4bfc08d6457f87d73afda7af7d8e1^1..724af9c35838492dcaacc1ac51a8a0187c994c54/)
- golang.org/x/tools: [v0.44.0 → v0.47.0](https://go.googlesource.com/tools/+/3dd188df80fd3563559f02e4eeb10ba1043cce55^1..fbf9f2e2c8124fbe1877f5ed2857111038d9fe12/)

### Removed
_Nothing has changed._



# v1.37.0-alpha.3


## Downloads for v1.37.0-alpha.3



### Source Code

filename | sha512 hash
-------- | -----------
[kubernetes.tar.gz](https://dl.k8s.io/v1.37.0-alpha.3/kubernetes.tar.gz) | 6ac747b1f3d8c6d341034ea37125829793dc3a3f8018eb0ba90e57b0190fed8a147ca56d3cf07562e932ae7e8291113e7e06c98d54c0c6577258f5844504ffd8
[kubernetes-src.tar.gz](https://dl.k8s.io/v1.37.0-alpha.3/kubernetes-src.tar.gz) | 407aa7241cd88a8ee7bf1f1b18399cc3adedcc25adb8df7123e6b2b4a5856ed3972b88262c0ae0eb9eec7d84c67250fbadf0f1f76a88530c2cede1348bec8353

### Client Binaries

filename | sha512 hash
-------- | -----------
[kubernetes-client-darwin-amd64.tar.gz](https://dl.k8s.io/v1.37.0-alpha.3/kubernetes-client-darwin-amd64.tar.gz) | 923ff3c315fc2fbcbbd215cdb4946f6d9559e0e259e8ed87fa55279c718b29c7530bfbe315a5f8fb289545a55f08dda3742f993fde519c722e469e8dc93cfab6
[kubernetes-client-darwin-arm64.tar.gz](https://dl.k8s.io/v1.37.0-alpha.3/kubernetes-client-darwin-arm64.tar.gz) | 6a9332c8aa9e548b967f492ab42b197a82c23555e2ea953dc8752d300a8ef38478042a74c0f6170af10cb35b41cb80e600d1a8575141ebb6d77f1e534fcf4b93
[kubernetes-client-linux-386.tar.gz](https://dl.k8s.io/v1.37.0-alpha.3/kubernetes-client-linux-386.tar.gz) | f245cf9de14b216b5d1354a7d5fff1b216bbd2db10639657939719175b3d2fe486128ad0e276ad7aba796a1fd3b7b1ec6686768c0167167b8ca44303e334f3b1
[kubernetes-client-linux-amd64.tar.gz](https://dl.k8s.io/v1.37.0-alpha.3/kubernetes-client-linux-amd64.tar.gz) | 6fe93886ce95d8b5b29fffc0ea311eb50e2dd6cdf27a2ea05c5b78d33db2094a9a1e2e7af5cdf9d3740d1fa69b83ad0a5e1776edc8a2cba71e1a1b2671ccd030
[kubernetes-client-linux-arm.tar.gz](https://dl.k8s.io/v1.37.0-alpha.3/kubernetes-client-linux-arm.tar.gz) | 69ec1be76b5216951ac7f2f2c4bfa5bf63bc7a2744f3ed973572aac8dabf8f2298520adf9230278f710dc95fe3db6c146ee1fd9311a01a887388cfe92a6a4845
[kubernetes-client-linux-arm64.tar.gz](https://dl.k8s.io/v1.37.0-alpha.3/kubernetes-client-linux-arm64.tar.gz) | d0bb9c6cdadbc797c05512f4f73cbbd412f6e840feb54b7232bc9b64b8060629e06365adfda670c37885bafb8bfa1d6de7f530c7b2922c287f23219aaf063aed
[kubernetes-client-linux-ppc64le.tar.gz](https://dl.k8s.io/v1.37.0-alpha.3/kubernetes-client-linux-ppc64le.tar.gz) | 7abbc629713d7f07d740de5dfa91e496087db0df1fcf7b7bcb93e5b5417453080fc859b004317439ac112e83401b3d16a19de07e477f2b605c82562dcd376ada
[kubernetes-client-linux-s390x.tar.gz](https://dl.k8s.io/v1.37.0-alpha.3/kubernetes-client-linux-s390x.tar.gz) | bbfd6060133b9203a33749f43b421dba9f6ba10c0d21f02ac8480165f4dcb25b0dd07639b5044a0b2fd0e8c32b16fa70460c40d56a59b3502026def632d7bc05
[kubernetes-client-windows-386.tar.gz](https://dl.k8s.io/v1.37.0-alpha.3/kubernetes-client-windows-386.tar.gz) | a2913f208ceee865ba595b670d149b6edc10209f04fc494a05ba870fb1d51a99bad22080b840fc0d113453fa39fff89ef5558c7aa4225b17a49fb0ce2ee2cad7
[kubernetes-client-windows-amd64.tar.gz](https://dl.k8s.io/v1.37.0-alpha.3/kubernetes-client-windows-amd64.tar.gz) | e4c153a764e58ed76c8892a6497aa9e094936b10c06f1226fb47d738c441d51e09182fa2bdd6e7e0e3bd678e7c9afb892c0a6ae21e920bd9f10231d2c94f77a2
[kubernetes-client-windows-arm64.tar.gz](https://dl.k8s.io/v1.37.0-alpha.3/kubernetes-client-windows-arm64.tar.gz) | cb6fd57d3c3b9c4b72c0b1865ce4b438627afc3cb9a46e06e6bcb9a04cd0ac7581e0f4c736e176025f3fe1d65c1d154afe36f52735caaee4e9ea2e0b029c4f09

### Server Binaries

filename | sha512 hash
-------- | -----------
[kubernetes-server-linux-amd64.tar.gz](https://dl.k8s.io/v1.37.0-alpha.3/kubernetes-server-linux-amd64.tar.gz) | f2968084ef1cff88a85bb9ec4de2df25475f74ea342b6115657216a85d52ff10bbdedc76dd486eef25495c7f3f7e188f43a0cbcaa2cec07b730068f5c01a52da
[kubernetes-server-linux-arm64.tar.gz](https://dl.k8s.io/v1.37.0-alpha.3/kubernetes-server-linux-arm64.tar.gz) | d5f8c06cc7d246112465d8435d01b99fda3a533171b34ead08ff64c26ddcc5329d540afd37df8013d3034540467ad99c93683c428eaad06a3bd1dc1640f2ac0b
[kubernetes-server-linux-ppc64le.tar.gz](https://dl.k8s.io/v1.37.0-alpha.3/kubernetes-server-linux-ppc64le.tar.gz) | e589b92dbb0b39fcdceb430c4d87cc7564f8143128a808c8fd89e2a09c7ceb566f1471c53fe5c38464f0c5994df43106e3c1d2d43eea97adbb48e9d7f6f68aba
[kubernetes-server-linux-s390x.tar.gz](https://dl.k8s.io/v1.37.0-alpha.3/kubernetes-server-linux-s390x.tar.gz) | 78eb0a050205e9f9c35584130124809a3c66f5f6696bc749892130f4f7fc23963680fc6ac5eb23aafd61e0e762dadb9b4a2418ba8f7cd2dfc6b8a55911b103a5

### Node Binaries

filename | sha512 hash
-------- | -----------
[kubernetes-node-linux-amd64.tar.gz](https://dl.k8s.io/v1.37.0-alpha.3/kubernetes-node-linux-amd64.tar.gz) | fc5cd6f7c3652bbdc58dd83d41fe33a4a36e901bd08ab12834a08510c9c9f48b2605e177394674b96b60d045f16dabe0461526943f9342f0bc92c75764a16c6f
[kubernetes-node-linux-arm64.tar.gz](https://dl.k8s.io/v1.37.0-alpha.3/kubernetes-node-linux-arm64.tar.gz) | da21197d3902a96ea603485700f7e32b719ea22b6d2c642c0c537727709a2c656d65f52ce3216e2c99d86ad1de4d98338668ad9dd123d887030c395261e5124e
[kubernetes-node-linux-ppc64le.tar.gz](https://dl.k8s.io/v1.37.0-alpha.3/kubernetes-node-linux-ppc64le.tar.gz) | 8e850cbe8dffbe31a7d38821efc9c27fbe12d66ed363ed4fb2abc9a6ddf840ca3b3a3f89ced2947fb722c0f15f9163af8c96bcd2ed59c6fdcd664d36ba8e2d8c
[kubernetes-node-linux-s390x.tar.gz](https://dl.k8s.io/v1.37.0-alpha.3/kubernetes-node-linux-s390x.tar.gz) | 6ed014e999b24438e3266d7c111d7cedddc568862d0a2eca7ba6c9ae29faf613c1b5d54731dd464f298052d58dce591c308cbfb6eacd23b25e4460a706494b1f
[kubernetes-node-windows-amd64.tar.gz](https://dl.k8s.io/v1.37.0-alpha.3/kubernetes-node-windows-amd64.tar.gz) | 9926cdb6b198b2906c433788a09f802dd72c8ef44f608f06fd3999661801af0e3f5d272c278cc8fab366f3e5526a6b483d3304d58171c67628fa3cdc736453a3

### Container Images

All container images are available as manifest lists and support the described
architectures. It is also possible to pull a specific architecture directly by
adding the "-$ARCH" suffix  to the container image name.

name | architectures
---- | -------------
[registry.k8s.io/conformance:v1.37.0-alpha.3](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/conformance) | [amd64](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/conformance-amd64), [arm64](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/conformance-arm64), [ppc64le](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/conformance-ppc64le), [s390x](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/conformance-s390x)
[registry.k8s.io/kube-apiserver:v1.37.0-alpha.3](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-apiserver) | [amd64](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-apiserver-amd64), [arm64](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-apiserver-arm64), [ppc64le](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-apiserver-ppc64le), [s390x](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-apiserver-s390x)
[registry.k8s.io/kube-controller-manager:v1.37.0-alpha.3](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-controller-manager) | [amd64](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-controller-manager-amd64), [arm64](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-controller-manager-arm64), [ppc64le](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-controller-manager-ppc64le), [s390x](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-controller-manager-s390x)
[registry.k8s.io/kube-proxy:v1.37.0-alpha.3](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-proxy) | [amd64](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-proxy-amd64), [arm64](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-proxy-arm64), [ppc64le](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-proxy-ppc64le), [s390x](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-proxy-s390x)
[registry.k8s.io/kube-scheduler:v1.37.0-alpha.3](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-scheduler) | [amd64](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-scheduler-amd64), [arm64](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-scheduler-arm64), [ppc64le](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-scheduler-ppc64le), [s390x](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-scheduler-s390x)
[registry.k8s.io/kubectl:v1.37.0-alpha.3](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kubectl) | [amd64](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kubectl-amd64), [arm64](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kubectl-arm64), [ppc64le](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kubectl-ppc64le), [s390x](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kubectl-s390x)

## Changelog since v1.37.0-alpha.2

## Urgent Upgrade Notes

### (No, really, you MUST read this before you upgrade)

 - Kubelet logs effective configuration on start.
  
  cluster admin should review permissions to only allow trusted users to nodes/logs cluster role. This is mostly the reminder as it was the best practice anyways and almost all of the effective configuration values can be already Inferred from other log messages or the kubelet behavior. ([#139837](https://github.com/kubernetes/kubernetes/pull/139837), [@SergeyKanzhelev](https://github.com/SergeyKanzhelev)) [SIG Node and Testing]
 
## Changes by Kind

### Dependency

- DEPRECATION!!! The kubelet's embedded cAdvisor now uses the leaner github.com/google/cadvisor/lib module, which removes three long-deprecated or legacy surfaces:
  - Deprecated cAdvisor flags are no longer accepted and the kubelet will fail to start if any are set (only --housekeeping-interval is kept): --application-metrics-count-limit, --boot-id-file, --container-hints, --containerd, --containerd-namespace, --enable-load-reader, --event-storage-age-limit, --event-storage-event-limit, --global-housekeeping-interval, --log-cadvisor-usage, --machine-id-file, --storage-driver-user, --storage-driver-password, --storage-driver-host, --storage-driver-db, --storage-driver-table, --storage-driver-secure, --storage-driver-buffer-duration. Remove these from your kubelet configuration.
  - cAdvisor application/custom metrics are no longer collected: the userDefinedMetrics field in /stats/summary and the custom container_application_* families in /metrics/cadvisor.
  - The /metrics/cadvisor series container_cpu_load_average_10s, container_cpu_load_d_average_10s, and container_tasks_state are no longer exported. ([#139870](https://github.com/kubernetes/kubernetes/pull/139870), [@dims](https://github.com/dims)) [SIG API Machinery, Auth, Instrumentation, Network, Node and Testing]

### API Change

- Add PreemptionPolicy field to PodGroup to define policy for workload-aware preemption ([#139240](https://github.com/kubernetes/kubernetes/pull/139240), [@ania-borowiec](https://github.com/ania-borowiec)) [SIG API Machinery, Apps, Architecture, Auth, Autoscaling, CLI, Cloud Provider, Cluster Lifecycle, Etcd, Instrumentation, Network, Node, Scheduling, Storage, Testing and Windows]
- Graduated the `SELinuxMount` feature gate to GA. `SELinuxMount` is now enabled by default in Kubernetes 1.37, which may break existing workloads in Kubernetes clusters with SELinux enabled. Please see [our blog](https://kubernetes.io/blog/2026/04/22/breaking-changes-in-selinux-volume-labeling/) to identify potentially problematic workloads in your 1.36 cluster and how to fix them or opt out of SELinuxMount changes before upgrading to 1.37. Admins of clusters without SELinux enabled can ignore this release note, as nothing changes for them. ([#139956](https://github.com/kubernetes/kubernetes/pull/139956), [@jsafrane](https://github.com/jsafrane)) [SIG API Machinery, Apps and Node]
- Implementation of core Conditional Authorization machinery ([#137513](https://github.com/kubernetes/kubernetes/pull/137513), [@luxas](https://github.com/luxas)) [SIG API Machinery, Auth, Node and Testing]
- Promoted node declared features to GA. ([#139763](https://github.com/kubernetes/kubernetes/pull/139763), [@pravk03](https://github.com/pravk03)) [SIG Apps, Autoscaling, Node, Scheduling and Testing]
- StorageVersionMigration is now enabled by default and GA with the StorageMigration/v1 API ([#138560](https://github.com/kubernetes/kubernetes/pull/138560), [@michaelasp](https://github.com/michaelasp)) [SIG API Machinery, Apps, Architecture, Auth, Etcd and Testing]
- The DRA Device Taints and Toleration feature is now generally available via the resource.k8s.io/v1 API. ([#138676](https://github.com/kubernetes/kubernetes/pull/138676), [@pohly](https://github.com/pohly)) [SIG API Machinery, Apps, Architecture, Auth, Etcd, Node, Scheduling, Storage and Testing]
- The NodeRestriction admission plugin now adds a defense-in-depth check for PodCertificateRequests.  A node may only create a PodCertificateRequest referring to a particular signer name if the pod actually mounts a podCertificate projected volume source that refers to that signer name, or if an authorization check for the user (verb=request-podcertificate-signer resource=<signerName>) succeeds. ([#140006](https://github.com/kubernetes/kubernetes/pull/140006), [@ahmedtd](https://github.com/ahmedtd)) [SIG Auth and Testing]
- Update to PodGroup API that converts the `PodGroupTemplateRef` to a simpler and more direct `WorkloadRef` that is aligned with the CompositePodGroup planned future changes. ([#140080](https://github.com/kubernetes/kubernetes/pull/140080), [@dom4ha](https://github.com/dom4ha)) [SIG API Machinery, Apps, Etcd, Node, Scheduling and Testing]

### Feature

- A FailedScheduling event and PodScheduled PodCondition for a pod for which the default preemption found a potential node will now contain
  "preemption:  found a potential placement for pod on node <node_name>, preempting <victim_count> victims" mesage. ([#140180](https://github.com/kubernetes/kubernetes/pull/140180), [@Argh4k](https://github.com/Argh4k)) [SIG Scheduling]
- Add progress to SVM conditions, allowing users to see the amount of objects a StorageVersionMigration has migrated. ([#138875](https://github.com/kubernetes/kubernetes/pull/138875), [@michaelasp](https://github.com/michaelasp)) [SIG API Machinery and Apps]
- Added Beta support for compressed responses to WatchList requests. When a client sends Accept-Encoding: gzip, the API server returns a gzip compressed response. This behavior is enabled by default and can be disabled using the WatchListCompression feature gate. Regular Watch requests are unaffected. ([#140140](https://github.com/kubernetes/kubernetes/pull/140140), [@p0lyn0mial](https://github.com/p0lyn0mial)) [SIG API Machinery]
- Added PodGroup methods to PodGroupManager and SharedLister, allowing scheduler plugins to obtain a consistent PodGroup state. ([#140077](https://github.com/kubernetes/kubernetes/pull/140077), [@macsko](https://github.com/macsko)) [SIG Node, Scheduling and Testing]
- Added the PodGroup field to the PodGroupInfo object in kube-scheduler to enable plugins to obtain a consistent state throughout the scheduling cycle. ([#140075](https://github.com/kubernetes/kubernetes/pull/140075), [@macsko](https://github.com/macsko)) [SIG Scheduling]
- Added the incompletePodGroupPods data structure to the scheduling queue to store pods waiting for their PodGroup object to be observed by kube-scheduler. ([#139952](https://github.com/kubernetes/kubernetes/pull/139952), [@macsko](https://github.com/macsko)) [SIG Node, Scheduling and Testing]
- Added validation to PodGroup scheduling which ensures priorities of the evaluated pods match the priority of the PodGroup. ([#139920](https://github.com/kubernetes/kubernetes/pull/139920), [@brejman](https://github.com/brejman)) [SIG Scheduling and Testing]
- After successful scheduling of a podgroup, its remaining unscheduled pods are requeued directly to active queue rather than backoff queue. These pods preserve their old timestamp so they have precedence in scheduling unless a higher priority entity comes in between. ([#139613](https://github.com/kubernetes/kubernetes/pull/139613), [@iomarsayed](https://github.com/iomarsayed)) [SIG Scheduling and Testing]
- Client-go now has context-aware APIs for REST mapping and discovery. This addresses a long-standing problem that the implementations under the hood made blocking API calls with `context.TODO`. Consumers of client-go are encouraged to switch to the new APIs and therefore they get marked as `Deprecated`. However, there is no plan to ever remove the old APIs. ([#129109](https://github.com/kubernetes/kubernetes/pull/129109), [@pohly](https://github.com/pohly)) [SIG API Machinery, Apps, Auth, Instrumentation, Node and Testing]
- Kube-proxy now warns you if you start it without explicitly specifying the proxy
  mode that you want (iptables, ipvs, or nftables), because the default on Linux
  will be switching from 'iptables' to 'nftables' in a future release. ([#139957](https://github.com/kubernetes/kubernetes/pull/139957), [@danwinship](https://github.com/danwinship)) [SIG Network]
- Support for `kubectl get -o kyaml` is promoted to stable. ([#140076](https://github.com/kubernetes/kubernetes/pull/140076), [@soltysh](https://github.com/soltysh)) [SIG CLI]
- Volume mount host path type mismatches log the actual path type along with the expected path type. ([#121873](https://github.com/kubernetes/kubernetes/pull/121873), [@skitt](https://github.com/skitt)) [SIG Storage]

### Documentation

- Client-go and apimachinery now track Go API changes in a Go-API/CHANGELOG.md file. ([#138351](https://github.com/kubernetes/kubernetes/pull/138351), [@pohly](https://github.com/pohly)) [SIG API Machinery]

### Bug or Regression

- Changed to only emit `FailedToRetrieveImagePullSecret` events if an image pull has failed. ([#138432](https://github.com/kubernetes/kubernetes/pull/138432), [@Jamstah](https://github.com/Jamstah)) [SIG Node]
- Config file migration changed to use source file's permissions when creating destination file. ([#138142](https://github.com/kubernetes/kubernetes/pull/138142), [@brianpursley](https://github.com/brianpursley)) [SIG API Machinery]
- Fix a regression in server side apply where patching a container type (list or map) could result in `422 required` errors for apply requests that previously succeeded. ([#140294](https://github.com/kubernetes/kubernetes/pull/140294), [@jpbetz](https://github.com/jpbetz)) [SIG API Machinery, Architecture, Auth, CLI, Cloud Provider, Cluster Lifecycle, Instrumentation, Network, Node, Scheduling, Storage and Testing]
- Fix audit request logging of malformed patch request bodies ([#139419](https://github.com/kubernetes/kubernetes/pull/139419), [@hoskeri](https://github.com/hoskeri)) [SIG API Machinery, Auth and Testing]
- Fixed a bug in kube-apiserver where a request matching multiple ValidatingAdmissionPolicy bindings with audit actions only recorded the first validation failure in the audit annotation; all audit failures are now published in a single annotation. ([#140001](https://github.com/kubernetes/kubernetes/pull/140001), [@lalitc375](https://github.com/lalitc375)) [SIG API Machinery]
- Fixed a bug in the DRA kubelet plugin helper where drivers with names longer
  than ~30 characters could not enable rolling updates because the plugin
  registration socket path exceeded the AF_UNIX path length limit. Rolling-update
  registration sockets now pick the shortest basename that fits under the
  configured registry directory, preferring `<driver>-<pod UID>-reg.sock`,
  then `<driver>-<hashed UID>-reg.sock`, then `dra-<hashed driver+UID>-reg.sock`. ([#139623](https://github.com/kubernetes/kubernetes/pull/139623), [@vishalanarase](https://github.com/vishalanarase)) [SIG Node and Testing]
- Fixed a bug that caused Pods in a PodGroup sharing a ResourceClaim to get stuck scheduling. ([#140269](https://github.com/kubernetes/kubernetes/pull/140269), [@nojnhuh](https://github.com/nojnhuh)) [SIG Node, Scheduling and Testing]
- Fixed a bug where Pods in a PodGroup sharing a ResourceClaim could be scheduled to Nodes where the ResourceClaim is not available. ([#140089](https://github.com/kubernetes/kubernetes/pull/140089), [@nojnhuh](https://github.com/nojnhuh)) [SIG Node, Scheduling and Testing]
- Fixed a bug where ValidatingAdmissionPolicy and MutatingAdmissionPolicy evaluation could observe subtle differences (particularly around quantity fields and type meta fields) in object representation. The bug could occur when a parameter object was loaded via an alternative path, due to a cache miss. CEL expressions now behave deterministically against params. ([#140201](https://github.com/kubernetes/kubernetes/pull/140201), [@jpbetz](https://github.com/jpbetz)) [SIG API Machinery]
- Fixed a bug where successfully scheduled Pods could be stuck with the `PodScheduled=False` condition. ([#139602](https://github.com/kubernetes/kubernetes/pull/139602), [@nojnhuh](https://github.com/nojnhuh)) [SIG Node and Scheduling]
- Fixed a kubelet memory leak regression in 1.36 caused by leaked contexts on every Pod sync. ([#139850](https://github.com/kubernetes/kubernetes/pull/139850), [@compumike](https://github.com/compumike)) [SIG Node]
- Fixed a panic in ResourceSlice validation that could occur when the DRAConsumableCapacity feature was enabled and a capacity request policy set validRange.step to zero. ([#139698](https://github.com/kubernetes/kubernetes/pull/139698), [@wilmerdooley](https://github.com/wilmerdooley))
- KEP-5491: the list-type attributes, `.includes` function, and macros can now be evaluated even when the `ListTypeAttributes` feature gate is disabled in the scheduler to avoid users from facing errors during rolling-upgrade or flipping the feature gate scenario. ([#139395](https://github.com/kubernetes/kubernetes/pull/139395), [@everpeace](https://github.com/everpeace)) [SIG Node]
- Kube-scheduler: fixed inter-pod (anti-)affinity and volume restriction evaluation during PodGroup scheduling cycles. The scheduler snapshot's AssumePod and ForgetPod now correctly maintain affinity node lists and PVC usage tracking. ([#139054](https://github.com/kubernetes/kubernetes/pull/139054), [@net0pyr](https://github.com/net0pyr)) [SIG Scheduling and Testing]
- Kubeadm: improved the logic around warnings when the user sets a non-default bindAddress in KubeProxyConfiguration. ([#139989](https://github.com/kubernetes/kubernetes/pull/139989), [@vinayakray19](https://github.com/vinayakray19)) [SIG Cluster Lifecycle]
- Kubelet no longer emits V(4) "Label not found" logs for missing optional container annotations. ([#140163](https://github.com/kubernetes/kubernetes/pull/140163), [@HirazawaUi](https://github.com/HirazawaUi)) [SIG Node]
- On nodes with hugepages, memory.available used by Kubelet eviction manager now correctly excludes
  hugepage-reserved RAM from AvailableBytes. This fixes delayed eviction and OOM kills caused by
  inflated available memory reporting. The HugepageAwareEviction feature gate
  (default: enabled) can be disabled to restore the previous behavior. ([#138127](https://github.com/kubernetes/kubernetes/pull/138127), [@jingczhang](https://github.com/jingczhang)) [SIG Node and Testing]
- PodGroup.Status.Conditions now reflects the failure reason when scheduling is rejected due to mismatched .spec.schedulerName across pods in a group. ([#140183](https://github.com/kubernetes/kubernetes/pull/140183), [@Argh4k](https://github.com/Argh4k)) [SIG Scheduling]
- The `pods/binding` endpoint now validates the specified node name consistently. ([#136776](https://github.com/kubernetes/kubernetes/pull/136776), [@yakir-shriker](https://github.com/yakir-shriker)) [SIG Apps and Scheduling]

### Other (Cleanup or Flake)

- Changed kubelet to log a warning if static pods are defined with an invalid `priority` or `priorityClassName`. ([#136705](https://github.com/kubernetes/kubernetes/pull/136705), [@sreeram-venkitesh](https://github.com/sreeram-venkitesh)) [SIG Node]
- Kubelet/DRA: fixed a bug where deleting a pod could un-prepare resources still in use by another pod. ([#140212](https://github.com/kubernetes/kubernetes/pull/140212), [@bart0sh](https://github.com/bart0sh)) [SIG Node]
- PreventStaticPodAPIReferences feature gate has been removed and cannot be disabled anymore to allow static pods to reference API resources ([#140226](https://github.com/kubernetes/kubernetes/pull/140226), [@sreeram-venkitesh](https://github.com/sreeram-venkitesh)) [SIG Node]

## Dependencies

### Added
- github.com/google/cadvisor/lib: [v0.60.3](https://github.com/google/cadvisor/commit/9c3903ca474779a5f5f9c7b3af9868c566a85f4e)

### Changed
- github.com/containerd/typeurl/v2: [v2.3.0 → v2.2.3](https://github.com/containerd/typeurl/compare/v2.3.0...v2.2.3)
- k8s.io/utils: [b8788ab → be93311](https://github.com/kubernetes/utils/compare/b8788abfbbc27cab6c8732274b5c2ae213868854...be93311217bd4e42d0aa42a5987d08e8f5581ec0)
- sigs.k8s.io/structured-merge-diff/v6: [v6.4.0 → v6.4.2](https://github.com/kubernetes-sigs/structured-merge-diff/compare/v6.4.0...v6.4.2)

### Removed
- github.com/aws/aws-sdk-go-v2: [v1.36.3](https://github.com/aws/aws-sdk-go-v2/commit/c33f3e8d6bd4acd3c33d7abf391c7040305d5f12)
- github.com/aws/aws-sdk-go-v2/config: [v1.29.14](https://github.com/aws/aws-sdk-go-v2/commit/2a0c73e76f5f06579a2cb24239ca054d60ced4c2)
- github.com/aws/aws-sdk-go-v2/credentials: [v1.17.67](https://github.com/aws/aws-sdk-go-v2/commit/2a0c73e76f5f06579a2cb24239ca054d60ced4c2)
- github.com/aws/aws-sdk-go-v2/feature/ec2/imds: [v1.16.30](https://github.com/aws/aws-sdk-go-v2/commit/c33f3e8d6bd4acd3c33d7abf391c7040305d5f12)
- github.com/aws/aws-sdk-go-v2/internal/configsources: [v1.3.34](https://github.com/aws/aws-sdk-go-v2/commit/c33f3e8d6bd4acd3c33d7abf391c7040305d5f12)
- github.com/aws/aws-sdk-go-v2/internal/endpoints/v2: [v2.6.34](https://github.com/aws/aws-sdk-go-v2/commit/c33f3e8d6bd4acd3c33d7abf391c7040305d5f12)
- github.com/aws/aws-sdk-go-v2/internal/ini: [v1.8.3](https://github.com/aws/aws-sdk-go-v2/commit/54aed732316b5162e5c4382a1f2d3891175d0254)
- github.com/aws/aws-sdk-go-v2/service/internal/accept-encoding: [v1.12.3](https://github.com/aws/aws-sdk-go-v2/commit/54aed732316b5162e5c4382a1f2d3891175d0254)
- github.com/aws/aws-sdk-go-v2/service/internal/presigned-url: [v1.12.15](https://github.com/aws/aws-sdk-go-v2/commit/c33f3e8d6bd4acd3c33d7abf391c7040305d5f12)
- github.com/aws/aws-sdk-go-v2/service/sso: [v1.25.3](https://github.com/aws/aws-sdk-go-v2/commit/bada51283b7ea361a15a4bb018b817e899b363ad)
- github.com/aws/aws-sdk-go-v2/service/ssooidc: [v1.30.1](https://github.com/aws/aws-sdk-go-v2/commit/bada51283b7ea361a15a4bb018b817e899b363ad)
- github.com/aws/aws-sdk-go-v2/service/sts: [v1.33.19](https://github.com/aws/aws-sdk-go-v2/commit/2a0c73e76f5f06579a2cb24239ca054d60ced4c2)
- github.com/aws/smithy-go: [v1.22.3](https://github.com/aws/smithy-go/commit/312566ce7f2e736333ce7cbca09328d766c92ce7)
- github.com/containerd/errdefs: [v1.0.0](https://github.com/containerd/errdefs/commit/4817405e4a3caeb7aee9dac68ed55339c59cb635)
- github.com/containerd/errdefs/pkg: [v0.3.0](https://github.com/containerd/errdefs/commit/4817405e4a3caeb7aee9dac68ed55339c59cb635)
- github.com/docker/go-connections: [v0.6.0](https://github.com/docker/go-connections/commit/42faf792bde28c414a060127d6351769408a675f)
- github.com/euank/go-kmsg-parser: [v2.0.0](https://github.com/euank/go-kmsg-parser/tree/v2.0.0)
- github.com/google/cadvisor: [v0.57.0](https://github.com/google/cadvisor/commit/4098bb73867d45b7ced21695e073d047025403b8)
- github.com/mistifyio/go-zfs: [f784269](https://github.com/mistifyio/go-zfs/tree/f784269)
- github.com/moby/docker-image-spec: [v1.3.1](https://github.com/moby/docker-image-spec/commit/f1d00ebd2d6d6805170d5543dbca4b850f35f9af)
- github.com/moby/moby/api: [v1.54.1](https://github.com/moby/moby/commit/a3d12a24d680d2dccc18ff222ba560f8fef98279)
- github.com/moby/moby/client: [v0.4.0](https://github.com/moby/moby/commit/0c42ba8cf8e8d250b10e0e7e6387c857f8efb394)
- github.com/opencontainers/runc: [v1.4.0](https://github.com/opencontainers/runc/commit/8bd78a9977e604c4d5f67a7415d7b8b8c109cdc4)



# v1.37.0-alpha.2


## Downloads for v1.37.0-alpha.2



### Source Code

filename | sha512 hash
-------- | -----------
[kubernetes.tar.gz](https://dl.k8s.io/v1.37.0-alpha.2/kubernetes.tar.gz) | 834ebfaf9f6e895d3a74d31e0c046a19a9c499a0ce0f7dcbb4695fc85f8e5ab63fe8afff2639c152f4aace8d4ec72b9e849f926300a8a0f11548298a394e175d
[kubernetes-src.tar.gz](https://dl.k8s.io/v1.37.0-alpha.2/kubernetes-src.tar.gz) | 2d6fc271a71bc6105428fa29837163fe5089f9dad28add0393c43d8d693be36cdbc179919f5cec21758e260edf85601420228e6105b0906a29b86567a2a3d61d

### Client Binaries

filename | sha512 hash
-------- | -----------
[kubernetes-client-darwin-amd64.tar.gz](https://dl.k8s.io/v1.37.0-alpha.2/kubernetes-client-darwin-amd64.tar.gz) | 86d617eca510a1de567120eadb2f6a45a38506abb495325b213766c25168f8dfb108a04c7a24d74b7252d110e02770f68e681f61c27cdcd2a53e849cdf472398
[kubernetes-client-darwin-arm64.tar.gz](https://dl.k8s.io/v1.37.0-alpha.2/kubernetes-client-darwin-arm64.tar.gz) | 16fd148c6bb335f5507a329ece30762cd624ff8e4cf776ff84110ced1be2a478e4cc412b66624a982ca1e701271eaa2cfc11674b6c56b95124dd6fc21868e157
[kubernetes-client-linux-386.tar.gz](https://dl.k8s.io/v1.37.0-alpha.2/kubernetes-client-linux-386.tar.gz) | 1a734b4e839c25bc2b50cd764af075aabbabdf054855ed2762ca2eb1648f11fe047382ea888817cb27854d9cfed320896bb2251e16a68d1ea6d2add6c85c239e
[kubernetes-client-linux-amd64.tar.gz](https://dl.k8s.io/v1.37.0-alpha.2/kubernetes-client-linux-amd64.tar.gz) | f619cb6ae2b2907134f9624521169996f8501c20f2d430bd2909e422e4501442d4840714673954902f11ef51867ab688ce79979e62c74542d19e377d7835e21a
[kubernetes-client-linux-arm.tar.gz](https://dl.k8s.io/v1.37.0-alpha.2/kubernetes-client-linux-arm.tar.gz) | 70b83e9e72c4f75ac1e0925229e1bb55e358a7e14833a2c9878d09228a3b94ced4eed62b90ac6a257fb1e93ae3019da4a86219a4489b9a937c023b04bf1bc092
[kubernetes-client-linux-arm64.tar.gz](https://dl.k8s.io/v1.37.0-alpha.2/kubernetes-client-linux-arm64.tar.gz) | a60bd2e8ff138b9be87054fce9ba43a5ae721d2c7922bad97a34ba2610e157746c376bc267ee62fb2fefed9e446dcc517c601efa5231eb965865c55f7e5fba5a
[kubernetes-client-linux-ppc64le.tar.gz](https://dl.k8s.io/v1.37.0-alpha.2/kubernetes-client-linux-ppc64le.tar.gz) | ca201806431e2ffc7bddb355c4f194d738222f53288ead2a008d16c44ef494d5ee58da529f578b921ee13ca239527454b8556ab28b9dce1511dd852801a5e2d9
[kubernetes-client-linux-s390x.tar.gz](https://dl.k8s.io/v1.37.0-alpha.2/kubernetes-client-linux-s390x.tar.gz) | a87ac2544a04c9cd7de5d80e4e9e0f933dcb05deee6fa0734999a6befacbf01e58eb060c249528e9ab08c6e45ddf8dbf637d1f293670c6ff33366f5255e6ca46
[kubernetes-client-windows-386.tar.gz](https://dl.k8s.io/v1.37.0-alpha.2/kubernetes-client-windows-386.tar.gz) | f2d124c66d95496e55829b314ba29eba6fa494e44004a05272c7b6138dd98082695557d666d9466501390c6895b8eb374bcacffe71449e908a30efbc69a3816c
[kubernetes-client-windows-amd64.tar.gz](https://dl.k8s.io/v1.37.0-alpha.2/kubernetes-client-windows-amd64.tar.gz) | 1d6d31f249a283f576d4a75b95b802069b0d338b9e54a6d983eb7a595a5f6b110f38bcdb60ef90a030e96ab06e6d8666632f9cd720ed22bb07208d9041682310
[kubernetes-client-windows-arm64.tar.gz](https://dl.k8s.io/v1.37.0-alpha.2/kubernetes-client-windows-arm64.tar.gz) | f4231567a6f99f94de243b42386c76cc577ae465de6550fc4f0889c9c1c8c195dfabd2c88351875bb8e90146df9958776ba86eeed0a3650efb46e343991f90a5

### Server Binaries

filename | sha512 hash
-------- | -----------
[kubernetes-server-linux-amd64.tar.gz](https://dl.k8s.io/v1.37.0-alpha.2/kubernetes-server-linux-amd64.tar.gz) | d13945b5e4fbcba87abbde01649f0f75bbd5121e1eadfd74a2f8f03c370ba68accd2d46694b9a94077e07e1655562b53025d43d33aa11e9e3714759fd8b80e65
[kubernetes-server-linux-arm64.tar.gz](https://dl.k8s.io/v1.37.0-alpha.2/kubernetes-server-linux-arm64.tar.gz) | 210ecd08861ad00a5c712128ca03eda5d23bf7570d026f65cabd5161f296006b47f3c56eb8ce703d0064f27c7e6be4fe2749d87011c9ce5d15c5071de714eabc
[kubernetes-server-linux-ppc64le.tar.gz](https://dl.k8s.io/v1.37.0-alpha.2/kubernetes-server-linux-ppc64le.tar.gz) | c71e9f31155b4c16e63c5d90dbd75b48e80a3960b25cede95ff4aaedf1abfbd707f8b9a7cf39925b1134a4958887362b1147886a3690aae577521edd9ef06ecf
[kubernetes-server-linux-s390x.tar.gz](https://dl.k8s.io/v1.37.0-alpha.2/kubernetes-server-linux-s390x.tar.gz) | 55e5661fdb982c7922534d39e79c5cf6d15fe158fd97009ec1a9fd7c320eb2f513e3071464bc22731a87b6d6023becda47887370233dd9ec5fa259f5c8b2c82e

### Node Binaries

filename | sha512 hash
-------- | -----------
[kubernetes-node-linux-amd64.tar.gz](https://dl.k8s.io/v1.37.0-alpha.2/kubernetes-node-linux-amd64.tar.gz) | 36327dca5cfcbcd934cff975066e98d4a503da63f8889028f367a12519dad0a3cd8d5268fb7d07ba2ccc4a6e55ccc822d04fe2059bcc6117d2872441f822ce5b
[kubernetes-node-linux-arm64.tar.gz](https://dl.k8s.io/v1.37.0-alpha.2/kubernetes-node-linux-arm64.tar.gz) | dda000d9f40e21f48d3d52c728e26eb9b7677dccaf6c596869e2ddbdc436ce98429e37676fe7792e7b6246d725210d8fe79307bc159e40d42763c25ec533fb99
[kubernetes-node-linux-ppc64le.tar.gz](https://dl.k8s.io/v1.37.0-alpha.2/kubernetes-node-linux-ppc64le.tar.gz) | 2a4f6e5f2e90f4bc99f39f7bac1d8ebcd52e3a606e614c6ebf44c1306c30a0fd1076be8b3ab7852dba2e227c3b18288c843265110cd8728058151277cee5086b
[kubernetes-node-linux-s390x.tar.gz](https://dl.k8s.io/v1.37.0-alpha.2/kubernetes-node-linux-s390x.tar.gz) | f82fd679ce1a80dfec4b91856fdac268dd8cc135e4bb7eb9734c5a437d856721314c3c2b6d4bf4e3a419eff6c3e8ddccf65d209fd60d1b96bf45c9162c8924d1
[kubernetes-node-windows-amd64.tar.gz](https://dl.k8s.io/v1.37.0-alpha.2/kubernetes-node-windows-amd64.tar.gz) | 439bf15f4e0bc4fbea622747a83ed6ecb02d931b84b4ab4abe729334038237db0029d4a9cc262494945c869533b5b1afeae14a324a0be6cc49423859646d2165

### Container Images

All container images are available as manifest lists and support the described
architectures. It is also possible to pull a specific architecture directly by
adding the "-$ARCH" suffix  to the container image name.

name | architectures
---- | -------------
[registry.k8s.io/conformance:v1.37.0-alpha.2](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/conformance) | [amd64](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/conformance-amd64), [arm64](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/conformance-arm64), [ppc64le](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/conformance-ppc64le), [s390x](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/conformance-s390x)
[registry.k8s.io/kube-apiserver:v1.37.0-alpha.2](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-apiserver) | [amd64](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-apiserver-amd64), [arm64](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-apiserver-arm64), [ppc64le](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-apiserver-ppc64le), [s390x](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-apiserver-s390x)
[registry.k8s.io/kube-controller-manager:v1.37.0-alpha.2](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-controller-manager) | [amd64](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-controller-manager-amd64), [arm64](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-controller-manager-arm64), [ppc64le](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-controller-manager-ppc64le), [s390x](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-controller-manager-s390x)
[registry.k8s.io/kube-proxy:v1.37.0-alpha.2](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-proxy) | [amd64](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-proxy-amd64), [arm64](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-proxy-arm64), [ppc64le](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-proxy-ppc64le), [s390x](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-proxy-s390x)
[registry.k8s.io/kube-scheduler:v1.37.0-alpha.2](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-scheduler) | [amd64](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-scheduler-amd64), [arm64](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-scheduler-arm64), [ppc64le](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-scheduler-ppc64le), [s390x](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-scheduler-s390x)
[registry.k8s.io/kubectl:v1.37.0-alpha.2](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kubectl) | [amd64](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kubectl-amd64), [arm64](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kubectl-arm64), [ppc64le](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kubectl-ppc64le), [s390x](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kubectl-s390x)

## Changelog since v1.37.0-alpha.1

## Changes by Kind

### Deprecation

- Kubeadm: if the user is providing a KubeProxyConfiguration with an empty value for the 'mode' field or if KubeProxyConfiguration is not provided, explicitly set the mode to 'iptables'. In 1.37 kube-proxy will start throwing a warning if the user has not explicitly set the field. This is part of the plan to switch the default mode to 'nftables' in a future release. ([#139777](https://github.com/kubernetes/kubernetes/pull/139777), [@neolit123](https://github.com/neolit123)) [SIG Cluster Lifecycle]

### API Change

- Cloud-provider: the `NodeSyncPeriod` field was moved from KubeCloudSharedConfiguration to `CloudControllerManagerConfiguration.NodeLifecycleController.NodeMonitorPeriod` ([#137964](https://github.com/kubernetes/kubernetes/pull/137964), [@niewysoki](https://github.com/niewysoki)) [SIG API Machinery, Apps, Cloud Provider, Instrumentation and Node]
- Fix CEL estimated cost of metadata.name and metadata.generateName for CRDs to match what the 253 limit that is validated by default unless the CRD author adds sets validations on the metadata fields. ([#139573](https://github.com/kubernetes/kubernetes/pull/139573), [@jpbetz](https://github.com/jpbetz)) [SIG API Machinery]
- MinCount can be modify after setting in PodGroup and PodGroupTemplate, modifying template is not influencing already existing podgroups. ([#139279](https://github.com/kubernetes/kubernetes/pull/139279), [@antekjb](https://github.com/antekjb)) [SIG API Machinery, Scheduling and Testing]
- Rename podGroup condition from PodGroupScheduled to PodGroupInitiallyScheduled, to express clearly that this condition is set after the PodGroup first becomes scheduled successfully, and may not reflect the latest state of the PodGroup. ([#139743](https://github.com/kubernetes/kubernetes/pull/139743), [@antekjb](https://github.com/antekjb)) [SIG API Machinery, Scheduling and Testing]
- The GangScheduling and WorkloadAwarePreemption feature gates were removed, and GenericWorkload is used instead to enable all core workload-aware scheduling functionalities altogether. ([#139520](https://github.com/kubernetes/kubernetes/pull/139520), [@macsko](https://github.com/macsko)) [SIG API Machinery, Node, Scheduling and Testing]

### Feature

- Add informer metrics to apiserver ([#139968](https://github.com/kubernetes/kubernetes/pull/139968), [@michaelasp](https://github.com/michaelasp)) [SIG API Machinery and Testing]
- Added CBOR as a supported encoding for discovery endpoints and structured errors when the `CBORServingAndStorage` feature gate is enabled. ([#139632](https://github.com/kubernetes/kubernetes/pull/139632), [@benluddy](https://github.com/benluddy)) [SIG API Machinery and Testing]
- Added a feature gate for Composite Pod Group. ([#139407](https://github.com/kubernetes/kubernetes/pull/139407), [@jdzikowski](https://github.com/jdzikowski)) [SIG Scheduling]
- Bump coredns to 1.14.4 ([#139735](https://github.com/kubernetes/kubernetes/pull/139735), [@yashsingh74](https://github.com/yashsingh74)) [SIG Cloud Provider and Cluster Lifecycle]
- Client-go: allow passing a custom GenerateKey field in the Config structure of the certificate manager. ([#138999](https://github.com/kubernetes/kubernetes/pull/138999), [@neolit123](https://github.com/neolit123)) [SIG API Machinery and Auth]
- HPA: Enable scaling to and from zero by default. ([#139648](https://github.com/kubernetes/kubernetes/pull/139648), [@johanneswuerbach](https://github.com/johanneswuerbach)) [SIG Apps, Autoscaling and Testing]
- Kube-apiserver, when using --enable-aggregator-routing=true,  now load-balances requests evenly across all admission webhook endpoints. This ensures connection caching does not route all concurrent requests to a single backend endpoint. Cluster administrators can temporarily opt out of this new behavior using the `WebhookRoundTripLoadBalancing` feature gate (Beta, default `true`). ([#139237](https://github.com/kubernetes/kubernetes/pull/139237), [@aojea](https://github.com/aojea)) [SIG API Machinery and Testing]
- Optimized kube-scheduler performance for Pods with PersistentVolumeClaim mounts by processing only delta counts between scheduling cycles. ([#139238](https://github.com/kubernetes/kubernetes/pull/139238), [@yue9944882](https://github.com/yue9944882)) [SIG Scheduling and Testing]
- Relaxed DNS names for Services is now GA. ([#139282](https://github.com/kubernetes/kubernetes/pull/139282), [@adrianmoisey](https://github.com/adrianmoisey)) [SIG Apps and Network]
- This PR introduces the `WatchListCompression` feature gate (Beta, enabled by default).
  When enabled `WatchList` responses are compressed with `gzip` for clients that include `Accept-Encoding: gzip`. Regular `Watch` requests are unaffected. ([#139308](https://github.com/kubernetes/kubernetes/pull/139308), [@p0lyn0mial](https://github.com/p0lyn0mial)) [SIG API Machinery]

### Failing Test

- Fixed a bug when the DRADeviceTaintRules feature is enabled that caused kube-scheduler to panic when DeviceTaintRules exist and ResourceSlices are changed or to ignore new changes to DeviceTaintRules. ([#139651](https://github.com/kubernetes/kubernetes/pull/139651), [@nojnhuh](https://github.com/nojnhuh)) [SIG Node and Testing]

### Bug or Regression

- Add a way to wait on run finishing when closing an event handler. ([#139755](https://github.com/kubernetes/kubernetes/pull/139755), [@michaelasp](https://github.com/michaelasp)) [SIG API Machinery]
- An assumed pod is correctly removed from podGroupStates in cache, when it gets updated with deletion timestamp. ([#138445](https://github.com/kubernetes/kubernetes/pull/138445), [@iomarsayed](https://github.com/iomarsayed)) [SIG Scheduling]
- Cri-api: Reverts to pre-1.34 JSON encoding of the KeyValue value field ([#139964](https://github.com/kubernetes/kubernetes/pull/139964), [@liggitt](https://github.com/liggitt)) [SIG Node]
- Fix duplicated configs reported in resourceclaim status ([#139732](https://github.com/kubernetes/kubernetes/pull/139732), [@LionelJouin](https://github.com/LionelJouin)) [SIG Node]
- Fix(kubelet):  pods with subPath mounts stuck in error loop after FUSE/GlusterFS network filesystem disruption. ([#139275](https://github.com/kubernetes/kubernetes/pull/139275), [@yuehaii](https://github.com/yuehaii)) [SIG Node, Storage and Testing]
- Fixed a Windows kube-proxy issue where transient HNS downtime during restart/recovery could cause incorrect LoadBalancer state reconciliation, resulting in duplicate LoadBalancer creation failures with "Cannot create a file when that file already exists. (0xb7)" errors. ([#139503](https://github.com/kubernetes/kubernetes/pull/139503), [@princepereira](https://github.com/princepereira)) [SIG Network and Windows]
- Fixed a bug where the kubelet node shutdown manager could leak dbus connections on repeated failures, eventually leading to thread exhaustion and crash. ([#137141](https://github.com/kubernetes/kubernetes/pull/137141), [@harche](https://github.com/harche)) [SIG Node]
- Fixed a regression where the Job controller could attempt to report `status.active` as 0 while replacement Pod creation was deferred due to pod-failure backoff, causing the Job status update to be rejected by the apiserver. This could delay flushing uncounted terminated Pods, finalizer removal, and Job status updates, leaving Pods stuck `Terminating` and the Job with stale status until the backoff elapsed. ([#139457](https://github.com/kubernetes/kubernetes/pull/139457), [@akhilsingh-git](https://github.com/akhilsingh-git)) [SIG Apps]
- Fixed a scheduler bug where clearing NominatedNodeName left pods tracked under an empty node key in the nominator. ([#139904](https://github.com/kubernetes/kubernetes/pull/139904), [@pacoxu](https://github.com/pacoxu)) [SIG Scheduling]
- Fixed inconsistent ephemeral-storage format between capacity and allocatable in node status by using DecimalSI format for ephemeral-storage capacity. ([#137652](https://github.com/kubernetes/kubernetes/pull/137652), [@0xMH](https://github.com/0xMH)) [SIG Node]
- Kube-proxy now removes stale conntrack entries when a UDP service no longer has any serving endpoints (e.g. scaled down to zero), preventing previously established one-way UDP flows from being blackholed to deleted pod IPs indefinitely. ([#139629](https://github.com/kubernetes/kubernetes/pull/139629), [@Bafff](https://github.com/Bafff)) [SIG Network]
- Kubeadm: Improved resilience of kubeadm etcd learner promotion. kubeadm now correctly handles cases where learner promotion succeeds on the etcd side but a transient client-side error is returned, preventing unnecessary etcd-join failures. ([#139842](https://github.com/kubernetes/kubernetes/pull/139842), [@jihyun-huh](https://github.com/jihyun-huh)) [SIG Cluster Lifecycle]
- Kubeadm: during "kubeadm join", use the KubernetesAPICall timeout
  (default 1 minute) when fetching the kubeadm-config ConfigMap, instead
  of the short 350ms retry used for optional component configs. A new
  shortConfigMapGet parameter is added to FetchInitConfigurationFromCluster
  so that callers like "kubeadm reset" can still use the short retry. ([#139667](https://github.com/kubernetes/kubernetes/pull/139667), [@damdo](https://github.com/damdo)) [SIG Cluster Lifecycle]
- The `PodReadyToStartContainers` condition now includes a diagnostic message when `Status` is `False`, explaining why the pod sandbox is not ready (e.g., "pod sandbox has no IP address", "no pod sandbox exists"). This improves debuggability for pods stuck in `ContainerCreating` state without requiring access to node logs. ([#135300](https://github.com/kubernetes/kubernetes/pull/135300), [@harche](https://github.com/harche)) [SIG Node]

### Other (Cleanup or Flake)

- Empty requests field in config status of resourceclaim when the config applies to all requests ([#139731](https://github.com/kubernetes/kubernetes/pull/139731), [@LionelJouin](https://github.com/LionelJouin)) [SIG Node]
- Kubelet: the Topology Manager now returns a clearer error when the `prefer-closest-numa-nodes` policy option is enabled on a windows node that does not expose NUMA distance information, explaining that the option is not supported there. ([#139760](https://github.com/kubernetes/kubernetes/pull/139760), [@zylxjtu](https://github.com/zylxjtu)) [SIG Node]
- The `service/proxy` subresource of the apiserver now uses the EndpointSlices
  of the service rather than the Endpoints. (This will have no effect unless you
  were previously using that API with a Service for which you constructed the
  Endpoints by hand _and_ disabled EndpointSlice mirroring of them.) ([#134860](https://github.com/kubernetes/kubernetes/pull/134860), [@danwinship](https://github.com/danwinship)) [SIG API Machinery and Network]

## Dependencies

### Added
_Nothing has changed._

### Changed
- github.com/coredns/corefile-migration: [v1.0.31 → v1.0.33](https://github.com/coredns/corefile-migration/compare/v1.0.31...v1.0.33)
- go.opentelemetry.io/contrib/instrumentation/github.com/emicklei/go-restful/otelrestful: [v0.68.0 → v0.69.0](https://github.com/open-telemetry/opentelemetry-go-contrib/compare/instrumentation/github.com/emicklei/go-restful/otelrestful/v0.68.0...instrumentation/github.com/emicklei/go-restful/otelrestful/v0.69.0)
- go.opentelemetry.io/contrib/instrumentation/net/http/otelhttp: [v0.68.0 → v0.69.0](https://github.com/open-telemetry/opentelemetry-go-contrib/compare/instrumentation/net/http/otelhttp/v0.68.0...instrumentation/net/http/otelhttp/v0.69.0)
- go.opentelemetry.io/contrib/propagators/b3: [v1.43.0 → v1.44.0](https://github.com/open-telemetry/opentelemetry-go-contrib/compare/propagators/b3/v1.43.0...propagators/b3/v1.44.0)
- go.opentelemetry.io/otel/exporters/stdout/stdouttrace: [v1.43.0 → v1.44.0](https://github.com/open-telemetry/opentelemetry-go/compare/exporters/stdout/stdouttrace/v1.43.0...exporters/stdout/stdouttrace/v1.44.0)
- k8s.io/kube-openapi: [bbf5c55 → bc653b6](https://github.com/kubernetes/kube-openapi/compare/bbf5c557728870a14cee51b4271cfd51b58ef2f8...bc653b64f9748b1f57d580a5e57be90d295d9b46)
- sigs.k8s.io/apiserver-network-proxy/konnectivity-client: [v0.34.0 → v0.36.0](https://github.com/kubernetes-sigs/apiserver-network-proxy/compare/konnectivity-client/v0.34.0...konnectivity-client/v0.36.0)

### Removed
_Nothing has changed._



# v1.37.0-alpha.1


## Downloads for v1.37.0-alpha.1



### Source Code

filename | sha512 hash
-------- | -----------
[kubernetes.tar.gz](https://dl.k8s.io/v1.37.0-alpha.1/kubernetes.tar.gz) | 9fd5423640e5935366e023dd22c62e9fca12405937c2411e81cc3ca2fc28255a43984bb736a2c4cc30189791d30a79b62e82aa5a80b065ce5b32171a95942a61
[kubernetes-src.tar.gz](https://dl.k8s.io/v1.37.0-alpha.1/kubernetes-src.tar.gz) | e142c1afc4ff99f21bc928354d3eca1508c8ed34cc98952bf75b2ab6171da83864e15218a4669bc555964cbcbddc759ba12ac7cb989a2afa00312e03e56f9fab

### Client Binaries

filename | sha512 hash
-------- | -----------
[kubernetes-client-darwin-amd64.tar.gz](https://dl.k8s.io/v1.37.0-alpha.1/kubernetes-client-darwin-amd64.tar.gz) | adcd35338556cfb80dee5a093d769a89d551609dd8b1d8f5c075bdcf1abd956f13fb1a90b262f47bd99c2b5d8b89db018dbaa818881021d44fef7e072898f09c
[kubernetes-client-darwin-arm64.tar.gz](https://dl.k8s.io/v1.37.0-alpha.1/kubernetes-client-darwin-arm64.tar.gz) | 02e2a54db5dc24b8661e44030e09695078a64a615ca94862edbd222a4c5955c1fa2ae9df6d54329d93b3e329720d6f097f9f32dee0118e612df225ee16d67755
[kubernetes-client-linux-386.tar.gz](https://dl.k8s.io/v1.37.0-alpha.1/kubernetes-client-linux-386.tar.gz) | 9cc9c69c6d76a6afb214a72a5fb06995ed91f6026cc592e64aa94eff3c76a119fc486ddb2ce6a2ca6ab4adf17d48ceb89aae4cd801c572b9128c9e968041e753
[kubernetes-client-linux-amd64.tar.gz](https://dl.k8s.io/v1.37.0-alpha.1/kubernetes-client-linux-amd64.tar.gz) | 6979e554e427dd993b32ca218cfc727f6bccbdc50981251626ab9b1a72c22b270467d27ebcfa7cb6ece7b41d6584e42086886f76a74be3c5cd79b0f4cb5c1c4c
[kubernetes-client-linux-arm.tar.gz](https://dl.k8s.io/v1.37.0-alpha.1/kubernetes-client-linux-arm.tar.gz) | 6c925eb12c287a5cc8860d639176f814255f91bb3f28e4c526137474231e47cbfa2e67176ead7d783a77633b104cf976a523d07f9b784470555c0b5e1c53adc6
[kubernetes-client-linux-arm64.tar.gz](https://dl.k8s.io/v1.37.0-alpha.1/kubernetes-client-linux-arm64.tar.gz) | 37a440504570ccdf8a247b6e148c5b4c249697bd4f42546746de5fadd11bab393a56802c92c363d77e621604721560282d1f482a463e546102e41d2a032c95ac
[kubernetes-client-linux-ppc64le.tar.gz](https://dl.k8s.io/v1.37.0-alpha.1/kubernetes-client-linux-ppc64le.tar.gz) | 08fe5ef61e41ac33c39492e527ebf292e8758fc319e2a3dc8535d454de16161a1c8e77c1c988f44d5b0f5ccab14f97a7587ebaa633ea794e39ac17e18f8288cc
[kubernetes-client-linux-s390x.tar.gz](https://dl.k8s.io/v1.37.0-alpha.1/kubernetes-client-linux-s390x.tar.gz) | 5c1a0e0a94da2a70c67c2a0e3ecc94c1c914d5bbcc49f81b62e9c3141aa3661e59e8e73f908738674cbbbbdee3fea88636f4e1bf742309db86bc12c916744e66
[kubernetes-client-windows-386.tar.gz](https://dl.k8s.io/v1.37.0-alpha.1/kubernetes-client-windows-386.tar.gz) | 7bc268f0352c671e7c30aadcc0af3976960cb0f43efcafd3966ebb99de236a88c53d04deed9fb831b891440319e280239ab9bcc1d9eecb27d5f665ccdf8f143e
[kubernetes-client-windows-amd64.tar.gz](https://dl.k8s.io/v1.37.0-alpha.1/kubernetes-client-windows-amd64.tar.gz) | cd44efdb02873ea13792931621882bb4c8834839874e2aa6cb97293995212a3fa09237dffb014b9510dc09b8638d71e259d44830bdd8b52315c33f5db6c798ce
[kubernetes-client-windows-arm64.tar.gz](https://dl.k8s.io/v1.37.0-alpha.1/kubernetes-client-windows-arm64.tar.gz) | e377ffb371bb61de9e93d8f3f4048768a1ff28bad8682f80cc520e477e1a43e01b5d0c076fdaf8d44ed464cc0dfb9a97f3ecf33aed2fd3b062221278a9ebe2c4

### Server Binaries

filename | sha512 hash
-------- | -----------
[kubernetes-server-linux-amd64.tar.gz](https://dl.k8s.io/v1.37.0-alpha.1/kubernetes-server-linux-amd64.tar.gz) | e88c3f6312ae9567706c0c9ea4558c32ba1e86523d07d1d12d5d8460aa759db44f84c7949806a1c2cddde8cc482d99cace4aca88685e20a5ddfac32f9de76386
[kubernetes-server-linux-arm64.tar.gz](https://dl.k8s.io/v1.37.0-alpha.1/kubernetes-server-linux-arm64.tar.gz) | adf4468c0bb18b2d2ea315dbebf55eb2ed17cd1eb951cafc180b141f0a6fe9302f6c446d760aedc177fb9c14e9cdaf7fd59f8fed9b2511fb713aa33d28c6f847
[kubernetes-server-linux-ppc64le.tar.gz](https://dl.k8s.io/v1.37.0-alpha.1/kubernetes-server-linux-ppc64le.tar.gz) | 26e52f7ce483fbef715162a98ff7506fdd6ee659c2dabfd0a3600e63e1b0a31762451093c3ed2683e50287ba82b057d19388f061e2f06a92a5cc4398ac62f128
[kubernetes-server-linux-s390x.tar.gz](https://dl.k8s.io/v1.37.0-alpha.1/kubernetes-server-linux-s390x.tar.gz) | d19ab25c6914aa6dd2b74398df9d455d37c40784520394399c57a8416a811fc16d4becc048168def681f3c964089ef0ce2de8074d9029829156d9e344ae4feca

### Node Binaries

filename | sha512 hash
-------- | -----------
[kubernetes-node-linux-amd64.tar.gz](https://dl.k8s.io/v1.37.0-alpha.1/kubernetes-node-linux-amd64.tar.gz) | 6e27d1b85181f3642a8c1dcf39243ce6a6c54913529ddf4a0a42884c233da462d3cc0db7bc223272889c2281f7a4d2be69c6327fe49bf9827331373168e818f1
[kubernetes-node-linux-arm64.tar.gz](https://dl.k8s.io/v1.37.0-alpha.1/kubernetes-node-linux-arm64.tar.gz) | f1a6bc663c3226bba06b1a78580e27e1de2f311832e94c30213933b97cbb8ad66a75e6707942cf4aaa8b30c4d2313a799c52b019468783ebaca37874c04bb207
[kubernetes-node-linux-ppc64le.tar.gz](https://dl.k8s.io/v1.37.0-alpha.1/kubernetes-node-linux-ppc64le.tar.gz) | 7e27887af5ef9c20d761ba43a2ec593569962f5aa8a2d854d73cf8ed88b94833f841359a622861817c2759fad4c1ae00bb54c55964168a588da29458aa3530ab
[kubernetes-node-linux-s390x.tar.gz](https://dl.k8s.io/v1.37.0-alpha.1/kubernetes-node-linux-s390x.tar.gz) | 01013b8b020c46562269e1137aaecbfb6171468a08e3ba38238cdb1df0ad46bac8f3e138fb6c8d3c14b81041cce99e409d09cd54a932fb04036cba70673b85fe
[kubernetes-node-windows-amd64.tar.gz](https://dl.k8s.io/v1.37.0-alpha.1/kubernetes-node-windows-amd64.tar.gz) | 6ae104549e49dff89004b252ad0712c137f33b51ffbc56ff0b3ad3147ba6608c8d76ed1e08fb7372a12b14c7ba75d88801e45e9013b433149805a17ca61f7f66

### Container Images

All container images are available as manifest lists and support the described
architectures. It is also possible to pull a specific architecture directly by
adding the "-$ARCH" suffix  to the container image name.

name | architectures
---- | -------------
[registry.k8s.io/conformance:v1.37.0-alpha.1](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/conformance) | [amd64](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/conformance-amd64), [arm64](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/conformance-arm64), [ppc64le](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/conformance-ppc64le), [s390x](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/conformance-s390x)
[registry.k8s.io/kube-apiserver:v1.37.0-alpha.1](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-apiserver) | [amd64](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-apiserver-amd64), [arm64](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-apiserver-arm64), [ppc64le](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-apiserver-ppc64le), [s390x](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-apiserver-s390x)
[registry.k8s.io/kube-controller-manager:v1.37.0-alpha.1](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-controller-manager) | [amd64](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-controller-manager-amd64), [arm64](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-controller-manager-arm64), [ppc64le](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-controller-manager-ppc64le), [s390x](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-controller-manager-s390x)
[registry.k8s.io/kube-proxy:v1.37.0-alpha.1](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-proxy) | [amd64](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-proxy-amd64), [arm64](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-proxy-arm64), [ppc64le](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-proxy-ppc64le), [s390x](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-proxy-s390x)
[registry.k8s.io/kube-scheduler:v1.37.0-alpha.1](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-scheduler) | [amd64](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-scheduler-amd64), [arm64](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-scheduler-arm64), [ppc64le](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-scheduler-ppc64le), [s390x](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kube-scheduler-s390x)
[registry.k8s.io/kubectl:v1.37.0-alpha.1](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kubectl) | [amd64](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kubectl-amd64), [arm64](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kubectl-arm64), [ppc64le](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kubectl-ppc64le), [s390x](https://console.cloud.google.com/artifacts/docker/k8s-artifacts-prod/southamerica-east1/images/kubectl-s390x)

## Changelog since v1.36.0

## Urgent Upgrade Notes

### (No, really, you MUST read this before you upgrade)

 - When eventRecordQPS in kubelet configuration file is set to 0, there will be no limit enforced. The bug when 0 value was treated as a default value, while the field description was saying "unlimited" is fixed.
  if your kubelet configuration setting eventRecordQPS to 0 and you want to preserve the previous behavior, please change the value to 50. Keeping it as 0 will make it undefined. ([#117119](https://github.com/kubernetes/kubernetes/pull/117119), [@HirazawaUi](https://github.com/HirazawaUi)) [SIG API Machinery, Auth and Node]
 
## Changes by Kind

### Dependency

- Updated the default etcd version to 3.7.0-rc.0 ([#139427](https://github.com/kubernetes/kubernetes/pull/139427), [@Jefftree](https://github.com/Jefftree)) [SIG API Machinery, Cloud Provider, Cluster Lifecycle, Etcd and Testing]
- Updates the etcd client library to v3.6.10 ([#138393](https://github.com/kubernetes/kubernetes/pull/138393), [@humblec](https://github.com/humblec)) [SIG API Machinery, Architecture, Auth, CLI, Cloud Provider, Cluster Lifecycle, Etcd, Instrumentation, Network, Node, Scheduling and Storage]

### Deprecation

- Deprecated the ignored `--filename`/`-f` flag on `kubectl run`. ([#138671](https://github.com/kubernetes/kubernetes/pull/138671), [@Suknna](https://github.com/Suknna)) [SIG CLI]
- Kubeadm: added a (delayed) warning that kube-proxy's 'ipvs' mode is deprecated since v1.35 and users on newer Linux kernels should be using the 'nftables' mode instead, which became GA in 1.33. For older kernel versions, users can use 'iptables', which is still the default. ([#139067](https://github.com/kubernetes/kubernetes/pull/139067), [@neolit123](https://github.com/neolit123)) [SIG Cluster Lifecycle]
- The deprecated `DeclarativeValidationTakeover` feature gate is now locked to its default value and can no longer be set. ([#139212](https://github.com/kubernetes/kubernetes/pull/139212), [@yongruilin](https://github.com/yongruilin)) [SIG API Machinery]

### API Change

- API Go types switched the json tag for inlined TypeMeta fields from `",inline"` to simply `""`. `inline` was not a recognized json serializer option and did not modify marshal or unmarshal behavior. ([#138260](https://github.com/kubernetes/kubernetes/pull/138260), [@liggitt](https://github.com/liggitt)) [SIG API Machinery, Apps, Architecture, Auth, CLI, Cloud Provider, Cluster Lifecycle, Etcd, Instrumentation, Network, Node, Scheduling, Storage and Testing]
- Converts the `DisruptionMode` enum field to struct to support future extensibility.
  Promotes the `scheduling.k8s.io` API group from `v1alpha2` to `v1alpha3` and drops `v1alpha2` entirely.
  Remember to remove all `v1alpha2` objects from the api-server while performing the cluster update. ([#138572](https://github.com/kubernetes/kubernetes/pull/138572), [@dom4ha](https://github.com/dom4ha)) [SIG API Machinery, Apps, CLI, Etcd, Node, Scheduling and Testing]
- DRA extended resource feature is promoted to GA in 1.37 ([#138488](https://github.com/kubernetes/kubernetes/pull/138488), [@yliaog](https://github.com/yliaog)) [SIG API Machinery, Apps, Node, Scheduling and Testing]
- Fixes a 1.34+ regression handling containers with environment values set from Secret API objects containing binary non-utf8 data. ([#139168](https://github.com/kubernetes/kubernetes/pull/139168), [@liggitt](https://github.com/liggitt)) [SIG Architecture, Node and Testing]
- HorizontalPodAutoscaler conditions allow optionally including the `observedGeneration` at the time the condition was recorded ([#138653](https://github.com/kubernetes/kubernetes/pull/138653), [@adrianmoisey](https://github.com/adrianmoisey)) [SIG API Machinery, Apps, Autoscaling and Testing]
- Improved CEL error messages in Dynamic Resource Allocation to provide guidance when accessing non-existent device attributes. Error messages now link to documentation on handling optional fields using orValue() and has(). ([#136709](https://github.com/kubernetes/kubernetes/pull/136709), [@gzb1128](https://github.com/gzb1128)) [SIG API Machinery, Node and Scheduling]
- Promoted kubelet volume metrics (`storage_operation_duration_seconds`, `volume_operation_total_seconds`) from Alpha to Beta stability, providing stronger API and label stability guarantees for metric consumers. ([#136189](https://github.com/kubernetes/kubernetes/pull/136189), [@bhope](https://github.com/bhope)) [SIG Instrumentation and Storage]
- Removed the generally available feature gate `AnyVolumeDataSource`, which was locked and enabled since 1.33. ([#135336](https://github.com/kubernetes/kubernetes/pull/135336), [@carlory](https://github.com/carlory)) [SIG API Machinery, Apps, Storage and Testing]
- Removed the unused `PodStatusResult` type from the Kubernetes API. This type had no REST endpoint and has been unused since 2015. ([#136271](https://github.com/kubernetes/kubernetes/pull/136271), [@adityasharmawork](https://github.com/adityasharmawork)) [SIG API Machinery, Apps, Node and Testing]
- The change is for developers building against cri-api. Enum keys of Signal are now prefixed with `SIGNAL_` in api.proto definition to avoid conflicts with C++ macroses. The wire format is unchanged. ([#139251](https://github.com/kubernetes/kubernetes/pull/139251), [@SergeyKanzhelev](https://github.com/SergeyKanzhelev)) [SIG Apps, Node and Testing]

### Feature

- Add new KubeProxyIPVS feature gate in preparation of deactivating and then removing the ipvs mode of kube-proxy. ([#139397](https://github.com/kubernetes/kubernetes/pull/139397), [@adrianmoisey](https://github.com/adrianmoisey)) [SIG Network]
- Added Prometheus metrics for Windows kube-proxy (winkernel) load balancer operation failures: `kubeproxy_sync_proxy_rules_winkernel_lb_create_failures_total`, `kubeproxy_sync_proxy_rules_winkernel_lb_update_failures_total`, and `kubeproxy_sync_proxy_rules_winkernel_lb_delete_failures_total`. Each metric includes `ip_family`, `lb_type`, and `error` labels for fine-grained failure observability. ([#137767](https://github.com/kubernetes/kubernetes/pull/137767), [@princepereira](https://github.com/princepereira)) [SIG Instrumentation, Network and Windows]
- Added ServiceName, PodManagementPolicy, and PersistentVolumeClaimRetentionPolicy to `kubectl describe statefulset` output. ([#137547](https://github.com/kubernetes/kubernetes/pull/137547), [@kfess](https://github.com/kfess)) [SIG CLI]
- Added `AnnotatedEventf` method to the new events API (`EventRecorder` and `EventRecorderLogger` interfaces in `client-go/tools/events`), enabling callers to attach custom annotations to events at creation time. ([#138103](https://github.com/kubernetes/kubernetes/pull/138103), [@adri1197](https://github.com/adri1197)) [SIG API Machinery and Node]
- Added `net.ipv4.tcp_slow_start_after_idle` and `net.ipv4.tcp_notsent_lowat` to the allowed safe sysctls list. ([#138389](https://github.com/kubernetes/kubernetes/pull/138389), [@gheffern](https://github.com/gheffern)) [SIG Auth, Network and Node]
- Added an alpha feature gate, ConsistentListFromCacheSkipTimeoutFallback. When enabled, kube-apiserver returns HTTP 429 for consistent LIST requests that cannot be served from watch cache within the timeout window, instead of falling back to storage. ([#138701](https://github.com/kubernetes/kubernetes/pull/138701), [@yedou37](https://github.com/yedou37)) [SIG API Machinery]
- Added metric `apiserver_watch_cache_initialization_duration_seconds` recording the duration of the most recent watch cache initialization, labeled by group and resource. ([#138767](https://github.com/kubernetes/kubernetes/pull/138767), [@Jefftree](https://github.com/Jefftree)) [SIG API Machinery and Instrumentation]
- Added scheduler extension point "PlacementFeasible" to allow for early termination of PodGroup scheduling cycle. This extension point is used by the GangScheduling plugin to stop evaluating pods once minCount becomes unsatisfiable. ([#138643](https://github.com/kubernetes/kubernetes/pull/138643), [@brejman](https://github.com/brejman)) [SIG Scheduling and Testing]
- Added structured `CauseType` values to PodDisruptionBudget-related eviction `Forbidden` errors in the eviction API, allowing clients to programmatically distinguish PDB invalid-state errors from other forbidden errors without string-matching on the message. ([#138003](https://github.com/kubernetes/kubernetes/pull/138003), [@shady0503](https://github.com/shady0503)) [SIG Apps, Auth and Node]
- Added support for testing invariant metrics in integration tests. ([#137883](https://github.com/kubernetes/kubernetes/pull/137883), [@lalitc375](https://github.com/lalitc375)) [SIG API Machinery, Auth and Testing]
- Added the `EtcdRangeStream` beta feature gate. The watch cache initializes by streaming objects from etcd in a single `RangeStream` RPC instead of paginated `Range` requests. ([#136915](https://github.com/kubernetes/kubernetes/pull/136915), [@Jefftree](https://github.com/Jefftree)) [SIG API Machinery, Architecture, Auth, CLI, Cloud Provider, Cluster Lifecycle, Etcd, Instrumentation, Network, Node, Scheduling, Storage and Testing]
- Adds the `+k8s:dependentRequired("siblingJSONName")` declarative validation tag. When the tagged field is set, the named sibling must also be set ([#139164](https://github.com/kubernetes/kubernetes/pull/139164), [@yongruilin](https://github.com/yongruilin)) [SIG API Machinery]
- After successful pod group preemption, the pods from pod group will have their Nominated Node Name set, similarly to pod preemption ([#138967](https://github.com/kubernetes/kubernetes/pull/138967), [@antekjb](https://github.com/antekjb)) [SIG Scheduling and Testing]
- Apply --field-selector to pod metrics when invoking kubectl top pod ([#139107](https://github.com/kubernetes/kubernetes/pull/139107), [@Mujib-Ahasan](https://github.com/Mujib-Ahasan)) [SIG CLI]
- Binding API calls in kube-scheduler are now retried when a transient error occurs. ([#138855](https://github.com/kubernetes/kubernetes/pull/138855), [@antekjb](https://github.com/antekjb)) [SIG Scheduling]
- Bump coredns to 1.14.3 ([#138536](https://github.com/kubernetes/kubernetes/pull/138536), [@yashsingh74](https://github.com/yashsingh74)) [SIG Cloud Provider and Cluster Lifecycle]
- Changed the `PatchPodStatus` API in the scheduler framework to accept a slice of Pod conditions (`[]*v1.PodCondition`) instead of a single condition (`*v1.PodCondition`). This allows scheduler plugins to update multiple Pod conditions in a single API call, preventing newer calls from overwriting older ones when multiple conditions need to be updated concurrently. ([#135160](https://github.com/kubernetes/kubernetes/pull/135160), [@KunWuLuan](https://github.com/KunWuLuan)) [SIG Scheduling]
- Ensure stale cache does not impact the marking of nodes as unhealthy by checking with a live get ([#138698](https://github.com/kubernetes/kubernetes/pull/138698), [@michaelasp](https://github.com/michaelasp)) [SIG Apps, Auth and Node]
- Errors coming from pod group preemption are now prefixed with `pod group preemption:` message. ([#139218](https://github.com/kubernetes/kubernetes/pull/139218), [@Argh4k](https://github.com/Argh4k)) [SIG Scheduling]
- Functions and structs that take in authorizer.Authorizer might now choose to accept only a smaller interface, authorizer.UnconditionalAuthorizer, in case only the receiver only needs to perform unconditional authorization requests and wants to signal this in the code for clarity. Any authorizer implementation must still implement the full authorizer.Authorizer interface. ([#138801](https://github.com/kubernetes/kubernetes/pull/138801), [@luxas](https://github.com/luxas)) [SIG API Machinery, Auth, Node, Scheduling and Testing]
- Graduate WatchCacheInitializationPostStartHook to GA ([#139452](https://github.com/kubernetes/kubernetes/pull/139452), [@serathius](https://github.com/serathius)) [SIG API Machinery]
- Kube-controller-manager: The HPA controller now defers syncing an HPA object when the controller has not yet observed HPA status writes from the last time the object was synced. ([#139025](https://github.com/kubernetes/kubernetes/pull/139025), [@omerap12](https://github.com/omerap12)) [SIG Apps and Autoscaling]
- Kube-scheduler now supports PodGroups in its scheduling queue. The active, backoff, and unschedulable queues have been abstracted to store `QueuedEntityInfo` (handling either individual pods or pod groups). ([#138567](https://github.com/kubernetes/kubernetes/pull/138567), [@macsko](https://github.com/macsko)) [SIG Instrumentation, Scheduling and Testing]
- Kube-scheduler: Added `PlacementCycleState` to the scheduling framework, providing per-placement state to `PlacementScore` plugins under the alpha `TopologyAwareWorkloadScheduling` feature gate. ([#138274](https://github.com/kubernetes/kubernetes/pull/138274), [@wtravO](https://github.com/wtravO)) [SIG Scheduling]
- Kubeadm: add the "kubeproxydaemonset" patch target to allow patching the kube-proxy DaemonSet during "kubeadm init" and "kubeadm upgrade", consistent with the existing "corednsdeployment" patch target. ([#138090](https://github.com/kubernetes/kubernetes/pull/138090), [@SataQiu](https://github.com/SataQiu)) [SIG Cluster Lifecycle]
- Kubeadm: during preflight, instead of running the "Port-xx" checks for kube-apiserver, kube-scheduler, kube-controller-manager and etcm using a "net.Listen()" call without an address (which instructs the operating system to bind to all available unicast and anycast IP addresses for a given port), pass an address which is configured in the kubeadm config for the respective components either using the "localAPIEndpoint.address" field or using the "--bind-address" extraArgs override. ([#138250](https://github.com/kubernetes/kubernetes/pull/138250), [@lentzi90](https://github.com/lentzi90)) [SIG Cluster Lifecycle]
- Kubeadm: removed the NodeLocalCRISocket feature gate which graduated to GA and was locked to enabled by default in a previous release. ([#138645](https://github.com/kubernetes/kubernetes/pull/138645), [@neolit123](https://github.com/neolit123)) [SIG Cluster Lifecycle]
- Kubeadm: the preflight check `ContainerRuntimeVersion` validates if the installed container runtime supports the `RuntimeConfig` gRPC method. For older kubelet versions than 1.38, it will return a preflight warning. ([#139122](https://github.com/kubernetes/kubernetes/pull/139122), [@carlory](https://github.com/carlory)) [SIG Cluster Lifecycle]
- Kubectl now sets its path in the KUBECTL_PATH environment variable when executing a plugin. ([#138694](https://github.com/kubernetes/kubernetes/pull/138694), [@brianpursley](https://github.com/brianpursley)) [SIG CLI and Testing]
- Kubelet: defer the configurations flags (and the related fallback behavior) deprecation removal timeline from 1.37 to 1.38 to align with containerd v1.7 support ([#139121](https://github.com/kubernetes/kubernetes/pull/139121), [@carlory](https://github.com/carlory)) [SIG Node and Testing]
- Kubernetes is now built using Go 1.26.4 ([#139584](https://github.com/kubernetes/kubernetes/pull/139584), [@cpanato](https://github.com/cpanato)) [SIG Release and Testing]
- Kubernetes is now built with Go 1.26.3 ([#138864](https://github.com/kubernetes/kubernetes/pull/138864), [@BenTheElder](https://github.com/BenTheElder)) [SIG Release]
- Kubernetes is now built with Go 1.26.4 ([#139479](https://github.com/kubernetes/kubernetes/pull/139479), [@BenTheElder](https://github.com/BenTheElder)) [SIG Release]
- Made it possible for authorizers to return conditional decisions in addition to unconditional (Allow/Deny/NoOpinion). ([#137204](https://github.com/kubernetes/kubernetes/pull/137204), [@luxas](https://github.com/luxas)) [SIG API Machinery, Auth, Node, Scheduling and Testing]
- Optimized CEL admission policy evaluation by adopting a lazy zero-allocation reflection-based utility for object traversal, significantly reducing CPU usage and garbage collection overhead during request processing. ([#138771](https://github.com/kubernetes/kubernetes/pull/138771), [@lalitc375](https://github.com/lalitc375)) [SIG API Machinery, Architecture, Auth, CLI, Cloud Provider, Cluster Lifecycle, Network, Node, Scheduling and Storage]
- Promote `serviceaccount_legacy_tokens_total`, `serviceaccount_stale_tokens_total`, `serviceaccount_valid_tokens_total` to beta ([#137072](https://github.com/kubernetes/kubernetes/pull/137072), [@tico88612](https://github.com/tico88612)) [SIG Auth, Instrumentation and Testing]
- Promote the apiserver webhook `apiserver_webhooks_x509_missing_san_total` and `apiserver_webhooks_x509_insecure_sha1_total` metrics to BETA and update their documentation. ([#136894](https://github.com/kubernetes/kubernetes/pull/136894), [@LoginovIlia](https://github.com/LoginovIlia)) [SIG API Machinery, Instrumentation and Testing]
- The MaxUnavailableStatefulSet feature is now enabled by default. ([#139466](https://github.com/kubernetes/kubernetes/pull/139466), [@soltysh](https://github.com/soltysh)) [SIG Apps]
- The `apiserver_storage_list_*` metrics now include `storage` and `index` labels to distinguish the storage backend and lookup path used to serve LIST requests. ([#139125](https://github.com/kubernetes/kubernetes/pull/139125), [@yedou37](https://github.com/yedou37)) [SIG API Machinery, Etcd and Instrumentation]
- The scheduler now avoids redundant preemption attempts during PodGroup scheduling when terminating victim pods are already present on the nominated nodes. ([#138710](https://github.com/kubernetes/kubernetes/pull/138710), [@mm4tt](https://github.com/mm4tt)) [SIG Scheduling]
- Three different subtypes of the cluster event resource "Pod" are being added: "AssignedPod", "UnscheduledPod", "TargetPod". Plugins can and are expected to register to specific pod events for better performance. ([#135905](https://github.com/kubernetes/kubernetes/pull/135905), [@iomarsayed](https://github.com/iomarsayed)) [SIG Node, Scheduling, Storage and Testing]
- Updated cri-tools to v1.36.0. ([#138613](https://github.com/kubernetes/kubernetes/pull/138613), [@saschagrunert](https://github.com/saschagrunert)) [SIG Cloud Provider and Node]
- Workload-aware preemption now preempts victims so that as many as possible of the preemptor pods can be scheduled. ([#138757](https://github.com/kubernetes/kubernetes/pull/138757), [@jdzikowski](https://github.com/jdzikowski)) [SIG Scheduling and Testing]
- `kubectl get crd` now displays additional columns—GROUP, SCOPE, VERSIONS, and CREATED AT—alongside NAME.  
  
  This provides at-a-glance visibility into the API group, scope (Cluster‑ or Namespaced), served versions (comma‑separated), and exact creation timestamp of each CustomResourceDefinition. ([#131599](https://github.com/kubernetes/kubernetes/pull/131599), [@jaehanbyun](https://github.com/jaehanbyun)) [SIG API Machinery]

### Documentation

- Fixed a nil pointer dereference panic in client-go event recorder when processing events with nil fields.
  
    Additional documentation e.g., KEPs (Kubernetes Enhancements Proposals), usage docs, etc.:
  
    N/A
  
    /sig api-machinery
    /area client-libraries
    /priority important-soon ([#135925](https://github.com/kubernetes/kubernetes/pull/135925), [@jianzhangbjz](https://github.com/jianzhangbjz)) [SIG API Machinery]
- Update Japanese translation for kubectl ([#131176](https://github.com/kubernetes/kubernetes/pull/131176), [@yude](https://github.com/yude)) [SIG CLI and Testing]

### Failing Test

- Fixed a bug, where nomination of gated pod wasn't preventing lower priority pods from scheduling on the nominated space. ([#139057](https://github.com/kubernetes/kubernetes/pull/139057), [@macsko](https://github.com/macsko)) [SIG Scheduling]

### Bug or Regression

- Avoid costly comparisons during selinux metric emission. ([#138981](https://github.com/kubernetes/kubernetes/pull/138981), [@gnufied](https://github.com/gnufied)) [SIG Apps and Storage]
- Client-go: RetryWatcher now logs 410 Gone (resource expired) errors at debug verbosity (V(4)) instead of ERROR level during watch establishment. ([#138295](https://github.com/kubernetes/kubernetes/pull/138295), [@kencochrane](https://github.com/kencochrane)) [SIG API Machinery]
- DRA metadata read helper (KEP-5304): on decode skip only if version is unknown, return error if object/file is malformed ([#138530](https://github.com/kubernetes/kubernetes/pull/138530), [@alaypatel07](https://github.com/alaypatel07)) [SIG Node]
- Exposes the error reason when invalid service CIDRs are configured ([#139182](https://github.com/kubernetes/kubernetes/pull/139182), [@PseudoResonance](https://github.com/PseudoResonance)) [SIG Network]
- Fix a regression in kubernetes v1.35, where with a Parallel pod management policy unavailable pods from an older revision were incorrectly counted towards maxUnavailable budget. ([#137666](https://github.com/kubernetes/kubernetes/pull/137666), [@soltysh](https://github.com/soltysh)) [SIG Apps]
- Fix apiserver to create metadata fields for create-via-update and created-via-apply requests like they are for create requests. UID and resourceVersion preconditions are still honored. ([#138908](https://github.com/kubernetes/kubernetes/pull/138908), [@jpbetz](https://github.com/jpbetz)) [SIG API Machinery and Testing]
- Fix duplicated mount arguments in log string output from MakeMountArgsSensitiveWithMountFlags ([#138098](https://github.com/kubernetes/kubernetes/pull/138098), [@jeffbearer](https://github.com/jeffbearer)) [SIG Storage]
- Fix issue with stateful set controller skip metrics not being properly registered. ([#138451](https://github.com/kubernetes/kubernetes/pull/138451), [@michaelasp](https://github.com/michaelasp)) [SIG API Machinery, Apps and Testing]
- Fix nil pointer dereference in Windows memory eviction threshold notifier when GetPerformanceInfo() fails. ([#138727](https://github.com/kubernetes/kubernetes/pull/138727), [@rzlink](https://github.com/rzlink)) [SIG Node]
- Fix regression in kubectl resource printing on bigger data sets (100+ rows) ([#138550](https://github.com/kubernetes/kubernetes/pull/138550), [@rawkode](https://github.com/rawkode)) [SIG CLI]
- Fixed VolumeAttachment validation to report the correct maximum message size (1024 bytes) in error messages. ([#136436](https://github.com/kubernetes/kubernetes/pull/136436), [@Okabe-Junya](https://github.com/Okabe-Junya)) [SIG Storage]
- Fixed a bug in ImageLocality scoring where image volumes could receive a higher score than equivalent regular container images. ([#138951](https://github.com/kubernetes/kubernetes/pull/138951), [@sujoshua](https://github.com/sujoshua)) [SIG Scheduling]
- Fixed a bug when the GenericWorkload feature gate is enabled that could prevent Pods in the same PodGroup sharing the same ResourceClaim from successfully scheduling. ([#139418](https://github.com/kubernetes/kubernetes/pull/139418), [@nojnhuh](https://github.com/nojnhuh)) [SIG Node and Scheduling]
- Fixed a bug where Pod `.status.resourceClaimStatuses` could flap between partial lists of claims, when multiple claims were used in the pod. ([#138408](https://github.com/kubernetes/kubernetes/pull/138408), [@johnbelamaric](https://github.com/johnbelamaric)) [SIG Apps and Node]
- Fixed a bug where Pods that share multi-node claims and also have per-node claims can get stuck in Pending. ([#139017](https://github.com/kubernetes/kubernetes/pull/139017), [@johnbelamaric](https://github.com/johnbelamaric)) [SIG Node and Scheduling]
- Fixed a bug where StatefulSet with OnDelete update strategy never updated
  Status.CurrentRevision to match Status.UpdateRevision after all pods were
  recreated with the new revision. ([#136833](https://github.com/kubernetes/kubernetes/pull/136833), [@zhijun42](https://github.com/zhijun42)) [SIG Apps]
- Fixed a bug where `kubectl drain --disable-eviction --dry-run=server` hangs indefinitely. ([#137543](https://github.com/kubernetes/kubernetes/pull/137543), [@kfess](https://github.com/kfess)) [SIG CLI and Testing]
- Fixed a bug where disabling the MemoryQoS feature gate did not clear per-container memory.high cgroup values, causing containers to remain throttled at stale limits. ([#139377](https://github.com/kubernetes/kubernetes/pull/139377), [@sohankunkerkar](https://github.com/sohankunkerkar)) [SIG Node and Testing]
- Fixed a bug where kubelet would generate an event once per second for every image volume in a pod. ([#138655](https://github.com/kubernetes/kubernetes/pull/138655), [@mdbooth](https://github.com/mdbooth)) [SIG Node]
- Fixed a bug where pods with multiple subPath volume mounts on Windows would get stuck in Terminating state because file handles from subPath preparation were leaked, preventing volume cleanup. ([#138367](https://github.com/kubernetes/kubernetes/pull/138367), [@timmy-wright](https://github.com/timmy-wright)) [SIG Node, Testing and Windows]
- Fixed a bug where the kubelet did not enforce per-container ephemeral-storage limits on restartable init containers (sidecar containers), allowing them to exceed their declared limit without triggering pod eviction. ([#138462](https://github.com/kubernetes/kubernetes/pull/138462), [@shachartal](https://github.com/shachartal)) [SIG Node and Testing]
- Fixed a kube-proxy IPVS-mode performance bug where `syncProxyRules` could take tens of seconds in clusters with many Services because `GetAllLocalAddressesExcept` issued one full netlink address dump per interface. The function now issues a single dump per address family, reducing `syncProxyRules` latency by orders of magnitude on large clusters. ([#138927](https://github.com/kubernetes/kubernetes/pull/138927), [@ytcisme](https://github.com/ytcisme)) [SIG Network]
- Fixed a kube-scheduler panic when a DRA ResourceClaim using `allocationMode: All` selects a device that consumes shared counters. ([#138885](https://github.com/kubernetes/kubernetes/pull/138885), [@takonomura](https://github.com/takonomura)) [SIG Node]
- Fixed a kubelet panic in image pull credential verification when maxParallelImagePulls is configured above 31. ([#138937](https://github.com/kubernetes/kubernetes/pull/138937), [@RajvardhanPatil07](https://github.com/RajvardhanPatil07)) [SIG Node]
- Fixed a panic in the endpoint controller when processing services with empty IPFamilies field (pre-dual-stack services that were never spec-updated). ([#138736](https://github.com/kubernetes/kubernetes/pull/138736), [@rahulbabu95](https://github.com/rahulbabu95)) [SIG Apps and Network]
- Fixed a race condition in preemption, where a preemptor pod could get stuck in unschedulable state. ([#139162](https://github.com/kubernetes/kubernetes/pull/139162), [@brejman](https://github.com/brejman)) [SIG Scheduling and Testing]
- Fixed a regression in 1.36 where modifications to scheduling directives (nodeSelector, tolerations, node affinity) on suspended Jobs were rejected if the JobSuspended condition had not yet been set by the job controller. ([#139287](https://github.com/kubernetes/kubernetes/pull/139287), [@kannon92](https://github.com/kannon92)) [SIG Apps and Testing]
- Fixed a regression where kubelet did not clear stale cgroup v2 memory.min and memory.low values when the MemoryQoS feature gate was disabled after being previously enabled. ([#138903](https://github.com/kubernetes/kubernetes/pull/138903), [@sohankunkerkar](https://github.com/sohankunkerkar)) [SIG Node and Testing]
- Fixed an issue in the CronJob controller where it failed to adopt existing Jobs by erroneously using the empty namespace from the JobTemplate. ([#136920](https://github.com/kubernetes/kubernetes/pull/136920), [@ysam12345](https://github.com/ysam12345)) [SIG Apps]
- Fixed an issue where kubelet would delete the CSI mount directory when
  a periodic NodePublishVolume call (triggered by
  CSIDriver.spec.requiresRepublish=true) returned an error, leaving the
  pod with stale volume contents that subsequent successful republishes
  could not repair. ([#139045](https://github.com/kubernetes/kubernetes/pull/139045), [@aramase](https://github.com/aramase)) [SIG Storage]
- Fixed build for test/images/glibc-dns-testing ([#138877](https://github.com/kubernetes/kubernetes/pull/138877), [@BenTheElder](https://github.com/BenTheElder)) [SIG Network and Testing]
- Fixed duplicate logs when trying to attach to a pod fails. ([#139091](https://github.com/kubernetes/kubernetes/pull/139091), [@olamilekan000](https://github.com/olamilekan000)) [SIG CLI]
- Fixed incorrect error message formatting in the HPA controller when object metric retrieval fails. Error messages now correctly display the metric name, object kind, namespace, object name, and the underlying error. Also improved error wrapping across the HPA controller to use %w instead of %v, enabling proper error chain inspection. ([#139029](https://github.com/kubernetes/kubernetes/pull/139029), [@Fedosin](https://github.com/Fedosin)) [SIG Apps and Autoscaling]
- Fixed kubectl get storageclass to show only the effective default StorageClass as "(default)" when multiple StorageClasses have the default annotation. ([#135964](https://github.com/kubernetes/kubernetes/pull/135964), [@jaehanbyun](https://github.com/jaehanbyun)) [SIG CLI and Storage]
- Fixed kubelet failure starting on ZFS due to missing cadvisor plugin. ([#138587](https://github.com/kubernetes/kubernetes/pull/138587), [@BenTheElder](https://github.com/BenTheElder)) [SIG Node]
- Fixed queue hint for inter-pod anti-affinity in case there are multiple terms, which might have caused delays in scheduling. ([#139161](https://github.com/kubernetes/kubernetes/pull/139161), [@brejman](https://github.com/brejman)) [SIG Scheduling]
- Fixed stale remote HNS endpoint cleanup on Windows when a pod IP is reused across nodes in L2Bridge networks, preventing DNS timeouts caused by traffic being routed to the wrong node. ([#138000](https://github.com/kubernetes/kubernetes/pull/138000), [@princepereira](https://github.com/princepereira)) [SIG Network and Windows]
- Fixed the inconsistency between opportunistic batching and PodGroups that made the batching hints always infeasible during PodGroup scheduling cycle. ([#138754](https://github.com/kubernetes/kubernetes/pull/138754), [@macsko](https://github.com/macsko)) [SIG Scheduling]
- Fixed the wrong cause of the UnexpectedJob event/warning by checking the owner reference of the job correctly in the cron job controller. ([#133313](https://github.com/kubernetes/kubernetes/pull/133313), [@kei01234kei](https://github.com/kei01234kei)) [SIG Apps]
- Generate `metadata.generation` and `status.observedGeneration` fields in HorizontalPodAutoscaler resources ([#138228](https://github.com/kubernetes/kubernetes/pull/138228), [@adrianmoisey](https://github.com/adrianmoisey)) [SIG API Machinery, Apps, Autoscaling and Testing]
- HPA controller now reconciles newly created and spec-changed HPAs immediately instead of waiting for the full resync period (default 15s). ([#138294](https://github.com/kubernetes/kubernetes/pull/138294), [@Fedosin](https://github.com/Fedosin)) [SIG Apps and Autoscaling]
- Image volume validation now rejects empty `image.reference` fields in Pod templates (Deployment, StatefulSet, DaemonSet, Job, etc.). ([#135989](https://github.com/kubernetes/kubernetes/pull/135989), [@Okabe-Junya](https://github.com/Okabe-Junya)) [SIG Apps and Node]
- Improve error reporting when invoking kubectl exec ([#138214](https://github.com/kubernetes/kubernetes/pull/138214), [@hunshcn](https://github.com/hunshcn)) [SIG CLI and Testing]
- Kube-apiserver now validates the `--advertise-address` IP when using `--endpoint-reconciler-type` `master-count` or `lease` to ensure the specified IP address can be persisted to an `Endpoints` API object successfully. ([#138102](https://github.com/kubernetes/kubernetes/pull/138102), [@kairosci](https://github.com/kairosci)) [SIG API Machinery]
- Kube-proxy does not perform full-sync operations when operation in large cluster mode (more than 1000 endpoints) ([#138571](https://github.com/kubernetes/kubernetes/pull/138571), [@aojea](https://github.com/aojea)) [SIG Network]
- Kube-proxy now truncates nftables comments to the kernel's 128-byte limit before programming service maps, avoiding sync failures for long Service names. ([#139516](https://github.com/kubernetes/kubernetes/pull/139516), [@Vinayak9769](https://github.com/Vinayak9769)) [SIG Network]
- Kubeadm: during 'kubeadm init', if the default 'admin.conf' and 'super-admin.conf' paths are used, load the files, but construct in memory kubeconfigs that point to the InitConfiguration.localAPIEndpoint instead of the ClusterConfiguration.controlPlaneEndpoint. This would resolve issues with delayed load balancers which are provisioned only after the first kube-apiserver instance starts. ([#138449](https://github.com/kubernetes/kubernetes/pull/138449), [@neolit123](https://github.com/neolit123)) [SIG Cluster Lifecycle]
- Kubeadm: fix MemberPromote to skip the etcd promote API call when the member is already a voting member, avoiding unnecessary retries and timeout. ([#138390](https://github.com/kubernetes/kubernetes/pull/138390), [@wgkingk](https://github.com/wgkingk)) [SIG Cluster Lifecycle]
- Kubeadm: fixed a panic in kubeadm PKI key loading when the private key type and public key type mismatch. ([#138939](https://github.com/kubernetes/kubernetes/pull/138939), [@SataQiu](https://github.com/SataQiu)) [SIG Cluster Lifecycle]
- Kubeadm: fixed kubeadm init phase certs --dry-run to correctly copy existing CA files. ([#139339](https://github.com/kubernetes/kubernetes/pull/139339), [@ErikJiang](https://github.com/ErikJiang)) [SIG Cluster Lifecycle]
- Kubeadm: kubeadm join now returns a clear error message when the TLS bootstrap kubeconfig has a current-context that does not appear in the contexts list, instead of panicking with a nil pointer dereference. ([#138853](https://github.com/kubernetes/kubernetes/pull/138853), [@alexmchughdev](https://github.com/alexmchughdev)) [SIG Cluster Lifecycle]
- Kubeadm: skip LocalAPIEndpoint defaulting on 'kubeadm join' for worker nodes. ([#138692](https://github.com/kubernetes/kubernetes/pull/138692), [@clwluvw](https://github.com/clwluvw)) [SIG Cluster Lifecycle]
- Kubeadm: use a dedicated ClusterRole 'system:kubelet-api-admin' for the kube-apiserver kubelet client. ([#138957](https://github.com/kubernetes/kubernetes/pull/138957), [@neolit123](https://github.com/neolit123)) [SIG Cluster Lifecycle]
- Kubeadm: when checking the etcd cluster status use a quorum approach, instead of considering the health of all members. This would allow the check to not fail if there are sufficient healthy voting members. ([#138403](https://github.com/kubernetes/kubernetes/pull/138403), [@ahrtr](https://github.com/ahrtr)) [SIG Cluster Lifecycle]
- Kubeadm: when fetching cluster-info over HTTPS during discovery, the HTTP response status code is now checked, so a non-200 response produces a clear error instead of a confusing kubeconfig parse failure. ([#138852](https://github.com/kubernetes/kubernetes/pull/138852), [@alexmchughdev](https://github.com/alexmchughdev)) [SIG Cluster Lifecycle]
- Kubectl get now errors when --label-columns is used with custom-columns output. ([#138094](https://github.com/kubernetes/kubernetes/pull/138094), [@ahmadmaha02](https://github.com/ahmadmaha02)) [SIG CLI]
- Kubelet now enforces explicit HTTP method restrictions for logs-related endpoints. Read-only kubelet server endpoints reject non-GET methods with 405. NodeLogQuery explicitly allows only GET and POST and rejects other methods with 405. ([#138088](https://github.com/kubernetes/kubernetes/pull/138088), [@amritansh1502](https://github.com/amritansh1502)) [SIG Node]
- Kubelet now recovers from corrupted subpath mount points (e.g. stale NFS file handle) during container restart instead of leaving the pod stuck in CreateContainerConfigError. ([#138856](https://github.com/kubernetes/kubernetes/pull/138856), [@RomanBednar](https://github.com/RomanBednar)) [SIG Storage]
- Kubelet: set cgroup v2 memory.high for BestEffort containers when MemoryQoS is enabled (per KEP-2570). ([#138139](https://github.com/kubernetes/kubernetes/pull/138139), [@amritansh1502](https://github.com/amritansh1502)) [SIG Node]
- Kubelet: the eviction manager's monitoring goroutine now exits promptly when the kubelet's context is cancelled, fixing a goroutine leak on shutdown. ([#138854](https://github.com/kubernetes/kubernetes/pull/138854), [@alexmchughdev](https://github.com/alexmchughdev)) [SIG Node]
- Remove [alpha] admission plugin that validates PodGroup resources reference an existing Workload and match the declared PodGroupTemplate spec. ([#139008](https://github.com/kubernetes/kubernetes/pull/139008), [@wojtek-t](https://github.com/wojtek-t)) [SIG API Machinery, Etcd, Scheduling and Testing]
- Removed an edge case that could allow malformed object deletion to bypass admission and graceful deletion of well-formed objects. ([#137582](https://github.com/kubernetes/kubernetes/pull/137582), [@benluddy](https://github.com/benluddy)) [SIG API Machinery, Etcd and Testing]
- This fixes a bug related to pods that were removed from the active or backoff queues before scheduling. Previously, the metrics associated with these removed pods were not adjusted; this PR introduces a fix that allows us to decrease metrics for such pods. ([#138482](https://github.com/kubernetes/kubernetes/pull/138482), [@vshkrabkov](https://github.com/vshkrabkov)) [SIG Scheduling]
- Use stable curl download for windows busybox testing image ([#138879](https://github.com/kubernetes/kubernetes/pull/138879), [@BenTheElder](https://github.com/BenTheElder)) [SIG Testing and Windows]

### Other (Cleanup or Flake)

- Client-go will request v2 for aggregated discovery and not fall back to v2beta1 ([#138271](https://github.com/kubernetes/kubernetes/pull/138271), [@Jefftree](https://github.com/Jefftree)) [SIG API Machinery]
- Deprecated MultiLock, UnknownLeader, and ConcatRawRecord in client-go leader election resourcelock package. ([#138070](https://github.com/kubernetes/kubernetes/pull/138070), [@Jefftree](https://github.com/Jefftree)) [SIG API Machinery]
- Fixed a theoretic issue where nodes might have been denied access to synthesized ResourceClaims for pods using extended resources (e.g. nvidia.com/gpu), causing containers to get stuck in ContainerCreating. Not observed in practice. ([#138792](https://github.com/kubernetes/kubernetes/pull/138792), [@dims](https://github.com/dims)) [SIG Auth and Node]
- Kube-apiserver enable-logs-handler, deprecated in 1.15, is no-longer marked deprecated. It remains off-by-default. ([#138915](https://github.com/kubernetes/kubernetes/pull/138915), [@BenTheElder](https://github.com/BenTheElder)) [SIG API Machinery]
- Kube-controller-manager and kube-scheduler now both expose "dynamic_resource_allocation_resourceclaim_creates_total" as metric for number of ResourceClaims created, replacing differently names metrics in each component. The kube-controller-manager metric "resource_claims" gets moved to the same "dynamic_resource_allocation" sub-system. ([#138542](https://github.com/kubernetes/kubernetes/pull/138542), [@pohly](https://github.com/pohly)) [SIG Apps, Instrumentation, Node, Release, Scheduling and Testing]
- Kubeadm: removed the v1beta3 API which was deprecated since v1.31. The 1.35 kubeadm binary can be used to migrate to v1beta4 by using the command 'kubeadm config migrate'. Additionally, removed the PublicKeysECDSA kubeadm specific feature gate which was only kept for backwards compatibility with v1beta3. The support for ECDSA keys was added as part of the v1beta4 field ClusterConfiguration.EncryptionAlgorithm. Added a placeholder v1 API, that is a copy of v1beta4 and is flagged as experimental and cannot be used yet. ([#136016](https://github.com/kubernetes/kubernetes/pull/136016), [@neolit123](https://github.com/neolit123)) [SIG Cluster Lifecycle]
- Kubeadm: updated the supported etcd version to v3.6.10 for supported control plane versions v1.34, v1.35, and v1.36 ([#138392](https://github.com/kubernetes/kubernetes/pull/138392), [@humblec](https://github.com/humblec)) [SIG API Machinery, Cloud Provider, Cluster Lifecycle, Etcd and Testing]
- Kubeadm: updated the supported etcd version to v3.6.11 for supported control plane versions v1.34, v1.35, and v1.36 ([#138746](https://github.com/kubernetes/kubernetes/pull/138746), [@humblec](https://github.com/humblec)) [SIG API Machinery, Cloud Provider, Cluster Lifecycle, Etcd and Testing]
- Promote `apiserver_watch_events_total` and `apiserver_watch_events_sizes` to BETA ([#137116](https://github.com/kubernetes/kubernetes/pull/137116), [@tico88612](https://github.com/tico88612)) [SIG API Machinery, Instrumentation and Testing]
- Remove RelaxedDNSSearchValidation feature gate ([#139217](https://github.com/kubernetes/kubernetes/pull/139217), [@adrianmoisey](https://github.com/adrianmoisey)) [SIG Apps, Node and Testing]
- Removed locked GA feature gates `RetryGenerateName`, `BtreeWatchCache`, `OrderedNamespaceDeletion`, `StreamingCollectionEncodingToJSON`, `StreamingCollectionEncodingToProtobuf`, `APIServerTracing`, `ResilientWatchCacheInitialization`, and `ConsistentListFromCache`. ([#138907](https://github.com/kubernetes/kubernetes/pull/138907), [@Jefftree](https://github.com/Jefftree)) [SIG API Machinery, Apps, Etcd and Node]
- Removed the `--concurrent-service-syncs` kube-controller-manager flag (no-op since v1.31). ([#138002](https://github.com/kubernetes/kubernetes/pull/138002), [@Jefftree](https://github.com/Jefftree)) [SIG API Machinery]
- Removes the `KubeletMinVersion` label from the DRA e2e test covering multiple `ResourceClaims`. ([#138001](https://github.com/kubernetes/kubernetes/pull/138001), [@rogowski-piotr](https://github.com/rogowski-piotr)) [SIG Node and Testing]
- Switch StorageVersionMigration to use merge patch over SSA ([#138874](https://github.com/kubernetes/kubernetes/pull/138874), [@michaelasp](https://github.com/michaelasp)) [SIG API Machinery, Apps and Auth]
- The SidecarContainers feature gate, unconditionally enabled since 1.33, is removed. ([#137755](https://github.com/kubernetes/kubernetes/pull/137755), [@HirazawaUi](https://github.com/HirazawaUi)) [SIG Apps, Node, Scheduling and Testing]
- The deprecated ALPHA metrics `apiserver_cache_list_total`, `apiserver_cache_list_fetched_objects_total`, and `apiserver_cache_list_returned_objects_total` are no longer exposed by default.  
  Should migrate to the unified `apiserver_storage_list_*` metrics with `storage="watchcache"` label. ([#139154](https://github.com/kubernetes/kubernetes/pull/139154), [@yedou37](https://github.com/yedou37)) [SIG API Machinery and Instrumentation]
- The no-op `DefaultWatchCacheSize` field of `k8s.io/apiserver/pkg/server/options.EtcdOptions` is now removed. ([#134151](https://github.com/kubernetes/kubernetes/pull/134151), [@ialidzhikov](https://github.com/ialidzhikov)) [SIG API Machinery]
- Updates the etcd client library to v3.6.11 ([#138747](https://github.com/kubernetes/kubernetes/pull/138747), [@humblec](https://github.com/humblec)) [SIG API Machinery, Auth, Cloud Provider, Node and Scheduling]

## Dependencies

### Added
- github.com/aclements/go-moremath: [f10218a](https://github.com/aclements/go-moremath/tree/f10218a)
- github.com/go-openapi/swag/cmdutils: [v0.25.4](https://github.com/go-openapi/swag/commit/73525ad4f9d84ce7e4b15796f0d41a6cb32cc3cd)
- github.com/go-openapi/swag/conv: [v0.25.4](https://github.com/go-openapi/swag/commit/73525ad4f9d84ce7e4b15796f0d41a6cb32cc3cd)
- github.com/go-openapi/swag/fileutils: [v0.25.4](https://github.com/go-openapi/swag/commit/73525ad4f9d84ce7e4b15796f0d41a6cb32cc3cd)
- github.com/go-openapi/swag/jsonname: [v0.25.4](https://github.com/go-openapi/swag/commit/73525ad4f9d84ce7e4b15796f0d41a6cb32cc3cd)
- github.com/go-openapi/swag/jsonutils: [v0.25.4](https://github.com/go-openapi/swag/commit/73525ad4f9d84ce7e4b15796f0d41a6cb32cc3cd)
- github.com/go-openapi/swag/jsonutils/fixtures_test: [v0.25.4](https://github.com/go-openapi/swag/commit/73525ad4f9d84ce7e4b15796f0d41a6cb32cc3cd)
- github.com/go-openapi/swag/loading: [v0.25.4](https://github.com/go-openapi/swag/commit/73525ad4f9d84ce7e4b15796f0d41a6cb32cc3cd)
- github.com/go-openapi/swag/mangling: [v0.25.4](https://github.com/go-openapi/swag/commit/73525ad4f9d84ce7e4b15796f0d41a6cb32cc3cd)
- github.com/go-openapi/swag/netutils: [v0.25.4](https://github.com/go-openapi/swag/commit/73525ad4f9d84ce7e4b15796f0d41a6cb32cc3cd)
- github.com/go-openapi/swag/stringutils: [v0.25.4](https://github.com/go-openapi/swag/commit/73525ad4f9d84ce7e4b15796f0d41a6cb32cc3cd)
- github.com/go-openapi/swag/typeutils: [v0.25.4](https://github.com/go-openapi/swag/commit/73525ad4f9d84ce7e4b15796f0d41a6cb32cc3cd)
- github.com/go-openapi/swag/yamlutils: [v0.25.4](https://github.com/go-openapi/swag/commit/73525ad4f9d84ce7e4b15796f0d41a6cb32cc3cd)
- github.com/go-openapi/testify/enable/yaml/v2: [v2.0.2](https://github.com/go-openapi/testify/commit/43fcbc6c768e560ad65ed0be848fb306fee0c312)
- github.com/go-openapi/testify/v2: [v2.0.2](https://github.com/go-openapi/testify/commit/43fcbc6c768e560ad65ed0be848fb306fee0c312)
- go.opentelemetry.io/otel/metric/x: [v0.66.0](https://github.com/open-telemetry/opentelemetry-go/commit/b62d92831b2dd142f5a0cc89c828270274196877)
- golang.org/x/perf: [2f7363a](https://go.googlesource.com/perf/+/2f7363a06fe1e84314f47158b693ef982b0c2255)

### Changed
- github.com/Azure/go-ansiterm: [306776e → faa5f7b](https://github.com/Azure/go-ansiterm/compare/306776e...faa5f7b)
- github.com/GoogleCloudPlatform/opentelemetry-operations-go/detectors/gcp: [v1.30.0 → v1.31.0](https://github.com/GoogleCloudPlatform/opentelemetry-operations-go/compare/v1.30.0...v1.31.0)
- github.com/Microsoft/hnslib: [v0.1.2 → v0.1.3](https://github.com/Microsoft/hnslib/compare/v0.1.2...v0.1.3)
- github.com/antlr4-go/antlr/v4: [v4.13.0 → v4.13.1](https://github.com/antlr4-go/antlr/compare/v4.13.0...v4.13.1)
- github.com/cncf/xds/go: [ee656c7 → dba9d58](https://github.com/cncf/xds/compare/ee656c7534f5d7dc23d44dd611689568f72017a6...dba9d589def2cd10099a3a64887d859188c2f57a)
- github.com/containerd/containerd/api: [v1.10.0 → v1.11.0](https://github.com/containerd/containerd/compare/api/v1.10.0...api/v1.11.0)
- github.com/containerd/ttrpc: [v1.2.7 → v1.2.8](https://github.com/containerd/ttrpc/compare/v1.2.7...v1.2.8)
- github.com/containerd/typeurl/v2: [v2.2.3 → v2.3.0](https://github.com/containerd/typeurl/compare/v2.2.3...v2.3.0)
- github.com/envoyproxy/go-control-plane/envoy: [v1.36.0 → v1.37.0](https://github.com/envoyproxy/go-control-plane/compare/envoy/v1.36.0...envoy/v1.37.0)
- github.com/envoyproxy/protoc-gen-validate: [v1.3.0 → v1.3.3](https://github.com/envoyproxy/protoc-gen-validate/compare/v1.3.0...v1.3.3)
- github.com/fxamacker/cbor/v2: [v2.9.0 → v2.9.1](https://github.com/fxamacker/cbor/compare/v2.9.0...v2.9.1)
- github.com/go-jose/go-jose/v4: [v4.1.3 → v4.1.4](https://github.com/go-jose/go-jose/compare/v4.1.3...v4.1.4)
- github.com/go-openapi/jsonpointer: [v0.21.0 → v0.22.4](https://github.com/go-openapi/jsonpointer/compare/v0.21.0...v0.22.4)
- github.com/go-openapi/jsonreference: [v0.20.2 → v0.21.4](https://github.com/go-openapi/jsonreference/compare/v0.20.2...v0.21.4)
- github.com/go-openapi/swag: [v0.23.0 → v0.25.4](https://github.com/go-openapi/swag/compare/v0.23.0...v0.25.4)
- github.com/golang-jwt/jwt/v5: [v5.3.0 → v5.3.1](https://github.com/golang-jwt/jwt/compare/v5.3.0...v5.3.1)
- github.com/google/cadvisor: [v0.56.2 → v0.57.0](https://github.com/google/cadvisor/compare/v0.56.2...v0.57.0)
- github.com/google/cel-go: [v0.26.0 → v0.27.0](https://github.com/google/cel-go/compare/v0.26.0...v0.27.0)
- github.com/google/pprof: [294ebfa → 545e8a4](https://github.com/google/pprof/compare/294ebfa9ad836ed3d00d43d54ea599339e403110...545e8a4df9364095d66e521b8f515f7af961e653)
- github.com/grpc-ecosystem/grpc-gateway/v2: [v2.27.7 → v2.29.0](https://github.com/grpc-ecosystem/grpc-gateway/compare/v2.27.7...v2.29.0)
- github.com/moby/moby/api: [v1.52.0 → v1.54.1](https://github.com/moby/moby/compare/1408c9ca4f4f0717b2d885fc87ae0ff000a91c40...api/v1.54.1)
- github.com/moby/moby/client: [v0.2.1 → v0.4.0](https://github.com/moby/moby/compare/client/v0.2.1...client/v0.4.0)
- github.com/moby/term: [v0.5.0 → v0.5.2](https://github.com/moby/term/compare/main...v0.5.2)
- github.com/onsi/ginkgo/v2: [v2.28.1 → v2.28.3](https://github.com/onsi/ginkgo/compare/v2.28.1...v2.28.3)
- github.com/onsi/gomega: [v1.39.1 → v1.40.0](https://github.com/onsi/gomega/compare/v1.39.1...v1.40.0)
- github.com/sirupsen/logrus: [v1.9.3 → v1.9.4](https://github.com/sirupsen/logrus/compare/v1.9.3...v1.9.4)
- github.com/spf13/pflag: [v1.0.9 → v1.0.10](https://github.com/spf13/pflag/compare/v1.0.9...v1.0.10)
- github.com/stretchr/objx: [v0.5.2 → v0.5.3](https://github.com/stretchr/objx/compare/v0.5.2...v0.5.3)
- go.etcd.io/bbolt: [v1.4.3 → v1.5.0-rc.0](https://github.com/etcd-io/bbolt/compare/v1.4.3...v1.5.0-rc.0)
- go.etcd.io/etcd/api/v3: [v3.6.8 → v3.7.0-rc.0](https://github.com/etcd-io/etcd/compare/api/v3.6.8...api/v3.7.0-rc.0)
- go.etcd.io/etcd/client/pkg/v3: [v3.6.8 → v3.7.0-rc.0](https://github.com/etcd-io/etcd/compare/client/pkg/v3.6.8...client/pkg/v3.7.0-rc.0)
- go.etcd.io/etcd/client/v3: [v3.6.8 → v3.7.0-rc.0](https://github.com/etcd-io/etcd/compare/client/v3.6.8...client/v3.7.0-rc.0)
- go.etcd.io/etcd/pkg/v3: [v3.6.8 → v3.7.0-rc.0](https://github.com/etcd-io/etcd/compare/pkg/v3.6.8...pkg/v3.7.0-rc.0)
- go.etcd.io/etcd/server/v3: [v3.6.8 → v3.7.0-rc.0](https://github.com/etcd-io/etcd/compare/server/v3.6.8...server/v3.7.0-rc.0)
- go.etcd.io/raft/v3: [v3.6.0 → v3.7.0-rc.1](https://github.com/etcd-io/raft/compare/v3.6.0...v3.7.0-rc.1)
- go.opentelemetry.io/contrib/detectors/gcp: [v1.39.0 → v1.42.0](https://github.com/open-telemetry/opentelemetry-go-contrib/compare/detectors/gcp/v1.39.0...detectors/gcp/v1.42.0)
- go.opentelemetry.io/contrib/instrumentation/github.com/emicklei/go-restful/otelrestful: [v0.65.0 → v0.68.0](https://github.com/open-telemetry/opentelemetry-go-contrib/compare/instrumentation/github.com/emicklei/go-restful/otelrestful/v0.65.0...instrumentation/github.com/emicklei/go-restful/otelrestful/v0.68.0)
- go.opentelemetry.io/contrib/instrumentation/google.golang.org/grpc/otelgrpc: [v0.65.0 → v0.68.0](https://github.com/open-telemetry/opentelemetry-go-contrib/compare/instrumentation/google.golang.org/grpc/otelgrpc/v0.65.0...instrumentation/google.golang.org/grpc/otelgrpc/v0.68.0)
- go.opentelemetry.io/contrib/instrumentation/net/http/otelhttp: [v0.65.0 → v0.68.0](https://github.com/open-telemetry/opentelemetry-go-contrib/compare/instrumentation/net/http/otelhttp/v0.65.0...instrumentation/net/http/otelhttp/v0.68.0)
- go.opentelemetry.io/contrib/propagators/b3: [v1.40.0 → v1.43.0](https://github.com/open-telemetry/opentelemetry-go-contrib/compare/propagators/b3/v1.40.0...propagators/b3/v1.43.0)
- go.opentelemetry.io/otel: [v1.41.0 → v1.44.0](https://github.com/open-telemetry/opentelemetry-go/compare/v1.41.0...v1.44.0)
- go.opentelemetry.io/otel/exporters/otlp/otlptrace: [v1.40.0 → v1.44.0](https://github.com/open-telemetry/opentelemetry-go/compare/exporters/otlp/otlptrace/v1.40.0...exporters/otlp/otlptrace/v1.44.0)
- go.opentelemetry.io/otel/exporters/otlp/otlptrace/otlptracegrpc: [v1.40.0 → v1.44.0](https://github.com/open-telemetry/opentelemetry-go/compare/exporters/otlp/otlptrace/otlptracegrpc/v1.40.0...exporters/otlp/otlptrace/otlptracegrpc/v1.44.0)
- go.opentelemetry.io/otel/exporters/stdout/stdouttrace: [v1.40.0 → v1.43.0](https://github.com/open-telemetry/opentelemetry-go/compare/exporters/stdout/stdouttrace/v1.40.0...exporters/stdout/stdouttrace/v1.43.0)
- go.opentelemetry.io/otel/metric: [v1.41.0 → v1.44.0](https://github.com/open-telemetry/opentelemetry-go/compare/metric/v1.41.0...metric/v1.44.0)
- go.opentelemetry.io/otel/sdk: [v1.40.0 → v1.44.0](https://github.com/open-telemetry/opentelemetry-go/compare/sdk/v1.40.0...sdk/v1.44.0)
- go.opentelemetry.io/otel/sdk/metric: [v1.40.0 → v1.44.0](https://github.com/open-telemetry/opentelemetry-go/compare/sdk/metric/v1.40.0...sdk/metric/v1.44.0)
- go.opentelemetry.io/otel/trace: [v1.41.0 → v1.44.0](https://github.com/open-telemetry/opentelemetry-go/compare/trace/v1.41.0...trace/v1.44.0)
- go.opentelemetry.io/proto/otlp: [v1.9.0 → v1.10.0](https://github.com/open-telemetry/opentelemetry-proto-go/compare/otlp/v1.9.0...otlp/v1.10.0)
- go.yaml.in/yaml/v2: [v2.4.3 → v2.4.4](https://github.com/yaml/go-yaml/compare/v2.4.3...v2.4.4)
- golang.org/x/crypto: [v0.47.0 → v0.52.0](https://go.googlesource.com/crypto/+/506e022208b864bc3c9c4a416fe56be75d10ad24^1..a1c0d9929856c8aba2b31f079340f00578eda803/)
- golang.org/x/exp: [944ab1f → 746e56f](https://go.googlesource.com/exp/+/944ab1f22d936eefb8f6260ecd2053101d8d7b2a^1..746e56fc9e2fafde18176275ce0b96b06ac53955/)
- golang.org/x/mod: [v0.32.0 → v0.35.0](https://go.googlesource.com/mod/+/4c04067938546e62fc0572259a68a6912726bcdd^1..03901d351deb5bd95deb90714fb75bf8e232cb22/)
- golang.org/x/net: [v0.49.0 → 42abb85](https://go.googlesource.com/net/+/d977772e17ccaa1903b2af736f6405ab3a9f05cc^1..42abb857022cb79baacfa240bcf48588aa80bbee/)
- golang.org/x/oauth2: [v0.34.0 → v0.36.0](https://go.googlesource.com/oauth2/+/acc38155b7f6f36aefcb58faff6f36d314dd915c^1..4d954e69a88d9e1ccb8439f8d5b6cbef230c4ef9/)
- golang.org/x/sync: [v0.19.0 → v0.20.0](https://go.googlesource.com/sync/+/2a180e22fddcc336475e72aa950be958c1b68d33^1..ec11c4a93de22cde2abe2bf74d70791033c2464c/)
- golang.org/x/sys: [v0.40.0 → v0.45.0](https://go.googlesource.com/sys/+/2f442297556c884f9b52fc6ef7280083f4d65023^1..397d5f80920585bc27433d878aba498d062f81e1/)
- golang.org/x/telemetry: [bd525da → be6f6cb](https://go.googlesource.com/telemetry/+/bd525da824e2505db9e8ac44025316bf6f43a6f6^1..be6f6cb8b1fafcb1c710a0666a79acac61139b7b/)
- golang.org/x/term: [v0.39.0 → v0.43.0](https://go.googlesource.com/term/+/a7e5b0437ffa3159709172efbe396bc546550e23^1..3c3e4855f7d2eb06c3e48933554add9ec6b599b5/)
- golang.org/x/text: [v0.33.0 → v0.37.0](https://go.googlesource.com/text/+/536231a9abc69feaab8d726b5ec75ee8d3620829^1..3ef517e623a4bfc08d6457f87d73afda7af7d8e1/)
- golang.org/x/time: [v0.14.0 → v0.15.0](https://go.googlesource.com/time/+/2b4e43900c03fd6b77109b7b2b6d77583f48bc1c^1..812b343c8714c317b0dad633efa6d103e554c006/)
- golang.org/x/tools: [v0.41.0 → v0.44.0](https://go.googlesource.com/tools/+/2ad2b30edf98d0e3b67a7b3e8f6d1d6e41c963c3^1..3dd188df80fd3563559f02e4eeb10ba1043cce55/)
- gonum.org/v1/gonum: [v0.16.0 → v0.17.0](https://github.com/gonum/gonum/compare/v0.16.0...v0.17.0)
- google.golang.org/genproto/googleapis/api: [8636f87 → 3dc84a4](https://github.com/googleapis/go-genproto/compare/8636f8732409467ddc8453f81f4429397739bb17...3dc84a4a5aaa87331e10f51e22e90d961f986894)
- google.golang.org/genproto/googleapis/rpc: [8636f87 → 3dc84a4](https://github.com/googleapis/go-genproto/compare/8636f8732409467ddc8453f81f4429397739bb17...3dc84a4a5aaa87331e10f51e22e90d961f986894)
- google.golang.org/grpc: [v1.79.3 → v1.81.1](https://github.com/grpc/grpc-go/compare/v1.79.3...v1.81.1)
- k8s.io/gengo/v2: [ec3ebc5 → 25e2208](https://github.com/kubernetes/gengo/compare/ec3ebc5fd46b84f44dfb135e9684c6567791dd8e...25e2208e0dc371a827289e7faced19a2dbcd480b)
- k8s.io/kube-openapi: [43fb72c → bbf5c55](https://github.com/kubernetes/kube-openapi/compare/43fb72c5454a03ed83388cf20c070499ee359af8...bbf5c557728870a14cee51b4271cfd51b58ef2f8)
- sigs.k8s.io/structured-merge-diff/v6: [v6.3.2 → v6.4.0](https://github.com/kubernetes-sigs/structured-merge-diff/compare/v6.3.2...v6.4.0)

### Removed
- github.com/cenkalti/backoff/v4: [v4.3.0](https://github.com/cenkalti/backoff/commit/720b78985a65c0452fd37bb155c7cac4157a7c45)
- github.com/golang/groupcache: [41bb18b](https://github.com/golang/groupcache/tree/41bb18b)
- github.com/grpc-ecosystem/go-grpc-middleware: [v1.3.0](https://github.com/grpc-ecosystem/go-grpc-middleware/tree/v1.3.0)