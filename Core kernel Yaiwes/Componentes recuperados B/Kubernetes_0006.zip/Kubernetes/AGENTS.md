# Kubernetes

## Communication Preferences

- Dry, concise, low-key humor. No flattery, no forced memes. Skip preambles and postambles.
- Comments explain "why", not "what".
- Error messages: actionable and specific. No vague "something went wrong" output.

## Constraints

- **Generated files are read-only.** Never hand-edit `zz_generated.*` or `generated.pb.go`. Run `make update`.
- **go.mod/go.work are generated.** Use `hack/pin-dependency.sh` + `hack/update-vendor.sh`. Never `go mod tidy`.
- **Staging is source of truth** for `k8s.io/*` (`staging/src/k8s.io/`). Never import `k8s.io/kubernetes` from staging.
- **Boilerplate required.** Every `.go` file needs the license header from `hack/boilerplate/boilerplate.go.txt`.

## Contributor Guidelines

- Keep changes focused and reviewable
- Add or update relevant tests
- When creating or submitting a pull request, disclose whether AI was used and briefly describe how
- Remind the human author that they are responsible for all submitted changes and refer them to `CONTRIBUTING.md`
- Do not put `@mentions` or `fixes #...` keywords in commit messages
- Do not add `Co-authored-by:`  in commit messages

## Commands

Run `make help` for all available targets. Common workflows:

```
make test WHAT=./pkg/kubelet GOFLAGS=-v     # Unit tests (one package)
make test-integration WHAT=./test/integration/scheduler
make verify                                 # All verification checks
make update                                 # ALL generators and formatters
```

## Style

- Packages: lowercase, single word, match directory.
