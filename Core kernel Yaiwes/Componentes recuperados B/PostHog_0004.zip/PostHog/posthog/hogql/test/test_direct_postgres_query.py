from datetime import date, timedelta
from typing import Any, cast
from uuid import uuid4

from posthog.test.base import APIBaseTest
from unittest.mock import MagicMock, patch

from django.test import override_settings

import psycopg
from parameterized import parameterized
from sshtunnel import BaseSSHTunnelForwarderError

from posthog.hogql import ast
from posthog.hogql.constants import HogQLGlobalSettings
from posthog.hogql.context import HogQLContext
from posthog.hogql.database.schema.duckdb_table_functions import is_dangerous_table_function
from posthog.hogql.direct_sql.pgwire import (
    LenientDirectPostgresDateLoader,
    parse_lenient_direct_postgres_date,
    postgres_error_to_message,
    postgres_oid_to_clickhouse_type,
)
from posthog.hogql.direct_sql.postgres_adapter import (
    PostgresAdapter,
    direct_postgres_session_setup_sql,
    get_runtime_direct_postgres_connection_metadata,
)
from posthog.hogql.direct_sql.raw_sql import ensure_single_direct_statement
from posthog.hogql.errors import ExposedHogQLError, QueryError
from posthog.hogql.escape_sql import escape_postgres_identifier
from posthog.hogql.printer.postgres import PostgresPrinter
from posthog.hogql.query import HogQLQueryExecutor

from posthog.models import Team

from products.warehouse_sources.backend.facade.models import DataWarehouseTable, ExternalDataSchema, ExternalDataSource
from products.warehouse_sources.backend.facade.source_management import SSL_REQUIRED_AFTER_DATE


class TestDirectPostgresQuery(APIBaseTest):
    @parameterized.expand(
        [
            ("timestamp", 1114, "DateTime"),
            ("timestamptz", 1184, "DateTime64(6, 'UTC')"),
            ("int4", 23, "Int32"),
            ("int8", 20, "Int64"),
            ("unknown", 999999, "String"),
            ("none", None, "String"),
        ]
    )
    def test_postgres_oid_to_clickhouse_type(self, _name: str, oid: int | None, expected: str):
        self.assertEqual(postgres_oid_to_clickhouse_type(oid), expected)

    @parameterized.expand(
        [
            ("date_only", "2026-03-26", date(2026, 3, 26)),
            ("timestamp_with_space", "2026-03-26 00:00:00", date(2026, 3, 26)),
            ("timestamp_with_t", "2026-03-26T13:14:15", date(2026, 3, 26)),
            ("timestamp_with_timezone", "2026-03-26T13:14:15Z", date(2026, 3, 26)),
            ("timestamp_with_fractional_seconds", "2026-03-26 00:00:00.123456", date(2026, 3, 26)),
        ]
    )
    def test_parse_lenient_direct_postgres_date(self, _name: str, value: str, expected: date):
        self.assertEqual(parse_lenient_direct_postgres_date(value), expected)

    @parameterized.expand(
        [
            ("global_in", ast.CompareOperationOp.GlobalIn, "(x IN (SELECT session_id FROM sessions))"),
            ("global_not_in", ast.CompareOperationOp.GlobalNotIn, "(x NOT IN (SELECT session_id FROM sessions))"),
        ]
    )
    def test_postgres_printer_maps_global_in_operators(self, _name: str, op: ast.CompareOperationOp, expected_sql: str):
        # The resolver rewrites sessions/events IN subqueries to GlobalIn/GlobalNotIn; Postgres has no
        # distributed GLOBAL concept, so the printer must emit a plain IN/NOT IN rather than crashing.
        printer = PostgresPrinter(context=HogQLContext(team_id=self.team.pk))

        self.assertEqual(printer._get_compare_op(op, "x", "(SELECT session_id FROM sessions)"), expected_sql)

    def test_direct_postgres_session_setup_sql_uses_search_path_for_postgres(self):
        self.assertEqual(
            direct_postgres_session_setup_sql("ph3"),
            "SET search_path TO ph3",
        )

    def test_direct_postgres_session_setup_sql_returns_none_without_postgres_schema(self):
        self.assertIsNone(direct_postgres_session_setup_sql(None))

    def test_direct_postgres_session_setup_sql_uses_use_for_duckdb(self):
        self.assertEqual(
            direct_postgres_session_setup_sql("posthog", {"engine": "duckdb"}),
            "USE posthog",
        )

    def test_direct_postgres_session_setup_sql_uses_database_for_duckdb_without_schema(self):
        self.assertEqual(
            direct_postgres_session_setup_sql(None, {"engine": "duckdb", "database": "ducklake"}),
            "USE ducklake",
        )

    def test_direct_postgres_session_setup_sql_uses_schema_for_duckdb_with_schema(self):
        self.assertEqual(
            direct_postgres_session_setup_sql("system", {"engine": "duckdb", "database": "ducklake"}),
            "USE system",
        )

    @parameterized.expand(
        [
            ("lowercase", "db.eu.postwh.com"),
            ("uppercase_trailing_dot", "DB.EU.POSTWH.COM."),
        ]
    )
    def test_direct_postgres_session_setup_sql_treats_postwh_hosts_as_duckdb(self, _name, host):
        self.assertEqual(
            direct_postgres_session_setup_sql("posthog", host=host),
            "USE posthog",
        )

    def test_runtime_direct_postgres_connection_metadata_hydrates_missing_duckdb_catalog(self):
        connection = MagicMock()
        metadata_cursor = MagicMock()
        metadata_cursor.fetchone.return_value = ("ducklake", "DuckDB v1.3.2")
        connection.execute.return_value = metadata_cursor

        self.assertEqual(
            get_runtime_direct_postgres_connection_metadata(connection, {"engine": "duckdb"}),
            {"engine": "duckdb", "database": "ducklake"},
        )
        connection.execute.assert_called_once_with("SELECT current_database(), version()")

    def test_generate_sql_for_direct_postgres_table_does_not_require_team_id_field(self):
        source = ExternalDataSource.objects.create(
            team=self.team,
            source_id="source_id",
            connection_id="connection_id",
            status=ExternalDataSource.Status.COMPLETED,
            source_type="Postgres",
            access_method=ExternalDataSource.AccessMethod.DIRECT,
            prefix="ph3",
            job_inputs={
                "host": "localhost",
                "port": 5432,
                "database": "postgres",
                "user": "postgres",
                "password": "postgres",
                "schema": "ph3",
            },
        )

        DataWarehouseTable.objects.create(
            name="without_team_id",
            format="Parquet",
            team=self.team,
            external_data_source=source,
            url_pattern="",
            columns={"id": {"hogql": "IntegerDatabaseField", "clickhouse": "Int64", "valid": True}},
        )

        executor = HogQLQueryExecutor(
            query="SELECT * FROM without_team_id",
            team=self.team,
            connection_id=str(source.id),
        )

        sql, _context = executor.generate_clickhouse_sql()

        self.assertIn("ph3.without_team_id", sql)
        self.assertNotIn(".team_id", sql)
        self.assertEqual(executor.direct_source_id, str(source.id))

    def _create_simple_direct_source_and_table(self) -> ExternalDataSource:
        source = ExternalDataSource.objects.create(
            team=self.team,
            source_id=str(uuid4()),
            connection_id=str(uuid4()),
            status=ExternalDataSource.Status.COMPLETED,
            source_type="Postgres",
            access_method=ExternalDataSource.AccessMethod.DIRECT,
            prefix="shop",
            job_inputs={
                "host": "localhost",
                "port": 5432,
                "database": "postgres",
                "user": "postgres",
                "password": "postgres",
                "schema": "public",
            },
        )
        DataWarehouseTable.objects.create(
            name="orders",
            format="Parquet",
            team=self.team,
            external_data_source=source,
            url_pattern="",
            columns={"id": {"hogql": "IntegerDatabaseField", "clickhouse": "Int64", "valid": True}},
        )
        return source

    @parameterized.expand(
        [
            # Postgres has no zero-arg count(); it must print as count(*).
            ("count_star", "SELECT count() FROM orders", "count(*)"),
            # DISTINCT used to be silently dropped from function calls, returning plain counts.
            ("count_distinct", "SELECT count(DISTINCT id) FROM orders", "count(DISTINCT "),
        ]
    )
    def test_count_rendering(self, _name: str, query: str, expected_fragment: str):
        source = self._create_simple_direct_source_and_table()

        executor = HogQLQueryExecutor(query=query, team=self.team, connection_id=str(source.id))
        sql, _context = executor.generate_clickhouse_sql()

        self.assertIn(expected_fragment, sql)

    def test_set_query_operands_are_parenthesized(self):
        # The default LIMIT is injected into every branch of a set query; Postgres only
        # accepts a per-branch LIMIT on a parenthesized operand.
        source = self._create_simple_direct_source_and_table()

        executor = HogQLQueryExecutor(
            query="SELECT id FROM orders UNION ALL SELECT id FROM orders",
            team=self.team,
            connection_id=str(source.id),
        )
        sql, _context = executor.generate_clickhouse_sql()

        self.assertRegex(sql, r"\)\s*UNION ALL\s*\(")

    def test_handler_rendered_functions_reject_distinct(self):
        # Handlers compose custom SQL from pre-rendered args; DISTINCT must error rather than
        # be silently dropped from the aggregate.
        source = self._create_simple_direct_source_and_table()

        executor = HogQLQueryExecutor(
            query="SELECT uniq(DISTINCT id) FROM orders",
            team=self.team,
            connection_id=str(source.id),
        )
        with self.assertRaises(QueryError) as ctx:
            executor.generate_clickhouse_sql()
        self.assertIn("DISTINCT", str(ctx.exception))

    def test_generate_sql_for_aliased_direct_postgres_table(self):
        source = ExternalDataSource.objects.create(
            team=self.team,
            source_id="source_id",
            connection_id="connection_id",
            status=ExternalDataSource.Status.COMPLETED,
            source_type="Postgres",
            access_method=ExternalDataSource.AccessMethod.DIRECT,
            prefix="ph3",
            job_inputs={
                "host": "localhost",
                "port": 5432,
                "database": "postgres",
                "user": "postgres",
                "password": "postgres",
                "schema": "ph3",
            },
        )

        DataWarehouseTable.objects.create(
            name="posthog_activitylog",
            format="Parquet",
            team=self.team,
            external_data_source=source,
            url_pattern="",
            columns={"id": {"hogql": "IntegerDatabaseField", "clickhouse": "Int64", "valid": True}},
        )

        executor = HogQLQueryExecutor(
            query="SELECT activitylog.id FROM posthog_activitylog AS activitylog",
            team=self.team,
            connection_id=str(source.id),
        )

        sql, _context = executor.generate_clickhouse_sql()

        self.assertIn("ph3.posthog_activitylog", sql)
        self.assertIn("activitylog", sql)
        self.assertEqual(executor.direct_source_id, str(source.id))

    def test_modulo_renders_as_mod_function(self):
        # A bare `%` in the printed SQL is read by psycopg as a client-side parameter
        # placeholder and blows up before the query runs, so modulo must render as MOD(a, b).
        source = ExternalDataSource.objects.create(
            team=self.team,
            source_id="source_id",
            connection_id="connection_id",
            status=ExternalDataSource.Status.COMPLETED,
            source_type="Postgres",
            access_method=ExternalDataSource.AccessMethod.DIRECT,
            prefix="ph3",
            job_inputs={
                "host": "localhost",
                "port": 5432,
                "database": "postgres",
                "user": "postgres",
                "password": "postgres",
                "schema": "ph3",
            },
        )

        DataWarehouseTable.objects.create(
            name="orders",
            format="Parquet",
            team=self.team,
            external_data_source=source,
            url_pattern="",
            columns={"id": {"hogql": "IntegerDatabaseField", "clickhouse": "Int64", "valid": True}},
        )

        executor = HogQLQueryExecutor(
            query="SELECT id % 2 FROM orders",
            team=self.team,
            connection_id=str(source.id),
        )

        sql, _context = executor.generate_clickhouse_sql()

        self.assertIn("MOD(", sql)
        # Assert the modulo *operator* isn't rendered as a bare `%`; a plain `assertNotIn("%", sql)`
        # would be too broad since bound values legitimately use `%(hogql_val_*)s` placeholders.
        self.assertNotIn(" % ", sql)

    def test_generate_sql_for_direct_postgres_table_inside_cte(self):
        source = ExternalDataSource.objects.create(
            team=self.team,
            source_id="source_id",
            connection_id="connection_id",
            status=ExternalDataSource.Status.COMPLETED,
            source_type="Postgres",
            access_method=ExternalDataSource.AccessMethod.DIRECT,
            prefix="ph3",
            job_inputs={
                "host": "localhost",
                "port": 5432,
                "database": "postgres",
                "user": "postgres",
                "password": "postgres",
                "schema": "ph3",
            },
        )

        DataWarehouseTable.objects.create(
            name="posthog_dashboard",
            format="Parquet",
            team=self.team,
            external_data_source=source,
            url_pattern="",
            columns={"id": {"hogql": "IntegerDatabaseField", "clickhouse": "Int64", "valid": True}},
        )

        executor = HogQLQueryExecutor(
            query="""
            WITH dashboard_cte AS (
                SELECT id
                FROM posthog_dashboard
            )
            SELECT id
            FROM dashboard_cte
            """,
            team=self.team,
            connection_id=str(source.id),
        )

        sql, _context = executor.generate_clickhouse_sql()

        self.assertIn("dashboard_cte", sql)
        self.assertIn("ph3.posthog_dashboard", sql)
        self.assertEqual(executor.direct_source_id, str(source.id))

    def test_generate_sql_for_direct_postgres_struct_field_access(self):
        source = ExternalDataSource.objects.create(
            team=self.team,
            source_id="source_id",
            connection_id="connection_id",
            status=ExternalDataSource.Status.COMPLETED,
            source_type="Postgres",
            access_method=ExternalDataSource.AccessMethod.DIRECT,
            prefix="ph3",
            job_inputs={
                "host": "localhost",
                "port": 5432,
                "database": "postgres",
                "user": "postgres",
                "password": "postgres",
                "schema": "ph3",
            },
        )

        DataWarehouseTable.objects.create(
            name="members",
            format="Parquet",
            team=self.team,
            external_data_source=source,
            url_pattern="",
            columns={
                "membership": {
                    "clickhouse": "Tuple(String, String, String, String)",
                    "hogql": "StructDatabaseField",
                    "valid": True,
                    "fields": {
                        "type": {"clickhouse": "String", "hogql": "string", "valid": True},
                        "tier": {"clickhouse": "String", "hogql": "string", "valid": True},
                        "frequency": {"clickhouse": "String", "hogql": "string", "valid": True},
                        "provider": {"clickhouse": "String", "hogql": "string", "valid": True},
                    },
                }
            },
        )

        executor = HogQLQueryExecutor(
            query="SELECT membership.type, membership.tier FROM members",
            team=self.team,
            connection_id=str(source.id),
        )

        sql, _context = executor.generate_clickhouse_sql()

        self.assertIn('(members.membership).type AS "membership.type"', sql)
        self.assertIn('(members.membership).tier AS "membership.tier"', sql)
        self.assertEqual(executor.direct_source_id, str(source.id))

    def test_generate_sql_for_direct_postgres_connection_metadata_function(self):
        source = ExternalDataSource.objects.create(
            team=self.team,
            source_id="source_id",
            connection_id="connection_id",
            status=ExternalDataSource.Status.COMPLETED,
            source_type="Postgres",
            access_method=ExternalDataSource.AccessMethod.DIRECT,
            prefix="ph3",
            job_inputs={
                "host": "localhost",
                "port": 5432,
                "database": "postgres",
                "user": "postgres",
                "password": "postgres",
                "schema": "ph3",
            },
            connection_metadata={"available_functions": ["date_bin"]},
        )

        DataWarehouseTable.objects.create(
            name="without_team_id",
            format="Parquet",
            team=self.team,
            external_data_source=source,
            url_pattern="",
            columns={"id": {"hogql": "IntegerDatabaseField", "clickhouse": "Int64", "valid": True}},
        )

        executor = HogQLQueryExecutor(
            query="SELECT date_bin(toIntervalHour(1), now(), now()) FROM without_team_id",
            team=self.team,
            connection_id=str(source.id),
        )

        sql, _context = executor.generate_clickhouse_sql()

        self.assertIn("date_bin((1 * INTERVAL '1 hour'), NOW(), NOW())", sql)
        self.assertEqual(executor.direct_source_id, str(source.id))

    def test_generate_sql_for_direct_postgres_custom_connection_metadata_function(self):
        source = ExternalDataSource.objects.create(
            team=self.team,
            source_id="source_id",
            connection_id="connection_id",
            status=ExternalDataSource.Status.COMPLETED,
            source_type="Postgres",
            access_method=ExternalDataSource.AccessMethod.DIRECT,
            prefix="ph3",
            job_inputs={
                "host": "localhost",
                "port": 5432,
                "database": "postgres",
                "user": "postgres",
                "password": "postgres",
                "schema": "ph3",
            },
            connection_metadata={"available_functions": ["icu_collate_nl"]},
        )

        DataWarehouseTable.objects.create(
            name="without_team_id",
            format="Parquet",
            team=self.team,
            external_data_source=source,
            url_pattern="",
            columns={"name": {"hogql": "StringDatabaseField", "clickhouse": "String", "valid": True}},
        )

        executor = HogQLQueryExecutor(
            query="SELECT icu_collate_nl(name, 'nl') FROM without_team_id",
            team=self.team,
            connection_id=str(source.id),
        )

        sql, _context = executor.generate_clickhouse_sql()

        self.assertIn("icu_collate_nl", sql)
        self.assertEqual(executor.direct_source_id, str(source.id))

    @parameterized.expand(
        [
            (
                "introspected_via_metadata",
                {"available_table_functions": ["unnest"]},
                "SELECT * FROM unnest(ARRAY[1, 2, 3])",
                "unnest(",
            ),
            (
                "hardcoded_range_without_metadata",
                None,
                "SELECT range FROM range(10)",
                "range(10)",
            ),
        ]
    )
    def test_generate_sql_for_direct_postgres_table_function(
        self,
        _name: str,
        connection_metadata: dict[str, Any] | None,
        query: str,
        expected_sql_fragment: str,
    ):
        source_kwargs: dict[str, Any] = {
            "team": self.team,
            "source_id": "source_id",
            "connection_id": "connection_id",
            "status": ExternalDataSource.Status.COMPLETED,
            "source_type": "Postgres",
            "access_method": ExternalDataSource.AccessMethod.DIRECT,
            "prefix": "ph3",
            "job_inputs": {
                "host": "localhost",
                "port": 5432,
                "database": "postgres",
                "user": "postgres",
                "password": "postgres",
                "schema": "ph3",
            },
        }
        if connection_metadata is not None:
            source_kwargs["connection_metadata"] = connection_metadata
        source = ExternalDataSource.objects.create(**source_kwargs)

        executor = HogQLQueryExecutor(query=query, team=self.team, connection_id=str(source.id))

        sql, _context = executor.generate_clickhouse_sql()

        self.assertIn(expected_sql_fragment, sql)
        self.assertEqual(executor.direct_source_id, str(source.id))

    @parameterized.expand(
        [
            ("read_text", "SELECT * FROM read_text('/etc/passwd')"),
            ("read_csv", "SELECT * FROM read_csv('http://169.254.169.254/latest/meta-data')"),
            ("glob", "SELECT * FROM glob('/etc/*')"),
            ("postgres_query", "SELECT * FROM postgres_query('db', 'SELECT 1')"),
            ("query", "SELECT * FROM query('SELECT * FROM read_text(''/etc/passwd'')')"),
        ]
    )
    def test_generate_sql_rejects_dangerous_table_function_even_if_cached_in_metadata(
        self, function_name: str, query: str
    ):
        source = ExternalDataSource.objects.create(
            team=self.team,
            source_id="source_id",
            connection_id="connection_id",
            status=ExternalDataSource.Status.COMPLETED,
            source_type="Postgres",
            access_method=ExternalDataSource.AccessMethod.DIRECT,
            prefix="ph3",
            job_inputs={
                "host": "localhost",
                "port": 5432,
                "database": "postgres",
                "user": "postgres",
                "password": "postgres",
                "schema": "ph3",
            },
            connection_metadata={"available_table_functions": [function_name]},
        )

        executor = HogQLQueryExecutor(query=query, team=self.team, connection_id=str(source.id))

        with self.assertRaises((QueryError, ExposedHogQLError)) as ctx:
            executor.generate_clickhouse_sql()

        # Must fail at resolve time, not as an accepted opaque table (which fails generically at print).
        self.assertNotIn("is not supported in ClickHouse dialect", str(ctx.exception))

    @parameterized.expand(
        [
            ("query", True),
            ("read_csv", True),
            ("postgres_query", True),
            ("glob", True),
            ("READ_TEXT", True),
            ("read_anything", True),
            ("scan_anything", True),
            ("foo_scan", True),
            ("foo_attach", True),
            ("build_query", False),
            ("get_query", False),
            ("run_query", False),
            ("range", False),
            ("generate_series", False),
            ("unnest", False),
        ]
    )
    def test_is_dangerous_table_function(self, function_name: str, expected: bool):
        self.assertEqual(is_dangerous_table_function(function_name), expected)

    def test_generate_sql_for_duckdb_direct_postgres_table_uses_connection_catalog(self):
        source = ExternalDataSource.objects.create(
            team=self.team,
            source_id="source_id",
            connection_id="connection_id",
            status=ExternalDataSource.Status.COMPLETED,
            source_type="Postgres",
            access_method=ExternalDataSource.AccessMethod.DIRECT,
            prefix="ducklake",
            job_inputs={
                "host": "localhost",
                "port": 5432,
                "database": "postgres",
                "user": "postgres",
                "password": "postgres",
            },
            connection_metadata={"engine": "duckdb", "database": "ducklake"},
        )

        DataWarehouseTable.objects.create(
            name="system.query_log",
            format="Parquet",
            team=self.team,
            external_data_source=source,
            url_pattern="",
            columns={"query": {"hogql": "StringDatabaseField", "clickhouse": "String", "valid": True}},
            options={
                "direct_postgres_schema": "system",
                "direct_postgres_table": "query_log",
            },
        )

        executor = HogQLQueryExecutor(
            query="SELECT * FROM system.query_log LIMIT 100",
            team=self.team,
            connection_id=str(source.id),
        )

        sql, _context = executor.generate_clickhouse_sql()

        self.assertIn("ducklake.system.query_log", sql)
        self.assertEqual(executor.direct_source_id, str(source.id))

    def test_direct_query_requires_selected_connection(self):
        source = ExternalDataSource.objects.create(
            team=self.team,
            source_id="source_id",
            connection_id="connection_id",
            status=ExternalDataSource.Status.COMPLETED,
            source_type="Postgres",
            access_method=ExternalDataSource.AccessMethod.DIRECT,
            prefix="ph3",
            job_inputs={
                "host": "localhost",
                "port": 5432,
                "database": "postgres",
                "user": "postgres",
                "password": "postgres",
                "schema": "ph3",
            },
        )

        DataWarehouseTable.objects.create(
            name="without_team_id",
            format="Parquet",
            team=self.team,
            external_data_source=source,
            url_pattern="",
            columns={"id": {"hogql": "IntegerDatabaseField", "clickhouse": "Int64", "valid": True}},
        )

        executor = HogQLQueryExecutor(query="SELECT * FROM postgres.ph3.without_team_id", team=self.team)

        with self.assertRaises(QueryError) as error:
            executor.generate_clickhouse_sql()

        self.assertEqual(str(error.exception), "Unknown table `postgres.ph3.without_team_id`.")

    def test_mixed_direct_and_clickhouse_query_without_connection_rejects_clickhouse_printing(self):
        source = ExternalDataSource.objects.create(
            team=self.team,
            source_id="source_id",
            connection_id="connection_id",
            status=ExternalDataSource.Status.COMPLETED,
            source_type="Postgres",
            access_method=ExternalDataSource.AccessMethod.DIRECT,
            prefix="ph3",
            job_inputs={
                "host": "localhost",
                "port": 5432,
                "database": "postgres",
                "user": "postgres",
                "password": "postgres",
                "schema": "ph3",
            },
        )

        DataWarehouseTable.objects.create(
            name="posthog_dashboard",
            format="Parquet",
            team=self.team,
            external_data_source=source,
            url_pattern="direct://postgres",
            columns={"id": {"hogql": "IntegerDatabaseField", "clickhouse": "Int64", "valid": True}},
        )

        executor = HogQLQueryExecutor(
            query="SELECT dashboard.id FROM postgres.ph3.posthog_dashboard AS dashboard JOIN events ON 1 = 1",
            team=self.team,
        )

        with self.assertRaises(QueryError) as error:
            executor.generate_clickhouse_sql()

        self.assertEqual(str(error.exception), "Unknown table `postgres.ph3.posthog_dashboard`.")

    def test_selected_connection_prioritizes_matching_direct_source_for_canonical_table_name(self):
        first_source = ExternalDataSource.objects.create(
            team=self.team,
            source_id="source_id_1",
            connection_id="connection_id_1",
            status=ExternalDataSource.Status.COMPLETED,
            source_type="Postgres",
            access_method=ExternalDataSource.AccessMethod.DIRECT,
            prefix="first",
            job_inputs={
                "host": "localhost",
                "port": 5432,
                "database": "postgres",
                "user": "postgres",
                "password": "postgres",
                "schema": "first_schema",
            },
        )
        second_source = ExternalDataSource.objects.create(
            team=self.team,
            source_id="source_id_2",
            connection_id="connection_id_2",
            status=ExternalDataSource.Status.COMPLETED,
            source_type="Postgres",
            access_method=ExternalDataSource.AccessMethod.DIRECT,
            prefix="second",
            job_inputs={
                "host": "localhost",
                "port": 5432,
                "database": "postgres",
                "user": "postgres",
                "password": "postgres",
                "schema": "second_schema",
            },
        )

        DataWarehouseTable.objects.create(
            name="posthog_team",
            format="Parquet",
            team=self.team,
            external_data_source=first_source,
            url_pattern="direct://postgres",
            columns={"id": {"hogql": "IntegerDatabaseField", "clickhouse": "Int64", "valid": True}},
        )
        DataWarehouseTable.objects.create(
            name="posthog_team",
            format="Parquet",
            team=self.team,
            external_data_source=second_source,
            url_pattern="direct://postgres",
            columns={"id": {"hogql": "IntegerDatabaseField", "clickhouse": "Int64", "valid": True}},
        )

        executor = HogQLQueryExecutor(
            query="SELECT id FROM posthog_team",
            team=self.team,
            connection_id=str(second_source.id),
        )

        sql, _context = executor.generate_clickhouse_sql()

        self.assertIn("FROM\n    second_schema.posthog_team", sql)
        self.assertEqual(executor.direct_source_id, str(second_source.id))

    def test_selected_connection_rejects_clickhouse_only_tables(self):
        source = ExternalDataSource.objects.create(
            team=self.team,
            source_id="source_id",
            connection_id="connection_id",
            status=ExternalDataSource.Status.COMPLETED,
            source_type="Postgres",
            access_method=ExternalDataSource.AccessMethod.DIRECT,
            prefix="ph3",
            job_inputs={
                "host": "localhost",
                "port": 5432,
                "database": "postgres",
                "user": "postgres",
                "password": "postgres",
                "schema": "ph3",
            },
        )

        executor = HogQLQueryExecutor(
            query="SELECT * FROM persons",
            team=self.team,
            connection_id=str(source.id),
        )

        with self.assertRaises(QueryError) as error:
            executor.execute()

        self.assertEqual(str(error.exception), "Unknown table `persons`.")

    def test_selected_connection_uses_direct_tables_named_like_posthog_tables(self):
        source = ExternalDataSource.objects.create(
            team=self.team,
            source_id="source_id",
            connection_id="connection_id",
            status=ExternalDataSource.Status.COMPLETED,
            source_type="Postgres",
            access_method=ExternalDataSource.AccessMethod.DIRECT,
            prefix="ph3",
            job_inputs={
                "host": "localhost",
                "port": 5432,
                "database": "postgres",
                "user": "postgres",
                "password": "postgres",
                "schema": "ph3",
            },
        )

        DataWarehouseTable.objects.create(
            name="events",
            format="Parquet",
            team=self.team,
            external_data_source=source,
            url_pattern="direct://postgres",
            columns={"id": {"hogql": "IntegerDatabaseField", "clickhouse": "Int64", "valid": True}},
        )
        DataWarehouseTable.objects.create(
            name="persons",
            format="Parquet",
            team=self.team,
            external_data_source=source,
            url_pattern="direct://postgres",
            columns={"id": {"hogql": "IntegerDatabaseField", "clickhouse": "Int64", "valid": True}},
        )

        events_executor = HogQLQueryExecutor(
            query="SELECT id FROM events",
            team=self.team,
            connection_id=str(source.id),
        )
        persons_executor = HogQLQueryExecutor(
            query="SELECT id FROM persons",
            team=self.team,
            connection_id=str(source.id),
        )

        events_sql, _events_context = events_executor.generate_clickhouse_sql()
        persons_sql, _persons_context = persons_executor.generate_clickhouse_sql()

        self.assertIn("FROM\n    ph3.events", events_sql)
        self.assertIn("FROM\n    ph3.persons", persons_sql)
        self.assertEqual(events_executor.direct_source_id, str(source.id))
        self.assertEqual(persons_executor.direct_source_id, str(source.id))

    @patch("posthog.hogql.direct_sql.postgres_adapter.psycopg.connect")
    def test_selected_connection_allows_table_less_sql(self, mock_connect):
        source = ExternalDataSource.objects.create(
            team=self.team,
            source_id="source_id",
            connection_id="connection_id",
            status=ExternalDataSource.Status.COMPLETED,
            source_type="Postgres",
            access_method=ExternalDataSource.AccessMethod.DIRECT,
            prefix="ph3",
            job_inputs={
                "host": "localhost",
                "port": 5432,
                "database": "postgres",
                "user": "postgres",
                "password": "postgres",
                "schema": "ph3",
            },
        )

        mocked_cursor = MagicMock()
        mocked_cursor.fetchall.return_value = [(1,)]
        column = MagicMock(type_code=23)
        column.name = "value"
        mocked_cursor.description = [column]
        mocked_connection = MagicMock()
        mocked_connection.cursor.return_value.__enter__.return_value = mocked_cursor
        mock_connect.return_value.__enter__.return_value = mocked_connection

        executor = HogQLQueryExecutor(
            query="SELECT 1 AS value",
            team=self.team,
            connection_id=str(source.id),
        )

        response = executor.execute()

        self.assertEqual(response.results, [(1,)])
        self.assertEqual(executor.direct_source_id, str(source.id))
        assert executor.direct_sql is not None
        self.assertIn("1 AS value", executor.direct_sql)
        self.assertIn("LIMIT 100", executor.direct_sql)

    @patch("posthog.hogql.direct_sql.postgres_adapter.psycopg.connect")
    def test_send_raw_query_registers_lenient_date_loader_for_duckdb_style_dates(self, mock_connect):
        source = ExternalDataSource.objects.create(
            team=self.team,
            source_id="source_id",
            connection_id="connection_id",
            status=ExternalDataSource.Status.COMPLETED,
            source_type="Postgres",
            access_method=ExternalDataSource.AccessMethod.DIRECT,
            prefix="ph3",
            job_inputs={
                "host": "localhost",
                "port": 5432,
                "database": "postgres",
                "user": "postgres",
                "password": "postgres",
                "schema": "ph3",
            },
            connection_metadata={"engine": "duckdb", "database": "posthog"},
        )

        mocked_cursor = MagicMock()
        mocked_cursor.fetchall.return_value = [(date(2026, 3, 26),)]
        column = MagicMock(type_code=1082)
        column.name = "current_date"
        mocked_cursor.description = [column]
        mocked_connection = MagicMock()
        mocked_connection.cursor.return_value.__enter__.return_value = mocked_cursor
        mock_connect.return_value.__enter__.return_value = mocked_connection

        executor = HogQLQueryExecutor(
            query="SELECT CURRENT_DATE AS current_date",
            team=self.team,
            connection_id=str(source.id),
            send_raw_query=True,
        )

        response = executor.execute()

        self.assertEqual(response.results, [(date(2026, 3, 26),)])
        job_inputs = cast(dict[str, Any], source.job_inputs)
        mocked_connection.execute.assert_called_once_with(f"USE {escape_postgres_identifier(job_inputs['schema'])}")
        mocked_connection.adapters.register_loader.assert_any_call("date", LenientDirectPostgresDateLoader)

    @patch("posthog.hogql.direct_sql.postgres_adapter.psycopg.connect")
    def test_send_raw_query_uses_duckdb_schema_without_hydrating_catalog(self, mock_connect):
        source = ExternalDataSource.objects.create(
            team=self.team,
            source_id="source_id",
            connection_id="connection_id",
            status=ExternalDataSource.Status.COMPLETED,
            source_type="Postgres",
            access_method=ExternalDataSource.AccessMethod.DIRECT,
            prefix="ph3",
            job_inputs={
                "host": "localhost",
                "port": 5432,
                "database": "postgres",
                "user": "postgres",
                "password": "postgres",
                "schema": "system",
            },
            connection_metadata={"engine": "duckdb"},
        )

        mocked_cursor = MagicMock()
        mocked_cursor.fetchall.return_value = [(1,)]
        column = MagicMock(type_code=23)
        column.name = "value"
        mocked_cursor.description = [column]

        mocked_connection = MagicMock()
        mocked_connection.execute.return_value = None
        mocked_connection.cursor.return_value.__enter__.return_value = mocked_cursor
        mock_connect.return_value.__enter__.return_value = mocked_connection

        executor = HogQLQueryExecutor(
            query="SELECT * FROM system.query_log LIMIT 100",
            team=self.team,
            connection_id=str(source.id),
            send_raw_query=True,
        )

        response = executor.execute()

        self.assertEqual(response.results, [(1,)])
        mocked_connection.execute.assert_any_call(f"USE {escape_postgres_identifier(source.job_inputs['schema'])}")
        self.assertEqual(mocked_connection.execute.call_count, 1)
        mocked_cursor.execute.assert_called_once_with("SELECT * FROM system.query_log LIMIT 100", None)

    @patch("posthog.hogql.direct_sql.postgres_adapter.psycopg.connect")
    def test_send_raw_query_uses_schema_for_duckdb_when_catalog_is_available(self, mock_connect):
        source = ExternalDataSource.objects.create(
            team=self.team,
            source_id="source_id",
            connection_id="connection_id",
            status=ExternalDataSource.Status.COMPLETED,
            source_type="Postgres",
            access_method=ExternalDataSource.AccessMethod.DIRECT,
            prefix="ph3",
            job_inputs={
                "host": "localhost",
                "port": 5432,
                "database": "postgres",
                "user": "postgres",
                "password": "postgres",
                "schema": "system",
            },
            connection_metadata={"engine": "duckdb", "database": "ducklake"},
        )

        mocked_cursor = MagicMock()
        mocked_cursor.fetchall.return_value = [(1,)]
        column = MagicMock(type_code=23)
        column.name = "value"
        mocked_cursor.description = [column]
        mocked_connection = MagicMock()
        mocked_connection.cursor.return_value.__enter__.return_value = mocked_cursor
        mock_connect.return_value.__enter__.return_value = mocked_connection

        executor = HogQLQueryExecutor(
            query="SELECT 1 AS value",
            team=self.team,
            connection_id=str(source.id),
            send_raw_query=True,
        )

        response = executor.execute()

        self.assertEqual(response.results, [(1,)])
        mocked_connection.execute.assert_called_once_with(
            f"USE {escape_postgres_identifier(source.job_inputs['schema'])}"
        )

    @patch("posthog.hogql.direct_sql.postgres_adapter.psycopg.connect")
    def test_send_raw_query_executes_raw_query_without_hogql_preparation(self, mock_connect):
        source = ExternalDataSource.objects.create(
            team=self.team,
            source_id="source_id",
            connection_id="connection_id",
            status=ExternalDataSource.Status.COMPLETED,
            source_type="Postgres",
            access_method=ExternalDataSource.AccessMethod.DIRECT,
            prefix="ph3",
            job_inputs={
                "host": "localhost",
                "port": 5432,
                "database": "postgres",
                "user": "postgres",
                "password": "postgres",
                "schema": "ph3",
            },
        )

        mocked_cursor = MagicMock()
        mocked_cursor.fetchall.return_value = [(1,)]
        column = MagicMock(type_code=23)
        column.name = "value"
        mocked_cursor.description = [column]
        mocked_connection = MagicMock()
        mocked_connection.cursor.return_value.__enter__.return_value = mocked_cursor
        mock_connect.return_value.__enter__.return_value = mocked_connection

        executor = HogQLQueryExecutor(
            query="SELECT 1 AS value",
            team=self.team,
            connection_id=str(source.id),
            send_raw_query=True,
        )

        with patch.object(HogQLQueryExecutor, "_prepare_execution") as mock_prepare_execution:
            response = executor.execute()

        self.assertEqual(response.results, [(1,)])
        self.assertEqual(response.clickhouse, "SELECT 1 AS value")
        self.assertEqual(response.columns, ["value"])
        self.assertIsNone(response.hogql)
        mock_prepare_execution.assert_not_called()
        mocked_connection.execute.assert_called_once_with(
            f"SET search_path TO {escape_postgres_identifier(source.job_inputs['schema'])}"
        )
        mocked_cursor.execute.assert_called_once_with("SELECT 1 AS value", None)

    @patch("posthog.hogql.direct_sql.postgres_adapter.psycopg.connect")
    def test_send_raw_query_unsupported_by_hogql_succeeds_without_hogql(self, mock_connect):
        source = ExternalDataSource.objects.create(
            team=self.team,
            source_id="source_id",
            connection_id="connection_id",
            status=ExternalDataSource.Status.COMPLETED,
            source_type="Postgres",
            access_method=ExternalDataSource.AccessMethod.DIRECT,
            prefix="ph3",
            job_inputs={
                "host": "localhost",
                "port": 5432,
                "database": "postgres",
                "user": "postgres",
                "password": "postgres",
                "schema": "ph3",
            },
        )

        mocked_cursor = MagicMock()
        mocked_cursor.fetchall.return_value = [(True,)]
        column = MagicMock(type_code=16)
        column.name = "value"
        mocked_cursor.description = [column]
        mocked_connection = MagicMock()
        mocked_connection.cursor.return_value.__enter__.return_value = mocked_cursor
        mock_connect.return_value.__enter__.return_value = mocked_connection

        executor = HogQLQueryExecutor(
            query="SELECT 1 IS TRUE AS value",
            team=self.team,
            connection_id=str(source.id),
            send_raw_query=True,
        )

        response = executor.execute()

        self.assertEqual(response.results, [(True,)])
        self.assertEqual(response.clickhouse, "SELECT 1 IS TRUE AS value")
        self.assertEqual(response.columns, ["value"])
        self.assertIsNone(response.hogql)
        mocked_cursor.execute.assert_called_once_with("SELECT 1 IS TRUE AS value", None)

    @patch("posthog.hogql.direct_sql.postgres_adapter.psycopg.connect")
    def test_send_raw_query_uses_catalog_for_duckdb_without_schema(self, mock_connect):
        source = ExternalDataSource.objects.create(
            team=self.team,
            source_id="source_id",
            connection_id="connection_id",
            status=ExternalDataSource.Status.COMPLETED,
            source_type="Postgres",
            access_method=ExternalDataSource.AccessMethod.DIRECT,
            prefix="ducklake",
            job_inputs={
                "host": "localhost",
                "port": 5432,
                "database": "postgres",
                "user": "postgres",
                "password": "postgres",
                "schema": "",
            },
            connection_metadata={"engine": "duckdb", "database": "ducklake"},
        )

        mocked_cursor = MagicMock()
        mocked_cursor.fetchall.return_value = [(1,)]
        column = MagicMock(type_code=23)
        column.name = "value"
        mocked_cursor.description = [column]
        mocked_connection = MagicMock()
        mocked_connection.cursor.return_value.__enter__.return_value = mocked_cursor
        mock_connect.return_value.__enter__.return_value = mocked_connection

        executor = HogQLQueryExecutor(
            query="SELECT 1 AS value",
            team=self.team,
            connection_id=str(source.id),
            send_raw_query=True,
        )

        response = executor.execute()

        self.assertEqual(response.results, [(1,)])
        mocked_connection.execute.assert_called_once_with("USE ducklake")
        mocked_cursor.execute.assert_called_once_with("SELECT 1 AS value", None)

    @patch("posthog.hogql.direct_sql.postgres_adapter.psycopg.connect")
    def test_send_raw_query_skips_session_setup_when_schema_is_blank(self, mock_connect):
        source = ExternalDataSource.objects.create(
            team=self.team,
            source_id="source_id",
            connection_id="connection_id",
            status=ExternalDataSource.Status.COMPLETED,
            source_type="Postgres",
            access_method=ExternalDataSource.AccessMethod.DIRECT,
            prefix="ph3",
            job_inputs={
                "host": "localhost",
                "port": 5432,
                "database": "postgres",
                "user": "postgres",
                "password": "postgres",
                "schema": "",
            },
        )

        mocked_cursor = MagicMock()
        mocked_cursor.fetchall.return_value = [(1,)]
        column = MagicMock(type_code=23)
        column.name = "value"
        mocked_cursor.description = [column]
        mocked_connection = MagicMock()
        mocked_connection.cursor.return_value.__enter__.return_value = mocked_cursor
        mock_connect.return_value.__enter__.return_value = mocked_connection

        executor = HogQLQueryExecutor(
            query="SELECT 1 AS value",
            team=self.team,
            connection_id=str(source.id),
            send_raw_query=True,
        )

        response = executor.execute()

        self.assertEqual(response.results, [(1,)])
        mocked_connection.execute.assert_called_once_with("SELECT current_database(), version()")
        mocked_cursor.execute.assert_called_once_with("SELECT 1 AS value", None)
        timing_keys = {timing.k for timing in response.timings or []}
        self.assertTrue(any(key.endswith("/postgres_connection_metadata") for key in timing_keys))
        self.assertFalse(any(key.endswith("/postgres_session_setup") for key in timing_keys))

    @patch("posthog.hogql.direct_sql.postgres_adapter.psycopg.connect")
    def test_send_raw_query_handles_statements_without_result_set(self, mock_connect):
        source = ExternalDataSource.objects.create(
            team=self.team,
            source_id="source_id",
            connection_id="connection_id",
            status=ExternalDataSource.Status.COMPLETED,
            source_type="Postgres",
            access_method=ExternalDataSource.AccessMethod.DIRECT,
            prefix="ph3",
            job_inputs={
                "host": "localhost",
                "port": 5432,
                "database": "postgres",
                "user": "postgres",
                "password": "postgres",
                "schema": "ph3",
            },
        )

        # ATTACH, SET and other utility/DDL statements return no result set: cursor.description
        # is None and calling fetchall() on them raises ProgrammingError. They must be reported
        # as a successful, empty result instead of a spurious error.
        mocked_cursor = MagicMock()
        mocked_cursor.description = None
        mocked_cursor.fetchall.side_effect = psycopg.ProgrammingError("the last operation didn't produce a result")
        mocked_connection = MagicMock()
        mocked_connection.cursor.return_value.__enter__.return_value = mocked_cursor
        mock_connect.return_value.__enter__.return_value = mocked_connection

        executor = HogQLQueryExecutor(
            query="SET TIME ZONE 'UTC'",
            team=self.team,
            connection_id=str(source.id),
            send_raw_query=True,
        )

        response = executor.execute()

        self.assertIsNone(response.error)
        self.assertEqual(response.results, [])
        self.assertEqual(response.columns, [])
        mocked_cursor.fetchall.assert_not_called()
        mocked_cursor.execute.assert_called_once_with("SET TIME ZONE 'UTC'", None)

    @parameterized.expand(
        [
            ("explicit_read_write", "COMMIT; BEGIN READ WRITE; UPDATE t SET a = 1; COMMIT;"),
            ("set_then_write", "SET default_transaction_read_only = off; UPDATE t SET a = 1;"),
            ("two_selects", "SELECT 1; SELECT 2"),
        ]
    )
    def test_ensure_single_direct_statement_rejects_multi_statement(self, _name: str, sql: str):
        with self.assertRaises(ExposedHogQLError):
            ensure_single_direct_statement(sql)

    @parameterized.expand(
        [
            ("plain_select", "SELECT 1 AS value"),
            ("trailing_semicolon", "SELECT 1 AS value;"),
            ("stray_empty_statements", "SELECT 1 AS value;   ;  "),
            ("percent_literal", "SELECT name FROM t WHERE name LIKE '%admin%'"),
            ("semicolon_in_literal", "SELECT 'a;b' AS value"),
            ("dollar_quoted", "SELECT $$a;b;c$$ AS value"),
        ]
    )
    def test_ensure_single_direct_statement_allows_single_statement(self, _name: str, sql: str):
        self.assertEqual(ensure_single_direct_statement(sql), sql)

    @patch("posthog.hogql.direct_sql.postgres_adapter.psycopg.connect")
    def test_send_raw_query_rejects_multi_statement_before_execution(self, mock_connect):
        source = ExternalDataSource.objects.create(
            team=self.team,
            source_id="source_id",
            connection_id="connection_id",
            status=ExternalDataSource.Status.COMPLETED,
            source_type="Postgres",
            access_method=ExternalDataSource.AccessMethod.DIRECT,
            prefix="ph3",
            job_inputs={
                "host": "localhost",
                "port": 5432,
                "database": "postgres",
                "user": "postgres",
                "password": "postgres",
                "schema": "ph3",
            },
        )

        executor = HogQLQueryExecutor(
            query="COMMIT; BEGIN READ WRITE; UPDATE t SET a = 1; COMMIT;",
            team=self.team,
            connection_id=str(source.id),
            send_raw_query=True,
        )

        with self.assertRaises(ExposedHogQLError):
            executor.execute()

        mock_connect.assert_not_called()

    def test_selected_connection_rejects_disabled_direct_tables(self):
        source = ExternalDataSource.objects.create(
            team=self.team,
            source_id="source_id",
            connection_id="connection_id",
            status=ExternalDataSource.Status.COMPLETED,
            source_type="Postgres",
            access_method=ExternalDataSource.AccessMethod.DIRECT,
            prefix="ph3",
            job_inputs={
                "host": "localhost",
                "port": 5432,
                "database": "postgres",
                "user": "postgres",
                "password": "postgres",
                "schema": "ph3",
            },
        )

        table = DataWarehouseTable.objects.create(
            name="posthog_dashboard",
            format="Parquet",
            team=self.team,
            external_data_source=source,
            url_pattern="direct://postgres",
            columns={"id": {"hogql": "IntegerDatabaseField", "clickhouse": "Int64", "valid": True}},
        )
        ExternalDataSchema.objects.create(
            name="posthog_dashboard",
            team=self.team,
            source=source,
            table=table,
            should_sync=False,
        )

        executor = HogQLQueryExecutor(
            query="SELECT id FROM posthog_dashboard",
            team=self.team,
            connection_id=str(source.id),
        )

        with self.assertRaises(ExposedHogQLError) as error:
            executor.execute()

        self.assertEqual(str(error.exception), "Unknown table `posthog_dashboard`.")

    def test_execute_direct_postgres_query_raises_user_error_for_missing_source(self):
        missing_source_id = str(uuid4())
        executor = HogQLQueryExecutor(query="SELECT 1", team=self.team, connection_id=missing_source_id)
        executor.direct_sql = "SELECT 1"
        executor.direct_source_id = missing_source_id

        with self.assertRaises(ExposedHogQLError) as error:
            executor._execute_direct_sql_query()

        self.assertEqual(str(error.exception), "Connection not found or has been deleted")

    def test_postgres_error_to_message_uses_primary_message(self):
        error = psycopg.errors.GroupingError(
            'column "posthog_dashboard.name" must appear in the GROUP BY clause or be used in an aggregate function'
        )
        self.assertEqual(
            postgres_error_to_message(error),
            'column "posthog_dashboard.name" must appear in the GROUP BY clause or be used in an aggregate function',
        )

    # DEV (not US/EU) keeps the host guard active without the internal-team allowlist, which the
    # test team's auto-assigned id can otherwise collide with (US team_id 2 / EU team_id 1).
    @override_settings(CLOUD_DEPLOYMENT="DEV")
    @patch("posthog.hogql.direct_sql.postgres_adapter.psycopg.connect")
    def test_execute_direct_postgres_query_blocks_internal_host(self, mock_connect):
        # team id 2 (US) / 1 (EU) are allowlisted to reach internal IPs, so use an explicit
        # non-allowlisted id — otherwise this flakes when pytest-split orders the test first in
        # its shard and self.team happens to be assigned pk 2, bypassing the SSRF block.
        team = Team.objects.create(id=984961485, name="ssrf_test_team", organization=self.organization)
        source = ExternalDataSource.objects.create(
            team=team,
            source_id="source_id",
            connection_id="connection_id",
            status=ExternalDataSource.Status.COMPLETED,
            source_type="Postgres",
            access_method=ExternalDataSource.AccessMethod.DIRECT,
            prefix="ph3",
            job_inputs={
                "host": "localhost",
                "port": 5432,
                "database": "postgres",
                "user": "postgres",
                "password": "postgres",
                "schema": "ph3",
            },
        )

        DataWarehouseTable.objects.create(
            name="posthog_dashboard",
            format="Parquet",
            team=team,
            external_data_source=source,
            url_pattern="direct://postgres",
            columns={
                "id": {"hogql": "IntegerDatabaseField", "clickhouse": "Int64", "valid": True},
            },
        )

        executor = HogQLQueryExecutor(
            query="SELECT id FROM posthog_dashboard LIMIT 1",
            team=team,
            connection_id=str(source.id),
        )

        with self.assertRaises(ExposedHogQLError) as error:
            executor.execute()

        self.assertEqual(
            str(error.exception),
            "This host points to an internal or private IP address, which PostHog can't reach. "
            "Use a host that's reachable from the public internet. "
            "If your database isn't publicly reachable, connect through an SSH tunnel.",
        )
        mock_connect.assert_not_called()

    @patch("posthog.hogql.direct_sql.postgres_adapter.psycopg.connect")
    def test_execute_direct_postgres_query_exposes_database_errors(self, mock_connect):
        source = ExternalDataSource.objects.create(
            team=self.team,
            source_id="source_id",
            connection_id="connection_id",
            status=ExternalDataSource.Status.COMPLETED,
            source_type="Postgres",
            access_method=ExternalDataSource.AccessMethod.DIRECT,
            prefix="ph3",
            job_inputs={
                "host": "localhost",
                "port": 5432,
                "database": "postgres",
                "user": "postgres",
                "password": "postgres",
                "schema": "ph3",
            },
        )

        DataWarehouseTable.objects.create(
            name="posthog_dashboard",
            format="Parquet",
            team=self.team,
            external_data_source=source,
            url_pattern="direct://postgres",
            columns={
                "id": {"hogql": "IntegerDatabaseField", "clickhouse": "Int64", "valid": True},
                "name": {"hogql": "StringDatabaseField", "clickhouse": "String", "valid": True},
            },
        )

        mocked_cursor = MagicMock()
        mocked_cursor.execute.side_effect = psycopg.errors.GroupingError(
            'column "posthog_dashboard.name" must appear in the GROUP BY clause or be used in an aggregate function'
        )
        mocked_connection = MagicMock()
        mocked_connection.cursor.return_value.__enter__.return_value = mocked_cursor
        mock_connect.return_value.__enter__.return_value = mocked_connection

        executor = HogQLQueryExecutor(
            query="SELECT name, count(id) FROM posthog_dashboard LIMIT 100",
            team=self.team,
            connection_id=str(source.id),
        )

        with self.assertRaises(ExposedHogQLError) as error:
            executor.execute()

        self.assertIn("must appear in the GROUP BY clause", str(error.exception))
        self.assertEqual(mock_connect.call_args.kwargs["connect_timeout"], 15)
        self.assertEqual(
            mock_connect.call_args.kwargs["options"],
            "-c default_transaction_read_only=on -c statement_timeout=60000",
        )

    @patch("posthog.hogql.direct_sql.postgres_adapter.psycopg.connect")
    def test_execute_direct_postgres_query_uses_custom_statement_timeout(self, mock_connect):
        source = ExternalDataSource.objects.create(
            team=self.team,
            source_id="source_id",
            connection_id="connection_id",
            status=ExternalDataSource.Status.COMPLETED,
            source_type="Postgres",
            access_method=ExternalDataSource.AccessMethod.DIRECT,
            prefix="ph3",
            job_inputs={
                "host": "localhost",
                "port": 5432,
                "database": "postgres",
                "user": "postgres",
                "password": "postgres",
                "schema": "ph3",
            },
        )

        DataWarehouseTable.objects.create(
            name="posthog_dashboard",
            format="Parquet",
            team=self.team,
            external_data_source=source,
            url_pattern="direct://postgres",
            columns={
                "id": {"hogql": "IntegerDatabaseField", "clickhouse": "Int64", "valid": True},
            },
        )

        mocked_cursor = MagicMock()
        mocked_cursor.fetchall.return_value = [(1,)]
        column = MagicMock(type_code=23)
        column.name = "id"
        mocked_cursor.description = [column]
        mocked_connection = MagicMock()
        mocked_connection.cursor.return_value.__enter__.return_value = mocked_cursor
        mock_connect.return_value.__enter__.return_value = mocked_connection

        executor = HogQLQueryExecutor(
            query="SELECT id FROM posthog_dashboard LIMIT 1",
            team=self.team,
            connection_id=str(source.id),
            settings=HogQLGlobalSettings(max_execution_time=12),
        )

        executor.execute()

        self.assertEqual(
            mock_connect.call_args.kwargs["options"], "-c default_transaction_read_only=on -c statement_timeout=12000"
        )
        self.assertTrue(any(timing.k.endswith("/postgres_execute") for timing in executor.timings.to_list()))

    @patch("posthog.hogql.direct_sql.postgres_adapter.psycopg.connect")
    def test_execute_direct_postgres_query_records_postgres_execute_timing(self, mock_connect):
        source = ExternalDataSource.objects.create(
            team=self.team,
            source_id="source_id",
            connection_id="connection_id",
            status=ExternalDataSource.Status.COMPLETED,
            source_type="Postgres",
            access_method=ExternalDataSource.AccessMethod.DIRECT,
            prefix="ph3",
            job_inputs={
                "host": "localhost",
                "port": 5432,
                "database": "postgres",
                "user": "postgres",
                "password": "postgres",
                "schema": "ph3",
            },
        )

        DataWarehouseTable.objects.create(
            name="posthog_dashboard",
            format="Parquet",
            team=self.team,
            external_data_source=source,
            url_pattern="direct://postgres",
            columns={
                "id": {"hogql": "IntegerDatabaseField", "clickhouse": "Int64", "valid": True},
            },
        )

        mocked_cursor = MagicMock()
        mocked_cursor.fetchall.return_value = [(1,)]
        column = MagicMock(type_code=23)
        column.name = "id"
        mocked_cursor.description = [column]
        mocked_connection = MagicMock()
        mocked_connection.cursor.return_value.__enter__.return_value = mocked_cursor
        mock_connect.return_value.__enter__.return_value = mocked_connection

        executor = HogQLQueryExecutor(
            query="SELECT id FROM posthog_dashboard LIMIT 1",
            team=self.team,
            connection_id=str(source.id),
        )

        response = executor.execute()

        timing_keys = {timing.k for timing in response.timings or []}
        for timing_suffix in (
            "/postgres_source_validation",
            "/postgres_source_helpers_import",
            "/postgres_source_config",
            "/postgres_source_capability",
            "/postgres_source_registry",
            "/postgres_source_parse_config",
            "/postgres_ssh_validation",
            "/postgres_host_validation",
            "/postgres_execute",
            "/postgres_tunnel_open",
            "/postgres_connect",
            "/postgres_session_setup",
            "/postgres_query_execute",
            "/postgres_query_fetch",
        ):
            self.assertTrue(any(key.endswith(timing_suffix) for key in timing_keys))

    @patch("posthog.hogql.direct_sql.postgres_adapter.psycopg.connect")
    def test_execute_direct_postgres_query_reraises_unexpected_errors(self, mock_connect):
        source = ExternalDataSource.objects.create(
            team=self.team,
            source_id="source_id",
            connection_id="connection_id",
            status=ExternalDataSource.Status.COMPLETED,
            source_type="Postgres",
            access_method=ExternalDataSource.AccessMethod.DIRECT,
            prefix="ph3",
            job_inputs={
                "host": "localhost",
                "port": 5432,
                "database": "postgres",
                "user": "postgres",
                "password": "postgres",
                "schema": "ph3",
            },
        )

        DataWarehouseTable.objects.create(
            name="posthog_dashboard",
            format="Parquet",
            team=self.team,
            external_data_source=source,
            url_pattern="direct://postgres",
            columns={
                "id": {"hogql": "IntegerDatabaseField", "clickhouse": "Int64", "valid": True},
            },
        )

        mocked_cursor = MagicMock()
        mocked_cursor.execute.side_effect = RuntimeError("boom")
        mocked_connection = MagicMock()
        mocked_connection.cursor.return_value.__enter__.return_value = mocked_cursor
        mock_connect.return_value.__enter__.return_value = mocked_connection

        executor = HogQLQueryExecutor(
            query="SELECT id FROM posthog_dashboard LIMIT 1",
            team=self.team,
            connection_id=str(source.id),
        )

        with self.assertRaises(RuntimeError) as error:
            executor.execute()

        self.assertEqual(str(error.exception), "boom")

    _SSH_TUNNEL_CONFIG = {
        "ssh_tunnel": {
            "enabled": True,
            "host": "bastion.example.com",
            "port": 22,
            "auth_type": {
                "selection": "password",
                "username": "user",
                "password": "pass",
                "private_key": "",
                "passphrase": "",
            },
        },
    }

    _SSH_TUNNEL_TLS_OFF = {
        "ssh_tunnel": {
            **_SSH_TUNNEL_CONFIG["ssh_tunnel"],
            "require_tls": {"enabled": False},
        },
    }

    _SSH_TUNNEL_DISABLED_TLS_OFF = {
        "ssh_tunnel": {
            **_SSH_TUNNEL_CONFIG["ssh_tunnel"],
            "enabled": False,
            "require_tls": {"enabled": False},
        },
    }

    @parameterized.expand(
        [
            ("no_tunnel", {}, "require"),
            ("tunnel_tls_on", _SSH_TUNNEL_CONFIG, "require"),
            ("tunnel_tls_off", _SSH_TUNNEL_TLS_OFF, "prefer"),
            ("disabled_tunnel_tls_off_ignored", _SSH_TUNNEL_DISABLED_TLS_OFF, "require"),
        ]
    )
    @override_settings(DEBUG=False, TEST=False)
    @patch("products.warehouse_sources.backend.models.ssh_tunnel.SSHTunnelForwarder")
    @patch("posthog.hogql.direct_sql.postgres_adapter.psycopg.connect")
    def test_direct_postgres_ssl(self, _name, job_inputs, expected_sslmode, mock_connect, mock_tunnel_cls):
        mock_tunnel = MagicMock()
        mock_tunnel.local_bind_host = "127.0.0.1"
        mock_tunnel.local_bind_port = 15432
        mock_tunnel.__enter__ = MagicMock(return_value=mock_tunnel)
        mock_tunnel.__exit__ = MagicMock(return_value=False)
        mock_tunnel_cls.return_value = mock_tunnel

        base_inputs = {
            "host": "localhost",
            "port": 5432,
            "database": "postgres",
            "user": "postgres",
            "password": "postgres",
            "schema": "ph3",
        }
        base_inputs.update(job_inputs)

        source = ExternalDataSource.objects.create(
            team=self.team,
            source_id="source_id",
            connection_id="connection_id",
            status=ExternalDataSource.Status.COMPLETED,
            source_type="Postgres",
            access_method=ExternalDataSource.AccessMethod.DIRECT,
            prefix="ph3",
            job_inputs=base_inputs,
        )
        source.created_at = SSL_REQUIRED_AFTER_DATE + timedelta(days=1)
        source.save(update_fields=["created_at"])

        DataWarehouseTable.objects.create(
            name="posthog_dashboard",
            format="Parquet",
            team=self.team,
            external_data_source=source,
            url_pattern="direct://postgres",
            columns={
                "id": {"hogql": "IntegerDatabaseField", "clickhouse": "Int64", "valid": True},
            },
        )

        mocked_cursor = MagicMock()
        mocked_cursor.fetchall.return_value = [(1,)]
        column = MagicMock(type_code=23)
        column.name = "id"
        mocked_cursor.description = [column]
        mocked_connection = MagicMock()
        mocked_connection.cursor.return_value.__enter__.return_value = mocked_cursor
        mock_connect.return_value.__enter__.return_value = mocked_connection

        executor = HogQLQueryExecutor(
            query="SELECT id FROM posthog_dashboard LIMIT 1",
            team=self.team,
            connection_id=str(source.id),
        )

        executor.execute()

        self.assertEqual(mock_connect.call_args.kwargs["sslmode"], expected_sslmode)

    @override_settings(DEBUG=False, TEST=False)
    @patch("products.warehouse_sources.backend.models.ssh_tunnel.SSHTunnelForwarder")
    @patch("posthog.hogql.direct_sql.postgres_adapter.psycopg.connect")
    def test_direct_postgres_ssh_tunnel_failure_raises_exposed_error(self, mock_connect, mock_tunnel_cls):
        mock_tunnel_cls.return_value.__enter__.side_effect = BaseSSHTunnelForwarderError(
            "Could not establish session to SSH gateway"
        )

        source = ExternalDataSource.objects.create(
            team=self.team,
            source_id="source_id",
            connection_id="connection_id",
            status=ExternalDataSource.Status.COMPLETED,
            source_type="Postgres",
            access_method=ExternalDataSource.AccessMethod.DIRECT,
            prefix="ph3",
            job_inputs={
                "host": "localhost",
                "port": 5432,
                "database": "postgres",
                "user": "postgres",
                "password": "postgres",
                "schema": "ph3",
                **self._SSH_TUNNEL_CONFIG,
            },
        )

        DataWarehouseTable.objects.create(
            name="posthog_dashboard",
            format="Parquet",
            team=self.team,
            external_data_source=source,
            url_pattern="direct://postgres",
            columns={"id": {"hogql": "IntegerDatabaseField", "clickhouse": "Int64", "valid": True}},
        )

        executor = HogQLQueryExecutor(
            query="SELECT id FROM posthog_dashboard LIMIT 1",
            team=self.team,
            connection_id=str(source.id),
        )

        with self.assertRaises(ExposedHogQLError) as error:
            executor.execute()

        self.assertEqual(str(error.exception), "Could not establish session to SSH gateway")
        mock_connect.assert_not_called()

    @override_settings(DEBUG=False, TEST=False, E2E_TESTING=True)
    @patch("posthog.hogql.direct_sql.postgres_adapter.psycopg.connect")
    def test_execute_direct_postgres_query_uses_prefer_sslmode_in_e2e_for_new_sources(self, mock_connect):
        source = ExternalDataSource.objects.create(
            team=self.team,
            source_id="source_id",
            connection_id="connection_id",
            status=ExternalDataSource.Status.COMPLETED,
            source_type="Postgres",
            access_method=ExternalDataSource.AccessMethod.DIRECT,
            prefix="ph3",
            job_inputs={
                "host": "localhost",
                "port": 5432,
                "database": "postgres",
                "user": "postgres",
                "password": "postgres",
                "schema": "ph3",
            },
        )
        source.created_at = SSL_REQUIRED_AFTER_DATE + timedelta(days=1)
        source.save(update_fields=["created_at"])

        DataWarehouseTable.objects.create(
            name="posthog_dashboard",
            format="Parquet",
            team=self.team,
            external_data_source=source,
            url_pattern="direct://postgres",
            columns={
                "id": {"hogql": "IntegerDatabaseField", "clickhouse": "Int64", "valid": True},
            },
        )

        mocked_cursor = MagicMock()
        mocked_cursor.fetchall.return_value = [(1,)]
        column = MagicMock(type_code=23)
        column.name = "id"
        mocked_cursor.description = [column]
        mocked_connection = MagicMock()
        mocked_connection.cursor.return_value.__enter__.return_value = mocked_cursor
        mock_connect.return_value.__enter__.return_value = mocked_connection

        executor = HogQLQueryExecutor(
            query="SELECT id FROM posthog_dashboard LIMIT 1",
            team=self.team,
            connection_id=str(source.id),
        )

        executor.execute()

        self.assertEqual(mock_connect.call_args.kwargs["sslmode"], "prefer")

    @parameterized.expand(
        [
            ("us", "db.us.postwh.com"),
            ("eu", "db.eu.postwh.com"),
            ("eu_uppercase_trailing_dot", "DB.EU.POSTWH.COM."),
        ]
    )
    @override_settings(DEBUG=False, TEST=False)
    @patch("posthog.hogql.direct_sql.postgres_adapter.psycopg.connect")
    def test_execute_direct_postgres_query_adds_ssl_cert_paths_for_postwh_hosts(self, _name, host, mock_connect):
        source = ExternalDataSource.objects.create(
            team=self.team,
            source_id="source_id",
            connection_id="connection_id",
            status=ExternalDataSource.Status.COMPLETED,
            source_type="Postgres",
            access_method=ExternalDataSource.AccessMethod.DIRECT,
            prefix="ph3",
            job_inputs={
                "host": host,
                "port": 5432,
                "database": "postgres",
                "user": "postgres",
                "password": "postgres",
                "schema": "ph3",
            },
        )
        source.created_at = SSL_REQUIRED_AFTER_DATE - timedelta(days=1)
        source.save(update_fields=["created_at"])

        DataWarehouseTable.objects.create(
            name="posthog_dashboard",
            format="Parquet",
            team=self.team,
            external_data_source=source,
            url_pattern="direct://postgres",
            columns={
                "id": {"hogql": "IntegerDatabaseField", "clickhouse": "Int64", "valid": True},
            },
        )

        mocked_cursor = MagicMock()
        mocked_cursor.fetchall.return_value = [(1,)]
        column = MagicMock(type_code=23)
        column.name = "id"
        mocked_cursor.description = [column]
        mocked_connection = MagicMock()
        mocked_connection.cursor.return_value.__enter__.return_value = mocked_cursor
        mock_connect.return_value.__enter__.return_value = mocked_connection

        executor = HogQLQueryExecutor(
            query="SELECT id FROM posthog_dashboard LIMIT 1",
            team=self.team,
            connection_id=str(source.id),
        )

        executor.execute()

        self.assertEqual(mock_connect.call_args.kwargs["sslmode"], "require")
        self.assertEqual(mock_connect.call_args.kwargs["sslcert"], "/tmp/no.txt")
        self.assertEqual(mock_connect.call_args.kwargs["sslkey"], "/tmp/no.txt")
        self.assertEqual(mock_connect.call_args.kwargs["sslrootcert"], "/tmp/no.txt")

    def test_hogql_query_for_synced_source_prints_identical_sql_to_pure_direct(self):
        job_inputs = {
            "host": "localhost",
            "port": 5432,
            "database": "postgres",
            "user": "postgres",
            "password": "postgres",
            "schema": "public",
        }
        direct_source = ExternalDataSource.objects.create(
            team=self.team,
            source_id="pure_direct_source",
            connection_id="pure_direct_connection",
            status=ExternalDataSource.Status.COMPLETED,
            source_type="Postgres",
            access_method=ExternalDataSource.AccessMethod.DIRECT,
            prefix="direct",
            job_inputs=job_inputs,
        )
        DataWarehouseTable.objects.create(
            name="users",
            format="Parquet",
            team=self.team,
            external_data_source=direct_source,
            url_pattern="direct://postgres",
            columns={"id": {"hogql": "IntegerDatabaseField", "clickhouse": "Int64", "valid": True}},
        )
        synced_source = ExternalDataSource.objects.create(
            team=self.team,
            source_id="synced_source",
            connection_id="synced_connection",
            status=ExternalDataSource.Status.COMPLETED,
            source_type="Postgres",
            access_method=ExternalDataSource.AccessMethod.WAREHOUSE,
            direct_query_enabled=True,
            prefix="synced",
            job_inputs=job_inputs,
        )
        ExternalDataSchema.objects.create(
            team=self.team,
            name="users",
            source=synced_source,
            should_sync=True,
            sync_type_config={
                "schema_metadata": {
                    "columns": [{"name": "id", "data_type": "integer", "is_nullable": False}],
                    "source_schema": "public",
                    "source_table_name": "users",
                }
            },
        )

        sql_by_mode = {}
        for mode, source in (("direct", direct_source), ("synced", synced_source)):
            executor = HogQLQueryExecutor(
                query="SELECT id FROM users WHERE id > 10",
                team=self.team,
                connection_id=str(source.id),
            )
            sql, _context = executor.generate_clickhouse_sql()
            sql_by_mode[mode] = sql

        # The virtual table built from schema metadata must print byte-identically to the
        # physical pure-direct row for the same source location and columns.
        self.assertEqual(sql_by_mode["synced"], sql_by_mode["direct"])
        self.assertIn("public.users", sql_by_mode["synced"])

    @patch("posthog.hogql.direct_sql.postgres_adapter.psycopg.connect")
    def test_send_raw_query_for_synced_source_raises_error(self, mock_connect):
        # A synced source only exposes its `should_sync` catalog through the HogQL-compiled
        # path — raw SQL has no such projection, so it's restricted to pure-direct connections.
        source = ExternalDataSource.objects.create(
            team=self.team,
            source_id="synced_source",
            connection_id="synced_connection",
            status=ExternalDataSource.Status.COMPLETED,
            source_type="Postgres",
            access_method=ExternalDataSource.AccessMethod.WAREHOUSE,
            direct_query_enabled=True,
            prefix="synced",
            job_inputs={
                "host": "localhost",
                "port": 5432,
                "database": "postgres",
                "user": "postgres",
                "password": "postgres",
                "schema": "public",
            },
        )

        executor = HogQLQueryExecutor(
            query="SELECT 1 AS value",
            team=self.team,
            connection_id=str(source.id),
            send_raw_query=True,
        )

        with self.assertRaises(ExposedHogQLError) as ctx:
            executor.execute()

        self.assertIn("Invalid connectionId", str(ctx.exception))
        mock_connect.assert_not_called()

    @parameterized.expand(
        [
            ("empty", {}),
            ("partial", {"host": "localhost", "schema": "public"}),
        ]
    )
    def test_validate_source_config_raises_exposed_error_for_incomplete_job_inputs(self, _name: str, job_inputs: dict):
        # A direct-capable Postgres source with missing connection credentials must surface a clean
        # ExposedHogQLError, not a raw TypeError from config building that leaks to error tracking.
        source = ExternalDataSource.objects.create(
            team=self.team,
            source_id="source_id",
            connection_id="connection_id",
            status=ExternalDataSource.Status.COMPLETED,
            source_type="Postgres",
            access_method=ExternalDataSource.AccessMethod.DIRECT,
            prefix="ph3",
            job_inputs=job_inputs,
        )

        with self.assertRaises(ExposedHogQLError):
            PostgresAdapter().validate_source_config(source, self.team)
