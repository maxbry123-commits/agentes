from posthog.test.base import BaseTest
from unittest.mock import patch

from parameterized import parameterized

from posthog.schema import ParserMode

from posthog.hogql import (
    ast,
    parser as parser_module,
)
from posthog.hogql.errors import SyntaxError as HogQLSyntaxError
from posthog.hogql.parser import (
    HogQLParserShadowMismatch,
    ResolvedParserBackends,
    _resolve_parser_mode,
    parse_expr,
    parse_select,
    sanitize_client_parser_mode,
)


class TestParserMode(BaseTest):
    @parameterized.expand(
        [
            # No mode + no explicit backend in TEST → rust-py primary, no shadow
            # (prod's default shadow pair is asserted separately below).
            (None, None, ResolvedParserBackends(primary="rust-py")),
            # No mode + explicit backend → honour the explicit backend, no shadow.
            (None, "cpp-json", ResolvedParserBackends(primary="cpp-json")),
            (None, "rust-json", ResolvedParserBackends(primary="rust-json")),
            (None, "rust-py", ResolvedParserBackends(primary="rust-py")),
            (ParserMode.CPP_ONLY, None, ResolvedParserBackends(primary="cpp-json")),
            (ParserMode.RUST_ONLY, None, ResolvedParserBackends(primary="rust-json")),
            (ParserMode.CPP_WITH_RUST_SHADOW, None, ResolvedParserBackends(primary="cpp-json", shadow="rust-json")),
            (ParserMode.CPP_WITH_RUST_PY_SHADOW, None, ResolvedParserBackends(primary="cpp-json", shadow="rust-py")),
            (ParserMode.RUST_WITH_CPP_SHADOW, None, ResolvedParserBackends(primary="rust-json", shadow="cpp-json")),
            (ParserMode.RUST_PY_ONLY, None, ResolvedParserBackends(primary="rust-py")),
            (ParserMode.RUST_PY_WITH_CPP_SHADOW, None, ResolvedParserBackends(primary="rust-py", shadow="cpp-json")),
        ]
    )
    def test_resolve_parser_mode(self, mode, backend, expected):
        self.assertEqual(_resolve_parser_mode(mode, backend), expected)

    def test_resolve_parser_mode_default_shadows_in_prod(self):
        with patch("posthog.hogql.parser.settings") as mock_settings:
            mock_settings.TEST = False
            self.assertEqual(
                _resolve_parser_mode(None, None), ResolvedParserBackends(primary="rust-py", shadow="cpp-json")
            )

    def test_resolve_parser_mode_drops_shadow_when_rust_unavailable(self):
        with patch("posthog.hogql.parser._RUST_PARSER_AVAILABLE", False):
            self.assertEqual(_resolve_parser_mode(None, None), ResolvedParserBackends(primary="cpp-json"))

    def test_resolve_parser_mode_rejects_both_mode_and_backend(self):
        with self.assertRaises(ValueError):
            _resolve_parser_mode(ParserMode.RUST_PY_ONLY, "cpp-json")

    @parameterized.expand(
        [
            # cpp-as-primary modes are untrusted from a client → neutralized to the safe default.
            (ParserMode.CPP_ONLY, None),
            (ParserMode.CPP_WITH_RUST_SHADOW, None),
            (ParserMode.CPP_WITH_RUST_PY_SHADOW, None),
            # cpp-as-shadow and rust-primary modes are safe (rust primary rejects deep input
            # before the shadow runs) → passed through untouched.
            (ParserMode.RUST_WITH_CPP_SHADOW, ParserMode.RUST_WITH_CPP_SHADOW),
            (ParserMode.RUST_PY_WITH_CPP_SHADOW, ParserMode.RUST_PY_WITH_CPP_SHADOW),
            (ParserMode.RUST_ONLY, ParserMode.RUST_ONLY),
            (ParserMode.RUST_PY_ONLY, ParserMode.RUST_PY_ONLY),
            (None, None),
        ]
    )
    def test_sanitize_client_parser_mode(self, mode, expected):
        self.assertEqual(sanitize_client_parser_mode(mode), expected)

    def test_client_cpp_parser_mode_does_not_reach_the_parser(self):
        # A client that sets `parserMode=cpp_only` must not force the cpp backend: the query
        # path sanitizes it first, so `parse_select` sees the safe (None) mode. This guards the
        # wiring at the single consume point (query.py), not just the helper in isolation.
        from posthog.schema import HogQLQueryModifiers  # noqa: PLC0415

        from posthog.hogql.query import HogQLQueryExecutor  # noqa: PLC0415

        executor = HogQLQueryExecutor(
            query="select 1",
            team=self.team,
            modifiers=HogQLQueryModifiers(parserMode=ParserMode.CPP_ONLY),
        )
        with patch("posthog.hogql.query.parse_select", wraps=parse_select) as spy:
            executor._parse_query()
        self.assertIsNone(spy.call_args.kwargs["parser_mode"])

    def test_shadow_silent_when_backends_agree(self):
        with patch("posthog.hogql.parser._SHADOW_SAMPLE_RATE", 1.0):
            with patch("posthog.hogql.parser.capture_exception") as captured:
                node = parse_select("select 1 from events", parser_mode=ParserMode.CPP_WITH_RUST_SHADOW)
        self.assertIsInstance(node, ast.SelectQuery)
        captured.assert_not_called()

    def test_shadow_raises_mismatch_in_test_mode(self):
        decoy = ast.SelectQuery(select=[ast.Constant(value=999)])
        real_invoke = parser_module._invoke_parser

        def only_shadow_diverges(backend, rule, statement, start):
            if backend == "rust-json":
                return decoy
            return real_invoke(backend, rule, statement, start)

        with patch("posthog.hogql.parser._invoke_parser", side_effect=only_shadow_diverges):
            with self.assertRaises(HogQLParserShadowMismatch):
                parse_select(
                    "select shadow_mismatch_probe from events",
                    parser_mode=ParserMode.CPP_WITH_RUST_SHADOW,
                )

    def test_shadow_captures_mismatch_without_raising_in_prod(self):
        decoy = ast.SelectQuery(select=[ast.Constant(value=999)])
        real_invoke = parser_module._invoke_parser

        def only_shadow_diverges(backend, rule, statement, start):
            if backend == "rust-json":
                return decoy
            return real_invoke(backend, rule, statement, start)

        with patch("posthog.hogql.parser._SHADOW_SAMPLE_RATE", 1.0):
            with patch("posthog.hogql.parser.settings") as mock_settings:
                mock_settings.TEST = False
                with patch("posthog.hogql.parser._invoke_parser", side_effect=only_shadow_diverges):
                    with patch("posthog.hogql.parser.capture_exception") as captured:
                        node = parse_select(
                            "select shadow_mismatch_probe from events",
                            parser_mode=ParserMode.CPP_WITH_RUST_SHADOW,
                        )
        self.assertIsInstance(node, ast.SelectQuery)
        captured.assert_called_once()
        self.assertIsInstance(captured.call_args.args[0], HogQLParserShadowMismatch)

    def test_rust_only_parses_through_the_rust_backend(self):
        node = parse_select("select a, b from events where a > 1", parser_mode=ParserMode.RUST_ONLY)
        self.assertIsInstance(node, ast.SelectQuery)

    def test_shadow_raises_when_shadow_rejects_primary_accepted_input_in_test_mode(self):
        real_invoke = parser_module._invoke_parser

        def shadow_throws_parser_class(backend, rule, statement, start):
            if backend == "rust-json":
                raise HogQLSyntaxError("simulated rust-json regression")
            return real_invoke(backend, rule, statement, start)

        with patch("posthog.hogql.parser._invoke_parser", side_effect=shadow_throws_parser_class):
            with patch("posthog.hogql.parser.capture_exception"):
                with self.assertRaises(HogQLSyntaxError):
                    parse_select("select 1 from events", parser_mode=ParserMode.CPP_WITH_RUST_SHADOW)

    def test_shadow_rejection_counts_and_captures_sql_without_raising_in_prod(self):
        real_invoke = parser_module._invoke_parser

        def shadow_throws_parser_class(backend, rule, statement, start):
            if backend == "rust-py":
                raise HogQLSyntaxError("simulated rust-py rejection")
            return real_invoke(backend, rule, statement, start)

        with patch("posthog.hogql.parser.settings") as mock_settings:
            mock_settings.TEST = False
            with patch("posthog.hogql.parser._SHADOW_SAMPLE_RATE", 1.0):
                with patch("posthog.hogql.parser._invoke_parser", side_effect=shadow_throws_parser_class):
                    with patch("posthog.hogql.parser._SHADOW_COMPARISONS") as counter:
                        with patch("posthog.hogql.parser.capture_exception") as captured:
                            node = parse_select(
                                "select shadow_rejected_probe from events",
                                parser_mode=ParserMode.CPP_WITH_RUST_PY_SHADOW,
                            )
        self.assertIsInstance(node, ast.SelectQuery)
        results = [c.kwargs.get("result") for c in counter.labels.call_args_list]
        self.assertIn("shadow_rejected", results)
        captured.assert_called_once()
        props = captured.call_args.kwargs["additional_properties"]
        self.assertIn("shadow_rejected_probe", props["hogql_parser_statement"])
        self.assertEqual(props["hogql_parser_shadow_version"], parser_module._BACKEND_VERSION["rust-py"])

    def test_shadow_swallows_non_parser_packaging_error_even_in_test_mode(self):
        real_invoke = parser_module._invoke_parser

        def shadow_throws_packaging(backend, rule, statement, start):
            if backend == "rust-json":
                raise ImportError("simulated wheel failure")
            return real_invoke(backend, rule, statement, start)

        with patch("posthog.hogql.parser._invoke_parser", side_effect=shadow_throws_packaging):
            with patch("posthog.hogql.parser.capture_exception") as captured:
                node = parse_select("select 1 from events", parser_mode=ParserMode.CPP_WITH_RUST_SHADOW)
        self.assertIsInstance(node, ast.SelectQuery)
        captured.assert_called_once()
        self.assertIsInstance(captured.call_args.args[0], ImportError)

    def test_shadow_agreement_counts_as_agree_with_parser_version_labels(self):
        with patch("posthog.hogql.parser._SHADOW_COMPARISONS") as counter:
            with patch("posthog.hogql.parser.capture_exception") as captured:
                parse_select("select 1 from events", parser_mode=ParserMode.CPP_WITH_RUST_PY_SHADOW)
        self.assertEqual([c.kwargs.get("result") for c in counter.labels.call_args_list], ["agree"])
        agree_call = counter.labels.call_args_list[0]
        self.assertEqual(agree_call.kwargs["primary_version"], parser_module._BACKEND_VERSION["cpp-json"])
        self.assertEqual(agree_call.kwargs["shadow_version"], parser_module._BACKEND_VERSION["rust-py"])
        captured.assert_not_called()

    def test_shadow_divergence_counts_as_disagree_and_captures_sql_in_prod(self):
        decoy = ast.SelectQuery(select=[ast.Constant(value=999)])
        real_invoke = parser_module._invoke_parser

        def only_shadow_diverges(backend, rule, statement, start):
            if backend == "rust-py":
                return decoy
            return real_invoke(backend, rule, statement, start)

        with patch("posthog.hogql.parser.settings") as mock_settings:
            mock_settings.TEST = False
            with patch("posthog.hogql.parser._SHADOW_SAMPLE_RATE", 1.0):
                with patch("posthog.hogql.parser._invoke_parser", side_effect=only_shadow_diverges):
                    with patch("posthog.hogql.parser._SHADOW_COMPARISONS") as counter:
                        with patch("posthog.hogql.parser.capture_exception") as captured:
                            parse_select(
                                "select sql_attach_probe from events",
                                parser_mode=ParserMode.CPP_WITH_RUST_PY_SHADOW,
                            )
        results = [c.kwargs.get("result") for c in counter.labels.call_args_list]
        self.assertIn("disagree", results)
        captured.assert_called_once()
        self.assertIsInstance(captured.call_args.args[0], HogQLParserShadowMismatch)
        props = captured.call_args.kwargs["additional_properties"]
        self.assertEqual(props["hogql_parser_rule"], "select")
        self.assertIn("sql_attach_probe", props["hogql_parser_statement"])
        self.assertEqual(props["hogql_parser_primary_version"], parser_module._BACKEND_VERSION["cpp-json"])
        self.assertEqual(props["hogql_parser_shadow_version"], parser_module._BACKEND_VERSION["rust-py"])

    def test_shadow_treats_nan_constant_as_agreement_not_divergence(self):
        with patch("posthog.hogql.parser._SHADOW_COMPARISONS") as counter:
            node = parse_expr("nan", parser_mode=ParserMode.CPP_WITH_RUST_PY_SHADOW)
        self.assertIsInstance(node, ast.Constant)
        self.assertEqual([c.kwargs.get("result") for c in counter.labels.call_args_list], ["agree"])

    def test_parser_version_falls_back_to_unknown_for_missing_dist(self):
        self.assertEqual(parser_module._parser_version("definitely-not-a-real-distribution"), "unknown")

    def test_backend_version_map_covers_every_parse_backend(self):
        self.assertEqual(set(parser_module._BACKEND_VERSION), set(parser_module.RULE_TO_PARSE_FUNCTION))
