from decimal import Decimal
from uuid import UUID

from freezegun import freeze_time
from posthog.test.base import _create_event, _create_person, snapshot_clickhouse_queries
from unittest.mock import patch

from parameterized import parameterized

from posthog.schema import (
    CurrencyCode,
    DateRange,
    HogQLQueryModifiers,
    PersonsOnEventsMode,
    RevenueAnalyticsEventItem,
    RevenueCurrencyPropertyConfig,
    SubscriptionDropoffMode,
    TrendsQuery,
)

from posthog.hogql import ast
from posthog.hogql.database.schema import persons_revenue_analytics
from posthog.hogql.database.schema.test.base import RevenueAnalyticsManagedViewsetsTestMixin, RevenueAnalyticsTestBase
from posthog.hogql.parser import parse_select
from posthog.hogql.query import execute_hogql_query

from posthog.hogql_queries.insights.trends.trends_query_runner import TrendsQueryRunner

from products.data_tools.backend.models.join import DataWarehouseJoin
from products.revenue_analytics.backend.views.schemas.customer import SCHEMA


class TestPersonsRevenueAnalyticsMixin(RevenueAnalyticsTestBase):
    # The base default is the all-zeros UUID, which this table drops as the unattributable key a
    # LEFT JOIN miss produces. Real person UUIDs are never all-zeros, so use one that isn't.
    PERSON_ID = "0193a0b1-2c3d-4e5f-8899-aabbccddeeff"

    def setup_events(self):
        _create_person(
            uuid=self.PERSON_ID,
            team_id=self.team.pk,
            distinct_ids=[self.DISTINCT_ID],
        )

        _create_event(
            event="$pageview",
            team=self.team,
            distinct_id=self.DISTINCT_ID,
            timestamp=self.EVENT_TIMESTAMP,
        )

        _create_event(
            event=self.PURCHASE_EVENT_NAME,
            team=self.team,
            distinct_id=self.DISTINCT_ID,
            timestamp=self.EVENT_TIMESTAMP,
            properties={self.REVENUE_PROPERTY: 10000},
        )

        _create_event(
            event=self.PURCHASE_EVENT_NAME,
            team=self.team,
            distinct_id=self.DISTINCT_ID,
            timestamp=self.EVENT_TIMESTAMP,
            properties={self.REVENUE_PROPERTY: 25042},
        )

    def setup_events_with_subscriptions(self):
        _create_person(
            uuid=self.PERSON_ID,
            team_id=self.team.pk,
            distinct_ids=[self.DISTINCT_ID],
        )

        _create_event(
            event="$pageview",
            team=self.team,
            distinct_id=self.DISTINCT_ID,
            timestamp=self.EVENT_TIMESTAMP,
        )

        # Non-recurring event (no subscription_id)
        _create_event(
            event=self.PURCHASE_EVENT_NAME,
            team=self.team,
            distinct_id=self.DISTINCT_ID,
            timestamp=self.EVENT_TIMESTAMP,
            properties={self.REVENUE_PROPERTY: 10042},
        )

        # Recurring event (with subscription_id) - contributes to MRR
        _create_event(
            event=self.PURCHASE_EVENT_NAME,
            team=self.team,
            distinct_id=self.DISTINCT_ID,
            timestamp=self.EVENT_TIMESTAMP,
            properties={self.REVENUE_PROPERTY: 25042, self.SUBSCRIPTION_PROPERTY: "sub_1"},
        )

    def setup_schema_sources(self):
        self.create_sources()
        self.join = DataWarehouseJoin.objects.create(
            team=self.team,
            source_table_name=f"stripe.posthog_test.{SCHEMA.source_suffix}",
            source_table_key="id",
            joining_table_name="persons",
            joining_table_key="pdi.distinct_id",
            field_name="persons",
        )

        self.team.base_currency = CurrencyCode.GBP.value
        self.team.save()


@snapshot_clickhouse_queries
class TestPersonsRevenueAnalytics(TestPersonsRevenueAnalyticsMixin):
    def test_get_revenue_for_events(self):
        self.setup_events()

        self.team.revenue_analytics_config.events = [
            RevenueAnalyticsEventItem(
                eventName=self.PURCHASE_EVENT_NAME,
                revenueProperty=self.REVENUE_PROPERTY,
                revenueCurrencyProperty=RevenueCurrencyPropertyConfig(static="USD"),
                currencyAwareDecimal=True,
            )
        ]
        self.team.revenue_analytics_config.save()
        self.team.save()

        with freeze_time(self.QUERY_TIMESTAMP):
            response = execute_hogql_query(
                parse_select(
                    "select revenue_analytics.revenue, $virt_revenue from persons where id = {id}",
                    placeholders={"id": ast.Constant(value=self.PERSON_ID)},
                ),
                self.team,
                user=self.user,
            )

            self.assertEqual(response.results[0], (Decimal("350.42"), Decimal("350.42")))

    def test_get_revenue_for_schema_source_for_id_join(self):
        self.setup_schema_sources()
        self.join.source_table_key = "id"
        self.join.save()

        # These are the 6 IDs inside the CSV files, plus an extra dummy/empty one
        distinct_id_to_person_id: dict[str, str] = {}
        for distinct_id in ["cus_1", "cus_2", "cus_3", "cus_4", "cus_5", "cus_6", "dummy"]:
            person = _create_person(team_id=self.team.pk, distinct_ids=[distinct_id])
            distinct_id_to_person_id[distinct_id] = person.uuid

        with freeze_time(self.QUERY_TIMESTAMP):
            queries = [
                "SELECT id, revenue_analytics.revenue from persons order by id asc",
                "SELECT id, $virt_revenue from persons order by id asc",
            ]

            for query in queries:
                response = execute_hogql_query(parse_select(query), self.team, user=self.user, modifiers=self.MODIFIERS)

                self.assertEqual(
                    response.results,
                    [
                        (distinct_id_to_person_id["cus_1"], Decimal("283.8496260553")),
                        (distinct_id_to_person_id["cus_2"], Decimal("482.2158673452")),
                        (distinct_id_to_person_id["cus_3"], Decimal("4161.34422")),
                        (distinct_id_to_person_id["cus_4"], Decimal("254.12345")),
                        (distinct_id_to_person_id["cus_5"], Decimal("1494.0562")),
                        (distinct_id_to_person_id["cus_6"], Decimal("2796.37014")),
                        (distinct_id_to_person_id["dummy"], None),
                    ],
                )

    def test_get_revenue_for_schema_source_for_email_join(self):
        self.setup_schema_sources()
        self.join.source_table_key = "email"
        self.join.save()

        # These are the 6 IDs inside the CSV files, and we have an extra empty one
        distinct_id_to_person_id: dict[str, str] = {}
        for distinct_id in [
            "john.doe@example.com",  # cus_1
            "jane.doe@example.com",  # cus_2
            "john.smith@example.com",  # cus_3
            "jane.smith@example.com",  # cus_4
            "john.doejr@example.com",  # cus_5
            "john.doejrjr@example.com",  # cus_6
            "zdummy",
        ]:
            person = _create_person(team_id=self.team.pk, distinct_ids=[distinct_id])
            distinct_id_to_person_id[distinct_id] = person.uuid

        with freeze_time(self.QUERY_TIMESTAMP):
            response = execute_hogql_query(
                parse_select("SELECT id, revenue_analytics.revenue, $virt_revenue FROM persons ORDER BY id ASC"),
                self.team,
                user=self.user,
                modifiers=self.MODIFIERS,
            )

            self.assertEqual(
                response.results,
                [
                    (
                        distinct_id_to_person_id["john.doe@example.com"],
                        Decimal("283.8496260553"),
                        Decimal("283.8496260553"),
                    ),
                    (
                        distinct_id_to_person_id["jane.doe@example.com"],
                        Decimal("482.2158673452"),
                        Decimal("482.2158673452"),
                    ),
                    (distinct_id_to_person_id["john.smith@example.com"], Decimal("4161.34422"), Decimal("4161.34422")),
                    (distinct_id_to_person_id["jane.smith@example.com"], Decimal("254.12345"), Decimal("254.12345")),
                    (distinct_id_to_person_id["john.doejr@example.com"], Decimal("1494.0562"), Decimal("1494.0562")),
                    (
                        distinct_id_to_person_id["john.doejrjr@example.com"],
                        Decimal("2796.37014"),
                        Decimal("2796.37014"),
                    ),
                    (distinct_id_to_person_id["zdummy"], None, None),
                ],
            )

    def test_get_revenue_for_schema_source_for_metadata_join(self):
        self.setup_schema_sources()
        self.join.source_table_key = "JSONExtractString(metadata, 'id')"
        self.join.save()

        # These are the 6 IDs inside the CSV files, and we have an extra empty one
        distinct_id_to_person_id: dict[str, str] = {}
        for distinct_id in [
            "cus_1_metadata",
            "cus_2_metadata",
            "cus_3_metadata",
            "cus_4_metadata",
            "cus_5_metadata",
            "cus_6_metadata",
            "dummy",
        ]:
            person = _create_person(team_id=self.team.pk, distinct_ids=[distinct_id])
            distinct_id_to_person_id[distinct_id] = person.uuid

        with freeze_time(self.QUERY_TIMESTAMP):
            response = execute_hogql_query(
                parse_select("SELECT id, revenue_analytics.revenue, $virt_revenue from persons order by id asc"),
                self.team,
                user=self.user,
                modifiers=self.MODIFIERS,
            )

            self.assertEqual(
                response.results,
                [
                    (distinct_id_to_person_id["cus_1_metadata"], Decimal("283.8496260553"), Decimal("283.8496260553")),
                    (distinct_id_to_person_id["cus_2_metadata"], Decimal("482.2158673452"), Decimal("482.2158673452")),
                    (distinct_id_to_person_id["cus_3_metadata"], Decimal("4161.34422"), Decimal("4161.34422")),
                    (distinct_id_to_person_id["cus_4_metadata"], Decimal("254.12345"), Decimal("254.12345")),
                    (distinct_id_to_person_id["cus_5_metadata"], Decimal("1494.0562"), Decimal("1494.0562")),
                    (distinct_id_to_person_id["cus_6_metadata"], Decimal("2796.37014"), Decimal("2796.37014")),
                    (distinct_id_to_person_id["dummy"], None, None),
                ],
            )

    def test_get_revenue_for_schema_source_for_customer_with_multiple_distinct_ids(self):
        self.setup_schema_sources()
        self.join.source_table_key = "email"
        self.join.save()

        # Person has several distinct IDs, but only one of them can be matched from the customer table
        multiple_distinct_ids_person = _create_person(
            team_id=self.team.pk, distinct_ids=["distinct_1", "john.doe@example.com"]
        )

        # Dummy person without revenue
        dummy_person = _create_person(team_id=self.team.pk, distinct_ids=["dummy"])

        with freeze_time(self.QUERY_TIMESTAMP):
            response = execute_hogql_query(
                parse_select("SELECT id, $virt_revenue FROM persons ORDER BY $virt_revenue ASC"),
                self.team,
                user=self.user,
                modifiers=self.MODIFIERS,
            )

            self.assertEqual(
                response.results,
                [
                    (multiple_distinct_ids_person.uuid, Decimal("283.8496260553")),
                    (dummy_person.uuid, None),
                ],
            )

            response = execute_hogql_query(
                parse_select("SELECT $virt_revenue FROM persons ORDER BY $virt_revenue ASC"),
                self.team,
                user=self.user,
                modifiers=self.MODIFIERS,
            )

            self.assertEqual(response.results, [(Decimal("283.8496260553"),), (None,)])

    def test_revenue_aggregated_per_person_across_multiple_customers(self):
        self.setup_schema_sources()
        self.join.source_table_key = "id"
        self.join.save()

        # One person owns two distinct IDs, each matching a different Stripe customer. Without
        # per-person aggregation this maps to two rows and fans the persons table out on join.
        person = _create_person(team_id=self.team.pk, distinct_ids=["cus_1", "cus_2"])

        expected_revenue = Decimal("766.0654934005")  # cus_1 283.8496260553 + cus_2 482.2158673452
        expected_mrr = Decimal("63.7684363904")  # cus_1 22.9631447238 + cus_2 40.8052916666

        with freeze_time(self.QUERY_TIMESTAMP):
            table_results = execute_hogql_query(
                parse_select(
                    "SELECT person_id, revenue, mrr FROM persons_revenue_analytics WHERE person_id = {id}",
                    placeholders={"id": ast.Constant(value=person.uuid)},
                ),
                self.team,
                user=self.user,
                modifiers=self.MODIFIERS,
            )
            self.assertEqual(table_results.results, [(person.uuid, expected_revenue, expected_mrr)])

            persons_results = execute_hogql_query(
                parse_select(
                    "SELECT id, $virt_revenue, $virt_mrr FROM persons WHERE id = {id}",
                    placeholders={"id": ast.Constant(value=person.uuid)},
                ),
                self.team,
                user=self.user,
                modifiers=self.MODIFIERS,
            )
            self.assertEqual(persons_results.results, [(person.uuid, expected_revenue, expected_mrr)])

    def test_revenue_aggregated_per_person_across_event_and_warehouse_sources(self):
        self.setup_schema_sources()

        self.setup_events()

        self.team.revenue_analytics_config.events = [
            RevenueAnalyticsEventItem(
                eventName=self.PURCHASE_EVENT_NAME,
                revenueProperty=self.REVENUE_PROPERTY,
                revenueCurrencyProperty=RevenueCurrencyPropertyConfig(static="USD"),
                currencyAwareDecimal=True,
            )
        ]
        self.team.revenue_analytics_config.save()
        self.team.save()

        # Both source kinds are configured, so the two legs of the UNION ALL must agree on `person_id`
        warehouse_person = _create_person(team_id=self.team.pk, distinct_ids=["cus_1"])

        # `cus_2` through `cus_6` match no person, so they carry the all-zeros UUID and are dropped.
        # Only the two attributable rows remain, one from each leg.
        with freeze_time(self.QUERY_TIMESTAMP):
            results = execute_hogql_query(
                parse_select("SELECT person_id, revenue, mrr FROM persons_revenue_analytics"),
                self.team,
                user=self.user,
                modifiers=self.MODIFIERS,
            )

            self.assertEqual(
                sorted(results.results),
                sorted(
                    [
                        (warehouse_person.uuid, Decimal("283.8496260553"), Decimal("22.9631447238")),
                        (UUID(self.PERSON_ID), Decimal("279.28474"), Decimal("0")),
                    ]
                ),
            )

    def test_warehouse_join_named_persons_pointing_elsewhere_is_ignored(self):
        self.create_sources()
        self.team.base_currency = CurrencyCode.GBP.value
        self.team.save()

        # `field_name` is user-controlled, so a join can be called `persons` while pointing anywhere.
        # Reading `id` off that table casts to NULL, which would pool every customer's revenue into
        # one row keyed on nothing. The source is skipped instead.
        DataWarehouseJoin.objects.create(
            team=self.team,
            source_table_name=f"stripe.posthog_test.{SCHEMA.source_suffix}",
            source_table_key="id",
            joining_table_name="posthog_test_stripe_customer",
            joining_table_key="id",
            field_name="persons",
        )

        with freeze_time(self.QUERY_TIMESTAMP), patch.object(persons_revenue_analytics, "logger") as mock_logger:
            results = execute_hogql_query(
                parse_select("SELECT person_id, revenue FROM persons_revenue_analytics"),
                self.team,
                user=self.user,
                modifiers=self.MODIFIERS,
            )

            self.assertEqual(results.results, [])

            # Dropping the source is silent in the results, so the warning is the only way to tell
            # this apart from the source genuinely earning nothing.
            mock_logger.warning.assert_called_once()
            event, kwargs = mock_logger.warning.call_args[0][0], mock_logger.warning.call_args[1]
            self.assertEqual(event, "persons_revenue_analytics_skipped_source")
            self.assertEqual(kwargs["team_id"], self.team.pk)

    @parameterized.expand(["events", "warehouse", "none"])
    def test_person_id_joins_directly_against_persons_id(self, source_kind: str):
        # `person_id` is the documented join target for `persons.id`. The event leg reaches it through
        # `toString(persons.id)`, so it is the leg that fails with `NO_COMMON_TYPE` when the column is
        # not cast back to UUID. The warehouse leg already holds a UUID and passes either way, so both
        # kinds are covered to stop one of them regressing alone. `none` covers the empty-table branch,
        # which is most projects: the join has to return no rows there rather than fail on the types.
        # `none` configures no source at all, so the table falls to its empty branch
        expected_rows: list[tuple] = []
        if source_kind == "events":
            self.setup_events()
            self.team.revenue_analytics_config.events = [
                RevenueAnalyticsEventItem(
                    eventName=self.PURCHASE_EVENT_NAME,
                    revenueProperty=self.REVENUE_PROPERTY,
                    revenueCurrencyProperty=RevenueCurrencyPropertyConfig(static="USD"),
                    currencyAwareDecimal=True,
                )
            ]
            self.team.revenue_analytics_config.save()
            self.team.save()
            expected_rows = [(UUID(self.PERSON_ID), Decimal("350.42"))]
        elif source_kind == "warehouse":
            self.setup_schema_sources()
            person = _create_person(team_id=self.team.pk, distinct_ids=["cus_1"])
            expected_rows = [(person.uuid, Decimal("283.8496260553"))]

        with freeze_time(self.QUERY_TIMESTAMP):
            results = execute_hogql_query(
                parse_select(
                    """
                    SELECT persons.id, revenue.revenue
                    FROM persons
                    JOIN persons_revenue_analytics AS revenue ON persons.id = revenue.person_id
                    """
                ),
                self.team,
                user=self.user,
                modifiers=self.MODIFIERS,
            )

            self.assertEqual(results.results, expected_rows)

    def test_query_revenue_analytics_table_sources(self):
        self.setup_schema_sources()
        self.join.source_table_key = "id"
        self.join.save()

        # Create persons matching customer IDs from the stripe data
        distinct_id_to_person_id: dict[str, str] = {}
        for distinct_id in ["cus_1", "cus_2", "cus_3", "cus_4", "cus_5", "cus_6"]:
            person = _create_person(team_id=self.team.pk, distinct_ids=[distinct_id])
            distinct_id_to_person_id[distinct_id] = person.uuid

        with freeze_time(self.QUERY_TIMESTAMP):
            results = execute_hogql_query(
                parse_select(
                    "SELECT person_id, revenue, mrr FROM persons_revenue_analytics ORDER BY mrr DESC, revenue DESC"
                ),
                self.team,
                user=self.user,
                modifiers=self.MODIFIERS,
            )

            self.assertEqual(
                results.results,
                [
                    (distinct_id_to_person_id["cus_3"], Decimal("4161.34422"), Decimal("1546.59444")),
                    (distinct_id_to_person_id["cus_6"], Decimal("2796.37014"), Decimal("1459.02008")),
                    (distinct_id_to_person_id["cus_4"], Decimal("254.12345"), Decimal("83.16695")),
                    (distinct_id_to_person_id["cus_5"], Decimal("1494.0562"), Decimal("43.82703")),
                    (distinct_id_to_person_id["cus_2"], Decimal("482.2158673452"), Decimal("40.8052916666")),
                    (distinct_id_to_person_id["cus_1"], Decimal("283.8496260553"), Decimal("22.9631447238")),
                ],
            )

    def test_query_revenue_analytics_table_events(self):
        self.setup_events_with_subscriptions()

        self.team.revenue_analytics_config.events = [
            RevenueAnalyticsEventItem(
                eventName=self.PURCHASE_EVENT_NAME,
                revenueProperty=self.REVENUE_PROPERTY,
                revenueCurrencyProperty=RevenueCurrencyPropertyConfig(static="USD"),
                currencyAwareDecimal=True,
                subscriptionProperty=self.SUBSCRIPTION_PROPERTY,
                subscriptionDropoffMode=SubscriptionDropoffMode.AFTER_DROPOFF_PERIOD,  # Better default for tests
            )
        ]
        self.team.revenue_analytics_config.save()
        self.team.save()

        with freeze_time(self.QUERY_TIMESTAMP):
            results = execute_hogql_query(
                parse_select("SELECT person_id, revenue, mrr FROM persons_revenue_analytics ORDER BY person_id ASC"),
                self.team,
                user=self.user,
                modifiers=self.MODIFIERS,
            )

            # MRR is calculated from recurring events (those with subscription_id)
            # Total revenue = 100.42 + 250.42 = 350.84, MRR = 250.42 (only the recurring event)
            self.assertEqual(
                results.results,
                [(UUID(self.PERSON_ID), Decimal("350.84"), Decimal("250.42"))],
            )

    @parameterized.expand([e.value for e in PersonsOnEventsMode])
    def test_virtual_property_in_trend(self, mode):
        self.setup_events()

        self.team.revenue_analytics_config.events = [
            RevenueAnalyticsEventItem(
                eventName=self.PURCHASE_EVENT_NAME,
                revenueProperty=self.REVENUE_PROPERTY,
                revenueCurrencyProperty=RevenueCurrencyPropertyConfig(static="USD"),
                currencyAwareDecimal=True,
            )
        ]
        self.team.revenue_analytics_config.save()
        self.team.save()

        # Breaking down by revenue doesnt make any sense, but this is just proving it works
        with freeze_time(self.QUERY_TIMESTAMP):
            query = TrendsQuery(
                **{
                    "kind": "TrendsQuery",
                    "series": [{"kind": "EventsNode", "name": "$pageview", "event": "$pageview", "math": "total"}],
                    "trendsFilter": {},
                    "breakdownFilter": {"breakdowns": [{"property": "$virt_revenue", "type": "person"}]},
                },
                dateRange=DateRange(date_from="all", date_to=None),
                modifiers=HogQLQueryModifiers(personsOnEventsMode=mode),
            )
            tqr = TrendsQueryRunner(team=self.team, query=query, user=self.user)
            results = tqr.calculate().results

        assert results[0]["breakdown_value"] == ["350.42"]


class TestPersonsRevenueAnalyticsManagedViewsets(
    TestPersonsRevenueAnalyticsMixin, RevenueAnalyticsManagedViewsetsTestMixin
):
    @parameterized.expand([e.value for e in PersonsOnEventsMode])
    def test_virtual_property_in_trend(self, mode):
        self.setup_events()
        self.team.revenue_analytics_config.events = [
            RevenueAnalyticsEventItem(
                eventName=self.PURCHASE_EVENT_NAME,
                revenueProperty=self.REVENUE_PROPERTY,
                revenueCurrencyProperty=RevenueCurrencyPropertyConfig(static="USD"),
                currencyAwareDecimal=True,
            )
        ]
        self.team.revenue_analytics_config.save()
        self.team.save()

        self.create_and_materialize_viewsets()

        # Breaking down by revenue doesnt make any sense, but this is just proving it works
        with freeze_time(self.QUERY_TIMESTAMP), self.snapshot_select_queries():
            query = TrendsQuery(
                **{
                    "kind": "TrendsQuery",
                    "series": [{"kind": "EventsNode", "name": "$pageview", "event": "$pageview", "math": "total"}],
                    "trendsFilter": {},
                    "breakdownFilter": {"breakdowns": [{"property": "$virt_revenue", "type": "person"}]},
                },
                dateRange=DateRange(date_from="all", date_to=None),
                modifiers=HogQLQueryModifiers(personsOnEventsMode=mode),
            )
            tqr = TrendsQueryRunner(team=self.team, query=query, user=self.user)
            results = tqr.calculate().results

        assert results[0]["breakdown_value"] == ["350.42"]

    def test_query_revenue_analytics_table_events(self):
        self.setup_events_with_subscriptions()
        self.team.revenue_analytics_config.events = [
            RevenueAnalyticsEventItem(
                eventName=self.PURCHASE_EVENT_NAME,
                revenueProperty=self.REVENUE_PROPERTY,
                revenueCurrencyProperty=RevenueCurrencyPropertyConfig(static="USD"),
                currencyAwareDecimal=True,
                subscriptionProperty=self.SUBSCRIPTION_PROPERTY,
                subscriptionDropoffMode=SubscriptionDropoffMode.AFTER_DROPOFF_PERIOD,  # Better default for tests
            )
        ]
        self.team.revenue_analytics_config.save()
        self.team.save()
        self.create_and_materialize_viewsets()

        with freeze_time(self.QUERY_TIMESTAMP), self.snapshot_select_queries():
            results = execute_hogql_query(
                parse_select("SELECT person_id, revenue, mrr FROM persons_revenue_analytics ORDER BY person_id ASC"),
                self.team,
                user=self.user,
                modifiers=self.MODIFIERS,
            )

            # MRR is calculated from recurring events (those with subscription_id)
            self.assertEqual(
                results.results,
                [(UUID(self.PERSON_ID), Decimal("350.84"), Decimal("250.42"))],
            )

    def test_query_revenue_analytics_table_sources(self):
        self.setup_schema_sources()
        self.join.source_table_key = "id"
        self.join.save()
        # Create persons matching customer IDs from the stripe data
        distinct_id_to_person_id: dict[str, str] = {}
        for distinct_id in ["cus_1", "cus_2", "cus_3", "cus_4", "cus_5", "cus_6"]:
            person = _create_person(team_id=self.team.pk, distinct_ids=[distinct_id])
            distinct_id_to_person_id[distinct_id] = person.uuid
        self.create_and_materialize_viewsets()
        with freeze_time(self.QUERY_TIMESTAMP), self.snapshot_select_queries():
            results = execute_hogql_query(
                parse_select(
                    "SELECT person_id, revenue, mrr FROM persons_revenue_analytics ORDER BY mrr DESC, revenue DESC"
                ),
                self.team,
                user=self.user,
                modifiers=self.MODIFIERS,
            )

            self.assertEqual(
                results.results,
                [
                    (distinct_id_to_person_id["cus_3"], Decimal("4161.34422"), Decimal("1546.59444")),
                    (distinct_id_to_person_id["cus_6"], Decimal("2796.37014"), Decimal("1459.02008")),
                    (distinct_id_to_person_id["cus_4"], Decimal("254.12345"), Decimal("83.16695")),
                    (distinct_id_to_person_id["cus_5"], Decimal("1494.0562"), Decimal("43.82703")),
                    (distinct_id_to_person_id["cus_2"], Decimal("482.2158673452"), Decimal("40.8052916666")),
                    (distinct_id_to_person_id["cus_1"], Decimal("283.8496260553"), Decimal("22.9631447238")),
                ],
            )

    def test_get_revenue_for_schema_source_for_id_join(self):
        self.setup_schema_sources()
        self.join.source_table_key = "id"
        self.join.save()

        # These are the 6 IDs inside the CSV files, plus an extra dummy/empty one
        distinct_id_to_person_id: dict[str, str] = {}
        for distinct_id in ["cus_1", "cus_2", "cus_3", "cus_4", "cus_5", "cus_6", "dummy"]:
            person = _create_person(team_id=self.team.pk, distinct_ids=[distinct_id])
            distinct_id_to_person_id[distinct_id] = person.uuid

        self.create_and_materialize_viewsets()
        with freeze_time(self.QUERY_TIMESTAMP), self.snapshot_select_queries():
            queries = [
                "SELECT id, revenue_analytics.revenue from persons order by id asc",
                "SELECT id, $virt_revenue from persons order by id asc",
            ]

            for query in queries:
                response = execute_hogql_query(parse_select(query), self.team, user=self.user, modifiers=self.MODIFIERS)

                self.assertEqual(
                    response.results,
                    [
                        (distinct_id_to_person_id["cus_1"], Decimal("283.8496260553")),
                        (distinct_id_to_person_id["cus_2"], Decimal("482.2158673452")),
                        (distinct_id_to_person_id["cus_3"], Decimal("4161.34422")),
                        (distinct_id_to_person_id["cus_4"], Decimal("254.12345")),
                        (distinct_id_to_person_id["cus_5"], Decimal("1494.0562")),
                        (distinct_id_to_person_id["cus_6"], Decimal("2796.37014")),
                        (distinct_id_to_person_id["dummy"], None),
                    ],
                )

    def test_get_revenue_for_events(self):
        self.setup_events()
        self.team.revenue_analytics_config.events = [
            RevenueAnalyticsEventItem(
                eventName=self.PURCHASE_EVENT_NAME,
                revenueProperty=self.REVENUE_PROPERTY,
                revenueCurrencyProperty=RevenueCurrencyPropertyConfig(static="USD"),
                currencyAwareDecimal=True,
            )
        ]
        self.team.revenue_analytics_config.save()
        self.team.save()
        self.create_and_materialize_viewsets()

        with freeze_time(self.QUERY_TIMESTAMP), self.snapshot_select_queries():
            response = execute_hogql_query(
                parse_select(
                    "select revenue_analytics.revenue, $virt_revenue from persons where id = {id}",
                    placeholders={"id": ast.Constant(value=self.PERSON_ID)},
                ),
                self.team,
                user=self.user,
            )

            self.assertEqual(response.results[0], (Decimal("350.42"), Decimal("350.42")))
