import sys
from datetime import date, datetime
from enum import StrEnum
from typing import Literal, Optional
from uuid import UUID

from pydantic import BaseModel, ConfigDict

type ConstantDataType = Literal[
    "int", "float", "str", "bool", "array", "tuple", "map", "date", "datetime", "uuid", "unknown"
]
type ConstantSupportedPrimitive = int | float | str | bool | date | datetime | UUID | None
type ConstantSupportedData = (
    ConstantSupportedPrimitive | list[ConstantSupportedPrimitive] | tuple[ConstantSupportedPrimitive, ...]
)

# Keywords passed to ClickHouse without transformation
KEYWORDS = ["true", "false", "null"]

# Keywords you can't alias to
RESERVED_KEYWORDS = [*KEYWORDS, "team_id"]

# Limit applied to SELECT statements without LIMIT clause when queried via the API
DEFAULT_RETURNED_ROWS = 100
# Max limit for all SELECT queries, and the default for CSV exports
# Sync with frontend/src/queries/nodes/DataTable/DataTableExport.tsx
MAX_SELECT_RETURNED_ROWS = 50000
# Max limit for retention queries.
MAX_SELECT_RETENTION_LIMIT = 100000  # 100k
# Max limit for heatmaps which don't really need 1 billion so have their own max
MAX_SELECT_HEATMAPS_LIMIT = 1000000  # 1m datapoints
# Max limit for all cohort calculations
MAX_SELECT_COHORT_CALCULATION_LIMIT = 1000000000  # 1b persons
# Max limit for notebook dataframe materialization (the sandbox kernel fetching a whole frame
# over the object-storage frame store). Tier 1 of the rollout ladder in
# products/notebooks/backend/sql_v2_frame_store.md — raised toward the kernel executor's
# _MATERIALIZE_ROW_CAP (2M) on query-log evidence.
MAX_SELECT_NOTEBOOK_MATERIALIZE_LIMIT = 500000  # 500k rows
# Max limit for LLM traces
MAX_SELECT_TRACES_LIMIT_EXPORT = 10000  # 10k traces
# Max limit for PostHog AI queries
MAX_SELECT_POSTHOG_AI_LIMIT = 500  # 500 rows
# Default limit for PostHog AI queries
DEFAULT_POSTHOG_AI_RETURNED_ROWS = 100
# Max amount of memory usage when doing group by before swapping to disk. Only used in certain queries
MAX_BYTES_BEFORE_EXTERNAL_GROUP_BY = 22 * 1024 * 1024 * 1024

CSV_EXPORT_LIMIT = 300000
CSV_EXPORT_BREAKDOWN_LIMIT_INITIAL = 512
CSV_EXPORT_BREAKDOWN_LIMIT_LOW = 64  # The lowest limit we want to go to

BREAKDOWN_VALUES_LIMIT = 25
BREAKDOWN_VALUES_LIMIT_FOR_COUNTRIES = 300
BREAKDOWN_VALUE_MAX_LENGTH = 400

# Event properties that hold a JSON-encoded array of strings. When materialized they are stored
# as a raw String column, so any array function (hasAny/hasAll/...) run against them must first
# extract the array via JSONExtract(..., 'Array(String)'). See posthog/hogql/property.py and the
# PropertySwapper transform, which both apply that wrapping.
EXCEPTION_STRING_ARRAY_PROPERTIES = frozenset(
    {
        "$exception_types",
        "$exception_values",
        "$exception_sources",
        "$exception_functions",
    }
)

type HogQLDialect = Literal["hogql", "clickhouse", "postgres", "duckdb", "mysql", "snowflake", "redshift", "trino"]

# All dialects that compile to an external SQL database queried directly (as opposed to
# ClickHouse / HogQL). MySQL shares the standard-SQL keyword surface (CURRENT_DATE & co.)
# but not Postgres-specific features like PIVOT/UNPIVOT, TRY_CAST, or positional references.
# Redshift is a Postgres fork: it reuses the Postgres-family lazy-table resolution and
# property lowering, then its printer blocks the constructs the Redshift engine can't run.
SQL_TARGET_DIALECTS: frozenset[HogQLDialect] = frozenset({"postgres", "duckdb", "mysql", "redshift", "trino"})

type HogQLParserBackend = Literal["cpp-json", "rust-json", "rust-py"]


class LimitContext(StrEnum):
    QUERY = "query"
    QUERY_ASYNC = "query_async"
    EXPORT = "export"
    COHORT_CALCULATION = "cohort_calculation"
    HEATMAPS = "heatmaps"
    NOTEBOOK_MATERIALIZE = "notebook_materialize"
    SAVED_QUERY = "saved_query"
    RETENTION = "retention"
    POSTHOG_AI = "posthog_ai"


def get_max_limit_for_context(limit_context: LimitContext) -> int:
    if limit_context in (
        LimitContext.QUERY,
        LimitContext.QUERY_ASYNC,
    ):
        return MAX_SELECT_RETURNED_ROWS  # 50k
    elif limit_context == LimitContext.EXPORT:
        return CSV_EXPORT_LIMIT
    elif limit_context == LimitContext.HEATMAPS:
        return MAX_SELECT_HEATMAPS_LIMIT  # 1M
    elif limit_context == LimitContext.COHORT_CALCULATION:
        return MAX_SELECT_COHORT_CALCULATION_LIMIT  # 1b
    elif limit_context == LimitContext.NOTEBOOK_MATERIALIZE:
        return MAX_SELECT_NOTEBOOK_MATERIALIZE_LIMIT  # 500k
    elif limit_context == LimitContext.RETENTION:
        return MAX_SELECT_RETENTION_LIMIT  # 100k
    elif limit_context == LimitContext.SAVED_QUERY:
        return sys.maxsize  # Max python int
    elif limit_context == LimitContext.POSTHOG_AI:
        return MAX_SELECT_POSTHOG_AI_LIMIT  # 500
    else:
        raise ValueError(f"Unexpected LimitContext value: {limit_context}")


def get_default_limit_for_context(limit_context: LimitContext) -> int:
    """Limit used if no limit is provided"""
    if limit_context == LimitContext.EXPORT:
        return CSV_EXPORT_LIMIT
    elif limit_context in (LimitContext.QUERY, LimitContext.QUERY_ASYNC):
        return DEFAULT_RETURNED_ROWS  # 100
    elif limit_context == LimitContext.POSTHOG_AI:
        return DEFAULT_POSTHOG_AI_RETURNED_ROWS  # 100
    elif limit_context == LimitContext.HEATMAPS:
        return MAX_SELECT_HEATMAPS_LIMIT  # 1M
    elif limit_context == LimitContext.COHORT_CALCULATION:
        return MAX_SELECT_COHORT_CALCULATION_LIMIT  # 1b
    elif limit_context == LimitContext.NOTEBOOK_MATERIALIZE:
        return MAX_SELECT_NOTEBOOK_MATERIALIZE_LIMIT  # 500k
    elif limit_context == LimitContext.SAVED_QUERY:
        return sys.maxsize  # Max python int
    else:
        raise ValueError(f"Unexpected LimitContext value: {limit_context}")


def get_breakdown_limit_for_context(limit_context: LimitContext) -> int:
    """Limit used for breakdowns"""
    if limit_context == LimitContext.EXPORT:
        return CSV_EXPORT_BREAKDOWN_LIMIT_INITIAL

    return BREAKDOWN_VALUES_LIMIT


# Settings applied at the SELECT level
class HogQLQuerySettings(BaseModel):
    model_config = ConfigDict(extra="forbid")
    optimize_aggregation_in_order: Optional[bool] = None
    date_time_output_format: Optional[str] = None
    date_time_input_format: Optional[str] = None
    join_algorithm: Optional[str] = None
    grace_hash_join_initial_buckets: Optional[int] = None
    force_data_skipping_indices: Optional[list[str]] = None
    load_balancing: Optional[str] = None
    format_csv_allow_double_quotes: Optional[bool] = None
    optimize_skip_unused_shards: Optional[bool] = None
    read_overflow_mode: Optional[str] = None
    max_bytes_to_read: Optional[int] = None


# Settings applied on top of all HogQL queries.
class HogQLGlobalSettings(HogQLQuerySettings):
    model_config = ConfigDict(extra="forbid")
    readonly: Optional[int] = 2
    max_execution_time: Optional[int] = 60
    # None inherits the cluster profile's overflow behavior. Set "throw" when a partial
    # result is worse than an error (e.g. sampling queries whose output feeds further
    # computation), or "break" to accept partial results on timeout.
    timeout_overflow_mode: Optional[str] = None
    max_memory_usage: Optional[int] = None  # default value coming from cloud config
    max_threads: Optional[int] = None
    allow_experimental_object_type: Optional[bool] = True
    max_ast_elements: Optional[int] = 4_000_000  # default value 50000
    max_expanded_ast_elements: Optional[int] = 4_000_000
    max_bytes_before_external_group_by: Optional[int] = 0  # default value means we don't swap ordering by to disk
    enable_analyzer: Optional[bool] = None
    transform_null_in: Optional[bool] = True
    # A bugfix workaround that stops clauses that look like
    # `or(event = '1', event = '2', event = '3')` from being optimized into `event IN ('1', '2', '3')`
    # which can cause an error like `Not found column if(in(__table1.event, __set_String_14734461331367945596_10185115430245904968), 1_UInt8, 0_UInt8) in block.
    # There are only columns: if(nullIn(__table1.event, __set_String_14734461331367945596_10185115430245904968), 1_UInt8, 0_UInt8)
    # https://github.com/ClickHouse/ClickHouse/issues/64487
    optimize_min_equality_disjunction_chain_length: Optional[int] = 4294967295
    # A bugfix workaround for a distributed-planner crash under the new analyzer. ClickHouse rewrites
    # `max(if(cond, <const>, NULL))` into `maxIf(<const>, cond)` (and similar for sum/avg/min, count(DISTINCT ...)),
    # but the constant in the non-NULL branch is constant-folded to a different type on the initiator
    # (`_CAST(1_UInt8, 'Nullable(UInt8)')`) than on the shards (`_CAST(1_Nullable(UInt8), 'Nullable(UInt8)')`),
    # so distributed column matching fails with `Cannot find column maxIf(...)` (THERE_IS_NO_COLUMN).
    # Disabling the rewrite avoids it with no perf cost (the rewrite benchmarks ~3-4% slower anyway).
    # https://github.com/ClickHouse/ClickHouse/issues/82941
    optimize_rewrite_aggregate_function_with_if: Optional[bool] = False
    # The mirror image of the setting above, for `and(event != '1', event != '2', event != '3')` being optimized into
    # `event NOT IN ('1', '2', '3')`. With transform_null_in=1 the new analyzer rewrites the synthesized notIn to
    # notNullIn inconsistently between the shard (producing) and initiator (consuming) headers of a distributed query,
    # so column matching fails with `Cannot find column minIf(..., notIn(...)) in source stream, there are only columns:
    # [minIf(..., notNullIn(...))]` (THERE_IS_NO_COLUMN). Same bug class as #64487; disabling the rewrite avoids it
    # without touching NULL semantics (unlike transform_null_in).
    optimize_min_inequality_conjunction_chain_length: Optional[int] = 4294967295
    # experimental support for nonequal joins
    allow_experimental_join_condition: Optional[bool] = True
    preferred_block_size_bytes: Optional[int] = None
    use_hive_partitioning: Optional[int] = 0
    # Serve repeated scans of the same parts from the server's uncompressed block cache
    # instead of re-decompressing. Off by default (None): only opt in for interactive
    # queries that re-read the same narrow data repeatedly, and mind that scans larger
    # than the two merge_tree_*_to_use_cache guards below bypass the cache entirely.
    use_uncompressed_cache: Optional[bool] = None
    merge_tree_max_rows_to_use_cache: Optional[int] = None
    merge_tree_max_bytes_to_use_cache: Optional[int] = None


def get_default_hogql_global_settings(
    team_id: int | None = None,
    base: HogQLGlobalSettings | None = None,
) -> HogQLGlobalSettings:
    return base.model_copy(deep=True) if base is not None else HogQLGlobalSettings()
