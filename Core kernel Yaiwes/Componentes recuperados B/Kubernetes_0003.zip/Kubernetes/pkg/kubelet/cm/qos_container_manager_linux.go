/*
Copyright 2017 The Kubernetes Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package cm

import (
	"context"
	"fmt"
	"strconv"
	"strings"
	"sync"
	"time"

	v1 "k8s.io/api/core/v1"
	"k8s.io/klog/v2"

	"k8s.io/apimachinery/pkg/util/wait"

	units "github.com/docker/go-units"
	libcontainercgroups "github.com/opencontainers/cgroups"
	utilfeature "k8s.io/apiserver/pkg/util/feature"

	"k8s.io/component-helpers/resource"
	v1qos "k8s.io/kubernetes/pkg/apis/core/v1/helper/qos"
	kubefeatures "k8s.io/kubernetes/pkg/features"
	kubeletconfig "k8s.io/kubernetes/pkg/kubelet/apis/config"
	kubeletmetrics "k8s.io/kubernetes/pkg/kubelet/metrics"
)

const (
	// how often the qos cgroup manager will perform periodic update
	// of the qos level cgroup resource constraints
	periodicQOSCgroupUpdateInterval = 1 * time.Minute
)

type QOSContainerManager interface {
	Start(context.Context, func() v1.ResourceList, ActivePodsFunc) error
	GetQOSContainersInfo() QOSContainersInfo
	UpdateCgroups(logger klog.Logger) error
}

type qosContainerManagerImpl struct {
	sync.Mutex
	qosContainersInfo       QOSContainersInfo
	subsystems              *CgroupSubsystems
	cgroupManager           CgroupManager
	activePods              ActivePodsFunc
	getNodeAllocatable      func() v1.ResourceList
	cgroupRoot              CgroupName
	qosReserved             map[v1.ResourceName]int64
	memoryReservationPolicy kubeletconfig.MemoryReservationPolicy
}

func NewQOSContainerManager(subsystems *CgroupSubsystems, cgroupRoot CgroupName, nodeConfig NodeConfig, cgroupManager CgroupManager) (QOSContainerManager, error) {
	if !nodeConfig.CgroupsPerQOS {
		return &qosContainerManagerNoop{
			cgroupRoot: cgroupRoot,
		}, nil
	}

	return &qosContainerManagerImpl{
		subsystems:              subsystems,
		cgroupManager:           cgroupManager,
		cgroupRoot:              cgroupRoot,
		qosReserved:             nodeConfig.QOSReserved,
		memoryReservationPolicy: nodeConfig.MemoryReservationPolicy,
	}, nil
}

func (m *qosContainerManagerImpl) GetQOSContainersInfo() QOSContainersInfo {
	return m.qosContainersInfo
}

func (m *qosContainerManagerImpl) Start(ctx context.Context, getNodeAllocatable func() v1.ResourceList, activePods ActivePodsFunc) error {
	logger := klog.FromContext(ctx)
	cm := m.cgroupManager
	rootContainer := m.cgroupRoot

	if err := cm.Validate(rootContainer); err != nil {
		return fmt.Errorf("error validating root container %v : %w", rootContainer, err)
	}

	// Top level for Qos containers are created only for Burstable
	// and Best Effort classes
	qosClasses := map[v1.PodQOSClass]CgroupName{
		v1.PodQOSBurstable:  NewCgroupName(rootContainer, strings.ToLower(string(v1.PodQOSBurstable))),
		v1.PodQOSBestEffort: NewCgroupName(rootContainer, strings.ToLower(string(v1.PodQOSBestEffort))),
	}

	// Create containers for both qos classes
	for qosClass, containerName := range qosClasses {
		resourceParameters := &ResourceConfig{}
		// the BestEffort QoS class has a statically configured minShares value
		if qosClass == v1.PodQOSBestEffort {
			minShares := uint64(MinShares)
			resourceParameters.CPUShares = &minShares
		}

		// Reset stale memory protection on startup when MemoryQoS is off or
		// policy is None. The periodic loop only runs for TieredReservation
		// (where values change with pod churn); all other transitions are
		// config changes that require a kubelet restart, so startup is
		// sufficient.
		if libcontainercgroups.IsCgroup2UnifiedMode() {
			if !utilfeature.DefaultFeatureGate.Enabled(kubefeatures.MemoryQoS) ||
				m.memoryReservationPolicy != kubeletconfig.TieredReservationMemoryReservationPolicy {
				if qosClass == v1.PodQOSBurstable {
					resourceParameters.Unified = map[string]string{Cgroup2MemoryLow: "0"}
				}
			}
		}

		// containerConfig object stores the cgroup specifications
		containerConfig := &CgroupConfig{
			Name:               containerName,
			ResourceParameters: resourceParameters,
		}

		// for each enumerated huge page size, the qos tiers are unbounded
		m.setHugePagesUnbounded(containerConfig)

		// check if it exists
		if !cm.Exists(containerName) {
			if err := cm.Create(logger, containerConfig); err != nil {
				return fmt.Errorf("failed to create top level %v QOS cgroup : %v", qosClass, err)
			}
		} else {
			// to ensure we actually have the right state, we update the config on startup
			if err := cm.Update(logger, containerConfig); err != nil {
				return fmt.Errorf("failed to update top level %v QOS cgroup : %v", qosClass, err)
			}
		}
	}
	// Reset stale memory protection on the root cgroup (kubepods.slice) at
	// startup, which the loop above
	// does not cover.
	if libcontainercgroups.IsCgroup2UnifiedMode() {
		if !utilfeature.DefaultFeatureGate.Enabled(kubefeatures.MemoryQoS) ||
			m.memoryReservationPolicy != kubeletconfig.TieredReservationMemoryReservationPolicy {
			rootConfig := &CgroupConfig{
				Name: rootContainer,
				ResourceParameters: &ResourceConfig{
					Unified: map[string]string{
						Cgroup2MemoryMin: "0",
						Cgroup2MemoryLow: "0",
					},
				},
			}
			if err := cm.Update(logger, rootConfig); err != nil {
				logger.Error(err, "Failed to reset memory protection on root cgroup")
			}
		}
	}

	// Store the top level qos container names
	m.qosContainersInfo = QOSContainersInfo{
		Guaranteed: rootContainer,
		Burstable:  qosClasses[v1.PodQOSBurstable],
		BestEffort: qosClasses[v1.PodQOSBestEffort],
	}
	m.getNodeAllocatable = getNodeAllocatable
	m.activePods = activePods

	// update qos cgroup tiers on startup and in periodic intervals
	// to ensure desired state is in sync with actual state.
	go wait.Until(func() {
		err := m.UpdateCgroups(logger)
		if err != nil {
			logger.Info("Failed to reserve QoS requests", "err", err)
		}
	}, periodicQOSCgroupUpdateInterval, wait.NeverStop)

	return nil
}

// setHugePagesUnbounded ensures hugetlb is effectively unbounded
func (m *qosContainerManagerImpl) setHugePagesUnbounded(cgroupConfig *CgroupConfig) error {
	hugePageLimit := map[int64]int64{}
	for _, pageSize := range libcontainercgroups.HugePageSizes() {
		pageSizeBytes, err := units.RAMInBytes(pageSize)
		if err != nil {
			return err
		}
		hugePageLimit[pageSizeBytes] = int64(1 << 62)
	}
	cgroupConfig.ResourceParameters.HugePageLimit = hugePageLimit
	return nil
}

func (m *qosContainerManagerImpl) setHugePagesConfig(configs map[v1.PodQOSClass]*CgroupConfig) error {
	for _, v := range configs {
		if err := m.setHugePagesUnbounded(v); err != nil {
			return err
		}
	}
	return nil
}

func (m *qosContainerManagerImpl) setCPUCgroupConfig(configs map[v1.PodQOSClass]*CgroupConfig) error {
	pods := m.activePods()
	burstablePodCPURequest := int64(0)
	reuseReqs := make(v1.ResourceList, 4)
	for i := range pods {
		pod := pods[i]
		qosClass := v1qos.GetPodQOS(pod)
		if qosClass != v1.PodQOSBurstable {
			// we only care about the burstable qos tier
			continue
		}
		draNodeAllocatableEnabled := utilfeature.DefaultFeatureGate.Enabled(kubefeatures.DRANodeAllocatableResources)
		req := resource.PodRequests(pod, resource.PodResourcesOptions{
			Reuse: reuseReqs,
			// SkipPodLevelResources is set to false when PodLevelResources feature is enabled.
			SkipPodLevelResources:                    !utilfeature.DefaultFeatureGate.Enabled(kubefeatures.PodLevelResources),
			UseDRANodeAllocatableResourceClaimStatus: draNodeAllocatableEnabled,
		})
		if request, found := req[v1.ResourceCPU]; found {
			burstablePodCPURequest += request.MilliValue()
		}
	}

	// make sure best effort is always 2 shares
	bestEffortCPUShares := uint64(MinShares)
	configs[v1.PodQOSBestEffort].ResourceParameters.CPUShares = &bestEffortCPUShares

	// set burstable shares based on current observe state
	burstableCPUShares := MilliCPUToShares(burstablePodCPURequest)
	configs[v1.PodQOSBurstable].ResourceParameters.CPUShares = &burstableCPUShares
	return nil
}

// getQoSMemoryRequests sums and returns the memory request of all pods for
// guaranteed and burstable qos classes.
func (m *qosContainerManagerImpl) getQoSMemoryRequests() map[v1.PodQOSClass]int64 {
	qosMemoryRequests := map[v1.PodQOSClass]int64{
		v1.PodQOSGuaranteed: 0,
		v1.PodQOSBurstable:  0,
	}

	// Sum the pod limits for pods in each QOS class
	pods := m.activePods()
	reuseReqs := make(v1.ResourceList, 4)
	for _, pod := range pods {
		podMemoryRequest := int64(0)
		qosClass := v1qos.GetPodQOS(pod)
		if qosClass == v1.PodQOSBestEffort {
			// limits are not set for Best Effort pods
			continue
		}
		draNodeAllocatableEnabled := utilfeature.DefaultFeatureGate.Enabled(kubefeatures.DRANodeAllocatableResources)
		req := resource.PodRequests(pod, resource.PodResourcesOptions{
			Reuse:                                    reuseReqs,
			UseDRANodeAllocatableResourceClaimStatus: draNodeAllocatableEnabled,
		})
		if request, found := req[v1.ResourceMemory]; found {
			podMemoryRequest += request.Value()
		}
		qosMemoryRequests[qosClass] += podMemoryRequest
	}

	return qosMemoryRequests
}

// setMemoryReserve sums the memory limits of all pods in a QOS class,
// calculates QOS class memory limits, and set those limits in the
// CgroupConfig for each QOS class.
func (m *qosContainerManagerImpl) setMemoryReserve(logger klog.Logger, configs map[v1.PodQOSClass]*CgroupConfig, percentReserve int64) {
	qosMemoryRequests := m.getQoSMemoryRequests()

	resources := m.getNodeAllocatable()
	allocatableResource, ok := resources[v1.ResourceMemory]
	if !ok {
		logger.V(2).Info("Allocatable memory value could not be determined, not setting QoS memory limits")
		return
	}
	allocatable := allocatableResource.Value()
	if allocatable == 0 {
		logger.V(2).Info("Allocatable memory reported as 0, might be in standalone mode, not setting QoS memory limits")
		return
	}

	for qos, limits := range qosMemoryRequests {
		logger.V(2).Info("QoS pod memory limit", "qos", qos, "limits", limits, "percentReserve", percentReserve)
	}

	// Calculate QOS memory limits
	burstableLimit := allocatable - (qosMemoryRequests[v1.PodQOSGuaranteed] * percentReserve / 100)
	bestEffortLimit := burstableLimit - (qosMemoryRequests[v1.PodQOSBurstable] * percentReserve / 100)
	configs[v1.PodQOSBurstable].ResourceParameters.Memory = &burstableLimit
	configs[v1.PodQOSBestEffort].ResourceParameters.Memory = &bestEffortLimit
}

// retrySetMemoryReserve checks for any QoS cgroups over the limit
// that was attempted to be set in the first Update() and adjusts
// their memory limit to the usage to prevent further growth.
func (m *qosContainerManagerImpl) retrySetMemoryReserve(logger klog.Logger, configs map[v1.PodQOSClass]*CgroupConfig, percentReserve int64) {
	// Unreclaimable memory usage may already exceeded the desired limit
	// Attempt to set the limit near the current usage to put pressure
	// on the cgroup and prevent further growth.
	for qos, config := range configs {
		usage, err := m.cgroupManager.MemoryUsage(config.Name)
		if err != nil {
			logger.V(2).Info("Failed to get resource stats", "err", err)
			return
		}

		// Because there is no good way to determine of the original Update()
		// on the memory resource was successful, we determine failure of the
		// first attempt by checking if the usage is above the limit we attempt
		// to set.  If it is, we assume the first attempt to set the limit failed
		// and try again setting the limit to the usage.  Otherwise we leave
		// the CgroupConfig as is.
		if configs[qos].ResourceParameters.Memory != nil && usage > *configs[qos].ResourceParameters.Memory {
			configs[qos].ResourceParameters.Memory = &usage
		}
	}
}

// setMemoryQoS sets cgroup v2 memory protection for QoS-class cgroups.
// Guaranteed pods get memory.min (hard protection), Burstable pods get memory.low (soft protection).
func (m *qosContainerManagerImpl) setMemoryQoS(logger klog.Logger, configs map[v1.PodQOSClass]*CgroupConfig) {
	setUnified := func(qos v1.PodQOSClass, key string, value int64) {
		if configs[qos].ResourceParameters.Unified == nil {
			configs[qos].ResourceParameters.Unified = make(map[string]string)
		}
		configs[qos].ResourceParameters.Unified[key] = strconv.FormatInt(value, 10)
		logger.V(4).Info("MemoryQoS config for qos", "qos", qos, "key", key, "value", value)
	}

	// In production the only caller already gates on
	// memoryReservationPolicy == TieredReservation, so this branch is
	// unreachable. Keep this for unit-test coverage.
	if m.memoryReservationPolicy != kubeletconfig.TieredReservationMemoryReservationPolicy {
		setUnified(v1.PodQOSGuaranteed, Cgroup2MemoryMin, 0)
		setUnified(v1.PodQOSGuaranteed, Cgroup2MemoryLow, 0)
		setUnified(v1.PodQOSBurstable, Cgroup2MemoryLow, 0)
		kubeletmetrics.MemoryQoSNodeMemoryMinBytes.Set(0)
		kubeletmetrics.MemoryQoSNodeMemoryLowBytes.Set(0)
		return
	}

	qosMemoryRequests := m.getQoSMemoryRequests()

	burstableRequests := qosMemoryRequests[v1.PodQOSBurstable]
	guaranteedRequests := qosMemoryRequests[v1.PodQOSGuaranteed]

	kubeletmetrics.MemoryQoSNodeMemoryMinBytes.Set(float64(guaranteedRequests))
	kubeletmetrics.MemoryQoSNodeMemoryLowBytes.Set(float64(burstableRequests))

	// Root (kubepods.slice): ancestor coverage for both protection chains.
	// v1.PodQOSGuaranteed is the map key for the root cgroup, not per-pod config.
	setUnified(v1.PodQOSGuaranteed, Cgroup2MemoryMin, guaranteedRequests+burstableRequests)
	setUnified(v1.PodQOSGuaranteed, Cgroup2MemoryLow, burstableRequests)

	setUnified(v1.PodQOSBurstable, Cgroup2MemoryLow, burstableRequests)
}

func (m *qosContainerManagerImpl) UpdateCgroups(logger klog.Logger) error {
	m.Lock()
	defer m.Unlock()

	qosConfigs := map[v1.PodQOSClass]*CgroupConfig{
		v1.PodQOSGuaranteed: {
			Name:               m.qosContainersInfo.Guaranteed,
			ResourceParameters: &ResourceConfig{},
		},
		v1.PodQOSBurstable: {
			Name:               m.qosContainersInfo.Burstable,
			ResourceParameters: &ResourceConfig{},
		},
		v1.PodQOSBestEffort: {
			Name:               m.qosContainersInfo.BestEffort,
			ResourceParameters: &ResourceConfig{},
		},
	}

	// update the qos level cgroup settings for cpu shares
	if err := m.setCPUCgroupConfig(qosConfigs); err != nil {
		return err
	}

	// update the qos level cgroup settings for huge pages (ensure they remain unbounded)
	if err := m.setHugePagesConfig(qosConfigs); err != nil {
		return err
	}

	// Update cgroup v2 memory.min/memory.low periodically only when
	// TieredReservation policy is active, since the values change as pods
	// come and go. The None policy and feature-gate-disabled rollback cases
	// are handled at startup to avoid unnecessary systemd SetUnitProperties
	// calls that reset unrelated cgroup properties as a side effect.
	if utilfeature.DefaultFeatureGate.Enabled(kubefeatures.MemoryQoS) && libcontainercgroups.IsCgroup2UnifiedMode() &&
		m.memoryReservationPolicy == kubeletconfig.TieredReservationMemoryReservationPolicy {
		m.setMemoryQoS(logger, qosConfigs)
	}

	if utilfeature.DefaultFeatureGate.Enabled(kubefeatures.QOSReserved) {
		for resource, percentReserve := range m.qosReserved {
			switch resource {
			case v1.ResourceMemory:
				m.setMemoryReserve(logger, qosConfigs, percentReserve)
			}
		}

		updateSuccess := true
		for _, config := range qosConfigs {
			err := m.cgroupManager.Update(logger, config)
			if err != nil {
				updateSuccess = false
			}
		}
		if updateSuccess {
			logger.V(4).Info("Updated QoS cgroup configuration")
			return nil
		}

		// If the resource can adjust the ResourceConfig to increase likelihood of
		// success, call the adjustment function here.  Otherwise, the Update() will
		// be called again with the same values.
		for resource, percentReserve := range m.qosReserved {
			switch resource {
			case v1.ResourceMemory:
				m.retrySetMemoryReserve(logger, qosConfigs, percentReserve)
			}
		}
	}

	for _, config := range qosConfigs {
		err := m.cgroupManager.Update(logger, config)
		if err != nil {
			logger.Error(err, "Failed to update QoS cgroup configuration")
			return err
		}
	}

	logger.V(4).Info("Updated QoS cgroup configuration")
	return nil
}

type qosContainerManagerNoop struct {
	cgroupRoot CgroupName
}

var _ QOSContainerManager = &qosContainerManagerNoop{}

func (m *qosContainerManagerNoop) GetQOSContainersInfo() QOSContainersInfo {
	return QOSContainersInfo{}
}

func (m *qosContainerManagerNoop) Start(_ context.Context, _ func() v1.ResourceList, _ ActivePodsFunc) error {
	return nil
}

func (m *qosContainerManagerNoop) UpdateCgroups(_ klog.Logger) error {
	return nil
}
