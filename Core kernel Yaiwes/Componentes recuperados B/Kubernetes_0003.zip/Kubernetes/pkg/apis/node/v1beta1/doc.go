/*
Copyright 2019 The Kubernetes Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

// +k8s:conversion-gen=k8s.io/kubernetes/pkg/apis/node
// +k8s:conversion-gen-external-types=k8s.io/api/node/v1beta1

// Default generation is explicitly disabled to preserve existing behavior.
// If enabled corev1's SetDefaults_ResourceList (defaults.go)
// will default RuntimeClass's overhead.podFixed field.
// +k8s:defaulter-gen=false

// +k8s:validation-gen=TypesWithField=TypeMeta
// +k8s:validation-gen-input=k8s.io/api/node/v1beta1

// +groupName=node.k8s.io

package v1beta1
