<script lang="ts" setup>
import { computed, nextTick, onBeforeUnmount, onMounted, ref, watch } from 'vue';
import { truncate } from '@n8n/utils/string/truncate';
import { useI18n } from '@n8n/i18n';
import { N8nBadge, N8nHoverCard, N8nIconButton } from '@n8n/design-system';
import { convertToDisplayDate } from '@/app/utils/formatters/dateFormatter';
import type { CSSProperties } from 'vue';
import type { IdleRange, TimelineItem } from '../session-timeline.types';
import {
	executionErrorLabel,
	executionErrorMessage,
	formatDuration,
	hitlRequestLabelKey,
	hitlTimelineName,
	isErroredTimelineItem,
	isSubAgentTimelineItem,
	matchesTimelineFilters,
	timelineItemStatus,
} from '../session-timeline.utils';
import { chartBlockStyleForItem } from '../session-timeline.styles';
import { formatToolNameForDisplay, resolveToolNameForDisplay } from '../utils/toolDisplayName';
import SessionTimelinePill from './SessionTimelinePill.vue';

const props = defineProps<{
	items: TimelineItem[];
	idleRanges: IdleRange[];
	sessionStart: number;
	sessionEnd: number;
	visibleKinds: Set<string>;
	selectedIndex: number | null;
}>();

const SCROLL_PADDING = 48;

const emit = defineEmits<{ select: [index: number] }>();

type Segment =
	| { kind: 'event'; item: TimelineItem; index: number; duration: number }
	| { kind: 'idle'; range: IdleRange };

type PopoverTarget = { segment: Segment; reference: HTMLElement };

const i18n = useI18n();
const carouselRef = ref<HTMLElement | null>(null);
const chartRef = ref<HTMLElement | null>(null);
const hasOverflow = ref(false);
const canScrollLeft = ref(false);
const canScrollRight = ref(false);
const activePopover = ref<PopoverTarget | null>(null);
const popoverOpen = ref(false);
const activePopoverStatus = computed(() => {
	const segment = activePopover.value?.segment;
	return segment?.kind === 'event' ? timelineItemStatus(segment.item) : undefined;
});

const INSTANT_MS = 100;
const POPOVER_SHOW_DELAY_MS = 300;
let showPopoverTimer: ReturnType<typeof setTimeout> | null = null;
let resizeObserver: ResizeObserver | null = null;

let hoveredPopover: PopoverTarget | null = null;
let focusedPopover: PopoverTarget | null = null;

const segments = computed<Segment[]>(() => {
	const out: Segment[] = [];
	const idles = [...props.idleRanges].sort((a, b) => a.start - b.start);
	let idleIdx = 0;
	for (let i = 0; i < props.items.length; i++) {
		const item = props.items[i];
		while (idleIdx < idles.length && idles[idleIdx].start <= item.timestamp) {
			out.push({ kind: 'idle', range: idles[idleIdx] });
			idleIdx++;
		}
		const duration = item.endTimestamp ? item.endTimestamp - item.timestamp : INSTANT_MS;
		out.push({ kind: 'event', item, index: i, duration });
	}
	while (idleIdx < idles.length) {
		out.push({ kind: 'idle', range: idles[idleIdx] });
		idleIdx++;
	}
	return out;
});

function isDimmed(item: TimelineItem): boolean {
	return !matchesTimelineFilters(item, props.visibleKinds);
}

function cellStyle(seg: Segment): Record<string, string> {
	if (seg.kind === 'idle') return { flex: '0 0 56px' };
	// flex-shrink: 1 lets cells contract when total min-widths exceed the chart width.
	return { flex: `${Math.max(seg.duration, 1)} 1 0` };
}

function eventStyle(item: TimelineItem): CSSProperties {
	const style: CSSProperties = chartBlockStyleForItem(item);
	if (isDimmed(item)) {
		style.opacity = '0.15';
		style.pointerEvents = 'none';
	}
	return style;
}

function popoverPillKind(item: TimelineItem) {
	return isSubAgentTimelineItem(item) ? 'subagent' : item.kind;
}

function popoverLabel(item: TimelineItem): string {
	if (isSubAgentTimelineItem(item)) return i18n.baseText('agentSessions.timeline.subAgent');
	switch (item.kind) {
		case 'user':
			return i18n.baseText('agentSessions.timeline.user');
		case 'agent':
			return i18n.baseText('agentSessions.timeline.agent');
		case 'tool':
			return i18n.baseText('agentSessions.timeline.tool');
		case 'workflow':
			return i18n.baseText('agentSessions.timeline.workflow');
		case 'node':
			return i18n.baseText('agentSessions.timeline.node');
		case 'execution-error':
			return executionErrorLabel(item, i18n);
		case 'suspension':
			return i18n.baseText(hitlRequestLabelKey(item.hitlRequestType));
		case 'hitl-response':
			return i18n.baseText('agentSessions.timeline.hitlResponse');
		default:
			return '';
	}
}

function popoverName(item: TimelineItem): string {
	if (isSubAgentTimelineItem(item)) {
		return item.subAgentName ?? formatToolNameForDisplay(item.toolName);
	}
	switch (item.kind) {
		case 'user':
		case 'agent':
			return truncate(item.content ?? '', 80);
		case 'tool': {
			return resolveToolNameForDisplay(item.toolName, i18n);
		}
		case 'workflow':
			return item.workflowName ?? formatToolNameForDisplay(item.toolName);
		case 'node':
			return item.nodeDisplayName ?? formatToolNameForDisplay(item.toolName);
		case 'execution-error':
			return executionErrorMessage(item, i18n);
		case 'suspension':
		case 'hitl-response':
			return hitlTimelineName(item, i18n);
		default:
			return '';
	}
}

function statusLabel(item: TimelineItem): string | undefined {
	const status = timelineItemStatus(item);
	return status ? i18n.baseText(status.labelKey) : undefined;
}

/**
 * Real-event duration for the popover. Returns empty when the item has no
 * `endTimestamp` greater than `timestamp` — point events (user/agent text,
 * memory, suspension) and incomplete tool calls. The chart's `seg.duration`
 * applies a synthetic `INSTANT_MS` floor so point events get a visible block;
 * we deliberately don't use that here, otherwise every popover would read
 * "100ms".
 */
function popoverDuration(item: TimelineItem): string {
	if (!item.endTimestamp || item.endTimestamp <= item.timestamp) return '';
	return formatDuration(item.endTimestamp - item.timestamp);
}

function idleDuration(range: IdleRange): string {
	return formatDuration(range.end - range.start);
}

function popoverTime(item: TimelineItem): string {
	if (!item.timestamp) return '';
	return convertToDisplayDate(new Date(item.timestamp).toISOString()).time;
}

function blockAriaLabel(item: TimelineItem): string {
	return [popoverLabel(item), popoverName(item), statusLabel(item)]
		.filter((part): part is string => Boolean(part))
		.join(', ');
}

function onClick(index: number, item: TimelineItem): void {
	if (isDimmed(item)) return;
	emit('select', index);
}

function showPopover(segment: Segment, event: MouseEvent | FocusEvent): void {
	if (!(event.currentTarget instanceof HTMLElement)) return;
	const target = { segment, reference: event.currentTarget };
	if (event.type === 'focus') {
		focusedPopover = target;
	} else {
		hoveredPopover = target;
	}
	clearShowPopoverTimer();
	showPopoverTimer = setTimeout(() => {
		activePopover.value = target;
		popoverOpen.value = true;
	}, POPOVER_SHOW_DELAY_MS);
}

function clearShowPopoverTimer(): void {
	if (!showPopoverTimer) return;
	clearTimeout(showPopoverTimer);
	showPopoverTimer = null;
}

function scrollSelectedIntoView(): void {
	const selectedIndex = props.selectedIndex;
	const chart = chartRef.value;
	if (selectedIndex === null || !chart) return;

	const selectedBlock = chart.querySelector<HTMLElement>(
		`[data-timeline-index="${selectedIndex}"]`,
	);
	if (!selectedBlock) return;

	const blockLeft = selectedBlock.offsetLeft;
	const blockRight = blockLeft + selectedBlock.offsetWidth;
	const viewportLeft = chart.scrollLeft;
	const viewportRight = viewportLeft + chart.clientWidth;

	if (blockLeft - SCROLL_PADDING < viewportLeft) {
		chart.scrollLeft = Math.max(0, blockLeft - SCROLL_PADDING);
	} else if (blockRight + SCROLL_PADDING > viewportRight) {
		chart.scrollLeft = blockRight + SCROLL_PADDING - chart.clientWidth;
	}
}

function updateScrollState(): void {
	const chart = chartRef.value;
	if (!chart) {
		hasOverflow.value = false;
		canScrollLeft.value = false;
		canScrollRight.value = false;
		return;
	}

	const availableWidth = carouselRef.value?.clientWidth ?? chart.clientWidth;
	const maxScrollLeft = Math.max(0, chart.scrollWidth - chart.clientWidth);
	hasOverflow.value = chart.scrollWidth - availableWidth > 1;
	canScrollLeft.value = hasOverflow.value && chart.scrollLeft > 1;
	canScrollRight.value = hasOverflow.value && chart.scrollLeft < maxScrollLeft - 1;
}

function scrollChart(direction: -1 | 1): void {
	const chart = chartRef.value;
	if (!chart) return;

	const distance = Math.max(chart.clientWidth - SCROLL_PADDING, SCROLL_PADDING);
	const behavior = window.matchMedia('(prefers-reduced-motion: reduce)').matches
		? 'auto'
		: 'smooth';
	chart.scrollBy({ left: direction * distance, top: 0, behavior });
}

function hidePopover(event: MouseEvent | FocusEvent): void {
	if (event.type === 'blur') {
		focusedPopover = null;
	} else {
		hoveredPopover = null;
	}
	clearShowPopoverTimer();
	const remainingTarget = focusedPopover ?? hoveredPopover;
	if (remainingTarget) {
		activePopover.value = remainingTarget;
		popoverOpen.value = true;
		return;
	}
	popoverOpen.value = false;
	activePopover.value = null;
}

watch(
	() => props.selectedIndex,
	() => {
		void nextTick(scrollSelectedIntoView);
	},
);

watch(segments, () => {
	void nextTick(updateScrollState);
});

onMounted(() => {
	const chart = chartRef.value;
	if (!chart) return;

	chart.addEventListener('scroll', updateScrollState, { passive: true });
	resizeObserver = new ResizeObserver(updateScrollState);
	resizeObserver.observe(chart);
	if (carouselRef.value) resizeObserver.observe(carouselRef.value);
	updateScrollState();
});

onBeforeUnmount(() => {
	clearShowPopoverTimer();
	chartRef.value?.removeEventListener('scroll', updateScrollState);
	resizeObserver?.disconnect();
});
</script>

<template>
	<div ref="carouselRef" :class="$style.carousel">
		<N8nIconButton
			v-if="hasOverflow"
			icon="chevron-left"
			variant="ghost"
			size="small"
			:aria-label="i18n.baseText('agentSessions.timeline.scrollBackward')"
			:disabled="!canScrollLeft"
			@click="scrollChart(-1)"
		/>
		<div ref="chartRef" :class="$style.chart">
			<N8nHoverCard
				:open="popoverOpen"
				hide-trigger
				:reference="activePopover?.reference"
				side="top"
				align="center"
				:side-offset="8"
				:close-delay="0"
				max-width="none"
				:content-class="$style.hoverCardContent"
			>
				<!-- One shared HoverCard avoids hundreds of tooltip instances; segment handlers set content and reference. -->
				<template #content>
					<div v-if="activePopover?.segment.kind === 'idle'" :class="$style.popoverInner">
						<SessionTimelinePill
							kind="idle"
							:label="i18n.baseText('agentSessions.timeline.idle')"
							show-label
						/>
						<span :class="$style.popoverMeta">{{ idleDuration(activePopover.segment.range) }}</span>
					</div>
					<div v-else-if="activePopover" :class="$style.popoverInner">
						<SessionTimelinePill
							:kind="popoverPillKind(activePopover.segment.item)"
							:label="popoverLabel(activePopover.segment.item)"
							show-label
						/>
						<span :class="$style.popoverName">{{ popoverName(activePopover.segment.item) }}</span>
						<N8nBadge
							v-if="activePopoverStatus"
							:theme="activePopoverStatus.theme"
							size="xsmall"
							:data-test-id="
								activePopoverStatus.kind === 'hitl-response'
									? 'timeline-popover-hitl-response-badge'
									: activePopover.segment.item.kind === 'execution-error'
										? 'timeline-popover-execution-error-badge'
										: 'timeline-popover-tool-error-badge'
							"
						>
							{{ i18n.baseText(activePopoverStatus.labelKey) }}
						</N8nBadge>
						<span v-if="popoverDuration(activePopover.segment.item)" :class="$style.popoverMeta">
							{{ popoverDuration(activePopover.segment.item) }}
						</span>
						<span :class="$style.popoverMeta">{{ popoverTime(activePopover.segment.item) }}</span>
					</div>
				</template>
			</N8nHoverCard>
			<div
				v-for="(seg, segIdx) in segments"
				:key="segIdx"
				data-test-id="timeline-cell"
				:data-error="seg.kind === 'event' && isErroredTimelineItem(seg.item) ? 'true' : undefined"
				:class="$style.cell"
				:style="cellStyle(seg)"
			>
				<div
					v-if="seg.kind === 'idle'"
					data-test-id="timeline-idle"
					:class="$style.idle"
					@mouseenter="showPopover(seg, $event)"
					@mouseleave="hidePopover($event)"
				>
					<span :class="$style.idleFill">{{ i18n.baseText('agentSessions.timeline.idle') }}</span>
				</div>
				<button
					v-else
					type="button"
					data-test-id="timeline-block"
					:data-timeline-index="seg.index"
					:data-error="isErroredTimelineItem(seg.item) ? 'true' : undefined"
					:aria-label="blockAriaLabel(seg.item)"
					:class="[$style.block, props.selectedIndex === seg.index && $style.selected]"
					:data-selected="props.selectedIndex === seg.index ? 'true' : undefined"
					:style="eventStyle(seg.item)"
					@mouseenter="showPopover(seg, $event)"
					@mouseleave="hidePopover($event)"
					@focus="showPopover(seg, $event)"
					@blur="hidePopover($event)"
					@click="onClick(seg.index, seg.item)"
				/>
			</div>
		</div>
		<N8nIconButton
			v-if="hasOverflow"
			icon="chevron-right"
			variant="ghost"
			size="small"
			:aria-label="i18n.baseText('agentSessions.timeline.scrollForward')"
			:disabled="!canScrollRight"
			@click="scrollChart(1)"
		/>
	</div>
</template>

<style module lang="scss">
.carousel {
	display: flex;
	align-items: center;
	gap: var(--spacing--4xs);
	width: 100%;
	min-width: 0;
}

.chart {
	display: flex;
	align-items: stretch;
	flex: 1;
	gap: 1px;
	height: 28px;
	min-width: 0;
	overflow-x: auto;
	scrollbar-width: none;
	scroll-padding-inline: var(--spacing--lg);
	border-radius: var(--radius);

	&::-webkit-scrollbar {
		display: none;
	}
}

/*
 * Each segment lives inside a flex .cell that owns the inline flex sizing.
 * Hover/focus popover positioning is handled by one shared HoverCard above,
 * anchored to the active block/idle element.
 */
.cell {
	position: relative;
	display: flex;
	align-items: stretch;
	min-width: 24px;
	flex-shrink: 0;
	transition:
		opacity,
		transform var(--duration--snappy) var(--easing--ease-out);
}

.cell[data-error='true']::before {
	position: absolute;
	top: calc(var(--spacing--5xs) * -1);
	left: 0;
	width: 100%;
	height: var(--spacing--4xs);
	border-radius: var(--radius--sm);
	background-color: var(--color--danger);
	content: '';
	z-index: 10;
}

.chart:has(.block:hover, .block.selected) .block:not(:hover):not(.selected) {
	opacity: 0.4;
}

.idle {
	position: relative;
	flex: 1 0 0;
	display: flex;
	align-items: center;
	justify-content: center;
	background-image: repeating-linear-gradient(
		45deg,
		var(--color--foreground--shade-1) 0 4px,
		transparent 4px 8px
	);
	border-radius: var(--radius--sm);
	cursor: default;
}

.idleFill {
	display: inline-flex;
	align-items: center;
	padding: 1px var(--spacing--3xs);
	background-color: var(--color--background);
	border-radius: var(--radius--lg);
	font-size: var(--font-size--3xs);
	font-weight: var(--font-weight--bold);
	color: var(--color--text--tint-1);
	text-transform: lowercase;
	letter-spacing: 0.02em;
}

.block {
	position: relative;
	flex: 1 0 0;
	margin: 4px 0;
	border: none;
	border-radius: var(--radius--sm);
	padding: 0;
	background-color: var(--session-timeline-chart-block-color);
	cursor: pointer;
	transition: filter 0.15s;
}

/*
 * Keep the shared hover card compact so the single-line row layout
 * (pill · name · duration · time) doesn't wrap.
 */
.hoverCardContent {
	max-width: none;
	min-height: var(--height--sm);
	font-size: var(--font-size--xs);
	font-weight: var(--font-weight--medium);
	line-height: var(--line-height--md);
	word-wrap: break-word;
	display: flex;
	align-items: center;
	justify-content: center;
	color: var(--color--text);
}

.popoverInner {
	display: inline-flex;
	align-items: center;
	gap: var(--spacing--2xs);
	padding: var(--spacing--4xs) var(--spacing--3xs);
	white-space: nowrap;
}

.popoverName {
	max-width: 320px;
	overflow: hidden;
	text-overflow: ellipsis;
}

.popoverMeta {
	color: var(--color--text--tint-1);
	font-variant-numeric: tabular-nums;
}
</style>
