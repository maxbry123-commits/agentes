import { Flex, Text, RadioGroup as RadixRadioGroup } from "@radix-ui/themes";
import { MarginProps } from "@radix-ui/themes/dist/esm/props/margin.props.js";
import { forwardRef, Fragment, ReactElement, ReactNode } from "react";
import clsx from "clsx";
import HelperText, { getRadixColor } from "@/ui/HelperText";
import Tooltip from "@/ui/Tooltip";
import { radixSize, Size } from "@/ui/sizes";

export type RadioOptions = {
  value: string;
  label?: string | ReactNode;
  description?: string | JSX.Element;
  error?: string;
  errorLevel?: "error" | "warning";
  renderOnSelect?: ReactElement;
  /**
   * When true, `renderOnSelect` is rendered as a sibling after the radio item
   * rather than inside the label element. Use this when the disclosed content
   * contains interactive elements (dropdowns, inputs) that must not be wrapped
   * in a `<label>`.
   */
  renderOutsideItem?: boolean;
  itemClassName?: string;
  disabled?: boolean;
  disabledReason?: ReactNode;
}[];

export type Props = {
  disabled?: boolean;
  options: RadioOptions;
  value: string;
  setValue: (value: string) => void;
  gap?: string;
  descriptionSize?: Size<"sm" | "md" | "lg" | "xl">;
  labelSize?: Size<"sm" | "md" | "lg" | "xl">;
  width?: string | number;
} & MarginProps;

export default forwardRef<HTMLDivElement, Props>(function RadioGroup(
  {
    disabled,
    options,
    value,
    setValue,
    gap = "1",
    descriptionSize = "sm",
    labelSize = "md",
    width,
    ...containerProps
  }: Props,
  ref,
) {
  // get color for selected option
  const selectedOption = options.find((o) => o.value === value);
  const selectedValue = value;
  const radioColor = selectedOption?.error
    ? getRadixColor(selectedOption?.errorLevel ?? "error")
    : "violet";

  return (
    <Flex
      style={width != null ? { width } : undefined}
      {...containerProps}
      ref={ref}
    >
      <Flex direction={"column"} style={width != null ? { width } : undefined}>
        <Text size="2" color={disabled ? "gray" : undefined}>
          <RadixRadioGroup.Root
            value={value}
            onValueChange={(val) => setValue(val)}
            disabled={disabled}
            color={radioColor}
          >
            <Flex direction="column" gap={gap}>
              {options.map(
                ({
                  value,
                  label,
                  description,
                  disabled,
                  disabledReason,
                  error,
                  errorLevel = "error",
                  renderOnSelect,
                  renderOutsideItem = false,
                  itemClassName,
                }) => {
                  const selected = value == selectedValue;
                  const item = (
                    <Fragment key={value}>
                      <RadixRadioGroup.Item
                        value={value}
                        disabled={disabled}
                        className={
                          clsx({ disabled }, itemClassName) || undefined
                        }
                      >
                        <Text
                          className={disabled ? "rt-TextDisabled" : undefined}
                        >
                          <Flex direction="column">
                            <Text
                              weight="medium"
                              className="main-text"
                              size={radixSize(labelSize)}
                            >
                              {label || value}
                            </Text>
                            {description ? (
                              <Text
                                weight="regular"
                                size={radixSize(descriptionSize)}
                              >
                                {description}
                              </Text>
                            ) : null}
                            {error && selected ? (
                              <HelperText status={errorLevel}>
                                {error}
                              </HelperText>
                            ) : null}
                            {!renderOutsideItem && renderOnSelect && selected
                              ? renderOnSelect
                              : null}
                          </Flex>
                        </Text>
                      </RadixRadioGroup.Item>
                      {renderOutsideItem && renderOnSelect && selected
                        ? renderOnSelect
                        : null}
                    </Fragment>
                  );

                  if (!disabledReason) return item;

                  return (
                    <Tooltip
                      key={value}
                      content={disabledReason}
                      enabled={!!disabled}
                    >
                      <span style={{ display: "block" }}>{item}</span>
                    </Tooltip>
                  );
                },
              )}
            </Flex>
          </RadixRadioGroup.Root>
        </Text>
      </Flex>
    </Flex>
  );
});
