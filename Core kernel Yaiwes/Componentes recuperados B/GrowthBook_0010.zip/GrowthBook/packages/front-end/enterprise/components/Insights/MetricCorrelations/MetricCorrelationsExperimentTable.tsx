import React, { FC, useState } from "react";
import { FaShippingFast } from "react-icons/fa";
import { Flex } from "@radix-ui/themes";
import clsx from "clsx";
import { date, datetime } from "shared/dates";
import {
  ExperimentMetricDefinition,
  getLatestPhaseVariations,
  getMetricResultStatus,
  isSuspiciousUplift,
} from "shared/experiments";
import { DifferenceType, StatsEngine } from "shared/types/stats";
import {
  ExperimentWithSnapshot,
  SnapshotMetric,
} from "shared/types/experiment-snapshot";
import {
  ExperimentDecisionFrameworkSettings,
  ExperimentPhaseStringDates,
  ExperimentResultsType,
  ExperimentStatus,
  Variation,
} from "shared/types/experiment";
import Link from "@/ui/Link";
import { useOrganizationMetricDefaults } from "@/hooks/useOrganizationMetricDefaults";
import useConfidenceLevels from "@/hooks/useConfidenceLevels";
import usePValueThreshold from "@/hooks/usePValueThreshold";
import useSignificanceThresholdsByProject from "@/hooks/useSignificanceThresholdsByProject";
import { experimentDate, RowResults } from "@/services/experiments";
import { useAddComputedFields, useSearch } from "@/services/search";
import Tooltip from "@/components/Tooltip/Tooltip";
import { formatNumber } from "@/services/metrics";
import ExperimentStatusIndicator from "@/components/Experiment/TabbedPage/ExperimentStatusIndicator";
import ChangeColumn from "@/components/Experiment/ChangeColumn";
import Pagination from "@/components/Pagination";
import Checkbox from "@/ui/Checkbox";
import VariationLabel from "@/ui/VariationLabel";

interface Props {
  experimentsWithSnapshot: ExperimentWithSnapshot[];
  metrics: ExperimentMetricDefinition[];
  bandits?: boolean;
  numPerPage?: number;
  differenceType?: DifferenceType;
  excludedExperimentVariations: {
    experimentId: string;
    variationIndex: number;
  }[];
  setExcludedExperimentVariations: (
    experimentVariations: { experimentId: string; variationIndex: number }[],
  ) => void;
}

export interface MetricExperimentData {
  id: string;
  date: string;
  name: string;
  status: ExperimentStatus;
  results?: ExperimentResultsType;
  archived: boolean;
  variations: Variation[];
  statsEngine: StatsEngine;
  variationIndex: number;
  variationName: string;
  metricResults: {
    results: SnapshotMetric;
    significant: boolean;
    lift?: number;
    resultsStatus?: string;
    directionalStatus?: "winning" | "losing";
    suspiciousChange: boolean;
    suspiciousThreshold: number;
    minPercentChange: number;
  }[];
  users?: number;
  shipped?: boolean;
  phases: ExperimentPhaseStringDates[];
  guardrailMetrics: string[];
  goalMetrics: string[];
  secondaryMetrics: string[];
  datasource: string;
  decisionFrameworkSettings: ExperimentDecisionFrameworkSettings;
  project?: string;
}

// Interface for computed data with dynamic lift fields
export interface ComputedMetricExperimentData extends MetricExperimentData {
  // only show lift for first 2 metrics
  // TODO generalize to more metrics
  lift0?: number;
  lift1?: number;
  included: boolean;
}

const NUM_PER_PAGE = 50;

const ExperimentWithMetricsTable: FC<Props> = ({
  experimentsWithSnapshot,
  metrics,
  bandits,
  numPerPage = NUM_PER_PAGE,
  differenceType = "relative",
  excludedExperimentVariations,
  setExcludedExperimentVariations,
}: Props) => {
  const [currentPage, setCurrentPage] = useState(1);
  const start = (currentPage - 1) * numPerPage;
  const end = start + numPerPage;

  const { metricDefaults } = useOrganizationMetricDefaults();
  const bayesianConfidenceLevels = useConfidenceLevels(undefined);
  const pValueThreshold = usePValueThreshold(undefined);
  const defaultSignificanceThresholds = {
    bayesianConfidenceLevels,
    pValueThreshold,
  };
  // Experiments in this table can span projects. Resolve project-scoped
  // significance thresholds up front for every project in the org so we can
  // look them up per-experiment without calling hooks in a loop.
  const significanceThresholdsByProject = useSignificanceThresholdsByProject();

  const expData: MetricExperimentData[] = [];
  experimentsWithSnapshot.forEach((e) => {
    const {
      bayesianConfidenceLevels: { ciUpper, ciLower },
      pValueThreshold,
    } =
      significanceThresholdsByProject.get(e.project || "") ??
      defaultSignificanceThresholds;
    let variationResults: SnapshotMetric[][] = [];
    let statsEngine: StatsEngine = "bayesian";
    let differenceType: DifferenceType = "relative";
    if (e.snapshot) {
      const snapshot = e.snapshot.analyses?.[0];
      if (snapshot) {
        statsEngine = snapshot.settings.statsEngine;
        differenceType = snapshot.settings.differenceType;
        variationResults = snapshot.results?.[0]?.variations.map((v) => {
          return metrics.map((m) => v.metrics?.[m.id]);
        });
      }
    }
    const baseline = variationResults?.[0];
    getLatestPhaseVariations(e).forEach((v, variationIndex) => {
      if (variationIndex === 0) return;
      const expVariationData: MetricExperimentData = {
        id: e.id,
        date: experimentDate(e),
        name: e.name,
        status: e.status,
        results: e.results,
        archived: e.archived,
        variations: getLatestPhaseVariations(e),
        statsEngine: statsEngine,
        variationIndex: variationIndex,
        variationName: v.name,
        metricResults: [],
        phases: e.phases,
        goalMetrics: e.goalMetrics,
        guardrailMetrics: e.guardrailMetrics,
        secondaryMetrics: e.secondaryMetrics,
        datasource: e.datasource,
        decisionFrameworkSettings: e.decisionFrameworkSettings,
        users: undefined,
        project: e.project,
      };
      metrics.forEach((m, metricIndex) => {
        if (
          !bandits &&
          baseline?.[metricIndex] &&
          variationResults[variationIndex][metricIndex]
        ) {
          const { significant, resultsStatus, directionalStatus } =
            getMetricResultStatus({
              metric: m,
              metricDefaults,
              baseline: baseline[metricIndex],
              stats: variationResults[variationIndex][metricIndex],
              ciLower,
              ciUpper,
              pValueThreshold,
              statsEngine,
              differenceType,
            });
          const suspiciousChange = isSuspiciousUplift(
            baseline[metricIndex],
            variationResults[variationIndex][metricIndex],
            m,
            metricDefaults,
            differenceType,
          );
          const suspiciousThreshold =
            m.maxPercentChange ?? metricDefaults?.maxPercentageChange ?? 0;
          const minPercentChange =
            m.minPercentChange ?? metricDefaults.minPercentageChange ?? 0;
          expVariationData.metricResults.push({
            results: variationResults[variationIndex][metricIndex],
            significant,
            lift:
              variationResults[variationIndex][metricIndex].uplift?.mean ??
              undefined,
            resultsStatus,
            directionalStatus,
            suspiciousChange,
            suspiciousThreshold,
            minPercentChange,
          });
          expVariationData.users = Math.max(
            expVariationData.users ?? 0,
            variationResults[variationIndex][metricIndex].users,
          );
        }
      });
      expVariationData.shipped =
        e.results === "won" && e.winner === variationIndex;
      expData.push(expVariationData);
    });
  });

  const computedExpData = useAddComputedFields<
    MetricExperimentData,
    ComputedMetricExperimentData
  >(
    expData,
    (e) => {
      return {
        ...e,
        // Only show lift for first 2 metrics
        // TODO generalize to more metrics
        lift0: e.metricResults[0]?.lift,
        lift1: e.metricResults[1]?.lift,
        included: !excludedExperimentVariations.some(
          (ev) =>
            ev.experimentId === e.id && ev.variationIndex === e.variationIndex,
        ),
      };
    },
    [excludedExperimentVariations, metrics],
  );

  const { items, SortableTH } = useSearch({
    items: computedExpData,
    localStorageKey: "metricExperiments",
    defaultSortField: "date",
    defaultSortDir: -1,
    undefinedLast: true,
    searchFields: [],
    // This is a sort-only table embedded inside pages that own the URL `q`
    // param (e.g. MetricCorrelations). Without this, the hook would latch
    // onto the page's filter string at mount, which combined with an empty
    // searchFields collapses the table to zero rows.
    disableUrlSearchTerm: true,
  });

  const expRows = items.slice(start, end).map((e) => {
    return (
      <tr
        key={`${e.id}-${e.variationIndex}`}
        className="hover-highlight impact-results"
      >
        <td>
          <Checkbox
            value={
              !excludedExperimentVariations.some(
                (ev) =>
                  ev.experimentId === e.id &&
                  ev.variationIndex === e.variationIndex,
              )
            }
            setValue={(value) => {
              setExcludedExperimentVariations(
                value
                  ? excludedExperimentVariations.filter(
                      (ev) =>
                        ev.experimentId !== e.id ||
                        ev.variationIndex !== e.variationIndex,
                    )
                  : [
                      ...excludedExperimentVariations,
                      { experimentId: e.id, variationIndex: e.variationIndex },
                    ],
              );
            }}
          />
        </td>
        <td>
          <div className="my-1">
            <Link className="font-weight-bold" href={`/experiment/${e.id}`}>
              {e.name}
            </Link>
          </div>
        </td>

        <td>
          <Flex
            key={`var-experiment${e.id}-variation${e.variationIndex}`}
            align="center"
            gap="1"
            my="1"
          >
            <VariationLabel
              number={e.variationIndex}
              name={e.variationName}
              size="md"
              maxWidth="220px"
            />
            {e.shipped ? (
              <Tooltip body={"Variation marked as the winner"}>
                <FaShippingFast />
              </Tooltip>
            ) : null}
          </Flex>
        </td>
        <td className="nowrap" title={datetime(e.date)}>
          {e.status === "running"
            ? "started"
            : e.status === "draft"
              ? "created"
              : e.status === "stopped"
                ? "ended"
                : ""}{" "}
          {date(e.date)}
        </td>
        <td>
          <div className="my-1">
            <ExperimentStatusIndicator experimentData={e} />
          </div>
        </td>
        <td>{e.users ? formatNumber(e.users) : ""}</td>
        {!bandits
          ? metrics.slice(0, 2).map((m, i) => {
              const mr = e.metricResults[i];
              if (!mr) return <td key={`${e.id}-${e.variationIndex}-${i}`} />;
              const resultsHighlightClassname = clsx(mr.resultsStatus, {
                "non-significant": !mr.significant,
                hover: false,
              });
              return (
                <ChangeColumn
                  metric={m}
                  pValueThreshold={
                    (
                      significanceThresholdsByProject.get(e.project || "") ??
                      defaultSignificanceThresholds
                    ).pValueThreshold
                  }
                  stats={mr.results}
                  rowResults={{
                    enoughData: true,
                    directionalStatus: mr.directionalStatus ?? "losing",
                    hasScaledImpact: true,
                    significant: mr.significant,
                    resultsStatus:
                      (mr.resultsStatus as RowResults["resultsStatus"]) ?? "",
                    suspiciousChange: mr.suspiciousChange,
                    suspiciousThreshold: mr.suspiciousThreshold,
                    minPercentChange: mr.minPercentChange,
                    currentMetricTotal: mr.results?.value ?? 0,
                  }}
                  showPlusMinus={false}
                  statsEngine={e.statsEngine}
                  differenceType={differenceType}
                  showCI={true}
                  className={resultsHighlightClassname}
                  key={`${e.id}-${e.variationIndex}-${i}`}
                />
              );
            })
          : null}
      </tr>
    );
  });

  return (
    <div>
      <table className="table appbox">
        <thead className="bg-light">
          <tr>
            <SortableTH field="included">Include</SortableTH>
            <SortableTH field="name">Experiment</SortableTH>
            <SortableTH field="variationIndex">Variation</SortableTH>
            <SortableTH field="date">Date</SortableTH>
            <SortableTH field="status">Status</SortableTH>
            <SortableTH field="users">Variation Users</SortableTH>
            {metrics[0] && (
              <SortableTH field="lift0">Lift {metrics[0].name}</SortableTH>
            )}
            {metrics[1] && (
              <SortableTH field="lift1">Lift {metrics[1].name}</SortableTH>
            )}
          </tr>
        </thead>
        <tbody>{expRows}</tbody>
      </table>
      {items.length > numPerPage && (
        <Pagination
          numItemsTotal={items.length}
          currentPage={currentPage}
          perPage={numPerPage}
          onPageChange={setCurrentPage}
        />
      )}
    </div>
  );
};

export default ExperimentWithMetricsTable;
