const path = require("path");

const withBundleAnalyzer = require("@next/bundle-analyzer")({
  enabled: process.env.ANALYZE === "true",
});

const cspHeader = `
    frame-ancestors 'none';
`;

/** @type {import('next').NextConfig} */
const nextConfig = {
  // The app doesn't use next/image anywhere, so the /_next/image optimizer is
  // unused product surface — only a public, unauthenticated endpoint for SSRF/
  // path-traversal probing and (via its uncapped disk cache) disk-fill risk.
  // Disabling it closes the route entirely (404) instead of serving it.
  images: {
    unoptimized: true,
  },
  turbopack: {
    root: path.join(__dirname, "../.."),
    // Ace workers: load as raw text so we can create Blob URLs. Turbopack doesn't support
    // webpack's asset/resource the same way - raw-loader gives us the worker source,
    // which we convert to blob: URLs that Ace can load.
    rules: {
      "**/ace-builds/**/worker-*.js": {
        loaders: ["raw-loader"],
        as: "*.js",
      },
    },
  },
  experimental: {
    turbopackFileSystemCacheForDev: true,
    turbopackFileSystemCacheForBuild: true,
  },
  sassOptions: {
    silenceDeprecations: [
      "legacy-js-api",
      "import",
      "slash-div",
      "color-functions",
      "global-builtin",
      "abs-percent",
    ],
  },
  headers: () => [
    {
      source: "/(.*)",
      headers: [
        {
          key: "Content-Security-Policy",
          value: cspHeader.replace(/\n/g, ""),
        },
        {
          key: "X-Frame-Options",
          value: "deny",
        },
        {
          key: "Cross-Origin-Opener-Policy",
          value: "same-origin",
        },
      ],
    },
  ],
  transpilePackages: ["echarts", "zrender"],
  webpack: (config) => {
    // Ace workers: use raw-loader (same as Turbopack) so we get source and create
    // Blob URLs. asset/resource only works with webpack, not Turbopack.
    config.module.rules.push({
      test: /ace-builds.*\/worker-.*\.js$/,
      use: "raw-loader",
    });

    // Suppress OpenTelemetry dynamic require warnings from Sentry
    config.ignoreWarnings = [
      ...(config.ignoreWarnings || []),
      {
        module: /@opentelemetry\/instrumentation/,
        message:
          /Critical dependency: the request of a dependency is an expression/,
      },
    ];

    return config;
  },
  productionBrowserSourceMaps: true,
};

module.exports = withBundleAnalyzer(nextConfig);
