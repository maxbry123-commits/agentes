import asyncio
import dataclasses
import time
from collections.abc import MutableSequence

import pytest
from google.protobuf.duration_pb2 import Duration

import temporalio.api.workflowservice.v1.request_response_pb2 as workflowservice_pb2
import temporalio.bridge.worker
import temporalio.converter
import temporalio.exceptions
import temporalio.nexus.system as nexus_system
from temporalio.api.common.v1.message_pb2 import (
    Payload,
    Payloads,
    Priority,
    SearchAttributes,
)
from temporalio.api.sdk.v1.user_metadata_pb2 import UserMetadata
from temporalio.bridge._visitor import PayloadVisitor
from temporalio.bridge._visitor_functions import VisitorFunctions
from temporalio.bridge.proto.workflow_activation.workflow_activation_pb2 import (
    InitializeWorkflow,
    WorkflowActivation,
    WorkflowActivationJob,
)
from temporalio.bridge.proto.workflow_commands.workflow_commands_pb2 import (
    ContinueAsNewWorkflowExecution,
    ScheduleActivity,
    ScheduleLocalActivity,
    ScheduleNexusOperation,
    SignalExternalWorkflowExecution,
    StartChildWorkflowExecution,
    UpdateResponse,
    WorkflowCommand,
)
from temporalio.bridge.proto.workflow_completion.workflow_completion_pb2 import (
    Success,
    WorkflowActivationCompletion,
)
from tests.worker.test_workflow import SimpleCodec


class Visitor(VisitorFunctions):
    async def visit_payload(self, payload: Payload) -> None:
        payload.metadata["visited"] = b"True"

    async def visit_payloads(self, payloads: MutableSequence[Payload]) -> None:
        for payload in payloads:
            payload.metadata["visited"] = b"True"


async def test_workflow_activation_completion():
    comp = WorkflowActivationCompletion(
        run_id="1",
        successful=Success(
            commands=[
                WorkflowCommand(
                    schedule_activity=ScheduleActivity(
                        seq=1,
                        activity_id="1",
                        activity_type="",
                        task_queue="",
                        headers={"foo": Payload(data=b"bar")},
                        arguments=[Payload(data=b"baz")],
                        schedule_to_close_timeout=Duration(seconds=5),
                        priority=Priority(),
                    ),
                    user_metadata=UserMetadata(summary=Payload(data=b"Summary")),
                )
            ],
        ),
    )

    await PayloadVisitor().visit(Visitor(), comp)

    cmd = comp.successful.commands[0]
    sa = cmd.schedule_activity
    assert sa.headers["foo"].metadata["visited"]
    assert len(sa.arguments) == 1 and sa.arguments[0].metadata["visited"]

    assert cmd.user_metadata.summary.metadata["visited"]


async def test_workflow_activation():
    original = WorkflowActivation(
        jobs=[
            WorkflowActivationJob(
                initialize_workflow=InitializeWorkflow(
                    arguments=[
                        Payload(data=b"repeated1"),
                        Payload(data=b"repeated2"),
                    ],
                    headers={"header": Payload(data=b"map")},
                    last_completion_result=Payloads(
                        payloads=[
                            Payload(data=b"obj1"),
                            Payload(data=b"obj2"),
                        ]
                    ),
                    search_attributes=SearchAttributes(
                        indexed_fields={
                            "sakey": Payload(data=b"saobj"),
                        }
                    ),
                ),
            )
        ]
    )

    act = original.__deepcopy__()
    await PayloadVisitor().visit(Visitor(), act)
    assert act.jobs[0].initialize_workflow.arguments[0].metadata["visited"]
    assert act.jobs[0].initialize_workflow.arguments[1].metadata["visited"]
    assert act.jobs[0].initialize_workflow.headers["header"].metadata["visited"]
    assert (
        act.jobs[0]
        .initialize_workflow.last_completion_result.payloads[0]
        .metadata["visited"]
    )
    assert (
        act.jobs[0]
        .initialize_workflow.last_completion_result.payloads[1]
        .metadata["visited"]
    )
    assert (
        act.jobs[0]
        .initialize_workflow.search_attributes.indexed_fields["sakey"]
        .metadata["visited"]
    )

    act = original.__deepcopy__()
    await PayloadVisitor(skip_search_attributes=True).visit(Visitor(), act)
    assert (
        not act.jobs[0]
        .initialize_workflow.search_attributes.indexed_fields["sakey"]
        .metadata["visited"]
    )

    act = original.__deepcopy__()
    await PayloadVisitor(skip_headers=True).visit(Visitor(), act)
    assert not act.jobs[0].initialize_workflow.headers["header"].metadata["visited"]


async def test_visit_payloads_on_other_commands():
    comp = WorkflowActivationCompletion(
        run_id="2",
        successful=Success(
            commands=[
                # Continue as new
                WorkflowCommand(
                    continue_as_new_workflow_execution=ContinueAsNewWorkflowExecution(
                        arguments=[Payload(data=b"a1")],
                        headers={"h1": Payload(data=b"a2")},
                        memo={"m1": Payload(data=b"a3")},
                    )
                ),
                # Start child
                WorkflowCommand(
                    start_child_workflow_execution=StartChildWorkflowExecution(
                        input=[Payload(data=b"b1")],
                        headers={"h2": Payload(data=b"b2")},
                        memo={"m2": Payload(data=b"b3")},
                    )
                ),
                # Signal external
                WorkflowCommand(
                    signal_external_workflow_execution=SignalExternalWorkflowExecution(
                        args=[Payload(data=b"c1")],
                        headers={"h3": Payload(data=b"c2")},
                    )
                ),
                # Schedule local activity
                WorkflowCommand(
                    schedule_local_activity=ScheduleLocalActivity(
                        arguments=[Payload(data=b"d1")],
                        headers={"h4": Payload(data=b"d2")},
                    )
                ),
                # Update response completed
                WorkflowCommand(
                    update_response=UpdateResponse(
                        completed=Payload(data=b"e1"),
                    )
                ),
            ]
        ),
    )

    await PayloadVisitor().visit(Visitor(), comp)

    cmds = comp.successful.commands
    can = cmds[0].continue_as_new_workflow_execution
    assert can.arguments[0].metadata["visited"]
    assert can.headers["h1"].metadata["visited"]
    assert can.memo["m1"].metadata["visited"]

    sc = cmds[1].start_child_workflow_execution
    assert sc.input[0].metadata["visited"]
    assert sc.headers["h2"].metadata["visited"]
    assert sc.memo["m2"].metadata["visited"]

    se = cmds[2].signal_external_workflow_execution
    assert se.args[0].metadata["visited"]
    assert se.headers["h3"].metadata["visited"]

    sla = cmds[3].schedule_local_activity
    assert sla.arguments[0].metadata["visited"]
    assert sla.headers["h4"].metadata["visited"]

    ur = cmds[4].update_response
    assert ur.completed.metadata["visited"]


async def test_system_nexus_envelope_is_detected_in_generic_payload_field():
    class SystemNexusVisitor(Visitor):
        def __init__(self) -> None:
            self.visited_payload_count = 0
            self.system_envelope_count = 0

        async def visit_payload(self, payload: Payload) -> None:
            self.visited_payload_count += 1
            await super().visit_payload(payload)

        async def visit_payloads(self, payloads: MutableSequence[Payload]) -> None:
            self.visited_payload_count += len(payloads)
            await super().visit_payloads(payloads)

        async def visit_system_nexus_envelope(self, payload: Payload) -> None:
            _ = payload
            self.system_envelope_count += 1

    system_request = workflowservice_pb2.SignalWithStartWorkflowExecutionRequest(
        input=Payloads(payloads=[Payload(data=b"workflow-input")]),
    )
    data_converter = temporalio.converter.default()
    payload_converter = nexus_system._get_payload_converter(
        data_converter.payload_converter,
        data_converter.failure_converter,
    )
    system_payload = payload_converter.to_payload(system_request)
    assert system_payload is not None
    comp = WorkflowActivationCompletion(
        run_id="3",
        successful=Success(
            commands=[
                WorkflowCommand(
                    update_response=UpdateResponse(completed=system_payload),
                )
            ]
        ),
    )
    visitor = SystemNexusVisitor()

    await PayloadVisitor(concurrency_limit=3).visit(visitor, comp)

    completed = comp.successful.commands[0].update_response.completed
    assert completed.metadata["__temporal_system_payload"] == b"true"
    assert "visited" not in completed.metadata
    decoded = payload_converter.from_payload(completed)
    assert isinstance(
        decoded, workflowservice_pb2.SignalWithStartWorkflowExecutionRequest
    )
    assert decoded.input.payloads[0].metadata["visited"] == b"True"
    assert visitor.visited_payload_count == 1
    assert visitor.system_envelope_count == 1


async def test_system_nexus_envelope_without_payloads_is_visited():
    class SystemNexusVisitor(Visitor):
        def __init__(self) -> None:
            self.system_envelope_count = 0

        async def visit_system_nexus_envelope(self, payload: Payload) -> None:
            _ = payload
            self.system_envelope_count += 1

    response = workflowservice_pb2.SignalWithStartWorkflowExecutionResponse(
        run_id="test-run-id"
    )
    data_converter = temporalio.converter.default()
    payload_converter = nexus_system._get_payload_converter(
        data_converter.payload_converter,
        data_converter.failure_converter,
    )
    system_payload = payload_converter.to_payload(response)
    assert system_payload is not None
    completion = WorkflowActivationCompletion(
        run_id="3",
        successful=Success(
            commands=[
                WorkflowCommand(
                    update_response=UpdateResponse(completed=system_payload),
                )
            ]
        ),
    )
    visitor = SystemNexusVisitor()

    await PayloadVisitor().visit(visitor, completion)

    completed = completion.successful.commands[0].update_response.completed
    assert payload_converter.from_payload(completed) == response
    assert visitor.system_envelope_count == 1


async def test_unknown_system_nexus_payload_raises_application_error():
    data_converter = temporalio.converter.default()
    payload_converter = nexus_system._get_payload_converter(
        data_converter.payload_converter,
        data_converter.failure_converter,
    )
    system_payload = payload_converter.to_payload(
        workflowservice_pb2.StartWorkflowExecutionResponse(run_id="test-run-id")
    )
    assert system_payload is not None
    completion = WorkflowActivationCompletion(
        run_id="3",
        successful=Success(
            commands=[
                WorkflowCommand(
                    update_response=UpdateResponse(completed=system_payload),
                )
            ]
        ),
    )

    with pytest.raises(temporalio.exceptions.ApplicationError) as err:
        await PayloadVisitor().visit(Visitor(), completion)

    assert (
        err.value.message == "Unknown Temporal system payload: "
        "temporal.api.workflowservice.v1.StartWorkflowExecutionResponse"
    )
    assert not err.value.non_retryable


async def test_concurrent_throughput():
    """Demonstrate that concurrent visitation is faster than serialized for I/O-bound codecs."""
    N_CMDS = 10
    N_ARGS = 5
    SLEEP = 0.02

    class SlowVisitor(VisitorFunctions):
        def __init__(self, *, blocking: bool = False):
            self.visit_count = 0
            self._active = 0
            self.max_concurrent = 0
            self._blocking = blocking

        async def visit_payload(self, payload: Payload) -> None:
            return await self._visit(1)

        async def visit_payloads(self, payloads: MutableSequence[Payload]) -> None:
            return await self._visit(len(payloads))

        async def _visit(self, count: int) -> None:
            self._active += 1
            self.max_concurrent = max(self.max_concurrent, self._active)
            try:
                if self._blocking:
                    time.sleep(SLEEP * count)
                else:
                    await asyncio.sleep(SLEEP * count)
                self.visit_count += count
            finally:
                self._active -= 1

    completion = WorkflowActivationCompletion(
        run_id="1",
        successful=Success(
            commands=[
                WorkflowCommand(
                    schedule_activity=ScheduleActivity(
                        seq=i,
                        activity_id=str(i),
                        activity_type="",
                        task_queue="",
                        arguments=[
                            Payload(data=f"cmd_{i}_arg_{j}".encode())
                            for j in range(N_ARGS)
                        ],
                        priority=Priority(),
                    )
                )
                for i in range(N_CMDS)
            ]
        ),
    )

    visitor_default = SlowVisitor()
    await PayloadVisitor().visit(visitor_default, completion)

    assert visitor_default.visit_count == N_CMDS * N_ARGS
    assert visitor_default.max_concurrent == 1

    visitor_concurrent = SlowVisitor()
    await PayloadVisitor(concurrency_limit=5).visit(visitor_concurrent, completion)

    assert visitor_concurrent.visit_count == N_CMDS * N_ARGS
    assert visitor_concurrent.max_concurrent == 5


async def test_cancel_drains_background_tasks():
    """Cancelling visit() cancels in-flight tasks and awaits their cleanup."""
    tasks_started = 0
    tasks_cleaned_up = 0
    background_running = asyncio.Event()

    class SlowVisitor(VisitorFunctions):
        async def visit_payload(self, payload: Payload) -> None:
            pass

        async def visit_payloads(self, payloads: MutableSequence[Payload]) -> None:
            nonlocal tasks_started, tasks_cleaned_up
            tasks_started += 1
            background_running.set()
            try:
                await asyncio.sleep(10)
            finally:
                tasks_cleaned_up += 1

    completion = WorkflowActivationCompletion(
        run_id="1",
        successful=Success(
            commands=[
                WorkflowCommand(
                    schedule_activity=ScheduleActivity(
                        seq=i,
                        activity_id=str(i),
                        activity_type="",
                        task_queue="",
                        arguments=[Payload(data=f"arg_{i}".encode())],
                        priority=Priority(),
                    )
                )
                for i in range(5)
            ]
        ),
    )

    task = asyncio.create_task(
        PayloadVisitor(concurrency_limit=5).visit(SlowVisitor(), completion)
    )
    await background_running.wait()
    task.cancel()

    with pytest.raises(asyncio.CancelledError):
        await task

    # All started tasks ran their finally blocks before drain() returned.
    assert tasks_started > 0
    assert tasks_cleaned_up == tasks_started


async def test_system_nexus_envelope_visit_is_bounded():
    active_visits = 0
    max_active_visits = 0
    two_visits_started = asyncio.Event()
    release_visits = asyncio.Event()

    class SlowVisitor(VisitorFunctions):
        async def visit_payload(self, payload: Payload) -> None:
            await self._visit()

        async def visit_payloads(self, payloads: MutableSequence[Payload]) -> None:
            await self._visit()

        async def visit_system_nexus_envelope(self, payload: Payload) -> None:
            await self._visit()

        async def _visit(self) -> None:
            nonlocal active_visits, max_active_visits
            active_visits += 1
            max_active_visits = max(max_active_visits, active_visits)
            if active_visits == 2:
                two_visits_started.set()
            try:
                await release_visits.wait()
            finally:
                active_visits -= 1

    data_converter = temporalio.converter.default()
    payload_converter = nexus_system._get_payload_converter(
        data_converter.payload_converter, data_converter.failure_converter
    )
    system_request = workflowservice_pb2.SignalWithStartWorkflowExecutionRequest(
        input=Payloads(payloads=[Payload(data=b"workflow-input")]),
        signal_input=Payloads(payloads=[Payload(data=b"signal-input")]),
    )
    payload = payload_converter.to_payload(system_request)
    assert payload is not None
    completion = WorkflowActivationCompletion(
        run_id="1",
        successful=Success(
            commands=[
                WorkflowCommand(
                    schedule_nexus_operation=ScheduleNexusOperation(
                        seq=1,
                        endpoint=nexus_system.TEMPORAL_SYSTEM_ENDPOINT,
                        service="temporal.api.workflowservice.v1.WorkflowService",
                        operation="SignalWithStartWorkflowExecution",
                        input=payload,
                    ),
                )
            ],
        ),
    )

    task = asyncio.create_task(
        PayloadVisitor(concurrency_limit=2).visit(SlowVisitor(), completion)
    )
    await two_visits_started.wait()
    await asyncio.sleep(0)
    assert max_active_visits == 2

    release_visits.set()
    await task
    assert max_active_visits == 2


async def test_bridge_encoding():
    comp = WorkflowActivationCompletion(
        run_id="1",
        successful=Success(
            commands=[
                WorkflowCommand(
                    schedule_activity=ScheduleActivity(
                        seq=1,
                        activity_id="1",
                        activity_type="",
                        task_queue="",
                        headers={"foo": Payload(data=b"bar")},
                        arguments=[
                            Payload(data=b"repeated1"),
                            Payload(data=b"repeated2"),
                        ],
                        schedule_to_close_timeout=Duration(seconds=5),
                        priority=Priority(),
                    ),
                    user_metadata=UserMetadata(summary=Payload(data=b"Summary")),
                )
            ],
        ),
    )

    data_converter = dataclasses.replace(
        temporalio.converter.default(),
        payload_codec=SimpleCodec(),
    )

    await temporalio.bridge.worker.encode_completion(
        comp, data_converter, True, storage_concurrency_limit=1
    )

    cmd = comp.successful.commands[0]
    sa = cmd.schedule_activity
    assert sa.headers["foo"].metadata["simple-codec"]
    assert len(sa.arguments) == 1
    assert sa.arguments[0].metadata["simple-codec"]

    assert cmd.user_metadata.summary.metadata["simple-codec"]
