/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

/// <reference types="vitest" />
/// <reference types="vite/client" />

import {defineConfig, type PluginOption, type UserConfig} from 'vite';
import react from '@vitejs/plugin-react';
import svgr from 'vite-plugin-svgr';
import sbom from 'rollup-plugin-sbom';
import {configDefaults} from 'vitest/config';
import {playwright} from '@vitest/browser-playwright';

const plugins: PluginOption[] = [react(), svgr()];
const outDir = 'build';

function getReporters(): Pick<
  NonNullable<UserConfig['test']>,
  'reporters' | 'outputFile'
> {
  if (process.env['CI']) {
    return {
      reporters: ['default', 'junit', 'github-actions'],
      outputFile: {
        junit: 'TEST-unit.xml',
      },
    };
  }
  return {
    reporters: ['default'],
  };
}

export default defineConfig(({mode}) => ({
  base: mode === 'production' ? './' : undefined,
  plugins: [
    ...plugins,
    ...(mode === 'sbom'
      ? [
          sbom({
            specVersion: '1.6',
          }),
        ]
      : []),
  ],
  preview: {
    port: 3003,
    open: false,
    proxy: {},
  },
  server: {
    port: 3000,
    open: true,
    proxy: {
      '/api': 'http://localhost:8080',
      '/v1': 'http://localhost:8080',
      '/v2': 'http://localhost:8080',
      '/login': {
        target: 'http://localhost:8080',
        bypass: (req) => (req.method !== 'POST' ? '/' : undefined),
      },
      '/logout': {
        target: 'http://localhost:8080',
        bypass: (req) => (req.method !== 'POST' ? '/' : undefined),
      },
      '/session/heartbeat': {
        target: 'http://localhost:8080',
        bypass: (req) => (req.method !== 'POST' ? '/' : undefined),
      },
      '/client-config.js': 'http://localhost:8080/operate',
    },
  },
  build: {
    outDir,
    sourcemap: mode !== 'sbom',
    license: {
      fileName: 'assets/vendor.LICENSE.txt',
    },
    rolldownOptions: {
      output: {
        postBanner: '/*! licenses: /assets/vendor.LICENSE.txt */',
      },
      input: {
        index:
          mode === 'visual-regression' ? './index.html' : './index.prod.html',
      },
    },
  },
  resolve: {
    tsconfigPaths: true,
  },
  test: {
    globals: true,
    restoreMocks: true,
    mockReset: true,
    unstubGlobals: true,
    clearMocks: true,
    resetMocks: true,
    unstubEnvs: true,
    retry: process.env['CI'] ? 3 : 0,
    dangerouslyIgnoreUnhandledErrors: true,
    ...getReporters(),
    server: {
      deps: {
        // this was necessary due to some issues with styled-components which appeared when bumping C3 on this https://github.com/camunda/camunda/pull/44663
        inline: [
          '@camunda/camunda-composite-components',
          '@camunda/design-system',
        ],
      },
    },
    projects: [
      {
        extends: true,
        test: {
          name: 'unit',
          environment: 'jsdom',
          include: ['./src/**/*.{test,spec}.?(c|m)[jt]s?(x)'],
          exclude: [
            ...configDefaults.exclude,
            './src/**/*.browser.{test,spec}.?(c|m)[jt]s?(x)',
          ],
          setupFiles: ['./src/setupTests.tsx'],
        },
      },
      {
        extends: true,
        test: {
          name: 'browser',
          include: ['./src/**/*.browser.{test,spec}.?(c|m)[jt]s?(x)'],
          setupFiles: ['./vitest.browser.setup.ts'],
          browser: {
            enabled: true,
            provider: playwright(),
            instances: [
              {
                browser: 'chromium',
              },
            ],
          },
        },
      },
    ],
  },
}));
