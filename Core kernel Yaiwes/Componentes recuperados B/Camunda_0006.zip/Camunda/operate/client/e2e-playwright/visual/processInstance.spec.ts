/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */

import {expect} from '@playwright/test';
import {test} from '@/visual-fixtures';
import {
  compensationProcessInstance,
  completedInstance,
  instanceWithIncident,
  mockResponses,
  runningInstance,
  waitStateRunningInstance,
} from '@/mocks/processInstance';
import {URL_API_PATTERN} from '@/constants';
import {clientConfigMock} from '@/mocks/clientConfig';

test.beforeEach(async ({context}) => {
  await context.route('**/client-config.js', (route) =>
    route.fulfill({
      status: 200,
      headers: {
        'Content-Type': 'text/javascript;charset=UTF-8',
      },
      body: clientConfigMock,
    }),
  );
});

test.describe('process instance page', () => {
  test('error page', async ({page, processInstancePage}) => {
    await page.route(
      URL_API_PATTERN,
      mockResponses({
        processInstanceDetail: runningInstance.detail,
        callHierarchy: runningInstance.callHierarchy,
        xml: runningInstance.xml,
      }),
    );

    await processInstancePage.gotoProcessInstancePage({
      key: runningInstance.detail.processInstanceKey,
    });

    await expect(processInstancePage.variablesTableSpinner).not.toBeVisible();
    await processInstancePage.resetZoomButton.click();

    await expect(
      page.getByText('Variables could not be fetched'),
    ).toBeVisible();

    await expect(page).toHaveScreenshot();
  });

  test('helper modal', async ({page}) => {
    await page.route(
      URL_API_PATTERN,
      mockResponses({
        processInstanceDetail: runningInstance.detail,
        callHierarchy: runningInstance.callHierarchy,
        elementInstances: runningInstance.elementInstances,
        statistics: runningInstance.statistics,
        sequenceFlows: runningInstance.sequenceFlows,
        variables: runningInstance.variables,
        xml: runningInstance.xml,
      }),
    );

    await page.goto(
      `/operate/processes/${runningInstance.detail.processInstanceKey}`,
    );

    await expect(page.getByText("Here's what moved in Operate")).toBeVisible();

    await expect(page).toHaveScreenshot();
  });

  test('running instance', async ({page, processInstancePage}) => {
    await page.route(
      URL_API_PATTERN,
      mockResponses({
        processInstanceDetail: runningInstance.detail,
        callHierarchy: runningInstance.callHierarchy,
        elementInstances: runningInstance.elementInstances,
        statistics: runningInstance.statistics,
        sequenceFlows: runningInstance.sequenceFlows,
        variables: runningInstance.variables,
        xml: runningInstance.xml,
        incidents: runningInstance.incidents,
      }),
    );

    await processInstancePage.gotoProcessInstancePage({
      key: runningInstance.detail.processInstanceKey,
    });
    await processInstancePage.resetZoomButton.click();
    await page.waitForTimeout(500);
    await expect(page.getByTestId(/^state-overlay/)).toHaveText('1');

    await expect(page).toHaveScreenshot();
  });

  test('running instance - wait state details', async ({
    page,
    processInstancePage,
  }) => {
    await page.route(
      URL_API_PATTERN,
      mockResponses({
        processInstanceDetail: waitStateRunningInstance.detail,
        callHierarchy: waitStateRunningInstance.callHierarchy,
        elementInstances: waitStateRunningInstance.elementInstances,
        statistics: waitStateRunningInstance.statistics,
        sequenceFlows: waitStateRunningInstance.sequenceFlows,
        variables: waitStateRunningInstance.variables,
        xml: waitStateRunningInstance.xml,
        incidents: waitStateRunningInstance.incidents,
        waitStates: waitStateRunningInstance.waitStates,
        waitStateStatistics: waitStateRunningInstance.waitStateStatistics,
      }),
    );

    await processInstancePage.gotoProcessInstancePage({
      key: waitStateRunningInstance.detail.processInstanceKey,
    });
    await processInstancePage.resetZoomButton.click();
    // allow the diagram (bpmn-js SVG) to finish rendering before screenshotting
    await page.waitForTimeout(500);
    await expect(
      page.getByTestId('waiting-state-overlay').first(),
    ).toBeVisible();

    // labels cover single- and multi-digit counts (and the narrow-element offset)
    await expect(page.getByText('2 waiting')).toBeVisible();
    await expect(page.getByText('5 waiting')).toBeVisible();
    await expect(page.getByText('11 waiting')).toBeVisible();
    await expect(page.getByText('333 waiting')).toBeVisible();

    // select the waiting user task and open its details
    await processInstancePage.diagram
      .getFlowNodeById('Activity_0dex012')
      .click();
    await page.getByRole('link', {name: 'Details', exact: true}).click();

    // both wait states are listed for the selected element
    await expect(page.getByTestId('waiting-status')).toBeVisible();
    await expect(page.getByText('Waiting for task completion')).toBeVisible();
    await expect(
      page.getByText('Waiting for task listener: notify-assignee'),
    ).toBeVisible();

    // The double-ring signal catch events anti-alias slightly differently
    // between CI runs; allow a small pixel budget to avoid flakiness.
    await expect(page).toHaveScreenshot({maxDiffPixels: 60});
  });

  test('add variable state', async ({page, processInstancePage}) => {
    await page.route(
      URL_API_PATTERN,
      mockResponses({
        processInstanceDetail: runningInstance.detail,
        callHierarchy: runningInstance.callHierarchy,
        elementInstances: runningInstance.elementInstances,
        statistics: runningInstance.statistics,
        sequenceFlows: runningInstance.sequenceFlows,
        variables: runningInstance.variables,
        xml: runningInstance.xml,
      }),
    );

    await processInstancePage.gotoProcessInstancePage({
      key: runningInstance.detail.processInstanceKey,
    });
    await processInstancePage.resetZoomButton.click();
    await page.waitForTimeout(500);
    await expect(page.getByTestId(/^state-overlay/)).toHaveText('1');

    await processInstancePage.addVariableButton.click();

    await expect(page).toHaveScreenshot();
  });

  test('variable modal overlays navigation at narrow desktop width', async ({
    page,
    processInstancePage,
  }) => {
    await page.setViewportSize({width: 1200, height: 720});
    await page.route(
      URL_API_PATTERN,
      mockResponses({
        processInstanceDetail: runningInstance.detail,
        callHierarchy: runningInstance.callHierarchy,
        elementInstances: runningInstance.elementInstances,
        statistics: runningInstance.statistics,
        sequenceFlows: runningInstance.sequenceFlows,
        variables: runningInstance.variables,
        xml: runningInstance.xml,
      }),
    );

    await processInstancePage.gotoProcessInstancePage({
      key: runningInstance.detail.processInstanceKey,
    });
    await processInstancePage.addVariableButton.click();
    await page.getByRole('button', {name: 'Open', exact: true}).last().click();

    await expect(
      page.getByRole('heading', {name: 'Edit a new Variable'}),
    ).toBeVisible();
    await processInstancePage.variablesEditor.hideCaret();
    await page.addStyleTag({
      content:
        '.monaco-editor :is(.scrollbar, .decorationsOverviewRuler) {opacity: 0 !important;}',
    });
    await page.mouse.move(0, 0);

    await expect(page).toHaveScreenshot();
  });

  test('edit variable state', async ({page, processInstancePage}) => {
    await page.route(
      URL_API_PATTERN,
      mockResponses({
        processInstanceDetail: runningInstance.detail,
        callHierarchy: runningInstance.callHierarchy,
        elementInstances: runningInstance.elementInstances,
        statistics: runningInstance.statistics,
        sequenceFlows: runningInstance.sequenceFlows,
        variables: runningInstance.variables,
        xml: runningInstance.xml,
      }),
    );

    await processInstancePage.gotoProcessInstancePage({
      key: runningInstance.detail.processInstanceKey,
    });
    await processInstancePage.resetZoomButton.click();
    await page.waitForTimeout(500);
    await expect(page.getByTestId(/^state-overlay/)).toHaveText('1');

    await page
      .getByRole('button', {
        name: /edit/i,
      })
      .click();
    await processInstancePage.variablesEditor.waitForEditorToLoad();

    await processInstancePage.variablesEditor.hideCaret();

    await expect(page).toHaveScreenshot();
  });

  test('instance with incident', async ({page, processInstancePage}) => {
    await page.route(
      URL_API_PATTERN,
      mockResponses({
        processInstanceDetail: instanceWithIncident.detail,
        callHierarchy: instanceWithIncident.callHierarchy,
        elementInstances: instanceWithIncident.elementInstances,
        statistics: instanceWithIncident.statistics,
        sequenceFlows: instanceWithIncident.sequenceFlows,
        variables: instanceWithIncident.variables,
        xml: instanceWithIncident.xml,
        incidents: instanceWithIncident.incidents,
      }),
    );

    await processInstancePage.gotoProcessInstancePage({
      key: instanceWithIncident.detail.processInstanceKey,
    });

    await processInstancePage.resetZoomButton.click();
    await page.waitForTimeout(500);
    await expect(page.getByTestId(/^state-overlay/)).toHaveText('1');

    await page.getByRole('link', {name: 'Incidents'}).click();

    await expect(page).toHaveScreenshot();
  });

  test('instance with incident expanded row', async ({
    page,
    processInstancePage,
  }) => {
    await page.route(
      URL_API_PATTERN,
      mockResponses({
        processInstanceDetail: instanceWithIncident.detail,
        callHierarchy: instanceWithIncident.callHierarchy,
        elementInstances: instanceWithIncident.elementInstances,
        statistics: instanceWithIncident.statistics,
        sequenceFlows: instanceWithIncident.sequenceFlows,
        variables: instanceWithIncident.variables,
        xml: instanceWithIncident.xml,
        incidents: instanceWithIncident.incidents,
      }),
    );

    await processInstancePage.gotoProcessInstancePage({
      key: instanceWithIncident.detail.processInstanceKey,
    });

    await processInstancePage.resetZoomButton.click();
    await page.waitForTimeout(500);
    await expect(page.getByTestId(/^state-overlay/)).toHaveText('1');

    await page.getByRole('link', {name: 'Incidents'}).click();

    await page.getByRole('button', {name: /expand current row/i}).click();
    await expect(page.getByText('Job ID')).toBeVisible();
    await expect(page.getByText('Error message')).toBeVisible();

    await expect(page).toHaveScreenshot();
  });

  test('completed instance', async ({page, processInstancePage}) => {
    await page.route(
      URL_API_PATTERN,
      mockResponses({
        processInstanceDetail: completedInstance.detail,
        callHierarchy: completedInstance.callHierarchy,
        elementInstances: completedInstance.elementInstances,
        statistics: completedInstance.statistics,
        sequenceFlows: completedInstance.sequenceFlows,
        variables: completedInstance.variables,
        xml: completedInstance.xml,
      }),
    );

    await processInstancePage.gotoProcessInstancePage({
      key: completedInstance.detail.processInstanceKey,
    });
    await processInstancePage.resetZoomButton.click();
    await page.waitForTimeout(500);
    await expect(page.getByTestId(/^state-overlay/)).toHaveText('1');

    await expect(processInstancePage.executionCountToggle).toBeEnabled();
    await processInstancePage.executionCountToggle.click({force: true});

    await processInstancePage.endDateToggle.click({force: true});

    await expect(page).toHaveScreenshot();
  });

  test('compensation process instance', async ({page, processInstancePage}) => {
    await page.route(
      URL_API_PATTERN,
      mockResponses({
        processInstanceDetail: compensationProcessInstance.detail,
        callHierarchy: compensationProcessInstance.callHierarchy,
        elementInstances: compensationProcessInstance.elementInstances,
        statistics: compensationProcessInstance.statistics,
        sequenceFlows: compensationProcessInstance.sequenceFlows,
        variables: compensationProcessInstance.variables,
        xml: compensationProcessInstance.xml,
      }),
    );

    await processInstancePage.gotoProcessInstancePage({
      key: compensationProcessInstance.detail.processInstanceKey,
    });
    await processInstancePage.resetZoomButton.click();
    await page.waitForTimeout(500);
    await expect(page.getByTestId(/^state-overlay/)).toHaveText('1');

    await processInstancePage.executionCountToggle.click({force: true});

    await processInstancePage.endDateToggle.click({force: true});

    await expect(page).toHaveScreenshot();
  });

  test('inline JSON view - running instance', async ({
    page,
    processInstancePage,
  }) => {
    const jsonVariable = {
      variableKey: '2251799813687144-payload',
      name: 'payload',
      value: '{"status":"active","count":42}',
      isTruncated: false,
      tenantId: '',
      processInstanceKey: '2251799813687144',
      scopeKey: '2251799813687144',
      rootProcessInstanceKey: null,
    };

    await page.route(
      URL_API_PATTERN,
      mockResponses({
        processInstanceDetail: runningInstance.detail,
        callHierarchy: runningInstance.callHierarchy,
        elementInstances: runningInstance.elementInstances,
        statistics: runningInstance.statistics,
        sequenceFlows: runningInstance.sequenceFlows,
        variables: [jsonVariable],
        xml: runningInstance.xml,
      }),
    );

    await processInstancePage.gotoProcessInstancePage({
      key: runningInstance.detail.processInstanceKey,
    });
    await processInstancePage.resetZoomButton.click();
    await page.waitForTimeout(500);
    await expect(page.getByTestId(/^state-overlay/)).toHaveText('1');

    await expect(page.getByTestId('variable-payload')).toBeVisible();

    await expect(page).toHaveScreenshot();
  });

  test('inline JSON view - scrollable', async ({page, processInstancePage}) => {
    const longJsonVariable = {
      variableKey: '2251799813687144-longPayload',
      name: 'longPayload',
      value: '{"a":1,"b":2,"c":3,"d":4,"e":5,"f":6}',
      isTruncated: false,
      tenantId: '',
      processInstanceKey: '2251799813687144',
      scopeKey: '2251799813687144',
      rootProcessInstanceKey: null,
    };

    await page.route(
      URL_API_PATTERN,
      mockResponses({
        processInstanceDetail: runningInstance.detail,
        callHierarchy: runningInstance.callHierarchy,
        elementInstances: runningInstance.elementInstances,
        statistics: runningInstance.statistics,
        sequenceFlows: runningInstance.sequenceFlows,
        variables: [longJsonVariable],
        xml: runningInstance.xml,
      }),
    );

    await processInstancePage.gotoProcessInstancePage({
      key: runningInstance.detail.processInstanceKey,
    });
    await processInstancePage.resetZoomButton.click();
    await page.waitForTimeout(500);
    await expect(page.getByTestId(/^state-overlay/)).toHaveText('1');

    await expect(page.getByTestId('variable-longPayload')).toBeVisible();

    await expect(page).toHaveScreenshot();
  });

  test('inline JSON edit - error state', async ({
    page,
    processInstancePage,
  }) => {
    const jsonVariable = {
      variableKey: '2251799813687144-payload',
      name: 'payload',
      value: '{"status":"active","count":42}',
      isTruncated: false,
      tenantId: '',
      processInstanceKey: '2251799813687144',
      scopeKey: '2251799813687144',
      rootProcessInstanceKey: null,
    };

    await page.route(
      URL_API_PATTERN,
      mockResponses({
        processInstanceDetail: runningInstance.detail,
        callHierarchy: runningInstance.callHierarchy,
        elementInstances: runningInstance.elementInstances,
        statistics: runningInstance.statistics,
        sequenceFlows: runningInstance.sequenceFlows,
        variables: [jsonVariable],
        xml: runningInstance.xml,
      }),
    );

    await processInstancePage.gotoProcessInstancePage({
      key: runningInstance.detail.processInstanceKey,
    });
    await processInstancePage.resetZoomButton.click();
    await page.waitForTimeout(500);
    await expect(page.getByTestId(/^state-overlay/)).toHaveText('1');

    await page
      .getByTestId('variable-payload')
      .getByRole('button', {name: /^edit$/i})
      .click();

    await processInstancePage.variablesEditor.waitForEditorToLoad();

    await processInstancePage.variablesEditor.clear();
    await processInstancePage.variablesEditor.fill('{invalid');

    await expect(page.getByText('Value has to be JSON')).toBeVisible();

    await processInstancePage.variablesEditor.hideCaret();

    await expect(page).toHaveScreenshot();
  });

  test('inline JSON edit - edit mode before focus', async ({
    page,
    processInstancePage,
  }) => {
    await page.route(
      URL_API_PATTERN,
      mockResponses({
        processInstanceDetail: runningInstance.detail,
        callHierarchy: runningInstance.callHierarchy,
        elementInstances: runningInstance.elementInstances,
        statistics: runningInstance.statistics,
        sequenceFlows: runningInstance.sequenceFlows,
        variables: [],
        xml: runningInstance.xml,
      }),
    );

    await processInstancePage.gotoProcessInstancePage({
      key: runningInstance.detail.processInstanceKey,
    });
    await processInstancePage.resetZoomButton.click();
    await page.waitForTimeout(500);
    await expect(page.getByTestId(/^state-overlay/)).toHaveText('1');

    await processInstancePage.addVariableButton.click();

    await processInstancePage.newVariableNameField.fill('newPayload');

    await expect(
      page
        .getByTestId('json-editor-wrapper')
        .getByTestId('json-editor-readonly'),
    ).toBeVisible();

    await expect(page).toHaveScreenshot();
  });

  test('inline JSON edit - error state after blur', async ({
    page,
    processInstancePage,
  }) => {
    const jsonVariable = {
      variableKey: '2251799813687144-payload',
      name: 'payload',
      value: '{"status":"active","count":42}',
      isTruncated: false,
      tenantId: '',
      processInstanceKey: '2251799813687144',
      scopeKey: '2251799813687144',
      rootProcessInstanceKey: null,
    };

    await page.route(
      URL_API_PATTERN,
      mockResponses({
        processInstanceDetail: runningInstance.detail,
        callHierarchy: runningInstance.callHierarchy,
        elementInstances: runningInstance.elementInstances,
        statistics: runningInstance.statistics,
        sequenceFlows: runningInstance.sequenceFlows,
        variables: [jsonVariable],
        xml: runningInstance.xml,
      }),
    );

    await processInstancePage.gotoProcessInstancePage({
      key: runningInstance.detail.processInstanceKey,
    });
    await processInstancePage.resetZoomButton.click();
    await page.waitForTimeout(500);
    await expect(page.getByTestId(/^state-overlay/)).toHaveText('1');

    await page
      .getByTestId('variable-payload')
      .getByRole('button', {name: /^edit$/i})
      .click();

    await processInstancePage.variablesEditor.waitForEditorToLoad();

    await processInstancePage.variablesEditor.clear();
    await processInstancePage.variablesEditor.fill('{invalid');

    await expect(page.getByText('Value has to be JSON')).toBeVisible();

    await processInstancePage.variablesEditor.blur();

    await expect(
      page.getByTestId('edit-variable-value-readonly'),
    ).toBeVisible();

    await expect(page).toHaveScreenshot();
  });

  test('instance history panel at its minimum width', async ({
    page,
    processInstancePage,
  }) => {
    await page.addInitScript(() => {
      window.localStorage.setItem(
        'panelStates',
        // 10% is smaller than the configured minimum width, which will override it.
        JSON.stringify({'process-instance-bottom-panel': [10, 90]}),
      );
    });

    await page.route(
      URL_API_PATTERN,
      mockResponses({
        processInstanceDetail: runningInstance.detail,
        callHierarchy: runningInstance.callHierarchy,
        elementInstances: runningInstance.elementInstances,
        statistics: runningInstance.statistics,
        sequenceFlows: runningInstance.sequenceFlows,
        variables: runningInstance.variables,
        xml: runningInstance.xml,
        incidents: runningInstance.incidents,
      }),
    );

    await processInstancePage.gotoProcessInstancePage({
      key: runningInstance.detail.processInstanceKey,
    });

    await expect(processInstancePage.instanceHistory).toBeVisible();
    await expect(
      processInstancePage.instanceHistory.getByRole('heading', {
        name: 'Instance History',
      }),
    ).toBeVisible();
    await processInstancePage.resetZoomButton.click();
    await page.waitForTimeout(500);
    await expect(page.getByTestId(/^state-overlay/)).toHaveText('1');

    await expect(page).toHaveScreenshot();
  });
});
