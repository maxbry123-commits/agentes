// Code generated - EDITING IS FUTILE. DO NOT EDIT.

package v0alpha1

// +k8s:openapi-gen=true
type GetUsageBody struct {
	Namespace string `json:"namespace"`
	Resource  string `json:"resource"`
	Group     string `json:"group"`
	Usage     int64  `json:"usage"`
	Limit     int64  `json:"limit"`
}

// NewGetUsageBody creates a new GetUsageBody object.
func NewGetUsageBody() *GetUsageBody {
	return &GetUsageBody{}
}

// OpenAPIModelName returns the OpenAPI model name for GetUsageBody.
func (GetUsageBody) OpenAPIModelName() string {
	return "com.github.grafana.grafana.apps.quotas.pkg.apis.quotas.v0alpha1.GetUsageBody"
}
