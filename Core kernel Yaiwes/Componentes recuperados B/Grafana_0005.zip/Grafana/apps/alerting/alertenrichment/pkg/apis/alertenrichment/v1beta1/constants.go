package v1beta1

import "k8s.io/apimachinery/pkg/runtime/schema"

const (
	// APIGroup is the API group used by all kinds in this package
	APIGroup = "alertenrichment.grafana.app"
	// APIVersion is the API version used by all kinds in this package
	APIVersion = "v1beta1"

	OpenAPIPrefix = "com.github.grafana.grafana.apps.alerting.alertenrichment.pkg.apis.alertenrichment.v1beta1."
)

var (
	// GroupVersion is a schema.GroupVersion consisting of the Group and Version constants for this package
	GroupVersion = schema.GroupVersion{
		Group:   APIGroup,
		Version: APIVersion,
	}
)
