import argparse
import dataclasses
import inspect
import json
import types
import typing
from typing import (
    TYPE_CHECKING,
    Any,
    AsyncGenerator,
    Dict,
    List,
    Literal,
    Optional,
    Tuple,
    Union,
)

from pydantic import BaseModel, TypeAdapter, ValidationError, field_validator
from starlette.datastructures import State
from starlette.requests import Request
from vllm.engine.arg_utils import AsyncEngineArgs
from vllm.entrypoints.openai.cli_args import FrontendArgs
from vllm.entrypoints.openai.engine.protocol import ErrorResponse as VLLMErrorResponse
from vllm.entrypoints.serve.utils.server_utils import vllm_error_handler
from vllm.exceptions import VLLMClientError, VLLMError
from vllm.v1.engine.exceptions import EngineGenerateError

import ray
from ray.llm._internal.common.callbacks.base import CallbackCtx
from ray.llm._internal.common.utils.import_utils import try_import
from ray.llm._internal.serve.constants import (
    RAY_SERVE_LLM_ENABLE_DECODE_BLOCK_PROGRESS,
)
from ray.llm._internal.serve.core.configs.llm_config import (
    DiskMultiplexConfig,
    LLMConfig,
)
from ray.llm._internal.serve.core.configs.openai_api_models import (
    ChatCompletionRequest,
    ChatCompletionResponse,
    CompletionRequest,
    CompletionResponse,
    DetokenizeRequest,
    DetokenizeResponse,
    EmbeddingRequest,
    EmbeddingResponse,
    ErrorInfo,
    ErrorResponse,
    ScoreRequest,
    ScoreResponse,
    TokenizeRequest,
    TokenizeResponse,
    TranscriptionRequest,
    TranscriptionResponse,
)
from ray.llm._internal.serve.core.engine.protocol import LLMEngine
from ray.llm._internal.serve.core.protocol import RawRequestInfo
from ray.llm._internal.serve.engines.vllm.vllm_models import VLLMEngineConfig
from ray.llm._internal.serve.observability.logging import get_logger
from ray.llm._internal.serve.routing_policies.kv_aware import (
    token_channel,
)
from ray.llm._internal.serve.routing_policies.kv_aware.kv_aware_router import (
    is_kv_aware,
)
from ray.llm._internal.serve.routing_policies.kv_aware.vllm.kv_events import (
    assign_replica_kv_events_endpoint,
    enable_native_kv_offload_events,
    get_kv_event_routing_stats,
    get_prompt_token_routing_stats,
    get_token_channel_endpoints,
)
from ray.llm._internal.serve.routing_policies.kv_aware.vllm.prompt_token_forwarding import (
    install_prompt_token_forwarding,
)
from ray.llm._internal.serve.routing_policies.kv_aware.vllm.token_tracking import (
    enable_token_tracking,
)
from ray.llm._internal.serve.utils.node_initialization_utils import initialize_node
from ray.util.placement_group import PlacementGroup
from ray.util.scheduling_strategies import PlacementGroupSchedulingStrategy

if TYPE_CHECKING:
    from vllm.config import VllmConfig
    from vllm.engine.protocol import EngineClient
    from vllm.entrypoints.openai.chat_completion.serving import OpenAIServingChat
    from vllm.entrypoints.openai.completion.serving import OpenAIServingCompletion
    from vllm.entrypoints.openai.models.serving import OpenAIServingModels
    from vllm.entrypoints.pooling.embed.serving import ServingEmbedding
    from vllm.entrypoints.pooling.scoring.serving import ServingScores
    from vllm.entrypoints.serve.tokenize.serving import ServingTokenization
    from vllm.entrypoints.speech_to_text.transcription.serving import (
        OpenAIServingTranscription,
    )

vllm = try_import("vllm")
logger = get_logger(__name__)


# TODO(jeffreywang): Remove this in vLLM 0.28.0 (#52394).
def _unwrap_client_error(exc: BaseException) -> BaseException:
    if isinstance(exc, EngineGenerateError) and isinstance(
        exc.__cause__, (ValueError, VLLMClientError)
    ):
        return exc.__cause__
    return exc


async def _unwrapping_vllm_error_handler(request: Request, exc: Exception):
    return await vllm_error_handler(request, _unwrap_client_error(exc))


def _canonicalize_request_id_header(
    request: Any, raw_request_info: Optional[RawRequestInfo]
) -> Optional[RawRequestInfo]:
    """Ensure raw_request_info carries X-Request-Id == request.request_id so vLLM's
    OpenAI layer (which prefers the header) sees the authoritative request id.

    Returns a RawRequestInfo (new or mutated) with a single, correctly-cased header.
    If the request has no request_id, this is a no-op and returns raw_request_info
    unchanged (so embeddings/score/transcription requests are unaffected).
    """
    rid = getattr(request, "request_id", None)
    if not rid:
        return raw_request_info
    headers = dict(raw_request_info.headers) if raw_request_info is not None else {}
    # Drop any existing variant of the header (case- and separator-insensitive,
    # e.g. "X-Request-Id" or "x_request_id") before setting the canonical one.
    headers = {
        k: v
        for k, v in headers.items()
        if k.replace("_", "-").lower() != "x-request-id"
    }
    headers["x-request-id"] = str(rid)
    if raw_request_info is None:
        return RawRequestInfo(headers=headers)
    # Preserve any non-header fields RawRequestInfo carries (now or in the future).
    return dataclasses.replace(raw_request_info, headers=headers)


def _get_vllm_config_type(annotation: Any) -> Optional[type]:
    """Return the config dataclass contained in a vLLM field annotation."""
    if isinstance(annotation, type) and dataclasses.is_dataclass(annotation):
        return annotation

    origin = typing.get_origin(annotation)
    annotation_args = typing.get_args(annotation)
    if origin is typing.Annotated:
        return _get_vllm_config_type(annotation_args[0])
    # Only unwrap type modifiers. Recursing through arbitrary generic types
    # could mistake a mapping of dataclasses for a config dataclass itself.
    if origin in (Union, types.UnionType):
        for annotation_arg in annotation_args:
            if config_type := _get_vllm_config_type(annotation_arg):
                return config_type
    return None


def _normalize_vllm_engine_kwargs(engine_kwargs: Dict[str, Any]) -> Dict[str, Any]:
    """Normalize structured config dictionaries as vLLM's CLI parser does."""
    fields_by_name = {
        field.name: field for field in dataclasses.fields(AsyncEngineArgs)
    }
    normalized_kwargs = engine_kwargs.copy()

    for key, value in engine_kwargs.items():
        field = fields_by_name.get(key)
        if field is None or not isinstance(value, dict):
            continue

        config_type = _get_vllm_config_type(field.type)
        if config_type is None:
            continue

        try:
            normalized_kwargs[key] = TypeAdapter(config_type).validate_python(value)
        except ValidationError as e:
            raise ValueError(f"Invalid vLLM config for {key!r}: {e}") from e

    return normalized_kwargs


def _get_vllm_engine_config(
    llm_config: LLMConfig,
    *,
    device_type: Optional[str] = None,
) -> Tuple["AsyncEngineArgs", "VllmConfig"]:
    engine_config = llm_config.get_engine_config()

    # Resolve to local cache path if model was downloaded from S3/GCS mirror
    # Only do this if mirror_config was specified (intentional S3/GCS download)
    if engine_config.mirror_config:
        from ray.llm._internal.common.utils.download_utils import (
            get_model_location_on_disk,
        )

        local_path = get_model_location_on_disk(engine_config.actual_hf_model_id)
        if local_path and local_path != engine_config.actual_hf_model_id:
            engine_config.hf_model_id = local_path
            logger.info(f"Resolved model from mirror to local path: {local_path}")

    from vllm.usage.usage_lib import UsageContext

    try:
        if device_type is not None:
            from vllm.platforms import current_platform

            current_platform.device_type = device_type

        engine_kwargs = _normalize_vllm_engine_kwargs(
            engine_config.get_initialization_kwargs()
        )
        async_engine_args = vllm.engine.arg_utils.AsyncEngineArgs(**engine_kwargs)
        vllm_engine_config = async_engine_args.create_engine_config(
            usage_context=UsageContext.OPENAI_API_SERVER
        )
    except Exception as e:
        # vLLM's ModelConfig is a pydantic dataclass; its ValidationError holds an
        # unpicklable ArgsKwargs and cannot cross the Ray task boundary. Re-raise as
        # a plain error so the real message propagates instead of a pickling failure.
        raise RuntimeError(f"Failed to create vLLM engine config: {e}") from None
    return async_engine_args, vllm_engine_config


def _clear_current_platform_cache():
    """Clear the cache of the current platform.

    vllm current has an lru cache for getting device compatibility
    that will not have the correct returned value if
    CUDA_VISIBLE_DEVICES is not set properly. In RayLLM eventually
    when we want to create the engine the env will be set properly,
    but till then, upon the import of vllm somewhere
    (which is a mystery) the lru cache will have the wrong value.
    This function will clear the cache so that the next time the
    cache is accessed, it will be re-evaluated.

    Related issues:
    https://github.com/vllm-project/vllm/issues/8402
    https://github.com/vllm-project/vllm/issues/7890
    """
    from vllm.platforms import current_platform

    # This check is just to future proof this implementation
    # in case vllm removes their lru_cache decorator
    if hasattr(current_platform.get_device_capability, "cache_clear"):
        logger.info("Clearing the current platform cache ...")
        current_platform.get_device_capability.cache_clear()


class VLLMSleepConfig(BaseModel):
    """vLLM-specific configuration for sleep operation."""

    level: int = 1
    """Sleep level:
    - Level 1: Offload weights to CPU RAM, discard KV cache
    - Level 2: Discard both model weights and KV cache (deeper sleep)
    """

    @field_validator("level")
    @classmethod
    def validate_level(cls, v: Any) -> int:
        if v not in (1, 2):
            raise ValueError("level must be 1 or 2")
        return v


class VLLMWakeupConfig(BaseModel):
    """vLLM-specific configuration for wakeup operation."""

    tags: Optional[List[str]] = None
    """Optional tags to selectively wake up components:
    - "weights": Restore model weights only
    - "kv_cache": Restore KV cache only
    - None: Restore everything
    """

    @field_validator("tags")
    @classmethod
    def validate_tags(cls, v: Any) -> Optional[List[str]]:
        if v is not None:
            valid_tags = {"weights", "kv_cache"}
            for tag in v:
                if tag not in valid_tags:
                    raise ValueError(
                        f"Invalid tag '{tag}'. Must be one of: {valid_tags}"
                    )
        return v


class VLLMPauseConfig(BaseModel):
    """vLLM-specific configuration for pause operation."""

    mode: Literal["abort", "wait", "keep"] = "abort"
    """Pause mode:
    - "abort" (default): Abort all in-flight requests immediately.
    - "wait": Wait for in-flight requests to complete before pausing.
    - "keep": Freeze requests in queue; they resume on resume_generation().
    """

    clear_cache: bool = True
    """Whether to clear KV and prefix caches after draining.
    Set to False to preserve cache for faster resume.
    """


class VLLMEngine(LLMEngine):
    def __init__(
        self,
        llm_config: LLMConfig,
    ):
        """Create a vLLM Engine class

        Args:
            llm_config: The llm configuration for this engine
        """
        super().__init__(llm_config)

        self.llm_config = llm_config

        if vllm is None:
            raise ImportError(
                "vLLM is not installed. Please install it with `pip install ray[llm]`."
            )
        assign_replica_kv_events_endpoint(self.llm_config)
        self.llm_config.setup_engine_backend()

        self._running = False
        # Routing stats advertised to Serve's request router; populated in
        # start() once the engine's KV-events and prompt-token endpoints are bound.
        self._routing_stats: Dict[str, Any] = {}
        self._prompt_token_store = token_channel.TokenStore()
        prompt_token_endpoints = get_token_channel_endpoints(self.llm_config)
        if prompt_token_endpoints is None:
            self._token_receiver = None
            self._prompt_token_zmq_advertised_endpoint = None
        else:
            bind_endpoint, advertised_endpoint = prompt_token_endpoints
            self._token_receiver = token_channel.TokenReceiver(
                bind_endpoint=bind_endpoint,
                store=self._prompt_token_store,
            )
            self._prompt_token_zmq_advertised_endpoint = advertised_endpoint

        # vLLM Integration points. Will be set through .start()
        self._engine_client = None
        self._oai_models: Optional["OpenAIServingModels"] = None
        self._oai_serving_chat: Optional["OpenAIServingChat"] = None
        self._oai_serving_completion: Optional["OpenAIServingCompletion"] = None
        self._oai_serving_embedding: Optional["ServingEmbedding"] = None
        self._oai_serving_transcription: Optional["OpenAIServingTranscription"] = None
        self._oai_serving_scores: Optional["ServingScores"] = None
        self._oai_serving_tokenization: Optional["ServingTokenization"] = None

    async def build_asgi_app(self):
        from vllm.entrypoints.openai.api_server import build_app, init_app_state

        supported_tasks = ("generate",)
        if hasattr(self._engine_client, "get_supported_tasks"):
            supported_tasks = await self._engine_client.get_supported_tasks()

        # Pass model_config so vLLM mounts the pooling routers (/pooling, /classify,
        # /embed, /score) on the native ASGI app to enable direct streaming for pooling
        # classify, embed, and score.
        app = build_app(
            self._vllm_args,
            supported_tasks=supported_tasks,
            model_config=self._engine_client.model_config,
        )
        await init_app_state(
            self._engine_client,
            app.state,
            self._vllm_args,
            supported_tasks=supported_tasks,
        )
        app.add_exception_handler(VLLMError, _unwrapping_vllm_error_handler)
        # Apply Ray's replacement handler when FastAPI builds the ASGI stack.
        # TODO(jeffreywang): Remove this when we upgrade vLLM to 0.28.0 (https://github.com/vllm-project/vllm/pull/52394).
        app.middleware_stack = None
        # On an engine error, vLLM's handler reads state.server -- the uvicorn.Server
        # its own launcher sets -- and flips should_exit on it, which is what makes
        # uvicorn stop serving and the process exit. Ray runs no uvicorn loop to
        # observe that flag (Serve restarts the replica via check_health), but the
        # read must still succeed: otherwise it raises AttributeError, and that
        # replaces the engine error in the response.
        app.state.server = types.SimpleNamespace()
        if self._token_receiver is not None:
            install_prompt_token_forwarding(
                app.state,
                self._prompt_token_store,
            )
        return app

    async def start(self) -> None:
        """Start the vLLM engine.

        If the engine is already running, do nothing.
        """

        if self._running:
            # The engine is already running!
            logger.info("Skipping engine restart because the engine is already running")
            return

        from vllm.entrypoints.openai.api_server import init_app_state

        callback = self.llm_config.get_or_create_callback()
        await callback.run_callback("on_before_node_init")
        if callback.ctx.run_init_node:
            await initialize_node(self.llm_config)
        await callback.run_callback("on_after_node_init")

        (
            vllm_engine_args,
            vllm_frontend_args,
            vllm_engine_config,
        ) = self._prepare_engine_config(callback.ctx)

        # Apply checkpoint info to the llm_config.
        # This is needed for capturing model capabilities
        # (e.g. supports vision, etc.) on the llm_config.
        config = self.llm_config.get_engine_config()
        self.llm_config.apply_checkpoint_info(
            vllm_engine_config.model_config.model,
            trust_remote_code=config.trust_remote_code,
            hf_config=vllm_engine_config.model_config.hf_config,
        )

        self._engine_client = self._start_async_llm_engine(
            vllm_engine_args,
            vllm_engine_config,
            callback.ctx.placement_group,
        )

        state = State()
        # vLLM's parser produces a flat Namespace. Its values have already been
        # parsed into their declared types; nested dictionaries stay dictionaries.
        args = argparse.Namespace(**(vars(vllm_frontend_args) | vars(vllm_engine_args)))
        self._vllm_args = args

        # Query supported tasks from the engine so init_app_state initializes the correct serving objects.
        # Without this, vLLM falls back to 'generate' only.
        init_kwargs: dict[str, Any] = dict(
            state=state,
            args=args,
        )
        if "supported_tasks" in inspect.signature(init_app_state).parameters:
            if hasattr(self._engine_client, "get_supported_tasks"):
                supported_tasks = await self._engine_client.get_supported_tasks()
                init_kwargs["supported_tasks"] = supported_tasks

        if "vllm_config" in inspect.signature(init_app_state).parameters:
            init_kwargs["vllm_config"] = vllm_engine_config

        await init_app_state(self._engine_client, **init_kwargs)

        self._oai_models = getattr(state, "openai_serving_models", None)
        self._oai_serving_chat = getattr(state, "openai_serving_chat", None)
        self._oai_serving_completion = getattr(state, "openai_serving_completion", None)
        self._oai_serving_embedding = getattr(state, "serving_embedding", None)
        self._oai_serving_transcription = getattr(
            state, "openai_serving_transcription", None
        )
        self._oai_serving_scores = getattr(state, "serving_scores", None)
        self._oai_serving_tokenization = getattr(
            state, "openai_serving_tokenization", None
        )

        self._validate_openai_serving_models()
        self._validate_engine_client()

        prompt_token_stats: Dict[str, Any] = {}
        if self._token_receiver is not None:
            if await self._token_receiver.start():
                prompt_token_stats = get_prompt_token_routing_stats(
                    self._prompt_token_zmq_advertised_endpoint
                )

        self._routing_stats = get_kv_event_routing_stats(
            self.llm_config,
            vllm_engine_config.cache_config.block_size,
            vllm_engine_config.scheduler_config.max_num_batched_tokens,
        )
        self._routing_stats.update(prompt_token_stats)

        self._running = True

        logger.info("Started vLLM engine.")

    async def shutdown(self) -> None:
        """Release the prompt-token channel's ZMQ socket and receive task."""
        if self._token_receiver is not None:
            await self._token_receiver.close()

    def routing_stats(self) -> Dict[str, Any]:
        """Returns KV event and prompt-token endpoints for KV-aware routing."""
        return self._routing_stats

    def _validate_openai_serving_models(self):
        assert self._oai_models is not None, "oai_models is not initialized"
        assert hasattr(
            self._oai_models, "lora_requests"
        ), "oai_models must have a lora_requests attribute"
        assert hasattr(
            self._oai_models, "load_lora_adapter"
        ), "oai_models must have a load_lora_adapter attribute"

    @staticmethod
    def _make_error(message: str) -> ErrorResponse:
        return ErrorResponse(
            error=ErrorInfo(message=message, type="invalid_request_error", code=400)
        )

    def _validate_openai_serving_chat(self) -> Optional[ErrorResponse]:
        if self._oai_serving_chat is None:
            return self._make_error(
                "This model does not support the 'generate' task. "
                "The chat completion endpoint is not available for this model."
            )

    def _validate_openai_serving_completion(self) -> Optional[ErrorResponse]:
        if self._oai_serving_completion is None:
            return self._make_error(
                "This model does not support the 'generate' task. "
                "The completion endpoint is not available for this model."
            )

    def _validate_openai_serving_embedding(self) -> Optional[ErrorResponse]:
        if self._oai_serving_embedding is None:
            return self._make_error(
                "This model does not support the 'embed' task. "
                "The embedding endpoint is not available for this model."
            )

    def _validate_openai_serving_transcription(self) -> Optional[ErrorResponse]:
        if self._oai_serving_transcription is None:
            return self._make_error(
                "This model does not support the 'transcription' task. "
                "The transcription endpoint is not available for this model."
            )

    def _validate_openai_serving_scores(self) -> Optional[ErrorResponse]:
        if self._oai_serving_scores is None:
            return self._make_error(
                "This model does not support the 'score' task. "
                "The score endpoint is not available for this model."
            )

    def _validate_openai_serving_tokenization(self) -> Optional[ErrorResponse]:
        if self._oai_serving_tokenization is None:
            return self._make_error(
                "This model does not support the 'tokenization' task. "
                "The tokenization endpoint is not available for this model."
            )

    def _validate_engine_client(self):
        assert hasattr(
            self._engine_client, "check_health"
        ), "engine_client must have a check_health attribute"

    def _prepare_engine_config(
        self, callback_ctx: CallbackCtx
    ) -> Tuple["AsyncEngineArgs", "FrontendArgs", "VllmConfig"]:
        """Prepare the engine config to start the engine.

        Args:
            callback_ctx: The callback context.

        Returns:
            A tuple of:
                engine_args: The vLLM's internal engine arguments that is flattened.
                frontend_args: The vLLM's internal frontend arguments that is flattened.
                engine_config: The vLLM's internal engine config that is nested.
        """

        engine_config: VLLMEngineConfig = self.llm_config.get_engine_config()

        # If the backend is anything other than CPU, we need to create the
        # engine config on a task with hardware access.
        if engine_config.accelerator.requires_remote_initialization:
            accelerator = engine_config.accelerator
            accelerator_type = self.llm_config.accelerator_type

            # Initialize options required for the remote task and hardware backend
            remote_options = {
                "num_cpus": 0,
                "runtime_env": callback_ctx.runtime_env,
                "scheduling_strategy": PlacementGroupSchedulingStrategy(
                    placement_group=callback_ctx.placement_group,
                ),
                **accelerator.get_remote_options(accelerator_type),
            }

            ref = (
                ray.remote(_get_vllm_engine_config)
                .options(**remote_options)
                .remote(self.llm_config)
            )
            vllm_engine_args, vllm_engine_config = ray.get(ref)
        else:
            vllm_engine_args, vllm_engine_config = _get_vllm_engine_config(
                self.llm_config
            )

        vllm_frontend_args = FrontendArgs(**engine_config.frontend_kwargs)
        return vllm_engine_args, vllm_frontend_args, vllm_engine_config

    def _start_async_llm_engine(
        self,
        vllm_engine_args: "AsyncEngineArgs",
        vllm_engine_config: "VllmConfig",
        placement_group: PlacementGroup,
    ) -> "EngineClient":
        """Creates an async LLM engine from the engine arguments."""

        from vllm.v1.engine.async_llm import AsyncLLM
        from vllm.v1.executor.abstract import Executor

        vllm_engine_config.parallel_config.placement_group = placement_group
        if is_kv_aware(self.llm_config):
            enable_native_kv_offload_events(vllm_engine_config)

        _clear_current_platform_cache()

        custom_stat_loggers = None
        if self.llm_config.log_engine_metrics:
            from vllm.v1.metrics.ray_wrappers import RayPrometheusStatLogger

            # V1 AsyncLLM does not yet support add_logger: https://github.com/vllm-project/vllm/issues/17702
            # Use `disable_log_stats: False` and `log_engine_metrics: False` as
            # a workaround to enable PrometheusStatLogger instead.
            custom_stat_loggers = [RayPrometheusStatLogger]

        executor_class = Executor.get_class(vllm_engine_config)
        logger.info(f"Using executor class: {executor_class}")
        # Report per-request token progress to the deployment's KV router actor,
        # but only on KV-aware deployments: elsewhere the actor never exists and
        # resolving it per request would block the engine's event loop.
        engine_cls = AsyncLLM
        if is_kv_aware(self.llm_config):
            engine_cls = enable_token_tracking(
                AsyncLLM,
                report_decode_progress=RAY_SERVE_LLM_ENABLE_DECODE_BLOCK_PROGRESS,
            )
        engine_client = engine_cls(
            vllm_config=vllm_engine_config,
            executor_class=executor_class,
            log_requests=vllm_engine_args.enable_log_requests,
            log_stats=not vllm_engine_args.disable_log_stats,
            stat_loggers=custom_stat_loggers,
        )

        return engine_client

    async def resolve_lora(self, disk_lora_model: DiskMultiplexConfig):
        from vllm.entrypoints.serve.lora.protocol import LoadLoRAAdapterRequest

        self._validate_openai_serving_models()

        if disk_lora_model.model_id in self._oai_models.lora_requests:
            # Lora is already loaded, return
            return

        lora_request = await self._oai_models.load_lora_adapter(  # type: ignore[attr-defined]
            request=LoadLoRAAdapterRequest(
                lora_name=disk_lora_model.model_id,
                lora_path=disk_lora_model.local_path,
            )
        )

        if isinstance(lora_request, VLLMErrorResponse):
            raise ValueError(f"Failed to load lora model: {lora_request.error.message}")

    @staticmethod
    def _make_error_response(
        serving: Any,
        exc: Exception,
    ) -> ErrorResponse:
        """Convert an exception to an ErrorResponse and map exception types to
        the appropriate HTTP status codes (e.g. VLLMValidationError -> 400).
        """
        # Genuine engine failures keep propagating so Serve still reports a 500.
        exc = _unwrap_client_error(exc)
        if isinstance(exc, EngineGenerateError):
            raise exc

        try:
            vllm_error = serving.create_error_response(exc)
            return ErrorResponse(error=ErrorInfo(**vllm_error.error.model_dump()))
        except Exception:
            raise exc  # re-raise the original so it surfaces as a 500

    async def chat(
        self,
        request: ChatCompletionRequest,
        raw_request_info: Optional[RawRequestInfo] = None,
    ) -> AsyncGenerator[Union[str, ChatCompletionResponse, ErrorResponse], None]:
        if error := self._validate_openai_serving_chat():
            yield error
            return

        raw_request_info = _canonicalize_request_id_header(request, raw_request_info)
        raw_request: Optional[Request] = RawRequestInfo.to_starlette_request_optional(
            raw_request_info
        )
        try:
            chat_response = await self._oai_serving_chat.create_chat_completion(  # type: ignore[attr-defined]
                request,
                raw_request=raw_request,
            )
        except (ValueError, VLLMClientError, EngineGenerateError) as e:
            yield self._make_error_response(self._oai_serving_chat, e)
            return

        if isinstance(chat_response, AsyncGenerator):
            async for response in chat_response:
                if not isinstance(response, str):
                    raise ValueError(
                        f"Expected create_chat_completion to return a stream of strings, got an item with type {type(response)}"
                    )
                yield response
        else:
            if isinstance(chat_response, VLLMErrorResponse):
                yield ErrorResponse(error=ErrorInfo(**chat_response.error.model_dump()))
            else:
                yield ChatCompletionResponse(**chat_response.model_dump())

    async def completions(
        self,
        request: CompletionRequest,
        raw_request_info: Optional[RawRequestInfo] = None,
    ) -> AsyncGenerator[Union[str, CompletionResponse, ErrorResponse], None]:
        if error := self._validate_openai_serving_completion():
            yield error
            return

        raw_request_info = _canonicalize_request_id_header(request, raw_request_info)
        raw_request: Optional[Request] = RawRequestInfo.to_starlette_request_optional(
            raw_request_info
        )
        try:
            completion_response = await self._oai_serving_completion.create_completion(  # type: ignore[attr-defined]
                request,
                raw_request=raw_request,
            )
        except (ValueError, VLLMClientError, EngineGenerateError) as e:
            yield self._make_error_response(self._oai_serving_completion, e)
            return

        if isinstance(completion_response, AsyncGenerator):
            async for response in completion_response:
                if not isinstance(response, str):
                    raise ValueError(
                        f"Expected create_completion to return a stream of strings, got an item with type {type(response)}"
                    )
                yield response
        else:
            if isinstance(completion_response, VLLMErrorResponse):
                yield ErrorResponse(
                    error=ErrorInfo(**completion_response.error.model_dump())
                )
            else:
                yield CompletionResponse(**completion_response.model_dump())

    async def embeddings(
        self,
        request: EmbeddingRequest,
        raw_request_info: Optional[RawRequestInfo] = None,
    ) -> AsyncGenerator[Union[EmbeddingResponse, ErrorResponse], None]:
        if error := self._validate_openai_serving_embedding():
            yield error
            return

        raw_request_info = _canonicalize_request_id_header(request, raw_request_info)
        raw_request: Optional[Request] = RawRequestInfo.to_starlette_request_optional(
            raw_request_info
        )
        try:
            embedding_response = await self._oai_serving_embedding(
                request,
                raw_request=raw_request,
            )
        except (ValueError, VLLMClientError, EngineGenerateError) as e:
            yield self._make_error_response(self._oai_serving_embedding, e)
            return

        # vLLM 0.18+ returns a starlette Response object
        content = json.loads(embedding_response.body)
        yield EmbeddingResponse(**content)

    async def transcriptions(
        self,
        request: TranscriptionRequest,
        raw_request_info: Optional[RawRequestInfo] = None,
    ) -> AsyncGenerator[Union[str, TranscriptionResponse, ErrorResponse], None]:
        if error := self._validate_openai_serving_transcription():
            yield error
            return

        # Extract audio data from the request file
        audio_data = await request.file.read()

        raw_request_info = _canonicalize_request_id_header(request, raw_request_info)
        raw_request: Optional[Request] = RawRequestInfo.to_starlette_request_optional(
            raw_request_info
        )
        try:
            transcription_response = await self._oai_serving_transcription.create_transcription(  # type: ignore[attr-defined]
                audio_data,
                request,
                raw_request=raw_request,
            )
        except (ValueError, VLLMClientError, EngineGenerateError) as e:
            yield self._make_error_response(self._oai_serving_transcription, e)
            return

        if isinstance(transcription_response, AsyncGenerator):
            async for response in transcription_response:
                if not isinstance(response, str):
                    raise ValueError(
                        f"Expected create_transcription to return a stream of strings, got an item with type {type(response)}"
                    )
                yield response
        else:
            if isinstance(transcription_response, VLLMErrorResponse):
                yield ErrorResponse(
                    error=ErrorInfo(**transcription_response.error.model_dump())
                )
            else:
                yield TranscriptionResponse(**transcription_response.model_dump())

    async def score(
        self,
        request: ScoreRequest,
        raw_request_info: Optional[RawRequestInfo] = None,
    ) -> AsyncGenerator[Union[ScoreResponse, ErrorResponse], None]:
        if error := self._validate_openai_serving_scores():
            yield error
            return

        raw_request_info = _canonicalize_request_id_header(request, raw_request_info)
        raw_request: Optional[Request] = RawRequestInfo.to_starlette_request_optional(
            raw_request_info
        )
        try:
            assert self._oai_serving_scores is not None
            score_response = await self._oai_serving_scores(
                request,
                raw_request=raw_request,
            )
        except (ValueError, VLLMClientError, EngineGenerateError) as e:
            yield self._make_error_response(self._oai_serving_scores, e)
            return

        content = json.loads(score_response.body)
        yield ScoreResponse(**content)

    async def tokenize(
        self,
        request: TokenizeRequest,
        raw_request_info: Optional[RawRequestInfo] = None,
    ) -> AsyncGenerator[Union[TokenizeResponse, ErrorResponse], None]:
        if error := self._validate_openai_serving_tokenization():
            yield error
            return

        raw_request_info = _canonicalize_request_id_header(request, raw_request_info)
        raw_request: Optional[Request] = RawRequestInfo.to_starlette_request_optional(
            raw_request_info
        )
        try:
            tokenize_response = await self._oai_serving_tokenization.create_tokenize(
                request,
                raw_request=raw_request,
            )
        except (ValueError, VLLMClientError, EngineGenerateError) as e:
            yield self._make_error_response(self._oai_serving_tokenization, e)
            return

        if isinstance(tokenize_response, VLLMErrorResponse):
            yield ErrorResponse(error=ErrorInfo(**tokenize_response.error.model_dump()))
        else:
            yield TokenizeResponse(**tokenize_response.model_dump())

    async def detokenize(
        self,
        request: DetokenizeRequest,
        raw_request_info: Optional[RawRequestInfo] = None,
    ) -> AsyncGenerator[Union[DetokenizeResponse, ErrorResponse], None]:
        if error := self._validate_openai_serving_tokenization():
            yield error
            return

        raw_request_info = _canonicalize_request_id_header(request, raw_request_info)
        raw_request: Optional[Request] = RawRequestInfo.to_starlette_request_optional(
            raw_request_info
        )
        try:
            detokenize_response = (
                await self._oai_serving_tokenization.create_detokenize(
                    request,
                    raw_request=raw_request,
                )
            )
        except (ValueError, VLLMClientError, EngineGenerateError) as e:
            yield self._make_error_response(self._oai_serving_tokenization, e)
            return

        if isinstance(detokenize_response, VLLMErrorResponse):
            yield ErrorResponse(
                error=ErrorInfo(**detokenize_response.error.model_dump())
            )
        else:
            yield DetokenizeResponse(**detokenize_response.model_dump())

    async def check_health(self) -> None:
        assert self._engine_client is not None, "engine_client is not initialized"

        try:
            await self._engine_client.check_health()
        except BaseException as e:
            logger.error("Healthcheck failed. The replica will be restarted")
            raise e from None

    async def reset_prefix_cache(self) -> None:
        assert self._engine_client is not None, "engine_client is not initialized"
        await self._engine_client.reset_prefix_cache()

    async def sleep(self, **kwargs: Any) -> None:
        """Put the vLLM engine to sleep.

        Args:
            **kwargs: Options parsed into VLLMSleepConfig.
                - level (int): Sleep level (1 or 2). Default 1.
        """
        assert self._engine_client is not None, "engine_client is not initialized"
        config = VLLMSleepConfig(**kwargs)
        await self._engine_client.sleep(level=config.level)

    async def wakeup(self, **kwargs: Any) -> None:
        """Wake up the vLLM engine from sleep mode.

        Args:
            **kwargs: Options parsed into VLLMWakeupConfig.
                - tags (List[str], optional): Components to wake up.
        """
        assert self._engine_client is not None, "engine_client is not initialized"
        config = VLLMWakeupConfig(**kwargs)
        await self._engine_client.wake_up(tags=config.tags)

    async def is_sleeping(self) -> bool:
        """Check whether the vLLM engine is currently sleeping.

        Returns:
            True if the engine is sleeping, False otherwise.
        """
        assert self._engine_client is not None, "engine_client is not initialized"
        return await self._engine_client.is_sleeping()

    async def pause(self, **kwargs: Any) -> None:
        """Pause generation on the vLLM engine.

        This halts generation/encoding requests while keeping model weights
        in GPU memory. New requests are blocked until resume is called.

        Args:
            **kwargs: Options parsed into VLLMPauseConfig.
                - mode (str): "abort" (default), "wait", or "keep".
                - clear_cache (bool): Clear KV cache after draining. Default True.
        """
        assert self._engine_client is not None, "engine_client is not initialized"
        config = VLLMPauseConfig(**kwargs)
        await self._engine_client.pause_generation(
            mode=config.mode,
            clear_cache=config.clear_cache,
        )

    async def resume(self, **kwargs: Any) -> None:
        """Resume generation on the vLLM engine after pause.

        Args:
            **kwargs: Reserved for future options.
        """
        assert self._engine_client is not None, "engine_client is not initialized"
        await self._engine_client.resume_generation()

    async def is_paused(self) -> bool:
        """Check whether the vLLM engine is currently paused.

        Returns:
            True if the engine is paused, False otherwise.
        """
        assert self._engine_client is not None, "engine_client is not initialized"
        return await self._engine_client.is_paused()

    async def start_profile(self) -> None:
        assert self._engine_client is not None, "engine_client is not initialized"
        await self._engine_client.start_profile()

    async def stop_profile(self) -> None:
        assert self._engine_client is not None, "engine_client is not initialized"
        await self._engine_client.stop_profile()

    async def collective_rpc(
        self,
        method: str,
        timeout: Optional[float] = None,
        args: tuple = (),
        kwargs: Optional[dict] = None,
    ) -> list:
        """Execute a collective RPC call on all vLLM workers.

        This is used for RLHF workflows where a trainer needs to execute
        methods on all TP/PP workers (e.g., for weight synchronization).

        Args:
            method: Name of the worker method to execute.
            timeout: Maximum time in seconds to wait for execution.
            args: Positional arguments to pass to the worker method.
            kwargs: Keyword arguments to pass to the worker method.

        Returns:
            A list containing the results from each worker.
        """
        assert self._engine_client is not None, "engine_client is not initialized"
        return await self._engine_client.collective_rpc(
            method=method,
            timeout=timeout,
            args=args,
            kwargs=kwargs or {},
        )
