import collections
import copy
import logging
import os
import traceback
from typing import Any, Dict, List, Optional, Union

import ray
from ray._private.ray_constants import env_float
from ray._private.state import state as ray_state
from ray.actor import ActorHandle
from ray.exceptions import RayActorError
from ray.runtime_env import RuntimeEnv
from ray.train.v2._internal.constants import (
    COLLECTIVE_TIMEOUT_S_ENV_VAR,
    COLLECTIVE_WARN_INTERVAL_S_ENV_VAR,
    DEFAULT_COLLECTIVE_TIMEOUT_S,
    DEFAULT_COLLECTIVE_WARN_INTERVAL_S,
    DEFAULT_WORKER_GROUP_START_TIMEOUT_S,
    DEFAULT_WORKER_HEALTH_CHECK_TIMEOUT_S,
    WORKER_GROUP_START_TIMEOUT_S_ENV_VAR,
    WORKER_HEALTH_CHECK_TIMEOUT_S_ENV_VAR,
    get_env_vars_to_propagate,
)
from ray.train.v2._internal.exceptions import (
    InsufficientClusterResourcesError,
    WorkerGroupStartupFailedError,
    WorkerGroupStartupTimeoutError,
    WorkerHealthCheckFailedError,
    WorkerHealthCheckTimeoutError,
)
from ray.train.v2._internal.execution.callback import (
    ExecutionGroupCallback,
    ReplicaGroupCallback,
    TrainContextCallback,
    WorkerCallback,
    WorkerGroupCallback,
)
from ray.train.v2._internal.execution.checkpoint.sync_actor import SynchronizationActor
from ray.train.v2._internal.execution.context import (
    DistributedContext,
    TrainRunContext,
)
from ray.train.v2._internal.execution.worker_group.execution_group import (
    ExecutionGroup,
    ReplicaGroup,
)
from ray.train.v2._internal.execution.worker_group.placement_group_handle import (
    DefaultPlacementGroupHandle,
    PlacementGroupHandle,
    SlicePlacementGroupHandle,
)
from ray.train.v2._internal.execution.worker_group.poll import (
    PollTask,
    WorkerGroupPollStatus,
)
from ray.train.v2._internal.execution.worker_group.state import (
    WorkerGroupContext,
    WorkerGroupState,
    WorkerGroupStateBuilder,
)
from ray.train.v2._internal.execution.worker_group.worker import (
    RayTrainWorker,
    Worker,
    WorkerStatus,
)
from ray.train.v2._internal.logging.logging import get_train_application_worker_log_path
from ray.train.v2._internal.util import (
    bundle_to_remote_args,
    invoke_context_managers,
    time_monotonic,
)
from ray.train.v2.api.config import ScalingConfig
from ray.types import ObjectRef
from ray.util.placement_group import PlacementGroup, placement_group
from ray.util.scheduling_strategies import (
    PlacementGroupSchedulingStrategy,
)
from ray.util.tpu import (
    SlicePlacementGroup,
    get_current_pod_name,
    get_tpu_version_from_type,
)

logger = logging.getLogger(__name__)


_SERIALIZATION_FAILURE_MARKERS = (
    "cannot pickle",
    "Cannot pickle",
    "cannot serialize",
    "Can't pickle",
    "PicklingError",
    "ray/cloudpickle/cloudpickle.py",
)


class WorkerGroup(ExecutionGroup):
    _worker_cls = RayTrainWorker

    @classmethod
    def create(
        cls,
        train_run_context: TrainRunContext,
        worker_group_context: WorkerGroupContext,
        callbacks: Optional[
            List[Union[WorkerGroupCallback, WorkerCallback, TrainContextCallback]]
        ] = None,
    ) -> "WorkerGroup":
        """Create and start a new worker group.

        Args:
            train_run_context: The training run context.
            worker_group_context: The worker group context.
            callbacks: Optional callbacks to attach.

        Returns:
            An active WorkerGroup instance.

        Raises:
            WorkerGroupStartupTimeoutError: If worker group startup times out.
            WorkerGroupStartupFailedError: If worker group fails to start.
        """

        worker_group = cls(train_run_context, worker_group_context, callbacks)
        worker_group._start()
        return worker_group

    def __init__(
        self,
        train_run_context: TrainRunContext,
        worker_group_context: WorkerGroupContext,
        callbacks: Optional[
            List[Union[WorkerGroupCallback, WorkerCallback, TrainContextCallback]]
        ] = None,
    ):
        """Initialize a WorkerGroup instance.

        Note: This should not be called directly. Use WorkerGroup.create() instead.
        """
        self._train_run_context = train_run_context
        run_config = self._train_run_context.run_config
        self._storage_context = run_config.storage_context

        self._worker_group_context: WorkerGroupContext = worker_group_context

        callbacks = callbacks or []
        # Group of callbacks that are specific to worker group itself.
        self._callbacks = [c for c in callbacks if isinstance(c, WorkerGroupCallback)]
        # Group of callbacks for replica group lifecycle events.
        self._replica_group_callbacks = [
            c for c in callbacks if isinstance(c, ReplicaGroupCallback)
        ]
        self._execution_group_callbacks = [
            c for c in callbacks if isinstance(c, ExecutionGroupCallback)
        ]
        # Group of callbacks that will be propagated and called on the worker actors.
        self._worker_callbacks_to_propagate = [
            c
            for c in callbacks
            if isinstance(c, (WorkerCallback, TrainContextCallback))
        ]

        self._worker_group_state: Optional[WorkerGroupState] = None
        self._replica_groups: Optional[List[ReplicaGroup]] = None
        # Maps world rank to replica group index.
        self._worker_rank_to_replica_group_rank: Optional[Dict[int, int]] = None
        # Tracks ongoing poll tasks by world rank.
        self._world_rank_to_ongoing_poll: Dict[int, PollTask] = {}
        self._latest_poll_status: Optional[WorkerGroupPollStatus] = None

        # Environment variables
        self._worker_group_start_timeout_s = float(
            os.environ.get(
                WORKER_GROUP_START_TIMEOUT_S_ENV_VAR,
                DEFAULT_WORKER_GROUP_START_TIMEOUT_S,
            )
        )
        self._worker_health_check_timeout_s = float(
            os.getenv(
                WORKER_HEALTH_CHECK_TIMEOUT_S_ENV_VAR,
                DEFAULT_WORKER_HEALTH_CHECK_TIMEOUT_S,
            )
        )
        self._collective_timeout_s = env_float(
            COLLECTIVE_TIMEOUT_S_ENV_VAR, DEFAULT_COLLECTIVE_TIMEOUT_S
        )
        self._collective_warn_interval_s = env_float(
            COLLECTIVE_WARN_INTERVAL_S_ENV_VAR,
            DEFAULT_COLLECTIVE_WARN_INTERVAL_S,
        )

        # Whether the worker group will manage replica groups.
        self._manages_replica_groups = (
            train_run_context.backend_config.backend_cls.has_replica_groups
            if train_run_context.backend_config
            else False
        )

    ################################################################################
    # Start Worker Group
    ################################################################################

    def _start(
        self,
    ):
        """Internal method to start the worker group."""

        worker_group_state_builder = WorkerGroupStateBuilder()

        try:
            self._start_impl(
                worker_group_state_builder,
            )
        except Exception as e:
            if not self.has_started():
                # Clean up partial worker group state.
                worker_group_state_builder.shutdown()
            raise e

        assert self.has_started(), "Worker group failed to start."

    @staticmethod
    def _check_cluster_resources_and_raise_if_insufficient(
        resources_per_worker: Dict[str, float], num_workers: int
    ) -> None:
        """Check if the cluster has enough resources before waiting for placement group.

        Args:
            resources_per_worker: The resources per worker.
            num_workers: The number of workers.
        """
        max_cluster_resources = ray_state.get_max_resources_from_cluster_config()
        if not max_cluster_resources:
            return

        for (
            resource_name,
            required_amount,
        ) in resources_per_worker.items():
            total_required_amount = required_amount * num_workers
            available_amount = max_cluster_resources.get(resource_name, 0)
            if total_required_amount > available_amount:
                error_msg = (
                    "Insufficient cluster resources to launch training workers.\n"
                    f'The worker group requires {{"{resource_name}": {total_required_amount}}} but the cluster only has a maximum of {{"{resource_name}": {available_amount}}} resources.\n'
                    "Please reduce `num_workers`, lower resource requirements, or increase the cluster size."
                )
                raise InsufficientClusterResourcesError(error_msg)

    def _start_impl(
        self,
        worker_group_state_builder: WorkerGroupStateBuilder,
    ):
        """Implementation of worker group startup.

        Args:
            worker_group_state_builder: Builder for constructing worker group state.

        Raises:
            ValueError: If workers are already started.
            WorkerGroupStartupTimeoutError: If startup times out requesting resources.
            WorkerGroupStartupFailedError: If workers fail during initialization.
        """
        self._assert_inactive()
        worker_group_context = self._worker_group_context
        start_time = time_monotonic()

        # Check that we have sufficient resources in the cluster before waiting for
        # a placement group.
        WorkerGroup._check_cluster_resources_and_raise_if_insufficient(
            worker_group_context.resources_per_worker,
            worker_group_context.num_workers,
        )

        # TODO: Review the order of `on_xyz_start` and `after_xyz_start` callbacks.
        # The current execution order is as follows:`on_worker_group_start` callbacks
        # are triggered before the `after_worker_group_start` callbacks.
        with invoke_context_managers(
            [callback.on_worker_group_start for callback in self._callbacks]
        ):
            for callback in self._callbacks:
                callback.before_worker_group_start(worker_group_context)

            pg_handle = self._create_placement_group(
                self._train_run_context.scaling_config, worker_group_context
            )

            logger.info(
                f"Attempting to start training worker group of size {worker_group_context.num_workers} with "
                f"the following resources: [{worker_group_context.resources_per_worker}] * {worker_group_context.num_workers}"
            )

            # Wait for the placement group to be ready before proceeding
            # to create actors.
            # This could hang if the resources are not available, so we should
            # time out if this hangs for a while to try again with a different size.
            # For example, the controller may try to set a worker group size
            # based on stale information about cluster resources.
            pg_wait_start = time_monotonic()
            if not pg_handle.wait(self._worker_group_start_timeout_s):
                pg_handle.shutdown()
                raise WorkerGroupStartupTimeoutError(
                    num_workers=worker_group_context.num_workers
                )
            logger.debug(
                "[Worker Group Initialization] Placement group ready in "
                f"{time_monotonic() - pg_wait_start:.2f}s."
            )

            # TODO: Figure out ordering between these different calls/callbacks.
            worker_group_state_builder.with_placement_group_handle(pg_handle)

            # Initialize the synchronization actor on the driver node
            sync_actor = SynchronizationActor.options(
                label_selector={
                    ray._raylet.RAY_NODE_ID_KEY: ray.get_runtime_context().get_node_id()
                }
            ).remote(
                timeout_s=self._collective_timeout_s,
                warn_interval_s=self._collective_warn_interval_s,
            )
            worker_group_state_builder.with_sync_actor(sync_actor)

            # Create workers and (if applicable) replica groups.
            create_workers_start = time_monotonic()
            # TODO: change after we support replica groups of size > 1.
            workers = self._create_workers(
                worker_group_context.num_workers,
                pg_handle.placement_group,
                worker_group_context.resources_per_worker,
                replica_group_size=1 if self._manages_replica_groups else None,
            )
            logger.debug(
                f"[Worker Group Initialization] {worker_group_context.num_workers} worker actors created in "
                f"{time_monotonic() - create_workers_start:.2f}s."
            )
            self._replica_groups = [
                ReplicaGroup(
                    # TODO: change after we support replica groups of size > 1.
                    [worker],
                    worker_group_context.resources_per_worker,
                    self._replica_group_callbacks,
                )
                for worker in workers
            ]
            self._worker_rank_to_replica_group_rank = {
                worker.distributed_context.world_rank: i
                for i, rg in enumerate(self._replica_groups)
                for worker in rg.get_workers()
            }
            worker_group_state_builder.with_workers(workers)

            # All the ray.get calls in this try block can possibly error if the
            # worker actors die during initialization.
            # To prevent the driver from crashing, catch all `RayActorError`s and
            # raise a specially handled error to the controller.
            try:
                self._init_train_context(workers, sync_actor)

                self._worker_group_state = worker_group_state_builder.build()

                after_wg_start_cb_start = time_monotonic()
                after_wg_start_cb_times = {}
                for callback in self._callbacks:
                    cb_start = time_monotonic()
                    callback.after_worker_group_start(self)
                    after_wg_start_cb_times[type(callback).__name__] = (
                        time_monotonic() - cb_start
                    )
                after_wg_start_cb_breakdown = "\n".join(
                    f"    {name}: {elapsed:.2f}s"
                    for name, elapsed in after_wg_start_cb_times.items()
                )
                logger.debug(
                    "[Worker Group Initialization] after_worker_group_start "
                    f"callbacks completed in {time_monotonic() - after_wg_start_cb_start:.2f}s.\n"
                    f"  Individual callback time breakdown:\n{after_wg_start_cb_breakdown}"
                )

            except RayActorError as actor_error:
                error_msg = "At least one of the worker actors failed to initialize."
                raise WorkerGroupStartupFailedError(error_msg) from actor_error

        # Launch the training function on each worker.
        # This task should start a worker thread and return immediately.
        launch_start = time_monotonic()
        ray.get(
            [
                worker.actor.run_train_fn.remote(worker_group_context.train_fn_ref)
                for worker in workers
            ]
        )
        logger.debug(
            "[Worker Group Initialization] Train function launched on "
            f"workers in {time_monotonic() - launch_start:.2f}s."
        )

        workers_info = "\n".join(
            [
                f"- (ip={w.metadata.node_ip}, pid={w.metadata.pid}) "
                f"world_rank={w.distributed_context.world_rank}, "
                f"local_rank={w.distributed_context.local_rank}, "
                f"node_rank={w.distributed_context.node_rank}"
                for w in workers
            ]
        )

        after_training_start_cb_start = time_monotonic()
        after_training_start_cb_times = {}
        for callback in self._callbacks:
            cb_start = time_monotonic()
            callback.after_worker_group_training_start(self)
            after_training_start_cb_times[type(callback).__name__] = (
                time_monotonic() - cb_start
            )
        after_training_start_cb_breakdown = "\n".join(
            f"    {name}: {elapsed:.2f}s"
            for name, elapsed in after_training_start_cb_times.items()
        )
        logger.debug(
            "[Worker Group Initialization] after_worker_group_training_start "
            f"callbacks completed in {time_monotonic() - after_training_start_cb_start:.2f}s.\n"
            f"  Individual callback time breakdown:\n{after_training_start_cb_breakdown}"
        )

        logger.debug(
            "[Worker Group Initialization] Worker group startup completed in "
            f"{time_monotonic() - start_time:.2f}s total."
        )

        logger.info(
            f"Started training worker group of size {len(workers)}: \n{workers_info}"
        )

    def _create_workers(
        self,
        num_workers: int,
        placement_group: PlacementGroup,
        resources_per_worker: Dict[str, float],
        placement_group_bundle_indices: Optional[List[int]] = None,
        starting_world_rank: int = 0,
        world_size: Optional[int] = None,
        replica_group_size: Optional[int] = None,
    ) -> List[Worker]:
        """Create worker actors at placement group bundle indices.

        Args:
            num_workers: Number of workers to create.
            placement_group: The placement group to schedule workers in.
            resources_per_worker: Resources per worker.
            placement_group_bundle_indices: Optional explicit bundle indices to use.
                If None, uses range(num_workers).
            starting_world_rank: The starting world rank for this list of
                workers. Note that world rank is global across replica groups
                (so we can make only replica group 0 checkpoint) but local rank
                is local to (node, replica group) pairs (every replica group has
                different data, so all local rank 0's must download data to node).
            world_size: The total world size of the worker group.
                If None, uses the number of workers.
            replica_group_size: If set, workers are divided into replica groups
                of this size. num_workers must be divisible by this value.
                local_rank and local_world_size are computed per
                (node, replica group) pair. If None, all workers are treated
                as a single group.

        Returns:
            Sorted list of Workers sorted by world_rank.
        """
        indices = (
            placement_group_bundle_indices
            if placement_group_bundle_indices is not None
            else list(range(num_workers))
        )

        runtime_env = self._get_worker_runtime_env(
            custom_runtime_env=self._train_run_context.run_config.worker_runtime_env
        )
        worker_actor_cls = ray.remote(
            runtime_env=runtime_env,
            **bundle_to_remote_args(resources_per_worker),
        )(self._worker_cls)

        actors = [
            worker_actor_cls.options(
                scheduling_strategy=PlacementGroupSchedulingStrategy(
                    placement_group=placement_group, placement_group_bundle_index=i
                ),
            ).remote()
            for i in indices
        ]

        try:
            actor_metadatas = ray.get([actor.get_metadata.remote() for actor in actors])
        except RayActorError as actor_error:
            for actor in actors:
                ray.kill(actor)

            error_msg = (
                "One of the worker actors failed to initialize due to error:\n"
                f"{traceback.format_exc()}"
            )
            raise WorkerGroupStartupFailedError(error_msg) from actor_error

        workers = [
            Worker(actor, meta, resources_per_worker, placement_group_bundle_index=idx)
            for idx, actor, meta in zip(indices, actors, actor_metadatas)
        ]

        return WorkerGroup._assign_worker_ranks(
            workers, starting_world_rank, world_size, replica_group_size
        )

    def _init_train_context(
        self,
        workers: List[Worker],
        sync_actor: ActorHandle,
    ) -> None:
        """Collect train context args from callbacks and initialize train context.

        This method is used by both _start_impl (for full worker group startup)
        and replace_replica_group (for partial replica replacement).

        Args:
            workers: The workers to initialize.
            sync_actor: The synchronization actor.
        """
        before_init_train_context_cb_start = time_monotonic()
        train_context_args: Dict[str, List[Any]] = {}
        for cb in self._execution_group_callbacks:
            args = cb.before_init_train_context(workers)
            for arg, arg_values in args.items():
                assert len(arg_values) == len(workers), (
                    f"Callback {cb} returned {arg} with "
                    f"{len(arg_values)} values, expected {len(workers)}."
                )
                assert (
                    arg not in train_context_args
                ), f"Callback {cb} returned {arg} which is already set."
                train_context_args[arg] = arg_values
        logger.debug(
            "[Worker Group Initialization] before_init_train_context "
            f"callbacks completed in {time_monotonic() - before_init_train_context_cb_start:.2f}s."
        )

        init_ctx_start = time_monotonic()
        self._init_train_context_on_workers(workers, sync_actor, train_context_args)
        logger.debug(
            "[Worker Group Initialization] Train context initialized "
            f"on workers in {time_monotonic() - init_ctx_start:.2f}s."
        )

    def _init_train_context_on_workers(
        self,
        workers: List[Worker],
        sync_actor: ActorHandle,
        train_context_args: Dict[str, List[Any]],
    ) -> None:
        context_init_tasks = [
            worker.actor.init_train_context.remote(
                train_run_context=self._train_run_context,
                distributed_context=worker.distributed_context,
                synchronization_actor=sync_actor,
                storage_context=self._storage_context,
                worker_callbacks=self._worker_callbacks_to_propagate,
                controller_actor=ray.get_runtime_context().current_actor,
                **{
                    arg: arg_values[i] for arg, arg_values in train_context_args.items()
                },
            )
            for i, worker in enumerate(workers)
        ]
        ray.get(context_init_tasks)

        self._decorate_worker_log_file_paths(workers)

    def _create_placement_group(
        self,
        scaling_config: ScalingConfig,
        worker_group_context: WorkerGroupContext,
    ) -> PlacementGroupHandle:
        """Creates and returns a placement group handle for the worker group.

        If TPU resources are requested, this uses `SlicePlacementGroup` to reserve
        resources. Otherwise, it creates a standard placement group.
        """

        if (
            scaling_config.use_tpu
            and scaling_config.topology
            and scaling_config.accelerator_type
        ):
            # TPU specific SlicePlacementGroup reservation.
            logger.info(
                f"Using SlicePlacementGroup utility to reserve {worker_group_context.num_slices} "
                f"slice(s) with topology '{scaling_config.topology}'..."
            )

            try:
                accelerator_version = get_tpu_version_from_type(
                    scaling_config.accelerator_type
                )
                spg = SlicePlacementGroup(
                    topology=scaling_config.topology,
                    accelerator_version=accelerator_version,
                    num_slices=worker_group_context.num_slices,
                    resources_per_bundle=worker_group_context.resources_per_worker,
                    strategy=worker_group_context.placement_strategy,
                    head_reservation_timeout_s=self._worker_group_start_timeout_s,
                )

                return SlicePlacementGroupHandle(spg)

            except TimeoutError as e:
                # Unlike the default placement group path, ``SlicePlacementGroup``
                # synchronously reserves a TPU head placement group inside its
                # constructor and raises ``TimeoutError`` when the cluster does
                # not yet have enough TPU capacity (e.g. autoscaler is still
                # bringing up nodes). Convert this into the standard
                # ``WorkerGroupStartupTimeoutError`` so the controller retries
                # via SCHEDULING -> RESCHEDULING instead of failing the run.
                raise WorkerGroupStartupTimeoutError(
                    num_workers=worker_group_context.num_workers
                ) from e
            except Exception as e:
                raise WorkerGroupStartupFailedError(
                    f"Failed to reserve TPU slice(s): {e}"
                ) from e

        pg = placement_group(
            # TODO: support heterogeneous workers and placement
            bundles=[worker_group_context.resources_per_worker]
            * worker_group_context.num_workers,
            strategy=worker_group_context.placement_strategy,
            bundle_label_selector=worker_group_context.label_selector,
        )
        return DefaultPlacementGroupHandle(pg)

    #####################################################################################
    # Shutdown Worker Group
    #####################################################################################

    def shutdown(self):
        """Shutdown all the workers in this worker group."""
        self._assert_active()

        with invoke_context_managers(
            [callback.on_worker_group_shutdown for callback in self._callbacks]
        ):
            if self.has_started():
                for callback in self._callbacks:
                    callback.before_worker_group_shutdown(self)

                self._worker_group_state.shutdown()

            self._clear_state()

            logger.debug("Worker group shutdown successful.")

            for callback in self._callbacks:
                callback.after_worker_group_shutdown(self._worker_group_context)

    def _clear_state(self):
        self._worker_group_state = None
        self._replica_groups = None
        self._worker_rank_to_replica_group_rank = None
        self._world_rank_to_ongoing_poll.clear()

    def abort(self):
        """Abort the worker group."""
        self._assert_active()
        for callback in self._callbacks:
            callback.before_worker_group_abort(self._worker_group_context)

        # TODO: Add shutdown callback hooks

        self._worker_group_state.shutdown()
        self._clear_state()

        for callback in self._callbacks:
            callback.after_worker_group_abort(self._worker_group_context)

    #####################################################################################
    # Polling Worker Group
    #####################################################################################

    def poll_status(self, timeout: Optional[float] = None) -> WorkerGroupPollStatus:
        """Poll the status of all workers in the worker group.

        Args:
            timeout: The maximum time to wait for the poll tasks to complete.

        Returns:
            A ``WorkerGroupPollStatus`` aggregating each worker's status.
        """
        self._assert_active()

        poll_results = self._poll_workers_and_collect_errors(timeout)

        worker_group_poll_status = WorkerGroupPollStatus(
            worker_statuses=dict(enumerate(poll_results)),
            worker_rank_to_replica_group_rank=self._worker_rank_to_replica_group_rank,
        )

        for callback in self._callbacks:
            callback.after_worker_group_poll_status(worker_group_poll_status)

        self._latest_poll_status = worker_group_poll_status
        return worker_group_poll_status

    def _poll_workers_and_collect_errors(
        self, timeout: Optional[float]
    ) -> List[WorkerStatus]:
        """Launch poll tasks on each worker and collect the results.

        The poll task should involve very little computation and should
        return almost immediately.

        If a worker does not return the result of the poll task within
        the timeout, it is considered as a missed health check.
        The timeout is set to ~seconds, so a missed health check usually
        means that something is wrong with the worker.
        Subsequent calls to poll the worker will continue waiting on the
        hanging poll task.

        If a worker's health check hangs for too long, it is marked as dead
        and a WorkerHealthCheckTimeoutError is propagated as the error in the
        worker status for the controller to handle.

        If a worker's poll task fails, a WorkerHealthCheckFailedError is similarly
        propagated in the worker status.

        Args:
            timeout: The maximum time to wait for the poll tasks to complete.

        Returns:
            poll_results: A list of WorkerStatus objects.
                If polling a certain worker hangs or fails, the corresponding
                WorkerStatus object will include a system error mentioned above.
        """
        workers = self.get_workers()
        start_time = time_monotonic()
        poll_tasks = self._get_poll_tasks()
        poll_task_to_world_rank = {
            poll_task: i for i, poll_task in enumerate(poll_tasks)
        }
        done_polls, hanging_polls = ray.wait(
            list(poll_task_to_world_rank),
            num_returns=len(poll_task_to_world_rank),
            timeout=timeout,
        )

        poll_task_to_result = {}

        for hanging_poll in hanging_polls:
            hanging_rank = poll_task_to_world_rank[hanging_poll]

            # The hanging poll task should be saved and awaited in the next round.
            # Save the start time of the poll task to check for timeouts.
            # Don't overwrite the ongoing poll task if it already exists.
            ongoing_poll = self._world_rank_to_ongoing_poll.setdefault(
                hanging_rank, PollTask(start_time=start_time, task=hanging_poll)
            )

            error = None
            elapsed_time_s = time_monotonic() - ongoing_poll.start_time
            if elapsed_time_s > self._worker_health_check_timeout_s:
                error_msg = (
                    f"A worker health check has been hanging for {elapsed_time_s:.2f} "
                    "seconds. Marking the worker as dead.\n"
                    f"Worker info: {workers[hanging_rank]}"
                )
                error = WorkerHealthCheckTimeoutError(error_msg)

            poll_task_to_result[hanging_poll] = WorkerStatus(
                running=True, error=error, training_report=None
            )

        for done_poll in done_polls:
            done_rank = poll_task_to_world_rank[done_poll]

            # Remove the ongoing poll task for the worker.
            self._world_rank_to_ongoing_poll.pop(done_rank, None)

            try:
                poll_result: WorkerStatus = ray.get(done_poll)
            except Exception as e:
                error_msg = (
                    "A worker health check failed.\n"
                    f"Worker info: {workers[done_rank]}"
                )

                # The ray.get can fail for serialization / deserialization, adds a hint to users.
                try:
                    exception_msg = str(e)

                    if any(
                        marker in exception_msg
                        for marker in _SERIALIZATION_FAILURE_MARKERS
                    ):
                        error_msg += (
                            "\nHint: This is a failure to serialize a value that "
                            "the training function produced, which is needed to "
                            "send it back to the Ray Train controller. "
                            "Ray Train checks the most common cases up front, "
                            "but cannot cover every type. "
                            "Look for non-serializable objects in: \n"
                            " (1) the `metrics` passed to `ray.train.report()`,\n"
                            " (2) the value returned by the training function, and\n"
                            " (3) exceptions raised by the training function.\n"
                            "The traceback below shows the object that failed to serialize."
                        )
                except Exception:
                    error_msg += "\nFailed to convert the exception to a string."

                poll_result = WorkerStatus(
                    running=False,
                    error=WorkerHealthCheckFailedError(error_msg, failure=e),
                    training_report=None,
                )

            poll_task_to_result[done_poll] = poll_result

        # Collect the results and errors in the order of the workers.
        results = [
            poll_task_to_result.get(poll_task) for poll_task in poll_task_to_world_rank
        ]
        return results

    def _get_poll_tasks(self) -> List[ObjectRef]:
        """Get the poll tasks for each worker.

        If there is an ongoing poll task for a worker that did not finish
        in the timeout on the previous round, return that task instead of
        queueing up a new one.

        Spawns a new poll task for the worker if there is no ongoing poll task.
        """
        workers = self.get_workers()
        poll_tasks = []
        for i, worker in enumerate(workers):
            ongoing_poll = self._world_rank_to_ongoing_poll.get(i)
            if ongoing_poll is not None:
                poll_tasks.append(ongoing_poll.task)
            else:
                poll_tasks.append(worker.actor.poll_status.remote())
        return poll_tasks

    #####################################################################################
    # Replica Group Replacement
    #####################################################################################

    def replace_replica_group(self, replica_group_index: int):
        """Replace a failing replica group with new workers at the same placement
        group slots.

        Args:
            replica_group_index: The index of the replica group to replace.
        """
        self._assert_active()
        try:
            self._replace_replica_group_impl(replica_group_index)
        except Exception as e:
            self._replica_groups[replica_group_index].shutdown()
            raise e

    def _replace_replica_group_impl(self, replica_group_index: int):
        """replace_replica_group is simple wrapper around this method."""

        # Save old replica group state.
        old_replica_group = self._replica_groups[replica_group_index]
        old_workers = old_replica_group.get_workers()
        old_placement_group_bundle_indices = [
            w.placement_group_bundle_index for w in old_workers
        ]

        # Shutdown old replica group.
        # It can be inactive if we failed to initialize the workers in the previous attempt.
        old_replica_group.shutdown()

        # Remove old workers from ongoing poll tracking.
        for w in old_workers:
            if w.distributed_context is not None:
                self._world_rank_to_ongoing_poll.pop(
                    w.distributed_context.world_rank, None
                )

        # Clear result queues on surviving workers to avoid mixed-generation
        # results (some workers with old report, others with new report).
        clear_tasks = []
        for i, rg in enumerate(self._replica_groups):
            if i != replica_group_index and rg.is_active():
                for w in rg.get_workers():
                    clear_tasks.append(w.actor.clear_result_queue.remote())
        if clear_tasks:
            ray.get(clear_tasks)

        # Reset the sync actor to unblock surviving workers that may be stuck
        # at the synchronization barrier. This is a no-op if no workers are
        # currently at the barrier (e.g., failure occurred after the barrier).
        sync_actor = self._worker_group_state.sync_actor
        ray.get(sync_actor.reset.remote())

        # Create new workers with old replica group state.
        pg = self._worker_group_state.placement_group_handle.placement_group
        new_workers = self._create_workers(
            num_workers=len(old_workers),
            placement_group=pg,
            resources_per_worker=self._worker_group_context.resources_per_worker,
            placement_group_bundle_indices=old_placement_group_bundle_indices,
            # TODO: change after we support replica groups of size > 1.
            starting_world_rank=replica_group_index,
            world_size=len(self._replica_groups),
            replica_group_size=len(old_workers),
        )

        # Update internal tracking.
        self._worker_group_state = self._worker_group_state.replace_workers(
            old_workers, new_workers
        )
        new_replica_group = ReplicaGroup(
            new_workers,
            self._worker_group_context.resources_per_worker,
            self._replica_group_callbacks,
        )
        self._replica_groups[replica_group_index] = new_replica_group

        # Initialize train context on new workers.
        sync_actor = self._worker_group_state.sync_actor
        try:
            self._init_train_context(new_workers, sync_actor)
        except RayActorError as actor_error:
            error_msg = (
                "At least one replacement worker failed to initialize "
                f"in replica group {replica_group_index}."
            )
            raise WorkerGroupStartupFailedError(error_msg) from actor_error

        # Start training.
        new_replica_group.start_training(self._worker_group_context)

        workers_info = "\n".join(
            [
                f"- (ip={w.metadata.node_ip}, pid={w.metadata.pid}) "
                f"world_rank={w.distributed_context.world_rank}, "
                f"local_rank={w.distributed_context.local_rank}, "
                f"node_rank={w.distributed_context.node_rank}"
                for w in new_workers
            ]
        )
        logger.info(
            f"Started training replica group of size {len(new_workers)}: "
            f"\n{workers_info}"
        )

    #####################################################################################
    # Utility Methods
    #####################################################################################

    def has_started(self) -> bool:
        return self._worker_group_state is not None

    def _assert_active(self):
        """Assert that the worker group is active (not shut down)."""
        if not self.has_started():
            raise ValueError(
                "Worker group is not active. "
                "Call WorkerGroup.create() to create a new worker group."
            )

    def _assert_inactive(self):
        """Assert that the worker group is inactive (shut down)."""
        if self.has_started():
            raise ValueError(
                "Worker group is active. "
                "Call WorkerGroup.shutdown() to shut down the worker group."
            )

    def get_workers(self) -> List[Worker]:
        self._assert_active()
        return self._worker_group_state.workers

    def get_worker_group_context(self) -> WorkerGroupContext:
        return self._worker_group_context

    def get_worker_group_state(self) -> WorkerGroupState:
        self._assert_active()
        return self._worker_group_state

    def get_latest_poll_status(self) -> Optional[WorkerGroupPollStatus]:
        self._assert_active()
        return self._latest_poll_status

    def get_replica_groups(self) -> Optional[List[ReplicaGroup]]:
        return self._replica_groups

    def get_resources_per_worker(self) -> dict:
        """Get the resources allocated per worker."""
        return copy.deepcopy(self._worker_group_context.resources_per_worker)

    #########################################################################################
    # Static Utility Methods
    #########################################################################################

    @staticmethod
    def _sort_workers_by_tpu_pod_name(workers: List[Worker]) -> List[Worker]:
        """
        Sort workers by their TPU Pod name to ensure deterministic
        topology mapping for TPU multi-slice. The TPU Pod name is based on
        TPU_NAME env var, which is unique and indexed within the Ray worker group
        requesting TPUs.
        """
        pod_name_refs = [
            worker.execute_async(get_current_pod_name) for worker in workers
        ]
        pod_names = ray.get(pod_name_refs)

        # Zip workers with names and sort by name.
        worker_name_pairs = list(zip(workers, pod_names))
        worker_name_pairs.sort(key=lambda pair: pair[1] or "")

        return [w for w, name in worker_name_pairs]

    @staticmethod
    def _assign_worker_ranks(
        workers: List[Worker],
        starting_world_rank: int = 0,
        world_size: Optional[int] = None,
        replica_group_size: Optional[int] = None,
    ) -> List[Worker]:
        """Assign world ranks to workers by increasing node id and GPU id.

        Initializes the `DistributedContext` for each worker.

        Args:
            workers: The workers to assign ranks to.
            starting_world_rank: The starting world rank for this list of workers.
            world_size: The total world size of the worker group.
                If None, uses the number of workers.
            replica_group_size: If set, workers are divided into replica groups
                of this size. len(workers) must be divisible by this value.
                local_rank and local_world_size are computed per
                (node, replica group) pair. If None, all workers are treated
                as a single group.

        Returns:
            workers: Workers sorted by increasing world rank,
                with the `DistributedContext` set.
        """
        if replica_group_size is not None:
            assert len(workers) % replica_group_size == 0, (
                f"num_workers ({len(workers)}) must be divisible by "
                f"replica_group_size ({replica_group_size})"
            )

        is_tpu = False
        if len(workers) > 0:
            is_tpu = workers[0].resources.get("TPU", 0) > 0

        if is_tpu:
            # Use deterministic sort for TPU to align with actual slice IDs.
            workers = WorkerGroup._sort_workers_by_tpu_pod_name(workers)
        else:
            workers = WorkerGroup._sort_workers_by_gpu_id_grouped_by_node(workers)

        # Group workers by local world i.e. (node) or (node, replica group).
        local_world_to_workers = collections.defaultdict(list)
        if replica_group_size is not None:
            # Use OrderedDict for OrderedSet
            group_to_node_ips = collections.defaultdict(collections.OrderedDict)
            for idx, worker in enumerate(workers):
                group_idx = idx // replica_group_size
                key = (worker.metadata.node_ip, group_idx)
                local_world_to_workers[key].append(worker)
                group_to_node_ips[group_idx][worker.metadata.node_ip] = 0  # dummy value
        else:
            for worker in workers:
                local_world_to_workers[worker.metadata.node_ip].append(worker)
            node_ips = list(local_world_to_workers.keys())

        for world_rank, worker in enumerate(workers):
            if replica_group_size is not None:
                group_idx = world_rank // replica_group_size
                key = (worker.metadata.node_ip, group_idx)
                node_ips = list(group_to_node_ips[group_idx].keys())
            else:
                key = worker.metadata.node_ip
            peers = local_world_to_workers[key]
            distributed_context = DistributedContext(
                local_rank=peers.index(worker),
                local_world_size=len(peers),
                world_rank=starting_world_rank + world_rank,
                world_size=world_size if world_size is not None else len(workers),
                node_rank=node_ips.index(worker.metadata.node_ip),
            )
            worker.distributed_context = distributed_context

        return workers

    @staticmethod
    def _decorate_worker_log_file_paths(workers: List[Worker]) -> List[Worker]:
        """Decorate worker log file paths.

        Args:
            workers: The workers to decorate with log file paths.

        Returns:
            workers: Workers with log file paths set.
        """
        # Execute all tasks in parallel and then get results
        log_path_refs = [
            worker.execute_async(get_train_application_worker_log_path)
            for worker in workers
        ]
        log_paths = ray.get(log_path_refs)

        # Assign log paths to workers
        for worker, log_path in zip(workers, log_paths):
            worker.log_file_path = log_path

        return workers

    @staticmethod
    def _sort_workers_by_gpu_id_grouped_by_node(
        workers: List[Worker], _first_id: Optional[str] = None
    ) -> List[Worker]:
        """Reorder the workers by grouping by node id and sorting each group by lowest GPU id.

        Example:
            Given workers with the following attributes:
                worker_0: id=1, gpu_ids=[1]
                worker_1: id=0, gpu_ids=[0]
                worker_2: id=1, gpu_ids=[0]
                worker_3: id=0, gpu_ids=[1]

            The function will perform the following steps:
                1. Group by node id (by default, order node id by insertion order):
                    id=1: worker_0, worker_2
                    id=0: worker_1, worker_3

                2. Sort each group by GPU ID:
                    id=1: worker_2 (gpu_id=0), worker_0 (gpu_id=1)
                    id=0: worker_1 (gpu_id=0), worker_3 (gpu_id=1)

            Resulting in the order: [worker_2, worker_0, worker_1, worker_3]

        Args:
            workers: The workers to sort.
            _first_id: The first node id to group by.

        Returns:
            List of sorted workers.
        """
        node_id_to_workers = collections.defaultdict(list)

        if _first_id is not None:
            node_id_to_workers[_first_id] = []

        for worker in workers:
            node_id_to_workers[worker.metadata.node_id].append(worker)

        # Sort workers on the same node by the lowest GPU id
        # More details: https://github.com/ray-project/ray/issues/40803
        def get_lowest_gpu_id(worker) -> int:
            gpu_ids = worker.metadata.accelerator_ids.get("GPU", [])
            # If there are no GPU IDs, return 0 as a default
            if not gpu_ids:
                return 0

            # Attempt to convert GPU IDs to integers and find the minimum ID.
            # Fallback to return the minimum string-based ID
            try:
                return min(int(gpu_id) for gpu_id in gpu_ids)
            except ValueError:
                return min(gpu_ids)

        for node_id in node_id_to_workers:
            node_id_to_workers[node_id].sort(key=get_lowest_gpu_id)

        sorted_workers = []
        for workers in node_id_to_workers.values():
            sorted_workers.extend(workers)
        return sorted_workers

    @staticmethod
    def _get_worker_runtime_env(
        custom_runtime_env: Union[Dict, RuntimeEnv],
    ) -> Union[Dict, RuntimeEnv]:
        """Update custom runtime env with internal Ray Train env vars
        that should be propagated from the driver to worker processes.

        Args:
            custom_runtime_env: The custom runtime env dict passed in by the user.

        Returns:
            A copy of the custom runtime env dict updated with internal
            Ray Train environment variables to propagate to worker processes.
        """
        merged_env_vars = get_env_vars_to_propagate()
        merged_env_vars.update(custom_runtime_env.get("env_vars", {}))

        runtime_env = dict(custom_runtime_env)
        runtime_env["env_vars"] = merged_env_vars
        return runtime_env
