import copy
import json
import logging
import os
import sys
import time
from collections import defaultdict
from multiprocessing import Process
from unittest.mock import MagicMock, patch

import aiohttp
import numpy as np
import pytest
import requests
from google.protobuf import text_format
from opentelemetry.proto.common.v1.common_pb2 import AnyValue, KeyValue
from opentelemetry.proto.metrics.v1.metrics_pb2 import Metric as OTelMetric

import ray
import ray._common.usage.usage_lib as ray_usage_lib
from ray._common.network_utils import build_address
from ray._common.test_utils import (
    fetch_prometheus,
    wait_for_condition,
)
from ray._private import ray_constants
from ray._private.metrics_agent import fix_grpc_metric
from ray._private.test_utils import (
    format_web_url,
    wait_until_server_available,
)
from ray.core.generated.metrics_pb2 import Metric
from ray.dashboard.modules.reporter.reporter_agent import (
    METRICS_GAUGES,
    ReporterAgent,
    TpuUtilizationInfo,
)
from ray.dashboard.modules.reporter.reporter_head import (
    MULTI_TASK_WARNING_HEADER,
    SVG_STYLE,
    WARNING_FOR_MULTI_TASK_IN_A_WORKER,
    _query_duration,
    _query_flag,
    _task_cpu_profiling_response,
)
from ray.dashboard.tests.conftest import *  # noqa
from ray.dashboard.utils import Bunch

import psutil

try:
    import prometheus_client
except ImportError:
    prometheus_client = None

logger = logging.getLogger(__name__)

STATS_TEMPLATE = {
    "now": 1614826393.975763,
    "hostname": "fake_hostname.local",
    "ip": "127.0.0.1",
    "cpu": 57.4,
    "cpus": (8, 4),
    "mem": (17179869184, 5723353088, 66.7, 9234341888),
    "swap": None,
    "shm": 456,
    "workers": [
        {
            "memory_info": Bunch(
                rss=55934976, vms=7026937856, pfaults=15354, pageins=0
            ),
            "memory_full_info": Bunch(
                uss=51428381, rss=55934976, vms=7026937856, pfaults=15354, pageins=0
            ),
            "cpu_percent": 0.0,
            "num_fds": 10,
            "cmdline": ["ray::IDLE", "", "", "", "", "", "", "", "", "", "", ""],
            "create_time": 1614826391.338613,
            "pid": 7174,
            "cpu_times": Bunch(
                user=0.607899328,
                system=0.274044032,
                children_user=0.0,
                children_system=0.0,
            ),
        }
    ],
    "gcs": {
        "memory_info": Bunch(rss=18354171, vms=6921486336, pfaults=6203, pageins=2),
        "memory_full_info": Bunch(
            uss=51428384, rss=18354171, vms=6921486336, pfaults=6203, pageins=2
        ),
        "cpu_percent": 5.0,
        "num_fds": 14,
        "cmdline": ["fake gcs cmdline"],
        "create_time": 1614826395.274854,
        "pid": 7154,
        "cpu_times": Bunch(
            user=0.01683138,
            system=0.045913716,
            children_user=0.0,
            children_system=0.0,
        ),
    },
    "raylet": {
        "memory_info": Bunch(rss=18354176, vms=6921486336, pfaults=6206, pageins=3),
        "cpu_percent": 0.0,
        "num_fds": 10,
        "cmdline": ["fake raylet cmdline"],
        "create_time": 1614826390.274854,
        "pid": 7153,
        "cpu_times": Bunch(
            user=0.03683138,
            system=0.035913716,
            children_user=0.0,
            children_system=0.0,
        ),
    },
    "agent": {
        "memory_info": Bunch(rss=18354176, vms=6921486336, pfaults=6206, pageins=3),
        "cpu_percent": 0.0,
        "num_fds": 10,
        "cmdline": ["fake raylet cmdline"],
        "create_time": 1614826390.274854,
        "pid": 7154,
        "cpu_times": Bunch(
            user=0.03683138,
            system=0.035913716,
            children_user=0.0,
            children_system=0.0,
        ),
    },
    "bootTime": 1612934656.0,
    "loadAvg": ((4.4521484375, 3.61083984375, 3.5400390625), (0.56, 0.45, 0.44)),
    "disk_io": (100, 100, 100, 100),
    "disk_io_speed": (100, 100, 100, 100),
    "disk": {
        "/": Bunch(
            total=250790436864, used=11316781056, free=22748921856, percent=33.2
        ),
        "/tmp": Bunch(
            total=250790436864, used=209532035072, free=22748921856, percent=90.2
        ),
    },
    "gpus": [],
    "gpu_processes": {},
    "tpus": [],
    "network": (13621160960, 11914936320),
    "network_speed": (8.435062128545095, 7.378462703142336),
    "cmdline": ["fake raylet cmdline"],
    "host_mem": (10737418240, 17179869184),
    "cgroup_mem": None,
}


def random_work():
    import time

    for _ in range(10000):
        time.sleep(0.1)
        np.random.rand(5 * 1024 * 1024)  # 40 MB


def test_fix_grpc_metrics():
    """
    A real metric output from gcs_server, with name prefixed with "grpc.io/" and 1
    distribution time series. It has 45 buckets, first of which bounds = 0.0.
    """
    metric_textproto = (
        'metric_descriptor { name: "grpc.io/server/server_latency" description: "Time '
        "between first byte of request received to last byte of response sent, or "
        'terminal error" unit: "ms" label_keys { key: "grpc_server_method" } label_keys'
        ' { key: "Component" } label_keys { key: "WorkerId" } label_keys { key: '
        '"Version" } label_keys { key: "NodeAddress" } label_keys { key: "SessionName" '
        "} } timeseries { start_timestamp { seconds: 1693693592 } label_values { value:"
        ' "ray.rpc.NodeInfoGcsService/RegisterNode" } label_values { value: '
        '"gcs_server" } label_values { } label_values { value: "3.0.0.dev0" } '
        'label_values { value: "127.0.0.1" } label_values { value: '
        '"session_2023-09-02_15-26-32_589652_23265" } points { timestamp { seconds: '
        "1693693602 } distribution_value { count: 1 sum: 0.266 bucket_options { "
        "explicit { bounds: 0.0 bounds: 0.01 bounds: 0.05 bounds: 0.1 bounds: 0.3 "
        "bounds: 0.6 bounds: 0.8 bounds: 1.0 bounds: 2.0 bounds: 3.0 bounds: 4.0 "
        "bounds: 5.0 bounds: 6.0 bounds: 8.0 bounds: 10.0 bounds: 13.0 bounds: 16.0 "
        "bounds: 20.0 bounds: 25.0 bounds: 30.0 bounds: 40.0 bounds: 50.0 bounds: 65.0 "
        "bounds: 80.0 bounds: 100.0 bounds: 130.0 bounds: 160.0 bounds: 200.0 bounds: "
        "250.0 bounds: 300.0 bounds: 400.0 bounds: 500.0 bounds: 650.0 bounds: 800.0 "
        "bounds: 1000.0 bounds: 2000.0 bounds: 5000.0 bounds: 10000.0 bounds: 20000.0 "
        "bounds: 50000.0 bounds: 100000.0 } } buckets { } buckets { } buckets { } "
        "buckets { } buckets { count: 1 } buckets { } buckets { } buckets { } buckets {"
        " } buckets { } buckets { } buckets { } buckets { } buckets { } buckets { } "
        "buckets { } buckets { } buckets { } buckets { } buckets { } buckets { } "
        "buckets { } buckets { } buckets { } buckets { } buckets { } buckets { } "
        "buckets { } buckets { } buckets { } buckets { } buckets { } buckets { } "
        "buckets { } buckets { } buckets { } buckets { } buckets { } buckets { } "
        "buckets { } buckets { } buckets { } } } }"
    )

    metric = Metric()
    text_format.Parse(metric_textproto, metric)

    expected_fixed_metric = Metric()
    expected_fixed_metric.CopyFrom(metric)
    expected_fixed_metric.metric_descriptor.name = "grpc_io_server_server_latency"
    expected_fixed_metric.timeseries[0].points[
        0
    ].distribution_value.bucket_options.explicit.bounds[0] = 0.0000001

    fix_grpc_metric(metric)
    assert metric == expected_fixed_metric


def test_export_histogram_data_normalizes_mixed_attribute_sets():
    metric = OTelMetric(name="test_histogram", description="Test Histogram")

    data_point = metric.histogram.data_points.add()
    data_point.count = 1
    data_point.explicit_bounds.extend([1.0, 2.0])
    data_point.bucket_counts.extend([0, 1, 0])
    data_point.attributes.append(
        KeyValue(key="Component", value=AnyValue(string_value="worker_a"))
    )
    data_point.attributes.append(
        KeyValue(key="SessionName", value=AnyValue(string_value="session_1"))
    )

    data_point = metric.histogram.data_points.add()
    data_point.count = 1
    data_point.explicit_bounds.extend([1.0, 2.0])
    data_point.bucket_counts.extend([1, 0, 0])
    data_point.attributes.append(
        KeyValue(key="Component", value=AnyValue(string_value="worker_b"))
    )

    agent = object.__new__(ReporterAgent)
    agent._open_telemetry_metric_recorder = MagicMock()

    ReporterAgent._export_histogram_data(agent, metric)

    agent._open_telemetry_metric_recorder.register_histogram_metric.assert_called_once_with(
        "test_histogram", "Test Histogram", [1.0, 2.0]
    )
    agent._open_telemetry_metric_recorder.record_histogram_aggregated_batch.assert_called_once()
    (
        _,
        batch_data_points,
    ) = (
        agent._open_telemetry_metric_recorder.record_histogram_aggregated_batch.call_args.args
    )

    assert batch_data_points == [
        {
            "tags": {"Component": "worker_a", "SessionName": "session_1"},
            "bucket_counts": [0, 1, 0],
        },
        {
            "tags": {"Component": "worker_b", "SessionName": ""},
            "bucket_counts": [1, 0, 0],
        },
    ]


@pytest.fixture(autouse=True)
def enable_profiling():
    os.environ["RAY_DASHBOARD_ENABLE_PROFILING"] = "1"
    yield
    os.environ.pop("RAY_DASHBOARD_ENABLE_PROFILING", None)


@pytest.fixture
def enable_grpc_metrics_collection():
    os.environ["RAY_enable_grpc_metrics_collection_for"] = "gcs"
    yield
    os.environ.pop("RAY_enable_grpc_metrics_collection_for", None)


@pytest.mark.skipif(prometheus_client is None, reason="prometheus_client not installed")
def test_prometheus_physical_stats_record(
    enable_grpc_metrics_collection,
    enable_test_module,
    shutdown_only,
):
    addresses = ray.init(include_dashboard=True, num_cpus=1)
    metrics_export_port = addresses["metrics_export_port"]
    addr = addresses["node_ip_address"]
    prom_addresses = [build_address(addr, metrics_export_port)]

    def test_case_stats_exist():
        _, metric_descriptors, _ = fetch_prometheus(prom_addresses)
        metric_names = metric_descriptors.keys()
        predicates = [
            "ray_node_cpu_utilization" in metric_names,
            "ray_node_cpu_count" in metric_names,
            "ray_node_mem_used" in metric_names,
            "ray_node_mem_available" in metric_names,
            "ray_node_mem_total" in metric_names,
            "ray_node_mem_used_host" in metric_names,
            "ray_node_mem_total_host" in metric_names,
            "ray_component_rss_mb" in metric_names,
            "ray_component_uss_mb" in metric_names,
            "ray_component_rss_bytes" in metric_names,
            "ray_component_uss_bytes" in metric_names,
            "ray_component_num_fds" in metric_names,
            "ray_node_disk_io_read" in metric_names,
            "ray_node_disk_io_write" in metric_names,
            "ray_node_disk_io_read_count" in metric_names,
            "ray_node_disk_io_write_count" in metric_names,
            "ray_node_disk_io_read_speed" in metric_names,
            "ray_node_disk_io_write_speed" in metric_names,
            "ray_node_disk_read_iops" in metric_names,
            "ray_node_disk_write_iops" in metric_names,
            "ray_node_disk_usage" in metric_names,
            "ray_node_disk_free" in metric_names,
            "ray_node_disk_utilization_percentage" in metric_names,
            "ray_node_network_sent" in metric_names,
            "ray_node_network_received" in metric_names,
            "ray_node_network_send_speed" in metric_names,
            "ray_node_network_receive_speed" in metric_names,
            "ray_grpc_io_client_sent_bytes_per_rpc_bucket" in metric_names,
        ]
        if sys.platform == "linux" or sys.platform == "linux2":
            predicates.append("ray_node_mem_shared_bytes" in metric_names)
        return all(predicates)

    def test_case_ip_correct():
        _, _, metric_samples = fetch_prometheus(prom_addresses)
        raylet_proc = ray._private.worker._global_node.all_processes[
            ray_constants.PROCESS_TYPE_RAYLET
        ][0]
        raylet_pid = None
        # Find the raylet pid recorded in the tag.
        for sample in metric_samples:
            if (
                sample.name == "ray_component_cpu_percentage"
                and sample.labels["Component"] == "raylet"
            ):
                raylet_pid = sample.labels["pid"]
                break
        return str(raylet_proc.process.pid) == str(raylet_pid)

    wait_for_condition(test_case_stats_exist, timeout=30, retry_interval_ms=1000)
    wait_for_condition(test_case_ip_correct, timeout=30, retry_interval_ms=1000)


@pytest.mark.skipif(
    prometheus_client is None,
    reason="prometheus_client must be installed.",
)
def test_prometheus_export_worker_and_memory_stats(enable_test_module, shutdown_only):
    addresses = ray.init(include_dashboard=True, num_cpus=1)
    metrics_export_port = addresses["metrics_export_port"]
    addr = addresses["node_ip_address"]
    prom_addresses = [build_address(addr, metrics_export_port)]

    @ray.remote
    def f():
        return 1

    ret = f.remote()
    ray.get(ret)

    def test_worker_stats():
        _, metric_descriptors, _ = fetch_prometheus(prom_addresses)
        metric_names = metric_descriptors.keys()
        expected_metrics = [
            "ray_component_cpu_percentage",
            "ray_component_rss_mb",
            "ray_component_uss_mb",
            "ray_component_rss_bytes",
            "ray_component_uss_bytes",
            "ray_component_num_fds",
        ]
        for metric in expected_metrics:
            if metric not in metric_names:
                return False
        return True

    wait_for_condition(test_worker_stats, retry_interval_ms=1000)


def test_report_stats(tmp_path):
    dashboard_agent = MagicMock()
    dashboard_agent.gcs_address = build_address("127.0.0.1", 6379)
    dashboard_agent.session_dir = str(tmp_path)
    dashboard_agent.node_id = ray.NodeID.from_random().hex()
    raylet_client = MagicMock()
    agent = ReporterAgent(dashboard_agent, raylet_client)
    # Assume it is a head node.
    agent._is_head_node = True

    cluster_stats = {
        "autoscaler_report": {
            "active_nodes": {"head_node": 1, "worker-node-0": 2},
            "failed_nodes": [],
            "pending_launches": {},
            "pending_nodes": [],
        }
    }

    # Use a deep copy to avoid modifying the global template
    stats = copy.deepcopy(STATS_TEMPLATE)
    records = agent._to_records(stats, cluster_stats)
    for record in records:
        name = record.gauge.name
        val = record.value
        if name == "node_mem_shared_bytes":
            assert val == stats["shm"]
        print(record.gauge.name)
        print(record)
    assert len(records) == 49
    # Verify RayNodeType and IsHeadNode tags
    for record in records:
        if record.gauge.name.startswith("node_"):
            assert "RayNodeType" in record.tags
            assert record.tags["RayNodeType"] == "head"
            assert "IsHeadNode" in record.tags
            assert record.tags["IsHeadNode"] == "true"
    # Verify host memory metrics are reported
    host_mem_used = [r for r in records if r.gauge.name == "node_mem_used_host"]
    host_mem_total = [r for r in records if r.gauge.name == "node_mem_total_host"]
    assert len(host_mem_used) == 1
    assert host_mem_used[0].value == stats["host_mem"][0]
    assert len(host_mem_total) == 1
    assert host_mem_total[0].value == stats["host_mem"][1]
    # Verify no cgroup records when cgroup_mem is None
    assert not any(r.gauge.name == "node_cgroup_mem_used" for r in records)
    assert not any(r.gauge.name == "node_cgroup_mem_total" for r in records)

    # Test cgroup memory metrics when cgroup_mem is populated
    stats["cgroup_mem"] = (5368709120, 10737418240)
    records = agent._to_records(stats, cluster_stats)
    cgroup_used = [r for r in records if r.gauge.name == "node_cgroup_mem_used"]
    cgroup_total = [r for r in records if r.gauge.name == "node_cgroup_mem_total"]
    assert len(cgroup_used) == 1
    assert cgroup_used[0].value == 5368709120
    assert len(cgroup_total) == 1
    assert cgroup_total[0].value == 10737418240

    # Swap gauges must NOT be emitted when swap_total == 0 (e.g. flag off, or
    # no swap on the host). Otherwise dashboards see a constant-zero series.
    assert not any(r.gauge.name == "node_swap_used" for r in records)
    assert not any(r.gauge.name == "node_swap_total" for r in records)
    assert not any(r.gauge.name == "node_swap_utilization" for r in records)

    # When swap is reported (flag on + cgroup-aware lookup returned non-zero),
    # all three swap gauges are emitted as a unit.
    stats["swap"] = (2 * 1024**3, 512 * 1024**2, 25.0)
    records = agent._to_records(stats, cluster_stats)
    swap_used = [r for r in records if r.gauge.name == "node_swap_used"]
    swap_total = [r for r in records if r.gauge.name == "node_swap_total"]
    swap_util = [r for r in records if r.gauge.name == "node_swap_utilization"]
    assert len(swap_used) == 1 and swap_used[0].value == 512 * 1024**2
    assert len(swap_total) == 1 and swap_total[0].value == 2 * 1024**3
    assert len(swap_util) == 1 and swap_util[0].value == 25.0
    # Restore swap to None (the off/unreadable state) so the downstream
    # record-count assertions still hold.
    stats["swap"] = None

    # Test stats without raylets
    stats["raylet"] = None
    records = agent._to_records(stats, cluster_stats)
    assert len(records) == 46
    # Test stats with gpus
    stats["gpus"] = [
        {
            "name": "foo",
            "uuid": "gpu-12345",
            "utilization_gpu": 1,
            "memory_used": 100,
            "memory_total": 1000,
            "index": 0,
        }
    ]
    # Test stats with tpus
    stats["tpus"] = [
        {
            "index": 0,
            "name": "foo",
            "tpu_type": "v6e",
            "tpu_topology": "2x2",
            "tensorcore_utilization": 25.0,
            "hbm_utilization": 50.0,
            "duty_cycle": 10.0,
            "memory_used": 1000,
            "memory_total": 2000,
        }
    ]
    records = agent._to_records(stats, cluster_stats)
    assert len(records) == 55
    # Test stats without autoscaler report
    cluster_stats = {}
    records = agent._to_records(stats, cluster_stats)
    assert len(records) == 53

    stats_payload = agent._generate_stats_payload(stats)
    assert stats_payload is not None
    assert isinstance(stats_payload, str)


def test_generate_stats_payload_normalizes_none_process_cmdline(tmp_path):
    from ray._common.pydantic_compat import PYDANTIC_INSTALLED

    if not PYDANTIC_INSTALLED:
        pytest.skip("Pydantic is not installed")

    dashboard_agent = MagicMock()
    dashboard_agent.gcs_address = build_address("127.0.0.1", 6379)
    dashboard_agent.session_dir = str(tmp_path)
    dashboard_agent.node_id = ray.NodeID.from_random().hex()
    raylet_client = MagicMock()
    agent = ReporterAgent(dashboard_agent, raylet_client)

    stats = copy.deepcopy(STATS_TEMPLATE)
    stats["workers"][0]["cmdline"] = None
    stats["raylet"]["cmdline"] = None
    stats["agent"]["cmdline"] = None
    stats["gcs"]["cmdline"] = None
    stats["cmdline"] = None

    stats_payload = json.loads(agent._generate_stats_payload(stats))

    assert stats_payload["workers"][0]["cmdline"] == []
    assert stats_payload["raylet"]["cmdline"] == []
    assert stats_payload["agent"]["cmdline"] == []
    assert stats_payload["gcs"]["cmdline"] == []
    assert stats_payload["cmdline"] == []


def test_report_stats_gpu(tmp_path):
    dashboard_agent = MagicMock()
    dashboard_agent.gcs_address = build_address("127.0.0.1", 6379)
    dashboard_agent.session_dir = str(tmp_path)
    dashboard_agent.node_id = ray.NodeID.from_random().hex()
    raylet_client = MagicMock()
    agent = ReporterAgent(dashboard_agent, raylet_client)
    # Assume it is a head node.
    agent._is_head_node = True
    # GPUstats query output example.
    """
    {'index': 0,
    'uuid': 'GPU-36e1567d-37ed-051e-f8ff-df807517b396',
    'name': 'NVIDIA A10G',
    'utilization_gpu': 1,
    'memory_used': 0,
    'memory_total': 22731,
    'processes': []}
    """
    GPU_MEMORY = 22731
    # Use a deep copy to avoid modifying the global template
    stats = copy.deepcopy(STATS_TEMPLATE)
    stats["gpus"] = [
        {
            "index": 0,
            "uuid": "GPU-36e1567d-37ed-051e-f8ff-df807517b396",
            "name": "NVIDIA A10G",
            "utilization_gpu": 0,
            "memory_used": 0,
            "memory_total": GPU_MEMORY,
            "processes": [],
        },
        {
            "index": 1,
            "uuid": "GPU-36e1567d-37ed-051e-f8ff-df807517b397",
            "name": "NVIDIA A10G",
            "utilization_gpu": 1,
            "memory_used": 1,
            "memory_total": GPU_MEMORY,
            "processes": [],
        },
        {
            "index": 2,
            "uuid": "GPU-36e1567d-37ed-051e-f8ff-df807517b398",
            "name": "NVIDIA A10G",
            "utilization_gpu": 2,
            "memory_used": 2,
            "memory_total": GPU_MEMORY,
            "processes": [],
        },
        {
            "index": 3,
            "name": "NVIDIA A10G",
            "uuid": "GPU-36e1567d-37ed-051e-f8ff-df807517b399",
            "utilization_gpu": 3,
            "memory_used": 3,
            "memory_total": GPU_MEMORY,
            "processes": [],
        },
    ]
    gpu_metrics_aggregatd = {
        "node_gpus_available": 0,
        "node_gpus_utilization": 0,
        "node_gram_used": 0,
        "node_gram_available": 0,
    }
    records = agent._to_records(stats, {})
    # If index is not available, we don't emit metrics.
    num_gpu_records = 0
    for record in records:
        if record.gauge.name in gpu_metrics_aggregatd:
            num_gpu_records += 1
    assert num_gpu_records == 16

    ip = stats["ip"]
    gpu_records = defaultdict(list)
    for record in records:
        if record.gauge.name in gpu_metrics_aggregatd:
            gpu_records[record.gauge.name].append(record)

    for name, records in gpu_records.items():
        records.sort(key=lambda e: e.tags["GpuIndex"])
        index = 0
        for record in records:
            assert record.tags == {
                "ip": ip,
                # The tag value must be string for prometheus.
                "GpuIndex": str(index),
                "GpuDeviceName": "NVIDIA A10G",
                "GpuUuid": f"GPU-36e1567d-37ed-051e-f8ff-df807517b39{6 + index}",
                "RayNodeType": "head",
                "IsHeadNode": "true",
            }

            if name == "node_gram_available":
                assert record.value == GPU_MEMORY - index
            elif name == "node_gpus_available":
                assert record.value == 1
            else:
                assert record.value == index

            gpu_metrics_aggregatd[name] += record.value
            index += 1

    assert gpu_metrics_aggregatd["node_gpus_available"] == 4
    assert gpu_metrics_aggregatd["node_gpus_utilization"] == 6
    assert gpu_metrics_aggregatd["node_gram_used"] == 6
    assert gpu_metrics_aggregatd["node_gram_available"] == GPU_MEMORY * 4 - 6

    stats_payload = agent._generate_stats_payload(stats)
    assert stats_payload is not None
    assert isinstance(stats_payload, str)


def test_report_stats_gpu_power_and_temperature(tmp_path):
    """Test that GPU power and temperature metrics are reported when present in stats."""
    dashboard_agent = MagicMock()
    dashboard_agent.gcs_address = build_address("127.0.0.1", 6379)
    dashboard_agent.session_dir = str(tmp_path)
    dashboard_agent.node_id = ray.NodeID.from_random().hex()
    raylet_client = MagicMock()
    agent = ReporterAgent(dashboard_agent, raylet_client)
    agent._is_head_node = True

    stats = copy.deepcopy(STATS_TEMPLATE)
    stats["gpus"] = [
        {
            "index": 0,
            "uuid": "GPU-aaa",
            "name": "NVIDIA A10G",
            "utilization_gpu": 10,
            "memory_used": 100,
            "memory_total": 1024,
            "processes": [],
            "power_mw": 125000,  # 125 W
            "temperature_c": 65,
        },
        {
            "index": 1,
            "uuid": "GPU-bbb",
            "name": "NVIDIA A10G",
            "utilization_gpu": 20,
            "memory_used": 200,
            "memory_total": 1024,
            "processes": [],
            "power_mw": 200000,  # 200 W
            "temperature_c": 72,
        },
    ]

    records = agent._to_records(stats, {})

    power_records = [r for r in records if r.gauge.name == "node_gpu_power_milliwatts"]
    temp_records = [
        r for r in records if r.gauge.name == "node_gpu_temperature_celsius"
    ]

    assert len(power_records) == 2
    assert len(temp_records) == 2

    power_by_index = {r.tags["GpuIndex"]: r.value for r in power_records}
    assert power_by_index["0"] == 125000
    assert power_by_index["1"] == 200000

    temp_by_index = {r.tags["GpuIndex"]: r.value for r in temp_records}
    assert temp_by_index["0"] == 65
    assert temp_by_index["1"] == 72

    # Tags should include GpuIndex, GpuDeviceName and GpuUuid
    expected_uuids = {"0": "GPU-aaa", "1": "GPU-bbb"}
    for r in power_records + temp_records:
        assert "GpuIndex" in r.tags
        assert r.tags.get("GpuDeviceName") == "NVIDIA A10G"
        assert r.tags.get("GpuUuid") == expected_uuids[r.tags["GpuIndex"]]


def test_report_stats_gpu_without_power_temperature(tmp_path):
    """Test that no power/temperature records are emitted when fields are absent."""
    dashboard_agent = MagicMock()
    dashboard_agent.gcs_address = build_address("127.0.0.1", 6379)
    dashboard_agent.session_dir = str(tmp_path)
    dashboard_agent.node_id = ray.NodeID.from_random().hex()
    raylet_client = MagicMock()
    agent = ReporterAgent(dashboard_agent, raylet_client)
    agent._is_head_node = True

    stats = copy.deepcopy(STATS_TEMPLATE)
    stats["gpus"] = [
        {
            "index": 0,
            "uuid": "GPU-ccc",
            "name": "NVIDIA A10G",
            "utilization_gpu": 0,
            "memory_used": 0,
            "memory_total": 1024,
            "processes": [],
            # no power_mw or temperature_c
        },
    ]

    records = agent._to_records(stats, {})

    power_records = [r for r in records if r.gauge.name == "node_gpu_power_milliwatts"]
    temp_records = [
        r for r in records if r.gauge.name == "node_gpu_temperature_celsius"
    ]

    assert len(power_records) == 0
    assert len(temp_records) == 0


def test_get_tpu_usage(tmp_path):
    dashboard_agent = MagicMock()
    dashboard_agent.gcs_address = build_address("127.0.0.1", 6379)
    dashboard_agent.session_dir = str(tmp_path)
    dashboard_agent.node_id = ray.NodeID.from_random().hex()
    raylet_client = MagicMock()
    agent = ReporterAgent(dashboard_agent, raylet_client)

    fake_metrics_content = """
    duty_cycle{accelerator_id="1234-0",container="ray-head",make="cloud-tpu",model="tpu-v6e-slice",namespace="default",pod="test",tpu_topology="2x2"} 20.0
    duty_cycle{accelerator_id="1234-1",container="ray-head",make="cloud-tpu",model="tpu-v6e-slice",namespace="default",pod="test",tpu_topology="2x2"} 40.0
    memory_bandwidth_utilization{accelerator_id="1234-0",container="ray-head",make="cloud-tpu",model="tpu-v6e-slice",namespace="default",pod="test",tpu_topology="2x2"} 11
    memory_bandwidth_utilization{accelerator_id="1234-1",container="ray-head",make="cloud-tpu",model="tpu-v6e-slice",namespace="default",pod="test",tpu_topology="2x2"} 12
    memory_used{accelerator_id="1234-0",container="ray-head",make="cloud-tpu",model="tpu-v6e-slice",namespace="default",pod="test",tpu_topology="2x2"} 1000
    memory_used{accelerator_id="1234-1",container="ray-head",make="cloud-tpu",model="tpu-v6e-slice",namespace="default",pod="test",tpu_topology="2x2"} 2000
    memory_total{accelerator_id="1234-0",container="ray-head",make="cloud-tpu",model="tpu-v6e-slice",namespace="default",pod="test",tpu_topology="2x2"} 4000
    memory_total{accelerator_id="1234-1",container="ray-head",make="cloud-tpu",model="tpu-v6e-slice",namespace="default",pod="test",tpu_topology="2x2"} 4000
    tensorcore_utilization{accelerator_id="1234-0",container="ray-head",make="cloud-tpu",model="tpu-v6e-slice",namespace="default",pod="test",tpu_topology="2x2"} 22
    tensorcore_utilization{accelerator_id="1234-1",container="ray-head",make="cloud-tpu",model="tpu-v6e-slice",namespace="default",pod="test",tpu_topology="2x2"} 23
    """
    with patch.multiple(
        "ray.dashboard.modules.reporter.reporter_agent",
        TPU_DEVICE_PLUGIN_ADDR="localhost:2112",
    ):
        with patch("requests.get") as mock_get:
            mock_response = MagicMock()
            mock_response.content = fake_metrics_content.encode("utf-8")
            mock_get.return_value = mock_response

            tpu_utilizations = agent._get_tpu_usage()

            mock_get.assert_called_once_with("http://localhost:2112/metrics")

            expected_utilizations = [
                TpuUtilizationInfo(
                    index=0,
                    name="1234-0",
                    tpu_type="tpu-v6e-slice",
                    tpu_topology="2x2",
                    tensorcore_utilization=22.0,
                    hbm_utilization=11.0,
                    duty_cycle=20.0,
                    memory_used=1000,
                    memory_total=4000,
                ),
                TpuUtilizationInfo(
                    index=1,
                    name="1234-1",
                    tpu_type="tpu-v6e-slice",
                    tpu_topology="2x2",
                    tensorcore_utilization=23.0,
                    hbm_utilization=12.0,
                    duty_cycle=40.0,
                    memory_used=2000,
                    memory_total=4000,
                ),
            ]
            assert tpu_utilizations == expected_utilizations


def test_get_tpu_usage_idle_and_duplicates(tmp_path):
    dashboard_agent = MagicMock()
    dashboard_agent.gcs_address = build_address("127.0.0.1", 6379)
    dashboard_agent.session_dir = str(tmp_path)
    dashboard_agent.node_id = ray.NodeID.from_random().hex()
    raylet_client = MagicMock()
    agent = ReporterAgent(dashboard_agent, raylet_client)

    # 4 TPUs, all idle (0.0 utilization)
    # Utilization metrics use indices 0-3
    # Other metrics use indices 10, 11, 14, 15
    # Also includes duplicate samples for index 0 and 10 to test robustness.
    fake_metrics_content = """
    # Duplicate samples for duty_cycle index 10
    duty_cycle{accelerator_id="1234-10",container="ray-worker",make="cloud-tpu",model="v6e",tpu_topology="2x2"} 0.0
    duty_cycle{accelerator_id="1234-10",make="cloud-tpu",model="v6e",tpu_topology="2x2"} 0.0
    duty_cycle{accelerator_id="1234-11",make="cloud-tpu",model="v6e",tpu_topology="2x2"} 0.0
    duty_cycle{accelerator_id="1234-14",make="cloud-tpu",model="v6e",tpu_topology="2x2"} 0.0
    duty_cycle{accelerator_id="1234-15",make="cloud-tpu",model="v6e",tpu_topology="2x2"} 0.0
    # Duplicate samples for tensorcore_utilization index 0
    tensorcore_utilization{accelerator_id="1234-0",container="ray-worker",make="cloud-tpu",model="v6e",tpu_topology="2x2"} 0.0
    tensorcore_utilization{accelerator_id="1234-0",make="cloud-tpu",model="v6e",tpu_topology="2x2"} 0.0
    tensorcore_utilization{accelerator_id="1234-1",make="cloud-tpu",model="v6e",tpu_topology="2x2"} 0.0
    tensorcore_utilization{accelerator_id="1234-2",make="cloud-tpu",model="v6e",tpu_topology="2x2"} 0.0
    tensorcore_utilization{accelerator_id="1234-3",make="cloud-tpu",model="v6e",tpu_topology="2x2"} 0.0
    # Memory metrics
    memory_total{accelerator_id="1234-10",make="cloud-tpu",model="v6e",tpu_topology="2x2"} 4000
    memory_total{accelerator_id="1234-11",make="cloud-tpu",model="v6e",tpu_topology="2x2"} 4000
    memory_total{accelerator_id="1234-14",make="cloud-tpu",model="v6e",tpu_topology="2x2"} 4000
    memory_total{accelerator_id="1234-15",make="cloud-tpu",model="v6e",tpu_topology="2x2"} 4000
    """
    with patch.multiple(
        "ray.dashboard.modules.reporter.reporter_agent",
        TPU_DEVICE_PLUGIN_ADDR="localhost:2112",
    ):
        with patch("requests.get") as mock_get:
            mock_response = MagicMock()
            mock_response.content = fake_metrics_content.encode("utf-8")
            mock_get.return_value = mock_response

            tpu_utilizations = agent._get_tpu_usage()

            # Should have 4 unique TPUs
            assert len(tpu_utilizations) == 4
            # Verify mapping (10 mapped to 0, 11 to 1, etc.)
            assert tpu_utilizations[0]["index"] == 0
            assert tpu_utilizations[0]["memory_total"] == 4000
            assert tpu_utilizations[3]["index"] == 3
            assert tpu_utilizations[3]["memory_total"] == 4000


def test_report_stats_tpu(tmp_path):
    dashboard_agent = MagicMock()
    dashboard_agent.gcs_address = build_address("127.0.0.1", 6379)
    dashboard_agent.session_dir = str(tmp_path)
    dashboard_agent.node_id = ray.NodeID.from_random().hex()
    raylet_client = MagicMock()
    agent = ReporterAgent(dashboard_agent, raylet_client)

    stats = copy.deepcopy(STATS_TEMPLATE)

    stats["tpus"] = [
        {
            "index": 0,
            "name": "tpu-0",
            "tpu_type": "v6e",
            "tpu_topology": "2x2",
            "tensorcore_utilization": 10.0,
            "hbm_utilization": 10.0,
            "duty_cycle": 1.0,
            "memory_used": 500,
            "memory_total": 2000,
        },
        {
            "index": 1,
            "name": "tpu-1",
            "tpu_type": "v6e",
            "tpu_topology": "2x2",
            "tensorcore_utilization": 20.0,
            "hbm_utilization": 10.0,
            "duty_cycle": 2.0,
            "memory_used": 400,
            "memory_total": 2000,
        },
        {
            "index": 2,
            "name": "tpu-2",
            "tpu_type": "v6e",
            "tpu_topology": "2x2",
            "tensorcore_utilization": 30.0,
            "hbm_utilization": 10.0,
            "duty_cycle": 3.0,
            "memory_used": 300,
            "memory_total": 2000,
        },
        {
            "index": 3,
            "name": "tpu-3",
            "tpu_type": "v6e",
            "tpu_topology": "2x2",
            "tensorcore_utilization": 40.0,
            "hbm_utilization": 10.0,
            "duty_cycle": 4.0,
            "memory_used": 200,
            "memory_total": 2000,
        },
    ]
    tpu_metrics_aggregated = {
        "tpu_tensorcore_utilization": 0.0,
        "tpu_memory_bandwidth_utilization": 0.0,
        "tpu_duty_cycle": 0.0,
        "tpu_memory_used": 0,
        "tpu_memory_total": 0,
    }
    records = agent._to_records(stats, {})
    num_tpu_records = 0
    for record in records:
        if record.gauge.name in tpu_metrics_aggregated:
            num_tpu_records += 1
            tpu_metrics_aggregated[record.gauge.name] += record.value

    assert num_tpu_records == 20
    assert tpu_metrics_aggregated["tpu_tensorcore_utilization"] == 100
    assert tpu_metrics_aggregated["tpu_memory_bandwidth_utilization"] == 40
    assert tpu_metrics_aggregated["tpu_duty_cycle"] == 10
    assert tpu_metrics_aggregated["tpu_memory_used"] == 1400
    assert tpu_metrics_aggregated["tpu_memory_total"] == 8000

    stats_payload = agent._generate_stats_payload(stats)
    assert stats_payload is not None
    assert isinstance(stats_payload, str)


def test_report_per_component_stats(tmp_path):
    dashboard_agent = MagicMock()
    dashboard_agent.gcs_address = build_address("127.0.0.1", 6379)
    dashboard_agent.session_dir = str(tmp_path)
    dashboard_agent.node_id = ray.NodeID.from_random().hex()
    raylet_client = MagicMock()
    agent = ReporterAgent(dashboard_agent, raylet_client)
    # Assume it is a head node.
    agent._is_head_node = True

    # Generate stats.
    test_stats = copy.deepcopy(STATS_TEMPLATE)
    idle_stats = {
        "memory_info": Bunch(
            rss=55934976, vms=7026937856, uss=1234567, pfaults=15354, pageins=0
        ),
        "memory_full_info": Bunch(
            uss=51428381, rss=55934976, vms=7026937856, pfaults=15354, pageins=0
        ),
        "cpu_percent": 5.0,
        "num_fds": 11,
        "cmdline": ["ray::IDLE", "", "", "", "", "", "", "", "", "", "", ""],
        "create_time": 1614826391.338613,
        "pid": 7174,
        "cpu_times": Bunch(
            user=0.607899328,
            system=0.274044032,
            children_user=0.0,
            children_system=0.0,
        ),
    }
    func_stats = {
        "memory_info": Bunch(rss=55934976, vms=7026937856, pfaults=15354, pageins=0),
        "memory_full_info": Bunch(
            uss=51428381, rss=55934976, vms=7026937856, pfaults=15354, pageins=0
        ),
        "cpu_percent": 6.0,
        "num_fds": 12,
        "cmdline": ["ray::func", "", "", "", "", "", "", "", "", "", "", ""],
        "create_time": 1614826391.338613,
        "pid": 7175,
        "cpu_times": Bunch(
            user=0.607899328,
            system=0.274044032,
            children_user=0.0,
            children_system=0.0,
        ),
    }
    gcs_stats = {
        "memory_info": Bunch(rss=18354171, vms=6921486336, pfaults=6203, pageins=2),
        "memory_full_info": Bunch(
            uss=51428384, rss=18354171, vms=6921486336, pfaults=6203, pageins=2
        ),
        "cpu_percent": 5.0,
        "num_fds": 14,
        "cmdline": ["fake gcs cmdline"],
        "create_time": 1614826395.274854,
        "pid": 7154,
        "cpu_times": Bunch(
            user=0.01683138,
            system=0.045913716,
            children_user=0.0,
            children_system=0.0,
        ),
    }
    raylet_stats = {
        "memory_info": Bunch(rss=18354176, vms=6921486336, pfaults=6206, pageins=3),
        "memory_full_info": Bunch(
            uss=51428381, rss=18354176, vms=6921486336, pfaults=6206, pageins=3
        ),
        "cpu_percent": 4.0,
        "num_fds": 13,
        "cmdline": ["fake raylet cmdline"],
        "create_time": 1614826390.274854,
        "pid": 7153,
        "cpu_times": Bunch(
            user=0.03683138,
            system=0.035913716,
            children_user=0.0,
            children_system=0.0,
        ),
    }
    agent_stats = {
        "memory_info": Bunch(rss=18354176, vms=6921486336, pfaults=6206, pageins=3),
        "memory_full_info": Bunch(
            uss=51428381, rss=18354176, vms=6921486336, pfaults=6206, pageins=3
        ),
        "cpu_percent": 6.0,
        "num_fds": 14,
        "cmdline": ["fake raylet cmdline"],
        "create_time": 1614826390.274854,
        "pid": 7156,
        "cpu_times": Bunch(
            user=0.03683138,
            system=0.035913716,
            children_user=0.0,
            children_system=0.0,
        ),
    }

    test_stats["workers"] = [idle_stats, func_stats]
    test_stats["gcs"] = gcs_stats
    test_stats["raylet"] = raylet_stats
    test_stats["agent"] = agent_stats

    cluster_stats = {
        "autoscaler_report": {
            "active_nodes": {"head_node": 1, "worker-node-0": 2},
            "failed_nodes": [],
            "pending_launches": {},
            "pending_nodes": [],
        }
    }

    def get_uss_and_cpu_and_num_fds_records(records):
        component_uss_bytes_records = defaultdict(list)
        component_cpu_percentage_records = defaultdict(list)
        component_num_fds_records = defaultdict(list)
        for record in records:
            name = record.gauge.name
            if name == "component_uss_bytes":
                comp = record.tags["Component"]
                component_uss_bytes_records[comp].append(record)
            if name == "component_cpu_percentage":
                comp = record.tags["Component"]
                component_cpu_percentage_records[comp].append(record)
            if name == "component_num_fds":
                comp = record.tags["Component"]
                component_num_fds_records[comp].append(record)
        return (
            component_uss_bytes_records,
            component_cpu_percentage_records,
            component_num_fds_records,
        )

    """
    Test basic case.
    """
    records = agent._to_records(test_stats, cluster_stats)
    uss_records, cpu_records, num_fds_records = get_uss_and_cpu_and_num_fds_records(
        records
    )

    def verify_metrics_values(
        uss_records, cpu_records, num_fds_records, comp, uss, cpu_percent, num_fds
    ):
        """Verify the component exists and match the resource usage."""
        assert comp in uss_records
        assert comp in cpu_records
        assert comp in num_fds_records
        uss_metrics = uss_records[comp][0].value
        cpu_percnet_metrics = cpu_records[comp][0].value
        num_fds_metrics = num_fds_records[comp][0].value
        assert uss_metrics == uss
        assert cpu_percnet_metrics == cpu_percent
        assert num_fds_metrics == num_fds

    stats_map = {
        "gcs": gcs_stats,
        "raylet": raylet_stats,
        "agent": agent_stats,
        "ray::IDLE": idle_stats,
        "ray::func": func_stats,
    }
    # Verify metrics are correctly reported with a component name.
    for comp, stats in stats_map.items():
        verify_metrics_values(
            uss_records,
            cpu_records,
            num_fds_records,
            comp,
            float(stats["memory_full_info"].uss),
            stats["cpu_percent"],
            stats["num_fds"],
        )

    """
    Test metrics are resetted (report metrics with values 0) when
    the proc doesn't exist anymore.
    """
    # Verify the metrics are reset after ray::func is killed.
    test_stats["workers"] = [idle_stats]
    records = agent._to_records(test_stats, cluster_stats)
    uss_records, cpu_records, num_fds_records = get_uss_and_cpu_and_num_fds_records(
        records
    )
    verify_metrics_values(
        uss_records,
        cpu_records,
        num_fds_records,
        "ray::IDLE",
        float(idle_stats["memory_full_info"].uss),
        idle_stats["cpu_percent"],
        idle_stats["num_fds"],
    )

    comp = "ray::func"
    stats = func_stats
    # Value should be reset since func doesn't exist anymore.
    verify_metrics_values(
        uss_records,
        cpu_records,
        num_fds_records,
        "ray::func",
        0,
        0,
        0,
    )

    stats_payload = agent._generate_stats_payload(test_stats)
    assert stats_payload is not None
    assert isinstance(stats_payload, str)


@pytest.mark.parametrize("enable_k8s_disk_usage", [True, False])
def test_enable_k8s_disk_usage(enable_k8s_disk_usage: bool):
    """Test enabling display of K8s node disk usage when in a K8s pod."""
    with patch.multiple(
        "ray.dashboard.modules.reporter.reporter_agent",
        IN_KUBERNETES_POD=True,
        ENABLE_K8S_DISK_USAGE=enable_k8s_disk_usage,
    ):
        root_usage = ReporterAgent._get_disk_usage(
            ray._common.utils.get_default_ray_temp_dir()
        )["/"]
        if enable_k8s_disk_usage:
            # Since K8s disk usage is enabled, we shouuld get non-dummy values.
            assert root_usage.total != 1
            assert root_usage.free != 1
        else:
            # Unless K8s disk usage display is enabled, we should get dummy values.
            assert root_usage.total == 1
            assert root_usage.free == 1


@pytest.mark.asyncio
async def test_reporter_worker_cpu_percent():
    raylet_dummy_proc_f = psutil.Process
    agent_mock = Process(target=random_work)
    children = [Process(target=random_work) for _ in range(2)]

    class ReporterAgentDummy(object):
        _workers = {}

        def _get_raylet_proc(self):
            return raylet_dummy_proc_f()

        def _get_agent_proc(self):
            return psutil.Process(agent_mock.pid)

        def _generate_proc_key(self, proc):
            return (proc.pid, proc.create_time())

        async def _async_get_worker_pids_from_raylet(self):
            return [p.pid for p in children]

        async def _async_get_worker_processes(self):
            return await ReporterAgent._async_get_worker_processes(self)

        async def _async_get_agent_pids_from_raylet(self):
            return []

        async def _async_get_agent_processes(self):
            return await ReporterAgent._async_get_agent_processes(self)

    obj = ReporterAgentDummy()

    try:
        agent_mock.start()
        for child_proc in children:
            child_proc.start()
        children_pids = {p.pid for p in children}
        workers = await ReporterAgent._async_get_workers_and_agents(obj)
        # In the first run, the percent should be 0.
        assert all([worker["cpu_percent"] == 0.0 for worker in workers])
        for _ in range(10):
            time.sleep(0.1)
            workers = await ReporterAgent._async_get_workers_and_agents(obj)
            workers_pids = {w["pid"] for w in workers}

            # Make sure all children are registered.
            for pid in children_pids:
                assert pid in workers_pids

            for worker in workers:
                if worker["pid"] in children_pids:
                    # Subsequent run shouldn't be 0.
                    worker["cpu_percent"] > 0

        # Kill one of the child procs and test it is cleaned.
        print("killed ", children[0].pid)
        children[0].kill()
        wait_for_condition(lambda: not children[0].is_alive())
        workers = await ReporterAgent._async_get_workers_and_agents(obj)
        workers_pids = {w["pid"] for w in workers}
        assert children[0].pid not in workers_pids
        assert children[1].pid in workers_pids

        children[1].kill()
        wait_for_condition(lambda: not children[1].is_alive())
        workers = await ReporterAgent._async_get_workers_and_agents(obj)
        workers_pids = {w["pid"] for w in workers}
        assert children[0].pid not in workers_pids
        assert children[1].pid not in workers_pids

    except Exception as e:
        logger.exception(e)
        raise
    finally:
        for child_proc in children:
            if child_proc.is_alive():
                child_proc.kill()
        if agent_mock.is_alive():
            agent_mock.kill()


@pytest.mark.skipif(
    os.environ.get("RAY_MINIMAL") == "1",
    reason="This test is not supposed to work for minimal installation.",
)
@pytest.mark.skipif(sys.platform == "win32", reason="No py-spy on Windows.")
@pytest.mark.skipif(
    sys.platform == "darwin",
    reason="Fails on OSX: https://github.com/ray-project/ray/issues/30114",
)
def test_get_task_traceback_running_task(shutdown_only):
    """
    Verify that Ray can get the traceback for a running task.

    """
    address_info = ray.init()
    webui_url = format_web_url(address_info["webui_url"])

    @ray.remote
    def f():
        pass

    @ray.remote
    def long_running_task():
        print("Long-running task began.")
        time.sleep(1000)
        print("Long-running task completed.")

    ray.get([f.remote() for _ in range(5)])

    task = long_running_task.remote()

    params = {
        "task_id": task.task_id().hex(),
        "attempt_number": 0,
        "node_id": ray.get_runtime_context().get_node_id(),
    }

    def verify():
        resp = requests.get(f"{webui_url}/task/traceback", params=params)
        print(f"resp.text {type(resp.text)}: {resp.text}")

        assert "Process" in resp.text
        return True

    wait_for_condition(verify, timeout=20)


@pytest.mark.skipif(
    os.environ.get("RAY_MINIMAL") == "1",
    reason="This test is not supposed to work for minimal installation.",
)
@pytest.mark.skipif(sys.platform == "win32", reason="No memray on Windows.")
@pytest.mark.skipif(
    sys.platform == "darwin",
    reason="Fails on OSX, requires memray & lldb installed in osx image",
)
def test_get_memory_profile_running_task(shutdown_only):
    """
    Verify that we can get the memory profile for a running task.

    """
    address_info = ray.init()
    webui_url = format_web_url(address_info["webui_url"])

    @ray.remote
    def f():
        pass

    @ray.remote
    def long_running_task():
        print("Long-running task began.")
        time.sleep(1000)
        print("Long-running task completed.")

    ray.get([f.remote() for _ in range(5)])

    task = long_running_task.remote()

    params = {
        "task_id": task.task_id().hex(),
        "attempt_number": 0,
        "node_id": ray.get_runtime_context().get_node_id(),
        "duration": 5,
    }

    def verify():
        resp = requests.get(f"{webui_url}/memory_profile", params=params)
        print(f"resp.text {type(resp.text)}: {resp.text}")

        assert resp.status_code == 200
        assert "memray" in resp.text
        return True

    wait_for_condition(verify, timeout=20)


TASK = {
    "task_id": "32d950ec0ccf9d2affffffffffffffffffffffff01000000",
    "attempt_number": 0,
    "node_id": "ffffffffffffffffffffffffffffffffffffffff01000000",
}


@pytest.mark.skipif(
    os.environ.get("RAY_MINIMAL") == "1",
    reason="This test is not supposed to work for minimal installation.",
)
@pytest.mark.skipif(sys.platform == "win32", reason="No py-spy on Windows.")
@pytest.mark.skipif(
    sys.platform == "darwin",
    reason="Fails on OSX: https://github.com/ray-project/ray/issues/30114",
)
def test_get_task_traceback_non_running_task(shutdown_only):
    """
    Verify that Ray throws an error for a non-running task.
    """

    # The sleep is needed since it seems a previous shutdown could be not yet
    # done when the next test starts. This prevents a previous cluster to be
    # connected the current test session.

    address_info = ray.init()
    webui_url = format_web_url(address_info["webui_url"])

    @ray.remote
    def f():
        pass

    ray.get([f.remote() for _ in range(5)])

    params = {
        "task_id": TASK["task_id"],
        "attempt_number": TASK["attempt_number"],
        "node_id": TASK["node_id"],
    }

    # Make sure the API works.
    def verify():
        with pytest.raises(requests.exceptions.HTTPError) as exc_info:
            resp = requests.get(f"{webui_url}/task/traceback", params=params)
            resp.raise_for_status()
        assert isinstance(exc_info.value, requests.exceptions.HTTPError)
        return True

    wait_for_condition(verify, timeout=10)


@pytest.mark.skipif(
    os.environ.get("RAY_MINIMAL") == "1",
    reason="This test is not supposed to work for minimal installation.",
)
@pytest.mark.skipif(sys.platform == "win32", reason="No py-spy on Windows.")
@pytest.mark.skipif(
    sys.platform == "darwin",
    reason="Fails on OSX: https://github.com/ray-project/ray/issues/30114",
)
def test_get_cpu_profile_non_running_task(shutdown_only):
    """
    Verify that we throw an error for a non-running task.
    """
    address_info = ray.init()
    webui_url = format_web_url(address_info["webui_url"])

    @ray.remote
    def f():
        pass

    ray.get([f.remote() for _ in range(5)])

    params = {
        "task_id": TASK["task_id"],
        "attempt_number": TASK["attempt_number"],
        "node_id": TASK["node_id"],
    }

    # Make sure the API works.
    def verify():
        with pytest.raises(requests.exceptions.HTTPError) as exc_info:
            resp = requests.get(f"{webui_url}/task/cpu_profile", params=params)
            resp.raise_for_status()
        assert isinstance(exc_info.value, requests.exceptions.HTTPError)
        return True

    wait_for_condition(verify, timeout=10)


@pytest.mark.skipif(
    os.environ.get("RAY_MINIMAL") == "1",
    reason="This test is not supposed to work for minimal installation.",
)
@pytest.mark.skipif(sys.platform == "win32", reason="No py-spy on Windows.")
@pytest.mark.skipif(
    sys.platform == "darwin",
    reason="Fails on OSX, requires memray & lldb installed in osx image",
)
def test_task_get_memory_profile_missing_params(shutdown_only):
    """
    Verify that we throw an error for a non-running task.
    """
    address_info = ray.init()
    webui_url = format_web_url(address_info["webui_url"])

    @ray.remote
    def f():
        pass

    ray.get([f.remote() for _ in range(5)])

    missing_node_id_params = {
        "task_id": TASK["task_id"],
        "attempt_number": TASK["attempt_number"],
    }

    # Make sure the API works.
    def verify():
        resp = requests.get(
            f"{webui_url}/memory_profile", params=missing_node_id_params
        )
        content = resp.content.decode("utf-8")
        assert "task's node id is required" in content, content
        return True

    wait_for_condition(verify, timeout=10)


def test_get_cluster_metadata(ray_start_with_dashboard):
    assert wait_until_server_available(ray_start_with_dashboard["webui_url"])
    webui_url = format_web_url(ray_start_with_dashboard["webui_url"])
    url = f"{webui_url}/api/v0/cluster_metadata"

    resp = requests.get(url)
    assert resp.status_code == 200
    resp_data = resp.json()["data"]
    meta = ray_usage_lib._generate_cluster_metadata(ray_init_cluster=True)
    assert len(resp_data) == len(meta)
    assert resp_data["pythonVersion"] == meta["python_version"]
    assert resp_data["rayVersion"] == meta["ray_version"]
    assert resp_data["rayInitCluster"] == meta["ray_init_cluster"]


@pytest.mark.asyncio
@pytest.mark.parametrize(
    "ray_start_with_dashboard",
    [
        {"num_cpus": 1},
    ],
    indirect=True,
)
async def test_reporter_raylet_agent(ray_start_with_dashboard):
    @ray.remote
    class MyActor:
        def get_pid(self):
            return os.getpid()

    a = MyActor.remote()
    worker_pid = ray.get(a.get_pid.remote())
    dashboard_agent = MagicMock()
    dashboard_agent.gcs_address = build_address("127.0.0.1", 6379)
    dashboard_agent.ip = "127.0.0.1"
    dashboard_agent.node_manager_port = (
        ray._private.worker.global_worker.node.node_manager_port
    )
    dashboard_agent.session_dir = (
        ray._private.worker.global_worker.node.get_session_dir_path()
    )
    dashboard_agent.node_id = ray._private.worker.global_worker.node.unique_id
    agent = ReporterAgent(dashboard_agent)
    pids = await agent._async_get_worker_pids_from_raylet()
    assert len(pids) == 2
    # check if worker is reported
    assert worker_pid in pids
    # check if driver is reported
    assert os.getpid() in pids


@pytest.mark.asyncio
@pytest.mark.parametrize(
    "ray_start_with_dashboard",
    [
        {"num_cpus": 1},
    ],
    indirect=True,
)
async def test_reporter_dashboard_and_runtime_env_agent(
    ray_start_with_dashboard, tmp_path
):
    dashboard_agent = MagicMock()
    dashboard_agent.gcs_address = build_address("127.0.0.1", 6379)
    dashboard_agent.session_dir = str(tmp_path)
    dashboard_agent.node_id = ray.NodeID.from_random().hex()
    dashboard_agent.ip = "127.0.0.1"
    dashboard_agent.node_manager_port = (
        ray._private.worker.global_worker.node.node_manager_port
    )
    agent = ReporterAgent(dashboard_agent)
    agent_pids = await agent._async_get_agent_pids_from_raylet()
    assert len(agent_pids) == 2
    for pid in agent_pids:
        proc = psutil.Process(pid)

        def verify():
            # If linux, proctitle will be cut to 15 chars. So we only check if the
            # proctitle is a substring
            return any(proc.cmdline()[0] in s for s in ray_constants.AGENT_PROCESS_LIST)

        wait_for_condition(verify, timeout=5, retry_interval_ms=100)


# --- Autoscaler cluster-level metrics (v1/v2 compatibility) ---
_AUTOSCALER_TEST_NODE_TYPE = "node_type_a"
_AUTOSCALER_TEST_IPS_PENDING = ("10.0.0.2", "10.0.0.3")
_AUTOSCALER_TEST_IP_FAILED = "10.0.0.4"


def _find_metric_value(records, metric_key: str, node_type: str):
    g = METRICS_GAUGES[metric_key]
    for r in records:
        if r.gauge is g and r.tags == {"node_type": node_type}:
            return r.value
    return None


def _make_reporter_agent_and_capture(tmp_path, *, ip="192.168.79.28"):
    dashboard_agent = MagicMock()
    dashboard_agent.gcs_address = "127.0.0.1:6379"
    dashboard_agent.session_dir = str(tmp_path)
    dashboard_agent.node_id = ray.NodeID.from_random().hex()
    dashboard_agent.ip = "127.0.0.1"
    dashboard_agent.node_manager_port = 12345

    agent = ReporterAgent(dashboard_agent)
    agent._is_head_node = True
    agent._metrics_collection_disabled = False

    captured = {}

    def _capture(records, global_tags=None):
        captured["records"] = records

    agent._metrics_agent = MagicMock()
    agent._metrics_agent.record_and_export.side_effect = _capture
    agent._metrics_agent.clean_all_dead_worker_metrics = MagicMock()

    agent._open_telemetry_metric_recorder = MagicMock()
    agent._open_telemetry_metric_recorder.record_and_export.side_effect = _capture

    async def fake_collect():
        s = copy.deepcopy(STATS_TEMPLATE)
        s["ip"] = ip
        return s

    agent._async_collect_stats = fake_collect
    agent._generate_stats_payload = lambda stats: "{}"

    return agent, captured


def _assert_cluster_node_metrics(
    records, node_type: str, *, active, pending, failed, idle_expected
):
    assert _find_metric_value(records, "cluster_active_nodes", node_type) == active
    assert _find_metric_value(records, "cluster_pending_nodes", node_type) == pending
    assert _find_metric_value(records, "cluster_failed_nodes", node_type) == failed

    idle_val = _find_metric_value(records, "cluster_idle_nodes", node_type)
    if idle_expected is None:
        assert idle_val is None
    else:
        assert idle_val == idle_expected


@pytest.mark.asyncio
async def test_reporter_v1_autoscaler_uses_debug_status_bytes(tmp_path):
    agent, captured = _make_reporter_agent_and_capture(tmp_path)

    agent._get_cluster_stats_v2 = MagicMock()

    node_type = _AUTOSCALER_TEST_NODE_TYPE
    v1_cluster_stats = {
        "autoscaler_report": {
            "active_nodes": {node_type: 1},
            "idle_nodes": None,
            "pending_nodes": [
                (ip, node_type, "PENDING") for ip in _AUTOSCALER_TEST_IPS_PENDING
            ],
            "failed_nodes": [(_AUTOSCALER_TEST_IP_FAILED, node_type)],
        }
    }

    await agent._async_compose_stats_payload(
        json.dumps(v1_cluster_stats).encode(), autoscaler_v2_enabled=False
    )

    recs = captured["records"]
    _assert_cluster_node_metrics(
        recs, node_type, active=1, pending=2, failed=1, idle_expected=None
    )
    agent._get_cluster_stats_v2.assert_not_called()


@pytest.mark.asyncio
async def test_reporter_v2_autoscaler_emits_idle_nodes_metric(tmp_path):
    agent, captured = _make_reporter_agent_and_capture(tmp_path)

    node_type = _AUTOSCALER_TEST_NODE_TYPE
    agent._get_cluster_stats_v2 = MagicMock(
        return_value={
            "autoscaler_report": {
                "active_nodes": {node_type: 1},
                "idle_nodes": {node_type: 2},
                "pending_nodes": [
                    (ip, node_type, "PENDING") for ip in _AUTOSCALER_TEST_IPS_PENDING
                ],
                "failed_nodes": [(_AUTOSCALER_TEST_IP_FAILED, node_type)],
            },
        }
    )

    await agent._async_compose_stats_payload(None, autoscaler_v2_enabled=True)

    recs = captured["records"]
    _assert_cluster_node_metrics(
        recs, node_type, active=1, pending=2, failed=1, idle_expected=2
    )
    agent._get_cluster_stats_v2.assert_called_once()


class _FakeRequest:
    """Minimal stand-in for aiohttp.web.Request exposing only `.query`."""

    def __init__(self, query):
        self.query = query


@pytest.mark.parametrize(
    "query, default, expected",
    [
        # Param absent -> falls back to the configured default (either value).
        ({}, False, False),
        ({}, True, True),
        # Param present -> the explicit value wins, ignoring the default.
        ({"native": "1"}, False, True),
        ({"native": "0"}, True, False),
        # Any non-"1" value is treated as False (matches prior behavior).
        ({"native": "true"}, True, False),
    ],
)
def test_query_flag(query, default, expected):
    assert _query_flag(_FakeRequest(query), "native", default) is expected


@pytest.mark.parametrize(
    "query, default, expected",
    [
        # Param absent -> falls back to the configured default.
        ({}, 5, 5),
        ({}, 10, 10),
        # Param present and in range -> parsed as int, ignoring the default.
        ({"duration": "30"}, 5, 30),
        # Boundary values are accepted (min is always 1; max is configurable).
        ({"duration": "1"}, 5, 1),
        (
            {"duration": str(ray_constants.MAX_PROFILING_DURATION_S)},
            5,
            ray_constants.MAX_PROFILING_DURATION_S,
        ),
    ],
)
def test_query_duration_valid(query, default, expected):
    assert _query_duration(_FakeRequest(query), default) == expected


@pytest.mark.parametrize(
    "value",
    [
        "abc",  # not an integer
        "0",  # below the minimum
        "-5",  # negative
        # just above the (operator-configurable) maximum
        str(ray_constants.MAX_PROFILING_DURATION_S + 1),
    ],
)
def test_query_duration_invalid_raises_bad_request(value):
    # Invalid or out-of-range durations must surface as HTTP 400, not a bare
    # ValueError (which would become a 500).
    with pytest.raises(aiohttp.web.HTTPBadRequest):
        _query_duration(_FakeRequest({"duration": value}), 5)


@pytest.mark.parametrize(
    "seconds, expected",
    [
        # In-range values pass through unchanged.
        (1, 1),
        (5, 5),
        (
            ray_constants.MAX_PROFILING_DURATION_S,
            ray_constants.MAX_PROFILING_DURATION_S,
        ),
        # Out-of-range env-configured values are clamped to the accepted bound,
        # so a misconfigured head-node default can never bypass the endpoint cap.
        (0, 1),
        (-5, 1),
        (
            ray_constants.MAX_PROFILING_DURATION_S + 1,
            ray_constants.MAX_PROFILING_DURATION_S,
        ),
        (10**9, ray_constants.MAX_PROFILING_DURATION_S),
    ],
)
def test_clamp_profiling_duration(seconds, expected):
    assert ray_constants._clamp_profiling_duration(seconds) == expected


def test_clamp_profiling_duration_warns_and_names_the_env_var():
    # A silently clamped value looks like the operator's setting took effect, so
    # the warning must name the env var that was ignored and the bound applied.
    with patch.object(ray_constants.logger, "warning") as mock_warning:
        ray_constants._clamp_profiling_duration(
            ray_constants.MAX_PROFILING_DURATION_S + 1, "RAY_TEST_PROFILING_DURATION"
        )
    assert mock_warning.call_count == 1
    rendered = mock_warning.call_args.args[0] % mock_warning.call_args.args[1:]
    assert "RAY_TEST_PROFILING_DURATION" in rendered
    assert str(ray_constants.MAX_PROFILING_DURATION_S) in rendered


def test_clamp_profiling_duration_silent_when_in_range():
    with patch.object(ray_constants.logger, "warning") as mock_warning:
        ray_constants._clamp_profiling_duration(
            ray_constants.MIN_PROFILING_DURATION_S, "RAY_TEST_PROFILING_DURATION"
        )
    mock_warning.assert_not_called()


# A speedscope profile is JSON, so any markup prepended to it makes it unparseable.
_SPEEDSCOPE_OUTPUT = '{"version": "0.0.1", "profiles": []}'


def test_task_cpu_profiling_response_wraps_flamegraph_in_html():
    resp = _task_cpu_profiling_response("<svg></svg>", "flamegraph", ["task_1"])
    assert resp.content_type == "text/html"
    # SVG_STYLE sizes the flame graph to the viewport, so it must stay.
    assert resp.text == SVG_STYLE + "<svg></svg>"
    assert MULTI_TASK_WARNING_HEADER not in resp.headers


def test_task_cpu_profiling_response_prepends_multi_task_warning_to_flamegraph():
    resp = _task_cpu_profiling_response(
        "<svg></svg>", "flamegraph", ["task_1", "task_2"]
    )
    assert resp.content_type == "text/html"
    assert WARNING_FOR_MULTI_TASK_IN_A_WORKER in resp.text
    assert resp.text.endswith(SVG_STYLE + "<svg></svg>")


@pytest.mark.parametrize(
    "format, output",
    [
        ("raw", "frame_a;frame_b 10"),
        ("speedscope", _SPEEDSCOPE_OUTPUT),
    ],
)
def test_task_cpu_profiling_response_returns_non_flamegraph_verbatim(format, output):
    # Only flamegraph output is an SVG. Wrapping `raw`/`speedscope` in HTML (as
    # this endpoint used to do for every format) corrupts the payload.
    resp = _task_cpu_profiling_response(output, format, ["task_1"])
    assert resp.content_type == "text/plain"
    assert resp.text == output
    assert SVG_STYLE not in resp.text


@pytest.mark.parametrize("format", ["raw", "speedscope"])
def test_task_cpu_profiling_response_moves_multi_task_warning_to_header(format):
    # The warning is an HTML fragment, so for non-HTML formats it has to travel
    # out of band rather than be dropped or spliced into the body.
    resp = _task_cpu_profiling_response(
        _SPEEDSCOPE_OUTPUT, format, ["task_1", "task_2"]
    )
    assert resp.text == _SPEEDSCOPE_OUTPUT
    assert WARNING_FOR_MULTI_TASK_IN_A_WORKER in resp.headers[MULTI_TASK_WARNING_HEADER]
    assert "task_2" in resp.headers[MULTI_TASK_WARNING_HEADER]


def test_task_cpu_profiling_response_keeps_speedscope_output_parseable():
    # The regression this guards: speedscope output served as HTML with
    # SVG_STYLE prepended is rejected by speedscope.app as invalid JSON.
    resp = _task_cpu_profiling_response(
        _SPEEDSCOPE_OUTPUT, "speedscope", ["task_1", "task_2"]
    )
    assert json.loads(resp.text) == {"version": "0.0.1", "profiles": []}


@pytest.mark.parametrize(
    "env_value, valid_formats, expected",
    [
        # Valid values pass through unchanged.
        ("flamegraph", ray_constants.VALID_CPU_PROFILING_FORMATS, "flamegraph"),
        ("speedscope", ray_constants.VALID_CPU_PROFILING_FORMATS, "speedscope"),
        ("table", ray_constants.VALID_MEMORY_PROFILING_FORMATS, "table"),
        # Invalid values fall back to flamegraph.
        ("bogus", ray_constants.VALID_CPU_PROFILING_FORMATS, "flamegraph"),
        # The valid sets differ by profiler: `speedscope` is a py-spy (CPU) format
        # and must be rejected for memray (memory) profiling, and vice versa for
        # `table`. This guards against a single shared format default.
        ("speedscope", ray_constants.VALID_MEMORY_PROFILING_FORMATS, "flamegraph"),
        ("table", ray_constants.VALID_CPU_PROFILING_FORMATS, "flamegraph"),
    ],
)
def test_validated_profiling_format(monkeypatch, env_value, valid_formats, expected):
    monkeypatch.setenv("RAY_TEST_PROFILING_FORMAT", env_value)
    assert (
        ray_constants._validated_profiling_format(
            "RAY_TEST_PROFILING_FORMAT", valid_formats
        )
        == expected
    )


def test_validated_profiling_format_absent_uses_fallback(monkeypatch):
    monkeypatch.delenv("RAY_TEST_PROFILING_FORMAT", raising=False)
    assert (
        ray_constants._validated_profiling_format(
            "RAY_TEST_PROFILING_FORMAT", ray_constants.VALID_CPU_PROFILING_FORMATS
        )
        == "flamegraph"
    )


def test_profiling_enabled_endpoint_returns_defaults(shutdown_only):
    """`/api/profiling_enabled` exposes the profiling defaults (camelCased)."""
    address_info = ray.init()
    assert wait_until_server_available(address_info["webui_url"])
    webui_url = format_web_url(address_info["webui_url"])

    def verify():
        resp = requests.get(f"{webui_url}/api/profiling_enabled")
        resp.raise_for_status()
        data = resp.json()["data"]
        assert data["profilingEnabled"] is True
        defaults = data["profilingDefaults"]
        # snake_case keys are google-style-cased in the response.
        for key in (
            "native",
            "subprocesses",
            "idle",
            "leaks",
            "tracePythonAllocators",
            "cpuDuration",
            "memoryDuration",
            "maxDuration",
            "cpuFormat",
            "memoryFormat",
            "pyspyNativeSupported",
        ):
            assert key in defaults, f"missing {key} in {defaults}"
        # Spot-check defaults match the constants' shipped values.
        assert defaults["cpuDuration"] == 5
        assert defaults["memoryDuration"] == 10
        assert defaults["cpuFormat"] == "flamegraph"
        return True

    wait_for_condition(verify, timeout=20)


if __name__ == "__main__":
    sys.exit(pytest.main(["-v", __file__]))
