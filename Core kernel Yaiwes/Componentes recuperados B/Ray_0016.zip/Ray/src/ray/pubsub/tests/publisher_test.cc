// Copyright 2017 The Ray Authors.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//  http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#include "ray/pubsub/publisher.h"

#include <algorithm>
#include <memory>
#include <string>
#include <vector>

#include "gtest/gtest.h"
#include "ray/asio/instrumented_io_context.h"
#include "ray/asio/periodical_runner.h"
#include "ray/common/ray_config.h"

namespace ray {

namespace pubsub {

namespace {
const NodeID kDefaultPublisherId = NodeID::FromRandom();
}

class PublisherTest : public ::testing::Test {
 public:
  PublisherTest() : periodical_runner_(PeriodicalRunner::Create(io_service_)) {}

  void SetUp() override {
    publisher_ = std::make_shared<Publisher>(
        /*channels=*/
        std::vector<rpc::ChannelType>{
            rpc::ChannelType::WORKER_REF_REMOVED_CHANNEL,
            rpc::ChannelType::WORKER_OBJECT_LOCATIONS_CHANNEL,
            rpc::ChannelType::RAY_ERROR_INFO_CHANNEL,
        },
        /*periodical_runner=*/*periodical_runner_,
        /*clock=*/fake_clock_,
        /*subscriber_timeout_ms=*/subscriber_timeout_ms_,
        /*batch_size*/ 100,
        kDefaultPublisherId);
    request_.set_subscriber_id(subscriber_id_.Binary());
    request_.set_publisher_id(kDefaultPublisherId.Binary());
  }

  void ResetSequenceId() { sequence_id_ = 0; }

  int64_t GetNextSequenceId() { return ++sequence_id_; }

  rpc::PubMessage GeneratePubMessage(const ObjectID &object_id, int64_t sequence_id = 0) {
    rpc::PubMessage pub_message;
    pub_message.mutable_worker_object_locations_message();
    pub_message.set_key_id(object_id.Binary());
    pub_message.set_channel_type(rpc::ChannelType::WORKER_OBJECT_LOCATIONS_CHANNEL);
    RAY_LOG(INFO) << "message sequence_id is " << sequence_id;
    pub_message.set_sequence_id(sequence_id);
    return pub_message;
  }

  rpc::PubMessage GenerateErrorInfoMessage(const std::string &id,
                                           const std::string &text) {
    rpc::PubMessage pub_message;
    auto *error_msg = pub_message.mutable_error_info_message();
    error_msg->set_error_message(text);
    pub_message.set_key_id(id);
    pub_message.set_channel_type(rpc::ChannelType::RAY_ERROR_INFO_CHANNEL);
    return pub_message;
  }

  bool HasSubscriber(const std::vector<UniqueID> &subscribers,
                     const UniqueID &subscriber) {
    return std::find(subscribers.begin(), subscribers.end(), subscriber) !=
           subscribers.end();
  }

  SubscriberState *CreateSubscriber() {
    subscribers_.push_back(
        std::make_unique<SubscriberState>(NodeID::FromRandom(),
                                          /*clock=*/fake_clock_,
                                          /*subscriber_timeout_ms=*/1000,
                                          /*publish_batch_size=*/1000,
                                          kDefaultPublisherId));
    return subscribers_.back().get();
  }

  std::shared_ptr<rpc::PubsubLongPollingReply> FlushSubscriber(
      SubscriberState *subscriber, int64_t max_processed_sequence_id = -1) {
    rpc::PubsubLongPollingRequest request;
    auto pubsub_reply = std::make_shared<rpc::PubsubLongPollingReply>();
    request.set_publisher_id(kDefaultPublisherId.Binary());
    if (max_processed_sequence_id >= 0) {
      request.set_max_processed_sequence_id(max_processed_sequence_id);
    }
    rpc::SendReplyCallback callback = [pubsub_reply](Status status,
                                                     std::function<void()> success,
                                                     std::function<void()> failure) {};
    subscriber->ConnectToSubscriber(request,
                                    pubsub_reply->mutable_publisher_id(),
                                    pubsub_reply->mutable_pub_messages(),
                                    callback);
    subscriber->PublishIfPossible(/*force_noop=*/false);
    return pubsub_reply;
  }

  instrumented_io_context io_service_;
  rpc::PubsubLongPollingReply reply;
  rpc::SendReplyCallback send_reply_callback;
  std::shared_ptr<PeriodicalRunner> periodical_runner_;
  // Declared before publisher_/subscribers_ so it outlives the objects that hold a
  // ClockInterface& to it. Tests drive time via AdvanceTime().
  FakeClock fake_clock_;
  std::shared_ptr<Publisher> publisher_;
  absl::flat_hash_map<ObjectID, absl::flat_hash_set<NodeID>> subscribers_map_;
  const uint64_t subscriber_timeout_ms_ = 30000;
  const UniqueID subscriber_id_ = UniqueID::FromRandom();
  rpc::PubsubLongPollingRequest request_;
  std::vector<std::unique_ptr<SubscriberState>> subscribers_;
  int64_t sequence_id_ = 0;
};

TEST_F(PublisherTest, TestSubscriptionIndexSingeNodeSingleObject) {
  auto oid = ObjectID::FromRandom();
  auto *subscriber = CreateSubscriber();

  ///
  /// Test single node id & object id
  ///
  /// oid1 -> [nid1]
  SubscriptionIndex subscription_index(rpc::ChannelType::RAY_ERROR_INFO_CHANNEL);
  subscription_index.AddEntry(oid.Binary(), subscriber);
  const auto &subscribers_from_index =
      subscription_index.GetSubscriberIdsByKeyId(oid.Binary());
  ASSERT_TRUE(HasSubscriber(subscribers_from_index, subscriber->id()));
}

TEST_F(PublisherTest, TestSubscriptionIndexMultiNodeSingleObject) {
  ///
  /// Test single object id & multi nodes
  ///
  /// oid1 -> [nid1~nid5]
  SubscriptionIndex subscription_index(rpc::ChannelType::RAY_ERROR_INFO_CHANNEL);
  const auto oid = ObjectID::FromRandom();
  absl::flat_hash_set<NodeID> empty_set;
  subscribers_map_.emplace(oid, empty_set);

  for (int i = 0; i < 5; i++) {
    auto *subscriber = CreateSubscriber();
    auto subscriber_id = subscriber->id();
    subscribers_map_.at(oid).emplace(subscriber_id);
    subscription_index.AddEntry(oid.Binary(), subscriber);
  }
  const auto &subscribers_from_index =
      subscription_index.GetSubscriberIdsByKeyId(oid.Binary());
  for (const auto &subscriber_id : subscribers_map_.at(oid)) {
    ASSERT_TRUE(HasSubscriber(subscribers_from_index, subscriber_id));
  }

  ///
  /// Test multi node id & multi object ids
  ///
  /// oid1 -> [nid1~nid5]
  /// oid2 -> [nid1~nid5]
  const auto oid2 = ObjectID::FromRandom();
  subscribers_map_.emplace(oid2, empty_set);
  for (int i = 0; i < 5; i++) {
    auto *subscriber = CreateSubscriber();
    auto subscriber_id = subscriber->id();
    subscribers_map_.at(oid2).emplace(subscriber_id);
    subscription_index.AddEntry(oid2.Binary(), subscriber);
  }
  const auto &subscribers_from_index2 =
      subscription_index.GetSubscriberIdsByKeyId(oid2.Binary());
  for (const auto &subscriber_id : subscribers_map_.at(oid2)) {
    ASSERT_TRUE(HasSubscriber(subscribers_from_index2, subscriber_id));
  }

  // Make sure oid1 entries are not corrupted.
  const auto &subscribers_from_index3 =
      subscription_index.GetSubscriberIdsByKeyId(oid.Binary());
  for (const auto &subscriber_id : subscribers_map_.at(oid)) {
    ASSERT_TRUE(HasSubscriber(subscribers_from_index3, subscriber_id));
  }
}

TEST_F(PublisherTest, TestSubscriptionIndexErase) {
  ///
  /// Test erase entry.
  ///
  /// oid1 -> [nid1~nid5]
  /// oid2 -> [nid1~nid5]
  SubscriptionIndex subscription_index(rpc::ChannelType::RAY_ERROR_INFO_CHANNEL);
  int total_entries = 6;
  int entries_to_delete_at_each_time = 3;
  auto oid = ObjectID::FromRandom();
  absl::flat_hash_set<NodeID> empty_set;
  subscribers_map_.emplace(oid, empty_set);

  // Add entries.
  for (int i = 0; i < total_entries; i++) {
    auto *subscriber = CreateSubscriber();
    auto subscriber_id = subscriber->id();
    subscribers_map_.at(oid).emplace(subscriber_id);
    subscription_index.AddEntry(oid.Binary(), subscriber);
  }

  // Verify that the first 3 entries are deleted properly.
  int i = 0;
  auto &oid_subscribers = subscribers_map_[oid];
  for (auto it = oid_subscribers.begin(); it != oid_subscribers.end();) {
    if (i == entries_to_delete_at_each_time) {
      break;
    }
    auto current = it++;
    auto subscriber_id = *current;
    oid_subscribers.erase(current);
    subscription_index.EraseEntry(oid.Binary(), subscriber_id);
    i++;
  }
  const auto &subscribers_from_index =
      subscription_index.GetSubscriberIdsByKeyId(oid.Binary());
  for (const auto &subscriber_id : subscribers_map_.at(oid)) {
    ASSERT_TRUE(HasSubscriber(subscribers_from_index, subscriber_id));
  }

  // Delete all entries and make sure the oid is removed from the index.
  for (auto it = oid_subscribers.begin(); it != oid_subscribers.end();) {
    auto current = it++;
    auto subscriber_id = *current;
    oid_subscribers.erase(current);
    subscription_index.EraseEntry(oid.Binary(), subscriber_id);
  }
  ASSERT_FALSE(subscription_index.HasKeyId(oid.Binary()));
  ASSERT_TRUE(subscription_index.CheckNoLeaks());
}

TEST_F(PublisherTest, TestSubscriptionIndexEraseMultiSubscribers) {
  ///
  /// Test erase the duplicated entries with multi subscribers.
  ///
  SubscriptionIndex subscription_index(rpc::ChannelType::RAY_ERROR_INFO_CHANNEL);
  auto oid = ObjectID::FromRandom();
  auto oid2 = ObjectID::FromRandom();
  absl::flat_hash_set<NodeID> empty_set;
  subscribers_map_.emplace(oid, empty_set);
  subscribers_map_.emplace(oid2, empty_set);

  // Add entries.
  auto *subscriber_1 = CreateSubscriber();
  auto subscriber_id = subscriber_1->id();
  auto *subscriber_2 = CreateSubscriber();
  subscribers_map_.at(oid).emplace(subscriber_id);
  subscribers_map_.at(oid2).emplace(subscriber_id);
  subscription_index.AddEntry(oid.Binary(), subscriber_1);
  subscription_index.AddEntry(oid2.Binary(), subscriber_1);
  subscription_index.AddEntry(oid.Binary(), subscriber_2);
  subscription_index.EraseEntry(oid.Binary(), subscriber_id);
  subscription_index.EraseEntry(oid.Binary(), subscriber_id);
}

TEST_F(PublisherTest, TestSubscriptionIndexEraseSubscriber) {
  ///
  /// Test erase subscriber.
  ///
  SubscriptionIndex subscription_index(rpc::ChannelType::RAY_ERROR_INFO_CHANNEL);
  auto oid = ObjectID::FromRandom();
  auto &subscribers = subscribers_map_[oid];
  std::vector<UniqueID> subscriber_ids;

  // Add entries.
  for (int i = 0; i < 6; i++) {
    auto *subscriber = CreateSubscriber();
    auto subscriber_id = subscriber->id();
    subscriber_ids.push_back(subscriber_id);
    subscribers.emplace(subscriber_id);
    subscription_index.AddEntry(oid.Binary(), subscriber);
  }
  subscription_index.EraseSubscriber(subscriber_ids[0]);
  ASSERT_FALSE(subscription_index.HasSubscriber(subscriber_ids[0]));
  const auto &subscribers_from_index =
      subscription_index.GetSubscriberIdsByKeyId(oid.Binary());
  ASSERT_FALSE(HasSubscriber(subscribers_from_index, subscriber_ids[0]));

  for (int i = 1; i < 6; i++) {
    subscription_index.EraseSubscriber(subscriber_ids[i]);
  }
  ASSERT_TRUE(subscription_index.CheckNoLeaks());
}

TEST_F(PublisherTest, TestSubscriptionIndexIdempotency) {
  ///
  /// Test the subscription index is idempotent.
  ///
  auto *subscriber = CreateSubscriber();
  auto subscriber_id = subscriber->id();
  auto oid = ObjectID::FromRandom();
  SubscriptionIndex subscription_index(rpc::ChannelType::RAY_ERROR_INFO_CHANNEL);

  // Add the same entry many times.
  for (int i = 0; i < 5; i++) {
    subscription_index.AddEntry(oid.Binary(), subscriber);
  }
  ASSERT_TRUE(subscription_index.HasKeyId(oid.Binary()));
  ASSERT_TRUE(subscription_index.HasSubscriber(subscriber_id));

  // Erase it and make sure it is erased.
  for (int i = 0; i < 5; i++) {
    subscription_index.EraseEntry(oid.Binary(), subscriber_id);
  }
  ASSERT_TRUE(subscription_index.CheckNoLeaks());

  // Random mix.
  subscription_index.AddEntry(oid.Binary(), subscriber);
  subscription_index.AddEntry(oid.Binary(), subscriber);
  subscription_index.EraseEntry(oid.Binary(), subscriber_id);
  subscription_index.EraseEntry(oid.Binary(), subscriber_id);
  ASSERT_TRUE(subscription_index.CheckNoLeaks());

  subscription_index.AddEntry(oid.Binary(), subscriber);
  subscription_index.AddEntry(oid.Binary(), subscriber);
  ASSERT_TRUE(subscription_index.HasKeyId(oid.Binary()));
  ASSERT_TRUE(subscription_index.HasSubscriber(subscriber_id));
}

TEST_F(PublisherTest, TestSubscriber) {
  absl::flat_hash_set<ObjectID> object_ids_published;
  reply = rpc::PubsubLongPollingReply();
  send_reply_callback = [this, &object_ids_published](Status status,
                                                      std::function<void()> success,
                                                      std::function<void()> failure) {
    for (int i = 0; i < reply.pub_messages_size(); i++) {
      const auto &msg = reply.pub_messages(i);
      const auto oid = ObjectID::FromBinary(msg.key_id());
      object_ids_published.emplace(oid);
    }
    reply.Clear();
  };

  auto subscriber = std::make_shared<SubscriberState>(
      subscriber_id_, fake_clock_, subscriber_timeout_ms_, 10, kDefaultPublisherId);
  // If there's no connection, it will return false.
  subscriber->PublishIfPossible(/*force_noop=*/false);
  // Try connecting.
  subscriber->ConnectToSubscriber(request_,
                                  reply.mutable_publisher_id(),
                                  reply.mutable_pub_messages(),
                                  send_reply_callback);
  // Reconnection should still succeed.
  subscriber->ConnectToSubscriber(request_,
                                  reply.mutable_publisher_id(),
                                  reply.mutable_pub_messages(),
                                  send_reply_callback);
  // No result should have been returned.
  ASSERT_TRUE(object_ids_published.empty());
  subscriber->PublishIfPossible(/*force_noop=*/false);
  ASSERT_TRUE(object_ids_published.empty());

  absl::flat_hash_set<ObjectID> expected_published_objects;
  // Make sure publishing one object works as expected.
  auto oid = ObjectID::FromRandom();
  subscriber->QueueMessage(
      std::make_shared<rpc::PubMessage>(GeneratePubMessage(oid, GetNextSequenceId())));
  expected_published_objects.emplace(oid);
  subscriber->PublishIfPossible(/*force_noop=*/false);
  ASSERT_TRUE(object_ids_published.contains(oid));
  // No object is pending to be published, and there's no connection.
  subscriber->PublishIfPossible(/*force_noop=*/false);

  // Add 3 oids and see if it works properly.
  for (int i = 0; i < 3; i++) {
    oid = ObjectID::FromRandom();
    subscriber->QueueMessage(
        std::make_shared<rpc::PubMessage>(GeneratePubMessage(oid, GetNextSequenceId())));
    expected_published_objects.emplace(oid);
  }
  // Since there's no connection, objects won't be published.
  subscriber->PublishIfPossible(/*force_noop=*/false);
  subscriber->ConnectToSubscriber(request_,
                                  reply.mutable_publisher_id(),
                                  reply.mutable_pub_messages(),
                                  send_reply_callback);
  ASSERT_EQ(expected_published_objects, object_ids_published);

  // Queue is not cleaned up if max_processed_sequence_id hasn't
  // been set properly.
  request_.set_max_processed_sequence_id(1);
  subscriber->ConnectToSubscriber(request_,
                                  reply.mutable_publisher_id(),
                                  reply.mutable_pub_messages(),
                                  send_reply_callback);
  ASSERT_FALSE(subscriber->CheckNoLeaks());

  // If we set wrong publisher_id, the queue won't be cleaned up.
  request_.set_publisher_id(NodeID::FromRandom().Binary());
  request_.set_max_processed_sequence_id(sequence_id_);
  subscriber->ConnectToSubscriber(request_,
                                  reply.mutable_publisher_id(),
                                  reply.mutable_pub_messages(),
                                  send_reply_callback);
  ASSERT_FALSE(subscriber->CheckNoLeaks());

  // By sending back max_processed_sequence_id, the subscriber's sending queue
  // is cleaned up.
  request_.set_max_processed_sequence_id(sequence_id_);
  request_.set_publisher_id(kDefaultPublisherId.Binary());
  subscriber->ConnectToSubscriber(request_,
                                  reply.mutable_publisher_id(),
                                  reply.mutable_pub_messages(),
                                  send_reply_callback);
  ASSERT_TRUE(subscriber->CheckNoLeaks());
}

TEST_F(PublisherTest, TestSubscriberBatchSize) {
  absl::flat_hash_set<ObjectID> object_ids_published;
  int64_t max_processed_sequence_id = 0;
  send_reply_callback = [this, &object_ids_published, &max_processed_sequence_id](
                            Status status,
                            std::function<void()> success,
                            std::function<void()> failure) {
    for (int i = 0; i < reply.pub_messages_size(); i++) {
      const auto &msg = reply.pub_messages(i);
      const auto oid = ObjectID::FromBinary(msg.key_id());
      object_ids_published.emplace(oid);
      max_processed_sequence_id = std::max(msg.sequence_id(), max_processed_sequence_id);
    }
    reply = rpc::PubsubLongPollingReply();
  };

  auto max_publish_size = 5;
  auto subscriber = std::make_shared<SubscriberState>(subscriber_id_,
                                                      fake_clock_,
                                                      subscriber_timeout_ms_,
                                                      max_publish_size,
                                                      kDefaultPublisherId);

  std::vector<ObjectID> oids;
  for (int i = 0; i < 10; i++) {
    auto oid = ObjectID::FromRandom();
    oids.push_back(oid);
    subscriber->QueueMessage(
        std::make_shared<rpc::PubMessage>(GeneratePubMessage(oid, GetNextSequenceId())));
  }

  subscriber->ConnectToSubscriber(request_,
                                  reply.mutable_publisher_id(),
                                  reply.mutable_pub_messages(),
                                  send_reply_callback);

  for (int i = 0; i < max_publish_size; i++) {
    ASSERT_TRUE(object_ids_published.contains(oids[i]));
  }
  for (int i = max_publish_size; i < 10; i++) {
    ASSERT_FALSE(object_ids_published.contains(oids[i]));
  }

  // Remaining messages are published upon polling.
  ASSERT_EQ(max_processed_sequence_id, max_publish_size);
  request_.set_max_processed_sequence_id(max_processed_sequence_id);
  subscriber->ConnectToSubscriber(request_,
                                  reply.mutable_publisher_id(),
                                  reply.mutable_pub_messages(),
                                  send_reply_callback);
  for (int i = 0; i < 10; i++) {
    ASSERT_TRUE(object_ids_published.contains(oids[i]));
  }
}

TEST_F(PublisherTest, TestSubscriberActiveTimeout) {
  ///
  /// Test the active connection timeout.
  ///

  auto reply_count = 0;
  send_reply_callback = [&reply_count](Status status,
                                       std::function<void()> success,
                                       std::function<void()> failure) { reply_count++; };

  auto subscriber = std::make_shared<SubscriberState>(
      subscriber_id_, fake_clock_, subscriber_timeout_ms_, 10, kDefaultPublisherId);

  subscriber->ConnectToSubscriber(request_,
                                  reply.mutable_publisher_id(),
                                  reply.mutable_pub_messages(),
                                  send_reply_callback);

  // Connection is not timed out yet.
  ASSERT_TRUE(subscriber->IsActive());
  ASSERT_TRUE(subscriber->ConnectionExists());

  // Some time has passed, but it is not timed out yet.
  fake_clock_.AdvanceTime(absl::Milliseconds(subscriber_timeout_ms_ / 2));
  ASSERT_TRUE(subscriber->IsActive());
  ASSERT_TRUE(subscriber->ConnectionExists());

  // Timeout is reached, and the long polling connection should've been refreshed.
  fake_clock_.AdvanceTime(absl::Milliseconds(subscriber_timeout_ms_ / 2));
  ASSERT_FALSE(subscriber->IsActive());
  ASSERT_TRUE(subscriber->ConnectionExists());

  // Refresh the connection.
  subscriber->PublishIfPossible(/*force_noop=*/true);
  ASSERT_EQ(reply_count, 1);

  // New connection is established.
  reply = rpc::PubsubLongPollingReply();
  subscriber->ConnectToSubscriber(request_,
                                  reply.mutable_publisher_id(),
                                  reply.mutable_pub_messages(),
                                  send_reply_callback);
  ASSERT_TRUE(subscriber->IsActive());
  ASSERT_TRUE(subscriber->ConnectionExists());

  // Some time has passed, but it is not timed out yet.
  fake_clock_.AdvanceTime(absl::Milliseconds(subscriber_timeout_ms_ / 2));
  ASSERT_TRUE(subscriber->IsActive());
  ASSERT_TRUE(subscriber->ConnectionExists());

  // A message is published, so the connection is refreshed.
  auto oid = ObjectID::FromRandom();
  subscriber->QueueMessage(
      std::make_shared<rpc::PubMessage>(GeneratePubMessage(oid, GetNextSequenceId())));
  ASSERT_TRUE(subscriber->IsActive());
  ASSERT_FALSE(subscriber->ConnectionExists());
  ASSERT_EQ(reply_count, 2);

  // Although time has passed, since the connection was refreshed, timeout shouldn't
  // happen.
  fake_clock_.AdvanceTime(absl::Milliseconds(subscriber_timeout_ms_ / 2));
  ASSERT_TRUE(subscriber->IsActive());
  ASSERT_FALSE(subscriber->ConnectionExists());

  // There is one message to be GCed.
  ASSERT_FALSE(subscriber->CheckNoLeaks());

  // Notify that message 1 is safe to be GCed.
  request_.set_max_processed_sequence_id(1);
  reply = rpc::PubsubLongPollingReply();
  subscriber->ConnectToSubscriber(request_,
                                  reply.mutable_publisher_id(),
                                  reply.mutable_pub_messages(),
                                  send_reply_callback);
  ASSERT_TRUE(subscriber->CheckNoLeaks());
}

TEST_F(PublisherTest, TestSubscriberDisconnected) {
  ///
  /// Test the subscriber is considered as dead due to the disconnection timeout.
  ///

  auto reply_count = 0;
  send_reply_callback = [&reply_count](Status status,
                                       std::function<void()> success,
                                       std::function<void()> failure) { reply_count++; };

  auto subscriber = std::make_shared<SubscriberState>(
      subscriber_id_, fake_clock_, subscriber_timeout_ms_, 10, kDefaultPublisherId);

  // Suppose the new connection is removed.
  subscriber->ConnectToSubscriber(request_,
                                  reply.mutable_publisher_id(),
                                  reply.mutable_pub_messages(),
                                  send_reply_callback);
  subscriber->PublishIfPossible(/*force_noop=*/true);
  ASSERT_EQ(reply_count, 1);
  ASSERT_TRUE(subscriber->IsActive());
  ASSERT_FALSE(subscriber->ConnectionExists());

  // Some time has passed, but it is not timed out yet.
  fake_clock_.AdvanceTime(absl::Milliseconds(subscriber_timeout_ms_ / 2));
  ASSERT_TRUE(subscriber->IsActive());
  ASSERT_FALSE(subscriber->ConnectionExists());

  // Timeout is reached. Since there was no new long polling connection, it is considered
  // as disconnected.
  fake_clock_.AdvanceTime(absl::Milliseconds(subscriber_timeout_ms_ / 2));
  ASSERT_FALSE(subscriber->IsActive());
  ASSERT_FALSE(subscriber->ConnectionExists());

  // New connection is coming in.
  subscriber->ConnectToSubscriber(request_,
                                  reply.mutable_publisher_id(),
                                  reply.mutable_pub_messages(),
                                  send_reply_callback);
  subscriber->PublishIfPossible(/*force_noop=*/true);
  ASSERT_EQ(reply_count, 2);

  // Some time has passed, but it is not timed out yet.
  fake_clock_.AdvanceTime(absl::Milliseconds(subscriber_timeout_ms_ / 2));
  ASSERT_TRUE(subscriber->IsActive());
  ASSERT_FALSE(subscriber->ConnectionExists());

  // Another connection is made, so it shouldn't timeout until the next timeout is
  // reached.
  subscriber->ConnectToSubscriber(request_,
                                  reply.mutable_publisher_id(),
                                  reply.mutable_pub_messages(),
                                  send_reply_callback);
  subscriber->PublishIfPossible(/*force_noop=*/true);
  ASSERT_EQ(reply_count, 3);
  fake_clock_.AdvanceTime(absl::Milliseconds(subscriber_timeout_ms_ / 2));
  ASSERT_TRUE(subscriber->IsActive());
  ASSERT_FALSE(subscriber->ConnectionExists());

  // IF there's no new connection for a long time it should eventually timeout.
  fake_clock_.AdvanceTime(absl::Milliseconds(subscriber_timeout_ms_ / 2));
  ASSERT_FALSE(subscriber->IsActive());
  ASSERT_FALSE(subscriber->ConnectionExists());

  ASSERT_TRUE(subscriber->CheckNoLeaks());
}

TEST_F(PublisherTest, TestSubscriberTimeoutComplicated) {
  ///
  /// Test the subscriber timeout in more complicated scenario.
  ///

  auto reply_count = 0;
  send_reply_callback = [&reply_count](Status status,
                                       std::function<void()> success,
                                       std::function<void()> failure) { reply_count++; };

  auto subscriber = std::make_shared<SubscriberState>(
      subscriber_id_, fake_clock_, subscriber_timeout_ms_, 10, kDefaultPublisherId);

  // Suppose the new connection is removed.
  subscriber->ConnectToSubscriber(request_,
                                  reply.mutable_publisher_id(),
                                  reply.mutable_pub_messages(),
                                  send_reply_callback);
  subscriber->PublishIfPossible(/*force_noop=*/true);
  ASSERT_EQ(reply_count, 1);
  ASSERT_TRUE(subscriber->IsActive());
  ASSERT_FALSE(subscriber->ConnectionExists());

  // Some time has passed, and the connection is removed.
  fake_clock_.AdvanceTime(absl::Milliseconds(subscriber_timeout_ms_ - 1));
  subscriber->ConnectToSubscriber(request_,
                                  reply.mutable_publisher_id(),
                                  reply.mutable_pub_messages(),
                                  send_reply_callback);
  fake_clock_.AdvanceTime(absl::Milliseconds(2));
  // Timeout shouldn't happen because the connection has been refreshed.
  ASSERT_TRUE(subscriber->IsActive());
  ASSERT_TRUE(subscriber->ConnectionExists());

  // Right before the timeout, connection is removed. In this case, timeout shouldn't also
  // happen.
  fake_clock_.AdvanceTime(absl::Milliseconds(subscriber_timeout_ms_ - 1));
  subscriber->PublishIfPossible(/*force_noop=*/true);
  fake_clock_.AdvanceTime(absl::Milliseconds(2));
  ASSERT_TRUE(subscriber->IsActive());
  ASSERT_FALSE(subscriber->ConnectionExists());

  // Timeout is reached. Since there was no connection, it should be considered
  // disconnected.
  fake_clock_.AdvanceTime(absl::Milliseconds(subscriber_timeout_ms_));
  ASSERT_FALSE(subscriber->IsActive());
  ASSERT_FALSE(subscriber->ConnectionExists());

  ASSERT_TRUE(subscriber->CheckNoLeaks());
}

TEST_F(PublisherTest, TestBasicSingleSubscriber) {
  std::vector<ObjectID> batched_ids;
  send_reply_callback = [this, &batched_ids](Status status,
                                             std::function<void()> success,
                                             std::function<void()> failure) {
    for (int i = 0; i < reply.pub_messages_size(); i++) {
      const auto &msg = reply.pub_messages(i);
      const auto oid = ObjectID::FromBinary(msg.key_id());
      batched_ids.push_back(oid);
    }
    reply = rpc::PubsubLongPollingReply();
  };

  const auto oid = ObjectID::FromRandom();

  publisher_->ConnectToSubscriber(request_,
                                  reply.mutable_publisher_id(),
                                  reply.mutable_pub_messages(),
                                  send_reply_callback);
  RAY_CHECK(publisher_
                ->RegisterSubscription(rpc::ChannelType::WORKER_OBJECT_LOCATIONS_CHANNEL,
                                       subscriber_id_,
                                       oid.Binary())
                .ok())
      << "Register subscription for a valid channel type should succeed.";
  publisher_->Publish(GeneratePubMessage(oid, 0));
  ASSERT_EQ(batched_ids[0], oid);
}

TEST_F(PublisherTest, TestNoConnectionWhenRegistered) {
  std::vector<ObjectID> batched_ids;
  send_reply_callback = [this, &batched_ids](Status status,
                                             std::function<void()> success,
                                             std::function<void()> failure) {
    for (int i = 0; i < reply.pub_messages_size(); i++) {
      const auto &msg = reply.pub_messages(i);
      const auto oid = ObjectID::FromBinary(msg.key_id());
      batched_ids.push_back(oid);
    }
    reply = rpc::PubsubLongPollingReply();
  };

  const auto oid = ObjectID::FromRandom();

  RAY_CHECK(publisher_
                ->RegisterSubscription(rpc::ChannelType::WORKER_OBJECT_LOCATIONS_CHANNEL,
                                       subscriber_id_,
                                       oid.Binary())
                .ok())
      << "Register subscription for a valid channel type should succeed.";
  publisher_->Publish(GeneratePubMessage(oid));
  // Nothing has been published because there's no connection.
  ASSERT_EQ(batched_ids.size(), 0);
  publisher_->ConnectToSubscriber(request_,
                                  reply.mutable_publisher_id(),
                                  reply.mutable_pub_messages(),
                                  send_reply_callback);
  // When the connection is coming, it should be published.
  ASSERT_EQ(batched_ids[0], oid);
}

TEST_F(PublisherTest, TestMultiObjectsFromSingleNode) {
  std::vector<ObjectID> batched_ids;
  send_reply_callback = [this, &batched_ids](Status status,
                                             std::function<void()> success,
                                             std::function<void()> failure) {
    for (int i = 0; i < reply.pub_messages_size(); i++) {
      const auto &msg = reply.pub_messages(i);
      const auto oid = ObjectID::FromBinary(msg.key_id());
      batched_ids.push_back(oid);
    }
    reply = rpc::PubsubLongPollingReply();
  };

  std::vector<ObjectID> oids;
  int num_oids = 5;
  for (int i = 0; i < num_oids; i++) {
    const auto oid = ObjectID::FromRandom();
    oids.push_back(oid);
    RAY_CHECK(
        publisher_
            ->RegisterSubscription(rpc::ChannelType::WORKER_OBJECT_LOCATIONS_CHANNEL,
                                   subscriber_id_,
                                   oid.Binary())
            .ok())
        << "Register subscription for a valid channel type should succeed.";
    publisher_->Publish(GeneratePubMessage(oid));
  }
  ASSERT_EQ(batched_ids.size(), 0);

  // Now connection is initiated, and all oids are published.
  publisher_->ConnectToSubscriber(request_,
                                  reply.mutable_publisher_id(),
                                  reply.mutable_pub_messages(),
                                  send_reply_callback);
  for (int i = 0; i < num_oids; i++) {
    const auto oid_test = oids[i];
    const auto published_oid = batched_ids[i];
    ASSERT_EQ(oid_test, published_oid);
  }
}

TEST_F(PublisherTest, TestMultiObjectsFromMultiNodes) {
  std::vector<ObjectID> batched_ids;
  send_reply_callback = [this, &batched_ids](Status status,
                                             std::function<void()> success,
                                             std::function<void()> failure) {
    for (int i = 0; i < reply.pub_messages_size(); i++) {
      const auto &msg = reply.pub_messages(i);
      const auto oid = ObjectID::FromBinary(msg.key_id());
      batched_ids.push_back(oid);
    }
    reply = rpc::PubsubLongPollingReply();
  };

  std::vector<NodeID> subscribers;
  std::vector<ObjectID> oids;
  int num_nodes = 5;
  for (int i = 0; i < num_nodes; i++) {
    oids.push_back(ObjectID::FromRandom());
    subscribers.push_back(NodeID::FromRandom());
  }

  // There will be one object per node.
  for (int i = 0; i < num_nodes; i++) {
    const auto oid = oids[i];
    RAY_CHECK(
        publisher_
            ->RegisterSubscription(rpc::ChannelType::WORKER_OBJECT_LOCATIONS_CHANNEL,
                                   subscriber_id_,
                                   oid.Binary())
            .ok())
        << "Register subscription for a valid channel type should succeed.";
    publisher_->Publish(GeneratePubMessage(oid));
  }
  ASSERT_EQ(batched_ids.size(), 0);

  // Check all of nodes are publishing objects properly.
  for (int i = 0; i < num_nodes; i++) {
    publisher_->ConnectToSubscriber(request_,
                                    reply.mutable_publisher_id(),
                                    reply.mutable_pub_messages(),
                                    send_reply_callback);
    const auto oid_test = oids[i];
    const auto published_oid = batched_ids[i];
    ASSERT_EQ(oid_test, published_oid);
  }
}

TEST_F(PublisherTest, TestMultiSubscribers) {
  absl::flat_hash_set<ObjectID> batched_ids;
  int reply_invoked = 0;
  reply = rpc::PubsubLongPollingReply();
  send_reply_callback =
      [this, &batched_ids, &reply_invoked](
          Status status, std::function<void()> success, std::function<void()> failure) {
        for (int i = 0; i < reply.pub_messages_size(); i++) {
          const auto &msg = reply.pub_messages(i);
          const auto oid = ObjectID::FromBinary(msg.key_id());
          batched_ids.emplace(oid);
        }
        reply.Clear();
        reply_invoked += 1;
      };

  std::vector<NodeID> subscribers;
  const auto oid = ObjectID::FromRandom();
  int num_nodes = 5;
  for (int i = 0; i < num_nodes; i++) {
    subscribers.push_back(NodeID::FromRandom());
  }

  // There will be one object per node.
  for (int i = 0; i < num_nodes; i++) {
    RAY_CHECK(
        publisher_
            ->RegisterSubscription(rpc::ChannelType::WORKER_OBJECT_LOCATIONS_CHANNEL,
                                   subscriber_id_,
                                   oid.Binary())
            .ok())
        << "Register subscription for a valid channel type should succeed.";
  }
  ASSERT_EQ(batched_ids.size(), 0);

  // Check all of nodes are publishing objects properly.
  for (int i = 0; i < num_nodes; i++) {
    publisher_->ConnectToSubscriber(request_,
                                    reply.mutable_publisher_id(),
                                    reply.mutable_pub_messages(),
                                    send_reply_callback);
  }
  publisher_->Publish(GeneratePubMessage(oid));
  ASSERT_EQ(batched_ids.size(), 1);
  ASSERT_EQ(reply_invoked, 5);
}

TEST_F(PublisherTest, TestBatch) {
  // Test if published objects are batched properly.
  std::vector<ObjectID> batched_ids;
  int64_t max_processed_sequence_id = 0;
  send_reply_callback = [this, &batched_ids, &max_processed_sequence_id](
                            Status status,
                            std::function<void()> success,
                            std::function<void()> failure) {
    for (int i = 0; i < reply.pub_messages_size(); i++) {
      const auto &msg = reply.pub_messages(i);
      const auto oid = ObjectID::FromBinary(msg.key_id());
      batched_ids.push_back(oid);
      max_processed_sequence_id = std::max(max_processed_sequence_id, msg.sequence_id());
    }
    reply = rpc::PubsubLongPollingReply();
  };

  std::vector<ObjectID> oids;
  int num_oids = 5;
  for (int i = 0; i < num_oids; i++) {
    const auto oid = ObjectID::FromRandom();
    oids.push_back(oid);
    RAY_CHECK(
        publisher_
            ->RegisterSubscription(rpc::ChannelType::WORKER_OBJECT_LOCATIONS_CHANNEL,
                                   subscriber_id_,
                                   oid.Binary())
            .ok())
        << "Register subscription for a valid channel type should succeed.";
    publisher_->Publish(GeneratePubMessage(oid));
  }
  ASSERT_EQ(batched_ids.size(), 0);

  // Now connection is initiated, and all oids are published.
  request_.set_max_processed_sequence_id(max_processed_sequence_id);
  publisher_->ConnectToSubscriber(request_,
                                  reply.mutable_publisher_id(),
                                  reply.mutable_pub_messages(),
                                  send_reply_callback);
  for (int i = 0; i < num_oids; i++) {
    const auto oid_test = oids[i];
    const auto published_oid = batched_ids[i];
    ASSERT_EQ(oid_test, published_oid);
  }

  batched_ids.clear();
  oids.clear();

  for (int i = 0; i < num_oids; i++) {
    const auto oid = ObjectID::FromRandom();
    oids.push_back(oid);
    RAY_CHECK(
        publisher_
            ->RegisterSubscription(rpc::ChannelType::WORKER_OBJECT_LOCATIONS_CHANNEL,
                                   subscriber_id_,
                                   oid.Binary())
            .ok())
        << "Register subscription for a valid channel type should succeed.";
    publisher_->Publish(GeneratePubMessage(oid));
  }
  request_.set_max_processed_sequence_id(max_processed_sequence_id);
  publisher_->ConnectToSubscriber(request_,
                                  reply.mutable_publisher_id(),
                                  reply.mutable_pub_messages(),
                                  send_reply_callback);
  ASSERT_EQ(num_oids, oids.size());
  ASSERT_EQ(num_oids, batched_ids.size());
  for (int i = 0; i < num_oids; i++) {
    const auto oid_test = oids[i];
    const auto published_oid = batched_ids[i];
    ASSERT_EQ(oid_test, published_oid);
  }
}

TEST_F(PublisherTest, TestNodeFailureWhenConnectionExisted) {
  bool long_polling_connection_replied = false;
  send_reply_callback =
      [&long_polling_connection_replied](
          Status status, std::function<void()> success, std::function<void()> failure) {
        long_polling_connection_replied = true;
      };

  const auto oid = ObjectID::FromRandom();
  publisher_->ConnectToSubscriber(request_,
                                  reply.mutable_publisher_id(),
                                  reply.mutable_pub_messages(),
                                  send_reply_callback);
  // This information should be cleaned up as the subscriber is dead.
  RAY_CHECK(publisher_
                ->RegisterSubscription(rpc::ChannelType::WORKER_OBJECT_LOCATIONS_CHANNEL,
                                       subscriber_id_,
                                       oid.Binary())
                .ok())
      << "Register subscription for a valid channel type should succeed.";
  // Timeout is reached. The connection should've been refreshed. Since the subscriber is
  // dead, no new connection is made.
  fake_clock_.AdvanceTime(absl::Milliseconds(subscriber_timeout_ms_));
  publisher_->CheckDeadSubscribers();
  ASSERT_EQ(long_polling_connection_replied, true);

  // More time has passed, and since there was no new long polling connection, this
  // subscriber is considered as dead.
  fake_clock_.AdvanceTime(absl::Milliseconds(subscriber_timeout_ms_));
  publisher_->CheckDeadSubscribers();

  // Connection should be replied (removed) when the subscriber is unregistered.
  publisher_->UnregisterSubscriber(subscriber_id_);
  ASSERT_TRUE(publisher_->CheckNoLeaks());

  // New subscriber is registsered for some reason. Since there's no new long polling
  // connection for the timeout, it should be removed.
  long_polling_connection_replied = false;
  RAY_CHECK(publisher_
                ->RegisterSubscription(rpc::ChannelType::WORKER_OBJECT_LOCATIONS_CHANNEL,
                                       subscriber_id_,
                                       oid.Binary())
                .ok())
      << "Register subscription for a valid channel type should succeed.";
  fake_clock_.AdvanceTime(absl::Milliseconds(subscriber_timeout_ms_));
  publisher_->CheckDeadSubscribers();
  publisher_->UnregisterSubscriber(subscriber_id_);
  ASSERT_TRUE(publisher_->CheckNoLeaks());
}

TEST_F(PublisherTest, TestNodeFailureWhenConnectionDoesntExist) {
  bool long_polling_connection_replied = false;
  send_reply_callback =
      [&long_polling_connection_replied](
          Status status, std::function<void()> success, std::function<void()> failure) {
        long_polling_connection_replied = true;
      };

  ///
  /// Test the case where there was a registration, but no connection.
  ///
  auto oid = ObjectID::FromRandom();
  RAY_CHECK(publisher_
                ->RegisterSubscription(rpc::ChannelType::WORKER_OBJECT_LOCATIONS_CHANNEL,
                                       subscriber_id_,
                                       oid.Binary())
                .ok())
      << "Register subscription for a valid channel type should succeed.";
  publisher_->Publish(GeneratePubMessage(oid));
  // There was no long polling connection yet.
  ASSERT_EQ(long_polling_connection_replied, false);

  // Connect should be removed eventually to avoid having a memory leak.
  publisher_->ConnectToSubscriber(request_,
                                  reply.mutable_publisher_id(),
                                  reply.mutable_pub_messages(),
                                  send_reply_callback);
  ASSERT_EQ(long_polling_connection_replied, true);
  // Nothing happens at first.
  publisher_->CheckDeadSubscribers();

  // After the timeout, the subscriber should be considered as dead because there was no
  // new long polling connection.
  fake_clock_.AdvanceTime(absl::Milliseconds(subscriber_timeout_ms_));
  publisher_->CheckDeadSubscribers();
  // Make sure the registration is cleaned up.
  ASSERT_TRUE(publisher_->CheckNoLeaks());

  /// Test the case where there's no connection coming at all when there was a
  /// registration.
  RAY_CHECK(publisher_
                ->RegisterSubscription(rpc::ChannelType::WORKER_OBJECT_LOCATIONS_CHANNEL,
                                       subscriber_id_,
                                       oid.Binary())
                .ok())
      << "Register subscription for a valid channel type should succeed.";
  publisher_->Publish(GeneratePubMessage(oid));

  // No new long polling connection was made until timeout.
  fake_clock_.AdvanceTime(absl::Milliseconds(subscriber_timeout_ms_));
  publisher_->CheckDeadSubscribers();
  // Make sure the registration is cleaned up.
  ASSERT_TRUE(publisher_->CheckNoLeaks());
}

// Unregistration an entry.
TEST_F(PublisherTest, TestUnregisterSubscription) {
  bool long_polling_connection_replied = false;
  send_reply_callback =
      [&long_polling_connection_replied](
          Status status, std::function<void()> success, std::function<void()> failure) {
        long_polling_connection_replied = true;
      };

  const auto oid = ObjectID::FromRandom();
  publisher_->ConnectToSubscriber(request_,
                                  reply.mutable_publisher_id(),
                                  reply.mutable_pub_messages(),
                                  send_reply_callback);
  RAY_CHECK(publisher_
                ->RegisterSubscription(rpc::ChannelType::WORKER_OBJECT_LOCATIONS_CHANNEL,
                                       subscriber_id_,
                                       oid.Binary())
                .ok())
      << "Register subscription for a valid channel type should succeed.";
  ASSERT_EQ(long_polling_connection_replied, false);

  // Connection should be replied (removed) when the subscriber is unregistered.
  publisher_->UnregisterSubscription(
      rpc::ChannelType::WORKER_OBJECT_LOCATIONS_CHANNEL, subscriber_id_, oid.Binary());
  ASSERT_EQ(long_polling_connection_replied, false);

  // Make sure when the entries don't exist, it doesn't delete anything.
  publisher_->UnregisterSubscription(rpc::ChannelType::WORKER_OBJECT_LOCATIONS_CHANNEL,
                                     subscriber_id_,
                                     ObjectID::FromRandom().Binary());
  publisher_->UnregisterSubscription(rpc::ChannelType::WORKER_OBJECT_LOCATIONS_CHANNEL,
                                     NodeID::FromRandom(),
                                     oid.Binary());
  publisher_->UnregisterSubscription(rpc::ChannelType::WORKER_OBJECT_LOCATIONS_CHANNEL,
                                     NodeID::FromRandom(),
                                     ObjectID::FromRandom().Binary());
  ASSERT_EQ(long_polling_connection_replied, false);
  // Metadata won't be removed until we unregsiter the subscriber.
  publisher_->UnregisterSubscriber(subscriber_id_);
  ASSERT_TRUE(publisher_->CheckNoLeaks());
}

// Unregistration a subscriber.
TEST_F(PublisherTest, TestUnregisterSubscriber) {
  bool long_polling_connection_replied = false;
  send_reply_callback =
      [&long_polling_connection_replied](
          Status status, std::function<void()> success, std::function<void()> failure) {
        long_polling_connection_replied = true;
      };

  // Test basic.
  const auto oid = ObjectID::FromRandom();
  publisher_->ConnectToSubscriber(request_,
                                  reply.mutable_publisher_id(),
                                  reply.mutable_pub_messages(),
                                  send_reply_callback);
  RAY_CHECK(publisher_
                ->RegisterSubscription(rpc::ChannelType::WORKER_OBJECT_LOCATIONS_CHANNEL,
                                       subscriber_id_,
                                       oid.Binary())
                .ok())
      << "Register subscription for a valid channel type should succeed.";
  ASSERT_EQ(long_polling_connection_replied, false);
  publisher_->UnregisterSubscriber(subscriber_id_);
  // Make sure the long polling request is replied to avoid memory leak.
  ASSERT_EQ(long_polling_connection_replied, true);

  // Test when registration wasn't done.
  long_polling_connection_replied = false;
  publisher_->ConnectToSubscriber(request_,
                                  reply.mutable_publisher_id(),
                                  reply.mutable_pub_messages(),
                                  send_reply_callback);
  publisher_->UnregisterSubscriber(subscriber_id_);
  ASSERT_EQ(long_polling_connection_replied, true);

  // Test when connect wasn't done.
  long_polling_connection_replied = false;
  RAY_CHECK(publisher_
                ->RegisterSubscription(rpc::ChannelType::WORKER_OBJECT_LOCATIONS_CHANNEL,
                                       subscriber_id_,
                                       oid.Binary())
                .ok())
      << "Register subscription for a valid channel type should succeed.";
  publisher_->UnregisterSubscriber(subscriber_id_);
  ASSERT_EQ(long_polling_connection_replied, false);
  ASSERT_TRUE(publisher_->CheckNoLeaks());
}

// Test if registration / unregistration is idempotent.
TEST_F(PublisherTest, TestRegistrationIdempotency) {
  const auto oid = ObjectID::FromRandom();

  // Double register and assert publish
  RAY_CHECK(publisher_
                ->RegisterSubscription(rpc::ChannelType::WORKER_OBJECT_LOCATIONS_CHANNEL,
                                       subscriber_id_,
                                       oid.Binary())
                .ok())
      << "Register subscription for a valid channel type should succeed.";
  RAY_CHECK(publisher_
                ->RegisterSubscription(rpc::ChannelType::WORKER_OBJECT_LOCATIONS_CHANNEL,
                                       subscriber_id_,
                                       oid.Binary())
                .ok())
      << "Register subscription for a valid channel type should succeed.";
  publisher_->ConnectToSubscriber(
      request_,
      reply.mutable_publisher_id(),
      reply.mutable_pub_messages(),
      [](Status, std::function<void()>, std::function<void()>) {});
  publisher_->Publish(GeneratePubMessage(oid));
  ASSERT_EQ(reply.publisher_id(), kDefaultPublisherId.Binary());
  ASSERT_EQ(reply.pub_messages().size(), 1);
  reply = rpc::PubsubLongPollingReply();

  // Reconnect, unregister and assert no publish messages
  request_.set_max_processed_sequence_id(1);
  publisher_->ConnectToSubscriber(
      request_,
      reply.mutable_publisher_id(),
      reply.mutable_pub_messages(),
      [](Status, std::function<void()>, std::function<void()>) {});
  publisher_->UnregisterSubscription(
      rpc::ChannelType::WORKER_OBJECT_LOCATIONS_CHANNEL, subscriber_id_, oid.Binary());
  publisher_->UnregisterSubscription(
      rpc::ChannelType::WORKER_OBJECT_LOCATIONS_CHANNEL, subscriber_id_, oid.Binary());
  auto pub_message = GeneratePubMessage(oid);
  publisher_->Publish(pub_message);
  ASSERT_TRUE(reply.pub_messages().empty());
  ASSERT_TRUE(publisher_->CheckNoLeaks());

  // Register and connect. Then unregister a couple times and make sure there's no
  // publish.
  RAY_CHECK(publisher_
                ->RegisterSubscription(rpc::ChannelType::WORKER_OBJECT_LOCATIONS_CHANNEL,
                                       subscriber_id_,
                                       oid.Binary())
                .ok())
      << "Register subscription for a valid channel type should succeed.";
  publisher_->ConnectToSubscriber(
      request_,
      reply.mutable_publisher_id(),
      reply.mutable_pub_messages(),
      [](Status, std::function<void()>, std::function<void()>) {});
  ASSERT_FALSE(publisher_->CheckNoLeaks());
  publisher_->UnregisterSubscriber(subscriber_id_);
  publisher_->UnregisterSubscriber(subscriber_id_);
  publisher_->UnregisterSubscription(
      rpc::ChannelType::WORKER_OBJECT_LOCATIONS_CHANNEL, subscriber_id_, oid.Binary());
  ASSERT_TRUE(publisher_->CheckNoLeaks());
  publisher_->Publish(GeneratePubMessage(oid));
  ASSERT_TRUE(reply.pub_messages().empty());
}

TEST_F(PublisherTest, TestSubscriberLostAPublish) {
  const auto oid = ObjectID::FromRandom();
  send_reply_callback = [](Status, std::function<void()>, std::function<void()>) {};

  // Subscriber registers and connects and publisher publishes.
  RAY_CHECK(publisher_
                ->RegisterSubscription(rpc::ChannelType::WORKER_OBJECT_LOCATIONS_CHANNEL,
                                       subscriber_id_,
                                       oid.Binary())
                .ok())
      << "Register subscription for a valid channel type should succeed.";
  publisher_->ConnectToSubscriber(request_,
                                  reply.mutable_publisher_id(),
                                  reply.mutable_pub_messages(),
                                  send_reply_callback);
  publisher_->Publish(GeneratePubMessage(oid));
  ASSERT_EQ(reply.pub_messages().size(), 1);
  reply = rpc::PubsubLongPollingReply();

  // The publisher publishes while there's no active request, then the Subscriber retries
  // the LongPollingRequest with the same max_sequence_id since it lost the reply from the
  // publisher. Object-location messages are snapshots, so only the latest is resent.
  publisher_->Publish(GeneratePubMessage(oid));
  publisher_->ConnectToSubscriber(request_,
                                  reply.mutable_publisher_id(),
                                  reply.mutable_pub_messages(),
                                  send_reply_callback);
  ASSERT_EQ(reply.pub_messages().size(), 1);
  auto max_processed = reply.pub_messages(0).sequence_id();
  reply = rpc::PubsubLongPollingReply();

  // Subscriber got the reply this time, sends another request with a higher
  // max_sequence_id, and then the publisher publishes.
  request_.set_max_processed_sequence_id(max_processed);
  publisher_->ConnectToSubscriber(request_,
                                  reply.mutable_publisher_id(),
                                  reply.mutable_pub_messages(),
                                  send_reply_callback);
  publisher_->Publish(GeneratePubMessage(oid));
  ASSERT_EQ(reply.pub_messages().size(), 1);
}

TEST_F(PublisherTest, TestPublishFailure) {
  ///
  /// Test the publish failure API.
  ///
  std::vector<ObjectID> failed_ids;
  send_reply_callback = [this, &failed_ids](Status status,
                                            std::function<void()> success,
                                            std::function<void()> failure) {
    for (int i = 0; i < reply.pub_messages_size(); i++) {
      const auto &msg = reply.pub_messages(i);
      RAY_LOG(ERROR) << "ha";
      if (msg.has_failure_message()) {
        const auto oid = ObjectID::FromBinary(msg.key_id());
        failed_ids.push_back(oid);
      }
    }
    reply = rpc::PubsubLongPollingReply();
  };

  const auto oid = ObjectID::FromRandom();

  publisher_->ConnectToSubscriber(request_,
                                  reply.mutable_publisher_id(),
                                  reply.mutable_pub_messages(),
                                  send_reply_callback);
  RAY_CHECK(publisher_
                ->RegisterSubscription(rpc::ChannelType::WORKER_OBJECT_LOCATIONS_CHANNEL,
                                       subscriber_id_,
                                       oid.Binary())
                .ok())
      << "Register subscription for a valid channel type should succeed.";
  publisher_->PublishFailure(rpc::ChannelType::WORKER_OBJECT_LOCATIONS_CHANNEL,
                             oid.Binary());
  ASSERT_EQ(failed_ids[0], oid);
}

class ScopedEntityBufferMaxBytes {
 public:
  ScopedEntityBufferMaxBytes(
      int64_t max_buffer_bytes,
      int64_t max_message_size_bytes = RayConfig::instance().max_grpc_message_size())
      : prev_max_buffer_bytes_(RayConfig::instance().publisher_entity_buffer_max_bytes()),
        prev_max_message_size_bytes_(RayConfig::instance().max_grpc_message_size()) {
    RayConfig::instance().publisher_entity_buffer_max_bytes() = max_buffer_bytes;
    RayConfig::instance().max_grpc_message_size() = max_message_size_bytes;
  }

  ~ScopedEntityBufferMaxBytes() {
    RayConfig::instance().publisher_entity_buffer_max_bytes() = prev_max_buffer_bytes_;
    RayConfig::instance().max_grpc_message_size() = prev_max_message_size_bytes_;
  }

 private:
  const int64_t prev_max_buffer_bytes_;
  const int64_t prev_max_message_size_bytes_;
};

TEST_F(PublisherTest, TestObjectLocationsChannelKeepsOnlyLatestSnapshot) {
  SubscriptionIndex subscription_index(rpc::ChannelType::WORKER_OBJECT_LOCATIONS_CHANNEL);
  auto oid_a = ObjectID::FromRandom();
  auto oid_b = ObjectID::FromRandom();
  auto *subscriber = CreateSubscriber();
  subscription_index.AddEntry(oid_a.Binary(), subscriber);
  subscription_index.AddEntry(oid_b.Binary(), subscriber);

  auto publish = [&](const ObjectID &oid, int object_size) {
    rpc::PubMessage pub_message;
    pub_message.set_key_id(oid.Binary());
    pub_message.set_channel_type(rpc::ChannelType::WORKER_OBJECT_LOCATIONS_CHANNEL);
    pub_message.set_sequence_id(GetNextSequenceId());
    pub_message.mutable_worker_object_locations_message()->set_object_size(object_size);
    ASSERT_TRUE(subscription_index.Publish(std::make_shared<rpc::PubMessage>(pub_message),
                                           /*msg_size=*/pub_message.ByteSizeLong()));
  };

  // Many updates to one entity must not grow the mailbox.
  for (int i = 0; i < 100; i++) {
    publish(oid_a, /*object_size=*/i + 1);
    EXPECT_EQ(subscriber->MailboxSize(), 1);
  }

  // Coalescing A must not drop an in-flight snapshot for B.
  publish(oid_b, /*object_size=*/7);
  publish(oid_a, /*object_size=*/42);
  EXPECT_EQ(subscriber->MailboxSize(), 2);

  auto reply = FlushSubscriber(subscriber);
  ASSERT_EQ(reply->pub_messages().size(), 2);
  EXPECT_EQ(reply->pub_messages(0).key_id(), oid_b.Binary());
  EXPECT_EQ(reply->pub_messages(0).worker_object_locations_message().object_size(), 7);
  EXPECT_EQ(reply->pub_messages(1).key_id(), oid_a.Binary());
  EXPECT_EQ(reply->pub_messages(1).worker_object_locations_message().object_size(), 42);
}

TEST_F(PublisherTest, TestObjectLocationsSnapshotReplaceSurvivesAckOfOlderSeq) {
  SubscriptionIndex subscription_index(rpc::ChannelType::WORKER_OBJECT_LOCATIONS_CHANNEL);
  ObjectID oid = ObjectID::FromRandom();
  SubscriberState *subscriber = CreateSubscriber();
  subscription_index.AddEntry(oid.Binary(), subscriber);

  auto publish = [this, &subscription_index, &oid](int object_size) {
    rpc::PubMessage pub_message;
    pub_message.set_key_id(oid.Binary());
    pub_message.set_channel_type(rpc::ChannelType::WORKER_OBJECT_LOCATIONS_CHANNEL);
    pub_message.set_sequence_id(GetNextSequenceId());
    pub_message.mutable_worker_object_locations_message()->set_object_size(object_size);
    EXPECT_TRUE(subscription_index.Publish(std::make_shared<rpc::PubMessage>(pub_message),
                                           /*msg_size=*/pub_message.ByteSizeLong()));
    return pub_message.sequence_id();
  };

  const int64_t seq_v1 = publish(/*object_size=*/1);
  EXPECT_EQ(subscriber->MailboxSize(), 1);

  // Deliver v1. The copy is sent, but the mailbox keeps it until ACK.
  std::shared_ptr<rpc::PubsubLongPollingReply> reply_v1 = FlushSubscriber(subscriber);
  ASSERT_EQ(reply_v1->pub_messages().size(), 1);
  EXPECT_EQ(reply_v1->pub_messages(0).sequence_id(), seq_v1);
  EXPECT_EQ(reply_v1->pub_messages(0).worker_object_locations_message().object_size(), 1);
  EXPECT_EQ(subscriber->MailboxSize(), 1);

  // Replace with a newer snapshot before the subscriber ACKs v1.
  const int64_t seq_v2 = publish(/*object_size=*/2);
  EXPECT_GT(seq_v2, seq_v1);
  EXPECT_EQ(subscriber->MailboxSize(), 1);

  // ACK only through v1. v2 has a higher sequence_id, so it must remain and be
  // delivered on this poll.
  std::shared_ptr<rpc::PubsubLongPollingReply> reply_v2 =
      FlushSubscriber(subscriber, /*max_processed_sequence_id=*/seq_v1);
  ASSERT_EQ(reply_v2->pub_messages().size(), 1);
  EXPECT_EQ(reply_v2->pub_messages(0).sequence_id(), seq_v2);
  EXPECT_EQ(reply_v2->pub_messages(0).worker_object_locations_message().object_size(), 2);
  EXPECT_FALSE(subscriber->CheckNoLeaks());

  // ACK v2; mailbox and snapshot index should both be empty.
  FlushSubscriber(subscriber, /*max_processed_sequence_id=*/seq_v2);
  EXPECT_TRUE(subscriber->CheckNoLeaks());
  EXPECT_EQ(subscriber->MailboxSize(), 0);
}

TEST_F(PublisherTest, TestObjectLocationsFailureMessageNotCoalesced) {
  SubscriptionIndex subscription_index(rpc::ChannelType::WORKER_OBJECT_LOCATIONS_CHANNEL);
  ObjectID oid = ObjectID::FromRandom();
  SubscriberState *subscriber = CreateSubscriber();
  subscription_index.AddEntry(oid.Binary(), subscriber);

  auto publish_location = [this, &subscription_index, &oid](int object_size) {
    rpc::PubMessage pub_message;
    pub_message.set_key_id(oid.Binary());
    pub_message.set_channel_type(rpc::ChannelType::WORKER_OBJECT_LOCATIONS_CHANNEL);
    pub_message.set_sequence_id(GetNextSequenceId());
    pub_message.mutable_worker_object_locations_message()->set_object_size(object_size);
    EXPECT_TRUE(subscription_index.Publish(std::make_shared<rpc::PubMessage>(pub_message),
                                           /*msg_size=*/pub_message.ByteSizeLong()));
    return pub_message.sequence_id();
  };
  auto publish_failure = [this, &subscription_index, &oid]() {
    rpc::PubMessage pub_message;
    pub_message.set_key_id(oid.Binary());
    pub_message.set_channel_type(rpc::ChannelType::WORKER_OBJECT_LOCATIONS_CHANNEL);
    pub_message.set_sequence_id(GetNextSequenceId());
    pub_message.mutable_failure_message();
    EXPECT_TRUE(subscription_index.Publish(std::make_shared<rpc::PubMessage>(pub_message),
                                           /*msg_size=*/pub_message.ByteSizeLong()));
    return pub_message.sequence_id();
  };

  // Many location updates collapse to one; failure must still be appended.
  for (int i = 0; i < 50; i++) {
    publish_location(/*object_size=*/i + 1);
  }
  EXPECT_EQ(subscriber->MailboxSize(), 1);
  const int64_t failure_seq = publish_failure();
  EXPECT_EQ(subscriber->MailboxSize(), 2);

  std::shared_ptr<rpc::PubsubLongPollingReply> reply = FlushSubscriber(subscriber);
  ASSERT_EQ(reply->pub_messages().size(), 2);
  EXPECT_TRUE(reply->pub_messages(0).has_worker_object_locations_message());
  EXPECT_EQ(reply->pub_messages(0).worker_object_locations_message().object_size(), 50);
  EXPECT_TRUE(reply->pub_messages(1).has_failure_message());
  EXPECT_EQ(reply->pub_messages(1).sequence_id(), failure_seq);

  // A later location snapshot must not drop an earlier in-flight failure.
  const int64_t seq_after_failure = publish_location(/*object_size=*/99);
  EXPECT_EQ(subscriber->MailboxSize(), 2);
  reply = FlushSubscriber(subscriber, /*max_processed_sequence_id=*/failure_seq);
  ASSERT_EQ(reply->pub_messages().size(), 1);
  EXPECT_TRUE(reply->pub_messages(0).has_worker_object_locations_message());
  EXPECT_EQ(reply->pub_messages(0).sequence_id(), seq_after_failure);
  EXPECT_EQ(reply->pub_messages(0).worker_object_locations_message().object_size(), 99);

  FlushSubscriber(subscriber, /*max_processed_sequence_id=*/seq_after_failure);
  EXPECT_TRUE(subscriber->CheckNoLeaks());
}

TEST_F(PublisherTest, TestMaxBufferSizePerEntity) {
  ScopedEntityBufferMaxBytes max_bytes(10000);

  SubscriptionIndex subscription_index(rpc::ChannelType::RAY_ERROR_INFO_CHANNEL);
  auto job_id = JobID::FromInt(1234);
  auto *subscriber = CreateSubscriber();
  // Subscribe to job_id.
  subscription_index.AddEntry(job_id.Binary(), subscriber);

  rpc::PubMessage pub_message;
  pub_message.set_key_id(job_id.Binary());
  pub_message.set_channel_type(rpc::ChannelType::RAY_ERROR_INFO_CHANNEL);
  pub_message.set_sequence_id(GetNextSequenceId());
  pub_message.mutable_error_info_message()->set_error_message(std::string(4000, 'a'));

  // Buffer is available.
  EXPECT_TRUE(subscription_index.Publish(std::make_shared<rpc::PubMessage>(pub_message),
                                         /*msg_size=*/pub_message.ByteSizeLong()));

  // Buffer is still available.
  pub_message.mutable_error_info_message()->set_error_message(std::string(4000, 'b'));
  pub_message.set_sequence_id(GetNextSequenceId());
  EXPECT_TRUE(subscription_index.Publish(std::make_shared<rpc::PubMessage>(pub_message),
                                         /*msg_size=*/pub_message.ByteSizeLong()));

  // Buffer is full.
  pub_message.mutable_error_info_message()->set_error_message(std::string(4000, 'c'));
  pub_message.set_sequence_id(GetNextSequenceId());
  EXPECT_TRUE(subscription_index.Publish(std::make_shared<rpc::PubMessage>(pub_message),
                                         /*msg_size=*/pub_message.ByteSizeLong()));

  // Subscriber receives the last two messages. 1st message is dropped.
  auto reply = FlushSubscriber(subscriber);
  ASSERT_EQ(reply->pub_messages().size(), 2);
  EXPECT_EQ(reply->pub_messages(0).error_info_message().error_message(),
            std::string(4000, 'b'));
  EXPECT_EQ(reply->pub_messages(1).error_info_message().error_message(),
            std::string(4000, 'c'));

  // A message larger than the buffer limit can still be published.
  pub_message.mutable_error_info_message()->set_error_message(std::string(14000, 'd'));
  pub_message.set_sequence_id(GetNextSequenceId());
  EXPECT_TRUE(subscription_index.Publish(std::make_shared<rpc::PubMessage>(pub_message),
                                         /*msg_size=*/pub_message.ByteSizeLong()));
  reply = FlushSubscriber(subscriber);
  ASSERT_EQ(reply->pub_messages().size(), 1);
  EXPECT_EQ(reply->pub_messages(0).error_info_message().error_message(),
            std::string(14000, 'd'));
}

TEST_F(PublisherTest, TestMaxBufferSizeAllEntities) {
  int64_t max_bytes = 10000;
  ScopedEntityBufferMaxBytes max_bytes_config(/*max_buffer_bytes=*/max_bytes,
                                              /*max_message_size_bytes=*/max_bytes);

  SubscriptionIndex subscription_index(rpc::ChannelType::RAY_ERROR_INFO_CHANNEL);
  auto *subscriber = CreateSubscriber();
  // Subscribe to all entities.
  subscription_index.AddEntry("", subscriber);

  rpc::PubMessage pub_message;
  {
    pub_message.set_key_id("aaa");
    pub_message.set_channel_type(rpc::ChannelType::RAY_ERROR_INFO_CHANNEL);
    pub_message.mutable_error_info_message()->set_error_message(std::string(4000, 'a'));
    pub_message.set_sequence_id(GetNextSequenceId());

    // Buffer is available.
    EXPECT_TRUE(subscription_index.Publish(std::make_shared<rpc::PubMessage>(pub_message),
                                           /*msg_size=*/pub_message.ByteSizeLong()));
  }

  // Buffer is still available.
  {
    pub_message.set_key_id("bbb");
    pub_message.mutable_error_info_message()->set_error_message(std::string(4000, 'b'));
    pub_message.set_sequence_id(GetNextSequenceId());
    EXPECT_TRUE(subscription_index.Publish(std::make_shared<rpc::PubMessage>(pub_message),
                                           /*msg_size=*/pub_message.ByteSizeLong()));
  }

  // Buffer is full.
  {
    pub_message.set_key_id("ccc");
    pub_message.mutable_error_info_message()->set_error_message(std::string(4000, 'c'));
    pub_message.set_sequence_id(GetNextSequenceId());
    EXPECT_TRUE(subscription_index.Publish(std::make_shared<rpc::PubMessage>(pub_message),
                                           /*msg_size=*/pub_message.ByteSizeLong()));
  }

  {
    // Publishing individual messages that are too large fails.
    pub_message.set_key_id("ddd");
    pub_message.set_channel_type(rpc::ChannelType::RAY_ERROR_INFO_CHANNEL);
    pub_message.mutable_error_info_message()->set_error_message(std::string(12000, 'a'));
    pub_message.set_sequence_id(GetNextSequenceId());

    EXPECT_FALSE(
        subscription_index.Publish(std::make_shared<rpc::PubMessage>(pub_message),
                                   /*msg_size=*/pub_message.ByteSizeLong()));
  }

  auto reply = FlushSubscriber(subscriber);
  ASSERT_EQ(reply->pub_messages().size(), 2);
  EXPECT_EQ(reply->pub_messages(0).error_info_message().error_message(),
            std::string(4000, 'b'));
  EXPECT_EQ(reply->pub_messages(1).error_info_message().error_message(),
            std::string(4000, 'c'));

  reply = FlushSubscriber(subscriber, reply->pub_messages(1).sequence_id());
  ASSERT_EQ(reply->pub_messages().size(), 0);
}

TEST_F(PublisherTest, TestRegisterSubscriptionInvalidChannelTypeReturnsInvalidArgument) {
  // Test that RegisterSubscription returns InvalidArgument for an invalid channel type.
  const auto subscriber_id = UniqueID::FromRandom();
  const auto oid = ObjectID::FromRandom();

  // Use a channel type that was not registered with the publisher.
  // The publisher was created with only:
  // - WORKER_REF_REMOVED_CHANNEL
  // - WORKER_OBJECT_LOCATIONS_CHANNEL
  // - RAY_ERROR_INFO_CHANNEL
  StatusSet<StatusT::InvalidArgument> result = publisher_->RegisterSubscription(
      rpc::ChannelType::GCS_ACTOR_CHANNEL, subscriber_id, oid.Binary());

  ASSERT_TRUE(std::holds_alternative<StatusT::InvalidArgument>(result.error()))
      << "Expected InvalidArgument error, got "
      << std::get<StatusT::InvalidArgument>(result.error()).ToString();
}

TEST_F(PublisherTest, TestMaxMessageSize) {
  int64_t max_message_size_bytes = 1000;
  int64_t max_messages = 2;
  ScopedEntityBufferMaxBytes max_bytes_config(
      /*max_buffer_bytes=*/max_message_size_bytes * max_messages,
      /*max_message_size_bytes=*/max_message_size_bytes);

  SubscriptionIndex subscription_index(rpc::ChannelType::RAY_ERROR_INFO_CHANNEL);
  auto *subscriber = CreateSubscriber();
  // Subscribe to all entities.
  subscription_index.AddEntry("", subscriber);

  {
    // Publishing individual messages that are too large fails.
    rpc::PubMessage pub_message;
    pub_message.set_key_id("a");
    pub_message.set_channel_type(rpc::ChannelType::RAY_ERROR_INFO_CHANNEL);
    pub_message.mutable_error_info_message()->set_error_message(
        std::string(max_message_size_bytes * 2, 'x'));
    pub_message.set_sequence_id(GetNextSequenceId());

    EXPECT_FALSE(
        subscription_index.Publish(std::make_shared<rpc::PubMessage>(pub_message),
                                   /*msg_size=*/pub_message.ByteSizeLong()));
  }

  // Fill the buffer and force one message to get evicted.
  for (int64_t i = 0; i < 2 * (max_messages + 1); i++) {
    rpc::PubMessage pub_message;
    pub_message.set_key_id(std::to_string(i));
    pub_message.set_channel_type(rpc::ChannelType::RAY_ERROR_INFO_CHANNEL);
    pub_message.mutable_error_info_message()->set_error_message(
        std::string(max_message_size_bytes / 3, 'x'));
    pub_message.set_sequence_id(GetNextSequenceId());
    ASSERT_TRUE(subscription_index.Publish(std::make_shared<rpc::PubMessage>(pub_message),
                                           /*msg_size=*/pub_message.ByteSizeLong()));
  }

  // We should only get back two notifications at a time because of the max
  // message size limit.
  int64_t max_processed_seq_id = 0;
  for (int64_t i = 0; i < max_messages; i++) {
    auto reply = FlushSubscriber(subscriber, max_processed_seq_id);
    ASSERT_EQ(reply->pub_messages().size(), 2);
    // Messages are offset by 1 because the first message should have gotten
    // dropped to avoid exceeding the buffer size.
    ASSERT_EQ(reply->pub_messages(0).key_id(), std::to_string(2 * i + 1));
    ASSERT_EQ(reply->pub_messages(1).key_id(), std::to_string(2 * i + 2));
    max_processed_seq_id = reply->pub_messages(1).sequence_id();
  }

  {
    auto reply = FlushSubscriber(subscriber, max_processed_seq_id);
    ASSERT_EQ(reply->pub_messages().size(), 1);
    max_processed_seq_id = reply->pub_messages(0).sequence_id();
  }

  {
    auto reply = FlushSubscriber(subscriber, max_processed_seq_id);
    ASSERT_EQ(reply->pub_messages().size(), 0);
  }
}

}  // namespace pubsub

}  // namespace ray
