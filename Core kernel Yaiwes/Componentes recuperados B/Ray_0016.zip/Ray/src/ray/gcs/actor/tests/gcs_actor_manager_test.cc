// Copyright 2017 The Ray Authors.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//  http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#include "ray/gcs/actor/gcs_actor_manager.h"

#include <gtest/gtest.h>

#include <list>
#include <memory>
#include <string>
#include <utility>
#include <vector>

#include "mock/ray/gcs/gcs_kv_manager.h"
#include "mock/ray/gcs/gcs_node_manager.h"
#include "ray/asio/instrumented_io_context.h"
#include "ray/asio/periodical_runner.h"
#include "ray/common/runtime_env_manager.h"
#include "ray/common/test_utils.h"
#include "ray/core_worker_rpc_client/fake_core_worker_client.h"
#include "ray/gcs/actor/gcs_actor.h"
#include "ray/gcs/actor/gcs_actor_scheduler.h"
#include "ray/gcs/gcs_function_manager.h"
#include "ray/gcs/gcs_init_data.h"
#include "ray/gcs/store_client/in_memory_store_client.h"
#include "ray/observability/fake_metric.h"
#include "ray/pubsub/fake_publisher.h"
#include "ray/pubsub/gcs_publisher.h"
#include "ray/pubsub/publisher.h"
#include "ray/raylet_rpc_client/fake_raylet_client.h"
#include "ray/util/clock.h"

namespace ray {
namespace gcs {

using ::testing::_;
using ::testing::Return;

class MockActorScheduler : public gcs::GcsActorSchedulerInterface {
 public:
  MockActorScheduler() {}

  void Schedule(std::shared_ptr<gcs::GcsActor> actor) { actors.push_back(actor); }
  void Reschedule(std::shared_ptr<gcs::GcsActor> actor) {}
  void ReleaseUnusedActorWorkers(
      const absl::flat_hash_map<NodeID, std::vector<WorkerID>> &node_to_workers) {}
  void OnActorDestruction(std::shared_ptr<gcs::GcsActor> actor) {
    const auto &actor_id = actor->GetActorID();
    auto pending_it =
        std::find_if(actors.begin(),
                     actors.end(),
                     [actor_id](const std::shared_ptr<gcs::GcsActor> &current_actor) {
                       return current_actor->GetActorID() == actor_id;
                     });
    if (pending_it != actors.end()) {
      actors.erase(pending_it);
    }
  }

  MOCK_CONST_METHOD0(DebugString, std::string());
  MOCK_METHOD1(CancelOnNode, std::vector<ActorID>(const NodeID &node_id));
  MOCK_METHOD2(CancelOnWorker, ActorID(const NodeID &node_id, const WorkerID &worker_id));
  MOCK_METHOD3(CancelOnLeasing,
               void(const NodeID &node_id,
                    const ActorID &actor_id,
                    const LeaseID &lease_id));

  std::vector<std::shared_ptr<gcs::GcsActor>> actors;
};

class MockWorkerClient : public rpc::FakeCoreWorkerClient {
 public:
  explicit MockWorkerClient(instrumented_io_context &io_service)
      : io_service_(io_service) {}

  void WaitForActorRefDeleted(
      rpc::WaitForActorRefDeletedRequest &&request,
      const rpc::ClientCallback<rpc::WaitForActorRefDeletedReply> &callback) override {
    callbacks_.push_back(callback);
  }

  void KillActor(const rpc::KillActorRequest &request,
                 const rpc::ClientCallback<rpc::KillActorReply> &callback) override {
    killed_actors_.push_back(ActorID::FromBinary(request.intended_actor_id()));
  }

  bool Reply(Status status = Status::OK()) {
    if (callbacks_.size() == 0) {
      return false;
    }
    auto callback = callbacks_.front();
    auto reply = rpc::WaitForActorRefDeletedReply();
    callback(status, std::move(reply));
    callbacks_.pop_front();
    return true;
  }

  std::list<rpc::ClientCallback<rpc::WaitForActorRefDeletedReply>> callbacks_;
  std::vector<ActorID> killed_actors_;
  instrumented_io_context &io_service_;
};

class TestGcsInitData : public GcsInitData {
 public:
  using GcsInitData::GcsInitData;

  void SetJobTableData(absl::flat_hash_map<JobID, rpc::JobTableData> job_data) {
    job_table_data_ = std::move(job_data);
  }

  void SetNodeTableData(absl::flat_hash_map<NodeID, rpc::GcsNodeInfo> node_data) {
    node_table_data_ = std::move(node_data);
  }

  void SetActorTableData(absl::flat_hash_map<ActorID, rpc::ActorTableData> actor_data) {
    actor_table_data_ = std::move(actor_data);
  }

  void SetActorTaskSpecTableData(
      absl::flat_hash_map<ActorID, rpc::TaskSpec> actor_task_spec_data) {
    actor_task_spec_table_data_ = std::move(actor_task_spec_data);
  }
};

class GcsActorManagerTest : public ::testing::Test {
 public:
  GcsActorManagerTest() : periodical_runner_(PeriodicalRunner::Create(io_service_)) {
    RayConfig::instance().initialize(
        R"(
{
  "maximum_gcs_destroyed_actor_cached_count": 10
}
  )");
    worker_client_ = std::make_shared<MockWorkerClient>(io_service_);
    raylet_client_ = std::make_shared<rpc::FakeRayletClient>();
    runtime_env_mgr_ =
        std::make_unique<ray::RuntimeEnvManager>([](auto, auto f) { f(true); });
    std::vector<rpc::ChannelType> channels = {rpc::ChannelType::GCS_ACTOR_CHANNEL};
    auto publisher = std::make_unique<ray::pubsub::Publisher>(
        std::vector<rpc::ChannelType>{
            rpc::ChannelType::GCS_ACTOR_CHANNEL,
        },
        /*periodical_runner=*/*periodical_runner_,
        /*clock=*/clock_,
        /*subscriber_timeout_ms=*/absl::ToInt64Milliseconds(absl::Seconds(30)),
        /*batch_size=*/100);

    gcs_publisher_ = std::make_unique<pubsub::GcsPublisher>(std::move(publisher));
    observability_publisher_ = std::make_unique<pubsub::ObservabilityPublisher>(
        std::make_unique<pubsub::FakePublisher>());
    store_client_ = std::make_shared<gcs::InMemoryStoreClient>();
    gcs_table_storage_ =
        std::make_unique<gcs::GcsTableStorage>(std::make_unique<InMemoryStoreClient>());
    kv_ = std::make_unique<gcs::MockInternalKVInterface>();
    function_manager_ = std::make_unique<gcs::GCSFunctionManager>(*kv_, io_service_);
    auto scheduler = std::make_unique<MockActorScheduler>();
    mock_actor_scheduler_ = scheduler.get();
    raylet_client_pool_ = std::make_unique<rpc::RayletClientPool>(
        [this](const rpc::Address &address) { return raylet_client_; });
    worker_client_pool_ = std::make_unique<rpc::CoreWorkerClientPool>(
        [this](const rpc::Address &address) { return worker_client_; });
    fake_ray_event_recorder_ = std::make_unique<observability::FakeRayEventRecorder>();
    gcs_actor_manager_ = std::make_unique<gcs::GcsActorManager>(
        std::move(scheduler),
        gcs_table_storage_.get(),
        io_service_,
        gcs_publisher_.get(),
        *runtime_env_mgr_,
        *function_manager_,
        [](const ActorID &actor_id) {},
        *raylet_client_pool_,
        *worker_client_pool_,
        *fake_ray_event_recorder_,
        "test_session_name",
        fake_actor_by_state_gauge_,
        fake_gcs_actor_by_state_gauge_,
        observability_publisher_.get(),
        clock_);

    for (int i = 1; i <= 10; i++) {
      auto job_id = JobID::FromInt(i);
      job_namespace_table_[job_id] = "";
    }
  }

  ~GcsActorManagerTest() { io_service_.stop(); }

  rpc::Address RandomAddress() const {
    rpc::Address address;
    auto node_id = NodeID::FromRandom();
    auto worker_id = WorkerID::FromRandom();
    address.set_node_id(node_id.Binary());
    address.set_worker_id(worker_id.Binary());
    return address;
  }

  std::shared_ptr<gcs::GcsActor> RegisterActor(
      const JobID &job_id,
      int max_restarts = 0,
      bool detached = false,
      const std::string &name = "",
      const std::string &ray_namespace = "test") {
    // The tests queue up operations and sometimes don't execute them through the
    // io_context themselves. This is a hack, and future tests shouldn't use this
    // RegisterActor function.
    drain_io_context();
    auto request =
        GenRegisterActorRequest(job_id, max_restarts, detached, name, ray_namespace);
    auto status = gcs_actor_manager_->RegisterActor(request, [](const Status &) {});
    io_service_.run_one();
    io_service_.run_one();
    auto actor_id =
        ActorID::FromBinary(request.task_spec().actor_creation_task_spec().actor_id());
    return gcs_actor_manager_->registered_actors_.contains(actor_id)
               ? gcs_actor_manager_->registered_actors_[actor_id]
               : nullptr;
  }

  void OnNodeDead(const NodeID &node_id) {
    auto node_info = std::make_shared<rpc::GcsNodeInfo>();
    node_info->set_node_id(node_id.Binary());
    gcs_actor_manager_->OnNodeDead(node_info, "127.0.0.1");
  }

  void ReportActorOutOfScope(const ActorID &actor_id,
                             size_t num_restarts_due_to_lineage_reconstrcution) {
    rpc::ReportActorOutOfScopeRequest request;
    request.set_actor_id(actor_id.Binary());
    request.set_num_restarts_due_to_lineage_reconstruction(
        num_restarts_due_to_lineage_reconstrcution);
    rpc::ReportActorOutOfScopeReply reply;
    gcs_actor_manager_->HandleReportActorOutOfScope(
        request, &reply, [](auto status, auto success_callback, auto failure_callback) {
        });
    io_service_.run_one();
  }

  const absl::flat_hash_map<ActorID, std::vector<std::function<void(Status)>>>
      &GetActorRegisterCallbacks() const {
    return gcs_actor_manager_->actor_to_register_callbacks_;
  }

  std::unique_ptr<gcs::GcsActorManager> CreateActorManagerForInitializeTest() {
    auto scheduler = std::make_unique<MockActorScheduler>();
    return std::make_unique<gcs::GcsActorManager>(
        std::move(scheduler),
        gcs_table_storage_.get(),
        io_service_,
        gcs_publisher_.get(),
        *runtime_env_mgr_,
        *function_manager_,
        [](const ActorID &actor_id) {},
        *raylet_client_pool_,
        *worker_client_pool_,
        *fake_ray_event_recorder_,
        "test_session_name",
        fake_actor_by_state_gauge_,
        fake_gcs_actor_by_state_gauge_,
        observability_publisher_.get(),
        clock_);
  }

  size_t RegisteredActorCount(const gcs::GcsActorManager &actor_manager) const {
    return actor_manager.registered_actors_.size();
  }

  std::shared_ptr<gcs::GcsActor> GetRegisteredActor(
      const gcs::GcsActorManager &actor_manager, const ActorID &actor_id) const {
    auto actor_it = actor_manager.registered_actors_.find(actor_id);
    return actor_it != actor_manager.registered_actors_.end() ? actor_it->second
                                                              : nullptr;
  }

  /**
   * Helper function to perform the complete cycle of named actor creation.
   * 1. Register the actor
   * 2. Create the actor
   * 3. Actor connecting to the gcs
   * Also verifies that the actor is discoverable.
   *
   * @param job_id The job ID.
   * @param actor_name The name of the actor.
   * @param ray_namespace The ray namespace.
   * @param actor[out] Set to the created actor on success.
   */
  void RegisterAndCreateNamedActor(const JobID &job_id,
                                   const std::string &actor_name,
                                   const std::string &ray_namespace,
                                   const rpc::SendReplyCallback &send_reply_callback,
                                   std::shared_ptr<gcs::GcsActor> &actor) {
    // Spinning up the actor
    auto register_request1 = GenRegisterActorRequest(job_id,
                                                     /*max_restarts=*/-1,
                                                     /*detached=*/false,
                                                     /*actor_name=*/actor_name,
                                                     /*ray_namespace=*/ray_namespace);

    rpc::RegisterActorReply register_reply1;
    gcs_actor_manager_->HandleRegisterActor(
        register_request1, &register_reply1, send_reply_callback);
    drain_io_context();

    rpc::CreateActorRequest create_request1;
    create_request1.mutable_task_spec()->CopyFrom(register_request1.task_spec());
    rpc::CreateActorReply create_reply1;
    gcs_actor_manager_->HandleCreateActor(
        create_request1, &create_reply1, send_reply_callback);

    actor = mock_actor_scheduler_->actors.back();
    mock_actor_scheduler_->actors.pop_back();

    // Mock actor connecting to the gcs
    rpc::Address address = RandomAddress();
    actor->UpdateAddress(address);
    gcs_actor_manager_->OnActorCreationSuccess(actor, rpc::PushTaskReply());
    drain_io_context();
    ASSERT_EQ(actor->GetState(), rpc::ActorTableData::ALIVE);

    // Verify the actor is discoverable
    rpc::GetNamedActorInfoRequest get_request1;
    get_request1.set_name(actor_name);
    get_request1.set_ray_namespace(ray_namespace);

    rpc::GetNamedActorInfoReply get_reply1;
    gcs_actor_manager_->HandleGetNamedActorInfo(
        get_request1, &get_reply1, send_reply_callback);
    ASSERT_EQ(get_reply1.status().code(), static_cast<int>(StatusCode::OK))
        << absl::StrFormat(
               "Failed to get named actor info for actor %s in namespace %s. "
               "Was the actor created correctly?",
               actor_name,
               ray_namespace);
  }

  /**
   * @brief Flushes all events queued on the io_context without blocking.
   */
  void drain_io_context() {
    while (io_service_.poll_one()) {
    }
  }

  FakeClock clock_;
  instrumented_io_context io_service_;
  std::shared_ptr<gcs::StoreClient> store_client_;
  std::shared_ptr<gcs::GcsTableStorage> gcs_table_storage_;
  // Actor scheduler's ownership lies in actor manager.
  MockActorScheduler *mock_actor_scheduler_ = nullptr;
  std::shared_ptr<MockWorkerClient> worker_client_;
  std::shared_ptr<rpc::FakeRayletClient> raylet_client_;
  std::unique_ptr<rpc::RayletClientPool> raylet_client_pool_;
  std::unique_ptr<rpc::CoreWorkerClientPool> worker_client_pool_;
  absl::flat_hash_map<JobID, std::string> job_namespace_table_;
  std::unique_ptr<gcs::GcsActorManager> gcs_actor_manager_;
  std::shared_ptr<pubsub::GcsPublisher> gcs_publisher_;
  std::unique_ptr<pubsub::ObservabilityPublisher> observability_publisher_;
  std::unique_ptr<ray::RuntimeEnvManager> runtime_env_mgr_;
  const std::chrono::milliseconds timeout_ms_{2000};
  absl::Mutex mutex_;
  std::unique_ptr<gcs::GCSFunctionManager> function_manager_;
  std::unique_ptr<gcs::MockInternalKVInterface> kv_;
  std::shared_ptr<PeriodicalRunner> periodical_runner_;
  std::unique_ptr<observability::FakeRayEventRecorder> fake_ray_event_recorder_;
  ray::observability::FakeGauge fake_actor_by_state_gauge_;
  ray::observability::FakeGauge fake_gcs_actor_by_state_gauge_;
};

TEST_F(GcsActorManagerTest, TestBasic) {
  auto job_id = JobID::FromInt(1);
  auto registered_actor = RegisterActor(job_id);
  rpc::CreateActorRequest create_actor_request;
  create_actor_request.mutable_task_spec()->CopyFrom(
      registered_actor->GetCreationTaskSpecification().GetMessage());
  RAY_CHECK_EQ(
      gcs_actor_manager_->CountFor(rpc::ActorTableData::DEPENDENCIES_UNREADY, ""), 1);

  std::vector<std::shared_ptr<gcs::GcsActor>> finished_actors;
  Status status = gcs_actor_manager_->CreateActor(
      create_actor_request,
      [&finished_actors](const std::shared_ptr<gcs::GcsActor> &actor,
                         const rpc::PushTaskReply &reply,
                         const Status &) { finished_actors.emplace_back(actor); });
  RAY_CHECK_OK(status);
  RAY_CHECK_EQ(gcs_actor_manager_->CountFor(rpc::ActorTableData::PENDING_CREATION, ""),
               1);

  ASSERT_EQ(finished_actors.size(), 0);
  ASSERT_EQ(mock_actor_scheduler_->actors.size(), 1);
  auto actor = mock_actor_scheduler_->actors.back();
  mock_actor_scheduler_->actors.pop_back();

  // Check that the actor is in state `ALIVE`.
  actor->UpdateAddress(RandomAddress());
  gcs_actor_manager_->OnActorCreationSuccess(actor, rpc::PushTaskReply());
  io_service_.run_one();
  ASSERT_EQ(finished_actors.size(), 1);
  RAY_CHECK_EQ(gcs_actor_manager_->CountFor(rpc::ActorTableData::ALIVE, ""), 1);

  ASSERT_TRUE(worker_client_->Reply());
  ASSERT_EQ(actor->GetState(), rpc::ActorTableData::DEAD);
  RAY_CHECK_EQ(gcs_actor_manager_->CountFor(rpc::ActorTableData::ALIVE, ""), 0);
  RAY_CHECK_EQ(gcs_actor_manager_->CountFor(rpc::ActorTableData::DEAD, ""), 1);
}

TEST_F(GcsActorManagerTest, TestActorStateMetrics) {
  auto job_id = JobID::FromInt(1);
  auto registered_actor = RegisterActor(job_id);
  rpc::CreateActorRequest create_actor_request;
  create_actor_request.mutable_task_spec()->CopyFrom(
      registered_actor->GetCreationTaskSpecification().GetMessage());

  Status status =
      gcs_actor_manager_->CreateActor(create_actor_request,
                                      [](const std::shared_ptr<gcs::GcsActor> &actor,
                                         const rpc::PushTaskReply &reply,
                                         const Status &) {});
  RAY_CHECK_OK(status);
  auto actor = mock_actor_scheduler_->actors.back();
  mock_actor_scheduler_->actors.pop_back();
  actor->UpdateAddress(RandomAddress());
  gcs_actor_manager_->OnActorCreationSuccess(actor, rpc::PushTaskReply());
  io_service_.run_one();

  // cleanup the registered_actor so that the destructor can be called to update the
  // count
  registered_actor.reset();
  gcs_actor_manager_->RecordMetrics();
  auto gcs_actor_tag_to_value = fake_gcs_actor_by_state_gauge_.GetTagToValue();
  // 5 states: REGISTERED, CREATED, DESTROYED, UNRESOLVED, PENDING
  ASSERT_EQ(gcs_actor_tag_to_value.size(), 5);
  // 3 states: DEPENDENCIES_UNREADY, PENDING_CREATION, ALIVE
  auto tag_to_value = fake_actor_by_state_gauge_.GetTagToValue();
  ASSERT_EQ(tag_to_value.size(), 3);

  // Returns the actors gauge value for the given State tag, or -1 if absent.
  auto value_for_state = [this](const std::string &state) -> double {
    for (const auto &[tags, value] : fake_actor_by_state_gauge_.GetTagToValue()) {
      if (tags.at("State") == state) {
        return value;
      }
    }
    return -1;
  };
  // Only ALIVE is live; the states the actor passed through are retracted to 0.
  ASSERT_EQ(value_for_state("ALIVE"), 1);
  ASSERT_EQ(value_for_state("PENDING_CREATION"), 0);
  ASSERT_EQ(value_for_state("DEPENDENCIES_UNREADY"), 0);

  // With no transition, the ALIVE actor must still be re-asserted on the next tick
  // (the metrics backend clears gauge observations after each export, #56405).
  fake_actor_by_state_gauge_.Clear();
  gcs_actor_manager_->RecordMetrics();
  ASSERT_EQ(value_for_state("ALIVE"), 1)
      << "alive actor must persist without a transition";
}

TEST_F(GcsActorManagerTest, TestDeadCount) {
  ///
  /// Verify the DEAD count is correct after actors are GC'ed from the GCS.
  /// Actors are GC'ed from the GCS when there are more than
  /// maximum_gcs_destroyed_actor_cached_count dead actors.
  ///

  // Make sure we can cache only up to 10 dead actors.
  ASSERT_EQ(RayConfig::instance().maximum_gcs_destroyed_actor_cached_count(), 10);
  auto job_id = JobID::FromInt(1);

  // Create 20 actors.
  for (int i = 0; i < 20; i++) {
    auto registered_actor = RegisterActor(job_id);
    rpc::CreateActorRequest create_actor_request;
    create_actor_request.mutable_task_spec()->CopyFrom(
        registered_actor->GetCreationTaskSpecification().GetMessage());

    Status status =
        gcs_actor_manager_->CreateActor(create_actor_request,
                                        [](const std::shared_ptr<gcs::GcsActor> &actor,
                                           const rpc::PushTaskReply &reply,
                                           const Status &) {});
    RAY_CHECK_OK(status);
    auto actor = mock_actor_scheduler_->actors.back();
    mock_actor_scheduler_->actors.pop_back();
    // Check that the actor is in state `ALIVE`.
    actor->UpdateAddress(RandomAddress());
    gcs_actor_manager_->OnActorCreationSuccess(actor, rpc::PushTaskReply());
    io_service_.run_one();
    // Actor is killed.
    ASSERT_TRUE(worker_client_->Reply());
    ASSERT_EQ(actor->GetState(), rpc::ActorTableData::DEAD);
  }

  // drain every handler posted on the io_context when actor is destroyed to assert final
  // state
  drain_io_context();

  RAY_CHECK_EQ(gcs_actor_manager_->CountFor(rpc::ActorTableData::DEAD, ""), 20);

  // The observability cache must hold exactly the configured maximum.
  ASSERT_EQ(gcs_actor_manager_->destroyed_actor_observability_data_.size(), 10u);
}

TEST_F(GcsActorManagerTest, TestNonDeadEntryEvictionDecrementsCounter) {
  ///
  /// Verify that when a non-DEAD entry is evicted from the observability cache,
  /// the counter for that state is decremented. This mirrors
  /// `GcsActor::~GcsActor`'s carve-out: DEAD counts are intentionally cumulative,
  /// but non-DEAD counts must be balanced. Only Initialize-rehydrated orphans
  /// (e.g., ALIVE actor whose owning job died) ever land in the cache with a
  /// non-DEAD state; the normal `DestroyActor` path always transitions to DEAD
  /// before insertion, so `TestDeadCount` doesn't exercise this path.
  ///
  ASSERT_EQ(RayConfig::instance().maximum_gcs_destroyed_actor_cached_count(), 10);

  // Seed the cache with an orphaned ALIVE entry, simulating what Initialize
  // would produce for an actor whose owner job died while it was still alive.
  const std::string orphan_class = "OrphanClass";
  auto orphan_job_id = JobID::FromInt(99);
  ActorID orphan_id =
      ActorID::Of(orphan_job_id, TaskID::FromRandom(orphan_job_id), /*counter=*/0);
  rpc::ActorTableData orphan_data;
  orphan_data.set_actor_id(orphan_id.Binary());
  orphan_data.set_state(rpc::ActorTableData::ALIVE);
  orphan_data.set_class_name(orphan_class);
  // timestamp=0 ensures the orphan stays at the head of the sorted list so it's
  // the first thing evicted when the cache fills.
  orphan_data.set_timestamp(0);

  gcs_actor_manager_->destroyed_actor_observability_data_.emplace(orphan_id, orphan_data);
  gcs_actor_manager_->sorted_destroyed_actor_observability_list_.emplace_back(orphan_id,
                                                                              0);
  gcs_actor_manager_->actor_state_counter_->Increment(
      {rpc::ActorTableData::ALIVE, orphan_class});

  ASSERT_EQ(gcs_actor_manager_->CountFor(rpc::ActorTableData::ALIVE, orphan_class), 1);
  ASSERT_EQ(gcs_actor_manager_->destroyed_actor_observability_data_.size(), 1u);

  // Now drive 10 actor deaths through the normal flow. Cache cap is 10; starting
  // size is 1; the 10th destroy finds size>=10 and triggers eviction of the
  // orphan (oldest by timestamp).
  auto job_id = JobID::FromInt(1);
  for (int i = 0; i < 10; i++) {
    auto registered_actor = RegisterActor(job_id);
    rpc::CreateActorRequest create_actor_request;
    create_actor_request.mutable_task_spec()->CopyFrom(
        registered_actor->GetCreationTaskSpecification().GetMessage());

    Status status =
        gcs_actor_manager_->CreateActor(create_actor_request,
                                        [](const std::shared_ptr<gcs::GcsActor> &actor,
                                           const rpc::PushTaskReply &reply,
                                           const Status &) {});
    RAY_CHECK_OK(status);
    auto actor = mock_actor_scheduler_->actors.back();
    mock_actor_scheduler_->actors.pop_back();
    // Check that the actor is in state `ALIVE`.
    actor->UpdateAddress(RandomAddress());
    gcs_actor_manager_->OnActorCreationSuccess(actor, rpc::PushTaskReply());
    io_service_.run_one();
    // Actor is killed.
    ASSERT_TRUE(worker_client_->Reply());
    ASSERT_EQ(actor->GetState(), rpc::ActorTableData::DEAD);
  }
  drain_io_context();

  // The orphan should have been evicted and its ALIVE count decremented.
  ASSERT_FALSE(
      gcs_actor_manager_->destroyed_actor_observability_data_.contains(orphan_id));
  ASSERT_EQ(gcs_actor_manager_->CountFor(rpc::ActorTableData::ALIVE, orphan_class), 0);

  // Cache is still at the configured cap.
  ASSERT_EQ(gcs_actor_manager_->destroyed_actor_observability_data_.size(), 10u);
}

TEST_F(GcsActorManagerTest, TestActorCreationRaceWithRestart) {
  auto job_id = JobID::FromInt(1);

  // Register and Create Actor.
  auto request = GenRegisterActorRequest(job_id, /*max_restarts=*/1, /*detached=*/false);
  auto actor_id =
      ActorID::FromBinary(request.task_spec().actor_creation_task_spec().actor_id());

  rpc::RegisterActorReply register_reply;
  gcs_actor_manager_->HandleRegisterActor(
      request, &register_reply, [](auto, auto, auto) {});
  drain_io_context();

  rpc::CreateActorRequest create_request;
  create_request.mutable_task_spec()->CopyFrom(request.task_spec());
  rpc::CreateActorReply create_reply;

  bool callback_invoked = false;
  gcs_actor_manager_->HandleCreateActor(
      create_request, &create_reply, [&callback_invoked](Status status, auto, auto) {
        callback_invoked = true;
        ASSERT_TRUE(status.ok());
      });

  // Get the actor instance from the scheduler.
  ASSERT_FALSE(mock_actor_scheduler_->actors.empty());
  auto actor = mock_actor_scheduler_->actors.back();

  // Manually simulate success state (ALIVE) without triggering storage write.
  auto address = RandomAddress();
  auto object_id = "test_object_id";
  actor->UpdateAddress(address);
  actor->UpdateState(rpc::ActorTableData::ALIVE);
  google::protobuf::RepeatedPtrField<rpc::ObjectReferenceCount> borrowed_refs;
  borrowed_refs.Add()->mutable_reference()->set_object_id(object_id);
  actor->SetBorrowedRefsAtCreation(borrowed_refs);

  // Verify it hasn't been invoked yet since OnActorCreationSuccess is not called.
  ASSERT_FALSE(callback_invoked);

  // Mock CancelOnWorker to return the actor_id, simulating worker death during creation.
  EXPECT_CALL(*mock_actor_scheduler_,
              CancelOnWorker(NodeID::FromBinary(address.node_id()),
                             WorkerID::FromBinary(address.worker_id())))
      .WillOnce(testing::Return(actor_id));

  // Trigger worker death.
  gcs_actor_manager_->OnWorkerDead(NodeID::FromBinary(address.node_id()),
                                   WorkerID::FromBinary(address.worker_id()),
                                   "127.0.0.1",
                                   rpc::WorkerExitType::SYSTEM_ERROR,
                                   "worker process has died.");

  // Verify that callbacks are invoked.
  ASSERT_TRUE(callback_invoked);
  // Verify that the reply is correctly populated with the original created address and
  // borrowed_refs.
  ASSERT_EQ(create_reply.actor_address().worker_id(), address.worker_id());
  ASSERT_EQ(create_reply.actor_address().node_id(), address.node_id());
  ASSERT_EQ(create_reply.borrowed_refs().size(), 1);
  ASSERT_EQ(create_reply.borrowed_refs(0).reference().object_id(), object_id);
}

TEST_F(GcsActorManagerTest, TestActorCreationRaceWithRestartActorNotAlive) {
  auto job_id = JobID::FromInt(1);

  // Register and Create Actor.
  auto request = GenRegisterActorRequest(job_id, /*max_restarts=*/1, /*detached=*/false);
  auto actor_id =
      ActorID::FromBinary(request.task_spec().actor_creation_task_spec().actor_id());

  rpc::RegisterActorReply register_reply;
  gcs_actor_manager_->HandleRegisterActor(
      request, &register_reply, [](auto, auto, auto) {});
  drain_io_context();

  rpc::CreateActorRequest create_request;
  create_request.mutable_task_spec()->CopyFrom(request.task_spec());
  rpc::CreateActorReply create_reply;

  bool callback_invoked = false;
  gcs_actor_manager_->HandleCreateActor(
      create_request, &create_reply, [&callback_invoked](Status status, auto, auto) {
        callback_invoked = true;
        ASSERT_TRUE(status.ok());
      });

  // Get the actor instance from the scheduler.
  ASSERT_FALSE(mock_actor_scheduler_->actors.empty());
  auto actor = mock_actor_scheduler_->actors.back();

  // Simulate a state where the actor is in PENDING_CREATION (not ALIVE yet).
  auto address = RandomAddress();
  actor->UpdateAddress(address);
  actor->UpdateState(rpc::ActorTableData::PENDING_CREATION);

  // Verify it hasn't been invoked yet.
  ASSERT_FALSE(callback_invoked);

  // Mock CancelOnWorker to return the actor_id, simulating worker death during creation.
  EXPECT_CALL(*mock_actor_scheduler_,
              CancelOnWorker(NodeID::FromBinary(address.node_id()),
                             WorkerID::FromBinary(address.worker_id())))
      .WillOnce(testing::Return(actor_id));

  // Trigger worker death.
  gcs_actor_manager_->OnWorkerDead(NodeID::FromBinary(address.node_id()),
                                   WorkerID::FromBinary(address.worker_id()),
                                   "127.0.0.1",
                                   rpc::WorkerExitType::SYSTEM_ERROR,
                                   "worker process has died.");

  // Verify that the creation callback is NOT invoked early when the actor is not ALIVE.
  ASSERT_FALSE(callback_invoked);
  // Verify that the reply remains empty and unpopulated.
  ASSERT_FALSE(create_reply.has_actor_address());
  ASSERT_EQ(create_reply.borrowed_refs().size(), 0);
}

TEST_F(GcsActorManagerTest, TestSchedulingFailed) {
  auto job_id = JobID::FromInt(1);
  auto registered_actor = RegisterActor(job_id);
  rpc::CreateActorRequest create_actor_request;
  create_actor_request.mutable_task_spec()->CopyFrom(
      registered_actor->GetCreationTaskSpecification().GetMessage());

  std::vector<std::shared_ptr<gcs::GcsActor>> finished_actors;
  RAY_CHECK_OK(gcs_actor_manager_->CreateActor(
      create_actor_request,
      [&finished_actors](std::shared_ptr<gcs::GcsActor> result_actor,
                         const rpc::PushTaskReply &,
                         const Status &) {
        finished_actors.emplace_back(result_actor);
      }));

  ASSERT_EQ(finished_actors.size(), 0);
  ASSERT_EQ(mock_actor_scheduler_->actors.size(), 1);
  auto actor = mock_actor_scheduler_->actors.back();
  mock_actor_scheduler_->actors.clear();

  gcs_actor_manager_->OnActorSchedulingFailed(
      actor,
      rpc::RequestWorkerLeaseReply::SCHEDULING_CANCELLED_RUNTIME_ENV_SETUP_FAILED,
      "");
  io_service_.run_one();
  ASSERT_EQ(mock_actor_scheduler_->actors.size(), 0);
}

TEST_F(GcsActorManagerTest, TestWorkerFailure) {
  auto job_id = JobID::FromInt(1);
  auto registered_actor = RegisterActor(job_id);
  rpc::CreateActorRequest create_actor_request;
  create_actor_request.mutable_task_spec()->CopyFrom(
      registered_actor->GetCreationTaskSpecification().GetMessage());

  std::vector<std::shared_ptr<gcs::GcsActor>> finished_actors;
  RAY_CHECK_OK(gcs_actor_manager_->CreateActor(
      create_actor_request,
      [&finished_actors](std::shared_ptr<gcs::GcsActor> result_actor,
                         const rpc::PushTaskReply &,
                         const Status &) {
        finished_actors.emplace_back(result_actor);
      }));

  ASSERT_EQ(finished_actors.size(), 0);
  ASSERT_EQ(mock_actor_scheduler_->actors.size(), 1);
  auto actor = mock_actor_scheduler_->actors.back();
  mock_actor_scheduler_->actors.pop_back();

  // Check that the actor is in state `ALIVE`.
  auto address = RandomAddress();
  auto node_id = NodeID::FromBinary(address.node_id());
  auto worker_id = WorkerID::FromBinary(address.worker_id());
  actor->UpdateAddress(address);
  gcs_actor_manager_->OnActorCreationSuccess(actor, rpc::PushTaskReply());
  io_service_.run_one();
  ASSERT_EQ(finished_actors.size(), 1);

  // Killing another worker does not affect this actor.
  EXPECT_CALL(*mock_actor_scheduler_, CancelOnWorker(node_id, _));
  gcs_actor_manager_->OnWorkerDead(node_id, WorkerID::FromRandom());
  ASSERT_EQ(actor->GetState(), rpc::ActorTableData::ALIVE);

  // Remove worker and then check that the actor is dead.
  gcs_actor_manager_->OnWorkerDead(node_id, worker_id);
  ASSERT_EQ(actor->GetState(), rpc::ActorTableData::DEAD);
  ASSERT_TRUE(actor->GetActorTableData().death_cause().has_actor_died_error_context());
  ASSERT_TRUE(absl::StrContains(
      actor->GetActorTableData().death_cause().actor_died_error_context().error_message(),
      "worker process has died."));
  // No more actors to schedule.
  ASSERT_EQ(mock_actor_scheduler_->actors.size(), 0);

  ASSERT_TRUE(worker_client_->Reply());
}

TEST_F(GcsActorManagerTest, TestNodeFailure) {
  auto job_id = JobID::FromInt(1);
  auto registered_actor = RegisterActor(job_id);
  rpc::CreateActorRequest create_actor_request;
  create_actor_request.mutable_task_spec()->CopyFrom(
      registered_actor->GetCreationTaskSpecification().GetMessage());

  std::vector<std::shared_ptr<gcs::GcsActor>> finished_actors;
  Status status = gcs_actor_manager_->CreateActor(
      create_actor_request,
      [&finished_actors](std::shared_ptr<gcs::GcsActor> actor,
                         const rpc::PushTaskReply &,
                         const Status &) { finished_actors.emplace_back(actor); });
  RAY_CHECK_OK(status);

  ASSERT_EQ(finished_actors.size(), 0);
  ASSERT_EQ(mock_actor_scheduler_->actors.size(), 1);
  auto actor = mock_actor_scheduler_->actors.back();
  mock_actor_scheduler_->actors.pop_back();

  // Check that the actor is in state `ALIVE`.
  auto address = RandomAddress();
  actor->UpdateAddress(address);
  gcs_actor_manager_->OnActorCreationSuccess(actor, rpc::PushTaskReply());
  io_service_.run_one();
  ASSERT_EQ(finished_actors.size(), 1);

  // Killing another node does not affect this actor.
  EXPECT_CALL(*mock_actor_scheduler_, CancelOnNode(_));
  OnNodeDead(NodeID::FromRandom());
  ASSERT_EQ(actor->GetState(), rpc::ActorTableData::ALIVE);

  // Remove node and then check that the actor is dead.
  auto node_id = NodeID::FromBinary(address.node_id());
  EXPECT_CALL(*mock_actor_scheduler_, CancelOnNode(node_id));

  OnNodeDead(node_id);
  ASSERT_EQ(actor->GetState(), rpc::ActorTableData::DEAD);
  ASSERT_TRUE(actor->GetActorTableData().death_cause().has_actor_died_error_context());
  ASSERT_TRUE(absl::StrContains(
      actor->GetActorTableData().death_cause().actor_died_error_context().error_message(),
      "node has died."));
  // No more actors to schedule.
  ASSERT_EQ(mock_actor_scheduler_->actors.size(), 0);

  ASSERT_TRUE(worker_client_->Reply());
}

TEST_F(GcsActorManagerTest, TestActorReconstruction) {
  auto job_id = JobID::FromInt(1);
  auto registered_actor = RegisterActor(job_id,
                                        /*max_restarts=*/1,
                                        /*detached=*/false);
  rpc::CreateActorRequest create_actor_request;
  create_actor_request.mutable_task_spec()->CopyFrom(
      registered_actor->GetCreationTaskSpecification().GetMessage());

  std::vector<std::shared_ptr<gcs::GcsActor>> finished_actors;
  Status status = gcs_actor_manager_->CreateActor(
      create_actor_request,
      [&finished_actors](std::shared_ptr<gcs::GcsActor> actor,
                         const rpc::PushTaskReply &,
                         const Status &) { finished_actors.emplace_back(actor); });
  RAY_CHECK_OK(status);

  ASSERT_EQ(finished_actors.size(), 0);
  ASSERT_EQ(mock_actor_scheduler_->actors.size(), 1);
  auto actor = mock_actor_scheduler_->actors.back();
  mock_actor_scheduler_->actors.pop_back();

  // Check that the actor is in state `ALIVE`.
  auto address = RandomAddress();
  auto node_id = NodeID::FromBinary(address.node_id());
  actor->UpdateAddress(address);
  gcs_actor_manager_->OnActorCreationSuccess(actor, rpc::PushTaskReply());
  io_service_.run_one();
  ASSERT_EQ(finished_actors.size(), 1);

  // Remove worker and then check that the actor is being restarted.
  EXPECT_CALL(*mock_actor_scheduler_, CancelOnNode(node_id));
  OnNodeDead(node_id);
  ASSERT_EQ(actor->GetState(), rpc::ActorTableData::RESTARTING);

  // Add node and check that the actor is restarted.
  ASSERT_EQ(mock_actor_scheduler_->actors.size(), 1);
  mock_actor_scheduler_->actors.clear();
  ASSERT_EQ(finished_actors.size(), 1);
  auto node_id2 = NodeID::FromRandom();
  address.set_node_id(node_id2.Binary());
  actor->UpdateAddress(address);
  gcs_actor_manager_->OnActorCreationSuccess(actor, rpc::PushTaskReply());
  io_service_.run_one();
  io_service_.run_one();
  ASSERT_EQ(finished_actors.size(), 1);
  ASSERT_EQ(actor->GetState(), rpc::ActorTableData::ALIVE);
  ASSERT_EQ(actor->GetNodeID(), node_id2);

  // Killing another worker does not affect this actor.
  EXPECT_CALL(*mock_actor_scheduler_, CancelOnNode(_));
  OnNodeDead(NodeID::FromRandom());
  ASSERT_EQ(actor->GetState(), rpc::ActorTableData::ALIVE);

  // Remove worker and then check that the actor is dead.
  EXPECT_CALL(*mock_actor_scheduler_, CancelOnNode(node_id2));
  OnNodeDead(node_id2);
  ASSERT_EQ(actor->GetState(), rpc::ActorTableData::DEAD);
  ASSERT_TRUE(actor->GetActorTableData().death_cause().has_actor_died_error_context());
  ASSERT_TRUE(absl::StrContains(
      actor->GetActorTableData().death_cause().actor_died_error_context().error_message(),
      "node has died."));
  // No more actors to schedule.
  ASSERT_EQ(mock_actor_scheduler_->actors.size(), 0);

  ASSERT_TRUE(worker_client_->Reply());
}

TEST_F(GcsActorManagerTest, TestActorRestartWhenOwnerDead) {
  auto job_id = JobID::FromInt(1);
  auto registered_actor = RegisterActor(job_id,
                                        /*max_restarts=*/1,
                                        /*detached=*/false);
  rpc::CreateActorRequest create_actor_request;
  create_actor_request.mutable_task_spec()->CopyFrom(
      registered_actor->GetCreationTaskSpecification().GetMessage());

  std::vector<std::shared_ptr<gcs::GcsActor>> finished_actors;
  RAY_CHECK_OK(gcs_actor_manager_->CreateActor(
      create_actor_request,
      [&finished_actors](std::shared_ptr<gcs::GcsActor> result_actor,
                         const rpc::PushTaskReply &,
                         const Status &) {
        finished_actors.emplace_back(result_actor);
      }));

  ASSERT_EQ(finished_actors.size(), 0);
  ASSERT_EQ(mock_actor_scheduler_->actors.size(), 1);
  auto actor = mock_actor_scheduler_->actors.back();
  mock_actor_scheduler_->actors.pop_back();
  const auto owner_node_id = actor->GetOwnerNodeID();

  // Check that the actor is in state `ALIVE`.
  auto address = RandomAddress();
  auto node_id = NodeID::FromBinary(address.node_id());
  actor->UpdateAddress(address);
  gcs_actor_manager_->OnActorCreationSuccess(actor, rpc::PushTaskReply());
  io_service_.run_one();
  ASSERT_EQ(finished_actors.size(), 1);

  // Remove the owner's node.
  EXPECT_CALL(*mock_actor_scheduler_, CancelOnNode(owner_node_id));
  OnNodeDead(owner_node_id);
  // The child actor should be marked as dead.
  ASSERT_EQ(actor->GetState(), rpc::ActorTableData::DEAD);
  ASSERT_TRUE(actor->GetActorTableData().death_cause().has_actor_died_error_context());
  ASSERT_TRUE(absl::StrContains(
      actor->GetActorTableData().death_cause().actor_died_error_context().error_message(),
      "owner has died."));
  // The worker has not yet been granted a lease, so no KillActor RPC should be sent.
  ASSERT_EQ(raylet_client_->killed_actors.size(), 0);

  // Remove the actor's node and check that the actor is not restarted, since
  // its owner has died.
  EXPECT_CALL(*mock_actor_scheduler_, CancelOnNode(node_id));
  OnNodeDead(node_id);
  ASSERT_EQ(actor->GetState(), rpc::ActorTableData::DEAD);
  ASSERT_TRUE(mock_actor_scheduler_->actors.empty());
}

TEST_F(GcsActorManagerTest, TestDetachedActorRestartWhenCreatorDead) {
  auto job_id = JobID::FromInt(1);
  auto registered_actor = RegisterActor(job_id,
                                        /*max_restarts=*/1,
                                        /*detached=*/true);
  rpc::CreateActorRequest create_actor_request;
  create_actor_request.mutable_task_spec()->CopyFrom(
      registered_actor->GetCreationTaskSpecification().GetMessage());

  std::vector<std::shared_ptr<gcs::GcsActor>> finished_actors;
  RAY_CHECK_OK(gcs_actor_manager_->CreateActor(
      create_actor_request,
      [&finished_actors](std::shared_ptr<gcs::GcsActor> result_actor,
                         const rpc::PushTaskReply &,
                         const Status &) {
        finished_actors.emplace_back(result_actor);
      }));

  ASSERT_EQ(finished_actors.size(), 0);
  ASSERT_EQ(mock_actor_scheduler_->actors.size(), 1);
  auto actor = mock_actor_scheduler_->actors.back();
  mock_actor_scheduler_->actors.pop_back();
  const auto owner_node_id = actor->GetOwnerNodeID();

  // Check that the actor is in state `ALIVE`.
  actor->UpdateAddress(RandomAddress());
  gcs_actor_manager_->OnActorCreationSuccess(actor, rpc::PushTaskReply());
  io_service_.run_one();
  ASSERT_EQ(finished_actors.size(), 1);

  // Remove the owner's node.
  EXPECT_CALL(*mock_actor_scheduler_, CancelOnNode(owner_node_id));
  OnNodeDead(owner_node_id);
  // The child actor should not be marked as dead.
  ASSERT_TRUE(raylet_client_->killed_actors.empty());
  ASSERT_EQ(actor->GetState(), rpc::ActorTableData::ALIVE);
}

TEST_F(GcsActorManagerTest, TestActorWithEmptyName) {
  auto job_id = JobID::FromInt(1);

  // Gen `CreateActorRequest` with an empty name.
  // (name,actor_id) => ("", actor_id_1)
  auto request1 = GenRegisterActorRequest(job_id,
                                          /*max_restarts=*/0,
                                          /*detached=*/true,
                                          /*name=*/"");

  Status status = gcs_actor_manager_->RegisterActor(request1, [](const Status &) {});
  io_service_.run_one();

  // Ensure successful registration.
  ASSERT_TRUE(status.ok());
  // Make sure actor who empty name is not treated as a named actor.
  ASSERT_TRUE(gcs_actor_manager_->GetActorIDByName("", "").IsNil());

  // Gen another `CreateActorRequest` with an empty name.
  // (name,actor_id) => ("", actor_id_2)
  auto request2 = GenRegisterActorRequest(job_id,
                                          /*max_restarts=*/0,
                                          /*detached=*/true,
                                          /*name=*/"");
  status = gcs_actor_manager_->RegisterActor(request2, [](const Status &) {});
  io_service_.run_one();
  // Ensure successful registration.
  ASSERT_TRUE(status.ok());
}

TEST_F(GcsActorManagerTest, TestNamedActors) {
  auto job_id_1 = JobID::FromInt(1);
  auto job_id_2 = JobID::FromInt(2);

  auto request1 = GenRegisterActorRequest(job_id_1,
                                          /*max_restarts=*/0,
                                          /*detached=*/true,
                                          /*name=*/"actor1",
                                          /*ray_namespace=*/"test_named_actor");
  Status status = gcs_actor_manager_->RegisterActor(request1, [](const Status &) {});
  io_service_.run_one();
  ASSERT_TRUE(status.ok());
  ASSERT_EQ(gcs_actor_manager_->GetActorIDByName("actor1", "test_named_actor").Binary(),
            request1.task_spec().actor_creation_task_spec().actor_id());

  auto request2 = GenRegisterActorRequest(job_id_1,
                                          /*max_restarts=*/0,
                                          /*detached=*/true,
                                          /*name=*/"actor2",
                                          /*ray_namesapce=*/"test_named_actor");
  status = gcs_actor_manager_->RegisterActor(request2, [](const Status &) {});
  io_service_.run_one();
  ASSERT_TRUE(status.ok());
  ASSERT_EQ(gcs_actor_manager_->GetActorIDByName("actor2", "test_named_actor").Binary(),
            request2.task_spec().actor_creation_task_spec().actor_id());

  // Check that looking up a non-existent name returns ActorID::Nil();
  ASSERT_EQ(gcs_actor_manager_->GetActorIDByName("actor3", "test_named_actor"),
            ActorID::Nil());

  // Check that naming collisions return Status::AlreadyExists.
  auto request3 = GenRegisterActorRequest(job_id_1,
                                          /*max_restarts=*/0,
                                          /*detached=*/true,
                                          /*name=*/"actor2",
                                          /*ray_namesapce=*/"test_named_actor");
  status = gcs_actor_manager_->RegisterActor(request3, [](const Status &) {});
  io_service_.run_one();
  ASSERT_TRUE(status.IsAlreadyExists());
  ASSERT_EQ(gcs_actor_manager_->GetActorIDByName("actor2", "test_named_actor").Binary(),
            request2.task_spec().actor_creation_task_spec().actor_id());

  // Check that naming collisions are enforced across JobIDs.
  auto request4 = GenRegisterActorRequest(job_id_2,
                                          /*max_restarts=*/0,
                                          /*detached=*/true,
                                          /*name=*/"actor2",
                                          /*ray_namesapce=*/"test_named_actor");
  status = gcs_actor_manager_->RegisterActor(request4, [](const Status &) {});
  io_service_.run_one();
  ASSERT_TRUE(status.IsAlreadyExists());
  ASSERT_EQ(gcs_actor_manager_->GetActorIDByName("actor2", "test_named_actor").Binary(),
            request2.task_spec().actor_creation_task_spec().actor_id());
}

TEST_F(GcsActorManagerTest, TestNamedActorDeletionWorkerFailure) {
  // Make sure named actor deletion succeeds when workers fail.
  const auto actor_name = "actor_to_delete";
  const auto job_id_1 = JobID::FromInt(1);
  auto registered_actor_1 = RegisterActor(job_id_1,
                                          /*max_restarts=*/0,
                                          /*detached=*/true,
                                          /*name=*/actor_name);
  rpc::CreateActorRequest request1;
  request1.mutable_task_spec()->CopyFrom(
      registered_actor_1->GetCreationTaskSpecification().GetMessage());

  Status status = gcs_actor_manager_->CreateActor(
      request1,
      [](std::shared_ptr<gcs::GcsActor>, const rpc::PushTaskReply &, const Status &) {});
  ASSERT_TRUE(status.ok());
  ASSERT_EQ(gcs_actor_manager_->GetActorIDByName(actor_name, "test").Binary(),
            request1.task_spec().actor_creation_task_spec().actor_id());

  auto actor = mock_actor_scheduler_->actors.back();
  mock_actor_scheduler_->actors.pop_back();

  // Check that the actor is in state `ALIVE`.
  auto address = RandomAddress();
  auto node_id = NodeID::FromBinary(address.node_id());
  auto worker_id = WorkerID::FromBinary(address.worker_id());
  actor->UpdateAddress(address);
  gcs_actor_manager_->OnActorCreationSuccess(actor, rpc::PushTaskReply());
  io_service_.run_one();

  // Remove worker and then check that the actor is dead.
  gcs_actor_manager_->OnWorkerDead(node_id, worker_id);
  ASSERT_EQ(actor->GetState(), rpc::ActorTableData::DEAD);
  ASSERT_TRUE(actor->GetActorTableData().death_cause().has_actor_died_error_context());
  ASSERT_TRUE(absl::StrContains(
      actor->GetActorTableData().death_cause().actor_died_error_context().error_message(),
      "worker process has died."));
  ASSERT_EQ(gcs_actor_manager_->GetActorIDByName(actor_name, "test"),
            actor->GetActorID());

  // Detached actor has no reply of WaitForActorRefDeleted request.
  ASSERT_FALSE(worker_client_->Reply());
  // Kill this detached actor
  rpc::KillActorViaGcsReply reply;
  rpc::KillActorViaGcsRequest request;
  request.set_actor_id(actor->GetActorID().Binary());
  request.set_force_kill(true);
  request.set_no_restart(true);
  gcs_actor_manager_->HandleKillActorViaGcs(
      request,
      &reply,
      /*send_reply_callback*/
      [](Status status, std::function<void()> success, std::function<void()> failure) {});
  io_service_.run_one();

  ASSERT_EQ(gcs_actor_manager_->GetActorIDByName(actor_name, "test"), ActorID::Nil());

  // Create an actor with the same name. This ensures that the name has been properly
  // deleted.
  auto registered_actor_2 = RegisterActor(job_id_1,
                                          /*max_restarts=*/0,
                                          /*detached=*/true,
                                          /*name=*/actor_name);
  rpc::CreateActorRequest request2;
  request2.mutable_task_spec()->CopyFrom(
      registered_actor_2->GetCreationTaskSpecification().GetMessage());

  status = gcs_actor_manager_->CreateActor(
      request2,
      [](std::shared_ptr<gcs::GcsActor>, const rpc::PushTaskReply &, const Status &) {});
  ASSERT_TRUE(status.ok());
  ASSERT_EQ(gcs_actor_manager_->GetActorIDByName(actor_name, "test").Binary(),
            request2.task_spec().actor_creation_task_spec().actor_id());
}

TEST_F(GcsActorManagerTest, TestNamedActorDeletionNodeFailure) {
  // Make sure named actor deletion succeeds when nodes fail.
  const auto job_id_1 = JobID::FromInt(1);
  auto registered_actor_1 = RegisterActor(job_id_1,
                                          /*max_restarts=*/0,
                                          /*detached=*/true,
                                          /*name=*/"actor");
  rpc::CreateActorRequest request1;
  request1.mutable_task_spec()->CopyFrom(
      registered_actor_1->GetCreationTaskSpecification().GetMessage());

  Status status = gcs_actor_manager_->CreateActor(
      request1,
      [](std::shared_ptr<gcs::GcsActor>, const rpc::PushTaskReply &, const Status &) {});
  ASSERT_TRUE(status.ok());
  ASSERT_EQ(gcs_actor_manager_->GetActorIDByName("actor", "test").Binary(),
            request1.task_spec().actor_creation_task_spec().actor_id());

  auto actor = mock_actor_scheduler_->actors.back();
  mock_actor_scheduler_->actors.pop_back();

  // Check that the actor is in state `ALIVE`.
  auto address = RandomAddress();
  auto node_id = NodeID::FromBinary(address.node_id());
  actor->UpdateAddress(address);
  gcs_actor_manager_->OnActorCreationSuccess(actor, rpc::PushTaskReply());
  io_service_.run_one();

  // Remove node and then check that the actor is dead.
  EXPECT_CALL(*mock_actor_scheduler_, CancelOnNode(node_id));
  OnNodeDead(node_id);
  ASSERT_EQ(actor->GetState(), rpc::ActorTableData::DEAD);
  ASSERT_TRUE(actor->GetActorTableData().death_cause().has_actor_died_error_context());
  ASSERT_TRUE(absl::StrContains(
      actor->GetActorTableData().death_cause().actor_died_error_context().error_message(),
      "node has died."));

  // Create an actor with the same name. This ensures that the name has been properly
  // deleted.
  auto registered_actor_2 = RegisterActor(job_id_1,
                                          /*max_restarts=*/0,
                                          /*detached=*/true,
                                          /*name=*/"actor");
  rpc::CreateActorRequest request2;
  request2.mutable_task_spec()->CopyFrom(
      registered_actor_2->GetCreationTaskSpecification().GetMessage());

  status = gcs_actor_manager_->CreateActor(
      request2,
      [](std::shared_ptr<gcs::GcsActor>, const rpc::PushTaskReply &, const Status &) {});
  ASSERT_TRUE(status.ok());
  ASSERT_EQ(gcs_actor_manager_->GetActorIDByName("actor", "test").Binary(),
            request2.task_spec().actor_creation_task_spec().actor_id());
}

TEST_F(GcsActorManagerTest, TestNamedActorDeletionNotHappendWhenReconstructed) {
  // Make sure named actor deletion succeeds when nodes fail.
  const auto job_id_1 = JobID::FromInt(1);
  // The dead actor will be reconstructed.
  auto registered_actor_1 = RegisterActor(job_id_1,
                                          /*max_restarts=*/1,
                                          /*detached=*/true,
                                          /*name=*/"actor");
  rpc::CreateActorRequest request1;
  request1.mutable_task_spec()->CopyFrom(
      registered_actor_1->GetCreationTaskSpecification().GetMessage());

  Status status = gcs_actor_manager_->CreateActor(request1,
                                                  [](std::shared_ptr<gcs::GcsActor> actor,
                                                     const rpc::PushTaskReply &reply,
                                                     const Status &) {});
  ASSERT_TRUE(status.ok());
  ASSERT_EQ(gcs_actor_manager_->GetActorIDByName("actor", "test").Binary(),
            request1.task_spec().actor_creation_task_spec().actor_id());

  auto actor = mock_actor_scheduler_->actors.back();
  mock_actor_scheduler_->actors.pop_back();

  // Check that the actor is in state `ALIVE`.
  auto address = RandomAddress();
  auto node_id = NodeID::FromBinary(address.node_id());
  auto worker_id = WorkerID::FromBinary(address.worker_id());
  actor->UpdateAddress(address);
  gcs_actor_manager_->OnActorCreationSuccess(actor, rpc::PushTaskReply());
  io_service_.run_one();

  // Remove worker and then check that the actor is dead. The actor should be
  // reconstructed.
  gcs_actor_manager_->OnWorkerDead(node_id, worker_id);
  ASSERT_EQ(actor->GetState(), rpc::ActorTableData::RESTARTING);

  // Create an actor with the same name.
  // It should fail because actor has been reconstructed, and names shouldn't have been
  // cleaned.
  const auto job_id_2 = JobID::FromInt(2);
  auto request2 = GenRegisterActorRequest(job_id_2,
                                          /*max_restarts=*/0,
                                          /*detached=*/true,
                                          /*name=*/"actor");
  status = gcs_actor_manager_->RegisterActor(request2, [](const Status &) {});
  io_service_.run_one();
  ASSERT_TRUE(status.IsAlreadyExists());
  ASSERT_EQ(gcs_actor_manager_->GetActorIDByName("actor", "test").Binary(),
            request1.task_spec().actor_creation_task_spec().actor_id());
}

TEST_F(GcsActorManagerTest, TestDestroyActorBeforeActorCreationCompletes) {
  auto job_id = JobID::FromInt(1);
  auto registered_actor = RegisterActor(job_id);
  rpc::CreateActorRequest create_actor_request;
  create_actor_request.mutable_task_spec()->CopyFrom(
      registered_actor->GetCreationTaskSpecification().GetMessage());

  std::vector<std::shared_ptr<gcs::GcsActor>> finished_actors;
  RAY_CHECK_OK(gcs_actor_manager_->CreateActor(
      create_actor_request,
      [&finished_actors](std::shared_ptr<gcs::GcsActor> result_actor,
                         const rpc::PushTaskReply &,
                         const Status &) {
        finished_actors.emplace_back(result_actor);
      }));

  ASSERT_EQ(finished_actors.size(), 0);
  ASSERT_EQ(mock_actor_scheduler_->actors.size(), 1);
  auto actor = mock_actor_scheduler_->actors.back();
  mock_actor_scheduler_->actors.clear();

  // Simulate the reply of WaitForActorRefDeleted request to trigger actor destruction.
  ASSERT_TRUE(worker_client_->Reply());

  // Check that the actor is in state `DEAD`.
  actor->UpdateAddress(RandomAddress());
  gcs_actor_manager_->OnActorCreationSuccess(actor, rpc::PushTaskReply());
  ASSERT_EQ(actor->GetState(), rpc::ActorTableData::DEAD);
  ASSERT_TRUE(actor->GetActorTableData().death_cause().has_actor_died_error_context());
  ASSERT_TRUE(absl::StrContains(
      actor->GetActorTableData().death_cause().actor_died_error_context().error_message(),
      "all references to the actor were removed"));
}

TEST_F(GcsActorManagerTest, TestRaceConditionCancelLease) {
  // Covers a scenario 1 in this PR https://github.com/ray-project/ray/pull/9215.
  auto job_id = JobID::FromInt(1);
  auto registered_actor = RegisterActor(job_id,
                                        /*max_restarts=*/1,
                                        /*detached=*/false);
  rpc::CreateActorRequest create_actor_request;
  create_actor_request.mutable_task_spec()->CopyFrom(
      registered_actor->GetCreationTaskSpecification().GetMessage());

  std::vector<std::shared_ptr<gcs::GcsActor>> finished_actors;
  RAY_CHECK_OK(gcs_actor_manager_->CreateActor(
      create_actor_request,
      [&finished_actors](std::shared_ptr<gcs::GcsActor> result_actor,
                         const rpc::PushTaskReply &,
                         const Status &) {
        finished_actors.emplace_back(result_actor);
      }));

  ASSERT_EQ(finished_actors.size(), 0);
  ASSERT_EQ(mock_actor_scheduler_->actors.size(), 1);
  auto actor = mock_actor_scheduler_->actors.back();
  mock_actor_scheduler_->actors.pop_back();
  const auto owner_node_id = actor->GetOwnerNodeID();
  const auto owner_worker_id = actor->GetOwnerID();

  // Check that the actor is in state `ALIVE`.
  rpc::Address address;
  auto node_id = NodeID::FromRandom();
  auto worker_id = WorkerID::FromRandom();
  address.set_node_id(node_id.Binary());
  address.set_worker_id(worker_id.Binary());
  actor->UpdateAddress(address);
  const auto &actor_id = actor->GetActorID();
  // LeaseID is randomly generated, so we can't check for a specific lease ID.
  EXPECT_CALL(*mock_actor_scheduler_, CancelOnLeasing(node_id, actor_id, _));
  gcs_actor_manager_->OnWorkerDead(owner_node_id, owner_worker_id);
  io_service_.run_one();
  ASSERT_TRUE(actor->GetActorTableData().death_cause().has_actor_died_error_context());
  ASSERT_TRUE(absl::StrContains(
      actor->GetActorTableData().death_cause().actor_died_error_context().error_message(),
      "owner has died."));
}

TEST_F(GcsActorManagerTest, TestRegisterActor) {
  auto job_id = JobID::FromInt(1);
  auto registered_actor = RegisterActor(job_id);
  // Make sure the actor state is `DEPENDENCIES_UNREADY`.
  ASSERT_EQ(registered_actor->GetState(), rpc::ActorTableData::DEPENDENCIES_UNREADY);
  // Make sure the actor has not been scheduled yet.
  ASSERT_TRUE(mock_actor_scheduler_->actors.empty());

  std::vector<std::shared_ptr<gcs::GcsActor>> finished_actors;
  rpc::CreateActorRequest request;
  request.mutable_task_spec()->CopyFrom(
      registered_actor->GetCreationTaskSpecification().GetMessage());
  RAY_CHECK_OK(gcs_actor_manager_->CreateActor(
      request,
      [&finished_actors](std::shared_ptr<gcs::GcsActor> result_actor,
                         const rpc::PushTaskReply &,
                         const Status &) {
        finished_actors.emplace_back(result_actor);
      }));
  // Make sure the actor is scheduling.
  ASSERT_EQ(mock_actor_scheduler_->actors.size(), 1);
  auto actor = mock_actor_scheduler_->actors.back();
  mock_actor_scheduler_->actors.pop_back();
  // Make sure the actor state is `PENDING`.
  ASSERT_EQ(actor->GetState(), rpc::ActorTableData::PENDING_CREATION);

  actor->UpdateAddress(RandomAddress());
  gcs_actor_manager_->OnActorCreationSuccess(actor, rpc::PushTaskReply());
  io_service_.run_one();
  ASSERT_EQ(actor->GetState(), rpc::ActorTableData::ALIVE);
}

TEST_F(GcsActorManagerTest, TestOwnerWorkerDieBeforeActorDependenciesResolved) {
  auto job_id = JobID::FromInt(1);
  auto registered_actor = RegisterActor(job_id);
  const auto &owner_address = registered_actor->GetOwnerAddress();
  auto node_id = NodeID::FromBinary(owner_address.node_id());
  auto worker_id = WorkerID::FromBinary(owner_address.worker_id());
  gcs_actor_manager_->OnWorkerDead(node_id, worker_id);
  io_service_.run_one();
  ASSERT_EQ(registered_actor->GetState(), rpc::ActorTableData::DEAD);
  ASSERT_TRUE(
      registered_actor->GetActorTableData().death_cause().has_actor_died_error_context());
  ASSERT_TRUE(absl::StrContains(registered_actor->GetActorTableData()
                                    .death_cause()
                                    .actor_died_error_context()
                                    .error_message(),
                                "owner has died."));

  // Make sure the actor gets cleaned up.
  const auto &registered_actors = gcs_actor_manager_->GetRegisteredActors();
  ASSERT_FALSE(registered_actors.count(registered_actor->GetActorID()));

  const auto &callbacks = GetActorRegisterCallbacks();
  ASSERT_FALSE(callbacks.count(registered_actor->GetActorID()));
  io_service_.run_one();
}

TEST_F(GcsActorManagerTest, TestOwnerWorkerDieBeforeDetachedActorDependenciesResolved) {
  auto job_id = JobID::FromInt(1);
  auto registered_actor = RegisterActor(job_id, /*max_restarts=*/1, /*detached=*/true);
  const auto &owner_address = registered_actor->GetOwnerAddress();
  auto node_id = NodeID::FromBinary(owner_address.node_id());
  auto worker_id = WorkerID::FromBinary(owner_address.worker_id());
  gcs_actor_manager_->OnWorkerDead(node_id, worker_id);
  io_service_.run_one();
  ASSERT_EQ(registered_actor->GetState(), rpc::ActorTableData::DEAD);
  ASSERT_TRUE(
      registered_actor->GetActorTableData().death_cause().has_actor_died_error_context());
  ASSERT_TRUE(absl::StrContains(registered_actor->GetActorTableData()
                                    .death_cause()
                                    .actor_died_error_context()
                                    .error_message(),
                                "owner has died."));

  // Make sure the actor gets cleaned up.
  const auto &registered_actors = gcs_actor_manager_->GetRegisteredActors();
  ASSERT_FALSE(registered_actors.count(registered_actor->GetActorID()));
  const auto &callbacks = GetActorRegisterCallbacks();
  ASSERT_FALSE(callbacks.count(registered_actor->GetActorID()));
  io_service_.run_one();
}

TEST_F(GcsActorManagerTest, TestOwnerNodeDieBeforeActorDependenciesResolved) {
  auto job_id = JobID::FromInt(1);
  auto registered_actor = RegisterActor(job_id);
  const auto &owner_address = registered_actor->GetOwnerAddress();
  auto node_id = NodeID::FromBinary(owner_address.node_id());
  OnNodeDead(node_id);
  ASSERT_EQ(registered_actor->GetState(), rpc::ActorTableData::DEAD);
  ASSERT_TRUE(
      registered_actor->GetActorTableData().death_cause().has_actor_died_error_context());
  ASSERT_TRUE(absl::StrContains(registered_actor->GetActorTableData()
                                    .death_cause()
                                    .actor_died_error_context()
                                    .error_message(),
                                "owner has died."));

  // Make sure the actor gets cleaned up.
  const auto &registered_actors = gcs_actor_manager_->GetRegisteredActors();
  ASSERT_FALSE(registered_actors.count(registered_actor->GetActorID()));
  const auto &callbacks = GetActorRegisterCallbacks();
  ASSERT_FALSE(callbacks.count(registered_actor->GetActorID()));
}

TEST_F(GcsActorManagerTest, TestOwnerNodeDieBeforeDetachedActorDependenciesResolved) {
  auto job_id = JobID::FromInt(1);
  auto registered_actor = RegisterActor(job_id, /*max_restarts=*/1, /*detached=*/true);
  const auto &owner_address = registered_actor->GetOwnerAddress();
  auto node_id = NodeID::FromBinary(owner_address.node_id());
  OnNodeDead(node_id);
  ASSERT_EQ(registered_actor->GetState(), rpc::ActorTableData::DEAD);
  ASSERT_TRUE(
      registered_actor->GetActorTableData().death_cause().has_actor_died_error_context());
  ASSERT_TRUE(absl::StrContains(registered_actor->GetActorTableData()
                                    .death_cause()
                                    .actor_died_error_context()
                                    .error_message(),
                                "owner has died."));

  // Make sure the actor gets cleaned up.
  const auto &registered_actors = gcs_actor_manager_->GetRegisteredActors();
  ASSERT_FALSE(registered_actors.count(registered_actor->GetActorID()));
  const auto &callbacks = GetActorRegisterCallbacks();
  ASSERT_FALSE(callbacks.count(registered_actor->GetActorID()));
}

TEST_F(GcsActorManagerTest, TestOwnerAndChildDiedAtTheSameTimeRaceCondition) {
  // When owner and child die at the same time,
  auto job_id = JobID::FromInt(1);
  auto registered_actor = RegisterActor(job_id,
                                        /*max_restarts=*/1,
                                        /*detached=*/false);
  rpc::CreateActorRequest create_actor_request;
  create_actor_request.mutable_task_spec()->CopyFrom(
      registered_actor->GetCreationTaskSpecification().GetMessage());

  std::vector<std::shared_ptr<gcs::GcsActor>> finished_actors;
  RAY_CHECK_OK(gcs_actor_manager_->CreateActor(
      create_actor_request,
      [&finished_actors](std::shared_ptr<gcs::GcsActor> result_actor,
                         const rpc::PushTaskReply &,
                         const Status &) {
        finished_actors.emplace_back(result_actor);
      }));
  auto actor = mock_actor_scheduler_->actors.back();
  mock_actor_scheduler_->actors.pop_back();

  auto address = RandomAddress();
  actor->UpdateAddress(address);
  gcs_actor_manager_->OnActorCreationSuccess(actor, rpc::PushTaskReply());
  io_service_.run_one();
  ASSERT_EQ(finished_actors.size(), 1);

  const auto owner_node_id = actor->GetOwnerNodeID();
  const auto owner_worker_id = actor->GetOwnerID();
  const auto child_node_id = actor->GetNodeID();
  const auto child_worker_id = actor->GetWorkerID();
  const auto actor_id = actor->GetActorID();
  // Make worker & owner fail at the same time, but owner's failure comes first.
  gcs_actor_manager_->OnWorkerDead(owner_node_id, owner_worker_id);
  EXPECT_CALL(*mock_actor_scheduler_, CancelOnWorker(child_node_id, child_worker_id))
      .WillOnce(Return(actor_id));
  gcs_actor_manager_->OnWorkerDead(child_node_id, child_worker_id);
  io_service_.run_one();
}

TEST_F(GcsActorManagerTest, TestRayNamespace) {
  auto job_id_1 = JobID::FromInt(1);
  auto job_id_2 = JobID::FromInt(20);
  auto job_id_3 = JobID::FromInt(3);
  std::string second_namespace = "another_namespace";
  job_namespace_table_[job_id_2] = second_namespace;

  auto request1 = GenRegisterActorRequest(job_id_1,
                                          /*max_restarts=*/0,
                                          /*detached=*/true,
                                          /*name=*/"actor");
  Status status = gcs_actor_manager_->RegisterActor(request1, [](const Status &) {});
  ASSERT_TRUE(status.ok());
  ASSERT_EQ(gcs_actor_manager_->GetActorIDByName("actor", "test").Binary(),
            request1.task_spec().actor_creation_task_spec().actor_id());
  io_service_.run_one();

  auto request2 = GenRegisterActorRequest(job_id_2,
                                          /*max_restarts=*/0,
                                          /*detached=*/true,
                                          /*name=*/"actor",
                                          second_namespace);
  // Create a second actor of the same name. Its job id belongs to a different
  // namespace though.
  status = gcs_actor_manager_->RegisterActor(request2, [](const Status &) {});
  ASSERT_TRUE(status.ok());
  ASSERT_EQ(gcs_actor_manager_->GetActorIDByName("actor", second_namespace).Binary(),
            request2.task_spec().actor_creation_task_spec().actor_id());
  // The actors may have the same name, but their ids are different.
  ASSERT_NE(gcs_actor_manager_->GetActorIDByName("actor", second_namespace).Binary(),
            request1.task_spec().actor_creation_task_spec().actor_id());
  io_service_.run_one();

  auto request3 = GenRegisterActorRequest(job_id_3,
                                          /*max_restarts=*/0,
                                          /*detached=*/true,
                                          /*name=*/"actor",
                                          /*ray_namespace=*/"test");
  status = gcs_actor_manager_->RegisterActor(request3, [](const Status &) {});
  ASSERT_TRUE(status.IsAlreadyExists());
  ASSERT_EQ(gcs_actor_manager_->GetActorIDByName("actor", "test").Binary(),
            request1.task_spec().actor_creation_task_spec().actor_id());
  io_service_.run_one();
}

TEST_F(GcsActorManagerTest, TestReuseActorNameInNamespace) {
  std::string actor_name = "actor";
  std::string ray_namespace = "actor_namespace";

  auto job_id_1 = JobID::FromInt(1);
  auto request_1 = GenRegisterActorRequest(job_id_1, 0, true, actor_name, ray_namespace);
  auto actor_id_1 =
      ActorID::FromBinary(request_1.task_spec().actor_creation_task_spec().actor_id());
  Status status = gcs_actor_manager_->RegisterActor(request_1, [](const Status &) {});
  ASSERT_TRUE(status.ok());
  ASSERT_EQ(gcs_actor_manager_->GetActorIDByName(actor_name, ray_namespace).Binary(),
            actor_id_1.Binary());
  io_service_.run_one();

  auto owner_address = request_1.task_spec().caller_address();
  auto node_info = std::make_shared<rpc::GcsNodeInfo>();
  node_info->set_node_id(owner_address.node_id());
  gcs_actor_manager_->OnNodeDead(node_info, "");
  ASSERT_EQ(gcs_actor_manager_->GetActorIDByName(actor_name, ray_namespace).Binary(),
            ActorID::Nil().Binary());
  io_service_.run_one();

  auto job_id_2 = JobID::FromInt(2);
  auto request_2 = GenRegisterActorRequest(job_id_2, 0, true, actor_name, ray_namespace);
  auto actor_id_2 =
      ActorID::FromBinary(request_2.task_spec().actor_creation_task_spec().actor_id());
  status = gcs_actor_manager_->RegisterActor(request_2, [](const Status &) {});
  ASSERT_TRUE(status.ok());
  ASSERT_EQ(gcs_actor_manager_->GetActorIDByName(actor_name, ray_namespace).Binary(),
            actor_id_2.Binary());
  io_service_.run_one();
}

TEST_F(GcsActorManagerTest, TestGetAllActorInfoFilters) {
  google::protobuf::Arena arena;
  // The target filter actor.
  auto job_id = JobID::FromInt(1);
  auto registered_actor = RegisterActor(job_id);
  rpc::CreateActorRequest create_actor_request;
  create_actor_request.mutable_task_spec()->CopyFrom(
      registered_actor->GetCreationTaskSpecification().GetMessage());
  std::vector<std::shared_ptr<gcs::GcsActor>> finished_actors;
  Status create_status = gcs_actor_manager_->CreateActor(
      create_actor_request,
      [&finished_actors](const std::shared_ptr<gcs::GcsActor> &result_actor,
                         const rpc::PushTaskReply &,
                         const Status &) { finished_actors.emplace_back(result_actor); });

  ASSERT_TRUE(create_status.ok());
  auto actor = mock_actor_scheduler_->actors.back();
  mock_actor_scheduler_->actors.pop_back();

  // Check that the actor is in state `ALIVE`.
  actor->UpdateAddress(RandomAddress());
  gcs_actor_manager_->OnActorCreationSuccess(actor, rpc::PushTaskReply());
  io_service_.run_one();
  ASSERT_EQ(gcs_actor_manager_->CountFor(rpc::ActorTableData::ALIVE, ""), 1);
  ASSERT_EQ(actor->GetState(), rpc::ActorTableData::ALIVE);

  // Just register some other actors.
  auto job_id_other = JobID::FromInt(2);
  auto num_other_actors = 3;
  for (int i = 0; i < num_other_actors; i++) {
    auto request1 = GenRegisterActorRequest(job_id_other,
                                            /*max_restarts=*/0,
                                            /*detached=*/false);
    Status register_status =
        gcs_actor_manager_->RegisterActor(request1, [](const Status &) {});
    ASSERT_TRUE(register_status.ok());
    io_service_.run_one();
  }

  auto callback = [](Status, std::function<void()>, std::function<void()>) {};
  // Filter with actor id
  {
    rpc::GetAllActorInfoRequest request;
    request.mutable_filters()->set_actor_id(actor->GetActorID().Binary());

    auto &reply =
        *google::protobuf::Arena::CreateMessage<rpc::GetAllActorInfoReply>(&arena);
    gcs_actor_manager_->HandleGetAllActorInfo(request, &reply, callback);
    ASSERT_EQ(reply.actor_table_data().size(), 1);
    ASSERT_EQ(reply.total(), 1 + num_other_actors);
    ASSERT_EQ(reply.num_filtered(), num_other_actors);
  }

  // Filter with job id
  {
    rpc::GetAllActorInfoRequest request;
    request.mutable_filters()->set_job_id(job_id.Binary());

    auto &reply =
        *google::protobuf::Arena::CreateMessage<rpc::GetAllActorInfoReply>(&arena);
    gcs_actor_manager_->HandleGetAllActorInfo(request, &reply, callback);
    ASSERT_EQ(reply.actor_table_data().size(), 1);
    ASSERT_EQ(reply.num_filtered(), num_other_actors);
  }

  // Filter with states
  {
    rpc::GetAllActorInfoRequest request;
    request.mutable_filters()->set_state(rpc::ActorTableData::ALIVE);

    auto &reply =
        *google::protobuf::Arena::CreateMessage<rpc::GetAllActorInfoReply>(&arena);
    gcs_actor_manager_->HandleGetAllActorInfo(request, &reply, callback);
    ASSERT_EQ(reply.actor_table_data().size(), 1);
    ASSERT_EQ(reply.num_filtered(), num_other_actors);
  }

  // Simple test AND
  {
    rpc::GetAllActorInfoRequest request;
    request.mutable_filters()->set_state(rpc::ActorTableData::ALIVE);
    request.mutable_filters()->set_job_id(job_id.Binary());

    auto &reply =
        *google::protobuf::Arena::CreateMessage<rpc::GetAllActorInfoReply>(&arena);
    gcs_actor_manager_->HandleGetAllActorInfo(request, &reply, callback);
    ASSERT_EQ(reply.actor_table_data().size(), 1);
    ASSERT_EQ(reply.num_filtered(), num_other_actors);
  }
  {
    rpc::GetAllActorInfoRequest request;
    request.mutable_filters()->set_state(rpc::ActorTableData::DEAD);
    request.mutable_filters()->set_job_id(job_id.Binary());

    auto &reply =
        *google::protobuf::Arena::CreateMessage<rpc::GetAllActorInfoReply>(&arena);
    gcs_actor_manager_->HandleGetAllActorInfo(request, &reply, callback);
    ASSERT_EQ(reply.num_filtered(), num_other_actors + 1);
    ASSERT_EQ(reply.actor_table_data().size(), 0);
  }
}

TEST_F(GcsActorManagerTest, TestGetAllActorInfoLimit) {
  google::protobuf::Arena arena;
  auto job_id_1 = JobID::FromInt(1);
  auto num_actors = 3;
  for (int i = 0; i < num_actors; i++) {
    auto request1 = GenRegisterActorRequest(job_id_1,
                                            /*max_restarts=*/0,
                                            /*detached=*/false);
    Status status = gcs_actor_manager_->RegisterActor(request1, [](const Status &) {});
    ASSERT_TRUE(status.ok());
    io_service_.run_one();
  }

  {
    rpc::GetAllActorInfoRequest request;
    auto &reply =
        *google::protobuf::Arena::CreateMessage<rpc::GetAllActorInfoReply>(&arena);
    auto callback = [](Status, std::function<void()>, std::function<void()>) {};
    gcs_actor_manager_->HandleGetAllActorInfo(request, &reply, callback);
    ASSERT_EQ(reply.actor_table_data().size(), 3);

    request.set_limit(2);
    auto &reply_2 =
        *google::protobuf::Arena::CreateMessage<rpc::GetAllActorInfoReply>(&arena);
    gcs_actor_manager_->HandleGetAllActorInfo(request, &reply_2, callback);
    ASSERT_EQ(reply_2.actor_table_data().size(), 2);
    ASSERT_EQ(reply_2.total(), 3);
  }
}

TEST_F(GcsActorManagerTest, TestKillActorWhenActorIsCreating) {
  auto job_id = JobID::FromInt(1);
  auto registered_actor = RegisterActor(job_id, /*max_restarts*/ -1);
  rpc::CreateActorRequest create_actor_request;
  create_actor_request.mutable_task_spec()->CopyFrom(
      registered_actor->GetCreationTaskSpecification().GetMessage());

  std::vector<std::shared_ptr<gcs::GcsActor>> finished_actors;
  Status status = gcs_actor_manager_->CreateActor(
      create_actor_request,
      [&finished_actors](const std::shared_ptr<gcs::GcsActor> &result_actor,
                         const rpc::PushTaskReply &,
                         const Status &) { finished_actors.emplace_back(result_actor); });
  RAY_CHECK_OK(status);

  ASSERT_EQ(finished_actors.size(), 0);
  ASSERT_EQ(mock_actor_scheduler_->actors.size(), 1);
  auto actor = mock_actor_scheduler_->actors.back();
  mock_actor_scheduler_->actors.pop_back();

  // Make sure actor in the phase of creating, that is the worker id is not nil and the
  // actor state is not alive yet.
  actor->UpdateAddress(RandomAddress());
  actor->UpdateLocalRayletAddress(RandomAddress());
  const auto &worker_id = actor->GetWorkerID();
  ASSERT_TRUE(!worker_id.IsNil());
  const auto &local_raylet_address = actor->LocalRayletAddress();
  ASSERT_TRUE(local_raylet_address.has_value());
  ASSERT_NE(actor->GetState(), rpc::ActorTableData::ALIVE);

  // Then handle the kill actor requst (restart).
  rpc::KillActorViaGcsReply reply;
  rpc::KillActorViaGcsRequest request;
  request.set_actor_id(actor->GetActorID().Binary());
  request.set_force_kill(true);
  // Set the `no_restart` flag to true so that the actor will restart again.
  request.set_no_restart(false);
  gcs_actor_manager_->HandleKillActorViaGcs(
      request,
      &reply,
      /*send_reply_callback*/
      [](Status, std::function<void()>, std::function<void()>) {});
  io_service_.run_one();

  // Make sure the `KillLocalActor` rpc is sent.
  ASSERT_EQ(raylet_client_->killed_actors.size(), 1);
  ASSERT_EQ(raylet_client_->killed_actors.front(), actor->GetActorID());

  // Make sure the actor is restarting.
  ASSERT_EQ(actor->GetState(), rpc::ActorTableData::RESTARTING);
}

TEST_F(GcsActorManagerTest, TestRestartActorForLineageReconstruction) {
  RayConfig::instance().initialize(
      R"(
{
  "maximum_gcs_destroyed_actor_cached_count": 10,
  "enable_ray_event": true
}
  )");
  auto job_id = JobID::FromInt(1);
  auto registered_actor = RegisterActor(job_id, /*max_restarts*/ -1);
  rpc::CreateActorRequest create_actor_request;
  create_actor_request.mutable_task_spec()->CopyFrom(
      registered_actor->GetCreationTaskSpecification().GetMessage());

  std::vector<std::shared_ptr<gcs::GcsActor>> created_actors;
  RAY_CHECK_OK(gcs_actor_manager_->CreateActor(
      create_actor_request,
      [&created_actors](std::shared_ptr<gcs::GcsActor> result_actor,
                        const rpc::PushTaskReply &,
                        const Status &) { created_actors.emplace_back(result_actor); }));

  ASSERT_EQ(created_actors.size(), 0);
  ASSERT_EQ(mock_actor_scheduler_->actors.size(), 1);
  auto actor = mock_actor_scheduler_->actors.back();
  mock_actor_scheduler_->actors.pop_back();

  // Check that the actor is in state `ALIVE`.
  auto address = RandomAddress();
  auto node_id = NodeID::FromBinary(address.node_id());
  actor->UpdateAddress(address);
  gcs_actor_manager_->OnActorCreationSuccess(actor, rpc::PushTaskReply());
  io_service_.run_one();
  ASSERT_EQ(created_actors.size(), 1);
  ASSERT_EQ(actor->GetState(), rpc::ActorTableData::ALIVE);

  // Remove node and then check that the actor is being restarted.
  EXPECT_CALL(*mock_actor_scheduler_, CancelOnNode(node_id));
  OnNodeDead(node_id);
  ASSERT_EQ(actor->GetState(), rpc::ActorTableData::RESTARTING);
  fake_ray_event_recorder_->FlushBuffer();

  // Add node and check that the actor is restarted.
  ASSERT_EQ(mock_actor_scheduler_->actors.size(), 1);
  mock_actor_scheduler_->actors.clear();
  ASSERT_EQ(created_actors.size(), 1);
  auto node_id2 = NodeID::FromRandom();
  address.set_node_id(node_id2.Binary());
  actor->UpdateAddress(address);
  gcs_actor_manager_->OnActorCreationSuccess(actor, rpc::PushTaskReply());
  io_service_.run_one();
  io_service_.run_one();
  io_service_.run_one();
  ASSERT_EQ(created_actors.size(), 1);
  ASSERT_EQ(actor->GetState(), rpc::ActorTableData::ALIVE);
  ASSERT_EQ(actor->GetNodeID(), node_id2);
  ASSERT_EQ(actor->GetActorTableData().num_restarts(), 1);
  ASSERT_EQ(actor->GetActorTableData().num_restarts_due_to_lineage_reconstruction(), 0);
  ASSERT_EQ(actor->GetMutableTaskSpec()->attempt_number(), 1);
  gcs_table_storage_->ActorTable().Get(
      actor->GetActorID(),
      {[](Status, std::optional<rpc::ActorTableData> actor_table_data) {
         ASSERT_EQ(actor_table_data->state(), rpc::ActorTableData::ALIVE);
       },
       io_service_});
  io_service_.run_one();
  gcs_table_storage_->ActorTable().Get(
      actor->GetActorID(),
      {[](Status, std::optional<rpc::ActorTableData> actor_table_data) {
         ASSERT_EQ(actor_table_data->num_restarts(), 1);
       },
       io_service_});
  io_service_.run_one();
  gcs_table_storage_->ActorTable().Get(
      actor->GetActorID(),
      {[](Status, std::optional<rpc::ActorTableData> actor_table_data) {
         ASSERT_EQ(actor_table_data->num_restarts_due_to_lineage_reconstruction(), 0);
       },
       io_service_});
  io_service_.run_one();
  gcs_table_storage_->ActorTaskSpecTable().Get(
      actor->GetActorID(),
      {[](Status, std::optional<rpc::TaskSpec> task_spec) {
         ASSERT_EQ(task_spec->attempt_number(), 1);
       },
       io_service_});
  io_service_.run_one();

  // The actor is out of scope and dead.
  ReportActorOutOfScope(actor->GetActorID(),
                        /*num_restarts_due_to_lineage_reconstruction=*/0);
  ASSERT_EQ(actor->GetState(), rpc::ActorTableData::DEAD);
  fake_ray_event_recorder_->FlushBuffer();

  // Restart the actor due to linage reconstruction.
  rpc::RestartActorForLineageReconstructionRequest request;
  request.set_actor_id(actor->GetActorID().Binary());
  request.set_num_restarts_due_to_lineage_reconstruction(
      /*num_restarts_due_to_lineage_reconstruction=*/1);
  rpc::RestartActorForLineageReconstructionReply reply;
  gcs_actor_manager_->HandleRestartActorForLineageReconstruction(
      request, &reply, [](auto, auto, auto) {});
  io_service_.run_one();
  io_service_.run_one();
  ASSERT_EQ(actor->GetState(), rpc::ActorTableData::RESTARTING);
  auto events = fake_ray_event_recorder_->FlushBuffer();
  bool found_lineage_restart_event = false;
  for (auto &event : events) {
    if (event->GetEventType() != rpc::events::RayEvent::ACTOR_LIFECYCLE_EVENT) {
      continue;
    }
    auto ray_event = std::move(*event).Serialize().value();
    const auto &lifecycle_event = ray_event.actor_lifecycle_event();
    if (lifecycle_event.state_transitions_size() == 0) {
      continue;
    }
    const auto &transition = lifecycle_event.state_transitions(0);
    if (transition.state() == rpc::events::ActorLifecycleEvent::RESTARTING) {
      ASSERT_EQ(transition.restart_reason(),
                rpc::events::ActorLifecycleEvent::LINEAGE_RECONSTRUCTION);
      found_lineage_restart_event = true;
      break;
    }
  }
  ASSERT_TRUE(found_lineage_restart_event);

  // Add node and check that the actor is restarted.
  ASSERT_EQ(mock_actor_scheduler_->actors.size(), 1);
  mock_actor_scheduler_->actors.clear();
  ASSERT_EQ(created_actors.size(), 1);
  auto node_id3 = NodeID::FromRandom();
  address.set_node_id(node_id3.Binary());
  actor->UpdateAddress(address);
  gcs_actor_manager_->OnActorCreationSuccess(actor, rpc::PushTaskReply());
  io_service_.run_one();
  ASSERT_EQ(created_actors.size(), 1);
  ASSERT_EQ(actor->GetState(), rpc::ActorTableData::ALIVE);
  ASSERT_EQ(actor->GetNodeID(), node_id3);
  ASSERT_EQ(actor->GetActorTableData().num_restarts(), 2);
  ASSERT_EQ(actor->GetActorTableData().num_restarts_due_to_lineage_reconstruction(), 1);
  gcs_table_storage_->ActorTable().Get(
      actor->GetActorID(),
      {[](Status, std::optional<rpc::ActorTableData> actor_table_data) {
         ASSERT_EQ(actor_table_data->state(), rpc::ActorTableData::ALIVE);
       },
       io_service_});
  io_service_.run_one();
  gcs_table_storage_->ActorTable().Get(
      actor->GetActorID(),
      {[](Status, std::optional<rpc::ActorTableData> actor_table_data) {
         ASSERT_EQ(actor_table_data->num_restarts(), 2);
       },
       io_service_});
  io_service_.run_one();
  gcs_table_storage_->ActorTable().Get(
      actor->GetActorID(),
      {[](Status, std::optional<rpc::ActorTableData> actor_table_data) {
         ASSERT_EQ(actor_table_data->num_restarts_due_to_lineage_reconstruction(), 1);
       },
       io_service_});
  io_service_.run_one();
  gcs_table_storage_->ActorTaskSpecTable().Get(
      actor->GetActorID(),
      {[](Status, std::optional<rpc::TaskSpec> task_spec) {
         ASSERT_EQ(task_spec->attempt_number(), 2);
       },
       io_service_});
  io_service_.run_one();
}

TEST_F(GcsActorManagerTest, TestRestartPermanentlyDeadActorForLineageReconstruction) {
  auto job_id = JobID::FromInt(1);
  auto registered_actor = RegisterActor(job_id, /*max_restarts*/ 0);
  rpc::CreateActorRequest create_actor_request;
  create_actor_request.mutable_task_spec()->CopyFrom(
      registered_actor->GetCreationTaskSpecification().GetMessage());

  std::vector<std::shared_ptr<gcs::GcsActor>> created_actors;
  RAY_CHECK_OK(gcs_actor_manager_->CreateActor(
      create_actor_request,
      [&created_actors](std::shared_ptr<gcs::GcsActor> result_actor,
                        const rpc::PushTaskReply &,
                        const Status &) { created_actors.emplace_back(result_actor); }));

  ASSERT_EQ(created_actors.size(), 0);
  ASSERT_EQ(mock_actor_scheduler_->actors.size(), 1);
  auto actor = mock_actor_scheduler_->actors.back();
  mock_actor_scheduler_->actors.pop_back();

  // Check that the actor is in state `ALIVE`.
  auto address = RandomAddress();
  actor->UpdateAddress(address);
  gcs_actor_manager_->OnActorCreationSuccess(actor, rpc::PushTaskReply());
  io_service_.run_one();
  ASSERT_EQ(created_actors.size(), 1);
  ASSERT_EQ(actor->GetState(), rpc::ActorTableData::ALIVE);

  // Remove owner node and then check that the actor is dead.
  const auto owner_node_id = actor->GetOwnerNodeID();
  EXPECT_CALL(*mock_actor_scheduler_, CancelOnNode(owner_node_id));
  OnNodeDead(owner_node_id);
  ASSERT_EQ(actor->GetState(), rpc::ActorTableData::DEAD);

  // Restart on an invalid or permanently dead actor should fail.
  rpc::RestartActorForLineageReconstructionRequest request;
  request.set_actor_id(
      ActorID::Of(actor->GetActorID().JobId(), RandomTaskId(), 0).Binary());
  request.set_num_restarts_due_to_lineage_reconstruction(
      /*num_restarts_due_to_lineage_reconstruction=*/0);
  rpc::RestartActorForLineageReconstructionReply reply;
  gcs_actor_manager_->HandleRestartActorForLineageReconstruction(
      request, &reply, [](auto, auto, auto) {});
  io_service_.run_one();
  io_service_.run_one();
  ASSERT_EQ(reply.status().code(), static_cast<int>(StatusCode::Invalid));

  rpc::RestartActorForLineageReconstructionRequest request2;
  request2.set_actor_id(actor->GetActorID().Binary());
  request2.set_num_restarts_due_to_lineage_reconstruction(
      /*num_restarts_due_to_lineage_reconstruction=*/0);
  rpc::RestartActorForLineageReconstructionReply reply2;
  gcs_actor_manager_->HandleRestartActorForLineageReconstruction(
      request2, &reply2, [](auto, auto, auto) {});
  ASSERT_EQ(reply2.status().code(), static_cast<int>(StatusCode::Invalid));
}

TEST_F(GcsActorManagerTest, TestIdempotencyOfRestartActorForLineageReconstruction) {
  auto job_id = JobID::FromInt(1);
  auto registered_actor = RegisterActor(job_id, /*max_restarts*/ -1);
  rpc::CreateActorRequest create_actor_request;
  create_actor_request.mutable_task_spec()->CopyFrom(
      registered_actor->GetCreationTaskSpecification().GetMessage());

  std::vector<std::shared_ptr<gcs::GcsActor>> created_actors;
  RAY_CHECK_OK(gcs_actor_manager_->CreateActor(
      create_actor_request,
      [&created_actors](std::shared_ptr<gcs::GcsActor> result_actor,
                        const rpc::PushTaskReply &,
                        const Status &) { created_actors.emplace_back(result_actor); }));

  ASSERT_EQ(created_actors.size(), 0);
  ASSERT_EQ(mock_actor_scheduler_->actors.size(), 1);
  auto actor = mock_actor_scheduler_->actors.back();
  mock_actor_scheduler_->actors.pop_back();

  // Check that the actor is in state `ALIVE`.
  auto address = RandomAddress();
  actor->UpdateAddress(address);
  gcs_actor_manager_->OnActorCreationSuccess(actor, rpc::PushTaskReply());
  io_service_.run_one();
  ASSERT_EQ(created_actors.size(), 1);

  // The actor is out of scope and dead.
  ReportActorOutOfScope(actor->GetActorID(),
                        /*num_restarts_due_to_lineage_reconstruction=*/0);
  ASSERT_EQ(actor->GetState(), rpc::ActorTableData::DEAD);

  // Test the case where the RestartActorForLineageReconstruction rpc is received and
  // being handled and then the connection is lost and the caller resends the same
  // request. The second RestartActorForLineageReconstruction rpc should be deduplicated
  // and not be handled again, instead it should be replied with the same reply as the
  // first one.
  rpc::RestartActorForLineageReconstructionRequest request;
  request.set_actor_id(actor->GetActorID().Binary());
  request.set_num_restarts_due_to_lineage_reconstruction(1);
  rpc::RestartActorForLineageReconstructionReply reply1;
  rpc::RestartActorForLineageReconstructionReply reply2;

  gcs_actor_manager_->HandleRestartActorForLineageReconstruction(
      request, &reply1, [&reply1](Status, std::function<void()>, std::function<void()>) {
        ASSERT_EQ(reply1.status().code(), static_cast<int>(StatusCode::OK));
      });
  gcs_actor_manager_->HandleRestartActorForLineageReconstruction(
      request, &reply2, [&reply2](Status, std::function<void()>, std::function<void()>) {
        ASSERT_EQ(reply2.status().code(), static_cast<int>(StatusCode::OK));
      });
  io_service_.run_one();
  ASSERT_EQ(actor->GetState(), rpc::ActorTableData::RESTARTING);

  // Add node and check that the actor is restarted.
  ASSERT_EQ(mock_actor_scheduler_->actors.size(), 1);
  mock_actor_scheduler_->actors.clear();
  ASSERT_EQ(created_actors.size(), 1);
  auto node_id = NodeID::FromRandom();
  address.set_node_id(node_id.Binary());
  actor->UpdateAddress(address);
  gcs_actor_manager_->OnActorCreationSuccess(actor, rpc::PushTaskReply());
  io_service_.run_one();
  ASSERT_EQ(created_actors.size(), 1);
  ASSERT_EQ(actor->GetState(), rpc::ActorTableData::ALIVE);
  ASSERT_EQ(actor->GetNodeID(), node_id);
  // Two duplicate RestartActorForLineageReconstruction rpcs should only trigger the
  // restart once.
  ASSERT_EQ(actor->GetActorTableData().num_restarts(), 1);
  ASSERT_EQ(actor->GetActorTableData().num_restarts_due_to_lineage_reconstruction(), 1);

  // Test the case where the RestartActorForLineageReconstruction rpc is replied but the
  // reply is lost and the caller resends the same request. The second
  // RestartActorForLineageReconstruction rpc should be directly replied without
  // triggering another restart of the actor.
  rpc::RestartActorForLineageReconstructionRequest request3;
  request3.set_actor_id(actor->GetActorID().Binary());
  request3.set_num_restarts_due_to_lineage_reconstruction(1);
  rpc::RestartActorForLineageReconstructionReply reply3;
  gcs_actor_manager_->HandleRestartActorForLineageReconstruction(
      request3, &reply3, [](auto, auto, auto) {});
  ASSERT_EQ(reply3.status().code(), static_cast<int>(StatusCode::OK));
  // Make sure the actor is not restarted again.
  ASSERT_EQ(actor->GetState(), rpc::ActorTableData::ALIVE);
  ASSERT_EQ(actor->GetActorTableData().num_restarts(), 1);
  ASSERT_EQ(actor->GetActorTableData().num_restarts_due_to_lineage_reconstruction(), 1);
}

TEST_F(GcsActorManagerTest, TestDestroyActorWhenActorIsCreating) {
  auto job_id = JobID::FromInt(1);
  auto registered_actor = RegisterActor(job_id, /*max_restarts*/ -1);
  rpc::CreateActorRequest create_actor_request;
  create_actor_request.mutable_task_spec()->CopyFrom(
      registered_actor->GetCreationTaskSpecification().GetMessage());

  std::vector<std::shared_ptr<gcs::GcsActor>> finished_actors;
  Status status = gcs_actor_manager_->CreateActor(
      create_actor_request,
      [&finished_actors](const std::shared_ptr<gcs::GcsActor> &result_actor,
                         const rpc::PushTaskReply &,
                         const Status &) { finished_actors.emplace_back(result_actor); });
  RAY_CHECK_OK(status);

  ASSERT_EQ(finished_actors.size(), 0);
  ASSERT_EQ(mock_actor_scheduler_->actors.size(), 1);
  auto actor = mock_actor_scheduler_->actors.back();
  mock_actor_scheduler_->actors.pop_back();

  // Make sure actor in the phase of creating, that is the worker id is not nil and the
  // actor state is not alive yet.
  actor->UpdateAddress(RandomAddress());
  actor->UpdateLocalRayletAddress(RandomAddress());
  const auto &worker_id = actor->GetWorkerID();
  ASSERT_TRUE(!worker_id.IsNil());
  const auto &local_raylet_address = actor->LocalRayletAddress();
  ASSERT_TRUE(local_raylet_address.has_value());
  ASSERT_NE(actor->GetState(), rpc::ActorTableData::ALIVE);

  // Then handle the kill actor requst (no restart).
  rpc::KillActorViaGcsReply reply;
  rpc::KillActorViaGcsRequest request;
  request.set_actor_id(actor->GetActorID().Binary());
  request.set_force_kill(true);
  // Set the `no_restart` flag to true so that the actor will be destoryed.
  request.set_no_restart(true);
  gcs_actor_manager_->HandleKillActorViaGcs(
      request,
      &reply,
      /*send_reply_callback*/
      [](Status, std::function<void()>, std::function<void()>) {});
  io_service_.run_one();
  io_service_.run_one();

  // Make sure the `KillLocalActor` rpc is sent.
  ASSERT_EQ(raylet_client_->killed_actors.size(), 1);
  ASSERT_EQ(raylet_client_->killed_actors.front(), actor->GetActorID());

  // Make sure the actor is dead.
  ASSERT_EQ(actor->GetState(), rpc::ActorTableData::DEAD);
}

TEST_F(GcsActorManagerTest, TestDestroyWhileRegistering) {
  // Register comes in -> Kill comes in -> Run all kv operations and callbacks
  auto register_request = GenRegisterActorRequest(
      JobID::FromInt(1), /*max_restarts=*/0, /*detached=*/false, "", "test");
  rpc::RegisterActorReply register_reply;
  gcs_actor_manager_->HandleRegisterActor(
      register_request, &register_reply, [](auto, auto, auto) {});
  rpc::KillActorViaGcsRequest kill_request;
  kill_request.set_actor_id(
      register_request.task_spec().actor_creation_task_spec().actor_id());
  kill_request.set_force_kill(false);
  kill_request.set_no_restart(true);
  rpc::KillActorViaGcsReply kill_reply;
  gcs_actor_manager_->HandleKillActorViaGcs(
      kill_request, &kill_reply, [](auto, auto, auto) {});
  // Run all kv operations and callbacks
  for (int i = 0; i < 5; i++) {
    io_service_.run_one();
  }
  ASSERT_EQ(register_reply.status().code(),
            static_cast<int>(StatusCode::SchedulingCancelled));
  ASSERT_EQ(kill_reply.status().code(), static_cast<int>(StatusCode::OK));
  ASSERT_EQ(raylet_client_->killed_actors.size(), 0);
  ASSERT_TRUE(gcs_actor_manager_->GetRegisteredActors().empty());
}

TEST_F(GcsActorManagerTest, TestNodeFailureDestroysAllOwnedActors) {
  JobID job_id = JobID::FromInt(1);

  // Create a shared owner
  rpc::Address owner_address;
  NodeID owner_node_id = NodeID::FromRandom();
  WorkerID owner_worker_id = WorkerID::FromRandom();
  owner_address.set_node_id(owner_node_id.Binary());
  owner_address.set_ip_address("1234");
  owner_address.set_port(5678);
  owner_address.set_worker_id(owner_worker_id.Binary());

  // Register 3 actors all owned by the same worker (non-detached)
  std::vector<std::shared_ptr<gcs::GcsActor>> actors;
  for (int i = 0; i < 3; i++) {
    TaskSpecification actor_creation_task_spec =
        GenActorCreationTask(job_id,
                             /*max_restarts=*/0,
                             /*detached=*/false,
                             /*name=*/"",
                             /*ray_namespace=*/"test",
                             owner_address);
    rpc::RegisterActorRequest register_request;
    register_request.mutable_task_spec()->CopyFrom(actor_creation_task_spec.GetMessage());

    Status status =
        gcs_actor_manager_->RegisterActor(register_request, [](const Status &) {});
    ASSERT_TRUE(status.ok()) << status.ToString();
    drain_io_context();

    ActorID actor_id = ActorID::FromBinary(
        register_request.task_spec().actor_creation_task_spec().actor_id());
    ASSERT_TRUE(gcs_actor_manager_->registered_actors_.contains(actor_id));
    std::shared_ptr<gcs::GcsActor> actor =
        gcs_actor_manager_->registered_actors_[actor_id];

    rpc::CreateActorRequest create_request;
    create_request.mutable_task_spec()->CopyFrom(actor_creation_task_spec.GetMessage());
    RAY_CHECK_OK(gcs_actor_manager_->CreateActor(
        create_request,
        [](std::shared_ptr<gcs::GcsActor>, const rpc::PushTaskReply &, const Status &) {
        }));

    ASSERT_EQ(mock_actor_scheduler_->actors.size(), 1);
    std::shared_ptr<gcs::GcsActor> scheduled_actor = mock_actor_scheduler_->actors.back();
    mock_actor_scheduler_->actors.pop_back();

    // Make the actor alive on a different node (not the owner's node)
    rpc::Address actor_address = RandomAddress();
    scheduled_actor->UpdateAddress(actor_address);
    gcs_actor_manager_->OnActorCreationSuccess(scheduled_actor, rpc::PushTaskReply());
    drain_io_context();

    ASSERT_EQ(scheduled_actor->GetState(), rpc::ActorTableData::ALIVE);
    actors.push_back(scheduled_actor);
  }

  // Verify all 3 actors are alive and have the same owner
  ASSERT_EQ(actors.size(), 3);
  for (const auto &actor : actors) {
    ASSERT_EQ(actor->GetState(), rpc::ActorTableData::ALIVE);
    ASSERT_EQ(actor->GetOwnerNodeID(), owner_node_id);
    ASSERT_EQ(actor->GetOwnerID(), owner_worker_id);
  }

  // Kill the owner's node
  OnNodeDead(owner_node_id);

  // Verify ALL 3 actors are now DEAD
  for (size_t i = 0; i < actors.size(); i++) {
    ASSERT_EQ(actors[i]->GetState(), rpc::ActorTableData::DEAD)
        << "Actor " << i << " should be DEAD after owner's node died";
    ASSERT_TRUE(
        actors[i]->GetActorTableData().death_cause().has_actor_died_error_context());
    ASSERT_TRUE(absl::StrContains(actors[i]
                                      ->GetActorTableData()
                                      .death_cause()
                                      .actor_died_error_context()
                                      .error_message(),
                                  "owner has died."));
  }
}

TEST_F(GcsActorManagerTest, TestRestartPreemptedActor) {
  // This test verifies that when an actor is preempted, calling OnWorkerDead
  // does not increment the num_restarts counter and still restarts the actor.
  auto job_id = JobID::FromInt(1);
  auto registered_actor = RegisterActor(job_id,
                                        /*max_restarts=*/1,
                                        /*detached=*/false);
  rpc::CreateActorRequest create_actor_request;
  create_actor_request.mutable_task_spec()->CopyFrom(
      registered_actor->GetCreationTaskSpecification().GetMessage());

  Status status =
      gcs_actor_manager_->CreateActor(create_actor_request,
                                      [](const std::shared_ptr<gcs::GcsActor> &,
                                         const rpc::PushTaskReply &,
                                         const Status &) {});
  RAY_CHECK_OK(status);

  ASSERT_EQ(mock_actor_scheduler_->actors.size(), 1);
  auto actor = mock_actor_scheduler_->actors.back();
  mock_actor_scheduler_->actors.pop_back();

  // Make the actor alive on a specific node
  auto address = RandomAddress();
  auto node_id = NodeID::FromBinary(address.node_id());
  auto worker_id = WorkerID::FromBinary(address.worker_id());
  actor->UpdateAddress(address);
  gcs_actor_manager_->OnActorCreationSuccess(actor, rpc::PushTaskReply());
  io_service_.run_one();
  ASSERT_EQ(actor->GetState(), rpc::ActorTableData::ALIVE);

  // Initially num_restarts should be 0
  ASSERT_EQ(actor->GetActorTableData().num_restarts(), 0);
  ASSERT_FALSE(actor->GetActorTableData().preempted());

  // First restart: actor is NOT preempted, so num_restarts should increment
  gcs_actor_manager_->OnWorkerDead(node_id, worker_id);
  ASSERT_EQ(actor->GetState(), rpc::ActorTableData::RESTARTING);
  ASSERT_EQ(actor->GetActorTableData().num_restarts(), 1);  // Should increment
  ASSERT_FALSE(actor->GetActorTableData().preempted());

  // Make the actor alive on a specific node again.
  auto new_address = RandomAddress();
  auto new_node_id = NodeID::FromBinary(new_address.node_id());
  auto new_worker_id = WorkerID::FromBinary(new_address.worker_id());
  actor->UpdateAddress(new_address);
  gcs_actor_manager_->OnActorCreationSuccess(actor, rpc::PushTaskReply());
  io_service_.run_one();
  ASSERT_EQ(actor->GetState(), rpc::ActorTableData::ALIVE);
  ASSERT_EQ(actor->GetActorTableData().num_restarts(), 1);
  ASSERT_EQ(actor->GetActorTableData().num_restarts_due_to_node_preemption(), 0);

  // Now set the actor as preempted using SetPreemptedAndPublish
  gcs_actor_manager_->SetPreemptedAndPublish(new_node_id);
  io_service_.run_one();
  ASSERT_TRUE(actor->GetActorTableData().preempted());

  // Second restart: actor is preempted, so num_restarts and
  // num_restarts_due_to_node_preemption should increment
  gcs_actor_manager_->OnWorkerDead(new_node_id, new_worker_id);
  ASSERT_EQ(actor->GetState(), rpc::ActorTableData::RESTARTING);
  ASSERT_EQ(actor->GetActorTableData().num_restarts(), 2);  // Should increment
  ASSERT_EQ(actor->GetActorTableData().num_restarts_due_to_node_preemption(), 1);

  // Make the actor alive on another node again
  auto new_address_2 = RandomAddress();
  auto new_node_id_2 = NodeID::FromBinary(new_address_2.node_id());
  auto new_worker_id_2 = WorkerID::FromBinary(new_address_2.worker_id());
  actor->UpdateAddress(new_address_2);
  gcs_actor_manager_->OnActorCreationSuccess(actor, rpc::PushTaskReply());
  io_service_.run_one();
  ASSERT_EQ(actor->GetState(), rpc::ActorTableData::ALIVE);
  ASSERT_EQ(actor->GetActorTableData().num_restarts(), 2);
  ASSERT_EQ(actor->GetActorTableData().num_restarts_due_to_node_preemption(), 1);
  ASSERT_FALSE(actor->GetActorTableData().preempted());  // Turn preempted back

  // Third restart: actor reaches max_restarts, so num_restarts and
  // num_restarts_due_to_node_preemption should not increment
  gcs_actor_manager_->OnWorkerDead(new_node_id_2, new_worker_id_2);
  ASSERT_EQ(actor->GetState(), rpc::ActorTableData::DEAD);
  ASSERT_EQ(actor->GetActorTableData().num_restarts(), 2);
  ASSERT_EQ(actor->GetActorTableData().num_restarts_due_to_node_preemption(), 1);
  ASSERT_FALSE(actor->GetActorTableData().preempted());
}

TEST_F(GcsActorManagerTest,
       TestGetNamedActorOnOutOfScopeActorReturnsReconstructableActor) {
  auto send_reply_callback = [](Status, std::function<void()>, std::function<void()>) {};
  const JobID job_id = JobID::FromInt(1);
  const std::string actor_name = "test_get_if_exists_actor";
  const std::string ray_namespace = "test_namespace";

  std::shared_ptr<gcs::GcsActor> actor;
  RegisterAndCreateNamedActor(
      job_id, actor_name, ray_namespace, send_reply_callback, actor);

  // Simulate actor going out of scope
  rpc::ReportActorOutOfScopeRequest out_of_scope_request;
  out_of_scope_request.set_actor_id(actor->GetActorID().Binary());
  out_of_scope_request.set_num_restarts_due_to_lineage_reconstruction(0);
  rpc::ReportActorOutOfScopeReply out_of_scope_reply;
  gcs_actor_manager_->HandleReportActorOutOfScope(
      out_of_scope_request,
      &out_of_scope_reply,
      [](auto status, auto success_callback, auto failure_callback) {});
  drain_io_context();
  // Actor should now be DEAD but still fetchable as it is reconstructable
  ASSERT_EQ(actor->GetState(), rpc::ActorTableData::DEAD);

  rpc::GetNamedActorInfoRequest get_request;
  get_request.set_name(actor_name);
  get_request.set_ray_namespace(ray_namespace);

  rpc::GetNamedActorInfoReply get_reply;
  gcs_actor_manager_->HandleGetNamedActorInfo(
      get_request, &get_reply, send_reply_callback);
  ASSERT_EQ(get_reply.status().code(), static_cast<int>(StatusCode::OK));
  ASSERT_EQ(ActorID::FromBinary(get_reply.actor_table_data().actor_id()),
            actor->GetActorID())
      << absl::StrFormat(
             "Fetched actor ID %s differs from the existing actor ID %s. "
             "Was a new actor created instead of fetching the existing one?",
             ActorID::FromBinary(get_reply.actor_table_data().actor_id()).Hex(),
             actor->GetActorID().Hex());
}

TEST_F(GcsActorManagerTest, TestRegisterNamedActorOnOutOfScopeActorReturnsAlreadyExists) {
  auto send_reply_callback = [](Status, std::function<void()>, std::function<void()>) {};
  const JobID job_id = JobID::FromInt(1);
  const std::string actor_name = "test_create_already_exists_actor";
  const std::string ray_namespace = "test_namespace";

  std::shared_ptr<gcs::GcsActor> actor;
  RegisterAndCreateNamedActor(
      job_id, actor_name, ray_namespace, send_reply_callback, actor);

  // Simulate actor going out of scope
  rpc::ReportActorOutOfScopeRequest out_of_scope_request;
  out_of_scope_request.set_actor_id(actor->GetActorID().Binary());
  out_of_scope_request.set_num_restarts_due_to_lineage_reconstruction(0);
  rpc::ReportActorOutOfScopeReply out_of_scope_reply;
  gcs_actor_manager_->HandleReportActorOutOfScope(
      out_of_scope_request,
      &out_of_scope_reply,
      [](auto status, auto success_callback, auto failure_callback) {});
  drain_io_context();
  // Actor should now be DEAD but name still reserved (reconstructable) by owner
  ASSERT_EQ(actor->GetState(), rpc::ActorTableData::DEAD);

  auto capture_reply_callback =
      [](Status status, std::function<void()>, std::function<void()>) {};
  auto register_request = GenRegisterActorRequest(job_id,
                                                  /*max_restarts=*/-1,
                                                  /*detached=*/false,
                                                  /*name=*/actor_name,
                                                  /*ray_namespace=*/ray_namespace);
  rpc::RegisterActorReply register_reply;
  gcs_actor_manager_->HandleRegisterActor(
      register_request, &register_reply, capture_reply_callback);
  drain_io_context();
  ASSERT_EQ(register_reply.status().code(), static_cast<int>(StatusCode::AlreadyExists))
      << "Registering a named actor with the same name as an out-of-scope but "
      << "still reconstructable actor should return AlreadyExists. "
      << "Did the actor manager correctly detect that an actor with the same name "
         "already exists?";
}

TEST_F(GcsActorManagerTest, TestGetNamedActorOnDeletedActorRefReturnsNotFound) {
  auto send_reply_callback = [](Status, std::function<void()>, std::function<void()>) {};
  const JobID job_id = JobID::FromInt(1);
  const std::string actor_name = "test_get_if_exists_deleted_actor";
  const std::string ray_namespace = "test_namespace";

  std::shared_ptr<gcs::GcsActor> actor;
  RegisterAndCreateNamedActor(
      job_id, actor_name, ray_namespace, send_reply_callback, actor);

  // Simulate actor going out of scope
  rpc::ReportActorOutOfScopeRequest out_of_scope_request;
  out_of_scope_request.set_actor_id(actor->GetActorID().Binary());
  out_of_scope_request.set_num_restarts_due_to_lineage_reconstruction(0);
  rpc::ReportActorOutOfScopeReply out_of_scope_reply;
  gcs_actor_manager_->HandleReportActorOutOfScope(
      out_of_scope_request,
      &out_of_scope_reply,
      [](auto status, auto success_callback, auto failure_callback) {});
  drain_io_context();
  // Actor should now be DEAD
  ASSERT_EQ(actor->GetState(), rpc::ActorTableData::DEAD);

  // Simulate the reply of WaitForActorRefDeleted request to trigger actor ref deletion
  ASSERT_TRUE(worker_client_->Reply())
      << "Failed to notify the actor manager that the actor has been deleted.";
  // Actor ref should be deleted and is no longer reconstructable
  drain_io_context();

  rpc::GetNamedActorInfoRequest get_request;
  get_request.set_name(actor_name);
  get_request.set_ray_namespace(ray_namespace);

  rpc::GetNamedActorInfoReply get_reply;
  gcs_actor_manager_->HandleGetNamedActorInfo(
      get_request, &get_reply, send_reply_callback);
  ASSERT_EQ(get_reply.status().code(), static_cast<int>(StatusCode::NotFound))
      << "Getting a named actor info for a deleted actor should return NotFound. "
      << "Was the actor accidentally detected somewhere?";
}

TEST_F(GcsActorManagerTest, TestRegisterNamedActorOnDeletedActorRefCreatesNewActor) {
  auto send_reply_callback = [](Status, std::function<void()>, std::function<void()>) {};
  const JobID job_id = JobID::FromInt(1);
  const std::string actor_name = "test_get_if_exists_in_scope_actor";
  const std::string ray_namespace = "test_namespace";

  std::shared_ptr<gcs::GcsActor> actor;
  RegisterAndCreateNamedActor(
      job_id, actor_name, ray_namespace, send_reply_callback, actor);

  // Simulate actor going out of scope
  rpc::ReportActorOutOfScopeRequest out_of_scope_request;
  out_of_scope_request.set_actor_id(actor->GetActorID().Binary());
  out_of_scope_request.set_num_restarts_due_to_lineage_reconstruction(0);
  rpc::ReportActorOutOfScopeReply out_of_scope_reply;
  gcs_actor_manager_->HandleReportActorOutOfScope(
      out_of_scope_request,
      &out_of_scope_reply,
      [](auto status, auto success_callback, auto failure_callback) {});
  drain_io_context();
  // Actor should now be DEAD
  ASSERT_EQ(actor->GetState(), rpc::ActorTableData::DEAD);

  // Simulate the reply of WaitForActorRefDeleted request to trigger actor ref deletion
  ASSERT_TRUE(worker_client_->Reply())
      << "Failed to notify the actor manager that the actor has been deleted.";
  drain_io_context();

  rpc::RegisterActorRequest register_request =
      GenRegisterActorRequest(job_id,
                              /*max_restarts=*/-1,
                              /*detached=*/false,
                              /*name=*/actor_name,
                              /*ray_namespace=*/ray_namespace);
  rpc::RegisterActorReply register_reply;
  gcs_actor_manager_->HandleRegisterActor(
      register_request, &register_reply, send_reply_callback);
  drain_io_context();

  rpc::CreateActorRequest create_request;
  create_request.mutable_task_spec()->CopyFrom(register_request.task_spec());
  rpc::CreateActorReply create_reply;
  gcs_actor_manager_->HandleCreateActor(
      create_request, &create_reply, send_reply_callback);

  ASSERT_EQ(mock_actor_scheduler_->actors.size(), 1)
      << "Failed to schedule the be to created actor. Was the actor created correctly?";
  std::shared_ptr<gcs::GcsActor> new_actor = mock_actor_scheduler_->actors.back();
  mock_actor_scheduler_->actors.pop_back();

  // Mock new actor connecting to the gcs manager
  rpc::Address new_address = RandomAddress();
  new_actor->UpdateAddress(new_address);
  gcs_actor_manager_->OnActorCreationSuccess(new_actor, rpc::PushTaskReply());
  drain_io_context();
  ASSERT_EQ(new_actor->GetState(), rpc::ActorTableData::ALIVE);

  // Verify the new actor has a different ID
  ASSERT_NE(actor->GetActorID(), new_actor->GetActorID());
}

TEST_F(GcsActorManagerTest, TestGetNamedActorOnInScopeActorReturnsSameActor) {
  auto send_reply_callback = [](Status, std::function<void()>, std::function<void()>) {};
  const JobID job_id = JobID::FromInt(1);
  const std::string actor_name = "test_get_if_exists_in_scope_actor";
  const std::string ray_namespace = "test_namespace";

  std::shared_ptr<gcs::GcsActor> actor;
  RegisterAndCreateNamedActor(
      job_id, actor_name, ray_namespace, send_reply_callback, actor);

  rpc::GetNamedActorInfoRequest get_request;
  get_request.set_name(actor_name);
  get_request.set_ray_namespace(ray_namespace);

  rpc::GetNamedActorInfoReply get_reply;
  gcs_actor_manager_->HandleGetNamedActorInfo(
      get_request, &get_reply, send_reply_callback);
  ASSERT_EQ(get_reply.status().code(), static_cast<int>(StatusCode::OK));
  ASSERT_EQ(ActorID::FromBinary(get_reply.actor_table_data().actor_id()),
            actor->GetActorID())
      << absl::StrFormat(
             "Fetched actor ID %s differs from the existing actor ID %s. "
             "Was a new actor created?",
             ActorID::FromBinary(get_reply.actor_table_data().actor_id()).Hex(),
             actor->GetActorID().Hex());

  // Actor is still ALIVE (in scope)
  ASSERT_EQ(actor->GetState(), rpc::ActorTableData::ALIVE);
}

TEST_F(GcsActorManagerTest, TestInitializeRestoresLocalRayletAddressForAliveActors) {
  // This test verifies that after GCS restart, the local_raylet_address_ is properly
  // restored for ALIVE actors on ALIVE nodes. This is critical because without the
  // local raylet address, the GCS cannot send KillLocalActorRequest to kill zombie
  // actor processes.

  // Step 1: Create a node that is ALIVE
  rpc::GcsNodeInfo node_info;
  auto node_id = NodeID::FromRandom();
  node_info.set_node_id(node_id.Binary());
  node_info.set_state(rpc::GcsNodeInfo::ALIVE);
  node_info.set_node_manager_address("127.0.0.1");
  node_info.set_node_manager_port(9999);

  // Step 2: Create a job that is ALIVE
  auto job_id = JobID::FromInt(1);
  rpc::JobTableData job_data;
  job_data.set_job_id(job_id.Binary());
  job_data.set_is_dead(false);

  // Step 3: Create an ALIVE actor on that node
  auto worker_id = WorkerID::FromRandom();
  auto actor_id = ActorID::Of(job_id, RandomTaskId(), 0);
  rpc::ActorTableData actor_table_data;
  actor_table_data.set_actor_id(actor_id.Binary());
  actor_table_data.set_state(rpc::ActorTableData::ALIVE);
  actor_table_data.set_node_id(node_id.Binary());
  actor_table_data.mutable_address()->set_node_id(node_id.Binary());
  actor_table_data.mutable_address()->set_worker_id(worker_id.Binary());
  actor_table_data.mutable_address()->set_ip_address("127.0.0.1");
  actor_table_data.mutable_address()->set_port(12345);
  // Set owner address (owner is the driver/job)
  auto *owner_address = actor_table_data.mutable_owner_address();
  owner_address->set_node_id(node_id.Binary());
  owner_address->set_worker_id(WorkerID::FromRandom().Binary());
  owner_address->set_ip_address("127.0.0.1");
  owner_address->set_port(12345);
  actor_table_data.set_max_restarts(0);
  actor_table_data.set_is_detached(false);

  // Step 4: Create task spec for the actor
  // Need to properly set up the task spec so RootDetachedActorId() returns Nil()
  rpc::TaskSpec task_spec;
  auto *actor_creation_spec = task_spec.mutable_actor_creation_task_spec();
  actor_creation_spec->set_actor_id(actor_id.Binary());
  // Set root_detached_actor_id to empty (Nil) to indicate owner is job
  // This field is in TaskSpec, not ActorCreationTaskSpec
  task_spec.set_root_detached_actor_id("");

  // Step 5: Populate GcsInitData with test data
  TestGcsInitData gcs_init_data(*gcs_table_storage_);

  absl::flat_hash_map<NodeID, rpc::GcsNodeInfo> node_data;
  node_data[node_id] = node_info;
  gcs_init_data.SetNodeTableData(node_data);

  absl::flat_hash_map<JobID, rpc::JobTableData> job_data_map;
  job_data_map[job_id] = job_data;
  gcs_init_data.SetJobTableData(job_data_map);

  absl::flat_hash_map<ActorID, rpc::ActorTableData> actor_data;
  actor_data[actor_id] = actor_table_data;
  gcs_init_data.SetActorTableData(actor_data);

  absl::flat_hash_map<ActorID, rpc::TaskSpec> task_spec_data;
  task_spec_data[actor_id] = task_spec;
  gcs_init_data.SetActorTaskSpecTableData(task_spec_data);

  // Step 6: Create a new GcsActorManager to test Initialize()
  // We need a fresh instance since the original one was already initialized
  auto test_gcs_actor_manager = CreateActorManagerForInitializeTest();

  // Step 7: Call Initialize() with the populated GcsInitData
  test_gcs_actor_manager->Initialize(gcs_init_data);

  // Step 8: Verify that the actor was registered and local_raylet_address_ was restored
  ASSERT_EQ(RegisteredActorCount(*test_gcs_actor_manager), 1u);

  auto actor = GetRegisteredActor(*test_gcs_actor_manager, actor_id);
  ASSERT_NE(actor, nullptr);

  // Verify that local_raylet_address_ was properly restored
  const auto &local_raylet_address = actor->LocalRayletAddress();
  ASSERT_TRUE(local_raylet_address.has_value())
      << "local_raylet_address_ should be restored for ALIVE actors on ALIVE nodes";

  // Verify the restored address matches the node info
  ASSERT_EQ(local_raylet_address->node_id(), node_id.Binary());
  ASSERT_EQ(local_raylet_address->ip_address(), "127.0.0.1");
  ASSERT_EQ(local_raylet_address->port(), 9999);
}

}  // namespace gcs

}  // namespace ray
