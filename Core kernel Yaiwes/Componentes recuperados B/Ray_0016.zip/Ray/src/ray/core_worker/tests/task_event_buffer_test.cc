// Copyright 2022 The Ray Authors.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//  http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#include "ray/core_worker/task_event_buffer.h"

#include <google/protobuf/util/message_differencer.h>

#include <algorithm>
#include <atomic>
#include <chrono>
#include <filesystem>
#include <fstream>
#include <memory>
#include <string>
#include <thread>
#include <tuple>
#include <unordered_map>
#include <utility>
#include <vector>

#include "absl/base/thread_annotations.h"
#include "absl/synchronization/mutex.h"
#include "absl/types/optional.h"
#include "gmock/gmock.h"
#include "gtest/gtest.h"
#include "mock/ray/gcs_client/gcs_client.h"
#include "ray/common/task/task_spec.h"
#include "ray/common/task/task_util.h"
#include "ray/common/test_utils.h"
#include "ray/util/clock.h"
#include "ray/util/event.h"

using ::testing::_;
using ::testing::DoAll;
using ::testing::Invoke;
using ::testing::MakeAction;
using ::testing::Return;

namespace ray {

namespace core {

namespace worker {

class MockEventAggregatorClient : public ray::rpc::EventAggregatorClient {
 public:
  MOCK_METHOD(void,
              AddEvents,
              (const rpc::events::AddEventsRequest &request,
               const rpc::ClientCallback<rpc::events::AddEventsReply> &callback),
              (override));
};

class MockEventAggregatorAddEvents
    : public ::testing::ActionInterface<void(
          const rpc::events::AddEventsRequest &request,
          const rpc::ClientCallback<rpc::events::AddEventsReply> &callback)> {
 public:
  MockEventAggregatorAddEvents(Status status, rpc::events::AddEventsReply reply)
      : status_(std::move(status)), reply_(std::move(reply)) {}

  void Perform(const std::tuple<const rpc::events::AddEventsRequest &,
                                const rpc::ClientCallback<rpc::events::AddEventsReply> &>
                   &args) override {
    std::get<1>(args)(status_, std::move(reply_));
  }

 private:
  Status status_;
  rpc::events::AddEventsReply reply_;
};

class TaskEventBufferTest : public ::testing::Test {
 public:
  TaskEventBufferTest() {
    // The buffer records only while one of its destinations is enabled, so name one
    // here to exercise the ring.
    RayConfig::instance().initialize(
        R"(
{
  "task_events_report_interval_ms": 1000,
  "task_events_max_num_status_events_buffer_on_worker": 100,
  "task_events_send_batch_size": 100,
  "task_events_shutdown_flush_timeout_ms": 100,
  "enable_core_worker_task_event_to_gcs": true
}
  )");

    task_event_buffer_ = std::make_unique<TaskEventBufferImpl>(
        std::make_unique<ray::gcs::MockGcsClient>(),
        std::make_unique<MockEventAggregatorClient>(),
        "test_session_name",
        NodeID::Nil(),
        clock_);
  }

  virtual void SetUp() { RAY_CHECK_OK(task_event_buffer_->Start(/*auto_flush*/ false)); }

  virtual void TearDown() {
    if (task_event_buffer_) task_event_buffer_->Stop();
  };

  std::vector<TaskID> GenTaskIDs(size_t num_tasks) {
    std::vector<TaskID> task_ids;
    for (size_t i = 0; i < num_tasks; ++i) {
      task_ids.push_back(RandomTaskId());
    }
    return task_ids;
  }

  TaskSpecification BuildTaskSpec(TaskID task_id, int32_t attempt_num) {
    TaskSpecBuilder builder;
    rpc::Address empty_address;
    rpc::JobConfig config;
    std::unordered_map<std::string, double> resources = {{"CPU", 1}};
    std::unordered_map<std::string, std::string> labels = {{"label1", "value1"}};
    builder.SetCommonTaskSpec(task_id,
                              "dummy_task",
                              Language::PYTHON,
                              FunctionDescriptorBuilder::BuildPython(
                                  "dummy_module", "dummy_class", "dummy_function", ""),
                              JobID::Nil(),
                              config,
                              TaskID::Nil(),
                              0,
                              TaskID::Nil(),
                              empty_address,
                              1,
                              false,
                              false,
                              -1,
                              resources,
                              resources,
                              "",
                              0,
                              TaskID::Nil(),
                              "",
                              std::make_shared<rpc::RuntimeEnvInfo>(),
                              "",
                              true,
                              labels);
    return std::move(builder).ConsumeAndBuild();
  }

  std::unique_ptr<TaskEvent> GenFullStatusTaskEvent(TaskID task_id, int32_t attempt_num) {
    // Generate a task spec
    auto task_spec = BuildTaskSpec(task_id, attempt_num);

    // Generate a status update
    auto status_update = TaskStatusEvent::TaskStateUpdate(123u);

    return std::make_unique<TaskStatusEvent>(
        task_id,
        JobID::FromInt(0),
        attempt_num,
        rpc::TaskStatus::RUNNING,
        1,
        /*is_actor_task_event=*/false,
        "test_session_name",
        NodeID::Nil(),
        std::make_shared<TaskSpecification>(task_spec),
        status_update);
  }

  std::unique_ptr<TaskEvent> GenStatusTaskEvent(
      TaskID task_id,
      int32_t attempt_num,
      int64_t running_ts = 1,
      std::optional<const TaskStatusEvent::TaskStateUpdate> state_update =
          absl::nullopt) {
    return std::make_unique<TaskStatusEvent>(task_id,
                                             JobID::FromInt(0),
                                             attempt_num,
                                             rpc::TaskStatus::RUNNING,
                                             running_ts,
                                             /*is_actor_task_event=*/false,
                                             "test_session_name",
                                             NodeID::Nil(),
                                             nullptr,
                                             state_update);
  }

  std::unique_ptr<TaskEvent> GenProfileTaskEvent(TaskID task_id, int32_t attempt_num) {
    return std::make_unique<TaskProfileEvent>(task_id,
                                              JobID::FromInt(0),
                                              attempt_num,
                                              "",
                                              "",
                                              "",
                                              "test_event",
                                              1,
                                              "test_session_name",
                                              NodeID::Nil());
  }

  static void CompareTaskEventData(const rpc::TaskEventData &actual_data,
                                   const rpc::TaskEventData &expect_data) {
    // Sort and compare
    std::vector<std::string> actual_events;
    std::vector<std::string> expect_events;
    for (const auto &e : actual_data.events_by_task()) {
      actual_events.push_back(e.DebugString());
    }
    for (const auto &e : expect_data.events_by_task()) {
      expect_events.push_back(e.DebugString());
    }
    std::sort(actual_events.begin(), actual_events.end());
    std::sort(expect_events.begin(), expect_events.end());
    EXPECT_EQ(actual_events.size(), expect_events.size());
    for (size_t i = 0; i < actual_events.size(); ++i) {
      EXPECT_EQ(actual_events[i], expect_events[i]);
    }

    EXPECT_EQ(actual_data.num_profile_events_dropped(),
              expect_data.num_profile_events_dropped());

    std::vector<std::string> actual_dropped_task_attempts;
    std::vector<std::string> expect_dropped_task_attempts;

    for (const auto &t : actual_data.dropped_task_attempts()) {
      actual_dropped_task_attempts.push_back(t.DebugString());
    }
    for (const auto &t : expect_data.dropped_task_attempts()) {
      expect_dropped_task_attempts.push_back(t.DebugString());
    }

    std::sort(actual_dropped_task_attempts.begin(), actual_dropped_task_attempts.end());
    std::sort(expect_dropped_task_attempts.begin(), expect_dropped_task_attempts.end());
    EXPECT_EQ(actual_dropped_task_attempts.size(), expect_dropped_task_attempts.size());
    for (size_t i = 0; i < actual_dropped_task_attempts.size(); ++i) {
      EXPECT_EQ(actual_dropped_task_attempts[i], expect_dropped_task_attempts[i]);
    }
  }

  static void CompareRayEventsData(const rpc::events::RayEventsData &actual_data,
                                   const rpc::events::RayEventsData &expect_data) {
    // Sort and compare
    std::vector<std::string> actual_events;
    std::vector<std::string> expect_events;
    for (const auto &e : actual_data.events()) {
      auto event_copy = e;
      event_copy.set_event_id(UniqueID::Nil().Binary());
      actual_events.push_back(event_copy.DebugString());
    }
    for (const auto &e : expect_data.events()) {
      auto event_copy = e;
      event_copy.set_event_id(UniqueID::Nil().Binary());
      expect_events.push_back(event_copy.DebugString());
    }
    std::sort(actual_events.begin(), actual_events.end());
    std::sort(expect_events.begin(), expect_events.end());
    EXPECT_EQ(actual_events.size(), expect_events.size());
    for (size_t i = 0; i < actual_events.size(); ++i) {
      EXPECT_EQ(actual_events[i], expect_events[i]);
    }

    std::vector<std::string> actual_dropped_task_attempts;
    std::vector<std::string> expect_dropped_task_attempts;

    for (const auto &t : actual_data.task_events_metadata().dropped_task_attempts()) {
      actual_dropped_task_attempts.push_back(t.DebugString());
    }
    for (const auto &t : expect_data.task_events_metadata().dropped_task_attempts()) {
      expect_dropped_task_attempts.push_back(t.DebugString());
    }
    std::sort(actual_dropped_task_attempts.begin(), actual_dropped_task_attempts.end());
    std::sort(expect_dropped_task_attempts.begin(), expect_dropped_task_attempts.end());
    EXPECT_EQ(actual_dropped_task_attempts.size(), expect_dropped_task_attempts.size());

    for (size_t i = 0; i < actual_dropped_task_attempts.size(); ++i) {
      EXPECT_EQ(actual_dropped_task_attempts[i], expect_dropped_task_attempts[i]);
    }
  }

  Clock clock_;
  std::unique_ptr<TaskEventBufferImpl> task_event_buffer_ = nullptr;
};

struct DifferentDestination {
  bool to_gcs;
  bool to_aggregator;
};

class TaskEventBufferTestManualStart : public TaskEventBufferTest {
  void SetUp() override {}
};

class TaskEventBufferTestBatchSendDifferentDestination
    : public TaskEventBufferTest,
      public ::testing::WithParamInterface<DifferentDestination> {
 public:
  TaskEventBufferTestBatchSendDifferentDestination() : TaskEventBufferTest() {
    const auto [to_gcs, to_aggregator] = GetParam();
    std::string to_gcs_str = to_gcs ? "true" : "false";
    std::string to_aggregator_str = to_aggregator ? "true" : "false";
    RayConfig::instance().initialize(
        R"(
{
  "task_events_report_interval_ms": 1000,
  "task_events_max_num_status_events_buffer_on_worker": 100,
  "task_events_max_num_profile_events_buffer_on_worker": 100,
  "task_events_send_batch_size": 10,
  "task_events_shutdown_flush_timeout_ms": 100,
  "enable_ray_task_event_recorder": false,
  "enable_core_worker_task_event_to_gcs": )" +
        to_gcs_str + R"(,
  "enable_core_worker_ray_event_to_aggregator": )" +
        to_aggregator_str + R"(
}
  )");
  }
};

class TaskEventBufferTestLimitBufferDifferentDestination
    : public TaskEventBufferTest,
      public ::testing::WithParamInterface<DifferentDestination> {
 public:
  TaskEventBufferTestLimitBufferDifferentDestination() : TaskEventBufferTest() {
    const auto [to_gcs, to_aggregator] = GetParam();
    std::string to_gcs_str = to_gcs ? "true" : "false";
    std::string to_aggregator_str = to_aggregator ? "true" : "false";
    RayConfig::instance().initialize(
        R"(
{
  "task_events_report_interval_ms": 1000,
  "task_events_max_num_status_events_buffer_on_worker": 10,
  "task_events_max_num_profile_events_buffer_on_worker": 5,
  "task_events_send_batch_size": 10,
  "task_events_shutdown_flush_timeout_ms": 100,
  "enable_ray_task_event_recorder": false,
  "enable_core_worker_task_event_to_gcs": )" +
        to_gcs_str + R"(,
  "enable_core_worker_ray_event_to_aggregator": )" +
        to_aggregator_str + R"(
}
  )");
  }
};

class TaskEventBufferTestLimitProfileEvents : public TaskEventBufferTest {
 public:
  TaskEventBufferTestLimitProfileEvents() : TaskEventBufferTest() {
    RayConfig::instance().initialize(
        R"(
{
  "task_events_report_interval_ms": 1000,
  "task_events_max_num_profile_events_per_task": 10,
  "task_events_max_num_profile_events_buffer_on_worker": 20,
  "task_events_shutdown_flush_timeout_ms": 100,
  "enable_core_worker_task_event_to_gcs": true
}
  )");
  }
};

class TaskEventBufferTestDifferentDestination
    : public TaskEventBufferTest,
      public ::testing::WithParamInterface<DifferentDestination> {
 public:
  TaskEventBufferTestDifferentDestination() : TaskEventBufferTest() {
    const auto [to_gcs, to_aggregator] = GetParam();
    std::string to_gcs_str = to_gcs ? "true" : "false";
    std::string to_aggregator_str = to_aggregator ? "true" : "false";
    // Keep the recorder disabled so the buffer's own aggregator send path (exercised by
    // to_aggregator) is not taken over by RayTaskEventRecorder.
    RayConfig::instance().initialize(
        R"(
{
  "task_events_report_interval_ms": 1000,
  "task_events_max_num_status_events_buffer_on_worker": 100,
  "task_events_send_batch_size": 100,
  "task_events_shutdown_flush_timeout_ms": 100,
  "enable_ray_task_event_recorder": false,
  "enable_core_worker_task_event_to_gcs": )" +
        to_gcs_str + R"(,
  "enable_core_worker_ray_event_to_aggregator": )" +
        to_aggregator_str + R"(
}
  )");
  }
};

class TaskEventBufferTestDroppedAttemptsOnly
    : public TaskEventBufferTest,
      public ::testing::WithParamInterface<DifferentDestination> {
 public:
  TaskEventBufferTestDroppedAttemptsOnly() : TaskEventBufferTest() {
    const auto [to_gcs, to_aggregator] = GetParam();
    std::string to_gcs_str = to_gcs ? "true" : "false";
    std::string to_aggregator_str = to_aggregator ? "true" : "false";
    RayConfig::instance().initialize(
        R"(
{
  "task_events_report_interval_ms": 1000,
  "task_events_max_num_status_events_buffer_on_worker": 1,
  "task_events_send_batch_size": 1,
  "task_events_dropped_task_attempt_batch_size": 1,
  "task_events_shutdown_flush_timeout_ms": 100,
  "enable_ray_task_event_recorder": false,
  "enable_core_worker_task_event_to_gcs": )" +
        to_gcs_str + R"(,
  "enable_core_worker_ray_event_to_aggregator": )" +
        to_aggregator_str + R"(
}
  )");
  }
};

void ReadContentFromFile(std::vector<std::string> &vc,
                         std::string log_file,
                         std::string filter = "") {
  std::string line;
  std::ifstream read_file;
  read_file.open(log_file, std::ios::binary);
  while (std::getline(read_file, line)) {
    if (filter.empty() || line.find(filter) != std::string::npos) {
      vc.push_back(line);
    }
  }
  read_file.close();
}

TEST_F(TaskEventBufferTestManualStart, TestGcsClientFail) {
  ASSERT_NE(task_event_buffer_, nullptr);

  // Mock GCS connect fail.
  auto gcs_client =
      static_cast<ray::gcs::MockGcsClient *>(task_event_buffer_->GetGcsClient());
  EXPECT_CALL(*gcs_client, Connect)
      .Times(1)
      .WillOnce(Return(Status::UnknownError("error")));

  // Expect no flushing even if auto flush is on since start fails.
  auto task_gcs_accessor =
      static_cast<ray::gcs::MockGcsClient *>(task_event_buffer_->GetGcsClient())
          ->mock_task_accessor;
  EXPECT_CALL(*task_gcs_accessor, AsyncAddTaskEventData).Times(0);

  ASSERT_TRUE(task_event_buffer_->Start(/*auto_flush*/ true).IsUnknownError());
  ASSERT_FALSE(task_event_buffer_->Enabled());
}

TEST_F(TaskEventBufferTest, TestAddEvents) {
  ASSERT_EQ(task_event_buffer_->GetNumTaskEventsStored(), 0);

  // Test add status event
  auto task_id_1 = RandomTaskId();
  task_event_buffer_->AddTaskEvent(GenStatusTaskEvent(task_id_1, 0));

  ASSERT_EQ(task_event_buffer_->GetNumTaskEventsStored(), 1);

  // Test add profile events
  task_event_buffer_->AddTaskEvent(GenProfileTaskEvent(task_id_1, 1));
  ASSERT_EQ(task_event_buffer_->GetNumTaskEventsStored(), 2);
}

// Buffer configured with no destination live (GCS, aggregator and export all off, and the
// recorder disabled). The buffer should short-circuit and record nothing.
class TaskEventBufferTestNoDestination : public TaskEventBufferTest {
 public:
  TaskEventBufferTestNoDestination() : TaskEventBufferTest() {
    RayConfig::instance().initialize(
        R"(
{
  "task_events_report_interval_ms": 1000,
  "task_events_max_num_status_events_buffer_on_worker": 100,
  "task_events_send_batch_size": 100,
  "task_events_shutdown_flush_timeout_ms": 100,
  "enable_ray_task_event_recorder": false,
  "enable_core_worker_task_event_to_gcs": false,
  "enable_core_worker_ray_event_to_aggregator": false
}
  )");
  }
};

TEST_F(TaskEventBufferTestNoDestination, TestNoRecordingWhenNoDestination) {
  ASSERT_FALSE(task_event_buffer_->Enabled());

  auto task_id = RandomTaskId();
  task_event_buffer_->AddTaskEvent(GenStatusTaskEvent(task_id, 0));
  task_event_buffer_->AddTaskEvent(GenProfileTaskEvent(task_id, 1));

  ASSERT_EQ(task_event_buffer_->GetNumTaskEventsStored(), 0);
}

TEST_P(TaskEventBufferTestDifferentDestination, TestFlushEvents) {
  const auto [to_gcs, to_aggregator] = GetParam();
  size_t num_events = 20;
  auto task_ids = GenTaskIDs(num_events);

  std::vector<std::unique_ptr<TaskEvent>> task_events;
  for (const auto &task_id : task_ids) {
    task_events.push_back(GenFullStatusTaskEvent(task_id, 0));
  }

  // Expect data flushed match. Generate expected data
  rpc::TaskEventData expected_task_event_data;
  rpc::events::RayEventsData expected_ray_events_data;
  expected_task_event_data.set_num_profile_events_dropped(0);
  for (const auto &task_event : task_events) {
    auto event = expected_task_event_data.add_events_by_task();
    task_event->ToRpcTaskEvents(event);

    RayEventsTuple ray_events_tuple;
    task_event->ToRpcRayEvents(ray_events_tuple);
    if (ray_events_tuple.task_definition_event) {
      auto new_event = expected_ray_events_data.add_events();
      *new_event = std::move(ray_events_tuple.task_definition_event.value());
    }
    if (ray_events_tuple.task_lifecycle_event) {
      auto new_event = expected_ray_events_data.add_events();
      *new_event = std::move(ray_events_tuple.task_lifecycle_event.value());
    }
    if (ray_events_tuple.task_profile_event) {
      auto new_event = expected_ray_events_data.add_events();
      *new_event = std::move(ray_events_tuple.task_profile_event.value());
    }
  }

  for (auto &task_event : task_events) {
    task_event_buffer_->AddTaskEvent(std::move(task_event));
  }

  ASSERT_EQ(task_event_buffer_->GetNumTaskEventsStored(), num_events);

  // Manually call flush should call GCS client's flushing grpc.
  auto task_gcs_accessor =
      static_cast<ray::gcs::MockGcsClient *>(task_event_buffer_->GetGcsClient())
          ->mock_task_accessor;
  if (to_gcs) {
    EXPECT_CALL(*task_gcs_accessor, AsyncAddTaskEventData(_, _))
        .WillOnce([&](std::unique_ptr<rpc::TaskEventData> actual_data,
                      ray::rpc::StatusCallback callback) {
          CompareTaskEventData(*actual_data, expected_task_event_data);
          return Status::OK();
        });
  } else {
    EXPECT_CALL(*task_gcs_accessor, AsyncAddTaskEventData(_, _)).Times(0);
  }

  // If ray events to aggregator is enabled, expect to call AddEvents grpc.
  auto event_aggregator_client = static_cast<MockEventAggregatorClient *>(
      task_event_buffer_->event_aggregator_client_.get());
  rpc::events::AddEventsRequest add_events_request;
  if (to_aggregator) {
    rpc::events::AddEventsReply reply;
    Status status = Status::OK();
    EXPECT_CALL(*event_aggregator_client, AddEvents(_, _))
        .WillOnce(DoAll(
            Invoke([&](const rpc::events::AddEventsRequest &request,
                       const rpc::ClientCallback<rpc::events::AddEventsReply> &callback) {
              CompareRayEventsData(request.events_data(), expected_ray_events_data);
            }),
            MakeAction(
                new MockEventAggregatorAddEvents(std::move(status), std::move(reply)))));
  } else {
    EXPECT_CALL(*event_aggregator_client, AddEvents(_, _)).Times(0);
  }

  task_event_buffer_->FlushEvents(false);

  // Expect no more events.
  ASSERT_EQ(task_event_buffer_->GetNumTaskEventsStored(), 0);
}

TEST_P(TaskEventBufferTestDifferentDestination, TestFailedFlush) {
  const auto [to_gcs, to_aggregator] = GetParam();
  size_t num_status_events = 20;
  size_t num_profile_events = 20;
  // Adding some events
  for (size_t i = 0; i < num_status_events + num_profile_events; ++i) {
    auto task_id = RandomTaskId();
    if (i % 2 == 0) {
      task_event_buffer_->AddTaskEvent(GenStatusTaskEvent(task_id, 0));
    } else {
      task_event_buffer_->AddTaskEvent(GenProfileTaskEvent(task_id, 0));
    }
  }

  auto task_gcs_accessor =
      static_cast<ray::gcs::MockGcsClient *>(task_event_buffer_->GetGcsClient())
          ->mock_task_accessor;

  // Mock gRPC sent failure.
  if (to_gcs) {
    EXPECT_CALL(*task_gcs_accessor, AsyncAddTaskEventData)
        .Times(2)
        .WillOnce([&](std::unique_ptr<rpc::TaskEventData> actual_data,
                      ray::rpc::StatusCallback callback) {
          callback(Status::RpcError("grpc error", grpc::StatusCode::UNKNOWN));
          return Status::OK();
        })
        .WillOnce([&](std::unique_ptr<rpc::TaskEventData> actual_data,
                      ray::rpc::StatusCallback callback) {
          callback(Status::OK());
          return Status::OK();
        });
  }

  auto event_aggregator_client = static_cast<MockEventAggregatorClient *>(
      task_event_buffer_->event_aggregator_client_.get());
  if (to_aggregator) {
    rpc::events::AddEventsReply reply_1;
    Status status_1 = Status::RpcError("grpc error", grpc::StatusCode::UNKNOWN);
    rpc::events::AddEventsReply reply_2;
    Status status_2 = Status::OK();

    EXPECT_CALL(*event_aggregator_client, AddEvents(_, _))
        .Times(2)
        .WillOnce(MakeAction(
            new MockEventAggregatorAddEvents(std::move(status_1), std::move(reply_1))))
        .WillOnce(MakeAction(
            new MockEventAggregatorAddEvents(std::move(status_2), std::move(reply_2))));
  }

  // Flush
  task_event_buffer_->FlushEvents(false);

  // Expect the number of dropped events incremented.
  if (to_gcs) {
    ASSERT_EQ(task_event_buffer_->stats_counter_.Get(
                  TaskEventBufferCounter::kTotalNumFailedToReport),
              1);
  }
  if (to_aggregator) {
    ASSERT_EQ(task_event_buffer_->stats_counter_.Get(
                  TaskEventBufferCounter::kTotalNumFailedRequestsToAggregator),
              1);
  }

  // Adding some more events
  for (size_t i = 0; i < num_status_events + num_profile_events; ++i) {
    auto task_id = RandomTaskId();
    if (i % 2 == 0) {
      task_event_buffer_->AddTaskEvent(GenStatusTaskEvent(task_id, 1));
    } else {
      task_event_buffer_->AddTaskEvent(GenProfileTaskEvent(task_id, 1));
    }
  }

  // Flush successfully will not affect the failed to report count.
  task_event_buffer_->FlushEvents(false);
  if (to_gcs) {
    ASSERT_EQ(task_event_buffer_->stats_counter_.Get(
                  TaskEventBufferCounter::kTotalNumFailedToReport),
              1);
  }
  if (to_aggregator) {
    ASSERT_EQ(task_event_buffer_->stats_counter_.Get(
                  TaskEventBufferCounter::kTotalNumFailedRequestsToAggregator),
              1);
  }
}

TEST_P(TaskEventBufferTestDifferentDestination, TestBackPressure) {
  const auto [to_gcs, to_aggregator] = GetParam();
  size_t num_events = 20;
  // Adding some events
  for (size_t i = 0; i < num_events; ++i) {
    auto task_id = RandomTaskId();
    task_event_buffer_->AddTaskEvent(GenStatusTaskEvent(task_id, 0));
  }

  auto task_gcs_accessor =
      static_cast<ray::gcs::MockGcsClient *>(task_event_buffer_->GetGcsClient())
          ->mock_task_accessor;
  // Multiple flush calls should only result in 1 grpc call if not forced flush.
  if (to_gcs) {
    EXPECT_CALL(*task_gcs_accessor, AsyncAddTaskEventData).Times(1);
  } else {
    EXPECT_CALL(*task_gcs_accessor, AsyncAddTaskEventData).Times(0);
  }

  auto event_aggregator_client = static_cast<MockEventAggregatorClient *>(
      task_event_buffer_->event_aggregator_client_.get());
  if (to_aggregator) {
    EXPECT_CALL(*event_aggregator_client, AddEvents(_, _)).Times(1);
  } else {
    EXPECT_CALL(*event_aggregator_client, AddEvents(_, _)).Times(0);
  }

  task_event_buffer_->FlushEvents(false);

  auto task_id_1 = RandomTaskId();
  task_event_buffer_->AddTaskEvent(GenStatusTaskEvent(task_id_1, 0));
  task_event_buffer_->FlushEvents(false);

  auto task_id_2 = RandomTaskId();
  task_event_buffer_->AddTaskEvent(GenStatusTaskEvent(task_id_2, 0));
  task_event_buffer_->FlushEvents(false);
}

TEST_P(TaskEventBufferTestDifferentDestination, TestForcedFlush) {
  const auto [to_gcs, to_aggregator] = GetParam();
  size_t num_events = 20;
  // Adding some events
  for (size_t i = 0; i < num_events; ++i) {
    auto task_id = RandomTaskId();
    task_event_buffer_->AddTaskEvent(GenStatusTaskEvent(task_id, 0));
  }

  // Multiple flush calls with forced should result in same number of grpc call.
  auto task_gcs_accessor =
      static_cast<ray::gcs::MockGcsClient *>(task_event_buffer_->GetGcsClient())
          ->mock_task_accessor;
  if (to_gcs) {
    EXPECT_CALL(*task_gcs_accessor, AsyncAddTaskEventData).Times(2);
  } else {
    EXPECT_CALL(*task_gcs_accessor, AsyncAddTaskEventData).Times(0);
  }

  auto event_aggregator_client = static_cast<MockEventAggregatorClient *>(
      task_event_buffer_->event_aggregator_client_.get());
  if (to_aggregator) {
    EXPECT_CALL(*event_aggregator_client, AddEvents(_, _)).Times(2);
  } else {
    EXPECT_CALL(*event_aggregator_client, AddEvents(_, _)).Times(0);
  }

  auto task_id_1 = RandomTaskId();
  task_event_buffer_->AddTaskEvent(GenStatusTaskEvent(task_id_1, 0));
  task_event_buffer_->FlushEvents(false);

  auto task_id_2 = RandomTaskId();
  task_event_buffer_->AddTaskEvent(GenStatusTaskEvent(task_id_2, 0));
  task_event_buffer_->FlushEvents(true);
}

TEST_P(TaskEventBufferTestBatchSendDifferentDestination, TestBatchedSend) {
  const auto [to_gcs, to_aggregator] = GetParam();
  size_t num_events = 100;
  size_t batch_size = 10;  // Sync with constructor.
  std::vector<TaskID> task_ids;
  // Adding some events
  for (size_t i = 0; i < num_events; ++i) {
    auto task_id = RandomTaskId();
    task_ids.push_back(task_id);
    task_event_buffer_->AddTaskEvent(GenStatusTaskEvent(task_id, 0));
  }

  auto task_gcs_accessor =
      static_cast<ray::gcs::MockGcsClient *>(task_event_buffer_->GetGcsClient())
          ->mock_task_accessor;
  if (to_gcs) {
    // With batch size = 10, there should be 10 flush calls
    EXPECT_CALL(*task_gcs_accessor, AsyncAddTaskEventData)
        .Times(num_events / batch_size)
        .WillRepeatedly([&batch_size](std::unique_ptr<rpc::TaskEventData> actual_data,
                                      ray::rpc::StatusCallback callback) {
          EXPECT_EQ(actual_data->events_by_task_size(), batch_size);
          callback(Status::OK());
          return Status::OK();
        });
  } else {
    EXPECT_CALL(*task_gcs_accessor, AsyncAddTaskEventData).Times(0);
  }

  auto event_aggregator_client = static_cast<MockEventAggregatorClient *>(
      task_event_buffer_->event_aggregator_client_.get());
  if (to_aggregator) {
    rpc::events::AddEventsReply reply;
    Status status = Status::OK();
    EXPECT_CALL(*event_aggregator_client, AddEvents(_, _))
        .Times(num_events / batch_size)
        .WillRepeatedly(DoAll(
            Invoke([&batch_size](
                       const rpc::events::AddEventsRequest &request,
                       const rpc::ClientCallback<rpc::events::AddEventsReply> &callback) {
              EXPECT_EQ(request.events_data().events_size(), batch_size);
            }),
            MakeAction(
                new MockEventAggregatorAddEvents(std::move(status), std::move(reply)))));
  } else {
    EXPECT_CALL(*event_aggregator_client, AddEvents(_, _)).Times(0);
  }

  for (int i = 0; i * batch_size < num_events; i++) {
    task_event_buffer_->FlushEvents(true);
    EXPECT_EQ(task_event_buffer_->GetNumTaskEventsStored(),
              num_events - (i + 1) * batch_size);
  }

  // With last flush, there should be no more events in the buffer and as data.
  EXPECT_EQ(task_event_buffer_->GetNumTaskEventsStored(), 0);
}

TEST_P(TaskEventBufferTestLimitBufferDifferentDestination,
       TestBufferSizeLimitStatusEvents) {
  const auto [to_gcs, to_aggregator] = GetParam();
  size_t num_limit_status_events = 10;  // sync with setup
  size_t num_status_dropped = 10;

  // Generate 2 batches of events each, where batch 1 will be evicted by batch 2.
  std::vector<std::unique_ptr<TaskEvent>> status_events_1;
  std::vector<std::unique_ptr<TaskEvent>> status_events_2;

  // Generate data
  for (size_t i = 0; i < num_limit_status_events; ++i) {
    status_events_1.push_back(GenStatusTaskEvent(RandomTaskId(), 0));
    status_events_2.push_back(GenStatusTaskEvent(RandomTaskId(), 0));
  }

  rpc::TaskEventData expected_data;
  rpc::events::RayEventsData expected_ray_events_data;
  for (const auto &event_ptr : status_events_1) {
    rpc::TaskAttempt rpc_task_attempt;
    auto task_attempt = event_ptr->GetTaskAttempt();
    rpc_task_attempt.set_task_id(task_attempt.first.Binary());
    rpc_task_attempt.set_attempt_number(task_attempt.second);
    *(expected_data.add_dropped_task_attempts()) = rpc_task_attempt;
    *(expected_ray_events_data.mutable_task_events_metadata()
          ->add_dropped_task_attempts()) = rpc_task_attempt;
  }

  for (const auto &event_ptr : status_events_2) {
    auto expect_event = expected_data.add_events_by_task();
    // Copy the data
    auto event = std::make_unique<TaskStatusEvent>(
        *static_cast<TaskStatusEvent *>(event_ptr.get()));
    event->ToRpcTaskEvents(expect_event);

    RayEventsTuple ray_events_tuple;
    event->ToRpcRayEvents(ray_events_tuple);
    if (ray_events_tuple.task_definition_event) {
      auto new_event = expected_ray_events_data.add_events();
      *new_event = std::move(ray_events_tuple.task_definition_event.value());
    }
    if (ray_events_tuple.task_lifecycle_event) {
      auto new_event = expected_ray_events_data.add_events();
      *new_event = std::move(ray_events_tuple.task_lifecycle_event.value());
    }
    if (ray_events_tuple.task_profile_event) {
      auto new_event = expected_ray_events_data.add_events();
      *new_event = std::move(ray_events_tuple.task_profile_event.value());
    }
  }

  // Add the data
  for (auto &event : status_events_1) {
    task_event_buffer_->AddTaskEvent(std::move(event));
  }
  for (auto &event : status_events_2) {
    task_event_buffer_->AddTaskEvent(std::move(event));
  }
  // Expect only limit in buffer.
  ASSERT_EQ(task_event_buffer_->GetNumTaskEventsStored(), num_limit_status_events);

  // Expect the reported data to match.
  auto task_gcs_accessor =
      static_cast<ray::gcs::MockGcsClient *>(task_event_buffer_->GetGcsClient())
          ->mock_task_accessor;

  if (to_gcs) {
    EXPECT_CALL(*task_gcs_accessor, AsyncAddTaskEventData(_, _))
        .WillOnce([&](std::unique_ptr<rpc::TaskEventData> actual_data,
                      ray::rpc::StatusCallback callback) {
          // Sort and compare
          CompareTaskEventData(*actual_data, expected_data);
          return Status::OK();
        });
  } else {
    EXPECT_CALL(*task_gcs_accessor, AsyncAddTaskEventData(_, _)).Times(0);
  }

  auto event_aggregator_client = static_cast<MockEventAggregatorClient *>(
      task_event_buffer_->event_aggregator_client_.get());
  if (to_aggregator) {
    rpc::events::AddEventsReply reply;
    Status status = Status::OK();
    EXPECT_CALL(*event_aggregator_client, AddEvents(_, _))
        .WillOnce(DoAll(
            Invoke([&](const rpc::events::AddEventsRequest &request,
                       const rpc::ClientCallback<rpc::events::AddEventsReply> &callback) {
              CompareRayEventsData(request.events_data(), expected_ray_events_data);
            }),
            MakeAction(
                new MockEventAggregatorAddEvents(std::move(status), std::move(reply)))));
  } else {
    EXPECT_CALL(*event_aggregator_client, AddEvents(_, _)).Times(0);
  }
  task_event_buffer_->FlushEvents(false);

  // Expect data flushed.
  ASSERT_EQ(task_event_buffer_->GetNumTaskEventsStored(), 0);
  ASSERT_EQ(task_event_buffer_->stats_counter_.Get(
                TaskEventBufferCounter::kNumTaskProfileEventDroppedSinceLastFlush),
            0);
  ASSERT_EQ(task_event_buffer_->stats_counter_.Get(
                TaskEventBufferCounter::kNumTaskStatusEventDroppedSinceLastFlush),
            0);
  ASSERT_EQ(task_event_buffer_->stats_counter_.Get(
                TaskEventBufferCounter::kTotalNumTaskProfileEventDropped),
            0);
  ASSERT_EQ(task_event_buffer_->stats_counter_.Get(
                TaskEventBufferCounter::kTotalNumTaskStatusEventDropped),
            num_status_dropped);
}

TEST_F(TaskEventBufferTestLimitProfileEvents, TestBufferSizeLimitProfileEvents) {
  size_t num_limit_profile_events = 20;  // sync with setup
  size_t num_profile_dropped = 20;

  // Generate 2 batches of events each, where batch 1 will be evicted by batch 2.
  std::vector<std::unique_ptr<TaskEvent>> profile_events_1;
  std::vector<std::unique_ptr<TaskEvent>> profile_events_2;

  // Generate data
  for (size_t i = 0; i < num_limit_profile_events; ++i) {
    profile_events_1.push_back(GenProfileTaskEvent(RandomTaskId(), 0));
    profile_events_2.push_back(GenProfileTaskEvent(RandomTaskId(), 0));
  }

  // Add the data
  for (auto &event : profile_events_1) {
    task_event_buffer_->AddTaskEvent(std::move(event));
  }
  for (auto &event : profile_events_2) {
    task_event_buffer_->AddTaskEvent(std::move(event));
  }

  // Expect only limit in buffer.
  ASSERT_EQ(task_event_buffer_->GetNumTaskEventsStored(), num_limit_profile_events);

  // Expect the reported data to match.
  auto task_gcs_accessor =
      static_cast<ray::gcs::MockGcsClient *>(task_event_buffer_->GetGcsClient())
          ->mock_task_accessor;

  EXPECT_CALL(*task_gcs_accessor, AsyncAddTaskEventData(_, _))
      .WillOnce([&](std::unique_ptr<rpc::TaskEventData> actual_data,
                    ray::rpc::StatusCallback callback) {
        EXPECT_EQ(actual_data->num_profile_events_dropped(), num_profile_dropped);
        EXPECT_EQ(actual_data->events_by_task_size(), num_limit_profile_events);
        return Status::OK();
      });

  task_event_buffer_->FlushEvents(false);

  // Expect data flushed.
  ASSERT_EQ(task_event_buffer_->GetNumTaskEventsStored(), 0);
  ASSERT_EQ(task_event_buffer_->stats_counter_.Get(
                TaskEventBufferCounter::kNumTaskProfileEventDroppedSinceLastFlush),
            0);
  ASSERT_EQ(task_event_buffer_->stats_counter_.Get(
                TaskEventBufferCounter::kNumTaskStatusEventDroppedSinceLastFlush),
            0);
  ASSERT_EQ(task_event_buffer_->stats_counter_.Get(
                TaskEventBufferCounter::kTotalNumTaskProfileEventDropped),
            num_profile_dropped);
  ASSERT_EQ(task_event_buffer_->stats_counter_.Get(
                TaskEventBufferCounter::kTotalNumTaskStatusEventDropped),
            0);
}

TEST_F(TaskEventBufferTestLimitProfileEvents, TestLimitProfileEventsPerTask) {
  size_t num_profile_events_per_task = 10;
  size_t num_total_profile_events = 1000;
  std::vector<std::unique_ptr<TaskEvent>> profile_events;
  auto task_id = RandomTaskId();

  // Generate data for the same task attempts.
  for (size_t i = 0; i < num_total_profile_events; ++i) {
    profile_events.push_back(GenProfileTaskEvent(task_id, 0));
  }

  // Add all
  for (auto &event : profile_events) {
    task_event_buffer_->AddTaskEvent(std::move(event));
  }

  // Assert dropped count
  task_event_buffer_->FlushEvents(false);
  ASSERT_EQ(task_event_buffer_->stats_counter_.Get(
                TaskEventBufferCounter::kTotalNumTaskProfileEventDropped),
            num_total_profile_events - num_profile_events_per_task);
  ASSERT_EQ(task_event_buffer_->stats_counter_.Get(
                TaskEventBufferCounter::kTotalNumTaskStatusEventDropped),
            0);
}

TEST_F(TaskEventBufferTest, TestIsDebuggerPausedFlag) {
  // Generate the event
  auto task_id = RandomTaskId();
  TaskStatusEvent::TaskStateUpdate state_update(true);
  auto task_event = GenStatusTaskEvent(task_id, 0, 1, state_update);

  // Convert to rpc
  rpc::TaskEventData expected_data;
  expected_data.set_num_profile_events_dropped(0);
  auto event = expected_data.add_events_by_task();
  task_event->ToRpcTaskEvents(event);

  // Verify the flag is set
  ASSERT_TRUE(event->state_updates().is_debugger_paused());
}

TEST_F(TaskEventBufferTest, TestTaskLogInfoInLifecycleEvent) {
  // Create task log info
  rpc::TaskLogInfo task_log_info;
  task_log_info.set_stdout_file("/tmp/stdout.log");
  task_log_info.set_stderr_file("/tmp/stderr.log");
  task_log_info.set_stdout_start(0);
  task_log_info.set_stdout_end(100);
  task_log_info.set_stderr_start(0);
  task_log_info.set_stderr_end(50);

  // Generate the event
  auto task_id = RandomTaskId();
  TaskStatusEvent::TaskStateUpdate state_update(task_log_info);
  auto task_event = GenStatusTaskEvent(task_id, 0, 1, state_update);

  // Convert to RayEvents format
  RayEventsTuple ray_events_tuple;
  task_event->ToRpcRayEvents(ray_events_tuple);

  // Verify the lifecycle event has task_log_info
  ASSERT_TRUE(ray_events_tuple.task_lifecycle_event.has_value());
  const auto &lifecycle_event =
      ray_events_tuple.task_lifecycle_event->task_lifecycle_event();
  ASSERT_TRUE(lifecycle_event.has_task_log_info());

  const auto &log_info = lifecycle_event.task_log_info();
  EXPECT_EQ(log_info.stdout_file(), "/tmp/stdout.log");
  EXPECT_EQ(log_info.stderr_file(), "/tmp/stderr.log");
  EXPECT_EQ(log_info.stdout_start(), 0);
  EXPECT_EQ(log_info.stdout_end(), 100);
  EXPECT_EQ(log_info.stderr_start(), 0);
  EXPECT_EQ(log_info.stderr_end(), 50);
}

// Tests that TaskLifecycleEvent.node_id is only set to the executor's node ID
// (available at SUBMITTED_TO_WORKER), never the submitter's node ID.
TEST_F(TaskEventBufferTest, TestTaskLifecycleEventNodeId) {
  auto task_id = RandomTaskId();
  NodeID submitter_node_id = NodeID::FromRandom();
  NodeID executor_node_id = NodeID::FromRandom();

  // For SUBMITTED_TO_WORKER, node_id should be set to the executor's node (not the
  // submitter's).
  {
    TaskStatusEvent::TaskStateUpdate submitted_state_update(executor_node_id,
                                                            WorkerID::FromRandom());
    auto submitted_event =
        std::make_unique<TaskStatusEvent>(task_id,
                                          JobID::FromInt(0),
                                          /*attempt_number=*/0,
                                          rpc::TaskStatus::SUBMITTED_TO_WORKER,
                                          /*timestamp=*/1,
                                          /*is_actor_task_event=*/false,
                                          "test_session_name",
                                          submitter_node_id,
                                          nullptr,
                                          submitted_state_update);

    RayEventsTuple submitted_ray_events;
    submitted_event->ToRpcRayEvents(submitted_ray_events);
    ASSERT_TRUE(submitted_ray_events.task_lifecycle_event.has_value());
    const auto &submitted_lifecycle =
        submitted_ray_events.task_lifecycle_event->task_lifecycle_event();
    EXPECT_EQ(submitted_lifecycle.node_id(), executor_node_id.Binary())
        << "node_id should be the executor's node for SUBMITTED_TO_WORKER";
    EXPECT_NE(submitted_lifecycle.node_id(), submitter_node_id.Binary())
        << "node_id should not be the submitter's node";
  }

  // For RUNNING (no state_update node_id), node_id should NOT be set — the submitter's
  // node must not leak into the lifecycle event's node_id field.
  {
    auto task_event = std::make_unique<TaskStatusEvent>(task_id,
                                                        JobID::FromInt(0),
                                                        /*attempt_number=*/0,
                                                        rpc::TaskStatus::RUNNING,
                                                        /*timestamp=*/2,
                                                        /*is_actor_task_event=*/false,
                                                        "test_session_name",
                                                        submitter_node_id,
                                                        nullptr,
                                                        /*state_update=*/absl::nullopt);

    RayEventsTuple ray_events_tuple;
    task_event->ToRpcRayEvents(ray_events_tuple);
    ASSERT_TRUE(ray_events_tuple.task_lifecycle_event.has_value());
    const auto &lifecycle_event =
        ray_events_tuple.task_lifecycle_event->task_lifecycle_event();
    EXPECT_TRUE(lifecycle_event.node_id().empty())
        << "node_id should not be set to the submitter's node in lifecycle event";
  }
}

TEST_F(TaskEventBufferTest, TestGracefulDestruction) {
  delete task_event_buffer_.release();
}

TEST_F(TaskEventBufferTest, TestTaskProfileEventToRpcRayEvents) {
  auto task_id = RandomTaskId();
  auto job_id = JobID::FromInt(123);
  int32_t attempt_number = 1;
  std::string component_type = "core_worker";
  std::string component_id = "worker_123";
  std::string node_ip = "127.0.0.1";
  std::string event_name = "test_profile_event";
  int64_t start_time = 1000;

  auto profile_event = std::make_unique<TaskProfileEvent>(task_id,
                                                          job_id,
                                                          attempt_number,
                                                          component_type,
                                                          component_id,
                                                          node_ip,
                                                          event_name,
                                                          start_time,
                                                          "test_session_name",
                                                          NodeID::Nil());

  // Set end time and extra data to test full population
  profile_event->SetEndTime(2000);
  profile_event->SetExtraData("test_extra_data");

  RayEventsTuple ray_events_tuple;
  profile_event->ToRpcRayEvents(ray_events_tuple);

  // Verify that the second event is nullopt (empty)
  EXPECT_FALSE(ray_events_tuple.task_definition_event.has_value())
      << "TaskProfileEvent should be populated in RayEventsTuple";
  EXPECT_FALSE(ray_events_tuple.task_lifecycle_event.has_value())
      << "TaskProfileEvent should be populated in RayEventsTuple";

  // Verify that the first event contains the profile event
  ASSERT_TRUE(ray_events_tuple.task_profile_event.has_value())
      << "TaskProfileEvent should populate in RayEventsTuple";

  const auto &ray_event = ray_events_tuple.task_profile_event.value();

  // Verify base fields
  EXPECT_EQ(ray_event.source_type(), rpc::events::RayEvent::CORE_WORKER);
  EXPECT_EQ(ray_event.event_type(), rpc::events::RayEvent::TASK_PROFILE_EVENT);
  EXPECT_EQ(ray_event.severity(), rpc::events::RayEvent::INFO);
  EXPECT_FALSE(ray_event.event_id().empty());
  EXPECT_EQ(ray_event.session_name(), "test_session_name");

  // Verify task profile events are populated
  ASSERT_TRUE(ray_event.has_task_profile_events());
  const auto &task_profile_events = ray_event.task_profile_events();

  EXPECT_EQ(task_profile_events.task_id(), task_id.Binary());
  EXPECT_EQ(task_profile_events.job_id(), job_id.Binary());
  EXPECT_EQ(task_profile_events.attempt_number(), attempt_number);

  // Verify profile event
  ASSERT_TRUE(task_profile_events.has_profile_events());
  const auto &profile_events = task_profile_events.profile_events();

  EXPECT_EQ(profile_events.component_type(), component_type);
  EXPECT_EQ(profile_events.component_id(), component_id);
  EXPECT_EQ(profile_events.node_ip_address(), node_ip);

  // Verify event entry
  ASSERT_EQ(profile_events.events_size(), 1);
  const auto &event_entry = profile_events.events(0);

  EXPECT_EQ(event_entry.event_name(), event_name);
  EXPECT_EQ(event_entry.start_time(), start_time);
  EXPECT_EQ(event_entry.end_time(), 2000);
  EXPECT_EQ(event_entry.extra_data(), "test_extra_data");
}

TEST_F(TaskEventBufferTest, TestTaskProfileEventDefaultExtraDataIsEmptyJson) {
  // A profile event that is flushed without SetExtraData ever being called
  // (e.g. task:execute events that are not populated with extra data) must
  // still serialize a valid-JSON extra_data. An empty string is not valid JSON
  // and makes consumers that json-parse the field (the state API) fail on the
  // whole request. The default must be "{}".
  auto make_event = [](const std::string &event_name) {
    return std::make_unique<TaskProfileEvent>(RandomTaskId(),
                                              JobID::FromInt(123),
                                              /*attempt_number=*/1,
                                              /*component_type=*/"core_worker",
                                              /*component_id=*/"worker_123",
                                              /*node_ip_address=*/"127.0.0.1",
                                              event_name,
                                              /*start_time=*/1000,
                                              /*session_name=*/"test_session_name",
                                              NodeID::Nil());
  };

  // State API path: ToRpcTaskEvents (rpc::TaskEvents consumed via GCS).
  {
    auto profile_event = make_event("task:execute");
    profile_event->SetEndTime(2000);
    // Intentionally do NOT call SetExtraData.

    rpc::TaskEvents task_events;
    profile_event->ToRpcTaskEvents(&task_events);

    ASSERT_EQ(task_events.profile_events().events_size(), 1);
    EXPECT_EQ(task_events.profile_events().events(0).extra_data(), "{}");
  }

  // RayEvents path: ToRpcRayEvents.
  {
    auto profile_event = make_event("task:execute");
    profile_event->SetEndTime(2000);
    // Intentionally do NOT call SetExtraData.

    RayEventsTuple ray_events_tuple;
    profile_event->ToRpcRayEvents(ray_events_tuple);

    ASSERT_TRUE(ray_events_tuple.task_profile_event.has_value());
    const auto &profile_events =
        ray_events_tuple.task_profile_event->task_profile_events().profile_events();
    ASSERT_EQ(profile_events.events_size(), 1);
    EXPECT_EQ(profile_events.events(0).extra_data(), "{}");
  }
}

TEST_F(TaskEventBufferTest, TestTaskProfileEventToRpcRayEventsMultipleEvents) {
  auto task_id = RandomTaskId();
  auto job_id = JobID::FromInt(123);
  int32_t attempt_number = 1;
  std::string component_type = "core_worker";
  std::string component_id = "worker_123";
  std::string node_ip = "127.0.0.1";

  // Create first profile event
  auto profile_event1 = std::make_unique<TaskProfileEvent>(task_id,
                                                           job_id,
                                                           attempt_number,
                                                           component_type,
                                                           component_id,
                                                           node_ip,
                                                           "task:deserialize_arguments",
                                                           1000,
                                                           "test_session_name",
                                                           NodeID::Nil());
  profile_event1->SetEndTime(2000);
  profile_event1->SetExtraData("extra_data_1");

  // Create second profile event
  auto profile_event2 = std::make_unique<TaskProfileEvent>(task_id,
                                                           job_id,
                                                           attempt_number,
                                                           component_type,
                                                           component_id,
                                                           node_ip,
                                                           "task:execute",
                                                           2000,
                                                           "test_session_name",
                                                           NodeID::Nil());
  profile_event2->SetEndTime(3000);
  profile_event2->SetExtraData("extra_data_2");

  // Create third profile event
  auto profile_event3 = std::make_unique<TaskProfileEvent>(task_id,
                                                           job_id,
                                                           attempt_number,
                                                           component_type,
                                                           component_id,
                                                           node_ip,
                                                           "task:store_outputs",
                                                           3000,
                                                           "test_session_name",
                                                           NodeID::Nil());
  profile_event3->SetEndTime(4000);
  profile_event3->SetExtraData("extra_data_3");

  // Convert all events to the same RayEventsTuple
  RayEventsTuple ray_events_tuple;
  profile_event1->ToRpcRayEvents(ray_events_tuple);
  profile_event2->ToRpcRayEvents(ray_events_tuple);
  profile_event3->ToRpcRayEvents(ray_events_tuple);

  // Verify that only the profile event is populated
  EXPECT_FALSE(ray_events_tuple.task_definition_event.has_value());
  EXPECT_FALSE(ray_events_tuple.task_lifecycle_event.has_value());
  ASSERT_TRUE(ray_events_tuple.task_profile_event.has_value());

  const auto &ray_event = ray_events_tuple.task_profile_event.value();

  // Verify base fields
  EXPECT_EQ(ray_event.source_type(), rpc::events::RayEvent::CORE_WORKER);
  EXPECT_EQ(ray_event.event_type(), rpc::events::RayEvent::TASK_PROFILE_EVENT);
  EXPECT_EQ(ray_event.severity(), rpc::events::RayEvent::INFO);
  EXPECT_FALSE(ray_event.event_id().empty());
  EXPECT_EQ(ray_event.session_name(), "test_session_name");

  // Verify task profile events are populated
  ASSERT_TRUE(ray_event.has_task_profile_events());
  const auto &task_profile_events = ray_event.task_profile_events();

  EXPECT_EQ(task_profile_events.task_id(), task_id.Binary());
  EXPECT_EQ(task_profile_events.job_id(), job_id.Binary());
  EXPECT_EQ(task_profile_events.attempt_number(), attempt_number);

  // Verify all 3 profile events are present
  ASSERT_TRUE(task_profile_events.has_profile_events());
  const auto &profile_events = task_profile_events.profile_events();

  EXPECT_EQ(profile_events.component_type(), component_type);
  EXPECT_EQ(profile_events.component_id(), component_id);
  EXPECT_EQ(profile_events.node_ip_address(), node_ip);

  // Verify there are 3 events
  ASSERT_EQ(profile_events.events_size(), 3);

  // Check each event entry
  const auto &event_entry1 = profile_events.events(0);
  EXPECT_EQ(event_entry1.event_name(), "task:deserialize_arguments");
  EXPECT_EQ(event_entry1.start_time(), 1000);
  EXPECT_EQ(event_entry1.end_time(), 2000);
  EXPECT_EQ(event_entry1.extra_data(), "extra_data_1");

  const auto &event_entry2 = profile_events.events(1);
  EXPECT_EQ(event_entry2.event_name(), "task:execute");
  EXPECT_EQ(event_entry2.start_time(), 2000);
  EXPECT_EQ(event_entry2.end_time(), 3000);
  EXPECT_EQ(event_entry2.extra_data(), "extra_data_2");

  const auto &event_entry3 = profile_events.events(2);
  EXPECT_EQ(event_entry3.event_name(), "task:store_outputs");
  EXPECT_EQ(event_entry3.start_time(), 3000);
  EXPECT_EQ(event_entry3.end_time(), 4000);
  EXPECT_EQ(event_entry3.extra_data(), "extra_data_3");
}

TEST_F(TaskEventBufferTest, TestCreateRayEventsDataWithProfileEvents) {
  // Test that CreateRayEventsDataToSend correctly handles profile events
  // by only including the first element of RayEventsPair

  auto task_id = RandomTaskId();
  auto job_id = JobID::FromInt(456);
  int32_t attempt_number = 2;

  // Create a profile event
  auto profile_event = std::make_unique<TaskProfileEvent>(task_id,
                                                          job_id,
                                                          attempt_number,
                                                          "core_worker",
                                                          "worker_456",
                                                          "192.168.1.2",
                                                          "profile_test",
                                                          5000,
                                                          "test_session_name",
                                                          NodeID::Nil());
  profile_event->SetEndTime(6000);

  absl::flat_hash_map<TaskAttempt, RayEventsTuple> agg_ray_events;
  TaskAttempt task_attempt = std::make_pair(task_id, attempt_number);

  // Populate the ray events pair
  RayEventsTuple ray_events_tuple;
  profile_event->ToRpcRayEvents(ray_events_tuple);
  agg_ray_events[task_attempt] = std::move(ray_events_tuple);

  // Create the data using the real implementation
  absl::flat_hash_set<TaskAttempt> dropped_task_attempts;
  auto ray_events_data = task_event_buffer_->CreateRayEventsDataToSend(
      std::move(agg_ray_events), dropped_task_attempts);

  // Verify that exactly one event was added (only the profile event, not the nullopt
  // second)
  ASSERT_EQ(ray_events_data->events_size(), 1);

  const auto &event = ray_events_data->events(0);
  EXPECT_EQ(event.event_type(), rpc::events::RayEvent::TASK_PROFILE_EVENT);
  EXPECT_EQ(event.session_name(), "test_session_name");
  EXPECT_TRUE(event.has_task_profile_events());

  const auto &task_profile_events = event.task_profile_events();
  EXPECT_EQ(task_profile_events.task_id(), task_id.Binary());
  EXPECT_EQ(task_profile_events.job_id(), job_id.Binary());
  EXPECT_EQ(task_profile_events.attempt_number(), attempt_number);
}

TEST_P(TaskEventBufferTestDifferentDestination,
       TestMixedStatusAndProfileEventsToRayEvents) {
  // Test that a mix of status events and profile events are correctly handled
  const auto [to_gcs, to_aggregator] = GetParam();

  // Generate the task id and job id
  auto task_id = RandomTaskId();
  auto job_id = JobID::FromInt(789);

  auto make_profile_event = [&]() {
    return std::make_unique<TaskProfileEvent>(task_id,
                                              job_id,
                                              1,
                                              "core_worker",
                                              "worker_789",
                                              "192.168.1.3",
                                              "mixed_test",
                                              7000,
                                              "test_session_name",
                                              NodeID::Nil());
  };

  // Create a status event (should populate both elements of RayEventsPair) and a
  // profile event (should populate only the first). These are the events that get
  // flushed to produce the actual data.
  auto status_event = GenStatusTaskEvent(task_id, 1, 1000);
  auto profile_event = make_profile_event();

  // Build the expected data from SEPARATE, identically-constructed instances:
  // ToRpcRayEvents/ToRpcTaskExportEvents move fields out of the event (e.g.
  // extra_data), so serializing is destructive and must not run on the same
  // objects that are later flushed for the actual data.
  auto status_event_expected = GenStatusTaskEvent(task_id, 1, 1000);
  auto profile_event_expected = make_profile_event();

  // Expect data flushed match. Generate the expected data
  rpc::TaskEventData expected_task_event_data;
  rpc::events::RayEventsData expected_ray_events_data;
  auto event = expected_task_event_data.add_events_by_task();
  status_event_expected->ToRpcTaskEvents(event);
  profile_event_expected->ToRpcTaskEvents(event);

  RayEventsTuple ray_events_tuple;
  status_event_expected->ToRpcRayEvents(ray_events_tuple);
  profile_event_expected->ToRpcRayEvents(ray_events_tuple);
  if (ray_events_tuple.task_definition_event) {
    auto new_event = expected_ray_events_data.add_events();
    *new_event = std::move(ray_events_tuple.task_definition_event.value());
  }
  if (ray_events_tuple.task_lifecycle_event) {
    auto new_event = expected_ray_events_data.add_events();
    *new_event = std::move(ray_events_tuple.task_lifecycle_event.value());
  }
  if (ray_events_tuple.task_profile_event) {
    auto new_event = expected_ray_events_data.add_events();
    *new_event = std::move(ray_events_tuple.task_profile_event.value());
  }

  // Add Events to the task event buffer
  task_event_buffer_->AddTaskEvent(std::move(status_event));
  task_event_buffer_->AddTaskEvent(std::move(profile_event));
  ASSERT_EQ(task_event_buffer_->GetNumTaskEventsStored(), 2);

  // Manually call flush should call GCS client's flushing grpc.
  auto task_gcs_accessor =
      static_cast<ray::gcs::MockGcsClient *>(task_event_buffer_->GetGcsClient())
          ->mock_task_accessor;
  if (to_gcs) {
    EXPECT_CALL(*task_gcs_accessor, AsyncAddTaskEventData(_, _))
        .WillOnce([&](std::unique_ptr<rpc::TaskEventData> actual_data,
                      ray::rpc::StatusCallback callback) {
          CompareTaskEventData(*actual_data, expected_task_event_data);
          return Status::OK();
        });
  } else {
    EXPECT_CALL(*task_gcs_accessor, AsyncAddTaskEventData(_, _)).Times(0);
  }

  // If ray events to aggregator is enabled, expect to call AddEvents grpc.
  auto event_aggregator_client = static_cast<MockEventAggregatorClient *>(
      task_event_buffer_->event_aggregator_client_.get());
  rpc::events::AddEventsRequest add_events_request;
  if (to_aggregator) {
    rpc::events::AddEventsReply reply;
    Status status = Status::OK();
    EXPECT_CALL(*event_aggregator_client, AddEvents(_, _))
        .WillOnce(DoAll(
            Invoke([&](const rpc::events::AddEventsRequest &request,
                       const rpc::ClientCallback<rpc::events::AddEventsReply> &callback) {
              CompareRayEventsData(request.events_data(), expected_ray_events_data);
            }),
            MakeAction(
                new MockEventAggregatorAddEvents(std::move(status), std::move(reply)))));
  } else {
    EXPECT_CALL(*event_aggregator_client, AddEvents(_, _)).Times(0);
  }

  // Flush events
  task_event_buffer_->FlushEvents(false);

  // Expect no more events.
  ASSERT_EQ(task_event_buffer_->GetNumTaskEventsStored(), 0);
}

// Test that Stop() flushes all buffered events before shutting down.
// This verifies the fix for https://github.com/ray-project/ray/issues/60218
TEST_P(TaskEventBufferTestDifferentDestination, TestStopFlushesEvents) {
  const auto [to_gcs, to_aggregator] = GetParam();

  // Add some events using GenFullStatusTaskEvent like other tests
  size_t num_events = 10;
  auto task_ids = GenTaskIDs(num_events);
  for (const auto &task_id : task_ids) {
    task_event_buffer_->AddTaskEvent(GenFullStatusTaskEvent(task_id, 0));
  }

  ASSERT_EQ(task_event_buffer_->GetNumTaskEventsStored(), num_events);

  auto task_gcs_accessor =
      static_cast<ray::gcs::MockGcsClient *>(task_event_buffer_->GetGcsClient())
          ->mock_task_accessor;

  if (to_gcs) {
    EXPECT_CALL(*task_gcs_accessor, AsyncAddTaskEventData(_, _))
        .WillOnce([](std::unique_ptr<rpc::TaskEventData> actual_data,
                     ray::rpc::StatusCallback callback) {
          // Verify that events are being flushed during Stop()
          EXPECT_GT(actual_data->events_by_task_size(), 0);
          return Status::OK();
        });
  } else {
    EXPECT_CALL(*task_gcs_accessor, AsyncAddTaskEventData(_, _)).Times(0);
  }

  auto event_aggregator_client = static_cast<MockEventAggregatorClient *>(
      task_event_buffer_->event_aggregator_client_.get());

  if (to_aggregator) {
    EXPECT_CALL(*event_aggregator_client, AddEvents(_, _))
        .WillOnce([](const rpc::events::AddEventsRequest &request,
                     const rpc::ClientCallback<rpc::events::AddEventsReply> &callback) {
          // Verify that events are being flushed during Stop()
          EXPECT_GT(request.events_data().events_size(), 0);
        });
  } else {
    EXPECT_CALL(*event_aggregator_client, AddEvents(_, _)).Times(0);
  }

  // Calling Stop() should flush all events - this is the key verification.
  // The EXPECT_CALL assertions above verify that FlushEvents is called during Stop().
  // Note: The test will wait up to task_events_shutdown_flush_timeout_ms (100ms in tests)
  // for gRPC to complete. Since we don't invoke the callback, it will timeout but
  // the test verifies that flush was attempted.
  task_event_buffer_->Stop();
}

// Test that Stop() waits for in-flight gRPC to complete, then performs final flush.
// This ensures no events are lost during shutdown.
TEST_P(TaskEventBufferTestDifferentDestination, TestStopWaitsForInflightThenFlushes) {
  const auto [to_gcs, to_aggregator] = GetParam();
  if (!to_gcs && !to_aggregator) {
    GTEST_SKIP();
  }

  task_event_buffer_->AddTaskEvent(GenFullStatusTaskEvent(RandomTaskId(), 0));
  task_event_buffer_->AddTaskEvent(GenFullStatusTaskEvent(RandomTaskId(), 0));

  auto task_gcs_accessor =
      static_cast<ray::gcs::MockGcsClient *>(task_event_buffer_->GetGcsClient())
          ->mock_task_accessor;
  ray::rpc::StatusCallback gcs_callback;
  std::atomic_bool gcs_callback_set = false;
  ray::rpc::StatusCallback gcs_callback_2;
  std::atomic_bool gcs_callback_2_set = false;

  if (to_gcs) {
    // Expect 2 calls: first from FlushEvents(), second from Stop() after waiting
    EXPECT_CALL(*task_gcs_accessor, AsyncAddTaskEventData(_, _))
        .Times(2)
        .WillOnce([&](std::unique_ptr<rpc::TaskEventData> actual_data,
                      ray::rpc::StatusCallback callback) {
          EXPECT_GT(actual_data->events_by_task_size(), 0);
          gcs_callback = std::move(callback);
          gcs_callback_set = true;
          return Status::OK();
        })
        .WillOnce([&](std::unique_ptr<rpc::TaskEventData> actual_data,
                      ray::rpc::StatusCallback callback) {
          // This is the final flush from Stop() - should contain the events added
          // while the first flush was in progress
          EXPECT_GT(actual_data->events_by_task_size(), 0);
          gcs_callback_2 = std::move(callback);
          gcs_callback_2_set = true;
          return Status::OK();
        });
  } else {
    EXPECT_CALL(*task_gcs_accessor, AsyncAddTaskEventData(_, _)).Times(0);
  }

  auto event_aggregator_client = static_cast<MockEventAggregatorClient *>(
      task_event_buffer_->event_aggregator_client_.get());
  rpc::ClientCallback<rpc::events::AddEventsReply> aggregator_callback;
  std::atomic_bool aggregator_callback_set = false;
  rpc::ClientCallback<rpc::events::AddEventsReply> aggregator_callback_2;
  std::atomic_bool aggregator_callback_2_set = false;

  if (to_aggregator) {
    // Expect 2 calls: first from FlushEvents(), second from Stop() after waiting
    EXPECT_CALL(*event_aggregator_client, AddEvents(_, _))
        .Times(2)
        .WillOnce([&](const rpc::events::AddEventsRequest &request,
                      const rpc::ClientCallback<rpc::events::AddEventsReply> &callback) {
          EXPECT_GT(request.events_data().events_size(), 0);
          aggregator_callback = callback;
          aggregator_callback_set = true;
        })
        .WillOnce([&](const rpc::events::AddEventsRequest &request,
                      const rpc::ClientCallback<rpc::events::AddEventsReply> &callback) {
          // This is the final flush from Stop() - should contain the events added
          // while the first flush was in progress
          EXPECT_GT(request.events_data().events_size(), 0);
          aggregator_callback_2 = callback;
          aggregator_callback_2_set = true;
        });
  } else {
    EXPECT_CALL(*event_aggregator_client, AddEvents(_, _)).Times(0);
  }

  // Trigger first flush - this starts the gRPC call
  task_event_buffer_->FlushEvents(false);

  // Add more events while flush is in progress
  task_event_buffer_->AddTaskEvent(GenFullStatusTaskEvent(RandomTaskId(), 0));

  // Stop() should wait for in-flight gRPC, then perform final flush
  std::thread stop_thread([&]() { task_event_buffer_->Stop(); });
  std::this_thread::sleep_for(std::chrono::milliseconds(10));

  // Complete the first in-flight gRPC calls - this unblocks Stop() to do the final flush
  if (to_gcs) {
    ASSERT_TRUE(gcs_callback_set.load());
    gcs_callback(Status::OK());
  }
  if (to_aggregator) {
    ASSERT_TRUE(aggregator_callback_set.load());
    aggregator_callback(Status::OK(), rpc::events::AddEventsReply{});
  }

  // Wait for the second flush to be triggered
  std::this_thread::sleep_for(std::chrono::milliseconds(10));

  // Complete the second gRPC calls from the final flush
  if (to_gcs) {
    ASSERT_TRUE(gcs_callback_2_set.load());
    gcs_callback_2(Status::OK());
  }
  if (to_aggregator) {
    ASSERT_TRUE(aggregator_callback_2_set.load());
    aggregator_callback_2(Status::OK(), rpc::events::AddEventsReply{});
  }

  stop_thread.join();
}

// Test that metadata-only payloads (dropped task attempts) are still sent.
TEST_P(TaskEventBufferTestDroppedAttemptsOnly,
       TestFlushSendsDroppedAttemptsWithoutEvents) {
  const auto [to_gcs, to_aggregator] = GetParam();
  if (!to_gcs && !to_aggregator) {
    GTEST_SKIP();
  }

  for (size_t i = 0; i < 3; ++i) {
    task_event_buffer_->AddTaskEvent(GenStatusTaskEvent(RandomTaskId(), 0));
  }

  auto task_gcs_accessor =
      static_cast<ray::gcs::MockGcsClient *>(task_event_buffer_->GetGcsClient())
          ->mock_task_accessor;
  if (to_gcs) {
    EXPECT_CALL(*task_gcs_accessor, AsyncAddTaskEventData(_, _))
        .Times(2)
        .WillOnce([&](std::unique_ptr<rpc::TaskEventData> actual_data,
                      ray::rpc::StatusCallback callback) {
          EXPECT_GT(actual_data->events_by_task_size(), 0);
          EXPECT_EQ(actual_data->dropped_task_attempts_size(), 1);
          callback(Status::OK());
          return Status::OK();
        })
        .WillOnce([&](std::unique_ptr<rpc::TaskEventData> actual_data,
                      ray::rpc::StatusCallback callback) {
          EXPECT_EQ(actual_data->events_by_task_size(), 0);
          EXPECT_EQ(actual_data->dropped_task_attempts_size(), 1);
          callback(Status::OK());
          return Status::OK();
        });
  } else {
    EXPECT_CALL(*task_gcs_accessor, AsyncAddTaskEventData(_, _)).Times(0);
  }

  auto event_aggregator_client = static_cast<MockEventAggregatorClient *>(
      task_event_buffer_->event_aggregator_client_.get());
  if (to_aggregator) {
    EXPECT_CALL(*event_aggregator_client, AddEvents(_, _))
        .Times(2)
        .WillOnce([&](const rpc::events::AddEventsRequest &request,
                      const rpc::ClientCallback<rpc::events::AddEventsReply> &callback) {
          EXPECT_GT(request.events_data().events_size(), 0);
          EXPECT_EQ(
              request.events_data().task_events_metadata().dropped_task_attempts_size(),
              1);
          callback(Status::OK(), rpc::events::AddEventsReply{});
        })
        .WillOnce([&](const rpc::events::AddEventsRequest &request,
                      const rpc::ClientCallback<rpc::events::AddEventsReply> &callback) {
          EXPECT_EQ(request.events_data().events_size(), 0);
          EXPECT_EQ(
              request.events_data().task_events_metadata().dropped_task_attempts_size(),
              1);
          callback(Status::OK(), rpc::events::AddEventsReply{});
        });
  } else {
    EXPECT_CALL(*event_aggregator_client, AddEvents(_, _)).Times(0);
  }

  task_event_buffer_->FlushEvents(false);
  task_event_buffer_->FlushEvents(false);
}

// Manual-start fixture parameterized on whether the RayTaskEventRecorder is enabled. Each
// test sets the flag combination before calling Start() so it can observe how the flag
// flips the buffer's own aggregator send.
class TaskEventBufferTestRecorderSwitch : public TaskEventBufferTest,
                                          public ::testing::WithParamInterface<bool> {
  void SetUp() override {}
};

// The recorder flag flips the buffer's legacy aggregator send: when the recorder takes
// over (enable_ray_task_event_recorder + enable_ray_event), the buffer must NOT send to
// the aggregator; when the recorder is off (with the buffer's own aggregator flag on),
// the buffer DOES send.
TEST_P(TaskEventBufferTestRecorderSwitch, TestRecorderTakesOverAggregatorSend) {
  const bool recorder_enabled = GetParam();
  std::string recorder_str = recorder_enabled ? "true" : "false";
  RayConfig::instance().initialize(
      R"(
{
  "task_events_report_interval_ms": 1000,
  "task_events_max_num_status_events_buffer_on_worker": 100,
  "task_events_send_batch_size": 100,
  "task_events_shutdown_flush_timeout_ms": 100,
  "enable_core_worker_task_event_to_gcs": false,
  "enable_ray_event": )" +
      recorder_str + R"(,
  "enable_ray_task_event_recorder": )" +
      recorder_str + R"(,
  "enable_core_worker_ray_event_to_aggregator": true
}
  )");
  RAY_CHECK_OK(task_event_buffer_->Start(/*auto_flush=*/false));

  task_event_buffer_->AddTaskEvent(GenFullStatusTaskEvent(RandomTaskId(), 0));

  // GCS send is off in both cases; only the aggregator send is being switched.
  auto task_gcs_accessor =
      static_cast<ray::gcs::MockGcsClient *>(task_event_buffer_->GetGcsClient())
          ->mock_task_accessor;
  EXPECT_CALL(*task_gcs_accessor, AsyncAddTaskEventData(_, _)).Times(0);

  auto event_aggregator_client = static_cast<MockEventAggregatorClient *>(
      task_event_buffer_->event_aggregator_client_.get());
  // When the recorder is active it owns the aggregator send, so the buffer's own send is
  // suppressed; otherwise the buffer's legacy aggregator send fires.
  EXPECT_CALL(*event_aggregator_client, AddEvents(_, _)).Times(recorder_enabled ? 0 : 1);

  task_event_buffer_->FlushEvents(false);
}

INSTANTIATE_TEST_SUITE_P(TaskEventBufferTest,
                         TaskEventBufferTestRecorderSwitch,
                         ::testing::Values(true, false));

INSTANTIATE_TEST_SUITE_P(TaskEventBufferTest,
                         TaskEventBufferTestDifferentDestination,
                         ::testing::Values(DifferentDestination{true, true},
                                           DifferentDestination{true, false},
                                           DifferentDestination{false, true}));

INSTANTIATE_TEST_SUITE_P(TaskEventBufferTest,
                         TaskEventBufferTestBatchSendDifferentDestination,
                         ::testing::Values(DifferentDestination{true, true},
                                           DifferentDestination{true, false},
                                           DifferentDestination{false, true}));

INSTANTIATE_TEST_SUITE_P(TaskEventBufferTest,
                         TaskEventBufferTestDroppedAttemptsOnly,
                         ::testing::Values(DifferentDestination{true, true},
                                           DifferentDestination{true, false},
                                           DifferentDestination{false, true}));

INSTANTIATE_TEST_SUITE_P(TaskEventBufferTest,
                         TaskEventBufferTestLimitBufferDifferentDestination,
                         ::testing::Values(DifferentDestination{true, true},
                                           DifferentDestination{true, false},
                                           DifferentDestination{false, true}));

}  // namespace worker

}  // namespace core

}  // namespace ray
