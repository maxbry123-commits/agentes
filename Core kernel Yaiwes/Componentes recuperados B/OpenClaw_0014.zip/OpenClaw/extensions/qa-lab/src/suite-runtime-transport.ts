// Qa Lab plugin module implements suite runtime transport behavior.
import { setTimeout as sleep } from "node:timers/promises";
import {
  findFailureOutboundMessage as findTransportFailureOutboundMessage,
  waitForQaTransportCondition,
  type QaTransportState,
} from "./qa-transport.js";
import { extractQaFailureReplyText } from "./reply-failure.js";
import type { QaBusMessage } from "./runtime-api.js";

type WaitForNoOutboundOptions = {
  sinceIndex?: number;
};

function findFailureOutboundMessage(
  state: QaTransportState,
  options?: { accountId?: string; sinceIndex?: number; cursorSpace?: "all" | "outbound" },
) {
  return findTransportFailureOutboundMessage(state, options);
}

async function waitForOutboundMessage(
  state: QaTransportState,
  predicate: (message: QaBusMessage) => boolean,
  timeoutMs = 15_000,
  options?: { accountId?: string; sinceIndex?: number },
) {
  return await waitForQaTransportCondition(() => {
    const failureMessage = findFailureOutboundMessage(state, options);
    if (failureMessage) {
      throw new Error(extractQaFailureReplyText(failureMessage) ?? failureMessage.text);
    }
    const match = state
      .getSnapshot()
      .messages.filter((message: QaBusMessage) => message.direction === "outbound")
      .slice(options?.sinceIndex ?? 0)
      .find(
        (message) =>
          !message.deleted &&
          (!options?.accountId || message.accountId === options.accountId) &&
          predicate(message),
      );
    if (!match) {
      return undefined;
    }
    const failureReply = extractQaFailureReplyText(match);
    if (failureReply) {
      throw new Error(failureReply);
    }
    return match;
  }, timeoutMs);
}

async function waitForNoOutbound(
  state: QaTransportState,
  timeoutMs = 1_200,
  options?: WaitForNoOutboundOptions,
) {
  await sleep(timeoutMs);
  const outbound = state
    .getSnapshot()
    .messages.filter((message: QaBusMessage) => message.direction === "outbound")
    .slice(options?.sinceIndex ?? 0);
  if (outbound.length > 0) {
    const summary = outbound
      .slice(0, 5)
      .map(
        (message: QaBusMessage) =>
          `${message.conversation.kind}:${message.conversation.id}:${message.senderId}:${message.text}`,
      )
      .join(" | ");
    throw new Error(`expected no outbound messages, saw ${outbound.length}: ${summary}`);
  }
}

function recentOutboundSummary(state: QaTransportState, limit = 5) {
  return state
    .getSnapshot()
    .messages.filter((message: QaBusMessage) => message.direction === "outbound")
    .slice(-limit)
    .map(({ accountId, conversation: { kind, id }, text }) => `${accountId}:${kind}:${id}:${text}`)
    .join(" | ");
}

function readTransportTranscript(
  state: QaTransportState,
  params: {
    conversationId: string;
    threadId?: string;
    direction?: "inbound" | "outbound";
    limit?: number;
  },
) {
  const messages = state
    .getSnapshot()
    .messages.filter(
      (message: QaBusMessage) =>
        message.conversation.id === params.conversationId &&
        (params.threadId ? message.threadId === params.threadId : true) &&
        (params.direction ? message.direction === params.direction : true),
    );
  return params.limit ? messages.slice(-params.limit) : messages;
}

function formatTransportTranscript(
  state: QaTransportState,
  params: {
    conversationId: string;
    threadId?: string;
    direction?: "inbound" | "outbound";
    limit?: number;
  },
) {
  const messages = readTransportTranscript(state, params);
  return messages
    .map((message: QaBusMessage) => {
      const direction = message.direction === "inbound" ? "user" : "assistant";
      const speaker = message.senderName?.trim() || message.senderId;
      const attachmentSummary =
        message.attachments && message.attachments.length > 0
          ? ` [attachments: ${message.attachments
              .map(
                (attachment: NonNullable<QaBusMessage["attachments"]>[number]) =>
                  `${attachment.kind}:${attachment.fileName ?? attachment.id}`,
              )
              .join(", ")}]`
          : "";
      return `${direction.toUpperCase()} ${speaker}: ${message.text}${attachmentSummary}`;
    })
    .join("\n\n");
}

function formatConversationTranscript(
  state: QaTransportState,
  params: {
    conversationId: string;
    threadId?: string;
    limit?: number;
  },
) {
  return formatTransportTranscript(state, params);
}

async function waitForNoTransportOutbound(
  state: QaTransportState,
  timeoutMs = 1_200,
  options?: WaitForNoOutboundOptions,
) {
  await waitForNoOutbound(state, timeoutMs, options);
}

export {
  formatConversationTranscript,
  formatTransportTranscript,
  readTransportTranscript,
  recentOutboundSummary,
  waitForNoOutbound,
  waitForNoTransportOutbound,
  waitForOutboundMessage,
};
