// Qa Lab tests cover Tool Search gateway flow fixture behavior.
import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { DatabaseSync } from "node:sqlite";
import { afterEach, describe, expect, it, vi } from "vitest";
import {
  countSessionLogMentions,
  countSystemPromptChars,
  outputText,
  outputToolNames,
} from "./fixture-utils.js";
import { QA_TOOL_SEARCH_SECONDARY_TARGET } from "./providers/mock-openai/mock-openai-tooling.js";
import {
  qaMockRequestCursorUrl,
  qaMockRequestsAfterUrl,
  readQaMockRequestCursor,
} from "./providers/shared/debug-request-cursor.js";
import type { QaSuiteRuntimeEnv } from "./suite-runtime-types.js";
import {
  assertToolSearchBatchLaneResult,
  assertToolSearchLaneResults,
  fetchJson,
  readToolSearchGatewayFetchLimits,
  runToolSearchGatewayLane,
} from "./tool-search-gateway.fixture.js";

afterEach(() => {
  vi.unstubAllGlobals();
});

describe("tool search gateway e2e fetch helper", () => {
  it("builds and validates mock request cursor reads", () => {
    expect(readQaMockRequestCursor({ cursor: 42 })).toBe(42);
    expect(qaMockRequestCursorUrl("http://mock.test/")).toBe(
      "http://mock.test/debug/request-cursor",
    );
    expect(qaMockRequestsAfterUrl("http://mock.test/", 42)).toBe(
      "http://mock.test/debug/requests?after=42",
    );
    expect(() => readQaMockRequestCursor({ cursor: -1 })).toThrow(
      "mock provider request cursor response was invalid",
    );
    expect(() => readQaMockRequestCursor([])).toThrow(
      "mock provider request cursor response was invalid",
    );
  });

  it("rejects loose numeric env limits instead of parsing prefixes", () => {
    expect(() =>
      readToolSearchGatewayFetchLimits({
        OPENCLAW_TOOL_SEARCH_GATEWAY_E2E_FETCH_TIMEOUT_MS: "1e3",
      }),
    ).toThrow("invalid OPENCLAW_TOOL_SEARCH_GATEWAY_E2E_FETCH_TIMEOUT_MS: 1e3");
    expect(() =>
      readToolSearchGatewayFetchLimits({
        OPENCLAW_TOOL_SEARCH_GATEWAY_E2E_FETCH_BODY_MAX_BYTES: "1000ms",
      }),
    ).toThrow("invalid OPENCLAW_TOOL_SEARCH_GATEWAY_E2E_FETCH_BODY_MAX_BYTES: 1000ms");
    expect(
      readToolSearchGatewayFetchLimits({
        OPENCLAW_TOOL_SEARCH_GATEWAY_E2E_FETCH_BODY_MAX_BYTES: "4096",
        OPENCLAW_TOOL_SEARCH_GATEWAY_E2E_FETCH_TIMEOUT_MS: "5000",
      }),
    ).toEqual({
      bodyMaxBytes: 4096,
      timeoutMs: 5_000,
    });
  });

  it("aborts requests that never resolve", async () => {
    let signal: AbortSignal | undefined;
    await expect(
      fetchJson("https://qa.example.invalid/debug/requests", undefined, {
        timeoutMs: 25,
        fetchImpl: async (_url, init) => {
          signal = init.signal as AbortSignal | undefined;
          return new Promise<Response>(() => {});
        },
      }),
    ).rejects.toMatchObject({
      code: "ETIMEDOUT",
      message: "HTTP request to https://qa.example.invalid/debug/requests timed out after 25ms",
    });
    expect(signal?.aborted).toBe(true);
  });

  it("times out while reading stalled response bodies", async () => {
    await expect(
      fetchJson("https://qa.example.invalid/v1/responses", undefined, {
        timeoutMs: 25,
        fetchImpl: async () =>
          new Response(new ReadableStream<Uint8Array>({ start() {} }), {
            status: 200,
          }),
      }),
    ).rejects.toMatchObject({
      code: "ETIMEDOUT",
      message: "HTTP request to https://qa.example.invalid/v1/responses timed out after 25ms",
    });
  });

  it("parses successful JSON responses", async () => {
    await expect(
      fetchJson("https://qa.example.invalid/debug/requests", undefined, {
        timeoutMs: 25,
        fetchImpl: async () => new Response('{"ok":true}', { status: 200 }),
      }),
    ).resolves.toEqual({ ok: true });
  });

  it("bounds oversized response bodies", async () => {
    await expect(
      fetchJson("https://qa.example.invalid/debug/requests", undefined, {
        maxBodyBytes: 16,
        timeoutMs: 1000,
        fetchImpl: async () =>
          new Response(JSON.stringify({ ok: true, padding: "x".repeat(128) }), {
            status: 200,
          }),
      }),
    ).rejects.toMatchObject({
      code: "ETOOBIG",
      message: "HTTP response from https://qa.example.invalid/debug/requests exceeded 16 bytes",
    });
  });
});

describe("tool search gateway e2e session log scanner", () => {
  it("counts JSONL mentions without treating prompt text as a call", async () => {
    const stateDir = await fs.mkdtemp(path.join(os.tmpdir(), "openclaw-tool-search-log-"));
    try {
      const sessionsDir = path.join(stateDir, "agents", "qa", "sessions");
      await fs.mkdir(sessionsDir, { recursive: true });
      await fs.writeFile(
        path.join(sessionsDir, "session.jsonl"),
        [
          JSON.stringify({
            message: {
              role: "user",
              content: "tool search qa check target=fake_plugin_tool_17",
            },
          }),
          JSON.stringify({
            message: {
              role: "assistant",
              content: "FAKE_PLUGIN_OK fake_plugin_tool_17",
            },
          }),
          JSON.stringify({
            message: {
              role: "toolResult",
              toolName: "fake_plugin_tool_17",
              content: [{ type: "text", text: "FAKE_PLUGIN_OK" }],
            },
          }),
          "",
        ].join("\n"),
        "utf8",
      );

      await expect(
        countSessionLogMentions({
          sessionsDir,
          needles: {
            fake_plugin_tool_17: "fake_plugin_tool_17",
            tool_search_code: "tool_search_code",
          },
        }),
      ).resolves.toEqual({
        fake_plugin_tool_17: 2,
        tool_search_code: 0,
      });
    } finally {
      await fs.rm(stateDir, { recursive: true, force: true });
    }
  });

  it("counts target mentions from SQLite transcript rows", async () => {
    const stateDir = await fs.mkdtemp(path.join(os.tmpdir(), "openclaw-tool-search-sqlite-"));
    const sqlitePath = path.join(stateDir, "agents", "qa", "agent", "openclaw-agent.sqlite");
    await fs.mkdir(path.dirname(sqlitePath), { recursive: true });
    const db = new DatabaseSync(sqlitePath);
    try {
      const sessionsDir = path.join(stateDir, "agents", "qa", "sessions");
      db.exec(`
        CREATE TABLE transcript_events (
          session_id TEXT NOT NULL,
          seq INTEGER NOT NULL,
          event_json TEXT NOT NULL,
          created_at INTEGER NOT NULL,
          PRIMARY KEY (session_id, seq)
        );
      `);
      const insert = db.prepare(
        "INSERT INTO transcript_events (session_id, seq, event_json, created_at) VALUES (?, ?, ?, ?)",
      );
      insert.run(
        "sqlite-session",
        1,
        JSON.stringify({
          message: {
            role: "user",
            content: "tool search qa check target=fake_plugin_tool_17",
          },
        }),
        1,
      );
      insert.run(
        "sqlite-session",
        2,
        JSON.stringify({
          message: {
            role: "assistant",
            content: 'FAKE_PLUGIN_OK fake_plugin_tool_17 via tool_search_code quoted_call("alpha")',
          },
        }),
        2,
      );
      insert.run(
        "sqlite-session",
        3,
        JSON.stringify({
          message: {
            role: "toolResult",
            toolName: "fake_plugin_tool_17",
            content: [{ type: "text", text: "FAKE_PLUGIN_OK" }],
          },
        }),
        3,
      );

      await expect(
        countSessionLogMentions({
          sessionsDir,
          needles: {
            fake_plugin_tool_17: "fake_plugin_tool_17",
            quoted_call: 'quoted_call("alpha")',
            tool_search_code: "tool_search_code",
          },
        }),
      ).resolves.toEqual({
        fake_plugin_tool_17: 2,
        quoted_call: 1,
        tool_search_code: 1,
      });
    } finally {
      db.close();
      await fs.rm(stateDir, { recursive: true, force: true });
    }
  });
});

describe("tool search gateway e2e lane result", () => {
  it("preserves surrogate pairs in provider request snippets", async () => {
    const tempRoot = await fs.mkdtemp(path.join(os.tmpdir(), "openclaw-tool-search-lane-"));
    const configPath = path.join(tempRoot, "openclaw.json");
    const inputPrefix = "i".repeat(499);
    const searchOutput = '{"results":[{"query":"first"}]}';
    const toolOutput = `${"o".repeat(3_999)}😀tail`;
    await fs.writeFile(configPath, "{}\n", "utf8");
    const jsonResponse = (body: unknown) =>
      new Response(JSON.stringify(body), {
        headers: { "content-type": "application/json" },
      });
    const fetchMock = vi
      .fn()
      .mockResolvedValueOnce(jsonResponse({ cursor: 0 }))
      .mockResolvedValueOnce(jsonResponse({ output: [], status: "completed" }))
      .mockResolvedValueOnce(
        jsonResponse([
          {
            body: { tools: [] },
            plannedToolName: "tool_search",
            raw: "{}",
          },
          {
            body: { tools: [] },
            plannedToolName: "tool_call",
            raw: "{}",
            toolOutput: searchOutput,
          },
          {
            allInputText: `${inputPrefix}😀tail\n### Deferred Tool Schemas\n- fake_plugin_tool_17: Fake plugin target`,
            body: { tools: [] },
            plannedToolName: "fake_plugin_tool_17",
            raw: "{}",
            toolOutput,
          },
        ]),
      );
    vi.stubGlobal("fetch", fetchMock);
    const gatewayCall = vi.fn(async () => ({
      groups: [
        {
          tools: [
            {
              id: "fake_plugin_tool_17",
              source: "plugin",
              pluginId: "tool-search-e2e-fixture",
            },
          ],
        },
      ],
    }));
    const env: QaSuiteRuntimeEnv = {
      alternateModel: "openai/gpt-5.6-luna",
      cfg: {},
      gateway: {
        baseUrl: "http://gateway.test",
        call: gatewayCall,
        restartAfterStateMutation: async (mutateState) => {
          await mutateState({
            configPath,
            runtimeEnv: {},
            stateDir: path.join(tempRoot, "state"),
            tempRoot,
          });
        },
        runtimeEnv: { OPENCLAW_GATEWAY_TOKEN: "test-token" },
        tempRoot,
        workspaceDir: tempRoot,
      },
      mock: { baseUrl: "http://mock-openai.test" },
      outputDir: path.join(tempRoot, "output"),
      primaryModel: "openai/gpt-5.6-luna",
      providerMode: "mock-openai",
      repoRoot: tempRoot,
      transport: {} as QaSuiteRuntimeEnv["transport"],
    };

    try {
      const result = await runToolSearchGatewayLane({
        env,
        fixture: { fakePluginDir: tempRoot, targetTool: "fake_plugin_tool_17" },
        lane: "code",
      });

      expect(result.providerInputSnippet).toBe(inputPrefix);
      expect(result.providerToolOutputSnippet).toBe(
        `${searchOutput}\n${"o".repeat(4_000 - searchOutput.length - 1)}`,
      );
      expect(result.providerDirectoryContainsTarget).toBe(true);
      expect(result.targetToolIdentity).toEqual({
        source: "plugin",
        pluginId: "tool-search-e2e-fixture",
      });
      expect(fetchMock).toHaveBeenCalledTimes(3);
      expect(gatewayCall).toHaveBeenCalledWith(
        "tools.effective",
        { sessionKey: "tool-search-gateway-code" },
        { timeoutMs: expect.any(Number) },
      );
      const laneConfig = JSON.parse(await fs.readFile(configPath, "utf8")) as {
        memory?: { search?: Record<string, unknown> };
      };
      expect(laneConfig.memory?.search).toMatchObject({ enabled: false });
      expect(laneConfig.memory?.search).not.toHaveProperty("sync");
    } finally {
      await fs.rm(tempRoot, { force: true, recursive: true });
    }
  });
});

describe("qa fixture response helpers", () => {
  it("reads Responses API text, function call names, and prompt sizing", () => {
    const payload = {
      output: [
        { type: "function_call", name: "fake_plugin_tool_17" },
        {
          type: "message",
          content: [{ text: "alpha" }, { text: "beta" }],
        },
      ],
    };

    expect(outputToolNames(payload)).toEqual(["fake_plugin_tool_17"]);
    expect(outputText(payload)).toBe("alpha\nbeta");
    expect(
      countSystemPromptChars({
        instructions: "abc",
        input: [
          { role: "system", content: [{ type: "input_text", text: "def" }] },
          { role: "developer", content: "ghi" },
          { role: "user", content: [{ type: "input_text", text: "ignored" }] },
        ],
      }),
    ).toBe(9);
  });
});

describe("tool search gateway e2e lane assertions", () => {
  const targetTool = "fake_plugin_tool_17";
  const targetToolIdentity = {
    source: "plugin",
    pluginId: "tool-search-e2e-fixture",
  };
  const providerToolCallResult = {
    tool: { name: targetTool },
    result: { details: { status: "ok", tool: targetTool } },
  };
  const normal = {
    gatewayOutputText: `FAKE_PLUGIN_OK ${targetTool}`,
    providerDeclaredToolCount: 36,
    providerDirectoryContainsTarget: false,
    providerPlannedTools: [targetTool],
    providerRawBytes: 12_000,
    sessionLogToolMentions: {
      [targetTool]: 1,
    },
    targetToolIdentity,
  };

  it("accepts code lane proof only when the target plugin tool output is present", () => {
    expect(() =>
      assertToolSearchLaneResults({
        normal,
        targetTool,
        code: {
          targetToolIdentity,
          gatewayOutputText: `FAKE_PLUGIN_OK ${targetTool}`,
          providerDeclaredToolCount: 1,
          providerDirectoryContainsTarget: true,
          providerPlannedTools: ["tool_search_code"],
          providerRawBytes: 4_000,
          sessionLogToolMentions: {
            tool_search_code: 1,
            [targetTool]: 1,
          },
        },
      }),
    ).not.toThrow();
  });

  it("accepts one structured batch search followed by one catalog call", () => {
    expect(() =>
      assertToolSearchBatchLaneResult({
        targetTool,
        tools: {
          status: "completed",
          targetToolIdentity,
          providerToolCallResult,
          gatewayOutputText: `FAKE_PLUGIN_OK ${targetTool}`,
          providerDeclaredToolCount: 3,
          providerDeclaredToolNames: ["tool_search", "tool_describe", "tool_call"],
          providerDirectoryContainsTarget: true,
          providerPlannedTools: ["tool_search", "tool_call"],
          providerRawBytes: 4_000,
          providerToolOutputSnippet: JSON.stringify({
            results: [
              { query: targetTool, candidates: [{ name: targetTool }] },
              {
                query: QA_TOOL_SEARCH_SECONDARY_TARGET,
                candidates: [{ name: QA_TOOL_SEARCH_SECONDARY_TARGET }],
              },
            ],
          }),
          providerToolSearchResult: {
            results: [
              { query: targetTool, candidates: [{ name: targetTool }] },
              {
                query: QA_TOOL_SEARCH_SECONDARY_TARGET,
                candidates: [{ name: QA_TOOL_SEARCH_SECONDARY_TARGET }],
              },
            ],
          },
          sessionLogToolMentions: {
            tool_search: 1,
            tool_call: 1,
            [targetTool]: 1,
          },
        },
      }),
    ).not.toThrow();
  });

  it("rejects structured proof that splits discovery across outer calls", () => {
    expect(() =>
      assertToolSearchBatchLaneResult({
        targetTool,
        tools: {
          status: "completed",
          targetToolIdentity,
          providerToolCallResult,
          gatewayOutputText: `FAKE_PLUGIN_OK ${targetTool}`,
          providerDeclaredToolCount: 3,
          providerDeclaredToolNames: ["tool_search", "tool_describe", "tool_call"],
          providerDirectoryContainsTarget: true,
          providerPlannedTools: ["tool_search", "tool_search", "tool_call"],
          providerRawBytes: 4_000,
          providerToolOutputSnippet: JSON.stringify({
            results: [{ query: targetTool, candidates: [{ name: targetTool }] }],
          }),
          sessionLogToolMentions: {
            tool_search: 2,
            tool_call: 1,
            [targetTool]: 1,
          },
        },
      }),
    ).toThrow("structured lane did not use one batch search");
  });

  it.each([
    {
      label: "omits a grouped result",
      status: "completed",
      plannedTools: ["tool_search", "tool_call"],
      result: { results: [{ query: targetTool, candidates: [{ name: targetTool }] }] },
      mentions: { tool_search: 1, tool_call: 1, [targetTool]: 1 },
      error: "did not return both grouped search results",
    },
    {
      label: "reorders grouped results",
      status: "completed",
      plannedTools: ["tool_search", "tool_call"],
      result: {
        results: [
          {
            query: QA_TOOL_SEARCH_SECONDARY_TARGET,
            candidates: [{ name: QA_TOOL_SEARCH_SECONDARY_TARGET }],
          },
          { query: targetTool, candidates: [{ name: targetTool }] },
        ],
      },
      mentions: { tool_search: 1, tool_call: 1, [targetTool]: 1 },
      error: "did not return both grouped search results",
    },
    {
      label: "reuses the first query candidate for the second group",
      status: "completed",
      plannedTools: ["tool_search", "tool_call"],
      result: {
        results: [
          { query: targetTool, candidates: [{ name: targetTool }] },
          { query: QA_TOOL_SEARCH_SECONDARY_TARGET, candidates: [{ name: targetTool }] },
        ],
      },
      mentions: { tool_search: 1, tool_call: 1, [targetTool]: 1 },
      error: "did not return both grouped search results",
    },
    {
      label: "calls before searching",
      status: "completed",
      plannedTools: ["tool_call", "tool_search"],
      result: {
        results: [
          { query: targetTool, candidates: [{ name: targetTool }] },
          {
            query: QA_TOOL_SEARCH_SECONDARY_TARGET,
            candidates: [{ name: QA_TOOL_SEARCH_SECONDARY_TARGET }],
          },
        ],
      },
      mentions: { tool_search: 1, tool_call: 1, [targetTool]: 1 },
      error: "did not use one batch search followed by one catalog call",
    },
    {
      label: "omits bridge telemetry",
      status: "completed",
      plannedTools: ["tool_search", "tool_call"],
      result: {
        results: [
          { query: targetTool, candidates: [{ name: targetTool }] },
          {
            query: QA_TOOL_SEARCH_SECONDARY_TARGET,
            candidates: [{ name: QA_TOOL_SEARCH_SECONDARY_TARGET }],
          },
        ],
      },
      mentions: { tool_search: 0, tool_call: 0, [targetTool]: 1 },
      error: "session log did not record search and call mentions",
    },
    {
      label: "returns an incomplete response",
      status: "incomplete",
      plannedTools: ["tool_search", "tool_call"],
      result: {
        results: [
          { query: targetTool, candidates: [{ name: targetTool }] },
          {
            query: QA_TOOL_SEARCH_SECONDARY_TARGET,
            candidates: [{ name: QA_TOOL_SEARCH_SECONDARY_TARGET }],
          },
        ],
      },
      mentions: { tool_search: 1, tool_call: 1, [targetTool]: 1 },
      error: "did not complete successfully",
    },
  ])(
    "rejects structured proof that $label",
    ({ status, plannedTools, result, mentions, error }) => {
      expect(() =>
        assertToolSearchBatchLaneResult({
          targetTool,
          tools: {
            status,
            targetToolIdentity,
            providerToolCallResult,
            gatewayOutputText: `FAKE_PLUGIN_OK ${targetTool}`,
            providerDeclaredToolCount: 3,
            providerDeclaredToolNames: ["tool_search", "tool_describe", "tool_call"],
            providerDirectoryContainsTarget: true,
            providerPlannedTools: plannedTools,
            providerRawBytes: 4_000,
            providerToolOutputSnippet: JSON.stringify(result),
            providerToolSearchResult: result,
            sessionLogToolMentions: mentions,
          },
        }),
      ).toThrow(error);
    },
  );

  it.each([
    {
      label: "omits a control tool",
      declaredToolNames: ["tool_search", "tool_call"],
      directoryContainsTarget: true,
    },
    {
      label: "omits the target directory",
      declaredToolNames: ["tool_search", "tool_describe", "tool_call"],
      directoryContainsTarget: false,
    },
  ])("rejects structured proof that $label", ({ declaredToolNames, directoryContainsTarget }) => {
    const result = {
      results: [
        { query: targetTool, candidates: [{ name: targetTool }] },
        {
          query: QA_TOOL_SEARCH_SECONDARY_TARGET,
          candidates: [{ name: QA_TOOL_SEARCH_SECONDARY_TARGET }],
        },
      ],
    };
    expect(() =>
      assertToolSearchBatchLaneResult({
        targetTool,
        tools: {
          status: "completed",
          targetToolIdentity,
          providerToolCallResult,
          gatewayOutputText: `FAKE_PLUGIN_OK ${targetTool}`,
          providerDeclaredToolCount: declaredToolNames.length,
          providerDeclaredToolNames: declaredToolNames,
          providerDirectoryContainsTarget: directoryContainsTarget,
          providerPlannedTools: ["tool_search", "tool_call"],
          providerRawBytes: 4_000,
          providerToolSearchResult: result,
          sessionLogToolMentions: { tool_search: 1, tool_call: 1, [targetTool]: 1 },
        },
      }),
    ).toThrow("structured lane did not expose its bounded directory with all three control tools");
  });

  it("rejects structured proof without a typed target tool result", () => {
    const result = {
      results: [
        { query: targetTool, candidates: [{ name: targetTool }] },
        {
          query: QA_TOOL_SEARCH_SECONDARY_TARGET,
          candidates: [{ name: QA_TOOL_SEARCH_SECONDARY_TARGET }],
        },
      ],
    };
    expect(() =>
      assertToolSearchBatchLaneResult({
        targetTool,
        tools: {
          status: "completed",
          targetToolIdentity,
          gatewayOutputText: `FAKE_PLUGIN_OK ${targetTool}`,
          providerDeclaredToolCount: 3,
          providerDeclaredToolNames: ["tool_search", "tool_describe", "tool_call"],
          providerDirectoryContainsTarget: true,
          providerPlannedTools: ["tool_search", "tool_call"],
          providerRawBytes: 4_000,
          providerToolSearchResult: result,
          sessionLogToolMentions: { tool_search: 1, tool_call: 1, [targetTool]: 2 },
        },
      }),
    ).toThrow(`structured lane did not call ${targetTool}`);
  });

  it("rejects structured tools.effective ownership outside the fixture plugin", () => {
    const result = {
      results: [
        { query: targetTool, candidates: [{ name: targetTool }] },
        {
          query: QA_TOOL_SEARCH_SECONDARY_TARGET,
          candidates: [{ name: QA_TOOL_SEARCH_SECONDARY_TARGET }],
        },
      ],
    };
    expect(() =>
      assertToolSearchBatchLaneResult({
        targetTool,
        tools: {
          status: "completed",
          targetToolIdentity: { source: "core", pluginId: "" },
          providerToolCallResult,
          gatewayOutputText: `FAKE_PLUGIN_OK ${targetTool}`,
          providerDeclaredToolCount: 3,
          providerDeclaredToolNames: ["tool_search", "tool_describe", "tool_call"],
          providerDirectoryContainsTarget: true,
          providerPlannedTools: ["tool_search", "tool_call"],
          providerRawBytes: 4_000,
          providerToolSearchResult: result,
          sessionLogToolMentions: { tool_search: 1, tool_call: 1, [targetTool]: 2 },
        },
      }),
    ).toThrow(`tools.effective did not attribute ${targetTool} to plugin`);
  });

  it("preserves surrogate pairs in both lane debug output snippets", () => {
    const outputPrefix = `FAKE_PLUGIN_OK ${targetTool} `;
    const normalOutput = `${outputPrefix}${"n".repeat(299 - outputPrefix.length)}`;
    const codeOutput = `${outputPrefix}${"c".repeat(299 - outputPrefix.length)}`;
    const assertInvalidLaneResults = () =>
      assertToolSearchLaneResults({
        targetTool,
        normal: {
          ...normal,
          gatewayOutputText: `${normalOutput}😀tail`,
        },
        code: {
          targetToolIdentity,
          gatewayOutputText: `${codeOutput}😀tail`,
          providerDeclaredToolCount: 1,
          providerDirectoryContainsTarget: true,
          providerPlannedTools: ["tool_search_code", targetTool],
          providerRawBytes: 4_000,
          sessionLogToolMentions: {
            tool_search_code: 1,
            [targetTool]: 1,
          },
        },
      });

    expect(assertInvalidLaneResults).toThrow(`"output": "${normalOutput}"`);
    expect(assertInvalidLaneResults).toThrow(`"output": "${codeOutput}"`);
  });

  it("rejects code lane output that only echoes the target tool name", () => {
    expect(() =>
      assertToolSearchLaneResults({
        normal,
        targetTool,
        code: {
          targetToolIdentity,
          gatewayOutputText: targetTool,
          providerDeclaredToolCount: 1,
          providerDirectoryContainsTarget: true,
          providerPlannedTools: ["tool_search_code"],
          providerRawBytes: 4_000,
          sessionLogToolMentions: {
            tool_search_code: 1,
            [targetTool]: 1,
          },
        },
      }),
    ).toThrow(`code lane did not bridge-call ${targetTool}`);
  });

  it("rejects code lane proof that also exposes the direct target tool", () => {
    expect(() =>
      assertToolSearchLaneResults({
        normal,
        targetTool,
        code: {
          targetToolIdentity,
          gatewayOutputText: `FAKE_PLUGIN_OK ${targetTool}`,
          providerDeclaredToolCount: 2,
          providerDirectoryContainsTarget: true,
          providerPlannedTools: ["tool_search_code", targetTool],
          providerRawBytes: 4_000,
          sessionLogToolMentions: {
            tool_search_code: 1,
            [targetTool]: 1,
          },
        },
      }),
    ).toThrow(`code lane exposed direct provider tool ${targetTool}`);
  });

  it("rejects normal lane output that only echoes the target tool name", () => {
    expect(() =>
      assertToolSearchLaneResults({
        targetTool,
        normal: {
          ...normal,
          sessionLogToolMentions: {
            [targetTool]: 0,
          },
        },
        code: {
          targetToolIdentity,
          gatewayOutputText: `FAKE_PLUGIN_OK ${targetTool}`,
          providerDeclaredToolCount: 1,
          providerDirectoryContainsTarget: true,
          providerPlannedTools: ["tool_search_code"],
          providerRawBytes: 4_000,
          sessionLogToolMentions: {
            tool_search_code: 1,
            [targetTool]: 1,
          },
        },
      }),
    ).toThrow(`normal lane did not call ${targetTool}`);
  });

  it("rejects normal lane proof that uses the Tool Search bridge", () => {
    expect(() =>
      assertToolSearchLaneResults({
        targetTool,
        normal: {
          ...normal,
          providerPlannedTools: [targetTool, "tool_search_code"],
          sessionLogToolMentions: {
            tool_search_code: 1,
            [targetTool]: 1,
          },
        },
        code: {
          targetToolIdentity,
          gatewayOutputText: `FAKE_PLUGIN_OK ${targetTool}`,
          providerDeclaredToolCount: 1,
          providerDirectoryContainsTarget: true,
          providerPlannedTools: ["tool_search_code"],
          providerRawBytes: 4_000,
          sessionLogToolMentions: {
            tool_search_code: 1,
            [targetTool]: 1,
          },
        },
      }),
    ).toThrow("normal lane unexpectedly used Tool Search bridge");
  });

  it("rejects code lane proof without the automatically advertised capability directory", () => {
    expect(() =>
      assertToolSearchLaneResults({
        normal,
        targetTool,
        code: {
          targetToolIdentity,
          gatewayOutputText: `FAKE_PLUGIN_OK ${targetTool}`,
          providerDeclaredToolCount: 1,
          providerDirectoryContainsTarget: false,
          providerPlannedTools: ["tool_search_code"],
          providerRawBytes: 4_000,
          sessionLogToolMentions: {
            tool_search_code: 1,
            [targetTool]: 1,
          },
        },
      }),
    ).toThrow(`code lane did not advertise ${targetTool} in the capability directory`);
  });

  it("rejects a Tool Search capability directory in the direct lane", () => {
    expect(() =>
      assertToolSearchLaneResults({
        normal: { ...normal, providerDirectoryContainsTarget: true },
        targetTool,
        code: {
          targetToolIdentity,
          gatewayOutputText: `FAKE_PLUGIN_OK ${targetTool}`,
          providerDeclaredToolCount: 1,
          providerDirectoryContainsTarget: true,
          providerPlannedTools: ["tool_search_code"],
          providerRawBytes: 4_000,
          sessionLogToolMentions: {
            tool_search_code: 1,
            [targetTool]: 1,
          },
        },
      }),
    ).toThrow("normal lane unexpectedly advertised a Tool Search capability directory");
  });

  it("rejects tools.effective ownership that does not identify the fixture plugin", () => {
    expect(() =>
      assertToolSearchLaneResults({
        normal: {
          ...normal,
          targetToolIdentity: { source: "core", pluginId: "" },
        },
        targetTool,
        code: {
          targetToolIdentity,
          gatewayOutputText: `FAKE_PLUGIN_OK ${targetTool}`,
          providerDeclaredToolCount: 1,
          providerDirectoryContainsTarget: true,
          providerPlannedTools: ["tool_search_code"],
          providerRawBytes: 4_000,
          sessionLogToolMentions: {
            tool_search_code: 1,
            [targetTool]: 1,
          },
        },
      }),
    ).toThrow(`tools.effective did not attribute ${targetTool} to plugin tool-search-e2e-fixture`);
  });
});
