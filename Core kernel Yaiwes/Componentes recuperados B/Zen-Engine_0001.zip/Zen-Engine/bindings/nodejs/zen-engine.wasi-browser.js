import {
  createOnMessage as __wasmCreateOnMessageForFsProxy,
  getDefaultContext as __emnapiGetDefaultContext,
  instantiateNapiModule as __emnapiInstantiateNapiModule,
  WASI as __WASI,
} from '@napi-rs/wasm-runtime'



const __wasi = new __WASI({
  version: 'preview1',
})

const __wasmUrl = new URL('./zen-engine.wasm32-wasi.wasm', import.meta.url).href
const __emnapiContext = __emnapiGetDefaultContext()


const __sharedMemory = new WebAssembly.Memory({
  initial: 1024,
  maximum: 16384,
  shared: true,
})

const __wasmFile = await fetch(__wasmUrl).then((res) => res.arrayBuffer())

const {
  instance: __napiInstance,
  module: __wasiModule,
  napiModule: __napiModule,
} = await __emnapiInstantiateNapiModule(__wasmFile, {
  context: __emnapiContext,
  asyncWorkPoolSize: 4,
  wasi: __wasi,
  onCreateWorker() {
    const worker = new Worker(new URL('./wasi-worker-browser.mjs', import.meta.url), {
      type: 'module',
    })

    return worker
  },
  overwriteImports(importObject) {
    importObject.env = {
      ...importObject.env,
      ...importObject.napi,
      ...importObject.emnapi,
      memory: __sharedMemory,
    }
    return importObject
  },
  beforeInit({ instance }) {
    for (const name of Object.keys(instance.exports)) {
      if (name.startsWith('__napi_register__')) {
        instance.exports[name]()
      }
    }
  },
})
export default __napiModule.exports
export const Workspace = __napiModule.exports.Workspace
export const ZenDecision = __napiModule.exports.ZenDecision
export const ZenDecisionContent = __napiModule.exports.ZenDecisionContent
export const ZenEngine = __napiModule.exports.ZenEngine
export const ZenEngineHandlerRequest = __napiModule.exports.ZenEngineHandlerRequest
export const evaluateExpression = __napiModule.exports.evaluateExpression
export const evaluateExpressionSync = __napiModule.exports.evaluateExpressionSync
export const evaluateUnaryExpression = __napiModule.exports.evaluateUnaryExpression
export const evaluateUnaryExpressionSync = __napiModule.exports.evaluateUnaryExpressionSync
export const nlEncodeString = __napiModule.exports.nlEncodeString
export const nlTokenizeBatch = __napiModule.exports.nlTokenizeBatch
export const overrideConfig = __napiModule.exports.overrideConfig
export const renderTemplate = __napiModule.exports.renderTemplate
export const renderTemplateSync = __napiModule.exports.renderTemplateSync
