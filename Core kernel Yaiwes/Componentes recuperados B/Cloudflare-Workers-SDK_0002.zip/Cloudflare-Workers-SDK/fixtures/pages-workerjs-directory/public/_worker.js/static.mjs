export default "mjs static";
