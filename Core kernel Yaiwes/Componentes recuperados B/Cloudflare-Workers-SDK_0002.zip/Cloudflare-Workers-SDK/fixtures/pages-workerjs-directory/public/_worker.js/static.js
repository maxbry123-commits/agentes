export default "js static";
