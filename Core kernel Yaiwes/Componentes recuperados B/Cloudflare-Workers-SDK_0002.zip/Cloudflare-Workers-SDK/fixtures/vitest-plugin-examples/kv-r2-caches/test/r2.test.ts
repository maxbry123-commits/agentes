import {
	createExecutionContext,
	waitOnExecutionContext,
} from "cloudflare:test";
import { env, exports } from "cloudflare:workers";
import { it } from "vitest";
import { handleR2Request } from "../src/helpers"; // Note we can import any function

it("stores in R2 bucket", async ({ expect }) => {
	let response = await exports.default.fetch("https://example.com/r2/key", {
		method: "PUT",
		headers: { "Cache-Control": "max-age=3600" },
		body: "value",
	});
	expect(response.status).toBe(204);

	const request = new Request("https://example.com/r2/key");
	let ctx = createExecutionContext();
	response = await handleR2Request(request, env, ctx);
	await waitOnExecutionContext(ctx); // Wait for `caches.default.put()`
	expect(response.status).toBe(200);
	expect(response.headers.get("CF-Cache-Status")).toBe(null);
	expect(await response.text()).toBe("value");

	// Check 2nd request to the same resource is cached
	ctx = createExecutionContext();
	response = await handleR2Request(request, env, ctx);
	await waitOnExecutionContext(ctx);
	expect(response.status).toBe(200);
	expect(response.headers.get("CF-Cache-Status")).toBe("HIT");
	expect(await response.text()).toBe("value");
});
