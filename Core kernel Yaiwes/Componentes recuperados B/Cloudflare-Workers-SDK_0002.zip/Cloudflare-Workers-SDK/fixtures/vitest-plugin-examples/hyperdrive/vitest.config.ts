import { cloudflareTest } from "@cloudflare/vitest-plugin";
import { defineProject, mergeConfig } from "vitest/config";
import configShared from "../../../vitest.shared";

export default mergeConfig(
	configShared,
	defineProject({
		plugins: [
			cloudflareTest(({ inject }) => {
				// Provided in `global-setup.ts`
				const echoServerPort = inject("echoServerPort");

				return {
					miniflare: {
						hyperdrives: {
							ECHO_SERVER_HYPERDRIVE: `postgres://user:pass@127.0.0.1:${echoServerPort}/db`,
						},
					},
					wrangler: {
						configPath: "./wrangler.jsonc",
					},
				};
			}),
		],
		test: {
			globalSetup: ["./global-setup.ts"],
		},
	})
);
