module.exports = "cjs-string";
