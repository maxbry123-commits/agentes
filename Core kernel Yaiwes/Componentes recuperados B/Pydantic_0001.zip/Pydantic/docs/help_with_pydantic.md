# Getting help with Pydantic

If you need help getting started with Pydantic or with advanced usage, the following sources may be useful.

## :simple-slack: Slack

The [Pydantic Logfire Slack](https://pydantic.dev/docs/logfire/join-slack/) is a great place to ask questions,
and get help and chat about Pydantic and the other Pydantic products ([Pydantic AI](https://pydantic.dev/pydantic-ai),
[Logfire](https://pydantic.dev/logfire)).

## :material-help: Usage Documentation

The [usage documentation](concepts/models.md) is the most complete guide on how to use Pydantic.

## :material-api: API Documentation

The [API documentation](api/base_model.md) gives reference docs for all public Pydantic APIs.

## :simple-github: GitHub Discussions

[GitHub discussions](https://github.com/pydantic/pydantic/discussions) are useful for asking questions, your question and the answer will help everyone.

## :simple-stackoverflow: Stack Overflow

Use the [`pydantic`](https://stackoverflow.com/questions/tagged/pydantic) tag on Stack Overflow to ask questions; note that this is not always monitored by the core Pydantic team.

## :simple-youtube: YouTube

Youtube has lots of useful [videos on Pydantic](https://www.youtube.com/results?search_query=pydantic).

In particular Marcelo Trylesinski's video ["Pydantic V1 to V2 - The Migration"](https://youtu.be/sD_xpYl4fPU) has helped people a lot when migrating from Pydantic V1 to V2.
