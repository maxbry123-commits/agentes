import { CommaSeparatedStringArray, Config, Env } from '@n8n/config';

import { UnknownModuleError } from './errors/unknown-module.error';

export const MODULE_NAMES = [
	'agents',
	'agent-evals',
	'insights',
	'external-secrets',
	'community-packages',
	'data-table',
	'oauth-server',
	'mcp',
	'provisioning',
	'breaking-changes',
	'source-control',
	'git-connections',
	'dynamic-credentials',
	'chat-hub',
	'sso-oidc',
	'sso-saml',
	'log-streaming',
	'ldap',
	'quick-connect',
	'workflow-builder',
	'favorites',
	'redaction',
	'instance-registry',
	'instance-ai',
	'mcp-registry',
	'otel',
	'token-exchange',
	'instance-version-history',
	'encryption-key-manager',
	'oauth-jwe',
	'runtime-credentials',
	'n8n-packages',
	'workflow-reviews',
	'engine-v2',
	'policy-infrastructure',
	'type-availability-policies',
] as const;

export type ModuleName = (typeof MODULE_NAMES)[number];

class ModuleArray extends CommaSeparatedStringArray<ModuleName> {
	constructor(str: string) {
		super(str);

		for (const moduleName of this) {
			if (!MODULE_NAMES.includes(moduleName)) throw new UnknownModuleError(moduleName);
		}
	}
}

@Config
export class ModulesConfig {
	/** Comma-separated list of all enabled modules. */
	@Env('N8N_ENABLED_MODULES')
	enabledModules: ModuleArray = [];

	/** Comma-separated list of all disabled modules. */
	@Env('N8N_DISABLED_MODULES')
	disabledModules: ModuleArray = [];
}
