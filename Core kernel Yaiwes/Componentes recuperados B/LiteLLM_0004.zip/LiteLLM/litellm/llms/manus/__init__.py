# Manus provider implementation
