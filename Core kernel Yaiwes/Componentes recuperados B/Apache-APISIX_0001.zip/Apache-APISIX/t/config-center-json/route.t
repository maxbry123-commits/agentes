#
# Licensed to the Apache Software Foundation (ASF) under one or more
# contributor license agreements.  See the NOTICE file distributed with
# this work for additional information regarding copyright ownership.
# The ASF licenses this file to You under the Apache License, Version 2.0
# (the "License"); you may not use this file except in compliance with
# the License.  You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
use t::APISIX 'no_plan';

repeat_each(1);
log_level('info');
no_root_location();
no_shuffle();

run_tests();

__DATA__

=== TEST 1: sanity
--- yaml_config eval: $::yaml_config
--- apisix_json
{
  "routes": [
    {
      "id": 1,
      "uri": "/hello",
      "upstream": {
        "nodes": {
          "127.0.0.1:1980": 1
        },
        "type": "roundrobin"
      }
    }
  ]
}
--- request
GET /hello
--- response_body
hello world
--- error_log
use config_provider: json



=== TEST 2: route:uri + host (missing host, not hit)
--- yaml_config eval: $::yaml_config
--- apisix_json
{
  "routes": [
    {
      "id": 1,
      "uri": "/hello",
      "host": "foo.com",
      "upstream": {
        "nodes": {
          "127.0.0.1:1980": 1
        },
        "type": "roundrobin"
      }
    }
  ]
}
--- request
GET /hello
--- error_code: 404
--- error_log
use config_provider: json



=== TEST 3: route:uri + host
--- yaml_config eval: $::yaml_config
--- apisix_json
{
  "routes": [
    {
      "id": 1,
      "uri": "/hello",
      "host": "foo.com",
      "upstream": {
        "nodes": {
          "127.0.0.1:1980": 1
        },
        "type": "roundrobin"
      }
    }
  ]
}
--- more_headers
host: foo.com
--- request
GET /hello
--- response_body
hello world



=== TEST 4: route with bad plugin
--- yaml_config eval: $::yaml_config
--- apisix_json
{
  "routes": [
    {
      "id": 1,
      "uri": "/hello",
      "plugins": {
        "proxy-rewrite": {
          "uri": 1
        }
      },
      "upstream": {
        "nodes": {
          "127.0.0.1:1980": 1
        },
        "type": "roundrobin"
      }
    }
  ]
}
--- request
GET /hello
--- error_code: 404
--- error_log
property "uri" validation failed



=== TEST 5: ignore unknown plugin
--- yaml_config eval: $::yaml_config
--- apisix_json
{
  "routes": [
    {
      "id": 1,
      "uri": "/hello",
      "plugins": {
        "x-rewrite": {
          "uri": 1
        }
      },
      "upstream": {
        "nodes": {
          "127.0.0.1:1980": 1
        },
        "type": "roundrobin"
      }
    }
  ]
}
--- request
GET /hello
--- error_code: 404
--- response_body
{"error_msg":"404 Route Not Found"}
--- error_log
failed to check item data of [routes] err:unknown plugin



=== TEST 6: route with bad plugin, radixtree_host_uri
--- yaml_config
apisix:
    node_listen: 1984
    router:
        http: "radixtree_host_uri"
deployment:
    role: data_plane
    role_data_plane:
        config_provider: json
--- apisix_json
{
  "routes": [
    {
      "id": 1,
      "uri": "/hello",
      "plugins": {
        "proxy-rewrite": {
          "uri": 1
        }
      },
      "upstream": {
        "nodes": {
          "127.0.0.1:1980": 1
        },
        "type": "roundrobin"
      }
    }
  ]
}
--- request
GET /hello
--- error_code: 404
--- error_log
property "uri" validation failed



=== TEST 7: fix route with default value
--- yaml_config
apisix:
    node_listen: 1984
    router:
        http: "radixtree_host_uri"
deployment:
    role: data_plane
    role_data_plane:
        config_provider: json
--- apisix_json
{
  "routes": [
    {
      "id": 1,
      "uri": "/hello",
      "plugins": {
        "uri-blocker": {
          "block_rules": [
            "/h*"
          ]
        }
      },
      "upstream": {
        "nodes": {
          "127.0.0.1:1980": 1
        },
        "type": "roundrobin"
      }
    }
  ]
}
--- request
GET /hello
--- error_code: 403



=== TEST 8: invalid route, bad vars operator
--- yaml_config
apisix:
    node_listen: 1984
    router:
        http: "radixtree_host_uri"
deployment:
    role: data_plane
    role_data_plane:
        config_provider: json
--- apisix_json
{
  "routes": [
    {
      "id": 1,
      "uri": "/hello",
      "vars": [
        ["remote_addr", "=", "1"]
      ],
      "upstream": {
        "nodes": {
          "127.0.0.1:1980": 1
        },
        "type": "roundrobin"
      }
    }
  ]
}
--- request
GET /hello
--- error_code: 404
--- error_log
failed to validate the 'vars' expression



=== TEST 9: script with id
--- yaml_config
apisix:
    node_listen: 1984
deployment:
    role: data_plane
    role_data_plane:
        config_provider: json
--- apisix_json
{
  "routes": [
    {
      "id": 1,
      "uri": "/hello",
      "script": "local ngx = ngx",
      "script_id": "1",
      "upstream": {
        "nodes": {
          "127.0.0.1:1980": 1
        },
        "type": "roundrobin"
      }
    }
  ]
}
--- request
GET /hello
--- error_code: 200
--- error_log
missing loaded script object



=== TEST 10: hosts with '_' is valid
--- yaml_config eval: $::yaml_config
--- apisix_json
{
  "routes": [
    {
      "id": 1,
      "uri": "/hello",
      "hosts": [
        "foo.com",
        "v1_test-api.com"
      ],
      "upstream": {
        "nodes": {
          "127.0.0.1:1980": 1
        },
        "type": "roundrobin"
      }
    }
  ]
}
--- more_headers
host: v1_test-api.com
--- request
GET /hello
--- response_body
hello world



=== TEST 11: script with plugin_config_id
--- yaml_config eval: $::yaml_config
--- apisix_json
{
  "routes": [
    {
      "id": 1,
      "uri": "/hello",
      "script": "local ngx = ngx",
      "plugin_config_id": "1",
      "upstream": {
        "nodes": {
          "127.0.0.1:1980": 1
        },
        "type": "roundrobin"
      }
    }
  ]
}
--- request
GET /hello
--- error_code: 404
--- error_log
failed to check item data of [routes]
