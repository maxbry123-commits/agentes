--
-- Licensed to the Apache Software Foundation (ASF) under one or more
-- contributor license agreements.  See the NOTICE file distributed with
-- this work for additional information regarding copyright ownership.
-- The ASF licenses this file to You under the Apache License, Version 2.0
-- (the "License"); you may not use this file except in compliance with
-- the License.  You may obtain a copy of the License at
--
--     http://www.apache.org/licenses/LICENSE-2.0
--
-- Unless required by applicable law or agreed to in writing, software
-- distributed under the License is distributed on an "AS IS" BASIS,
-- WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
-- See the License for the specific language governing permissions and
-- limitations under the License.
--
local core            = require("apisix.core")
local consumer_mod    = require("apisix.consumer")
local base64          = require("ngx.base64")
local aes             = require("resty.aes")
local sub_str         = string.sub
local type            = type
local cipher          = aes.cipher(256, "gcm")

local plugin_name     = "jwe-decrypt"

local schema = {
    type = "object",
    properties = {
        header = {
            type = "string",
            default = "Authorization"
        },
        forward_header = {
            type = "string",
            default = "Authorization"
        },
        strict = {
            type = "boolean",
            default = true
        }
    },
    required = { "header", "forward_header" },
}

local consumer_schema = {
    type = "object",
    properties = {
        key = { type = "string" },
        secret = { type = "string" },
        is_base64_encoded = { type = "boolean" },
    },
    required = { "key", "secret" },
    encrypt_fields = { "key", "secret" },
}


local _M = {
    version = 0.1,
    priority = 2509,
    type = 'auth',
    name = plugin_name,
    schema = schema,
    consumer_schema = consumer_schema
}


function _M.check_schema(conf, schema_type)
    if schema_type == core.schema.TYPE_CONSUMER then
        local ok, err = core.schema.check(consumer_schema, conf)
        if not ok then
            return false, err
        end

        local local_conf, err = core.config.local_conf(true)
        if not local_conf then
            return false, "failed to load the configuration file: " .. err
        end

        local encrypted = core.table.try_read_attr(local_conf, "apisix", "data_encryption",
        "enable_encrypt_fields") and (core.config.type == "etcd")

        -- if encrypted, the secret length will exceed 32 so don't check
        if not encrypted then
            -- restrict the length of secret, we use A256GCM for encryption,
            -- so the length should be 32 chars only
            if conf.is_base64_encoded then
                local decoded = base64.decode_base64url(conf.secret)
                if not decoded then
                    return false, "the secret should be a base64url encoded string"
                end

                if #decoded ~= 32 then
                    return false, "the secret length after base64 decode should be 32 chars"
                end
            else
                if #conf.secret ~= 32 then
                    return false, "the secret length should be 32 chars"
                end
            end
        end

        return true
    end
    return core.schema.check(schema, conf)
end


local function get_secret(conf)
    local secret = conf.secret

    if conf.is_base64_encoded then
        return base64.decode_base64url(secret)
    end

    return secret
end


local function load_jwe_token(jwe_token)
    local o = { valid = false }
    o.header, o.enckey, o.iv, o.ciphertext, o.tag = jwe_token:match("(.-)%.(.-)%.(.-)%.(.-)%.(.*)")
    if not o.header then
        return o
    end
    local he = base64.decode_base64url(o.header)
    if not he then
        return o
    end
    o.header_obj = core.json.decode(he)
    -- a JSON scalar decodes to a non-table value, `null` even to a truthy
    -- userdata, so indexing the header later would throw
    if type(o.header_obj) ~= "table" then
        return o
    end
    o.valid = true
    return o
end


-- the plugin only implements direct encryption with A256GCM; reject a token
-- that asks for anything else instead of failing later with a decrypt error
local function unsupported_header(header_obj)
    if header_obj.alg ~= nil and header_obj.alg ~= "dir" then
        return true
    end

    return header_obj.enc ~= nil and header_obj.enc ~= "A256GCM"
end


local function jwe_decrypt_with_obj(o, consumer)
    local secret = get_secret(consumer.auth_conf)
    if not secret then
        return nil, "invalid secret in the consumer configuration"
    end

    local dec = base64.decode_base64url
    local iv, ciphertext, tag = dec(o.iv), dec(o.ciphertext), dec(o.tag)
    if not iv or not ciphertext or not tag then
        return nil, "invalid base64url encoding in the JWE token"
    end

    local aes_default, err = aes:new(
        secret,
        nil,
        cipher,
        {iv = iv}
    )
    if not aes_default then
        return nil, err
    end

    -- RFC 7516 authenticates the encoded protected header as the AES-GCM
    -- additional authenticated data, which is what JWE libraries produce
    local decrypted, decrypt_err = aes_default:decrypt(ciphertext, tag, o.header)
    if decrypted then
        return decrypted
    end

    -- tokens built the way APISIX used to build them carry no AAD
    local plaintext, legacy_err = aes_default:decrypt(ciphertext, tag)
    if not plaintext then
        return nil, decrypt_err or legacy_err
    end

    return plaintext
end


local function get_consumer(key)
    local consumer_conf = consumer_mod.plugin(plugin_name)
    if not consumer_conf then
        return nil
    end
    local consumers = consumer_mod.consumers_kv(plugin_name, consumer_conf, "key")
    if not consumers then
        return nil
    end
    return consumers[key]
end


local function fetch_jwe_token(conf, ctx)
    local token = core.request.header(ctx, conf.header)
    if token then
        local prefix = sub_str(token, 1, 7)
        if prefix == 'Bearer ' or prefix == 'bearer ' then
            return sub_str(token, 8)
        end

        return token
    end
end


function _M.rewrite(conf, ctx)
    -- fetch token and hide credentials if necessary
    local jwe_token, err = fetch_jwe_token(conf, ctx)
    if not jwe_token then
        -- If true, throw a 403 error if JWE token is missing from the request.
        -- If false, do not throw an error when JWE token is not found.
        if conf.strict then
            core.log.info("failed to fetch JWE token: ", err)
            return 403, { message = "missing JWE token in request" }
        end
        return
    end

    local jwe_obj = load_jwe_token(jwe_token)
    if not jwe_obj.valid then
        return 400, { message = "JWE token invalid" }
    end

    if not jwe_obj.header_obj.kid then
        return 400, { message = "missing kid in JWE token" }
    end

    if unsupported_header(jwe_obj.header_obj) then
        return 400, { message = "unsupported alg or enc in JWE token" }
    end

    local consumer = get_consumer(jwe_obj.header_obj.kid)
    if not consumer then
        return 400, { message = "invalid kid in JWE token" }
    end

    local plaintext, err = jwe_decrypt_with_obj(jwe_obj, consumer)
    if not plaintext then
        core.log.info("failed to decrypt JWE token: ", err)
        return 400, { message = "failed to decrypt JWE token" }
    end
    core.request.set_header(ctx, conf.forward_header, plaintext)
end

return _M
