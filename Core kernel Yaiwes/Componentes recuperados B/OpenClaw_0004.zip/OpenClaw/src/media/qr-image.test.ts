import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { afterAll, beforeAll, beforeEach, describe, expect, it, vi } from "vitest";
import { useAutoCleanupTempDirTracker } from "../../test/helpers/temp-dir.js";

const { MOCK_PNG_BASE64, MOCK_PNG_BUFFER, toBuffer } = vi.hoisted(() => {
  const MOCK_PNG_BUFFERLocal = Buffer.from("fakepng");
  return {
    MOCK_PNG_BASE64: MOCK_PNG_BUFFERLocal.toString("base64"),
    MOCK_PNG_BUFFER: MOCK_PNG_BUFFERLocal,
    toBuffer: vi.fn(async () => MOCK_PNG_BUFFERLocal),
  };
});

vi.mock("./qr-runtime.ts", () => ({
  loadQrCodeRuntime: async () => ({ toBuffer }),
}));

let renderQrPngBase64: typeof import("./qr-image.ts").renderQrPngBase64;
let renderQrPngDataUrl: typeof import("./qr-image.ts").renderQrPngDataUrl;
let writeQrPngTempFile: typeof import("./qr-image.ts").writeQrPngTempFile;

beforeAll(async () => {
  vi.resetModules();
  ({ renderQrPngBase64, renderQrPngDataUrl, writeQrPngTempFile } = await import("./qr-image.ts"));
});

describe("renderQrPngBase64", () => {
  beforeEach(() => {
    toBuffer.mockClear();
    toBuffer.mockResolvedValue(MOCK_PNG_BUFFER);
  });

  it("delegates PNG rendering to qrcode", async () => {
    await expect(renderQrPngBase64("openclaw", { scale: 8, marginModules: 2 })).resolves.toBe(
      MOCK_PNG_BASE64,
    );
    expect(toBuffer).toHaveBeenCalledWith("openclaw", {
      margin: 2,
      scale: 8,
    });
  });

  it("uses the default PNG rendering options", async () => {
    await renderQrPngBase64("openclaw");
    expect(toBuffer).toHaveBeenCalledWith("openclaw", {
      margin: 4,
      scale: 6,
    });
  });

  it("floors finite PNG rendering options before delegating", async () => {
    await renderQrPngBase64("openclaw", { scale: 8.9, marginModules: 2.9 });
    expect(toBuffer).toHaveBeenCalledWith("openclaw", {
      margin: 2,
      scale: 8,
    });
  });

  it.each([
    ["scale", 0, 4, "scale must be between 1 and 12."],
    ["scale", 13, 4, "scale must be between 1 and 12."],
    ["scale", Number.NaN, 4, "scale must be a finite number."],
    ["marginModules", 6, -1, "marginModules must be between 0 and 16."],
    ["marginModules", 6, 17, "marginModules must be between 0 and 16."],
    ["marginModules", 6, Number.POSITIVE_INFINITY, "marginModules must be a finite number."],
  ])("rejects invalid %s values", async (_name, scale, marginModules, message) => {
    await expect(renderQrPngBase64("openclaw", { scale, marginModules })).rejects.toThrow(message);
    expect(toBuffer).not.toHaveBeenCalled();
  });

  it("formats QR PNG data URLs", async () => {
    await expect(renderQrPngDataUrl("openclaw")).resolves.toBe(
      `data:image/png;base64,${MOCK_PNG_BASE64}`,
    );
  });

  it("writes QR PNGs to a scoped temp file", async ({ onTestFinished }) => {
    const tmpRoot = useAutoCleanupTempDirTracker(onTestFinished).make("openclaw-qr-image-");

    const result = await writeQrPngTempFile("openclaw", {
      tmpRoot,
      dirPrefix: "pair-",
      fileName: "pair-qr.png",
    });

    expect(path.basename(result.filePath)).toBe("pair-qr.png");
    expect(path.basename(result.dirPath)).toMatch(/^pair-/);
    expect(result.mediaLocalRoots).toEqual([result.dirPath]);
    await expect(fs.readFile(result.filePath, "utf8")).resolves.toBe("fakepng");
  });

  it.each([
    ["dirPrefix", { dirPrefix: "../pair-", fileName: "qr.png" }],
    ["fileName", { dirPrefix: "pair-", fileName: "../qr.png" }],
  ])("rejects pathful QR temp %s values", async (name, opts) => {
    await expect(
      writeQrPngTempFile("openclaw", {
        tmpRoot: os.tmpdir(),
        dirPrefix: opts.dirPrefix,
        fileName: opts.fileName,
      }),
    ).rejects.toThrow(`${name} must be a non-empty filename segment.`);
    expect(toBuffer).not.toHaveBeenCalled();
  });
});

afterAll(() => {
  vi.doUnmock("./qr-runtime.ts");
  vi.resetModules();
});
