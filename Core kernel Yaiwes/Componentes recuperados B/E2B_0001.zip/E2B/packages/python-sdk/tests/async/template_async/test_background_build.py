import uuid

import pytest

from e2b import AsyncTemplate, wait_for_timeout


@pytest.mark.skip_debug()
@pytest.mark.timeout(10)
async def test_build_in_background_should_start_build_and_return_info():
    """Test that build_in_background returns immediately without waiting for build to complete."""
    template = (
        AsyncTemplate()
        .from_image("ubuntu:22.04")
        .skip_cache()
        .run_cmd("sleep 5")  # Add a delay to ensure build takes time
        .set_start_cmd('echo "Hello"', wait_for_timeout(10_000))
    )

    name = f"e2b-test:v1-{uuid.uuid4()}"

    build_info = await AsyncTemplate.build_in_background(
        template,
        name,
        cpu_count=1,
        memory_mb=1024,
    )

    # Should return quickly (within a few seconds), not wait for the full build
    assert build_info is not None

    # Verify the build is actually running
    status = await AsyncTemplate.get_build_status(build_info)
    assert status.status.value == "building"
