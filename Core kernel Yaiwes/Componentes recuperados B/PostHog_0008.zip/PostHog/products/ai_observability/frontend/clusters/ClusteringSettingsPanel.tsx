import { useActions, useValues } from 'kea'

import { LemonBanner, LemonButton, LemonModal } from '@posthog/lemon-ui'

import { AccessControlAction } from 'lib/components/AccessControlAction'
import { PropertyFilters } from 'lib/components/PropertyFilters/PropertyFilters'
import { TaxonomicFilterGroupType } from 'lib/components/TaxonomicFilter/types'

import { AccessControlLevel, AccessControlResourceType } from '~/types'

import { clusteringConfigLogic } from './clusteringConfigLogic'

export function ClusteringSettingsPanel(): JSX.Element {
    const { isSettingsPanelOpen, localEventFilters, configLoading } = useValues(clusteringConfigLogic)
    const { closeSettingsPanel, setLocalEventFilters, saveEventFilters } = useActions(clusteringConfigLogic)

    return (
        <LemonModal
            isOpen={isSettingsPanelOpen}
            onClose={closeSettingsPanel}
            title="Clustering settings"
            description="Configure event filters applied to both summarization and clustering pipelines."
            footer={
                <>
                    <div className="flex-1" />
                    <LemonButton type="secondary" onClick={closeSettingsPanel} data-attr="clustering-settings-cancel">
                        Cancel
                    </LemonButton>
                    <AccessControlAction
                        resourceType={AccessControlResourceType.AiObservabilityClusters}
                        minAccessLevel={AccessControlLevel.Editor}
                    >
                        <LemonButton
                            type="primary"
                            onClick={saveEventFilters}
                            loading={configLoading}
                            data-attr="clustering-settings-save"
                        >
                            Save
                        </LemonButton>
                    </AccessControlAction>
                </>
            }
        >
            <div className="space-y-4">
                <div>
                    <h4 className="font-semibold mb-3">Event filters</h4>
                    <div className="text-sm text-muted mb-3">
                        Only include traces and generations matching these criteria in automated summarization and
                        clustering. Leave empty to include all.
                    </div>
                    <PropertyFilters
                        propertyFilters={localEventFilters}
                        onChange={(properties) => setLocalEventFilters(properties)}
                        pageKey="clustering-config-event-filters"
                        taxonomicGroupTypes={[
                            TaxonomicFilterGroupType.EventProperties,
                            TaxonomicFilterGroupType.EventMetadata,
                            TaxonomicFilterGroupType.PersonProperties,
                            TaxonomicFilterGroupType.Cohorts,
                        ]}
                        addText="Add event filter"
                        hasRowOperator={false}
                        sendAllKeyUpdates
                        allowRelativeDateOptions={false}
                    />
                    <LemonBanner type="info" className="mt-3">
                        Saved filters will be applied on the next automated clustering and summarization run.
                    </LemonBanner>
                </div>
            </div>
        </LemonModal>
    )
}
