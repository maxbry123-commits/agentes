import { useActions, useMountedLogic, useValues } from 'kea'
import { combineUrl, router } from 'kea-router'

import { IconCopy, IconTrends } from '@posthog/icons'

import { LemonButton } from 'lib/lemon-ui/LemonButton'
import { Link } from 'lib/lemon-ui/Link'
import { Tooltip } from 'lib/lemon-ui/Tooltip'
import { copyToClipboard } from 'lib/utils/copyToClipboard'
import { urls } from 'scenes/urls'

import { DataTable } from '~/queries/nodes/DataTable/DataTable'
import { type InsightVizNode, NodeKind } from '~/queries/schema/schema-general'
import { isHogQLQuery } from '~/queries/utils'
import { type AnyPropertyFilter, PropertyFilterType, PropertyOperator } from '~/types'

import { buildApplyUrlStatePayload, aiObservabilitySharedLogic } from './aiObservabilitySharedLogic'
import { useSortableColumns } from './hooks/useSortableColumns'
import { aiObservabilityErrorsLogic } from './tabs/aiObservabilityErrorsLogic'

export function buildErrorTracesUrl(
    errorString: string,
    searchParams: Record<string, unknown>,
    currentPropertyFilters: AnyPropertyFilter[]
): string {
    return combineUrl(urls.aiObservabilityTraces(), {
        ...searchParams,
        filters: [
            ...currentPropertyFilters,
            {
                type: PropertyFilterType.Event,
                key: '$ai_is_error',
                operator: PropertyOperator.Exact,
                value: 'true',
            },
            {
                type: PropertyFilterType.Event,
                key: '$ai_error_normalized',
                operator: PropertyOperator.Exact,
                value: errorString,
            },
        ],
    }).url
}

export function AIObservabilityErrors(): JSX.Element {
    const sharedLogic = useMountedLogic(aiObservabilitySharedLogic)
    const { applyUrlState } = useActions(aiObservabilitySharedLogic)
    const { dateFilter, propertyFilters: currentPropertyFilters } = useValues(aiObservabilitySharedLogic)
    const { setErrorsSort } = useActions(aiObservabilityErrorsLogic)
    const { errorsQuery, errorsSort, buildErrorTrendQuery, buildAllErrorsTrendQuery } =
        useValues(aiObservabilityErrorsLogic)
    const { searchParams } = useValues(router)

    const { renderSortableColumnTitle } = useSortableColumns(errorsSort, setErrorsSort)

    return (
        <DataTable
            attachTo={sharedLogic}
            query={{
                ...errorsQuery,
                showSavedFilters: true,
            }}
            setQuery={(query) => {
                if (!isHogQLQuery(query.source)) {
                    console.warn('AIObservabilityErrors received a non-HogQL query:', query.source)
                    return
                }
                const { filters = {} } = query.source
                const { dateRange = {} } = filters
                applyUrlState(
                    buildApplyUrlStatePayload({
                        dateFrom: dateRange.date_from || null,
                        dateTo: dateRange.date_to || null,
                        shouldFilterTestAccounts: filters.filterTestAccounts || false,
                        propertyFilters: filters.properties || [],
                        currentDateFilter: dateFilter,
                        currentPropertyFilters,
                    })
                )
            }}
            context={{
                customActions: [
                    <Tooltip title="View error trends over time" key="trends">
                        <LemonButton
                            icon={<IconTrends />}
                            size="small"
                            type="secondary"
                            to={urls.insightNew({ query: buildAllErrorsTrendQuery })}
                            targetBlank
                            data-attr="llma-errors-all-trends-click"
                        >
                            Error trends
                        </LemonButton>
                    </Tooltip>,
                ],
                columns: {
                    error: {
                        renderTitle: () => (
                            <Tooltip title="Normalized error message with IDs, timestamps, and numbers replaced by placeholders for grouping">
                                <span>Error</span>
                            </Tooltip>
                        ),
                        render: function RenderError(x) {
                            const errorValue = x.value
                            if (!errorValue || errorValue === 'null' || errorValue === '') {
                                return <span className="text-muted">No error</span>
                            }

                            const errorString = String(errorValue)
                            const displayValue =
                                errorString.length > 80 ? errorString.slice(0, 77) + '...' : errorString

                            return (
                                <div className="flex min-w-0 items-center gap-1">
                                    <Tooltip title={errorString}>
                                        <Link
                                            to={buildErrorTracesUrl(errorString, searchParams, currentPropertyFilters)}
                                            className="min-w-0 shrink truncate font-mono text-sm"
                                            data-attr="llm-errors-row-click"
                                        >
                                            {displayValue}
                                        </Link>
                                    </Tooltip>
                                    <Tooltip title={`View ${displayValue} trend over time`}>
                                        <LemonButton
                                            icon={<IconTrends />}
                                            size="xsmall"
                                            to={urls.insightNew({
                                                query: {
                                                    kind: NodeKind.InsightVizNode,
                                                    source: buildErrorTrendQuery(errorString),
                                                } as InsightVizNode,
                                            })}
                                            targetBlank
                                            data-attr="llma-errors-trend-click"
                                        />
                                    </Tooltip>
                                    <LemonButton
                                        size="xsmall"
                                        noPadding
                                        icon={<IconCopy />}
                                        onClick={(e) => {
                                            e.preventDefault()
                                            e.stopPropagation()
                                            copyToClipboard(errorString, 'error')
                                        }}
                                        tooltip="Copy error to clipboard"
                                        className="opacity-50 hover:opacity-100"
                                    />
                                </div>
                            )
                        },
                    },
                    first_seen: {
                        renderTitle: () => renderSortableColumnTitle('first_seen', 'First Seen'),
                    },
                    last_seen: {
                        renderTitle: () => renderSortableColumnTitle('last_seen', 'Last Seen'),
                    },
                    traces: {
                        renderTitle: () => (
                            <Tooltip title="Number of unique traces with this error">
                                {renderSortableColumnTitle('traces', 'Traces')}
                            </Tooltip>
                        ),
                    },
                    generations: {
                        renderTitle: () => (
                            <Tooltip title="Number of generations with this error">
                                {renderSortableColumnTitle('generations', 'Generations')}
                            </Tooltip>
                        ),
                    },
                    spans: {
                        renderTitle: () => (
                            <Tooltip title="Number of spans with this error">
                                {renderSortableColumnTitle('spans', 'Spans')}
                            </Tooltip>
                        ),
                    },
                    embeddings: {
                        renderTitle: () => (
                            <Tooltip title="Number of embeddings with this error">
                                {renderSortableColumnTitle('embeddings', 'Embeddings')}
                            </Tooltip>
                        ),
                    },
                    sessions: {
                        renderTitle: () => (
                            <Tooltip title="Number of unique sessions with this error">
                                {renderSortableColumnTitle('sessions', 'Sessions')}
                            </Tooltip>
                        ),
                    },
                    users: {
                        renderTitle: () => (
                            <Tooltip title="Number of unique users who encountered this error">
                                {renderSortableColumnTitle('users', 'Users')}
                            </Tooltip>
                        ),
                    },
                    days_seen: {
                        renderTitle: () => (
                            <Tooltip title="Number of distinct days this error occurred">
                                {renderSortableColumnTitle('days_seen', 'Days Seen')}
                            </Tooltip>
                        ),
                    },
                },
            }}
            uniqueKey="llm-analytics-errors"
        />
    )
}
