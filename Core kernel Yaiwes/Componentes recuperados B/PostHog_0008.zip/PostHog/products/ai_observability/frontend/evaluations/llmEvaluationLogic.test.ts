import { combineUrl, router } from 'kea-router'
import { expectLogic } from 'kea-test-utils'

import { urls } from 'scenes/urls'

import { useMocks } from '~/mocks/jest'
import { initKeaTests } from '~/test/init'
import { ActivityScope } from '~/types'

import type { TestHogResponseApi } from '../generated/api.schemas'
import { LLMProviderKey, llmProviderKeysLogic } from '../settings/llmProviderKeysLogic'
import { evaluationReportLogic } from './evaluationReportLogic'
import { DEFAULT_HOG_SOURCE, llmEvaluationLogic } from './llmEvaluationLogic'
import { llmEvaluationsLogic } from './llmEvaluationsLogic'
import { EvaluationConfig, EvaluationReport, EvaluationRun } from './types'

const mockProviderKeys: LLMProviderKey[] = [
    {
        id: 'key-1',
        provider: 'openai',
        name: 'Production Key',
        state: 'ok',
        error_message: null,
        api_key_masked: 'sk-...1234',
        created_at: '2024-01-01T00:00:00Z',
        created_by: null,
        last_used_at: null,
        azure_endpoint_display: null,
        api_version_display: null,
    },
    {
        id: 'key-2',
        provider: 'anthropic',
        name: 'Anthropic Key',
        state: 'ok',
        error_message: null,
        api_key_masked: 'sk-ant-...5678',
        created_at: '2024-01-02T00:00:00Z',
        created_by: null,
        last_used_at: null,
        azure_endpoint_display: null,
        api_version_display: null,
    },
    {
        id: 'key-3',
        provider: 'openrouter',
        name: 'OpenRouter Key',
        state: 'ok',
        error_message: null,
        api_key_masked: 'sk-or-...9012',
        created_at: '2024-01-03T00:00:00Z',
        created_by: null,
        last_used_at: null,
        azure_endpoint_display: null,
        api_version_display: null,
    },
    {
        id: 'key-4',
        provider: 'fireworks',
        name: 'Fireworks Key',
        state: 'ok',
        error_message: null,
        api_key_masked: 'fw-...3456',
        created_at: '2024-01-04T00:00:00Z',
        created_by: null,
        last_used_at: null,
        azure_endpoint_display: null,
        api_version_display: null,
    },
]

const mockEvaluation: EvaluationConfig = {
    id: 'eval-123',
    name: 'Test Evaluation',
    description: 'A test evaluation',
    enabled: true,
    status: 'active',
    status_reason: null,
    status_reason_detail: null,
    evaluation_type: 'llm_judge',
    evaluation_config: { prompt: 'Is this response helpful?' },
    output_type: 'boolean',
    output_config: { allows_na: false },
    conditions: [{ id: 'cond-1', rollout_percentage: 50, properties: [] }],
    target: 'generation',
    target_config: {},
    model_configuration: {
        provider: 'openai',
        model: 'gpt-5-mini',
        provider_key_id: 'key-1',
    },
    total_runs: 10,
    created_at: '2024-01-01T00:00:00Z',
    updated_at: '2024-01-01T00:00:00Z',
}

const mockEvaluationReport: EvaluationReport = {
    id: 'report-123',
    evaluation: 'eval-123',
    frequency: 'scheduled',
    rrule: 'FREQ=WEEKLY;BYDAY=FR',
    starts_at: '2024-01-01T00:00:00Z',
    timezone_name: 'UTC',
    next_delivery_date: '2024-01-05T00:00:00Z',
    delivery_targets: [{ type: 'email', value: 'alerts@example.com' }],
    max_sample_size: 200,
    enabled: true,
    deleted: false,
    last_delivered_at: null,
    report_prompt_guidance: 'Focus on regressions.',
    trigger_threshold: 500,
    cooldown_minutes: 180,
    daily_run_cap: 8,
    created_by: null,
    created_at: '2024-01-01T00:00:00Z',
}

const mockRuns: EvaluationRun[] = [
    {
        id: 'run-1',
        evaluation_id: 'eval-123',
        evaluation_name: 'Test Evaluation',
        generation_id: 'gen-1',
        trace_id: 'trace-1',
        timestamp: '2024-01-01T12:00:00Z',
        result: true,
        applicable: true,
        reasoning: 'The response was helpful',
        status: 'completed',
    },
    {
        id: 'run-2',
        evaluation_id: 'eval-123',
        evaluation_name: 'Test Evaluation',
        generation_id: 'gen-2',
        trace_id: 'trace-2',
        timestamp: '2024-01-01T13:00:00Z',
        result: false,
        applicable: true,
        reasoning: 'The response was not helpful',
        status: 'completed',
    },
    {
        id: 'run-3',
        evaluation_id: 'eval-123',
        evaluation_name: 'Test Evaluation',
        generation_id: 'gen-3',
        trace_id: 'trace-3',
        timestamp: '2024-01-01T14:00:00Z',
        result: null,
        applicable: false,
        reasoning: 'Not applicable',
        status: 'completed',
    },
]

const mockSentimentEvaluation: EvaluationConfig = {
    ...mockEvaluation,
    evaluation_type: 'sentiment',
    evaluation_config: { source: 'user_messages' },
    output_type: 'sentiment',
    output_config: {},
    model_configuration: null,
}

const mockSentimentRuns: EvaluationRun[] = [
    {
        id: 'run-negative',
        evaluation_id: 'eval-123',
        evaluation_name: 'Sentiment Evaluation',
        generation_id: 'gen-negative',
        trace_id: 'trace-negative',
        timestamp: '2024-01-01T12:00:00Z',
        evaluation_type: 'sentiment',
        result_type: 'sentiment',
        result: null,
        sentiment_label: 'negative',
        sentiment_score: -0.8,
        reasoning: 'The message was frustrated',
        status: 'completed',
    },
    {
        id: 'run-positive',
        evaluation_id: 'eval-123',
        evaluation_name: 'Sentiment Evaluation',
        generation_id: 'gen-positive',
        trace_id: 'trace-positive',
        timestamp: '2024-01-01T13:00:00Z',
        evaluation_type: 'sentiment',
        result_type: 'sentiment',
        result: null,
        sentiment_label: 'positive',
        sentiment_score: 0.7,
        reasoning: 'The message was happy',
        status: 'completed',
    },
    {
        id: 'run-neutral',
        evaluation_id: 'eval-123',
        evaluation_name: 'Sentiment Evaluation',
        generation_id: 'gen-neutral',
        trace_id: 'trace-neutral',
        timestamp: '2024-01-01T14:00:00Z',
        evaluation_type: 'sentiment',
        result_type: 'sentiment',
        result: null,
        sentiment_label: 'neutral',
        sentiment_score: 0.1,
        reasoning: 'The message was neutral',
        status: 'completed',
    },
    {
        id: 'run-positive-failed',
        evaluation_id: 'eval-123',
        evaluation_name: 'Sentiment Evaluation',
        generation_id: 'gen-positive-failed',
        trace_id: 'trace-positive-failed',
        timestamp: '2024-01-01T15:00:00Z',
        evaluation_type: 'sentiment',
        result_type: 'sentiment',
        result: null,
        sentiment_label: 'positive',
        sentiment_score: 0.5,
        reasoning: 'This run did not complete',
        status: 'failed',
    },
]

describe('llmEvaluationLogic', () => {
    let logic: ReturnType<typeof llmEvaluationLogic.build>
    let keysLogic: ReturnType<typeof llmProviderKeysLogic.build>

    beforeEach(() => {
        useMocks({
            get: {
                '/api/environments/:teamId/llm_analytics/provider_keys/': { results: mockProviderKeys },
                '/api/environments/:teamId/llm_analytics/evaluation_config/': {
                    active_provider_key: null,
                    created_at: '2024-01-01T00:00:00Z',
                    updated_at: '2024-01-01T00:00:00Z',
                },
                '/api/projects/:teamId/evaluations/:id/': mockEvaluation,
                '/api/environments/:teamId/llm_analytics/models/': {
                    models: [
                        { id: 'gpt-5-mini', provider: 'openai' },
                        { id: 'gpt-5', provider: 'openai' },
                    ],
                    providers: [{ provider: 'openai', model_count: 2, requires_provider_key: false }],
                },
            },
        })
        initKeaTests()
        keysLogic = llmProviderKeysLogic()
        keysLogic.mount()
    })

    afterEach(() => {
        logic?.unmount()
        keysLogic?.unmount()
    })

    describe('reducers', () => {
        beforeEach(() => {
            logic = llmEvaluationLogic({ evaluationId: 'new' })
            logic.mount()
        })

        it('setEvaluationName updates evaluation name', async () => {
            await expectLogic(logic).toDispatchActions(['loadEvaluationSuccess'])

            logic.actions.setEvaluationName('New Name')

            await expectLogic(logic).toMatchValues({
                evaluation: expect.objectContaining({ name: 'New Name' }),
                hasUnsavedChanges: true,
            })
        })

        it('setEvaluationPrompt updates evaluation prompt', async () => {
            await expectLogic(logic).toDispatchActions(['loadEvaluationSuccess'])

            logic.actions.setEvaluationPrompt('New prompt')

            await expectLogic(logic).toMatchValues({
                evaluation: expect.objectContaining({
                    evaluation_config: { prompt: 'New prompt' },
                }),
            })
        })

        it('setAllowsNA updates output config', async () => {
            await expectLogic(logic).toDispatchActions(['loadEvaluationSuccess'])

            logic.actions.setAllowsNA(true)

            await expectLogic(logic).toMatchValues({
                evaluation: expect.objectContaining({
                    output_config: { allows_na: true },
                }),
            })
        })

        it('setTriggerConditions updates conditions', async () => {
            await expectLogic(logic).toDispatchActions(['loadEvaluationSuccess'])

            const newConditions = [{ id: 'new-cond', rollout_percentage: 100, properties: [] }]
            logic.actions.setTriggerConditions(newConditions)

            await expectLogic(logic).toMatchValues({
                evaluation: expect.objectContaining({ conditions: newConditions }),
            })
        })

        it('initializes new evaluations with 100% sampling', async () => {
            await expectLogic(logic).toDispatchActions(['loadEvaluationSuccess'])

            await expectLogic(logic).toMatchValues({
                evaluation: expect.objectContaining({
                    conditions: [expect.objectContaining({ rollout_percentage: 100 })],
                }),
            })
        })

        it('setModelConfiguration updates model config', async () => {
            await expectLogic(logic).toDispatchActions(['loadEvaluationSuccess'])

            const newConfig = { provider: 'anthropic' as const, model: 'claude-3-5-haiku', provider_key_id: 'key-2' }
            logic.actions.setModelConfiguration(newConfig)

            await expectLogic(logic).toMatchValues({
                evaluation: expect.objectContaining({ model_configuration: newConfig }),
            })
        })

        it('hasUnsavedChanges resets on save success', async () => {
            await expectLogic(logic).toDispatchActions(['loadEvaluationSuccess'])

            logic.actions.setEvaluationName('Changed Name')

            await expectLogic(logic).toMatchValues({ hasUnsavedChanges: true })

            logic.actions.saveEvaluationSuccess(mockEvaluation)

            await expectLogic(logic).toMatchValues({ hasUnsavedChanges: false })
        })

        it('uses the target-independent Hog default for a trace target', async () => {
            await expectLogic(logic).toDispatchActions(['loadEvaluationSuccess'])

            logic.actions.setEvaluationTarget('trace')
            logic.actions.setEvaluationType('hog')

            await expectLogic(logic).toMatchValues({
                evaluation: expect.objectContaining({
                    evaluation_config: { source: DEFAULT_HOG_SOURCE },
                }),
            })
        })

        it('keeps the untouched Hog default when the target changes', async () => {
            await expectLogic(logic).toDispatchActions(['loadEvaluationSuccess'])

            logic.actions.setEvaluationType('hog')
            await expectLogic(logic).toMatchValues({
                evaluation: expect.objectContaining({ evaluation_config: { source: DEFAULT_HOG_SOURCE } }),
            })

            logic.actions.setEvaluationTarget('trace')
            await expectLogic(logic).toMatchValues({
                evaluation: expect.objectContaining({ evaluation_config: { source: DEFAULT_HOG_SOURCE } }),
            })
        })

        it('replaces the legacy generation default when switching to trace', async () => {
            await expectLogic(logic).toDispatchActions(['loadEvaluationSuccess'])

            logic.actions.loadEvaluationSuccess({
                ...mockEvaluation,
                evaluation_type: 'hog',
                evaluation_config: {
                    source: `// Check that the output is not empty
let result := length(output) > 0
if (not result) {
    print('Output is empty')
}
return result`,
                },
                model_configuration: null,
            })
            logic.actions.setEvaluationTarget('trace')

            await expectLogic(logic).toMatchValues({
                evaluation: expect.objectContaining({ evaluation_config: { source: DEFAULT_HOG_SOURCE } }),
            })
        })

        it('does not clobber an edited Hog source when the target changes', async () => {
            await expectLogic(logic).toDispatchActions(['loadEvaluationSuccess'])

            logic.actions.setEvaluationType('hog')
            logic.actions.setHogSource('return length(events) > 5')
            logic.actions.setEvaluationTarget('trace')

            await expectLogic(logic).toMatchValues({
                evaluation: expect.objectContaining({
                    evaluation_config: expect.objectContaining({ source: 'return length(events) > 5' }),
                }),
            })
        })

        it('seeds a fixed window settle config when switching target to trace', async () => {
            await expectLogic(logic).toDispatchActions(['loadEvaluationSuccess'])

            logic.actions.setEvaluationTarget('trace')

            expect(logic.values.evaluation?.target_config).toEqual({
                strategy: 'fixed_window',
                window_seconds: 30 * 60,
            })
        })

        it('seeds inactivity defaults when switching settle strategy', async () => {
            await expectLogic(logic).toDispatchActions(['loadEvaluationSuccess'])

            logic.actions.setEvaluationTarget('trace')
            logic.actions.setSettleStrategy('inactivity')

            expect(logic.values.evaluation?.target_config).toEqual({
                strategy: 'inactivity',
                quiet_period_seconds: 5 * 60,
                max_age_seconds: 2 * 60 * 60,
            })
        })

        it('patches a single settle field without clobbering the rest', async () => {
            await expectLogic(logic).toDispatchActions(['loadEvaluationSuccess'])

            logic.actions.setEvaluationTarget('trace')
            logic.actions.setSettleStrategy('inactivity')
            logic.actions.patchTargetConfig({ quiet_period_seconds: 60 })

            expect(logic.values.evaluation?.target_config).toEqual({
                strategy: 'inactivity',
                quiet_period_seconds: 60,
                max_age_seconds: 2 * 60 * 60,
            })
        })

        it('reseeds the fixed window when switching strategy back', async () => {
            await expectLogic(logic).toDispatchActions(['loadEvaluationSuccess'])

            logic.actions.setEvaluationTarget('trace')
            logic.actions.setSettleStrategy('inactivity')
            logic.actions.setSettleStrategy('fixed_window')

            expect(logic.values.evaluation?.target_config).toEqual({
                strategy: 'fixed_window',
                window_seconds: 30 * 60,
            })
        })

        it('reseeding fixed window over an inactivity bag leaves no inactivity keys', () => {
            logic.actions.setEvaluationTarget('trace')
            logic.actions.setSettleStrategy('inactivity')
            logic.actions.setSettleStrategy('fixed_window')
            logic.actions.patchTargetConfig({ window_seconds: 900 })
            expect(logic.values.evaluation?.target_config).toEqual({
                strategy: 'fixed_window',
                window_seconds: 900,
            })
        })

        it('seeds inactivity defaults when switching to the session target', async () => {
            await expectLogic(logic, () => {
                logic.actions.setEvaluationTarget('session')
            }).toMatchValues({
                evaluation: expect.objectContaining({
                    target: 'session',
                    target_config: {
                        strategy: 'inactivity',
                        quiet_period_seconds: 3600,
                        max_age_seconds: 86400,
                    },
                }),
            })
        })

        it('reseeds with session defaults, not trace defaults, when switching strategy', async () => {
            await expectLogic(logic, () => {
                logic.actions.setEvaluationTarget('session')
                logic.actions.setSettleStrategy('fixed_window')
                logic.actions.setSettleStrategy('inactivity')
            }).toMatchValues({
                evaluation: expect.objectContaining({
                    target_config: {
                        strategy: 'inactivity',
                        quiet_period_seconds: 3600,
                        max_age_seconds: 86400,
                    },
                }),
            })
        })

        it('clears the settle bag when switching back to generation', async () => {
            await expectLogic(logic, () => {
                logic.actions.setEvaluationTarget('session')
                logic.actions.setEvaluationTarget('generation')
            }).toMatchValues({
                evaluation: expect.objectContaining({ target: 'generation', target_config: {} }),
            })
        })
    })

    describe('selectors', () => {
        describe('formValid', () => {
            beforeEach(() => {
                logic = llmEvaluationLogic({ evaluationId: 'new' })
                logic.mount()
            })

            it('returns false when evaluation is null', async () => {
                expect(logic.values.formValid).toBe(false)
            })

            it('returns false when name is empty', async () => {
                await expectLogic(logic).toDispatchActions(['loadEvaluationSuccess'])

                await expectLogic(logic).toMatchValues({ formValid: false })
            })

            it('returns false when prompt is empty', async () => {
                await expectLogic(logic).toDispatchActions(['loadEvaluationSuccess'])
                logic.actions.setEvaluationName('Valid Name')
                logic.actions.setTriggerConditions([{ id: 'c1', rollout_percentage: 50, properties: [] }])

                await expectLogic(logic).toMatchValues({ formValid: false })
            })

            it('returns false when an LLM judge has no selected model', async () => {
                await expectLogic(logic).toDispatchActions(['loadEvaluationSuccess'])
                logic.actions.setEvaluationName('Valid Name')
                logic.actions.setEvaluationPrompt('Valid prompt')
                logic.actions.setTriggerConditions([{ id: 'c1', rollout_percentage: 50, properties: [] }])

                await expectLogic(logic).toMatchValues({ formValid: false })
            })

            it('returns false when no conditions have rollout > 0', async () => {
                await expectLogic(logic).toDispatchActions(['loadEvaluationSuccess'])
                logic.actions.setEvaluationName('Valid Name')
                logic.actions.setEvaluationPrompt('Valid prompt')
                logic.actions.setTriggerConditions([{ id: 'c1', rollout_percentage: 0, properties: [] }])

                await expectLogic(logic).toMatchValues({ formValid: false })
            })

            it('returns false when conditions array is empty', async () => {
                await expectLogic(logic).toDispatchActions(['loadEvaluationSuccess'])
                logic.actions.setEvaluationName('Valid Name')
                logic.actions.setEvaluationPrompt('Valid prompt')
                logic.actions.setTriggerConditions([])

                await expectLogic(logic).toMatchValues({ formValid: false })
            })

            it.each([
                ['rollout_percentage of 0', 0],
                ['rollout_percentage above 100', 150],
            ])('returns false when %s', async (_label, percentage) => {
                await expectLogic(logic).toDispatchActions(['loadEvaluationSuccess'])
                logic.actions.setEvaluationName('Valid Name')
                logic.actions.setEvaluationPrompt('Valid prompt')
                logic.actions.setTriggerConditions([{ id: 'c1', rollout_percentage: percentage, properties: [] }])

                await expectLogic(logic).toMatchValues({ formValid: false })
            })

            it('returns true when all fields valid', async () => {
                await expectLogic(logic).toDispatchActions(['loadEvaluationSuccess'])
                logic.actions.setEvaluationName('Valid Name')
                logic.actions.setEvaluationPrompt('Valid prompt')
                logic.actions.setTriggerConditions([{ id: 'c1', rollout_percentage: 50, properties: [] }])
                logic.actions.setModelConfiguration({
                    provider: 'openai',
                    model: 'gpt-5-mini',
                    provider_key_id: 'key-1',
                })

                await expectLogic(logic).toMatchValues({ formValid: true })
            })

            // A loaded evaluation whose stored shape doesn't match its type (e.g. an llm_judge
            // record with no prompt) used to crash formValid with a TypeError on render.
            it.each([
                ['missing name', { ...mockEvaluation, name: undefined }],
                ['missing conditions', { ...mockEvaluation, conditions: undefined }],
                ['missing evaluation_config', { ...mockEvaluation, evaluation_config: undefined }],
                ['llm_judge missing prompt', { ...mockEvaluation, evaluation_config: {} }],
                ['hog missing source', { ...mockEvaluation, evaluation_type: 'hog' as const, evaluation_config: {} }],
            ])('returns false without throwing when %s', async (_label, malformed) => {
                logic.actions.loadEvaluationSuccess(malformed as unknown as EvaluationConfig)

                await expectLogic(logic).toMatchValues({ formValid: false })
            })
        })

        describe('sidePanelContext', () => {
            it('scopes the side panel to this evaluation once it loads', async () => {
                logic = llmEvaluationLogic({ evaluationId: 'eval-123' })
                logic.mount()

                await expectLogic(logic).toDispatchActions(['loadEvaluationSuccess'])

                await expectLogic(logic).toMatchValues({
                    sidePanelContext: {
                        activity_scope: ActivityScope.EVALUATION,
                        activity_item_id: 'eval-123',
                        access_control_resource: 'evaluation',
                        access_control_resource_id: 'eval-123',
                    },
                })
            })

            it('stays null while creating a new evaluation', async () => {
                logic = llmEvaluationLogic({ evaluationId: 'new' })
                logic.mount()

                await expectLogic(logic).toMatchValues({ sidePanelContext: null })
            })
        })

        describe('modelSelectionRequired', () => {
            beforeEach(() => {
                logic = llmEvaluationLogic({ evaluationId: 'eval-123' })
                logic.mount()
            })

            it('allows existing legacy evaluations without a model configuration to remain editable', async () => {
                await expectLogic(logic).toDispatchActions(['loadEvaluationSuccess'])

                logic.actions.loadEvaluationSuccess({ ...mockEvaluation, model_configuration: null })

                await expectLogic(logic).toMatchValues({ modelSelectionRequired: false, formValid: true })
            })

            it('requires an existing configured evaluation to keep a selected model', async () => {
                await expectLogic(logic).toDispatchActions(['loadEvaluationSuccess'])

                logic.actions.setModelConfiguration(null)

                await expectLogic(logic).toMatchValues({ modelSelectionRequired: true, formValid: false })
            })

            it('requires a model when converting an existing Hog evaluation to an LLM judge', async () => {
                await expectLogic(logic).toDispatchActions(['loadEvaluationSuccess'])
                logic.actions.loadEvaluationSuccess({
                    ...mockEvaluation,
                    evaluation_type: 'hog',
                    evaluation_config: { source: DEFAULT_HOG_SOURCE },
                    model_configuration: null,
                })

                logic.actions.setEvaluationType('llm_judge')

                await expectLogic(logic).toMatchValues({ modelSelectionRequired: true, formValid: false })
            })
        })

        describe('evaluationProviderKeyIssue', () => {
            beforeEach(() => {
                logic = llmEvaluationLogic({ evaluationId: 'eval-123' })
                logic.mount()
            })

            it.each([
                ['invalid' as const, 'Authentication failed'],
                ['error' as const, 'Quota exceeded'],
            ])('returns the provider key when state is %s', async (state, errorMessage) => {
                await expectLogic(logic).toDispatchActions(['loadEvaluationSuccess'])

                keysLogic.actions.loadProviderKeysSuccess(
                    mockProviderKeys.map((key) =>
                        key.id === 'key-1' ? { ...key, state, error_message: errorMessage } : key
                    )
                )

                await expectLogic(logic).toMatchValues({
                    evaluationProviderKeyIssue: expect.objectContaining({
                        id: 'key-1',
                        state,
                        error_message: errorMessage,
                    }),
                })
            })

            it('returns null when evaluation uses the PostHog default key', async () => {
                await expectLogic(logic).toDispatchActions(['loadEvaluationSuccess'])

                logic.actions.loadEvaluationSuccess({
                    ...mockEvaluation,
                    model_configuration: null,
                })

                await expectLogic(logic).toMatchValues({
                    evaluationProviderKeyIssue: null,
                })
            })

            it('returns null when provider key state is healthy', async () => {
                await expectLogic(logic).toDispatchActions(['loadEvaluationSuccess'])

                await expectLogic(logic).toMatchValues({
                    evaluationProviderKeyIssue: null,
                })
            })
        })

        describe('breadcrumbs', () => {
            it('does not show the template picker while an existing evaluation loads', () => {
                logic = llmEvaluationLogic({ evaluationId: 'eval-123' })
                logic.mount()

                expect(logic.values.evaluation).toBeNull()
                expect(logic.values.breadcrumbs.map((breadcrumb) => breadcrumb.name)).toEqual([
                    'Evaluations',
                    'New Evaluation',
                ])
            })
        })

        describe('runsSummary', () => {
            beforeEach(() => {
                logic = llmEvaluationLogic({ evaluationId: 'eval-123' })
                logic.mount()
            })

            it('returns null when no runs', async () => {
                expect(logic.values.runsSummary).toBeNull()
            })

            it('calculates summary from server-side aggregate counts', async () => {
                logic.actions.loadRunsStatsSuccess({ total: 3, applicable: 2, passed: 1 })

                await expectLogic(logic).toMatchValues({
                    runsSummary: {
                        total: 3,
                        successful: 1,
                        failed: 1,
                        errors: 0,
                        successRate: 50,
                        applicabilityRate: 67,
                    },
                })
            })
        })
    })

    describe('routing', () => {
        it('opens a direct configuration link and keeps tab changes in the URL', async () => {
            router.actions.push(
                combineUrl(urls.aiObservabilityEvaluation('eval-123'), {
                    evaluation_tab: 'configuration',
                }).url
            )
            logic = llmEvaluationLogic({ evaluationId: 'eval-123' })
            logic.mount()

            await expectLogic(logic).toDispatchActions(['loadEvaluationSuccess']).toMatchValues({
                activeTab: 'configuration',
            })

            logic.actions.setActiveTab('runs')

            expect(router.values.searchParams.evaluation_tab).toBeUndefined()
        })
    })

    describe('async flows', () => {
        describe('loadEvaluation', () => {
            it('initializes new evaluation with default values', async () => {
                // Pin the team to a state with an active key before mounting so the draft's enabled
                // default doesn't depend on config-fetch timing.
                keysLogic.actions.loadEvaluationConfigSuccess({
                    active_provider_key: mockProviderKeys[0],
                    created_at: '2024-01-01T00:00:00Z',
                    updated_at: '2024-01-01T00:00:00Z',
                })
                logic = llmEvaluationLogic({ evaluationId: 'new' })
                logic.mount()

                await expectLogic(logic).toDispatchActions(['loadEvaluationSuccess'])

                await expectLogic(logic).toMatchValues({
                    isNewEvaluation: true,
                    evaluation: expect.objectContaining({
                        id: '',
                        name: '',
                        enabled: true,
                        evaluation_type: 'llm_judge',
                        output_type: 'boolean',
                    }),
                })
            })

            it('initializes new evaluation disabled for teams that require a provider key', async () => {
                keysLogic.actions.loadEvaluationConfigSuccess({
                    active_provider_key: null,
                    created_at: '2024-01-01T00:00:00Z',
                    updated_at: '2024-01-01T00:00:00Z',
                })
                logic = llmEvaluationLogic({ evaluationId: 'new' })
                logic.mount()

                await expectLogic(logic).toDispatchActions(['loadEvaluationSuccess'])

                await expectLogic(logic).toMatchValues({
                    isNewEvaluation: true,
                    evaluation: expect.objectContaining({ enabled: false }),
                })
            })

            it('disables an enabled new draft when a late config load says the team requires a key', async () => {
                // The draft's enabled default is read before the config fetch resolves — the
                // listener must correct it when the config arrives late.
                keysLogic.actions.loadEvaluationConfigSuccess({
                    active_provider_key: mockProviderKeys[0],
                    created_at: '2024-01-01T00:00:00Z',
                    updated_at: '2024-01-01T00:00:00Z',
                })
                logic = llmEvaluationLogic({ evaluationId: 'new' })
                logic.mount()

                await expectLogic(logic).toDispatchActions(['loadEvaluationSuccess'])
                await expectLogic(logic).toMatchValues({
                    evaluation: expect.objectContaining({ enabled: true }),
                })

                keysLogic.actions.loadEvaluationConfigSuccess({
                    active_provider_key: null,
                    created_at: '2024-01-01T00:00:00Z',
                    updated_at: '2024-01-01T00:00:00Z',
                })

                await expectLogic(logic).toMatchValues({
                    evaluation: expect.objectContaining({ enabled: false }),
                })
            })

            it('loads existing evaluation', async () => {
                logic = llmEvaluationLogic({ evaluationId: 'eval-123' })
                logic.mount()

                await expectLogic(logic).toDispatchActions(['loadEvaluationSuccess'])

                await expectLogic(logic).toMatchValues({
                    isNewEvaluation: false,
                    evaluation: expect.objectContaining({
                        id: 'eval-123',
                        name: 'Test Evaluation',
                    }),
                })
            })

            it.each([
                {
                    name: 'LLM judge',
                    templateKey: 'relevance',
                    expectedEvaluation: {
                        name: 'Relevance',
                        evaluation_type: 'llm_judge',
                        evaluation_config: { prompt: expect.stringContaining('relevant') },
                        output_type: 'boolean',
                    },
                },
                {
                    name: 'Hog',
                    templateKey: 'cost_latency',
                    expectedEvaluation: {
                        name: 'Cost & latency',
                        evaluation_type: 'hog',
                        evaluation_config: { source: expect.stringContaining('latency'), bytecode: [] },
                        output_type: 'boolean',
                    },
                },
                {
                    name: 'sentiment',
                    templateKey: 'sentiment',
                    expectedEvaluation: {
                        name: 'Sentiment analysis',
                        evaluation_type: 'sentiment',
                        evaluation_config: { source: 'user_messages' },
                        output_type: 'sentiment',
                    },
                },
            ])('applies the $name template', async ({ templateKey, expectedEvaluation }) => {
                logic = llmEvaluationLogic({ evaluationId: 'new', templateKey })
                logic.mount()

                await expectLogic(logic).toDispatchActions(['loadEvaluationSuccess'])

                await expectLogic(logic).toMatchValues({
                    evaluation: expect.objectContaining(expectedEvaluation),
                })
            })
        })

        describe('resetEvaluation', () => {
            it('resets new evaluation to defaults', async () => {
                logic = llmEvaluationLogic({ evaluationId: 'new' })
                logic.mount()

                await expectLogic(logic).toDispatchActions(['loadEvaluationSuccess'])

                logic.actions.setEvaluationName('Changed Name')
                logic.actions.resetEvaluation()

                await expectLogic(logic).toMatchValues({
                    evaluation: expect.objectContaining({
                        name: '',
                        conditions: [expect.objectContaining({ rollout_percentage: 100 })],
                    }),
                    hasUnsavedChanges: false,
                })
            })

            it('resets existing evaluation to original', async () => {
                logic = llmEvaluationLogic({ evaluationId: 'eval-123' })
                logic.mount()

                await expectLogic(logic).toDispatchActions(['loadEvaluationSuccess'])

                logic.actions.setEvaluationName('Changed Name')
                logic.actions.resetEvaluation()

                await expectLogic(logic).toMatchValues({
                    evaluation: expect.objectContaining({ name: 'Test Evaluation' }),
                    hasUnsavedChanges: false,
                })
            })
        })
    })

    describe('runs filtering', () => {
        beforeEach(() => {
            logic = llmEvaluationLogic({ evaluationId: 'eval-123' })
            logic.mount()
        })

        describe('evaluationRunsFilter', () => {
            it('defaults to all', async () => {
                expect(logic.values.evaluationRunsFilter).toBe('all')
            })

            it('updates when setEvaluationRunsFilter is called', async () => {
                logic.actions.setEvaluationRunsFilter('pass', 'all')

                await expectLogic(logic).toMatchValues({
                    evaluationRunsFilter: 'pass',
                })
            })
        })

        describe('sentiment evaluation filters', () => {
            it('defaults to all for boolean evaluations', async () => {
                expect(logic.values.evaluationRunsFilter).toBe('all')
            })

            it('defaults to negative for sentiment evaluations', async () => {
                logic.actions.loadEvaluationSuccess(mockSentimentEvaluation)

                await expectLogic(logic).toMatchValues({
                    evaluationRunsFilter: 'negative',
                })
            })
        })

        describe('filteredEvaluationRuns', () => {
            it('returns all runs when filter is all', async () => {
                logic.actions.loadEvaluationRunsSuccess(mockRuns)

                await expectLogic(logic).toMatchValues({
                    filteredEvaluationRuns: mockRuns,
                })
            })

            it('returns only passing runs when filter is pass', async () => {
                logic.actions.loadEvaluationRunsSuccess(mockRuns)
                logic.actions.setEvaluationRunsFilter('pass', 'all')

                await expectLogic(logic).toMatchValues({
                    filteredEvaluationRuns: [expect.objectContaining({ id: 'run-1', result: true })],
                })
            })

            it('returns only failing runs when filter is fail', async () => {
                logic.actions.loadEvaluationRunsSuccess(mockRuns)
                logic.actions.setEvaluationRunsFilter('fail', 'all')

                await expectLogic(logic).toMatchValues({
                    filteredEvaluationRuns: [expect.objectContaining({ id: 'run-2', result: false })],
                })
            })

            it('returns only N/A runs when filter is na', async () => {
                logic.actions.loadEvaluationRunsSuccess(mockRuns)
                logic.actions.setEvaluationRunsFilter('na', 'all')

                await expectLogic(logic).toMatchValues({
                    filteredEvaluationRuns: [expect.objectContaining({ id: 'run-3', result: null })],
                })
            })

            // An evaluation that disallows N/A emits result=false alongside skipped=true, so a
            // session that was never graded would otherwise be counted and listed as a failure.
            it('excludes skipped runs from the fail bucket', async () => {
                const skippedRun: EvaluationRun = {
                    ...mockRuns[1],
                    id: 'run-skipped',
                    generation_id: 'gen-skipped',
                    result: false,
                    skipped: true,
                }
                logic.actions.loadEvaluationRunsSuccess([...mockRuns, skippedRun])
                logic.actions.setEvaluationRunsFilter('fail', 'all')

                await expectLogic(logic).toMatchValues({
                    filteredEvaluationRuns: [expect.objectContaining({ id: 'run-2' })],
                })
            })

            it('excludes non-completed runs when filter is not all', async () => {
                const runsWithFailed: EvaluationRun[] = [
                    ...mockRuns,
                    {
                        id: 'run-4',
                        evaluation_id: 'eval-123',
                        evaluation_name: 'Test Evaluation',
                        generation_id: 'gen-4',
                        trace_id: 'trace-4',
                        timestamp: '2024-01-01T15:00:00Z',
                        result: true,
                        reasoning: 'Good',
                        status: 'failed',
                    },
                ]
                logic.actions.loadEvaluationRunsSuccess(runsWithFailed)
                logic.actions.setEvaluationRunsFilter('pass', 'all')

                await expectLogic(logic).toMatchValues({
                    filteredEvaluationRuns: [expect.objectContaining({ id: 'run-1' })],
                })
            })

            it('returns only negative sentiment runs by default for sentiment evaluations', async () => {
                logic.actions.loadEvaluationSuccess(mockSentimentEvaluation)
                logic.actions.loadEvaluationRunsSuccess(mockSentimentRuns)

                await expectLogic(logic).toMatchValues({
                    filteredEvaluationRuns: [expect.objectContaining({ id: 'run-negative' })],
                })
            })

            it('returns only completed sentiment runs matching the selected filter', async () => {
                logic.actions.loadEvaluationSuccess(mockSentimentEvaluation)
                logic.actions.loadEvaluationRunsSuccess(mockSentimentRuns)
                logic.actions.setEvaluationRunsFilter('positive', 'negative')

                await expectLogic(logic).toMatchValues({
                    filteredEvaluationRuns: [expect.objectContaining({ id: 'run-positive' })],
                })
            })

            it('returns all sentiment runs when the all filter is selected', async () => {
                logic.actions.loadEvaluationSuccess(mockSentimentEvaluation)
                logic.actions.loadEvaluationRunsSuccess(mockSentimentRuns)
                logic.actions.setEvaluationRunsFilter('all', 'negative')

                await expectLogic(logic).toMatchValues({
                    filteredEvaluationRuns: mockSentimentRuns,
                })
            })
        })

        // Without this the failed query keeps the default empty list, and the table shows "no runs
        // yet" instead of a failure state — the bug this fix addresses.
        describe('evaluationRunsError', () => {
            it('records the failure so the table can show an error state', async () => {
                logic.actions.loadEvaluationRunsFailure('boom')

                await expectLogic(logic).toMatchValues({
                    evaluationRunsError: true,
                })
            })

            it('clears the error on the next successful load', async () => {
                logic.actions.loadEvaluationRunsFailure('boom')
                logic.actions.loadEvaluationRunsSuccess(mockRuns)

                await expectLogic(logic).toMatchValues({
                    evaluationRunsError: false,
                })
            })
        })
    })

    describe('hog evaluation type', () => {
        beforeEach(() => {
            logic = llmEvaluationLogic({ evaluationId: 'new' })
            logic.mount()
        })

        it('setEvaluationType switches to hog config shape', async () => {
            await expectLogic(logic).toDispatchActions(['loadEvaluationSuccess'])

            logic.actions.setEvaluationType('hog')

            await expectLogic(logic).toMatchValues({
                evaluation: expect.objectContaining({
                    evaluation_type: 'hog',
                    evaluation_config: { source: DEFAULT_HOG_SOURCE },
                    model_configuration: null,
                }),
            })
        })

        it('setEvaluationType switches back to llm_judge config shape', async () => {
            await expectLogic(logic).toDispatchActions(['loadEvaluationSuccess'])

            logic.actions.setEvaluationType('hog')
            logic.actions.setEvaluationType('llm_judge')

            await expectLogic(logic).toMatchValues({
                evaluation: expect.objectContaining({
                    evaluation_type: 'llm_judge',
                    evaluation_config: { prompt: '' },
                }),
            })
        })

        it('setEvaluationType switches to sentiment config shape', async () => {
            await expectLogic(logic).toDispatchActions(['loadEvaluationSuccess'])

            logic.actions.setEvaluationType('sentiment')

            await expectLogic(logic).toMatchValues({
                evaluation: expect.objectContaining({
                    evaluation_type: 'sentiment',
                    evaluation_config: { source: 'user_messages' },
                    output_type: 'sentiment',
                    output_config: {},
                    model_configuration: null,
                    conditions: [expect.objectContaining({ rollout_percentage: 100 })],
                }),
            })
        })

        it('switching to sentiment resets a trace target back to generation', async () => {
            await expectLogic(logic).toDispatchActions(['loadEvaluationSuccess'])

            logic.actions.setEvaluationTarget('trace')
            logic.actions.setEvaluationType('sentiment')

            await expectLogic(logic).toMatchValues({
                evaluation: expect.objectContaining({
                    evaluation_type: 'sentiment',
                    target: 'generation',
                    target_config: {},
                }),
            })
        })

        it('initializes new evaluations as sentiment when requested', async () => {
            logic.unmount()
            logic = llmEvaluationLogic({ evaluationId: 'new', evaluationType: 'sentiment' })
            logic.mount()

            await expectLogic(logic).toDispatchActions(['loadEvaluationSuccess'])

            await expectLogic(logic).toMatchValues({
                evaluation: expect.objectContaining({
                    evaluation_type: 'sentiment',
                    evaluation_config: { source: 'user_messages' },
                    output_type: 'sentiment',
                    output_config: {},
                    model_configuration: null,
                }),
            })
        })

        it('switching to sentiment keeps the reports tab active', async () => {
            await expectLogic(logic).toDispatchActions(['loadEvaluationSuccess'])

            logic.actions.setActiveTab('reports')
            logic.actions.setEvaluationType('sentiment')

            await expectLogic(logic).toMatchValues({
                activeTab: 'reports',
            })
        })

        it('setHogSource updates source in hog config', async () => {
            await expectLogic(logic).toDispatchActions(['loadEvaluationSuccess'])

            logic.actions.setEvaluationType('hog')
            logic.actions.setHogSource('return true')

            await expectLogic(logic).toMatchValues({
                evaluation: expect.objectContaining({
                    evaluation_config: { source: 'return true' },
                }),
            })
        })

        it('formValid checks source for hog type', async () => {
            await expectLogic(logic).toDispatchActions(['loadEvaluationSuccess'])

            logic.actions.setEvaluationType('hog')
            logic.actions.setEvaluationName('Valid Name')
            logic.actions.setTriggerConditions([{ id: 'c1', rollout_percentage: 50, properties: [] }])

            // Default source is non-empty -> valid
            await expectLogic(logic).toMatchValues({ formValid: true })

            logic.actions.setHogSource('')

            // Empty source -> invalid
            await expectLogic(logic).toMatchValues({ formValid: false })

            logic.actions.setHogSource('return true')

            // Non-empty source -> valid again
            await expectLogic(logic).toMatchValues({ formValid: true })
        })

        it('formValid rejects whitespace-only source', async () => {
            await expectLogic(logic).toDispatchActions(['loadEvaluationSuccess'])

            logic.actions.setEvaluationType('hog')
            logic.actions.setEvaluationName('Valid Name')
            logic.actions.setTriggerConditions([{ id: 'c1', rollout_percentage: 50, properties: [] }])
            logic.actions.setHogSource('   ')

            await expectLogic(logic).toMatchValues({ formValid: false })
        })

        it('formValid does not require prompt or code for sentiment type', async () => {
            await expectLogic(logic).toDispatchActions(['loadEvaluationSuccess'])

            logic.actions.setEvaluationType('sentiment')
            logic.actions.setEvaluationName('Valid Name')
            logic.actions.setTriggerConditions([{ id: 'c1', rollout_percentage: 50, properties: [] }])

            await expectLogic(logic).toMatchValues({ formValid: true })
        })

        it('setAllowsNA does not mutate sentiment output config', async () => {
            await expectLogic(logic).toDispatchActions(['loadEvaluationSuccess'])

            logic.actions.setEvaluationType('sentiment')
            logic.actions.setAllowsNA(true)

            await expectLogic(logic).toMatchValues({
                evaluation: expect.objectContaining({
                    output_type: 'sentiment',
                    output_config: {},
                }),
            })
        })

        it('setEvaluationType marks unsaved changes', async () => {
            await expectLogic(logic).toDispatchActions(['loadEvaluationSuccess'])

            logic.actions.setEvaluationType('hog')

            await expectLogic(logic).toMatchValues({ hasUnsavedChanges: true })
        })

        it('setHogSource marks unsaved changes', async () => {
            await expectLogic(logic).toDispatchActions(['loadEvaluationSuccess'])

            logic.actions.setEvaluationType('hog')
            // Clear the flag
            logic.actions.saveEvaluationSuccess({
                ...mockEvaluation,
                evaluation_type: 'hog',
                evaluation_config: { source: DEFAULT_HOG_SOURCE },
            } as any)

            logic.actions.setHogSource('return true')

            await expectLogic(logic).toMatchValues({ hasUnsavedChanges: true })
        })
    })

    describe('selectModelFromPicker', () => {
        beforeEach(() => {
            logic = llmEvaluationLogic({ evaluationId: 'new' })
            logic.mount()
        })

        it('sets model configuration from BYOK provider key', async () => {
            await expectLogic(logic).toDispatchActions(['loadEvaluationSuccess'])
            await expectLogic(keysLogic).toDispatchActions(['loadProviderKeysSuccess'])

            logic.actions.selectModelFromPicker('gpt-5', 'key-1')

            await expectLogic(logic).toMatchValues({
                selectedModel: 'gpt-5',
                evaluation: expect.objectContaining({
                    model_configuration: {
                        provider: 'openai',
                        model: 'gpt-5',
                        provider_key_id: 'key-1',
                    },
                }),
            })
        })

        it('sets model configuration from playground provider key', async () => {
            await expectLogic(logic).toDispatchActions(['loadEvaluationSuccess'])

            logic.actions.selectModelFromPicker('gpt-5', 'playground:openai')

            await expectLogic(logic).toMatchValues({
                selectedModel: 'gpt-5',
                evaluation: expect.objectContaining({
                    model_configuration: {
                        provider: 'openai',
                        model: 'gpt-5',
                        provider_key_id: null,
                    },
                }),
            })
        })

        it('ignores empty modelId', async () => {
            await expectLogic(logic).toDispatchActions(['loadEvaluationSuccess'])

            logic.actions.selectModelFromPicker('', 'key-1')

            await expectLogic(logic).toMatchValues({
                evaluation: expect.objectContaining({
                    model_configuration: null,
                }),
            })
        })
    })

    describe('Hog sample testing', () => {
        it('sends the trace aggregation window and clears completed results when it changes', async () => {
            let requestBody: Record<string, unknown> | undefined
            useMocks({
                post: {
                    '/api/projects/:teamId/evaluations/test_hog/': async ({ request }) => {
                        requestBody = (await request.json()) as Record<string, unknown>
                        return {
                            results: [
                                {
                                    sample_id: 'trace-1',
                                    sample_type: 'trace',
                                    event_uuid: null,
                                    trace_id: 'trace-1',
                                    input_preview: 'hello',
                                    output_preview: 'world',
                                    result: true,
                                    reasoning: null,
                                    error: null,
                                },
                            ],
                        }
                    },
                },
            })
            logic = llmEvaluationLogic({ evaluationId: 'new' })
            logic.mount()
            await expectLogic(logic).toDispatchActions(['loadEvaluationSuccess'])

            logic.actions.setEvaluationType('hog')
            logic.actions.setEvaluationTarget('trace')
            logic.actions.patchTargetConfig({ window_seconds: 120 })
            logic.actions.testHogOnSample()

            await expectLogic(logic)
                .toDispatchActions(['testHogOnSampleSuccess'])
                .toMatchValues({
                    hogTestResults: [expect.objectContaining({ sample_id: 'trace-1', sample_type: 'trace' })],
                })
            expect(requestBody).toMatchObject({
                target: 'trace',
                target_config: { window_seconds: 120 },
            })

            logic.actions.patchTargetConfig({ window_seconds: 240 })
            await expectLogic(logic).toMatchValues({ hogTestResults: null })
        })

        it('does not restore results from a request whose target changed in flight', async () => {
            let resolveRequest: (value: TestHogResponseApi) => void = () => {}
            const pendingResponse = new Promise<TestHogResponseApi>((resolve) => {
                resolveRequest = resolve
            })
            useMocks({
                post: {
                    '/api/projects/:teamId/evaluations/test_hog/': () => pendingResponse,
                },
            })
            logic = llmEvaluationLogic({ evaluationId: 'new' })
            logic.mount()
            await expectLogic(logic).toDispatchActions(['loadEvaluationSuccess'])

            logic.actions.setEvaluationType('hog')
            logic.actions.testHogOnSample()
            await expectLogic(logic).toMatchValues({ hogTestResultsLoading: true })

            logic.actions.setEvaluationTarget('trace')
            await expectLogic(logic).toMatchValues({ hogTestResults: null })
            resolveRequest({
                results: [
                    {
                        sample_id: 'generation-1',
                        sample_type: 'generation',
                        event_uuid: 'generation-1',
                        trace_id: 'trace-1',
                        input_preview: 'hello',
                        output_preview: 'world',
                        result: true,
                        reasoning: '',
                        error: null,
                    },
                ],
            })

            await expectLogic(logic)
                .toDispatchActions(['testHogOnSampleSuccess'])
                .toMatchValues({ hogTestResults: null })
        })
    })

    describe('saveEvaluation list refresh', () => {
        it('reloads the evaluations list so it shows the eval just created', async () => {
            const pushSpy = jest.spyOn(router.actions, 'push').mockImplementation(() => {})
            let evaluationListCount = 0

            useMocks({
                get: {
                    '/api/projects/:teamId/evaluations/': () => {
                        evaluationListCount += 1
                        return { results: evaluationListCount === 1 ? [] : [mockSentimentEvaluation] }
                    },
                    '/api/projects/:teamId/evaluation_directories/': [],
                },
                post: {
                    '/api/projects/:teamId/evaluations/': () => mockSentimentEvaluation,
                },
            })

            const evaluationsLogic = llmEvaluationsLogic()
            evaluationsLogic.mount()

            try {
                await expectLogic(evaluationsLogic).toDispatchActions(['loadEvaluationsSuccess'])
                expect(evaluationsLogic.values.evaluations).toEqual([])

                logic = llmEvaluationLogic({ evaluationId: 'new', evaluationType: 'sentiment' })
                logic.mount()
                await expectLogic(logic).toDispatchActions(['loadEvaluationSuccess'])
                logic.actions.setEvaluationName('Sentiment evaluation')
                logic.actions.saveEvaluation()

                await expectLogic(evaluationsLogic).toDispatchActions(['loadEvaluations', 'loadEvaluationsSuccess'])
                expect(evaluationsLogic.values.evaluations).toHaveLength(1)
            } finally {
                pushSpy.mockRestore()
                evaluationsLogic.unmount()
            }
        })
    })

    describe('saveEvaluation report persistence', () => {
        it('does not create an evaluation when the report threshold is invalid', async () => {
            let evaluationCreateCount = 0
            useMocks({
                post: {
                    '/api/projects/:teamId/evaluations/': () => {
                        evaluationCreateCount += 1
                        return mockEvaluation
                    },
                },
            })

            logic = llmEvaluationLogic({ evaluationId: 'new' })
            const reportLogic = evaluationReportLogic({ evaluationId: 'new' })
            logic.mount()
            reportLogic.mount()

            try {
                await expectLogic(logic).toDispatchActions(['loadEvaluationSuccess'])
                logic.actions.setEvaluationName('Valid Name')
                logic.actions.setEvaluationPrompt('Valid prompt')
                logic.actions.setModelConfiguration({
                    provider: 'openai',
                    model: 'gpt-5-mini',
                    provider_key_id: 'key-1',
                })
                reportLogic.actions.setDraftTriggerThreshold(67)

                expect(reportLogic.values.configErrors.triggerThreshold).toBe(
                    'Evaluation count threshold must be a whole number between 100 and 10,000.'
                )

                logic.actions.saveEvaluation()

                await expectLogic(logic)
                    .toDispatchActions(['saveEvaluationFailure'])
                    .toMatchValues({ evaluationFormSubmitting: false })
                expect(evaluationCreateCount).toBe(0)
            } finally {
                reportLogic.unmount()
            }
        })

        it('does not overwrite a saved report with defaults before the report load finishes', async () => {
            let reportWriteCount = 0
            let reportListRequestCount = 0
            let resolveInitialReports: (value: { results: EvaluationReport[] }) => void = () => {}
            const initialReportsPromise = new Promise<{ results: EvaluationReport[] }>((resolve) => {
                resolveInitialReports = resolve
            })
            let resolveNavigation: () => void = () => {}
            const navigationPromise = new Promise<void>((resolve) => {
                resolveNavigation = resolve
            })
            const pushSpy = jest.spyOn(router.actions, 'push').mockImplementation(() => {
                resolveNavigation()
            })

            useMocks({
                get: {
                    '/api/projects/:teamId/llm_analytics/evaluation_reports/': () => {
                        reportListRequestCount += 1
                        return reportListRequestCount === 1
                            ? initialReportsPromise
                            : { results: [mockEvaluationReport] }
                    },
                },
                patch: {
                    '/api/projects/:teamId/evaluations/:id/': () => mockEvaluation,
                    '/api/projects/:teamId/llm_analytics/evaluation_reports/:id/': () => {
                        reportWriteCount += 1
                        return mockEvaluationReport
                    },
                },
                post: {
                    '/api/projects/:teamId/llm_analytics/evaluation_reports/': () => {
                        reportWriteCount += 1
                        return mockEvaluationReport
                    },
                },
            })

            logic = llmEvaluationLogic({ evaluationId: 'eval-123' })
            const reportLogic = evaluationReportLogic({ evaluationId: 'eval-123' })
            logic.mount()
            reportLogic.mount()

            try {
                await expectLogic(logic).toDispatchActions(['loadEvaluationSuccess'])
                expect(reportLogic.values.reportsLoading).toBe(true)
                expect(reportLogic.values.activeReport).toBeNull()

                logic.actions.setEvaluationName('Renamed evaluation')
                logic.actions.saveEvaluation()

                await navigationPromise

                expect(reportListRequestCount).toBe(1)
                expect(reportWriteCount).toBe(0)
                resolveInitialReports({ results: [mockEvaluationReport] })
                await expectLogic(reportLogic).toFinishAllListeners()
            } finally {
                pushSpy.mockRestore()
                reportLogic.unmount()
            }
        })

        it('updates the backend-created report when saving a new sentiment evaluation', async () => {
            let evaluationCreateCount = 0
            let reportListCount = 0
            let reportCreateCount = 0
            let reportUpdateCount = 0
            const pushSpy = jest.spyOn(router.actions, 'push').mockImplementation(() => {})

            useMocks({
                get: {
                    '/api/projects/:teamId/llm_analytics/evaluation_reports/': () => {
                        reportListCount += 1
                        return { results: [mockEvaluationReport] }
                    },
                },
                post: {
                    '/api/projects/:teamId/evaluations/': () => {
                        evaluationCreateCount += 1
                        return mockSentimentEvaluation
                    },
                    '/api/projects/:teamId/llm_analytics/evaluation_reports/': () => {
                        reportCreateCount += 1
                        return mockEvaluationReport
                    },
                },
                patch: {
                    '/api/projects/:teamId/llm_analytics/evaluation_reports/:id/': () => {
                        reportUpdateCount += 1
                        return mockEvaluationReport
                    },
                },
            })

            logic = llmEvaluationLogic({ evaluationId: 'new', evaluationType: 'sentiment' })
            const reportLogic = evaluationReportLogic({ evaluationId: 'new' })
            logic.mount()
            reportLogic.mount()

            try {
                await expectLogic(logic).toDispatchActions(['loadEvaluationSuccess'])
                logic.actions.setEvaluationName('Sentiment evaluation')
                reportLogic.actions.setDraftTriggerThreshold(500)
                reportLogic.actions.setDraftEmailValue('sentiment@example.com')

                logic.actions.saveEvaluation()

                await expectLogic(logic).toFinishAllListeners()
                expect(evaluationCreateCount).toBe(1)
                expect(reportListCount).toBe(1)
                expect(reportUpdateCount).toBe(1)
                expect(reportCreateCount).toBe(0)
            } finally {
                pushSpy.mockRestore()
                reportLogic.unmount()
            }
        })
    })

    describe('saveEvaluation failure handling', () => {
        beforeEach(() => {
            useMocks({
                get: {
                    '/api/environments/:teamId/llm_analytics/provider_keys/': { results: mockProviderKeys },
                    '/api/environments/:teamId/llm_analytics/evaluation_config/': {
                        active_provider_key: null,
                        created_at: '2024-01-01T00:00:00Z',
                        updated_at: '2024-01-01T00:00:00Z',
                    },
                    '/api/projects/:teamId/evaluations/:id/': mockEvaluation,
                },
                patch: {
                    '/api/projects/:teamId/evaluations/:id/': () => [
                        400,
                        {
                            enabled: ['Add a provider API key to enable this evaluation.'],
                        },
                    ],
                },
            })

            logic = llmEvaluationLogic({ evaluationId: 'eval-123' })
            logic.mount()
        })

        it('dispatches saveEvaluationFailure and resets submitting state on 400', async () => {
            await expectLogic(logic).toDispatchActions(['loadEvaluationSuccess'])
            logic.actions.setEvaluationName('Renamed')

            logic.actions.saveEvaluation()

            await expectLogic(logic)
                .toDispatchActions(['saveEvaluation', 'saveEvaluationFailure'])
                .toMatchValues({ evaluationFormSubmitting: false })
        })
    })
})
