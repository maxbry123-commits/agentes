import { AccessControlLevel, AnyPropertyFilter, UserBasicType } from '~/types'

import type {
    EvaluationReportCitationApi,
    EvaluationReportMetricsApi,
    EvaluationReportRunApi,
    EvaluationReportRunContentApi,
    EvaluationReportSectionApi,
} from '../generated/api.schemas'
import { LLMProvider } from '../settings/llmProviderKeysLogic'

export type EvaluationType = 'llm_judge' | 'hog' | 'sentiment'
export type EvaluationTarget = 'generation' | 'trace' | 'session'
export type EvaluationSettleStrategy = 'fixed_window' | 'inactivity'
export type EvaluationOutputType = 'boolean' | 'sentiment'
export type EvaluationStatus = 'active' | 'paused' | 'error'
export type EvaluationStatusReason =
    | 'provider_key_required'
    | 'provider_key_deleted'
    | 'no_default_model'
    | 'provider_key_invalid'
    | 'provider_key_permission_denied'
    | 'provider_key_quota_exceeded'
    | 'provider_key_rate_limited'
    | 'model_not_found'
    | 'hog_error'

export interface ModelConfiguration {
    provider: LLMProvider
    model: string
    provider_key_id: string | null
    provider_key_name?: string | null
}

export interface EvaluationOutputConfig {
    allows_na?: boolean
}

/** Settle config for aggregate targets (trace, session). A missing `strategy` resolves per target:
 * 'fixed_window' for a trace, because rows saved before strategies existed mean exactly that, and
 * 'inactivity' for a session, which has no such rows. Accepted ranges also differ per target, both
 * enforced by the backend's `validate_target_config`. */
export interface EvaluationTargetConfig {
    strategy?: EvaluationSettleStrategy
    /** fixed_window: seconds to wait after the first matching generation before evaluating. */
    window_seconds?: number
    /** inactivity: seconds without new activity before the target counts as settled. */
    quiet_period_seconds?: number
    /** inactivity: hard cap in seconds on the total wait from the first matching generation. */
    max_age_seconds?: number
}

export interface LLMJudgeEvaluationConfig {
    prompt: string
}

export interface HogEvaluationConfig {
    source: string
    bytecode?: unknown[]
}

export interface SentimentEvaluationConfig {
    source: 'user_messages'
}

export interface BaseEvaluationConfig {
    id: string
    name: string
    description?: string
    directory_id?: string | null
    enabled: boolean
    status: EvaluationStatus
    status_reason: EvaluationStatusReason | null
    status_reason_detail: string | null
    output_type: EvaluationOutputType
    output_config: EvaluationOutputConfig
    conditions: EvaluationConditionSet[]
    /** What the evaluation runs on: each matching generation event, or the whole trace once. */
    target: EvaluationTarget
    /** Target-specific settings — see EvaluationTargetConfig. Empty for 'generation'. */
    target_config: EvaluationTargetConfig
    model_configuration: ModelConfiguration | null
    total_runs?: number
    last_run_at?: string
    created_at: string
    updated_at: string
    created_by?: UserBasicType | null
    deleted?: boolean
    user_access_level?: AccessControlLevel | null
}

export interface LLMJudgeEvaluation extends BaseEvaluationConfig {
    evaluation_type: 'llm_judge'
    output_type: 'boolean'
    evaluation_config: LLMJudgeEvaluationConfig
}

export interface HogEvaluation extends BaseEvaluationConfig {
    evaluation_type: 'hog'
    output_type: 'boolean'
    evaluation_config: HogEvaluationConfig
}

export interface SentimentEvaluation extends BaseEvaluationConfig {
    evaluation_type: 'sentiment'
    output_type: 'sentiment'
    evaluation_config: SentimentEvaluationConfig
    model_configuration: null
}

export type EvaluationConfig = LLMJudgeEvaluation | HogEvaluation | SentimentEvaluation

export interface EvaluationConditionSet {
    id: string
    // Optional because the backend serializer has `default=100` (not `required=True`), so legacy
    // condition rows stored in the JSONField before the field existed read back without the key.
    rollout_percentage?: number
    // Optional for the same reason: conditions live in a free-form JSONField and the inner shape
    // isn't validated, so legacy rows can come back without a `properties` key.
    properties?: AnyPropertyFilter[]
}

export interface EvaluationRun {
    id: string
    evaluation_id: string
    evaluation_name: string
    generation_id: string | null
    trace_id: string
    // Session-target verdicts carry no $ai_trace_id, so the session id is the only thing that
    // identifies what was graded. Absent on every other target.
    session_id?: string | null
    timestamp: string
    evaluation_type?: EvaluationType
    result_type?: EvaluationOutputType
    result: boolean | null
    sentiment_label?: string | null
    sentiment_score?: number | null
    applicable?: boolean
    // A skipped run completed without grading anything. Its `result` is still false when the
    // evaluation disallows N/A, so it has to be read alongside this rather than on its own.
    skipped?: boolean
    reasoning: string
    status: 'completed' | 'failed' | 'running'
}

export type EvaluationReportFrequency = 'scheduled' | 'every_n'

export interface EvaluationReportDeliveryTarget {
    type: 'email' | 'slack'
    value?: string
    integration_id?: number
    channel?: string
}

export interface EvaluationReport {
    id: string
    evaluation: string
    frequency: EvaluationReportFrequency
    /** RFC 5545 RRULE string (empty for every_n). */
    rrule: string
    /** Anchor datetime for rrule expansion (null for every_n). */
    starts_at: string | null
    /** IANA timezone for expanding rrule occurrences. */
    timezone_name: string
    next_delivery_date: string | null
    delivery_targets: EvaluationReportDeliveryTarget[]
    max_sample_size: number
    enabled: boolean
    deleted: boolean
    last_delivered_at: string | null
    /** Optional per-report custom guidance appended to the agent's system prompt. */
    report_prompt_guidance: string
    /** Number of new eval results that triggers a report (only for every_n frequency). */
    trigger_threshold: number | null
    /** Minimum minutes between count-triggered reports. */
    cooldown_minutes: number
    /** Maximum count-triggered report runs per calendar day (UTC). */
    daily_run_cap: number
    created_by: number | null
    created_at: string
}

export type EvaluationReportSection = EvaluationReportSectionApi
export type EvaluationReportCitation = EvaluationReportCitationApi
export type EvaluationReportMetrics = EvaluationReportMetricsApi
export type EvaluationReportStoredMetrics = EvaluationReportMetricsApi
export type EvaluationReportRunContent = EvaluationReportRunContentApi
export type EvaluationReportRun = EvaluationReportRunApi

export type SentimentEvaluationRunsFilter = 'negative' | 'positive' | 'neutral' | 'all'
export type EvaluationRunsFilter = 'pass' | 'fail' | 'na' | SentimentEvaluationRunsFilter
