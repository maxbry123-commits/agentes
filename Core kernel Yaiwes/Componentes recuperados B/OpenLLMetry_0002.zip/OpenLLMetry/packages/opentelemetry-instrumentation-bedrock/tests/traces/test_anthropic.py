import json

import pytest
from opentelemetry.semconv._incubating.attributes import (
    gen_ai_attributes as GenAIAttributes,
)
from opentelemetry.semconv._incubating.attributes.gen_ai_attributes import GenAiOperationNameValues, GenAiSystemValues
from opentelemetry.semconv_ai import SpanAttributes

from tests.traces import assert_message_in_logs


@pytest.mark.vcr
def test_anthropic_2_completion(instrument_legacy, brt, span_exporter, log_exporter):
    body = json.dumps(
        {
            "prompt": "Human: Tell me a joke about opentelemetry Assistant:",
            "max_tokens_to_sample": 200,
            "temperature": 0.5,
        }
    )

    response = brt.invoke_model(
        body=body,
        modelId="anthropic.claude-v2:1",
        accept="application/json",
        contentType="application/json",
    )

    response_body = json.loads(response.get("body").read())
    completion = response_body.get("completion")

    spans = span_exporter.get_finished_spans()
    assert all(span.name == "text_completion claude-v2:1" for span in spans)

    anthropic_span = spans[0]

    # Assert on vendor and operation (P3-4: enforce spec on every span)
    assert anthropic_span.attributes[GenAIAttributes.GEN_AI_PROVIDER_NAME] == GenAiSystemValues.AWS_BEDROCK.value
    assert (
        anthropic_span.attributes[GenAIAttributes.GEN_AI_OPERATION_NAME]
        == GenAiOperationNameValues.TEXT_COMPLETION.value
    )

    input_messages = json.loads(
        anthropic_span.attributes[GenAIAttributes.GEN_AI_INPUT_MESSAGES]
    )
    assert input_messages[0]["parts"][0]["content"] == "Human: Tell me a joke about opentelemetry Assistant:"
    assert input_messages[0]["role"] == "user"

    output_messages = json.loads(
        anthropic_span.attributes.get(GenAIAttributes.GEN_AI_OUTPUT_MESSAGES)
    )
    assert output_messages[0]["parts"][0]["content"] == completion
    assert output_messages[0]["finish_reason"] == "stop"

    assert anthropic_span.attributes[GenAIAttributes.GEN_AI_RESPONSE_FINISH_REASONS] == ("stop",)
    assert anthropic_span.attributes.get(GenAIAttributes.GEN_AI_USAGE_INPUT_TOKENS) == 18
    assert anthropic_span.attributes.get(
        GenAIAttributes.GEN_AI_USAGE_OUTPUT_TOKENS
    ) + anthropic_span.attributes.get(
        GenAIAttributes.GEN_AI_USAGE_INPUT_TOKENS
    ) == anthropic_span.attributes.get(SpanAttributes.GEN_AI_USAGE_TOTAL_TOKENS)
    # Bedrock does not return the response id for claude-v2:1
    assert anthropic_span.attributes.get("gen_ai.response.id") is None

    logs = log_exporter.get_finished_logs()
    assert (
        len(logs) == 0
    ), "Assert that it doesn't emit logs when use_legacy_attributes is True"


@pytest.mark.vcr
def test_anthropic_2_completion_with_events_with_content(
    instrument_with_content, brt, span_exporter, log_exporter
):
    body = json.dumps(
        {
            "prompt": "Human: Tell me a joke about opentelemetry Assistant:",
            "max_tokens_to_sample": 200,
            "temperature": 0.5,
        }
    )

    response = brt.invoke_model(
        body=body,
        modelId="anthropic.claude-v2:1",
        accept="application/json",
        contentType="application/json",
    )

    response_body = json.loads(response.get("body").read())
    completion = response_body.get("completion")

    spans = span_exporter.get_finished_spans()
    assert all(span.name == "text_completion claude-v2:1" for span in spans)

    anthropic_span = spans[0]

    assert anthropic_span.attributes.get(GenAIAttributes.GEN_AI_USAGE_INPUT_TOKENS) == 18
    assert anthropic_span.attributes.get(
        GenAIAttributes.GEN_AI_USAGE_OUTPUT_TOKENS
    ) + anthropic_span.attributes.get(
        GenAIAttributes.GEN_AI_USAGE_INPUT_TOKENS
    ) == anthropic_span.attributes.get(SpanAttributes.GEN_AI_USAGE_TOTAL_TOKENS)
    # Bedrock does not return the response id for claude-v2:1
    assert anthropic_span.attributes.get("gen_ai.response.id") is None

    logs = log_exporter.get_finished_logs()
    assert len(logs) == 2

    # Validate user message Event
    user_message_log = logs[0]
    assert_message_in_logs(
        user_message_log,
        "gen_ai.user.message",
        {"content": "Human: Tell me a joke about opentelemetry Assistant:"},
    )

    # Validate the ai response
    choice_event = {
        "index": 0,
        "finish_reason": "stop",
        "message": {"content": completion},
    }
    assert_message_in_logs(logs[1], "gen_ai.choice", choice_event)


@pytest.mark.vcr
def test_anthropic_2_completion_with_events_with_no_content(
    instrument_with_no_content, brt, span_exporter, log_exporter
):
    body = json.dumps(
        {
            "prompt": "Human: Tell me a joke about opentelemetry Assistant:",
            "max_tokens_to_sample": 200,
            "temperature": 0.5,
        }
    )

    response = brt.invoke_model(
        body=body,
        modelId="anthropic.claude-v2:1",
        accept="application/json",
        contentType="application/json",
    )

    response_body = json.loads(response.get("body").read())
    response_body.get("completion")

    spans = span_exporter.get_finished_spans()
    assert all(span.name == "text_completion claude-v2:1" for span in spans)

    anthropic_span = spans[0]

    assert anthropic_span.attributes.get(GenAIAttributes.GEN_AI_USAGE_INPUT_TOKENS) == 18
    assert anthropic_span.attributes.get(
        GenAIAttributes.GEN_AI_USAGE_OUTPUT_TOKENS
    ) + anthropic_span.attributes.get(
        GenAIAttributes.GEN_AI_USAGE_INPUT_TOKENS
    ) == anthropic_span.attributes.get(SpanAttributes.GEN_AI_USAGE_TOTAL_TOKENS)
    # Bedrock does not return the response id for claude-v2:1
    assert anthropic_span.attributes.get("gen_ai.response.id") is None

    logs = log_exporter.get_finished_logs()
    assert len(logs) == 2

    # Validate user message Event
    user_message_log = logs[0]
    assert_message_in_logs(user_message_log, "gen_ai.user.message", {})

    # Validate the ai response
    choice_event = {
        "index": 0,
        "finish_reason": "stop",
        "message": {},
    }
    assert_message_in_logs(logs[1], "gen_ai.choice", choice_event)


@pytest.mark.vcr
def test_anthropic_3_completion_complex_content(
    instrument_legacy, brt, span_exporter, log_exporter
):
    body = json.dumps(
        {
            "messages": [
                {
                    "role": "user",
                    "content": [
                        {"type": "text", "text": "Tell me a joke about opentelemetry"},
                    ],
                }
            ],
            "max_tokens": 200,
            "temperature": 0.5,
            "anthropic_version": "bedrock-2023-05-31",
        }
    )

    response = brt.invoke_model(
        body=body,
        modelId="anthropic.claude-3-sonnet-20240229-v1:0",
        accept="application/json",
        contentType="application/json",
    )

    json.loads(response.get("body").read())

    spans = span_exporter.get_finished_spans()
    assert all(span.name == "chat claude-3-sonnet-20240229-v1:0" for span in spans)

    anthropic_span = spans[0]
    input_messages = json.loads(
        anthropic_span.attributes[GenAIAttributes.GEN_AI_INPUT_MESSAGES]
    )
    assert input_messages[0]["parts"][0]["content"] == "Tell me a joke about opentelemetry"
    assert input_messages[0]["parts"][0]["type"] == "text"

    output_messages = json.loads(
        anthropic_span.attributes.get(GenAIAttributes.GEN_AI_OUTPUT_MESSAGES)
    )
    assert output_messages[0]["parts"][0]["type"] == "text"
    assert output_messages[0]["parts"][0]["content"] is not None
    assert output_messages[0]["finish_reason"] == "stop"

    assert anthropic_span.attributes[GenAIAttributes.GEN_AI_RESPONSE_FINISH_REASONS] == ("stop",)
    assert anthropic_span.attributes.get(GenAIAttributes.GEN_AI_USAGE_INPUT_TOKENS) == 16
    assert anthropic_span.attributes.get(
        GenAIAttributes.GEN_AI_USAGE_OUTPUT_TOKENS
    ) + anthropic_span.attributes.get(
        GenAIAttributes.GEN_AI_USAGE_INPUT_TOKENS
    ) == anthropic_span.attributes.get(SpanAttributes.GEN_AI_USAGE_TOTAL_TOKENS)
    assert (
        anthropic_span.attributes.get("gen_ai.response.id")
        == "msg_bdrk_01Q6Z4xmUkMigo9K4qd1fshW"
    )

    logs = log_exporter.get_finished_logs()
    assert (
        len(logs) == 0
    ), "Assert that it doesn't emit logs when use_legacy_attributes is True"


@pytest.mark.vcr
def test_anthropic_3_completion_complex_content_with_events_with_content(
    instrument_with_content, brt, span_exporter, log_exporter
):
    body = json.dumps(
        {
            "messages": [
                {
                    "role": "user",
                    "content": [
                        {"type": "text", "text": "Tell me a joke about opentelemetry"},
                    ],
                }
            ],
            "max_tokens": 200,
            "temperature": 0.5,
            "anthropic_version": "bedrock-2023-05-31",
        }
    )

    response = brt.invoke_model(
        body=body,
        modelId="anthropic.claude-3-sonnet-20240229-v1:0",
        accept="application/json",
        contentType="application/json",
    )

    response_body = json.loads(response.get("body").read())
    completion = response_body.get("content")

    spans = span_exporter.get_finished_spans()
    assert all(span.name == "chat claude-3-sonnet-20240229-v1:0" for span in spans)

    anthropic_span = spans[0]

    assert anthropic_span.attributes.get(GenAIAttributes.GEN_AI_USAGE_INPUT_TOKENS) == 16
    assert anthropic_span.attributes.get(
        GenAIAttributes.GEN_AI_USAGE_OUTPUT_TOKENS
    ) + anthropic_span.attributes.get(
        GenAIAttributes.GEN_AI_USAGE_INPUT_TOKENS
    ) == anthropic_span.attributes.get(SpanAttributes.GEN_AI_USAGE_TOTAL_TOKENS)
    assert (
        anthropic_span.attributes.get("gen_ai.response.id")
        == "msg_bdrk_01Q6Z4xmUkMigo9K4qd1fshW"
    )

    logs = log_exporter.get_finished_logs()
    assert len(logs) == 2

    # Validate user message Event
    user_message_log = logs[0]
    assert_message_in_logs(
        user_message_log,
        "gen_ai.user.message",
        {
            "content": [
                {"type": "text", "text": "Tell me a joke about opentelemetry"},
            ],
        },
    )

    # Validate the ai response
    choice_event = {
        "index": 0,
        "finish_reason": "stop",
        "message": {"content": completion},
    }
    assert_message_in_logs(logs[1], "gen_ai.choice", choice_event)


@pytest.mark.vcr
def test_anthropic_3_completion_complex_content_with_events_with_no_content(
    instrument_with_no_content, brt, span_exporter, log_exporter
):
    body = json.dumps(
        {
            "messages": [
                {
                    "role": "user",
                    "content": [
                        {"type": "text", "text": "Tell me a joke about opentelemetry"},
                    ],
                }
            ],
            "max_tokens": 200,
            "temperature": 0.5,
            "anthropic_version": "bedrock-2023-05-31",
        }
    )

    response = brt.invoke_model(
        body=body,
        modelId="anthropic.claude-3-sonnet-20240229-v1:0",
        accept="application/json",
        contentType="application/json",
    )

    response_body = json.loads(response.get("body").read())
    response_body.get("content")

    spans = span_exporter.get_finished_spans()
    assert all(span.name == "chat claude-3-sonnet-20240229-v1:0" for span in spans)

    anthropic_span = spans[0]

    assert anthropic_span.attributes.get(GenAIAttributes.GEN_AI_USAGE_INPUT_TOKENS) == 16
    assert anthropic_span.attributes.get(
        GenAIAttributes.GEN_AI_USAGE_OUTPUT_TOKENS
    ) + anthropic_span.attributes.get(
        GenAIAttributes.GEN_AI_USAGE_INPUT_TOKENS
    ) == anthropic_span.attributes.get(SpanAttributes.GEN_AI_USAGE_TOTAL_TOKENS)
    assert (
        anthropic_span.attributes.get("gen_ai.response.id")
        == "msg_bdrk_01Q6Z4xmUkMigo9K4qd1fshW"
    )

    logs = log_exporter.get_finished_logs()
    assert len(logs) == 2

    # Validate user message Event
    user_message_log = logs[0]
    assert_message_in_logs(user_message_log, "gen_ai.user.message", {})

    # Validate the ai response
    choice_event = {
        "index": 0,
        "finish_reason": "stop",
        "message": {},
    }
    assert_message_in_logs(logs[1], "gen_ai.choice", choice_event)


@pytest.mark.vcr
def test_anthropic_3_completion_streaming(
    instrument_legacy, brt, span_exporter, log_exporter
):
    body = json.dumps(
        {
            "messages": [
                {
                    "role": "user",
                    "content": [
                        {"type": "text", "text": "Tell me a joke about opentelemetry"},
                    ],
                }
            ],
            "max_tokens": 200,
            "temperature": 0.5,
            "anthropic_version": "bedrock-2023-05-31",
        }
    )

    response = brt.invoke_model_with_response_stream(
        body=body,
        modelId="anthropic.claude-3-sonnet-20240229-v1:0",
        accept="application/json",
        contentType="application/json",
    )

    completion = ""
    for event in response.get("body"):
        chunk = event.get("chunk")
        if chunk:
            decoded_chunk = json.loads(chunk.get("bytes").decode())
            if "delta" in decoded_chunk:
                completion += decoded_chunk.get("delta").get("text") or ""

    spans = span_exporter.get_finished_spans()
    assert all(span.name == "chat claude-3-sonnet-20240229-v1:0" for span in spans)

    anthropic_span = spans[0]
    input_messages = json.loads(
        anthropic_span.attributes[GenAIAttributes.GEN_AI_INPUT_MESSAGES]
    )
    assert input_messages[0]["parts"][0]["content"] == "Tell me a joke about opentelemetry"
    assert input_messages[0]["parts"][0]["type"] == "text"

    output_messages = json.loads(
        anthropic_span.attributes.get(GenAIAttributes.GEN_AI_OUTPUT_MESSAGES)
    )
    assert output_messages[0]["parts"][0]["type"] == "text"
    assert output_messages[0]["parts"][0]["content"] == completion
    assert output_messages[0]["finish_reason"] == "stop"

    assert anthropic_span.attributes[GenAIAttributes.GEN_AI_RESPONSE_FINISH_REASONS] == ("stop",)
    assert anthropic_span.attributes.get(GenAIAttributes.GEN_AI_USAGE_INPUT_TOKENS) == 16
    assert anthropic_span.attributes.get(
        GenAIAttributes.GEN_AI_USAGE_OUTPUT_TOKENS
    ) + anthropic_span.attributes.get(
        GenAIAttributes.GEN_AI_USAGE_INPUT_TOKENS
    ) == anthropic_span.attributes.get(SpanAttributes.GEN_AI_USAGE_TOTAL_TOKENS)
    assert (
        anthropic_span.attributes.get("gen_ai.response.id")
        == "msg_bdrk_014eJfxWXNnxFKhmuiT8FYf7"
    )

    logs = log_exporter.get_finished_logs()
    assert (
        len(logs) == 0
    ), "Assert that it doesn't emit logs when use_legacy_attributes is True"


@pytest.mark.vcr
def test_anthropic_3_completion_streaming_with_events_with_content(
    instrument_with_content, brt, span_exporter, log_exporter
):
    body = json.dumps(
        {
            "messages": [
                {
                    "role": "user",
                    "content": [
                        {"type": "text", "text": "Tell me a joke about opentelemetry"},
                    ],
                }
            ],
            "max_tokens": 200,
            "temperature": 0.5,
            "anthropic_version": "bedrock-2023-05-31",
        }
    )

    response = brt.invoke_model_with_response_stream(
        body=body,
        modelId="anthropic.claude-3-sonnet-20240229-v1:0",
        accept="application/json",
        contentType="application/json",
    )

    completion = ""
    for event in response.get("body"):
        chunk = event.get("chunk")
        if chunk:
            decoded_chunk = json.loads(chunk.get("bytes").decode())
            if "delta" in decoded_chunk:
                completion += decoded_chunk.get("delta").get("text") or ""

    spans = span_exporter.get_finished_spans()
    assert all(span.name == "chat claude-3-sonnet-20240229-v1:0" for span in spans)

    anthropic_span = spans[0]

    assert anthropic_span.attributes.get(GenAIAttributes.GEN_AI_USAGE_INPUT_TOKENS) == 16
    assert anthropic_span.attributes.get(
        GenAIAttributes.GEN_AI_USAGE_OUTPUT_TOKENS
    ) + anthropic_span.attributes.get(
        GenAIAttributes.GEN_AI_USAGE_INPUT_TOKENS
    ) == anthropic_span.attributes.get(SpanAttributes.GEN_AI_USAGE_TOTAL_TOKENS)
    assert (
        anthropic_span.attributes.get("gen_ai.response.id")
        == "msg_bdrk_014eJfxWXNnxFKhmuiT8FYf7"
    )

    logs = log_exporter.get_finished_logs()
    assert len(logs) == 2

    # Validate user message Event
    user_message_log = logs[0]
    assert_message_in_logs(
        user_message_log,
        "gen_ai.user.message",
        {"content": [{"text": "Tell me a joke about opentelemetry", "type": "text"}]},
    )

    # Validate the ai response
    choice_event = {
        "index": 0,
        "finish_reason": "stop",
        "message": {"content": response.get("body")._accumulating_body.get("content")},
    }
    assert_message_in_logs(logs[1], "gen_ai.choice", choice_event)


@pytest.mark.vcr
def test_anthropic_3_completion_streaming_with_events_with_no_content(
    instrument_with_no_content, brt, span_exporter, log_exporter
):
    body = json.dumps(
        {
            "messages": [
                {
                    "role": "user",
                    "content": [
                        {"type": "text", "text": "Tell me a joke about opentelemetry"},
                    ],
                }
            ],
            "max_tokens": 200,
            "temperature": 0.5,
            "anthropic_version": "bedrock-2023-05-31",
        }
    )

    response = brt.invoke_model_with_response_stream(
        body=body,
        modelId="anthropic.claude-3-sonnet-20240229-v1:0",
        accept="application/json",
        contentType="application/json",
    )

    completion = ""
    for event in response.get("body"):
        chunk = event.get("chunk")
        if chunk:
            decoded_chunk = json.loads(chunk.get("bytes").decode())
            if "delta" in decoded_chunk:
                completion += decoded_chunk.get("delta").get("text") or ""

    spans = span_exporter.get_finished_spans()
    assert all(span.name == "chat claude-3-sonnet-20240229-v1:0" for span in spans)

    anthropic_span = spans[0]

    assert anthropic_span.attributes.get(GenAIAttributes.GEN_AI_USAGE_INPUT_TOKENS) == 16
    assert anthropic_span.attributes.get(
        GenAIAttributes.GEN_AI_USAGE_OUTPUT_TOKENS
    ) + anthropic_span.attributes.get(
        GenAIAttributes.GEN_AI_USAGE_INPUT_TOKENS
    ) == anthropic_span.attributes.get(SpanAttributes.GEN_AI_USAGE_TOTAL_TOKENS)
    assert (
        anthropic_span.attributes.get("gen_ai.response.id")
        == "msg_bdrk_014eJfxWXNnxFKhmuiT8FYf7"
    )

    logs = log_exporter.get_finished_logs()
    assert len(logs) == 2

    # Validate user message Event
    user_message_log = logs[0]
    assert_message_in_logs(user_message_log, "gen_ai.user.message", {})

    # Validate the ai response
    choice_event = {
        "index": 0,
        "finish_reason": "stop",
        "message": {},
    }
    assert_message_in_logs(logs[1], "gen_ai.choice", choice_event)


@pytest.mark.vcr
def test_anthropic_3_completion_string_content(
    instrument_legacy, brt, span_exporter, log_exporter
):
    body = json.dumps(
        {
            "messages": [
                {
                    "role": "user",
                    "content": "Tell me a joke about opentelemetry",
                }
            ],
            "max_tokens": 200,
            "temperature": 0.5,
            "anthropic_version": "bedrock-2023-05-31",
        }
    )

    response = brt.invoke_model(
        body=body,
        modelId="anthropic.claude-3-sonnet-20240229-v1:0",
        accept="application/json",
        contentType="application/json",
    )

    json.loads(response.get("body").read())

    spans = span_exporter.get_finished_spans()
    assert all(span.name == "chat claude-3-sonnet-20240229-v1:0" for span in spans)

    anthropic_span = spans[0]
    input_messages = json.loads(
        anthropic_span.attributes[GenAIAttributes.GEN_AI_INPUT_MESSAGES]
    )
    assert input_messages[0]["parts"][0]["content"] == "Tell me a joke about opentelemetry"

    output_messages = json.loads(
        anthropic_span.attributes.get(GenAIAttributes.GEN_AI_OUTPUT_MESSAGES)
    )
    assert output_messages[0]["parts"][0]["type"] == "text"
    assert output_messages[0]["parts"][0]["content"] is not None
    assert output_messages[0]["finish_reason"] == "stop"

    assert anthropic_span.attributes[GenAIAttributes.GEN_AI_RESPONSE_FINISH_REASONS] == ("stop",)
    assert anthropic_span.attributes.get(GenAIAttributes.GEN_AI_USAGE_INPUT_TOKENS) == 16
    assert anthropic_span.attributes.get(
        GenAIAttributes.GEN_AI_USAGE_OUTPUT_TOKENS
    ) + anthropic_span.attributes.get(
        GenAIAttributes.GEN_AI_USAGE_INPUT_TOKENS
    ) == anthropic_span.attributes.get(SpanAttributes.GEN_AI_USAGE_TOTAL_TOKENS)
    assert (
        anthropic_span.attributes.get("gen_ai.response.id")
        == "msg_bdrk_01WR9VHqpyBzBhzgwCDapaQD"
    )

    logs = log_exporter.get_finished_logs()
    assert (
        len(logs) == 0
    ), "Assert that it doesn't emit logs when use_legacy_attributes is True"


@pytest.mark.vcr
def test_anthropic_3_completion_string_content_with_events_with_content(
    instrument_with_content, brt, span_exporter, log_exporter
):
    body = json.dumps(
        {
            "messages": [
                {
                    "role": "user",
                    "content": "Tell me a joke about opentelemetry",
                }
            ],
            "max_tokens": 200,
            "temperature": 0.5,
            "anthropic_version": "bedrock-2023-05-31",
        }
    )

    response = brt.invoke_model(
        body=body,
        modelId="anthropic.claude-3-sonnet-20240229-v1:0",
        accept="application/json",
        contentType="application/json",
    )

    response_body = json.loads(response.get("body").read())
    completion = response_body.get("content")

    spans = span_exporter.get_finished_spans()
    assert all(span.name == "chat claude-3-sonnet-20240229-v1:0" for span in spans)

    anthropic_span = spans[0]

    assert anthropic_span.attributes.get(GenAIAttributes.GEN_AI_USAGE_INPUT_TOKENS) == 16
    assert anthropic_span.attributes.get(
        GenAIAttributes.GEN_AI_USAGE_OUTPUT_TOKENS
    ) + anthropic_span.attributes.get(
        GenAIAttributes.GEN_AI_USAGE_INPUT_TOKENS
    ) == anthropic_span.attributes.get(SpanAttributes.GEN_AI_USAGE_TOTAL_TOKENS)
    assert (
        anthropic_span.attributes.get("gen_ai.response.id")
        == "msg_bdrk_01WR9VHqpyBzBhzgwCDapaQD"
    )

    logs = log_exporter.get_finished_logs()
    assert len(logs) == 2

    # Validate user message Event
    user_message_log = logs[0]
    assert_message_in_logs(
        user_message_log,
        "gen_ai.user.message",
        {"content": "Tell me a joke about opentelemetry"},
    )

    # Validate the ai response
    choice_event = {
        "index": 0,
        "finish_reason": "stop",
        "message": {"content": completion},
    }
    assert_message_in_logs(logs[1], "gen_ai.choice", choice_event)


@pytest.mark.vcr
def test_anthropic_3_completion_string_content_with_events_with_no_content(
    instrument_with_no_content, brt, span_exporter, log_exporter
):
    body = json.dumps(
        {
            "messages": [
                {
                    "role": "user",
                    "content": "Tell me a joke about opentelemetry",
                }
            ],
            "max_tokens": 200,
            "temperature": 0.5,
            "anthropic_version": "bedrock-2023-05-31",
        }
    )

    response = brt.invoke_model(
        body=body,
        modelId="anthropic.claude-3-sonnet-20240229-v1:0",
        accept="application/json",
        contentType="application/json",
    )

    json.loads(response.get("body").read())

    spans = span_exporter.get_finished_spans()
    assert all(span.name == "chat claude-3-sonnet-20240229-v1:0" for span in spans)

    anthropic_span = spans[0]

    assert anthropic_span.attributes.get(GenAIAttributes.GEN_AI_USAGE_INPUT_TOKENS) == 16
    assert anthropic_span.attributes.get(
        GenAIAttributes.GEN_AI_USAGE_OUTPUT_TOKENS
    ) + anthropic_span.attributes.get(
        GenAIAttributes.GEN_AI_USAGE_INPUT_TOKENS
    ) == anthropic_span.attributes.get(SpanAttributes.GEN_AI_USAGE_TOTAL_TOKENS)
    assert (
        anthropic_span.attributes.get("gen_ai.response.id")
        == "msg_bdrk_01WR9VHqpyBzBhzgwCDapaQD"
    )

    logs = log_exporter.get_finished_logs()
    assert len(logs) == 2

    # Validate user message Event
    user_message_log = logs[0]
    assert_message_in_logs(user_message_log, "gen_ai.user.message", {})

    # Validate the ai response
    choice_event = {
        "index": 0,
        "finish_reason": "stop",
        "message": {},
    }
    assert_message_in_logs(logs[1], "gen_ai.choice", choice_event)


@pytest.mark.vcr
def test_anthropic_cross_region(instrument_legacy, brt, span_exporter, log_exporter):
    inference_config = {"temperature": 0.5}
    messages = [
        {
            "role": "user",
            "content": [
                {"text": "Human: Tell me a joke about opentelemetry Assistant:"},
            ],
        },
    ]
    response = brt.converse(
        modelId="arn:aws:bedrock:us-east-1:012345678901:inference-profile/us.anthropic.claude-3-7-sonnet-20250219-v1:0",
        messages=messages,
        inferenceConfig=inference_config,
    )
    completion = response["output"]["message"]["content"][0]["text"]

    spans = span_exporter.get_finished_spans()

    assert len(spans) == 1

    anthropic_span = spans[0]
    assert anthropic_span.name == "chat claude-3-7-sonnet-20250219-v1"

    # Assert on model name and vendor
    assert (
        anthropic_span.attributes[GenAIAttributes.GEN_AI_REQUEST_MODEL]
        == "claude-3-7-sonnet-20250219-v1"
    )
    assert anthropic_span.attributes[GenAIAttributes.GEN_AI_PROVIDER_NAME] == GenAiSystemValues.AWS_BEDROCK.value

    input_messages = json.loads(
        anthropic_span.attributes[GenAIAttributes.GEN_AI_INPUT_MESSAGES]
    )
    assert input_messages[0]["parts"][0]["content"] is not None
    output_messages = json.loads(
        anthropic_span.attributes.get(GenAIAttributes.GEN_AI_OUTPUT_MESSAGES)
    )
    assert output_messages[0]["parts"][0]["content"] == completion
    assert output_messages[0]["finish_reason"] == "stop"

    assert anthropic_span.attributes[GenAIAttributes.GEN_AI_RESPONSE_FINISH_REASONS] == ("stop",)
    assert anthropic_span.attributes.get(GenAIAttributes.GEN_AI_USAGE_INPUT_TOKENS) == 20
    assert anthropic_span.attributes.get(
        GenAIAttributes.GEN_AI_USAGE_OUTPUT_TOKENS
    ) + anthropic_span.attributes.get(
        GenAIAttributes.GEN_AI_USAGE_INPUT_TOKENS
    ) == anthropic_span.attributes.get(SpanAttributes.GEN_AI_USAGE_TOTAL_TOKENS)
    # Bedrock does not return the response id for claude-v2:1
    assert anthropic_span.attributes.get("gen_ai.response.id") is None

    logs = log_exporter.get_finished_logs()
    assert (
        len(logs) == 0
    ), "Assert that it doesn't emit logs when use_legacy_attributes is True"


@pytest.mark.vcr
def test_anthropic_cross_region_with_events_with_content(
    instrument_with_content, brt, span_exporter, log_exporter
):
    inference_config = {"temperature": 0.5}
    messages = [
        {
            "role": "user",
            "content": [
                {"text": "Human: Tell me a joke about opentelemetry Assistant:"},
            ],
        },
    ]
    response = brt.converse(
        modelId="arn:aws:bedrock:us-east-1:012345678901:inference-profile/us.anthropic.claude-3-7-sonnet-20250219-v1:0",
        messages=messages,
        inferenceConfig=inference_config,
    )

    spans = span_exporter.get_finished_spans()

    assert len(spans) == 1

    anthropic_span = spans[0]
    assert anthropic_span.name == "chat claude-3-7-sonnet-20250219-v1"

    # Assert on model name and vendor
    assert (
        anthropic_span.attributes[GenAIAttributes.GEN_AI_REQUEST_MODEL]
        == "claude-3-7-sonnet-20250219-v1"
    )
    assert anthropic_span.attributes[GenAIAttributes.GEN_AI_PROVIDER_NAME] == GenAiSystemValues.AWS_BEDROCK.value

    assert anthropic_span.attributes.get(GenAIAttributes.GEN_AI_USAGE_INPUT_TOKENS) == 20
    assert anthropic_span.attributes.get(
        GenAIAttributes.GEN_AI_USAGE_OUTPUT_TOKENS
    ) + anthropic_span.attributes.get(
        GenAIAttributes.GEN_AI_USAGE_INPUT_TOKENS
    ) == anthropic_span.attributes.get(SpanAttributes.GEN_AI_USAGE_TOTAL_TOKENS)
    # Bedrock does not return the response id for claude-v2:1
    assert anthropic_span.attributes.get("gen_ai.response.id") is None

    logs = log_exporter.get_finished_logs()
    assert len(logs) == 2

    # Validate user message Event
    user_message_log = logs[0]
    assert_message_in_logs(
        user_message_log,
        "gen_ai.user.message",
        {
            "content": [
                {"text": "Human: Tell me a joke about opentelemetry Assistant:"},
            ]
        },
    )

    # Validate the ai response
    choice_event = {
        "index": 0,
        "finish_reason": "stop",
        "message": {"content": response["output"]["message"]["content"]},
    }
    assert_message_in_logs(logs[1], "gen_ai.choice", choice_event)


@pytest.mark.vcr
def test_anthropic_cross_region_with_events_with_no_content(
    instrument_with_no_content, brt, span_exporter, log_exporter
):
    inference_config = {"temperature": 0.5}
    messages = [
        {
            "role": "user",
            "content": [
                {"text": "Human: Tell me a joke about opentelemetry Assistant:"},
            ],
        },
    ]
    brt.converse(
        modelId="arn:aws:bedrock:us-east-1:012345678901:inference-profile/us.anthropic.claude-3-7-sonnet-20250219-v1:0",
        messages=messages,
        inferenceConfig=inference_config,
    )

    spans = span_exporter.get_finished_spans()

    assert len(spans) == 1

    anthropic_span = spans[0]
    assert anthropic_span.name == "chat claude-3-7-sonnet-20250219-v1"

    # Assert on model name and vendor
    assert (
        anthropic_span.attributes[GenAIAttributes.GEN_AI_REQUEST_MODEL]
        == "claude-3-7-sonnet-20250219-v1"
    )
    assert anthropic_span.attributes[GenAIAttributes.GEN_AI_PROVIDER_NAME] == GenAiSystemValues.AWS_BEDROCK.value

    assert anthropic_span.attributes.get(GenAIAttributes.GEN_AI_USAGE_INPUT_TOKENS) == 20
    assert anthropic_span.attributes.get(
        GenAIAttributes.GEN_AI_USAGE_OUTPUT_TOKENS
    ) + anthropic_span.attributes.get(
        GenAIAttributes.GEN_AI_USAGE_INPUT_TOKENS
    ) == anthropic_span.attributes.get(SpanAttributes.GEN_AI_USAGE_TOTAL_TOKENS)
    # Bedrock does not return the response id for claude-v2:1
    assert anthropic_span.attributes.get("gen_ai.response.id") is None

    logs = log_exporter.get_finished_logs()
    assert len(logs) == 2

    # Validate user message Event
    user_message_log = logs[0]
    assert_message_in_logs(user_message_log, "gen_ai.user.message", {})

    # Validate the ai response
    choice_event = {
        "index": 0,
        "finish_reason": "stop",
        "message": {},
    }
    assert_message_in_logs(logs[1], "gen_ai.choice", choice_event)


@pytest.mark.vcr
def test_anthropic_converse_stream_with_tool_use(
    instrument_legacy, brt, span_exporter, log_exporter
):
    """Test converse_stream with tool use to validate handling of non-text contentBlockDelta events."""
    messages = [
        {
            "role": "user",
            "content": [{"text": "What is the weather in Barcelona?"}],
        }
    ]

    tools = [
        {
            "toolSpec": {
                "name": "get_weather",
                "description": "Get the current weather for a location",
                "inputSchema": {
                    "json": {
                        "type": "object",
                        "properties": {
                            "location": {
                                "type": "string",
                                "description": "The city name",
                            }
                        },
                        "required": ["location"],
                    }
                },
            }
        }
    ]

    tool_config = {"tools": tools}
    inf_params = {"maxTokens": 300, "temperature": 0.5}

    response = brt.converse_stream(
        modelId="anthropic.claude-3-sonnet-20240229-v1:0",
        messages=messages,
        toolConfig=tool_config,
        inferenceConfig=inf_params,
    )

    stream = response.get("stream")
    content = ""
    tool_use_found = False

    for event in stream:
        # Test should handle contentBlockDelta events without text field
        if "contentBlockDelta" in event:
            delta = event["contentBlockDelta"].get("delta", {})
            # Only append if text exists (validates the fix)
            if "text" in delta:
                content += delta["text"]
            # Check if we got a toolUse delta
            if "toolUse" in delta:
                tool_use_found = True

    spans = span_exporter.get_finished_spans()
    assert len(spans) == 1
    assert spans[0].name == "chat claude-3-sonnet-20240229-v1:0"

    bedrock_span = spans[0]

    # Assert on model name
    assert (
        bedrock_span.attributes.get(GenAIAttributes.GEN_AI_REQUEST_MODEL)
        == "claude-3-sonnet-20240229-v1:0"
    )

    # Assert on vendor
    assert (
        bedrock_span.attributes.get(GenAIAttributes.GEN_AI_PROVIDER_NAME)
        == GenAiSystemValues.AWS_BEDROCK.value
    )

    # Assert on request type
    assert (
        bedrock_span.attributes.get(GenAIAttributes.GEN_AI_OPERATION_NAME)
        == GenAiOperationNameValues.CHAT.value
    )

    # tool use should have been triggered
    # (This test validates that non-text deltas don't crash the instrumentation)
    assert tool_use_found is True

    logs = log_exporter.get_finished_logs()
    assert (
        len(logs) == 0
    ), "Assert that it doesn't emit logs when use_legacy_attributes is True"

