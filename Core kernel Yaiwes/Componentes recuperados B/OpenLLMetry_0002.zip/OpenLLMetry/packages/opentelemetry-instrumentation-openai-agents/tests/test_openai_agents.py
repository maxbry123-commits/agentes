import json
import pytest
from types import SimpleNamespace
from unittest.mock import MagicMock
from opentelemetry.instrumentation.openai_agents import (
    OpenAIAgentsInstrumentor,
)
from opentelemetry.instrumentation.openai_agents._hooks import (
    _extract_response_attributes,
)
from agents import Runner, Agent, function_tool
from opentelemetry.trace import StatusCode
from opentelemetry.semconv_ai import (
    SpanAttributes,
    TraceloopSpanKindValues,
    Meters,
)
from opentelemetry.semconv._incubating.attributes import (
    gen_ai_attributes as GenAIAttributes,
)


@pytest.fixture
def mock_instrumentor():
    instrumentor = OpenAIAgentsInstrumentor()
    instrumentor.instrument = MagicMock()
    instrumentor.uninstrument = MagicMock()
    return instrumentor


@pytest.mark.vcr
def test_dict_content_serialization(exporter):
    """Test that dictionary content in messages is properly serialized to JSON strings."""
    import json
    from agents import Agent, Runner

    # Create a simple agent
    test_agent = Agent(
        name="TestAgent",
        instructions="You are a helpful assistant.",
        model="gpt-4o",
    )

    # Create a query with structured content as array of objects (multimodal format)
    # This should create dict structures that need serialization
    structured_query = [
        {"role": "user", "content": [{"type": "input_text", "text": "Hello, can you help me?"}]},
        {"role": "assistant", "content": [{"type": "output_text", "text": "Of course! How can I help you?"}]},
        {"role": "user", "content": [{"type": "input_text", "text": "What is the weather like?"}]},
    ]

    # Run the agent with structured content
    Runner.run_sync(test_agent, structured_query)

    spans = exporter.get_finished_spans()

    # Look for any spans with message content attributes
    for span in spans:
        for attr_name, attr_value in span.attributes.items():
            prompt_content_check = (
                attr_name in ("gen_ai.input.messages", "gen_ai.output.messages")
            )
            if prompt_content_check:
                # All content attributes should be strings, not dicts
                error_msg = f"Attribute {attr_name} should be a string, got {type(attr_value)}: {attr_value}"
                assert isinstance(attr_value, str), error_msg

                # Message attributes must be valid JSON (arrays of message objects)
                json.loads(attr_value)

    # The test passes if no dict type warnings occurred (all content attributes are strings)


@pytest.mark.vcr
def test_agent_spans(exporter, test_agent):
    query = "What is AI?"
    Runner.run_sync(
        test_agent,
        query,
    )
    spans = exporter.get_finished_spans()

    # Find the agent span
    agent_spans = [s for s in spans if s.name == "testAgent.agent"]
    assert len(agent_spans) == 1, f"Expected 1 agent span, got {len(agent_spans)}"
    agent_span = agent_spans[0]

    # Test agent span attributes (should NOT contain prompts/completions/usage/llm_params)
    assert agent_span.name == "testAgent.agent"
    assert agent_span.kind == agent_span.kind.INTERNAL
    assert agent_span.attributes[SpanAttributes.TRACELOOP_SPAN_KIND] == TraceloopSpanKindValues.AGENT.value
    assert agent_span.attributes[GenAIAttributes.GEN_AI_AGENT_NAME] == "testAgent"
    assert agent_span.attributes[GenAIAttributes.GEN_AI_PROVIDER_NAME] == "openai"
    assert agent_span.status.status_code == StatusCode.OK

    # Agent span should NOT contain LLM parameters
    assert GenAIAttributes.GEN_AI_REQUEST_TEMPERATURE not in agent_span.attributes
    assert GenAIAttributes.GEN_AI_REQUEST_MAX_TOKENS not in agent_span.attributes
    assert GenAIAttributes.GEN_AI_REQUEST_TOP_P not in agent_span.attributes
    assert GenAIAttributes.GEN_AI_REQUEST_FREQUENCY_PENALTY not in agent_span.attributes

    # Find the response span (openai.response) - this should contain prompts/completions/usage
    response_spans = [s for s in spans if s.name == "openai.response"]
    assert len(response_spans) >= 1, f"Expected at least 1 openai.response span, got {len(response_spans)}"
    response_span = response_spans[0]

    # Test proper semantic conventions
    assert response_span.attributes[GenAIAttributes.GEN_AI_OPERATION_NAME] == "chat"
    assert response_span.attributes[GenAIAttributes.GEN_AI_PROVIDER_NAME] == "openai"

    # Test input messages (JSON array with parts-based schema)
    # index 0 is the system message (agent instructions), index 1 is the user message
    input_messages = json.loads(response_span.attributes[GenAIAttributes.GEN_AI_INPUT_MESSAGES])
    assert input_messages[0]["role"] == "system"
    user_message = next(m for m in input_messages if m["role"] == "user")
    assert "parts" in user_message, "Input messages must use parts-based schema"
    assert user_message["parts"][0]["type"] == "text"
    assert user_message["parts"][0]["content"] == "What is AI?"

    # Test usage tokens
    assert response_span.attributes[GenAIAttributes.GEN_AI_USAGE_INPUT_TOKENS] is not None
    assert response_span.attributes[GenAIAttributes.GEN_AI_USAGE_OUTPUT_TOKENS] is not None
    assert response_span.attributes[SpanAttributes.GEN_AI_USAGE_TOTAL_TOKENS] is not None
    assert response_span.attributes[GenAIAttributes.GEN_AI_USAGE_INPUT_TOKENS] > 0
    assert response_span.attributes[GenAIAttributes.GEN_AI_USAGE_OUTPUT_TOKENS] > 0
    assert response_span.attributes[SpanAttributes.GEN_AI_USAGE_TOTAL_TOKENS] > 0

    # Test output messages (JSON array with parts-based schema)
    output_messages = json.loads(response_span.attributes[GenAIAttributes.GEN_AI_OUTPUT_MESSAGES])
    assert "parts" in output_messages[0], "Output messages must use parts-based schema"
    assert output_messages[0]["parts"][0]["type"] == "text"
    assert output_messages[0]["parts"][0]["content"] is not None
    assert len(output_messages[0]["parts"][0]["content"]) > 0
    assert output_messages[0]["role"] is not None
    assert "finish_reason" in output_messages[0], "Output messages must have finish_reason"

    # Test model settings are in the response span
    assert response_span.attributes["gen_ai.request.temperature"] == 0.3
    assert response_span.attributes["gen_ai.request.max_tokens"] == 1024
    assert response_span.attributes["gen_ai.request.top_p"] == 0.2
    assert response_span.attributes.get("gen_ai.request.model") is not None or \
        response_span.attributes.get("gen_ai.response.model") is not None

    # Test proper duration (should be > 0)
    duration_ms = (response_span.end_time - response_span.start_time) / 1_000_000
    assert duration_ms > 0, f"Response span should have positive duration, got {duration_ms}ms"


@pytest.mark.vcr
def test_agent_with_function_tool_spans(exporter, function_tool_agent):
    query = "What is the weather in London?"
    Runner.run_sync(
        function_tool_agent,
        query,
    )
    spans = exporter.get_finished_spans()

    # Expect 5 spans: workflow (root), agent, tool, and 2 response spans (before and after tool)
    assert len(spans) == 5, f"Expected 5 spans (workflow, agent, tool, 2 responses), got {len(spans)}"

    # Find spans by name instead of assuming position
    agent_spans = [s for s in spans if s.name == "WeatherAgent.agent"]
    tool_spans = [s for s in spans if s.name == "get_weather.tool"]
    workflow_spans = [s for s in spans if s.name == "Agent Workflow"]
    response_spans = [s for s in spans if s.name == "openai.response"]

    assert len(agent_spans) == 1, f"Expected 1 agent span, got {len(agent_spans)}: {[s.name for s in agent_spans]}"
    assert len(tool_spans) == 1, f"Expected 1 tool span, got {len(tool_spans)}"
    assert len(workflow_spans) == 1, f"Expected 1 workflow span, got {len(workflow_spans)}"
    assert len(response_spans) == 2, f"Expected 2 response spans (before and after tool), got {len(response_spans)}"

    agent_span = next(s for s in spans if s.name == "WeatherAgent.agent")
    tool_span = next(s for s in spans if s.name == "get_weather.tool")

    assert agent_span.attributes[SpanAttributes.TRACELOOP_SPAN_KIND] == TraceloopSpanKindValues.AGENT.value
    assert tool_span.attributes[SpanAttributes.TRACELOOP_SPAN_KIND] == TraceloopSpanKindValues.TOOL.value
    assert tool_span.kind == tool_span.kind.INTERNAL

    assert tool_span.attributes[GenAIAttributes.GEN_AI_TOOL_NAME] == "get_weather"
    assert tool_span.attributes[GenAIAttributes.GEN_AI_TOOL_TYPE] == "function"

    # Tool description is optional - only test if present
    if GenAIAttributes.GEN_AI_TOOL_DESCRIPTION in tool_span.attributes:
        assert (
            tool_span.attributes[GenAIAttributes.GEN_AI_TOOL_DESCRIPTION]
            == "Gets the current weather for a specified city."
        )

    assert agent_span.status.status_code == StatusCode.OK
    assert tool_span.status.status_code == StatusCode.OK


@pytest.mark.vcr
def test_agent_with_web_search_tool_spans(exporter, web_search_tool_agent):
    query = "Search for latest news on AI."
    Runner.run_sync(
        web_search_tool_agent,
        query,
    )
    spans = exporter.get_finished_spans()

    # Web search creates: workflow, agent, response (3 total) - WebSearchTool doesn't generate FunctionSpanData
    assert len(spans) == 3, f"Expected 3 spans (workflow, agent, response), got {len(spans)}"

    agent_span = next(s for s in spans if s.name == "SearchAgent.agent")
    # WebSearchTool doesn't create a separate tool span - it's handled differently than FunctionTool

    assert agent_span.attributes[SpanAttributes.TRACELOOP_SPAN_KIND] == TraceloopSpanKindValues.AGENT.value

    # WebSearchTool attributes should be on the agent span or response span
    # For now, just verify the agent span works correctly
    assert agent_span.status.status_code == StatusCode.OK


@pytest.mark.vcr
def test_agent_with_handoff_spans(exporter, handoff_agent):
    query = "Please handle this task by delegating to another agent."
    Runner.run_sync(
        handoff_agent,
        query,
    )
    spans = exporter.get_finished_spans()

    assert len(spans) >= 1

    # In this handoff scenario, TriageAgent hands off to AgentA, so we check AgentA span
    agent_a_span = next(s for s in spans if s.name == "AgentA.agent")
    handoff_span = next(s for s in spans if s.name.startswith("TriageAgent →"))

    # Verify the handoff span has the correct structure
    assert "handoff" in handoff_span.name.lower()
    assert handoff_span.status.status_code == StatusCode.OK

    # Verify the agent span was created successfully
    assert agent_a_span.status.status_code == StatusCode.OK
    assert agent_a_span.attributes[SpanAttributes.TRACELOOP_SPAN_KIND] == TraceloopSpanKindValues.AGENT.value


@pytest.mark.vcr
def test_generate_metrics(metrics_test_context, test_agent):
    provider, reader = metrics_test_context

    query = "What is AI?"
    Runner.run_sync(
        test_agent,
        query,
    )
    metrics_data = reader.get_metrics_data()

    # Our hook-based instrumentation currently focuses on spans, not metrics
    if metrics_data is None:
        # Skip metrics test for now - metrics instrumentation not implemented in hook-based approach
        return

    resource_metrics = metrics_data.resource_metrics

    assert len(resource_metrics) > 0

    found_token_metric = False
    found_duration_metric = False

    for rm in resource_metrics:
        for sm in rm.scope_metrics:
            for metric in sm.metrics:
                if metric.name == Meters.LLM_TOKEN_USAGE:
                    found_token_metric = True
                    for data_point in metric.data.data_points:
                        assert data_point.attributes[GenAIAttributes.GEN_AI_TOKEN_TYPE] in [
                            "output",
                            "input",
                        ]
                        assert data_point.count > 0
                        assert data_point.sum > 0

                if metric.name == Meters.LLM_OPERATION_DURATION:
                    found_duration_metric = True
                    assert any(data_point.count > 0 for data_point in metric.data.data_points)
                    assert any(data_point.sum > 0 for data_point in metric.data.data_points)

        assert found_token_metric is True
        assert found_duration_metric is True


@pytest.mark.vcr
@pytest.mark.asyncio
async def test_recipe_workflow_agent_handoffs_with_function_tools(exporter, recipe_workflow_agents):
    """Test agent handoffs with function tools - simplified to test basic agent functionality."""

    main_chat_agent, recipe_editor_agent = recipe_workflow_agents

    query = "Can you edit the carbonara recipe to be vegetarian?"

    # Since the handoff flow is complex, let's test the recipe editor directly to verify tool functionality
    messages = [{"role": "user", "content": query}]
    try:
        runner = Runner()
        await runner.run(starting_agent=recipe_editor_agent, input=messages)
    except Exception:
        # That's okay for testing - spans should still be created
        pass

    spans = exporter.get_finished_spans()
    non_rest_spans = [span for span in spans if not span.name.endswith("v1/responses")]
    span_names = [span.name for span in non_rest_spans]

    # Check for agent and workflow spans (basic requirements)
    assert any("agent" in name.lower() for name in span_names), f"Expected agent span in {span_names}"
    assert "Agent Workflow" in span_names, f"Expected Agent Workflow span in {span_names}"

    # Check for tool spans if they exist (optional for handoff scenarios)
    tool_spans = [name for name in span_names if ".tool" in name]
    if tool_spans:
        search_tool_spans = [s for s in non_rest_spans if s.name == "search_recipes.tool"]
        if search_tool_spans:
            search_tool_span = search_tool_spans[0]
            assert search_tool_span.attributes[SpanAttributes.TRACELOOP_SPAN_KIND] == TraceloopSpanKindValues.TOOL.value
            assert search_tool_span.status.status_code == StatusCode.OK

    # Verify basic span structure is working
    workflow_spans = [s for s in non_rest_spans if s.name == "Agent Workflow"]
    assert len(workflow_spans) == 1, f"Expected exactly 1 workflow span, got {len(workflow_spans)}"

    workflow_span = workflow_spans[0]
    assert workflow_span.parent is None, "Workflow span should be root"
    assert workflow_span.status.status_code == StatusCode.OK


@pytest.mark.vcr
@pytest.mark.asyncio
async def test_music_composer_handoff_hierarchy(exporter):
    """Test that handed-off agent spans are properly nested under the parent agent span."""

    # Use the same approach as the working recipe workflow test
    # Create agents with function tools to trigger handoffs properly
    from agents import function_tool

    # Create a simple function tool for the composer
    @function_tool
    async def compose_music(style: str, key: str) -> str:
        """Compose music in the specified style and key."""
        return f"Composed a beautiful {style} piece in {key} major"

    # Create composer agent with function tools
    composer_agent = Agent(
        name="Symphony Composer",
        instructions=("You compose and arrange symphonic music pieces using your composition tools."),
        model="gpt-4o",
        tools=[compose_music],
    )

    # Create conductor agent that can hand off to composer
    conductor_agent = Agent(
        name="Orchestra Conductor",
        instructions=(
            "You coordinate musical performances. When users ask for composition, hand off to the Symphony Composer."
        ),
        model="gpt-4o",
        handoffs=[composer_agent],
    )

    # Test the handoff workflow
    query = "Can you create a new symphony in D major?"
    messages = [{"role": "user", "content": query}]

    # Run the main conductor agent which should handoff to composer automatically
    # The handoff should happen within the same runner - no need for manual second runner
    conductor_runner = Runner().run_streamed(starting_agent=conductor_agent, input=messages)

    async for event in conductor_runner.stream_events():
        if event.type == "run_item_stream_event" and "handoff" in event.name.lower():
            pass  # Handoff detected but variable not needed
        # Let the handoff complete naturally within the same runner context

    spans = exporter.get_finished_spans()
    non_rest_spans = [span for span in spans if not span.name.endswith("v1/responses")]

    # Verify span hierarchy
    root_spans = [s for s in non_rest_spans if s.parent is None]

    # Updated expectation: Agent Workflow is now the expected root span
    expected_root_span_names = ["Agent Workflow"]  # Workflow span should be the root
    actual_root_span_names = [s.name for s in root_spans]
    unexpected_root_spans = [name for name in actual_root_span_names if name not in expected_root_span_names]

    assert len(unexpected_root_spans) == 0, (
        f"Found unexpected root spans that should be child spans: {unexpected_root_spans}. "
        f"All spans should be children of 'Agent Workflow' root span."
    )


@pytest.mark.vcr
def test_agent_name_propagation_to_agent_spans(exporter, test_agent):
    """Test that agent name is set into agent spans through the context propagation mechanism."""
    from opentelemetry.semconv._incubating.attributes.gen_ai_attributes import GEN_AI_AGENT_NAME

    query = "What is AI?"
    Runner.run_sync(
        test_agent,
        query,
    )
    spans = exporter.get_finished_spans()

    # Find the agent span
    agent_spans = [s for s in spans if s.name == "testAgent.agent"]
    assert len(agent_spans) == 1, f"Expected 1 agent span, got {len(agent_spans)}"
    agent_span = agent_spans[0]

    # Verify the agent span has the agent name attribute set via context propagation
    assert GEN_AI_AGENT_NAME in agent_span.attributes, f"Agent span should have {GEN_AI_AGENT_NAME} attribute"
    assert agent_span.attributes[GEN_AI_AGENT_NAME] == "testAgent", (
        f"Expected agent name 'testAgent', got '{agent_span.attributes[GEN_AI_AGENT_NAME]}'"
    )


@pytest.mark.vcr
def test_tool_call_and_result_attributes(exporter):
    """Test that tool calls and tool results are properly recorded in span attributes."""

    @function_tool
    async def get_city_info(city_name: str) -> str:
        """Get detailed information about a city."""
        # Return structured data to verify it appears in tool result content
        return (
            f"City: {city_name}, "
            "Population: 9000000, "
            "Country: United Kingdom, "
            "Description: Capital city with rich history"
        )

    # Create agent with the tool
    city_info_agent = Agent(
        name="CityInfoAgent",
        instructions="You help users get information about cities using the get_city_info tool.",
        model="gpt-4o",
        tools=[get_city_info],
    )

    # Run query that will trigger the tool call
    query = "Tell me about London"
    Runner.run_sync(city_info_agent, query)

    spans = exporter.get_finished_spans()

    # Find response spans - there should be at least 2 (before and after tool call)
    response_spans = [s for s in spans if s.name == "openai.response"]
    assert len(response_spans) >= 2, (
        f"Expected at least 2 response spans (before and after tool), got {len(response_spans)}"
    )

    # Tool calls and results appear in the second response span (as part of conversation history)
    second_response_span = response_spans[1]

    # The tool call and result appear in the SECOND response span as part of conversation history
    # Parse the input messages JSON array (parts-based schema)
    input_messages = json.loads(
        second_response_span.attributes[GenAIAttributes.GEN_AI_INPUT_MESSAGES]
    )

    tool_call_found = False
    tool_result_found = False

    for msg in input_messages:
        role = msg.get("role")
        parts = msg.get("parts", [])

        if role == "assistant" and not tool_call_found:
            # Look for tool_call parts
            for part in parts:
                if part.get("type") == "tool_call":
                    tool_call_found = True
                    assert part["name"] == "get_city_info", (
                        f"Expected tool name 'get_city_info', got '{part['name']}'"
                    )
                    tool_call_id = part.get("id", "")
                    assert len(tool_call_id) > 0, "Tool call ID should not be empty"
                    arguments = part.get("arguments", "")
                    if isinstance(arguments, dict):
                        arguments = json.dumps(arguments)
                    assert "London" in arguments or "london" in arguments.lower(), (
                        f"Expected 'London' in arguments, got: {arguments}"
                    )
                    break

        elif role == "tool" and not tool_result_found:
            # Look for tool_call_response parts
            for part in parts:
                if part.get("type") == "tool_call_response":
                    tool_result_found = True
                    response_text = part.get("response", "")
                    assert len(response_text) > 0, "Tool result response should not be empty"
                    assert (
                        "London" in response_text
                        or "9000000" in response_text
                        or "United Kingdom" in response_text
                    ), (
                        f"Expected tool result to contain city info, got: {response_text}"
                    )
                    tool_call_id = part.get("id", "")
                    assert len(tool_call_id) > 0, "Tool call ID should not be empty"
                    break

    assert tool_call_found, "No assistant message with tool_call parts found in second response span"
    assert tool_result_found, "No tool message with tool_call_response parts found in second response span"


@pytest.mark.vcr
def test_tool_span_operation_name(exporter, function_tool_agent):
    """Test that tool/function spans have gen_ai.operation.name set to 'execute_tool'."""
    query = "What is the weather in London?"

    Runner.run_sync(function_tool_agent, query)

    spans = exporter.get_finished_spans()
    tool_spans = [s for s in spans if s.name.endswith(".tool")]

    assert len(tool_spans) >= 1, f"Expected at least 1 tool span, found {len(tool_spans)}"

    for tool_span in tool_spans:
        assert GenAIAttributes.GEN_AI_OPERATION_NAME in tool_span.attributes, (
            f"Tool span '{tool_span.name}' missing gen_ai.operation.name attribute"
        )
        assert tool_span.attributes[GenAIAttributes.GEN_AI_OPERATION_NAME] == "execute_tool", (
            f"Tool span '{tool_span.name}' has incorrect gen_ai.operation.name: "
            f"{tool_span.attributes.get(GenAIAttributes.GEN_AI_OPERATION_NAME)}, expected 'execute_tool'"
        )


@pytest.mark.vcr
def test_handoff_span_operation_name(exporter, handoff_agent):
    """Test that handoff spans have gen_ai.operation.name set to 'handoff'."""
    query = "Please handle this task by delegating to another agent."

    Runner.run_sync(handoff_agent, query)

    spans = exporter.get_finished_spans()
    handoff_spans = [s for s in spans if ".handoff" in s.name]

    assert len(handoff_spans) >= 1, f"Expected at least 1 handoff span, found {len(handoff_spans)}"

    for handoff_span in handoff_spans:
        assert GenAIAttributes.GEN_AI_OPERATION_NAME in handoff_span.attributes, (
            f"Handoff span '{handoff_span.name}' missing gen_ai.operation.name attribute"
        )
        assert handoff_span.attributes[GenAIAttributes.GEN_AI_OPERATION_NAME] == "handoff", (
            f"Handoff span '{handoff_span.name}' has incorrect gen_ai.operation.name: "
            f"{handoff_span.attributes.get(GenAIAttributes.GEN_AI_OPERATION_NAME)}, expected 'handoff'"
        )


def _make_fake_response(cached_tokens=None, reasoning_tokens=None):
    """Build a duck-typed Response that exercises only the usage path of
    _extract_response_attributes. Other fields are absent so the helper's
    hasattr/getattr guards short-circuit them.

    Shape verified against:
      - openai-agents SDK v0.14.2 (our pinned floor) — agents.usage.Usage,
        InputTokensDetails (cached_tokens: int), OutputTokensDetails
        (reasoning_tokens: int).
      - A real recorded Responses API payload in this repo's cassette
        tests/cassettes/test_openai_agents/test_music_composer_handoff_hierarchy.yaml,
        which contains:
          "usage": {
            "input_tokens": 75,
            "input_tokens_details": {"cached_tokens": 0},
            "output_tokens": 16,
            "output_tokens_details": {"reasoning_tokens": 0},
            "total_tokens": 91
          }
      - OpenAI Responses API spec: https://platform.openai.com/docs/api-reference/responses
    """
    input_details = SimpleNamespace(cached_tokens=cached_tokens) if cached_tokens is not None else None
    output_details = (
        SimpleNamespace(reasoning_tokens=reasoning_tokens) if reasoning_tokens is not None else None
    )
    usage = SimpleNamespace(
        input_tokens=10,
        output_tokens=20,
        total_tokens=30,
        input_tokens_details=input_details,
        output_tokens_details=output_details,
    )
    return SimpleNamespace(usage=usage)


def test_extract_response_attributes_sets_cache_read_input_tokens():
    """_extract_response_attributes must read usage.input_tokens_details.cached_tokens
    and set gen_ai.usage.cache_read.input_tokens on the span."""
    response = _make_fake_response(cached_tokens=1024)
    span = MagicMock()

    _extract_response_attributes(span, response, trace_content=False)

    span.set_attribute.assert_any_call(
        GenAIAttributes.GEN_AI_USAGE_CACHE_READ_INPUT_TOKENS, 1024
    )


def test_extract_response_attributes_sets_reasoning_tokens():
    """_extract_response_attributes must read usage.output_tokens_details.reasoning_tokens
    and set gen_ai.usage.reasoning_tokens on the span."""
    response = _make_fake_response(reasoning_tokens=256)
    span = MagicMock()

    _extract_response_attributes(span, response, trace_content=False)

    span.set_attribute.assert_any_call(
        SpanAttributes.GEN_AI_USAGE_REASONING_TOKENS, 256
    )
