import { Logger } from '@n8n/backend-common';
import type { IExecutionDb, UpdateExecutionConditions } from '@n8n/db';
import { Container } from '@n8n/di';
import pick from 'lodash/pick';
import { ensureError } from '@n8n/utils/errors/ensure-error';
import { type ExecutionStatus, type IRun, type IWorkflowBase } from 'n8n-workflow';

import { ExecutionPersistence } from '@/executions/execution-persistence';
import type { UpdateExecutionPayload } from '@/interfaces';
import { ExecutionMetadataService } from '@/services/execution-metadata.service';
import { isWorkflowIdValid } from '@/utils';

export function determineFinalExecutionStatus(runData: IRun): ExecutionStatus {
	const workflowHasCrashed = runData.status === 'crashed';
	const workflowWasCanceled = runData.status === 'canceled';
	const workflowHasFailed = runData.status === 'error';
	const workflowDidSucceed =
		!runData.data.resultData?.error &&
		!workflowHasCrashed &&
		!workflowWasCanceled &&
		!workflowHasFailed;
	let workflowStatusFinal: ExecutionStatus = workflowDidSucceed ? 'success' : 'error';
	if (workflowHasCrashed) workflowStatusFinal = 'crashed';
	if (workflowWasCanceled) workflowStatusFinal = 'canceled';
	if (runData.waitTill) workflowStatusFinal = 'waiting';
	return workflowStatusFinal;
}

export function prepareExecutionDataForDbUpdate(parameters: {
	runData: IRun;
	workflowData: IWorkflowBase;
	workflowStatusFinal: ExecutionStatus;
	retryOf?: string;
}) {
	const { runData, workflowData, workflowStatusFinal, retryOf } = parameters;
	// Although it is treated as IWorkflowBase here, it's being instantiated elsewhere with properties that may be sensitive
	// As a result, we should create an IWorkflowBase object with only the data we want to save in it.
	const pristineWorkflowData: IWorkflowBase = pick(workflowData, [
		'id',
		'name',
		'active',
		'activeVersionId',
		'isArchived',
		'createdAt',
		'updatedAt',
		'nodes',
		'connections',
		'settings',
		'staticData',
		'pinData',
		'nodeGroups',
	]);

	const fullExecutionData: UpdateExecutionPayload = {
		data: runData.data,
		mode: runData.mode,
		finished: runData.finished ? runData.finished : false,
		startedAt: runData.startedAt,
		stoppedAt: runData.stoppedAt,
		workflowData: pristineWorkflowData,
		waitTill: runData.waitTill,
		status: workflowStatusFinal,
		workflowId: pristineWorkflowData.id,
	};

	if (retryOf !== undefined) {
		fullExecutionData.retryOf = retryOf.toString();
	}

	const workflowId = workflowData.id;
	if (isWorkflowIdValid(workflowId)) {
		fullExecutionData.workflowId = workflowId;
	}

	return fullExecutionData;
}

export async function updateExistingExecutionMetadata(
	executionId: string,
	metadata?: Record<string, string>,
) {
	const logger = Container.get(Logger);

	try {
		if (metadata && Object.keys(metadata).length > 0) {
			await Container.get(ExecutionMetadataService).save(executionId, metadata);
		}
	} catch (e) {
		const error = ensureError(e);
		logger.error(`Failed to save metadata for execution ID ${executionId}`, { error });
	}
}

export async function updateExistingExecution(parameters: {
	executionId: string;
	workflowId: string;
	executionData: Partial<IExecutionDb>;
	conditions?: UpdateExecutionConditions;
}) {
	const logger = Container.get(Logger);
	const { executionId, workflowId, executionData, conditions } = parameters;
	// Leave log message before flatten as that operation increased memory usage a lot and the chance of a crash is highest here
	logger.debug(`Save execution data to database for execution ID ${executionId}`, {
		executionId,
		workflowId,
		finished: executionData.finished,
		stoppedAt: executionData.stoppedAt,
	});

	const executionPersistence = Container.get(ExecutionPersistence);
	const updated = await executionPersistence.updateExistingExecution(
		executionId,
		executionData,
		conditions,
	);

	if (!updated) {
		logger.debug(
			`Skipped saving execution data for execution ID ${executionId} - update conditions not met`,
			{ executionId, workflowId },
		);
		return;
	}

	if (executionData.finished === true && executionData.retryOf !== undefined) {
		await executionPersistence.updateExistingExecution(executionData.retryOf, {
			retrySuccessId: executionId,
		});
	}
}
