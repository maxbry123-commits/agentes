import { GLOBAL_OWNER_ROLE, type IWorkflowDb } from '@n8n/db';
import type { InstanceSettings } from 'n8n-core';
import type { INode, IRun, IWorkflowBase, IWorkflowExecutionDataProcess } from 'n8n-workflow';
import { mock } from 'vitest-mock-extended';

import type { MessageEventBus } from '@/eventbus/message-event-bus/message-event-bus';
import { EventService } from '@/events/event.service';
import type { RelayEventMap } from '@/events/maps/relay.event-map';
import { LogStreamingEventRelay } from '@/events/relays/log-streaming.event-relay';

describe('LogStreamingEventRelay', () => {
	const eventBus = mock<MessageEventBus>();
	const eventService = new EventService();
	const hostId = 'host-xyz';
	const instanceSettings = mock<InstanceSettings>({ hostId });
	new LogStreamingEventRelay(eventService, eventBus, instanceSettings).init();

	afterEach(() => {
		vi.clearAllMocks();
	});

	describe('workflow events', () => {
		it('should log on `workflow-created` event', () => {
			const event: RelayEventMap['workflow-created'] = {
				user: {
					id: '123',
					email: 'john@n8n.io',
					firstName: 'John',
					lastName: 'Doe',
					role: { slug: 'owner' },
				},
				workflow: mock<IWorkflowBase>({
					id: 'wf123',
					name: 'Test Workflow',
				}),
				publicApi: false,
				projectId: 'proj123',
				projectType: 'personal',
			};

			eventService.emit('workflow-created', event);

			expect(eventBus.sendAuditEvent).toHaveBeenCalledWith({
				eventName: 'n8n.audit.workflow.created',
				payload: {
					userId: '123',
					_email: 'john@n8n.io',
					_firstName: 'John',
					_lastName: 'Doe',
					globalRole: 'owner',
					workflowId: 'wf123',
					workflowName: 'Test Workflow',
				},
			});
		});

		it('should log on `n8n-package-imported` event', () => {
			const event: RelayEventMap['n8n-package-imported'] = {
				user: {
					id: 'user-import',
					email: 'importer@example.com',
					firstName: 'Import',
					lastName: 'User',
					role: { slug: 'global:admin' },
				},
				projectIds: ['proj-brie', 'proj-stilton'],
				folderId: 'folder-cheese',
				workflowIds: ['wf-cheddar', 'wf-brie'],
				options: {
					workflowConflictPolicy: 'new-version',
					workflowIdPolicy: 'new',
					credentialMatchingMode: 'id-only',
					credentialMissingMode: 'must-preexist',
					workflowPublishingPolicy: 'preserve-published-state',
					missingNodeTypeMode: 'fail',
					projectConflictPolicy: 'merge',
					folderConflictPolicy: 'merge',
					overwriteDeletionPolicy: 'archive',
					dataTableMatchingMode: 'by-id',
					dataTableMissingMode: 'create',
					dataTableSchemaConflictPolicy: 'keep-existing',
					variableMissingMode: 'create-stub',
					variableConflictPolicy: 'keep-existing',
					variableParentPolicy: 'project',
					tagMissingMode: 'create',
					tagConflictPolicy: 'skip',
				},
				packageSourceId: 'source-instance-1',
				packageVersion: '1',
				credentialIds: {
					matched: ['cred-1'],
					created: [],
					updated: [],
				},
				// Telemetry-only; must not appear in the audit payload below.
				counts: {
					workflows: {
						created: 1,
						updated: 1,
						skipped: 0,
						archived: 1,
						deleted: 0,
					},
					folders: {
						removed: 1,
					},
					credentials: {
						matched: 1,
						created: 0,
						requirements: 1,
					},
					dataTables: {
						matched: 0,
						created: 1,
						requirements: 1,
					},
					variables: {
						matched: 0,
						missing: 1,
						created: 0,
						stubbed: 0,
						updated: 0,
						requirements: 1,
					},
					tags: {
						matched: 1,
						created: 0,
						renamed: 0,
						reconciled: 0,
						skipped: 0,
						requirements: 1,
					},
				},
			};

			eventService.emit('n8n-package-imported', event);

			expect(eventBus.sendAuditEvent).toHaveBeenCalledWith({
				eventName: 'n8n.audit.n8n-package.import.success',
				payload: {
					userId: 'user-import',
					_email: 'importer@example.com',
					_firstName: 'Import',
					_lastName: 'User',
					globalRole: 'global:admin',
					projectIds: ['proj-brie', 'proj-stilton'],
					folderId: 'folder-cheese',
					workflowIds: ['wf-cheddar', 'wf-brie'],
					options: {
						workflowConflictPolicy: 'new-version',
						workflowIdPolicy: 'new',
						credentialMatchingMode: 'id-only',
						credentialMissingMode: 'must-preexist',
						workflowPublishingPolicy: 'preserve-published-state',
						missingNodeTypeMode: 'fail',
						projectConflictPolicy: 'merge',
						folderConflictPolicy: 'merge',
						overwriteDeletionPolicy: 'archive',
						dataTableMatchingMode: 'by-id',
						dataTableMissingMode: 'create',
						dataTableSchemaConflictPolicy: 'keep-existing',
						variableMissingMode: 'create-stub',
						variableConflictPolicy: 'keep-existing',
						variableParentPolicy: 'project',
						tagMissingMode: 'create',
						tagConflictPolicy: 'skip',
					},
					packageSourceId: 'source-instance-1',
					packageVersion: '1',
					credentialIds: {
						matched: ['cred-1'],
						created: [],
						updated: [],
					},
				},
			});
		});

		it('should log on `n8n-package-exported` event', () => {
			const event: RelayEventMap['n8n-package-exported'] = {
				user: {
					id: 'user-export',
					email: 'exporter@example.com',
					firstName: 'Export',
					lastName: 'User',
					role: { slug: 'global:admin' },
				},
				workflowIds: ['wf-cheddar', 'wf-brie'],
				folderIds: ['folder-gouda'],
				projectIds: ['proj-stilton'],
				// Telemetry-only; must not appear in the audit payload below.
				counts: {
					workflows: 2,
					folders: 1,
					credentials: 1,
					dataTables: 1,
					variables: 1,
					tags: 1,
				},
				// Telemetry-only; must not appear in the audit payload below.
				credentialExportPolicy: 'expression-values-only',
			};

			eventService.emit('n8n-package-exported', event);

			expect(eventBus.sendAuditEvent).toHaveBeenCalledWith({
				eventName: 'n8n.audit.n8n-package.export.success',
				payload: {
					userId: 'user-export',
					_email: 'exporter@example.com',
					_firstName: 'Export',
					_lastName: 'User',
					globalRole: 'global:admin',
					workflowIds: ['wf-cheddar', 'wf-brie'],
					folderIds: ['folder-gouda'],
					projectIds: ['proj-stilton'],
				},
			});
		});

		it('should log on `n8n-package-export-failed` event', () => {
			const event: RelayEventMap['n8n-package-export-failed'] = {
				user: {
					id: 'user-export',
					email: 'exporter@example.com',
					firstName: 'Export',
					lastName: 'User',
					role: { slug: 'global:admin' },
				},
				reason: 'access-denied',
				workflowIds: ['wf-stilton'],
			};

			eventService.emit('n8n-package-export-failed', event);

			expect(eventBus.sendAuditEvent).toHaveBeenCalledWith({
				eventName: 'n8n.audit.n8n-package.export.failed',
				payload: {
					userId: 'user-export',
					_email: 'exporter@example.com',
					_firstName: 'Export',
					_lastName: 'User',
					globalRole: 'global:admin',
					operation: 'export',
					reason: 'access-denied',
					workflowIds: ['wf-stilton'],
				},
			});
		});

		it('should log on `n8n-package-import-failed` event', () => {
			const event: RelayEventMap['n8n-package-import-failed'] = {
				user: {
					id: 'user-import',
					email: 'importer@example.com',
					firstName: 'Import',
					lastName: 'User',
					role: { slug: 'global:admin' },
				},
				reason: 'access-denied',
				projectId: 'proj-brie',
			};

			eventService.emit('n8n-package-import-failed', event);

			expect(eventBus.sendAuditEvent).toHaveBeenCalledWith({
				eventName: 'n8n.audit.n8n-package.import.failed',
				payload: {
					userId: 'user-import',
					_email: 'importer@example.com',
					_firstName: 'Import',
					_lastName: 'User',
					globalRole: 'global:admin',
					operation: 'import',
					reason: 'access-denied',
					projectId: 'proj-brie',
				},
			});
		});

		it('should log on `workflow-archived` event', () => {
			const event: RelayEventMap['workflow-archived'] = {
				user: {
					id: '456',
					email: 'jane@n8n.io',
					firstName: 'Jane',
					lastName: 'Smith',
					role: { slug: 'user' },
				},
				workflowId: 'wf789',
				publicApi: false,
			};

			eventService.emit('workflow-archived', event);

			expect(eventBus.sendAuditEvent).toHaveBeenCalledWith({
				eventName: 'n8n.audit.workflow.archived',
				payload: {
					userId: '456',
					_email: 'jane@n8n.io',
					_firstName: 'Jane',
					_lastName: 'Smith',
					globalRole: 'user',
					workflowId: 'wf789',
				},
			});
		});

		it('should log on `workflow-unarchived` event', () => {
			const event: RelayEventMap['workflow-unarchived'] = {
				user: {
					id: '456',
					email: 'jane@n8n.io',
					firstName: 'Jane',
					lastName: 'Smith',
					role: { slug: 'user' },
				},
				workflowId: 'wf789',
				publicApi: false,
			};

			eventService.emit('workflow-unarchived', event);

			expect(eventBus.sendAuditEvent).toHaveBeenCalledWith({
				eventName: 'n8n.audit.workflow.unarchived',
				payload: {
					userId: '456',
					_email: 'jane@n8n.io',
					_firstName: 'Jane',
					_lastName: 'Smith',
					globalRole: 'user',
					workflowId: 'wf789',
				},
			});
		});

		it('should log on `workflow-activated` event', () => {
			const event: RelayEventMap['workflow-activated'] = {
				user: {
					id: '123',
					email: 'john@n8n.io',
					firstName: 'John',
					lastName: 'Doe',
					role: { slug: 'owner' },
				},
				workflowId: 'wf123',
				workflow: mock<IWorkflowDb>({
					id: 'wf123',
					name: 'Test Workflow',
					activeVersionId: 'version-abc-123',
				}),
				publicApi: false,
			};

			eventService.emit('workflow-activated', event);

			expect(eventBus.sendAuditEvent).toHaveBeenCalledWith({
				eventName: 'n8n.audit.workflow.activated',
				payload: {
					userId: '123',
					_email: 'john@n8n.io',
					_firstName: 'John',
					_lastName: 'Doe',
					globalRole: 'owner',
					workflowId: 'wf123',
					workflowName: 'Test Workflow',
					activeVersionId: 'version-abc-123',
				},
			});
		});

		it('should log on `workflow-deactivated` event', () => {
			const event: RelayEventMap['workflow-deactivated'] = {
				user: {
					id: '456',
					email: 'jane@n8n.io',
					firstName: 'Jane',
					lastName: 'Smith',
					role: { slug: 'user' },
				},
				workflowId: 'wf789',
				workflow: mock<IWorkflowDb>({
					id: 'wf789',
					name: 'Deactivated Workflow',
					activeVersionId: null,
				}),
				publicApi: false,
				deactivatedVersionId: 'version-xyz-789',
			};

			eventService.emit('workflow-deactivated', event);

			expect(eventBus.sendAuditEvent).toHaveBeenCalledWith({
				eventName: 'n8n.audit.workflow.deactivated',
				payload: {
					userId: '456',
					_email: 'jane@n8n.io',
					_firstName: 'Jane',
					_lastName: 'Smith',
					globalRole: 'user',
					workflowId: 'wf789',
					workflowName: 'Deactivated Workflow',
					deactivatedVersionId: 'version-xyz-789',
				},
			});
		});

		it('should log on `workflow-version-updated` event', () => {
			const event: RelayEventMap['workflow-version-updated'] = {
				user: {
					id: '789',
					email: 'john@n8n.io',
					firstName: 'John',
					lastName: 'Doe',
					role: { slug: 'admin' },
				},
				workflowId: 'wf-version-123',
				workflowName: 'Version Test Workflow',
				versionId: 'v-001',
				versionName: 'Production Release',
				versionDescription: 'Initial production release with all features',
			};

			eventService.emit('workflow-version-updated', event);

			expect(eventBus.sendAuditEvent).toHaveBeenCalledWith({
				eventName: 'n8n.audit.workflow.version.updated',
				payload: {
					userId: '789',
					_email: 'john@n8n.io',
					_firstName: 'John',
					_lastName: 'Doe',
					globalRole: 'admin',
					workflowId: 'wf-version-123',
					workflowName: 'Version Test Workflow',
					versionId: 'v-001',
					versionName: 'Production Release',
					versionDescription: 'Initial production release with all features',
				},
			});
		});

		it('should log on `workflow-deleted` event', () => {
			const event: RelayEventMap['workflow-deleted'] = {
				user: {
					id: '456',
					email: 'jane@n8n.io',
					firstName: 'Jane',
					lastName: 'Smith',
					role: { slug: 'user' },
				},
				workflowId: 'wf789',
				publicApi: false,
			};

			eventService.emit('workflow-deleted', event);

			expect(eventBus.sendAuditEvent).toHaveBeenCalledWith({
				eventName: 'n8n.audit.workflow.deleted',
				payload: {
					userId: '456',
					_email: 'jane@n8n.io',
					_firstName: 'Jane',
					_lastName: 'Smith',
					globalRole: 'user',
					workflowId: 'wf789',
				},
			});
		});

		it('should log on `workflow-saved` event', () => {
			const event: RelayEventMap['workflow-saved'] = {
				user: {
					id: '789',
					email: 'alex@n8n.io',
					firstName: 'Alex',
					lastName: 'Johnson',
					role: { slug: 'editor' },
				},
				workflow: mock<IWorkflowDb>({ id: 'wf101', name: 'Updated Workflow' }),
				publicApi: false,
			};

			eventService.emit('workflow-saved', event);

			expect(eventBus.sendAuditEvent).toHaveBeenCalledWith({
				eventName: 'n8n.audit.workflow.updated',
				payload: {
					userId: '789',
					_email: 'alex@n8n.io',
					_firstName: 'Alex',
					_lastName: 'Johnson',
					globalRole: 'editor',
					workflowId: 'wf101',
					workflowName: 'Updated Workflow',
				},
			});
		});

		it('should log on `workflow-saved` event with settings changes', () => {
			const event: RelayEventMap['workflow-saved'] = {
				user: {
					id: '789',
					email: 'alex@n8n.io',
					firstName: 'Alex',
					lastName: 'Johnson',
					role: { slug: 'editor' },
				},
				workflow: mock<IWorkflowDb>({ id: 'wf101', name: 'Updated Workflow' }),
				publicApi: false,
				settingsChanged: {
					saveDataErrorExecution: {
						from: 'none',
						to: 'all',
					},
					saveManualExecutions: {
						from: false,
						to: true,
					},
				},
			};

			eventService.emit('workflow-saved', event);

			expect(eventBus.sendAuditEvent).toHaveBeenCalledWith({
				eventName: 'n8n.audit.workflow.updated',
				payload: {
					userId: '789',
					_email: 'alex@n8n.io',
					_firstName: 'Alex',
					_lastName: 'Johnson',
					globalRole: 'editor',
					workflowId: 'wf101',
					workflowName: 'Updated Workflow',
					settingsChanged: {
						saveDataErrorExecution: {
							from: 'none',
							to: 'all',
						},
						saveManualExecutions: {
							from: false,
							to: true,
						},
					},
				},
			});
		});

		it('should not include settingsChanged when no settings changed', () => {
			const event: RelayEventMap['workflow-saved'] = {
				user: {
					id: '789',
					email: 'alex@n8n.io',
					firstName: 'Alex',
					lastName: 'Johnson',
					role: { slug: 'editor' },
				},
				workflow: mock<IWorkflowDb>({ id: 'wf101', name: 'Updated Workflow' }),
				publicApi: false,
				// settingsChanged is not included when no settings changed
			};

			eventService.emit('workflow-saved', event);

			expect(eventBus.sendAuditEvent).toHaveBeenCalledWith({
				eventName: 'n8n.audit.workflow.updated',
				payload: {
					userId: '789',
					_email: 'alex@n8n.io',
					_firstName: 'Alex',
					_lastName: 'Johnson',
					globalRole: 'editor',
					workflowId: 'wf101',
					workflowName: 'Updated Workflow',
				},
			});
		});

		it('should log on `workflow-pre-execute` event', () => {
			const workflow = mock<IWorkflowBase>({
				id: 'wf202',
				name: 'Test Workflow',
				active: true,
				activeVersionId: 'some-version-id',
				nodes: [],
				connections: {},
				staticData: undefined,
				settings: {},
			});

			const event: RelayEventMap['workflow-pre-execute'] = {
				executionId: 'exec123',
				data: workflow,
				mode: 'trigger',
				projectId: 'proj-123',
				projectName: 'Test Project',
			};

			eventService.emit('workflow-pre-execute', event);

			expect(eventBus.sendWorkflowEvent).toHaveBeenCalledWith({
				eventName: 'n8n.workflow.started',
				payload: {
					executionId: 'exec123',
					userId: undefined,
					workflowId: 'wf202',
					isManual: false,
					mode: 'trigger',
					workflowName: 'Test Workflow',
					projectId: 'proj-123',
					projectName: 'Test Project',
				},
			});
		});

		it('should log on `workflow-pre-execute` with IWorkflowExecutionDataProcess data', () => {
			const executionData = {
				executionData: undefined,
				executionMode: 'manual' as const,
				userId: 'user-abc',
				projectId: 'proj-from-data',
				projectName: 'Data Project',
				workflowData: mock<IWorkflowBase>({ id: 'wf303', name: 'Data Workflow' }),
			} as unknown as IWorkflowExecutionDataProcess;

			const event: RelayEventMap['workflow-pre-execute'] = {
				executionId: 'exec456',
				data: executionData,
				mode: 'manual',
				projectId: 'proj-fallback',
				projectName: 'Fallback Project',
			};

			eventService.emit('workflow-pre-execute', event);

			expect(eventBus.sendWorkflowEvent).toHaveBeenCalledWith({
				eventName: 'n8n.workflow.started',
				payload: {
					executionId: 'exec456',
					userId: 'user-abc',
					workflowId: 'wf303',
					isManual: true,
					mode: 'manual',
					workflowName: 'Data Workflow',
					projectId: 'proj-from-data',
					projectName: 'Data Project',
				},
			});
		});

		it('should log on `workflow-post-execute` for successful execution', () => {
			const payload = mock<RelayEventMap['workflow-post-execute']>({
				executionId: 'some-id',
				userId: 'some-id',
				workflow: mock<IWorkflowBase>({ id: 'some-id', name: 'some-name' }),
				runData: mock<IRun>({
					finished: true,
					status: 'success',
					mode: 'manual',
					data: { resultData: {} },
				} as never),
				projectId: 'proj-456',
				projectName: 'My Project',
			});

			eventService.emit('workflow-post-execute', payload);

			const { runData: _, workflow: __, projectId: ___, projectName: ____, ...rest } = payload;

			expect(eventBus.sendWorkflowEvent).toHaveBeenCalledWith({
				eventName: 'n8n.workflow.success',
				payload: {
					...rest,
					success: true, // same as finished
					isManual: true,
					mode: 'manual',
					workflowName: 'some-name',
					workflowId: 'some-id',
					projectId: 'proj-456',
					projectName: 'My Project',
				},
			});
		});

		it('should log job completion on `workflow-post-execute` for successful job', () => {
			const runData = mock<IRun>({
				finished: true,
				status: 'success',
				mode: 'manual',
				jobId: '12345',
				data: { resultData: {} },
			} as never);

			const event = {
				executionId: 'exec-123',
				userId: 'user-456',
				workflow: mock<IWorkflowBase>({ id: 'wf-789', name: 'Test Workflow' }),
				runData,
			};

			eventService.emit('workflow-post-execute', event);

			expect(eventBus.sendQueueEvent).toHaveBeenCalledWith({
				eventName: 'n8n.queue.job.completed',
				payload: {
					executionId: 'exec-123',
					workflowId: 'wf-789',
					hostId: 'host-xyz',
					jobId: '12345',
				},
			});
		});

		it('should log on `workflow-post-execute` event for failed execution', () => {
			const runData = mock<IRun>({
				status: 'error',
				mode: 'manual',
				finished: false,
				data: {
					resultData: {
						lastNodeExecuted: 'some-node',
						error: {
							node: mock<INode>({ type: 'some-type' }),
							message: 'some-message',
						},
						errorMessage: 'some-message',
					},
				},
			} as never) as unknown as IRun;

			const event = {
				executionId: 'some-id',
				userId: 'some-id',
				workflow: mock<IWorkflowBase>({ id: 'some-id', name: 'some-name' }),
				runData,
				projectId: 'proj-789',
				projectName: 'Failed Project',
			};

			eventService.emit('workflow-post-execute', event);

			const { runData: _, workflow: __, projectId: ___, projectName: ____, ...rest } = event;

			expect(eventBus.sendWorkflowEvent).toHaveBeenCalledWith({
				eventName: 'n8n.workflow.failed',
				payload: {
					...rest,
					success: false, // same as finished
					isManual: true,
					mode: 'manual',
					workflowName: 'some-name',
					workflowId: 'some-id',
					lastNodeExecuted: 'some-node',
					errorNodeType: 'some-type',
					errorMessage: 'some-message',
					projectId: 'proj-789',
					projectName: 'Failed Project',
				},
			});
		});

		it('should log job failure on `workflow-post-execute` for failed job', () => {
			const runData = mock<IRun>({
				finished: false,
				status: 'error',
				mode: 'manual',
				jobId: '67890',
				data: {
					resultData: {
						lastNodeExecuted: 'some-node',
						error: {
							node: mock<INode>({ type: 'some-type' }),
							message: 'some-message',
						},
						errorMessage: 'some-message',
					},
				},
			} as never) as unknown as IRun;

			const event = {
				executionId: 'exec-456',
				userId: 'user-789',
				workflow: mock<IWorkflowBase>({ id: 'wf-101', name: 'Failed Workflow' }),
				runData,
			};

			eventService.emit('workflow-post-execute', event);

			expect(eventBus.sendQueueEvent).toHaveBeenCalledWith({
				eventName: 'n8n.queue.job.failed',
				payload: {
					executionId: 'exec-456',
					workflowId: 'wf-101',
					hostId: 'host-xyz',
					jobId: '67890',
				},
			});
		});
	});

	describe('user events', () => {
		it('should log on `user-updated` event', () => {
			const event: RelayEventMap['user-updated'] = {
				user: {
					id: 'user456',
					email: 'updated@example.com',
					firstName: 'Updated',
					lastName: 'User',
					role: { slug: 'global:member' },
				},
				fieldsChanged: ['firstName', 'lastName', 'password'],
			};

			eventService.emit('user-updated', event);

			expect(eventBus.sendAuditEvent).toHaveBeenCalledWith({
				eventName: 'n8n.audit.user.updated',
				payload: {
					userId: 'user456',
					_email: 'updated@example.com',
					_firstName: 'Updated',
					_lastName: 'User',
					globalRole: 'global:member',
					fieldsChanged: ['firstName', 'lastName', 'password'],
				},
			});
		});

		it('should log on `user-deleted` event', () => {
			const event: RelayEventMap['user-deleted'] = {
				user: {
					id: '123',
					email: 'john@n8n.io',
					firstName: 'John',
					lastName: 'Doe',
					role: { slug: 'some-role' },
				},
				targetUserOldStatus: 'active',
				publicApi: false,
				migrationStrategy: 'transfer_data',
				targetUserId: '456',
				migrationUserId: '789',
			};

			eventService.emit('user-deleted', event);

			expect(eventBus.sendAuditEvent).toHaveBeenCalledWith({
				eventName: 'n8n.audit.user.deleted',
				payload: {
					userId: '123',
					_email: 'john@n8n.io',
					_firstName: 'John',
					_lastName: 'Doe',
					globalRole: 'some-role',
				},
			});
		});

		it('should log on `user-invited` event', () => {
			const event: RelayEventMap['user-invited'] = {
				user: {
					id: 'user101',
					email: 'inviter@example.com',
					firstName: 'Inviter',
					lastName: 'User',
					role: { slug: GLOBAL_OWNER_ROLE.slug },
				},
				targetUserId: ['newUser123'],
				publicApi: false,
				emailSent: true,
				inviteeRole: 'global:member',
			};

			eventService.emit('user-invited', event);

			expect(eventBus.sendAuditEvent).toHaveBeenCalledWith({
				eventName: 'n8n.audit.user.invited',
				payload: {
					userId: 'user101',
					_email: 'inviter@example.com',
					_firstName: 'Inviter',
					_lastName: 'User',
					globalRole: 'global:owner',
					targetUserId: ['newUser123'],
				},
			});
		});

		it('should log on `user-reinvited` event', () => {
			const event: RelayEventMap['user-reinvited'] = {
				user: {
					id: 'user202',
					email: 'reinviter@example.com',
					firstName: 'Reinviter',
					lastName: 'User',
					role: { slug: 'global:admin' },
				},
				targetUserId: ['existingUser456'],
			};

			eventService.emit('user-reinvited', event);

			expect(eventBus.sendAuditEvent).toHaveBeenCalledWith({
				eventName: 'n8n.audit.user.reinvited',
				payload: {
					userId: 'user202',
					_email: 'reinviter@example.com',
					_firstName: 'Reinviter',
					_lastName: 'User',
					globalRole: 'global:admin',
					targetUserId: ['existingUser456'],
				},
			});
		});

		it('should log on `user-signed-up` event', () => {
			const event: RelayEventMap['user-signed-up'] = {
				user: {
					id: 'user303',
					email: 'newuser@example.com',
					firstName: 'New',
					lastName: 'User',
					role: { slug: 'global:member' },
				},
				userType: 'email',
				wasDisabledLdapUser: false,
			};

			eventService.emit('user-signed-up', event);

			expect(eventBus.sendAuditEvent).toHaveBeenCalledWith({
				eventName: 'n8n.audit.user.signedup',
				payload: {
					userId: 'user303',
					_email: 'newuser@example.com',
					_firstName: 'New',
					_lastName: 'User',
					globalRole: 'global:member',
				},
			});
		});

		it('should log on `user-logged-in` event', () => {
			const event: RelayEventMap['user-logged-in'] = {
				user: {
					id: 'user404',
					email: 'loggedin@example.com',
					firstName: 'Logged',
					lastName: 'In',
					role: { slug: GLOBAL_OWNER_ROLE.slug },
				},
				authenticationMethod: 'email',
			};

			eventService.emit('user-logged-in', event);

			expect(eventBus.sendAuditEvent).toHaveBeenCalledWith({
				eventName: 'n8n.audit.user.login.success',
				payload: {
					userId: 'user404',
					_email: 'loggedin@example.com',
					_firstName: 'Logged',
					_lastName: 'In',
					globalRole: 'global:owner',
					authenticationMethod: 'email',
				},
			});
		});

		it('should log on `user-mfa-enabled` event', () => {
			const event: RelayEventMap['user-mfa-enabled'] = {
				user: {
					id: 'user505',
					email: 'mfauser@example.com',
					firstName: 'MFA',
					lastName: 'User',
					role: { slug: 'global:member' },
				},
			};

			eventService.emit('user-mfa-enabled', event);

			expect(eventBus.sendAuditEvent).toHaveBeenCalledWith({
				eventName: 'n8n.audit.user.mfa.enabled',
				payload: {
					userId: 'user505',
					_email: 'mfauser@example.com',
					_firstName: 'MFA',
					_lastName: 'User',
					globalRole: 'global:member',
				},
			});
		});

		it('should log on `user-mfa-disabled` event with mfaCode method', () => {
			const event: RelayEventMap['user-mfa-disabled'] = {
				user: {
					id: 'user606',
					email: 'mfadisable@example.com',
					firstName: 'Disable',
					lastName: 'MFA',
					role: { slug: 'global:member' },
				},
				disableMethod: 'mfaCode',
			};

			eventService.emit('user-mfa-disabled', event);

			expect(eventBus.sendAuditEvent).toHaveBeenCalledWith({
				eventName: 'n8n.audit.user.mfa.disabled',
				payload: {
					userId: 'user606',
					_email: 'mfadisable@example.com',
					_firstName: 'Disable',
					_lastName: 'MFA',
					globalRole: 'global:member',
					disableMethod: 'mfaCode',
				},
			});
		});

		it('should log on `user-mfa-disabled` event with recoveryCode method', () => {
			const event: RelayEventMap['user-mfa-disabled'] = {
				user: {
					id: 'user707',
					email: 'recovery@example.com',
					firstName: 'Recovery',
					lastName: 'User',
					role: { slug: GLOBAL_OWNER_ROLE.slug },
				},
				disableMethod: 'recoveryCode',
			};

			eventService.emit('user-mfa-disabled', event);

			expect(eventBus.sendAuditEvent).toHaveBeenCalledWith({
				eventName: 'n8n.audit.user.mfa.disabled',
				payload: {
					userId: 'user707',
					_email: 'recovery@example.com',
					_firstName: 'Recovery',
					_lastName: 'User',
					globalRole: 'global:owner',
					disableMethod: 'recoveryCode',
				},
			});
		});
	});

	describe('click events', () => {
		it('should log on `user-password-reset-request-click` event', () => {
			const event: RelayEventMap['user-password-reset-request-click'] = {
				user: {
					id: 'user101',
					email: 'user101@example.com',
					firstName: 'John',
					lastName: 'Doe',
					role: { slug: 'global:member' },
				},
			};

			eventService.emit('user-password-reset-request-click', event);

			expect(eventBus.sendAuditEvent).toHaveBeenCalledWith({
				eventName: 'n8n.audit.user.reset.requested',
				payload: {
					userId: 'user101',
					_email: 'user101@example.com',
					_firstName: 'John',
					_lastName: 'Doe',
					globalRole: 'global:member',
				},
			});
		});

		it('should log on `user-invite-email-click` event', () => {
			const event: RelayEventMap['user-invite-email-click'] = {
				inviter: {
					id: '123',
					email: 'john@n8n.io',
					firstName: 'John',
					lastName: 'Doe',
					role: { slug: 'some-role' },
				},
				invitee: {
					id: '456',
					email: 'jane@n8n.io',
					firstName: 'Jane',
					lastName: 'Doe',
					role: { slug: 'some-other-role' },
				},
			};

			eventService.emit('user-invite-email-click', event);

			expect(eventBus.sendAuditEvent).toHaveBeenCalledWith({
				eventName: 'n8n.audit.user.invitation.accepted',
				payload: {
					inviter: {
						userId: '123',
						_email: 'john@n8n.io',
						_firstName: 'John',
						_lastName: 'Doe',
						globalRole: 'some-role',
					},
					invitee: {
						userId: '456',
						_email: 'jane@n8n.io',
						_firstName: 'Jane',
						_lastName: 'Doe',
						globalRole: 'some-other-role',
					},
				},
			});
		});

		it('should log on `user-password-reset-email-click` event', () => {
			const event: RelayEventMap['user-password-reset-email-click'] = {
				user: {
					id: 'user505',
					email: 'resetuser@example.com',
					firstName: 'Reset',
					lastName: 'User',
					role: { slug: 'global:member' },
				},
			};

			eventService.emit('user-password-reset-email-click', event);

			expect(eventBus.sendAuditEvent).toHaveBeenCalledWith({
				eventName: 'n8n.audit.user.reset',
				payload: {
					userId: 'user505',
					_email: 'resetuser@example.com',
					_firstName: 'Reset',
					_lastName: 'User',
					globalRole: 'global:member',
				},
			});
		});
	});

	describe('node events', () => {
		it('should log on `node-pre-execute` event', () => {
			const workflow = mock<IWorkflowBase>({
				id: 'wf303',
				name: 'Test Workflow with Nodes',
				active: true,
				activeVersionId: 'some-version-id',
				nodes: [
					{
						id: 'node1',
						name: 'Start Node',
						type: 'n8n-nodes-base.manualTrigger',
						typeVersion: 1,
						position: [100, 200],
					},
					{
						id: 'node2',
						name: 'HTTP Request',
						type: 'n8n-nodes-base.httpRequest',
						typeVersion: 1,
						position: [300, 200],
					},
				],
				connections: {},
				settings: {},
			});

			const event: RelayEventMap['node-pre-execute'] = {
				executionId: 'exec456',
				nodeName: 'HTTP Request',
				workflow,
				nodeId: 'node2',
				nodeType: 'n8n-nodes-base.httpRequest',
			};

			eventService.emit('node-pre-execute', event);

			expect(eventBus.sendNodeEvent).toHaveBeenCalledWith({
				eventName: 'n8n.node.started',
				payload: {
					executionId: 'exec456',
					nodeName: 'HTTP Request',
					workflowId: 'wf303',
					workflowName: 'Test Workflow with Nodes',
					nodeType: 'n8n-nodes-base.httpRequest',
					nodeId: 'node2',
				},
			});
		});

		it('should log on `node-post-execute` event', () => {
			const workflow = mock<IWorkflowBase>({
				id: 'wf404',
				name: 'Test Workflow with Completed Node',
				active: true,
				activeVersionId: 'some-version-id',
				nodes: [
					{
						id: 'node1',
						name: 'Start Node',
						type: 'n8n-nodes-base.manualTrigger',
						typeVersion: 1,
						position: [100, 200],
					},
					{
						id: 'node2',
						name: 'HTTP Response',
						type: 'n8n-nodes-base.httpResponse',
						typeVersion: 1,
						position: [300, 200],
					},
				],
				connections: {},
				settings: {},
			});

			const event: RelayEventMap['node-post-execute'] = {
				executionId: 'exec789',
				nodeName: 'HTTP Response',
				workflow,
				nodeId: 'node2',
				nodeType: 'n8n-nodes-base.httpResponse',
			};

			eventService.emit('node-post-execute', event);

			expect(eventBus.sendNodeEvent).toHaveBeenCalledWith({
				eventName: 'n8n.node.finished',
				payload: {
					executionId: 'exec789',
					nodeName: 'HTTP Response',
					workflowId: 'wf404',
					workflowName: 'Test Workflow with Completed Node',
					nodeType: 'n8n-nodes-base.httpResponse',
					nodeId: 'node2',
				},
			});
		});
	});

	describe('credentials events', () => {
		it('should log on `credentials-shared` event', () => {
			const event: RelayEventMap['credentials-shared'] = {
				user: {
					id: 'user123',
					email: 'sharer@example.com',
					firstName: 'Alice',
					lastName: 'Sharer',
					role: { slug: GLOBAL_OWNER_ROLE.slug },
				},
				credentialId: 'cred789',
				credentialType: 'githubApi',
				userIdSharer: 'user123',
				userIdsShareesAdded: ['user456', 'user789'],
				shareesRemoved: null,
			};

			eventService.emit('credentials-shared', event);

			expect(eventBus.sendAuditEvent).toHaveBeenCalledWith({
				eventName: 'n8n.audit.user.credentials.shared',
				payload: {
					userId: 'user123',
					_email: 'sharer@example.com',
					_firstName: 'Alice',
					_lastName: 'Sharer',
					globalRole: 'global:owner',
					credentialId: 'cred789',
					credentialType: 'githubApi',
					userIdSharer: 'user123',
					userIdsShareesAdded: ['user456', 'user789'],
					shareesRemoved: null,
				},
			});
		});

		it('should log on `credentials-created` event', () => {
			const event: RelayEventMap['credentials-created'] = {
				user: {
					id: 'user123',
					email: 'user@example.com',
					firstName: 'Test',
					lastName: 'User',
					role: { slug: GLOBAL_OWNER_ROLE.slug },
				},
				credentialType: 'githubApi',
				credentialId: 'cred456',
				publicApi: false,
				projectId: 'proj789',
				projectType: 'Personal',
			};

			eventService.emit('credentials-created', event);

			expect(eventBus.sendAuditEvent).toHaveBeenCalledWith({
				eventName: 'n8n.audit.user.credentials.created',
				payload: {
					userId: 'user123',
					_email: 'user@example.com',
					_firstName: 'Test',
					_lastName: 'User',
					globalRole: 'global:owner',
					credentialType: 'githubApi',
					credentialId: 'cred456',
					publicApi: false,
					projectId: 'proj789',
					projectType: 'Personal',
				},
			});
		});

		it('should log on `credentials-deleted` event', () => {
			const event: RelayEventMap['credentials-deleted'] = {
				user: {
					id: 'user707',
					email: 'creduser@example.com',
					firstName: 'Cred',
					lastName: 'User',
					role: { slug: GLOBAL_OWNER_ROLE.slug },
				},
				credentialId: 'cred789',
				credentialType: 'githubApi',
			};

			eventService.emit('credentials-deleted', event);

			expect(eventBus.sendAuditEvent).toHaveBeenCalledWith({
				eventName: 'n8n.audit.user.credentials.deleted',
				payload: {
					userId: 'user707',
					_email: 'creduser@example.com',
					_firstName: 'Cred',
					_lastName: 'User',
					globalRole: 'global:owner',
					credentialId: 'cred789',
					credentialType: 'githubApi',
				},
			});
		});

		it('should log on `credentials-updated` event', () => {
			const event: RelayEventMap['credentials-updated'] = {
				user: {
					id: 'user808',
					email: 'updatecred@example.com',
					firstName: 'Update',
					lastName: 'Cred',
					role: { slug: GLOBAL_OWNER_ROLE.slug },
				},
				credentialId: 'cred101',
				credentialType: 'slackApi',
			};

			eventService.emit('credentials-updated', event);

			expect(eventBus.sendAuditEvent).toHaveBeenCalledWith({
				eventName: 'n8n.audit.user.credentials.updated',
				payload: {
					userId: 'user808',
					_email: 'updatecred@example.com',
					_firstName: 'Update',
					_lastName: 'Cred',
					globalRole: 'global:owner',
					credentialId: 'cred101',
					credentialType: 'slackApi',
				},
			});
		});
	});

	describe('variable events', () => {
		it('should log on `variable-created` event with projectId', () => {
			const event: RelayEventMap['variable-created'] = {
				user: {
					id: 'user123',
					email: 'user@example.com',
					firstName: 'Test',
					lastName: 'User',
					role: { slug: GLOBAL_OWNER_ROLE.slug },
				},
				variableId: 'var456',
				variableKey: 'MY_VARIABLE',
				projectId: 'proj789',
			};

			eventService.emit('variable-created', event);

			expect(eventBus.sendAuditEvent).toHaveBeenCalledWith({
				eventName: 'n8n.audit.variable.created',
				payload: {
					userId: 'user123',
					_email: 'user@example.com',
					_firstName: 'Test',
					_lastName: 'User',
					globalRole: 'global:owner',
					variableId: 'var456',
					variableKey: 'MY_VARIABLE',
					projectId: 'proj789',
				},
			});
		});

		it('should log on `variable-created` event without projectId', () => {
			const event: RelayEventMap['variable-created'] = {
				user: {
					id: 'user123',
					email: 'user@example.com',
					firstName: 'Test',
					lastName: 'User',
					role: { slug: GLOBAL_OWNER_ROLE.slug },
				},
				variableId: 'var456',
				variableKey: 'MY_GLOBAL_VARIABLE',
			};

			eventService.emit('variable-created', event);

			expect(eventBus.sendAuditEvent).toHaveBeenCalledWith({
				eventName: 'n8n.audit.variable.created',
				payload: {
					userId: 'user123',
					_email: 'user@example.com',
					_firstName: 'Test',
					_lastName: 'User',
					globalRole: 'global:owner',
					variableId: 'var456',
					variableKey: 'MY_GLOBAL_VARIABLE',
				},
			});
		});

		it('should log on `variable-updated` event with projectId', () => {
			const event: RelayEventMap['variable-updated'] = {
				user: {
					id: 'user123',
					email: 'user@example.com',
					firstName: 'Test',
					lastName: 'User',
					role: { slug: 'global:member' },
				},
				variableId: 'var456',
				variableKey: 'MY_UPDATED_VARIABLE',
				projectId: 'proj789',
			};

			eventService.emit('variable-updated', event);

			expect(eventBus.sendAuditEvent).toHaveBeenCalledWith({
				eventName: 'n8n.audit.variable.updated',
				payload: {
					userId: 'user123',
					_email: 'user@example.com',
					_firstName: 'Test',
					_lastName: 'User',
					globalRole: 'global:member',
					variableId: 'var456',
					variableKey: 'MY_UPDATED_VARIABLE',
					projectId: 'proj789',
				},
			});
		});

		it('should log on `variable-updated` event without projectId', () => {
			const event: RelayEventMap['variable-updated'] = {
				user: {
					id: 'user123',
					email: 'user@example.com',
					firstName: 'Test',
					lastName: 'User',
					role: { slug: 'global:member' },
				},
				variableId: 'var456',
				variableKey: 'MY_UPDATED_GLOBAL_VARIABLE',
			};

			eventService.emit('variable-updated', event);

			expect(eventBus.sendAuditEvent).toHaveBeenCalledWith({
				eventName: 'n8n.audit.variable.updated',
				payload: {
					userId: 'user123',
					_email: 'user@example.com',
					_firstName: 'Test',
					_lastName: 'User',
					globalRole: 'global:member',
					variableId: 'var456',
					variableKey: 'MY_UPDATED_GLOBAL_VARIABLE',
				},
			});
		});

		it('should log on `variable-deleted` event with projectId', () => {
			const event: RelayEventMap['variable-deleted'] = {
				user: {
					id: 'user123',
					email: 'user@example.com',
					firstName: 'Test',
					lastName: 'User',
					role: { slug: GLOBAL_OWNER_ROLE.slug },
				},
				variableId: 'var456',
				variableKey: 'MY_DELETED_VARIABLE',
				projectId: 'proj789',
			};

			eventService.emit('variable-deleted', event);

			expect(eventBus.sendAuditEvent).toHaveBeenCalledWith({
				eventName: 'n8n.audit.variable.deleted',
				payload: {
					userId: 'user123',
					_email: 'user@example.com',
					_firstName: 'Test',
					_lastName: 'User',
					globalRole: 'global:owner',
					variableId: 'var456',
					variableKey: 'MY_DELETED_VARIABLE',
					projectId: 'proj789',
				},
			});
		});

		it('should log on `variable-deleted` event without projectId', () => {
			const event: RelayEventMap['variable-deleted'] = {
				user: {
					id: 'user123',
					email: 'user@example.com',
					firstName: 'Test',
					lastName: 'User',
					role: { slug: GLOBAL_OWNER_ROLE.slug },
				},
				variableId: 'var456',
				variableKey: 'MY_DELETED_GLOBAL_VARIABLE',
			};

			eventService.emit('variable-deleted', event);

			expect(eventBus.sendAuditEvent).toHaveBeenCalledWith({
				eventName: 'n8n.audit.variable.deleted',
				payload: {
					userId: 'user123',
					_email: 'user@example.com',
					_firstName: 'Test',
					_lastName: 'User',
					globalRole: 'global:owner',
					variableId: 'var456',
					variableKey: 'MY_DELETED_GLOBAL_VARIABLE',
				},
			});
		});
	});

	describe('Secret events', () => {
		it('should log on `external-secrets-provider-settings-saved`', () => {
			const event: RelayEventMap['external-secrets-provider-settings-saved'] = {
				userId: 'user123',
				vaultType: 'aws',
				isValid: true,
				isNew: false,
			};

			eventService.emit('external-secrets-provider-settings-saved', event);

			expect(eventBus.sendAuditEvent).toHaveBeenCalledWith({
				eventName: 'n8n.audit.external-secrets.provider.settings.saved',
				payload: {
					userId: 'user123',
					vaultType: 'aws',
					isValid: true,
					isNew: false,
				},
			});
		});

		it('should log on `external-secrets-provider-reloaded`', () => {
			const event: RelayEventMap['external-secrets-provider-reloaded'] = {
				vaultType: 'aws',
			};

			eventService.emit('external-secrets-provider-reloaded', event);

			expect(eventBus.sendAuditEvent).toHaveBeenCalledWith({
				eventName: 'n8n.audit.external-secrets.provider.reloaded',
				payload: {
					vaultType: 'aws',
				},
			});
		});

		it('should log on `external-secrets-connection-created`', () => {
			const event: RelayEventMap['external-secrets-connection-created'] = {
				userId: 'user123',
				providerKey: 'my-aws',
				vaultType: 'awsSecretsManager',
				projects: [
					{ id: 'proj1', name: 'Project 1' },
					{ id: 'proj2', name: 'Project 2' },
				],
			};

			eventService.emit('external-secrets-connection-created', event);

			expect(eventBus.sendAuditEvent).toHaveBeenCalledWith({
				eventName: 'n8n.audit.external-secrets.connection.created',
				payload: event,
			});
		});

		it('should log on `external-secrets-connection-updated`', () => {
			const event: RelayEventMap['external-secrets-connection-updated'] = {
				userId: 'user123',
				providerKey: 'my-aws',
				vaultType: 'awsSecretsManager',
				projects: [{ id: 'proj1', name: 'Project 1' }],
			};

			eventService.emit('external-secrets-connection-updated', event);

			expect(eventBus.sendAuditEvent).toHaveBeenCalledWith({
				eventName: 'n8n.audit.external-secrets.connection.updated',
				payload: event,
			});
		});

		it('should log on `external-secrets-connection-deleted`', () => {
			const event: RelayEventMap['external-secrets-connection-deleted'] = {
				userId: 'user123',
				providerKey: 'my-aws',
				vaultType: 'awsSecretsManager',
				projects: [
					{ id: 'proj1', name: 'Project 1' },
					{ id: 'proj2', name: 'Project 2' },
				],
			};

			eventService.emit('external-secrets-connection-deleted', event);

			expect(eventBus.sendAuditEvent).toHaveBeenCalledWith({
				eventName: 'n8n.audit.external-secrets.connection.deleted',
				payload: event,
			});
		});

		it('should log on `external-secrets-connection-tested`', () => {
			const event: RelayEventMap['external-secrets-connection-tested'] = {
				userId: 'user123',
				providerKey: 'my-aws',
				vaultType: 'awsSecretsManager',
				projects: [{ id: 'proj1', name: 'Project 1' }],
				isValid: true,
			};

			eventService.emit('external-secrets-connection-tested', event);

			expect(eventBus.sendAuditEvent).toHaveBeenCalledWith({
				eventName: 'n8n.audit.external-secrets.connection.tested',
				payload: event,
			});
		});

		it('should log on `external-secrets-connection-tested` with error', () => {
			const event: RelayEventMap['external-secrets-connection-tested'] = {
				userId: 'user123',
				providerKey: 'my-aws',
				vaultType: 'awsSecretsManager',
				projects: [{ id: 'proj1', name: 'Project 1' }],
				isValid: false,
				errorMessage: 'Invalid credentials',
			};

			eventService.emit('external-secrets-connection-tested', event);

			expect(eventBus.sendAuditEvent).toHaveBeenCalledWith({
				eventName: 'n8n.audit.external-secrets.connection.tested',
				payload: event,
			});
		});

		it('should log on `external-secrets-connection-reloaded`', () => {
			const event: RelayEventMap['external-secrets-connection-reloaded'] = {
				userId: 'user123',
				providerKey: 'my-aws',
				vaultType: 'awsSecretsManager',
				projects: [
					{ id: 'proj1', name: 'Project 1' },
					{ id: 'proj2', name: 'Project 2' },
				],
			};

			eventService.emit('external-secrets-connection-reloaded', event);

			expect(eventBus.sendAuditEvent).toHaveBeenCalledWith({
				eventName: 'n8n.audit.external-secrets.connection.reloaded',
				payload: event,
			});
		});
	});

	describe('auth events', () => {
		it('should log on `user-login-failed` event', () => {
			const event: RelayEventMap['user-login-failed'] = {
				userEmail: 'user@example.com',
				authenticationMethod: 'email',
				reason: 'Invalid password',
			};

			eventService.emit('user-login-failed', event);

			expect(eventBus.sendAuditEvent).toHaveBeenCalledWith({
				eventName: 'n8n.audit.user.login.failed',
				payload: {
					userEmail: 'user@example.com',
					authenticationMethod: 'email',
					reason: 'Invalid password',
				},
			});
		});
	});

	describe('community package events', () => {
		it('should log on `community-package-updated` event', () => {
			const event: RelayEventMap['community-package-updated'] = {
				user: {
					id: 'user202',
					email: 'packageupdater@example.com',
					firstName: 'Package',
					lastName: 'Updater',
					role: { slug: 'global:admin' },
				},
				packageName: 'n8n-nodes-awesome-package',
				packageVersionCurrent: '1.0.0',
				packageVersionNew: '1.1.0',
				packageNodeNames: ['AwesomeNode1', 'AwesomeNode2'],
				packageAuthor: 'Jane Doe',
				packageAuthorEmail: 'jane@example.com',
			};

			eventService.emit('community-package-updated', event);

			expect(eventBus.sendAuditEvent).toHaveBeenCalledWith({
				eventName: 'n8n.audit.package.updated',
				payload: {
					userId: 'user202',
					_email: 'packageupdater@example.com',
					_firstName: 'Package',
					_lastName: 'Updater',
					globalRole: 'global:admin',
					packageName: 'n8n-nodes-awesome-package',
					packageVersionCurrent: '1.0.0',
					packageVersionNew: '1.1.0',
					packageNodeNames: ['AwesomeNode1', 'AwesomeNode2'],
					packageAuthor: 'Jane Doe',
					packageAuthorEmail: 'jane@example.com',
				},
			});
		});

		it('should log on `community-package-installed` event', () => {
			const event: RelayEventMap['community-package-installed'] = {
				user: {
					id: 'user789',
					email: 'admin@example.com',
					firstName: 'Admin',
					lastName: 'User',
					role: { slug: 'global:admin' },
				},
				inputString: 'n8n-nodes-custom-package',
				packageName: 'n8n-nodes-custom-package',
				success: true,
				packageVersion: '1.0.0',
				packageNodeNames: ['CustomNode1', 'CustomNode2'],
				packageAuthor: 'John Doe',
				packageAuthorEmail: 'john@example.com',
			};

			eventService.emit('community-package-installed', event);

			expect(eventBus.sendAuditEvent).toHaveBeenCalledWith({
				eventName: 'n8n.audit.package.installed',
				payload: {
					userId: 'user789',
					_email: 'admin@example.com',
					_firstName: 'Admin',
					_lastName: 'User',
					globalRole: 'global:admin',
					inputString: 'n8n-nodes-custom-package',
					packageName: 'n8n-nodes-custom-package',
					success: true,
					packageVersion: '1.0.0',
					packageNodeNames: ['CustomNode1', 'CustomNode2'],
					packageAuthor: 'John Doe',
					packageAuthorEmail: 'john@example.com',
				},
			});
		});

		it('should log on `community-package-deleted` event', () => {
			const event: RelayEventMap['community-package-deleted'] = {
				user: {
					id: 'user909',
					email: 'packagedeleter@example.com',
					firstName: 'Package',
					lastName: 'Deleter',
					role: { slug: 'global:admin' },
				},
				packageName: 'n8n-nodes-awesome-package',
				packageVersion: '1.0.0',
				packageNodeNames: ['AwesomeNode1', 'AwesomeNode2'],
				packageAuthor: 'John Doe',
				packageAuthorEmail: 'john@example.com',
			};

			eventService.emit('community-package-deleted', event);

			expect(eventBus.sendAuditEvent).toHaveBeenCalledWith({
				eventName: 'n8n.audit.package.deleted',
				payload: {
					userId: 'user909',
					_email: 'packagedeleter@example.com',
					_firstName: 'Package',
					_lastName: 'Deleter',
					globalRole: 'global:admin',
					packageName: 'n8n-nodes-awesome-package',
					packageVersion: '1.0.0',
					packageNodeNames: ['AwesomeNode1', 'AwesomeNode2'],
					packageAuthor: 'John Doe',
					packageAuthorEmail: 'john@example.com',
				},
			});
		});
	});

	describe('email events', () => {
		it('should log on `email-failed` event', () => {
			const event: RelayEventMap['email-failed'] = {
				user: {
					id: 'user789',
					email: 'recipient@example.com',
					firstName: 'Failed',
					lastName: 'Recipient',
					role: { slug: 'global:member' },
				},
				messageType: 'New user invite',
				publicApi: false,
			};

			eventService.emit('email-failed', event);

			expect(eventBus.sendAuditEvent).toHaveBeenCalledWith({
				eventName: 'n8n.audit.user.email.failed',
				payload: {
					userId: 'user789',
					_email: 'recipient@example.com',
					_firstName: 'Failed',
					_lastName: 'Recipient',
					globalRole: 'global:member',
					messageType: 'New user invite',
				},
			});
		});
	});

	describe('public API events', () => {
		it('should log on `public-api-key-created` event', () => {
			const event: RelayEventMap['public-api-key-created'] = {
				user: {
					id: 'user101',
					email: 'apiuser@example.com',
					firstName: 'API',
					lastName: 'User',
					role: { slug: GLOBAL_OWNER_ROLE.slug },
				},
				publicApi: true,
			};

			eventService.emit('public-api-key-created', event);

			expect(eventBus.sendAuditEvent).toHaveBeenCalledWith({
				eventName: 'n8n.audit.user.api.created',
				payload: {
					userId: 'user101',
					_email: 'apiuser@example.com',
					_firstName: 'API',
					_lastName: 'User',
					globalRole: 'global:owner',
				},
			});
		});

		it('should log on `public-api-key-deleted` event when the user deletes their own key', () => {
			const event: RelayEventMap['public-api-key-deleted'] = {
				user: {
					id: 'user606',
					email: 'apiuser@example.com',
					firstName: 'API',
					lastName: 'User',
					role: { slug: GLOBAL_OWNER_ROLE.slug },
				},
				publicApi: true,
				isOwn: true,
			};

			eventService.emit('public-api-key-deleted', event);

			expect(eventBus.sendAuditEvent).toHaveBeenCalledWith({
				eventName: 'n8n.audit.user.api.deleted',
				payload: {
					userId: 'user606',
					_email: 'apiuser@example.com',
					_firstName: 'API',
					_lastName: 'User',
					globalRole: 'global:owner',
					is_own: true,
				},
			});
		});

		it('should log `is_own: false` on `public-api-key-deleted` event when an admin revokes another user’s key', () => {
			const event: RelayEventMap['public-api-key-deleted'] = {
				user: {
					id: 'admin-1',
					email: 'admin@example.com',
					firstName: 'Admin',
					lastName: 'User',
					role: { slug: GLOBAL_OWNER_ROLE.slug },
				},
				publicApi: false,
				isOwn: false,
			};

			eventService.emit('public-api-key-deleted', event);

			expect(eventBus.sendAuditEvent).toHaveBeenCalledWith({
				eventName: 'n8n.audit.user.api.deleted',
				payload: {
					userId: 'admin-1',
					_email: 'admin@example.com',
					_firstName: 'Admin',
					_lastName: 'User',
					globalRole: 'global:owner',
					is_own: false,
				},
			});
		});
	});

	describe('execution events', () => {
		it('should log on `execution-started-during-bootup` event', () => {
			const event: RelayEventMap['execution-started-during-bootup'] = {
				executionId: 'exec101010',
			};

			eventService.emit('execution-started-during-bootup', event);

			expect(eventBus.sendExecutionEvent).toHaveBeenCalledWith({
				eventName: 'n8n.execution.started-during-bootup',
				payload: {
					executionId: 'exec101010',
				},
			});
		});

		it('should log on `execution-throttled` event', () => {
			const event: RelayEventMap['execution-throttled'] = {
				executionId: 'exec123456',
				type: 'production',
			};

			eventService.emit('execution-throttled', event);

			expect(eventBus.sendExecutionEvent).toHaveBeenCalledWith({
				eventName: 'n8n.execution.throttled',
				payload: {
					executionId: 'exec123456',
					type: 'production',
				},
			});
		});

		it.each(['manual', 'timeout', 'shutdown'] as const)(
			'should log on `execution-cancelled` event with %s reason',
			(reason) => {
				const event: RelayEventMap['execution-cancelled'] = {
					executionId: 'exec-cancelled-123',
					workflowId: 'wf-456',
					workflowName: 'Cancelled Workflow',
					reason,
				};

				eventService.emit('execution-cancelled', event);

				expect(eventBus.sendWorkflowEvent).toHaveBeenCalledWith({
					eventName: 'n8n.workflow.cancelled',
					payload: {
						executionId: 'exec-cancelled-123',
						workflowId: 'wf-456',
						workflowName: 'Cancelled Workflow',
						reason,
					},
				});
			},
		);

		it('should log on `execution-deleted` event with multiple execution ids', () => {
			const event: RelayEventMap['execution-deleted'] = {
				user: {
					id: 'user123',
					email: 'user@example.com',
					firstName: 'Test',
					lastName: 'User',
					role: { slug: 'global:owner' },
				},
				executionIds: ['exec1', 'exec2'],
			};

			eventService.emit('execution-deleted', event);

			expect(eventBus.sendAuditEvent).toHaveBeenCalledWith({
				eventName: 'n8n.audit.user.execution.deleted',
				payload: {
					userId: 'user123',
					_email: 'user@example.com',
					_firstName: 'Test',
					_lastName: 'User',
					globalRole: 'global:owner',
					executionIds: ['exec1', 'exec2'],
				},
			});
		});

		it('should log on `execution-deleted` event with single execution id', () => {
			const event: RelayEventMap['execution-deleted'] = {
				user: {
					id: 'user789',
					email: 'singledelete@example.com',
					firstName: 'Single',
					lastName: 'Deleter',
					role: { slug: 'global:member' },
				},
				executionIds: ['exec-single'],
			};

			eventService.emit('execution-deleted', event);

			expect(eventBus.sendAuditEvent).toHaveBeenCalledWith({
				eventName: 'n8n.audit.user.execution.deleted',
				payload: {
					userId: 'user789',
					_email: 'singledelete@example.com',
					_firstName: 'Single',
					_lastName: 'Deleter',
					globalRole: 'global:member',
					executionIds: ['exec-single'],
				},
			});
		});

		it('should log on `execution-deleted` event with empty execution ids array', () => {
			const event: RelayEventMap['execution-deleted'] = {
				user: {
					id: 'user456',
					email: 'bulkdelete@example.com',
					firstName: 'Bulk',
					lastName: 'Deleter',
					role: { slug: 'global:owner' },
				},
				executionIds: [],
			};

			eventService.emit('execution-deleted', event);

			expect(eventBus.sendAuditEvent).toHaveBeenCalledWith({
				eventName: 'n8n.audit.user.execution.deleted',
				payload: {
					userId: 'user456',
					_email: 'bulkdelete@example.com',
					_firstName: 'Bulk',
					_lastName: 'Deleter',
					globalRole: 'global:owner',
					executionIds: [],
				},
			});
		});

		it('should log on `execution-deleted` event with deleteBefore date filter', () => {
			const deleteBefore = new Date('2024-01-01T00:00:00.000Z');
			const event: RelayEventMap['execution-deleted'] = {
				user: {
					id: 'user999',
					email: 'datefilter@example.com',
					firstName: 'Date',
					lastName: 'Filter',
					role: { slug: 'global:owner' },
				},
				executionIds: [],
				deleteBefore,
			};

			eventService.emit('execution-deleted', event);

			expect(eventBus.sendAuditEvent).toHaveBeenCalledWith({
				eventName: 'n8n.audit.user.execution.deleted',
				payload: {
					userId: 'user999',
					_email: 'datefilter@example.com',
					_firstName: 'Date',
					_lastName: 'Filter',
					globalRole: 'global:owner',
					executionIds: [],
					deleteBefore: '2024-01-01T00:00:00.000Z',
				},
			});
		});

		it('should log on `workflow-executed` event for manual user execution', () => {
			const event: RelayEventMap['workflow-executed'] = {
				user: {
					id: 'user789',
					email: 'executor@example.com',
					firstName: 'Manual',
					lastName: 'Executor',
					role: { slug: 'global:member' },
				},
				workflowId: 'wf-manual',
				workflowName: 'Manual Test Workflow',
				executionId: 'exec-manual-123',
				projectId: 'project-manual',
				projectName: 'Manual Project',
				source: 'user-manual',
			};

			eventService.emit('workflow-executed', event);

			expect(eventBus.sendAuditEvent).toHaveBeenCalledWith({
				eventName: 'n8n.audit.workflow.executed',
				payload: {
					userId: 'user789',
					_email: 'executor@example.com',
					_firstName: 'Manual',
					_lastName: 'Executor',
					globalRole: 'global:member',
					workflowId: 'wf-manual',
					workflowName: 'Manual Test Workflow',
					executionId: 'exec-manual-123',
					projectId: 'project-manual',
					projectName: 'Manual Project',
					source: 'user-manual',
				},
			});
		});

		it('should log on `execution-waiting` event', () => {
			const event: RelayEventMap['execution-waiting'] = {
				executionId: 'exec-waiting-123',
				workflowId: 'wf-waiting-456',
			};

			eventService.emit('execution-waiting', event);

			expect(eventBus.sendAuditEvent).toHaveBeenCalledWith({
				eventName: 'n8n.audit.workflow.waiting',
				payload: {
					executionId: 'exec-waiting-123',
					workflowId: 'wf-waiting-456',
				},
			});
		});

		it('should log on `execution-resumed` event with resumeSource webhook', () => {
			const responseAt = new Date('2025-06-02T08:00:00.000Z');
			const event: RelayEventMap['execution-resumed'] = {
				executionId: 'exec-resumed-123',
				workflowId: 'wf-resumed-456',
				resumeSource: 'webhook',
				responseAt,
			};

			eventService.emit('execution-resumed', event);

			expect(eventBus.sendAuditEvent).toHaveBeenCalledWith({
				eventName: 'n8n.audit.workflow.resumed',
				payload: {
					executionId: 'exec-resumed-123',
					workflowId: 'wf-resumed-456',
					resumeSource: 'webhook',
					responseAt: responseAt.toISOString(),
				},
			});
		});

		it('should log on `workflow-executed` event for retry user execution', () => {
			const event: RelayEventMap['workflow-executed'] = {
				user: {
					id: 'user101',
					email: 'retrier@example.com',
					firstName: 'Retry',
					lastName: 'User',
					role: { slug: GLOBAL_OWNER_ROLE.slug },
				},
				workflowId: 'wf-retry',
				workflowName: 'Retry Test Workflow',
				executionId: 'exec-retry-456',
				projectId: 'project-retry',
				projectName: 'Retry Project',
				source: 'user-retry',
			};

			eventService.emit('workflow-executed', event);

			expect(eventBus.sendAuditEvent).toHaveBeenCalledWith({
				eventName: 'n8n.audit.workflow.executed',
				payload: {
					userId: 'user101',
					_email: 'retrier@example.com',
					_firstName: 'Retry',
					_lastName: 'User',
					globalRole: 'global:owner',
					workflowId: 'wf-retry',
					workflowName: 'Retry Test Workflow',
					executionId: 'exec-retry-456',
					projectId: 'project-retry',
					projectName: 'Retry Project',
					source: 'user-retry',
				},
			});
		});

		it('should log on `workflow-executed` event for webhook execution', () => {
			const event: RelayEventMap['workflow-executed'] = {
				workflowId: 'wf-webhook',
				workflowName: 'Webhook Test Workflow',
				executionId: 'exec-webhook-123',
				projectId: 'project-webhook',
				projectName: 'Webhook Project',
				source: 'webhook',
			};

			eventService.emit('workflow-executed', event);

			expect(eventBus.sendAuditEvent).toHaveBeenCalledWith({
				eventName: 'n8n.audit.workflow.executed',
				payload: {
					workflowId: 'wf-webhook',
					workflowName: 'Webhook Test Workflow',
					executionId: 'exec-webhook-123',
					projectId: 'project-webhook',
					projectName: 'Webhook Project',
					source: 'webhook',
				},
			});
		});

		it('should log on `workflow-executed` event for trigger execution', () => {
			const event: RelayEventMap['workflow-executed'] = {
				workflowId: 'wf-trigger',
				workflowName: 'Trigger Test Workflow',
				executionId: 'exec-trigger-123',
				projectId: 'project-trigger',
				projectName: 'Trigger Project',
				source: 'trigger',
			};

			eventService.emit('workflow-executed', event);

			expect(eventBus.sendAuditEvent).toHaveBeenCalledWith({
				eventName: 'n8n.audit.workflow.executed',
				payload: {
					workflowId: 'wf-trigger',
					workflowName: 'Trigger Test Workflow',
					executionId: 'exec-trigger-123',
					projectId: 'project-trigger',
					projectName: 'Trigger Project',
					source: 'trigger',
				},
			});
		});

		it('should log on `workflow-executed` event for error workflow execution', () => {
			const event: RelayEventMap['workflow-executed'] = {
				workflowId: 'wf-error',
				workflowName: 'Error Test Workflow',
				executionId: 'exec-error-123',
				projectId: 'project-error',
				projectName: 'Error Project',
				source: 'error',
			};

			eventService.emit('workflow-executed', event);

			expect(eventBus.sendAuditEvent).toHaveBeenCalledWith({
				eventName: 'n8n.audit.workflow.executed',
				payload: {
					workflowId: 'wf-error',
					workflowName: 'Error Test Workflow',
					executionId: 'exec-error-123',
					projectId: 'project-error',
					projectName: 'Error Project',
					source: 'error',
				},
			});
		});

		it('should log on `workflow-executed` event for CLI execution', () => {
			const event: RelayEventMap['workflow-executed'] = {
				user: {
					id: 'user-cli',
				},
				workflowId: 'wf-cli',
				workflowName: 'CLI Test Workflow',
				executionId: 'exec-cli-123',
				projectId: 'project-cli',
				projectName: 'CLI Project',
				source: 'cli',
			};

			eventService.emit('workflow-executed', event);

			expect(eventBus.sendAuditEvent).toHaveBeenCalledWith({
				eventName: 'n8n.audit.workflow.executed',
				payload: {
					userId: 'user-cli',
					workflowId: 'wf-cli',
					workflowName: 'CLI Test Workflow',
					executionId: 'exec-cli-123',
					projectId: 'project-cli',
					projectName: 'CLI Project',
					source: 'cli',
				},
			});
		});

		it('should log on `workflow-executed` event for integrated/subworkflow execution', () => {
			const event: RelayEventMap['workflow-executed'] = {
				user: {
					id: 'user-integrated',
				},
				workflowId: 'wf-integrated',
				workflowName: 'Integrated Test Workflow',
				executionId: 'exec-integrated-123',
				projectId: 'project-integrated',
				projectName: 'Integrated Project',
				source: 'integrated',
			};

			eventService.emit('workflow-executed', event);

			expect(eventBus.sendAuditEvent).toHaveBeenCalledWith({
				eventName: 'n8n.audit.workflow.executed',
				payload: {
					userId: 'user-integrated',
					workflowId: 'wf-integrated',
					workflowName: 'Integrated Test Workflow',
					executionId: 'exec-integrated-123',
					projectId: 'project-integrated',
					projectName: 'Integrated Project',
					source: 'integrated',
				},
			});
		});

		it('should log on `workflow-executed` event for evaluation execution', () => {
			const event: RelayEventMap['workflow-executed'] = {
				user: {
					id: 'user-eval',
				},
				workflowId: 'wf-evaluation',
				workflowName: 'Evaluation Test Workflow',
				executionId: 'exec-evaluation-123',
				projectId: 'project-evaluation',
				projectName: 'Evaluation Project',
				source: 'evaluation',
			};

			eventService.emit('workflow-executed', event);

			expect(eventBus.sendAuditEvent).toHaveBeenCalledWith({
				eventName: 'n8n.audit.workflow.executed',
				payload: {
					userId: 'user-eval',
					workflowId: 'wf-evaluation',
					workflowName: 'Evaluation Test Workflow',
					executionId: 'exec-evaluation-123',
					projectId: 'project-evaluation',
					projectName: 'Evaluation Project',
					source: 'evaluation',
				},
			});
		});

		it('should log on `workflow-executed` event for chat execution', () => {
			const event: RelayEventMap['workflow-executed'] = {
				user: {
					id: 'user-chat',
				},
				workflowId: 'wf-chat',
				workflowName: 'Chat Test Workflow',
				executionId: 'exec-chat-123',
				projectId: 'project-chat',
				projectName: 'Chat Project',
				source: 'chat',
			};

			eventService.emit('workflow-executed', event);

			expect(eventBus.sendAuditEvent).toHaveBeenCalledWith({
				eventName: 'n8n.audit.workflow.executed',
				payload: {
					userId: 'user-chat',
					workflowId: 'wf-chat',
					workflowName: 'Chat Test Workflow',
					executionId: 'exec-chat-123',
					projectId: 'project-chat',
					projectName: 'Chat Project',
					source: 'chat',
				},
			});
		});
	});

	describe('AI events', () => {
		it('should log on `ai-messages-retrieved-from-memory` event', () => {
			const payload: RelayEventMap['ai-messages-retrieved-from-memory'] = {
				msg: 'Hello, world!',
				executionId: 'exec789',
				nodeName: 'Memory',
				workflowId: 'wf123',
				workflowName: 'My Workflow',
				nodeType: 'n8n-nodes-base.memory',
			};

			eventService.emit('ai-messages-retrieved-from-memory', payload);

			expect(eventBus.sendAiNodeEvent).toHaveBeenCalledWith({
				eventName: 'n8n.ai.memory.get.messages',
				payload,
			});
		});

		it('should log on `ai-message-added-to-memory` event', () => {
			const payload: RelayEventMap['ai-message-added-to-memory'] = {
				msg: 'Test',
				executionId: 'exec456',
				nodeName: 'Memory',
				workflowId: 'wf789',
				workflowName: 'My Workflow',
				nodeType: 'n8n-nodes-base.memory',
			};

			eventService.emit('ai-message-added-to-memory', payload);

			expect(eventBus.sendAiNodeEvent).toHaveBeenCalledWith({
				eventName: 'n8n.ai.memory.added.message',
				payload,
			});
		});

		it('should log on `ai-output-parsed` event', () => {
			const payload: RelayEventMap['ai-output-parsed'] = {
				msg: 'Test',
				executionId: 'exec123',
				nodeName: 'Output Parser',
				workflowId: 'wf456',
				workflowName: 'My Workflow',
				nodeType: 'n8n-nodes-base.outputParser',
			};

			eventService.emit('ai-output-parsed', payload);

			expect(eventBus.sendAiNodeEvent).toHaveBeenCalledWith({
				eventName: 'n8n.ai.output.parser.parsed',
				payload,
			});
		});

		it('should log on `ai-documents-retrieved` event', () => {
			const payload: RelayEventMap['ai-documents-retrieved'] = {
				msg: 'Test',
				executionId: 'exec789',
				nodeName: 'Retriever',
				workflowId: 'wf123',
				workflowName: 'My Workflow',
				nodeType: 'n8n-nodes-base.retriever',
			};

			eventService.emit('ai-documents-retrieved', payload);

			expect(eventBus.sendAiNodeEvent).toHaveBeenCalledWith({
				eventName: 'n8n.ai.retriever.get.relevant.documents',
				payload,
			});
		});

		it('should log on `ai-document-embedded` event', () => {
			const payload: RelayEventMap['ai-document-embedded'] = {
				msg: 'Test',
				executionId: 'exec456',
				nodeName: 'Embeddings',
				workflowId: 'wf789',
				workflowName: 'My Workflow',
				nodeType: 'n8n-nodes-base.embeddings',
			};

			eventService.emit('ai-document-embedded', payload);

			expect(eventBus.sendAiNodeEvent).toHaveBeenCalledWith({
				eventName: 'n8n.ai.embeddings.embedded.document',
				payload,
			});
		});

		it('should log on `ai-query-embedded` event', () => {
			const payload: RelayEventMap['ai-query-embedded'] = {
				msg: 'Test',
				executionId: 'exec123',
				nodeName: 'Embeddings',
				workflowId: 'wf456',
				workflowName: 'My Workflow',
				nodeType: 'n8n-nodes-base.embeddings',
			};

			eventService.emit('ai-query-embedded', payload);

			expect(eventBus.sendAiNodeEvent).toHaveBeenCalledWith({
				eventName: 'n8n.ai.embeddings.embedded.query',
				payload,
			});
		});

		it('should log on `ai-document-processed` event', () => {
			const payload: RelayEventMap['ai-document-processed'] = {
				msg: 'Test',
				executionId: 'exec789',
				nodeName: 'Embeddings',
				workflowId: 'wf789',
				workflowName: 'My Workflow',
				nodeType: 'n8n-nodes-base.embeddings',
			};

			eventService.emit('ai-document-processed', payload);

			expect(eventBus.sendAiNodeEvent).toHaveBeenCalledWith({
				eventName: 'n8n.ai.document.processed',
				payload,
			});
		});

		it('should log on `ai-text-split` event', () => {
			const payload: RelayEventMap['ai-text-split'] = {
				msg: 'Test',
				executionId: 'exec456',
				nodeName: 'Text Splitter',
				workflowId: 'wf789',
				workflowName: 'My Workflow',
				nodeType: 'n8n-nodes-base.textSplitter',
			};

			eventService.emit('ai-text-split', payload);

			expect(eventBus.sendAiNodeEvent).toHaveBeenCalledWith({
				eventName: 'n8n.ai.text.splitter.split',
				payload,
			});
		});

		it('should log on `ai-tool-called` event', () => {
			const payload: RelayEventMap['ai-tool-called'] = {
				msg: 'Test',
				executionId: 'exec123',
				nodeName: 'Tool',
				workflowId: 'wf456',
				workflowName: 'My Workflow',
				nodeType: 'n8n-nodes-base.tool',
			};

			eventService.emit('ai-tool-called', payload);

			expect(eventBus.sendAiNodeEvent).toHaveBeenCalledWith({
				eventName: 'n8n.ai.tool.called',
				payload,
			});
		});

		it('should log on `ai-vector-store-searched` event', () => {
			const payload: RelayEventMap['ai-vector-store-searched'] = {
				msg: 'Test',
				executionId: 'exec789',
				nodeName: 'Vector Store',
				workflowId: 'wf123',
				workflowName: 'My Workflow',
				nodeType: 'n8n-nodes-base.vectorStore',
			};

			eventService.emit('ai-vector-store-searched', payload);

			expect(eventBus.sendAiNodeEvent).toHaveBeenCalledWith({
				eventName: 'n8n.ai.vector.store.searched',
				payload,
			});
		});

		it('should log on `ai-llm-generated-output` event', () => {
			const payload: RelayEventMap['ai-llm-generated-output'] = {
				msg: 'Test',
				executionId: 'exec456',
				nodeName: 'OpenAI',
				workflowId: 'wf789',
				workflowName: 'My Workflow',
				nodeType: 'n8n-nodes-base.openai',
			};

			eventService.emit('ai-llm-generated-output', payload);

			expect(eventBus.sendAiNodeEvent).toHaveBeenCalledWith({
				eventName: 'n8n.ai.llm.generated',
				payload,
			});
		});

		it('should log on `ai-llm-errored` event', () => {
			const payload: RelayEventMap['ai-llm-errored'] = {
				msg: 'Test',
				executionId: 'exec789',
				nodeName: 'OpenAI',
				workflowId: 'wf123',
				workflowName: 'My Workflow',
				nodeType: 'n8n-nodes-base.openai',
			};

			eventService.emit('ai-llm-errored', payload);

			expect(eventBus.sendAiNodeEvent).toHaveBeenCalledWith({
				eventName: 'n8n.ai.llm.error',
				payload,
			});
		});

		it('should log on `ai-vector-store-populated` event', () => {
			const payload: RelayEventMap['ai-vector-store-populated'] = {
				msg: 'Test',
				executionId: 'exec456',
				nodeName: 'Vector Store',
				workflowId: 'wf789',
				workflowName: 'My Workflow',
				nodeType: 'n8n-nodes-base.vectorStore',
			};

			eventService.emit('ai-vector-store-populated', payload);

			expect(eventBus.sendAiNodeEvent).toHaveBeenCalledWith({
				eventName: 'n8n.ai.vector.store.populated',
				payload,
			});
		});

		it('should log on `ai-vector-store-updated` event', () => {
			const payload: RelayEventMap['ai-vector-store-updated'] = {
				msg: 'Test',
				executionId: 'exec789',
				nodeName: 'Vector Store',
				workflowId: 'wf123',
				workflowName: 'My Workflow',
				nodeType: 'n8n-nodes-base.vectorStore',
			};

			eventService.emit('ai-vector-store-updated', payload);

			expect(eventBus.sendAiNodeEvent).toHaveBeenCalledWith({
				eventName: 'n8n.ai.vector.store.updated',
				payload,
			});
		});
	});

	describe('runner events', () => {
		it('should log on `runner-task-requested` event', () => {
			const event: RelayEventMap['runner-task-requested'] = {
				taskId: 't-1',
				nodeId: 'n-2',
				executionId: 'e-3',
				workflowId: 'w-4',
			};

			eventService.emit('runner-task-requested', event);

			expect(eventBus.sendRunnerEvent).toHaveBeenCalledWith({
				eventName: 'n8n.runner.task.requested',
				payload: {
					taskId: 't-1',
					nodeId: 'n-2',
					executionId: 'e-3',
					workflowId: 'w-4',
				},
			});
		});

		it('should log on `runner-response-received` event', () => {
			const event: RelayEventMap['runner-response-received'] = {
				taskId: 't-1',
				nodeId: 'n-2',
				executionId: 'e-3',
				workflowId: 'w-4',
			};

			eventService.emit('runner-response-received', event);

			expect(eventBus.sendRunnerEvent).toHaveBeenCalledWith({
				eventName: 'n8n.runner.response.received',
				payload: {
					taskId: 't-1',
					nodeId: 'n-2',
					executionId: 'e-3',
					workflowId: 'w-4',
				},
			});
		});
	});

	describe('job events', () => {
		it('should log on `job-enqueued` event', () => {
			const event: RelayEventMap['job-enqueued'] = {
				executionId: 'exec-1',
				workflowId: 'wf-2',
				hostId,
				jobId: 'job-4',
			};

			eventService.emit('job-enqueued', event);

			expect(eventBus.sendQueueEvent).toHaveBeenCalledWith({
				eventName: 'n8n.queue.job.enqueued',
				payload: {
					executionId: 'exec-1',
					workflowId: 'wf-2',
					hostId,
					jobId: 'job-4',
				},
			});
		});

		it('should log on `job-dequeued` event', () => {
			const event: RelayEventMap['job-dequeued'] = {
				executionId: 'exec-1',
				workflowId: 'wf-2',
				hostId,
				jobId: 'job-4',
			};

			eventService.emit('job-dequeued', event);

			expect(eventBus.sendQueueEvent).toHaveBeenCalledWith({
				eventName: 'n8n.queue.job.dequeued',
				payload: {
					executionId: 'exec-1',
					workflowId: 'wf-2',
					hostId,
					jobId: 'job-4',
				},
			});
		});

		it('should log on `job-stalled` event', () => {
			const event: RelayEventMap['job-stalled'] = {
				executionId: 'exec-1',
				workflowId: 'wf-2',
				hostId,
				jobId: 'job-4',
			};

			eventService.emit('job-stalled', event);

			expect(eventBus.sendQueueEvent).toHaveBeenCalledWith({
				eventName: 'n8n.queue.job.stalled',
				payload: {
					executionId: 'exec-1',
					workflowId: 'wf-2',
					hostId,
					jobId: 'job-4',
				},
			});
		});
	});

	describe('instance policies events', () => {
		it('should log `personal-publishing-restricted.enabled` when workflow_publishing is disabled', () => {
			const event: RelayEventMap['instance-policies-updated'] = {
				user: {
					id: 'user123',
					email: 'admin@example.com',
					firstName: 'Admin',
					lastName: 'User',
					role: { slug: 'global:owner' },
				},
				settingName: 'workflow_publishing',
				value: false,
			};

			eventService.emit('instance-policies-updated', event);

			expect(eventBus.sendAuditEvent).toHaveBeenCalledWith({
				eventName: 'n8n.audit.personal-publishing-restricted.enabled',
				payload: {
					userId: 'user123',
					_email: 'admin@example.com',
					_firstName: 'Admin',
					_lastName: 'User',
					globalRole: 'global:owner',
				},
			});
		});

		it('should log `personal-publishing-restricted.disabled` when workflow_publishing is enabled', () => {
			const event: RelayEventMap['instance-policies-updated'] = {
				user: {
					id: 'user456',
					email: 'admin2@example.com',
					firstName: 'Another',
					lastName: 'Admin',
					role: { slug: 'global:admin' },
				},
				settingName: 'workflow_publishing',
				value: true,
			};

			eventService.emit('instance-policies-updated', event);

			expect(eventBus.sendAuditEvent).toHaveBeenCalledWith({
				eventName: 'n8n.audit.personal-publishing-restricted.disabled',
				payload: {
					userId: 'user456',
					_email: 'admin2@example.com',
					_firstName: 'Another',
					_lastName: 'Admin',
					globalRole: 'global:admin',
				},
			});
		});

		it('should log `personal-sharing-restricted.enabled` when workflow_sharing is disabled', () => {
			const event: RelayEventMap['instance-policies-updated'] = {
				user: {
					id: 'user789',
					email: 'admin3@example.com',
					firstName: 'Third',
					lastName: 'Admin',
					role: { slug: 'global:owner' },
				},
				settingName: 'workflow_sharing',
				value: false,
			};

			eventService.emit('instance-policies-updated', event);

			expect(eventBus.sendAuditEvent).toHaveBeenCalledWith({
				eventName: 'n8n.audit.personal-sharing-restricted.enabled',
				payload: {
					userId: 'user789',
					_email: 'admin3@example.com',
					_firstName: 'Third',
					_lastName: 'Admin',
					globalRole: 'global:owner',
				},
			});
		});

		it('should log `personal-sharing-restricted.disabled` when workflow_sharing is enabled', () => {
			const event: RelayEventMap['instance-policies-updated'] = {
				user: {
					id: 'user101',
					email: 'admin4@example.com',
					firstName: 'Fourth',
					lastName: 'Admin',
					role: { slug: 'global:admin' },
				},
				settingName: 'workflow_sharing',
				value: true,
			};

			eventService.emit('instance-policies-updated', event);

			expect(eventBus.sendAuditEvent).toHaveBeenCalledWith({
				eventName: 'n8n.audit.personal-sharing-restricted.disabled',
				payload: {
					userId: 'user101',
					_email: 'admin4@example.com',
					_firstName: 'Fourth',
					_lastName: 'Admin',
					globalRole: 'global:admin',
				},
			});
		});

		it('should log `2fa-enforcement.enabled` when 2fa_enforcement is enabled', () => {
			const event: RelayEventMap['instance-policies-updated'] = {
				user: {
					id: 'user202',
					email: 'admin5@example.com',
					firstName: 'Fifth',
					lastName: 'Admin',
					role: { slug: 'global:admin' },
				},
				settingName: '2fa_enforcement',
				value: true,
			};

			eventService.emit('instance-policies-updated', event);

			expect(eventBus.sendAuditEvent).toHaveBeenCalledWith({
				eventName: 'n8n.audit.2fa-enforcement.enabled',
				payload: {
					userId: 'user202',
					_email: 'admin5@example.com',
					_firstName: 'Fifth',
					_lastName: 'Admin',
					globalRole: 'global:admin',
				},
			});
		});

		it('should log `2fa-enforcement.disabled` when 2fa_enforcement is disabled', () => {
			const event: RelayEventMap['instance-policies-updated'] = {
				user: {
					id: 'user303',
					email: 'admin6@example.com',
					firstName: 'Sixth',
					lastName: 'Admin',
					role: { slug: 'global:admin' },
				},
				settingName: '2fa_enforcement',
				value: false,
			};

			eventService.emit('instance-policies-updated', event);

			expect(eventBus.sendAuditEvent).toHaveBeenCalledWith({
				eventName: 'n8n.audit.2fa-enforcement.disabled',
				payload: {
					userId: 'user303',
					_email: 'admin6@example.com',
					_firstName: 'Sixth',
					_lastName: 'Admin',
					globalRole: 'global:admin',
				},
			});
		});

		it('does not emit an audit event for data_redaction_enforcement_floor (telemetry-only; audit is handled by redaction-enforcement-updated)', () => {
			const event: RelayEventMap['instance-policies-updated'] = {
				user: {
					id: 'user404',
					email: 'admin7@example.com',
					firstName: 'Seventh',
					lastName: 'Admin',
					role: { slug: 'global:admin' },
				},
				settingName: 'data_redaction_enforcement_floor',
				value: 'all',
			};

			eventService.emit('instance-policies-updated', event);

			expect(eventBus.sendAuditEvent).not.toHaveBeenCalled();
		});

		it('should log `workflow-reviews.enabled` when workflow_reviews is turned on', () => {
			const event: RelayEventMap['instance-policies-updated'] = {
				user: {
					id: 'user505',
					email: 'admin8@example.com',
					firstName: 'Eighth',
					lastName: 'Admin',
					role: { slug: 'global:owner' },
				},
				settingName: 'workflow_reviews',
				value: true,
			};

			eventService.emit('instance-policies-updated', event);

			expect(eventBus.sendAuditEvent).toHaveBeenCalledWith({
				eventName: 'n8n.audit.workflow-reviews.enabled',
				payload: {
					userId: 'user505',
					_email: 'admin8@example.com',
					_firstName: 'Eighth',
					_lastName: 'Admin',
					globalRole: 'global:owner',
				},
			});
		});

		it('should log `workflow-reviews.disabled` when workflow_reviews is turned off', () => {
			const event: RelayEventMap['instance-policies-updated'] = {
				user: {
					id: 'user606',
					email: 'admin9@example.com',
					firstName: 'Ninth',
					lastName: 'Admin',
					role: { slug: 'global:admin' },
				},
				settingName: 'workflow_reviews',
				value: false,
			};

			eventService.emit('instance-policies-updated', event);

			expect(eventBus.sendAuditEvent).toHaveBeenCalledWith({
				eventName: 'n8n.audit.workflow-reviews.disabled',
				payload: {
					userId: 'user606',
					_email: 'admin9@example.com',
					_firstName: 'Ninth',
					_lastName: 'Admin',
					globalRole: 'global:admin',
				},
			});
		});
	});

	describe('workflow review events', () => {
		const reviewer = {
			id: 'user123',
			email: 'reviewer@n8n.io',
			firstName: 'Rita',
			lastName: 'Reviewer',
			role: { slug: 'global:member' },
		};
		const redactedReviewer = {
			userId: 'user123',
			_email: 'reviewer@n8n.io',
			_firstName: 'Rita',
			_lastName: 'Reviewer',
			globalRole: 'global:member',
		};

		it('should log `workflow-review.requested` with the submitted version', () => {
			eventService.emit('workflow-review-requested', {
				user: reviewer,
				workflowReviewRequestId: 'review-1',
				projectId: 'project-1',
				workflowId: 'wf-1',
				workflowVersionId: 'ver-1',
				reviewerCount: 2,
			});

			expect(eventBus.sendAuditEvent).toHaveBeenCalledWith({
				eventName: 'n8n.audit.workflow-review.requested',
				payload: {
					...redactedReviewer,
					projectId: 'project-1',
					workflowId: 'wf-1',
					versionId: 'ver-1',
					workflowReviewRequestId: 'review-1',
				},
			});
		});

		it('should log `workflow-review.version-updated` with the newly pinned version', () => {
			eventService.emit('workflow-review-version-updated', {
				user: reviewer,
				workflowReviewRequestId: 'review-1',
				workflowId: 'wf-1',
				workflowVersionId: 'ver-2',
			});

			expect(eventBus.sendAuditEvent).toHaveBeenCalledWith({
				eventName: 'n8n.audit.workflow-review.version-updated',
				payload: {
					...redactedReviewer,
					workflowId: 'wf-1',
					versionId: 'ver-2',
					workflowReviewRequestId: 'review-1',
				},
			});
		});

		it('should log `workflow-review.approved` with who was entitled to approve', () => {
			eventService.emit('workflow-review-decided', {
				user: reviewer,
				workflowReviewRequestId: 'review-1',
				workflowId: 'wf-1',
				workflowVersionId: 'ver-1',
				decision: 'approved',
				decidedVia: 'assigned-reviewer',
				reviewCreatedAt: new Date('2026-01-01T10:00:00.000Z'),
			});

			expect(eventBus.sendAuditEvent).toHaveBeenCalledWith({
				eventName: 'n8n.audit.workflow-review.approved',
				payload: {
					...redactedReviewer,
					workflowId: 'wf-1',
					versionId: 'ver-1',
					workflowReviewRequestId: 'review-1',
					decidedVia: 'assigned-reviewer',
				},
			});
		});

		// A separate name, because SIEM rules key on the event name and cannot filter on payload.
		it('should log `workflow-review.changes-requested` under its own name', () => {
			eventService.emit('workflow-review-decided', {
				user: reviewer,
				workflowReviewRequestId: 'review-1',
				workflowId: 'wf-1',
				workflowVersionId: null,
				decision: 'changes_requested',
				decidedVia: 'admin-override',
				reviewCreatedAt: new Date('2026-01-01T10:00:00.000Z'),
			});

			expect(eventBus.sendAuditEvent).toHaveBeenCalledWith({
				eventName: 'n8n.audit.workflow-review.changes-requested',
				payload: {
					...redactedReviewer,
					workflowId: 'wf-1',
					versionId: null,
					workflowReviewRequestId: 'review-1',
					decidedVia: 'admin-override',
				},
			});
		});

		it('should log `workflow-review.closed` with what made the workflow unreviewable and who caused it', () => {
			eventService.emit('workflow-review-closed', {
				workflowReviewRequestId: 'review-1',
				cause: { trigger: 'workflow-archived', actorKind: 'user', userId: 'user123' },
			});

			expect(eventBus.sendAuditEvent).toHaveBeenCalledWith({
				eventName: 'n8n.audit.workflow-review.closed',
				payload: {
					workflowReviewRequestId: 'review-1',
					causeTrigger: 'workflow-archived',
					causeActorKind: 'user',
					causeUserId: 'user123',
				},
			});
		});
	});

	describe('redaction enforcement events', () => {
		it('should log `redaction-enforcement.updated` with redacted user and before/after payload', () => {
			const event: RelayEventMap['redaction-enforcement-updated'] = {
				user: {
					id: 'user404',
					email: 'admin7@example.com',
					firstName: 'Seventh',
					lastName: 'Admin',
					role: { slug: 'global:owner' },
				},
				before: 'off',
				after: 'production',
			};

			eventService.emit('redaction-enforcement-updated', event);

			expect(eventBus.sendAuditEvent).toHaveBeenCalledWith({
				eventName: 'n8n.audit.redaction-enforcement.updated',
				payload: {
					userId: 'user404',
					_email: 'admin7@example.com',
					_firstName: 'Seventh',
					_lastName: 'Admin',
					globalRole: 'global:owner',
					before: 'off',
					after: 'production',
				},
			});
		});

		it('should log `redaction-enforcement.updated` for downgrade (all -> production)', () => {
			const event: RelayEventMap['redaction-enforcement-updated'] = {
				user: {
					id: 'user404',
					email: 'admin7@example.com',
					firstName: 'Seventh',
					lastName: 'Admin',
					role: { slug: 'global:owner' },
				},
				before: 'all',
				after: 'production',
			};

			eventService.emit('redaction-enforcement-updated', event);

			expect(eventBus.sendAuditEvent).toHaveBeenCalledWith({
				eventName: 'n8n.audit.redaction-enforcement.updated',
				payload: {
					userId: 'user404',
					_email: 'admin7@example.com',
					_firstName: 'Seventh',
					_lastName: 'Admin',
					globalRole: 'global:owner',
					before: 'all',
					after: 'production',
				},
			});
		});

		it('should log `redaction-enforcement.updated` for upgrade to `all`', () => {
			const event: RelayEventMap['redaction-enforcement-updated'] = {
				user: {
					id: 'user404',
					email: 'admin7@example.com',
					firstName: 'Seventh',
					lastName: 'Admin',
					role: { slug: 'global:owner' },
				},
				before: 'production',
				after: 'all',
			};

			eventService.emit('redaction-enforcement-updated', event);

			expect(eventBus.sendAuditEvent).toHaveBeenCalledWith({
				eventName: 'n8n.audit.redaction-enforcement.updated',
				payload: {
					userId: 'user404',
					_email: 'admin7@example.com',
					_firstName: 'Seventh',
					_lastName: 'Admin',
					globalRole: 'global:owner',
					before: 'production',
					after: 'all',
				},
			});
		});
	});

	describe('MCP server events', () => {
		it('should log on `mcp-oauth-completed` event', () => {
			const event: RelayEventMap['mcp-oauth-completed'] = {
				userId: 'user-mcp-1',
				clientId: 'client-abc',
				clientName: 'Claude',
			};

			eventService.emit('mcp-oauth-completed', event);

			expect(eventBus.sendMcpEvent).toHaveBeenCalledWith({
				eventName: 'n8n.audit.mcp.oauth.completed',
				payload: {
					userId: 'user-mcp-1',
					clientId: 'client-abc',
					clientName: 'Claude',
				},
			});
		});

		it('should log on `mcp-tool-called` event with redacted user and target workflow', () => {
			const event: RelayEventMap['mcp-tool-called'] = {
				user: {
					id: 'user-mcp-2',
					email: 'mcp@n8n.io',
					firstName: 'Em',
					lastName: 'Cp',
					role: { slug: 'global:member' },
				},
				toolName: 'execute_workflow',
				workflowId: 'wf-789',
				status: 'success',
				authType: 'oauth',
				clientId: 'client-abc',
				clientName: 'Cursor',
			};

			eventService.emit('mcp-tool-called', event);

			expect(eventBus.sendMcpEvent).toHaveBeenCalledWith({
				eventName: 'n8n.audit.mcp.tool.called',
				payload: {
					userId: 'user-mcp-2',
					_email: 'mcp@n8n.io',
					_firstName: 'Em',
					_lastName: 'Cp',
					globalRole: 'global:member',
					toolName: 'execute_workflow',
					workflowId: 'wf-789',
					status: 'success',
					errorMessage: undefined,
					authType: 'oauth',
					clientId: 'client-abc',
					clientName: 'Cursor',
				},
			});
		});

		it('should log on `mcp-tool-called` event with error status', () => {
			const event: RelayEventMap['mcp-tool-called'] = {
				user: {
					id: 'user-mcp-3',
					email: 'err@n8n.io',
					firstName: 'Er',
					lastName: 'Ror',
					role: { slug: 'global:member' },
				},
				toolName: 'get_workflow_details',
				status: 'error',
				errorMessage: 'Workflow not found',
				authType: 'api_key',
			};

			eventService.emit('mcp-tool-called', event);

			expect(eventBus.sendMcpEvent).toHaveBeenCalledWith({
				eventName: 'n8n.audit.mcp.tool.called',
				payload: {
					userId: 'user-mcp-3',
					_email: 'err@n8n.io',
					_firstName: 'Er',
					_lastName: 'Ror',
					globalRole: 'global:member',
					toolName: 'get_workflow_details',
					workflowId: undefined,
					status: 'error',
					errorMessage: 'Workflow not found',
					// An API-key caller has no OAuth client and reports no name
					authType: 'api_key',
					clientId: undefined,
					clientName: undefined,
				},
			});
		});

		it('should log on `mcp-access-updated` event with redacted user', () => {
			const event: RelayEventMap['mcp-access-updated'] = {
				user: {
					id: 'user-mcp-4',
					email: 'owner@n8n.io',
					firstName: 'Own',
					lastName: 'Er',
					role: { slug: 'global:owner' },
				},
				enabled: false,
			};

			eventService.emit('mcp-access-updated', event);

			expect(eventBus.sendMcpEvent).toHaveBeenCalledWith({
				eventName: 'n8n.audit.mcp.access.updated',
				payload: {
					userId: 'user-mcp-4',
					_email: 'owner@n8n.io',
					_firstName: 'Own',
					_lastName: 'Er',
					globalRole: 'global:owner',
					enabled: false,
				},
			});
		});
	});
});
