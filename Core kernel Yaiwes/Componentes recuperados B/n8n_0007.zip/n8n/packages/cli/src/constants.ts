import { Time } from '@n8n/constants';
import { readFileSync, statSync } from 'fs';
import type { n8n } from 'n8n-core';
import type { ITaskDataConnections } from 'n8n-workflow';
import {
	ERROR_TRIGGER_NODE_TYPE,
	EXECUTE_WORKFLOW_TRIGGER_NODE_TYPE,
	jsonParse,
	TRIMMED_TASK_DATA_CONNECTIONS_KEY,
} from 'n8n-workflow';
import { resolve, join, dirname } from 'path';

const { E2E_TESTS } = process.env;
export const inE2ETests = E2E_TESTS === 'true';

export const CUSTOM_API_CALL_NAME = 'Custom API Call';
export const CUSTOM_API_CALL_KEY = '__CUSTOM_API_CALL__';

export const CLI_DIR = resolve(__dirname, '..');
export const AI_ASSISTANT_SDK_DIR = dirname(dirname(require.resolve('@n8n_io/ai-assistant-sdk')));
export const TEMPLATES_DIR = join(CLI_DIR, 'templates');
export const NODES_BASE_DIR = dirname(require.resolve('n8n-nodes-base'));
export const EDITOR_UI_DIST_DIR = join(dirname(require.resolve('n8n-editor-ui')), 'dist');

const packageJsonPath = join(CLI_DIR, 'package.json');
const aiAssistantPackageJsonPath = join(AI_ASSISTANT_SDK_DIR, 'package.json');
const workflowSdkPackageJsonPath = require.resolve('@n8n/workflow-sdk/package.json');
const n8nPackageJson = jsonParse<n8n.PackageJson>(readFileSync(packageJsonPath, 'utf8'));
const aiAssistantPackageJson = jsonParse<n8n.PackageJson>(
	readFileSync(aiAssistantPackageJsonPath, 'utf8'),
);
const workflowSdkPackageJson = jsonParse<n8n.PackageJson>(
	readFileSync(workflowSdkPackageJsonPath, 'utf8'),
);
export const N8N_VERSION = n8nPackageJson.version;
export const AI_ASSISTANT_SDK_VERSION = aiAssistantPackageJson.version;
export const WORKFLOW_SDK_VERSION = workflowSdkPackageJson.version;
export const N8N_RELEASE_DATE = statSync(packageJsonPath).mtime;

export const STARTING_NODES = [
	'@n8n/n8n-nodes-langchain.manualChatTrigger',
	'n8n-nodes-base.manualTrigger',
];

export const TRIGGER_COUNT_EXCLUDED_NODES = [
	EXECUTE_WORKFLOW_TRIGGER_NODE_TYPE,
	ERROR_TRIGGER_NODE_TYPE,
];

export const MCP_TRIGGER_NODE_TYPE = '@n8n/n8n-nodes-langchain.mcpTrigger';

export const NODE_PACKAGE_PREFIX = 'n8n-nodes-';

export const STARTER_TEMPLATE_NAME = `${NODE_PACKAGE_PREFIX}starter`;

export const RESPONSE_ERROR_MESSAGES = {
	NO_CREDENTIAL: 'Credential not found',
	NO_NODE: 'Node not found',
	PACKAGE_NAME_NOT_PROVIDED: 'Package name is required',
	PACKAGE_NAME_NOT_VALID: `Package name is not valid - it must start with "${NODE_PACKAGE_PREFIX}"`,
	PACKAGE_NOT_INSTALLED: 'This package is not installed - you must install it first',
	PACKAGE_FAILED_TO_INSTALL: 'Package could not be installed - check logs for details',
	PACKAGE_NOT_FOUND: 'Package not found in npm',
	PACKAGE_VERSION_NOT_FOUND: 'The specified package version was not found',
	PACKAGE_DOES_NOT_CONTAIN_NODES: 'The specified package does not contain any nodes',
	PACKAGE_LOADING_FAILED: 'The specified package could not be loaded',
	DISK_IS_FULL: 'There appears to be insufficient disk space',
	USERS_QUOTA_REACHED: 'Maximum number of users reached',
	OAUTH2_CREDENTIAL_TEST_SUCCEEDED: 'Connection Successful!',
	OAUTH2_CREDENTIAL_TEST_FAILED: 'This OAuth2 credential was not connected to an account.',
	MISSING_SCOPE: 'User is missing a scope required to perform this action',
} as const;

export const AUTH_COOKIE_NAME = 'n8n-auth';
export const OIDC_STATE_COOKIE_NAME = 'n8n-oidc-state';
export const OIDC_NONCE_COOKIE_NAME = 'n8n-oidc-nonce';

/**
 * Cookies the Form nodes set on their own pages, duplicated here because the
 * names are owned by `nodes-base/nodes/Form/utils/utils.ts`
 * (`FORM_AUTH_COOKIE_PREFIX` / `FORM_OAUTH_COOKIE_NAME`) and this package must
 * not reach into that package's internals. Keep both sides in step. The form
 * auth cookie's full name appends the workflow or execution it was minted for
 * (`<prefix>-wf-<id>` / `<prefix>-ex-<id>`), so concurrent forms don't
 * overwrite each other's cookie.
 */
export const FORM_AUTH_COOKIE_PREFIX = 'n8n-form-auth';
export const FORM_OAUTH_COOKIE_NAME = 'n8n-form-oauth';

export const NPM_COMMAND_TOKENS = {
	NPM_PACKAGE_NOT_FOUND_ERROR: '404 Not Found',
	NPM_PACKAGE_VERSION_NOT_FOUND_ERROR: 'No matching version found for',
	NPM_NO_VERSION_AVAILABLE: 'No valid versions available',
	NPM_DISK_NO_SPACE: 'ENOSPC',
	NPM_DISK_INSUFFICIENT_SPACE: 'insufficient space',
} as const;

export const NPM_PACKAGE_STATUS_GOOD = 'OK';

export const UNKNOWN_FAILURE_REASON = 'Unknown failure reason';

export const WORKFLOW_REACTIVATE_INITIAL_TIMEOUT = 1000; // 1 second
export const WORKFLOW_REACTIVATE_MAX_TIMEOUT = 24 * 60 * 60 * 1000; // 1 day

/** Max in-process attempts to activate a single trigger node before recording it as failed. */
export const TRIGGER_ACTIVATION_MAX_ATTEMPTS = 5;

/** Max in-process attempts to externally deregister a single webhook before abandoning it. */
export const TRIGGER_TEARDOWN_MAX_ATTEMPTS = 3;

/** Base delay between external webhook deregistration attempts; doubles per attempt. */
export const TRIGGER_TEARDOWN_RETRY_INITIAL_DELAY_MS = 1000;

export const SETTINGS_LICENSE_CERT_KEY = 'license.cert';

export const UM_FIX_INSTRUCTION =
	'Please fix the database by running ./packages/cli/bin/n8n user-management:reset';

export const TEST_WEBHOOK_TIMEOUT = 2 * Time.minutes.toMilliseconds;

export const TEST_WEBHOOK_TIMEOUT_BUFFER = 30 * Time.seconds.toMilliseconds;

export const GENERIC_OAUTH2_CREDENTIALS_WITH_EDITABLE_SCOPE = [
	'oAuth2Api',
	'googleOAuth2Api',
	'microsoftOAuth2Api',
	'atlassianOAuth2Api',
	'highLevelOAuth2Api',
	'mcpOAuth2Api',
	'snowflakeOAuth2Api',
	'facebookGraphApiOAuth2Api',
	'facebookGraphAppOAuth2Api',
	'stravaOAuth2Api',
	'wordpressOAuth2Api',
	'figmaOAuth2Api',
	'gumroadOAuth2Api',
	'googleCloudStorageOAuth2Api',
	'googleCalendarOAuth2Api',
	'googleSheetsOAuth2Api',
	'googleBigQueryOAuth2Api',
	'zendeskOAuth2Api',
	'gmailOAuth2',
	'gSuiteAdminOAuth2Api',
	'googleAdsOAuth2Api',
	'googleAnalyticsOAuth2',
	'googleBooksOAuth2Api',
	'googleBusinessProfileOAuth2Api',
	'googleChatOAuth2Api',
	'googleCloudNaturalLanguageOAuth2Api',
	'googleContactsOAuth2Api',
	'googleDocsOAuth2Api',
	'googleDriveOAuth2Api',
	'googleFirebaseCloudFirestoreOAuth2Api',
	'googleFirebaseRealtimeDatabaseOAuth2Api',
	'googlePerspectiveOAuth2Api',
	'googleSheetsTriggerOAuth2Api',
	'googleSlidesOAuth2Api',
	'googleTasksOAuth2Api',
	'googleTranslateOAuth2Api',
	'youTubeOAuth2Api',
	'typeformOAuth2Api',
];

export const ARTIFICIAL_TASK_DATA = {
	main: [
		[
			{
				json: { isArtificialRecoveredEventItem: true },
				pairedItem: undefined,
			},
		],
	],
};

/**
 * Connections for an item standing in for a manual execution data item too
 * large to be sent live via pubsub. This signals to the client to direct the
 * user to the execution history.
 */
export const TRIMMED_TASK_DATA_CONNECTIONS: ITaskDataConnections = {
	main: [
		[
			{
				json: { [TRIMMED_TASK_DATA_CONNECTIONS_KEY]: true },
				pairedItem: undefined,
			},
		],
	],
};

/** Lowest priority, meaning shut down happens after other groups */
export const LOWEST_SHUTDOWN_PRIORITY = 0;
export const DEFAULT_SHUTDOWN_PRIORITY = 100;
/** Highest priority, meaning shut down happens before all other groups */
export const HIGHEST_SHUTDOWN_PRIORITY = 200;

export const WsStatusCodes = {
	CloseNormal: 1000,
	CloseGoingAway: 1001,
	CloseProtocolError: 1002,
	CloseUnsupportedData: 1003,
	CloseAbnormal: 1006,
	CloseInvalidData: 1007,
} as const;

export const FREE_AI_CREDITS_CREDENTIAL_NAME = 'n8n free OpenAI API credits';

export const STREAM_SEPARATOR = '⧉⇋⇋➽⌑⧉§§\n';
