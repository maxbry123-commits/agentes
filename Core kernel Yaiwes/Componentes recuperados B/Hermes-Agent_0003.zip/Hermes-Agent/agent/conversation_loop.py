"""The agent conversation loop — extracted from ``run_agent.AIAgent``.

This is the biggest single chunk pulled out of ``run_agent.py``: the
roughly 3,900-line :func:`run_conversation` body that drives one user
turn through the agent (model call, tool dispatch, retries, fallbacks,
compression, post-turn hooks, background memory/skill review nudges).

The function takes the parent ``AIAgent`` instance as its first
argument (``agent``) and accesses its state via attribute lookup.
``_ra().AIAgent.run_conversation`` is now a thin forwarder.

Symbols that production code or tests patch on ``run_agent`` directly
(``handle_function_call``, ``_set_interrupt``, ``OpenAI``, ...) are
resolved through :func:`_ra` so those patches keep working.
"""

from __future__ import annotations

import json
import logging
import os
import random
import re
import ssl
import sys
import time
from typing import Any, Dict, List, Optional

from agent.codex_responses_adapter import _summarize_user_message_for_log
from agent.conversation_compression import (
    COMPRESSION_RETRY_CONTEXT_REDUCED_STATUS_TEMPLATE,
    COMPRESSION_RETRY_MESSAGES_STATUS_TEMPLATE,
    COMPRESSION_RETRY_TOKENS_STATUS_TEMPLATE,
    COMPRESSION_RETRY_TOO_LARGE_STATUS_TEMPLATE,
    PRE_API_COMPRESSION_STATUS_TEMPLATE,
    compression_blocked_transiently,
    compression_skipped_due_to_lock,
    context_compression_timed_out,
    conversation_history_after_compression,
)
from agent.context_engine import automatic_compaction_status_message
from agent.display import KawaiiSpinner
from agent.error_classifier import FailoverReason, classify_api_error
from agent.message_metadata import append_message
from agent.turn_context import (
    PreflightCompressionTimedOut,
    _compression_warrants_another_preflight_pass,
    _review_fork_first_request_pending,
    build_turn_context,
    compose_user_api_content,
    reanchor_current_turn_user_idx,
)
from agent.turn_retry_state import TurnRetryState
from agent.runtime_cwd import resolve_agent_cwd
from agent.message_sanitization import (
    close_interrupted_tool_sequence,
    _repair_tool_call_arguments,
    coalesce_tool_call_id,
    _sanitize_messages_non_ascii,
    _sanitize_messages_surrogates,
    _sanitize_structure_non_ascii,
    _sanitize_structure_surrogates,
    _sanitize_surrogates,
    _sanitize_tools_non_ascii,
    _looks_like_image_content_rejection,
    _strip_images_from_messages,
    _strip_non_ascii,
    serialized_messages_bytes,
)
# Must mirror _STALE_TOOL_CALL_MARKER_RE in hermes_state.py — kept local
# to avoid importing hermes_state at module load time (its module-level
# DEFAULT_DB_PATH = get_hermes_home() / "state.db" breaks tests that
# monkeypatch get_hermes_home to return a str).
_STALE_MARKER_RE = re.compile(r"^\[[A-Za-z_][A-Za-z0-9_.-]*\]$")
from agent.model_metadata import (
    MINIMUM_CONTEXT_LENGTH,
    _estimate_tools_tokens_rough,
    anchored_context_tokens,
    capture_usage_anchor,
    estimate_messages_tokens_rough,
    estimate_request_tokens_rough,
    get_context_length_from_provider_error,
    is_output_cap_error,
    parse_available_output_tokens_from_error,
    save_context_length,
)
from agent.process_bootstrap import _install_safe_stdio
from agent.prompt_caching import (
    build_prompt_cache_plan,
    effective_cache_ttl,
    strip_anthropic_cache_control,
    strip_anthropic_tool_cache_control,
)
from agent.provider_projection import splice_provider_projection
from agent.retry_utils import (
    adaptive_rate_limit_backoff,
    is_zai_coding_overload_error,
    jittered_backoff,
    zai_coding_overload_retry_ceiling,
)
from agent.repetition_guard import is_repetition_dominated
from agent.trajectory import has_incomplete_scratchpad
# Bind before the turn starts so a source-tree swap cannot load a skewed
# finalizer at turn end.
from agent.turn_finalizer import finalize_turn
from agent.usage_pricing import estimate_usage_cost, normalize_usage
from agent import empty_response_guard as _empty_guard
from hermes_constants import PARTIAL_STREAM_STUB_ID
from hermes_logging import set_session_context
from tools.skill_provenance import set_current_write_origin
from utils import base_url_host_matches, env_var_enabled

logger = logging.getLogger(__name__)


# Scaffold marker used by _apply_active_turn_redirect and the ghost-row filter
# in the api_messages loop. Module-level so both sites can never drift.
_INTERRUPT_SCAFFOLD_MARKER = "[This response was interrupted by a user correction.]"


# One-time wrap-up notice appended when a wall-clock run budget crosses its
# 80% threshold (agent.run_budget_seconds / --run-budget). Mirrors the Codex
# CLI budget wrap-up template: stop new work, deliver from current state.
RUN_BUDGET_WRAPUP_NOTICE = (
    "[SYSTEM NOTICE — run time budget nearly exhausted] "
    "Run time budget nearly exhausted. Stop new discovery/verification work "
    "now. Produce the required final deliverable (answer/JSON/summary) from "
    "the state you already have, completing only mandatory writes."
)


def _midturn_request_pressure_tokens(
    agent: Any,
    api_messages: List[Dict[str, Any]],
    effective_system: str,
    approx_tokens: int,
) -> int:
    """Token figure the mid-turn pre-API compression guard compares.

    When the upcoming request is eligible for native Responses compaction the
    transport will checkpoint-prune the payload before sending, so the generic
    durable-history estimate overstates the wire by orders of magnitude on a
    compacted session and fires a 600s local compression the main request
    never needed (#96995). Mirror the turn-prologue preflight (#96644 /
    #96155): use the pruned estimate when native eligibility is proven, the
    generic message+tools figure otherwise.

    The native estimator adds the system prompt and tool schemas itself and
    its converter skips system-role rows, so passing the assembled
    ``api_messages`` (which carries the system row) alongside
    ``effective_system`` counts the system prompt exactly once.
    """
    try:
        from agent.codex_responses_adapter import (
            estimate_native_responses_preflight_tokens,
        )

        native = estimate_native_responses_preflight_tokens(
            agent,
            api_messages,
            system_prompt=effective_system or "",
            tools=getattr(agent, "tools", None) or None,
        )
        if isinstance(native, int) and not isinstance(native, bool) and native >= 0:
            return native
    except Exception:
        logger.debug(
            "native Responses mid-turn estimate unavailable; "
            "using generic transcript estimate",
            exc_info=True,
        )
    return approx_tokens + (
        _estimate_tools_tokens_rough(agent.tools) if agent.tools else 0
    )


def _review_input_budget_exhausted(agent: Any) -> bool:
    """True when a detached review fork has replayed its aggregate input budget.

    Only forks carrying an explicit ``_review_input_token_budget`` (the
    background-review path, #93057) are gated; every other agent returns
    False and is unaffected. ``session_input_tokens`` accumulates from
    provider usage after each response, so the check fires at the top of the
    NEXT tool-loop iteration — the budget-crossing request is admitted and
    completes (its tool writes land), then the loop stops before any further
    provider call. This caps the review's total replayed input, complementing
    the per-request bound provided by detached in-memory compaction and the
    ``_REVIEW_MAX_ITERATIONS`` iteration cap.
    """
    budget = getattr(agent, "_review_input_token_budget", None)
    if not isinstance(budget, int) or isinstance(budget, bool) or budget <= 0:
        return False
    used = getattr(agent, "session_input_tokens", 0)
    return isinstance(used, int) and not isinstance(used, bool) and used >= budget


def _maybe_inject_run_budget_wrapup(agent: Any, messages: List[Dict[str, Any]]) -> bool:
    """Inject the one-time wall-clock wrap-up notice when past 80% of budget.

    Cache-safe delivery: the notice is appended to the NEWEST ``role:"tool"``
    message (the same channel /steer uses) — no synthetic user message is
    inserted mid-loop and no past context is rewritten, so role alternation
    and the prompt-cache prefix survive.  Latches ``_run_budget_wrapup_injected``
    only on a successful append, so a first iteration without tool results
    retries on the next iteration.  Returns True when the notice was injected.

    Dormant unless ``agent.run_budget_seconds`` is set AND the turn stamped
    ``_run_budget_started_at`` (see ``turn_context.prepare_conversation_turn``).
    """
    budget = getattr(agent, "run_budget_seconds", None)
    if not budget:
        return False
    if getattr(agent, "_run_budget_wrapup_injected", False):
        return False
    started = getattr(agent, "_run_budget_started_at", None)
    if not started:
        return False
    if (time.time() - started) < 0.8 * float(budget):
        return False
    for i in range(len(messages) - 1, -1, -1):
        msg = messages[i]
        if isinstance(msg, dict) and msg.get("role") == "tool":
            existing = msg.get("content", "")
            if isinstance(existing, str):
                msg["content"] = existing + f"\n\n{RUN_BUDGET_WRAPUP_NOTICE}"
            else:
                # Multimodal content blocks — append a text block.
                try:
                    blocks = list(existing) if existing else []
                    blocks.append({"type": "text", "text": RUN_BUDGET_WRAPUP_NOTICE})
                    msg["content"] = blocks
                except Exception:
                    return False
            agent._run_budget_wrapup_injected = True
            logger.info(
                "Run budget wrap-up notice injected (budget=%.0fs, elapsed=%.0fs)",
                float(budget),
                time.time() - started,
            )
            return True
    return False


def _restore_user_after_reference_handoff(
    messages: List[Dict[str, Any]], user_message: Any
) -> bool:
    """Re-append this turn's real user ask when compaction left only a handoff.

    Returns True when a restore append happened. The caller has already
    established that a reference-only handoff would drive the next model
    call (#80622); this helper only decides whether a restorable ask exists.
    """
    if user_message is None:
        return False
    if isinstance(user_message, str):
        if not user_message.strip():
            return False
        content: Any = user_message
    elif isinstance(user_message, list):
        if not user_message:
            return False
        content = user_message
    else:
        return False
    if (
        messages
        and isinstance(messages[-1], dict)
        and messages[-1].get("role") == "user"
        and messages[-1].get("content") == content
    ):
        return False
    append_message(messages, {"role": "user", "content": content})
    return True


def _should_skip_model_call_for_reference_handoff(
    messages: List[Dict[str, Any]], user_message: Any
) -> bool:
    """Guard post-compaction continues against sole-handoff active turns (#80622)."""
    from agent.context_compressor import reference_handoff_would_drive_next_model_call

    if not reference_handoff_would_drive_next_model_call(messages):
        return False
    if _restore_user_after_reference_handoff(messages, user_message):
        # The restored ask is an actionable non-synthetic user row appended
        # after the handoff — by construction the handoff no longer drives.
        return False
    return True


# Fallback final_response for a turn ended by the sole-handoff skip (#80622).
# Deliberately NOT a replay of the last assistant text: finalize_turn's
# non-assistant-tail chokepoint (#43849) appends final_response as a fresh
# assistant row, so recovering the previous turn's prose here would duplicate
# it in the durable transcript AND re-deliver it to the user as if it were
# this turn's answer. A short status is honest and idempotent.
_HANDOFF_SKIP_FINAL_RESPONSE = (
    "Context was compacted. The previous response is complete — "
    "awaiting your next message."
)

# Terminal final_response for a turn ended because context compression hit its
# host progress-aware timeout while the request was still oversized (#98722,
# salvaged from #98741). Sending the unchanged request would only bounce off
# the provider's overflow error and re-enter compression in the same turn.
_COMPRESSION_TIMEOUT_FINAL_RESPONSE = (
    "Context compression timed out without reducing this conversation. "
    "No messages were dropped. Start a fresh session with /new, or check "
    "auxiliary.compression before retrying /compress."
)


# Stable prefix of the local interrupt status string emitted when a turn is
# cancelled while waiting on the provider. Surfaces (ACP, TUI) match on this
# to treat it as cancellation metadata rather than assistant prose.
INTERRUPT_WAITING_FOR_MODEL_PREFIX = "Operation interrupted: waiting for model response ("


def _should_rearm_compression_budget(
    compression_attempts: int,
    *,
    completed_compaction_pending: bool,
    prompt_tokens: int,
    threshold_tokens: int,
) -> bool:
    """Return True after a provider proves a completed compaction worked.

    Rough estimates cannot safely rearm the anti-thrash budget: they can dip
    below the threshold while the provider-visible prompt remains too large.
    Require the completed-compaction latch plus a positive, normalized prompt
    count below the threshold from the next successful provider response.
    """
    return bool(
        compression_attempts
        and completed_compaction_pending
        and threshold_tokens > 0
        and 0 < prompt_tokens < threshold_tokens
    )


# Modules that indicate a deterministic local processing error when they
# appear in an exception traceback WITHOUT any API-call module. Used by the
# outer-loop error classifier to avoid retrying bugs that will fail
# identically every time (e.g. TypeError from passing list content into a
# regex helper).  IMPORTANT: do NOT include "conversation_loop" or
# "run_agent" here — those are the container modules for the try/except
# itself, so every exception passes through them, which would make
# _hit_local always True and misclassify transient API/network errors as
# non-retryable local bugs. (#66267)
_LOCAL_PROCESSING_MODULES = frozenset({
    "agent_runtime_helpers",
    "message_content",
    "message_sanitization",
    "chat_completion_helpers",  # only local when NOT also an API-call module
})
_API_CALL_MODULES = frozenset({
    "chat_completion_helpers",
})

# Maximum total outer-loop exceptions tolerated within one user turn before
# the loop gives up (#92450). The turn budget is unlimited by default
# (``max_iterations = sys.maxsize``), so the historical "near the limit"
# guard no longer stops a turn whose outer loop keeps raising: permanent
# failures spun at ~64 retries/s, pegged a core, and overwrote the rotated
# agent.log history (days of diagnostic context) within minutes. The inner
# retry/fallback machinery owns transient API recovery and terminates on its
# own; only exceptions that ESCAPE it reach this bound, so the cap can be
# small. Still scaled down by a tiny explicit ``max_iterations`` so a
# manually bounded budget keeps governing.
_MAX_OUTER_LOOP_ERRORS = 8


def _is_interpreter_shutdown_error(exc: Exception) -> bool:
    """Check if *exc* is a fatal interpreter-shutdown failure.

    During teardown, ``concurrent.futures`` refuses new work with
    ``RuntimeError: cannot schedule new futures after interpreter shutdown``
    (or the shorter ``... after shutdown`` variant from a plain
    ThreadPoolExecutor).  Both are documented in #58720.

    Delegates to the shared predicate in ``tools.interpreter_shutdown``
    (same home as cron delivery and concurrent tool submission) so the
    shutdown-race bug class has one text-matching site. Keeps the
    RuntimeError type gate from the original (#93269): unlike the raw
    predicate, a ValueError carrying similar text must not match here.
    """
    if isinstance(exc, RuntimeError):
        from tools.interpreter_shutdown import interpreter_shutting_down

        return interpreter_shutting_down(exc)
    return False


def _moa_client_consumes_prepared_request(client: Any) -> bool:
    """True when ``client`` is the in-process MoA facade.

    ``_moa_prepared_request`` is a private handshake with
    ``MoAChatCompletions.create``, and only that facade exposes ``prepare()``.
    Every other chat-completions object raises TypeError on the unexpected
    keyword — including the native OpenAI client that credential rotation,
    provider fallback and dead-connection cleanup rebuild from
    ``_client_kwargs`` while ``agent.provider`` stays ``"moa"``.
    """
    completions = getattr(getattr(client, "chat", None), "completions", None)
    return callable(getattr(completions, "prepare", None))


def _join_truncated_parts(parts: List[str]) -> str:
    """Join continuation fragments, adding a newline where two would glue together (#78577)."""
    joined = ""
    for part in parts:
        if joined and not joined[-1].isspace() and part and not part[0].isspace():
            joined += "\n"
        joined += part
    return joined


def _moa_reference_metrics_for_hook(agent: Any) -> Any:
    """Per-advisor metrics for post_api_request, or None off the MoA path.

    MoA runs N advisor models before its aggregator and returns only the
    aggregator's response, so an observability plugin sees one generation for
    the whole fan-out. The advisor spend is already computed per slot (see
    ``_RefAccounting``); this only carries it across the hook boundary.
    """
    client = getattr(agent, "client", None)
    getter = getattr(client, "last_reference_metrics", None)
    if not callable(getter):
        return None
    try:
        return getter()
    except Exception:
        return None


def _apply_active_turn_redirect(agent: Any, messages: List[Dict[str, Any]], text: str) -> None:
    """Append a provider-safe checkpoint and correction to the live turn.

    Incomplete provider reasoning blocks are not valid replay items (Anthropic
    signs them; Responses reasoning items require their following output).
    Preserve only the *visible* response text, demoted to ordinary text, then
    add the correction as a real user message. This keeps role alternation
    valid and leaves every previously cached message byte-for-byte unchanged.

    INVARIANT — raw chain-of-thought must never be serialized into replayable
    message content. Streamed reasoning is display-only state: it may be shown
    live, but it does not re-enter the transcript as assistant (or user) text.
    An assistant turn whose content inlines its own chain-of-thought reads to
    Anthropic's output classifier as reasoning-injection/prefill jailbreak,
    and because the poisoned checkpoint is persisted and replayed on every
    subsequent call, the session dies permanently with deterministic
    "Provider returned an empty response" storms that no retry, nudge, or
    empty-recovery branch can escape (July 2026: four sessions bricked this
    way; every reasoning-free checkpoint that week was untouched — same
    mechanism as the ~/.hermes/prefill.json incident, 20/20 blocked with
    assistant-exposed CoT vs 0/20 without). The interrupted reasoning was
    incomplete by definition; the model regenerates it on the retried turn.
    If a future path needs to preserve interrupted thinking, carry it in a
    provider-gated reasoning *field*, never in content.
    INVARIANT — the scaffolding is provider-replay text, not transcript text.
    ``[This response was interrupted by a user correction.]`` and its
    ``Visible response before the interruption:`` header exist so the MODEL
    understands its own reply was cut off. They are not prose the user wrote
    or the agent said. Persisting them into an assistant row's ``content`` or
    ``api_content`` made the model treat the scaffold as *its own previous
    reply*, echo it, and self-replicate ghost rows across turns (#81841).
    Carry the scaffolded form only in the *user correction's* ``api_content``
    sidecar — never on the placeholder assistant row. When nothing was on
    screen the placeholder is marked ``display_kind="hidden"`` (empty
    content) so every transcript surface drops it, exactly like
    compaction-reference rows.
    """
    visible = agent._strip_think_blocks(
        getattr(agent, "_current_streamed_assistant_text", "") or ""
    ).strip()

    checkpoint_parts = [_INTERRUPT_SCAFFOLD_MARKER]
    if visible:
        checkpoint_parts.extend(
            ["Visible response before the interruption:", visible]
        )
    checkpoint = "\n\n".join(checkpoint_parts)
    correction = (
        "[Context from the interrupted assistant response]\n"
        f"{checkpoint}\n\n"
        f"{text}"
    )

    # The normal live tail is user or tool, so an assistant placeholder
    # followed by the correction preserves strict alternation. If a transport
    # already committed an assistant item, attribute the checkpoint inside the
    # user correction instead of creating assistant→assistant.
    if messages and messages[-1].get("role") == "assistant":
        # Transcript shows the user's own words; the provider replays the
        # scaffolded form so it still sees the interrupted context.
        append_message(
            messages,
            {"role": "user", "content": text, "api_content": correction},
        )
    else:
        # Placeholder preserves role alternation only. Scaffold bytes must
        # never land here — the API replay path substitutes api_content back
        # into content, and a scaffold-as-assistant-reply is what the model
        # then echoes (#81841 / incomplete #73146 else branch).
        placeholder: Dict[str, Any] = {
            "role": "assistant",
            "content": visible or "",
        }
        if not visible:
            placeholder["display_kind"] = "hidden"
            # Keep the transcript hidden and empty, but give the historical
            # API projection a non-empty neutral assistant turn so the
            # pre-call sanitizer (repair_empty_non_final_messages) does not
            # re-heal this row on every later call (#88955). display_kind is
            # stripped before sanitization, while api_content is projected
            # back into content for historical assistant rows. Use the
            # canonical neutral interruption placeholder, never
            # _INTERRUPT_SCAFFOLD_MARKER: replaying the scaffold as assistant
            # text made the model echo it and self-replicate ghost rows
            # (#81841).
            from agent.agent_runtime_helpers import _INTERRUPTED_PLACEHOLDER

            placeholder["api_content"] = _INTERRUPTED_PLACEHOLDER
        append_message(messages, placeholder)
        append_message(
            messages,
            {"role": "user", "content": text, "api_content": correction},
        )

    agent._current_streamed_assistant_text = ""
    agent._stream_needs_break = True


def _is_copilot_provider(agent: Any) -> bool:
    """Delegate to ``AIAgent._is_copilot_provider`` (single owner of the check).

    ``agent.provider`` is not always the normalized ``copilot`` slug —
    ``/model`` and profile configs can leave the alias ``github-copilot`` (or
    ``github``) in place, and a bare ``provider == "copilot"`` gate silently
    skips credential recovery for those spellings.
    """
    try:
        return bool(agent._is_copilot_provider())
    except Exception:
        return (getattr(agent, "provider", "") or "").strip().lower() in {
            "copilot",
            "github-copilot",
            "github",
        }


def _is_stale_copilot_credential_error(status_code: Optional[int], error_message: str) -> bool:
    """Detect a Copilot 400 that is really a STALE / DEGRADED credential.

    Copilot surfaces a stale or degraded credential as an HTTP 400 rather than a
    clean 401. Two body markers indicate this class:

    - ``model_not_available_for_integrator`` — the request reached the
      restricted ``copilot-language-server`` integrator (the server's fallback
      when it receives a raw OAuth token instead of an exchanged API token),
      whose model allowlist omits enterprise-only models.
    - ``model_not_supported`` / "the requested model is not supported" — the
      cached bearer's Copilot entitlement rotated out from under a long-lived
      process.

    Matched narrowly (status 400 AND a specific marker) so a genuinely wrong
    model name — a real 400 — never triggers the single-shot re-exchange. The
    caller enforces copilot-provider scoping and the single-shot guard.
    """
    lowered = (error_message or "").lower()
    is_400 = status_code == 400 or "error code: 400" in lowered
    if not is_400:
        return False
    return (
        "model_not_available_for_integrator" in lowered
        or "not available for integrator" in lowered
        or "model_not_supported" in lowered
        or "the requested model is not supported" in lowered
    )


def _image_error_max_dimension(error: Exception) -> Optional[int]:
    """Extract a provider-reported image dimension ceiling, if present."""
    parts = []
    for value in (
        error,
        getattr(error, "message", None),
        getattr(error, "body", None),
    ):
        if value:
            try:
                parts.append(str(value))
            except Exception:
                pass
    text = " ".join(parts).lower()
    if "image" not in text or "dimension" not in text or "max allowed size" not in text:
        return None

    match = re.search(r"max allowed size(?:\s+for [^:]+)?:\s*(\d{3,5})\s*pixels?", text)
    if not match:
        return None
    try:
        max_dimension = int(match.group(1))
    except ValueError:
        return None
    if 512 <= max_dimension <= 8000:
        return max_dimension
    return None


def _ollama_context_limit_error(agent: Any, request_tokens: int) -> Optional[str]:
    """Return a user-facing error when Ollama is loaded with too little context."""
    if not getattr(agent, "tools", None):
        return None

    runtime_ctx = getattr(agent, "_ollama_num_ctx", None)
    if not isinstance(runtime_ctx, int) or runtime_ctx <= 0:
        return None
    if runtime_ctx >= MINIMUM_CONTEXT_LENGTH:
        return None

    model = getattr(agent, "model", "") or "the selected model"
    base_url = getattr(agent, "base_url", "") or "unknown base URL"
    provider = getattr(agent, "provider", "") or "unknown"
    tool_count = len(getattr(agent, "tools", None) or [])

    logger.warning(
        "Ollama runtime context too small for Hermes tool use: "
        "model=%s provider=%s base_url=%s runtime_context=%d "
        "minimum_context=%d estimated_request_tokens=%d tool_count=%d "
        "session=%s",
        model,
        provider,
        base_url,
        runtime_ctx,
        MINIMUM_CONTEXT_LENGTH,
        request_tokens,
        tool_count,
        getattr(agent, "session_id", None) or "none",
    )

    return (
        f"Ollama loaded `{model}` with only {runtime_ctx:,} tokens of runtime "
        f"context, but Hermes needs at least {MINIMUM_CONTEXT_LENGTH:,} tokens "
        "for reliable tool use.\n\n"
        "Increase the Ollama context for this model and restart/reload the "
        "model before trying again. A known-good starting point is 65,536 "
        "tokens. In Hermes config, set `model.ollama_num_ctx: 65536` "
        "(and `model.context_length: 65536` if you also override the displayed "
        "model context). If you manage the model through an Ollama Modelfile, "
        "set `PARAMETER num_ctx 65536` there instead."
    )


def _maybe_grow_local_window(agent: Any, compressor: Any,
                             request_tokens: int) -> Optional[int]:
    """Try growing the managed local model's context window before
    compressing. Returns the new window when the ladder granted one, else
    None (hold / at native / not a managed local session).

    The window ladder's design order: models launch at their zero-spill
    window and grow toward native max as the session needs room;
    compression is the move of last resort. Cheap for every non-local
    provider: one lowercase compare, no imports.
    """
    provider = (getattr(agent, "provider", "") or "").strip().lower()
    if provider not in ("llamacpp", "llama.cpp", "llama-cpp", "custom"):
        return None
    base_url = getattr(agent, "base_url", "") or ""
    if "127.0.0.1" not in base_url and "localhost" not in base_url:
        return None
    try:
        from hermes_cli.local_runtime.growth import maybe_grow_window

        current_window = int(getattr(compressor, "context_length", 0) or 0)
        if current_window <= 0:
            return None
        return maybe_grow_window(
            getattr(agent, "model", "") or "",
            base_url=base_url,
            session_tokens=int(request_tokens),
            current_window=current_window,
        )
    except Exception as exc:  # noqa: BLE001 — growth must never break a turn
        logger.debug("local window growth check failed: %s", exc)
        return None


def _ra():
    """Lazy reference to ``run_agent`` so callers can patch
    ``run_agent.handle_function_call`` / ``run_agent._set_interrupt`` /
    ``run_agent.OpenAI`` and have those patches reach this code path.
    """
    import run_agent
    return run_agent


def _nous_entitlement_message(capability: str) -> str:
    try:
        from hermes_cli.nous_account import (
            format_nous_portal_entitlement_message,
            get_nous_portal_account_info,
        )

        account_info = get_nous_portal_account_info(force_fresh=True)
        message = format_nous_portal_entitlement_message(
            account_info,
            capability=capability,
        )
        return message or ""
    except Exception:
        return ""


def _print_nous_entitlement_guidance(agent, capability: str) -> bool:
    message = _nous_entitlement_message(capability)
    if not message:
        return False
    for line in message.splitlines():
        agent._vprint(f"{agent.log_prefix}   💡 {line}", force=True)
    return True


def _system_prompt_for_hooks(api_kwargs: Any, request_messages: Any) -> Any:
    """System prompt as actually sent to the provider, for observability hooks.

    Providers move it out of ``messages``: Anthropic Messages uses a separate
    ``system`` kwarg (str or content-block list), the Responses/Codex API uses
    top-level ``instructions``; Chat Completions keeps it as ``messages[0]``.
    Returns None when the request carries no system prompt.
    """
    system_prompt = api_kwargs.get("system")
    if system_prompt is None:
        system_prompt = api_kwargs.get("instructions")
    if system_prompt is None and isinstance(request_messages, list) and request_messages:
        first = request_messages[0]
        if isinstance(first, dict) and first.get("role") == "system":
            system_prompt = first.get("content")
    return system_prompt


def _is_nous_inference_route(provider: str, base_url: str) -> bool:
    provider = (provider or "").strip().lower()
    if provider == "nous":
        return True
    base = str(base_url or "")
    return (
        base_url_host_matches(base, "inference-api.nousresearch.com")
    )


def _billing_or_entitlement_message(
    *,
    capability: str,
    provider: str,
    base_url: str,
    model: str,
    unverified: bool = False,
) -> str:
    if _is_nous_inference_route(provider, base_url):
        return _nous_entitlement_message(capability)

    provider_label = (provider or "").strip() or "the selected provider"
    model_label = (model or "").strip() or "the selected model"

    # Anthropic Claude Pro/Max OAuth subscriptions surface exhaustion of the
    # metered "extra usage" bucket as a hard 400 ("You're out of extra
    # usage"). Point at the exact settings page and note the cycle-reset
    # option, since the generic "add credits with that provider" line doesn't
    # apply to a subscription — the user waits for the reset or switches to an
    # API key.
    if (provider or "").strip().lower() == "anthropic":
        # ``unverified`` (ClassifiedError.billing_unverified, #82154): the
        # "out of extra usage" 400 is ambiguous — Anthropic returns the same
        # body when its server-side content filter rejects part of the request
        # on a subscription OAuth token, so the message reliably misdirects
        # diagnosis toward buying quota. Hedge the claim and name the other
        # cause. A confirmed verdict (e.g. a real 402 or an API-key credit
        # depletion) keeps the assertive wording.
        if unverified:
            lines = [
                (
                    f"{provider_label} reported that your Claude subscription usage may be "
                    f"exhausted for {model_label} (included quota + extra-usage credits) — "
                    "but this specific error is not proof of a billing problem."
                ),
                "If https://claude.ai/settings/usage still shows quota remaining, this is "
                "probably NOT a billing problem: on a Claude subscription (OAuth) token "
                "Anthropic returns this same message when its content filter rejects part "
                "of the request — typically a phrase in the system prompt.",
                "If usage really is exhausted: wait for the billing cycle to reset, or add "
                "extra usage at https://claude.ai/settings/usage",
                "You can also switch to an Anthropic API key or another provider with "
                "/model <model> --provider <provider>.",
                # The exhaustion latch replays the stored error without issuing
                # a request, so a real fix looks like it didn't work.
                "Retry with a fresh credential state: `hermes auth reset anthropic`. Until "
                "that cooldown clears, this error can be replayed from cache without "
                "contacting the API.",
            ]
        else:
            lines = [
                (
                    f"{provider_label} reported that your Claude subscription usage is "
                    f"exhausted for {model_label} (included quota + extra-usage credits)."
                ),
                "Options: wait for the billing cycle to reset, or add extra usage at "
                "https://claude.ai/settings/usage",
                "You can also switch to an Anthropic API key or another provider with "
                "/model <model> --provider <provider>.",
            ]
        return "\n".join(lines)

    # Provider-agnostic billing URL derivation (OpenAI, DeepSeek, xAI, Groq,
    # OpenRouter, …) so every text surface — CLI, gateway messaging, TUI
    # transcript — shows the same actionable link, not just OpenRouter.
    try:
        from agent.billing_links import build_billing_block

        _link = build_billing_block(provider=provider, base_url=base_url, model=model)
        if _link.provider_label:
            provider_label = _link.provider_label
        billing_url = _link.billing_url
    except Exception:
        billing_url = None

    lines = [
        (
            f"{provider_label} reported that billing, credits, or account "
            f"entitlement is exhausted for {model_label}."
        ),
        "Add credits or update billing with that provider, then retry.",
    ]
    if billing_url:
        lines.append(f"{provider_label} billing: {billing_url}")
    lines.append("You can switch providers temporarily with /model <model> --provider <provider>.")
    return "\n".join(lines)


def _billing_block_dict(
    provider, base_url, model, message="", *, unverified: bool = False
) -> Optional[dict]:
    """Best-effort structured billing descriptor (None if billing_links is unavailable)."""
    try:
        from agent.billing_links import build_billing_block

        block = build_billing_block(
            provider=provider, base_url=str(base_url), model=model, message=message
        ).to_dict()
    except Exception:
        return None
    if block is not None and unverified:
        # Carry the classifier's ambiguity into the structured descriptor so
        # every surface rendering the block can hedge too (#82154).
        block["unverified"] = True
    return block


def _billing_terminal_label(summary: str, unverified: bool) -> str:
    """Terminal-failure prefix for a billing-classified error.

    ``unverified`` (#82154): the Anthropic "out of extra usage" 400 can be a
    content-filter rejection, so the terminal line must not assert billing
    exhaustion as fact.
    """
    if unverified:
        return (
            "Provider reported usage/credit exhaustion (unverified — the same "
            f"error can be a content-filter rejection, not billing): {summary}"
        )
    return f"Billing or credits exhausted: {summary}"


def _billing_failure_result(
    *,
    classified,
    summary: str,
    messages,
    api_call_count: int,
    provider: str,
    base_url,
    model: str,
    guidance: Optional[str] = None,
) -> dict:
    """Structured terminal result for a billing-classified failure.

    Single construction point for the returned terminal response so the
    label, guidance, structured block, and ambiguity flag stay consistent
    across the non-retryable abort and max-retries paths (#82154).
    """
    unverified = bool(getattr(classified, "billing_unverified", False))
    if guidance is None:
        guidance = _billing_or_entitlement_message(
            capability="model access",
            provider=provider,
            base_url=str(base_url),
            model=model,
            unverified=unverified,
        )
    final = _billing_terminal_label(summary, unverified)
    if guidance:
        final += f"\n\n{guidance}"
    return {
        "final_response": final,
        "messages": messages,
        "api_calls": api_call_count,
        "completed": False,
        "failed": True,
        "error": summary,
        "failure_reason": classified.reason.value,
        # The classifier's own retry verdict — carried so UI surfaces
        # (agent/error_surface.py) show Retry only when a re-run can differ,
        # instead of re-deriving retryability from a second taxonomy.
        "failure_retryable": bool(classified.retryable),
        # The billing verdict may rest on an ambiguous body (#82154) — carry
        # that through the structured result, not just the prose.
        "billing_unverified": unverified,
        "billing_block": _billing_block_dict(
            provider, base_url, model, guidance, unverified=unverified
        ),
    }


def _print_billing_or_entitlement_guidance(
    agent,
    *,
    capability: str,
    provider: str,
    base_url: str,
    model: str,
    unverified: bool = False,
) -> bool:
    message = _billing_or_entitlement_message(
        capability=capability,
        provider=provider,
        base_url=base_url,
        model=model,
        unverified=unverified,
    )
    if not message:
        return False
    for line in message.splitlines():
        agent._vprint(f"{agent.log_prefix}   💡 {line}", force=True)
    return True


def _try_refresh_nous_paid_entitlement_credentials(agent) -> bool:
    """Refresh Nous runtime credentials after a fresh paid-entitlement check."""
    try:
        from hermes_cli.nous_account import get_nous_portal_account_info

        account_info = get_nous_portal_account_info(force_fresh=True)
        if account_info.paid_service_access is not True:
            return False
        return agent._try_refresh_nous_client_credentials(
            force=True,
        )
    except Exception:
        return False


def _restore_or_build_system_prompt(agent, system_message, conversation_history):
    """Restore the cached system prompt from the session DB or build it fresh.

    Mutates ``agent._cached_system_prompt`` and persists a freshly-built
    prompt back to the session DB on first build.  Extracted from
    ``run_conversation`` so the prefix-cache restore path can be tested in
    isolation.

    Three-way state distinction for the stored row, surfaced via logs so
    silent prefix-cache misses are visible in ``agent.log``:

      * ``missing`` — no session row yet (legitimate first turn).
      * ``null``   — row exists, ``system_prompt`` column is NULL.
        Legacy session predating system-prompt persistence, or a migration
        leftover.  Warns when ``conversation_history`` is non-empty.
      * ``empty``  — row exists, ``system_prompt`` column is the empty
        string.  Indicates a previous-turn write that ran but stored
        nothing (silent persistence bug).  Always warns.
      * ``present`` — row exists with a usable prompt → reused verbatim.

    Read or write failures against the session DB log at WARNING (not
    DEBUG) so persistent issues (disk full, schema drift, lock contention)
    surface without needing verbose mode.  This used to be a debug-level
    log that silently broke prefix-cache reuse on the gateway path
    (which constructs a fresh ``AIAgent`` per turn and depends on this
    DB roundtrip).
    """
    stored_prompt = None
    stored_state = "missing"
    if conversation_history and agent._session_db:
        try:
            session_row = agent._session_db.get_session(agent.session_id)
            if session_row is not None:
                raw_prompt = session_row.get("system_prompt")
                if raw_prompt is None:
                    stored_state = "null"
                elif raw_prompt == "":
                    stored_state = "empty"
                else:
                    stored_prompt = raw_prompt
                    stored_state = "present"
        except Exception as exc:
            logger.warning(
                "Session DB get_session failed for system-prompt restore "
                "(session=%s): %s. Falling back to fresh build — prefix "
                "cache will miss for this turn.",
                agent.session_id, exc,
            )

    if stored_prompt and _stored_prompt_matches_runtime(agent, stored_prompt):
        # Bot Chat capability epoch: an eternal bot session must adopt
        # user-initiated capability changes (skills/toolsets/MCP/SOUL/roster)
        # on the next message, not at /new or compression. The stored prompt
        # embeds a fingerprint of the capability surface; a mismatch against
        # disk is a deliberate, once-per-change rebuild — the /model
        # exception applied to capabilities. Prompts without the stamp
        # (every non-Bot-Chat session) never take this branch, and the check
        # fails closed to "reuse" so a probe failure can't burn cache.
        _bot_stale = False
        try:
            from tools.bot_mode_probe import (
                BOT_CHAT_TITLE,
                stored_bot_chat_prompt_needs_upgrade,
                stored_prompt_capability_stale,
            )

            _home_for_epoch = None
            try:
                from agent.system_prompt import _agent_home

                _home_for_epoch = _agent_home(agent)
            except Exception:
                pass
            _bot_stale = stored_prompt_capability_stale(stored_prompt, _home_for_epoch)
            if not _bot_stale and getattr(agent, "_bot_mode_protocol", True):
                # Legacy upgrade: a Bot Chat whose prompt predates the epoch
                # mechanism (no stamp, no protocol) gets ONE migration
                # rebuild — otherwise pre-existing bots would never learn
                # the messaging protocol. Title-gated so ordinary unstamped
                # sessions (i.e. all of them) never take this path; the
                # rebuilt prompt carries the stamp, so it cannot re-fire.
                _t = str(getattr(agent, "_session_title_hint", "") or "").strip()
                if not _t and agent._session_db and agent.session_id:
                    try:
                        _t = str(agent._session_db.get_session_title(agent.session_id) or "").strip()
                    except Exception:
                        _t = ""
                if _t == BOT_CHAT_TITLE:
                    _bot_stale = stored_bot_chat_prompt_needs_upgrade(stored_prompt, _home_for_epoch)
        except Exception:
            _bot_stale = False
        if _bot_stale:
            logger.info(
                "Bot Chat capability epoch changed for session %s; rebuilding "
                "system prompt to adopt the new capability surface (one-time "
                "prefix-cache break).",
                agent.session_id,
            )
            agent._session_title_hint = "Bot Chat"
            # The skills index inside the prompt comes from a two-layer cache
            # (in-process LRU + disk snapshot) that doesn't watch the skills
            # dir; a capability refresh must rebuild THROUGH it or a freshly
            # installed skill stays invisible in the new prompt.
            try:
                from agent.prompt_builder import clear_skills_system_prompt_cache

                clear_skills_system_prompt_cache(clear_snapshot=True)
            except Exception:
                pass
            agent._cached_system_prompt = agent._build_system_prompt(system_message)
            agent._bot_capability_refreshed = True
            # Persist the refreshed prompt so the NEXT turn restores the new
            # bytes verbatim — the cache break is once per capability change,
            # never per turn. (on_session_start deliberately not re-fired:
            # this is a continuation, not a new session.)
            if agent._session_db:
                try:
                    agent._session_db.update_system_prompt(
                        agent.session_id, agent._cached_system_prompt
                    )
                except Exception as exc:
                    logger.warning(
                        "Session DB update_system_prompt failed after Bot Chat "
                        "capability refresh (session=%s): %s. The refresh will "
                        "re-fire next turn.",
                        agent.session_id, exc,
                    )
            return
        # Continuing session — reuse the exact system prompt from the
        # previous turn so the Anthropic cache prefix matches.
        agent._cached_system_prompt = stored_prompt
        # Prompt-section callbacks are new-session-only. Recover their frozen
        # bytes from the persisted full prompt so a later compression rebuild
        # keeps them without evaluating plugin state in this resumed process.
        from agent.system_prompt import restore_plugin_prompt_sections

        restore_plugin_prompt_sections(agent, stored_prompt)
        # Reconstruct the cross-session-stable prefix for the early cache
        # breakpoint. The static prefix is not persisted (only the full
        # prompt is), so gateway surfaces that build a fresh AIAgent per
        # turn would otherwise lose the two-block system layout after the
        # first turn — flip-flopping the wire shape mid-conversation and
        # silently degrading to the legacy single-breakpoint layout.
        #
        # ``reconstruct_static_prefix`` gates on ``_use_prompt_caching`` (so
        # non-Anthropic routes skip the rebuild), applies the startswith
        # safety gate (stored prompt bytes are never rewritten), and
        # fails open to the legacy cache layout.
        from agent.system_prompt import reconstruct_static_prefix

        reconstruct_static_prefix(agent, system_message=system_message)
        return
    if stored_prompt:
        stored_state = "stale_runtime"
        logger.info(
            "Stored system prompt for session %s has stale runtime identity; "
            "rebuilding for model=%s provider=%s.",
            agent.session_id,
            getattr(agent, "model", "") or "",
            getattr(agent, "provider", "") or "",
        )

    if conversation_history and stored_state in ("null", "empty"):
        # Continuing session whose stored prompt is unusable.  The
        # previous turn's write either never happened or wrote an empty
        # string — either way every turn now rebuilds and the prefix
        # cache misses every time.
        logger.warning(
            "Stored system prompt for session %s is %s; rebuilding "
            "from scratch this turn. Prefix cache will miss until "
            "the rebuild persists. Investigate the previous turn's "
            "update_system_prompt write path.",
            agent.session_id, stored_state,
        )

    # First turn of a new session (or recovering from a broken stored
    # prompt) — build from scratch.
    agent._cached_system_prompt = agent._build_system_prompt(system_message)

    # Plugin hook: on_session_start — fired once when a brand-new
    # session is created (not on continuation).  Plugins can use this
    # to initialise session-scoped state (e.g. warm a memory cache).
    try:
        from hermes_cli.lifecycle import invoke_hook as _invoke_hook
        _invoke_hook(
            "on_session_start",
            session_id=agent.session_id,
            model=agent.model,
            platform=getattr(agent, "platform", None) or "",
        )
    except Exception as exc:
        logger.warning("on_session_start hook failed: %s", exc)

    # Cold-start credits seed (L3) — fallback for the first-turn path. The TUI/
    # desktop build seeds at session OPEN (see seed_credits_at_session_start in
    # tui_gateway), so this call is usually a no-op there (idempotent: skips when
    # _credits_state already exists). For the plain CLI / any path that didn't seed
    # at build, it primes credits state from /api/oauth/account (or a fixture) on the
    # first turn so depletion / usage-band warnings fire. Fail-open inside the helper.
    try:
        from agent.credits_tracker import seed_credits_at_session_start

        seed_credits_at_session_start(agent)
    except Exception:
        logger.debug("cold-start credits seed failed (fail-open)", exc_info=True)

    # Persist the system prompt snapshot in SQLite.  Failure here used
    # to log at DEBUG, which silently broke prefix-cache reuse on the
    # gateway path (fresh AIAgent per turn → reads from this row every
    # subsequent turn).
    if agent._session_db:
        try:
            agent._session_db.update_system_prompt(agent.session_id, agent._cached_system_prompt)
        except Exception as exc:
            logger.warning(
                "Session DB update_system_prompt failed for session %s: "
                "%s. Subsequent turns will rebuild the system prompt and "
                "miss the prefix cache.",
                agent.session_id, exc,
            )


def _stored_prompt_matches_runtime(agent, prompt: str) -> bool:
    """Return False when the persisted runtime-identity lines are stale."""

    def line_value(label: str) -> str:
        """Last matching line wins.

        Safe ONLY for fields emitted in the volatile tier at the very END of
        the prompt (Model / Provider / Platform). User-supplied project
        context (AGENTS.md / CLAUDE.md / .cursorrules) is embedded in the
        middle context tier, so a last-match scan lets project prose shadow
        any field emitted EARLIER — see ``host_info_value``.
        """
        prefix = f"{label}:"
        value = ""
        for line in prompt.splitlines():
            if line.startswith(prefix):
                value = line[len(prefix):].strip()
        return value

    def host_info_value(label: str) -> str:
        """Read a field from the prompt's own host-info block.

        The host-info block (``build_environment_hints``) sits in the STABLE
        tier, ahead of the embedded project context files. A bare scan of the
        whole prompt would therefore match a user's ``AGENTS.md`` that merely
        contains a line starting with the same label, comparing runtime state
        against project prose. That mismatch never clears, so the check would
        reject the stored prompt on EVERY turn — rebuilding the system prompt
        each message and destroying the prefix cache for the whole session,
        which is far worse than the staleness this function guards against.

        Anchor on the ``User home directory:`` line that immediately precedes
        the working-directory line in that block, and take the FIRST such
        occurrence, so only Hermes' own emitted block can satisfy the read.
        """
        prefix = f"{label}:"
        lines = prompt.splitlines()
        for idx, line in enumerate(lines):
            if not line.startswith("User home directory:"):
                continue
            for candidate in lines[idx + 1: idx + 4]:
                if candidate.startswith(prefix):
                    return candidate[len(prefix):].strip()
        return ""

    stored_model = line_value("Model")
    current_model = str(getattr(agent, "model", "") or "").strip()
    if stored_model and current_model and stored_model != current_model:
        return False

    stored_provider = line_value("Provider")
    current_provider = str(getattr(agent, "provider", "") or "").strip()
    if stored_provider and current_provider and stored_provider != current_provider:
        return False

    # Detect cwd drift: if the stored prompt was built in a different working
    # directory, reuse would silently inject a stale path into the prefix cache.
    # Compare against resolve_agent_cwd() — the SAME resolver used to build the
    # prompt — so gateway/TUI sessions that set TERMINAL_CWD are not falsely
    # rejected (they would always differ from the launch dir's os.getcwd()).
    stored_cwd = host_info_value("Current working directory")
    if stored_cwd:
        if stored_cwd != str(resolve_agent_cwd()):
            return False

    # Detect runtime-surface drift: the stored prompt records which platform it
    # was built for (e.g. "desktop" vs "cli"). Reusing a desktop-built prompt on
    # a terminal session (or vice versa) would inject the wrong runtime hints.
    stored_platform = line_value("Platform")
    current_platform = str(getattr(agent, "platform", "") or "").strip()
    if stored_platform and current_platform and stored_platform != current_platform:
        return False

    return True


# The three _get_continuation_prompt variants below, in named-constant form
# so agent.context_compressor's _is_synthetic_compression_user_turn can
# recognize them by content after a crash/interrupt persists one mid-list —
# these rows carry no durable role beyond driving the retry, and SessionDB
# projection strips the _length_continuation_nudge metadata tag that marks
# them in live memory (see agent/context_compressor.py).
_LENGTH_CONTINUATION_NETWORK_STUB = (
    "[System: The previous response was cut off by a "
    "network error mid-stream. Continue exactly where "
    "you left off. Do not restart or repeat prior text. "
    "Finish the answer directly.]"
)
_LENGTH_CONTINUATION_OUTPUT_LIMIT = (
    "[System: Your previous response was truncated by the output "
    "length limit. Continue exactly where you left off. Do not "
    "restart or repeat prior text. Finish the answer directly.]"
)
# The dropped-tools variant interpolates the tool name list right after this
# prefix, so it can't be exact-matched — this stable prefix is what
# _is_synthetic_compression_user_turn checks with str.startswith instead.
_LENGTH_CONTINUATION_DROPPED_TOOLS_PREFIX = "[System: Your previous tool call "


def _get_continuation_prompt(is_partial_stub: bool, dropped_tools: Optional[List[str]] = None) -> str:
    if is_partial_stub and dropped_tools:
        tool_list = ", ".join(dropped_tools[:3])
        return (
            f"{_LENGTH_CONTINUATION_DROPPED_TOOLS_PREFIX}"
            f"({tool_list}) was too large and "
            "the stream timed out before it "
            "could be delivered. Do NOT retry "
            "the same tool call with the same "
            "large content. Instead, break the "
            "content into multiple smaller tool "
            "calls (e.g. use multiple patch calls "
            "or write smaller files). Each tool "
            "call's arguments must be under ~8K "
            "tokens to avoid stream timeouts.]"
        )
    elif is_partial_stub:
        return _LENGTH_CONTINUATION_NETWORK_STUB
    else:
        return _LENGTH_CONTINUATION_OUTPUT_LIMIT


# Continuation nudge for Codex/Responses turns that came back with only
# internal reasoning (no visible content, no tool calls).  When the interim
# assistant message also carries no encrypted reasoning items and no
# replayable message items, _chat_messages_to_responses_input emits nothing
# for it — a bare retry would be byte-identical to the request that just
# failed, so the model (observed: grok-4.20 on xai-oauth) deterministically
# repeats the reasoning-only response until the retry budget is exhausted.
_CODEX_INCOMPLETE_NUDGE = (
    "[System: Your previous response contained only internal reasoning and "
    "never produced a visible answer or tool call. Do not keep thinking. "
    "Produce your final answer as plain text now (or make the tool call "
    "you were planning).]"
)


# Re-prompt sent after a Codex/Responses turn ends with an acknowledgment-only
# reply (no tool calls, no final answer) — named so
# agent.context_compressor's _is_synthetic_compression_user_turn can
# recognize it by content the same way it recognizes _CODEX_INCOMPLETE_NUDGE.
_CODEX_ACK_CONTINUATION_NUDGE = (
    "[System: Continue now. Execute the required tool calls and only "
    "send your final answer after completing the task.]"
)

# Re-prompt sent when a provider returns finish_reason="tool_calls" with an
# empty tool_calls array (dropped-tool-call recovery, see the retry loop
# below). Named for the same reason as _CODEX_ACK_CONTINUATION_NUDGE — this
# pair is only stripped from the durable transcript once the turn reaches
# finalization; an interrupt/crash mid-retry can still persist it.
_DROPPED_TOOLCALL_NUDGE_CONTENT = (
    "Your previous turn indicated a tool call but none was "
    "included. Do not narrate a plan or restate intent — issue "
    "the actual tool call now to continue the task."
)

# Re-prompt sent when the model returns an empty response after executing tool
# calls (#9400). Named for the same reason as the nudges above — its
# _empty_recovery_synthetic metadata flag doesn't survive SessionDB projection.
_EMPTY_TOOL_RESPONSE_NUDGE = (
    "You just executed tool calls but returned an "
    "empty response. Please process the tool "
    "results above and continue with the task."
)


# Shared recovery hint appended to every content-policy refusal message. Both
# the HTTP-200 refusal path (``finish_reason=content_filter``) and the
# exception path (a provider moderation error classified as
# ``content_policy_blocked``) end with the same actionable next steps, so they
# share one trailer to keep the guidance from drifting between the two sites.
_CONTENT_POLICY_RECOVERY_HINT = (
    "Try rephrasing the request, narrowing the context, or "
    "adding a fallback provider with `hermes fallback add`."
)


# Memo for the send-path tool-call argument canonicalization inside
# run_conversation().  That pass re-canonicalizes the arguments string of
# EVERY historical tool call on EVERY API-call iteration (quadratic in
# session tool-call count), and the api_messages copies share the exact
# argument string objects with the persisted history, so the same strings
# come through unchanged iteration after iteration.
#
# Soundness: canonicalization is a pure, deterministic function of the
# input string (fixed separators, sort_keys=True), so a value-keyed memo
# is exact — equal inputs always produce the canonical form computed the
# first time.  Malformed strings raise out of json.loads BEFORE anything
# is stored, so the repair fallback below is never memoized and reruns on
# every occurrence, exactly as before.  Bounded FIFO eviction mirrors the
# _MSG_TOKENS_CACHE idiom in agent/model_metadata.py.
_CANON_ARGS_CACHE: Dict[str, str] = {}
_CANON_ARGS_CACHE_MAX = 4096
# Count bound alone doesn't bound MEMORY: write_file/patch argument strings
# run 100KB+, so 4096 entries could pin ~800MB in a long-lived gateway
# process. The byte budget keeps the memo effective for the common case
# (args ~0.5-2KB) while bounding the worst case.
_CANON_ARGS_CACHE_MAX_BYTES = 32 * 1024 * 1024
_canon_args_cache_bytes = 0


def _canonicalize_tool_call_arguments(arg_str: str) -> str:
    """Return the canonical wire form of a tool-call arguments JSON string.

    Raises whatever ``json.loads`` raises on malformed input; the caller
    falls back to ``_repair_tool_call_arguments``, exactly as before.
    """
    global _canon_args_cache_bytes
    cached = _CANON_ARGS_CACHE.get(arg_str)
    if cached is not None:
        return cached
    canonical = json.dumps(
        json.loads(arg_str), separators=(",", ":"), sort_keys=True,
    )
    _CANON_ARGS_CACHE[arg_str] = canonical
    _canon_args_cache_bytes += len(arg_str) + len(canonical)
    while len(_CANON_ARGS_CACHE) > _CANON_ARGS_CACHE_MAX or (
        _canon_args_cache_bytes > _CANON_ARGS_CACHE_MAX_BYTES
        and len(_CANON_ARGS_CACHE) > 1
    ):
        try:
            evicted_key = next(iter(_CANON_ARGS_CACHE))
            evicted_val = _CANON_ARGS_CACHE.pop(evicted_key)
            _canon_args_cache_bytes -= len(evicted_key) + len(evicted_val)
        except (StopIteration, KeyError, RuntimeError):
            break
    return canonical


def _clone_message_for_send(msg):
    """Structural clone of a history message for the per-call API copy.

    The send path builds ``api_messages`` from the persisted history and
    then rewrites the copies in place (canonicalization/repair of tool-call
    arguments, surrogate and non-ASCII sanitization, content strips, cache
    decoration). A shallow ``msg.copy()`` only decouples TOP-LEVEL fields:
    nested containers — ``tool_calls`` entries and their ``function`` dicts,
    multimodal ``content`` part lists, ``reasoning_details`` — remain the
    SAME objects the persisted history holds, so any in-place write there
    silently rewrites the stored transcript (#80498: an unrepairable
    ``write_file`` argument string was replaced with ``{}`` in the persisted
    turn, destroying the streamed file content).

    Cloning every container (dict/list) recursively while SHARING immutable
    leaves (strings, numbers, None) makes every downstream in-place
    transform safe by construction — current and future — at container-count
    cost, not string-byte cost: big argument strings and base64 image
    payloads are shared, never copied. Measured: ~1-5ms per 2000-message
    pathological build (20% multimodal, 30% tool calls) vs ~0.4ms for the
    shallow copy; compression keeps real request histories far smaller, and
    the build runs once per API call — noise next to the call itself.
    copy.deepcopy would be equally correct (CPython deepcopy also shares
    immutable str) but ~4x slower again and needs its memo machinery;
    history messages are JSON-shaped and acyclic (depth < 10 in practice;
    a >~1000-deep pathological nest would hit the recursion limit, exactly
    as deepcopy would), so cycle handling isn't needed here. Tuples are
    shared as leaves: JSON-derived message content never contains tuples,
    so a mutable container smuggled inside one is not a reachable shape on
    this path.
    """
    if isinstance(msg, dict):
        return {
            k: _clone_message_for_send(v) if isinstance(v, (dict, list)) else v
            for k, v in msg.items()
        }
    if isinstance(msg, list):
        return [
            _clone_message_for_send(v) if isinstance(v, (dict, list)) else v
            for v in msg
        ]
    return msg


def _canonicalize_api_tool_calls(api_messages) -> None:
    """Canonicalize tool-call argument JSON on the send-path message copy.

    Rewrites each message's ``tool_calls`` in place (copy-on-write for the
    tool-call dicts it canonicalizes; the persisted history is untouched).
    The pass still traverses every message and tool call each iteration;
    the memo above bounds the JSON parse/serialize work to one round-trip
    per UNIQUE argument string instead of one per string per iteration —
    the quadratic part of the cost. The remaining traversal is pointer
    chasing and dict copies, cheap next to a json.loads + json.dumps.
    """
    for am in api_messages:
        tcs = am.get("tool_calls")
        if not tcs:
            continue
        new_tcs = []
        for tc in tcs:
            if isinstance(tc, dict) and "function" in tc:
                try:
                    tc = {**tc, "function": {
                        **tc["function"],
                        "arguments": _canonicalize_tool_call_arguments(
                            tc["function"]["arguments"]
                        ),
                    }}
                except Exception:
                    # Copy-on-write here too. The send-path build now hands
                    # this pass structurally-cloned messages (see
                    # _clone_message_for_send), but this branch keeps its own
                    # copy as defense in depth: some callers (tests, future
                    # call sites) pass shallow copies, and assigning into a
                    # shared ``tc["function"]`` would rewrite the stored
                    # turn. On the unrepairable path the repair returns "{}",
                    # so a write-through here replaced the model's real
                    # arguments with an empty object in the transcript: a
                    # stream that died mid ``write_file`` lost the file
                    # content it had already streamed, with only a WARNING
                    # to show for it (#80498).
                    tc = {**tc, "function": {
                        **tc["function"],
                        "arguments": _repair_tool_call_arguments(
                            tc["function"]["arguments"],
                            tc["function"].get("name", "?"),
                        ),
                    }}
            new_tcs.append(tc)
        am["tool_calls"] = new_tcs


def _invalid_tool_name_error_content(name: str, valid_tool_names) -> str:
    """Error-result content for a tool call whose name isn't a real tool.

    A blank/whitespace-only name is not a typo the model can fuzzy-correct
    toward a real tool — it is almost always a weak open model echoing
    tool-call XML/JSON it saw in file or tool output (#47967:
    <tool_call>/<invoke name=...> payloads in a file prime
    mimo/nemotron-class models to emit empty structured calls), or a model
    degrading at very large context (observed with gpt-5.6 past ~350K input).
    Dumping the full tool catalog in that case feeds the priming loop more
    names to mimic and inflates context 3-4x across retries, so send a terse
    error that tells the model in-context tool-call syntax is DATA, not a
    call to make. A genuinely-wrong-but-nonempty name (an actual typo) still
    gets the catalog so the model can self-correct.
    """
    if not (name or "").strip():
        return (
            "Tool call rejected: the tool name was empty. "
            "If tool-call XML or JSON appeared in file "
            "contents or tool output, that is data — do "
            "not re-emit it as a tool call. To call a "
            "tool, use a valid name from your tool list; "
            "otherwise reply in plain text."
        )
    available = ", ".join(sorted(valid_tool_names))
    return f"Tool '{name}' does not exist. Available tools: {available}"


def _content_policy_blocked_result(
    messages: List[Dict],
    api_call_count: int,
    *,
    final_response: str,
    error_detail: str,
) -> Dict[str, Any]:
    """Build the terminal turn result for a content-policy block.

    A content-policy refusal is deterministic for the unchanged prompt, so the
    turn ends here (no retry). Both the HTTP-200 refusal handler and the
    exception-path handler return the identical shape — a failed, non-completed
    turn carrying the user-facing message and a ``content_policy_blocked:``
    prefixed error — so they funnel through this one builder.
    """
    return {
        "final_response": final_response,
        "messages": messages,
        "api_calls": api_call_count,
        "completed": False,
        "failed": True,
        "error": f"content_policy_blocked: {error_detail}",
    }


def _compression_deferred_result(
    agent,
    messages: List[Dict],
    api_call_count: int,
    reason: str = "lock",
) -> Dict[str, Any]:
    """Build the soft turn result for a transiently-deferred compression.

    Two transient shapes funnel here, and BOTH must end as a soft defer
    (``compression_deferred``), never as ``compression_exhausted``: the
    gateway auto-resets (wipes) the session on exhaustion (#9893/#35809).

    * ``reason="lock"`` — another path (a sibling turn, a background review
      fork, a manual ``/compress``) holds this session's compression lock,
      so every compression pass this turn no-oped and the request still does
      not fit. The lock winner is actively shrinking the same session.
    * ``reason="transient_block"`` — the compressor is in a timed transient
      guard (summary-failure cooldown / structural backoff, e.g. one just
      recorded by the host ceiling timeout, #97488). The no-op says nothing
      about compressibility; treating it as exhaustion falsely auto-reset
      sessions whose compression was merely cooling down.

    ``failed`` stays False so the gateway persists the user turn (transient
    branch) and retry-next-message semantics apply.
    """
    if reason == "transient_block":
        block = getattr(agent, "_compression_blocked_transient", None)
        logger.info(
            "turn deferred: compression transiently blocked (%s) "
            "(session=%s) — not counting as compression exhaustion",
            block if isinstance(block, str) else "unknown guard",
            agent.session_id or "none",
        )
        _final = (
            "Context compression is temporarily paused after a recent "
            "failed attempt. Please retry in a moment — compression will "
            "resume automatically (or run /compress to force a retry now)."
        )
    else:
        holder = getattr(agent, "_compression_skipped_due_to_lock", None)
        logger.info(
            "turn deferred: compression lock held by another path "
            "(session=%s holder=%s) — not counting as compression exhaustion",
            agent.session_id or "none",
            holder if isinstance(holder, str) else "unconfirmed",
        )
        _final = (
            "Context compression is already running for this session. "
            "Please retry in a moment — your next message will be processed "
            "once the concurrent compression finishes."
        )
    try:
        agent._flush_status_buffer()
    except Exception:
        pass
    return {
        "final_response": _final,
        "messages": messages,
        "completed": False,
        "api_calls": api_call_count,
        "error": _final,
        "partial": True,
        "failed": False,
        "compression_deferred": True,
        "session_id": agent.session_id,
    }


def _rewrite_system_content_blocks(system_message: dict, effective: str) -> bool:
    """Rewrite a cache-decorated system message in place, keeping its blocks.

    ``apply_anthropic_cache_control`` runs once per call block, *before* the
    retry loop, and splits the system prompt into ``[static prefix, volatile
    tail]`` text blocks carrying the cache_control breakpoints. Assigning a bare
    string over that list drops both breakpoints, so the failover retry ships
    the whole system prompt uncached and re-bills it in full.

    ``rewrite_prompt_model_identity`` only touches the LAST ``Model:`` /
    ``Provider:`` lines, and those live in the volatile tail — so the static
    prefix stays byte-identical and its cache entry keeps matching. Returns
    False when the shape is not one we can safely patch, so the caller falls
    back to the plain-string assignment.
    """
    content = system_message.get("content")
    if not isinstance(content, list) or not content:
        return False
    if not all(
        isinstance(part, dict) and part.get("type") == "text" for part in content
    ):
        return False
    if len(content) == 1:
        content[0]["text"] = effective
        return True
    if len(content) == 2:
        head = content[0].get("text") or ""
        if head and effective.startswith(head):
            tail = effective[len(head):]
            if tail:
                content[1]["text"] = tail
                return True
    return False


def _sync_failover_system_message(agent, api_messages, active_system_prompt):
    """Refresh the in-flight system message after a provider failover.

    ``try_activate_fallback`` rewrites the ``Model:``/``Provider:`` identity
    lines on ``agent._cached_system_prompt`` (see
    ``rewrite_prompt_model_identity``) so the agent reports the model that is
    actually answering.  But the current call block's ``api_messages`` were
    built from the pre-failover prompt, and the retry loop rebuilds
    ``api_kwargs`` from that list each iteration — without this sync the
    whole turn (and every gateway turn, since fallback re-activates per
    message while the primary is down) ships the stale identity.

    Mutates ``api_messages[0]`` in place and returns the prompt to use as
    ``active_system_prompt`` for subsequent call-block rebuilds.
    """
    sp = getattr(agent, "_cached_system_prompt", None)
    if not isinstance(sp, str) or not sp:
        return active_system_prompt
    if api_messages and api_messages[0].get("role") == "system":
        effective = sp
        if agent.ephemeral_system_prompt:
            effective = (effective + "\n\n" + agent.ephemeral_system_prompt).strip()
        if not _rewrite_system_content_blocks(api_messages[0], effective):
            api_messages[0]["content"] = effective
    return sp


def _ensure_cached_system_prompt_static(agent, system_message=None) -> None:
    """Rebuild ``_cached_system_prompt_static`` when caching becomes active.

    Sessions restored under a cache-off primary skip the static-prefix rebuild
    (gated on ``_use_prompt_caching`` at restore time). A later failover to a
    cache-on provider would otherwise redecorate with ``static_system_prefix=
    None`` and silently fall back to the legacy system-plus-3 layout (#72626).

    Thin wrapper over :func:`agent.system_prompt.reconstruct_static_prefix`,
    which memoizes failed rebuilds so this stays cheap on the retry-loop hot
    path (it runs at the top of every attempt).
    """
    from agent.system_prompt import reconstruct_static_prefix

    reconstruct_static_prefix(
        agent, system_message=system_message, log_label="failover redecoration"
    )


def _peel_moa_guidance(
    messages: List[Dict[str, Any]],
    guidance: Any,
) -> List[Dict[str, Any]]:
    """Remove MoA reference guidance previously attached by ``_attach_reference_guidance``.

    Thin wrapper over :func:`agent.moa_loop.peel_reference_guidance` (kept
    adjacent to the attach so the forward/inverse shapes evolve together).
    Lazy import mirrors the module's other moa_loop touchpoints.
    """
    from agent.moa_loop import peel_reference_guidance

    return peel_reference_guidance(messages, guidance)


def _redecorate_prompt_cache_for_provider(
    agent,
    api_messages: List[Dict[str, Any]],
    *,
    system_message=None,
    moa_prepared: Optional[Dict[str, Any]] = None,
    tools_for_api: Optional[List[Dict[str, Any]]] = None,
) -> tuple[List[Dict[str, Any]], Optional[Dict[str, Any]]] | tuple[List[Dict[str, Any]], Optional[Dict[str, Any]], List[Dict[str, Any]]]:
    """Strip and re-apply cache_control for the *current* provider policy.

    Decoration runs once per call block before the retry loop for the primary
    provider. ``try_activate_fallback`` refreshes ``_use_prompt_caching`` /
    ``_use_native_cache_layout`` but the nine failover ``continue`` paths reused
    the old ``api_messages`` (#72626). Mirror ``_reapply_reasoning_echo_for_provider``
    by reshaping at the top of each retry attempt.

    The source list is the mutated in-flight request (image shrink / ASCII /
    reasoning_details recoveries already applied), never a pristine
    pre-decoration snapshot. MoA guidance is peeled and rebased without
    decoration; the acting aggregator plans its resolved destination later.
    """
    messages: List[Dict[str, Any]] = [
        dict(m) if isinstance(m, dict) else m for m in (api_messages or [])
    ]
    prepared = moa_prepared
    guidance = prepared.get("guidance") if isinstance(prepared, dict) else None
    if guidance:
        messages = _peel_moa_guidance(messages, guidance)

    strip_anthropic_cache_control(messages)
    planned_tools = strip_anthropic_tool_cache_control(
        tools_for_api if tools_for_api is not None else getattr(agent, "tools", [])
    )

    if prepared is not None and getattr(agent, "provider", None) == "moa":
        # Prepared MoA state is canonical: the synchronous acting-aggregator
        # sender owns its destination-local cache plan after it resolves the slot.
        completions = getattr(getattr(agent.client, "chat", None), "completions", None)
        rebase = getattr(completions, "rebase_prepared_request", None)
        if callable(rebase):
            prepared = rebase(prepared, messages)
            messages = prepared["messages"]
        if tools_for_api is None:
            return messages, prepared
        return messages, prepared, planned_tools

    # Direct attribute access matches the call-block decoration site — the
    # flags are unconditionally initialized on AIAgent, and a getattr
    # default here would mask a real init bug as silent cache-off.
    if agent._use_prompt_caching:
        _ensure_cached_system_prompt_static(agent, system_message=system_message)
        static = getattr(agent, "_cached_system_prompt_static", None)
        direct_tool_cache = getattr(
            agent,
            "_direct_native_anthropic_tool_cache_capability",
            lambda: False,
        )()
        from agent.prompt_caching import envelope_tool_part_cache_markers_supported

        plan = build_prompt_cache_plan(
            messages,
            planned_tools,
            # Clamp per-destination: a configured 1h regresses to 5m on
            # Qwen/Alibaba routes, whose context cache is 5m-only (#84733).
            cache_ttl=effective_cache_ttl(
                agent._cache_ttl,
                provider=agent.provider,
                model=agent.model,
            ),
            native_anthropic=agent._use_native_cache_layout,
            static_system_prefix=static if isinstance(static, str) else None,
            direct_native_tool_cache=direct_tool_cache,
            # LiteLLM-style envelope routes forward part-level markers into
            # tool_result.content[] → non-retryable 400 (#89886).
            tool_part_markers=envelope_tool_part_cache_markers_supported(
                getattr(agent, "provider", ""), getattr(agent, "base_url", "")
            ),
        )
        messages = plan.messages
        planned_tools = plan.tools

    if tools_for_api is None:
        return messages, prepared
    return messages, prepared, planned_tools


def _apply_context_engine_selection(
    agent: Any,
    api_messages: List[Dict[str, Any]],
    conversation_messages: List[Dict[str, Any]],
    incoming_message: Optional[Dict[str, Any]],
    *,
    logger: Any,
) -> List[Dict[str, Any]]:
    """Run the optional per-turn ``ContextEngine.select_context()`` hook.

    Returns the (possibly replaced) request message list. The hook is for
    context *selection / routing* (retrieval, topic routing, role switching),
    which is distinct from compression and fires every turn independent of
    ``should_compress()``.

    Fail-open by design: a missing hook, any exception, or an invalid return
    value yields the unmodified ``api_messages``. The result is request-only —
    persisted conversation history is never mutated here.
    """
    engine = getattr(agent, "context_compressor", None)
    if engine is None or not hasattr(engine, "select_context"):
        return api_messages

    # Skip the no-op base implementation so non-implementing engines —
    # including the built-in ContextCompressor — pay nothing per request:
    # no history copies below, no call. ``hasattr`` alone is not enough,
    # because the ABC defines a default ``select_context`` that every engine
    # inherits. Mirrors the base-method short-circuit in
    # ``_notify_context_engine_turn_complete``. Lazy import avoids any import
    # cycle with agent.context_engine.
    try:
        from agent.context_engine import ContextEngine as _CE
        if getattr(engine.select_context, "__func__", None) is _CE.select_context:
            return api_messages
    except Exception:
        pass

    session_label = getattr(agent, "session_id", None) or "-"
    # Pass shallow copies of the reference-only inputs so an engine that
    # mutates them in place cannot alter persisted transcript state. Only
    # ``request_messages`` (the per-call request list) is meant to be acted on,
    # and it may be replaced wholesale via the return value — never mutated in
    # place either. ``conversation_messages`` / ``incoming_message`` are
    # read-only context; copying enforces the request-only contract rather than
    # merely documenting it. Structural clones, not dict(m): a shallow copy
    # would leave nested containers (tool_calls, content parts) aliased to
    # the persisted history, so an engine writing into them would rewrite
    # the transcript (#80498 aliasing class).
    _conv_copy = [_clone_message_for_send(m) for m in conversation_messages] \
        if conversation_messages is not None else None
    _incoming_copy = _clone_message_for_send(incoming_message) if isinstance(incoming_message, dict) else incoming_message
    try:
        selected = engine.select_context(
            api_messages,
            conversation_messages=_conv_copy,
            incoming_message=_incoming_copy,
            budget_tokens=getattr(engine, "context_length", 0) or 0,
        )
    except Exception:
        logger.warning(
            "Context engine select_context hook failed; using unmodified "
            "request messages (session=%s)",
            session_label,
            exc_info=True,
        )
        return api_messages

    if selected is None:
        return api_messages
    # Require a NON-EMPTY list of dicts. An empty list must fall open to the
    # original request: ``all([])`` is ``True``, so without the emptiness check
    # a ``[]`` returned by a buggy/failing engine would replace a valid request
    # with an empty message list that the downstream sanitizers cannot restore,
    # reaching the provider as an invalid request instead of failing open.
    if isinstance(selected, list) and selected and all(isinstance(m, dict) for m in selected):
        return selected

    logger.warning(
        "Context engine select_context returned an invalid value "
        "(not a non-empty list of dicts); ignoring (session=%s)",
        session_label,
    )
    return api_messages


def _notify_context_engine_turn_complete(
    agent: Any,
    messages: List[Dict[str, Any]],
    *,
    usage: Optional[Dict[str, Any]] = None,
    logger: Any,
    **meta: Any,
) -> None:
    """Notify the active context engine that a user turn has finished.

    Calls the optional ``ContextEngine.on_turn_complete()`` observation hook
    once per turn, after the assistant/tool loop has produced the finalized
    transcript. The complement to ``select_context()`` (pre-request selection):
    this lets an engine ingest / index / summarize the completed turn.

    Fail-open: a missing or no-op hook, or any exception, is swallowed.
    ``messages`` is passed as a shallow copy so the engine cannot mutate the
    persisted transcript.
    """
    engine = getattr(agent, "context_compressor", None)
    hook = getattr(engine, "on_turn_complete", None)
    if engine is None or not callable(hook):
        return

    # Skip the no-op base implementation so non-implementing engines (incl.
    # the built-in compressor) pay nothing per turn. Lazy import avoids any
    # import cycle with agent.context_engine.
    try:
        from agent.context_engine import ContextEngine as _CE
        if getattr(hook, "__func__", None) is _CE.on_turn_complete:
            return
    except Exception:
        pass

    try:
        hook(
            # Structural clones: on_turn_complete receives the PERSISTED
            # history; a shallow dict(m) would let a hook write through
            # nested containers into the transcript (#80498 aliasing class).
            [_clone_message_for_send(m) for m in messages],
            usage=usage,
            **meta,
        )
    except Exception:
        logger.warning(
            "Context engine on_turn_complete hook failed (session=%s)",
            getattr(agent, "session_id", None) or "-",
            exc_info=True,
        )


def run_conversation(
    agent,
    user_message: Any,
    system_message: str = None,
    conversation_history: List[Dict[str, Any]] = None,
    task_id: str = None,
    stream_callback: Optional[callable] = None,
    persist_user_message: Optional[Any] = None,
    persist_user_timestamp: Optional[float] = None,
    persist_user_display_kind: Optional[str] = None,
    persist_user_display_metadata: Optional[Dict[str, Any]] = None,
    persist_user_platform_id: Optional[str] = None,
    moa_config: Optional[dict[str, Any]] = None,
) -> Dict[str, Any]:
    """
    Run a complete conversation with tool calling until completion.

    Args:
        user_message (str): The user's message/question
        system_message (str): Custom system message (optional, overrides ephemeral_system_prompt if provided)
        conversation_history (List[Dict]): Previous conversation messages (optional)
        task_id (str): Unique identifier for this task to isolate VMs between concurrent tasks (optional, auto-generated if not provided)
        stream_callback: Optional callback invoked with each text delta during streaming.
            Used by the TTS pipeline to start audio generation before the full response.
            When None (default), API calls use the standard non-streaming path.
        persist_user_message: Optional clean user message to store in
            transcripts/history when user_message contains API-only
            synthetic prefixes.
        persist_user_timestamp: Optional platform event timestamp to store
            as metadata on that persisted user message.
        persist_user_display_kind: Optional presentation type for a
            synthesized user turn (``auto_continue``, ``model_switch``, …).
            Display-only: transcript surfaces render the row as a timeline
            event instead of a user bubble, while the model still receives
            the message unchanged.
        persist_user_display_metadata: Optional payload for that event
            (e.g. a delegation's task count).
        persist_user_platform_id: Optional platform-side message id (e.g. the
            Discord/Telegram message id) to store as metadata on that
            persisted user message, so restart drain-window recovery can
            dedup an interrupted turn against the transcript.
                or queuing follow-up prefetch work.

    Returns:
        Dict: Complete conversation result with final response and message history
    """
    if moa_config is None:
        try:
            from hermes_cli.moa_config import decode_moa_turn

            _decoded_message, _decoded_moa_config = decode_moa_turn(user_message)
            if _decoded_moa_config is not None:
                user_message = _decoded_message
                moa_config = _decoded_moa_config
                if persist_user_message is None:
                    persist_user_message = _decoded_message
        except Exception:
            pass

    # The gateway caches agents across user turns.  Compression state is
    # per-turn: carrying a prior in-place boundary forward would make a later
    # uncompressed result look like a compacted transcript to gateway writers.
    agent._last_compaction_in_place = False
    agent._last_compression_attempt_recorded = False
    agent._last_compression_attempt_in_place = None

    # Adopt any ~/.hermes/.env credential/base-url edits made since the last
    # turn — a Settings save updates .env but not this worker's client, which
    # was built at agent init (#67821). No-op when .env is unchanged.
    try:
        agent._try_refresh_env_client_credentials()
    except Exception:
        logger.debug("per-turn env credential refresh failed", exc_info=True)

    # ── Per-turn setup (the prologue) ──
    # All once-per-turn setup — stdio guarding, retry-counter resets, user
    # message sanitization, todo/nudge hydration, system-prompt restore-or-
    # build, preflight compression, the ``pre_llm_call`` plugin hook,
    # external-memory prefetch, and crash-resilience persistence — lives in
    # ``build_turn_context``.  It mutates ``agent`` exactly as the inline code
    # did and returns the locals the loop below reads back.  See
    # ``agent/turn_context.py``.
    try:
        _ctx = build_turn_context(
            agent,
            user_message,
            system_message,
            conversation_history,
            task_id,
            stream_callback,
            persist_user_message,
            persist_user_timestamp,
            persist_user_display_kind=persist_user_display_kind,
            persist_user_display_metadata=persist_user_display_metadata,
            persist_user_platform_id=persist_user_platform_id,
            restore_or_build_system_prompt=_restore_or_build_system_prompt,
            install_safe_stdio=_install_safe_stdio,
            sanitize_surrogates=_sanitize_surrogates,
            summarize_user_message_for_log=_summarize_user_message_for_log,
            set_session_context=set_session_context,
            set_current_write_origin=set_current_write_origin,
            ra=_ra,
            # MoA turns append per-call aggregated context to the API copy of the
            # user message, so no byte-stable api_content sidecar can be stamped.
            moa_active=bool(moa_config),
        )
    except PreflightCompressionTimedOut as _preflight_timeout_exc:
        # Turn-start fail-closed boundary (#98424): preflight compression hit
        # the host's progress-aware timeout while the request was still
        # oversized, so no provider call was sent. Convert the typed exception
        # into the same typed recovery result the in-loop consumers return
        # (salvaged #98741 / PR #99710) instead of letting it escape to the
        # surfaces' generic exception handlers — the gateway deliberately
        # hides raw exception text from users, which would bury the
        # actionable "run /compress and retry" guidance and skip the
        # compression_exhausted clean-session recovery contract.
        logger.warning(
            "Turn-start preflight compression timed out — ending turn with "
            "typed recovery result: %s",
            _preflight_timeout_exc,
        )
        # build_turn_context registered this turn's in-flight tripwire slot
        # (note_turn_start) but the early return skips the persist funnel
        # that normally clears it — clear it here so the next turn does not
        # log a spurious "concurrent turns on one session" warning. The
        # inbound user row is intentionally NOT persisted on this path: the
        # gateway skips transcript persistence for compression_exhausted
        # results to prevent the session-growth loop (#7100), and the
        # auto-reset moves future input to a clean session.
        from agent.agent_runtime_helpers import note_turn_persisted

        note_turn_persisted(agent)
        # Intentionally NOT _COMPRESSION_TIMEOUT_FINAL_RESPONSE: the boundary's
        # exception text carries per-request context (token count, "provider
        # call was not sent") that is the actionable guidance this handler
        # exists to surface; the in-loop constant describes a different state
        # (compression ran and could not reduce).
        _final_response = str(_preflight_timeout_exc)
        return {
            "final_response": _final_response,
            "messages": list(conversation_history or []),
            "completed": False,
            "api_calls": 0,
            "error": _final_response,
            "partial": True,
            "failed": True,
            "compression_exhausted": True,
            "turn_exit_reason": "context_compression_timeout",
        }
    user_message = _ctx.user_message
    original_user_message = _ctx.original_user_message
    messages = _ctx.messages
    conversation_history = _ctx.conversation_history
    active_system_prompt = _ctx.active_system_prompt
    effective_task_id = _ctx.effective_task_id
    turn_id = _ctx.turn_id
    current_turn_user_idx = _ctx.current_turn_user_idx
    _should_review_memory = _ctx.should_review_memory
    _plugin_user_context = _ctx.plugin_user_context
    _ext_prefetch_cache = _ctx.ext_prefetch_cache

    # Commentary deduplication spans all provider continuations and tool calls
    # within one user turn, but must not suppress the same phrase next turn.
    agent._delivered_interim_texts = set()
    # A configured SessionDB append failure halts only the affected turn. A
    # cached gateway agent must recover on the next message if storage did.
    agent._incremental_persistence_failed = False
    # Cause of the most recent persistence failure this turn ('locked',
    # 'disk', or 'unknown' — see hermes_state.classify_persistence_error).
    # Reset alongside the failure flag so a lock-contention diagnosis from a
    # previous turn can never leak into this turn's user-facing explanation.
    agent._last_persistence_error_cause = None
    # Per-turn diagnostic: a failed compression-tip adoption in a previous
    # turn's flush must not be reported against this turn.
    agent._compression_adoption_failed = False

    # Main conversation loop counters (pure locals consumed by the loop below).
    api_call_count = 0
    final_response = None
    interrupted = False
    failed = False
    codex_ack_continuations = 0
    length_continue_retries = 0
    # Total outer-loop exceptions this turn (#92450) — see _MAX_OUTER_LOOP_ERRORS.
    _outer_error_count = 0
    truncated_tool_call_retries = 0
    truncated_response_parts: List[str] = []
    compression_attempts = 0
    # One resolved per-turn compression attempt cap, shared by every site that
    # consumes ``compression_attempts``: the pre-API pressure gate, the
    # overflow/413 retry handlers, and the post-tool compaction gate. The
    # counter is a consecutive unverified/ineffective-attempt backstop: a
    # completed compaction rearms it only after a successful provider response
    # reports a prompt below the threshold.
    # Config-driven via compression.max_attempts (parsed + validated in
    # agent_init); default 3 preserves the prior hardcoded behavior for
    # objects without the attribute (older pickles / minimal stubs).
    max_compression_attempts = getattr(agent, "max_compression_attempts", 3)
    _last_preflight_pressure: Optional[int] = None
    _preflight_compression_blocked = _ctx.preflight_compression_blocked
    # Armed when a compression host-timeout terminates the turn (#98722,
    # salvaged from #98741); finalize below reuses the gateway's existing
    # context-recovery contract (error/partial/compression_exhausted).
    _compression_timeout_exhausted = False
    _turn_exit_reason = "unknown"  # Diagnostic: why the loop ended
    # Last composed answer intentionally held back by a verification gate. If
    # that continuation consumes the remaining budget, this is the best
    # user-facing result available; it must not be confused with error or
    # recovery text produced by unrelated exit paths.
    _pending_verification_response = None
    # Tracks whether the pending verification candidate was already streamed
    # to the user as interim content. The finalizer uses this to set
    # ``_response_was_previewed`` ONLY when the pending candidate is actually
    # reused as the final response — not merely because any interim was
    # streamed. (#65919 review: response-loss blocker)
    _pending_verification_response_previewed = False
    # If pre-API compression fires after MoA advisors have produced guidance,
    # retain that ephemeral output and rebase it onto the compacted transcript
    # on the next loop iteration. This prevents a second advisor fan-out.
    pending_moa_prepared_request = None

    # Per-turn tally of consecutive successful credential-pool token refreshes,
    # keyed by (provider, pool-entry-id). A persistent upstream 401 lets
    # ``try_refresh_current()`` "succeed" forever on a single-entry OAuth pool,
    # so this tally caps same-entry refreshes and lets the fallback chain take
    # over instead of spinning. Reset here so each turn starts fresh. See #26080.
    agent._auth_pool_refresh_counts = {}

    # Reset the per-turn usage holder forwarded to the context engine's
    # on_turn_complete() observation hook. Set after each successful provider
    # response (see below); left as None on turns that never reach a response
    # (early failure / interrupt) so the hook receives None rather than a
    # stale prior turn's usage.
    agent._last_turn_usage = None

    # Optional opt-in runtime: if api_mode == codex_app_server, hand the
    # turn to the codex app-server subprocess (terminal/file ops/patching
    # all run inside Codex). Default Hermes path is bypassed entirely.
    # See agent/transports/codex_app_server_session.py for the adapter
    # and references/codex-app-server-runtime.md for the rationale.
    if agent.api_mode == "codex_app_server":
        return agent._run_codex_app_server_turn(
            user_message=user_message,
            original_user_message=original_user_message,
            messages=messages,
            effective_task_id=effective_task_id,
            should_review_memory=_should_review_memory,
        )

    while (api_call_count < agent.max_iterations and agent.iteration_budget.remaining > 0) or agent._budget_grace_call:
        _redirect_text = agent._drain_pending_redirect()
        if _redirect_text:
            _apply_active_turn_redirect(agent, messages, _redirect_text)
            if isinstance(original_user_message, str):
                original_user_message = (
                    f"{original_user_message}\n\n"
                    f"User correction during the turn: {_redirect_text}"
                )
            agent._persist_session(messages, conversation_history)

        # Reset per-turn checkpoint dedup so each iteration can take one snapshot
        agent._checkpoint_mgr.new_turn()

        # Check for interrupt request (e.g., user sent new message)
        if agent._interrupt_requested:
            interrupted = True
            _turn_exit_reason = "interrupted_by_user"
            if not agent.quiet_mode:
                agent._safe_print("\n⚡ Breaking out of tool loop due to interrupt...")
            break

        # Aggregate input budget for detached auxiliary forks (background
        # review, #93057): compaction bounds each request; this bounds the
        # review as a whole. Fires between iterations — the budget-crossing
        # request completed (its tool writes landed), and the tool loop stops
        # before the next provider call, mirroring the iteration-budget exit.
        if _review_input_budget_exhausted(agent):
            _turn_exit_reason = "review_input_budget_exhausted"
            if not agent.quiet_mode:
                agent._safe_print(
                    f"\n⏹️  Review input budget exhausted "
                    f"({int(agent.session_input_tokens):,} tokens) — stopping "
                    f"the review tool loop before the next provider call."
                )
            break
        
        api_call_count += 1
        agent._api_call_count = api_call_count
        agent._touch_activity(f"starting API call #{api_call_count}")

        # Grace call: the budget is exhausted but we gave the model one
        # more chance.  Consume the grace flag so the loop exits after
        # this iteration regardless of outcome.
        if agent._budget_grace_call:
            agent._budget_grace_call = False
        elif not agent.iteration_budget.consume():
            _turn_exit_reason = "budget_exhausted"
            if not agent.quiet_mode:
                agent._safe_print(f"\n⚠️  Iteration budget exhausted ({agent.iteration_budget.used}/{agent.iteration_budget.max_total} iterations used)")
            break

        # Fire step_callback for gateway hooks (agent:step event)
        if agent.step_callback is not None:
            try:
                prev_tools = []
                for _idx, _m in enumerate(reversed(messages)):
                    if _m.get("role") == "assistant" and _m.get("tool_calls"):
                        _fwd_start = len(messages) - _idx
                        _results_by_id = {}
                        for _tm in messages[_fwd_start:]:
                            if _tm.get("role") != "tool":
                                break
                            _tcid = _tm.get("tool_call_id")
                            if _tcid:
                                _results_by_id[_tcid] = _tm.get("content", "")
                        prev_tools = [
                            {
                                "name": tc["function"]["name"],
                                "result": _results_by_id.get(tc.get("id")),
                                "arguments": tc["function"].get("arguments"),
                            }
                            for tc in _m["tool_calls"]
                            if isinstance(tc, dict)
                        ]
                        break
                agent.step_callback(api_call_count, prev_tools)
            except Exception as _step_err:
                logger.debug("step_callback error (iteration %s): %s", api_call_count, _step_err)

        # Track tool-calling iterations for skill nudge.
        # Counter resets whenever skill_manage is actually used.
        if (agent._skill_nudge_interval > 0
                and "skill_manage" in agent.valid_tool_names):
            agent._iters_since_skill += 1
        
        # ── Pre-API-call /steer drain ──────────────────────────────────
        # If a /steer arrived during the previous API call (while the model
        # was thinking), drain it now — before we build api_messages — so
        # the model sees the steer text on THIS iteration.  Without this,
        # steers sent during an API call only land after the NEXT tool batch,
        # which may never come if the model returns a final response.
        #
        # We scan backwards for the last tool-role message in the messages
        # list.  If found, the steer is appended there.  If not (first
        # iteration, no tools yet), the steer stays pending for the next
        # tool batch — injecting into a user message would break role
        # alternation, and there's no tool output to piggyback on.
        _pre_api_steer = agent._drain_pending_steer()
        if _pre_api_steer:
            _injected = False
            for _si in range(len(messages) - 1, -1, -1):
                _sm = messages[_si]
                if isinstance(_sm, dict) and _sm.get("role") == "tool":
                    from agent.prompt_builder import format_steer_marker
                    marker = format_steer_marker(_pre_api_steer)
                    existing = _sm.get("content", "")
                    if isinstance(existing, str):
                        _sm["content"] = existing + marker
                    else:
                        # Multimodal content blocks — append text block
                        try:
                            blocks = list(existing) if existing else []
                            blocks.append({"type": "text", "text": marker})
                            _sm["content"] = blocks
                        except Exception:
                            pass
                    _injected = True
                    logger.debug(
                        "Pre-API-call steer drain: injected into tool msg at index %d",
                        _si,
                    )
                    break
            if not _injected:
                # No tool message to inject into — put it back so
                # the post-tool-execution drain picks it up later.
                _lock = getattr(agent, "_pending_steer_lock", None)
                if _lock is not None:
                    with _lock:
                        if agent._pending_steer:
                            agent._pending_steer = agent._pending_steer + "\n" + _pre_api_steer
                        else:
                            agent._pending_steer = _pre_api_steer
                else:
                    existing = getattr(agent, "_pending_steer", None)
                    agent._pending_steer = (existing + "\n" + _pre_api_steer) if existing else _pre_api_steer

        # ── Wall-clock run-budget wrap-up notice ───────────────────────
        # One-shot: when a run budget (agent.run_budget_seconds /
        # --run-budget) is active and 80% of it has elapsed, ask the model
        # to wrap up and deliver from the state it already has. Same
        # cache-safe channel as /steer (appended to the newest tool
        # result); dormant when no budget is set.
        if getattr(agent, "run_budget_seconds", None):
            _maybe_inject_run_budget_wrapup(agent, messages)

        # Prepare messages for API call
        # If we have an ephemeral system prompt, prepend it to the messages
        # Note: Reasoning is embedded in content via <think> tags for trajectory storage.
        # However, providers like Moonshot AI require a separate 'reasoning_content' field
        # on assistant messages with tool_calls. We handle both cases here.
        request_logger = getattr(agent, "logger", None) or logging.getLogger(__name__)
        # Per-agent validation cursor: skips re-json.loads-ing tool_call
        # arguments on history messages already validated in a previous
        # iteration. Identity-keyed (strong refs) — compression/undo/repair
        # rewriting the list breaks the prefix match and forces a re-scan
        # from the divergence point. See sanitize_tool_call_arguments.
        _sanitize_cursor = getattr(agent, "_sanitize_args_cursor", None)
        if _sanitize_cursor is None:
            _sanitize_cursor = {}
            try:
                agent._sanitize_args_cursor = _sanitize_cursor
            except Exception:
                pass
        repaired_tool_calls = agent._sanitize_tool_call_arguments(
            messages,
            logger=request_logger,
            session_id=agent.session_id,
            cursor=_sanitize_cursor,
        )
        if repaired_tool_calls > 0:
            request_logger.info(
                "Sanitized %s corrupted tool_call arguments before request (session=%s)",
                repaired_tool_calls,
                agent.session_id or "-",
            )

        # Drop legacy ghost rows from the incomplete #73146 else branch BEFORE
        # the alternation repair below: a hidden assistant placeholder whose
        # content/api_content is the raw interrupt scaffold. Replaying that as
        # an assistant message makes the model echo it and self-replicate
        # (#81841). Dropping before repair lets repair_message_sequence fix
        # any user→user adjacency the filter creates.
        messages = [
            msg for msg in messages
            if not (
                msg.get("display_kind") == "hidden"
                and msg.get("role") == "assistant"
                and (
                    (
                        isinstance(msg.get("content"), str)
                        and msg["content"].strip() == _INTERRUPT_SCAFFOLD_MARKER
                    )
                    or (
                        isinstance(msg.get("api_content"), str)
                        and msg["api_content"].strip() == _INTERRUPT_SCAFFOLD_MARKER
                    )
                )
            )
        ]

        # Defensive: repair malformed role-alternation before API call.
        # Catches cases where the history got wedged into a
        # ``tool → user`` or ``user → user`` tail (e.g. after empty-
        # response scaffolding was stripped and a new user message
        # landed after an orphan tool result). Most providers return
        # empty content on malformed sequences, which would otherwise
        # retrigger the empty-retry loop indefinitely.
        # repair_message_sequence_with_cursor also recomputes the SessionDB
        # flush cursor (_last_flushed_db_idx) when repair compacts the list,
        # so the turn-end flush doesn't skip the assistant/tool chain (#44837).
        from agent.agent_runtime_helpers import (
            fill_empty_non_final_wire_payload,
            repair_message_sequence_with_cursor,
        )
        repaired_seq = repair_message_sequence_with_cursor(agent, messages)
        if repaired_seq > 0:
            request_logger.info(
                "Repaired %s message-alternation violations before request (session=%s)",
                repaired_seq,
                agent.session_id or "-",
            )

        api_messages = []
        for idx, msg in enumerate(messages):

            # Structural clone, NOT msg.copy(): every in-place transform
            # below (canonicalize/repair, surrogate + non-ASCII sanitizers,
            # cache decoration) must be unable to reach the persisted
            # history through shared nested containers. See
            # _clone_message_for_send.
            api_msg = _clone_message_for_send(msg)

            # api_content is the persistence sidecar carrying the exact bytes
            # sent to the API for this message when they differ from the clean
            # stored content (see compose_user_api_content in turn_context).
            # It is bookkeeping, never a provider field — pop it from EVERY
            # outgoing copy.
            _api_content = api_msg.pop("api_content", None)

            # Display-only timeline metadata. Never a provider field — strip
            # from every outgoing copy so strict OpenAI-compatible backends
            # don't reject the request after a model switch or resumed typed
            # event row enters the live history.
            api_msg.pop("display_kind", None)
            api_msg.pop("display_metadata", None)

            # Durable row identity stamped by _rows_to_conversation so the
            # desktop can address a specific persisted message (reactions).
            # Bookkeeping, never a provider field — only the chat-completions
            # transport strips underscore keys, so drop it centrally here.
            api_msg.pop("_row_id", None)

            # Inject ephemeral context into the current turn's user message.
            # Sources: memory manager prefetch + plugin pre_llm_call hooks
            # with target="user_message" (the default).  Both are
            # API-call-time only — the original message in `messages` is
            # never mutated beyond the api_content stamp, so nothing leaks
            # into the clean transcript content.
            if idx == current_turn_user_idx and msg.get("role") == "user":
                if isinstance(_api_content, str) and _api_content:
                    # Stamped by the prologue from the same composition —
                    # reuse it so the persisted sidecar and the wire cannot
                    # drift, and so every pass this turn sends identical
                    # bytes (composed from msg["content"], never from a
                    # previously-injected copy).
                    api_msg["content"] = _api_content
                else:
                    # Callers that bypass the prologue stamping: compose live.
                    _composed = compose_user_api_content(
                        api_msg.get("content", ""),
                        _ext_prefetch_cache,
                        _plugin_user_context,
                    )
                    if _composed is not None:
                        api_msg["content"] = _composed
            elif (
                isinstance(_api_content, str)
                and _api_content
                and msg.get("role") in ("user", "assistant")
            ):
                # Historical message: replay the exact bytes sent when it was
                # live, so the provider prompt-cache prefix stays byte-stable
                # instead of diverging at the injection point and
                # re-prefilling everything after it. User rows carry the
                # prefetch/plugin injection sidecar; user AND assistant rows
                # can carry a sanitize-divergence sidecar (content that
                # ``get_messages_as_conversation``'s sanitize_context/strip
                # would rewrite on reload — see the capture in
                # ``_flush_messages_to_session_db``).
                api_msg["content"] = _api_content

            # For ALL assistant messages, pass reasoning back to the API
            # This ensures multi-turn reasoning context is preserved
            agent._copy_reasoning_content_for_api(msg, api_msg)

            # Remove 'reasoning' field - it's for trajectory storage only
            # We've copied it to 'reasoning_content' for the API above
            if "reasoning" in api_msg:
                api_msg.pop("reasoning")
            # Remove finish_reason - not accepted by strict APIs (e.g. Mistral)
            if "finish_reason" in api_msg:
                api_msg.pop("finish_reason")
            # Empty non-final user/assistant turns (#88955 hidden placeholders
            # and #96870 stream-death / host-fed empties): once display_kind
            # and api_content are stripped, the pre-call sanitizer would
            # re-heal the wire copy on every send and flood errors.log.
            # Fill the WIRE copy here so the sanitizer has nothing to do.
            # Durable history is not mutated. After reasoning copy so a
            # thinking-only turn keeps its payload and is not rewritten.
            fill_empty_non_final_wire_payload(
                api_msg, is_final=(idx == len(messages) - 1)
            )
            # _thinking_prefill survives here intentionally: the drop pass below
            # needs it. The transport strips all underscore keys before the wire.
            # Strip length-continuation marks; not every transport drops underscore keys.
            api_msg.pop("_length_continuation_fragment", None)
            api_msg.pop("_length_continuation_nudge", None)
            # Strip Codex Responses API fields (call_id, response_item_id) for
            # strict providers like Mistral, Fireworks, etc. that reject unknown fields.
            # Uses new dicts so the internal messages list retains the fields
            # for Codex Responses compatibility.
            if agent._should_sanitize_tool_calls():
                # In MoA mode, agent.model is the virtual preset name
                # (e.g. "closed"), not the actual aggregator model.  Use
                # the resolved aggregator model so Gemini aggregators
                # correctly preserve thought_signature (extra_content).
                _sanitize_model = agent.model
                if agent.provider == "moa":
                    if moa_config:
                        _agg = moa_config.get("aggregator") or {}
                        if _agg.get("model"):
                            _sanitize_model = _agg["model"]
                    if _sanitize_model == agent.model:
                        # Virtual-provider mode: no moa_config is threaded
                        # through run_conversation — the facade resolves the
                        # preset internally. Ask the facade for the resolved
                        # aggregator slot from the previous create() instead
                        # (set before any history replay that could carry
                        # thought_signature).
                        _moa_client = getattr(agent, "client", None)
                        _agg_slot = getattr(_moa_client, "last_aggregator_slot", None)
                        if _agg_slot and _agg_slot.get("model"):
                            _sanitize_model = _agg_slot["model"]
                agent._sanitize_tool_calls_for_strict_api(api_msg, model=_sanitize_model)
            # Keep 'reasoning_details' - OpenRouter uses this for multi-turn reasoning context
            # The signature field helps maintain reasoning continuity
            api_messages.append(api_msg)

        # Build the final system message: cached prompt + ephemeral system prompt.
        # Ephemeral additions are API-call-time only (not persisted to session DB).
        # External recall context is injected into the user message, not the system
        # prompt, so the stable cache prefix remains unchanged.
        #
        # NOTE: Plugin context from pre_llm_call hooks is injected into the
        # user message (see injection block above), NOT the system prompt.
        # This is intentional — system prompt modifications break the prompt
        # cache prefix.  The system prompt is reserved for Hermes internals.
        #
        # Hermes invariant: the system prompt is built ONCE per session
        # (cached on ``_cached_system_prompt``) and replayed verbatim on
        # every turn. ``apply_anthropic_cache_control`` may split its stable
        # prefix into content blocks on the wire, but the stored string and
        # its byte-stability remain unchanged.
        effective_system = active_system_prompt or ""
        if agent.ephemeral_system_prompt:
            effective_system = (effective_system + "\n\n" + agent.ephemeral_system_prompt).strip()
        if effective_system:
            api_messages = [{"role": "system", "content": effective_system}] + api_messages

        if moa_config:
            try:
                from agent.message_content import flatten_message_text as _flatten_mt
                from agent.moa_loop import _preset_temperature, aggregate_moa_context

                _moa_context = aggregate_moa_context(
                    user_prompt=(
                        original_user_message
                        if isinstance(original_user_message, str)
                        # Multimodal / decorated content list: extract the
                        # visible text instead of str()-ing a Python repr of
                        # the parts (which would leak base64 image payloads
                        # into the aggregator prompt).
                        else _flatten_mt(original_user_message)
                    ),
                    api_messages=api_messages,
                    reference_models=moa_config.get("reference_models") or [],
                    aggregator=moa_config.get("aggregator") or {},
                    temperature=_preset_temperature(moa_config, "reference_temperature"),
                    aggregator_temperature=_preset_temperature(moa_config, "aggregator_temperature"),
                    reference_max_tokens=moa_config.get("reference_max_tokens"),
                    # None = no per-preset override; inherit
                    # auxiliary.moa_reference.timeout via call_llm.
                    reference_timeout=(
                        float(moa_config["reference_timeout"])
                        if moa_config.get("reference_timeout")
                        else None
                    ),
                    degraded_reference_policy=str(
                        moa_config.get("degraded_reference_policy") or "loud"
                    ),
                    agent=agent,
                )
                if _moa_context:
                    for _msg in reversed(api_messages):
                        if _msg.get("role") == "user":
                            _base = _msg.get("content", "")
                            if isinstance(_base, str):
                                _msg["content"] = _base + "\n\n" + _moa_context
                            elif isinstance(_base, list):
                                # Multimodal user turn (text + image parts):
                                # append the MoA context as a trailing text
                                # part instead of silently dropping it.
                                _msg["content"] = [
                                    *_base,
                                    {"type": "text", "text": "\n\n" + _moa_context},
                                ]
                            break
            except Exception as _moa_exc:
                logger.warning("MoA context aggregation failed: %s", _moa_exc)

        # Inject ephemeral prefill messages right after the system prompt
        # but before conversation history. Same API-call-time-only pattern.
        if agent.prefill_messages:
            sys_offset = 1 if (api_messages and api_messages[0].get("role") == "system") else 0
            for idx, pfm in enumerate(agent.prefill_messages):
                # Structural clone: the sanitizers below run over
                # api_messages in place, and a shallow copy would let them
                # write through into agent.prefill_messages' nested
                # containers (same aliasing class as the history build).
                api_messages.insert(sys_offset + idx, _clone_message_for_send(pfm))

        # Per-turn context selection hook (additive, no-op by default).
        # Lets a context engine select/replace which context enters the
        # prompt for THIS call only — retrieval, topic routing, role/branch
        # switching — distinct from compression and independent of
        # should_compress(). Request-only: persisted history is untouched, so
        # caching/sanitization below operate on whatever the engine selected.
        # Fail-open (see _apply_context_engine_selection).
        _sel_incoming = (
            messages[current_turn_user_idx]
            if 0 <= current_turn_user_idx < len(messages)
            else None
        )
        api_messages = _apply_context_engine_selection(
            agent,
            api_messages,
            messages,
            _sel_incoming,
            logger=request_logger,
        )

        # Safety net: strip orphaned tool results / add stubs for missing
        # results before sending to the API.  Runs unconditionally — not
        # gated on context_compressor — so orphans from session loading or
        # manual message manipulation are always caught.
        api_messages = agent._sanitize_api_messages(api_messages)

        # One-time repeated-heal escalation notice (#96870): if the sanitizer
        # above just crossed the per-session heal threshold, deliver the
        # queued notice through the status/warning callback — the normal
        # out-of-band delivery channel (gateway status message / CLI print).
        # NEVER appended to messages/api_messages: conversation context and
        # the cached prompt prefix stay byte-identical.
        try:
            from agent.agent_runtime_helpers import (
                consume_pending_sanitizer_heal_notice,
            )

            _heal_notice = consume_pending_sanitizer_heal_notice()
            if _heal_notice:
                agent._emit_warning(_heal_notice)
        except Exception:
            # A notice hiccup must never break the send path.
            logger.debug("sanitizer heal notice delivery failed", exc_info=True)

        # Drop thinking-only assistant turns (reasoning but no visible
        # output and no tool_calls) and merge any adjacent user messages
        # left behind. Prevents Anthropic 400s ("The final block in an
        # assistant message cannot be `thinking`.") and equivalent errors
        # from third-party Anthropic-compatible gateways that can't replay
        # a thinking-only turn. Runs on the per-call copy only — the
        # stored conversation history keeps the reasoning block for the
        # UI transcript and session persistence.
        api_messages = agent._drop_thinking_only_and_merge_users(
            api_messages,
            drop_codex_reasoning_items=agent.api_mode != "codex_responses",
        )

        # Normalize message whitespace and tool-call JSON for consistent
        # prefix matching.  Ensures bit-perfect prefixes across turns,
        # which enables KV cache reuse on local inference servers
        # (llama.cpp, vLLM, Ollama) and improves cache hit rates for
        # cloud providers.  Operates on api_messages (the API copy) so
        # the original conversation history in `messages` is untouched.
        for am in api_messages:
            if isinstance(am.get("content"), str):
                am["content"] = am["content"].strip()
        _canonicalize_api_tool_calls(api_messages)

        # Proactively strip any surrogate characters before the API call.
        # Models served via Ollama (Kimi K2.5, GLM-5, Qwen) can return
        # lone surrogates (U+D800-U+DFFF) that crash json.dumps() inside
        # the OpenAI SDK. Sanitizing here prevents the 3-retry cycle.
        _sanitize_messages_surrogates(api_messages)

        # NOTE (empty-content class fix): no send-time pad loop here.  The
        # single owner for "never send a turn strict wire validation rejects
        # as empty" is ``repair_empty_non_final_messages``, which runs inside
        # ``_sanitize_api_messages`` above — the unconditional pre-send
        # chokepoint shared with the summary path.  Its placeholder is
        # non-whitespace, so it survives the whitespace-normalization pass
        # regardless of ordering (a single-space pad here previously had to
        # be sequenced after normalization to survive, forking the concept).

        # Build the request-local cache sections only after every transcript
        # mutation. The canonical tool registry stays undecorated.
        #
        # Runs LAST, after every message mutation above. Marking earlier
        # defeats the prefix stability the mutations exist to create:
        # ``_apply_cache_marker`` rewrites ``content`` from a plain string
        # into a ``[{"type": "text", ...}]`` block, so the marked messages
        # no longer match the ``isinstance(content, str)`` test in the
        # whitespace-normalization pass and silently keep their raw
        # leading/trailing whitespace. A tool result ending in "\n" is
        # therefore sent unstripped while it sits in the last-3 window and
        # stripped once it rolls out of it — the same message, different
        # bytes on consecutive turns, which breaks the prefix match at
        # exactly the point the breakpoints were meant to protect. Marking
        # last also keeps breakpoints off messages that the orphan sweep or
        # the thinking-only drop is about to remove or merge away.
        tools_for_api = agent.tools
        if agent._use_prompt_caching and agent.provider != "moa":
            from agent.prompt_caching import (
                envelope_tool_part_cache_markers_supported,
            )

            _static_system_prefix = getattr(agent, "_cached_system_prompt_static", None)
            _initial_cache_plan = build_prompt_cache_plan(
                api_messages,
                tools_for_api,
                # Clamp per-destination: a configured 1h regresses to 5m on
                # Qwen/Alibaba routes, whose context cache is 5m-only (#84733).
                cache_ttl=effective_cache_ttl(
                    agent._cache_ttl,
                    provider=agent.provider,
                    model=agent.model,
                ),
                native_anthropic=agent._use_native_cache_layout,
                static_system_prefix=(
                    _static_system_prefix
                    if isinstance(_static_system_prefix, str)
                    else None
                ),
                direct_native_tool_cache=agent._direct_native_anthropic_tool_cache_capability(),
                # LiteLLM-style envelope routes forward part-level markers into
                # tool_result.content[] → non-retryable 400 (#89886).
                tool_part_markers=envelope_tool_part_cache_markers_supported(
                    getattr(agent, "provider", ""), getattr(agent, "base_url", "")
                ),
            )
            api_messages = _initial_cache_plan.messages
            tools_for_api = _initial_cache_plan.tools

        # Build a persistent-MoA request before measuring compression pressure.
        # MoA reference output is injected into the aggregator prompt, but it
        # is deliberately ephemeral and therefore absent from ``messages``.
        # Preparing here makes the pre-API guard measure the exact prompt the
        # aggregator will receive; ``create()`` consumes this private prepared
        # request later without running the advisors a second time.
        _moa_prepared_request = None
        if agent.provider == "moa":
            _moa_completions = getattr(getattr(agent.client, "chat", None), "completions", None)
            if pending_moa_prepared_request is not None:
                _rebase_moa_request = getattr(_moa_completions, "rebase_prepared_request", None)
                if callable(_rebase_moa_request):
                    _moa_prepared_request = _rebase_moa_request(
                        pending_moa_prepared_request, api_messages
                    )
                pending_moa_prepared_request = None
            if _moa_prepared_request is None:
                _prepare_moa_request = getattr(_moa_completions, "prepare", None)
                if callable(_prepare_moa_request):
                    _moa_prepared_request = _prepare_moa_request(api_messages)
            if _moa_prepared_request is not None:
                api_messages = _moa_prepared_request["messages"]

        # One image-stripped message estimate feeds both figures. Was: a
        # str(msg) char walk (re-serialized base64 every call) + a second
        # messages walk inside estimate_request_tokens_rough. Tools added
        # separately (compression needs them: 50+ tools = 20-30K tokens).
        # total_chars is a rough (~) proxy — verbose log + hook metric only.
        # Charge stale thinking only when the active route actually replays
        # it (#84371): on codex_responses the text keys never ship (the
        # encrypted item sidecars — charged unconditionally — carry the
        # chain), so counting them here re-created the trigger/tail-walk
        # disagreement that dead-looped compaction.
        from agent.turn_context import _agent_stale_thinking_on_wire

        if _agent_stale_thinking_on_wire(agent):
            approx_tokens = estimate_messages_tokens_rough(api_messages)
        else:
            approx_tokens = estimate_messages_tokens_rough(
                api_messages, charge_stale_thinking=False
            )
        # Route-aware pressure: when the upcoming request is eligible for
        # native Responses compaction the transport will checkpoint-prune
        # the payload before sending — the generic durable-history figure
        # overstates the wire by orders of magnitude on a compacted session
        # and fires a 600s local compression the main request never needed
        # (#96995, mirroring the turn-prologue preflight #96644/#96155).
        request_pressure_tokens = _midturn_request_pressure_tokens(
            agent, api_messages, effective_system or "", approx_tokens
        )
        # Usage-anchored override: when the last provider response's exact
        # usage is still valid for the durable transcript, replace the
        # whole-history heuristic with anchor + delta-estimate. The anchor's
        # prompt_tokens already includes system prompt AND tool schemas as
        # the provider counted them, so no tools add-on is needed. Falls
        # back to the rough figures above when the anchor is stale/missing
        # (first request, post-compaction, usage-less providers).
        _anchored_pressure = anchored_context_tokens(
            messages, getattr(agent, "_usage_anchor", None)
        )
        if _anchored_pressure is not None:
            request_pressure_tokens = _anchored_pressure
        total_chars = approx_tokens * 4
        # Stash this request's rough estimate so update_from_response() can
        # pair it with the provider's real prompt count — the (rough, real)
        # anchor behind should_defer_preflight_to_real_usage()'s projection.
        # getattr guard: test doubles built via object.__new__ lack the method.
        _note_rough = getattr(
            agent.context_compressor, "note_request_rough_estimate", None
        )
        if callable(_note_rough):
            _note_rough(request_pressure_tokens)

        _runtime_context_error = _ollama_context_limit_error(
            agent, request_pressure_tokens
        )
        if _runtime_context_error:
            final_response = _runtime_context_error
            failed = True
            _turn_exit_reason = "ollama_runtime_context_too_small"
            append_message(messages, {"role": "assistant", "content": final_response})
            agent._emit_status("❌ Ollama runtime context is too small for Hermes tool use")
            api_call_count -= 1
            agent._api_call_count = api_call_count
            try:
                agent.iteration_budget.refund()
            except Exception:
                pass
            break

        # Pre-API pressure check. The turn-prologue preflight only saw the
        # incoming user message; a single turn can then grow by many large
        # tool results and leave no output budget before the NEXT call (the
        # live 271k/272k Codex failure). The post-response should_compress
        # gate at the tool-loop tail uses API-reported last_prompt_tokens,
        # which LAGS a just-appended huge tool result — so it misses this
        # case. Re-check here against the current request estimate.
        #
        # Mirror the turn-prologue preflight's guard chain exactly (see
        # turn_context.py): (1) defer when the rough estimate is known-noisy
        # relative to a recent real provider prompt that fit under threshold
        # (schema overhead / post-compaction over-count, #36718); (2) skip
        # while a same-session compression-failure cooldown is active; (3) then
        # should_compress() — reusing the canonical threshold_tokens (output
        # room already reserved by _compute_threshold_tokens) and its summary-
        # LLM cooldown + anti-thrash guards (#11529). compression_attempts is a
        # hard per-turn backstop shared with the overflow error handlers.
        _compressor = agent.context_compressor
        _preflight_threshold = int(
            getattr(_compressor, "threshold_tokens", 0) or 0
        )
        # A previous mid-turn preflight pass deliberately continued the loop so
        # API-only context and all sanitization could be rebuilt. Compare that
        # fully assembled request with the fully assembled request that caused
        # the pass. Raw ``messages`` are not equivalent here: they omit
        # api_content/plugin injections, prefills, MoA context, and ephemeral
        # system text.
        _previous_preflight_pressure = _last_preflight_pressure
        _last_preflight_pressure = None
        if (
            _previous_preflight_pressure is not None
            and request_pressure_tokens >= _preflight_threshold
            and not _compression_warrants_another_preflight_pass(
                _previous_preflight_pressure,
                request_pressure_tokens,
                _preflight_threshold,
            )
        ):
            # Stop proactive retries for this turn without consuming the
            # shared overflow-recovery budget. If the provider proves the
            # request truly does not fit, its error handler may still compact
            # with that stronger signal.
            _preflight_compression_blocked = True
            logger.warning(
                "Pre-API compression made insufficient progress: ~%s -> "
                "~%s request tokens; skipping additional preflight passes",
                f"{_previous_preflight_pressure:,}",
                f"{request_pressure_tokens:,}",
            )
        _defer_preflight = getattr(
            _compressor, "should_defer_preflight_to_real_usage", lambda _t: False
        )
        _compression_cooldown = getattr(
            _compressor, "get_active_compression_failure_cooldown", lambda: None
        )()
        if (
            agent.compression_enabled
            and not _review_fork_first_request_pending(agent)
            and len(messages) > 1
            and compression_attempts < max_compression_attempts
            and not _preflight_compression_blocked
            and not _defer_preflight(request_pressure_tokens)
            and not _compression_cooldown
            and _compressor.should_compress(request_pressure_tokens)
        ):
            # Managed local runtime: try GROWING the context window before
            # compressing (the window ladder's design order — compression is
            # the move of last resort, once the window is at the model's
            # native max or physics/speed say stop). Only fires for a
            # llamacpp-flavored provider whose base_url is the server this
            # process supervises; every other provider falls straight
            # through to compression, exactly as before.
            _grown_window = _maybe_grow_local_window(
                agent, _compressor, request_pressure_tokens
            )
            if _grown_window:
                # The server now grants a bigger window: recalibrate the
                # compressor to it and skip compression this pass — the
                # request that was over the OLD threshold fits the new one.
                _compressor.update_model(
                    agent.model,
                    _grown_window,
                    base_url=getattr(agent, "base_url", "") or "",
                    api_key=getattr(agent, "api_key", "") or "",
                    provider=getattr(agent, "provider", "") or "",
                    api_mode=getattr(agent, "api_mode", "") or "",
                )
                agent._buffer_status(
                    f"📈 Context window grown to {_grown_window // 1024}K "
                    f"(local model; conversation continues uncompressed)"
                )
                # This preflight iteration never reached the provider —
                # refund the consumed call/budget exactly as the compression
                # path below does before ITS continue.
                api_call_count -= 1
                agent._api_call_count = api_call_count
                agent.iteration_budget.refund()
                continue
            if _moa_prepared_request is not None:
                pending_moa_prepared_request = _moa_prepared_request
            compression_attempts += 1
            # Compression is actually running (block cleared / was never
            # blocked) — reset the blocked-overflow warning dedup so a future
            # blocked-over-threshold turn can warn again. Mirrors the
            # turn-context preflight reset (silent-overflow fix #62625).
            # getattr guard: test doubles built via object.__new__ lack the
            # method (gateway test-double pitfall) — treat absence as no-op.
            _clear_warn = getattr(agent, "_clear_context_overflow_warn", None)
            if callable(_clear_warn):
                _clear_warn()
            logger.info(
                "Pre-API compression: ~%s request tokens >= %s threshold "
                "(context=%s, attempt=%s/%s)",
                f"{request_pressure_tokens:,}",
                f"{int(getattr(_compressor, 'threshold_tokens', 0) or 0):,}",
                f"{int(getattr(_compressor, 'context_length', 0) or 0):,}"
                if getattr(_compressor, "context_length", 0) else "unknown",
                compression_attempts,
                max_compression_attempts,
            )
            _pre_api_status = automatic_compaction_status_message(
                _compressor,
                phase="pre_api",
                default_message=PRE_API_COMPRESSION_STATUS_TEMPLATE.format(
                    tokens=request_pressure_tokens
                ),
                approx_tokens=request_pressure_tokens,
                threshold_tokens=int(
                    getattr(_compressor, "threshold_tokens", 0) or 0
                ),
                context_length=int(
                    getattr(_compressor, "context_length", 0) or 0
                ),
                model=agent.model,
                attempt=compression_attempts,
                max_attempts=max_compression_attempts,
            )
            if _pre_api_status:
                agent._emit_status(_pre_api_status)
            _last_preflight_pressure = request_pressure_tokens
            _pre_api_input = messages
            messages, active_system_prompt = agent._compress_context(
                messages,
                system_message,
                approx_tokens=request_pressure_tokens,
                task_id=effective_task_id,
            )
            if context_compression_timed_out(agent):
                # Host progress-aware timeout (#98722, salvaged from #98741):
                # this preflight iteration never reached the provider. Refund
                # its provisional call/budget exactly like a successful
                # pre-API compaction, then stop before the unchanged oversized
                # request reaches the provider — its overflow error would only
                # invoke compression again on the same transcript with the
                # wait budget already spent.
                api_call_count -= 1
                agent._api_call_count = api_call_count
                agent.iteration_budget.refund()
                final_response = _COMPRESSION_TIMEOUT_FINAL_RESPONSE
                failed = True
                _compression_timeout_exhausted = True
                _turn_exit_reason = "context_compression_timeout"
                break
            if messages is _pre_api_input and (
                compression_skipped_due_to_lock(agent)
                or compression_blocked_transiently(agent)
            ):
                # #69870 lock-skip / #97488 transient-block: this pass
                # no-oped for a TEMPORARY reason (another path holds the
                # compression lock, or a timed cooldown/backoff guard is
                # active). That is a temporary DEFER, not evidence about
                # compressibility — refund the attempt (it must not burn the
                # shared overflow-recovery budget toward
                # compression_exhausted → gateway auto-reset, #9893/#35809)
                # and leave the insufficient-progress blocker unarmed.
                # Proceed with the current request: if it truly does not
                # fit, the provider's 413/overflow handler returns the soft
                # compression_deferred result with that stronger signal.
                compression_attempts -= 1
                _last_preflight_pressure = None
                if pending_moa_prepared_request is _moa_prepared_request:
                    pending_moa_prepared_request = None
            else:
                # Reset retry/empty-response state so the compacted request
                # gets a fresh chance instead of inheriting stale recovery
                # counters from the pre-compaction history.
                agent._empty_content_retries = 0
                agent._thinking_prefill_retries = 0
                agent._last_content_with_tools = None
                agent._last_content_tools_all_housekeeping = False
                agent._mute_post_response = False
                # Re-baseline the flush cursor for the compaction mode that just
                # ran. Legacy session-rotation returns None (the child session has
                # not seen the compacted transcript, so the next flush writes it
                # whole); in-place compaction returns list(messages) because the
                # compacted rows are already persisted under the same session id —
                # leaving None there would re-append them, doubling the active
                # context and retriggering compression. Mirrors the post-response
                # and preflight compaction sites; see
                # conversation_history_after_compression().
                conversation_history = conversation_history_after_compression(
                    agent, messages, conversation_history
                )
                # This preflight iteration never reaches the provider whether
                # we skip the turn (handoff guard below) or re-run the loop —
                # refund the consumed call/budget in BOTH cases, mirroring the
                # ollama_runtime_context_too_small early-exit above. Without
                # the refund on the break path, every skipped turn leaked one
                # iteration-budget unit for the agent's lifetime and
                # finalize_turn logged an api_call_count including a call that
                # was never made.
                api_call_count -= 1
                agent._api_call_count = api_call_count
                agent.iteration_budget.refund()
                if _should_skip_model_call_for_reference_handoff(
                    messages, user_message
                ):
                    # Reference-only handoff must not become the active turn
                    # after a completed assistant response (#80622).
                    logger.info(
                        "Skipping post-compaction model call: reference-only "
                        "handoff would be the sole active user turn (#80622)"
                    )
                    if not final_response:
                        final_response = _HANDOFF_SKIP_FINAL_RESPONSE
                    _turn_exit_reason = "compaction_handoff_not_actionable"
                    break
                continue
        elif (
            agent.compression_enabled
            and len(messages) > 1
            and compression_attempts < max_compression_attempts
            and not _defer_preflight(request_pressure_tokens)
            and _compression_cooldown
        ):
            # Blocked by the summary-LLM cooldown. Surface a deduped warning
            # (only when actually over threshold — should_compress_info
            # returns a None reason below threshold) so the user isn't left
            # with a silently growing context. Mirrors the turn-context
            # preflight and the loop-compaction guards (silent-overflow fix
            # #62625).
            _block_reason = None
            try:
                _block_reason = _compressor.should_compress_info(
                    request_pressure_tokens
                )[1]
            except Exception:
                _block_reason = None
            if _block_reason:
                agent._warn_context_overflow_blocked(
                    _block_reason,
                    request_pressure_tokens,
                    int(getattr(_compressor, "threshold_tokens", 0) or 0),
                )
        elif not agent.compression_enabled and len(messages) > 1:
            # Uncompressed session guard (#89297): compression is disabled, so
            # nothing shrinks a growing session. Reuse the unconditionally
            # computed request estimate (zero marginal cost — this site runs
            # before every provider request, covering turn-start AND mid-turn
            # tool-result growth) and surface a deduped, actionable warning
            # when the request exceeds the model context window. The dedup is
            # re-armed by the turn-context preflight once the session is back
            # under the window (manual /compress works with compression
            # disabled), so the guard warns again on a later re-overflow.
            # context_compressor always exists (agent_init constructs it even
            # when compression is disabled) and its context_length property
            # hard-floors at a positive default — no metadata re-resolution
            # needed here.
            _ctx_len = getattr(
                getattr(agent, "context_compressor", None), "context_length", None
            )
            if (
                isinstance(_ctx_len, int)
                and _ctx_len > 0
                and request_pressure_tokens > _ctx_len
            ):
                _warn_fn = getattr(
                    agent, "_warn_uncompressed_context_overflow", None
                )
                if callable(_warn_fn):
                    _warn_fn(request_pressure_tokens, _ctx_len)

        # Thinking spinner for quiet mode (animated during API call)
        thinking_spinner = None
        
        if not agent.quiet_mode:
            agent._vprint(f"\n{agent.log_prefix}🔄 Making API call #{api_call_count}/{agent.max_iterations}...")
            agent._vprint(f"{agent.log_prefix}   📊 Request size: {len(api_messages)} messages, ~{approx_tokens:,} tokens (~{total_chars:,} chars)")
            agent._vprint(f"{agent.log_prefix}   🔧 Available tools: {len(agent.tools) if agent.tools else 0}")
        else:
            # Animated thinking spinner in quiet mode
            face = random.choice(KawaiiSpinner.get_thinking_faces())
            verb = random.choice(KawaiiSpinner.get_thinking_verbs())
            if agent.thinking_callback:
                # CLI TUI mode: use prompt_toolkit widget instead of raw spinner
                # (works in both streaming and non-streaming modes)
                agent.thinking_callback(f"{face} {verb}...")
            elif not agent._has_stream_consumers() and agent._should_start_quiet_spinner():
                # Raw KawaiiSpinner only when no streaming consumers and the
                # spinner output has a safe sink.
                spinner_type = random.choice(['brain', 'sparkle', 'pulse', 'moon', 'star'])
                thinking_spinner = KawaiiSpinner(f"{face} {verb}...", spinner_type=spinner_type, print_fn=agent._print_fn)
                thinking_spinner.start()
        
        # Log request details if verbose
        if agent.verbose_logging:
            logging.debug(f"API Request - Model: {agent.model}, Messages: {len(messages)}, Tools: {len(agent.tools) if agent.tools else 0}")
            logging.debug(f"Last message role: {messages[-1]['role'] if messages else 'none'}")
            logging.debug(f"Total message size: ~{approx_tokens:,} tokens")
        
        api_start_time = time.time()
        retry_count = 0
        max_retries = agent._api_max_retries
        _retry = TurnRetryState()

        finish_reason = "stop"
        response = None  # Guard against UnboundLocalError if all retries fail
        api_kwargs = None  # Guard against UnboundLocalError in except handler
        api_request_id = f"{turn_id}:api:{api_call_count}"
        agent._current_api_request_id = api_request_id

        while retry_count < max_retries:
            # ── Nous Portal rate limit guard ──────────────────────
            # If another session already recorded that Nous is rate-
            # limited, skip the API call entirely.  Each attempt
            # (including SDK-level retries) counts against RPH and
            # deepens the rate limit hole.
            if agent.provider == "nous":
                try:
                    from agent.nous_rate_guard import (
                        nous_rate_limit_remaining,
                        format_remaining as _fmt_nous_remaining,
                    )
                    _nous_remaining = nous_rate_limit_remaining()
                    if _nous_remaining is not None and _nous_remaining > 0:
                        _nous_msg = (
                            f"Nous Portal rate limit active — "
                            f"resets in {_fmt_nous_remaining(_nous_remaining)}."
                        )
                        agent._buffer_vprint(
                            f"⏳ {_nous_msg} Trying fallback..."
                        )
                        agent._buffer_status(f"⏳ {_nous_msg}")
                        if agent._try_activate_fallback():
                            active_system_prompt = _sync_failover_system_message(
                                agent, api_messages, active_system_prompt)
                            retry_count = 0
                            compression_attempts = 0
                            _retry.primary_recovery_attempted = False
                            _retry.restart_with_rebuilt_messages = True
                            break
                        # No fallback available — surface buffered context
                        # so user sees the rate-limit message that led here.
                        agent._flush_status_buffer()
                        agent._persist_session(messages, conversation_history)
                        return {
                            "final_response": (
                                f"⏳ {_nous_msg}\n\n"
                                "No fallback provider available. "
                                "Try again after the reset, or add a "
                                "fallback provider in config.yaml."
                            ),
                            "messages": messages,
                            "api_calls": api_call_count,
                            "completed": False,
                            "failed": True,
                            "error": _nous_msg,
                        }
                except ImportError:
                    pass
                except Exception:
                    pass  # Never let rate guard break the agent loop

            try:
                agent._reset_stream_delivery_tracking()
                # Per-attempt first-chunk timestamp, refreshed each attempt so
                # a stale value from a previous API call can never leak into
                # the post_api_request hook (set again on stream success).
                agent._last_api_first_chunk_at = None
                # api_messages is built once, before this retry loop, while the
                # primary provider is active.  A mid-conversation fallback can
                # switch to a require-side provider (DeepSeek / Kimi / MiMo) that
                # rejects assistant turns lacking reasoning_content.  Re-apply the
                # echo-back pad for the *current* provider here (idempotent no-op
                # unless the active provider needs it) so the fallback request
                # isn't sent with stale, primary-shaped reasoning fields.
                agent._reapply_reasoning_echo_for_provider(api_messages)
                # Same story for prompt-cache decoration (#72626): try_activate_
                # fallback refreshes the policy flags, but the decorated list
                # still carries the primary's breakpoints (or none). Strip and
                # re-render for the current provider before building kwargs.
                api_messages, _moa_prepared_request, tools_for_api = (
                    _redecorate_prompt_cache_for_provider(
                        agent,
                        api_messages,
                        system_message=system_message,
                        moa_prepared=_moa_prepared_request,
                        tools_for_api=tools_for_api,
                    )
                )
                if tools_for_api == agent.tools:
                    api_kwargs = agent._build_api_kwargs(api_messages)
                else:
                    api_kwargs = agent._build_api_kwargs(
                        api_messages,
                        tools_for_api=tools_for_api,
                    )
                # Outbound-request surrogate chokepoint (#50959): the messages
                # were scrubbed above, but the rest of the request body —
                # tool/function descriptions (session_search's ±-heavy text is
                # the recorded repro), extra_body, system strings routed via
                # kwargs — can still carry invalid code points that providers
                # reject with a non-retryable HTTP 400 ("invalid unicode code
                # point"). One in-place walk here guarantees the entire
                # payload json.dumps()-safe regardless of which leaf produced
                # the string. Fast no-op when the payload is clean.
                _sanitize_structure_surrogates(api_kwargs)
                if agent._force_ascii_payload:
                    _sanitize_structure_non_ascii(api_kwargs)
                if agent.api_mode == "codex_responses":
                    api_kwargs = agent._get_transport().preflight_kwargs(
                        api_kwargs,
                        allow_stream=False,
                        is_github_responses=agent._is_copilot_url(),
                        sanitize_harmony_tokens=agent._is_codex_backend(),
                    )
                # OpenRouter response caching replays identical successful
                # responses verbatim, including empty completions. An empty-
                # response retry must reach the provider instead of replaying
                # the response that triggered the retry.
                if agent._empty_content_retries > 0 and agent._is_openrouter_url():
                    _xh = dict(api_kwargs.get("extra_headers") or {})
                    _xh["X-OpenRouter-Cache"] = "false"
                    api_kwargs["extra_headers"] = _xh
                # Copilot x-initiator: the first API call of a user turn is
                # marked "user" so Copilot bills a premium request; tool-loop
                # follow-ups keep the default "agent" header (#3040).
                if getattr(agent, "_is_user_initiated_turn", False) and agent._is_copilot_url():
                    _xh = dict(api_kwargs.get("extra_headers") or {})
                    _xh["x-initiator"] = "user"
                    api_kwargs["extra_headers"] = _xh
                    agent._is_user_initiated_turn = False
                try:
                    from hermes_cli.middleware import apply_llm_request_middleware

                    _llm_request_mw = apply_llm_request_middleware(
                        api_kwargs,
                        task_id=effective_task_id,
                        turn_id=turn_id,
                        api_request_id=api_request_id,
                        session_id=agent.session_id or "",
                        platform=agent.platform or "",
                        model=agent.model,
                        provider=agent.provider,
                        base_url=agent.base_url,
                        api_mode=agent.api_mode,
                        api_call_count=api_call_count,
                    )
                    api_kwargs = _llm_request_mw.payload
                    _original_api_kwargs = _llm_request_mw.original_payload
                    _llm_middleware_trace = _llm_request_mw.trace
                except Exception:
                    _original_api_kwargs = dict(api_kwargs)
                    _llm_middleware_trace = []

                try:
                    from hermes_cli.lifecycle import (
                        has_hook,
                        invoke_hook as _invoke_hook,
                    )
                    if has_hook("pre_api_request"):
                        request_messages = api_kwargs.get("messages")
                        if not isinstance(request_messages, list):
                            request_messages = api_kwargs.get("input")
                        if not isinstance(request_messages, list):
                            request_messages = api_messages
                        # Shallow-copy the outer list so plugins that retain the
                        # reference for async snapshotting don't observe later
                        # mutations of api_messages.  The inner dicts are not
                        # mutated by the agent loop, so a shallow copy is
                        # sufficient; a deepcopy would walk every tool result
                        # and base64 image on every API call.
                        #
                        # The ``request_messages`` and ``conversation_history``
                        # kwargs below are pre-existing raw passthroughs
                        # consumed by the bundled langfuse plugin
                        # (``plugins/observability/langfuse/__init__.py:_coerce_request_messages``).
                        # They predate ``request`` and are intentionally NOT
                        # sanitised — secrets are not expected here because
                        # ``api_kwargs`` is the same object passed to the
                        # provider client.  New consumers should read the
                        # sanitised view from ``request["body"]["messages"]``.
                        _request_payload = agent._api_request_payload_for_hook(api_kwargs)
                        # Anthropic (``system``) and Responses/Codex
                        # (``instructions``) move the system prompt out of
                        # messages; pass it explicitly for observability
                        # plugins (Langfuse).
                        system_prompt_for_hooks = _system_prompt_for_hooks(
                            api_kwargs, request_messages
                        )
                        _invoke_hook(
                            "pre_api_request",
                            task_id=effective_task_id,
                            turn_id=turn_id,
                            api_request_id=api_request_id,
                            session_id=agent.session_id or "",
                            user_message=original_user_message,
                            conversation_history=list(messages),
                            platform=agent.platform or "",
                            model=agent.model,
                            provider=agent.provider,
                            base_url=agent.base_url,
                            api_mode=agent.api_mode,
                            api_call_count=api_call_count,
                            retry_count=retry_count,
                            request_messages=list(request_messages)
                            if isinstance(request_messages, list)
                            else [],
                            system_prompt=system_prompt_for_hooks,
                            message_count=len(api_messages),
                            tool_count=len(agent.tools or []),
                            approx_input_tokens=approx_tokens,
                            request_char_count=total_chars,
                            max_tokens=agent.max_tokens,
                            started_at=api_start_time,
                            middleware_trace=list(_llm_middleware_trace),
                            request=_request_payload,
                        )
                except Exception:
                    pass

                if env_var_enabled("HERMES_DUMP_REQUESTS"):
                    agent._dump_api_request_debug(api_kwargs, reason="preflight")

                # This object is private to the in-process MoA facade.  Add it
                # only after middleware, hooks, and debug dumps so none of them
                # attempts to serialize it as part of the provider payload.
                if _moa_prepared_request is not None and agent.provider == "moa":
                    # Re-read the live client instead of trusting the one that
                    # prepared the request above. Credential rotation, provider
                    # fallback and dead-connection cleanup all rebuild
                    # agent.client from _client_kwargs between attempts, and
                    # pending_moa_prepared_request carries a prepared request
                    # across exactly that boundary. The rebuilt client is a
                    # native OpenAI client while provider stays "moa", so this
                    # private key would reach the SDK as an unexpected keyword
                    # — a non-retryable TypeError that kills every remaining
                    # turn on the session.
                    if _moa_client_consumes_prepared_request(agent.client):
                        api_kwargs["_moa_prepared_request"] = _moa_prepared_request
                    else:
                        logger.warning(
                            "MoA client replaced mid-turn (client=%s); sending the "
                            "prepared prompt without the MoA handshake",
                            type(agent.client).__name__,
                        )

                # Always prefer the streaming path — even without stream
                # consumers.  Streaming gives us fine-grained health
                # checking (90s stale-stream detection, 60s read timeout)
                # that the non-streaming path lacks.  Without this,
                # subagents and other quiet-mode callers can hang
                # indefinitely when the provider keeps the connection
                # alive with SSE pings but never delivers a response.
                # The streaming path is a no-op for callbacks when no
                # consumers are registered, and falls back to non-
                # streaming automatically if the provider doesn't
                # support it.
                def _stop_spinner():
                    nonlocal thinking_spinner
                    if thinking_spinner:
                        thinking_spinner.stop("")
                        thinking_spinner = None
                    if agent.thinking_callback:
                        agent.thinking_callback("")

                _use_streaming = True
                # Provider signaled "stream not supported" on a previous
                # attempt — switch to non-streaming for the rest of this
                # session instead of re-failing every retry.
                if getattr(agent, "_disable_streaming", False):
                    _use_streaming = False
                # An ACP client communicates via subprocess stdio and returns a
                # plain SimpleNamespace — not an iterable stream.  Keyed on the
                # `acp://` scheme rather than one vendor, so any ACP client is
                # excluded.  Mirror the ACP exclusion used for Responses API
                # upgrade (lines ~1083-1085).
                elif (
                    agent.provider in {"copilot-acp"}
                    or str(agent.base_url or "").lower().startswith("acp://")
                    or str(agent.base_url or "").lower().startswith("acp+tcp://")
                ):
                    _use_streaming = False
                # MoA streams only when a display/TTS consumer is present to
                # receive the deltas. MoAChatCompletions.create() honors
                # stream=True (runs the references, then returns the aggregator's
                # raw token stream) and is reached here because, for provider
                # "moa", _create_request_openai_client returns the MoA facade
                # itself. Without consumers (quiet mode, subagents, health-check
                # probes) we keep the complete-response path: the facade returns a
                # whole response when stream is not requested, preserving the
                # prior behavior for those callers.
                elif agent.provider == "moa" and not agent._has_stream_consumers():
                    _use_streaming = False
                elif not agent._has_stream_consumers():
                    # No display/TTS consumer. Still prefer streaming for
                    # health checking, but skip for Mock clients in tests
                    # (mocks return SimpleNamespace, not stream iterators).
                    from unittest.mock import Mock
                    if isinstance(getattr(agent, "client", None), Mock):
                        _use_streaming = False

                def _perform_api_call(next_api_kwargs):
                    if agent.api_mode == "codex_responses":
                        next_api_kwargs = agent._get_transport().preflight_kwargs(
                            next_api_kwargs,
                            allow_stream=False,
                            is_github_responses=agent._is_copilot_url(),
                            sanitize_harmony_tokens=agent._is_codex_backend(),
                        )
                    if _use_streaming:
                        return agent._interruptible_streaming_api_call(
                            next_api_kwargs, on_first_delta=_stop_spinner
                        )
                    from agent import relay_llm

                    return relay_llm.execute(
                        next_api_kwargs,
                        agent._interruptible_api_call,
                        session_id=str(agent.session_id or ""),
                        name=str(agent.provider or "provider"),
                        model_name=str(agent.model or ""),
                        metadata={
                            "api_mode": agent.api_mode,
                            "api_request_id": api_request_id,
                            "call_role": (
                                "delegated"
                                if getattr(agent, "is_subagent", False)
                                else "fallback"
                                if int(getattr(agent, "_fallback_index", 0) or 0) > 0
                                else "primary"
                            ),
                            "retry_count": retry_count,
                        },
                        defer_logical_completion=True,
                    )

                from hermes_cli.middleware import run_llm_execution_middleware

                _model_request_active = getattr(agent, "_model_request_active", None)
                _redirect_lock = getattr(agent, "_pending_redirect_lock", None)
                if _redirect_lock is not None:
                    with _redirect_lock:
                        if _model_request_active is not None:
                            _model_request_active.set()
                elif _model_request_active is not None:
                    _model_request_active.set()
                _redirect_crossed_response = False
                try:
                    response = run_llm_execution_middleware(
                        api_kwargs,
                        _perform_api_call,
                        original_request=_original_api_kwargs,
                        task_id=effective_task_id,
                        turn_id=turn_id,
                        api_request_id=api_request_id,
                        session_id=agent.session_id or "",
                        platform=agent.platform or "",
                        model=agent.model,
                        provider=agent.provider,
                        base_url=agent.base_url,
                        api_mode=agent.api_mode,
                        api_call_count=api_call_count,
                        middleware_trace=list(_llm_middleware_trace),
                    )
                finally:
                    if _redirect_lock is not None:
                        with _redirect_lock:
                            if _model_request_active is not None:
                                _model_request_active.clear()
                            _redirect_crossed_response = bool(
                                agent._pending_redirect
                            )
                    else:
                        if _model_request_active is not None:
                            _model_request_active.clear()
                        _redirect_crossed_response = agent._has_pending_redirect()
                if _redirect_crossed_response:
                    # The response and redirect can cross on different threads:
                    # redirect() observed the request as active just before this
                    # call returned. Discard that now-stale response and rebuild
                    # from the correction rather than silently losing it.
                    if thinking_spinner:
                        thinking_spinner.stop("")
                        thinking_spinner = None
                    if agent.thinking_callback:
                        agent.thinking_callback("")
                    if agent.clear_interrupt(preserve_redirect=True):
                        _retry.restart_with_redirected_messages = True
                    else:
                        interrupted = True
                    break
                
                api_duration = time.time() - api_start_time
                
                # Stop thinking spinner silently -- the response box or tool
                # execution messages that follow are more informative.
                if thinking_spinner:
                    thinking_spinner.stop("")
                    thinking_spinner = None
                if agent.thinking_callback:
                    agent.thinking_callback("")
                
                if not agent.quiet_mode:
                    agent._vprint(f"{agent.log_prefix}⏱️  API call completed in {api_duration:.2f}s")
                
                if agent.verbose_logging:
                    # Log response with provider info if available
                    resp_model = getattr(response, 'model', 'N/A') if response else 'N/A'
                    logging.debug(f"API Response received - Model: {resp_model}, Usage: {response.usage if hasattr(response, 'usage') else 'N/A'}")
                
                # Validate response shape before proceeding
                response_invalid = False
                error_details = []
                if agent.api_mode == "codex_responses":
                    _ct_v = agent._get_transport()
                    if not _ct_v.validate_response(response):
                        if response is None:
                            response_invalid = True
                            error_details.append("response is None")
                        else:
                            # Provider returned a terminal failure (e.g. quota exhaustion).
                            # Treat as invalid so the fallback chain is triggered instead of
                            # letting the error bubble up outside the retry/fallback loop.
                            _codex_resp_status = str(getattr(response, "status", "") or "").strip().lower()
                            if _codex_resp_status in {"failed", "cancelled"}:
                                _codex_error_obj = getattr(response, "error", None)
                                _codex_error_msg = (
                                    _codex_error_obj.get("message") if isinstance(_codex_error_obj, dict)
                                    else str(_codex_error_obj) if _codex_error_obj
                                    else f"Responses API returned status '{_codex_resp_status}'"
                                )
                                logger.warning(
                                    "Codex response status='%s' (error=%s). Routing to fallback. %s",
                                    _codex_resp_status, _codex_error_msg,
                                    agent._client_log_context(),
                                )
                                response_invalid = True
                                error_details.append(f"response.status={_codex_resp_status}: {_codex_error_msg}")
                            else:
                                # output_text fallback: stream backfill may have failed
                                # but normalize can still recover from output_text
                                _out_text = getattr(response, "output_text", None)
                                _out_text_stripped = _out_text.strip() if isinstance(_out_text, str) else ""
                                if _out_text_stripped:
                                    logger.debug(
                                        "Codex response.output is empty but output_text is present "
                                        "(%d chars); deferring to normalization.",
                                        len(_out_text_stripped),
                                    )
                                else:
                                    _resp_status = getattr(response, "status", None)
                                    _resp_incomplete = getattr(response, "incomplete_details", None)
                                    logger.warning(
                                        "Codex response.output is empty after stream backfill "
                                        "(status=%s, incomplete_details=%s, model=%s). %s",
                                        _resp_status, _resp_incomplete,
                                        getattr(response, "model", None),
                                        f"api_mode={agent.api_mode} provider={agent.provider}",
                                    )
                                    response_invalid = True
                                    error_details.append("response.output is empty")
                elif agent.api_mode == "anthropic_messages":
                    _tv = agent._get_transport()
                    if not _tv.validate_response(response):
                        response_invalid = True
                        if response is None:
                            error_details.append("response is None")
                        else:
                            error_details.append("response.content invalid (not a non-empty list)")
                elif agent.api_mode == "bedrock_converse":
                    _btv = agent._get_transport()
                    if not _btv.validate_response(response):
                        response_invalid = True
                        if response is None:
                            error_details.append("response is None")
                        else:
                            error_details.append("Bedrock response invalid (no output or choices)")
                else:
                    _ctv = agent._get_transport()
                    if not _ctv.validate_response(response):
                        response_invalid = True
                        if response is None:
                            error_details.append("response is None")
                        elif not hasattr(response, 'choices'):
                            error_details.append("response has no 'choices' attribute")
                        elif response.choices is None:
                            error_details.append("response.choices is None")
                        else:
                            error_details.append("response.choices is empty")

                if response_invalid:
                    agent._invoke_api_request_error_hook(
                        task_id=effective_task_id,
                        turn_id=turn_id,
                        api_request_id=api_request_id,
                        api_call_count=api_call_count,
                        api_start_time=api_start_time,
                        api_kwargs=api_kwargs,
                        error_type="InvalidAPIResponse",
                        error_message=", ".join(error_details) or "Invalid API response",
                        status_code=getattr(getattr(response, "error", None), "code", None),
                        retry_count=retry_count,
                        max_retries=max_retries,
                        retryable=True,
                        reason="invalid_response",
                    )
                    # Stop spinner silently — retry status is now buffered
                    # and only surfaced if every retry+fallback exhausts.
                    if thinking_spinner:
                        thinking_spinner.stop("")
                        thinking_spinner = None
                    if agent.thinking_callback:
                        agent.thinking_callback("")
                    
                    # Invalid response — could be rate limiting, provider timeout,
                    # upstream server error, or malformed response.
                    retry_count += 1
                    
                    # Eager fallback: empty/malformed responses are a common
                    # rate-limit symptom.  Switch to fallback immediately
                    # rather than retrying with extended backoff.
                    if agent._fallback_index < len(agent._fallback_chain):
                        agent._buffer_status("⚠️ Empty/malformed response — switching to fallback...")
                    if agent._try_activate_fallback():
                        active_system_prompt = _sync_failover_system_message(
                            agent, api_messages, active_system_prompt)
                        retry_count = 0
                        compression_attempts = 0
                        _retry.primary_recovery_attempted = False
                        _retry.restart_with_rebuilt_messages = True
                        break

                    # Check for error field in response (some providers include this)
                    error_msg = "Unknown"
                    provider_name = "Unknown"
                    if response and hasattr(response, 'error') and response.error:
                        error_msg = str(response.error)
                        # Try to extract provider from error metadata
                        if hasattr(response.error, 'metadata') and response.error.metadata:
                            provider_name = response.error.metadata.get('provider_name', 'Unknown')
                    elif response and hasattr(response, 'message') and response.message:
                        error_msg = str(response.message)
                    
                    # Try to get provider from model field (OpenRouter often returns actual model used)
                    if provider_name == "Unknown" and response and hasattr(response, 'model') and response.model:
                        provider_name = f"model={response.model}"
                    
                    # Check for x-openrouter-provider or similar metadata
                    if provider_name == "Unknown" and response:
                        # Log all response attributes for debugging
                        resp_attrs = {k: str(v)[:100] for k, v in vars(response).items() if not k.startswith('_')}
                        if agent.verbose_logging:
                            logging.debug(f"Response attributes for invalid response: {resp_attrs}")
                    
                    # Extract error code from response for contextual diagnostics
                    _resp_error_code = None
                    if response and hasattr(response, 'error') and response.error:
                        _code_raw = getattr(response.error, 'code', None)
                        if _code_raw is None and isinstance(response.error, dict):
                            _code_raw = response.error.get('code')
                        if _code_raw is not None:
                            try:
                                _resp_error_code = int(_code_raw)
                            except (TypeError, ValueError):
                                pass

                    # Build a human-readable failure hint from the error code
                    # and response time, instead of always assuming rate limiting.
                    if _resp_error_code == 524:
                        _failure_hint = f"upstream provider timed out (Cloudflare 524, {api_duration:.0f}s)"
                    elif _resp_error_code == 504:
                        _failure_hint = f"upstream gateway timeout (504, {api_duration:.0f}s)"
                    elif _resp_error_code == 429:
                        _failure_hint = "rate limited by upstream provider (429)"
                    elif _resp_error_code in {500, 502}:
                        _failure_hint = f"upstream server error ({_resp_error_code}, {api_duration:.0f}s)"
                    elif _resp_error_code in {503, 529}:
                        _failure_hint = f"upstream provider overloaded ({_resp_error_code})"
                    elif _resp_error_code is not None:
                        _failure_hint = f"upstream error (code {_resp_error_code}, {api_duration:.0f}s)"
                    elif api_duration < 10:
                        _failure_hint = f"fast response ({api_duration:.1f}s) — likely rate limited"
                    elif api_duration > 60:
                        _failure_hint = f"slow response ({api_duration:.0f}s) — likely upstream timeout"
                    else:
                        _failure_hint = f"response time {api_duration:.1f}s"

                    agent._buffer_vprint(f"⚠️  Invalid API response (attempt {retry_count}/{max_retries}): {', '.join(error_details)}")
                    agent._buffer_vprint(f"   🏢 Provider: {provider_name}")
                    cleaned_provider_error = agent._clean_error_message(error_msg)
                    agent._buffer_vprint(f"   📝 Provider message: {cleaned_provider_error}")
                    agent._buffer_vprint(f"   ⏱️  {_failure_hint}")
                    
                    if retry_count >= max_retries:
                        # Try fallback before giving up
                        if agent._has_pending_fallback():
                            agent._buffer_status(f"⚠️ Max retries ({max_retries}) for invalid responses — trying fallback...")
                        if agent._try_activate_fallback():
                            active_system_prompt = _sync_failover_system_message(
                                agent, api_messages, active_system_prompt)
                            retry_count = 0
                            compression_attempts = 0
                            _retry.primary_recovery_attempted = False
                            _retry.restart_with_rebuilt_messages = True
                            break
                        # Terminal — flush buffered retry trace so user sees what happened.
                        agent._flush_status_buffer()
                        agent._emit_status(f"❌ Max retries ({max_retries}) exceeded for invalid responses. Giving up.")
                        logger.error("%sInvalid API response after %d retries.", agent.log_prefix, max_retries)
                        agent._persist_session(messages, conversation_history)
                        _final_response = f"Invalid API response after {max_retries} retries: {_failure_hint}"
                        return {
                            "final_response": _final_response,
                            "messages": messages,
                            "completed": False,
                            "api_calls": api_call_count,
                            "error": _final_response,
                            "failed": True  # Mark as failure for filtering
                        }
                    
                    # Backoff before retry — jittered exponential: 5s base, 120s cap
                    wait_time = jittered_backoff(retry_count, base_delay=5.0, max_delay=120.0)
                    agent._buffer_vprint(f"⏳ Retrying in {wait_time:.1f}s ({_failure_hint})...")
                    logger.warning("Invalid API response (retry %d/%d): %s | Provider: %s", retry_count, max_retries, ', '.join(error_details), provider_name)
                    
                    # Sleep in small increments to stay responsive to interrupts
                    sleep_end = time.time() + wait_time
                    _backoff_touch_counter = 0
                    while time.time() < sleep_end:
                        if agent._interrupt_requested:
                            # A redirect uses the interrupt machinery to cancel
                            # only the live request. Aborting the retry here
                            # with clear_interrupt() would DESTROY the pending
                            # correction and kill the turn with "Operation
                            # interrupted" — the exact mid-stream steer loss
                            # users hit when a redirect lands during provider
                            # backoff. Rebuild from the correction instead,
                            # mirroring the InterruptedError handler.
                            if agent.clear_interrupt(preserve_redirect=True):
                                _retry.restart_with_redirected_messages = True
                                break
                            agent._vprint(f"{agent.log_prefix}⚡ Interrupt detected during retry wait, aborting.", force=True)
                            _interrupt_text = f"Operation interrupted during retry ({_failure_hint}, attempt {retry_count}/{max_retries})."
                            close_interrupted_tool_sequence(messages, _interrupt_text)
                            agent._persist_session(messages, conversation_history)
                            agent.clear_interrupt()
                            return {
                                "final_response": _interrupt_text,
                                "messages": messages,
                                "api_calls": api_call_count,
                                "completed": False,
                                "interrupted": True,
                            }
                        time.sleep(0.2)
                        # Touch activity every ~30s so the gateway's inactivity
                        # monitor knows we're alive during backoff waits.
                        _backoff_touch_counter += 1
                        if _backoff_touch_counter % 150 == 0:  # 150 × 0.2s = 30s
                            agent._touch_activity(
                                f"retry backoff ({retry_count}/{max_retries}), "
                                f"{int(sleep_end - time.time())}s remaining"
                            )
                    if _retry.restart_with_redirected_messages:
                        break  # rebuild this iteration from the correction
                    continue  # Retry the API call

                agent._turn_received_provider_response = True

                # Check finish_reason before proceeding
                if agent.api_mode == "codex_responses":
                    status = getattr(response, "status", None)
                    if isinstance(status, str):
                        status = status.strip().lower()
                    incomplete_details = getattr(response, "incomplete_details", None)
                    incomplete_reason = None
                    if isinstance(incomplete_details, dict):
                        incomplete_reason = incomplete_details.get("reason")
                    else:
                        incomplete_reason = getattr(incomplete_details, "reason", None)
                    if incomplete_reason is not None:
                        incomplete_reason = str(incomplete_reason).strip().lower()
                    if status == "incomplete" and incomplete_reason in {"max_output_tokens", "length"}:
                        # Responses API max-output exhaustion is a normal
                        # Codex incomplete turn.  Let the Codex-specific
                        # continuation path below append the incomplete
                        # assistant state and retry, instead of routing to
                        # the generic chat-completions length rollback that
                        # emits "Response truncated due to output length
                        # limit" and stops gateway turns.
                        finish_reason = "incomplete"
                    elif status == "incomplete" and incomplete_reason == "content_filter":
                        finish_reason = "content_filter"
                    else:
                        finish_reason = "stop"
                elif agent.api_mode == "anthropic_messages":
                    _tfr = agent._get_transport()
                    finish_reason = _tfr.map_finish_reason(response.stop_reason)
                elif agent.api_mode == "bedrock_converse":
                    # Bedrock response already normalized at dispatch — use transport
                    _bt_fr = agent._get_transport()
                    _bedrock_result = _bt_fr.normalize_response(response)
                    finish_reason = _bedrock_result.finish_reason
                else:
                    _cc_fr = agent._get_transport()
                    _finish_result = _cc_fr.normalize_response(response)
                    finish_reason = _finish_result.finish_reason
                    assistant_message = _finish_result
                    if agent._should_treat_stop_as_truncated(
                        finish_reason,
                        assistant_message,
                        messages,
                    ):
                        agent._vprint(
                            f"{agent.log_prefix}⚠️  Treating suspicious Ollama/GLM stop response as truncated",
                            force=True,
                        )
                        finish_reason = "length"

                # ── Content-policy refusal (HTTP 200) ──────────────────
                # The model — or the provider's safety system — returned a
                # *successful* response whose stop/finish reason is a refusal:
                # Anthropic ``stop_reason="refusal"`` → ``content_filter``;
                # OpenAI / portal ``finish_reason="content_filter"`` or a
                # populated ``message.refusal`` (mapped in the chat_completions
                # transport); Bedrock ``guardrail_intervened``. The content is
                # typically empty, so without this branch the response falls
                # through to the empty-response / invalid-response retry loops
                # and is mis-surfaced as "rate limited" / "no content after
                # retries" — burning paid attempts reproducing a deterministic
                # refusal. Surface it clearly and stop. Mirrors the
                # exception-based ``content_policy_blocked`` recovery: try a
                # configured fallback once, otherwise return the refusal.
                if finish_reason == "content_filter":
                    _refusal_transport = agent._get_transport()
                    if agent.api_mode == "anthropic_messages":
                        _refusal_result = _refusal_transport.normalize_response(
                            response, strip_tool_prefix=agent._is_anthropic_oauth
                        )
                    else:
                        _refusal_result = _refusal_transport.normalize_response(response)
                    _refusal_text = (getattr(_refusal_result, "content", None) or "").strip()
                    # Some refusals carry the explanation only in the reasoning
                    # channel; fall back to it so the user sees *something*.
                    if not _refusal_text:
                        _refusal_text = (agent._extract_reasoning(_refusal_result) or "").strip()

                    agent._invoke_api_request_error_hook(
                        task_id=effective_task_id,
                        turn_id=turn_id,
                        api_request_id=api_request_id,
                        api_call_count=api_call_count,
                        api_start_time=api_start_time,
                        api_kwargs=api_kwargs,
                        error_type="ContentPolicyBlocked",
                        error_message=_refusal_text or "model declined to respond (content_filter)",
                        status_code=None,
                        retry_count=retry_count,
                        max_retries=max_retries,
                        retryable=False,
                        reason=FailoverReason.content_policy_blocked.value,
                    )

                    if thinking_spinner:
                        thinking_spinner.stop("")
                        thinking_spinner = None
                    if agent.thinking_callback:
                        agent.thinking_callback("")

                    # Deterministic for the unchanged prompt — never retry.
                    # Try a configured fallback once (a different model may not
                    # refuse); otherwise surface the refusal terminally.
                    if agent._has_pending_fallback():
                        agent._buffer_status(
                            "⚠️ Model declined to respond (safety refusal) — trying fallback..."
                        )
                    if agent._try_activate_fallback():
                        active_system_prompt = _sync_failover_system_message(
                            agent, api_messages, active_system_prompt)
                        retry_count = 0
                        compression_attempts = 0
                        _retry.primary_recovery_attempted = False
                        _retry.restart_with_rebuilt_messages = True
                        break

                    agent._flush_status_buffer()
                    _refusal_log = (
                        _refusal_text[:500] + "..."
                        if len(_refusal_text) > 500
                        else _refusal_text
                    )
                    logger.warning(
                        "%sModel declined to respond (finish_reason=content_filter). "
                        "model=%s provider=%s refusal=%s",
                        agent.log_prefix, agent.model, agent.provider,
                        _refusal_log or "(no text)",
                    )
                    agent._emit_status(
                        "⚠️ The model declined to respond to this request (safety refusal)."
                    )

                    _refusal_detail = (
                        f"Model's explanation: {_refusal_text}"
                        if _refusal_text
                        else "The model returned no explanation."
                    )
                    _refusal_response = (
                        "⚠️  The model declined to respond to this request "
                        "(safety refusal — not a Hermes/gateway failure).\n\n"
                        f"{_refusal_detail}\n\n"
                        f"{_CONTENT_POLICY_RECOVERY_HINT}"
                    )

                    agent._cleanup_task_resources(effective_task_id)
                    agent._persist_session(messages, conversation_history)
                    return _content_policy_blocked_result(
                        messages,
                        api_call_count,
                        final_response=_refusal_response,
                        error_detail=_refusal_text or "model declined (content_filter)",
                    )

                if finish_reason == "length":
                    if getattr(response, "id", "") == PARTIAL_STREAM_STUB_ID:
                        agent._vprint(
                            f"{agent.log_prefix}⚠️  Response truncated — stream "
                            f"ended before completion",
                            force=True,
                        )
                    else:
                        agent._vprint(
                            f"{agent.log_prefix}⚠️  Response truncated "
                            f"(finish_reason='length') - model hit max output tokens",
                            force=True,
                        )

                    # Normalize the truncated response to a single OpenAI-style
                    # message shape so text-continuation and tool-call retry
                    # work uniformly across chat_completions, bedrock_converse,
                    # and anthropic_messages.  For Anthropic we use the same
                    # adapter the agent loop already relies on so the rebuilt
                    # interim assistant message is byte-identical to what
                    # would have been appended in the non-truncated path.
                    _trunc_msg = None
                    _trunc_transport = agent._get_transport()
                    if agent.api_mode == "anthropic_messages":
                        _trunc_result = _trunc_transport.normalize_response(
                            response, strip_tool_prefix=agent._is_anthropic_oauth
                        )
                    else:
                        _trunc_result = _trunc_transport.normalize_response(response)
                    _trunc_msg = _trunc_result

                    _trunc_content = getattr(_trunc_msg, "content", None) if _trunc_msg else None
                    _trunc_has_tool_calls = bool(getattr(_trunc_msg, "tool_calls", None)) if _trunc_msg else False

                    # ── Detect thinking-budget exhaustion ──────────────
                    # When the model spends ALL output tokens on reasoning
                    # and has none left for the response, continuation
                    # retries are pointless.  Detect this early and give a
                    # targeted error instead of wasting 3 API calls.
                    # A response is "thinking exhausted" only when the model
                    # actually produced reasoning blocks but no visible text after
                    # them.  Models that do not use <think> tags (e.g. GLM-4.7 on
                    # NVIDIA Build, minimax) may return content=None or an empty
                    # string for unrelated reasons — treat those as normal
                    # truncations that deserve continuation retries, not as
                    # thinking-budget exhaustion.
                    _has_think_tags = bool(
                        _trunc_content and re.search(
                            r'<(?:think|thinking|reasoning|REASONING_SCRATCHPAD)[^>]*>',
                            _trunc_content,
                            re.IGNORECASE,
                        )
                    )
                    _thinking_exhausted = (
                        not _trunc_has_tool_calls
                        and _has_think_tags
                        and (
                            (_trunc_content is not None and not agent._has_content_after_think_block(_trunc_content))
                            or _trunc_content is None
                        )
                    )

                    if _thinking_exhausted:
                        _exhaust_error = (
                            "Model used all output tokens on reasoning with none left "
                            "for the response. Try lowering reasoning effort or "
                            "increasing max_tokens."
                        )
                        agent._vprint(
                            f"{agent.log_prefix}💭 Reasoning exhausted the output token budget — "
                            f"no visible response was produced.",
                            force=True,
                        )
                        # Return a user-friendly message as the response so
                        # CLI (response box) and gateway (chat message) both
                        # display it naturally instead of a suppressed error.
                        _exhaust_response = (
                            "⚠️ **Thinking Budget Exhausted**\n\n"
                            "The model used all its output tokens on reasoning "
                            "and had none left for the actual response.\n\n"
                            "To fix this:\n"
                            "→ Lower reasoning effort: `/thinkon low` or `/thinkon minimal`\n"
                            "→ Or switch to a larger/non-reasoning model with `/model`"
                        )
                        agent._cleanup_task_resources(effective_task_id)
                        agent._persist_session(messages, conversation_history)
                        return {
                            "final_response": _exhaust_response,
                            "messages": messages,
                            "api_calls": api_call_count,
                            "completed": False,
                            "partial": True,
                            "error": _exhaust_error,
                        }

                    # ── Detect repetition-dominated truncation (#86581) ──
                    # A model in a degenerate repetition loop can spend its
                    # ENTIRE output budget echoing one fragment.  The
                    # continuation nudge below would then stitch the
                    # pathological fragment into the final response — in the
                    # #86581 incident one turn produced a 60,698-char
                    # response delivered as 31 Discord messages.  Abort with
                    # a clear user-facing error instead, mirroring the
                    # _thinking_exhausted guard above.  Reasoning blocks are
                    # stripped first (repeated scratchpad lines are not
                    # evidence of a degenerate visible response).
                    _visible_trunc = (
                        agent._strip_think_blocks(_trunc_content)
                        if isinstance(_trunc_content, str)
                        else _trunc_content
                    )
                    _repetition_dominated = (
                        not _trunc_has_tool_calls
                        and bool(_visible_trunc)
                        and is_repetition_dominated(_visible_trunc)
                    )
                    if _repetition_dominated:
                        _rep_error = (
                            "Model output entered a repetition loop and was "
                            "truncated mid-loop; refusing to continue a "
                            "degenerate response."
                        )
                        agent._vprint(
                            f"{agent.log_prefix}🔁 Response dominated by "
                            f"repeated text — stopping instead of "
                            f"continuing a degenerate response.",
                            force=True,
                        )
                        _rep_response = (
                            "⚠️ **Response Stopped — Repetition Detected**\n\n"
                            "The model fell into a repetition loop while "
                            "writing this response, so continuing would only "
                            "produce more repeated text. The partial response "
                            "was discarded.\n\n"
                            "→ Switch to a different model with `/model`\n"
                            "→ Or resend your message (your conversation "
                            "history is preserved)"
                        )
                        agent._cleanup_task_resources(effective_task_id)
                        agent._persist_session(messages, conversation_history)
                        return {
                            "final_response": _rep_response,
                            "messages": messages,
                            "api_calls": api_call_count,
                            "completed": False,
                            "partial": True,
                            "error": _rep_error,
                        }

                    if agent.api_mode in {"chat_completions", "bedrock_converse", "anthropic_messages"}:
                        assistant_message = _trunc_msg
                        # ── Content-filter stream stall → fallback (#32421) ──
                        # When the provider's output-layer safety filter (e.g.
                        # MiniMax "output new_sensitive (1027)", Azure
                        # content_filter) kills the stream mid-delivery, the
                        # raw error was classified at the swallow point and the
                        # stub tagged ``_content_filter_terminated``.  This
                        # filter is content-deterministic — continuation
                        # retries against the SAME primary just re-hit it and
                        # burn paid attempts (the loop used to give up with
                        # "Response remained truncated after 3 continuation
                        # attempts" and never consult the fallback chain).
                        # Escalate to the configured fallback BEFORE retrying.
                        _cf_terminated = getattr(
                            response, "_content_filter_terminated", False
                        )
                        if (
                            _cf_terminated
                            and agent._fallback_index < len(agent._fallback_chain)
                        ):
                            agent._vprint(
                                f"{agent.log_prefix}🛡️  Content filter terminated "
                                f"stream — activating fallback provider...",
                                force=True,
                            )
                            agent._emit_status(
                                "Content filter terminated stream; switching to fallback..."
                            )
                            if agent._try_activate_fallback():
                                # Roll the partial content (if any was already
                                # appended in a prior continuation pass) back to
                                # the last clean turn so the fallback provider
                                # gets a coherent continuation point.
                                if truncated_response_parts:
                                    messages = agent._get_messages_up_to_last_assistant(messages)
                                # Unmark survivors: their text left the stitched partial.
                                for _frag in messages:
                                    if isinstance(_frag, dict):
                                        _frag.pop("_length_continuation_fragment", None)
                                        _frag.pop("_length_continuation_nudge", None)
                                agent._session_messages = messages
                                length_continue_retries = 0
                                truncated_response_parts = []
                                retry_count = 0
                                compression_attempts = 0
                                _retry.primary_recovery_attempted = False
                                _retry.restart_with_rebuilt_messages = True
                                break
                            # No fallback available — fall through to normal
                            # continuation (best-effort, may loop).
                            agent._vprint(
                                f"{agent.log_prefix}⚠️  No fallback provider "
                                f"configured — retrying with same provider "
                                f"(may re-hit filter)...",
                                force=True,
                            )
                        if assistant_message is not None and not _trunc_has_tool_calls:
                            length_continue_retries += 1
                            # An EMPTY partial-stream stub (stream dropped
                            # mid tool-call before any text was delivered)
                            # must not be appended as an interim assistant
                            # message: it would serialize as
                            # {"role": "assistant", "content": ""}, and
                            # strict providers (Moonshot/Kimi via OpenRouter)
                            # reject empty assistant content with HTTP 400
                            # ("message ... with role 'assistant' must not be
                            # empty") on the very next replay — permanently
                            # poisoning the session history.  There is no
                            # partial text to continue from anyway, so only
                            # the continuation user-message is appended.
                            _is_empty_partial_stub = (
                                getattr(response, "id", "") == PARTIAL_STREAM_STUB_ID
                                and not getattr(assistant_message, "content", None)
                            )
                            if not _is_empty_partial_stub:
                                interim_msg = agent._build_assistant_message(assistant_message, finish_reason)
                                # Marked so the ceiling exit can drop the fragment trail.
                                interim_msg["_length_continuation_fragment"] = True
                                append_message(messages, interim_msg)
                                if assistant_message.content:
                                    truncated_response_parts.append(assistant_message.content)

                            if length_continue_retries < 4:
                                _is_partial_stream_stub = (
                                    getattr(response, "id", "") == PARTIAL_STREAM_STUB_ID
                                )
                                _dropped_tools = getattr(
                                    response, "_dropped_tool_names", None
                                )

                                if _is_partial_stream_stub and _dropped_tools:
                                    _tool_list = ", ".join(_dropped_tools[:3])
                                    agent._vprint(
                                        f"{agent.log_prefix}↻ Stream interrupted mid "
                                        f"tool-call ({_tool_list}) — requesting "
                                        f"chunked retry "
                                        f"({length_continue_retries}/4)..."
                                    )
                                elif _is_partial_stream_stub:
                                    agent._vprint(
                                        f"{agent.log_prefix}↻ Stream interrupted — "
                                        f"requesting continuation "
                                        f"({length_continue_retries}/4)..."
                                    )
                                else:
                                    agent._vprint(
                                        f"{agent.log_prefix}↻ Requesting continuation "
                                        f"({length_continue_retries}/4)..."
                                    )

                                _continue_content = _get_continuation_prompt(
                                    _is_partial_stream_stub, _dropped_tools
                                )
                                continue_msg = {
                                    "role": "user",
                                    "content": _continue_content,
                                    "_length_continuation_nudge": True,
                                }
                                append_message(messages, continue_msg)
                                agent._session_messages = messages
                                _retry.restart_with_length_continuation = True
                                break

                            partial_response = agent._strip_think_blocks(_join_truncated_parts(truncated_response_parts)).strip()
                            if partial_response:
                                agent._vprint(
                                    f"{agent.log_prefix}⚠️  Response still truncated "
                                    f"after 4 continuation attempts — keeping the "
                                    f"partial response received so far.",
                                    force=True,
                                )
                            # Unanswered continue nudges made every later turn re-truncate.
                            _turn_start = (
                                current_turn_user_idx + 1
                                if isinstance(current_turn_user_idx, int)
                                and current_turn_user_idx >= 0
                                else 0
                            )
                            messages[_turn_start:] = [
                                m for m in messages[_turn_start:]
                                if not (
                                    isinstance(m, dict)
                                    and (
                                        m.get("_length_continuation_fragment")
                                        or m.get("_length_continuation_nudge")
                                    )
                                )
                            ]
                            if partial_response:
                                append_message(messages, {
                                    "role": "assistant",
                                    "content": partial_response,
                                    "finish_reason": "length",
                                })
                            agent._session_messages = messages
                            agent._cleanup_task_resources(effective_task_id)
                            agent._persist_session(messages, conversation_history)
                            return {
                                "final_response": partial_response or None,
                                "messages": messages,
                                "api_calls": api_call_count,
                                "completed": False,
                                "partial": True,
                                "error": "Response remained truncated after 4 continuation attempts",
                            }

                    if agent.api_mode in {"chat_completions", "bedrock_converse", "anthropic_messages"}:
                        assistant_message = _trunc_msg
                        if assistant_message is not None and _trunc_has_tool_calls:
                            _is_stub_stall = (
                                getattr(response, "id", "") == PARTIAL_STREAM_STUB_ID
                            )
                            if truncated_tool_call_retries < 4:
                                truncated_tool_call_retries += 1
                                if _is_stub_stall:
                                    # The stream broke mid tool-call (network /
                                    # peer-closed connection), not a real output
                                    # cap — say so instead of "max output tokens".
                                    agent._buffer_vprint(
                                        f"⚠️  Stream interrupted mid tool-call — "
                                        f"retrying ({truncated_tool_call_retries}/4)..."
                                    )
                                else:
                                    agent._buffer_vprint(
                                        f"⚠️  Truncated tool call detected — "
                                        f"retrying API call "
                                        f"({truncated_tool_call_retries}/4)..."
                                    )
                                # Boost max_tokens on each retry so the model has
                                # more room to complete the tool-call JSON. A
                                # network stall doesn't need a bigger budget, but
                                # a genuine output-cap truncation does, and the
                                # boost is harmless for the stall case.
                                _tc_boost_base = agent.max_tokens if agent.max_tokens else 4096
                                _tc_boost = _tc_boost_base * (2 ** truncated_tool_call_retries)
                                _tc_requested_cap = agent._requested_output_cap_from_api_kwargs(api_kwargs)
                                if _tc_requested_cap is not None:
                                    _tc_boost = max(_tc_boost, _tc_requested_cap)
                                _tc_boost_cap = max(32768, _tc_requested_cap or 0)
                                agent._ephemeral_max_output_tokens = min(_tc_boost, _tc_boost_cap)
                                # Don't append the broken response to messages;
                                # just re-run the same API call from the current
                                # message state, giving the model another chance.
                                continue
                            agent._flush_status_buffer()
                            if _is_stub_stall:
                                agent._vprint(
                                    f"{agent.log_prefix}⚠️  Stream kept dropping mid tool-call after 4 retries — the action was not executed.",
                                    force=True,
                                )
                            else:
                                agent._vprint(
                                    f"{agent.log_prefix}⚠️  Truncated tool call response detected again — refusing to execute incomplete tool arguments.",
                                    force=True,
                                )
                            agent._cleanup_task_resources(effective_task_id)
                            _final_response = (
                                "Stream repeatedly dropped mid tool-call (network); "
                                "the tool was not executed"
                                if _is_stub_stall
                                else "Response truncated due to output length limit"
                            )
                            # Prior successful tool batches (or injected tool
                            # errors) can leave a tool-result tail; this path
                            # never reaches finalize_turn (#48879 class).
                            close_interrupted_tool_sequence(messages, _final_response)
                            agent._persist_session(messages, conversation_history)
                            return {
                                "final_response": _final_response,
                                "messages": messages,
                                "api_calls": api_call_count,
                                "completed": False,
                                "partial": True,
                                "error": _final_response,
                            }

                    # If we have prior messages, roll back to last complete state
                    if len(messages) > 1:
                        agent._vprint(f"{agent.log_prefix}   ⏪ Rolling back to last complete assistant turn")
                        rolled_back_messages = agent._get_messages_up_to_last_assistant(messages)

                        agent._cleanup_task_resources(effective_task_id)
                        agent._persist_session(messages, conversation_history)

                        return {
                            "final_response": "Response truncated due to output length limit",
                            "messages": rolled_back_messages,
                            "api_calls": api_call_count,
                            "completed": False,
                            "partial": True,
                            "error": "Response truncated due to output length limit"
                        }
                    else:
                        # First message was truncated - mark as failed
                        agent._flush_status_buffer()
                        agent._vprint(f"{agent.log_prefix}❌ First response truncated - cannot recover", force=True)
                        agent._persist_session(messages, conversation_history)
                        return {
                            "final_response": "First response truncated due to output length limit",
                            "messages": messages,
                            "api_calls": api_call_count,
                            "completed": False,
                            "failed": True,
                            "error": "First response truncated due to output length limit"
                        }
                
                # Track actual token usage from response for context management
                if hasattr(response, 'usage') and response.usage:
                    canonical_usage = normalize_usage(
                        response.usage,
                        provider=agent.provider,
                        api_mode=agent.api_mode,
                    )
                    # Aggregator-only usage is retained for cost pricing: MoA
                    # advisor tokens must be priced at each advisor's OWN model
                    # rate, not the aggregator's, so they are added as dollars
                    # (below) rather than folded into the priced usage.
                    aggregator_usage = canonical_usage
                    # MoA: fold the reference (advisor) fan-out's token usage
                    # into this turn's REPORTED token counts. MoA runs advisors
                    # before the aggregator and returns only the aggregator's
                    # usage, so without this the entire advisor spend — usually
                    # the bulk of a MoA turn — is invisible in token counts.
                    _moa_ref_cost = None
                    _moa_client = getattr(agent, "client", None)
                    if _moa_client is not None and hasattr(_moa_client, "consume_reference_usage"):
                        try:
                            _ref_usage, _moa_ref_cost = _moa_client.consume_reference_usage()
                            if _ref_usage is not None:
                                canonical_usage = canonical_usage + _ref_usage
                        except Exception as _moa_acct_exc:  # pragma: no cover - defensive
                            logger.debug("MoA reference usage accounting failed: %s", _moa_acct_exc)
                    # Flush the full-turn MoA trace (references + aggregator I/O)
                    # to disk when moa.save_traces is on. No-op otherwise and
                    # for non-MoA clients. Uses the live session_id so traces
                    # land in the right per-session file. On the streaming path
                    # the aggregator's output wasn't captured inline (its raw
                    # token stream went to the live consumer), so pass the
                    # resolved streamed acting text as a fallback — makes the
                    # trace self-contained instead of only pointing at state.db.
                    if _moa_client is not None and hasattr(_moa_client, "consume_and_save_trace"):
                        try:
                            _agg_streamed_text = (
                                getattr(agent, "_current_streamed_assistant_text", "") or ""
                            )
                            _moa_client.consume_and_save_trace(
                                agent.session_id,
                                aggregator_output_fallback=_agg_streamed_text or None,
                            )
                        except Exception as _moa_trace_exc:  # pragma: no cover - defensive
                            logger.debug("MoA trace flush failed: %s", _moa_trace_exc)
                    prompt_tokens = canonical_usage.prompt_tokens
                    completion_tokens = canonical_usage.output_tokens
                    total_tokens = canonical_usage.total_tokens
                    # Forward canonical token + cache buckets so context engines
                    # can make decisions on cache hit ratios / reasoning costs,
                    # not just legacy aggregate tokens. Legacy keys stay for
                    # back-compat with engines that only read prompt/completion/total.
                    usage_dict = {
                        "prompt_tokens": prompt_tokens,
                        "completion_tokens": completion_tokens,
                        "total_tokens": total_tokens,
                        "input_tokens": canonical_usage.input_tokens,
                        "output_tokens": canonical_usage.output_tokens,
                        "cache_read_tokens": canonical_usage.cache_read_tokens,
                        "cache_write_tokens": canonical_usage.cache_write_tokens,
                        "reasoning_tokens": canonical_usage.reasoning_tokens,
                    }
                    # Capture the boundary latch before update_from_response()
                    # consumes it. Only a real provider prompt count for the
                    # request immediately following a completed compaction can
                    # prove that attempt effective and rearm the shared budget.
                    _completed_compaction_pending = bool(
                        getattr(
                            agent.context_compressor,
                            "_verify_compaction_cleared_threshold",
                            False,
                        )
                    )
                    agent.context_compressor.update_from_response(usage_dict)
                    # Usage-anchored context accounting: snapshot this
                    # response's exact provider-reported usage against the
                    # durable transcript. Later context-size checks anchor on
                    # this and estimate only the messages appended since,
                    # instead of re-estimating the whole history with
                    # heuristics. Main-loop responses ONLY — MoA advisor and
                    # auxiliary calls never reach this site, so they cannot
                    # pollute the anchor. A usage-less response leaves the
                    # previous anchor in place (still valid for its base).
                    # MoA note: use the pre-fold aggregator usage — the folded
                    # canonical figure adds advisor fan-out tokens that were
                    # never part of THIS conversation's prompt.
                    _new_anchor = capture_usage_anchor(
                        aggregator_usage.prompt_tokens,
                        aggregator_usage.output_tokens,
                        messages,
                    )
                    if _new_anchor is not None:
                        agent._usage_anchor = _new_anchor
                        # Turn-base anchor for display surfaces: the FIRST
                        # response of a turn carries minimal current-turn
                        # reasoning replay, so its prompt_tokens approximate
                        # the durable transcript cost (what the next turn
                        # inherits). Later same-turn responses inflate
                        # prompt_tokens with replayed thinking + tool
                        # scaffolding that evaporates at the turn boundary —
                        # anchoring the context meter here instead of on the
                        # last response removes the end-of-turn sawtooth
                        # (850K mid-loop -> 600K next turn) that users read
                        # as a broken compaction. Display-only: compression
                        # trigger math keeps using real last-request usage.
                        if api_call_count == 1:
                            agent._turn_base_usage_anchor = _new_anchor
                    _compression_threshold = int(
                        getattr(agent.context_compressor, "threshold_tokens", 0)
                        or 0
                    )
                    if _should_rearm_compression_budget(
                        compression_attempts,
                        completed_compaction_pending=_completed_compaction_pending,
                        prompt_tokens=prompt_tokens,
                        threshold_tokens=_compression_threshold,
                    ):
                        logger.info(
                            "Compression budget rearmed after provider-confirmed "
                            "recovery: prompt=%s < threshold=%s (attempts were %s/%s)",
                            f"{prompt_tokens:,}",
                            f"{_compression_threshold:,}",
                            compression_attempts,
                            max_compression_attempts,
                        )
                        compression_attempts = 0
                        # Provider-confirmed recovery also invalidates the
                        # insufficient-progress preflight state: with the
                        # prompt proven back below the threshold, a prior
                        # "insufficient progress" verdict (and the stale
                        # pressure reading it would be compared against)
                        # describes a request shape that no longer exists.
                        # Left armed, _preflight_compression_blocked keeps the
                        # pre-API gate dark for the rest of the turn even
                        # though the attempt budget was just rearmed, so a
                        # later pressure spike would grow unchecked until the
                        # provider's overflow handler fired.
                        _preflight_compression_blocked = False
                        _last_preflight_pressure = None

                    # Stash this response's canonical usage so the post-turn
                    # on_turn_complete() observation hook can forward it (the
                    # same dict shape passed to update_from_response). A turn
                    # may make several API calls; the engine's per-turn signal
                    # of interest is the cost/size of the latest assembled
                    # request, so we keep the most recent call's usage.
                    agent._last_turn_usage = dict(usage_dict)
                elif getattr(
                    agent.context_compressor,
                    "awaiting_real_usage_after_compression",
                    False,
                ):
                    # A response with no usage cannot adjudicate whether the
                    # prior compaction cleared the threshold. Consume the pending
                    # verdict now so a much later, unrelated reading is not
                    # charged to that old compaction, and so preflight deferral
                    # does not remain latched indefinitely.
                    agent.context_compressor.update_from_response({})

                if hasattr(response, 'usage') and response.usage:
                    # Cache discovered context length after successful call.
                    # Only persist limits confirmed by the provider (parsed
                    # from the error message), not guessed probe tiers.
                    if getattr(agent.context_compressor, "_context_probed", False):
                        ctx = agent.context_compressor.context_length
                        if getattr(agent.context_compressor, "_context_probe_persistable", False):
                            save_context_length(agent.model, agent.base_url, ctx)
                            agent._safe_print(f"{agent.log_prefix}💾 Cached context length: {ctx:,} tokens for {agent.model}")
                        agent.context_compressor._context_probed = False
                        agent.context_compressor._context_probe_persistable = False

                    agent.session_prompt_tokens += prompt_tokens
                    agent.session_completion_tokens += completion_tokens
                    agent.session_total_tokens += total_tokens
                    agent.session_api_calls += 1
                    agent.session_input_tokens += canonical_usage.input_tokens
                    agent.session_output_tokens += canonical_usage.output_tokens
                    agent.session_cache_read_tokens += canonical_usage.cache_read_tokens
                    agent.session_cache_write_tokens += canonical_usage.cache_write_tokens
                    agent.session_reasoning_tokens += canonical_usage.reasoning_tokens
                    # Rolling history for status-bar averages (last 10).
                    try:
                        hist = getattr(agent, "_api_latency_history", None)
                        if hist is not None:
                            hist.append(float(api_duration))
                        ohist = getattr(agent, "_api_output_history", None)
                        if ohist is not None:
                            ohist.append(int(canonical_usage.output_tokens or 0))
                    except Exception:
                        pass

                    # Log API call details for debugging/observability
                    _cache_pct = ""
                    if canonical_usage.cache_read_tokens and prompt_tokens:
                        _cache_pct = f" cache={canonical_usage.cache_read_tokens}/{prompt_tokens} ({100*canonical_usage.cache_read_tokens/prompt_tokens:.0f}%)"
                    logger.info(
                        "API call #%d: model=%s provider=%s in=%d out=%d total=%d latency=%.1fs%s",
                        agent.session_api_calls, agent.model, agent.provider or "unknown",
                        prompt_tokens, completion_tokens, total_tokens,
                        api_duration, _cache_pct,
                    )

                    # On the MoA path, agent.model/provider are the virtual
                    # preset name ("closed") and "moa", which have no pricing
                    # entry — estimating against them returns None and silently
                    # drops the aggregator's own spend, leaving the session cost
                    # as advisor-fan-out only (a ~50% undercount when the
                    # aggregator does the full acting loop). Price the aggregator
                    # turn at its REAL model/provider, read from the MoA client's
                    # resolved aggregator slot.
                    _agg_cost_model = agent.model
                    _agg_cost_provider = agent.provider
                    _agg_cost_base_url = agent.base_url
                    _agg_slot = getattr(_moa_client, "last_aggregator_slot", None) if _moa_client is not None else None
                    if _agg_slot and _agg_slot.get("model"):
                        _agg_cost_model = _agg_slot["model"]
                        _agg_cost_provider = _agg_slot.get("provider") or agent.provider
                        _agg_cost_base_url = _agg_slot.get("base_url") or agent.base_url
                    cost_result = estimate_usage_cost(
                        _agg_cost_model,
                        aggregator_usage,
                        provider=_agg_cost_provider,
                        base_url=_agg_cost_base_url,
                        api_key=getattr(agent, "api_key", ""),
                    )
                    if cost_result.amount_usd is not None:
                        agent.session_estimated_cost_usd += float(cost_result.amount_usd)
                    # Add MoA advisor cost (already priced per-advisor at each
                    # advisor's own model rate) on top of the aggregator cost.
                    if _moa_ref_cost is not None:
                        try:
                            agent.session_estimated_cost_usd += float(_moa_ref_cost)
                        except (TypeError, ValueError):  # pragma: no cover - defensive
                            pass
                    agent.session_cost_status = cost_result.status
                    agent.session_cost_source = cost_result.source

                    # Persist token counts to session DB for /insights.
                    # Do this for every platform with a session_id so non-CLI
                    # sessions (gateway, cron, delegated runs) cannot lose
                    # token/accounting data if a higher-level persistence path
                    # is skipped or fails. Gateway/session-store writes use
                    # absolute totals, so they safely overwrite these per-call
                    # deltas instead of double-counting them.
                    if agent._session_db and agent.session_id:
                        try:
                            # Ensure the session row exists before attempting UPDATE.
                            # Under concurrent load (cron/kanban), the initial
                            # _ensure_db_session() may have failed due to SQLite
                            # locking.  Retry here so per-call token deltas are
                            # not silently lost (UPDATE on a non-existent row
                            # affects 0 rows without error).
                            if not agent._session_db_created:
                                agent._ensure_db_session()
                            # Per-call cost delta = aggregator cost + MoA
                            # advisor cost (each priced at its own rate). Folded
                            # here so state.db's estimated_cost_usd includes the
                            # full MoA spend, matching the folded token counts.
                            _cost_delta = None
                            if cost_result.amount_usd is not None:
                                _cost_delta = float(cost_result.amount_usd)
                            if _moa_ref_cost is not None:
                                try:
                                    _cost_delta = (_cost_delta or 0.0) + float(_moa_ref_cost)
                                except (TypeError, ValueError):  # pragma: no cover
                                    pass
                            # Enqueued, not written: the background writer
                            # applies the delta off the turn thread (a cold
                            # state.db UPDATE here stalled the tool loop for
                            # up to hundreds of ms per API call). Drained at
                            # turn finalize via _persist_session.
                            agent._session_db.queue_token_counts(
                                agent.session_id,
                                input_tokens=canonical_usage.input_tokens,
                                output_tokens=canonical_usage.output_tokens,
                                cache_read_tokens=canonical_usage.cache_read_tokens,
                                cache_write_tokens=canonical_usage.cache_write_tokens,
                                reasoning_tokens=canonical_usage.reasoning_tokens,
                                estimated_cost_usd=_cost_delta,
                                cost_status=cost_result.status,
                                cost_source=cost_result.source,
                                billing_provider=agent.provider,
                                billing_base_url=agent.base_url,
                                billing_mode="subscription_included"
                                if cost_result.status == "included" else None,
                                model=agent.model,
                                api_call_count=1,
                            )
                        except Exception as e:
                            # Log token persistence failures so they're
                            # visible in agent.log — silent loss here is
                            # the root cause of undercounted analytics.
                            logger.debug(
                                "Token persistence failed (session=%s, tokens=%d): %s",
                                agent.session_id, total_tokens, e,
                            )
                    
                    if agent.verbose_logging:
                        logging.debug(f"Token usage: prompt={usage_dict['prompt_tokens']:,}, completion={usage_dict['completion_tokens']:,}, total={usage_dict['total_tokens']:,}")
                    
                    # Surface cache hit stats for any provider that reports
                    # them — not just those where we inject cache_control
                    # markers.  OpenAI/Kimi/DeepSeek/Qwen all do automatic
                    # server-side prefix caching and return
                    # ``prompt_tokens_details.cached_tokens``; users
                    # previously could not see their cache % because this
                    # line was gated on ``_use_prompt_caching``, which is
                    # only True for Anthropic-style marker injection.
                    # ``canonical_usage`` is already normalised from all
                    # three API shapes (Anthropic / Codex / OpenAI-chat)
                    # so we can rely on its values directly.
                    cached = canonical_usage.cache_read_tokens
                    written = canonical_usage.cache_write_tokens
                    prompt = usage_dict["prompt_tokens"]
                    if (cached or written) and not agent.quiet_mode:
                        hit_pct = (cached / prompt * 100) if prompt > 0 else 0
                        agent._vprint(
                            f"{agent.log_prefix}   💾 Cache: "
                            f"{cached:,}/{prompt:,} tokens "
                            f"({hit_pct:.0f}% hit, {written:,} written)"
                        )
                
                _retry.has_retried_429 = False  # Reset on success
                # Note: don't clear the retry buffer here — an "API call
                # success" only means we got bytes back, not that we got
                # usable content. Empty responses still loop through the
                # empty-retry path below; the buffer is cleared when
                # genuinely successful content is detected later (~L4127).
                # Clear Nous rate limit state on successful request —
                # proves the limit has reset and other sessions can
                # resume hitting Nous.
                if agent.provider == "nous":
                    try:
                        from agent.nous_rate_guard import clear_nous_rate_limit
                        clear_nous_rate_limit()
                    except Exception:
                        pass
                from agent import relay_llm

                relay_llm.complete_logical_call(
                    api_request_id,
                    outcome="success",
                )
                agent._touch_activity(f"API call #{api_call_count} completed")
                break  # Success, exit retry loop

            except InterruptedError:
                if thinking_spinner:
                    thinking_spinner.stop("")
                    thinking_spinner = None
                if agent.thinking_callback:
                    agent.thinking_callback("")
                if agent._has_pending_redirect():
                    # redirect() deliberately used the interrupt machinery to
                    # cancel only this provider request. Keep its correction
                    # queued, clear the cancellation bit, and let the outer
                    # loop rebuild a clean request tail. Never materialize
                    # incomplete signed/encrypted reasoning items.
                    if agent.clear_interrupt(preserve_redirect=True):
                        _retry.restart_with_redirected_messages = True
                        break
                api_elapsed = time.time() - api_start_time
                agent._vprint(f"{agent.log_prefix}⚡ Interrupted during API call.", force=True)
                interrupted = True
                # Preserve any assistant text already streamed to the user
                # before the stop landed. Dropping it leaves history with no
                # record of the half-finished reply on screen, so the next turn
                # the model "forgets" what it just said — exactly what users hit
                # when they stop to redirect mid-response.
                _partial = agent._strip_think_blocks(
                    getattr(agent, "_current_streamed_assistant_text", "") or ""
                ).strip()
                if _partial:
                    append_message(messages, {"role": "assistant", "content": _partial})
                    final_response = _partial
                else:
                    final_response = f"{INTERRUPT_WAITING_FOR_MODEL_PREFIX}{api_elapsed:.1f}s elapsed)."
                agent._persist_session(messages, conversation_history)
                break

            except Exception as api_error:
                # Stop spinner silently — retry status is buffered and
                # only flushed when every retry+fallback is exhausted.
                if thinking_spinner:
                    thinking_spinner.stop("")
                    thinking_spinner = None
                if agent.thinking_callback:
                    agent.thinking_callback("")

                # -----------------------------------------------------------
                # UnicodeEncodeError recovery.  Two common causes:
                #   1. Lone surrogates (U+D800..U+DFFF) from clipboard paste
                #      (Google Docs, rich-text editors) — sanitize and retry.
                #   2. ASCII codec on systems with LANG=C or non-UTF-8 locale
                #      (e.g. Chromebooks) — any non-ASCII character fails.
                #      Detect via the error message mentioning 'ascii' codec.
                # We sanitize messages in-place and may retry twice:
                # first to strip surrogates, then once more for pure
                # ASCII-only locale sanitization if needed.
                # -----------------------------------------------------------
                if isinstance(api_error, UnicodeEncodeError) and getattr(agent, '_unicode_sanitization_passes', 0) < 2:
                    _err_str = str(api_error).lower()
                    _is_ascii_codec = "'ascii'" in _err_str or "ascii" in _err_str
                    # Detect surrogate errors — utf-8 codec refusing to
                    # encode U+D800..U+DFFF.  The error text is:
                    #   "'utf-8' codec can't encode characters in position
                    #    N-M: surrogates not allowed"
                    _is_surrogate_error = (
                        "surrogate" in _err_str
                        or ("'utf-8'" in _err_str and not _is_ascii_codec)
                    )
                    # Sanitize surrogates from both the canonical `messages`
                    # list AND `api_messages` (the API-copy, which may carry
                    # `reasoning_content`/`reasoning_details` transformed
                    # from `reasoning` — fields the canonical list doesn't
                    # have directly).  Also clean `api_kwargs` if built and
                    # `prefill_messages` if present.  Mirrors the ASCII
                    # codec recovery below.
                    _surrogates_found = _sanitize_messages_surrogates(messages)
                    if isinstance(api_messages, list):
                        if _sanitize_messages_surrogates(api_messages):
                            _surrogates_found = True
                    if isinstance(api_kwargs, dict):
                        if _sanitize_structure_surrogates(api_kwargs):
                            _surrogates_found = True
                    if isinstance(getattr(agent, "prefill_messages", None), list):
                        if _sanitize_messages_surrogates(agent.prefill_messages):
                            _surrogates_found = True
                    # Gate the retry on the error type, not on whether we
                    # found anything — _force_ascii_payload / the extended
                    # surrogate walker above cover all known paths, but a
                    # new transformed field could still slip through.  If
                    # the error was a surrogate encode failure, always let
                    # the retry run; the proactive sanitizer at line ~8781
                    # runs again on the next iteration.  Bounded by
                    # _unicode_sanitization_passes < 2 (outer guard).
                    if _surrogates_found or _is_surrogate_error:
                        agent._unicode_sanitization_passes += 1
                        if _surrogates_found:
                            agent._buffer_vprint(
                                "⚠️  Stripped invalid surrogate characters from messages. Retrying..."
                            )
                        else:
                            agent._buffer_vprint(
                                "⚠️  Surrogate encoding error — retrying after full-payload sanitization..."
                            )
                        continue
                    if _is_ascii_codec:
                        agent._force_ascii_payload = True
                        # ASCII codec: the system encoding can't handle
                        # non-ASCII characters at all. Sanitize all
                        # non-ASCII content from messages/tool schemas and retry.
                        # Sanitize both the canonical `messages` list and
                        # `api_messages` (the API-copy built before the retry
                        # loop, which may contain extra fields like
                        # reasoning_content that are not in `messages`).
                        _messages_sanitized = _sanitize_messages_non_ascii(messages)
                        if isinstance(api_messages, list):
                            _sanitize_messages_non_ascii(api_messages)
                        # Also sanitize the last api_kwargs if already built,
                        # so a leftover non-ASCII value in a transformed field
                        # (e.g. extra_body, reasoning_content) doesn't survive
                        # into the next attempt via _build_api_kwargs cache paths.
                        if isinstance(api_kwargs, dict):
                            _sanitize_structure_non_ascii(api_kwargs)
                        _prefill_sanitized = False
                        if isinstance(getattr(agent, "prefill_messages", None), list):
                            _prefill_sanitized = _sanitize_messages_non_ascii(agent.prefill_messages)

                        _tools_sanitized = False
                        if isinstance(getattr(agent, "tools", None), list):
                            _tools_sanitized = _sanitize_tools_non_ascii(agent.tools)

                        _system_sanitized = False
                        if isinstance(active_system_prompt, str):
                            _sanitized_system = _strip_non_ascii(active_system_prompt)
                            if _sanitized_system != active_system_prompt:
                                active_system_prompt = _sanitized_system
                                agent._cached_system_prompt = _sanitized_system
                                _system_sanitized = True
                        if isinstance(getattr(agent, "ephemeral_system_prompt", None), str):
                            _sanitized_ephemeral = _strip_non_ascii(agent.ephemeral_system_prompt)
                            if _sanitized_ephemeral != agent.ephemeral_system_prompt:
                                agent.ephemeral_system_prompt = _sanitized_ephemeral
                                _system_sanitized = True

                        _headers_sanitized = False
                        _default_headers = (
                            agent._client_kwargs.get("default_headers")
                            if isinstance(getattr(agent, "_client_kwargs", None), dict)
                            else None
                        )
                        if isinstance(_default_headers, dict):
                            _headers_sanitized = _sanitize_structure_non_ascii(_default_headers)

                        # Sanitize the API key — non-ASCII characters in
                        # credentials (e.g. ʋ instead of v from a bad
                        # copy-paste) cause httpx to fail when encoding
                        # the Authorization header as ASCII.  This is the
                        # most common cause of persistent UnicodeEncodeError
                        # that survives message/tool sanitization (#6843).
                        _credential_sanitized = False
                        _raw_key = getattr(agent, "api_key", None) or ""
                        # Entra ID bearer providers are callables — their
                        # minted JWTs are always ASCII, so no sanitization
                        # is needed (and ``_strip_non_ascii`` would crash
                        # on a callable input).
                        if _raw_key and isinstance(_raw_key, str):
                            _clean_key = _strip_non_ascii(_raw_key)
                            if _clean_key != _raw_key:
                                agent.api_key = _clean_key
                                if isinstance(getattr(agent, "_client_kwargs", None), dict):
                                    agent._client_kwargs["api_key"] = _clean_key
                                # Also update the live client — it holds its
                                # own copy of api_key which auth_headers reads
                                # dynamically on every request.
                                if getattr(agent, "client", None) is not None and hasattr(agent.client, "api_key"):
                                    agent.client.api_key = _clean_key
                                _credential_sanitized = True
                                agent._vprint(
                                    f"{agent.log_prefix}⚠️  API key contained non-ASCII characters "
                                    f"(bad copy-paste?) — stripped them. If auth fails, "
                                    f"re-copy the key from your provider's dashboard.",
                                    force=True,
                                )

                        # Always retry on ASCII codec detection —
                        # _force_ascii_payload guarantees the full
                        # api_kwargs payload is sanitized on the
                        # next iteration (line ~8475).  Even when
                        # per-component checks above find nothing
                        # (e.g. non-ASCII only in api_messages'
                        # reasoning_content), the flag catches it.
                        # Bounded by _unicode_sanitization_passes < 2.
                        agent._unicode_sanitization_passes += 1
                        _any_sanitized = (
                            _messages_sanitized
                            or _prefill_sanitized
                            or _tools_sanitized
                            or _system_sanitized
                            or _headers_sanitized
                            or _credential_sanitized
                        )
                        if _any_sanitized:
                            agent._vprint(
                                f"{agent.log_prefix}⚠️  System encoding is ASCII — stripped non-ASCII characters from request payload. Retrying...",
                                force=True,
                            )
                        else:
                            agent._vprint(
                                f"{agent.log_prefix}⚠️  System encoding is ASCII — enabling full-payload sanitization for retry...",
                                force=True,
                            )
                        continue

                # ── Image-rejection recovery ──────────────────────────────
                # Some providers (mlx-lm, text-only endpoints, text-only
                # fallbacks on multimodal models) reject any message that
                # contains image_url content with a 4xx error like
                # "Only 'text' content type is supported."  On first hit,
                # strip all images from the message list, mark the session
                # as vision-unsupported, and retry with text only.
                #
                # Detection is best-effort English phrase matching — a
                # locale-translated or heavily-reworded upstream error
                # will bypass this guard and fall through to the normal
                # error handler.  Expand the phrase list when new
                # provider wordings are observed in the wild.
                _err_body = ""
                try:
                    _err_body = str(getattr(api_error, "body", None) or
                                    getattr(api_error, "message", None) or
                                    str(api_error))
                except Exception:
                    pass
                _err_status = getattr(api_error, "status_code", None)
                _looks_like_image_rejection = _looks_like_image_content_rejection(_err_body)
                # 4xx-only gate: never interpret 5xx/timeout as "server
                # said no to images" — those are transient and must
                # route to the normal retry path.
                _status_ok = _err_status is None or (400 <= int(_err_status) < 500)
                if (
                    getattr(agent, "_vision_supported", True)
                    and _looks_like_image_rejection
                    and _status_ok
                ):
                    agent._vision_supported = False
                    _imgs_removed = _strip_images_from_messages(messages)
                    if isinstance(api_messages, list):
                        _strip_images_from_messages(api_messages)
                    agent._vprint(
                        f"{agent.log_prefix}⚠️  Server rejected image content — "
                        f"switching to text-only mode for this session"
                        + (". Stripped images from history and retrying." if _imgs_removed else "."),
                        force=True,
                    )
                    continue

                # ── Bedrock AnthropicBedrock SDK streaming failure ──
                # The Anthropic SDK's stream accumulator raises RuntimeError
                # "Unexpected event order" when Bedrock returns an error event
                # before message_start (throttling, overload, validation).
                # Fall back to the native Converse API path for the rest of
                # this session — it handles these errors gracefully.  Ref: #28156.
                if (
                    isinstance(api_error, RuntimeError)
                    and "unexpected event order" in str(api_error).lower()
                    and getattr(agent, "provider", "") == "bedrock"
                    and agent.api_mode == "anthropic_messages"
                    and not getattr(agent, "_bedrock_converse_fallback_attempted", False)
                ):
                    agent._bedrock_converse_fallback_attempted = True
                    agent.api_mode = "bedrock_converse"
                    agent._bedrock_region = getattr(agent, "_bedrock_region", None) or "us-east-1"
                    agent.client = None  # Drop the AnthropicBedrock client
                    agent._client_kwargs = {}
                    agent._vprint(
                        f"{agent.log_prefix}⚠️  AnthropicBedrock SDK streaming failed — "
                        f"falling back to native Converse API for this session.",
                        force=True,
                    )
                    continue

                status_code = getattr(api_error, "status_code", None)
                error_context = agent._extract_api_error_context(api_error)

                # ── Interpreter finalization: abandon immediately ──
                # The process is exiting (TUI quit, SIGTERM, one-shot done)
                # while this turn — typically the post-turn review fork's
                # daemon thread — is mid-flight. Retries, credential
                # rotation, and fallbacks are all futile ("cannot schedule
                # new futures..."), and the buffered ⚠️/❌ retry trace spams
                # the shell after the TUI already exited. End the turn with
                # a single log line: no print, no traceback, no debug dump,
                # no retry. Same class as cron delivery (#55924/#58720) and
                # concurrent tool submission — shared predicate.
                from tools.interpreter_shutdown import interpreter_shutting_down

                if interpreter_shutting_down(api_error):
                    logger.warning(
                        "%sInterpreter is shutting down — abandoning turn "
                        "during API call #%d (%s)",
                        agent.log_prefix, api_call_count, api_error,
                    )
                    _shutdown_summary = (
                        "Turn abandoned: the process was shutting down "
                        "before the model call could complete."
                    )
                    return {
                        "final_response": _shutdown_summary,
                        "messages": messages,
                        "api_calls": api_call_count,
                        "completed": False,
                        "failed": True,
                        "error": _shutdown_summary,
                        "failure_reason": "interpreter_shutdown",
                        "failure_retryable": False,
                    }

                # ── Classify the error for structured recovery decisions ──
                _compressor = getattr(agent, "context_compressor", None)
                _ctx_len = getattr(_compressor, "context_length", 200000) if _compressor else 200000
                classified = classify_api_error(
                    api_error,
                    provider=getattr(agent, "provider", "") or "",
                    model=getattr(agent, "model", "") or "",
                    approx_tokens=approx_tokens,
                    context_length=_ctx_len,
                    num_messages=len(api_messages) if api_messages else 0,
                )
                logger.debug(
                    "Error classified: reason=%s status=%s retryable=%s compress=%s rotate=%s fallback=%s",
                    classified.reason.value, classified.status_code,
                    classified.retryable, classified.should_compress,
                    classified.should_rotate_credential, classified.should_fallback,
                )
                agent._invoke_api_request_error_hook(
                    task_id=effective_task_id,
                    turn_id=turn_id,
                    api_request_id=api_request_id,
                    api_call_count=api_call_count,
                    api_start_time=api_start_time,
                    api_kwargs=api_kwargs,
                    error_type=type(api_error).__name__,
                    error_message=str(api_error),
                    status_code=status_code,
                    retry_count=retry_count,
                    max_retries=max_retries,
                    retryable=classified.retryable,
                    reason=classified.reason.value,
                )

                if (
                    classified.reason == FailoverReason.billing
                    and _is_nous_inference_route(
                        getattr(agent, "provider", "") or "",
                        getattr(agent, "base_url", "") or "",
                    )
                    and not _retry.nous_paid_entitlement_refresh_attempted
                ):
                    _retry.nous_paid_entitlement_refresh_attempted = True
                    if _try_refresh_nous_paid_entitlement_credentials(agent):
                        agent._vprint(
                            f"{agent.log_prefix}🔐 Nous paid access verified — "
                            "refreshed runtime credentials and retrying request...",
                            force=True,
                        )
                        continue

                recovered_with_pool, _retry.has_retried_429 = agent._recover_with_credential_pool(
                    status_code=status_code,
                    has_retried_429=_retry.has_retried_429,
                    classified_reason=classified.reason,
                    error_context=error_context,
                    billing_unverified=classified.billing_unverified,
                )
                if recovered_with_pool:
                    continue

                # Image-too-large recovery: shrink oversized native image
                # parts in-place and retry once.  Triggered by Anthropic's
                # per-image 5 MB ceiling (400 with "image exceeds 5 MB
                # maximum") or any other provider that complains about
                # image size.  If shrink fails or a second attempt still
                # fails, fall through to normal error handling.
                if (
                    classified.reason == FailoverReason.image_too_large
                    and not _retry.image_shrink_retry_attempted
                ):
                    _retry.image_shrink_retry_attempted = True
                    image_max_dimension = _image_error_max_dimension(api_error) or 8000
                    if agent._try_shrink_image_parts_in_messages(
                        api_messages,
                        max_dimension=image_max_dimension,
                    ):
                        agent._vprint(
                            f"{agent.log_prefix}📐 Image(s) exceeded provider size limit — "
                            f"shrank and retrying...",
                            force=True,
                        )
                        continue
                    else:
                        logger.info(
                            "image-shrink recovery: no data-URL image parts found "
                            "or shrink didn't reduce size; surfacing original error."
                        )

                # Multimodal-tool-content recovery: providers that follow
                # the OpenAI spec strictly (tool message content must be a
                # string) reject our list-type content with a 400.  Strip
                # image parts from any list-type tool messages, mark the
                # (provider, model) as no-list-tool-content for the rest
                # of this session so future tool results preemptively
                # downgrade, and retry once.  See issue #27344.
                if (
                    classified.reason == FailoverReason.multimodal_tool_content_unsupported
                    and not _retry.multimodal_tool_content_retry_attempted
                ):
                    _retry.multimodal_tool_content_retry_attempted = True
                    if agent._try_strip_image_parts_from_tool_messages(api_messages):
                        agent._vprint(
                            f"{agent.log_prefix}📐 Provider rejected list-type tool content — "
                            f"downgraded screenshots to text and retrying...",
                            force=True,
                        )
                        continue
                    else:
                        logger.info(
                            "multimodal-tool-content recovery: no list-type tool "
                            "messages with image parts found; surfacing original error."
                        )

                # Image-corrupt recovery: the provider decoded the request but
                # rejected the image bytes themselves (e.g. xAI's "Invalid PNG
                # image." on a re-serialized image part from replayed
                # history). Shrinking corrupt bytes doesn't help, so strip the
                # image parts and retry once instead of routing through the
                # shrink path above. See issue #69078.
                if classified.reason == FailoverReason.image_corrupt:
                    # Strip ONLY the per-call payload copy. api_messages rows
                    # are shallow copies of canonical history, and the strip
                    # replaces msg["content"] rather than mutating the shared
                    # parts list — so canonical messages keep their images.
                    # A transient provider rejection must not permanently
                    # erase history (#69104 sweeper review; the copy-on-write
                    # contract from e762a5a473).
                    _imgs_removed = False
                    if isinstance(api_messages, list):
                        _imgs_removed = _strip_images_from_messages(api_messages)
                    if _imgs_removed:
                        agent._vprint(
                            f"{agent.log_prefix}⚠️  Provider rejected a corrupted image — "
                            f"stripped images from the retry payload and retrying...",
                            force=True,
                        )
                        continue
                    else:
                        logger.info(
                            "image-corrupt recovery: no image parts found to "
                            "strip; surfacing original error."
                        )

                # Anthropic OAuth subscription rejected the 1M-context beta
                # header ("long context beta is not yet available for this
                # subscription"). Disable the beta for the rest of this
                # session, rebuild the client, and retry once.  1M-capable
                # subscriptions never hit this branch — they accept the
                # beta and keep full 1M context.  See PR #17680 for the
                # original report (we chose reactive recovery over the
                # proposed unconditional omit so capable subscriptions
                # don't silently lose the capability).
                if (
                    classified.reason == FailoverReason.oauth_long_context_beta_forbidden
                    and agent.api_mode == "anthropic_messages"
                    and agent._is_anthropic_oauth
                    and not _retry.oauth_1m_beta_retry_attempted
                ):
                    _retry.oauth_1m_beta_retry_attempted = True
                    if not getattr(agent, "_oauth_1m_beta_disabled", False):
                        agent._oauth_1m_beta_disabled = True
                        try:
                            agent._anthropic_client.close()
                        except Exception:
                            pass
                        agent._rebuild_anthropic_client()
                        agent._vprint(
                            f"{agent.log_prefix}🔕 OAuth subscription doesn't support "
                            f"the 1M-context beta — disabled for this session and retrying...",
                            force=True,
                        )
                        continue

                if (
                    agent.api_mode == "codex_responses"
                    and agent.provider in {"openai-codex", "xai-oauth"}
                    and status_code == 401
                    and not _retry.codex_auth_retry_attempted
                ):
                    _retry.codex_auth_retry_attempted = True
                    if agent._try_refresh_codex_client_credentials(force=True):
                        _label = "xAI OAuth" if agent.provider == "xai-oauth" else "Codex"
                        agent._buffer_vprint(f"🔐 {_label} auth refreshed after 401. Retrying request...")
                        continue
                if (
                    agent.api_mode == "chat_completions"
                    and agent.provider == "vertex"
                    and status_code == 401
                    and not _retry.vertex_auth_retry_attempted
                ):
                    _retry.vertex_auth_retry_attempted = True
                    if agent._try_refresh_vertex_client_credentials():
                        agent._buffer_vprint("🔐 Vertex AI token refreshed after 401. Retrying request...")
                        continue
                if (
                    agent.api_mode in ("chat_completions", "anthropic_messages")
                    and agent.provider == "nous"
                    and status_code == 401
                    and not _retry.nous_auth_retry_attempted
                ):
                    _retry.nous_auth_retry_attempted = True
                    if agent._try_refresh_nous_client_credentials(force=True):
                        print(f"{agent.log_prefix}🔐 Nous agent key refreshed after 401. Retrying request...")
                        continue
                    # Credential refresh didn't help — show diagnostic info.
                    # Most common causes: Portal OAuth expired/revoked,
                    # account out of credits, or agent key blocked.
                    from hermes_constants import display_hermes_home as _dhh_fn
                    _dhh = _dhh_fn()
                    _body_text = ""
                    try:
                        _body = getattr(api_error, "body", None) or getattr(api_error, "response", None)
                        if _body is not None:
                            _body_text = str(_body)[:200]
                    except Exception:
                        pass
                    print(f"{agent.log_prefix}🔐 Nous 401 — Portal authentication failed.")
                    if _body_text:
                        print(f"{agent.log_prefix}   Response: {_body_text}")
                    if not _print_nous_entitlement_guidance(agent, "Nous model access"):
                        print(f"{agent.log_prefix}   Most likely: Portal OAuth expired, account out of credits, or agent key revoked.")
                    print(f"{agent.log_prefix}   Troubleshooting:")
                    print(f"{agent.log_prefix}     • Re-authenticate: hermes auth add nous")
                    print(f"{agent.log_prefix}     • Check credits / billing: https://portal.nousresearch.com")
                    print(f"{agent.log_prefix}     • Verify stored credentials: {_dhh}/auth.json")
                    print(f"{agent.log_prefix}     • Switch providers temporarily: /model <model> --provider openrouter")
                if (
                    _is_copilot_provider(agent)
                    and status_code == 401
                    and not _retry.copilot_auth_retry_attempted
                ):
                    _retry.copilot_auth_retry_attempted = True
                    if agent._try_refresh_copilot_client_credentials():
                        agent._buffer_vprint("🔐 Copilot credentials refreshed after 401. Retrying request...")
                        continue
                if (
                    agent.api_mode == "anthropic_messages"
                    and status_code == 401
                    and hasattr(agent, '_anthropic_api_key')
                    and not _retry.anthropic_auth_retry_attempted
                ):
                    _retry.anthropic_auth_retry_attempted = True
                    from agent.anthropic_adapter import _is_oauth_token
                    from agent.azure_identity_adapter import is_token_provider
                    if agent._try_refresh_anthropic_client_credentials():
                        print(f"{agent.log_prefix}🔐 Anthropic credentials refreshed after 401. Retrying request...")
                        continue
                    # Credential refresh didn't help — show diagnostic info
                    key = agent._anthropic_api_key
                    print(f"{agent.log_prefix}🔐 Anthropic 401 — authentication failed.")
                    if is_token_provider(key):
                        # Azure Foundry Entra ID — the bearer token is
                        # minted per-request by an httpx event hook on a
                        # custom http_client passed to the SDK. The 401
                        # means Azure rejected the JWT (RBAC role missing,
                        # az login expired, IMDS unreachable, etc.).
                        print(f"{agent.log_prefix}   Auth method: Microsoft Entra ID (httpx event hook)")
                        print(f"{agent.log_prefix}   Run `hermes doctor` for credential-chain diagnostics, or")
                        print(f"{agent.log_prefix}   `az login` if your developer session expired.")
                    else:
                        auth_method = "Bearer (OAuth/setup-token)" if _is_oauth_token(key) else "x-api-key (API key)"
                        print(f"{agent.log_prefix}   Auth method: {auth_method}")
                        print(f"{agent.log_prefix}   Token prefix: {key[:12]}..." if isinstance(key, str) and len(key) > 12 else f"{agent.log_prefix}   Token: (empty or short)")
                    print(f"{agent.log_prefix}   Troubleshooting:")
                    from hermes_constants import display_hermes_home as _dhh_fn
                    _dhh = _dhh_fn()
                    print(f"{agent.log_prefix}     • Check ANTHROPIC_TOKEN in {_dhh}/.env for Hermes-managed OAuth/setup tokens")
                    print(f"{agent.log_prefix}     • Check ANTHROPIC_API_KEY in {_dhh}/.env for API keys or legacy token values")
                    print(f"{agent.log_prefix}     • For API keys: verify at https://platform.claude.com/settings/keys")
                    print(f"{agent.log_prefix}     • For Claude Code: run 'claude /login' to refresh, then retry")
                    print(f"{agent.log_prefix}     • Legacy cleanup: hermes config set ANTHROPIC_TOKEN \"\"")
                    print(f"{agent.log_prefix}     • Clear stale keys: hermes config set ANTHROPIC_API_KEY \"\"")

                # Thinking block signature recovery.
                #
                # Anthropic signs thinking blocks against the full turn
                # content. Any upstream mutation (context compression,
                # session truncation, message merging) invalidates the
                # signature and the API replies HTTP 400 ("invalid
                # signature" or "cannot be modified"). Recovery strips
                # ``reasoning_details`` so the retry sends no thinking
                # blocks at all. One-shot per outer loop.
                #
                # The strip targets ``api_messages``, which is the
                # API-call-time list that ``_build_api_kwargs`` consumes
                # on every retry. ``api_messages`` was populated once at
                # the start of the turn from shallow copies of
                # ``messages``, so mutating it does not touch the
                # canonical store. The previous implementation popped
                # ``reasoning_details`` from ``messages`` instead, which
                # had two problems: ``api_messages`` carried its own
                # reference to the field through the shallow copy, so the
                # retry's wire payload still included thinking blocks and
                # the recovery never reached the API; and the mutation
                # persisted into ``state.db`` through any subsequent
                # ``_persist_session`` call, permanently corrupting the
                # conversation. Future turns would replay the stripped
                # state, hit the same 400, and the agent would terminate
                # with ``max_retries_exhausted``, often spawning
                # cascading compaction-ended sessions chained off the
                # corrupted parent.
                if (
                    classified.reason == FailoverReason.thinking_signature
                    and not _retry.thinking_sig_retry_attempted
                ):
                    _retry.thinking_sig_retry_attempted = True
                    _api_stripped = 0
                    for _m in api_messages:
                        if isinstance(_m, dict) and "reasoning_details" in _m:
                            _m.pop("reasoning_details", None)
                            _api_stripped += 1
                    agent._vprint(
                        f"{agent.log_prefix}⚠️  Thinking block signature invalid, "
                        f"stripped reasoning_details from api_messages for retry...",
                        force=True,
                    )
                    logger.warning(
                        "%sThinking block signature recovery: stripped "
                        "reasoning_details from %d api_messages "
                        "(canonical messages unchanged)",
                        agent.log_prefix, _api_stripped,
                    )
                    continue

                # ── Invalid encrypted reasoning replay recovery ───────
                # OpenAI Responses API surfaces (and some compatible relays)
                # return HTTP 400 ``invalid_encrypted_content`` when a
                # replayed ``codex_reasoning_items`` blob from a previous
                # turn fails verification (provider rotated the encryption
                # key, the route doesn't actually persist reasoning state,
                # etc.).  Recovery: disable replay for the rest of the
                # session, strip cached items from history, retry once.
                # One-shot — if a second 400 fires we fall through to the
                # normal retry/backoff path.  Only fires for codex_responses
                # mode with at least one assistant message that has cached
                # ``codex_reasoning_items``; without replay state, the
                # error is unrelated to our cache so the normal retry path
                # handles it (the provider is rejecting something else).
                if (
                    classified.reason == FailoverReason.invalid_encrypted_content
                    and not _retry.invalid_encrypted_content_retry_attempted
                    and agent.api_mode == "codex_responses"
                    and bool(getattr(agent, "_codex_reasoning_replay_enabled", True))
                    and any(
                        isinstance(_m, dict)
                        and _m.get("role") == "assistant"
                        and isinstance(_m.get("codex_reasoning_items"), list)
                        and _m.get("codex_reasoning_items")
                        for _m in messages
                    )
                ):
                    _retry.invalid_encrypted_content_retry_attempted = True
                    replay_stats = agent._disable_codex_reasoning_replay(messages)
                    agent._vprint(
                        f"{agent.log_prefix}⚠️  Encrypted reasoning replay was rejected by the provider — "
                        f"disabled replay and stripped {replay_stats['items']} item(s) from "
                        f"{replay_stats['messages']} message(s), retrying...",
                        force=True,
                    )
                    logger.warning(
                        "%sInvalid encrypted reasoning recovery: disabled replay and stripped %d items from %d messages",
                        agent.log_prefix,
                        replay_stats["items"],
                        replay_stats["messages"],
                    )
                    continue

                # ── Native compaction rejection recovery ──────────────
                # Provider explicitly rejected the ``context_management``
                # field (structured 400 naming the param). One-shot: turn
                # native compaction off for the rest of the session and
                # retry — the next _build_api_kwargs re-resolves the gate
                # and omits the field, and Hermes' local compression takes
                # over as the sole owner. Generic 4xx/5xx/timeouts do NOT
                # match (see is_native_compaction_rejection) and take the
                # normal retry path.
                if (
                    agent.api_mode == "codex_responses"
                    and not _retry.native_compaction_reject_retry_attempted
                    and bool(getattr(agent, "codex_responses_native_compaction", False))
                ):
                    from agent.native_compaction import is_native_compaction_rejection
                    if is_native_compaction_rejection(
                        api_error, getattr(api_error, "status_code", None)
                    ):
                        _retry.native_compaction_reject_retry_attempted = True
                        agent.codex_responses_native_compaction = False
                        agent._vprint(
                            f"{agent.log_prefix}⚠️  Provider rejected native compaction "
                            f"(context_management) — disabled for this session, "
                            f"local compression stays active. Retrying...",
                            force=True,
                        )
                        logger.warning(
                            "%sNative compaction rejection recovery: disabled "
                            "codex_responses_native for this session and retrying",
                            agent.log_prefix,
                        )
                        continue

                # ── llama.cpp grammar-parse recovery ──────────────────
                # llama.cpp's ``json-schema-to-grammar`` converter rejects
                # regex escape classes (``\d``, ``\w``, ``\s``) and most
                # ``format`` values in tool schemas.  MCP servers emit
                # these routinely for date/phone/email params.  Recovery:
                # strip ``pattern``/``format`` from ``agent.tools`` and
                # retry once.  We keep the keywords by default so cloud
                # providers get the full prompting hints; this branch
                # fires only for users on llama.cpp's OAI server.
                if (
                    classified.reason == FailoverReason.llama_cpp_grammar_pattern
                    and not _retry.llama_cpp_grammar_retry_attempted
                ):
                    _retry.llama_cpp_grammar_retry_attempted = True
                    try:
                        from tools.schema_sanitizer import strip_pattern_and_format
                        _, _stripped = strip_pattern_and_format(agent.tools)
                    except Exception as _strip_exc:  # pragma: no cover — defensive
                        logger.warning(
                            "%sllama.cpp grammar recovery: strip helper failed: %s",
                            agent.log_prefix, _strip_exc,
                        )
                        _stripped = 0
                    if _stripped:
                        agent._vprint(
                            f"{agent.log_prefix}⚠️  llama.cpp rejected tool schema grammar — "
                            f"stripped {_stripped} pattern/format keyword(s), retrying...",
                            force=True,
                        )
                        logger.warning(
                            "%sllama.cpp grammar recovery: stripped %d "
                            "pattern/format keyword(s) from tool schemas",
                            agent.log_prefix, _stripped,
                        )
                        continue
                    # No keywords found to strip — fall through to normal
                    # retry path rather than loop forever on the same error.
                    logger.warning(
                        "%sllama.cpp grammar error but no pattern/format "
                        "keywords to strip — falling through to normal retry",
                        agent.log_prefix,
                    )

                retry_count += 1
                elapsed_time = time.time() - api_start_time
                agent._touch_activity(
                    f"API error recovery (attempt {retry_count}/{max_retries})"
                )
                
                error_type = type(api_error).__name__
                error_msg = str(api_error).lower()
                _error_summary = agent._summarize_api_error(api_error)
                logger.warning(
                    "API call failed (attempt %s/%s) error_type=%s %s summary=%s",
                    retry_count,
                    max_retries,
                    error_type,
                    agent._client_log_context(),
                    _error_summary,
                )

                _provider = getattr(agent, "provider", "unknown")
                _base = getattr(agent, "base_url", "unknown")
                _model = getattr(agent, "model", "unknown")
                _status_code_str = f" [HTTP {status_code}]" if status_code else ""
                agent._buffer_vprint(f"⚠️  API call failed (attempt {retry_count}/{max_retries}): {error_type}{_status_code_str}")
                agent._buffer_vprint(f"   🔌 Provider: {_provider}  Model: {_model}")
                agent._buffer_vprint(f"   🌐 Endpoint: {_base}")
                agent._buffer_vprint(f"   📝 Error: {_error_summary}")
                if status_code and status_code < 500:
                    _err_body = getattr(api_error, "body", None)
                    _err_body_str = str(_err_body)[:300] if _err_body else None
                    if _err_body_str:
                        agent._buffer_vprint(f"   📋 Details: {_err_body_str}")
                agent._buffer_vprint(f"   ⏱️  Elapsed: {elapsed_time:.2f}s  Context: {len(api_messages)} msgs, ~{approx_tokens:,} tokens")

                # Actionable hint for OpenRouter "no tool endpoints" error.
                # Buffered like the rest of the retry trace — surfaced only
                # if every retry+fallback exhausts.  Avoids spamming users
                # who recover automatically via fallback.
                if (
                    agent._is_openrouter_url()
                    and "support tool use" in error_msg
                ):
                    agent._buffer_vprint(
                        f"   💡 No OpenRouter providers for {_model} support tool calling with your current settings."
                    )
                    if agent.providers_allowed:
                        agent._buffer_vprint(
                            "      Your provider_routing.only restriction is filtering out tool-capable providers."
                        )
                        agent._buffer_vprint(
                            "      Try removing the restriction or adding providers that support tools for this model."
                        )
                    agent._buffer_vprint(
                        f"      Check which providers support tools: https://openrouter.ai/models/{_model}"
                    )

                # Actionable hint for a bare 404 on a provider whose catalogue
                # uses ``vendor/model`` ids.  A model id that lost its prefix
                # (e.g. ``nemotron-…`` instead of ``nvidia/nemotron-…``) gets
                # a content-free "404 page not found" from the provider that
                # never names the model, so it reads like an outage or an auth
                # failure.  Name the real cause and the exact id to use (#78796).
                if getattr(api_error, "status_code", None) == 404:
                    try:
                        from hermes_cli.model_normalize import suggest_prefixed_model_id

                        _suggestion = suggest_prefixed_model_id(_provider, _model)
                    except Exception:
                        _suggestion = None
                    if _suggestion:
                        agent._buffer_vprint(
                            f"   💡 Model '{_model}' is not a valid id for provider {_provider} — "
                            f"it is missing its vendor prefix."
                        )
                        agent._buffer_vprint(
                            f"      Did you mean '{_suggestion}'?  Re-pick it with `hermes model`."
                        )

                # Check for interrupt before deciding to retry
                if agent._interrupt_requested:
                    # Preserve a pending redirect (mid-stream correction): the
                    # user is steering, not stopping. Rebuild the turn from the
                    # correction instead of aborting with a dead-end interrupt.
                    if agent.clear_interrupt(preserve_redirect=True):
                        _retry.restart_with_redirected_messages = True
                        break
                    agent._vprint(f"{agent.log_prefix}⚡ Interrupt detected during error handling, aborting retries.", force=True)
                    _interrupt_text = f"Operation interrupted: handling API error ({error_type}: {agent._clean_error_message(str(api_error))})."
                    close_interrupted_tool_sequence(messages, _interrupt_text)
                    agent._persist_session(messages, conversation_history)
                    agent.clear_interrupt()
                    return {
                        "final_response": _interrupt_text,
                        "messages": messages,
                        "api_calls": api_call_count,
                        "completed": False,
                        "interrupted": True,
                    }
                
                # Check for 413 payload-too-large BEFORE generic 4xx handler.
                # A 413 is a payload-size error — the correct response is to
                # compress history and retry, not abort immediately.
                status_code = getattr(api_error, "status_code", None)

                # ── Respect disabled auto-compaction on overflow ──────
                # Ported from anomalyco/opencode#30749.  When the user has
                # turned auto-compaction off (``compression.enabled: false``),
                # NO automatic compaction trigger may fire — including the
                # provider/request-size overflow recovery paths below
                # (long-context-tier 429, 413 payload-too-large, and
                # context-overflow).  Without this guard the proactive
                # threshold path correctly honours the setting (see the
                # preflight check and the post-response ``should_compress``
                # gate) but a provider overflow error would still silently
                # compress + rotate the session, bypassing the user's
                # explicit choice.  Surface a terminal error instead so the
                # user can compact manually (``/compress``), start fresh
                # (``/new``), switch to a larger-context model, or reduce
                # attachments.  Forced compaction via ``/compress``
                # (``force=True``) is unaffected — it never reaches this loop.
                #
                # Output-cap errors (max_tokens too large) are NOT input
                # overflow — the recovery is a max_tokens-only retry that
                # does not require compression.  Exempt them from this guard
                # so the retry still fires even when compression is disabled.
                _overflow_reasons = {
                    FailoverReason.long_context_tier,
                    FailoverReason.payload_too_large,
                    FailoverReason.context_overflow,
                }
                _is_output_cap_error = (
                    is_output_cap_error(error_msg)
                    or parse_available_output_tokens_from_error(error_msg) is not None
                )
                if (
                    classified.reason in _overflow_reasons
                    and not getattr(agent, "compression_enabled", True)
                    and not _is_output_cap_error
                ):
                    agent._flush_status_buffer()
                    agent._vprint(
                        f"{agent.log_prefix}❌ Context overflow, but auto-compaction is disabled "
                        f"(compression.enabled: false).",
                        force=True,
                    )
                    agent._vprint(
                        f"{agent.log_prefix}   💡 Run /compress to compact manually, /new to start fresh, "
                        f"switch to a larger-context model, or reduce attachments.",
                        force=True,
                    )
                    logger.error(
                        f"{agent.log_prefix}Context overflow ({classified.reason.value}) with "
                        f"auto-compaction disabled — not compressing."
                    )
                    agent._persist_session(messages, conversation_history)
                    _final_response = (
                        "Context overflow and auto-compaction is disabled "
                        "(compression.enabled: false). Run /compress to compact manually, "
                        "/new to start fresh, or switch to a larger-context model."
                    )
                    return {
                        "final_response": _final_response,
                        "messages": messages,
                        "completed": False,
                        "api_calls": api_call_count,
                        "error": _final_response,
                        "partial": True,
                        "failed": True,
                        "compaction_disabled": True,
                    }

                # ── Anthropic Sonnet long-context tier gate ───────────
                # Anthropic returns HTTP 429 "Extra usage is required for
                # long context requests" when a Claude Max (or similar)
                # subscription doesn't include the 1M-context tier.  This
                # is NOT a transient rate limit — retrying or switching
                # credentials won't help.  Reduce context to 200k (the
                # standard tier) and compress.
                if classified.reason == FailoverReason.long_context_tier:
                    _reduced_ctx = 200000
                    compressor = agent.context_compressor
                    old_ctx = compressor.context_length
                    if old_ctx > _reduced_ctx:
                        compressor.update_model(
                            model=agent.model,
                            context_length=_reduced_ctx,
                            base_url=agent.base_url,
                            api_key=getattr(agent, "api_key", ""),
                            provider=agent.provider,
                            api_mode=agent.api_mode,
                        )
                        # Context probing flags — only set on built-in
                        # compressor (plugin engines manage their own).
                        if hasattr(compressor, "_context_probed"):
                            compressor._context_probed = True
                            # Don't persist — this is a subscription-tier
                            # limitation, not a model capability.  If the
                            # user later enables extra usage the 1M limit
                            # should come back automatically.
                            compressor._context_probe_persistable = False
                        agent._buffer_vprint(
                            f"⚠️  Anthropic long-context tier "
                            f"requires extra usage — reducing context: "
                            f"{old_ctx:,} → {_reduced_ctx:,} tokens"
                        )

                    compression_attempts += 1
                    if compression_attempts <= max_compression_attempts:
                        original_len = len(messages)
                        # Option A (LCM issue 441): overhead-aware request size so recovery arms on
                        # the true request (msgs + tools + system), not the tool-blind message count.
                        messages, active_system_prompt = agent._compress_context(
                            messages, system_message,
                            approx_tokens=estimate_request_tokens_rough(api_messages, tools=agent.tools or None),
                            task_id=effective_task_id,
                        )
                        conversation_history = conversation_history_after_compression(
                            agent, messages, conversation_history
                        )
                        if len(messages) < original_len or old_ctx > _reduced_ctx:
                            agent._buffer_status(
                                COMPRESSION_RETRY_CONTEXT_REDUCED_STATUS_TEMPLATE.format(
                                    new_ctx=_reduced_ctx, old_ctx=old_ctx
                                )
                            )
                            time.sleep(2)
                            _retry.restart_with_compressed_messages = True
                            break
                    # Fall through to normal error handling if compression
                    # is exhausted or didn't help.

                # Eager fallback for rate-limit errors (429 or quota exhaustion)
                # and transport errors (connection failure / timeout / provider
                # overloaded).  Rate limits and billing: switch immediately —
                # the primary provider won't recover within the retry window.
                # Transport errors: allow 1 retry first (transient hiccups
                # recover), then fall back if the provider is truly unreachable.
                is_rate_limited = classified.reason in {
                    FailoverReason.rate_limit,
                    FailoverReason.billing,
                    FailoverReason.upstream_rate_limit,
                }
                # Relay-wrapped output-cap errors: some gateways wrap an
                # upstream "[400]: max_tokens (...) exceeds model's maximum
                # output tokens (...)" as HTTP 429, which classifies as
                # rate_limit. The failure is a deterministic request-shape
                # problem — falling back to another provider (or burning
                # generic retries) can't fix it, but the output-cap clamp
                # below can, in one retry (#72281). Parse once here; the
                # result gates both the eager-fallback exemption and the
                # widened is_context_length_error entry, and is reused as
                # available_out inside the handler.
                _wrapped_output_cap_budget = (
                    parse_available_output_tokens_from_error(error_msg)
                    if classified.reason == FailoverReason.rate_limit
                    else None
                )
                _is_transport_failure = classified.reason in {
                    FailoverReason.timeout,
                    FailoverReason.overloaded,
                }
                # Z.AI Coding Plan GLM-5.2 overload 429s classify as
                # `overloaded` (to spare the credential pool), but `overloaded`
                # is excluded from `is_rate_limited` — the gate for the adaptive
                # Z.AI backoff below. Detect the overload directly so its
                # long-backoff schedule runs, and raise the retry ceiling so the
                # long tier (30/60/90/120s) is reachable. See
                # zai_coding_overload_retry_ceiling() for the ceiling rationale.
                _is_zai_coding_overload = is_zai_coding_overload_error(
                    base_url=str(_base), model=_model, error=api_error
                )
                if _is_zai_coding_overload:
                    max_retries = max(max_retries, zai_coding_overload_retry_ceiling())
                _should_fallback = (
                    (is_rate_limited and _wrapped_output_cap_budget is None)
                    or (_is_transport_failure and retry_count >= 2)
                )
                if _should_fallback and agent._fallback_index < len(agent._fallback_chain):
                    # Don't eagerly fallback if credential pool rotation may
                    # still recover.  See _pool_may_recover_from_rate_limit
                    # for the single-credential-pool exception.  Fixes #11314.
                    #
                    # Exception: an upstream-aggregator 429 — the credential
                    # pool can't help when the *upstream* model (DeepSeek,
                    # etc.) is throttling OpenRouter, so always fall back to a
                    # different model regardless of pool state.
                    _is_upstream = classified.reason == FailoverReason.upstream_rate_limit
                    pool_may_recover = (
                        False if _is_upstream
                        else _ra()._pool_may_recover_from_rate_limit(
                            agent._credential_pool,
                        )
                    )
                    if not pool_may_recover:
                        if _is_upstream:
                            _upstream_name = (classified.error_context or {}).get(
                                "upstream_provider", "aggregator"
                            )
                            agent._buffer_status(
                                f"⚠️ Upstream {_upstream_name} rate-limited — "
                                "switching to fallback model..."
                            )
                        elif classified.reason == FailoverReason.billing:
                            if classified.billing_unverified:
                                # Ambiguous body (#82154) — don't assert billing.
                                agent._buffer_status(
                                    "⚠️ Provider reported usage/credit exhaustion "
                                    "(unverified — may be a content-filter rejection) "
                                    "— switching to fallback provider..."
                                )
                            else:
                                agent._buffer_status(
                                    "⚠️ Billing or credits exhausted — switching to fallback provider..."
                                )
                        elif _is_transport_failure:
                            agent._buffer_status(
                                "⚠️ Provider unreachable — switching to fallback provider..."
                            )
                        else:
                            agent._buffer_status("⚠️ Rate limited — switching to fallback provider...")
                        if agent._try_activate_fallback(reason=classified.reason):
                            active_system_prompt = _sync_failover_system_message(
                                agent, api_messages, active_system_prompt)
                            retry_count = 0
                            compression_attempts = 0
                            _retry.primary_recovery_attempted = False
                            _retry.restart_with_rebuilt_messages = True
                            break

                # ── Auth-failure provider failover ───────────────────────
                # A 401/403 that survives the per-provider credential-refresh
                # attempt above (each guarded by its own
                # ``*_auth_retry_attempted`` flag) means the active provider's
                # credential or endpoint is broken in a way refreshing can't
                # fix (revoked OAuth, blocked/expired key, an account pinned to
                # a dead/staging endpoint). Previously the loop only printed
                # "switch providers manually" advice and fell through, so a
                # user with a configured fallback chain kept thrashing on the
                # same dead credential every turn instead of failing over.
                # Escalate to the fallback chain here, mirroring the rate-
                # limit/billing failover above. When no fallback is configured
                # (or the chain is exhausted), _try_activate_fallback returns
                # False and we fall through to the existing terminal handling
                # + provider-specific troubleshooting guidance unchanged.
                if (
                    classified.is_auth
                    and not _retry.auth_failover_attempted
                    and agent._fallback_index < len(agent._fallback_chain)
                ):
                    _retry.auth_failover_attempted = True
                    agent._buffer_status(
                        "🔐 Authentication failed and could not be refreshed — "
                        "switching to fallback provider..."
                    )
                    if agent._try_activate_fallback(reason=classified.reason):
                        active_system_prompt = _sync_failover_system_message(
                            agent, api_messages, active_system_prompt)
                        retry_count = 0
                        compression_attempts = 0
                        _retry.primary_recovery_attempted = False
                        _retry.restart_with_rebuilt_messages = True
                        break

                # ── Nous Portal: record rate limit & skip retries ─────
                # When Nous returns a 429 that is a genuine account-
                # level rate limit, record the reset time to a shared
                # file so ALL sessions (cron, gateway, auxiliary) know
                # not to pile on, then skip further retries -- each
                # one burns another RPH request and deepens the hole.
                # The retry loop's top-of-iteration guard will catch
                # this on the next pass and try fallback or bail.
                #
                # IMPORTANT: Nous Portal multiplexes multiple upstream
                # providers (DeepSeek, Kimi, MiMo, Hermes).  A 429 can
                # also mean an UPSTREAM provider is out of capacity
                # for one specific model -- transient, clears in
                # seconds, nothing to do with the caller's quota.
                # Tripping the cross-session breaker on that would
                # block every Nous model for minutes.  We use
                # ``is_genuine_nous_rate_limit`` to tell the two
                # apart via the 429's own x-ratelimit-* headers and
                # the last-known-good state captured on the previous
                # successful response.
                if (
                    is_rate_limited
                    and agent.provider == "nous"
                    and classified.reason == FailoverReason.rate_limit
                    and not recovered_with_pool
                ):
                    _genuine_nous_rate_limit = False
                    try:
                        from agent.nous_rate_guard import (
                            is_genuine_nous_rate_limit,
                            record_nous_rate_limit,
                        )
                        _err_resp = getattr(api_error, "response", None)
                        _err_hdrs = (
                            getattr(_err_resp, "headers", None)
                            if _err_resp else None
                        )
                        _genuine_nous_rate_limit = is_genuine_nous_rate_limit(
                            headers=_err_hdrs,
                            last_known_state=agent._rate_limit_state,
                        )
                        if _genuine_nous_rate_limit:
                            record_nous_rate_limit(
                                headers=_err_hdrs,
                                error_context=error_context,
                            )
                        else:
                            logger.info(
                                "Nous 429 looks like upstream capacity "
                                "(no exhausted bucket in headers or "
                                "last-known state) -- not tripping "
                                "cross-session breaker."
                            )
                    except Exception:
                        pass
                    if _genuine_nous_rate_limit:
                        # Re-enter the loop exactly once so the
                        # top-of-loop Nous guard handles fallback or
                        # bails cleanly. (Setting retry_count to
                        # max_retries would make the while condition
                        # false immediately and the guard would never
                        # run -- no fallback, generic exhaustion error.)
                        retry_count = max(0, max_retries - 1)
                        continue
                    # Upstream capacity 429: fall through to normal
                    # retry logic.  A different model (or the same
                    # model a moment later) will typically succeed.

                is_payload_too_large = (
                    classified.reason == FailoverReason.payload_too_large
                )

                # Actionable hint for GitHub Models (Azure) 413 errors.
                # The free tier enforces a hard 8K token cap per request,
                # which Hermes' system prompt + tool schemas alone exceed.
                # Compression can't help — the floor is the system prompt
                # itself, not the conversation — so surface a clear "not
                # compatible" message instead of looping into three futile
                # compression attempts.
                if (
                    status_code == 413
                    and isinstance(agent.base_url, str)
                    and base_url_host_matches(agent.base_url, "models.inference.ai.azure.com")
                ):
                    agent._vprint(
                        f"{agent.log_prefix}   💡 GitHub Models free tier (models.inference.ai.azure.com) caps every",
                        force=True,
                    )
                    agent._vprint(
                        f"{agent.log_prefix}      request at ~8K tokens. Hermes' system prompt + tool schemas baseline",
                        force=True,
                    )
                    agent._vprint(
                        f"{agent.log_prefix}      exceeds that floor, so this endpoint cannot run an agentic loop.",
                        force=True,
                    )
                    agent._vprint(
                        f"{agent.log_prefix}      Use the `copilot` provider with a Copilot subscription token (`hermes",
                        force=True,
                    )
                    agent._vprint(
                        f"{agent.log_prefix}      setup` → GitHub Copilot), or pick any other provider.",
                        force=True,
                    )

                if is_payload_too_large:
                    compression_attempts += 1
                    if compression_attempts > max_compression_attempts:
                        # Terminal — surface the buffered retry trace.
                        agent._flush_status_buffer()
                        agent._vprint(f"{agent.log_prefix}❌ Max compression attempts ({max_compression_attempts}) reached for payload-too-large error.", force=True)
                        agent._vprint(f"{agent.log_prefix}   💡 Try /new to start a fresh conversation, or /compress to retry compression.", force=True)
                        logger.error("%s413 compression failed after %d attempts.", agent.log_prefix, max_compression_attempts)
                        agent._persist_session(messages, conversation_history)
                        _final_response = f"Request payload too large: max compression attempts ({max_compression_attempts}) reached."
                        return {
                            "final_response": _final_response,
                            "messages": messages,
                            "completed": False,
                            "api_calls": api_call_count,
                            "error": _final_response,
                            "partial": True,
                            "failed": True,
                            "compression_exhausted": True,
                        }
                    agent._buffer_status(f"⚠️  Request payload too large (413) — compression attempt {compression_attempts}/{max_compression_attempts}...")

                    original_len = len(messages)
                    # A 413 is a BYTE-size error, so this branch scores
                    # progress in BYTES of the serialized messages payload —
                    # exact and free — never the token estimate.  The
                    # estimator prices every image at a flat per-image token
                    # cost (see estimate_messages_tokens_rough) so screenshots
                    # don't trigger premature compaction; that deliberate
                    # byte-blindness means compaction can free megabytes of
                    # base64 (real case: two vision results = 96.6% of the
                    # request body but ~3.7% of the estimate) while the token
                    # delta stays under any threshold.  Token-scored progress
                    # here burned all attempts on "no progress" and wedged
                    # the session permanently. (#88960 / #47339)
                    original_bytes = serialized_messages_bytes(messages)
                    _overflow_input = messages
                    # Option A (LCM issue 441): overhead-aware request size so recovery arms on the
                    # true request (msgs + tools + system), not the tool-blind message count.
                    messages, active_system_prompt = agent._compress_context(
                        messages, system_message,
                        approx_tokens=estimate_request_tokens_rough(api_messages, tools=agent.tools or None),
                        task_id=effective_task_id,
                    )
                    if messages is _overflow_input and compression_skipped_due_to_lock(agent):
                        # #69870 lock-skip: the provider proved the request
                        # does not fit, but this compression pass no-oped only
                        # because another path holds the session's compression
                        # lock. Temporary defer, not exhaustion — refund the
                        # attempt and end the turn softly so the gateway does
                        # NOT auto-reset the session (#9893/#35809).
                        compression_attempts -= 1
                        agent._persist_session(messages, conversation_history)
                        return _compression_deferred_result(
                            agent, messages, api_call_count
                        )
                    if messages is _overflow_input and compression_blocked_transiently(agent):
                        # #97488 transient-block: compression no-oped because a
                        # timed guard (host-timeout cooldown / structural
                        # backoff) is active — a temporary defer, not evidence
                        # of incompressibility. Never classify it as
                        # compression_exhausted (gateway auto-reset).
                        compression_attempts -= 1
                        agent._persist_session(messages, conversation_history)
                        return _compression_deferred_result(
                            agent, messages, api_call_count,
                            reason="transient_block",
                        )
                    conversation_history = conversation_history_after_compression(
                        agent, messages, conversation_history
                    )

                    # Re-measure after compression.  Same-message-count
                    # compression (tool-result pruning, in-place summarization)
                    # can materially reduce request size without reducing the
                    # message array (#39550), and — the image-dominated case —
                    # compaction's historical-media aging (#97160) can free
                    # megabytes of base64 that the token estimate never
                    # counted.  Bytes are the yardstick for a 413; tokens are
                    # kept only for status display.
                    new_tokens = estimate_messages_tokens_rough(messages)
                    approx_tokens = new_tokens  # update for downstream logging
                    new_bytes = serialized_messages_bytes(messages)

                    made_progress = (
                        len(messages) < original_len
                        or (new_bytes > 0 and new_bytes < original_bytes * 0.95)
                    )
                    if made_progress:
                        if len(messages) < original_len:
                            agent._buffer_status(COMPRESSION_RETRY_MESSAGES_STATUS_TEMPLATE.format(before=original_len, after=len(messages)))
                        else:
                            agent._buffer_status(
                                f"🗜️ Compressed {original_bytes:,} → {new_bytes:,} "
                                f"payload bytes, retrying..."
                            )
                        time.sleep(2)  # Brief pause between compression retries
                        _retry.restart_with_compressed_messages = True
                        break
                    else:
                        if agent._try_strip_image_parts_from_tool_messages(
                            api_messages,
                            remember_model=False,
                        ):
                            agent._buffer_status(
                                "📐 Compression could not reduce the request further — "
                                "removed retained vision payloads and retrying..."
                            )
                            continue

                        # Terminal — surface buffered context so the user
                        # sees what compression attempts were made.
                        agent._flush_status_buffer()
                        agent._vprint(f"{agent.log_prefix}❌ Payload too large and cannot compress further.", force=True)
                        agent._vprint(f"{agent.log_prefix}   💡 Try /new to start a fresh conversation, or /compress to retry compression.", force=True)
                        logger.error("%s413 payload too large. Cannot compress further.", agent.log_prefix)
                        agent._persist_session(messages, conversation_history)
                        _final_response = "Request payload too large (413). Cannot compress further."
                        return {
                            "final_response": _final_response,
                            "messages": messages,
                            "completed": False,
                            "api_calls": api_call_count,
                            "error": _final_response,
                            "partial": True,
                            "failed": True,
                            "compression_exhausted": True,
                        }

                # Check for context-length errors BEFORE generic 4xx handler.
                # The classifier detects context overflow from: explicit error
                # messages, generic 400 + large session heuristic (#1630), and
                # server disconnect + large session pattern (#2153).
                is_context_length_error = (
                    classified.reason == FailoverReason.context_overflow
                    # Relay-wrapped output-cap 429s (parsed once above, where
                    # the eager-fallback exemption is gated) route into the
                    # output-cap clamp below instead of provider failover or
                    # generic retries (#72281).
                    or _wrapped_output_cap_budget is not None
                )

                if is_context_length_error:
                    compressor = agent.context_compressor
                    old_ctx = compressor.context_length

                    # ── Distinguish two very different errors ───────────
                    # 1. "Prompt too long": the INPUT exceeds the context window.
                    #    Fix: reduce context_length + compress history.
                    # 2. "max_tokens too large": input is fine, but
                    #    input_tokens + requested max_tokens > context_window.
                    #    Fix: reduce max_tokens (the OUTPUT cap) for this call.
                    #    Do NOT shrink context_length — the window is unchanged.
                    #
                    # Note: max_tokens = output token cap (one response).
                    #       context_length = total window (input + output combined).
                    available_out = parse_available_output_tokens_from_error(error_msg)
                    if available_out is not None:
                        # This is an output-cap error, not input overflow.
                        # The provider's available_tokens is the authoritative
                        # cap for the failed request, so keep it as an upper
                        # bound.  Also estimate the current API request shape
                        # (system prompt, injected context, tool schemas) because
                        # Hermes may add API-only content not present in persisted
                        # messages.  Use the smaller budget and apply a small
                        # safety margin.  Do not alter context_length.
                        request_input_estimate = estimate_request_tokens_rough(
                            api_messages, tools=agent.tools or None,
                        )
                        local_available_out = old_ctx - request_input_estimate
                        if local_available_out > 0:
                            safe_out = max(1, min(available_out, local_available_out) - 64)
                        else:
                            # The rough local estimate can overshoot the real
                            # request size.  Fall back to the provider-reported
                            # budget, which is authoritative for the failed
                            # request.
                            safe_out = max(1, available_out - 64)
                        agent._ephemeral_max_output_tokens = safe_out
                        agent._buffer_vprint(
                            f"⚠️  Output cap too large for current prompt — "
                            f"retrying with max_tokens={safe_out:,} "
                            f"(provider_available={available_out:,}, "
                            f"estimated_request_tokens={request_input_estimate:,}; "
                            f"context_length unchanged at {old_ctx:,})"
                        )
                        # Still count against compression_attempts so we don't
                        # loop forever if the error keeps recurring.
                        compression_attempts += 1
                        if compression_attempts > max_compression_attempts:
                            agent._flush_status_buffer()
                            agent._vprint(f"{agent.log_prefix}❌ Max compression attempts ({max_compression_attempts}) reached.", force=True)
                            agent._vprint(f"{agent.log_prefix}   💡 Try /new to start a fresh conversation, or /compress to retry compression.", force=True)
                            logger.error("%sContext compression failed after %d attempts.", agent.log_prefix, max_compression_attempts)
                            agent._persist_session(messages, conversation_history)
                            _final_response = f"Context length exceeded: max compression attempts ({max_compression_attempts}) reached."
                            return {
                                "final_response": _final_response,
                                "messages": messages,
                                "completed": False,
                                "api_calls": api_call_count,
                                "error": _final_response,
                                "partial": True,
                                "failed": True,
                                "compression_exhausted": True,
                            }
                        # Also compress the message history so the output-cap
                        # retry does not just spin on max_tokens alone.  The
                        # compressor drops the middle window, freeing enough
                        # tokens for the total to fit inside context_length.
                        # (#55546)
                        try:
                            original_len = len(messages)
                            original_tokens = estimate_messages_tokens_rough(messages)
                            _overflow_input = messages
                            messages, active_system_prompt = agent._compress_context(
                                messages, system_message,
                                approx_tokens=request_input_estimate,
                                task_id=effective_task_id,
                            )
                            if messages is _overflow_input and compression_skipped_due_to_lock(agent):
                                compression_attempts -= 1
                                agent._persist_session(messages, conversation_history)
                                return _compression_deferred_result(
                                    agent, messages, api_call_count
                                )
                            if messages is _overflow_input and compression_blocked_transiently(agent):
                                # #97488: timed transient guard — defer, never
                                # exhaustion (gateway auto-reset).
                                compression_attempts -= 1
                                agent._persist_session(messages, conversation_history)
                                return _compression_deferred_result(
                                    agent, messages, api_call_count,
                                    reason="transient_block",
                                )
                            conversation_history = conversation_history_after_compression(
                                agent, messages, conversation_history
                            )
                            new_tokens = estimate_messages_tokens_rough(messages)
                            if len(messages) < original_len:
                                agent._buffer_status(COMPRESSION_RETRY_MESSAGES_STATUS_TEMPLATE.format(before=original_len, after=len(messages)))
                            elif new_tokens > 0 and new_tokens < original_tokens * 0.95:
                                agent._buffer_status(COMPRESSION_RETRY_TOKENS_STATUS_TEMPLATE.format(before=original_tokens, after=new_tokens))
                        except Exception:
                            # Compression must never turn an output-cap error
                            # fatal — fall through and retry on max_tokens alone.
                            logger.warning(
                                "%sOutput-cap compression hit an error; retrying on max_tokens only.",
                                agent.log_prefix,
                            )
                        _retry.restart_with_compressed_messages = True
                        break

                    # The error is output-cap-shaped (about max_tokens being
                    # too large) but the provider's wording didn't let us parse
                    # the available output budget.  Compression CANNOT help here
                    # — the input already fits; the call fails deterministically
                    # on the oversized max_tokens.  Routing it into compression
                    # re-sends the same max_tokens, gets the identical 400, and
                    # death-loops until "cannot compress further" (#55546).
                    # Fail fast with an actionable message instead of looping.
                    if is_output_cap_error(error_msg):
                        agent._flush_status_buffer()
                        agent._vprint(
                            f"{agent.log_prefix}❌ The provider rejected the request because "
                            f"max_tokens exceeds its output cap for this model.",
                            force=True,
                        )
                        agent._vprint(
                            f"{agent.log_prefix}   💡 Lower model.max_tokens in your config.yaml to "
                            f"at or below the model's max-output limit. "
                            f"(This is an output-cap error, not a context overflow — "
                            f"compression cannot fix it.)",
                            force=True,
                        )
                        logger.error(
                            f"{agent.log_prefix}Output-cap error not routed into compression "
                            f"(max_tokens over provider cap): {error_msg[:200]}"
                        )
                        agent._persist_session(messages, conversation_history)
                        _final_response = (
                            "max_tokens exceeds the provider's output cap for this model. "
                            "Lower model.max_tokens in config.yaml."
                        )
                        return {
                            "final_response": _final_response,
                            "messages": messages,
                            "completed": False,
                            "api_calls": api_call_count,
                            "error": _final_response,
                            "partial": True,
                            "failed": True,
                        }

                    # Error is about the INPUT being too large.  Only reduce
                    # context_length when the provider explicitly reports the
                    # real lower limit.  If the provider only says "input
                    # exceeds the context window", keep the configured window
                    # and try compression; guessing probe tiers can incorrectly
                    # turn a user-configured 1M window into 256K/128K/64K.
                    new_ctx = get_context_length_from_provider_error(error_msg, old_ctx)
                    _provider_lower = (getattr(agent, "provider", "") or "").lower()
                    _base_lower = (getattr(agent, "base_url", "") or "").rstrip("/").lower()
                    is_minimax_provider = (
                        _provider_lower in {"minimax", "minimax-cn"}
                        or _base_lower.startswith((
                            "https://api.minimax.io/anthropic",
                            "https://api.minimaxi.com/anthropic",
                        ))
                    )
                    minimax_delta_only_overflow = (
                        is_minimax_provider
                        and new_ctx is None
                        and "context window exceeds limit (" in error_msg
                    )

                    if new_ctx is not None:
                        agent._buffer_vprint(f"Context limit detected from API: {new_ctx:,} tokens (was {old_ctx:,})")
                        compressor.update_model(
                            model=agent.model,
                            context_length=new_ctx,
                            base_url=agent.base_url,
                            api_key=getattr(agent, "api_key", ""),
                            provider=agent.provider,
                            api_mode=agent.api_mode,
                        )
                        # Persist an explicit provider-reported limit before
                        # compression/retry. The next request can be rate
                        # limited, omit usage, or the process can restart; none
                        # of those should discard metadata the provider already
                        # confirmed. Keep the probe flags as a best-effort
                        # post-success retry if this write cannot complete.
                        save_context_length(agent.model, agent.base_url, new_ctx)
                        # Context probing flags — only set on built-in
                        # compressor (plugin engines manage their own).  This
                        # value came from the provider, so it is safe to cache.
                        if hasattr(compressor, "_context_probed"):
                            compressor._context_probed = True
                            compressor._context_probe_persistable = True
                        agent._buffer_vprint(f"⚠️  Context length exceeded — using provider limit: {old_ctx:,} → {new_ctx:,} tokens")
                    elif minimax_delta_only_overflow:
                        agent._buffer_vprint(
                            f"Provider reported overflow amount only; "
                            f"keeping context_length at {old_ctx:,} tokens and compressing."
                        )
                    else:
                        agent._buffer_vprint(
                            f"⚠️  Context length exceeded, but provider did not report a max context length; "
                            f"keeping context_length at {old_ctx:,} tokens and compressing."
                        )

                    compression_attempts += 1
                    if compression_attempts > max_compression_attempts:
                        agent._flush_status_buffer()
                        agent._vprint(f"{agent.log_prefix}❌ Max compression attempts ({max_compression_attempts}) reached.", force=True)
                        agent._vprint(f"{agent.log_prefix}   💡 Try /new to start a fresh conversation, or /compress to retry compression.", force=True)
                        logger.error("%sContext compression failed after %d attempts.", agent.log_prefix, max_compression_attempts)
                        agent._persist_session(messages, conversation_history)
                        _final_response = f"Context length exceeded: max compression attempts ({max_compression_attempts}) reached."
                        return {
                            "final_response": _final_response,
                            "messages": messages,
                            "completed": False,
                            "api_calls": api_call_count,
                            "error": _final_response,
                            "partial": True,
                            "failed": True,
                            "compression_exhausted": True,
                        }
                    agent._buffer_status(COMPRESSION_RETRY_TOO_LARGE_STATUS_TEMPLATE.format(tokens=approx_tokens, attempt=compression_attempts, cap=max_compression_attempts))

                    original_len = len(messages)
                    original_tokens = estimate_messages_tokens_rough(messages)
                    _overflow_input = messages
                    # Option A (LCM issue 441): pass the OVERHEAD-AWARE request size (msgs + tool
                    # schemas + system), not the tool-blind message count, so LCM forced-overflow
                    # recovery arms on the TRUE request that overflowed. See hermes-lcm engine
                    # _should_force_overflow_recovery. (approx_tokens stays for the status display.)
                    messages, active_system_prompt = agent._compress_context(
                        messages, system_message,
                        approx_tokens=estimate_request_tokens_rough(api_messages, tools=agent.tools or None),
                        task_id=effective_task_id,
                    )
                    if messages is _overflow_input and compression_skipped_due_to_lock(agent):
                        # #69870 lock-skip: the provider proved the request
                        # does not fit, but this compression pass no-oped only
                        # because another path holds the session's compression
                        # lock. Temporary defer, not exhaustion — refund the
                        # attempt and end the turn softly so the gateway does
                        # NOT auto-reset the session (#9893/#35809).
                        compression_attempts -= 1
                        agent._persist_session(messages, conversation_history)
                        return _compression_deferred_result(
                            agent, messages, api_call_count
                        )
                    if messages is _overflow_input and compression_blocked_transiently(agent):
                        # #97488 transient-block: a timed guard (host-timeout
                        # cooldown / structural backoff) no-oped this pass —
                        # defer softly, never compression_exhausted (which
                        # would auto-reset the session).
                        compression_attempts -= 1
                        agent._persist_session(messages, conversation_history)
                        return _compression_deferred_result(
                            agent, messages, api_call_count,
                            reason="transient_block",
                        )
                    if context_compression_timed_out(agent):
                        # Host progress-aware timeout (#98722, salvaged from
                        # #98741): the provider proved the request does not
                        # fit, but this recovery pass spent the full wait
                        # budget without a committed summary. Re-sending the
                        # unchanged request would bounce off the same overflow
                        # error and re-enter compression in the same turn. End
                        # the turn with the typed recovery contract instead —
                        # transcript intact, no further doomed provider sends.
                        agent._persist_session(messages, conversation_history)
                        _final_response = _COMPRESSION_TIMEOUT_FINAL_RESPONSE
                        return {
                            "final_response": _final_response,
                            "messages": messages,
                            "completed": False,
                            "api_calls": api_call_count,
                            "error": _final_response,
                            "partial": True,
                            "failed": True,
                            "compression_exhausted": True,
                            "turn_exit_reason": "context_compression_timeout",
                        }
                    conversation_history = conversation_history_after_compression(
                        agent, messages, conversation_history
                    )

                    # Re-estimate tokens after compression.  Same-message-count
                    # compression (tool-result pruning, in-place summarization)
                    # can materially reduce request size without reducing the
                    # message array.  (#39550)
                    new_tokens = estimate_messages_tokens_rough(messages)
                    approx_tokens = new_tokens  # update for downstream logging

                    if len(messages) < original_len or (new_tokens > 0 and new_tokens < original_tokens * 0.95) or (new_ctx and new_ctx < old_ctx):
                        if len(messages) < original_len:
                            agent._buffer_status(COMPRESSION_RETRY_MESSAGES_STATUS_TEMPLATE.format(before=original_len, after=len(messages)))
                        elif new_tokens > 0 and new_tokens < original_tokens * 0.95:
                            agent._buffer_status(COMPRESSION_RETRY_TOKENS_STATUS_TEMPLATE.format(before=original_tokens, after=new_tokens))
                        time.sleep(2)  # Brief pause between compression retries
                        _retry.restart_with_compressed_messages = True
                        break
                    else:
                        # Can't compress further and already at minimum tier
                        agent._flush_status_buffer()
                        agent._vprint(f"{agent.log_prefix}❌ Context length exceeded and cannot compress further.", force=True)
                        agent._vprint(f"{agent.log_prefix}   💡 The conversation has accumulated too much content. Try /new to start fresh, or /compress to manually trigger compression.", force=True)
                        logger.error("%sContext length exceeded: %s tokens. Cannot compress further.", agent.log_prefix, f"{new_tokens:,}")
                        agent._persist_session(messages, conversation_history)
                        _final_response = f"Context length exceeded ({new_tokens:,} tokens). Cannot compress further."
                        return {
                            "final_response": _final_response,
                            "messages": messages,
                            "completed": False,
                            "api_calls": api_call_count,
                            "error": _final_response,
                            "partial": True,
                            "failed": True,
                            "compression_exhausted": True,
                        }

                # Check for non-retryable client errors.  The classifier
                # already accounts for 413, 429, 529 (transient), context
                # overflow, and generic-400 heuristics.  Local validation
                # errors (ValueError, TypeError) are programming bugs.
                # Exclude UnicodeEncodeError — it's a ValueError subclass
                # but is handled separately by the surrogate sanitization
                # path above.  Exclude json.JSONDecodeError — also a
                # ValueError subclass, but it indicates a transient
                # provider/network failure (malformed response body,
                # truncated stream, routing layer corruption), not a
                # local programming bug, and should be retried (#14782).
                is_local_validation_error = (
                    isinstance(api_error, (ValueError, TypeError))
                    and not isinstance(
                        api_error, (UnicodeEncodeError, json.JSONDecodeError)
                    )
                    # ssl.SSLError (and its subclass SSLCertVerificationError)
                    # inherits from OSError *and* ValueError via Python MRO,
                    # so the isinstance(ValueError) check above would
                    # misclassify a TLS transport failure as a local
                    # programming bug and abort without retrying.  Exclude
                    # ssl.SSLError explicitly so the error classifier's
                    # retryable=True mapping takes effect instead.
                    and not isinstance(api_error, ssl.SSLError)
                    # Provider/SDK "NoneType is not iterable" failures are
                    # shape mismatches from upstream (e.g. chatgpt.com Codex
                    # backend response.completed.output=null) — not local
                    # programming bugs.  Even after #33042 made our own
                    # consumer immune, third-party shims and mocked clients
                    # can still surface this shape via TypeError.  Treat
                    # them as retryable so the error classifier's normal
                    # retry/fallback path runs instead of killing the turn
                    # as non-retryable (which left Telegram users staring
                    # at a bare "Non-retryable error" with no recovery).
                    and not (
                        isinstance(api_error, TypeError)
                        and "nonetype" in str(api_error).lower()
                        and "not iterable" in str(api_error).lower()
                    )
                )
                # ``FailoverReason.billing`` (HTTP 402) is NOT in this
                # exclusion set.  By the time we reach this block:
                #   • credential-pool rotation (line ~2031) has already
                #     fired for billing and either ``continue``d or
                #     returned (False, ...) — pool is exhausted or absent.
                #   • the eager-fallback branch above (line ~2422) also
                #     fires on billing and ``continue``s if a fallback
                #     provider is configured.
                # Falling through to here means BOTH recovery paths
                # gave up.  Treating 402 as retryable from this point
                # just burns more paid requests against a depleted
                # balance with no recovery mechanism left — see #31273
                # (real-world: ~$40 in 48h on a 24/7 gateway).  Aborting
                # mirrors how 401/403 (also ``should_fallback=True``)
                # already behave once their recovery paths have failed.
                is_client_error = (
                    is_local_validation_error
                    or (
                        not classified.retryable
                        and not classified.should_compress
                        and classified.reason not in {
                            FailoverReason.rate_limit,
                            FailoverReason.overloaded,
                            FailoverReason.context_overflow,
                            FailoverReason.payload_too_large,
                            FailoverReason.long_context_tier,
                            FailoverReason.thinking_signature,
                        }
                    )
                ) and not is_context_length_error

                if is_client_error:
                    # Copilot self-heal BEFORE fallback: a stale/degraded
                    # credential surfaces as a 400
                    # ``model_not_available_for_integrator`` /
                    # ``model_not_supported`` (not a clean 401), so the 401
                    # refresh path above never fired. Force a fresh token
                    # exchange + client rebuild and retry once on the SAME
                    # provider — a fresh 437-char API token routes to the
                    # correct integrator and the model becomes available again.
                    # Single-shot guard prevents looping on a genuinely
                    # unavailable model. Copilot-scoped so other providers'
                    # real 400s are untouched.
                    if (
                        _is_copilot_provider(agent)
                        and not _retry.copilot_stale_cred_retry_attempted
                        and _is_stale_copilot_credential_error(
                            status_code, str(getattr(api_error, "message", "") or api_error)
                        )
                    ):
                        _retry.copilot_stale_cred_retry_attempted = True
                        if agent._try_recover_stale_copilot_credential():
                            agent._buffer_vprint(
                                "🔐 Copilot credential re-exchanged after "
                                "model_not_available 400. Retrying request..."
                            )
                            retry_count = 0
                            continue
                    # Try fallback before aborting — a different provider may
                    # not have the same issue (rate limit, auth, etc.). Only
                    # announce the attempt when a fallback chain actually
                    # exists; otherwise "trying fallback..." is a lie and the
                    # session looks like it's recovering when it's about to
                    # abort silently (#35314, #17446).
                    if agent._has_pending_fallback():
                        if classified.reason == FailoverReason.content_policy_blocked:
                            agent._buffer_status("⚠️ Provider safety filter blocked this request — trying fallback...")
                        elif classified.reason == FailoverReason.ssl_cert_verification:
                            agent._buffer_status("⚠️ TLS certificate verification failed — trying fallback...")
                        else:
                            agent._buffer_status(f"⚠️ Non-retryable error (HTTP {status_code}) — trying fallback...")
                    if agent._try_activate_fallback():
                        active_system_prompt = _sync_failover_system_message(
                            agent, api_messages, active_system_prompt)
                        retry_count = 0
                        compression_attempts = 0
                        _retry.primary_recovery_attempted = False
                        _retry.restart_with_rebuilt_messages = True
                        break
                    if api_kwargs is not None:
                        agent._dump_api_request_debug(
                            api_kwargs, reason="non_retryable_client_error", error=api_error,
                        )
                    # Terminal — flush buffered context so the user sees
                    # what was tried before the abort.
                    agent._flush_status_buffer()
                    # Summarize once: Cloudflare/proxy HTML challenge pages and
                    # other raw provider bodies must be collapsed to a short
                    # one-liner here, otherwise the full page leaks into the
                    # returned ``error`` field and downstream consumers deliver
                    # it verbatim (e.g. a cron failure notification dumped a
                    # ~60KB Cloudflare challenge page as 31 Discord messages).
                    _nonretryable_summary = agent._summarize_api_error(api_error)
                    if classified.reason == FailoverReason.content_policy_blocked:
                        agent._emit_status(
                            f"❌ Provider safety filter blocked this request: "
                            f"{_nonretryable_summary}"
                        )
                    elif classified.reason == FailoverReason.ssl_cert_verification:
                        agent._emit_status(
                            f"❌ TLS certificate verification failed: "
                            f"{_nonretryable_summary}"
                        )
                    else:
                        agent._emit_status(
                            f"❌ Non-retryable error (HTTP {status_code}): "
                            f"{_nonretryable_summary}"
                        )
                    agent._vprint(f"{agent.log_prefix}❌ Non-retryable client error (HTTP {status_code}). Aborting.", force=True)
                    agent._vprint(f"{agent.log_prefix}   🔌 Provider: {_provider}  Model: {_model}", force=True)
                    agent._vprint(f"{agent.log_prefix}   🌐 Endpoint: {_base}", force=True)
                    # Actionable guidance for common auth errors
                    if classified.is_auth or classified.reason == FailoverReason.billing:
                        if classified.reason == FailoverReason.billing and _print_billing_or_entitlement_guidance(
                            agent,
                            capability="model access",
                            provider=_provider,
                            base_url=str(_base),
                            model=_model,
                            unverified=classified.billing_unverified,
                        ):
                            pass
                        elif _provider == "nous" and _print_nous_entitlement_guidance(
                            agent,
                            "Nous model access",
                        ):
                            pass
                        elif _provider in {"openai-codex", "xai-oauth", "nous"} and status_code == 401:
                            if _provider == "openai-codex":
                                agent._vprint(f"{agent.log_prefix}   💡 Codex OAuth token was rejected (HTTP 401). Your token may have been", force=True)
                                agent._vprint(f"{agent.log_prefix}      refreshed by another client (Codex CLI, VS Code). To fix:", force=True)
                                agent._vprint(f"{agent.log_prefix}      1. Run `codex` in your terminal to generate fresh tokens.", force=True)
                                agent._vprint(f"{agent.log_prefix}      2. Then run `hermes auth` to re-authenticate.", force=True)
                            elif _provider == "xai-oauth":
                                agent._vprint(f"{agent.log_prefix}   💡 xAI OAuth token was rejected (HTTP 401). To fix:", force=True)
                                agent._vprint(f"{agent.log_prefix}      re-authenticate with xAI Grok OAuth (SuperGrok / Premium+) from `hermes model`.", force=True)
                            else:  # nous
                                agent._vprint(f"{agent.log_prefix}   💡 Nous Portal OAuth token was rejected (HTTP 401). Your token may be", force=True)
                                agent._vprint(f"{agent.log_prefix}      expired, revoked, or your account may be out of credits. To fix:", force=True)
                                agent._vprint(f"{agent.log_prefix}      1. Re-authenticate: hermes portal", force=True)
                                agent._vprint(f"{agent.log_prefix}      2. Check your portal account: https://portal.nousresearch.com", force=True)
                                # ``:free`` is OpenRouter slug syntax; Nous Portal will reject
                                # the model name even after a successful re-auth.
                                if isinstance(_model, str) and _model.endswith(":free"):
                                    agent._vprint(f"{agent.log_prefix}      ⚠️  Note: `{_model}` looks like an OpenRouter slug (`:free` suffix).", force=True)
                                    agent._vprint(f"{agent.log_prefix}         Nous Portal won't recognize that model name. Either switch to a", force=True)
                                    agent._vprint(f"{agent.log_prefix}         Nous catalog model, or run `/model openrouter:{_model}` to use OpenRouter.", force=True)
                        else:
                            agent._vprint(f"{agent.log_prefix}   💡 Your API key was rejected by the provider. Check:", force=True)
                            agent._vprint(f"{agent.log_prefix}      • Is the key valid? Run: hermes setup", force=True)
                            agent._vprint(f"{agent.log_prefix}      • Does your account have access to {_model}?", force=True)
                            if base_url_host_matches(str(_base), "openrouter.ai"):
                                agent._vprint(f"{agent.log_prefix}      • Check credits: https://openrouter.ai/settings/credits", force=True)
                    else:
                        agent._vprint(f"{agent.log_prefix}   💡 This type of error won't be fixed by retrying.", force=True)
                    # Content-policy blocks deserve their own actionable
                    # guidance — neither "fix your API key" nor "retry won't
                    # help" tells the user what to actually do. The provider
                    # has refused this specific prompt, so the recovery is
                    # either a rephrase or routing to a different model.
                    if classified.reason == FailoverReason.content_policy_blocked:
                        agent._vprint(
                            f"{agent.log_prefix}   💡 The provider's safety filter rejected this specific prompt.",
                            force=True,
                        )
                        agent._vprint(
                            f"{agent.log_prefix}      • Try rephrasing the request, narrowing the context, or splitting into smaller steps.",
                            force=True,
                        )
                        agent._vprint(
                            f"{agent.log_prefix}      • Configure a fallback provider so future blocks route automatically:",
                            force=True,
                        )
                        agent._vprint(
                            f"{agent.log_prefix}        hermes fallback add   (interactive picker — same as `hermes model`)",
                            force=True,
                        )
                    # TLS certificate failures are environment problems, not
                    # provider/prompt problems — tell the user exactly which
                    # knobs fix each common cause. Inspired by Claude Code
                    # v2.1.199's immediate SSL fix hints.
                    if classified.reason == FailoverReason.ssl_cert_verification:
                        agent._vprint(
                            f"{agent.log_prefix}   💡 The TLS certificate chain could not be verified. This fails the same",
                            force=True,
                        )
                        agent._vprint(
                            f"{agent.log_prefix}      way on every retry — fix the environment, then try again:",
                            force=True,
                        )
                        agent._vprint(
                            f"{agent.log_prefix}      • Corporate TLS-inspecting proxy? Point Python at its CA bundle:",
                            force=True,
                        )
                        agent._vprint(
                            f"{agent.log_prefix}        export SSL_CERT_FILE=/path/to/corp-ca.pem  (also REQUESTS_CA_BUNDLE)",
                            force=True,
                        )
                        agent._vprint(
                            f"{agent.log_prefix}      • Missing/stale system CA store? Install/refresh it:",
                            force=True,
                        )
                        agent._vprint(
                            f"{agent.log_prefix}        pip install --upgrade certifi   (macOS: run 'Install Certificates.command')",
                            force=True,
                        )
                        agent._vprint(
                            f"{agent.log_prefix}      • Self-signed local endpoint (llama.cpp, LM Studio, vLLM)? Use http://",
                            force=True,
                        )
                        agent._vprint(
                            f"{agent.log_prefix}        for localhost, or add the server's cert to your trust store.",
                            force=True,
                        )
                    logger.error("%sNon-retryable client error: %s", agent.log_prefix, api_error)
                    # Skip session persistence when the error is likely
                    # context-overflow related (status 400 + large session).
                    # Persisting the failed user message would make the
                    # session even larger, causing the same failure on the
                    # next attempt. (#1630)
                    if status_code == 400 and (approx_tokens > 50000 or len(api_messages) > 80):
                        agent._vprint(
                            f"{agent.log_prefix}⚠️  Skipping session persistence "
                            f"for large failed session to prevent growth loop.",
                            force=True,
                        )
                    else:
                        agent._persist_session(messages, conversation_history)
                    if classified.reason == FailoverReason.content_policy_blocked:
                        _policy_response = (
                            "⚠️  The model provider's safety filter blocked this request "
                            "(not a Hermes/gateway failure).\n\n"
                            f"Provider message: {_nonretryable_summary}\n\n"
                            f"{_CONTENT_POLICY_RECOVERY_HINT}"
                        )
                        return _content_policy_blocked_result(
                            messages,
                            api_call_count,
                            final_response=_policy_response,
                            error_detail=_nonretryable_summary,
                        )
                    # Billing walls are the common non-retryable abort: enrich
                    # the result with the same structured recovery descriptor as
                    # the max-retries path so every surface (CLI, TUI, desktop)
                    # renders one consistent billing signal.
                    if classified.reason == FailoverReason.billing:
                        return _billing_failure_result(
                            classified=classified,
                            summary=_nonretryable_summary,
                            messages=messages,
                            api_call_count=api_call_count,
                            provider=_provider,
                            base_url=_base,
                            model=_model,
                        )
                    return {
                        "final_response": _nonretryable_summary,
                        "messages": messages,
                        "api_calls": api_call_count,
                        "completed": False,
                        "failed": True,
                        "error": _nonretryable_summary,
                    }

                if retry_count >= max_retries:
                    # Before falling back, try rebuilding the primary
                    # client once for transient transport errors (stale
                    # connection pool, TCP reset).  Only attempted once
                    # per API call block.
                    if not _retry.primary_recovery_attempted and agent._try_recover_primary_transport(
                        api_error, retry_count=retry_count, max_retries=max_retries,
                    ):
                        _retry.primary_recovery_attempted = True
                        retry_count = 0
                        # Primary transport recovery starts a fresh attempt
                        # cycle. Re-open fallback state so a follow-on 429 can
                        # still activate fallback_providers after stale
                        # pre-recovery fallback/credential-pool bookkeeping.
                        _retry.has_retried_429 = False
                        agent._fallback_index = 0
                        agent._fallback_activated = False
                        continue
                    # Try fallback before giving up entirely
                    if agent._has_pending_fallback():
                        agent._buffer_status(f"⚠️ Max retries ({max_retries}) exhausted — trying fallback...")
                    if agent._try_activate_fallback():
                        active_system_prompt = _sync_failover_system_message(
                            agent, api_messages, active_system_prompt)
                        retry_count = 0
                        compression_attempts = 0
                        _retry.primary_recovery_attempted = False
                        _retry.restart_with_rebuilt_messages = True
                        break
                    # Terminal — flush buffered retry/fallback trace.
                    agent._flush_status_buffer()
                    _final_summary = agent._summarize_api_error(api_error)
                    _billing_guidance = ""
                    if classified.reason == FailoverReason.billing:
                        if classified.billing_unverified:
                            # Ambiguous body (#82154) — hedge the terminal line.
                            agent._emit_status(
                                "❌ Provider reported usage/credit exhaustion "
                                f"(unverified — may be a content-filter rejection) — {_final_summary}"
                            )
                        else:
                            agent._emit_status(f"❌ Billing or credits exhausted — {_final_summary}")
                        _billing_guidance = _billing_or_entitlement_message(
                            capability="model access",
                            provider=_provider,
                            base_url=str(_base),
                            model=_model,
                            unverified=classified.billing_unverified,
                        )
                        _print_billing_or_entitlement_guidance(
                            agent,
                            capability="model access",
                            provider=_provider,
                            base_url=str(_base),
                            model=_model,
                            unverified=classified.billing_unverified,
                        )
                    elif is_rate_limited:
                        agent._emit_status(f"❌ Rate limited after {max_retries} retries — {_final_summary}")
                    else:
                        agent._emit_status(f"❌ API failed after {max_retries} retries — {_final_summary}")
                    agent._vprint(f"{agent.log_prefix}   💀 Final error: {_final_summary}", force=True)

                    # Detect SSE stream-drop pattern (e.g. "Network
                    # connection lost") and surface actionable guidance.
                    # This typically happens when the model generates a
                    # very large tool call (write_file with huge content)
                    # and the proxy/CDN drops the stream mid-response.
                    _is_stream_drop = (
                        not getattr(api_error, "status_code", None)
                        and any(p in error_msg for p in (
                            "connection lost", "connection reset",
                            "connection closed", "network connection",
                            "network error", "terminated",
                        ))
                    )
                    if _is_stream_drop:
                        agent._vprint(
                            f"{agent.log_prefix}   💡 The provider's stream "
                            f"connection keeps dropping. This often happens "
                            f"when the model tries to write a very large "
                            f"file in a single tool call.",
                            force=True,
                        )
                        agent._vprint(
                            f"{agent.log_prefix}      Try asking the model "
                            f"to use execute_code with Python's open() for "
                            f"large files, or to write the file in smaller "
                            f"sections.",
                            force=True,
                        )

                    # Detect thinking-timeout pattern: a known reasoning model
                    # hit a transport-layer error before the first content
                    # token arrived.  Distinct from _is_stream_drop above
                    # (which fires for large file-write stream drops) and
                    # from any classifier reason that's not a transport
                    # timeout.  Reuses the reasoning-model allowlist from
                    # agent/reasoning_timeouts.py (Fixes #52217) so the
                    # trigger is consistent with what the per-model
                    # stale-timeout floor covers.  After the classifier
                    # override at agent/error_classifier.py:720-738 (this
                    # PR), transport disconnects on reasoning models route
                    # to FailoverReason.timeout rather than
                    # context_overflow, so this branch actually fires.
                    # Detection and message text live in
                    # agent.thinking_timeout_guidance so they're
                    # unit-testable without driving the full retry loop.
                    # (Part 2 of Fixes #52310.)
                    from agent.thinking_timeout_guidance import (
                        is_thinking_timeout,
                    )
                    _is_thinking_timeout = is_thinking_timeout(
                        classified,
                        _model,
                        error_msg,
                    )
                    if _is_thinking_timeout:
                        agent._vprint(
                            f"{agent.log_prefix}   💡 The model's thinking "
                            f"phase exceeded the upstream proxy's idle "
                            f"timeout before the first content token "
                            f"arrived. This is a known issue with "
                            f"reasoning models behind cloud gateways "
                            f"(NVIDIA NIM, OpenAI, Anthropic, DeepSeek).",
                            force=True,
                        )
                        agent._vprint(
                            f"{agent.log_prefix}      Workarounds in priority order:",
                            force=True,
                        )
                        agent._vprint(
                            f"{agent.log_prefix}      1. Set "
                            f"`providers.{_provider}.models.{_model}.stale_timeout_seconds: 900` "
                            f"in `~/.hermes/config.yaml` to extend the per-call "
                            f"timeout. (Hermes's built-in floor is 600s for "
                            f"known reasoning models — if you still see this "
                            f"after raising, the upstream cap is even shorter.)",
                            force=True,
                        )
                        agent._vprint(
                            f"{agent.log_prefix}      2. Lower `reasoning_budget` or set "
                            f"`reasoning_effort: medium` on this model if the provider supports it.",
                            force=True,
                        )
                        agent._vprint(
                            f"{agent.log_prefix}      3. Use a smaller / faster reasoning "
                            f"model if the task doesn't require deep thinking.",
                            force=True,
                        )

                    logger.error(
                        "%sAPI call failed after %s retries. %s | provider=%s model=%s msgs=%s tokens=~%s",
                        agent.log_prefix, max_retries, _final_summary,
                        _provider, _model, len(api_messages), f"{approx_tokens:,}",
                    )
                    if api_kwargs is not None:
                        agent._dump_api_request_debug(
                            api_kwargs, reason="max_retries_exhausted", error=api_error,
                        )
                    agent._persist_session(messages, conversation_history)
                    _billing_block = None
                    _billing_unverified = False
                    if classified.reason == FailoverReason.billing:
                        _billing_unverified = classified.billing_unverified
                        _final_response = _billing_terminal_label(
                            _final_summary, _billing_unverified
                        )
                        if _billing_guidance:
                            _final_response += f"\n\n{_billing_guidance}"
                        # Structured recovery descriptor so every surface renders
                        # the same link + label from one signal (see helper).
                        _billing_block = _billing_block_dict(
                            _provider, _base, _model, _billing_guidance,
                            unverified=_billing_unverified,
                        )
                    else:
                        _final_response = f"API call failed after {max_retries} retries: {_final_summary}"
                    if _is_thinking_timeout:
                        # Thinking-timeout guidance overrides the generic
                        # stream-drop guidance — the latter is wrong for
                        # this case (it suggests splitting large file
                        # writes, which isn't what happened).  See the
                        # reasoning-model override at
                        # agent/error_classifier.py:720-738 and the
                        # detection block above for context.
                        from agent.thinking_timeout_guidance import (
                            build_thinking_timeout_guidance,
                        )
                        _final_response += build_thinking_timeout_guidance(
                            provider=_provider,
                            model=_model,
                        )
                    elif _is_stream_drop:
                        _final_response += (
                            "\n\nThe provider's stream connection keeps "
                            "dropping — this often happens when generating "
                            "very large tool call responses (e.g. write_file "
                            "with long content). Try asking me to use "
                            "execute_code with Python's open() for large "
                            "files, or to write in smaller sections."
                        )
                    return {
                        "final_response": _final_response,
                        "messages": messages,
                        "api_calls": api_call_count,
                        "completed": False,
                        "failed": True,
                        "error": _final_summary,
                        # Surface the classified reason so callers (notably the
                        # kanban worker path in cli.py) can distinguish a
                        # transient throttle from a real failure and choose a
                        # different exit code. ``rate_limit`` / ``billing`` here
                        # mean "quota wall, not a task error".
                        "failure_reason": classified.reason.value,
                        # The classifier's own retry verdict — UI surfaces use
                        # this instead of re-deriving from the reason string.
                        "failure_retryable": bool(classified.retryable),
                        # True when the billing verdict rests on an ambiguous
                        # body (#82154) — may be a content-filter rejection.
                        "billing_unverified": _billing_unverified,
                        # Present only for billing walls: structured recovery
                        # descriptor (provider, billing_url, is_nous, message).
                        "billing_block": _billing_block,
                    }

                # For rate limits, respect the Retry-After header if present
                _retry_after = None
                if is_rate_limited:
                    _resp_headers = getattr(getattr(api_error, "response", None), "headers", None)
                    if _resp_headers and hasattr(_resp_headers, "get"):
                        _ra_raw = _resp_headers.get("retry-after") or _resp_headers.get("Retry-After")
                        if _ra_raw:
                            try:
                                # Cap at 10 minutes. Anthropic Tier 1 input-token
                                # buckets reset in ~171s, so a 120s cap caused us to
                                # retry before the actual reset window and re-trip the
                                # limit. 600s covers all realistic provider reset
                                # windows while still rejecting pathological values. (#26293)
                                _retry_after = min(float(_ra_raw), 600)
                            except (TypeError, ValueError):
                                pass
                wait_time = _retry_after if _retry_after else jittered_backoff(retry_count, base_delay=2.0, max_delay=60.0)
                _backoff_policy = None
                if (is_rate_limited or _is_zai_coding_overload) and not _retry_after:
                    wait_time, _backoff_policy = adaptive_rate_limit_backoff(
                        retry_count,
                        base_url=str(_base),
                        model=_model,
                        error=api_error,
                        default_wait=wait_time,
                    )
                if is_rate_limited or _is_zai_coding_overload:
                    _policy_note = ""
                    if _backoff_policy == "zai_coding_overload_long":
                        _policy_note = " (Z.AI Coding overload adaptive long backoff)"
                    elif _backoff_policy == "zai_coding_overload_short":
                        _policy_note = " (Z.AI Coding overload short retry)"
                    _wait_reason = "Provider overloaded" if _is_zai_coding_overload and not is_rate_limited else "Rate limited"
                    _rate_limit_status = f"⏱️ {_wait_reason}. Waiting {wait_time:.1f}s (attempt {retry_count + 1}/{max_retries}){_policy_note}..."
                    # Normal retries are buffered to avoid noisy transient chatter. Long
                    # Z.AI Coding waits are different: they can last minutes, so surface
                    # progress immediately instead of making the TUI look frozen.
                    if _backoff_policy == "zai_coding_overload_long":
                        agent._emit_status(_rate_limit_status)
                    else:
                        agent._buffer_status(_rate_limit_status)
                else:
                    agent._buffer_status(f"⏳ Retrying in {wait_time:.1f}s (attempt {retry_count}/{max_retries})...")
                logger.warning(
                    "Retrying API call in %ss (attempt %s/%s) %s policy=%s error=%s",
                    wait_time,
                    retry_count,
                    max_retries,
                    agent._client_log_context(),
                    _backoff_policy or "default",
                    api_error,
                )
                # Sleep in small increments so we can respond to interrupts quickly
                # instead of blocking the entire wait_time in one sleep() call
                sleep_end = time.time() + wait_time
                _backoff_touch_counter = 0
                while time.time() < sleep_end:
                    if agent._interrupt_requested:
                        # Same preserve-redirect rule as the retry-wait above:
                        # a steering correction must survive backoff, not die
                        # as "Operation interrupted".
                        if agent.clear_interrupt(preserve_redirect=True):
                            _retry.restart_with_redirected_messages = True
                            break
                        agent._vprint(f"{agent.log_prefix}⚡ Interrupt detected during retry wait, aborting.", force=True)
                        _interrupt_text = f"Operation interrupted: retrying API call after error (retry {retry_count}/{max_retries})."
                        close_interrupted_tool_sequence(messages, _interrupt_text)
                        agent._persist_session(messages, conversation_history)
                        agent.clear_interrupt()
                        return {
                            "final_response": _interrupt_text,
                            "messages": messages,
                            "api_calls": api_call_count,
                            "completed": False,
                            "interrupted": True,
                        }
                    time.sleep(0.2)  # Check interrupt every 200ms
                    # Touch activity every ~30s so the gateway's inactivity
                    # monitor knows we're alive during backoff waits.
                    _backoff_touch_counter += 1
                    if _backoff_touch_counter % 150 == 0:  # 150 × 0.2s = 30s
                        agent._touch_activity(
                            f"error retry backoff ({retry_count}/{max_retries}), "
                            f"{int(sleep_end - time.time())}s remaining"
                        )
                if _retry.restart_with_redirected_messages:
                    # Leave the retry loop — the check right below rebuilds this
                    # iteration from the correction instead of re-firing the
                    # stale request.
                    break
        
        if _retry.restart_with_redirected_messages:
            # The cancelled request produced no valid assistant item. Reuse the
            # same logical iteration after the outer loop appends the displayed
            # partial context and correction to ``messages``.
            api_call_count -= 1
            agent.iteration_budget.refund()
            _retry.restart_with_redirected_messages = False
            continue

        # If the API call was interrupted, skip response processing
        if interrupted:
            _turn_exit_reason = "interrupted_during_api_call"
            break

        if _retry.restart_with_compressed_messages:
            api_call_count -= 1
            agent.iteration_budget.refund()
            # Count compression restarts toward the retry limit to prevent
            # infinite loops when compression reduces messages but not enough
            # to fit the context window.
            retry_count += 1
            _retry.restart_with_compressed_messages = False
            if _should_skip_model_call_for_reference_handoff(
                messages, user_message
            ):
                logger.info(
                    "Skipping compressed-restart model call: reference-only "
                    "handoff would be the sole active user turn (#80622)"
                )
                if not final_response:
                    final_response = _HANDOFF_SKIP_FINAL_RESPONSE
                _turn_exit_reason = "compaction_handoff_not_actionable"
                break
            # In-loop compression rebuilt `messages` with fresh compaction
            # copies, so the pre-compression current-turn index is stale.
            # Re-anchor exactly like the prologue does: a stale index that
            # lands on a historical user message would make the live-compose
            # fallback inject this turn's prefetch into that message on the
            # wire only, diverging the next turn's replayed prefix there.
            # Ordered AFTER the handoff guard: the guard may have re-appended
            # this turn's real user ask (restore path), and the anchor must
            # land on that restored row, not on -1 / a pre-restore index.
            current_turn_user_idx = reanchor_current_turn_user_idx(
                messages, user_message
            )
            agent._persist_user_message_idx = current_turn_user_idx
            continue

        if _retry.restart_with_rebuilt_messages:
            # A stream stall or provider failure was escalated to the
            # fallback chain (10 activation sites in the retry loop set this
            # flag and break here).  Re-issue the API call against the
            # now-active fallback provider.  Refund the budget/count for the
            # stalled attempt so the fallback gets a fair turn.
            api_call_count -= 1
            agent.iteration_budget.refund()
            _retry.restart_with_rebuilt_messages = False
            # Failover shrank the compressor's context window to the
            # fallback's; clear the preflight block so the pre-API preflight
            # re-runs against the new threshold before the first fallback
            # call (#84733). Hoisted here (the single consumer) so every
            # activation site — including ones added later — gets it.
            _preflight_compression_blocked = False
            continue

        if _retry.restart_with_length_continuation:
            # Progressively boost the output token budget on each retry.
            # Retry 1 → 2× base, retry 2 → 4× base, retry 3 → 8× base,
            # retry 4 → 16× base, then cap at 32 768.
            # Applies to all providers via _ephemeral_max_output_tokens.
            # If the original request already used a larger provider/model
            # default budget, keep that floor so continuation retries do
            # not accidentally downshift to a much smaller cap.
            _boost_base = agent.max_tokens if agent.max_tokens else 4096
            _boost = _boost_base * (2 ** length_continue_retries)
            _requested_cap = agent._requested_output_cap_from_api_kwargs(api_kwargs)
            if _requested_cap is not None:
                _boost = max(_boost, _requested_cap)
            _boost_cap = max(32768, _requested_cap or 0)
            agent._ephemeral_max_output_tokens = min(_boost, _boost_cap)
            continue

        # Guard: if all retries exhausted without a successful response
        # (e.g. repeated context-length errors that exhausted retry_count),
        # the `response` variable is still None. Break out cleanly.
        if response is None:
            _turn_exit_reason = "all_retries_exhausted_no_response"
            print(f"{agent.log_prefix}❌ All API retries exhausted with no successful response.")
            agent._persist_session(messages, conversation_history)
            break

        try:
            _transport = agent._get_transport()
            _normalize_kwargs = {}
            if agent.api_mode == "anthropic_messages":
                _normalize_kwargs["strip_tool_prefix"] = agent._is_anthropic_oauth
            normalized = _transport.normalize_response(response, **_normalize_kwargs)
            assistant_message = normalized
            finish_reason = normalized.finish_reason
            
            # Normalize content to string — some OpenAI-compatible servers
            # (llama-server, etc.) return content as a dict or list instead
            # of a plain string, which crashes downstream .strip() calls.
            if assistant_message.content is not None and not isinstance(assistant_message.content, str):
                raw = assistant_message.content
                if isinstance(raw, dict):
                    assistant_message.content = raw.get("text", "") or raw.get("content", "") or json.dumps(raw)
                elif isinstance(raw, list):
                    # Multimodal content list — extract text parts
                    parts = []
                    for part in raw:
                        if isinstance(part, str):
                            parts.append(part)
                        elif isinstance(part, dict) and part.get("type") == "text":
                            parts.append(part.get("text", ""))
                        elif isinstance(part, dict) and "text" in part:
                            parts.append(str(part["text"]))
                    assistant_message.content = "\n".join(parts)
                else:
                    assistant_message.content = str(raw)

            # ── Agent-as-provider projection ──────────────────────────────
            # A provider that IS an agent ran its own tools inside its own
            # session before we got here: splice that work into the transcript
            # as completed call/result rows and tick the skill-review nudge
            # with the iterations Hermes never saw. Appended before this turn's
            # assistant message, so the order reads call → result → answer.
            # No-op for ordinary providers; see agent/provider_projection.py.
            splice_provider_projection(agent, response, messages)

            try:
                from hermes_cli.lifecycle import (
                    has_hook,
                    invoke_hook as _invoke_hook,
                )
                if has_hook("post_api_request"):
                    _assistant_tool_calls = (
                        getattr(assistant_message, "tool_calls", None) or []
                    )
                    _assistant_text = assistant_message.content or ""
                    _api_ended_at = api_start_time + api_duration
                    _invoke_hook(
                        "post_api_request",
                        task_id=effective_task_id,
                        turn_id=turn_id,
                        api_request_id=api_request_id,
                        session_id=agent.session_id or "",
                        platform=agent.platform or "",
                        model=agent.model,
                        provider=agent.provider,
                        base_url=agent.base_url,
                        api_mode=agent.api_mode,
                        api_call_count=api_call_count,
                        api_duration=api_duration,
                        started_at=api_start_time,
                        ended_at=_api_ended_at,
                        # First received stream chunk timestamp (epoch seconds), set by
                        # interruptible_streaming_api_call from its per-attempt
                        # stream diagnostics; None when the response was not
                        # streamed or no chunk arrived. TTFB =
                        # first_chunk_at - started_at.
                        first_chunk_at=getattr(
                            agent, "_last_api_first_chunk_at", None
                        ),
                        finish_reason=finish_reason,
                        message_count=len(api_messages),
                        response_model=getattr(response, "model", None),
                        response=agent._api_response_payload_for_hook(
                            response,
                            assistant_message,
                            finish_reason=finish_reason,
                        ),
                        usage=agent._usage_summary_for_api_request_hook(response),
                        assistant_message=assistant_message,
                        assistant_content_chars=len(_assistant_text),
                        assistant_tool_call_count=len(_assistant_tool_calls),
                        moa_references=_moa_reference_metrics_for_hook(agent),
                    )
            except Exception:
                pass

            # Handle assistant response
            if assistant_message.content and not agent.quiet_mode:
                if agent.verbose_logging:
                    agent._vprint(f"{agent.log_prefix}🤖 Assistant: {assistant_message.content}")
                else:
                    agent._vprint(f"{agent.log_prefix}🤖 Assistant: {assistant_message.content[:100]}{'...' if len(assistant_message.content) > 100 else ''}")

            # Notify progress callback of model's thinking (used by subagent
            # delegation to relay the child's reasoning to the parent display).
            if (assistant_message.content and agent.tool_progress_callback):
                _think_text = assistant_message.content.strip()
                # Strip reasoning XML tags that shouldn't leak to parent display
                _think_text = re.sub(
                    r'</?(?:REASONING_SCRATCHPAD|think|reasoning)>', '', _think_text
                ).strip()
                # For subagents: relay first line to parent display (existing behaviour).
                # For all agents with a structured callback: emit reasoning.available event.
                first_line = _think_text.split('\n')[0][:80] if _think_text else ""
                if first_line and getattr(agent, '_delegate_depth', 0) > 0:
                    try:
                        agent.tool_progress_callback("_thinking", first_line)
                    except Exception:
                        pass
                elif _think_text:
                    try:
                        agent.tool_progress_callback("reasoning.available", "_thinking", _think_text[:500], None)
                    except Exception:
                        pass
            
            # Check for incomplete <REASONING_SCRATCHPAD> (opened but never closed)
            # This means the model ran out of output tokens mid-reasoning — retry up to 2 times
            if has_incomplete_scratchpad(assistant_message.content or ""):
                agent._incomplete_scratchpad_retries += 1
                
                agent._buffer_vprint("⚠️  Incomplete <REASONING_SCRATCHPAD> detected (opened but never closed)")
                
                if agent._incomplete_scratchpad_retries <= 2:
                    agent._buffer_vprint(f"🔄 Retrying API call ({agent._incomplete_scratchpad_retries}/2)...")
                    # Don't add the broken message, just retry
                    continue
                else:
                    # Max retries - discard this turn and save as partial
                    agent._flush_status_buffer()
                    agent._vprint(f"{agent.log_prefix}❌ Max retries (2) for incomplete scratchpad. Saving as partial.", force=True)
                    agent._incomplete_scratchpad_retries = 0
                    
                    rolled_back_messages = agent._get_messages_up_to_last_assistant(messages)
                    agent._cleanup_task_resources(effective_task_id)
                    agent._persist_session(messages, conversation_history)
                    
                    return {
                        "final_response": "Incomplete REASONING_SCRATCHPAD after 2 retries",
                        "messages": rolled_back_messages,
                        "api_calls": api_call_count,
                        "completed": False,
                        "partial": True,
                        "error": "Incomplete REASONING_SCRATCHPAD after 2 retries"
                    }
            
            # Reset incomplete scratchpad counter on clean response
            agent._incomplete_scratchpad_retries = 0

            if agent.api_mode == "codex_responses" and finish_reason == "incomplete":
                agent._codex_incomplete_retries += 1

                interim_msg = agent._build_assistant_message(assistant_message, finish_reason)
                interim_has_content = bool((interim_msg.get("content") or "").strip())
                interim_has_reasoning = bool(interim_msg.get("reasoning", "").strip()) if isinstance(interim_msg.get("reasoning"), str) else False
                interim_has_codex_reasoning = bool(interim_msg.get("codex_reasoning_items"))
                interim_has_codex_message_items = bool(interim_msg.get("codex_message_items"))

                if (
                    interim_has_content
                    or interim_has_reasoning
                    or interim_has_codex_reasoning
                    or interim_has_codex_message_items
                ):
                    last_msg = messages[-1] if messages else None
                    # Duplicate detection: compare only visible content
                    # (content + reasoning).  Opaque provider state
                    # (encrypted reasoning items, message item ids/phases)
                    # drifts per continuation even when the visible output
                    # is identical, so including it in the comparison defeats
                    # dedup and causes message storms (#52711).
                    last_interim_visible = (
                        agent._interim_assistant_visible_text(last_msg)
                        if isinstance(last_msg, dict)
                        else ""
                    )
                    current_interim_visible = agent._interim_assistant_visible_text(interim_msg)
                    if last_interim_visible or current_interim_visible:
                        same_visible_output = last_interim_visible == current_interim_visible
                    else:
                        # Preserve the existing reasoning-only behavior when
                        # neither response has text eligible for interim delivery.
                        same_visible_output = (
                            (last_msg.get("content") or "") == (interim_msg.get("content") or "")
                            and (last_msg.get("reasoning") or "") == (interim_msg.get("reasoning") or "")
                        ) if isinstance(last_msg, dict) else False
                    visible_duplicate = (
                        isinstance(last_msg, dict)
                        and last_msg.get("role") == "assistant"
                        and last_msg.get("finish_reason") == "incomplete"
                        and same_visible_output
                    )
                    if visible_duplicate:
                        # Update replay state in-place so the latest provider
                        # payload is preserved without re-emitting identical
                        # user-visible commentary.
                        for _key in (
                            "content",
                            "reasoning",
                            "reasoning_content",
                            "reasoning_details",
                            "codex_reasoning_items",
                            "codex_message_items",
                        ):
                            if _key in interim_msg:
                                if _key == "codex_reasoning_items":
                                    # Merge instead of overwrite: a native
                                    # compaction checkpoint captured on the
                                    # earlier incomplete response is the only
                                    # copy — the continuation won't re-emit
                                    # it. See merge_interim_reasoning_items.
                                    from agent.native_compaction import (
                                        merge_interim_reasoning_items,
                                    )
                                    last_msg[_key] = merge_interim_reasoning_items(
                                        last_msg.get(_key), interim_msg[_key]
                                    )
                                else:
                                    last_msg[_key] = interim_msg[_key]
                    else:
                        append_message(messages, interim_msg)
                        agent._emit_interim_assistant_message(interim_msg)

                if agent._codex_incomplete_retries < 3:
                    # When the interim message has nothing the Responses
                    # input converter will replay (no visible content, no
                    # encrypted reasoning items, no replayable message
                    # items — plain-text reasoning only), a bare retry is
                    # byte-identical to the request that just came back
                    # incomplete and fails the same way every time
                    # (observed with grok-4.20 on xai-oauth, whose
                    # reasoning items lack encrypted_content).  Append a
                    # user-role nudge so the retry actually differs and
                    # explicitly asks for the final answer.
                    interim_replayable = (
                        interim_has_content
                        or interim_has_codex_reasoning
                        or interim_has_codex_message_items
                    )
                    # A replayable interim is not the same thing as a retry
                    # that DIFFERS.  When the interim replays but carries no
                    # new instruction, the continuation is byte-identical to
                    # the request that just failed and returns the same empty
                    # response until the budget is gone.  Live case (gpt-5.6
                    # on the Codex backend, Aug 2026): the model answers with
                    # a server-side ``compaction`` checkpoint and no message.
                    # The checkpoint lands in ``codex_reasoning_items``, so
                    # ``interim_replayable`` is True and no nudge is added —
                    # meanwhile the checkpoint makes the wire converter prune
                    # every pre-checkpoint item, so all three attempts send
                    # the same checkpoint + retained user messages and end on
                    # an empty assistant turn with nothing to answer.  The
                    # provider's own prefix cache reports 99-100% on the
                    # repeats, and the turn dies with "Codex response
                    # remained incomplete after 3 continuation attempts",
                    # losing the whole turn's work.
                    #
                    # One bare retry is still worth trying (the model often
                    # just needs another turn).  Once THAT has also come back
                    # incomplete, a bare retry is proven not to work for this
                    # turn, so every remaining attempt carries the nudge.
                    if not interim_replayable or agent._codex_incomplete_retries >= 2:
                        _last_msg = messages[-1] if messages else None
                        _already_nudged = (
                            isinstance(_last_msg, dict)
                            and _last_msg.get("role") == "user"
                            and _last_msg.get("content") == _CODEX_INCOMPLETE_NUDGE
                        )
                        # Alternation guard: the nudge is a user-role message,
                        # so it may only follow an assistant message. When the
                        # interim was too empty to append (no content AND no
                        # reasoning), the last message is still the prior
                        # user/tool turn — appending the nudge there would
                        # create a user→user / tool→user sequence that strict
                        # providers reject.
                        _last_is_assistant = (
                            isinstance(_last_msg, dict)
                            and _last_msg.get("role") == "assistant"
                        )
                        if not _already_nudged and _last_is_assistant:
                            append_message(messages, {
                                "role": "user",
                                "content": _CODEX_INCOMPLETE_NUDGE,
                            })
                    if not agent.quiet_mode:
                        agent._vprint(f"{agent.log_prefix}↻ Codex response incomplete; continuing turn ({agent._codex_incomplete_retries}/3)")
                    # Surface the continuation on the live spinner/status line
                    # (CLI/TUI/Desktop) and gateway heartbeat: each of these
                    # retries can spend minutes waiting on the provider, and
                    # without a distinct notice the user only sees a generic
                    # thinking spinner ("infinite thinking", #64434).
                    agent._emit_wait_notice(
                        f"↻ model returned reasoning with no final answer — "
                        f"asking it to continue "
                        f"({agent._codex_incomplete_retries}/3)"
                    )
                    agent._session_messages = messages
                    continue

                agent._codex_incomplete_retries = 0
                agent._persist_session(messages, conversation_history)
                return {
                    "final_response": "Codex response remained incomplete after 3 continuation attempts",
                    "messages": messages,
                    "api_calls": api_call_count,
                    "completed": False,
                    "partial": True,
                    "error": "Codex response remained incomplete after 3 continuation attempts",
                }
            elif hasattr(agent, "_codex_incomplete_retries"):
                agent._codex_incomplete_retries = 0
            
            # Check for tool calls
            if assistant_message.tool_calls:
                if not agent.quiet_mode:
                    agent._vprint(f"{agent.log_prefix}🔧 Processing {len(assistant_message.tool_calls)} tool call(s)...")
                
                if agent.verbose_logging:
                    for tc in assistant_message.tool_calls:
                        raw_args = tc.function.arguments
                        args_preview = raw_args[:200] if isinstance(raw_args, str) else repr(raw_args)[:200]
                        logging.debug("Tool call: %s with args: %s...", tc.function.name, args_preview)
                
                # Uniquify duplicate tool-call ids BEFORE any downstream
                # consumer (validation error paths, dispatch, history build,
                # Responses item-id derivation). Models that reuse one id for
                # different calls in a batch otherwise lose the later call's
                # result: the pre-API sanitizer keeps only the first
                # call/result pair per id. See _uniquify_tool_call_ids.
                agent._uniquify_tool_call_ids(assistant_message.tool_calls)

                # Validate tool call names - detect model hallucinations
                # Repair mismatched tool names before validating
                for tc in assistant_message.tool_calls:
                    if tc.function.name not in agent.valid_tool_names:
                        repaired = agent._repair_tool_call(tc.function.name)
                        if repaired:
                            print(f"{agent.log_prefix}🔧 Auto-repaired tool name: '{tc.function.name}' -> '{repaired}'")
                            tc.function.name = repaired
                invalid_tool_calls = [
                    tc.function.name for tc in assistant_message.tool_calls
                    if tc.function.name not in agent.valid_tool_names
                ]
                # Mixed batch: at least one valid call alongside the invalid
                # one(s). Degrading models (observed with gpt-5.6 at very
                # large context) emit batches like 6 named calls + 1
                # blank-name call; voiding the whole turn throws away real
                # work and, across the 3-strike budget, halts sessions that
                # were still making progress. Instead: error-result ONLY the
                # invalid calls (below, after dedup/cap guardrails) and let
                # the valid ones execute. The strike counter only advances
                # when a turn contains NO valid call, so a fully-degenerate
                # model still halts at 3 while a mostly-coherent one keeps
                # working.
                _mixed_invalid_batch = bool(invalid_tool_calls) and any(
                    tc.function.name in agent.valid_tool_names
                    for tc in assistant_message.tool_calls
                )
                if _mixed_invalid_batch:
                    agent._invalid_tool_retries = 0
                    invalid_name = invalid_tool_calls[0]
                    invalid_preview = invalid_name[:80] + "..." if len(invalid_name) > 80 else invalid_name
                    _n_valid = sum(
                        1 for tc in assistant_message.tool_calls
                        if tc.function.name in agent.valid_tool_names
                    )
                    agent._buffer_vprint(
                        f"⚠️  Unknown tool '{invalid_preview}' in batch — erroring that call, "
                        f"executing {_n_valid} valid call(s)"
                    )
                elif invalid_tool_calls:
                    # Track retries for invalid tool calls
                    agent._invalid_tool_retries += 1

                    # Return helpful error to model — model can agent-correct next turn
                    invalid_name = invalid_tool_calls[0]
                    invalid_preview = invalid_name[:80] + "..." if len(invalid_name) > 80 else invalid_name
                    agent._buffer_vprint(f"⚠️  Unknown tool '{invalid_preview}' — sending error to model for agent-correction ({agent._invalid_tool_retries}/3)")

                    if agent._invalid_tool_retries >= 3:
                        agent._flush_status_buffer()
                        agent._vprint(f"{agent.log_prefix}❌ Max retries (3) for invalid tool calls exceeded. Stopping as partial.", force=True)
                        agent._invalid_tool_retries = 0
                        _final_response = f"Model generated invalid tool call: {invalid_preview}"
                        # Prior <3 retries (or an earlier successful tool batch)
                        # leave a tool-result tail. Closing it here matches
                        # interrupt aborts (#48879 / #52592) so the next user
                        # turn is not tool→user for strict providers.
                        close_interrupted_tool_sequence(messages, _final_response)
                        agent._persist_session(messages, conversation_history)
                        return {
                            "final_response": _final_response,
                            "messages": messages,
                            "api_calls": api_call_count,
                            "completed": False,
                            "partial": True,
                            "error": _final_response
                        }

                    assistant_msg = agent._build_assistant_message(assistant_message, finish_reason)
                    append_message(messages, assistant_msg)
                    for tc in assistant_message.tool_calls:
                        _tc_name = tc.function.name
                        if _tc_name not in agent.valid_tool_names:
                            # See _invalid_tool_name_error_content for the
                            # blank-name anti-priming rationale (#47967).
                            content = _invalid_tool_name_error_content(
                                _tc_name, agent.valid_tool_names
                            )
                        else:
                            content = "Skipped: another tool call in this turn used an invalid name. Please retry this tool call."
                        append_message(messages, {
                            "role": "tool",
                            "name": tc.function.name,
                            "tool_call_id": coalesce_tool_call_id(tc),
                            "content": content,
                        })
                    continue
                # Reset retry counter on successful tool call validation
                agent._invalid_tool_retries = 0
                
                # Validate tool call arguments are valid JSON
                # Handle empty strings as empty objects (common model quirk)
                invalid_json_args = []
                for tc in assistant_message.tool_calls:
                    args = tc.function.arguments
                    if isinstance(args, (dict, list)):
                        tc.function.arguments = json.dumps(args)
                        continue
                    if args is not None and not isinstance(args, str):
                        tc.function.arguments = str(args)
                        args = tc.function.arguments
                    # Treat empty/whitespace strings as empty object
                    if not args or not args.strip():
                        tc.function.arguments = "{}"
                        continue
                    try:
                        json.loads(args)
                    except json.JSONDecodeError as e:
                        if (
                            _mixed_invalid_batch
                            and tc.function.name not in agent.valid_tool_names
                        ):
                            # This call never executes — it gets an
                            # invalid-name error result below. Don't let its
                            # broken args trigger the whole-turn JSON retry.
                            continue
                        invalid_json_args.append((tc.function.name, str(e)))
                
                if invalid_json_args:
                    # Check if the invalid JSON is due to truncation rather
                    # than a model formatting mistake.  Routers sometimes
                    # rewrite finish_reason from "length" to "tool_calls",
                    # hiding the truncation from the length handler above.
                    # Detect truncation: args that don't end with } or ]
                    # (after stripping whitespace) are cut off mid-stream.
                    _truncated = any(
                        not (tc.function.arguments or "").rstrip().endswith(("}", "]"))
                        for tc in assistant_message.tool_calls
                        if tc.function.name in {n for n, _ in invalid_json_args}
                    )
                    if _truncated:
                        agent._vprint(
                            f"{agent.log_prefix}⚠️  Truncated tool call arguments detected "
                            f"(finish_reason={finish_reason!r}) — refusing to execute.",
                            force=True,
                        )
                        agent._invalid_json_retries = 0
                        agent._cleanup_task_resources(effective_task_id)
                        _final_response = "Response truncated due to output length limit"
                        # Same tool-tail close as interrupt / invalid-tool
                        # exhaustion — this path never reaches finalize_turn.
                        close_interrupted_tool_sequence(messages, _final_response)
                        agent._persist_session(messages, conversation_history)
                        return {
                            "final_response": _final_response,
                            "messages": messages,
                            "api_calls": api_call_count,
                            "completed": False,
                            "partial": True,
                            "error": _final_response,
                        }

                    # Track retries for invalid JSON arguments
                    agent._invalid_json_retries += 1

                    tool_name, error_msg = invalid_json_args[0]
                    agent._buffer_vprint(f"⚠️  Invalid JSON in tool call arguments for '{tool_name}': {error_msg}")

                    if agent._invalid_json_retries < 3:
                        agent._buffer_vprint(f"🔄 Retrying API call ({agent._invalid_json_retries}/3)...")
                        # Don't add anything to messages, just retry the API call
                        continue
                    else:
                        # Instead of returning partial, inject tool error results so the model can recover.
                        # Using tool results (not user messages) preserves role alternation.
                        agent._buffer_vprint("⚠️  Injecting recovery tool results for invalid JSON...")
                        agent._invalid_json_retries = 0  # Reset for next attempt
                        
                        # Append the assistant message with its (broken) tool_calls
                        recovery_assistant = agent._build_assistant_message(assistant_message, finish_reason)
                        append_message(messages, recovery_assistant)
                        
                        # Respond with tool error results for each tool call
                        invalid_names = {name for name, _ in invalid_json_args}
                        for tc in assistant_message.tool_calls:
                            if tc.function.name in invalid_names:
                                err = next(e for n, e in invalid_json_args if n == tc.function.name)
                                tool_result = (
                                    f"Error: Invalid JSON arguments. {err}. "
                                    f"For tools with no required parameters, use an empty object: {{}}. "
                                    f"Please retry with valid JSON."
                                )
                            else:
                                tool_result = "Skipped: other tool call in this response had invalid JSON."
                            append_message(messages, {
                                "role": "tool",
                                "name": tc.function.name,
                                "tool_call_id": coalesce_tool_call_id(tc),
                                "content": tool_result,
                            })
                        continue
                
                # Reset retry counter on successful JSON validation
                agent._invalid_json_retries = 0

                # ── Post-call guardrails ──────────────────────────
                assistant_message.tool_calls = agent._cap_delegate_task_calls(
                    assistant_message.tool_calls
                )
                assistant_message.tool_calls = agent._deduplicate_tool_calls(
                    assistant_message.tool_calls
                )

                # Mixed-batch invalid-name handling: collect the invalid
                # calls now so the assistant message (built below) keeps
                # EVERY call the model emitted — providers require each
                # tool_call to have a matching tool result and vice versa —
                # while only the valid subset is dispatched for execution.
                _invalid_batch_calls = []
                if _mixed_invalid_batch:
                    _invalid_batch_calls = [
                        tc for tc in assistant_message.tool_calls
                        if tc.function.name not in agent.valid_tool_names
                    ]

                assistant_msg = agent._build_assistant_message(assistant_message, finish_reason)

                turn_content = assistant_message.content or ""

                # Some local tool-call templates emit a bare bracketed token
                # (for example ``[memory]``) as assistant content alongside a
                # function call. It is protocol scaffolding, not an answer.
                # Persisting or caching it as visible content lets the empty
                # post-tool fallback replay that token forever after compaction (#78148).
                if (
                    assistant_message.tool_calls
                    and _STALE_MARKER_RE.fullmatch(turn_content.strip())
                ):
                    logger.warning(
                        "Discarding bare tool-call marker from assistant content: %s",
                        turn_content,
                    )
                    turn_content = ""
                    assistant_msg["content"] = ""

                # Classify tools in this turn to determine if they are all housekeeping.
                # This classification is needed regardless of whether the turn has visible content,
                # because a substantive tool-only turn must invalidate any older housekeeping fallback.
                _HOUSEKEEPING_TOOLS = frozenset({
                    "memory", "todo", "skill_manage", "session_search",
                })
                _all_housekeeping = all(
                    tc.function.name in _HOUSEKEEPING_TOOLS
                    for tc in assistant_message.tool_calls
                )

                # If this turn has substantive tools (non-housekeeping), clear any older fallback.
                # Prevents a two-turn-old housekeeping narration from being treated as if it belonged
                # to the immediately preceding substantive tool turn.
                if assistant_message.tool_calls and not _all_housekeeping:
                    agent._last_content_with_tools = None
                    agent._last_content_tools_all_housekeeping = False
                    # Also clear the mute flag: a prior housekeeping turn may
                    # have set _mute_post_response (line ~4667), and the
                    # substantive tools in THIS turn should produce visible
                    # progress output. Without this reset, _vprint suppresses
                    # tool progress until the no-tool-call branch clears it at
                    # line ~4834 — after all tools have finished.
                    agent._mute_post_response = False

                # If this turn has both content AND tool_calls, capture the content
                # as a fallback final response. Common pattern: model delivers its
                # answer and calls memory/skill tools as a side-effect in the same
                # turn. If the follow-up turn after tools is empty, we use this.
                if turn_content and agent._has_content_after_think_block(turn_content):
                    agent._last_content_with_tools = turn_content
                    # Only mute subsequent output when EVERY tool call in
                    # this turn is post-response housekeeping (memory, todo,
                    # skill_manage, etc.).  If any substantive tool is present
                    # (search_files, read_file, write_file, terminal, ...),
                    # keep output visible so the user sees progress.
                    agent._last_content_tools_all_housekeeping = _all_housekeeping
                    if _all_housekeeping and agent._has_stream_consumers():
                        agent._mute_post_response = True
                    elif agent._should_emit_quiet_tool_messages():
                        clean = agent._strip_think_blocks(turn_content).strip()
                        if clean:
                            agent._vprint(f"  ┊ 💬 {clean}")
                
                # Pop thinking-only prefill message(s) before appending
                # (tool-call path — same rationale as the final-response path).
                _had_prefill = False
                while (
                    messages
                    and isinstance(messages[-1], dict)
                    and messages[-1].get("_thinking_prefill")
                ):
                    messages.pop()
                    _had_prefill = True

                # Reset prefill counter when tool calls follow a prefill
                # recovery.  Without this, the counter accumulates across
                # the whole conversation — a model that intermittently
                # empties (empty → prefill → tools → empty → prefill →
                # tools) burns both prefill attempts and the third empty
                # gets zero recovery.  Resetting here treats each tool-
                # call success as a fresh start.
                if _had_prefill:
                    agent._thinking_prefill_retries = 0
                    agent._empty_content_retries = 0
                # Successful tool execution — reset the post-tool nudge
                # flag so it can fire again if the model goes empty on
                # a LATER tool round.
                agent._post_tool_empty_retried = False
                # A landed tool call means any earlier dropped-tool-call stall
                # was recovered — refresh that budget too so it guards each
                # stall independently rather than capping the whole run.
                agent._dropped_toolcall_retries = 0

                previous_msg = messages[-1] if messages else None
                current_interim_visible = agent._interim_assistant_visible_text(assistant_msg)
                previous_interim_visible = (
                    agent._interim_assistant_visible_text(previous_msg)
                    if isinstance(previous_msg, dict)
                    else ""
                )
                duplicate_previous_interim = (
                    bool(current_interim_visible)
                    and isinstance(previous_msg, dict)
                    and previous_msg.get("role") == "assistant"
                    and previous_msg.get("finish_reason") == "incomplete"
                    and previous_interim_visible == current_interim_visible
                )
                append_message(messages, assistant_msg)

                # Mixed batch: error-result the invalid calls and strip them
                # from the execution set. The assistant message above keeps
                # all calls (each gets a matching tool result — the invalid
                # ones get theirs here, the valid ones during execution), so
                # provider-side tool_call/result pairing stays intact.
                if _invalid_batch_calls:
                    for tc in _invalid_batch_calls:
                        append_message(messages, {
                            "role": "tool",
                            "name": tc.function.name,
                            "tool_call_id": coalesce_tool_call_id(tc),
                            "content": _invalid_tool_name_error_content(
                                tc.function.name, agent.valid_tool_names
                            ),
                        })
                    assistant_message.tool_calls = [
                        tc for tc in assistant_message.tool_calls
                        if tc.function.name in agent.valid_tool_names
                    ]

                _tool_turn_persisted = None
                try:
                    # Persist the assistant tool-call turn before any tool
                    # side effects run. If a destructive tool restarts or
                    # terminates Hermes mid-turn, resume logic still sees the
                    # exact tool-call block that already executed.
                    _tool_turn_persisted = agent._flush_messages_to_session_db(
                        messages, conversation_history
                    )
                except Exception as exc:
                    _tool_turn_persisted = False
                    from hermes_state import classify_persistence_error
                    agent._last_persistence_error_cause = (
                        classify_persistence_error(exc)
                    )
                    logger.warning(
                        "Incremental tool-call persistence failed before execution "
                        "(session=%s): %s",
                        agent.session_id or "none",
                        exc,
                    )

                if _tool_turn_persisted is False:
                    # The canonical append failed. Do not project the row or
                    # run side-effecting tools from state that exists only in
                    # this process. Breaking also avoids retrying the same
                    # unpersisted turn until the iteration budget is exhausted.
                    # The flush may have classified the cause internally; if
                    # nothing was recorded, the cause is genuinely unknown.
                    if getattr(agent, "_last_persistence_error_cause", None) is None:
                        agent._last_persistence_error_cause = "unknown"
                    _turn_exit_reason = "session_persistence_failed"
                    final_response = ""
                    failed = True
                    break

                # A UI must never observe an assistant/tool-call row that is
                # still only an ephemeral in-memory projection. Emit interim
                # commentary only after the canonical SessionDB append above.
                if not duplicate_previous_interim:
                    agent._emit_interim_assistant_message(assistant_msg)

                # Close any open streaming display (response box, reasoning
                # box) before tool execution begins.  Intermediate turns may
                # have streamed early content that opened the response box;
                # flushing here prevents it from wrapping tool feed lines.
                # Only signal the display callback — TTS (_stream_callback)
                # should NOT receive None (it uses None as end-of-stream).
                if agent.stream_delta_callback:
                    try:
                        agent.stream_delta_callback(None)
                    except Exception:
                        pass

                agent._execute_tool_calls(assistant_message, messages, effective_task_id, api_call_count)

                if getattr(agent, "_incremental_persistence_failed", False):
                    # A tool result could not be made canonical. Do not send
                    # the in-memory result back to the model or project any
                    # later events from this turn.
                    _turn_exit_reason = "session_persistence_failed"
                    final_response = ""
                    failed = True
                    break

                if agent._tool_guardrail_halt_decision is not None:
                    decision = agent._tool_guardrail_halt_decision
                    _turn_exit_reason = "guardrail_halt"
                    final_response = agent._toolguard_controlled_halt_response(decision)
                    agent._emit_status(
                        f"⚠️ Tool guardrail halted {decision.tool_name}: {decision.code}"
                    )
                    append_message(messages, {"role": "assistant", "content": final_response})
                    # Emit the halt message to the client so it's not
                    # indistinguishable from a crash.  The stream display
                    # was flushed (callback(None)) before tool execution,
                    # but the callback is still alive — fire the text
                    # through it so SSE/TUI clients see the explanation.
                    if final_response:
                        agent._safe_print(f"\n{final_response}\n")
                        if agent.stream_delta_callback:
                            try:
                                agent.stream_delta_callback(final_response)
                                agent.stream_delta_callback(None)
                            except Exception:
                                pass
                    break

                # Reset per-turn retry counters after successful tool
                # execution so a single truncation doesn't poison the
                # entire conversation.
                truncated_tool_call_retries = 0

                # Signal that a paragraph break is needed before the next
                # streamed text.  We don't emit it immediately because
                # multiple consecutive tool iterations would stack up
                # redundant blank lines.  Instead, _fire_stream_delta()
                # will prepend a single "\n\n" the next time real text
                # arrives.
                agent._stream_needs_break = True

                # Refund the iteration if the ONLY tool(s) called were
                # execute_code (programmatic tool calling).  These are
                # cheap RPC-style calls that shouldn't eat the budget.
                _tc_names = {tc.function.name for tc in assistant_message.tool_calls}
                if _tc_names == {"execute_code"}:
                    agent.iteration_budget.refund()
                
                # Use real token counts from the API response to decide
                # compression.  prompt_tokens + completion_tokens is the
                # actual context size the provider reported plus the
                # assistant turn — a tight lower bound for the next prompt.
                # Tool results appended above aren't counted yet, but the
                # threshold (default 50%) leaves ample headroom; if tool
                # results push past it, the next API call will report the
                # real total and trigger compression then.
                #
                # If last_prompt_tokens is 0 (stale after API disconnect
                # or provider returned no usage data), fall back to rough
                # estimate to avoid missing compression.  Without this,
                # a session can grow unbounded after disconnects because
                # should_compress(0) never fires.  (#2153)
                _compressor = agent.context_compressor
                if _compressor.last_prompt_tokens > 0:
                    # Only use prompt_tokens — completion/reasoning
                    # tokens don't consume context window space.
                    # Thinking models (GLM-5.1, QwQ, DeepSeek R1)
                    # inflate completion_tokens with reasoning,
                    # causing premature compression.  (#12026)
                    _real_tokens = _compressor.last_prompt_tokens
                elif _compressor.last_prompt_tokens == -1:
                    # Compression just ran and no API-reported prompt count
                    # has arrived yet. Avoid treating a schema-heavy rough
                    # post-compression estimate as real context pressure.
                    _real_tokens = 0
                else:
                    # Include tool schemas — with 50+ tools enabled
                    # these add 20-30K tokens the messages-only
                    # estimate misses, which can skip compression
                    # past the configured threshold (#14695).
                    # Route-aware (#96995/#97602 class): on a compacted
                    # native-Codex session the generic durable-history
                    # figure overstates the wire and would false-trigger
                    # compression here exactly like the pre-API guard —
                    # this fallback runs precisely when no provider usage
                    # is available (post-disconnect / gateway restart),
                    # the unanchored case from #97602's repro.
                    _real_tokens = _midturn_request_pressure_tokens(
                        agent,
                        messages,
                        active_system_prompt or "",
                        estimate_request_tokens_rough(
                            messages, tools=agent.tools or None
                        ),
                    )

                if (
                    agent.compression_enabled
                    and compression_attempts < max_compression_attempts
                    and _compressor.should_compress(_real_tokens)
                ):
                    compression_attempts += 1
                    # Compression is actually running (block cleared / was
                    # never blocked) — reset the blocked-overflow warning
                    # dedup so a future blocked-over-threshold turn can warn
                    # again (silent-overflow fix #62625).
                    # getattr guard: test doubles built via object.__new__ lack the
                    # method (gateway test-double pitfall) — treat absence as no-op.
                    _clear_warn = getattr(agent, "_clear_context_overflow_warn", None)
                    if callable(_clear_warn):
                        _clear_warn()
                    agent._safe_print("  ⟳ compacting context…")
                    _post_tool_input = messages
                    # Route the overhead-aware _real_tokens (computed above) into compression, not
                    # the bare last_prompt_tokens — which is 0 in the no-usage fallback, hiding the
                    # true request size from the engine's overflow guard (upstream PR #77169 review).
                    messages, active_system_prompt = agent._compress_context(
                        messages, system_message,
                        approx_tokens=_real_tokens,
                        task_id=effective_task_id,
                    )
                    if (
                        messages is _post_tool_input
                        and compression_skipped_due_to_lock(agent)
                    ):
                        # #69870 lock-skip: this pass no-oped because another
                        # path holds the session's compression lock — a
                        # temporary defer, not evidence about compressibility.
                        # Refund the attempt so a lock-loser tool loop does not
                        # burn the shared per-turn budget toward
                        # compression_exhausted (#9893/#35809).
                        compression_attempts -= 1
                    else:
                        conversation_history = conversation_history_after_compression(
                            agent, messages, conversation_history
                        )
                        if _should_skip_model_call_for_reference_handoff(
                            messages, user_message
                        ):
                            logger.info(
                                "Skipping post-tool compaction model call: "
                                "reference-only handoff would be the sole "
                                "active user turn (#80622)"
                            )
                            if not final_response:
                                final_response = _HANDOFF_SKIP_FINAL_RESPONSE
                            _turn_exit_reason = "compaction_handoff_not_actionable"
                            break
                elif agent.compression_enabled:
                    # Over threshold but compression is blocked (summary-LLM
                    # cooldown or anti-thrashing). Surface a deduped warning so
                    # the user isn't left with a silently growing context that
                    # eventually hits the hard provider limit. Mirrors the
                    # turn-context preflight guard (silent-overflow fix #62625).
                    _block_reason = None
                    _info = getattr(_compressor, "should_compress_info", None)
                    if _info is not None:
                        try:
                            _block_reason = _info(_real_tokens)[1]
                        except Exception:
                            _block_reason = None
                    if _block_reason:
                        agent._warn_context_overflow_blocked(
                            _block_reason,
                            _real_tokens,
                            int(getattr(_compressor, "threshold_tokens", 0) or 0),
                        )
                    # Proactive tool-result prune: reclaim re-sent history on
                    # large-window models long before should_compress() (≈50% of
                    # the window) would ever fire. Deterministic, no LLM call;
                    # protects the recent tail. No-op unless proactive_prune_tokens
                    # is configured and _real_tokens is above it — and even then
                    # the prune only commits when it reclaims at least
                    # proactive_prune_min_reclaim_tokens, so prompt-cache breaks
                    # stay episodic like compression's (the one sanctioned cache
                    # break) instead of firing every tool iteration. See
                    # ContextCompressor.prune_tool_results_only.
                    # getattr guard: plugin context engines predating the hook and
                    # minimal test doubles (SimpleNamespace compressors) lack the
                    # method — treat absence as a no-op.
                    _prune = getattr(_compressor, "prune_tool_results_only", None)
                    if callable(_prune):
                        try:
                            _pruned_msgs, _pruned_n = _prune(
                                messages, current_tokens=_real_tokens
                            )
                        except Exception:
                            logger.debug(
                                "proactive tool-result prune failed; skipping",
                                exc_info=True,
                            )
                            _pruned_msgs, _pruned_n = messages, 0
                        # Standard no-op caller contract: only commit when the
                        # engine returned a NEW list object with a non-zero count.
                        if _pruned_n and _pruned_msgs is not messages:
                            # Do NOT rebuild conversation_history here. The compressor
                            # atomically rewrites the active transcript with the durable
                            # rearm threshold, then stamps every returned row with
                            # _DB_PERSISTED_MARKER, so the marker-based flush dedup (see
                            # _flush_messages_to_session_db) prevents duplicate writes.
                            # Calling
                            # conversation_history_after_compression (a compaction-only
                            # helper keyed on the _last_compaction_in_place flag) would be
                            # a no-op at best, and on a stale in-place flag could seed
                            # this turn's fresh, not-yet-persisted rows into history_ids
                            # and skip writing them.
                            messages = _pruned_msgs
                
                # Save session log incrementally (so progress is visible even if interrupted)
                agent._session_messages = messages
                
                # Touch activity before continuing so the gateway's
                # inactivity monitor never sees a stale timestamp
                # between tool completion and the start of the next
                # API call.  Without this, a tool-call result (which
                # takes ~0s to process) followed by slow post-tool
                # processing (compression, persist) and a slow
                # follow-up API call can exceed the gateway inactivity
                # timeout (HERMES_AGENT_TIMEOUT, default 1800s) and the
                # gateway kills the session before the next activity
                # touch fires (#69559, #69131).
                agent._touch_activity(f"tool results posted, continuing iteration #{api_call_count}")
                # Continue loop for next response
                continue
            
            else:
                # No tool calls - this is the final response.
                # (Dropped tool-call recovery — finish_reason=="tool_calls" with
                # an empty tool_calls array — is handled at the finalization
                # chokepoint below, after final_msg is built, so it catches
                # every path that reaches turn finalization, not just this one.)
                final_response = assistant_message.content or ""
                
                # Fix: unmute output when entering the no-tool-call branch
                # so the user can see empty-response warnings and recovery
                # status messages.  _mute_post_response was set during a
                # prior housekeeping tool turn and should not silence the
                # final response path.
                agent._mute_post_response = False
                
                # Check if response only has think block with no actual content after it
                if not agent._has_content_after_think_block(final_response):
                    # ── Partial stream recovery ─────────────────────
                    # If content was already streamed to the user before
                    # the connection died, use it as the final response
                    # instead of falling through to prior-turn fallback
                    # or wasting API calls on retries.
                    _partial_streamed = (
                        getattr(agent, "_current_streamed_assistant_text", "") or ""
                    )
                    if agent._has_content_after_think_block(_partial_streamed):
                        _turn_exit_reason = "partial_stream_recovery"
                        _recovered = agent._strip_think_blocks(_partial_streamed).strip()
                        logger.info(
                            "Partial stream content delivered (%d chars) "
                            "— using as final response",
                            len(_recovered),
                        )
                        agent._emit_status(
                            "↻ Stream interrupted — using delivered content "
                            "as final response"
                        )
                        final_response = _recovered
                        # Streaming delivered a fragment, not a confirmed
                        # final preview. Leave response_previewed false so
                        # gateway fallback delivery can send the recovered
                        # text plus the abnormal-turn explanation.
                        agent._response_was_previewed = False
                        break

                    # If the previous turn already delivered real content alongside
                    # HOUSEKEEPING tool calls (e.g. "You're welcome!" + memory save),
                    # the model has nothing more to say. Use the earlier content
                    # immediately instead of wasting API calls on retries.
                    # NOTE: Only use this shortcut when ALL tools in that turn were
                    # housekeeping (memory, todo, etc.).  When substantive tools
                    # were called (terminal, search_files, etc.), the content was
                    # likely mid-task narration ("I'll scan the directory...") and
                    # the empty follow-up means the model choked — let the
                    # post-tool nudge below handle that instead of exiting early.
                    fallback = getattr(agent, '_last_content_with_tools', None)
                    if fallback and getattr(agent, '_last_content_tools_all_housekeeping', False):
                        _turn_exit_reason = "fallback_prior_turn_content"
                        logger.info("Empty follow-up after tool calls — using prior turn content as final response")
                        agent._emit_status("↻ Empty response after tool calls — using earlier content as final answer")
                        agent._last_content_with_tools = None
                        agent._last_content_tools_all_housekeeping = False
                        agent._empty_content_retries = 0
                        # Do NOT modify the assistant message content — the
                        # old code injected "Calling the X tools..." which
                        # poisoned the conversation history.  Just use the
                        # fallback text as the final response and break.
                        final_response = agent._strip_think_blocks(fallback).strip()
                        agent._response_was_previewed = True
                        break

                    # ── Post-tool-call empty response nudge ───────────
                    # The model returned empty after executing tool calls.
                    # This covers two cases:
                    #  (a) No prior-turn content at all — model went silent
                    #  (b) Prior turn had content + SUBSTANTIVE tools (the
                    #      fallback above was skipped because the content
                    #      was mid-task narration, not a final answer)
                    # Instead of giving up, nudge the model to continue by
                    # appending a user-level hint.  This is the #9400 case:
                    # weaker models (mimo-v2-pro, GLM-5, etc.) sometimes
                    # return empty after tool results instead of continuing
                    # to the next step.  One retry with a nudge usually
                    # fixes it.
                    _prior_was_tool = any(
                        m.get("role") == "tool"
                        for m in messages[-5:]  # check recent messages
                    )
                    # Detect Qwen3/Ollama-style in-content thinking blocks.
                    # Ollama puts <think> in the content field (not in
                    # reasoning_content), so _has_structured below would
                    # miss it.  We check here so thinking-only responses
                    # after tool calls route to prefill instead of nudge.
                    _has_inline_thinking = bool(
                        re.search(
                            r'<think>|<thinking>|<reasoning>',
                            final_response or "",
                            re.IGNORECASE,
                        )
                    )
                    if (
                        _prior_was_tool
                        and not getattr(agent, "_post_tool_empty_retried", False)
                        and not _has_inline_thinking  # thinking model still working — let prefill handle
                    ):
                        agent._post_tool_empty_retried = True
                        # Clear stale narration so it doesn't resurface
                        # on a later empty response after the nudge.
                        agent._last_content_with_tools = None
                        agent._last_content_tools_all_housekeeping = False
                        logger.info(
                            "Empty response after tool calls — nudging model "
                            "to continue processing"
                        )
                        agent._buffer_status(
                            "⚠️ Model returned empty after tool calls — "
                            "nudging to continue"
                        )
                        # Append the empty assistant message first so the
                        # message sequence stays valid:
                        #   tool(result) → assistant("(empty)") → user(nudge)
                        # Without this, we'd have tool → user which most
                        # APIs reject as an invalid sequence.
                        _nudge_msg = agent._build_assistant_message(assistant_message, finish_reason)
                        _nudge_msg["content"] = "(empty)"
                        _nudge_msg["_empty_recovery_synthetic"] = True
                        append_message(messages, _nudge_msg)
                        append_message(messages, {
                            "role": "user",
                            "content": _EMPTY_TOOL_RESPONSE_NUDGE,
                            "_empty_recovery_synthetic": True,
                        })
                        continue

                    # ── Thinking-only prefill continuation ──────────
                    # The model produced structured reasoning (via API
                    # fields) but no visible text content.  Rather than
                    # giving up, append the assistant message as-is and
                    # continue — the model will see its own reasoning
                    # on the next turn and produce the text portion.
                    # Inspired by clawdbot's "incomplete-text" recovery.
                    # Also covers Qwen3/Ollama in-content <think> blocks
                    # (detected above as _has_inline_thinking).
                    _has_structured = bool(
                        getattr(assistant_message, "reasoning", None)
                        or getattr(assistant_message, "reasoning_content", None)
                        or getattr(assistant_message, "reasoning_details", None)
                        or _has_inline_thinking
                    )
                    if _has_structured and agent._thinking_prefill_retries < 2:
                        agent._thinking_prefill_retries += 1
                        logger.info(
                            "Thinking-only response (no visible content) — "
                            "prefilling to continue (%d/2)",
                            agent._thinking_prefill_retries,
                        )
                        agent._buffer_status(
                            f"↻ Thinking-only response — prefilling to continue "
                            f"({agent._thinking_prefill_retries}/2)"
                        )
                        interim_msg = agent._build_assistant_message(
                            assistant_message, "incomplete"
                        )
                        interim_msg["_thinking_prefill"] = True
                        append_message(messages, interim_msg)
                        agent._session_messages = messages
                        continue

                    # ── Empty response retry ──────────────────────
                    # Model returned nothing usable.  Retry up to 3
                    # times before attempting fallback.  This covers
                    # both truly empty responses (no content, no
                    # reasoning) AND reasoning-only responses after
                    # prefill exhaustion — models like mimo-v2-pro
                    # always populate reasoning fields via OpenRouter,
                    # so the old `not _has_structured` guard blocked
                    # retries for every reasoning model after prefill.
                    _truly_empty = not agent._strip_think_blocks(
                        final_response
                    ).strip()
                    _prefill_exhausted = (
                        _has_structured
                        and agent._thinking_prefill_retries >= 2
                    )
                    _empty_candidate = _truly_empty and (
                        not _has_structured or _prefill_exhausted
                    )
                    if _empty_candidate:
                        # NS-503: every empty attempt re-sends the full
                        # conversation input at full price. Record the
                        # attempt (usage/finish_reason signature) so
                        # deterministic empties — e.g. unsignaled
                        # provider refusals with zero output tokens —
                        # stop burning paid retries reproducing the
                        # same empty. Fails open: missing usage or
                        # any generated tokens keep the full budget.
                        _empty_guard.record_empty_attempt(
                            agent,
                            finish_reason=finish_reason,
                            response=response,
                        )
                    _empty_retry_budget = (
                        _empty_guard.empty_retry_budget(agent, response)
                        if _empty_candidate
                        else _empty_guard.DEFAULT_EMPTY_RETRY_BUDGET
                    )
                    _deterministic_empty = _empty_candidate and (
                        _empty_guard.deterministic_empty(agent)
                    )
                    if (
                        _empty_candidate
                        and agent._empty_content_retries < _empty_retry_budget
                        and not _deterministic_empty
                    ):
                        agent._empty_content_retries += 1
                        wait_time = jittered_backoff(
                            agent._empty_content_retries,
                            base_delay=5.0,
                            max_delay=60.0,
                        )
                        logger.warning(
                            "Empty response (no content or reasoning) — "
                            "retry %d/%d in %.1fs (model=%s)",
                            agent._empty_content_retries,
                            _empty_retry_budget, wait_time, agent.model,
                        )
                        _budget_note = (
                            " — high-cost request, reduced retry budget"
                            if _empty_retry_budget < _empty_guard.DEFAULT_EMPTY_RETRY_BUDGET
                            else ""
                        )
                        agent._buffer_status(
                            f"⚠️ Empty response from model — retrying "
                            f"({agent._empty_content_retries}/{_empty_retry_budget}) "
                            f"in {wait_time:.0f}s{_budget_note}"
                        )
                        # Sleep in small increments to stay responsive to interrupts
                        sleep_end = time.time() + wait_time
                        _backoff_touch_counter = 0
                        while time.time() < sleep_end:
                            if agent._interrupt_requested:
                                agent._vprint(f"{agent.log_prefix}⚡ Interrupt detected during empty-response retry wait, aborting.", force=True)
                                _interrupt_text = (
                                    f"Operation interrupted: retrying empty response from model "
                                    f"(retry {agent._empty_content_retries}/{_empty_retry_budget})."
                                )
                                close_interrupted_tool_sequence(messages, _interrupt_text)
                                agent._persist_session(messages, conversation_history)
                                agent.clear_interrupt()
                                return {
                                    "final_response": _interrupt_text,
                                    "messages": messages,
                                    "api_calls": api_call_count,
                                    "completed": False,
                                    "interrupted": True,
                                }
                            time.sleep(0.2)
                            _backoff_touch_counter += 1
                            if _backoff_touch_counter % 150 == 0:  # 150 × 0.2s = 30s
                                agent._touch_activity(
                                    f"empty response retry backoff ({agent._empty_content_retries}/{_empty_retry_budget}), "
                                    f"{int(sleep_end - time.time())}s remaining"
                                )
                        continue

                    if _truly_empty and _deterministic_empty:
                        logger.warning(
                            "Deterministic empty response detected "
                            "(consecutive zero-output completions, "
                            "model=%s provider=%s finish_reason=%s) — "
                            "skipping remaining retries",
                            agent.model, agent.provider, finish_reason,
                        )
                        agent._buffer_status(
                            "⚠️ Model is deterministically returning empty "
                            "(zero output tokens) — skipping further retries "
                            "to avoid repeat charges"
                        )

                    # ── Exhausted retries — try fallback provider ──
                    # Before giving up with "(empty)", attempt to
                    # switch to the next provider in the fallback
                    # chain.  This covers the case where a model
                    # (e.g. GLM-4.5-Air) consistently returns empty
                    # due to context degradation or provider issues.
                    if _truly_empty and agent._fallback_chain:
                        logger.warning(
                            "Empty response after %d retries — "
                            "attempting fallback (model=%s, provider=%s)",
                            agent._empty_content_retries, agent.model,
                            agent.provider,
                        )
                        agent._buffer_status(
                            "⚠️ Model returning empty responses — "
                            "switching to fallback provider..."
                        )
                        if agent._try_activate_fallback():
                            active_system_prompt = _sync_failover_system_message(
                                agent, api_messages, active_system_prompt)
                            agent._empty_content_retries = 0
                            agent._buffer_status(
                                f"↻ Switched to fallback: {agent.model} "
                                f"({agent.provider})"
                            )
                            logger.info(
                                "Fallback activated after empty responses: "
                                "now using %s on %s",
                                agent.model, agent.provider,
                            )
                            # This site sits directly in the OUTER iteration
                            # loop (not the retry loop), so `continue` already
                            # restarts the iteration and re-runs the pre-API
                            # preflight against the fallback's context window
                            # (#84733). A `break` here would exit the outer
                            # loop and end the turn without ever calling the
                            # fallback. Clear the preflight block so the
                            # re-run isn't skipped.
                            _preflight_compression_blocked = False
                            continue

                    # Exhausted retries and fallback chain (or no
                    # fallback configured).  Fall through to the
                    # "(empty)" terminal.
                    # Surface the buffered retry/fallback trace so the
                    # user can see what was attempted before "(empty)".
                    # NS-503: if we know roughly what the empty streak
                    # cost (each attempt re-billed the full input), say
                    # so — an unexplained charge for "no answer" is the
                    # core of the complaint.
                    _streak_cost = _empty_guard.streak_cost_usd(agent)
                    if _streak_cost is not None:
                        agent._buffer_status(
                            f"ℹ️ Estimated cost of these empty attempts: "
                            f"~${_streak_cost:.2f} (input tokens are billed "
                            f"per attempt even when no answer is produced)"
                        )
                    agent._flush_status_buffer()
                    _turn_exit_reason = "empty_response_exhausted"
                    reasoning_text = agent._extract_reasoning(assistant_message)
                    agent._drop_trailing_empty_response_scaffolding(messages)
                    assistant_msg = agent._build_assistant_message(assistant_message, finish_reason)
                    assistant_msg["content"] = "(empty)"
                    # This is a user-facing failure sentinel for the gateway,
                    # not real assistant content. Persisting it makes later
                    # "continue" turns replay assistant("(empty)") as if it
                    # were a meaningful model response, which can keep long
                    # tool-heavy sessions stuck in empty-response loops.
                    assistant_msg["_empty_terminal_sentinel"] = True
                    append_message(messages, assistant_msg)

                    if reasoning_text:
                        reasoning_preview = reasoning_text[:500] + "..." if len(reasoning_text) > 500 else reasoning_text
                        logger.warning(
                            "Reasoning-only response (no visible content) "
                            "after exhausting retries and fallback. "
                            "Reasoning: %s", reasoning_preview,
                        )
                        agent._emit_status(
                            "⚠️ Model produced reasoning but no visible "
                            "response after all retries. Returning empty."
                        )
                    else:
                        logger.warning(
                            "Empty response (no content or reasoning) "
                            "after %d retries. No fallback available. "
                            "model=%s provider=%s",
                            agent._empty_content_retries, agent.model,
                            agent.provider,
                        )
                        agent._emit_status(
                            "❌ Model returned no content after all retries"
                            + (" and fallback attempts." if agent._fallback_chain else
                               ". No fallback providers configured.")
                        )

                    # Deliver a labeled reasoning excerpt instead of a bare
                    # "(empty)" when the model DID think but never produced
                    # visible text. This is delivery-only: the persisted
                    # assistant message above keeps the "(empty)" sentinel
                    # (its replay semantics prevent empty-response loops),
                    # and raw chain-of-thought is never promoted to a normal
                    # answer earlier in the ladder — prefill continuation,
                    # empty-content retries, and provider fallback all run
                    # first. Only at this terminal, where the alternative is
                    # returning nothing, is showing the model's own reasoning
                    # (clearly labeled as such) strictly more useful.
                    # Idea credit: PR #48795 (@ligl0325).
                    if reasoning_text:
                        final_response = (
                            "⚠️ The model produced only internal reasoning and "
                            "no final answer, despite retries"
                            + (" and fallback" if agent._fallback_chain else "")
                            + ". Its last reasoning, which may contain the "
                            "answer:\n\n" + reasoning_preview
                        )
                    else:
                        final_response = "(empty)"
                    break
                
                # Reset retry counter/signature on successful content
                agent._empty_content_retries = 0
                agent._thinking_prefill_retries = 0
                # Successful content reached — surface the one-shot fallback
                # switch notice (if a fallback activated this turn) before
                # dropping the noisy retry buffer, so a provider/model switch
                # stays visible even when the fallback succeeds.
                agent._emit_pending_fallback_notice()
                agent._clear_status_buffer()

                from agent.agent_runtime_helpers import (
                    intent_ack_continuation_mode,
                    trailing_continue_intent,
                )

                _ack_mode = intent_ack_continuation_mode(agent)
                # Said-continue-but-stopped guard (agent.stall_guards): the
                # model ended the turn with no tool calls but its short reply
                # TAILS with an announced next action ("Let me now…",
                # "I will now…"). Unlike the intent-ack detector below, this
                # fires mid-task too (after tool results), which is exactly
                # where eval traces show the stall. It reuses the SAME bounded
                # continuation path and counter (max 2 per turn), so the
                # alternation-safe interim-assistant + user-nudge mechanism —
                # not a new parallel one — carries the recovery.
                _stall_continue_intent = (
                    bool(getattr(agent, "_stall_guards", True))
                    and agent.valid_tool_names
                    and codex_ack_continuations < 2
                    and trailing_continue_intent(
                        agent._strip_think_blocks(final_response or "")
                    )
                )
                if _stall_continue_intent or (
                    _ack_mode != "off"
                    and agent.valid_tool_names
                    and codex_ack_continuations < 2
                    and agent._looks_like_codex_intermediate_ack(
                        user_message=user_message,
                        assistant_content=final_response,
                        messages=messages,
                        require_workspace=(_ack_mode == "codex_only"),
                    )
                ):
                    if _stall_continue_intent:
                        logger.info(
                            "Stall guard: turn ending on trailing continue-"
                            "intent with no tool calls — re-prompting to act "
                            "(%d/2)", codex_ack_continuations + 1,
                        )
                    codex_ack_continuations += 1
                    interim_msg = agent._build_assistant_message(assistant_message, "incomplete")
                    append_message(messages, interim_msg)
                    agent._emit_interim_assistant_message(interim_msg)

                    continue_msg = {
                        "role": "user",
                        "content": _CODEX_ACK_CONTINUATION_NUDGE,
                    }
                    append_message(messages, continue_msg)
                    agent._session_messages = messages
                    # An acknowledgment is explicitly non-final. Do not let its
                    # text suppress iteration-limit summarization if this
                    # continuation consumes the remaining budget.
                    final_response = None
                    continue

                codex_ack_continuations = 0

                if truncated_response_parts:
                    final_response = _join_truncated_parts([*truncated_response_parts, final_response])
                    truncated_response_parts = []
                    length_continue_retries = 0
                    # The continuation recovered, so the fragments stay in the transcript.
                    for _frag in messages:
                        if isinstance(_frag, dict):
                            _frag.pop("_length_continuation_fragment", None)
                            _frag.pop("_length_continuation_nudge", None)
                
                final_response = agent._strip_think_blocks(final_response).strip()
                
                final_msg = agent._build_assistant_message(assistant_message, finish_reason)

                # ── Dropped tool-call recovery (copilot/Claude) ────────
                # Some providers (observed: claude-opus-4.8 / claude-sonnet-4.5
                # on GitHub Copilot, ~2026-07) return finish_reason="tool_calls"
                # while the parsed tool_calls array is empty — the model
                # signalled it wanted to act but the payload shipped no call.
                # Reaching finalization with that mismatch means the turn is
                # about to end with the task unstarted (the narration, which may
                # be in content or only in the reasoning field, gets treated as
                # the final answer). Re-prompt (bounded to 3 CONSECUTIVE stalls;
                # the budget resets after any successful tool round) to make the
                # model emit the call instead of exiting. finish_reason="stop"
                # text finishes never enter this guard.
                if (
                    finish_reason == "tool_calls"
                    and not assistant_message.tool_calls
                    and getattr(agent, "_dropped_toolcall_retries", 0) < 3
                ):
                    agent._dropped_toolcall_retries = getattr(agent, "_dropped_toolcall_retries", 0) + 1
                    logger.warning(
                        "finish_reason=tool_calls with empty tool_calls array "
                        "(narration only) — re-prompting to emit the call "
                        "(retry %d/3, model=%s provider=%s)",
                        agent._dropped_toolcall_retries, agent.model, agent.provider,
                    )
                    agent._emit_status(
                        "↻ Model signaled a tool call but sent none — "
                        f"re-prompting ({agent._dropped_toolcall_retries}/3)"
                    )
                    # Both halves of the re-prompt pair are ephemeral recovery
                    # scaffolding (mirrors the empty-response nudge pattern):
                    # the interim narration-only assistant turn exists solely to
                    # keep role alternation valid for the nudge, and the nudge
                    # exists solely to drive the retry. Flag both so the
                    # persistence layer never writes them to the durable
                    # transcript and the finalization pop below can strip an
                    # unanswered tail pair. A recovered (answered) pair stays
                    # buried mid-list in live memory but is skipped by the
                    # flush regardless of position.
                    final_msg["_dropped_toolcall_nudge"] = True
                    append_message(messages, final_msg)
                    append_message(messages, {
                        "role": "user",
                        "content": _DROPPED_TOOLCALL_NUDGE_CONTENT,
                        "_dropped_toolcall_nudge": True,
                    })
                    agent._session_messages = messages
                    final_response = None
                    continue

                # Reached finalization without the dropped-tool-call mismatch —
                # a genuine turn end. Clear the consecutive-stall budget so the
                # next turn starts fresh.
                agent._dropped_toolcall_retries = 0

                # Pop thinking-only prefill and empty-response retry
                # scaffolding before appending either a final response or a
                # verification-stop follow-up. These internal turns are only
                # for the next API retry and should not become durable
                # transcript context.
                while (
                    messages
                    and isinstance(messages[-1], dict)
                    and (
                        messages[-1].get("_thinking_prefill")
                        or messages[-1].get("_empty_recovery_synthetic")
                        or messages[-1].get("_empty_terminal_sentinel")
                        or messages[-1].get("_dropped_toolcall_nudge")
                    )
                ):
                    messages.pop()

                try:
                    from agent.verification_stop import (
                        build_verify_on_stop_nudge,
                        verify_on_stop_enabled,
                    )

                    if verify_on_stop_enabled():
                        _verify_nudge = build_verify_on_stop_nudge(
                            session_id=getattr(agent, "session_id", None),
                            changed_paths=getattr(agent, "_turn_file_mutation_paths", set()),
                            attempts=getattr(agent, "_verification_stop_nudges", 0),
                        )
                    else:
                        _verify_nudge = None
                except Exception:
                    logger.debug("verification stop-loop check failed", exc_info=True)
                    _verify_nudge = None

                if _verify_nudge:
                    agent._verification_stop_nudges = (
                        getattr(agent, "_verification_stop_nudges", 0) + 1
                    )
                    final_msg["finish_reason"] = "verification_required"
                    # The assistant response is real content — persist it and
                    # emit to the UI as an interim message so the user sees the
                    # attempted final answer before the verification loop runs.
                    # Only the nudge is flagged synthetic so it gets stripped
                    # from the durable transcript (#65919 §7).
                    agent._emit_interim_assistant_message(final_msg)
                    append_message(messages, final_msg)
                    try:
                        agent._flush_messages_to_session_db(messages, conversation_history)
                    except Exception:
                        logger.debug("verify-on-stop interim flush failed", exc_info=True)
                    append_message(messages, {
                        "role": "user",
                        "content": _verify_nudge,
                        "_verification_stop_synthetic": True,
                    })
                    agent._session_messages = messages
                    # Run the verification-stop loop silently — the nudge is an
                    # internal turn that should not add noise to the user's
                    # terminal. Keep a debug breadcrumb in agent.log for tracing.
                    logger.debug("verification stop-loop nudge issued (attempt %d)",
                                 agent._verification_stop_nudges)
                    # Keep the attempted answer only as an explicit fallback for
                    # continuation-budget exhaustion.  ``final_response`` itself
                    # must be cleared so the finalizer can distinguish this gate
                    # from unrelated error/recovery exits. (#61631)
                    # Track whether this candidate was already streamed so the
                    # finalizer can mark the turn previewed only if the
                    # candidate is actually reused as the final response.
                    _pending_verification_response = final_response
                    _pending_verification_response_previewed = (
                        agent._interim_content_was_streamed(final_response or "")
                    )
                    final_response = None
                    continue

                # User verification-loop gate: when the agent edited code this
                # turn, let a registered `pre_verify` hook (plugin/shell) keep it
                # going one more turn. The shipped guidance is folded into the
                # evidence-based verify-on-stop nudge above, so this path has no
                # default continuation cost.
                _verify_nudge2 = None
                _edited = sorted(getattr(agent, "_turn_file_mutation_paths", set()) or [])
                _attempt = getattr(agent, "_pre_verify_nudges", 0)
                try:
                    from agent.verify_hooks import max_verify_nudges
                    from hermes_cli.lifecycle import has_hook
                    from hermes_cli.plugins import get_pre_verify_continue_message

                    if _edited and has_hook("pre_verify") and _attempt < max_verify_nudges():
                        # Posture is fixed for the session — resolve once + cache.
                        coding = getattr(agent, "_resolved_is_coding", None)
                        if coding is None:
                            from agent.coding_context import is_coding_context
                            coding = bool(is_coding_context(platform=getattr(agent, "platform", "") or ""))
                            agent._resolved_is_coding = coding
                        _verify_nudge2 = get_pre_verify_continue_message(
                            session_id=getattr(agent, "session_id", None) or "",
                            platform=getattr(agent, "platform", "") or "",
                            model=getattr(agent, "model", "") or "",
                            coding=coding,
                            attempt=_attempt,
                            final_response=final_response,
                            changed_paths=_edited,
                        )
                except Exception:
                    logger.debug("pre_verify hook check failed", exc_info=True)
                    _verify_nudge2 = None

                if _verify_nudge2:
                    agent._pre_verify_nudges = _attempt + 1
                    final_msg["finish_reason"] = "verify_hook_continue"
                    # The assistant response is real content — persist it and
                    # emit to the UI as an interim message so the user sees the
                    # attempted final answer before the pre_verify loop runs.
                    # Only the nudge is flagged synthetic so it gets stripped
                    # from the durable transcript (#65919 §7).
                    agent._emit_interim_assistant_message(final_msg)
                    append_message(messages, final_msg)
                    try:
                        agent._flush_messages_to_session_db(messages, conversation_history)
                    except Exception:
                        logger.debug("pre_verify interim flush failed", exc_info=True)
                    append_message(messages, {
                        "role": "user",
                        "content": _verify_nudge2,
                        "_pre_verify_synthetic": True,
                    })
                    agent._session_messages = messages
                    logger.debug("pre_verify nudge issued (attempt %d)",
                                 agent._pre_verify_nudges)
                    _pending_verification_response = final_response
                    _pending_verification_response_previewed = (
                        agent._interim_content_was_streamed(final_response or "")
                    )
                    final_response = None
                    continue

                # ── Kanban worker terminal-tool stop guard ─────────────
                # Workers must end with kanban_complete / kanban_block.
                # Models sometimes narrate the next step ("Let me write the
                # report") and stop with finish_reason=stop — a clean exit
                # that the dispatcher records as protocol_violation. Nudge
                # once or twice before allowing that exit.
                try:
                    from agent.kanban_stop import build_kanban_stop_nudge

                    _kanban_nudge = build_kanban_stop_nudge(
                        messages=messages,
                        attempts=getattr(agent, "_kanban_stop_nudges", 0),
                    )
                except Exception:
                    logger.debug("kanban stop-loop check failed", exc_info=True)
                    _kanban_nudge = None

                if _kanban_nudge:
                    agent._kanban_stop_nudges = (
                        getattr(agent, "_kanban_stop_nudges", 0) + 1
                    )
                    final_msg["finish_reason"] = "kanban_terminal_required"
                    final_msg["_kanban_stop_synthetic"] = True
                    append_message(messages, final_msg)
                    append_message(messages, {
                        "role": "user",
                        "content": _kanban_nudge,
                        "_kanban_stop_synthetic": True,
                    })
                    agent._session_messages = messages
                    logger.info(
                        "kanban stop-loop nudge issued (attempt %d) task=%s",
                        agent._kanban_stop_nudges,
                        os.environ.get("HERMES_KANBAN_TASK", ""),
                    )
                    agent._emit_status(
                        "⚠️ Kanban worker tried to exit without "
                        "kanban_complete/kanban_block — nudging to finish"
                    )
                    # Same finalizer contract as verify-on-stop: clear
                    # final_response while continuing so a later budget
                    # exhaustion path does not treat the narrated stop as
                    # a completed answer.
                    _pending_verification_response = final_response
                    _pending_verification_response_previewed = (
                        agent._interim_content_was_streamed(final_response or "")
                    )
                    final_response = None
                    continue

                append_message(messages, final_msg)
                # Make the completed answer durable before leaving the loop —
                # a session torn down before finalize_turn's _persist_session
                # otherwise loses a reply the user already saw (#81641). Same
                # contract as the tool-call exit (#49045) and the verify exits
                # above; _DB_PERSISTED_MARKER keeps _persist_session idempotent.
                # Unlike the tool-call exit, failure must NOT abort the turn:
                # no side effect follows and _persist_session retries the write.
                # Full incident narrative: tests/run_agent/test_81641_*.py.
                try:
                    agent._flush_messages_to_session_db(messages, conversation_history)
                except Exception:
                    logger.warning(
                        "final text-turn flush failed (session=%s) — reply is "
                        "not yet durable; relying on finalize_turn retry",
                        getattr(agent, "session_id", None) or "none",
                        exc_info=True,
                    )

                _turn_exit_reason = f"text_response(finish_reason={finish_reason})"
                if not agent.quiet_mode:
                    agent._safe_print(f"🎉 Conversation completed after {api_call_count} OpenAI-compatible API call(s)")
                break
            
        except Exception as e:
            # Count every escaped exception against the per-turn bound before
            # classification — permanent failures must terminate even when the
            # turn budget is unlimited (#92450).
            _outer_error_count += 1

            # Phase-aware error classification. The huge outer try/except spans
            # both the actual API request and all local post-processing of the
            # returned assistant message. Deterministic local bugs (e.g.
            # passing a multimodal content list into a regex helper after a
            # vision turn or context compaction) should not be retried: they
            # will fail identically on every iteration and only burn the
            # iteration budget. We classify an error as local by inspecting the
            # traceback: if the exception propagated through any of the known
            # local post-processing helpers and never entered the interruptible
            # API-call helpers, it is almost certainly a local processing bug.
            # (#66267)
            #
            # Interpreter shutdown: if the process is tearing down, every
            # executor-backed operation (API call, tool dispatch, memory sync)
            # raises ``RuntimeError: cannot schedule new futures after
            # interpreter shutdown``. Retrying is pointless — the executor is
            # gone for good — and each retry just spams another traceback.
            # Break immediately so the turn exits cleanly. (#93217)
            if sys.is_finalizing() or _is_interpreter_shutdown_error(e):
                error_msg = (
                    f"Interpreter is shutting down — cannot continue "
                    f"(API call #{api_call_count}): {e}"
                )
                try:
                    agent._safe_print(f"❌ {error_msg}")
                except (OSError, ValueError):
                    pass
                logger.warning(error_msg)
                # Best-effort persist — the executor is dying, so this may
                # raise the same RuntimeError.  Don't let that mask the
                # shutdown exit.  finalize_turn will retry the persist.
                try:
                    agent._persist_session(messages, conversation_history)
                except Exception:
                    pass
                _turn_exit_reason = "interpreter_shutdown"
                final_response = (
                    "Session is shutting down. Your conversation can be "
                    "resumed with: hermes --resume <session-id>"
                )
                # Don't append the assistant message here — a thinking-prefill
                # or interim assistant may already be the tail, and appending
                # would create assistant→assistant.  finalize_turn handles
                # this case safely (lines 341-353: appends only when
                # _tail_role != "assistant"), matching the pattern at other
                # break sites that set final_response without appending.
                break

            tb_module_names: set[str] = set()
            _tb = e.__traceback__
            while _tb is not None:
                _fname = os.path.splitext(os.path.basename(_tb.tb_frame.f_code.co_filename))[0]
                tb_module_names.add(_fname)
                _tb = _tb.tb_next

            _hit_local = bool(tb_module_names & _LOCAL_PROCESSING_MODULES)
            _hit_api = bool(tb_module_names & _API_CALL_MODULES)

            _is_local_processing_error = _hit_local and not _hit_api

            if _is_local_processing_error:
                error_msg = (
                    f"Error during local message processing after "
                    f"OpenAI-compatible API call #{api_call_count}: {str(e)}"
                )
            else:
                error_msg = f"Error during OpenAI-compatible API call #{api_call_count}: {str(e)}"
            # The background-review fork sets suppress_status_output=True so
            # lifecycle noise never reaches the user's terminal — but this
            # bare print() bypassed it, leaking ❌ lines onto the shell after
            # the TUI exited. Honor the same contract _vprint enforces
            # (quiet_mode -q still shows hard failures, matching force=True
            # semantics; suppress_status_output silences them). The
            # logger.exception below still captures the full traceback.
            if getattr(agent, "suppress_status_output", False):
                logger.error(error_msg)
            else:
                try:
                    print(f"❌ {error_msg}")
                except (OSError, ValueError):
                    logger.error(error_msg)

            # Emit the full traceback at ERROR level so it lands in both
            # agent.log AND errors.log.  Previously this was logged at DEBUG,
            # which meant intermittent outer-loop failures were unreproducible
            # — users would see a one-line summary on screen with no way to
            # recover the call site.  logger.exception() includes the
            # traceback automatically and emits at ERROR.
            logger.exception("Outer loop error in API call #%d", api_call_count)
            
            # If an assistant message with tool_calls was already appended,
            # the API expects a role="tool" result for every tool_call_id.
            # Fill in error results for any that weren't answered yet.
            for idx in range(len(messages) - 1, -1, -1):
                msg = messages[idx]
                if not isinstance(msg, dict):
                    break
                if msg.get("role") == "tool":
                    continue
                if msg.get("role") == "assistant" and msg.get("tool_calls"):
                    answered_ids = {
                        m["tool_call_id"]
                        for m in messages[idx + 1:]
                        if isinstance(m, dict) and m.get("role") == "tool"
                    }
                    for tc in msg["tool_calls"]:
                        if not tc or not isinstance(tc, dict): continue
                        if tc["id"] not in answered_ids:
                            err_msg = {
                                "role": "tool",
                                "name": _ra().AIAgent._get_tool_call_name_static(tc),
                                "tool_call_id": tc["id"],
                                "content": f"Error executing tool: {error_msg}",
                            }
                            append_message(messages, err_msg)
                break
            
            # Non-tool errors don't need a synthetic message injected.
            # The error is already printed to the user (line above), and
            # the retry loop continues.  Injecting a fake user/assistant
            # message pollutes history, burns tokens, and risks violating
            # role-alternation invariants.

            # If we're near the limit, break to avoid infinite loops.
            # Local processing errors are deterministic — stop immediately
            # rather than retrying until the budget is exhausted. Repeated
            # outer-loop errors stop after a small per-turn cap: with
            # max_iterations now unlimited by default, a permanent failure
            # would otherwise spin forever and overwrite the rotated log
            # history within minutes (#92450).
            _outer_error_cap = min(_MAX_OUTER_LOOP_ERRORS, max(1, agent.max_iterations))
            if (
                _is_local_processing_error
                or api_call_count >= agent.max_iterations - 1
                or _outer_error_count >= _outer_error_cap
            ):
                if _is_local_processing_error:
                    _turn_exit_reason = f"local_processing_error({error_msg[:80]})"
                    final_response = f"I apologize, but I encountered an error while processing the model response: {error_msg}"
                elif _outer_error_count >= _outer_error_cap:
                    failed = True
                    _turn_exit_reason = f"repeated_outer_errors({error_msg[:80]})"
                    final_response = f"I apologize, but I encountered repeated errors: {error_msg}"
                else:
                    _turn_exit_reason = f"error_near_max_iterations({error_msg[:80]})"
                    final_response = f"I apologize, but I encountered repeated errors: {error_msg}"
                # Don't append the assistant message here — a thinking-prefill
                # or interim assistant may already be the tail, and appending
                # would create assistant→assistant.  finalize_turn handles
                # this case safely (lines 341-353: appends only when
                # _tail_role != "assistant"), matching the pattern at other
                # break sites that set final_response without appending.
                break
    
    # Post-loop turn finalization extracted to agent/turn_finalizer.finalize_turn
    # (god-file decomposition Phase 1 step 4). Behavior-neutral: the assembled
    # result dict is returned exactly as before.
    result = finalize_turn(
        agent,
        final_response=final_response,
        api_call_count=api_call_count,
        interrupted=interrupted,
        failed=failed,
        messages=messages,
        conversation_history=conversation_history,
        effective_task_id=effective_task_id,
        turn_id=turn_id,
        user_message=user_message,
        original_user_message=original_user_message,
        _should_review_memory=_should_review_memory,
        _turn_exit_reason=_turn_exit_reason,
        _pending_verification_response=_pending_verification_response,
        _pending_verification_response_previewed=_pending_verification_response_previewed,
    )
    if _compression_timeout_exhausted:
        # Reuse the gateway's existing context-recovery contract (#98722,
        # salvaged from #98741). The bloated transcript remains intact while
        # future input can move to a clean session instead of replaying the
        # summarize-timeout loop.
        result["error"] = _COMPRESSION_TIMEOUT_FINAL_RESPONSE
        result["partial"] = True
        result["compression_exhausted"] = True
    return result



__all__ = ["run_conversation"]
