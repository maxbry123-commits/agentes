/*
Copyright The Kubernetes Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package csidriver

import (
	"testing"

	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/util/validation/field"
	genericapirequest "k8s.io/apiserver/pkg/endpoints/request"
	apitesting "k8s.io/kubernetes/pkg/api/testing"
	storage "k8s.io/kubernetes/pkg/apis/storage"
	registry "k8s.io/kubernetes/pkg/registry/storage/csidriver"
	"k8s.io/kubernetes/test/declarative_validation/meta"
)

func TestDeclarativeValidate(t *testing.T) {
	for _, apiVersion := range apiVersions {
		t.Run(apiVersion, func(t *testing.T) {
			testDeclarativeValidate(t, apiVersion)
		})
	}
}

func TestDeclarativeValidateUpdate(t *testing.T) {
	for _, apiVersion := range apiVersions {
		t.Run(apiVersion, func(t *testing.T) {
			testDeclarativeValidateUpdate(t, apiVersion)
		})
	}
}

func testDeclarativeValidate(t *testing.T, apiVersion string) {
	ctx := genericapirequest.WithRequestInfo(genericapirequest.NewDefaultContext(), &genericapirequest.RequestInfo{
		APIPrefix:         "apis",
		APIGroup:          "storage.k8s.io",
		APIVersion:        apiVersion,
		Resource:          "csidrivers",
		IsResourceRequest: true,
		Verb:              "create",
	})

	obj := mkCSIDriver()
	meta.RunObjectMetaTestCases(t, ctx, &obj, registry.Strategy, meta.WithStringentFinalizerValidation())
}

func testDeclarativeValidateUpdate(t *testing.T, apiVersion string) {
	ctx := genericapirequest.WithRequestInfo(genericapirequest.NewDefaultContext(), &genericapirequest.RequestInfo{
		APIPrefix:         "apis",
		APIGroup:          "storage.k8s.io",
		APIVersion:        apiVersion,
		Resource:          "csidrivers",
		Name:              "valid-obj",
		IsResourceRequest: true,
		Verb:              "update",
	})

	testCases := map[string]struct {
		oldObj       storage.CSIDriver
		updateObj    storage.CSIDriver
		expectedErrs field.ErrorList
	}{
		"valid update": {
			oldObj:    mkCSIDriver(),
			updateObj: mkCSIDriver(),
		},
		"invalid update volumeLifecycleModes changed": {
			oldObj:    mkCSIDriver(TweakVolumeLifecycleModes(storage.VolumeLifecyclePersistent)),
			updateObj: mkCSIDriver(TweakVolumeLifecycleModes(storage.VolumeLifecycleEphemeral)),
			expectedErrs: field.ErrorList{
				field.Invalid(field.NewPath("spec", "volumeLifecycleModes"), nil, "").WithOrigin("immutable").MarkAlpha(),
			},
		},
		"invalid update volumeLifecycleModes unset to set": {
			oldObj:    mkCSIDriver(),
			updateObj: mkCSIDriver(TweakVolumeLifecycleModes(storage.VolumeLifecyclePersistent)),
			expectedErrs: field.ErrorList{
				field.Invalid(field.NewPath("spec", "volumeLifecycleModes"), nil, "").WithOrigin("immutable").MarkAlpha(),
			},
		},
		"invalid update volumeLifecycleModes set to unset": {
			oldObj:    mkCSIDriver(TweakVolumeLifecycleModes(storage.VolumeLifecyclePersistent)),
			updateObj: mkCSIDriver(),
			expectedErrs: field.ErrorList{
				field.Invalid(field.NewPath("spec", "volumeLifecycleModes"), nil, "").WithOrigin("immutable").MarkAlpha(),
			},
		},
	}
	for k, tc := range testCases {
		t.Run(k, func(t *testing.T) {
			tc.oldObj.ResourceVersion = "1"
			tc.updateObj.ResourceVersion = "2"
			apitesting.VerifyUpdateValidationEquivalence(t, ctx, &tc.updateObj, &tc.oldObj, registry.Strategy, tc.expectedErrs)
		})
	}

	updateObj := mkCSIDriver()
	meta.RunObjectMetaUpdateTestCases(t, ctx, &updateObj, registry.Strategy, meta.WithStringentFinalizerValidation())
}

func mkCSIDriver(tweaks ...func(csi *storage.CSIDriver)) storage.CSIDriver {
	falsePtr := false
	csi := storage.CSIDriver{
		ObjectMeta: metav1.ObjectMeta{
			Name: "valid-obj",
		},
		Spec: storage.CSIDriverSpec{
			AttachRequired:                &falsePtr,
			PodInfoOnMount:                &falsePtr,
			StorageCapacity:               &falsePtr,
			SELinuxMount:                  &falsePtr,
			PreventPodSchedulingIfMissing: &falsePtr,
		},
	}
	for _, tweak := range tweaks {
		tweak(&csi)
	}
	return csi
}

func TweakVolumeLifecycleModes(modes ...storage.VolumeLifecycleMode) func(csi *storage.CSIDriver) {
	return func(csi *storage.CSIDriver) {
		csi.Spec.VolumeLifecycleModes = modes
	}
}
