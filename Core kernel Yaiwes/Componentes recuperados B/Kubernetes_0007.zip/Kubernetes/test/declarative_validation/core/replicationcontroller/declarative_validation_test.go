/*
Copyright 2025 The Kubernetes Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package replicationcontroller

import (
	"fmt"
	"strings"
	"testing"

	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/util/validation/field"
	genericapirequest "k8s.io/apiserver/pkg/endpoints/request"
	podtest "k8s.io/kubernetes/pkg/api/pod/testing"
	apitesting "k8s.io/kubernetes/pkg/api/testing"
	api "k8s.io/kubernetes/pkg/apis/core"
	registry "k8s.io/kubernetes/pkg/registry/core/replicationcontroller"
	poddeclarativevalidation "k8s.io/kubernetes/test/declarative_validation/core/pod"
	"k8s.io/kubernetes/test/declarative_validation/meta"
	"k8s.io/utils/ptr"
)

func TestDeclarativeValidate(t *testing.T) {
	ctx := genericapirequest.WithRequestInfo(genericapirequest.NewDefaultContext(), &genericapirequest.RequestInfo{
		APIPrefix:         "api",
		APIGroup:          "",
		APIVersion:        "v1",
		Resource:          "replicationcontrollers",
		IsResourceRequest: true,
		Verb:              "create",
	})
	testCases := map[string]struct {
		input        api.ReplicationController
		expectedErrs field.ErrorList
	}{
		// baseline
		"empty resource": {
			input: mkValidReplicationController(),
		},
		// metadata.name
		"name: empty": {
			input: mkValidReplicationController(func(rc *api.ReplicationController) {
				rc.Name = ""
			}),
			expectedErrs: field.ErrorList{
				field.Required(field.NewPath("metadata.name"), "").MarkFromImperative(),
			},
		},
		"name: label format": {
			input: mkValidReplicationController(func(rc *api.ReplicationController) {
				rc.Name = "this-is-a-label"
			}),
		},
		"name: subdomain format": {
			input: mkValidReplicationController(func(rc *api.ReplicationController) {
				rc.Name = "this.is.a.subdomain"
			}),
		},
		"name: invalid label format": {
			input: mkValidReplicationController(func(rc *api.ReplicationController) {
				rc.Name = "-this-is-not-a-label"
			}),
			expectedErrs: field.ErrorList{
				field.Invalid(field.NewPath("metadata.name"), nil, "").WithOrigin("format=k8s-long-name").MarkBeta(),
			},
		},
		"name: invalid subdomain format": {
			input: mkValidReplicationController(func(rc *api.ReplicationController) {
				rc.Name = ".this.is.not.a.subdomain"
			}),
			expectedErrs: field.ErrorList{
				field.Invalid(field.NewPath("metadata.name"), nil, "").WithOrigin("format=k8s-long-name").MarkBeta(),
			},
		},
		"name: label format with trailing dash": {
			input: mkValidReplicationController(func(rc *api.ReplicationController) {
				rc.Name = "this-is-a-label-"
			}),
			expectedErrs: field.ErrorList{
				field.Invalid(field.NewPath("metadata.name"), nil, "").WithOrigin("format=k8s-long-name").MarkBeta(),
			},
		},
		"name: subdomain format with trailing dash": {
			input: mkValidReplicationController(func(rc *api.ReplicationController) {
				rc.Name = "this.is.a.subdomain-"
			}),
			expectedErrs: field.ErrorList{
				field.Invalid(field.NewPath("metadata.name"), nil, "").WithOrigin("format=k8s-long-name").MarkBeta(),
			},
		},
		"name: long label format": {
			input: mkValidReplicationController(func(rc *api.ReplicationController) {
				rc.Name = strings.Repeat("x", 253)
			}),
		},
		"name: long subdomain format": {
			input: mkValidReplicationController(func(rc *api.ReplicationController) {
				rc.Name = strings.Repeat("x.", 126) + "x"
			}),
		},
		"name: too long label format": {
			input: mkValidReplicationController(func(rc *api.ReplicationController) {
				rc.Name = strings.Repeat("x", 254)
			}),
			expectedErrs: field.ErrorList{
				field.Invalid(field.NewPath("metadata.name"), nil, "").WithOrigin("format=k8s-long-name").MarkBeta(),
			},
		},
		"name: too long subdomain format": {
			input: mkValidReplicationController(func(rc *api.ReplicationController) {
				rc.Name = strings.Repeat("x.", 126) + "xx"
			}),
			expectedErrs: field.ErrorList{
				field.Invalid(field.NewPath("metadata.name"), nil, "").WithOrigin("format=k8s-long-name").MarkBeta(),
			},
		},
		// metadata.generateName (note: it's is not really validated)
		"generateName: valid with empty name": {
			input: mkValidReplicationController(func(rc *api.ReplicationController) {
				rc.Name = ""
				rc.GenerateName = "name"
			}),
			expectedErrs: field.ErrorList{
				field.Required(field.NewPath("metadata.name"), "").MarkFromImperative(),
				field.InternalError(field.NewPath("metadata.name"), fmt.Errorf("")).MarkFromImperative(),
			},
		},

		"generateName: label format": {
			input: mkValidReplicationController(func(rc *api.ReplicationController) {
				rc.GenerateName = "this-is-a-label"
			}),
		},
		"generateName: subdomain format": {
			input: mkValidReplicationController(func(rc *api.ReplicationController) {
				rc.GenerateName = "this.is.a.subdomain"
			}),
		},
		"generateName: invalid format": {
			input: mkValidReplicationController(func(rc *api.ReplicationController) {
				rc.GenerateName = "Obviously not a valid generateName!!"
			}),
		},
		"generateName: too long": {
			input: mkValidReplicationController(func(rc *api.ReplicationController) {
				rc.GenerateName = strings.Repeat("x", 4096)
			}),
		},
		// spec.replicas
		"replicas: nil": {
			input: mkValidReplicationController(func(rc *api.ReplicationController) {
				rc.Spec.Replicas = nil
			}),
			expectedErrs: field.ErrorList{
				field.Required(field.NewPath("spec.replicas"), ""),
			},
		},
		"replicas: 0": {
			input: mkValidReplicationController(setSpecReplicas(0)),
		},
		"replicas: positive": {
			input: mkValidReplicationController(setSpecReplicas(100)),
		},
		"replicas: negative": {
			input: mkValidReplicationController(setSpecReplicas(-1)),
			expectedErrs: field.ErrorList{
				field.Invalid(field.NewPath("spec.replicas"), nil, "").WithOrigin("minimum"),
			},
		},
		// spec.minReadySeconds
		"minReadySeconds: 0": {
			input: mkValidReplicationController(setSpecMinReadySeconds(0)),
		},
		"minReadySeconds: positive": {
			input: mkValidReplicationController(setSpecMinReadySeconds(100)),
		},
		"minReadySeconds: negative": {
			input: mkValidReplicationController(setSpecMinReadySeconds(-1)),
			expectedErrs: field.ErrorList{
				field.Invalid(field.NewPath("spec.minReadySeconds"), nil, "").WithOrigin("minimum"),
			},
		},
		// spec.template.spec.tolerations[*].key
		"tolerations: valid key": {
			input: mkValidReplicationController(setSpecTolerations(api.Toleration{Key: "example.com/valid-key", Operator: api.TolerationOpExists})),
		},
		"tolerations: valid key without prefix": {
			input: mkValidReplicationController(setSpecTolerations(api.Toleration{Key: "simple-key", Operator: api.TolerationOpExists})),
		},
		"tolerations: invalid key format": {
			input: mkValidReplicationController(setSpecTolerations(api.Toleration{Key: "invalid key", Operator: api.TolerationOpExists})),
			expectedErrs: field.ErrorList{
				field.Invalid(field.NewPath("spec.template.spec.tolerations").Index(0).Child("key"), nil, "").WithOrigin("format=k8s-label-key").MarkAlpha(),
			},
		},
	}
	for k, tc := range testCases {
		t.Run(k, func(t *testing.T) {
			apitesting.VerifyValidationEquivalence(t, ctx, &tc.input, registry.Strategy, tc.expectedErrs)
		})
	}
	obj := mkValidReplicationController()
	meta.RunObjectMetaTestCases(t, ctx, &obj, registry.Strategy, meta.WithStringentFinalizerValidation())
	poddeclarativevalidation.RunDeclarativeValidateEvictionRespondersTestCases(t, ctx, registry.Strategy, field.NewPath("spec", "template", "spec"), new(mkValidReplicationController()), func(baseObj *api.ReplicationController, responders []api.EvictionResponder, schedulingGroup *api.PodSchedulingGroup) {
		baseObj.Spec.Template.Spec.EvictionResponders = responders
		baseObj.Spec.Template.Spec.SchedulingGroup = schedulingGroup
	})
}

func TestDeclarativeValidateUpdate(t *testing.T) {
	ctx := genericapirequest.WithRequestInfo(genericapirequest.NewDefaultContext(), &genericapirequest.RequestInfo{
		APIPrefix:         "api",
		APIGroup:          "",
		APIVersion:        "v1",
		Resource:          "replicationcontrollers",
		Name:              "valid-obj",
		IsResourceRequest: true,
		Verb:              "update",
	})
	testCases := map[string]struct {
		old          api.ReplicationController
		update       api.ReplicationController
		expectedErrs field.ErrorList
	}{
		// baseline
		"no change": {
			old:    mkValidReplicationController(),
			update: mkValidReplicationController(),
		},
		// metadata.name
		"name: changed": {
			old: mkValidReplicationController(),
			update: mkValidReplicationController(func(rc *api.ReplicationController) {
				rc.Name += "x"
			}),
			expectedErrs: field.ErrorList{
				field.Invalid(field.NewPath("metadata.name"), nil, "").MarkFromImperative(),
			},
		},
		// metadata.generateName
		"generateName: changed": {
			old: mkValidReplicationController(),
			update: mkValidReplicationController(func(rc *api.ReplicationController) {
				rc.GenerateName += "x"
			}),
			// This is, oddly, mutable.  We should probably ratchet this off
			// and make it immutable.
		},
		// spec.replicas
		"replicas: nil": {
			old: mkValidReplicationController(),
			update: mkValidReplicationController(func(rc *api.ReplicationController) {
				rc.Spec.Replicas = nil
			}),
			expectedErrs: field.ErrorList{
				field.Required(field.NewPath("spec.replicas"), ""),
			},
		},
		"replicas: 0": {
			old:    mkValidReplicationController(),
			update: mkValidReplicationController(setSpecReplicas(0)),
		},
		"replicas: positive": {
			old:    mkValidReplicationController(),
			update: mkValidReplicationController(setSpecReplicas(100)),
		},
		"replicas: negative": {
			old:    mkValidReplicationController(),
			update: mkValidReplicationController(setSpecReplicas(-1)),
			expectedErrs: field.ErrorList{
				field.Invalid(field.NewPath("spec.replicas"), nil, "").WithOrigin("minimum"),
			},
		},
		// spec.minReadySeconds
		"minReadySeconds: 0": {
			old:    mkValidReplicationController(),
			update: mkValidReplicationController(setSpecMinReadySeconds(0)),
		},
		"minReadySeconds: positive": {
			old:    mkValidReplicationController(),
			update: mkValidReplicationController(setSpecMinReadySeconds(3)),
		},
		"minReadySeconds: negative": {
			old:    mkValidReplicationController(),
			update: mkValidReplicationController(setSpecMinReadySeconds(-1)),
			expectedErrs: field.ErrorList{
				field.Invalid(field.NewPath("spec.minReadySeconds"), nil, "").WithOrigin("minimum"),
			},
		},
	}
	for k, tc := range testCases {
		t.Run(k, func(t *testing.T) {
			tc.old.ObjectMeta.ResourceVersion = "1"
			tc.update.ObjectMeta.ResourceVersion = "1"
			apitesting.VerifyUpdateValidationEquivalence(t, ctx, &tc.update, &tc.old, registry.Strategy, tc.expectedErrs)
		})
	}
	updateObj := mkValidReplicationController()
	meta.RunObjectMetaUpdateTestCases(t, ctx, &updateObj, registry.Strategy, meta.WithStringentFinalizerValidation())
}

// mkValidReplicationController produces a ReplicationController which passes
// validation with no tweaks.
func mkValidReplicationController(tweaks ...func(rc *api.ReplicationController)) api.ReplicationController {
	rc := api.ReplicationController{
		ObjectMeta: metav1.ObjectMeta{Name: "abc", Namespace: metav1.NamespaceDefault},
		Spec: api.ReplicationControllerSpec{
			Replicas: ptr.To[int32](1),
			Selector: map[string]string{"a": "b"},
			Template: &api.PodTemplateSpec{
				ObjectMeta: metav1.ObjectMeta{
					Labels: map[string]string{"a": "b"},
				},
				Spec: podtest.MakePodSpec(),
			},
		},
	}
	for _, tweak := range tweaks {
		tweak(&rc)
	}
	return rc
}

func setSpecReplicas(val int32) func(rc *api.ReplicationController) {
	return func(rc *api.ReplicationController) {
		rc.Spec.Replicas = ptr.To(val)
	}
}

func setSpecMinReadySeconds(val int32) func(rc *api.ReplicationController) {
	return func(rc *api.ReplicationController) {
		rc.Spec.MinReadySeconds = val
	}
}

func setSpecTolerations(tolerations ...api.Toleration) func(rc *api.ReplicationController) {
	return func(rc *api.ReplicationController) {
		rc.Spec.Template.Spec.Tolerations = tolerations
	}
}
