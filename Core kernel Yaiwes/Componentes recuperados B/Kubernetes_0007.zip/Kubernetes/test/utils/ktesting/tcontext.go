/*
Copyright 2023 The Kubernetes Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package ktesting

import (
	"context"
	"flag"
	"fmt"
	"strings"
	"sync"
	"testing"
	"testing/synctest"
	"time"

	"github.com/onsi/gomega"

	"k8s.io/klog/v2"
	"k8s.io/klog/v2/ktesting"
	"k8s.io/kubernetes/test/utils/ktesting/format"
	"k8s.io/kubernetes/test/utils/ktesting/initoption"
	"k8s.io/kubernetes/test/utils/ktesting/internal"
)

// Underlier is the additional interface implemented by the per-test LogSink
// behind [TContext.Logger]. Together with [initoption.BufferLogs] it can be
// used to capture log output in memory to check it in tests.
type Underlier = ktesting.Underlier

// DefaultCleanupGracePeriod is the time that a [TContext] gets canceled before
// the deadline of its underlying test suite (usually determined via "go test
// -timeout"). This gives the running test(s) time to fail with an informative
// timeout error. After that, all cleanup callbacks then have the remaining
// time to complete before the test binary is killed.
//
// For this to work, each blocking call in a test must respect the
// cancellation of the [TContext].
//
// When using Ginkgo to manage the test suite and running tests, the
// cleanup grace period is ignored because Ginkgo itself manages timeouts.
//
// This value can be overridden per-[TContext] via [initoption.WithCleanupGracePeriod].
const DefaultCleanupGracePeriod = 5 * time.Second

// TB is the interface common to [testing.T], [testing.B], [testing.F] and
// [github.com/onsi/ginkgo/v2] which ktesting relies upon itself or
// passes through (like Chdir, TempDir).
//
// In contrast to [testing.TB], it can be implemented also outside of the
// testing package.
//
// Fatal/Error/Skip are used by ktesting instead of Log + FailNow/Failed/SkipNow
// because when implemented by Ginkgo it is better to pass the reason for
// a failure or skip directly to Ginkgo in the method intended for that purpose.
type TB interface {
	Attr(key, value string)
	Chdir(dir string)
	Cleanup(func())
	Error(args ...any)
	Errorf(format string, args ...any)
	Fail()
	FailNow()
	Failed() bool
	Fatal(args ...any)
	Fatalf(format string, args ...any)
	Helper()
	Log(args ...any)
	Logf(format string, args ...any)
	Name() string
	Setenv(key, value string)
	Skip(args ...any)
	Skipf(format string, args ...any)
	SkipNow()
	Skipped() bool
	TempDir() string
}

// ContextTB adds support for cleanup callbacks with explicit context
// parameter. This is used when integrating with Ginkgo: then CleanupCtx
// gets implemented via ginkgo.DeferCleanup.
type ContextTB interface {
	TB
	CleanupCtx(func(ctx context.Context))
}

// Init can be called in a unit or integration test to create
// a test context which:
// - has a per-test logger with verbosity derived from the -v command line flag
// - gets canceled when the test finishes (via [TB.Cleanup])
//
// Note that the test context supports the interfaces of [TB] and
// [context.Context] and thus can be used like one of those where needed.
// It also has additional methods for retrieving the logger and canceling
// the context early, which can be useful in tests which want to wait
// for goroutines to terminate after cancellation.
//
// If the [TB] implementation also implements [ContextTB], then
// [TContext.CleanupCtx] uses [ContextTB.CleanupCtx] and uses
// the context passed into that callback. This can be used to let
// Ginkgo create a fresh context for cleanup code.
//
// Can be called more than once per test to get different contexts with
// independent cancellation. The default behavior described above can be
// modified via optional functional options defined in [initoption].
//
// Can be called inside a synctest bubble. Signal handling (cleaning up on
// SIGINT, progress reporting on SIGUSR1) then does not get initialized because
// code running inside a bubble should not depend on outside input. Progress
// reporting still works when some parent test already initialized it.
// Therefore the recommended pattern is to initialize ktesting first, then
// create the synctest bubble:
//
//	func TestSomething(t *testing.T) { ktesting.Init(t).SyncTest("", testSomething) }
//	func testSomething(tCtx ktesting.TContext) { ... }
//
// This pattern also has the advantage that the test code cannot accidentally
// use the testing.T instance directly. The same works for normal tests:
//
//	func TestSomething(t *testing.T) { testSomething(ktesting.Init(t)) }
//	func testSomething(tCtx ktesting.TContext) { ... }
func Init(tb TB, opts ...InitOption) TContext {
	tb.Helper()

	c := internal.InitConfig{
		PerTestOutput: true,
	}
	for _, opt := range opts {
		opt(&c)
	}

	// We don't need a Deadline implementation, testing.B doesn't have it.
	// But if we have one, we use it to determine the deadline and
	// set a timeout shortly before it.
	//
	// This also allows us to detect a synctest bubble.
	isSyncTest := false
	var deadline *time.Time
	if deadlineTB, deadlineOK := tb.(interface {
		Deadline() (time.Time, bool)
	}); deadlineOK {
		func() {
			defer func() {
				// Calling testing.T.Deadline panics inside a synctest bubble.
				// There's no API to detect that in advance, so here we react
				// by catching the panic.
				if r := recover(); r != nil {
					isSyncTest = true
				}
			}()
			if d, ok := deadlineTB.Deadline(); ok {
				deadline = &d
			}
		}()
	}

	ctx := defaultProgressReporter.init(tb, isSyncTest)
	var header func() string
	if c.PerTestOutput {
		logger := newLogger(tb, c.BufferLogs)
		ctx = klog.NewContext(ctx, logger)
		header = klogHeader
	}

	// Resolve the effective cleanup grace period: use the caller-supplied value
	// if positive, otherwise fall back to DefaultCleanupGracePeriod.
	gracePeriod := c.CleanupGracePeriod
	if gracePeriod <= 0 {
		gracePeriod = DefaultCleanupGracePeriod
	}

	var cancelTimeout func(cause string)
	if deadline != nil {
		timeLeft := time.Until(*deadline)
		timeLeft -= gracePeriod
		ctx, cancelTimeout = withTimeout(ctx, tb, timeLeft, fmt.Sprintf("test suite deadline (%s) is close, need to clean up before the %s cleanup grace period", deadline.Truncate(time.Second), gracePeriod))
	}

	// Construct new TContext with context and settings as determined above.
	tCtx := InitCtx(ctx, tb)
	tCtx.cleanupGracePeriod = gracePeriod
	tCtx.isSyncTest = isSyncTest
	if cancelTimeout != nil {
		tCtx.cancel = cancelTimeout
	} else {
		tCtx = tCtx.WithCancel()
		tCtx.Cleanup(func() {
			tCtx.Cancel(cleanupErr(tCtx.Name()).Error())
		})
	}
	tCtx.perTestHeader = header

	return tCtx
}

func newLogger(tb TB, bufferLogs bool) klog.Logger {
	config := ktesting.NewConfig(
		ktesting.AnyToString(func(v interface{}) string {
			// For basic types where the string
			// representation is "obvious" we use
			// fmt.Sprintf because format.Object always
			// adds a <"type"> prefix, which is too long
			// for simple values.
			switch v := v.(type) {
			case int, int32, int64, uint, uint32, uint64, float32, float64, bool:
				return fmt.Sprintf("%v", v)
			case string:
				return v
			default:
				return strings.TrimSpace(format.Object(v, 1))
			}
		}),
		ktesting.VerbosityFlagName("v"),
		ktesting.VModuleFlagName("vmodule"),
		ktesting.BufferLogs(bufferLogs),
	)

	// Copy klog settings instead of making the ktesting logger
	// configurable directly.
	var fs flag.FlagSet
	config.AddFlags(&fs)
	for _, name := range []string{"v", "vmodule"} {
		from := flag.CommandLine.Lookup(name)
		to := fs.Lookup(name)
		if err := to.Value.Set(from.Value.String()); err != nil {
			panic(err)
		}
	}

	// Ensure consistent logging: this klog.Logger writes to tb, adding the
	// date/time header, and our own wrapper emulates that behavior for
	// Log/Logf/...
	logger := ktesting.NewLogger(tb, config)
	return logger
}

type InitOption = initoption.InitOption

// InitCtx is a variant of [Init] which uses an already existing context and
// whatever logger and timeouts are stored there.
func InitCtx(ctx context.Context, tb TB, opts ...InitOption) TContext {
	c := internal.InitConfig{}
	for _, opt := range opts {
		opt(&c)
	}
	gracePeriod := c.CleanupGracePeriod
	if gracePeriod <= 0 {
		gracePeriod = DefaultCleanupGracePeriod
	}
	return TContext{
		Context:            ctx,
		testingTB:          testingTB{TB: tb},
		cleanupGracePeriod: gracePeriod,
	}
}

// withTB constructs a new TContext with a different TB instance.
//
// This is used internally to set up some of the context, in particular
// clients, in the root test and then run sub-tests:
//
//	func TestSomething(t *testing.T) {
//	   tCtx := ktesting.Init(t)
//	   ...
//	   tCtx = ktesting.WithRESTConfig(tCtx, config)
//
//	   t.Run("sub", func (t *testing.T) {
//	       tCtx := ktesting.WithTB(tCtx, t)
//	       ...
//	   })
//
// withTB sets up cancellation for the sub-test and uses per-test output.
func (tCtx TContext) withTB(tb TB) TContext {
	tCtx.testingTB.TB = tb
	if tCtx.perTestHeader != nil {
		logger := newLogger(tb, false /* don't buffer logs in sub-test */)
		tCtx.Context = klog.NewContext(tCtx.Context, logger)
	}
	return tCtx.WithCancel()
}

// run implements the different Run and SyncTest methods. It's not an exported
// method because tCtx.Run is more discoverable (same usage as
// with normal Go).
func run(tCtx TContext, name string, syncTest bool, cb func(tCtx TContext)) bool {
	tCtx.Helper()
	switch tb := tCtx.TB().(type) {
	case *testing.T:
		if syncTest {
			f := func(t *testing.T) {
				// We must not propagate the parent's
				// cancellation channel into the bubble,
				// it causes "panic: receive on synctest channel from outside bubble".
				//
				// Sync tests shouldn't need the overall suite timeout,
				// so this seems okay.
				tCtx.isSyncTest = true
				tCtx = tCtx.WithoutCancel().withTB(t)
				cb(tCtx)
			}
			if name != "" {
				return tb.Run(name, func(t *testing.T) { synctest.Test(t, f) })
			}
			synctest.Test(tb, f)
			return true
		}
		return tb.Run(name, func(t *testing.T) {
			cb(tCtx.withTB(t))
		})
	case *testing.B:
		if !syncTest {
			return tb.Run(name, func(b *testing.B) {
				cb(tCtx.withTB(b))
			})
		}
	}

	what := "Run"
	if syncTest {
		what = "SyncTest"
	}
	tCtx.Fatalf("%s not implemented, underlying %T does not support it", what, tCtx.TB())

	return false
}

// WithContext constructs a new TContext with a different Context instance.
// This can be used in callbacks which receive a Context, for example
// from Gomega:
//
//	gomega.Eventually(tCtx, func(ctx context.Context) {
//	   tCtx := ktesting.WithContext(tCtx, ctx)
//	   ...
//
// Cancellation and deadline are determined by the new context.
// Values are looked up first in the new context, then the old one.
// In other words, values set previous via WithValue are still
// available.
func (tCtx TContext) WithContext(ctx context.Context) TContext {
	tCtx.Context = &chainContext{Context: ctx, previousCtx: tCtx.Context}
	return tCtx
}

// WithValue wraps [context.WithValue] such that the result is again a TContext.
func (tCtx TContext) WithValue(key, val any) TContext {
	ctx := context.WithValue(tCtx, key, val)
	return tCtx.WithContext(ctx)
}

type chainContext struct {
	context.Context
	previousCtx context.Context
}

func (ctx *chainContext) Value(key any) any {
	if val := ctx.Context.Value(key); val != nil {
		return val
	}
	return ctx.previousCtx.Value(key)
}

// TContext implements [context.Context], [testing.TB] and some additional
// methods. [TContext] is the public pointer type for referencing a TC.
// Variables are usually called tCtx. To ensure that test code does not
// use `t` directly unintentionally, it is recommended to use two functions:
//
//	func TestSomething(t *testing.T) { testSomething(ktesting.Init(t)) }
//	func testSomething(tCtx ktesting.TContext) { ... }
//
// Log output is associated with the current test and includes a header similar
// to klog, which enables post-processing to distinguish between log output
// (starts with header) and failure messages (header comes later). Errors
// ([Error], [Errorf]) are recorded with "ERROR" as prefix, fatal errors
// ([Fatal], [Fatalf]) with "FATAL ERROR". Indention is used to ensure that
// follow-up lines belonging to the same log entry can be handled properly
// by post-processing and to make the header stand out more.
//
// tCtx provides features offered by Ginkgo also when using normal Go [testing]:
//   - The context contains a deadline that expires soon enough before
//     the overall timeout that cleanup code can still run.
//   - Cleanup callbacks can get their own, separate contexts when
//     registered via [CleanupCtx].
//   - CTRL-C aborts, prints a progress report, and then cleans up
//     before terminating.
//   - SIGUSR1 prints a progress report without aborting.
//
// Progress reporting is more informative when doing polling with
// [gomega.Eventually] and [gomega.Consistently]. Without that, it
// can only report which tests are active.
type TContext struct {
	// Context makes the methods of the underlying context
	// available. It must not be modified.
	context.Context

	// testingTB makes the methods of the underlying test implementation
	// available. Its embedded TB must not be modified.
	testingTB

	// perTestHeader is an optional function which produces a klog-like perTestHeader when
	// not using some global logger.
	perTestHeader func() string

	// for Cancel
	cancel func(cause string)

	// steps is a concatenation ("step1: step2: step3: ") of steps passed to WithStep.
	// It's empty if there are no steps.
	steps string

	// for IsSyncTest
	isSyncTest bool

	// for WithNamespace
	namespace string

	// capture, if non-nil, changes Error/Errorf/Fatal/Fatalf/Fail/FailNow so
	// that they intercept the problem and convert to errors. Log messages
	// are passed through.
	//
	// Used by WithError.
	capture *capture

	// cleanupGracePeriod is the effective cleanup grace period for this context.
	// It is always non-zero: both Init and InitCtx resolve it from the supplied
	// options or fall back to DefaultCleanupGracePeriod.
	cleanupGracePeriod time.Duration
}

type capture struct {
	mutex  sync.Mutex
	errors []error
	failed bool
}

// testingTB is needed to avoid a name conflict
// between field and method in tContext.
type testingTB struct {
	// TB makes the methods of the underlying test implementation available.
	// In particular Helper must be called directly, not via a wrapper.
	// It must not be modified.
	TB
}

// Parallel signals that this test is to be run in parallel with (and
// only with) other parallel tests. In other words, it needs to be
// called in each test which is meant to run in parallel.
//
// Only supported in Go unit tests, calling it elsewhere causes a test failure.
//
// When a unit test is run multiple times due to use of -test.count or -test.cpu,
// multiple instances of a single test never run in parallel with each other.
func (tCtx TContext) Parallel() {
	if tb, ok := tCtx.TB().(interface{ Parallel() }); ok {
		tb.Parallel()
	} else {
		tCtx.Fatalf("Parallel not implemented, underlying %T does not support it", tCtx.TB())
	}
}

// Cancel can be invoked to cancel the context before the test is completed.
// Tests which use the context to control goroutines and then wait for
// termination of those goroutines must call Cancel to avoid a deadlock.
//
// The cause, if non-empty, is turned into an error which is equivalent
// to context.Canceled. context.Cause will return that error for the
// context.
func (tCtx TContext) Cancel(cause string) {
	if tCtx.cancel != nil {
		tCtx.cancel(cause)
	}
}

// CleanupCtx registers a callback that will get invoked when the test
// has finished. Callbacks get invoked in last-in-first-out order (LIFO).
//
// Using CleanupCtx is preferred because of the automatic context cancellation.
// The following broken (!) cleanup code will use a canceled context,
// which is not desirable:
//
//	// tCtx gets canceled when the test ends and before the callback runs.
//	tCtx.Cleanup(func() { /* do something with the test's tCtx */ })
//
// A safer way to run cleanup code is:
//
//	tCtx.CleanupCtx(func (tCtx ktesting.TContext) { /* do something with the cleanup's tCtx */ })
//
// The logger and clients are the same as in the TContext that CleanupCtx
// is invoked on.
func (tCtx TContext) CleanupCtx(cb func(TContext)) {
	tCtx.Helper()

	if tb, ok := tCtx.TB().(ContextTB); ok {
		// Use context from base TB (most likely Ginkgo).
		tb.CleanupCtx(func(ctx context.Context) {
			tCtx := tCtx.WithContext(ctx)
			cb(tCtx)
		})
		return
	}

	tCtx.Cleanup(func() {
		// Use new context. This is the code path for "go test". The
		// context then has *no* deadline. In the code path above for
		// Ginkgo, Ginkgo is more sophisticated and also applies
		// timeouts to cleanup calls which accept a context.
		childCtx := tCtx.WithContext(context.WithoutCancel(tCtx))
		cb(childCtx)
	})
}

// Run runs cb as a subtest called name. It blocks until cb returns or
// calls t.Parallel to become a parallel test.
//
// Only supported in Go unit tests or benchmarks. It fails the current
// test when called elsewhere.
func (tCtx TContext) Run(name string, cb func(tCtx TContext)) bool {
	return run(tCtx, name, false, cb)
}

// SyncTest uses [synctest.Test] to execute the callback inside a bubble.
// Creates a new subtest if the name is non-empty, otherwise it creates
// the bubble directly in the current test context.
//
// Only works in Go unit tests.
//
// Cleaning up on SIGINT is not available because code running inside a bubble
// should not depend on outside input.
func (tCtx TContext) SyncTest(name string, cb func(tCtx TContext)) bool {
	return run(tCtx, name, true, cb)
}

// IsSyncTest returns true if the context was created by SyncTest.
//
// Inside such a context, Wait is usable. This can be used in
// code which runs inside synctest bubbles and outside:
//   - Inside a bubble, Wait can be used to block until
//     background activity has settled down (= "durably blocked").
//     Eventually and Consistently both call Wait and then check
//     the condition.
//   - Outside, polling or some synchronization mechanism has to be used.
func (tCtx TContext) IsSyncTest() bool {
	return tCtx.isSyncTest
}

// Wait calls [synctest.Wait] and thus ensures that all background
// activity has settled down (= "durably blocked").
//
// Only works inside a bubble started by SyncTest (can be checked with
// IsSyncTest), panics elsewhere.
func (tCtx TContext) Wait() {
	synctest.Wait()
}

// TB returns the underlying TB. This can be used to "break the glass"
// and cast back into a testing.T or TB. Calling TB is necessary
// because TContext wraps the underlying TB.
//
// For example, in benchmarks it is necessary to cast back to
// a testing.B because not all benchmark-only methods are provided.
// This examples uses separate functions again to ensure that
// b isn't used unintentionally:
//
//	func BenchmarkSomething(b *testing.B) { benchmarkSomething(ktesting.Init(b) }
//	func benchmarkSomething(tCtx ktesting.TContext) {
//	    ... set up with tCtx ...
//	    for tCtx.TB().(*testing.B).Loop() {
//	        ...
//	    }
//	}
func (tCtx TContext) TB() TB { return tCtx.testingTB.TB }

// Logger returns a logger for the current test. This is a shortcut
// for calling klog.FromContext.
//
// Output emitted via this logger and the TB interface (like Logf)
// is formatted consistently. The TB interface generates a single
// message string, while Logger enables structured logging and can
// be passed down into code which expects a logger.
//
// To skip intermediate helper functions during stack unwinding,
// TB.Helper can be called in those functions.
func (tCtx TContext) Logger() klog.Logger {
	return klog.FromContext(tCtx.Context)
}

// Expect wraps [gomega.Expect] such that a failure will be reported via
// [TContext.Fatal]. As with [gomega.Expect], additional values
// may get passed. Those values then all must be nil for the assertion
// to pass. This can be used with functions which return a value
// plus error. The error gets checked automatically.
//
//	myAmazingThing := func(int, error) { ...}
//	tCtx.Expect(myAmazingThing()).Should(gomega.Equal(1))
func (tCtx TContext) Expect(actual interface{}, extra ...interface{}) gomega.Assertion {
	return gomegaAssertion(tCtx, true, actual, extra...)
}

// Require is an alias for Expect.
func (tCtx TContext) Require(actual interface{}, extra ...interface{}) gomega.Assertion {
	return gomegaAssertion(tCtx, true, actual, extra...)
}

// Assert also wraps [gomega.Expect], but in contrast to Expect = Require,
// it reports a failure through [TContext.Error]. This makes it possible
// to test several different assertions.
func (tCtx TContext) Assert(actual interface{}, extra ...interface{}) gomega.Assertion {
	return gomegaAssertion(tCtx, false, actual, extra...)
}

// WithNamespace creates a new context with a Kubernetes namespace name for retrieval through [Namespace].
func (tCtx TContext) WithNamespace(namespace string) TContext {
	tCtx.namespace = namespace
	return tCtx
}

// Namespace returns the Kubernetes namespace name that was set previously
// through WithNamespace and the empty string if none is available.
//
// This namespace is the one to be used by tests which need to create namespace-scoped
// objects. The name is guaranteed to be unique for the test context, so tests running
// in parallel need to be set up so that each test has its own namespace.
func (tCtx TContext) Namespace() string {
	return tCtx.namespace
}
