// The MIT License (MIT)

// Copyright (c) 2017-2020 Uber Technologies Inc.

// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

package task

import (
	"context"
	"encoding/json"
	"runtime/debug"

	"github.com/uber/cadence/common/activecluster"
	"github.com/uber/cadence/common/log"
	"github.com/uber/cadence/common/log/tag"
)

type (
	executorWrapper struct {
		currentClusterName string
		activeClusterMgr   activecluster.Manager
		activeExecutor     Executor
		standbyExecutor    Executor
		logger             log.Logger
	}
)

func NewExecutorWrapper(
	currentClusterName string,
	activeClusterMgr activecluster.Manager,
	activeExecutor Executor,
	standbyExecutor Executor,
	logger log.Logger,
) Executor {
	return &executorWrapper{
		currentClusterName: currentClusterName,
		activeClusterMgr:   activeClusterMgr,
		activeExecutor:     activeExecutor,
		standbyExecutor:    standbyExecutor,
		logger:             logger,
	}
}

func (e *executorWrapper) Stop() {
	e.activeExecutor.Stop()
	e.standbyExecutor.Stop()
}

func (e *executorWrapper) Execute(task Task) (ExecuteResponse, error) {
	if e.isActiveTask(task) {
		return e.activeExecutor.Execute(task)
	}

	return e.standbyExecutor.Execute(task)
}

func (e *executorWrapper) isActiveTask(
	task Task,
) bool {
	domainID := task.GetDomainID()
	wfID := task.GetWorkflowID()
	rID := task.GetRunID()

	activeClusterInfo, err := e.activeClusterMgr.GetActiveClusterInfoByWorkflow(context.Background(), domainID, wfID, rID)
	if err != nil {
		e.logger.Warn("Failed to get active cluster info, process task as active.", tag.WorkflowDomainID(domainID), tag.WorkflowID(wfID), tag.WorkflowRunID(rID), tag.Error(err))
		return true
	}

	if activeClusterInfo.ActiveClusterName != e.currentClusterName {
		if e.logger.DebugOn() {
			taskJSON, _ := json.Marshal(task)
			e.logger.Debug("Process task as standby.",
				tag.WorkflowDomainID(domainID),
				tag.Dynamic("task", string(taskJSON)),
				tag.Dynamic("taskType", task.GetTaskType()),
				tag.ClusterName(activeClusterInfo.ActiveClusterName),
				tag.Dynamic("stack", string(debug.Stack())),
			)
		}
		return false
	}
	if e.logger.DebugOn() {
		taskJSON, _ := json.Marshal(task)
		e.logger.Debug("Process task as active.",
			tag.WorkflowDomainID(domainID),
			tag.Dynamic("task", string(taskJSON)),
			tag.Dynamic("taskType", task.GetTaskType()),
			tag.ClusterName(activeClusterInfo.ActiveClusterName),
			tag.Dynamic("stack", string(debug.Stack())),
		)
	}
	return true
}
