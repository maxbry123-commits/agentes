module.exports = {
  apps: [
    {
      name: "back-end",
      script: "dist/server.js",
      cwd: "./packages/back-end",
      instances: 1,
      autorestart: process.env.PM2_AUTORESTART === "true",
      watch: false,
      max_memory_restart: process.env.PM2_MAX_MEMORY_RESTART || "6G",
      ...(process.env.TRACING_PROVIDER === "datadog" && {
        node_args: "--require ./packages/back-end/dist/tracing.datadog.js",
      }),
      ...(process.env.TRACING_PROVIDER === "opentelemetry" && {
        node_args:
          "--require ./packages/back-end/dist/tracing.opentelemetry.js",
      }),
    },
    {
      name: "front-end",
      script: "node_modules/next/dist/bin/next",
      args: "start",
      cwd: "./packages/front-end",
      exec_mode: "fork",
      instances: 1,
      autorestart: process.env.PM2_AUTORESTART === "true",
      watch: false,
      max_memory_restart: process.env.PM2_MAX_MEMORY_RESTART || "6G",
    },
    // Idle monitor for preview environments - shuts down the container after
    // inactivity. Shell-free (reads /proc) so it runs on the distroless image.
    ...(process.env.PREVIEW_IDLE_TIMEOUT_SECONDS
      ? [
          {
            name: "idle-monitor",
            script: "./preview/idle-monitor.js",
            exec_mode: "fork",
            instances: 1,
            autorestart: false,
            watch: false,
          },
        ]
      : []),
  ],
};
