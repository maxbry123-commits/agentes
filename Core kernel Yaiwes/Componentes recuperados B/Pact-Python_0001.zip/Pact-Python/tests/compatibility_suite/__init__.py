"""
Compatibility suite tests.
"""
