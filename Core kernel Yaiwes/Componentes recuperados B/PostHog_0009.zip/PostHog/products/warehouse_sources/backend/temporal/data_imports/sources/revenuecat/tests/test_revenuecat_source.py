from typing import cast

from unittest.mock import MagicMock, patch

import pyarrow as pa

from products.warehouse_sources.backend.temporal.data_imports.pipelines.core.arrow_utils import table_from_py_list
from products.warehouse_sources.backend.temporal.data_imports.sources.common.base import WebhookCreationResult
from products.warehouse_sources.backend.temporal.data_imports.sources.common.typings import SourceResponse
from products.warehouse_sources.backend.temporal.data_imports.sources.generated_configs.revenuecat import (
    RevenueCatSourceConfig,
)
from products.warehouse_sources.backend.temporal.data_imports.sources.revenuecat.constants import (
    CUSTOMER_RESOURCE_NAME,
    EVENT_RESOURCE_NAME,
    RESOURCE_TO_REVENUECAT_EVENT_TYPE,
)
from products.warehouse_sources.backend.temporal.data_imports.sources.revenuecat.settings import (
    REVENUECAT_API_ENDPOINTS,
    REVENUECAT_API_SCHEMA_NAMES,
    REVENUECAT_WEBHOOK_SCHEMA_NAMES,
)
from products.warehouse_sources.backend.temporal.data_imports.sources.revenuecat.source import (
    RevenueCatSource,
    _webhook_table_transformer,
)


def _config(api_key: str = "sk_test", project_id: str = "proj_test") -> RevenueCatSourceConfig:
    return RevenueCatSourceConfig(secret_api_key=api_key, project_id=project_id)


class TestRevenueCatSourceWebhookResourceMap:
    def test_wildcard_funnels_all_events_into_one_table(self):
        source = RevenueCatSource()
        mapping = source.webhook_resource_map

        # Single events table — every webhook delivery is routed here regardless
        # of `event.type`. The wildcard sentinel lets the Hog template skip
        # per-type lookup.
        assert mapping == RESOURCE_TO_REVENUECAT_EVENT_TYPE
        assert mapping[EVENT_RESOURCE_NAME] == "*"


class TestRevenueCatSourceGetSchemas:
    def test_includes_both_webhook_and_api_schemas(self):
        source = RevenueCatSource()

        schemas = source.get_schemas(_config(), team_id=1)

        names = {s.name for s in schemas}
        for name in REVENUECAT_WEBHOOK_SCHEMA_NAMES:
            assert name in names, f"missing webhook schema: {name}"
        for name in REVENUECAT_API_SCHEMA_NAMES:
            assert name in names, f"missing api schema: {name}"

    def test_only_events_schema_supports_webhooks(self):
        source = RevenueCatSource()

        schemas = source.get_schemas(_config(), team_id=1)

        webhook_supported = {s.name for s in schemas if s.supports_webhooks}
        assert webhook_supported == set(REVENUECAT_WEBHOOK_SCHEMA_NAMES)

    def test_filters_by_names_argument(self):
        source = RevenueCatSource()

        schemas = source.get_schemas(_config(), team_id=1, names=["customers", "events"])

        assert {s.name for s in schemas} == {"customers", "events"}


class TestRevenueCatSourceCreateWebhook:
    @patch(
        "products.warehouse_sources.backend.temporal.data_imports.sources.revenuecat.source.api_client.create_webhook"
    )
    def test_delegates_to_api_client_without_authorization_header(self, mock_create):
        mock_create.return_value = WebhookCreationResult(success=True, pending_inputs=["authorization_header"])
        source = RevenueCatSource()

        result = source.create_webhook(_config("k", "p"), "https://example.com/h", team_id=1)

        assert result.success is True
        assert result.pending_inputs == ["authorization_header"]
        mock_create.assert_called_once()
        kwargs = mock_create.call_args.kwargs
        assert kwargs["api_key"] == "k"
        assert kwargs["project_id"] == "p"
        assert kwargs["webhook_url"] == "https://example.com/h"


class TestRevenueCatSourceWebhookInputsUpdated:
    @patch(
        "products.warehouse_sources.backend.temporal.data_imports.sources.revenuecat.source.api_client.delete_webhook"
    )
    @patch(
        "products.warehouse_sources.backend.temporal.data_imports.sources.revenuecat.source.api_client.create_webhook"
    )
    def test_binds_authorization_header_without_deleting_integration(self, mock_create, mock_delete):
        # Binding the header goes through `create_webhook`, which updates the
        # existing integration in place (or creates it fresh if
        # auto-registration failed earlier). A delete + recreate here would
        # drop deliveries in the gap.
        mock_create.return_value = WebhookCreationResult(success=True)
        source = RevenueCatSource()

        success, error = source.webhook_inputs_updated(
            _config("k", "p"),
            "https://example.com/h",
            team_id=1,
            inputs={"authorization_header": "Bearer my-secret"},
        )

        assert success is True
        assert error is None
        mock_delete.assert_not_called()
        mock_create.assert_called_once()
        kwargs = mock_create.call_args.kwargs
        assert kwargs["authorization_header_value"] == "Bearer my-secret"

    @patch(
        "products.warehouse_sources.backend.temporal.data_imports.sources.revenuecat.source.api_client.create_webhook"
    )
    def test_skips_api_call_when_authorization_header_missing(self, mock_create):
        source = RevenueCatSource()

        success, error = source.webhook_inputs_updated(_config(), "https://example.com/h", team_id=1, inputs={})

        assert success is True
        assert error is None
        mock_create.assert_not_called()

    @patch(
        "products.warehouse_sources.backend.temporal.data_imports.sources.revenuecat.source.api_client.create_webhook"
    )
    def test_propagates_bind_failure(self, mock_create):
        mock_create.return_value = WebhookCreationResult(success=False, error="boom")
        source = RevenueCatSource()

        success, error = source.webhook_inputs_updated(
            _config(), "https://example.com/h", team_id=1, inputs={"authorization_header": "x"}
        )

        assert success is False
        assert error == "boom"


class TestRevenueCatSourceSyncWebhookEvents:
    """RevenueCat has no provider-side event subscription to reconcile — it inherits the
    `WebhookSource` defaults, which are a no-op."""

    def test_get_desired_webhook_events_is_none(self):
        source = RevenueCatSource()
        assert source.get_desired_webhook_events(_config("k", "p"), ["events"]) is None

    def test_sync_webhook_events_is_noop_success(self):
        source = RevenueCatSource()
        result = source.sync_webhook_events(
            _config("k", "p"), "https://example.com/h", team_id=1, eligible_schema_names=["events"]
        )
        assert result.success is True
        assert result.error is None


class TestRevenueCatSourcePipelineDispatch:
    @patch(
        "products.warehouse_sources.backend.temporal.data_imports.sources.revenuecat.source.api_client.revenuecat_api_source"
    )
    def test_api_schema_delegates_to_transport_with_config_and_inputs(self, mock_api_source):
        # Resume scoping and pagination now live inside `revenuecat_api_source`; the source just
        # wires the config secret/project and the run's team/job/schema through to it.
        sentinel = cast(SourceResponse, "API_RESPONSE")
        mock_api_source.return_value = sentinel
        source = RevenueCatSource()
        inputs = MagicMock()
        inputs.schema_name = "customers"
        inputs.team_id = 7
        inputs.job_id = "job-1"

        manager = MagicMock()
        response = source.source_for_pipeline(_config("k", "p"), manager, inputs)

        assert response is sentinel
        mock_api_source.assert_called_once()
        kwargs = mock_api_source.call_args.kwargs
        assert kwargs["api_key"] == "k"
        assert kwargs["project_id"] == "p"
        assert kwargs["schema_name"] == "customers"
        assert kwargs["team_id"] == 7
        assert kwargs["job_id"] == "job-1"
        assert kwargs["resumable_source_manager"] is manager

    def test_events_schema_routes_to_webhook_source_response(self):
        source = RevenueCatSource()
        inputs = MagicMock()
        inputs.schema_name = EVENT_RESOURCE_NAME
        inputs.logger = MagicMock()

        sentinel = cast(SourceResponse, "WEBHOOK_RESPONSE")
        with patch.object(source, "_webhook_source_response", return_value=sentinel) as mock_webhook:
            result = source.source_for_pipeline(_config(), MagicMock(), inputs)

        assert result is sentinel
        mock_webhook.assert_called_once_with(inputs)

    def test_every_api_endpoint_partitions_by_stable_timestamp(self):
        # Customers have no `created_at`; they partition by `first_seen_at`. Every
        # other endpoint partitions by `created_at`. Both are stable per row.
        for name, endpoint in REVENUECAT_API_ENDPOINTS.items():
            expected = ["first_seen_at"] if name == CUSTOMER_RESOURCE_NAME else ["created_at"]
            assert endpoint.partition_keys == expected, name
            assert endpoint.primary_keys == ["id"], name


class TestRevenueCatWebhookTableTransformer:
    def test_lifts_event_fields_and_preserves_api_version(self):
        table = table_from_py_list(
            [
                {
                    "api_version": "1.0",
                    "event": {
                        "id": "evt-1",
                        "type": "INITIAL_PURCHASE",
                        "app_user_id": "user-1",
                        "product_id": "com.subscription.weekly",
                        "store": "APP_STORE",
                        "event_timestamp_ms": 1658726374000,
                        "purchased_at_ms": 1658726374000,
                    },
                }
            ]
        )

        result = _webhook_table_transformer(table)
        rows = result.to_pylist()

        assert len(rows) == 1
        assert rows[0]["id"] == "evt-1"
        assert rows[0]["type"] == "INITIAL_PURCHASE"
        assert rows[0]["app_user_id"] == "user-1"
        assert rows[0]["store"] == "APP_STORE"
        assert rows[0]["api_version"] == "1.0"
        # Original ms field preserved unchanged for callers that care about
        # sub-second precision; `created_at` is the derived seconds value used
        # for partitioning.
        assert rows[0]["event_timestamp_ms"] == 1658726374000
        assert rows[0]["created_at"] == 1658726374

    def test_coerces_whole_valued_double_fields_to_float(self):
        # RevenueCat documents these fields as doubles, but whole values arrive as JSON
        # ints. If every row in the batch that creates the Delta table is whole (e.g. $0
        # trials), the column would be locked to int64 and the first fractional price
        # (19.99) would fail every later sync with an Arrow truncation error.
        table = table_from_py_list(
            [
                {
                    "api_version": "1.0",
                    "event": {
                        "id": "evt-1",
                        "type": "INITIAL_PURCHASE",
                        "price": 0,
                        "price_in_purchased_currency": 0,
                        "takehome_percentage": 1,
                        "tax_percentage": 0,
                        "commission_percentage": 0,
                        "discount_percentage": 10,
                        "discount_amount": 0,
                        "renewal_number": 1,
                        "event_timestamp_ms": 1658726374000,
                    },
                },
                {
                    "api_version": "1.0",
                    "event": {"id": "evt-2", "type": "TRANSFER", "price": None},
                },
            ]
        )

        result = _webhook_table_transformer(table)

        for field in (
            "price",
            "price_in_purchased_currency",
            "takehome_percentage",
            "tax_percentage",
            "commission_percentage",
            "discount_percentage",
            "discount_amount",
        ):
            assert result.schema.field(field).type == pa.float64(), field
        # Only the documented double fields are coerced — integer fields stay integers.
        assert result.schema.field("renewal_number").type == pa.int64()
        assert result.schema.field("event_timestamp_ms").type == pa.int64()

        rows = result.to_pylist()
        assert rows[0]["price"] == 0.0
        assert rows[1]["price"] is None

    def test_all_null_double_fields_are_still_typed_as_float(self):
        # A first batch where a double field is null on every row (e.g. TRANSFER events)
        # would otherwise infer a `null` column, which the delta write path stores as
        # string — silently stringifying every later price instead of erroring.
        table = table_from_py_list(
            [
                {"api_version": "1.0", "event": {"id": "evt-1", "type": "TRANSFER", "price": None}},
                {"api_version": "1.0", "event": {"id": "evt-2", "type": "TRANSFER", "price": None}},
            ]
        )

        result = _webhook_table_transformer(table)

        assert result.schema.field("price").type == pa.float64()
        assert result.column("price").to_pylist() == [None, None]

    def test_skips_created_at_derivation_when_event_timestamp_ms_missing(self):
        # Older RevenueCat events or test deliveries may omit the timestamp
        # entirely. Don't synthesize a fake `created_at` value — the partition
        # layer falls back to "1970-01" for missing keys, which is a clearer
        # signal of the missing field than a zero value would be.
        table = table_from_py_list([{"api_version": "1.0", "event": {"id": "evt-1", "type": "TEST"}}])

        result = _webhook_table_transformer(table)
        rows = result.to_pylist()

        assert rows[0]["id"] == "evt-1"
        assert "created_at" not in rows[0]

    def test_handles_event_as_json_string(self):
        # Defensive: if upstream serializes `event` as a JSON string, we still
        # parse it correctly.
        table = pa.table(
            {
                "api_version": ["1.0"],
                "event": ['{"id": "evt-2", "type": "RENEWAL", "app_user_id": "u"}'],
            }
        )

        result = _webhook_table_transformer(table)
        rows = result.to_pylist()

        assert rows == [{"id": "evt-2", "type": "RENEWAL", "app_user_id": "u", "api_version": "1.0"}]

    def test_skips_rows_with_null_event(self):
        table = pa.table(
            {
                "api_version": ["1.0", "1.0"],
                "event": [None, {"id": "evt-4", "type": "RENEWAL"}],
            }
        )

        result = _webhook_table_transformer(table)
        rows = result.to_pylist()

        assert rows == [{"id": "evt-4", "type": "RENEWAL", "api_version": "1.0"}]

    def test_returns_empty_when_event_column_missing(self):
        table = pa.table({"api_version": ["1.0"]})

        result = _webhook_table_transformer(table)

        assert result.num_rows == 0
