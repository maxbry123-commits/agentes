from typing import Optional, cast

from posthog.schema import (
    DataWarehouseSourceCategory,
    ExternalDataSourceType as SchemaExternalDataSourceType,
    ReleaseStatus,
    SourceConfig,
    SourceFieldInputConfig,
    SourceFieldInputConfigType,
    SourceFieldSelectConfig,
    SourceFieldSelectConfigOption,
)

from products.warehouse_sources.backend.temporal.data_imports.sources.common.base import FieldType, ResumableSource
from products.warehouse_sources.backend.temporal.data_imports.sources.common.canonical_descriptions import (
    CanonicalDescriptions,
)
from products.warehouse_sources.backend.temporal.data_imports.sources.common.registry import SourceRegistry
from products.warehouse_sources.backend.temporal.data_imports.sources.common.rest_source.fanout import (
    required_parents_from_endpoint_configs,
)
from products.warehouse_sources.backend.temporal.data_imports.sources.common.resumable import ResumableSourceManager
from products.warehouse_sources.backend.temporal.data_imports.sources.common.schema import SourceSchema
from products.warehouse_sources.backend.temporal.data_imports.sources.common.typings import SourceInputs, SourceResponse
from products.warehouse_sources.backend.temporal.data_imports.sources.generated_configs.sentry import SentrySourceConfig
from products.warehouse_sources.backend.temporal.data_imports.sources.sentry.sentry import (
    STATS_SUMMARY_REJECTED_MESSAGE,
    SentryResumeConfig,
    _normalize_organization_slug,
    sentry_source,
    validate_credentials as validate_sentry_credentials,
)
from products.warehouse_sources.backend.temporal.data_imports.sources.sentry.settings import (
    ALLOWED_SENTRY_API_BASE_URLS,
    DEFAULT_SENTRY_API_BASE_URL,
    ENDPOINTS,
    INCREMENTAL_FIELDS,
    REQUIRED_SENTRY_SCOPES,
    SENTRY_ENDPOINTS,
)
from products.warehouse_sources.backend.types import ExternalDataSourceType


@SourceRegistry.register
class SentrySource(ResumableSource[SentrySourceConfig, SentryResumeConfig]):
    supported_versions = ("0",)
    default_version = "0"
    api_docs_url = "https://docs.sentry.io/api/"

    lists_tables_without_credentials = True  # static endpoint catalog — safe for public docs

    @property
    def source_type(self) -> ExternalDataSourceType:
        return ExternalDataSourceType.SENTRY

    def parse_config(self, job_inputs: dict) -> SentrySourceConfig:
        # Normalize before building the config so both the credential check and the stored
        # job_inputs use the extracted slug. Normalizing only in validate_credentials would let a
        # pasted URL pass validation but persist as the slug, breaking every later sync.
        organization_slug = job_inputs.get("organization_slug")
        if isinstance(organization_slug, str):
            job_inputs = {**job_inputs, "organization_slug": _normalize_organization_slug(organization_slug)}
        return self._config_class.from_dict(job_inputs)

    @property
    def get_source_config(self) -> SourceConfig:
        return SourceConfig(
            name=SchemaExternalDataSourceType.SENTRY,
            category=DataWarehouseSourceCategory.ENGINEERING___MONITORING,
            label="Sentry",
            iconPath="/static/services/sentry.png",
            caption=(
                "Enter a Sentry auth token and your organization slug to sync Sentry organization, "
                "project, issue, and monitor datasets.\n\n"
                "Create a token in Sentry and make sure it includes the scopes below if you want to "
                "sync all datasets:\n" + "\n".join(f"- `{scope}`" for scope in REQUIRED_SENTRY_SCOPES) + "\n"
            ),
            docsUrl="https://posthog.com/docs/cdp/sources/sentry",
            fields=cast(
                list[FieldType],
                [
                    SourceFieldInputConfig(
                        name="auth_token",
                        label="Auth token",
                        type=SourceFieldInputConfigType.PASSWORD,
                        required=True,
                        placeholder="324587...",
                        secret=True,
                    ),
                    SourceFieldInputConfig(
                        name="organization_slug",
                        label="Organization slug",
                        type=SourceFieldInputConfigType.TEXT,
                        required=True,
                        placeholder="my-org",
                        secret=False,
                    ),
                    SourceFieldSelectConfig(
                        name="api_base_url",
                        label="API base URL",
                        required=False,
                        defaultValue=DEFAULT_SENTRY_API_BASE_URL,
                        options=[
                            SourceFieldSelectConfigOption(
                                label=DEFAULT_SENTRY_API_BASE_URL, value=DEFAULT_SENTRY_API_BASE_URL
                            ),
                            SourceFieldSelectConfigOption(label="https://us.sentry.io", value="https://us.sentry.io"),
                            SourceFieldSelectConfigOption(label="https://de.sentry.io", value="https://de.sentry.io"),
                        ],
                    ),
                ],
            ),
            releaseStatus=ReleaseStatus.GA,
        )

    def get_canonical_descriptions(self) -> CanonicalDescriptions:
        from products.warehouse_sources.backend.temporal.data_imports.sources.sentry.canonical_descriptions import (
            CANONICAL_DESCRIPTIONS,
        )

        return CANONICAL_DESCRIPTIONS

    def get_non_retryable_errors(self) -> dict[str, str | None]:
        return {
            "401 Client Error": "Invalid Sentry auth token. Please update your token and reconnect.",
            "403 Client Error": "Sentry token is missing required scopes. Make sure it includes the scopes required for your schemas — the full set is: "
            + ", ".join(REQUIRED_SENTRY_SCOPES)
            + ".",
            "404 Client Error": "Sentry organization not found. Verify your organization slug.",
            # Raised as `SentryStatsSummaryRejectedError` for any stats-summary 400 other than the
            # skipped no-projects case (see sentry.py). Deterministic for the request we build, so
            # stop retrying; the message is defined at the raise site so it stays credential-safe.
            STATS_SUMMARY_REJECTED_MESSAGE: None,
        }

    def get_retryable_errors(self) -> set[str]:
        # `_request_with_retry` (sentry.py) retries dropped connections and read timeouts at the
        # urllib3 level; once that budget is exhausted, urllib3 re-raises with the stable "Max
        # retries exceeded with url" prefix regardless of the underlying cause.
        #
        # HTTP 429s are retried by tenacity (respecting X-Sentry-Rate-Limit-Reset); when that
        # budget is exhausted, `raise_for_status()` raises `HTTPError: 429 Client Error: Too Many
        # Requests`, which does NOT contain the "Max retries exceeded" phrase. Match the stable
        # status-line prefix so persistent rate-limiting lets Temporal retry instead of being
        # reported to error tracking as a bug.
        return {"Max retries exceeded with url", "429 Client Error"}

    def get_required_parent_schemas(self, schema_name: str) -> list[str]:
        # issue_tag_values fans out over issues through its custom two-level iterator, so it
        # carries no DependentEndpointConfig to derive the dependency from.
        if schema_name == "issue_tag_values":
            return ["issues"]
        return required_parents_from_endpoint_configs(SENTRY_ENDPOINTS, schema_name)

    def get_schemas(
        self,
        config: SentrySourceConfig,
        team_id: int,
        with_counts: bool = False,
        names: list[str] | None = None,
        force_refresh: bool = False,
        api_version: str | None = None,
    ) -> list[SourceSchema]:
        schemas: list[SourceSchema] = []
        for endpoint in ENDPOINTS:
            if names and endpoint not in names:
                continue
            incremental_fields = INCREMENTAL_FIELDS.get(endpoint, [])
            supports_incremental = bool(incremental_fields)
            schemas.append(
                SourceSchema(
                    name=endpoint,
                    supports_incremental=supports_incremental,
                    supports_append=supports_incremental,
                    incremental_fields=incremental_fields,
                )
            )
        return schemas

    def validate_credentials(
        self,
        config: SentrySourceConfig,
        team_id: int,
        schema_name: Optional[str] = None,
        api_version: str | None = None,
    ) -> tuple[bool, str | None]:
        api_base_url = config.api_base_url or DEFAULT_SENTRY_API_BASE_URL

        if api_base_url not in ALLOWED_SENTRY_API_BASE_URLS:
            return (
                False,
                "API base URL must be one of https://sentry.io, https://us.sentry.io, or https://de.sentry.io.",
            )

        return validate_sentry_credentials(
            auth_token=config.auth_token,
            organization_slug=config.organization_slug,
            api_base_url=api_base_url,
        )

    def get_resumable_source_manager(self, inputs: SourceInputs) -> ResumableSourceManager[SentryResumeConfig]:
        return ResumableSourceManager[SentryResumeConfig](inputs, SentryResumeConfig)

    def source_for_pipeline(
        self,
        config: SentrySourceConfig,
        resumable_source_manager: ResumableSourceManager[SentryResumeConfig],
        inputs: SourceInputs,
    ) -> SourceResponse:
        return sentry_source(
            auth_token=config.auth_token,
            organization_slug=config.organization_slug,
            api_base_url=config.api_base_url,
            endpoint=inputs.schema_name,
            team_id=inputs.team_id,
            job_id=inputs.job_id,
            resumable_source_manager=resumable_source_manager,
            should_use_incremental_field=inputs.should_use_incremental_field,
            db_incremental_field_last_value=inputs.db_incremental_field_last_value
            if inputs.should_use_incremental_field
            else None,
            incremental_field=inputs.incremental_field,
            source_id=inputs.source_id,
            use_warehouse_parent=inputs.fanout_warehouse_reuse,
        )
