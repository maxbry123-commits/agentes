select * from {{ ref('customers') }}
