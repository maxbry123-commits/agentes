Deprecations
============

.. include:: pending-removal-in-3.17.rst

.. include:: pending-removal-in-3.18.rst

.. include:: pending-removal-in-3.19.rst

.. include:: pending-removal-in-3.20.rst

.. include:: pending-removal-in-3.21.rst

.. include:: pending-removal-in-future.rst

.. include:: soft-deprecations.rst

C API deprecations
------------------

.. include:: c-api-pending-removal-in-3.18.rst

.. include:: c-api-pending-removal-in-3.19.rst

.. include:: c-api-pending-removal-in-3.20.rst

.. include:: c-api-pending-removal-in-future.rst
