"""Semantic conventions for TruLens spans.

This file should not have any dependencies except possibly other semantic
conventions packages so it can be easily imported by tools that want to read
TruLens data but not use TruLens otherwise.

Relevant links:

- [OTEL Semantic Conventions](https://opentelemetry.io/docs/specs/semconv/).

- [OTEL Trace Semantic
  Conventions](https://opentelemetry.io/docs/specs/semconv/general/trace/).

- [OTEL Semantic Conventions for Generative AI
  Systems](https://opentelemetry.io/docs/specs/semconv/gen-ai/).
"""

from enum import Enum

BASE_SCOPE = "ai.observability"

GEN_AI_SCOPE = "gen_ai"


class GenAIAttributes:
    """OTEL GenAI semantic convention attributes.

    These are emitted alongside ``ai.observability.*`` attributes for
    interoperability with the official OpenTelemetry Generative AI
    semantic conventions.

    Only constants present in the linked OpenTelemetry GenAI specification
    belong in this class. TruLens-specific concepts belong under
    :class:`SpanAttributes` instead.

    See: https://opentelemetry.io/docs/specs/semconv/gen-ai/
    """

    class OPERATION:
        """Attributes for a GenAI operation."""

        NAME = GEN_AI_SCOPE + ".operation.name"
        """Name of the GenAI operation (e.g. ``chat``, ``text_completion``)."""

    class REQUEST:
        """Attributes describing the GenAI request."""

        MODEL = GEN_AI_SCOPE + ".request.model"
        """Model name requested by the caller."""

        TEMPERATURE = GEN_AI_SCOPE + ".request.temperature"
        """Sampling temperature requested."""

    class RESPONSE:
        """Attributes describing the GenAI response."""

        MODEL = GEN_AI_SCOPE + ".response.model"
        """Model name that produced the response."""

    class USAGE:
        """Token usage reported by the GenAI provider."""

        INPUT_TOKENS = GEN_AI_SCOPE + ".usage.input_tokens"
        """Number of prompt/input tokens consumed."""

        OUTPUT_TOKENS = GEN_AI_SCOPE + ".usage.output_tokens"
        """Number of completion/output tokens generated."""

    class PROVIDER:
        """Current attribute identifying the GenAI provider."""

        NAME = GEN_AI_SCOPE + ".provider.name"
        """Name of the GenAI provider (e.g. ``openai``)."""

    class SYSTEM:
        """Attributes identifying the GenAI provider/system.

        Note: We use ``gen_ai.system`` (OTEL GenAI spec v1.36.0) rather than
        the newer ``gen_ai.provider.name`` because the OTEL spec transition plan
        states that implementations SHOULD NOT change away from v1.36.0 by
        default. The attribute is accessed as ``GenAIAttributes.SYSTEM.NAME``
        (not ``gen_ai.system.name`` — the inner class name ``SYSTEM`` is just
        a grouping convenience; the actual key is ``gen_ai.system``).
        """

        NAME = GEN_AI_SCOPE + ".system"
        """Name of the GenAI provider (e.g. ``openai``, ``anthropic``)."""

    class RETRIEVAL:
        """Legacy TruLens aliases; not official OTEL GenAI attributes."""

        QUERY_TEXT = GEN_AI_SCOPE + ".retrieval.query.text"
        """Query text used for retrieval."""

        DOCUMENTS = GEN_AI_SCOPE + ".retrieval.documents"
        """Retrieved documents / contexts."""

    class TOOL:
        """Attributes for a tool/function call."""

        NAME = GEN_AI_SCOPE + ".tool.name"
        """Name of the tool being called."""

        CALL_ID = GEN_AI_SCOPE + ".tool.call.id"
        """Provider-assigned identifier for the tool call."""

        CALL_ARGUMENTS = GEN_AI_SCOPE + ".tool.call.arguments"
        """Arguments passed to the tool (JSON-serialised)."""

        CALL_RESULT = GEN_AI_SCOPE + ".tool.call.result"
        """Result returned by the tool (JSON-serialised)."""


class GenAIEvents:
    """OTEL GenAI semantic convention event names and event attribute keys.

    See: https://opentelemetry.io/docs/specs/semconv/gen-ai/gen-ai-events/

    ``CLIENT_INFERENCE_OPERATION_DETAILS`` and its input/output message
    attributes are official OTEL GenAI conventions. Retrieval event constants
    below are legacy TruLens aliases and must not be used for new telemetry.
    """

    CLIENT_INFERENCE_OPERATION_DETAILS = (
        GEN_AI_SCOPE + ".client.inference.operation.details"
    )
    """Span event emitted for GenAI client inference operation details (inputs and outputs)."""

    RETRIEVAL_QUERY = GEN_AI_SCOPE + ".retrieval.query"
    """Span event emitted for retrieval query content."""

    RETRIEVAL_DOCUMENTS = GEN_AI_SCOPE + ".retrieval.documents"
    """Span event emitted for retrieved documents content."""

    # Backward-compatible event name aliases
    PROMPT = CLIENT_INFERENCE_OPERATION_DETAILS
    CHOICE = CLIENT_INFERENCE_OPERATION_DETAILS

    class EventAttributes:
        INPUT_MESSAGES = GEN_AI_SCOPE + ".input.messages"
        """Structured input messages attribute in a ``gen_ai.client.inference.operation.details`` event."""

        OUTPUT_MESSAGES = GEN_AI_SCOPE + ".output.messages"
        """Structured output messages attribute in a ``gen_ai.client.inference.operation.details`` event."""

        ROLE = GEN_AI_SCOPE + ".role"
        """Message role attribute (e.g. ``user``, ``system``, ``assistant``)."""

        FINISH_REASON = GEN_AI_SCOPE + ".finish_reason"
        """Completion finish reason (e.g. ``stop``, ``length``)."""

        QUERY_TEXT = GEN_AI_SCOPE + ".retrieval.query.text"
        """Query text attribute in a retrieval event."""

        DOCUMENTS = GEN_AI_SCOPE + ".retrieval.documents"
        """Retrieved documents attribute in a retrieval event."""

        # Backward-compatible attribute key aliases
        PROMPT_TEXT = GEN_AI_SCOPE + ".input.messages"
        COMPLETION_TEXT = GEN_AI_SCOPE + ".output.messages"


class ResourceAttributes:
    """TruLens application-routing attributes carried on every app span.

    Despite the historical class name, these are ``ai.observability.*``
    extensions rather than standard OpenTelemetry resource attributes.
    """

    APP_ID = BASE_SCOPE + ".app_id"
    """ID of the app that the span belongs to."""

    APP_NAME = BASE_SCOPE + ".app_name"
    """Fully qualified name of the app that the span belongs to."""

    APP_VERSION = BASE_SCOPE + ".app_version"
    """Name of the version that the span belongs to."""


class ServerAttributes:
    """Standard OpenTelemetry server attributes."""

    ADDRESS = "server.address"
    """Server network address."""

    PORT = "server.port"
    """Server network port."""


class ErrorAttributes:
    """Standard OpenTelemetry error attributes."""

    TYPE = "error.type"
    """Error type or class name."""


class SpanAttributes:
    """Names of keys in the attributes field of a span.

    In some cases below, we also include span name or span name prefix.
    """

    SPAN_TYPE = BASE_SCOPE + ".span_type"
    """
    Span type attribute.
    """

    RECORD_ID = BASE_SCOPE + ".record_id"
    """ID of the record that the span belongs to."""

    RUN_NAME = BASE_SCOPE + ".run.name"
    """Name of the run that the span belongs to."""

    INPUT_ID = BASE_SCOPE + ".input_id"
    """ID of the input that the span belongs to."""

    INPUT_RECORDS_COUNT = BASE_SCOPE + ".input_records_count"
    """To track the number of records processed in a run."""

    SPAN_GROUPS = BASE_SCOPE + ".span_groups"
    """List of groups that the span belongs to."""

    CONVERSATION_ID = BASE_SCOPE + ".conversation_id"
    """ID of the conversation that the span belongs to.

    A conversation groups multiple records (app invocations) that belong to
    the same multi-turn interaction. All spans recorded within a context
    manager that has a ``conversation_id`` set will carry this attribute.
    """

    class SpanType(str, Enum):
        """Span type attribute values.

        The root types indicate the process that initiating the tracking of
        spans (either app tracing or feedback evaluation). Call indicates a
        method/function call. App indicates a call by an app method. Cost
        indicates a call with cost tracking. All others are semantic types.

        The first three classes are exclusive but the others can be mixed in
        with each other.

        Attributes relevant to each span type follow.
        """

        # Exclusive types.

        UNKNOWN = "unknown"
        """Unknown span type."""

        RECORD_ROOT = "record_root"
        """Spans as collected by tracing system."""

        NESTED_RECORD_ROOT = "nested_record_root"
        """Root span for a record created by a nested app call."""

        EVAL_ROOT = "eval_root"
        """Feedback function evaluation root span."""

        EVAL = "eval"
        """Feedback function evaluation span information."""

        RETRIEVAL = "retrieval"
        """A retrieval."""

        GENERATION = "generation"
        """A generation call to an LLM."""

        GRAPH_TASK = "graph_task"
        """A graph task function execution."""

        GRAPH_NODE = "graph_node"
        """A graph node execution."""

        WORKFLOW_STEP = "workflow_step"
        """A workflow step execution."""

        AGENT = "agent"
        """An agent execution."""

        TOOL = "tool"
        """A tool/function call execution."""

        RERANKER = "reranking"
        """A reranking operation."""

        MCP = "MCP"
        """A Model Context Protocol (MCP) tool call."""

        GUARDRAIL = "guardrail"
        """A guardrail check execution."""

        EVAL_DECISION = "eval_decision"
        """Lightweight span recording whether a record was sampled for evaluation."""

    class UNKNOWN:
        """Attributes relevant for spans that could not be categorized otherwise."""

        base = BASE_SCOPE + ".unknown"

    class RECORD_ROOT:
        """Attributes for the root span of a record.

        Includes most fields carried over from
        [trulens.core.schema.base.Record][trulens.core.schema.base.Record].
        """

        base = BASE_SCOPE + ".record_root"

        INPUT = base + ".input"
        """Main input to the app."""

        OUTPUT = base + ".output"
        """Main output of the app."""

        ERROR = base + ".error"
        """Main error of the app.

        Exclusive with main output.
        """

        GROUND_TRUTH_OUTPUT = base + ".ground_truth_output"
        """Ground truth of the record."""

    class EVAL_ROOT:
        """Attributes for the root span of a feedback evaluation.

        Includes most of the fields carried over from
        [trulens.core.schema.feedback.FeedbackResult][trulens.core.schema.feedback.FeedbackResult].
        """

        base = BASE_SCOPE + ".eval_root"

        METRIC_NAME = base + ".metric_name"
        """Name of the feedback definition being evaluated."""

        SPAN_GROUP = base + ".span_group"
        """The span group of the inputs to this metric."""

        ARGS_SPAN_ID = base + ".args_metadata.span_id"
        """
        Mapping of argument name to the ID of the span that provided it. Note
        that this is a scope, and not an attribute by itself.

        E.g. If the function has an argument `x` that came from a span with ID
        "abc", then we would have `ARGS_SPAN_ID + ".x"` with value "abc".
        """

        ARGS_SPAN_ATTRIBUTE = base + ".args_metadata.span_attribute"
        """
        Mapping of argument name to the full span attribute name of the span
        that provided it. Note that this is a scope, and not an attribute by
        itself.

        E.g. If the function has an argument `x` that came directly from the
        span attribute "xyz", then we would have `ARGS_SPAN_ATTRIBUTE + ".x"`
        with value "xyz". If a span attribute was not used directly, then this
        is not set.
        """

        ERROR = base + ".error"
        """Error raised during evaluation."""

        SCORE = base + ".score"
        """Score of the evaluation."""

        HIGHER_IS_BETTER = base + ".higher_is_better"
        """Whether higher is better for this feedback function."""

        EXPLANATION = base + ".explanation"
        """Explanation for the score of the evaluation."""

        METADATA = base + ".metadata"
        """Any metadata of the evaluation."""

    class EVAL:
        """Feedback function evaluation span information."""

        base = BASE_SCOPE + ".eval"

        TARGET_RECORD_ID = base + ".target_record_id"
        """Record id of the record being evaluated."""

        EVAL_ROOT_ID = base + ".eval_root_id"
        """Span id for the EVAL_ROOT span this span is under."""

        METRIC_NAME = base + ".metric_name"
        """Name of the feedback definition being evaluated."""

        CRITERIA = base + ".criteria"
        """Criteria for this sub-step."""

        EXPLANATION = base + ".explanation"
        """Explanation for the score for this sub-step."""

        METADATA = base + ".metadata"
        """Any metadata for this sub-step."""

        SCORE = base + ".score"
        """Score for this sub-step."""

        ERROR = base + ".error"
        """Error raised during this sub-step."""

    class COST:
        """Attributes for spans with a cost."""

        base = BASE_SCOPE + ".cost"

        COST = base + ".cost"
        """Cost of the span."""

        CURRENCY = base + ".cost_currency"
        """Currency of the cost."""

        MODEL = base + ".model"
        """Model used that caused any costs."""

        NUM_TOKENS = base + ".num_tokens"
        """Total tokens processed. """

        NUM_PROMPT_TOKENS = base + ".num_prompt_tokens"
        """Number of prompt tokens supplied."""

        NUM_COMPLETION_TOKENS = base + ".num_completion_tokens"
        """Number of completion tokens generated."""

        NUM_REASONING_TOKENS = base + ".num_reasoning_tokens"
        """Number of reasoning tokens generated (for reasoning models)."""

    class CALL:
        """Instrumented method call attributes."""

        base = BASE_SCOPE + ".call"

        FUNCTION = base + ".function"
        """Name of function being tracked."""

        KWARGS = base + ".kwargs"
        """
        Keyword arguments of the function. This is a scope, and not an
        attribute by itself. E.g. If the function has an argument `x` that had
        a value `1`, then we should have an attribute with key `KWARGS + ".x"`
        with value `1`.
        """

        RETURN = base + ".return"
        """Return value of the function if it executed without error."""

        ERROR = base + ".error"
        """Error raised by the function if it executed with an error.

        Serialized using [str][builtins.str].
        """

    class RETRIEVAL:
        """A retrieval."""

        base = BASE_SCOPE + ".retrieval"

        QUERY_TEXT = base + ".query_text"
        """Input text whose related contexts are being retrieved."""

        NUM_CONTEXTS = base + ".num_contexts"
        """The number of contexts requested, not necessarily retrieved."""

        RETRIEVED_CONTEXTS = base + ".retrieved_contexts"
        """The retrieved contexts."""

    class GENERATION:
        """A generation call to an LLM."""

        base = BASE_SCOPE + ".generation"

        IS_STREAMING = base + ".is_streaming"
        """Whether the generation was streamed back incrementally."""

        TIME_TO_FIRST_TOKEN_MS = base + ".time_to_first_token_ms"
        """Milliseconds between issuing the request and receiving the first chunk.

        Only set for streaming generations.
        """

        TOKENS_PER_SECOND = base + ".tokens_per_second"
        """Completion tokens generated per second over the streaming window.

        Measured from the first chunk to the last so that it reflects generation
        throughput rather than including time-to-first-token. Only set for
        streaming generations whose completion token count is known.
        """

        CHUNKS_RECEIVED = base + ".chunks_received"
        """Number of chunks received over the stream."""

    class GRAPH_TASK:
        """A graph task function execution."""

        base = BASE_SCOPE + ".graph_task"

        TASK_NAME = base + ".task_name"
        """Name of the task function."""

        INPUT_STATE = base + ".input_state"
        """Input state to the task."""

        OUTPUT_STATE = base + ".output_state"
        """Output state from the task."""

        ERROR = base + ".error"
        """Error raised during task execution."""

    class GRAPH_NODE:
        """A graph node execution."""

        base = BASE_SCOPE + ".graph_node"

        NODE_NAME = base + ".node_name"
        """Name of the node."""

        INPUT_STATE = base + ".input_state"
        """Input state to the graph."""

        OUTPUT_STATE = base + ".output_state"
        """Output state from the graph."""

        LATEST_MESSAGE = base + ".latest_message"
        """Latest message flowing between nodes."""

        NODES_EXECUTED = base + ".nodes_executed"
        """List of nodes executed in the graph."""

        ERROR = base + ".error"
        """Error raised during graph execution."""

    class WORKFLOW:
        """A workflow execution."""

        base = BASE_SCOPE + ".workflow"

        INPUT_EVENT = base + ".input_event"
        """Input event to the workflow."""

        OUTPUT_EVENT = base + ".output_event"
        """Output event from the workflow."""

        ERROR = base + ".error"
        """Error raised during workflow execution."""

        AGENT_NAME = base + ".agent_name"
        """Name of the agent executing in the workflow."""

    class RERANKER:
        """A reranking operation."""

        base = BASE_SCOPE + ".reranking"

        QUERY_TEXT = base + ".query_text"
        """Query text used for reranking."""

        MODEL_NAME = base + ".model_name"
        """Name of the reranking model."""

        TOP_N = base + ".top_n"
        """Number of top results to return after reranking."""

        INPUT_CONTEXT_TEXTS = base + ".input_context_texts"
        """Input contexts before reranking."""

        INPUT_CONTEXT_SCORES = base + ".input_context_scores"
        """Input scores before reranking."""

        INPUT_RANKS = base + ".input_ranks"
        """Input ranking order before reranking."""

        OUTPUT_RANKS = base + ".output_ranks"
        """Output ranking order after reranking."""

        OUTPUT_CONTEXT_TEXTS = base + ".output_context_texts"
        """Output contexts after reranking."""

        OUTPUT_CONTEXT_SCORES = base + ".output_context_scores"
        """Output scores after reranking."""

    class MCP:
        """TruLens MCP extensions used where OTEL has no MCP convention."""

        base = BASE_SCOPE + ".mcp"

        TOOL_NAME = base + ".tool_name"
        """Name of the MCP tool being called."""

        TOOL_DESCRIPTION = base + ".tool_description"
        """Description of the MCP tool."""

        SERVER_NAME = base + ".server_name"
        """Name of the MCP server providing the tool."""

        INPUT_SCHEMA = base + ".input_schema"
        """Schema of the input parameters for the MCP tool."""

        INPUT_ARGUMENTS = base + ".input_arguments"
        """Arguments passed to the MCP tool."""

        OUTPUT_CONTENT = base + ".output_content"
        """Content returned by the MCP tool."""

        OUTPUT_IS_ERROR = base + ".output_is_error"
        """Whether the MCP tool call resulted in an error."""

        EXECUTION_TIME_MS = base + ".execution_time_ms"
        """Time taken to execute the MCP tool call in milliseconds."""

    class CODING_AGENT:
        """TruLens extensions for coding-agent client instrumentation."""

        base = BASE_SCOPE + ".coding_agent"

        CLIENT = base + ".client"
        """Coding-agent client name, such as Cursor or Claude Code."""

        NATIVE_EVENT = base + ".native_event"
        """Native lifecycle event emitted by the coding-agent client."""

        DIFF = base + ".diff"
        """Source diff or old/new edit pairs captured from an edit event."""

        EDITOR_VERSION = base + ".editor_version"
        """Version of the coding-agent editor or CLI when available."""

        WORKSPACE = base + ".workspace"
        """Workspace path or identifier when path capture is enabled."""

    class GUARDRAIL:
        """Attributes relevant for guardrail check spans."""

        base = BASE_SCOPE + ".guardrail"

        NAME = base + ".name"
        """Name of the guardrail."""

        SCORE = base + ".score"
        """Numeric feedback score returned by the guardrail evaluation."""

        PASSED = base + ".passed"
        """Boolean indicating whether the guardrail check passed."""

        THRESHOLD = base + ".threshold"
        """Configured threshold for the guardrail check."""

    class EVAL_DECISION:
        """Lightweight span recording whether a record was sampled for evaluation.

        One ``EVAL_DECISION`` span is emitted per record that flows through
        the evaluator (both evaluated and skipped), so that
        ``get_records_and_feedback`` can project ``sampled`` /
        ``sample_rate`` / ``eval_decision_reason`` columns and the
        dashboard can show evaluation coverage.
        """

        base = BASE_SCOPE + ".eval_decision"

        SAMPLE_RATE = base + ".sample_rate"
        """The sample_rate that was active when this record was processed."""

        EVAL_DECISION_REASON = base + ".eval_decision_reason"
        """Why this record was or was not evaluated.

        One of: ``evaluated``, ``not_configured``, ``not_sampled``,
        ``throttled``, ``over_budget``.
        """

    class INLINE_EVAL:
        """Attributes specific to inline evaluation instrumentation."""

        base = BASE_SCOPE + ".inline_eval"

        EMIT_SPAN = base + ".emit_span"
        """Boolean flag indicating whether a span should be exported."""

    class NESTED_RECORD_ROOT:
        """Attributes for the root span of a nested record."""

        base = BASE_SCOPE + ".nested_record_root"

        PARENT_SPAN_ID = base + ".parent_span_id"
        """Span ID of the active parent span in the outer app trace."""

        PARENT_APP_ID = base + ".parent_app_id"
        """App ID of the outer app that owns the active parent span."""
