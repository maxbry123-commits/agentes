# langchain-huggingface

[![PyPI - Version](https://img.shields.io/pypi/v/langchain-huggingface?label=%20)](https://pypi.org/project/langchain-huggingface/#history)
[![PyPI - License](https://img.shields.io/pypi/l/langchain-huggingface)](https://opensource.org/licenses/MIT)
[![PyPI - Downloads](https://img.shields.io/pepy/dt/langchain-huggingface)](https://pypistats.org/packages/langchain-huggingface)
[![Twitter](https://img.shields.io/twitter/url/https/twitter.com/langchain_oss.svg?style=social&label=Follow%20%40LangChain)](https://x.com/langchain_oss)

Looking for the JS/TS version? Check out [LangChain.js](https://github.com/langchain-ai/langchainjs).

## Quick Install

```bash
uv add langchain-huggingface
```

> **Note:** The base install does not include `sentence-transformers` or `transformers`.
> If you plan to use `HuggingFaceEmbeddings` or `HuggingFacePipeline` for **local inference**,
> install the `[full]` extra which includes `sentence-transformers>=5.2.0` and `transformers>=5.0.0`:
>
> ```bash
> uv add "langchain-huggingface[full]"
> ```
>
> **Migrating from `langchain-community`?** Note that `langchain-community` accepted
> `sentence-transformers>=2.2.0`, but `langchain-huggingface[full]` requires `>=5.2.0`.
> If your project pins an older version, upgrade it:
>
> ```bash
> uv add "sentence-transformers>=5.2.0"
> ```

## 🤔 What is this?

This package contains the LangChain integrations for Hugging Face related classes.

## 📖 Documentation

For full documentation, see the [API reference](https://reference.langchain.com/python/integrations/langchain_huggingface/). For conceptual guides, tutorials, and examples on using these classes, see the [LangChain Docs](https://docs.langchain.com/oss/python/integrations/providers/huggingface).

## 📕 Releases & Versioning

See our [Releases](https://docs.langchain.com/oss/python/release-policy) and [Versioning](https://docs.langchain.com/oss/python/versioning) policies.

## 💁 Contributing

As an open-source project in a rapidly developing field, we are extremely open to contributions, whether it be in the form of a new feature, improved infrastructure, or better documentation.

For detailed information on how to contribute, see the [Contributing Guide](https://docs.langchain.com/oss/python/contributing/overview).

## Resources

- [LangChain Academy](https://academy.langchain.com/) — comprehensive, free courses on LangChain libraries and products, made by the LangChain team
- [Code of Conduct](https://github.com/langchain-ai/langchain/?tab=coc-ov-file) — community guidelines and standards
