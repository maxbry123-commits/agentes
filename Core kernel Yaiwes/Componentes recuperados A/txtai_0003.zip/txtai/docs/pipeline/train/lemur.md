# LemurTrainer

![pipeline](../../images/pipeline.png#only-light)
![pipeline](../../images/pipeline-dark.png#only-dark)

Trains a LEMUR fixed dimensional encoder for a late interaction model and corpus. Training is a separate pipeline step; the saved
artifact is then loaded through the embeddings `vectors.lemur` configuration.

`LemurTrainer` owns training-data construction, feature-model setup, epoch training and validation-based selection. The loaded LEMUR
pooler remains responsible for query-feature and document-weight encoding.

## Example

```python
from txtai.pipeline import LemurTrainer

corpus = [
    "First document",
    "Second document",
    "Third document",
]

trainer = LemurTrainer()
trainer(
    "colbert-ir/colbertv2.0",
    corpus,
    "lemur-model",
    epochs=100,
    validationsplit=0.1,
)
```

`epochs` is required so the training mode is explicit. Use `epochs=100` for the quality-oriented MLP setting. This can take hours on
a CPU. Use `epochs=0` to select deterministic random ELM features as a lower-cost fallback.

The learn distribution defaults to `learncategory="query"`. Target documents are always encoded with the data encoder, so the
default encodes selected corpus texts once as data and once as queries. Set `learncategory="data"` to reuse the data encodings, or
pass a separate iterable of texts with `learn`.

When `vectors.center` is omitted, the trainer encodes the corpus without centering, computes one mean over all corpus token rows and
uses that mean to center both data and learn vectors before fitting. The collection mean is stored in the LEMUR artifact. An explicit
`vectors.center` setting keeps its configured behavior and does not store an automatic collection mean.

Set `corpussubsetsize` to a positive integer to sample that many raw corpus texts under `seed` before either encoding pass. The
default is `None`, which uses every corpus text. `trainsubsetsize` and `learnsubsetsize` apply later, after token vectors have already
been created. `corpussubsetsize` applies to `data`; a separate `learn` iterable remains caller-sized.

For trained MLP features, set `validationsplit` to a fraction greater than zero and less than one to retain the epoch with the lowest
held-out loss. The default is `0.0`, which preserves training-loss selection. The selected one-based epoch, loss and metric are
available as `selectedepoch`, `selectedloss` and `selectionmetric` on the fitted or reloaded encoder.

MLP training displays a `tqdm` progress bar on an interactive terminal, including percent complete and the current validation loss
when `validationsplit` is enabled (or training loss otherwise). Progress output is disabled for non-interactive runs.

The artifact contains `config.json` and `model.safetensors`. It stores the inference feature model, output-normalization statistics,
token sample needed to encode documents added after training and, by default, the collection token mean. The training-only output
readout is not saved.

Load the artifact in an embeddings configuration.

```yaml
embeddings:
    path: colbert-ir/colbertv2.0
    vectors:
        lemur:
            path: lemur-model
```

## Search behavior

Loading a LEMUR artifact with a stored collection mean automatically centers both query and document token vectors with that mean.
This keeps training and search on the same representation and makes fixed vectors independent of indexing or query batch size. An
explicit `vectors.center` setting takes precedence. Older artifacts without a stored mean use the standard late-pooling fallback:
batch centering for models with multiple linear layers and no centering for models with zero or one linear layer.

LEMUR approximates standardized MaxSim targets, so useful ranking scores can be negative. txtai's dense vector path L2-normalizes the
fixed vectors and removes results with scores less than or equal to zero. This can change ordering and return fewer than the requested
number of candidates compared with raw maximum inner-product search.

The Faiss backend uses exact `IDMap,Flat` search through 5,000 rows and switches to an IVF index above that threshold. In the measured
scifact run, default IVF reduced LEMUR NDCG@10 by 43% relative to exact search, compared with 25% for MUVERA. For LEMUR corpora above
5,000 rows, either pin `faiss.components` to an exact index or tune the IVF settings for the corpus. The exact configuration is:

```yaml
embeddings:
    path: colbert-ir/colbertv2.0
    vectors:
        lemur:
            path: lemur-model
    faiss:
        components: IDMap,Flat
```

## Methods

Python documentation for the pipeline.

### ::: txtai.pipeline.LemurTrainer.__call__
