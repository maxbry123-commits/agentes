"""
Normalize module
"""

# Core library imports
from ..util import Library

np = Library().numpy()


class Normalize:
    """
    Applies score normalization methods.

    Bayesian mode supports BB25-style score calibration aliases ("bayes", "bb25", "bayesian-bm25").
    Reference implementations:
      - https://github.com/instructkr/bb25
      - https://github.com/cognica-io/bayesian-bm25
    """

    def __init__(self, config):
        """
        Creates a new Normalize instance.

        Args:
            config: normalize configuration
        """

        # Normalize settings
        self.config = config if isinstance(config, dict) else {}
        method = self.config.get("method", config if isinstance(config, str) else "default")
        self.method = str(method).lower()

        # Bayesian settings
        self.alpha = float(self.config.get("alpha", 1.0))
        self.beta = self.config.get("beta")
        self.beta = float(self.beta) if self.beta is not None else self.beta

    def isbayes(self):
        """
        Checks if Bayesian normalization mode is active.

        Returns:
            True if using BB25/Bayesian normalization
        """

        return self.method in ("bayes", "bayesian", "bayesian-bm25", "bb25")

    def __call__(self, scores, avgscore):
        """
        Normalizes scores.

        Args:
            scores: list of (id, score)
            avgscore: average score across index

        Returns:
            normalized scores
        """

        return self.bayes(scores) if self.isbayes() else self.default(scores, avgscore)

    def default(self, scores, avgscore):
        """
        Default normalization implementation.

        Args:
            scores: list of (id, score)
            avgscore: average score across index

        Returns:
            normalized scores
        """

        # Use average index score in max score calculation
        maxscore = min(scores[0][1] + avgscore, 6 * avgscore)

        # Normalize scores between 0 - 1 using maxscore
        return [(uid, min(score / maxscore, 1.0)) for uid, score in scores]

    def bayes(self, scores):
        """
        BB25/Bayesian normalization implementation.

        Args:
            scores: list of (id, score)

        Returns:
            normalized scores
        """

        # Convert scores to numpy array
        values = np.array([score for _, score in scores], dtype=np.float32)
        probabilities = np.zeros(values.shape[0], dtype=np.float32)

        # Follow BB25 candidate-set behavior:
        #   - estimate statistics on positive-score candidates only
        #   - assign zero-score candidates a final score of 0.0
        positive = values > 0.0
        if not np.any(positive):
            return [(uid, 0.0) for uid, _ in scores]

        candidates = values[positive]

        # Dynamically derive beta using candidate score distribution, if not configured
        beta = self.beta if self.beta is not None else float(np.median(candidates))

        # Scale alpha by standard deviation for score-range invariance
        std = float(np.std(candidates))
        alpha = abs(self.alpha / std if std > 0 else self.alpha)

        # Compute sigmoid likelihood for positive-score candidates.
        # In this generic normalize flow, term-structure priors (tf/doc length) are not available,
        # so we use the likelihood-only BB25 transform (equivalent to a flat prior of 0.5).
        logits = np.clip(alpha * (candidates - beta), -500, 500)
        probabilities[positive] = 1.0 / (1.0 + np.exp(-logits))
        probabilities = np.clip(probabilities, 0.0, 1.0)

        # Convert back to score tuples
        return [(uid, float(probabilities[x])) for x, (uid, _) in enumerate(scores)]
