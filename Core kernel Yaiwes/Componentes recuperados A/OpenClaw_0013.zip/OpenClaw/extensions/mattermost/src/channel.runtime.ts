// Mattermost plugin module implements channel behavior.
export {
  listMattermostDirectoryGroups,
  listMattermostDirectoryPeers,
} from "./mattermost/directory.js";
export { monitorMattermostProvider } from "./mattermost/monitor.js";
export { probeMattermost } from "./mattermost/probe.js";
export { addMattermostReaction, removeMattermostReaction } from "./mattermost/reactions.js";
export { readMattermostMessages } from "./mattermost/read.js";
export { sendMessageMattermost } from "./mattermost/send.js";
export { resolveMattermostOpaqueTarget } from "./mattermost/target-resolution.js";
