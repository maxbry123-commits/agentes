// Mattermost plugin module implements client behavior.
import { bufferToBlobPart } from "openclaw/plugin-sdk/blob-runtime";
import { createChannelPartialDeliveryError } from "openclaw/plugin-sdk/channel-inbound";
import { collectErrorGraphCandidates } from "openclaw/plugin-sdk/error-runtime";
import { buildTimeoutAbortSignal } from "openclaw/plugin-sdk/extension-shared";
import { responseWithRelease } from "openclaw/plugin-sdk/fetch-runtime";
import { resolveTimerTimeoutMs } from "openclaw/plugin-sdk/number-runtime";
import {
  readProviderJsonResponse,
  readResponseTextLimited,
} from "openclaw/plugin-sdk/provider-http";
import { readResponseWithLimit } from "openclaw/plugin-sdk/response-limit-runtime";
import { retryAsync } from "openclaw/plugin-sdk/retry-runtime";
import {
  fetchWithSsrFGuard,
  ssrfPolicyFromPrivateNetworkOptIn,
} from "openclaw/plugin-sdk/ssrf-runtime";
import {
  normalizeLowercaseStringOrEmpty,
  normalizeOptionalString,
} from "openclaw/plugin-sdk/string-coerce-runtime";
import { z } from "zod";

const MATTERMOST_ERROR_BODY_LIMIT_BYTES = 8 * 1024;
const MATTERMOST_REQUEST_TIMEOUT_MS = 30_000;
// Mattermost REST control-plane JSON (posts, users, channels, file-upload
// results) stays well under a megabyte; cap successful JSON the same way the
// shared provider path is capped so an untrusted/self-hosted homeserver cannot
// stream an unbounded body into the runtime before parsing.
// Non-JSON success bodies are a rare fallback (the API is JSON-first); keep a
// generous text budget but still bound it instead of buffering the whole stream.
const MATTERMOST_TEXT_RESPONSE_LIMIT_BYTES = 64 * 1024;

export type MattermostFetch = (input: RequestInfo | URL, init?: RequestInit) => Promise<Response>;
type MattermostRequestInit = RequestInit & {
  timeoutMs?: number;
};

export type MattermostClient = {
  baseUrl: string;
  apiBaseUrl: string;
  token: string;
  request: <T>(path: string, init?: MattermostRequestInit) => Promise<T>;
  /** Guarded fetch implementation; use in place of raw fetch for outbound requests. */
  fetchImpl: MattermostFetch;
};

export type MattermostUser = {
  id: string;
  username?: string | null;
  nickname?: string | null;
  first_name?: string | null;
  last_name?: string | null;
  update_at?: number;
};

export type MattermostChannel = {
  id: string;
  name?: string | null;
  display_name?: string | null;
  type?: string | null;
  team_id?: string | null;
};

export const MattermostPostSchema = z
  .object({
    id: z.string(),
    user_id: z.string().nullable().optional(),
    channel_id: z.string().nullable().optional(),
    message: z.string().nullable().optional(),
    file_ids: z.array(z.string()).nullable().optional(),
    type: z.string().nullable().optional(),
    root_id: z.string().nullable().optional(),
    create_at: z.number().nullable().optional(),
    props: z.record(z.string(), z.unknown()).nullable().optional(),
  })
  .passthrough();

export type MattermostPost = z.infer<typeof MattermostPostSchema>;

const MattermostPostListSchema = z
  .object({
    order: z.array(z.string()),
    posts: z.record(z.string(), MattermostPostSchema),
    next_post_id: z.string().nullable().optional(),
    prev_post_id: z.string().nullable().optional(),
  })
  .passthrough();

type MattermostFileInfo = {
  id: string;
  name?: string | null;
  mime_type?: string | null;
  size?: number | null;
};

export function parseMattermostApiStatus(error: unknown): number | undefined {
  if (!error || typeof error !== "object") {
    return undefined;
  }
  const message = "message" in error && typeof error.message === "string" ? error.message : "";
  // Read only the provider's status prefix; upstream details can mention other HTTP statuses.
  const match = /Mattermost API (\d{3})\b/.exec(message);
  if (!match) {
    return undefined;
  }
  const status = Number(match[1]);
  return Number.isFinite(status) ? status : undefined;
}

export function normalizeMattermostBaseUrl(raw?: string | null): string | undefined {
  const trimmed = raw?.trim();
  if (!trimmed) {
    return undefined;
  }
  const withoutTrailing = trimmed.replace(/\/+$/, "");
  return withoutTrailing.replace(/\/api\/v4$/i, "");
}

export function buildMattermostApiUrl(baseUrl: string, path: string): string {
  const normalized = normalizeMattermostBaseUrl(baseUrl);
  if (!normalized) {
    throw new Error("Mattermost baseUrl is required");
  }
  const pathname = (path.split(/[?#]/, 1)[0] ?? "").replace(/[\t\r\n]/g, "").replace(/\\/g, "/");
  for (const segment of pathname.split("/")) {
    let decoded: string;
    try {
      decoded = decodeURIComponent(segment).replace(/[\t\r\n]/g, "");
    } catch {
      throw new Error("Mattermost API path must not contain unsafe path segments");
    }
    if (decoded.split(/[\\/]/).some((part) => part === "." || part === "..")) {
      throw new Error("Mattermost API path must not contain unsafe path segments");
    }
  }
  const suffix = path.startsWith("/") ? path : `/${path}`;
  return `${normalized}/api/v4${suffix}`;
}

async function readMattermostSuccessText(res: Response, path: string): Promise<string> {
  const bytes = await readResponseWithLimit(res, MATTERMOST_TEXT_RESPONSE_LIMIT_BYTES, {
    onOverflow: ({ maxBytes }) =>
      new Error(`Mattermost API ${path}: text response exceeds ${maxBytes} bytes`),
  });
  return new TextDecoder().decode(bytes);
}

export async function readMattermostError(res: Response): Promise<string> {
  const contentType = res.headers.get("content-type") ?? "";
  const text = await readResponseTextLimited(res, MATTERMOST_ERROR_BODY_LIMIT_BYTES);
  if (contentType.includes("application/json")) {
    try {
      const data = JSON.parse(text) as { message?: string } | undefined;
      if (data?.message) {
        return data.message;
      }
      return JSON.stringify(data);
    } catch {
      return text;
    }
  }
  return text;
}

export function createMattermostClient(params: {
  baseUrl: string;
  botToken: string;
  fetchImpl?: MattermostFetch;
  /** Timeout for REST requests in milliseconds (default: 30000). */
  timeoutMs?: number;
  /** Allow requests to private/internal IPs (self-hosted/LAN deployments). */
  allowPrivateNetwork?: boolean;
}): MattermostClient {
  const baseUrl = normalizeMattermostBaseUrl(params.baseUrl);
  if (!baseUrl) {
    throw new Error("Mattermost baseUrl is required");
  }
  const apiBaseUrl = `${baseUrl}/api/v4`;
  const token = params.botToken.trim();
  const requestTimeoutMs = resolveTimerTimeoutMs(params.timeoutMs, MATTERMOST_REQUEST_TIMEOUT_MS);
  // When no custom fetchImpl is provided (production path), use an SSRF-guarded wrapper
  // that validates the target URL before making the request (DNS rebinding protection etc.).
  // A custom fetchImpl is accepted for testing and special cases.
  const externalFetchImpl = params.fetchImpl;

  const guardedFetchImpl = async (
    input: RequestInfo | URL,
    init?: MattermostRequestInit,
  ): Promise<Response> => {
    const url =
      typeof input === "string" ? input : input instanceof URL ? input.toString() : input.url;
    const { timeoutMs: initTimeoutMs, ...requestInit } = init ?? {};
    const timeoutMs = resolveTimerTimeoutMs(initTimeoutMs, requestTimeoutMs);
    const { response, release } = await fetchWithSsrFGuard({
      url,
      init: requestInit,
      auditContext: "mattermost-api",
      policy: ssrfPolicyFromPrivateNetworkOptIn(params.allowPrivateNetwork),
      signal: requestInit.signal ?? undefined,
      timeoutMs,
    });
    return responseWithRelease(response, release);
  };

  const timedExternalFetchImpl:
    | ((input: RequestInfo | URL, init?: MattermostRequestInit) => Promise<Response>)
    | undefined = externalFetchImpl
    ? async (input, init) => {
        const url =
          typeof input === "string" ? input : input instanceof URL ? input.toString() : input.url;
        const { timeoutMs: initTimeoutMs, ...requestInit } = init ?? {};
        const timeoutMs = resolveTimerTimeoutMs(initTimeoutMs, requestTimeoutMs);
        const { signal: timeoutSignal, cleanup } = buildTimeoutAbortSignal({
          timeoutMs,
          operation: "mattermost-api",
          url,
        });
        const callerSignal = requestInit.signal ?? undefined;
        const signal =
          callerSignal && timeoutSignal
            ? AbortSignal.any([callerSignal, timeoutSignal])
            : (callerSignal ?? timeoutSignal);
        try {
          const response = await externalFetchImpl(input, { ...requestInit, signal });
          // Match guarded production fetches: retain cancellation and the
          // request deadline until the custom response body is consumed.
          return responseWithRelease(response, async () => cleanup());
        } catch (error) {
          cleanup();
          throw error;
        }
      }
    : undefined;

  const fetchImpl = timedExternalFetchImpl ?? guardedFetchImpl;

  const request = async <T>(path: string, init?: MattermostRequestInit): Promise<T> => {
    const url = buildMattermostApiUrl(baseUrl, path);
    const headers = new Headers(init?.headers);
    headers.set("Authorization", `Bearer ${token}`);
    if (typeof init?.body === "string" && !headers.has("Content-Type")) {
      headers.set("Content-Type", "application/json");
    }
    const res = await fetchImpl(url, { ...init, headers });
    if (!res.ok) {
      const detail = await readMattermostError(res);
      throw new Error(
        `Mattermost API ${res.status} ${res.statusText}: ${detail || "unknown error"}`,
      );
    }

    if (res.status === 204) {
      return undefined as T;
    }

    try {
      const contentType = res.headers.get("content-type") ?? "";
      if (contentType.includes("application/json")) {
        return await readProviderJsonResponse<T>(res, `Mattermost API ${path}`);
      }
      return (await readMattermostSuccessText(res, path)) as T;
    } catch (error) {
      if (path === "/posts" && init?.method?.toUpperCase() === "POST") {
        // POST already succeeded; a lost/unreadable receipt must never schedule another visible post.
        throw createChannelPartialDeliveryError(error, { messageIds: [], visibleReplySent: true });
      }
      throw error;
    }
  };

  return { baseUrl, apiBaseUrl, token, request, fetchImpl };
}

export async function fetchMattermostMe(client: MattermostClient): Promise<MattermostUser> {
  return await client.request<MattermostUser>("/users/me");
}

export async function fetchMattermostUser(
  client: MattermostClient,
  userId: string,
): Promise<MattermostUser> {
  return await client.request<MattermostUser>(`/users/${userId}`);
}

export async function fetchMattermostUserByUsername(
  client: MattermostClient,
  username: string,
): Promise<MattermostUser> {
  return await client.request<MattermostUser>(`/users/username/${encodeURIComponent(username)}`);
}

export async function fetchMattermostChannel(
  client: MattermostClient,
  channelId: string,
): Promise<MattermostChannel> {
  return await client.request<MattermostChannel>(`/channels/${encodeURIComponent(channelId)}`);
}

export async function fetchMattermostChannelPosts(
  client: MattermostClient,
  channelId: string,
  options: {
    limit?: number;
    before?: string;
    after?: string;
  } = {},
): Promise<{ messages: MattermostPost[]; hasMore: boolean }> {
  const before = normalizeOptionalString(options.before);
  const after = normalizeOptionalString(options.after);
  if (before && after) {
    throw new Error("Mattermost read accepts either before or after, not both.");
  }

  if (options.limit !== undefined && (!Number.isSafeInteger(options.limit) || options.limit <= 0)) {
    throw new Error("Mattermost read limit must be a positive integer.");
  }
  const perPage = Math.min(options.limit ?? 60, 200);
  const query = new URLSearchParams({ per_page: String(perPage) });
  if (before) {
    query.set("before", before);
  }
  if (after) {
    query.set("after", after);
  }
  const response = await client.request<unknown>(
    `/channels/${encodeURIComponent(channelId)}/posts?${query.toString()}`,
  );
  const parsed = MattermostPostListSchema.safeParse(response);
  if (!parsed.success || parsed.data.order.some((postId) => !parsed.data.posts[postId])) {
    throw new Error("Unexpected Mattermost channel posts response.");
  }

  return {
    messages: parsed.data.order.map((postId) => parsed.data.posts[postId] as MattermostPost),
    // Mattermost returns the cursor for the opposite direction as well. For
    // descending/default and `before` reads, `prev_post_id` points to older
    // posts; for `after` reads, `next_post_id` points to newer posts.
    hasMore: Boolean(after ? parsed.data.next_post_id : parsed.data.prev_post_id),
  };
}

export async function fetchMattermostChannelByName(
  client: MattermostClient,
  teamId: string,
  channelName: string,
): Promise<MattermostChannel> {
  return await client.request<MattermostChannel>(
    `/teams/${teamId}/channels/name/${encodeURIComponent(channelName)}`,
  );
}

export async function sendMattermostTyping(
  client: MattermostClient,
  params: { channelId: string; parentId?: string },
): Promise<void> {
  const payload: Record<string, string> = {
    channel_id: params.channelId,
  };
  const parentId = params.parentId?.trim();
  if (parentId) {
    payload.parent_id = parentId;
  }
  await client.request<Record<string, unknown>>("/users/me/typing", {
    method: "POST",
    body: JSON.stringify(payload),
  });
}

async function createMattermostDirectChannel(
  client: MattermostClient,
  userIds: string[],
  signal?: AbortSignal,
  timeoutMs?: number,
): Promise<MattermostChannel> {
  return await client.request<MattermostChannel>("/channels/direct", {
    method: "POST",
    body: JSON.stringify(userIds),
    signal,
    timeoutMs,
  });
}

export type CreateDmChannelRetryOptions = {
  /** Maximum number of retry attempts (default: 3) */
  maxRetries?: number;
  /** Initial delay in milliseconds (default: 1000) */
  initialDelayMs?: number;
  /** Maximum delay in milliseconds (default: 10000) */
  maxDelayMs?: number;
  /** Timeout for each individual request in milliseconds (default: 30000) */
  timeoutMs?: number;
  /** Optional logger for retry events */
  onRetry?: (attempt: number, delayMs: number, error: Error) => void;
};

const RETRYABLE_NETWORK_ERROR_CODES = new Set([
  "ECONNRESET",
  "ECONNREFUSED",
  "ETIMEDOUT",
  "ESOCKETTIMEDOUT",
  "ECONNABORTED",
  "ENOTFOUND",
  "EAI_AGAIN",
  "EHOSTUNREACH",
  "ENETUNREACH",
  "EPIPE",
  "UND_ERR_CONNECT_TIMEOUT",
  "UND_ERR_DNS_RESOLVE_FAILED",
  "UND_ERR_CONNECT",
  "UND_ERR_SOCKET",
  "UND_ERR_HEADERS_TIMEOUT",
  "UND_ERR_BODY_TIMEOUT",
]);

const RETRYABLE_NETWORK_ERROR_NAMES = new Set([
  "AbortError",
  "TimeoutError",
  "ConnectTimeoutError",
  "HeadersTimeoutError",
  "BodyTimeoutError",
]);

const RETRYABLE_NETWORK_MESSAGE_SNIPPETS = [
  "network error",
  "timeout",
  "timed out",
  "abort",
  "connection refused",
  "econnreset",
  "econnrefused",
  "etimedout",
  "enotfound",
  "socket hang up",
  "getaddrinfo",
];

/**
 * Creates a Mattermost DM channel with exponential backoff retry logic.
 * Retries on transient errors (429, 5xx, network errors) but not on
 * client errors (4xx except 429) or permanent failures.
 */
export async function createMattermostDirectChannelWithRetry(
  client: MattermostClient,
  userIds: string[],
  options: CreateDmChannelRetryOptions = {},
): Promise<MattermostChannel> {
  const {
    maxRetries = 3,
    initialDelayMs = 1000,
    maxDelayMs = 10000,
    timeoutMs: rawTimeoutMs = 30000,
    onRetry,
  } = options;
  const timeoutMs = resolveTimerTimeoutMs(rawTimeoutMs, 30000);

  return await retryAsync(
    async () => {
      // Use AbortController for per-request timeout
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), timeoutMs);
      try {
        return await createMattermostDirectChannel(client, userIds, controller.signal, timeoutMs);
      } catch (err) {
        // Normalize before rethrowing so shouldRetry/onRetry below always see Errors.
        throw err instanceof Error ? err : new Error(String(err));
      } finally {
        clearTimeout(timeoutId);
      }
    },
    {
      attempts: maxRetries + 1,
      // Core retry raises maxDelayMs to the minDelayMs floor, but the schema
      // allows initialDelayMs above the (defaulted) maxDelayMs cap. The cap is
      // the documented contract here, so clamp the base instead of letting
      // the floor win.
      minDelayMs: Math.min(initialDelayMs, maxDelayMs),
      maxDelayMs,
      // Full jitter (uniform [delay, 2*delay) with maxDelayMs applied after
      // the draw) preserves the schedule pinned by client.retry.test.ts.
      jitter: "full",
      shouldRetry: (err) => isRetryableError(err as Error),
      onRetry: (info) => onRetry?.(info.attempt, info.delayMs, info.err as Error),
    },
  );
}

function isRetryableError(error: Error): boolean {
  const candidates = collectErrorGraphCandidates(error, (current) => [
    current.cause,
    current.reason,
    ...(Array.isArray(current.errors) ? current.errors : []),
  ]);
  const messages = candidates
    .map((candidate) => normalizeLowercaseStringOrEmpty(readErrorMessage(candidate)))
    .filter((message): message is string => Boolean(message));

  // Retry on 5xx server errors FIRST (before checking 4xx)
  // Use "mattermost api" prefix to avoid matching port numbers (e.g., :443) or IP octets
  // This prevents misclassification when a 5xx error detail contains a 4xx substring
  // e.g., "Mattermost API 503: upstream returned 404"
  if (messages.some((message) => /mattermost api 5\d{2}\b/.test(message))) {
    return true;
  }

  // Check for explicit 429 rate limiting FIRST (before generic "429" text match)
  // This avoids retrying when error detail contains "429" but it's not the status code
  if (
    messages.some(
      (message) => /mattermost api 429\b/.test(message) || message.includes("too many requests"),
    )
  ) {
    return true;
  }

  // Check for explicit 4xx status codes - these are client errors and should NOT be retried
  // (except 429 which is handled above)
  // Use "mattermost api" prefix to avoid matching port numbers like :443
  for (const message of messages) {
    const clientErrorMatch = message.match(/mattermost api (4\d{2})\b/);
    if (!clientErrorMatch) {
      continue;
    }
    const statusCodeText = clientErrorMatch[1];
    if (!statusCodeText) {
      continue;
    }
    const statusCode = Number.parseInt(statusCodeText, 10);
    if (statusCode >= 400 && statusCode < 500) {
      return false;
    }
  }

  // Retry on network/transient errors only if no explicit Mattermost API status code is present
  // This avoids false positives like:
  // - "400 Bad Request: connection timed out" (has status code)
  // - "connect ECONNRESET 104.18.32.10:443" (has port number, not status)
  const hasMattermostApiStatusCode = messages.some((message) =>
    /mattermost api \d{3}\b/.test(message),
  );
  if (hasMattermostApiStatusCode) {
    return false;
  }

  const codes: string[] = [];
  for (const candidate of candidates) {
    const code = readErrorCode(candidate);
    if (code) {
      codes.push(code);
    }
  }
  if (codes.some((code) => RETRYABLE_NETWORK_ERROR_CODES.has(code))) {
    return true;
  }

  const names: string[] = [];
  for (const candidate of candidates) {
    const name = readErrorName(candidate);
    if (name) {
      names.push(name);
    }
  }
  if (names.some((name) => RETRYABLE_NETWORK_ERROR_NAMES.has(name))) {
    return true;
  }

  return messages.some((message) =>
    RETRYABLE_NETWORK_MESSAGE_SNIPPETS.some((pattern) => message.includes(pattern)),
  );
}

function readErrorMessage(error: unknown): string | undefined {
  if (!error || typeof error !== "object") {
    return undefined;
  }
  const message = (error as { message?: unknown }).message;
  return typeof message === "string" && message.trim() ? message : undefined;
}

function readErrorName(error: unknown): string | undefined {
  if (!error || typeof error !== "object") {
    return undefined;
  }
  const name = (error as { name?: unknown }).name;
  return typeof name === "string" && name.trim() ? name : undefined;
}

function readErrorCode(error: unknown): string | undefined {
  if (!error || typeof error !== "object") {
    return undefined;
  }
  const { code, errno } = error as {
    code?: unknown;
    errno?: unknown;
  };
  const raw = typeof code === "string" && code.trim() ? code : errno;
  if (typeof raw === "string" && raw.trim()) {
    return raw.trim().toUpperCase();
  }
  if (typeof raw === "number" && Number.isFinite(raw)) {
    return String(raw);
  }
  return undefined;
}

export async function createMattermostPost(
  client: MattermostClient,
  params: {
    channelId: string;
    message: string;
    rootId?: string;
    fileIds?: string[];
    props?: Record<string, unknown>;
  },
): Promise<MattermostPost> {
  const payload: Record<string, unknown> = {
    channel_id: params.channelId,
    message: params.message,
  };
  if (params.rootId) {
    payload.root_id = params.rootId;
  }
  if (params.fileIds?.length) {
    payload.file_ids = params.fileIds;
  }
  if (params.props) {
    payload.props = params.props;
  }
  const post = await client.request<MattermostPost>("/posts", {
    method: "POST",
    body: JSON.stringify(payload),
  });
  const postId = post && typeof post === "object" ? normalizeOptionalString(post.id) : undefined;
  if (!postId) {
    // Successful POST may already be visible; retrying because its receipt is malformed duplicates it.
    throw createChannelPartialDeliveryError(
      new Error("Mattermost post creation response did not include a post id"),
      { messageIds: [], visibleReplySent: true },
    );
  }
  return postId === post.id ? post : { ...post, id: postId };
}

type MattermostTeam = {
  id: string;
  name?: string | null;
  display_name?: string | null;
};

export async function fetchMattermostUserTeams(
  client: MattermostClient,
  userId: string,
): Promise<MattermostTeam[]> {
  return await client.request<MattermostTeam[]>(`/users/${userId}/teams`);
}

export async function updateMattermostPost(
  client: MattermostClient,
  postId: string,
  params: {
    message?: string;
    props?: Record<string, unknown>;
  },
): Promise<MattermostPost> {
  const payload: Record<string, unknown> = { id: postId };
  if (params.message !== undefined) {
    payload.message = params.message;
  }
  if (params.props !== undefined) {
    payload.props = params.props;
  }
  return await client.request<MattermostPost>(`/posts/${postId}`, {
    method: "PUT",
    body: JSON.stringify(payload),
  });
}

export async function deleteMattermostPost(
  client: MattermostClient,
  postId: string,
): Promise<void> {
  await client.request<void>(`/posts/${postId}`, {
    method: "DELETE",
  });
}

export async function uploadMattermostFile(
  client: MattermostClient,
  params: {
    channelId: string;
    buffer: Buffer;
    fileName: string;
    contentType?: string;
  },
): Promise<MattermostFileInfo> {
  const form = new FormData();
  const fileName = normalizeOptionalString(params.fileName) ?? "upload";
  const blob = new Blob([bufferToBlobPart(params.buffer)], { type: params.contentType });
  form.append("files", blob, fileName);
  form.append("channel_id", params.channelId);

  const res = await client.fetchImpl(`${client.apiBaseUrl}/files`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${client.token}`,
    },
    body: form,
  });

  if (!res.ok) {
    const detail = await readMattermostError(res);
    throw new Error(`Mattermost API ${res.status} ${res.statusText}: ${detail || "unknown error"}`);
  }
  const data = await readProviderJsonResponse<{ file_infos?: MattermostFileInfo[] }>(
    res,
    "Mattermost API /files",
  );
  const info = data.file_infos?.[0];
  if (!info?.id) {
    throw new Error("Mattermost file upload failed");
  }
  return info;
}
