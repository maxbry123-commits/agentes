// Mattermost API module exposes the plugin public contract.
export type {
  BaseProbeResult,
  ChannelAccountSnapshot,
  ChannelDirectoryEntry,
  ChatType,
  HistoryEntry,
  OpenClawConfig,
  OpenClawPluginApi,
  ReplyPayload,
} from "openclaw/plugin-sdk/core";
export type { RuntimeEnv } from "openclaw/plugin-sdk/runtime";
export { resolveAllowlistMatchSimple } from "openclaw/plugin-sdk/allow-from";
export { logInboundDrop } from "openclaw/plugin-sdk/channel-inbound";
export { createChannelPairingController } from "openclaw/plugin-sdk/channel-pairing";
export { createChannelMessageReplyPipeline } from "openclaw/plugin-sdk/channel-outbound";
export { logTypingFailure } from "openclaw/plugin-sdk/channel-feedback";
export { listSkillCommandsForAgents } from "openclaw/plugin-sdk/command-auth-native";
export { buildPreparedModelsProviderData } from "openclaw/plugin-sdk/models-provider-runtime";
export { isDangerousNameMatchingEnabled } from "openclaw/plugin-sdk/dangerous-name-runtime";
export {
  resolveAllowlistProviderRuntimeGroupPolicy,
  resolveDefaultGroupPolicy,
  warnMissingProviderGroupPolicyFallbackOnce,
} from "openclaw/plugin-sdk/runtime-group-policy";
export { resolveChannelMediaMaxBytes } from "openclaw/plugin-sdk/account-helpers";
export { loadOutboundMediaFromUrl } from "openclaw/plugin-sdk/outbound-media";
// Legacy map-helper exports stay for older plugin consumers. New message-turn
// code should use createChannelHistoryWindow.
export {
  DEFAULT_GROUP_HISTORY_LIMIT,
  createChannelHistoryWindow,
} from "openclaw/plugin-sdk/reply-history";
export { registerPluginHttpRoute } from "openclaw/plugin-sdk/webhook-targets";
export {
  isRequestBodyLimitError,
  readRequestBodyWithLimit,
} from "openclaw/plugin-sdk/webhook-ingress";
export { isTrustedProxyAddress, resolveClientIp } from "openclaw/plugin-sdk/core";
