// Whatsapp tests cover group gating.allowlist warn plugin behavior.
import { describe, expect, it, vi } from "vitest";

vi.mock("./group-activation.js", () => ({
  resolveGroupActivationFor: vi.fn(async () => "mention"),
}));

import { createTestWebInboundMessage } from "../../inbound/test-message.test-helper.js";
import type { AdmittedWebInboundMessage } from "../../inbound/types.js";
import type { MentionConfig } from "../mentions.js";
import { applyGroupGating, type GroupHistoryEntry } from "./group-gating.js";

function makeUnregisteredGroupMsg(
  conversationId: string,
  accountId = "default",
): AdmittedWebInboundMessage {
  return createTestWebInboundMessage({
    event: {
      id: `msg-${conversationId}`,
      timestamp: 1700000000,
    },
    payload: {
      body: "@openclaw hello",
    },
    platform: {
      chatJid: conversationId,
      recipientJid: "+15550000001",
      sender: { e164: "+15550000002", name: "Alice" },
    },
    admission: {
      accountId,
      conversation: {
        kind: "group",
        id: conversationId,
      },
      sender: {
        id: "+15550000002",
      },
      senderAccess: {
        reasonCode: "group_policy_allowed",
      },
    },
  });
}

type WarnLogger = (obj: unknown, msg: string) => void;
type ApplyGroupGatingParams = Parameters<typeof applyGroupGating>[0];

function makeParams(
  msg: AdmittedWebInboundMessage,
  warn: WarnLogger,
  cfg: ApplyGroupGatingParams["cfg"] = {
    channels: {
      whatsapp: {
        groupPolicy: "allowlist",
        groups: {
          "registered@g.us": {},
        },
        accounts: {
          work: {
            groupPolicy: "allowlist",
            groups: {
              "registered@g.us": {},
            },
          },
        },
      },
    },
    messages: {
      groupChat: {
        mentionPatterns: ["\\bopenclaw\\b"],
      },
    },
  } as never,
) {
  const admission = msg.admission;
  if (!admission) {
    throw new Error("Expected admitted WhatsApp test message");
  }
  return {
    cfg,
    msg,
    groupHistoryKey: `whatsapp:group:${admission.conversation.id}`,
    agentId: "main",
    sessionKey: `agent:main:whatsapp:group:${admission.conversation.id}`,
    baseMentionConfig: { mentionRegexes: [/\bopenclaw\b/i] } satisfies MentionConfig,
    groupHistories: new Map<string, GroupHistoryEntry[]>(),
    groupHistoryLimit: 20,
    groupMemberNames: new Map<string, Map<string, string>>(),
    logVerbose: vi.fn(),
    replyLogger: { debug: vi.fn(), warn },
  };
}

describe("applyGroupGating allowlist drop warning", () => {
  it.each([
    {
      name: "emits a warn log naming the root groups path for the default account",
      conversationId: "root-unregistered@g.us",
      accountId: "default",
      groupsPath: "channels.whatsapp.groups",
      cfg: undefined,
      verboseMessage:
        'Dropping message from unregistered WhatsApp group root-unregistered@g.us. Add the group JID to channels.whatsapp.groups, or add "*" there to admit all groups. Sender authorization still applies.',
    },
    {
      name: "names the account-scoped groups path for non-default accounts",
      conversationId: "work-unregistered@g.us",
      accountId: "work",
      groupsPath: "channels.whatsapp.accounts.work.groups",
      cfg: undefined,
      verboseMessage: undefined,
    },
    {
      name: "names the root groups path for non-default accounts inheriting root groups",
      conversationId: "inherited-unregistered@g.us",
      accountId: "work",
      groupsPath: "channels.whatsapp.groups",
      cfg: {
        channels: {
          whatsapp: {
            groupPolicy: "allowlist",
            groups: { "registered@g.us": {} },
            accounts: { work: { groupPolicy: "allowlist" } },
          },
        },
        messages: { groupChat: { mentionPatterns: ["\\bopenclaw\\b"] } },
      } as ApplyGroupGatingParams["cfg"],
      verboseMessage: undefined,
    },
  ])("$name", async ({ conversationId, accountId, groupsPath, cfg, verboseMessage }) => {
    const warn = vi.fn<WarnLogger>();
    const msg = makeUnregisteredGroupMsg(conversationId, accountId);
    const params = makeParams(msg, warn, cfg);

    await expect(applyGroupGating(params)).resolves.toEqual({ shouldProcess: false });

    expect(warn).toHaveBeenCalledTimes(1);
    if (verboseMessage) {
      expect(params.logVerbose).toHaveBeenCalledWith(verboseMessage);
    }
    const [context, message] = warn.mock.calls[0] ?? [];
    expect(context).toMatchObject({ conversationId, accountId, groupsPath });
    expect(message).toContain(conversationId);
    expect(message).toContain(groupsPath);
  });

  it("warns once but keeps verbose diagnostics per dropped message", async () => {
    const warn = vi.fn<WarnLogger>();
    const first = makeParams(makeUnregisteredGroupMsg("loud@g.us"), warn);
    const second = makeParams(makeUnregisteredGroupMsg("loud@g.us"), warn);
    const third = makeParams(makeUnregisteredGroupMsg("loud@g.us"), warn);

    await applyGroupGating(first);
    await applyGroupGating(second);
    await applyGroupGating(third);

    expect(warn).toHaveBeenCalledTimes(1);
    expect(warn.mock.calls[0]?.[1]).toContain("loud@g.us");
    expect(first.logVerbose).toHaveBeenCalledTimes(1);
    expect(second.logVerbose).toHaveBeenCalledTimes(1);
    expect(third.logVerbose).toHaveBeenCalledTimes(1);
  });

  it("warns separately for distinct conversations", async () => {
    const warn = vi.fn<WarnLogger>();

    await applyGroupGating(makeParams(makeUnregisteredGroupMsg("a@g.us"), warn));
    await applyGroupGating(makeParams(makeUnregisteredGroupMsg("b@g.us"), warn));

    expect(warn).toHaveBeenCalledTimes(2);
    expect(warn.mock.calls[0]?.[1]).toContain("a@g.us");
    expect(warn.mock.calls[1]?.[1]).toContain("b@g.us");
  });

  it("bounds warning keys by least-recently-used conversations", async () => {
    const warn = vi.fn<WarnLogger>();
    const apply = (conversationId: string) =>
      applyGroupGating(makeParams(makeUnregisteredGroupMsg(conversationId), warn));

    for (let index = 0; index < 100; index += 1) {
      await apply(`lru-${index}@g.us`);
    }
    await apply("lru-0@g.us");
    await apply("lru-100@g.us");
    await apply("lru-0@g.us");
    await apply("lru-1@g.us");
    await apply("lru-100@g.us");

    expect(warn).toHaveBeenCalledTimes(102);
    expect(warn.mock.calls[100]?.[1]).toContain("lru-100@g.us");
    expect(warn.mock.calls[101]?.[1]).toContain("lru-1@g.us");
  });

  it("does not warn when the group is registered", async () => {
    const warn = vi.fn<WarnLogger>();
    const msg = makeUnregisteredGroupMsg("registered@g.us");

    await applyGroupGating(makeParams(msg, warn));

    expect(warn).not.toHaveBeenCalled();
  });
});
