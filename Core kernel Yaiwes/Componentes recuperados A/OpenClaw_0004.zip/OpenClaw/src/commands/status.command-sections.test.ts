// Status command section tests cover footer, health, and report section rendering.
import { describe, expect, it } from "vitest";
import { formatHealthChannelLines } from "./health-format.js";
import type { HealthSummary } from "./health.js";
import {
  buildStatusFooterLines,
  buildStatusAgentsValue,
  buildStatusHealthRows,
  buildStatusHeartbeatValue,
  buildStatusModelSelectionLines,
  buildStatusPairingRecoveryLines,
  buildStatusPluginCompatibilityLines,
  buildStatusSecurityAuditLines,
  buildStatusSessionsRows,
  buildStatusSystemEventsRows,
  buildStatusSystemEventsTrailer,
  statusHealthColumns,
} from "./status.command-sections.ts";

describe("status.command-sections", () => {
  it("does not label an arbitrary agent as the default in an explicit fleet", () => {
    expect(
      buildStatusAgentsValue({
        agentStatus: {
          defaultId: null,
          bootstrapPendingCount: 0,
          totalSessions: 0,
          agents: [
            {
              id: "alpha",
              workspaceDir: "/tmp/alpha",
              bootstrapPending: false,
              sessionsPath: "/tmp/alpha/sessions.json",
              sessionsCount: 0,
              lastUpdatedAt: null,
              lastActiveAgeMs: null,
            },
            {
              id: "beta",
              workspaceDir: "/tmp/beta",
              bootstrapPending: false,
              sessionsPath: "/tmp/beta/sessions.json",
              sessionsCount: 0,
              lastUpdatedAt: null,
              lastActiveAgeMs: null,
            },
          ],
        },
        formatTimeAgo: () => "now",
      }),
    ).toBe("2 · no workspaces bootstrapping · sessions 0");
  });

  it("shows when heartbeat is waiting for a delivery route", () => {
    expect(
      buildStatusHeartbeatValue({
        summary: {
          heartbeat: {
            defaultAgentId: "main",
            agents: [
              {
                agentId: "main",
                enabled: true,
                every: "30m",
                everyMs: 1_800_000,
                waitingForRoute: true,
              },
            ],
          },
        },
      }),
    ).toBe(
      "30m (main; waiting for delivery route — set commands.ownerAllowFrom or channel allowFrom, or heartbeat.target)",
    );
  });

  it("formats security audit lines with finding caps and follow-up commands", () => {
    const lines = buildStatusSecurityAuditLines({
      securityAudit: {
        summary: { critical: 1, warn: 6, info: 2 },
        findings: [
          {
            severity: "warn",
            title: "Warn first",
            detail: "warn detail",
          },
          {
            severity: "critical",
            title: "Critical first",
            detail: "critical\ndetail",
            remediation: "fix it",
          },
          ...Array.from({ length: 5 }, (_, index) => ({
            severity: "warn" as const,
            title: `Warn ${index + 2}`,
            detail: `detail ${index + 2}`,
          })),
        ],
      },
      theme: {
        error: (value) => `error(${value})`,
        warn: (value) => `warn(${value})`,
        muted: (value) => `muted(${value})`,
      },
      shortenText: (value) => value,
      formatCliCommand: (value) => `cmd:${value}`,
    });

    expect(lines[0]).toBe("muted(Summary: error(1 critical) · warn(6 warn) · muted(2 info))");
    expect(lines).toContain("  error(CRITICAL) Critical first");
    expect(lines).toContain("    critical detail");
    expect(lines).toContain("    muted(Fix: fix it)");
    expect(lines).toContain("muted(… +1 more)");
    expect(lines.at(-2)).toBe("muted(Full report: cmd:openclaw security audit)");
    expect(lines.at(-1)).toBe("muted(Deep probe: cmd:openclaw security audit --deep)");
  });

  it("builds verbose sessions rows and returns no rows for empty sessions", () => {
    const verboseRows = buildStatusSessionsRows({
      recent: [
        {
          key: "session-key-1234567890",
          kind: "direct",
          updatedAt: 1,
          age: 5_000,
          model: "gpt-5.4",
          runtime: "OpenAI Codex",
          totalTokens: null,
          totalTokensFresh: false,
          remainingTokens: null,
          percentUsed: null,
          contextTokens: null,
          configuredModel: "openai/gpt-5.4",
          selectedModel: "openai/gpt-5.4",
          modelSelectionReason: null,
          flags: [],
        },
        {
          key: "agent:main:cron:daily-digest",
          kind: "cron",
          updatedAt: 2,
          age: 7_000,
          model: "gpt-5.5",
          runtime: "OpenClaw Default",
          totalTokens: null,
          totalTokensFresh: false,
          remainingTokens: null,
          percentUsed: null,
          contextTokens: null,
          configuredModel: "openai/gpt-5.5",
          selectedModel: "openai/gpt-5.5",
          modelSelectionReason: null,
          flags: [],
        },
      ],
      verbose: true,
      shortenText: (value) => value.slice(0, 8),
      formatTimeAgo: (value) => `${value}ms`,
      formatTokensCompact: () => "12k",
      formatPromptCacheCompact: () => "cache ok",
      muted: (value) => `muted(${value})`,
    });

    expect(verboseRows).toEqual([
      {
        Key: "session-",
        Kind: "direct",
        Age: "5000ms",
        Model: "gpt-5.4",
        Runtime: "OpenAI Codex",
        Tokens: "12k",
        Cache: "cache ok",
      },
      {
        Key: "agent:ma",
        Kind: "cron",
        Age: "7000ms",
        Model: "gpt-5.5",
        Runtime: "OpenClaw Default",
        Tokens: "12k",
        Cache: "cache ok",
      },
    ]);

    const emptyRows = buildStatusSessionsRows({
      recent: [],
      verbose: true,
      shortenText: (value) => value,
      formatTimeAgo: () => "",
      formatTokensCompact: () => "",
      formatPromptCacheCompact: () => null,
      muted: (value) => `muted(${value})`,
    });

    expect(emptyRows).toEqual([]);
  });

  it("shows configured default and selected session model when they differ", () => {
    const lines = buildStatusModelSelectionLines({
      recent: [
        {
          key: "agent:main:telegram:chat-1",
          kind: "direct",
          updatedAt: 1,
          age: 5_000,
          model: "deepseek-v4-flash",
          configuredModel: "zhipu/glm-4.5-air",
          selectedModel: "deepseek/deepseek-v4-flash",
          modelSelectionReason: "session override",
          runtime: "OpenClaw Default",
          totalTokens: null,
          totalTokensFresh: false,
          remainingTokens: null,
          percentUsed: null,
          contextTokens: null,
          flags: [],
        },
      ],
      shortenText: (value) => value,
      warn: (value) => `warn(${value})`,
      muted: (value) => `muted(${value})`,
    });

    expect(lines).toEqual([
      "warn(Session agent:main:telegram:chat-1 is pinned to deepseek/deepseek-v4-flash; config primary zhipu/glm-4.5-air will apply to new/unpinned sessions.)",
      "  Configured default: zhipu/glm-4.5-air",
      "  Session selected: deepseek/deepseek-v4-flash",
      "  Reason: session override",
      "  Clear with: /model default",
      "  Docs: https://docs.openclaw.ai/concepts/models#selection-source-and-fallback-behavior",
    ]);
  });

  it("shows fallback-specific wording for auto-fallback model mismatches", () => {
    const lines = buildStatusModelSelectionLines({
      recent: [
        {
          key: "agent:main:telegram:chat-2",
          kind: "direct",
          updatedAt: 1,
          age: 5_000,
          model: "qwen3.6-blue",
          configuredModel: "minimax/MiniMax-M3",
          selectedModel: "ollama/qwen3.6-blue:35b-a3b",
          modelSelectionReason: "fallback selected",
          runtime: "OpenClaw Default",
          totalTokens: null,
          totalTokensFresh: false,
          remainingTokens: null,
          percentUsed: null,
          contextTokens: null,
          flags: [],
        },
      ],
      shortenText: (value) => value,
      warn: (value) => `warn(${value})`,
      muted: (value) => `muted(${value})`,
    });

    expect(lines).toEqual([
      "warn(Session agent:main:telegram:chat-2 is running ollama/qwen3.6-blue:35b-a3b (auto fallback); config primary is minimax/MiniMax-M3.)",
      "  Configured default: minimax/MiniMax-M3",
      "  Session selected: ollama/qwen3.6-blue:35b-a3b",
      "  Reason: fallback selected",
      "  Action: check provider availability or retry with /model",
      "  Docs: https://docs.openclaw.ai/concepts/models#selection-source-and-fallback-behavior",
    ]);
  });

  it("maps health channel detail lines into status rows", () => {
    const rows = buildStatusHealthRows({
      health: { durationMs: 42 } as HealthSummary,
      formatHealthChannelLines: () => [
        "QuietChat: OK · ready",
        "WorkChat: failed · auth",
        "Forum: not configured",
        "Matrix: linked",
        "Pager: not linked",
      ],
      ok: (value) => `ok(${value})`,
      warn: (value) => `warn(${value})`,
      muted: (value) => `muted(${value})`,
    });

    expect(rows).toEqual([
      { Item: "Gateway", Status: "ok(reachable)", Detail: "42ms" },
      { Item: "QuietChat", Status: "ok(OK)", Detail: "OK · ready" },
      { Item: "WorkChat", Status: "warn(WARN)", Detail: "failed · auth" },
      { Item: "Forum", Status: "muted(OFF)", Detail: "not configured" },
      { Item: "Matrix", Status: "ok(LINKED)", Detail: "linked" },
      { Item: "Pager", Status: "warn(UNLINKED)", Detail: "not linked" },
    ]);
  });

  it.each([
    { account: {}, status: "ok(OK)", detail: "healthy" },
    {
      account: { probe: { ok: false, error: "sync rejected" } },
      status: "warn(WARN)",
      detail: "failed (unknown) - sync rejected",
    },
    {
      account: { healthState: "blocked" },
      status: "warn(WARN)",
      detail: "blocked",
    },
    {
      account: { healthState: "unknown" },
      status: "warn(WARN)",
      detail: "unknown",
    },
    {
      account: { statusState: "unstable" },
      status: "warn(WARN)",
      detail: "auth stabilizing",
    },
    {
      account: { configured: false },
      status: "muted(OFF)",
      detail: "not configured",
    },
  ])("classifies the real channel health detail $detail", ({ account, status, detail }) => {
    const health: HealthSummary = {
      ok: true,
      ts: 0,
      durationMs: 42,
      heartbeatSeconds: 60,
      defaultAgentId: "main",
      agents: [],
      sessions: { path: "/tmp/sessions.json", count: 0, recent: [] },
      channels: {
        whatsapp: {
          accountId: "default",
          configured: true,
          linked: true,
          healthState: "healthy",
          ...account,
        },
      },
      channelOrder: ["whatsapp"],
      channelLabels: { whatsapp: "WhatsApp" },
    };
    const rows = buildStatusHealthRows({
      health,
      formatHealthChannelLines,
      ok: (value) => `ok(${value})`,
      warn: (value) => `warn(${value})`,
      muted: (value) => `muted(${value})`,
    });

    expect(rows).toContainEqual({ Item: "WhatsApp", Status: status, Detail: detail });
  });

  it("marks activated plugin service failures as warnings in deep health rows", () => {
    const health: HealthSummary = {
      ok: true,
      ts: 0,
      durationMs: 42,
      heartbeatSeconds: 60,
      defaultAgentId: "main",
      agents: [],
      sessions: { path: "/tmp/sessions.json", count: 0, recent: [] },
      channels: {},
      channelOrder: [],
      channelLabels: {},
      plugins: {
        loaded: ["calendar"],
        errors: [
          {
            id: "calendar",
            origin: "workspace",
            activated: true,
            failurePhase: "service",
            error: "service scheduler: address already in use",
          },
        ],
      },
    };
    const rows = buildStatusHealthRows({
      health,
      formatHealthChannelLines,
      ok: (value) => `ok(${value})`,
      warn: (value) => `warn(${value})`,
      muted: (value) => `muted(${value})`,
    });

    expect(rows).toContainEqual({
      Item: "Plugin calendar",
      Status: "warn(WARN)",
      Detail: "failed - service scheduler: address already in use; run openclaw doctor",
    });
  });

  it("shows blocked ingress even when the channel connection is healthy", () => {
    const rows = buildStatusHealthRows({
      health: {
        ok: true,
        ts: 0,
        durationMs: 42,
        heartbeatSeconds: 60,
        defaultAgentId: "main",
        agents: [],
        sessions: { path: "/tmp/sessions.json", count: 0, recent: [] },
        channels: {},
        channelOrder: [],
        channelLabels: {},
        deliveryQueues: {
          failed: [],
          ingressPressure: [
            {
              channelId: "telegram",
              accountId: "ops",
              laneCount: 1,
              pendingCount: 2,
              claimedCount: 0,
              blockedCount: 1,
              oldestReceivedAt: Date.now(),
            },
          ],
        },
      },
      formatHealthChannelLines: () => ["Telegram: healthy"],
      ok: (value) => `ok(${value})`,
      warn: (value) => `warn(${value})`,
      muted: (value) => `muted(${value})`,
    });

    expect(rows).toContainEqual({ Item: "Telegram", Status: "ok(OK)", Detail: "healthy" });
    expect(rows).toContainEqual({
      Item: "Delivery queue",
      Status: "warn(WARN)",
      Detail: expect.stringContaining(
        "inbound telegram/ops: 1 pressured lane, 2 pending, 0 claimed, 1 blocked",
      ),
    });
  });

  it("adds degraded event-loop health to status rows", () => {
    const rows = buildStatusHealthRows({
      health: {
        durationMs: 42,
        eventLoop: {
          degraded: true,
          degradedSinceMs: 180_000,
          reasons: ["event_loop_delay"],
          intervalMs: 62_000,
          delayP99Ms: 61_000,
          delayMaxMs: 62_000,
          utilization: 1,
          cpuCoreRatio: 1,
        },
      } as HealthSummary,
      formatHealthChannelLines: () => [],
      ok: (value) => `ok(${value})`,
      warn: (value) => `warn(${value})`,
      muted: (value) => `muted(${value})`,
    });

    expect(rows).toEqual([
      { Item: "Gateway", Status: "ok(reachable)", Detail: "42ms" },
      {
        Item: "Event loop",
        Status: "warn(WARN)",
        Detail:
          "degraded for 3m · reasons event_loop_delay · max 62000ms · p99 61000ms · util 1 · cpu 1",
      },
    ]);
  });

  it("builds footer lines from update and reachability state", () => {
    expect(
      buildStatusFooterLines({
        updateHint: "upgrade ready",
        warn: (value) => `warn(${value})`,
        formatCliCommand: (value) => `cmd:${value}`,
        nodeOnlyGateway: null,
        gatewayReachable: false,
      }),
    ).toEqual([
      "FAQ: https://docs.openclaw.ai/faq",
      "Troubleshooting: https://docs.openclaw.ai/troubleshooting",
      "",
      "warn(upgrade ready)",
      "Next steps:",
      "  Need to share?      cmd:openclaw status --all",
      "  Need to debug live? cmd:openclaw logs --follow",
      "  Fix reachability first: cmd:openclaw gateway probe",
    ]);
  });

  it("builds plugin compatibility lines and pairing recovery guidance", () => {
    expect(
      buildStatusPluginCompatibilityLines({
        notices: [
          { severity: "warn" as const, message: "legacy" },
          { severity: "info" as const, message: "heads-up" },
          { severity: "warn" as const, message: "extra" },
        ],
        limit: 2,
        formatNotice: (notice) => notice.message,
        warn: (value) => `warn(${value})`,
        muted: (value) => `muted(${value})`,
      }),
    ).toEqual(["  warn(WARN) legacy", "  muted(INFO) heads-up", "muted(  … +1 more)"]);

    expect(
      buildStatusPairingRecoveryLines({
        pairingRecovery: {
          requestId: "req-123",
          reason: "scope-upgrade",
          remediationHint: "Review the requested scopes, then approve the pending upgrade.",
        },
        warn: (value) => `warn(${value})`,
        muted: (value) => `muted(${value})`,
        formatCliCommand: (value) => `cmd:${value}`,
      }),
    ).toEqual([
      "warn(Gateway scope upgrade approval required.)",
      "muted(Reason: device is asking for more scopes than currently approved.)",
      "muted(Hint: Review the requested scopes, then approve the pending upgrade.)",
      "muted(Recovery: cmd:openclaw devices approve req-123)",
      "muted(Fallback: cmd:openclaw devices approve --latest)",
      "muted(Inspect: cmd:openclaw devices list)",
    ]);
  });

  it("builds system event rows and health columns", () => {
    expect(
      buildStatusSystemEventsRows({
        queuedSystemEvents: ["one", "two", "three"],
        limit: 2,
      }),
    ).toEqual([{ Event: "one" }, { Event: "two" }]);
    expect(
      buildStatusSystemEventsTrailer({
        queuedSystemEvents: ["one", "two", "three"],
        limit: 2,
        muted: (value) => `muted(${value})`,
      }),
    ).toBe("muted(… +1 more)");
    expect(statusHealthColumns).toEqual([
      { key: "Item", header: "Item", minWidth: 10 },
      { key: "Status", header: "Status", minWidth: 8 },
      { key: "Detail", header: "Detail", flex: true, minWidth: 28 },
    ]);
  });
});
