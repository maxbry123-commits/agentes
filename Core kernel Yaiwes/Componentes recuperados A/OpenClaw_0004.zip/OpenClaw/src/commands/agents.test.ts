// Agents command tests cover agent config mutation, binding updates, and summary generation.
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { describe, expect, it } from "vitest";
import type { OpenClawConfig } from "../config/config.js";
import { applyAgentBindings, removeAgentBindings } from "./agents.bindings.js";
import { applyAgentConfig, buildAgentSummaries, pruneAgentConfig } from "./agents.config.js";

function requireAgentSummary(
  summaries: ReturnType<typeof buildAgentSummaries>,
  id: string,
): ReturnType<typeof buildAgentSummaries>[number] {
  const summary = summaries.find((entry) => entry.id === id);
  if (!summary) {
    throw new Error(`expected agent summary ${id}`);
  }
  return summary;
}

describe("agents helpers", () => {
  it("buildAgentSummaries includes configured agents without inventing a fleet default", () => {
    const cfg: OpenClawConfig = {
      agents: {
        defaults: {
          workspace: "/main-ws",
          model: { primary: "anthropic/claude" },
        },
        entries: {
          main: {},
          work: {
            name: "Work",
            workspace: "/work-ws",
            agentDir: "/state/agents/work/agent",
            model: "openai/gpt-4.1",
          },
        },
      },
      bindings: [
        {
          agentId: "work",
          match: { channel: "whatsapp", accountId: "biz" },
        },
        { agentId: "main", match: { channel: "telegram" } },
      ],
    };

    const summaries = buildAgentSummaries(cfg);
    const main = requireAgentSummary(summaries, "main");
    const work = requireAgentSummary(summaries, "work");

    expect(main.workspace).toBe(path.resolve("/main-ws/main"));
    expect(main.bindings).toBe(1);
    expect(main.model).toBe("anthropic/claude");
    expect(main.agentDir.endsWith(path.join("agents", "main", "agent"))).toBe(true);

    expect(work.name).toBe("Work");
    expect(work.workspace).toBe(path.resolve("/work-ws"));
    expect(work.agentDir).toBe(path.resolve("/state/agents/work/agent"));
    expect(work.bindings).toBe(1);
    expect(main.isDefault).toBe(false);
    expect(work.isDefault).toBe(false);
  });

  it("buildAgentSummaries renders local avatars and omits absent avatars", () => {
    const workspace = fs.mkdtempSync(path.join(os.tmpdir(), "openclaw-agent-avatar-"));
    try {
      fs.writeFileSync(path.join(workspace, "avatar.png"), Buffer.from([0x89, 0x50, 0x4e, 0x47]));
      const cfg: OpenClawConfig = {
        agents: {
          entries: {
            main: { workspace },
            work: { workspace, identity: { avatar: "avatar.png" } },
          },
        },
      };

      const summaries = buildAgentSummaries(cfg);
      const work = requireAgentSummary(summaries, "work");
      expect(work.identityAvatarUrl).toBe("data:image/png;base64,iVBORw==");
      expect(work.identitySource).toBe("config");
      expect(requireAgentSummary(summaries, "main")).not.toHaveProperty("identityAvatarUrl");
    } finally {
      fs.rmSync(workspace, { force: true, recursive: true });
    }
  });

  it("applyAgentConfig merges updates", () => {
    const cfg: OpenClawConfig = {
      agents: {
        entries: { work: { workspace: "/old-ws", model: "anthropic/claude" } },
      },
    };

    const next = applyAgentConfig(cfg, {
      agentId: "work",
      name: "Work",
      workspace: "/new-ws",
      agentDir: "/state/work/agent",
    });

    const work = next.agents?.entries?.work;
    expect(work?.name).toBe("Work");
    expect(work?.workspace).toBe("/new-ws");
    expect(work?.agentDir).toBe("/state/work/agent");
    expect(work?.model).toBe("anthropic/claude");
  });

  it("applyAgentConfig leaves a first roster entry trivially sole", () => {
    const next = applyAgentConfig({}, { agentId: "work", name: "Work" });

    expect(next.agents?.entries).toEqual({ work: { name: "Work" } });
    expect(requireAgentSummary(buildAgentSummaries(next), "work").isDefault).toBe(true);
  });

  it("preserves the sole agent as the ambient system owner when adding a second agent", () => {
    const cfg: OpenClawConfig = { agents: { entries: { main: {} } } };

    const next = applyAgentConfig(cfg, { agentId: "helper", name: "Helper" });

    expect(next.agents).toMatchObject({
      ownership: "explicit",
      defaults: { systemAgent: { agentId: "main" } },
      entries: { main: {}, helper: { name: "Helper" } },
    });
  });

  it("applyAgentConfig clears a model override", () => {
    const cfg: OpenClawConfig = {
      agents: {
        defaults: { model: { primary: "openai/gpt-5.6-luna" } },
        entries: {
          work: { workspace: "/work-ws", model: "anthropic/claude" },
        },
      },
    };

    const next = applyAgentConfig(cfg, { agentId: "work", model: null });
    const work = next.agents?.entries?.work;

    expect(work).not.toHaveProperty("model");
    expect(requireAgentSummary(buildAgentSummaries(next), "work").model).toBe(
      "openai/gpt-5.6-luna",
    );
  });

  it("applyAgentConfig merges identity with existing", () => {
    const cfg: OpenClawConfig = {
      agents: {
        entries: { work: { identity: { name: "Old", theme: "chill", emoji: "🐢" } } },
      },
    };

    const next = applyAgentConfig(cfg, {
      agentId: "work",
      identity: { name: "New", emoji: "🦀" },
    });

    const work = next.agents?.entries?.work;
    expect(work?.identity?.name).toBe("New");
    expect(work?.identity?.emoji).toBe("🦀");
    expect(work?.identity?.theme).toBe("chill");
  });

  it("applyAgentConfig skips identity when not provided", () => {
    const cfg: OpenClawConfig = {
      agents: {
        entries: { work: { identity: { name: "Keep", emoji: "🐢" } } },
      },
    };

    const next = applyAgentConfig(cfg, { agentId: "work", name: "Renamed" });

    const work = next.agents?.entries?.work;
    expect(work?.name).toBe("Renamed");
    expect(work?.identity?.name).toBe("Keep");
    expect(work?.identity?.emoji).toBe("🐢");
  });

  it("applyAgentBindings skips duplicates and reports conflicts", () => {
    const cfg: OpenClawConfig = {
      bindings: [
        {
          agentId: "main",
          match: { channel: "whatsapp", accountId: "default" },
        },
      ],
    };

    const result = applyAgentBindings(cfg, [
      {
        agentId: "main",
        match: { channel: "whatsapp", accountId: "default" },
      },
      {
        agentId: "work",
        match: { channel: "whatsapp", accountId: "default" },
      },
      {
        agentId: "work",
        match: { channel: "telegram" },
      },
    ]);

    expect(result.added).toStrictEqual([
      {
        agentId: "work",
        match: { channel: "telegram" },
      },
    ]);
    expect(result.skipped).toStrictEqual([
      {
        agentId: "main",
        match: { channel: "whatsapp", accountId: "default" },
      },
    ]);
    expect(result.conflicts).toStrictEqual([
      {
        binding: {
          agentId: "work",
          match: { channel: "whatsapp", accountId: "default" },
        },
        existingAgentId: "main",
      },
    ]);
    expect(result.config.bindings).toStrictEqual([
      {
        agentId: "main",
        match: { channel: "whatsapp", accountId: "default" },
      },
      {
        agentId: "work",
        match: { channel: "telegram" },
      },
    ]);
  });

  it("applyAgentBindings upgrades channel-only binding to account-specific binding for same agent", () => {
    const cfg: OpenClawConfig = {
      bindings: [
        {
          agentId: "main",
          match: { channel: "telegram" },
        },
      ],
    };

    const result = applyAgentBindings(cfg, [
      {
        agentId: "main",
        match: { channel: "telegram", accountId: "work" },
      },
    ]);

    expect(result.added).toStrictEqual([]);
    expect(result.updated).toStrictEqual([
      {
        agentId: "main",
        match: { channel: "telegram", accountId: "work" },
      },
    ]);
    expect(result.conflicts).toStrictEqual([]);
    expect(result.config.bindings).toEqual([
      {
        agentId: "main",
        match: { channel: "telegram", accountId: "work" },
      },
    ]);
  });

  it("applyAgentBindings treats role-based bindings as distinct routes", () => {
    const cfg: OpenClawConfig = {
      bindings: [
        {
          agentId: "main",
          match: {
            channel: "discord",
            accountId: "guild-a",
            guildId: "123",
            roles: ["111", "222"],
          },
        },
      ],
    };

    const result = applyAgentBindings(cfg, [
      {
        agentId: "work",
        match: {
          channel: "discord",
          accountId: "guild-a",
          guildId: "123",
        },
      },
    ]);

    expect(result.added).toStrictEqual([
      {
        agentId: "work",
        match: {
          channel: "discord",
          accountId: "guild-a",
          guildId: "123",
        },
      },
    ]);
    expect(result.conflicts).toStrictEqual([]);
    expect(result.config.bindings).toStrictEqual([
      {
        agentId: "main",
        match: {
          channel: "discord",
          accountId: "guild-a",
          guildId: "123",
          roles: ["111", "222"],
        },
      },
      {
        agentId: "work",
        match: {
          channel: "discord",
          accountId: "guild-a",
          guildId: "123",
        },
      },
    ]);
  });

  it("applyAgentBindings keeps distinct bindings when persisted match fields contain pipes", () => {
    const cfg: OpenClawConfig = {};

    const result = applyAgentBindings(cfg, [
      {
        agentId: "main",
        match: {
          channel: "discord",
          peer: { kind: "direct", id: "a|b" },
          accountId: "default",
        },
      },
      {
        agentId: "main",
        match: {
          channel: "discord",
          peer: { kind: "direct", id: "a" },
          guildId: "b",
          accountId: "|default",
        },
      },
    ]);

    expect(result.added).toStrictEqual([
      {
        agentId: "main",
        match: {
          channel: "discord",
          peer: { kind: "direct", id: "a|b" },
          accountId: "default",
        },
      },
      {
        agentId: "main",
        match: {
          channel: "discord",
          peer: { kind: "direct", id: "a" },
          guildId: "b",
          accountId: "|default",
        },
      },
    ]);
    expect(result.skipped).toStrictEqual([]);
    expect(result.conflicts).toStrictEqual([]);
    expect(result.config.bindings).toStrictEqual(result.added);
  });

  it("removeAgentBindings does not remove role-based bindings when removing channel-level routes", () => {
    const cfg: OpenClawConfig = {
      bindings: [
        {
          agentId: "main",
          match: {
            channel: "discord",
            accountId: "guild-a",
            guildId: "123",
            roles: ["111", "222"],
          },
        },
        {
          agentId: "main",
          match: {
            channel: "discord",
            accountId: "guild-a",
            guildId: "123",
          },
        },
      ],
    };

    const result = removeAgentBindings(cfg, [
      {
        agentId: "main",
        match: {
          channel: "discord",
          accountId: "guild-a",
          guildId: "123",
        },
      },
    ]);

    expect(result.removed).toStrictEqual([
      {
        agentId: "main",
        match: {
          channel: "discord",
          accountId: "guild-a",
          guildId: "123",
        },
      },
    ]);
    expect(result.conflicts).toStrictEqual([]);
    expect(result.config.bindings).toEqual([
      {
        agentId: "main",
        match: {
          channel: "discord",
          accountId: "guild-a",
          guildId: "123",
          roles: ["111", "222"],
        },
      },
    ]);
  });

  it("pruneAgentConfig removes agent, bindings, and allowlist entries", () => {
    const cfg: OpenClawConfig = {
      agents: {
        defaults: {
          heartbeat: { agentId: "work", every: "5m" },
          systemAgent: { agentId: "WORK" },
          subagents: { allowAgents: ["work", "home"] },
        },
        entries: {
          work: { workspace: "/work-ws" },
          home: {
            workspace: "/home-ws",
            subagents: { allowAgents: ["WORK", "home"] },
          },
        },
      },
      bindings: [
        { agentId: "work", match: { channel: "whatsapp" } },
        { agentId: "home", match: { channel: "telegram" } },
      ],
      broadcast: {
        strategy: "parallel",
        "peer-1": ["work", "home"],
        "peer-2": ["WORK"],
      },
      hooks: {
        allowedAgentIds: ["*", "work", "home"],
        mappings: [
          { id: "work-hook", agentId: "WORK", action: "agent" },
          { id: "home-hook", agentId: "home", action: "agent" },
          { id: "default-hook", action: "agent" },
        ],
      },
      tools: {
        agentToAgent: { enabled: true, allow: ["work", "home"] },
      },
      talk: { agentId: "work", provider: "test-provider" },
    };

    const result = pruneAgentConfig(cfg, "work");
    expect(result.config.agents?.entries).not.toHaveProperty("work");
    expect(result.config.agents?.entries).toHaveProperty("home");
    expect(result.config.bindings).toStrictEqual([
      { agentId: "home", match: { channel: "telegram" } },
    ]);
    expect(result.config.broadcast).toEqual({
      strategy: "parallel",
      "peer-1": ["home"],
      "peer-2": [],
    });
    expect(result.config.hooks?.allowedAgentIds).toEqual(["*", "home"]);
    expect(result.config.hooks?.mappings).toEqual([
      { id: "home-hook", agentId: "home", action: "agent" },
      { id: "default-hook", action: "agent" },
    ]);
    expect(result.config.tools?.agentToAgent?.allow).toEqual(["home"]);
    expect(result.config.agents?.defaults?.subagents?.allowAgents).toEqual(["home"]);
    expect(result.config.agents?.defaults?.heartbeat).toEqual({ every: "5m" });
    expect(result.config.agents?.defaults?.systemAgent).toBeUndefined();
    expect(result.config.talk).toEqual({ provider: "test-provider" });
    expect(result.config.agents?.entries?.home?.subagents?.allowAgents).toEqual(["home"]);
    expect(result.removedBindings).toBe(1);
    expect(result.removedAllow).toBe(1);
    expect(result.clearedOwnerRefs).toEqual([
      "agents.defaults.heartbeat.agentId",
      "agents.defaults.systemAgent.agentId",
      "talk.agentId",
    ]);
  });

  it("pruneAgentConfig pins a survivor's workspace before the roster becomes sole", () => {
    const cfg: OpenClawConfig = {
      agents: {
        ownership: "explicit",
        defaults: { workspace: "/srv/fleet" },
        entries: { ops: {}, research: {} },
      },
    };

    const result = pruneAgentConfig(cfg, "ops");

    expect(result.config.agents?.entries).toEqual({
      research: { workspace: "/srv/fleet/research" },
    });
  });

  it("removes ambient heartbeat policy when its owner leaves a surviving fleet", () => {
    const result = pruneAgentConfig(
      {
        agents: {
          ownership: "explicit",
          defaults: { heartbeat: { agentId: "ops", every: "5m" } },
          entries: { ops: {}, research: {}, writer: {} },
        },
      },
      "ops",
    );

    expect(result.config.agents?.defaults?.heartbeat).toBeUndefined();
    expect(result.clearedOwnerRefs).toContain("agents.defaults.heartbeat");
  });
});
