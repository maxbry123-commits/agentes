// Channels status command-flow tests cover gateway calls, config fallback, and timeout validation.
import { beforeEach, describe, expect, it, vi } from "vitest";
import { GatewaySecretRefUnavailableError } from "../gateway/credentials.js";
import { GatewayTransportError } from "../gateway/transport-error.js";
import { DEFAULT_ACCOUNT_ID } from "../routing/session-key.js";
import { channelsStatusCommand } from "./channels/status.js";
import { createCapturingTestRuntime } from "./test-runtime-config-helpers.js";

const resolveDefaultAccountId = () => DEFAULT_ACCOUNT_ID;

const mocks = vi.hoisted(() => ({
  callGateway: vi.fn(),
  resolveCommandConfigWithSecrets: vi.fn(),
  readConfigFileSnapshot: vi.fn(async () => ({ path: "/tmp/openclaw.json" })),
  requireValidConfig: vi.fn(),
  listChannelPlugins: vi.fn(),
  listConfiguredAnnounceChannelIdsForConfig: vi.fn((_params: unknown) => ["discord"]),
  missingOfficialExternalChannels: new Set<string>(),
  repairHintChannelIdCalls: [] as string[][],
  withProgress: vi.fn(async (_opts: unknown, run: () => Promise<unknown>) => await run()),
}));

vi.mock("../gateway/call.js", () => ({
  callGateway: (opts: unknown) => mocks.callGateway(opts),
}));

vi.mock("../cli/command-config-resolution.js", () => ({
  resolveCommandConfigWithSecrets: async (opts: {
    runtime?: { log: (message: string) => void };
  }) => {
    const result = await mocks.resolveCommandConfigWithSecrets(opts);
    for (const entry of result?.diagnostics ?? []) {
      opts.runtime?.log(`[secrets] ${entry}`);
    }
    return result;
  },
}));

vi.mock("../config/config.js", () => ({
  readConfigFileSnapshot: () => mocks.readConfigFileSnapshot(),
}));

vi.mock("./config-validation.js", () => ({
  requireValidConfig: (runtime: unknown) => mocks.requireValidConfig(runtime),
}));

vi.mock("../plugins/channel-plugin-ids.js", () => ({
  listExplicitConfiguredChannelIdsForConfig: (config: { channels?: Record<string, unknown> }) =>
    Object.keys(config.channels ?? {}),
  listConfiguredAnnounceChannelIdsForConfig: (params: unknown) =>
    mocks.listConfiguredAnnounceChannelIdsForConfig(params),
}));

vi.mock("../plugins/official-external-plugin-repair-hints.js", () => ({
  resolveMissingOfficialExternalChannelPluginRepairHints: ({
    channelIds,
  }: {
    channelIds: string[];
  }) => {
    mocks.repairHintChannelIdCalls.push([...channelIds]);
    return channelIds.flatMap((channelId) =>
      mocks.missingOfficialExternalChannels.has(channelId)
        ? [
            {
              pluginId: channelId,
              channelId,
              label: "Feishu",
              installSpec: "@openclaw/feishu",
              installCommand: "openclaw plugins install @openclaw/feishu",
              doctorFixCommand: "openclaw doctor --fix",
              repairHint:
                "Install the official external plugin with: openclaw plugins install @openclaw/feishu, or run: openclaw doctor --fix.",
            },
          ]
        : [],
    );
  },
}));

vi.mock("./channels/shared.js", () => ({
  formatChannelAccountLabel: ({
    channel,
    accountId,
  }: {
    channel: string;
    accountId: string;
    name?: string;
  }) => `${channel} ${accountId}`,
  appendEnabledConfiguredLinkedBits: (bits: string[], account: Record<string, unknown>) => {
    if (typeof account.enabled === "boolean") {
      bits.push(account.enabled ? "enabled" : "disabled");
    }
    if (account.configured === true) {
      bits.push("configured");
      if (Object.values(account).includes("configured_unavailable")) {
        bits.push("secret unavailable in this command path");
      }
    }
  },
  appendModeBit: (bits: string[], account: Record<string, unknown>) => {
    if (typeof account.mode === "string" && account.mode.length > 0) {
      bits.push(`mode:${account.mode}`);
    }
  },
  appendTokenSourceBits: (bits: string[], account: Record<string, unknown>) => {
    if (account.tokenSource === "config") {
      const unavailable = account.tokenStatus === "configured_unavailable" ? " (unavailable)" : "";
      bits.push(`token:config${unavailable}`);
    }
  },
  appendBaseUrlBit: (bits: string[], account: Record<string, unknown>) => {
    if (typeof account.baseUrl === "string" && account.baseUrl) {
      bits.push(`url:${account.baseUrl}`);
    }
  },
  buildChannelAccountLine: (channel: string, account: Record<string, unknown>, bits: string[]) => {
    const accountId = typeof account.accountId === "string" ? account.accountId : "default";
    return `- ${channel} ${accountId}: ${bits.join(", ")}`;
  },
}));

vi.mock("../channels/plugins/index.js", () => ({
  listChannelPlugins: () => mocks.listChannelPlugins(),
  getChannelPlugin: (channel: string) =>
    (mocks.listChannelPlugins() as Array<{ id: string }>).find((plugin) => plugin.id === channel),
  normalizeChannelId: (channel: string) =>
    channel === "clickclack" ? undefined : channel === "imsg" ? "imessage" : channel,
}));

vi.mock("../channels/plugins/read-only.js", () => ({
  listReadOnlyChannelPluginsForConfig: () => mocks.listChannelPlugins(),
}));

vi.mock("../channels/account-snapshot-fields.js", () => ({
  hasConfiguredUnavailableCredentialStatus: (account: Record<string, unknown>) =>
    Object.values(account).includes("configured_unavailable"),
  hasResolvedCredentialValue: (account: Record<string, unknown>) =>
    ["token", "botToken", "appToken", "signingSecret"].some(
      (key) => typeof account[key] === "string" && account[key].length > 0,
    ),
}));

vi.mock("../channels/plugins/status.js", () => ({
  buildReadOnlySourceChannelAccountSnapshot: async ({
    plugin,
    cfg,
    accountId,
  }: {
    plugin: ReturnType<typeof createTokenOnlyPlugin>;
    cfg: { secretResolved?: boolean };
    accountId: string;
  }) => ({
    accountId,
    ...plugin.config.inspectAccount(cfg),
  }),
  resolveChannelAccountSnapshot: async ({
    plugin,
    cfg,
    accountId,
  }: {
    plugin: ReturnType<typeof createTokenOnlyPlugin>;
    cfg: { secretResolved?: boolean };
    accountId: string;
  }) => ({
    accountId,
    ...plugin.config.resolveAccount(cfg),
  }),
}));

vi.mock("../cli/command-secret-targets.js", () => ({
  getConfiguredChannelsCommandSecretTargetIds: () => [],
}));

vi.mock("../infra/channels-status-issues.js", () => ({
  collectChannelStatusIssues: () => [],
}));

vi.mock("../cli/progress.js", () => ({
  withProgress: (opts: unknown, run: () => Promise<unknown>) => mocks.withProgress(opts, run),
}));

function createTokenAccountSnapshot(cfg: { secretResolved?: boolean }) {
  return {
    name: "Primary",
    enabled: true,
    configured: true,
    token: cfg.secretResolved ? "resolved-discord-token" : "",
    tokenSource: "config",
    tokenStatus: cfg.secretResolved ? "available" : "configured_unavailable",
  };
}

function createTokenOnlyPlugin() {
  return {
    id: "discord",
    meta: {
      id: "discord",
      label: "Discord",
      selectionLabel: "Discord",
      docsPath: "/channels/discord",
      blurb: "test",
    },
    capabilities: { chatTypes: ["direct"] },
    config: {
      listAccountIds: () => ["default"],
      defaultAccountId: resolveDefaultAccountId,
      inspectAccount: createTokenAccountSnapshot,
      resolveAccount: createTokenAccountSnapshot,
      isConfigured: () => true,
      isEnabled: () => true,
    },
    actions: {
      describeMessageTool: () => ({ actions: ["send"] }),
    },
  };
}

function createGatewayTransportError(message = "Gateway not reachable (ECONNREFUSED).") {
  return new GatewayTransportError({
    kind: "closed",
    message,
    connectionDetails: {
      url: "ws://127.0.0.1:18997",
      urlSource: "local loopback",
      message: "Gateway target: ws://127.0.0.1:18997",
    },
  });
}

describe("channelsStatusCommand SecretRef fallback flow", () => {
  beforeEach(() => {
    mocks.callGateway.mockReset();
    mocks.resolveCommandConfigWithSecrets.mockReset();
    mocks.readConfigFileSnapshot.mockClear();
    mocks.requireValidConfig.mockReset();
    mocks.listChannelPlugins.mockReset();
    mocks.missingOfficialExternalChannels.clear();
    mocks.repairHintChannelIdCalls.length = 0;
    mocks.listConfiguredAnnounceChannelIdsForConfig.mockClear();
    mocks.listConfiguredAnnounceChannelIdsForConfig.mockReturnValue(["discord"]);
    mocks.withProgress.mockClear();
    mocks.listChannelPlugins.mockReturnValue([createTokenOnlyPlugin()]);
  });

  it("passes a channel filter to the gateway status request", async () => {
    mocks.callGateway.mockResolvedValue({
      channelAccounts: { imessage: [] },
      channels: { imessage: {} },
    });
    const { runtime } = createCapturingTestRuntime();

    await channelsStatusCommand({ channel: "imsg", json: true, probe: true }, runtime as never);

    expect(mocks.callGateway).toHaveBeenCalledWith({
      method: "channels.status",
      params: { channel: "imsg", probe: true, timeoutMs: 30000 },
      timeoutMs: 30000,
    });
  });

  it("preserves gateway account text in JSON output", async () => {
    const name = "Primary\u001B]0;channels-status-json\u0007🦞\r\nAccount";
    const payload = {
      channelAccounts: { discord: [{ accountId: "default", name }] },
      channels: { discord: { name } },
    };
    mocks.callGateway.mockResolvedValue(payload);
    const { runtime, logs } = createCapturingTestRuntime();

    await channelsStatusCommand({ json: true, probe: false }, runtime as never);

    expect(JSON.parse(logs.at(-1) ?? "{}")).toStrictEqual(payload);
  });

  it("rejects malformed timeouts before gateway status requests", async () => {
    const { runtime } = createCapturingTestRuntime();

    await expect(
      channelsStatusCommand({ channel: "imsg", timeout: "10s", probe: true }, runtime as never),
    ).rejects.toThrow('Received: "10s"');

    expect(mocks.callGateway).not.toHaveBeenCalled();
  });

  it("keeps read-only fallback output when SecretRefs are unresolved", async () => {
    mocks.callGateway.mockRejectedValue(createGatewayTransportError());
    mocks.requireValidConfig.mockResolvedValue({ secretResolved: false, channels: {} });
    mocks.resolveCommandConfigWithSecrets.mockResolvedValue({
      resolvedConfig: { secretResolved: false, channels: {} },
      effectiveConfig: { secretResolved: false, channels: {} },
      diagnostics: [
        "channels status: channels.discord.token is unavailable in this command path; continuing with degraded read-only config.",
      ],
    });
    const { runtime, logs, errors } = createCapturingTestRuntime();

    await channelsStatusCommand({ probe: false }, runtime as never);

    expect(errors.join("\n")).toContain("Gateway not reachable");
    expect(errors.join("\n")).not.toContain("Gateway auth unavailable");
    expect(mocks.resolveCommandConfigWithSecrets).toHaveBeenCalledOnce();
    const configResolutionRequest = mocks.resolveCommandConfigWithSecrets.mock.calls[0]?.[0];
    expect(configResolutionRequest?.commandName).toBe("channels status");
    expect(configResolutionRequest?.mode).toBe("read_only_status");
    expect(
      logs.some((line) =>
        line.includes("[secrets] channels status: channels.discord.token is unavailable"),
      ),
    ).toBe(true);
    const joined = logs.join("\n");
    expect(joined).toContain("Gateway not reachable; showing config-only status.");
    expect(joined).not.toContain("Gateway auth unavailable; showing config-only status.");
    expect(joined).toContain("configured, secret unavailable in this command path");
    expect(joined).toContain("token:config (unavailable)");
  });

  it("labels config-only fallback as auth-unavailable when gateway auth SecretRefs are unresolved", async () => {
    mocks.callGateway.mockRejectedValue(
      new GatewaySecretRefUnavailableError("gateway.auth.password"),
    );
    mocks.requireValidConfig.mockResolvedValue({ secretResolved: false, channels: {} });
    mocks.resolveCommandConfigWithSecrets.mockResolvedValue({
      resolvedConfig: { secretResolved: false, channels: {} },
      effectiveConfig: { secretResolved: false, channels: {} },
      diagnostics: [],
    });
    const { runtime, logs, errors } = createCapturingTestRuntime();

    await channelsStatusCommand({ probe: false }, runtime as never);

    const errorOutput = errors.join("\n");
    expect(errorOutput).toContain("Gateway auth unavailable");
    expect(errorOutput).not.toContain("Gateway not reachable");
    const joined = logs.join("\n");
    expect(joined).toContain("Gateway auth unavailable; showing config-only status.");
    expect(joined).not.toContain("Gateway not reachable; showing config-only status.");
    expect(joined).toContain("configured, secret unavailable in this command path");

    const { runtime: jsonRuntime, logs: jsonLogs } = createCapturingTestRuntime();
    await channelsStatusCommand({ json: true, probe: false }, jsonRuntime as never);
    expect(JSON.parse(jsonLogs.at(-1) ?? "{}").gatewayAuthUnavailable).toBe(true);
  });

  it("renders missing gateway credentials canonically before config-only status", async () => {
    const error = Object.assign(
      new Error(
        [
          "gateway channels.status requires credentials before opening a websocket",
          "Fix: configure gateway.auth token/password, pair this device, or pass --token/--password.",
          "Config: /tmp/openclaw.json",
        ].join("\n"),
      ),
      {
        name: "GatewayCredentialsRequiredError",
        method: "channels.status",
        configPath: "/tmp/openclaw.json",
      },
    );
    mocks.callGateway.mockRejectedValue(error);
    mocks.requireValidConfig.mockResolvedValue({ channels: {} });
    mocks.resolveCommandConfigWithSecrets.mockResolvedValue({
      resolvedConfig: { channels: {} },
      effectiveConfig: { channels: {} },
      diagnostics: [],
    });
    const { runtime, logs, errors } = createCapturingTestRuntime();

    await channelsStatusCommand({ probe: false }, runtime as never);

    expect(errors).toEqual([error.message]);
    expect(errors.join("\n")).not.toContain("Gateway not reachable:");
    expect(logs.join("\n")).toContain("Gateway auth unavailable; showing config-only status.");
  });

  it("prefers resolved snapshots when command-local SecretRef resolution succeeds", async () => {
    mocks.callGateway.mockRejectedValue(new Error("gateway closed"));
    mocks.requireValidConfig.mockResolvedValue({ secretResolved: false, channels: {} });
    mocks.resolveCommandConfigWithSecrets.mockResolvedValue({
      resolvedConfig: { secretResolved: true, channels: {} },
      effectiveConfig: { secretResolved: true, channels: {} },
      diagnostics: [],
    });
    const { runtime, logs } = createCapturingTestRuntime();

    await channelsStatusCommand({ probe: false }, runtime as never);

    const joined = logs.join("\n");
    expect(joined).toContain("configured");
    expect(joined).toContain("token:config");
    expect(joined).not.toContain("secret unavailable in this command path");
    expect(joined).not.toContain("token:config (unavailable)");
  });

  it("shows missing official external plugin repair hints in config-only output", async () => {
    mocks.callGateway.mockRejectedValue(new Error("gateway closed"));
    mocks.requireValidConfig.mockResolvedValue({
      channels: { feishu: { appId: "cli_xxx" } },
    });
    mocks.resolveCommandConfigWithSecrets.mockResolvedValue({
      resolvedConfig: { channels: { feishu: { appId: "cli_xxx" } } },
      effectiveConfig: { channels: { feishu: { appId: "cli_xxx" } } },
      diagnostics: [],
    });
    mocks.missingOfficialExternalChannels.add("feishu");
    mocks.listChannelPlugins.mockReturnValue([]);
    const { runtime, logs } = createCapturingTestRuntime();

    await channelsStatusCommand({ probe: false }, runtime as never);

    const joined = logs.join("\n");
    expect(joined).toContain("Missing official external plugins:");
    expect(joined).toContain(
      "Feishu: Install the official external plugin with: openclaw plugins install @openclaw/feishu, or run: openclaw doctor --fix.",
    );
  });

  it("resolves config-only repair hints only for the requested channel", async () => {
    mocks.callGateway.mockRejectedValue(new Error("gateway closed"));
    const config = { channels: { feishu: { appId: "cli_xxx" }, matrix: { enabled: true } } };
    mocks.requireValidConfig.mockResolvedValue(config);
    mocks.resolveCommandConfigWithSecrets.mockResolvedValue({
      resolvedConfig: config,
      effectiveConfig: config,
      diagnostics: [],
    });
    mocks.missingOfficialExternalChannels.add("feishu");
    mocks.missingOfficialExternalChannels.add("matrix");
    mocks.listChannelPlugins.mockReturnValue([]);
    const { runtime } = createCapturingTestRuntime();

    await channelsStatusCommand({ channel: "feishu", probe: false }, runtime as never);

    expect(mocks.repairHintChannelIdCalls).toEqual([["feishu"]]);
  });

  it("excludes visible channels from config-only repair-hint resolution", async () => {
    mocks.callGateway.mockRejectedValue(new Error("gateway closed"));
    const config = {
      channels: { discord: { enabled: true }, feishu: { appId: "cli_xxx" } },
    };
    mocks.requireValidConfig.mockResolvedValue(config);
    mocks.resolveCommandConfigWithSecrets.mockResolvedValue({
      resolvedConfig: config,
      effectiveConfig: config,
      diagnostics: [],
    });
    mocks.missingOfficialExternalChannels.add("feishu");
    const { runtime } = createCapturingTestRuntime();

    await channelsStatusCommand({ probe: false }, runtime as never);

    expect(mocks.repairHintChannelIdCalls).toEqual([["feishu"]]);
  });

  it("keeps JSON fallback structured without rendering config-only text", async () => {
    mocks.callGateway.mockRejectedValue(
      createGatewayTransportError(
        [
          "gateway timeout after 3000ms",
          "Gateway target: wss://user:pass@gateway.example.com/socket?token=secret-token&keep=visible",
          "Gateway fallback: (wss://fallback-user:fallback-pass@[bad-host/socket?token=fallback-secret&keep=visible)",
          "Source: env OPENCLAW_GATEWAY_URL",
        ].join("\n"),
      ),
    );
    mocks.requireValidConfig.mockResolvedValue({ secretResolved: false, channels: {} });
    mocks.resolveCommandConfigWithSecrets.mockResolvedValue({
      resolvedConfig: { secretResolved: true, channels: {} },
      effectiveConfig: { secretResolved: true, channels: {} },
      diagnostics: [],
    });
    const { runtime, logs, errors } = createCapturingTestRuntime();

    await channelsStatusCommand({ channel: "imsg", json: true, probe: false }, runtime as never);

    expect(mocks.listChannelPlugins).not.toHaveBeenCalled();
    expect(mocks.listConfiguredAnnounceChannelIdsForConfig).toHaveBeenCalledOnce();
    const announceRequest = mocks.listConfiguredAnnounceChannelIdsForConfig.mock.calls[0]?.[0] as
      | {
          config?: { secretResolved?: unknown };
          activationSourceConfig?: { secretResolved?: unknown };
        }
      | undefined;
    expect(announceRequest?.config?.secretResolved).toBe(true);
    expect(announceRequest?.activationSourceConfig?.secretResolved).toBe(false);
    const payload = JSON.parse(logs.at(-1) ?? "{}");
    expect(errors).toEqual([]);
    expect(errors.join("\n")).not.toContain("user:pass");
    expect(errors.join("\n")).not.toContain("secret-token");
    expect(errors.join("\n")).not.toContain("fallback-user:fallback-pass");
    expect(errors.join("\n")).not.toContain("fallback-secret");
    expect(payload.error).toContain("Gateway target:");
    expect(payload.error).not.toContain("user:pass");
    expect(payload.error).not.toContain("secret-token");
    expect(payload.error).not.toContain("fallback-user:fallback-pass");
    expect(payload.error).not.toContain("fallback-secret");
    expect(payload.gatewayReachable).toBe(false);
    expect(payload.gatewayAuthUnavailable).toBe(false);
    expect(payload.configOnly).toBe(true);
    expect(payload.configuredChannels).toStrictEqual([]);
  });

  it("treats all as no filter in JSON config-only fallback", async () => {
    mocks.callGateway.mockRejectedValue(new Error("gateway closed"));
    mocks.requireValidConfig.mockResolvedValue({
      channels: { clickclack: { enabled: true } },
    });
    mocks.resolveCommandConfigWithSecrets.mockResolvedValue({
      resolvedConfig: { channels: { clickclack: { enabled: true } } },
      effectiveConfig: { channels: { clickclack: { enabled: true } } },
      diagnostics: [],
    });
    mocks.listConfiguredAnnounceChannelIdsForConfig.mockReturnValue(["clickclack"]);
    const { runtime, logs } = createCapturingTestRuntime();

    await channelsStatusCommand({ channel: "all", json: true, probe: false }, runtime as never);

    const payload = JSON.parse(logs.at(-1) ?? "{}");
    expect(payload.gatewayReachable).toBe(false);
    expect(payload.configOnly).toBe(true);
    expect(payload.configuredChannels).toStrictEqual(["clickclack"]);
  });

  it("filters explicitly configured channels in JSON config-only fallback", async () => {
    mocks.callGateway.mockRejectedValue(new Error("gateway closed"));
    mocks.requireValidConfig.mockResolvedValue({
      channels: { clickclack: { enabled: true }, telegram: { enabled: true } },
    });
    mocks.resolveCommandConfigWithSecrets.mockResolvedValue({
      resolvedConfig: {
        channels: { clickclack: { enabled: true }, telegram: { enabled: true } },
      },
      effectiveConfig: {
        channels: { clickclack: { enabled: true }, telegram: { enabled: true } },
      },
      diagnostics: [],
    });
    mocks.listConfiguredAnnounceChannelIdsForConfig.mockReturnValue(["clickclack", "telegram"]);
    const { runtime, logs } = createCapturingTestRuntime();

    await channelsStatusCommand(
      { channel: "clickclack", json: true, probe: false },
      runtime as never,
    );

    const payload = JSON.parse(logs.at(-1) ?? "{}");
    expect(payload.configuredChannels).toStrictEqual(["clickclack"]);
  });

  it("rejects invalid timeout before falling back to config-only status", async () => {
    const { runtime } = createCapturingTestRuntime();

    await expect(channelsStatusCommand({ timeout: "1000ms" }, runtime as never)).rejects.toThrow(
      'Received: "1000ms"',
    );

    expect(mocks.callGateway).not.toHaveBeenCalled();
    expect(mocks.requireValidConfig).not.toHaveBeenCalled();
  });
});
