// Formatting helpers for status tokens, prompt-cache stats, and daemon runtime snippets.
// These helpers are shared by report rows and command output surfaces.

import { normalizeLowercaseStringOrEmpty } from "@openclaw/normalization-core/string-coerce";
import { sanitizeTerminalText } from "../../packages/terminal-core/src/safe-text.js";
import { formatCliCommand } from "../cli/command-format.js";
import type { BestEffortConfigSnapshot } from "../config/io.js";
import { formatConfigIssueLines } from "../config/issue-format.js";
import type { GatewayServiceRuntime } from "../daemon/service-runtime.js";
import { getSystemdCgroupHygieneSummary } from "../daemon/service-runtime.js";
import { formatRuntimeStatusWithDetails } from "../infra/runtime-status.ts";
import type { SessionStatus } from "../status/types.js";
import { formatTokenCount } from "../utils/token-format.js";
export { shortenText } from "./text-format.js";

export const formatKTokens = formatTokenCount;

/** Formats the actionable entries shown under status config diagnostic headings. */
export const formatStatusConfigDiagnosticEntries = (
  diagnostics: NonNullable<BestEffortConfigSnapshot["configDiagnostics"]>,
): string[] => [
  `- Config file is invalid: ${sanitizeTerminalText(diagnostics.path)}`,
  ...formatConfigIssueLines(diagnostics.issues, "-", { normalizeRoot: true }),
  `- Fix: ${formatCliCommand("openclaw doctor --fix")}`,
];

/** Formats session token usage and prompt-cache hit rate for the sessions table. */
export const formatTokensCompact = (
  sess: Pick<
    SessionStatus,
    "inputTokens" | "totalTokens" | "contextTokens" | "percentUsed" | "cacheRead" | "cacheWrite"
  >,
) => {
  const used = sess.totalTokens;
  const ctx = sess.contextTokens;

  let result;
  if (used == null) {
    result = ctx ? `unknown/${formatKTokens(ctx)} (?%)` : "unknown used";
  } else if (!ctx) {
    result = `${formatKTokens(used)} used`;
  } else {
    const pctLabel = sess.percentUsed != null ? `${sess.percentUsed}%` : "?%";
    result = `${formatKTokens(used)}/${formatKTokens(ctx)} (${pctLabel})`;
  }

  const cacheStats = resolvePromptCacheStats(sess);
  if (cacheStats && cacheStats.cacheRead > 0) {
    result += ` · 🗄️ ${cacheStats.hitRate}% cached`;
  }

  return result;
};

/** Formats prompt-cache details for verbose sessions table output. */
export const formatPromptCacheCompact = (
  sess: Pick<SessionStatus, "inputTokens" | "totalTokens" | "cacheRead" | "cacheWrite">,
) => {
  const cacheStats = resolvePromptCacheStats(sess);
  if (!cacheStats) {
    return "";
  }
  const parts = [`${cacheStats.hitRate}% hit`];
  if (cacheStats.cacheRead > 0) {
    parts.push(`read ${formatKTokens(cacheStats.cacheRead)}`);
  }
  if (cacheStats.cacheWrite > 0) {
    parts.push(`write ${formatKTokens(cacheStats.cacheWrite)}`);
  }
  return parts.join(" · ");
};

function resolvePromptCacheStats(
  sess: Pick<SessionStatus, "inputTokens" | "totalTokens" | "cacheRead" | "cacheWrite">,
) {
  const cacheRead =
    typeof sess.cacheRead === "number" && Number.isFinite(sess.cacheRead) && sess.cacheRead >= 0
      ? sess.cacheRead
      : 0;
  const cacheWrite =
    typeof sess.cacheWrite === "number" && Number.isFinite(sess.cacheWrite) && sess.cacheWrite >= 0
      ? sess.cacheWrite
      : 0;
  if (cacheRead <= 0 && cacheWrite <= 0) {
    return null;
  }
  const inputTokens =
    typeof sess.inputTokens === "number" &&
    Number.isFinite(sess.inputTokens) &&
    sess.inputTokens >= 0
      ? sess.inputTokens
      : undefined;
  const promptTokensFromParts =
    inputTokens != null ? inputTokens + cacheRead + cacheWrite : undefined;
  const used = sess.totalTokens;
  // Legacy entries can carry an undersized totalTokens value. Keep the cache
  // denominator aligned with the prompt-side token fields when available, and
  // never let the fallback denominator drop below the known cached prompt
  // tokens.
  const total =
    promptTokensFromParts ??
    (typeof used === "number" && Number.isFinite(used) && used > 0
      ? Math.max(used, cacheRead + cacheWrite)
      : cacheRead + cacheWrite);
  return {
    cacheRead,
    cacheWrite,
    hitRate: total > 0 ? Math.round((cacheRead / total) * 100) : 0,
  };
}

/** Formats daemon runtime status plus launchd/systemd details into one compact string. */
export const formatDaemonRuntimeShort = (runtime?: GatewayServiceRuntime) => {
  if (!runtime) {
    return null;
  }
  const details: string[] = [];
  const detail = runtime.inspectionFailure ? "" : runtime.detail?.replace(/\s+/g, " ").trim() || "";
  const noisyLaunchctlDetail =
    runtime.missingUnit === true &&
    normalizeLowercaseStringOrEmpty(detail).includes("could not find service");
  // launchctl reports missing units noisily; installed=false already carries that signal.
  if (detail && !noisyLaunchctlDetail) {
    details.push(detail);
  }
  const cgroupSummary = getSystemdCgroupHygieneSummary(runtime.systemd);
  if (cgroupSummary) {
    details.push(cgroupSummary);
  }
  return formatRuntimeStatusWithDetails({
    status: runtime.status,
    pid: runtime.pid,
    state: runtime.state,
    details,
  });
};
