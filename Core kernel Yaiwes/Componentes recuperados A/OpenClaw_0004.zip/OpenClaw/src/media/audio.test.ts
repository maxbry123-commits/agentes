// Audio media tests cover audio type normalization and extension mapping.
import { describe, expect, it } from "vitest";
import { isVoiceCompatibleAudio } from "./audio.js";

describe("isVoiceCompatibleAudio", () => {
  it.each([
    {
      name: "returns true for supported MIME types",
      cases: [
        ...[
          "audio/ogg",
          "audio/opus",
          "audio/mpeg",
          "audio/mp3",
          "audio/mp4",
          "audio/x-m4a",
          "audio/m4a",
        ].map((contentType) => ({
          opts: { contentType, fileName: null },
          expected: true,
        })),
        { opts: { contentType: "audio/ogg; codecs=opus", fileName: null }, expected: true },
        { opts: { contentType: "audio/mp4; codecs=mp4a.40.2", fileName: null }, expected: true },
      ],
    },
    {
      name: "returns true for supported extensions",
      cases: [".oga", ".ogg", ".opus", ".mp3", ".m4a"].map((ext) => ({
        opts: { fileName: `voice${ext}` },
        expected: true,
      })),
    },
    {
      name: "returns false for unsupported MIME types",
      cases: [
        { opts: { contentType: "audio/wav", fileName: null }, expected: false },
        { opts: { contentType: "audio/flac", fileName: null }, expected: false },
        { opts: { contentType: "audio/aac", fileName: null }, expected: false },
        { opts: { contentType: "video/mp4", fileName: null }, expected: false },
      ],
    },
    {
      name: "returns false for unsupported extensions",
      cases: [".wav", ".flac", ".webm"].map((ext) => ({
        opts: { fileName: `audio${ext}` },
        expected: false,
      })),
    },
    {
      name: "keeps fallback edge cases explicit",
      cases: [
        {
          opts: {},
          expected: false,
        },
        {
          opts: { contentType: "audio/mpeg", fileName: "file.wav" },
          expected: true,
        },
      ],
    },
  ])("$name", ({ cases }) => {
    for (const { opts, expected } of cases) {
      expect(isVoiceCompatibleAudio(opts)).toBe(expected);
    }
  });
});
