"""Databricks batch export destination tests using the common test framework."""

import os
import json
import uuid
import typing as t
import datetime as dt
import contextlib
from collections.abc import Callable, Generator

import pytest
import unittest.mock

import numpy as np
from databricks import sql
from databricks.sdk.core import Config, oauth_service_principal
from databricks.sql.exc import ServerOperationError

from posthog.models.integration import Integration
from posthog.models.team import Team
from posthog.temporal.common.base import PostHogWorkflow

from products.batch_exports.backend.service import (
    BaseBatchExportInputs,
    BatchExportField,
    BatchExportModel,
    DatabricksBatchExportInputs,
)
from products.batch_exports.backend.temporal.destinations.databricks_batch_export import (
    DatabricksBatchExportWorkflow,
    databricks_default_fields,
    insert_into_databricks_activity_from_stage,
)
from products.batch_exports.backend.tests.temporal.destinations.base_destination_tests import (
    BaseDestinationTest,
    CommonWorkflowTests,
    RetryableTestException,
    assert_clickhouse_records_in_destination,
)
from products.batch_exports.backend.tests.temporal.utils.persons import (
    generate_test_person_distinct_id2_in_clickhouse,
    generate_test_persons_in_clickhouse,
)

# Note: we add _BE to the env vars to avoid conflicts with env vars the Databricks SDK is automatically looking for,
# which can cause issues.
REQUIRED_ENV_VARS = (
    "DATABRICKS_BE_SERVER_HOSTNAME",
    "DATABRICKS_BE_HTTP_PATH",
    "DATABRICKS_BE_CLIENT_ID",
    "DATABRICKS_BE_CLIENT_SECRET",
)


pytestmark = [
    pytest.mark.django_db,
    pytest.mark.skipif(
        not all(env_var in os.environ for env_var in REQUIRED_ENV_VARS),
        reason=f"Databricks required env vars are not set: {', '.join(REQUIRED_ENV_VARS)}",
    ),
]


class DatabricksDestinationTest(BaseDestinationTest):
    """Databricks-specific implementation of the base destination test interface."""

    @property
    def destination_type(self) -> str:
        return "Databricks"

    @property
    def workflow_class(self) -> type[PostHogWorkflow]:
        return DatabricksBatchExportWorkflow

    @property
    def main_activity(self) -> Callable:
        return insert_into_databricks_activity_from_stage

    @property
    def batch_export_inputs_class(self) -> type[BaseBatchExportInputs]:
        return DatabricksBatchExportInputs

    @property
    def destination_default_fields(self) -> list[BatchExportField]:
        return databricks_default_fields()

    def get_json_columns(self, inputs: BaseBatchExportInputs) -> list[str]:
        assert isinstance(inputs, DatabricksBatchExportInputs)
        if inputs.use_variant_type is True:
            json_columns = ["properties", "person_properties"]
        else:
            json_columns = []
        return json_columns

    def get_destination_config(self, team_id: int) -> dict:
        """Provide test configuration for Databricks destination."""
        return {
            "http_path": os.getenv("DATABRICKS_BE_HTTP_PATH"),
            "catalog": os.getenv("DATABRICKS_CATALOG", f"batch_export_tests"),
            # use a hyphen in the schema name to test we handle it correctly
            "schema": os.getenv("DATABRICKS_SCHEMA", f"test_workflow_schema-{team_id}"),
            # use a hyphen in the table name to test we handle it correctly
            "table_name": f"test_workflow_table-{team_id}",
        }

    async def create_integration(self, team_id: int) -> Integration | None:
        """Create a test integration.

        NOTE: we're using machine-to-machine OAuth here:
        https://docs.databricks.com/aws/en/dev-tools/python-sql-connector#oauth-machine-to-machine-m2m-authentication
        """
        server_hostname = os.getenv("DATABRICKS_BE_SERVER_HOSTNAME")
        integration = await Integration.objects.acreate(
            team_id=team_id,
            kind=Integration.IntegrationKind.DATABRICKS,
            integration_id=server_hostname,
            config={"server_hostname": server_hostname},
            sensitive_config={
                "client_id": os.getenv("DATABRICKS_BE_CLIENT_ID"),
                "client_secret": os.getenv("DATABRICKS_BE_CLIENT_SECRET"),
            },
        )
        return integration

    async def get_inserted_records(
        self,
        team_id: int,
        json_columns: list[str],
        integration: Integration | None = None,
    ) -> list[dict[str, t.Any]]:
        """Get the inserted records from Databricks."""
        if integration is None:
            raise ValueError("Integration is required for Databricks get_inserted_records")

        config = self.get_destination_config(team_id)

        with self.cursor(team_id, integration) as cursor:
            cursor.execute(f"USE CATALOG `{config['catalog']}`")
            cursor.execute(f"USE SCHEMA `{config['schema']}`")
            cursor.execute(f"SELECT * FROM `{config['table_name']}`")
            rows = cursor.fetchall()
            assert cursor.description is not None
            columns = {index: metadata[0] for index, metadata in enumerate(cursor.description)}

        # Rows are tuples, so we construct a dictionary using the metadata from cursor.description.
        # We rely on the order of the columns in each row matching the order set in cursor.description.
        # This seems to be the case, at least for now.
        inserted_records = [
            {
                columns[index]: json.loads(row[index])
                if columns[index] in json_columns and row[index] is not None
                # Databricks uses pytz timezones, so we need to convert them to the datetime.UTC timezone
                else row[index].replace(tzinfo=dt.UTC)
                if isinstance(row[index], dt.datetime)
                # convert from numpy arrays to regular lists
                else row[index].tolist()
                if isinstance(row[index], np.ndarray)
                else row[index]
                for index in columns.keys()
            }
            for row in rows
        ]
        return inserted_records

    def preprocess_records_before_comparison(self, records: list[dict[str, t.Any]]) -> list[dict[str, t.Any]]:
        """Preprocess the records before comparison (if required).

        For Databricks we use a `databricks_ingested_timestamp` field to track when the records were ingested into the destination.
        For this timestamp, we use now64(), which is not suitable for comparison, so we exclude it.
        """
        return [{k: v for k, v in record.items() if k != "databricks_ingested_timestamp"} for record in records]

    async def assert_no_data_in_destination(self, team_id: int, integration: Integration | None = None) -> None:
        """Assert that no data was written to Databricks."""
        try:
            records = await self.get_inserted_records(
                team_id=team_id,
                json_columns=[],
                integration=integration,
            )
            assert len(records) == 0
        except ServerOperationError as e:
            if "TABLE_OR_VIEW_NOT_FOUND" in str(e):
                return
            raise

    @contextlib.contextmanager
    def cursor(self, team_id: int, integration: Integration):
        destination_config = self.get_destination_config(team_id)
        databricks_config = {**destination_config, **integration.config, **integration.sensitive_config}

        def _get_credential_provider():
            config = Config(
                host=f"https://{databricks_config['server_hostname']}",
                client_id=databricks_config["client_id"],
                client_secret=databricks_config["client_secret"],
            )
            return oauth_service_principal(config)

        with sql.connect(
            server_hostname=databricks_config["server_hostname"],
            http_path=databricks_config["http_path"],
            credentials_provider=_get_credential_provider,
        ) as connection:
            with connection.cursor() as cursor:
                yield cursor


class TestDatabricksBatchExportWorkflow(CommonWorkflowTests):
    """Databricks batch export tests using the common test workflow framework.

    This class inherits all the common test patterns and runs them specifically
    for the Databricks destination by providing the DatabricksDestinationTest
    implementation.
    """

    @pytest.fixture(autouse=True)
    def reduce_poll_interval(self):
        """Reduce the poll interval for the Databricks client, in order to speed up the tests."""
        with unittest.mock.patch(
            "products.batch_exports.backend.temporal.destinations.databricks_batch_export.DatabricksClient.DEFAULT_POLL_INTERVAL",
            0.2,
        ):
            yield

    @pytest.fixture
    def destination_test(self, ateam: Team) -> DatabricksDestinationTest:
        """Provide the Databricks-specific test implementation."""
        return DatabricksDestinationTest()

    @pytest.fixture
    async def integration(self, ateam):
        """Create a test integration (for those destinations that require an integration)"""
        destination_test = DatabricksDestinationTest()
        yield await destination_test.create_integration(ateam.pk)

    @pytest.fixture
    def setup_destination(self, ateam: Team, integration: Integration) -> Generator[None, t.Any, t.Any]:
        """Set up and tear down the Databricks schema for tests."""
        destination_test = DatabricksDestinationTest()
        destination_config = destination_test.get_destination_config(ateam.pk)
        with destination_test.cursor(ateam.pk, integration) as cursor:
            cursor.execute(f"USE CATALOG `{destination_config['catalog']}`")
            cursor.execute(f"CREATE SCHEMA IF NOT EXISTS `{destination_config['schema']}`")
            cursor.execute(f"USE SCHEMA `{destination_config['schema']}`")

            yield

            cursor.execute(f"DROP SCHEMA IF EXISTS `{destination_config['schema']}` CASCADE")

    @pytest.fixture
    def simulate_unexpected_error(self):
        with unittest.mock.patch(
            "products.batch_exports.backend.temporal.destinations.databricks_batch_export.Producer.start",
            side_effect=RetryableTestException("A useful error message"),
        ):
            yield

    @pytest.fixture
    def simulate_non_retryable_error(self):
        """Simulate a non-retryable error by raising a ValueError when calling sql.connect.

        Yields the expected error message.
        """
        with unittest.mock.patch(
            "products.batch_exports.backend.temporal.destinations.databricks_batch_export.sql.connect",
            side_effect=ValueError("A simulated connection error"),
        ):
            yield "DatabricksConnectionError: Failed to connect to Databricks. Please check that your connection details are valid."

    # Additional tests specific to Databricks

    async def test_workflow_handles_merge_persons_data_in_follow_up_runs(
        self,
        destination_test: DatabricksDestinationTest,
        interval: str,
        generate_test_data,
        data_interval_start: dt.datetime,
        data_interval_end: dt.datetime,
        ateam,
        batch_export_for_destination,
        clickhouse_client,
        integration: Integration,
        setup_destination,
    ):
        """Test that the Databricks batch export workflow handles merging new versions of person rows.

        This unit tests looks at the mutability handling capabilities of the aforementioned workflow.
        We will generate a new entry in the persons table for half of the persons exported in a first
        run of the workflow. We expect the new entries to have replaced the old ones in Databricks after
        the second run.
        """
        batch_export_model = BatchExportModel(name="persons", schema=None)

        inputs = destination_test.create_batch_export_inputs(
            team_id=ateam.pk,
            data_interval_end=data_interval_end,
            interval=interval,
            batch_export_model=batch_export_model,
            batch_export_schema=None,
            batch_export=batch_export_for_destination,
        )

        run = await destination_test.run_workflow(
            batch_export_id=batch_export_for_destination.id,
            inputs=inputs,
        )
        assert run.status == "Completed"
        _, persons_to_export_created = generate_test_data
        assert run.records_completed == len(persons_to_export_created)
        await assert_clickhouse_records_in_destination(
            destination_test=destination_test,
            team_id=ateam.pk,
            data_interval_start=data_interval_start,
            data_interval_end=data_interval_end,
            batch_export_model=batch_export_model,
            exclude_events=None,
            inputs=inputs,
            integration=integration,
        )

        # generate new versions of persons
        num_new_persons = len(persons_to_export_created) // 2
        for old_person in persons_to_export_created[:num_new_persons]:
            new_person_id = uuid.uuid4()
            new_person, _ = await generate_test_persons_in_clickhouse(
                client=clickhouse_client,
                team_id=ateam.pk,
                start_time=data_interval_start,
                end_time=data_interval_end,
                person_id=new_person_id,
                count=1,
                properties={"utm_medium": "referral", "$initial_os": "Linux", "new_property": "Something"},
            )

            await generate_test_person_distinct_id2_in_clickhouse(
                clickhouse_client,
                ateam.pk,
                person_id=uuid.UUID(new_person[0]["id"]),
                distinct_id=old_person["distinct_id"],
                version=old_person["version"] + 1,
                timestamp=old_person["_timestamp"],
            )

        # run the workflow again
        run = await destination_test.run_workflow(
            batch_export_id=batch_export_for_destination.id,
            inputs=inputs,
        )
        assert run.status == "Completed"
        assert run.records_completed == len(persons_to_export_created)
        await assert_clickhouse_records_in_destination(
            destination_test=destination_test,
            team_id=ateam.pk,
            data_interval_start=data_interval_start,
            data_interval_end=data_interval_end,
            batch_export_model=batch_export_model,
            exclude_events=None,
            inputs=inputs,
            integration=integration,
        )

    @pytest.mark.parametrize("use_automatic_schema_evolution", [True, False])
    @pytest.mark.parametrize(
        "model_name,missing_column,pre_created_table_columns",
        [
            pytest.param(
                "persons",
                "created_at",
                [
                    ("team_id", "BIGINT"),
                    ("distinct_id", "STRING"),
                    ("person_id", "STRING"),
                    ("properties", "VARIANT"),
                    ("person_distinct_id_version", "BIGINT"),
                    ("person_version", "BIGINT"),
                    ("is_deleted", "BOOLEAN"),
                ],
                id="persons-missing-created_at",
            ),
            pytest.param(
                "events",
                "person_properties",
                [
                    ("uuid", "STRING"),
                    ("event", "STRING"),
                    ("properties", "VARIANT"),
                    ("distinct_id", "STRING"),
                    ("team_id", "BIGINT"),
                    ("timestamp", "TIMESTAMP"),
                    ("created_at", "TIMESTAMP"),
                    ("databricks_ingested_timestamp", "TIMESTAMP"),
                ],
                id="events-missing-person_properties",
            ),
        ],
    )
    async def test_workflow_handles_model_schema_changes(
        self,
        use_automatic_schema_evolution: bool,
        model_name: str,
        missing_column: str,
        pre_created_table_columns: list[tuple[str, str]],
        destination_test: DatabricksDestinationTest,
        interval: str,
        generate_test_data,
        data_interval_start: dt.datetime,
        data_interval_end: dt.datetime,
        ateam,
        batch_export_for_destination,
        integration: Integration,
        setup_destination,
    ):
        """Test that the Databricks batch export workflow handles changes to the model schema.

        If we update the schema of the model we export, we should still be able to export the data without breaking
        existing exports.
        To replicate this situation we create the destination table with a schema that predates `missing_column`
        and then run the export.

        Databricks supports automatic schema evolution, which means the target table will automatically be updated with
        the schema of the source table (no columns will ever be dropped from the target table however). For the persons
        model this happens in the MERGE, for the events model in the COPY INTO.

        If `use_automatic_schema_evolution` is True, the target table will automatically be updated with the new
        column.

        If `use_automatic_schema_evolution` is False, the target table will not be updated with the new column, and
        the export should proceed without it.
        """

        # create the table manually, specifically without `missing_column`
        destination_config = batch_export_for_destination.destination.config
        catalog = destination_config["catalog"]
        schema = destination_config["schema"]
        table_name = destination_config["table_name"]
        column_ddl = ",\n".join(f"`{name}` {field_type}" for name, field_type in pre_created_table_columns)
        query = f"""
        CREATE TABLE IF NOT EXISTS `{catalog}`.`{schema}`.`{table_name}` (
            {column_ddl}
        )
        USING DELTA
        COMMENT 'PostHog generated table'
        """
        with destination_test.cursor(ateam.pk, integration) as cursor:
            cursor.execute(query)

        batch_export_model = BatchExportModel(name=model_name, schema=None)

        inputs = destination_test.create_batch_export_inputs(
            team_id=ateam.pk,
            data_interval_end=data_interval_end,
            interval=interval,
            batch_export_model=batch_export_model,
            batch_export_schema=None,
            batch_export=batch_export_for_destination,
            use_automatic_schema_evolution=use_automatic_schema_evolution,
        )

        run = await destination_test.run_workflow(
            batch_export_id=batch_export_for_destination.id,
            inputs=inputs,
        )

        assert run.status == "Completed"
        events_to_export_created, persons_to_export_created = generate_test_data
        expected_records = persons_to_export_created if model_name == "persons" else events_to_export_created
        assert run.records_completed == len(expected_records)
        await assert_clickhouse_records_in_destination(
            destination_test=destination_test,
            team_id=ateam.pk,
            data_interval_start=data_interval_start,
            data_interval_end=data_interval_end,
            batch_export_model=batch_export_model,
            exclude_events=None,
            inputs=inputs,
            integration=integration,
            # if `use_automatic_schema_evolution` is False, we expect `missing_column` to be dropped
            fields_to_exclude=[missing_column] if use_automatic_schema_evolution is False else [],
        )

        # check that `missing_column` is present or not in the destination
        records_from_destination = await destination_test.get_inserted_records(
            team_id=ateam.pk,
            json_columns=destination_test.get_json_columns(inputs),
            integration=integration,
        )
        if use_automatic_schema_evolution is True:
            assert missing_column in records_from_destination[0]
        else:
            assert missing_column not in records_from_destination[0]

    async def test_workflow_raises_incompatible_schema_error_when_target_table_schema_is_wrong(
        self,
        destination_test: DatabricksDestinationTest,
        interval: str,
        generate_test_data,
        data_interval_start: dt.datetime,
        data_interval_end: dt.datetime,
        ateam,
        batch_export_for_destination,
        integration: Integration,
        setup_destination,
    ):
        # Pre-create the target table with a schema that doesn't match the persons model. None of
        # these columns match the merge keys (`team_id`, `distinct_id`), so the MERGE condition
        # references columns that can't be resolved on the target.
        destination_config = batch_export_for_destination.destination.config
        catalog = destination_config["catalog"]
        schema = destination_config["schema"]
        table_name = destination_config["table_name"]
        query = f"""
        CREATE TABLE IF NOT EXISTS `{catalog}`.`{schema}`.`{table_name}` (
            `wrong_id` BIGINT,
            `wrong_data` STRING
        )
        USING DELTA
        COMMENT 'User created table with the wrong schema'
        """
        with destination_test.cursor(ateam.pk, integration) as cursor:
            cursor.execute(query)

        batch_export_model = BatchExportModel(name="persons", schema=None)

        inputs = destination_test.create_batch_export_inputs(
            team_id=ateam.pk,
            data_interval_end=data_interval_end,
            interval=interval,
            batch_export_model=batch_export_model,
            batch_export_schema=None,
            batch_export=batch_export_for_destination,
        )

        run = await destination_test.run_workflow(
            batch_export_id=batch_export_for_destination.id,
            inputs=inputs,
        )

        assert run.status == "Failed"
        assert run.latest_error is not None
        assert "DatabricksIncompatibleSchemaError" in run.latest_error

    async def test_workflow_cleans_up_volume_and_stage_table_if_there_is_an_error(
        self,
        destination_test: DatabricksDestinationTest,
        interval: str,
        generate_test_data,
        data_interval_start: dt.datetime,
        data_interval_end: dt.datetime,
        ateam,
        batch_export_for_destination,
        clickhouse_client,
        integration: Integration,
        setup_destination,
    ):
        """Test that the Databricks batch export workflow cleans up the volume and stage table if there is an error.

        If there is an error during the export, we should clean up the volume and stage table, otherwise we will try to
        merge in duplicate data in a follow up run, causing Databricks to raise another error, such as:
        "Cannot perform Merge as multiple source rows matched and attempted to modify the same target row in the Delta
        table in possibly conflicting ways"
        """
        batch_export_model = BatchExportModel(name="persons", schema=None)

        inputs = destination_test.create_batch_export_inputs(
            team_id=ateam.pk,
            data_interval_end=data_interval_end,
            interval=interval,
            batch_export_model=batch_export_model,
            batch_export_schema=None,
            batch_export=batch_export_for_destination,
        )

        with unittest.mock.patch(
            "products.batch_exports.backend.temporal.destinations.databricks_batch_export.DatabricksClient.amerge_tables",
            side_effect=ValueError("A simulated error during merge"),
        ):
            run = await destination_test.run_workflow(
                batch_export_id=batch_export_for_destination.id,
                inputs=inputs,
                expect_workflow_failure=True,
            )

        assert run.status == "FailedRetryable"

        # Verify that the volume and stage table have been cleaned up
        destination_config = destination_test.get_destination_config(ateam.pk)
        data_interval_end_str = data_interval_end.strftime("%Y-%m-%d_%H-%M-%S")
        # Attempt number is always 1 in tests
        expected_volume_name = f"stage_{destination_config['table_name']}_{data_interval_end_str}_{ateam.pk}_1"
        expected_stage_table_name = f"stage_{destination_config['table_name']}_{data_interval_end_str}_{ateam.pk}_1"

        with destination_test.cursor(ateam.pk, integration) as cursor:
            cursor.execute(f"USE CATALOG `{destination_config['catalog']}`")
            cursor.execute(f"USE SCHEMA `{destination_config['schema']}`")

            # Check that the volume does not exist
            cursor.execute("SHOW VOLUMES")
            volumes = cursor.fetchall()
            volume_names = [row["volume_name"] for row in volumes] if volumes else []
            assert expected_volume_name not in volume_names, (
                f"Expected volume '{expected_volume_name}' to be cleaned up, but it still exists"
            )

            # Check that the stage table does not exist
            cursor.execute("SHOW TABLES")
            tables = cursor.fetchall()
            table_names = [row["tableName"] for row in tables] if tables else []
            assert expected_stage_table_name not in table_names, (
                f"Expected stage table '{expected_stage_table_name}' to be cleaned up, but it still exists"
            )
