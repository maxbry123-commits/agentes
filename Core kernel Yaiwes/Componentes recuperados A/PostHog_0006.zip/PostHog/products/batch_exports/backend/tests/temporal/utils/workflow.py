import uuid
import contextlib

import pytest

from asgiref.sync import sync_to_async
from temporalio import activity
from temporalio.client import WorkflowFailureError
from temporalio.exceptions import ActivityError, ApplicationError

from products.batch_exports.backend.models.batch_export import BatchExportRun
from products.batch_exports.backend.service import create_batch_export_run
from products.batch_exports.backend.temporal.batch_exports import StartBatchExportRunInputs

# Guards against a workflow that never settles. Deliberately real time, not a Temporal
# `execution_timeout`: the time-skipping environment charges both real activity time and fast-forwarded
# retry backoffs against a workflow deadline, so it expires for reasons unrelated to the behavior under
# test and reports `TimeoutError` in place of the error being asserted on.
WORKFLOW_REAL_TIME_LIMIT_SECONDS = 60


@activity.defn(name="start_batch_export_run")
async def mocked_start_batch_export_run(inputs: StartBatchExportRunInputs) -> str:
    """Create a run and return some count >0 to avoid early return."""
    run = await sync_to_async(create_batch_export_run)(
        batch_export_id=uuid.UUID(inputs.batch_export_id),
        data_interval_start=inputs.data_interval_start,
        data_interval_end=inputs.data_interval_end,
        status=BatchExportRun.Status.STARTING,
    )

    return str(run.id)


@contextlib.contextmanager
def fail_on_application_error():
    """Context manager to fail the test if an application error is raised.

    Tests typically fail if a WorkflowFailureError is raised, but the error traceback you get back is not very helpful
    as it just contains the traceback from within Temporal's own code.
    This context manager will parse the error and fail the test with a more helpful message and trackback from our own
    code, which helps debug the issue.
    """
    try:
        yield
    except WorkflowFailureError as e:
        # try to parse the root cause of the error in case it's an error from our own code
        if isinstance(e.cause, ActivityError):
            if isinstance(e.cause.cause, ApplicationError):
                message = e.cause.cause.message
                error_type = e.cause.cause.type
                failure = e.cause.cause.failure
                stack_trace = failure.stack_trace if failure else None

                detailed_error = (
                    f"Workflow failed with an ApplicationError:\n\n  Error: {message}\n\n  Error Type: {error_type}\n"
                )
                if stack_trace:
                    detailed_error += f"  Error Stack Trace: {stack_trace}\n"

                pytest.fail(detailed_error)
        # not an application error, re-raise (which will also cause the test to fail)
        raise
