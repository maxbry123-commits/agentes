import typing
import datetime as dt
from datetime import timedelta
from enum import IntEnum
from math import ceil
from zoneinfo import ZoneInfo

from django.db import models
from django.db.models import Q

import pytz

# This import prevents a circular import during Django app loading.
# The import chain: apps.py -> tasks -> async_migrations/definition.py -> models.utils
# triggers models/__init__.py which imports batch_exports.models. Without this import,
# ModelActivityMixin is loaded before Django apps are ready, causing AppRegistryNotReady.
from posthog.clickhouse.client import sync_execute  # noqa: F401
from posthog.helpers.encrypted_fields import EncryptedJSONField
from posthog.models.activity_logging.model_activity import ModelActivityMixin
from posthog.models.scoping.root_mixin import TeamScopedRootMixin
from posthog.models.utils import UUIDTModel

# this is what is used by the Team model
# (we could use common_timezones instead; this has 433 timezones vs 596 for all_timezones)
TIMEZONES = [(tz, tz) for tz in pytz.all_timezones]

# All destination types that share the s3-export Temporal workflow.
# Includes the legacy "S3" alias for backwards compatibility.
S3_FAMILY_TYPES: frozenset[str] = frozenset({"S3", "AwsS3", "S3Compatible"})

# S3-family types that can be created via the API. The legacy "S3" type is excluded:
# existing rows keep working, but new destinations must use "AwsS3" or "S3Compatible".
S3_CREATABLE_TYPES: frozenset[str] = frozenset({"AwsS3", "S3Compatible"})


class DayOfWeek(IntEnum):
    """Day of the week enum for batch export schedules.

    Values match Temporal's day_of_week format (0=Sunday, 6=Saturday) and is also aligns with the WeekStartDay enum in
    the Team model.
    """

    SUNDAY = 0
    MONDAY = 1
    TUESDAY = 2
    WEDNESDAY = 3
    THURSDAY = 4
    FRIDAY = 5
    SATURDAY = 6

    @property
    def name_capitalized(self) -> str:
        """Return the capitalized day name (e.g., 'Sunday', 'Monday')."""
        return self.name.capitalize()


class BatchExportDestination(UUIDTModel):
    """A model for the destination that a PostHog BatchExport will target.

    This model answers the question: where are we exporting data? It contains
    all the necessary information to interact with a specific destination. As we
    wish to support multiple destinations, this forces us to relax schema
    requirements for any configuration parameters, as different destinations
    will have different configuration parameters.
    """

    class Meta:
        db_table = "posthog_batchexportdestination"

    class Destination(models.TextChoices):
        """Enumeration of supported destinations for PostHog BatchExports."""

        S3 = "S3"  # legacy alias; AwsS3 / S3Compatible are the preferred types for new rows
        AWS_S3 = "AwsS3"
        S3_COMPATIBLE = "S3Compatible"
        SNOWFLAKE = "Snowflake"
        POSTGRES = "Postgres"
        REDSHIFT = "Redshift"
        BIGQUERY = "BigQuery"
        DATABRICKS = "Databricks"
        AZURE_BLOB = "AzureBlob"
        WORKFLOWS = "Workflows"
        HTTP = "HTTP"
        NOOP = "NoOp"
        FILE_DOWNLOAD = "FileDownload"

    secret_fields = {
        "S3": {"aws_access_key_id", "aws_secret_access_key"},
        "AwsS3": {"aws_access_key_id", "aws_secret_access_key"},
        "S3Compatible": {"aws_access_key_id", "aws_secret_access_key"},
        "Snowflake": {"user", "password", "private_key", "private_key_passphrase"},
        "Postgres": {"user", "password"},
        "Redshift": {"user", "password", "aws_access_key_id", "aws_secret_access_key"},
        "BigQuery": {"private_key", "private_key_id", "client_email", "token_uri"},
        "Databricks": set(),  # uses Integration model to store credentials
        "AzureBlob": set(),  # uses Integration model to store credentials
        "HTTP": {"token"},
        "NoOp": set(),
        "Workflows": set(),
        "FileDownload": set(),
    }

    type = models.CharField(
        choices=Destination,
        max_length=64,
        help_text="A choice of supported BatchExportDestination types.",
    )
    config = EncryptedJSONField(
        default=dict,
        ignore_decrypt_errors=True,
        blank=True,
        help_text="A JSON field to store all configuration parameters required to access a BatchExportDestination.",
    )
    created_at = models.DateTimeField(
        auto_now_add=True,
        help_text="The timestamp at which this BatchExportDestination was created.",
    )
    last_updated_at = models.DateTimeField(
        auto_now=True,
        help_text="The timestamp at which this BatchExportDestination was last updated.",
    )
    integration = models.ForeignKey(
        "posthog.Integration",
        on_delete=models.SET_NULL,
        help_text="The integration for this destination.",
        null=True,
        blank=True,
    )


class BatchExportSource(TeamScopedRootMixin, UUIDTModel):
    """A model for the source of the data that a PostHog BatchExport will export.

    This model answers the question: what data are we exporting? For now it holds a
    HogQL query whose results are exported, but it's designed to grow into the single
    place that captures how a batch export selects its data (data warehouse view
    references, export mode, data interval field, primary and version keys) in future.
    """

    class Meta:
        db_table = "posthog_batchexportsource"

    # `db_constraint=False`: a real FK constraint to the hot `posthog_team` table would
    # take a lock on it while being created. Team scoping is enforced at the app level
    # via `TeamScopedRootMixin`. See products/README.md "Adding or moving backend models
    # and migrations".
    team = models.ForeignKey(
        "posthog.Team",
        on_delete=models.CASCADE,
        db_constraint=False,
        help_text="The team this belongs to.",
    )
    hogql_query = models.TextField(
        null=True,
        blank=True,
        help_text="The HogQL query whose results are exported.",
    )
    created_at = models.DateTimeField(
        auto_now_add=True,
        help_text="The timestamp at which this BatchExportSource was created.",
    )
    last_updated_at = models.DateTimeField(
        auto_now=True,
        help_text="The timestamp at which this BatchExportSource was last updated.",
    )


class BatchExportRun(UUIDTModel):
    """A single run of a PostHog batch export defined by its data interval bounds.

    It is used to keep track of the status of the export and once it finishes to
    store any result metadata, and errors that may have occurred during the process.
    """

    class Meta:
        db_table = "posthog_batchexportrun"
        constraints = [
            models.CheckConstraint(
                check=(
                    Q(batch_export__isnull=False, batch_export_on_demand__isnull=True)
                    | Q(batch_export__isnull=True, batch_export_on_demand__isnull=False)
                ),
                name="run_has_exactly_one_parent_batch_export_or_batch_export_on_demand",
            )
        ]

    class Status(models.TextChoices):
        """Possible states of the BatchExportRun."""

        CANCELLED = "Cancelled"
        COMPLETED = "Completed"
        CONTINUED_AS_NEW = "ContinuedAsNew"
        FAILED = "Failed"
        FAILED_RETRYABLE = "FailedRetryable"
        FAILED_BILLING = "FailedBilling"
        TERMINATED = "Terminated"
        TIMEDOUT = "TimedOut"
        RUNNING = "Running"
        STARTING = "Starting"

    batch_export = models.ForeignKey(
        "BatchExport",
        on_delete=models.CASCADE,
        null=True,
        help_text="The `BatchExport` this run belongs to.",
    )
    batch_export_on_demand = models.ForeignKey(
        "BatchExportOnDemand",
        on_delete=models.CASCADE,
        null=True,
        help_text="The `BatchExportOnDemand` this run belongs to.",
    )
    status = models.CharField(choices=Status, max_length=64, help_text="The status of this run.")
    records_completed = models.IntegerField(null=True, help_text="The number of records that have been exported.")
    records_failed = models.IntegerField(
        null=True,
        help_text="The number of records that failed downstream processing (e.g. hog function execution errors).",
    )
    latest_error = models.TextField(null=True, help_text="The latest error that occurred during this run.")
    data_interval_start = models.DateTimeField(help_text="The start of the data interval.", null=True)
    data_interval_end = models.DateTimeField(help_text="The end of the data interval.")
    cursor = models.TextField(null=True, help_text="An opaque cursor that may be used to resume.")
    created_at = models.DateTimeField(
        auto_now_add=True,
        help_text="The timestamp at which this BatchExportRun was created.",
    )
    finished_at = models.DateTimeField(
        null=True,
        help_text="The timestamp at which this BatchExportRun finished, successfully or not.",
    )
    last_updated_at = models.DateTimeField(
        auto_now=True,
        help_text="The timestamp at which this BatchExportRun was last updated.",
    )
    records_total_count = models.IntegerField(
        null=True, help_text="The total count of records that should be exported in this BatchExportRun."
    )
    backfill = models.ForeignKey(
        "BatchExportBackfill",
        on_delete=models.SET_NULL,
        help_text="The backfill this run belongs to.",
        null=True,
        blank=True,
        related_name="runs",
        related_query_name="run",
    )
    bytes_exported = models.BigIntegerField(
        null=True, blank=True, help_text="The number of bytes that have been exported in this BatchExportRun."
    )

    @property
    def workflow_id(self) -> str:
        """Return the Workflow id that corresponds to this model."""
        parent = self.parent

        if isinstance(parent, BatchExport):
            return f"{parent.id}-{self.data_interval_end:%Y-%m-%dT%H:%M:%S}Z"

        if isinstance(parent, BatchExportOnDemand):
            return (
                f"{parent.id}-{self.data_interval_start:%Y-%m-%dT%H:%M:%S}Z-{self.data_interval_end:%Y-%m-%dT%H:%M:%S}Z"
            )

        typing.assert_never(parent)

    @property
    def parent(self) -> "BatchExport | BatchExportOnDemand":
        """Get this run's parent batch export.

        It is enforced by a check constraint that either a `BatchExport` or a
        `BatchExportOnDemand` must be defined in this run, but we must communicate that
        to the Python type checker too via this property.
        """
        if self.batch_export is not None:
            return self.batch_export
        if self.batch_export_on_demand is not None:
            return self.batch_export_on_demand

        raise ValueError("One of batch export or batch export on demand must always be defined")


BATCH_EXPORT_INTERVALS = [
    ("hour", "hour"),
    ("day", "day"),
    ("week", "week"),
    ("every 5 minutes", "every 5 minutes"),
    ("every 15 minutes", "every 15 minutes"),
]

BATCH_EXPORT_INTERVAL_TO_START_JITTER = {
    "hour": timedelta(minutes=15),
    "day": timedelta(minutes=20),
    "week": timedelta(minutes=30),
}


class BatchExport(ModelActivityMixin, UUIDTModel):
    """A model for a PostHog batch export that runs on a schedule.

    A batch export exports data from PostHog to the configured destination on a
    schedule given by its `interval`, `interval_offset`, and `timezone`.

    An instance of a batch export for a particular period of the schedule is called a
    "run", and runs are modelled by the `BatchExportRun` model.

    Old periods of time can be re-exported by executing a "backfill", even periods from
    before the batch export was created. Backfills are modelled via the
    `BatchExportBackfill` model.
    """

    class Meta:
        db_table = "posthog_batchexport"

    class Model(models.TextChoices):
        """Possible data models that this BatchExport can export."""

        EVENTS = "events"
        PERSONS = "persons"
        SESSIONS = "sessions"
        HOGQL = "hogql"

    team = models.ForeignKey("posthog.Team", on_delete=models.CASCADE, help_text="The team this belongs to.")
    name = models.TextField(help_text="A human-readable name for this BatchExport.")
    destination = models.ForeignKey(
        "BatchExportDestination",
        on_delete=models.CASCADE,
        help_text="The destination to export data to.",
    )
    source = models.ForeignKey(
        "BatchExportSource",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        help_text="The source of the data to export. When set, takes precedence over `model`.",
    )
    interval = models.CharField(
        max_length=64,
        null=False,
        choices=BATCH_EXPORT_INTERVALS,
        default="hour",
        help_text="The interval at which to export data.",
    )
    paused = models.BooleanField(default=False, help_text="Whether this BatchExport is paused or not.")
    deleted = models.BooleanField(default=False, help_text="Whether this BatchExport is deleted or not.")
    created_at = models.DateTimeField(
        auto_now_add=True,
        help_text="The timestamp at which this BatchExport was created.",
    )
    last_updated_at = models.DateTimeField(
        auto_now=True,
        help_text="The timestamp at which this BatchExport was last updated.",
    )
    last_paused_at = models.DateTimeField(
        null=True,
        default=None,
        help_text="The timestamp at which this BatchExport was last paused.",
    )
    start_at = models.DateTimeField(
        null=True,
        default=None,
        help_text="Time before which any Batch Export runs won't be triggered.",
    )
    end_at = models.DateTimeField(
        null=True,
        default=None,
        help_text="Time after which any Batch Export runs won't be triggered.",
    )

    schema = models.JSONField(
        null=True,
        default=None,
        help_text="A schema of custom fields to select when exporting data.",
    )

    model = models.CharField(
        max_length=64,
        null=True,
        blank=True,
        choices=Model,
        default=Model.EVENTS,
        help_text="Which model this BatchExport is exporting.",
    )
    filters = models.JSONField(null=True, blank=True)
    # determines the timezone used for daily or weekly exports
    timezone = models.CharField(max_length=240, choices=TIMEZONES, default="UTC")
    # interval offset allows for batch exports to start at a custom time
    # (eg daily exports can be configured to run at 1am local time by setting this to 3600)
    interval_offset = models.IntegerField(
        null=True,
        blank=True,
        help_text="The offset in seconds from the start of the default interval that this batch export should run at.",
    )

    @property
    def latest_runs(self):
        """Return the latest 10 runs for this batch export."""
        return self.batchexportrun_set.all().order_by("-created_at")[:10]

    @property
    def interval_time_delta(self) -> timedelta:
        """Return a datetime.timedelta that corresponds to this batch export's interval."""
        if self.interval == "hour":
            return timedelta(hours=1)
        elif self.interval == "day":
            return timedelta(days=1)
        elif self.interval == "week":
            return timedelta(weeks=1)
        elif self.interval.startswith("every"):
            _, value, unit = self.interval.split(" ")
            kwargs = {unit: int(value)}
            return timedelta(**kwargs)
        raise ValueError(f"Invalid interval: '{self.interval}'")

    @property
    def jitter(self) -> timedelta:
        """Return jitter for this batch export based on interval.

        We always want the start jitter to be less than the frequency, as
        otherwise a batch export run could start after it's batch period has
        elapsed. But there is margin to tweak this under that upper limit.

        So, the values set here are quite arbitrary and are adjusted based on
        how other systems react to batch exports load.

        Note that for daily and weekly exports, we allow the user to configure
        the start hour of the export, therefore we don't want to make the jitter
        too large.
        """
        if self.interval in ("hour", "day", "week"):
            return BATCH_EXPORT_INTERVAL_TO_START_JITTER[self.interval]
        elif self.interval.startswith("every"):
            # This yields 1 minute for 5 minute batch exports, which is the only
            # "every" interval in use currently.
            # In the future, we can extend this to have different handling for
            # different "every" intervals.
            return self.interval_time_delta / 5

        raise ValueError(f"Invalid interval: '{self.interval}'")

    @property
    def timezone_info(self) -> ZoneInfo:
        """Return the timezone info for this batch export."""
        return ZoneInfo(self.timezone or "UTC")

    @property
    def offset_day(self) -> int | None:
        """Return the offset day for this batch export.

        For a weekly schedule, this is the day of the week to start at (0-6, where 0 is Sunday).
        Sunday is 0 since this is what is used by Temporal and Sunday is also the default week start day in PostHog.
        For all other intervals, this is None.
        """
        if self.interval == "week":
            if self.interval_offset is None:
                return int(DayOfWeek.SUNDAY)  # default to Sunday
            day_value = self.interval_offset // (24 * 3600)
            return int(DayOfWeek(day_value))
        return None

    @property
    def offset_day_name(self) -> str | None:
        """Return the offset day name for this batch export.

        For a weekly schedule, this is the name of the day to start at (Sunday, Monday, etc.).
        For all other intervals, this is None.
        """
        offset_day = self.offset_day
        if offset_day is None:
            return None
        return DayOfWeek(offset_day).name_capitalized

    @property
    def offset_hour(self) -> int | None:
        """Return the offset hour for this batch export.

        For a daily or weekly schedule, this is the hour to start at (0-23).
        For all other intervals, this is None.

        Note: we don't support sub-hour offsets at the moment so we can assume the offset is always an
        integer number of hours.
        """
        if self.interval == "day" or self.interval == "week":
            if self.interval_offset is None:
                return 0  # default to midnight
            offset_in_hours = self.interval_offset // 3600
            return offset_in_hours % 24
        return None


def get_batch_exports_using_integration(team_id: int, integration_id: int) -> list[BatchExport]:
    """Return a list of batch exports using integration_id.

    This is used to check when destroying an integration if it is not in use,
    as otherwise users could get themselves into an undesired state.

    We only consider batch exports that are not deleted, as deleted batch
    exports are not relevant to users.
    """
    return list(
        BatchExport.objects.filter(
            team_id=team_id,
            deleted=False,
            destination__in=BatchExportDestination.objects.filter(integration_id=integration_id),
        ).only("id", "name")
    )


class BatchExportBackfill(UUIDTModel):
    class Meta:
        db_table = "posthog_batchexportbackfill"

    class Status(models.TextChoices):
        """Possible states of the BatchExportBackfill."""

        CANCELLED = "Cancelled"
        COMPLETED = "Completed"
        CONTINUED_AS_NEW = "ContinuedAsNew"
        FAILED = "Failed"
        FAILED_RETRYABLE = "FailedRetryable"
        TERMINATED = "Terminated"
        TIMEDOUT = "TimedOut"
        RUNNING = "Running"
        STARTING = "Starting"

    team = models.ForeignKey("posthog.Team", on_delete=models.CASCADE, help_text="The team this belongs to.")
    batch_export = models.ForeignKey(
        "BatchExport",
        on_delete=models.CASCADE,
        help_text="The BatchExport this backfill belongs to.",
    )
    start_at = models.DateTimeField(help_text="The start of the data interval.", null=True)
    end_at = models.DateTimeField(help_text="The end of the data interval.", null=True)
    status = models.CharField(choices=Status, max_length=64, help_text="The status of this backfill.")
    created_at = models.DateTimeField(
        auto_now_add=True,
        help_text="The timestamp at which this BatchExportBackfill was created.",
    )
    finished_at = models.DateTimeField(
        null=True,
        help_text="The timestamp at which this BatchExportBackfill finished, successfully or not.",
    )
    last_updated_at = models.DateTimeField(
        auto_now=True,
        help_text="The timestamp at which this BatchExportBackfill was last updated.",
    )
    total_records_count = models.BigIntegerField(
        null=True,
        blank=True,
        help_text="The total number of records to export. Initially estimated, updated with actual count after completion.",
    )
    adjusted_start_at = models.DateTimeField(
        null=True,
        blank=True,
        help_text="The actual start time after adjustment for earliest available data. May differ from start_at if user requested a date before data exists.",
    )

    @property
    def workflow_id(self) -> str:
        """Return the Workflow id that corresponds to this BatchExportBackfill model."""
        end_at = self.end_at.astimezone(tz=dt.UTC).isoformat() if self.end_at else "END"
        # we use the start_at rather than adjusted_start_at here since the workflow ID for this batch export is created
        # before the backfill is started
        start_at = self.start_at.astimezone(tz=dt.UTC).isoformat() if self.start_at else "START"

        return f"{self.batch_export.id}-Backfill-{start_at}-{end_at}"

    @property
    def total_expected_runs(self) -> int | None:
        """Return the total number of expected runs for this backfill, based on the number of intervals."""
        start_at = self.adjusted_start_at or self.start_at
        # if no start_at then it means we're backfilling all data in a single run
        if start_at is None:
            return 1

        if self.total_records_count == 0:
            return 0

        end_at = self.end_at
        # if the backfill has no end_at then it means it's backfilling everything up to the 'present' (whatever that
        # is defined as depends on whether the backfill is still running or not)
        if not end_at and self.finished_at:
            # if backfill has finished then we can use the finished_at as the approximate end_at
            end_at = self.finished_at
        elif not end_at and self.status == self.Status.RUNNING:
            # if backfill is still running then we use the current time as the approximate end_at (it will obviously
            # keep changing but is arguably better than returning nothing if a user wants to know a rough estimate of
            # progress)
            end_at = dt.datetime.now(tz=dt.UTC)
        elif not end_at:
            # we didn't always populated finished_at in the past, so probably don't have enough information
            return None
        return ceil((end_at - start_at) / self.batch_export.interval_time_delta)

    def get_finished_runs(self) -> int:
        """Return the number of finished runs for this backfill.

        This is primarily used to report progress of this backfill.
        Note that this is just approximate since:
        a) we don't know how many records are in each run of the backfill
        b) some runs may have been cancelled or terminated (these are excluded since they may be retried manually and we
            don't want to double count them)
        """
        return BatchExportRun.objects.filter(
            backfill=self,
            status__in=[
                BatchExportRun.Status.COMPLETED,
                BatchExportRun.Status.FAILED,
            ],
        ).count()


class BatchExportFileDownload(ModelActivityMixin, UUIDTModel):
    """Represents a file made available to download by a batch export.

    When creating a "file-download" batch export, the output is a row in this table
    containing pre-signed URLs to access the data exported.
    """

    class Meta:
        db_table = "posthog_batchexportfiledownload"
        indexes = [
            models.Index(fields=["team", "key"], name="team_key_idx"),
        ]

    team = models.ForeignKey("posthog.Team", on_delete=models.CASCADE, help_text="The team this belongs to.")
    batch_export_run = models.ForeignKey(
        "BatchExportRun",
        on_delete=models.CASCADE,
        help_text="The batch export run that generated this file downloads.",
    )
    key = models.TextField(help_text="The S3 key containing the file to download.")
    expires_at = models.DateTimeField(null=True, help_text="When will this key expire, if available.")

    created_at = models.DateTimeField(
        auto_now_add=True,
        help_text="The timestamp at which this was created.",
    )
    last_updated_at = models.DateTimeField(
        auto_now=True,
        help_text="The timestamp at which this was last updated.",
    )

    def is_expired(self) -> bool:
        """Return whether this file download is expired.

        If expired, then the file download should not be used to generate download URLs anymore.
        """
        if self.expires_at is None:
            raise ValueError("Cannot determine if object is expired: `expires_at` missing.")

        return dt.datetime.now(dt.UTC) > self.expires_at

    def is_expired_or_close(self, threshold: dt.timedelta | int = dt.timedelta(hours=1)) -> bool:
        """Return whether this file download is expired, or close to expiring."""
        if self.is_expired():
            return True

        delta = self.expires_at - dt.datetime.now(dt.UTC)  # type: ignore

        if isinstance(threshold, int):
            threshold_delta = dt.timedelta(seconds=threshold)
        else:
            threshold_delta = threshold

        return threshold_delta > delta


class BatchExportOnDemand(TeamScopedRootMixin, ModelActivityMixin, UUIDTModel):
    """A model for a PostHog batch export triggered on demand.

    Shares a lot of similarities with a `BatchExport`, with the big difference that
    an on demand batch export does not run on a schedule.
    """

    class Meta:
        db_table = "posthog_batchexportondemand"

    class Model(models.TextChoices):
        """Possible data models that this BatchExport can export."""

        EVENTS = "events"
        PERSONS = "persons"
        SESSIONS = "sessions"
        HOGQL = "hogql"

    team = models.ForeignKey("posthog.Team", on_delete=models.CASCADE, help_text="The team this belongs to.")
    destination = models.ForeignKey(
        "BatchExportDestination",
        on_delete=models.CASCADE,
        help_text="The destination to export data to.",
    )
    source = models.ForeignKey(
        "BatchExportSource",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        help_text="The source of the data to export. When set, takes precedence over `model`.",
    )
    deleted = models.BooleanField(default=False, help_text="Whether this is deleted or not.")
    created_at = models.DateTimeField(
        auto_now_add=True,
        help_text="The timestamp at which this was created.",
    )
    last_updated_at = models.DateTimeField(
        auto_now=True,
        help_text="The timestamp at which this was last updated.",
    )
    model = models.CharField(
        max_length=64,
        null=True,
        blank=True,
        choices=Model,
        default=Model.EVENTS,
        help_text="Which model this batch export is exporting.",
    )
    filters = models.JSONField(null=True, blank=True)
