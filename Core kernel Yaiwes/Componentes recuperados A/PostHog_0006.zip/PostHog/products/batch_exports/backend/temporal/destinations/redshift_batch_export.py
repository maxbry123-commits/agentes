import io
import json
import typing
import asyncio
import datetime as dt
import functools
import posixpath
import contextlib
import dataclasses
import collections.abc

from django.conf import settings

import psycopg
import pyarrow as pa
import aioboto3
import botocore.exceptions
from psycopg import sql
from structlog.contextvars import bind_contextvars
from temporalio import activity, exceptions, workflow
from temporalio.common import RetryPolicy

from posthog.dataclasses import frozen
from posthog.models import Team
from posthog.models.integration import (
    TLS,
    Authority,
    AWSRedshiftIntegration,
    AWSRedshiftRoleBasedIntegration,
    AWSS3Integration,
    AWSS3RoleBasedIntegration,
    Credentials,
    Integration,
    IntegrationError,
    RedshiftIntegration,
)
from posthog.temporal.common.base import PostHogWorkflow
from posthog.temporal.common.heartbeat import Heartbeater
from posthog.temporal.common.logger import get_logger, get_write_only_logger

from products.batch_exports.backend.service import (
    AWSCredentials,
    BatchExportField,
    BatchExportInsertInputs,
    BatchExportModel,
    BatchExportSchema,
    IAMRole,
    IntegrationID,
    RedshiftBatchExportInputs,
)
from products.batch_exports.backend.temporal.batch_exports import (
    StartBatchExportRunInputs,
    default_fields,
    get_data_interval,
    is_over_billing_limit_error,
    start_batch_export_run,
)
from products.batch_exports.backend.temporal.destinations.postgres_batch_export import (
    Fields,
    PostgreSQLClient,
    PostgreSQLField,
    _PostgreSQLClientInputsProtocol,
)
from products.batch_exports.backend.temporal.destinations.s3_batch_export import (
    ConcurrentS3Consumer,
    PolicyStatement,
    RefreshCoroutine,
    get_credentials_using_user_aws_role,
    s3_client,
)
from products.batch_exports.backend.temporal.destinations.utils import get_absolute_key_prefix
from products.batch_exports.backend.temporal.pipeline.consumer import Consumer, run_consumer_from_stage
from products.batch_exports.backend.temporal.pipeline.entrypoint import execute_batch_export_using_internal_stage
from products.batch_exports.backend.temporal.pipeline.producer import Producer
from products.batch_exports.backend.temporal.pipeline.transformer import (
    ParquetStreamTransformer,
    RedshiftQueryStreamTransformer,
)
from products.batch_exports.backend.temporal.pipeline.types import BatchExportResult
from products.batch_exports.backend.temporal.queue import RecordBatchQueue, wait_for_schema_or_producer
from products.batch_exports.backend.temporal.utils import (
    JsonType,
    cast_record_batch_schema_json_columns,
    handle_non_retryable_errors,
)

LOGGER = get_write_only_logger(__name__)
EXTERNAL_LOGGER = get_logger()

NON_RETRYABLE_ERROR_TYPES = (
    # The integration backing this export is missing, of the wrong kind, or
    # misconfigured. Retrying can never recover it.
    "IntegrationError",
    # Raised on errors that are related to database operation.
    # For example: unexpected disconnect, database or other object not found.
    "OperationalError",
    # The schema name provided is invalid (usually because it doesn't exist).
    "InvalidSchemaName",
    # Missing permissions to, e.g., insert into table.
    "InsufficientPrivilege",
    # A column, usually properties, exceeds the limit for a VARCHAR field,
    # usually the max of 65535 bytes
    "StringDataRightTruncation",
    "StringLimitExceededError",
    # Raised by our PostgreSQL client when failing to connect after several attempts.
    "PostgreSQLConnectionError",
    # Column missing in Redshift, likely the schema was altered.
    "UndefinedColumn",
    # Raised by our PostgreSQL client when a given feature is not supported.
    # This can also happen when merging tables with a different number of columns:
    # "Target relation and source relation must have the same number of columns"
    "FeatureNotSupported",
    # There is a mismatch between the schema of the table and our data. This
    # usually means the table was created by the user, as we resolve types the
    # same way every time.
    "DatatypeMismatch",
    # Raised when multiple S3 operations failed with a ClientError.
    "ClientErrorGroup",
    # Raised by PostgreSQL client when a function doesn't exist for the specified types.
    # This can indicate, for example, attempting to compare two types that cannot be
    # compared.
    "UndefinedFunction",
    # Unretryable error raised by S3 client when using `copy_into_redshift_activity_from_stage`.
    "ClientError",
    # An S3 bucket doesn't exist when using `copy_into_redshift_activity_from_stage`.
    "NoSuchBucket",
    # S3 parameter validation failed.
    "ParamValidationError",
    # Invalid S3 credentials when using `copy_into_redshift_activity_from_stage`.
    "InvalidCredentialsError",
    # Raised by Redshift client when the cluster has insufficient system resources.
    "InsufficientSystemResourcesError",
    # The S3 credentials provided for the COPY can't read the staged files.
    "InsufficientS3PermissionsError",
    # Redshift failed to COPY the staged files from S3 (IAM role auth, cause not locally confirmable).
    # These (read access, region, manifest) don't self-heal, so retrying is pointless.
    "RedshiftS3CopyError",
)


class StringLimitExceededError(Exception):
    """Error raised when exceeding Redshift VARCHAR limit."""

    def __init__(self, column: str | None, table: str, schema: str):
        if column:
            msg = f"Column '{column}' "
        else:
            msg = f"A column "

        msg += (
            f"in '{schema}.{table}' exceeds Redshift's string limit and cannot be exported."
            " The 'json_parse_truncate_strings' setting can be enabled in Redshift to"
            " automatically truncate strings to the maximum limit."
        )

        super().__init__(msg)


class InsufficientSystemResourcesError(Exception):
    """Error raised when the Redshift cluster has insufficient system resources.

    For example: "Insufficient system resources to support data size: consider increasing compute size. (Disk Full)"
    """

    pass


class InsufficientS3PermissionsError(Exception):
    """Error raised when Redshift cannot read the staged files from S3 during COPY.

    Redshift surfaces a missing read permission as the misleading "COPY with MANIFEST parameter
    requires full path of an S3 object" error rather than a clean access-denied. We translate it
    into something actionable once we've confirmed S3 read is denied with the same credentials.
    """

    def __init__(self, bucket: str):
        super().__init__(
            f"Redshift could not read the staged files from S3 bucket '{bucket}'."
            " The S3 credentials provided for the Redshift COPY are missing read access"
            " (Redshift requires both 's3:GetObject' and 's3:ListBucket')."
            " If the bucket uses SSE-KMS encryption, 'kms:Decrypt' on the key is also required."
            " Grant read access and retry."
        )


class RedshiftS3CopyError(Exception):
    """Error raised when Redshift fails to COPY the staged files from S3 and we can't pin down why.

    Used for IAM role auth, which we can't probe locally to confirm a read denial. The message points
    at the common causes of a failed COPY so the user knows where to look.
    """

    def __init__(self, bucket: str):
        super().__init__(
            f"Redshift could not COPY the staged files from S3 bucket '{bucket}'."
            " Common causes: the IAM role provided for the Redshift COPY lacks read access to the"
            " bucket (Redshift requires 's3:GetObject' and 's3:ListBucket', plus 'kms:Decrypt' if the"
            " bucket uses SSE-KMS encryption), or the bucket is in a different AWS region than the"
            " Redshift cluster. Verify the role's permissions and the bucket region, then retry."
        )


class ClientErrorGroup(ExceptionGroup):
    """Exception group wrapping multiple `botocore.exceptions.ClientError`.

    We detail each operation that failed, summarizing the results if only one type
    of operation failed with the same error multiple times. This is common in situations
    when permissions are missing.
    """

    def __new__(cls, exceptions: collections.abc.Sequence[botocore.exceptions.ClientError]):
        ops = {}
        for err in exceptions:
            op_name = err.operation_name
            error_code = err.response.get("Error", {}).get("Code", "Unknown")

            if op_name not in ops:
                ops[op_name] = {error_code}

            else:
                ops[op_name].add(error_code)

        if len(ops) == 1:
            op_name, error_codes = next(iter(ops.items()))

            if len(error_codes) == 1:
                # One type of operation failed, one error.
                error_code = next(iter(error_codes))

                self = super().__new__(
                    ClientErrorGroup, f"S3 operation '{op_name}' failed with error: '{error_code}'", exceptions
                )
            else:
                # One type of operation failed, but with multiple errors.
                self = super().__new__(
                    ClientErrorGroup,
                    f"S3 operation '{op_name}' failed with multiple errors: {', '.join(f"'{error_code}'" for error_code in error_codes)}",
                    exceptions,
                )
        else:
            # Many operations failed with multiple errors.
            pairs = ((op_name, error_code) for op_name, error_codes in ops.items() for error_code in error_codes)

            self = super().__new__(
                ClientErrorGroup,
                f"Multiple S3 operations failed: {', '.join(f"'{op_name}' failed with error '{error_code}'" for op_name, error_code in pairs)}",
                exceptions,
            )

        # This __new__ is based on the documentation on subclassing exception groups:
        # https://docs.python.org/3.12/library/exceptions.html#ExceptionGroup
        # Not sure how to tell mypy this is "fine".
        self.ops = ops  # type: ignore

        return self

    def derive(self, excs):
        return ClientErrorGroup(excs)


class RedshiftClient(PostgreSQLClient):
    @contextlib.asynccontextmanager
    async def connect(self) -> collections.abc.AsyncIterator[typing.Self]:
        """Manage a Redshift connection.

        This just yields a Postgres connection but we adjust a couple of things required for
        psycopg to work with Redshift:
        1. Set UNICODE encoding to utf-8 as Redshift reports back UNICODE.
        2. Set prepare_threshold to None on the connection as psycopg attempts to run DEALLOCATE ALL otherwise
            which is not supported on Redshift.
        """
        psycopg._encodings._py_codecs["UNICODE"] = "utf-8"
        psycopg._encodings.py_codecs.update((k.encode(), v) for k, v in psycopg._encodings._py_codecs.items())

        async with super().connect():
            self.connection.prepare_threshold = None
            yield self

    @contextlib.asynccontextmanager
    async def async_client_cursor(self) -> collections.abc.AsyncIterator[psycopg.AsyncClientCursor]:
        """Yield a AsyncClientCursor from a psycopg.AsyncConnection.

        Keeps track of the current cursor_factory to set it after we are done.
        """
        current_factory = self.connection.cursor_factory
        self.connection.cursor_factory = psycopg.AsyncClientCursor

        try:
            async with self.connection.cursor() as cursor:
                # Not a fan of typing.cast, but we know this is an psycopg.AsyncClientCursor
                # as we have just set cursor_factory.
                cursor = typing.cast(psycopg.AsyncClientCursor, cursor)
                yield cursor
        finally:
            self.connection.cursor_factory = current_factory

    async def amerge_tables(
        self,
        final_table_name: str,
        stage_table_name: str,
        schema: str,
        merge_key: Fields,
        update_key: Fields,
        final_table_fields: Fields,
        stage_fields_cast_to_super: collections.abc.Container[str] | None = None,
        remove_duplicates: bool = True,
        skip_delete: bool = False,
    ) -> None:
        """Merge two tables in Redshift.

        This can handle transforming fields into 'SUPER' type if required by setting
        `stage_fields_cast_to_super`, with the `JSON_PARSE` Redshift function.
        """
        if schema:
            final_table_identifier = sql.Identifier(schema, final_table_name)
            stage_table_identifier = sql.Identifier(schema, stage_table_name)

        else:
            final_table_identifier = sql.Identifier(final_table_name)
            stage_table_identifier = sql.Identifier(stage_table_name)

        and_separator = sql.SQL("AND")
        merge_condition = and_separator.join(
            sql.SQL("{final_field} = {stage_field}").format(
                final_field=sql.Identifier(schema, final_table_name, field[0]),
                stage_field=sql.Identifier("stage", field[0]),
            )
            for field in merge_key
        )

        # Redshift doesn't support adding a condition on the merge, so we have
        # to first delete any rows in stage that match those in final, where
        # stage also has a higher version. Otherwise we risk merging adding old
        # versions back.
        delete_condition = and_separator.join(
            sql.SQL("{final_field} = {stage_field}").format(
                final_field=sql.Identifier("final", field[0]),
                stage_field=sql.Identifier(schema, stage_table_name, field[0]),
            )
            for field in merge_key
        )

        or_separator = sql.SQL(" OR ")
        delete_extra_conditions = or_separator.join(
            sql.SQL("{stage_field} < {final_field}").format(
                final_field=sql.Identifier("final", field[0]),
                stage_field=sql.Identifier(schema, stage_table_name, field[0]),
            )
            for field in update_key
        )

        delete_query = sql.SQL(
            """\
        DELETE FROM {stage_table}
        USING {final_table} AS final
        WHERE {merge_condition}
        AND ({delete_extra_conditions})
        """
        ).format(
            final_table=final_table_identifier,
            stage_table=stage_table_identifier,
            merge_condition=delete_condition,
            delete_extra_conditions=delete_extra_conditions,
        )

        if stage_fields_cast_to_super is not None:
            select_stage_table_fields = sql.SQL(",").join(
                sql.SQL("JSON_PARSE({field}) AS {field}").format(field=sql.Identifier(field[0]))
                if field[0] in stage_fields_cast_to_super
                else sql.Identifier(field[0])
                for field in final_table_fields
            )
        else:
            select_stage_table_fields = sql.SQL(",").join(sql.Identifier(field[0]) for field in final_table_fields)

        merge_query = sql.SQL(
            """\
        MERGE INTO {final_table}
        USING (
            SELECT {select_stage_table_fields}
            FROM {stage_table}
        ) AS stage
        ON {merge_condition}
        """
        ).format(
            final_table=final_table_identifier,
            select_stage_table_fields=select_stage_table_fields,
            stage_table=stage_table_identifier,
            merge_condition=merge_condition,
        )
        if remove_duplicates:
            merge_query = merge_query + sql.SQL("REMOVE DUPLICATES")
        else:
            update_values = sql.SQL(",").join(
                sql.SQL("{final_field} = {stage_field}").format(
                    final_field=sql.Identifier(field[0]),
                    stage_field=sql.Identifier("stage", field[0]),
                )
                for field in final_table_fields
            )

            insert_values = sql.SQL(",").join(
                sql.SQL("{stage_field}").format(
                    stage_field=sql.Identifier("stage", field[0]),
                )
                for field in final_table_fields
            )

            merge_query = merge_query + sql.SQL(
                """\
                WHEN MATCHED THEN UPDATE SET {update_values}
                WHEN NOT MATCHED THEN INSERT VALUES ({insert_values})
                """
            ).format(update_values=update_values, insert_values=insert_values)

        # This means the default is to not lock, even if we can't get the isolation level.
        isolation_level = await self.aget_isolation_level()
        needs_lock = isolation_level == "SERIALIZABLE"

        async with self.connection.transaction():
            async with self.connection.cursor() as cursor:
                if needs_lock:
                    await cursor.execute(sql.SQL("LOCK TABLE {final_table}").format(final_table=final_table_identifier))
                    self.logger.info("Table locked")

                try:
                    if not skip_delete:
                        await cursor.execute(delete_query)
                except psycopg.errors.UndefinedFunction:
                    self.logger.exception(
                        "Query failed",
                        table=final_table_name,
                        schema=schema,
                        stage_table=stage_table_name,
                        query="DELETE",
                        full_query=delete_query,
                    )
                    self.external_logger.error(  # noqa: TRY400
                        "A non-retryable 'UndefinedFunction' error happened when attempting to"
                        " delete existing rows from '%s.%s' before a 'MERGE' command can be executed."
                        " This can indicate that the schema of the table does not match what the"
                        " batch export expects."
                        " Please review the table schema before retrying again, there may be fields"
                        " that have been created with incorrect types. The batch export will always"
                        " create a table with the correct schema if it doesn't already exist.",
                        schema,
                        final_table_name,
                    )
                    raise

                try:
                    await cursor.execute(merge_query)
                except psycopg.errors.InternalError_ as e:
                    self.logger.exception(
                        "Query failed",
                        table=final_table_name,
                        schema=schema,
                        stage_table=stage_table_name,
                        query="MERGE",
                        full_query=merge_query,
                    )
                    if "String value exceeds the max size of 65535" in str(e):
                        raise StringLimitExceededError(column=None, schema=schema, table=final_table_name) from e
                    else:
                        raise

    async def aget_isolation_level(self) -> typing.Literal["SERIALIZABLE", "SNAPSHOT", "UNKNOWN"]:
        """Return the isolation level from the current database.

        This method is safe in the sense that it will never raise: In case of any
        issues, 'UNKNOWN' will be returned.
        """
        try:
            async with self.connection.transaction():
                async with self.connection.cursor() as cursor:
                    await cursor.execute(
                        sql.SQL("SELECT isolation_level FROM STV_DB_ISOLATION_LEVEL WHERE db_name = %s"),
                        (self.database,),
                    )
                    row = await cursor.fetchone()
        except Exception as e:
            if isinstance(e, psycopg.errors.InsufficientPrivilege):
                self.logger.warning("Insufficient privileges to get isolation level")
            else:
                self.logger.exception("Check isolation level failed")
            return "UNKNOWN"

        else:
            if not row:
                return "UNKNOWN"

            isolation_level = row[0]

            match isolation_level.lower():
                case "serializable":
                    return "SERIALIZABLE"
                case "snapshot isolation":
                    return "SNAPSHOT"
                case _:
                    return "UNKNOWN"

    async def acopy_from_s3_bucket(
        self,
        table_name: str,
        parquet_fields: list[str],
        schema_name: str,
        s3_bucket: str,
        manifest_key: str,
        authorization: IAMRole | AWSCredentials,
    ) -> None:
        table_identifier = sql.Identifier(schema_name, table_name)

        s3_files = sql.Literal(f"s3://{s3_bucket}/{manifest_key}")

        if isinstance(authorization, AWSCredentials):
            credentials: sql.SQL | sql.Composed = sql.SQL(
                """
                ACCESS_KEY_ID {access_key_id}
                SECRET_ACCESS_KEY {secret_access_key}
                """
            ).format(
                access_key_id=sql.Literal(authorization.aws_access_key_id),
                secret_access_key=sql.Literal(authorization.aws_secret_access_key),
            )

            if authorization.aws_session_token is not None:
                credentials += sql.SQL(
                    """
                    SESSION_TOKEN {session_token}
                    """
                ).format(session_token=sql.Literal(authorization.aws_session_token))

        else:
            if authorization == "default":
                credentials = sql.SQL("IAM_ROLE default")
            else:
                credentials = sql.SQL("IAM_ROLE {iam_role}").format(iam_role=sql.Literal(authorization))

        copy_query = sql.SQL(
            """
        COPY {table_name} ({fields})
        FROM {s3_files}
        {credentials}
        MANIFEST
        FORMAT AS PARQUET
        SERIALIZETOJSON
        """
        ).format(
            table_name=table_identifier,
            fields=sql.SQL(",").join(sql.Identifier(field) for field in parquet_fields),
            s3_files=s3_files,
            credentials=credentials,
        )

        async with self.connection.transaction():
            async with self.connection.cursor() as cursor:
                try:
                    await cursor.execute(copy_query)
                except psycopg.errors.InternalError_ as err:
                    msg_detail = err.diag.message_detail
                    # This error is generic, and not well parsed by psycopg
                    # so we have to do some awkward substring check.
                    if msg_detail is not None and all(
                        s in msg_detail
                        for s in (
                            "Spectrum Scan Error",
                            "length of the data column",
                            "longer than the length defined in the table",
                        )
                    ):
                        try:
                            column = msg_detail.split("length of the data column ", 1)[1].split(" ")[0]
                        except Exception:
                            column = "unknown"

                        raise StringLimitExceededError(column, table_name, schema_name)
                    raise


def redshift_default_fields() -> list[BatchExportField]:
    batch_export_fields = default_fields()
    batch_export_fields.append(
        {
            "expression": "nullIf(JSONExtractString(properties, '$ip'), '')",
            "alias": "ip",
        }
    )
    # Fields kept or removed for backwards compatibility with legacy apps schema.
    batch_export_fields.append({"expression": "''", "alias": "elements"})
    batch_export_fields.append({"expression": "''", "alias": "site_url"})
    batch_export_fields.pop(batch_export_fields.index({"expression": "created_at", "alias": "created_at"}))
    # Team ID is (for historical reasons) an INTEGER (4 bytes) in PostgreSQL, but in ClickHouse is stored as Int64.
    # We can't encode it as an Int64, as this includes 4 extra bytes, and PostgreSQL will reject the data with a
    # 'incorrect binary data format' error on the column, so we cast it to Int32.
    team_id_field = batch_export_fields.pop(
        batch_export_fields.index(BatchExportField(expression="team_id", alias="team_id"))
    )
    team_id_field["expression"] = "toInt32(team_id)"
    batch_export_fields.append(team_id_field)
    return batch_export_fields


def get_redshift_fields_from_record_schema(
    record_schema: pa.Schema, known_super_columns: collections.abc.Container[str], use_super: bool
) -> Fields:
    """Generate a list of supported Redshift fields from PyArrow schema.

    This function is used to map custom schemas to Redshift-supported types. Some loss of precision is
    expected.
    """
    pg_schema: list[PostgreSQLField] = []

    for name in record_schema.names:
        if name == "_inserted_at":
            continue

        pa_field = record_schema.field(name)

        if pa.types.is_string(pa_field.type) or isinstance(pa_field.type, JsonType):
            if pa_field.name in known_super_columns and use_super is True:
                pg_type = "SUPER"
            else:
                # Redshift treats `TEXT` as `VARCHAR(256)`, not as unlimited length like PostgreSQL.
                # So, instead of `TEXT` we use the largest possible `VARCHAR`.
                # See: https://docs.aws.amazon.com/redshift/latest/dg/r_Character_types.html
                pg_type = "VARCHAR(65535)"

        elif pa.types.is_signed_integer(pa_field.type) or pa.types.is_unsigned_integer(pa_field.type):
            if pa.types.is_uint64(pa_field.type) or pa.types.is_int64(pa_field.type):
                pg_type = "BIGINT"
            else:
                pg_type = "INTEGER"

        elif pa.types.is_floating(pa_field.type):
            if pa.types.is_float64(pa_field.type):
                pg_type = "DOUBLE PRECISION"
            else:
                pg_type = "REAL"

        elif pa.types.is_boolean(pa_field.type):
            pg_type = "BOOLEAN"

        elif pa.types.is_timestamp(pa_field.type):
            if pa_field.type.tz is not None:
                pg_type = "TIMESTAMPTZ"
            else:
                pg_type = "TIMESTAMP"

        elif pa.types.is_list(pa_field.type) and pa.types.is_string(pa_field.type.value_type):
            pg_type = "SUPER"

        else:
            raise TypeError(f"Unsupported type in field '{name}': '{pa_field.type}'")

        pg_schema.append((name, pg_type))

    return pg_schema


@frozen
class S3StageBucketParameters:
    name: str
    region_name: str
    credentials: IAMRole | AWSCredentials | IntegrationID


@frozen
class CopyParameters:
    s3_bucket: S3StageBucketParameters
    s3_key_prefix: str
    authorization: IAMRole | AWSCredentials | IntegrationID


@frozen
class ConnectionParameters:
    user: str
    password: str = dataclasses.field(repr=False)
    host: str
    port: int
    database: str
    has_self_signed_cert: bool = False

    def credentials(self) -> Credentials:
        user = self.user
        password = self.password
        return Credentials(user, password)

    def authority(self) -> Authority:
        host = self.host
        port = self.port
        return Authority(host, port)

    def tls(self) -> TLS:
        return TLS(ssl_mode="prefer" if settings.TEST else "require")


@frozen
class ServerConnectionParameters:
    """Location of a Redshift server for exports whose credentials live in an integration.

    `host` is None when a plain Redshift integration carries the host itself.
    """

    database: str
    port: int
    host: str | None = None


@dataclasses.dataclass
class TableParameters:
    schema_name: str
    name: str
    properties_data_type: str = "varchar"


@frozen
class RedshiftCopyActivityInputs:
    """Inputs for Redshift copy activity."""

    batch_export: BatchExportInsertInputs
    connection: ConnectionParameters | ServerConnectionParameters
    table: TableParameters
    copy: CopyParameters
    integration_id: IntegrationID | None = None


@frozen
class RedshiftInsertInputs:
    """Inputs for Redshift insert activity."""

    batch_export: BatchExportInsertInputs
    connection: ConnectionParameters | ServerConnectionParameters
    table: TableParameters
    integration_id: IntegrationID | None = None


class RedshiftConsumer(Consumer):
    def __init__(
        self,
        client: RedshiftClient,
        table: str,
    ):
        super().__init__()

        self.client = client
        self.current_file_index = 0
        self.current_buffer = io.BytesIO()

        self.logger = self.logger.bind(table=table)

    async def consume_chunk(self, data: bytes):
        self.current_buffer.write(data)
        await asyncio.sleep(0)

    async def finalize_file(self):
        await self._upload_current_buffer()
        self._start_new_file()

    def _start_new_file(self):
        """Start a new file (reset state for file splitting)."""
        self.current_file_index += 1

    async def finalize(self):
        """Finalize by uploading any remaining data."""
        await self._upload_current_buffer()

    async def _upload_current_buffer(self):
        buffer_size = self.current_buffer.tell()
        if buffer_size == 0:
            return

        self.logger.debug(
            "Insert query starting",
            current_file_index=self.current_file_index,
            buffer_size=buffer_size,
        )

        self.current_buffer.seek(0)

        async with self.client.async_client_cursor() as cursor:
            async with self.client.connection.transaction():
                try:
                    await cursor.execute(self.current_buffer.read())
                except psycopg.errors.InternalError_ as err:
                    self.logger.exception("Error executing insert query", error=str(err))
                    self.external_logger.error("Error executing insert query: %s", str(err))  # noqa: TRY400
                    if "Insufficient system resources" in str(err):
                        raise InsufficientSystemResourcesError(str(err)) from err
                    else:
                        raise

        self.logger.debug(
            "Insert query finished",
            current_file_index=self.current_file_index,
            buffer_size=buffer_size,
        )

        self.current_buffer = io.BytesIO()


class TableSchemas(typing.NamedTuple):
    table_schema: Fields
    stage_table_schema: Fields
    super_columns: set[str]
    use_super: bool


def _get_table_schemas(
    model: BatchExportModel | BatchExportSchema | None,
    record_batch_schema: pa.Schema,
    properties_data_type: str,
) -> TableSchemas:
    """Return the schemas used for main and stage tables."""
    known_super_columns = {"properties", "set", "set_once", "person_properties"}
    if properties_data_type != "varchar":
        properties_type = "SUPER"
        use_super = True

    else:
        properties_type = "VARCHAR(65535)"
        use_super = False

    if model is None or (isinstance(model, BatchExportModel) and model.name == "events"):
        table_schema: Fields = [  # ty: ignore[invalid-assignment]
            ("uuid", "VARCHAR(200)"),
            ("event", "VARCHAR(200)"),
            ("properties", properties_type),
            ("elements", "VARCHAR(65535)"),
            ("set", properties_type),
            ("set_once", properties_type),
            ("distinct_id", "VARCHAR(200)"),
            ("team_id", "INTEGER"),
            ("ip", "VARCHAR(200)"),
            ("site_url", "VARCHAR(200)"),
            ("timestamp", "TIMESTAMP WITH TIME ZONE"),
            ("person_properties", properties_type),
        ]

    else:
        table_schema = get_redshift_fields_from_record_schema(
            record_batch_schema, known_super_columns=known_super_columns, use_super=properties_type == "SUPER"
        )

    if properties_type == "SUPER":
        # Update stage schema to first load as VARBYTE, and later JSON_PARSE to SUPER
        stage_table_schema: Fields = [
            (field[0], field[1] if field[0] not in known_super_columns else "VARBYTE(16777216)")
            for field in table_schema
        ]
    else:
        stage_table_schema = table_schema

    return TableSchemas(table_schema, stage_table_schema, known_super_columns, use_super)


class RequiredMergeSettings(typing.NamedTuple):
    requires_merge: typing.Literal[True]
    merge_key: Fields
    update_key: Fields
    primary_key: Fields


class NotRequiredMergeSettings(typing.NamedTuple):
    requires_merge: typing.Literal[False]


MergeSettings = RequiredMergeSettings | NotRequiredMergeSettings


def _get_merge_settings(
    model: BatchExportModel | BatchExportSchema | None,
    use_super: bool = False,
) -> MergeSettings:
    """Return merge settings for models that require merging."""
    merge_key: Fields
    update_key: Fields
    primary_key: Fields

    if isinstance(model, BatchExportModel) and model.name == "persons":
        merge_key = [
            ("team_id", "INT"),
            ("distinct_id", "TEXT"),
        ]
        update_key = [
            ("person_version", "INT"),
            ("person_distinct_id_version", "INT"),
        ]
        primary_key = (("team_id", "INTEGER"), ("distinct_id", "VARCHAR(200)"))

        return RequiredMergeSettings(
            requires_merge=True, merge_key=merge_key, update_key=update_key, primary_key=primary_key
        )

    elif isinstance(model, BatchExportModel) and model.name == "sessions":
        merge_key = [
            ("team_id", "INT"),
            ("session_id", "TEXT"),
        ]
        update_key = [
            ("end_timestamp", "TIMESTAMP"),
        ]
        primary_key = (("team_id", "INTEGER"), ("session_id", "TEXT"))

        return RequiredMergeSettings(
            requires_merge=True, merge_key=merge_key, update_key=update_key, primary_key=primary_key
        )
    elif (model is None or (isinstance(model, BatchExportModel) and model.name == "events")) and use_super is True:
        merge_key = [("uuid", "TEXT")]
        update_key = [("timestamp", "TIMESTAMP")]
        primary_key = [("uuid", "TEXT")]

        return RequiredMergeSettings(
            requires_merge=True, merge_key=merge_key, update_key=update_key, primary_key=primary_key
        )
    else:
        return NotRequiredMergeSettings(requires_merge=False)


async def _get_redshift_integration(
    integration_id: int, team_id: int
) -> AWSRedshiftRoleBasedIntegration | AWSRedshiftIntegration | RedshiftIntegration:
    """Fetch a Redshift integration from the database."""
    try:
        integration = await Integration.objects.aget(id=integration_id, team_id=team_id)
    except Integration.DoesNotExist:
        raise IntegrationError(f"Redshift integration with ID '{integration_id}' not found for team '{team_id}'")

    if integration.kind != Integration.IntegrationKind.AWS_REDSHIFT:
        raise IntegrationError(
            f"Integration with ID '{integration_id}' for team '{team_id}' is not a Redshift integration "
            f"(kind='{integration.kind}')"
        )
    if "aws_role_arn" in integration.config:
        return AWSRedshiftRoleBasedIntegration(integration)
    elif "aws_access_key_id" in integration.sensitive_config:
        return AWSRedshiftIntegration(integration)
    else:
        return RedshiftIntegration(integration)


async def _get_aws_s3_integration(integration_id: int, team_id: int) -> AWSS3RoleBasedIntegration | AWSS3Integration:
    """Fetch an AWS S3 integration from the database."""
    try:
        integration = await Integration.objects.aget(id=integration_id, team_id=team_id)
    except Integration.DoesNotExist:
        raise IntegrationError(f"AWS S3 integration with ID '{integration_id}' not found for team '{team_id}'")

    if integration.kind != Integration.IntegrationKind.AWS_S3:
        raise IntegrationError(
            f"Integration with ID '{integration_id}' for team '{team_id}' is not an S3 integration "
            f"(kind='{integration.kind}')"
        )
    if "aws_role_arn" in integration.config:
        return AWSS3RoleBasedIntegration(integration)
    else:
        return AWSS3Integration(integration)


@frozen
class RedshiftCredentials:
    user: str
    password: str = dataclasses.field(repr=False)


@frozen
class ProvisionedCluster:
    """A provisioned Redshift cluster parsed from its endpoint hostname."""

    cluster_identifier: str
    region: str


@frozen
class ServerlessWorkgroup:
    """A Redshift Serverless workgroup parsed from its endpoint hostname."""

    workgroup: str
    account_id: str
    region: str


def _parse_redshift_host(host: str) -> ProvisionedCluster | ServerlessWorkgroup:
    """Parse a Redshift endpoint hostname into its cluster or workgroup location."""
    match host.split(".", maxsplit=3):
        case [cluster_identifier, _, region, "redshift.amazonaws.com"]:
            return ProvisionedCluster(cluster_identifier=cluster_identifier, region=region)
        case [workgroup, account_id, region, "redshift-serverless.amazonaws.com"]:
            return ServerlessWorkgroup(workgroup=workgroup, account_id=account_id, region=region)
        case _:
            raise IntegrationError(
                f"Redshift host '{host}' is not a recognized AWS Redshift endpoint. Expected "
                "'<cluster>.<id>.<region>.redshift.amazonaws.com' or "
                "'<workgroup>.<account>.<region>.redshift-serverless.amazonaws.com'"
            )


def _get_host_from_connection(connection: ConnectionParameters | ServerConnectionParameters) -> str:
    if connection.host is None:
        raise IntegrationError(
            "An AWS Redshift integration requires the cluster endpoint to be set as 'host' in the "
            "batch export configuration"
        )
    return connection.host


async def _get_temporary_redshift_credentials(
    aws_credentials: AWSCredentials,
    *,
    server: ProvisionedCluster | ServerlessWorkgroup,
    user: str,
    database: str,
    auto_create: bool | None = None,
    groups: list[str] | None = None,
) -> RedshiftCredentials:
    """Use AWS APIs to obtain temporary Redshift credentials.

    This will return a username and password to be used to authenticate to
    Redshift. Note that the returned user will be the same as user but it will
    include the prefix IAM: or IAMA: (depending on the value of `auto_create`).
    This prefix must be preserved when authenticating.

    If auto_create is True, then the user or role given by aws_credentials must
    also be allowed to redshift:CreateClusterUser on the dbuser resource. If the
    user already exists then no new users will be created, even if
    auto_create=True.

    Automatically created users do not have any permissions. Thus, usually
    groups should be set when auto_create=True. This parameter indicates which
    groups is the user meant to join on creation, which is usually needed when
    the user is automatically created. However, this is not a strict
    requirement.

    The AWS role or user requires redshift:JoinGroup on each dbgroup resource
    whenever groups is set.

    Serverless workgroups use `redshift-serverless:GetCredentials` instead of
    `redshift:GetClusterCredentials`. There, the database user is derived from
    the IAM identity, so `user`, `auto_create`, and `groups` do not apply.
    """
    session = aioboto3.Session(
        aws_access_key_id=aws_credentials.aws_access_key_id,
        aws_secret_access_key=aws_credentials.aws_secret_access_key,
        aws_session_token=aws_credentials.aws_session_token,
    )

    match server:
        case ProvisionedCluster():
            optional: dict[str, typing.Any] = {}
            if auto_create is not None:
                optional["AutoCreate"] = auto_create
            if groups is not None:
                optional["DbGroups"] = groups

            async with session.client("redshift", region_name=server.region) as redshift:
                response = await redshift.get_cluster_credentials(
                    DbUser=user,
                    DbName=database,
                    ClusterIdentifier=server.cluster_identifier,
                    # TODO: Refreshable credentials
                    DurationSeconds=3600,
                    **optional,
                )

            return RedshiftCredentials(user=response["DbUser"], password=response["DbPassword"])

        case ServerlessWorkgroup():
            async with session.client("redshift-serverless", region_name=server.region) as redshift_serverless:
                response = await redshift_serverless.get_credentials(
                    workgroupName=server.workgroup,
                    dbName=database,
                    durationSeconds=3600,
                )

            return RedshiftCredentials(user=response["dbUser"], password=response["dbPassword"])

        case _:
            typing.assert_never(server)


async def _get_redshift_client_inputs(
    inputs: RedshiftInsertInputs | RedshiftCopyActivityInputs,
) -> _PostgreSQLClientInputsProtocol:
    """Return PostgreSQL client inputs to establish a connection from Redshift.

    The inputs will be obtained from an integration when integration_id is set,
    and otherwise we will assert they are present in the activity inputs to be
    read directly.
    """
    if inputs.integration_id is not None:
        integration = await _get_redshift_integration(inputs.integration_id, inputs.batch_export.team_id)
        return await _get_redshift_client_inputs_from_integration(integration, inputs)

    if not isinstance(inputs.connection, ConnectionParameters):
        raise IntegrationError(
            "Redshift connection credentials are missing: the batch export has no linked integration "
            "and no inline user and password configured"
        )

    return inputs.connection


def _get_redshift_credentials_policy_statements(
    integration: AWSRedshiftRoleBasedIntegration,
    server: ProvisionedCluster | ServerlessWorkgroup,
    database: str,
) -> list[PolicyStatement]:
    """Build policy statements scoping an assumed role to obtaining Redshift credentials."""
    match server:
        case ProvisionedCluster():
            account_id = integration.aws_account_id
            get_cluster_credentials_policy = PolicyStatement(
                Effect="Allow",
                Action=["redshift:GetClusterCredentials"],
                Resource=[
                    f"arn:aws:redshift:{server.region}:{account_id}:dbuser:{server.cluster_identifier}/{integration.user}",
                    f"arn:aws:redshift:{server.region}:{account_id}:dbname:{server.cluster_identifier}/{database}",
                ],
            )
            if integration.auto_create is True:
                get_cluster_credentials_policy["Action"].append("redshift:CreateClusterUser")

            policy_statements = [get_cluster_credentials_policy]
            if integration.groups is not None:
                policy_statements.append(
                    PolicyStatement(
                        Effect="Allow",
                        Action=["redshift:JoinGroup"],
                        Resource=[
                            f"arn:aws:redshift:{server.region}:{account_id}:dbgroup:{server.cluster_identifier}/{group}"
                            for group in integration.groups
                        ],
                    )
                )
            return policy_statements

        case ServerlessWorkgroup():
            # Workgroup ARNs contain a UUID that cannot be derived from the endpoint hostname,
            # so Serverless requires the ARN on the integration to scope the policy exactly.
            workgroup_arn = integration.workgroup_arn
            if workgroup_arn is None:
                raise IntegrationError(
                    "A Redshift Serverless workgroup requires 'workgroup_arn' to be set on the integration"
                )

            _, _, _, arn_region, arn_account_id, _ = workgroup_arn.split(":", maxsplit=5)
            if arn_region != server.region or arn_account_id != server.account_id:
                raise IntegrationError(
                    f"The integration's workgroup ARN '{workgroup_arn}' does not match the region or account "
                    f"of the Redshift Serverless host (region '{server.region}', account '{server.account_id}')"
                )

            return [
                PolicyStatement(
                    Effect="Allow",
                    Action=["redshift-serverless:GetCredentials"],
                    Resource=[workgroup_arn],
                )
            ]

        case _:
            typing.assert_never(server)


async def _get_redshift_client_inputs_from_integration(
    integration: AWSRedshiftRoleBasedIntegration | AWSRedshiftIntegration | RedshiftIntegration,
    inputs: RedshiftInsertInputs | RedshiftCopyActivityInputs,
) -> _PostgreSQLClientInputsProtocol:
    """Return PostgreSQL client inputs to establish a connection from Redshift.

    These inputs can be obtained from an integration by:
    * Generating temporary credentials using a short-lived session via assuming
      a role configured in an integration.
    * Generating temporary credentials using long-lived AWS credentials stored
      in the integration.
    * Directly reading inputs stored in the integration.

    Depending on the type of integration, is which one we'll use.
    """
    client_inputs: _PostgreSQLClientInputsProtocol

    match integration:
        case AWSRedshiftRoleBasedIntegration():
            host = _get_host_from_connection(inputs.connection)
            server = _parse_redshift_host(host)

            team = await Team.objects.aget(id=inputs.batch_export.team_id)
            external_id = f"posthog-{team.organization_id}"

            policy_statements = _get_redshift_credentials_policy_statements(
                integration, server, inputs.connection.database
            )

            credentials = await get_credentials_using_user_aws_role(
                integration.aws_role_arn,
                external_id,
                session_name=f"PostHog-batch-exports-{inputs.batch_export.batch_export_id}",
                policy_statements=policy_statements,
            )

            redshift_credentials = await _get_temporary_redshift_credentials(
                credentials,
                server=server,
                user=integration.user,
                database=inputs.connection.database,
                groups=integration.groups,
                auto_create=integration.auto_create,
            )
            client_inputs = ConnectionParameters(
                user=redshift_credentials.user,
                password=redshift_credentials.password,
                host=host,
                port=inputs.connection.port,
                database=inputs.connection.database,
            )

        case AWSRedshiftIntegration():
            host = _get_host_from_connection(inputs.connection)
            server = _parse_redshift_host(host)

            redshift_credentials = await _get_temporary_redshift_credentials(
                AWSCredentials(
                    aws_access_key_id=integration.aws_access_key_id,
                    aws_secret_access_key=integration.aws_secret_access_key,
                ),
                server=server,
                user=integration.user,
                database=inputs.connection.database,
                groups=integration.groups,
                auto_create=integration.auto_create,
            )
            client_inputs = ConnectionParameters(
                user=redshift_credentials.user,
                password=redshift_credentials.password,
                host=host,
                port=inputs.connection.port,
                database=inputs.connection.database,
            )

        case RedshiftIntegration():
            client_inputs = integration

        case _:
            typing.assert_never(integration)

    return client_inputs


@activity.defn
@handle_non_retryable_errors(NON_RETRYABLE_ERROR_TYPES)
async def insert_into_redshift_activity_from_stage(inputs: RedshiftInsertInputs) -> BatchExportResult:
    """Activity to insert data from ClickHouse to Redshift.

    This activity executes the following steps:
    1. Check if anything is to be exported.
    2. Create destination table if not present.
    3. Query rows to export.
    4. Insert rows into Redshift stage table (if required) or directly into final table.
    5. Merge data from stage table (if required) into final table.

    This MERGE step handles updates to mutable models, and converts fields from
    'VARBYTE' to 'SUPER' type if required. We use 'VARBYTE' as the stage type due to
    size restrictions: Executing a COPY directly to 'SUPER' type requires casting the
    value to 'VARCHAR', which imposes a 64KB limit on the entire document. In contrast,
    'VARBYTE' can ingest up to 16MB, and the 64KB limit only applies per value in the
    document.

    Args:
        inputs: The dataclass holding inputs for this activity. The inputs
            include: connection configuration (e.g. host, user, port), batch export
            query parameters (e.g. team_id, data_interval_start, include_events), and
            the Redshift-specific properties_data_type to indicate the type of JSON-like
            fields.
    """
    bind_contextvars(
        team_id=inputs.batch_export.team_id,
        destination="Redshift",
        integration_id=inputs.integration_id,
        data_interval_start=inputs.batch_export.data_interval_start,
        data_interval_end=inputs.batch_export.data_interval_end,
        database=inputs.connection.database,
        schema=inputs.table.schema_name,
    )
    external_logger = EXTERNAL_LOGGER.bind()

    external_logger.info(
        "Batch exporting range %s - %s to Redshift: %s.%s.%s",
        inputs.batch_export.data_interval_start or "START",
        inputs.batch_export.data_interval_end or "END",
        inputs.connection.database,
        inputs.table.schema_name,
        inputs.table.name,
    )

    async with Heartbeater():
        model: BatchExportModel | BatchExportSchema | None = None
        if inputs.batch_export.batch_export_schema is None:
            model = inputs.batch_export.batch_export_model
        else:
            model = inputs.batch_export.batch_export_schema

        queue = RecordBatchQueue(max_size_bytes=settings.BATCH_EXPORT_REDSHIFT_RECORD_BATCH_QUEUE_MAX_SIZE_BYTES)
        producer = Producer()
        assert inputs.batch_export.batch_export_id is not None
        producer_task = await producer.start(
            queue=queue,
            batch_export_id=inputs.batch_export.batch_export_id,
            data_interval_start=inputs.batch_export.data_interval_start,
            data_interval_end=inputs.batch_export.data_interval_end,
            max_record_batch_size_bytes=1024 * 1024 * 10,  # 10MB
            stage_folder=inputs.batch_export.stage_folder,
        )

        record_batch_schema = await wait_for_schema_or_producer(queue, producer_task)
        if record_batch_schema is None:
            external_logger.info(
                "Batch export will finish early as there is no data matching specified filters in range %s - %s",
                inputs.batch_export.data_interval_start or "START",
                inputs.batch_export.data_interval_end or "END",
            )

            return BatchExportResult(records_completed=0, bytes_exported=0)

        record_batch_schema = pa.schema(
            [field.with_nullable(True) for field in record_batch_schema if field.name != "_inserted_at"]
        )

        table_schemas = _get_table_schemas(
            model=model, record_batch_schema=record_batch_schema, properties_data_type=inputs.table.properties_data_type
        )
        merge_settings = _get_merge_settings(model=model, use_super=table_schemas.use_super)

        data_interval_end_str = dt.datetime.fromisoformat(inputs.batch_export.data_interval_end).strftime(
            "%Y-%m-%d_%H-%M-%S"
        )
        stage_table_name = (
            f"stage_{inputs.table.name}_{data_interval_end_str}_{inputs.batch_export.team_id}"
            if merge_settings.requires_merge
            else inputs.table.name
        )

        client_inputs = await _get_redshift_client_inputs(inputs)

        async with RedshiftClient.from_inputs(
            client_inputs, database=inputs.connection.database
        ).connect() as redshift_client:
            remove_duplicates = True
            # filter out fields that are not in the destination table
            try:
                columns = await redshift_client.aget_table_columns(inputs.table.schema_name, inputs.table.name)
                if len(columns) > len(tuple(table_schemas.table_schema)):
                    # MERGE cannot remove duplicates if table columns don't match.
                    remove_duplicates = False
                    external_logger.warning(
                        "Table %s.%s has %d columns instead of %d as expected. "
                        "MERGE command may perform worse and not properly clean up duplicates",
                        inputs.table.schema_name,
                        inputs.table.name,
                        len(columns),
                        len(tuple(table_schemas.table_schema)),
                    )

                table_fields = [field for field in table_schemas.table_schema if field[0] in columns]
            except (psycopg.errors.UndefinedTable, psycopg.errors.InternalError_):
                table_fields = list(table_schemas.table_schema)
            except psycopg.errors.QueryCanceled as e:
                if "usage limit" in str(e):
                    raise InsufficientSystemResourcesError(
                        "A spending or usage quota was hit and the batch export cannot proceed. "
                        "Consider raising the quota after identifying the one that fired."
                    )
                raise

            primary_key = merge_settings.primary_key if merge_settings.requires_merge is True else None
            async with (
                redshift_client.managed_table(
                    inputs.table.schema_name, inputs.table.name, table_fields, delete=False, primary_key=primary_key
                ) as redshift_table,
                redshift_client.managed_table(
                    inputs.table.schema_name,
                    stage_table_name,
                    table_schemas.stage_table_schema,
                    create=merge_settings.requires_merge,
                    delete=merge_settings.requires_merge,
                    primary_key=primary_key,
                ) as redshift_stage_table,
            ):
                consumer = RedshiftConsumer(
                    client=redshift_client,
                    table=redshift_stage_table if merge_settings.requires_merge else redshift_table,
                )
                transformer = RedshiftQueryStreamTransformer(
                    schema=record_batch_schema,
                    redshift_table=redshift_stage_table if merge_settings.requires_merge else redshift_table,
                    redshift_schema=inputs.table.schema_name,
                    table_columns=[field[0] for field in table_fields],
                    known_json_columns=table_schemas.super_columns,
                    redshift_client=redshift_client,
                    max_query_size_bytes=settings.BATCH_EXPORT_REDSHIFT_UPLOAD_CHUNK_SIZE_BYTES,
                )
                result = await run_consumer_from_stage(
                    queue=queue,
                    consumer=consumer,
                    producer_task=producer_task,
                    transformer=transformer,
                    records_total=inputs.batch_export.records_total,
                )

                if merge_settings.requires_merge is True:
                    await redshift_client.amerge_tables(
                        final_table_name=redshift_table,
                        final_table_fields=table_fields,
                        stage_table_name=redshift_stage_table,
                        schema=inputs.table.schema_name,
                        merge_key=merge_settings.merge_key,
                        update_key=merge_settings.update_key,
                        stage_fields_cast_to_super=table_schemas.super_columns if table_schemas.use_super else None,
                        remove_duplicates=remove_duplicates,
                    )

                return result


async def upload_manifest_file(
    bucket: str,
    region_name: str,
    credentials: AWSCredentials,
    files_uploaded: list[str],
    manifest_key: str,
    refresh_using: RefreshCoroutine | None = None,
):
    """Upload manifest file used by Redshift COPY.

    The manifest file Redshift uses is slightly different to the manifest file that our
    `ConcurrentS3Consumer` produces: The top level key is `"entries"` and each entry has
    a `"meta"` key with the `"content_length"` of each file. The content length is a
    requirement when using Parquet. Since we don't track exactly the size of bytes of
    each Parquet file produced, this function gets it from S3 instead.
    """

    async with s3_client(
        credentials,
        region=region_name,
        # Required for unit tests which run against a local bucket, otherwise always None.
        endpoint_url=settings.OBJECT_STORAGE_ENDPOINT if settings.TEST else None,
        refresh_using=refresh_using,
    ) as client:
        entries = []

        async def populate_entry(f: str):
            """Obtain size for file `f` and construct entry dictionary."""
            nonlocal entries

            response = await client.list_objects_v2(Bucket=bucket, Prefix=f)

            if "Contents" not in response or len(response["Contents"]) == 0:
                # Unlikely as this should be called after the files have been
                # successfully uploaded.
                raise ValueError(f"File {f} not found in bucket {bucket}")

            entries.append(
                {
                    "url": f"s3://{bucket}/{f}",
                    "mandatory": True,
                    "meta": {"content_length": response["Contents"][0]["Size"]},
                }
            )

        try:
            async with asyncio.TaskGroup() as tg:
                for f in files_uploaded:
                    tg.create_task(populate_entry(f))
        except* botocore.exceptions.ClientError as err_group:
            LOGGER.exception("Failed to populate manifest entries")

            # According to type hints, ExceptionGroup.exceptions can be either
            # ClientError or nested ExceptionGroup[ClientError]. At the moment, there
            # isn't a good way to flatten these without a recursive function, so we keep
            # only the top level ClientErrors for analysis. There shouldn't be any
            # nested ExceptionGroup as the populate_entry task doesn't run a
            # TaskGroup, so this should be good enough.
            # There is an ongoing discussion in PEP-0785:
            # https://peps.python.org/pep-0785/#a-leaf-exceptions-helper-function.
            top_level_errors = tuple(
                err for err in err_group.exceptions if isinstance(err, botocore.exceptions.ClientError)
            )

            error_codes = {err.response.get("Error", {}).get("Code", None) for err in top_level_errors}
            for error_code in error_codes:
                if error_code == "AccessDenied":
                    # This reports the error to the user, we have already logged the exception above.
                    EXTERNAL_LOGGER.error(  # noqa: TRY400
                        "Missing permissions when attempting to list uploaded files while preparing for manifest upload. Have you granted 's3:ListBucket' permissions to the provided user on the bucket '%s'?",
                        bucket,
                    )
                else:
                    EXTERNAL_LOGGER.error(  # noqa: TRY400
                        "Unknown error when attempting to list uploaded files: %s",
                        error_code,
                    )

            raise ClientErrorGroup(top_level_errors)

        manifest = {"entries": entries}

        await client.put_object(
            Bucket=bucket,
            Key=manifest_key,
            Body=json.dumps(manifest),
            ChecksumAlgorithm="CRC64NVME",
        )


async def delete_uploaded_files(
    bucket: str,
    region_name: str,
    credentials: AWSCredentials,
    files_uploaded: list[str],
    manifest_key: str,
    refresh_using: RefreshCoroutine | None = None,
):
    """Delete files uploaded to S3 bucket during 'COPY' activity.

    This includes the `files_uploaded` and the manifest in `manifest_key`.

    The delete itself is a "best-effort" as we don't want to fail the batch export if
    this fails.
    """
    async with s3_client(
        credentials,
        region=region_name,
        refresh_using=refresh_using,
    ) as client:

        async def delete_key(f: str):
            """Delete key `f` in S3."""
            try:
                _ = await client.delete_object(Bucket=bucket, Key=f)
            except Exception:
                LOGGER.exception("S3 delete failed", key=f, bucket=bucket)

        async with asyncio.TaskGroup() as tg:
            for f in files_uploaded:
                tg.create_task(delete_key(f))
            tg.create_task(delete_key(manifest_key))


async def is_s3_read_access_denied(
    bucket: str,
    region_name: str,
    credentials: AWSCredentials,
    keys: collections.abc.Sequence[str],
    refresh_using: RefreshCoroutine | None = None,
) -> bool:
    """Return True only if a HEAD positively confirms read access is denied for any of `keys`.

    We `head_object` each key with the same credentials Redshift uses for the COPY. A 403 / Access
    Denied / Forbidden confirms a read-permission problem (including the SSE-KMS 'kms:Decrypt' case,
    which also fails the HEAD). Anything else returns False — a successful HEAD, a non-permission
    error (e.g. a 404), or an unexpected probe failure (e.g. a connection error). This is best-effort
    by design: callers should only escalate to a hard error on a confirmed denial, and never mask an
    original failure just because the probe itself couldn't run.
    """
    try:
        async with s3_client(
            credentials,
            region=region_name,
            refresh_using=refresh_using,
        ) as client:
            for key in keys:
                try:
                    await client.head_object(Bucket=bucket, Key=key)
                except botocore.exceptions.ClientError as err:
                    status = err.response.get("ResponseMetadata", {}).get("HTTPStatusCode")
                    code = err.response.get("Error", {}).get("Code")
                    if status == 403 or code in ("403", "AccessDenied", "Forbidden"):
                        return True
    except Exception:
        LOGGER.warning("S3 read-access probe failed; treating as not confirmed", exc_info=True)
    return False


async def check_and_raise_redshift_copy_error(
    err: psycopg.errors.InternalError_,
    *,
    authorization: IAMRole | AWSCredentials,
    bucket: str,
    region_name: str,
    manifest_key: str,
    files_uploaded: collections.abc.Sequence[str],
    refresh_using: RefreshCoroutine | None = None,
) -> None:
    """Translate a failed Redshift COPY into an actionable error.

    Redshift reports a missing read permission as the misleading "requires full path of an S3 object"
    error. We always generate a well-formed manifest, so for credential auth we confirm the real
    cause by probing S3 read access (HEAD on the manifest + a staged file) with the same credentials
    Redshift uses for the COPY: a confirmed denial raises `InsufficientS3PermissionsError`, otherwise
    we return so the caller re-raises the original (it's some other COPY problem).

    IAM role auth can't be probed locally, so we can't confirm the cause. We only translate when the
    error matches a known S3 read/access marker, raising the more generic `RedshiftS3CopyError` that
    points at the likely culprits (role read access or bucket region). Any other COPY error returns
    unchanged so it keeps its original message and retry behaviour.
    """
    if isinstance(authorization, AWSCredentials):
        probe_keys = [manifest_key, *files_uploaded[:1]]
        if await is_s3_read_access_denied(
            bucket=bucket,
            region_name=region_name,
            credentials=authorization,
            keys=probe_keys,
            refresh_using=refresh_using,
        ):
            raise InsufficientS3PermissionsError(bucket) from err
        return

    markers = (
        "requires full path of an S3 object",
        "Access Denied",
        "S3ServiceException",
        "Forbidden",
    )
    diagnostics = (str(err), err.diag.message_primary or "", err.diag.message_detail or "")
    if any(marker in text for text in diagnostics for marker in markers):
        raise RedshiftS3CopyError(bucket) from err


async def _resolve_aws_s3_integration(integration_id: IntegrationID, team_id: int) -> IAMRole | AWSCredentials:
    """Resolve an AWS S3 integration into its role ARN or stored credentials."""
    integration = await _get_aws_s3_integration(integration_id, team_id=team_id)

    match integration:
        case AWSS3RoleBasedIntegration():
            return integration.aws_role_arn
        case AWSS3Integration():
            return AWSCredentials(
                aws_access_key_id=integration.aws_access_key_id,
                aws_secret_access_key=integration.aws_secret_access_key,
            )
        case _:
            typing.assert_never(integration)


async def _assume_role_for_stage_bucket(
    aws_role_arn: IAMRole, inputs: RedshiftCopyActivityInputs, policy_statements: list[PolicyStatement]
) -> AWSCredentials:
    team = await Team.objects.aget(id=inputs.batch_export.team_id)
    external_id = f"posthog-{team.organization_id}"

    return await get_credentials_using_user_aws_role(
        aws_role_arn,
        external_id,
        session_name=f"PostHog-batch-exports-{inputs.batch_export.batch_export_id}",
        policy_statements=policy_statements,
    )


async def _get_s3_bucket_aws_credentials(
    inputs: RedshiftCopyActivityInputs,
) -> tuple[AWSCredentials, RefreshCoroutine | None]:
    """Resolve the credentials used to stage files in the user's S3 bucket.

    If the credentials are refreshable (i.e. via role assumption), then
    additionally return a function that may be used to refresh the crednetials.
    Otherwise, credentials are long lived and the second returned parameter is
    None.
    """
    credentials = inputs.copy.s3_bucket.credentials
    if isinstance(credentials, IntegrationID):
        credentials = await _resolve_aws_s3_integration(credentials, inputs.batch_export.team_id)

    if isinstance(credentials, AWSCredentials):
        return credentials, None

    bucket_name = inputs.copy.s3_bucket.name
    key_prefix = get_absolute_key_prefix(
        inputs.copy.s3_key_prefix,
        inputs.batch_export.data_interval_start,
        inputs.batch_export.data_interval_end,
        inputs.batch_export.batch_export_model,
    )
    policy_statements = [
        PolicyStatement(
            Effect="Allow",
            Action=["s3:PutObject", "s3:GetObject", "s3:DeleteObject", "s3:AbortMultipartUpload"],
            Resource=f"arn:aws:s3:::{bucket_name}{key_prefix}*",
        ),
        PolicyStatement(
            Effect="Allow",
            Action=["s3:ListBucket"],
            Resource=f"arn:aws:s3:::{bucket_name}",
        ),
    ]
    refresh_credentials = functools.partial(_assume_role_for_stage_bucket, credentials, inputs, policy_statements)

    return await refresh_credentials(), refresh_credentials


async def _resolve_copy_authorization(
    inputs: RedshiftCopyActivityInputs,
) -> tuple[IAMRole | AWSCredentials, RefreshCoroutine | None]:
    """Resolve the authorization Redshift uses to read staged files during COPY.

    An integration id resolves to temporary AWS credentials scoped to reading the
    staged files: a customer role ARN from an integration cannot be passed as
    `IAM_ROLE` in the COPY statement, since it is not attached to the cluster.
    """
    authorization = inputs.copy.authorization
    if not isinstance(authorization, IntegrationID):
        return authorization, None

    resolved = await _resolve_aws_s3_integration(authorization, inputs.batch_export.team_id)
    if isinstance(resolved, AWSCredentials):
        return resolved, None

    bucket_name = inputs.copy.s3_bucket.name
    key_prefix = get_absolute_key_prefix(
        inputs.copy.s3_key_prefix,
        inputs.batch_export.data_interval_start,
        inputs.batch_export.data_interval_end,
        inputs.batch_export.batch_export_model,
    )
    policy_statements = [
        PolicyStatement(
            Effect="Allow",
            Action=["s3:GetObject"],
            Resource=f"arn:aws:s3:::{bucket_name}{key_prefix}*",
        ),
        PolicyStatement(
            Effect="Allow",
            Action=["s3:ListBucket", "s3:GetBucketLocation"],
            Resource=f"arn:aws:s3:::{bucket_name}",
        ),
    ]

    refresh_credentials = functools.partial(_assume_role_for_stage_bucket, resolved, inputs, policy_statements)
    credentials = await refresh_credentials()
    return credentials, refresh_credentials


@activity.defn
@handle_non_retryable_errors(NON_RETRYABLE_ERROR_TYPES)
async def copy_into_redshift_activity_from_stage(inputs: RedshiftCopyActivityInputs) -> BatchExportResult:
    """Activity to COPY data to Redshift.

    Note that Redshift's COPY requires data to first be available in an S3 bucket that
    is different from the S3 stage bucket used in batch exports. I will call the
    buckets the "user's bucket" and the "stage bucket" respectively to differentiate
    them.

    The user's bucket must be in the same region as the Redshift instance, and Redshift
    must be able to access the bucket via credentials or assuming an IAM role. Since the
    stage bucket is an internal bucket, not publicly accessible, and in a fixed region
    it cannot play the role of the user's bucket.

    So, this activity first exports a Parquet file from our stage bucket to the user's
    bucket. Then, the Parquet file is copied into Redshift with a COPY command into a
    stage table. Finally, we MERGE the stage table into the final table.

    This MERGE step handles updates to mutable models, and converts fields from
    'VARBYTE' to 'SUPER' type if required. We use 'VARBYTE' as the stage type due to
    size restrictions: Executing a COPY directly to 'SUPER' type requires casting the
    value to 'VARCHAR', which imposes a 64KB limit on the entire document. In contrast,
    'VARBYTE' can ingest up to 16MB, and the 64KB limit only applies per value in the
    document.

    To move the data to the user's bucket we make use of the tools available in our S3
    batch export, as it is functionally the same operation.

    Args:
        inputs: The dataclass holding inputs for this activity. The inputs
            include: connection configuration (e.g. host, user, port), batch export
            query parameters (e.g. team_id, data_interval_start, include_events), and
            the Redshift-specific properties_data_type to indicate the type of JSON-like
            fields.
    """
    bind_contextvars(
        team_id=inputs.batch_export.team_id,
        destination="Redshift",
        integration_id=inputs.integration_id,
        data_interval_start=inputs.batch_export.data_interval_start,
        data_interval_end=inputs.batch_export.data_interval_end,
        database=inputs.connection.database,
        schema=inputs.table.schema_name,
    )
    external_logger = EXTERNAL_LOGGER.bind()

    external_logger.info(
        "Batch exporting range %s - %s to Redshift: %s.%s.%s",
        inputs.batch_export.data_interval_start or "START",
        inputs.batch_export.data_interval_end or "END",
        inputs.connection.database,
        inputs.table.schema_name,
        inputs.table.name,
    )

    async with Heartbeater():
        model: BatchExportModel | BatchExportSchema | None = None
        if inputs.batch_export.batch_export_schema is None:
            model = inputs.batch_export.batch_export_model
        else:
            model = inputs.batch_export.batch_export_schema

        queue = RecordBatchQueue(max_size_bytes=settings.BATCH_EXPORT_S3_RECORD_BATCH_QUEUE_MAX_SIZE_BYTES)
        producer = Producer()
        assert inputs.batch_export.batch_export_id is not None
        producer_task = await producer.start(
            queue=queue,
            batch_export_id=inputs.batch_export.batch_export_id,
            data_interval_start=inputs.batch_export.data_interval_start,
            data_interval_end=inputs.batch_export.data_interval_end,
            max_record_batch_size_bytes=1024 * 1024 * 60,  # 60MB
            stage_folder=inputs.batch_export.stage_folder,
        )

        record_batch_schema = await wait_for_schema_or_producer(queue, producer_task)
        if record_batch_schema is None:
            external_logger.info(
                "Batch export will finish early as there is no data matching specified filters in range %s - %s",
                inputs.batch_export.data_interval_start or "START",
                inputs.batch_export.data_interval_end or "END",
            )

            return BatchExportResult(records_completed=0, bytes_exported=0)

        record_batch_schema = pa.schema(
            [field.with_nullable(True) for field in record_batch_schema if field.name != "_inserted_at"]
        )

        # Redshift recommends files should be between 1MB-1GB, and that we
        # should aim for files to be equally distributed across cluster slices.
        # We don't know the number of slices in our user's cluster, so I've chosen
        # some nice round somewhere in the range (100MB).
        # TODO: Maybe derive this from user's input?
        max_file_size_mb = 100

        table_schemas = _get_table_schemas(
            model=model,
            record_batch_schema=record_batch_schema,
            properties_data_type=inputs.table.properties_data_type,
        )

        transformer = ParquetStreamTransformer(
            compression="zstd",
            include_inserted_at=False,
            max_file_size_bytes=max_file_size_mb * 1024**2,
        )

        merge_settings = _get_merge_settings(model=model, use_super=table_schemas.use_super)

        data_interval_end_str = dt.datetime.fromisoformat(inputs.batch_export.data_interval_end).strftime(
            "%Y-%m-%d_%H-%M-%S"
        )
        attempt = activity.info().attempt
        stage_table_name = (
            f"stage_{inputs.table.name}_{data_interval_end_str}_{inputs.batch_export.team_id}_{attempt}"
            if merge_settings.requires_merge
            else inputs.table.name
        )

        if not merge_settings.requires_merge:
            # Without a stage table, Parquet files are copied directly into the final
            # table, and the COPY column list names every column in the files. Pre-set
            # the transformer's schema to drop columns missing from an existing table,
            # as COPY would otherwise fail on them.
            client_inputs = await _get_redshift_client_inputs(inputs)
            try:
                async with RedshiftClient.from_inputs(
                    client_inputs, database=inputs.connection.database
                ).connect() as redshift_client:
                    existing_columns = set(
                        await redshift_client.aget_table_columns(inputs.table.schema_name, inputs.table.name)
                    )
            except (psycopg.errors.UndefinedTable, psycopg.errors.InternalError_):
                pass
            else:
                filtered_fields = [field for field in record_batch_schema if field.name in existing_columns]

                if 0 < len(filtered_fields) < len(record_batch_schema):
                    transformer.schema = cast_record_batch_schema_json_columns(
                        pa.schema(filtered_fields), json_columns=table_schemas.super_columns
                    )

        credentials, refresh_credentials = await _get_s3_bucket_aws_credentials(inputs)

        async with s3_client(
            credentials,
            region=inputs.copy.s3_bucket.region_name,
            refresh_using=refresh_credentials,
        ) as client:
            consumer = ConcurrentS3Consumer(
                bucket=inputs.copy.s3_bucket.name,
                region_name=inputs.copy.s3_bucket.region_name,
                prefix=inputs.copy.s3_key_prefix,
                data_interval_start=inputs.batch_export.data_interval_start,
                data_interval_end=inputs.batch_export.data_interval_end,
                batch_export_model=inputs.batch_export.batch_export_model,
                file_format="Parquet",
                checksum_algorithm="CRC64NVME",
                compression="zstd",
                encryption=None,
                s3_client=client,
                max_file_size_mb=max_file_size_mb,
                part_size=settings.BATCH_EXPORT_S3_UPLOAD_CHUNK_SIZE_BYTES,
                max_concurrent_uploads=settings.BATCH_EXPORT_S3_MAX_CONCURRENT_UPLOADS,
            )

            result = await run_consumer_from_stage(
                queue=queue,
                consumer=consumer,
                producer_task=producer_task,
                transformer=transformer,
                json_columns=table_schemas.super_columns,
                records_total=inputs.batch_export.records_total,
            )

        if result.error is not None:
            return result

        client_inputs = await _get_redshift_client_inputs(inputs)
        async with RedshiftClient.from_inputs(
            client_inputs, database=inputs.connection.database
        ).connect() as redshift_client:
            remove_duplicates = True

            # filter out fields that are not in the destination table
            try:
                columns = await redshift_client.aget_table_columns(inputs.table.schema_name, inputs.table.name)
                if len(columns) > len(tuple(table_schemas.table_schema)):
                    # MERGE cannot remove duplicates if table columns don't match.
                    remove_duplicates = False
                    external_logger.warning(
                        "Table %s.%s has %d columns instead of %d as expected. "
                        "MERGE command may perform worse and not properly clean up duplicates",
                        inputs.table.schema_name,
                        inputs.table.name,
                        len(columns),
                        len(tuple(table_schemas.table_schema)),
                    )

                table_fields = [field for field in table_schemas.table_schema if field[0] in columns]

            except (psycopg.errors.UndefinedTable, psycopg.errors.InternalError_):
                table_fields = list(table_schemas.table_schema)

            primary_key = merge_settings.primary_key if merge_settings.requires_merge is True else None
            async with (
                redshift_client.managed_table(
                    inputs.table.schema_name,
                    inputs.table.name,
                    table_fields,
                    delete=False,
                    primary_key=primary_key,
                ) as redshift_table,
                redshift_client.managed_table(
                    inputs.table.schema_name,
                    stage_table_name,
                    table_schemas.stage_table_schema,
                    create=merge_settings.requires_merge,
                    delete=merge_settings.requires_merge,
                    primary_key=primary_key,
                ) as redshift_stage_table,
            ):
                manifest_key = posixpath.join(
                    inputs.copy.s3_key_prefix,
                    f"{inputs.batch_export.data_interval_start}-{inputs.batch_export.data_interval_end}_manifest.json",
                )

                if posixpath.isabs(manifest_key):
                    manifest_key = posixpath.relpath(manifest_key, "/")

                await upload_manifest_file(
                    bucket=inputs.copy.s3_bucket.name,
                    region_name=inputs.copy.s3_bucket.region_name,
                    credentials=credentials,
                    files_uploaded=consumer.files_uploaded,
                    manifest_key=manifest_key,
                    refresh_using=refresh_credentials,
                )

                # Resolved after uploads finish: temporary credentials from an assumed
                # role last one hour, which a long upload could outlive.
                copy_authorization, refresh_copy_authorization = await _resolve_copy_authorization(inputs)

                try:
                    external_logger.info(f"Copying {len(consumer.files_uploaded)} file/s into Redshift")

                    try:
                        await redshift_client.acopy_from_s3_bucket(
                            table_name=redshift_stage_table,
                            parquet_fields=[field.name for field in transformer.schema],
                            schema_name=inputs.table.schema_name,
                            s3_bucket=inputs.copy.s3_bucket.name,
                            manifest_key=manifest_key,
                            authorization=copy_authorization,
                        )
                    except psycopg.errors.InternalError_ as err:
                        await check_and_raise_redshift_copy_error(
                            err,
                            authorization=copy_authorization,
                            bucket=inputs.copy.s3_bucket.name,
                            region_name=inputs.copy.s3_bucket.region_name,
                            manifest_key=manifest_key,
                            files_uploaded=consumer.files_uploaded,
                            refresh_using=refresh_copy_authorization,
                        )
                        raise

                    if merge_settings.requires_merge is True:
                        await redshift_client.amerge_tables(
                            final_table_name=redshift_table,
                            final_table_fields=table_fields,
                            stage_table_name=redshift_stage_table,
                            schema=inputs.table.schema_name,
                            merge_key=merge_settings.merge_key,
                            update_key=merge_settings.update_key,
                            stage_fields_cast_to_super=table_schemas.super_columns if table_schemas.use_super else None,
                            remove_duplicates=remove_duplicates,
                            skip_delete=isinstance(model, BatchExportModel)
                            and model.name == "events"
                            and str(inputs.batch_export.team_id) in settings.BATCH_EXPORT_REDSHIFT_SKIP_DELETE_TEAM_IDS,
                        )

                    external_logger.info(f"Finished {len(consumer.files_uploaded)} copying file/s into Redshift")

                finally:
                    await delete_uploaded_files(
                        bucket=inputs.copy.s3_bucket.name,
                        region_name=inputs.copy.s3_bucket.region_name,
                        credentials=credentials,
                        files_uploaded=consumer.files_uploaded,
                        manifest_key=manifest_key,
                        refresh_using=refresh_credentials,
                    )

        return result


@workflow.defn(name="redshift-export", failure_exception_types=[workflow.NondeterminismError])
class RedshiftBatchExportWorkflow(PostHogWorkflow):
    """A Temporal Workflow to export ClickHouse data into Postgres.

    This Workflow is intended to be executed both manually and by a Temporal
    Schedule. When ran by a schedule, `data_interval_end` should be set to
    `None` so that we will fetch the end of the interval from the Temporal
    search attribute `TemporalScheduledStartTime`.
    """

    @staticmethod
    def parse_inputs(inputs: list[str]) -> RedshiftBatchExportInputs:
        """Parse inputs from the management command CLI."""
        loaded = json.loads(inputs[0])
        return RedshiftBatchExportInputs(**loaded)

    @workflow.run
    async def run(self, inputs: RedshiftBatchExportInputs):
        """Workflow implementation to export data to Redshift."""
        is_backfill = inputs.get_is_backfill()
        is_earliest_backfill = inputs.get_is_earliest_backfill()
        data_interval = get_data_interval(inputs.interval, inputs.data_interval_end, inputs.timezone)
        should_backfill_from_beginning = is_backfill and is_earliest_backfill

        start_batch_export_run_inputs = StartBatchExportRunInputs(
            team_id=inputs.team_id,
            batch_export_id=inputs.batch_export_id,
            data_interval_start=data_interval.start.isoformat() if not should_backfill_from_beginning else None,
            data_interval_end=data_interval.end.isoformat(),
            exclude_events=inputs.exclude_events,
            include_events=inputs.include_events,
            backfill_id=inputs.backfill_details.backfill_id if inputs.backfill_details else None,
        )
        try:
            run_id = await workflow.execute_activity(
                start_batch_export_run,
                start_batch_export_run_inputs,
                start_to_close_timeout=dt.timedelta(minutes=5),
                retry_policy=RetryPolicy(
                    initial_interval=dt.timedelta(seconds=10),
                    maximum_interval=dt.timedelta(seconds=60),
                    maximum_attempts=0,
                    non_retryable_error_types=["NotNullViolation", "IntegrityError", "OverBillingLimitError"],
                ),
            )
        except exceptions.ActivityError as e:
            if is_over_billing_limit_error(e):
                return
            raise

        batch_export_inputs = BatchExportInsertInputs(
            team_id=inputs.team_id,
            data_interval_start=data_interval.start.isoformat() if not should_backfill_from_beginning else None,
            data_interval_end=data_interval.end.isoformat(),
            exclude_events=inputs.exclude_events,
            include_events=inputs.include_events,
            run_id=run_id,
            backfill_details=inputs.backfill_details,
            is_backfill=is_backfill,
            batch_export_model=inputs.batch_export_model,
            batch_export_schema=inputs.batch_export_schema,
            batch_export_id=inputs.batch_export_id,
            destination_default_fields=redshift_default_fields(),
        )
        connection_parameters: ConnectionParameters | ServerConnectionParameters
        if inputs.user is not None and inputs.password is not None and inputs.host is not None:
            connection_parameters = ConnectionParameters(
                user=inputs.user,
                password=inputs.password,
                host=inputs.host,
                port=inputs.port,
                database=inputs.database,
            )
        else:
            # Credentials live in the linked integration. The activity raises a clear,
            # non-retryable error if there is no integration either; raising here would
            # retry the workflow task forever.
            connection_parameters = ServerConnectionParameters(
                database=inputs.database,
                port=inputs.port,
                host=inputs.host,
            )
        table_parameters = TableParameters(
            schema_name=inputs.schema,
            name=inputs.table_name,
            properties_data_type=inputs.properties_data_type,
        )

        if inputs.mode == "COPY" and inputs.copy_inputs is not None:
            await execute_batch_export_using_internal_stage(
                copy_into_redshift_activity_from_stage,
                RedshiftCopyActivityInputs(  # type: ignore
                    batch_export=batch_export_inputs,
                    connection=connection_parameters,
                    table=table_parameters,
                    copy=CopyParameters(
                        s3_bucket=S3StageBucketParameters(
                            name=inputs.copy_inputs.s3_bucket,
                            region_name=inputs.copy_inputs.region_name,
                            credentials=inputs.copy_inputs.bucket_credentials,
                        ),
                        s3_key_prefix=inputs.copy_inputs.s3_key_prefix,
                        authorization=inputs.copy_inputs.authorization,
                    ),
                    integration_id=inputs.integration_id,
                ),
                interval=inputs.interval,
                maximum_retry_interval_seconds=240,
            )
        else:
            await execute_batch_export_using_internal_stage(
                insert_into_redshift_activity_from_stage,
                RedshiftInsertInputs(  # type: ignore
                    batch_export=batch_export_inputs,
                    connection=connection_parameters,
                    table=table_parameters,
                    integration_id=inputs.integration_id,
                ),
                interval=inputs.interval,
                # TODO: Temporarily bump start to close timeout until we speed up
                # Redshift inserts.
                override_start_to_close_timeout_seconds=60 * 60 * 24,  # 24 hours
                maximum_retry_interval_seconds=240,
            )
