import { apiMutator } from '../../../../frontend/src/lib/api-orval-mutator'
/**
 * Auto-generated from the Django backend OpenAPI schema.
 * To modify these types, update the Django serializers or views, then run:
 *   hogli build:openapi
 * Questions or issues? #team-devex on Slack
 *
 * PostHog API - generated
 * OpenAPI spec version: 1.0.0
 */
import type {
    AchievementsListResponseApi,
    AcknowledgeCelebrationRequestApi,
    AcknowledgeCelebrationResponseApi,
    ApplyPathCleaningSuggestionResponseApi,
    GeneratePathCleaningSuggestionResponseApi,
    HeatmapEventsResponseApi,
    HeatmapPreflightRequestApi,
    HeatmapPreflightResponseApi,
    HeatmapPrewarmRequestApi,
    HeatmapScreenshotResponseApi,
    HeatmapScreenshotsContentRetrieveParams,
    HeatmapsEventsRetrieveParams,
    HeatmapsListParams,
    HeatmapsResponseApi,
    LlmsTxtFetchRequestApi,
    LlmsTxtFetchResponseApi,
    PaginatedWebAnalyticsFilterPresetListApi,
    PatchedSavedHeatmapRequestApi,
    PatchedWebAnalyticsFilterPresetApi,
    PreviewPathCleaningSuggestionResponseApi,
    RecordInteractionRequestApi,
    RecordInteractionResponseApi,
    RecordVisitResponseApi,
    SavedHeatmapCaptureRequestApi,
    SavedHeatmapListResponseApi,
    SavedHeatmapRequestApi,
    SavedListParams,
    WebAnalyticsFilterPresetApi,
    WebAnalyticsFilterPresetsListParams,
    WebAnalyticsRecapParams,
    WebAnalyticsRecapResponseApi,
    WebAnalyticsUserPreferencesApi,
    WebAnalyticsWeeklyDigestParams,
    WeeklyDigestResponseApi,
} from './api.schemas'

// https://stackoverflow.com/questions/49579094/typescript-conditional-types-filter-out-readonly-properties-pick-only-requir/49579497#49579497
type IfEquals<X, Y, A = X, B = never> = (<T>() => T extends X ? 1 : 2) extends <T>() => T extends Y ? 1 : 2 ? A : B

type WritableKeys<T> = {
    [P in keyof T]-?: IfEquals<{ [Q in P]: T[P] }, { -readonly [Q in P]: T[P] }, P>
}[keyof T]

type UnionToIntersection<U> = (U extends any ? (k: U) => void : never) extends (k: infer I) => void ? I : never
type DistributeReadOnlyOverUnions<T> = T extends any ? NonReadonly<T> : never

type Writable<T> = Pick<T, WritableKeys<T>>
type NonReadonly<T> = [T] extends [UnionToIntersection<T>]
    ? {
          [P in keyof Writable<T>]: T[P] extends object ? NonReadonly<NonNullable<T[P]>> : T[P]
      }
    : DistributeReadOnlyOverUnions<T>

export const getHeatmapScreenshotsContentRetrieveUrl = (
    projectId: string,
    id: string,
    params?: HeatmapScreenshotsContentRetrieveParams
) => {
    const normalizedParams = new URLSearchParams()

    Object.entries(params || {}).forEach(([key, value]) => {
        if (value !== undefined) {
            normalizedParams.append(key, value === null ? 'null' : String(value))
        }
    })

    const stringifiedParams = normalizedParams.toString()

    return stringifiedParams.length > 0
        ? `/api/projects/${projectId}/heatmap_screenshots/${id}/content/?${stringifiedParams}`
        : `/api/projects/${projectId}/heatmap_screenshots/${id}/content/`
}

/**
 * Fetch the rendered screenshot image (JPEG bytes) for a saved heatmap at a given viewport width. Returns 202 with the saved-heatmap metadata while the screenshot is still being generated.
 */
export const heatmapScreenshotsContentRetrieve = async (
    projectId: string,
    id: string,
    params?: HeatmapScreenshotsContentRetrieveParams,
    options?: RequestInit
): Promise<Blob | HeatmapScreenshotResponseApi> => {
    return apiMutator<Blob | HeatmapScreenshotResponseApi>(
        getHeatmapScreenshotsContentRetrieveUrl(projectId, id, params),
        {
            ...options,
            method: 'GET',
        }
    )
}

export const getHeatmapsListUrl = (projectId: string, params?: HeatmapsListParams) => {
    const normalizedParams = new URLSearchParams()

    Object.entries(params || {}).forEach(([key, value]) => {
        if (value !== undefined) {
            normalizedParams.append(key, value === null ? 'null' : String(value))
        }
    })

    const stringifiedParams = normalizedParams.toString()

    return stringifiedParams.length > 0
        ? `/api/projects/${projectId}/heatmaps/?${stringifiedParams}`
        : `/api/projects/${projectId}/heatmaps/`
}

/**
 * Aggregated heatmap interactions for a page. For type 'click'/'rageclick'/'mousemove' each result is a point with relative x, absolute client-y, and a count. For type 'scrolldepth' the response is scroll-depth buckets instead (cumulative reach down the page).
 */
export const heatmapsList = async (
    projectId: string,
    params?: HeatmapsListParams,
    options?: RequestInit
): Promise<HeatmapsResponseApi[]> => {
    return apiMutator<HeatmapsResponseApi[]>(getHeatmapsListUrl(projectId, params), {
        ...options,
        method: 'GET',
    })
}

export const getHeatmapsEventsRetrieveUrl = (projectId: string, params: HeatmapsEventsRetrieveParams) => {
    const normalizedParams = new URLSearchParams()

    Object.entries(params || {}).forEach(([key, value]) => {
        if (value !== undefined) {
            normalizedParams.append(key, value === null ? 'null' : String(value))
        }
    })

    const stringifiedParams = normalizedParams.toString()

    return stringifiedParams.length > 0
        ? `/api/projects/${projectId}/heatmaps/events/?${stringifiedParams}`
        : `/api/projects/${projectId}/heatmaps/events/`
}

/**
 * Drill into the individual session interactions behind one or more heatmap coordinates. Pass the 'points' you want to inspect (from the heatmaps list response) to get the underlying per-session events, so you can jump to the session recordings that produced a hotspot.
 */
export const heatmapsEventsRetrieve = async (
    projectId: string,
    params: HeatmapsEventsRetrieveParams,
    options?: RequestInit
): Promise<HeatmapEventsResponseApi> => {
    return apiMutator<HeatmapEventsResponseApi>(getHeatmapsEventsRetrieveUrl(projectId, params), {
        ...options,
        method: 'GET',
    })
}

export const getSavedListUrl = (projectId: string, params?: SavedListParams) => {
    const normalizedParams = new URLSearchParams()

    Object.entries(params || {}).forEach(([key, value]) => {
        if (value !== undefined) {
            normalizedParams.append(key, value === null ? 'null' : String(value))
        }
    })

    const stringifiedParams = normalizedParams.toString()

    return stringifiedParams.length > 0
        ? `/api/projects/${projectId}/saved/?${stringifiedParams}`
        : `/api/projects/${projectId}/saved/`
}

/**
 * List saved heatmaps for the project. A saved heatmap pins a page URL and a set of viewport widths, and (for type 'screenshot') renders the page so heatmap data can be overlaid on it.
 */
export const savedList = async (
    projectId: string,
    params?: SavedListParams,
    options?: RequestInit
): Promise<SavedHeatmapListResponseApi[]> => {
    return apiMutator<SavedHeatmapListResponseApi[]>(getSavedListUrl(projectId, params), {
        ...options,
        method: 'GET',
    })
}

export const getSavedCreateUrl = (projectId: string) => {
    return `/api/projects/${projectId}/saved/`
}

/**
 * Create a saved heatmap for a page URL. For type 'screenshot' (the default) this enqueues a headless render of the page at each target width; poll the saved heatmap or its content endpoint until status is 'completed'. Provide 'widths' to control which viewport widths are rendered.
 */
export const savedCreate = async (
    projectId: string,
    savedHeatmapRequestApi: SavedHeatmapRequestApi,
    options?: RequestInit
): Promise<HeatmapScreenshotResponseApi> => {
    return apiMutator<HeatmapScreenshotResponseApi>(getSavedCreateUrl(projectId), {
        ...options,
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...options?.headers },
        body: JSON.stringify(savedHeatmapRequestApi),
    })
}

export const getSavedRetrieveUrl = (projectId: string, shortId: string) => {
    return `/api/projects/${projectId}/saved/${shortId}/`
}

/**
 * Get a single saved heatmap by its short_id, including per-width render status.
 */
export const savedRetrieve = async (
    projectId: string,
    shortId: string,
    options?: RequestInit
): Promise<HeatmapScreenshotResponseApi> => {
    return apiMutator<HeatmapScreenshotResponseApi>(getSavedRetrieveUrl(projectId, shortId), {
        ...options,
        method: 'GET',
    })
}

export const getSavedPartialUpdateUrl = (projectId: string, shortId: string) => {
    return `/api/projects/${projectId}/saved/${shortId}/`
}

/**
 * Update a saved heatmap (e.g. rename, change widths, or soft-delete via 'deleted'). Changing the URL of a 'screenshot' heatmap triggers a re-render.
 */
export const savedPartialUpdate = async (
    projectId: string,
    shortId: string,
    patchedSavedHeatmapRequestApi?: PatchedSavedHeatmapRequestApi,
    options?: RequestInit
): Promise<HeatmapScreenshotResponseApi> => {
    return apiMutator<HeatmapScreenshotResponseApi>(getSavedPartialUpdateUrl(projectId, shortId), {
        ...options,
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json', ...options?.headers },
        body: JSON.stringify(patchedSavedHeatmapRequestApi),
    })
}

export const getSavedDestroyUrl = (projectId: string, shortId: string) => {
    return `/api/projects/${projectId}/saved/${shortId}/`
}

/**
 * Hard delete of this model is not allowed. Use a patch API call to set "deleted" to true
 */
export const savedDestroy = async (projectId: string, shortId: string, options?: RequestInit): Promise<unknown> => {
    return apiMutator<unknown>(getSavedDestroyUrl(projectId, shortId), {
        ...options,
        method: 'DELETE',
    })
}

export const getSavedRegenerateCreateUrl = (projectId: string, shortId: string) => {
    return `/api/projects/${projectId}/saved/${shortId}/regenerate/`
}

/**
 * Re-run screenshot generation for a saved heatmap of type 'screenshot'. Clears existing renders and re-renders at every target width; status returns to 'processing'.
 */
export const savedRegenerateCreate = async (
    projectId: string,
    shortId: string,
    options?: RequestInit
): Promise<HeatmapScreenshotResponseApi> => {
    return apiMutator<HeatmapScreenshotResponseApi>(getSavedRegenerateCreateUrl(projectId, shortId), {
        ...options,
        method: 'POST',
    })
}

export const getSavedCaptureCreateUrl = (projectId: string) => {
    return `/api/projects/${projectId}/saved/capture/`
}

/**
 * Persist screenshots captured client-side by the on-page toolbar as a completed screenshot heatmap. No headless render is enqueued: the toolbar runs in the user's authenticated browser, so this is the path for pages behind a login that Browserless cannot reach. Send one 'image'+'width', or 'images'+'widths' parallel arrays to store several viewport widths on one heatmap (the toolbar re-lays out the page at each width and captures it, matching the widths the server renders). The image bytes are stored and served only through the authenticated content endpoint. The heatmap's data URL is set to the captured URL.
 */
export const savedCaptureCreate = async (
    projectId: string,
    savedHeatmapCaptureRequestApi: SavedHeatmapCaptureRequestApi,
    options?: RequestInit
): Promise<HeatmapScreenshotResponseApi> => {
    const formData = new FormData()
    if (savedHeatmapCaptureRequestApi.image !== undefined && savedHeatmapCaptureRequestApi.image !== null) {
        formData.append(`image`, savedHeatmapCaptureRequestApi.image)
    }
    if (savedHeatmapCaptureRequestApi.width !== undefined) {
        formData.append(`width`, savedHeatmapCaptureRequestApi.width.toString())
    }
    if (savedHeatmapCaptureRequestApi.images !== undefined) {
        savedHeatmapCaptureRequestApi.images.forEach((value) => formData.append(`images`, value))
    }
    if (savedHeatmapCaptureRequestApi.widths !== undefined) {
        savedHeatmapCaptureRequestApi.widths.forEach((value) => formData.append(`widths`, value.toString()))
    }
    formData.append(`url`, savedHeatmapCaptureRequestApi.url)
    if (savedHeatmapCaptureRequestApi.name !== undefined) {
        formData.append(`name`, savedHeatmapCaptureRequestApi.name)
    }

    return apiMutator<HeatmapScreenshotResponseApi>(getSavedCaptureCreateUrl(projectId), {
        ...options,
        method: 'POST',
        body: formData,
    })
}

export const getSavedPreflightCreateUrl = (projectId: string) => {
    return `/api/projects/${projectId}/saved/preflight/`
}

/**
 * Fetch a page URL server-side and report whether it allows being embedded in the live preview iframe, plus the HTTP status it returned. The live preview loads the customer's site directly in their browser, so a site that sends X-Frame-Options or a restrictive frame-ancestors will never render, and a 4xx or 5xx from the site's own host or CDN leaves an empty frame with no explanation. This endpoint makes both cases explainable. The fetch comes from PostHog's own network rather than from the screenshot renderer, so a host that varies its response by IP or user agent can answer this differently than it answers a screenshot render. Settled verdicts are cached briefly, so repeat checks for the same URL do not refetch it.
 * @summary Check whether a page can back a heatmap
 */
export const savedPreflightCreate = async (
    projectId: string,
    heatmapPreflightRequestApi: HeatmapPreflightRequestApi,
    options?: RequestInit
): Promise<HeatmapPreflightResponseApi> => {
    return apiMutator<HeatmapPreflightResponseApi>(getSavedPreflightCreateUrl(projectId), {
        ...options,
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...options?.headers },
        body: JSON.stringify(heatmapPreflightRequestApi),
    })
}

export const getSavedPrewarmCreateUrl = (projectId: string) => {
    return `/api/projects/${projectId}/saved/prewarm/`
}

/**
 * Speculatively render a screenshot for a page URL ahead of heatmap creation, so it's ready (or closer to ready) by the time the user reaches the generation screen. Renders a single preview width. Idempotent within a short window: returns the existing in-flight or completed prewarm render for the same URL and consent setting if one exists (200), otherwise starts a new one (201). The result is reused when a heatmap is later created for the same URL.
 */
export const savedPrewarmCreate = async (
    projectId: string,
    heatmapPrewarmRequestApi: HeatmapPrewarmRequestApi,
    options?: RequestInit
): Promise<HeatmapScreenshotResponseApi> => {
    return apiMutator<HeatmapScreenshotResponseApi>(getSavedPrewarmCreateUrl(projectId), {
        ...options,
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...options?.headers },
        body: JSON.stringify(heatmapPrewarmRequestApi),
    })
}

export const getWebAnalyticsFetchLlmsTxtUrl = (projectId: string) => {
    return `/api/projects/${projectId}/web_analytics/llms_txt/`
}

/**
 * Loads an llms.txt file from a public URL for coverage analysis without saving it.
 * @summary Load an llms.txt file
 */
export const webAnalyticsFetchLlmsTxt = async (
    projectId: string,
    llmsTxtFetchRequestApi: LlmsTxtFetchRequestApi,
    options?: RequestInit
): Promise<LlmsTxtFetchResponseApi> => {
    return apiMutator<LlmsTxtFetchResponseApi>(getWebAnalyticsFetchLlmsTxtUrl(projectId), {
        ...options,
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...options?.headers },
        body: JSON.stringify(llmsTxtFetchRequestApi),
    })
}

export const getWebAnalyticsRecapUrl = (projectId: string, params?: WebAnalyticsRecapParams) => {
    const normalizedParams = new URLSearchParams()

    Object.entries(params || {}).forEach(([key, value]) => {
        if (value !== undefined) {
            normalizedParams.append(key, value === null ? 'null' : String(value))
        }
    })

    const stringifiedParams = normalizedParams.toString()

    return stringifiedParams.length > 0
        ? `/api/projects/${projectId}/web_analytics/recap/?${stringifiedParams}`
        : `/api/projects/${projectId}/web_analytics/recap/`
}

/**
 * The 'Wrapped'-style weekly recap: everything in the weekly digest (visitors, pageviews, sessions, bounce rate, average session duration with period-over-period comparisons, top pages, top sources, and goals) plus a single derived weekly persona and a short list of screenshot-worthy highlights for the period.
 * @summary Weekly web analytics recap
 */
export const webAnalyticsRecap = async (
    projectId: string,
    params?: WebAnalyticsRecapParams,
    options?: RequestInit
): Promise<WebAnalyticsRecapResponseApi> => {
    return apiMutator<WebAnalyticsRecapResponseApi>(getWebAnalyticsRecapUrl(projectId, params), {
        ...options,
        method: 'GET',
    })
}

export const getWebAnalyticsWeeklyDigestUrl = (projectId: string, params?: WebAnalyticsWeeklyDigestParams) => {
    const normalizedParams = new URLSearchParams()

    Object.entries(params || {}).forEach(([key, value]) => {
        if (value !== undefined) {
            normalizedParams.append(key, value === null ? 'null' : String(value))
        }
    })

    const stringifiedParams = normalizedParams.toString()

    return stringifiedParams.length > 0
        ? `/api/projects/${projectId}/web_analytics/weekly_digest/?${stringifiedParams}`
        : `/api/projects/${projectId}/web_analytics/weekly_digest/`
}

/**
 * Summarizes a project's web analytics over a lookback window (default 7 days): unique visitors, pageviews, sessions, bounce rate, and average session duration with period-over-period comparisons, plus the top 5 pages, top 5 traffic sources, and goal conversions.
 * @summary Summarize web analytics
 */
export const webAnalyticsWeeklyDigest = async (
    projectId: string,
    params?: WebAnalyticsWeeklyDigestParams,
    options?: RequestInit
): Promise<WeeklyDigestResponseApi> => {
    return apiMutator<WeeklyDigestResponseApi>(getWebAnalyticsWeeklyDigestUrl(projectId, params), {
        ...options,
        method: 'GET',
    })
}

export const getWebAnalyticsAchievementsAcknowledgeCelebrationUrl = (projectId: string) => {
    return `/api/projects/${projectId}/web_analytics_achievements/acknowledge_celebration/`
}

/**
 * Clears a pending celebration for the given track and stage once the client has shown it, so it isn't celebrated again. Idempotent.
 * @summary Acknowledge an achievement celebration
 */
export const webAnalyticsAchievementsAcknowledgeCelebration = async (
    projectId: string,
    acknowledgeCelebrationRequestApi: AcknowledgeCelebrationRequestApi,
    options?: RequestInit
): Promise<AcknowledgeCelebrationResponseApi> => {
    return apiMutator<AcknowledgeCelebrationResponseApi>(
        getWebAnalyticsAchievementsAcknowledgeCelebrationUrl(projectId),
        {
            ...options,
            method: 'POST',
            headers: { 'Content-Type': 'application/json', ...options?.headers },
            body: JSON.stringify(acknowledgeCelebrationRequestApi),
        }
    )
}

export const getWebAnalyticsAchievementsOverviewUrl = (projectId: string) => {
    return `/api/projects/${projectId}/web_analytics_achievements/overview/`
}

/**
 * Returns the achievement track definitions (thresholds resolved for the requesting user's streak-cadence arm), the user's and team's progress, and any newly unlocked stages awaiting an in-session celebration.
 * @summary Get Web analytics achievements overview
 */
export const webAnalyticsAchievementsOverview = async (
    projectId: string,
    options?: RequestInit
): Promise<AchievementsListResponseApi> => {
    return apiMutator<AchievementsListResponseApi>(getWebAnalyticsAchievementsOverviewUrl(projectId), {
        ...options,
        method: 'GET',
    })
}

export const getWebAnalyticsAchievementsPreferencesUrl = (projectId: string) => {
    return `/api/projects/${projectId}/web_analytics_achievements/preferences/`
}

/**
 * Returns the requesting user's per-project Web analytics achievements preferences.
 * @summary Get Web analytics achievements preferences
 */
export const webAnalyticsAchievementsPreferences = async (
    projectId: string,
    options?: RequestInit
): Promise<WebAnalyticsUserPreferencesApi> => {
    return apiMutator<WebAnalyticsUserPreferencesApi>(getWebAnalyticsAchievementsPreferencesUrl(projectId), {
        ...options,
        method: 'GET',
    })
}

export const getWebAnalyticsAchievementsUpdatePreferencesUrl = (projectId: string) => {
    return `/api/projects/${projectId}/web_analytics_achievements/preferences/`
}

/**
 * Sets the requesting user's per-project Web analytics achievements preferences.
 * @summary Update Web analytics achievements preferences
 */
export const webAnalyticsAchievementsUpdatePreferences = async (
    projectId: string,
    webAnalyticsUserPreferencesApi: WebAnalyticsUserPreferencesApi,
    options?: RequestInit
): Promise<WebAnalyticsUserPreferencesApi> => {
    return apiMutator<WebAnalyticsUserPreferencesApi>(getWebAnalyticsAchievementsUpdatePreferencesUrl(projectId), {
        ...options,
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...options?.headers },
        body: JSON.stringify(webAnalyticsUserPreferencesApi),
    })
}

export const getWebAnalyticsAchievementsRecordInteractionUrl = (projectId: string) => {
    return `/api/projects/${projectId}/web_analytics_achievements/record_interaction/`
}

/**
 * Idempotently increments the requesting user's first-party counter for an in-product Web analytics interaction (slicing data, or opening a session recording), which drives the Explorer and Detective achievement tracks.
 * @summary Record a Web analytics interaction
 */
export const webAnalyticsAchievementsRecordInteraction = async (
    projectId: string,
    recordInteractionRequestApi: RecordInteractionRequestApi,
    options?: RequestInit
): Promise<RecordInteractionResponseApi> => {
    return apiMutator<RecordInteractionResponseApi>(getWebAnalyticsAchievementsRecordInteractionUrl(projectId), {
        ...options,
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...options?.headers },
        body: JSON.stringify(recordInteractionRequestApi),
    })
}

export const getWebAnalyticsAchievementsRecordVisitUrl = (projectId: string) => {
    return `/api/projects/${projectId}/web_analytics_achievements/record_visit/`
}

/**
 * Idempotently records that the requesting user opened Web analytics today (team-local date) and schedules a debounced achievement recompute. Intended to be called once per session.
 * @summary Record a Web analytics visit
 */
export const webAnalyticsAchievementsRecordVisit = async (
    projectId: string,
    options?: RequestInit
): Promise<RecordVisitResponseApi> => {
    return apiMutator<RecordVisitResponseApi>(getWebAnalyticsAchievementsRecordVisitUrl(projectId), {
        ...options,
        method: 'POST',
    })
}

export const getWebAnalyticsFilterPresetsListUrl = (
    projectId: string,
    params?: WebAnalyticsFilterPresetsListParams
) => {
    const normalizedParams = new URLSearchParams()

    Object.entries(params || {}).forEach(([key, value]) => {
        if (value !== undefined) {
            normalizedParams.append(key, value === null ? 'null' : String(value))
        }
    })

    const stringifiedParams = normalizedParams.toString()

    return stringifiedParams.length > 0
        ? `/api/projects/${projectId}/web_analytics_filter_presets/?${stringifiedParams}`
        : `/api/projects/${projectId}/web_analytics_filter_presets/`
}

export const webAnalyticsFilterPresetsList = async (
    projectId: string,
    params?: WebAnalyticsFilterPresetsListParams,
    options?: RequestInit
): Promise<PaginatedWebAnalyticsFilterPresetListApi> => {
    return apiMutator<PaginatedWebAnalyticsFilterPresetListApi>(
        getWebAnalyticsFilterPresetsListUrl(projectId, params),
        {
            ...options,
            method: 'GET',
        }
    )
}

export const getWebAnalyticsFilterPresetsCreateUrl = (projectId: string) => {
    return `/api/projects/${projectId}/web_analytics_filter_presets/`
}

export const webAnalyticsFilterPresetsCreate = async (
    projectId: string,
    webAnalyticsFilterPresetApi: NonReadonly<WebAnalyticsFilterPresetApi>,
    options?: RequestInit
): Promise<WebAnalyticsFilterPresetApi> => {
    return apiMutator<WebAnalyticsFilterPresetApi>(getWebAnalyticsFilterPresetsCreateUrl(projectId), {
        ...options,
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...options?.headers },
        body: JSON.stringify(webAnalyticsFilterPresetApi),
    })
}

export const getWebAnalyticsFilterPresetsRetrieveUrl = (projectId: string, shortId: string) => {
    return `/api/projects/${projectId}/web_analytics_filter_presets/${shortId}/`
}

export const webAnalyticsFilterPresetsRetrieve = async (
    projectId: string,
    shortId: string,
    options?: RequestInit
): Promise<WebAnalyticsFilterPresetApi> => {
    return apiMutator<WebAnalyticsFilterPresetApi>(getWebAnalyticsFilterPresetsRetrieveUrl(projectId, shortId), {
        ...options,
        method: 'GET',
    })
}

export const getWebAnalyticsFilterPresetsUpdateUrl = (projectId: string, shortId: string) => {
    return `/api/projects/${projectId}/web_analytics_filter_presets/${shortId}/`
}

export const webAnalyticsFilterPresetsUpdate = async (
    projectId: string,
    shortId: string,
    webAnalyticsFilterPresetApi: NonReadonly<WebAnalyticsFilterPresetApi>,
    options?: RequestInit
): Promise<WebAnalyticsFilterPresetApi> => {
    return apiMutator<WebAnalyticsFilterPresetApi>(getWebAnalyticsFilterPresetsUpdateUrl(projectId, shortId), {
        ...options,
        method: 'PUT',
        headers: { 'Content-Type': 'application/json', ...options?.headers },
        body: JSON.stringify(webAnalyticsFilterPresetApi),
    })
}

export const getWebAnalyticsFilterPresetsPartialUpdateUrl = (projectId: string, shortId: string) => {
    return `/api/projects/${projectId}/web_analytics_filter_presets/${shortId}/`
}

export const webAnalyticsFilterPresetsPartialUpdate = async (
    projectId: string,
    shortId: string,
    patchedWebAnalyticsFilterPresetApi?: NonReadonly<PatchedWebAnalyticsFilterPresetApi>,
    options?: RequestInit
): Promise<WebAnalyticsFilterPresetApi> => {
    return apiMutator<WebAnalyticsFilterPresetApi>(getWebAnalyticsFilterPresetsPartialUpdateUrl(projectId, shortId), {
        ...options,
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json', ...options?.headers },
        body: JSON.stringify(patchedWebAnalyticsFilterPresetApi),
    })
}

export const getWebAnalyticsFilterPresetsDestroyUrl = (projectId: string, shortId: string) => {
    return `/api/projects/${projectId}/web_analytics_filter_presets/${shortId}/`
}

/**
 * Hard delete of this model is not allowed. Use a patch API call to set "deleted" to true
 */
export const webAnalyticsFilterPresetsDestroy = async (
    projectId: string,
    shortId: string,
    options?: RequestInit
): Promise<unknown> => {
    return apiMutator<unknown>(getWebAnalyticsFilterPresetsDestroyUrl(projectId, shortId), {
        ...options,
        method: 'DELETE',
    })
}

export const getWebAnalyticsPathCleaningSuggestionsApplyUrl = (projectId: string, id: string) => {
    return `/api/projects/${projectId}/web_analytics_path_cleaning_suggestions/${id}/apply/`
}

/**
 * Merges the suggestion's rules into the team's path_cleaning_filters (never overwrites existing rules) and resolves the underlying health issue. Requires project admin, matching the team API's gate on path_cleaning_filters.
 * @summary Apply a path-cleaning suggestion
 */
export const webAnalyticsPathCleaningSuggestionsApply = async (
    projectId: string,
    id: string,
    options?: RequestInit
): Promise<ApplyPathCleaningSuggestionResponseApi> => {
    return apiMutator<ApplyPathCleaningSuggestionResponseApi>(
        getWebAnalyticsPathCleaningSuggestionsApplyUrl(projectId, id),
        {
            ...options,
            method: 'POST',
        }
    )
}

export const getWebAnalyticsPathCleaningSuggestionsPreviewUrl = (projectId: string, id: string) => {
    return `/api/projects/${projectId}/web_analytics_path_cleaning_suggestions/${id}/preview/`
}

/**
 * Applies the suggestion's rules (in order) to a fresh sample of the team's top paths and returns before/after pairs for the paths that would change. Computed on demand; path samples are never stored. Nothing is modified.
 * @summary Preview a path-cleaning suggestion on real paths
 */
export const webAnalyticsPathCleaningSuggestionsPreview = async (
    projectId: string,
    id: string,
    options?: RequestInit
): Promise<PreviewPathCleaningSuggestionResponseApi> => {
    return apiMutator<PreviewPathCleaningSuggestionResponseApi>(
        getWebAnalyticsPathCleaningSuggestionsPreviewUrl(projectId, id),
        {
            ...options,
            method: 'GET',
        }
    )
}

export const getWebAnalyticsPathCleaningSuggestionsGenerateUrl = (projectId: string) => {
    return `/api/projects/${projectId}/web_analytics_path_cleaning_suggestions/generate/`
}

/**
 * Samples the team's recent paths, asks the LLM for cleaning rules, validates them against the real paths, and stores the result as a `path_cleaning_suggestions` health issue (replacing any previous active one). Runs even if the team already has rules. Returns the suggestion (or a skip status when there aren't enough paths to suggest from).
 * @summary Generate path-cleaning suggestions on demand
 */
export const webAnalyticsPathCleaningSuggestionsGenerate = async (
    projectId: string,
    options?: RequestInit
): Promise<GeneratePathCleaningSuggestionResponseApi> => {
    return apiMutator<GeneratePathCleaningSuggestionResponseApi>(
        getWebAnalyticsPathCleaningSuggestionsGenerateUrl(projectId),
        {
            ...options,
            method: 'POST',
        }
    )
}
