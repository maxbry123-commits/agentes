import { useActions, useValues } from 'kea'
import { useEffect, useState } from 'react'

import { IconFilter, IconGear, IconLaptop, IconPhone, IconTabletLandscape, IconTabletPortrait } from '@posthog/icons'
import { LemonBadge, LemonBanner, LemonButton, LemonSegmentedButton, LemonSelect } from '@posthog/lemon-ui'

import { DateFilter } from 'lib/components/DateFilter/DateFilter'
import { heatmapDataLogic } from 'lib/components/heatmaps/heatmapDataLogic'
import { HeatmapsSettings } from 'lib/components/heatmaps/HeatMapsSettings'
import { SectionSetting } from 'lib/components/heatmaps/HeatMapsSettings'
import { HeatmapEventFilter } from 'lib/components/heatmaps/types'
import { heatmapDateOptions } from 'lib/components/IframedToolbarBrowser/utils'
import { PropertyFilters } from 'lib/components/PropertyFilters/PropertyFilters'
import { TaxonomicFilterGroupType } from 'lib/components/TaxonomicFilter/types'
import { useFeatureFlag } from 'lib/hooks/useFeatureFlag'
import { LoadingBar } from 'lib/lemon-ui/LoadingBar'
import { Popover } from 'lib/lemon-ui/Popover'
import { inStorybook, inStorybookTestRunner } from 'lib/utils/dom'
import { COHORTS_ONLY_SUPPORT_IN_PICKER_PROPS } from 'scenes/feature-flags/cohortPickerProps'
import { ActionFilter } from 'scenes/insights/filters/ActionFilter/ActionFilter'
import { MathAvailability } from 'scenes/insights/filters/ActionFilter/ActionFilterRow/ActionFilterRow'
import { TestAccountFilter } from 'scenes/insights/filters/TestAccountFilter'

import { AnyPropertyFilter, CohortPropertyFilter, HeatmapType, PropertyFilterType, PropertyOperator } from '~/types'

const cohortIdsToPropertyFilters = (ids: number[]): AnyPropertyFilter[] =>
    ids.map((id) => ({
        type: PropertyFilterType.Cohort,
        key: 'id',
        value: id,
        operator: PropertyOperator.In,
    }))

const propertyFiltersToCohortIds = (filters: AnyPropertyFilter[]): number[] =>
    filters
        .filter((f): f is CohortPropertyFilter => f.type === PropertyFilterType.Cohort)
        .map((f) => f.value)
        .filter((v): v is number => typeof v === 'number')

const useDebounceLoading = (loading: boolean, delay = 200): boolean => {
    const [debouncedLoading, setDebouncedLoading] = useState(false)

    useEffect(() => {
        const timer = setTimeout(() => {
            setDebouncedLoading(loading)
        }, delay)

        return () => clearTimeout(timer)
    }, [loading, delay])

    return debouncedLoading
}

export function ViewportChooser({ lockedWidth }: { lockedWidth?: number }): JSX.Element {
    const { widthOverride } = useValues(heatmapDataLogic({ context: 'in-app' }))
    const { setWindowWidthOverride } = useActions(heatmapDataLogic({ context: 'in-app' }))

    const options = [
        {
            value: 320,
            icon: <IconPhone />,
        },
        {
            value: 375,
            icon: <IconPhone />,
        },
        {
            value: 425,
            icon: <IconPhone />,
        },
        {
            value: 768,
            icon: <IconTabletPortrait />,
        },
        {
            value: 1024,
            icon: <IconTabletLandscape />,
        },
        {
            value: 1440,
            icon: <IconLaptop />,
        },
        {
            value: 1920,
            icon: <IconLaptop />,
        },
    ]

    const allOptions = lockedWidth ? [{ value: lockedWidth, icon: <IconLaptop /> }] : [...options]
    if (!lockedWidth && widthOverride && !options.some((option) => option.value === widthOverride)) {
        allOptions.push({
            value: widthOverride,
            icon: <IconLaptop />,
        })
    }

    return (
        <div className="flex justify-center items-center gap-2">
            <span>Screen width:</span>
            <LemonSelect
                size="small"
                onChange={setWindowWidthOverride}
                value={lockedWidth ?? widthOverride}
                disabledReason={lockedWidth ? 'Toolbar captures are saved at a single width' : undefined}
                data-attr="viewport-chooser"
                options={allOptions.map(({ value, icon }) => ({
                    value,
                    label: (
                        <div className="flex items-center gap-1">
                            {icon}
                            <div className="text-xs">{value} px</div>
                        </div>
                    ),
                }))}
            />
        </div>
    )
}

/**
 * values and actions are passed as props because they are different
 * between fixed and embedded mode
 */
export function FilterPanel({
    captureMethod,
    onCaptureMethodChange,
    clickmapSettings,
    lockedWidth,
}: {
    captureMethod?: HeatmapType
    onCaptureMethodChange?: (type: HeatmapType) => void
    clickmapSettings?: JSX.Element
    lockedWidth?: number
}): JSX.Element {
    const [isSettingsOpen, setIsSettingsOpen] = useState(false)
    const [isEventFilterOpen, setIsEventFilterOpen] = useState(false)
    const {
        heatmapFilters,
        heatmapColorPalette,
        heatmapFixedPositionMode,
        viewportRange,
        commonFilters,
        rawHeatmapLoading,
        heatmapEmpty,
    } = useValues(heatmapDataLogic({ context: 'in-app' }))

    const { patchHeatmapFilters, setHeatmapColorPalette, setHeatmapFixedPositionMode, setCommonFilters } = useActions(
        heatmapDataLogic({ context: 'in-app' })
    )

    const cohortFilterEnabled = useFeatureFlag('HEATMAPS_COHORT_FILTER')
    const eventFilterEnabled = useFeatureFlag('HEATMAPS_EVENT_FILTER')
    const eventFilterCount = commonFilters?.events?.length ?? 0

    const debouncedLoading = useDebounceLoading(rawHeatmapLoading ?? false)

    // KLUDGE: the loading bar flaps in visual regression tests,
    // for some reason our wait for loading to finish can't see it
    // this is ugly but better than stopping taking visual snapshots of it
    return (
        <>
            {debouncedLoading && !inStorybook() && !inStorybookTestRunner() && (
                <LoadingBar
                    wrapperClassName="absolute top-0 left-0 w-full overflow-hidden rounded-none my-0"
                    className="h-1 rounded-none"
                />
            )}
            <div className="flex-none md:flex justify-between items-center gap-2 my-2">
                <div className="flex-none md:flex items-center gap-2 my-2 md:my-0">
                    <DateFilter
                        dateFrom={commonFilters?.date_from}
                        dateTo={commonFilters?.date_to}
                        onChange={(fromDate, toDate) => {
                            setCommonFilters?.({ ...commonFilters, date_from: fromDate, date_to: toDate })
                        }}
                        dateOptions={heatmapDateOptions}
                    />
                    {cohortFilterEnabled && (
                        <div className="mt-2 md:mt-0">
                            <PropertyFilters
                                pageKey="heatmap-cohorts"
                                propertyFilters={cohortIdsToPropertyFilters(commonFilters?.cohort_ids ?? [])}
                                onChange={(filters) =>
                                    setCommonFilters?.({
                                        ...commonFilters,
                                        cohort_ids: propertyFiltersToCohortIds(filters),
                                    })
                                }
                                taxonomicGroupTypes={[TaxonomicFilterGroupType.Cohorts]}
                                buttonText="Filter by cohort"
                                addText="Add cohort filter"
                                buttonSize="small"
                                {...COHORTS_ONLY_SUPPORT_IN_PICKER_PROPS}
                            />
                        </div>
                    )}
                    {eventFilterEnabled && (
                        <div className="mt-2 md:mt-0">
                            <Popover
                                overlay={
                                    // The filter bar is a single row of controls, so the event list, which grows a
                                    // row per event, sits in a popover rather than stretching the row it lives in.
                                    <div className="p-2 w-96">
                                        <ActionFilter
                                            bordered
                                            filters={{ events: commonFilters?.events ?? [] }}
                                            setFilters={(filters) => {
                                                setCommonFilters?.({
                                                    ...commonFilters,
                                                    // ActionFilter types events as the loose Record shape; narrow
                                                    // back to what heatmapDataLogic serializes.
                                                    events: (filters.events ?? []) as HeatmapEventFilter[],
                                                })
                                            }}
                                            typeKey="heatmap-events"
                                            buttonCopy="Add event"
                                            mathAvailability={MathAvailability.None}
                                            actionsTaxonomicGroupTypes={[TaxonomicFilterGroupType.Events]}
                                            // "All events" matches every session, so as a filter it does nothing.
                                            excludedProperties={{ [TaxonomicFilterGroupType.Events]: [null] }}
                                            propertiesTaxonomicGroupTypes={[
                                                TaxonomicFilterGroupType.EventProperties,
                                                TaxonomicFilterGroupType.EventFeatureFlags,
                                            ]}
                                            propertyFiltersPopover
                                            hideRename
                                            hideDuplicate
                                            showNestedArrow={false}
                                        />
                                    </div>
                                }
                                visible={isEventFilterOpen}
                                onClickOutside={() => setIsEventFilterOpen(false)}
                                placement="bottom"
                            >
                                <LemonButton
                                    type="secondary"
                                    size="small"
                                    icon={<IconFilter />}
                                    sideIcon={
                                        eventFilterCount ? (
                                            <LemonBadge.Number count={eventFilterCount} size="small" />
                                        ) : undefined
                                    }
                                    onClick={() => setIsEventFilterOpen(!isEventFilterOpen)}
                                    tooltip="Only show interactions from sessions where these events happened"
                                    data-attr="heatmap-event-filter"
                                >
                                    Filter by event
                                </LemonButton>
                            </Popover>
                        </div>
                    )}
                    <div className="mt-2 md:mt-0">
                        <Popover
                            overlay={
                                <div className="p-2 w-80">
                                    <HeatmapsSettings
                                        heatmapFilters={heatmapFilters}
                                        patchHeatmapFilters={patchHeatmapFilters}
                                        viewportRange={viewportRange}
                                        heatmapColorPalette={heatmapColorPalette}
                                        setHeatmapColorPalette={setHeatmapColorPalette}
                                        heatmapFixedPositionMode={heatmapFixedPositionMode}
                                        setHeatmapFixedPositionMode={setHeatmapFixedPositionMode}
                                    />
                                    {captureMethod && onCaptureMethodChange && (
                                        <SectionSetting
                                            title="Capture method"
                                            info="Screenshot generates a full-page screenshot. Iframe loads your site directly."
                                        >
                                            <LemonSegmentedButton
                                                onChange={onCaptureMethodChange}
                                                value={captureMethod}
                                                options={[
                                                    {
                                                        value: 'screenshot',
                                                        label: 'Screenshot',
                                                    },
                                                    {
                                                        value: 'iframe',
                                                        label: 'Iframe',
                                                    },
                                                ]}
                                                size="small"
                                            />
                                        </SectionSetting>
                                    )}
                                </div>
                            }
                            visible={isSettingsOpen}
                            onClickOutside={() => {
                                setIsSettingsOpen(false)
                            }}
                            placement="bottom"
                        >
                            <LemonButton
                                type="secondary"
                                size="small"
                                onClick={() => setIsSettingsOpen(!isSettingsOpen)}
                                icon={<IconGear />}
                                tooltip="Heatmap settings"
                                data-attr="heatmap-settings"
                            >
                                Heatmap settings
                            </LemonButton>
                        </Popover>
                    </div>
                    {clickmapSettings ? <div className="mt-2 md:mt-0">{clickmapSettings}</div> : null}
                    <div className="mt-2 md:mt-0">
                        <TestAccountFilter
                            size="small"
                            filters={{ filter_test_accounts: commonFilters?.filter_test_accounts }}
                            onChange={(value) => {
                                setCommonFilters?.({
                                    ...commonFilters,
                                    filter_test_accounts: value.filter_test_accounts,
                                })
                            }}
                        />
                    </div>
                </div>
                <ViewportChooser lockedWidth={lockedWidth} />
            </div>
            {heatmapEmpty ? (
                <LemonBanner type="info" className="mb-2">
                    No data found. Try a different date range or URL, or lower the "Viewport accuracy" in heatmap
                    settings. A high value can hide data on pages with less traffic.
                </LemonBanner>
            ) : null}
        </>
    )
}
