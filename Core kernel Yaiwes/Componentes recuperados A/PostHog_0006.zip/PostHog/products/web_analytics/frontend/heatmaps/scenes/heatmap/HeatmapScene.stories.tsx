import { Meta, StoryObj } from '@storybook/react'

import { FEATURE_FLAGS } from 'lib/constants'
import { App } from 'scenes/App'
import { urls } from 'scenes/urls'

import { mswDecorator } from '~/mocks/browser'

const generatingSaved = {
    id: 100,
    short_id: 'hm_gen',
    name: 'Generating…',
    url: 'https://example.com',
    data_url: 'https://example.com',
    target_widths: [768, 1024],
    type: 'screenshot',
    status: 'processing',
    has_content: false,
    snapshots: [],
    deleted: false,
    created_by: { id: 1, uuid: 'user-1', distinct_id: 'd1', first_name: 'Alice', email: 'alice@ph.com' },
    created_at: '2024-01-01T00:00:00Z',
    updated_at: '2024-01-01T00:00:00Z',
    exception: null,
}

const meta: Meta = {
    component: App,
    title: 'Scenes-App/Heatmap',
    parameters: {
        layout: 'fullscreen',
        viewMode: 'story',
        pageUrl: urls.heatmap('hm_gen'),
        testOptions: {
            waitForLoadersToDisappear: true,
        },
    },
    decorators: [
        mswDecorator({
            get: {
                '/api/projects/:team_id/saved/hm_gen/': generatingSaved,
                '/api/projects/:team_id/heatmap_screenshots/:id/content/': () => [202, generatingSaved],
            },
        }),
    ],
}
export default meta

type Story = StoryObj<{}>

export const Generating: Story = {
    parameters: {
        testOptions: {
            waitForLoadersToDisappear: false,
        },
    },
}

const makeIframeSaved = (): Record<string, unknown> => ({
    id: 101,
    short_id: 'hm_iframe',
    name: 'Iframe example.com',
    url: `${window.location.origin}/mock-page.html`,
    data_url: `${window.location.origin}/mock-page.html`,
    target_widths: [],
    type: 'iframe',
    status: 'completed',
    has_content: false,
    snapshots: [],
    deleted: false,
    created_by: { id: 1, uuid: 'user-1', distinct_id: 'd1', first_name: 'Alice', email: 'alice@ph.com' },
    created_at: '2024-01-03T00:00:00Z',
    updated_at: '2024-01-03T00:00:00Z',
    exception: null,
})

export const IframeExample: Story = {
    parameters: {
        pageUrl: urls.heatmap('hm_iframe'),
        testOptions: {
            // Wait for heatmap canvas to be ready with data loaded
            waitForSelector: '.heatmaps-ready',
            waitForLoadersToDisappear: true,
            // The overlay is 800px tall until the heatmap data arrives, then grows to fit the lowest
            // point. The app shell fixes its own height before the fetch resolves, so at the default
            // 720px viewport the page height depended on which of the two won the race. A viewport at
            // least as tall as the loaded overlay makes both states resolve to the same height.
            viewport: { width: 1280, height: 1300 },
        },
    },
    decorators: [
        mswDecorator({
            get: {
                '/api/projects/:team_id/saved/hm_iframe/': () => [200, makeIframeSaved()],
                '/api/projects/:team_id/heatmaps/': () => [
                    200,
                    {
                        results: [
                            { pointer_relative_x: 0.4, pointer_target_fixed: false, pointer_y: 355, count: 85 },
                            { pointer_relative_x: 0.7, pointer_target_fixed: false, pointer_y: 24, count: 32 },
                            { pointer_relative_x: 0.77, pointer_target_fixed: false, pointer_y: 24, count: 28 },
                            { pointer_relative_x: 0.84, pointer_target_fixed: false, pointer_y: 24, count: 15 },
                            { pointer_relative_x: 0.91, pointer_target_fixed: false, pointer_y: 24, count: 12 },
                            { pointer_relative_x: 0.1, pointer_target_fixed: false, pointer_y: 24, count: 18 },
                            { pointer_relative_x: 0.17, pointer_target_fixed: false, pointer_y: 1150, count: 22 },
                            { pointer_relative_x: 0.5, pointer_target_fixed: false, pointer_y: 1150, count: 19 },
                            { pointer_relative_x: 0.83, pointer_target_fixed: false, pointer_y: 1150, count: 14 },
                        ],
                        count: 9,
                        next: null,
                        previous: null,
                    },
                ],
            },
        }),
    ],
}

export const IframeExampleWithEventFilter: Story = {
    parameters: {
        ...IframeExample.parameters,
        featureFlags: [FEATURE_FLAGS.HEATMAPS_EVENT_FILTER],
    },
    decorators: IframeExample.decorators,
}

export const New: Story = {
    parameters: {
        pageUrl: urls.heatmap('new'),
    },
}
