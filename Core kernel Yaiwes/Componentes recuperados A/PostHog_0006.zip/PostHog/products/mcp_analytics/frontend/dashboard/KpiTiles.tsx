import { Link } from '@posthog/lemon-ui'
import { type ChartTheme } from '@posthog/quill-charts'

import { formatPercentage } from 'lib/utils/numbers'
import { urls } from 'scenes/urls'

import { type KPIData, KPIMetric } from '../mcpDashboardOverviewLogic'
import { formatBucketLabel, formatMs, formatNumber } from './formatters'
import { MetricTile } from './MetricTile'

interface TileSpec {
    label: string
    metric: KPIMetric
    href: string
    format: (n: number) => string
    color: string
    loading: boolean
    summaryLabel: string
    // Overrides the summary caption — used to flag a tile whose value isn't
    // scoped by the dashboard filters.
    subtitle?: string
}

function KPITile({
    tile,
    theme,
    incompleteTail,
}: {
    tile: TileSpec
    theme: ChartTheme
    incompleteTail: boolean
}): JSX.Element {
    const { metric } = tile
    // Tiles whose metric carries no sparkline (Users, Intent clusters) have no segment to dash.
    const dashedFromIndex = incompleteTail && metric.sparkline.length >= 2 ? metric.sparkline.length - 1 : undefined

    return (
        <Link to={tile.href} subtle className="group/tile flex h-full">
            <MetricTile
                className="transition-transform group-hover/tile:-translate-y-0.5"
                label={tile.label}
                loading={tile.loading}
                value={metric.value}
                data={metric.sparkline}
                labels={metric.sparklineLabels.map(formatBucketLabel)}
                theme={theme}
                color={tile.color}
                goodDirection={metric.goodDirection}
                formatValue={tile.format}
                change={metric.deltaPct !== null ? { value: metric.deltaPct } : null}
                changeTooltip={
                    metric.deltaPct !== null
                        ? `vs. ${tile.format(metric.previousValue)} in the previous period`
                        : undefined
                }
                hoverChangeFromPreviousPoint
                restingSubtitle={tile.subtitle ?? tile.summaryLabel}
                sparklineHeight={50}
                sparklineDashedFromIndex={dashedFromIndex}
            />
        </Link>
    )
}

export function KpiTiles({
    kpis,
    users,
    intentClusterCount,
    kpisLoading,
    usersLoading,
    showIntentClusters,
    theme,
    incompleteTail,
}: {
    kpis: KPIData
    users: KPIMetric
    intentClusterCount: KPIMetric
    kpisLoading: boolean
    usersLoading: boolean
    showIntentClusters: boolean
    theme: ChartTheme
    // When true, the sparklines' final point is the current in-progress interval — dash it so a
    // partial period doesn't read as a decline. Required rather than optional: an omitted prop
    // silently renders the partial bucket as settled data.
    incompleteTail: boolean
}): JSX.Element {
    const tiles: TileSpec[] = [
        {
            label: 'Users',
            metric: users,
            // Person identity (email/name) is resolved on the Sessions tab, so that's the drill-down for "who".
            href: urls.mcpAnalyticsSessions(),
            format: formatNumber,
            color: theme.colors[2],
            loading: usersLoading,
            summaryLabel: 'Total',
        },
        {
            label: 'Sessions',
            metric: kpis.sessions,
            href: urls.mcpAnalyticsSessions(),
            format: formatNumber,
            color: theme.colors[0],
            loading: kpisLoading,
            summaryLabel: 'Total',
        },
        {
            label: 'Tool calls',
            metric: kpis.toolCalls,
            href: urls.mcpAnalyticsToolQuality(),
            format: formatNumber,
            color: theme.colors[0],
            loading: kpisLoading,
            summaryLabel: 'Total',
        },
        {
            label: 'Error rate',
            metric: kpis.errorRatePct,
            href: urls.mcpAnalyticsSessions(),
            format: (n) => formatPercentage(n, { compact: true }),
            color: theme.colors[4],
            loading: kpisLoading,
            summaryLabel: 'Latest',
        },
        {
            label: 'p95 latency',
            metric: kpis.p95LatencyMs,
            href: urls.mcpAnalyticsToolQuality(),
            format: formatMs,
            color: theme.colors[0],
            loading: kpisLoading,
            summaryLabel: 'Latest',
        },
        ...(showIntentClusters
            ? [
                  {
                      label: 'Intent clusters',
                      metric: intentClusterCount,
                      href: urls.mcpAnalyticsIntentClustering(),
                      format: formatNumber,
                      color: theme.colors[6],
                      loading: false,
                      summaryLabel: 'Total',
                      // Clusters come from the latest clustering snapshot across all sessions, so
                      // unlike the other tiles this count isn't scoped by the date or test-account
                      // filters. Label it so the grid doesn't read as a single consistent scope.
                      subtitle: 'Latest run · all sessions',
                  },
              ]
            : []),
    ]

    // Keep both flag states balanced: six tiles wrap as 3+3 or 2+2+2, while five stay on one
    // wide row. Container queries key off the card area's width rather than the viewport.
    return (
        <div className="@container">
            <div
                className={`grid gap-3 ${
                    showIntentClusters ? 'grid-cols-2 @xl:grid-cols-3 @6xl:grid-cols-6' : 'grid-cols-1 @xl:grid-cols-5'
                }`}
            >
                {tiles.map((tile) => (
                    <KPITile key={tile.label} tile={tile} theme={theme} incompleteTail={incompleteTail} />
                ))}
            </div>
        </div>
    )
}
