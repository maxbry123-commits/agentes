use crate::api::errors::FlagError;
use crate::flags::flag_group_type_mapping::GroupTypeIndex;
use crate::flags::flag_match_reason::FeatureFlagMatchReason;
use crate::flags::flag_matching::FeatureFlagMatch;
use crate::flags::flag_matching_utils::match_flag_value_to_flag_filter;
use crate::flags::flag_models::{FeatureFlag, FeatureFlagId, FlagFilters, Holdout};
use crate::properties::property_matching::match_property;
use crate::properties::property_models::OperatorType;
use chrono_tz::Tz;
use serde::{de, Deserialize, Deserializer, Serialize};
use serde_json::Value;
use std::{collections::HashMap, fmt, str::FromStr};
use uuid::Uuid;

fn format_operator_explanation(key: &str, op_label: &str, value: &Option<Value>) -> String {
    match value {
        Some(v) => format!("Property '{}' {} {}", key, op_label, v),
        None => format!("Property '{}' {} (empty)", key, op_label),
    }
}

#[derive(Debug, PartialEq, Eq, Deserialize, Serialize)]
pub enum FlagsResponseCode {
    Ok = 1,
}

#[derive(Clone, Debug, PartialEq, Eq, Deserialize, Serialize)]
#[serde(untagged)]
pub enum FlagValue {
    Boolean(bool),
    String(String),
}

#[derive(Debug, PartialEq, Eq, Deserialize, Serialize)]
pub struct LinkedFlag {
    pub flag: String,
    pub variant: String,
}

#[derive(Debug, Clone, PartialEq, Deserialize, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct SiteApp {
    pub id: i64,
    pub url: String,
}

#[derive(Debug, Clone, Copy, Deserialize, Serialize, PartialEq, Eq, Default)]
#[serde(rename_all = "lowercase")]
pub enum Compression {
    #[serde(alias = "gzip-js")]
    Gzip,
    Base64,
    #[default]
    #[serde(other)]
    Unsupported,
}

impl FromStr for Compression {
    type Err = String;

    fn from_str(s: &str) -> Result<Self, Self::Err> {
        match s.to_lowercase().as_str() {
            "gzip" | "gzip-js" => Ok(Compression::Gzip),
            "base64" => Ok(Compression::Base64),
            _ => Ok(Compression::Unsupported),
        }
    }
}

impl Compression {
    pub fn as_str(&self) -> &'static str {
        match self {
            Compression::Gzip => "gzip",
            Compression::Base64 => "base64",
            Compression::Unsupported => "unsupported",
        }
    }
}

#[derive(Clone, Deserialize, Default)]
pub struct FlagsQueryParams {
    /// Optional API version identifier, defaults to None (which returns a legacy response)
    #[serde(alias = "v", default, deserialize_with = "empty_string_as_none")]
    pub version: Option<String>,

    /// Compression type for the incoming request
    #[serde(default, deserialize_with = "empty_string_as_none")]
    pub compression: Option<Compression>,

    /// Library version (alias: "ver")
    #[serde(alias = "ver", default, deserialize_with = "empty_string_as_none")]
    pub lib_version: Option<String>,

    /// Optional timestamp indicating when the request was sent
    #[serde(
        alias = "_",
        default,
        deserialize_with = "deserialize_optional_timestamp"
    )]
    pub sent_at: Option<i64>,

    /// Optional boolean indicating whether to only evaluate survey feature flags
    #[serde(default, deserialize_with = "deserialize_optional_bool")]
    pub only_evaluate_survey_feature_flags: Option<bool>,

    /// Optional boolean indicating whether to include the config field in the response
    /// This lets us have parity with the legacy /decide endpoint so that we can support
    /// JS and other mobile clients need more config data than /flags supplied originally.
    /// e.g. https://us.posthog.com/flags?v=2&config=true
    #[serde(default, deserialize_with = "deserialize_optional_bool")]
    pub config: Option<bool>,
    /// Optional boolean indicating whether to include detailed condition analysis in the response
    /// When true, returns detailed information about why each condition matched or didn't match
    /// e.g. https://us.posthog.com/flags?v=2&detailed_analysis=true
    #[serde(default, deserialize_with = "deserialize_optional_bool")]
    pub detailed_analysis: Option<bool>,
    /// Optional boolean indicating whether to only use person properties from the request payload
    /// When true, ignores person properties from the database and only uses properties from person_properties field
    /// Useful for historical evaluation at specific timestamps
    /// e.g. https://us.posthog.com/flags?v=2&only_use_override_person_properties=true
    #[serde(default, deserialize_with = "deserialize_optional_bool")]
    pub only_use_override_person_properties: Option<bool>,
}

#[derive(Debug, PartialEq, Deserialize, Serialize)]
#[serde(untagged)]
pub enum ServiceResponse {
    Default(LegacyFlagsResponse),
    V2(FlagsResponse),
    DecideV1(DecideV1Response),
    DecideV2(DecideV2Response),
}

/// Config response that passes through Python's cached config as raw JSON.
///
/// This is a thin wrapper around a JSON map that allows Rust to pass through
/// config fields without knowing their structure. Only fields that Rust must
/// modify (like `sessionRecording` for quota limiting) are accessed directly.
#[derive(Debug, Clone, PartialEq, Eq, Deserialize, Serialize, Default)]
pub struct ConfigResponse {
    #[serde(flatten)]
    inner: HashMap<String, Value>,
}

impl ConfigResponse {
    /// Create an empty config response
    pub fn new() -> Self {
        Self {
            inner: HashMap::new(),
        }
    }

    /// Create a minimal fallback config for cache miss/error scenarios.
    ///
    /// This config disables optional features (session recording, surveys, heatmaps, etc.)
    /// to ensure safe degradation when the full config from Python's HyperCache is unavailable.
    pub fn fallback(has_feature_flags: bool) -> Self {
        let fallback = serde_json::json!({
            "hasFeatureFlags": has_feature_flags,
            "supportedCompression": ["gzip", "gzip-js"],
            "sessionRecording": false,
            "surveys": false,
            "heatmaps": false,
            "capturePerformance": false,
            "autocaptureExceptions": false,
            "isAuthenticated": false,
            "toolbarParams": {},
            "config": {"enable_collect_everything": true}
        });

        Self::from_value(fallback)
    }

    /// Create from a raw JSON Value (must be an object)
    pub fn from_value(value: Value) -> Self {
        match value {
            Value::Object(map) => Self {
                inner: map.into_iter().collect(),
            },
            _ => Self::new(),
        }
    }

    /// Set a field in the config
    pub fn set(&mut self, key: &str, value: Value) {
        self.inner.insert(key.to_string(), value);
    }

    /// Get a field from the config
    pub fn get(&self, key: &str) -> Option<&Value> {
        self.inner.get(key)
    }

    /// Check if config is empty
    pub fn is_empty(&self) -> bool {
        self.inner.is_empty()
    }
}

#[derive(Debug, PartialEq, Deserialize, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct FlagsResponse {
    /// Whether any errors occurred while evaluating feature flags.
    /// If true, some flags may be missing or have fallback values.
    pub errors_while_computing_flags: bool,
    /// Map of feature flag keys to their evaluation results and values
    pub flags: HashMap<String, FlagDetails>,
    /// List of resource types that hit quota limits during evaluation (e.g., "database", "redis")
    /// Only included in response if quotas were exceeded
    #[serde(skip_serializing_if = "Option::is_none")]
    pub quota_limited: Option<Vec<String>>,
    /// Unique identifier for this flag evaluation request, useful for debugging and tracing
    pub request_id: Uuid,
    /// Timestamp when flags were evaluated, in milliseconds since Unix epoch
    pub evaluated_at: i64,
    /// Set to `true` when the team is gated into slim `$feature_flag_called` events
    /// (TeamFeatureFlagsConfig.minimal_flag_called_events). Omitted otherwise, so SDKs
    /// that see no field at all fall back to full events, same as legacy teams.
    /// Only reaches the wire on this v2 shape: `LegacyFlagsResponse`, `DecideV1Response`,
    /// and `DecideV2Response` intentionally never carry it over. SDKs old enough to hit
    /// those response shapes predate this field and have no code path that reads it, so
    /// there's nothing gained by sending it to them.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub minimal_flag_called_events: Option<bool>,

    /// Additional configuration data merged into the response at the top level
    #[serde(flatten)]
    pub config: ConfigResponse,
}

/// Legacy `/flags` response shape. This and the two decide response shapes below never
/// carry `minimal_flag_called_events`: see the field's doc on `FlagsResponse` for why.
#[derive(Debug, PartialEq, Eq, Deserialize, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct LegacyFlagsResponse {
    pub errors_while_computing_flags: bool,
    pub feature_flags: HashMap<String, FlagValue>,
    pub feature_flag_payloads: HashMap<String, Value>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub quota_limited: Option<Vec<String>>, // list of quota limited resources
    pub request_id: Uuid,
    pub evaluated_at: i64,

    #[serde(flatten)]
    pub config: ConfigResponse,
}

impl LegacyFlagsResponse {
    pub fn from_response(response: FlagsResponse) -> Self {
        let mut feature_flags = HashMap::with_capacity(response.flags.len());
        let mut feature_flag_payloads = HashMap::with_capacity(response.flags.len());

        for (key, mut flag) in response.flags {
            let payload = flag.metadata.payload.take();
            let flag_value = flag.into_value();
            if let Some(payload) = payload {
                feature_flags.insert(key.clone(), flag_value);
                feature_flag_payloads.insert(key, payload);
            } else {
                feature_flags.insert(key, flag_value);
            }
        }

        Self {
            errors_while_computing_flags: response.errors_while_computing_flags,
            feature_flags,
            feature_flag_payloads,
            quota_limited: response.quota_limited,
            request_id: response.request_id,
            evaluated_at: response.evaluated_at,
            config: response.config,
        }
    }
}

/// Legacy decide v1 format response - returns just a list of active flag keys
#[derive(Debug, PartialEq, Eq, Deserialize, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct DecideV1Response {
    pub feature_flags: Vec<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub quota_limited: Option<Vec<String>>,
    pub request_id: Uuid,
    pub evaluated_at: i64,

    #[serde(flatten)]
    pub config: ConfigResponse,
}

impl DecideV1Response {
    pub fn from_response(response: FlagsResponse) -> Self {
        // Only include flags that are enabled (active)
        let active_flags: Vec<String> = response
            .flags
            .into_iter()
            .filter(|(_, flag)| flag.enabled)
            .map(|(key, _)| key)
            .collect();

        Self {
            feature_flags: active_flags,
            quota_limited: response.quota_limited,
            request_id: response.request_id,
            evaluated_at: response.evaluated_at,
            config: response.config,
        }
    }
}

/// Legacy decide v2 format response - returns active flags with their values
#[derive(Debug, PartialEq, Eq, Deserialize, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct DecideV2Response {
    pub feature_flags: HashMap<String, FlagValue>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub quota_limited: Option<Vec<String>>,
    pub request_id: Uuid,
    pub evaluated_at: i64,

    #[serde(flatten)]
    pub config: ConfigResponse,
}

impl DecideV2Response {
    pub fn from_response(response: FlagsResponse) -> Self {
        // Only include flags that are enabled
        let active_flags: HashMap<String, FlagValue> = response
            .flags
            .into_iter()
            .filter(|(_, flag)| flag.enabled)
            .map(|(key, flag)| (key, flag.into_value()))
            .collect();

        Self {
            feature_flags: active_flags,
            quota_limited: response.quota_limited,
            request_id: response.request_id,
            evaluated_at: response.evaluated_at,
            config: response.config,
        }
    }
}

impl FlagsResponse {
    pub fn new(
        errors_while_computing_flags: bool,
        flags: HashMap<String, FlagDetails>,
        quota_limited: Option<Vec<String>>,
        request_id: Uuid,
    ) -> Self {
        Self {
            errors_while_computing_flags,
            flags,
            quota_limited,
            request_id,
            evaluated_at: chrono::Utc::now().timestamp_millis(),
            minimal_flag_called_events: None,
            config: ConfigResponse::default(),
        }
    }

    /// Test helper to create a FlagsResponse with a specific evaluated_at timestamp
    #[cfg(test)]
    pub fn with_evaluated_at(
        errors_while_computing_flags: bool,
        flags: HashMap<String, FlagDetails>,
        quota_limited: Option<Vec<String>>,
        request_id: Uuid,
        evaluated_at: i64,
    ) -> Self {
        Self {
            errors_while_computing_flags,
            flags,
            quota_limited,
            request_id,
            evaluated_at,
            minimal_flag_called_events: None,
            config: ConfigResponse::default(),
        }
    }
}

#[derive(Debug, PartialEq, Eq, Deserialize, Serialize)]
pub struct FlagsOptionsResponse {
    pub status: FlagsResponseCode,
}

#[derive(Debug, Clone, PartialEq, Eq, Deserialize, Serialize)]
pub struct PropertyAnalysis {
    pub key: String,
    pub operator: String,
    pub value: Value,
    pub r#type: String,
    pub actual_value: Option<Value>,
    pub matched: bool,
    pub explanation: String,
}

/// `ConditionAnalysis::index` for the early-access enrollment entry, which has no position among
/// the zero-based release conditions. Negative so consumers can label it instead of "Condition #N".
/// Mirrored independently in `FeatureFlagTestingTab.tsx` and `FeatureFlagTestingView.tsx`: update
/// both if this value ever changes.
pub const SUPER_CONDITION_INDEX: i32 = -1;

/// `ConditionAnalysis::index` for the holdout entry, which (like enrollment) has no position among
/// the zero-based release conditions. Distinct from `SUPER_CONDITION_INDEX` so a flag with both an
/// enrollment super condition and a holdout keeps two separate synthetic rows. Mirrored independently
/// in `FeatureFlagTestingTab.tsx` and `FeatureFlagTestingView.tsx`: update all three if it changes.
pub const HOLDOUT_CONDITION_INDEX: i32 = -2;

#[derive(Debug, Clone, PartialEq, Deserialize, Serialize)]
pub struct ConditionAnalysis {
    pub index: i32,
    pub properties: Vec<PropertyAnalysis>,
    pub rollout_percentage: f64,
    pub variant: Option<String>,
    /// True when this condition was the one that won (i.e. determined the
    /// flag's enabled/variant outcome). Use this to find the winning condition
    /// in a list — it is guaranteed to be set on at most one condition per flag.
    pub matched: bool,
    /// True when every property in this condition evaluated to true,
    /// regardless of whether this condition was the eventual winner. A later
    /// condition may have won, an earlier one may have short-circuited the
    /// evaluation, or rollout may have excluded this condition entirely.
    pub properties_matched: bool,
    pub rollout_excluded: bool,
    pub explanation: String,
}

#[derive(Debug, PartialEq, Deserialize, Serialize)]
pub struct FlagDetails {
    pub key: String,
    pub enabled: bool,
    pub variant: Option<String>,
    #[serde(skip_serializing_if = "std::ops::Not::not")]
    pub failed: bool,
    pub reason: FlagEvaluationReason,
    pub metadata: FlagDetailsMetadata,
    /// Optional detailed condition analysis, only included when requested
    #[serde(skip_serializing_if = "Option::is_none")]
    pub conditions: Option<Vec<ConditionAnalysis>>,
}

impl FlagDetails {
    pub fn to_value(&self) -> FlagValue {
        if let Some(variant) = &self.variant {
            FlagValue::String(variant.clone())
        } else {
            FlagValue::Boolean(self.enabled)
        }
    }

    pub fn into_value(self) -> FlagValue {
        if let Some(variant) = self.variant {
            FlagValue::String(variant)
        } else {
            FlagValue::Boolean(self.enabled)
        }
    }
}

#[derive(Debug, PartialEq, Eq, Deserialize, Serialize)]
pub struct FlagDetailsMetadata {
    pub id: i32,
    pub version: i32,
    pub description: Option<String>,
    pub payload: Option<Value>,
    /// True if the flag has at least one non-deleted linked experiment. SDKs use this to
    /// decide whether to keep all $feature_flag_called event properties or send a minimal event.
    #[serde(default)]
    pub has_experiment: bool,
}

#[derive(Clone, Debug, PartialEq, Eq, Deserialize, Serialize)]
pub struct FlagEvaluationReason {
    pub code: String,
    pub condition_index: Option<i32>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub description: Option<String>,
}

pub trait FromFeatureAndMatch {
    fn create(flag: &FeatureFlag, flag_match: &FeatureFlagMatch) -> Self;
    fn create_with_analysis(
        flag: &FeatureFlag,
        flag_match: &FeatureFlagMatch,
        detailed_analysis: bool,
        property_values: Option<&HashMap<String, Value>>,
        group_property_values: Option<&HashMap<GroupTypeIndex, HashMap<String, Value>>>,
        flag_evaluation_results: Option<&HashMap<FeatureFlagId, FlagValue>>,
        team_timezone: Tz,
    ) -> Self;
    fn create_error(flag: &FeatureFlag, error: &FlagError, condition_index: Option<i32>) -> Self;
    fn get_reason_description(match_info: &FeatureFlagMatch) -> Option<String>;
}

impl FromFeatureAndMatch for FlagDetails {
    fn create(flag: &FeatureFlag, flag_match: &FeatureFlagMatch) -> Self {
        // Timezone is only consulted for detailed analysis, which is off here.
        Self::create_with_analysis(flag, flag_match, false, None, None, None, Tz::UTC)
    }

    fn create_with_analysis(
        flag: &FeatureFlag,
        flag_match: &FeatureFlagMatch,
        detailed_analysis: bool,
        property_values: Option<&HashMap<String, Value>>,
        group_property_values: Option<&HashMap<GroupTypeIndex, HashMap<String, Value>>>,
        flag_evaluation_results: Option<&HashMap<FeatureFlagId, FlagValue>>,
        team_timezone: Tz,
    ) -> Self {
        FlagDetails {
            key: flag.key.clone(),
            enabled: flag_match.matches,
            variant: flag_match.variant.clone(),
            failed: false,
            reason: FlagEvaluationReason {
                code: flag_match.reason.to_string(),
                condition_index: flag_match.condition_index.map(|i| i as i32),
                description: Self::get_reason_description(flag_match),
            },
            metadata: FlagDetailsMetadata {
                id: flag.id,
                version: flag.version.unwrap_or(0),
                description: None,
                payload: flag_match.payload.clone(),
                has_experiment: flag.has_experiment,
            },
            conditions: if detailed_analysis {
                Some(Self::build_condition_analysis(
                    flag,
                    flag_match,
                    property_values,
                    group_property_values,
                    flag_evaluation_results,
                    team_timezone,
                ))
            } else {
                None
            },
        }
    }

    fn create_error(flag: &FeatureFlag, error: &FlagError, condition_index: Option<i32>) -> Self {
        FlagDetails {
            key: flag.key.clone(),
            enabled: false,
            variant: None,
            failed: true,
            reason: FlagEvaluationReason {
                code: error.evaluation_error_code(),
                condition_index,
                description: Some(error.evaluation_error_description()),
            },
            metadata: FlagDetailsMetadata {
                id: flag.id,
                version: flag.version.unwrap_or(0),
                description: None,
                payload: None,
                has_experiment: flag.has_experiment,
            },
            conditions: None,
        }
    }

    fn get_reason_description(match_info: &FeatureFlagMatch) -> Option<String> {
        match match_info.reason {
            FeatureFlagMatchReason::ConditionMatch => {
                let set_number = match_info.condition_index.unwrap_or(0) + 1;
                Some(format!("Matched condition set {set_number}"))
            }
            FeatureFlagMatchReason::NoConditionMatch => {
                Some("No matching condition set".to_string())
            }
            FeatureFlagMatchReason::NoConditionMatchGroupsNotEvaluated => {
                Some("No matching condition set (group conditions were not evaluated because no group type was provided)".to_string())
            }
            FeatureFlagMatchReason::NoConditionMatchCohortNotEvaluated => {
                Some("This condition targets a behavioral or realtime cohort. Its membership is not fully evaluated here, so this result can differ from the cohort's member list.".to_string())
            }
            FeatureFlagMatchReason::OutOfRolloutBound => Some("Out of rollout bound".to_string()),
            FeatureFlagMatchReason::NoGroupType => Some("No group type".to_string()),
            FeatureFlagMatchReason::SuperConditionValue => {
                Some("Super condition value".to_string())
            }
            FeatureFlagMatchReason::HoldoutConditionValue => {
                Some("Holdout condition value".to_string())
            }
            FeatureFlagMatchReason::FlagDisabled => Some("Feature flag is disabled".to_string()),
            FeatureFlagMatchReason::MissingDependency => {
                Some("Flag cannot be evaluated due to missing dependency".to_string())
            }
        }
    }
}

impl FlagDetails {
    fn build_condition_analysis(
        flag: &FeatureFlag,
        flag_match: &FeatureFlagMatch,
        property_values: Option<&HashMap<String, Value>>,
        group_property_values: Option<&HashMap<GroupTypeIndex, HashMap<String, Value>>>,
        flag_evaluation_results: Option<&HashMap<FeatureFlagId, FlagValue>>,
        team_timezone: Tz,
    ) -> Vec<ConditionAnalysis> {
        let mut analyses = Vec::new();

        // Analyze each property group (condition)
        for (index, group) in flag.filters.groups.iter().enumerate() {
            let mut property_analyses = Vec::new();
            let mut condition_matched = false;

            // Effective aggregation for this condition: the per-condition group type
            // when set, otherwise the flag-level one. Used to resolve legacy group
            // filters that don't carry their own `group_type_index`. Mirrors the
            // aggregation the real matching path uses (flag_matching.rs), so an
            // explicit person aggregation (`Some(None)`) does not fall back to the
            // flag-level group index here.
            let effective_aggregation = group.effective_aggregation(flag.get_group_type_index());

            // Only a real ConditionMatch wins a release condition. Enrollment wins report
            // condition_index Some(0) and holdout wins report None, but neither is a ConditionMatch,
            // so gating on the reason keeps both from being attributed to a release condition here.
            if flag_match.matches
                && matches!(flag_match.reason, FeatureFlagMatchReason::ConditionMatch)
            {
                condition_matched = index == flag_match.condition_index.unwrap_or(0);
            }

            // Analyze properties within this group
            if let Some(properties) = &group.properties {
                for property in properties {
                    let operator_str = match property.operator {
                        Some(op) => format!("{:?}", op).to_lowercase(),
                        None => "exact".to_string(),
                    };

                    let type_str = match property.prop_type {
                        crate::properties::property_models::PropertyType::Person => "person",
                        crate::properties::property_models::PropertyType::PersonMetadata => {
                            "person_metadata"
                        }
                        crate::properties::property_models::PropertyType::Group => "group",
                        crate::properties::property_models::PropertyType::Cohort => "cohort",
                        crate::properties::property_models::PropertyType::Flag => "flag",
                    }
                    .to_string();

                    // Flag-dependency filters don't evaluate against person/group properties — they
                    // resolve against the result of the flag they depend on. Running them through
                    // match_property() (which rejects the FlagEvaluatesTo operator and returns Err)
                    // would always report matched=false, contradicting the condition-level outcome.
                    // Resolve them against the actual flag evaluation results instead.
                    if property.depends_on_feature_flag() {
                        let empty = HashMap::new();
                        let property_matched = match_flag_value_to_flag_filter(
                            property,
                            flag_evaluation_results.unwrap_or(&empty),
                        );
                        // Do not expose the dependency flag's evaluated value here. The caller is
                        // only authorized for the flag under test, not necessarily the dependency
                        // flag, so serializing its raw value would leak it. `matched` reflects the
                        // tested flag's own condition outcome, which the caller may already see.
                        let expected = property.value.clone().unwrap_or(Value::Null);
                        let explanation = if property_matched {
                            format!(
                                "Flag dependency '{}' satisfied the required value {}",
                                property.key, expected
                            )
                        } else {
                            format!(
                                "Flag dependency '{}' did not satisfy the required value {}",
                                property.key, expected
                            )
                        };
                        property_analyses.push(PropertyAnalysis {
                            key: property.key.clone(),
                            operator: operator_str,
                            value: expected,
                            r#type: type_str,
                            actual_value: None,
                            matched: property_matched,
                            explanation,
                        });
                        continue;
                    }

                    // Generate explanation placeholder - will be updated after we know if property matched
                    let explanation_placeholder = match property.operator {
                        Some(OperatorType::IsSet) => ("is set", "is not set"),
                        Some(OperatorType::IsNotSet) => ("is not set", "is set"),
                        Some(OperatorType::Exact) => ("equals", "does not equal"),
                        Some(OperatorType::IsNot) => ("does not equal", "equals"),
                        Some(OperatorType::Icontains) => ("contains", "does not contain"),
                        Some(OperatorType::NotIcontains) => ("does not contain", "contains"),
                        Some(OperatorType::StartsWith) => ("starts with", "does not start with"),
                        Some(OperatorType::NotStartsWith) => ("does not start with", "starts with"),
                        Some(OperatorType::EndsWith) => ("ends with", "does not end with"),
                        Some(OperatorType::NotEndsWith) => ("does not end with", "ends with"),
                        Some(OperatorType::Gt) => (">", "<="),
                        Some(OperatorType::Lt) => ("<", ">="),
                        Some(OperatorType::Gte) => (">=", "<"),
                        Some(OperatorType::Lte) => ("<=", ">"),
                        Some(OperatorType::In) => ("is in", "is not in"),
                        Some(OperatorType::NotIn) => ("is not in", "is in"),
                        Some(OperatorType::Regex) => ("matches regex", "does not match regex"),
                        Some(OperatorType::NotRegex) => ("does not match regex", "matches regex"),
                        _ => (operator_str.as_str(), "does not match"),
                    };

                    // Route each filter to the correct property namespace. Group-typed
                    // filters (e.g. a group `name` or `$group_key`) must be resolved
                    // against the named group's properties, not the person's — otherwise
                    // a matching group condition reports `matched: false` with the
                    // person's value (or null) as `actual_value`. Mirrors the routing in
                    // `PropertyContext::resolve_for_filter` used during actual matching.
                    let resolved_props = match property.prop_type {
                        crate::properties::property_models::PropertyType::Group => {
                            let gti = property.group_type_index.or(effective_aggregation);
                            gti.and_then(|idx| group_property_values.and_then(|m| m.get(&idx)))
                        }
                        _ => property_values,
                    };

                    let (property_matched, actual_value) = if let Some(props) = resolved_props {
                        let actual = props.get(&property.key).cloned();
                        let matched =
                            match_property(property, props, false, team_timezone).unwrap_or(false);
                        (matched, actual)
                    } else {
                        // No properties available, fall back to condition-level match
                        (condition_matched, None)
                    };

                    // Generate the correct explanation based on whether the property matched
                    let explanation = if property_matched {
                        match property.operator {
                            Some(OperatorType::IsSet) | Some(OperatorType::IsNotSet) => {
                                format!("Property '{}' {}", property.key, explanation_placeholder.0)
                            }
                            _ => format_operator_explanation(
                                &property.key,
                                explanation_placeholder.0,
                                &property.value,
                            ),
                        }
                    } else {
                        match property.operator {
                            Some(OperatorType::IsSet) | Some(OperatorType::IsNotSet) => {
                                format!("Property '{}' {}", property.key, explanation_placeholder.1)
                            }
                            _ => format_operator_explanation(
                                &property.key,
                                explanation_placeholder.1,
                                &property.value,
                            ),
                        }
                    };

                    let property_analysis = PropertyAnalysis {
                        key: property.key.clone(),
                        operator: operator_str,
                        value: property.value.clone().unwrap_or(serde_json::Value::Null),
                        r#type: type_str,
                        actual_value,
                        matched: property_matched,
                        explanation,
                    };
                    property_analyses.push(property_analysis);
                }
            }

            // Determine rollout status and properties match status
            let rollout_percentage = group.rollout_percentage.unwrap_or(100.0);
            let is_zero_rollout = rollout_percentage == 0.0;

            // Check if this condition has properties that would need to be evaluated
            let has_properties = group
                .properties
                .as_ref()
                .map(|props| !props.is_empty())
                .unwrap_or(false);

            // Determine if all properties in this condition actually matched
            let all_properties_matched = if has_properties {
                property_analyses.iter().all(|prop| prop.matched)
            } else {
                // If no properties, consider it a match (rollout-only condition)
                true
            };

            // Key insight: Use the overall match reason to determine what happened
            // If reason is OutOfRolloutBound, it means properties matched but rollout failed
            let properties_matched_but_rollout_failed =
                matches!(flag_match.reason, FeatureFlagMatchReason::OutOfRolloutBound);

            // Determine if this specific condition was the one that got excluded by rollout
            let this_condition_rollout_excluded = if properties_matched_but_rollout_failed {
                // If overall reason is OutOfRolloutBound, check if this condition has matching index
                if let Some(match_condition_index) = flag_match.condition_index {
                    // This condition was the one that matched properties but failed rollout
                    index == match_condition_index && is_zero_rollout
                } else {
                    // No specific condition index, so could be this one if it has zero rollout
                    is_zero_rollout && all_properties_matched
                }
            } else {
                // Overall reason is not OutOfRolloutBound, so use simple zero rollout check
                is_zero_rollout && all_properties_matched
            };

            // 1-based to match the frontend's Condition #N headers.
            let explanation = if this_condition_rollout_excluded {
                format!(
                    "Condition {} matched properties but was excluded by {}% rollout",
                    index + 1,
                    rollout_percentage
                )
            } else if all_properties_matched && condition_matched {
                format!(
                    "Condition {} matched and passed {}% rollout",
                    index + 1,
                    rollout_percentage
                )
            } else if all_properties_matched && !condition_matched {
                format!(
                    "Condition {} matched properties but was not evaluated due to an earlier condition matching",
                    index + 1
                )
            } else {
                format!("Condition {} did not match properties", index + 1)
            };

            let analysis = ConditionAnalysis {
                index: index as i32,
                properties: property_analyses,
                rollout_percentage,
                variant: group.variant.clone(),
                matched: condition_matched,
                properties_matched: all_properties_matched,
                rollout_excluded: this_condition_rollout_excluded,
                explanation,
            };

            analyses.push(analysis);
        }

        // Surface synthetic entries the matcher evaluates before the release conditions above but
        // which the loop can't see, in the matcher's enrollment-then-holdout evaluation order.
        let mut synthetic = Vec::new();

        if flag.filters.feature_enrollment == Some(true) {
            synthetic.push(Self::build_enrollment_condition_analysis(
                flag,
                flag_match,
                property_values,
            ));
        }

        // Holdout is only shown when the flag actually resolved through it — the "excluded from
        // holdout" case isn't distinguishable here without threading the holdout hash result down
        // from the matcher.
        if matches!(
            flag_match.reason,
            FeatureFlagMatchReason::HoldoutConditionValue
        ) {
            if let Some(holdout) = &flag.filters.holdout {
                synthetic.push(Self::build_holdout_condition_analysis(holdout, flag_match));
            }
        }

        if synthetic.is_empty() {
            return analyses;
        }

        synthetic.extend(analyses);
        synthetic
    }

    /// Synthetic [`ConditionAnalysis`] for the holdout, surfaced only when the matcher resolved the
    /// flag through it (reason `HoldoutConditionValue`). The holdout has no person properties — it's
    /// a hash rollout keyed on the flag's aggregation — so the entry carries no property rows and
    /// explains the exclusion percentage in prose instead.
    fn build_holdout_condition_analysis(
        holdout: &Holdout,
        flag_match: &FeatureFlagMatch,
    ) -> ConditionAnalysis {
        let exclusion_percentage = holdout.exclusion_percentage_clamped();

        ConditionAnalysis {
            index: HOLDOUT_CONDITION_INDEX,
            properties: vec![],
            rollout_percentage: 100.0,
            variant: flag_match.variant.clone(),
            matched: true,
            properties_matched: true,
            rollout_excluded: false,
            explanation: format!(
                "In the holdout group ({exclusion_percentage}% of users are held out). This overrides all release conditions and holds the flag at its holdout value"
            ),
        }
    }

    /// Synthetic [`ConditionAnalysis`] for the early-access enrollment super condition.
    fn build_enrollment_condition_analysis(
        flag: &FeatureFlag,
        flag_match: &FeatureFlagMatch,
        property_values: Option<&HashMap<String, Value>>,
    ) -> ConditionAnalysis {
        let enrollment_key = FlagFilters::enrollment_key(&flag.key);

        // Mirrors the matcher's opted-in check; absent means enrollment doesn't apply.
        let actual_value = property_values.and_then(|props| props.get(&enrollment_key).cloned());
        let enrolled = actual_value.as_ref().is_some_and(FlagFilters::is_enrolled);

        // Winner only when the matcher actually resolved the flag through enrollment.
        let matched = enrolled
            && flag_match.matches
            && matches!(
                flag_match.reason,
                FeatureFlagMatchReason::SuperConditionValue
            );

        let (property_matched, property_explanation, explanation) = if enrolled {
            (
                true,
                format!("Property '{enrollment_key}' is true (opted in)"),
                "Enrolled in the early access feature. This overrides all release conditions and enables the flag".to_string(),
            )
        } else if actual_value.is_some() {
            (
                false,
                format!("Property '{enrollment_key}' is set but not true (opted out)"),
                "Opted out of the early access feature. This overrides all release conditions and disables the flag".to_string(),
            )
        } else {
            (
                false,
                format!("Property '{enrollment_key}' is not set (not enrolled)"),
                "Not enrolled in the early access feature. The release conditions below are evaluated normally".to_string(),
            )
        };

        ConditionAnalysis {
            index: SUPER_CONDITION_INDEX,
            properties: vec![PropertyAnalysis {
                key: enrollment_key,
                operator: "exact".to_string(),
                value: Value::Bool(true),
                r#type: "person".to_string(),
                actual_value,
                matched: property_matched,
                explanation: property_explanation,
            }],
            rollout_percentage: 100.0,
            variant: None,
            matched,
            properties_matched: enrolled,
            rollout_excluded: false,
            explanation,
        }
    }
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize, Default, Eq)]
#[serde(rename_all = "camelCase")]
pub struct AnalyticsConfig {
    pub endpoint: Option<String>,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize, Default, Eq)]
#[serde(rename_all = "camelCase")]
pub struct SessionRecordingConfig {
    pub endpoint: Option<String>,
    pub console_log_recording_enabled: Option<bool>,
    pub recorder_version: Option<String>,
    pub sample_rate: Option<String>,
    pub minimum_duration_milliseconds: Option<i32>,
    pub linked_flag: Option<Value>, // string or object
    pub network_payload_capture: Option<Value>,
    pub masking: Option<Value>,
    pub url_triggers: Option<Value>,
    pub script_config: Option<Value>,
    pub url_blocklist: Option<Value>,
    pub event_triggers: Option<Value>,
    pub trigger_match_type: Option<Value>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub record_canvas: Option<bool>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub canvas_fps: Option<u8>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub canvas_quality: Option<String>,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize, Eq)]
#[serde(untagged)]
pub enum SessionRecordingField {
    Disabled(bool), // NB: this should only ever be false
    Config(Box<SessionRecordingConfig>),
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize, Default, Eq)]
#[serde(rename_all = "camelCase")]
pub struct LogsConfig {
    pub capture_console_logs: Option<bool>,
}

impl Default for SessionRecordingField {
    fn default() -> Self {
        SessionRecordingField::Disabled(false)
    }
}

/// Generic deserializer that treats empty strings as None for any type that implements FromStr
fn empty_string_as_none<'de, D, T>(de: D) -> Result<Option<T>, D::Error>
where
    D: Deserializer<'de>,
    T: FromStr,
    T::Err: fmt::Display,
{
    let opt = Option::<String>::deserialize(de)?;
    match opt.as_deref() {
        None | Some("") => Ok(None),
        Some(s) => FromStr::from_str(s).map_err(de::Error::custom).map(Some),
    }
}

/// Deserializer for timestamps that handles both strings and integers
fn deserialize_optional_timestamp<'de, D>(de: D) -> Result<Option<i64>, D::Error>
where
    D: Deserializer<'de>,
{
    #[derive(Deserialize)]
    #[serde(untagged)]
    enum IntOrString {
        Int(i64),
        String(String),
    }

    let opt = Option::<IntOrString>::deserialize(de)?;
    match opt {
        None => Ok(None),
        Some(IntOrString::Int(i)) => Ok(Some(i)),
        Some(IntOrString::String(s)) if s.is_empty() => Ok(None),
        Some(IntOrString::String(s)) => s.parse().map(Some).map_err(de::Error::custom),
    }
}

/// Deserializer for boolean query parameters that treats presence as true
/// Examples:
/// - `?config` → Some(true)
/// - `?config=` → Some(true)
/// - `?config=true` → Some(true)
/// - `?config=false` → Some(false)
/// - `?config=1` → Some(true)
/// - `?config=0` → Some(false)
/// - missing → None
fn deserialize_optional_bool<'de, D>(de: D) -> Result<Option<bool>, D::Error>
where
    D: Deserializer<'de>,
{
    #[derive(Deserialize)]
    #[serde(untagged)]
    enum BoolOrString {
        Bool(bool),
        String(String),
    }

    let opt = Option::<BoolOrString>::deserialize(de)?;
    match opt {
        None => Ok(None),
        Some(BoolOrString::Bool(b)) => Ok(Some(b)),
        Some(BoolOrString::String(s)) => {
            match s.to_lowercase().as_str() {
                "" => Ok(Some(true)), // Empty string = present = true
                "true" | "1" | "yes" | "on" => Ok(Some(true)),
                "false" | "0" | "no" | "off" => Ok(Some(false)),
                _ => Ok(Some(true)), // Any other value = true (presence indicates true)
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::flags::flag_match_reason::FeatureFlagMatchReason;
    use crate::flags::flag_match_reason::FeatureFlagMatchReason::{
        ConditionMatch, SuperConditionValue,
    };
    use crate::flags::flag_matching::FeatureFlagMatch;
    use chrono::Utc;
    use rstest::rstest;
    use serde_json::json;

    #[test]
    fn test_fallback_config_excludes_request_token() {
        let config = serde_json::to_value(ConfigResponse::fallback(true)).unwrap();

        assert!(config.get("token").is_none());
        assert_eq!(config["hasFeatureFlags"], json!(true));
    }

    #[rstest]
    #[case::condition_match(
        FeatureFlagMatch {
            matches: true,
            variant: None,
            reason: FeatureFlagMatchReason::ConditionMatch,
            condition_index: Some(0),
            payload: None,
        },
        Some("Matched condition set 1".to_string())
    )]
    #[case::condition_match_different_set(
        FeatureFlagMatch {
            matches: true,
            variant: None,
            reason: FeatureFlagMatchReason::ConditionMatch,
            condition_index: Some(2),
            payload: None,
        },
        Some("Matched condition set 3".to_string())
    )]
    #[case::no_condition_match(
        FeatureFlagMatch {
            matches: false,
            variant: None,
            reason: FeatureFlagMatchReason::NoConditionMatch,
            condition_index: None,
            payload: None,
        },
        Some("No matching condition set".to_string())
    )]
    #[case::out_of_rollout(
        FeatureFlagMatch {
            matches: false,
            variant: None,
            reason: FeatureFlagMatchReason::OutOfRolloutBound,
            condition_index: Some(2),
            payload: None,
        },
        Some("Out of rollout bound".to_string())
    )]
    #[case::no_group_type(
        FeatureFlagMatch {
            matches: false,
            variant: None,
            reason: FeatureFlagMatchReason::NoGroupType,
            condition_index: None,
            payload: None,
        },
        Some("No group type".to_string())
    )]
    #[case::super_condition(
        FeatureFlagMatch {
            matches: true,
            variant: None,
            reason: FeatureFlagMatchReason::SuperConditionValue,
            condition_index: None,
            payload: None,
        },
        Some("Super condition value".to_string())
    )]
    #[case::holdout_condition(
        FeatureFlagMatch {
            matches: true,
            variant: None,
            reason: FeatureFlagMatchReason::HoldoutConditionValue,
            condition_index: None,
            payload: None,
        },
        Some("Holdout condition value".to_string())
    )]
    #[case::flag_disabled(
        FeatureFlagMatch {
            matches: false,
            variant: None,
            reason: FeatureFlagMatchReason::FlagDisabled,
            condition_index: None,
            payload: None,
        },
        Some("Feature flag is disabled".to_string())
    )]
    #[case::missing_dependency(
        FeatureFlagMatch {
            matches: false,
            variant: None,
            reason: FeatureFlagMatchReason::MissingDependency,
            condition_index: None,
            payload: None,
        },
        Some("Flag cannot be evaluated due to missing dependency".to_string())
    )]
    #[case::no_condition_match_groups_not_evaluated(
        FeatureFlagMatch {
            matches: false,
            variant: None,
            reason: FeatureFlagMatchReason::NoConditionMatchGroupsNotEvaluated,
            condition_index: Some(0),
            payload: None,
        },
        Some("No matching condition set (group conditions were not evaluated because no group type was provided)".to_string())
    )]
    fn test_get_reason_description(
        #[case] flag_match: FeatureFlagMatch,
        #[case] expected_description: Option<String>,
    ) {
        assert_eq!(
            FlagDetails::get_reason_description(&flag_match),
            expected_description
        );
    }

    #[test]
    fn test_flags_response_only_includes_non_null_payloads() {
        // Create a response with multiple flags, some with payloads and some without
        let mut flags = HashMap::new();

        // Flag with payload
        flags.insert(
            "flag_with_payload".to_string(),
            FlagDetails {
                key: "flag_with_payload".to_string(),
                enabled: true,
                variant: None,
                failed: false,
                reason: FlagEvaluationReason {
                    code: "condition_match".to_string(),
                    condition_index: Some(0),
                    description: None,
                },
                metadata: FlagDetailsMetadata {
                    id: 1,
                    version: 1,
                    description: None,
                    payload: Some(json!({"key": "value"})),
                    has_experiment: false,
                },
                conditions: None,
            },
        );

        // Flag without payload
        flags.insert(
            "flag2".to_string(),
            FlagDetails {
                key: "flag2".to_string(),
                enabled: true,
                variant: None,
                failed: false,
                reason: FlagEvaluationReason {
                    code: "condition_match".to_string(),
                    condition_index: Some(0),
                    description: None,
                },
                metadata: FlagDetailsMetadata {
                    id: 2,
                    version: 1,
                    description: None,
                    payload: None,
                    has_experiment: false,
                },
                conditions: None,
            },
        );

        // Flag with null payload, which should not be filtered out; since Some(Value::Null) is not None
        flags.insert(
            "flag_with_null_payload".to_string(),
            FlagDetails {
                key: "flag_with_null_payload".to_string(),
                enabled: true,
                variant: None,
                failed: false,
                reason: FlagEvaluationReason {
                    code: "condition_match".to_string(),
                    condition_index: Some(0),
                    description: None,
                },
                metadata: FlagDetailsMetadata {
                    id: 3,
                    version: 1,
                    description: None,
                    payload: Some(Value::Null),
                    has_experiment: false,
                },
                conditions: None,
            },
        );

        let request_id = Uuid::new_v4();
        let evaluated_at = Utc::now().timestamp_millis();
        let response =
            FlagsResponse::with_evaluated_at(false, flags, None, request_id, evaluated_at);
        let legacy_response = LegacyFlagsResponse::from_response(response);

        // Check that only flag1 with actual payload is included
        assert_eq!(legacy_response.feature_flag_payloads.len(), 2);
        assert!(legacy_response
            .feature_flag_payloads
            .contains_key("flag_with_payload"));
        assert!(!legacy_response.feature_flag_payloads.contains_key("flag2"));
        assert!(legacy_response
            .feature_flag_payloads
            .contains_key("flag_with_null_payload"));

        // Verify the payload value
        assert_eq!(
            legacy_response
                .feature_flag_payloads
                .get("flag_with_payload"),
            Some(&json!({"key": "value"}))
        );
        assert_eq!(
            legacy_response
                .feature_flag_payloads
                .get("flag_with_null_payload"),
            Some(&json!(null))
        );

        // Check that the request_id is included
        assert_eq!(legacy_response.request_id, request_id);
    }

    #[test]
    fn test_config_fields_are_skipped_when_none() {
        let response = FlagsResponse::new(false, HashMap::new(), None, Uuid::new_v4());

        let json = serde_json::to_value(&response).unwrap();
        let obj = json.as_object().unwrap();

        // Config fields should not be present when None/empty
        assert!(!obj.contains_key("analytics"));
        assert!(!obj.contains_key("autocaptureExceptions"));
        assert!(!obj.contains_key("sessionRecording"));

        // Core fields should always be present
        assert!(obj.contains_key("errorsWhileComputingFlags"));
        assert!(obj.contains_key("flags"));
        assert!(obj.contains_key("requestId"));
    }

    #[test]
    fn test_minimal_flag_called_events_round_trips_through_serde() {
        let mut response = FlagsResponse::new(false, HashMap::new(), None, Uuid::new_v4());

        let json = serde_json::to_value(&response).unwrap();
        assert!(
            !json.as_object().unwrap().contains_key("minimalFlagCalledEvents"),
            "absence must mean full events — SDKs treat a missing key the same as an old cache entry"
        );

        response.minimal_flag_called_events = Some(true);
        let json = serde_json::to_value(&response).unwrap();
        assert_eq!(json.get("minimalFlagCalledEvents"), Some(&json!(true)));
    }

    #[test]
    fn test_config_fields_are_included_when_set() {
        let mut response = FlagsResponse::new(false, HashMap::new(), None, Uuid::new_v4());

        // Set some config fields using the new passthrough API
        response
            .config
            .set("analytics", json!({"endpoint": "/analytics"}));
        response.config.set("supportedCompression", json!(["gzip"]));

        let json = serde_json::to_value(&response).unwrap();

        let obj = json.as_object().unwrap();

        // Config fields should be present when set
        assert!(obj.contains_key("analytics"));
        assert!(obj.contains_key("supportedCompression"));
    }

    #[test]
    fn test_evaluated_at_field_is_present() {
        let before = Utc::now().timestamp_millis();
        let response = FlagsResponse::new(false, HashMap::new(), None, Uuid::new_v4());
        let after = Utc::now().timestamp_millis();

        let json = serde_json::to_value(&response).unwrap();
        let obj = json.as_object().unwrap();

        // evaluated_at field should always be present
        assert!(obj.contains_key("evaluatedAt"));

        // Verify it's a number and within a reasonable range
        let evaluated_at = obj.get("evaluatedAt").unwrap().as_i64().unwrap();
        assert!(evaluated_at >= before);
        assert!(evaluated_at <= after);
    }

    #[test]
    fn test_condition_analysis_properties_matched_can_diverge_from_matched() {
        use crate::flags::flag_models::FeatureFlag;
        use std::collections::HashMap;

        // Create a flag with two conditions using JSON parsing (same pattern as other tests):
        // Condition 0: properties match but rollout_percentage = 0 (no match)
        // Condition 1: properties match and rollout_percentage = 100 (match)
        let flag: FeatureFlag = serde_json::from_value(json!(
            {
                "id": 1,
                "team_id": 1,
                "name": "test-flag",
                "key": "test-flag",
                "active": true,
                "filters": {
                    "groups": [
                        {
                            "properties": [
                                {
                                    "key": "email",
                                    "value": "test@example.com",
                                    "type": "person"
                                }
                            ],
                            "rollout_percentage": 0
                        },
                        {
                            "properties": [
                                {
                                    "key": "email",
                                    "value": "test@example.com",
                                    "type": "person"
                                }
                            ],
                            "rollout_percentage": 100
                        }
                    ]
                }
            }
        ))
        .unwrap();

        // Create a flag match where condition 1 matched (index 1)
        let flag_match = FeatureFlagMatch {
            matches: true,
            variant: None,
            reason: FeatureFlagMatchReason::ConditionMatch,
            condition_index: Some(1),
            payload: None,
        };

        // Create property values that would match both conditions
        let mut property_values = HashMap::new();
        property_values.insert("email".to_string(), serde_json::json!("test@example.com"));

        // Build condition analysis
        let analysis = FlagDetails::build_condition_analysis(
            &flag,
            &flag_match,
            Some(&property_values),
            None,
            None,
            chrono_tz::Tz::UTC,
        );

        // Verify we have analysis for both conditions
        assert_eq!(analysis.len(), 2);

        // Condition 0: properties matched but overall condition did not match (rollout = 0%)
        assert!(
            analysis[0].properties_matched,
            "Condition 0 should have properties_matched=true"
        );
        assert!(
            !analysis[0].matched,
            "Condition 0 should have matched=false due to 0% rollout"
        );
        assert_eq!(analysis[0].index, 0);
        assert!(
            analysis[0].rollout_excluded,
            "Condition 0 should be rollout_excluded"
        );

        // Condition 1: properties matched and overall condition matched
        assert!(
            analysis[1].properties_matched,
            "Condition 1 should have properties_matched=true"
        );
        assert!(analysis[1].matched, "Condition 1 should have matched=true");
        assert_eq!(analysis[1].index, 1);
        assert!(
            !analysis[1].rollout_excluded,
            "Condition 1 should not be rollout_excluded"
        );
    }

    #[test]
    fn test_condition_analysis_resolves_group_filters_against_group_properties() {
        use crate::flags::flag_models::FeatureFlag;
        use std::collections::HashMap;

        // A group-aggregated flag whose only condition targets a group property.
        let flag: FeatureFlag = serde_json::from_value(json!(
            {
                "id": 1,
                "team_id": 1,
                "name": "org-flag",
                "key": "org-flag",
                "active": true,
                "filters": {
                    "aggregation_group_type_index": 0,
                    "groups": [
                        {
                            "properties": [
                                {
                                    "key": "name",
                                    "value": "Mjolnir - Test Org",
                                    "operator": "exact",
                                    "type": "group",
                                    "group_type_index": 0
                                },
                                {
                                    "key": "$group_key",
                                    "value": "org_123",
                                    "operator": "exact",
                                    "type": "group"
                                    // No explicit group_type_index: a legacy filter that must fall
                                    // back to the flag-level aggregation_group_type_index above.
                                }
                            ],
                            "rollout_percentage": 100
                        }
                    ]
                }
            }
        ))
        .unwrap();

        let flag_match = FeatureFlagMatch {
            matches: true,
            variant: None,
            reason: FeatureFlagMatchReason::ConditionMatch,
            condition_index: Some(0),
            payload: None,
        };

        // The person happens to carry a conflicting `name`; it must not leak into the
        // group-typed condition analysis.
        let mut person_props = HashMap::new();
        person_props.insert("name".to_string(), json!("Hans Grønskag Hammer"));

        // Group properties keyed by group type index, with `$group_key` injected the way
        // request handling does for the `groups` param.
        let mut group_props_for_index = HashMap::new();
        group_props_for_index.insert("name".to_string(), json!("Mjolnir - Test Org"));
        group_props_for_index.insert("$group_key".to_string(), json!("org_123"));
        let group_props: HashMap<GroupTypeIndex, HashMap<String, Value>> =
            HashMap::from([(0, group_props_for_index)]);

        let analysis = FlagDetails::build_condition_analysis(
            &flag,
            &flag_match,
            Some(&person_props),
            Some(&group_props),
            None,
            chrono_tz::Tz::UTC,
        );

        assert_eq!(analysis.len(), 1);
        let props = &analysis[0].properties;
        assert_eq!(props.len(), 2);

        // Group `name` resolves against the group, not the person.
        assert_eq!(props[0].key, "name");
        assert!(props[0].matched, "group name should match");
        assert_eq!(props[0].actual_value, Some(json!("Mjolnir - Test Org")));

        // `$group_key` resolves from the injected group override rather than reporting null.
        assert_eq!(props[1].key, "$group_key");
        assert!(props[1].matched, "$group_key should match");
        assert_eq!(props[1].actual_value, Some(json!("org_123")));
    }

    #[test]
    fn test_condition_analysis_respects_explicit_person_aggregation_over_flag_level_group() {
        use crate::flags::flag_models::FeatureFlag;
        use std::collections::HashMap;

        // Flag-level group aggregation, but this condition explicitly overrides to person
        // aggregation (JSON `null`). A legacy group-typed filter with no `group_type_index`
        // must resolve against the (empty) person-aggregation namespace, not fall back to
        // the flag-level group index. Mirrors `FlagPropertyGroup::effective_aggregation`'s
        // `Some(None)` case, which the real matching path already honors.
        let flag: FeatureFlag = serde_json::from_value(json!(
            {
                "id": 1,
                "team_id": 1,
                "name": "org-flag",
                "key": "org-flag",
                "active": true,
                "filters": {
                    "aggregation_group_type_index": 0,
                    "groups": [
                        {
                            "aggregation_group_type_index": null,
                            "properties": [
                                {
                                    "key": "name",
                                    "value": "Mjolnir - Test Org",
                                    "operator": "exact",
                                    "type": "group"
                                }
                            ],
                            "rollout_percentage": 100
                        }
                    ]
                }
            }
        ))
        .unwrap();

        // The flag did not match, so a filter that incorrectly falls back to the
        // flag-level group index and finds a real match there would flip `matched`
        // to true and leak the group's value as `actual_value` — the exact bug this
        // fix closes.
        let flag_match = FeatureFlagMatch {
            matches: false,
            variant: None,
            reason: FeatureFlagMatchReason::NoConditionMatch,
            condition_index: None,
            payload: None,
        };

        // Group 0's properties do carry a matching `name`, but the condition's explicit
        // person aggregation must prevent the filter from ever consulting them.
        let mut group_props_for_index = HashMap::new();
        group_props_for_index.insert("name".to_string(), json!("Mjolnir - Test Org"));
        let group_props: HashMap<GroupTypeIndex, HashMap<String, Value>> =
            HashMap::from([(0, group_props_for_index)]);

        let analysis = FlagDetails::build_condition_analysis(
            &flag,
            &flag_match,
            None,
            Some(&group_props),
            None,
            chrono_tz::Tz::UTC,
        );

        assert_eq!(analysis.len(), 1);
        let props = &analysis[0].properties;
        assert_eq!(props.len(), 1);
        assert_eq!(props[0].key, "name");
        assert!(
            !props[0].matched,
            "must fall back to the condition's own (unmatched) outcome, not the flag-level group's properties"
        );
        assert_eq!(props[0].actual_value, None);
    }

    #[test]
    fn test_condition_analysis_resolves_flag_dependencies_against_flag_results() {
        use crate::flags::flag_models::FeatureFlag;
        use std::collections::HashMap;

        // A flag with a single condition that depends on flag id 42 evaluating to true.
        let flag: FeatureFlag = serde_json::from_value(json!(
            {
                "id": 1,
                "team_id": 1,
                "name": "dependent-flag",
                "key": "dependent-flag",
                "active": true,
                "filters": {
                    "groups": [
                        {
                            "properties": [
                                {
                                    "key": "42",
                                    "value": true,
                                    "type": "flag",
                                    "operator": "flag_evaluates_to"
                                }
                            ],
                            "rollout_percentage": 100
                        }
                    ]
                }
            }
        ))
        .unwrap();

        // Case 1: the dependency flag matched → the tested flag matched via condition 0.
        let flag_match = FeatureFlagMatch {
            matches: true,
            variant: None,
            reason: FeatureFlagMatchReason::ConditionMatch,
            condition_index: Some(0),
            payload: None,
        };
        let mut flag_results = HashMap::new();
        flag_results.insert(42, FlagValue::Boolean(true));

        let analysis = FlagDetails::build_condition_analysis(
            &flag,
            &flag_match,
            Some(&HashMap::new()),
            None,
            Some(&flag_results),
            chrono_tz::Tz::UTC,
        );

        assert_eq!(analysis.len(), 1);
        assert!(analysis[0].matched, "Condition should be the winner");
        assert!(
            analysis[0].properties_matched,
            "Flag dependency matched, so properties_matched must be true"
        );
        assert!(
            analysis[0].properties[0].matched,
            "Flag dependency property must report matched=true"
        );
        // The dependency flag's evaluated value must not be disclosed.
        assert_eq!(analysis[0].properties[0].actual_value, None);

        // Case 2: the dependency flag did NOT match → the tested flag did not match.
        let flag_match = FeatureFlagMatch {
            matches: false,
            variant: None,
            reason: FeatureFlagMatchReason::NoConditionMatch,
            condition_index: None,
            payload: None,
        };
        let mut flag_results = HashMap::new();
        flag_results.insert(42, FlagValue::Boolean(false));

        let analysis = FlagDetails::build_condition_analysis(
            &flag,
            &flag_match,
            Some(&HashMap::new()),
            None,
            Some(&flag_results),
            chrono_tz::Tz::UTC,
        );

        assert_eq!(analysis.len(), 1);
        assert!(!analysis[0].matched, "Condition should not be the winner");
        assert!(
            !analysis[0].properties_matched,
            "Flag dependency did not match, so properties_matched must be false"
        );
        assert!(
            !analysis[0].properties[0].matched,
            "Flag dependency property must report matched=false"
        );
        // The dependency flag's evaluated value must not be disclosed regardless of match outcome.
        assert_eq!(analysis[0].properties[0].actual_value, None);

        // Case 3: the dependency flag id is absent from flag_results (e.g. not yet evaluated).
        // match_flag_value_to_flag_filter returns false when the id is missing — the analysis
        // should reflect that rather than falling through to match_property() which rejects the
        // FlagEvaluatesTo operator entirely.
        let flag_match = FeatureFlagMatch {
            matches: false,
            variant: None,
            reason: FeatureFlagMatchReason::NoConditionMatch,
            condition_index: None,
            payload: None,
        };

        let analysis = FlagDetails::build_condition_analysis(
            &flag,
            &flag_match,
            Some(&HashMap::new()),
            None,
            None, // empty — dependency flag 42 absent
            chrono_tz::Tz::UTC,
        );

        assert_eq!(analysis.len(), 1);
        assert!(
            !analysis[0].properties[0].matched,
            "Absent dependency flag must report matched=false, not error"
        );
        assert_eq!(analysis[0].properties[0].actual_value, None);
    }

    #[rstest]
    #[case::opted_in(Some("true"), SuperConditionValue, true, true, true, "Enrolled", false)]
    #[case::opted_out(
        Some("false"),
        SuperConditionValue,
        false,
        false,
        false,
        "Opted out",
        false
    )]
    #[case::not_enrolled(None, ConditionMatch, true, false, false, "Not enrolled", true)]
    fn test_condition_analysis_surfaces_early_access_enrollment(
        #[case] enrollment_value: Option<&str>,
        #[case] reason: FeatureFlagMatchReason,
        #[case] flag_matches: bool,
        #[case] expected_enrollment_matched: bool,
        #[case] expected_enrollment_properties_matched: bool,
        #[case] expected_explanation_fragment: &str,
        #[case] expected_release_condition_matched: bool,
    ) {
        use crate::flags::flag_models::FeatureFlag;
        use std::collections::HashMap;

        let flag: FeatureFlag = serde_json::from_value(json!({
            "id": 1, "team_id": 1, "name": "beta-feature", "key": "beta-feature", "active": true,
            "filters": {
                "feature_enrollment": true,
                "groups": [{
                    "properties": [{ "key": "is_scoped", "value": ["false"], "operator": "exact", "type": "person" }],
                    "rollout_percentage": 100
                }]
            }
        }))
        .unwrap();

        // is_scoped="false" makes the release condition match, so opted-in/out exercise enrollment
        // overriding an otherwise-matching release condition.
        let enrollment_key = "$feature_enrollment/beta-feature";
        let mut property_values = HashMap::from([("is_scoped".to_string(), json!("false"))]);
        if let Some(v) = enrollment_value {
            property_values.insert(enrollment_key.to_string(), json!(v));
        }

        let flag_match = FeatureFlagMatch {
            matches: flag_matches,
            variant: None,
            reason,
            condition_index: Some(0),
            payload: None,
        };

        let analysis = FlagDetails::build_condition_analysis(
            &flag,
            &flag_match,
            Some(&property_values),
            None,
            None,
            chrono_tz::Tz::UTC,
        );

        // Enrollment is surfaced as the first entry (omitted entirely before the fix).
        assert_eq!(analysis.len(), 2);
        let enrollment = &analysis[0];
        assert_eq!(enrollment.index, SUPER_CONDITION_INDEX);
        assert_eq!(enrollment.matched, expected_enrollment_matched);
        assert_eq!(
            enrollment.properties_matched,
            expected_enrollment_properties_matched
        );
        assert!(enrollment
            .explanation
            .contains(expected_explanation_fragment));
        assert_eq!(
            enrollment.properties[0].actual_value,
            enrollment_value.map(|v| json!(v))
        );

        // The release condition wins only when the flag matched through it, never hijacked by the
        // super condition's condition_index Some(0). is_scoped="false" is always in
        // property_values, so the release condition's own properties always match, pinning the
        // premise that enrollment overrides an otherwise-matching condition.
        assert_eq!(analysis[1].index, 0);
        assert!(analysis[1].properties_matched);
        assert_eq!(analysis[1].matched, expected_release_condition_matched);
        assert!(analysis.iter().filter(|c| c.matched).count() <= 1);
    }

    /// Shared fixture for the two holdout-surfacing tests below: a flag with a holdout and a
    /// release condition that would otherwise match on its own.
    fn held_flag_with_release_condition() -> (
        crate::flags::flag_models::FeatureFlag,
        HashMap<String, Value>,
    ) {
        use crate::flags::flag_models::FeatureFlag;

        let flag: FeatureFlag = serde_json::from_value(json!({
            "id": 1, "team_id": 1, "name": "held-flag", "key": "held-flag", "active": true,
            "filters": {
                "holdout": { "id": 42, "exclusion_percentage": 10.0 },
                "groups": [{
                    "properties": [{ "key": "is_scoped", "value": ["false"], "operator": "exact", "type": "person" }],
                    "rollout_percentage": 100
                }]
            }
        }))
        .unwrap();

        let property_values = HashMap::from([("is_scoped".to_string(), json!("false"))]);

        (flag, property_values)
    }

    #[test]
    fn test_condition_analysis_surfaces_holdout_winner() {
        // When the matcher resolves through the holdout, the holdout entry must be surfaced as
        // the winner and the release condition must not be attributed the win.
        let (flag, property_values) = held_flag_with_release_condition();

        let flag_match = FeatureFlagMatch {
            matches: true,
            variant: Some("holdout-42".to_string()),
            reason: FeatureFlagMatchReason::HoldoutConditionValue,
            condition_index: None,
            payload: None,
        };

        let analysis = FlagDetails::build_condition_analysis(
            &flag,
            &flag_match,
            Some(&property_values),
            None,
            None,
            chrono_tz::Tz::UTC,
        );

        // Holdout is surfaced as the first entry (omitted entirely before the fix).
        assert_eq!(analysis.len(), 2);
        let holdout = &analysis[0];
        assert_eq!(holdout.index, HOLDOUT_CONDITION_INDEX);
        assert!(holdout.matched);
        assert!(holdout.properties_matched);
        assert!(!holdout.rollout_excluded);
        assert!(holdout.properties.is_empty());
        assert_eq!(holdout.variant, Some("holdout-42".to_string()));
        assert!(holdout.explanation.contains("holdout"));
        assert!(holdout.explanation.contains("10%"));

        // The release condition matches its properties but the holdout, not it, is the winner.
        assert_eq!(analysis[1].index, 0);
        assert!(analysis[1].properties_matched);
        assert!(!analysis[1].matched);
        assert_eq!(analysis.iter().filter(|c| c.matched).count(), 1);
    }

    #[test]
    fn test_condition_analysis_omits_holdout_entry_when_flag_did_not_resolve_via_holdout() {
        // The person was excluded from the holdout and matched a release condition instead.
        // Without the holdout hash threaded down we can't describe the exclusion, so no holdout
        // entry is surfaced (only the winning release condition).
        let (flag, property_values) = held_flag_with_release_condition();

        let flag_match = FeatureFlagMatch {
            matches: true,
            variant: None,
            reason: FeatureFlagMatchReason::ConditionMatch,
            condition_index: Some(0),
            payload: None,
        };

        let analysis = FlagDetails::build_condition_analysis(
            &flag,
            &flag_match,
            Some(&property_values),
            None,
            None,
            chrono_tz::Tz::UTC,
        );

        assert_eq!(analysis.len(), 1);
        assert_eq!(analysis[0].index, 0);
        assert!(analysis[0].matched);
    }

    #[test]
    fn test_condition_analysis_orders_enrollment_before_holdout_when_both_configured() {
        // A flag with both an enrollment super condition and a holdout: when the person isn't
        // enrolled and the matcher resolves via the holdout, both synthetic entries must be
        // surfaced together, in the matcher's enrollment-then-holdout order.
        use crate::flags::flag_models::FeatureFlag;

        let flag: FeatureFlag = serde_json::from_value(json!({
            "id": 1, "team_id": 1, "name": "held-flag", "key": "held-flag", "active": true,
            "filters": {
                "feature_enrollment": true,
                "holdout": { "id": 42, "exclusion_percentage": 10.0 },
                "groups": [{
                    "properties": [{ "key": "is_scoped", "value": ["false"], "operator": "exact", "type": "person" }],
                    "rollout_percentage": 100
                }]
            }
        }))
        .unwrap();

        // No enrollment property set, so the person isn't enrolled and the matcher falls
        // through to the holdout.
        let property_values = HashMap::from([("is_scoped".to_string(), json!("false"))]);

        let flag_match = FeatureFlagMatch {
            matches: true,
            variant: Some("holdout-42".to_string()),
            reason: FeatureFlagMatchReason::HoldoutConditionValue,
            condition_index: None,
            payload: None,
        };

        let analysis = FlagDetails::build_condition_analysis(
            &flag,
            &flag_match,
            Some(&property_values),
            None,
            None,
            chrono_tz::Tz::UTC,
        );

        assert_eq!(analysis.len(), 3);
        assert_eq!(analysis[0].index, SUPER_CONDITION_INDEX);
        assert!(!analysis[0].matched);
        assert_eq!(analysis[1].index, HOLDOUT_CONDITION_INDEX);
        assert!(analysis[1].matched);
        assert_eq!(analysis[2].index, 0);
        assert!(!analysis[2].matched);
        assert_eq!(analysis.iter().filter(|c| c.matched).count(), 1);
    }

    #[test]
    fn test_condition_analysis_attributes_winner_to_non_zero_release_condition() {
        use crate::flags::flag_models::FeatureFlag;
        use std::collections::HashMap;

        // Two release groups, plus enrollment enabled, so this also exercises the interaction
        // between the prepended enrollment entry and attribution to a non-zero condition_index:
        // the enrollment entry must stay first while group 1 still wins.
        let flag: FeatureFlag = serde_json::from_value(json!({
            "id": 1, "team_id": 1, "name": "beta-feature", "key": "beta-feature", "active": true,
            "filters": {
                "feature_enrollment": true,
                "groups": [
                    {
                        "properties": [{ "key": "is_scoped", "value": ["true"], "operator": "exact", "type": "person" }],
                        "rollout_percentage": 100
                    },
                    {
                        "properties": [{ "key": "is_scoped", "value": ["false"], "operator": "exact", "type": "person" }],
                        "rollout_percentage": 100
                    }
                ]
            }
        }))
        .unwrap();

        // is_scoped="false" fails group 0's ["true"] requirement and satisfies group 1's, so the
        // matcher resolves through group 1, not group 0.
        let property_values = HashMap::from([("is_scoped".to_string(), json!("false"))]);

        let flag_match = FeatureFlagMatch {
            matches: true,
            variant: None,
            reason: ConditionMatch,
            condition_index: Some(1),
            payload: None,
        };

        let analysis = FlagDetails::build_condition_analysis(
            &flag,
            &flag_match,
            Some(&property_values),
            None,
            None,
            chrono_tz::Tz::UTC,
        );

        // Enrollment entry, then both release conditions in order, with only group 1 as the winner.
        assert_eq!(analysis.len(), 3);
        assert_eq!(analysis[0].index, SUPER_CONDITION_INDEX);
        assert!(!analysis[0].matched);

        assert_eq!(analysis[1].index, 0);
        assert!(!analysis[1].properties_matched);
        assert!(!analysis[1].matched);

        assert_eq!(analysis[2].index, 1);
        assert!(analysis[2].properties_matched);
        assert!(analysis[2].matched);

        assert!(analysis.iter().filter(|c| c.matched).count() <= 1);
    }
}
