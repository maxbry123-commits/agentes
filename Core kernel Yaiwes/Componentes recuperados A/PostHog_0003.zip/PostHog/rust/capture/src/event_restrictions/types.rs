use std::collections::HashSet;

use metrics::counter;

use crate::config::CaptureMode;

/// Logical ingestion pipeline a restriction is scoped to. Distinct from
/// [`CaptureMode`] — a single capture deployment (e.g. `CaptureMode::Events`)
/// produces events to multiple pipelines (`Analytics` for normal events,
/// `ErrorTracking` for `$exception` events). Each pipeline owns its own
/// restriction config in Redis and its own [`EventRestrictionService`].
///
/// String values must match Django's `EventIngestionRestrictionConfig.pipelines`
/// — the Redis JSON entries are filtered against [`Pipeline::as_str`].
#[derive(Debug, PartialEq, Eq, Clone, Copy, Hash)]
pub enum Pipeline {
    Analytics,
    SessionRecordings,
    Ai,
    ErrorTracking,
}

impl Pipeline {
    pub fn as_str(&self) -> &'static str {
        match self {
            Self::Analytics => "analytics",
            Self::SessionRecordings => "session_recordings",
            Self::Ai => "ai",
            Self::ErrorTracking => "errortracking",
        }
    }

    pub fn parse(s: &str) -> Option<Self> {
        match s {
            "analytics" => Some(Self::Analytics),
            "session_recordings" => Some(Self::SessionRecordings),
            "ai" => Some(Self::Ai),
            "errortracking" => Some(Self::ErrorTracking),
            _ => None,
        }
    }
}

impl Pipeline {
    /// Pipelines a given capture deployment produces events to. The events
    /// deployment writes to `analytics` (normal events), `errortracking`
    /// (`$exception` events split off in `process_single_event`), and `ai`
    /// (names on the `AI_EVENT_NAMES` allowlist), so its restriction service
    /// must serve restrictions for all three pipelines. `Import` is an events
    /// deployment restricted to backfills, so it serves the same three.
    ///
    /// `Ai` serves only `ai`. That deployment registers no analytics route,
    /// and `process_events` rejects a batch carrying anything off the AI lane,
    /// so no event there resolves to another pipeline. Both halves have to
    /// hold: serving fewer pipelines than a deployment can produce to leaves
    /// those lookups matching an unloaded slice, which returns an empty
    /// `RestrictionSet` — silently unrestricted.
    pub fn for_capture_mode(mode: CaptureMode) -> Vec<Pipeline> {
        match mode {
            CaptureMode::Events | CaptureMode::Import => {
                vec![Self::Analytics, Self::ErrorTracking, Self::Ai]
            }
            CaptureMode::Recordings => vec![Self::SessionRecordings],
            // capture-ai registers only the AI routes, and `process_events`
            // rejects a batch carrying anything off the AI lane, so no event
            // there ever resolves to another pipeline. Loading the analytics
            // and error-tracking slices would only cost memory.
            CaptureMode::Ai => vec![Self::Ai],
        }
    }
}

/// Restriction types that can be applied to events in capture.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum RestrictionType {
    DropEvent,
    ForceOverflow,
    RedirectToDlq,
    SkipPersonProcessing,
    RedirectToTopic,
}

impl RestrictionType {
    pub fn from_redis_key(value: &str) -> Option<Self> {
        match value {
            "drop_event_from_ingestion" => Some(Self::DropEvent),
            "force_overflow_from_ingestion" => Some(Self::ForceOverflow),
            "redirect_to_dlq" => Some(Self::RedirectToDlq),
            "skip_person_processing" => Some(Self::SkipPersonProcessing),
            "redirect_to_topic" => Some(Self::RedirectToTopic),
            _ => None,
        }
    }

    pub fn as_str(&self) -> &'static str {
        match self {
            Self::DropEvent => "drop_event",
            Self::ForceOverflow => "force_overflow",
            Self::RedirectToDlq => "redirect_to_dlq",
            Self::SkipPersonProcessing => "skip_person_processing",
            Self::RedirectToTopic => "redirect_to_topic",
        }
    }

    pub fn redis_key(&self) -> &'static str {
        match self {
            Self::DropEvent => "drop_event_from_ingestion",
            Self::ForceOverflow => "force_overflow_from_ingestion",
            Self::RedirectToDlq => "redirect_to_dlq",
            Self::SkipPersonProcessing => "skip_person_processing",
            Self::RedirectToTopic => "redirect_to_topic",
        }
    }

    pub fn all() -> [Self; 5] {
        [
            Self::DropEvent,
            Self::ForceOverflow,
            Self::SkipPersonProcessing,
            Self::RedirectToDlq,
            Self::RedirectToTopic,
        ]
    }

    /// Bit position for this restriction type (0-4).
    const fn bit_pos(self) -> u8 {
        match self {
            Self::DropEvent => 0,
            Self::ForceOverflow => 1,
            Self::RedirectToDlq => 2,
            Self::SkipPersonProcessing => 3,
            Self::RedirectToTopic => 4,
        }
    }
}

/// A compact set of restriction types using a bitfield, with optional topic for redirect.
#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct RestrictionSet {
    bits: u8,
    redirect_topic: Option<String>,
}

impl RestrictionSet {
    /// Create an empty set.
    pub fn new() -> Self {
        Self {
            bits: 0,
            redirect_topic: None,
        }
    }

    /// Insert a restriction type into the set.
    pub fn insert(&mut self, t: RestrictionType) {
        self.bits |= 1 << t.bit_pos();
    }

    /// Insert a RedirectToTopic restriction with the target topic.
    pub fn insert_redirect_to_topic(&mut self, topic: String) {
        self.bits |= 1 << RestrictionType::RedirectToTopic.bit_pos();
        self.redirect_topic = Some(topic);
    }

    /// Get the redirect topic, if set.
    pub fn redirect_topic(&self) -> Option<&str> {
        self.redirect_topic.as_deref()
    }

    /// Check if the set contains a restriction type.
    pub fn contains(&self, t: RestrictionType) -> bool {
        (self.bits & (1 << t.bit_pos())) != 0
    }

    /// Check if the set is empty.
    pub fn is_empty(&self) -> bool {
        self.bits == 0
    }

    /// Count the number of restrictions in the set.
    pub fn len(&self) -> usize {
        self.bits.count_ones() as usize
    }
}

/// Result of applying restrictions to an event.
/// Immutable — constructed from a RestrictionSet with metrics emission.
#[derive(Debug, Default)]
pub struct AppliedRestrictions {
    should_drop: bool,
    force_overflow: bool,
    skip_person_processing: bool,
    redirect_to_dlq: bool,
    redirect_to_topic: Option<String>,
}

impl AppliedRestrictions {
    /// Build from a RestrictionSet and emit per-type metrics.
    pub(crate) fn from_restrictions(restrictions: RestrictionSet, pipeline: Pipeline) -> Self {
        let mut result = Self::default();
        let pipeline_str = pipeline.as_str();

        for restriction_type in RestrictionType::all() {
            if restrictions.contains(restriction_type) {
                counter!(
                    "capture_event_restrictions_applied",
                    "restriction_type" => restriction_type.as_str(),
                    "pipeline" => pipeline_str
                )
                .increment(1);

                match restriction_type {
                    RestrictionType::DropEvent => result.should_drop = true,
                    RestrictionType::ForceOverflow => result.force_overflow = true,
                    RestrictionType::SkipPersonProcessing => result.skip_person_processing = true,
                    RestrictionType::RedirectToDlq => result.redirect_to_dlq = true,
                    RestrictionType::RedirectToTopic => {
                        result.redirect_to_topic =
                            restrictions.redirect_topic().map(|s| s.to_string());
                    }
                }
            }
        }

        result
    }

    pub fn is_empty(&self) -> bool {
        !self.should_drop
            && !self.force_overflow
            && !self.skip_person_processing
            && !self.redirect_to_dlq
            && self.redirect_to_topic.is_none()
    }

    pub fn should_drop(&self) -> bool {
        self.should_drop
    }

    pub fn force_overflow(&self) -> bool {
        self.force_overflow
    }

    pub fn skip_person_processing(&self) -> bool {
        self.skip_person_processing
    }

    pub fn redirect_to_dlq(&self) -> bool {
        self.redirect_to_dlq
    }

    pub fn redirect_to_topic(&self) -> Option<&str> {
        self.redirect_to_topic.as_deref()
    }

    /// OR two sets of restrictions together. Used for all-or-nothing batch processing
    /// where any span triggering a flag applies it to the whole batch.
    pub fn merge(self, other: AppliedRestrictions) -> Self {
        Self {
            should_drop: self.should_drop || other.should_drop,
            force_overflow: self.force_overflow || other.force_overflow,
            skip_person_processing: self.skip_person_processing || other.skip_person_processing,
            redirect_to_dlq: self.redirect_to_dlq || other.redirect_to_dlq,
            redirect_to_topic: self.redirect_to_topic.or(other.redirect_to_topic),
        }
    }
}

/// Filters for a restriction. AND logic between types, OR logic within each type.
/// Empty set means "no filter on this field" (matches all).
#[derive(Debug, Clone, Default)]
pub struct RestrictionFilters {
    pub distinct_ids: HashSet<String>,
    pub session_ids: HashSet<String>,
    pub event_names: HashSet<String>,
    pub event_uuids: HashSet<String>,
}

impl RestrictionFilters {
    /// Check if an event matches these filters.
    /// AND logic between filter types, OR logic within each type.
    /// Empty filter = matches all for that field.
    pub fn matches(&self, event: &EventContext) -> bool {
        self.matches_field(&self.distinct_ids, event.distinct_id)
            && self.matches_field(&self.session_ids, event.session_id)
            && self.matches_field(&self.event_names, event.event_name)
            && self.matches_field(&self.event_uuids, event.event_uuid)
    }

    fn matches_field(&self, filter: &HashSet<String>, value: Option<&str>) -> bool {
        if filter.is_empty() {
            return true; // no filter = matches all
        }
        match value {
            Some(v) => filter.contains(v),
            None => false, // filter set but no value = no match
        }
    }
}

/// Event data for matching against restrictions.
/// Uses references to avoid cloning strings for every event.
#[derive(Debug, Clone, Copy, Default)]
pub struct EventContext<'a> {
    pub distinct_id: Option<&'a str>,
    pub session_id: Option<&'a str>,
    pub event_name: Option<&'a str>,
    pub event_uuid: Option<&'a str>,
    /// Pre-computed timestamp to avoid syscalls per event. Use `chrono::Utc::now().timestamp()`.
    pub now_ts: i64,
}

/// What events a restriction applies to.
#[derive(Debug, Clone)]
pub enum RestrictionScope {
    /// Applies to all events for this token
    AllEvents,
    /// Applies only to events matching the filters
    Filtered(RestrictionFilters),
}

/// A single restriction rule.
#[derive(Debug, Clone)]
pub struct Restriction {
    pub restriction_type: RestrictionType,
    pub scope: RestrictionScope,
    pub args: Option<serde_json::Value>,
}

impl Restriction {
    pub fn matches(&self, event: &EventContext) -> bool {
        match &self.scope {
            RestrictionScope::AllEvents => true,
            RestrictionScope::Filtered(filters) => filters.matches(event),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_restriction_type_from_redis_key() {
        assert_eq!(
            RestrictionType::from_redis_key("drop_event_from_ingestion"),
            Some(RestrictionType::DropEvent)
        );
        assert_eq!(
            RestrictionType::from_redis_key("force_overflow_from_ingestion"),
            Some(RestrictionType::ForceOverflow)
        );
        assert_eq!(
            RestrictionType::from_redis_key("redirect_to_dlq"),
            Some(RestrictionType::RedirectToDlq)
        );
        assert_eq!(
            RestrictionType::from_redis_key("skip_person_processing"),
            Some(RestrictionType::SkipPersonProcessing)
        );
        assert_eq!(
            RestrictionType::from_redis_key("redirect_to_topic"),
            Some(RestrictionType::RedirectToTopic)
        );
        assert_eq!(RestrictionType::from_redis_key("unknown_type"), None);
    }

    #[test]
    fn test_pipeline_parse() {
        assert_eq!(Pipeline::parse("analytics"), Some(Pipeline::Analytics));
        assert_eq!(
            Pipeline::parse("session_recordings"),
            Some(Pipeline::SessionRecordings)
        );
        assert_eq!(Pipeline::parse("ai"), Some(Pipeline::Ai));
        assert_eq!(
            Pipeline::parse("errortracking"),
            Some(Pipeline::ErrorTracking)
        );
        assert_eq!(Pipeline::parse("unknown"), None);
    }

    #[test]
    fn test_pipeline_as_str_roundtrip() {
        for pipeline in [
            Pipeline::Analytics,
            Pipeline::SessionRecordings,
            Pipeline::Ai,
            Pipeline::ErrorTracking,
        ] {
            assert_eq!(Pipeline::parse(pipeline.as_str()), Some(pipeline));
        }
    }

    #[test]
    fn test_pipeline_for_capture_mode() {
        assert_eq!(
            Pipeline::for_capture_mode(CaptureMode::Events),
            vec![Pipeline::Analytics, Pipeline::ErrorTracking, Pipeline::Ai]
        );
        // Import is an events deployment restricted to backfills, so it must
        // serve the identical pipeline set -- a backfill can carry $exception
        // and AI events too.
        assert_eq!(
            Pipeline::for_capture_mode(CaptureMode::Import),
            Pipeline::for_capture_mode(CaptureMode::Events)
        );
        assert_eq!(
            Pipeline::for_capture_mode(CaptureMode::Recordings),
            vec![Pipeline::SessionRecordings]
        );
        // Ai serves only the AI lane: its routes are AI-only and its batch path
        // rejects anything off the allowlist, so every event it processes
        // resolves to Pipeline::Ai. Widening this would load slices nothing
        // looks up; narrowing it below is only safe while both of those hold.
        assert_eq!(
            Pipeline::for_capture_mode(CaptureMode::Ai),
            vec![Pipeline::Ai]
        );
    }

    #[test]
    fn test_restriction_scope_all_events() {
        let restriction = Restriction {
            restriction_type: RestrictionType::DropEvent,
            scope: RestrictionScope::AllEvents,
            args: None,
        };
        let event = EventContext::default();
        assert!(restriction.matches(&event));
    }

    #[test]
    fn test_restriction_filters_empty_matches_all() {
        let filters = RestrictionFilters::default();
        let event = EventContext {
            distinct_id: Some("user1"),
            event_name: Some("$pageview"),
            ..Default::default()
        };
        assert!(filters.matches(&event));
    }

    #[test]
    fn test_restriction_filters_distinct_id_match() {
        let mut filters = RestrictionFilters::default();
        filters.distinct_ids.insert("user1".to_string());
        filters.distinct_ids.insert("user2".to_string());

        let event_match = EventContext {
            distinct_id: Some("user1"),
            ..Default::default()
        };
        assert!(filters.matches(&event_match));

        let event_no_match = EventContext {
            distinct_id: Some("user3"),
            ..Default::default()
        };
        assert!(!filters.matches(&event_no_match));
    }

    #[test]
    fn test_restriction_filters_and_logic() {
        let mut filters = RestrictionFilters::default();
        filters.distinct_ids.insert("user1".to_string());
        filters.event_names.insert("$pageview".to_string());

        // both match
        let event_both = EventContext {
            distinct_id: Some("user1"),
            event_name: Some("$pageview"),
            ..Default::default()
        };
        assert!(filters.matches(&event_both));

        // only distinct_id matches
        let event_wrong_event = EventContext {
            distinct_id: Some("user1"),
            event_name: Some("$identify"),
            ..Default::default()
        };
        assert!(!filters.matches(&event_wrong_event));

        // only event_name matches
        let event_wrong_user = EventContext {
            distinct_id: Some("user2"),
            event_name: Some("$pageview"),
            ..Default::default()
        };
        assert!(!filters.matches(&event_wrong_user));
    }

    #[test]
    fn test_restriction_set_new_is_empty() {
        let set = RestrictionSet::new();
        assert!(set.is_empty());
        assert_eq!(set.len(), 0);
    }

    #[test]
    fn test_restriction_set_insert_and_contains() {
        let mut set = RestrictionSet::new();

        set.insert(RestrictionType::DropEvent);
        assert!(set.contains(RestrictionType::DropEvent));
        assert!(!set.contains(RestrictionType::ForceOverflow));
        assert!(!set.contains(RestrictionType::RedirectToDlq));
        assert!(!set.contains(RestrictionType::SkipPersonProcessing));
        assert_eq!(set.len(), 1);
        assert!(!set.is_empty());
    }

    #[test]
    fn test_restriction_set_multiple_inserts() {
        let mut set = RestrictionSet::new();

        set.insert(RestrictionType::DropEvent);
        set.insert(RestrictionType::ForceOverflow);
        set.insert(RestrictionType::RedirectToDlq);

        assert!(set.contains(RestrictionType::DropEvent));
        assert!(set.contains(RestrictionType::ForceOverflow));
        assert!(set.contains(RestrictionType::RedirectToDlq));
        assert!(!set.contains(RestrictionType::SkipPersonProcessing));
        assert_eq!(set.len(), 3);
    }

    #[test]
    fn test_restriction_set_all_types() {
        let mut set = RestrictionSet::new();

        for t in RestrictionType::all() {
            set.insert(t);
        }

        assert_eq!(set.len(), 5);
        for t in RestrictionType::all() {
            assert!(set.contains(t));
        }
    }

    #[test]
    fn test_restriction_set_insert_idempotent() {
        let mut set = RestrictionSet::new();

        set.insert(RestrictionType::DropEvent);
        set.insert(RestrictionType::DropEvent);
        set.insert(RestrictionType::DropEvent);

        assert_eq!(set.len(), 1);
        assert!(set.contains(RestrictionType::DropEvent));
    }

    #[test]
    fn test_restriction_set_default() {
        let set = RestrictionSet::default();
        assert!(set.is_empty());
        assert_eq!(set.len(), 0);
    }

    #[test]
    fn test_restriction_set_clone() {
        let mut set1 = RestrictionSet::new();
        set1.insert(RestrictionType::DropEvent);

        let set2 = set1.clone();
        assert!(set2.contains(RestrictionType::DropEvent));

        // set1 is still valid after clone
        assert!(set1.contains(RestrictionType::DropEvent));
    }

    #[test]
    fn test_restriction_set_insert_redirect_to_topic() {
        let mut set = RestrictionSet::new();
        set.insert_redirect_to_topic("custom_topic".to_string());

        assert!(set.contains(RestrictionType::RedirectToTopic));
        assert_eq!(set.redirect_topic(), Some("custom_topic"));
        assert_eq!(set.len(), 1);
    }

    #[test]
    fn test_applied_restrictions_merge_defaults() {
        let a = AppliedRestrictions::default();
        let b = AppliedRestrictions::default();
        let merged = a.merge(b);
        assert!(merged.is_empty());
        assert!(!merged.should_drop());
        assert!(!merged.force_overflow());
        assert!(!merged.skip_person_processing());
        assert!(!merged.redirect_to_dlq());
        assert!(merged.redirect_to_topic().is_none());
    }

    #[test]
    fn test_applied_restrictions_merge_should_drop_propagates() {
        for (left, right) in [(true, false), (false, true), (true, true)] {
            let a = AppliedRestrictions {
                should_drop: left,
                ..Default::default()
            };
            let b = AppliedRestrictions {
                should_drop: right,
                ..Default::default()
            };
            assert!(a.merge(b).should_drop());
        }
    }

    #[test]
    fn test_applied_restrictions_merge_boolean_flags_or() {
        let a = AppliedRestrictions {
            force_overflow: true,
            ..Default::default()
        };
        let b = AppliedRestrictions {
            skip_person_processing: true,
            redirect_to_dlq: true,
            ..Default::default()
        };
        let merged = a.merge(b);
        assert!(merged.force_overflow());
        assert!(merged.skip_person_processing());
        assert!(merged.redirect_to_dlq());
    }

    #[test]
    fn test_applied_restrictions_merge_redirect_to_topic_first_wins() {
        let a = AppliedRestrictions {
            redirect_to_topic: Some("topic_a".to_string()),
            ..Default::default()
        };
        let b = AppliedRestrictions {
            redirect_to_topic: Some("topic_b".to_string()),
            ..Default::default()
        };
        assert_eq!(a.merge(b).redirect_to_topic(), Some("topic_a"));
    }

    #[test]
    fn test_applied_restrictions_merge_redirect_to_topic_from_right() {
        let a = AppliedRestrictions::default();
        let b = AppliedRestrictions {
            redirect_to_topic: Some("topic_b".to_string()),
            ..Default::default()
        };
        assert_eq!(a.merge(b).redirect_to_topic(), Some("topic_b"));
    }

    #[test]
    fn test_applied_restrictions_merge_accumulates_all_flags() {
        let merged = AppliedRestrictions::default()
            .merge(AppliedRestrictions {
                should_drop: true,
                ..Default::default()
            })
            .merge(AppliedRestrictions {
                force_overflow: true,
                ..Default::default()
            })
            .merge(AppliedRestrictions {
                skip_person_processing: true,
                ..Default::default()
            })
            .merge(AppliedRestrictions {
                redirect_to_dlq: true,
                ..Default::default()
            })
            .merge(AppliedRestrictions {
                redirect_to_topic: Some("final_topic".to_string()),
                ..Default::default()
            });

        assert!(merged.should_drop());
        assert!(merged.force_overflow());
        assert!(merged.skip_person_processing());
        assert!(merged.redirect_to_dlq());
        assert_eq!(merged.redirect_to_topic(), Some("final_topic"));
    }

    #[test]
    fn test_restriction_set_redirect_topic_last_wins() {
        let mut set = RestrictionSet::new();
        set.insert_redirect_to_topic("first_topic".to_string());
        set.insert_redirect_to_topic("second_topic".to_string());

        assert!(set.contains(RestrictionType::RedirectToTopic));
        assert_eq!(set.redirect_topic(), Some("second_topic"));
        assert_eq!(set.len(), 1);
    }
}
