use axum::http::HeaderMap;
use bytes::Bytes;
use opentelemetry_proto::tonic::collector::trace::v1::ExportTraceServiceRequest;
use prost::Message;
use serde_json::Value;

use crate::api::CaptureError;
use crate::payload::decompression::decompress_gzip_to_bytes;

/// Patch OTEL JSON AnyValue objects for proper deserialization into protobuf-derived Rust types.
///
/// Handles two cases:
/// 1. Empty `{}` objects under `"value"` keys become `null` (opentelemetry-rust#1253).
/// 2. Null-valued scalar fields (e.g. `{"doubleValue": null}`) are removed. In protobuf-JSON
///    encoding a missing key is equivalent to an unset scalar, but serde rejects null for
///    non-optional f64/i64/bool/String fields.
fn patch_otel_json(v: &mut Value) {
    match v {
        Value::Object(map) => {
            if let Some(inner) = map.get_mut("value") {
                if let Some(obj) = inner.as_object_mut() {
                    for field in &[
                        "doubleValue",
                        "intValue",
                        "stringValue",
                        "boolValue",
                        "bytesValue",
                    ] {
                        if matches!(obj.get(*field), Some(Value::Null)) {
                            obj.remove(*field);
                        }
                    }
                    if obj.is_empty() {
                        *inner = Value::Null;
                    }
                }
            }
            for (_, val) in map.iter_mut() {
                patch_otel_json(val);
            }
        }
        Value::Array(arr) => {
            for val in arr.iter_mut() {
                patch_otel_json(val);
            }
        }
        _ => {}
    }
}

pub fn parse_request(
    body: &Bytes,
    headers: &HeaderMap,
    body_limit: usize,
) -> Result<ExportTraceServiceRequest, CaptureError> {
    let content_encoding = headers
        .get("content-encoding")
        .and_then(|v| v.to_str().ok())
        .unwrap_or("");

    let body = if content_encoding.eq_ignore_ascii_case("gzip") {
        Bytes::from(decompress_gzip_to_bytes(body, body_limit)?)
    } else if !content_encoding.is_empty() {
        return Err(CaptureError::RequestDecodingError(format!(
            "Unsupported content-encoding: {content_encoding}"
        )));
    } else {
        body.clone()
    };

    let content_type = headers
        .get("content-type")
        .and_then(|v| v.to_str().ok())
        .unwrap_or("");

    let is_protobuf = content_type.starts_with("application/x-protobuf");
    let is_json = content_type.starts_with("application/json");

    if is_protobuf {
        ExportTraceServiceRequest::decode(&body[..])
            .map_err(|e| CaptureError::RequestParsingError(format!("Invalid protobuf: {e}")))
    } else if is_json {
        let mut json_value: Value = serde_json::from_slice(&body)
            .map_err(|e| CaptureError::RequestParsingError(format!("Invalid JSON: {e}")))?;

        patch_otel_json(&mut json_value);

        serde_json::from_value(json_value).map_err(|e| {
            CaptureError::RequestParsingError(format!("Invalid OTLP trace format: {e}"))
        })
    } else {
        Err(CaptureError::RequestDecodingError(
            "Content-Type must be application/x-protobuf or application/json".to_string(),
        ))
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use axum::http::HeaderMap;
    use flate2::write::GzEncoder;
    use flate2::Compression;
    use opentelemetry_proto::tonic::trace::v1::{ResourceSpans, ScopeSpans, Span};
    use std::io::Write;

    fn make_protobuf_request() -> ExportTraceServiceRequest {
        ExportTraceServiceRequest {
            resource_spans: vec![ResourceSpans {
                resource: None,
                scope_spans: vec![ScopeSpans {
                    scope: None,
                    spans: vec![Span {
                        trace_id: vec![1; 16],
                        span_id: vec![2; 8],
                        ..Default::default()
                    }],
                    schema_url: String::new(),
                }],
                schema_url: String::new(),
            }],
        }
    }

    #[test]
    fn test_parse_protobuf() {
        let request = make_protobuf_request();
        let body = Bytes::from(request.encode_to_vec());
        let mut headers = HeaderMap::new();
        headers.insert("content-type", "application/x-protobuf".parse().unwrap());

        let parsed = parse_request(&body, &headers, 4 * 1024 * 1024).unwrap();
        assert_eq!(parsed.resource_spans.len(), 1);
        assert_eq!(
            parsed.resource_spans[0].scope_spans[0].spans[0].trace_id,
            vec![1; 16]
        );
    }

    #[test]
    fn test_parse_json() {
        let json = r#"{"resourceSpans":[{"scopeSpans":[{"spans":[{"traceId":"","spanId":""}]}]}]}"#;
        let body = Bytes::from(json);
        let mut headers = HeaderMap::new();
        headers.insert("content-type", "application/json".parse().unwrap());

        let parsed = parse_request(&body, &headers, 4 * 1024 * 1024).unwrap();
        assert_eq!(parsed.resource_spans.len(), 1);
    }

    #[test]
    fn test_parse_gzip_protobuf() {
        let request = make_protobuf_request();
        let encoded = request.encode_to_vec();

        let mut encoder = GzEncoder::new(Vec::new(), Compression::default());
        encoder.write_all(&encoded).unwrap();
        let compressed = encoder.finish().unwrap();

        let body = Bytes::from(compressed);
        let mut headers = HeaderMap::new();
        headers.insert("content-type", "application/x-protobuf".parse().unwrap());
        headers.insert("content-encoding", "gzip".parse().unwrap());

        let parsed = parse_request(&body, &headers, 4 * 1024 * 1024).unwrap();
        assert_eq!(parsed.resource_spans.len(), 1);
    }

    #[test]
    fn test_parse_malformed_protobuf() {
        let body = Bytes::from(vec![0xFF, 0xFF, 0xFF]);
        let mut headers = HeaderMap::new();
        headers.insert("content-type", "application/x-protobuf".parse().unwrap());

        assert!(parse_request(&body, &headers, 4 * 1024 * 1024).is_err());
    }

    #[test]
    fn test_parse_malformed_json() {
        let body = Bytes::from("not json");
        let mut headers = HeaderMap::new();
        headers.insert("content-type", "application/json".parse().unwrap());

        assert!(parse_request(&body, &headers, 4 * 1024 * 1024).is_err());
    }

    #[test]
    fn test_parse_unsupported_content_type() {
        let body = Bytes::from("data");
        let mut headers = HeaderMap::new();
        headers.insert("content-type", "text/plain".parse().unwrap());

        assert!(parse_request(&body, &headers, 4 * 1024 * 1024).is_err());
    }

    #[test]
    fn test_unsupported_content_encoding() {
        let body = Bytes::from("data");
        let mut headers = HeaderMap::new();
        headers.insert("content-type", "application/x-protobuf".parse().unwrap());
        headers.insert("content-encoding", "deflate".parse().unwrap());

        assert!(parse_request(&body, &headers, 4 * 1024 * 1024).is_err());
    }

    #[test]
    fn test_patch_otel_json_empty_value() {
        let mut v = serde_json::json!({"value": {}});
        patch_otel_json(&mut v);
        assert_eq!(v["value"], Value::Null);
    }

    #[test]
    fn test_patch_otel_json_nested() {
        let mut v = serde_json::json!({
            "attributes": [
                {"key": "test", "value": {}},
                {"key": "other", "value": {"stringValue": "hello"}}
            ]
        });
        patch_otel_json(&mut v);
        assert_eq!(v["attributes"][0]["value"], Value::Null);
        assert_eq!(v["attributes"][1]["value"]["stringValue"], "hello");
    }

    #[test]
    fn test_patch_otel_json_deeply_nested() {
        let mut v = serde_json::json!({
            "resourceSpans": [{
                "scopeSpans": [{
                    "spans": [{
                        "attributes": [
                            {"key": "empty", "value": {}},
                            {"key": "string", "value": {"stringValue": "test"}}
                        ]
                    }]
                }]
            }]
        });
        patch_otel_json(&mut v);
        assert_eq!(
            v["resourceSpans"][0]["scopeSpans"][0]["spans"][0]["attributes"][0]["value"],
            Value::Null
        );
    }

    #[test]
    fn test_patch_otel_json_null_scalar_attrs() {
        for field in &[
            "doubleValue",
            "intValue",
            "stringValue",
            "boolValue",
            "bytesValue",
        ] {
            let mut v = serde_json::json!({"value": {}});
            v["value"]
                .as_object_mut()
                .unwrap()
                .insert(field.to_string(), Value::Null);
            patch_otel_json(&mut v);
            assert_eq!(
                v["value"],
                Value::Null,
                "field `{field}` with null should be stripped"
            );
        }

        // Non-null scalar must be preserved.
        let mut v = serde_json::json!({"value": {"stringValue": "gpt-4"}});
        patch_otel_json(&mut v);
        assert_eq!(v["value"]["stringValue"], "gpt-4");
    }

    #[test]
    fn test_parse_json_with_null_double_attr() {
        let json = r#"{"resourceSpans":[{"scopeSpans":[{"spans":[{
            "traceId":"","spanId":"",
            "attributes":[{"key":"cost","value":{"doubleValue":null}}]
        }]}]}]}"#;
        let body = Bytes::from(json);
        let mut headers = HeaderMap::new();
        headers.insert("content-type", "application/json".parse().unwrap());

        let parsed = parse_request(&body, &headers, 4 * 1024 * 1024).unwrap();
        assert_eq!(parsed.resource_spans.len(), 1);
    }
}
