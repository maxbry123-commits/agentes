use axum::body::Body;
use axum::extract::{MatchedPath, Query, State};
use axum::http::{HeaderMap, Method};
use axum::{debug_handler, Extension, Json};
use axum_client_ip::InsecureClientIp;
use tracing::{instrument, Span};

use crate::{
    api::{CaptureError, CaptureResponse, CaptureResponseCode},
    events::{analytics::process_events, recordings::process_replay_events},
    payload::{handle_event_payload, handle_recording_payload, EventQuery},
    prometheus::{report_dropped_events, report_internal_error_metrics},
    router,
};

#[instrument(skip(state, body, meta), fields(params_compression))]
#[debug_handler]
#[allow(clippy::too_many_arguments)]
pub async fn event(
    state: State<router::State>,
    ip: InsecureClientIp,
    meta: Query<EventQuery>,
    headers: HeaderMap,
    method: Method,
    path: MatchedPath,
    wire_limit: Option<Extension<router::WireBodyLimit>>,
    body: Body,
) -> Result<CaptureResponse, CaptureError> {
    let mut params: EventQuery = meta.0;

    // TODO(eli): temporary peek at compression
    if params.compression.is_some() {
        Span::current().record(
            "params_compression",
            format!("{}", params.compression.unwrap()),
        );
    }

    match handle_event_payload(
        &state,
        &ip,
        &mut params,
        &headers,
        &method,
        &path,
        wire_limit.map(|Extension(l)| l),
        body,
    )
    .await
    {
        Err(CaptureError::BillingLimit) => {
            // Short term: return OK here to avoid clients retrying over and over
            // Long term: v1 endpoints will return richer errors, sync w/SDK behavior
            Ok(CaptureResponse {
                status: CaptureResponseCode::Ok,
                quota_limited: None,
            })
        }

        Err(CaptureError::EmptyPayloadFiltered) => {
            // as per legacy behavior, for now we'll silently accept these submissions
            // when invalid event type filtering has resulted in an empty event payload
            Ok(CaptureResponse {
                status: CaptureResponseCode::Ok,
                quota_limited: None,
            })
        }

        Err(err) => {
            report_internal_error_metrics(err.to_metric_tag(), "parsing");
            Err(err)
        }

        Ok((context, events)) => {
            let event_count = events.len() as u64;
            if let Err(err) = process_events(
                state.outputs.clone(),
                state.token_dropper.clone(),
                state.event_restriction_service.clone(),
                state.historical_cfg,
                state.global_rate_limiter_token_distinctid.clone(),
                state.overflow_limiter.clone(),
                state.ai_events_overflow_limiter.clone(),
                state.ingestion_warning_emitter.clone(),
                events,
                &context,
                state.ai_byte_rate_limiter.clone(),
            )
            .await
            {
                report_dropped_events(err.to_metric_tag(), event_count);
                report_internal_error_metrics(err.to_metric_tag(), "processing");
                return Err(err);
            }

            Ok(CaptureResponse {
                status: if params.beacon {
                    CaptureResponseCode::NoContent
                } else {
                    CaptureResponseCode::Ok
                },
                quota_limited: None,
            })
        }
    }
}

#[instrument(
    skip_all,
    fields(
        path,
        token,
        batch_size,
        user_agent,
        content_encoding,
        content_type,
        version,
        compression,
        historical_migration
    )
)]
#[debug_handler]
#[allow(clippy::too_many_arguments)]
pub async fn recording(
    state: State<router::State>,
    ip: InsecureClientIp,
    meta: Query<EventQuery>,
    headers: HeaderMap,
    method: Method,
    path: MatchedPath,
    wire_limit: Option<Extension<router::WireBodyLimit>>,
    body: Body,
) -> Result<CaptureResponse, CaptureError> {
    let mut params: EventQuery = meta.0;

    match handle_recording_payload(
        &state,
        &ip,
        &mut params,
        &headers,
        &method,
        &path,
        wire_limit.map(|Extension(l)| l),
        body,
    )
    .await
    {
        Err(CaptureError::BillingLimit) => Ok(CaptureResponse {
            status: CaptureResponseCode::Ok,
            quota_limited: Some(vec!["recordings".to_string()]),
        }),
        Err(err) => {
            report_internal_error_metrics(err.to_metric_tag(), "parsing");
            Err(err)
        }
        Ok((context, events)) => {
            let count = events.len() as u64;
            if let Err(err) = process_replay_events(
                state.outputs.clone(),
                state.event_restriction_service.clone(),
                state.replay_overflow_limiter.clone(),
                state.ingestion_warning_emitter.clone(),
                events,
                &context,
            )
            .await
            {
                report_dropped_events(err.to_metric_tag(), count);
                report_internal_error_metrics(err.to_metric_tag(), "processing");
                return Err(err);
            }
            Ok(CaptureResponse {
                status: if params.beacon {
                    CaptureResponseCode::NoContent
                } else {
                    CaptureResponseCode::Ok
                },
                quota_limited: None,
            })
        }
    }
}

pub async fn options() -> Result<Json<CaptureResponse>, CaptureError> {
    Ok(Json(CaptureResponse {
        status: CaptureResponseCode::Ok,
        quota_limited: None,
    }))
}
