use std::time::Duration;

use envconfig::Envconfig;
use opentelemetry::{KeyValue, Value};
use opentelemetry_otlp::WithExportConfig;
use opentelemetry_sdk::trace::{BatchConfig, RandomIdGenerator, Sampler, Tracer};
use opentelemetry_sdk::{runtime, Resource};
use tracing::level_filters::LevelFilter;
use tracing_opentelemetry::OpenTelemetryLayer;
use tracing_subscriber::fmt::format::FmtSpan;
use tracing_subscriber::layer::SubscriberExt;
use tracing_subscriber::util::SubscriberInitExt;
use tracing_subscriber::{EnvFilter, Layer};

use capture::config::Config;
use capture::server::serve;
use capture::setup;

common_alloc::used!();

fn init_tracer(sink_url: &str, sampling_rate: f64, service_name: &str) -> Tracer {
    opentelemetry_otlp::new_pipeline()
        .tracing()
        .with_trace_config(
            opentelemetry_sdk::trace::Config::default()
                .with_sampler(Sampler::ParentBased(Box::new(Sampler::TraceIdRatioBased(
                    sampling_rate,
                ))))
                .with_id_generator(RandomIdGenerator::default())
                .with_resource(Resource::new(vec![KeyValue::new(
                    "service.name",
                    Value::from(service_name.to_string()),
                )])),
        )
        .with_batch_config(BatchConfig::default())
        .with_exporter(
            opentelemetry_otlp::new_exporter()
                .tonic()
                .with_endpoint(sink_url)
                .with_timeout(Duration::from_secs(3)),
        )
        .install_batch(runtime::Tokio)
        .unwrap()
}

#[tokio::main]
async fn main() {
    let config = Config::init_from_env().expect("Invalid configuration:");

    // Start continuous profiling if enabled (keep _agent alive for the duration of the program)
    // Fails gracefully - logs error but doesn't prevent service from starting
    let _profiling_agent = match config.continuous_profiling.start_agent() {
        Ok(agent) => agent,
        Err(e) => {
            eprintln!("Failed to start continuous profiling agent: {e:#}");
            None
        }
    };

    let log_layer = {
        let base = tracing_subscriber::fmt::layer()
            .with_target(true)
            .with_thread_ids(true)
            .with_level(true);

        if config.log_level == tracing::Level::DEBUG {
            base.with_span_events(
                FmtSpan::NEW | FmtSpan::CLOSE | FmtSpan::ENTER | FmtSpan::EXIT | FmtSpan::ACTIVE,
            )
            .with_ansi(true)
            .with_filter(
                EnvFilter::builder()
                    .with_default_directive(LevelFilter::INFO.into())
                    .from_env_lossy()
                    .add_directive("pyroscope=warn".parse().unwrap()),
            )
            .boxed()
        } else {
            // Production: JSON format so Loki/Grafana can extract useful filter tags
            base.json()
                .flatten_event(true)
                .with_span_list(true)
                .with_current_span(true)
                .with_filter(
                    EnvFilter::builder()
                        .with_default_directive(LevelFilter::INFO.into())
                        .from_env_lossy()
                        .add_directive("pyroscope=warn".parse().unwrap()),
                )
                .boxed()
        }
    };

    let otel_layer = config
        .otel_url
        .clone()
        .map(|url| {
            OpenTelemetryLayer::new(init_tracer(
                &url,
                config.otel_sampling_rate,
                &config.otel_service_name,
            ))
        })
        .with_filter(LevelFilter::from_level(config.log_level));
    tracing_subscriber::registry()
        .with(log_layer)
        .with(otel_layer)
        .init();

    // Root span with pod hostname for Loki/Grafana filtering
    let pod = std::env::var("HOSTNAME").unwrap_or_else(|_| "unknown".to_string());
    let _root_span = tracing::info_span!("service", pod = %pod).entered();

    // Use OTEL_SERVICE_NAME (set per-variant by the chart's releaseName) as the
    // lifecycle Manager identity so `common/lifecycle` metrics carry the correct
    // `service_name` label. This binary is shared by capture, capture-replay,
    // capture-mirrored, and capture-ai deployments — hardcoding a literal here
    // would collapse their lifecycle metrics into a single bucket in Grafana.
    let mut manager = lifecycle::Manager::builder(config.otel_service_name.as_str())
        .with_trap_signals(true)
        .with_prestop_check(true)
        .with_health_poll_interval(Duration::from_secs(2))
        .build();

    let handles = setup::register_components(&mut manager, &config);
    let guard = manager.monitor_background();

    let listener = tokio::net::TcpListener::bind(config.address)
        .await
        .expect("could not bind port");
    tracing::info!("listening on {:?}", listener.local_addr().unwrap());

    let components = setup::build_components(config, std::env::vars().collect(), handles).await;

    serve(listener, components).await;

    match guard.wait().await {
        Ok(()) => tracing::info!("All lifecycle components completed cleanly"),
        Err(e) => tracing::warn!("Lifecycle monitor reported: {e}"),
    }
    tracing::info!("Shutdown complete");
}
