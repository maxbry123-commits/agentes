use envconfig::Envconfig;

use crate::v1::sinks::types::Destination;

/// Per-sink Kafka producer configuration. Loaded via `Envconfig::init_from_hashmap`
/// from env vars under the `KAFKA_` sub-prefix of a sink's env namespace.
///
/// For example, for sink "msk" the env var `CAPTURE_V1_SINK_MSK_KAFKA_HOSTS`
/// is stripped to key `HOSTS` in the hashmap fed to this struct.
#[derive(Envconfig, Clone, Debug)]
pub struct Config {
    // -- Connection --
    /// Comma-separated broker list (e.g. "broker1:9092,broker2:9092").
    pub hosts: String,
    #[envconfig(default = "false")]
    pub tls: bool,
    #[envconfig(default = "")]
    pub client_id: String,

    // -- Producer tuning (maps to librdkafka settings) --
    #[envconfig(default = "20")]
    pub linger_ms: u32,
    /// In-memory producer queue size in MiB (converted to KB for rdkafka).
    #[envconfig(default = "400")]
    pub queue_mib: u32,
    /// Time before we stop retrying producing a message (ms).
    /// Allows ~6 retry cycles at 5s socket timeout.
    #[envconfig(default = "30000")]
    pub message_timeout_ms: u32,
    #[envconfig(default = "1000000")]
    pub message_max_bytes: u32,
    /// none, gzip, snappy, lz4, zstd
    #[envconfig(default = "lz4")]
    pub compression_codec: String,
    #[envconfig(default = "all")]
    pub acks: String,
    #[envconfig(default = "false")]
    pub enable_idempotence: bool,
    #[envconfig(default = "10000")]
    pub batch_num_messages: u32,
    #[envconfig(default = "1000000")]
    pub batch_size: u32,
    /// How often librdkafka refreshes topic metadata from brokers (ms).
    /// Low value ensures fast leader discovery on broker failover.
    #[envconfig(default = "5000")]
    pub metadata_refresh_interval_ms: u32,
    /// Max age of cached metadata before forced refresh (ms). Should be
    /// `>= 3x` metadata_refresh_interval_ms. Keeping this low ensures
    /// stale broker state is flushed promptly after recovery.
    #[envconfig(default = "15000")]
    pub metadata_max_age_ms: u32,
    /// Timeout for socket operations (ms). Lower = faster dead broker detection.
    #[envconfig(default = "5000")]
    pub socket_timeout_ms: u32,
    /// How often librdkafka fires the stats callback (ms). Controls the
    /// refresh cadence for broker health, queue depth, and RTT gauges.
    #[envconfig(default = "10000")]
    pub statistics_interval_ms: u32,

    // -- v0 parity settings (defaults from production charts/argocd/capture) --
    /// Partitioning strategy. Must be murmur2_random for v0 parity
    /// (python-kafka compat). librdkafka default varies by version.
    #[envconfig(default = "murmur2_random")]
    pub partitioner: String,
    /// Max retry attempts per message. Production default: 4 (tuned for
    /// MSK failover with socket_timeout_ms=5000, message_timeout_ms=30000).
    #[envconfig(default = "4")]
    pub max_retries: u32,
    #[envconfig(default = "1000000")]
    pub max_in_flight_requests: u32,
    /// How long (ms) the producer sticks to a random partition for keyless
    /// messages before switching. Affects distribution of events with
    /// force_disable_person_processing (no partition key).
    #[envconfig(default = "10")]
    pub sticky_partitioning_linger_ms: u32,

    /// IP family for broker connections. Empty = let librdkafka decide (default);
    /// "v4" / "v6" / "any" force-select. Matches legacy KAFKA_BROKER_ADDRESS_FAMILY.
    #[envconfig(default = "")]
    pub broker_address_family: String,
    /// Log broker connection close events. librdkafka default = true.
    #[envconfig(default = "true")]
    pub log_connection_close: bool,
    /// Max messages buffered in the producer queue. librdkafka default = 100_000.
    #[envconfig(default = "100000")]
    pub queue_buffering_max_messages: u32,
    /// Upper bound on exponential retry backoff (ms). librdkafka default = 1000.
    #[envconfig(default = "1000")]
    pub retry_backoff_max_ms: u32,
    /// TCP socket send buffer size in bytes. 0 = use OS default. librdkafka default = 0.
    #[envconfig(default = "0")]
    pub socket_send_buffer_bytes: u32,
    /// TCP socket receive buffer size in bytes. 0 = use OS default. librdkafka default = 0.
    #[envconfig(default = "0")]
    pub socket_receive_buffer_bytes: u32,

    // -- Topics (all required -- envconfig errors if any are missing) --
    pub topic_main: String,
    pub topic_historical: String,
    pub topic_overflow: String,
    pub topic_dlq: String,

    // -- Non-analytics topics (also required) --
    pub topic_exception: String,
    pub topic_heatmap: String,
    pub topic_client_ingestion_warning: String,

    /// Dedicated topic for `$ai_*` events. Not meant to be set via per-sink
    /// env: setup injects the deployment-level `CAPTURE_ANALYTICS_AI_EVENTS_TOPIC` into
    /// every sink config, overwriting whatever the env parse produced.
    #[envconfig(default = "events_plugin_ingestion_ai")]
    pub topic_ai: String,

    /// Optional overflow topic for the AI lane. Like `topic_ai`, injected at
    /// setup from the deployment-level `CAPTURE_ANALYTICS_AI_EVENTS_OVERFLOW_TOPIC`; unset
    /// means the pipeline never produces `Destination::AiEventsOverflow`.
    pub topic_ai_overflow: Option<String>,
}

const VALID_ACKS: &[&str] = &["0", "1", "-1", "all"];
const VALID_COMPRESSION: &[&str] = &["none", "gzip", "snappy", "lz4", "zstd"];

impl Config {
    /// Validate kafka-specific configuration invariants that would otherwise
    /// blow up at rdkafka producer creation or silently break runtime health.
    pub fn validate(&self) -> anyhow::Result<()> {
        anyhow::ensure!(!self.hosts.is_empty(), "empty kafka hosts");

        anyhow::ensure!(
            self.queue_mib > 0,
            "queue_mib must be > 0 (got 0, which makes the producer queue zero-size)"
        );

        anyhow::ensure!(
            VALID_ACKS.contains(&self.acks.as_str()),
            "acks must be one of {VALID_ACKS:?} (got {:?})",
            self.acks
        );

        anyhow::ensure!(
            VALID_COMPRESSION.contains(&self.compression_codec.as_str()),
            "compression_codec must be one of {VALID_COMPRESSION:?} (got {:?})",
            self.compression_codec
        );

        anyhow::ensure!(
            self.statistics_interval_ms > 0,
            "statistics_interval_ms must be > 0 (0 disables stats callback, breaking health heartbeat)"
        );

        anyhow::ensure!(
            self.metadata_max_age_ms >= self.metadata_refresh_interval_ms * 3,
            "metadata_max_age_ms ({}) should be >= 3x metadata_refresh_interval_ms ({}) \
             for reliable metadata refresh after broker failover",
            self.metadata_max_age_ms,
            self.metadata_refresh_interval_ms
        );

        Ok(())
    }

    /// Resolve which topic to use for the given destination on this sink.
    pub fn topic_for<'a>(&'a self, dest: &'a Destination) -> Option<&'a str> {
        match dest {
            Destination::AnalyticsMain => Some(&self.topic_main),
            Destination::AnalyticsHistorical => Some(&self.topic_historical),
            Destination::Overflow => Some(&self.topic_overflow),
            Destination::Dlq => Some(&self.topic_dlq),
            Destination::ExceptionErrorTracking => Some(&self.topic_exception),
            Destination::HeatmapMain => Some(&self.topic_heatmap),
            Destination::ClientIngestionWarning => Some(&self.topic_client_ingestion_warning),
            Destination::AiEvents => Some(&self.topic_ai),
            Destination::AiEventsOverflow => self.topic_ai_overflow.as_deref(),
            Destination::Custom(t) => Some(t.as_str()),
            Destination::Drop => None,
        }
    }
}

#[cfg(test)]
mod tests {
    use std::collections::HashMap;

    use envconfig::Envconfig;
    use rstest::rstest;

    use super::Config;
    use crate::v1::sinks::Destination;

    fn required_kafka_env() -> HashMap<String, String> {
        [
            ("HOSTS", "localhost:9092"),
            ("TOPIC_MAIN", "events_main"),
            ("TOPIC_HISTORICAL", "events_hist"),
            ("TOPIC_OVERFLOW", "events_overflow"),
            ("TOPIC_DLQ", "events_dlq"),
            ("TOPIC_EXCEPTION", "error_tracking_events"),
            ("TOPIC_HEATMAP", "heatmaps_ingestion"),
            ("TOPIC_CLIENT_INGESTION_WARNING", "events_plugin_ingestion"),
        ]
        .into_iter()
        .map(|(k, v)| (k.to_string(), v.to_string()))
        .collect()
    }

    #[test]
    fn all_fields_from_hashmap() {
        let mut env = required_kafka_env();
        env.insert("TLS".into(), "true".into());
        env.insert("CLIENT_ID".into(), "my-client".into());
        env.insert("LINGER_MS".into(), "50".into());
        env.insert("QUEUE_MIB".into(), "800".into());
        env.insert("MESSAGE_TIMEOUT_MS".into(), "30000".into());
        env.insert("MESSAGE_MAX_BYTES".into(), "2000000".into());
        env.insert("COMPRESSION_CODEC".into(), "lz4".into());
        env.insert("ACKS".into(), "1".into());
        env.insert("ENABLE_IDEMPOTENCE".into(), "true".into());
        env.insert("BATCH_NUM_MESSAGES".into(), "5000".into());
        env.insert("BATCH_SIZE".into(), "500000".into());
        env.insert("METADATA_REFRESH_INTERVAL_MS".into(), "10000".into());
        env.insert("METADATA_MAX_AGE_MS".into(), "30000".into());
        env.insert("SOCKET_TIMEOUT_MS".into(), "30000".into());
        env.insert("STATISTICS_INTERVAL_MS".into(), "5000".into());
        env.insert("PARTITIONER".into(), "consistent_random".into());
        env.insert("MAX_RETRIES".into(), "6".into());
        env.insert("MAX_IN_FLIGHT_REQUESTS".into(), "500000".into());
        env.insert("STICKY_PARTITIONING_LINGER_MS".into(), "20".into());
        env.insert("BROKER_ADDRESS_FAMILY".into(), "v4".into());
        env.insert("LOG_CONNECTION_CLOSE".into(), "false".into());
        env.insert("QUEUE_BUFFERING_MAX_MESSAGES".into(), "250000".into());
        env.insert("RETRY_BACKOFF_MAX_MS".into(), "2000".into());
        env.insert("SOCKET_SEND_BUFFER_BYTES".into(), "65536".into());
        env.insert("SOCKET_RECEIVE_BUFFER_BYTES".into(), "65536".into());

        let cfg = Config::init_from_hashmap(&env).unwrap();
        assert_eq!(cfg.hosts, "localhost:9092");
        assert!(cfg.tls);
        assert_eq!(cfg.client_id, "my-client");
        assert_eq!(cfg.linger_ms, 50);
        assert_eq!(cfg.queue_mib, 800);
        assert_eq!(cfg.message_timeout_ms, 30000);
        assert_eq!(cfg.message_max_bytes, 2000000);
        assert_eq!(cfg.compression_codec, "lz4");
        assert_eq!(cfg.acks, "1");
        assert!(cfg.enable_idempotence);
        assert_eq!(cfg.batch_num_messages, 5000);
        assert_eq!(cfg.batch_size, 500000);
        assert_eq!(cfg.metadata_refresh_interval_ms, 10000);
        assert_eq!(cfg.metadata_max_age_ms, 30000);
        assert_eq!(cfg.socket_timeout_ms, 30000);
        assert_eq!(cfg.statistics_interval_ms, 5000);
        assert_eq!(cfg.partitioner, "consistent_random");
        assert_eq!(cfg.max_retries, 6);
        assert_eq!(cfg.max_in_flight_requests, 500000);
        assert_eq!(cfg.sticky_partitioning_linger_ms, 20);
        assert_eq!(cfg.broker_address_family, "v4");
        assert!(!cfg.log_connection_close);
        assert_eq!(cfg.queue_buffering_max_messages, 250000);
        assert_eq!(cfg.retry_backoff_max_ms, 2000);
        assert_eq!(cfg.socket_send_buffer_bytes, 65536);
        assert_eq!(cfg.socket_receive_buffer_bytes, 65536);
        assert_eq!(cfg.topic_main, "events_main");
    }

    #[test]
    fn defaults_applied() {
        let env = required_kafka_env();
        let cfg = Config::init_from_hashmap(&env).unwrap();
        assert!(!cfg.tls);
        assert_eq!(cfg.client_id, "");
        assert_eq!(cfg.linger_ms, 20);
        assert_eq!(cfg.queue_mib, 400);
        assert_eq!(cfg.message_timeout_ms, 30000);
        assert_eq!(cfg.message_max_bytes, 1000000);
        assert_eq!(cfg.compression_codec, "lz4");
        assert_eq!(cfg.acks, "all");
        assert!(!cfg.enable_idempotence);
        assert_eq!(cfg.batch_num_messages, 10000);
        assert_eq!(cfg.batch_size, 1000000);
        assert_eq!(cfg.metadata_refresh_interval_ms, 5000);
        assert_eq!(cfg.metadata_max_age_ms, 15000);
        assert_eq!(cfg.socket_timeout_ms, 5000);
        assert_eq!(cfg.statistics_interval_ms, 10000);
        assert_eq!(cfg.partitioner, "murmur2_random");
        assert_eq!(cfg.max_retries, 4);
        assert_eq!(cfg.max_in_flight_requests, 1000000);
        assert_eq!(cfg.sticky_partitioning_linger_ms, 10);
        assert_eq!(cfg.broker_address_family, "");
        assert!(cfg.log_connection_close);
        assert_eq!(cfg.queue_buffering_max_messages, 100000);
        assert_eq!(cfg.retry_backoff_max_ms, 1000);
        assert_eq!(cfg.socket_send_buffer_bytes, 0);
        assert_eq!(cfg.socket_receive_buffer_bytes, 0);
    }

    #[rstest]
    #[case("HOSTS")]
    #[case("TOPIC_MAIN")]
    #[case("TOPIC_HISTORICAL")]
    #[case("TOPIC_OVERFLOW")]
    #[case("TOPIC_DLQ")]
    #[case("TOPIC_EXCEPTION")]
    #[case("TOPIC_HEATMAP")]
    #[case("TOPIC_CLIENT_INGESTION_WARNING")]
    fn missing_required_field_errors(#[case] key: &str) {
        let mut env = required_kafka_env();
        env.remove(key);
        assert!(
            Config::init_from_hashmap(&env).is_err(),
            "{key} should be required"
        );
    }

    #[test]
    fn numeric_field_parsing_error() {
        let mut env = required_kafka_env();
        env.insert("LINGER_MS".into(), "not_a_number".into());
        assert!(Config::init_from_hashmap(&env).is_err());
    }

    // -- validate() tests --

    type Mutator = (&'static str, fn(&mut Config));

    fn valid_config() -> Config {
        Config::init_from_hashmap(&required_kafka_env()).unwrap()
    }

    #[test]
    fn validate_accepts_defaults() {
        assert!(valid_config().validate().is_ok());
    }

    #[test]
    fn validate_rejects_bad_configs() {
        let cases: &[Mutator] = &[
            ("empty_hosts", |c| c.hosts = "".into()),
            ("queue_mib_zero", |c| c.queue_mib = 0),
            ("acks_garbage", |c| c.acks = "banana".into()),
            ("compression_garbage", |c| {
                c.compression_codec = "brotli".into()
            }),
            ("stats_interval_zero", |c| c.statistics_interval_ms = 0),
            ("metadata_age_too_low", |c| {
                c.metadata_refresh_interval_ms = 5000;
                c.metadata_max_age_ms = 10000;
            }),
        ];

        for (label, mutate) in cases {
            let mut cfg = valid_config();
            mutate(&mut cfg);
            assert!(
                cfg.validate().is_err(),
                "case '{label}' should fail validation"
            );
        }
    }

    #[test]
    fn validate_accepts_valid_acks_values() {
        for acks in ["0", "1", "-1", "all"] {
            let mut cfg = valid_config();
            cfg.acks = acks.to_string();
            assert!(cfg.validate().is_ok(), "acks={acks} should be valid");
        }
    }

    #[test]
    fn validate_accepts_all_compression_codecs() {
        for codec in ["none", "gzip", "snappy", "lz4", "zstd"] {
            let mut cfg = valid_config();
            cfg.compression_codec = codec.to_string();
            assert!(cfg.validate().is_ok(), "codec={codec} should be valid");
        }
    }

    #[test]
    fn validate_metadata_age_boundary() {
        let mut cfg = valid_config();
        cfg.metadata_refresh_interval_ms = 5000;

        cfg.metadata_max_age_ms = 14999;
        assert!(cfg.validate().is_err(), "just under 3x should fail");

        cfg.metadata_max_age_ms = 15000;
        assert!(cfg.validate().is_ok(), "exactly 3x should pass");
    }

    #[rstest]
    #[case(Destination::AnalyticsMain, Some("events_main"))]
    #[case(Destination::AnalyticsHistorical, Some("events_hist"))]
    #[case(Destination::Overflow, Some("events_overflow"))]
    #[case(Destination::Dlq, Some("events_dlq"))]
    #[case(Destination::ExceptionErrorTracking, Some("error_tracking_events"))]
    #[case(Destination::HeatmapMain, Some("heatmaps_ingestion"))]
    #[case(Destination::ClientIngestionWarning, Some("events_plugin_ingestion"))]
    #[case(Destination::Drop, None)]
    fn topic_for_resolves_destination(#[case] dest: Destination, #[case] expected: Option<&str>) {
        let cfg = Config::init_from_hashmap(&required_kafka_env()).unwrap();
        assert_eq!(cfg.topic_for(&dest), expected);
    }

    #[test]
    fn topic_ai_defaults() {
        let cfg = Config::init_from_hashmap(&required_kafka_env()).unwrap();
        assert_eq!(cfg.topic_ai, "events_plugin_ingestion_ai");
        assert_eq!(
            cfg.topic_for(&Destination::AiEvents),
            Some("events_plugin_ingestion_ai")
        );
        assert_eq!(cfg.topic_ai_overflow, None);
        assert_eq!(cfg.topic_for(&Destination::AiEventsOverflow), None);
    }

    #[test]
    fn topic_ai_overflow_present_resolves_destination() {
        // Set the field directly, mirroring how setup injects
        // CAPTURE_ANALYTICS_AI_EVENTS_OVERFLOW_TOPIC into sink configs after env loading.
        let mut cfg = Config::init_from_hashmap(&required_kafka_env()).unwrap();
        cfg.topic_ai_overflow = Some("ai_events_overflow".to_string());
        assert_eq!(
            cfg.topic_for(&Destination::AiEventsOverflow),
            Some("ai_events_overflow")
        );
    }

    #[test]
    fn topic_ai_present_resolves_destination() {
        // Set the field directly, mirroring how setup injects CAPTURE_ANALYTICS_AI_EVENTS_TOPIC
        // into sink configs after env loading.
        let mut cfg = Config::init_from_hashmap(&required_kafka_env()).unwrap();
        cfg.topic_ai = "ai_events".to_string();
        assert_eq!(cfg.topic_for(&Destination::AiEvents), Some("ai_events"));
    }
}
