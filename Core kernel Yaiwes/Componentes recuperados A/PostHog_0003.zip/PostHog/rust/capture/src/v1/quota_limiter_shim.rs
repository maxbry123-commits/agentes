use common_types::HasEventName;
use limiters::redis::QuotaResource;
use metrics::counter;

use crate::quota_limiters::CaptureQuotaLimiter;
use crate::quota_limiters::{is_exception_event, is_llm_event, is_survey_event, EventInfo};
use crate::v1::analytics::constants::CAPTURE_V1_EVENTS_QUOTA_LIMITED;
use crate::v1::analytics::types::{EventResult, WrappedEvent};
use crate::v1::sinks::Destination;
use crate::v1::Error;

type ScopedCheck = (QuotaResource, fn(EventInfo) -> bool);

const SCOPED_CHECKS: &[ScopedCheck] = &[
    (QuotaResource::Exceptions, is_exception_event),
    (QuotaResource::Surveys, is_survey_event),
    (QuotaResource::LLMEvents, is_llm_event),
];

/// Apply billing quota limits to a batch of events in-place.
///
/// Checks global limiter first (short-circuit), then scoped limiters.
/// Returns `Error::BillingLimitExceeded` when every event is limited.
/// Expects at least one `Ok` event — all-dropped batches should
/// short-circuit in `process_batch` before reaching here.
pub async fn apply_quota_limits(
    limiter: &CaptureQuotaLimiter,
    token: &str,
    events: &mut [WrappedEvent],
) -> Result<(), Error> {
    if events.is_empty() {
        return Ok(());
    }

    // --- Global check — short-circuit ---
    if limiter
        .is_quota_limited_v1(token, &QuotaResource::Events)
        .await
    {
        counter!(CAPTURE_V1_EVENTS_QUOTA_LIMITED, "resource" => "events")
            .increment(events.len() as u64);
        return Err(Error::BillingLimitExceeded);
    }

    // --- Scoped checks ---
    let mut all_non_ok = true;
    for (resource, predicate) in SCOPED_CHECKS {
        if !limiter.is_quota_limited_v1(token, resource).await {
            continue;
        }

        let resource_tag = resource.as_str();
        let mut count: u64 = 0;
        for ev in events.iter_mut() {
            if ev.result != EventResult::Ok {
                continue;
            }
            // Gateway-verified events are wallet-billed, not AIO-billed, so they
            // must not be dropped by the llm_events quota.
            if *resource == QuotaResource::LLMEvents && ev.is_gateway_verified {
                continue;
            }
            let info = EventInfo {
                name: ev.event_name(),
                has_product_tour_id: ev.has_property("product_tour_id"),
            };
            if predicate(info) {
                ev.result = EventResult::Drop;
                ev.destination = Destination::Drop;
                ev.details = Some(match resource {
                    QuotaResource::Exceptions => "exceptions_over_quota",
                    QuotaResource::Surveys => "survey_responses_over_quota",
                    QuotaResource::LLMEvents => "llm_events_over_quota",
                    _ => "over_quota",
                });
                count += 1;
            }
        }
        if count > 0 {
            counter!(CAPTURE_V1_EVENTS_QUOTA_LIMITED, "resource" => resource_tag).increment(count);
        }
    }

    // If every event is now non-Ok, the whole batch is limited
    for ev in events.iter() {
        if ev.result == EventResult::Ok {
            all_non_ok = false;
            break;
        }
    }
    if all_non_ok {
        return Err(Error::BillingLimitExceeded);
    }

    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::num::NonZeroU32;
    use std::sync::Arc;
    use std::time::Duration;

    use chrono::{DateTime, Utc};
    use common_continuous_profiling::ContinuousProfilingConfig;
    use common_redis::MockRedisClient;
    use limiters::redis::QUOTA_LIMITER_CACHE_KEY;
    use serde_json::value::RawValue;
    use tracing::Level;
    use uuid::Uuid;

    use crate::config::EnvelopeCompression;

    use crate::config::{CaptureMode, Config, KafkaConfig};
    use crate::v1::analytics::types::{Event, Options, RawOptions};

    fn test_config() -> Config {
        Config {
            print_sink: false,
            noop_sink: false,
            address: "127.0.0.1:0".parse().unwrap(),
            redis_url: "redis://localhost:6379/".to_string(),
            redis_response_timeout_ms: 100,
            redis_connection_timeout_ms: 5000,
            global_rate_limit_enabled: false,
            global_rate_limit_dry_run: false,
            global_rate_limit_window_interval_secs: 60,
            global_rate_limit_sync_interval_secs: 15,
            global_rate_limit_tick_interval_ms: 1000,
            global_rate_limit_token_distinctid_threshold: 10_000,
            global_rate_limit_token_distinctid_overrides_csv: None,
            global_rate_limit_token_distinctid_local_cache_max_entries: 300_000,
            global_rate_limit_min_sync_floor: 0,
            global_rate_limit_max_sync_keys_per_tick: 20_000,
            global_rate_limit_max_keys_per_command: 2_000,
            global_rate_limit_max_concurrent_commands: 4,
            global_rate_limit_max_write_batch_entries: 200_000,
            global_rate_limit_max_pending_sync_entries: 200_000,
            global_rate_limit_local_cache_ttl_secs: 600,
            global_rate_limit_local_cache_idle_timeout_secs: 300,
            global_rate_limit_read_timeout_ms: 250,
            global_rate_limit_write_timeout_ms: 250,
            global_rate_limit_token_threshold: 300_000,
            global_rate_limit_token_overrides_csv: None,
            global_rate_limit_token_local_cache_max_entries: 300_000,
            global_rate_limit_redis_url: None,
            global_rate_limit_redis_reader_url: None,
            global_rate_limit_redis_response_timeout_ms: None,
            global_rate_limit_redis_connection_timeout_ms: None,
            global_rate_limit_custom_threshold_key: None,
            global_rate_limit_custom_threshold_refresh_secs: 60,
            event_restrictions_enabled: false,
            event_restrictions_redis_url: None,
            event_restrictions_refresh_interval_secs: 30,
            event_restrictions_fail_open_after_secs: 300,
            overflow_enabled: false,
            overflow_preserve_partition_locality: false,
            overflow_burst_limit: NonZeroU32::new(5).unwrap(),
            overflow_per_second_limit: NonZeroU32::new(10).unwrap(),
            ingestion_force_overflow_by_token_distinct_id: None,
            drop_events_by_token_distinct_id: None,
            enable_historical_rerouting: false,
            historical_rerouting_threshold_days: 1,
            is_mirror_deploy: false,
            log_level: Level::INFO,
            verbose_sample_percent: 0.0,
            kafka: KafkaConfig {
                kafka_producer_linger_ms: 0,
                kafka_producer_queue_mib: 10,
                kafka_message_timeout_ms: 10000,
                kafka_producer_message_max_bytes: 1000000,
                kafka_topic_metadata_refresh_interval_ms: 10000,
                kafka_compression_codec: "none".to_string(),
                kafka_hosts: "kafka:9092".to_string(),
                kafka_topic: "events_plugin_ingestion".to_string(),
                kafka_overflow_topic: "events_plugin_ingestion_overflow".to_string(),
                kafka_historical_topic: "events_plugin_ingestion_historical".to_string(),
                kafka_client_ingestion_warning_topic: "events_plugin_ingestion".to_string(),
                kafka_error_tracking_topic: "error_tracking_events".to_string(),
                kafka_heatmaps_topic: "events_plugin_ingestion".to_string(),
                kafka_replay_overflow_topic: "session_recording_snapshot_item_overflow".to_string(),
                kafka_dlq_topic: "events_plugin_ingestion_dlq".to_string(),
                outputs_completeness_check_enabled: true,
                capture_analytics_ai_events_topic: "events_plugin_ingestion_ai".to_string(),
                capture_analytics_ai_events_overflow_topic: None,
                kafka_traces_topic: "ingestion_traces".to_string(),
                kafka_metrics_topic: "ingestion_metrics".to_string(),
                kafka_tls: false,
                kafka_client_id: String::new(),
                kafka_metadata_max_age_ms: 60000,
                kafka_producer_max_retries: 2,
                kafka_producer_acks: "all".to_string(),
                kafka_socket_timeout_ms: 60000,
                kafka_producer_batch_num_messages: 10000,
                kafka_producer_batch_size: 1000000,
                kafka_producer_max_in_flight_requests: 1000000,
                kafka_producer_sticky_partitioning_linger_ms: 10,
                kafka_producer_enable_idempotence: false,
                kafka_producer_partitioner: "murmur2_random".to_string(),
                kafka_broker_address_family: String::new(),
                kafka_log_connection_close: true,
                kafka_producer_queue_buffering_max_messages: 100000,
                kafka_retry_backoff_max_ms: 1000,
                kafka_socket_send_buffer_bytes: 0,
                kafka_socket_receive_buffer_bytes: 0,
                kafka_traces_hosts: None,
                kafka_traces_tls: None,
                kafka_traces_client_id: None,
                kafka_traces_compression_codec: None,
                kafka_traces_producer_acks: None,
                kafka_traces_producer_linger_ms: None,
                kafka_traces_producer_queue_mib: None,
                kafka_traces_message_timeout_ms: None,
                kafka_traces_producer_message_max_bytes: None,
                kafka_traces_producer_max_retries: None,
                kafka_traces_topic_metadata_refresh_interval_ms: None,
                kafka_traces_metadata_max_age_ms: None,
                kafka_metrics_hosts: None,
                kafka_metrics_tls: None,
                kafka_metrics_client_id: None,
                kafka_metrics_compression_codec: None,
                kafka_metrics_producer_acks: None,
                kafka_metrics_producer_linger_ms: None,
                kafka_metrics_producer_queue_mib: None,
                kafka_metrics_message_timeout_ms: None,
                kafka_metrics_producer_message_max_bytes: None,
                kafka_metrics_producer_max_retries: None,
                kafka_metrics_topic_metadata_refresh_interval_ms: None,
                kafka_metrics_metadata_max_age_ms: None,
                kafka_replay_envelope_compression: EnvelopeCompression::None,
            },
            otel_url: None,
            otel_sampling_rate: 0.0,
            otel_service_name: "capture-testing".to_string(),
            export_prometheus: false,
            redis_key_prefix: None,
            capture_mode: CaptureMode::Events,
            concurrency_limit: None,
            s3_fallback_enabled: false,
            s3_fallback_bucket: None,
            s3_fallback_endpoint: None,
            s3_fallback_prefix: String::new(),
            ai_max_sum_of_parts_bytes: 26_214_400,
            ai_max_event_bytes: 8_388_608,
            ai_gateway_signing_secret: None,
            http1_header_read_timeout_ms: Some(5000),
            body_chunk_read_timeout_ms: None,
            body_read_chunk_size_kb: 256,
            continuous_profiling: ContinuousProfilingConfig::default(),
            capture_v1_sinks: String::new(),
            capture_v1_max_compressed_body_bytes: 10 * 1024 * 1024,
            capture_v1_max_decompressed_body_bytes: 50 * 1024 * 1024,
            capture_v1_scatter_gather_min_batch: 8,
            capture_ingestion_warnings_enabled: false,
            capture_ingestion_warnings_kafka_queue_mib: 16,
            capture_ingestion_warnings_kafka_message_max_bytes: 1048576,
            capture_ingestion_warnings_kafka_topic: String::new(),
            capture_ingestion_warnings_kafka_hosts: String::new(),
            capture_ingestion_warnings_kafka_tls: false,
            ai_byte_limit_per_second: 0,
            ai_byte_limit_overrides_csv: None,
            ai_byte_limit_dry_run: false,
            ai_byte_limit_window_interval_secs: None,
            ai_byte_limit_local_cache_max_entries: 300_000,
        }
    }

    async fn build_limiter(
        token: &str,
        set_global_limit: bool,
        resources_to_limit: &[QuotaResource],
    ) -> CaptureQuotaLimiter {
        let cfg = test_config();
        let global_resource = CaptureQuotaLimiter::get_resource_for_mode(cfg.capture_mode);
        let global_key = format!("{}{}", QUOTA_LIMITER_CACHE_KEY, global_resource.as_str());

        let mut redis = if set_global_limit {
            MockRedisClient::new().zrangebyscore_ret(&global_key, vec![token.to_string()])
        } else {
            MockRedisClient::new().zrangebyscore_ret(&global_key, vec![])
        };

        for resource in &[
            QuotaResource::Exceptions,
            QuotaResource::Surveys,
            QuotaResource::LLMEvents,
        ] {
            let key = format!("{}{}", QUOTA_LIMITER_CACHE_KEY, resource.as_str());
            let limited_tokens = if resources_to_limit.contains(resource) {
                vec![token.to_string()]
            } else {
                vec![]
            };
            redis = redis.zrangebyscore_ret(&key, limited_tokens);
        }

        let limiter = CaptureQuotaLimiter::new(&cfg, Arc::new(redis), Duration::from_secs(60))
            .add_scoped_limiter(QuotaResource::Exceptions, is_exception_event)
            .add_scoped_limiter(QuotaResource::Surveys, is_survey_event)
            .add_scoped_limiter(QuotaResource::LLMEvents, is_llm_event);

        // Allow background tasks to populate the DashMap caches from MockRedisClient
        tokio::time::sleep(Duration::from_millis(50)).await;

        limiter
    }

    fn make_event(name: &str, product_tour_id: Option<&str>) -> WrappedEvent {
        let uuid = Uuid::now_v7();
        WrappedEvent {
            event: Event {
                event: name.to_string(),
                uuid: uuid.to_string(),
                distinct_id: "test_user".to_string(),
                timestamp: "2026-03-26T12:00:00.000Z".to_string(),
                session_id: None,
                window_id: None,
                options: match product_tour_id {
                    Some(id) => RawOptions(serde_json::json!({"product_tour_id": id})),
                    None => RawOptions::default(),
                },
                properties: RawValue::from_string("{}".to_owned()).unwrap(),
            },
            uuid,
            options: Options {
                cookieless_mode: None,
                disable_skew_correction: None,
                product_tour_id: product_tour_id.map(String::from),
                process_person_profile: None,
            },
            adjusted_timestamp: Some(
                DateTime::parse_from_rfc3339("2026-03-26T12:00:00Z")
                    .unwrap()
                    .with_timezone(&Utc),
            ),
            result: EventResult::Ok,
            details: None,
            destination: Destination::AnalyticsMain,
            force_disable_person_processing: false,
            spread_partitions: false,
            is_gateway_verified: false,
        }
    }

    fn make_verified_event(name: &str) -> WrappedEvent {
        let mut ev = make_event(name, None);
        ev.is_gateway_verified = true;
        ev
    }

    fn ok_event_names(events: &[WrappedEvent]) -> Vec<&str> {
        let mut names: Vec<&str> = events
            .iter()
            .filter(|e| e.result == EventResult::Ok)
            .map(|e| e.event.event.as_str())
            .collect();
        names.sort();
        names
    }

    fn quota_dropped_event_names(events: &[WrappedEvent]) -> Vec<&str> {
        let mut names: Vec<&str> = events
            .iter()
            .filter(|e| e.result == EventResult::Drop && e.destination == Destination::Drop)
            .map(|e| e.event.event.as_str())
            .collect();
        names.sort();
        names
    }

    /// Panics on zero or multiple matches — callers rely on uniqueness.
    fn find_unique_by_name<'a>(events: &'a [WrappedEvent], name: &str) -> &'a WrappedEvent {
        let matches: Vec<&WrappedEvent> = events.iter().filter(|e| e.event.event == name).collect();
        assert_eq!(
            matches.len(),
            1,
            "expected exactly one event named {name:?}, found {}",
            matches.len()
        );
        matches[0]
    }

    // -----------------------------------------------------------------------
    // No limits
    // -----------------------------------------------------------------------

    #[tokio::test]
    async fn no_limits_all_events_pass() {
        let limiter = build_limiter("tok", false, &[]).await;
        let mut events = vec![
            make_event("$pageview", None),
            make_event("$exception", None),
            make_event("survey sent", None),
            make_event("$ai_generation", None),
        ];

        let result = apply_quota_limits(&limiter, "tok", &mut events).await;
        assert!(result.is_ok());
        assert_eq!(ok_event_names(&events).len(), 4);
        assert!(quota_dropped_event_names(&events).is_empty());
    }

    // -----------------------------------------------------------------------
    // Global limit
    // -----------------------------------------------------------------------

    #[tokio::test]
    async fn global_limit_returns_error_without_marking_events() {
        let limiter = build_limiter("tok", true, &[]).await;
        let mut events = vec![
            make_event("$pageview", None),
            make_event("$exception", None),
            make_event("survey sent", None),
            make_event("$ai_generation", None),
        ];

        let result = apply_quota_limits(&limiter, "tok", &mut events).await;
        assert!(result.is_err());

        // Global limit short-circuits without mutating events
        assert_eq!(ok_event_names(&events).len(), 4);
        assert!(quota_dropped_event_names(&events).is_empty());
    }

    #[tokio::test]
    async fn global_limit_preserves_all_event_states() {
        let limiter = build_limiter("tok", true, &[]).await;
        let bad = make_event("bad_event", None);
        let bad_uuid = bad.uuid;
        let mut events = vec![make_event("$pageview", None), bad];
        // Pre-mark one event as Drop (e.g. from validation)
        let bad_ev = events.iter_mut().find(|e| e.uuid == bad_uuid).unwrap();
        bad_ev.result = EventResult::Drop;
        bad_ev.destination = Destination::Drop;
        bad_ev.details = Some("invalid_event_name");

        let result = apply_quota_limits(&limiter, "tok", &mut events).await;
        assert!(result.is_err());

        // Global limit short-circuits — no events are mutated
        let pv = find_unique_by_name(&events, "$pageview");
        assert_eq!(pv.result, EventResult::Ok);
        assert_eq!(pv.details, None);

        // Pre-existing Drop event also untouched
        let bad_ev = events.iter().find(|e| e.uuid == bad_uuid).unwrap();
        assert_eq!(bad_ev.result, EventResult::Drop);
        assert_eq!(bad_ev.details, Some("invalid_event_name"));
    }

    #[tokio::test]
    async fn global_limit_different_token_not_affected() {
        let limiter = build_limiter("limited_tok", true, &[]).await;
        let mut events = vec![
            make_event("$pageview", None),
            make_event("$exception", None),
        ];

        let result = apply_quota_limits(&limiter, "other_tok", &mut events).await;
        assert!(result.is_ok());
        assert_eq!(ok_event_names(&events).len(), 2);
    }

    // -----------------------------------------------------------------------
    // Exception scoped limit
    // -----------------------------------------------------------------------

    #[tokio::test]
    async fn exception_limit_marks_only_exceptions() {
        let limiter = build_limiter("tok", false, &[QuotaResource::Exceptions]).await;
        let mut events = vec![
            make_event("$pageview", None),
            make_event("$exception", None),
            make_event("survey sent", None),
            make_event("$exception", None),
        ];

        let result = apply_quota_limits(&limiter, "tok", &mut events).await;
        assert!(result.is_ok());

        let mut ok = ok_event_names(&events);
        ok.sort();
        assert_eq!(ok, vec!["$pageview", "survey sent"]);
        assert_eq!(
            quota_dropped_event_names(&events),
            vec!["$exception", "$exception"]
        );
        for ev in events.iter().filter(|e| e.result == EventResult::Drop) {
            assert_eq!(ev.details, Some("exceptions_over_quota"));
        }
    }

    #[tokio::test]
    async fn exception_limit_all_exceptions_returns_error() {
        let limiter = build_limiter("tok", false, &[QuotaResource::Exceptions]).await;
        let mut events = vec![
            make_event("$exception", None),
            make_event("$exception", None),
        ];

        let result = apply_quota_limits(&limiter, "tok", &mut events).await;
        assert!(result.is_err());
        assert_eq!(quota_dropped_event_names(&events).len(), 2);
    }

    // -----------------------------------------------------------------------
    // Survey scoped limit
    // -----------------------------------------------------------------------

    #[tokio::test]
    async fn survey_limit_marks_only_survey_events() {
        let limiter = build_limiter("tok", false, &[QuotaResource::Surveys]).await;
        let mut events = vec![
            make_event("$pageview", None),
            make_event("survey sent", None),
            make_event("survey shown", None),
            make_event("survey dismissed", None),
            make_event("$exception", None),
        ];

        let result = apply_quota_limits(&limiter, "tok", &mut events).await;
        assert!(result.is_ok());

        let mut ok = ok_event_names(&events);
        ok.sort();
        assert_eq!(ok, vec!["$exception", "$pageview"]);
        assert_eq!(quota_dropped_event_names(&events).len(), 3);
        for ev in events.iter().filter(|e| e.result == EventResult::Drop) {
            assert_eq!(ev.details, Some("survey_responses_over_quota"));
        }
    }

    #[tokio::test]
    async fn survey_limit_excludes_product_tour_events() {
        let limiter = build_limiter("tok", false, &[QuotaResource::Surveys]).await;
        let tour_ev = make_event("survey sent", Some("tour-123"));
        let tour_uuid = tour_ev.uuid;
        let mut events = vec![make_event("survey sent", None), tour_ev];

        let result = apply_quota_limits(&limiter, "tok", &mut events).await;
        assert!(result.is_ok());

        // Product tour survey → Ok, regular survey → Drop (quota exceeded)
        assert_eq!(
            events.iter().find(|e| e.uuid == tour_uuid).unwrap().result,
            EventResult::Ok
        );
        assert_eq!(quota_dropped_event_names(&events).len(), 1);
    }

    // -----------------------------------------------------------------------
    // LLM scoped limit
    // -----------------------------------------------------------------------

    #[tokio::test]
    async fn llm_limit_marks_only_ai_events() {
        let limiter = build_limiter("tok", false, &[QuotaResource::LLMEvents]).await;
        let mut events = vec![
            make_event("$ai_generation", None),
            make_event("$ai_span", None),
            make_event("$pageview", None),
            make_event("$ai_trace", None),
        ];

        let result = apply_quota_limits(&limiter, "tok", &mut events).await;
        assert!(result.is_ok());

        assert_eq!(ok_event_names(&events), vec!["$pageview"]);
        assert_eq!(quota_dropped_event_names(&events).len(), 3);
        for ev in events.iter().filter(|e| e.result == EventResult::Drop) {
            assert_eq!(ev.details, Some("llm_events_over_quota"));
        }
    }

    #[tokio::test]
    async fn llm_limit_ignores_non_ai_prefix() {
        let limiter = build_limiter("tok", false, &[QuotaResource::LLMEvents]).await;
        let mut events = vec![
            make_event("$ai_generation", None),
            make_event("$ainotcounted", None), // no underscore
            make_event("ai_generation", None), // no $ prefix
        ];

        let result = apply_quota_limits(&limiter, "tok", &mut events).await;
        assert!(result.is_ok());

        let mut ok = ok_event_names(&events);
        ok.sort();
        assert_eq!(ok, vec!["$ainotcounted", "ai_generation"]);
        assert_eq!(quota_dropped_event_names(&events), vec!["$ai_generation"]);
    }

    #[tokio::test]
    async fn llm_limit_exempts_gateway_verified_events() {
        let limiter = build_limiter("tok", false, &[QuotaResource::LLMEvents]).await;
        let verified = make_verified_event("$ai_generation");
        let verified_uuid = verified.uuid;
        let mut events = vec![verified, make_event("$ai_generation", None)];

        let result = apply_quota_limits(&limiter, "tok", &mut events).await;
        assert!(result.is_ok());

        // Gateway-verified event survives (wallet-billed); the plain $ai_ one drops.
        let verified = events.iter().find(|e| e.uuid == verified_uuid).unwrap();
        assert_eq!(verified.result, EventResult::Ok);
        assert_eq!(verified.details, None);
        assert_eq!(quota_dropped_event_names(&events), vec!["$ai_generation"]);
    }

    // -----------------------------------------------------------------------
    // Multiple scoped limits
    // -----------------------------------------------------------------------

    #[tokio::test]
    async fn multiple_scoped_limits_applied_independently() {
        let limiter = build_limiter(
            "tok",
            false,
            &[
                QuotaResource::Exceptions,
                QuotaResource::Surveys,
                QuotaResource::LLMEvents,
            ],
        )
        .await;
        let mut events = vec![
            make_event("$exception", None),
            make_event("survey sent", None),
            make_event("$ai_generation", None),
            make_event("$pageview", None),
        ];

        let result = apply_quota_limits(&limiter, "tok", &mut events).await;
        assert!(result.is_ok());

        assert_eq!(ok_event_names(&events), vec!["$pageview"]);
        assert_eq!(quota_dropped_event_names(&events).len(), 3);
        assert_eq!(
            find_unique_by_name(&events, "$exception").details,
            Some("exceptions_over_quota")
        );
        assert_eq!(
            find_unique_by_name(&events, "survey sent").details,
            Some("survey_responses_over_quota")
        );
        assert_eq!(
            find_unique_by_name(&events, "$ai_generation").details,
            Some("llm_events_over_quota")
        );
    }

    #[tokio::test]
    async fn all_scoped_limited_returns_error() {
        let limiter = build_limiter(
            "tok",
            false,
            &[
                QuotaResource::Exceptions,
                QuotaResource::Surveys,
                QuotaResource::LLMEvents,
            ],
        )
        .await;
        let mut events = vec![
            make_event("$exception", None),
            make_event("survey sent", None),
            make_event("$ai_generation", None),
        ];

        let result = apply_quota_limits(&limiter, "tok", &mut events).await;
        assert!(result.is_err());
        assert!(ok_event_names(&events).is_empty());
    }

    // -----------------------------------------------------------------------
    // Global + scoped limits interaction
    // -----------------------------------------------------------------------

    #[tokio::test]
    async fn global_limit_short_circuits_before_scoped() {
        // Global limited, plus scoped exception limited
        let limiter = build_limiter("tok", true, &[QuotaResource::Exceptions]).await;
        let mut events = vec![
            make_event("$pageview", None),
            make_event("$exception", None),
        ];

        let result = apply_quota_limits(&limiter, "tok", &mut events).await;
        assert!(result.is_err());

        // Global short-circuits without marking — scoped limiters never run
        for ev in &events {
            assert_eq!(ev.result, EventResult::Ok);
            assert_eq!(ev.details, None);
        }
    }

    // -----------------------------------------------------------------------
    // Pre-existing non-Ok events + post-check
    // -----------------------------------------------------------------------

    #[tokio::test]
    async fn pre_existing_drop_events_counted_in_post_check() {
        // No global limit, but exceptions limited
        let limiter = build_limiter("tok", false, &[QuotaResource::Exceptions]).await;
        let pv = make_event("$pageview", None);
        let pv_uuid = pv.uuid;
        let mut events = vec![make_event("$exception", None), pv];
        // Pre-mark pageview as Drop from a prior validation step
        let pv_ev = events.iter_mut().find(|e| e.uuid == pv_uuid).unwrap();
        pv_ev.result = EventResult::Drop;
        pv_ev.destination = Destination::Drop;

        let result = apply_quota_limits(&limiter, "tok", &mut events).await;
        // $exception → Drop (quota), $pageview → already Drop → all non-Ok → error
        assert!(result.is_err());
    }

    #[tokio::test]
    async fn mixed_pre_existing_and_scoped_still_ok_if_some_remain() {
        let limiter = build_limiter("tok", false, &[QuotaResource::Exceptions]).await;
        let pv = make_event("$pageview", None);
        let pv_uuid = pv.uuid;
        let mut events = vec![
            make_event("$exception", None),
            pv,
            make_event("click", None),
        ];
        events
            .iter_mut()
            .find(|e| e.uuid == pv_uuid)
            .unwrap()
            .result = EventResult::Drop;

        let result = apply_quota_limits(&limiter, "tok", &mut events).await;
        // "click" still Ok, so should return Ok
        assert!(result.is_ok());
        assert_eq!(ok_event_names(&events), vec!["click"]);
    }

    // -----------------------------------------------------------------------
    // Empty batch
    // -----------------------------------------------------------------------

    #[tokio::test]
    async fn empty_batch_returns_ok_when_global_limited() {
        let limiter = build_limiter("tok", true, &[]).await;
        let mut events: Vec<WrappedEvent> = Vec::new();

        let result = apply_quota_limits(&limiter, "tok", &mut events).await;
        assert!(result.is_ok());
    }

    #[tokio::test]
    async fn empty_batch_returns_ok_when_not_limited() {
        let limiter = build_limiter("tok", false, &[]).await;
        let mut events: Vec<WrappedEvent> = Vec::new();

        let result = apply_quota_limits(&limiter, "tok", &mut events).await;
        assert!(result.is_ok());
    }
}
