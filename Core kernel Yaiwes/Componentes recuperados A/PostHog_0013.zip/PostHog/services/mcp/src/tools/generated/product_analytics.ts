// AUTO-GENERATED from products/product_analytics/mcp/tools.yaml + OpenAPI — do not edit
import { z } from 'zod'

import type { Schemas } from '@/api/generated'
import {
    ElementsStatsRetrieveQueryParams,
    InsightsActivityRetrieveParams,
    InsightsActivityRetrieveQueryParams,
    InsightsAllActivityRetrieveQueryParams,
    InsightsCreateBody,
    InsightsDestroyParams,
    InsightsListQueryParams,
    InsightsPartialUpdateBody,
    InsightsPartialUpdateParams,
    InsightsRetrieveParams,
    InsightsRetrieveQueryParams,
    InsightsTrendingRetrieveQueryParams,
} from '@/generated/product_analytics/api'
import { castStringToInt, normalizeParamAliases } from '@/tools/cast-helpers'
import {
    withPostHogUrl,
    withAgentNote,
    omitResponseFields,
    pickResponseFields,
    type WithPostHogUrl,
    type WithAgentNote,
} from '@/tools/tool-utils'
import type { Context, ToolBase, ZodObjectAny } from '@/tools/types'

const AssistantInsightVizNode = z.object({
    kind: z.literal('InsightVizNode').default('InsightVizNode'),
    source: z
        .record(z.string(), z.unknown())
        .describe(
            'Product analtycs query objects like TrendsQuery, FunnelsQuery, RetentionQuery, PathsQuery, StickinessQuery, LifecycleQuery'
        ),
})

const AssistantDataVisualizationBoxPlotSettings = z.object({
    excludeOutliers: z.coerce
        .boolean()
        .describe('Clip whiskers to 1.5 times the interquartile range. Defaults to true.')
        .optional(),
    maxColumn: z.string().describe('Numeric column containing the maximum for each box.'),
    meanColumn: z.string().describe('Numeric column containing the mean for each box.'),
    medianColumn: z.string().describe('Numeric column containing the median for each box.'),
    minColumn: z.string().describe('Numeric column containing the minimum for each box.'),
    p25Column: z.string().describe('Numeric column containing the 25th percentile for each box.'),
    p75Column: z.string().describe('Numeric column containing the 75th percentile for each box.'),
    seriesColumn: z
        .string()
        .nullable()
        .describe(
            'Optional column that groups each X-axis value into separate colored series. Set to `null` for one series.'
        )
        .optional(),
    xAxisColumn: z
        .string()
        .nullable()
        .describe('X-axis category column. Set to `null` for one overall distribution or one box per series.')
        .optional(),
})

const AssistantDataVisualizationGoalLine = z.object({
    label: z.string().describe('Label rendered next to the goal line.'),
    value: z.coerce.number().describe('Y-axis value at which the goal line is drawn.'),
})

const AssistantDataVisualizationYAxisSettings = z.object({
    label: z.string().describe('Label rendered beside this Y axis.').optional(),
    scale: z.enum(['linear', 'logarithmic']).describe('Scale used for this Y axis.').optional(),
    showGridLines: z.coerce.boolean().describe('Show grid lines for this Y axis.').optional(),
    showTicks: z.coerce.boolean().describe('Show tick labels on this Y axis.').optional(),
    startAtZero: z.coerce.boolean().describe('Whether this Y axis should start at zero.').optional(),
})

const AssistantDataVisualizationAxisDisplaySettings = z.object({
    color: z.string().describe('Custom color for this series as a hex string (e.g. `#1d4aff`).').optional(),
    displayType: z
        .enum(['auto', 'line', 'bar', 'area'])
        .describe(
            'Override how this individual series is rendered, independent of the chart-level `display` type. Use this to mix series types — e.g. plot one series as `bar` and overlay another as `line`. `auto` follows the chart-level display type.'
        )
        .optional(),
    label: z
        .string()
        .describe('Custom label for this series, shown in the legend and tooltips instead of the column name.')
        .optional(),
    trendLine: z.coerce
        .boolean()
        .describe('Draw a linear trend line for this series. Only meaningful for line, bar, and area charts.')
        .optional(),
    yAxisPosition: z
        .enum(['left', 'right'])
        .describe('Which Y axis this numeric series should use. Use `right` for a secondary Y axis.')
        .optional(),
})

const AssistantDataVisualizationAxisFormatting = z.object({
    decimalPlaces: z.coerce.number().describe('Number of decimal places to display.').optional(),
    prefix: z.string().describe('Text prepended to each value (e.g. `$`).').optional(),
    style: z
        .enum(['none', 'number', 'short', 'percent'])
        .describe(
            'Number formatting style.\n- `none` — no formatting.\n- `number` — thousands separators (e.g. `1,234`).\n- `short` — abbreviated large numbers (e.g. `1.2k`, `3.4M`).\n- `percent` — multiply the value by 100 and append a `%` sign, so pass a 0-1 ratio (`a / b`, not `100.0 * a / b`). Never pair it with a `%` suffix, which renders `47.3%%`.'
        )
        .optional(),
    suffix: z
        .string()
        .describe(
            'Text appended to each value (e.g. ` ms`). Leave unset when `style` is `percent`, which already appends the `%` sign.'
        )
        .optional(),
})

const AssistantDataVisualizationAxisSettings = z.object({
    display: AssistantDataVisualizationAxisDisplaySettings.describe(
        'Display settings for a plotted Y series.'
    ).optional(),
    formatting: AssistantDataVisualizationAxisFormatting.describe(
        'Number-formatting settings for the values on this axis or series.'
    ).optional(),
})

const AssistantDataVisualizationAxis = z.object({
    column: z.string().describe('Name of a column returned by the SQL query to map onto this axis.'),
    settings: AssistantDataVisualizationAxisSettings.describe(
        'Optional series settings. Only applies to Y-axis series.'
    ).optional(),
})

const AssistantDataVisualizationChartSettings = z.object({
    boxPlot: AssistantDataVisualizationBoxPlotSettings.describe(
        'Column mappings for `BoxPlot`. The SQL must return one pre-aggregated row per X-axis and series pair.'
    ).optional(),
    goalLines: z
        .array(AssistantDataVisualizationGoalLine)
        .describe('Horizontal goal lines drawn across the chart.')
        .optional(),
    leftYAxisSettings: AssistantDataVisualizationYAxisSettings.describe('Settings for the left Y axis.').optional(),
    rightYAxisSettings: AssistantDataVisualizationYAxisSettings.describe(
        'Settings for the right Y axis. Only applies when a Y series uses `settings.display.yAxisPosition: "right"`.'
    ).optional(),
    seriesBreakdownColumn: z
        .string()
        .nullable()
        .describe(
            'Column that splits a single Y series into multiple colored series — e.g. breaking down a line chart by `country`. Set to `null` or omit to disable. A breakdown buckets rows by x value, so it is ignored when `display` is `ScatterPlot`.'
        )
        .optional(),
    showLegend: z.coerce.boolean().describe('Show the chart legend.').optional(),
    showNullsAsZero: z.coerce.boolean().describe('Replace null aggregation results with zero.').optional(),
    showTotalRow: z.coerce
        .boolean()
        .describe('Show a total summing all Y series. Applies to line, bar, and area charts.')
        .optional(),
    showValuesOnSeries: z.coerce
        .boolean()
        .describe("Render each data point's value as a label directly on the series.")
        .optional(),
    stackBars100: z.coerce
        .boolean()
        .describe('Stack bars to 100% of the total. Only meaningful with `ActionsStackedBar`.')
        .optional(),
    xAxis: AssistantDataVisualizationAxis.describe(
        'Column used as the X axis. Typically a time bucket or categorical column, but `ScatterPlot` plots two measures against each other, so it needs a numeric column here too.'
    ).optional(),
    xAxisLabel: z.string().describe('Label rendered under the X axis.').optional(),
    yAxis: z
        .array(AssistantDataVisualizationAxis)
        .describe('One or more numeric columns plotted as Y series.')
        .optional(),
})

const AssistantDataVisualizationDisplayType = z.enum([
    'ActionsTable',
    'BoldNumber',
    'ActionsLineGraph',
    'ActionsBar',
    'ActionsPie',
    'ActionsStackedBar',
    'ActionsAreaGraph',
    'TwoDimensionalHeatmap',
    'ScatterPlot',
    'BoxPlot',
])

const AssistantDataVisualizationTableSettings = z.object({
    columns: z
        .array(AssistantDataVisualizationAxis)
        .describe('Columns to display and their order. Omit to show every column returned by the query.')
        .optional(),
    pinnedColumns: z.array(z.string()).describe('Column names to pin to the left of the table.').optional(),
    transpose: z.coerce.boolean().describe('Transpose rows and columns.').optional(),
})

const AssistantDataVisualizationNode = z.object({
    chartSettings: AssistantDataVisualizationChartSettings.describe(
        'Chart configuration. Ignored when `display` is `ActionsTable` or `BoldNumber`.'
    ).optional(),
    display: AssistantDataVisualizationDisplayType.describe(
        'Visualization type. Defaults to `ActionsTable` when omitted.\n\nGuidance:\n- Single-value result (one numeric column, one row) → `BoldNumber`.\n- Time series → `ActionsLineGraph` or `ActionsAreaGraph`.\n- Categorical proportions → `ActionsPie`.\n- Categorical comparison → `ActionsBar` or `ActionsStackedBar`.\n- Two-dimensional aggregation → `TwoDimensionalHeatmap`.\n- Relationship between two numeric measures, one point per row → `ScatterPlot`.\n- Distribution summaries from pre-aggregated SQL rows → `BoxPlot` with `chartSettings.boxPlot`.\n- Otherwise → `ActionsTable`.'
    ).optional(),
    kind: z.literal('DataVisualizationNode').default('DataVisualizationNode'),
    source: z.record(z.string(), z.unknown()).describe('HogQL query object that produces the rows to visualize.'),
    tableSettings: AssistantDataVisualizationTableSettings.describe(
        'Table configuration. Only applies when `display` is `ActionsTable` or omitted.'
    ).optional(),
})

const InsightQuery = z.union([AssistantInsightVizNode, AssistantDataVisualizationNode])

const ElementsStatsRetrieveSchema = ElementsStatsRetrieveQueryParams

const elementsStatsRetrieve = (): ToolBase<typeof ElementsStatsRetrieveSchema, Schemas.ElementStatsResponse> => ({
    name: 'elements-stats-retrieve',
    schema: ElementsStatsRetrieveSchema,
    handler: async (context: Context, params: z.infer<typeof ElementsStatsRetrieveSchema>) => {
        const projectId = await context.stateManager.getProjectId()
        const result = await context.api.request<Schemas.ElementStatsResponse>({
            method: 'GET',
            path: `/api/projects/${encodeURIComponent(String(projectId))}/elements/stats/`,
            query: {
                data_attributes: params.data_attributes,
                date_from: params.date_from,
                date_to: params.date_to,
                filter_test_accounts: params.filter_test_accounts,
                include: params.include,
                limit: params.limit,
                offset: params.offset,
                properties: params.properties,
                sampling_factor: params.sampling_factor,
            },
        })
        return result
    },
})

const InsightCreateSchema = InsightsCreateBody.omit({
    derived_name: true,
    order: true,
    deleted: true,
    _create_in_folder: true,
}).extend({
    query: InsightQuery,
    dashboards: InsightsCreateBody.shape['dashboards'].describe(
        'Dashboard IDs this insight should belong to. This is a full replacement — always include all existing dashboard IDs when adding a new one.'
    ),
    description: InsightsCreateBody.shape['description'].describe(
        'Human-readable summary of what the insight shows. Max 400 characters (longer values are rejected).'
    ),
})

const insightCreate = (): ToolBase<typeof InsightCreateSchema, WithPostHogUrl<Schemas.Insight>> => ({
    name: 'insight-create',
    schema: InsightCreateSchema,
    handler: async (context: Context, params: z.infer<typeof InsightCreateSchema>) => {
        const projectId = await context.stateManager.getProjectId()
        const body: Record<string, unknown> = {}
        if (params.name !== undefined) {
            body['name'] = params.name
        }
        if (params.dashboards !== undefined) {
            body['dashboards'] = params.dashboards
        }
        if (params.description !== undefined) {
            body['description'] = params.description
        }
        if (params.tags !== undefined) {
            body['tags'] = params.tags
        }
        if (params.favorited !== undefined) {
            body['favorited'] = params.favorited
        }
        if (params.query !== undefined) {
            body['query'] = params.query
        }
        const result = await context.api.request<Schemas.Insight>({
            method: 'POST',
            path: `/api/projects/${encodeURIComponent(String(projectId))}/insights/`,
            body,
        })
        const filtered = omitResponseFields(result, [
            'result',
            'hasMore',
            'columns',
            'is_cached',
            'query_status',
            'hogql',
            'types',
        ]) as typeof result
        return await withPostHogUrl(context, filtered, `/insights/${filtered.short_id}`)
    },
})

const InsightDeleteSchema = z.preprocess(
    normalizeParamAliases({ id: ['insightId', 'insight_id', 'short_id', 'shortId'] }),
    InsightsDestroyParams.omit({ project_id: true })
)

const insightDelete = (): ToolBase<typeof InsightDeleteSchema, Schemas.Insight> => ({
    name: 'insight-delete',
    schema: InsightDeleteSchema,
    handler: async (context: Context, params: z.infer<typeof InsightDeleteSchema>) => {
        const projectId = await context.stateManager.getProjectId()
        const result = await context.api.request<Schemas.Insight>({
            method: 'PATCH',
            path: `/api/projects/${encodeURIComponent(String(projectId))}/insights/${encodeURIComponent(String(params.id))}/`,
            body: { deleted: true },
        })
        return result
    },
})

const InsightGetSchema = z.preprocess(
    normalizeParamAliases({ id: ['insightId', 'insight_id', 'short_id', 'shortId'] }),
    InsightsRetrieveParams.omit({ project_id: true })
        .extend(InsightsRetrieveQueryParams.omit({ format: true, from_dashboard: true, refresh: true }).shape)
        .extend({
            filters_override: z
                .union([z.string(), z.record(z.string(), z.unknown())])
                .optional()
                .describe(
                    "Object (or pre-encoded JSON string) to override the insight's filters for this request only (not persisted). Top-level keys replace; nested values are not deep-merged — pass the complete value for any key you override. Accepts the same keys as the dashboard filters schema (e.g., `date_from`, `date_to`, `properties`). Ignored when accessed via a sharing token."
                ),
            variables_override: z
                .union([z.string(), z.record(z.string(), z.unknown())])
                .optional()
                .describe(
                    'Object (or pre-encoded JSON string) to override the insight\'s HogQL variables for this request only (not persisted). Format: {"<variable_id>": {"code_name": "<code_name>", "variableId": "<variable_id>", "value": <new_value>}}. Each entry must include `code_name` — partial entries are silently dropped. The simplest workflow is to call `insight-get` first, copy the matching entry from the response, and mutate `value`. Top-level keys replace; nested values are not deep-merged. Ignored when accessed via a sharing token.'
                ),
        })
)

const insightGet = (): ToolBase<typeof InsightGetSchema, WithPostHogUrl<Schemas.Insight>> => ({
    name: 'insight-get',
    schema: InsightGetSchema,
    handler: async (context: Context, params: z.infer<typeof InsightGetSchema>) => {
        const projectId = await context.stateManager.getProjectId()
        const result = await context.api.request<Schemas.Insight>({
            method: 'GET',
            path: `/api/projects/${encodeURIComponent(String(projectId))}/insights/${encodeURIComponent(String(params.id))}/`,
            query: {
                filters_override: params.filters_override,
                include_dashboards: params.include_dashboards,
                variables_override: params.variables_override,
            },
        })
        const filtered = omitResponseFields(result, [
            'result',
            'hasMore',
            'columns',
            'is_cached',
            'query_status',
            'hogql',
            'types',
        ]) as typeof result
        return await withPostHogUrl(context, filtered, `/insights/${filtered.short_id}`)
    },
})

const InsightUpdateSchema = z.preprocess(
    normalizeParamAliases({ id: ['insightId', 'insight_id', 'short_id', 'shortId'] }),
    InsightsPartialUpdateParams.omit({ project_id: true })
        .extend(
            InsightsPartialUpdateBody.omit({ derived_name: true, order: true, deleted: true, _create_in_folder: true })
                .shape
        )
        .extend({
            query: InsightQuery.optional(),
            dashboards: InsightsPartialUpdateBody.shape['dashboards'].describe(
                'Dashboard IDs this insight should belong to. This is a full replacement — always include all existing dashboard IDs when adding a new one.'
            ),
            description: InsightsPartialUpdateBody.shape['description'].describe(
                'Human-readable summary of what the insight shows. Max 400 characters (longer values are rejected).'
            ),
        })
)

const insightUpdate = (): ToolBase<typeof InsightUpdateSchema, WithAgentNote<WithPostHogUrl<Schemas.Insight>>> => ({
    name: 'insight-update',
    schema: InsightUpdateSchema,
    handler: async (context: Context, params: z.infer<typeof InsightUpdateSchema>) => {
        const projectId = await context.stateManager.getProjectId()
        const body: Record<string, unknown> = {}
        if (params.name !== undefined) {
            body['name'] = params.name
        }
        if (params.dashboards !== undefined) {
            body['dashboards'] = params.dashboards
        }
        if (params.description !== undefined) {
            body['description'] = params.description
        }
        if (params.tags !== undefined) {
            body['tags'] = params.tags
        }
        if (params.favorited !== undefined) {
            body['favorited'] = params.favorited
        }
        if (params.query !== undefined) {
            body['query'] = params.query
        }
        const result = await context.api.request<Schemas.Insight>({
            method: 'PATCH',
            path: `/api/projects/${encodeURIComponent(String(projectId))}/insights/${encodeURIComponent(String(params.id))}/`,
            body,
        })
        const filtered = omitResponseFields(result, [
            'result',
            'hasMore',
            'columns',
            'is_cached',
            'query_status',
            'hogql',
            'types',
        ]) as typeof result
        return withAgentNote(
            await withPostHogUrl(context, filtered, `/insights/${filtered.short_id}`),
            "If this update added the insight to a dashboard through the `dashboards` field, consider offering the user a recurring delivery of that dashboard as a next step. `dashboards` is a full replacement, so only offer when the dashboard id you just added was not already on the insight before this call. Offer at most once per dashboard in a conversation, however many insights you attach to it. First call subscriptions-list with `dashboard` set to that dashboard's id, and do not offer a second subscription when it returns one. Say nothing when this update left `dashboards` alone or only removed the insight from a dashboard. Describe it the way a person would recognize it, for example a weekly email every Monday morning with these charts attached, or the same thing posted to a Slack channel. To create it, use subscriptions-create. It needs `dashboard` set to the dashboard's id, `dashboard_export_insights` listing up to 10 charts, `target_type` of `email` or `slack`, and `target_value`, `frequency`, `interval` and `start_date`. For a Slack delivery, also set `integration_id`. Find the connected Slack workspace with integrations-list (filter kind=slack) and the channel for `target_value` with integrations-channels-retrieve. Ask the user for the recipients and the cadence rather than choosing them, since this creates a recurring outbound delivery. If either subscriptions-create or subscriptions-list is not available to you in this session, say nothing about subscriptions. If the user already declined a subscription earlier in this conversation, do not offer again."
        )
    },
})

const InsightsActivityRetrieveSchema = InsightsActivityRetrieveParams.omit({ project_id: true }).extend(
    InsightsActivityRetrieveQueryParams.omit({ format: true }).shape
)

const insightsActivityRetrieve = (): ToolBase<
    typeof InsightsActivityRetrieveSchema,
    WithPostHogUrl<Schemas.ActivityLogPaginatedResponse>
> => ({
    name: 'insights-activity-retrieve',
    schema: InsightsActivityRetrieveSchema,
    handler: async (context: Context, params: z.infer<typeof InsightsActivityRetrieveSchema>) => {
        const projectId = await context.stateManager.getProjectId()
        const result = await context.api.request<Schemas.ActivityLogPaginatedResponse>({
            method: 'GET',
            path: `/api/projects/${encodeURIComponent(String(projectId))}/insights/${encodeURIComponent(String(params.id))}/activity/`,
            query: {
                limit: params.limit,
                page: params.page,
            },
        })
        const filtered = {
            ...result,
            results: (result.results ?? []).map((item: any) =>
                omitResponseFields(item, [
                    'detail.changes.*.before',
                    'detail.changes.*.after',
                    'detail.trigger',
                    'detail.type',
                ])
            ),
        } as typeof result
        return await withPostHogUrl(context, filtered, '/insights')
    },
})

const InsightsAllActivityRetrieveSchema = InsightsAllActivityRetrieveQueryParams.omit({ format: true })

const insightsAllActivityRetrieve = (): ToolBase<
    typeof InsightsAllActivityRetrieveSchema,
    WithPostHogUrl<Schemas.ActivityLogPaginatedResponse>
> => ({
    name: 'insights-all-activity-retrieve',
    schema: InsightsAllActivityRetrieveSchema,
    handler: async (context: Context, params: z.infer<typeof InsightsAllActivityRetrieveSchema>) => {
        const projectId = await context.stateManager.getProjectId()
        const result = await context.api.request<Schemas.ActivityLogPaginatedResponse>({
            method: 'GET',
            path: `/api/projects/${encodeURIComponent(String(projectId))}/insights/activity/`,
            query: {
                limit: params.limit,
                page: params.page,
            },
        })
        const filtered = {
            ...result,
            results: (result.results ?? []).map((item: any) =>
                omitResponseFields(item, [
                    'detail.changes.*.before',
                    'detail.changes.*.after',
                    'detail.trigger',
                    'detail.type',
                ])
            ),
        } as typeof result
        return await withPostHogUrl(context, filtered, '/insights')
    },
})

const InsightsListSchema = InsightsListQueryParams.omit({ format: true, basic: true, refresh: true }).extend({
    limit: z.preprocess(castStringToInt, InsightsListQueryParams.shape['limit']).optional(),
    offset: z.preprocess(castStringToInt, InsightsListQueryParams.shape['offset']).optional(),
})

const insightsList = (): ToolBase<typeof InsightsListSchema, WithPostHogUrl<Schemas.PaginatedInsightList>> => ({
    name: 'insights-list',
    schema: InsightsListSchema,
    handler: async (context: Context, params: z.infer<typeof InsightsListSchema>) => {
        const projectId = await context.stateManager.getProjectId()
        const result = await context.api.request<Schemas.PaginatedInsightList>({
            method: 'GET',
            path: `/api/projects/${encodeURIComponent(String(projectId))}/insights/`,
            query: {
                created_by: params.created_by,
                created_date_from: params.created_date_from,
                created_date_to: params.created_date_to,
                dashboards: params.dashboards,
                date_from: params.date_from,
                date_to: params.date_to,
                favorited: params.favorited,
                include_dashboards: params.include_dashboards,
                insight: params.insight,
                last_viewed_date_from: params.last_viewed_date_from,
                last_viewed_date_to: params.last_viewed_date_to,
                limit: params.limit,
                offset: params.offset,
                saved: params.saved,
                search: params.search,
                short_id: params.short_id,
                tags: params.tags,
                user: params.user,
            },
        })
        const filtered = {
            ...result,
            results: (result.results ?? []).map((item: any) =>
                pickResponseFields(item, [
                    'id',
                    'short_id',
                    'name',
                    'derived_name',
                    'description',
                    'tags',
                    'favorited',
                    'dashboards',
                    'created_at',
                    'created_by',
                    'last_modified_at',
                    'last_modified_by',
                    'last_viewed_at',
                    'alerts',
                ])
            ),
        } as typeof result
        return await withPostHogUrl(
            context,
            {
                ...filtered,
                results: await Promise.all(
                    (filtered.results ?? []).map((item) => withPostHogUrl(context, item, `/insights/${item.short_id}`))
                ),
            },
            '/insights'
        )
    },
})

const InsightsTrendingRetrieveSchema = InsightsTrendingRetrieveQueryParams.omit({ format: true })

const insightsTrendingRetrieve = (): ToolBase<
    typeof InsightsTrendingRetrieveSchema,
    WithPostHogUrl<Schemas.PaginatedTrendingInsightList>
> => ({
    name: 'insights-trending-retrieve',
    schema: InsightsTrendingRetrieveSchema,
    handler: async (context: Context, params: z.infer<typeof InsightsTrendingRetrieveSchema>) => {
        const projectId = await context.stateManager.getProjectId()
        const result = await context.api.request<Schemas.PaginatedTrendingInsightList>({
            method: 'GET',
            path: `/api/projects/${encodeURIComponent(String(projectId))}/insights/trending/`,
            query: {
                days: params.days,
                include_dashboards: params.include_dashboards,
                limit: params.limit,
                offset: params.offset,
            },
        })
        const filtered = {
            ...result,
            results: (result.results ?? []).map((item: any) =>
                pickResponseFields(item, [
                    'id',
                    'short_id',
                    'name',
                    'derived_name',
                    'description',
                    'tags',
                    'favorited',
                    'dashboards',
                    'created_at',
                    'created_by',
                    'last_modified_at',
                    'last_modified_by',
                    'last_viewed_at',
                    'view_count',
                    'viewers',
                ])
            ),
        } as typeof result
        return await withPostHogUrl(
            context,
            {
                ...filtered,
                results: await Promise.all(
                    (filtered.results ?? []).map((item) => withPostHogUrl(context, item, `/insights/${item.short_id}`))
                ),
            },
            '/insights'
        )
    },
})

export const GENERATED_TOOLS: Record<string, () => ToolBase<ZodObjectAny>> = {
    'elements-stats-retrieve': elementsStatsRetrieve,
    'insight-create': insightCreate,
    'insight-delete': insightDelete,
    'insight-get': insightGet,
    'insight-update': insightUpdate,
    'insights-activity-retrieve': insightsActivityRetrieve,
    'insights-all-activity-retrieve': insightsAllActivityRetrieve,
    'insights-list': insightsList,
    'insights-trending-retrieve': insightsTrendingRetrieve,
}
