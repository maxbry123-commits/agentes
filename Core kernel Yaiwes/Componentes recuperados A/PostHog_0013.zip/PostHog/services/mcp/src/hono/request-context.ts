import { ApiClient } from '@/api/client'
import { MCP_ANALYTICS_SOURCE, MCP_SERVER_NAME, MCP_SERVER_VERSION } from '@/lib/constants'
import { wrapError } from '@/lib/errors'
import { getPostHogClient } from '@/lib/posthog'
import {
    AnalyticsEvent,
    buildMCPAnalyticsGroups,
    buildMCPContextProperties,
    type MCPAnalyticsContext,
} from '@/lib/posthog/analytics'
import type { RequestProperties } from '@/lib/request-properties'
import { SessionManager } from '@/lib/SessionManager'
import { StateManager } from '@/lib/StateManager'
import { hash } from '@/lib/utils'
import type { Context, Env, State } from '@/tools/types'

import { RedisCache, type RedisLike } from './cache/RedisCache'
import { getCustomApiBaseUrl, getPublicBaseUrl } from './constants'
import {
    buildMCPRequestContext,
    buildMCPSessionAnalyticsProperties,
    type MCPRequestContext,
    type MCPSessionContext,
} from './mcp-context'

export class RequestContext {
    private tokenCacheInstance: RedisCache<State> | undefined
    private userCacheInstance: RedisCache<State> | undefined
    private apiInstance: ApiClient | undefined
    private sessionManagerInstance: SessionManager | undefined
    private distinctIdPromise: Promise<string> | undefined
    private readonly redis: RedisLike
    private readonly env: Env
    private readonly props: RequestProperties
    private requestContext: MCPRequestContext
    private sessionContext: MCPSessionContext | null = null

    constructor(
        redis: RedisLike,
        env: Env,
        props: RequestProperties,
        requestContext: MCPRequestContext = buildMCPRequestContext(props)
    ) {
        this.redis = redis
        this.env = env
        this.props = props
        this.requestContext = requestContext
    }

    get tokenCache(): RedisCache<State> {
        if (!this.props.userHash) {
            throw new Error('User hash is required to use the token cache')
        }
        if (!this.tokenCacheInstance) {
            this.tokenCacheInstance = new RedisCache<State>(this.props.userHash, this.redis, 'token')
        }
        return this.tokenCacheInstance
    }

    getUserCache(distinctId: string): RedisCache<State> {
        if (!this.userCacheInstance) {
            this.userCacheInstance = new RedisCache<State>(hash(distinctId), this.redis, 'user')
        }
        return this.userCacheInstance
    }

    get cache(): RedisCache<State> {
        return this.tokenCache
    }

    private async readCachedOAuthClientName(): Promise<string | undefined> {
        if (!this.props.userHash) {
            return undefined
        }
        return (await this.tokenCache.get('clientName')) || undefined
    }

    private async api(): Promise<ApiClient> {
        if (!this.apiInstance) {
            const customApiBaseUrl = getCustomApiBaseUrl()
            let baseUrl: string
            if (customApiBaseUrl) {
                baseUrl = customApiBaseUrl
            } else if (process.env.NODE_ENV === 'production') {
                throw new Error(
                    'POSTHOG_API_BASE_URL must be set in production — Hono deployments are regional and do not auto-detect.'
                )
            } else {
                baseUrl = 'http://localhost:8010'
            }
            this.apiInstance = new ApiClient({
                apiToken: this.props.apiToken,
                baseUrl,
                publicBaseUrl: getPublicBaseUrl(),
                clientUserAgent: this.props.clientUserAgent,
                mcpClientName: this.props.mcpClientName,
                mcpClientVersion: this.props.mcpClientVersion,
                mcpProtocolVersion: this.props.mcpProtocolVersion,
                mcpConsumer: this.props.mcpConsumer,
                // Cached from a previous request's token introspection. On a cold cache this is
                // still unset here, so `StateManager` also stamps it onto the live client's config
                // the moment introspection resolves it — otherwise a token's first request would
                // reach the API unattributed.
                oauthClientName: await this.readCachedOAuthClientName(),
                taskId: this.props.taskId,
            })
        }
        return this.apiInstance
    }

    get sessionManager(): SessionManager {
        if (!this.sessionManagerInstance) {
            this.sessionManagerInstance = new SessionManager(this.tokenCache)
        }
        return this.sessionManagerInstance
    }

    async getSessionUuid(sessionId: string | undefined): Promise<string | undefined> {
        if (!sessionId) {
            return undefined
        }
        return this.sessionManager.getSessionUuid(sessionId)
    }

    /**
     * Resolves the UUID emitted as `$session_id`. Prefers the explicit
     * `?sessionId=` param and falls back to the MCP protocol session id, so
     * sessions are still attributed for clients that don't pass an explicit
     * session id. Without the fallback `$session_id` is absent on most events
     * and the MCP analytics dashboard — which aggregates sessions on
     * `$session_id` — counts zero.
     */
    async getEffectiveSessionUuid(requestContext: MCPRequestContext): Promise<string | undefined> {
        return this.getSessionUuid(requestContext.sessionId ?? requestContext.mcpSessionId)
    }

    getDistinctId(): Promise<string> {
        if (!this.distinctIdPromise) {
            this.distinctIdPromise = this.resolveDistinctId()
        }
        return this.distinctIdPromise
    }

    private async resolveDistinctId(): Promise<string> {
        const cached = await this.tokenCache.get('distinctId')
        if (cached) {
            return cached
        }
        const userResult = await (await this.api()).users().me()
        if (!userResult.success) {
            throw wrapError(`Failed to get user: ${userResult.error.message}`, userResult.error)
        }
        const distinctId = userResult.data.distinct_id as string
        await this.tokenCache.set('distinctId', distinctId)
        return distinctId
    }

    async getContext(): Promise<Context> {
        const api = await this.api()
        const stateManager = new StateManager(this.tokenCache, api)
        const partialContext: Omit<Context, 'trackEvent'> = {
            api,
            cache: this.tokenCache,
            env: this.env,
            stateManager,
            sessionManager: this.sessionManager,
            getDistinctId: () => this.getDistinctId(),
        }
        const trackEvent: Context['trackEvent'] = async (event, properties = {}) => {
            const analyticsContext = await this.safelyGetAnalyticsContext(partialContext)
            const distinctId = await this.getDistinctId()
            await this.trackEvent(event, properties, analyticsContext, undefined, distinctId)
        }
        return { ...partialContext, trackEvent }
    }

    setMcpContexts(requestContext: MCPRequestContext, sessionContext: MCPSessionContext | null): void {
        this.requestContext = requestContext
        this.sessionContext = sessionContext
    }

    async safelyGetAnalyticsContext(context: Pick<Context, 'stateManager'>): Promise<MCPAnalyticsContext | undefined> {
        try {
            return await context.stateManager.getAnalyticsContext()
        } catch {
            return undefined
        }
    }

    async trackContextSwitchEvent(
        toolName: string,
        context: Context,
        previousContext: MCPAnalyticsContext | undefined
    ): Promise<void> {
        const resolvedContext = await this.safelyGetAnalyticsContext(context)
        if (!resolvedContext) {
            return
        }

        const event =
            toolName === 'switch-project'
                ? AnalyticsEvent.MCP_PROJECT_SWITCHED
                : toolName === 'switch-organization'
                  ? AnalyticsEvent.MCP_ORGANIZATION_SWITCHED
                  : undefined
        if (!event) {
            return
        }

        const distinctId = await this.getDistinctId()
        await this.trackEvent(event, {}, resolvedContext, previousContext, distinctId)
    }

    buildClientProperties(
        requestContext: MCPRequestContext = this.requestContext,
        sessionContext: MCPSessionContext | null = this.sessionContext
    ): Record<string, unknown> {
        return {
            $ai_product: 'mcp',
            $mcp_source: MCP_ANALYTICS_SOURCE,
            $mcp_server_name: MCP_SERVER_NAME,
            $mcp_server_version: MCP_SERVER_VERSION,
            $mcp_client_name: requestContext.mcpClientName,
            $mcp_client_version: requestContext.mcpClientVersion,
            $mcp_client_user_agent: requestContext.clientUserAgent,
            $mcp_protocol_version: requestContext.mcpProtocolVersion,
            $mcp_transport: requestContext.transport,
            $mcp_session_id: requestContext.mcpSessionId,
            $mcp_conversation_id: requestContext.mcpConversationId,
            $mcp_consumer: requestContext.mcpConsumer,
            $mcp_mode: requestContext.mode,
            $mcp_region: requestContext.region,
            mcp_runtime: 'hono',
            mcp_vendor_client: requestContext.mcpVendorClient,
            ...buildMCPSessionAnalyticsProperties(sessionContext),
        }
    }

    async trackEvent(
        event: AnalyticsEvent,
        properties: Record<string, unknown>,
        analyticsContext?: MCPAnalyticsContext,
        previousContext?: MCPAnalyticsContext,
        distinctId?: string
    ): Promise<void> {
        try {
            const resolvedDistinctId = distinctId ?? (await this.getDistinctId())
            const clientName = await this.tokenCache.get('clientName')
            const sessionUuid = await this.getEffectiveSessionUuid(this.requestContext)
            const contextProperties = analyticsContext ? buildMCPContextProperties(analyticsContext) : {}
            const previousContextProperties = previousContext
                ? buildMCPContextProperties(previousContext, { prefix: 'previous_' })
                : {}
            const groups = analyticsContext ? buildMCPAnalyticsGroups(analyticsContext) : {}

            getPostHogClient().capture({
                distinctId: resolvedDistinctId,
                event,
                ...(Object.keys(groups).length > 0 ? { groups } : {}),
                properties: {
                    ...this.buildClientProperties(),
                    ...(sessionUuid ? { $session_id: sessionUuid } : {}),
                    ...(clientName ? { $mcp_oauth_client_name: clientName } : {}),
                    ...contextProperties,
                    ...previousContextProperties,
                    ...properties,
                },
            })
        } catch {
            // skip
        }
    }
}
