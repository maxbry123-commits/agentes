import { RESOURCE_URI_META_KEY } from '@modelcontextprotocol/ext-apps/server'
import type { Tool as McpTool } from '@modelcontextprotocol/sdk/types.js'

import type { QueryToolInfo } from '@/lib/instructions'
import { type InstructionsContext, InstructionsFormatter } from '@/lib/instructions-formatter'
import { formatPrompt } from '@/lib/utils'
import { RENDER_UI_RESOURCE_URI } from '@/resources/ui-apps.generated'
import EXECUTE_SQL_PROMPT from '@/templates/execute-sql-prompt.md'
import CATALOG_TRUST_DISCOVERY from '@/templates/sections/catalog-trust-discovery.md'
import METRIC_DISCOVERY from '@/templates/sections/metric-discovery.md'
import SCHEMA_DISCOVERY from '@/templates/sections/schema-discovery.md'
import { ExecHelpCatalog } from '@/tools/exec-help'
import {
    getRenderableToolNames,
    makeRenderUiSchema,
    RENDER_UI_TOOL_DESCRIPTION,
    RENDER_UI_TOOL_NAME,
    RENDER_UI_TOOL_TITLE,
} from '@/tools/render-ui'
import { getToolDefinition } from '@/tools/toolDefinitions'

import type { ResolvedState } from './request-state-resolver'
import { toMcpInputSchema } from './tool-catalog'

/** Presence of this tool is the runtime signal that the notebook cell surface
 *  (the `revamped-py-notebooks` flag) is live for this client. */
const NOTEBOOK_ADD_CELL_TOOL = 'notebooks-add-cell'

export class InstructionsBuilder {
    private readonly formatter: InstructionsFormatter
    private readonly guidelines: string

    constructor(guidelines: string, formatter?: InstructionsFormatter) {
        this.guidelines = guidelines
        this.formatter = formatter ?? new InstructionsFormatter()
    }

    build(state: ResolvedState): string {
        const supportsInstructions = state.clientProfile.capabilities.supportsInstructions
        if (!supportsInstructions) {
            return ''
        }

        const ctx = this.buildContext(state)
        if (state.useSingleExec) {
            return this.formatter.buildExecInstructions(ctx)
        }
        return this.formatter.buildToolsInstructions(ctx)
    }

    buildContext(state: ResolvedState): InstructionsContext {
        return {
            guidelines: this.guidelines,
            tools: state.allTools.map((t) => ({
                name: t.name,
                category: getToolDefinition(t.name).category,
            })),
            queryTools: state.allTools
                .filter((t) => t.name.startsWith('query-'))
                .map((t) => {
                    const def = getToolDefinition(t.name)
                    return {
                        name: t.name,
                        title: def.title,
                        ...(def.system_prompt_hint ? { systemPromptHint: def.system_prompt_hint } : {}),
                    } as QueryToolInfo
                }),
            renderUiEnabled: state.renderUiEnabled,
            metadata: state.metadata,
            metadataCompact: state.metadataCompact,
            groupTypes: state.groupTypes,
            notebookCellsEnabled: state.allTools.some((tool) => tool.name === NOTEBOOK_ADD_CELL_TOOL),
        }
    }

    buildExecToolEntry(state: ResolvedState): McpTool {
        const commandReference = this.buildExecCommandReference(state)
        const ExecSchema = { command: { type: 'string', description: commandReference } }

        return {
            name: 'exec',
            title: 'Execute PostHog command',
            description: this.formatter.buildExecToolDescription(),
            inputSchema: { type: 'object', properties: ExecSchema, required: ['command'] },
        }
    }

    buildRenderUiToolEntry(state: ResolvedState): McpTool | null {
        const toolNames = getRenderableToolNames(state.allTools)
        if (toolNames.length === 0) {
            return null
        }
        return {
            name: RENDER_UI_TOOL_NAME,
            title: RENDER_UI_TOOL_TITLE,
            description: RENDER_UI_TOOL_DESCRIPTION,
            // Derived from the same zod schema the executor validates with, so the
            // advertised contract (enum, descriptions, required) cannot drift from it.
            inputSchema: toMcpInputSchema(makeRenderUiSchema(toolNames as [string, ...string[]])),
            // Advertise the umbrella UI resource so MCP Apps hosts (e.g. Claude) discover
            // render-ui as renderable from `tools/list` and mount its iframe. Both the
            // modern and legacy keys are emitted since this entry isn't normalized downstream.
            _meta: {
                ui: { resourceUri: RENDER_UI_RESOURCE_URI },
                [RESOURCE_URI_META_KEY]: RENDER_UI_RESOURCE_URI,
            },
        }
    }

    buildExecCommandReference(state: ResolvedState): string {
        const supportsInstructions = state.clientProfile.capabilities.supportsInstructions
        // Claude web/desktop report `supportsInstructions` but never surface the
        // `instructions` payload to the model, so its env-context (tool domains,
        // project metadata, group types) would be lost. Those chat hosts get their
        // own smaller-budget reference. (Codex, which reports
        // `supportsInstructions: false`, gets the full env-context via the
        // un-stripped path.)
        const ctx = this.buildContext(state)
        if (state.clientProfile.isClaudeChatHost()) {
            return this.formatter.buildClaudeExecCommandReference(ctx)
        }
        return this.formatter.buildExecCommandReference(ctx, {
            stripEnvContext: supportsInstructions,
            // Env-context rides here even for clients that honor `instructions`: that
            // payload is capped at MCP_INSTRUCTIONS_CHAR_BUDGET and is spent entirely
            // on the tool-domain index, which is the part that can't be recovered by
            // any later tool call. This description has no such cap.
            keepEnvContext: true,
        })
    }

    buildExecHelpCatalog(state: ResolvedState): ExecHelpCatalog | undefined {
        if (!state.clientProfile.isClaudeChatHost()) {
            return undefined
        }
        return new ExecHelpCatalog(this.formatter.buildClaudeExecHelpEntries(this.buildContext(state)))
    }

    buildExecToolDescription(): string {
        return this.formatter.buildExecToolDescription()
    }

    getGuidelines(): string {
        return this.guidelines
    }

    formatExecuteSqlDescription(): string {
        // Metric discovery leads the splice so catalog-first routing still precedes
        // raw schema discovery, without displacing the tool's own intro line.
        const schemaDiscovery = `${METRIC_DISCOVERY.trim()}\n\n${SCHEMA_DISCOVERY.trim()}\n\n${CATALOG_TRUST_DISCOVERY.trim()}`
        return formatPrompt(EXECUTE_SQL_PROMPT, {
            guidelines: this.guidelines.trim(),
            schema_discovery: schemaDiscovery,
        })
    }
}
