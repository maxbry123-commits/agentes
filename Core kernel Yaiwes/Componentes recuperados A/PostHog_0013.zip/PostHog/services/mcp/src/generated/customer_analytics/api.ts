/**
 * Auto-generated from the Django backend OpenAPI schema.
 * MCP service uses these Zod schemas for generated tool handlers.
 * To regenerate: hogli build:openapi
 *
 * PostHog API - MCP 65 enabled ops
 * OpenAPI spec version: 1.0.0
 */
import * as zod from 'zod'

export const AccountRelationshipDefinitionsListParams = /* @__PURE__ */ zod.object({
    project_id: zod
        .string()
        .describe(
            "Project ID of the project you're trying to access. To find the ID of the project, make a call to \/api\/projects\/."
        ),
})

export const AccountRelationshipDefinitionsListQueryParams = /* @__PURE__ */ zod.object({
    limit: zod.number().optional().describe('Number of results to return per page.'),
    offset: zod.number().optional().describe('The initial index from which to return the results.'),
})

export const AccountRelationshipDefinitionsCreateParams = /* @__PURE__ */ zod.object({
    project_id: zod
        .string()
        .describe(
            "Project ID of the project you're trying to access. To find the ID of the project, make a call to \/api\/projects\/."
        ),
})

export const accountRelationshipDefinitionsCreateBodyNameMax = 400

export const accountRelationshipDefinitionsCreateBodyIsSingleHolderDefault = true

export const AccountRelationshipDefinitionsCreateBody = /* @__PURE__ */ zod
    .object({
        name: zod
            .string()
            .max(accountRelationshipDefinitionsCreateBodyNameMax)
            .describe('Human-readable name of the relationship. Unique within the team.'),
        description: zod
            .string()
            .nullish()
            .describe(
                "What this relationship means, e.g. 'The customer success manager responsible for this account'."
            ),
        is_single_holder: zod
            .boolean()
            .default(accountRelationshipDefinitionsCreateBodyIsSingleHolderDefault)
            .describe(
                'Whether only one user can hold this relationship per account at a time, e.g. a single CSM per account.'
            ),
    })
    .describe('A team-defined account relationship type (CSM, Onboarding manager, ...).')

export const AccountRelationshipDefinitionsRetrieveParams = /* @__PURE__ */ zod.object({
    id: zod.string(),
    project_id: zod
        .string()
        .describe(
            "Project ID of the project you're trying to access. To find the ID of the project, make a call to \/api\/projects\/."
        ),
})

export const AccountRelationshipDefinitionsPartialUpdateParams = /* @__PURE__ */ zod.object({
    id: zod.string(),
    project_id: zod
        .string()
        .describe(
            "Project ID of the project you're trying to access. To find the ID of the project, make a call to \/api\/projects\/."
        ),
})

export const accountRelationshipDefinitionsPartialUpdateBodyNameMax = 400

export const AccountRelationshipDefinitionsPartialUpdateBody = /* @__PURE__ */ zod
    .object({
        name: zod
            .string()
            .max(accountRelationshipDefinitionsPartialUpdateBodyNameMax)
            .optional()
            .describe('Human-readable name of the relationship. Unique within the team.'),
        description: zod
            .string()
            .nullish()
            .describe(
                "What this relationship means, e.g. 'The customer success manager responsible for this account'."
            ),
        is_single_holder: zod
            .boolean()
            .optional()
            .describe(
                'Whether only one user can hold this relationship per account at a time, e.g. a single CSM per account.'
            ),
    })
    .describe('A team-defined account relationship type (CSM, Onboarding manager, ...).')

export const AccountRelationshipDefinitionsDestroyParams = /* @__PURE__ */ zod.object({
    id: zod.string(),
    project_id: zod
        .string()
        .describe(
            "Project ID of the project you're trying to access. To find the ID of the project, make a call to \/api\/projects\/."
        ),
})

export const AccountsListParams = /* @__PURE__ */ zod.object({
    project_id: zod
        .string()
        .describe(
            "Project ID of the project you're trying to access. To find the ID of the project, make a call to \/api\/projects\/."
        ),
})

export const accountsListQueryIncludeChurnedDefault = false
export const accountsListQueryIncludeIgnoredDefault = false

export const AccountsListQueryParams = /* @__PURE__ */ zod.object({
    all_roles_unassigned: zod
        .boolean()
        .optional()
        .describe('When true, returns only accounts where no user actively holds any relationship.'),
    include_churned: zod
        .boolean()
        .default(accountsListQueryIncludeChurnedDefault)
        .describe('Include churned accounts. Churned accounts are hidden by default.'),
    include_ignored: zod
        .boolean()
        .default(accountsListQueryIncludeIgnoredDefault)
        .describe('Include ignored accounts. Ignored accounts are hidden by default.'),
    limit: zod.number().optional().describe('Number of results to return per page.'),
    offset: zod.number().optional().describe('The initial index from which to return the results.'),
    ordering: zod.string().optional().describe("Sort order. Defaults to '-created_at'."),
    search: zod.string().optional().describe('Case-insensitive substring search across account name and external ID.'),
    tags: zod
        .string()
        .optional()
        .describe(
            'JSON-encoded array of tag names to filter by, e.g. `[\"enterprise\",\"priority\"]`. Returns accounts that have any of the listed tags. Malformed values (not a JSON-encoded list of strings) return a 400.'
        ),
})

export const AccountsCreateParams = /* @__PURE__ */ zod.object({
    project_id: zod
        .string()
        .describe(
            "Project ID of the project you're trying to access. To find the ID of the project, make a call to \/api\/projects\/."
        ),
})

export const accountsCreateBodyNameMax = 400

export const accountsCreateBodyExternalIdMax = 400

export const AccountsCreateBody = /* @__PURE__ */ zod
    .object({
        name: zod.string().max(accountsCreateBodyNameMax).describe('Human-readable name of the account.'),
        external_id: zod
            .string()
            .max(accountsCreateBodyExternalIdMax)
            .nullish()
            .describe(
                "Identifier linking this account to its source customer — the analytics group key (the customer's organization id), used to match billing and external records. Optional."
            ),
        properties: zod
            .object({
                website_domain: zod
                    .string()
                    .nullish()
                    .describe('Primary company website hostname used for account identity and logo lookup.'),
                email_domains: zod
                    .array(zod.string())
                    .optional()
                    .describe(
                        "Email domains owned by this account's company, used to match inbound touchpoints to the account."
                    ),
                known_emails: zod
                    .array(zod.string())
                    .optional()
                    .describe('Individual email addresses pinned to this account, matched before the domain fallback.'),
                stripe_customer_id: zod.string().nullish(),
                hubspot_deal_id: zod.string().nullish(),
                billing_id: zod.string().nullish(),
                sfdc_id: zod.string().nullish(),
                zendesk_id: zod.string().nullish(),
                slack_channel_id: zod.string().nullish(),
                usage_dashboard_link: zod.string().nullish(),
                metabase_link: zod.string().nullish(),
            })
            .nullish()
            .describe(
                "Typed account properties: website_domain, external system identifiers (stripe_customer_id, hubspot_deal_id, billing_id, sfdc_id, zendesk_id, slack_channel_id, usage_dashboard_link, metabase_link), and touchpoint matching lists: email_domains (the company's email domains) and known_emails (individual addresses pinned to the account). Defaults to an empty object. Unknown keys are rejected. User assignments live on account relationships, not here."
            ),
        tags: zod
            .array(zod.string())
            .optional()
            .describe('Tag names attached to the account. Pass a list to replace existing tags.'),
        slack_summary_cadence: zod
            .union([
                zod
                    .enum(['daily', 'weekly', 'monthly'])
                    .describe('\* `daily` - daily\n\* `weekly` - weekly\n\* `monthly` - monthly'),
                zod.null(),
            ])
            .optional()
            .describe(
                "How often to generate an AI summary of the account's bound Slack channel (daily, weekly, or monthly). Null means summaries are off.\n\n\* `daily` - daily\n\* `weekly` - weekly\n\* `monthly` - monthly"
            ),
        churned_at: zod.iso
            .datetime({ offset: true })
            .nullish()
            .describe('When the account churned. Null means the account has not churned.'),
    })
    .describe('A Customer Analytics account — a logical grouping used to assign customer-success ownership.')

export const AccountsCustomPropertyValuesListParams = /* @__PURE__ */ zod.object({
    account_id: zod.string().describe('UUID of the parent account.'),
    project_id: zod
        .string()
        .describe(
            "Project ID of the project you're trying to access. To find the ID of the project, make a call to \/api\/projects\/."
        ),
})

export const AccountsCustomPropertyValuesCreateParams = /* @__PURE__ */ zod.object({
    account_id: zod.string().describe('UUID of the parent account.'),
    project_id: zod
        .string()
        .describe(
            "Project ID of the project you're trying to access. To find the ID of the project, make a call to \/api\/projects\/."
        ),
})

export const AccountsCustomPropertyValuesCreateBody = /* @__PURE__ */ zod.object({
    definition: zod.string().describe('UUID of the custom property definition whose value to set for this account.'),
    value: zod
        .union([zod.string(), zod.number(), zod.boolean()])
        .describe(
            "Value to store, matching the definition's type: a number for number\/currency\/percent, a boolean for boolean, an ISO-8601 string for date\/datetime, an HTTP or HTTPS URL for link properties, or text for text properties."
        ),
})

export const AccountsNotebooksListParams = /* @__PURE__ */ zod.object({
    account_id: zod.string().describe('UUID of the parent account.'),
    project_id: zod
        .string()
        .describe(
            "Project ID of the project you're trying to access. To find the ID of the project, make a call to \/api\/projects\/."
        ),
})

export const AccountsNotebooksListQueryParams = /* @__PURE__ */ zod.object({
    limit: zod.number().optional().describe('Number of results to return per page.'),
    offset: zod.number().optional().describe('The initial index from which to return the results.'),
    ordering: zod.string().optional().describe("Sort by creation date or author. Defaults to '-created_at'."),
    search: zod.string().optional().describe('Full-text search across notebook title and content.'),
})

export const AccountsNotebooksCreateParams = /* @__PURE__ */ zod.object({
    account_id: zod.string().describe('UUID of the parent account.'),
    project_id: zod
        .string()
        .describe(
            "Project ID of the project you're trying to access. To find the ID of the project, make a call to \/api\/projects\/."
        ),
})

export const accountsNotebooksCreateBodyTitleMax = 256

export const AccountsNotebooksCreateBody = /* @__PURE__ */ zod.object({
    title: zod
        .string()
        .max(accountsNotebooksCreateBodyTitleMax)
        .nullish()
        .describe('Human-readable title of the account notebook.'),
    content: zod.unknown().optional().describe('Notebook content as a ProseMirror JSON document structure.'),
    text_content: zod.string().nullish().describe('Plain text representation of the notebook content for search.'),
})

export const AccountsNotebooksRetrieveParams = /* @__PURE__ */ zod.object({
    account_id: zod.string().describe('UUID of the parent account.'),
    project_id: zod
        .string()
        .describe(
            "Project ID of the project you're trying to access. To find the ID of the project, make a call to \/api\/projects\/."
        ),
    short_id: zod.string(),
})

export const AccountsNotebooksDestroyParams = /* @__PURE__ */ zod.object({
    account_id: zod.string().describe('UUID of the parent account.'),
    project_id: zod
        .string()
        .describe(
            "Project ID of the project you're trying to access. To find the ID of the project, make a call to \/api\/projects\/."
        ),
    short_id: zod.string(),
})

export const AccountsRelationshipsListParams = /* @__PURE__ */ zod.object({
    account_id: zod.string().describe('UUID of the parent account.'),
    project_id: zod
        .string()
        .describe(
            "Project ID of the project you're trying to access. To find the ID of the project, make a call to \/api\/projects\/."
        ),
})

export const AccountsRelationshipsListQueryParams = /* @__PURE__ */ zod.object({
    include_history: zod
        .boolean()
        .optional()
        .describe('Include ended assignments (the full timeline), not just active ones.'),
})

export const AccountsRelationshipsCreateParams = /* @__PURE__ */ zod.object({
    account_id: zod.string().describe('UUID of the parent account.'),
    project_id: zod
        .string()
        .describe(
            "Project ID of the project you're trying to access. To find the ID of the project, make a call to \/api\/projects\/."
        ),
})

export const AccountsRelationshipsCreateBody = /* @__PURE__ */ zod
    .object({
        definition: zod.string().describe('Id of the relationship definition to assign.'),
        user: zod.number().describe("PostHog user id of the assignee. Must be a member of the account's organization."),
    })
    .describe('Input for assigning a user to an account relationship.')

export const AccountsRelationshipsEndCreateParams = /* @__PURE__ */ zod.object({
    account_id: zod.string().describe('UUID of the parent account.'),
    id: zod.string(),
    project_id: zod
        .string()
        .describe(
            "Project ID of the project you're trying to access. To find the ID of the project, make a call to \/api\/projects\/."
        ),
})

export const AccountsRetrieveParams = /* @__PURE__ */ zod.object({
    id: zod.string().describe('A UUID string identifying this account.'),
    project_id: zod
        .string()
        .describe(
            "Project ID of the project you're trying to access. To find the ID of the project, make a call to \/api\/projects\/."
        ),
})

export const AccountsPartialUpdateParams = /* @__PURE__ */ zod.object({
    id: zod.string().describe('A UUID string identifying this account.'),
    project_id: zod
        .string()
        .describe(
            "Project ID of the project you're trying to access. To find the ID of the project, make a call to \/api\/projects\/."
        ),
})

export const accountsPartialUpdateBodyNameMax = 400

export const accountsPartialUpdateBodyExternalIdMax = 400

export const AccountsPartialUpdateBody = /* @__PURE__ */ zod
    .object({
        name: zod
            .string()
            .max(accountsPartialUpdateBodyNameMax)
            .optional()
            .describe('Human-readable name of the account.'),
        external_id: zod
            .string()
            .max(accountsPartialUpdateBodyExternalIdMax)
            .nullish()
            .describe(
                "Identifier linking this account to its source customer — the analytics group key (the customer's organization id), used to match billing and external records. Optional."
            ),
        properties: zod
            .object({
                website_domain: zod
                    .string()
                    .nullish()
                    .describe('Primary company website hostname used for account identity and logo lookup.'),
                email_domains: zod
                    .array(zod.string())
                    .optional()
                    .describe(
                        "Email domains owned by this account's company, used to match inbound touchpoints to the account."
                    ),
                known_emails: zod
                    .array(zod.string())
                    .optional()
                    .describe('Individual email addresses pinned to this account, matched before the domain fallback.'),
                stripe_customer_id: zod.string().nullish(),
                hubspot_deal_id: zod.string().nullish(),
                billing_id: zod.string().nullish(),
                sfdc_id: zod.string().nullish(),
                zendesk_id: zod.string().nullish(),
                slack_channel_id: zod.string().nullish(),
                usage_dashboard_link: zod.string().nullish(),
                metabase_link: zod.string().nullish(),
            })
            .nullish()
            .describe(
                "Typed account properties: website_domain, external system identifiers (stripe_customer_id, hubspot_deal_id, billing_id, sfdc_id, zendesk_id, slack_channel_id, usage_dashboard_link, metabase_link), and touchpoint matching lists: email_domains (the company's email domains) and known_emails (individual addresses pinned to the account). Defaults to an empty object. Unknown keys are rejected. User assignments live on account relationships, not here."
            ),
        tags: zod
            .array(zod.string())
            .optional()
            .describe('Tag names attached to the account. Pass a list to replace existing tags.'),
        slack_summary_cadence: zod
            .union([
                zod
                    .enum(['daily', 'weekly', 'monthly'])
                    .describe('\* `daily` - daily\n\* `weekly` - weekly\n\* `monthly` - monthly'),
                zod.null(),
            ])
            .optional()
            .describe(
                "How often to generate an AI summary of the account's bound Slack channel (daily, weekly, or monthly). Null means summaries are off.\n\n\* `daily` - daily\n\* `weekly` - weekly\n\* `monthly` - monthly"
            ),
        churned_at: zod.iso
            .datetime({ offset: true })
            .nullish()
            .describe('When the account churned. Null means the account has not churned.'),
    })
    .describe('A Customer Analytics account — a logical grouping used to assign customer-success ownership.')

export const AccountsDestroyParams = /* @__PURE__ */ zod.object({
    id: zod.string().describe('A UUID string identifying this account.'),
    project_id: zod
        .string()
        .describe(
            "Project ID of the project you're trying to access. To find the ID of the project, make a call to \/api\/projects\/."
        ),
})

export const AccountsMeetingsListParams = /* @__PURE__ */ zod.object({
    id: zod.string().describe('A UUID string identifying this account.'),
    project_id: zod
        .string()
        .describe(
            "Project ID of the project you're trying to access. To find the ID of the project, make a call to \/api\/projects\/."
        ),
})

export const AccountsMeetingsListQueryParams = /* @__PURE__ */ zod.object({
    limit: zod.number().optional().describe('Number of results to return per page.'),
    offset: zod.number().optional().describe('The initial index from which to return the results.'),
    search: zod.string().optional().describe('Filter meetings by title or attendee email\/name.'),
})

export const AccountsSummariesListParams = /* @__PURE__ */ zod.object({
    id: zod.string().describe('A UUID string identifying this account.'),
    project_id: zod
        .string()
        .describe(
            "Project ID of the project you're trying to access. To find the ID of the project, make a call to \/api\/projects\/."
        ),
})

export const AccountsSummariesListQueryParams = /* @__PURE__ */ zod.object({
    limit: zod.number().optional().describe('Number of results to return per page.'),
    offset: zod.number().optional().describe('The initial index from which to return the results.'),
})

export const AnnouncementsListParams = /* @__PURE__ */ zod.object({
    project_id: zod
        .string()
        .describe(
            "Project ID of the project you're trying to access. To find the ID of the project, make a call to \/api\/projects\/."
        ),
})

export const AnnouncementsListQueryParams = /* @__PURE__ */ zod.object({
    limit: zod.number().optional().describe('Number of results to return per page.'),
    offset: zod.number().optional().describe('The initial index from which to return the results.'),
})

export const AnnouncementsCreateParams = /* @__PURE__ */ zod.object({
    project_id: zod
        .string()
        .describe(
            "Project ID of the project you're trying to access. To find the ID of the project, make a call to \/api\/projects\/."
        ),
})

export const AnnouncementsCreateBody = /* @__PURE__ */ zod.object({
    message: zod.string().describe('Message body to send, rendered as Slack mrkdwn.'),
    channels: zod
        .array(zod.string())
        .describe(
            'Slack channel IDs to send to. Each must be a channel the SupportHog bot is a member of; names are resolved server-side.'
        ),
})

export const AnnouncementsRetrieveParams = /* @__PURE__ */ zod.object({
    project_id: zod
        .string()
        .describe(
            "Project ID of the project you're trying to access. To find the ID of the project, make a call to \/api\/projects\/."
        ),
    short_id: zod.string(),
})

/**
 * Slack channels the SupportHog bot can post to, labeled by customer account name.
 */
export const AnnouncementsChannelsListParams = /* @__PURE__ */ zod.object({
    project_id: zod
        .string()
        .describe(
            "Project ID of the project you're trying to access. To find the ID of the project, make a call to \/api\/projects\/."
        ),
})

export const CustomPropertyDefinitionsListParams = /* @__PURE__ */ zod.object({
    project_id: zod
        .string()
        .describe(
            "Project ID of the project you're trying to access. To find the ID of the project, make a call to \/api\/projects\/."
        ),
})

export const CustomPropertyDefinitionsListQueryParams = /* @__PURE__ */ zod.object({
    limit: zod.number().optional().describe('Number of results to return per page.'),
    offset: zod.number().optional().describe('The initial index from which to return the results.'),
})

export const CustomPropertyDefinitionsCreateParams = /* @__PURE__ */ zod.object({
    project_id: zod
        .string()
        .describe(
            "Project ID of the project you're trying to access. To find the ID of the project, make a call to \/api\/projects\/."
        ),
})

export const customPropertyDefinitionsCreateBodyNameMax = 400

export const customPropertyDefinitionsCreateBodyTargetTypeDefault = `account`
export const customPropertyDefinitionsCreateBodyGroupTypeIndexMin = 0
export const customPropertyDefinitionsCreateBodyGroupTypeIndexMax = 4

export const customPropertyDefinitionsCreateBodyIsBigNumberDefault = false
export const customPropertyDefinitionsCreateBodyOptionsItemLabelMax = 400

export const CustomPropertyDefinitionsCreateBody = /* @__PURE__ */ zod
    .object({
        name: zod
            .string()
            .max(customPropertyDefinitionsCreateBodyNameMax)
            .describe('Human-readable name of the custom property. Unique within the team.'),
        description: zod.string().nullish().describe('Optional description of what the property represents.'),
        display_type: zod
            .enum(['text', 'link', 'number', 'currency', 'percent', 'date', 'datetime', 'boolean', 'select'])
            .describe(
                '\* `text` - text\n\* `link` - link\n\* `number` - number\n\* `currency` - currency\n\* `percent` - percent\n\* `date` - date\n\* `datetime` - datetime\n\* `boolean` - boolean\n\* `select` - select'
            )
            .describe(
                "How the property is interpreted and rendered: 'text', 'link', 'number', 'currency', 'percent', 'date', 'datetime', 'boolean', or 'select'. Links require an HTTP or HTTPS URL.\n\n\* `text` - text\n\* `link` - link\n\* `number` - number\n\* `currency` - currency\n\* `percent` - percent\n\* `date` - date\n\* `datetime` - datetime\n\* `boolean` - boolean\n\* `select` - select"
            ),
        target_type: zod
            .enum(['account', 'person', 'group'])
            .describe('\* `account` - account\n\* `person` - person\n\* `group` - group')
            .default(customPropertyDefinitionsCreateBodyTargetTypeDefault)
            .describe(
                "What entity this property is attached to: 'account' (default), 'person', or 'group'. Person and group properties are populated from a warehouse schema and become usable like any other person\/group property (feature flags, cohorts, insights).\n\n\* `account` - account\n\* `person` - person\n\* `group` - group"
            ),
        group_type_index: zod
            .number()
            .min(customPropertyDefinitionsCreateBodyGroupTypeIndexMin)
            .max(customPropertyDefinitionsCreateBodyGroupTypeIndexMax)
            .nullish()
            .describe(
                "For 'group' targets only: which group type (0-4) the property attaches to. Required when target_type is 'group'; must be omitted otherwise. Create-only."
            ),
        is_big_number: zod
            .boolean()
            .default(customPropertyDefinitionsCreateBodyIsBigNumberDefault)
            .describe('Abbreviate large numbers (e.g. 10,000 → 10K). Only applies to numeric properties.'),
        options: zod
            .array(
                zod
                    .object({
                        id: zod
                            .string()
                            .nullish()
                            .describe(
                                'Server-assigned stable id of the option. Omit for new options; send it back unchanged when editing so renames and removals can be told apart.'
                            ),
                        label: zod
                            .string()
                            .max(customPropertyDefinitionsCreateBodyOptionsItemLabelMax)
                            .describe("Display label of the option. Stored as the account's value when picked."),
                        color: zod
                            .enum([
                                'preset-1',
                                'preset-2',
                                'preset-3',
                                'preset-4',
                                'preset-5',
                                'preset-6',
                                'preset-7',
                                'preset-8',
                                'preset-9',
                                'preset-10',
                            ])
                            .describe(
                                '\* `preset-1` - preset-1\n\* `preset-2` - preset-2\n\* `preset-3` - preset-3\n\* `preset-4` - preset-4\n\* `preset-5` - preset-5\n\* `preset-6` - preset-6\n\* `preset-7` - preset-7\n\* `preset-8` - preset-8\n\* `preset-9` - preset-9\n\* `preset-10` - preset-10'
                            )
                            .describe(
                                "Preset color token used to render the option ('preset-1' through 'preset-10').\n\n\* `preset-1` - preset-1\n\* `preset-2` - preset-2\n\* `preset-3` - preset-3\n\* `preset-4` - preset-4\n\* `preset-5` - preset-5\n\* `preset-6` - preset-6\n\* `preset-7` - preset-7\n\* `preset-8` - preset-8\n\* `preset-9` - preset-9\n\* `preset-10` - preset-10"
                            ),
                    })
                    .describe('An allowed value of a select custom property.')
            )
            .nullish()
            .describe(
                "For select properties: the allowed options. Required (non-empty) when display_type is 'select'; cleared server-side for other types."
            ),
    })
    .describe(
        "A team-scoped definition of a custom account property — the attribute side of the model.\n\nHolds only the property's shape (name, display type, big-number flag). Per-account values are\nstored separately, so this serializer never reads or writes account values."
    )

export const CustomPropertyDefinitionsRetrieveParams = /* @__PURE__ */ zod.object({
    id: zod.string(),
    project_id: zod
        .string()
        .describe(
            "Project ID of the project you're trying to access. To find the ID of the project, make a call to \/api\/projects\/."
        ),
})

export const CustomPropertyDefinitionsPartialUpdateParams = /* @__PURE__ */ zod.object({
    id: zod.string(),
    project_id: zod
        .string()
        .describe(
            "Project ID of the project you're trying to access. To find the ID of the project, make a call to \/api\/projects\/."
        ),
})

export const customPropertyDefinitionsPartialUpdateBodyNameMax = 400

export const customPropertyDefinitionsPartialUpdateBodyGroupTypeIndexMin = 0
export const customPropertyDefinitionsPartialUpdateBodyGroupTypeIndexMax = 4

export const customPropertyDefinitionsPartialUpdateBodyOptionsItemLabelMax = 400

export const CustomPropertyDefinitionsPartialUpdateBody = /* @__PURE__ */ zod
    .object({
        name: zod
            .string()
            .max(customPropertyDefinitionsPartialUpdateBodyNameMax)
            .optional()
            .describe('Human-readable name of the custom property. Unique within the team.'),
        description: zod.string().nullish().describe('Optional description of what the property represents.'),
        display_type: zod
            .enum(['text', 'link', 'number', 'currency', 'percent', 'date', 'datetime', 'boolean', 'select'])
            .describe(
                '\* `text` - text\n\* `link` - link\n\* `number` - number\n\* `currency` - currency\n\* `percent` - percent\n\* `date` - date\n\* `datetime` - datetime\n\* `boolean` - boolean\n\* `select` - select'
            )
            .optional()
            .describe(
                "How the property is interpreted and rendered: 'text', 'link', 'number', 'currency', 'percent', 'date', 'datetime', 'boolean', or 'select'. Links require an HTTP or HTTPS URL.\n\n\* `text` - text\n\* `link` - link\n\* `number` - number\n\* `currency` - currency\n\* `percent` - percent\n\* `date` - date\n\* `datetime` - datetime\n\* `boolean` - boolean\n\* `select` - select"
            ),
        target_type: zod
            .enum(['account', 'person', 'group'])
            .describe('\* `account` - account\n\* `person` - person\n\* `group` - group')
            .optional()
            .describe(
                "What entity this property is attached to: 'account' (default), 'person', or 'group'. Person and group properties are populated from a warehouse schema and become usable like any other person\/group property (feature flags, cohorts, insights).\n\n\* `account` - account\n\* `person` - person\n\* `group` - group"
            ),
        group_type_index: zod
            .number()
            .min(customPropertyDefinitionsPartialUpdateBodyGroupTypeIndexMin)
            .max(customPropertyDefinitionsPartialUpdateBodyGroupTypeIndexMax)
            .nullish()
            .describe(
                "For 'group' targets only: which group type (0-4) the property attaches to. Required when target_type is 'group'; must be omitted otherwise. Create-only."
            ),
        is_big_number: zod
            .boolean()
            .optional()
            .describe('Abbreviate large numbers (e.g. 10,000 → 10K). Only applies to numeric properties.'),
        options: zod
            .array(
                zod
                    .object({
                        id: zod
                            .string()
                            .nullish()
                            .describe(
                                'Server-assigned stable id of the option. Omit for new options; send it back unchanged when editing so renames and removals can be told apart.'
                            ),
                        label: zod
                            .string()
                            .max(customPropertyDefinitionsPartialUpdateBodyOptionsItemLabelMax)
                            .describe("Display label of the option. Stored as the account's value when picked."),
                        color: zod
                            .enum([
                                'preset-1',
                                'preset-2',
                                'preset-3',
                                'preset-4',
                                'preset-5',
                                'preset-6',
                                'preset-7',
                                'preset-8',
                                'preset-9',
                                'preset-10',
                            ])
                            .describe(
                                '\* `preset-1` - preset-1\n\* `preset-2` - preset-2\n\* `preset-3` - preset-3\n\* `preset-4` - preset-4\n\* `preset-5` - preset-5\n\* `preset-6` - preset-6\n\* `preset-7` - preset-7\n\* `preset-8` - preset-8\n\* `preset-9` - preset-9\n\* `preset-10` - preset-10'
                            )
                            .describe(
                                "Preset color token used to render the option ('preset-1' through 'preset-10').\n\n\* `preset-1` - preset-1\n\* `preset-2` - preset-2\n\* `preset-3` - preset-3\n\* `preset-4` - preset-4\n\* `preset-5` - preset-5\n\* `preset-6` - preset-6\n\* `preset-7` - preset-7\n\* `preset-8` - preset-8\n\* `preset-9` - preset-9\n\* `preset-10` - preset-10"
                            ),
                    })
                    .describe('An allowed value of a select custom property.')
            )
            .nullish()
            .describe(
                "For select properties: the allowed options. Required (non-empty) when display_type is 'select'; cleared server-side for other types."
            ),
    })
    .describe(
        "A team-scoped definition of a custom account property — the attribute side of the model.\n\nHolds only the property's shape (name, display type, big-number flag). Per-account values are\nstored separately, so this serializer never reads or writes account values."
    )

export const CustomPropertyDefinitionsDestroyParams = /* @__PURE__ */ zod.object({
    id: zod.string(),
    project_id: zod
        .string()
        .describe(
            "Project ID of the project you're trying to access. To find the ID of the project, make a call to \/api\/projects\/."
        ),
})

export const CustomPropertySourcesListParams = /* @__PURE__ */ zod.object({
    project_id: zod
        .string()
        .describe(
            "Project ID of the project you're trying to access. To find the ID of the project, make a call to \/api\/projects\/."
        ),
})

export const CustomPropertySourcesListQueryParams = /* @__PURE__ */ zod.object({
    limit: zod.number().optional().describe('Number of results to return per page.'),
    offset: zod.number().optional().describe('The initial index from which to return the results.'),
})

export const CustomPropertySourcesCreateParams = /* @__PURE__ */ zod.object({
    project_id: zod
        .string()
        .describe(
            "Project ID of the project you're trying to access. To find the ID of the project, make a call to \/api\/projects\/."
        ),
})

export const customPropertySourcesCreateBodySourceColumnMax = 400

export const customPropertySourcesCreateBodyKeyColumnMax = 400

export const customPropertySourcesCreateBodyIsEnabledDefault = true

export const CustomPropertySourcesCreateBody = /* @__PURE__ */ zod
    .object({
        definition: zod
            .string()
            .describe('UUID of the custom property definition this source feeds. One source per definition.'),
        saved_query: zod
            .string()
            .nullish()
            .describe(
                'UUID of the data-warehouse saved query to read from. Required for an account source. For a person or group source it must be a materialized view, and is one of the two binding options. Mutually exclusive with external_data_schema.'
            ),
        external_data_schema: zod
            .string()
            .nullish()
            .describe(
                'Person and group sources only: UUID of the warehouse schema (an imported table) to read from. Mutually exclusive with saved_query; a person or group source sets exactly one.'
            ),
        source_column: zod
            .string()
            .max(customPropertySourcesCreateBodySourceColumnMax)
            .nullish()
            .describe('Account sources only: column in the view whose value is written to the property.'),
        column_property_map: zod
            .unknown()
            .optional()
            .describe(
                'Person and group sources only: {warehouse_column: property_name} mapping the columns this source writes onto the person or group.'
            ),
        column_descriptions: zod
            .unknown()
            .optional()
            .describe(
                "Person and group sources only: {warehouse_column: description} giving each mapped column a human-facing description, seeded from the warehouse column's information_schema description. Optional per column. Create-only."
            ),
        key_column: zod
            .string()
            .max(customPropertySourcesCreateBodyKeyColumnMax)
            .describe(
                "Column whose value identifies the target: an account's external_id for account sources, the person's distinct_id for person sources, or the group key for group sources."
            ),
        is_enabled: zod
            .boolean()
            .default(customPropertySourcesCreateBodyIsEnabledDefault)
            .describe(
                'Whether the source syncs. Auto-disabled after repeated failures or a missing view; re-enabling resets the failure count.'
            ),
    })
    .describe(
        'Binds warehouse columns to a custom property definition. Account sources read a materialized\nview column and sync onto matching accounts; person and group sources read either an imported\nwarehouse table or a materialized view, and sync onto matching persons or groups on every\nwarehouse run of what they read.'
    )

export const CustomPropertySourcesRetrieveParams = /* @__PURE__ */ zod.object({
    id: zod.string(),
    project_id: zod
        .string()
        .describe(
            "Project ID of the project you're trying to access. To find the ID of the project, make a call to \/api\/projects\/."
        ),
})

export const CustomPropertySourcesPartialUpdateParams = /* @__PURE__ */ zod.object({
    id: zod.string(),
    project_id: zod
        .string()
        .describe(
            "Project ID of the project you're trying to access. To find the ID of the project, make a call to \/api\/projects\/."
        ),
})

export const customPropertySourcesPartialUpdateBodySourceColumnMax = 400

export const customPropertySourcesPartialUpdateBodyKeyColumnMax = 400

export const CustomPropertySourcesPartialUpdateBody = /* @__PURE__ */ zod
    .object({
        source_column: zod
            .string()
            .max(customPropertySourcesPartialUpdateBodySourceColumnMax)
            .optional()
            .describe('Column in the view whose value is written to the property.'),
        key_column: zod
            .string()
            .max(customPropertySourcesPartialUpdateBodyKeyColumnMax)
            .optional()
            .describe("Column in the view whose value matches an account's external_id."),
        is_enabled: zod
            .boolean()
            .optional()
            .describe('Whether the source syncs; re-enabling it resets the failure count.'),
    })
    .describe(
        "Writable fields for updating a source. ``definition`` and ``saved_query`` are create-only, so\nthey are intentionally absent — only these reach the facade's update."
    )

export const CustomPropertySourcesDestroyParams = /* @__PURE__ */ zod.object({
    id: zod.string(),
    project_id: zod
        .string()
        .describe(
            "Project ID of the project you're trying to access. To find the ID of the project, make a call to \/api\/projects\/."
        ),
})

/**
 * Person and group sources only: start a backfill that reads the whole warehouse table and
 * populates person or group properties for historical rows. Coalesces if one is already running
 * for the table.
 */
export const CustomPropertySourcesBackfillParams = /* @__PURE__ */ zod.object({
    id: zod.string(),
    project_id: zod
        .string()
        .describe(
            "Project ID of the project you're trying to access. To find the ID of the project, make a call to \/api\/projects\/."
        ),
})

/**
 * The source's sync history, newest first. Person and group runs require viewer access to
 * their warehouse source because the response includes row counts and sync errors.
 */
export const CustomPropertySourcesRunsListParams = /* @__PURE__ */ zod.object({
    id: zod.string(),
    project_id: zod
        .string()
        .describe(
            "Project ID of the project you're trying to access. To find the ID of the project, make a call to \/api\/projects\/."
        ),
})

export const CustomPropertySourcesRunsListQueryParams = /* @__PURE__ */ zod.object({
    limit: zod.number().optional().describe('Number of results to return per page.'),
    offset: zod.number().optional().describe('The initial index from which to return the results.'),
    search: zod
        .string()
        .optional()
        .describe('Match run IDs, workflow IDs, job IDs, statuses, segments, triggers, or errors.'),
})

/**
 * Person and group sources only: run what this source reads now — an import for a table
 * binding (a real, billable warehouse sync), a materialization for a view binding. The
 * incremental person/group-property update runs off that run.
 */
export const CustomPropertySourcesSyncParams = /* @__PURE__ */ zod.object({
    id: zod.string(),
    project_id: zod
        .string()
        .describe(
            "Project ID of the project you're trying to access. To find the ID of the project, make a call to \/api\/projects\/."
        ),
})

/**
 * The caller's event stream: a live feed of selected accounts' events posted to a
 * Slack channel of their choice. Per-user — each team member owns at most one stream, and
 * every endpoint is scoped to the caller's own. Delivery runs through a managed CDP
 * destination that is re-provisioned inside the same transaction as every write, so
 * config and delivery can't drift apart.
 */
export const EventStreamsListParams = /* @__PURE__ */ zod.object({
    project_id: zod
        .string()
        .describe(
            "Project ID of the project you're trying to access. To find the ID of the project, make a call to \/api\/projects\/."
        ),
})

/**
 * The caller's event stream: a live feed of selected accounts' events posted to a
 * Slack channel of their choice. Per-user — each team member owns at most one stream, and
 * every endpoint is scoped to the caller's own. Delivery runs through a managed CDP
 * destination that is re-provisioned inside the same transaction as every write, so
 * config and delivery can't drift apart.
 */
export const EventStreamsCreateParams = /* @__PURE__ */ zod.object({
    project_id: zod
        .string()
        .describe(
            "Project ID of the project you're trying to access. To find the ID of the project, make a call to \/api\/projects\/."
        ),
})

export const eventStreamsCreateBodyEnabledDefault = false
export const eventStreamsCreateBodyEventNamesItemMax = 400

export const eventStreamsCreateBodySlackChannelIdDefault = ``
export const eventStreamsCreateBodySlackChannelIdMax = 200

export const eventStreamsCreateBodySlackChannelNameDefault = ``
export const eventStreamsCreateBodySlackChannelNameMax = 200

export const EventStreamsCreateBody = /* @__PURE__ */ zod
    .object({
        enabled: zod
            .boolean()
            .default(eventStreamsCreateBodyEnabledDefault)
            .describe(
                'Whether the stream delivers to Slack. Delivery also requires at least one event, at least one member account with an external ID, and a Slack workspace + channel.'
            ),
        event_names: zod
            .array(zod.string().max(eventStreamsCreateBodyEventNamesItemMax))
            .optional()
            .describe('Names of the events to stream (matched exactly). Duplicates and blanks are dropped.'),
        slack_integration: zod
            .number()
            .nullish()
            .describe("ID of the team's Slack workspace integration to deliver through."),
        slack_channel_id: zod
            .string()
            .max(eventStreamsCreateBodySlackChannelIdMax)
            .default(eventStreamsCreateBodySlackChannelIdDefault)
            .describe('Slack channel ID to post to (e.g. C0123ABC).'),
        slack_channel_name: zod
            .string()
            .max(eventStreamsCreateBodySlackChannelNameMax)
            .default(eventStreamsCreateBodySlackChannelNameDefault)
            .describe('Display name of the Slack channel (e.g. #customer-events). Informational only.'),
    })
    .describe(
        "The caller's event stream — a live feed of selected accounts' events posted to a\nSlack channel of their choice. One stream per user per project."
    )

/**
 * The caller's event stream: a live feed of selected accounts' events posted to a
 * Slack channel of their choice. Per-user — each team member owns at most one stream, and
 * every endpoint is scoped to the caller's own. Delivery runs through a managed CDP
 * destination that is re-provisioned inside the same transaction as every write, so
 * config and delivery can't drift apart.
 */
export const EventStreamsPartialUpdateParams = /* @__PURE__ */ zod.object({
    id: zod.string().describe('A UUID string identifying this event stream.'),
    project_id: zod
        .string()
        .describe(
            "Project ID of the project you're trying to access. To find the ID of the project, make a call to \/api\/projects\/."
        ),
})

export const eventStreamsPartialUpdateBodyEventNamesItemMax = 400

export const eventStreamsPartialUpdateBodySlackChannelIdMax = 200

export const eventStreamsPartialUpdateBodySlackChannelNameMax = 200

export const EventStreamsPartialUpdateBody = /* @__PURE__ */ zod
    .object({
        enabled: zod
            .boolean()
            .optional()
            .describe(
                'Whether the stream delivers to Slack. Delivery also requires at least one event, at least one member account with an external ID, and a Slack workspace + channel.'
            ),
        event_names: zod
            .array(zod.string().max(eventStreamsPartialUpdateBodyEventNamesItemMax))
            .optional()
            .describe('Names of the events to stream (matched exactly). Duplicates and blanks are dropped.'),
        slack_integration: zod
            .number()
            .nullish()
            .describe("ID of the team's Slack workspace integration to deliver through."),
        slack_channel_id: zod
            .string()
            .max(eventStreamsPartialUpdateBodySlackChannelIdMax)
            .optional()
            .describe('Slack channel ID to post to (e.g. C0123ABC).'),
        slack_channel_name: zod
            .string()
            .max(eventStreamsPartialUpdateBodySlackChannelNameMax)
            .optional()
            .describe('Display name of the Slack channel (e.g. #customer-events). Informational only.'),
    })
    .describe(
        "The caller's event stream — a live feed of selected accounts' events posted to a\nSlack channel of their choice. One stream per user per project."
    )

/**
 * The caller's event stream: a live feed of selected accounts' events posted to a
 * Slack channel of their choice. Per-user — each team member owns at most one stream, and
 * every endpoint is scoped to the caller's own. Delivery runs through a managed CDP
 * destination that is re-provisioned inside the same transaction as every write, so
 * config and delivery can't drift apart.
 */
export const EventStreamsDestroyParams = /* @__PURE__ */ zod.object({
    id: zod.string().describe('A UUID string identifying this event stream.'),
    project_id: zod
        .string()
        .describe(
            "Project ID of the project you're trying to access. To find the ID of the project, make a call to \/api\/projects\/."
        ),
})

/**
 * The caller's event stream: a live feed of selected accounts' events posted to a
 * Slack channel of their choice. Per-user — each team member owns at most one stream, and
 * every endpoint is scoped to the caller's own. Delivery runs through a managed CDP
 * destination that is re-provisioned inside the same transaction as every write, so
 * config and delivery can't drift apart.
 */
export const EventStreamsAddAccountCreateParams = /* @__PURE__ */ zod.object({
    id: zod.string().describe('A UUID string identifying this event stream.'),
    project_id: zod
        .string()
        .describe(
            "Project ID of the project you're trying to access. To find the ID of the project, make a call to \/api\/projects\/."
        ),
})

export const EventStreamsAddAccountCreateBody = /* @__PURE__ */ zod
    .object({
        account_id: zod.string().describe('UUID of the account to add to or remove from the stream.'),
    })
    .describe('Request body for adding or removing an event-stream member account.')

/**
 * The caller's event stream: a live feed of selected accounts' events posted to a
 * Slack channel of their choice. Per-user — each team member owns at most one stream, and
 * every endpoint is scoped to the caller's own. Delivery runs through a managed CDP
 * destination that is re-provisioned inside the same transaction as every write, so
 * config and delivery can't drift apart.
 */
export const EventStreamsRemoveAccountCreateParams = /* @__PURE__ */ zod.object({
    id: zod.string().describe('A UUID string identifying this event stream.'),
    project_id: zod
        .string()
        .describe(
            "Project ID of the project you're trying to access. To find the ID of the project, make a call to \/api\/projects\/."
        ),
})

export const EventStreamsRemoveAccountCreateBody = /* @__PURE__ */ zod
    .object({
        account_id: zod.string().describe('UUID of the account to add to or remove from the stream.'),
    })
    .describe('Request body for adding or removing an event-stream member account.')

/**
 * The caller's event stream: a live feed of selected accounts' events posted to a
 * Slack channel of their choice. Per-user — each team member owns at most one stream, and
 * every endpoint is scoped to the caller's own. Delivery runs through a managed CDP
 * destination that is re-provisioned inside the same transaction as every write, so
 * config and delivery can't drift apart.
 */
export const EventStreamsSendTestMessageCreateParams = /* @__PURE__ */ zod.object({
    id: zod.string().describe('A UUID string identifying this event stream.'),
    project_id: zod
        .string()
        .describe(
            "Project ID of the project you're trying to access. To find the ID of the project, make a call to \/api\/projects\/."
        ),
})

export const FeatureRequestProductAreasListParams = /* @__PURE__ */ zod.object({
    project_id: zod
        .string()
        .describe(
            "Project ID of the project you're trying to access. To find the ID of the project, make a call to \/api\/projects\/."
        ),
})

export const featureRequestProductAreasListQueryIncludeInactiveDefault = false

export const FeatureRequestProductAreasListQueryParams = /* @__PURE__ */ zod.object({
    include_inactive: zod
        .boolean()
        .default(featureRequestProductAreasListQueryIncludeInactiveDefault)
        .describe('Include inactive product areas. Defaults to false.'),
})

export const FeatureRequestProductAreasCreateParams = /* @__PURE__ */ zod.object({
    project_id: zod
        .string()
        .describe(
            "Project ID of the project you're trying to access. To find the ID of the project, make a call to \/api\/projects\/."
        ),
})

export const featureRequestProductAreasCreateBodyNameMax = 200

export const featureRequestProductAreasCreateBodyDisplayOrderDefault = 0
export const featureRequestProductAreasCreateBodyDisplayOrderMin = 0

export const featureRequestProductAreasCreateBodyIsActiveDefault = true

export const FeatureRequestProductAreasCreateBody = /* @__PURE__ */ zod.object({
    name: zod.string().max(featureRequestProductAreasCreateBodyNameMax).describe('Team-maintained product area name.'),
    display_order: zod
        .number()
        .min(featureRequestProductAreasCreateBodyDisplayOrderMin)
        .default(featureRequestProductAreasCreateBodyDisplayOrderDefault)
        .describe('Position in product area selectors. Lower values appear first.'),
    is_active: zod
        .boolean()
        .default(featureRequestProductAreasCreateBodyIsActiveDefault)
        .describe('Whether editors can select this product area for new requests.'),
})

export const FeatureRequestProductAreasPartialUpdateParams = /* @__PURE__ */ zod.object({
    id: zod.string(),
    project_id: zod
        .string()
        .describe(
            "Project ID of the project you're trying to access. To find the ID of the project, make a call to \/api\/projects\/."
        ),
})

export const featureRequestProductAreasPartialUpdateBodyNameMax = 200

export const featureRequestProductAreasPartialUpdateBodyDisplayOrderMin = 0

export const FeatureRequestProductAreasPartialUpdateBody = /* @__PURE__ */ zod.object({
    name: zod
        .string()
        .max(featureRequestProductAreasPartialUpdateBodyNameMax)
        .optional()
        .describe('Team-maintained product area name.'),
    display_order: zod
        .number()
        .min(featureRequestProductAreasPartialUpdateBodyDisplayOrderMin)
        .optional()
        .describe('Position in product area selectors. Lower values appear first.'),
    is_active: zod.boolean().optional().describe('Whether editors can select this product area for new requests.'),
})

export const FeatureRequestsListParams = /* @__PURE__ */ zod.object({
    project_id: zod
        .string()
        .describe(
            "Project ID of the project you're trying to access. To find the ID of the project, make a call to \/api\/projects\/."
        ),
})

export const featureRequestsListQueryArchiveStateDefault = `active`
export const featureRequestsListQueryRequestOrderingDefault = `-updated_at`

export const FeatureRequestsListQueryParams = /* @__PURE__ */ zod.object({
    account_ids: zod
        .array(zod.string())
        .optional()
        .describe('Accessible account IDs to include. Multiple values use OR semantics.'),
    archive_state: zod
        .enum(['active', 'archived', 'all'])
        .default(featureRequestsListQueryArchiveStateDefault)
        .describe(
            'Whether to return active requests, archived requests, or all requests.\n\n\* `active` - Active\n\* `archived` - Archived\n\* `all` - All'
        ),
    created_by_ids: zod
        .array(zod.number().min(1))
        .optional()
        .describe('Creator user IDs to include. Multiple values use OR semantics.'),
    limit: zod.number().optional().describe('Number of results to return per page.'),
    offset: zod.number().optional().describe('The initial index from which to return the results.'),
    priorities: zod
        .array(
            zod
                .enum(['high', 'medium', 'low', 'none'])
                .describe('\* `high` - High\n\* `medium` - Medium\n\* `low` - Low\n\* `none` - No priority')
        )
        .optional()
        .describe('Priorities to include. Use none for requests without a priority.'),
    product_area_ids: zod
        .array(zod.string())
        .optional()
        .describe('Product area IDs to include. Multiple values use OR semantics.'),
    request_ordering: zod
        .string()
        .min(1)
        .default(featureRequestsListQueryRequestOrderingDefault)
        .describe(
            'Stable ordering for the result list.\n\n\* `-updated_at` - Last updated: newest\n\* `updated_at` - Last updated: oldest\n\* `-created_at` - Date created: newest\n\* `created_at` - Date created: oldest\n\* `-priority` - Priority: high to low\n\* `priority` - Priority: low to high\n\* `title` - Title: A to Z\n\* `-title` - Title: Z to A\n\* `account` - Accounts: A to Z\n\* `-account` - Accounts: Z to A\n\* `product_area` - Product areas: A to Z\n\* `-product_area` - Product areas: Z to A\n\* `status` - Status: A to Z\n\* `-status` - Status: Z to A\n\* `created_by` - Created by: A to Z\n\* `-created_by` - Created by: Z to A\n\* `evidence_count` - Evidence: low to high\n\* `-evidence_count` - Evidence: high to low'
        ),
    search: zod.string().optional().describe('Case-insensitive text to find in request titles and descriptions.'),
    statuses: zod
        .array(
            zod
                .enum(['requested', 'planned', 'completed', 'wont_fix', 'duplicate'])
                .describe(
                    "\* `requested` - Requested\n\* `planned` - Planned\n\* `completed` - Completed\n\* `wont_fix` - Won't fix\n\* `duplicate` - Duplicate"
                )
        )
        .optional()
        .describe('Lifecycle statuses to include. Multiple values use OR semantics.'),
})

export const FeatureRequestsCreateParams = /* @__PURE__ */ zod.object({
    project_id: zod
        .string()
        .describe(
            "Project ID of the project you're trying to access. To find the ID of the project, make a call to \/api\/projects\/."
        ),
})

export const featureRequestsCreateBodyTitleMax = 400

export const featureRequestsCreateBodyDescriptionDefault = ``
export const featureRequestsCreateBodyEvidenceOneSummaryDefault = ``
export const featureRequestsCreateBodyEvidenceOneCustomerQuoteDefault = ``
export const featureRequestsCreateBodyEvidenceOneEvidenceSourceMax = 200

export const featureRequestsCreateBodyEvidenceOneSourceUrlOneDefault = ``
export const featureRequestsCreateBodyEvidenceOneSourceUrlOneMax = 2000

export const featureRequestsCreateBodyEvidenceOneSourceUrlTwoMax = 0

export const FeatureRequestsCreateBody = /* @__PURE__ */ zod.object({
    title: zod.string().max(featureRequestsCreateBodyTitleMax).describe('Required customer-facing request title.'),
    description: zod
        .string()
        .default(featureRequestsCreateBodyDescriptionDefault)
        .describe('Optional customer-facing request description in Markdown.'),
    account_id: zod.string().describe('ID of the affected Customer Analytics account.'),
    product_area_ids: zod
        .array(zod.string())
        .describe('One or more active product area IDs. Duplicate IDs are ignored.'),
    idempotency_key: zod
        .string()
        .describe(
            'Client-generated key that makes retries return the original request instead of creating a duplicate.'
        ),
    evidence: zod
        .union([
            zod.object({
                summary: zod
                    .string()
                    .default(featureRequestsCreateBodyEvidenceOneSummaryDefault)
                    .describe("Internal summary of this account's request evidence."),
                customer_quote: zod
                    .string()
                    .default(featureRequestsCreateBodyEvidenceOneCustomerQuoteDefault)
                    .describe('Customer quote kept with this evidence item.'),
                evidence_source: zod
                    .string()
                    .max(featureRequestsCreateBodyEvidenceOneEvidenceSourceMax)
                    .describe('Free-form name of the source where this evidence was recorded.'),
                source_url: zod
                    .union([
                        zod
                            .url()
                            .max(featureRequestsCreateBodyEvidenceOneSourceUrlOneMax)
                            .default(featureRequestsCreateBodyEvidenceOneSourceUrlOneDefault),
                        zod.string().max(featureRequestsCreateBodyEvidenceOneSourceUrlTwoMax),
                    ])
                    .optional()
                    .describe('Optional HTTP or HTTPS link to the source.'),
                requested_on: zod.iso
                    .date()
                    .nullish()
                    .describe('Date the account made the request, or null when unknown.'),
                image_ids: zod
                    .array(zod.string())
                    .optional()
                    .describe('Uploaded image IDs from this project to attach in display order.'),
            }),
            zod.null(),
        ])
        .optional()
        .describe('Optional first evidence item to create for the selected account.'),
})

export const FeatureRequestsRetrieveParams = /* @__PURE__ */ zod.object({
    id: zod.string(),
    project_id: zod
        .string()
        .describe(
            "Project ID of the project you're trying to access. To find the ID of the project, make a call to \/api\/projects\/."
        ),
})

export const FeatureRequestsPartialUpdateParams = /* @__PURE__ */ zod.object({
    id: zod.string(),
    project_id: zod
        .string()
        .describe(
            "Project ID of the project you're trying to access. To find the ID of the project, make a call to \/api\/projects\/."
        ),
})

export const featureRequestsPartialUpdateBodyTitleMax = 400

export const FeatureRequestsPartialUpdateBody = /* @__PURE__ */ zod.object({
    expected_version: zod
        .number()
        .min(1)
        .optional()
        .describe('Request version loaded by the editor. Stale versions return 409 Conflict.'),
    title: zod
        .string()
        .max(featureRequestsPartialUpdateBodyTitleMax)
        .optional()
        .describe('Updated customer-facing request title.'),
    description: zod.string().optional().describe('Updated optional customer-facing request description in Markdown.'),
    account_id: zod.string().optional().describe('Deprecated single affected account ID. Use account_ids.'),
    account_ids: zod
        .array(zod.string())
        .optional()
        .describe('One or more affected account IDs. Removed accounts are unlinked without deleting their evidence.'),
    product_area_ids: zod
        .array(zod.string())
        .optional()
        .describe('One or more product area IDs. Existing inactive areas can remain linked.'),
    request_status: zod
        .enum(['requested', 'planned', 'completed', 'wont_fix', 'duplicate'])
        .describe(
            "\* `requested` - Requested\n\* `planned` - Planned\n\* `completed` - Completed\n\* `wont_fix` - Won't fix\n\* `duplicate` - Duplicate"
        )
        .optional()
        .describe(
            "Updated customer-facing lifecycle status.\n\n\* `requested` - Requested\n\* `planned` - Planned\n\* `completed` - Completed\n\* `wont_fix` - Won't fix\n\* `duplicate` - Duplicate"
        ),
    request_priority: zod
        .union([
            zod.enum(['high', 'medium', 'low']).describe('\* `high` - High\n\* `medium` - Medium\n\* `low` - Low'),
            zod.null(),
        ])
        .optional()
        .describe(
            'Updated manual priority. Pass null to remove the priority.\n\n\* `high` - High\n\* `medium` - Medium\n\* `low` - Low'
        ),
})

export const FeatureRequestsAddAccountCreateParams = /* @__PURE__ */ zod.object({
    id: zod.string(),
    project_id: zod
        .string()
        .describe(
            "Project ID of the project you're trying to access. To find the ID of the project, make a call to \/api\/projects\/."
        ),
})

export const featureRequestsAddAccountCreateBodyEvidenceOneSummaryDefault = ``
export const featureRequestsAddAccountCreateBodyEvidenceOneCustomerQuoteDefault = ``
export const featureRequestsAddAccountCreateBodyEvidenceOneEvidenceSourceMax = 200

export const featureRequestsAddAccountCreateBodyEvidenceOneSourceUrlOneDefault = ``
export const featureRequestsAddAccountCreateBodyEvidenceOneSourceUrlOneMax = 2000

export const featureRequestsAddAccountCreateBodyEvidenceOneSourceUrlTwoMax = 0

export const FeatureRequestsAddAccountCreateBody = /* @__PURE__ */ zod.object({
    expected_version: zod
        .number()
        .min(1)
        .describe('Request version loaded by the editor. Stale versions return 409 Conflict.'),
    account_id: zod.string().describe('Accessible account to link to this feature request.'),
    evidence: zod
        .union([
            zod.object({
                summary: zod
                    .string()
                    .default(featureRequestsAddAccountCreateBodyEvidenceOneSummaryDefault)
                    .describe("Internal summary of this account's request evidence."),
                customer_quote: zod
                    .string()
                    .default(featureRequestsAddAccountCreateBodyEvidenceOneCustomerQuoteDefault)
                    .describe('Customer quote kept with this evidence item.'),
                evidence_source: zod
                    .string()
                    .max(featureRequestsAddAccountCreateBodyEvidenceOneEvidenceSourceMax)
                    .describe('Free-form name of the source where this evidence was recorded.'),
                source_url: zod
                    .union([
                        zod
                            .url()
                            .max(featureRequestsAddAccountCreateBodyEvidenceOneSourceUrlOneMax)
                            .default(featureRequestsAddAccountCreateBodyEvidenceOneSourceUrlOneDefault),
                        zod.string().max(featureRequestsAddAccountCreateBodyEvidenceOneSourceUrlTwoMax),
                    ])
                    .optional()
                    .describe('Optional HTTP or HTTPS link to the source.'),
                requested_on: zod.iso
                    .date()
                    .nullish()
                    .describe('Date the account made the request, or null when unknown.'),
                image_ids: zod
                    .array(zod.string())
                    .optional()
                    .describe('Uploaded image IDs from this project to attach in display order.'),
            }),
            zod.null(),
        ])
        .optional()
        .describe('Optional first evidence item to create for the account in the same change.'),
})

export const FeatureRequestsAddEvidenceCreateParams = /* @__PURE__ */ zod.object({
    id: zod.string(),
    project_id: zod
        .string()
        .describe(
            "Project ID of the project you're trying to access. To find the ID of the project, make a call to \/api\/projects\/."
        ),
})

export const featureRequestsAddEvidenceCreateBodySummaryDefault = ``
export const featureRequestsAddEvidenceCreateBodyCustomerQuoteDefault = ``
export const featureRequestsAddEvidenceCreateBodyEvidenceSourceMax = 200

export const featureRequestsAddEvidenceCreateBodySourceUrlOneDefault = ``
export const featureRequestsAddEvidenceCreateBodySourceUrlOneMax = 2000

export const featureRequestsAddEvidenceCreateBodySourceUrlTwoMax = 0

export const FeatureRequestsAddEvidenceCreateBody = /* @__PURE__ */ zod.object({
    summary: zod
        .string()
        .default(featureRequestsAddEvidenceCreateBodySummaryDefault)
        .describe("Internal summary of this account's request evidence."),
    customer_quote: zod
        .string()
        .default(featureRequestsAddEvidenceCreateBodyCustomerQuoteDefault)
        .describe('Customer quote kept with this evidence item.'),
    evidence_source: zod
        .string()
        .max(featureRequestsAddEvidenceCreateBodyEvidenceSourceMax)
        .describe('Free-form name of the source where this evidence was recorded.'),
    source_url: zod
        .union([
            zod
                .url()
                .max(featureRequestsAddEvidenceCreateBodySourceUrlOneMax)
                .default(featureRequestsAddEvidenceCreateBodySourceUrlOneDefault),
            zod.string().max(featureRequestsAddEvidenceCreateBodySourceUrlTwoMax),
        ])
        .optional()
        .describe('Optional HTTP or HTTPS link to the source.'),
    requested_on: zod.iso.date().nullish().describe('Date the account made the request, or null when unknown.'),
    image_ids: zod
        .array(zod.string())
        .optional()
        .describe('Uploaded image IDs from this project to attach in display order.'),
    expected_version: zod
        .number()
        .min(1)
        .describe('Request version loaded by the editor. Stale versions return 409 Conflict.'),
    account_link_id: zod.string().describe('Active account link that owns this evidence.'),
})

export const FeatureRequestsArchiveCreateParams = /* @__PURE__ */ zod.object({
    id: zod.string(),
    project_id: zod
        .string()
        .describe(
            "Project ID of the project you're trying to access. To find the ID of the project, make a call to \/api\/projects\/."
        ),
})

export const FeatureRequestsArchiveCreateBody = /* @__PURE__ */ zod.object({
    expected_version: zod
        .number()
        .min(1)
        .describe('Request version loaded by the editor. Stale versions return 409 Conflict.'),
})

export const FeatureRequestsHistoryListParams = /* @__PURE__ */ zod.object({
    id: zod.string(),
    project_id: zod
        .string()
        .describe(
            "Project ID of the project you're trying to access. To find the ID of the project, make a call to \/api\/projects\/."
        ),
})

export const FeatureRequestsRemoveEvidenceCreateParams = /* @__PURE__ */ zod.object({
    id: zod.string(),
    project_id: zod
        .string()
        .describe(
            "Project ID of the project you're trying to access. To find the ID of the project, make a call to \/api\/projects\/."
        ),
})

export const FeatureRequestsRemoveEvidenceCreateBody = /* @__PURE__ */ zod.object({
    expected_version: zod
        .number()
        .min(1)
        .describe('Request version loaded by the editor. Stale versions return 409 Conflict.'),
    evidence_id: zod.string().describe('Evidence item to delete.'),
})

export const FeatureRequestsRestoreCreateParams = /* @__PURE__ */ zod.object({
    id: zod.string(),
    project_id: zod
        .string()
        .describe(
            "Project ID of the project you're trying to access. To find the ID of the project, make a call to \/api\/projects\/."
        ),
})

export const FeatureRequestsRestoreCreateBody = /* @__PURE__ */ zod.object({
    expected_version: zod
        .number()
        .min(1)
        .describe('Request version loaded by the editor. Stale versions return 409 Conflict.'),
})

export const FeatureRequestsStatusHistoryListParams = /* @__PURE__ */ zod.object({
    id: zod.string(),
    project_id: zod
        .string()
        .describe(
            "Project ID of the project you're trying to access. To find the ID of the project, make a call to \/api\/projects\/."
        ),
})

export const FeatureRequestsUpdateEvidenceCreateParams = /* @__PURE__ */ zod.object({
    id: zod.string(),
    project_id: zod
        .string()
        .describe(
            "Project ID of the project you're trying to access. To find the ID of the project, make a call to \/api\/projects\/."
        ),
})

export const featureRequestsUpdateEvidenceCreateBodySummaryDefault = ``
export const featureRequestsUpdateEvidenceCreateBodyCustomerQuoteDefault = ``
export const featureRequestsUpdateEvidenceCreateBodyEvidenceSourceMax = 200

export const featureRequestsUpdateEvidenceCreateBodySourceUrlOneDefault = ``
export const featureRequestsUpdateEvidenceCreateBodySourceUrlOneMax = 2000

export const featureRequestsUpdateEvidenceCreateBodySourceUrlTwoMax = 0

export const FeatureRequestsUpdateEvidenceCreateBody = /* @__PURE__ */ zod.object({
    summary: zod
        .string()
        .default(featureRequestsUpdateEvidenceCreateBodySummaryDefault)
        .describe("Internal summary of this account's request evidence."),
    customer_quote: zod
        .string()
        .default(featureRequestsUpdateEvidenceCreateBodyCustomerQuoteDefault)
        .describe('Customer quote kept with this evidence item.'),
    evidence_source: zod
        .string()
        .max(featureRequestsUpdateEvidenceCreateBodyEvidenceSourceMax)
        .describe('Free-form name of the source where this evidence was recorded.'),
    source_url: zod
        .union([
            zod
                .url()
                .max(featureRequestsUpdateEvidenceCreateBodySourceUrlOneMax)
                .default(featureRequestsUpdateEvidenceCreateBodySourceUrlOneDefault),
            zod.string().max(featureRequestsUpdateEvidenceCreateBodySourceUrlTwoMax),
        ])
        .optional()
        .describe('Optional HTTP or HTTPS link to the source.'),
    requested_on: zod.iso.date().nullish().describe('Date the account made the request, or null when unknown.'),
    image_ids: zod
        .array(zod.string())
        .optional()
        .describe('Uploaded image IDs from this project to attach in display order.'),
    expected_version: zod
        .number()
        .min(1)
        .describe('Request version loaded by the editor. Stale versions return 409 Conflict.'),
    evidence_id: zod.string().describe('Evidence item to replace.'),
})

export const groupsTypesMetricsListPathGroupTypeIndexMin = -2147483648
export const groupsTypesMetricsListPathGroupTypeIndexMax = 2147483647

export const GroupsTypesMetricsListParams = /* @__PURE__ */ zod.object({
    group_type_index: zod
        .number()
        .min(groupsTypesMetricsListPathGroupTypeIndexMin)
        .max(groupsTypesMetricsListPathGroupTypeIndexMax),
    project_id: zod
        .string()
        .describe(
            "Project ID of the project you're trying to access. To find the ID of the project, make a call to \/api\/projects\/."
        ),
})

export const GroupsTypesMetricsListQueryParams = /* @__PURE__ */ zod.object({
    limit: zod.number().optional().describe('Number of results to return per page.'),
    offset: zod.number().optional().describe('The initial index from which to return the results.'),
})

export const groupsTypesMetricsCreatePathGroupTypeIndexMin = -2147483648
export const groupsTypesMetricsCreatePathGroupTypeIndexMax = 2147483647

export const GroupsTypesMetricsCreateParams = /* @__PURE__ */ zod.object({
    group_type_index: zod
        .number()
        .min(groupsTypesMetricsCreatePathGroupTypeIndexMin)
        .max(groupsTypesMetricsCreatePathGroupTypeIndexMax),
    project_id: zod
        .string()
        .describe(
            "Project ID of the project you're trying to access. To find the ID of the project, make a call to \/api\/projects\/."
        ),
})

export const groupsTypesMetricsCreateBodyNameMax = 255

export const groupsTypesMetricsCreateBodyFormatDefault = `numeric`
export const groupsTypesMetricsCreateBodyIntervalDefault = 7
export const groupsTypesMetricsCreateBodyDisplayDefault = `number`
export const groupsTypesMetricsCreateBodyMathDefault = `count`
export const groupsTypesMetricsCreateBodyMathPropertyMax = 255

export const GroupsTypesMetricsCreateBody = /* @__PURE__ */ zod.object({
    name: zod
        .string()
        .max(groupsTypesMetricsCreateBodyNameMax)
        .describe('Name of the usage metric. Must be unique per group type within the project.'),
    format: zod
        .enum(['numeric', 'currency'])
        .describe('\* `numeric` - numeric\n\* `currency` - currency')
        .default(groupsTypesMetricsCreateBodyFormatDefault)
        .describe(
            'How the metric value is formatted in the UI. One of `numeric` or `currency`.\n\n\* `numeric` - numeric\n\* `currency` - currency'
        ),
    interval: zod
        .number()
        .default(groupsTypesMetricsCreateBodyIntervalDefault)
        .describe('Rolling time window in days used to compute the metric. Defaults to 7.'),
    display: zod
        .enum(['number', 'sparkline'])
        .describe('\* `number` - number\n\* `sparkline` - sparkline')
        .default(groupsTypesMetricsCreateBodyDisplayDefault)
        .describe(
            'Visual representation in the UI. One of `number` or `sparkline`.\n\n\* `number` - number\n\* `sparkline` - sparkline'
        ),
    filters: zod
        .record(zod.string(), zod.unknown())
        .describe(
            'Filter definition for the metric. Two shapes are accepted, discriminated by an optional `source` key.\n\n\*\*Events\*\* (default, when `source` is missing or `\"events\"`): HogFunction filter shape — `events: [...]`, optional `actions: [...]`, `properties: [...]`, `filter_test_accounts: bool`.\n\n\*\*Data warehouse\*\* (`source: \"data_warehouse\"`): `table_name` (synced DW table), `timestamp_field` (timestamp column or HogQL expression), `key_field` (column whose value matches the entity key). Currently DW metrics only render on group profiles — person profiles are not yet supported.'
        ),
    math: zod
        .enum(['count', 'sum'])
        .describe('\* `count` - count\n\* `sum` - sum')
        .default(groupsTypesMetricsCreateBodyMathDefault)
        .describe(
            'Aggregation function. `count` counts matching events; `sum` sums the value of `math_property` on matching events.\n\n\* `count` - count\n\* `sum` - sum'
        ),
    math_property: zod
        .string()
        .max(groupsTypesMetricsCreateBodyMathPropertyMax)
        .nullish()
        .describe(
            'Required when `math` is `sum`; must be empty when `math` is `count`. For events metrics this is an event property name. For data warehouse metrics this is the column name (or HogQL expression) to sum on the DW table.'
        ),
})

export const groupsTypesMetricsRetrievePathGroupTypeIndexMin = -2147483648
export const groupsTypesMetricsRetrievePathGroupTypeIndexMax = 2147483647

export const GroupsTypesMetricsRetrieveParams = /* @__PURE__ */ zod.object({
    group_type_index: zod
        .number()
        .min(groupsTypesMetricsRetrievePathGroupTypeIndexMin)
        .max(groupsTypesMetricsRetrievePathGroupTypeIndexMax),
    id: zod.string().describe('A UUID string identifying this group usage metric.'),
    project_id: zod
        .string()
        .describe(
            "Project ID of the project you're trying to access. To find the ID of the project, make a call to \/api\/projects\/."
        ),
})

export const groupsTypesMetricsPartialUpdatePathGroupTypeIndexMin = -2147483648
export const groupsTypesMetricsPartialUpdatePathGroupTypeIndexMax = 2147483647

export const GroupsTypesMetricsPartialUpdateParams = /* @__PURE__ */ zod.object({
    group_type_index: zod
        .number()
        .min(groupsTypesMetricsPartialUpdatePathGroupTypeIndexMin)
        .max(groupsTypesMetricsPartialUpdatePathGroupTypeIndexMax),
    id: zod.string().describe('A UUID string identifying this group usage metric.'),
    project_id: zod
        .string()
        .describe(
            "Project ID of the project you're trying to access. To find the ID of the project, make a call to \/api\/projects\/."
        ),
})

export const groupsTypesMetricsPartialUpdateBodyNameMax = 255

export const groupsTypesMetricsPartialUpdateBodyMathPropertyMax = 255

export const GroupsTypesMetricsPartialUpdateBody = /* @__PURE__ */ zod.object({
    name: zod
        .string()
        .max(groupsTypesMetricsPartialUpdateBodyNameMax)
        .optional()
        .describe('Name of the usage metric. Must be unique per group type within the project.'),
    format: zod
        .enum(['numeric', 'currency'])
        .describe('\* `numeric` - numeric\n\* `currency` - currency')
        .optional()
        .describe(
            'How the metric value is formatted in the UI. One of `numeric` or `currency`.\n\n\* `numeric` - numeric\n\* `currency` - currency'
        ),
    interval: zod
        .number()
        .optional()
        .describe('Rolling time window in days used to compute the metric. Defaults to 7.'),
    display: zod
        .enum(['number', 'sparkline'])
        .describe('\* `number` - number\n\* `sparkline` - sparkline')
        .optional()
        .describe(
            'Visual representation in the UI. One of `number` or `sparkline`.\n\n\* `number` - number\n\* `sparkline` - sparkline'
        ),
    filters: zod
        .record(zod.string(), zod.unknown())
        .optional()
        .describe(
            'Filter definition for the metric. Two shapes are accepted, discriminated by an optional `source` key.\n\n\*\*Events\*\* (default, when `source` is missing or `\"events\"`): HogFunction filter shape — `events: [...]`, optional `actions: [...]`, `properties: [...]`, `filter_test_accounts: bool`.\n\n\*\*Data warehouse\*\* (`source: \"data_warehouse\"`): `table_name` (synced DW table), `timestamp_field` (timestamp column or HogQL expression), `key_field` (column whose value matches the entity key). Currently DW metrics only render on group profiles — person profiles are not yet supported.'
        ),
    math: zod
        .enum(['count', 'sum'])
        .describe('\* `count` - count\n\* `sum` - sum')
        .optional()
        .describe(
            'Aggregation function. `count` counts matching events; `sum` sums the value of `math_property` on matching events.\n\n\* `count` - count\n\* `sum` - sum'
        ),
    math_property: zod
        .string()
        .max(groupsTypesMetricsPartialUpdateBodyMathPropertyMax)
        .nullish()
        .describe(
            'Required when `math` is `sum`; must be empty when `math` is `count`. For events metrics this is an event property name. For data warehouse metrics this is the column name (or HogQL expression) to sum on the DW table.'
        ),
})

export const groupsTypesMetricsDestroyPathGroupTypeIndexMin = -2147483648
export const groupsTypesMetricsDestroyPathGroupTypeIndexMax = 2147483647

export const GroupsTypesMetricsDestroyParams = /* @__PURE__ */ zod.object({
    group_type_index: zod
        .number()
        .min(groupsTypesMetricsDestroyPathGroupTypeIndexMin)
        .max(groupsTypesMetricsDestroyPathGroupTypeIndexMax),
    id: zod.string().describe('A UUID string identifying this group usage metric.'),
    project_id: zod
        .string()
        .describe(
            "Project ID of the project you're trying to access. To find the ID of the project, make a call to \/api\/projects\/."
        ),
})
