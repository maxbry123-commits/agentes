package identity

import (
	"context"
	"fmt"
	"reflect"
	"slices"

	"github.com/grafana/authlib/authn"
	"github.com/grafana/authlib/types"
)

// provisioningServiceAudience is the API group the provisioning (Git Sync) service token carries
// as an audience in multi-tenant deployments. It mirrors the provisioning apiserver's group
// ("provisioning.grafana.app"); it is duplicated here as a literal to keep apimachinery free of
// dependencies on app packages.
const provisioningServiceAudience = "provisioning.grafana.app"

type ctxUserKey struct{}
type metadataIdentityUIDKey struct{}
type ctxOrgIDKey struct{}
type innermostServiceIdentityKey struct{}

// WithOrgID stores the org ID in context as a fallback when no requester is available.
func WithOrgID(ctx context.Context, orgID int64) context.Context {
	return context.WithValue(ctx, ctxOrgIDKey{}, orgID)
}

// OrgIDFrom returns the org ID stored by WithOrgID, and whether it was present.
func OrgIDFrom(ctx context.Context) (int64, bool) {
	orgID, ok := ctx.Value(ctxOrgIDKey{}).(int64)
	return orgID, ok
}

// WithOriginalIdentityUID sets the UID to use for createdBy/updatedBy annotations when the
// context identity is overridden (e.g. by the store wrapper using service identity). Storage
// that sets these annotations (e.g. unistore prepare) should call MetadataIdentityUIDFrom
// and use it when present so the real acting user is recorded.
func WithOriginalIdentityUID(ctx context.Context, uid string) context.Context {
	return context.WithValue(ctx, metadataIdentityUIDKey{}, uid)
}

// MetadataIdentityUIDFrom returns the UID to use for createdBy/updatedBy when set by a
// wrapper (e.g. store wrapper). If not set, the caller should use the identity from
// AuthInfoFrom(ctx) for annotations.
func MetadataIdentityUIDFrom(ctx context.Context) (string, bool) {
	uid, ok := ctx.Value(metadataIdentityUIDKey{}).(string)
	return uid, ok && uid != ""
}

// WithRequester attaches the requester to the context.
func WithRequester(ctx context.Context, usr Requester) context.Context {
	ctx = types.WithAuthInfo(ctx, usr) // also set the upstream auth info claims
	return context.WithValue(ctx, ctxUserKey{}, usr)
}

// Get the Requester from context
func GetRequester(ctx context.Context) (Requester, error) {
	// Set by appcontext.WithUser
	u, ok := ctx.Value(ctxUserKey{}).(Requester)
	if ok && !checkNilRequester(u) {
		return u, nil
	}
	return nil, fmt.Errorf("a Requester was not found in the context")
}

// WithInnermostServiceIdentity sets the innermost service identity in the context.
// This is useful for gRPC services to propagate and recover the caller service identity, in the context of audit logging.
func WithInnermostServiceIdentity(ctx context.Context, svcIdentity string) context.Context {
	return context.WithValue(ctx, innermostServiceIdentityKey{}, svcIdentity)
}

// InnermostServiceIdentityFrom returns the innermost service identity stored in the context, and whether it was present.
// This is useful for gRPC services to propagate and recover the caller service identity, in the context of audit logging.
func InnermostServiceIdentityFrom(ctx context.Context) (string, bool) {
	svcIdentity, ok := ctx.Value(innermostServiceIdentityKey{}).(string)
	return svcIdentity, ok && svcIdentity != ""
}

func checkNilRequester(r Requester) bool {
	return r == nil || (reflect.ValueOf(r).Kind() == reflect.Pointer && reflect.ValueOf(r).IsNil())
}

const (
	serviceName                = "service"
	serviceNameForProvisioning = "provisioning"
)

type IdentityOpts func(*StaticRequester)

// WithServiceIdentityName sets the `StaticRequester.AccessTokenClaims.Rest.ServiceIdentity` field to the provided name.
// This is so far only used by Secrets Manager to identify and gate the service decrypting a secret.
func WithServiceIdentityName(name string) IdentityOpts {
	return func(r *StaticRequester) {
		r.AccessTokenClaims.Rest.ServiceIdentity = name
	}
}

func newInternalIdentity(name string, namespace string, orgID int64, opts ...IdentityOpts) Requester {
	// Create a copy of the ServiceIdentityClaims to avoid modifying the global one.
	// Some of the options might mutate it.
	claimsCopy := *ServiceIdentityClaims

	staticRequester := &StaticRequester{
		Type:           types.TypeAccessPolicy,
		Name:           name,
		UserUID:        name,
		AuthID:         name,
		Login:          name,
		OrgRole:        RoleAdmin,
		Namespace:      namespace,
		IsGrafanaAdmin: true,
		OrgID:          orgID,
		Permissions: map[int64]map[string][]string{
			orgID: serviceIdentityPermissions,
		},
		AccessTokenClaims: &claimsCopy,
	}

	for _, opt := range opts {
		opt(staticRequester)
	}

	return staticRequester
}

// WithServiceIdentityForSingleNamespace sets an identity representing the service itself in provided namespace and store it in context.
// This is useful for background tasks that has to communicate with other services in the same namespace. It also returns a Requester with
// static permissions so it can be used in legacy code paths.
func WithServiceIdentityForSingleNamespace(ctx context.Context, namespace string, opts ...IdentityOpts) (context.Context, Requester) {
	r := newInternalIdentity(serviceName, namespace, 1, opts...)
	return WithRequester(ctx, r), r
}

// WithServiceIdentityForSingleNamespaceContext sets an identity representing the service itself in context, restricted to a namespace.
// Use when using a middleware that signs tokens with the same restriction.
func WithServiceIdentityForSingleNamespaceContext(ctx context.Context, namespace string, opts ...IdentityOpts) context.Context {
	ctx, _ = WithServiceIdentityForSingleNamespace(ctx, namespace, opts...)
	return ctx
}

// WithServiceIdentity sets an identity representing the service itself in provided org and store it in context.
// This is useful for background tasks that has to communicate with unfied storage. It also returns a Requester with
// static permissions so it can be used in legacy code paths.
func WithServiceIdentity(ctx context.Context, orgID int64, opts ...IdentityOpts) (context.Context, Requester) {
	r := newInternalIdentity(serviceName, "*", orgID, opts...)
	return WithRequester(ctx, r), r
}

func WithProvisioningIdentity(ctx context.Context, namespace string, opts ...IdentityOpts) (context.Context, Requester, error) {
	ns, err := types.ParseNamespace(namespace)
	if err != nil {
		return nil, nil, err
	}

	r := newInternalIdentity(serviceNameForProvisioning, ns.Value, ns.OrgID, opts...)
	return WithRequester(ctx, r), r, nil
}

// WithServiceIdentityContext sets an identity representing the service itself in context.
func WithServiceIdentityContext(ctx context.Context, orgID int64, opts ...IdentityOpts) context.Context {
	ctx, _ = WithServiceIdentity(ctx, orgID, opts...)
	return ctx
}

// WithServiceIdentityFN calls provided closure with an context contaning the identity of the service.
func WithServiceIdentityFn[T any](ctx context.Context, orgID int64, fn func(ctx context.Context) (T, error), opts ...IdentityOpts) (T, error) {
	return fn(WithServiceIdentityContext(ctx, orgID, opts...))
}

func getWildcardPermissions(actions ...string) map[string][]string {
	permissions := make(map[string][]string, len(actions))
	for _, a := range actions {
		permissions[a] = []string{"*"}
	}
	return permissions
}

// serviceIdentityPermissions is a list of wildcard permissions for provided actions.
// We should add every action required "internally" here.
var serviceIdentityPermissions = getWildcardPermissions(
	"annotations:read",
	"folders:read",
	"folders:write",
	"folders:create",
	"folders:delete",
	"dashboards:read",
	"dashboards:write",
	"dashboards:create",
	"datasources:query",
	"datasources:read",
	"datasources:delete",
	"library.panels:create", // ActionLibraryPanelsCreate
	"library.panels:read",   // ActionLibraryPanelsRead
	"library.panels:write",  // ActionLibraryPanelsWrite
	"library.panels:delete", // ActionLibraryPanelsDelete
	"variables:create",      // ActionVariablesCreate
	"variables:read",        // ActionVariablesRead
	"variables:write",       // ActionVariablesWrite
	"variables:delete",      // ActionVariablesDelete
	"alert.rules:delete",    // ActionAlertingRuleDelete — folder cascade delete removes contained alert rules.
	"playlists:read",        // playlist.ActionPlaylistsRead
	"playlists:write",       // playlist.ActionPlaylistsWrite
	"alert.provisioning:write",
	"alert.provisioning.secrets:read",
	"notifications.alerting.grafana.app/configs:get",           // accesscontrol.ActionAlertingConfigRead — ExternalAMSyncer reads spec.externalAlertmanagerSync.datasourceUid.
	"notifications.alerting.grafana.app/configs:update",        // accesscontrol.ActionAlertingConfigUpdate — ExternalAMSyncer creates the Config singleton on first sync.
	"notifications.alerting.grafana.app/configs/status:update", // accesscontrol.ActionAlertingConfigStatusUpdate — service-only; humans never write status directly.
	"users:read",           // accesscontrol.ActionUsersRead,
	"org.users:read",       // accesscontrol.ActionOrgUsersRead,
	"teams:read",           // accesscontrol.ActionTeamsRead,
	"serviceaccounts:read", // serviceaccounts.ActionRead,
)

// Note: Any wildcard-prefixed permissions here must be whitelisted in authlib: https://github.com/grafana/authlib/blob/main/authz/service_permissions.go
var serviceIdentityTokenPermissions = []string{
	"folder.grafana.app:*",
	"dashboard.grafana.app:*",
	"playlist.grafana.app:*",
	"secret.grafana.app:*",
	"query.grafana.app:*",
	"datasource.grafana.app:*",
	"iam.grafana.app:*",
	"provisioning.grafana.app:*",
	"preferences.grafana.app:*", // user, team, and org preferences
	"collections.grafana.app:*", // user stars
	"plugins.grafana.app:*",
	"historian.alerting.grafana.app:*",
	"notifications.alerting.grafana.app:*",
	"rules.alerting.grafana.app:*",
	"advisor.grafana.app:*",
	"annotation.grafana.app:*",
	"setting.grafana.app:*",

	// allow access to all datasource types
	"*.datasource.grafana.app:*",

	// Secrets Manager uses a custom verb for secret decryption, and its authorizer does not allow wildcard permissions.
	"secret.grafana.app/securevalues:decrypt",

	// Allow access to all apiextensions.k8s.io resources
	"*.ext.grafana.app:*",

	// Named explicitly: the *.ext.grafana.app wildcard only matches single-segment prefixes.
	"assistant.alertrules.ext.grafana.app:*",

	// Allow access to apps.grafana.app resources (e.g. AppManifest)
	"apps.grafana.app:*",
}

var ServiceIdentityClaims = &authn.Claims[authn.AccessTokenClaims]{
	Rest: authn.AccessTokenClaims{
		Permissions:          serviceIdentityTokenPermissions,
		DelegatedPermissions: serviceIdentityTokenPermissions,
	},
}

func IsServiceIdentity(ctx context.Context) bool {
	ident, ok := types.AuthInfoFrom(ctx)
	if !ok {
		return false
	}
	t, uid, err := types.ParseTypeID(ident.GetUID())
	if err != nil {
		return false
	}

	return t == types.TypeAccessPolicy && (uid == serviceName || uid == serviceNameForProvisioning)
}

// IsProvisioningServiceIdentity reports whether auth is the provisioning (Git Sync) service
// identity — identified either by its access-policy UID (single-tenant / OSS) or by carrying the
// provisioning API group as a token audience (multi-tenant). Use it to grant the provisioning
// service write paths that are otherwise closed to regular users. The unified storage backend
// enforces the same rule on managed resources (pkg/storage/unified/apistore); this is the shared
// predicate so legacy services that bypass that backend can apply it consistently.
func IsProvisioningServiceIdentity(auth types.AuthInfo) bool {
	if auth == nil {
		return false
	}
	return auth.GetUID() == types.NewTypeID(types.TypeAccessPolicy, serviceNameForProvisioning) ||
		slices.Contains(auth.GetAudience(), provisioningServiceAudience)
}
