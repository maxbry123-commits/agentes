// Narrow shared media-generation runtime helpers for bundled and third-party plugins.

export { resolveClosestSize } from "../media-generation/runtime-shared.js";
export { resolveGeneratedMediaMaxBytes } from "../media/configured-max-bytes.js";
export { downloadGeneratedVideoAsset } from "../media-generation/provider-assets.js";
