import { cleanup, type RenderResult } from '@testing-library/react'
import React from 'react'

import type { BaseChartContext } from '../core/chart-context'
import type { ChartScales, ChartTheme, ResolvedSeries, ResolveValueFn } from '../core/types'
import { makeOverlayContext, type OverlayContextOverrides, renderOverlayInChart } from '../testing'
import { ValueLabels } from './ValueLabels'

const DIMENSIONS = {
    width: 800,
    height: 400,
    plotLeft: 48,
    plotTop: 16,
    plotWidth: 720,
    plotHeight: 352,
}

const LABELS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri']
const X_POSITIONS: Record<string, number> = { Mon: 60, Tue: 220, Wed: 380, Thu: 540, Fri: 700 }

const xScale = (label: string): number | undefined => X_POSITIONS[label]
// Left axis: 0 -> 368, 100 -> 16
const yScale = (v: number): number => 368 - (v / 100) * 352
// The overlay drops anchors outside the plot, so a case carrying values beyond 0..100 needs a scale
// whose domain covers them or every label is dropped and the case stops testing what it was for.
const wideYScale = (v: number): number => 368 - (v / 10000) * 352
const signedYScale = (v: number): number => 192 - (v / 100) * 176

function makeContext(
    series: ResolvedSeries[],
    overrides: OverlayContextOverrides & { scales?: ChartScales } = {}
): BaseChartContext {
    const { scales, ...rest } = overrides
    return makeOverlayContext(scales ?? { x: xScale, y: yScale, yTicks: () => [0, 50, 100] }, {
        dimensions: DIMENSIONS,
        labels: LABELS,
        series,
        ...rest,
    })
}

function renderInChart(context: BaseChartContext, node: React.ReactNode): RenderResult {
    return renderOverlayInChart(node, context)
}

function labelDivs(container: HTMLElement): HTMLDivElement[] {
    return Array.from(container.querySelectorAll<HTMLDivElement>('[data-attr="hog-chart-value-label"]'))
}

describe('ValueLabels', () => {
    afterEach(() => cleanup())

    it('renders one label per non-zero data point in a single series', () => {
        const series: ResolvedSeries[] = [{ key: 's', label: 'S', color: '#f00', data: [10, 20, 30, 40, 50] }]
        const { container } = renderInChart(makeContext(series), <ValueLabels />)
        const divs = labelDivs(container)
        expect(divs).toHaveLength(5)
        expect(divs.map((d) => d.textContent)).toEqual(['10', '20', '30', '40', '50'])
    })

    it.each<[string, ((value: number) => string) | undefined, number[], string[]]>([
        ['no formatter → toLocaleString', undefined, [1234, 5678], [(1234).toLocaleString(), (5678).toLocaleString()]],
        ['custom formatter', (v) => `$${(v / 1000).toFixed(1)}k`, [1000, 2000], ['$1.0k', '$2.0k']],
    ])('formats labels: %s', (_name, formatter, data, expected) => {
        const series: ResolvedSeries[] = [{ key: 's', label: 'S', color: '#f00', data }]
        const ctx = makeContext(series, {
            labels: ['Mon', 'Tue'],
            scales: { x: xScale, y: wideYScale, yTicks: () => [0, 5000, 10000] },
        })
        const { container } = renderInChart(ctx, <ValueLabels valueFormatter={formatter} />)
        const divs = labelDivs(container)
        expect(divs.map((d) => d.textContent)).toEqual(expected)
    })

    it('skips zero values', () => {
        const series: ResolvedSeries[] = [{ key: 's', label: 'S', color: '#f00', data: [10, 0, 30, 0, 50] }]
        const { container } = renderInChart(makeContext(series), <ValueLabels />)
        expect(labelDivs(container).map((d) => d.textContent)).toEqual(['10', '30', '50'])
    })

    it('skips non-finite values (NaN, Infinity)', () => {
        const series: ResolvedSeries[] = [{ key: 's', label: 'S', color: '#f00', data: [10, NaN, 30, Infinity, 50] }]
        const { container } = renderInChart(makeContext(series), <ValueLabels />)
        expect(labelDivs(container).map((d) => d.textContent)).toEqual(['10', '30', '50'])
    })

    it('skips series where visibility.excluded is true', () => {
        const series: ResolvedSeries[] = [
            { key: 'a', label: 'A', color: '#f00', data: [10, 20, 30, 40, 50] },
            { key: 'b', label: 'B', color: '#0f0', data: [60, 70, 80, 90, 100], visibility: { excluded: true } },
        ]
        const { container } = renderInChart(makeContext(series), <ValueLabels />)
        const divs = labelDivs(container)
        expect(divs).toHaveLength(5)
        divs.forEach((d) => expect(d.style.backgroundColor).toBe('rgb(255, 0, 0)'))
    })

    it('positions negative values below the point and positive values above', () => {
        const series: ResolvedSeries[] = [{ key: 's', label: 'S', color: '#f00', data: [50, -50, 25, -25, 75] }]
        const ctx = makeContext(series, { scales: { x: xScale, y: signedYScale, yTicks: () => [-100, 0, 100] } })
        const { container } = renderInChart(ctx, <ValueLabels />)
        const divs = labelDivs(container)
        expect(divs).toHaveLength(5)
        // positive values (50, 25, 75) render above → transform translates up by full height
        // negative values (-50, -25) render below → transform is plain translateX
        const values = [50, -50, 25, -25, 75]
        divs.forEach((d, i) => {
            const value = values[i]
            if (value >= 0) {
                expect(d.style.transform).toBe('translate(-50%, -100%)')
            } else {
                expect(d.style.transform).toBe('translateX(-50%)')
            }
        })
    })

    it('vertical: flips a top-clipping label inside the bar instead of expanding margins', () => {
        // yScale(100) = 16, so an above-placed label would render with top=16-22=-6 and get
        // clipped by the wrapper's `overflow: hidden`. The overlay flips it below the bar top.
        const series: ResolvedSeries[] = [{ key: 's', label: 'S', color: '#f00', data: [100] }]
        const { container } = renderInChart(makeContext(series, { labels: ['Mon'] }), <ValueLabels />)
        const divs = labelDivs(container)
        expect(divs).toHaveLength(1)
        expect(divs[0].style.transform).toBe('translateX(-50%)')
        expect(divs[0].style.top).toBe('16px')
    })

    it('horizontal: flips a right-clipping label inside the bar instead of expanding margins', () => {
        // A bar reaching the edge of a plot with almost no right margin: anchored on its leading
        // edge the label would overflow the wrapper's `overflow: hidden`, so it flips. The anchor
        // stays on the plot edge rather than past it, since beyond that a label is dropped.
        const series: ResolvedSeries[] = [{ key: 's', label: 'S', color: '#f00', data: [1] }]
        const ctx = makeContext(series, {
            axisOrientation: 'horizontal',
            labels: ['Mon'],
            dimensions: { ...DIMENSIONS, plotWidth: 744 },
            scales: { x: () => 200, y: () => 792, yTicks: () => [0, 1] },
        })
        const divs = labelDivs(renderInChart(ctx, <ValueLabels />).container)
        expect(divs).toHaveLength(1)
        expect(divs[0].style.transform).toBe('translate(-100%, -50%)')
    })

    it('drops overlapping labels via greedy collision avoidance', () => {
        // Two points at the same x: only one should survive.
        const series: ResolvedSeries[] = [{ key: 's', label: 'S', color: '#f00', data: [50, 50] }]
        const ctx = makeContext(series, {
            labels: ['A', 'B'],
            scales: {
                // both points sit at x=100 → guaranteed collision
                x: () => 100,
                y: yScale,
                yTicks: () => [0, 50, 100],
            },
        })
        const { container } = renderInChart(ctx, <ValueLabels />)
        expect(labelDivs(container)).toHaveLength(1)
    })

    it('uses the matching yAxes scale when a series has a yAxisId', () => {
        // Right axis maps 0-1000; left axis maps 0-100.
        const rightScale = (v: number): number => 368 - (v / 1000) * 352
        const series: ResolvedSeries[] = [{ key: 'right', label: 'R', color: '#00f', data: [500], yAxisId: 'y1' }]
        const ctx = makeContext(series, {
            labels: ['Mon'],
            scales: {
                x: xScale,
                y: yScale,
                yTicks: () => [0, 50, 100],
                yAxes: {
                    left: { scale: yScale, ticks: () => [0, 50, 100], position: 'left' },
                    y1: { scale: rightScale, ticks: () => [0, 500, 1000], position: 'right' },
                },
            },
        })
        const { container } = renderInChart(ctx, <ValueLabels />)
        const divs = labelDivs(container)
        expect(divs).toHaveLength(1)
        // rightScale(500) = 192 → label top should match (positive → 'above' case uses top=y exactly)
        expect(divs[0].style.top).toBe('192px')
    })

    it('falls back to the primary y-scale when yAxisId is unknown', () => {
        const series: ResolvedSeries[] = [{ key: 's', label: 'S', color: '#f00', data: [50], yAxisId: 'missing' }]
        const ctx = makeContext(series, { labels: ['Mon'] })
        const { container } = renderInChart(ctx, <ValueLabels />)
        const divs = labelDivs(container)
        expect(divs).toHaveLength(1)
        // yScale(50) = 192
        expect(divs[0].style.top).toBe('192px')
    })

    it('renders one label per series at the same x, each with its own color', () => {
        const series: ResolvedSeries[] = [
            { key: 'a', label: 'A', color: '#112233', data: [10] },
            { key: 'b', label: 'B', color: '#445566', data: [20] },
        ]
        const ctx = makeContext(series, { labels: ['Mon'] })
        // Same x but different values put the two labels at different value-axis coords, so their
        // boxes don't overlap and both render.
        const { container } = renderInChart(ctx, <ValueLabels />)
        const divs = labelDivs(container)
        expect(divs).toHaveLength(2)
        const bgColors = divs.map((d) => d.style.backgroundColor).sort()
        expect(bgColors).toEqual(['rgb(17, 34, 51)', 'rgb(68, 85, 102)'])
    })

    it('per-segment: passes seriesKey to scales.x so grouped bars anchor on their own bar', () => {
        // Mirrors BarChart's grouped-layout x-scale: returns a per-series offset when seriesKey
        // is supplied, otherwise the band center. With the seriesKey wired through, each label
        // lands on its own bar instead of the shared band center.
        const series: ResolvedSeries[] = [
            { key: 'a', label: 'A', color: '#112233', data: [10] },
            { key: 'b', label: 'B', color: '#445566', data: [20] },
        ]
        const xScaleGrouped = (label: string, seriesKey?: string): number | undefined => {
            const bandStart = X_POSITIONS[label]
            if (bandStart == null) {
                return undefined
            }
            if (seriesKey === 'a') {
                return bandStart - 10
            }
            if (seriesKey === 'b') {
                return bandStart + 10
            }
            return bandStart
        }
        const ctx = makeContext(series, {
            labels: ['Mon'],
            scales: { x: xScaleGrouped, y: yScale, yTicks: () => [0, 50, 100] },
        })
        const { container } = renderInChart(ctx, <ValueLabels />)
        const divs = labelDivs(container)
        expect(divs).toHaveLength(2)
        // Each label should land on its own bar's x — not the shared band center (60).
        const byColor = new Map(divs.map((d) => [d.style.backgroundColor, d.style.left]))
        expect(byColor.get('rgb(17, 34, 51)')).toBe('50px')
        expect(byColor.get('rgb(68, 85, 102)')).toBe('70px')
    })

    it('renders null when nothing survives filtering', () => {
        const series: ResolvedSeries[] = [{ key: 's', label: 'S', color: '#f00', data: [NaN, NaN, NaN] }]
        const ctx = makeContext(series, { labels: ['Mon', 'Tue', 'Wed'] })
        const { container } = renderInChart(ctx, <ValueLabels />)
        expect(labelDivs(container)).toHaveLength(0)
    })

    it('positions labels at the resolved (e.g. stacked) y, not the raw series.data y', () => {
        // Raw value 25 sits at y=278 on the left axis; stacking lifts it to top-of-stack=75 → y=104.
        // The resolvePositionValue closure mimics what LineChart provides for stacked series.
        const series: ResolvedSeries[] = [{ key: 's', label: 'S', color: '#f00', data: [25] }]
        const stackedTops: Record<string, number[]> = { s: [75] }
        const resolvePositionValue: ResolveValueFn = (s, i) => stackedTops[s.key]?.[i] ?? s.data[i] ?? 0
        const ctx = makeContext(series, { labels: ['Mon'], resolvePositionValue })
        const { container } = renderInChart(ctx, <ValueLabels />)
        const divs = labelDivs(container)
        expect(divs).toHaveLength(1)
        // Label text comes from the raw value (25), but position uses the resolved 75.
        expect(divs[0].textContent).toBe('25')
        // yScale(75) = 368 - (75/100)*352 = 104
        expect(divs[0].style.top).toBe('104px')
    })

    it('uses theme.backgroundColor for the label border (dark-mode safe)', () => {
        const series: ResolvedSeries[] = [{ key: 's', label: 'S', color: '#f00', data: [50] }]
        const darkTheme: ChartTheme = { colors: ['#f00'], backgroundColor: '#222222' }
        const ctx = makeContext(series, { labels: ['Mon'], theme: darkTheme })
        const { container } = renderInChart(ctx, <ValueLabels />)
        const divs = labelDivs(container)
        expect(divs).toHaveLength(1)
        expect(divs[0].style.borderColor).toBe('#222222')
    })

    it.each<[string, number, string, string]>([
        ['positive value past the right edge', 50, '192px', 'translateY(-50%)'],
        ['negative value past the left edge', -50, '544px', 'translate(-100%, -50%)'],
    ])('horizontal: places %s', (_name, value, expectedLeft, expectedTransform) => {
        const series: ResolvedSeries[] = [{ key: 's', label: 'S', color: '#f00', data: [value] }]
        const ctx = makeContext(series, {
            axisOrientation: 'horizontal',
            labels: ['Mon'],
            scales: { x: () => 60, y: yScale, yTicks: () => [0, 50, 100] },
        })
        const divs = labelDivs(renderInChart(ctx, <ValueLabels />).container)
        expect(divs[0].style.left).toBe(expectedLeft)
        expect(divs[0].style.transform).toBe(expectedTransform)
    })

    it('vertical: keeps neighbours that overlap along x but are separated along the value axis', () => {
        // Two adjacent bars whose labels overlap horizontally (x=100 and x=108, boxes ~24px wide)
        // but sit far apart vertically because the bars have very different heights (90 vs 10).
        // A categorical-axis-only pass would drop the second; the 2D check keeps both.
        const series: ResolvedSeries[] = [{ key: 's', label: 'S', color: '#f00', data: [90, 10] }]
        const xByLabel: Record<string, number> = { A: 100, B: 108 }
        const ctx = makeContext(series, {
            labels: ['A', 'B'],
            scales: { x: (label: string) => xByLabel[label], y: yScale, yTicks: () => [0, 50, 100] },
        })
        expect(labelDivs(renderInChart(ctx, <ValueLabels />).container)).toHaveLength(2)
    })

    it('vertical: drops neighbours that overlap along both axes', () => {
        // Same near-x overlap as above, but equal heights so the boxes also overlap vertically.
        const series: ResolvedSeries[] = [{ key: 's', label: 'S', color: '#f00', data: [50, 50] }]
        const xByLabel: Record<string, number> = { A: 100, B: 108 }
        const ctx = makeContext(series, {
            labels: ['A', 'B'],
            scales: { x: (label: string) => xByLabel[label], y: yScale, yTicks: () => [0, 50, 100] },
        })
        expect(labelDivs(renderInChart(ctx, <ValueLabels />).container)).toHaveLength(1)
    })

    it('horizontal: keeps neighbours on the same row that are separated along the value axis', () => {
        // Both labels share the categorical row (y=200) but their bars have very different values
        // (10 vs 90), so the boxes sit far apart along the x (value) axis and never touch.
        const series: ResolvedSeries[] = [{ key: 's', label: 'S', color: '#f00', data: [10, 90] }]
        const ctx = makeContext(series, {
            axisOrientation: 'horizontal',
            labels: ['A', 'B'],
            scales: { x: () => 200, y: yScale, yTicks: () => [0, 50, 100] },
        })
        expect(labelDivs(renderInChart(ctx, <ValueLabels />).container)).toHaveLength(2)
    })

    it('horizontal: drops neighbours that overlap along both axes', () => {
        // Same row (y=200) and equal values, so the boxes overlap on the value axis too.
        const series: ResolvedSeries[] = [{ key: 's', label: 'S', color: '#f00', data: [50, 50] }]
        const ctx = makeContext(series, {
            axisOrientation: 'horizontal',
            labels: ['A', 'B'],
            scales: { x: () => 200, y: yScale, yTicks: () => [0, 50, 100] },
        })
        expect(labelDivs(renderInChart(ctx, <ValueLabels />).container)).toHaveLength(1)
    })

    describe('stack-total mode', () => {
        it('skips mixed-sign bands (no single visual stack apex)', () => {
            const series: ResolvedSeries[] = [
                { key: 'a', label: 'A', color: '#a00', data: [30, 30] },
                { key: 'b', label: 'B', color: '#0a0', data: [-10, 5] },
            ]
            const ctx = makeContext(series, { labels: ['Mon', 'Tue'] })
            const divs = labelDivs(renderInChart(ctx, <ValueLabels mode="stack-total" />).container)
            // Mon is mixed-sign (skipped); Tue is all-positive total=35.
            expect(divs.map((d) => d.textContent)).toEqual(['35'])
        })

        it('sums visible series per band, skips zero totals and excluded series', () => {
            const series: ResolvedSeries[] = [
                { key: 'a', label: 'A', color: '#112233', data: [10, 0, 30] },
                { key: 'b', label: 'B', color: '#445566', data: [5, 0, 5] },
                { key: 'c', label: 'C', color: '#778899', data: [99, 99, 99], visibility: { valueLabel: false } },
            ]
            const ctx = makeContext(series, { labels: ['Mon', 'Tue', 'Wed'] })
            const divs = labelDivs(renderInChart(ctx, <ValueLabels mode="stack-total" />).container)
            expect(divs.map((d) => d.textContent)).toEqual(['15', '35'])
            // Total label uses the topmost visible series color.
            expect(divs[0].style.backgroundColor).toBe('rgb(68, 85, 102)')
        })
    })

    describe('formatter context', () => {
        it('passes each segment the raw value and its band of stack-contributing values', () => {
            // Two series, one negative — the formatter encodes rawValue and the band so we can
            // assert the overlay surfaces the full band (incl. the negative) to the caller.
            const series: ResolvedSeries[] = [
                { key: 'a', label: 'A', color: '#a00', data: [30, 25] },
                { key: 'b', label: 'B', color: '#0a0', data: [-10, 75] },
            ]
            const ctx = makeContext(series, {
                labels: ['Mon', 'Tue'],
                scales: { x: xScale, y: signedYScale, yTicks: () => [-100, 0, 100] },
            })
            const { container } = renderInChart(
                ctx,
                <ValueLabels valueFormatter={(_v, _si, _di, c) => `${c.rawValue}|${c.bandValues.join(',')}`} />
            )
            expect(
                labelDivs(container)
                    .map((d) => d.textContent)
                    .sort()
            ).toEqual(['-10|30,-10', '25|25,75', '30|30,-10', '75|25,75'])
        })

        it('passes the preceding band as previousBandValues (empty at the first index)', () => {
            const series: ResolvedSeries[] = [
                { key: 'a', label: 'A', color: '#a00', data: [30, 25] },
                { key: 'b', label: 'B', color: '#0a0', data: [-10, 75] },
            ]
            const ctx = makeContext(series, {
                labels: ['Mon', 'Tue'],
                scales: { x: xScale, y: signedYScale, yTicks: () => [-100, 0, 100] },
            })
            const { container } = renderInChart(
                ctx,
                <ValueLabels valueFormatter={(_v, _si, _di, c) => `${c.rawValue}|${c.previousBandValues.join(',')}`} />
            )
            expect(
                labelDivs(container)
                    .map((d) => d.textContent)
                    .sort()
            ).toEqual(['-10|', '25|30,-10', '30|', '75|30,-10'])
        })

        it('marks the context isPercent in percent layout and passes the segment fraction as value', () => {
            const series: ResolvedSeries[] = [
                { key: 'a', label: 'A', color: '#a00', data: [20, 60] },
                { key: 'b', label: 'B', color: '#0a0', data: [80, 40] },
            ]
            const percentScales: ChartScales = {
                x: xScale,
                y: (v: number) => 368 - v * 352,
                yTicks: () => [0, 0.5, 1],
            }
            const positionByKey: Record<string, number[]> = { a: [0.2, 0.6], b: [1.0, 1.0] }
            const resolvePositionValue: ResolveValueFn = (s, i) => positionByKey[s.key]?.[i] ?? 0
            const ctx = makeContext(series, {
                isPercent: true,
                labels: ['Mon', 'Tue'],
                scales: percentScales,
                resolvePositionValue,
            })
            const { container } = renderInChart(
                ctx,
                // Encode both `value` (the fraction) and `isPercent` so the assertion pins both, no branch.
                <ValueLabels valueFormatter={(v, _si, _di, c) => `${(v * 100).toFixed(0)}%|${c.isPercent}`} />
            )
            expect(
                labelDivs(container)
                    .map((d) => d.textContent)
                    .sort()
            ).toEqual(['20%|true', '40%|true', '60%|true', '80%|true'])
        })

        it('skips labels whose formatter returns an empty string', () => {
            const series: ResolvedSeries[] = [{ key: 's', label: 'S', color: '#f00', data: [10, 20, 30] }]
            const ctx = makeContext(series, { labels: ['Mon', 'Tue', 'Wed'] })
            const textByValue: Record<number, string> = { 10: '10', 20: '', 30: '30' }
            const { container } = renderInChart(ctx, <ValueLabels valueFormatter={(v) => textByValue[v]} />)
            expect(labelDivs(container).map((d) => d.textContent)).toEqual(['10', '30'])
        })
    })

    it('in percent layout, formatter receives each segment fraction (0..1), not raw data', () => {
        // Both series have non-zero values in both bands so we exercise the `raw / total`
        // division, not the trivial single-segment-per-band 100% path.
        // Band totals: Mon = 100, Tue = 100. Expected fractions: a = [0.2, 0.6], b = [0.8, 0.4].
        const series: ResolvedSeries[] = [
            { key: 'a', label: 'A', color: '#f00', data: [20, 60] },
            { key: 'b', label: 'B', color: '#0f0', data: [80, 40] },
        ]
        // Custom yScale on 0..1 (matches percent layout) so segment centers don't collide.
        const percentScales: ChartScales = {
            x: xScale,
            y: (v: number) => 368 - v * 352,
            yTicks: () => [0, 0.5, 1],
        }
        // Stacked tops per series in 0..1 space — matches d3.stackOffsetExpand output.
        const positionByKey: Record<string, number[]> = {
            a: [0.2, 0.6],
            b: [1.0, 1.0],
        }
        const resolvePositionValue: ResolveValueFn = (s, i) => positionByKey[s.key]?.[i] ?? 0
        const ctx = makeContext(series, {
            isPercent: true,
            labels: ['Mon', 'Tue'],
            scales: percentScales,
            resolvePositionValue,
        })
        const { container } = renderInChart(ctx, <ValueLabels valueFormatter={(v) => `${(v * 100).toFixed(0)}%`} />)
        expect(
            labelDivs(container)
                .map((d) => d.textContent)
                .sort()
        ).toEqual(['20%', '40%', '60%', '80%'])
    })

    describe('offset', () => {
        it('nudges a vertical above-label up by the offset', () => {
            const series: ResolvedSeries[] = [{ key: 's', label: 'S', color: '#f00', data: [50] }]
            const { container } = renderInChart(makeContext(series, { labels: ['Mon'] }), <ValueLabels offset={6} />)
            const divs = labelDivs(container)
            expect(divs).toHaveLength(1)
            expect(divs[0].style.transform).toBe('translate(-50%, -100%) translate(0px, -6px)')
        })

        it('nudges a horizontal label outward from the bar tip by the offset', () => {
            const series: ResolvedSeries[] = [{ key: 's', label: 'S', color: '#f00', data: [1] }]
            const ctx = makeContext(series, {
                axisOrientation: 'horizontal',
                labels: ['Mon'],
                scales: { x: () => 200, y: () => 400, yTicks: () => [0, 1] },
            })
            const divs = labelDivs(renderInChart(ctx, <ValueLabels offset={6} />).container)
            expect(divs).toHaveLength(1)
            expect(divs[0].style.transform).toBe('translateY(-50%) translate(6px, 0px)')
        })

        it('ignores offset for centered percent-mode labels', () => {
            const series: ResolvedSeries[] = [
                { key: 'a', label: 'A', color: '#f00', data: [20, 60] },
                { key: 'b', label: 'B', color: '#0f0', data: [80, 40] },
            ]
            const percentScales: ChartScales = { x: xScale, y: (v: number) => 368 - v * 352, yTicks: () => [0, 0.5, 1] }
            const positionByKey: Record<string, number[]> = { a: [0.2, 0.6], b: [1.0, 1.0] }
            const resolvePositionValue: ResolveValueFn = (s, i) => positionByKey[s.key]?.[i] ?? 0
            const ctx = makeContext(series, {
                isPercent: true,
                labels: ['Mon', 'Tue'],
                scales: percentScales,
                resolvePositionValue,
            })
            const divs = labelDivs(renderInChart(ctx, <ValueLabels offset={6} />).container)
            expect(divs.length).toBeGreaterThan(0)
            divs.forEach((d) => expect(d.style.transform).toBe('translate(-50%, -50%)'))
        })
    })
})
