import { cleanup, fireEvent, type RenderResult } from '@testing-library/react'
import React from 'react'

import type { BaseChartContext } from '../core/chart-context'
import { makeOverlayContext, renderOverlayInChart } from '../testing'
import { ReferenceLine, ReferenceLines } from './ReferenceLine'

const DIMENSIONS = {
    width: 800,
    height: 400,
    plotLeft: 48,
    plotTop: 16,
    plotWidth: 720,
    plotHeight: 352,
}

// Simple linear y-scale: 0 -> plotBottom (368), 100 -> plotTop (16)
const yScale = (v: number): number => 368 - (v / 100) * 352

const CONTEXT: BaseChartContext = makeOverlayContext(
    {
        x: (label: string) => (({ Mon: 100, Tue: 400, Wed: 700 }) as Record<string, number | undefined>)[label],
        y: yScale,
        yTicks: () => [0, 50, 100],
    },
    {
        dimensions: DIMENSIONS,
        labels: ['Mon', 'Tue', 'Wed'],
    }
)

function renderInChart(node: React.ReactNode, ctx: BaseChartContext = CONTEXT): RenderResult {
    return renderOverlayInChart(node, ctx)
}

function lineDiv(container: HTMLElement, side: 'top' | 'left'): HTMLDivElement | null {
    return container.querySelector<HTMLDivElement>(`div[style*="border-${side}"]`)
}

describe('ReferenceLine', () => {
    afterEach(() => cleanup())

    describe('horizontal', () => {
        it('renders null when value is not a number', () => {
            const { container } = renderInChart(<ReferenceLine value="Mon" />)
            expect(container.firstChild).toBeNull()
        })

        it('renders null when value is outside the plot bounds', () => {
            const { container } = renderInChart(<ReferenceLine value={-50} />)
            expect(container.firstChild).toBeNull()
        })

        it('renders the line at the y pixel computed from the scale', () => {
            const { container } = renderInChart(<ReferenceLine value={50} />)
            const line = lineDiv(container, 'top')
            expect(line).not.toBeNull()
            // y-scale(50) = 192; default stroke width 2 => top = 192 - 1 = 191
            expect(line!.style.top).toBe('191px')
            expect(line!.style.left).toBe('48px')
            expect(line!.style.width).toBe('720px')
        })

        it('renders the label text when provided', () => {
            const { getByText } = renderInChart(<ReferenceLine value={50} label="Target" />)
            expect(getByText('Target')).toBeTruthy()
        })

        it('appends the value to the label on hover and restores it on leave', () => {
            // value must sit inside the test scale's 0-100 range or the line renders null.
            const { getByText } = renderInChart(<ReferenceLine value={50} label="Target" />)
            const label = getByText('Target') as HTMLDivElement
            fireEvent.mouseEnter(label)
            expect(getByText('Target: 50')).toBeTruthy()
            fireEvent.mouseLeave(label)
            expect(getByText('Target')).toBeTruthy()
        })

        it('reveals the value on line hover even when the line has no text label', () => {
            const { container, getByText, queryByText } = renderInChart(<ReferenceLine value={50} />)
            expect(queryByText('50')).toBeNull() // nothing shown at rest
            const hitArea = container.querySelector('[data-attr="hog-chart-reference-line-hit-area"]')!
            expect(hitArea).not.toBeNull()
            fireEvent.mouseEnter(hitArea)
            expect(getByText('50')).toBeTruthy()
            fireEvent.mouseLeave(hitArea)
            expect(queryByText('50')).toBeNull()
        })

        it('anchors the label at the start when labelPosition="start"', () => {
            const { getByText } = renderInChart(<ReferenceLine value={50} label="T" labelPosition="start" />)
            const label = getByText('T') as HTMLDivElement
            expect(label.style.left).toBe('52px') // plotLeft + LABEL_PADDING
            expect(label.style.right).toBe('')
        })

        it('anchors the label at the end by default', () => {
            const { getByText } = renderInChart(<ReferenceLine value={50} label="T" />)
            const label = getByText('T') as HTMLDivElement
            expect(label.style.right).not.toBe('')
            expect(label.style.left).toBe('')
        })

        it('centers the label on the line when there is room', () => {
            const { getByText } = renderInChart(<ReferenceLine value={50} label="T" />)
            const label = getByText('T') as HTMLDivElement
            // y-scale(50) = 192, comfortably inside the plot, so the center sits on the line.
            expect(label.style.top).toBe('192px')
            expect(label.style.transform).toBe('translateY(-50%)')
        })

        it('clamps the label inside the plot when the line is at the top edge', () => {
            const { getByText } = renderInChart(<ReferenceLine value={100} label="T" />)
            const label = getByText('T') as HTMLDivElement
            // y-scale(100) = 16 (plotTop); center clamped down to plotTop + LABEL_HEIGHT/2 = 26.
            expect(label.style.top).toBe('26px')
        })

        it('clamps the label inside the plot when the line is at the bottom edge', () => {
            const { getByText } = renderInChart(<ReferenceLine value={0} label="T" />)
            const label = getByText('T') as HTMLDivElement
            // y-scale(0) = 368 (plotBottom); center clamped up to plotBottom - LABEL_HEIGHT/2 = 358.
            expect(label.style.top).toBe('358px')
        })

        it('renders a fill rect above the line when fillSide="above"', () => {
            const { container } = renderInChart(<ReferenceLine value={50} fillSide="above" />)
            const fill = container.querySelector<HTMLDivElement>('div[style*="background-color"]')!
            // above fill runs from plotTop down to the line y
            expect(fill.style.top).toBe('16px')
            expect(parseFloat(fill.style.height)).toBeGreaterThan(0)
        })

        it('renders a fill rect below the line when fillSide="below"', () => {
            const { container } = renderInChart(<ReferenceLine value={50} fillSide="below" />)
            const fill = container.querySelector<HTMLDivElement>('div[style*="background-color"]')!
            expect(parseFloat(fill.style.top)).toBeGreaterThan(DIMENSIONS.plotTop)
        })

        it('uses the matching yAxes scale when a yAxisId is specified', () => {
            // Primary (left) scale ranges 0-100; right axis 'y1' ranges 0-1000.
            // Rendering `value=500` on the left axis would fall outside bounds, but the
            // right axis maps it to the middle of the plot.
            const rightScale = (v: number): number => 368 - (v / 1000) * 352
            const multiAxisContext: BaseChartContext = {
                ...CONTEXT,
                scales: {
                    ...CONTEXT.scales,
                    yAxes: {
                        left: { scale: yScale, ticks: () => [0, 50, 100], position: 'left' },
                        y1: { scale: rightScale, ticks: () => [0, 500, 1000], position: 'right' },
                    },
                },
            }
            const { container } = renderInChart(<ReferenceLine value={500} yAxisId="y1" />, multiAxisContext)
            const line = lineDiv(container, 'top')
            expect(line).not.toBeNull()
            // rightScale(500) = 192; width 2 → top = 191
            expect(line!.style.top).toBe('191px')
        })

        it('falls back to the primary y-scale when yAxisId is unknown or absent', () => {
            const { container } = renderInChart(<ReferenceLine value={50} yAxisId="missing" />)
            const line = lineDiv(container, 'top')
            // Unknown axis id → default scale → same pixel as the plain `value=50` case (191px).
            expect(line!.style.top).toBe('191px')
        })
    })

    describe('vertical', () => {
        it('renders null when value is not a string', () => {
            const { container } = renderInChart(<ReferenceLine value={50} orientation="vertical" />)
            expect(container.firstChild).toBeNull()
        })

        it('renders null when label is unknown to the x-scale', () => {
            const { container } = renderInChart(<ReferenceLine value="Missing" orientation="vertical" />)
            expect(container.firstChild).toBeNull()
        })

        it('renders the line at the x pixel computed from the scale', () => {
            const { container } = renderInChart(<ReferenceLine value="Tue" orientation="vertical" />)
            const line = lineDiv(container, 'left')
            expect(line).not.toBeNull()
            // xScale('Tue') = 400; stroke width 2 => left = 400 - 1 = 399
            expect(line!.style.left).toBe('399px')
            expect(line!.style.top).toBe('16px')
            expect(line!.style.height).toBe('352px')
        })

        it('renders a fill rect to the left when fillSide="left"', () => {
            const { container } = renderInChart(<ReferenceLine value="Tue" orientation="vertical" fillSide="left" />)
            const fill = container.querySelectorAll<HTMLDivElement>('div')[0]
            expect(fill.style.left).toBe('48px')
            expect(fill.style.width).toBe('352px') // 400 - 48
        })

        it('renders a fill rect to the right when fillSide="right"', () => {
            const { container } = renderInChart(<ReferenceLine value="Tue" orientation="vertical" fillSide="right" />)
            const fill = container.querySelectorAll<HTMLDivElement>('div')[0]
            expect(fill.style.left).toBe('400px')
            expect(parseFloat(fill.style.width)).toBeGreaterThan(0)
        })
    })

    describe('axisOrientation from chart context', () => {
        // In a horizontal-axis chart, scales.y is the value scale producing x-pixels, so a
        // numeric horizontal reference line is drawn as a vertical stripe at scales.y(value).
        const horizontalAxisContext: BaseChartContext = makeOverlayContext(
            { ...CONTEXT.scales },
            { dimensions: DIMENSIONS, labels: ['Mon', 'Tue', 'Wed'], axisOrientation: 'horizontal' }
        )

        it('defaults to the chart axis orientation (horizontal) without an explicit prop', () => {
            const { container } = renderInChart(<ReferenceLine value={50} />, horizontalAxisContext)
            // Drawn as a vertical stripe (left border) at scales.y(50) = 192; width 2 → left = 191.
            const line = lineDiv(container, 'left')
            expect(line).not.toBeNull()
            expect(line!.style.left).toBe('191px')
            // ...and NOT as a horizontal (top border) line.
            expect(lineDiv(container, 'top')).toBeNull()
        })

        it('renders a horizontal line in a vertical-axis chart by default', () => {
            // CONTEXT defaults axis.orientation to 'vertical'.
            const { container } = renderInChart(<ReferenceLine value={50} />)
            expect(lineDiv(container, 'top')).not.toBeNull()
            expect(lineDiv(container, 'left')).toBeNull()
        })

        it('lets an explicit axisOrientation prop override the context', () => {
            const { container } = renderInChart(
                <ReferenceLine value={50} axisOrientation="vertical" />,
                horizontalAxisContext
            )
            // Forced back to a horizontal (top border) line despite the horizontal-axis context.
            expect(lineDiv(container, 'top')).not.toBeNull()
            expect(lineDiv(container, 'left')).toBeNull()
        })
    })

    describe('variants and style overrides', () => {
        it.each([
            ['goal (default)', undefined, 'dashed', '2px'],
            ['alert', 'alert' as const, 'dashed', '2px'],
            ['marker', 'marker' as const, 'solid', '1px'],
        ])('variant %s renders expected stroke style', (_name, variant, expectedStyle, expectedWidth) => {
            const { container } = renderInChart(<ReferenceLine value={50} variant={variant} />)
            const line = lineDiv(container, 'top')!
            expect(line.style.borderTopStyle).toBe(expectedStyle)
            expect(line.style.borderTopWidth).toBe(expectedWidth)
        })

        it('applies an explicit style.stroke override', () => {
            const { container } = renderInChart(<ReferenceLine value={50} style={{ stroke: 'solid' }} />)
            const line = lineDiv(container, 'top')!
            expect(line.style.borderTopStyle).toBe('solid')
        })

        it('applies an explicit style.width override', () => {
            const { container } = renderInChart(<ReferenceLine value={50} style={{ width: 4 }} />)
            const line = lineDiv(container, 'top')!
            expect(line.style.borderTopWidth).toBe('4px')
        })

        // var() literals are deliberately not in this table: jsdom doesn't store CSS
        // custom properties and reads back as the empty string, so we can only assert
        // the no-crash path for var() — see the dedicated test below. Real browsers
        // resolve the variable natively.
        it.each([
            ['hex literal', '#ff8800'],
            ['rgb literal', 'rgb(10, 20, 30)'],
        ])('passes %s color through to inline styles without resolving', (_name, color) => {
            const { container } = renderInChart(<ReferenceLine value={50} style={{ color }} />)
            const line = lineDiv(container, 'top')!
            expect(line.style.borderTopColor).toBe(color)
        })

        it('renders a var(...) color without throwing (browser-resolved at runtime)', () => {
            const { container } = renderInChart(<ReferenceLine value={50} style={{ color: 'var(--danger)' }} />)
            const line = lineDiv(container, 'top')
            // We're asserting the component mounts and exposes the line — the actual color
            // resolution happens in the browser's CSSOM, which jsdom doesn't implement.
            expect(line).not.toBeNull()
        })

        it('uses style.fillColor when provided, falling back to color', () => {
            const { container } = renderInChart(
                <ReferenceLine
                    value={50}
                    fillSide="above"
                    style={{ color: '#111', fillColor: 'rgb(50, 60, 70)', fillOpacity: 0.3 }}
                />
            )
            const fill = container.querySelectorAll<HTMLDivElement>('div')[0]
            expect(fill.style.backgroundColor).toBe('rgb(50, 60, 70)')
            expect(fill.style.opacity).toBe('0.3')
        })
    })

    describe('ReferenceLines wrapper', () => {
        it('renders each props entry as its own line', () => {
            const { getByText } = renderInChart(
                <ReferenceLines
                    lines={[
                        { value: 25, label: 'Low' },
                        { value: 75, label: 'High' },
                    ]}
                />
            )
            expect(getByText('Low')).toBeTruthy()
            expect(getByText('High')).toBeTruthy()
        })

        it('omits lines whose value is out of plot bounds', () => {
            const { queryByText } = renderInChart(
                <ReferenceLines
                    lines={[
                        { value: 50, label: 'Visible' },
                        { value: -9999, label: 'Hidden' },
                    ]}
                />
            )
            expect(queryByText('Visible')).toBeTruthy()
            expect(queryByText('Hidden')).toBeNull()
        })
    })
})
