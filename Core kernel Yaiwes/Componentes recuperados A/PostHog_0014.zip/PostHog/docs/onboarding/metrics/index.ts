export { OpenTelemetryInstallation } from './opentelemetry'
