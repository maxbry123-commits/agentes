import { useMDXComponents } from 'scenes/onboarding/shared/OnboardingDocsContentWrapper'

export const PythonEventCapture = (): JSX.Element => {
    const { Markdown, CodeBlock, dedent } = useMDXComponents()

    return (
        <>
            <Markdown>
                Capture custom events by calling the `capture` method with an event name and properties:
            </Markdown>
            <CodeBlock
                blocks={[
                    {
                        language: 'python',
                        file: 'Python',
                        code: dedent`
                            import posthog
                            posthog.capture('user_signed_up', distinct_id='user_123', properties={'example_property': 'example_value'})
                        `,
                    },
                ]}
            />
        </>
    )
}
