import { OnboardingComponentsContext, createInstallation } from 'scenes/onboarding/shared/OnboardingDocsContentWrapper'

import { StepDefinition } from '../steps'
import { SDK_DEFAULTS_DATE } from './_snippets/sdkDefaults'

export const getRemixInstallSteps = (ctx: OnboardingComponentsContext): StepDefinition[] => {
    const { CodeBlock, Markdown, CalloutBox, dedent } = ctx

    return [
        {
            title: 'Install the package',
            badge: 'required',
            content: (
                <>
                    <CalloutBox type="fyi" title="Remix version">
                        <Markdown>
                            This guide is for Remix v2. For Remix v3, see our [React Router v7
                            docs](https://posthog.com/docs/libraries/react-router).
                        </Markdown>
                    </CalloutBox>
                    <Markdown>Install the PostHog JavaScript library using your package manager:</Markdown>
                    <CodeBlock
                        blocks={[
                            {
                                language: 'bash',
                                file: 'npm',
                                code: dedent`
                                    npm install posthog-js
                                `,
                            },
                            {
                                language: 'bash',
                                file: 'yarn',
                                code: dedent`
                                    yarn add posthog-js
                                `,
                            },
                            {
                                language: 'bash',
                                file: 'pnpm',
                                code: dedent`
                                    pnpm add posthog-js
                                `,
                            },
                            {
                                language: 'bash',
                                file: 'bun',
                                code: dedent`
                                    bun add posthog-js
                                `,
                            },
                        ]}
                    />
                </>
            ),
        },
        {
            title: 'Configure Vite',
            badge: 'required',
            content: (
                <>
                    <Markdown>
                        Add `posthog-js` and `@posthog/react` to `ssr.noExternal` in your `vite.config.ts` so they get
                        bundled for SSR:
                    </Markdown>
                    <CodeBlock
                        blocks={[
                            {
                                language: 'typescript',
                                file: 'vite.config.ts',
                                code: dedent`
                                    // ... imports and rest of config

                                    export default defineConfig({
                                      plugins: [
                                        remix({
                                          future: {
                                            v3_fetcherPersist: true,
                                            v3_relativeSplatPath: true,
                                            v3_throwAbortReason: true,
                                            v3_singleFetch: true,
                                            v3_lazyRouteDiscovery: true,
                                          },
                                        }),
                                        tsconfigPaths(),
                                      ],
                                      ssr: {
                                        noExternal: ["posthog-js", "@posthog/react"],
                                      },
                                    });
                                `,
                            },
                        ]}
                    />
                </>
            ),
        },
        {
            title: 'Create a provider',
            badge: 'required',
            content: (
                <>
                    <Markdown>
                        Create a `provider.tsx` file in the app folder. Set up the PostHog provider to initialize after
                        hydration:
                    </Markdown>
                    <CodeBlock
                        blocks={[
                            {
                                language: 'typescript',
                                file: 'app/provider.tsx',
                                code: dedent`
                                    import { useEffect, useState } from "react";
                                    import posthog from "posthog-js";
                                    import { PostHogProvider } from "@posthog/react";

                                    export function PHProvider({ children }: { children: React.ReactNode }) {
                                      const [hydrated, setHydrated] = useState(false);

                                      useEffect(() => {
                                        posthog.init("<ph_project_token>", {
                                          api_host: "<ph_client_api_host>",
                                          defaults: "${SDK_DEFAULTS_DATE}"
                                        });

                                        setHydrated(true);
                                      }, []);

                                      if (!hydrated) return <>{children}</>;
                                      return <PostHogProvider client={posthog}>{children}</PostHogProvider>;
                                    }
                                `,
                            },
                        ]}
                    />
                </>
            ),
        },
        {
            title: 'Wrap your app',
            badge: 'required',
            content: (
                <>
                    <Markdown>
                        Import the `PHProvider` component in your `app/root.tsx` file and use it to wrap your app:
                    </Markdown>
                    <CodeBlock
                        blocks={[
                            {
                                language: 'typescript',
                                file: 'app/root.tsx',
                                code: dedent`
                                    // ... imports
                                    import { PHProvider } from "./provider";

                                    // ... links, meta, etc.

                                    export function Layout({ children }: { children: React.ReactNode }) {
                                      return (
                                        <html lang="en">
                                          <head>
                                            <meta charSet="utf-8" />
                                            <meta name="viewport" content="width=device-width, initial-scale=1" />
                                            <Meta />
                                            <Links />
                                          </head>
                                          <body>
                                            <PHProvider>
                                              {children}
                                              <ScrollRestoration />
                                              <Scripts />
                                            </PHProvider>
                                          </body>
                                        </html>
                                      );
                                    }

                                    export default function App() {
                                      return <Outlet />;
                                    }
                                `,
                            },
                        ]}
                    />
                </>
            ),
        },
    ]
}

export const getRemixEventStep = (ctx: OnboardingComponentsContext): StepDefinition => {
    const { snippets } = ctx

    const JSEventCapture = snippets?.JSEventCapture

    return {
        title: 'Send events',
        badge: undefined,
        content: <>{JSEventCapture && <JSEventCapture />}</>,
    }
}

export const getRemixSteps = (ctx: OnboardingComponentsContext): StepDefinition[] => [
    ...getRemixInstallSteps(ctx),
    getRemixEventStep(ctx),
]

export const RemixInstallation = createInstallation(getRemixSteps)
