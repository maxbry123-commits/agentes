import { OnboardingComponentsContext, createInstallation } from 'scenes/onboarding/shared/OnboardingDocsContentWrapper'

import { StepDefinition } from '../steps'

export const getElixirSteps = (ctx: OnboardingComponentsContext): StepDefinition[] => {
    const { CodeBlock, Markdown, dedent } = ctx

    return [
        {
            title: 'Install',
            badge: 'required',
            content: (
                <>
                    <Markdown>Add the PostHog Elixir library to your `mix.exs` dependencies:</Markdown>
                    <CodeBlock
                        blocks={[
                            {
                                language: 'elixir',
                                file: 'mix.exs',
                                code: dedent`
                                def deps do
                                    [
                                        {:posthog, "~> 2.0"}
                                    ]
                                end
                            `,
                            },
                        ]}
                    />
                </>
            ),
        },
        {
            title: 'Configure',
            badge: 'required',
            content: (
                <>
                    <Markdown>Add your PostHog configuration to your config file:</Markdown>
                    <CodeBlock
                        blocks={[
                            {
                                language: 'elixir',
                                file: 'config/config.exs',
                                code: dedent`
                                config :posthog,
                                    api_host: "<ph_client_api_host>",
                                    api_key: "<ph_project_token>"
                            `,
                            },
                        ]}
                    />
                </>
            ),
        },
        {
            title: 'Send events',
            badge: 'recommended',
            content: (
                <>
                    <Markdown>Once installed, you can manually send events to test your integration:</Markdown>
                    <CodeBlock
                        blocks={[
                            {
                                language: 'elixir',
                                file: 'Elixir',
                                code: dedent`
                                PostHog.capture("user_signed_up", %{
                                    distinct_id: "distinct_id_of_the_user",
                                    login_type: "email",
                                    is_free_trial: true
                                })
                            `,
                            },
                        ]}
                    />
                </>
            ),
        },
    ]
}

export const ElixirInstallation = createInstallation(getElixirSteps)
