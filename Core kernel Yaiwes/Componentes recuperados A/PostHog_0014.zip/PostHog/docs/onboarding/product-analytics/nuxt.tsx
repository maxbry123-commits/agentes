import { OnboardingComponentsContext, createInstallation } from 'scenes/onboarding/shared/OnboardingDocsContentWrapper'

import { StepDefinition } from '../steps'
import { SDK_DEFAULTS_DATE } from './_snippets/sdkDefaults'

export const getNuxtClientSteps = (ctx: OnboardingComponentsContext): StepDefinition[] => {
    const { CodeBlock, Markdown, CalloutBox, dedent } = ctx

    return [
        {
            title: 'Install the package',
            badge: 'required',
            content: (
                <>
                    <Markdown>Install the PostHog JavaScript library using your package manager:</Markdown>
                    <CodeBlock
                        blocks={[
                            {
                                language: 'bash',
                                file: 'npm',
                                code: dedent`
                                    npm install posthog-js
                                `,
                            },
                            {
                                language: 'bash',
                                file: 'yarn',
                                code: dedent`
                                    yarn add posthog-js
                                `,
                            },
                            {
                                language: 'bash',
                                file: 'pnpm',
                                code: dedent`
                                    pnpm add posthog-js
                                `,
                            },
                            {
                                language: 'bash',
                                file: 'bun',
                                code: dedent`
                                    bun add posthog-js
                                `,
                            },
                        ]}
                    />
                    <CalloutBox type="fyi" title="Nuxt version">
                        <Markdown>
                            This guide is for Nuxt v3.0 and above. For Nuxt v2.16 and below, see our [Nuxt
                            docs](https://posthog.com/docs/libraries/nuxt-js#nuxt-v216-and-below).
                        </Markdown>
                    </CalloutBox>
                </>
            ),
        },
        {
            title: 'Add environment variables',
            badge: 'required',
            content: (
                <>
                    <Markdown>Add your PostHog project token and host to your `nuxt.config.js` file:</Markdown>
                    <CodeBlock
                        blocks={[
                            {
                                language: 'javascript',
                                file: 'nuxt.config.js',
                                code: dedent`
                                    export default defineNuxtConfig({
                                      runtimeConfig: {
                                        public: {
                                          posthogPublicKey: '<ph_project_token>',
                                          posthogHost: '<ph_client_api_host>',
                                          posthogDefaults: '${SDK_DEFAULTS_DATE}'
                                        }
                                      }
                                    })
                                `,
                            },
                        ]}
                    />
                </>
            ),
        },
        {
            title: 'Create a plugin',
            badge: 'required',
            content: (
                <>
                    <Markdown>
                        Create a new plugin by creating a new file `posthog.client.js` in your plugins directory:
                    </Markdown>
                    <CodeBlock
                        blocks={[
                            {
                                language: 'javascript',
                                file: 'plugins/posthog.client.js',
                                code: dedent`
                                    import { defineNuxtPlugin } from '#app'
                                    import posthog from 'posthog-js'

                                    export default defineNuxtPlugin(nuxtApp => {
                                      const runtimeConfig = useRuntimeConfig();
                                      const posthogClient = posthog.init(runtimeConfig.public.posthogPublicKey, {
                                        api_host: runtimeConfig.public.posthogHost,
                                        defaults: runtimeConfig.public.posthogDefaults,
                                        loaded: (posthog) => {
                                          if (import.meta.env.MODE === 'development') posthog.debug();
                                        }
                                      })

                                      return {
                                        provide: {
                                          posthog: () => posthogClient
                                        }
                                      }
                                    })
                                `,
                            },
                        ]}
                    />
                </>
            ),
        },
    ]
}

export const getNuxtServerSteps = (ctx: OnboardingComponentsContext): StepDefinition[] => {
    const { CodeBlock, Markdown, dedent } = ctx

    return [
        {
            title: 'Server-side setup',
            badge: 'optional',
            content: (
                <>
                    <Markdown>
                        To capture events from server routes, install `posthog-node` and instantiate it directly. You
                        can also use it to evaluate feature flags on the server:
                    </Markdown>
                    <CodeBlock
                        blocks={[
                            {
                                language: 'bash',
                                file: 'npm',
                                code: dedent`
                                    npm install posthog-node
                                `,
                            },
                            {
                                language: 'bash',
                                file: 'yarn',
                                code: dedent`
                                    yarn add posthog-node
                                `,
                            },
                            {
                                language: 'bash',
                                file: 'pnpm',
                                code: dedent`
                                    pnpm add posthog-node
                                `,
                            },
                            {
                                language: 'bash',
                                file: 'bun',
                                code: dedent`
                                    bun add posthog-node
                                `,
                            },
                        ]}
                    />
                    <CodeBlock
                        blocks={[
                            {
                                language: 'javascript',
                                file: 'server/api/example.js',
                                code: dedent`
                                    import { PostHog } from 'posthog-node'

                                    export default defineEventHandler(async (event) => {
                                        const runtimeConfig = useRuntimeConfig()

                                        const posthog = new PostHog(
                                            runtimeConfig.public.posthogPublicKey,
                                            { host: runtimeConfig.public.posthogHost }
                                        )

                                        posthog.capture({
                                            distinctId: 'distinct_id_of_the_user',
                                            event: 'event_name'
                                        })

                                        await posthog.shutdown()
                                    })
                                `,
                            },
                        ]}
                    />
                </>
            ),
        },
    ]
}

export const getNuxtInstallSteps = (ctx: OnboardingComponentsContext): StepDefinition[] => [
    ...getNuxtClientSteps(ctx),
    ...getNuxtServerSteps(ctx),
]

export const getNuxtEventStep = (ctx: OnboardingComponentsContext): StepDefinition => {
    const JSEventCapture = ctx.snippets?.JSEventCapture

    return {
        title: 'Send events',
        badge: undefined,
        content: <>{JSEventCapture && <JSEventCapture />}</>,
    }
}

export const getNuxtSteps = (ctx: OnboardingComponentsContext): StepDefinition[] => [
    ...getNuxtInstallSteps(ctx),
    getNuxtEventStep(ctx),
]

export const NuxtInstallation = createInstallation(getNuxtSteps)
