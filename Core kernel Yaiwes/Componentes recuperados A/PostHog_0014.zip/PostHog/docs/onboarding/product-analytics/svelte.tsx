import { OnboardingComponentsContext, createInstallation } from 'scenes/onboarding/shared/OnboardingDocsContentWrapper'

import { StepDefinition } from '../steps'
import { SDK_DEFAULTS_DATE } from './_snippets/sdkDefaults'

export const getSvelteClientSteps = (ctx: OnboardingComponentsContext): StepDefinition[] => {
    const { CodeBlock, Markdown, CalloutBox, dedent } = ctx

    return [
        {
            title: 'Install the package',
            badge: 'required',
            content: (
                <>
                    <Markdown>Install the PostHog JavaScript library using your package manager:</Markdown>
                    <CodeBlock
                        blocks={[
                            {
                                language: 'bash',
                                file: 'npm',
                                code: dedent`
                                    npm install posthog-js
                                `,
                            },
                            {
                                language: 'bash',
                                file: 'yarn',
                                code: dedent`
                                    yarn add posthog-js
                                `,
                            },
                            {
                                language: 'bash',
                                file: 'pnpm',
                                code: dedent`
                                    pnpm add posthog-js
                                `,
                            },
                            {
                                language: 'bash',
                                file: 'bun',
                                code: dedent`
                                    bun add posthog-js
                                `,
                            },
                        ]}
                    />
                </>
            ),
        },
        {
            title: 'Initialize PostHog',
            badge: 'required',
            content: (
                <>
                    <Markdown>
                        If you haven't created a root layout already, create a new file called `+layout.js` in your
                        `src/routes` folder. Check the environment is the browser, and initialize PostHog if so:
                    </Markdown>
                    <CodeBlock
                        blocks={[
                            {
                                language: 'javascript',
                                file: 'src/routes/+layout.js',
                                code: dedent`
                                    import posthog from 'posthog-js'
                                    import { browser } from '$app/environment';
                                    import { onMount } from 'svelte';

                                    export const load = async () => {
                                      if (browser) {
                                        posthog.init(
                                          '<ph_project_token>',
                                          {
                                            api_host: '<ph_client_api_host>',
                                            defaults: '${SDK_DEFAULTS_DATE}'
                                          }
                                        )
                                      }

                                      return
                                    };
                                `,
                            },
                        ]}
                    />
                    <CalloutBox type="fyi" title="SvelteKit layout">
                        <Markdown>
                            Learn more about [SvelteKit layouts](https://kit.svelte.dev/docs/routing#layout) in the
                            official documentation.
                        </Markdown>
                    </CalloutBox>
                </>
            ),
        },
    ]
}

export const getSvelteServerSteps = (ctx: OnboardingComponentsContext): StepDefinition[] => {
    const { CodeBlock, Markdown, CalloutBox, dedent } = ctx

    return [
        {
            title: 'Server-side setup',
            badge: 'optional',
            content: (
                <>
                    <Markdown>Install `posthog-node` using your package manager:</Markdown>
                    <CodeBlock
                        blocks={[
                            {
                                language: 'bash',
                                file: 'npm',
                                code: dedent`
                                    npm install posthog-node --save
                                `,
                            },
                            {
                                language: 'bash',
                                file: 'yarn',
                                code: dedent`
                                    yarn add posthog-node
                                `,
                            },
                            {
                                language: 'bash',
                                file: 'pnpm',
                                code: dedent`
                                    pnpm add posthog-node
                                `,
                            },
                            {
                                language: 'bash',
                                file: 'bun',
                                code: dedent`
                                    bun add posthog-node
                                `,
                            },
                        ]}
                    />
                    <Markdown>
                        Then, initialize the PostHog Node client where you'd like to use it on the server side. For
                        example, in a load function:
                    </Markdown>
                    <CodeBlock
                        blocks={[
                            {
                                language: 'javascript',
                                file: 'routes/+page.server.js',
                                code: dedent`
                                    import { PostHog } from 'posthog-node';

                                    export async function load() {
                                      const posthog = new PostHog('<ph_project_token>', { host: '<ph_client_api_host>' });

                                      posthog.capture({
                                        distinctId: 'distinct_id_of_the_user',
                                        event: 'event_name',
                                      })

                                      await posthog.shutdown()
                                    }
                                `,
                            },
                        ]}
                    />
                    <CalloutBox type="fyi" title="Note">
                        <Markdown>
                            Make sure to always call `posthog.shutdown()` after capturing events from the server-side.
                            PostHog queues events into larger batches, and this call forces all batched events to be
                            flushed immediately.
                        </Markdown>
                    </CalloutBox>
                </>
            ),
        },
    ]
}

export const getSvelteInstallSteps = (ctx: OnboardingComponentsContext): StepDefinition[] => [
    ...getSvelteClientSteps(ctx),
    ...getSvelteServerSteps(ctx),
]

export const getSvelteEventStep = (ctx: OnboardingComponentsContext): StepDefinition => {
    const JSEventCapture = ctx.snippets?.JSEventCapture

    return {
        title: 'Send events',
        badge: undefined,
        content: <>{JSEventCapture && <JSEventCapture />}</>,
    }
}

export const getSvelteSteps = (ctx: OnboardingComponentsContext): StepDefinition[] => [
    ...getSvelteInstallSteps(ctx),
    getSvelteEventStep(ctx),
]

export const SvelteInstallation = createInstallation(getSvelteSteps)
