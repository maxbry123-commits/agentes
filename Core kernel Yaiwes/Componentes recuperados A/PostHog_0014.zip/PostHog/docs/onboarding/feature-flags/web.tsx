import { OnboardingComponentsContext, createInstallation } from 'scenes/onboarding/shared/OnboardingDocsContentWrapper'

import { getWebSteps as getWebStepsPA } from '../product-analytics/web'
import { StepDefinition } from '../steps'

export const getWebSteps = (ctx: OnboardingComponentsContext): StepDefinition[] => {
    const { Markdown, dedent, snippets } = ctx
    const BooleanFlag = snippets?.BooleanFlagSnippet
    const MultivariateFlag = snippets?.MultivariateFlagSnippet
    const FlagPayload = snippets?.FlagPayloadSnippet
    const OnFeatureFlagsCallback = snippets?.OnFeatureFlagsCallbackSnippet
    const ReloadFlags = snippets?.ReloadFlagsSnippet

    const installationSteps = getWebStepsPA(ctx)

    const flagSteps: StepDefinition[] = [
        {
            title: 'Use boolean feature flags',
            badge: 'required',
            content: (
                <>
                    <Markdown>
                        {dedent`
                            Check if a feature flag is enabled:
                        `}
                    </Markdown>
                    {BooleanFlag && <BooleanFlag language="javascript" />}
                </>
            ),
        },
        {
            title: 'Use multivariate feature flags',
            badge: 'optional',
            content: (
                <>
                    <Markdown>
                        {dedent`
                            For multivariate flags, check which variant the user has been assigned:
                        `}
                    </Markdown>
                    {MultivariateFlag && <MultivariateFlag language="javascript" />}
                </>
            ),
        },
        {
            title: 'Use feature flag payloads',
            badge: 'optional',
            content: (
                <>
                    <Markdown>
                        {dedent`
                            Feature flags can include payloads with additional data. Fetch the payload like this:
                        `}
                    </Markdown>
                    {FlagPayload && <FlagPayload language="javascript" />}
                </>
            ),
        },
        {
            title: 'Ensure flags are loaded',
            badge: 'optional',
            content: <>{OnFeatureFlagsCallback && <OnFeatureFlagsCallback />}</>,
        },
        {
            title: 'Reload feature flags',
            badge: 'optional',
            content: (
                <>
                    <Markdown>
                        {dedent`
                            Feature flag values are cached. If something has changed with your user and you'd like to refetch their flag values:
                        `}
                    </Markdown>
                    {ReloadFlags && <ReloadFlags language="javascript" />}
                </>
            ),
        },
        {
            title: 'Running experiments',
            badge: 'optional',
            content: (
                <Markdown>
                    {dedent`
                        Experiments run on top of our feature flags. Once you've implemented the flag in your code, you run an experiment by creating a new experiment in the PostHog dashboard.
                    `}
                </Markdown>
            ),
        },
    ]

    return [...installationSteps, ...flagSteps]
}

export const WebInstallation = createInstallation(getWebSteps)
