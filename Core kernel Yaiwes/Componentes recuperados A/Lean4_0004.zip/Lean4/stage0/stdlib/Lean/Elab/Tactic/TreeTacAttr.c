// Lean compiler output
// Module: Lean.Elab.Tactic.TreeTacAttr
// Imports: public import Lean.Meta.Tactic.Simp
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* l_Lean_Name_mkStr3(lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Meta_registerSimpAttr(lean_object*, lean_object*, lean_object*);
static const lean_string_object l___private_Lean_Elab_Tactic_TreeTacAttr_0__Std_Internal_initFn___closed__0_00___x40_Lean_Elab_Tactic_TreeTacAttr_1721268732____hygCtx___hyg_2__value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 4, .m_capacity = 4, .m_length = 3, .m_data = "Std"};
static const lean_object* l___private_Lean_Elab_Tactic_TreeTacAttr_0__Std_Internal_initFn___closed__0_00___x40_Lean_Elab_Tactic_TreeTacAttr_1721268732____hygCtx___hyg_2_ = (const lean_object*)&l___private_Lean_Elab_Tactic_TreeTacAttr_0__Std_Internal_initFn___closed__0_00___x40_Lean_Elab_Tactic_TreeTacAttr_1721268732____hygCtx___hyg_2__value;
static const lean_string_object l___private_Lean_Elab_Tactic_TreeTacAttr_0__Std_Internal_initFn___closed__1_00___x40_Lean_Elab_Tactic_TreeTacAttr_1721268732____hygCtx___hyg_2__value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 9, .m_capacity = 9, .m_length = 8, .m_data = "Internal"};
static const lean_object* l___private_Lean_Elab_Tactic_TreeTacAttr_0__Std_Internal_initFn___closed__1_00___x40_Lean_Elab_Tactic_TreeTacAttr_1721268732____hygCtx___hyg_2_ = (const lean_object*)&l___private_Lean_Elab_Tactic_TreeTacAttr_0__Std_Internal_initFn___closed__1_00___x40_Lean_Elab_Tactic_TreeTacAttr_1721268732____hygCtx___hyg_2__value;
static const lean_string_object l___private_Lean_Elab_Tactic_TreeTacAttr_0__Std_Internal_initFn___closed__2_00___x40_Lean_Elab_Tactic_TreeTacAttr_1721268732____hygCtx___hyg_2__value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 9, .m_capacity = 9, .m_length = 8, .m_data = "tree_tac"};
static const lean_object* l___private_Lean_Elab_Tactic_TreeTacAttr_0__Std_Internal_initFn___closed__2_00___x40_Lean_Elab_Tactic_TreeTacAttr_1721268732____hygCtx___hyg_2_ = (const lean_object*)&l___private_Lean_Elab_Tactic_TreeTacAttr_0__Std_Internal_initFn___closed__2_00___x40_Lean_Elab_Tactic_TreeTacAttr_1721268732____hygCtx___hyg_2__value;
static const lean_ctor_object l___private_Lean_Elab_Tactic_TreeTacAttr_0__Std_Internal_initFn___closed__3_00___x40_Lean_Elab_Tactic_TreeTacAttr_1721268732____hygCtx___hyg_2__value_aux_0 = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&l___private_Lean_Elab_Tactic_TreeTacAttr_0__Std_Internal_initFn___closed__0_00___x40_Lean_Elab_Tactic_TreeTacAttr_1721268732____hygCtx___hyg_2__value),LEAN_SCALAR_PTR_LITERAL(48, 144, 193, 124, 159, 137, 91, 218)}};
static const lean_ctor_object l___private_Lean_Elab_Tactic_TreeTacAttr_0__Std_Internal_initFn___closed__3_00___x40_Lean_Elab_Tactic_TreeTacAttr_1721268732____hygCtx___hyg_2__value_aux_1 = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&l___private_Lean_Elab_Tactic_TreeTacAttr_0__Std_Internal_initFn___closed__3_00___x40_Lean_Elab_Tactic_TreeTacAttr_1721268732____hygCtx___hyg_2__value_aux_0),((lean_object*)&l___private_Lean_Elab_Tactic_TreeTacAttr_0__Std_Internal_initFn___closed__1_00___x40_Lean_Elab_Tactic_TreeTacAttr_1721268732____hygCtx___hyg_2__value),LEAN_SCALAR_PTR_LITERAL(225, 148, 172, 135, 227, 248, 47, 24)}};
static const lean_ctor_object l___private_Lean_Elab_Tactic_TreeTacAttr_0__Std_Internal_initFn___closed__3_00___x40_Lean_Elab_Tactic_TreeTacAttr_1721268732____hygCtx___hyg_2__value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&l___private_Lean_Elab_Tactic_TreeTacAttr_0__Std_Internal_initFn___closed__3_00___x40_Lean_Elab_Tactic_TreeTacAttr_1721268732____hygCtx___hyg_2__value_aux_1),((lean_object*)&l___private_Lean_Elab_Tactic_TreeTacAttr_0__Std_Internal_initFn___closed__2_00___x40_Lean_Elab_Tactic_TreeTacAttr_1721268732____hygCtx___hyg_2__value),LEAN_SCALAR_PTR_LITERAL(243, 155, 163, 92, 201, 101, 200, 86)}};
static const lean_object* l___private_Lean_Elab_Tactic_TreeTacAttr_0__Std_Internal_initFn___closed__3_00___x40_Lean_Elab_Tactic_TreeTacAttr_1721268732____hygCtx___hyg_2_ = (const lean_object*)&l___private_Lean_Elab_Tactic_TreeTacAttr_0__Std_Internal_initFn___closed__3_00___x40_Lean_Elab_Tactic_TreeTacAttr_1721268732____hygCtx___hyg_2__value;
static const lean_string_object l___private_Lean_Elab_Tactic_TreeTacAttr_0__Std_Internal_initFn___closed__4_00___x40_Lean_Elab_Tactic_TreeTacAttr_1721268732____hygCtx___hyg_2__value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 47, .m_capacity = 47, .m_length = 46, .m_data = "simp theorems used by internal DTreeMap lemmas"};
static const lean_object* l___private_Lean_Elab_Tactic_TreeTacAttr_0__Std_Internal_initFn___closed__4_00___x40_Lean_Elab_Tactic_TreeTacAttr_1721268732____hygCtx___hyg_2_ = (const lean_object*)&l___private_Lean_Elab_Tactic_TreeTacAttr_0__Std_Internal_initFn___closed__4_00___x40_Lean_Elab_Tactic_TreeTacAttr_1721268732____hygCtx___hyg_2__value;
static const lean_string_object l___private_Lean_Elab_Tactic_TreeTacAttr_0__Std_Internal_initFn___closed__5_00___x40_Lean_Elab_Tactic_TreeTacAttr_1721268732____hygCtx___hyg_2__value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 11, .m_capacity = 11, .m_length = 10, .m_data = "treeTacExt"};
static const lean_object* l___private_Lean_Elab_Tactic_TreeTacAttr_0__Std_Internal_initFn___closed__5_00___x40_Lean_Elab_Tactic_TreeTacAttr_1721268732____hygCtx___hyg_2_ = (const lean_object*)&l___private_Lean_Elab_Tactic_TreeTacAttr_0__Std_Internal_initFn___closed__5_00___x40_Lean_Elab_Tactic_TreeTacAttr_1721268732____hygCtx___hyg_2__value;
static const lean_ctor_object l___private_Lean_Elab_Tactic_TreeTacAttr_0__Std_Internal_initFn___closed__6_00___x40_Lean_Elab_Tactic_TreeTacAttr_1721268732____hygCtx___hyg_2__value_aux_0 = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)&l___private_Lean_Elab_Tactic_TreeTacAttr_0__Std_Internal_initFn___closed__0_00___x40_Lean_Elab_Tactic_TreeTacAttr_1721268732____hygCtx___hyg_2__value),LEAN_SCALAR_PTR_LITERAL(48, 144, 193, 124, 159, 137, 91, 218)}};
static const lean_ctor_object l___private_Lean_Elab_Tactic_TreeTacAttr_0__Std_Internal_initFn___closed__6_00___x40_Lean_Elab_Tactic_TreeTacAttr_1721268732____hygCtx___hyg_2__value_aux_1 = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&l___private_Lean_Elab_Tactic_TreeTacAttr_0__Std_Internal_initFn___closed__6_00___x40_Lean_Elab_Tactic_TreeTacAttr_1721268732____hygCtx___hyg_2__value_aux_0),((lean_object*)&l___private_Lean_Elab_Tactic_TreeTacAttr_0__Std_Internal_initFn___closed__1_00___x40_Lean_Elab_Tactic_TreeTacAttr_1721268732____hygCtx___hyg_2__value),LEAN_SCALAR_PTR_LITERAL(225, 148, 172, 135, 227, 248, 47, 24)}};
static const lean_ctor_object l___private_Lean_Elab_Tactic_TreeTacAttr_0__Std_Internal_initFn___closed__6_00___x40_Lean_Elab_Tactic_TreeTacAttr_1721268732____hygCtx___hyg_2__value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*2 + 8, .m_other = 2, .m_tag = 1}, .m_objs = {((lean_object*)&l___private_Lean_Elab_Tactic_TreeTacAttr_0__Std_Internal_initFn___closed__6_00___x40_Lean_Elab_Tactic_TreeTacAttr_1721268732____hygCtx___hyg_2__value_aux_1),((lean_object*)&l___private_Lean_Elab_Tactic_TreeTacAttr_0__Std_Internal_initFn___closed__5_00___x40_Lean_Elab_Tactic_TreeTacAttr_1721268732____hygCtx___hyg_2__value),LEAN_SCALAR_PTR_LITERAL(209, 247, 26, 210, 194, 109, 18, 184)}};
static const lean_object* l___private_Lean_Elab_Tactic_TreeTacAttr_0__Std_Internal_initFn___closed__6_00___x40_Lean_Elab_Tactic_TreeTacAttr_1721268732____hygCtx___hyg_2_ = (const lean_object*)&l___private_Lean_Elab_Tactic_TreeTacAttr_0__Std_Internal_initFn___closed__6_00___x40_Lean_Elab_Tactic_TreeTacAttr_1721268732____hygCtx___hyg_2__value;
LEAN_EXPORT lean_object* l___private_Lean_Elab_Tactic_TreeTacAttr_0__Std_Internal_initFn_00___x40_Lean_Elab_Tactic_TreeTacAttr_1721268732____hygCtx___hyg_2_();
LEAN_EXPORT lean_object* l___private_Lean_Elab_Tactic_TreeTacAttr_0__Std_Internal_initFn_00___x40_Lean_Elab_Tactic_TreeTacAttr_1721268732____hygCtx___hyg_2____boxed(lean_object*);
LEAN_EXPORT lean_object* l_Std_Internal_treeTacExt;
LEAN_EXPORT lean_object* l___private_Lean_Elab_Tactic_TreeTacAttr_0__Std_Internal_initFn_00___x40_Lean_Elab_Tactic_TreeTacAttr_1721268732____hygCtx___hyg_2_(){
_start:
{
lean_object* v___x_15_; lean_object* v___x_16_; lean_object* v___x_17_; lean_object* v___x_18_; 
v___x_15_ = ((lean_object*)(l___private_Lean_Elab_Tactic_TreeTacAttr_0__Std_Internal_initFn___closed__3_00___x40_Lean_Elab_Tactic_TreeTacAttr_1721268732____hygCtx___hyg_2_));
v___x_16_ = ((lean_object*)(l___private_Lean_Elab_Tactic_TreeTacAttr_0__Std_Internal_initFn___closed__4_00___x40_Lean_Elab_Tactic_TreeTacAttr_1721268732____hygCtx___hyg_2_));
v___x_17_ = ((lean_object*)(l___private_Lean_Elab_Tactic_TreeTacAttr_0__Std_Internal_initFn___closed__6_00___x40_Lean_Elab_Tactic_TreeTacAttr_1721268732____hygCtx___hyg_2_));
v___x_18_ = l_Lean_Meta_registerSimpAttr(v___x_15_, v___x_16_, v___x_17_);
return v___x_18_;
}
}
LEAN_EXPORT lean_object* l___private_Lean_Elab_Tactic_TreeTacAttr_0__Std_Internal_initFn_00___x40_Lean_Elab_Tactic_TreeTacAttr_1721268732____hygCtx___hyg_2____boxed(lean_object* v_a_19_){
_start:
{
lean_object* v_res_20_; 
v_res_20_ = l___private_Lean_Elab_Tactic_TreeTacAttr_0__Std_Internal_initFn_00___x40_Lean_Elab_Tactic_TreeTacAttr_1721268732____hygCtx___hyg_2_();
return v_res_20_;
}
}
lean_object* runtime_initialize_Lean_Meta_Tactic_Simp(uint8_t builtin);
void lean_initialize_runtime_module();
static bool _G_runtime_initialized = false;
LEAN_EXPORT lean_object* runtime_initialize_Lean_Elab_Tactic_TreeTacAttr(uint8_t builtin) {
lean_object * res;
if (_G_runtime_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_runtime_initialized = true;
lean_initialize_runtime_module();
res = runtime_initialize_Lean_Meta_Tactic_Simp(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = l___private_Lean_Elab_Tactic_TreeTacAttr_0__Std_Internal_initFn_00___x40_Lean_Elab_Tactic_TreeTacAttr_1721268732____hygCtx___hyg_2_();
if (lean_io_result_is_error(res)) return res;
l_Std_Internal_treeTacExt = lean_io_result_get_value(res);
lean_mark_persistent(l_Std_Internal_treeTacExt);
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
static bool _G_meta_initialized = false;
LEAN_EXPORT lean_object* meta_initialize_Lean_Elab_Tactic_TreeTacAttr(uint8_t builtin) {
lean_object * res;
if (_G_meta_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_meta_initialized = true;
return lean_io_result_mk_ok(lean_box(0));
}
lean_object* initialize_Lean_Meta_Tactic_Simp(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_Lean_Elab_Tactic_TreeTacAttr(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Lean_Meta_Tactic_Simp(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = runtime_initialize_Lean_Elab_Tactic_TreeTacAttr(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = meta_initialize_Lean_Elab_Tactic_TreeTacAttr(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return initialize_Lean_Elab_Tactic_TreeTacAttr(builtin);
}
#ifdef __cplusplus
}
#endif
