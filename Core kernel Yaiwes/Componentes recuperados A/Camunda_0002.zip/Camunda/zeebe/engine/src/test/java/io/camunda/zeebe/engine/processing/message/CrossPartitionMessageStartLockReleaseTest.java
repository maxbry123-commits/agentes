/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */
package io.camunda.zeebe.engine.processing.message;

import static org.assertj.core.api.Assertions.assertThat;

import io.camunda.zeebe.engine.util.EngineRule;
import io.camunda.zeebe.model.bpmn.Bpmn;
import io.camunda.zeebe.model.bpmn.BpmnModelInstance;
import io.camunda.zeebe.protocol.Protocol;
import io.camunda.zeebe.protocol.impl.SubscriptionUtil;
import io.camunda.zeebe.protocol.record.Record;
import io.camunda.zeebe.protocol.record.RecordValue;
import io.camunda.zeebe.protocol.record.ValueType;
import io.camunda.zeebe.protocol.record.intent.JobIntent;
import io.camunda.zeebe.protocol.record.intent.MessageIntent;
import io.camunda.zeebe.protocol.record.intent.MessageStartCorrelationKeyLockReleaseIntent;
import io.camunda.zeebe.protocol.record.intent.MessageStartEventSubscriptionIntent;
import io.camunda.zeebe.protocol.record.intent.MessageStartProcessInstanceRequestIntent;
import io.camunda.zeebe.protocol.record.intent.ProcessInstanceIntent;
import io.camunda.zeebe.protocol.record.value.BpmnElementType;
import io.camunda.zeebe.protocol.record.value.MessageStartCorrelationKeyLockReleaseRecordValue;
import io.camunda.zeebe.test.util.record.RecordingExporter;
import io.camunda.zeebe.util.buffer.BufferUtil;
import java.time.Duration;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Predicate;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;

/**
 * Multi-partition behavioural pin for the pull-based correlation-key lock release. A message-start
 * instance created via the cross-partition handshake runs on {@code P_B = hash(businessId)} while
 * the correlation-key lock it holds lives on {@code P_K = hash(correlationKey)}. On holder
 * completion or termination {@code P_B} pushes a release straight to {@code P_K} (the fast path);
 * {@code P_K} also reconciles periodically as a slow-path backstop for lost pushes. These tests
 * exercise that whole loop — scheduler on {@code P_K} → query handler on {@code P_B} → release
 * reply on {@code P_K} → buffered-message pick-up — through the real inter-partition transport.
 *
 * <p>Component-level behaviour that does not need the full transport is pinned with the code it
 * belongs to and is intentionally <em>not</em> re-tested here: the scheduler's per-partition
 * batching and stateless per-tick reconciliation live in {@code
 * CrossPartitionMessageStartLockReleaseSchedulerTest}; the {@code P_B} query outcomes (active /
 * gone / banned) live in {@code MessageStartCorrelationKeyLockReleaseQueryProcessorTest}; and the
 * {@code P_K} release handler's holder-precise idempotency guard lives in {@code
 * MessageStartCorrelationKeyLockReleaseReleaseProcessorTest}. Restart / leadership recovery is a
 * property of the poll set being reconstructed from local lock state each tick (covered by the
 * scheduler unit test's reconcile case) and needs no dedicated multi-partition pin.
 *
 * <p>The constants are chosen so {@code hash(correlationKey) != hash(businessId)}; an
 * {@code @Before} precondition fails loudly if a future hash change degenerates the scenario into a
 * single-partition path.
 */
public final class CrossPartitionMessageStartLockReleaseTest {

  private static final int PARTITION_COUNT = 3;

  // hash("ck-1") → P_K=1 and hash("biz-1") → P_B=3 under PARTITION_COUNT=3, so the holder runs on a
  // different partition than the lock. Re-asserted in @Before against hash drift.
  private static final String CORRELATION_KEY = "ck-1";
  private static final String OTHER_CORRELATION_KEY = "ck-2";
  private static final String BUSINESS_ID = "biz-1";

  private static final long LONG_TTL = Duration.ofMinutes(5).toMillis();
  private static final Duration POLL_INTERVAL = Duration.ofSeconds(1);

  // Auto-completing message-start process: the holder completes on P_B on its own (the engine's job
  // client writes to the primary partition and could not complete a job living on P_B).
  private static final String AUTO_PROCESS_ID = "wf-auto";
  private static final String AUTO_MESSAGE_NAME = "auto-start-msg";
  private static final BpmnModelInstance AUTO_PROCESS =
      Bpmn.createExecutableProcess(AUTO_PROCESS_ID)
          .startEvent("autoStart")
          .message(AUTO_MESSAGE_NAME)
          .endEvent()
          .done();

  // Message-start process with a service task: the holder stays active on P_B until banned.
  private static final String SERVICE_PROCESS_ID = "wf-svc";
  private static final String SERVICE_MESSAGE_NAME = "svc-start-msg";
  private static final BpmnModelInstance SERVICE_PROCESS =
      Bpmn.createExecutableProcess(SERVICE_PROCESS_ID)
          .startEvent("svcStart")
          .message(SERVICE_MESSAGE_NAME)
          .serviceTask("task", t -> t.zeebeJobType("test"))
          .endEvent()
          .done();

  // None-start process used only to keep a businessId actively held by a *different* instance while
  // the original holder has already completed (the precise-release-under-reuse scenario).
  private static final String HOLD_PROCESS_ID = "wf-hold";
  private static final BpmnModelInstance HOLD_PROCESS =
      Bpmn.createExecutableProcess(HOLD_PROCESS_ID)
          .startEvent("holdStart")
          .serviceTask("holdTask", t -> t.zeebeJobType("hold"))
          .endEvent()
          .done();

  // Dual-start process on a *single* bpmnProcessId: the message-start path parks on a service task
  // (the cross-partition holder stays active), while the none-start path parks on a service task so
  // a second instance of the SAME process definition can actively hold the businessId. Needed
  // because businessId uniqueness is scoped per (businessId, processDefinitionId, tenantId) — a
  // different process could not contend for the same businessId.
  private static final String CONTENDED_PROCESS_ID = "wf-contended";
  private static final String CONTENDED_MESSAGE_NAME = "contended-start-msg";
  private static final BpmnModelInstance CONTENDED_PROCESS = contendedProcess();

  @Rule
  public final EngineRule engine =
      EngineRule.multiplePartition(PARTITION_COUNT)
          .withEngineConfig(
              config ->
                  config
                      .setBusinessIdUniquenessEnabled(true)
                      .setMessageStartLockReleasePollInterval(POLL_INTERVAL));

  private static BpmnModelInstance contendedProcess() {
    final var process = Bpmn.createExecutableProcess(CONTENDED_PROCESS_ID);
    // the message-start holder parks on a job so it stays active: it must not auto-complete, which
    // would push its own release immediately (before the contender exists), a separately covered
    // path. Deferring the release to the poll (via ban) lets the contender take the businessId
    // first.
    process
        .startEvent("contendedMsgStart")
        .message(CONTENDED_MESSAGE_NAME)
        .serviceTask("contendedMsgTask", t -> t.zeebeJobType("hold"))
        .endEvent();
    process
        .startEvent("contendedNoneStart")
        .serviceTask("contendedTask", t -> t.zeebeJobType("hold"))
        .endEvent();
    return process.done();
  }

  @Before
  public void assertCrossPartitionRouting() {
    assertThat(partitionFor(CORRELATION_KEY))
        .as(
            "CORRELATION_KEY (%s) and BUSINESS_ID (%s) must hash to different partitions so the"
                + " cross-partition lock-release loop is actually exercised",
            CORRELATION_KEY, BUSINESS_ID)
        .isNotEqualTo(partitionFor(BUSINESS_ID));
  }

  @Test
  public void shouldWriteHolderOriginOnPBButNotOnPKForCrossPartitionStart() {
    // given a cross-partition start whose holder stays active on P_B (service task) while the
    // correlation-key lock lives on P_K
    deployAndAwaitStartSubscriptions(SERVICE_PROCESS, SERVICE_MESSAGE_NAME);
    publishStart(SERVICE_MESSAGE_NAME, CORRELATION_KEY, BUSINESS_ID);
    final long holderKey = awaitHolderActivating(SERVICE_PROCESS_ID);
    // holder active on P_B (its local STARTED applied) and the STARTED reply consumed on P_K
    awaitHolderJobCreated(holderKey);
    awaitMessageConsumedOnPK(SERVICE_MESSAGE_NAME);

    // then the holder-origin entry exists on P_B (where the holder lives), keyed by the holder PI
    // and carrying the lock coordinates plus a messageKey that addresses P_K
    final var originOnPB =
        engine
            .getProcessingState(partitionFor(BUSINESS_ID))
            .getMessageState()
            .getCrossPartitionStartHolderOrigin(holderKey);
    assertThat(originOnPB).as("the holder partition records the origin entry").isNotNull();
    assertThat(BufferUtil.bufferAsString(originOnPB.getBpmnProcessIdBuffer()))
        .isEqualTo(SERVICE_PROCESS_ID);
    assertThat(BufferUtil.bufferAsString(originOnPB.getCorrelationKeyBuffer()))
        .isEqualTo(CORRELATION_KEY);
    assertThat(Protocol.decodePartitionId(originOnPB.getMessageKey()))
        .as("the stored messageKey addresses P_K")
        .isEqualTo(partitionFor(CORRELATION_KEY));

    // and no entry is written on P_K, where the same STARTED reply is applied
    assertThat(
            engine
                .getProcessingState(partitionFor(CORRELATION_KEY))
                .getMessageState()
                .getCrossPartitionStartHolderOrigin(holderKey))
        .as("the lock partition never records a holder-origin entry")
        .isNull();
  }

  @Test
  public void shouldReleaseLockAndStartBufferedMessageWhenHolderCompletesOnPB() {
    // given a cross-partition start: the holder is created (and auto-completes) on P_B and the
    // correlation-key lock is written on P_K
    deployAndAwaitStartSubscriptions(AUTO_PROCESS, AUTO_MESSAGE_NAME);
    publishStart(AUTO_MESSAGE_NAME, CORRELATION_KEY, BUSINESS_ID);
    final long holderKey = awaitHolderActivating(AUTO_PROCESS_ID);
    awaitMessageConsumedOnPK(AUTO_MESSAGE_NAME);

    // and a second publish with the same correlation key (no businessId) is buffered behind the
    // lock
    publishStart(AUTO_MESSAGE_NAME, CORRELATION_KEY, null);

    // and the holder completes on P_B
    awaitHolderCompleted(AUTO_PROCESS_ID);

    // when the release poll fires
    engine.increaseTime(POLL_INTERVAL.multipliedBy(2));

    // then P_K releases the lock and picks up the buffered message, starting a fresh PI on P_K
    final var pickedUp =
        RecordingExporter.processInstanceRecords(ProcessInstanceIntent.ELEMENT_ACTIVATING)
            .withBpmnProcessId(AUTO_PROCESS_ID)
            .withElementType(BpmnElementType.PROCESS)
            .filter(r -> r.getValue().getProcessInstanceKey() != holderKey)
            .getFirst();
    assertThat(Protocol.decodePartitionId(pickedUp.getValue().getProcessInstanceKey()))
        .as("the buffered message is picked up and started on P_K after the lock is released")
        .isEqualTo(partitionFor(CORRELATION_KEY));
  }

  @Test
  public void shouldReleaseCompletedHolderExactlyOnceEvenThoughReconciliationPollAlsoRuns() {
    // Idempotency pin for push × poll coexistence: with the poll enabled, a lock that the
    // completion push has already released must not be released a second time when a later
    // reconciliation poll runs. P_K must emit exactly one RELEASED for the holder and re-drive the
    // buffered message exactly once; the holder-precise guard on the release handler makes the
    // redundant poll a no-op.
    deployAndAwaitStartSubscriptions(AUTO_PROCESS, AUTO_MESSAGE_NAME);

    // given a cross-partition start — holder created (and auto-completing) on P_B, correlation-key
    // lock on P_K — with a same-key message buffered behind that lock
    publishStart(AUTO_MESSAGE_NAME, CORRELATION_KEY, BUSINESS_ID);
    final long firstHolderKey = awaitHolderActivating(AUTO_PROCESS_ID);
    awaitMessageConsumedOnPK(AUTO_MESSAGE_NAME);
    publishStart(AUTO_MESSAGE_NAME, CORRELATION_KEY, null);

    // and the completion push has already released the lock, so the poll can only ever act on an
    // already-released lock
    awaitLockReleasedFor(firstHolderKey);

    // when the reconciliation poll then runs
    engine.increaseTime(POLL_INTERVAL.multipliedBy(2));

    // then, observed through a sentinel that bounds the record stream just past the poll tick (a
    // second holder driven to completion; not part of the scenario — see the helper)
    final var releasesThroughSentinel = awaitReleasesThroughPollSentinel();

    // the first holder's lock is released exactly once — the poll did not release it again
    final long releasesForFirstHolder =
        releasesThroughSentinel.stream().filter(r -> holderHasKey(r, firstHolderKey)).count();
    assertThat(releasesForFirstHolder)
        .as("a completed holder's lock is released exactly once, even with the poll running")
        .isEqualTo(1L);

    // and the buffered message is re-driven exactly once: a single pick-up PI started on P_K within
    // the same sentinel-bounded window (both holders live on P_B, so they are not pick-ups)
    final long pickUps =
        RecordingExporter.records()
            .limit(nthReleased(2))
            .processInstanceRecords()
            .withBpmnProcessId(AUTO_PROCESS_ID)
            .withElementType(BpmnElementType.PROCESS)
            .withIntent(ProcessInstanceIntent.ELEMENT_ACTIVATING)
            .filter(
                r ->
                    Protocol.decodePartitionId(r.getValue().getProcessInstanceKey())
                        == partitionFor(CORRELATION_KEY))
            .count();
    assertThat(pickUps).as("the buffered message is re-driven exactly once").isEqualTo(1L);
  }

  @Test
  public void shouldReRouteBufferedCrossPartitionBusinessIdMessageThroughPBWhenLockReleased() {
    // Pins the cross-partition routing of the *buffered-message pick-up* path. A second publish
    // with
    // the same correlation key but a businessId that hashes to P_B != P_K is buffered behind the
    // lock. When the holder completes and the lock is released, that buffered message must be
    // re-routed through the cross-partition handshake to P_B (its businessId's partition) — exactly
    // as the original live publish was — and NOT started locally on P_K. Starting it locally would
    // bypass P_B's uniqueness check and violate the invariant "every active root PI carrying a
    // businessId lives on P_B = hash(businessId)".
    deployAndAwaitStartSubscriptions(AUTO_PROCESS, AUTO_MESSAGE_NAME);

    // given a cross-partition start: holder created (and auto-completes) on P_B, lock on P_K
    publishStart(AUTO_MESSAGE_NAME, CORRELATION_KEY, BUSINESS_ID);
    final long holderKey = awaitHolderActivating(AUTO_PROCESS_ID);
    awaitMessageConsumedOnPK(AUTO_MESSAGE_NAME);

    // and a second publish with the same correlation key AND a cross-partition businessId buffered
    // behind the lock
    publishStart(AUTO_MESSAGE_NAME, CORRELATION_KEY, BUSINESS_ID);

    // and the holder completes on P_B, freeing the businessId
    awaitHolderCompleted(AUTO_PROCESS_ID);

    // when the release poll fires and P_K picks up the buffered message
    engine.increaseTime(POLL_INTERVAL.multipliedBy(2));

    // then the picked-up instance must run on P_B (re-routed through the handshake), not on P_K
    final var pickedUp =
        RecordingExporter.processInstanceRecords(ProcessInstanceIntent.ELEMENT_ACTIVATING)
            .withBpmnProcessId(AUTO_PROCESS_ID)
            .withElementType(BpmnElementType.PROCESS)
            .filter(r -> r.getValue().getProcessInstanceKey() != holderKey)
            .getFirst();
    assertThat(Protocol.decodePartitionId(pickedUp.getValue().getProcessInstanceKey()))
        .as(
            "a buffered cross-partition-businessId message must be re-routed to P_B on pick-up, not"
                + " started locally on P_K")
        .isEqualTo(partitionFor(BUSINESS_ID));
  }

  @Test
  public void shouldNotReleaseLockWhileHolderIsStillActiveOnPB() {
    // given a cross-partition start whose holder stays active on P_B (service task)
    deployAndAwaitStartSubscriptions(SERVICE_PROCESS, SERVICE_MESSAGE_NAME);
    publishStart(SERVICE_MESSAGE_NAME, CORRELATION_KEY, BUSINESS_ID);
    final long holderKey = awaitHolderActivating(SERVICE_PROCESS_ID);
    awaitHolderJobCreated(holderKey);
    awaitMessageConsumedOnPK(SERVICE_MESSAGE_NAME);

    // and a second same-correlation-key publish buffered behind the lock
    publishStart(SERVICE_MESSAGE_NAME, CORRELATION_KEY, null);

    // when the reconciliation poll fires, then fires again on the next tick
    engine.increaseTime(POLL_INTERVAL.multipliedBy(2));
    awaitQueryRounds(1);
    engine.increaseTime(POLL_INTERVAL.multipliedBy(2));

    // then a SECOND query round is observed — which can only happen if the lock still exists, i.e.
    // round 1 did not release the still-active holder. This re-query is the fence that proves the
    // lock survived a full poll round (a wrongful release would have dropped the lock, so no second
    // query would ever be sent and this await would time out).
    awaitQueryRounds(2);

    // and no RELEASE / RELEASED was ever produced for the active holder, up to the second round
    final long releases =
        RecordingExporter.records()
            .limit(nthQueried(2))
            .filter(
                r ->
                    r.getValueType() == ValueType.MESSAGE_START_CORRELATION_KEY_LOCK_RELEASE
                        && (r.getIntent() == MessageStartCorrelationKeyLockReleaseIntent.RELEASE
                            || r.getIntent()
                                == MessageStartCorrelationKeyLockReleaseIntent.RELEASED))
            .count();
    assertThat(releases).as("an active holder is never released").isZero();

    // and the buffered message stays buffered — only the holder PI was ever activated
    final long activations =
        RecordingExporter.records()
            .limit(nthQueried(2))
            .processInstanceRecords()
            .withBpmnProcessId(SERVICE_PROCESS_ID)
            .withElementType(BpmnElementType.PROCESS)
            .withIntent(ProcessInstanceIntent.ELEMENT_ACTIVATING)
            .count();
    assertThat(activations)
        .as("the buffered message stays buffered while the holder is active")
        .isEqualTo(1L);
  }

  @Test
  public void shouldReleaseLockWhenHolderIsBannedOnPB() {
    // given a cross-partition start whose holder is active on P_B, with a second message buffered
    deployAndAwaitStartSubscriptions(SERVICE_PROCESS, SERVICE_MESSAGE_NAME);
    publishStart(SERVICE_MESSAGE_NAME, CORRELATION_KEY, BUSINESS_ID);
    final long holderKey = awaitHolderActivating(SERVICE_PROCESS_ID);
    awaitHolderJobCreated(holderKey);
    awaitMessageConsumedOnPK(SERVICE_MESSAGE_NAME);
    publishStart(SERVICE_MESSAGE_NAME, CORRELATION_KEY, null);

    // and the holder is banned on P_B (a stuck holder must not block its correlation key forever)
    engine.banInstanceInNewTransaction(partitionFor(BUSINESS_ID), holderKey);

    // when the release poll fires
    engine.increaseTime(POLL_INTERVAL.multipliedBy(2));

    // then the banned holder is treated as gone, the lock is released, and the buffered message
    // starts on P_K
    final var pickedUp =
        RecordingExporter.processInstanceRecords(ProcessInstanceIntent.ELEMENT_ACTIVATING)
            .withBpmnProcessId(SERVICE_PROCESS_ID)
            .withElementType(BpmnElementType.PROCESS)
            .filter(r -> r.getValue().getProcessInstanceKey() != holderKey)
            .getFirst();
    assertThat(Protocol.decodePartitionId(pickedUp.getValue().getProcessInstanceKey()))
        .as("a banned holder releases the lock and the buffered message starts on P_K")
        .isEqualTo(partitionFor(CORRELATION_KEY));
  }

  @Test
  public void shouldDeleteHolderOriginDuringReconciliationWhenHolderBanned() {
    // A holder that vanishes without completing — here, banned on P_B — never runs the completion
    // push, so the push path never drops its holder-origin entry. The reconciliation poll, which
    // releases the lock for such a gone holder, must also clean up the leftover origin entry, so a
    // stuck cross-partition start does not leak one entry forever.
    deployAndAwaitStartSubscriptions(SERVICE_PROCESS, SERVICE_MESSAGE_NAME);
    publishStart(SERVICE_MESSAGE_NAME, CORRELATION_KEY, BUSINESS_ID);
    final long holderKey = awaitHolderActivating(SERVICE_PROCESS_ID);
    awaitHolderJobCreated(holderKey);
    awaitMessageConsumedOnPK(SERVICE_MESSAGE_NAME);

    // guard: the origin entry exists on P_B before the holder goes away, so the assertion below
    // observes a deletion rather than an entry that was never written
    final var pBMessageState =
        engine.getProcessingState(partitionFor(BUSINESS_ID)).getMessageState();
    assertThat(pBMessageState.getCrossPartitionStartHolderOrigin(holderKey))
        .as("the holder-origin entry is written on P_B at holder creation")
        .isNotNull();

    // and the holder is banned on P_B — gone, but with no completion transition to push
    engine.banInstanceInNewTransaction(partitionFor(BUSINESS_ID), holderKey);

    // when the reconciliation poll fires
    engine.increaseTime(POLL_INTERVAL.multipliedBy(2));

    // then P_B appends a PUSHED for the gone holder (its applier drops the origin entry), on the
    // holder's own partition
    final var pushed =
        RecordingExporter.messageStartCorrelationKeyLockReleaseRecords(
                MessageStartCorrelationKeyLockReleaseIntent.PUSHED)
            .filter(r -> r.getKey() == holderKey)
            .getFirst();
    assertThat(Protocol.decodePartitionId(pushed.getKey()))
        .as("the origin cleanup is applied on P_B, the holder's partition")
        .isEqualTo(partitionFor(BUSINESS_ID));

    // and the leaked origin entry is gone
    assertThat(pBMessageState.getCrossPartitionStartHolderOrigin(holderKey))
        .as("reconciliation deletes the leftover holder-origin entry on P_B")
        .isNull();
  }

  @Test
  public void shouldReleaseCompletedHolderLockEvenWhenBusinessIdWasReusedByAnotherInstance() {
    // Pins holder-instance precision: the release polls the *specific holder instance*, not
    // businessId availability, so the lock is released once the holder completes even if a
    // different instance has since taken the same businessId. A businessId-availability poll would
    // have wrongly kept the lock held here.
    deployAndAwaitStartSubscriptions(AUTO_PROCESS, AUTO_MESSAGE_NAME);
    engine.deployment().withXmlResource(HOLD_PROCESS).deploy();

    // the original holder starts on P_B via the ask and auto-completes; the lock is on P_K
    publishStart(AUTO_MESSAGE_NAME, CORRELATION_KEY, BUSINESS_ID);
    final long holderKey = awaitHolderActivating(AUTO_PROCESS_ID);
    awaitMessageConsumedOnPK(AUTO_MESSAGE_NAME);
    publishStart(AUTO_MESSAGE_NAME, CORRELATION_KEY, null);
    awaitHolderCompleted(AUTO_PROCESS_ID);

    // a *different* instance (different process) now actively holds the same businessId on P_B
    final long reuseKey =
        engine
            .processInstance()
            .ofBpmnProcessId(HOLD_PROCESS_ID)
            .onPartition(partitionFor(BUSINESS_ID))
            .withBusinessId(BUSINESS_ID)
            .create();
    awaitHolderJobCreated(reuseKey);

    // when the release poll fires — it polls the gone holder instance, not businessId availability
    engine.increaseTime(POLL_INTERVAL.multipliedBy(2));

    // then the lock is released and the buffered message starts on P_K, despite businessId still
    // being actively held by the reuse instance
    final var pickedUp =
        RecordingExporter.processInstanceRecords(ProcessInstanceIntent.ELEMENT_ACTIVATING)
            .withBpmnProcessId(AUTO_PROCESS_ID)
            .withElementType(BpmnElementType.PROCESS)
            .filter(r -> r.getValue().getProcessInstanceKey() != holderKey)
            .getFirst();
    assertThat(Protocol.decodePartitionId(pickedUp.getValue().getProcessInstanceKey()))
        .as("a completed holder's lock is released even under businessId reuse")
        .isEqualTo(partitionFor(CORRELATION_KEY));
  }

  @Test
  public void shouldUniquenessRejectBufferedBusinessIdMessageWhenBusinessIdStillHeldAtPickUp() {
    // Severe-consequence pin for the re-routed pick-up. The buffered message must honor P_B's
    // uniqueness check, not merely land on P_B: if another instance of the SAME process still
    // actively holds the businessId on P_B when the buffered message is picked up, the re-routed
    // ask
    // must be UNIQUENESS_REJECTED and NO second instance may be created. Starting it anyway would
    // leave two active root PIs sharing one businessId — the exact corruption the cross-partition
    // routing of the pick-up exists to prevent. Uses a dual-start process so the contender shares
    // the buffered message's process definition (uniqueness is scoped per process definition).
    //
    // The release is deferred to the reconciliation poll by *banning* the holder rather than
    // completing it: a completing holder pushes its own release immediately — before the contender
    // exists, while the businessId is free — which is a separately covered path. Banning frees the
    // businessId (uniqueness excludes banned instances) while leaving the correlation-key lock for
    // the poll to release, so the contender can take the businessId before the pick-up.
    deployAndAwaitStartSubscriptions(CONTENDED_PROCESS, CONTENDED_MESSAGE_NAME);

    // the holder starts on P_B via the message-start ask and parks on a job (stays active); lock
    // P_K
    publishStart(CONTENDED_MESSAGE_NAME, CORRELATION_KEY, BUSINESS_ID);
    final long holderKey = awaitHolderActivating(CONTENDED_PROCESS_ID);
    awaitHolderJobCreated(holderKey);
    awaitMessageConsumedOnPK(CONTENDED_MESSAGE_NAME);

    // a second publish with the same correlation key AND the same businessId is buffered behind the
    // lock — it will have to be re-routed to P_B on pick-up
    publishStart(CONTENDED_MESSAGE_NAME, CORRELATION_KEY, BUSINESS_ID);

    // ban the holder: frees the businessId without completing it, so no push fires and the
    // correlation-key lock is left for the poll to release
    engine.banInstanceInNewTransaction(partitionFor(BUSINESS_ID), holderKey);

    // a *different* instance of the same process now actively holds that businessId on P_B (via the
    // none-start path that parks on a service task), so the businessId is taken again before the
    // buffered message is picked up
    final long contenderKey =
        engine
            .processInstance()
            .ofBpmnProcessId(CONTENDED_PROCESS_ID)
            .onPartition(partitionFor(BUSINESS_ID))
            .withBusinessId(BUSINESS_ID)
            .create();
    awaitHolderJobCreated(contenderKey);

    // when the release poll fires and P_K re-routes the buffered message to P_B
    engine.increaseTime(POLL_INTERVAL.multipliedBy(2));

    // then P_B rejects the re-routed ask on uniqueness (the businessId is still held by the
    // contender). The rejection applier writes no process instance, so observing it already proves
    // the buffered message did not start a duplicate; it is also the deterministic fence below.
    final var rejection =
        RecordingExporter.records()
            .withIntent(MessageStartProcessInstanceRequestIntent.UNIQUENESS_REJECTED)
            .getFirst();
    assertThat(rejection).isNotNull();
  }

  @Test
  public void shouldNotProactivelyRetryUniquenessBlockedMessageWhenAnUnrelatedLockIsReleased() {
    // Pins: when a correlation-key lock is released, only the buffered message for THAT key is
    // picked up. A publish rejected purely on businessId uniqueness (a *different* correlation key)
    // stays buffered and is NOT proactively retried by the release — it waits for its TTL or an
    // existing same-key trigger, exactly as on a single partition.
    deployAndAwaitStartSubscriptions(SERVICE_PROCESS, SERVICE_MESSAGE_NAME);

    // holder for correlation key A, businessId X — active on P_B, lock on P_K
    publishStart(SERVICE_MESSAGE_NAME, CORRELATION_KEY, BUSINESS_ID);
    final long holderKey = awaitHolderActivating(SERVICE_PROCESS_ID);
    awaitHolderJobCreated(holderKey);
    awaitMessageConsumedOnPK(SERVICE_MESSAGE_NAME);

    // a same-key (A) message buffered behind the lock — the release's rightful next pick-up
    publishStart(SERVICE_MESSAGE_NAME, CORRELATION_KEY, null);

    // a second publish with a *different* correlation key but the *same* businessId is rejected on
    // uniqueness and stays buffered — there is no cross-partition lock entry for it
    publishStart(SERVICE_MESSAGE_NAME, OTHER_CORRELATION_KEY, BUSINESS_ID);
    RecordingExporter.records()
        .withIntent(MessageStartProcessInstanceRequestIntent.UNIQUENESS_REJECTED)
        .getFirst();

    // free businessId X by banning the holder, then fire the release poll (releases the A-lock)
    engine.banInstanceInNewTransaction(partitionFor(BUSINESS_ID), holderKey);
    engine.increaseTime(POLL_INTERVAL.multipliedBy(2));

    // the lock release picks up the buffered SAME-key (A) message — a fresh PI started on P_K.
    // Observing it is the deterministic fence: by now the release has been fully processed, so any
    // (wrongful) retry of the different-key blocked message would already have been emitted too.
    final var pickedUp =
        RecordingExporter.processInstanceRecords(ProcessInstanceIntent.ELEMENT_ACTIVATING)
            .withBpmnProcessId(SERVICE_PROCESS_ID)
            .withElementType(BpmnElementType.PROCESS)
            .filter(r -> r.getValue().getProcessInstanceKey() != holderKey)
            .getFirst();
    assertThat(Protocol.decodePartitionId(pickedUp.getValue().getProcessInstanceKey()))
        .as("the same-key buffered message is picked up on P_K when the lock is released")
        .isEqualTo(partitionFor(CORRELATION_KEY));

    // but the uniqueness-blocked different-key (B) message is NOT retried by that release: up to
    // and including the A pick-up, nothing ever correlates the B correlation key
    final long blockedKeyCorrelations =
        RecordingExporter.records()
            .limit(
                r ->
                    r.getValueType() == ValueType.PROCESS_INSTANCE
                        && r.getIntent() == ProcessInstanceIntent.ELEMENT_ACTIVATING
                        && r.getKey() == pickedUp.getValue().getProcessInstanceKey())
            .messageStartEventSubscriptionRecords()
            .withIntent(MessageStartEventSubscriptionIntent.CORRELATED)
            .filter(r -> OTHER_CORRELATION_KEY.equals(r.getValue().getCorrelationKey()))
            .count();
    assertThat(blockedKeyCorrelations)
        .as("a uniqueness-blocked message is not proactively retried on an unrelated lock release")
        .isZero();
  }

  /**
   * Blocks until {@code rounds} holder-liveness query rounds (QUERIED events) have been exported.
   */
  private static void awaitQueryRounds(final int rounds) {
    RecordingExporter.messageStartCorrelationKeyLockReleaseRecords(
            MessageStartCorrelationKeyLockReleaseIntent.QUERIED)
        .limit(rounds)
        .asList();
  }

  /**
   * A merged-stream bound that stops at the {@code n}-th QUERIED event. Each call returns a fresh
   * stateful predicate, so it must not be shared across streams.
   */
  private static Predicate<Record<RecordValue>> nthQueried(final int n) {
    final var seen = new AtomicInteger();
    return r ->
        r.getIntent() == MessageStartCorrelationKeyLockReleaseIntent.QUERIED
            && seen.incrementAndGet() == n;
  }

  /**
   * A merged-stream bound that stops at the {@code n}-th RELEASED event. Each call returns a fresh
   * stateful predicate, so it must not be shared across streams.
   */
  private static Predicate<Record<RecordValue>> nthReleased(final int n) {
    final var seen = new AtomicInteger();
    return r ->
        r.getIntent() == MessageStartCorrelationKeyLockReleaseIntent.RELEASED
            && seen.incrementAndGet() == n;
  }

  private static boolean holderHasKey(
      final Record<MessageStartCorrelationKeyLockReleaseRecordValue> record, final long holderKey) {
    return record.getValue().getHolders().stream()
        .anyMatch(h -> h.getProcessInstanceKey() == holderKey);
  }

  /**
   * Waits for the completion push to release the correlation-key lock held for {@code holderKey}.
   */
  private static void awaitLockReleasedFor(final long holderKey) {
    RecordingExporter.messageStartCorrelationKeyLockReleaseRecords(
            MessageStartCorrelationKeyLockReleaseIntent.RELEASED)
        .filter(r -> holderHasKey(r, holderKey))
        .getFirst();
  }

  /**
   * Sentinel that makes the reconciliation poll's (in)action observable without waiting on the
   * absence of a record. It is not part of the scenario under test: it drives a <em>second</em>
   * cross-partition holder on the same correlation key to completion (its businessId is free again
   * now that the first holder completed), whose push emits a second RELEASED. Because P_K applies
   * release records in order, observing that second RELEASED proves the poll tick queued earlier
   * has already been fully processed — so the returned window contains every effect the poll could
   * have had on the first holder.
   *
   * @return the first two RELEASED records: the first holder's release, then the sentinel's
   */
  private List<Record<MessageStartCorrelationKeyLockReleaseRecordValue>>
      awaitReleasesThroughPollSentinel() {
    publishStart(AUTO_MESSAGE_NAME, CORRELATION_KEY, BUSINESS_ID);
    return RecordingExporter.messageStartCorrelationKeyLockReleaseRecords(
            MessageStartCorrelationKeyLockReleaseIntent.RELEASED)
        .limit(2)
        .asList();
  }

  private void deployAndAwaitStartSubscriptions(
      final BpmnModelInstance process, final String messageName) {
    engine.deployment().withXmlResource(process).deploy();
    // deploy() waits for CommandDistribution:FINISHED; additionally wait until every partition has
    // its MessageStartEventSubscription so the P_B ask handler sees its local subscription before
    // the first cross-partition request arrives (otherwise it would reply
    // NO_SUBSCRIPTION_REJECTED).
    RecordingExporter.messageStartEventSubscriptionRecords(
            MessageStartEventSubscriptionIntent.CREATED)
        .withMessageName(messageName)
        .limit(PARTITION_COUNT)
        .asList();
  }

  private void publishStart(
      final String messageName, final String correlationKey, final String businessId) {
    var builder =
        engine
            .message()
            .withName(messageName)
            .withCorrelationKey(correlationKey)
            .withTimeToLive(LONG_TTL);
    if (businessId != null) {
      builder = builder.withBusinessId(businessId);
    }
    builder.publish();
  }

  /** First PROCESS-level activation for the given process — the holder created on {@code P_B}. */
  private static long awaitHolderActivating(final String bpmnProcessId) {
    return RecordingExporter.processInstanceRecords(ProcessInstanceIntent.ELEMENT_ACTIVATING)
        .withBpmnProcessId(bpmnProcessId)
        .withElementType(BpmnElementType.PROCESS)
        .getFirst()
        .getValue()
        .getProcessInstanceKey();
  }

  private static void awaitHolderCompleted(final String bpmnProcessId) {
    RecordingExporter.processInstanceRecords(ProcessInstanceIntent.ELEMENT_COMPLETED)
        .withBpmnProcessId(bpmnProcessId)
        .withElementType(BpmnElementType.PROCESS)
        .getFirst();
  }

  /**
   * Waits for the holder's service-task {@code JOB:CREATED} — the first observable signal that the
   * PI is active and its businessId index entry is populated on {@code P_B}.
   */
  private static void awaitHolderJobCreated(final long processInstanceKey) {
    RecordingExporter.jobRecords(JobIntent.CREATED)
        .filter(r -> r.getValue().getProcessInstanceKey() == processInstanceKey)
        .getFirst();
  }

  /**
   * Waits for the buffered message to be consumed on {@code P_K} by the handshake (its terminal
   * {@code EXPIRED}), which is written in the same {@code STARTED}-reply processing that writes the
   * correlation-key lock on {@code P_K}.
   */
  private static void awaitMessageConsumedOnPK(final String messageName) {
    RecordingExporter.messageRecords(MessageIntent.EXPIRED)
        .withName(messageName)
        .withCorrelationKey(CORRELATION_KEY)
        .getFirst();
  }

  private static int partitionFor(final String key) {
    return SubscriptionUtil.getSubscriptionPartitionId(BufferUtil.wrapString(key), PARTITION_COUNT);
  }
}
