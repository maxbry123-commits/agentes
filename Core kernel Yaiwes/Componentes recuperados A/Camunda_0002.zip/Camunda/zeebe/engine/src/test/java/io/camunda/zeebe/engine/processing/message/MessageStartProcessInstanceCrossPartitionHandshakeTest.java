/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */
package io.camunda.zeebe.engine.processing.message;

import static io.camunda.zeebe.protocol.record.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThat;

import io.camunda.zeebe.engine.EngineConfiguration;
import io.camunda.zeebe.engine.util.EngineRule;
import io.camunda.zeebe.model.bpmn.Bpmn;
import io.camunda.zeebe.model.bpmn.BpmnModelInstance;
import io.camunda.zeebe.protocol.Protocol;
import io.camunda.zeebe.protocol.impl.SubscriptionUtil;
import io.camunda.zeebe.protocol.record.RejectionType;
import io.camunda.zeebe.protocol.record.intent.JobIntent;
import io.camunda.zeebe.protocol.record.intent.MessageIntent;
import io.camunda.zeebe.protocol.record.intent.MessageStartEventSubscriptionIntent;
import io.camunda.zeebe.protocol.record.intent.MessageStartProcessInstanceRequestIntent;
import io.camunda.zeebe.protocol.record.intent.ProcessInstanceIntent;
import io.camunda.zeebe.protocol.record.value.BpmnElementType;
import io.camunda.zeebe.test.util.record.RecordingExporter;
import io.camunda.zeebe.util.buffer.BufferUtil;
import java.time.Duration;
import java.util.concurrent.atomic.AtomicBoolean;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;

/**
 * Multi-partition behavioural pin for the cross-partition message-start handshake. The unit-level
 * coverage of the individual components (request processor outcomes, dedup hit / miss / expired
 * dedup entry, banned-PI filter, pending-ask scheduler, reply-applier bookkeeping) lives with their
 * respective code commits; this class only asserts the end-to-end observable outcomes that exist
 * because all three pieces — routing on {@code P_K}, the {@code P_B}-side processor with dedup, and
 * the reply processors on {@code P_K} — are wired together.
 *
 * <p>The tests deliberately pick {@code correlationKey} and {@code businessId} values whose hashes
 * route them to <em>different</em> partitions so the routing flip in {@link
 * MessageCorrelateBehavior} is actually exercised; an explicit precondition check fails the test
 * loudly if a future change to the hash function silently degenerates the scenario into a
 * single-partition path.
 */
public final class MessageStartProcessInstanceCrossPartitionHandshakeTest {

  private static final int PARTITION_COUNT = 3;

  // Strings whose subscription-partition hashes are stable and known on the current hash function:
  // hash("ck-1") → partition 1 (P_K) and hash("biz-1") → partition 3 (P_B) under PARTITION_COUNT=3,
  // so the cross-partition arm is actually exercised. The mapping is re-asserted at @Before so a
  // future change to the hash function does not silently turn this into a same-partition test.
  private static final String CORRELATION_KEY = "ck-1";
  private static final String BUSINESS_ID = "biz-1";
  // A second businessId used only by the local-lock-contract test; its specific partition does not
  // matter — the assertion is that the local correlationKey lock blocks the dispatch before any
  // routing happens at all.
  private static final String OTHER_BUSINESS_ID = "biz-A";

  private static final String PROCESS_ID = "wf-cross";
  private static final String MESSAGE_NAME = "start-msg";
  private static final String START_EVENT_ID = "msgStart";

  private static final Duration MESSAGE_TTL = Duration.ofSeconds(5);
  private static final Duration SWEEP_INTERVAL = Duration.ofSeconds(1);
  private static final Duration ASK_RETRY_INTERVAL = Duration.ofSeconds(1);

  /** Message-start-only process. */
  private static final BpmnModelInstance MESSAGE_START_PROCESS =
      Bpmn.createExecutableProcess(PROCESS_ID)
          .startEvent(START_EVENT_ID)
          .message(MESSAGE_NAME)
          .serviceTask("task", t -> t.zeebeJobType("test"))
          .endEvent()
          .done();

  /**
   * Auto-completing message-start process used by the dedup expiration tests so the PI can complete
   * on {@code P_B} without requiring a cross-partition job-complete command (the engine's job
   * client writes to the primary partition and would not reach a job that lives on {@code P_B}).
   */
  private static final String AUTO_PROCESS_ID = "wf-cross-auto";

  private static final String AUTO_MESSAGE_NAME = "start-msg-auto";
  private static final BpmnModelInstance AUTO_COMPLETE_MESSAGE_START_PROCESS =
      Bpmn.createExecutableProcess(AUTO_PROCESS_ID)
          .startEvent("autoStart")
          .message(AUTO_MESSAGE_NAME)
          .endEvent()
          .done();

  /**
   * Process with both a none-start event and a message-start event sharing the same {@code
   * bpmnProcessId}, so that {@code CreateProcessInstance} (which always uses the none-start) and
   * the message-start handshake hit the same business-id uniqueness index. Required for the tests
   * that exercise the uniqueness invariant across both creation APIs.
   */
  private static final BpmnModelInstance DUAL_START_PROCESS =
      Bpmn.createExecutableProcess(PROCESS_ID)
          .startEvent("noneStart")
          .serviceTask("task", t -> t.zeebeJobType("test"))
          .endEvent()
          .moveToProcess(PROCESS_ID)
          .startEvent(START_EVENT_ID)
          .message(MESSAGE_NAME)
          .connectTo("task")
          .done();

  /**
   * Like {@link #DUAL_START_PROCESS} but the none-start arm waits on an intermediate timer instead
   * of a service task, so a holder PI created on {@code P_B} via {@code CreateProcessInstance} can
   * be completed on a clock-controlled schedule (the engine job client cannot reach a job living on
   * {@code P_B}). Used by the rejection-then-retry-flips-to-success test: the holder blocks the
   * first ask, then the timer fires and frees the businessId so a retried ask succeeds.
   */
  private static final String HOLDER_TIMER_DURATION = "PT2S";

  private static final BpmnModelInstance TIMER_HOLDER_AND_MESSAGE_START_PROCESS =
      Bpmn.createExecutableProcess(PROCESS_ID)
          .startEvent("noneStart")
          .intermediateCatchEvent("holderTimer", e -> e.timerWithDuration(HOLDER_TIMER_DURATION))
          .endEvent()
          .moveToProcess(PROCESS_ID)
          .startEvent(START_EVENT_ID)
          .message(MESSAGE_NAME)
          .endEvent()
          .done();

  @Rule
  public final EngineRule engine =
      EngineRule.multiplePartition(PARTITION_COUNT)
          .withEngineConfig(
              config ->
                  config
                      .setBusinessIdUniquenessEnabled(true)
                      .setMessageStartDedupExpirationSweepInterval(SWEEP_INTERVAL)
                      .setMessageStartAskRetryInterval(ASK_RETRY_INTERVAL));

  @Before
  public void assertCrossPartitionRouting() {
    final int pk = partitionFor(CORRELATION_KEY);
    final int pb = partitionFor(BUSINESS_ID);
    assertThat(pk)
        .as(
            "CORRELATION_KEY (%s) and BUSINESS_ID (%s) must hash to different partitions so the"
                + " cross-partition arm is actually exercised; if this fails after a hash change,"
                + " pick new constants",
            CORRELATION_KEY, BUSINESS_ID)
        .isNotEqualTo(pb);
  }

  @Test
  public void shouldStartProcessInstanceOnPBViaCrossPartitionAskWhenBusinessIdHashesElsewhere() {
    // given
    deployAndAwaitStartEventSubscriptionsOnAllPartitions(MESSAGE_START_PROCESS);

    // when a message-start publish lands on P_K but its businessId hashes to P_B
    engine
        .message()
        .withName(MESSAGE_NAME)
        .withCorrelationKey(CORRELATION_KEY)
        .withBusinessId(BUSINESS_ID)
        .publish();

    // then the new PI is created on P_B (its key encodes hash(businessId))
    final var activating =
        RecordingExporter.processInstanceRecords(ProcessInstanceIntent.ELEMENT_ACTIVATING)
            .withElementType(BpmnElementType.PROCESS)
            .withBpmnProcessId(PROCESS_ID)
            .getFirst();
    assertThat(Protocol.decodePartitionId(activating.getValue().getProcessInstanceKey()))
        .as("the new PI lives on P_B = hash(businessId), not on P_K = hash(correlationKey)")
        .isEqualTo(partitionFor(BUSINESS_ID));
    assertThat(activating.getValue().getBusinessId()).isEqualTo(BUSINESS_ID);

    // and the buffered message on P_K is consumed by the handshake (EXPIRED on P_K)
    final var expired =
        RecordingExporter.messageRecords(MessageIntent.EXPIRED)
            .withName(MESSAGE_NAME)
            .withCorrelationKey(CORRELATION_KEY)
            .getFirst();
    assertThat(expired.getPartitionId())
        .as("the message lifecycle ends on P_K, not on P_B")
        .isEqualTo(partitionFor(CORRELATION_KEY));
  }

  @Test
  public void shouldBufferSecondPublishWithSameCorrelationKeyAndDifferentBusinessId() {
    // Pins that the local correlationKey lock entry written by the STARTED reply on P_K blocks
    // any further trigger sharing the correlationKey, regardless of its businessId. Preserves the
    // pre-existing contract that the process-correlation-key lock is businessId-agnostic; the
    // unblock for cross-partition holders is the pull-based release path that lands later.

    // given a first PI is started via the cross-partition ask
    deployAndAwaitStartEventSubscriptionsOnAllPartitions(MESSAGE_START_PROCESS);
    engine
        .message()
        .withName(MESSAGE_NAME)
        .withCorrelationKey(CORRELATION_KEY)
        .withBusinessId(BUSINESS_ID)
        .publish();
    final var firstJob = RecordingExporter.jobRecords(JobIntent.CREATED).getFirst();

    // when a second publish reuses the same correlationKey but carries a different businessId; we
    // pin behaviour with TTL=0 so the publish has a deterministic terminal (EXPIRED) and we can
    // bound the assertion stream
    final var second =
        engine
            .message()
            .withName(MESSAGE_NAME)
            .withCorrelationKey(CORRELATION_KEY)
            .withBusinessId(OTHER_BUSINESS_ID)
            .withTimeToLive(0L)
            .publish();

    // then no second PI is created up to the EXPIRED terminal of the second publish — the local
    // correlationKey lock written by the STARTED reply blocks the dispatch before any
    // cross-partition ask is sent
    final long secondPis =
        RecordingExporter.records()
            .limit(r -> r.getIntent() == MessageIntent.EXPIRED && r.getKey() == second.getKey())
            .processInstanceRecords()
            .withElementType(BpmnElementType.PROCESS)
            .withIntent(ProcessInstanceIntent.ELEMENT_ACTIVATING)
            .count();
    assertThat(secondPis)
        .as("the correlationKey lock blocks the second publish regardless of its businessId")
        .isEqualTo(1L);
    assertThat(firstJob.getValue().getProcessInstanceKey()).isPositive();
  }

  @Test
  public void shouldReplyUniquenessRejectedAndKeepMessageBufferedWhenBusinessIdAlreadyHeldOnPB() {
    // Pins the UNIQUENESS_REJECTED reply outcome of the handshake. A holder PI on P_B (created
    // here via CreateProcessInstance; the cross-API single-PI invariant of this same setup is
    // pinned separately by the test below) causes a later message-start publish on P_K to be
    // rejected. A different correlationKey is required so the local correlationKey lock entry
    // from a prior STARTED does not short-circuit the second publish before the ask is
    // dispatched.
    deployAndAwaitStartEventSubscriptionsOnAllPartitions(DUAL_START_PROCESS);
    final long pBHolderKey = createHolderPiOnPBViaApi(BUSINESS_ID);
    awaitHolderJobCreated(pBHolderKey);

    // when a message-start publish lands on P_K and asks P_B for the same businessId
    engine
        .message()
        .withName(MESSAGE_NAME)
        .withCorrelationKey(CORRELATION_KEY)
        .withBusinessId(BUSINESS_ID)
        .withTimeToLive(0L)
        .publish();

    // then P_B replies UNIQUENESS_REJECTED — observable on the P_K stream as the wire-level
    // outcome of the handshake
    RecordingExporter.records()
        .withIntent(MessageStartProcessInstanceRequestIntent.UNIQUENESS_REJECTED)
        .getFirst();
  }

  @Test
  public void shouldRejectCrossPartitionMessageStartAfterCreateProcessInstanceLandsOnPB() {
    // Pins the cross-API uniqueness invariant in the CreateProcessInstance-then-message-start
    // direction: a CreateProcessInstance(businessId) first lands a PI on P_B; a later
    // message-start publish from P_K with the same businessId is rejected by the ask, so across
    // both APIs exactly one PI is ever activated. Uses the same setup as the test above — the
    // distinction is in what the assertion pins: the test above pins the reply intent; this one
    // pins the single-PI invariant across both creation APIs.
    deployAndAwaitStartEventSubscriptionsOnAllPartitions(DUAL_START_PROCESS);
    final long pBHolderKey = createHolderPiOnPBViaApi(BUSINESS_ID);
    awaitHolderJobCreated(pBHolderKey);

    // when a message-start publish lands on P_K and asks P_B for the same businessId
    final var second =
        engine
            .message()
            .withName(MESSAGE_NAME)
            .withCorrelationKey(CORRELATION_KEY)
            .withBusinessId(BUSINESS_ID)
            .withTimeToLive(0L)
            .publish();

    // then the buffered message on P_K eventually expires via the standard TTL path, and only
    // the original CreateProcessInstance PI is ever activated across both APIs
    final long activations =
        RecordingExporter.records()
            .limit(r -> r.getIntent() == MessageIntent.EXPIRED && r.getKey() == second.getKey())
            .processInstanceRecords()
            .withBpmnProcessId(PROCESS_ID)
            .withElementType(BpmnElementType.PROCESS)
            .withIntent(ProcessInstanceIntent.ELEMENT_ACTIVATING)
            .count();
    assertThat(activations)
        .as("only the original CreateProcessInstance PI exists; the message-start ask is rejected")
        .isEqualTo(1L);
  }

  @Test
  public void shouldRejectCreateProcessInstanceWhenCrossPartitionMessageStartHoldsBusinessId() {
    // Pins the cross-API uniqueness invariant in the message-start-then-CreateProcessInstance
    // direction: message-start lands a PI on P_B via the cross-partition ask; a subsequent
    // CreateProcessInstance on P_B targeting the same bpmnProcessId / businessId is rejected for
    // uniqueness. Demonstrates that the invariant "every active root PI with a businessId lives
    // on P_B = hash(businessId)" holds across both creation paths.
    deployAndAwaitStartEventSubscriptionsOnAllPartitions(DUAL_START_PROCESS);

    engine
        .message()
        .withName(MESSAGE_NAME)
        .withCorrelationKey(CORRELATION_KEY)
        .withBusinessId(BUSINESS_ID)
        .publish();
    // ensure the holder PI's index entry exists on P_B before issuing the conflicting create —
    // JOB:CREATED is the first observable signal that V3 PI-activating applier ran. We do not
    // know the PI key up-front (the handshake creates it on P_B), so we wait by job type.
    RecordingExporter.jobRecords(JobIntent.CREATED).withType("test").getFirst();

    // when a CreateProcessInstance with the same businessId is routed to P_B
    engine
        .processInstance()
        .ofBpmnProcessId(PROCESS_ID)
        .onPartition(partitionFor(BUSINESS_ID))
        .withBusinessId(BUSINESS_ID)
        .withTags("rejectedSecond")
        .expectRejection()
        .create();

    // then it is rejected with ALREADY_EXISTS — the message-start handshake has already populated
    // the uniqueness index on P_B
    assertThat(
            RecordingExporter.processInstanceCreationRecords()
                .onlyCommandRejections()
                .withTags("rejectedSecond")
                .withBpmnProcessId(PROCESS_ID)
                .getFirst())
        .hasRejectionType(RejectionType.ALREADY_EXISTS);
  }

  @Test
  public void shouldNotDuplicatePiWhenStartedReplyIsDroppedAndRetriedAcrossPartitions() {
    // Pins multi-partition retry idempotency: a dropped STARTED reply leaves the pending-ask on
    // P_K. The retry scheduler re-dispatches the ask; P_B's success-only dedup re-replies STARTED
    // with the same processInstanceKey; the STARTED reply applier on P_K is unconditionally
    // idempotent so no second PI is activated and the local correlationKey lock is written
    // exactly once across retries.
    deployAndAwaitStartEventSubscriptionsOnAllPartitions(MESSAGE_START_PROCESS);

    final AtomicBoolean droppedOnce = new AtomicBoolean(false);
    engine.interceptInterPartitionCommands(
        (receiverPartitionId, valueType, intent, recordKey, command) ->
            !(intent == MessageStartProcessInstanceRequestIntent.START
                && droppedOnce.compareAndSet(false, true)));

    // when
    engine
        .message()
        .withName(MESSAGE_NAME)
        .withCorrelationKey(CORRELATION_KEY)
        .withBusinessId(BUSINESS_ID)
        .publish();

    // and the retry scheduler fires (advance past one askRetryInterval + askCheckInterval so the
    // first eligible scan sees the past-deadline entry and re-dispatches)
    engine.increaseTime(ASK_RETRY_INTERVAL.multipliedBy(2).plusSeconds(1));

    // then a STARTED reply eventually reaches P_K (the second attempt is not dropped) and exactly
    // one PI is activated; P_B's success-only dedup re-replies the same processInstanceKey on
    // every retry so the cumulative number of PI activations across all retries is still one
    final long expectedPiKey =
        RecordingExporter.processInstanceRecords(ProcessInstanceIntent.ELEMENT_ACTIVATING)
            .withBpmnProcessId(PROCESS_ID)
            .withElementType(BpmnElementType.PROCESS)
            .getFirst()
            .getValue()
            .getProcessInstanceKey();
    final long activations =
        RecordingExporter.records()
            .limit(
                r ->
                    r.getPartitionId() == partitionFor(CORRELATION_KEY)
                        && r.getIntent() == MessageStartProcessInstanceRequestIntent.STARTED)
            .processInstanceRecords()
            .withBpmnProcessId(PROCESS_ID)
            .withElementType(BpmnElementType.PROCESS)
            .withIntent(ProcessInstanceIntent.ELEMENT_ACTIVATING)
            .count();
    assertThat(activations)
        .as("retry must not activate a second PI; P_B re-replies the cached PI key")
        .isEqualTo(1L);

    // sanity: the single activation is the one whose key we observed before applying the retry
    assertThat(
            RecordingExporter.processInstanceRecords(ProcessInstanceIntent.ELEMENT_ACTIVATING)
                .withBpmnProcessId(PROCESS_ID)
                .withElementType(BpmnElementType.PROCESS)
                .getFirst()
                .getValue()
                .getProcessInstanceKey())
        .isEqualTo(expectedPiKey);
  }

  @Test
  public void
      shouldReReplyStartedWithCachedKeyWhenRetryArrivesAfterPiCompletedWithinMessageDeadline() {
    // Pins the multi-partition expired-dedup-entry-within-deadline outcome: P_B's success-only
    // dedup keeps re-replying STARTED with the original PI key until the dedup row's
    // deletionDeadline (= messageDeadline) passes, so a P_K retry that loses a race with the
    // holder's lifecycle is still a no-op on P_B. The unit-level coverage of the dedup state
    // transitions lives in MessageStartProcessInstanceDedupBehaviorTest; this test exercises the
    // same outcome through the real inter-partition transport and ask retry scheduler.
    //
    // We deploy an auto-completing process so the holder PI on P_B completes on its own; the
    // engine's job client writes to the primary partition and could not reach a job on P_B.
    deployAndAwaitStartEventSubscriptionsOnAllPartitions(
        AUTO_COMPLETE_MESSAGE_START_PROCESS, AUTO_MESSAGE_NAME);

    // drop the first STARTED reply so the pending-ask on P_K survives and is retryable; let
    // every subsequent inter-partition command through (including the re-replied STARTED)
    final AtomicBoolean droppedOnce = new AtomicBoolean(false);
    engine.interceptInterPartitionCommands(
        (receiverPartitionId, valueType, intent, recordKey, command) ->
            !(intent == MessageStartProcessInstanceRequestIntent.START
                && droppedOnce.compareAndSet(false, true)));

    // when
    engine
        .message()
        .withName(AUTO_MESSAGE_NAME)
        .withCorrelationKey(CORRELATION_KEY)
        .withBusinessId(BUSINESS_ID)
        .withTimeToLive(MESSAGE_TTL.toMillis())
        .publish();

    // the holder PI auto-completes on P_B and the V3 applier leaves the dedup entry in place
    // (the dedup's deletionDeadline is the messageDeadline, independent of PI lifecycle)
    final long firstPiKey =
        RecordingExporter.processInstanceRecords(ProcessInstanceIntent.ELEMENT_COMPLETED)
            .withBpmnProcessId(AUTO_PROCESS_ID)
            .withElementType(BpmnElementType.PROCESS)
            .getFirst()
            .getValue()
            .getProcessInstanceKey();

    // and the ask retry scheduler fires while the dedup row is still valid (advance only past the
    // retry+check interval; messageDeadline = MESSAGE_TTL = 5s so we stay safely inside it)
    engine.increaseTime(ASK_RETRY_INTERVAL.multipliedBy(2).plusSeconds(1));

    // then the re-dispatched REQUEST hits the dedup entry within its deadline and P_B
    // re-replies STARTED with the original PI key; no second PI is ever activated
    final long secondStartedPiKey = retryStartedReplyPiKey();
    assertThat(secondStartedPiKey)
        .as(
            "the dedup entry re-replies the cached PI key while its deletionDeadline holds; this"
                + " alone implies no second PI was activated, because P_B only writes STARTED"
                + " with the cached key on a dedup short-circuit, never together with a fresh"
                + " PROCESS_INSTANCE_CREATION")
        .isEqualTo(firstPiKey);
  }

  @Test
  public void shouldRejectExpiredWhenRetryArrivesAfterMessageDeadlineHasPassed() {
    // Pins the multi-partition TTL-gated expiry guard: once the messageDeadline has elapsed, a
    // retry from P_K is deterministically refused with REJECT_EXPIRED. P_B does NOT re-evaluate
    // live state and does NOT start a fresh (duplicate) PI, even though the original holder has
    // auto-completed and freed the businessId — this is exactly the near-deadline duplicate window
    // the guard closes. Symmetric counterpart to the within-deadline re-reply test above.
    deployAndAwaitStartEventSubscriptionsOnAllPartitions(
        AUTO_COMPLETE_MESSAGE_START_PROCESS, AUTO_MESSAGE_NAME);

    final AtomicBoolean droppedOnce = new AtomicBoolean(false);
    engine.interceptInterPartitionCommands(
        (receiverPartitionId, valueType, intent, recordKey, command) ->
            !(intent == MessageStartProcessInstanceRequestIntent.START
                && droppedOnce.compareAndSet(false, true)));

    // when
    engine
        .message()
        .withName(AUTO_MESSAGE_NAME)
        .withCorrelationKey(CORRELATION_KEY)
        .withBusinessId(BUSINESS_ID)
        .withTimeToLive(MESSAGE_TTL.toMillis())
        .publish();

    RecordingExporter.processInstanceRecords(ProcessInstanceIntent.ELEMENT_COMPLETED)
        .withBpmnProcessId(AUTO_PROCESS_ID)
        .withElementType(BpmnElementType.PROCESS)
        .getFirst();

    // and time advances past messageDeadline + sweep interval so the dedup entry is swept before
    // the next retry arrives
    engine.increaseTime(MESSAGE_TTL.plus(SWEEP_INTERVAL).plusSeconds(1));

    // then the re-dispatched REQUEST is refused on P_B with REJECT_EXPIRED, P_K records
    // EXPIRED_REJECTED, and no second PI is ever activated — exactly one PI existed on P_B
    RecordingExporter.messageStartProcessInstanceRequestRecords(
            MessageStartProcessInstanceRequestIntent.EXPIRED_REJECTED)
        .getFirst();
    final long activations =
        RecordingExporter.records()
            .limit(r -> r.getIntent() == MessageStartProcessInstanceRequestIntent.EXPIRED_REJECTED)
            .processInstanceRecords()
            .withBpmnProcessId(AUTO_PROCESS_ID)
            .withElementType(BpmnElementType.PROCESS)
            .withIntent(ProcessInstanceIntent.ELEMENT_ACTIVATING)
            .count();
    assertThat(activations)
        .as("after the messageDeadline has passed, P_B refuses the retry instead of duplicating")
        .isEqualTo(1L);
  }

  @Test
  public void shouldActivatePiForZeroTtlCrossPartitionFirstArrival() {
    // Pins the TTL=0 carve-out at the multi-partition level (spec §8.2 #3): a TTL=0 message-start
    // publish still activates a PI cross-partition. On P_K the buffered message expires
    // synchronously in the same processing cycle, but the cross-partition REQUEST is dispatched
    // before that expiry, so P_B receives it with messageDeadline <= now AND messageTtl == 0. The
    // guard rejects only on messageTtl > 0, so a TTL=0 request falls through to live evaluation and
    // starts the PI exactly as today — the deterministic expiry guard must not swallow it. This is
    // the regression pin for the documented behaviour the whole TTL gate is carefully carved
    // around.
    deployAndAwaitStartEventSubscriptionsOnAllPartitions(MESSAGE_START_PROCESS);

    // when a TTL=0 message-start publish lands on P_K but its businessId hashes to P_B
    engine
        .message()
        .withName(MESSAGE_NAME)
        .withCorrelationKey(CORRELATION_KEY)
        .withBusinessId(BUSINESS_ID)
        .withTimeToLive(0L)
        .publish();

    // then a PI is still activated on P_B (its key encodes hash(businessId)) carrying the
    // businessId
    final var activating =
        RecordingExporter.processInstanceRecords(ProcessInstanceIntent.ELEMENT_ACTIVATING)
            .withElementType(BpmnElementType.PROCESS)
            .withBpmnProcessId(PROCESS_ID)
            .getFirst();
    assertThat(Protocol.decodePartitionId(activating.getValue().getProcessInstanceKey()))
        .as(
            "a TTL=0 cross-partition first-arrival must still start its PI on P_B = hash(businessId)")
        .isEqualTo(partitionFor(BUSINESS_ID));
    assertThat(activating.getValue().getBusinessId()).isEqualTo(BUSINESS_ID);
  }

  @Test
  public void shouldRejectExpiredFirstArrivalThatOnlyReachesPbAfterDeadline() {
    // Pins the reordered / late first-arrival window (spec §8.2 #2, §3.2) at the multi-partition
    // level: the guard gates on messageTtl, not on an isRetry marker, so a request that P_B has
    // never seen before — a genuine first-arrival, not a re-reply of an already-started PI — is
    // still refused with REJECT_EXPIRED once it lands past the messageDeadline. This is the exact
    // window the rejected isRetry design left open (a delayed first-arrival racing its own retry
    // would carry isRetry=false and activate); here no delivery ever reaches P_B before the
    // deadline, so no PI and no dedup row ever exist, and the only surviving delivery is the
    // post-deadline one — which must be rejected, never allowed to start a fresh (duplicate) PI.
    deployAndAwaitStartEventSubscriptionsOnAllPartitions(MESSAGE_START_PROCESS);

    // drop every forward REQUEST to P_B until we cross the deadline, so P_B never sees the request
    // while it is still live; the pending ask on P_K survives and the scheduler keeps
    // re-dispatching
    final AtomicBoolean blockRequest = new AtomicBoolean(true);
    engine.interceptInterPartitionCommands(
        (receiverPartitionId, valueType, intent, recordKey, command) ->
            !(intent == MessageStartProcessInstanceRequestIntent.REQUEST && blockRequest.get()));

    // when a message-start publish lands on P_K and asks P_B for a businessId no holder owns
    engine
        .message()
        .withName(MESSAGE_NAME)
        .withCorrelationKey(CORRELATION_KEY)
        .withBusinessId(BUSINESS_ID)
        .withTimeToLive(MESSAGE_TTL.toMillis())
        .publish();

    // and time advances past the messageDeadline + sweep interval (still well inside the 1-minute
    // message-TTL checker, so the buffered message on P_K is not yet expired and the ask keeps
    // being
    // retried) — every REQUEST dispatched so far was dropped, so no PI was ever created
    engine.increaseTime(MESSAGE_TTL.plus(SWEEP_INTERVAL).plusSeconds(1));

    // when the transport is unblocked so the next retry actually reaches P_B, now past the deadline
    blockRequest.set(false);
    engine.increaseTime(ASK_RETRY_INTERVAL.multipliedBy(2).plusSeconds(1));

    // then P_B refuses the first-ever-seen request with REJECT_EXPIRED (P_K records
    // EXPIRED_REJECTED) and no PI is ever activated — the guard closes the late-first-arrival
    // window
    // without any isRetry escape hatch
    RecordingExporter.messageStartProcessInstanceRequestRecords(
            MessageStartProcessInstanceRequestIntent.EXPIRED_REJECTED)
        .getFirst();
    final long activations =
        RecordingExporter.records()
            .limit(r -> r.getIntent() == MessageStartProcessInstanceRequestIntent.EXPIRED_REJECTED)
            .processInstanceRecords()
            .withBpmnProcessId(PROCESS_ID)
            .withElementType(BpmnElementType.PROCESS)
            .withIntent(ProcessInstanceIntent.ELEMENT_ACTIVATING)
            .count();
    assertThat(activations)
        .as(
            "a first-arrival that only reaches P_B past the deadline is expiry-rejected, never started")
        .isZero();
  }

  @Test
  public void shouldStartFreshPiWhenRetryArrivesWithBannedHolderOnPB() {
    // Pins the multi-partition banned-PI re-evaluation outcome: the lookup-time filter on P_B
    // treats a cached dedup entry whose holder PI has been banned as a miss and re-evaluates
    // live state — banned PIs are excluded from the uniqueness index, so a fresh PI is
    // started. This pins the ADR choice to defend against retries via a lookup-time filter
    // rather than a dedicated ban-cleanup hook.
    deployAndAwaitStartEventSubscriptionsOnAllPartitions(MESSAGE_START_PROCESS);

    final AtomicBoolean droppedOnce = new AtomicBoolean(false);
    engine.interceptInterPartitionCommands(
        (receiverPartitionId, valueType, intent, recordKey, command) ->
            !(intent == MessageStartProcessInstanceRequestIntent.START
                && droppedOnce.compareAndSet(false, true)));

    // when
    engine
        .message()
        .withName(MESSAGE_NAME)
        .withCorrelationKey(CORRELATION_KEY)
        .withBusinessId(BUSINESS_ID)
        .publish();

    final long bannedPiKey =
        RecordingExporter.processInstanceRecords(ProcessInstanceIntent.ELEMENT_ACTIVATING)
            .withBpmnProcessId(PROCESS_ID)
            .withElementType(BpmnElementType.PROCESS)
            .getFirst()
            .getValue()
            .getProcessInstanceKey();
    // wait for the holder's JOB:CREATED so the V3 applier has populated the businessId index
    // before we ban — otherwise the live re-evaluation could race the index write
    awaitHolderJobCreated(bannedPiKey);
    engine.banInstanceInNewTransaction(partitionFor(BUSINESS_ID), bannedPiKey);

    // and the ask retry scheduler fires
    engine.increaseTime(ASK_RETRY_INTERVAL.multipliedBy(2).plusSeconds(1));

    // then the re-dispatched REQUEST hits the dedup entry, the banned-holder filter treats it
    // as a miss, live uniqueness re-evaluation excludes the banned PI, and a fresh PI is
    // started on P_B with a different key
    final long secondStartedPiKey = retryStartedReplyPiKey();
    assertThat(secondStartedPiKey)
        .as("a banned holder must not block a retry from starting a fresh PI")
        .isPositive()
        .isNotEqualTo(bannedPiKey);
  }

  @Test
  public void shouldStartPiWhenUniquenessRejectedAskIsRetriedAfterHolderCompletesOnPB() {
    // Pins the headline Part-B "way out": a cross-partition ask rejected on businessId uniqueness
    // is kept and retried, and once the holder PI on P_B completes (freeing the businessId) a
    // retried ask flips to a successful start. The holder parks on an intermediate timer so it
    // stays active — and keeps the businessId held — until the clock is advanced (the engine job
    // client cannot reach a job living on P_B, so a service-task holder could not be completed).
    deployAndAwaitStartEventSubscriptionsOnAllPartitions(TIMER_HOLDER_AND_MESSAGE_START_PROCESS);
    final long holderPiKey =
        engine
            .processInstance()
            .ofBpmnProcessId(PROCESS_ID)
            .onPartition(partitionFor(BUSINESS_ID))
            .withBusinessId(BUSINESS_ID)
            .create();
    // wait until the holder PI has activated on P_B so the businessId uniqueness index is
    // populated before the first ask arrives (ELEMENT_ACTIVATED follows the index-writing
    // ACTIVATING applier)
    RecordingExporter.processInstanceRecords(ProcessInstanceIntent.ELEMENT_ACTIVATED)
        .withProcessInstanceKey(holderPiKey)
        .withElementType(BpmnElementType.PROCESS)
        .getFirst();

    // when a message-start publish lands on P_K and asks P_B for the same businessId; the holder
    // is still active so P_B replies UNIQUENESS_REJECTED (the ask is kept, not dropped)
    engine
        .message()
        .withName(MESSAGE_NAME)
        .withCorrelationKey(CORRELATION_KEY)
        .withBusinessId(BUSINESS_ID)
        .withTimeToLive(Duration.ofMinutes(5))
        .publish();
    RecordingExporter.records()
        .withIntent(MessageStartProcessInstanceRequestIntent.UNIQUENESS_REJECTED)
        .getFirst();

    // and the holder's timer fires, completing it and freeing the businessId
    engine.increaseTime(Duration.ofSeconds(3));
    RecordingExporter.processInstanceRecords(ProcessInstanceIntent.ELEMENT_COMPLETED)
        .withProcessInstanceKey(holderPiKey)
        .filterRootScope()
        .await();

    // and the ask retry scheduler re-dispatches the ask (advance past the worst-case backed-off
    // interval, capped at base * 64, while still well inside the 5-minute message TTL)
    engine.increaseTime(ASK_RETRY_INTERVAL.multipliedBy(64).plusSeconds(1));

    // then the retried ask now succeeds: P_B starts a fresh message-start PI carrying BUSINESS_ID,
    // distinct from the completed holder
    final var messagePi =
        RecordingExporter.processInstanceRecords(ProcessInstanceIntent.ELEMENT_ACTIVATING)
            .withElementType(BpmnElementType.PROCESS)
            .withBpmnProcessId(PROCESS_ID)
            .filter(r -> r.getValue().getProcessInstanceKey() != holderPiKey)
            .getFirst();
    assertThat(messagePi.getValue().getBusinessId()).isEqualTo(BUSINESS_ID);
    assertThat(Protocol.decodePartitionId(messagePi.getValue().getProcessInstanceKey()))
        .as("the retried start lands on P_B = hash(businessId)")
        .isEqualTo(partitionFor(BUSINESS_ID));
  }

  @Test
  public void shouldExpireBlockedMessageAtTtlWhenHolderNeverClearsAcrossPartitions() {
    // Pins the safe terminal of the retry loop: when the cross-partition holder never frees the
    // businessId, every retry is rejected and the buffered message simply expires at its TTL —
    // no start, no duplicate, no leak. The holder sits on a service task it never leaves (the
    // engine job client cannot reach a job on P_B), so it holds the businessId for the whole test.
    deployAndAwaitStartEventSubscriptionsOnAllPartitions(DUAL_START_PROCESS);
    final long holderPiKey = createHolderPiOnPBViaApi(BUSINESS_ID);
    awaitHolderJobCreated(holderPiKey);

    // when a message-start publish on P_K asks P_B for the same businessId with a short TTL
    final var blockedPublish =
        engine
            .message()
            .withName(MESSAGE_NAME)
            .withCorrelationKey(CORRELATION_KEY)
            .withBusinessId(BUSINESS_ID)
            .withTimeToLive(MESSAGE_TTL.toMillis())
            .publish();
    RecordingExporter.records()
        .withIntent(MessageStartProcessInstanceRequestIntent.UNIQUENESS_REJECTED)
        .getFirst();

    // and time advances past the messageDeadline so the buffered message expires on P_K
    engine.increaseTime(
        MESSAGE_TTL.plus(EngineConfiguration.DEFAULT_MESSAGES_TTL_CHECKER_INTERVAL));

    // then the buffered message expires and no message-start PI is ever created — only the holder
    // PI exists on P_B, bounded by the EXPIRED terminal of the blocked publish
    final long processActivations =
        RecordingExporter.records()
            .limit(
                r ->
                    r.getIntent() == MessageIntent.EXPIRED && r.getKey() == blockedPublish.getKey())
            .processInstanceRecords()
            .withBpmnProcessId(PROCESS_ID)
            .withElementType(BpmnElementType.PROCESS)
            .withIntent(ProcessInstanceIntent.ELEMENT_ACTIVATING)
            .count();
    assertThat(processActivations)
        .as("a never-freed cross-partition holder lets the blocked message expire unstarted")
        .isEqualTo(1L);
  }

  private void deployAndAwaitStartEventSubscriptionsOnAllPartitions(
      final BpmnModelInstance process) {
    deployAndAwaitStartEventSubscriptionsOnAllPartitions(process, MESSAGE_NAME);
  }

  private void deployAndAwaitStartEventSubscriptionsOnAllPartitions(
      final BpmnModelInstance process, final String messageName) {
    engine.deployment().withXmlResource(process).deploy();
    // deploy() already waits for CommandDistribution:FINISHED in multi-partition mode; we still
    // need to wait until every partition has the MessageStartEventSubscription CREATED so the
    // ask processor on P_B sees its local subscription before the first cross-partition request
    // arrives (otherwise it would reply NO_SUBSCRIPTION_REJECTED on a deployment race).
    RecordingExporter.messageStartEventSubscriptionRecords(
            MessageStartEventSubscriptionIntent.CREATED)
        .withMessageName(messageName)
        .limit(PARTITION_COUNT)
        .asList();
  }

  private static int partitionFor(final String key) {
    return SubscriptionUtil.getSubscriptionPartitionId(BufferUtil.wrapString(key), PARTITION_COUNT);
  }

  /**
   * Creates a holder PI for the given {@code businessId} directly on {@code P_B} via the {@code
   * CreateProcessInstance} API, bypassing the message-start handshake. Used by the tests that need
   * an active uniqueness-index entry already on {@code P_B} before exercising a conflicting
   * message-start ask.
   */
  private long createHolderPiOnPBViaApi(final String businessId) {
    return engine
        .processInstance()
        .ofBpmnProcessId(PROCESS_ID)
        .onPartition(partitionFor(businessId))
        .withBusinessId(businessId)
        .create();
  }

  /**
   * Waits for the given PI's service-task {@code JOB:CREATED} record — the first observable signal
   * that {@code ProcessInstanceElementActivatingV3Applier} has populated the businessId uniqueness
   * index on the PI's partition. Without this guard, a subsequent uniqueness check can race the
   * index-write applier and observe a stale "businessId-free" state.
   */
  private static void awaitHolderJobCreated(final long processInstanceKey) {
    RecordingExporter.jobRecords(JobIntent.CREATED)
        .filter(r -> r.getValue().getProcessInstanceKey() == processInstanceKey)
        .getFirst();
  }

  /**
   * Returns the {@code processInstanceKey} carried by the <em>second</em> {@code STARTED} reply
   * observed — i.e. the reply produced after the retry scheduler re-dispatches the ask, once the
   * first reply has been dropped by the test's inter-partition interceptor.
   */
  private static long retryStartedReplyPiKey() {
    return RecordingExporter.messageStartProcessInstanceRequestRecords(
            MessageStartProcessInstanceRequestIntent.STARTED)
        .limit(2)
        .skip(1)
        .getFirst()
        .getValue()
        .getProcessInstanceKey();
  }
}
