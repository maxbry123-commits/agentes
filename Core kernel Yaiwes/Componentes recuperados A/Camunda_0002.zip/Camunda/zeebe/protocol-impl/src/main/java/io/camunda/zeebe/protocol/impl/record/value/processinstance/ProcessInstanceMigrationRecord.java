/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */
package io.camunda.zeebe.protocol.impl.record.value.processinstance;

import static io.camunda.zeebe.util.buffer.BufferUtil.bufferAsString;

import com.fasterxml.jackson.annotation.JsonIgnore;
import io.camunda.zeebe.msgpack.property.ArrayProperty;
import io.camunda.zeebe.msgpack.property.IntegerProperty;
import io.camunda.zeebe.msgpack.property.LongProperty;
import io.camunda.zeebe.msgpack.property.StringProperty;
import io.camunda.zeebe.msgpack.value.StringValue;
import io.camunda.zeebe.protocol.impl.record.UnifiedRecordValue;
import io.camunda.zeebe.protocol.record.value.ProcessInstanceMigrationRecordValue;
import io.camunda.zeebe.protocol.record.value.TenantOwned;
import java.util.List;

public final class ProcessInstanceMigrationRecord extends UnifiedRecordValue
    implements ProcessInstanceMigrationRecordValue {

  public static final StringValue TENANT_ID_KEY = new StringValue("tenantId");
  // Static StringValue keys to avoid memory waste
  private static final StringValue PROCESS_INSTANCE_KEY_KEY = new StringValue("processInstanceKey");
  private static final StringValue TARGET_PROCESS_DEFINITION_KEY_KEY =
      new StringValue("targetProcessDefinitionKey");
  private static final StringValue MAPPING_INSTRUCTIONS_KEY =
      new StringValue("mappingInstructions");
  private static final StringValue ROOT_PROCESS_INSTANCE_KEY_KEY =
      new StringValue("rootProcessInstanceKey");
  private static final StringValue STORAGE_ORDINAL_KEY_KEY = new StringValue("storageOrdinalKey");
  private static final StringValue PROCESS_DEFINITION_KEY_KEY =
      new StringValue("processDefinitionKey");
  private static final StringValue BPMN_PROCESS_ID_KEY = new StringValue("bpmnProcessId");
  private final LongProperty processInstanceKeyProperty =
      new LongProperty(PROCESS_INSTANCE_KEY_KEY);
  private final LongProperty targetProcessDefinitionKeyProperty =
      new LongProperty(TARGET_PROCESS_DEFINITION_KEY_KEY);
  private final ArrayProperty<ProcessInstanceMigrationMappingInstruction>
      mappingInstructionsProperty =
          new ArrayProperty<>(
              MAPPING_INSTRUCTIONS_KEY, ProcessInstanceMigrationMappingInstruction::new);

  private final StringProperty tenantIdProperty =
      new StringProperty(TENANT_ID_KEY, TenantOwned.DEFAULT_TENANT_IDENTIFIER);
  private final LongProperty rootProcessInstanceKeyProperty =
      new LongProperty(ROOT_PROCESS_INSTANCE_KEY_KEY, -1);
  private final IntegerProperty storageOrdinalKeyProperty =
      new IntegerProperty(STORAGE_ORDINAL_KEY_KEY, 0);
  private final LongProperty processDefinitionKeyProperty =
      new LongProperty(PROCESS_DEFINITION_KEY_KEY, -1L);
  private final StringProperty bpmnProcessIdProperty = new StringProperty(BPMN_PROCESS_ID_KEY, "");

  public ProcessInstanceMigrationRecord() {
    super(8);
    declareProperty(processInstanceKeyProperty)
        .declareProperty(targetProcessDefinitionKeyProperty)
        .declareProperty(mappingInstructionsProperty)
        .declareProperty(tenantIdProperty)
        .declareProperty(rootProcessInstanceKeyProperty)
        .declareProperty(storageOrdinalKeyProperty)
        .declareProperty(processDefinitionKeyProperty)
        .declareProperty(bpmnProcessIdProperty);
  }

  @Override
  public long getProcessInstanceKey() {
    return processInstanceKeyProperty.getValue();
  }

  public ProcessInstanceMigrationRecord setProcessInstanceKey(final long processInstanceKey) {
    processInstanceKeyProperty.setValue(processInstanceKey);
    return this;
  }

  @Override
  public long getProcessDefinitionKey() {
    return processDefinitionKeyProperty.getValue();
  }

  public ProcessInstanceMigrationRecord setProcessDefinitionKey(final long processDefinitionKey) {
    processDefinitionKeyProperty.setValue(processDefinitionKey);
    return this;
  }

  @Override
  public long getTargetProcessDefinitionKey() {
    return targetProcessDefinitionKeyProperty.getValue();
  }

  public ProcessInstanceMigrationRecord setTargetProcessDefinitionKey(
      final long targetProcessDefinitionKey) {
    targetProcessDefinitionKeyProperty.setValue(targetProcessDefinitionKey);
    return this;
  }

  /**
   * This method is expensive because it copies each element before returning it. It is recommended
   * to use {@link #hasMappingInstructions()} before calling this.
   *
   * <p>{@inheritDoc}
   */
  @Override
  public List<ProcessInstanceMigrationMappingInstructionValue> getMappingInstructions() {
    // we need to make a copy of each element in the ArrayProperty while iterating it because the
    // inner values are updated during the iteration
    return mappingInstructionsProperty.stream()
        .map(
            element -> {
              final var elementCopy = new ProcessInstanceMigrationMappingInstruction();
              elementCopy.copy(element);
              return (ProcessInstanceMigrationMappingInstructionValue) elementCopy;
            })
        .toList();
  }

  @Override
  public long getRootProcessInstanceKey() {
    return rootProcessInstanceKeyProperty.getValue();
  }

  public ProcessInstanceMigrationRecord setRootProcessInstanceKey(
      final long rootProcessInstanceKey) {
    rootProcessInstanceKeyProperty.setValue(rootProcessInstanceKey);
    return this;
  }

  @Override
  public String getBpmnProcessId() {
    return bufferAsString(bpmnProcessIdProperty.getValue());
  }

  public ProcessInstanceMigrationRecord setBpmnProcessId(final String bpmnProcessId) {
    bpmnProcessIdProperty.setValue(bpmnProcessId);
    return this;
  }

  /** Returns true if this record has mapping instructions, otherwise false. */
  @JsonIgnore
  public boolean hasMappingInstructions() {
    return !mappingInstructionsProperty.isEmpty();
  }

  public ProcessInstanceMigrationRecord addMappingInstruction(
      final ProcessInstanceMigrationMappingInstruction mappingInstruction) {
    mappingInstructionsProperty.add().copy(mappingInstruction);
    return this;
  }

  @Override
  public String getTenantId() {
    return bufferAsString(tenantIdProperty.getValue());
  }

  public ProcessInstanceMigrationRecord setTenantId(final String tenantId) {
    tenantIdProperty.setValue(tenantId);
    return this;
  }

  @Override
  public int getStorageOrdinalKey() {
    return storageOrdinalKeyProperty.getValue();
  }

  public ProcessInstanceMigrationRecord setStorageOrdinalKey(final int storageOrdinalKey) {
    storageOrdinalKeyProperty.setValue(storageOrdinalKey);
    return this;
  }
}
