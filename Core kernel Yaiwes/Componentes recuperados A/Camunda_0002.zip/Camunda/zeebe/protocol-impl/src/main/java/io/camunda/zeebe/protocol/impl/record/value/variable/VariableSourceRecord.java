/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */
package io.camunda.zeebe.protocol.impl.record.value.variable;

import io.camunda.zeebe.msgpack.property.EnumProperty;
import io.camunda.zeebe.msgpack.value.StringValue;
import io.camunda.zeebe.protocol.impl.record.UnifiedRecordValue;
import io.camunda.zeebe.protocol.record.value.VariableOperationType;
import io.camunda.zeebe.protocol.record.value.VariableSourceValue;

public class VariableSourceRecord extends UnifiedRecordValue implements VariableSourceValue {

  //  public static final VariableSourceRecord API =
  //      new VariableSourceRecord().setType(VariableOperationType.API);
  //  public static final VariableSourceRecord NONE =
  //      new VariableSourceRecord().setType(VariableOperationType.UNKNOWN);

  private static final StringValue TYPE_KEY = new StringValue("type");

  // possible enhancements documented in https://github.com/camunda/camunda/issues/46970
  private final EnumProperty<VariableOperationType> typeProp =
      new EnumProperty<>(TYPE_KEY, VariableOperationType.class, VariableOperationType.UNKNOWN);

  public VariableSourceRecord() {
    super(1);
    declareProperty(typeProp);
  }

  @Override
  public VariableOperationType getType() {
    return typeProp.getValue();
  }

  public VariableSourceRecord setType(final VariableOperationType variableSourceType) {
    typeProp.setValue(variableSourceType);
    return this;
  }

  public void wrap(final VariableSourceRecord variableSourceRecord) {
    setType(variableSourceRecord.getType());
  }

  public static VariableSourceRecord api() {
    return new VariableSourceRecord().setType(VariableOperationType.API);
  }

  public static VariableSourceRecord none() {
    return new VariableSourceRecord().setType(VariableOperationType.UNKNOWN);
  }
}
