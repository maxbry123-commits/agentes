/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */
package io.camunda.zeebe.protocol.impl.encoding;

import static io.camunda.zeebe.protocol.record.BrokerInfoEncoder.clusterSizeNullValue;
import static io.camunda.zeebe.protocol.record.BrokerInfoEncoder.nodeIdNullValue;
import static io.camunda.zeebe.protocol.record.BrokerInfoEncoder.partitionGroupHeaderLength;
import static io.camunda.zeebe.protocol.record.BrokerInfoEncoder.versionHeaderLength;
import static io.camunda.zeebe.protocol.record.BrokerInfoEncoder.zoneHeaderLength;
import static io.camunda.zeebe.util.buffer.BufferUtil.wrapString;

import io.camunda.cluster.PhysicalTenantIds;
import io.camunda.zeebe.protocol.impl.Loggers;
import io.camunda.zeebe.protocol.record.BrokerInfoDecoder;
import io.camunda.zeebe.protocol.record.BrokerInfoDecoder.AddressesDecoder;
import io.camunda.zeebe.protocol.record.BrokerInfoDecoder.PartitionHealthDecoder;
import io.camunda.zeebe.protocol.record.BrokerInfoDecoder.PartitionLeaderTermsDecoder;
import io.camunda.zeebe.protocol.record.BrokerInfoDecoder.PartitionRolesDecoder;
import io.camunda.zeebe.protocol.record.BrokerInfoEncoder;
import io.camunda.zeebe.protocol.record.BrokerInfoEncoder.AddressesEncoder;
import io.camunda.zeebe.protocol.record.BrokerInfoEncoder.PartitionHealthEncoder;
import io.camunda.zeebe.protocol.record.BrokerInfoEncoder.PartitionLeaderTermsEncoder;
import io.camunda.zeebe.protocol.record.BrokerInfoEncoder.PartitionRolesEncoder;
import io.camunda.zeebe.protocol.record.MessageHeaderDecoder;
import io.camunda.zeebe.protocol.record.MessageHeaderEncoder;
import io.camunda.zeebe.protocol.record.PartitionHealthStatus;
import io.camunda.zeebe.protocol.record.PartitionRole;
import io.camunda.zeebe.util.MemberIdUtil;
import io.camunda.zeebe.util.buffer.BufferReader;
import io.camunda.zeebe.util.buffer.BufferUtil;
import io.camunda.zeebe.util.buffer.BufferWriter;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Base64.Encoder;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.Properties;
import java.util.function.BiConsumer;
import java.util.function.IntConsumer;
import java.util.function.ObjLongConsumer;
import org.agrona.DirectBuffer;
import org.agrona.MutableDirectBuffer;
import org.agrona.concurrent.UnsafeBuffer;
import org.jspecify.annotations.NullMarked;
import org.jspecify.annotations.Nullable;
import org.slf4j.Logger;

@NullMarked
public final class BrokerInfo implements BufferReader, BufferWriter {

  public static final String DEFAULT_PARTITION_GROUP = PhysicalTenantIds.DEFAULT_PHYSICAL_TENANT_ID;

  private static final String BROKER_INFO_PROPERTY_NAME = "brokerInfo";
  private static final DirectBuffer COMMAND_API_NAME = wrapString("commandApi");
  private static final byte[] EMPTY_BYTE_ARRAY = new byte[0];

  private static final Logger LOG = Loggers.PROTOCOL_LOGGER;

  private static final Encoder BASE_64_ENCODER = Base64.getEncoder();
  private static final Decoder BASE_64_DECODER = Base64.getDecoder();
  private static final Charset BASE_64_CHARSET = StandardCharsets.UTF_8;

  private final MessageHeaderEncoder headerEncoder = new MessageHeaderEncoder();
  private final MessageHeaderDecoder headerDecoder = new MessageHeaderDecoder();

  private final BrokerInfoEncoder bodyEncoder = new BrokerInfoEncoder();
  private final BrokerInfoDecoder bodyDecoder = new BrokerInfoDecoder();
  private final Map<DirectBuffer, DirectBuffer> addresses = new HashMap<>();
  private final Map<Integer, PartitionRole> partitionRoles = new HashMap<>();
  private final Map<Integer, Long> partitionLeaderTerms = new HashMap<>();
  private final Map<Integer, PartitionHealthStatus> partitionHealthStatuses = new HashMap<>();

  private int nodeId;
  private int clusterSize;
  private DirectBuffer version = new UnsafeBuffer();
  private @Nullable String zone;
  private @Nullable String partitionGroup;

  public BrokerInfo() {
    reset();
  }

  public BrokerInfo(final int nodeId, @Nullable final String zone, final String commandApiAddress) {
    reset();
    this.nodeId = nodeId;
    this.zone = zone;
    setCommandApiAddress(BufferUtil.wrapString(commandApiAddress));
  }

  public BrokerInfo reset() {
    nodeId = nodeIdNullValue();
    clusterSize = clusterSizeNullValue();
    addresses.clear();
    version.wrap(0, 0);
    zone = null;
    partitionGroup = null;
    clearPartitions();

    return this;
  }

  public void clearPartitions() {
    partitionRoles.clear();
    partitionLeaderTerms.clear();
    partitionHealthStatuses.clear();
  }

  public void removePartition(final int partitionId) {
    partitionRoles.remove(partitionId);
    partitionLeaderTerms.remove(partitionId);
    partitionHealthStatuses.remove(partitionId);
  }

  @Deprecated
  public int getNodeId() {
    if (nodeIdNullValue() == nodeId) {
      throw new IllegalStateException("nodeId is not set");
    }
    return nodeId;
  }

  public BrokerInfo setBrokerId(final int nodeId, @Nullable final String zone) {
    this.nodeId = nodeId;
    this.zone = zone;
    return this;
  }

  public String brokerIdStr() {
    return MemberIdUtil.memberIdString(zone, getNodeId());
  }

  public int getClusterSize() {
    if (clusterSizeNullValue() == clusterSize) {
      throw new IllegalStateException("clusterSize is not set");
    }
    return clusterSize;
  }

  public BrokerInfo setClusterSize(final int clusterSize) {
    if (clusterSize <= 0) {
      throw new IllegalArgumentException("clusterSize must be positive, was " + clusterSize);
    }
    this.clusterSize = clusterSize;
    return this;
  }

  public String getVersion() {
    return BufferUtil.bufferAsString(version);
  }

  public void setVersion(final String version) {
    this.version = BufferUtil.wrapString(version);
  }

  public void setVersion(final DirectBuffer buffer, final int offset, final int length) {
    version.wrap(buffer, offset, length);
  }

  public @Nullable String getZone() {
    return zone;
  }

  public String getPartitionGroup() {
    // can be null for older versions that are received via gossip, but in that case we want to
    // treat is as the default partition group.
    return partitionGroup != null ? partitionGroup : DEFAULT_PARTITION_GROUP;
  }

  public BrokerInfo setPartitionGroup(final String partitionGroup) {
    // partitionGroup can only be null in older versions that are received via gossip.
    Objects.requireNonNull(partitionGroup);
    if (partitionGroup.isBlank()) {
      throw new IllegalArgumentException("partitionGroup must not be blank");
    }
    this.partitionGroup = partitionGroup.isBlank() ? null : partitionGroup;
    return this;
  }

  public Map<DirectBuffer, DirectBuffer> getAddresses() {
    return addresses;
  }

  public BrokerInfo addAddress(final DirectBuffer apiName, final DirectBuffer address) {
    addresses.put(apiName, address);
    return this;
  }

  public @Nullable String getCommandApiAddress() {
    final DirectBuffer buffer = addresses.get(COMMAND_API_NAME);
    if (buffer != null) {
      return BufferUtil.bufferAsString(buffer);
    } else {
      return null;
    }
  }

  public BrokerInfo setCommandApiAddress(final String address) {
    return setCommandApiAddress(BufferUtil.wrapString(address));
  }

  public BrokerInfo setCommandApiAddress(final DirectBuffer address) {
    return addAddress(COMMAND_API_NAME, address);
  }

  public Map<Integer, PartitionRole> getPartitionRoles() {
    return partitionRoles;
  }

  public Map<Integer, PartitionHealthStatus> getPartitionHealthStatuses() {
    return partitionHealthStatuses;
  }

  public Map<Integer, Long> getPartitionLeaderTerms() {
    return partitionLeaderTerms;
  }

  public BrokerInfo addPartitionRole(final Integer partitionId, final PartitionRole role) {
    partitionRoles.put(partitionId, role);
    return this;
  }

  public BrokerInfo addPartitionHealth(
      final Integer partitionId, final PartitionHealthStatus status) {
    partitionHealthStatuses.put(partitionId, status);
    return this;
  }

  public BrokerInfo setPartitionUnhealthy(final Integer partitionId) {
    addPartitionHealth(partitionId, PartitionHealthStatus.UNHEALTHY);
    return this;
  }

  public BrokerInfo setPartitionHealthy(final Integer partitionId) {
    addPartitionHealth(partitionId, PartitionHealthStatus.HEALTHY);
    return this;
  }

  public BrokerInfo setPartitionDead(final Integer partitionId) {
    addPartitionHealth(partitionId, PartitionHealthStatus.DEAD);
    return this;
  }

  public BrokerInfo setFollowerForPartition(final int partitionId) {
    partitionLeaderTerms.remove(partitionId);
    return addPartitionRole(partitionId, PartitionRole.FOLLOWER);
  }

  public BrokerInfo setLeaderForPartition(final int partitionId, final long term) {
    partitionLeaderTerms.put(partitionId, term);
    return addPartitionRole(partitionId, PartitionRole.LEADER);
  }

  public BrokerInfo setInactiveForPartition(final int partitionId) {
    partitionLeaderTerms.remove(partitionId);
    return addPartitionRole(partitionId, PartitionRole.INACTIVE);
  }

  // TODO: This will be fixed in the https://github.com/zeebe-io/zeebe/issues/5640
  @Override
  public void wrap(final DirectBuffer buffer, int offset, final int length) {
    reset();

    final int frameEnd = offset + length;

    headerDecoder.wrap(buffer, offset);

    offset += headerDecoder.encodedLength();

    bodyDecoder.wrap(buffer, offset, headerDecoder.blockLength(), headerDecoder.version());

    nodeId = bodyDecoder.nodeId();
    clusterSize = bodyDecoder.clusterSize();

    final AddressesDecoder addressesDecoder = bodyDecoder.addresses();
    while (addressesDecoder.hasNext()) {
      addressesDecoder.next();
      final int apiNameLength = addressesDecoder.apiNameLength();
      final byte[] apiNameBytes = new byte[apiNameLength];
      addressesDecoder.getApiName(apiNameBytes, 0, apiNameLength);

      final int addressLength = addressesDecoder.addressLength();
      final byte[] addressBytes = new byte[addressLength];
      addressesDecoder.getAddress(addressBytes, 0, addressLength);

      addAddress(new UnsafeBuffer(apiNameBytes), new UnsafeBuffer(addressBytes));
    }

    final PartitionRolesDecoder partitionRolesDecoder = bodyDecoder.partitionRoles();
    while (partitionRolesDecoder.hasNext()) {
      partitionRolesDecoder.next();
      addPartitionRole(partitionRolesDecoder.partitionId(), partitionRolesDecoder.role());
    }

    final PartitionLeaderTermsDecoder partitionLeaderTermsDecoder =
        bodyDecoder.partitionLeaderTerms();
    while (partitionLeaderTermsDecoder.hasNext()) {
      partitionLeaderTermsDecoder.next();
      partitionLeaderTerms.put(
          partitionLeaderTermsDecoder.partitionId(), partitionLeaderTermsDecoder.term());
    }

    // NOTE: this is the wrong position, but for compatibility it needs to stay here, before
    // partitionHealthCount
    if (bodyDecoder.versionLength() > 0) {
      bodyDecoder.wrapVersion(version);
    } else {
      version.wrap(EMPTY_BYTE_ARRAY);
      bodyDecoder.skipVersion();
    }

    final PartitionHealthDecoder partitionHealthDecoder = bodyDecoder.partitionHealth();
    while (partitionHealthDecoder.hasNext()) {
      partitionHealthDecoder.next();
      partitionHealthStatuses.put(
          partitionHealthDecoder.partitionId(), partitionHealthDecoder.healthStatus());
    }

    // NOTE: this is the wrong position, but for compatibility it needs to stay here, after
    // partitionHealthCount
    if (bodyDecoder.zoneLength() > 0) {
      zone = bodyDecoder.zone();
    } else {
      zone = null;
      bodyDecoder.skipZone();
    }

    if (bodyDecoder.partitionGroupLength() > 0) {
      partitionGroup = bodyDecoder.partitionGroup();
    } else {
      partitionGroup = null;
      bodyDecoder.skipPartitionGroup();
    }

    assert bodyDecoder.limit() == frameEnd
        : "Decoder read only to position "
            + bodyDecoder.limit()
            + " but expected "
            + frameEnd
            + " as final position";
  }

  @Override
  public int getLength() {
    int length =
        headerEncoder.encodedLength()
            + bodyEncoder.sbeBlockLength()
            + AddressesEncoder.sbeHeaderSize()
            + PartitionRolesEncoder.sbeHeaderSize()
            + PartitionLeaderTermsEncoder.sbeHeaderSize()
            + PartitionHealthEncoder.sbeHeaderSize()
            + versionHeaderLength()
            + version.capacity()
            + zoneHeaderLength()
            + (zone != null ? zone.getBytes(StandardCharsets.UTF_8).length : 0)
            + partitionGroupHeaderLength()
            + (partitionGroup != null ? partitionGroup.getBytes(StandardCharsets.UTF_8).length : 0);

    for (final Entry<DirectBuffer, DirectBuffer> entry : addresses.entrySet()) {
      length +=
          AddressesEncoder.sbeBlockLength()
              + AddressesEncoder.apiNameHeaderLength()
              + entry.getKey().capacity()
              + AddressesEncoder.addressHeaderLength()
              + entry.getValue().capacity();
    }

    length += partitionRoles.size() * PartitionRolesEncoder.sbeBlockLength();
    length += partitionLeaderTerms.size() * PartitionLeaderTermsEncoder.sbeBlockLength();
    length += partitionHealthStatuses.size() * PartitionHealthEncoder.sbeBlockLength();

    return length;
  }

  // TODO: This will be fixed in the https://github.com/zeebe-io/zeebe/issues/5640
  @Override
  public int write(final MutableDirectBuffer buffer, final int offset) {
    bodyEncoder
        .wrapAndApplyHeader(buffer, offset, headerEncoder)
        .nodeId(nodeId)
        .clusterSize(clusterSize);

    final int addressesCount = addresses.size();
    final AddressesEncoder addressesEncoder = bodyEncoder.addressesCount(addressesCount);
    if (addressesCount > 0) {
      for (final Entry<DirectBuffer, DirectBuffer> entry : addresses.entrySet()) {
        final DirectBuffer apiName = entry.getKey();
        final DirectBuffer address = entry.getValue();

        addressesEncoder
            .next()
            .putApiName(apiName, 0, apiName.capacity())
            .putAddress(address, 0, address.capacity());
      }
    }

    final int partitionRolesCount = partitionRoles.size();
    final PartitionRolesEncoder partitionRolesEncoder =
        bodyEncoder.partitionRolesCount(partitionRolesCount);

    if (partitionRolesCount > 0) {
      for (final Entry<Integer, PartitionRole> entry : partitionRoles.entrySet()) {
        partitionRolesEncoder.next().partitionId(entry.getKey()).role(entry.getValue());
      }
    }

    final int partitionLeaderTermsCount = partitionLeaderTerms.size();
    final PartitionLeaderTermsEncoder partitionLeaderTermsEncoder =
        bodyEncoder.partitionLeaderTermsCount(partitionLeaderTermsCount);

    if (partitionLeaderTermsCount > 0) {
      for (final Entry<Integer, Long> entry : partitionLeaderTerms.entrySet()) {
        partitionLeaderTermsEncoder.next().partitionId(entry.getKey()).term(entry.getValue());
      }
    }

    // NOTE: this is the wrong position, but for compatibility it needs to stay here, before
    // partitionHealthCount
    bodyEncoder.putVersion(version, 0, version.capacity());

    final int partitionHealthCount = partitionHealthStatuses.size();
    final PartitionHealthEncoder partitionHealthEncoder =
        bodyEncoder.partitionHealthCount(partitionHealthCount);

    if (partitionHealthCount > 0) {
      for (final Entry<Integer, PartitionHealthStatus> entry : partitionHealthStatuses.entrySet()) {
        partitionHealthEncoder.next().partitionId(entry.getKey()).healthStatus(entry.getValue());
      }
    }

    // NOTE: this is the wrong position, but for compatibility it needs to stay here, after
    // partitionHealthCount
    if (zone != null) {
      bodyEncoder.zone(zone);
    } else {
      bodyEncoder.putZone(EMPTY_BYTE_ARRAY, 0, 0);
    }

    if (partitionGroup != null) {
      bodyEncoder.partitionGroup(partitionGroup);
    } else {
      bodyEncoder.putPartitionGroup(EMPTY_BYTE_ARRAY, 0, 0);
    }

    return headerEncoder.encodedLength() + bodyEncoder.encodedLength();
  }

  public static @Nullable BrokerInfo fromProperties(final Properties properties) {
    final String property = properties.getProperty(BROKER_INFO_PROPERTY_NAME);
    if (property != null) {
      return readFromString(property);
    } else {
      return null;
    }
  }

  /**
   * Reads the {@link BrokerInfo} for the given {@code partitionGroup} from member properties. The
   * default group uses the legacy key {@value #BROKER_INFO_PROPERTY_NAME}; other groups use a
   * namespaced key of the form {@code "brokerInfo:<group>"}. Returns {@code null} if no entry
   * exists for that group.
   */
  public static @Nullable BrokerInfo fromProperties(
      final Properties properties, final String partitionGroup) {
    final String key = brokerInfoPropertyName(partitionGroup);
    final String property = properties.getProperty(key);
    return property != null ? readFromString(property) : null;
  }

  /**
   * Reads all {@link BrokerInfo} entries from member properties. Collects all keys equal to {@value
   * #BROKER_INFO_PROPERTY_NAME} (legacy/default group) or starting with {@value
   * #BROKER_INFO_PROPERTY_NAME}{@code ":"} (namespaced non-default groups). Used by the topology
   * manager to aggregate per-group topology from a single member.
   */
  public static List<BrokerInfo> allFromProperties(final Properties properties) {
    final List<BrokerInfo> result = new ArrayList<>();
    for (final String key : properties.stringPropertyNames()) {
      if (key.equals(BROKER_INFO_PROPERTY_NAME)
          || key.startsWith(BROKER_INFO_PROPERTY_NAME + ":")) {
        final String property = properties.getProperty(key);
        if (property != null) {
          result.add(readFromString(property));
        }
      }
    }
    return result;
  }

  private static BrokerInfo readFromString(final String property) {
    final byte[] bytes = BASE_64_DECODER.decode(property.getBytes(BASE_64_CHARSET));

    final BrokerInfo brokerInfo = new BrokerInfo();
    brokerInfo.wrap(new UnsafeBuffer(bytes), 0, bytes.length);

    return brokerInfo;
  }

  /**
   * Returns the member-property key under which a broker publishes its {@link BrokerInfo} for the
   * given partition group. The default group uses the legacy {@value #BROKER_INFO_PROPERTY_NAME}
   * key so that older readers continue to work during rolling upgrades. Non-default groups use a
   * namespaced key of the form {@code "brokerInfo:<partitionGroup>"}.
   */
  public static String brokerInfoPropertyName(final String partitionGroup) {
    if (PhysicalTenantIds.DEFAULT_PHYSICAL_TENANT_ID.equals(partitionGroup)) {
      return BROKER_INFO_PROPERTY_NAME;
    }
    return BROKER_INFO_PROPERTY_NAME + ":" + partitionGroup;
  }

  /**
   * Creates a copy of this {@link BrokerInfo} carrying only the broker-level fields (node ID, zone,
   * cluster config, version, addresses) with the given {@code partitionGroup} set. The returned
   * instance has empty partition-role, leader-term, and health maps so it can be used as the
   * starting point for a per-tenant {@code TopologyManagerImpl}.
   */
  public BrokerInfo withPartitionGroup(final String partitionGroup) {
    final BrokerInfo copy = new BrokerInfo();
    // Direct field assignment avoids validation checks so that null-sentinel values
    // (e.g. partitionsCount before it has been set) are preserved faithfully.
    copy.nodeId = nodeId;
    copy.zone = zone;
    copy.clusterSize = clusterSize;
    copy.version = BufferUtil.cloneBuffer(version);
    copy.partitionGroup = partitionGroup;
    addresses.forEach(copy::addAddress);
    return copy;
  }

  public void writeIntoProperties(final Properties memberProperties) {
    writeIntoProperties(memberProperties, brokerInfoPropertyName(getPartitionGroup()));
  }

  public void writeIntoProperties(final Properties memberProperties, final String propertyKey) {
    memberProperties.setProperty(propertyKey, writeToString());
  }

  private String writeToString() {
    final byte[] bytes = new byte[getLength()];
    final UnsafeBuffer buffer = new UnsafeBuffer(bytes);
    write(buffer, 0);
    return new String(BASE_64_ENCODER.encode(bytes), BASE_64_CHARSET);
  }

  public void consumePartitions(
      final ObjLongConsumer<Integer> leaderPartitionConsumer,
      final IntConsumer followerPartitionsConsumer,
      final IntConsumer inactivePartitionsConsumer) {
    consumePartitions(
        p -> {}, leaderPartitionConsumer, followerPartitionsConsumer, inactivePartitionsConsumer);
  }

  public void consumePartitions(
      final IntConsumer partitionConsumer,
      final ObjLongConsumer<Integer> leaderPartitionConsumer,
      final IntConsumer followerPartitionsConsumer,
      final IntConsumer inactivePartitionsConsumer) {
    partitionRoles.forEach(
        (partition, role) -> {
          partitionConsumer.accept(partition);
          switch (role) {
            case LEADER:
              final var term =
                  Objects.requireNonNull(
                      partitionLeaderTerms.get(partition),
                      "missing term for partition " + partition);
              leaderPartitionConsumer.accept(partition, term);
              break;
            case FOLLOWER:
              followerPartitionsConsumer.accept(partition);
              break;
            case INACTIVE:
              inactivePartitionsConsumer.accept(partition);
              break;
            default:
              LOG.warn("Failed to decode broker info, found unknown partition role: {}", role);
          }
        });
  }

  public void consumePartitionsHealth(
      final BiConsumer<Integer, PartitionHealthStatus> partitionConsumer) {
    partitionHealthStatuses.forEach(partitionConsumer);
  }

  @Override
  public String toString() {
    return "BrokerInfo{"
        + "nodeId="
        + nodeId
        + ", clusterSize="
        + clusterSize
        + ", partitionRoles="
        + partitionRoles
        + ", partitionLeaderTerms="
        + partitionLeaderTerms
        + ", partitionHealthStatuses="
        + partitionHealthStatuses
        + ", version="
        + BufferUtil.bufferAsString(version)
        + ", zone="
        + zone
        + ", partitionGroup="
        + partitionGroup
        + '}';
  }
}
