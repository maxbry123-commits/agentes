/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */
package io.camunda.zeebe.protocol.impl.record.value.deployment;

import static io.camunda.zeebe.protocol.impl.record.value.processinstance.ProcessInstanceRecord.BPMN_PROCESS_ID_KEY;
import static io.camunda.zeebe.protocol.impl.record.value.processinstance.ProcessInstanceRecord.PROCESS_DEFINITION_KEY_KEY;
import static io.camunda.zeebe.protocol.impl.record.value.processinstance.ProcessInstanceRecord.VERSION_KEY;

import com.fasterxml.jackson.annotation.JsonIgnore;
import io.camunda.zeebe.msgpack.UnpackedObject;
import io.camunda.zeebe.msgpack.property.ArrayProperty;
import io.camunda.zeebe.msgpack.property.BinaryProperty;
import io.camunda.zeebe.msgpack.property.BooleanProperty;
import io.camunda.zeebe.msgpack.property.IntegerProperty;
import io.camunda.zeebe.msgpack.property.LongProperty;
import io.camunda.zeebe.msgpack.property.StringProperty;
import io.camunda.zeebe.msgpack.value.IntegerValue;
import io.camunda.zeebe.protocol.impl.record.UnifiedRecordValue;
import io.camunda.zeebe.protocol.record.value.TenantOwned;
import io.camunda.zeebe.protocol.record.value.deployment.Process;
import io.camunda.zeebe.util.buffer.BufferUtil;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import org.agrona.DirectBuffer;
import org.agrona.concurrent.UnsafeBuffer;

public final class ProcessRecord extends UnifiedRecordValue implements Process {
  private final StringProperty bpmnProcessIdProp = new StringProperty(BPMN_PROCESS_ID_KEY);
  private final IntegerProperty versionProp = new IntegerProperty(VERSION_KEY);
  private final LongProperty keyProp = new LongProperty(PROCESS_DEFINITION_KEY_KEY);
  private final StringProperty resourceNameProp = new StringProperty("resourceName");
  private final BinaryProperty checksumProp = new BinaryProperty("checksum", new UnsafeBuffer());
  private final BinaryProperty resourceProp = new BinaryProperty("resource", new UnsafeBuffer());
  private final StringProperty tenantIdProp =
      new StringProperty("tenantId", TenantOwned.DEFAULT_TENANT_IDENTIFIER);
  private final LongProperty deploymentKeyProp = new LongProperty("deploymentKey", -1);
  private final StringProperty versionTagProp = new StringProperty("versionTag", "");
  private final ArrayProperty<TransformerVersion> transformerVersionsProp =
      new ArrayProperty<>("transformerVersions", TransformerVersion::new);
  private final BooleanProperty deleteHistoryProp = new BooleanProperty("deleteHistory", false);
  private final ArrayProperty<IntegerValue> drainPartitionsProp =
      new ArrayProperty<>("drainPartitions", IntegerValue::new);

  public ProcessRecord() {
    super(12);
    declareProperty(bpmnProcessIdProp)
        .declareProperty(versionProp)
        .declareProperty(keyProp)
        .declareProperty(resourceNameProp)
        .declareProperty(checksumProp)
        .declareProperty(resourceProp)
        .declareProperty(tenantIdProp)
        .declareProperty(deploymentKeyProp)
        .declareProperty(versionTagProp)
        .declareProperty(transformerVersionsProp)
        .declareProperty(deleteHistoryProp)
        .declareProperty(drainPartitionsProp);
  }

  public ProcessRecord wrap(final ProcessMetadata metadata, final byte[] resource) {
    bpmnProcessIdProp.setValue(metadata.getBpmnProcessIdBuffer());
    versionProp.setValue(metadata.getVersion());
    checksumProp.setValue(metadata.getChecksumBuffer());
    keyProp.setValue(metadata.getKey());
    resourceNameProp.setValue(metadata.getResourceNameBuffer());
    resourceProp.setValue(BufferUtil.wrapArray(resource));
    tenantIdProp.setValue(metadata.getTenantId());
    deploymentKeyProp.setValue(metadata.getDeploymentKey());
    versionTagProp.setValue(metadata.getVersionTag());
    return this;
  }

  @Override
  public String getBpmnProcessId() {
    return BufferUtil.bufferAsString(bpmnProcessIdProp.getValue());
  }

  @Override
  public int getVersion() {
    return versionProp.getValue();
  }

  public ProcessRecord setVersion(final int version) {
    versionProp.setValue(version);
    return this;
  }

  @Override
  public String getVersionTag() {
    return BufferUtil.bufferAsString(versionTagProp.getValue());
  }

  @Override
  public long getProcessDefinitionKey() {
    return getKey();
  }

  @Override
  public String getResourceName() {
    return BufferUtil.bufferAsString(resourceNameProp.getValue());
  }

  @Override
  public byte[] getChecksum() {
    return BufferUtil.bufferAsArray(checksumProp.getValue());
  }

  @Override
  public boolean isDuplicate() {
    return false;
  }

  @Override
  public long getDeploymentKey() {
    return deploymentKeyProp.getValue();
  }

  public ProcessRecord setDeploymentKey(final long deploymentKey) {
    deploymentKeyProp.setValue(deploymentKey);
    return this;
  }

  public ProcessRecord setChecksum(final DirectBuffer checksumBuffer) {
    checksumProp.setValue(checksumBuffer);
    return this;
  }

  public ProcessRecord setResourceName(final String resourceName) {
    resourceNameProp.setValue(resourceName);
    return this;
  }

  public ProcessRecord setResourceName(final DirectBuffer resourceName) {
    resourceNameProp.setValue(resourceName);
    return this;
  }

  public ProcessRecord setVersionTag(final String versionTag) {
    versionTagProp.setValue(versionTag);
    return this;
  }

  public ProcessRecord setBpmnProcessId(final String bpmnProcessId) {
    bpmnProcessIdProp.setValue(bpmnProcessId);
    return this;
  }

  public ProcessRecord setBpmnProcessId(final DirectBuffer bpmnProcessId) {
    bpmnProcessIdProp.setValue(bpmnProcessId);
    return this;
  }

  @JsonIgnore
  public DirectBuffer getChecksumBuffer() {
    return checksumProp.getValue();
  }

  @Override
  public byte[] getResource() {
    return BufferUtil.bufferAsArray(resourceProp.getValue());
  }

  public ProcessRecord setResource(final DirectBuffer resource) {
    return setResource(resource, 0, resource.capacity());
  }

  @JsonIgnore
  public long getKey() {
    return keyProp.getValue();
  }

  public ProcessRecord setKey(final long key) {
    keyProp.setValue(key);
    return this;
  }

  @JsonIgnore
  public DirectBuffer getBpmnProcessIdBuffer() {
    return bpmnProcessIdProp.getValue();
  }

  @Override
  @JsonIgnore
  public int getLength() {
    return super.getLength();
  }

  @Override
  @JsonIgnore
  public int getEncodedLength() {
    return super.getEncodedLength();
  }

  @JsonIgnore
  public DirectBuffer getResourceNameBuffer() {
    return resourceNameProp.getValue();
  }

  public ProcessRecord setBpmnProcessId(
      final DirectBuffer bpmnProcessId, final int offset, final int length) {
    bpmnProcessIdProp.setValue(bpmnProcessId, offset, length);
    return this;
  }

  public ProcessRecord setResource(
      final DirectBuffer resource, final int offset, final int length) {
    resourceProp.setValue(resource, offset, length);
    return this;
  }

  @JsonIgnore
  public DirectBuffer getResourceBuffer() {
    return resourceProp.getValue();
  }

  @Override
  public String getTenantId() {
    return BufferUtil.bufferAsString(tenantIdProp.getValue());
  }

  public ProcessRecord setTenantId(final String tenantId) {
    tenantIdProp.setValue(tenantId);
    return this;
  }

  /**
   * Returns the stored slot→version pairs sorted by slot ID. Absent entries default to version 1.
   * Excluded from JSON export — engine-internal state not exposed to external consumers.
   */
  @JsonIgnore
  public Map<Integer, Integer> getTransformerVersions() {
    final Map<Integer, Integer> result = new TreeMap<>();
    for (final TransformerVersion entry : transformerVersionsProp) {
      result.put(entry.getSlotId(), entry.getVersion());
    }
    return result;
  }

  /**
   * Sets the per-slot transformer versions frozen at deploy time. Entries are sorted by slot ID
   * before writing so the msgpack array is always in a deterministic order regardless of the input
   * map's iteration order. Version-1 entries are stored but redundant — {@link
   * io.camunda.zeebe.engine.processing.deployment.model.transformation.BpmnTransformer#currentVersionsById()}
   * omits them automatically, so callers using that method need not filter.
   */
  public ProcessRecord setTransformerVersions(final Map<Integer, Integer> versions) {
    transformerVersionsProp.reset();
    new TreeMap<>(versions)
        .forEach(
            (slotId, version) -> {
              final var entry = transformerVersionsProp.add();
              entry.setSlotId(slotId);
              entry.setVersion(version);
            });
    return this;
  }

  /**
   * Whether the instances' history must be deleted once the definition is gone cluster-wide.
   * Carried on {@code DRAINING} to be persisted with the draining definition, then back on the
   * {@code DELETE_COMPLETE} drain report so the deployment partition knows whether to delete it.
   * Excluded from JSON export — engine-internal coordination.
   */
  @JsonIgnore
  public boolean isDeleteHistory() {
    return deleteHistoryProp.getValue();
  }

  public ProcessRecord setDeleteHistory(final boolean deleteHistory) {
    deleteHistoryProp.setValue(deleteHistory);
    return this;
  }

  /** Partitions frozen at DRAINING time to seed drain-aggregation. Only set on DRAINING events. */
  @JsonIgnore
  public List<Integer> getDrainPartitions() {
    final List<Integer> result = new ArrayList<>();
    for (final IntegerValue partitionId : drainPartitionsProp) {
      result.add(partitionId.getValue());
    }
    return result;
  }

  public ProcessRecord setDrainPartitions(final Collection<Integer> partitionIds) {
    drainPartitionsProp.reset();
    // Sort to keep the serialized record deterministic across runs.
    partitionIds.stream()
        .sorted()
        .forEach(partitionId -> drainPartitionsProp.add().setValue(partitionId));
    return this;
  }

  /** A single (slotId, version) pair persisted inside the transformer-versions array. */
  public static final class TransformerVersion extends UnpackedObject {
    private final IntegerProperty slotIdProp = new IntegerProperty("slotId");
    private final IntegerProperty versionProp = new IntegerProperty("version");

    public TransformerVersion() {
      super(2);
      declareProperty(slotIdProp).declareProperty(versionProp);
    }

    public int getSlotId() {
      return slotIdProp.getValue();
    }

    public TransformerVersion setSlotId(final int slotId) {
      slotIdProp.setValue(slotId);
      return this;
    }

    public int getVersion() {
      return versionProp.getValue();
    }

    public TransformerVersion setVersion(final int version) {
      versionProp.setValue(version);
      return this;
    }
  }
}
