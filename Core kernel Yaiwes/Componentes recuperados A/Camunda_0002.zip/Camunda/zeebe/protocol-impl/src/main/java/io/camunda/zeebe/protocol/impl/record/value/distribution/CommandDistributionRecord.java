/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */
package io.camunda.zeebe.protocol.impl.record.value.distribution;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.camunda.zeebe.msgpack.property.EnumProperty;
import io.camunda.zeebe.msgpack.property.IntegerProperty;
import io.camunda.zeebe.msgpack.property.LongProperty;
import io.camunda.zeebe.msgpack.property.ObjectProperty;
import io.camunda.zeebe.msgpack.property.StringProperty;
import io.camunda.zeebe.msgpack.spec.MsgPackReader;
import io.camunda.zeebe.msgpack.spec.MsgPackWriter;
import io.camunda.zeebe.msgpack.value.StringValue;
import io.camunda.zeebe.protocol.impl.encoding.AuthInfo;
import io.camunda.zeebe.protocol.impl.record.UnifiedRecordValue;
import io.camunda.zeebe.protocol.impl.record.value.authorization.AuthorizationRecord;
import io.camunda.zeebe.protocol.impl.record.value.authorization.IdentitySetupRecord;
import io.camunda.zeebe.protocol.impl.record.value.authorization.MappingRuleRecord;
import io.camunda.zeebe.protocol.impl.record.value.authorization.RoleRecord;
import io.camunda.zeebe.protocol.impl.record.value.batchoperation.BatchOperationCreationRecord;
import io.camunda.zeebe.protocol.impl.record.value.batchoperation.BatchOperationLifecycleManagementRecord;
import io.camunda.zeebe.protocol.impl.record.value.batchoperation.BatchOperationPartitionLifecycleRecord;
import io.camunda.zeebe.protocol.impl.record.value.clock.ClockRecord;
import io.camunda.zeebe.protocol.impl.record.value.clustervariable.ClusterVariableRecord;
import io.camunda.zeebe.protocol.impl.record.value.deployment.DeploymentRecord;
import io.camunda.zeebe.protocol.impl.record.value.deployment.ProcessRecord;
import io.camunda.zeebe.protocol.impl.record.value.globallistener.GlobalListenerBatchRecord;
import io.camunda.zeebe.protocol.impl.record.value.globallistener.GlobalListenerRecord;
import io.camunda.zeebe.protocol.impl.record.value.group.GroupRecord;
import io.camunda.zeebe.protocol.impl.record.value.message.MessageSubscriptionRecord;
import io.camunda.zeebe.protocol.impl.record.value.resource.ResourceDeletionRecord;
import io.camunda.zeebe.protocol.impl.record.value.scaling.ScaleRecord;
import io.camunda.zeebe.protocol.impl.record.value.signal.SignalRecord;
import io.camunda.zeebe.protocol.impl.record.value.tenant.TenantRecord;
import io.camunda.zeebe.protocol.impl.record.value.user.UserRecord;
import io.camunda.zeebe.protocol.record.ValueType;
import io.camunda.zeebe.protocol.record.intent.Intent;
import io.camunda.zeebe.protocol.record.value.CommandDistributionRecordValue;
import io.camunda.zeebe.util.buffer.BufferUtil;
import java.util.EnumMap;
import java.util.Map;
import java.util.function.Supplier;
import org.agrona.concurrent.UnsafeBuffer;

public final class CommandDistributionRecord extends UnifiedRecordValue
    implements CommandDistributionRecordValue {

  private static final Map<ValueType, Supplier<UnifiedRecordValue>> RECORDS_BY_TYPE =
      new EnumMap<>(ValueType.class);
  /*
   NOTE! When adding a new property here it must also be added to the ProtocolFactory! This class
   contains a randomizer implementation which is used to generate a random
   CommandDistributionRecord. The new property must be added there. Without it we won't generate a
   complete record.
  */
  // Static StringValue keys for property names
  private static final StringValue PARTITION_ID_KEY = new StringValue("partitionId");
  private static final StringValue QUEUE_ID_KEY = new StringValue("queueId");
  private static final StringValue VALUE_TYPE_KEY = new StringValue("valueType");
  private static final StringValue INTENT_KEY = new StringValue("intent");
  private static final StringValue COMMAND_VALUE_KEY = new StringValue("commandValue");
  private static final StringValue AUTH_INFO_KEY = new StringValue("authInfo");
  private static final StringValue START_TIME_KEY = new StringValue("startTime");

  // You'll need to register any of the records value's that you want to distribute
  static {
    RECORDS_BY_TYPE.put(ValueType.DEPLOYMENT, DeploymentRecord::new);
    RECORDS_BY_TYPE.put(ValueType.PROCESS, ProcessRecord::new);
    RECORDS_BY_TYPE.put(ValueType.MESSAGE_SUBSCRIPTION, MessageSubscriptionRecord::new);
    RECORDS_BY_TYPE.put(ValueType.RESOURCE_DELETION, ResourceDeletionRecord::new);
    RECORDS_BY_TYPE.put(ValueType.SIGNAL, SignalRecord::new);
    RECORDS_BY_TYPE.put(ValueType.USER, UserRecord::new);
    RECORDS_BY_TYPE.put(ValueType.CLOCK, ClockRecord::new);
    RECORDS_BY_TYPE.put(ValueType.AUTHORIZATION, AuthorizationRecord::new);
    RECORDS_BY_TYPE.put(ValueType.ROLE, RoleRecord::new);
    RECORDS_BY_TYPE.put(ValueType.TENANT, TenantRecord::new);
    RECORDS_BY_TYPE.put(ValueType.MAPPING_RULE, MappingRuleRecord::new);
    RECORDS_BY_TYPE.put(ValueType.GROUP, GroupRecord::new);
    RECORDS_BY_TYPE.put(ValueType.SCALE, ScaleRecord::new);
    RECORDS_BY_TYPE.put(ValueType.IDENTITY_SETUP, IdentitySetupRecord::new);
    RECORDS_BY_TYPE.put(ValueType.BATCH_OPERATION_CREATION, BatchOperationCreationRecord::new);
    RECORDS_BY_TYPE.put(
        ValueType.BATCH_OPERATION_LIFECYCLE_MANAGEMENT,
        BatchOperationLifecycleManagementRecord::new);
    RECORDS_BY_TYPE.put(
        ValueType.BATCH_OPERATION_PARTITION_LIFECYCLE, BatchOperationPartitionLifecycleRecord::new);
    RECORDS_BY_TYPE.put(ValueType.CLUSTER_VARIABLE, ClusterVariableRecord::new);
    RECORDS_BY_TYPE.put(ValueType.GLOBAL_LISTENER_BATCH, GlobalListenerBatchRecord::new);
    RECORDS_BY_TYPE.put(ValueType.GLOBAL_LISTENER, GlobalListenerRecord::new);
  }

  private final IntegerProperty partitionIdProperty = new IntegerProperty(PARTITION_ID_KEY);
  private final StringProperty queueIdProperty = new StringProperty(QUEUE_ID_KEY, "");
  private final EnumProperty<ValueType> valueTypeProperty =
      new EnumProperty<>(VALUE_TYPE_KEY, ValueType.class, ValueType.NULL_VAL);
  private final IntegerProperty intentProperty = new IntegerProperty(INTENT_KEY, Intent.NULL_VAL);
  private final ObjectProperty<UnifiedRecordValue> commandValueProperty =
      new ObjectProperty<>(COMMAND_VALUE_KEY, new UnifiedRecordValue(10));
  private final ObjectProperty<AuthInfo> authInfoProperty =
      new ObjectProperty<>(AUTH_INFO_KEY, new AuthInfo());
  private final MsgPackWriter commandValueWriter = new MsgPackWriter();
  private final MsgPackReader commandValueReader = new MsgPackReader();
  private final LongProperty startTimeProperty = new LongProperty(START_TIME_KEY, -1L);

  public CommandDistributionRecord() {
    super(7);
    declareProperty(partitionIdProperty)
        .declareProperty(queueIdProperty)
        .declareProperty(valueTypeProperty)
        .declareProperty(intentProperty)
        .declareProperty(commandValueProperty)
        .declareProperty(authInfoProperty)
        .declareProperty(startTimeProperty);
  }

  public CommandDistributionRecord wrap(final CommandDistributionRecord other) {
    setPartitionId(other.getPartitionId())
        .setQueueId(other.getQueueId())
        .setValueType(other.getValueType())
        .setIntent(other.getIntent())
        .setCommandValue(other.getCommandValue())
        .setAuthInfo(other.getAuthInfo());
    return this;
  }

  @Override
  public int getPartitionId() {
    return partitionIdProperty.getValue();
  }

  @Override
  public String getQueueId() {
    final var value = BufferUtil.bufferAsString(queueIdProperty.getValue());
    return value.isEmpty() ? null : value;
  }

  @Override
  public ValueType getValueType() {
    return valueTypeProperty.getValue();
  }

  @Override
  public Intent getIntent() {
    final int intentValue = intentProperty.getValue();
    if (intentValue < 0 || intentValue > Short.MAX_VALUE) {
      throw new IllegalStateException(
          String.format(
              "Expected to read the intent, but it's persisted value '%d' is not a short integer",
              intentValue));
    }
    return Intent.fromProtocolValue(getValueType(), (short) intentValue);
  }

  @Override
  public UnifiedRecordValue getCommandValue() {
    // fetch a concrete instance of the record value by type
    final var valueType = getValueType();
    if (valueType == ValueType.NULL_VAL) {
      return null;
    }

    final var storedCommandValue = commandValueProperty.getValue();
    if (storedCommandValue.isEmpty()) {
      return storedCommandValue;
    }

    final var concrecteCommandValueSupplier = RECORDS_BY_TYPE.get(valueType);
    if (concrecteCommandValueSupplier == null) {
      throw new IllegalStateException(
          "Expected to read the record value, but it's type `"
              + valueType.name()
              + "` is unknown. Please add it to CommandDistributionRecord.RECORDS_BY_TYPE");
    }
    final var concreteCommandValue = concrecteCommandValueSupplier.get();

    // write the command value property's content into a buffer
    final var commandValueBuffer = new UnsafeBuffer(0, 0);
    final int encodedLength = storedCommandValue.getEncodedLength();
    commandValueBuffer.wrap(new byte[encodedLength]);
    storedCommandValue.write(commandValueWriter.wrap(commandValueBuffer, 0));

    // read the value back from the buffer into the concrete command value
    concreteCommandValue.wrap(commandValueBuffer);
    return concreteCommandValue;
  }

  public CommandDistributionRecord setCommandValue(final UnifiedRecordValue commandValue) {
    if (commandValue == null) {
      commandValueProperty.reset();
      return this;
    }

    // inspired by IndexedRecord.setValue
    final var valueBuffer = new UnsafeBuffer(0, 0);
    final int encodedLength = commandValue.getLength();
    valueBuffer.wrap(new byte[encodedLength]);

    commandValue.write(valueBuffer, 0);
    commandValueProperty.getValue().read(commandValueReader.wrap(valueBuffer, 0, encodedLength));
    return this;
  }

  public CommandDistributionRecord setIntent(final Intent intent) {
    intentProperty.setValue(intent.value());
    return this;
  }

  public CommandDistributionRecord setValueType(final ValueType valueType) {
    valueTypeProperty.setValue(valueType);
    return this;
  }

  public CommandDistributionRecord setQueueId(final String queueId) {
    if (queueId == null) {
      queueIdProperty.reset();
    } else {
      queueIdProperty.setValue(queueId);
    }
    return this;
  }

  public CommandDistributionRecord setPartitionId(final int partitionId) {
    partitionIdProperty.setValue(partitionId);
    return this;
  }

  public long getStartTime() {
    return startTimeProperty.getValue();
  }

  public CommandDistributionRecord setStartTime(final long startTimeProperty) {
    this.startTimeProperty.setValue(startTimeProperty);
    return this;
  }

  @JsonIgnoreProperties
  public AuthInfo getAuthInfo() {
    return authInfoProperty.getValue();
  }

  public CommandDistributionRecord setAuthInfo(final AuthInfo authInfo) {
    authInfoProperty.getValue().copyFrom(authInfo);
    return this;
  }
}
