import { Suspense, useCallback, useMemo, useState } from "react";
import { graphql, useMutation } from "react-relay";
import { useNavigate } from "react-router";

import {
  Alert,
  Button,
  Dialog,
  DialogTrigger,
  Flex,
  Group,
  Icon,
  IconButton,
  Icons,
  Modal,
  ModalOverlay,
  ViewportModal,
  ViewportModalOverlay,
  Popover,
  PopoverArrow,
  Text,
  Toolbar,
  View,
} from "@phoenix/components";
import {
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTitleExtra,
} from "@phoenix/components/core/dialog";
import { FloatingToolbarContainer } from "@phoenix/components/core/toolbar/FloatingToolbarContainer";
import { CreateDatasetForm } from "@phoenix/components/dataset/CreateDatasetForm";
import { useNotifySuccess } from "@phoenix/contexts";
import { useStreamState } from "@phoenix/contexts/StreamStateContext";
import { useTracingContext } from "@phoenix/contexts/TracingContext";
import { getErrorMessagesFromRelayMutationError } from "@phoenix/utils/errorUtils";

import { DatasetSelectorPopoverContent } from "./DatasetSelectorPopoverContent";
import { SpanSelectionDownloadButton } from "./SpanSelectionDownloadButton";
import { TransferTracesButton } from "./TransferTracesButton";

export interface SelectedSpan {
  /**
   * The span node (relay global) ID
   */
  id: string;
  /**
   * The OpenTelemetry span ID
   */
  spanId: string;
  trace: {
    /**
     * The trace node (relay global) ID
     */
    id: string;
    /**
     * The OpenTelemetry trace ID
     */
    traceId: string;
  };
}

type SpanSelectionToolbarProps = {
  projectName: string;
  selectedSpans: SelectedSpan[];
  onClearSelection: () => void;
};

export function SpanSelectionToolbar(props: SpanSelectionToolbarProps) {
  const projectId = useTracingContext((state) => state.projectId);
  const { setFetchKey } = useStreamState();
  const navigate = useNavigate();
  const notifySuccess = useNotifySuccess();
  const [error, setError] = useState<string | null>(null);
  const [isCreatingDataset, setIsCreatingDataset] = useState(false);
  const [isDatasetPopoverOpen, setIsDatasetPopoverOpen] = useState(false);
  const [isDeletingTracesDialogOpen, setIsDeletingTracesDialogOpen] =
    useState(false);
  const { projectName, selectedSpans, onClearSelection } = props;

  const traceIds = useMemo(
    () => [...new Set(selectedSpans.map((span) => span.trace.id))],
    [selectedSpans]
  );
  const [commitSpansToDataset, isAddingSpansToDataset] = useMutation(graphql`
    mutation SpanSelectionToolbarAddSpansToDatasetMutation(
      $input: AddSpansToDatasetInput!
    ) {
      addSpansToDataset(input: $input) {
        dataset {
          id
        }
      }
    }
  `);
  const [commitDeleteTraces, isDeletingTraces] = useMutation(graphql`
    mutation SpanSelectionToolbarDeleteTracesMutation($traceIds: [ID!]!) {
      deleteTraces(traceIds: $traceIds) {
        __typename
      }
    }
  `);
  const isPlural = selectedSpans.length !== 1;
  const onAddSpansToDataset = useCallback(
    (datasetId: string) => {
      setError(null);
      commitSpansToDataset({
        variables: {
          input: {
            datasetId,
            spanIds: selectedSpans.map((span) => span.id),
          },
        },
        onCompleted: () => {
          notifySuccess({
            title: "Examples added to dataset",
            message: `${selectedSpans.length} example${isPlural ? "s have" : " has"} been added to the dataset.`,
            action: {
              text: "View dataset",
              onClick: () => {
                // Navigate to the dataset page
                navigate(`/datasets/${datasetId}/examples`);
              },
            },
          });
          // Clear the selection
          onClearSelection();
        },
        onError: (error) => {
          const formattedError = getErrorMessagesFromRelayMutationError(error);
          setError(
            `Failed to add spans to dataset: ${formattedError?.[0] ?? error.message}`
          );
        },
      });
    },
    [
      commitSpansToDataset,
      selectedSpans,
      notifySuccess,
      isPlural,
      onClearSelection,
      navigate,
    ]
  );
  const onDeleteTraces = useCallback(() => {
    setError(null);
    commitDeleteTraces({
      variables: {
        traceIds,
      },
      onCompleted: () => {
        notifySuccess({
          title: "Traces deleted",
          message: `${traceIds.length} trace${traceIds.length !== 1 ? "s have" : " has"} been deleted.`,
        });
        onClearSelection();
      },
      onError: (error) => {
        const formattedError = getErrorMessagesFromRelayMutationError(error);
        setError(
          `Failed to delete traces: ${formattedError?.[0] ?? error.message}`
        );
      },
    });
  }, [commitDeleteTraces, traceIds, notifySuccess, onClearSelection]);

  const onDeletePress = () => {
    setIsDeletingTracesDialogOpen(true);
  };

  return (
    <FloatingToolbarContainer>
      {error && (
        <Alert
          variant="danger"
          dismissable
          onDismissClick={() => setError(null)}
        >
          {error}
        </Alert>
      )}
      <Toolbar>
        <Group aria-label="Span selection">
          <IconButton
            size="M"
            onPress={onClearSelection}
            aria-label="Clear selection"
          >
            <Icon svg={<Icons.Close />} />
          </IconButton>
          <View paddingEnd="size-100">
            <Text>{`${selectedSpans.length} span${isPlural ? "s" : ""} selected`}</Text>
          </View>
        </Group>
        <Group aria-label="Span selection actions">
          <DialogTrigger
            isOpen={isDatasetPopoverOpen}
            onOpenChange={(isOpen) => {
              setIsDatasetPopoverOpen(isOpen);
            }}
          >
            <Button
              variant="primary"
              size="M"
              leadingVisual={<Icon svg={<Icons.Plus />} />}
              onPress={() => {
                setIsDatasetPopoverOpen(true);
              }}
              isDisabled={isAddingSpansToDataset}
            >
              {isAddingSpansToDataset ? "Adding..." : "Add to Dataset"}
            </Button>
            <Popover placement="top end">
              <Suspense>
                <PopoverArrow />
                <Dialog>
                  <DatasetSelectorPopoverContent
                    onDatasetSelected={(datasetId) => {
                      onAddSpansToDataset(datasetId);
                      setIsDatasetPopoverOpen(false);
                    }}
                    onCreateNewDataset={() => {
                      setIsDatasetPopoverOpen(false);
                      setIsCreatingDataset(true);
                    }}
                  />
                </Dialog>
              </Suspense>
            </Popover>
          </DialogTrigger>
          <TransferTracesButton
            traceIds={traceIds}
            currentProjectId={projectId}
            onSuccess={({ projectName }) => {
              notifySuccess({
                title: "Transfer Success",
                message: `The traces have been moved to project: ${projectName}`,
              });
              onClearSelection();
              setFetchKey(`trace-transfer-${Date.now()}`);
            }}
            onError={(error) => {
              setError(`Failed to transfer due to error: ${error.message}`);
            }}
          />
          {/* Add dataset dialog */}
          <DialogTrigger
            isOpen={isCreatingDataset}
            onOpenChange={setIsCreatingDataset}
          >
            <ViewportModalOverlay>
              <ViewportModal>
                <Dialog>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>New Dataset</DialogTitle>
                      <DialogTitleExtra>
                        <Button
                          variant="default"
                          size="S"
                          onPress={() => {
                            setIsCreatingDataset(false);
                          }}
                          leadingVisual={<Icon svg={<Icons.Close />} />}
                        ></Button>
                      </DialogTitleExtra>
                    </DialogHeader>
                    <CreateDatasetForm
                      submitButtonText="Create and add"
                      onDatasetCreateError={(error) => {
                        const formattedError =
                          getErrorMessagesFromRelayMutationError(error);
                        setError(
                          `Failed to create dataset: ${formattedError?.[0] ?? error.message}`
                        );
                      }}
                      onDatasetCreated={(dataset) => {
                        setIsCreatingDataset(false);
                        onAddSpansToDataset(dataset.id);
                      }}
                    />
                  </DialogContent>
                </Dialog>
              </ViewportModal>
            </ViewportModalOverlay>
          </DialogTrigger>
          <SpanSelectionDownloadButton
            projectId={projectId}
            fileNamePrefix={projectName}
            selectedSpans={selectedSpans}
          />
          <Button
            size="M"
            aria-label="Delete Traces"
            isDisabled={isDeletingTraces}
            onPress={onDeletePress}
            variant="danger"
            leadingVisual={<Icon svg={<Icons.Trash />} />}
          ></Button>
          {/* Delete traces dialog */}
          <DialogTrigger
            isOpen={isDeletingTracesDialogOpen}
            onOpenChange={setIsDeletingTracesDialogOpen}
          >
            <ModalOverlay>
              <Modal>
                <Dialog>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Delete Traces</DialogTitle>
                    </DialogHeader>
                    <View padding="size-200">
                      <Text color="danger">
                        Are you sure you want to delete the selected spans and
                        their traces?
                      </Text>
                    </View>
                    <View
                      paddingEnd="size-200"
                      paddingTop="size-100"
                      paddingBottom="size-100"
                      borderTopColor="default"
                      borderTopWidth="thin"
                    >
                      <Flex direction="row" justifyContent="end" gap="size-100">
                        <Button
                          variant="default"
                          onPress={() => {
                            setIsDeletingTracesDialogOpen(false);
                          }}
                        >
                          Cancel
                        </Button>
                        <Button
                          variant="danger"
                          onPress={() => {
                            onDeleteTraces();
                            setIsDeletingTracesDialogOpen(false);
                          }}
                        >
                          Delete Traces
                        </Button>
                      </Flex>
                    </View>
                  </DialogContent>
                </Dialog>
              </Modal>
            </ModalOverlay>
          </DialogTrigger>
        </Group>
      </Toolbar>
    </FloatingToolbarContainer>
  );
}
