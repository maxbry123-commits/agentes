import { buildRouteInfoCatalog } from "@phoenix/agent/tools/getRouteInfo/catalog";
import { getRouteInfoFromCatalog } from "@phoenix/agent/tools/getRouteInfo/getRouteInfo";
import { appRouteObjects } from "@phoenix/Routes";

describe("profile route information", () => {
  const catalog = buildRouteInfoCatalog(appRouteObjects);

  it("registers clean metadata for the profile root and every section", () => {
    expect(
      catalog
        .filter((entry) => entry.path.startsWith("/profile"))
        .map((entry) => ({
          path: entry.path,
          label: entry.metadata.label,
          description: entry.metadata.description,
        }))
    ).toEqual([
      {
        path: "/profile",
        label: "Profile",
        description:
          "Open personal account settings, API keys, connected applications, display preferences, and accessibility options.",
      },
      {
        path: "/profile/account",
        label: "Profile Account",
        description:
          "View your email and role, update your username, and reset your local password.",
      },
      {
        path: "/profile/api-keys",
        label: "Profile API Keys",
        description:
          "Create, view, and revoke personal API keys for programmatic access.",
      },
      {
        path: "/profile/apps",
        label: "Profile Apps",
        description:
          "Review and revoke OAuth applications connected to your Phoenix account.",
      },
      {
        path: "/profile/preferences",
        label: "Profile Preferences",
        description:
          "Choose your theme, timezone, code language, and package manager defaults.",
      },
      {
        path: "/profile/accessibility",
        label: "Profile Accessibility",
        description:
          "Configure accessibility options and use native scrollbars from your browser and operating system.",
      },
      {
        path: "/profile/generative-ai",
        label: "Profile Generative AI",
        description:
          "Configure generative AI features: enable AI query for filter fields, choose the model — your browser's built-in on-device AI or a model provider with an API key — and manage the on-device model (download status, download it ahead of time, how to remove it).",
      },
    ]);
  });

  it.each([
    ["change my username", "/profile/account"],
    ["personal API key", "/profile/api-keys"],
    ["revoke connected OAuth app", "/profile/apps"],
    ["change my timezone", "/profile/preferences"],
    ["use native scrollbars", "/profile/accessibility"],
    ["enable AI query", "/profile/generative-ai"],
  ])("finds %s at %s", (query, expectedPath) => {
    const result = getRouteInfoFromCatalog({
      catalog,
      input: { query, limit: 5 },
      contexts: [],
    });

    expect(result.matches[0]?.path).toBe(expectedPath);
    expect(result.matches[0]?.link).toBe(expectedPath);
  });
});
