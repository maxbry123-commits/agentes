#!/bin/bash

set -euo pipefail

uncomment.sh "$1" --comment -h \
  --uncomment-func-decl TLS_method \
  --uncomment-func-decl OPENSSL_init_ssl \
  --uncomment-func-decl DTLS_method \
  --uncomment-func-decl SSL_write \
  --uncomment-func-decl SSL_version \
  --uncomment-func-decl SSL_shutdown \
  --uncomment-func-decl SSL_set1_curves_list \
  --uncomment-func-decl SSL_set0_wbio \
  --uncomment-func-decl SSL_set0_rbio \
  --uncomment-func-decl SSL_set_verify \
  --uncomment-func-decl SSL_set_tlsext_host_name \
  --uncomment-func-decl SSL_set_session \
  --uncomment-func-decl SSL_set_quiet_shutdown \
  --uncomment-func-decl SSL_get_quiet_shutdown \
  --uncomment-func-decl SSL_set_fd \
  --uncomment-func-decl SSL_set_ex_data \
  --uncomment-func-decl SSL_set_connect_state \
  --uncomment-func-decl SSL_set_cipher_list \
  --uncomment-func-decl SSL_set_cert_cb \
  --uncomment-func-decl SSL_get0_peer_verify_algorithms \
  --uncomment-func-decl SSL_set_bio \
  --uncomment-macro SSL_set_app_data \
  --uncomment-func-decl SSL_set_alpn_protos \
  --uncomment-func-decl SSL_set_accept_state \
  --uncomment-func-decl SSL_session_reused \
  --uncomment-func-decl SSL_SESSION_is_resumable \
  --uncomment-func-decl SSL_SESSION_get_ticket_lifetime_hint \
  --uncomment-func-decl SSL_SESSION_get_id \
  --uncomment-func-decl SSL_SESSION_free \
  --uncomment-func-decl SSL_SESSION_up_ref \
  --uncomment-func-decl SSL_select_next_proto \
  --uncomment-func-decl SSL_read \
  --uncomment-func-decl SSL_new \
  --uncomment-func-decl SSL_get1_session \
  --uncomment-func-decl SSL_get0_alpn_selected \
  --uncomment-func-decl SSL_get_version \
  --uncomment-func-decl SSL_get_SSL_CTX \
  --uncomment-func-decl SSL_get_session \
  --uncomment-func-decl SSL_get_servername \
  --uncomment-func-decl SSL_get_peer_certificate \
  --uncomment-func-decl SSL_get_ex_new_index \
  --uncomment-func-decl SSL_get_ex_data \
  --uncomment-func-decl SSL_alert_from_verify_result \
  --uncomment-func-decl SSL_get_ex_data_X509_STORE_CTX_idx \
  --uncomment-func-decl SSL_get_error \
  --uncomment-func-decl SSL_get_current_cipher \
  --uncomment-func-decl SSL_get_client_CA_list \
  --uncomment-macro SSL_get_cipher_name \
  --uncomment-func-decl SSL_get_certificate \
  --uncomment-macro SSL_get_app_data \
  --uncomment-func-decl SSL_do_handshake \
  --uncomment-func-decl SSL_CTX_check_private_key \
  --uncomment-func-decl SSL_CTX_set_tmp_ecdh \
  --uncomment-func-decl SSL_get0_next_proto_negotiated \
  --uncomment-func-decl SSL_CTX_use_PrivateKey \
  --uncomment-func-decl SSL_CTX_use_PrivateKey_file \
  --uncomment-func-decl SSL_CTX_use_certificate \
  --uncomment-func-decl SSL_CTX_use_certificate_file \
  --uncomment-func-decl SSL_CTX_set1_curves_list \
  --uncomment-func-decl SSL_CTX_set1_groups_list \
  --uncomment-func-decl SSL_CTX_set_verify \
  --uncomment-func-decl SSL_CTX_set_verify_depth \
  --uncomment-func-decl SSL_CTX_set_tlsext_ticket_key_cb \
  --uncomment-func-decl SSL_CTX_set_tlsext_servername_callback \
  --uncomment-func-decl SSL_CTX_set_timeout \
  --uncomment-func-decl SSL_CTX_set_session_id_context \
  --uncomment-func-decl SSL_CTX_set_session_cache_mode \
  --uncomment-func-decl SSL_CTX_set_options \
  --uncomment-func-decl SSL_CTX_set_min_proto_version \
  --uncomment-func-decl SSL_CTX_set_max_proto_version \
  --uncomment-func-decl SSL_CTX_set_client_CA_list \
  --uncomment-func-decl SSL_CTX_set_cert_cb \
  --uncomment-func-decl SSL_CTX_set_cert_verify_callback \
  --uncomment-macro SSL_CTX_set_app_data \
  --uncomment-func-decl SSL_CTX_set_alpn_select_cb \
  --uncomment-func-decl SSL_CTX_set_alpn_protos \
  --uncomment-typedef SSL_new_session_cb \
  --uncomment-func-decl SSL_CTX_sess_set_new_cb \
  --uncomment-func-decl SSL_CTX_new \
  --uncomment-func-decl SSL_CTX_up_ref \
  --uncomment-func-decl SSL_CTX_get0_param \
  --uncomment-func-decl SSL_CTX_get_verify_mode \
  --uncomment-func-decl SSL_CTX_get_options \
  --uncomment-func-decl SSL_CTX_get_client_CA_list \
  --uncomment-func-decl SSL_CTX_get_ciphers \
  --uncomment-func-decl SSL_CTX_get_cert_store \
  --uncomment-func-decl SSL_CTX_set_cert_store \
  --uncomment-func-decl SSL_CTX_get_ex_new_index \
  --uncomment-macro SSL_CTX_get_app_data \
  --uncomment-func-decl SSL_CTX_free \
  --uncomment-func-decl SSL_CTX_add_extra_chain_cert \
  --uncomment-func-decl SSL_CIPHER_get_name \
  --uncomment-func-decl SSL_CIPHER_get_id \
  --uncomment-func-decl SSL_CIPHER_get_auth_nid \
  --uncomment-func-decl SSL_CTX_set_select_certificate_cb \
  --uncomment-func-decl SSL_CTX_set_keylog_callback \
  --uncomment-func-decl SSL_CIPHER_get_min_version \
  --uncomment-func-decl SSL_get_negotiated_group \
  --uncomment-func-decl SSL_get_peer_full_cert_chain \
  --uncomment-func-decl SSL_set_ocsp_response \
  --uncomment-func-decl SSL_set_enforce_rsa_key_usage \
  --uncomment-func-decl SSL_set_renegotiate_mode \
  --uncomment-func-decl SSL_CTX_get0_certificate \
  --uncomment-func-decl SSL_enable_ocsp_stapling \
  --uncomment-func-decl SSL_error_description \
  --uncomment-func-decl SSL_SESSION_should_be_single_use \
  --uncomment-func-decl SSL_set_SSL_CTX \
  --uncomment-func-decl SSL_set_info_callback \
  --uncomment-func-decl SSL_state_string_long \
  --uncomment-func-decl SSL_state_string \
  --uncomment-func-decl TLS_with_buffers_method \
  --uncomment-func-decl SSL_get_signature_algorithm_digest \
  --uncomment-func-decl SSL_get_signature_algorithm_key_type \
  --uncomment-func-decl SSL_is_signature_algorithm_rsa_pss \
  --uncomment-func-decl SSL_CTX_set_next_proto_select_cb \
  --uncomment-func-decl SSL_CTX_set_strict_cipher_list \
  --uncomment-func-decl SSL_CTX_set_verify_algorithm_prefs \
  --uncomment-func-decl SSL_CTX_set_next_protos_advertised_cb \
  --uncomment-func-decl SSL_early_callback_ctx_extension_get \
  --uncomment-func-decl SSL_get_cipher_by_value \
  --uncomment-func-decl SSL_get_curve_id \
  --uncomment-func-decl SSL_get_group_id \
  --uncomment-func-decl SSL_get_group_name \
  --uncomment-func-decl SSL_get_curve_name \
  --uncomment-func-decl SSL_get_peer_signature_algorithm \
  --uncomment-func-decl SSL_get_signature_algorithm_name \
  --uncomment-func-decl SSL_get0_ocsp_response \
  --uncomment-func-decl SSL_set_chain_and_key \
  --uncomment-func-decl SSL_SESSION_from_bytes \
  --uncomment-func-decl SSL_is_server \
  --uncomment-func-decl SSL_is_init_finished \
  --uncomment-func-decl SSL_get_wbio \
  --uncomment-func-decl SSL_get_rbio \
  --uncomment-func-decl SSL_connect \
  --uncomment-func-decl SSL_accept \
  --uncomment-func-decl SSL_free \
  --uncomment-macro-redef 'SSL_ERROR_[[:alnum:]_]*' \
  --uncomment-macro-redef '\(DTLS1\|DTLS1_2\|SSL3\|TLS1\|TLS1_1\|TLS1_2\|TLS1_3\)_VERSION' \
  --uncomment-macro-redef '\(DTLS1\|SSL3\)_VERSION_MAJOR' \
  --uncomment-func-decl SSL_CTX_get_min_proto_version \
  --uncomment-func-decl SSL_CTX_get_max_proto_version \
  --uncomment-macro-redef 'SSL_OP_[[:alnum:]_]*' \
  --uncomment-macro-redef 'SSL_MODE_[[:alnum:]_]*' \
  --uncomment-macro 'SSL_SIGN_[[:alnum:]_]*' \
  --uncomment-macro-redef 'SSL_FILETYPE_[[:alnum:]_]*' \
  --uncomment-func-decl SSL_CTX_use_certificate_chain_file \
  --uncomment-enum ssl_private_key_result_t \
  --uncomment-struct ssl_private_key_method_st \
  --uncomment-regex 'DEFINE_CONST_STACK_OF(SSL_CIPHER)' \
  --uncomment-macro SSL_CIPHER_CHACHA20_POLY1305_SHA256 \
  --uncomment-macro SSL_CIPHER_RSA_WITH_AES_128_CBC_SHA \
  --uncomment-macro SSL_CIPHER_PSK_WITH_AES_256_CBC_SHA \
  --uncomment-macro SSL_CIPHER_ECDHE_RSA_WITH_AES_128_CBC_SHA \
  --uncomment-macro SSL_CIPHER_ECDHE_RSA_WITH_AES_256_CBC_SHA \
  --uncomment-macro SSL_CIPHER_ECDHE_RSA_WITH_AES_128_GCM_SHA256 \
  --uncomment-macro SSL_CIPHER_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256 \
  --uncomment-macro SSL_CIPHER_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384 \
  --uncomment-macro SSL_CIPHER_ECDHE_PSK_WITH_AES_128_CBC_SHA \
  --uncomment-macro SSL_CIPHER_ECDHE_RSA_WITH_CHACHA20_POLY1305_SHA256 \
  --uncomment-macro SSL_CIPHER_AES_256_GCM_SHA384 \
  --uncomment-macro SSL_CIPHER_AES_128_GCM_SHA256 \
  --uncomment-func-decl SSL_CIPHER_get_cipher_nid \
  --uncomment-func-decl SSL_CIPHER_get_digest_nid \
  --uncomment-func-decl SSL_CIPHER_get_kx_nid \
  --uncomment-func-decl SSL_CIPHER_get_prf_nid \
  --uncomment-func-decl SSL_CIPHER_standard_name \
  --uncomment-func-decl SSL_CTX_set_cipher_list \
  --uncomment-func-decl SSL_get_ciphers \
  --uncomment-func-decl SSL_get_peer_cert_chain \
  --uncomment-func-decl SSL_SESSION_new \
  --uncomment-func-decl SSL_SESSION_to_bytes \
  --uncomment-func-decl SSL_SESSION_get_version \
  --uncomment-func-decl SSL_SESSION_set_protocol_version \
  --uncomment-macro-redef 'SSL_SESS_[[:alnum:]_]*' \
  --uncomment-func-decl SSL_set_session_id_context \
  --uncomment-func-decl SSL_CTX_set_tlsext_ticket_keys \
  --uncomment-macro 'SSL_CURVE_SECP[0-9]*R1' \
  --uncomment-macro 'SSL_CURVE_X25519' \
  --uncomment-macro-redef 'SSL_VERIFY_[[:alnum:]_]*' \
  --uncomment-func-decl SSL_CTX_load_verify_locations \
  --uncomment-func-decl SSL_set_client_CA_list \
  --uncomment-func-decl SSL_add_file_cert_subjects_to_stack \
  --uncomment-macro TLSEXT_NAMETYPE_host_name \
  --uncomment-func-decl SSL_CTX_set_tlsext_servername_arg \
  --uncomment-macro-redef 'SSL_TLSEXT_ERR_[[:alnum:]_]*' \
  --uncomment-macro-redef 'OPENSSL_NPN_[[:alnum:]_]*' \
  --uncomment-macro-redef 'SSL_AD_[[:alnum:]_]*' \
  --uncomment-func-decl SSL_CTX_set_ex_data \
  --uncomment-func-decl SSL_CTX_get_ex_data \
  --uncomment-enum ssl_renegotiate_mode_t \
  --uncomment-struct ssl_early_callback_ctx \
  --uncomment-enum ssl_select_cert_result_t \
  --uncomment-func-decl TLS_server_method \
  --uncomment-func-decl TLS_client_method \
  --uncomment-func-decl i2d_SSL_SESSION \
  --uncomment-func-decl d2i_SSL_SESSION \
  --uncomment-func-decl SSL_CTX_set1_sigalgs_list \
  --uncomment-func-decl SSL_CTX_set_tlsext_status_cb \
  --uncomment-macro-redef 'SSL_R_[[:alnum:]_]*' \
  --uncomment-regex 'BORINGSSL_MAKE_DELETER(SSL,' \
  --uncomment-regex 'BORINGSSL_MAKE_DELETER(SSL_CTX,' \
  --uncomment-regex 'BORINGSSL_MAKE_DELETER(SSL_SESSION,' \
  --uncomment-macro-redef SSL_CB_LOOP \
  --uncomment-macro-redef SSL_CB_HANDSHAKE_START \
  --uncomment-macro-redef SSL_CB_HANDSHAKE_DONE \
  --uncomment-macro-redef SSL_MAX_SSL_SESSION_ID_LENGTH \
  --uncomment-macro SSL_TICKET_KEY_NAME_LEN \
  --uncomment-enum ssl_verify_result_t \
  --uncomment-func-decl SSL_CTX_set_reverify_on_resume \
  --uncomment-func-decl SSL_CTX_set_custom_verify \
  --uncomment-func-decl SSL_CTX_set_private_key_method \
  --uncomment-func-decl SSL_send_fatal_alert \
  --uncomment-func-decl SSL_alert_desc_string_long \
  --uncomment-func-decl SSL_CTX_get_session_cache_mode \
  --uncomment-func-decl SSL_get0_peer_certificates \
  --uncomment-func-decl SSL_get_all_cipher_names \
  --uncomment-func-decl SSL_get_all_signature_algorithm_names \
  --uncomment-func-decl SSL_get_all_version_names \
  --uncomment-func-decl SSL_get_all_curve_names \
  --uncomment-func-decl SSL_get_all_group_names \
  --uncomment-func-decl SSL_CTX_set1_group_ids \
  --uncomment-macro SSL_GROUP_SECP256R1 \
  --uncomment-macro SSL_GROUP_SECP384R1 \
  --uncomment-macro SSL_GROUP_SECP521R1 \
  --uncomment-macro SSL_GROUP_X25519 \
  --uncomment-macro SSL_GROUP_X25519_MLKEM768 \
  --uncomment-macro SSL_GROUP_X25519_KYBER768_DRAFT00 \
  --uncomment-func-decl SSL_CIPHER_get_handshake_digest \
  --uncomment-enum ssl_compliance_policy_t \
  --uncomment-func-decl SSL_CTX_set_compliance_policy \
  --uncomment-func-decl SSL_was_key_usage_invalid \
  --uncomment-func-decl SSL_get_verify_result \
  --uncomment-func-decl SSL_CIPHER_get_version \
  --uncomment-func-decl SSL_set0_CA_names \
  --uncomment-func-decl SSL_clear \
  --uncomment-macro DTLS1_3_VERSION

# Append BoringSSL-only SSL_ERROR constants that have no OpenSSL equivalent.
# These are needed so that Envoy code can reference them unconditionally.
# The compat layer's SSL_get_error() translates the corresponding OpenSSL
# error codes to these values.
cat >> "$1" <<'EOF'

#ifndef SSL_ERROR_PENDING_CERTIFICATE
#define SSL_ERROR_PENDING_CERTIFICATE 12
#endif
#ifndef SSL_ERROR_WANT_PRIVATE_KEY_OPERATION
#define SSL_ERROR_WANT_PRIVATE_KEY_OPERATION 13
#endif
#ifndef SSL_ERROR_WANT_CERTIFICATE_VERIFY
#define SSL_ERROR_WANT_CERTIFICATE_VERIFY 16
#endif

// BoringSSL-only SSL_R_* reason codes (no OpenSSL equivalent).
// Values use a 10000+ range to avoid collisions with OpenSSL's SSL_R_*
// numbering (which densely covers 100-422 and 1010-1120).
#ifndef SSL_R_CIPHER_OR_HASH_UNAVAILABLE
#define SSL_R_CIPHER_OR_HASH_UNAVAILABLE 10001
#endif
#ifndef SSL_R_DECODE_ERROR
#define SSL_R_DECODE_ERROR 10002
#endif
#ifndef SSL_R_NEGOTIATED_BOTH_NPN_AND_ALPN
#define SSL_R_NEGOTIATED_BOTH_NPN_AND_ALPN 10003
#endif
#ifndef SSL_R_NO_CIPHERS_PASSED
#define SSL_R_NO_CIPHERS_PASSED 10004
#endif
#ifndef SSL_R_UNSUPPORTED_CIPHER
#define SSL_R_UNSUPPORTED_CIPHER 10005
#endif
#ifndef SSL_R_UNSUPPORTED_PROTOCOL_FOR_CUSTOM_KEY
#define SSL_R_UNSUPPORTED_PROTOCOL_FOR_CUSTOM_KEY 10006
#endif
#ifndef SSL_R_EXCESS_HANDSHAKE_DATA
#define SSL_R_EXCESS_HANDSHAKE_DATA 10007
#endif
#ifndef SSL_R_INVALID_ALPN_PROTOCOL
#define SSL_R_INVALID_ALPN_PROTOCOL 10008
#endif
#ifndef SSL_R_ALPN_MISMATCH_ON_EARLY_DATA
#define SSL_R_ALPN_MISMATCH_ON_EARLY_DATA 10009
#endif
#ifndef SSL_R_WRONG_VERSION_ON_EARLY_DATA
#define SSL_R_WRONG_VERSION_ON_EARLY_DATA 10010
#endif
#ifndef SSL_R_NO_SUPPORTED_VERSIONS_ENABLED
#define SSL_R_NO_SUPPORTED_VERSIONS_ENABLED 10011
#endif
#ifndef SSL_R_SECOND_SERVERHELLO_VERSION_MISMATCH
#define SSL_R_SECOND_SERVERHELLO_VERSION_MISMATCH 10012
#endif
#ifndef SSL_R_CIPHER_MISMATCH_ON_EARLY_DATA
#define SSL_R_CIPHER_MISMATCH_ON_EARLY_DATA 10013
#endif
#ifndef SSL_R_INVALID_ALPN_PROTOCOL_LIST
#define SSL_R_INVALID_ALPN_PROTOCOL_LIST 10014
#endif
#ifndef SSL_R_TLSV1_ALERT_CERTIFICATE_REQUIRED
#define SSL_R_TLSV1_ALERT_CERTIFICATE_REQUIRED 10015
#endif
EOF
