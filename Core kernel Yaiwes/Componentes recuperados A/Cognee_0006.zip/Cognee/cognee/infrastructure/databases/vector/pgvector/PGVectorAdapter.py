import asyncio
from typing import Any, Dict, List, Optional, get_type_hints
from uuid import UUID
from sqlalchemy.inspection import inspect
from sqlalchemy.orm import Mapped, mapped_column
from sqlalchemy.dialects.postgresql import insert
from sqlalchemy import JSON, Column, Table, select, delete, MetaData, func, text
from sqlalchemy import exc
from sqlalchemy.exc import DBAPIError, ProgrammingError
from tenacity import retry, retry_if_exception_type, stop_after_attempt, wait_exponential
from asyncpg import DeadlockDetectedError, DuplicateTableError, UniqueViolationError
from sqlalchemy.engine import make_url

from cognee.shared.logging_utils import get_logger
from cognee.infrastructure.engine import DataPoint
from cognee.infrastructure.engine.utils import parse_id
from cognee.infrastructure.databases.relational import get_relational_engine, get_relational_config
from cognee.infrastructure.databases.vector.config import get_vectordb_config

from cognee.infrastructure.databases.exceptions import MissingQueryParameterError
from cognee.context_global_variables import backend_access_control_enabled
from cognee.modules.graph.methods.sanitize_relational_payload import sanitize_relational_payload

from ...relational.ModelBase import Base
from ...relational.sqlalchemy.SqlAlchemyAdapter import SQLAlchemyAdapter
from ..models.ScoredResult import ScoredResult
from ..exceptions import CollectionNotFoundError
from ..vector_db_interface import VectorDBInterface
from ..embeddings.EmbeddingEngine import EmbeddingEngine
from .serialize_data import serialize_data

logger = get_logger("PGVectorAdapter")
QUERY_BATCH_SIZE = 1000

# Default pool sizing for per-dataset PGVector engines when ENABLE_BACKEND_ACCESS_CONTROL=True.
# Lean pool_size limits connection fan-out across datasets (only pool_size connections are
# retained while idle); the large max_overflow keeps burst headroom, since overflow
# connections close on release instead of idling.
_ACCESS_CONTROL_DEFAULT_POOL_ARGS = {"pool_size": 2, "max_overflow": 20}


class IndexSchema(DataPoint):
    """
    Define a schema for indexing data points with a text field.

    This class inherits from the DataPoint class and specifies the structure of a single
    data point that includes a text attribute. It also includes a metadata field that
    indicates which fields should be indexed.
    """

    text: str

    # Optional reference scalars carried for the search "Evidence" feature.
    # They stay None for non-chunk data points, so this schema remains
    # compatible with every indexed DataPoint type.
    document_id: Optional[str] = None
    document_name: Optional[str] = None
    chunk_index: Optional[int] = None
    source_chunk_id: Optional[str] = None
    importance_weight: Optional[float] = 0.5

    metadata: dict = {"index_fields": ["text"]}
    belongs_to_set: List[str] = []


class PGVectorAdapter(SQLAlchemyAdapter, VectorDBInterface):
    """Vector-database adapter backed by Postgres + pgvector; implements VectorDBInterface."""

    name = "PGVector"

    def __init__(
        self,
        connection_string: str,
        api_key: Optional[str],
        embedding_engine: EmbeddingEngine,
        schema: str = "",
    ):
        """Initialize the adapter and, when possible, reuse the relational engine.

        When ``schema`` is set (shared-database isolation mode), this adapter is
        pinned to a single Postgres schema via the connection ``search_path``:
        every collection table is created and queried inside that schema, so
        many datasets coexist in one database with no table-name collisions and
        no per-dataset database. In that mode the adapter always owns a
        dedicated engine (it must never mutate the search_path of the shared
        relational engine, which has to stay on ``public``).
        """
        self.api_key = api_key
        self.embedding_engine = embedding_engine
        self.db_uri: str = connection_string
        # Postgres schema this adapter is pinned to ("" = default/public search path).
        # Read by schema-scoped overrides of get_table_names()/delete_database().
        self.schema: str = schema or ""
        self.VECTOR_DB_LOCK = asyncio.Lock()
        self._write_locks: dict[str, asyncio.Lock] = {}
        self._metadata = MetaData()
        # True when this adapter created its own engine and must dispose it on close().
        # False when the engine is borrowed from the relational adapter.
        self._owns_engine: bool = False

        relational_db = get_relational_engine()
        relational_config = get_relational_config()
        vector_config = get_vectordb_config()

        # Resolve effective pool_args for any new PGVector engine we create:
        # 1. Explicit VECTOR_POOL_ARGS always wins.
        # 2. Then the relational POOL_ARGS, when configured — an operator who
        #    sized the pool explicitly outranks our built-in default.
        # 3. Otherwise, when access control is on, each dataset gets its own
        #    engine — use a small default to avoid connection fan-out
        #    (N datasets × pool_size).
        if vector_config.vector_pool_args is not None:
            effective_pool_args = dict(vector_config.vector_pool_args)
        elif relational_config.pool_args:
            effective_pool_args = dict(relational_config.pool_args)
        elif backend_access_control_enabled():
            effective_pool_args = _ACCESS_CONTROL_DEFAULT_POOL_ARGS
        else:
            effective_pool_args = {}

        # A per-dataset PGVector engine may connect to managed
        # Postgres (Neon) which requires SSL. Reuse the relational connect_args
        # (e.g. {"ssl": "require"} from DATABASE_CONNECT_ARGS); {} for in-cluster.
        effective_connect_args = (
            dict(relational_config.database_connect_args)
            if relational_config.database_connect_args
            else None
        )

        # Reuse engine and sessionmaker if the relational engine is provided and is the same database as the one configured for pgvector
        db_name1 = make_url(relational_db.db_uri).database
        db_name2 = make_url(self.db_uri).database
        if self.schema:
            # Shared-database schema-isolation mode. Always a dedicated engine
            # whose connections are pinned to this dataset's schema via
            # search_path; ``public`` is kept on the path so the pgvector
            # extension's ``vector`` type and operators (installed in public)
            # resolve. Our collection tables are always created in the dataset
            # schema (first on the path), so reads never fall through to public.
            connect_args = dict(effective_connect_args) if effective_connect_args else {}
            server_settings = dict(connect_args.get("server_settings") or {})
            server_settings["search_path"] = f"{self.schema}, public"
            connect_args["server_settings"] = server_settings
            super().__init__(
                connection_string=self.db_uri,
                connect_args=connect_args,
                pool_args=effective_pool_args,
            )
            self._owns_engine = True
        elif backend_access_control_enabled() and (db_name1 != db_name2):
            # If backend access control create new instances of engine and sessionmaker
            super().__init__(
                connection_string=self.db_uri,
                connect_args=effective_connect_args,
                pool_args=effective_pool_args,
            )
            self._owns_engine = True
        elif relational_db.engine.dialect.name == "postgresql":
            # If postgreSQL is used and not backend access control we must use the same engine and sessionmaker
            self.engine = relational_db.engine
            self.sessionmaker = relational_db.sessionmaker
        else:
            # If not postgreSQL and not backend access control create new instances of engine and sessionmaker
            super().__init__(
                connection_string=self.db_uri,
                connect_args=effective_connect_args,
                pool_args=effective_pool_args,
            )
            self._owns_engine = True

        # Has to be imported at class level
        # Functions reading tables from database need to know what a Vector column type is
        from pgvector.sqlalchemy import Vector

        self.Vector = Vector

    def reset_metadata_cache(self):
        """
        Reset SQLAlchemy metadata reflection cache for this adapter instance.
        """
        self._metadata = MetaData()

    async def get_table_names(self) -> List[str]:
        """List collection tables, scoped to this adapter's schema when pinned.

        In shared-database mode this adapter's engine is pinned to a single
        Postgres schema (``self.schema``); reflecting every schema (the base
        adapter's behavior) would leak other datasets' collections into
        schema-wide operations such as ``remove_belongs_to_set_tags``. Falls
        back to the base (all non-system schemas) when not schema-pinned.
        """
        if not self.schema:
            return await super().get_table_names()

        table_names: List[str] = []
        async with self.engine.begin() as connection:
            metadata = MetaData()
            await connection.run_sync(metadata.reflect, schema=self.schema)
            table_names.extend(metadata.tables.keys())
        return table_names

    async def delete_database(self):
        """Drop this dataset's tables, scoped to its schema when pinned.

        In shared-database mode ``prune`` must only drop the pinned dataset
        schema's tables — never ``public`` (which holds cognee's shared
        relational tables) or other datasets' schemas. Falls back to the base
        public-schema behavior when not schema-pinned.
        """
        if not self.schema:
            return await super().delete_database()

        async with self.engine.begin() as connection:
            metadata = MetaData()
            await connection.run_sync(metadata.reflect, schema=self.schema)
            for table in metadata.sorted_tables:
                await connection.execute(
                    text(f'DROP TABLE IF EXISTS "{self.schema}"."{table.name}" CASCADE')
                )

    async def close(self) -> None:
        """
        Release connection-pool resources held by this adapter.

        Only disposes the engine when this adapter owns it. When the engine is
        borrowed from the relational adapter (shared-engine mode), disposal is
        left to the relational adapter so the pool is not torn down while the
        relational layer is still using it.

        Called automatically by ``closing_lru_cache`` when this adapter is
        evicted from ``_create_vector_engine``'s cache.
        """
        if self._owns_engine:
            await self.engine.dispose(close=True)

    def _get_write_lock(self, collection_name: str) -> asyncio.Lock:
        if collection_name not in self._write_locks:
            self._write_locks[collection_name] = asyncio.Lock()
        return self._write_locks[collection_name]

    async def embed_data(self, data: list[str]) -> list[list[float]]:
        """
        Embed a list of texts into vectors using the specified embedding engine.

        Parameters:
        -----------

            - data (list[str]): A list of strings to be embedded into vectors.

        Returns:
        --------

            - list[list[float]]: A list of lists of floats representing embedded vectors.
        """
        return await self.embedding_engine.embed_text(data)

    async def has_collection(self, collection_name: str) -> bool:
        """
        Check if a specified collection exists in the database.

        Parameters:
        -----------

            - collection_name (str): The name of the collection to check for existence.

        Returns:
        --------

            - bool: Returns True if the collection exists, False otherwise.
        """
        if collection_name in self._metadata.tables:
            return True

        try:
            async with self.engine.begin() as connection:
                await connection.run_sync(self._metadata.reflect, only=[collection_name])
        except exc.InvalidRequestError:
            return False

        return collection_name in self._metadata.tables

    @retry(
        retry=retry_if_exception_type(
            (DuplicateTableError, UniqueViolationError, ProgrammingError)
        ),
        stop=stop_after_attempt(5),
        wait=wait_exponential(multiplier=2, min=1, max=6),
    )
    async def create_collection(self, collection_name: str, payload_schema=None):
        """Create the pgvector table for `collection_name` if it does not already exist."""
        data_point_types = get_type_hints(DataPoint)
        vector_size = self.embedding_engine.get_vector_size()

        if not await self.has_collection(collection_name):
            async with self.VECTOR_DB_LOCK:
                if not await self.has_collection(collection_name):

                    class PGVectorDataPoint(Base):
                        """
                        Represent a point in a vector data space with associated data and vector representation.

                        This class inherits from Base and is associated with a database table defined by
                        __tablename__. It maintains the following public methods and instance variables:

                        - __init__(self, id, payload, vector): Initializes a new PGVectorDataPoint instance.

                        Instance variables:
                        - id: Identifier for the data point, defined by data_point_types.
                        - payload: JSON data associated with the data point.
                        - vector: Vector representation of the data point, with size defined by vector_size.
                        """

                        __tablename__ = collection_name
                        __table_args__ = {"extend_existing": True}
                        # PGVector requires one column to be the primary key
                        id: Mapped[data_point_types["id"]] = mapped_column(primary_key=True)
                        payload = Column(JSON)
                        vector = Column(self.Vector(vector_size))

                        def __init__(self, id, payload, vector):
                            """Initialize the pgvector row with id, JSON payload, and vector."""
                            self.id = id
                            self.payload = payload
                            self.vector = vector

                    async with self.engine.begin() as connection:
                        if len(Base.metadata.tables.keys()) > 0:
                            await connection.run_sync(
                                Base.metadata.create_all, tables=[PGVectorDataPoint.__table__]
                            )
                    # Reflect AFTER the DDL transaction commits so
                    # _metadata is never populated for a table that
                    # might be rolled back.
                    async with self.engine.begin() as connection:
                        await connection.run_sync(self._metadata.reflect, only=[collection_name])

    @retry(
        retry=retry_if_exception_type((DeadlockDetectedError, DBAPIError)),
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=2, min=1, max=6),
    )
    async def create_data_points(self, collection_name: str, data_points: List[DataPoint]):
        """Upsert DataPoints into `collection_name`, merging belongs_to_set on conflict."""
        data_point_types = get_type_hints(DataPoint)
        if not await self.has_collection(collection_name):
            await self.create_collection(
                collection_name=collection_name,
                payload_schema=type(data_points[0]),
            )

        data_vectors = await self.embed_data(
            [DataPoint.get_embeddable_data(data_point) for data_point in data_points]
        )

        vector_size = self.embedding_engine.get_vector_size()

        class PGVectorDataPoint(Base):
            """
            Represents a data point in a PGVector database. This class maps to a table defined by
            the SQLAlchemy ORM.

            It contains the following public instance variables:
            - id: An identifier for the data point.
            - payload: A JSON object containing additional data related to the data point.
            - vector: A vector representation of the data point, configured to the specified size.
            """

            __tablename__ = collection_name
            __table_args__ = {"extend_existing": True}
            # PGVector requires one column to be the primary key
            id: Mapped[data_point_types["id"]] = mapped_column(primary_key=True)
            payload = Column(JSON)
            vector = Column(self.Vector(vector_size))

            def __init__(self, id, payload, vector):
                self.id = id
                self.payload = payload
                self.vector = vector

        pgvector_data_points = []

        for data_index, data_point in enumerate(data_points):
            pgvector_data_points.append(
                PGVectorDataPoint(
                    id=data_point.id,
                    vector=data_vectors[data_index],
                    # Strip NUL bytes: the json column accepts \u0000 on insert, but
                    # the payload::jsonb casts in search/merge queries reject it.
                    payload=sanitize_relational_payload(serialize_data(data_point.model_dump())),
                )
            )

        def to_dict(obj):
            """Dump a mapped PGVectorDataPoint row to a plain column→value dict."""
            return {
                column.key: getattr(obj, column.key) for column in inspect(obj).mapper.column_attrs
            }

        # Dedup by id within the batch — with ON CONFLICT DO UPDATE,
        # Postgres raises "cannot affect row a second time" if the same
        # id appears twice in one INSERT. The prior ON CONFLICT DO NOTHING
        # path silently tolerated duplicates, so entity extraction may
        # still emit same-UUID5 rows in one batch. Union the duplicates'
        # belongs_to_set arrays before collapsing so a tag that only
        # appears on one duplicate isn't dropped (mirrors the in-batch
        # tag merge in Neo4jAdapter.add_nodes).
        deduped_by_id: dict = {}
        for dp in pgvector_data_points:
            existing = deduped_by_id.get(dp.id)
            if existing is None:
                deduped_by_id[dp.id] = dp
                continue
            existing_payload = existing.payload or {}
            incoming_payload = dp.payload or {}
            existing_tags = existing_payload.get("belongs_to_set") or []
            incoming_tags = incoming_payload.get("belongs_to_set") or []
            if existing_tags or incoming_tags:
                merged_tags = list(dict.fromkeys(list(existing_tags) + list(incoming_tags)))
                dp.payload = {**incoming_payload, "belongs_to_set": merged_tags}
            deduped_by_id[dp.id] = dp
        pgvector_data_points = list(deduped_by_id.values())

        point_dicts = [to_dict(data_point) for data_point in pgvector_data_points]

        async with self._get_write_lock(collection_name):
            async with self.get_async_session() as session:
                for start_index in range(0, len(point_dicts), QUERY_BATCH_SIZE):
                    point_batch = point_dicts[start_index : start_index + QUERY_BATCH_SIZE]
                    insert_statement = insert(PGVectorDataPoint).values(point_batch)
                    quoted_table = f'"{collection_name}"'
                    merged_payload_expr = text(
                        f"""
                                    jsonb_set(
                                        EXCLUDED.payload::jsonb,
                                        '{{belongs_to_set}}',
                                        (
                                            SELECT COALESCE(jsonb_agg(DISTINCT val), '[]'::jsonb)
                                            FROM jsonb_array_elements_text(
                                                COALESCE({quoted_table}.payload::jsonb->'belongs_to_set', '[]'::jsonb)
                                                || COALESCE(EXCLUDED.payload::jsonb->'belongs_to_set', '[]'::jsonb)
                                            ) AS val
                                        )
                                    )::json
                                    """
                    )
                    insert_statement = insert_statement.on_conflict_do_update(
                        index_elements=["id"],
                        set_={"payload": merged_payload_expr},
                    )
                    await session.execute(insert_statement)
                await session.commit()

    async def create_vector_index(self, index_name: str, index_property_name: str):
        """Create the underlying index collection (table) for the given name/property pair."""
        await self.create_collection(f"{index_name}_{index_property_name}")

    async def index_data_points(
        self, index_name: str, index_property_name: str, data_points: list[DataPoint]
    ):
        """Write index rows derived from `data_points` into the `{index}_{property}` table."""
        await self.create_data_points(
            f"{index_name}_{index_property_name}",
            [
                IndexSchema(
                    id=data_point.id,
                    text=DataPoint.get_embeddable_data(data_point),
                    # Reference scalars for search "Evidence". Pulled via getattr
                    # so non-chunk data points (which lack these fields) simply
                    # fall back to None instead of raising.
                    document_id=getattr(data_point, "document_id", None),
                    document_name=getattr(data_point, "document_name", None),
                    chunk_index=getattr(data_point, "chunk_index", None),
                    source_chunk_id=getattr(data_point, "source_chunk_id", None),
                    importance_weight=getattr(data_point, "importance_weight", None),
                    belongs_to_set=(data_point.belongs_to_set or []),
                )
                for data_point in data_points
            ],
        )

    async def get_table(self, collection_name: str) -> Table:
        """
        Dynamically loads a table using the given collection name
        with an async engine.
        """
        if collection_name in self._metadata.tables:
            return self._metadata.tables[collection_name]

        try:
            async with self.engine.begin() as connection:
                await connection.run_sync(self._metadata.reflect, only=[collection_name])
        except exc.InvalidRequestError:
            raise CollectionNotFoundError(
                f"Collection '{collection_name}' not found!",
            )

        if collection_name in self._metadata.tables:
            return self._metadata.tables[collection_name]

        raise CollectionNotFoundError(
            f"Collection '{collection_name}' not found!",
        )

    async def retrieve(self, collection_name: str, data_point_ids: List[str]):
        """Return rows from `collection_name` matching any of `data_point_ids`."""
        # Get PGVectorDataPoint Table from database
        try:
            PGVectorDataPoint = await self.get_table(collection_name)
        except CollectionNotFoundError:
            # If collection doesn't exist, return empty list (no items to retrieve)
            return []

        async with self.get_async_session() as session:
            results = []
            for start_index in range(0, len(data_point_ids), QUERY_BATCH_SIZE):
                id_batch = data_point_ids[start_index : start_index + QUERY_BATCH_SIZE]
                batch_results = await session.execute(
                    select(PGVectorDataPoint).where(PGVectorDataPoint.c.id.in_(id_batch))
                )
                results.extend(batch_results.all())

            seen_ids = set()
            unique_results = []
            for result in results:
                if result.id in seen_ids:
                    continue
                seen_ids.add(result.id)
                unique_results.append(result)

            return [
                ScoredResult(id=parse_id(result.id), payload=result.payload, score=0)
                for result in unique_results
            ]

    async def search(
        self,
        collection_name: str,
        query_text: Optional[str] = None,
        query_vector: Optional[List[float]] = None,
        limit: Optional[int] = 15,
        with_vector: bool = False,
        include_payload: bool = False,
        node_name: Optional[List[str]] = None,
        node_name_filter_operator: str = "OR",
    ) -> List[ScoredResult]:
        """Run a cosine-distance similarity search, optionally filtered by NodeSet tag."""
        if query_text is None and query_vector is None:
            raise MissingQueryParameterError()

        if query_text and not query_vector:
            query_vector = (await self.embedding_engine.embed_text([query_text]))[0]

        # Get PGVectorDataPoint Table from database
        PGVectorDataPoint = await self.get_table(collection_name)

        if limit is None:
            async with self.get_async_session() as session:
                query = select(func.count()).select_from(PGVectorDataPoint)
                result = await session.execute(query)
                limit = result.scalar_one()

        # If limit is still 0, no need to do the search, just return empty results
        if limit <= 0:
            return []

        # NOTE: This needs to be initialized in case search doesn't return a value
        closest_items = []

        # Note: Exclude payload from returned columns if not needed to optimize performance
        select_columns = (
            [PGVectorDataPoint]
            if include_payload
            else [PGVectorDataPoint.c.id, PGVectorDataPoint.c.vector]
        )
        # Use async session to connect to the database
        async with self.get_async_session() as session:
            if node_name:
                if node_name_filter_operator == "AND":
                    filter_operator = "?&"
                else:
                    filter_operator = "?|"

                from sqlalchemy import cast, bindparam
                from sqlalchemy.dialects.postgresql import JSONB, ARRAY, TEXT

                target = bindparam("target", value=node_name, type_=ARRAY(TEXT()))
                query = (
                    select(
                        *select_columns,
                        PGVectorDataPoint.c.vector.cosine_distance(query_vector).label(
                            "similarity"
                        ),
                    )
                    .where(
                        cast(PGVectorDataPoint.c.payload, JSONB)
                        .op("->")("belongs_to_set")
                        .op(filter_operator)(target)
                    )
                    .order_by("similarity")
                )
            else:
                query = select(
                    *select_columns,
                    PGVectorDataPoint.c.vector.cosine_distance(query_vector).label("similarity"),
                ).order_by("similarity")

            if limit > 0:
                query = query.limit(limit)

            # Find closest vectors to query_vector
            closest_items = await session.execute(query)

        vector_list = []

        # Extract distances and find min/max for normalization
        for vector in closest_items.all():
            vector_list.append(
                {
                    "id": parse_id(str(vector.id)),
                    "payload": vector.payload if include_payload else None,
                    "_distance": vector.similarity,
                }
            )

        if len(vector_list) == 0:
            return []

        # Return backend raw cosine distance as score (lower is better)
        for i in range(0, len(vector_list)):
            vector_list[i]["score"] = float(vector_list[i]["_distance"])

        # Create and return ScoredResult objects
        return [
            ScoredResult(
                id=row.get("id"),
                payload=row.get("payload") if include_payload else None,
                score=row.get("score"),
            )
            for row in vector_list
        ]

    async def batch_search(
        self,
        collection_name: str,
        query_texts: List[str],
        limit: int = None,
        with_vectors: bool = False,
        include_payload: bool = False,
        node_name: Optional[List[str]] = None,
    ):
        """Run `search` concurrently for each query text and return a list of result lists."""
        query_vectors = await self.embedding_engine.embed_text(query_texts)

        return await asyncio.gather(
            *[
                self.search(
                    collection_name=collection_name,
                    query_vector=query_vector,
                    limit=limit,
                    with_vector=with_vectors,
                    include_payload=include_payload,
                    node_name=node_name,
                )
                for query_vector in query_vectors
            ]
        )

    async def delete_data_points(self, collection_name: str, data_point_ids: list[UUID]):
        """Delete rows from `collection_name` whose id is in `data_point_ids`."""
        # Skip deletion if collection doesn't exist
        if not await self.has_collection(collection_name):
            return None

        async with self._get_write_lock(collection_name):
            # Resolve the table BEFORE opening the session. get_table() checks out
            # its own connection; doing it inside the session would hold two pooled
            # connections at once and deadlock the pool under concurrency (same
            # class as #4197). Mirrors retrieve()/search().
            PGVectorDataPoint = await self.get_table(collection_name)
            async with self.get_async_session() as session:
                results = None
                if not data_point_ids:
                    results = await session.execute(
                        delete(PGVectorDataPoint).where(PGVectorDataPoint.c.id.in_(data_point_ids))
                    )
                else:
                    for start_index in range(0, len(data_point_ids), QUERY_BATCH_SIZE):
                        id_batch = data_point_ids[start_index : start_index + QUERY_BATCH_SIZE]
                        results = await session.execute(
                            delete(PGVectorDataPoint).where(PGVectorDataPoint.c.id.in_(id_batch))
                        )
                await session.commit()
                return results

    async def remove_belongs_to_set_tags(
        self,
        tags: List[str],
        node_ids: Optional[List[str]] = None,
    ) -> None:
        """
        Strip the given tag names from `belongs_to_set` arrays in every
        vector collection and delete rows whose array is now empty. Used to
        reconcile surviving shared rows when a dataset/NodeSet is deleted.

        When `node_ids` is provided, the detag only applies to rows whose
        id is in the list — used to reconcile shared rows that lose a
        dataset's anchor while that dataset still exists for other rows.

        Cognee vector collections follow the `{PascalCaseType}_{field}`
        naming convention (e.g. `Entity_name`, `DocumentChunk_text`) and
        coexist in the same schema as lowercase relational tables — filter
        to collections by requiring an uppercase first character.
        """
        if not tags:
            return None

        if node_ids is not None and not node_ids:
            return None

        # `get_table_names()` returns the raw SQLAlchemy reflection keys; for
        # Postgres those may be schema-qualified (`schema.table`) when the
        # reflected schema isn't the search-path default, while SQLite and
        # same-schema Postgres return plain table names. Strip any leading
        # `schema.` prefix first, then keep only PascalCase names — cognee's
        # vector collections are `Entity_name` / `DocumentChunk_text` etc.,
        # whereas relational tables (`users`, `nodes`, …) are snake_case.
        def _table_only(name: str) -> str:
            """Strip any leading `schema.` prefix from a reflected table name."""
            return name.rpartition(".")[2] if "." in name else name

        candidate_tables: list[str] = []
        for name in await self.get_table_names():
            if not name:
                continue
            table_only = _table_only(name)
            if table_only and table_only[0].isupper():
                candidate_tables.append(table_only)

        id_scope_clause = "AND id = ANY(:node_ids)" if node_ids is not None else ""
        bind_params: Dict[str, Any] = {"tags": list(tags)}
        if node_ids is not None:
            bind_params["node_ids"] = [str(nid) for nid in node_ids]

        for table_name in candidate_tables:
            quoted_table = f'"{table_name}"'
            # Can't use a data-modifying CTE (UPDATE … RETURNING then DELETE
            # against the CTE): Postgres runs both statements under the
            # same snapshot, so the outer DELETE doesn't observe the
            # updated row versions and silently no-ops. Instead, capture
            # the id set up front, run the UPDATE scoped to those ids,
            # then DELETE only the ones that ended up empty. The captured
            # set ensures the DELETE can't drop rows that were already
            # empty before the call.
            select_targets_sql = text(
                f"""
                SELECT id FROM {quoted_table}
                WHERE payload::jsonb ? 'belongs_to_set'
                  {id_scope_clause}
                  AND EXISTS (
                      SELECT 1
                      FROM jsonb_array_elements_text(
                          payload::jsonb->'belongs_to_set'
                      ) v
                      WHERE v = ANY(:tags)
                  )
                """
            )
            update_sql = text(
                f"""
                UPDATE {quoted_table}
                SET payload = jsonb_set(
                    payload::jsonb,
                    '{{belongs_to_set}}',
                    (
                        SELECT COALESCE(jsonb_agg(val), '[]'::jsonb)
                        FROM jsonb_array_elements_text(
                            COALESCE(payload::jsonb->'belongs_to_set', '[]'::jsonb)
                        ) AS val
                        WHERE val <> ALL(:tags)
                    )
                )::json
                WHERE id = ANY(:target_ids)
                """
            )
            delete_empties_sql = text(
                f"""
                DELETE FROM {quoted_table}
                WHERE id = ANY(:target_ids)
                  AND payload::jsonb->'belongs_to_set' = '[]'::jsonb
                """
            )
            # Run each table in its own transaction — a failure on one table
            # (e.g. a PascalCase name that isn't a vector collection and has
            # no `payload::jsonb` column) must not roll back updates already
            # committed for other tables.
            try:
                async with self._get_write_lock(table_name):
                    async with self.get_async_session() as session:
                        target_rows = await session.execute(select_targets_sql, bind_params)
                        target_ids = [row[0] for row in target_rows.all()]
                        if not target_ids:
                            await session.commit()
                            continue

                        scoped_params: Dict[str, Any] = {
                            "tags": list(tags),
                            "target_ids": target_ids,
                        }
                        await session.execute(update_sql, scoped_params)
                        await session.execute(delete_empties_sql, {"target_ids": target_ids})
                        await session.commit()
            except exc.SQLAlchemyError as e:
                logger.debug(
                    "remove_belongs_to_set_tags skipped '%s': %s",
                    table_name,
                    e,
                )

        return None

    async def prune(self):
        """Drop all vector collection tables and reset cached reflection metadata."""
        self._metadata.clear()
        await self.delete_database()

    async def run_migrations(self):
        """Run PGVector adapter migrations (currently no-op)."""
        return None
