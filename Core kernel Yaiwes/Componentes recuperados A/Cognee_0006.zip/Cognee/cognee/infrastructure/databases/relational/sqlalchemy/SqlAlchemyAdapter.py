import os
from urllib.parse import unquote
import gc
import asyncio
from os import path
import tempfile
from uuid import UUID
from typing import Optional
from typing import AsyncGenerator, List
from contextlib import asynccontextmanager
from sqlalchemy.orm import joinedload
from sqlalchemy.exc import NoResultFound
from sqlalchemy import NullPool, event, text, select, MetaData, Table, delete, inspect, func, or_
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine, async_sessionmaker

from cognee.modules.data.models.Data import Data
from cognee.shared.logging_utils import get_logger
from cognee.infrastructure.utils.run_sync import run_sync
from cognee.infrastructure.databases.exceptions import EntityNotFoundError
from cognee.infrastructure.files.storage import get_file_storage, get_storage_config

from ..ModelBase import Base


logger = get_logger()


class SQLAlchemyAdapter:
    """
    Adapt a SQLAlchemy connection for asynchronous operations with database management
    functions.
    """

    def __init__(self, connection_string: str, connect_args: dict = None, pool_args: dict = None):
        """
        Initialize the SQLAlchemy adapter with connection settings.

        Parameters:
        -----------
            connection_string (str): The database connection string (e.g., 'sqlite:///path/to/db'
                or 'postgresql://user:pass@host:port/db').
            connect_args (dict, optional): Database driver connection arguments.
                Configuration is loaded from RelationalConfig.database_connect_args, which reads
                from the DATABASE_CONNECT_ARGS environment variable.

                Examples:
                    PostgreSQL with SSL:
                        DATABASE_CONNECT_ARGS='{"sslmode": "require", "connect_timeout": 10}'

                    SQLite with custom timeout:
                        DATABASE_CONNECT_ARGS='{"timeout": 60}'
            pool_args (dict, optional): SQLAlchemy connection-pool settings, loaded from
                RelationalConfig.pool_args, which reads from the POOL_ARGS environment
                variable.

                For SQLite, the pool-sizing keys (pool_size, max_overflow,
                pool_recycle, pool_timeout, pool_pre_ping) and poolclass are applied:
                sizing keys switch the engine from its NullPool default to a bounded
                pool, and poolclass "nullpool" is normalized to the NullPool class.
                For other databases every key is forwarded, with QueuePool defaults
                filled in when no poolclass is given.

                Example:
                    POOL_ARGS='{"pool_size": 5, "max_overflow": 10}'
        """
        self.db_path: str = None
        self.db_uri: str = connection_string

        # Use provided connect_args (already parsed from config)
        final_connect_args = connect_args or {}

        if "sqlite" in connection_string:
            [prefix, db_path] = connection_string.split("///")
            self.db_path = db_path

            if "s3://" in self.db_path:
                db_dir_path = path.dirname(self.db_path)
                file_storage = get_file_storage(db_dir_path)

                run_sync(file_storage.ensure_directory_exists())

                with tempfile.NamedTemporaryFile(mode="w", delete=False) as temp_file:
                    self.temp_db_file = temp_file.name
                    connection_string = prefix + "///" + self.temp_db_file

                run_sync(self.pull_from_s3())

        if "sqlite" in connection_string:
            # Pool-sizing keys opt into a bounded pool; without them the engine
            # uses NullPool (no connection reuse). ``poolclass: "nullpool"`` is
            # normalized to the class, exactly as on the server-database branch
            # below. Other engine kwargs stay excluded so they cannot collide
            # with the sqlite-specific connect_args assembled here.
            sqlite_pool_args = {
                key: value
                for key, value in (pool_args or {}).items()
                if key
                in (
                    "pool_size",
                    "max_overflow",
                    "pool_recycle",
                    "pool_timeout",
                    "pool_pre_ping",
                    "poolclass",
                )
            }
            if sqlite_pool_args.get("poolclass", "").lower() == "nullpool":
                sqlite_pool_args["poolclass"] = NullPool
            self.engine = create_async_engine(
                connection_string,
                **(sqlite_pool_args or {"poolclass": NullPool}),
                connect_args={**{"timeout": 120}, **final_connect_args},
            )

            # SQLite defaults to rollback-journal mode, where a connection that
            # holds a read lock and then tries to upgrade to a write lock can
            # deadlock against another reader's lock. Because cognify() fans
            # work out to parallel greenlets that each open their own connection
            # (NullPool by default), those read-then-write transactions race and surface as
            # "sqlite3.OperationalError: database is locked" (see issue #2717).
            #
            # Enabling WAL serializes writers on a single write lock while
            # letting readers proceed, so concurrent writers wait (bounded by
            # busy_timeout) instead of deadlocking. These PRAGMAs are connection
            # scoped, so they must be (re)applied on every new connection.
            @event.listens_for(self.engine.sync_engine, "connect")
            def _set_sqlite_pragmas(dbapi_connection, connection_record):
                cursor = dbapi_connection.cursor()
                try:
                    cursor.execute("PRAGMA journal_mode=WAL")
                    cursor.execute("PRAGMA synchronous=NORMAL")
                    cursor.execute("PRAGMA busy_timeout=120000")
                finally:
                    cursor.close()
        else:
            # Transform pool_args from tuple into dict if provided
            # Note: For caching purposes, pool_args is stored as a sorted tuple of key-value pairs in the config
            pool_args = pool_args or {}

            if pool_args.get("poolclass", "").lower() == "nullpool":
                pool_args["poolclass"] = NullPool
            else:
                # Standard QueuePool settings. Lean pool_size with a large
                # max_overflow: only pool_size connections are retained while
                # idle (overflow connections close on release), so engines —
                # which multiply per dataset under access control — hold few
                # of the server's max_connections slots between bursts while
                # keeping a 40-connection burst ceiling.
                pool_args.setdefault("pool_size", 5)
                pool_args.setdefault("max_overflow", 35)
                pool_args.setdefault("pool_pre_ping", True)
                pool_args.setdefault("pool_recycle", 280)
                pool_args.setdefault("pool_timeout", 280)

            engine_kwargs = {**pool_args}
            if final_connect_args:
                engine_kwargs["connect_args"] = final_connect_args

            self.engine = create_async_engine(
                connection_string,
                **engine_kwargs,
            )

        self.sessionmaker = async_sessionmaker(bind=self.engine, expire_on_commit=False)

    async def push_to_s3(self) -> None:
        if os.getenv("STORAGE_BACKEND", "").lower() == "s3" and hasattr(self, "temp_db_file"):
            from cognee.infrastructure.files.storage.S3FileStorage import S3FileStorage

            s3_file_storage = S3FileStorage("")
            s3_file_storage.s3.put(self.temp_db_file, self.db_path, recursive=True)

    async def pull_from_s3(self) -> None:
        from cognee.infrastructure.files.storage.S3FileStorage import S3FileStorage

        s3_file_storage = S3FileStorage("")
        try:
            s3_file_storage.s3.get(self.db_path, self.temp_db_file, recursive=True)
        except FileNotFoundError:
            pass

    @asynccontextmanager
    async def get_async_session(self) -> AsyncGenerator[AsyncSession, None]:
        """
        Provide an asynchronous context manager for obtaining a database session.
        """
        async_session_maker = self.sessionmaker
        async with async_session_maker() as session:
            try:
                yield session
            except asyncio.CancelledError:
                # A cancelled request can leave the connection in an open
                # transaction; returning it to the pool leaks an "idle in
                # transaction" backend. Invalidate (drop) it instead, shielded
                # so the cleanup is not cut short by the same cancellation.
                await asyncio.shield(self._discard_cancelled_session(session))
                raise
            # Happy path and ordinary exceptions: the sessionmaker context
            # manager closes and rolls back, so no explicit close is needed.

    @staticmethod
    async def _discard_cancelled_session(session: AsyncSession) -> None:
        # A graceful close needs a ROLLBACK round-trip that the cancellation
        # keeps interrupting; invalidate() drops the DBAPI connection without
        # it, so the connection is never reused dirty.
        try:
            await session.invalidate()
        except Exception:
            logger.exception("Failed to invalidate session on cancellation")

    def get_session(self):
        """
        Provide a context manager for obtaining a database session.
        """
        session_maker = self.sessionmaker
        with session_maker() as session:
            try:
                yield session
            finally:
                session.close()  # Ensure the session is closed

    async def get_datasets(self):
        """
        Retrieve a list of datasets from the database.

        Returns:
        --------

            A list of datasets retrieved from the database.
        """
        from cognee.modules.data.models import Dataset

        async with self.get_async_session() as session:
            result = await session.execute(select(Dataset).options(joinedload(Dataset.data)))
            datasets = result.unique().scalars().all()
            return datasets

    async def create_table(self, schema_name: str, table_name: str, table_config: list[dict]):
        """
        Create a table with the specified schema and configuration if it does not exist.

        Parameters:
        -----------

            - schema_name (str): The name of the schema to create the table within.
            - table_name (str): The name of the table to be created.
            - table_config (list[dict]): A list of dictionaries representing the table's fields
              and their types.
        """
        fields_query_parts = [f"{item['name']} {item['type']}" for item in table_config]
        async with self.engine.begin() as connection:
            await connection.execute(text(f"CREATE SCHEMA IF NOT EXISTS {schema_name};"))
            await connection.execute(
                text(
                    f'CREATE TABLE IF NOT EXISTS {schema_name}."{table_name}" ({", ".join(fields_query_parts)});'
                )
            )
            await connection.close()

    async def delete_table(self, table_name: str, schema_name: Optional[str] = "public"):
        """
        Delete a table from the specified schema, if it exists.

        Parameters:
        -----------

            - table_name (str): The name of the table to delete.
            - schema_name (Optional[str]): The name of the schema containing the table to
              delete, defaults to 'public'. (default 'public')
        """
        async with self.engine.begin() as connection:
            if self.engine.dialect.name == "sqlite":
                # SQLite doesn't support schema namespaces and the CASCADE keyword.
                # However, foreign key constraint can be defined with ON DELETE CASCADE during table creation.
                await connection.execute(text(f'DROP TABLE IF EXISTS "{table_name}";'))
            else:
                await connection.execute(
                    text(f'DROP TABLE IF EXISTS {schema_name}."{table_name}" CASCADE;')
                )

    async def insert_data(
        self,
        table_name: str,
        data: list[dict],
        schema_name: Optional[str] = "public",
    ) -> int:
        """
        Insert data into a specified table, returning the number of rows inserted.

        Parameters:
        -----------

            - table_name (str): The name of the table to insert data into.
            - data (list[dict]): A list of dictionaries representing the rows to add to the
              table.
            - schema_name (Optional[str]): The name of the schema containing the table, defaults
              to 'public'. (default 'public')

        Returns:
        --------

            - int: The number of rows inserted into the table.
        """
        if not data:
            logger.info("No data provided for insertion")
            return 0

        try:
            # Resolve the table BEFORE opening the write connection. get_table()
            # checks out its own connection; doing it inside would hold two pooled
            # connections at once and deadlock the pool under concurrency (#4197).
            if self.engine.dialect.name == "sqlite":
                table = await self.get_table(table_name)  # SQLite ignores schemas
            else:
                table = await self.get_table(table_name, schema_name)

            # Use SQLAlchemy Core insert with execution options
            async with self.engine.begin() as conn:
                if self.engine.dialect.name == "sqlite":
                    # Foreign key constraints are disabled by default in SQLite (for backwards compatibility),
                    # so must be enabled for each database connection/session separately.
                    await conn.execute(text("PRAGMA foreign_keys=ON"))

                result = await conn.execute(table.insert().values(data))

                # Return rowcount for validation
                return result.rowcount

        except Exception as e:
            logger.error(f"Insert failed: {str(e)}")
            raise e  # Re-raise for error handling upstream

    async def get_schema_list(self) -> List[str]:
        """
        Return a list of all schema names in the database, excluding system schemas.

        Returns:
        --------

            - List[str]: A list of schema names in the database.
        """
        if self.engine.dialect.name == "postgresql":
            async with self.engine.begin() as connection:
                result = await connection.execute(
                    text(
                        """
                        SELECT schema_name FROM information_schema.schemata
                        WHERE schema_name NOT IN ('pg_catalog', 'pg_toast', 'information_schema');
                        """
                    )
                )
                return [schema[0] for schema in result.fetchall()]
        return []

    async def delete_entity_by_id(
        self, table_name: str, data_id: UUID, schema_name: Optional[str] = "public"
    ):
        """
        Delete an entity from the specified table based on its unique ID.

        Parameters:
        -----------

            - table_name (str): The name of the table from which to delete the entity.
            - data_id (UUID): The unique identifier of the entity to be deleted.
            - schema_name (Optional[str]): The name of the schema where the table resides,
              defaults to 'public'. (default 'public')
        """
        # Resolve the table BEFORE opening the session. get_table() checks out its
        # own connection; doing it inside would hold two pooled connections at once
        # and deadlock the pool under concurrency (#4197).
        TableModel = await self.get_table(table_name, schema_name)

        if self.engine.dialect.name == "sqlite":
            async with self.get_async_session() as session:
                # Foreign key constraints are disabled by default in SQLite (for backwards compatibility),
                # so must be enabled for each database connection/session separately.
                await session.execute(text("PRAGMA foreign_keys = ON;"))

                await session.execute(TableModel.delete().where(TableModel.c.id == data_id))
                await session.commit()
        else:
            async with self.get_async_session() as session:
                await session.execute(TableModel.delete().where(TableModel.c.id == data_id))
                await session.commit()

    async def delete_data_entity(self, data_id: UUID, dataset_id: UUID):
        """
        Delete a data entity along with its local files if no references remain in the database.

        Parameters:
        -----------

            - data_id (UUID): The unique identifier of the data entity to be deleted.
        """
        async with self.get_async_session() as session:
            if self.engine.dialect.name == "sqlite":
                # Foreign key constraints are disabled by default in SQLite (for backwards compatibility),
                # so must be enabled for each database connection/session separately.
                await session.execute(text("PRAGMA foreign_keys = ON;"))

            # Rows are dataset-scoped: the (data_id, dataset_id) pair must
            # match — a mismatch means a mispinned id, not a membership to
            # silently unlink.
            try:
                data_entity = (
                    await session.scalars(
                        select(Data).where(Data.id == data_id, Data.dataset_id == dataset_id)
                    )
                ).one()
            except (ValueError, NoResultFound) as e:
                raise EntityNotFoundError(
                    message=f"Data {data_id} not found in dataset {dataset_id}: {str(e)}"
                ) from e

            raw_data_location = data_entity.raw_data_location
            original_data_location = data_entity.original_data_location

            await session.execute(delete(Data).where(Data.id == data_id))
            await session.commit()

        # Storage cleanup runs after the commit so the reference count reflects
        # the deletion. Both the derived text (raw_data_location) and the
        # stored original (original_data_location) are collected — originals
        # live under content-addressed keys shared by identical payloads, so
        # each is removed only once nothing references it.
        await self.remove_data_file_if_unreferenced(raw_data_location)
        await self.remove_data_file_if_unreferenced(original_data_location)

    async def remove_data_file_if_unreferenced(self, file_location: Optional[str]) -> None:
        """Remove a cognee-managed stored file once no ``Data`` row references it.

        A location outside the data root is a user's own file (a local path, an
        external s3:// URL) and is never touched. Content-addressed keys are
        shared by design — two rows with identical payloads point at one object
        — so the reference count spans both location columns of every dataset.
        """
        if not file_location:
            return

        storage_config = get_storage_config()
        data_root = storage_config["data_root_directory"]
        if data_root not in file_location:
            return

        async with self.get_async_session() as session:
            references = (
                await session.execute(
                    select(func.count())
                    .select_from(Data)
                    .where(
                        or_(
                            Data.raw_data_location == file_location,
                            Data.original_data_location == file_location,
                        )
                    )
                )
            ).scalar()

        if references:
            return

        relative_path = file_location.split(data_root, 1)[1].lstrip("/\\")
        if file_location.startswith("file://"):
            # file:// locations carry percent-encoding (spaces as %20); storage
            # keys are the decoded form.
            relative_path = unquote(relative_path)

        file_storage = get_file_storage(data_root)
        if await file_storage.file_exists(relative_path):
            await file_storage.remove(relative_path)
        else:
            logger.warning("Stored file to clean up was already gone: %s", file_location)

    async def get_table(self, table_name: str, schema_name: Optional[str] = "public") -> Table:
        """
        Load a table dynamically using the specified name and schema information.

        Parameters:
        -----------

            - table_name (str): The name of the table to load.
            - schema_name (Optional[str]): The name of the schema containing the table, defaults
              to 'public'. (default 'public')

        Returns:
        --------

            - Table: The SQLAlchemy Table object corresponding to the specified table.
        """
        async with self.engine.begin() as connection:
            if self.engine.dialect.name == "sqlite":
                # Prefer the declarative table: it carries the models' Python-side
                # type converters (a raw reflected sqlite table would return e.g.
                # datetimes as strings).
                if table_name in Base.metadata.tables:
                    return Base.metadata.tables[table_name]
                # Unknown to the imported models — reflect into a throwaway
                # MetaData, never into Base.metadata: registering an on-disk
                # table whose model module has not been imported yet makes that
                # model's later declarative definition fail with "Table ... is
                # already defined for this MetaData instance".
                metadata = MetaData()
                await connection.run_sync(metadata.reflect)
                if table_name in metadata.tables:
                    return metadata.tables[table_name]
                else:
                    raise EntityNotFoundError(message=f"Table '{table_name}' not found.")
            else:
                # Create a MetaData instance to load table information
                metadata = MetaData()
                # Load table information from schema into MetaData
                await connection.run_sync(metadata.reflect, schema=schema_name)
                # Define the full table name
                if schema_name is None:
                    full_table_name = table_name
                else:
                    full_table_name = f"{schema_name}.{table_name}"
                # Check if table is in list of tables for the given schema
                if full_table_name in metadata.tables:
                    return metadata.tables[full_table_name]
                raise EntityNotFoundError(message=f"Table '{full_table_name}' not found.")

    async def get_table_names(self) -> List[str]:
        """
        Return a list of all table names in the database, regardless of their model definitions.

        Returns:
        --------

            - List[str]: A list of all table names in the database.
        """
        table_names = []
        # Resolve the schema list BEFORE opening our reflection connection.
        # get_schema_list() checks out its own connection; calling it inside would
        # hold two pooled connections at once and deadlock the pool under
        # concurrency (#4197).
        schema_list = await self.get_schema_list() if self.engine.dialect.name != "sqlite" else []
        async with self.engine.begin() as connection:
            if self.engine.dialect.name == "sqlite":
                # Use a new MetaData instance to reflect all tables
                metadata = MetaData()
                await connection.run_sync(metadata.reflect)  # Reflect the entire database
                table_names = list(metadata.tables.keys())  # Get table names
            else:
                metadata = MetaData()
                for schema_name in schema_list:
                    await connection.run_sync(metadata.reflect, schema=schema_name)
                    table_names.extend(metadata.tables.keys())  # Append table names from schema
                    metadata.clear()  # Clear metadata for the next schema

        return table_names

    async def get_data(self, table_name: str, filters: dict = None):
        """
        Retrieve data from a specified table using optional filtering conditions.

        Parameters:
        -----------

            - table_name (str): The name of the table from which to retrieve data.
            - filters (dict): A dictionary of filtering conditions to apply to the data
              retrieval, defaults to None for no filters. (default None)

        Returns:
        --------

            A dictionary of data results keyed by their unique identifiers.
        """
        async with self.engine.begin() as connection:
            query = f'SELECT * FROM "{table_name}"'
            if filters:
                filter_conditions = " AND ".join(
                    [
                        f"{key} IN ({', '.join([f':{key}{i}' for i in range(len(value))])})"
                        if isinstance(value, list)
                        else f"{key} = :{key}"
                        for key, value in filters.items()
                    ]
                )
                query += f" WHERE {filter_conditions};"
                query = text(query)
                results = await connection.execute(query, filters)
            else:
                query += ";"
                query = text(query)
                results = await connection.execute(query)
            return {result["data_id"]: result["status"] for result in results}

    async def get_all_data_from_table(self, table_name: str, schema: str = "public"):
        """
        Fetch all records from a specified table, validating inputs against SQL injection.

        Parameters:
        -----------

            - table_name (str): The name of the table to query data from.
            - schema (str): The schema of the table, defaults to 'public'. (default 'public')

        Returns:
        --------

            A list of dictionaries representing all rows in the specified table.
        """
        # Validate inputs to prevent SQL injection
        if not table_name.isidentifier():
            raise ValueError("Invalid table name")
        if schema and not schema.isidentifier():
            raise ValueError("Invalid schema name")

        # Resolve the table BEFORE opening the session. get_table() checks out its
        # own connection; doing it inside would hold two pooled connections at once
        # and deadlock the pool under concurrency (#4197).
        if self.engine.dialect.name == "sqlite":
            table = await self.get_table(table_name)
        else:
            table = await self.get_table(table_name, schema)

        async with self.get_async_session() as session:
            # Query all data from the table
            query = select(table)
            result = await session.execute(query)

            # Fetch all rows as a list of dictionaries
            rows = result.mappings().all()
            return rows

    async def execute_query(self, query):
        """
        Execute a raw SQL query against the database asynchronously.

        Parameters:
        -----------

            - query: The SQL query string to execute.

        Returns:
        --------

            The result set as a list of dictionaries, with each dictionary representing a row.
        """
        async with self.engine.begin() as connection:
            result = await connection.execute(text(query))
            return [dict(row) for row in result]

    async def drop_tables(self):
        """
        Drop specified tables from the database, if they exist, and handle errors that may occur
        during the process.
        """
        async with self.engine.begin() as connection:
            try:
                await connection.execute(text("DROP TABLE IF EXISTS group_permission CASCADE"))
                await connection.execute(text("DROP TABLE IF EXISTS permissions CASCADE"))
                # Add more DROP TABLE statements for other tables as needed
                logger.debug("Database tables dropped successfully.")
            except Exception as e:
                logger.error(f"Error dropping database tables: {e}")
                raise e

    async def create_database(self):
        """
        Create the database if it does not exist, ensuring necessary directories are in place
        for SQLite.
        """
        if self.engine.dialect.name == "sqlite":
            db_directory = path.dirname(self.db_path)
            db_name = path.basename(self.db_path)
            file_storage = get_file_storage(db_directory)

            if not await file_storage.file_exists(db_name):
                await file_storage.ensure_directory_exists()

        async with self.engine.begin() as connection:
            # Import here to avoid circular imports
            from cognee.infrastructure.databases.vector.config import get_vectordb_config

            vector_config = get_vectordb_config()
            if (
                vector_config.vector_db_provider == "pgvector"
                and self.engine.dialect.name == "postgresql"
            ):
                await connection.execute(text("CREATE EXTENSION IF NOT EXISTS vector;"))
            if len(Base.metadata.tables.keys()) > 0:
                await connection.run_sync(Base.metadata.create_all)

    async def delete_database(self):
        """
        Delete the entire database, including all tables and files if applicable.
        """
        try:
            if self.engine.dialect.name == "sqlite":
                await self.engine.dispose(close=True)
                # The create_relational_engine() lru_cache keeps this adapter
                # (and its AsyncEngine/sessionmaker) reachable, which on Windows
                # keeps the underlying aiosqlite connection/background thread
                # alive and holding the file handle. Drop that strong reference
                # so the connection can finalize before we remove the file.
                # Imported lazily to avoid the circular import
                # (create_relational_engine imports this adapter).
                from cognee.infrastructure.databases.relational.create_relational_engine import (
                    create_relational_engine,
                )

                create_relational_engine.cache_clear()
                gc.collect()
                # Wait for the database connections to close and release the file.
                # This settle also preserves teardown timing other resources
                # (e.g. the graph DB) rely on between tests, so keep it
                # unconditional.
                await asyncio.sleep(2)
                db_directory = path.dirname(self.db_path)
                file_name = path.basename(self.db_path)
                file_storage = get_file_storage(db_directory)
                # On Windows the SQLite file handle can still linger after the
                # settle above (aiosqlite closes the connection on a background
                # thread), so os.remove fails with WinError 32. Retry with short
                # backoff and force a GC pass to finalize lingering connection
                # objects.
                for attempt in range(10):
                    try:
                        await file_storage.remove(file_name)
                        break
                    except (PermissionError, OSError) as remove_error:
                        if attempt == 9:
                            # Best-effort cleanup: a stubborn Windows file lock
                            # must never poison teardown/prune. No test asserts
                            # the file is gone and every create path uses
                            # CREATE TABLE IF NOT EXISTS, so a left-behind file
                            # is harmless. Log and continue instead of raising.
                            logger.warning(
                                "Could not remove sqlite database file %s after retries: %s",
                                file_name,
                                remove_error,
                            )
                            break
                        gc.collect()
                        await asyncio.sleep(0.5)
            else:
                async with self.engine.begin() as connection:
                    # Create a MetaData instance to load table information
                    metadata = MetaData()
                    # Drop all tables from the public schema
                    schema_list = ["public", "public_staging"]
                    for schema_name in schema_list:
                        # Load the schema information into the MetaData object
                        await connection.run_sync(metadata.reflect, schema=schema_name)
                        for table in metadata.sorted_tables:
                            drop_table_query = text(
                                f'DROP TABLE IF EXISTS {schema_name}."{table.name}" CASCADE'
                            )
                            await connection.execute(drop_table_query)
                        metadata.clear()

        except Exception as e:
            logger.error(f"Error deleting database: {e}")
            raise e

        logger.info("Database deleted successfully.")

    async def extract_schema(self):
        """
        Extract the schema information of the database, including tables and their respective
        columns and constraints.

        Returns:
        --------

            A dictionary containing the schema details of the database.
        """
        # Resolve table names / schema list BEFORE opening our connection. Each of
        # these checks out its own connection; calling them inside would hold two
        # pooled connections at once and deadlock the pool under concurrency (#4197).
        tables = await self.get_table_names()
        schema_list = await self.get_schema_list() if self.engine.dialect.name != "sqlite" else []

        async with self.engine.begin() as connection:
            schema = {}

            if self.engine.dialect.name == "sqlite":
                for table_name in tables:
                    schema[table_name] = {"columns": [], "primary_key": None, "foreign_keys": []}

                    # Get column details
                    columns_result = await connection.execute(
                        text(f"PRAGMA table_info('{table_name}');")
                    )
                    columns = columns_result.fetchall()
                    for column in columns:
                        column_name = column[1]
                        column_type = column[2]
                        is_pk = column[5] == 1
                        schema[table_name]["columns"].append(
                            {"name": column_name, "type": column_type}
                        )
                        if is_pk:
                            schema[table_name]["primary_key"] = column_name

                    # Get foreign key details
                    foreign_keys_results = await connection.execute(
                        text(f"PRAGMA foreign_key_list('{table_name}');")
                    )
                    foreign_keys = foreign_keys_results.fetchall()
                    for fk in foreign_keys:
                        schema[table_name]["foreign_keys"].append(
                            {
                                "column": fk[3],  # Column in the current table
                                "ref_table": fk[2],  # Referenced table
                                "ref_column": fk[4],  # Referenced column
                            }
                        )
            else:
                for schema_name in schema_list:
                    # Get tables for the current schema via the inspector.
                    tables = await connection.run_sync(
                        lambda sync_conn: inspect(sync_conn).get_table_names(schema=schema_name)
                    )
                    for table_name in tables:
                        # Optionally, qualify the table name with the schema if not in the default schema.
                        key = (
                            table_name if schema_name == "public" else f"{schema_name}.{table_name}"
                        )
                        schema[key] = {"columns": [], "primary_key": None, "foreign_keys": []}

                        # Helper function to get table details using the inspector.
                        def get_details(sync_conn, table, schema_name):
                            """
                            Retrieve detailed information about a specific table including columns, primary keys,
                            and foreign keys.

                            Parameters:
                            -----------

                                - sync_conn: The synchronous connection used to interact with the database.
                                - table: The name of the table to retrieve details for.
                                - schema_name: The schema name in which the table resides.

                            Returns:
                            --------

                                Details about the table's columns, primary keys, and foreign keys.
                            """
                            insp = inspect(sync_conn)
                            cols = insp.get_columns(table, schema=schema_name)
                            pk = insp.get_pk_constraint(table, schema=schema_name)
                            fks = insp.get_foreign_keys(table, schema=schema_name)
                            return cols, pk, fks

                        cols, pk, fks = await connection.run_sync(
                            get_details, table_name, schema_name
                        )

                        for column in cols:
                            # Convert the type to string
                            schema[key]["columns"].append(
                                {"name": column["name"], "type": str(column["type"])}
                            )
                        pk_columns = pk.get("constrained_columns", [])
                        if pk_columns:
                            schema[key]["primary_key"] = pk_columns[0]
                        for fk in fks:
                            for col, ref_col in zip(
                                fk.get("constrained_columns", []), fk.get("referred_columns", [])
                            ):
                                if col and ref_col:
                                    schema[key]["foreign_keys"].append(
                                        {
                                            "column": col,
                                            "ref_table": fk.get("referred_table"),
                                            "ref_column": ref_col,
                                        }
                                    )
                                else:
                                    logger.warning(
                                        f"Missing value in foreign key information. \nColumn value: {col}\nReference column value: {ref_col}\n"
                                    )

            return schema
