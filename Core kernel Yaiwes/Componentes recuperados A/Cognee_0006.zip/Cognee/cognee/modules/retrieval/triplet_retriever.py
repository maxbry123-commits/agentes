from typing import Any, Dict, List, Optional, Type, Union

from cognee.shared.logging_utils import get_logger
from cognee.infrastructure.databases.vector import get_vector_engine_async
from cognee.modules.retrieval.utils.completion import generate_completion
from cognee.modules.retrieval.utils.merge_results import conversational_reserve, merge_ranked
from cognee.infrastructure.session.get_session_manager import get_session_manager
from cognee.modules.retrieval.base_retriever import BaseRetriever
from cognee.modules.retrieval.exceptions.exceptions import NoDataError
from cognee.infrastructure.databases.vector.exceptions import CollectionNotFoundError
from cognee.context_global_variables import session_user
from cognee.infrastructure.databases.cache.config import CacheConfig
from cognee.modules.retrieval.utils.references import append_chunk_evidence

logger = get_logger("TripletRetriever")


class TripletRetriever(BaseRetriever):
    """
    Retriever for handling LLM-based completion searches using triplets.

    Public methods:
    - get_context(query: str) -> str
    - get_completion(query: str, context: Optional[Any] = None) -> Any
    """

    def __init__(
        self,
        user_prompt_path: str = "context_for_question.txt",
        system_prompt_path: str = "answer_simple_question.txt",
        system_prompt: Optional[str] = None,
        top_k: Optional[int] = 5,
        session_id: Optional[str] = None,
        response_model: Type = str,
        include_references: bool = False,
        node_name: Optional[List[str]] = None,
        node_name_filter_operator: str = "OR",
    ):
        """Initialize retriever with optional custom prompt paths."""
        self.user_prompt_path = user_prompt_path
        self.system_prompt_path = system_prompt_path
        self.top_k = top_k if top_k is not None else 5
        self.system_prompt = system_prompt
        self.session_id = session_id
        self.response_model = response_model
        self.include_references = include_references
        self.node_name = node_name
        self.node_name_filter_operator = node_name_filter_operator

    async def get_retrieved_objects(self, query: str) -> Any:
        """
        Retrieves relevant triplets.

        Fetches triplets based on a query from a vector engine.
        Returns empty list if no triplets are found. Raises NoDataError if the collection is not
        found.

        Parameters:
        -----------

            - query (str): The query string used to search for relevant triplets.

        Returns:
        --------

            - Any: A list containing the retrieved triplets, or an empty list if none are found.
        """
        vector_engine = await get_vector_engine_async()

        try:
            if not await vector_engine.has_collection(collection_name="Triplet_text"):
                logger.error("Triplet_text collection not found")
                raise NoDataError(
                    "In order to use TRIPLET_COMPLETION first use the create_triplet_embeddings memify pipeline. "
                )

            found_triplets = await vector_engine.search(
                "Triplet_text",
                query,
                limit=self.top_k,
                include_payload=True,
                node_name=self.node_name,
                node_name_filter_operator=self.node_name_filter_operator,
            )

            if len(found_triplets) == 0:
                return []

            return found_triplets
        except CollectionNotFoundError as error:
            logger.error("Triplet_text collection not found")
            raise NoDataError("No data found in the system, please add data first.") from error

    def merge_retrieved_objects(self, primary: Any, secondary: Any) -> Any:
        return merge_ranked(
            primary,
            secondary,
            limit=self.top_k,
            secondary_reserve=conversational_reserve(self.top_k),
        )

    def extract_context_object_ids(self, retrieved_objects: Any) -> Optional[Dict[str, List[str]]]:
        """Triplets are non-elementary graph objects; do not report IDs for session QA - object ids cannot be resolved"""
        return None

    async def get_context_from_objects(self, query: str, retrieved_objects: Any) -> str:
        if retrieved_objects:
            triplets_payload = [
                found_triplet.payload["text"] for found_triplet in retrieved_objects
            ]
            combined_context = "\n".join(triplets_payload)
            return combined_context
        return ""

    def _completion_kwargs(self, context: str) -> dict:
        """Common kwargs for completion calls (no session)."""
        return {
            "context": context,
            "user_prompt_path": self.user_prompt_path,
            "system_prompt_path": self.system_prompt_path,
            "system_prompt": self.system_prompt,
            "response_model": self.response_model,
        }

    async def _generate_completion_without_session(self, query: str, context: str) -> List[Any]:
        """Generate completion without session; returns list of one completion."""
        kwargs = self._completion_kwargs(context)
        completion = await generate_completion(query=query, **kwargs)
        return [completion]

    async def append_references(self, completions: List[Any], retrieved_objects: Any) -> List[Any]:
        return append_chunk_evidence(
            completions,
            retrieved_objects,
            enabled=self.include_references and self.response_model is str,
        )

    async def get_completion_from_context(
        self,
        query: str,
        retrieved_objects: Any,
        context: Any,
        effective_query: Optional[str] = None,
        turn_preparation=None,
    ) -> Union[List[str], List[dict]]:
        """
        Generates an LLM completion using the context.

        Retrieves context if not provided and generates a completion based on the query and
        context using an external completion generator.

        Parameters:
        -----------

            - query (str): The query string to be used for generating a completion.
            - context (Optional[Any]): Optional pre-fetched context to use for generating the
              completion; if None, it retrieves the context for the query. (default None)
            - session_id (Optional[str]): Optional session identifier for caching. If None,
              defaults to 'default_session'. (default None)
            - response_model (Type): The Pydantic model type for structured output. (default str)

        Returns:
        --------

            - Any: The generated completion based on the provided query and context.
        """
        cache_config = CacheConfig()
        user = session_user.get()
        user_id = getattr(user, "id", None)
        use_session = user_id and cache_config.caching

        if use_session:
            sm = get_session_manager()
            used_graph_element_ids = self.extract_context_object_ids(retrieved_objects)
            completion = await sm.generate_completion_with_session(
                session_id=self.session_id,
                query=query,
                context=context,
                user_prompt_path=self.user_prompt_path,
                system_prompt_path=self.system_prompt_path,
                system_prompt=self.system_prompt,
                response_model=self.response_model,
                summarize_context=False,
                used_graph_element_ids=used_graph_element_ids,
                max_context_chars=getattr(self, "max_context_chars", None),
                effective_query=effective_query,
                turn_preparation=turn_preparation,
            )
            completions = [completion]
        else:
            completions = await self._generate_completion_without_session(query, context)

        # Both the session/cache branch and the non-session branch rejoin here.
        return await self.append_references(completions, retrieved_objects)
