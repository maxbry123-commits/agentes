"""Full-stack end-to-end test for the docker-compose deployment.

Complements the workflow-level remember/recall smoke test in
``.github/workflows/docker_compose.yml`` with a real assertion suite:

* the golden flow against the cognee API on :8000,
* a real MCP tool call against the cognee-mcp service on :8001,
* a traceback scan over every service's logs, and
* Postgres-backed persistence across a container recreate.

By default the LLM-dependent leg (cognify/search) is skipped, so this suite
never calls a real model ("mock LLM by default"). Set ``COGNEE_E2E_RUN_LLM=1``
with a real key to exercise it.

Ordering matters: the traceback scan runs *before* the persistence test,
because force-recreating Postgres legitimately drops the API's live database
connections and the resulting (recovered-from) errors may be logged with
tracebacks.
"""

from __future__ import annotations

import re
import time

import requests

from compose_utils import recreate_service, service_logs, wait_for_http_ok
from config import CONFIG
from golden_flow import find_dataset, golden_flow, login
from mcp_client import call_mcp_tool

# Services whose logs must be free of Python tracebacks.
LOG_SERVICES = ("cognee", "cognee-mcp", "postgres")


def test_golden_flow_api(api_ready):
    """health -> login -> add -> datasets -> data (+ optional cognify/search)."""
    result = golden_flow(api_ready)

    assert result.dataset_id
    assert result.data_count >= 1
    if CONFIG.run_llm:
        assert result.searched, "LLM run requested but search leg did not execute"


def test_mcp_health_and_tool_call(mcp_ready):
    """MCP service is healthy and a real tool call round-trips."""
    health = wait_for_http_ok(CONFIG.mcp_health_url, name="cognee-mcp /health")
    assert health.json().get("status") == "ok", health.text

    call = call_mcp_tool()
    # `cognify_status()` renders the pipeline-status mapping as a dict string
    # ("{}", or "{'<dataset-uuid>': ...}" once ingestion has run) — or, in API
    # mode before any ingestion, an explicit "❌ Dataset ... not found via API"
    # line. Any of these proves a real LLM-free tool call round-tripped.
    assert re.match(r"(\{|❌ Dataset )", call.result_text), (
        f"unexpected cognify_status output: {call.result_text!r}"
    )
    # structuredContent is only forwarded for tools advertised in tools/list,
    # and `cognify_status` returns plain TextContent — treat any structured
    # payload as a bonus and only sanity-check its type when present.
    if call.structured is not None:
        assert isinstance(call.structured, dict), call.structured


def test_service_logs_are_traceback_free(requires_compose):
    """No service should have emitted an unhandled Python traceback.

    Must run before the persistence test: recreating Postgres drops the API's
    live connections, and those transient (handled) failures can be logged
    with tracebacks.
    """
    offenders = {}
    for service in LOG_SERVICES:
        logs = service_logs(service)
        if "Traceback (most recent call last)" in logs:
            tail = "\n".join(logs.splitlines()[-40:])
            offenders[service] = tail

    assert not offenders, "Tracebacks found in service logs:\n" + "\n\n".join(
        f"--- {svc} ---\n{tail}" for svc, tail in offenders.items()
    )


def test_postgres_persistence_across_recreate(requires_compose, api_ready):
    """Data added through the API survives a Postgres container recreate.

    A force-recreate discards the container's writable layer, so the dataset
    only survives if Postgres data lives on the named volume. This makes the
    volume requirement explicit: comment the volume out and this test fails.
    """
    result = golden_flow(api_ready)

    recreate_service("postgres")

    # Postgres comes back on a fresh container; wait for it (and the API) again.
    wait_for_http_ok(CONFIG.health_url, name="cognee API after postgres recreate")

    # The app re-establishes its connection pool after the DB bounced, so the
    # first requests may fail transiently — keep retrying until the deadline.
    deadline = time.monotonic() + 90
    dataset = None
    last_error: Exception | None = None
    while time.monotonic() < deadline:
        try:
            token = login(api_ready, CONFIG.username, CONFIG.password)
            dataset = find_dataset(api_ready, token, result.dataset_name)
            if dataset is not None:
                break
        except (requests.RequestException, AssertionError) as exc:
            last_error = exc
        time.sleep(3)

    assert dataset is not None, (
        f"dataset '{result.dataset_name}' did not survive the Postgres recreate — "
        "the postgres_data volume is likely missing from docker-compose.yml "
        f"(last error: {last_error!r})"
    )
