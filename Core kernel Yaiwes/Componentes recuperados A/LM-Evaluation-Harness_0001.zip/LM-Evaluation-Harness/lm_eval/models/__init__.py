"""Model implementations for lm_eval.

Models are lazily loaded via the registry system to improve startup performance.

Usage
-----
For programmatic access, use the registry:

    from lm_eval.api.registry import get_model
    model_cls = get_model("hf")
    model = model_cls(pretrained="gpt2")

For direct imports (e.g., subclassing), use explicit module paths:

    from lm_eval.models.huggingface import HFLM
    from lm_eval.models.vllm_causallms import VLLM

Adding New Models
-----------------
1. Create your model class in a new file under lm_eval/models/
2. Use the @register_model decorator on your class
3. Add an entry to MODEL_MAPPING below for lazy discovery
"""

MODEL_MAPPING = {
    "anthropic-chat": "lm_eval.models.anthropic_llms:AnthropicChat",
    "anthropic-chat-completions": "lm_eval.models.anthropic_llms:AnthropicChat",
    "anthropic-completions": "lm_eval.models.anthropic_llms:AnthropicLM",
    "dummy": "lm_eval.models.dummy:DummyLM",
    "ggml": "lm_eval.models.gguf:GGUFLM",
    "gguf": "lm_eval.models.gguf:GGUFLM",
    "hf": "lm_eval.models.huggingface:HFLM",
    "hf-audiolm-qwen": "lm_eval.models.hf_audiolm:HFAudioLM",
    "hf-auto": "lm_eval.models.huggingface:HFLM",
    "hf-mistral3": "lm_eval.models.mistral3:Mistral3LM",
    "hf-multimodal": "lm_eval.models.hf_vlms:HFMultimodalLM",
    "huggingface": "lm_eval.models.huggingface:HFLM",
    "ipex": "lm_eval.models.optimum_ipex:IPEXForCausalLM",
    "litellm": "lm_eval.models.litellm_llms:LiteLLMChatCompletion",
    "litellm-chat": "lm_eval.models.litellm_llms:LiteLLMChatCompletion",
    "litellm-chat-completions": "lm_eval.models.litellm_llms:LiteLLMChatCompletion",
    "local-chat-completions": "lm_eval.models.openai_completions:LocalChatCompletion",
    "local-completions": "lm_eval.models.openai_completions:LocalCompletionsAPI",
    "mamba_ssm": "lm_eval.models.mamba_lm:MambaLMWrapper",
    "megatron_lm": "lm_eval.models.megatron_lm:MegatronLMEval",
    "nemo_lm": "lm_eval.models.nemo_lm:NeMoLM",
    "neuronx": "lm_eval.models.neuron_optimum:NeuronModelForCausalLM",
    "onnxruntime": "lm_eval.models.onnxruntime_ort:ONNXRuntimeLM",
    "onnxruntime-genai": "lm_eval.models.onnxruntime_genai:ONNXRuntimeGenAILM",
    "openai-chat-completions": "lm_eval.models.openai_completions:OpenAIChatCompletion",
    "openai-completions": "lm_eval.models.openai_completions:OpenAICompletionsAPI",
    "openvino": "lm_eval.models.optimum_lm:OptimumLM",
    "habana": "lm_eval.models.optimum_habana:HabanaLM",
    "sglang": "lm_eval.models.sglang_causallms:SGLangLM",
    "sglang-generate": "lm_eval.models.sglang_generate_API:SGLANGGENERATEAPI",
    "steered": "lm_eval.models.hf_steered:SteeredModel",
    "textsynth": "lm_eval.models.textsynth:TextSynthLM",
    "trtllm": "lm_eval.models.trtllm_causallms:TRTLLM",
    "vllm": "lm_eval.models.vllm_causallms:VLLM",
    "vllm-vlm": "lm_eval.models.vllm_vlms:VLLM_VLM",
    "watsonx_llm": "lm_eval.models.ibm_watsonx_ai:WatsonxLLM",
    "winml": "lm_eval.models.winml:WindowsML",
}


def _register_all_models():
    """Register all known models lazily in the registry."""
    from lm_eval.api.registry import load_plugins, model_registry

    for name, path in MODEL_MAPPING.items():
        # Only register if not already present (avoids conflicts when modules are imported)
        if name not in model_registry:
            # Register the lazy placeholder
            model_registry.register(name, target=path)

    # Discover external backends advertised via entry points by installed packages.
    load_plugins("lm_eval.models", model_registry)


# Call registration on module import
_register_all_models()

__all__ = ["MODEL_MAPPING"]
