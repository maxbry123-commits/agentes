# CrowdStrike AIDR Example

This example demonstrates how to integrate with the CrowdStrike AIDR API for protecting data and interactions with LLMs within AI-powered applications

To test this configuration you can use the CLI Chat by running the following command from the
`examples/configs/crowdstrike_aidr` directory:

```bash
uv run nemoguardrails chat --config=.
```
