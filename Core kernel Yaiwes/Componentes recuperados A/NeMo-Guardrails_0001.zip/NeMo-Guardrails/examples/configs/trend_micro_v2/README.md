# Trend Micro Vision One AI Application Security Example

This example demonstrates how to integrate with the Trend Micro Vision One API Guard API for protecting data and interactions with LLMs within AI-powered applications

To test this configuration you can use the CLI Chat by running the following command from the `examples/configs/trend_micro_v2` directory:

```bash
uv run nemoguardrails chat --config=.
```

Documentation:

- [Configuration options and setup instructions](../../../docs/user-guides/community/trend-micro.md)
