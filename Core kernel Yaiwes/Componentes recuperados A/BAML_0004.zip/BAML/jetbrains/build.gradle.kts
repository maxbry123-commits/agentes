import org.jetbrains.changelog.Changelog
import org.jetbrains.changelog.markdownToHTML
import org.jetbrains.intellij.platform.gradle.IntelliJPlatformType
import org.jetbrains.intellij.platform.gradle.TestFrameworkType

plugins {
    id("java") // Java support
    alias(libs.plugins.kotlin) // Kotlin support
    alias(libs.plugins.kotlinSerialization)
    alias(libs.plugins.intelliJPlatform) // IntelliJ Platform Gradle Plugin
    alias(libs.plugins.changelog) // Gradle Changelog Plugin
    alias(libs.plugins.qodana) // Gradle Qodana Plugin
    alias(libs.plugins.kover) // Gradle Kover Plugin
}

group = providers.gradleProperty("pluginGroup").get()
version = providers.gradleProperty("pluginVersion").get()

// Set the JVM language level used to build the project.
kotlin {
    jvmToolchain(21)
}

// Configure project's dependencies
repositories {
    mavenCentral()

    // IntelliJ Platform Gradle Plugin Repositories Extension - read more: https://plugins.jetbrains.com/docs/intellij/tools-intellij-platform-gradle-plugin-repositories-extension.html
    intellijPlatform {
        defaultRepositories()
    }
}

// Dependencies are managed with Gradle version catalog - read more: https://docs.gradle.org/current/userguide/platforms.html#sub:version-catalog
dependencies {
    testImplementation(libs.junit)
    testImplementation(libs.opentest4j)

    // IntelliJ Platform Gradle Plugin Dependencies Extension - read more: https://plugins.jetbrains.com/docs/intellij/tools-intellij-platform-gradle-plugin-dependencies-extension.html
    intellijPlatform {
        create(providers.gradleProperty("platformType"), providers.gradleProperty("platformVersion"))

        // Plugin Dependencies. Uses `platformBundledPlugins` property from the gradle.properties file for bundled IntelliJ Platform plugins.
        bundledPlugins(providers.gradleProperty("platformBundledPlugins").map { it.split(',') })

        // Plugin Dependencies. Uses `platformPlugins` property from the gradle.properties file for plugin from JetBrains Marketplace.
        plugins(providers.gradleProperty("platformPlugins").map { it.split(',') })

        testFramework(TestFrameworkType.Platform)
    }

    implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.6.3")
    
    // CLI Downloader dependencies
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("org.apache.commons:commons-compress:1.24.0")
    implementation("org.slf4j:slf4j-api:2.0.9")
    implementation("ch.qos.logback:logback-classic:1.4.11")
    implementation("io.github.microutils:kotlin-logging-jvm:3.0.5")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-core:1.7.3")
}

// Configure IntelliJ Platform Gradle Plugin - read more: https://plugins.jetbrains.com/docs/intellij/tools-intellij-platform-gradle-plugin-extension.html
intellijPlatform {
    pluginConfiguration {
        name = providers.gradleProperty("pluginName")
        version = providers.gradleProperty("pluginVersion")

        // Use the BAML v0 README as the plugin's Marketplace description.
        description = providers.fileContents(layout.projectDirectory.file("../README.v0.md")).asText.map(::markdownToHTML)

        val changelog = project.changelog // local variable for configuration cache compatibility
        // Get the latest available change notes from the changelog file
        changeNotes = providers.gradleProperty("pluginVersion").map { pluginVersion ->
            with(changelog) {
                renderItem(
                    (getOrNull(pluginVersion) ?: getUnreleased())
                        .withHeader(false)
                        .withEmptySections(false),
                    Changelog.OutputType.HTML,
                )
            }
        }

        ideaVersion {
            sinceBuild = providers.gradleProperty("pluginSinceBuild")
            untilBuild = providers.gradleProperty("pluginUntilBuild")
        }
    }

    signing {
        certificateChain = providers.environmentVariable("CERTIFICATE_CHAIN")
        privateKey = providers.environmentVariable("PRIVATE_KEY")
        password = providers.environmentVariable("PRIVATE_KEY_PASSWORD")
    }

    publishing {
        token = providers.environmentVariable("INTELLIJ_PLATFORM_PUBLISH_TOKEN")
        // The pluginVersion is based on the SemVer (https://semver.org) and supports pre-release labels, like 2.1.7-alpha.3
        // Specify pre-release label to publish the plugin in a custom Release Channel automatically. Read more:
        // https://plugins.jetbrains.com/docs/intellij/deployment.html#specifying-a-release-channel
        channels = providers.gradleProperty("pluginVersion").map { listOf(it.substringAfter('-', "").substringBefore('.').ifEmpty { "default" }) }
    }

    pluginVerification {
        ides {
            if (providers.gradleProperty("verifyDeclaredPlatformOnly").map(String::toBoolean).getOrElse(false)) {
                ide(providers.gradleProperty("platformType"), providers.gradleProperty("platformVersion"))
            } else if (providers.gradleProperty("verifyMarketplaceBoundary").map(String::toBoolean).getOrElse(false)) {
                ide(providers.gradleProperty("platformType"), providers.gradleProperty("platformVersion"))
                ide(IntelliJPlatformType.IntellijIdeaUltimate, providers.gradleProperty("marketplaceVerificationVersion").get())
            } else {
                recommended()
            }
        }
    }
}

// Configure Gradle Changelog Plugin - read more: https://github.com/JetBrains/gradle-changelog-plugin
changelog {
    groups.empty()
    repositoryUrl = providers.gradleProperty("pluginRepositoryUrl")
}

// Configure Gradle Kover Plugin - read more: https://github.com/Kotlin/kotlinx-kover#configuration
kover {
    reports {
        total {
            xml {
                onCheck = true
            }
        }
    }
}

tasks {
    println("Setting up gradle tasks (src=${"dummy-println"})")

    wrapper {
        gradleVersion = providers.gradleProperty("gradleVersion").get()
    }

    // This task is inherited from a dependency, "intellij platform" maybe?
    processResources {
        dependsOn("copyTextmateFiles")
    }

    // This task is inherited from a dependency, "intellij platform" maybe?
    publishPlugin {
        dependsOn(patchChangelog)
    }

    register<Copy>("copyTextmateFiles") {
        group = "build"
        from("../typescript/apps/vscode-ext") {
            include("package.json")
            include("language-configuration.json")
            include("syntaxes/baml.tmLanguage.json")
            include("syntaxes/jinja.tmLanguage.json")
        }
        into("src/main/resources/textmate")
    }
    
    // Configure the runIde task to auto-open integ-tests directory
    runIde {
        args = listOf("${layout.projectDirectory}/../integ-tests/baml_src")
    }
    
    // Configure trusted paths to avoid security prompts in development
    prepareSandbox {
        val integTestsPath = layout.projectDirectory.dir("../integ-tests").asFile.absolutePath
        val bamlSrcPath = layout.projectDirectory.dir("../integ-tests/baml_src").asFile.absolutePath
        
        doLast {
            val trustedPathsFile = sandboxConfigDirectory.file("options/trusted-paths.xml").get().asFile
            trustedPathsFile.parentFile.mkdirs()
            trustedPathsFile.writeText(
                """
                <application>
                  <component name="Trusted.Paths">
                    <option name="TRUSTED_PROJECT_PATHS">
                      <map>
                        <entry key="$integTestsPath" value="true" />
                        <entry key="$bamlSrcPath" value="true" />
                      </map>
                    </option>
                  </component>
                </application>
                """.trimIndent()
            )
        }
    }
}

intellijPlatformTesting {
    runIde {
        register("runIdeForUiTests") {
            task {
                jvmArgumentProviders += CommandLineArgumentProvider {
                    listOf(
                        "-Drobot-server.port=8082",
                        "-Dide.mac.message.dialogs.as.sheets=false",
                        "-Djb.privacy.policy.text=<!--999.999-->",
                        "-Djb.consents.confirmation.enabled=false",
                    )
                }
            }

            plugins {
                robotServerPlugin()
            }
        }
    }
}
