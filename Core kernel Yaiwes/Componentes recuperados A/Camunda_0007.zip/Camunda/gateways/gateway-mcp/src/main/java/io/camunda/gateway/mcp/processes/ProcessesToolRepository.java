/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */
package io.camunda.gateway.mcp.processes;

import io.camunda.gateway.mcp.config.server.ToolRepository;
import io.camunda.gateway.mcp.mapper.CallToolResultMapper;
import io.camunda.search.entities.MessageSubscriptionEntity;
import io.camunda.search.entities.MessageSubscriptionEntity.MessageSubscriptionState;
import io.camunda.search.entities.MessageSubscriptionEntity.MessageSubscriptionType;
import io.camunda.search.filter.Operation;
import io.camunda.search.query.MessageSubscriptionQuery;
import io.camunda.security.api.context.CamundaAuthenticationProvider;
import io.camunda.service.MessageServices.CorrelateMessageRequest;
import io.camunda.service.registry.ServiceRegistry;
import io.camunda.spring.utils.PhysicalTenantContext;
import io.camunda.zeebe.protocol.record.ChannelType;
import io.camunda.zeebe.util.Either;
import io.camunda.zeebe.util.collection.Tuple;
import io.modelcontextprotocol.common.McpTransportContext;
import io.modelcontextprotocol.server.McpStatelessServerFeatures.SyncToolSpecification;
import io.modelcontextprotocol.spec.McpSchema.CallToolRequest;
import io.modelcontextprotocol.spec.McpSchema.CallToolResult;
import io.modelcontextprotocol.spec.McpSchema.Tool;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import java.util.function.BiFunction;
import java.util.stream.Stream;
import org.jspecify.annotations.NonNull;

public class ProcessesToolRepository implements ToolRepository {

  protected static final String PROPERTY_INPUTS = "io.camunda.tool:inputs";
  protected static final String PROPERTY_PURPOSE = "io.camunda.tool:purpose";
  protected static final String PROPERTY_RESULTS = "io.camunda.tool:results";
  protected static final String PROPERTY_WHEN_NOT_TO_USE = "io.camunda.tool:when_not_to_use";
  protected static final String PROPERTY_WHEN_TO_USE = "io.camunda.tool:when_to_use";
  protected static final String LABEL_INPUTS = "## Inputs";
  protected static final String LABEL_RESULTS = "## Results";
  protected static final String LABEL_WHEN_NOT_TO_USE = "## When not to use";
  protected static final String LABEL_WHEN_TO_USE = "## When to use";
  protected static final String BUSINESS_ID_ARGUMENT = "businessId";
  private static final char TOOL_NAME_DELIMITER = '_';
  private static final Map<String, Object> TOOL_INPUT_SCHEMA =
      Map.of(
          "type",
          "object",
          "properties",
          Map.of(
              BUSINESS_ID_ARGUMENT,
              Map.of(
                  "type",
                  "string",
                  "description",
                  "Optional business id that enforces uniqueness of the started process instance. "
                      + "While another instance of this process started with the same business id is "
                      + "active, starting another one is rejected. All other arguments are passed as "
                      + "process variables.")));
  private static final Map<String, Object> TOOL_OUTPUT_SCHEMA =
      Map.of(
          "type",
          "object",
          "properties",
          Map.of(
              "processInstanceKey",
              Map.of(
                  "type",
                  "integer",
                  "format",
                  "int64",
                  "description",
                  "The key of the started process instance. Use this to investigate the state of the started instance.")),
          "required",
          List.of("processInstanceKey"));
  private static final List<Tuple<String, String>> DESCRIPTION_PARTS =
      List.of(
          Tuple.of(PROPERTY_PURPOSE, ""),
          Tuple.of(PROPERTY_INPUTS, LABEL_INPUTS),
          Tuple.of(PROPERTY_WHEN_TO_USE, LABEL_WHEN_TO_USE),
          Tuple.of(PROPERTY_WHEN_NOT_TO_USE, LABEL_WHEN_NOT_TO_USE),
          Tuple.of(PROPERTY_RESULTS, LABEL_RESULTS));

  private final ServiceRegistry serviceRegistry;
  private final CamundaAuthenticationProvider authenticationProvider;
  private final List<SyncToolSpecification> staticTools;

  public ProcessesToolRepository(
      final ServiceRegistry serviceRegistry,
      final CamundaAuthenticationProvider authenticationProvider,
      final List<SyncToolSpecification> staticTools) {
    this.serviceRegistry = serviceRegistry;
    this.authenticationProvider = authenticationProvider;
    this.staticTools = List.copyOf(staticTools);
  }

  @Override
  public @NonNull List<Tool> getTools(@NonNull final McpTransportContext transportContext) {
    final var auth = authenticationProvider.getCamundaAuthentication();
    // fetch open start message subscriptions with tool names
    final var query =
        MessageSubscriptionQuery.of(
            b ->
                b.filter(
                        f ->
                            f.messageSubscriptionTypes(MessageSubscriptionType.START_EVENT.name())
                                .messageSubscriptionStateOperations(
                                    Operation.neq(MessageSubscriptionState.DELETED.name()))
                                .toolNameOperations(Operation.exists(true)))
                    .unlimited());

    // combine static and dynamic tools
    return Stream.concat(
            serviceRegistry
                .messageSubscriptionServices(PhysicalTenantContext.current())
                .search(query, auth)
                .items()
                .stream()
                .map(ProcessesToolRepository::buildTool),
            staticTools.stream().map(SyncToolSpecification::tool))
        .toList();
  }

  @Override
  public @NonNull Either<String, SyncToolSpecification> findTool(
      @NonNull final McpTransportContext transportContext, @NonNull final String toolName) {
    // check static tools first
    final var staticTool =
        staticTools.stream().filter(spec -> spec.tool().name().equals(toolName)).findFirst();
    if (staticTool.isPresent()) {
      return Either.right(staticTool.get());
    }
    return findMessageSubscription(toolName)
        .map(
            entity ->
                SyncToolSpecification.builder()
                    .tool(buildTool(entity))
                    .callHandler(buildCallHandler(entity))
                    .build());
  }

  private Either<String, MessageSubscriptionEntity> findMessageSubscription(final String toolName) {
    // extract the message subscription key encoded in the tool name
    final int subscriptionKeyIndex = toolName.lastIndexOf(TOOL_NAME_DELIMITER);
    if (subscriptionKeyIndex < 0) {
      return Either.left("Tool not found: " + toolName);
    }
    final long subscriptionKey;
    try {
      subscriptionKey = Long.parseLong(toolName.substring(subscriptionKeyIndex + 1));
    } catch (final NumberFormatException e) {
      return Either.left("Tool not found: " + toolName);
    }

    // find the message subscription based on the key
    final var auth = authenticationProvider.getCamundaAuthentication();
    final var entity =
        serviceRegistry
            .messageSubscriptionServices(PhysicalTenantContext.current())
            .getByKey(subscriptionKey, auth);

    if (entity == null) {
      return Either.left("Tool not found: " + toolName);
    }
    if (entity.messageSubscriptionState() == MessageSubscriptionState.DELETED) {
      return Either.left("Tool " + toolName + " has been removed. Please refresh the tool list.");
    }

    return Either.right(entity);
  }

  private @NonNull BiFunction<McpTransportContext, CallToolRequest, CallToolResult>
      buildCallHandler(final MessageSubscriptionEntity entity) {
    final String toolName = entity.toolName();
    return (ctx, req) -> {
      final Map<String, Object> arguments = req.arguments() != null ? req.arguments() : Map.of();
      final String businessId = businessIdFrom(arguments);
      final Map<String, Object> variables = processVariablesFrom(arguments);
      return CallToolResultMapper.from(
          serviceRegistry
              .messageServices(PhysicalTenantContext.current())
              .correlateMessage(
                  new CorrelateMessageRequest(
                      entity.messageName(),
                      // UUID: distribute messages across partitions, support parallel process
                      // instances
                      UUID.randomUUID().toString(),
                      variables,
                      entity.tenantId(),
                      businessId),
                  authenticationProvider.getCamundaAuthentication(),
                  ChannelType.MCP,
                  toolName),
          record -> Map.of("processInstanceKey", record.getProcessInstanceKey()));
    };
  }

  private static String businessIdFrom(final Map<String, Object> arguments) {
    return arguments.get(BUSINESS_ID_ARGUMENT) instanceof final String businessId
            && !businessId.isBlank()
        ? businessId
        : null;
  }

  private static Map<String, Object> processVariablesFrom(final Map<String, Object> arguments) {
    if (!arguments.containsKey(BUSINESS_ID_ARGUMENT)) {
      return arguments;
    }
    // businessId is a reserved tool argument, not a process variable
    final Map<String, Object> variables = new HashMap<>(arguments);
    variables.remove(BUSINESS_ID_ARGUMENT);
    return variables;
  }

  private static Tool buildTool(final MessageSubscriptionEntity entity) {
    final var name = buildToolName(entity);
    final var description = buildDescription(entity.toolProperties());
    return Tool.builder(name, TOOL_INPUT_SCHEMA)
        .title(entity.toolName())
        .description(description)
        .outputSchema(TOOL_OUTPUT_SCHEMA)
        .build();
  }

  private static @NonNull String buildToolName(final MessageSubscriptionEntity entity) {
    return entity.toolName() + TOOL_NAME_DELIMITER + entity.messageSubscriptionKey();
  }

  private static String buildDescription(final Map<String, String> props) {
    return String.join(
        "\n\n",
        DESCRIPTION_PARTS.stream()
            .map(
                part -> {
                  final String value = props.get(part.getLeft());
                  if (value == null || value.isBlank()) {
                    return null;
                  }
                  if (part.getRight().isBlank()) {
                    return value;
                  }
                  return part.getRight() + "\n" + value;
                })
            .filter(Objects::nonNull)
            .toList());
  }
}
