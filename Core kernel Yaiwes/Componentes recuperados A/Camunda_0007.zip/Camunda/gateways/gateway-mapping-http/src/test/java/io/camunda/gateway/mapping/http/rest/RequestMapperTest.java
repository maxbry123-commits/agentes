/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */
package io.camunda.gateway.mapping.http.rest;

import static org.assertj.core.api.Assertions.assertThat;

import io.camunda.gateway.mapping.http.RequestMapper;
import io.camunda.gateway.protocol.model.DeleteResourceRequest;
import io.camunda.gateway.protocol.model.JobActivationRequest;
import io.camunda.gateway.protocol.model.JobChangeset;
import io.camunda.gateway.protocol.model.JobCompletionRequest;
import io.camunda.gateway.protocol.model.JobErrorRequest;
import io.camunda.gateway.protocol.model.JobFailRequest;
import io.camunda.gateway.protocol.model.JobUpdateRequest;
import io.camunda.gateway.protocol.model.TenantFilterEnum;
import io.camunda.service.JobServices.UpdateJobChangeset;
import io.camunda.zeebe.protocol.record.value.TenantFilter;
import java.util.List;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

class RequestMapperTest {

  @Nested
  class ResourceDeletionRequestMappingTest {

    @Test
    void shouldMapResourceDeletionWithMinimalFields() {
      // given
      final long resourceKey = 12345L;

      // when
      final var result = RequestMapper.toResourceDeletion(resourceKey, null);

      // then
      assertThat(result.isRight()).isTrue();
      final var request = result.get();
      assertThat(request.resourceKey()).isEqualTo(12345L);
      assertThat(request.operationReference()).isNull();
      assertThat(request.deleteHistory()).isFalse();
    }

    @Test
    void shouldMapResourceDeletionWithOperationReference() {
      // given
      final long resourceKey = 67890L;
      final var deleteRequest =
          DeleteResourceRequest.Builder.create().operationReference(999L).build();

      // when
      final var result = RequestMapper.toResourceDeletion(resourceKey, deleteRequest);

      // then
      assertThat(result.isRight()).isTrue();
      final var request = result.get();
      assertThat(request.resourceKey()).isEqualTo(67890L);
      assertThat(request.operationReference()).isEqualTo(999L);
      assertThat(request.deleteHistory()).isFalse();
    }

    @Test
    void shouldMapResourceDeletionWithDeleteHistory() {
      // given
      final long resourceKey = 11111L;
      final var deleteRequest = DeleteResourceRequest.Builder.create().deleteHistory(true).build();

      // when
      final var result = RequestMapper.toResourceDeletion(resourceKey, deleteRequest);

      // then
      assertThat(result.isRight()).isTrue();
      final var request = result.get();
      assertThat(request.resourceKey()).isEqualTo(11111L);
      assertThat(request.operationReference()).isNull();
      assertThat(request.deleteHistory()).isTrue();
    }

    @Test
    void shouldMapResourceDeletionWithAllFields() {
      // given
      final long resourceKey = 22222L;
      final var deleteRequest =
          DeleteResourceRequest.Builder.create()
              .operationReference(555L)
              .deleteHistory(true)
              .build();

      // when
      final var result = RequestMapper.toResourceDeletion(resourceKey, deleteRequest);

      // then
      assertThat(result.isRight()).isTrue();
      final var request = result.get();
      assertThat(request.resourceKey()).isEqualTo(22222L);
      assertThat(request.operationReference()).isEqualTo(555L);
      assertThat(request.deleteHistory()).isTrue();
    }

    @Test
    void shouldMapResourceDeletionWithDeleteHistoryFalse() {
      // given
      final long resourceKey = 33333L;
      final var deleteRequest = DeleteResourceRequest.Builder.create().deleteHistory(false).build();

      // when
      final var result = RequestMapper.toResourceDeletion(resourceKey, deleteRequest);

      // then
      assertThat(result.isRight()).isTrue();
      final var request = result.get();
      assertThat(request.resourceKey()).isEqualTo(33333L);
      assertThat(request.operationReference()).isNull();
      assertThat(request.deleteHistory()).isFalse();
    }

    @Test
    void shouldRejectResourceDeletionWithInvalidOperationReference() {
      // given
      final long resourceKey = 44444L;
      final var deleteRequest =
          DeleteResourceRequest.Builder.create().operationReference(0L).build();

      // when
      final var result = RequestMapper.toResourceDeletion(resourceKey, deleteRequest);

      // then
      assertThat(result.isLeft()).isTrue();
      final var problemDetail = result.getLeft();
      assertThat(problemDetail.getStatus()).isEqualTo(400);
      assertThat(problemDetail.getDetail()).contains("operationReference");
      assertThat(problemDetail.getDetail()).contains("> 0");
    }
  }

  @Nested
  class JobActivationRequestMappingTest {

    @Test
    void shouldMapJobActivationWithProvidedTenantFilterAndTenantIds() {
      // given
      final var request =
          JobActivationRequest.Builder.create()
              .type("test-job")
              .maxJobsToActivate(10)
              .timeout(5000L)
              .tenantIds(List.of("tenant-a", "tenant-b"))
              .build();
      // when
      final var result = RequestMapper.toJobsActivationRequest(request, true);

      // then
      assertThat(result.isRight()).isTrue();
      final var activateJobsRequest = result.get();
      assertThat(activateJobsRequest.type()).isEqualTo("test-job");
      assertThat(activateJobsRequest.maxJobsToActivate()).isEqualTo(10);
      assertThat(activateJobsRequest.timeout()).isEqualTo(5000L);
      assertThat(activateJobsRequest.tenantIds()).containsExactly("tenant-a", "tenant-b");
      assertThat(activateJobsRequest.tenantFilter()).isEqualTo(TenantFilter.PROVIDED);
    }

    @Test
    void shouldMapJobActivationWithLease() {
      // given
      final var request =
          JobActivationRequest.Builder.create()
              .type("test-job")
              .maxJobsToActivate(10)
              .timeout(5000L)
              .tenantIds(List.of("tenant-a"))
              .withLease(true)
              .build();

      // when
      final var result = RequestMapper.toJobsActivationRequest(request, true);

      // then
      assertThat(result.isRight()).isTrue();
      assertThat(result.get().withLease()).isTrue();
    }

    @Test
    void shouldNotSetWithLeaseByDefault() {
      // given
      final var request =
          JobActivationRequest.Builder.create()
              .type("test-job")
              .maxJobsToActivate(10)
              .timeout(5000L)
              .tenantIds(List.of("tenant-a"))
              .build();

      // when
      final var result = RequestMapper.toJobsActivationRequest(request, true);

      // then
      assertThat(result.isRight()).isTrue();
      assertThat(result.get().withLease()).isFalse();
    }

    @Test
    void shouldMapJobActivationWithAssignedTenantFilterAndNoTenantIds() {
      // given
      final var request =
          JobActivationRequest.Builder.create()
              .type("test-job")
              .maxJobsToActivate(5)
              .timeout(3000L)
              .tenantFilter(TenantFilterEnum.ASSIGNED)
              .build();

      // when
      final var result = RequestMapper.toJobsActivationRequest(request, true);

      // then
      assertThat(result.isRight()).isTrue();
      final var activateJobsRequest = result.get();
      assertThat(activateJobsRequest.type()).isEqualTo("test-job");
      assertThat(activateJobsRequest.tenantIds())
          .describedAs("With ASSIGNED filter, tenant IDs should be empty")
          .isEmpty();
      assertThat(activateJobsRequest.tenantFilter()).isEqualTo(TenantFilter.ASSIGNED);
    }

    @Test
    void shouldIgnoreTenantIdsWhenAssignedTenantFilterIsUsed() {
      // given
      final var request =
          JobActivationRequest.Builder.create()
              .type("test-job")
              .maxJobsToActivate(5)
              .timeout(3000L)
              .tenantIds(List.of("tenant-a", "tenant-b"))
              .tenantFilter(TenantFilterEnum.ASSIGNED)
              .build();
      // when
      final var result = RequestMapper.toJobsActivationRequest(request, true);

      // then
      assertThat(result.isRight()).isTrue();
      final var activateJobsRequest = result.get();
      assertThat(activateJobsRequest.tenantIds())
          .describedAs(
              "Provided tenant IDs should be ignored when ASSIGNED filter is used. "
                  + "Tenant IDs will be determined from authorized tenants instead.")
          .isEmpty();
      assertThat(activateJobsRequest.tenantFilter()).isEqualTo(TenantFilter.ASSIGNED);
    }

    @Test
    void shouldRejectProvidedFilterWithoutTenantIdsWhenMultiTenancyEnabled() {
      // given
      final var request =
          JobActivationRequest.Builder.create()
              .type("test-job")
              .maxJobsToActivate(10)
              .timeout(5000L)
              .build();

      // when
      final var result = RequestMapper.toJobsActivationRequest(request, true);

      // then
      assertThat(result.isLeft()).isTrue();
      final var problemDetail = result.getLeft();
      assertThat(problemDetail.getStatus()).isEqualTo(400);
      assertThat(problemDetail.getDetail()).contains("Activate Jobs");
      assertThat(problemDetail.getDetail()).contains("no tenant identifier");
    }

    @Test
    void shouldDefaultToProvidedTenantFilterWhenNotSpecified() {
      // given
      final var request =
          JobActivationRequest.Builder.create()
              .type("test-job")
              .maxJobsToActivate(10)
              .timeout(5000L)
              .tenantIds(List.of("tenant-a"))
              .build();

      // when
      final var result = RequestMapper.toJobsActivationRequest(request, true);

      // then
      assertThat(result.isRight()).isTrue();
      final var activateJobsRequest = result.get();
      assertThat(activateJobsRequest.tenantFilter())
          .describedAs("When no tenant filter is specified, it should default to PROVIDED")
          .isEqualTo(TenantFilter.PROVIDED);
      assertThat(activateJobsRequest.tenantIds()).containsExactly("tenant-a");
    }

    @Test
    void shouldMapJobActivationWithDefaultTenantWhenMultiTenancyDisabled() {
      // given
      final var request =
          JobActivationRequest.Builder.create()
              .type("test-job")
              .maxJobsToActivate(5)
              .timeout(3000L)
              .worker("test-worker")
              .build();

      // when
      final var result = RequestMapper.toJobsActivationRequest(request, false);

      // then
      assertThat(result.isRight()).isTrue();
      final var activateJobsRequest = result.get();
      assertThat(activateJobsRequest.tenantIds())
          .describedAs(
              "When multi-tenancy is disabled, default tenant ID should be automatically added")
          .containsExactly("<default>");
      assertThat(activateJobsRequest.tenantFilter()).isEqualTo(TenantFilter.PROVIDED);
    }

    @Test
    void shouldRejectNonDefaultTenantIdWhenMultiTenancyDisabled() {
      // given - tenant ID provided when multi-tenancy is disabled
      final var request =
          JobActivationRequest.Builder.create()
              .type("test-job")
              .maxJobsToActivate(10)
              .timeout(5000L)
              .tenantIds(List.of("tenant-a"))
              .build();

      // when
      final var result = RequestMapper.toJobsActivationRequest(request, false);

      // then
      assertThat(result.isLeft()).isTrue();
      final var problemDetail = result.getLeft();
      assertThat(problemDetail.getStatus()).isEqualTo(400);
      assertThat(problemDetail.getDetail()).contains("multi-tenancy is disabled");
    }

    @Test
    void shouldMapJobActivationWithAllFields() {
      // given
      final var request =
          JobActivationRequest.Builder.create()
              .type("complex-job")
              .maxJobsToActivate(15)
              .timeout(10000L)
              .worker("worker-123")
              .requestTimeout(30000L)
              .fetchVariable(List.of("var1", "var2"))
              .tenantIds(List.of("tenant-a"))
              .build();

      // when
      final var result = RequestMapper.toJobsActivationRequest(request, true);

      // then
      assertThat(result.isRight()).isTrue();
      final var activateJobsRequest = result.get();
      assertThat(activateJobsRequest.type()).isEqualTo("complex-job");
      assertThat(activateJobsRequest.maxJobsToActivate()).isEqualTo(15);
      assertThat(activateJobsRequest.timeout()).isEqualTo(10000L);
      assertThat(activateJobsRequest.worker()).isEqualTo("worker-123");
      assertThat(activateJobsRequest.requestTimeout()).isEqualTo(30000L);
      assertThat(activateJobsRequest.fetchVariable()).containsExactly("var1", "var2");
      assertThat(activateJobsRequest.tenantIds()).containsExactly("tenant-a");
    }

    @Test
    void shouldRejectJobActivationWithInvalidType() {
      // given - request with empty type
      final var request =
          JobActivationRequest.Builder.create()
              .type("")
              .maxJobsToActivate(10)
              .timeout(5000L)
              .tenantIds(List.of("tenant-a"))
              .build();

      // when
      final var result = RequestMapper.toJobsActivationRequest(request, true);

      // then
      assertThat(result.isLeft()).isTrue();
      final var problemDetail = result.getLeft();
      assertThat(problemDetail.getStatus()).isEqualTo(400);
      assertThat(problemDetail.getDetail()).contains("type");
    }

    @Test
    void shouldRejectJobActivationWithInvalidMaxJobsToActivate() {
      // given - request with invalid maxJobsToActivate
      final var request =
          JobActivationRequest.Builder.create()
              .type("test-job")
              .maxJobsToActivate(0)
              .timeout(5000L)
              .tenantIds(List.of("tenant-a"))
              .build();

      // when
      final var result = RequestMapper.toJobsActivationRequest(request, true);

      // then
      assertThat(result.isLeft()).isTrue();
      final var problemDetail = result.getLeft();
      assertThat(problemDetail.getStatus()).isEqualTo(400);
      assertThat(problemDetail.getDetail()).contains("maxJobsToActivate");
    }

    @Test
    void shouldRejectJobActivationWithInvalidTimeout() {
      // given - request with invalid timeout
      final var request =
          JobActivationRequest.Builder.create()
              .type("test-job")
              .maxJobsToActivate(10)
              .timeout(0L)
              .tenantIds(List.of("tenant-a"))
              .build();

      // when
      final var result = RequestMapper.toJobsActivationRequest(request, true);

      // then
      assertThat(result.isLeft()).isTrue();
      final var problemDetail = result.getLeft();
      assertThat(problemDetail.getStatus()).isEqualTo(400);
      assertThat(problemDetail.getDetail()).contains("timeout");
    }

    @Test
    void shouldMapJobActivationWithMultipleTenantIds() {
      // given
      final var request =
          JobActivationRequest.Builder.create()
              .type("test-job")
              .maxJobsToActivate(10)
              .timeout(5000L)
              .tenantIds(List.of("tenant-a", "tenant-b", "tenant-c"))
              .build();

      // when
      final var result = RequestMapper.toJobsActivationRequest(request, true);

      // then
      assertThat(result.isRight()).isTrue();
      final var activateJobsRequest = result.get();
      assertThat(activateJobsRequest.tenantIds())
          .containsExactly("tenant-a", "tenant-b", "tenant-c");
    }

    @Test
    void shouldRejectAssignedTenantFilterWhenMultiTenancyDisabled() {
      // given
      final var request =
          JobActivationRequest.Builder.create()
              .type("test-job")
              .maxJobsToActivate(10)
              .timeout(5000L)
              .tenantFilter(TenantFilterEnum.ASSIGNED)
              .build();

      // when
      final var result = RequestMapper.toJobsActivationRequest(request, false);

      // then
      assertThat(result.isLeft()).isTrue();
      final var problemDetail = result.getLeft();
      assertThat(problemDetail.getStatus()).isEqualTo(400);
      assertThat(problemDetail.getDetail())
          .contains("ASSIGNED tenant filter")
          .contains("multi-tenancy is disabled");
    }
  }

  @Nested
  class JobUpdateRequestMappingTest {

    @Test
    void shouldMapPriorityToChangeset() {
      // given
      final var changeset = JobChangeset.Builder.create().priority(80).build();
      final var request = JobUpdateRequest.Builder.create().changeset(changeset).build();

      // when
      final var result = RequestMapper.toJobUpdateRequest(request, 1L);

      // then
      assertThat(result.isRight()).isTrue();
      assertThat(result.get().changeset()).isEqualTo(new UpdateJobChangeset(null, null, 80));
    }

    @Test
    void shouldMapNullPriorityWhenNotProvided() {
      // given
      final var changeset = JobChangeset.Builder.create().retries(3).build();
      final var request = JobUpdateRequest.Builder.create().changeset(changeset).build();

      // when
      final var result = RequestMapper.toJobUpdateRequest(request, 1L);

      // then
      assertThat(result.isRight()).isTrue();
      assertThat(result.get().changeset()).isEqualTo(new UpdateJobChangeset(3, null, null));
    }

    @Test
    @SuppressWarnings("NullAway")
    void shouldRejectWhenChangesetIsNull() {
      // given
      final var request = JobUpdateRequest.Builder.create().changeset(null).build();

      // when
      final var result = RequestMapper.toJobUpdateRequest(request, 1L);

      // then
      assertThat(result.isLeft()).isTrue();
      assertThat(result.getLeft().getStatus()).isEqualTo(400);
    }

    @Test
    void shouldRejectWhenAllChangesetFieldsAreNull() {
      // given
      final var changeset = JobChangeset.Builder.create().build();
      final var request = JobUpdateRequest.Builder.create().changeset(changeset).build();

      // when
      final var result = RequestMapper.toJobUpdateRequest(request, 1L);

      // then
      assertThat(result.isLeft()).isTrue();
      assertThat(result.getLeft().getStatus()).isEqualTo(400);
      assertThat(result.getLeft().getDetail()).contains("retries", "timeout", "priority");
    }
  }

  @Nested
  class LeaseTokenMappingTest {

    @Test
    void shouldMapLeaseTokenOnJobCompletion() {
      // given
      final var request = JobCompletionRequest.Builder.create().leaseToken("lease-1").build();

      // when
      final var result = RequestMapper.toJobCompletionRequest(request, 1L);

      // then
      assertThat(result.get().leaseToken()).isEqualTo("lease-1");
    }

    @Test
    void shouldMapAbsentLeaseTokenOnJobCompletion() {
      // given
      final var request = JobCompletionRequest.Builder.create().build();

      // when
      final var result = RequestMapper.toJobCompletionRequest(request, 1L);

      // then
      assertThat(result.get().leaseToken()).isNull();
    }

    @Test
    void shouldMapBusinessIdOnJobCompletion() {
      // given
      final var request = JobCompletionRequest.Builder.create().businessId("biz-1").build();

      // when
      final var result = RequestMapper.toJobCompletionRequest(request, 1L);

      // then
      assertThat(result.get().businessId()).isEqualTo("biz-1");
    }

    @Test
    void shouldMapAbsentBusinessIdOnJobCompletion() {
      // given
      final var request = JobCompletionRequest.Builder.create().build();

      // when
      final var result = RequestMapper.toJobCompletionRequest(request, 1L);

      // then
      assertThat(result.get().businessId()).isNull();
    }

    @Test
    void shouldRejectEmptyBusinessIdOnJobCompletion() {
      // given
      final var request = JobCompletionRequest.Builder.create().businessId("").build();

      // when
      final var result = RequestMapper.toJobCompletionRequest(request, 1L);

      // then
      assertThat(result.isLeft()).isTrue();
      final var problemDetail = result.getLeft();
      assertThat(problemDetail.getStatus()).isEqualTo(400);
      assertThat(problemDetail.getDetail()).contains("businessId");
    }

    @Test
    void shouldRejectBlankBusinessIdOnJobCompletion() {
      // given
      final var request = JobCompletionRequest.Builder.create().businessId("   ").build();

      // when
      final var result = RequestMapper.toJobCompletionRequest(request, 1L);

      // then
      assertThat(result.isLeft()).isTrue();
      final var problemDetail = result.getLeft();
      assertThat(problemDetail.getStatus()).isEqualTo(400);
      assertThat(problemDetail.getDetail()).contains("businessId");
    }

    @Test
    void shouldMapLeaseTokenOnJobFail() {
      // given
      final var request = JobFailRequest.Builder.create().leaseToken("lease-1").build();

      // when
      final var result = RequestMapper.toJobFailRequest(request, 1L);

      // then
      assertThat(result.leaseToken()).isEqualTo("lease-1");
    }

    @Test
    void shouldMapAbsentLeaseTokenOnJobFail() {
      // given
      final var request = JobFailRequest.Builder.create().build();

      // when
      final var result = RequestMapper.toJobFailRequest(request, 1L);

      // then
      assertThat(result.leaseToken()).isNull();
    }

    @Test
    void shouldMapLeaseTokenOnJobError() {
      // given
      final var request =
          JobErrorRequest.Builder.create().errorCode("error-1").leaseToken("lease-1").build();

      // when
      final var result = RequestMapper.toJobErrorRequest(request, 1L);

      // then
      assertThat(result.isRight()).isTrue();
      assertThat(result.get().leaseToken()).isEqualTo("lease-1");
    }

    @Test
    void shouldMapAbsentLeaseTokenOnJobError() {
      // given
      final var request = JobErrorRequest.Builder.create().errorCode("error-1").build();

      // when
      final var result = RequestMapper.toJobErrorRequest(request, 1L);

      // then
      assertThat(result.isRight()).isTrue();
      assertThat(result.get().leaseToken()).isNull();
    }

    @Test
    void shouldMapLeaseTokenOnJobUpdate() {
      // given
      final var changeset = JobChangeset.Builder.create().priority(80).build();
      final var request =
          JobUpdateRequest.Builder.create().changeset(changeset).leaseToken("lease-1").build();

      // when
      final var result = RequestMapper.toJobUpdateRequest(request, 1L);

      // then
      assertThat(result.isRight()).isTrue();
      assertThat(result.get().leaseToken()).isEqualTo("lease-1");
    }

    @Test
    void shouldMapAbsentLeaseTokenOnJobUpdate() {
      // given
      final var changeset = JobChangeset.Builder.create().priority(80).build();
      final var request = JobUpdateRequest.Builder.create().changeset(changeset).build();

      // when
      final var result = RequestMapper.toJobUpdateRequest(request, 1L);

      // then
      assertThat(result.isRight()).isTrue();
      assertThat(result.get().leaseToken()).isNull();
    }
  }
}
