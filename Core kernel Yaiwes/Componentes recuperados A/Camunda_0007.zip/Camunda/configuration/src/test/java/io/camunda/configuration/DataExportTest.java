/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */
package io.camunda.configuration;

import static org.assertj.core.api.Assertions.assertThat;

import io.camunda.configuration.beanoverrides.BrokerBasedPropertiesOverride;
import io.camunda.configuration.beans.BrokerBasedProperties;
import java.time.Duration;
import java.util.Set;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit.jupiter.SpringJUnitConfig;

@SpringJUnitConfig({
  UnifiedConfiguration.class,
  BrokerBasedPropertiesOverride.class,
  UnifiedConfigurationHelper.class
})
@ActiveProfiles("broker")
public class DataExportTest {
  @Nested
  @TestPropertySource(
      properties = {
        "camunda.data.export.distribution-interval=1m",
      })
  class WithOnlyUnifiedConfigSet {
    final BrokerBasedProperties brokerCfg;

    WithOnlyUnifiedConfigSet(@Autowired final BrokerBasedProperties brokerCfg) {
      this.brokerCfg = brokerCfg;
    }

    @Test
    void shouldSetDistributionInterval() {
      assertThat(brokerCfg.getExporting().distributionInterval()).isEqualTo(Duration.ofMinutes(1));
    }
  }

  @Nested
  @TestPropertySource(
      properties = {
        "zeebe.broker.exporting.distributionInterval=2m",
      })
  class WithOnlyLegacySet {
    final BrokerBasedProperties brokerCfg;

    WithOnlyLegacySet(@Autowired final BrokerBasedProperties brokerCfg) {
      this.brokerCfg = brokerCfg;
    }

    @Test
    void shouldSetDistributionInterval() {
      assertThat(brokerCfg.getExporting().distributionInterval()).isEqualTo(Duration.ofMinutes(2));
    }
  }

  @Nested
  @TestPropertySource(
      properties = {
        // new
        "camunda.data.export.distribution-interval=1m",
        // legacy
        "zeebe.broker.exporting.distributionInterval=2m",
      })
  class WithNewAndLegacySet {
    final BrokerBasedProperties brokerCfg;

    WithNewAndLegacySet(@Autowired final BrokerBasedProperties brokerCfg) {
      this.brokerCfg = brokerCfg;
    }

    @Test
    void shouldSetDistributionIntervalFromNew() {
      assertThat(brokerCfg.getExporting().distributionInterval()).isEqualTo(Duration.ofMinutes(1));
    }
  }

  @Nested
  @TestPropertySource(
      properties = {
        "camunda.data.export.skip-records.1=10,20",
        "camunda.data.export.skip-records.2=30",
      })
  class WithPerPartitionSkipRecordsSet {
    final BrokerBasedProperties brokerCfg;

    WithPerPartitionSkipRecordsSet(@Autowired final BrokerBasedProperties brokerCfg) {
      this.brokerCfg = brokerCfg;
    }

    @Test
    void shouldSetSkipRecordsForPartition1() {
      assertThat(brokerCfg.getExporting().skipRecords()).containsEntry(1, Set.of(10L, 20L));
    }

    @Test
    void shouldSetSkipRecordsForPartition2() {
      assertThat(brokerCfg.getExporting().skipRecords()).containsEntry(2, Set.of(30L));
    }
  }
}
