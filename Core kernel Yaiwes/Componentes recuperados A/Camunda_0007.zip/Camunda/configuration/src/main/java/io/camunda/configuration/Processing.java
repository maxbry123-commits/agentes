/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */
package io.camunda.configuration;

import io.camunda.configuration.UnifiedConfigurationHelper.BackwardsCompatibilityMode;
import java.time.Duration;
import java.util.Set;
import org.springframework.boot.context.properties.NestedConfigurationProperty;
import org.springframework.core.ResolvableType;

public class Processing {
  private static final String PREFIX = "camunda.processing";
  private static final int DEFAULT_PROCESSING_BATCH_LIMIT = 100;
  private static final Duration DEFAULT_SCHEDULED_TASKS_CHECK_INTERVAL = Duration.ofSeconds(1);

  private static final boolean DEFAULT_ENABLE_PRECONDITIONS_CHECK = false;
  private static final boolean DEFAULT_ENABLE_FOREIGN_KEY_CHECKS = false;

  private static final boolean DEFAULT_ENABLE_YIELDING_DUEDATE_CHECKER = true;
  private static final boolean DEFAULT_ENABLE_ASYNC_MESSAGE_TTL_CHECKER = false;
  private static final boolean DEFAULT_ENABLE_ASYNC_TIMER_DUEDATE_CHECKER = false;
  private static final boolean DEFAULT_ENABLE_STRAIGHTTHROUGH_PROCESSING_LOOP_DETECTOR = true;
  private static final boolean DEFAULT_ENABLE_MESSAGE_BODY_ON_EXPIRED = false;
  private static final boolean DEFAULT_EVALUATE_BOUNDARY_EVENT_CORRELATION_KEY_IN_ACTIVITY_SCOPE =
      true;

  private static final int DEFAULT_MAX_RECOVERABLE_RETRIES = 1000;
  private static final int DEFAULT_MAX_PENDING_SIDE_EFFECTS = 1000;

  private static final Set<String> LEGACY_MAX_COMMANDS_IN_BATCH_PROPERTIES =
      Set.of("zeebe.broker.processingCfg.maxCommandsInBatch");
  private static final Set<String> LEGACY_SCHEDULED_TASKS_CHECK_INTERVAL_PROPERTIES =
      Set.of("zeebe.broker.processingCfg.scheduledTaskCheckInterval");
  private static final Set<String> LEGACY_SKIP_POSITIONS_PROPERTIES =
      Set.of("zeebe.broker.processingCfg.skipPositions");

  private static final Set<String> LEGACY_CONSISTENCY_CHECK_ENABLE_PRECONDITIONS_PROPERTIES =
      Set.of("zeebe.broker.experimental.consistencyChecks.enablePreconditions");
  private static final Set<String> LEGACY_CONSISTENCY_CHECK_ENABLE_FOREIGN_KEY_CHECKS_PROPERTIES =
      Set.of("zeebe.broker.experimental.consistencyChecks.enableForeignKeyChecks");

  private static final Set<String> LEGACY_FEATURES_ENABLE_YIELD_DUEDATE_CHECKER_PROPERTIES =
      Set.of("zeebe.broker.experimental.features.enableYieldingDueDateChecker");
  private static final Set<String> LEGACY_FEATURES_ENABLE_MESSAGE_TTL_CHECKER_ASYNC_PROPERTIES =
      Set.of("zeebe.broker.experimental.features.enableMessageTtlCheckerAsync");
  private static final Set<String> LEGACY_FEATURES_ENABLE_TIMER_DUE_DATE_CHECKER_ASYNC_PROPERTIES =
      Set.of("zeebe.broker.experimental.features.enableTimerDueDateCheckerAsync");
  private static final Set<String>
      LEGACY_FEATURES_ENABLE_STRAIGHT_THROUGH_PROCESSING_LOOP_DETECTOR_PROPERTIES =
          Set.of("zeebe.broker.experimental.features.enableStraightThroughProcessingLoopDetector");
  private static final Set<String> LEGACY_FEATURES_ENABLE_MESSAGE_BODY_ON_EXPIRED_PROPERTIES =
      Set.of("zeebe.broker.experimental.features.enableMessageBodyOnExpired");
  private static final Set<String>
      LEGACY_FEATURES_EVALUATE_BOUNDARY_EVENT_CORRELATION_KEY_IN_ACTIVITY_SCOPE_PROPERTIES =
          Set.of(
              "zeebe.broker.experimental.features.evaluateBoundaryEventCorrelationKeyInActivityScope");

  /**
   * Configure flow control for user requests. This setting takes precedence over the backpressure
   * configuration.
   */
  @NestedConfigurationProperty FlowControl flowControl = new FlowControl();

  /** Configuration properties for the engine. */
  @NestedConfigurationProperty Engine engine = new Engine();

  /**
   * Sets the maximum number of commands that processed within one batch. The processor will process
   * until no more follow up commands are created by the initial command or the configured limit is
   * reached. By default, up to 100 commands are processed in one batch. Can be set to 1 to disable
   * batch processing. Must be a positive integer number. Note that the resulting batch size will
   * contain more entries than this limit because it includes follow up events. When resulting batch
   * size is too large (see maxMessageSize), processing will be rolled back and retried with a
   * smaller maximum batch size. Lowering the command limit can reduce the frequency of rollback and
   * retry.
   */
  private Integer maxCommandsInBatch = DEFAULT_PROCESSING_BATCH_LIMIT;

  /**
   * Configures the rate at which a partition leader checks for expired scheduled tasks such as the
   * due date checker. The default value is 1 second. Use a lower interval to potentially decrease
   * delays between requested and actual execution of scheduled tasks. Using a low interval will
   * result in unnecessary load while idle. We recommend to benchmark any changes to this setting.
   */
  private Duration scheduledTasksCheckInterval = DEFAULT_SCHEDULED_TASKS_CHECK_INTERVAL;

  /**
   * Allows to skip certain commands by their position. This is useful for debugging and data
   * recovery. It is not recommended to use this in production. The value is a comma-separated list
   * of positions to skip. Whitespace is ignored.
   */
  private Set<Long> skipPositions;

  /**
   * Configures if the basic operations on RocksDB, such as inserting or deleting key-value pairs,
   * should check preconditions, for example that a key does not already exist when inserting.
   */
  private boolean enablePreconditionsCheck = DEFAULT_ENABLE_PRECONDITIONS_CHECK;

  /**
   * Configures if inserting or updating key-value pairs on RocksDB should check that foreign keys
   * exist.
   */
  private boolean enableForeignKeyChecks = DEFAULT_ENABLE_FOREIGN_KEY_CHECKS;

  /**
   * Changes the DueDateTimerCheckScheduler to give yield to other processing steps in situations
   * where it has many (i.e. millions of) timers to process. If set to false (default) the
   * DueDateTimerCheckScheduler will activate all due timers. In the worst case, this can lead to
   * the node being blocked for indefinite amount of time, being subsequently flagged as unhealthy.
   * Currently, there is no known way to recover from this situation If set to true, the
   * DueDateTimerCheckScheduler will give yield to other processing steps. This avoids the worst
   * case described above. However, under consistent high load it may happen that the activated
   * timers will fall behind real time, if more timers become due than can be activated during a
   * certain time period.
   */
  private boolean enableYieldingDueDateChecker = DEFAULT_ENABLE_YIELDING_DUEDATE_CHECKER;

  /**
   * While disabled, checking the Time-To-Live of buffered messages blocks all other executions that
   * occur on the stream processor, including process execution and job activation/completion. When
   * enabled, the Message TTL Checker will run asynchronous to the Engine's stream processor. This
   * helps improve throughput and process latency in use cases that publish many messages with a
   * non-zero TTL. We recommend testing this feature in a non-production environment before enabling
   * it in production.
   */
  private boolean enableAsyncMessageTtlChecker = DEFAULT_ENABLE_ASYNC_MESSAGE_TTL_CHECKER;

  /**
   * While disabled, checking for due timers blocks all other executions that occur on the stream
   * processor, including process execution and job activation/completion. When enabled, the Due
   * Date Checker will run asynchronous to the Engine's stream processor. This helps improve
   * throughput and process latency when there are a lot of timers. We recommend testing this
   * feature in a non-production environment before enabling it in production.
   */
  private boolean enableAsyncTimerDuedateChecker = DEFAULT_ENABLE_ASYNC_TIMER_DUEDATE_CHECKER;

  private boolean enableStraightthroughProcessingLoopDetector =
      DEFAULT_ENABLE_STRAIGHTTHROUGH_PROCESSING_LOOP_DETECTOR;

  /**
   * Controls whether the full message body is included in the follow-up event when a message
   * expires. When enabled, the system appends the entire message payload during expiration. This is
   * useful in environments where full visibility into expired messages is needed. Such that full
   * message details can be exported by configuring the exporter filtering to allow
   * `Message.EXPIRED` events. However, including the full message body increases the size of each
   * follow-up event. For large messages (e.g., ~100KB), this may lead to batch size limits being
   * exceeded earlier. As a result, fewer messages may be expired per batch (e.g., only 40 instead
   * of more), which requires multiple checker runs to process the full batch. Please be aware that
   * this may introduce performance regressions or cause the expired message state to grow more
   * quickly over time. To maintain backward compatibility and avoid performance degradation, the
   * default value is false, meaning message bodies will not be appended unless explicitly enabled.
   */
  private boolean enableMessageBodyOnExpired = DEFAULT_ENABLE_MESSAGE_BODY_ON_EXPIRED;

  /**
   * Controls the scope used to evaluate the {@code correlationKey} expression of a message boundary
   * event. When enabled (default), the expression is evaluated in the activity's own (element
   * instance) scope, consistent with timer duration, message name, and signal name expressions.
   * When disabled, restores the previous behavior where the expression is evaluated in the flow
   * scope instead.
   */
  private boolean evaluateBoundaryEventCorrelationKeyInActivityScope =
      DEFAULT_EVALUATE_BOUNDARY_EVENT_CORRELATION_KEY_IN_ACTIVITY_SCOPE;

  /**
   * Sets the maximum number of recoverable retries for state update and replay operations. When the
   * limit is reached, the operation fails and the partition restarts. Must be a positive integer.
   * Default is 1000.
   */
  private int maxRecoverableRetries = DEFAULT_MAX_RECOVERABLE_RETRIES;

  /**
   * Sets how many processed records may wait for their side effects to be committed before
   * processing stops reading new records. Processing reads records as soon as they are appended,
   * while a record's side effects, such as command responses, only run once its results are
   * committed. This limit bounds the memory those waiting side effects retain when commits are
   * slow. It is a safety valve rather than a tuning knob: the default sits far above the number of
   * records processed within one commit round trip, so it should not be reached in normal
   * operation. Raise it only to trade memory for throughput on a partition whose commit latency is
   * genuinely high. Must be a positive integer. Default is 1000.
   */
  private int maxPendingSideEffects = DEFAULT_MAX_PENDING_SIDE_EFFECTS;

  public Integer getMaxCommandsInBatch() {
    return UnifiedConfigurationHelper.validateLegacyConfigurationUnsafe(
        PREFIX + ".max-commands-in-batch",
        maxCommandsInBatch,
        Integer.class,
        BackwardsCompatibilityMode.SUPPORTED,
        LEGACY_MAX_COMMANDS_IN_BATCH_PROPERTIES);
  }

  public void setMaxCommandsInBatch(final Integer maxCommandsInBatch) {
    this.maxCommandsInBatch = maxCommandsInBatch;
  }

  public Duration getScheduledTasksCheckInterval() {
    return UnifiedConfigurationHelper.validateLegacyConfigurationUnsafe(
        PREFIX + ".scheduled-tasks-check-interval",
        scheduledTasksCheckInterval,
        Duration.class,
        BackwardsCompatibilityMode.SUPPORTED,
        LEGACY_SCHEDULED_TASKS_CHECK_INTERVAL_PROPERTIES);
  }

  public void setScheduledTasksCheckInterval(final Duration scheduledTasksCheckInterval) {
    this.scheduledTasksCheckInterval = scheduledTasksCheckInterval;
  }

  public Set<Long> getSkipPositions() {
    return UnifiedConfigurationHelper.validateLegacyConfigurationUnsafe(
        PREFIX + ".skip-positions",
        skipPositions,
        ResolvableType.forClassWithGenerics(Set.class, Long.class),
        BackwardsCompatibilityMode.SUPPORTED,
        LEGACY_SKIP_POSITIONS_PROPERTIES);
  }

  public void setSkipPositions(final Set<Long> skipPositions) {
    this.skipPositions = skipPositions;
  }

  public Engine getEngine() {
    return engine;
  }

  public void setEngine(final Engine engine) {
    this.engine = engine;
  }

  public boolean isEnablePreconditionsCheck() {
    return UnifiedConfigurationHelper.validateLegacyConfigurationUnsafe(
        PREFIX + ".enable-preconditions-check",
        enablePreconditionsCheck,
        Boolean.class,
        BackwardsCompatibilityMode.SUPPORTED,
        LEGACY_CONSISTENCY_CHECK_ENABLE_PRECONDITIONS_PROPERTIES);
  }

  public void setEnablePreconditionsCheck(final boolean enablePreconditionsCheck) {
    this.enablePreconditionsCheck = enablePreconditionsCheck;
  }

  public boolean isEnableForeignKeyChecks() {
    return UnifiedConfigurationHelper.validateLegacyConfigurationUnsafe(
        PREFIX + ".enable-foreign-key-checks",
        enableForeignKeyChecks,
        Boolean.class,
        BackwardsCompatibilityMode.SUPPORTED,
        LEGACY_CONSISTENCY_CHECK_ENABLE_FOREIGN_KEY_CHECKS_PROPERTIES);
  }

  public void setEnableForeignKeyChecks(final boolean enableForeignKeyChecks) {
    this.enableForeignKeyChecks = enableForeignKeyChecks;
  }

  public boolean isEnableYieldingDueDateChecker() {
    return UnifiedConfigurationHelper.validateLegacyConfigurationUnsafe(
        PREFIX + ".enable-yielding-duedate-checker",
        enableYieldingDueDateChecker,
        Boolean.class,
        BackwardsCompatibilityMode.SUPPORTED,
        LEGACY_FEATURES_ENABLE_YIELD_DUEDATE_CHECKER_PROPERTIES);
  }

  public void setEnableYieldingDueDateChecker(final boolean enableYieldingDueDateChecker) {
    this.enableYieldingDueDateChecker = enableYieldingDueDateChecker;
  }

  public boolean isEnableAsyncMessageTtlChecker() {
    return UnifiedConfigurationHelper.validateLegacyConfigurationUnsafe(
        PREFIX + ".enable-async-message-ttl-checker",
        enableAsyncMessageTtlChecker,
        Boolean.class,
        BackwardsCompatibilityMode.SUPPORTED,
        LEGACY_FEATURES_ENABLE_MESSAGE_TTL_CHECKER_ASYNC_PROPERTIES);
  }

  public void setEnableAsyncMessageTtlChecker(final boolean enableAsyncMessageTtlChecker) {
    this.enableAsyncMessageTtlChecker = enableAsyncMessageTtlChecker;
  }

  public boolean isEnableAsyncTimerDuedateChecker() {
    return UnifiedConfigurationHelper.validateLegacyConfigurationUnsafe(
        PREFIX + ".enable-async-timer-duedate-checker",
        enableAsyncTimerDuedateChecker,
        Boolean.class,
        BackwardsCompatibilityMode.SUPPORTED,
        LEGACY_FEATURES_ENABLE_TIMER_DUE_DATE_CHECKER_ASYNC_PROPERTIES);
  }

  public void setEnableAsyncTimerDuedateChecker(final boolean enableAsyncTimerDuedateChecker) {
    this.enableAsyncTimerDuedateChecker = enableAsyncTimerDuedateChecker;
  }

  public boolean isEnableStraightthroughProcessingLoopDetector() {
    return UnifiedConfigurationHelper.validateLegacyConfigurationUnsafe(
        PREFIX + ".enable-straightthrough-processing-loop-detector",
        enableStraightthroughProcessingLoopDetector,
        Boolean.class,
        BackwardsCompatibilityMode.SUPPORTED,
        LEGACY_FEATURES_ENABLE_STRAIGHT_THROUGH_PROCESSING_LOOP_DETECTOR_PROPERTIES);
  }

  public void setEnableStraightthroughProcessingLoopDetector(
      final boolean enableStraightthroughProcessingLoopDetector) {
    this.enableStraightthroughProcessingLoopDetector = enableStraightthroughProcessingLoopDetector;
  }

  public boolean isEnableMessageBodyOnExpired() {
    return UnifiedConfigurationHelper.validateLegacyConfigurationUnsafe(
        PREFIX + ".enable-message-body-on-expired",
        enableMessageBodyOnExpired,
        Boolean.class,
        BackwardsCompatibilityMode.SUPPORTED,
        LEGACY_FEATURES_ENABLE_MESSAGE_BODY_ON_EXPIRED_PROPERTIES);
  }

  public void setEnableMessageBodyOnExpired(final boolean enableMessageBodyOnExpired) {
    this.enableMessageBodyOnExpired = enableMessageBodyOnExpired;
  }

  public boolean isEvaluateBoundaryEventCorrelationKeyInActivityScope() {
    return UnifiedConfigurationHelper.validateLegacyConfigurationUnsafe(
        PREFIX + ".evaluate-boundary-event-correlation-key-in-activity-scope",
        evaluateBoundaryEventCorrelationKeyInActivityScope,
        Boolean.class,
        BackwardsCompatibilityMode.SUPPORTED,
        LEGACY_FEATURES_EVALUATE_BOUNDARY_EVENT_CORRELATION_KEY_IN_ACTIVITY_SCOPE_PROPERTIES);
  }

  public void setEvaluateBoundaryEventCorrelationKeyInActivityScope(
      final boolean evaluateBoundaryEventCorrelationKeyInActivityScope) {
    this.evaluateBoundaryEventCorrelationKeyInActivityScope =
        evaluateBoundaryEventCorrelationKeyInActivityScope;
  }

  public int getMaxRecoverableRetries() {
    return maxRecoverableRetries;
  }

  public void setMaxRecoverableRetries(final int maxRecoverableRetries) {
    this.maxRecoverableRetries = maxRecoverableRetries;
  }

  public int getMaxPendingSideEffects() {
    return maxPendingSideEffects;
  }

  public void setMaxPendingSideEffects(final int maxPendingSideEffects) {
    this.maxPendingSideEffects = maxPendingSideEffects;
  }

  public FlowControl getFlowControl() {
    return flowControl;
  }

  public void setFlowControl(final FlowControl flowControl) {
    this.flowControl = flowControl;
  }
}
