/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */
package io.camunda.configuration;

import io.camunda.security.spring.CamundaSecurityLibraryProperties;
import org.springframework.boot.context.properties.NestedConfigurationProperty;

public class Security extends CamundaSecurityLibraryProperties {

  /** TLS configuration. */
  @NestedConfigurationProperty private Tls transportLayerSecurity = new Tls();

  /** Configuration for the dedicated cluster-admin security chain. */
  @NestedConfigurationProperty private ClusterAdmin clusterAdmin = new ClusterAdmin();

  public Tls getTransportLayerSecurity() {
    return transportLayerSecurity;
  }

  public void setTransportLayerSecurity(final Tls transportLayerSecurity) {
    this.transportLayerSecurity = transportLayerSecurity;
  }

  public ClusterAdmin getClusterAdmin() {
    return clusterAdmin;
  }

  public void setClusterAdmin(final ClusterAdmin clusterAdmin) {
    this.clusterAdmin = clusterAdmin == null ? new ClusterAdmin() : clusterAdmin;
  }
}
