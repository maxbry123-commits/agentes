/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */
package io.camunda.configuration;

import static io.camunda.zeebe.engine.EngineConfiguration.DEFAULT_MESSAGE_START_ASK_RETRY_INTERVAL;
import static io.camunda.zeebe.engine.EngineConfiguration.DEFAULT_MESSAGE_START_DEDUP_EXPIRATION_SWEEP_BATCH_LIMIT;
import static io.camunda.zeebe.engine.EngineConfiguration.DEFAULT_MESSAGE_START_DEDUP_EXPIRATION_SWEEP_INTERVAL;
import static io.camunda.zeebe.engine.EngineConfiguration.DEFAULT_MESSAGE_START_LOCK_RELEASE_POLL_BATCH_LIMIT;
import static io.camunda.zeebe.engine.EngineConfiguration.DEFAULT_MESSAGE_START_LOCK_RELEASE_POLL_INTERVAL;

import java.time.Duration;

public class ProcessInstanceCreation {
  private static final boolean DEFAULT_BUSINESS_ID_UNIQUENESS_ENABLED = false;

  /**
   * Controls uniqueness enforcement of business IDs across active process instances.
   *
   * <ul>
   *   <li><b>Disabled (default):</b> Multiple active process instances can share the same business
   *       ID. No tracking or validation is performed.
   *   <li><b>Enabled:</b> Creating a process instance with a business ID that is already in use by
   *       an active process instance will be rejected. Business IDs of process instances created
   *       before enabling this setting are not tracked, so duplicates with those are not detected.
   * </ul>
   */
  private boolean businessIdUniquenessEnabled = DEFAULT_BUSINESS_ID_UNIQUENESS_ENABLED;

  /**
   * Interval between scheduled expired-dedup-entry sweeps of the cross-partition message-start
   * dedup state on {@code P_B}. The sweep removes dedup rows whose deletion deadline has passed; it
   * is correctness-irrelevant and only bounds storage growth.
   */
  private Duration messageStartDedupExpirationSweepInterval =
      DEFAULT_MESSAGE_START_DEDUP_EXPIRATION_SWEEP_INTERVAL;

  /**
   * Upper bound on the number of expired dedup entries removed per sweep cycle on {@code P_B}. A
   * follow-up sweep is scheduled when more entries remain.
   */
  private int messageStartDedupExpirationSweepBatchLimit =
      DEFAULT_MESSAGE_START_DEDUP_EXPIRATION_SWEEP_BATCH_LIMIT;

  /**
   * Retry cadence for the cross-partition message-start pending-ask scheduler on {@code P_K}. Every
   * tick re-emits each pending ask whose last-sent time is older than this interval; the same value
   * also drives the scheduler's tick frequency.
   */
  private Duration messageStartAskRetryInterval = DEFAULT_MESSAGE_START_ASK_RETRY_INTERVAL;

  /**
   * Base poll interval for the cross-partition correlation-key lock-release scheduler on {@code
   * P_K}. {@code P_K} reconciles the completion of each remotely-created holder instance with
   * {@code P_B}; this value drives the scheduler's tick frequency. It is only a slow-path backstop,
   * since holder completion is normally pushed from {@code P_B} directly.
   */
  private Duration messageStartLockReleasePollInterval =
      DEFAULT_MESSAGE_START_LOCK_RELEASE_POLL_INTERVAL;

  /**
   * Upper bound on the number of holders batched into a single cross-partition correlation-key
   * lock-release query per target partition each poll cycle on {@code P_K}. Remaining due holders
   * are polled on the next tick.
   */
  private int messageStartLockReleasePollBatchLimit =
      DEFAULT_MESSAGE_START_LOCK_RELEASE_POLL_BATCH_LIMIT;

  public boolean isBusinessIdUniquenessEnabled() {
    return businessIdUniquenessEnabled;
  }

  public void setBusinessIdUniquenessEnabled(final boolean businessIdUniquenessEnabled) {
    this.businessIdUniquenessEnabled = businessIdUniquenessEnabled;
  }

  public Duration getMessageStartDedupExpirationSweepInterval() {
    return messageStartDedupExpirationSweepInterval;
  }

  public void setMessageStartDedupExpirationSweepInterval(
      final Duration messageStartDedupExpirationSweepInterval) {
    this.messageStartDedupExpirationSweepInterval = messageStartDedupExpirationSweepInterval;
  }

  public int getMessageStartDedupExpirationSweepBatchLimit() {
    return messageStartDedupExpirationSweepBatchLimit;
  }

  public void setMessageStartDedupExpirationSweepBatchLimit(
      final int messageStartDedupExpirationSweepBatchLimit) {
    this.messageStartDedupExpirationSweepBatchLimit = messageStartDedupExpirationSweepBatchLimit;
  }

  public Duration getMessageStartAskRetryInterval() {
    return messageStartAskRetryInterval;
  }

  public void setMessageStartAskRetryInterval(final Duration messageStartAskRetryInterval) {
    this.messageStartAskRetryInterval = messageStartAskRetryInterval;
  }

  public Duration getMessageStartLockReleasePollInterval() {
    return messageStartLockReleasePollInterval;
  }

  public void setMessageStartLockReleasePollInterval(
      final Duration messageStartLockReleasePollInterval) {
    this.messageStartLockReleasePollInterval = messageStartLockReleasePollInterval;
  }

  public int getMessageStartLockReleasePollBatchLimit() {
    return messageStartLockReleasePollBatchLimit;
  }

  public void setMessageStartLockReleasePollBatchLimit(
      final int messageStartLockReleasePollBatchLimit) {
    this.messageStartLockReleasePollBatchLimit = messageStartLockReleasePollBatchLimit;
  }
}
