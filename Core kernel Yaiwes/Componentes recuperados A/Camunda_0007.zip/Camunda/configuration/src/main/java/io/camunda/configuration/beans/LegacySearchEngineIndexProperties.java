/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */
package io.camunda.configuration.beans;

import io.camunda.search.schema.config.IndexConfiguration;
import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties("camunda.database.index")
public class LegacySearchEngineIndexProperties extends IndexConfiguration {}
