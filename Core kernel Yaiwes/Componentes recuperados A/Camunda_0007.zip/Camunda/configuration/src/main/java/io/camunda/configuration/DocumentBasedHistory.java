/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */
package io.camunda.configuration;

import io.camunda.configuration.UnifiedConfigurationHelper.BackwardsCompatibilityMode;
import io.camunda.exporter.config.ExporterConfiguration.HistoryConfiguration.ProcessInstanceRetentionMode;
import java.time.Duration;
import java.util.Map;
import java.util.Set;

public class DocumentBasedHistory {

  public static final Duration DEFAULT_HISTORY_MAX_DELAY_BETWEEN_RUNS = Duration.ofMillis(60000);
  private static final Duration DEFAULT_HISTORY_DELAY_BETWEEN_RUNS = Duration.ofMillis(2000);
  private static final boolean DEFAULT_HISTORY_PROCESS_INSTANCE_ENABLED = true;
  private static final ProcessInstanceRetentionMode
      DEFAULT_HISTORY_PROCESS_INSTANCE_RETENTION_MODE = ProcessInstanceRetentionMode.PI_HIERARCHY;
  private static final boolean DEFAULT_HISTORY_ARCHIVE_BY_ID_ENABLED = true;
  private static final String DEFAULT_HISTORY_POLICY_NAME = "camunda-retention-policy";
  /* keep in sync with RetentionConfiguration.DEFAULT_USAGE_METRICS_POLICY_NAME */
  private static final String DEFAULT_HISTORY_USAGE_METRICS_POLICY_NAME =
      "camunda-usage-metrics-retention-policy";
  private static final String DEFAULT_HISTORY_ELS_ROLLOVER_DATE_FORMAT = "date";
  private static final String DEFAULT_HISTORY_ROLLOVER_INTERVAL = "1d";
  /* keep in sync with ExporterConfiguration.HistoryConfiguration.usageMetricsRolloverInterval */
  private static final String DEFAULT_HISTORY_USAGE_METRICS_ROLLOVER_INTERVAL = "1M";
  /* This should be kept in sync with CamundaBackgroundTaskManagerFactory.DEFAULT_HISTORY_ROLLOVER_BATCH_SIZE */
  private static final int DEFAULT_HISTORY_ROLLOVER_BATCH_SIZE = 100;
  /* This should be kept in sync with CamundaBackgroundTaskManagerFactory.DEFAULT_HISTORY_ARCHIVE_BY_ID_ROLLOVER_BATCH_SIZE */
  private static final int DEFAULT_HISTORY_ARCHIVE_BY_ID_ROLLOVER_BATCH_SIZE = 500;
  private static final int DEFAULT_HISTORY_ARCHIVE_BY_ID_REINDEX_BATCH_SIZE = 2500;
  private static final int DEFAULT_HISTORY_ARCHIVE_BY_ID_MAX_RETRY_ATTEMPTS = 3;
  private static final int DEFAULT_HISTORY_ARCHIVE_BY_ID_RETRY_DELAY_MS = 1000;
  private static final String DEFAULT_HISTORY_WAIT_PERIOD_BEFORE_ARCHIVING = "1h";
  private static final Map<String, String> LEGACY_BROKER_PROPERTIES =
      Map.of(
          "process-instance-enabled",
          "zeebe.broker.exporters.camundaexporter.args.history.process-instance-enabled",
          "process-instance-retention-mode",
          "zeebe.broker.exporters.camundaexporter.args.history.processInstanceRetentionMode",
          "els-rollover-date-format",
          "zeebe.broker.exporters.camundaexporter.args.history.elsRolloverDateFormat",
          "rollover-interval",
          "zeebe.broker.exporters.camundaexporter.args.history.rolloverInterval",
          "rollover-batch-size",
          "zeebe.broker.exporters.camundaexporter.args.history.rolloverBatchSize",
          "wait-period-before-archiving",
          "zeebe.broker.exporters.camundaexporter.args.history.waitPeriodBeforeArchiving",
          "delay-between-runs",
          "zeebe.broker.exporters.camundaexporter.args.history.delayBetweenRuns",
          "max-delay-between-runs",
          "zeebe.broker.exporters.camundaexporter.args.history.maxDelayBetweenRuns",
          "usage-metrics-rollover-interval",
          "zeebe.broker.exporters.camundaexporter.args.history.usageMetricsRolloverInterval");
  private String prefix = "";

  private boolean processInstanceEnabled = DEFAULT_HISTORY_PROCESS_INSTANCE_ENABLED;

  private ProcessInstanceRetentionMode processInstanceRetentionMode =
      DEFAULT_HISTORY_PROCESS_INSTANCE_RETENTION_MODE;

  private boolean archiveByIdEnabled = DEFAULT_HISTORY_ARCHIVE_BY_ID_ENABLED;

  /** Date format for historical indices in Java DateTimeFormatter syntax */
  private String elsRolloverDateFormat = DEFAULT_HISTORY_ELS_ROLLOVER_DATE_FORMAT;

  /** Time range for creating dated indices (e.g., 1d creates daily indices). */
  private String rolloverInterval = DEFAULT_HISTORY_ROLLOVER_INTERVAL;

  /** Maximum number of process instances per archiving batch */
  private Integer rolloverBatchSize;

  /** Maximum number of docs reindexed/deleted in a batch */
  private int reindexBatchSize = DEFAULT_HISTORY_ARCHIVE_BY_ID_REINDEX_BATCH_SIZE;

  /**
   * Grace period before archiving completed processes. Processes finished within this window are
   * not yet archived.
   */
  private String waitPeriodBeforeArchiving = DEFAULT_HISTORY_WAIT_PERIOD_BEFORE_ARCHIVING;

  /** Millisecond interval between archiver runs */
  private Duration delayBetweenRuns = DEFAULT_HISTORY_DELAY_BETWEEN_RUNS;

  /** Maximum millisecond interval between archiver runs due to failure backoffs */
  private Duration maxDelayBetweenRuns = DEFAULT_HISTORY_MAX_DELAY_BETWEEN_RUNS;

  /** Maximum number of retries for archive-by-id batch operations on retryable errors */
  private int archiveByIdMaxRetryAttempts = DEFAULT_HISTORY_ARCHIVE_BY_ID_MAX_RETRY_ATTEMPTS;

  /** Retry delay in millisecond interval when archive-by-id batch fails on retryable errors */
  private int archiveByIdRetryDelayMs = DEFAULT_HISTORY_ARCHIVE_BY_ID_RETRY_DELAY_MS;

  /** Defines the name of the created and applied ILM policy. */
  private String policyName = DEFAULT_HISTORY_POLICY_NAME;

  /** Defines the name of the created and applied usage-metrics ILM policy. */
  private String usageMetricsPolicyName = DEFAULT_HISTORY_USAGE_METRICS_POLICY_NAME;

  /** Time range for creating dated usage-metrics indices. */
  private String usageMetricsRolloverInterval = DEFAULT_HISTORY_USAGE_METRICS_ROLLOVER_INTERVAL;

  /**
   * No-arg constructor solely so spring-boot-configuration-processor does not treat this class as
   * constructor-bound — with a single parameterized constructor, the processor derives metadata
   * only from that constructor's parameters and silently ignores every getter/setter below.
   * Deliberately unused and {@code private}: nothing — not even a test — should ever call it;
   * {@link #DocumentBasedHistory(String)} remains the only real construction path (see {@link
   * DocumentBasedSecondaryStorageDatabase}). Do not remove as dead code.
   */
  private DocumentBasedHistory() {}

  public DocumentBasedHistory(final String databaseName) {
    prefix = "camunda.data.secondary-storage.%s.history".formatted(databaseName);
  }

  public boolean isProcessInstanceEnabled() {
    return UnifiedConfigurationHelper.validateLegacyConfigurationUnsafe(
        prefix + ".process-instance-enabled",
        processInstanceEnabled,
        Boolean.class,
        BackwardsCompatibilityMode.SUPPORTED_ONLY_IF_VALUES_MATCH,
        Set.of(LEGACY_BROKER_PROPERTIES.get("process-instance-enabled")));
  }

  public void setProcessInstanceEnabled(final boolean processInstanceEnabled) {
    this.processInstanceEnabled = processInstanceEnabled;
  }

  public ProcessInstanceRetentionMode getProcessInstanceRetentionMode() {
    return UnifiedConfigurationHelper.validateLegacyConfigurationUnsafe(
        prefix + ".process-instance-retention-mode",
        processInstanceRetentionMode,
        ProcessInstanceRetentionMode.class,
        BackwardsCompatibilityMode.SUPPORTED,
        Set.of(LEGACY_BROKER_PROPERTIES.get("process-instance-retention-mode")));
  }

  public void setProcessInstanceRetentionMode(
      final ProcessInstanceRetentionMode processInstanceRetentionMode) {
    this.processInstanceRetentionMode = processInstanceRetentionMode;
  }

  public boolean isArchiveByIdEnabled() {
    return archiveByIdEnabled;
  }

  public void setArchiveByIdEnabled(final boolean archiveByIdEnabled) {
    this.archiveByIdEnabled = archiveByIdEnabled;
  }

  public String getPrefix() {
    return prefix;
  }

  public String getElsRolloverDateFormat() {
    return UnifiedConfigurationHelper.validateLegacyConfigurationUnsafe(
        prefix + ".els-rollover-date-format",
        elsRolloverDateFormat,
        String.class,
        BackwardsCompatibilityMode.SUPPORTED,
        Set.of(LEGACY_BROKER_PROPERTIES.get("els-rollover-date-format")));
  }

  public void setElsRolloverDateFormat(final String elsRolloverDateFormat) {
    this.elsRolloverDateFormat = elsRolloverDateFormat;
  }

  public String getRolloverInterval() {
    return UnifiedConfigurationHelper.validateLegacyConfigurationUnsafe(
        prefix + ".rollover-interval",
        rolloverInterval,
        String.class,
        BackwardsCompatibilityMode.SUPPORTED,
        Set.of(LEGACY_BROKER_PROPERTIES.get("rollover-interval")));
  }

  public void setRolloverInterval(final String rolloverInterval) {
    this.rolloverInterval = rolloverInterval;
  }

  public int getRolloverBatchSize() {
    if (rolloverBatchSize == null) {
      if (archiveByIdEnabled) {
        rolloverBatchSize = DEFAULT_HISTORY_ARCHIVE_BY_ID_ROLLOVER_BATCH_SIZE;
      } else {
        rolloverBatchSize = DEFAULT_HISTORY_ROLLOVER_BATCH_SIZE;
      }
    }

    return UnifiedConfigurationHelper.validateLegacyConfigurationUnsafe(
        prefix + ".rollover-batch-size",
        rolloverBatchSize,
        Integer.class,
        BackwardsCompatibilityMode.SUPPORTED,
        Set.of(LEGACY_BROKER_PROPERTIES.get("rollover-batch-size")));
  }

  public void setRolloverBatchSize(final int rolloverBatchSize) {
    this.rolloverBatchSize = rolloverBatchSize;
  }

  public int getReindexBatchSize() {
    return reindexBatchSize;
  }

  public void setReindexBatchSize(final int reindexBatchSize) {
    this.reindexBatchSize = reindexBatchSize;
  }

  public String getWaitPeriodBeforeArchiving() {
    return UnifiedConfigurationHelper.validateLegacyConfigurationUnsafe(
        prefix + ".wait-period-before-archiving",
        waitPeriodBeforeArchiving,
        String.class,
        BackwardsCompatibilityMode.SUPPORTED,
        Set.of(LEGACY_BROKER_PROPERTIES.get("wait-period-before-archiving")));
  }

  public void setWaitPeriodBeforeArchiving(final String waitPeriodBeforeArchiving) {
    this.waitPeriodBeforeArchiving = waitPeriodBeforeArchiving;
  }

  public Duration getDelayBetweenRuns() {
    return UnifiedConfigurationHelper.validateLegacyConfigurationUnsafe(
        prefix + ".delay-between-runs",
        delayBetweenRuns,
        Duration.class,
        BackwardsCompatibilityMode.SUPPORTED,
        Set.of(LEGACY_BROKER_PROPERTIES.get("delay-between-runs")));
  }

  public void setDelayBetweenRuns(final Duration delayBetweenRuns) {
    this.delayBetweenRuns = delayBetweenRuns;
  }

  public Duration getMaxDelayBetweenRuns() {
    return UnifiedConfigurationHelper.validateLegacyConfigurationUnsafe(
        prefix + ".max-delay-between-runs",
        maxDelayBetweenRuns,
        Duration.class,
        BackwardsCompatibilityMode.SUPPORTED,
        Set.of(LEGACY_BROKER_PROPERTIES.get("max-delay-between-runs")));
  }

  public void setMaxDelayBetweenRuns(final Duration maxDelayBetweenRuns) {
    this.maxDelayBetweenRuns = maxDelayBetweenRuns;
  }

  public String getPolicyName() {
    return UnifiedConfigurationHelper.validateLegacyConfigurationUnsafe(
        prefix + ".policy-name",
        policyName,
        String.class,
        BackwardsCompatibilityMode.SUPPORTED_ONLY_IF_VALUES_MATCH,
        legacyPolicyNameProperties());
  }

  public void setPolicyName(final String policyName) {
    this.policyName = policyName;
  }

  public String getUsageMetricsPolicyName() {
    return UnifiedConfigurationHelper.validateLegacyConfigurationUnsafe(
        prefix + ".usage-metrics-policy-name",
        usageMetricsPolicyName,
        String.class,
        BackwardsCompatibilityMode.SUPPORTED_ONLY_IF_VALUES_MATCH,
        legacyUsageMetricsPolicyNameProperties());
  }

  public void setUsageMetricsPolicyName(final String usageMetricsPolicyName) {
    this.usageMetricsPolicyName = usageMetricsPolicyName;
  }

  public String getUsageMetricsRolloverInterval() {
    return UnifiedConfigurationHelper.validateLegacyConfigurationUnsafe(
        prefix + ".usage-metrics-rollover-interval",
        usageMetricsRolloverInterval,
        String.class,
        BackwardsCompatibilityMode.SUPPORTED,
        Set.of(LEGACY_BROKER_PROPERTIES.get("usage-metrics-rollover-interval")));
  }

  public void setUsageMetricsRolloverInterval(final String usageMetricsRolloverInterval) {
    this.usageMetricsRolloverInterval = usageMetricsRolloverInterval;
  }

  public int getArchiveByIdMaxRetryAttempts() {
    return archiveByIdMaxRetryAttempts;
  }

  public void setArchiveByIdMaxRetryAttempts(final int archiveByIdMaxRetryAttempts) {
    this.archiveByIdMaxRetryAttempts = archiveByIdMaxRetryAttempts;
  }

  public int getArchiveByIdRetryDelayMs() {
    return archiveByIdRetryDelayMs;
  }

  public void setArchiveByIdRetryDelayMs(final int archiveByIdRetryDelayMs) {
    this.archiveByIdRetryDelayMs = archiveByIdRetryDelayMs;
  }

  private Set<String> legacyPolicyNameProperties() {
    return Set.of(
        "camunda.database.retention.policyName",
        "zeebe.broker.exporters.camundaexporter.args.history.retention.policyName");
  }

  private Set<String> legacyUsageMetricsPolicyNameProperties() {
    return Set.of(
        "camunda.database.retention.usageMetricsPolicyName",
        "zeebe.broker.exporters.camundaexporter.args.history.retention.usageMetricsPolicyName");
  }
}
