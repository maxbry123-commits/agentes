/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */
package io.camunda.configuration;

import java.util.List;

public class ClusterAdminBasic {

  /** Statically configured cluster-admin users for HTTP Basic authentication. */
  private List<ClusterAdminUser> users = List.of();

  public List<ClusterAdminUser> getUsers() {
    return users;
  }

  public void setUsers(final List<ClusterAdminUser> users) {
    this.users = users == null ? List.of() : users;
  }
}
