/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */
package io.camunda.configuration;

import static io.camunda.zeebe.gateway.impl.configuration.ConfigurationDefaults.DEFAULT_TLS_ENABLED;

import io.camunda.configuration.UnifiedConfigurationHelper.BackwardsCompatibilityMode;
import java.io.File;
import java.util.Map;
import java.util.Set;
import org.springframework.boot.context.properties.NestedConfigurationProperty;

public class Ssl implements Cloneable {
  private static final String PREFIX = "camunda.api.grpc.ssl";
  private static final Map<String, String> LEGACY_GATEWAY_SSL_PROPERTIES =
      Map.of(
          "enabled", "zeebe.gateway.security.enabled",
          "certificateChainPath", "zeebe.gateway.security.certificateChainPath",
          "privateKeyPath", "zeebe.gateway.security.privateKeyPath");
  private static final Map<String, String> LEGACY_BROKER_SSL_PROPERTIES =
      Map.of(
          "enabled", "zeebe.broker.gateway.security.enabled",
          "certificateChainPath", "zeebe.broker.gateway.security.certificateChainPath",
          "privateKeyPath", "zeebe.broker.gateway.security.privateKeyPath");

  private Map<String, String> legacyPropertiesMap = LEGACY_BROKER_SSL_PROPERTIES;

  /** Enables TLS authentication between clients and the gateway */
  private boolean enabled = DEFAULT_TLS_ENABLED;

  /** Sets the path to the certificate chain file */
  private File certificate;

  /** Sets the path to the private key file location */
  private File certificatePrivateKey;

  /**
   * Configures the keystore file containing both the certificate chain and the private key.
   * Currently only supports PKCS12 format.
   */
  @NestedConfigurationProperty private KeyStore keyStore = new KeyStore();

  public boolean isEnabled() {
    return UnifiedConfigurationHelper.validateLegacyConfigurationUnsafe(
        PREFIX + ".enabled",
        enabled,
        Boolean.class,
        BackwardsCompatibilityMode.SUPPORTED,
        Set.of(legacyPropertiesMap.get("enabled")));
  }

  public void setEnabled(final boolean enabled) {
    this.enabled = enabled;
  }

  public File getCertificate() {
    return UnifiedConfigurationHelper.validateLegacyConfigurationUnsafe(
        PREFIX + ".certificate",
        certificate,
        File.class,
        BackwardsCompatibilityMode.SUPPORTED,
        Set.of(legacyPropertiesMap.get("certificateChainPath")));
  }

  public void setCertificate(final File certificate) {
    this.certificate = certificate;
  }

  public File getCertificatePrivateKey() {
    return UnifiedConfigurationHelper.validateLegacyConfigurationUnsafe(
        PREFIX + ".certificate-private-key",
        certificatePrivateKey,
        File.class,
        BackwardsCompatibilityMode.SUPPORTED,
        Set.of(legacyPropertiesMap.get("privateKeyPath")));
  }

  public void setCertificatePrivateKey(final File certificatePrivateKey) {
    this.certificatePrivateKey = certificatePrivateKey;
  }

  public KeyStore getKeyStore() {
    return keyStore;
  }

  public void setKeyStore(final KeyStore keyStore) {
    this.keyStore = keyStore;
  }

  @Override
  public Object clone() {
    try {
      return super.clone();
    } catch (final CloneNotSupportedException e) {
      throw new AssertionError("Unexpected: Class must implement Cloneable", e);
    }
  }

  public Ssl withBrokerSslProperties() {
    final var copy = (Ssl) clone();
    copy.legacyPropertiesMap = LEGACY_BROKER_SSL_PROPERTIES;
    return copy;
  }

  public Ssl withGatewaySslProperties() {
    final var copy = (Ssl) clone();
    copy.legacyPropertiesMap = LEGACY_GATEWAY_SSL_PROPERTIES;
    return copy;
  }
}
