/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */
package io.camunda.operate.modules;

import io.camunda.operate.util.apps.modules.ModulesTestApplication;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(
    classes = {
      ModulesTestApplication.class,
    },
    properties = {
      "spring.mvc.pathmatch.matching-strategy=ANT_PATH_MATCHER",
      "spring.profiles.active=test,consolidated-auth,operate"
    })
public abstract class ModuleAbstractIT {

  @Autowired protected ApplicationContext applicationContext;
}
