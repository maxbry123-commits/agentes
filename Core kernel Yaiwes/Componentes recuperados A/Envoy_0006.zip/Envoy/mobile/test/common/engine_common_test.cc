#include "extension_registry.h"
#include "gtest/gtest.h"
#include "test/cc/engine_builder_test_shim.h"
#include "library/common/engine_common.h"

namespace Envoy {

TEST(EngineCommonTest, SignalHandlingFalse) {
  ExtensionRegistry::registerFactories();
  auto options = std::make_shared<Envoy::OptionsImplBase>();

  Platform::EngineBuilder builder;
  options->setConfigProto(builder.generateBootstrap());
  EngineCommon main_common{std::move(options)};
  ASSERT_FALSE(main_common.server()->options().signalHandlingEnabled());
}

TEST(EngineCommonTest, NewHandlerNotSet) {
  ExtensionRegistry::registerFactories();
  auto options = std::make_shared<Envoy::OptionsImplBase>();

  Platform::EngineBuilder builder;
  options->setConfigProto(builder.generateBootstrap());
  EngineCommon main_common{std::move(options)};
  ASSERT_EQ(std::get_new_handler(), nullptr);
}

} // namespace Envoy
