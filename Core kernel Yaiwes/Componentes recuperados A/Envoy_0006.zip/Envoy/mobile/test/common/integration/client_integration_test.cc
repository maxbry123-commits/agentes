#include "envoy/config/core/v3/extension.pb.h"

#include "source/common/quic/quic_server_transport_socket_factory.h"
#include "source/common/quic/server_codec_impl.h"
#include "source/common/tls/cert_validator/default_validator.h"
#include "source/common/tls/server_context_impl.h"
#include "source/extensions/http/header_formatters/preserve_case/preserve_case_formatter.h"
#include "source/extensions/quic/connection_id_generator/deterministic/envoy_deterministic_connection_id_generator_config.h"
#include "source/extensions/quic/crypto_stream/envoy_quic_crypto_server_stream.h"
#include "source/extensions/quic/proof_source/envoy_quic_proof_source_factory_impl.h"
#include "source/extensions/udp_packet_writer/default/config.h"

#include "test/common/http/common.h"
#include "test/common/integration/base_client_integration_test.h"
#include "test/common/mocks/common/mocks.h"
#include "test/common/mocks/dns/mock_dns_resolver.h"
#include "test/common/mocks/dns/mock_dns_resolver.pb.h"
#include "test/extensions/filters/http/dynamic_forward_proxy/test_resolver.h"
#include "test/integration/autonomous_upstream.h"
#include "test/test_common/registry.h"
#include "source/common/common/logger.h"
#include "test/test_common/test_random_generator.h"
#include "test/test_common/threadsafe_singleton_injector.h"

#include "absl/synchronization/notification.h"
#include "extension_registry.h"
#include "library/common/bridge/utility.h"
#include "library/common/http/header_utility.h"
#include "library/common/internal_engine.h"
#include "library/common/network/network_types.h"
#include "library/common/network/proxy_settings.h"
#include "library/common/types/c_types.h"
#include "quiche/quic/test_tools/quic_test_utils.h"

using testing::_;
using testing::AnyNumber;
using testing::Ge;
using testing::Return;
using testing::ReturnRef;
namespace Envoy {
namespace {

// The only thing this TestKeyValueStore does is return value_ when asked for
// initial loaded contents.
// In this case the TestKeyValueStore will be used for DNS and value will map
// www.lyft.com -> fake test upstream.
class TestKeyValueStore : public Envoy::Platform::KeyValueStore {
public:
  std::optional<std::string> read(const std::string&) override {
    ASSERT(!value_.empty());
    return value_;
  }
  void save(std::string, std::string) override {}
  void remove(const std::string&) override {}
  void addOrUpdate(absl::string_view, absl::string_view, std::optional<std::chrono::seconds>) {}
  std::optional<absl::string_view> get(absl::string_view) { return {}; }
  void flush() {}
  void iterate(::Envoy::KeyValueStore::ConstIterateCb) const {}
  void setValue(std::string value) { value_ = value; }

protected:
  std::string value_;
};

class ClientIntegrationTest : public BaseClientIntegrationTest,
                              public testing::TestWithParam<
                                  std::tuple<Network::Address::IpVersion, Http::CodecType, bool>> {
public:
  static void SetUpTestCase() { test_key_value_store_ = std::make_shared<TestKeyValueStore>(); }
  static void TearDownTestCase() { test_key_value_store_.reset(); }

  Http::CodecType getCodecType() { return std::get<1>(GetParam()); }
  bool getUseWorkerThread() { return std::get<2>(GetParam()); }

  ClientIntegrationTest() : BaseClientIntegrationTest(/*ip_version=*/std::get<0>(GetParam())) {
    // For server TLS
    Extensions::TransportSockets::Tls::forceRegisterServerContextFactoryImpl();
    // For H3 tests.
    Network::forceRegisterUdpDefaultWriterFactoryFactory();
    Quic::forceRegisterEnvoyQuicCryptoServerStreamFactoryImpl();
    Quic::forceRegisterQuicHttpServerConnectionFactoryImpl();
    Quic::forceRegisterQuicServerTransportSocketConfigFactory();
    Quic::forceRegisterEnvoyQuicProofSourceFactoryImpl();
    Quic::Extensions::ConnectionIdGenerator::Deterministic::
        forceRegisterEnvoyDeterministicConnectionIdGeneratorConfigFactory();
    // For H2 tests.
    Extensions::TransportSockets::Tls::forceRegisterDefaultCertValidatorFactory();
  }

  ~ClientIntegrationTest() override { Logger::Context::changeAllLogLevels(spdlog::level::info); }

  void initialize() override {
    builder_.setLogLevel(log_level_);
    Logger::Context::changeAllLogLevels(static_cast<spdlog::level::level_enum>(log_level_));
    builder_.enableWorkerThread(getUseWorkerThread());
    if (getUseWorkerThread()) {
      // Platform cert validation is disabled when using worker thread. The engine will use the
      // built-in root certs which doesn't have the CA cert for our fake upstream.
      builder_.enforceTrustChainVerification(false);
    }
    // Integration test starts upstreams before Envoy which can cause a data race.
    builder_.enableLogger(false);
    builder_.addRuntimeGuard("dns_cache_set_ip_version_to_remove", true);
    builder_.addRuntimeGuard("quic_no_tcp_delay", true);
    builder_.addRuntimeGuard("mobile_use_network_observer_registry", true);
    builder_.addRuntimeGuard("getaddrinfo_no_ai_flags", true);

    if (getCodecType() == Http::CodecType::HTTP3) {
      setUpstreamProtocol(Http::CodecType::HTTP3);
      builder_.enablePlatformCertificatesValidation(true);
      builder_.setUseQuicPlatformPacketWriter(true);
      // Create a k-v store for DNS lookup which createEnvoy() will use to point
      // www.lyft.com -> fake H3 backend.
      add_fake_dns_ = true;
      upstream_tls_ = true;
      add_quic_hints_ = true;
    } else if (getCodecType() == Http::CodecType::HTTP2) {
      setUpstreamProtocol(Http::CodecType::HTTP2);
      builder_.enablePlatformCertificatesValidation(true);
      upstream_tls_ = true;
    }

    if (add_fake_dns_) {
      builder_.addKeyValueStore("reserved.platform_store", test_key_value_store_);
      builder_.enableDnsCache(true, /* save_interval_seconds */ 1);
    }

    // Initialize the connectivity manager with a WIFI default network and another network with
    // unknown type.
    std::vector<std::pair<int64_t, ConnectionType>> connected_networks{
        {1, ConnectionType::CONNECTION_WIFI}, {2, ConnectionType::CONNECTION_UNKNOWN}};
    EXPECT_CALL(helper_handle_->mock_helper(), getDefaultNetworkHandle()).WillOnce(Return(1));
    EXPECT_CALL(helper_handle_->mock_helper(), getAllConnectedNetworks())
        .WillOnce(Return(connected_networks));
    // Mock socket binding to network 1 as binding to the default loopback address.
    EXPECT_CALL(helper_handle_->mock_helper(), bindSocketToNetwork(_, 1)).Times(AnyNumber());

    BaseClientIntegrationTest::initialize();

    if (getCodecType() == Http::CodecType::HTTP3) {
      auto address = fake_upstreams_[0]->localAddress();
      auto upstream_port = fake_upstreams_[0]->localAddress()->ip()->port();
      default_request_headers_.setHost(fmt::format("www.lyft.com:{}", upstream_port));
      default_request_headers_.setScheme("https");
    } else if (getCodecType() == Http::CodecType::HTTP2) {
      default_request_headers_.setScheme("https");
    }
  }

  void SetUp() override {
    setUpstreamCount(config_helper_.bootstrap().static_resources().clusters_size());
    helper_handle_ = test::SystemHelperPeer::replaceSystemHelper();
    EXPECT_CALL(helper_handle_->mock_helper(), isCleartextPermitted(_))
        .WillRepeatedly(Return(true));
    EXPECT_CALL(helper_handle_->mock_helper(), validateCertificateChain(_, _)).Times(AnyNumber());
    EXPECT_CALL(helper_handle_->mock_helper(), cleanupAfterCertificateValidation())
        .Times(AnyNumber());
  }

  void createEnvoy() override {
    // Allow last minute addition of QUIC hints. This is done lazily as it must be done after
    // upstreams are created.
    auto upstream_port = fake_upstreams_[0]->localAddress()->ip()->port();
    if (add_quic_hints_) {
      // With canonical suffix, having a quic hint of foo.lyft.com will make
      // www.lyft.com being recognized as QUIC ready.
      builder_.addQuicCanonicalSuffix(".lyft.com");
      builder_.addQuicHint("foo.lyft.com", upstream_port);
    }
    if (add_fake_dns_) {
      // Force www.lyft.com to resolve to the fake upstream. It's the only domain
      // name the certs work for so we want that in the request, but we need to
      // fake resolution to not result in a request to the real www.lyft.com
      std::string host = fmt::format("www.lyft.com:{}", upstream_port);
      std::string cache_file_value_contents =
          absl::StrCat(Network::Test::getLoopbackAddressUrlString(version_), ":",
                       fake_upstreams_[0]->localAddress()->ip()->port(), "|1000000|0");
      test_key_value_store_->setValue(absl::StrCat(host.length(), "\n", host,
                                                   cache_file_value_contents.length(), "\n",
                                                   cache_file_value_contents));
    }
    BaseClientIntegrationTest::createEnvoy();
  }

  void TearDown() override {
    if (upstream_connection_) {
      ASSERT_TRUE(upstream_connection_->close());
      ASSERT_TRUE(upstream_connection_->waitForDisconnect());
      upstream_connection_.reset();
    }
    BaseClientIntegrationTest::TearDown();
  }

  void basicTest();
  void trickleTest(bool final_chunk_has_data);
  void explicitFlowControlWithCancels(uint32_t body_size = 1000, bool terminate_engine = false);

  static std::string protocolToString(Http::CodecType type) {
    if (type == Http::CodecType::HTTP3) {
      return "Http3Upstream";
    }
    if (type == Http::CodecType::HTTP2) {
      return "Http2Upstream";
    }
    return "Http1Upstream";
  }

  static std::string testParamsToString(
      const testing::TestParamInfo<std::tuple<Network::Address::IpVersion, Http::CodecType, bool>>
          params) {
    return fmt::format(
        "{}_{}_{}",
        TestUtility::ipTestParamsToString(testing::TestParamInfo<Network::Address::IpVersion>(
            std::get<0>(params.param), params.index)),
        protocolToString(std::get<1>(params.param)),
        std::get<2>(params.param) ? "WorkerThreadOn" : "WorkerThreadOff");
  }

protected:
  Logger::Levels log_level_ = Logger::Levels::info;
  std::unique_ptr<test::SystemHelperPeer::Handle> helper_handle_;
  bool add_quic_hints_ = false;
  bool add_fake_dns_ = false;
  static std::shared_ptr<TestKeyValueStore> test_key_value_store_;
  FakeHttpConnectionPtr upstream_connection_;
  FakeStreamPtr upstream_request_;
};

std::shared_ptr<TestKeyValueStore> ClientIntegrationTest::test_key_value_store_{};

INSTANTIATE_TEST_SUITE_P(
    IpVersions, ClientIntegrationTest,
    testing::Combine(testing::ValuesIn(TestEnvironment::getIpVersionsForTest()),
                     testing::ValuesIn({Http::CodecType::HTTP1, Http::CodecType::HTTP2,
                                        Http::CodecType::HTTP3}),
                     testing::Bool()),
    ClientIntegrationTest::testParamsToString);

void ClientIntegrationTest::basicTest() {
  if (getCodecType() != Http::CodecType::HTTP1) {
    EXPECT_CALL(helper_handle_->mock_helper(), isCleartextPermitted(_)).Times(0);
    if (!getUseWorkerThread()) {
      EXPECT_CALL(helper_handle_->mock_helper(), validateCertificateChain(_, _));
      EXPECT_CALL(helper_handle_->mock_helper(), cleanupAfterCertificateValidation());
    }
  }
  Buffer::OwnedImpl request_data = Buffer::OwnedImpl("request body");
  default_request_headers_.addCopy(AutonomousStream::EXPECT_REQUEST_SIZE_BYTES,
                                   std::to_string(request_data.length()));

  EnvoyStreamCallbacks stream_callbacks = createDefaultStreamCallbacks();
  stream_callbacks.on_data_ = [this](const Buffer::Instance&, uint64_t, bool, envoy_stream_intel) {
    cc_.on_data_calls_++;
  };

  stream_ = createNewStream(std::move(stream_callbacks));
  stream_->sendHeaders(std::make_unique<Http::TestRequestHeaderMapImpl>(default_request_headers_),
                       false);

  stream_->sendData(std::make_unique<Buffer::OwnedImpl>(std::move(request_data)));

  stream_->close(Http::Utility::createRequestTrailerMapPtr());

  terminal_callback_.waitReady();

  ASSERT_EQ(cc_.on_headers_calls_, 1);
  ASSERT_EQ(cc_.status_, "200");
  ASSERT_GE(cc_.on_data_calls_, 1);
  ASSERT_EQ(cc_.on_complete_calls_, 1);
  if (upstreamProtocol() == Http::CodecType::HTTP1) {
    ASSERT_EQ(cc_.on_header_consumed_bytes_from_response_, 27);
    // HTTP/1
    ASSERT_EQ(1, last_stream_final_intel_.upstream_protocol);
  } else if (upstreamProtocol() == Http::CodecType::HTTP2) {
    ASSERT_EQ(2, last_stream_final_intel_.upstream_protocol);
  } else {
    // This verifies the H3 attempt was made due to the quic hints.
    absl::MutexLock l(engine_lock_);
    std::string stats = engine_->dumpStats();
    EXPECT_TRUE((absl::StrContains(stats, "cluster.base.upstream_cx_http3_total: 1"))) << stats;
    // Make sure the client reported protocol was also HTTP/3.
    ASSERT_EQ(3, last_stream_final_intel_.upstream_protocol);
  }
}

TEST_P(ClientIntegrationTest, Basic) {
  initialize();
  basicTest();
  if (upstreamProtocol() == Http::CodecType::HTTP1) {
    ASSERT_EQ(cc_.on_complete_received_byte_count_, 67);
  }
}

// TODO(fredyw): Disable this until we support treating no DNS record as a failure in the Apple
// resolver.
#if not defined(__APPLE__)
TEST_P(ClientIntegrationTest, DisableDnsRefreshOnFailure) {
  std::atomic<bool> found_cache_miss{false};
  LogExpectation log_expect(Envoy::GetLogSink(), [&](Logger::Levels, const std::string& msg) {
    if (msg.find("ignoring failed address cache hit for miss for host 'doesnotexist") !=
        std::string::npos) {
      found_cache_miss = true;
    }
  });

  // Configure MockDnsResolver with "doesnotexist" as a non-existent domain
  envoy::config::core::v3::TypedExtensionConfig dns_resolver_config;
  dns_resolver_config.set_name("envoy.test.mock_dns_resolver");
  envoy::test::mock_dns_resolver::v3::MockDnsResolverConfig config;
  config.add_non_existent_domains("doesnotexist");
  std::ignore = dns_resolver_config.mutable_typed_config()->PackFrom(config);
  builder_.setDnsResolver(dns_resolver_config);

  builder_.setDisableDnsRefreshOnFailure(true);
  log_level_ = Logger::Levels::debug;
  initialize();

  default_request_headers_.setHost("doesnotexist");
  stream_ = createNewStream(createDefaultStreamCallbacks());
  stream_->sendHeaders(std::make_unique<Http::TestRequestHeaderMapImpl>(default_request_headers_),
                       true);
  terminal_callback_.waitReady();

  stream_ = createNewStream(createDefaultStreamCallbacks());
  stream_->sendHeaders(std::make_unique<Http::TestRequestHeaderMapImpl>(default_request_headers_),
                       true);
  terminal_callback_.waitReady();

  EXPECT_TRUE(found_cache_miss);
}
#endif

TEST_P(ClientIntegrationTest, DisableDnsRefreshOnNetworkChange) {
  std::atomic<bool> found_force_dns_refresh{false};
  LogExpectation log_expect(Envoy::GetLogSink(), [&](Logger::Levels, const std::string& msg) {
    if (msg.find("beginning DNS cache force refresh") != std::string::npos) {
      found_force_dns_refresh = true;
    }
  });
  builder_.setDisableDnsRefreshOnNetworkChange(true);
  log_level_ = Logger::Levels::debug;
  initialize();

  internalEngine()->onDefaultNetworkChanged(1);

  EXPECT_FALSE(found_force_dns_refresh);
}

TEST_P(ClientIntegrationTest, HandleNetworkChangeEvents) {
  std::atomic<bool> found_force_dns_refresh{false};
  std::vector<absl::Notification> handled_network_changes(5);
  std::atomic<int> current_change_event{0};
  LogExpectation log_expect(Envoy::GetLogSink(), [&](Logger::Levels, const std::string& msg) {
    if (msg.find("beginning DNS cache force refresh") != std::string::npos) {
      found_force_dns_refresh = true;
    } else if (msg.find("Finished the network changed callback") != std::string::npos) {
      handled_network_changes[current_change_event].Notify();
    }
  });
  builder_.setDisableDnsRefreshOnNetworkChange(false);
  log_level_ = Logger::Levels::trace;
  initialize();

  // Set the network type to WIFI. This should trigger a network change.
  int network = static_cast<int>(NetworkType::WLAN);
  internalEngine()->onDefaultNetworkChangeEvent(network);
  handled_network_changes[current_change_event].WaitForNotification();
  EXPECT_TRUE(found_force_dns_refresh);
  found_force_dns_refresh = false;
  ++current_change_event;

  // Set the network type to Cellular 4G. This should trigger a network change.
  network = static_cast<int>(NetworkType::WWAN);
  network |= static_cast<int>(NetworkType::WWAN_4G);
  internalEngine()->onDefaultNetworkChangeEvent(network);
  handled_network_changes[current_change_event].WaitForNotification();
  EXPECT_TRUE(found_force_dns_refresh);
  found_force_dns_refresh = false;
  ++current_change_event;

  // Set the network type to Cellular 5G. This should not trigger a network change, because the
  // previous network type was still Cellular.
  network = static_cast<int>(NetworkType::WWAN);
  network |= static_cast<int>(NetworkType::WWAN_5G);
  internalEngine()->onDefaultNetworkChangeEvent(network);
  handled_network_changes[current_change_event].WaitForNotification();
  EXPECT_FALSE(found_force_dns_refresh);
  found_force_dns_refresh = false;
  ++current_change_event;

  // Set the network type back to WIFI. This should trigger a network change.
  network = static_cast<int>(NetworkType::WLAN);
  internalEngine()->onDefaultNetworkChangeEvent(network);
  handled_network_changes[current_change_event].WaitForNotification();
  EXPECT_TRUE(found_force_dns_refresh);
  found_force_dns_refresh = false;
  ++current_change_event;

  // Set the network type to WIFI, but with a VPN. This should trigger a network change.
  network = static_cast<int>(NetworkType::WLAN);
  network |= static_cast<int>(NetworkType::Generic);
  internalEngine()->onDefaultNetworkChangeEvent(network);
  handled_network_changes[current_change_event].WaitForNotification();
  EXPECT_TRUE(found_force_dns_refresh);
  EXPECT_EQ(4, current_change_event);
}

TEST_P(ClientIntegrationTest, HandleNetworkChangeEventsAndroid) {
  absl::Notification found_force_dns_refresh;
  std::atomic<bool> handled_network_change{false};
  LogExpectation log_expect(Envoy::GetLogSink(), [&](Logger::Levels, const std::string& msg) {
    if (msg.find("Default network state has been changed. Current net configuration key") !=
        std::string::npos) {
      handled_network_change = true;
    }
    if (msg.find("beginning DNS cache force refresh") != std::string::npos) {
      found_force_dns_refresh.Notify();
    }
  });
  builder_.setDisableDnsRefreshOnNetworkChange(false);
  log_level_ = Logger::Levels::trace;
  initialize();

  // A new WIFI network appears and becomes the default network. Even though
  // the test is initialized with a WIFI network, this should still have triggred
  // a network change event as it has a different network handle.
  internalEngine()->onNetworkConnectAndroid(ConnectionType::CONNECTION_WIFI, 123);
  internalEngine()->onDefaultNetworkChangedAndroid(ConnectionType::CONNECTION_WIFI, 123);
  // The HTTP status reset and DNS refresh should have been posted to the network thread and to be
  // handled there.
  found_force_dns_refresh.WaitForNotification();
  EXPECT_TRUE(handled_network_change);
}

TEST_P(ClientIntegrationTest, Http3IdleConnectionClosedUponNetworkChangeEventsAndroid) {
  expect_data_streams_ = false;
  builder_.enableQuicConnectionMigration(true);
  builder_.addRuntimeGuard("decouple_explicit_drain_pools_and_dns_refresh", true);
  builder_.addRuntimeGuard("mobile_use_network_observer_registry", true);
  // Refreshing DNS cache will revert the overridden lyft.com entry with actual
  // internet accessible address which is not intended.
  builder_.setDisableDnsRefreshOnNetworkChange(true);

  initialize();

  if (getCodecType() != Http::CodecType::HTTP3 || version_ != Network::Address::IpVersion::v4) {
    // This test relies on a 2nd v4 loopback address.
    return;
  }
  Buffer::OwnedImpl request_data = Buffer::OwnedImpl("request body");
  default_request_headers_.addCopy(AutonomousStream::EXPECT_REQUEST_SIZE_BYTES,
                                   std::to_string(request_data.length()));

  EnvoyStreamCallbacks stream_callbacks1 = createDefaultStreamCallbacks();
  stream_callbacks1.on_data_ = [this](const Buffer::Instance&, uint64_t, bool, envoy_stream_intel) {
    cc_.on_data_calls_++;
  };

  stream_ = createNewStream(std::move(stream_callbacks1));
  stream_->sendHeaders(std::make_unique<Http::TestRequestHeaderMapImpl>(default_request_headers_),
                       false);
  stream_->sendData(std::make_unique<Buffer::OwnedImpl>(std::move(request_data)));
  stream_->close(Http::Utility::createRequestTrailerMapPtr());

  terminal_callback_.waitReady();

  ASSERT_EQ(cc_.on_headers_calls_, 1);
  ASSERT_EQ(cc_.status_, "200");
  ASSERT_GE(cc_.on_data_calls_, 1);
  ASSERT_EQ(cc_.on_complete_calls_, 1);
  ASSERT_EQ(3, last_stream_final_intel_.upstream_protocol);
  ASSERT_EQ(0, last_stream_final_intel_.socket_reused);

  // An h3 upstream connection should have been established.
  ASSERT_TRUE(waitForCounter("cluster.base.upstream_cx_http3_total", Ge(1)));
  ASSERT_TRUE(waitForCounter("cluster.base.upstream_rq_total", Ge(1)));

  EXPECT_CALL(helper_handle_->mock_helper(), bindSocketToNetwork(_, 123)).Times(0u);
  // A new cellular network appears and becomes the default network. The idle connection should be
  // closed.
  internalEngine()->onNetworkConnectAndroid(ConnectionType::CONNECTION_4G, 123);
  internalEngine()->onDefaultNetworkChangedAndroid(ConnectionType::CONNECTION_4G, 123);
  ASSERT_TRUE(waitForCounter("http3.upstream.tx.quic_connection_close_error_code_QUIC_CONNECTION_"
                             "MIGRATION_NO_MIGRATABLE_STREAMS",
                             Ge(1)));

  // A new connection will be created on the new default network to serve new requests.
  EXPECT_CALL(helper_handle_->mock_helper(), bindSocketToNetwork(_, 123))
      .WillOnce(Invoke([&](Network::ConnectionSocket& socket, int64_t) {
        // Mock binding to the new cellular network with a new address.
        socket.ioHandle().bind(
            std::make_shared<const Network::Address::Ipv4Instance>("127.0.0.2", 0, nullptr));
      }));
  default_request_headers_.setCopy(
      Envoy::Http::LowerCaseString(AutonomousStream::EXPECT_REQUEST_SIZE_BYTES), "0");
  memset(&last_stream_final_intel_, 0, sizeof(envoy_final_stream_intel));
  ConditionalInitializer terminal_callback;
  cc_.terminal_callback_ = &terminal_callback;
  EnvoyStreamCallbacks stream_callbacks2 = createDefaultStreamCallbacks();

  stream_ = createNewStream(std::move(stream_callbacks2));
  stream_->sendHeaders(std::make_unique<Http::TestRequestHeaderMapImpl>(default_request_headers_),
                       true);

  terminal_callback.waitReady();

  ASSERT_EQ(cc_.on_headers_calls_, 2);
  ASSERT_EQ(cc_.status_, "200");
  ASSERT_EQ(cc_.on_complete_calls_, 2);
  ASSERT_EQ(3, last_stream_final_intel_.upstream_protocol);
  ASSERT_EQ(0, last_stream_final_intel_.socket_reused);

  ASSERT_TRUE(waitForCounter("cluster.base.upstream_rq_total", Ge(2)));
  // The total h3 connection count should have increased.
  EXPECT_EQ(2, getCounterValue("cluster.base.upstream_cx_http3_total"));
}

TEST_P(ClientIntegrationTest, Http3ConnectionMigrationUponNetworkChangeEventsAndroid) {
  builder_.enableQuicConnectionMigration(true);
  builder_.addRuntimeGuard("decouple_explicit_drain_pools_and_dns_refresh", true);
  builder_.addRuntimeGuard("mobile_use_network_observer_registry", true);
  builder_.setMigrateIdleQuicConnection(true);
  initialize();

  if (getCodecType() != Http::CodecType::HTTP3 || version_ != Network::Address::IpVersion::v4) {
    // This test relies on a 2nd v4 loopback address.
    return;
  }
  Buffer::OwnedImpl request_data = Buffer::OwnedImpl("request body");
  default_request_headers_.addCopy(AutonomousStream::EXPECT_REQUEST_SIZE_BYTES,
                                   std::to_string(request_data.length()));

  EnvoyStreamCallbacks stream_callbacks1 = createDefaultStreamCallbacks();
  stream_callbacks1.on_data_ = [this](const Buffer::Instance&, uint64_t, bool, envoy_stream_intel) {
    cc_.on_data_calls_++;
  };

  stream_ = createNewStream(std::move(stream_callbacks1));
  stream_->sendHeaders(std::make_unique<Http::TestRequestHeaderMapImpl>(default_request_headers_),
                       false);
  // Wait for the upstream connection to be established.
  ASSERT_TRUE(waitForCounter("cluster.base.upstream_cx_http3_total", Ge(1)));
  ASSERT_TRUE(waitForCounter("cluster.base.upstream_rq_total", Ge(1)));

  absl::Notification probing_socket_created;
  EXPECT_CALL(helper_handle_->mock_helper(), bindSocketToNetwork(_, 123))
      .WillOnce(Invoke([&](Network::ConnectionSocket& socket, int64_t) {
        // Mock binding to the new cellular network with a new address.
        socket.ioHandle().bind(
            std::make_shared<const Network::Address::Ipv4Instance>("127.0.0.2", 0, nullptr));
        probing_socket_created.Notify();
      }));
  // A new cellular network appears and becomes the default network. The connection should migrate
  // to it.
  internalEngine()->onNetworkConnectAndroid(ConnectionType::CONNECTION_4G, 123);
  internalEngine()->onDefaultNetworkChangedAndroid(ConnectionType::CONNECTION_4G, 123);
  // Wait for the device to start probing the new network.
  probing_socket_created.WaitForNotificationWithTimeout(absl::Seconds(10));

  // Continue sending more request body.
  stream_->sendData(std::make_unique<Buffer::OwnedImpl>(std::move(request_data)));

  stream_->close(Http::Utility::createRequestTrailerMapPtr());

  terminal_callback_.waitReady();

  ASSERT_EQ(cc_.on_headers_calls_, 1);
  ASSERT_EQ(cc_.status_, "200");
  ASSERT_GE(cc_.on_data_calls_, 1);
  ASSERT_EQ(cc_.on_complete_calls_, 1);
  ASSERT_EQ(3, last_stream_final_intel_.upstream_protocol);
  ASSERT_EQ(0, last_stream_final_intel_.socket_reused);

  // New request will reuse this connection as it was not drained.
  default_request_headers_.setCopy(
      Envoy::Http::LowerCaseString(AutonomousStream::EXPECT_REQUEST_SIZE_BYTES), "0");
  memset(&last_stream_final_intel_, 0, sizeof(envoy_final_stream_intel));
  ConditionalInitializer terminal_callback;
  cc_.terminal_callback_ = &terminal_callback;
  EnvoyStreamCallbacks stream_callbacks2 = createDefaultStreamCallbacks();

  stream_ = createNewStream(std::move(stream_callbacks2));
  stream_->sendHeaders(std::make_unique<Http::TestRequestHeaderMapImpl>(default_request_headers_),
                       true);

  terminal_callback.waitReady();

  ASSERT_EQ(cc_.on_headers_calls_, 2);
  ASSERT_EQ(cc_.status_, "200");
  ASSERT_EQ(cc_.on_complete_calls_, 2);
  ASSERT_EQ(3, last_stream_final_intel_.upstream_protocol);
  ASSERT_EQ(1, last_stream_final_intel_.socket_reused);

  ASSERT_TRUE(waitForCounter("cluster.base.upstream_rq_total", Ge(2)));
  // The total h3 connection count shouldn't have increased.
  EXPECT_EQ(1, getCounterValue("cluster.base.upstream_cx_http3_total"));
}

// Tests that when the current network is disconnected, the connection migrates to another available
// network. And idle connections are closed when the old network connects again and became the
// default.
TEST_P(ClientIntegrationTest, Http3ConnectionMigrationUponNetworkDisconnectedAndroid) {
  builder_.enableQuicConnectionMigration(true);
  builder_.addRuntimeGuard("decouple_explicit_drain_pools_and_dns_refresh", true);
  builder_.addRuntimeGuard("mobile_use_network_observer_registry", true);
  initialize();

  if (getCodecType() != Http::CodecType::HTTP3 || version_ != Network::Address::IpVersion::v4) {
    // This test relies on a 2nd v4 loopback address.
    return;
  }
  default_request_headers_.addCopy(AutonomousStream::EXPECT_REQUEST_SIZE_BYTES, "0");
  EnvoyStreamCallbacks stream_callbacks1 = createDefaultStreamCallbacks();
  stream_callbacks1.on_data_ = [this](const Buffer::Instance&, uint64_t, bool, envoy_stream_intel) {
    cc_.on_data_calls_++;
  };
  stream_ = createNewStream(std::move(stream_callbacks1));
  stream_->sendHeaders(std::make_unique<Http::TestRequestHeaderMapImpl>(default_request_headers_),
                       true);
  terminal_callback_.waitReady();

  ASSERT_EQ(cc_.on_headers_calls_, 1);
  ASSERT_EQ(cc_.status_, "200");
  ASSERT_GE(cc_.on_data_calls_, 1);
  ASSERT_EQ(cc_.on_complete_calls_, 1);
  ASSERT_EQ(3, last_stream_final_intel_.upstream_protocol);
  ASSERT_EQ(0, last_stream_final_intel_.socket_reused);

  // Wait for the upstream connection to be established.
  ASSERT_TRUE(waitForCounter("cluster.base.upstream_cx_http3_total", Ge(1)));
  ASSERT_TRUE(waitForCounter("cluster.base.upstream_rq_total", Ge(1)));

  // Send a new request with body during which network gets disconnected.
  Buffer::OwnedImpl request_data = Buffer::OwnedImpl("request body");
  default_request_headers_.setCopy(
      Envoy::Http::LowerCaseString(AutonomousStream::EXPECT_REQUEST_SIZE_BYTES),
      std::to_string(request_data.length()));
  memset(&last_stream_final_intel_, 0, sizeof(envoy_final_stream_intel));
  ConditionalInitializer terminal_callback;
  cc_.terminal_callback_ = &terminal_callback;
  EnvoyStreamCallbacks stream_callbacks2 = createDefaultStreamCallbacks();
  stream_ = createNewStream(std::move(stream_callbacks2));
  stream_->sendHeaders(std::make_unique<Http::TestRequestHeaderMapImpl>(default_request_headers_),
                       false);

  absl::Notification new_socket_created;
  EXPECT_CALL(helper_handle_->mock_helper(), bindSocketToNetwork(_, 2))
      .WillOnce(Invoke([&](Network::ConnectionSocket& socket, int64_t) {
        // Mock binding to the unknown network with a new address.
        socket.ioHandle().bind(
            std::make_shared<const Network::Address::Ipv4Instance>("127.0.0.2", 0, nullptr));
        new_socket_created.Notify();
      }));
  // The current WIFI network is disconnected, and the connection should migrate to the unknown
  // network.
  internalEngine()->onNetworkDisconnectAndroid(1);
  // Wait for the device to migrate to the 2nd network.
  new_socket_created.WaitForNotificationWithTimeout(absl::Seconds(10));

  // Continue sending more request body.
  stream_->sendData(std::make_unique<Buffer::OwnedImpl>(std::move(request_data)));

  stream_->close(Http::Utility::createRequestTrailerMapPtr());

  terminal_callback.waitReady();

  ASSERT_EQ(cc_.on_headers_calls_, 2);
  ASSERT_EQ(cc_.status_, "200");
  ASSERT_EQ(cc_.on_complete_calls_, 2);
  ASSERT_EQ(3, last_stream_final_intel_.upstream_protocol);
  ASSERT_EQ(1, last_stream_final_intel_.socket_reused);

  // The old WIFI network appears again and becomes the default network. The idle connection on the
  // unknown network should be closed.
  internalEngine()->onNetworkConnectAndroid(ConnectionType::CONNECTION_WIFI, 1);
  internalEngine()->onDefaultNetworkChangedAndroid(ConnectionType::CONNECTION_WIFI, 1);

  ASSERT_TRUE(waitForCounter("http3.upstream.tx.quic_connection_close_error_code_QUIC_CONNECTION_"
                             "MIGRATION_NO_MIGRATABLE_STREAMS",
                             Ge(1)));
}

TEST_P(ClientIntegrationTest, LargeResponse) {
  initialize();
  std::string data(1024 * 32, 'a');
  reinterpret_cast<AutonomousUpstream*>(fake_upstreams_.front().get())->setResponseBody(data);
  basicTest();
  if (upstreamProtocol() == Http::CodecType::HTTP1) {
    ASSERT_EQ(cc_.on_complete_received_byte_count_, 32828);
  } else {
    ASSERT_GE(cc_.on_complete_received_byte_count_, 32000);
  }
}

void ClientIntegrationTest::trickleTest(bool final_chunk_has_data) {
  autonomous_upstream_ = false;

  initialize();

  EnvoyStreamCallbacks stream_callbacks = createDefaultStreamCallbacks();
  stream_callbacks.on_data_ = [this,
                               final_chunk_has_data](const Buffer::Instance&, uint64_t /* length */,
                                                     bool /* end_stream */, envoy_stream_intel) {
    if (explicit_flow_control_) {
      // Allow reading up to 100 bytes.
      stream_->readData(100);
    }
    cc_.on_data_calls_++;
    if (cc_.on_data_calls_ < 10) {
      upstream_request_->encodeData(1, cc_.on_data_calls_ == 9 && final_chunk_has_data);
    }
    if (cc_.on_data_calls_ == 10 && !final_chunk_has_data) {
      upstream_request_->encodeData(0, true);
    }
  };

  stream_ = createNewStream(std::move(stream_callbacks));
  stream_->sendHeaders(std::make_unique<Http::TestRequestHeaderMapImpl>(default_request_headers_),
                       false);
  if (explicit_flow_control_) {
    // Allow reading up to 100 bytes
    stream_->readData(100);
  }
  stream_->sendData(std::make_unique<Buffer::OwnedImpl>("request body"));
  stream_->close(Http::Utility::createRequestTrailerMapPtr());

  ASSERT_TRUE(fake_upstreams_[0]->waitForHttpConnection(*BaseIntegrationTest::dispatcher_,
                                                        upstream_connection_));
  ASSERT_TRUE(
      upstream_connection_->waitForNewStream(*BaseIntegrationTest::dispatcher_, upstream_request_));
  ASSERT_TRUE(upstream_request_->waitForEndStream(*BaseIntegrationTest::dispatcher_));

  upstream_request_->encode1xxHeaders(Http::TestResponseHeaderMapImpl{{":status", "100"}});
  upstream_request_->encodeHeaders(Http::TestResponseHeaderMapImpl{{":status", "200"}}, false);
  // This will be read immediately. on_data_ will kick off more chunks.
  upstream_request_->encodeData(1, false);

  terminal_callback_.waitReady();
}

TEST_P(ClientIntegrationTest, Trickle) {
  trickleTest(true);
  ASSERT_LE(cc_.on_data_calls_, 11);
  ASSERT_EQ(cc_.on_error_calls_, 0);
  ASSERT_EQ(cc_.on_complete_calls_, 1);
}

TEST_P(ClientIntegrationTest, TrickleExplicitFlowControl) {
  explicit_flow_control_ = true;
  trickleTest(true);
  ASSERT_LE(cc_.on_data_calls_, 11);
  ASSERT_EQ(cc_.on_error_calls_, 0);
  ASSERT_EQ(cc_.on_complete_calls_, 1);
}

TEST_P(ClientIntegrationTest, TrickleFinalChunkEmpty) {
  trickleTest(false);
  ASSERT_EQ(cc_.on_data_calls_, 11);
  ASSERT_EQ(cc_.on_error_calls_, 0);
  ASSERT_EQ(cc_.on_complete_calls_, 1);
}

TEST_P(ClientIntegrationTest, TrickleExplicitFlowControlFinalChunkEmpty) {
  explicit_flow_control_ = true;
  trickleTest(false);
  ASSERT_EQ(cc_.on_data_calls_, 11);
  ASSERT_EQ(cc_.on_error_calls_, 0);
  ASSERT_EQ(cc_.on_complete_calls_, 1);
}

TEST_P(ClientIntegrationTest, ExplicitFlowControlEmptyChunkThenReadData) {
  expect_data_streams_ = false; // Don't validate intel.
  explicit_flow_control_ = true;
  autonomous_upstream_ = false;
  initialize();

  EnvoyStreamCallbacks stream_callbacks = createDefaultStreamCallbacks();

  stream_ = createNewStream(std::move(stream_callbacks));
  stream_->sendHeaders(std::make_unique<Http::TestRequestHeaderMapImpl>(default_request_headers_),
                       false);

  ASSERT_TRUE(fake_upstreams_[0]->waitForHttpConnection(*BaseIntegrationTest::dispatcher_,
                                                        upstream_connection_));
  ASSERT_TRUE(
      upstream_connection_->waitForNewStream(*BaseIntegrationTest::dispatcher_, upstream_request_));

  upstream_request_->encodeHeaders(Http::TestResponseHeaderMapImpl{{":status", "200"}}, false);
  upstream_request_->encodeData(0, true);

  // Wait for the chunk to hopefully arrive.
  sleep(1);
  stream_->readData(100);

  terminal_callback_.waitReady();

  ASSERT_EQ(cc_.on_data_calls_, 1);
  ASSERT_EQ(cc_.on_error_calls_, 0);
  ASSERT_EQ(cc_.on_complete_calls_, 1);
}

TEST_P(ClientIntegrationTest, ManyStreamExplicitFlowControl) {
  explicit_flow_control_ = true;
  initialize();

  default_request_headers_.addCopy(AutonomousStream::RESPONSE_SIZE_BYTES, std::to_string(1000));

  uint32_t num_requests = 100;
  std::vector<Platform::StreamPrototypeSharedPtr> prototype_streams;
  std::vector<Platform::StreamSharedPtr> streams;

  for (uint32_t i = 0; i < num_requests; ++i) {
    Platform::StreamPrototypeSharedPtr stream_prototype;
    {
      absl::MutexLock l(engine_lock_);
      stream_prototype = engine_->streamClient()->newStreamPrototype();
    }

    EnvoyStreamCallbacks stream_callbacks = createDefaultStreamCallbacks();
    stream_callbacks.on_complete_ = [this, &num_requests](envoy_stream_intel,
                                                          envoy_final_stream_intel) {
      cc_.on_complete_calls_++;
      if (cc_.on_complete_calls_ == num_requests) {
        cc_.terminal_callback_->setReady();
      }
    };

    stream_callbacks.on_data_ = [&streams, i](const Buffer::Instance&, uint64_t /* length */,
                                              bool /* end_stream */, envoy_stream_intel) {
      // Allow reading up to 100 bytes.
      streams[i]->readData(100);
    };
    auto stream = createNewStream(std::move(stream_callbacks));
    prototype_streams.push_back(stream_prototype);
    streams.push_back(stream);

    stream->sendHeaders(std::make_unique<Http::TestRequestHeaderMapImpl>(default_request_headers_),
                        true);
    stream->readData(100);
  }
  ASSERT(streams.size() == num_requests);
  ASSERT(prototype_streams.size() == num_requests);

  terminal_callback_.waitReady();
  ASSERT_EQ(num_requests, cc_.on_complete_calls_);
}

void ClientIntegrationTest::explicitFlowControlWithCancels(const uint32_t body_size,
                                                           const bool terminate_engine) {
  default_request_headers_.addCopy(AutonomousStream::RESPONSE_SIZE_BYTES,
                                   std::to_string(body_size));

  uint32_t num_requests = 100;
  std::vector<Platform::StreamPrototypeSharedPtr> prototype_streams;
  std::vector<Platform::StreamSharedPtr> streams;

  // Randomly select which request number to terminate the engine on.
  uint32_t request_for_engine_termination = 0;
  if (terminate_engine) {
    TestRandomGenerator rand;
    request_for_engine_termination = rand.random() % (num_requests / 2);
  }

  for (uint32_t i = 0; i < num_requests; ++i) {
    Platform::StreamPrototypeSharedPtr stream_prototype;
    {
      absl::MutexLock l(engine_lock_);
      stream_prototype = engine_->streamClient()->newStreamPrototype();
    }

    EnvoyStreamCallbacks stream_callbacks = createDefaultStreamCallbacks();
    stream_callbacks.on_complete_ = [this, &num_requests](envoy_stream_intel,
                                                          envoy_final_stream_intel) {
      cc_.on_complete_calls_++;
      if (cc_.on_complete_calls_ + cc_.on_cancel_calls_ == num_requests) {
        cc_.terminal_callback_->setReady();
      }
    };
    stream_callbacks.on_cancel_ = [this, &num_requests](envoy_stream_intel,
                                                        envoy_final_stream_intel) {
      cc_.on_cancel_calls_++;
      if (cc_.on_complete_calls_ + cc_.on_cancel_calls_ == num_requests) {
        cc_.terminal_callback_->setReady();
      }
    };
    stream_callbacks.on_data_ = [&streams, i](const Buffer::Instance&, uint64_t /* length */,
                                              bool /* end_stream */, envoy_stream_intel) {
      // Allow reading up to 100 bytes.
      streams[i]->readData(100);
    };
    stream_callbacks.on_error_ = [](const EnvoyError&, envoy_stream_intel,
                                    envoy_final_stream_intel) { RELEASE_ASSERT(0, "unexpected"); };

    auto stream = createNewStream(std::move(stream_callbacks));
    stream->sendHeaders(std::make_unique<Http::TestRequestHeaderMapImpl>(default_request_headers_),
                        true);
    prototype_streams.push_back(stream_prototype);
    streams.push_back(stream);
    if (i % 2 == 0) {
      stream->cancel();
    } else {
      stream->readData(100);
    }

    if (terminate_engine && request_for_engine_termination == i) {
      absl::MutexLock l(engine_lock_);
      ASSERT_EQ(engine_->terminate(), ENVOY_SUCCESS);
      engine_.reset();
      break;
    }
  }

  if (terminate_engine) {
    // Only the cancel calls are guaranteed to have completed when engine->terminate() is called.
    EXPECT_GE(cc_.on_cancel_calls_, request_for_engine_termination / 2);
  } else {
    ASSERT(streams.size() == num_requests);
    ASSERT(prototype_streams.size() == num_requests);
    terminal_callback_.waitReady();
    EXPECT_EQ(num_requests / 2, cc_.on_complete_calls_);
    EXPECT_EQ(num_requests / 2, cc_.on_cancel_calls_);
  }
}

TEST_P(ClientIntegrationTest, ManyStreamExplicitFlowWithCancels) {
  explicit_flow_control_ = true;
  initialize();
  explicitFlowControlWithCancels();
}

TEST_P(ClientIntegrationTest, ManyStreamExplicitFlowWithCancelsAfterComplete) {
  explicit_flow_control_ = true;
  initialize();
  explicitFlowControlWithCancels(/*body_size=*/100);
}

TEST_P(ClientIntegrationTest, ManyStreamExplicitFlowWithCancelsAfterCompleteEngineTermination) {
  explicit_flow_control_ = true;
  initialize();
  explicitFlowControlWithCancels(/*body_size=*/100, /*terminate_engine=*/true);
}

TEST_P(ClientIntegrationTest, ClearTextNotPermitted) {
  if (getCodecType() != Http::CodecType::HTTP1) {
    return;
  }
  EXPECT_CALL(helper_handle_->mock_helper(), isCleartextPermitted(_)).WillRepeatedly(Return(false));

  expect_data_streams_ = false;
  initialize();

  Buffer::OwnedImpl request_data = Buffer::OwnedImpl("request body");
  default_request_headers_.addCopy(AutonomousStream::EXPECT_REQUEST_SIZE_BYTES,
                                   std::to_string(request_data.length()));

  EnvoyStreamCallbacks stream_callbacks = createDefaultStreamCallbacks();
  stream_callbacks.on_data_ = [this](const Buffer::Instance& buffer, uint64_t length,
                                     bool end_stream, envoy_stream_intel) {
    if (end_stream) {
      std::string response_body(length, ' ');
      buffer.copyOut(0, length, response_body.data());
      EXPECT_EQ(response_body, "Cleartext is not permitted");
    }
    cc_.on_data_calls_++;
  };

  stream_ = createNewStream(std::move(stream_callbacks));
  stream_->sendHeaders(std::make_unique<Http::TestRequestHeaderMapImpl>(default_request_headers_),
                       true);

  terminal_callback_.waitReady();

  ASSERT_EQ(cc_.on_headers_calls_, 1);
  ASSERT_EQ(cc_.status_, "400");
  ASSERT_EQ(cc_.on_data_calls_, 1);
  ASSERT_EQ(cc_.on_complete_calls_, 1);
}

TEST_P(ClientIntegrationTest, BasicHttps) {
  EXPECT_CALL(helper_handle_->mock_helper(), isCleartextPermitted(_)).Times(0);
  if (!getUseWorkerThread()) {
    EXPECT_CALL(helper_handle_->mock_helper(), validateCertificateChain(_, _));
    EXPECT_CALL(helper_handle_->mock_helper(), cleanupAfterCertificateValidation());
  }

  builder_.enablePlatformCertificatesValidation(true);

  upstream_tls_ = true;

  initialize();
  default_request_headers_.setScheme("https");

  Buffer::OwnedImpl request_data = Buffer::OwnedImpl("request body");
  default_request_headers_.addCopy(AutonomousStream::EXPECT_REQUEST_SIZE_BYTES,
                                   std::to_string(request_data.length()));

  EnvoyStreamCallbacks stream_callbacks = createDefaultStreamCallbacks();
  stream_callbacks.on_data_ = [this](const Buffer::Instance& buffer, uint64_t length,
                                     bool end_stream, envoy_stream_intel) {
    if (end_stream) {
      std::string response_body(length, ' ');
      buffer.copyOut(0, length, response_body.data());
      EXPECT_EQ(response_body, "");
    } else {
      EXPECT_EQ(length, 10);
    }
    cc_.on_data_calls_++;
  };

  stream_ = createNewStream(std::move(stream_callbacks));
  stream_->sendHeaders(std::make_unique<Http::TestRequestHeaderMapImpl>(default_request_headers_),
                       false);

  stream_->sendData(std::make_unique<Buffer::OwnedImpl>(std::move(request_data)));

  stream_->close(Http::Utility::createRequestTrailerMapPtr());

  terminal_callback_.waitReady();

  ASSERT_EQ(cc_.on_headers_calls_, 1);
  ASSERT_EQ(cc_.status_, "200");
  ASSERT_GE(cc_.on_data_calls_, 1);
  ASSERT_EQ(cc_.on_complete_calls_, 1);
  if (upstreamProtocol() == Http::CodecType::HTTP1) {
    ASSERT_EQ(cc_.on_complete_received_byte_count_, 67);
  }
}

TEST_P(ClientIntegrationTest, BasicNon2xx) {
  initialize();

  // Set response header status to be non-2xx to test that the correct stats get charged.
  reinterpret_cast<AutonomousUpstream*>(fake_upstreams_.front().get())
      ->setResponseHeaders(std::make_unique<Http::TestResponseHeaderMapImpl>(
          Http::TestResponseHeaderMapImpl({{":status", "503"}})));

  stream_ = createNewStream(createDefaultStreamCallbacks());
  stream_->sendHeaders(std::make_unique<Http::TestRequestHeaderMapImpl>(default_request_headers_),
                       true);
  terminal_callback_.waitReady();

  ASSERT_EQ(cc_.on_error_calls_, 0);
  ASSERT_EQ(cc_.status_, "503");
  ASSERT_EQ(cc_.on_headers_calls_, 1);
  ASSERT_EQ(cc_.on_complete_calls_, 1);
}

TEST_P(ClientIntegrationTest, InvalidDomain) {
  // Configure MockDnsResolver with "www.doesnotexist.com" as a non-existent domain
  envoy::config::core::v3::TypedExtensionConfig dns_resolver_config;
  dns_resolver_config.set_name("envoy.test.mock_dns_resolver");
  envoy::test::mock_dns_resolver::v3::MockDnsResolverConfig config;
  config.add_non_existent_domains("www.doesnotexist.com");
  std::ignore = dns_resolver_config.mutable_typed_config()->PackFrom(config);
  builder_.setDnsResolver(dns_resolver_config);

  initialize();

  default_request_headers_.setHost("www.doesnotexist.com");
  stream_ = createNewStream(createDefaultStreamCallbacks());
  stream_->sendHeaders(std::make_unique<Http::TestRequestHeaderMapImpl>(default_request_headers_),
                       true);
  terminal_callback_.waitReady();

  ASSERT_EQ(cc_.on_error_calls_, 1);
  ASSERT_EQ(cc_.on_headers_calls_, 0);
}

TEST_P(ClientIntegrationTest, InvalidDomainFakeResolver) {
  upstream_tls_ = false; // Avoid cert verify errors.
  Network::OverrideAddrInfoDnsResolverFactory factory;
  Registry::InjectFactory<Network::DnsResolverFactory> inject_factory(factory);
  Registry::InjectFactory<Network::DnsResolverFactory>::forceAllowDuplicates();

  initialize();
  if (upstreamProtocol() != Http::CodecType::HTTP1) {
    return;
  }

  default_request_headers_.setHost(
      absl::StrCat("www.doesnotexist.com:", fake_upstreams_[0]->localAddress()->ip()->port()));
  stream_ = createNewStream(createDefaultStreamCallbacks());
  stream_->sendHeaders(std::make_unique<Http::TestRequestHeaderMapImpl>(default_request_headers_),
                       true);
  // Force the lookup to resolve to localhost.
  Network::TestResolver::unblockResolve("localhost");
  terminal_callback_.waitReady();

  // Instead of an error we should get a 200 ok from the fake upstream.
  ASSERT_EQ(cc_.on_error_calls_, 0);
  ASSERT_EQ(cc_.on_headers_calls_, 1);
  ASSERT_EQ(cc_.status_, "200");

  // Kick off a second request. There should be no resolution.
  stream_ = createNewStream(createDefaultStreamCallbacks());
  stream_->sendHeaders(std::make_unique<Http::TestRequestHeaderMapImpl>(default_request_headers_),
                       true);
  terminal_callback_.waitReady();
  EXPECT_EQ(1, getCounterValue("dns_cache.base_dns_cache.dns_query_attempt"));
}

TEST_P(ClientIntegrationTest, InvalidDomainReresolveWithNoAddresses) {
  builder_.addRuntimeGuard("reresolve_null_addresses", true);

  // Configure MockDnsResolver with "www.doesnotexist.com" as a non-existent domain
  envoy::config::core::v3::TypedExtensionConfig dns_resolver_config;
  dns_resolver_config.set_name("envoy.test.mock_dns_resolver");
  envoy::test::mock_dns_resolver::v3::MockDnsResolverConfig config;
  config.add_non_existent_domains("www.doesnotexist.com");
  std::ignore = dns_resolver_config.mutable_typed_config()->PackFrom(config);
  builder_.setDnsResolver(dns_resolver_config);

  initialize();
  default_request_headers_.setHost(
      absl::StrCat("www.doesnotexist.com:", fake_upstreams_[0]->localAddress()->ip()->port()));
  stream_ = stream_prototype_->start(createDefaultStreamCallbacks(), explicit_flow_control_);
  stream_->sendHeaders(std::make_unique<Http::TestRequestHeaderMapImpl>(default_request_headers_),
                       true);
  terminal_callback_.waitReady();

  // The stream should fail.
  ASSERT_EQ(cc_.on_error_calls_, 1);

  // A new stream will kick off a new resolution because the address was null.
  stream_ = createNewStream(createDefaultStreamCallbacks());
  stream_->sendHeaders(std::make_unique<Http::TestRequestHeaderMapImpl>(default_request_headers_),
                       true);
  terminal_callback_.waitReady();
}

TEST_P(ClientIntegrationTest, ReresolveAndDrain) {
  expect_data_streams_ = false; // 0-RTT request might skip some fields in final stream intel.
  builder_.enableDrainPostDnsRefresh(true);
  // 0-RTT requests will not populate some of the final stream intel fields, so skip the validation.
  expect_data_streams_ = false;
  add_fake_dns_ = true;
  Network::OverrideAddrInfoDnsResolverFactory factory;
  Registry::InjectFactory<Network::DnsResolverFactory> inject_factory(factory);
  Registry::InjectFactory<Network::DnsResolverFactory>::forceAllowDuplicates();

  initialize();
  if (version_ != Network::Address::IpVersion::v4) {
    return; // This test relies on ipv4 loopback.
  }

  auto next_address = Network::Utility::parseInternetAddressNoThrow(
      "127.0.0.3", fake_upstreams_[0]->localAddress()->ip()->port());
  // This will hopefully be miniminally flaky because of low use of 127.0.0.3
  // but may need to be disabled.
  createUpstream(next_address, upstreamConfig());
  ASSERT_EQ(fake_upstreams_.size(), 3);

  // Make the "original" upstream and reresolve upstream return different errors.
  auto* au = reinterpret_cast<AutonomousUpstream*>(fake_upstreams_[0].get());
  au->setResponseHeaders(std::make_unique<Http::TestResponseHeaderMapImpl>(
      Http::TestResponseHeaderMapImpl({{":status", "201"}})));
  au = reinterpret_cast<AutonomousUpstream*>(fake_upstreams_[2].get());
  au->setResponseHeaders(std::make_unique<Http::TestResponseHeaderMapImpl>(
      Http::TestResponseHeaderMapImpl({{":status", "202"}})));

  // Send a request. The original upstream should be used because of DNS block.
  default_request_headers_.setHost(
      absl::StrCat("www.lyft.com:", fake_upstreams_[0]->localAddress()->ip()->port()));
  stream_ = createNewStream(createDefaultStreamCallbacks());
  stream_->sendHeaders(std::make_unique<Http::TestRequestHeaderMapImpl>(default_request_headers_),
                       true);
  terminal_callback_.waitReady();
  ASSERT_EQ(cc_.status_, "201");
  // No DNS queries, because of the initial cache load.
  EXPECT_EQ(0, getCounterValue("dns_cache.base_dns_cache.dns_query_attempt"));
  EXPECT_EQ(1, getCounterValue("dns_cache.base_dns_cache.cache_load"));

  // Reset connectivity state. This should force a resolve but we will not
  // unblock it.
  {
    absl::MutexLock l(engine_lock_);
    engine_->engine()->resetConnectivityState();
  }

  // Make sure the attempt happened.
  ASSERT_TRUE(waitForCounter("dns_cache.base_dns_cache.dns_query_attempt", Ge(1)));
  EXPECT_EQ(0, getCounterValue("dns_cache.base_dns_cache.dns_query_success"));
  // The next request should go to the original upstream as there's been no drain.
  stream_ = createNewStream(createDefaultStreamCallbacks());
  stream_->sendHeaders(std::make_unique<Http::TestRequestHeaderMapImpl>(default_request_headers_),
                       true);
  terminal_callback_.waitReady();
  ASSERT_EQ(cc_.status_, "201");
  // No DNS query should have finished.
  EXPECT_EQ(0, getCounterValue("dns_cache.base_dns_cache.dns_query_success"));

  // Force the lookup to resolve to localhost.
  // Unblock the resolution and wait for it to succeed.
  Network::TestResolver::unblockResolve("127.0.0.3");
  ASSERT_TRUE(waitForCounter("dns_cache.base_dns_cache.dns_query_success", Ge(1)));

  // Do one final request. It should go to the second upstream and return 202
  stream_ = createNewStream(createDefaultStreamCallbacks());
  stream_->sendHeaders(std::make_unique<Http::TestRequestHeaderMapImpl>(default_request_headers_),
                       true);
  terminal_callback_.waitReady();
  ASSERT_EQ(cc_.status_, "202");
}

TEST_P(ClientIntegrationTest, BasicBeforeResponseHeaders) {
  initialize();

  default_request_headers_.addCopy(AutonomousStream::RESET_AFTER_REQUEST, "yes");

  stream_ = createNewStream(createDefaultStreamCallbacks());
  stream_->sendHeaders(std::make_unique<Http::TestRequestHeaderMapImpl>(default_request_headers_),
                       true);
  terminal_callback_.waitReady();

  ASSERT_EQ(cc_.on_error_calls_, 1);
  ASSERT_EQ(cc_.on_headers_calls_, 0);
}

TEST_P(ClientIntegrationTest, ExplicitBeforeResponseHeaders) {
  explicit_flow_control_ = true;
  initialize();

  default_request_headers_.addCopy(AutonomousStream::RESET_AFTER_REQUEST, "yes");

  stream_ = createNewStream(createDefaultStreamCallbacks());
  stream_->sendHeaders(std::make_unique<Http::TestRequestHeaderMapImpl>(default_request_headers_),
                       true);
  terminal_callback_.waitReady();

  ASSERT_EQ(cc_.on_error_calls_, 1);
  ASSERT_EQ(cc_.on_headers_calls_, 0);
}

TEST_P(ClientIntegrationTest, ResetAfterResponseHeaders) {
  autonomous_allow_incomplete_streams_ = true;
  initialize();

  default_request_headers_.addCopy(AutonomousStream::RESET_AFTER_RESPONSE_HEADERS, "yes");
  default_request_headers_.addCopy(AutonomousStream::RESPONSE_DATA_BLOCKS, "1");

  stream_ = createNewStream(createDefaultStreamCallbacks());
  stream_->sendHeaders(std::make_unique<Http::TestRequestHeaderMapImpl>(default_request_headers_),
                       true);
  terminal_callback_.waitReady();

  ASSERT_EQ(cc_.on_error_calls_, 1);
}

TEST_P(ClientIntegrationTest, ResetAfterResponseHeadersExplicit) {
  explicit_flow_control_ = true;
  autonomous_allow_incomplete_streams_ = true;
  initialize();

  default_request_headers_.addCopy(AutonomousStream::RESET_AFTER_RESPONSE_HEADERS, "yes");
  default_request_headers_.addCopy(AutonomousStream::RESPONSE_DATA_BLOCKS, "1");

  stream_ = createNewStream(createDefaultStreamCallbacks());
  stream_->sendHeaders(std::make_unique<Http::TestRequestHeaderMapImpl>(default_request_headers_),
                       true);
  // Read the body chunk. This releases the error.
  stream_->readData(100);

  terminal_callback_.waitReady();

  ASSERT_EQ(cc_.on_error_calls_, 1);
}

TEST_P(ClientIntegrationTest, ResetAfterHeaderOnlyResponse) {
  autonomous_allow_incomplete_streams_ = true;
  initialize();

  default_request_headers_.addCopy(AutonomousStream::RESET_AFTER_RESPONSE_HEADERS, "yes");
  default_request_headers_.addCopy(AutonomousStream::RESPONSE_DATA_BLOCKS, "0");

  stream_ = createNewStream(createDefaultStreamCallbacks());
  stream_->sendHeaders(std::make_unique<Http::TestRequestHeaderMapImpl>(default_request_headers_),
                       false);
  terminal_callback_.waitReady();

  ASSERT_EQ(cc_.on_error_calls_, 1);
}

TEST_P(ClientIntegrationTest, ResetBetweenDataChunks) {
  autonomous_allow_incomplete_streams_ = true;
  initialize();

  default_request_headers_.addCopy(AutonomousStream::RESET_AFTER_RESPONSE_DATA, "yes");
  default_request_headers_.addCopy(AutonomousStream::RESPONSE_DATA_BLOCKS, "2");

  stream_ = createNewStream(createDefaultStreamCallbacks());
  stream_->sendHeaders(std::make_unique<Http::TestRequestHeaderMapImpl>(default_request_headers_),
                       true);
  terminal_callback_.waitReady();

  ASSERT_EQ(cc_.on_error_calls_, 1);
}

TEST_P(ClientIntegrationTest, ResetAfterDataExplicit) {
  explicit_flow_control_ = true;

  autonomous_allow_incomplete_streams_ = true;
  initialize();

  default_request_headers_.addCopy(AutonomousStream::RESET_AFTER_RESPONSE_DATA, "yes");
  default_request_headers_.addCopy(AutonomousStream::RESPONSE_DATA_BLOCKS, "1");

  auto callbacks = createDefaultStreamCallbacks();
  stream_ = createNewStream(std::move(callbacks));
  stream_->sendHeaders(std::make_unique<Http::TestRequestHeaderMapImpl>(default_request_headers_),
                       true);

  // Allow passing up the data and error
  stream_->readData(100);
  terminal_callback_.waitReady();

  ASSERT_EQ(cc_.on_data_calls_, 1);
  ASSERT_EQ(cc_.on_error_calls_, 1);
}

TEST_P(ClientIntegrationTest, ResetAfterDataExplicitMultipleChunks) {
  explicit_flow_control_ = true;

  autonomous_allow_incomplete_streams_ = true;
  initialize();

  default_request_headers_.addCopy(AutonomousStream::RESET_AFTER_RESPONSE_DATA, "yes");
  default_request_headers_.addCopy(AutonomousStream::RESPONSE_DATA_BLOCKS, "1");

  auto callbacks = createDefaultStreamCallbacks();
  ConditionalInitializer initial_data;
  callbacks.on_data_ = [this, &initial_data](const Buffer::Instance&, uint64_t /* length */,
                                             bool /* end_stream */, envoy_stream_intel) {
    if (!cc_.on_data_calls_) {
      initial_data.setReady();
    }
    cc_.on_data_calls_++;
  };

  stream_ = createNewStream(std::move(callbacks));
  stream_->sendHeaders(std::make_unique<Http::TestRequestHeaderMapImpl>(default_request_headers_),
                       true);

  // Default body size is 10 - this will force 2 reads.
  stream_->readData(5);
  initial_data.waitReady();
  stream_->readData(5);
  terminal_callback_.waitReady();

  // Make sure we get both chunks before flushing the error.
  ASSERT_EQ(cc_.on_data_calls_, 2);
  ASSERT_EQ(cc_.on_error_calls_, 1);
}

TEST_P(ClientIntegrationTest, CancelBeforeRequestHeadersSent) {
  autonomous_upstream_ = false;
  initialize();

  stream_ = createNewStream(createDefaultStreamCallbacks());
  stream_->cancel();

  terminal_callback_.waitReady();

  ASSERT_EQ(cc_.on_cancel_calls_, 1);
}

TEST_P(ClientIntegrationTest, CancelAfterRequestHeadersSent) {
  initialize();

  default_request_headers_.addCopy(AutonomousStream::RESPOND_AFTER_REQUEST_HEADERS, "yes");

  stream_ = createNewStream(createDefaultStreamCallbacks());
  stream_->sendHeaders(std::make_unique<Http::TestRequestHeaderMapImpl>(default_request_headers_),
                       false);
  stream_->cancel();
  terminal_callback_.waitReady();
  ASSERT_EQ(cc_.on_cancel_calls_, 1);
}

TEST_P(ClientIntegrationTest, CancelAfterRequestComplete) {
  autonomous_upstream_ = false;
  initialize();

  stream_ = createNewStream(createDefaultStreamCallbacks());
  stream_->sendHeaders(std::make_unique<Http::TestRequestHeaderMapImpl>(default_request_headers_),
                       true);
  stream_->cancel();
  terminal_callback_.waitReady();
  ASSERT_EQ(cc_.on_cancel_calls_, 1);
}

TEST_P(ClientIntegrationTest, CancelDuringResponse) {
  autonomous_upstream_ = false;
  initialize();
  ConditionalInitializer headers_callback;

  EnvoyStreamCallbacks stream_callbacks = createDefaultStreamCallbacks();
  stream_callbacks.on_headers_ = [this, &headers_callback](const Http::ResponseHeaderMap& headers,
                                                           bool /* end_stream */,
                                                           envoy_stream_intel) {
    cc_.status_ = headers.getStatusValue();
    cc_.on_headers_calls_++;
    headers_callback.setReady();
    return nullptr;
  };

  stream_ = createNewStream(std::move(stream_callbacks));
  stream_->sendHeaders(std::make_unique<Http::TestRequestHeaderMapImpl>(default_request_headers_),
                       true);

  ASSERT_TRUE(fake_upstreams_[0]->waitForHttpConnection(*BaseIntegrationTest::dispatcher_,
                                                        upstream_connection_));
  ASSERT_TRUE(
      upstream_connection_->waitForNewStream(*BaseIntegrationTest::dispatcher_, upstream_request_));
  // Send an incomplete response.
  upstream_request_->encodeHeaders(Http::TestResponseHeaderMapImpl{{":status", "200"}}, false);

  headers_callback.waitReady();
  ASSERT_EQ(cc_.on_headers_calls_, 1);
  ASSERT_EQ(cc_.status_, "200");
  ASSERT_EQ(cc_.on_data_calls_, 0);
  ASSERT_EQ(cc_.on_complete_calls_, 0);

  // Now cancel, and make sure the cancel is received.
  stream_->cancel();
  memset(&cc_.final_intel_, 0, sizeof(cc_.final_intel_));
  terminal_callback_.waitReady();

  ASSERT_EQ(cc_.on_headers_calls_, 1);
  ASSERT_EQ(cc_.status_, "200");
  ASSERT_EQ(cc_.on_data_calls_, 0);
  ASSERT_EQ(cc_.on_complete_calls_, 0);
  ASSERT_EQ(cc_.on_cancel_calls_, 1);

  if (upstreamProtocol() != Http::CodecType::HTTP1) {
    ASSERT_TRUE(upstream_request_->waitForReset());
  }

  // Close the HTTP3 connection and verify stats are dumped properly.
  if (getCodecType() == Http::CodecType::HTTP3) {
    ASSERT_TRUE(upstream_connection_->close());
    ASSERT_TRUE(upstream_connection_->waitForDisconnect());
    upstream_connection_.reset();
    ASSERT_TRUE(
        waitForCounter("http3.upstream.tx.quic_connection_close_error_code_QUIC_NO_ERROR", Ge(1)));
    ASSERT_TRUE(waitForCounter(
        "http3.upstream.tx.quic_reset_stream_error_code_QUIC_STREAM_REQUEST_REJECTED", Ge(1)));
  }
}

TEST_P(ClientIntegrationTest, BasicCancelWithCompleteStream) {
  autonomous_upstream_ = false;

  initialize();

  stream_ = createNewStream(createDefaultStreamCallbacks());
  stream_->sendHeaders(std::make_unique<Http::TestRequestHeaderMapImpl>(default_request_headers_),
                       true);

  ASSERT_TRUE(fake_upstreams_[0]->waitForHttpConnection(*BaseIntegrationTest::dispatcher_,
                                                        upstream_connection_));
  ASSERT_TRUE(
      upstream_connection_->waitForNewStream(*BaseIntegrationTest::dispatcher_, upstream_request_));
  upstream_request_->encodeHeaders(Http::TestResponseHeaderMapImpl{{":status", "200"}}, true);

  terminal_callback_.waitReady();
  ASSERT_EQ(cc_.on_headers_calls_, 1);
  ASSERT_EQ(cc_.status_, "200");
  ASSERT_EQ(cc_.on_complete_calls_, 1);

  // Now cancel. As on_complete has been called cancel is a no-op but is
  // non-problematic.
  stream_->cancel();
}

TEST_P(ClientIntegrationTest, CancelWithPartialStream) {
  autonomous_upstream_ = false;
  explicit_flow_control_ = true;
  initialize();
  ConditionalInitializer headers_callback;

  EnvoyStreamCallbacks stream_callbacks = createDefaultStreamCallbacks();
  stream_callbacks.on_headers_ = [this, &headers_callback](const Http::ResponseHeaderMap& headers,
                                                           bool /* end_stream */,
                                                           envoy_stream_intel) {
    cc_.status_ = headers.getStatusValue();
    cc_.on_headers_calls_++;
    headers_callback.setReady();
    return nullptr;
  };

  stream_ = createNewStream(std::move(stream_callbacks));
  stream_->sendHeaders(std::make_unique<Http::TestRequestHeaderMapImpl>(default_request_headers_),
                       true);

  ASSERT_TRUE(fake_upstreams_[0]->waitForHttpConnection(*BaseIntegrationTest::dispatcher_,
                                                        upstream_connection_));
  ASSERT_TRUE(
      upstream_connection_->waitForNewStream(*BaseIntegrationTest::dispatcher_, upstream_request_));

  // Send a complete response with body.
  upstream_request_->encodeHeaders(Http::TestResponseHeaderMapImpl{{":status", "200"}}, false);
  upstream_request_->encodeData(1, true);

  headers_callback.waitReady();
  ASSERT_EQ(cc_.on_headers_calls_, 1);
  ASSERT_EQ(cc_.status_, "200");
  ASSERT_EQ(cc_.on_data_calls_, 0);
  ASSERT_EQ(cc_.on_complete_calls_, 0);

  // Due to explicit flow control, the upstream stream is complete, but the
  // callbacks will not be called for data and completion. Cancel the stream
  // and make sure the cancel is received.
  stream_->cancel();
  terminal_callback_.waitReady();

  ASSERT_EQ(cc_.on_headers_calls_, 1);
  ASSERT_EQ(cc_.status_, "200");
  ASSERT_EQ(cc_.on_data_calls_, 0);
  ASSERT_EQ(cc_.on_complete_calls_, 0);
  ASSERT_EQ(cc_.on_cancel_calls_, 1);
}

// Test header key case sensitivity.
TEST_P(ClientIntegrationTest, CaseSensitive) {
  if (getCodecType() != Http::CodecType::HTTP1) {
    return;
  }
  autonomous_upstream_ = false;
  initialize();

  auto headers = Http::Utility::createRequestHeaderMapPtr();
  HttpTestUtility::addDefaultHeaders(*headers);
  headers->setHost(fake_upstreams_[0]->localAddress()->asStringView());
  Http::StatefulHeaderKeyFormatter& formatter = headers->formatter().value();
  formatter.processKey("FoO");
  headers->addCopy(Http::LowerCaseString("FoO"), "bar");

  EnvoyStreamCallbacks stream_callbacks = createDefaultStreamCallbacks();
  stream_callbacks.on_headers_ = [this](const Http::ResponseHeaderMap& headers, bool,
                                        envoy_stream_intel) {
    cc_.status_ = headers.getStatusValue();
    cc_.on_headers_calls_++;
    auto result = headers.get(Http::LowerCaseString("My-ResponsE-Header"));
    ASSERT_FALSE(result.empty());
    EXPECT_TRUE(result[0]->value() == "foo");
  };

  stream_ = createNewStream(std::move(stream_callbacks));
  stream_->sendHeaders(std::move(headers), true);

  Envoy::FakeRawConnectionPtr upstream_connection;
  ASSERT_TRUE(fake_upstreams_[0]->waitForRawConnection(upstream_connection));

  // Verify that the upstream request has preserved cased headers.
  std::string upstream_request;
  EXPECT_TRUE(upstream_connection->waitForData(FakeRawConnection::waitForInexactMatch("GET /"),
                                               &upstream_request));
  EXPECT_TRUE(absl::StrContains(upstream_request, "FoO: bar")) << upstream_request;

  // Send mixed case headers, and verify via setOnHeaders they are received correctly.
  auto response = "HTTP/1.1 200 OK\r\nContent-Length: 0\r\nMy-ResponsE-Header: foo\r\n\r\n";
  ASSERT_TRUE(upstream_connection->write(response));

  terminal_callback_.waitReady();

  ASSERT_EQ(cc_.on_headers_calls_, 1);
  ASSERT_EQ(cc_.status_, "200");
  ASSERT_EQ(cc_.on_data_calls_, 0);
  ASSERT_EQ(cc_.on_complete_calls_, 1);
}

TEST_P(ClientIntegrationTest, TimeoutOnRequestPath) {
  builder_.setStreamIdleTimeoutSeconds(1);

  autonomous_upstream_ = false;
  initialize();

  stream_ = createNewStream(createDefaultStreamCallbacks());
  stream_->sendHeaders(std::make_unique<Http::TestRequestHeaderMapImpl>(default_request_headers_),
                       false);

  ASSERT_TRUE(fake_upstreams_[0]->waitForHttpConnection(*BaseIntegrationTest::dispatcher_,
                                                        upstream_connection_));
  ASSERT_TRUE(
      upstream_connection_->waitForNewStream(*BaseIntegrationTest::dispatcher_, upstream_request_));

  terminal_callback_.waitReady();

  ASSERT_EQ(cc_.on_headers_calls_, 0);
  ASSERT_EQ(cc_.on_data_calls_, 0);
  ASSERT_EQ(cc_.on_complete_calls_, 0);
  ASSERT_EQ(cc_.on_error_calls_, 1);

  if (getCodecType() != Http::CodecType::HTTP1) {
    ASSERT_TRUE(upstream_request_->waitForReset());
  } else {
    ASSERT_TRUE(upstream_connection_->waitForDisconnect());
  }
}

TEST_P(ClientIntegrationTest, TimeoutOnResponsePath) {
  builder_.setStreamIdleTimeoutSeconds(1);
  autonomous_upstream_ = false;
  initialize();

  stream_ = createNewStream(createDefaultStreamCallbacks());
  stream_->sendHeaders(std::make_unique<Http::TestRequestHeaderMapImpl>(default_request_headers_),
                       true);

  ASSERT_TRUE(fake_upstreams_[0]->waitForHttpConnection(*BaseIntegrationTest::dispatcher_,
                                                        upstream_connection_));
  ASSERT_TRUE(
      upstream_connection_->waitForNewStream(*BaseIntegrationTest::dispatcher_, upstream_request_));

  // Send response headers but no body.
  upstream_request_->encodeHeaders(Http::TestResponseHeaderMapImpl{{":status", "200"}}, false);

  // Wait for timeout.
  terminal_callback_.waitReady();

  ASSERT_EQ(cc_.on_headers_calls_, 1);
  ASSERT_EQ(cc_.status_, "200");
  ASSERT_EQ(cc_.on_data_calls_, 0);
  ASSERT_EQ(cc_.on_complete_calls_, 0);
  ASSERT_EQ(cc_.on_error_calls_, 1);

  if (upstreamProtocol() != Http::CodecType::HTTP1) {
    ASSERT_TRUE(upstream_request_->waitForReset());
  }
}

TEST_P(ClientIntegrationTest, ResetWithBidiTraffic) {
  autonomous_upstream_ = false;
  initialize();
  ConditionalInitializer headers_callback;

  EnvoyStreamCallbacks stream_callbacks = createDefaultStreamCallbacks();
  stream_callbacks.on_headers_ = [this, &headers_callback](const Http::ResponseHeaderMap& headers,
                                                           bool /* end_stream */,
                                                           envoy_stream_intel) {
    cc_.status_ = headers.getStatusValue();
    cc_.on_headers_calls_++;
    headers_callback.setReady();
    return nullptr;
  };

  stream_ = createNewStream(std::move(stream_callbacks));
  stream_->sendHeaders(std::make_unique<Http::TestRequestHeaderMapImpl>(default_request_headers_),
                       false);

  ASSERT_TRUE(fake_upstreams_[0]->waitForHttpConnection(*BaseIntegrationTest::dispatcher_,
                                                        upstream_connection_));
  ASSERT_TRUE(
      upstream_connection_->waitForNewStream(*BaseIntegrationTest::dispatcher_, upstream_request_));

  // Send response headers but no body.
  upstream_request_->encodeHeaders(Http::TestResponseHeaderMapImpl{{":status", "200"}}, false);
  // Make sure the headers are sent up.
  headers_callback.waitReady();
  // Reset the stream.
  upstream_request_->encodeResetStream();

  // Encoding data should not be problematic.
  stream_->sendData(std::make_unique<Buffer::OwnedImpl>("request body"));
  // Make sure cancel isn't problematic.
  stream_->cancel();
}

TEST_P(ClientIntegrationTest, ResetWithBidiTrafficExplicitData) {
  explicit_flow_control_ = true;
  autonomous_upstream_ = false;
  initialize();
  ConditionalInitializer headers_callback;

  EnvoyStreamCallbacks stream_callbacks = createDefaultStreamCallbacks();
  stream_callbacks.on_headers_ = [this, &headers_callback](const Http::ResponseHeaderMap& headers,
                                                           bool /* end_stream */,
                                                           envoy_stream_intel) {
    cc_.status_ = headers.getStatusValue();
    cc_.on_headers_calls_++;
    headers_callback.setReady();
    return nullptr;
  };

  stream_ = createNewStream(std::move(stream_callbacks));
  stream_->sendHeaders(std::make_unique<Http::TestRequestHeaderMapImpl>(default_request_headers_),
                       false);

  ASSERT_TRUE(fake_upstreams_[0]->waitForHttpConnection(*BaseIntegrationTest::dispatcher_,
                                                        upstream_connection_));
  ASSERT_TRUE(
      upstream_connection_->waitForNewStream(*BaseIntegrationTest::dispatcher_, upstream_request_));

  // Send response headers and body but no fin.
  upstream_request_->encodeHeaders(Http::TestResponseHeaderMapImpl{{":status", "200"}}, false);
  upstream_request_->encodeData(1, false);
  upstream_request_->encodeResetStream();
  // Make sure the headers are sent up.
  headers_callback.waitReady();

  // Encoding data should not be problematic.
  stream_->sendData(std::make_unique<Buffer::OwnedImpl>("request body"));
  // Make sure cancel isn't problematic.
  stream_->cancel();
}

TEST_P(ClientIntegrationTest, Proxying) {
  if (getCodecType() != Http::CodecType::HTTP1 || getUseWorkerThread()) {
    return;
  }
  initialize();
  {
    absl::MutexLock l(engine_lock_);
    engine_->engine()->setProxySettings(fake_upstreams_[0]->localAddress()->asString().c_str(),
                                        fake_upstreams_[0]->localAddress()->ip()->port());
  }

  stream_ = createNewStream(createDefaultStreamCallbacks());
  // The initial request will do the DNS lookup.
  stream_->sendHeaders(std::make_unique<Http::TestRequestHeaderMapImpl>(default_request_headers_),
                       true);
  terminal_callback_.waitReady();
  ASSERT_EQ(cc_.status_, "200");
  ASSERT_EQ(cc_.on_complete_calls_, 1);
  stream_.reset();

  // The second request will use the cached DNS entry and should succeed as well.
  stream_ = createNewStream(createDefaultStreamCallbacks());
  stream_->sendHeaders(std::make_unique<Http::TestRequestHeaderMapImpl>(default_request_headers_),
                       true);
  terminal_callback_.waitReady();
  ASSERT_EQ(cc_.status_, "200");
  ASSERT_EQ(cc_.on_complete_calls_, 2);
}

TEST_P(ClientIntegrationTest, TestRuntimeSet) {
  builder_.addRuntimeGuard("test_feature_true", false);
  builder_.addRuntimeGuard("test_feature_false", true);
  initialize();

  // Verify that the Runtime config values are from the RTDS response.
  EXPECT_TRUE(Runtime::runtimeFeatureEnabled("envoy.reloadable_features.test_feature_false"));
  EXPECT_FALSE(Runtime::runtimeFeatureEnabled("envoy.reloadable_features.test_feature_true"));
}

TEST_P(ClientIntegrationTest, TestStats) {
  initialize();

  {
    absl::MutexLock l(engine_lock_);
    std::string stats = engine_->dumpStats();
    EXPECT_TRUE((absl::StrContains(stats, "runtime.load_success: 2"))) << stats;
  }
}

#if defined(__APPLE__)
TEST_P(ClientIntegrationTest, TestProxyResolutionApi) {
  if (getUseWorkerThread()) {
    return;
  }
  builder_.respectSystemProxySettings(true);
  initialize();
  ASSERT_TRUE(Envoy::Api::External::retrieveApi("envoy_proxy_resolver") != nullptr);
}
#endif

// This test is simply to test the IPv6 connectivity check and DNS refresh and make sure the code
// doesn't crash. It doesn't really test the actual network change event.
TEST_P(ClientIntegrationTest, OnNetworkChanged) {
  builder_.addRuntimeGuard("dns_cache_set_ip_version_to_remove", true);
  if (getCodecType() == Http::CodecType::HTTP3) {
    builder_.setDisableDnsRefreshOnNetworkChange(true);
  }
  initialize();
  internalEngine()->onDefaultNetworkChanged(1);
  basicTest();
  if (upstreamProtocol() == Http::CodecType::HTTP1) {
    ASSERT_EQ(cc_.on_complete_received_byte_count_, 67);
  }
}

// This test is simply to test the IPv6 connectivity check and DNS refresh and make sure the code
// doesn't crash. It doesn't really test the actual network change event.
TEST_P(ClientIntegrationTest, OnNetworkChangeEvent) {
  builder_.addRuntimeGuard("dns_cache_set_ip_version_to_remove", true);
  if (getCodecType() == Http::CodecType::HTTP3) {
    builder_.setDisableDnsRefreshOnNetworkChange(true);
  }
  initialize();
  int network = 0;
  network |= static_cast<int>(NetworkType::WWAN);
  network |= static_cast<int>(NetworkType::WWAN_5G);
  internalEngine()->onDefaultNetworkChangeEvent(network);
  basicTest();
  if (upstreamProtocol() == Http::CodecType::HTTP1) {
    ASSERT_EQ(cc_.on_complete_received_byte_count_, 67);
  }
}

// A thread-safe implementation which can fake SOCKET_ERROR_NOBUFS send errors.
class MockSendOsSysCalls : public Api::OsSysCallsImpl {
public:
  MockSendOsSysCalls() {
    ON_CALL(*this, send(_, _, _, _))
        .WillByDefault([this](os_fd_t socket, void* buffer, size_t length, int flags) {
          int target = target_fd_.load();
          if (fail_send_.load() && (target == -1 || socket == target)) {
            bool expected = true;
            if (fail_send_.compare_exchange_strong(expected, false)) {
              return Api::SysCallSizeResult{-1, SOCKET_ERROR_NOBUFS};
            }
          }
          return Api::OsSysCallsImpl::send(socket, buffer, length, flags);
        });
  }

  MOCK_METHOD(Api::SysCallSizeResult, send,
              (os_fd_t socket, void* buffer, size_t length, int flags), (override));

  std::atomic<bool> fail_send_{false};
  std::atomic<int> target_fd_{-1};
};

// Tests that a transient write error due to no space available on the socket
// does not cause the stream to error out when using HTTP/3.
TEST_P(ClientIntegrationTest, NoSpaceAvailableWriteErrorSwallowed) {
  testing::NiceMock<MockSendOsSysCalls> sys_calls;
  TestThreadsafeSingletonInjector<Api::OsSysCallsImpl> injector(&sys_calls);

  initialize();
  if (upstreamProtocol() != Http::CodecType::HTTP3) {
    return;
  }
  // Create a stream with a write buffer limit of 1 byte to trigger the error.
  EnvoyStreamCallbacks stream_callbacks = createDefaultStreamCallbacks();
  stream_ = createNewStream(std::move(stream_callbacks));

  int fd = -1;
  EXPECT_CALL(helper_handle_->mock_helper(), bindSocketToNetwork(_, 1))
      .WillOnce(Invoke([&](Network::ConnectionSocket& socket, int /* network */) {
        fd = socket.ioHandle().fdDoNotUse();
      }));
  // Sending headers should be fine.
  stream_->sendHeaders(std::make_unique<Http::TestRequestHeaderMapImpl>(default_request_headers_),
                       false);

  // Sending data should trigger the write error but not crash.
  stream_->sendData(std::make_unique<Buffer::OwnedImpl>("request body"));

  // Wait for the upstream connection to be created and introduce a transient SOCKET_ERROR_NOBUFS
  // write error.
  ASSERT_TRUE(waitForCounter("cluster.base.upstream_cx_http3_total", Ge(1)));
  sys_calls.target_fd_.store(fd);
  sys_calls.fail_send_.store(true);

  // Complete the request.
  stream_->close(Http::Utility::createRequestTrailerMapPtr());
  terminal_callback_.waitReady();

  // The write error shouldn't have caused a stream error.
  ASSERT_EQ(cc_.on_error_calls_, 0);
  ASSERT_EQ(cc_.on_complete_calls_, 1);
  EXPECT_EQ(cc_.status_, "200");

  // Join background threads before local injector and mocks are destroyed to avoid TSAN data races.
  TearDown();
}

TEST_P(ClientIntegrationTest, HttpsWithEarlyData) {
  // Dummy comment to invalidate cache
  if (getCodecType() != Http::CodecType::HTTP3 ||
      !Runtime::runtimeFeatureEnabled("envoy.reloadable_features.fix_http3_early_data_timing")) {
    return;
  }
  EXPECT_CALL(helper_handle_->mock_helper(), isCleartextPermitted(_)).Times(0);
  EXPECT_CALL(helper_handle_->mock_helper(), validateCertificateChain(_, _)).Times(AnyNumber());
  EXPECT_CALL(helper_handle_->mock_helper(), cleanupAfterCertificateValidation())
      .Times(AnyNumber());

  autonomous_upstream_ = false;

  initialize();
  default_request_headers_.setScheme("https");
  stream_ = createNewStream(createDefaultStreamCallbacks());
  stream_->sendHeaders(std::make_unique<Http::TestRequestHeaderMapImpl>(default_request_headers_),
                       true);

  ASSERT_TRUE(fake_upstreams_[0]->waitForHttpConnection(*BaseIntegrationTest::dispatcher_,
                                                        upstream_connection_));
  ASSERT_TRUE(
      upstream_connection_->waitForNewStream(*BaseIntegrationTest::dispatcher_, upstream_request_));
  ASSERT_TRUE(upstream_request_->waitForEndStream(*BaseIntegrationTest::dispatcher_));
  upstream_request_->encodeHeaders(Http::TestResponseHeaderMapImpl{{":status", "200"}}, false);
  upstream_request_->encodeData(10, true);

  terminal_callback_.waitReady();

  ASSERT_EQ(cc_.on_headers_calls_, 1);
  ASSERT_EQ(cc_.status_, "200");
  ASSERT_GE(cc_.on_data_calls_, 1);
  ASSERT_EQ(cc_.on_complete_calls_, 1);
  EXPECT_EQ(0, getCounterValue("cluster.base.upstream_cx_connect_with_0_rtt"));

  // Wait for session ticket to be received (QUIC sends it after handshake)
  timeSystem().realSleepDoNotUseWithoutScrutiny(std::chrono::milliseconds(500));

  int old_upstream_cx_destroy = getCounterValue("cluster.base.upstream_cx_destroy");
  // Close connection to force reconnect and use session ticket
  ASSERT_TRUE(upstream_connection_->close());
  ASSERT_TRUE(upstream_connection_->waitForDisconnect());
  upstream_connection_.reset();
  ASSERT_TRUE(waitForCounter("cluster.base.upstream_cx_destroy", Ge(old_upstream_cx_destroy + 1)));

  // Reset terminal callback for the second request.
  ConditionalInitializer terminal_callback;
  cc_.terminal_callback_ = &terminal_callback;
  // Skip validating final stream intel for the second request.
  expect_data_streams_ = false;

  default_request_headers_.addCopy("second_request", "1");
  stream_ = createNewStream(createDefaultStreamCallbacks());
  stream_->sendHeaders(std::make_unique<Http::TestRequestHeaderMapImpl>(default_request_headers_),
                       true);

  // Handle second request on upstream
  ASSERT_TRUE(fake_upstreams_[0]->waitForHttpConnection(*BaseIntegrationTest::dispatcher_,
                                                        upstream_connection_));
  ASSERT_TRUE(
      upstream_connection_->waitForNewStream(*BaseIntegrationTest::dispatcher_, upstream_request_));
  ASSERT_TRUE(upstream_request_->waitForEndStream(*BaseIntegrationTest::dispatcher_));
  upstream_request_->encodeHeaders(Http::TestResponseHeaderMapImpl{{":status", "200"}}, false);
  upstream_request_->encodeData(10, true);

  terminal_callback.waitReady();

  ASSERT_EQ(cc_.on_headers_calls_, 2);
  ASSERT_EQ(cc_.status_, "200");

  EXPECT_EQ(1, getCounterValue("cluster.base.upstream_cx_connect_with_0_rtt"));
  if (Runtime::runtimeFeatureEnabled("envoy.reloadable_features.fix_http3_early_data_timing")) {
    EXPECT_EQ(1, getCounterValue("cluster.base.upstream_rq_0rtt"));
  }
}

class MockRecvMsgOsSysCalls : public Api::OsSysCallsImpl {
public:
  MockRecvMsgOsSysCalls() {
    ON_CALL(*this, recvmsg(_, _, _))
        .WillByDefault(Invoke([this](os_fd_t sockfd, msghdr* msg, int flags) {
          auto result = Api::OsSysCallsImpl::recvmsg(sockfd, msg, flags);
          int16_t bandwidth = scone_bandwidth_.exchange(-1);
          if (result.return_value_ <= 0 || bandwidth == -1) {
            return result;
          }

          std::vector<char> new_buffer(result.return_value_);
          if (quic::test::MaybeUpdateSconePacket(
                  reinterpret_cast<const char*>(msg->msg_iov[0].iov_base), new_buffer.data(),
                  result.return_value_, static_cast<uint8_t>(bandwidth))) {
            memcpy(msg->msg_iov[0].iov_base, new_buffer.data(), result.return_value_);
          }
          return result;
        }));
  }

  MOCK_METHOD(Api::SysCallSizeResult, recvmsg, (os_fd_t sockfd, msghdr* msg, int flags),
              (override));

  std::atomic<int16_t> scone_bandwidth_{-1};
};

TEST_P(ClientIntegrationTest, SconeValuePropagation) {
  if (upstreamProtocol() != Http::CodecType::HTTP3) {
    return;
  }

  const int16_t bandwidth_initial = 127;
  const int16_t bandwidth_throttled = 50;

  MockRecvMsgOsSysCalls sys_calls;
  TestThreadsafeSingletonInjector<Api::OsSysCallsImpl> injector(&sys_calls);

  builder_.enableScone(true);
  initialize();

  // 1. Stream 1: Receives initial bandwidth (127 kbps)
  int64_t captured_scone_max_kbps1 = -1;
  int64_t captured_scone_timestamp_ms1 = -1;
  uint64_t connection_id_1 = 0;

  EnvoyStreamCallbacks stream_callbacks1 = createDefaultStreamCallbacks();
  stream_callbacks1.on_headers_ = [&](const Http::ResponseHeaderMap& headers, bool,
                                      envoy_stream_intel intel) {
    cc_.on_headers_calls_++;
    cc_.status_ = absl::StrCat(headers.getStatusValue());
    captured_scone_max_kbps1 = intel.scone_max_kbps;
    captured_scone_timestamp_ms1 = intel.scone_timestamp_ms;
    connection_id_1 = intel.connection_id;
  };

  stream_ = createNewStream(std::move(stream_callbacks1));
  sys_calls.scone_bandwidth_.store(bandwidth_initial);
  stream_->sendHeaders(std::make_unique<Http::TestRequestHeaderMapImpl>(default_request_headers_),
                       true);
  cc_.terminal_callback_->waitReady();

  EXPECT_EQ(captured_scone_max_kbps1, bandwidth_initial);
  EXPECT_GT(captured_scone_timestamp_ms1, 0);

  // 2. Stream 2: Same connection, inherits bandwidth_initial without new packet
  int64_t captured_scone_max_kbps2 = -1;
  int64_t captured_scone_timestamp_ms2 = -1;
  uint64_t connection_id_2 = 0;

  EnvoyStreamCallbacks stream_callbacks2 = createDefaultStreamCallbacks();
  stream_callbacks2.on_headers_ = [&](const Http::ResponseHeaderMap& headers, bool,
                                      envoy_stream_intel intel) {
    cc_.on_headers_calls_++;
    cc_.status_ = absl::StrCat(headers.getStatusValue());
    captured_scone_max_kbps2 = intel.scone_max_kbps;
    captured_scone_timestamp_ms2 = intel.scone_timestamp_ms;
    connection_id_2 = intel.connection_id;
  };

  ConditionalInitializer terminal_callback2;
  cc_.terminal_callback_ = &terminal_callback2;
  auto stream2 = createNewStream(std::move(stream_callbacks2));
  stream2->sendHeaders(std::make_unique<Http::TestRequestHeaderMapImpl>(default_request_headers_),
                       true);
  terminal_callback2.waitReady();

  EXPECT_EQ(captured_scone_max_kbps2, bandwidth_initial);
  EXPECT_EQ(captured_scone_timestamp_ms2, captured_scone_timestamp_ms1);
  EXPECT_EQ(connection_id_2, connection_id_1);

  // 3. Stream 3: Bandwidth changes dynamically (throttled to 50 kbps)
  int64_t captured_scone_max_kbps3 = -1;
  int64_t captured_scone_timestamp_ms3 = -1;
  uint64_t connection_id_3 = 0;

  EnvoyStreamCallbacks stream_callbacks3 = createDefaultStreamCallbacks();
  stream_callbacks3.on_headers_ = [&](const Http::ResponseHeaderMap& headers, bool,
                                      envoy_stream_intel intel) {
    cc_.on_headers_calls_++;
    cc_.status_ = absl::StrCat(headers.getStatusValue());
    captured_scone_max_kbps3 = intel.scone_max_kbps;
    captured_scone_timestamp_ms3 = intel.scone_timestamp_ms;
    connection_id_3 = intel.connection_id;
  };

  ConditionalInitializer terminal_callback3;
  cc_.terminal_callback_ = &terminal_callback3;
  sys_calls.scone_bandwidth_.store(bandwidth_throttled);

  auto stream3 = createNewStream(std::move(stream_callbacks3));
  stream3->sendHeaders(std::make_unique<Http::TestRequestHeaderMapImpl>(default_request_headers_),
                       true);
  terminal_callback3.waitReady();

  EXPECT_EQ(captured_scone_max_kbps3, bandwidth_throttled);
  EXPECT_GT(captured_scone_timestamp_ms3, captured_scone_timestamp_ms2);
  EXPECT_EQ(connection_id_3, connection_id_1);
}

TEST_P(ClientIntegrationTest, SconeValuePropagationDelayed) {
  if (upstreamProtocol() != Http::CodecType::HTTP3) {
    return;
  }

  const int16_t expected_bandwidth = 50;

  MockRecvMsgOsSysCalls sys_calls;
  TestThreadsafeSingletonInjector<Api::OsSysCallsImpl> injector(&sys_calls);

  builder_.enableScone(true);
  initialize();

  int64_t captured_scone_max_kbps_headers = -1;
  int64_t captured_scone_max_kbps_data = -1;
  int64_t captured_scone_timestamp_ms_headers = -1;
  int64_t captured_scone_timestamp_ms_data = -1;

  absl::Notification headers_received;
  absl::Notification data_received;

  EnvoyStreamCallbacks stream_callbacks = createDefaultStreamCallbacks();
  stream_callbacks.on_headers_ = [&](const Http::ResponseHeaderMap& headers, bool,
                                     envoy_stream_intel intel) {
    cc_.on_headers_calls_++;
    cc_.status_ = absl::StrCat(headers.getStatusValue());
    captured_scone_max_kbps_headers = intel.scone_max_kbps;
    captured_scone_timestamp_ms_headers = intel.scone_timestamp_ms;
    if (!headers_received.HasBeenNotified()) {
      headers_received.Notify();
    }
  };
  stream_callbacks.on_data_ = [&](const Buffer::Instance&, uint64_t, bool,
                                  envoy_stream_intel intel) {
    cc_.on_data_calls_++;
    captured_scone_max_kbps_data = intel.scone_max_kbps;
    captured_scone_timestamp_ms_data = intel.scone_timestamp_ms;
    if (!data_received.HasBeenNotified()) {
      data_received.Notify();
    }
  };

  stream_ = createNewStream(std::move(stream_callbacks));
  stream_->sendHeaders(std::make_unique<Http::TestRequestHeaderMapImpl>(default_request_headers_),
                       true);

  ASSERT_TRUE(fake_upstreams_[0]->waitForHttpConnection(*BaseIntegrationTest::dispatcher_,
                                                        upstream_connection_));
  ASSERT_TRUE(
      upstream_connection_->waitForNewStream(*BaseIntegrationTest::dispatcher_, upstream_request_));
  ASSERT_TRUE(upstream_request_->waitForEndStream(*BaseIntegrationTest::dispatcher_));

  upstream_request_->encodeHeaders(Http::TestResponseHeaderMapImpl{{":status", "200"}}, false);

  headers_received.WaitForNotification();

  EXPECT_EQ(captured_scone_max_kbps_headers, -1);
  EXPECT_EQ(captured_scone_timestamp_ms_headers, -1);

  sys_calls.scone_bandwidth_.store(expected_bandwidth);

  upstream_request_->encodeData(10, false);

  data_received.WaitForNotification();

  EXPECT_EQ(captured_scone_max_kbps_data, expected_bandwidth);
  EXPECT_GT(captured_scone_timestamp_ms_data, 0);

  upstream_request_->encodeData(0, true);

  terminal_callback_.waitReady();
}

TEST_P(ClientIntegrationTest, SconeValuePropagationMultipleUpdates) {
  if (upstreamProtocol() != Http::CodecType::HTTP3) {
    return;
  }

  const int16_t expected_bandwidth_1 = 10;
  const int16_t expected_bandwidth_2 = 20;

  MockRecvMsgOsSysCalls sys_calls;
  TestThreadsafeSingletonInjector<Api::OsSysCallsImpl> injector(&sys_calls);

  builder_.enableScone(true);
  initialize();

  int64_t captured_scone_max_kbps_headers = -1;
  int64_t captured_scone_max_kbps_data = -1;
  int64_t captured_scone_timestamp_ms_headers = -1;
  int64_t captured_scone_timestamp_ms_data = -1;

  absl::Notification headers_received;
  absl::Notification data_received;

  EnvoyStreamCallbacks stream_callbacks = createDefaultStreamCallbacks();
  stream_callbacks.on_headers_ = [&](const Http::ResponseHeaderMap& headers, bool,
                                     envoy_stream_intel intel) {
    cc_.on_headers_calls_++;
    cc_.status_ = absl::StrCat(headers.getStatusValue());
    captured_scone_max_kbps_headers = intel.scone_max_kbps;
    captured_scone_timestamp_ms_headers = intel.scone_timestamp_ms;
    if (!headers_received.HasBeenNotified()) {
      headers_received.Notify();
    }
  };
  stream_callbacks.on_data_ = [&](const Buffer::Instance&, uint64_t, bool,
                                  envoy_stream_intel intel) {
    cc_.on_data_calls_++;
    captured_scone_max_kbps_data = intel.scone_max_kbps;
    captured_scone_timestamp_ms_data = intel.scone_timestamp_ms;
    if (!data_received.HasBeenNotified()) {
      data_received.Notify();
    }
  };

  stream_ = createNewStream(std::move(stream_callbacks));
  sys_calls.scone_bandwidth_.store(expected_bandwidth_1);
  stream_->sendHeaders(std::make_unique<Http::TestRequestHeaderMapImpl>(default_request_headers_),
                       true);

  ASSERT_TRUE(fake_upstreams_[0]->waitForHttpConnection(*BaseIntegrationTest::dispatcher_,
                                                        upstream_connection_));
  ASSERT_TRUE(
      upstream_connection_->waitForNewStream(*BaseIntegrationTest::dispatcher_, upstream_request_));
  ASSERT_TRUE(upstream_request_->waitForEndStream(*BaseIntegrationTest::dispatcher_));

  upstream_request_->encodeHeaders(Http::TestResponseHeaderMapImpl{{":status", "200"}}, false);

  headers_received.WaitForNotification();

  EXPECT_EQ(captured_scone_max_kbps_headers, expected_bandwidth_1);
  EXPECT_GT(captured_scone_timestamp_ms_headers, 0);

  sys_calls.scone_bandwidth_.store(expected_bandwidth_2);

  upstream_request_->encodeData(10, false);

  data_received.WaitForNotification();

  EXPECT_EQ(captured_scone_max_kbps_data, expected_bandwidth_2);
  EXPECT_GT(captured_scone_timestamp_ms_data, 0);
  EXPECT_GE(captured_scone_timestamp_ms_data, captured_scone_timestamp_ms_headers);

  upstream_request_->encodeData(0, true);

  terminal_callback_.waitReady();
}

TEST_P(ClientIntegrationTest, SconeDisabled) {
  if (upstreamProtocol() != Http::CodecType::HTTP3) {
    return;
  }

  const int16_t expected_bandwidth = 127;

  MockRecvMsgOsSysCalls sys_calls;
  TestThreadsafeSingletonInjector<Api::OsSysCallsImpl> injector(&sys_calls);

  builder_.enableScone(false);
  initialize();

  int64_t captured_scone_max_kbps = 0;
  int64_t captured_scone_timestamp_ms = 0;

  EnvoyStreamCallbacks stream_callbacks = createDefaultStreamCallbacks();
  stream_callbacks.on_headers_ = [&](const Http::ResponseHeaderMap& headers, bool,
                                     envoy_stream_intel intel) {
    cc_.on_headers_calls_++;
    cc_.status_ = absl::StrCat(headers.getStatusValue());
    captured_scone_max_kbps = intel.scone_max_kbps;
    captured_scone_timestamp_ms = intel.scone_timestamp_ms;
  };

  stream_ = createNewStream(std::move(stream_callbacks));
  sys_calls.scone_bandwidth_.store(expected_bandwidth);
  stream_->sendHeaders(std::make_unique<Http::TestRequestHeaderMapImpl>(default_request_headers_),
                       true);

  cc_.terminal_callback_->waitReady();

  EXPECT_EQ(captured_scone_max_kbps, -1);
  EXPECT_EQ(captured_scone_timestamp_ms, -1);
}

TEST_P(ClientIntegrationTest, DrainConnectionsBySocketTag) {
  autonomous_upstream_ = false;
  builder_.enableSocketTagging(true);
  builder_.enableStatsCollection(true);
  initialize();

  Platform::EngineSharedPtr engine;
  {
    absl::MutexLock l(engine_lock_);
    engine = engine_;
  }

  auto send_request_with_tag = [&](int tag_value, ConditionalInitializer& terminal,
                                   std::string& status) {
    Buffer::OwnedImpl request_data = Buffer::OwnedImpl("request body");
    Http::TestRequestHeaderMapImpl request_headers = default_request_headers_;
    request_headers.addCopy(Http::LowerCaseString("x-envoy-mobile-socket-tag"),
                            absl::StrCat("0,", tag_value));

    EnvoyStreamCallbacks callbacks;
    callbacks.on_headers_ = [&](const Http::ResponseHeaderMap& headers, bool, envoy_stream_intel) {
      status = absl::StrCat(headers.getStatusValue());
    };
    callbacks.on_data_ = [](const Buffer::Instance&, uint64_t, bool, envoy_stream_intel) {};
    callbacks.on_complete_ = [&terminal](envoy_stream_intel, envoy_final_stream_intel) {
      terminal.setReady();
    };
    callbacks.on_error_ = [&terminal](const EnvoyError&, envoy_stream_intel,
                                      envoy_final_stream_intel) { terminal.setReady(); };
    callbacks.on_cancel_ = [&terminal](envoy_stream_intel, envoy_final_stream_intel) {
      terminal.setReady();
    };

    Platform::StreamSharedPtr stream = createNewStream(std::move(callbacks));
    stream->sendHeaders(std::make_unique<Http::TestRequestHeaderMapImpl>(request_headers), false);
    stream->sendData(std::make_unique<Buffer::OwnedImpl>(std::move(request_data)));
    stream->close(Http::Utility::createRequestTrailerMapPtr());
    return stream;
  };

  // 1. First request to establish a connection with socket tag 12345
  ConditionalInitializer terminal1;
  std::string status1;
  auto s1 = send_request_with_tag(12345, terminal1, status1);

  FakeHttpConnectionPtr fake_upstream_connection1;
  FakeStreamPtr fake_stream1;
  ASSERT_TRUE(fake_upstreams_[0]->waitForHttpConnection(*BaseIntegrationTest::dispatcher_,
                                                        fake_upstream_connection1));
  ASSERT_TRUE(
      fake_upstream_connection1->waitForNewStream(*BaseIntegrationTest::dispatcher_, fake_stream1));
  ASSERT_TRUE(fake_stream1->waitForEndStream(*BaseIntegrationTest::dispatcher_));
  fake_stream1->encodeHeaders(Http::TestResponseHeaderMapImpl({{":status", "200"}}), false);
  fake_stream1->encodeData(100, true);
  terminal1.waitReady();
  ASSERT_EQ(status1, "200");

  // 2. Second request to the same host with a different socket tag 67890
  ConditionalInitializer terminal2;
  std::string status2;
  auto s2 = send_request_with_tag(67890, terminal2, status2);

  FakeHttpConnectionPtr fake_upstream_connection2;
  FakeStreamPtr fake_stream2;
  ASSERT_TRUE(fake_upstreams_[0]->waitForHttpConnection(*BaseIntegrationTest::dispatcher_,
                                                        fake_upstream_connection2));
  ASSERT_TRUE(
      fake_upstream_connection2->waitForNewStream(*BaseIntegrationTest::dispatcher_, fake_stream2));
  ASSERT_TRUE(fake_stream2->waitForEndStream(*BaseIntegrationTest::dispatcher_));
  fake_stream2->encodeHeaders(Http::TestResponseHeaderMapImpl({{":status", "200"}}), false);
  fake_stream2->encodeData(100, true);
  terminal2.waitReady();
  ASSERT_EQ(status2, "200");

  // 3. Drain only the connections matching the first socket tag 12345
  engine->drainConnectionsBySocketTag(12345);
  // Directly verify server-side connection 1 disconnects
  ASSERT_TRUE(fake_upstream_connection1->waitForDisconnect());
  // Verify server-side connection 2 remains fully open and connected
  EXPECT_TRUE(fake_upstream_connection2->connected());

  // 4. Third request to the same host with the second socket tag 67890
  ConditionalInitializer terminal3;
  std::string status3;
  auto s3 = send_request_with_tag(67890, terminal3, status3);

  FakeStreamPtr fake_stream3;
  ASSERT_TRUE(
      fake_upstream_connection2->waitForNewStream(*BaseIntegrationTest::dispatcher_, fake_stream3));
  ASSERT_TRUE(fake_stream3->waitForEndStream(*BaseIntegrationTest::dispatcher_));
  fake_stream3->encodeHeaders(Http::TestResponseHeaderMapImpl({{":status", "200"}}), false);
  fake_stream3->encodeData(100, true);
  terminal3.waitReady();

  ASSERT_EQ(status3, "200");
  if (fake_upstream_connection2 != nullptr) {
    ASSERT_TRUE(fake_upstream_connection2->close());
    ASSERT_TRUE(fake_upstream_connection2->waitForDisconnect());
  }
}
} // namespace
} // namespace Envoy
