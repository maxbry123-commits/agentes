#include <sys/socket.h>

#include <memory>
#include <string>
#include <utility>
#include <vector>

#include "gmock/gmock.h"
#include "envoy/config/cluster/v3/cluster.pb.h"
#include "envoy/config/core/v3/socket_option.pb.h"
#include "envoy/extensions/clusters/dynamic_forward_proxy/v3/cluster.pb.h"
#include "envoy/extensions/filters/http/buffer/v3/buffer.pb.h"

#include "source/common/protobuf/utility.h"
#include "test/test_common/utility.h"

#include "absl/strings/str_cat.h"
#include "gtest/gtest.h"
#include "test/cc/engine_builder_test_shim.h"
#include "library/common/api/external.h"
#include "library/common/bridge//utility.h"

#if defined(__APPLE__)
#include "source/extensions/network/dns_resolver/apple/apple_dns_impl.h"
#endif

namespace Envoy {
namespace {

using namespace Platform;

using envoy::config::bootstrap::v3::Bootstrap;
using envoy::config::cluster::v3::Cluster;
using envoy::config::core::v3::SocketOption;
using DfpClusterConfig = ::envoy::extensions::clusters::dynamic_forward_proxy::v3::ClusterConfig;
using testing::HasSubstr;
using testing::Not;
using testing::NotNull;

DfpClusterConfig getDfpClusterConfig(const Bootstrap& bootstrap) {
  DfpClusterConfig cluster_config;
  const auto& clusters = bootstrap.static_resources().clusters();
  for (const auto& cluster : clusters) {
    if (cluster.name() == "base") {
      MessageUtil::unpackTo(cluster.cluster_type().typed_config(), cluster_config).IgnoreError();
    }
  }
  return cluster_config;
}

bool socketAddressesEqual(
    const Protobuf::RepeatedPtrField<envoy::config::core::v3::SocketAddress>& lhs,
    const Protobuf::RepeatedPtrField<envoy::config::core::v3::SocketAddress>& rhs) {
  if (lhs.size() != rhs.size()) {
    return false;
  }

  for (int i = 0; i < lhs.size(); ++i) {
    if ((lhs[i].address() != rhs[i].address()) || lhs[i].port_value() != rhs[i].port_value()) {
      return false;
    }
  }
  return true;
}

TEST(TestConfig, ConfigIsApplied) {
  EngineBuilder engine_builder;
  engine_builder.addQuicConnectionOption("10AF")
      .addQuicConnectionOption("MPQC")
      .addQuicClientConnectionOption("1RTT")
      .addQuicHint("www.abc.com", 443)
      .addQuicHint("www.def.com", 443)
      .addQuicCanonicalSuffix(".opq.com")
      .addQuicCanonicalSuffix(".xyz.com")
      .setNumTimeoutsToTriggerPortMigration(4)
      .addConnectTimeoutSeconds(123)
      .setDisableDnsRefreshOnFailure(true)
      .addDnsRefreshSeconds(456)
      .addDnsMinRefreshSeconds(567)
      .addDnsFailureRefreshSeconds(789, 987)
      .addDnsQueryTimeoutSeconds(321)
      .addH2ConnectionKeepaliveIdleIntervalMilliseconds(222)
      .addH2ConnectionKeepaliveTimeoutSeconds(333)
      .setKeepAliveInitialIntervalMilliseconds(3500)
      .setAppVersion("1.2.3")
      .setAppId("1234-1234-1234")
      .addRuntimeGuard("quic_no_tcp_delay", true)
      .enableDnsCache(true, /* save_interval_seconds */ 101)
      .addDnsPreresolveHostnames({"lyft.com", "google.com"})
      .setDeviceOs("probably-ubuntu-on-CI")
      .enableScone(true);

  std::unique_ptr<Bootstrap> bootstrap = engine_builder.generateBootstrap();
  const std::string config_str = bootstrap->ShortDebugString();

  std::vector<std::string> must_contain = {
      "connect_timeout { seconds: 123 }",
      "dns_refresh_rate { seconds: 456 }",
      "dns_min_refresh_rate { seconds: 567 }",
      "dns_query_timeout { seconds: 321 }",
      "dns_failure_refresh_rate { base_interval { seconds: 789 } max_interval { seconds: 987 } }",
      "connection_idle_interval { nanos: 222000000 }",
      "connection_keepalive { timeout { seconds: 333 }",
      "initial_interval { seconds: 3 nanos: 500000000 }",
      "connection_options: \"AKDU,BWRS,5RTO,EVMB,10AF,MPQC\"",
      "client_connection_options: \"1RTT\"",
      "hostname: \"www.abc.com\"",
      "hostname: \"www.def.com\"",
      "canonical_suffixes: \".opq.com\"",
      "canonical_suffixes: \".xyz.com\"",
      "num_timeouts_to_trigger_port_migration { value: 4 }",
      "idle_network_timeout { seconds: 60 }",
      "key: \"dns_persistent_cache\" save_interval { seconds: 101 }",
      "key: \"quic_no_tcp_delay\" value { bool_value: true }",
      "key: \"device_os\" value { string_value: \"probably-ubuntu-on-CI\" } }",
      "key: \"app_version\" value { string_value: \"1.2.3\" } }",
      "key: \"app_id\" value { string_value: \"1234-1234-1234\" } }",
      "initial_stream_window_size { value: 6291456 }",
      "enable_scone { value: true }",
      "initial_connection_window_size { value: 15728640 }"};

  for (const auto& string : must_contain) {
    EXPECT_THAT(config_str, HasSubstr(string)) << "'" << string << "' not found in " << config_str;
  }
}

TEST(TestConfig, SetKeepAliveInitialIntervalMilliseconds) {
  EngineBuilder engine_builder;
  engine_builder.setKeepAliveInitialIntervalMilliseconds(3000);

  std::unique_ptr<Bootstrap> bootstrap = engine_builder.generateBootstrap();
  const std::string config_str = bootstrap->ShortDebugString();
  EXPECT_THAT(config_str, HasSubstr("initial_interval { seconds: 3 }"));
}

TEST(TestConfig, SameFlagMultiTimes) {
  EngineBuilder engine_builder;
  engine_builder.addRuntimeGuard("quic_no_tcp_delay", true)
      .addRuntimeGuard("quic_no_tcp_delay", false);

  std::unique_ptr<Bootstrap> bootstrap = engine_builder.generateBootstrap();
  const std::string bootstrap_str = bootstrap->ShortDebugString();
  EXPECT_THAT(bootstrap_str, HasSubstr("\"quic_no_tcp_delay\" value { bool_value: false }"));
}

TEST(TestConfig, InvalidRuntimeFlagIgnored) {
  EngineBuilder engine_builder;
  engine_builder.addRuntimeGuard("quic_no_tcp_delay", true)
      .addRuntimeGuard("not_a_real_flag", true)
      .addRestartRuntimeGuard("also_not_a_real_flag", true);

  std::unique_ptr<Bootstrap> bootstrap = engine_builder.generateBootstrap();
  const std::string bootstrap_str = bootstrap->ShortDebugString();
  EXPECT_THAT(bootstrap_str, HasSubstr("\"quic_no_tcp_delay\" value { bool_value: true }"));
  EXPECT_THAT(bootstrap_str, Not(HasSubstr("\"not_a_real_flag\"")));
  EXPECT_THAT(bootstrap_str, Not(HasSubstr("\"also_not_a_real_flag\"")));
}

TEST(TestConfig, ConfigIsValid) {
  EngineBuilder engine_builder;
  std::unique_ptr<Bootstrap> bootstrap = engine_builder.generateBootstrap();

  // Test per-platform DNS fixes.
#if defined(__APPLE__)
  EXPECT_THAT(bootstrap->DebugString(), Not(HasSubstr("envoy.network.dns_resolver.getaddrinfo")));
  EXPECT_THAT(bootstrap->DebugString(), HasSubstr("envoy.network.dns_resolver.apple"));
#else
  EXPECT_THAT(bootstrap->DebugString(), HasSubstr("envoy.network.dns_resolver.getaddrinfo"));
  EXPECT_THAT(bootstrap->DebugString(), Not(HasSubstr("envoy.network.dns_resolver.apple")));
#endif
}

TEST(TestConfig, SetGzipDecompression) {
  EngineBuilder engine_builder;

  engine_builder.enableGzipDecompression(false);
  std::unique_ptr<Bootstrap> bootstrap = engine_builder.generateBootstrap();
  EXPECT_THAT(bootstrap->DebugString(), Not(HasSubstr("envoy.filters.http.decompressor")));

  engine_builder.enableGzipDecompression(true);
  bootstrap.reset();
  bootstrap = engine_builder.generateBootstrap();
  EXPECT_THAT(bootstrap->DebugString(), HasSubstr("envoy.filters.http.decompressor"));
}

TEST(TestConfig, SetBrotliDecompression) {
  EngineBuilder engine_builder;

  engine_builder.enableBrotliDecompression(false);
  std::unique_ptr<Bootstrap> bootstrap = engine_builder.generateBootstrap();
  EXPECT_THAT(bootstrap->DebugString(), Not(HasSubstr("brotli.decompressor.v3.Brotli")));

  engine_builder.enableBrotliDecompression(true);
  bootstrap.reset();
  bootstrap = engine_builder.generateBootstrap();
  EXPECT_THAT(bootstrap->DebugString(), HasSubstr("brotli.decompressor.v3.Brotli"));
}

TEST(TestConfig, SetSocketTag) {
  EngineBuilder engine_builder;

  engine_builder.enableSocketTagging(false);
  std::unique_ptr<Bootstrap> bootstrap = engine_builder.generateBootstrap();
  EXPECT_THAT(bootstrap->DebugString(), Not(HasSubstr("http.socket_tag.SocketTag")));

  engine_builder.enableSocketTagging(true);
  bootstrap.reset();
  bootstrap = engine_builder.generateBootstrap();
  EXPECT_THAT(bootstrap->DebugString(), HasSubstr("http.socket_tag.SocketTag"));
}

TEST(TestConfig, SetAltSvcCache) {
  EngineBuilder engine_builder;
  std::unique_ptr<Bootstrap> bootstrap = engine_builder.generateBootstrap();
  EXPECT_THAT(bootstrap->DebugString(), HasSubstr("alternate_protocols_cache"));
}

TEST(TestConfig, StreamIdleTimeout) {
  EngineBuilder engine_builder;

  std::unique_ptr<Bootstrap> bootstrap = engine_builder.generateBootstrap();
  EXPECT_THAT(bootstrap->ShortDebugString(), HasSubstr("stream_idle_timeout { seconds: 15 }"));

  engine_builder.setStreamIdleTimeoutSeconds(42);
  bootstrap = engine_builder.generateBootstrap();
  EXPECT_THAT(bootstrap->ShortDebugString(), HasSubstr("stream_idle_timeout { seconds: 42 }"));
}

TEST(TestConfig, RequestTimeout) {
  EngineBuilder engine_builder;

  std::unique_ptr<Bootstrap> bootstrap = engine_builder.generateBootstrap();
  EXPECT_THAT(bootstrap->ShortDebugString(), HasSubstr("timeout { }"));

  engine_builder.setRequestTimeoutMilliseconds(42500);
  bootstrap = engine_builder.generateBootstrap();
  EXPECT_THAT(bootstrap->ShortDebugString(), HasSubstr("timeout { seconds: 42 nanos: 500000000 }"));
}

TEST(TestConfig, PerTryIdleTimeout) {
  EngineBuilder engine_builder;

  std::unique_ptr<Bootstrap> bootstrap = engine_builder.generateBootstrap();
  EXPECT_THAT(bootstrap->ShortDebugString(), HasSubstr("per_try_idle_timeout { seconds: 15 }"));

  engine_builder.setPerTryIdleTimeoutSeconds(42);
  bootstrap = engine_builder.generateBootstrap();
  EXPECT_THAT(bootstrap->ShortDebugString(), HasSubstr("per_try_idle_timeout { seconds: 42 }"));
}

TEST(TestConfig, EnableInterfaceBinding) {
  EngineBuilder engine_builder;

  std::unique_ptr<Bootstrap> bootstrap = engine_builder.generateBootstrap();
  EXPECT_THAT(bootstrap->ShortDebugString(), Not(HasSubstr("enable_interface_binding")));

  engine_builder.enableInterfaceBinding(true);
  bootstrap = engine_builder.generateBootstrap();
  EXPECT_THAT(bootstrap->ShortDebugString(), HasSubstr("enable_interface_binding: true"));
}

TEST(TestConfig, EnableDrainPostDnsRefresh) {
  EngineBuilder engine_builder;

  std::unique_ptr<Bootstrap> bootstrap = engine_builder.generateBootstrap();
  EXPECT_THAT(bootstrap->ShortDebugString(), Not(HasSubstr("enable_drain_post_dns_refresh")));

  engine_builder.enableDrainPostDnsRefresh(true);
  bootstrap = engine_builder.generateBootstrap();
  EXPECT_THAT(bootstrap->ShortDebugString(), HasSubstr("enable_drain_post_dns_refresh: true"));
}

TEST(TestConfig, SetDnsQueryTimeout) {
  EngineBuilder engine_builder;

  std::unique_ptr<Bootstrap> bootstrap = engine_builder.generateBootstrap();
  // The default value.
  EXPECT_THAT(bootstrap->ShortDebugString(), HasSubstr("dns_query_timeout { seconds: 120 }"));

  engine_builder.addDnsQueryTimeoutSeconds(30);
  bootstrap = engine_builder.generateBootstrap();
  EXPECT_THAT(bootstrap->ShortDebugString(), HasSubstr("dns_query_timeout { seconds: 30 }"));
}

TEST(TestConfig, SetDisableDnsRefreshOnFailure) {
  EngineBuilder engine_builder;

  std::unique_ptr<Bootstrap> bootstrap = engine_builder.generateBootstrap();
  // The default value.
  EXPECT_THAT(bootstrap->ShortDebugString(), Not(HasSubstr("disable_dns_refresh_on_failure")));

  engine_builder.setDisableDnsRefreshOnFailure(true);
  bootstrap = engine_builder.generateBootstrap();
  EXPECT_THAT(bootstrap->ShortDebugString(), HasSubstr("disable_dns_refresh_on_failure: true"));
}

TEST(TestConfig, EnforceTrustChainVerification) {
  EngineBuilder engine_builder;

  std::unique_ptr<Bootstrap> bootstrap = engine_builder.generateBootstrap();
  EXPECT_THAT(bootstrap->ShortDebugString(), Not(HasSubstr("trust_chain_verification")));

  engine_builder.enforceTrustChainVerification(false);
  bootstrap = engine_builder.generateBootstrap();
  EXPECT_THAT(bootstrap->ShortDebugString(),
              HasSubstr("trust_chain_verification: ACCEPT_UNTRUSTED"));
}

TEST(TestConfig, AddMaxConnectionsPerHost) {
  EngineBuilder engine_builder;

  std::unique_ptr<Bootstrap> bootstrap = engine_builder.generateBootstrap();
  EXPECT_THAT(bootstrap->ShortDebugString(), HasSubstr("max_connections { value: 7 }"));

  engine_builder.addMaxConnectionsPerHost(16);
  bootstrap = engine_builder.generateBootstrap();
  EXPECT_THAT(bootstrap->ShortDebugString(), HasSubstr("max_connections { value: 16 }"));
}

TEST(TestConfig, AddDnsPreresolveHostnames) {
  EngineBuilder engine_builder;
  engine_builder.addDnsPreresolveHostnames({"google.com", "lyft.com"});
  std::unique_ptr<Bootstrap> bootstrap = engine_builder.generateBootstrap();

  Protobuf::RepeatedPtrField<envoy::config::core::v3::SocketAddress>
      expected_dns_preresolve_hostnames;
  auto& host_addr1 = *expected_dns_preresolve_hostnames.Add();
  host_addr1.set_address("google.com");
  host_addr1.set_port_value(443);
  auto& host_addr2 = *expected_dns_preresolve_hostnames.Add();
  host_addr2.set_address("lyft.com");
  host_addr2.set_port_value(443);
  EXPECT_TRUE(socketAddressesEqual(
      getDfpClusterConfig(*bootstrap).dns_cache_config().preresolve_hostnames(),
      expected_dns_preresolve_hostnames));

  // Resetting the DNS preresolve hostnames with just "google.com" now.
  engine_builder.addDnsPreresolveHostnames({"google.com"});
  bootstrap = engine_builder.generateBootstrap();
  expected_dns_preresolve_hostnames.Clear();
  auto& host_addr3 = *expected_dns_preresolve_hostnames.Add();
  host_addr3.set_address("google.com");
  host_addr3.set_port_value(443);
  EXPECT_TRUE(socketAddressesEqual(
      getDfpClusterConfig(*bootstrap).dns_cache_config().preresolve_hostnames(),
      expected_dns_preresolve_hostnames));
}

TEST(TestConfig, DisableHttp3) {
  EngineBuilder engine_builder;

  std::unique_ptr<Bootstrap> bootstrap = engine_builder.generateBootstrap();
  EXPECT_THAT(bootstrap->ShortDebugString(),
              HasSubstr("envoy.extensions.filters.http.alternate_protocols_cache.v3.FilterConfig"));
  engine_builder.enableHttp3(false);
  bootstrap = engine_builder.generateBootstrap();
  EXPECT_THAT(
      bootstrap->ShortDebugString(),
      Not(HasSubstr("envoy.extensions.filters.http.alternate_protocols_cache.v3.FilterConfig")));
}

TEST(TestConfig, EnableEarlyData) {
  EngineBuilder engine_builder;

  std::unique_ptr<Bootstrap> bootstrap = engine_builder.generateBootstrap();
  EXPECT_THAT(bootstrap->ShortDebugString(), Not(HasSubstr("early_data_policy")));

  engine_builder.enableEarlyData(false);
  bootstrap = engine_builder.generateBootstrap();
  EXPECT_THAT(bootstrap->ShortDebugString(), HasSubstr("envoy.route.early_data_policy.default"));
}

TEST(TestConfig, UdpSocketReceiveBufferSize) {
  EngineBuilder engine_builder;
  engine_builder.enableHttp3(true);

  std::unique_ptr<Bootstrap> bootstrap = engine_builder.generateBootstrap();
  Cluster const* base_cluster = nullptr;
  for (const Cluster& cluster : bootstrap->static_resources().clusters()) {
    if (cluster.name() == "base") {
      base_cluster = &cluster;
      break;
    }
  }

  // The base H3 cluster should always be found.
  ASSERT_THAT(base_cluster, NotNull());

  SocketOption const* rcv_buf_option = nullptr;
  for (const SocketOption& sock_opt : base_cluster->upstream_bind_config().socket_options()) {
    if (sock_opt.name() == SO_RCVBUF) {
      rcv_buf_option = &sock_opt;
      break;
    }
  }

  // When using an H3 cluster, the UDP receive buffer size option should always be set.
  ASSERT_THAT(rcv_buf_option, NotNull());
  EXPECT_EQ(rcv_buf_option->level(), SOL_SOCKET);
  EXPECT_TRUE(rcv_buf_option->type().has_datagram());
  EXPECT_EQ(rcv_buf_option->int_value(), 1024 * 1024 /* 1 MB */);
}

TEST(TestConfig, UdpSocketSendBufferSize) {
  EngineBuilder engine_builder;
  engine_builder.enableHttp3(true);

  std::unique_ptr<Bootstrap> bootstrap = engine_builder.generateBootstrap();
  Cluster const* base_cluster = nullptr;
  for (const Cluster& cluster : bootstrap->static_resources().clusters()) {
    if (cluster.name() == "base") {
      base_cluster = &cluster;
      break;
    }
  }

  // The base H3 cluster should always be found.
  ASSERT_THAT(base_cluster, NotNull());

  SocketOption const* snd_buf_option = nullptr;
  for (const SocketOption& sock_opt : base_cluster->upstream_bind_config().socket_options()) {
    if (sock_opt.name() == SO_SNDBUF) {
      snd_buf_option = &sock_opt;
      break;
    }
  }

  // When using an H3 cluster, the UDP send buffer size option should always be set.
  ASSERT_THAT(snd_buf_option, NotNull());
  EXPECT_EQ(snd_buf_option->level(), SOL_SOCKET);
  EXPECT_TRUE(snd_buf_option->type().has_datagram());
  EXPECT_EQ(snd_buf_option->int_value(), 1452 * 20);
}

TEST(TestConfig, AdditionalSocketOptions) {
  EngineBuilder engine_builder;
  engine_builder.enableHttp3(true);
  envoy::config::core::v3::SocketOption socket_opt;
  socket_opt.set_level(SOL_SOCKET);
  socket_opt.set_name(123);
  socket_opt.set_int_value(456);
  socket_opt.mutable_type()->mutable_datagram();
  engine_builder.setAdditionalSocketOptions({socket_opt});

  std::unique_ptr<Bootstrap> bootstrap = engine_builder.generateBootstrap();
  Cluster const* base_cluster = nullptr;
  for (const Cluster& cluster : bootstrap->static_resources().clusters()) {
    if (cluster.name() == "base") {
      base_cluster = &cluster;
      break;
    }
  }

  // The base H3 cluster should always be found.
  ASSERT_THAT(base_cluster, NotNull());

  SocketOption const* additional_socket_opt = nullptr;
  for (const auto& sock_opt : base_cluster->upstream_bind_config().socket_options()) {
    if (sock_opt.name() == 123) {
      additional_socket_opt = &sock_opt;
      break;
    }
  }

  ASSERT_THAT(additional_socket_opt, NotNull());
  EXPECT_EQ(additional_socket_opt->level(), SOL_SOCKET);
  EXPECT_TRUE(additional_socket_opt->type().has_datagram());
  EXPECT_EQ(additional_socket_opt->int_value(), 456);
}

TEST(TestConfig, EnablePlatformCertificatesValidation) {
  EngineBuilder engine_builder;
  engine_builder.enablePlatformCertificatesValidation(false);
  std::unique_ptr<Bootstrap> bootstrap = engine_builder.generateBootstrap();
  EXPECT_THAT(bootstrap->ShortDebugString(),
              Not(HasSubstr("envoy_mobile.cert_validator.platform_bridge_cert_validator")));

  engine_builder.enablePlatformCertificatesValidation(true);
  bootstrap = engine_builder.generateBootstrap();
  EXPECT_THAT(bootstrap->ShortDebugString(),
              HasSubstr("envoy_mobile.cert_validator.platform_bridge_cert_validator"));
  EXPECT_THAT(bootstrap->ShortDebugString(), Not(HasSubstr("trusted_ca")));
}

// Implementation of StringAccessor which tracks the number of times it was used.
class TestStringAccessor : public StringAccessor {
public:
  explicit TestStringAccessor(std::string data) : data_(data) {}
  ~TestStringAccessor() override = default;

  // StringAccessor
  const std::string& get() const override {
    ++count_;
    return data_;
  }

  int count() { return count_; }

private:
  std::string data_;
  mutable int count_ = 0;
};

TEST(TestConfig, AddNativeFilters) {
  EngineBuilder engine_builder;

  std::string filter_name1 = "envoy.filters.http.buffer1";
  std::string filter_name2 = "envoy.filters.http.buffer2";

  envoy::extensions::filters::http::buffer::v3::Buffer buffer;
  buffer.mutable_max_request_bytes()->set_value(5242880);
  Protobuf::Any typed_config;
  typed_config.set_type_url("type.googleapis.com/envoy.extensions.filters.http.buffer.v3.Buffer");
  std::string serialized_buffer;
  std::ignore = buffer.SerializeToString(&serialized_buffer);
  typed_config.set_value(serialized_buffer);

  engine_builder.addNativeFilter(filter_name1, typed_config);
  engine_builder.addNativeFilter(filter_name2, typed_config);

  std::unique_ptr<Bootstrap> bootstrap = engine_builder.generateBootstrap();
  const std::string hcm_config =
      bootstrap->static_resources().listeners(0).api_listener().DebugString();
  EXPECT_THAT(hcm_config, HasSubstr(filter_name1));
  EXPECT_THAT(hcm_config, HasSubstr(filter_name2));
  EXPECT_THAT(hcm_config,
              HasSubstr("type.googleapis.com/envoy.extensions.filters.http.buffer.v3.Buffer"));
  EXPECT_THAT(hcm_config, HasSubstr(std::to_string(5242880)));
}

#ifdef ENVOY_ENABLE_FULL_PROTOS
TEST(TestConfig, AddTextProtoNativeFilters) {
  EngineBuilder engine_builder;

  std::string filter_name1 = "envoy.filters.http.buffer1";
  std::string filter_name2 = "envoy.filters.http.buffer2";
  std::string filter_config =
      "[type.googleapis.com/envoy.extensions.filters.http.buffer.v3.Buffer] { max_request_bytes { "
      "value: 5242880 } }";
  engine_builder.addNativeFilter(filter_name1, filter_config);
  engine_builder.addNativeFilter(filter_name2, filter_config);

  std::unique_ptr<Bootstrap> bootstrap = engine_builder.generateBootstrap();
  const std::string hcm_config =
      bootstrap->static_resources().listeners(0).api_listener().DebugString();
  EXPECT_THAT(hcm_config, HasSubstr(filter_name1));
  EXPECT_THAT(hcm_config, HasSubstr(filter_name2));
  EXPECT_THAT(hcm_config,
              HasSubstr("type.googleapis.com/envoy.extensions.filters.http.buffer.v3.Buffer"));
  EXPECT_THAT(hcm_config, HasSubstr(std::to_string(5242880)));
}

TEST(TestConfig, AddPlatformFilter) {
  EngineBuilder engine_builder;

  std::string filter_name = "test_platform_filter";

  std::unique_ptr<Bootstrap> bootstrap = engine_builder.generateBootstrap();
  std::string bootstrap_str = bootstrap->ShortDebugString();
  EXPECT_THAT(bootstrap_str, Not(HasSubstr("http.platform_bridge.PlatformBridge")));
  EXPECT_THAT(bootstrap_str, Not(HasSubstr("platform_filter_name: \"" + filter_name + "\"")));

  engine_builder.addPlatformFilter(filter_name);
  bootstrap = engine_builder.generateBootstrap();
  bootstrap_str = bootstrap->ShortDebugString();
  EXPECT_THAT(bootstrap_str, HasSubstr("http.platform_bridge.PlatformBridge"));
  EXPECT_THAT(bootstrap_str, HasSubstr("platform_filter_name: \"" + filter_name + "\""));
}
#endif // ENVOY_ENABLE_FULL_PROTOS

// TODO(RyanTheOptimist): This test seems to be flaky. #2641
TEST(TestConfig, DISABLED_StringAccessors) {
  std::string name("accessor_name");
  EngineBuilder engine_builder;
  std::string data_string = "envoy string";
  auto accessor = std::make_shared<TestStringAccessor>(data_string);
  engine_builder.addStringAccessor(name, accessor);
  Platform::EngineSharedPtr engine = engine_builder.build();
  auto c_accessor = static_cast<envoy_string_accessor*>(Envoy::Api::External::retrieveApi(name));
  ASSERT_TRUE(c_accessor != nullptr);
  EXPECT_EQ(0, accessor->count());
  envoy_data data = c_accessor->get_string(c_accessor->context);
  EXPECT_EQ(1, accessor->count());
  EXPECT_EQ(data_string, Bridge::Utility::copyToString(data));
  release_envoy_data(data);
}

TEST(TestConfig, SetNodeId) {
  EngineBuilder engine_builder;
  const std::string default_node_id = "envoy-mobile";
  EXPECT_EQ(engine_builder.generateBootstrap()->node().id(), default_node_id);

  const std::string test_node_id = "my_test_node";
  engine_builder.setNodeId(test_node_id);
  EXPECT_EQ(engine_builder.generateBootstrap()->node().id(), test_node_id);
}

TEST(TestConfig, SetNodeLocality) {
  EngineBuilder engine_builder;
  const std::string region = "us-west-1";
  const std::string zone = "some_zone";
  const std::string sub_zone = "some_sub_zone";
  engine_builder.setNodeLocality(region, zone, sub_zone);
  std::unique_ptr<Bootstrap> bootstrap = engine_builder.generateBootstrap();
  EXPECT_EQ(bootstrap->node().locality().region(), region);
  EXPECT_EQ(bootstrap->node().locality().zone(), zone);
  EXPECT_EQ(bootstrap->node().locality().sub_zone(), sub_zone);
}

TEST(TestConfig, SetNodeMetadata) {
  Protobuf::Struct node_metadata;
  (*node_metadata.mutable_fields())["string_field"].set_string_value("some_string");
  (*node_metadata.mutable_fields())["bool_field"].set_bool_value(true);
  (*node_metadata.mutable_fields())["number_field"].set_number_value(3.14);
  EngineBuilder engine_builder;
  engine_builder.setNodeMetadata(node_metadata);
  std::unique_ptr<Bootstrap> bootstrap = engine_builder.generateBootstrap();
  EXPECT_EQ(bootstrap->node().metadata().fields().at("string_field").string_value(), "some_string");
  EXPECT_EQ(bootstrap->node().metadata().fields().at("bool_field").bool_value(), true);
  EXPECT_EQ(bootstrap->node().metadata().fields().at("number_field").number_value(), 3.14);
}

#ifdef ENVOY_MOBILE_XDS
TEST(TestConfig, AddCdsLayer) {
  XdsBuilder xds_builder(/*xds_server_address=*/"fake-xds-server", /*xds_server_port=*/12345);
  xds_builder.addClusterDiscoveryService();
  EngineBuilder engine_builder;
  engine_builder.setXds(std::move(xds_builder));

  std::unique_ptr<Bootstrap> bootstrap = engine_builder.generateBootstrap();
  EXPECT_EQ(bootstrap->dynamic_resources().cds_resources_locator(), "");
  EXPECT_EQ(bootstrap->dynamic_resources().cds_config().initial_fetch_timeout().seconds(),
            /*default_timeout=*/5);

  xds_builder = XdsBuilder(/*xds_server_address=*/"fake-xds-server", /*xds_server_port=*/12345);
  const std::string cds_resources_locator =
      "xdstp://traffic-director-global.xds.googleapis.com/envoy.config.cluster.v3.Cluster";
  const int timeout_seconds = 300;
  xds_builder.addClusterDiscoveryService(cds_resources_locator, timeout_seconds);
  engine_builder.setXds(std::move(xds_builder));
  bootstrap = engine_builder.generateBootstrap();
  EXPECT_EQ(bootstrap->dynamic_resources().cds_resources_locator(), cds_resources_locator);
  EXPECT_EQ(bootstrap->dynamic_resources().cds_config().initial_fetch_timeout().seconds(),
            timeout_seconds);
  EXPECT_EQ(bootstrap->dynamic_resources().cds_config().api_config_source().api_type(),
            envoy::config::core::v3::ApiConfigSource::AGGREGATED_GRPC);
  EXPECT_EQ(bootstrap->dynamic_resources().cds_config().api_config_source().transport_api_version(),
            envoy::config::core::v3::ApiVersion::V3);
}

TEST(TestConfig, XdsConfig) {
  EngineBuilder engine_builder;
  const std::string host = "fake-td.googleapis.com";
  const uint32_t port = 12345;
  const std::string authority = absl::StrCat(host, ":", port);

  XdsBuilder xds_builder(/*xds_server_address=*/host,
                         /*xds_server_port=*/port);
  engine_builder.setXds(std::move(xds_builder));
  std::unique_ptr<Bootstrap> bootstrap = engine_builder.generateBootstrap();

  auto& ads_config = bootstrap->dynamic_resources().ads_config();
  EXPECT_EQ(ads_config.api_type(), envoy::config::core::v3::ApiConfigSource::GRPC);
  EXPECT_EQ(ads_config.grpc_services(0).envoy_grpc().cluster_name(), "base");
  EXPECT_EQ(ads_config.grpc_services(0).envoy_grpc().authority(), authority);

  Protobuf::RepeatedPtrField<envoy::config::core::v3::SocketAddress>
      expected_dns_preresolve_hostnames;
  auto& host_addr1 = *expected_dns_preresolve_hostnames.Add();
  host_addr1.set_address(host);
  host_addr1.set_port_value(port);
  EXPECT_TRUE(TestUtility::repeatedPtrFieldEqual(
      getDfpClusterConfig(*bootstrap).dns_cache_config().preresolve_hostnames(),
      expected_dns_preresolve_hostnames));

  // With initial gRPC metadata.
  xds_builder = XdsBuilder(/*xds_server_address=*/host, /*xds_server_port=*/port);
  xds_builder.addInitialStreamHeader(/*header=*/"x-goog-api-key", /*value=*/"A1B2C3")
      .addInitialStreamHeader(/*header=*/"x-android-package",
                              /*value=*/"com.google.envoymobile.io.myapp");
  engine_builder.setXds(std::move(xds_builder));
  bootstrap = engine_builder.generateBootstrap();
  auto& ads_config_with_metadata = bootstrap->dynamic_resources().ads_config();
  EXPECT_EQ(ads_config_with_metadata.api_type(), envoy::config::core::v3::ApiConfigSource::GRPC);
  EXPECT_EQ(ads_config_with_metadata.grpc_services(0).envoy_grpc().cluster_name(), "base");
  EXPECT_EQ(ads_config_with_metadata.grpc_services(0).envoy_grpc().authority(), authority);
  EXPECT_EQ(ads_config_with_metadata.grpc_services(0).initial_metadata(0).key(), "x-goog-api-key");
  EXPECT_EQ(ads_config_with_metadata.grpc_services(0).initial_metadata(0).value(), "A1B2C3");
  EXPECT_EQ(ads_config_with_metadata.grpc_services(0).initial_metadata(1).key(),
            "x-android-package");
  EXPECT_EQ(ads_config_with_metadata.grpc_services(0).initial_metadata(1).value(),
            "com.google.envoymobile.io.myapp");
}

TEST(TestConfig, MoveConstructor) {
  EngineBuilder engine_builder;
  engine_builder.addRuntimeGuard("quic_no_tcp_delay", true).enableGzipDecompression(false);

  std::unique_ptr<Bootstrap> bootstrap = engine_builder.generateBootstrap();
  std::string bootstrap_str = bootstrap->ShortDebugString();
  EXPECT_THAT(bootstrap_str, HasSubstr("\"quic_no_tcp_delay\" value { bool_value: true }"));
  EXPECT_THAT(bootstrap_str, Not(HasSubstr("envoy.filters.http.decompressor")));

  EngineBuilder engine_builder_move1(std::move(engine_builder));
  engine_builder_move1.enableGzipDecompression(true);
  XdsBuilder xdsBuilder("FAKE_XDS_SERVER", 0);
  xdsBuilder.addClusterDiscoveryService();
  engine_builder_move1.setXds(xdsBuilder);
  bootstrap_str = engine_builder_move1.generateBootstrap()->ShortDebugString();
  EXPECT_THAT(bootstrap_str, HasSubstr("\"quic_no_tcp_delay\" value { bool_value: true }"));
  EXPECT_THAT(bootstrap_str, HasSubstr("envoy.filters.http.decompressor"));
  EXPECT_THAT(bootstrap_str, HasSubstr("FAKE_XDS_SERVER"));

  EngineBuilder engine_builder_move2(std::move(engine_builder_move1));
  bootstrap_str = engine_builder_move2.generateBootstrap()->ShortDebugString();
  EXPECT_THAT(bootstrap_str, HasSubstr("\"quic_no_tcp_delay\" value { bool_value: true }"));
  EXPECT_THAT(bootstrap_str, HasSubstr("envoy.filters.http.decompressor"));
  EXPECT_THAT(bootstrap_str, HasSubstr("FAKE_XDS_SERVER"));
}
#endif // ENVOY_MOBILE_XDS

#if defined(USE_MOBILE_ENGINE_BUILDER)
TEST(TestConfig, CustomListenerSuccess) {
  MobileEngineBuilder builder;
  envoy::config::listener::v3::Listener listener;
  listener.set_name("custom_listener_1");
  listener.mutable_api_listener(); // set api_listener
  builder.addApiListener(listener);

  auto bootstrap_or_status = builder.generateBootstrap();
  ASSERT_TRUE(bootstrap_or_status.ok());
  auto bootstrap = std::move(bootstrap_or_status.value());

  ASSERT_EQ(bootstrap->static_resources().listeners_size(), 1);
  EXPECT_EQ(bootstrap->static_resources().listeners(0).name(), "custom_listener_1");
  EXPECT_TRUE(bootstrap->static_resources().listeners(0).has_api_listener());
}

TEST(TestConfig, CustomListenerValidationEmptyName) {
  MobileEngineBuilder builder;
  envoy::config::listener::v3::Listener listener;
  // name is empty
  listener.mutable_api_listener();
  builder.addApiListener(listener);

  auto bootstrap_or_status = builder.generateBootstrap();
  EXPECT_FALSE(bootstrap_or_status.ok());
  EXPECT_EQ(bootstrap_or_status.status().code(), absl::StatusCode::kInvalidArgument);
  EXPECT_THAT(bootstrap_or_status.status().message(),
              HasSubstr("Custom listener must have a name."));
}

TEST(TestConfig, CustomListenerValidationMissingApiListener) {
  MobileEngineBuilder builder;
  envoy::config::listener::v3::Listener listener;
  listener.set_name("custom_listener_1");
  // api_listener is not set
  builder.addApiListener(listener);

  auto bootstrap_or_status = builder.generateBootstrap();
  EXPECT_FALSE(bootstrap_or_status.ok());
  EXPECT_EQ(bootstrap_or_status.status().code(), absl::StatusCode::kInvalidArgument);
  EXPECT_THAT(bootstrap_or_status.status().message(), HasSubstr("must have an api_listener"));
}

TEST(TestConfig, CustomListenerValidationDuplicateName) {
  MobileEngineBuilder builder;
  envoy::config::listener::v3::Listener listener1;
  listener1.set_name("custom_listener_1");
  listener1.mutable_api_listener();
  builder.addApiListener(listener1);

  envoy::config::listener::v3::Listener listener2;
  listener2.set_name("custom_listener_1"); // duplicate name
  listener2.mutable_api_listener();
  builder.addApiListener(listener2);

  auto bootstrap_or_status = builder.generateBootstrap();
  EXPECT_FALSE(bootstrap_or_status.ok());
  EXPECT_EQ(bootstrap_or_status.status().code(), absl::StatusCode::kInvalidArgument);
  EXPECT_THAT(bootstrap_or_status.status().message(),
              HasSubstr("Duplicate listener name: custom_listener_1"));
}

TEST(TestConfig, MultipleCustomListeners) {
  MobileEngineBuilder builder;
  envoy::config::listener::v3::Listener listener1;
  listener1.set_name("custom_listener_1");
  listener1.mutable_api_listener();
  builder.addApiListener(listener1);

  envoy::config::listener::v3::Listener listener2;
  listener2.set_name("custom_listener_2");
  listener2.mutable_api_listener();
  builder.addApiListener(listener2);

  auto bootstrap_or_status = builder.generateBootstrap();
  ASSERT_TRUE(bootstrap_or_status.ok());
  auto bootstrap = std::move(bootstrap_or_status.value());

  ASSERT_EQ(bootstrap->static_resources().listeners_size(), 2);
  EXPECT_EQ(bootstrap->static_resources().listeners(0).name(), "custom_listener_1");
  EXPECT_EQ(bootstrap->static_resources().listeners(1).name(), "custom_listener_2");
}
#endif

} // namespace
} // namespace Envoy
