from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [
        ("posthog", "1279_drop_duckgresserverteam_table"),
    ]

    operations = [
        migrations.AlterField(
            model_name="integration",
            name="kind",
            field=models.CharField(
                choices=[
                    ("anthropic", "Anthropic"),
                    ("apns", "Apple Push"),
                    ("aws-s3", "Aws S3"),
                    ("azure-blob", "Azure Blob"),
                    ("bing-ads", "Bing Ads"),
                    ("clickup", "Clickup"),
                    ("customerio-app", "Customerio App"),
                    ("customerio-track", "Customerio Track"),
                    ("customerio-webhook", "Customerio Webhook"),
                    ("databricks", "Databricks"),
                    ("email", "Email"),
                    ("firebase", "Firebase"),
                    ("github", "Github"),
                    ("gitlab", "Gitlab"),
                    ("google-ads", "Google Ads"),
                    ("google-analytics", "Google Analytics"),
                    ("google-cloud-service-account", "Google Cloud Service Account"),
                    ("google-cloud-storage", "Google Cloud Storage"),
                    ("google-pubsub", "Google Pubsub"),
                    ("google-search-console", "Google Search Console"),
                    ("google-sheets", "Google Sheets"),
                    ("hubspot", "Hubspot"),
                    ("intercom", "Intercom"),
                    ("jira", "Jira"),
                    ("linear", "Linear"),
                    ("linkedin-ads", "Linkedin Ads"),
                    ("meta-ads", "Meta Ads"),
                    ("pardot", "Pardot"),
                    ("pinterest-ads", "Pinterest Ads"),
                    ("postgresql", "Postgresql"),
                    ("posthog", "Posthog"),
                    ("reddit-ads", "Reddit Ads"),
                    ("resend", "Resend"),
                    ("s3-compatible", "S3 Compatible"),
                    ("salesforce", "Salesforce"),
                    ("slack", "Slack"),
                    ("slack-posthog-code", "Slack Posthog Code"),
                    ("snapchat", "Snapchat"),
                    ("snowflake", "Snowflake"),
                    ("stripe", "Stripe"),
                    ("tiktok-ads", "Tiktok Ads"),
                    ("twilio", "Twilio"),
                    ("vercel", "Vercel"),
                ],
                max_length=32,
            ),
        ),
    ]
