"""
HyperCache verification and auto-fix utilities.

Provides reusable verification logic for Celery tasks that verify cache consistency
and automatically fix issues.
"""

import gc
import time
from collections.abc import Callable
from dataclasses import dataclass, field

from django.conf import settings
from django.db import InterfaceError, OperationalError, close_old_connections
from django.db.models import QuerySet

import structlog
from celery.exceptions import SoftTimeLimitExceeded
from prometheus_client import Counter
from tenacity import RetryCallState, Retrying, retry_if_exception_type, stop_after_attempt, wait_exponential

from posthog.models.team.team import Team
from posthog.storage.hypercache_manager import HyperCacheManagementConfig, batch_check_expiry_tracking

logger = structlog.get_logger(__name__)

# Verifies one team's cache: (team, db_batch_data, cache_batch_data) -> dict with "status" and "issue".
VerifyTeamFn = Callable[[Team, dict | None, dict | None], dict]

# Number of batches between progress logs (balance between log spam and visibility)
# With 250 teams/batch and ~238K teams, we have ~950 batches. Logging every 20
# batches gives us ~48 progress logs total.
PROGRESS_LOG_BATCH_INTERVAL = 20

# Prometheus counter for tracking fixes during scheduled verification. `writer`
# attributes the fix to the team's primary cache writer (see
# HyperCacheManagementConfig.get_primary_writer_fn); "python" when unattributed.
HYPERCACHE_VERIFY_FIX_COUNTER = Counter(
    "posthog_hypercache_verify_fixes_total",
    "Cache entries fixed during scheduled verification",
    labelnames=["cache_type", "issue_type", "writer"],
)

# Maximum number of team IDs to store for logging
MAX_FIXED_TEAM_IDS_TO_LOG = 10

# Maximum number of per-team fix detail logs emitted at INFO per verification run.
MAX_FIX_DETAIL_INFO_LOGS = 10

# A verification sweep pages through every team on one long-lived Django connection.
# Poolers rotate and drop that connection mid-sweep, so the batch fetch retries with a
# fresh connection rather than throwing away a partially-completed run.
TEAM_BATCH_FETCH_MAX_ATTEMPTS = 4
TEAM_BATCH_FETCH_BACKOFF_SECONDS = 1.0


class TeamBatchFetchError(Exception):
    """A team batch could not be fetched after exhausting connection retries."""


def _fetch_team_batch(base_qs: QuerySet[Team], last_id: int, chunk_size: int) -> list[Team]:
    """Fetch the next page of teams, reconnecting to Postgres on a dropped connection.

    Django's ``ensure_connection`` only reconnects when the connection object is
    ``None``, so a connection psycopg has already closed keeps raising until it is
    discarded, hence the explicit ``close_old_connections()`` between attempts.

    The Temporal sibling is ``posthog.temporal.common.utils.retry_on_db_connection_drop``,
    which retries only once because activities carry an outer retry policy. This Celery
    sweep has none, so it backs off across attempts and raises ``TeamBatchFetchError``
    for the task to classify the wind-down.
    """

    def _reconnect_and_log(retry_state: RetryCallState) -> None:
        error = retry_state.outcome.exception() if retry_state.outcome else None
        logger.warning(
            "Team batch fetch failed, reconnecting and retrying",
            last_team_id=last_id,
            attempt=retry_state.attempt_number,
            error=str(error),
        )
        close_old_connections()

    fetch_with_retry = Retrying(
        retry=retry_if_exception_type((OperationalError, InterfaceError)),
        stop=stop_after_attempt(TEAM_BATCH_FETCH_MAX_ATTEMPTS),
        wait=wait_exponential(multiplier=TEAM_BATCH_FETCH_BACKOFF_SECONDS, max=10),
        before_sleep=_reconnect_and_log,
        reraise=True,
    )

    try:
        return fetch_with_retry(lambda: list(base_qs.filter(id__gt=last_id)[:chunk_size]))
    except (OperationalError, InterfaceError) as e:
        raise TeamBatchFetchError(
            f"Failed to fetch team batch after {TEAM_BATCH_FETCH_MAX_ATTEMPTS} attempts (last_team_id={last_id})"
        ) from e


@dataclass(frozen=False)
class VerificationResult:
    """Result of verifying all teams' caches."""

    total: int = 0
    cache_miss_fixed: int = 0
    cache_mismatch_fixed: int = 0
    expiry_missing_fixed: int = 0
    fix_failed: int = 0
    errors: int = 0
    skipped_for_grace_period: int = 0
    fixed_team_ids: list[int] = field(default_factory=list)
    skipped_team_ids: list[int] = field(default_factory=list)
    # Per-run logging cap state, not a verification outcome.
    fix_detail_info_logs_emitted: int = 0
    # True when the sweep hit its monotonic deadline and wound down before
    # covering every team, so the caller can record the wind-down. Per-run state,
    # not a verification outcome.
    wound_down_early: bool = False

    @property
    def total_fixed(self) -> int:
        return self.cache_miss_fixed + self.cache_mismatch_fixed + self.expiry_missing_fixed

    def formatted_fixed_team_ids(self) -> str:
        """Format fixed_team_ids for logging: first 10 with '... and N more' if truncated."""
        if not self.fixed_team_ids:
            return "[]"
        if len(self.fixed_team_ids) <= MAX_FIXED_TEAM_IDS_TO_LOG:
            return str(self.fixed_team_ids)
        truncated = self.fixed_team_ids[:MAX_FIXED_TEAM_IDS_TO_LOG]
        remaining = len(self.fixed_team_ids) - MAX_FIXED_TEAM_IDS_TO_LOG
        return f"{truncated} ... and {remaining} more"

    def formatted_skipped_team_ids(self) -> str:
        """Format skipped_team_ids for logging: first 10 with '... and N more' if truncated."""
        if not self.skipped_team_ids:
            return "[]"
        if len(self.skipped_team_ids) <= MAX_FIXED_TEAM_IDS_TO_LOG:
            return str(self.skipped_team_ids)
        truncated = self.skipped_team_ids[:MAX_FIXED_TEAM_IDS_TO_LOG]
        remaining = len(self.skipped_team_ids) - MAX_FIXED_TEAM_IDS_TO_LOG
        return f"{truncated} ... and {remaining} more"


def verify_and_fix_all_teams(
    config: HyperCacheManagementConfig,
    verify_team_fn: VerifyTeamFn,
    cache_type: str,
    chunk_size: int | None = None,
    *,
    stop_time: float | None = None,
) -> VerificationResult:
    """
    Verify caches for teams in the configured scope and auto-fix any issues.

    Uses ``config.get_teams_queryset()`` to determine scope — if a queryset
    function is configured, only those teams are processed; otherwise all teams
    are verified, and teams are processed in chunks using seek-based pagination
    for memory efficiency. For each team,
    calls verify_team_fn to check cache consistency. If issues are found,
    automatically fixes them using config.update_fn.

    Args:
        config: HyperCache management configuration with update_fn
        verify_team_fn: Function that takes (team, db_batch_data, cache_batch_data) and returns
            a dict with 'status' ("match", "miss", "mismatch") and 'issue' type
        cache_type: Name for metrics/logging (e.g., "team_metadata", "flags")
        chunk_size: Number of teams to process per batch. Defaults to
            settings.FLAGS_CACHE_VERIFICATION_CHUNK_SIZE (the more conservative setting).
        stop_time: Monotonic deadline (from ``time.monotonic()``). When set, the sweep
            winds down at the first batch boundary past it, returning a partial result
            instead of running until Celery's hard time limit SIGKILLs the worker.

    Returns:
        VerificationResult with stats and list of fixed team IDs
    """
    # Clear any accumulated garbage before starting to maximize available memory.
    # Workers can accumulate memory from previous tasks, and starting clean
    # gives us more headroom for this memory-intensive operation.
    gc.collect()

    if chunk_size is None:
        # Use the more conservative flags setting as default
        chunk_size = settings.FLAGS_CACHE_VERIFICATION_CHUNK_SIZE

    result = VerificationResult()
    last_id = 0

    base_qs = config.narrow_team_queryset(config.get_teams_queryset()).order_by("id")

    batch_number = 0
    while True:
        teams = _fetch_team_batch(base_qs, last_id, chunk_size)

        if not teams:
            break

        batch_number += 1
        batch_start = result.total
        batch_fixes_start = result.total_fixed
        batch_fix_failures_start = result.fix_failed

        _verify_and_fix_batch(teams, config, verify_team_fn, cache_type, result)

        batch_verified = result.total - batch_start
        batch_fixed = result.total_fixed - batch_fixes_start
        batch_fix_failures = result.fix_failed - batch_fix_failures_start

        # Log periodically to avoid log spam while still showing progress
        log_message = None
        if batch_number % PROGRESS_LOG_BATCH_INTERVAL == 0:
            log_message = "Verification progress"
        elif batch_fixed > 0:
            log_message = "Batch completed with fixes"

        if log_message:
            logger.info(
                log_message,
                cache_type=cache_type,
                batch_number=batch_number,
                batch_verified=batch_verified,
                batch_fixed=batch_fixed,
                batch_fix_failures=batch_fix_failures,
                teams_verified_total=result.total,
                teams_fixed_total=result.total_fixed,
                cache_miss_fixed_total=result.cache_miss_fixed,
                cache_mismatch_fixed_total=result.cache_mismatch_fixed,
                expiry_missing_fixed_total=result.expiry_missing_fixed,
                fix_failures_total=result.fix_failed,
                last_team_id=teams[-1].id,
            )

        # Wind down at a batch boundary once the deadline passes, so the run ends
        # cleanly and records the wind-down instead of being SIGKILLed mid-batch past
        # the hard time limit (which reports nothing). The cursor is not persisted, so
        # the next cycle restarts from id 0 rather than resuming here: a run that winds
        # down repeatedly leaves the same tail of high-id teams unverified until it can
        # finish within the deadline. Only wind down when teams actually remain: a
        # deadline that trips on the final batch has already covered every team, so it
        # completed rather than winding down early.
        if stop_time is not None and time.monotonic() > stop_time and _fetch_team_batch(base_qs, teams[-1].id, 1):
            result.wound_down_early = True
            logger.warning(
                "Cache verification wound down early, deadline reached",
                cache_type=cache_type,
                teams_verified_total=result.total,
                last_team_id=teams[-1].id,
            )
            break

        last_id = teams[-1].id

        # Explicitly release memory between batches to prevent accumulation.
        # Python's GC doesn't aggressively return memory to the OS, so without this,
        # memory can accumulate across batches and contribute to OOMs in workers
        # with high baseline memory from other tasks.
        gc.collect()

    return result


def _verify_and_fix_batch(
    teams: list[Team],
    config: HyperCacheManagementConfig,
    verify_team_fn: VerifyTeamFn,
    cache_type: str,
    result: VerificationResult,
) -> None:
    """
    Verify and fix a batch of teams.

    Args:
        teams: List of Team objects to verify
        config: HyperCache management configuration
        verify_team_fn: Function to verify a single team (team, db_batch_data, cache_batch_data)
        cache_type: Name for metrics/logging
        result: VerificationResult to accumulate stats
    """
    # Batch-read cached values using MGET (single Redis round trip)
    try:
        cache_batch_data = config.hypercache.batch_get_from_cache(teams)
    except SoftTimeLimitExceeded:
        raise
    except Exception as e:
        logger.warning("Batch cache read failed, falling back to individual lookups", error=str(e))
        cache_batch_data = {}

    # Batch-check expiry tracking
    expiry_status = batch_check_expiry_tracking(teams, config)

    # Batch-check which teams should skip fixes (e.g., grace period for recently updated flags)
    # This is done once per batch to avoid N+1 queries
    team_ids_to_skip_fix: set[int] = set()
    if config.get_team_ids_to_skip_fix_fn:
        try:
            team_ids_to_skip_fix = config.get_team_ids_to_skip_fix_fn([t.id for t in teams])
        except SoftTimeLimitExceeded:
            raise
        except Exception as e:
            logger.warning("Batch skip-fix check failed, proceeding without skips", error=str(e))

    # Batch-load DB data for all teams in the batch
    db_batch_data = None
    if config.hypercache.batch_load_fn:
        try:
            batch_load_start = time.time()
            db_batch_data = config.hypercache.batch_load_fn(teams)
            logger.debug(
                "Batch DB load completed",
                cache_type=cache_type,
                team_count=len(teams),
                duration_seconds=time.time() - batch_load_start,
            )
        except SoftTimeLimitExceeded:
            raise
        except Exception as e:
            logger.warning("Batch load failed, falling back to individual loads", error=str(e))

    for team in teams:
        result.total += 1

        try:
            verification = verify_team_fn(team, db_batch_data, cache_batch_data)
        except SoftTimeLimitExceeded:
            # The task ran out of time, not the verify call. Let it propagate so the
            # run winds down instead of looping through the remaining teams; this
            # team is re-verified on the next cycle.
            raise
        except Exception as e:
            result.errors += 1
            logger.exception("Error verifying team", team_id=team.id, error=str(e))
            continue

        # Ensure db_data is available for cache fixes even if the verify
        # function didn't include it. This avoids a redundant per-team DB
        # query inside _fix_and_record.
        if "db_data" not in verification and db_batch_data:
            db_data = db_batch_data.get(team.id)
            if db_data is not None:
                verification["db_data"] = db_data

        status = verification["status"]

        # Determine issue type (if any)
        issue_type: str | None = None
        if status == "miss":
            issue_type = "cache_miss"
        elif status == "mismatch":
            issue_type = "cache_mismatch"
        elif status == "match":
            # Check expiry tracking for teams with valid cache
            identifier = config.hypercache.get_cache_identifier(team)
            if expiry_status and not expiry_status.get(identifier, True):
                issue_type = "expiry_missing"

        if issue_type:
            # The grace period guards against clobbering an in-flight async rebuild,
            # which only matters when an entry EXISTS (mismatch/expiry). A full
            # cache_miss has nothing to clobber and hard-fails no-DB-fallback readers
            # (e.g. the Rust /flags/definitions endpoint → 503). This routine is shared
            # by every hypercache, so the miss exemption is opt-in per config: only the
            # flag_definitions caches set repair_miss_during_grace_period; read-through
            # caches (flags, team_metadata) cold-load on miss and keep the skip.
            repair_miss = issue_type == "cache_miss" and config.repair_miss_during_grace_period
            if not repair_miss and team.id in team_ids_to_skip_fix:
                result.skipped_for_grace_period += 1
                if len(result.skipped_team_ids) < MAX_FIXED_TEAM_IDS_TO_LOG:
                    result.skipped_team_ids.append(team.id)
                logger.debug(
                    "Skipping fix due to grace period",
                    team_id=team.id,
                    issue_type=issue_type,
                    cache_type=cache_type,
                )
                continue

            _fix_and_record(
                team=team,
                config=config,
                issue_type=issue_type,
                cache_type=cache_type,
                result=result,
                verification=verification,
            )


def _fix_and_record(
    *,
    team: Team,
    config: HyperCacheManagementConfig,
    issue_type: str,
    cache_type: str,
    result: VerificationResult,
    verification: dict,
) -> None:
    """
    Fix a team's cache and record the result.

    Args:
        team: Team to fix
        config: HyperCache management configuration
        issue_type: Type of issue (cache_miss, cache_mismatch, expiry_missing)
        cache_type: Cache type for metrics
        result: VerificationResult to update
        verification: Verification result dict containing diff info.
            If it contains a "db_data" key, that data is written directly to
            cache to avoid a redundant DB query.
    """
    writer = "python"
    if config.get_primary_writer_fn is not None:
        try:
            writer = config.get_primary_writer_fn(team.id)
        except SoftTimeLimitExceeded:
            # The task ran out of time during attribution, not an attribution
            # failure. Let it propagate so the run winds down, matching the write
            # path below and the other guards in this file.
            raise
        except Exception:
            # Attribution must never fail the repair itself.
            writer = "unknown"

    # Log what's being fixed, including diff details for mismatches
    log_kwargs: dict = {"team_id": team.id, "issue_type": issue_type, "cache_type": cache_type, "writer": writer}
    if "diff_fields" in verification:
        log_kwargs["diff_fields"] = verification["diff_fields"]
    if "diff_flags" in verification:
        log_kwargs["diff_flags"] = verification["diff_flags"]
    if result.fix_detail_info_logs_emitted < MAX_FIX_DETAIL_INFO_LOGS:
        logger.info("Fixing cache entry", **log_kwargs)
        result.fix_detail_info_logs_emitted += 1

    try:
        # Use preloaded db_data if available to avoid redundant DB query
        if "db_data" in verification:
            # The direct write bypasses update_fn's internal guards, so apply the
            # config's write guard here too (e.g. refuse to cache an emptied
            # group_type_mapping over populated data). A veto is neither fix nor failure.
            if config.should_skip_write is not None and config.should_skip_write(team, verification["db_data"]):
                return
            config.hypercache.set_cache_value(team, verification["db_data"])
            success = True
        else:
            success = config.update_fn(team)
    except SoftTimeLimitExceeded:
        # The task ran out of time mid-write, not a cache/storage failure. Let it
        # propagate so the run winds down instead of logging a misleading error and
        # continuing; this team is re-fixed on the next cycle.
        raise
    except Exception as e:
        success = False
        logger.exception("Error fixing cache", team_id=team.id, issue_type=issue_type, error=str(e))

    if success:
        # Increment appropriate counter
        if issue_type == "cache_miss":
            result.cache_miss_fixed += 1
        elif issue_type == "cache_mismatch":
            result.cache_mismatch_fixed += 1
        elif issue_type == "expiry_missing":
            result.expiry_missing_fixed += 1

        result.fixed_team_ids.append(team.id)

        # Update Prometheus metric
        HYPERCACHE_VERIFY_FIX_COUNTER.labels(cache_type=cache_type, issue_type=issue_type, writer=writer).inc()
    else:
        result.fix_failed += 1


def _run_verification_for_cache(
    config: HyperCacheManagementConfig,
    verify_team_fn: VerifyTeamFn,
    cache_type: str,
    chunk_size: int,
    stop_time: float | None = None,
) -> VerificationResult:
    """
    Run verification for a single cache type and log results.

    Args:
        config: HyperCache management configuration
        verify_team_fn: Function to verify a single team
        cache_type: Name for metrics/logging
        chunk_size: Number of teams to process per batch
        stop_time: Monotonic deadline forwarded to verify_and_fix_all_teams for
            early wind-down.

    Returns:
        VerificationResult with stats
    """
    start_time = time.time()
    logger.info(f"Starting {cache_type} cache verification", chunk_size=chunk_size)

    result = verify_and_fix_all_teams(
        config=config,
        verify_team_fn=verify_team_fn,
        cache_type=cache_type,
        chunk_size=chunk_size,
        stop_time=stop_time,
    )

    duration = time.time() - start_time

    log_kwargs: dict = {
        "cache_type": cache_type,
        "teams_verified": result.total,
        "teams_fixed": result.total_fixed,
        "cache_miss_fixed": result.cache_miss_fixed,
        "cache_mismatch_fixed": result.cache_mismatch_fixed,
        "expiry_missing_fixed": result.expiry_missing_fixed,
        "fix_failures": result.fix_failed,
        "errors": result.errors,
        "fixed_team_ids": result.formatted_fixed_team_ids(),
        "duration_seconds": duration,
    }

    # Only include skipped info if there were skips (keeps logs clean for caches without grace period)
    if result.skipped_for_grace_period > 0:
        log_kwargs["skipped_for_grace_period"] = result.skipped_for_grace_period
        log_kwargs["skipped_team_ids"] = result.formatted_skipped_team_ids()

    logger.info(f"Completed {cache_type} cache verification", **log_kwargs)

    return result
