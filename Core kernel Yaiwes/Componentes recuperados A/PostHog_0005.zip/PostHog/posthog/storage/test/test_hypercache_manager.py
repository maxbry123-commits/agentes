"""
Tests for HyperCache management operations.

Covers:
- Django key prefix extraction for Redis patterns
- Redis URL routing for dedicated caches
- Cache stats operations
"""

from posthog.test.base import BaseTest
from unittest.mock import MagicMock, patch

from prometheus_client import CollectorRegistry

from posthog.models.team.team import Team
from posthog.storage.hypercache import HyperCache
from posthog.storage.hypercache_manager import (
    HyperCacheManagementConfig,
    get_cache_stats,
    push_hypercache_stats_metrics,
    push_hypercache_teams_processed_metrics,
    warm_caches,
)


def create_test_hypercache(
    namespace: str = "test_namespace",
    value: str = "test_value",
    token_based: bool = False,
    expiry_sorted_set_key: str = "test_cache_expiry",
) -> HyperCache:
    """Create a test HyperCache with minimal setup."""

    def load_fn(team):
        return {"test": "data"}

    return HyperCache(
        namespace=namespace,
        value=value,
        load_fn=load_fn,
        token_based=token_based,
        expiry_sorted_set_key=expiry_sorted_set_key,
    )


def create_test_config(
    namespace: str = "test_namespace",
    value: str = "test_value",
    token_based: bool = False,
) -> HyperCacheManagementConfig:
    """Create a test HyperCacheManagementConfig with minimal setup."""

    def update_fn(team, ttl=None):
        return True

    hypercache = create_test_hypercache(
        namespace=namespace,
        value=value,
        token_based=token_based,
    )

    return HyperCacheManagementConfig(
        hypercache=hypercache,
        update_fn=update_fn,
        cache_name="test_cache",
    )


class TestDjangoKeyPrefix(BaseTest):
    """Test _django_key_prefix property extraction."""

    def test_extracts_prefix_from_cache_client(self):
        """Test that _django_key_prefix extracts prefix and version from cache client."""
        config = create_test_config()

        # Mock cache client with key_prefix and version
        mock_cache_client = MagicMock()
        mock_cache_client.key_prefix = "posthog"
        mock_cache_client.version = 1

        with patch.object(config.hypercache, "cache_client", mock_cache_client):
            prefix = config._django_key_prefix

        assert prefix == "posthog:1:"

    def test_returns_empty_string_when_no_prefix(self):
        """Test that _django_key_prefix returns empty string when key_prefix is empty."""
        config = create_test_config()

        mock_cache_client = MagicMock()
        mock_cache_client.key_prefix = ""
        mock_cache_client.version = 1

        with patch.object(config.hypercache, "cache_client", mock_cache_client):
            prefix = config._django_key_prefix

        assert prefix == ""

    def test_handles_missing_key_prefix_attribute(self):
        """Test graceful handling when cache client lacks key_prefix attribute."""
        config = create_test_config()

        mock_cache_client = MagicMock(spec=[])  # No attributes
        del mock_cache_client.key_prefix  # Ensure it's not present

        with patch.object(config.hypercache, "cache_client", mock_cache_client):
            prefix = config._django_key_prefix

        assert prefix == ""

    def test_handles_missing_version_attribute(self):
        """Test that missing version defaults to 1."""
        config = create_test_config()

        mock_cache_client = MagicMock(spec=["key_prefix"])
        mock_cache_client.key_prefix = "posthog"
        # version is missing, should default to 1

        with patch.object(config.hypercache, "cache_client", mock_cache_client):
            prefix = config._django_key_prefix

        assert prefix == "posthog:1:"

    def test_handles_custom_version(self):
        """Test that custom version is used in prefix."""
        config = create_test_config()

        mock_cache_client = MagicMock()
        mock_cache_client.key_prefix = "posthog"
        mock_cache_client.version = 2

        with patch.object(config.hypercache, "cache_client", mock_cache_client):
            prefix = config._django_key_prefix

        assert prefix == "posthog:2:"


class TestRedisPatterns(BaseTest):
    """Test Redis pattern generation with Django prefix."""

    def test_redis_pattern_includes_django_prefix(self):
        """Test that redis_pattern includes the Django key prefix."""
        config = create_test_config(namespace="feature_flags", value="flags.json")

        mock_cache_client = MagicMock()
        mock_cache_client.key_prefix = "posthog"
        mock_cache_client.version = 1

        with patch.object(config.hypercache, "cache_client", mock_cache_client):
            pattern = config.redis_pattern

        assert pattern == "posthog:1:cache/teams/*/feature_flags/*"

    def test_redis_stats_pattern_includes_django_prefix(self):
        """Test that redis_stats_pattern includes the Django key prefix."""
        config = create_test_config(namespace="feature_flags", value="flags.json")

        mock_cache_client = MagicMock()
        mock_cache_client.key_prefix = "posthog"
        mock_cache_client.version = 1

        with patch.object(config.hypercache, "cache_client", mock_cache_client):
            pattern = config.redis_stats_pattern

        assert pattern == "posthog:1:cache/teams/*/feature_flags/flags.json"

    def test_redis_pattern_for_token_based_cache(self):
        """Test that token-based caches use team_tokens prefix."""
        config = create_test_config(namespace="feature_flags", value="flags.json", token_based=True)

        mock_cache_client = MagicMock()
        mock_cache_client.key_prefix = "posthog"
        mock_cache_client.version = 1

        with patch.object(config.hypercache, "cache_client", mock_cache_client):
            pattern = config.redis_pattern

        assert pattern == "posthog:1:cache/team_tokens/*/feature_flags/*"

    def test_redis_pattern_without_django_prefix(self):
        """Test pattern generation when there's no Django prefix."""
        config = create_test_config(namespace="feature_flags", value="flags.json")

        mock_cache_client = MagicMock()
        mock_cache_client.key_prefix = ""
        mock_cache_client.version = 1

        with patch.object(config.hypercache, "cache_client", mock_cache_client):
            pattern = config.redis_pattern

        assert pattern == "cache/teams/*/feature_flags/*"


class TestRedisUrlRouting(BaseTest):
    """Test that cache operations use the correct Redis instance."""

    @patch("posthog.storage.hypercache_manager.get_client")
    def test_get_cache_stats_uses_config_redis_url(self, mock_get_client):
        """Test that get_cache_stats uses the Redis URL from config."""
        config = create_test_config()

        mock_redis = MagicMock()
        mock_get_client.return_value = mock_redis
        mock_redis.scan_iter.return_value = iter([])
        mock_redis.zcard.return_value = 0

        # Mock the hypercache's redis_url to simulate a dedicated Redis
        with patch.object(config.hypercache, "redis_url", "redis://dedicated:6379/1"):
            with patch("posthog.models.team.team.Team.objects.count", return_value=10):
                get_cache_stats(config)

        mock_get_client.assert_called_once_with("redis://dedicated:6379/1")

    @patch("posthog.storage.hypercache_manager.get_client")
    def test_get_cache_stats_uses_default_redis_url(self, mock_get_client):
        """Test that get_cache_stats uses the default Redis URL from settings."""
        config = create_test_config()

        mock_redis = MagicMock()
        mock_get_client.return_value = mock_redis
        mock_redis.scan_iter.return_value = iter([])
        mock_redis.zcard.return_value = 0

        with patch("posthog.models.team.team.Team.objects.count", return_value=10):
            get_cache_stats(config)

        # Should be called with whatever redis_url the hypercache has (settings.REDIS_URL)
        mock_get_client.assert_called_once()
        # The default hypercache uses settings.REDIS_URL
        call_args = mock_get_client.call_args[0]
        assert call_args[0] is not None  # Should have a URL from settings


class TestGetCacheStats(BaseTest):
    """Test get_cache_stats functionality."""

    @patch("posthog.storage.hypercache_manager.get_client")
    def test_returns_stats_with_coverage(self, mock_get_client):
        """Test that get_cache_stats returns correct coverage statistics."""
        config = create_test_config()

        mock_redis = MagicMock()
        mock_get_client.return_value = mock_redis

        # Mock scan returning 5 keys
        mock_redis.scan_iter.side_effect = [
            iter([b"key1", b"key2", b"key3", b"key4", b"key5"]),  # TTL scan
            iter([b"key1", b"key2"]),  # Memory sample
        ]

        mock_pipeline = MagicMock()
        mock_redis.pipeline.return_value = mock_pipeline
        mock_pipeline.execute.side_effect = [
            [3600, 86400, 604800, 700000, -1],  # TTL results
            [1024, 2048],  # Memory results
        ]
        mock_redis.zcard.return_value = 5

        with patch("posthog.models.team.team.Team.objects.count", return_value=10):
            stats = get_cache_stats(config)

        assert stats["total_cached"] == 5
        assert stats["total_teams"] == 10
        assert stats["cache_coverage_percent"] == 50.0
        assert stats["expiry_tracked"] == 5

    @patch("posthog.storage.hypercache_manager.get_client")
    def test_ttl_distribution_buckets(self, mock_get_client):
        """Test that TTL distribution is correctly bucketed."""
        config = create_test_config()

        mock_redis = MagicMock()
        mock_get_client.return_value = mock_redis

        mock_redis.scan_iter.side_effect = [
            iter([b"k1", b"k2", b"k3", b"k4", b"k5"]),
            iter([]),  # No memory sampling
        ]

        mock_pipeline = MagicMock()
        mock_redis.pipeline.return_value = mock_pipeline
        mock_pipeline.execute.return_value = [
            -1,  # expired
            1800,  # expires in 1h (< 3600)
            43200,  # expires in 24h (< 86400)
            302400,  # expires in 7d (< 604800)
            700000,  # expires later (> 604800)
        ]
        mock_redis.zcard.return_value = 5

        with patch("posthog.models.team.team.Team.objects.count", return_value=10):
            stats = get_cache_stats(config)

        assert stats["ttl_distribution"]["expired"] == 1
        assert stats["ttl_distribution"]["expires_1h"] == 1
        assert stats["ttl_distribution"]["expires_24h"] == 1
        assert stats["ttl_distribution"]["expires_7d"] == 1
        assert stats["ttl_distribution"]["expires_later"] == 1

    @patch("posthog.storage.hypercache_manager.get_client")
    def test_returns_error_on_exception(self, mock_get_client):
        """Test that get_cache_stats returns error dict on exception."""
        config = create_test_config()

        mock_get_client.side_effect = Exception("Redis connection failed")

        stats = get_cache_stats(config)

        assert "error" in stats
        assert stats["namespace"] == "test_namespace"

    @patch("posthog.storage.hypercache_manager.get_client")
    def test_uses_correct_pattern_with_django_prefix(self, mock_get_client):
        """Test that scan uses the stats pattern with Django prefix."""
        config = create_test_config(namespace="feature_flags", value="flags.json")

        mock_cache_client = MagicMock()
        mock_cache_client.key_prefix = "posthog"
        mock_cache_client.version = 1

        mock_redis = MagicMock()
        mock_get_client.return_value = mock_redis
        mock_redis.scan_iter.return_value = iter([])
        mock_redis.zcard.return_value = 0

        with patch.object(config.hypercache, "cache_client", mock_cache_client):
            with patch("posthog.models.team.team.Team.objects.count", return_value=10):
                get_cache_stats(config)

        # First scan call should use the stats pattern
        first_call = mock_redis.scan_iter.call_args_list[0]
        assert first_call[1]["match"] == "posthog:1:cache/teams/*/feature_flags/flags.json"


class TestPushHypercacheStatsMetrics(BaseTest):
    """Test push_hypercache_stats_metrics functionality."""

    @patch("posthog.storage.hypercache_manager.pushed_metrics_registry")
    def test_pushes_metrics_to_pushgateway(self, mock_registry_cm):
        """Metrics are pushed to the namespace+cache_name group, labeled by both."""
        registry = CollectorRegistry()
        mock_registry_cm.return_value.__enter__ = MagicMock(return_value=registry)
        mock_registry_cm.return_value.__exit__ = MagicMock(return_value=False)

        with self.settings(PROM_PUSHGATEWAY_ADDRESS="http://pushgateway:9091"):
            push_hypercache_stats_metrics(
                namespace="feature_flags",
                cache_name="flags",
                coverage_percent=85.5,
                entries_total=1000,
                expiry_tracked_total=950,
                size_bytes=1024000,
            )

        mock_registry_cm.assert_called_once_with("hypercache_stats_feature_flags_flags")
        labels = {"namespace": "feature_flags", "cache_name": "flags"}
        assert registry.get_sample_value("posthog_hypercache_coverage_percent", labels) == 85.5
        assert registry.get_sample_value("posthog_hypercache_entries_total", labels) == 1000
        assert registry.get_sample_value("posthog_hypercache_expiry_tracked_total", labels) == 950
        assert registry.get_sample_value("posthog_hypercache_size_bytes", labels) == 1024000

    @patch("posthog.storage.hypercache_manager.pushed_metrics_registry")
    def test_skips_push_when_no_pushgateway_address(self, mock_registry_cm):
        """Test that no push happens when PROM_PUSHGATEWAY_ADDRESS is not set."""
        with self.settings(PROM_PUSHGATEWAY_ADDRESS=None):
            push_hypercache_stats_metrics(
                namespace="feature_flags",
                cache_name="flags",
                coverage_percent=85.5,
                entries_total=1000,
                expiry_tracked_total=950,
                size_bytes=1024000,
            )

        mock_registry_cm.assert_not_called()

    @patch("posthog.storage.hypercache_manager.pushed_metrics_registry")
    def test_skips_size_gauge_when_size_bytes_is_none(self, mock_registry_cm):
        """Test that size gauge is not created when size_bytes is None."""
        registry = CollectorRegistry()
        mock_registry_cm.return_value.__enter__ = MagicMock(return_value=registry)
        mock_registry_cm.return_value.__exit__ = MagicMock(return_value=False)

        with self.settings(PROM_PUSHGATEWAY_ADDRESS="http://pushgateway:9091"):
            push_hypercache_stats_metrics(
                namespace="team_metadata",
                cache_name="team_metadata",
                coverage_percent=90.0,
                entries_total=500,
                expiry_tracked_total=500,
                size_bytes=None,
            )

        mock_registry_cm.assert_called_once_with("hypercache_stats_team_metadata_team_metadata")
        labels = {"namespace": "team_metadata", "cache_name": "team_metadata"}
        assert registry.get_sample_value("posthog_hypercache_size_bytes", labels) is None
        assert registry.get_sample_value("posthog_hypercache_coverage_percent", labels) == 90.0
        assert registry.get_sample_value("posthog_hypercache_entries_total", labels) == 500
        assert registry.get_sample_value("posthog_hypercache_expiry_tracked_total", labels) == 500

    @patch("posthog.storage.hypercache_manager.pushed_metrics_registry")
    @patch("posthog.storage.hypercache_manager.logger")
    def test_logs_warning_on_push_failure(self, mock_logger, mock_registry_cm):
        """Test that a warning is logged when push fails."""
        mock_registry_cm.return_value.__enter__ = MagicMock(side_effect=Exception("Connection failed"))
        mock_registry_cm.return_value.__exit__ = MagicMock(return_value=False)

        with self.settings(PROM_PUSHGATEWAY_ADDRESS="http://pushgateway:9091"):
            push_hypercache_stats_metrics(
                namespace="feature_flags",
                cache_name="flags",
                coverage_percent=85.5,
                entries_total=1000,
                expiry_tracked_total=950,
                size_bytes=1024000,
            )

        mock_logger.warning.assert_called_once()
        assert "Failed to push hypercache stats" in str(mock_logger.warning.call_args)

    @patch("posthog.storage.hypercache_manager.pushed_metrics_registry")
    def test_caches_sharing_namespace_use_distinct_groups(self, mock_registry_cm):
        """Caches sharing a namespace must push to distinct Pushgateway groups.

        team_metadata and llm_gateway_policy both use namespace="team_metadata";
        without cache_name in the group key they would overwrite each other.
        """
        mock_registry = MagicMock()
        mock_registry_cm.return_value.__enter__ = MagicMock(return_value=mock_registry)
        mock_registry_cm.return_value.__exit__ = MagicMock(return_value=False)

        with self.settings(PROM_PUSHGATEWAY_ADDRESS="http://pushgateway:9091"):
            push_hypercache_stats_metrics(
                namespace="team_metadata",
                cache_name="team_metadata",
                coverage_percent=100.0,
                entries_total=409000,
                expiry_tracked_total=409000,
                size_bytes=378_000_000,
            )
            push_hypercache_stats_metrics(
                namespace="team_metadata",
                cache_name="llm_gateway_policy",
                coverage_percent=2.6,
                entries_total=10900,
                expiry_tracked_total=10900,
                size_bytes=1_000_000,
            )

        group_names = [call.args[0] for call in mock_registry_cm.call_args_list]
        assert group_names == [
            "hypercache_stats_team_metadata_team_metadata",
            "hypercache_stats_team_metadata_llm_gateway_policy",
        ]


class TestPushHypercacheTeamsProcessedMetrics(BaseTest):
    """Test push_hypercache_teams_processed_metrics functionality."""

    @patch("posthog.storage.hypercache_manager.pushed_metrics_registry")
    def test_pushes_metrics_to_pushgateway(self, mock_registry_cm):
        """Teams-processed counts are pushed to the namespace+cache_name group, labeled by both."""
        registry = CollectorRegistry()
        mock_registry_cm.return_value.__enter__ = MagicMock(return_value=registry)
        mock_registry_cm.return_value.__exit__ = MagicMock(return_value=False)

        with self.settings(PROM_PUSHGATEWAY_ADDRESS="http://pushgateway:9091"):
            push_hypercache_teams_processed_metrics(
                namespace="feature_flags",
                cache_name="flags",
                successful=900,
                failed=100,
            )

        mock_registry_cm.assert_called_once_with("hypercache_teams_processed_feature_flags_flags")
        base = {"namespace": "feature_flags", "cache_name": "flags"}
        assert (
            registry.get_sample_value("posthog_hypercache_teams_processed_last_run", {**base, "result": "success"})
            == 900
        )
        assert (
            registry.get_sample_value("posthog_hypercache_teams_processed_last_run", {**base, "result": "failure"})
            == 100
        )

    @patch("posthog.storage.hypercache_manager.pushed_metrics_registry")
    def test_skips_push_when_no_pushgateway_address(self, mock_registry_cm):
        """No push happens when PROM_PUSHGATEWAY_ADDRESS is not set."""
        with self.settings(PROM_PUSHGATEWAY_ADDRESS=None):
            push_hypercache_teams_processed_metrics(
                namespace="feature_flags",
                cache_name="flags",
                successful=900,
                failed=100,
            )

        mock_registry_cm.assert_not_called()

    @patch("posthog.storage.hypercache_manager.pushed_metrics_registry")
    def test_caches_sharing_namespace_use_distinct_groups(self, mock_registry_cm):
        """Caches sharing a namespace must push to distinct Pushgateway groups.

        team_metadata and llm_gateway_policy both use namespace="team_metadata";
        without cache_name in the group key they would overwrite each other.
        """
        mock_registry = MagicMock()
        mock_registry_cm.return_value.__enter__ = MagicMock(return_value=mock_registry)
        mock_registry_cm.return_value.__exit__ = MagicMock(return_value=False)

        with self.settings(PROM_PUSHGATEWAY_ADDRESS="http://pushgateway:9091"):
            push_hypercache_teams_processed_metrics(
                namespace="team_metadata",
                cache_name="team_metadata",
                successful=409000,
                failed=0,
            )
            push_hypercache_teams_processed_metrics(
                namespace="team_metadata",
                cache_name="llm_gateway_policy",
                successful=10900,
                failed=0,
            )

        group_names = [call.args[0] for call in mock_registry_cm.call_args_list]
        assert group_names == [
            "hypercache_teams_processed_team_metadata_team_metadata",
            "hypercache_teams_processed_team_metadata_llm_gateway_policy",
        ]


class TestConfigGetTeamsQuerysetFn(BaseTest):
    """Test HyperCacheManagementConfig.get_teams_queryset_fn and get_teams_queryset()."""

    def test_default_is_none(self):
        config = create_test_config()
        assert config.get_teams_queryset_fn is None

    def test_can_be_set_to_callable(self):
        from posthog.models.team.team import Team

        hypercache = create_test_hypercache()

        def update_fn(team, ttl=None):
            return True

        config = HyperCacheManagementConfig(
            hypercache=hypercache,
            update_fn=update_fn,
            cache_name="test_cache",
            get_teams_queryset_fn=lambda: Team.objects.all(),
        )
        assert config.get_teams_queryset_fn is not None
        assert config.get_teams_queryset_fn().count() >= 0

    def test_get_teams_queryset_uses_fn_when_set(self):
        from posthog.models.team.team import Team

        hypercache = create_test_hypercache()

        def update_fn(team, ttl=None):
            return True

        config = HyperCacheManagementConfig(
            hypercache=hypercache,
            update_fn=update_fn,
            cache_name="test_cache",
            get_teams_queryset_fn=lambda: Team.objects.none(),
        )
        assert config.get_teams_queryset().count() == 0

    def test_get_teams_queryset_falls_back_to_all_teams(self):
        config = create_test_config()
        assert config.get_teams_queryset().count() >= 1


class TestWarmCachesQuerysetScoping(BaseTest):
    """Test that warm_caches() scopes teams via config.get_teams_queryset()."""

    def test_scopes_to_queryset_when_configured(self):
        from posthog.models import Team

        team2 = Team.objects.create(organization=self.organization, name="Team 2")

        warmed_team_ids: list[int] = []

        def tracking_update_fn(team, ttl=None):
            warmed_team_ids.append(team.id)
            return True

        hypercache = create_test_hypercache()
        config = HyperCacheManagementConfig(
            hypercache=hypercache,
            update_fn=tracking_update_fn,
            cache_name="test_cache",
            get_teams_queryset_fn=lambda: Team.objects.filter(id=team2.id),
        )

        warm_caches(config, batch_size=100, stagger_ttl=False)

        assert team2.id in warmed_team_ids
        assert self.team.id not in warmed_team_ids

    def test_warms_all_teams_when_queryset_fn_is_none(self):
        from posthog.models import Team

        team2 = Team.objects.create(organization=self.organization, name="Team 2")

        warmed_team_ids: list[int] = []

        def tracking_update_fn(team, ttl=None):
            warmed_team_ids.append(team.id)
            return True

        hypercache = create_test_hypercache()
        config = HyperCacheManagementConfig(
            hypercache=hypercache,
            update_fn=tracking_update_fn,
            cache_name="test_cache",
        )

        warm_caches(config, batch_size=100, stagger_ttl=False)

        assert self.team.id in warmed_team_ids
        assert team2.id in warmed_team_ids

    def test_empty_queryset_warms_zero_teams(self):
        from posthog.models import Team

        warmed_team_ids: list[int] = []

        def tracking_update_fn(team, ttl=None):
            warmed_team_ids.append(team.id)
            return True

        hypercache = create_test_hypercache()
        config = HyperCacheManagementConfig(
            hypercache=hypercache,
            update_fn=tracking_update_fn,
            cache_name="test_cache",
            get_teams_queryset_fn=lambda: Team.objects.none(),
        )

        successful, failed = warm_caches(config, batch_size=100, stagger_ttl=False)

        assert warmed_team_ids == []
        assert successful == 0
        assert failed == 0

    def test_explicit_team_ids_bypass_scoping(self):
        """Explicit team_ids should bypass config scoping so operators can warm any team."""
        from posthog.models import Team

        warmed_team_ids: list[int] = []

        def tracking_update_fn(team, ttl=None):
            warmed_team_ids.append(team.id)
            return True

        hypercache = create_test_hypercache()
        # Config scopes to no teams, but explicit team_ids should bypass that
        config = HyperCacheManagementConfig(
            hypercache=hypercache,
            update_fn=tracking_update_fn,
            cache_name="test_cache",
            get_teams_queryset_fn=lambda: Team.objects.none(),
        )

        warm_caches(config, batch_size=100, stagger_ttl=False, team_ids=[self.team.id])

        assert self.team.id in warmed_team_ids


class TestNarrowTeamQueryset(BaseTest):
    def test_extra_fields_are_selected_alongside_refresh_fields(self):
        config = HyperCacheManagementConfig(
            hypercache=create_test_hypercache(),
            update_fn=lambda team, ttl=None: True,
            cache_name="test_cache",
            refresh_only_fields=["id", "project_id", "organization_id"],
        )

        team = config.narrow_team_queryset(Team.objects.filter(id=self.team.id), extra_fields=("name",)).get()

        deferred = team.get_deferred_fields()
        # Columns outside the refresh set stay deferred — a SELECT * regression leaves this empty.
        assert deferred
        # Neither the refresh fields nor the extra fields are deferred, so reading
        # team.name never triggers a per-team lazy load.
        assert deferred & {"id", "project_id", "organization_id", "name"} == set()
