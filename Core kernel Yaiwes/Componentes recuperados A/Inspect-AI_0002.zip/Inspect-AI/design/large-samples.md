# Arbitrarily Large Samples: Format, Viewer, and API Architecture

Status: **ratified design spec** — the output of the wayfinder effort
"[arbitrarily large samples in the viewer](https://github.com/epatey/inspect_ai/issues/1)"
(2026-07-18). Every section records a decision resolved on that map; section
headers link the resolving ticket. This document **absorbs and supersedes** the
`.eval2` framing doc (`design/plans/sample-data-pagination.md` on the
[`scale-prototype` branch](https://github.com/epatey/inspect_ai/tree/scale-prototype)) —
its problem analysis, measurements, and access-pattern inventory are carried
here; its draft mechanisms were ratified (with amendments) or replaced by the
map's tickets.

Reference workload: one sample with **337,351 events / 129,676 messages /
85,062 attachments** (~10B tokens, 963MB uncompressed) — the "monster" from
`mirror-code/ngnk_python`. Assume continued growth; the design targets 10M+
messages per sample.

---

## Change log

Post-ratification amendments. Each entry supersedes the affected sections in
place; affected sections carry a **⚑ amended** marker pointing back here.

- **2026-07-18 — New core principle 2: early merges are latent, zero
  behavior-change risk.** Merging early and often (principle 1) is not
  license to touch existing behavior: everything landed in the early phases
  must be latent — unreachable except through hidden/internal entry points —
  and existing functionality must carry no regression or behavior-change
  risk. Tasks that would touch the public API or observable behavior trigger
  a strategy discussion before work proceeds. Old principles 2–6 renumbered
  to 3–7.
- **2026-07-18 — Small-sample monolith threshold deferred indefinitely.**
  The finalize-time monolith-vs-chunk policy
  ([#17](https://github.com/epatey/inspect_ai/issues/17)) is dropped from the
  plan entirely — **working assumption: it is not needed. Every new-format
  sample is chunked, regardless of size**, on every path (converter, phase-2
  writer). No force-chunk knob (a threshold-respecting converter would noop
  exactly the small-sample corpora CI needs), no "CI pins 0", no code consumes
  a threshold constant; effort F drops the monolith finalize-time policy.
  Monolith samples still exist as a *read* concern — every pre-chunking log —
  so reader dispatch and old-format handling are untouched. Reopen trigger
  (measurement-triggered-lever posture): always-chunk costs on small samples
  (+36% compression toll, per-entry overhead, chattier reads / open latency)
  proving material in practice; the ratified decision text in
  [Small-sample monolith threshold](#small-sample-monolith-threshold-17) is
  retained as the design of record if that happens. Affected: that section,
  [Named size constants](#named-size-constants), [Converter](#converter),
  [old-format degradation](#degradation-policy-for-old-format-huge-samples-13),
  the effort A/B/F slicing, [Deferred open issues](#deferred-open-issues).
- **2026-07-21 — Default attachments chunk byte-target 2 MiB → 10 MiB.**
  Writer policy only, no format consequence (readers infer extents from
  entry names; mixed-policy logs read identically). Rationale: compression
  is insensitive to the target (the 2/8/32 MiB null result), while
  attachment-heavy reads are round-trip-bound — the mirror-code monster's
  final-conversation hydration touched 46 attachment chunks at 2 MiB vs a
  handful at 10 MiB. 10 MiB sits above the 1–8 MiB working band but under
  the ~16 MiB ceiling; per-chunk parse cost rises accordingly (envelope
  numbers unchanged as research record). The converter gained an
  `attachments_chunk_bytes` knob for further measurement. Affected:
  [Chunk-size envelope](#chunked-on-disk-layout-4-6).
- **2026-07-21 — Phase-1 efforts resequenced: viewer milestone next.** Effort
  A is complete (epatey#20–#24). The next accomplishment is **the real viewer
  working against the chunked format**, so effort C is split and pulled ahead
  of B: **C1 — TS data layer (headless)** (TS skeleton/format readers
  validated against the shared JSON fixtures, chunk-byte store, decode walk +
  FilteredCursor; vitest-testable against the CI corpora, no UI surface) and
  **C2 — viewer integration, the milestone** (row-window list-model fork,
  outline/timeline from skeleton, filter counts, infinite-query wiring;
  finish line: open a converted large log in the real viewer and
  browse/collapse/jump end-to-end). Search (D) follows C2 but sits outside
  the milestone. B and E defer behind the milestone — nothing viewer-side
  reads via the Python APIs, and E still depends on B. The refuse-message
  copy update moves from C to E (old-format degradation polish, not chunked
  rendering). Principle 2 restated for C2: old-format render paths stay
  behavior-identical; the list-model fork is the guarded seam. Within-phase
  order: A → C1 → C2 → D → B → E; effort letters stay stable. Affected:
  [Proposed slicing](#proposed-slicing-into-implementation-efforts).
- **2026-07-21 — Outline contract corrected: the legacy outline (and
  transcript body) are projections of the *timeline layer's selected view*,
  not the raw event tree.** Found via a real divergence (ais-decoder:
  chunked outline showed `init / solver / 9×checkpoint / 9 turns / scorers`
  where the browser shows `main / 10 turns / scoring`). What the legacy
  viewer actually does: `buildTimeline` synthesizes a root agent **"main"**
  (solvers content unwrapped, init prepended, scorers renamed "scoring",
  utility model-calls wrapped/classified), the swimlane selection defaults
  to that root row, `collectRawEvents` collects the selected view's events
  (utility spans excluded), `useEventNodes` re-treeifies them (its
  `transformTree` *discards* checkpoint/solvers spans and unwraps others),
  the default event-type filter (`kDefaultExcludeEvents`, incl. `checkpoint`
  and `sandbox`) prunes both stages, and only then do the outline visitors
  and turn/scoring grouping run. Two consequences ratified:
  1. **The mechanism-7 parity oracle froze the wrong branch.** The oracle
     ported the outline transform fed with raw events —
     `TranscriptLayout`'s `showSwimlanes=false` input — a path the real
     viewer effectively never takes (a timeline builds for every log and the
     root row is default-selected). Its 73/73 corpus parity validated
     oracle-vs-candidate, never either-vs-browser. The oracle must be
     re-frozen against the timeline-selected-view pipeline (deferred issue
     10); until then the Python harness remains valid only as a raw-tree
     regression pin.
  2. **New mechanism (8): synthetic event stream, real pipeline.** Rather
     than port the timeline layer (heuristic-heavy: utility classification,
     span discards, retry grouping), the chunked viewer synthesizes a
     minimal event stream from the skeleton — exact span/step tree, exact
     per-gap model counts, exact notable positions, real span timestamps
     (loose points interpolated inside their gap's real bounds), one
     representative stray per direct-child event type for empty-span
     survival — and runs the REAL exported pipeline over it
     (`buildTimeline` → `collectRawEvents` → `buildEventNodes` → outline
     visitors; components `TimelineSwimLanes` + `TranscriptOutline` render
     it). No ported twin exists to drift; the twin test pins
     synthetic-fed rows against real-events-fed rows through the identical
     code across the fixture corpus (exact at the default filter). The
     skeleton proved sufficient for this without format change.
     Documented fidelity limits: utility-call detection needs model
     payloads (utility calls count as turns on bridge logs);
     error/compaction/sample_limit events are strays (position/multiplicity
     collapse to one per span); root-level plain events are absent;
     branch-tree logs render the flat main view (no fork navigation);
     swimlane bar shapes are smoothed between span boundaries.
  **Skeleton v1 amendment candidates** (format is not yet frozen; evaluate
  before the phase-2 writer ships): (a) widen `NOTABLE_TYPES` with
  `error`/`compaction`/`sample_limit` (exact outline rows + timeline
  markers; the monster's 84 compactions currently collapse to one stray)
  and `branch` (+ `from_anchor`) for fork navigation; (b) notable
  timestamps (`t` on notables) for exact marker placement; (c) a root-level
  `children` type-count record (legacy `sample_init`, interrupted-eval
  `sample_limit` at root are currently lost); (d) writer-time utility
  classification persisted per span/gap (the writer has full event
  payloads; readers never will). Affected:
  [Structural skeleton](#structural-skeleton-5) (mechanisms 7–8),
  [Proposed slicing](#proposed-slicing-into-implementation-efforts) (C2),
  [Deferred open issues](#deferred-open-issues) (new items 10–12).
- **2026-07-21 — Windowed Messages tab promoted to an owned effort (C3).**
  Access pattern 3 ("page messages by index window") was inventoried in
  Appendix A but assigned to no effort — C2's deliverable list never named
  the Messages tab, and the implementation shipped an unowned full-hydration
  bridge (fetch + resolve the entire final conversation at tab open —
  134,989 messages / ~125MB on the monster). Ratified: **materializing an
  unbounded number of messages is a no-go**; a windowed Messages tab is a
  phase-1 requirement, sliced as effort C3 (see
  [Proposed slicing](#proposed-slicing-into-implementation-efforts) for the
  design hazards: tool folding and block numbering are functions of all
  prior message content; format candidate — write-time per-chunk cumulative
  block counts). Interim mitigation applied to the bridge: attachment-chunk
  prefetch pipelines per message range instead of serializing behind full
  conversation assembly. Affected: Proposed slicing (new C3), Appendix A
  pattern 3 landing note.
- **2026-07-22 — Server-timeline rendering gap characterized (petri3
  empirics; deferred issue 12 sharpened, new skeleton candidate e).**
  Old/new comparison on the petri3 rollback log shows a wholesale
  presentation divergence, and the diagnosis re-scopes issue 12. The legacy
  viewer **default-selects the log-supplied timeline** when one exists
  (`sample.timelines` → "target" selector, "branch 1" root), so the header
  selector, swimlane rows, time axis, outline, and body are all projections
  of that view; the chunked panel builds only the synthetic main-view
  timeline, and its body is the raw tree (issue 11) — on this log the two
  modes share almost nothing visually. Facts established:
  1. **`timelines` already survive conversion into the chunked shell** — no
     format change is needed to *carry* server timelines; the gap is
     plumbing them into the chunked panel.
  2. **Resolution is the real dependency**: `convertServerTimeline`
     resolves the timeline tree's event references by REAL event uuid
     against the loaded events array. The synthetic stream carries
     synthetic uuids, and the `anchor` events this log's timeline leans on
     (22 of them) are not represented in the skeleton at all.
  3. **petri3 contains zero `branch` events** — its branching is expressed
     entirely via server timelines + anchors. The issue-13 widening that
     unblocks fork/timeline rendering on such logs is therefore
     **timeline-referenced event addressability** (new candidate e), not
     the `branch` notable (which still matters for client-side branch
     detection on logs that do emit branch events).
  Also observed on this log: dead utility classification (candidate d)
  surfaces 13 `realism` judge spans as ordinary outline rows. Minor
  mechanism-8 correction from the PR #451 review round folded in: stray
  types that DO yield outline rows (e.g. `subtask`) collapse to one row per
  span, and notable types past the persistence cap emit no stray at all.
  Affected: [Deferred open issues](#deferred-open-issues) (12, 13),
  [Structural skeleton](#structural-skeleton-5) (mechanism 8).
- **2026-07-21 — C3 split into C3a/C3b (staging decision).** The windowed
  Messages tab lands in two stages: **C3a** converts the legacy Messages tab
  to infinite-query pagination over a page-source contract (in-memory
  source, folding/numbering/count/id-resolution computed globally —
  behavior-identical, ships on ts-mono main with no chunked coupling);
  **C3b** swaps in the chunked page source, where the folding/numbering
  decision lives behind the C3a contract. Rationale: the legacy path
  *becomes* the windowed implementation before the chunked source exists —
  the same lesson as mechanism 8 (never build chunked UI against a ported
  understanding of legacy behavior), applied structurally. C3a carries no
  performance benefit by itself (old data stays fully in memory; rendering
  was already virtualized); its value is the seam. Affected:
  [Proposed slicing](#proposed-slicing-into-implementation-efforts) (C3).
- **2026-07-22 — `sequences` dropped from the shell (reviewer feedback):
  the central directory is the whole chunk layout.** The shell's cumulative
  boundaries duplicated what start-named entry names already carry — a
  two-sources-of-truth hazard (the field had to mirror the written entries).
  `sample.json` no longer persists `sequences`; readers recover per-sequence
  chunk starts from central-directory entry names (which every reader
  fetches anyway — the CD was already the offset index). The one datum
  boundaries carried beyond entry names, the total sequence count, is
  deliberately not persisted: the events count is exact from the stats
  sidecar (per-chunk type-count sums), the other sequences are only ever
  accessed by known index/range (`message_refs`, `input_refs`/`call_refs`,
  `attachment://<index>`), and a last chunk's end is learned when it is
  parsed. Affected: [Chunked on-disk layout](#chunked-on-disk-layout-4-6)
  (shell block + conventions), [Client data contract](#client-data-contract)
  (item 1), Appendix A pattern 5, C3b format-candidate wording.
- **2026-07-22 — Fidelity plan for timeline'd logs; JJ's "global timeline"
  proposal evaluated; new `events/uuids.json` member.** Follow-on from the
  petri3 diagnosis (entry above), grounded in measurements on the MirrorCode
  monster sample (337,351 events): full event sequence 852 MB uncompressed; a
  payload-stripped copy of every event (uuid, type, span_id, timestamps,
  token usage, and a few small per-type fields — enough for the client to run
  the real timeline pipeline) measures 89 MB (265 B/event). Ratified:
  1. **JJ's outset proposal — persist a global timeline instead of a bespoke
     skeleton — is answered.** A timeline is, by definition, an opinionated
     selection, ordering, and grouping of event references: the client-built
     timeline encodes pipeline opinions (unwrapping, utility extraction, turn
     grouping, scoring placement); a server timeline encodes the producer's
     authored opinion. A "global" timeline that supersets every view a client
     might show is therefore a contradiction in terms — the superset of all
     selections and orderings of the events is the event sequence itself.
     Persisting any *derived* timeline freezes its opinions at write time
     (server timelines are fine to persist: they are authored data, not a
     derivation). The un-opinionated artifacts trade size for derivable
     fidelity: full events (852 MB) → payload-stripped events (89 MB) →
     skeleton (KB).
  2. **Invariant made explicit**: viewer memory must never scale with event
     count; bytes *read* may — but only in explicit streaming operations
     (search, one-time scans), never to hold a sample in memory.
  3. **Fidelity plan**: a chunked sample that carries `timelines` (or whose
     stats sidecar shows `branch`/`anchor` events) and is under
     `TIMELINE_HYDRATION_BYTES` renders by downloading its full event
     sequence and handing it to the legacy transcript panel unchanged — exact
     selector/swimlane/fork/body fidelity through the already-shipping code
     path, no format change, no write-time opinion. petri3-class samples are
     ~1 MB each. Above the limit, the sample keeps today's skeleton-based
     approximate view (this resolves issue 12; issue 11 now applies only to
     above-limit samples).
  4. **Payload-stripped events are NOT built.** They would only help a sample
     that is both too large to download fully and carries timelines; no such
     log exists in the corpus (the monster has zero timelines and zero
     branches; timeline'd logs are tiny — petri3: 287 events, 2 timelines,
     57/173 samples with real branch trees). Recorded in
     [Levers](#measurement-triggered-levers) with the measurements.
  5. **New format member `events/uuids.json`**: one JSON array of event uuids
     in ordinal order (position = ordinal), fetched lazily. Gives O(1)
     uuid→ordinal resolution for `?event=` deep links and server-timeline
     references at every sample size — without it, resolving any uuid on a
     monster means streaming all event chunks (852 MB). Costs ~1% of event
     bytes (MirrorCode: 8.4 MB raw / 5.8 MB compressed; typical samples KBs);
     identity facts only; appendable during a live run. Resolves skeleton
     candidate 13(e); core principle 3 amended (identity sidecars may be
     event-proportional).
  Affected: [Core principles](#core-principles) (3),
  [Chunked on-disk layout](#chunked-on-disk-layout-4-6),
  [Named size constants](#named-size-constants),
  [Client data contract](#client-data-contract),
  [Data-loading architecture](#data-loading-architecture-9), Appendix A
  pattern 7, deferred issues 12/13, levers table.

---

## Confidence markers

Two classes of content, marked throughout:

- **Ratified** — at-rest format, read paths, viewer architecture for sealed
  logs, Python API. Grounded in a working converter, three real converted
  evals, and a render prototype driven against the monster.
- **⚠️ PROVISIONAL (live flow)** — everything about the live path: live-view
  unification ([#7](https://github.com/epatey/inspect_ai/issues/7)), the live
  byte source ([#9](https://github.com/epatey/inspect_ai/issues/9)), live
  skeleton/stats emission ([#19](https://github.com/epatey/inspect_ai/issues/19)).
  These decisions are low-confidence direction, and by construction of the
  phasing (read-first, [Phasing](#phasing--compatibility-18)) they stay
  unexercised until phase 2. **Re-validate — possibly revise — during
  live-path implementation.** They are recorded so phase-2 work starts from a
  coherent story, not so it treats them as settled.

## Core principles

1. **Merge to main early and often — no long-running branch. Absolute
   deal-breaker.** Code lands continuously but stays *unexposed* (hidden CLI,
   no public write path) until the format is frozen; hiddenness is what makes
   early merging safe. ([#18](https://github.com/epatey/inspect_ai/issues/18))
2. **Early merges are latent — zero behavior-change risk.** (**⚑ added**,
   [Change log](#change-log)) Nothing merged in the early phases may change —
   or even risk changing — what existing functionality does. New code is
   *latent*: reachable only through hidden/internal entry points, with
   existing code paths behaviorally untouched. When work reaches tasks that
   would touch the public API or observable behavior (e.g. the lazy
   `EvalSample` properties), stop and strategize before proceeding — don't
   absorb the risk by default.
3. **Persisted-structure invariant** (**⚑ amended**,
   [Change log](#change-log), 2026-07-22): anything persisted for *structure*
   scales with *structural spans*, never events (chunk-count-proportional is
   also acceptable). Beware the tool-span trap — one `tool` span per call is
   event-proportional in long agentic transcripts. Amendment: pure *identity*
   sidecars (`events/uuids.json`) may be event-proportional — they carry no
   structure or opinion, cost ~1% of event bytes, and are fetched lazily. The
   runtime counterpart: viewer memory must never scale with event count;
   bytes *read* may, but only in explicit streaming operations (search,
   one-time scans), never to hold a sample in memory.
4. **Sealed logs = range reads only.** Consumption of a sealed log is purely
   byte-range reads + client-side zip central-directory parsing, on every
   backend. No server endpoint may ever be required for sealed-log features —
   anything the view server added would be an accelerator the static path
   can't have, so the format must not need it. ([#9](https://github.com/epatey/inspect_ai/issues/9))
5. **Persisted data is unopinionated**: the format stores structural and
   semantic facts (ids, ordinals, nesting, event types, names, counters) —
   never transformed output. Every interpretation (event-type filtering, turn
   synthesis, scoring collapse, labels, collapse defaults) is viewer-side
   policy applied at read time; policy evolves faster than stored logs.
6. **Chunking is writer policy, not format.** Readers infer chunk extents from
   names + the central directory; count-based, byte-target, or adaptive
   chunking all read identically.
7. **Derived data is regenerated, never migrated.** The skeleton and stats
   sidecar are deterministic functions of the event sequence; corruption or
   version skew is fixed by rebuilding them.

## Constraints (set up front, before design work began)

- **Serverless preserved**: partial event access via plain HTTP range requests
  (static hosting, S3, VS Code) — format-level chunking, not server-side
  pagination.
- **Old logs supported forever**: no on-the-fly conversion; feature-dropping
  above a size threshold is acceptable for old-format huge samples.
- **Scope axes**: events + messages + attachments (all token-linear).
  Store/scores stay whole-fetch.
- **Python API preserved**: `EvalSample.events`/`messages`/`attachments`
  become properties with getters — the hook to lazy-load and warn. New
  low-level read primitives are in scope; polished analysis APIs are not.
  Reading APIs must not force hydration (Confounder 1 below).
- **Write path**: incremental recorder in scope; bounding the eval process's
  own in-memory transcript is not (separate effort).

## The three confounders

Carried from the framing doc — the access patterns that fight a chunked
design, each with its ratified stance:

1. **The last page pulls in everything.** Opening a sample lands at the *end*
   of the transcript, and the final ModelEvent's input references essentially
   the whole conversation. Stance: references are range-encoded (never flat
   lists — those go O(N²)); the last chunk alone renders the frame; message
   ranges hydrate lazily on expand. Proven: the monster's final model event
   framed its 1,326-message input instantly from refs; tail hydration cost 1
   message chunk + 1 attachment chunk. Non-interactive consumers that want the
   fully hydrated final event genuinely need the whole conversation — that is
   information content; the mitigation is API-shaped (lazy reads), not
   format-shaped.
2. **Structure without content.** The transcript is a flattened tree (row
   count ≠ event count under collapse), the outline renders spans, the
   timeline reads span extents. Stance: the persisted span-proportional
   skeleton ([Skeleton](#structural-skeleton-5)).
3. **Jump-to-end with variable-height rows.** Estimate-then-correct
   virtualization, ratified with the ordinal-anchor amendment
   ([View-row pagination](#view-row-pagination-8)).

---

# Part I — At-rest format (ratified)

## Chunked on-disk layout ([#4](https://github.com/epatey/inspect_ai/issues/4), [#6](https://github.com/epatey/inspect_ai/issues/6))

The `.eval` zip gains an additive per-sample shape. A chunked sample lives
under a per-sample prefix; the zip **central directory is the offset index**
(every reader fetches it anyway; index→chunk is a binary search over
numerically-sorted entry names).

```
samples/
└── {id}_epoch_{e}/
    ├── sample.json          # the "shell" — everything small, cheap by construction:
    │                        #   id, epoch, input, target, scores, store, model_usage,
    │                        #   error, limit, timing, uuid…
    │                        #   + message_refs: [[0, 25], [26, 27]]  (final conversation,
    │                        #       half-open ranges into the message sequence)
    │                        #   NO messages / events / attachments / events_data / metadata
    │                        #   NO chunk layout (⚑ amended — `sequences` dropped;
    │                        #       entry names are the layout)
    ├── metadata.json        # sample.metadata (only when non-empty; user-controlled,
    │                        #   arbitrarily large — kept out of the shell)
    ├── skeleton.json        # span-proportional structural skeleton (below)
    ├── messages/
    │   ├── 0.json           # items [0, 1000)
    │   ├── 1000.json        # name = start index; extent = next chunk's start
    │   └── 2000.json
    ├── events/
    │   ├── 0.json           # ModelEvents carry range-encoded input_refs/call_refs
    │   ├── …                #   instead of inline copies
    │   ├── stats.json       # per-chunk event stats sidecar (below)
    │   └── uuids.json       # event uuids in ordinal order (⚑ added 2026-07-22);
    │                        #   lazy-fetched O(1) uuid→ordinal for deep links
    │                        #   and server-timeline references
    ├── calls/
    │   └── 0.json           # raw ModelCall payloads, one per model event
    └── attachments/
        ├── 0.json           # bare strings, referenced as attachment://<index>;
        └── 812.json         #   size-based chunking, so starts are irregular
```

Conventions:

- **Four flat, index-addressed sequences** per sample: `messages/`, `events/`,
  `calls/`, `attachments/`. A *sequence* is an ordered, homogeneous,
  index-addressed set of items, append-only during the run, physically stored
  as N chunk entries.
- **Chunk names carry the start index only** (`{start}.json`, no zero
  padding). Filenames have no range semantics; every range in *data* is
  half-open `[start, end_exclusive)`. The chunk holding index `i` is the one
  with the greatest start ≤ `i`; a chunk's extent is the next chunk's start.
  The central directory's entry names are the *only* persisted record of the
  chunk layout (**⚑ amended** — `sequences` dropped from the shell,
  [Change log](#change-log), 2026-07-22): the last chunk's end — the
  sequence count — is learned by parsing it; the events count is also exact
  without any chunk read, as the sum of the stats sidecar's per-chunk type
  counts.
- **Encoding**: JSON-array chunks. Protobuf deferred behind a measurement
  trigger ([Levers](#measurement-triggered-levers)).
- Per-sample enumeration is a central-directory prefix scan; everything for a
  sample lives under its one prefix.
- Top-level entries (`header.json`, `summaries.json`, `reductions.json`) are
  unchanged; `_journal/` is unchanged.

**Chunk-size envelope** (research, [#3](https://github.com/epatey/inspect_ai/issues/3)):
1–8 MiB uncompressed per chunk (floor ~256 KiB, ceiling ~16 MiB), ≤ ~10k
members per archive. In-member random access was ruled out (deflate needs an
external index; zstd-seekable has no browser support), so **chunk boundary =
member boundary**. One-member-per-event ruled out (~28 MB central directory at
350k members; TTFB-bound per-event GETs). Defaults today: count-based 1000
items for item sequences, ~10 MiB byte-target for attachments (an oversized
item gets a chunk to itself; **⚑ amended** from 2 MiB,
[Change log](#change-log)). Default policy tuning (count vs byte-target) is
an open tunable, settled by measurement — not a format property.

### Pools and attachments ([#6](https://github.com/epatey/inspect_ai/issues/6))

- **The message sequence subsumes the `events_data.messages` pool.** Pooled
  and top-level messages are the same currency; the sequence *is* the pool,
  extended with final-conversation messages not already pooled. The shell's
  final conversation becomes range-encoded `message_refs` — this kills the
  double-stored final conversation. Sequence order is **event-appearance
  order**, not conversation order; consumers always go through refs. Existing
  `input_refs` remain valid (the pool is a prefix of the sequence).
- **Calls** are a third sequence (raw provider payloads — a different
  currency, often the largest per-sample data).
- **Attachments** are a fourth sequence of bare strings; **identity =
  sequence index** (`attachment://<index>`); content-hash dedup is demoted to
  write-time policy, never persisted. Attachments stay extracted (not inlined
  into events): content dedups *across containers* — measured 92MB of unique
  content inlines to 444MB (~5×) on petri.
- **Cross-sample attachment dedup rejected**: breaks prefix enumeration,
  sample-independent writes, and sample-level GC.

### References

Events reference messages/calls by stable per-sample indexes, range-encoded as
half-open pairs (e.g. `[[0, 9874], [9875, 9876]]`), never flat lists.
Rehydration is a consumer concern: the format guarantees stable indexes and
start-named chunks; consumers resolve which chunks a window needs via the
central directory and fetch them independently.

## Structural skeleton ([#5](https://github.com/epatey/inspect_ai/issues/5))

Where the viewer gets transcript *structure* (outline, timeline, tree
scaffolding, scrollbar extents under collapse) without reading events.
Client-side derivation was rejected: span events land in ~every chunk, so
deriving structure degenerates to a full event scan, and the honest cheap
variant (a spans-only projection) can't serve `gap_models` turn rows,
descendant-count scrollbar extents, or `hasVisibleContents`. Derivability
gives its safety anyway: the skeleton is a deterministic function of the
events sequence — distrusted skeletons are rebuilt, never migrated.

Sibling entry `skeleton.json` under the sample prefix. Sized by the invariant:
**skeleton ∝ structural span count (+ capped notables)** — no per-event entry
of any width. Measured on the monster: 60,900 raw spans → **673 structural**
after leaf-tool exclusion (98.9% excluded), 297KB skeleton.

```jsonc
{
  "version": 1,
  "counts": { "events": 250000, "models": 3400 },   // sample totals
  "spans": [
    {
      "id": "aB3x…",                // span_id (identity for span rows / collapse keys)
      "parent": null,               // index into this array
      "name": "react",
      "type": "agent",              // solver | agent | subtask | handoff | scorer | tool | …
      "begin": 1042,                // sequence index of the span_begin event
      "extent": [1042, 15200],      // [first, last] descendant event index (fetch elision;
                                    //   parallel spans may overlap — tolerated, correctness
                                    //   comes from span_id on fetched events)
      "t": ["2026-07-01T10:00:02Z", "2026-07-01T10:41:17Z"],
      "working": [12.5, 340.2],
      "events": 14158,              // descendant event count (incl. nested spans)
      "models": 212,                // descendant model-event count
      "gap_models": [5, 190, 0, 17],// turn placement (below)
      "children": { "state": 1 }    // direct-child event-type counts, sparse
    }
  ],
  "notables": [
    { "i": 9120, "span": 0, "type": "score" },
    { "i": 249995, "span": 0, "type": "checkpoint", "checkpoint_id": 3 }
  ]
}
```

Ratified mechanisms:

1. **Leaf-tool exclusion + size escape hatch.** A tool span with no child
   spans, no model events, and no notables is excluded and summarized in its
   parent's counters — this defuses the tool-span trap. Escape hatch: a leaf
   tool span with ≥ ~1 chunk (~1000) of descendant events is included anyway;
   at most events/1000 such spans exist (chunk-count-proportional, accepted
   class), and monster tool spans keep fetch elision + outline presence.
   Proven: 664 escape-hatch spans on the monster earned their keep.
   The exclusion is a scale necessity, not row policy: tool spans are the
   event-proportional span class (one per tool call), so without it
   "skeleton ∝ spans" is "∝ events" in disguise — the monster's 98.9% is the
   whole argument. The `tool` type test protects small non-tool structural
   spans (outline rows), not demotes tools; what's dissolved is bounded
   (no models/notables/child spans, < ~1 chunk) and reconstructible from the
   one chunk a client rendering at that depth fetches anyway. Known
   fragility: a future span type emitted per-turn/per-call would make the
   skeleton event-proportional again — if one appears, revisit the predicate
   (type-neutral content test) rather than special-casing the new type.
2. **`gap_models` — the load-bearing counter.** A span's *items* are its
   direct-child structural spans and notables merged in sequence order;
   `gap_models[k]` = model-event count strictly between item `k-1` and item
   `k` (`len == items + 1`). This reproduces the outline's row layout (one "N
   turns" row per nonzero gap) without per-turn entries. Gap counts are
   **additive**: clients can suppress any item row by summing adjacent gaps,
   so escape-hatch spans and future row policy stay client-side. A gap row's
   anchor ordinal is the gap's lower bound.
3. **Notables: per-type first-N caps** (default ~1k, writer-policy knob) with
   per-type overflow flags — score events are *not* guaranteed sparse
   (intermediate scoring can emit one per turn). Outline degrades past-cap
   rows with an "N omitted" marker; `gap_models`/counters are computed against
   *persisted* items, so layout stays self-consistent.
4. **Field set**: `id, parent, name, type, begin, extent, t, working, events,
   models, gap_models, children` + sample totals. `flags` and agent-`desc`
   **cut** — no current consumer (verified: viewer default-collapse filters on
   spans key only on type+name; failed/agent/subtask filters target events,
   evaluated window-locally). Additive later via version bump + regeneration.
5. **Lifecycle**: written at sample finalize (live: re-emitted per flush,
   [#19](#live-skeleton--stats-availability-19-️-provisional)); monolith
   samples carry no skeleton ([#17](#small-sample-monolith-threshold-17));
   producer = the Python timeline code with a **TS twin pinned by a shared
   JSON test suite**; the converter backfills. **Legacy step-only logs**: the
   producer maps step begin/end pairs to span-table entries — one skeleton
   contract, no legacy carve-out.
6. **Event identity = sequence index** (spans: `span_id`); uuids are never
   persisted outside event bodies (a uuid→index map is event-proportional,
   forbidden). Legacy `?event=<uuid>` deep links resolve by a one-time
   parallelizable chunk scan. The O(events) `elementIds` scroll-sync surface
   dies; sync = binary search over anchor ordinals.
7. **Parity oracle** (**⚑ amended**, [Change log](#change-log), 2026-07-21):
   acceptance is differential — the legacy in-memory pipeline (frozen as an
   oracle) vs the skeleton-fed pipeline, compared row-for-row across
   converted real logs and synthetic fixtures × collapse states. Three
   divergence classes signed off (models nested directly under tool events →
   skeleton's structural row wins; cross-span consecutive score merging →
   two rows fine; "N turns" click anchor = gap lower bound). New divergences
   require explicit sign-off. **Correction**: the frozen oracle models the
   raw-event-tree outline (`showSwimlanes=false`), but the browser feeds the
   outline from the timeline-selected view — the oracle needs a re-freeze
   against that pipeline (deferred issue 10); its parity claims are valid
   for the raw tree only. The shipped acceptance mechanism is now the
   mechanism-8 twin test, which runs the *actual* pipeline code on both
   sides and therefore cannot freeze the wrong branch.
8. **Synthetic event stream — the skeleton's viewer consumption path**
   (**⚑ amended**, ratified 2026-07-21, [Change log](#change-log)). The
   legacy presentation layer (timeline swimlanes → selected-view collection
   → re-treeify → outline visitors) is a function of the full event list and
   is too heuristic-laden to port against. Instead, the viewer reconstructs
   a minimal stand-in event stream from the skeleton — exact span/step tree
   and per-gap model counts and notable positions (mechanism 2 makes model
   and notable ordering exact), real span timestamps with loose points
   interpolated inside their gap's real bounds, one representative stray per
   direct-child event type (survival of `filterEmpty`/type-filter behavior;
   strays carry the minimum payload the outline dereferences; types that DO
   yield outline rows — e.g. `subtask` — collapse to one row per span, and
   notable types past the persistence cap emit no stray, the persisted ones
   covering survival) — and
   runs the real, exported legacy pipeline over it. Acceptance: a twin test
   pins synthetic-fed against real-events-fed output *through the identical
   production code* per sample across the fixture corpus. Fidelity limits
   and skeleton amendment candidates: change-log entries of 2026-07-21 and
   2026-07-22.

Parked (measurement-triggered): columnar skeleton encoding.

## Per-chunk event stats sidecar ([#5](https://github.com/epatey/inspect_ai/issues/5))

`events/stats.json` — events sequence only. Per chunk:
`{start, sparse type_counts, first/last event type + span_id}`. Deliberately
**separate from the skeleton**: stats are a function of chunking policy
(rechunking invalidates stats, not the skeleton). Lazy-fetched on first
filter/run-scan. Load-bearing for: filter pushdown (skip non-matching chunks
unread), run-extent scans, per-chunk row estimates, and O(1) chunk-edge
resolution (the first/last type+span_id is exactly sufficient for the
head-run-continuation rule — proven in the render prototype).

## Small-sample monolith threshold ([#17](https://github.com/epatey/inspect_ai/issues/17))

**⚑ amended ([Change log](#change-log), 2026-07-18): deferred indefinitely —
working assumption: not needed.** Every new-format sample is chunked
regardless of size, on every path; this section is the retained design of
record, reopened only if always-chunk costs on small samples prove material.
Only the *reader dispatch* bullet below is live — monolith samples exist
regardless (every pre-chunking log), so readers must classify per-sample shape.

Chunking's costs (the +36% compression toll, per-entry overhead, chattier
reads) buy random access small samples don't need.

- **Per-sample granularity**: one log mixes monolith and chunked samples side
  by side. Denominated in **uncompressed serialized sample bytes**, known free
  at sample-finalize. Item counts rejected as proxies.
- **Monolith shape = today's `EvalSample` entry, unchanged**
  (`samples/{id}_epoch_{e}.json`). The existing parse path is reused
  wholesale. Accepted consequences: the format carries both reference dialects
  (quarantined per-sample); the live→sealed source swap for a small sample
  also swaps shape (chunked in flight → monolith at rest).
- **Finalize-time policy, never a start-time guess**: the in-flight live path
  is always chunk-encoded; the at-rest shape is chosen at sample-finalize when
  exact bytes are known (below threshold, seal serializes the in-memory
  sample; streamed live chunks are superseded).
- **Default = the shared 350 MiB full-fidelity constant** (same named
  constant as the viewer's full-fidelity bound — one number, not two).
  Invariant: **a new-format monolith can never hit the degradation ladder**
  (the ladder is an old-format-only concern). Trade-off accepted:
  tens-to-hundreds-of-MB samples keep today's whole-fetch open latency.
- Comparison: `chunk when uncompressed serialized sample bytes > threshold`.
  Writer config/env knob; **CI pins 0** (always chunk) so every small log
  exercises the chunked path; a "never chunk" debug sentinel exists.
- **Reader dispatch is structural, per-sample, off the central directory**:
  monolith = today's entry name; chunked = the `{id}_epoch_{e}/` prefix. One
  name form per sample. Monoliths get no skeleton — the viewer derives
  structure in memory as today; search treats them as fully-materialized
  corpus; lazy Python properties return already-materialized data, no warning.

## Named size constants

One table of spec'd named constants; all tunable without format consequences.
Python mirrors them so both surfaces degrade at the same sizes.

| Constant | Value | Measured on | Used by |
|---|---|---|---|
| `FULL_FIDELITY_BYTES` | 350 MiB | old format: events-array bytes post-fetch · new format: bytes being hydrated | old-format events-cleared tier trigger; Python hydration warning (monolith-vs-chunk threshold use **⚑ dropped** — indefinite deferral, [Change log](#change-log)) |
| `SAMPLE_CLEAR_BYTES` | 512 MiB | old format: member bytes post-fetch · Python: member `uncompressedSize` pre-parse | old-format events-cleared tier (total); Python pre-parse warning |
| `SAMPLE_REFUSE_BYTES` | 2 GiB | member `uncompressedSize`, pre-fetch (central directory) | viewer refuse tier (old format only) |
| `TIMELINE_HYDRATION_BYTES` | 50 MiB (⚑ added 2026-07-22) | sum of `uncompressedSize` over the sample's `events/` + `attachments/` entries, pre-fetch (central directory) | full-download gate for timeline'd chunked samples ([Change log](#change-log)) |

## Compression measurements & levers

Measured (petri, 470 samples): chunked conversion costs **+36% compressed**
(37.7 → 51.1 MB) — the direct price of per-entry compression scope severing
cross-entry matching. Uncompressed *drops* 332 → 292 MB (dedup working), but
dedup and zstd remove the same redundancy. Null results: attachment chunk
target size (2/8/32 MiB) makes no difference; zstd level 9 saves only ~7%.
Comingling measurements: all four sequences −27.6%, **events+attachments alone
−24.4%** (the affinity is almost entirely events↔attachments), messages+X
negligible — full comingling rejected (messages are ~4% of bytes;
time-interleaving smears a message window across every chunk).

### Measurement-triggered levers

Parked, additive, explicitly *not* built now. Each reopens only on an observed
problem:

| Lever | Trigger | Effect |
|---|---|---|
| Protobuf chunk encoding | the +36% toll proves material | removes JSON structural redundancy; cost = shared schema + TS/Python codegen |
| Trained zstd dictionaries | same | pre-warms every entry; needs browser fzstd support |
| Events+attachments comingling | same, or snippet-hydration latency | −24.4%; costs event-chunk overread from the Messages tab |
| Attachment inline-threshold bump (`len > 100`) | snippet-hydration latency | more smalls arrive with the event |
| Columnar skeleton encoding | skeleton size | parallel arrays, RLE/zstd-friendly |
| Durable client chunk cache (IndexedDB) | re-fetch cost observed | additive below the byte store; contract unchanged |
| Worker-side viewer data layer | observed main-thread jank | decoded window lives in a worker; render-ready rows shipped out |
| Precomputed search-index sidecar | scan latency at extreme scale | additive sidecar; drifts from renderer text — same posture as protobuf |
| Payload-stripped events sidecar (every event, minus payload fields) | a sample appears that is both over `TIMELINE_HYDRATION_BYTES` and carries timelines/branches | client runs the real timeline pipeline without payloads; measured 89 MB vs 852 MB full on the 337k-event monster ([Change log](#change-log), 2026-07-22) — note the parsed-heap cost scales with events too |

---

# Part II — Live path (⚠️ PROVISIONAL)

Everything in this part is provisional direction (see
[Confidence markers](#confidence-markers)): spec'd now, exercised only in
phase 2, expected to be re-validated and possibly revised then.

## Live-view unification ([#7](https://github.com/epatey/inspect_ai/issues/7))

**Unified encoding, consolidate at seal.** Live segments and the finalized
format become one encoding; the sealed zip remains the single final artifact.

1. **Segments carry final-format bytes.** Live segment zips (`segment.{N}.zip`,
   one PUT per flush as today) contain chunk members with their *final* names
   and encoding. Today's `SampleData`/pool/monotonic-cursor shape is retired.
2. **Supersede-tail.** A sample's partial tail chunk is rewritten under its
   final start-index name on each flush; the latest segment wins for a
   duplicated member name. Chunk boundaries remain pure writer policy — flush
   cadence never dictates them.
3. **Protocol-level unification, not storage-level.** SQLite
   (`buffer/database.py`) stays the sole local live store and the
   crash-recovery source; the local view server *synthesizes* chunk-protocol
   responses from it. Real segment objects exist only when `log_shared`. The
   viewer gets **one chunk decoder** with **two byte sources**:
   server-synthesized locally, static range reads remotely.
4. **Manifest = live chunk directory.** Per sample, per sequence:
   `(start_index, segment_id, member_offset, member_size)`,
   supersede-resolved by the writer (only winning versions listed). Client
   cursor = per-sequence next index; resolution to bytes is one HTTP range
   read per chunk — no zip-CD parsing, no post-filtering. After seal, the
   final zip's central directory plays the identical role: same client logic,
   two directory encodings. The four `last_*_id` cursors and the
   OR-filter/post-filter protocol are retired.
5. **Sidecar rule.** Everything span- or chunk-proportional that a late-joining
   reader needs is a live supersede-member: `skeleton.json` and the stats
   sidecar (see [#19](#live-skeleton--stats-availability-19-️-provisional)).
   Completion-semantic artifacts are seal-only: `sample.json` shell
   (`message_refs` only exist at completion; the manifest summary serves the
   live role), `metadata.json`, reductions, header.
6. **Seal path: local accumulator, seal-only remote upload.** The recorder
   keeps the growing zip locally; completed samples are appended as chunk
   members streamed from SQLite (memory-bounded — a huge sample is never held
   whole). In shared mode the per-flush whole-file re-stream is
   **eliminated**: a tiny start-stub `.eval` (spec/plan, status `started`) is
   written remotely at `log_start` (crash discovery + eval-set retry
   classification keep working), and the sealed file is uploaded once
   (multipart) at `log_finish`. Segments are purely a live transport; by
   construction of supersede-tail their chunk bytes are identical to the
   sealed file's.

Crash recovery is unchanged (SQLite source); remote segments additionally hold
final-format bytes up to the last sync as a redundancy bonus. The writer-side
attachment hash→index dedup table lives in the sample-buffer SQLite (a bounded
table degrades to duplicate storage, never incorrectness). Rejected: two
formats / two viewer paths (pool elimination obsoletes today's segment shape
anyway); no-consolidation (S3 immutability + no central directory while
growing; a directory-of-objects final format contradicts the layout decision).

## Live skeleton & stats availability ([#19](https://github.com/epatey/inspect_ai/issues/19))

**Same artifacts, re-emitted per flush; seal = the existing source swap. No
second structure format, no client derivation, no special cases.**

1. **Writer re-emits the full skeleton at each flush** — a `skeleton.json`
   member in the live segment, superseded per flush, manifest-pointed. No
   incremental-update protocol: the skeleton is span-proportional and small
   (KBs typical, <1MB pathological); how the writer computes it (recompute vs
   incremental) is writer-internal. Rejected: client-side derivation
   (structurally unsound under the window cap — the head may never be
   fetched); a degraded manifest-carried partial structure (a second, weaker
   format).
2. **Stats sidecar treated exactly like the skeleton** — full re-emit per
   flush, superseded, manifest-pointed — covering all sealed chunks plus the
   current partial tail. Head row accounting therefore works pre-seal
   (scrolling back up a running monster gets real per-chunk row estimates),
   and one encoding/decoder serves live and sealed stats.
3. **Seal handoff = nothing but the source swap**: invalidate and refetch
   skeleton + stats through the swapped byte source, like chunk bytes. The
   finalize-written versions are supersets of (typically identical to) the
   last live emission — same producer, same append-only events. The client
   never accumulates or merges structure, so nothing reconciles; UI state
   survives on stable keys (collapse = `span_id`, scroll anchors = event
   ordinals).

---

# Part III — Viewer architecture (ratified for sealed logs)

Proven end-to-end by the render prototype
([#8](https://github.com/epatey/inspect_ai/issues/8),
[proto/eval2-render](https://github.com/epatey/inspect_ai/tree/proto/eval2-render/prototypes/eval2-render)):
open-at-end of the monster = 9 requests / 3 of 338 event chunks; a full
session (2 deep jumps, fling-scroll, collapse/expand, type filter) touched
17/338 chunks; outline = zero event reads; collapsing the 337k-event span =
free.

## Client data contract

The complete surface the transcript + outline consume — no server, no other
index:

1. central-directory entry names (per-sequence chunk starts — **⚑ amended**,
   `sequences` dropped, [Change log](#change-log), 2026-07-22) +
   `shell.message_refs`
2. `skeleton.json`
3. `events/stats.json`
4. `events/uuids.json` — lazy uuid→ordinal identity for deep links and
   server-timeline references (**⚑ added**, [Change log](#change-log),
   2026-07-22)
5. `getRange(sequence, [lo, hi))` — chunk-cached random access, all four
   sequences
6. `readEvents(from, {types, max})` / `FilteredCursor` — the one nontrivial
   primitive

## Data-loading architecture ([#9](https://github.com/epatey/inspect_ai/issues/9))

1. **IndexedDB stays listings-only.** Chunk/sample-body data is never
   persisted client-side. (Durable chunk cache = parked lever.)
2. **Two-tier in-memory cache, scoped per sample, dropped on deselection.**
   Below: a **framework-free chunk-byte store** (precedent: `fetchEngine`'s
   framework-free core) owning `getRange` over all four sequences, raw-buffer
   byte-budget LRU (generous knob, ~256MB class), request dedup. Raw
   ArrayBuffers live outside the V8 heap cage; parsed objects are the scarce
   resource.
3. **Parsed tier = bidirectional `useInfiniteQuery`**: page = event chunk
   (chunk = decode = fetch unit), `pageParam` = chunk index,
   `getPreviousPageParam` for upward growth, `maxPages` = the window cap
   (far-end eviction; scroll-back re-parses from the byte store, no
   re-download). Deep jump = re-anchored queryKey
   (`[sample, filter…, anchorChunk]`); old anchors age out via gcTime. Page
   queryFn = decode walk + **synchronous attachment resolution** — a page is a
   materialized row-window slice; the UI never sees an `attachment://` ref.
   Boundary: event-body refs only; `input_refs` message ranges stay lazy
   (hydrate on expand — Confounder 1).
4. **⚠️ PROVISIONAL — live = a second byte source**, not a generalized
   `sampleStream`: manifest polled on the existing 2s/10ms-catchup cadence →
   same chunk store; tail-following = `fetchNextPage`; supersede-tail =
   invalidation of affected tail chunks (byte store + query pages), never
   in-place patching; seal = byte-source swap under the same store — chunk
   identity is preserved (final names), so nothing refetches.
   `sampleStream.ts` + the four-cursor protocol survive for **old-format live
   samples only** (lifetime = phasing).
5. **Sealed = range-reads-only** (core principle 4). All three backends
   (view-server `/log-bytes`, static-http, VS Code) work day one untouched.
   Live adds one method pair (sample manifest + segment bytes) mirroring
   today's proxy/presigned-direct split with the existing probe/fallback state
   machine; vscode inherits proxy via the tunnel; static keeps its no-live
   stance.
6. **Worker decompress, main-thread per-chunk parse.** Chunks flow through the
   existing zstd-worker path; per-chunk `JSON.parse` (1–8 MiB ⇒ ~5–40 ms)
   stays on the main thread — shipping parsed objects from a worker is a
   structured clone costing the same order. (Worker-side data layer = parked
   lever.)
7. **The UI boundary moves from events-array to row-window.** The data layer's
   product is materialized row windows + row-count estimates with bounded
   local corrections + ordinal scroll coordinates (`rowIndexForOrdinal`
   re-anchoring); the outline consumes the skeleton only. Consequence, named
   honestly: a **forked list-model layer** at the VirtualList level (shared
   per-event row renderers, second window model); fork lifetime = the phasing
   plan. Placement: new framework-free module under
   `apps/inspect/src/log_data/`, third source in `deriveSampleData`'s path
   selection.
8. **Filter counts: exact digits, approximate pixels.** Displayed numeric
   counts (filter badges, outline counters) are exact sums from the stats
   sidecar; scrollbar/row-space extents are estimate-then-correct — rows ≠
   events (runs, collapse elision), so exact extents are unobtainable from
   stats regardless, and an approximate pixel is invisible where an
   approximate digit reads as a bug.
9. **Timeline'd samples under the size limit bypass the windowed path**
   (**⚑ added**, [Change log](#change-log), 2026-07-22). A chunked sample
   that carries `timelines` (or whose stats sidecar shows `branch`/`anchor`
   events) and is under `TIMELINE_HYDRATION_BYTES` (computed free from
   central-directory uncompressed sizes) is rendered by downloading its full
   event sequence (attachments resolved) and handing it to the legacy
   transcript panel unchanged — exact timeline/fork fidelity through the
   already-shipping code path. Above the limit, the windowed skeleton view
   renders as today.

## View-row pagination ([#8](https://github.com/epatey/inspect_ai/issues/8))

View rows are not events: transformations filter events out, merge runs into
one row, and elide collapsed subtrees — so "fetch 20 rows" has no fixed answer
in raw-event units, and a raw window can split mid-row. The outline is
untouched (its rows come entirely from the skeleton). I/O invariant: **reads ∝
rows emitted, never events skipped**. Ratified as drafted with three
amendments (all proven in the prototype).

### Layer 1 — filtered cursor read (the primitive)

`readEvents(fromOrdinal, {types, max}) → {events: [{ordinal, raw}…], next}` —
a cursor read over the flat event sequence where **`max` counts *surviving*
events**, with type filtering pushed down into the reader (per-chunk type
counts let it skip non-matching chunks unread). This fully absorbs density
(10k logger events between two surviving rows cost ~nothing); callers never
estimate raw↔surviving ratios. A thin `FilteredCursor` wraps it with
`peek()`/`next()`/`seek(ordinal)` over an internal buffer.

### Layer 2 — the decode walk

Produce rows by walking surviving events; the skeleton lets the walk *seek*
(zero reads) and runs *coalesce*:

```ts
// filter always force-includes span_begin/span_end — structure drives the
// walk and is only conditionally a row, never subject to the user's filter
cursor = FilteredCursor(startOrdinal, userFilter ∪ {span_begin, span_end})

while (rows.length < n && !cursor.done) {
  ev = cursor.peek()
  if (ev is span_begin) {
    span = skeleton.byBeginOrdinal(ev.ordinal)
    if (!hasVisibleContents(span, userFilter)) cursor.seek(span.extent[1])  // filterEmpty, from counters
    else if (isCollapsed(span.id)) { rows.push(spanRow(span, collapsed)); cursor.seek(span.extent[1]) }
    else                           { rows.push(spanRow(span, expanded));  cursor.next() }
  }
  else if (ev is span_end) cursor.next()                       // no row
  else if (isRunType(ev)) rows.push(runRow(takeRun(cursor, ev)))
  else { rows.push(eventRow(ev, skeleton.depthAt(ev.ordinal))); cursor.next() }
}
```

A collapsed span covering 1M events is one row and one seek. Starting
mid-stream seeds depth from `skeleton.spanStackAt(k)` (binary search over
extents — giant spans never fetched to know where you are inside them).

### The three amendments (ratified)

1. **Row accounting per event chunk**, not a global segment tree: each chunk
   carries an estimated surviving-row count (from stats, minus collapse
   elision, runs guessed at average length); decoding corrects it to exact.
   Corrections are bounded and local; prefix sums over ≤~10k chunks are
   trivial. The chunk is decode unit = fetch unit.
2. **No reversed cursor.** Upward pagination = decode the chunk above via the
   same forward walk + the **head-run-continuation rule**: if the previous
   chunk's stats `last` (type+span_id) matches this chunk's `first` for a run
   type, the head run is consumed rowless (it belongs to the chunk where it
   starts). The stats sidecar's first/last fields are exactly sufficient — O(1)
   edge resolution.
3. **Ordinals are the scroll coordinate system.** Row-count corrections above
   the viewport shift content; the fix is an ordinal anchor — track the
   topmost visible ordinal, re-scroll to `rowIndexForOrdinal(anchor)` on
   correction. Not perceptible in normal scrolling; cold jumps settle in one
   correction.

### Runs — the mid-character case, bounded

Merge runs (retry groups, sandbox runs) are the only decode units that can
straddle arbitrarily many chunks. Two properties bound them: (1) run
membership is decidable from type + span facts alone, so `takeRun` finds a
run's extent by scanning chunk *statistics* — only the 1–2 mixed edge chunks
are read; (2) a run's row needs O(1) representative events, never its
contents. **Binding constraint on future transforms: every row-merging rule
must be decidable from type/span facts available in chunk stats — never from
event payload contents.** A payload-dependent merge rule silently reintroduces
unbounded lookback.

## Transcript search ([#10](https://github.com/epatey/inspect_ai/issues/10))

**Progressive scan-as-you-search is the only mechanism.** Rejected: a
server-side search endpoint (redundant once scan exists; violates
range-reads-only); a precomputed in-log index (token-linear cost; drifts from
the renderer's evolving notion of "the text of an event"; revisitable as a
parked lever); search over replicated IndexedDB (dead — listings-only).

- **Scope**: the find band (Ctrl-F) only. The scout-backed Search Panel is a
  separate server-dependent subsystem and keeps working where scout exists.
  One architecture for serverless and server-backed.
- **Corpus — renderer-aligned**: the scan runs over *materialized* events
  (chunk decode + synchronous attachment resolution) through the renderer's
  own text extraction (`extractEventFields` / `messageSearchText`). Find
  matches exactly what the user can see; attachment content is searched
  because rendered text includes it. Raw-stored scan rejected (misses
  attachment content, matches invisible JSON).
- **Execution — dedicated scan worker, scan-and-discard**: fetches chunk
  bytes, decompresses, parses, extracts, matches, drops the bytes.
  Read-through of the render path's chunk-byte store for already-cached
  bytes, **never writes into it** — scan traffic must not evict the viewing
  window. Extractors must be worker-importable (implementation-time check).
- **Navigation — cursor-anchored directional scan**: "next" scans forward
  chunk-by-chunk from the cursor's chunk, "prev" backward; first hit in the
  requested direction resolves navigation immediately. Hit identity =
  (sequence index, occurrence-within-item); hit → ordinal → chunk jump via the
  re-anchored-queryKey machinery, then the existing settle-and-highlight DOM
  dance. No-wrap semantics preserved.
- **Counter — progressive**: after navigation is served, a lower-priority
  background sweep walks remaining chunks; "n of ≥m — scanning…" settles to
  exact. Gated on explicit search action (Enter / first next-prev), never per
  keystroke. The worker keeps a per-term, per-chunk match table (ordinals +
  counts) memoizing counting and repeat navigation.
- **Sequence-generic**: one scanner parameterized by (sequence, extractor) —
  transcript = (events, event extractor), chat = (messages,
  `messageSearchText`). Whole-fetch tabs (Scoring/Metadata/JSON) keep plain
  `window.find`.
- **⚠️ PROVISIONAL — live**: the scanner consumes the same two-byte-source
  abstraction as the render path — tail chunks extend the match table
  incrementally, superseded chunks invalidate their entries, seal is an
  invisible source swap.

---

# Part IV — Python API (ratified)

## Read primitives & `EvalSample` back-compat ([#12](https://github.com/epatey/inspect_ai/issues/12))

**Lazy `EvalSample`** (back-compat surface):

- `events` / `messages` / `attachments` become hydrate-on-first-access
  properties with **transparent materialization** — the full list is always
  returned — plus a **warning above the mirrored byte thresholds**
  (`FULL_FIDELITY_BYTES` / `SAMPLE_CLEAR_BYTES`).
- **Detached hydration**: the sample holds log path + shell only; first access
  opens an ephemeral reader (reusing a caller-supplied `reader=` if open),
  fetches the sequence's chunks, caches, closes. No lifetime obligations;
  picklable.
- **Pydantic**: readers return a private `EvalSample` subclass
  (isinstance-compatible; no new public type; eval-runtime construction
  untouched). `model_dump`/`model_dump_json` **hydrate** (same warning) —
  `read → dump/write_eval_log` round-trips at full fidelity.

**New primitives — a sample reader object**:

- `open_sample_reader(log, id, epoch)` — context-managed; **async-native core
  + sync facade** via `run_coroutine` (the existing
  `read_eval_log_sample`/`_async` idiom). Central directory + shell parsed
  once.
- Roster: `shell`; `events/messages/calls/attachments(start, end)` half-open
  range reads fetching only covering chunks; `iter_events()`/`iter_messages()`
  chunk-buffered iteration (memory bounded by one chunk); `skeleton()`.
- Deliberately excluded: span-scoped convenience (compose `skeleton()` → range
  read) and by-uuid lookup (inherently a scan; legacy-link resolution is
  viewer-side).
- **Resolution defaults mirror the TS contract**: `resolve_attachments=True`,
  `resolve_input=False` — `input_refs` is already a legal schema state on
  main; full hydration is one explicit knob away. Default reads are
  Confounder-1-safe.

**Existing APIs on chunked logs**:

- `read_eval_log(samples=True)`, `read_eval_log_samples`,
  `read_eval_log_samples_by_id` → lazy samples; zero eager cost.
- `resolve_attachments=` keeps its documented default (`False` → events carry
  `attachment://<index>` refs and `.attachments` materializes as the
  `{index: content}` dict — manual resolution preserved; deliberate asymmetry
  with the new reader's `True` default).
- `exclude_fields=` honored at the lazy layer: excluded sequences never
  hydrate.
- Sync property getters bridge via `run_coroutine`, inheriting existing
  nested-loop behavior — no new bridging semantics.

## Degradation policy for old-format huge samples ([#13](https://github.com/epatey/inspect_ai/issues/13))

**Ratify, don't redesign**: the viewer's existing three-tier ladder is the
policy of record for old-format (`.eval`) samples. New-format samples never
hit it — always chunked (**⚑ amended**, [Change log](#change-log)), and
chunked reads never whole-fetch a sample.

| Tier | Trigger | Behavior |
|---|---|---|
| Full | member ≤ `FULL_FIDELITY_BYTES` | everything loads |
| Events cleared | events > `FULL_FIDELITY_BYTES` or total > `SAMPLE_CLEAR_BYTES` | full member fetched, `events` byte-stripped before parse; transcript tab shows the existing "events removed — use Messages tab" banner; messages/scores/metadata intact |
| Refused | member > `SAMPLE_REFUSE_BYTES` (checked pre-fetch against the central directory) | detail view errors; the list row (from summaries) stays visible |

- **Refuse-tier UX**: a hard error — no summary-stub detail view. The message
  is improved: states the sample's actual size and points at the Python API as
  the escape hatch. **It does not mention offline conversion** (the converter
  stays hidden per the phasing decision; copy revisited if that changes).
- **Python: warn, never fail.** Readers check member `uncompressedSize`
  (free — central directory) against `SAMPLE_CLEAR_BYTES` pre-parse, warn in
  the same style as the hydration warning, and proceed. No hard cap — Python
  has no browser memory cliff. Old-format samples remain eager-parse (no lazy
  subclass).
- **Rejected**: stream-parse-first-N-events (a mechanism redesign for a legacy
  edge case). **Out of scope**: `.json`-format logs (whole-log single file, no
  caps today; huge ones remain best-effort).
- Derived consequences: the events-cleared tier still downloads the full
  member (messages share it — inherent to the old format, accepted); search on
  a degraded old sample covers only what's in memory; the old-format live path
  is not governed by this policy.

## Downstream tooling matrix ([#14](https://github.com/epatey/inspect_ai/issues/14))

Vocabulary: **works-as-is** / **works-as-is + warning** (accepted RAM cost;
the hydration warning is the guard) / **needs rework** / **deferred** (open
issue, resolved outside this effort).

| Consumer | Verdict | Basis |
|---|---|---|
| `inspect log list` / `headers` / `export-config` / `dump --header-only` | works-as-is | header/filesystem reads only |
| eval-set directory scan + retry decisions | works-as-is | headers + summaries only |
| eval-set/retry lazy sample source (`read_from_file`) | works-as-is | per-sample reads; strictly improved by lazy samples |
| `eval_retry` whole-log read | works-as-is | lazy samples keep residency at shells until re-log |
| In-repo scanners (`task/scan.py`) | works-as-is | operate on in-memory samples as they complete |
| `resolve_attachments` | works-as-is | semantics fixed by the API decision; transient ~2× copy inherits warnings |
| `inspect log dump` | works-as-is + warning | hydrates at serialization; output is inherently sample-sized |
| `inspect log convert` | works-as-is + warning | `--stream N` bounds cross-sample concurrency only; one monster sample fully materializes |
| Dataframes (`samples_df`, `messages_df`, `events_df`) | works-as-is + warning | serial path holds all logs hydrated concurrently — unchanged; chunk-streamed extraction noted as future improvement |
| Crash recovery | **needs rework, mechanism deferred** | coupled to one-member-per-sample identity + hand-written inline-events JSON; the seal-from-SQLite path means a crashed chunked local log has no flushed samples — "recovery = run the seal against the surviving buffer" is the candidate shape. Old-format recovery unchanged. |

Investigation ground truth recorded with the matrix: viewer `/log-edit` is
tags/metadata only (header-only both ways; score edits have no viewer
endpoint); no event-level streaming exists anywhere today — the sample is the
universal granularity unit; `exclude_fields` (ijson skip) is the only
sub-sample mitigation and is not CLI-exposed.

## Mid-sequence state/store reconstruction ([#16](https://github.com/epatey/inspect_ai/issues/16))

**No keyframes; deltas stay as-is.** Ground truth: nothing reconstructs state
at arbitrary event k — anywhere. The viewer's `StateEventView` renders a
purely local single-event diff from the event's own `changes`; the only
whole-store UI is fed by the shell's final `store` field; Python has exactly
one replay site (`store_from_events()`, terminal-store-only, zero internal
callers); dataframes do no state reconstruction.

- Per-event diff rendering is self-contained, so windowed reads render
  state/store events with zero prior context.
- Keyframes rejected for now: event-proportional derived data serving zero
  consumers. Recorded as future-additive writer policy if a "state at point k"
  UI ever materializes (additive-chunk design ⇒ no format break).
- `store_from_events` stays as-is: callers pass `sample.events` → transparent
  hydration + size warning. No streaming variant (analysis APIs out of scope).

## Known-expensive operations

Standing section: Inspect features that are inherently inefficient or
expensive under the chunked format. Later work appends here.

1. `store_from_events` / `store_from_events_as` — full hydration + O(n)
   replay; a chunk-streamed variant is possible but unbuilt.
2. Any future "state/store at event k" — no keyframes; replay from sequence
   start.
3. Legacy `?event=<uuid>` deep links — one-time parallelizable chunk scan
   (uuids are not persisted outside event bodies).
4. Score edits / `invalidate_samples` — full-log parse + whole-zip rewrite
   (degraded with warning) until the deferred representation question is
   resolved ([Open issues](#deferred-open-issues)).
5. Reused-sample carry-over in eval-set/retry — full hydration + re-condense +
   rewrite per reused sample, until the deferred byte-copy candidate is
   pursued.
6. Remote tag/metadata edits — whole-zip in-memory rewrite with
   decompress/recompress, until the deferred candidates (raw member copy,
   `UploadPartCopy`) are pursued.

---

# Part V — Phasing & compatibility ([#18](https://github.com/epatey/inspect_ai/issues/18))

**Core principles 1–2 (restated from the top because they govern everything
below): merge progress to main early and often — no long-running branch.
Code lands continuously but stays unexposed until the format is frozen, and
every early-phase merge is latent: no regression or behavior-change risk to
existing functionality. Work that would touch the public API or observable
behavior triggers a strategy discussion first.**

## Phases (milestone-gated, no dates)

1. **Phase 1 — read support everywhere, no writer.** Chunked-sample reading
   diffuses into all eval-reading surfaces (inspect Python API, inspect
   viewer, Scout, Scout viewer, others). Testing rides the converter over real
   converted logs; the live path is knowingly unexercised in this phase.
2. **Phase 2 — opt-in write, after upgrade soak.** The write path is exposed
   opt-in (mechanism deferred to implementation: env var vs CLI/eval option —
   both candidates recorded); trial users; the live/seal path is proven here
   (and the ⚠️ PROVISIONAL sections re-validated).
3. **Phase 3 — default flip**, only after the opt-in soak.

## Format gate

**No version bump: `.eval` extension, `LOG_SCHEMA_VERSION` stays 2.** Chunked
samples are an additive per-sample shape detected structurally
(central-directory dispatch). Ground truth: the `.eval` read path deliberately
ignores the version field today (leniency norm); the `.json` reader hard-fails
on version > 2. `.eval2` was prototype-only naming. **Marked follow-up with
JJ**: whether the version field should ever gate this / why `.eval` reads
ignore version.

## Converter

`inspect log convert-eval2` (naming will change with the `.eval2` name's
retirement) stays on the CLI, **hidden long-term** — an internal/CI testing
vehicle only; no public exposure until the format is frozen (no supporting
intermediate format versions in the wild). **⚑ amended
([Change log](#change-log), 2026-07-18)**: the converter **always converts
every sample to the chunked shape** — no monolith threshold, no force-chunk
knob (a threshold-respecting converter would noop exactly the small-sample
corpora CI needs; the threshold itself is deferred indefinitely). CI corpora
come from simply running the converter. Consequence: the >2GB refuse-tier
message does **not** mention conversion for now.

## Forward compatibility

1. Stale installs meeting a chunked log **fail loudly by construction** —
   chunk entries break their `samples/*.json` sample enumeration; nothing
   silently drops samples. No retrofit; mitigation is the read-first phasing
   soak.
2. Updated readers handle both per-sample shapes transparently; version
   ignored pending the JJ follow-up.
3. The chunked shape is `.eval`-only; the `.json` log format never chunks (its
   existing version check stays).
4. Old logs readable forever (an up-front constraint, [Constraints](#constraints-set-up-front-before-design-work-began)).

## Proposed slicing into implementation efforts

A proposal to seed planning, not a commitment. Ordering follows the phases.
**⚑ amended** ([Change log](#change-log), 2026-07-21): phase-1 ordering is
resequenced — after A (complete), the next milestone is the real viewer
working against the chunked format (C1 + C2); D follows C2; B and E defer
behind the milestone. Within-phase order: A → C1 → C2 → D → B → E.

**Phase 1 (read everywhere):**

- **A. Format core + skeleton producer (Python).** **Complete** (2026-07-21,
  epatey#20–#24). Entry naming/dispatch
  (`format.py` lineage), the skeleton + stats producers on the timeline code,
  the shared Python/TS JSON test suite, the parity oracle harness, converter
  hardening (backfill skeleton/stats, always-chunk, `.eval2` naming retired).
  CI corpora generation. **⚑ amended** ([Change log](#change-log)): the
  force-chunk knob is gone (always-chunk) and the named-constants table moves
  to B, landing with its first consumer (the hydration warning) — in phase 1
  no other code reads those constants.
- **C1. TS data layer (headless).** **⚑ amended** ([Change log](#change-log),
  2026-07-21, split from C). TS skeleton/format readers (twin of the Python
  producer, validated against the shared JSON fixture suite), chunk-byte
  store, decode walk + FilteredCursor. Vitest-testable against the CI
  corpora; no UI surface. Depends on A.
- **C2. Viewer integration — the milestone.** **⚑ amended**
  ([Change log](#change-log), 2026-07-21, split from C; amended again
  2026-07-21 — outline/timeline delivered via mechanism 8). Infinite-query
  parsed tier, row-window list-model fork, outline/timeline from skeleton,
  filter counts. Finish line: open a converted large log in the real viewer,
  browse/collapse/jump end-to-end. Old-format render paths stay
  behavior-identical (principle 2); the list-model fork is the guarded seam.
  Depends on C1. The refuse-message copy update moves to E.
  **Delivery note**: outline and timeline swimlanes ship as the *real*
  legacy components fed by the mechanism-8 synthetic stream; swimlane and
  outline selection scroll the body to the selected span. The transcript
  *body* still renders the raw event tree (the legacy body renders the
  selected timeline view — solvers/agent wrappers hidden); reconciling the
  body is deferred issue 11, and branch-tree/server-timeline rendering is
  deferred issue 12. Acceptance lesson recorded in the change log: never
  ratify a projection against a ported oracle without a browser-real
  comparison log in the corpus.
- **C3. Windowed Messages tab.** **⚑ amended** ([Change log](#change-log),
  2026-07-21 — requirement was inventoried but unowned; split into C3a/C3b
  the same day, staging decision). Access pattern 3 made real:
  **materializing an unbounded number of messages is a no-go** — the current
  full-hydration bridge (tab-open hydration, attachment prefetch pipelined
  per message chunk) matches the old path's profile and dies exactly where
  the old path dies. Staged so the legacy path becomes the windowed
  implementation before the chunked source exists (the mechanism-8 lesson
  applied structurally — no ported oracle to diverge from):
  - **C3a. Legacy pagination seam (lands on ts-mono main,
    behavior-identical).** Convert the Messages tab to react-query
    infinite-query pagination (the inspect_scout pattern) over a **page
    source contract** while old logs keep the full message array in memory.
    The source owns everything the chunked source will later need to
    reinterpret: total row count, tool-message folding (pages deliver
    *resolved rows*, not raw messages), per-row `startNumber`, and
    message-id→row resolution (`?message=` deep links). The in-memory
    source computes all of these globally and exactly, so rendering is
    pixel-identical — this stage is a seam refactor with zero UX or
    performance change, reviewable and landable on main independent of the
    chunked format. Blast-radius note: `ChatViewVirtualList` is shared with
    scout — keep its array-prop signature as a thin wrapper over the paged
    core. No dependency on this effort's branches.
  - **C3b. Chunked page source.** Swap the source: exact row count and
    row→sequence mapping from `message_refs` prefix sums, windowed
    `getRange` + per-batch attachment resolution, page materialization.
    The folding/numbering decision lives entirely in this source, behind
    the C3a contract: either unfolded rows with message-ordinal numbering
    (UX deviation needing sign-off) or write-time persisted block/folding
    counts (format candidate: per-chunk cumulative block counts, e.g. a
    messages stats sidecar). `?message=` deep links resolve by scan (same posture as
    `?event=`). Depends on C1 + C3a; independent of D.
- **D. Search worker.** Scan worker, renderer-aligned extraction
  (worker-importable check), match table, find-band integration. Depends on
  C2; outside the viewer-works milestone.
- **B. Python read primitives.** The sample reader, lazy `EvalSample`
  subclass, warnings (introducing the named-constants table with them —
  **⚑ amended**, moved here from A), existing-API integration, old-format
  pre-parse warning. Depends on A. **⚑ amended** ([Change log](#change-log),
  2026-07-21): deferred behind the viewer milestone — nothing viewer-side
  reads via the Python APIs.
- **E. Downstream surfaces.** Scout + Scout viewer read support; verification
  pass over the tooling matrix; refuse-message copy update (**⚑ amended**,
  moved from C). Depends on B.

**Phase 2 (opt-in write):**

- **F. Recorder write path.** Chunked writer + seal path (local accumulator,
  start-stub, multipart upload), writer knobs (chunk policy, notables cap).
  **⚑ amended** ([Change log](#change-log)): the monolith finalize-time
  policy, monolith-threshold knob, and "CI pins 0" are dropped — the writer
  always chunks (indefinite deferral of [#17](#small-sample-monolith-threshold-17)).
- **G. Live path.** Segment chunk members + supersede-tail, manifest chunk
  directory, local SQLite synthesis, live skeleton/stats re-emission, viewer
  live byte source + seal swap, live search. **Re-validates every ⚠️
  PROVISIONAL section first.**
- **H. Crash recovery rework.** Resolve the deferred mechanism
  (seal-against-surviving-buffer candidate) and implement.

**Phase 3 (default flip):**

- **I. Flip + retirement.** Default-on-write; retire `sampleStream`/four-cursor
  protocol for new logs, converge the forked list-model layer, message-copy
  revisit if the converter goes public.

## Deferred open issues

Recorded here so they aren't lost; each is out of this effort's scope:

1. **Score-edit / `invalidate_samples` representation on chunked format** —
   mid-sequence `ScoreEditEvent` insertion collides with index-identity
   chunks. Candidates surfaced: shell-only edits, append-at-end with span
   linkage, tail-chunk rewrite. Until resolved: today's whole-rewrite path,
   degraded with warning.
2. **Reused-sample carry-over in eval-set/retry** — candidate: raw zip-member
   byte-copy of the sample's prefix.
3. **Remote tag/metadata edit cost** — candidates: raw member copy without
   recompression, S3 `UploadPartCopy` prefix copy.
4. **Crash-recovery mechanism for chunked logs** (phase-2 effort H).
5. **Opt-in write mechanism** (env var vs CLI/eval option) — phase 2.
6. **Version-field gating** — the JJ follow-up.
7. **Default chunk-policy tuning** (count vs byte-target within the 1–8 MiB
   envelope) — settled by measurement during implementation.
8. **Per-sample manifest sharding** — only if per-run live-manifest growth
   (chunk-directory entries × concurrent samples) ever bites.
9. **Small-sample monolith threshold** (**⚑ amended**,
   [Change log](#change-log)) — **deferred indefinitely**; working assumption
   is that it is not needed and every new-format sample is chunked. The
   ratified [#17](#small-sample-monolith-threshold-17) decision is retained as
   the design of record, reopened only if always-chunk costs on small samples
   prove material (measurement-triggered-lever posture).
10. **Parity oracle re-freeze** ([Change log](#change-log), 2026-07-21) —
    the Python oracle (#23) models the raw-tree outline branch the browser
    doesn't take; re-freeze it against the timeline-selected-view pipeline
    (or retire it in favor of extending the mechanism-8 twin corpus) and
    re-derive the signed-off divergence classes.
11. **Main-view transcript body for chunked samples** — the legacy body
    renders the selected timeline view (wrappers dissolved, utility
    extracted, scoring appended); the chunked body renders the raw tree via
    the row-window model. Reconciling needs a view-row mapping over the
    main-view ordering — design work, not a patch.
12. **Branch-tree and server-timeline rendering for chunked samples**
    (**⚑ amended**, [Change log](#change-log), 2026-07-22 — plan ratified,
    implementation pending) — rollback/fork logs (petri) get log-supplied
    timeline selectors and fork navigation in the legacy viewer, and the
    legacy default selection IS the server timeline when one exists — so on
    such logs the chunked path's flat main view (plus its raw-tree body,
    issue 11) diverged wholesale, not cosmetically. Ratified resolution:
    samples with `timelines` (or `branch`/`anchor` events in stats) under
    `TIMELINE_HYDRATION_BYTES` download all events and render the legacy
    panel unchanged; above the limit, the skeleton view stands and the body
    gap is issue 11. `events/uuids.json` supplies uuid→ordinal resolution
    at any size. petri3 empirics: zero `branch` events (branching is
    server-timeline + anchor only); 57/173 samples carry real branch trees.
13. **Skeleton v1 amendment candidates** ([Change log](#change-log),
    2026-07-21 + 2026-07-22) — (a) widen `NOTABLE_TYPES` (`error`/
    `compaction`/`sample_limit`/`branch`), (b) notable timestamps, (c)
    root-level `children` counts, (d) writer-time utility classification,
    (e) timeline-referenced event addressability — **resolved 2026-07-22**
    by `events/uuids.json` (uuid array in ordinal order,
    [Change log](#change-log)); no skeleton change needed. Remaining
    candidates a–d: decide before the phase-2 writer freezes the format.
14. **Materialized-row eviction** (PR #451 review, 2026-07-22) —
    `RowSpace.materializedRows` never evicts: decoded view rows (with
    attachments inlined) accumulate for the panel's lifetime, at odds with
    the byte store's budget and the parsed-chunk LRU. Fix shape: a cap that
    drops far-away chunks' `rows` while keeping the corrected
    `chunkRows`/`exact` entries, so accounting stays exact and only decode
    work is repaid on revisit. Interacts with ordinal re-anchoring — design
    it with issue 11 rather than patching ad hoc.

---

# Appendix A — Access-pattern inventory

Every completed-log access pattern and its landing (carried from the framing
doc, updated to the ratified decisions):

| # | Pattern | Accessed by | Landing |
|---|---|---|---|
| 1 | Header / summaries / listing | log list + sample list UI | unchanged (separate small entries) |
| 2 | Sample shell (metadata, scores, usage, error) | sample detail open; Python `exclude_fields` | `sample.json` — cheap by construction |
| 3 | Page messages by index window | Messages tab virtual list | index→chunk via start-named entries; **⚑ amended** — owned by effort C3 ([Change log](#change-log), 2026-07-21); interim = full-hydration bridge |
| 4 | Page events by index window | Transcript scroll | same |
| 5 | Tail / jump-to-last / follow | auto-follow, open-at-end | last chunk = greatest start-named entry; its end learned on parse |
| 6 | Structure without content (tree, outline, timeline) | first render of Transcript tab | `skeleton.json` |
| 7 | Deep links (event uuid, message→event) | URL deep links / citations | identity = sequence index; event uuid = O(1) lookup in `events/uuids.json` (**⚑ amended** 2026-07-22 — was one-time chunk scan) |
| 8 | Event-type filtering | Transcript filter menu | stats-sidecar pushdown; exact digits / approximate pixels |
| 9 | In-sample search | find band | progressive scan worker |
| 10 | Full hydration / export / Python full read | JSON tab, downloads, `read_eval_log` | read all chunks + reassemble (explicit bulk op, warned) |
| 11 | Live streaming | running-sample view | ⚠️ manifest + segment chunks (provisional) |
| 12 | Python selective reads | analysis/scoring pipelines, scout | sample reader primitives |

# Appendix B — Transformation audit

Where every viewer transformation runs against skeleton + windowed fetches
(verified against the viewer code at the start of this effort):

| Transformation | Reads | New home |
|---|---|---|
| `processPendingEvents` | `pending`, `uuid` | dropped — live-path only; at-rest logs contain no pending events |
| `collapseSampleInit` | event type | window-local; legacy no-span logs only |
| `groupSandboxEvents` | event type, timestamp | window-local (runs are contiguous; margin covers edges) |
| `injectScorersSpan` | span type | skeleton (synthesized wrapper over scorer spans) |
| `treeifyWithSpans` | `span_id`, `parent_id` | window-local — fetched bodies carry `span_id`; skeleton provides scaffolding |
| `transformTree` unwraps (`main`, `solvers`, `checkpoint`, same-name collapse) | span type/name | skeleton |
| `transformTree` child-shape matches (`unwrap_tools`, `unwrap_subtasks`, …) | direct-child event types + counts | skeleton `children` counts for outline; full fidelity window-local |
| `correctRetryTimestamps` / `groupRetryAttempts` | model error/success, `span_id`, timestamp | window-local with margin (retry runs adjacent) |
| `collapseFilters` default-collapse | span/step name+type, tool `agent`/`failed` | skeleton for spans; tool/subtask rows from fetched bodies |
| `filterEmpty` | children counts | skeleton counters |
| `removeNodeVisitor` family | event type, span name/type | outline: implicit; transcript: window-local |
| `makeTurns` / `collapseTurns` | event type sequence, depth | skeleton `gap_models` |
| `collapseScoring` | event type == score | skeleton notables |
| `computeTurnMap` | model-event positions | skeleton cumulative model counters |
| `pairToolApprovals` | approval `call.id` ↔ tool `id` | window-local with margin (pairs adjacent) |
| `flatTree` row math | tree + collapse state | skeleton descendant counts + extents |

# Appendix C — Decision record

| Section | Ticket | Resolved |
|---|---|---|
| Prior-art research | [#2](https://github.com/epatey/inspect_ai/issues/2) ([findings](https://github.com/epatey/inspect_ai/blob/research/prior-art-large-trace-viewers/design/research/prior-art-large-trace-viewers.md)) | 2026-07-18 |
| Zip/compression mechanics | [#3](https://github.com/epatey/inspect_ai/issues/3) ([findings](https://github.com/epatey/inspect_ai/blob/research/zip-chunked-log-mechanics/design/zip-chunked-log-mechanics.md)) | 2026-07-18 |
| Chunked on-disk layout | [#4](https://github.com/epatey/inspect_ai/issues/4) | 2026-07-18 |
| Structural skeleton | [#5](https://github.com/epatey/inspect_ai/issues/5) | 2026-07-18 |
| Attachments & pools | [#6](https://github.com/epatey/inspect_ai/issues/6) | 2026-07-18 |
| Live-view unification | [#7](https://github.com/epatey/inspect_ai/issues/7) | 2026-07-18 ⚠️ |
| Render prototype | [#8](https://github.com/epatey/inspect_ai/issues/8) ([FINDINGS](https://github.com/epatey/inspect_ai/blob/proto/eval2-render/prototypes/eval2-render/FINDINGS.md)) | 2026-07-18 |
| Viewer data loading | [#9](https://github.com/epatey/inspect_ai/issues/9) | 2026-07-18 (live source ⚠️) |
| Search | [#10](https://github.com/epatey/inspect_ai/issues/10) | 2026-07-18 |
| Python primitives & back-compat | [#12](https://github.com/epatey/inspect_ai/issues/12) | 2026-07-18 |
| Old-format degradation | [#13](https://github.com/epatey/inspect_ai/issues/13) | 2026-07-18 |
| Downstream tooling matrix | [#14](https://github.com/epatey/inspect_ai/issues/14) | 2026-07-18 |
| State/store reconstruction | [#16](https://github.com/epatey/inspect_ai/issues/16) | 2026-07-18 |
| Monolith threshold | [#17](https://github.com/epatey/inspect_ai/issues/17) | 2026-07-18 |
| Phasing & compat | [#18](https://github.com/epatey/inspect_ai/issues/18) | 2026-07-18 |
| Live skeleton/stats | [#19](https://github.com/epatey/inspect_ai/issues/19) | 2026-07-18 ⚠️ |

(#11 was absorbed into #5; #15 assembled this spec.)
