"""Fact triples — the explicit ingestion path for known, exact relationships.

Where LLM extraction is the wrong tool (product catalogs, org charts, seeding
canonical entities before a corpus ingest), assert facts directly. Every
documented API limit is validated client-side at construction, so a bad triple
is a clear Python error naming the field — not an HTTP 400 mid-run.
"""

import re
import uuid as _uuid
from collections.abc import Iterable
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from zep_cloud.client import Zep

from zep_ingest._errors import format_api_error
from zep_ingest._io import load_rows, rows_to_fields
from zep_ingest._validation import (
    check_len,
    check_required_string,
    check_scalar_map,
    check_timestamp,
)
from zep_ingest.exceptions import ConfigurationError
from zep_ingest.result import AddError, IngestResult
from zep_ingest.submitters.sequential import call_with_retries
from zep_ingest.types import MAX_METADATA_KEYS, Destination

MAX_FACT_CHARS = 250
MAX_NODE_NAME_CHARS = 50
MAX_FACT_NAME_CHARS = 50
MAX_SUMMARY_CHARS = 500

_FACT_NAME = re.compile(r"^[A-Z][A-Z0-9_]*$")


@dataclass(slots=True)
class FactTriple:
    """One fact edge between two named nodes, validated against the API limits.

    ``source_node_uuid``/``target_node_uuid`` pin an endpoint to an existing
    node by identity instead of name resolution — pass UUIDs from
    ``IngestResult.node_uuids`` (or another prior read) so a re-run cannot
    resolve a slightly different name to a new node. Zep assigns the fact's own
    UUID; it is returned as ``edge_uuid`` in the task params once the task
    completes and is collected on ``IngestResult.edge_uuids`` after ``wait()``
    (parallel to the submitted triples, with ``None`` for a terminal task that
    assigned none).
    """

    fact: str
    fact_name: str
    source_node_name: str
    target_node_name: str
    source_node_summary: str | None = None
    target_node_summary: str | None = None
    source_node_labels: list[str] | None = None
    target_node_labels: list[str] | None = None
    source_node_uuid: str | None = None
    target_node_uuid: str | None = None
    valid_at: str | None = None
    invalid_at: str | None = None
    created_at: str | None = None
    attributes: dict[str, Any] | None = None
    metadata: dict[str, Any] | None = None

    def __post_init__(self) -> None:
        errors: list[str] = []
        check_required_string("fact", self.fact, MAX_FACT_CHARS, errors)
        check_required_string("fact_name", self.fact_name, MAX_FACT_NAME_CHARS, errors)
        if isinstance(self.fact_name, str) and not _FACT_NAME.match(self.fact_name):
            errors.append(
                f"fact_name must be SCREAMING_SNAKE_CASE (e.g. WORKS_AT): {self.fact_name!r}"
            )
        check_required_string(
            "source_node_name", self.source_node_name, MAX_NODE_NAME_CHARS, errors
        )
        check_required_string(
            "target_node_name", self.target_node_name, MAX_NODE_NAME_CHARS, errors
        )
        check_len("source_node_summary", self.source_node_summary, MAX_SUMMARY_CHARS, errors)
        check_len("target_node_summary", self.target_node_summary, MAX_SUMMARY_CHARS, errors)
        for field in ("source_node_labels", "target_node_labels"):
            labels = getattr(self, field)
            if labels is None:
                continue
            if not isinstance(labels, list):
                errors.append(
                    f"{field} must be a list with one entity-type label, got "
                    f"{type(labels).__name__}"
                )
            elif len(labels) > 1:
                errors.append(
                    f"{field} allows at most one entity-type label (extraction assigns "
                    f"one best-match type per node); got {labels!r}"
                )
            elif labels:
                check_len(f"{field}[0]", labels[0], 100, errors)
        for field in ("source_node_uuid", "target_node_uuid"):
            value = getattr(self, field)
            if value is not None:
                try:
                    _uuid.UUID(str(value))
                except (ValueError, AttributeError, TypeError):
                    errors.append(f"{field} is not a valid UUID: {value!r}")
        check_timestamp("valid_at", self.valid_at, errors)
        check_timestamp("invalid_at", self.invalid_at, errors)
        check_timestamp("created_at", self.created_at, errors)
        check_scalar_map("attributes", self.attributes, errors)
        check_scalar_map("metadata", self.metadata, errors, max_keys=MAX_METADATA_KEYS)
        if errors:
            raise ConfigurationError(
                f"Invalid fact triple ({str(self.fact)[:60]!r}): " + "; ".join(errors)
            )

    def to_api_kwargs(self, destination: Destination) -> dict[str, Any]:
        kwargs: dict[str, Any] = {
            "fact": self.fact,
            "fact_name": self.fact_name,
            "source_node_name": self.source_node_name,
            "target_node_name": self.target_node_name,
        }
        for field in (
            "source_node_summary",
            "target_node_summary",
            "source_node_labels",
            "target_node_labels",
            "source_node_uuid",
            "target_node_uuid",
            "valid_at",
            "invalid_at",
            "created_at",
            "metadata",
        ):
            value = getattr(self, field)
            if value is not None:
                kwargs[field] = value
        if self.attributes is not None:
            kwargs["edge_attributes"] = self.attributes
        if destination.graph_id is not None:
            kwargs["graph_id"] = destination.graph_id
        else:
            kwargs["user_id"] = destination.user_id
        return kwargs


_RETIRED_TRIPLE_FIELDS = {
    "fact_uuid": (
        "fact_uuid cannot be supplied: Zep assigns fact UUIDs "
        "(returned as edge_uuid in task params once the task completes)"
    ),
}


def _load_triples(path: Path) -> list[FactTriple]:
    rows = rows_to_fields(load_rows(path), FactTriple, retired_fields=_RETIRED_TRIPLE_FIELDS)
    return [FactTriple(**row) for row in rows]


def ingest_fact_triples(
    client: Zep,
    triples: Iterable[FactTriple] | str | Path,
    *,
    graph_id: str | None = None,
    user_id: str | None = None,
    max_retries: int = 5,
) -> IngestResult:
    """Submit fact triples via graph.add_fact_triple (sequential; the Batch API
    does not accept triples). All triples are validated before the first call.

    Submission is asynchronous; bind the result, then wait on it, so the resume
    handles survive a timeout::

        result = ingest_fact_triples(client, triples, graph_id="g1")
        result.wait()
    """
    destination = Destination(graph_id=graph_id, user_id=user_id)
    if isinstance(triples, str | Path):
        materialized = _load_triples(Path(triples))
    else:
        materialized = list(triples)
    result = IngestResult(method="sequential", client=client)
    for index, triple in enumerate(materialized):
        kwargs = triple.to_api_kwargs(destination)
        response, error = call_with_retries(
            lambda: client.graph.add_fact_triple(**kwargs),  # noqa: B023
            max_retries=max_retries,
        )
        if error is not None:
            result.add_errors.append(
                AddError(
                    index=index,
                    item_count=1,
                    error=format_api_error("graph.add_fact_triple", error),
                )
            )
        else:
            result.items_submitted += 1
            task_id = getattr(response, "task_id", None)
            if task_id and str(task_id) not in result.task_ids:
                result.task_ids.append(str(task_id))
            elif not task_id:
                result.untracked_items += 1
    return result
