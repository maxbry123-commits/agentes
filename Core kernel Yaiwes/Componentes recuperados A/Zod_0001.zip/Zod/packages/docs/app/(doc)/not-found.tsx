import { DocsPage } from "fumadocs-ui/page";

export const metadata = { title: "Page not found | Zod" };

// rendered inside the (doc) layout, which already provides the docs shell
export default function NotFound() {
  return (
    <DocsPage>
      <div className="flex flex-col items-center justify-center min-h-[60vh] text-center">
        <h1 className="text-6xl font-bold text-fd-foreground border-none py-0!">404</h1>
        <p className="mt-4 text-lg text-fd-muted-foreground">This page could not be found.</p>
      </div>
    </DocsPage>
  );
}
