use anyhow::Result;

use walkdir::DirEntry;

use crate::{
    api::releases::Release,
    invocation_context::context,
    sourcemaps::inject::{inject_impl, EventReleaseSource, InjectArgs},
};

pub fn inject(args: &InjectArgs, existing_release: Option<&Release>) -> Result<()> {
    context().capture_command_invoked("sourcemap_inject");
    args.validate()?;
    inject_impl(
        args,
        is_javascript_file,
        existing_release,
        EventReleaseSource::EmbeddedInChunk,
    )
}

pub fn is_javascript_file(entry: &DirEntry) -> bool {
    entry.file_type().is_file()
        && entry
            .path()
            .extension()
            .is_some_and(|ext| ext == "js" || ext == "mjs" || ext == "cjs")
}

pub fn is_stylesheet_file(entry: &DirEntry) -> bool {
    entry.file_type().is_file() && entry.path().extension().is_some_and(|ext| ext == "css")
}
