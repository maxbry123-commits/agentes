from typing import Any

from unittest import mock
from unittest.mock import Mock, patch

from django.db import IntegrityError
from django.test import TestCase

from parameterized import parameterized
from rest_framework import exceptions
from rest_framework.exceptions import NotFound, ValidationError

from posthog.models.integration import Integration
from posthog.models.organization import Organization, OrganizationMembership
from posthog.models.organization_integration import OrganizationIntegration
from posthog.models.team import Team
from posthog.models.user import User

from products.experiments.backend.models.experiment import Experiment
from products.feature_flags.backend.models.feature_flag import FeatureFlag

from ee.api.vercel.types import VercelUserClaims
from ee.vercel.integration import VercelIntegration, _safe_vercel_sync

# Hardcoded independently of ee.vercel.integration.CLIENT_ENV_PREFIXES so a dropped prefix fails these tests.
EXPECTED_PREFIXES = ["NEXT_PUBLIC_", "VITE_", "NUXT_PUBLIC_", "PUBLIC_"]


class TestVercelIntegration(TestCase):
    TEST_INSTALLATION_ID = "icfg_9bceb8ccT32d3U417ezb5c8p"
    NONEXISTENT_INSTALLATION_ID = "icfg_nonexistent123456789012"
    NEW_INSTALLATION_ID = "icfg_987654321abcdef123456789"
    DIFFERENT_INSTALLATION_ID = "icfg_different123456789012345"

    def make_team_with_vercel(self, org, user):
        team = Team.objects.create(organization=org, name="Test Team")
        resource = Integration.objects.create(
            team=team,
            kind=Integration.IntegrationKind.VERCEL,
            integration_id=str(team.pk),
            config={"productId": "posthog", "name": "Test Resource"},
            created_by=user,
        )
        return team, resource

    def make_feature_flag(self, team, name, description, archived):
        # archived maps to the deleted field in FeatureFlag model
        return FeatureFlag.objects.create(
            team=team,
            key=name,
            name=description,
            deleted=archived,
        )

    def make_experiment(self, team, name, description, archived):
        ff = FeatureFlag.objects.create(team=team, key="exp-flag")
        return Experiment.objects.create(
            team=team,
            name=name,
            description=description,
            archived=archived,
            feature_flag=ff,
        )

    def assert_vercel_item(
        self, item, result, category, is_archived, slug=None, expected_name=None, expected_description=None
    ):
        assert result["id"] == f"{category}_{item.pk}"
        assert result["slug"] == slug or item.name.lower().replace(" ", "-")
        assert result["name"] == expected_name or getattr(item, "key", item.name)
        assert result["description"] == expected_description or getattr(item, "description", item.name)
        assert result["category"] == category
        assert result["isArchived"] == is_archived
        assert "origin" in result
        assert "createdAt" in result
        assert "updatedAt" in result
        # Verify createdAt is in milliseconds (should be > 1 billion ms since epoch)
        assert result["createdAt"] > 1_000_000_000_000, (
            f"createdAt should be in milliseconds, got {result['createdAt']}"
        )
        assert isinstance(result["createdAt"], int), f"createdAt should be int, got {type(result['createdAt'])}"
        # Verify updatedAt is in milliseconds
        assert result["updatedAt"] > 1_000_000_000_000, (
            f"updatedAt should be in milliseconds, got {result['updatedAt']}"
        )
        assert isinstance(result["updatedAt"], int), f"updatedAt should be int, got {type(result['updatedAt'])}"

    def make_vercel_item(self, **overrides):
        base = {
            "id": "test_id",
            "slug": "test-slug",
            "origin": "https://example.com",
            "name": "Test Item",
            "category": "test",
            "description": "Test Description",
            "isArchived": False,
        }
        base.update(overrides)
        return base

    def setUp(self):
        self.installation_id = self.TEST_INSTALLATION_ID
        self.user = User.objects.create_user(email="test@example.com", password="testpass", first_name="Test")
        self.organization = Organization.objects.create(name="Test Org")
        self.user.join(organization=self.organization, level=OrganizationMembership.Level.OWNER)

        self.installation = OrganizationIntegration.objects.create(
            organization=self.organization,
            kind=OrganizationIntegration.OrganizationIntegrationKind.VERCEL,
            integration_id=self.installation_id,
            config={"billing_plan_id": "posthog-usage-based", "scopes": ["read"]},
            created_by=self.user,
        )

        self.payload: dict[str, Any] = {
            "scopes": ["read", "write"],
            "acceptedPolicies": {"toc": "2024-02-28T10:00:00Z"},
            "credentials": {"access_token": "token", "token_type": "Bearer"},
            "account": {
                "name": "Test Account",
                "url": "https://example.com",
                "contact": {"email": "contact@example.com", "name": "John Doe"},
            },
        }

        # Create mock user claims for tests
        self.user_claims = self._create_user_claims("test_user_123")

    def _create_user_claims(self, user_id: str) -> VercelUserClaims:
        return VercelUserClaims(
            iss="https://marketplace.vercel.com",
            sub="account:test:user:test",
            aud="test_audience",
            account_id="test_account",
            installation_id=self.installation_id,
            user_id=user_id,
            user_role="ADMIN",
            type=None,
            user_avatar_url=None,
            user_email=self.payload["account"]["contact"]["email"],
            user_name=self.payload["account"]["contact"].get("name"),
        )

    def test_get_installation_exists(self):
        installation = VercelIntegration._get_installation(self.installation_id)
        assert installation.integration_id == self.installation_id
        assert installation.organization == self.organization

    def test_get_installation_not_found(self):
        with self.assertRaises(NotFound) as context:
            VercelIntegration._get_installation(self.NONEXISTENT_INSTALLATION_ID)
        assert str(context.exception) == "Installation not found"

    def test_get_vercel_plans_structure(self):
        plans = VercelIntegration.get_vercel_plans()
        assert len(plans) > 0
        assert plans[0]["id"]
        assert plans[0]["paymentMethodRequired"] is True

    def test_get_installation_billing_plan(self):
        result = VercelIntegration.get_installation_billing_plan(self.installation_id)
        # Returns empty dict - billing handled through PostHog, not Vercel
        assert result == {}

    def test_update_installation_not_found(self):
        VercelIntegration.update_installation(self.NONEXISTENT_INSTALLATION_ID, "pro200")

    @patch("ee.billing.billing_manager.BillingManager")
    @patch("ee.vercel.integration.get_cached_instance_license")
    def test_delete_installation(self, mock_license, mock_billing_manager):
        mock_license.return_value = Mock()
        mock_billing_manager.return_value = Mock()

        result = VercelIntegration.delete_installation(self.installation_id)

        assert result["finalized"]
        assert not OrganizationIntegration.objects.filter(integration_id=self.installation_id).exists()

    @patch("ee.vercel.integration.get_cached_instance_license")
    def test_delete_installation_aborts_without_license(self, mock_license):
        mock_license.return_value = None

        with self.assertRaises(RuntimeError):
            VercelIntegration.delete_installation(self.installation_id)

        assert OrganizationIntegration.objects.filter(integration_id=self.installation_id).exists()

    @patch("ee.billing.billing_manager.BillingManager")
    @patch("ee.vercel.integration.get_cached_instance_license")
    def test_delete_installation_calls_billing_deauthorize(self, mock_license, mock_billing_manager):
        """Deleting installation should notify billing service to cancel subscription."""
        from ee.billing.billing_types import BillingProvider

        mock_license.return_value = Mock()
        mock_manager_instance = Mock()
        mock_billing_manager.return_value = mock_manager_instance

        result = VercelIntegration.delete_installation(self.installation_id)

        assert result["finalized"]
        mock_billing_manager.assert_called_once_with(mock_license.return_value, user=self.user)
        mock_manager_instance.deauthorize.assert_called_once_with(
            self.organization, billing_provider=BillingProvider.VERCEL
        )

    @patch("ee.billing.billing_manager.BillingManager")
    @patch("ee.vercel.integration.get_cached_instance_license")
    def test_delete_installation_aborts_on_billing_failure(self, mock_license, mock_billing_manager):
        """Deletion should not proceed if billing deauthorization fails, so Vercel retries the webhook."""
        mock_license.return_value = Mock()
        mock_manager_instance = Mock()
        mock_manager_instance.deauthorize.side_effect = Exception("Billing service error")
        mock_billing_manager.return_value = mock_manager_instance

        with self.assertRaises(Exception) as context:
            VercelIntegration.delete_installation(self.installation_id)
        assert "Billing service error" in str(context.exception)

        assert OrganizationIntegration.objects.filter(integration_id=self.installation_id).exists()

    @patch("ee.billing.billing_manager.BillingManager")
    @patch("ee.vercel.integration.get_cached_instance_license")
    def test_delete_installation_blocked_by_open_invoices(self, mock_license, mock_billing_manager):
        from ee.billing.billing_manager import BillingServiceOpenInvoicesError

        mock_license.return_value = Mock()
        mock_manager_instance = Mock()
        mock_manager_instance.deauthorize.side_effect = BillingServiceOpenInvoicesError(
            "Cannot uninstall billing provider: 1 unpaid invoice must be resolved first."
        )
        mock_billing_manager.return_value = mock_manager_instance

        with self.assertRaises(BillingServiceOpenInvoicesError):
            VercelIntegration.delete_installation(self.installation_id)

        assert OrganizationIntegration.objects.filter(integration_id=self.installation_id).exists()

    def test_delete_installation_not_found(self):
        with self.assertRaises(NotFound):
            VercelIntegration.delete_installation(self.NONEXISTENT_INSTALLATION_ID)

    def test_get_product_plans_posthog(self):
        result = VercelIntegration.get_product_plans("posthog")
        assert "plans" in result
        assert len(result["plans"]) == 1
        assert result["plans"][0]["id"] == "posthog-usage-based"

    def test_get_product_plans_invalid_product(self):
        with self.assertRaises(NotFound) as context:
            VercelIntegration.get_product_plans("invalid_product")
        assert str(context.exception) == "Product not found"

    def test_upsert_installation_existing_installation(self):
        original_config = self.installation.config.copy()

        VercelIntegration.upsert_installation(self.installation_id, self.payload, self.user_claims)

        self.installation.refresh_from_db()
        expected_config = {k: v for k, v in self.payload.items() if k != "credentials"}
        assert self.installation.config == expected_config
        assert self.installation.config != original_config
        assert self.installation.sensitive_config["credentials"] == self.payload["credentials"]

    @patch("ee.vercel.integration.report_user_signed_up")
    def test_upsert_installation_new_user_new_org(self, mock_report):
        new_installation_id = self.NEW_INSTALLATION_ID
        new_user_claims = self._create_user_claims("new_user_456")
        new_user_claims.installation_id = new_installation_id
        new_user_claims.sub = "account:test:user:new"

        VercelIntegration.upsert_installation(new_installation_id, self.payload, new_user_claims)

        new_installation = OrganizationIntegration.objects.get(integration_id=new_installation_id)

        expected_config = self.payload.copy()
        expected_config["user_mappings"] = {"new_user_456": mock.ANY}

        # Check that user mapping was created
        assert "user_mappings" in new_installation.config
        assert "new_user_456" in new_installation.config["user_mappings"]
        assert new_installation.config["user_mappings"]["new_user_456"] is not None

        # Check all other config fields match (credentials are in sensitive_config)
        for key, value in self.payload.items():
            if key == "credentials":
                assert new_installation.sensitive_config["credentials"] == value
            else:
                assert new_installation.config[key] == value

        new_user = User.objects.get(email=self.payload["account"]["contact"]["email"])
        assert new_user.first_name == "John"
        assert not new_user.is_email_verified

        new_org = new_installation.organization
        assert new_org.name == self.payload["account"]["name"]

        membership = OrganizationMembership.objects.get(user=new_user, organization=new_org)
        assert membership.level == OrganizationMembership.Level.OWNER

        mock_report.assert_called_once()

    @patch("ee.vercel.integration.report_user_signed_up")
    def test_upsert_installation_existing_user_new_org(self, mock_report):
        """Test: External user (no Vercel mapping) installs - added to org but no mapping until SSO."""
        existing_user = User.objects.create_user(
            email=self.payload["account"]["contact"]["email"], password="existing", first_name="Existing"
        )
        new_installation_id = self.NEW_INSTALLATION_ID
        existing_user_claims = self._create_user_claims("existing_user_789")
        existing_user_claims.installation_id = new_installation_id
        existing_user_claims.sub = "account:test:user:existing"

        VercelIntegration.upsert_installation(new_installation_id, self.payload, existing_user_claims)

        new_installation = OrganizationIntegration.objects.get(integration_id=new_installation_id)
        assert new_installation.created_by == existing_user

        # User mapping is NOT created - user must prove ownership via SSO login first
        assert "user_mappings" not in new_installation.config or "existing_user_789" not in new_installation.config.get(
            "user_mappings", {}
        )

        # Check all other config fields match (credentials are in sensitive_config)
        for key, value in self.payload.items():
            if key == "credentials":
                assert new_installation.sensitive_config["credentials"] == value
            else:
                assert new_installation.config[key] == value

        # Existing user IS added to the organization - they are installing so they should be a member
        new_org = new_installation.organization
        membership = OrganizationMembership.objects.get(user=existing_user, organization=new_org)
        assert membership.level == OrganizationMembership.Level.OWNER

        mock_report.assert_not_called()

    @patch("ee.vercel.integration.report_user_signed_up")
    def test_sso_requires_login_for_external_user(self, mock_report):
        """Security test: External users (no Vercel mapping) must prove ownership via login."""
        from ee.vercel.integration import RequiresExistingUserLogin

        # Create an existing PostHog user (not through Vercel)
        existing_user = User.objects.create_user(
            email="external@example.com", password="external", first_name="External"
        )

        # Now install Vercel integration with that email
        installation_id = self.NEW_INSTALLATION_ID
        payload = {
            **self.payload,
            "account": {
                **self.payload["account"],
                "contact": {"email": "external@example.com", "name": "External User"},
            },
        }
        user_claims = self._create_user_claims("vercel_external_user")
        user_claims.installation_id = installation_id
        user_claims.user_email = "external@example.com"

        VercelIntegration.upsert_installation(installation_id, payload, user_claims)

        installation = OrganizationIntegration.objects.get(integration_id=installation_id)

        # User mapping is NOT created - they need to prove ownership via SSO login
        assert "user_mappings" not in installation.config or "vercel_external_user" not in installation.config.get(
            "user_mappings", {}
        )

        # User IS added to org - they are installing so they should be a member
        membership = OrganizationMembership.objects.get(user=existing_user, organization=installation.organization)
        assert membership.level == OrganizationMembership.Level.OWNER

        # SSO should require login for external user (no mapping yet)
        sso_claims = self._create_user_claims("vercel_external_user")
        sso_claims.installation_id = installation_id
        sso_claims.user_email = "external@example.com"

        with self.assertRaises(RequiresExistingUserLogin):
            VercelIntegration._find_sso_user(sso_claims)

    @patch("ee.vercel.integration.report_user_signed_up")
    def test_sso_works_for_trusted_vercel_user_second_installation(self, mock_report):
        """E2E: Trusted Vercel user's second installation should auto-link and SSO should work."""
        from ee.vercel.integration import RequiresExistingUserLogin

        # First installation - creates user with mapping
        first_installation_id = self.NEW_INSTALLATION_ID
        first_user_claims = self._create_user_claims("vercel_user_abc")
        first_user_claims.installation_id = first_installation_id

        VercelIntegration.upsert_installation(first_installation_id, self.payload, first_user_claims)
        user = User.objects.get(email=self.payload["account"]["contact"]["email"])

        # Second installation - same email, different installation
        second_installation_id = "icfg_second_install_12345678"
        second_payload = {**self.payload, "account": {**self.payload["account"], "name": "Second Org"}}
        second_user_claims = self._create_user_claims("vercel_user_xyz")
        second_user_claims.installation_id = second_installation_id

        VercelIntegration.upsert_installation(second_installation_id, second_payload, second_user_claims)

        # Verify installation created mapping and membership
        second_installation = OrganizationIntegration.objects.get(integration_id=second_installation_id)
        assert second_installation.config["user_mappings"].get("vercel_user_xyz") == user.pk
        membership = OrganizationMembership.objects.get(user=user, organization=second_installation.organization)
        assert membership.level == OrganizationMembership.Level.OWNER

        # SSO should work without requiring login
        sso_claims = self._create_user_claims("vercel_user_xyz")
        sso_claims.installation_id = second_installation_id

        try:
            sso_user = VercelIntegration._find_sso_user(sso_claims)
            assert sso_user.pk == user.pk
        except RequiresExistingUserLogin:
            self.fail("SSO should NOT require login for trusted Vercel user")

    @patch("ee.vercel.integration.report_user_signed_up")
    @patch("ee.billing.billing_manager.BillingManager")
    @patch("ee.vercel.integration.get_cached_instance_license")
    def test_billing_failure_does_not_delete_existing_user(self, mock_license, mock_billing, mock_report):
        """Billing failure should NOT delete existing users (only newly created ones)."""
        # First installation - creates user with mapping
        first_installation_id = self.NEW_INSTALLATION_ID
        first_user_claims = self._create_user_claims("vercel_user_billing")
        first_user_claims.installation_id = first_installation_id

        VercelIntegration.upsert_installation(first_installation_id, self.payload, first_user_claims)
        user = User.objects.get(email=self.payload["account"]["contact"]["email"])
        user_pk = user.pk

        # Second installation - billing will fail
        second_installation_id = "icfg_billing_fail_123456789"
        second_payload = {**self.payload, "account": {**self.payload["account"], "name": "Second Org"}}
        second_user_claims = self._create_user_claims("vercel_user_billing_2")
        second_user_claims.installation_id = second_installation_id

        # Make billing fail
        mock_license.return_value = Mock()
        mock_billing.return_value.authorize.side_effect = Exception("Billing failed")

        with self.assertRaises(Exception):
            VercelIntegration.upsert_installation(second_installation_id, second_payload, second_user_claims)

        # User should NOT be deleted - they existed before this installation
        assert User.objects.filter(pk=user_pk).exists(), "Trusted Vercel user should NOT be deleted on billing failure"

    @patch("ee.vercel.integration.capture_exception")
    def test_upsert_installation_integrity_error(self, mock_capture):
        error_user_claims = self._create_user_claims("error_user_999")
        error_user_claims.installation_id = self.NEW_INSTALLATION_ID
        error_user_claims.sub = "account:test:user:error"

        with patch("ee.vercel.integration.OrganizationIntegration.objects.update_or_create") as mock_update_or_create:
            mock_update_or_create.side_effect = IntegrityError("Duplicate key")

            with self.assertRaises(ValidationError) as context:
                VercelIntegration.upsert_installation(self.NEW_INSTALLATION_ID, self.payload, error_user_claims)

            detail = context.exception.detail
            if isinstance(detail, dict):
                assert detail.get("validation_error") == "Something went wrong."
            mock_capture.assert_called_once()

    def test_upsert_installation_creates_org_with_fallback_name(self):
        new_installation_id = self.NEW_INSTALLATION_ID
        payload_without_name = self.payload.copy()
        del payload_without_name["account"]["name"]

        fallback_user_claims = self._create_user_claims("fallback_user_111")
        fallback_user_claims.installation_id = new_installation_id
        fallback_user_claims.sub = "account:test:user:fallback"
        fallback_user_claims.user_email = payload_without_name["account"]["contact"]["email"]
        fallback_user_claims.user_name = payload_without_name["account"]["contact"]["name"]

        VercelIntegration.upsert_installation(new_installation_id, payload_without_name, fallback_user_claims)

        new_installation = OrganizationIntegration.objects.get(integration_id=new_installation_id)
        assert new_installation.organization.name == f"Vercel Installation {new_installation_id}"

    def test_upsert_installation_creates_user_with_fallback_name(self):
        new_installation_id = self.NEW_INSTALLATION_ID
        payload_without_name = self.payload.copy()
        del payload_without_name["account"]["contact"]["name"]

        no_name_user_claims = self._create_user_claims("noname_user_222")
        no_name_user_claims.installation_id = new_installation_id
        no_name_user_claims.sub = "account:test:user:noname"
        no_name_user_claims.user_email = payload_without_name["account"]["contact"]["email"]
        no_name_user_claims.user_name = None

        VercelIntegration.upsert_installation(new_installation_id, payload_without_name, no_name_user_claims)

        new_user = User.objects.get(email=payload_without_name["account"]["contact"]["email"])
        assert new_user.first_name == payload_without_name["account"]["contact"]["email"].split("@")[0]

    def test_upsert_installation_reactivates_inactive_user(self):
        new_installation_id = self.NEW_INSTALLATION_ID
        inactive_email = "inactive@example.com"

        inactive_user = User.objects.create_user(
            email=inactive_email, password="testpass", first_name="Inactive", is_active=False
        )

        payload = self.payload.copy()
        payload["account"]["contact"]["email"] = inactive_email

        user_claims = self._create_user_claims("inactive_user_123")
        user_claims.installation_id = new_installation_id
        user_claims.user_email = inactive_email

        VercelIntegration.upsert_installation(new_installation_id, payload, user_claims)

        inactive_user.refresh_from_db()
        assert inactive_user.is_active is True

        org_integration = OrganizationIntegration.objects.get(integration_id=new_installation_id)
        assert org_integration.created_by == inactive_user

    def test_get_resource_not_found(self):
        with self.assertRaises(NotFound):
            VercelIntegration.get_resource("999999")

    def test_create_resource(self):
        resource_data = {
            "productId": "posthog",
            "name": "New Resource",
            "metadata": {"key": "value"},
            "billingPlanId": "posthog-usage-based",
        }

        result = VercelIntegration.create_resource(self.installation_id, resource_data)

        assert "id" in result
        assert result["productId"] == "posthog"
        assert result["name"] == "New Resource"
        assert result["metadata"] == {"key": "value"}
        assert result["status"] == "ready"
        assert "secrets" in result
        assert "billingPlan" in result

        resource = Integration.objects.get(pk=result["id"])
        expected_config = {**resource_data, "externalId": None, "protocolSettings": None}
        assert resource.config == expected_config
        assert resource.team.organization == self.organization
        assert resource.created_by == self.installation.created_by

    def test_get_resource(self):
        team, resource = self.make_team_with_vercel(self.organization, self.user)
        resource.config["metadata"] = {}
        resource.save()

        result = VercelIntegration.get_resource(str(resource.pk))

        assert result["id"] == str(resource.pk)
        assert result["productId"] == "posthog"
        assert result["name"] == "Test Resource"
        assert result["status"] == "ready"
        assert "secrets" in result
        assert "billingPlan" in result

    def test_update_resource(self):
        team, resource = self.make_team_with_vercel(self.organization, self.user)
        resource.config.update(
            {
                "name": "Original Name",
                "metadata": {"old": "value"},
                "billingPlanId": "posthog-usage-based",
            }
        )
        resource.save()

        update_data = {"name": "Updated Name", "metadata": {"new": "value"}}
        result = VercelIntegration.update_resource(str(resource.pk), update_data)

        resource.refresh_from_db()
        assert resource.config["name"] == "Updated Name"
        assert resource.config["metadata"] == {"new": "value"}
        assert resource.config["productId"] == "posthog"
        assert result["name"] == "Updated Name"
        assert result["metadata"] == {"new": "value"}

    def test_delete_resource(self):
        team, resource = self.make_team_with_vercel(self.organization, self.user)
        resource_id = str(resource.pk)
        VercelIntegration.delete_resource(resource_id)
        assert not Integration.objects.filter(pk=resource_id).exists()

    def test_delete_resource_not_found(self):
        with self.assertRaises(NotFound):
            VercelIntegration.delete_resource("999999")

    def test_create_resource_missing_name(self):
        resource_data = {
            "productId": "posthog",
            "metadata": {"key": "value"},
            "billingPlanId": "posthog-usage-based",
        }

        with self.assertRaises(exceptions.ValidationError) as context:
            VercelIntegration.create_resource(self.installation_id, resource_data)

        assert "name" in str(context.exception.detail)

    def test_build_secrets_leads_with_the_next_public_names(self):
        team = Team.objects.create(organization=self.organization, name="Test Team", api_token="test_api_token")
        secrets = VercelIntegration._build_secrets(team)

        assert secrets[0]["name"] == "NEXT_PUBLIC_POSTHOG_PROJECT_TOKEN"
        assert secrets[0]["value"] == "test_api_token"
        assert secrets[1]["name"] == "NEXT_PUBLIC_POSTHOG_HOST"
        assert secrets[1]["value"].startswith(("https://", "http://"))

    @parameterized.expand([(prefix,) for prefix in EXPECTED_PREFIXES])
    def test_build_secrets_injects_framework_prefixed_aliases(self, prefix: str):
        team = Team.objects.create(organization=self.organization, name="Test Team", api_token="test_api_token")
        secrets = {secret["name"]: secret["value"] for secret in VercelIntegration._build_secrets(team)}

        assert secrets[f"{prefix}POSTHOG_PROJECT_TOKEN"] == "test_api_token"
        assert secrets[f"{prefix}POSTHOG_HOST"].startswith(("https://", "http://"))

    def test_build_secrets_covers_every_prefix_exactly_once(self):
        team = Team.objects.create(organization=self.organization, name="Test Team", api_token="test_api_token")
        secrets = VercelIntegration._build_secrets(team)

        names = [secret["name"] for secret in secrets]
        assert len(names) == len(set(names)) == 2 * len(EXPECTED_PREFIXES)

    @parameterized.expand(
        [
            ("exists", lambda self: self.make_team_with_vercel(self.organization, self.user)[0], True),
            (
                "not_found",
                lambda self: Team.objects.create(organization=self.organization, name="No Vercel Team"),
                False,
            ),
        ]
    )
    def test_get_vercel_resource_for_team(self, _, team_factory, should_exist):
        team = team_factory(self)
        result = VercelIntegration._get_vercel_resource_for_team(team)
        assert (result is not None) == should_exist

    @parameterized.expand(
        [
            ("exists", lambda self: self.organization, True),
            ("not_found", lambda self: Organization.objects.create(name="Other Org"), False),
        ]
    )
    def test_get_installation_for_organization(self, _, org_factory, should_exist):
        org = org_factory(self)
        result = VercelIntegration._get_installation_for_organization(org)
        assert (result == self.installation) if should_exist else (result is None)

    @parameterized.expand(
        [
            ("success", {"access_token": "test_token"}, "test_token"),
            ("missing", {}, None),
        ]
    )
    def test_get_access_token(self, _, credentials, expected):
        self.installation.sensitive_config["credentials"] = credentials
        self.installation.save()
        result = VercelIntegration._get_access_token(self.installation)
        assert result == expected

    def test_get_access_token_fallback_from_config(self):
        """Pre-migration installations store credentials in config — fallback should find them."""
        self.installation.config["credentials"] = {"access_token": "legacy_token", "token_type": "Bearer"}
        self.installation.sensitive_config = {}
        self.installation.save()
        result = VercelIntegration._get_access_token(self.installation)
        assert result == "legacy_token"

    @parameterized.expand(
        [
            ("success", False),
            ("failure", True),
        ]
    )
    @patch("ee.vercel.integration.VercelAPIClient")
    @patch("ee.vercel.integration.capture_exception")
    def test_create_vercel_client(self, _, should_fail, mock_capture, mock_client_class):
        token = "bad_token" if should_fail else "good_token"

        if should_fail:
            mock_client_class.side_effect = ValueError("Invalid token")
            assert VercelIntegration._create_vercel_client(token) is None
            mock_capture.assert_called_once()
        else:
            mock_client = Mock()
            mock_client_class.return_value = mock_client
            assert VercelIntegration._create_vercel_client(token) == mock_client
            mock_client_class.assert_called_once_with(bearer_token=token)

    @parameterized.expand(
        [
            (
                "flag",
                "make_feature_flag",
                VercelIntegration._convert_feature_flag_to_vercel_item,
                "flag",
                "test_flag",
                "Test Feature Flag",
                False,
                "test-flag",
            ),
            (
                "flag_deleted",
                "make_feature_flag",
                VercelIntegration._convert_feature_flag_to_vercel_item,
                "flag",
                "deleted_flag",
                "Deleted Flag",
                True,
                "deleted-flag",
            ),
            (
                "experiment",
                "make_experiment",
                VercelIntegration._convert_experiment_to_vercel_item,
                "experiment",
                "Test Experiment",
                "A test experiment",
                False,
                "test-experiment",
            ),
            (
                "experiment_archived",
                "make_experiment",
                VercelIntegration._convert_experiment_to_vercel_item,
                "experiment",
                "Archived Experiment",
                "",
                True,
                "archived-experiment",
            ),
        ]
    )
    def test_convert_to_vercel_item(self, _, factory_name, converter, category, name, desc, archived, expected_slug):
        team, _ = self.make_team_with_vercel(self.organization, self.user)
        factory = getattr(self, factory_name)
        item = factory(team, name, desc, archived)
        result = converter(item, created=True)
        self.assert_vercel_item(item, result, category, archived, expected_slug, name, desc)

    @parameterized.expand(
        [
            ("sync_create", "sync", "create_experimentation_items", {"created": True}),
            ("sync_update", "sync", "update_experimentation_item", {"created": False}),
            ("sync_no_client", "sync", None, {"created": True, "has_client": False}),
            ("delete", "delete", "delete_experimentation_item", {}),
        ]
    )
    @patch("ee.vercel.integration.VercelIntegration._setup_vercel_client_for_team")
    def test_vercel_item_operations(self, _, operation_type, client_method, params, mock_setup):
        team, _ = self.make_team_with_vercel(self.organization, self.user)
        has_client = params.get("has_client", True)

        if has_client:
            mock_client = Mock()
            mock_api_result = Mock(success=True)
            getattr(mock_client, client_method).return_value = mock_api_result
            mock_result = Mock(client=mock_client, integration_config_id="config_id", resource_id="resource_id")
            mock_setup.return_value = mock_result
        else:
            mock_setup.return_value = None

        if operation_type == "sync":
            vercel_item = self.make_vercel_item()
            VercelIntegration._sync_item_to_vercel(
                team=team,
                item_type="flag",
                item_pk="123",
                vercel_item=vercel_item,
                created=params.get("created", True),
            )
        else:
            VercelIntegration._delete_item_from_vercel(
                team=team,
                item_type="flag",
                item_id="test_id",
            )

        if has_client:
            getattr(mock_client, client_method).assert_called_once()
        else:
            mock_setup.assert_called_once_with(team)

    @patch("ee.vercel.integration.VercelIntegration._sync_item_to_vercel")
    def test_sync_feature_flag_to_vercel(self, mock_sync):
        team, _ = self.make_team_with_vercel(self.organization, self.user)
        feature_flag = self.make_feature_flag(team, "test_flag", "Test Flag", False)

        VercelIntegration.sync_feature_flag_to_vercel(feature_flag, created=True)
        assert mock_sync.call_count >= 1

    @patch("ee.vercel.integration.VercelIntegration._delete_item_from_vercel")
    def test_delete_feature_flag_from_vercel(self, mock_delete):
        team, _ = self.make_team_with_vercel(self.organization, self.user)
        feature_flag = self.make_feature_flag(team, "test_flag", "Test Flag", False)

        VercelIntegration.delete_feature_flag_from_vercel(feature_flag)

        mock_delete.assert_called_once_with(
            team=team,
            item_type="flag",
            item_id=f"flag_{feature_flag.pk}",
        )

    @patch("ee.vercel.integration.VercelIntegration.delete_feature_flag_from_vercel")
    def test_feature_flag_post_save_signal_deletes_when_marked_deleted(self, mock_delete):
        team, _ = self.make_team_with_vercel(self.organization, self.user)

        feature_flag = FeatureFlag.objects.create(
            team=team,
            key="test_flag",
            name="Test Flag",
            deleted=False,
        )
        mock_delete.reset_mock()

        feature_flag.deleted = True
        feature_flag.save()

        mock_delete.assert_called_once_with(feature_flag)

    @patch("ee.vercel.integration.VercelIntegration.sync_feature_flag_to_vercel")
    def test_feature_flag_post_save_signal_syncs_when_not_deleted(self, mock_sync):
        """Test that post_save signal triggers sync when feature flag is not deleted"""
        team, _ = self.make_team_with_vercel(self.organization, self.user)

        feature_flag = FeatureFlag.objects.create(
            team=team,
            key="test_flag",
            name="Test Flag",
            deleted=False,
        )

        mock_sync.assert_called_with(feature_flag, True)
        mock_sync.reset_mock()

        feature_flag.name = "Updated Test Flag"
        feature_flag.save()

        mock_sync.assert_called_once_with(feature_flag, False)

    @patch("ee.vercel.integration.VercelIntegration.delete_experiment_from_vercel")
    def test_experiment_post_save_signal_deletes_when_marked_deleted(self, mock_delete):
        """Test that post_save signal triggers deletion when experiment is marked as deleted=True"""
        team, _ = self.make_team_with_vercel(self.organization, self.user)

        feature_flag = FeatureFlag.objects.create(team=team, key="exp-flag")

        experiment = Experiment.objects.create(
            team=team,
            name="test_experiment",
            feature_flag=feature_flag,
            deleted=False,
        )
        mock_delete.reset_mock()

        experiment.deleted = True
        experiment.save()

        mock_delete.assert_called_once_with(experiment)

    @patch("ee.vercel.integration.VercelIntegration.sync_experiment_to_vercel")
    def test_experiment_post_save_signal_syncs_when_not_deleted(self, mock_sync):
        """Test that post_save signal triggers sync when experiment is not deleted"""
        team, _ = self.make_team_with_vercel(self.organization, self.user)

        feature_flag = FeatureFlag.objects.create(team=team, key="exp-flag")

        experiment = Experiment.objects.create(
            team=team,
            name="test_experiment",
            feature_flag=feature_flag,
            deleted=False,
        )

        mock_sync.assert_called_with(experiment, True)
        mock_sync.reset_mock()

        experiment.name = "Updated Test Experiment"
        experiment.save()

        mock_sync.assert_called_once_with(experiment, False)

    @parameterized.expand(
        [
            ("delete_skips_autocreate", True, False, 0),
            ("sync_autocreates", False, True, 1),
        ]
    )
    def test_safe_vercel_sync_only_autocreates_resource_on_sync(
        self, _name, is_delete, should_create, expected_sync_calls
    ):
        team = Team.objects.create(organization=self.organization, name="No Resource Team")
        sync_func = Mock()

        _safe_vercel_sync("op", "item_1", team, sync_func, is_delete=is_delete)

        created = Integration.objects.filter(team=team, kind=Integration.IntegrationKind.VERCEL).exists()
        assert created is should_create
        assert sync_func.call_count == expected_sync_calls

    @patch("ee.vercel.integration.VercelAPIClient")
    def test_feature_flag_post_delete_does_not_recreate_vercel_resource(self, _mock_client):
        # Regression: project deletion looped forever. During the team-deletion cascade the team's Vercel
        # resource is deleted before its feature flags, so each flag's post_delete auto-created a connectable
        # Integration row for the team being deleted in the same atomic transaction — orphaning it and failing
        # COMMIT with an IntegrityError on the team FK. The delete path must never auto-create a resource.
        team = Team.objects.create(organization=self.organization, name="Doomed Team")
        flag = FeatureFlag.objects.create(team=team, key="doomed-flag")
        Integration.objects.filter(team=team, kind=Integration.IntegrationKind.VERCEL).delete()

        flag.delete()

        assert not Integration.objects.filter(team=team, kind=Integration.IntegrationKind.VERCEL).exists()


class TestVercelInstallationRegressions(TestCase):
    """
    Regression tests for Vercel installation bugs.

    These tests document specific bugs that were fixed and ensure they don't regress.
    Each test includes a description of the original bug and the fix.
    """

    NEW_INSTALLATION_ID = "icfg_regression_test_123456789"

    def setUp(self):
        self.payload: dict[str, Any] = {
            "scopes": ["read", "write"],
            "acceptedPolicies": {"toc": "2024-02-28T10:00:00Z"},
            "credentials": {"access_token": "token", "token_type": "Bearer"},
            "account": {
                "name": "Regression Test Org",
                "url": "https://example.com",
                "contact": {"email": "regression@example.com", "name": "Regression Test"},
            },
        }
        self.user_claims = VercelUserClaims(
            iss="https://marketplace.vercel.com",
            sub="account:test:user:regression",
            aud="test_audience",
            account_id="test_account",
            installation_id=self.NEW_INSTALLATION_ID,
            user_id="regression_user",
            user_role="ADMIN",
            type=None,
            user_avatar_url=None,
            user_email=self.payload["account"]["contact"]["email"],
            user_name=self.payload["account"]["contact"].get("name"),
        )

    @patch("ee.vercel.integration.report_user_signed_up")
    def test_regression_existing_user_without_vercel_mapping_added_to_org(self, mock_report):
        """
        Regression test for: https://github.com/PostHog/posthog/pull/46107

        Bug: When an existing PostHog user (without any prior Vercel mappings) installed
        the Vercel integration, they were NOT added to the newly created organization.
        This caused the installation to fail from Vercel's perspective.

        Fix: Always add existing users to the org during installation. They are the ones
        installing, so they should be a member regardless of whether they have prior
        Vercel mappings.

        Security note: User mapping is still only created for trusted users (those with
        existing Vercel mappings). External users must prove ownership via SSO login.
        """
        # Create a PostHog user who has never used Vercel before
        existing_user = User.objects.create_user(
            email=self.payload["account"]["contact"]["email"],
            password="existing_password",
            first_name="Existing",
        )

        # This user has NO Vercel mappings anywhere
        vercel_integrations = OrganizationIntegration.objects.filter(
            kind=OrganizationIntegration.OrganizationIntegrationKind.VERCEL
        )
        for integration in vercel_integrations:
            user_mappings = integration.config.get("user_mappings", {})
            assert existing_user.pk not in user_mappings.values(), "Test setup error: user should have no mappings"

        # Install Vercel integration
        VercelIntegration.upsert_installation(self.NEW_INSTALLATION_ID, self.payload, self.user_claims)

        # CRITICAL: User must be added to the organization
        installation = OrganizationIntegration.objects.get(integration_id=self.NEW_INSTALLATION_ID)
        membership = OrganizationMembership.objects.filter(
            user=existing_user, organization=installation.organization
        ).first()

        assert membership is not None, "REGRESSION: Existing user was not added to org during installation"
        assert membership.level == OrganizationMembership.Level.OWNER

        # User mapping should NOT be created (security: they need to prove ownership via SSO)
        user_mappings = installation.config.get("user_mappings", {})
        assert "regression_user" not in user_mappings, "User mapping should not be created for external users"

    @patch("ee.vercel.integration.report_user_signed_up")
    def test_regression_installation_succeeds_for_external_user(self, mock_report):
        """
        Regression test: Installation must succeed even for external users.

        The installation should complete successfully and create:
        - Organization
        - OrganizationIntegration record
        - User added as member

        The installation should NOT fail just because the user doesn't have prior Vercel mappings.
        """
        external_user = User.objects.create_user(
            email=self.payload["account"]["contact"]["email"],
            password="external_password",
            first_name="External",
        )

        # Installation should not raise any exceptions
        VercelIntegration.upsert_installation(self.NEW_INSTALLATION_ID, self.payload, self.user_claims)

        # Verify installation was created
        installation = OrganizationIntegration.objects.filter(integration_id=self.NEW_INSTALLATION_ID).first()
        assert installation is not None, "REGRESSION: Installation was not created"
        assert installation.organization is not None, "REGRESSION: Organization was not created"
        assert installation.created_by == external_user, "REGRESSION: created_by not set correctly"


class TestAddUserToOrganization(TestCase):
    """Unit tests for _add_user_to_organization helper."""

    def setUp(self):
        self.user = User.objects.create_user(email="add_user@example.com", password="test", first_name="Test")
        self.organization = Organization.objects.create(name="Test Org")

    def test_adds_user_as_owner(self):
        """User is added with correct membership level."""
        membership, created = VercelIntegration._add_user_to_organization(
            self.user, self.organization, OrganizationMembership.Level.OWNER
        )

        assert created is True
        assert membership.user == self.user
        assert membership.organization == self.organization
        assert membership.level == OrganizationMembership.Level.OWNER

    def test_adds_user_as_member(self):
        """User can be added as member level."""
        membership, created = VercelIntegration._add_user_to_organization(
            self.user, self.organization, OrganizationMembership.Level.MEMBER
        )

        assert created is True
        assert membership.level == OrganizationMembership.Level.MEMBER

    def test_idempotent_does_not_duplicate(self):
        """Calling twice doesn't create duplicate membership."""
        membership1, created1 = VercelIntegration._add_user_to_organization(
            self.user, self.organization, OrganizationMembership.Level.OWNER
        )
        membership2, created2 = VercelIntegration._add_user_to_organization(
            self.user, self.organization, OrganizationMembership.Level.OWNER
        )

        assert created1 is True
        assert created2 is False
        assert membership1.pk == membership2.pk
        assert OrganizationMembership.objects.filter(user=self.user, organization=self.organization).count() == 1

    def test_upgrades_membership_level_if_higher(self):
        """Existing membership is upgraded if new level is higher."""
        # First add as member
        VercelIntegration._add_user_to_organization(self.user, self.organization, OrganizationMembership.Level.MEMBER)

        # Add as owner - should upgrade
        membership, created = VercelIntegration._add_user_to_organization(
            self.user, self.organization, OrganizationMembership.Level.OWNER
        )

        assert created is False
        assert membership.level == OrganizationMembership.Level.OWNER

    def test_does_not_downgrade_membership_level(self):
        """Existing membership is not downgraded if new level is lower."""
        # First add as owner
        VercelIntegration._add_user_to_organization(self.user, self.organization, OrganizationMembership.Level.OWNER)

        # Try to add as member - should not downgrade
        membership, created = VercelIntegration._add_user_to_organization(
            self.user, self.organization, OrganizationMembership.Level.MEMBER
        )

        assert created is False
        assert membership.level == OrganizationMembership.Level.OWNER


class TestInstallationUserHandlingLogic(TestCase):
    """
    Unit tests for the user handling decision logic in upsert_installation.

    Tests the core logic: when to add users to orgs and when to create mappings.
    """

    def setUp(self):
        self.payload: dict[str, Any] = {
            "scopes": ["read", "write"],
            "acceptedPolicies": {"toc": "2024-02-28T10:00:00Z"},
            "credentials": {"access_token": "token", "token_type": "Bearer"},
            "account": {
                "name": "Test Org",
                "url": "https://example.com",
                "contact": {"email": "test@example.com", "name": "Test User"},
            },
        }

    def _create_claims(self, installation_id: str, user_id: str) -> VercelUserClaims:
        return VercelUserClaims(
            iss="https://marketplace.vercel.com",
            sub=f"account:test:user:{user_id}",
            aud="test_audience",
            account_id="test_account",
            installation_id=installation_id,
            user_id=user_id,
            user_role="ADMIN",
            type=None,
            user_avatar_url=None,
            user_email=self.payload["account"]["contact"]["email"],
            user_name=self.payload["account"]["contact"].get("name"),
        )

    @parameterized.expand(
        [
            ("new_user", False, True, True),  # New user: added to org, mapping created
            ("trusted_user", True, True, True),  # Trusted user: added to org, mapping created
            ("external_user", False, True, False),  # External user: added to org, NO mapping
        ]
    )
    @patch("ee.vercel.integration.report_user_signed_up")
    def test_user_handling_matrix(self, name, has_prior_mapping, expect_membership, expect_mapping, mock_report):
        """
        Test matrix for user handling during installation.

        | User Type     | Has Prior Mapping | Added to Org | Mapping Created |
        |---------------|-------------------|--------------|-----------------|
        | New user      | N/A               | Yes          | Yes             |
        | Trusted user  | Yes               | Yes          | Yes             |
        | External user | No                | Yes          | No              |
        """
        installation_id = f"icfg_matrix_{name}_123456789"

        if name == "new_user":
            # No existing user
            pass
        else:
            # Create existing user
            user = User.objects.create_user(
                email=self.payload["account"]["contact"]["email"],
                password="test",
                first_name="Existing",
            )

            if has_prior_mapping:
                # Create a prior Vercel installation with mapping
                prior_org = Organization.objects.create(name="Prior Org")
                OrganizationIntegration.objects.create(
                    organization=prior_org,
                    kind=OrganizationIntegration.OrganizationIntegrationKind.VERCEL,
                    integration_id="icfg_prior_installation",
                    config={"user_mappings": {"prior_vercel_id": user.pk}},
                    created_by=user,
                )

        claims = self._create_claims(installation_id, "test_vercel_id")
        VercelIntegration.upsert_installation(installation_id, self.payload, claims)

        installation = OrganizationIntegration.objects.get(integration_id=installation_id)
        user = User.objects.get(email=self.payload["account"]["contact"]["email"])

        # Check membership
        has_membership = OrganizationMembership.objects.filter(
            user=user, organization=installation.organization
        ).exists()
        assert has_membership == expect_membership, f"{name}: membership mismatch"

        # Check mapping
        user_mappings = installation.config.get("user_mappings", {})
        has_mapping = "test_vercel_id" in user_mappings
        assert has_mapping == expect_mapping, f"{name}: mapping mismatch"


class TestVercelUserMappingLogic(TestCase):
    """
    Tests for the user mapping logic that determines trust relationships.
    """

    def setUp(self):
        self.user = User.objects.create_user(email="mapping@example.com", password="test", first_name="Mapping")
        self.organization = Organization.objects.create(name="Mapping Test Org")
        self.user.join(organization=self.organization, level=OrganizationMembership.Level.OWNER)

    def test_user_has_no_vercel_mapping_initially(self):
        """User with no Vercel integrations has no mappings."""
        assert not VercelIntegration._user_has_any_vercel_mapping(self.user)

    def test_user_has_mapping_after_installation(self):
        """User gains mapping after being part of a Vercel installation."""
        OrganizationIntegration.objects.create(
            organization=self.organization,
            kind=OrganizationIntegration.OrganizationIntegrationKind.VERCEL,
            integration_id="icfg_mapping_test_123456789",
            config={"user_mappings": {"vercel_user_123": self.user.pk}},
            created_by=self.user,
        )

        assert VercelIntegration._user_has_any_vercel_mapping(self.user)

    def test_user_mapping_checks_all_installations(self):
        """User mapping check searches across all Vercel installations."""
        # Create two installations
        org1 = Organization.objects.create(name="Org 1")
        org2 = Organization.objects.create(name="Org 2")

        OrganizationIntegration.objects.create(
            organization=org1,
            kind=OrganizationIntegration.OrganizationIntegrationKind.VERCEL,
            integration_id="icfg_org1_123456789",
            config={"user_mappings": {"other_user": 999}},  # Different user
        )

        OrganizationIntegration.objects.create(
            organization=org2,
            kind=OrganizationIntegration.OrganizationIntegrationKind.VERCEL,
            integration_id="icfg_org2_123456789",
            config={"user_mappings": {"vercel_user_456": self.user.pk}},  # Our user
        )

        assert VercelIntegration._user_has_any_vercel_mapping(self.user)


class TestPushSecretsToVercel(TestCase):
    """Tests for pushing secrets to Vercel when API token is rotated."""

    def setUp(self):
        self.user = User.objects.create_user(email="secrets@example.com", password="test", first_name="Test")
        self.organization = Organization.objects.create(name="Secrets Test Org")
        self.user.join(organization=self.organization, level=OrganizationMembership.Level.OWNER)

        self.team = Team.objects.create(organization=self.organization, name="Test Team")
        self.resource = Integration.objects.create(
            team=self.team,
            kind=Integration.IntegrationKind.VERCEL,
            integration_id=str(self.team.pk),
            config={"productId": "posthog", "name": "Test Resource"},
            created_by=self.user,
        )

        self.installation = OrganizationIntegration.objects.create(
            organization=self.organization,
            kind=OrganizationIntegration.OrganizationIntegrationKind.VERCEL,
            integration_id="icfg_secrets_test_123456789",
            config={
                "billing_plan_id": "posthog-usage-based",
            },
            sensitive_config={
                "credentials": {"access_token": "test_token", "token_type": "Bearer"},
            },
            created_by=self.user,
        )

    @patch("ee.vercel.integration.VercelAPIClient")
    def test_push_secrets_to_vercel_calls_api(self, mock_client_class):
        mock_client = Mock()
        mock_client.update_resource_secrets.return_value = Mock(success=True)
        mock_client_class.return_value = mock_client

        VercelIntegration.push_secrets_to_vercel(self.team)

        mock_client.update_resource_secrets.assert_called_once()
        call_args = mock_client.update_resource_secrets.call_args
        assert call_args[1]["integration_config_id"] == self.installation.integration_id
        assert call_args[1]["resource_id"] == str(self.resource.pk)

        secrets = call_args[1]["secrets"]
        assert len(secrets) == 2 * len(EXPECTED_PREFIXES)
        for prefix in EXPECTED_PREFIXES:
            assert any(s["name"] == f"{prefix}POSTHOG_PROJECT_TOKEN" for s in secrets)
            assert any(s["name"] == f"{prefix}POSTHOG_HOST" for s in secrets)

    @patch("ee.vercel.integration.VercelAPIClient")
    def test_push_secrets_sends_current_api_token(self, mock_client_class):
        mock_client = Mock()
        mock_client.update_resource_secrets.return_value = Mock(success=True)
        mock_client_class.return_value = mock_client

        VercelIntegration.push_secrets_to_vercel(self.team)

        call_args = mock_client.update_resource_secrets.call_args
        secrets = call_args[1]["secrets"]
        api_key_secret = next(s for s in secrets if s["name"] == "NEXT_PUBLIC_POSTHOG_PROJECT_TOKEN")
        assert api_key_secret["value"] == self.team.api_token

    @patch("ee.vercel.integration.VercelAPIClient")
    def test_push_secrets_does_nothing_without_vercel_resource(self, mock_client_class):
        team_without_vercel = Team.objects.create(organization=self.organization, name="No Vercel Team")

        VercelIntegration.push_secrets_to_vercel(team_without_vercel)

        mock_client_class.assert_not_called()

    @patch("ee.vercel.integration.capture_exception")
    @patch("ee.vercel.integration.VercelAPIClient")
    def test_push_secrets_handles_api_error_gracefully(self, mock_client_class, mock_capture):
        mock_client = Mock()
        mock_client.update_resource_secrets.return_value = Mock(success=False, error="API error")
        mock_client_class.return_value = mock_client

        VercelIntegration.push_secrets_to_vercel(self.team)

        mock_capture.assert_called_once()

    @patch("ee.vercel.integration.capture_exception")
    @patch("ee.vercel.integration.VercelAPIClient")
    def test_push_secrets_handles_exception_gracefully(self, mock_client_class, mock_capture):
        mock_client = Mock()
        mock_client.update_resource_secrets.side_effect = Exception("Network error")
        mock_client_class.return_value = mock_client

        VercelIntegration.push_secrets_to_vercel(self.team)

        mock_capture.assert_called_once()
