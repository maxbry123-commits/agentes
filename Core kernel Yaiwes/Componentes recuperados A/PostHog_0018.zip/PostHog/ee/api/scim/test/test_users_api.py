from parameterized import parameterized
from rest_framework import status

from posthog.constants import AvailableFeature
from posthog.models import Organization, OrganizationMembership, User
from posthog.models.identity_provider_config import IdentityProviderConfig
from posthog.models.linked_identity_provider_config import LinkedIdentityProviderConfig
from posthog.models.organization_domain import OrganizationDomain

from products.access_control.backend.models.role import RoleMembership

from ee.api.scim.auth import generate_scim_token
from ee.api.scim.views import MAX_ITEMS_PER_PAGE
from ee.api.test.base import APILicensedTest
from ee.models.scim_provisioned_user import SCIMProvisionedUser


class TestSCIMUsersAPI(APILicensedTest):
    def setUp(self):
        super().setUp()

        # Ensure SCIM is in available features
        if not self.organization.is_feature_available(AvailableFeature.SCIM):
            features = self.organization.available_product_features or []
            if not any(f.get("key") == AvailableFeature.SCIM for f in features):
                features.append({"key": AvailableFeature.SCIM, "name": "SCIM"})
            self.organization.available_product_features = features
            self.organization.save()

        # Create organization domain with a linked, SCIM-enabled IdP config (SCIM auth resolves
        # through the linked config, not the domain's own legacy columns).
        self.domain = OrganizationDomain.objects.create(
            organization=self.organization,
            domain="example.com",
            verified_at="2024-01-01T00:00:00Z",
        )

        # Generate SCIM token
        token = generate_scim_token()
        self.plain_token = token.plain
        self.config = IdentityProviderConfig.objects.create(
            organization=self.organization, scim_enabled=True, scim_bearer_token=token.hashed
        )
        LinkedIdentityProviderConfig.objects.create(
            organization_domain=self.domain, identity_provider_config=self.config
        )
        self.config.refresh_from_db()

        self.scim_headers = {"HTTP_AUTHORIZATION": f"Bearer {self.plain_token}"}
        self.client.credentials(**self.scim_headers)

    def test_users_list(self):
        response = self.client.get(f"/scim/v2/{self.config.scim_slug}/Users")

        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert "Resources" in data
        assert data["totalResults"] >= 1  # At least the test user

    def test_users_list_filter_exact_match(self):
        user_a = User.objects.create_user(
            email="engineering@example.com",
            password=None,
            first_name="Engineering",
            last_name="User",
            is_email_verified=True,
        )
        OrganizationMembership.objects.create(
            user=user_a, organization=self.organization, level=OrganizationMembership.Level.MEMBER
        )
        SCIMProvisionedUser.objects.create(
            user=user_a,
            identity_provider_config=self.config,
            username="engineering@example.com",
            identity_provider=SCIMProvisionedUser.IdentityProvider.OTHER,
            active=True,
        )

        user_b = User.objects.create_user(
            email="alex@example.com", password=None, first_name="Alex", last_name="Other", is_email_verified=True
        )
        OrganizationMembership.objects.create(
            user=user_b, organization=self.organization, level=OrganizationMembership.Level.MEMBER
        )
        SCIMProvisionedUser.objects.create(
            user=user_b,
            identity_provider_config=self.config,
            username="alex@example.com",
            identity_provider=SCIMProvisionedUser.IdentityProvider.OTHER,
            active=True,
        )

        # Exact match should return only engineering@example.com
        response = self.client.get(
            f"/scim/v2/{self.config.scim_slug}/Users",
            {"filter": 'userName eq "engineering@example.com"'},
        )

        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert data["totalResults"] == 1
        assert data["itemsPerPage"] == 1
        assert data["Resources"][0]["userName"] == "engineering@example.com"

    def test_users_list_filter_excludes_users_from_other_orgs(self):
        # Create user that belongs only to a different organization
        other_org = Organization.objects.create(name="Other Org")
        user_other_org = User.objects.create_user(
            email="engineering@example.com",
            password=None,
            first_name="Other",
            last_name="User",
            is_email_verified=True,
        )
        OrganizationMembership.objects.create(
            user=user_other_org, organization=other_org, level=OrganizationMembership.Level.MEMBER
        )

        # Filter for user from other org should return nothing
        response = self.client.get(
            f"/scim/v2/{self.config.scim_slug}/Users",
            {"filter": 'userName eq "engineering@example.com"'},
        )

        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert data["totalResults"] == 0
        assert data["Resources"] == []

    def test_users_list_filter_no_match_returns_empty_list(self):
        response = self.client.get(
            f"/scim/v2/{self.config.scim_slug}/Users",
            {"filter": 'userName eq "nonexistent@example.com"'},
        )

        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert data["totalResults"] == 0
        assert data["itemsPerPage"] == 0
        assert data["Resources"] == []

    def test_users_list_filter_unrecognized_returns_empty_list(self):
        # Unsupported filter should not return all users; return empty set
        response = self.client.get(
            f"/scim/v2/{self.config.scim_slug}/Users",
            {"filter": 'name.givenName sw "Eng"'},
        )

        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert data["totalResults"] == 0
        assert data["itemsPerPage"] == 0
        assert data["Resources"] == []

    def test_create_user(self):
        user_data = {
            "schemas": ["urn:ietf:params:scim:schemas:core:2.0:User"],
            "userName": "Newuser@example.com",
            "name": {"givenName": "New", "familyName": "User"},
            "emails": [{"value": "Newuser@example.com", "primary": True}],
            "active": True,
        }

        response = self.client.post(
            f"/scim/v2/{self.config.scim_slug}/Users", data=user_data, content_type="application/scim+json"
        )

        assert response.status_code == status.HTTP_201_CREATED
        data = response.json()
        assert data["userName"] == "Newuser@example.com"
        assert data["name"]["givenName"] == "New"
        assert data["name"]["familyName"] == "User"

        # Verify user was created with lowercase email
        user = User.objects.get(email="newuser@example.com")
        assert user.first_name == "New"
        assert user.last_name == "User"
        assert user.is_email_verified is True

        # Verify organization membership
        membership = OrganizationMembership.objects.get(user=user, organization=self.organization)
        assert membership.level == OrganizationMembership.Level.MEMBER

        # Verify SCIM provisioned user record was created
        scim_user = SCIMProvisionedUser.objects.get(user=user, identity_provider_config=self.config)
        assert scim_user.username == "Newuser@example.com"
        assert scim_user.active is True
        assert scim_user.identity_provider == SCIMProvisionedUser.IdentityProvider.OTHER

    def test_existing_user_is_added_to_org(self):
        # Create user in different org
        other_org = Organization.objects.create(name="Other Org")
        existing_user = User.objects.create_user(
            email="existing@example.com", password=None, first_name="Existing", is_email_verified=True
        )
        OrganizationMembership.objects.create(
            user=existing_user, organization=other_org, level=OrganizationMembership.Level.MEMBER
        )

        # Try to provision same user via SCIM
        user_data = {
            "schemas": ["urn:ietf:params:scim:schemas:core:2.0:User"],
            "userName": "existing@example.com",
            "name": {"givenName": "Existing", "familyName": "User"},
            "emails": [{"value": "existing@example.com", "primary": True}],
            "active": True,
        }

        response = self.client.post(
            f"/scim/v2/{self.config.scim_slug}/Users", data=user_data, content_type="application/scim+json"
        )

        assert response.status_code == status.HTTP_201_CREATED

        # User should now be member of both orgs
        assert OrganizationMembership.objects.filter(user=existing_user, organization=self.organization).exists()
        assert OrganizationMembership.objects.filter(user=existing_user, organization=other_org).exists()

        # Verify SCIM provisioned user record was created for this domain
        scim_user = SCIMProvisionedUser.objects.get(user=existing_user, identity_provider_config=self.config)
        assert scim_user.active is True

    def test_repeated_post_returns_409_for_already_provisioned_user(self):
        user_data_first = {
            "schemas": ["urn:ietf:params:scim:schemas:core:2.0:User"],
            "userName": "repeat@example.com",
            "name": {"givenName": "First", "familyName": "Time"},
            "emails": [{"value": "repeat@example.com", "primary": True}],
            "active": True,
        }

        response = self.client.post(
            f"/scim/v2/{self.config.scim_slug}/Users", data=user_data_first, content_type="application/scim+json"
        )

        assert response.status_code == status.HTTP_201_CREATED
        first_user = User.objects.get(email="repeat@example.com")

        # IdP sends POST request again with same email - should fail with 409
        user_data_second = {
            "schemas": ["urn:ietf:params:scim:schemas:core:2.0:User"],
            "userName": "repeat@example.com",
            "name": {"givenName": "Second", "familyName": "Time"},
            "emails": [{"value": "repeat@example.com", "primary": True}],
            "active": True,
        }

        response = self.client.post(
            f"/scim/v2/{self.config.scim_slug}/Users", data=user_data_second, content_type="application/scim+json"
        )

        assert response.status_code == status.HTTP_409_CONFLICT

        # Should NOT create duplicate user
        assert User.objects.filter(email="repeat@example.com").count() == 1

        # User should NOT be updated (still has first POST data)
        first_user.refresh_from_db()
        assert first_user.first_name == "First"
        assert first_user.last_name == "Time"

        # User should have only one membership
        assert OrganizationMembership.objects.filter(user=first_user, organization=self.organization).count() == 1

    def test_linking_another_verified_domain_does_not_reprovision_users(self):
        # Provisioning records key on the config, so a config that starts backing a second verified
        # domain still recognizes the users it has already provisioned. Keying them on one of the
        # config's domains instead would let the pick move and provision everyone a second time.
        user_data = {
            "schemas": ["urn:ietf:params:scim:schemas:core:2.0:User"],
            "userName": "multidomain@example.com",
            "name": {"givenName": "Multi", "familyName": "Domain"},
            "emails": [{"value": "multidomain@example.com", "primary": True}],
            "active": True,
        }
        assert (
            self.client.post(
                f"/scim/v2/{self.config.scim_slug}/Users", data=user_data, content_type="application/scim+json"
            ).status_code
            == status.HTTP_201_CREATED
        )

        partner_domain = OrganizationDomain.objects.create(
            organization=self.organization,
            domain="partner.example.com",
            verified_at="2024-01-01T00:00:00Z",
        )
        LinkedIdentityProviderConfig.objects.create(
            organization_domain=partner_domain, identity_provider_config=self.config
        )

        response = self.client.post(
            f"/scim/v2/{self.config.scim_slug}/Users", data=user_data, content_type="application/scim+json"
        )

        assert response.status_code == status.HTTP_409_CONFLICT
        user = User.objects.get(email="multidomain@example.com")
        assert SCIMProvisionedUser.objects.filter(user=user, identity_provider_config=self.config).count() == 1

    def test_get_user(self):
        user = User.objects.create_user(
            email="test@example.com", password=None, first_name="Test", last_name="User", is_email_verified=True
        )
        OrganizationMembership.objects.create(
            user=user, organization=self.organization, level=OrganizationMembership.Level.MEMBER
        )
        role = self.organization.roles.create(name="Engineers")

        RoleMembership.objects.create(
            role=role,
            user=user,
            organization_member=OrganizationMembership.objects.get(user=user, organization=self.organization),
        )

        response = self.client.get(f"/scim/v2/{self.config.scim_slug}/Users/{user.id}")

        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert data["userName"] == "test@example.com"
        assert data["name"]["givenName"] == "Test"
        assert data["name"]["familyName"] == "User"
        assert data["active"] is True
        assert "groups" in data
        assert any(g.get("display") == "Engineers" for g in data["groups"])

    @parameterized.expand(
        [
            ("replace_without_path", {"op": "replace", "value": {"active": False}}),
            ("replace_with_path", {"op": "replace", "path": "active", "value": False}),
            ("add_with_path", {"op": "add", "path": "active", "value": False}),
            ("remove_with_path", {"op": "remove", "path": "active", "value": False}),
        ]
    )
    def test_deactivate_user(self, _name: str, operation: dict):
        user = User.objects.create_user(
            email="deactivate@example.com", password=None, first_name="Test", is_email_verified=True
        )
        OrganizationMembership.objects.create(
            user=user, organization=self.organization, level=OrganizationMembership.Level.MEMBER
        )
        # Create SCIM provisioned user record
        SCIMProvisionedUser.objects.create(
            user=user,
            identity_provider_config=self.config,
            username="deactivate@example.com",
            identity_provider=SCIMProvisionedUser.IdentityProvider.OTHER,
            active=True,
        )

        patch_data = {
            "schemas": ["urn:ietf:params:scim:api:messages:2.0:PatchOp"],
            "Operations": [operation],
        }

        response = self.client.patch(
            f"/scim/v2/{self.config.scim_slug}/Users/{user.id}", data=patch_data, content_type="application/scim+json"
        )

        assert response.status_code == status.HTTP_200_OK

        # Verify membership was removed
        assert not OrganizationMembership.objects.filter(user=user, organization=self.organization).exists()

        # User still exists
        user.refresh_from_db()
        assert user.is_active is True  # User is still active globally

        # Verify SCIM provisioned user record still exists but is marked inactive
        scim_user = SCIMProvisionedUser.objects.get(user=user, identity_provider_config=self.config)
        assert scim_user.active is False

    def test_delete_user(self):
        user = User.objects.create_user(
            email="delete@example.com", password=None, first_name="Delete", is_email_verified=True
        )
        OrganizationMembership.objects.create(
            user=user, organization=self.organization, level=OrganizationMembership.Level.MEMBER
        )
        # Create SCIM provisioned user record
        SCIMProvisionedUser.objects.create(
            user=user,
            identity_provider_config=self.config,
            username="delete@example.com",
            identity_provider=SCIMProvisionedUser.IdentityProvider.OTHER,
            active=True,
        )

        response = self.client.delete(f"/scim/v2/{self.config.scim_slug}/Users/{user.id}")

        assert response.status_code == status.HTTP_204_NO_CONTENT

        # Verify membership was removed
        assert not OrganizationMembership.objects.filter(user=user, organization=self.organization).exists()

        # Verify SCIM provisioned user record was deleted
        assert not SCIMProvisionedUser.objects.filter(user=user, identity_provider_config=self.config).exists()

    def test_put_user(self):
        user = User.objects.create_user(
            email="old@example.com", password=None, first_name="Old", last_name="Name", is_email_verified=True
        )
        OrganizationMembership.objects.create(
            user=user, organization=self.organization, level=OrganizationMembership.Level.MEMBER
        )
        # Create SCIM provisioned user record
        SCIMProvisionedUser.objects.create(
            user=user,
            identity_provider_config=self.config,
            username="old@example.com",
            identity_provider=SCIMProvisionedUser.IdentityProvider.OTHER,
            active=True,
        )

        put_data = {
            "schemas": ["urn:ietf:params:scim:schemas:core:2.0:User"],
            "userName": "put@example.com",
            "name": {"givenName": "Replaced", "familyName": "User"},
            "emails": [{"value": "put@example.com", "primary": True}],
            "active": True,
        }

        response = self.client.put(
            f"/scim/v2/{self.config.scim_slug}/Users/{user.id}", data=put_data, content_type="application/scim+json"
        )

        assert response.status_code == status.HTTP_200_OK
        user.refresh_from_db()
        assert user.first_name == "Replaced"
        assert user.last_name == "User"
        assert user.email == "put@example.com"

        # Verify SCIM provisioned user was updated
        scim_user = SCIMProvisionedUser.objects.get(user=user, identity_provider_config=self.config)
        assert scim_user.username == "put@example.com"
        assert scim_user.active is True

    def test_put_reactivate_user(self):
        user = User.objects.create_user(
            email="put_reactivate@example.com",
            password=None,
            first_name="Put",
            last_name="Reactivate",
            is_email_verified=True,
        )
        # Create then remove membership to simulate deactivated user
        OrganizationMembership.objects.create(
            user=user, organization=self.organization, level=OrganizationMembership.Level.MEMBER
        )
        SCIMProvisionedUser.objects.create(
            user=user,
            identity_provider_config=self.config,
            username="put_reactivate@example.com",
            identity_provider=SCIMProvisionedUser.IdentityProvider.OTHER,
            active=True,
        )
        # Deactivate
        OrganizationMembership.objects.filter(user=user, organization=self.organization).delete()
        SCIMProvisionedUser.objects.filter(user=user, identity_provider_config=self.config).update(active=False)
        assert not OrganizationMembership.objects.filter(user=user, organization=self.organization).exists()

        put_data = {
            "schemas": ["urn:ietf:params:scim:schemas:core:2.0:User"],
            "userName": "put_reactivate@example.com",
            "name": {"givenName": "Put", "familyName": "Reactivate"},
            "emails": [{"value": "put_reactivate@example.com", "primary": True}],
            "active": True,
        }

        response = self.client.put(
            f"/scim/v2/{self.config.scim_slug}/Users/{user.id}", data=put_data, content_type="application/scim+json"
        )

        assert response.status_code == status.HTTP_200_OK
        assert response.json()["active"] is True
        assert OrganizationMembership.objects.filter(user=user, organization=self.organization).exists()
        scim_user = SCIMProvisionedUser.objects.get(user=user, identity_provider_config=self.config)
        assert scim_user.active is True

    def test_put_user_not_found(self):
        put_data = {
            "schemas": ["urn:ietf:params:scim:schemas:core:2.0:User"],
            "userName": "nonexistent@example.com",
            "name": {"givenName": "Should", "familyName": "Fail"},
            "emails": [{"value": "nonexistent@example.com", "primary": True}],
            "active": True,
        }

        fake_user_id = 999999999
        response = self.client.put(
            f"/scim/v2/{self.config.scim_slug}/Users/{fake_user_id}",
            data=put_data,
            content_type="application/scim+json",
        )

        assert response.status_code == status.HTTP_404_NOT_FOUND, (
            f"Expected 404, got {response.status_code}: {response.content}"
        )
        assert not User.objects.filter(email="nonexistent@example.com").exists()

    def test_put_user_email_belongs_to_another_user(self):
        # Existing user A in org
        user_a = User.objects.create_user(
            email="alpha@example.com", password=None, first_name="Alpha", is_email_verified=True
        )
        OrganizationMembership.objects.create(
            user=user_a, organization=self.organization, level=OrganizationMembership.Level.MEMBER
        )

        # Existing user B in org
        user_b = User.objects.create_user(
            email="beta@example.com", password=None, first_name="Beta", is_email_verified=True
        )
        OrganizationMembership.objects.create(
            user=user_b, organization=self.organization, level=OrganizationMembership.Level.MEMBER
        )

        # IdP mismatches B and tries to PUT with A email
        put_data_conflict = {
            "schemas": ["urn:ietf:params:scim:schemas:core:2.0:User"],
            "userName": "alpha@example.com",
            "name": {"givenName": "Should", "familyName": "Fail"},
            "emails": [{"value": "alpha@example.com", "primary": True}],
            "active": True,
        }

        response = self.client.put(
            f"/scim/v2/{self.config.scim_slug}/Users/{user_b.id}",
            data=put_data_conflict,
            content_type="application/scim+json",
        )

        assert response.status_code == status.HTTP_400_BAD_REQUEST
        assert b"Invalid user data" in response.content

    def test_patch_user_not_found(self):
        patch_data = {
            "schemas": ["urn:ietf:params:scim:api:messages:2.0:PatchOp"],
            "Operations": [{"op": "replace", "value": {"name": {"givenName": "Should", "familyName": "Fail"}}}],
        }

        fake_user_id = 999999999
        response = self.client.patch(
            f"/scim/v2/{self.config.scim_slug}/Users/{fake_user_id}",
            data=patch_data,
            content_type="application/scim+json",
        )

        assert response.status_code == status.HTTP_404_NOT_FOUND, (
            f"Expected 404, got {response.status_code}: {response.content}"
        )

    def test_patch_replace_user_without_path(self):
        user = User.objects.create_user(
            email="old@example.com", password=None, first_name="Old", last_name="Name", is_email_verified=True
        )
        OrganizationMembership.objects.create(
            user=user, organization=self.organization, level=OrganizationMembership.Level.MEMBER
        )

        patch_data = {
            "schemas": ["urn:ietf:params:scim:api:messages:2.0:PatchOp"],
            "Operations": [
                {
                    "op": "replace",
                    "value": {
                        "name": {"givenName": "New", "familyName": "Name"},
                        "emails": [{"value": "new@example.com", "primary": True}],
                    },
                }
            ],
        }

        response = self.client.patch(
            f"/scim/v2/{self.config.scim_slug}/Users/{user.id}", data=patch_data, content_type="application/scim+json"
        )

        assert response.status_code == status.HTTP_200_OK
        user.refresh_from_db()
        assert user.first_name == "New"
        assert user.last_name == "Name"
        assert user.email == "new@example.com"

    def test_patch_replace_user_name_with_simple_path(self):
        user = User.objects.create_user(
            email="pathtest@example.com", password=None, first_name="Path", last_name="Test", is_email_verified=True
        )
        OrganizationMembership.objects.create(
            user=user, organization=self.organization, level=OrganizationMembership.Level.MEMBER
        )

        patch_data = {
            "schemas": ["urn:ietf:params:scim:api:messages:2.0:PatchOp"],
            "Operations": [
                {"op": "replace", "path": "name", "value": {"givenName": "NewFirst", "familyName": "NewLast"}}
            ],
        }

        response = self.client.patch(
            f"/scim/v2/{self.config.scim_slug}/Users/{user.id}", data=patch_data, content_type="application/scim+json"
        )

        assert response.status_code == status.HTTP_200_OK
        user.refresh_from_db()
        assert user.first_name == "NewFirst"
        assert user.last_name == "NewLast"

    def test_patch_replace_user_emails_with_simple_path(self):
        user = User.objects.create_user(
            email="array@example.com", password=None, first_name="Array", last_name="Test", is_email_verified=True
        )
        OrganizationMembership.objects.create(
            user=user, organization=self.organization, level=OrganizationMembership.Level.MEMBER
        )

        patch_data = {
            "schemas": ["urn:ietf:params:scim:api:messages:2.0:PatchOp"],
            "Operations": [
                {
                    "op": "replace",
                    "path": "emails",
                    "value": [{"value": "newarray@example.com", "primary": True}],
                }
            ],
        }

        response = self.client.patch(
            f"/scim/v2/{self.config.scim_slug}/Users/{user.id}", data=patch_data, content_type="application/scim+json"
        )

        assert response.status_code == status.HTTP_200_OK
        user.refresh_from_db()
        assert user.email == "newarray@example.com"

    def test_patch_replace_user_given_name_with_dotted_path(self):
        user = User.objects.create_user(
            email="dotpath@example.com", password=None, first_name="Dot", last_name="Path", is_email_verified=True
        )
        OrganizationMembership.objects.create(
            user=user, organization=self.organization, level=OrganizationMembership.Level.MEMBER
        )

        patch_data = {
            "schemas": ["urn:ietf:params:scim:api:messages:2.0:PatchOp"],
            "Operations": [{"op": "replace", "path": "name.givenName", "value": "UpdatedFirst"}],
        }

        response = self.client.patch(
            f"/scim/v2/{self.config.scim_slug}/Users/{user.id}", data=patch_data, content_type="application/scim+json"
        )

        assert response.status_code == status.HTTP_200_OK
        user.refresh_from_db()
        assert user.first_name == "UpdatedFirst"
        assert user.last_name == "Path"

    def test_patch_replace_user_email_with_filtered_path(self):
        user = User.objects.create_user(
            email="primary@example.com", password=None, first_name="Primary", last_name="Email", is_email_verified=True
        )
        OrganizationMembership.objects.create(
            user=user, organization=self.organization, level=OrganizationMembership.Level.MEMBER
        )

        patch_data = {
            "schemas": ["urn:ietf:params:scim:api:messages:2.0:PatchOp"],
            "Operations": [
                {"op": "replace", "path": "emails[primary eq true].value", "value": "primaryemail@example.com"}
            ],
        }

        response = self.client.patch(
            f"/scim/v2/{self.config.scim_slug}/Users/{user.id}", data=patch_data, content_type="application/scim+json"
        )

        assert response.status_code == status.HTTP_200_OK
        user.refresh_from_db()
        assert user.email == "primaryemail@example.com"

    def test_patch_add_user_without_path(self):
        user = User.objects.create_user(
            email="testuser@example.com", password=None, first_name="", last_name="", is_email_verified=True
        )
        SCIMProvisionedUser.objects.create(
            user=user,
            identity_provider_config=self.config,
            username="testuser@example.com",
            identity_provider=SCIMProvisionedUser.IdentityProvider.OTHER,
            active=False,
        )

        patch_data = {
            "schemas": ["urn:ietf:params:scim:api:messages:2.0:PatchOp"],
            "Operations": [
                {
                    "op": "add",
                    "value": {
                        "name": {"givenName": "New", "familyName": "User"},
                        "emails": [{"value": "newuser@example.com", "primary": True}],
                        "active": True,
                    },
                }
            ],
        }

        response = self.client.patch(
            f"/scim/v2/{self.config.scim_slug}/Users/{user.id}", data=patch_data, content_type="application/scim+json"
        )

        assert response.status_code == status.HTTP_200_OK
        user.refresh_from_db()
        assert user.first_name == "New"
        assert user.last_name == "User"
        assert user.email == "newuser@example.com"
        assert OrganizationMembership.objects.filter(user=user, organization=self.organization).exists()

    def test_patch_add_user_name_with_simple_path(self):
        user = User.objects.create_user(
            email="old@example.com", password=None, first_name="Old", last_name="Name", is_email_verified=True
        )
        OrganizationMembership.objects.create(
            user=user, organization=self.organization, level=OrganizationMembership.Level.MEMBER
        )

        patch_data = {
            "schemas": ["urn:ietf:params:scim:api:messages:2.0:PatchOp"],
            "Operations": [{"op": "add", "path": "name", "value": {"givenName": "New", "familyName": "Name"}}],
        }

        response = self.client.patch(
            f"/scim/v2/{self.config.scim_slug}/Users/{user.id}", data=patch_data, content_type="application/scim+json"
        )

        assert response.status_code == status.HTTP_200_OK
        user.refresh_from_db()
        assert user.first_name == "New"
        assert user.last_name == "Name"

    def test_patch_add_active_user_with_simple_path(self):
        user = User.objects.create_user(
            email="reactivate@example.com", password=None, first_name="Test", is_email_verified=True
        )
        SCIMProvisionedUser.objects.create(
            user=user,
            identity_provider_config=self.config,
            username="reactivate@example.com",
            identity_provider=SCIMProvisionedUser.IdentityProvider.OTHER,
            active=False,
        )
        assert not OrganizationMembership.objects.filter(user=user, organization=self.organization).exists()

        patch_data = {
            "schemas": ["urn:ietf:params:scim:api:messages:2.0:PatchOp"],
            "Operations": [{"op": "add", "path": "active", "value": True}],
        }

        response = self.client.patch(
            f"/scim/v2/{self.config.scim_slug}/Users/{user.id}", data=patch_data, content_type="application/scim+json"
        )

        assert response.status_code == status.HTTP_200_OK
        assert OrganizationMembership.objects.filter(user=user, organization=self.organization).exists()

    def test_patch_replace_reactivate_user(self):
        user = User.objects.create_user(
            email="reactivate_replace@example.com", password=None, first_name="Test", is_email_verified=True
        )
        # Create then remove membership to simulate deactivated user
        OrganizationMembership.objects.create(
            user=user, organization=self.organization, level=OrganizationMembership.Level.MEMBER
        )
        SCIMProvisionedUser.objects.create(
            user=user,
            identity_provider_config=self.config,
            username="reactivate_replace@example.com",
            identity_provider=SCIMProvisionedUser.IdentityProvider.OTHER,
            active=True,
        )
        # Deactivate
        OrganizationMembership.objects.filter(user=user, organization=self.organization).delete()
        SCIMProvisionedUser.objects.filter(user=user, identity_provider_config=self.config).update(active=False)
        assert not OrganizationMembership.objects.filter(user=user, organization=self.organization).exists()

        patch_data = {
            "schemas": ["urn:ietf:params:scim:api:messages:2.0:PatchOp"],
            "Operations": [{"op": "replace", "path": "active", "value": True}],
        }

        response = self.client.patch(
            f"/scim/v2/{self.config.scim_slug}/Users/{user.id}", data=patch_data, content_type="application/scim+json"
        )

        assert response.status_code == status.HTTP_200_OK
        assert response.json()["active"] is True
        assert OrganizationMembership.objects.filter(user=user, organization=self.organization).exists()
        scim_user = SCIMProvisionedUser.objects.get(user=user, identity_provider_config=self.config)
        assert scim_user.active is True

    def test_patch_add_user_given_name_with_dotted_path(self):
        user = User.objects.create_user(
            email="addsubattr@example.com", password=None, first_name="", last_name="Existing", is_email_verified=True
        )
        OrganizationMembership.objects.create(
            user=user, organization=self.organization, level=OrganizationMembership.Level.MEMBER
        )

        patch_data = {
            "schemas": ["urn:ietf:params:scim:api:messages:2.0:PatchOp"],
            "Operations": [{"op": "add", "path": "name.givenName", "value": "Ada"}],
        }

        response = self.client.patch(
            f"/scim/v2/{self.config.scim_slug}/Users/{user.id}", data=patch_data, content_type="application/scim+json"
        )

        assert response.status_code == status.HTTP_200_OK
        user.refresh_from_db()
        assert user.first_name == "Ada"
        assert user.last_name == "Existing"

    def test_patch_add_user_email_with_filtered_path(self):
        user = User.objects.create_user(
            email="old@example.com", password=None, first_name="Test", is_email_verified=True
        )
        OrganizationMembership.objects.create(
            user=user, organization=self.organization, level=OrganizationMembership.Level.MEMBER
        )

        patch_data = {
            "schemas": ["urn:ietf:params:scim:api:messages:2.0:PatchOp"],
            "Operations": [{"op": "add", "path": "emails[primary eq true].value", "value": "primary@example.com"}],
        }

        response = self.client.patch(
            f"/scim/v2/{self.config.scim_slug}/Users/{user.id}", data=patch_data, content_type="application/scim+json"
        )

        assert response.status_code == status.HTTP_200_OK
        user.refresh_from_db()
        assert user.email == "primary@example.com"

    @parameterized.expand([("replace",), ("add",)])
    def test_patch_user_name_updates_scim_record(self, op: str):
        user = User.objects.create_user(
            email="rename@example.com", password=None, first_name="Test", is_email_verified=True
        )
        OrganizationMembership.objects.create(
            user=user, organization=self.organization, level=OrganizationMembership.Level.MEMBER
        )
        SCIMProvisionedUser.objects.create(
            user=user,
            identity_provider_config=self.config,
            username="old-username@example.com",
            identity_provider=SCIMProvisionedUser.IdentityProvider.OKTA,
            active=True,
        )

        patch_data = {
            "schemas": ["urn:ietf:params:scim:api:messages:2.0:PatchOp"],
            "Operations": [{"op": op, "path": "userName", "value": "new-username@example.com"}],
        }

        response = self.client.patch(
            f"/scim/v2/{self.config.scim_slug}/Users/{user.id}", data=patch_data, content_type="application/scim+json"
        )

        assert response.status_code == status.HTTP_200_OK
        assert response.json()["userName"] == "new-username@example.com"
        scim_user = SCIMProvisionedUser.objects.get(user=user, identity_provider_config=self.config)
        assert scim_user.username == "new-username@example.com"
        # The upsert must not reset which provider owns the record
        assert scim_user.identity_provider == SCIMProvisionedUser.IdentityProvider.OKTA

    @parameterized.expand(
        [
            ("unmapped_attribute", "nickName", "Nick"),
            ("unmapped_sub_attribute", "name.middleName", "Middle"),
        ]
    )
    def test_patch_ignores_attributes_we_do_not_support(self, _name: str, path: str, value: str):
        # Identity providers send attributes we do not store. Rejecting them fails the whole sync.
        user = User.objects.create_user(
            email="extra@example.com", password=None, first_name="Test", last_name="User", is_email_verified=True
        )
        OrganizationMembership.objects.create(
            user=user, organization=self.organization, level=OrganizationMembership.Level.MEMBER
        )

        patch_data = {
            "schemas": ["urn:ietf:params:scim:api:messages:2.0:PatchOp"],
            "Operations": [{"op": "replace", "path": path, "value": value}],
        }

        response = self.client.patch(
            f"/scim/v2/{self.config.scim_slug}/Users/{user.id}", data=patch_data, content_type="application/scim+json"
        )

        assert response.status_code == status.HTTP_200_OK
        user.refresh_from_db()
        assert user.first_name == "Test"
        assert user.last_name == "User"

    def test_patch_remove_user_family_name_with_simple_path(self):
        user = User.objects.create_user(
            email="removesimple@example.com",
            password=None,
            first_name="Simple",
            last_name="Fam",
            is_email_verified=True,
        )
        OrganizationMembership.objects.create(
            user=user, organization=self.organization, level=OrganizationMembership.Level.MEMBER
        )

        patch_data = {
            "schemas": ["urn:ietf:params:scim:api:messages:2.0:PatchOp"],
            "Operations": [{"op": "remove", "path": "name.familyName"}],
        }

        response = self.client.patch(
            f"/scim/v2/{self.config.scim_slug}/Users/{user.id}", data=patch_data, content_type="application/scim+json"
        )

        assert response.status_code == status.HTTP_200_OK
        user.refresh_from_db()
        assert user.first_name == "Simple"
        assert user.last_name == ""

    def test_patch_remove_user_family_name_with_dotted_path(self):
        user = User.objects.create_user(
            email="removename@example.com", password=None, first_name="Remove", last_name="Me", is_email_verified=True
        )
        OrganizationMembership.objects.create(
            user=user, organization=self.organization, level=OrganizationMembership.Level.MEMBER
        )

        patch_data = {
            "schemas": ["urn:ietf:params:scim:api:messages:2.0:PatchOp"],
            "Operations": [{"op": "remove", "path": "name.familyName"}],
        }

        response = self.client.patch(
            f"/scim/v2/{self.config.scim_slug}/Users/{user.id}", data=patch_data, content_type="application/scim+json"
        )

        assert response.status_code == status.HTTP_200_OK
        user.refresh_from_db()
        assert user.first_name == "Remove"
        assert user.last_name == ""

    def test_patch_remove_user_emails_should_fail(self):
        user = User.objects.create_user(
            email="email@example.com", password=None, first_name="Test", is_email_verified=True
        )
        OrganizationMembership.objects.create(
            user=user, organization=self.organization, level=OrganizationMembership.Level.MEMBER
        )

        patch_data = {
            "schemas": ["urn:ietf:params:scim:api:messages:2.0:PatchOp"],
            "Operations": [{"op": "remove", "path": "emails"}],
        }

        response = self.client.patch(
            f"/scim/v2/{self.config.scim_slug}/Users/{user.id}", data=patch_data, content_type="application/scim+json"
        )

        assert response.status_code == status.HTTP_400_BAD_REQUEST
        user.refresh_from_db()
        assert user.email == "email@example.com"

    def test_patch_remove_user_email_with_filtered_path_should_fail(self):
        user = User.objects.create_user(
            email="primary@example.com", password=None, first_name="Test", is_email_verified=True
        )
        OrganizationMembership.objects.create(
            user=user, organization=self.organization, level=OrganizationMembership.Level.MEMBER
        )

        patch_data = {
            "schemas": ["urn:ietf:params:scim:api:messages:2.0:PatchOp"],
            "Operations": [{"op": "remove", "path": "emails[primary eq true].value"}],
        }

        response = self.client.patch(
            f"/scim/v2/{self.config.scim_slug}/Users/{user.id}", data=patch_data, content_type="application/scim+json"
        )

        assert response.status_code == status.HTTP_400_BAD_REQUEST
        user.refresh_from_db()
        assert user.email == "primary@example.com"

    # ── Pagination tests ──

    def _create_users(self, count: int) -> list[User]:
        users = []
        for i in range(count):
            user = User.objects.create_user(
                email=f"paguser{i}@example.com",
                password=None,
                first_name=f"PagUser{i}",
                is_email_verified=True,
            )
            OrganizationMembership.objects.create(
                user=user, organization=self.organization, level=OrganizationMembership.Level.MEMBER
            )
            users.append(user)
        return users

    def test_users_list_pagination_with_count(self):
        self._create_users(5)

        response = self.client.get(f"/scim/v2/{self.config.scim_slug}/Users", {"count": "2"})

        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert data["totalResults"] == 6  # 5 created + setUp user
        assert data["itemsPerPage"] == 2
        assert data["startIndex"] == 1
        assert len(data["Resources"]) == 2

    def test_users_list_pagination_with_start_index(self):
        self._create_users(5)

        response = self.client.get(f"/scim/v2/{self.config.scim_slug}/Users", {"startIndex": "3", "count": "2"})

        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert data["totalResults"] == 6
        assert data["itemsPerPage"] == 2
        assert data["startIndex"] == 3
        assert len(data["Resources"]) == 2

    def test_users_list_pagination_count_zero(self):
        self._create_users(3)

        response = self.client.get(f"/scim/v2/{self.config.scim_slug}/Users", {"count": "0"})

        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert data["totalResults"] == 4  # 3 created + setUp user
        assert data["itemsPerPage"] == 0
        assert data["Resources"] == []

    def test_users_list_pagination_start_index_beyond_total(self):
        response = self.client.get(f"/scim/v2/{self.config.scim_slug}/Users", {"startIndex": "999"})

        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert data["totalResults"] >= 1
        assert data["itemsPerPage"] == 0
        assert data["Resources"] == []
        assert data["startIndex"] == 999

    def test_users_list_pagination_count_capped_at_max(self):
        response = self.client.get(f"/scim/v2/{self.config.scim_slug}/Users", {"count": "500"})

        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert data["itemsPerPage"] <= MAX_ITEMS_PER_PAGE

    @parameterized.expand(
        [
            ("start_index_zero", {"startIndex": "0"}, status.HTTP_400_BAD_REQUEST),
            ("start_index_negative", {"startIndex": "-1"}, status.HTTP_400_BAD_REQUEST),
            ("start_index_non_integer", {"startIndex": "abc"}, status.HTTP_400_BAD_REQUEST),
            ("count_negative", {"count": "-1"}, status.HTTP_400_BAD_REQUEST),
            ("count_non_integer", {"count": "abc"}, status.HTTP_400_BAD_REQUEST),
        ]
    )
    def test_users_list_pagination_invalid_values(self, _name: str, params: dict, expected_status: int):
        response = self.client.get(f"/scim/v2/{self.config.scim_slug}/Users", params)
        assert response.status_code == expected_status

    def test_users_list_pagination_with_filter(self):
        self._create_users(3)
        for i in range(3):
            SCIMProvisionedUser.objects.create(
                user=User.objects.get(email=f"paguser{i}@example.com"),
                identity_provider_config=self.config,
                username=f"paguser{i}@example.com",
                identity_provider=SCIMProvisionedUser.IdentityProvider.OTHER,
                active=True,
            )

        response = self.client.get(
            f"/scim/v2/{self.config.scim_slug}/Users",
            {"filter": 'userName eq "paguser0@example.com"', "count": "1"},
        )

        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert data["totalResults"] == 1
        assert data["itemsPerPage"] == 1
        assert data["Resources"][0]["userName"] == "paguser0@example.com"

    def test_users_list_pagination_page_through_all(self):
        self._create_users(5)
        total = 6  # 5 created + setUp user

        all_ids: list[str] = []
        start_index = 1
        page_size = 2
        while True:
            response = self.client.get(
                f"/scim/v2/{self.config.scim_slug}/Users",
                {"startIndex": str(start_index), "count": str(page_size)},
            )
            assert response.status_code == status.HTTP_200_OK
            data = response.json()
            assert data["totalResults"] == total
            if not data["Resources"]:
                break
            all_ids.extend(r["id"] for r in data["Resources"])
            start_index += len(data["Resources"])

        assert len(all_ids) == total
        assert len(set(all_ids)) == total

    def test_patch_replace_email_with_multi_at_domain_is_rejected(self):
        # A multi-"@" address whose second segment is a verified domain must not pass the
        # domain-ownership guard: the real delivery domain is the final segment.
        user = User.objects.create_user(
            email="multiat@example.com", password=None, first_name="Multi", is_email_verified=True
        )
        OrganizationMembership.objects.create(
            user=user, organization=self.organization, level=OrganizationMembership.Level.MEMBER
        )
        SCIMProvisionedUser.objects.create(
            user=user,
            identity_provider_config=self.config,
            username="multiat@example.com",
            identity_provider=SCIMProvisionedUser.IdentityProvider.OTHER,
            active=True,
        )

        patch_data = {
            "schemas": ["urn:ietf:params:scim:api:messages:2.0:PatchOp"],
            "Operations": [
                {
                    "op": "replace",
                    "path": "emails",
                    "value": [{"value": "attacker@example.com@evil.com", "primary": True}],
                }
            ],
        }

        response = self.client.patch(
            f"/scim/v2/{self.config.scim_slug}/Users/{user.id}", data=patch_data, content_type="application/scim+json"
        )

        assert response.status_code == status.HTTP_400_BAD_REQUEST
        user.refresh_from_db()
        assert user.email == "multiat@example.com"

    def test_patch_replace_email_case_collision_rejected(self):
        # A case-variant of an existing account's email collides at login time (email__iexact),
        # so SCIM must reject it even though the unique index is case-sensitive.
        user_a = User.objects.create_user(
            email="existing@example.com", password=None, first_name="A", is_email_verified=True
        )
        OrganizationMembership.objects.create(
            user=user_a, organization=self.organization, level=OrganizationMembership.Level.MEMBER
        )
        user_b = User.objects.create_user(
            email="userb@example.com", password=None, first_name="B", is_email_verified=True
        )
        OrganizationMembership.objects.create(
            user=user_b, organization=self.organization, level=OrganizationMembership.Level.MEMBER
        )
        SCIMProvisionedUser.objects.create(
            user=user_b,
            identity_provider_config=self.config,
            username="userb@example.com",
            identity_provider=SCIMProvisionedUser.IdentityProvider.OTHER,
            active=True,
        )

        patch_data = {
            "schemas": ["urn:ietf:params:scim:api:messages:2.0:PatchOp"],
            "Operations": [
                {
                    "op": "replace",
                    "path": "emails",
                    "value": [{"value": "EXISTING@example.com", "primary": True}],
                }
            ],
        }

        response = self.client.patch(
            f"/scim/v2/{self.config.scim_slug}/Users/{user_b.id}", data=patch_data, content_type="application/scim+json"
        )

        assert response.status_code == status.HTTP_400_BAD_REQUEST
        user_b.refresh_from_db()
        assert user_b.email == "userb@example.com"

    def test_deactivate_owner_is_blocked(self):
        # Deprovisioning must run the canonical User.leave path, which protects an
        # organization from being left without an owner.
        owner = User.objects.create_user(
            email="owner2@example.com", password=None, first_name="Owner", is_email_verified=True
        )
        OrganizationMembership.objects.create(
            user=owner, organization=self.organization, level=OrganizationMembership.Level.OWNER
        )
        SCIMProvisionedUser.objects.create(
            user=owner,
            identity_provider_config=self.config,
            username="owner2@example.com",
            identity_provider=SCIMProvisionedUser.IdentityProvider.OTHER,
            active=True,
        )

        patch_data = {
            "schemas": ["urn:ietf:params:scim:api:messages:2.0:PatchOp"],
            "Operations": [{"op": "replace", "value": {"active": False}}],
        }

        response = self.client.patch(
            f"/scim/v2/{self.config.scim_slug}/Users/{owner.id}", data=patch_data, content_type="application/scim+json"
        )

        assert response.status_code == status.HTTP_400_BAD_REQUEST
        assert OrganizationMembership.objects.filter(
            user=owner, organization=self.organization, level=OrganizationMembership.Level.OWNER
        ).exists()
