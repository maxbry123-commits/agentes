from parameterized import parameterized

from ee.api.scim.utils import (
    mask_email,
    mask_headers,
    mask_pii_value,
    mask_scim_filter,
    mask_scim_payload,
    mask_string,
    normalize_scim_operations,
)


class TestMaskString:
    @parameterized.expand(
        [
            ("John", "J***n"),
            ("A", "*"),
            ("AB", "**"),
            ("ABC", "A***C"),
            ("hello", "h***o"),
        ]
    )
    def test_mask_string(self, input_value, expected):
        assert mask_string(input_value) == expected


class TestMaskEmail:
    @parameterized.expand(
        [
            ("john.doe@example.com", "j***e@example.com"),
            ("a@b.co", "*@b.co"),
            ("ab@domain.org", "**@domain.org"),
            ("test@domain.org", "t***t@domain.org"),
            ("no-at-sign", "n***n"),
        ]
    )
    def test_mask_email(self, input_value, expected):
        assert mask_email(input_value) == expected


class TestMaskPiiValue:
    @parameterized.expand(
        [
            ("john@example.com", "j***n@example.com"),
            ("John", "J***n"),
            ("", ""),
            (None, None),
            (123, 123),
            (True, True),
        ]
    )
    def test_mask_pii_value(self, input_value, expected):
        assert mask_pii_value(input_value) == expected


class TestMaskScimPayload:
    def test_masks_user_create_payload(self):
        payload = {
            "schemas": ["urn:ietf:params:scim:schemas:core:2.0:User"],
            "userName": "john.doe@example.com",
            "name": {"givenName": "John", "familyName": "Doe"},
            "emails": [{"value": "john.doe@example.com", "primary": True}],
            "active": True,
        }

        assert mask_scim_payload(payload) == {
            "schemas": ["urn:ietf:params:scim:schemas:core:2.0:User"],
            "userName": "j***e@example.com",
            "name": {"givenName": "J***n", "familyName": "D***e"},
            "emails": [{"value": "j***e@example.com", "primary": True}],
            "active": True,
        }

    def test_masks_patch_operations(self):
        payload = {
            "schemas": ["urn:ietf:params:scim:api:messages:2.0:PatchOp"],
            "Operations": [
                {"op": "replace", "path": "userName", "value": "new.email@example.com"},
                {"op": "replace", "path": "active", "value": False},
                {"op": "replace", "path": "name", "value": {"givenName": "Jane", "familyName": "Smith"}},
            ],
        }

        assert mask_scim_payload(payload) == {
            "schemas": ["urn:ietf:params:scim:api:messages:2.0:PatchOp"],
            "Operations": [
                {"op": "replace", "path": "userName", "value": "n***l@example.com"},
                {"op": "replace", "path": "active", "value": False},
                {"op": "replace", "path": "name", "value": {"givenName": "J***e", "familyName": "S***h"}},
            ],
        }

    def test_masks_group_with_members(self):
        payload = {
            "schemas": ["urn:ietf:params:scim:schemas:core:2.0:Group"],
            "displayName": "Engineering Team",
            "members": [
                {"value": "user-123", "display": "john.doe@example.com"},
                {"value": "user-456", "display": "jane.smith@example.com"},
            ],
        }

        assert mask_scim_payload(payload) == {
            "schemas": ["urn:ietf:params:scim:schemas:core:2.0:Group"],
            "displayName": "E***m",
            "members": [
                {"value": "u***3", "display": "j***e@example.com"},
                {"value": "u***6", "display": "j***h@example.com"},
            ],
        }

    def test_preserves_non_pii_fields(self):
        payload = {
            "schemas": ["urn:ietf:params:scim:schemas:core:2.0:User"],
            "id": "12345",
            "externalId": "ext-123",
            "meta": {"resourceType": "User", "created": "2024-01-01T00:00:00Z"},
        }

        assert mask_scim_payload(payload) == payload

    def test_handles_empty_payload(self):
        assert mask_scim_payload({}) == {}
        assert mask_scim_payload([]) == []
        assert mask_scim_payload(None) is None


class TestMaskScimFilter:
    @parameterized.expand(
        [
            ('userName eq "alex@posthog.com"', 'userName eq "a***x@posthog.com"'),
            ('emails.value eq "test@example.com"', 'emails.value eq "t***t@example.com"'),
            ('displayName eq "John Doe"', 'displayName eq "J***e"'),
            ('userName eq "a@b.com"', 'userName eq "*@b.com"'),
            ("active eq true", "active eq true"),
            ('userName eq "test@x.com" and active eq true', 'userName eq "t***t@x.com" and active eq true'),
            # escaped quotes and backslashes
            (r'displayName eq "John \"The Man\" Doe"', r'displayName eq "J***e"'),
            (r'displayName eq "path\\to\\file"', r'displayName eq "p***e"'),
        ]
    )
    def test_mask_scim_filter(self, input_value, expected):
        assert mask_scim_filter(input_value) == expected


class TestNormalizeScimOperations:
    @parameterized.expand(
        [
            # String "True"/"False" to boolean when path is "active"
            (
                [{"op": "replace", "path": "active", "value": "True"}],
                [{"op": "replace", "path": "active", "value": True}],
            ),
            (
                [{"op": "replace", "path": "active", "value": "true"}],
                [{"op": "replace", "path": "active", "value": True}],
            ),
            (
                [{"op": "replace", "path": "active", "value": "FALSE"}],
                [{"op": "replace", "path": "active", "value": False}],
            ),
            (
                [{"op": "replace", "path": "active", "value": "false"}],
                [{"op": "replace", "path": "active", "value": False}],
            ),
            ([{"op": "add", "path": "active", "value": "True"}], [{"op": "add", "path": "active", "value": True}]),
            # String in nested value dict
            ([{"op": "replace", "value": {"active": "True"}}], [{"op": "replace", "value": {"active": True}}]),
            (
                [{"op": "replace", "value": {"active": "false", "name": "Test"}}],
                [{"op": "replace", "value": {"active": False, "name": "Test"}}],
            ),
            # Boolean values pass through unchanged
            (
                [{"op": "replace", "path": "active", "value": True}],
                [{"op": "replace", "path": "active", "value": True}],
            ),
            (
                [{"op": "replace", "path": "active", "value": False}],
                [{"op": "replace", "path": "active", "value": False}],
            ),
            ([{"op": "replace", "value": {"active": True}}], [{"op": "replace", "value": {"active": True}}]),
            # Non-active operations pass through unchanged
            (
                [{"op": "replace", "path": "userName", "value": "test@example.com"}],
                [{"op": "replace", "path": "userName", "value": "test@example.com"}],
            ),
            (
                [{"op": "replace", "path": "name.givenName", "value": "John"}],
                [{"op": "replace", "path": "name.givenName", "value": "John"}],
            ),
            # Empty operations list
            ([], []),
        ]
    )
    def test_normalize_scim_operations(self, input_ops, expected_ops):
        assert normalize_scim_operations(input_ops) == expected_ops

    def test_does_not_mutate_original_operations(self):
        original: list[dict] = [{"op": "replace", "value": {"active": "True"}}]
        normalize_scim_operations(original)
        assert original[0]["value"]["active"] == "True"


class TestMaskHeaders:
    @parameterized.expand(
        [
            ("bearer_token", {"Authorization": "Bearer phx_abc123def456"}, {"Authorization": "***"}),
            ("basic_auth", {"Authorization": "Basic dXNlcjpwYXNz"}, {"Authorization": "***"}),
            ("short_token", {"Authorization": "Bearer ab"}, {"Authorization": "***"}),
            ("cookie_stripped", {"Cookie": "session=abc123"}, {}),
            ("set_cookie_stripped", {"Set-Cookie": "session=abc123"}, {}),
            (
                "safe_header_passthrough",
                {"Content-Type": "application/json", "User-Agent": "Okta"},
                {"Content-Type": "application/json", "User-Agent": "Okta"},
            ),
            (
                "mixed",
                {"Authorization": "Bearer tok123", "Cookie": "x=1", "Accept": "application/json"},
                {"Authorization": "***", "Accept": "application/json"},
            ),
            ("empty", {}, {}),
            (
                "case_insensitive",
                {"AUTHORIZATION": "Bearer tok123", "COOKIE": "x=1"},
                {"AUTHORIZATION": "***"},
            ),
        ]
    )
    def test_mask_headers(self, _name, input_headers, expected):
        assert mask_headers(input_headers) == expected
