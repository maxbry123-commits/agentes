import logging
from typing import Union, cast

from django.db import transaction
from django.db.models import QuerySet

from django_scim import constants
from django_scim.adapters import SCIMGroup
from scim2_filter_parser.attr_paths import AttrPath

from posthog.models import OrganizationMembership, User
from posthog.models.identity_provider_config import IdentityProviderConfig

from products.access_control.backend.models.role import Role, RoleMembership

logger = logging.getLogger(__name__)


class PostHogSCIMGroup(SCIMGroup):
    """
    Adapter to map SCIM Group schema to PostHog RBAC Role model.
    SCIM Groups are mapped to PostHog Roles for organization-level permissions.
    """

    resource_type = "Group"

    # Attribute map for SCIM PATCH operation path parsing
    # Maps SCIM attribute paths to SCIM JSON paths for PATCH operations
    # NOT for database filtering - see SCIM_GROUP_ATTR_MAP in views.py for that
    # Each key is a tuple of (attribute, sub-attribute, schema URI)
    ATTR_MAP = {
        ("displayName", None, None): "displayName",
        ("members", None, None): "members",
        ("members", "value", None): "members.value",
        ("members", "display", None): "members.display",
    }

    @property
    def id(self) -> str:
        return str(self.obj.id)

    @property
    def display_name(self) -> str:
        return self.obj.name

    @property
    def members(self) -> list[dict]:
        """
        Return list of group members in SCIM format.
        """
        role_memberships = RoleMembership.objects.filter(role=self.obj).select_related("user")
        return [
            {
                "value": str(rm.user.id),
                "$ref": f"/scim/v2/{self._config.scim_slug}/Users/{rm.user.id}",
                "display": rm.user.email,
            }
            for rm in role_memberships
        ]

    def __init__(self, obj: Role, config: IdentityProviderConfig):
        super().__init__(obj)
        self._config = config

    @classmethod
    def resource_type_dict(cls, request=None) -> dict:
        return {
            "id": cls.resource_type,
            "name": cls.resource_type,
            "endpoint": f"/scim/v2/{request.auth.scim_slug if request and request.auth else '{scim_slug}'}/Groups",
            "schema": constants.SchemaURI.GROUP,
        }

    def to_dict(self) -> dict:
        """
        Convert Role to SCIM Group format.
        """
        return {
            "schemas": [constants.SchemaURI.GROUP],
            "id": self.id,
            "displayName": self.display_name,
            "members": self.members,
            "meta": {
                "resourceType": self.resource_type,
                "location": f"/scim/v2/{self._config.scim_slug}/Groups/{self.id}",
            },
        }

    @classmethod
    def from_dict(cls, data: dict, config: IdentityProviderConfig) -> "PostHogSCIMGroup":
        """
        Create or update a Role from SCIM Group data.
        Upserts role by name matching.
        """
        display_name = data.get("displayName")
        if not display_name:
            raise ValueError("displayName is required for groups")

        with transaction.atomic():
            # Upsert role by name
            role, created = Role.objects.get_or_create(
                name=display_name,
                organization=config.organization,
                defaults={"created_by": None},
            )

            # Handle member updates if provided
            if "members" in data:
                cls._update_members(role, data["members"], config)

        return cls(role, config)

    @staticmethod
    def _parse_member_id(raw_member_id) -> str | None:
        """
        Normalize a SCIM `members[].value` to the string form of an integer ID,
        matching the always-string `current_user_ids` set in `_update_members`.

        Some IdPs send `value` as a JSON number; without this, the set diff
        would be type-asymmetric and silently delete the membership the IdP
        asked to keep. Non-coercible values (e.g. nested-group UUIDs from
        Entra ID) return None and are logged once.
        """
        if raw_member_id is None:
            return None
        try:
            return str(int(raw_member_id))
        except (TypeError, ValueError):
            logger.warning("scim_group_skip_invalid_member_id", extra={"member_value": raw_member_id})
            return None

    @staticmethod
    def _assign_role_member(role: Role, user_pk: int, config: IdentityProviderConfig) -> None:
        try:
            user = User.objects.get(id=user_pk)
        except User.DoesNotExist:
            return

        org_membership = OrganizationMembership.objects.filter(user=user, organization=config.organization).first()
        if not org_membership:
            return

        # nosemgrep: idor-lookup-without-org (SCIM bearer token auth, org gated by middleware)
        RoleMembership.objects.get_or_create(role=role, user=user, defaults={"organization_member": org_membership})

    @classmethod
    def _update_members(cls, role: Role, members_data: list[dict], config: IdentityProviderConfig) -> None:
        """
        Update role membership based on SCIM members list.
        """
        member_user_ids: set[str] = set()
        for member in members_data:
            parsed = cls._parse_member_id(member.get("value"))
            if parsed is not None:
                member_user_ids.add(parsed)

        current_memberships = RoleMembership.objects.filter(role=role).select_related("user", "organization_member")
        current_user_ids = {str(rm.user.id) for rm in current_memberships}
        to_add = member_user_ids - current_user_ids
        to_remove = current_user_ids - member_user_ids

        for raw_member_id in to_add:
            cls._assign_role_member(role, int(raw_member_id), config)

        RoleMembership.objects.filter(role=role, user__id__in=to_remove).delete()

    def put(self, data: dict) -> None:
        """
        Handle PUT operation - completely replace group.

        Any attributes not provided are cleared.
        """
        display_name = data.get("displayName")
        if not display_name:
            raise ValueError("displayName is required for groups")

        with transaction.atomic():
            self.obj.name = display_name
            self.obj.save()

            members_data = data.get("members", [])
            self._update_members(self.obj, members_data, self._config)

    def delete(self) -> None:
        """
        Delete the role.
        """
        self.obj.delete()

    def handle_replace(self, path: AttrPath, value: Union[str, list, dict], operation: dict) -> None:
        """
        Handle SCIM PATCH replace operations (called by django-scim2 handle_operations).

        Replace group name or members.
        """
        first_path = path.first_path
        attr_name = first_path.attr_name

        with transaction.atomic():
            if attr_name == "displayName":
                self.obj.name = value
                self.obj.save()

            elif attr_name == "members":
                if path.is_complex:
                    raise ValueError("Complex filtered paths for members are not supported")
                else:
                    members_data: list[dict] = cast(list[dict], value if isinstance(value, list) else [value])
                    self._update_members(self.obj, members_data, self._config)

    def handle_add(self, path: AttrPath, value: Union[str, list, dict], operation: dict) -> None:
        """
        Handle SCIM PATCH add operations (called by django-scim2 handle_operations).

        Add members to a group without replacing existing members.
        """
        first_path = path.first_path
        attr_name = first_path.attr_name

        with transaction.atomic():
            if attr_name == "displayName":
                # Add operation for displayName acts like replace
                self.obj.name = value
                self.obj.save()

            elif attr_name == "members":
                if path.is_complex:
                    # Handle filtered path: members[value eq "<user-id>"]
                    user_id = path.params_by_attr_paths.get(("members", "value", None))
                    if user_id:
                        members_to_add = [{"value": user_id}]
                elif isinstance(value, list):
                    members_to_add = value
                elif isinstance(value, dict):
                    members_to_add = [value]
                elif isinstance(value, str):
                    members_to_add = [{"value": value}]

                for member_data in members_to_add:
                    parsed = self._parse_member_id(member_data.get("value"))
                    if parsed is None:
                        continue
                    self._assign_role_member(self.obj, int(parsed), self._config)

    def handle_remove(self, path: AttrPath, value: Union[str, list, dict], operation: dict) -> None:
        """
        Handle SCIM PATCH remove operations (called by django-scim2 handle_operations).

        Remove members from a group. Reject removing group name.
        """
        first_path = path.first_path
        attr_name = first_path.attr_name

        with transaction.atomic():
            if attr_name == "displayName":
                raise ValueError("Group name cannot be removed")

            elif attr_name == "members":
                if path.is_complex:
                    # Path like: members[value eq "<user-id>"]
                    user_id = path.params_by_attr_paths.get(("members", "value", None))
                    if user_id:
                        RoleMembership.objects.filter(role=self.obj, user__id=str(user_id)).delete()
                elif isinstance(value, (list, dict)):
                    # Simple path with value: remove only specified members
                    # Entra ID uses this format: {"op": "Remove", "path": "members", "value": [{"value": "user-id"}]}
                    members_to_remove = value if isinstance(value, list) else [value]
                    user_ids = [
                        str(m.get("value")) for m in members_to_remove if isinstance(m, dict) and m.get("value")
                    ]
                    if user_ids:
                        RoleMembership.objects.filter(role=self.obj, user__id__in=user_ids).delete()
                    else:
                        logger.warning(
                            "SCIM group remove: path='members' with value but no extractable user IDs, "
                            "skipping removal. value=%s",
                            value,
                        )
                else:
                    # Bare simple path with no value: remove all members
                    RoleMembership.objects.filter(role=self.obj).delete()

    @classmethod
    def get_queryset_for_organization(cls, config: IdentityProviderConfig) -> QuerySet[Role]:
        return Role.objects.filter(organization=config.organization).order_by("id")
