from typing import Any

from django.conf import settings

from rest_framework.request import Request

from posthog.models.identity_provider_config import IdentityProviderConfig

from ee.models.scim_provisioned_user import SCIMProvisionedUser

from .auth import generate_scim_token

PII_FIELDS = {"userName", "displayName", "givenName", "familyName", "value", "display", "formatted"}

REDACTED_HEADERS = {"cookie", "set-cookie"}
MASKED_HEADERS = {"authorization"}


def _looks_like_email(value: str) -> bool:
    return "@" in value and "." in value.rpartition("@")[2]


def mask_string(value: str) -> str:
    """Mask a string: 1-2 chars -> *, 3+ chars -> a***b"""
    if len(value) <= 2:
        return "*" * len(value)
    return f"{value[0]}***{value[-1]}"


def mask_email(email: str) -> str:
    """Mask email local part only: a***b@example.com"""
    if "@" not in email:
        return mask_string(email)
    local, domain = email.rsplit("@", 1)
    return f"{mask_string(local)}@{domain}"


def mask_pii_value(value: Any) -> Any:
    """Mask a single PII value"""
    if not isinstance(value, str) or not value:
        return value
    if _looks_like_email(value):
        return mask_email(value)
    return mask_string(value)


def mask_scim_filter(filter_str: str) -> str:
    """Mask quoted values in SCIM filter strings, e.g. userName eq "email@example.com" """
    temp = filter_str.replace('\\"', "")
    parts = temp.split('"')
    for i in range(1, len(parts), 2):
        parts[i] = mask_pii_value(parts[i])
    return '"'.join(parts)


def mask_scim_payload(data: Any, depth: int = 0) -> Any:
    """Recursively mask PII fields in a SCIM payload."""
    if depth > 20:
        return "[DEPTH_LIMIT_EXCEEDED]"

    match data:
        case dict():
            result = {}
            for key, value in data.items():
                match value:
                    case dict():
                        result[key] = mask_scim_payload(value, depth + 1)
                    case list():
                        result[key] = [mask_scim_payload(item, depth + 1) for item in value]
                    case _:
                        result[key] = mask_pii_value(value) if key in PII_FIELDS else value
            return result
        case list():
            return [mask_scim_payload(item, depth + 1) for item in data]
        case _:
            return data


def mask_headers(headers: dict[str, str]) -> dict[str, str]:
    result = {}
    for key, value in headers.items():
        normalized = key.lower().strip()
        if normalized in REDACTED_HEADERS:
            continue
        if normalized in MASKED_HEADERS:
            result[key] = "***"
        else:
            result[key] = value
    return result


def enable_scim_for_config(config: IdentityProviderConfig) -> str:
    """
    Enable SCIM for an IdentityProviderConfig and generate a new bearer token.
    Returns the plain text token (only shown once).
    """
    token = generate_scim_token()

    config.scim_enabled = True
    config.scim_bearer_token = token.hashed
    config.save()

    return token.plain


def disable_scim_for_config(config: IdentityProviderConfig) -> None:
    """
    Disable SCIM for an IdentityProviderConfig.
    """
    config.scim_enabled = False
    config.scim_bearer_token = None
    config.save()


def regenerate_scim_token_for_config(config: IdentityProviderConfig) -> str:
    """
    Regenerate SCIM bearer token for an IdentityProviderConfig.
    Returns the new plain text token (only shown once).
    """
    token = generate_scim_token()

    config.scim_bearer_token = token.hashed
    config.save()

    return token.plain


def get_scim_base_url(config: IdentityProviderConfig) -> str:
    """
    Get the SCIM base URL for an IdentityProviderConfig.
    """
    return f"{settings.SITE_URL}/scim/v2/{config.scim_slug}"


def detect_identity_provider(request: Request) -> SCIMProvisionedUser.IdentityProvider:
    """
    Detect identity provider from request User-Agent header.
    """
    user_agent = request.headers.get("user-agent", "").lower()

    if "okta" in user_agent:
        return SCIMProvisionedUser.IdentityProvider.OKTA
    elif "entra" in user_agent or "microsoft" in user_agent:
        return SCIMProvisionedUser.IdentityProvider.ENTRA_ID
    elif "google" in user_agent:
        return SCIMProvisionedUser.IdentityProvider.GOOGLE
    elif "onelogin" in user_agent:
        return SCIMProvisionedUser.IdentityProvider.ONELOGIN

    return SCIMProvisionedUser.IdentityProvider.OTHER


def normalize_scim_operations(operations: list[dict]) -> list[dict]:
    """
    Normalize SCIM PATCH operations to handle string booleans for 'active' field
    """
    normalized = []
    for op in operations:
        op = op.copy()
        path = op.get("path")
        value = op.get("value")

        if path == "active" and isinstance(value, str):
            op["value"] = value.lower() == "true"
        elif isinstance(value, dict) and "active" in value and isinstance(value["active"], str):
            value = value.copy()
            value["active"] = value["active"].lower() == "true"
            op["value"] = value

        normalized.append(op)
    return normalized
