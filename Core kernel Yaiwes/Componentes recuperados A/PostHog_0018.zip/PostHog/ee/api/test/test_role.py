from uuid import uuid4

from django.db import IntegrityError, connection
from django.test.utils import CaptureQueriesContext

from rest_framework import status

from posthog.models.organization import Organization, OrganizationMembership
from posthog.models.user import User

from products.access_control.backend.models.role import Role, RoleMembership

from ee.api.test.base import APILicensedTest


class TestRoleCrossOrgAuthorization(APILicensedTest):
    """Tests for cross-organization authorization bypass on role endpoints."""

    CLASS_DATA_LEVEL_SETUP = False

    def setUp(self):
        super().setUp()
        self.org_a = self.organization
        self.org_b = Organization.objects.create(name="Org B")
        self.org_b.update_available_product_features()
        self.org_b.save()

        # User is admin in org_a, member in org_b
        self.organization_membership.level = OrganizationMembership.Level.ADMIN
        self.organization_membership.save()
        self.org_b_membership = OrganizationMembership.objects.create(
            user=self.user, organization=self.org_b, level=OrganizationMembership.Level.MEMBER
        )

    def _switch_active_org(self, org):
        self.user.current_organization = org
        self.user.save()

    def test_cross_org_admin_cannot_create_roles_in_other_org(self):
        self._switch_active_org(self.org_a)
        res = self.client.post(f"/api/organizations/{self.org_b.id}/roles", {"name": "Hacked Role"})
        self.assertEqual(res.status_code, status.HTTP_403_FORBIDDEN)

    def test_cross_org_admin_cannot_update_roles_in_other_org(self):
        role = Role.objects.create(name="Engineering", organization=self.org_b)
        self._switch_active_org(self.org_a)
        res = self.client.patch(f"/api/organizations/{self.org_b.id}/roles/{role.id}", {"name": "Hacked"})
        self.assertEqual(res.status_code, status.HTTP_403_FORBIDDEN)

    def test_cross_org_admin_cannot_delete_roles_in_other_org(self):
        role = Role.objects.create(name="Engineering", organization=self.org_b)
        self._switch_active_org(self.org_a)
        res = self.client.delete(f"/api/organizations/{self.org_b.id}/roles/{role.id}")
        self.assertEqual(res.status_code, status.HTTP_403_FORBIDDEN)

    def test_cross_org_role_creation_uses_correct_org(self):
        """Admin in both orgs, active=A, POST to B URL → role.organization == B"""
        self.org_b_membership.level = OrganizationMembership.Level.ADMIN
        self.org_b_membership.save()
        self._switch_active_org(self.org_a)
        res = self.client.post(f"/api/organizations/{self.org_b.id}/roles", {"name": "New Role"})
        self.assertEqual(res.status_code, status.HTTP_201_CREATED)
        role = Role.objects.get(id=res.json()["id"])
        self.assertEqual(role.organization_id, self.org_b.id)

    def test_cross_org_role_name_uniqueness_checks_correct_org(self):
        """'Engineering' exists in A. Admin in both, active=A, POST to B → 201"""
        Role.objects.create(name="Engineering", organization=self.org_a)
        self.org_b_membership.level = OrganizationMembership.Level.ADMIN
        self.org_b_membership.save()
        self._switch_active_org(self.org_a)
        res = self.client.post(f"/api/organizations/{self.org_b.id}/roles", {"name": "Engineering"})
        self.assertEqual(res.status_code, status.HTTP_201_CREATED)

    def test_member_cannot_modify_roles_after_fix(self):
        self.organization_membership.level = OrganizationMembership.Level.MEMBER
        self.organization_membership.save()
        res = self.client.post(f"/api/organizations/{self.org_a.id}/roles", {"name": "Blocked"})
        self.assertEqual(res.status_code, status.HTTP_403_FORBIDDEN)

    def test_admin_can_modify_roles_with_explicit_org_id(self):
        res = self.client.post(f"/api/organizations/{self.org_a.id}/roles", {"name": "Allowed"})
        self.assertEqual(res.status_code, status.HTTP_201_CREATED)


class TestRoleAPI(APILicensedTest):
    def test_only_organization_admins_and_higher_can_create(self):
        self.organization_membership.level = OrganizationMembership.Level.ADMIN
        self.organization_membership.save()
        admin_create_res = self.client.post(
            "/api/organizations/@current/roles",
            {
                "name": "Product",
            },
        )

        self.organization_membership.level = OrganizationMembership.Level.MEMBER
        self.organization_membership.save()
        member_create_res = self.client.post(
            "/api/organizations/@current/roles",
            {
                "name": "Product 2",
            },
        )
        self.assertEqual(admin_create_res.status_code, status.HTTP_201_CREATED)
        self.assertEqual(Role.objects.all().count(), 1)
        self.assertEqual(Role.objects.first().name, "Product")  # type: ignore
        self.assertEqual(member_create_res.status_code, status.HTTP_403_FORBIDDEN)

    def test_only_organization_admins_and_higher_can_update(self):
        existing_eng_role = Role.objects.create(
            name="Engineering",
            organization=self.organization,
            created_by=self.user,
        )
        self.organization_membership.level = OrganizationMembership.Level.ADMIN
        self.organization_membership.save()
        admin_update_res = self.client.patch(
            f"/api/organizations/@current/roles/{existing_eng_role.id}",
            {"name": "on call support"},
        )

        self.organization_membership.level = OrganizationMembership.Level.MEMBER
        self.organization_membership.save()
        member_update_res = self.client.patch(
            f"/api/organizations/@current/roles/{existing_eng_role.id}",
            {"name": "member eng"},
        )

        self.assertEqual(admin_update_res.status_code, status.HTTP_200_OK)
        self.assertEqual(member_update_res.status_code, status.HTTP_403_FORBIDDEN)
        self.assertEqual(Role.objects.all().count(), 1)
        self.assertEqual(Role.objects.first().name, "on call support")  # type: ignore

    def test_cannot_duplicate_role_name(self):
        Role.objects.create(name="Marketing", organization=self.organization)
        count = Role.objects.count()
        self.organization_membership.level = OrganizationMembership.Level.ADMIN
        self.organization_membership.save()
        res = self.client.post(
            "/api/organizations/@current/roles",
            {
                "name": "marketing",
            },
        )
        self.assertEqual(res.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertEqual(
            res.json(),
            {
                "type": "validation_error",
                "code": "unique",
                "detail": "There is already a role with this name.",
                "attr": "name",
            },
        )
        self.assertEqual(Role.objects.count(), count)
        other_org = Organization.objects.create(name="other org")
        Role.objects.create(name="Marketing", organization=other_org)
        self.assertEqual(Role.objects.count(), 2)
        self.assertEqual(Role.objects.filter(organization=other_org).exists(), True)
        with self.assertRaises(IntegrityError):
            Role.objects.create(name="Marketing", organization=self.organization)

    def test_can_rename_role_with_case_change(self):
        self.organization_membership.level = OrganizationMembership.Level.ADMIN
        self.organization_membership.save()
        role = Role.objects.create(name="engineering", organization=self.organization, created_by=self.user)
        res = self.client.patch(
            f"/api/organizations/@current/roles/{role.id}",
            {"name": "Engineering"},
        )
        self.assertEqual(res.status_code, status.HTTP_200_OK)
        role.refresh_from_db()
        self.assertEqual(role.name, "Engineering")

    def test_cannot_rename_role_to_existing_name(self):
        self.organization_membership.level = OrganizationMembership.Level.ADMIN
        self.organization_membership.save()
        Role.objects.create(name="Marketing", organization=self.organization, created_by=self.user)
        eng_role = Role.objects.create(name="Engineering", organization=self.organization, created_by=self.user)
        res = self.client.patch(
            f"/api/organizations/@current/roles/{eng_role.id}",
            {"name": "marketing"},
        )
        self.assertEqual(res.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertEqual(res.json()["code"], "unique")

    def test_listing_roles_does_not_scale_queries_with_member_count(self):
        self.organization_membership.level = OrganizationMembership.Level.ADMIN
        self.organization_membership.save()
        role = Role.objects.create(name="Engineering", organization=self.organization)

        def add_members(count: int) -> None:
            for _ in range(count):
                user = User.objects.create_and_join(self.organization, f"member-{uuid4()}@posthog.com", None)
                membership = OrganizationMembership.objects.get(organization=self.organization, user=user)
                RoleMembership.objects.create(role=role, user=user, organization_member=membership)

        def members_for_role(response) -> list:
            return next(r["members"] for r in response.json()["results"] if r["id"] == str(role.id))

        # Warm up per-process caches (instance settings etc.) so they don't skew the counts below.
        self.client.get("/api/organizations/@current/roles")

        add_members(2)
        with CaptureQueriesContext(connection) as few_members:
            res = self.client.get("/api/organizations/@current/roles")
        self.assertEqual(res.status_code, status.HTTP_200_OK)
        self.assertEqual(len(members_for_role(res)), 2)

        add_members(4)
        with CaptureQueriesContext(connection) as more_members:
            res = self.client.get("/api/organizations/@current/roles")
        self.assertEqual(res.status_code, status.HTTP_200_OK)
        self.assertEqual(len(members_for_role(res)), 6)

        # Constant query count as members grow: the social-auth/2FA lookups are prefetched, not N+1.
        self.assertEqual(len(few_members.captured_queries), len(more_members.captured_queries))

    def test_returns_correct_results_by_organization(self):
        self.organization_membership.level = OrganizationMembership.Level.ADMIN
        self.organization_membership.save()

        self.client.post(
            "/api/organizations/@current/roles",
            {
                "name": "Product",
            },
        )
        self.client.post(
            "/api/organizations/@current/roles",
            {
                "name": "Customer Success",
            },
        )
        other_org = Organization.objects.create(name="other org")
        Role.objects.create(name="Product", organization=other_org)
        self.assertEqual(Role.objects.count(), 3)
        res = self.client.get("/api/organizations/@current/roles")
        results = res.json()
        self.assertEqual(results["count"], 2)
        self.assertNotContains(res, str(other_org.id))


class TestRoleMemberVisibilityRestriction(APILicensedTest):
    """When members_can_see_org_members is off, role endpoints must not disclose members the
    requester can't see in the members list."""

    def setUp(self):
        super().setUp()
        from posthog.constants import AvailableFeature

        from products.access_control.backend.models.access_control import AccessControl

        self.organization.available_product_features = [
            {"key": AvailableFeature.ACCESS_CONTROL, "name": AvailableFeature.ACCESS_CONTROL},
            {"key": AvailableFeature.ROLE_BASED_ACCESS, "name": AvailableFeature.ROLE_BASED_ACCESS},
        ]
        self.organization.members_can_see_org_members = False
        self.organization.save()

        self.mate = User.objects.create_and_join(self.organization, "mate@posthog.com", None)
        self.hidden = User.objects.create_and_join(self.organization, "hidden@posthog.com", None)
        self.role = Role.objects.create(name="Engineering", organization=self.organization, created_by=self.hidden)
        for user in [self.mate, self.hidden]:
            RoleMembership.objects.create(
                role=self.role,
                user=user,
                organization_member=user.organization_memberships.get(organization=self.organization),
            )
        # Private project: explicit access for the requester and one project mate, none for `hidden`
        AccessControl.objects.create(
            team=self.team, resource="project", resource_id=str(self.team.id), access_level="none"
        )
        for membership in [
            self.organization_membership,
            self.mate.organization_memberships.get(organization=self.organization),
        ]:
            AccessControl.objects.create(
                team=self.team,
                resource="project",
                resource_id=str(self.team.id),
                organization_member=membership,
                access_level="member",
            )

    def test_restricted_member_cannot_see_hidden_members_via_roles(self):
        response = self.client.get("/api/organizations/@current/roles")
        assert response.status_code == status.HTTP_200_OK
        role = response.json()["results"][0]
        assert {m["user"]["email"] for m in role["members"]} == {self.mate.email}
        assert role["created_by"] is None

    def test_restricted_member_cannot_see_hidden_members_via_role_memberships(self):
        response = self.client.get(f"/api/organizations/@current/roles/{self.role.id}/role_memberships")
        assert response.status_code == status.HTTP_200_OK
        assert {m["user"]["email"] for m in response.json()["results"]} == {self.mate.email}

    def test_admin_still_sees_all_role_members(self):
        self.organization_membership.level = OrganizationMembership.Level.ADMIN
        self.organization_membership.save()
        response = self.client.get("/api/organizations/@current/roles")
        role = response.json()["results"][0]
        assert {m["user"]["email"] for m in role["members"]} == {self.mate.email, self.hidden.email}
        assert role["created_by"]["email"] == self.hidden.email
