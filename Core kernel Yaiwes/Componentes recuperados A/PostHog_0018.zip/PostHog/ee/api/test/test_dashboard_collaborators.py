from rest_framework import status

from posthog.constants import AvailableFeature
from posthog.models import OrganizationMembership, User

from products.access_control.backend.models.access_control import AccessControl
from products.dashboards.backend.models.dashboard import Dashboard

from ee.api.test.base import APILicensedTest
from ee.models.dashboard_privilege import DashboardPrivilege


class TestDashboardCollaboratorsAPI(APILicensedTest):
    CONFIG_FORCE_ACCESS_CONTROL_ON_SETUP = True
    test_dashboard: Dashboard

    def setUp(self):
        super().setUp()

        if not self.organization.is_feature_available(AvailableFeature.ACCESS_CONTROL):
            self.skipTest("Dashboard collaborators tests require access control")

        AccessControl.objects.create(
            team=self.team,
            resource="project",
            resource_id=str(self.team.id),
            organization_member=None,
            role=None,
            access_level="member",
        )

        self.test_dashboard = Dashboard.objects.create(team=self.team, name="Test Insights 9001", created_by=self.user)

    def test_list_collaborators_as_person_without_edit_access(self):
        self.organization_membership.level = OrganizationMembership.Level.MEMBER
        self.organization_membership.save()
        self.test_dashboard.restriction_level = Dashboard.RestrictionLevel.ONLY_COLLABORATORS_CAN_EDIT
        self.test_dashboard.created_by = None
        self.test_dashboard.save()
        other_user_a = User.objects.create_and_join(self.organization, "a@x.com", None)
        other_user_b = User.objects.create_and_join(self.organization, "b@x.com", None)
        DashboardPrivilege.objects.create(
            user=other_user_a,
            dashboard=self.test_dashboard,
            level=Dashboard.PrivilegeLevel.CAN_VIEW,
        )
        DashboardPrivilege.objects.create(
            user=other_user_b,
            dashboard=self.test_dashboard,
            level=Dashboard.PrivilegeLevel.CAN_EDIT,
        )

        response = self.client.get(
            f"/api/projects/{self.test_dashboard.team_id}/dashboards/{self.test_dashboard.id}/collaborators/"
        )
        self.assertEqual(response.status_code, status.HTTP_200_OK)

        response_data = response.json()
        response_data = sorted(response_data, key=lambda entry: entry["user"]["email"])

        self.assertEqual(len(response_data), 2)
        self.assertEqual(response_data[0]["user"]["email"], other_user_a.email)
        self.assertEqual(response_data[0]["level"], Dashboard.PrivilegeLevel.CAN_VIEW)
        self.assertEqual(response_data[1]["user"]["email"], other_user_b.email)
        self.assertEqual(response_data[1]["level"], Dashboard.PrivilegeLevel.CAN_EDIT)

    def test_cannot_add_collaborator_to_unrestricted_dashboard_as_creator(self):
        self.organization_membership.level = OrganizationMembership.Level.MEMBER
        self.organization_membership.save()
        self.test_dashboard.restriction_level = Dashboard.RestrictionLevel.EVERYONE_IN_PROJECT_CAN_EDIT
        self.test_dashboard.save()
        other_user = User.objects.create_and_join(self.organization, "a@x.com", None)

        response = self.client.post(
            f"/api/projects/{self.test_dashboard.team_id}/dashboards/{self.test_dashboard.id}/collaborators/",
            {
                "user_uuid": str(other_user.uuid),
                "level": Dashboard.PrivilegeLevel.CAN_EDIT,
            },
        )
        response_data = response.json()

        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertEqual(
            response_data,
            self.validation_error_response("Cannot add collaborators to a dashboard on the lowest restriction level."),
        )

    def test_can_add_collaborator_to_edit_restricted_dashboard_as_creator(self):
        self.organization_membership.level = OrganizationMembership.Level.MEMBER
        self.organization_membership.save()
        self.test_dashboard.restriction_level = Dashboard.RestrictionLevel.ONLY_COLLABORATORS_CAN_EDIT
        self.test_dashboard.save()
        other_user = User.objects.create_and_join(self.organization, "a@x.com", None)

        response = self.client.post(
            f"/api/projects/{self.test_dashboard.team_id}/dashboards/{self.test_dashboard.id}/collaborators/",
            {
                "user_uuid": str(other_user.uuid),
                "level": Dashboard.PrivilegeLevel.CAN_EDIT,
            },
        )
        response_data = response.json()

        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertEqual(response_data["dashboard_id"], self.test_dashboard.id)
        self.assertEqual(response_data["user"]["email"], other_user.email)
        self.assertEqual(response_data["level"], Dashboard.PrivilegeLevel.CAN_EDIT)

    def test_cannot_add_yourself_to_restricted_dashboard_as_creator(self):
        self.organization_membership.level = OrganizationMembership.Level.MEMBER
        self.organization_membership.save()
        self.test_dashboard.restriction_level = Dashboard.RestrictionLevel.ONLY_COLLABORATORS_CAN_EDIT
        self.test_dashboard.save()

        response = self.client.post(
            f"/api/projects/{self.test_dashboard.team_id}/dashboards/{self.test_dashboard.id}/collaborators/",
            {
                "user_uuid": str(self.user.uuid),
                "level": Dashboard.PrivilegeLevel.CAN_EDIT,
            },
        )
        response_data = response.json()

        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

        self.assertEqual(
            response_data,
            self.validation_error_response(
                "Cannot add collaborators that already have inherent access (the dashboard owner or a project admins)."
            ),
        )

    def test_cannot_add_collaborator_to_edit_restricted_dashboard_as_other_user(self):
        self.organization_membership.level = OrganizationMembership.Level.MEMBER
        self.organization_membership.save()
        self.test_dashboard.restriction_level = Dashboard.RestrictionLevel.ONLY_COLLABORATORS_CAN_EDIT
        self.test_dashboard.created_by = None
        self.test_dashboard.save()
        other_user = User.objects.create_and_join(self.organization, "a@x.com", None)

        response = self.client.post(
            f"/api/projects/{self.test_dashboard.team_id}/dashboards/{self.test_dashboard.id}/collaborators/",
            {
                "user_uuid": str(other_user.uuid),
                "level": Dashboard.PrivilegeLevel.CAN_EDIT,
            },
        )
        response_data = response.json()

        self.assertEqual(response.status_code, status.HTTP_403_FORBIDDEN)
        self.assertEqual(
            response_data,
            self.permission_denied_response("You don't have edit permissions for this dashboard."),
        )

    def test_cannot_add_collaborator_from_other_org_to_edit_restricted_dashboard_as_creator(self):
        self.organization_membership.level = OrganizationMembership.Level.MEMBER
        self.organization_membership.save()
        self.test_dashboard.restriction_level = Dashboard.RestrictionLevel.ONLY_COLLABORATORS_CAN_EDIT
        self.test_dashboard.save()
        _, _, other_user = User.objects.bootstrap("Beta", "a@x.com", None)

        response = self.client.post(
            f"/api/projects/{self.test_dashboard.team_id}/dashboards/{self.test_dashboard.id}/collaborators/",
            {
                "user_uuid": str(other_user.uuid),
                "level": Dashboard.PrivilegeLevel.CAN_EDIT,
            },
        )
        response_data = response.json()

        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

        self.assertEqual(
            response_data,
            self.validation_error_response("Cannot add collaborators that have no access to the project."),
        )

    def test_cannot_add_collaborator_to_other_org_to_edit_restricted_dashboard_as_creator(self):
        self.organization_membership.level = OrganizationMembership.Level.MEMBER
        self.organization_membership.save()
        self.test_dashboard.restriction_level = Dashboard.RestrictionLevel.ONLY_COLLABORATORS_CAN_EDIT
        self.test_dashboard.save()
        self.organization_membership.delete()
        _, _, other_user = User.objects.bootstrap("Beta", "a@x.com", None)

        response = self.client.post(
            f"/api/projects/{self.test_dashboard.team_id}/dashboards/{self.test_dashboard.id}/collaborators/",
            {
                "user_uuid": str(other_user.uuid),
                "level": Dashboard.PrivilegeLevel.CAN_EDIT,
            },
        )
        response_data = response.json()

        self.assertEqual(response.status_code, status.HTTP_403_FORBIDDEN)
        self.assertEqual(
            response_data,
            self.permission_denied_response("You don't have access to the project."),
        )

    def test_cannot_update_existing_collaborator(self):
        # This will change once there are more levels, but with just two it doesn't make sense to PATCH privileges
        self.organization_membership.level = OrganizationMembership.Level.MEMBER
        self.organization_membership.save()
        self.test_dashboard.restriction_level = Dashboard.RestrictionLevel.EVERYONE_IN_PROJECT_CAN_EDIT
        self.test_dashboard.save()
        other_user = User.objects.create_and_join(self.organization, "a@x.com", None)
        DashboardPrivilege.objects.create(
            user=other_user,
            dashboard=self.test_dashboard,
            level=Dashboard.PrivilegeLevel.CAN_EDIT,
        )

        response = self.client.patch(
            f"/api/projects/{self.test_dashboard.team_id}/dashboards/{self.test_dashboard.id}/collaborators/{other_user.uuid}",
            {"level": Dashboard.PrivilegeLevel.CAN_VIEW},
        )

        self.assertEqual(response.status_code, status.HTTP_405_METHOD_NOT_ALLOWED)

    def test_cannot_remove_collaborator_from_unrestricted_dashboard_as_creator(self):
        self.organization_membership.level = OrganizationMembership.Level.MEMBER
        self.organization_membership.save()
        self.test_dashboard.restriction_level = Dashboard.RestrictionLevel.EVERYONE_IN_PROJECT_CAN_EDIT
        self.test_dashboard.save()
        other_user = User.objects.create_and_join(self.organization, "a@x.com", None)
        DashboardPrivilege.objects.create(
            user=other_user,
            dashboard=self.test_dashboard,
            level=Dashboard.PrivilegeLevel.CAN_EDIT,
        )

        response = self.client.delete(
            f"/api/projects/{self.test_dashboard.team_id}/dashboards/{self.test_dashboard.id}/collaborators/{other_user.uuid}"
        )
        response_data = response.json()

        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertEqual(
            response_data,
            self.validation_error_response(
                "Cannot remove collaborators from a dashboard on the lowest restriction level."
            ),
        )

    def test_can_remove_collaborator_from_restricted_dashboard_as_creator(self):
        self.organization_membership.level = OrganizationMembership.Level.MEMBER
        self.organization_membership.save()
        self.test_dashboard.restriction_level = Dashboard.RestrictionLevel.ONLY_COLLABORATORS_CAN_EDIT
        self.test_dashboard.save()
        other_user = User.objects.create_and_join(self.organization, "a@x.com", None)
        DashboardPrivilege.objects.create(
            user=other_user,
            dashboard=self.test_dashboard,
            level=Dashboard.PrivilegeLevel.CAN_EDIT,
        )

        response = self.client.delete(
            f"/api/projects/{self.test_dashboard.team_id}/dashboards/{self.test_dashboard.id}/collaborators/{other_user.uuid}"
        )

        self.assertEqual(response.status_code, status.HTTP_204_NO_CONTENT)

    def test_cannot_remove_collaborator_from_restricted_dashboard_as_other_user(self):
        self.organization_membership.level = OrganizationMembership.Level.MEMBER
        self.organization_membership.save()
        self.test_dashboard.restriction_level = Dashboard.RestrictionLevel.ONLY_COLLABORATORS_CAN_EDIT
        self.test_dashboard.created_by = None
        self.test_dashboard.save()
        other_user = User.objects.create_and_join(self.organization, "a@x.com", None)
        DashboardPrivilege.objects.create(
            user=other_user,
            dashboard=self.test_dashboard,
            level=Dashboard.PrivilegeLevel.CAN_EDIT,
        )

        response = self.client.delete(
            f"/api/projects/{self.test_dashboard.team_id}/dashboards/{self.test_dashboard.id}/collaborators/{other_user.uuid}"
        )
        response_data = response.json()

        self.assertEqual(response.status_code, status.HTTP_403_FORBIDDEN)
        self.assertEqual(
            response_data,
            self.permission_denied_response("You don't have edit permissions for this dashboard."),
        )

    def test_cannot_add_collaborator_to_dashboard_in_another_project(self):
        # Admin of their own project must not be able to manage collaborators on a dashboard
        # that belongs to a different organization, by passing their own project_id in the URL.
        self.organization_membership.level = OrganizationMembership.Level.ADMIN
        self.organization_membership.save()
        org_a_collaborator = User.objects.create_and_join(self.organization, "collab@x.com", None)

        _, victim_team, _ = User.objects.bootstrap("VictimOrg", "victim@x.com", None)
        victim_dashboard = Dashboard.objects.create(
            team=victim_team,
            name="Victim Dashboard",
            restriction_level=Dashboard.RestrictionLevel.ONLY_COLLABORATORS_CAN_EDIT,
        )

        response = self.client.post(
            f"/api/projects/{self.team.id}/dashboards/{victim_dashboard.id}/collaborators/",
            {
                "user_uuid": str(org_a_collaborator.uuid),
                "level": Dashboard.PrivilegeLevel.CAN_EDIT,
            },
        )

        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)
        self.assertFalse(DashboardPrivilege.objects.filter(dashboard=victim_dashboard).exists())

    def test_cannot_remove_collaborator_from_dashboard_in_another_project(self):
        self.organization_membership.level = OrganizationMembership.Level.ADMIN
        self.organization_membership.save()

        _, victim_team, _ = User.objects.bootstrap("VictimOrg", "victim@x.com", None)
        victim_dashboard = Dashboard.objects.create(
            team=victim_team,
            name="Victim Dashboard",
            restriction_level=Dashboard.RestrictionLevel.ONLY_COLLABORATORS_CAN_EDIT,
        )
        collaborator = User.objects.create_and_join(victim_team.organization, "vcollab@x.com", None)
        privilege = DashboardPrivilege.objects.create(
            user=collaborator,
            dashboard=victim_dashboard,
            level=Dashboard.PrivilegeLevel.CAN_EDIT,
        )

        response = self.client.delete(
            f"/api/projects/{self.team.id}/dashboards/{victim_dashboard.id}/collaborators/{collaborator.uuid}"
        )

        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)
        self.assertTrue(DashboardPrivilege.objects.filter(id=privilege.id).exists())
