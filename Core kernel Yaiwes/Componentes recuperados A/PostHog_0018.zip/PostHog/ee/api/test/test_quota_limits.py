from __future__ import annotations

from posthog.test.base import APIBaseTest
from unittest.mock import patch

from rest_framework import status

from posthog.constants import AvailableFeature
from posthog.models.organization import Organization
from posthog.models.personal_api_key import PersonalAPIKey
from posthog.models.team import Team
from posthog.models.utils import generate_random_token_personal, hash_key_value

from ee.billing.quota_limiting import (
    INFORMATIONAL_USAGE_RESOURCES,
    QuotaLimitingCaches,
    QuotaResource,
    add_limited_team_tokens,
    replace_limited_team_tokens,
)


def _clear_ai_credits_limits() -> None:
    replace_limited_team_tokens(QuotaResource.AI_CREDITS, {}, QuotaLimitingCaches.QUOTA_LIMITER_CACHE_KEY)


class TestQuotaLimitsAPI(APIBaseTest):
    def setUp(self) -> None:
        super().setUp()
        _clear_ai_credits_limits()

    def tearDown(self) -> None:
        _clear_ai_credits_limits()
        super().tearDown()

    def _url(self, team_id: int | None = None) -> str:
        return f"/api/projects/{team_id if team_id is not None else self.team.pk}/quota_limits/"

    def _set_ai_credits_limit(self, team_api_token: str, expires_at: int) -> None:
        add_limited_team_tokens(
            QuotaResource.AI_CREDITS,
            {team_api_token: expires_at},
            QuotaLimitingCaches.QUOTA_LIMITER_CACHE_KEY,
        )

    def test_unauthenticated_returns_401_or_403(self) -> None:
        self.client.logout()
        response = self.client.get(self._url())
        # DRF returns 401 when no creds are presented and an authenticator that supports
        # a WWW-Authenticate challenge is configured; otherwise it returns 403. Either is
        # an auth failure — we only care that the endpoint refuses unauthenticated reads.
        self.assertIn(response.status_code, (status.HTTP_401_UNAUTHORIZED, status.HTTP_403_FORBIDDEN))

    def test_session_auth_returns_under_quota_when_team_not_limited(self) -> None:
        response = self.client.get(self._url())
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        data = response.json()
        self.assertEqual(data["limited"]["ai_credits"], {"limited": False, "usage": None, "limit": None})
        # Org holds no billing-granted Desktop usage feature -> reads as not paying
        self.assertIs(data["code_usage_billing_active"], False)

    def test_any_deactivated_org_limits_only_credit_buckets_and_reads_unbilled(self) -> None:
        self.organization.available_product_features = [
            {"key": AvailableFeature.POSTHOG_CODE_USAGE, "name": "PostHog Desktop usage billing"}
        ]
        self.organization.is_active = False
        self.organization.is_not_active_reason = "Past due invoice"
        self.organization.save()

        # The deactivated-org answer must not depend on Redis being reachable.
        with patch(
            "ee.api.quota_limits.get_fresh_team_limited_resources",
            side_effect=Exception("redis unavailable"),
        ):
            response = self.client.get(self._url())

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        data = response.json()
        credit_buckets = {QuotaResource.AI_CREDITS.value, QuotaResource.POSTHOG_CODE_CREDITS.value}
        for resource in QuotaResource:
            expected = resource.value in credit_buckets
            self.assertIs(data["limited"][resource.value]["limited"], expected)
        for field in INFORMATIONAL_USAGE_RESOURCES:
            self.assertIs(data["limited"][field]["limited"], False)
        self.assertIs(data["code_usage_billing_active"], False)

    def test_null_active_org_is_not_treated_as_deactivated(self) -> None:
        self.organization.is_active = None
        self.organization.save()

        response = self.client.get(self._url())

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(
            response.json()["limited"]["ai_credits"],
            {"limited": False, "usage": None, "limit": None},
        )

    def test_reports_code_usage_billing_state(self) -> None:
        # The LLM gateway keys posthog_code per-user cap bypass and model gating
        # on this field - dropping it (or resolving the wrong org) silently
        # re-caps paying users.
        self.organization.available_product_features = [
            {"key": AvailableFeature.POSTHOG_CODE_USAGE, "name": "PostHog Desktop usage billing"}
        ]
        self.organization.save()

        response = self.client.get(self._url())

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIs(response.json()["code_usage_billing_active"], True)

    def test_reports_org_usage_and_limit_for_synced_resources(self) -> None:
        # The LLM gateway forwards these to clients (PostHog Desktop renders
        # "used $X of $Y"); usage mirrors the limiter's usage + todays_usage sum.
        self.organization.usage = {
            "period": ["2026-07-01T00:00:00Z", "2026-08-01T00:00:00Z"],
            "posthog_code_credits": {"usage": 1500, "todays_usage": 200, "limit": 2000},
            "ai_credits": {"usage": 50, "todays_usage": 0},
            "signals_credits": {"usage": None, "todays_usage": None, "limit": 5000},
        }
        self.organization.save()

        response = self.client.get(self._url())

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        limited = response.json()["limited"]
        self.assertEqual(limited["posthog_code_credits"], {"limited": False, "usage": 1700, "limit": 2000})
        # Synced but unlimited: usage without a limit.
        self.assertEqual(limited["ai_credits"], {"limited": False, "usage": 50, "limit": None})
        # Synced with a limit but null usage figures: unknown usage, not zero.
        self.assertEqual(limited["signals_credits"], {"limited": False, "usage": None, "limit": 5000})
        # Never synced: unknown, not zero.
        self.assertEqual(limited["events"], {"limited": False, "usage": None, "limit": None})

    def test_reports_desktop_component_usage(self) -> None:
        self.organization.usage = {
            "period": ["2026-07-01T00:00:00Z", "2026-08-01T00:00:00Z"],
            "posthog_code_credits": {"usage": 50, "todays_usage": 7, "limit": 1000},
            "posthog_code_token_credits": {"usage": 30, "todays_usage": 3, "limit": None},
            "sandbox_compute_credits": {"usage": 20, "todays_usage": 4, "limit": None},
            "sandbox_compute_cpu_millicore_seconds": {"usage": 0, "todays_usage": 0, "limit": None},
            "sandbox_compute_memory_mib_seconds": {"usage": None, "todays_usage": None, "limit": None},
        }
        self.organization.save()

        response = self.client.get(self._url())

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        limited = response.json()["limited"]
        self.assertEqual(limited["posthog_code_token_credits"], {"limited": False, "usage": 33, "limit": None})
        self.assertEqual(limited["sandbox_compute_credits"], {"limited": False, "usage": 24, "limit": None})
        # Explicit zero stays zero...
        self.assertEqual(
            limited["sandbox_compute_cpu_millicore_seconds"], {"limited": False, "usage": 0, "limit": None}
        )
        # ...while never-synced stays null (unknown), never coerced to zero.
        self.assertEqual(
            limited["sandbox_compute_memory_mib_seconds"], {"limited": False, "usage": None, "limit": None}
        )

    def test_components_absent_from_org_usage_read_as_unknown(self) -> None:
        self.organization.usage = {
            "period": ["2026-07-01T00:00:00Z", "2026-08-01T00:00:00Z"],
            "posthog_code_credits": {"usage": 50, "todays_usage": 7, "limit": 1000},
        }
        self.organization.save()

        response = self.client.get(self._url())

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        limited = response.json()["limited"]
        for field in INFORMATIONAL_USAGE_RESOURCES:
            self.assertEqual(limited[field], {"limited": False, "usage": None, "limit": None}, field)

    def test_returns_limited_when_team_is_over_quota(self) -> None:
        self._set_ai_credits_limit(self.team.api_token, 9_999_999_999)

        response = self.client.get(self._url())
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.json()["limited"]["ai_credits"], {"limited": True, "usage": None, "limit": None})

    def test_returns_unlimited_when_limit_has_already_expired(self) -> None:
        self._set_ai_credits_limit(self.team.api_token, 1)  # epoch 1970

        response = self.client.get(self._url())
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.json()["limited"]["ai_credits"], {"limited": False, "usage": None, "limit": None})

    def test_personal_api_key_auth_works(self) -> None:
        self.client.logout()
        raw_key = generate_random_token_personal()
        PersonalAPIKey.objects.create(
            label="quota_limits-test",
            user=self.user,
            secure_value=hash_key_value(raw_key),
            scopes=["project:read"],
        )

        self._set_ai_credits_limit(self.team.api_token, 9_999_999_999)

        response = self.client.get(
            self._url(),
            headers={"authorization": f"Bearer {raw_key}"},
        )
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.json()["limited"]["ai_credits"], {"limited": True, "usage": None, "limit": None})

    def test_user_not_in_teams_org_is_forbidden(self) -> None:
        other_org = Organization.objects.create(name="other-org")
        other_team = Team.objects.create(organization=other_org, name="other-team")

        response = self.client.get(self._url(other_team.pk))
        # The caller is logged in to a team in a different org — TeamMemberAccessPermission
        # rejects with 403 (or 404 if the queryset can't see the team at all).
        self.assertIn(response.status_code, (status.HTTP_403_FORBIDDEN, status.HTTP_404_NOT_FOUND))

    def test_personal_api_key_scoped_to_a_different_team_is_forbidden(self) -> None:
        # Caller has access to both teams via membership, but the token is scoped to
        # `other_team` only — the standalone-endpoint design would have missed this and
        # leaked the other team's state.
        other_team = Team.objects.create(organization=self.organization, name="other-team")
        self.client.logout()
        raw_key = generate_random_token_personal()
        PersonalAPIKey.objects.create(
            label="quota_limits-test",
            user=self.user,
            secure_value=hash_key_value(raw_key),
            scopes=["project:read"],
            scoped_teams=[other_team.pk],
        )

        response = self.client.get(
            self._url(),
            headers={"authorization": f"Bearer {raw_key}"},
        )
        self.assertEqual(response.status_code, status.HTTP_403_FORBIDDEN)

    def test_personal_api_key_missing_required_scope_is_forbidden(self) -> None:
        # A token with only `feature_flag:read` shouldn't be able to read quota state.
        self.client.logout()
        raw_key = generate_random_token_personal()
        PersonalAPIKey.objects.create(
            label="quota_limits-test",
            user=self.user,
            secure_value=hash_key_value(raw_key),
            scopes=["feature_flag:read"],
        )

        response = self.client.get(
            self._url(),
            headers={"authorization": f"Bearer {raw_key}"},
        )
        self.assertEqual(response.status_code, status.HTTP_403_FORBIDDEN)

    def test_response_includes_every_quota_resource(self) -> None:
        # Limiting one resource must not hide the unlimited state of the rest.
        self._set_ai_credits_limit(self.team.api_token, 9_999_999_999)

        response = self.client.get(self._url())
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        limited = response.json()["limited"]
        expected_keys = {resource.value for resource in QuotaResource} | set(INFORMATIONAL_USAGE_RESOURCES)
        self.assertEqual(set(limited.keys()), expected_keys)
        self.assertTrue(limited["ai_credits"]["limited"])
        for resource in QuotaResource:
            if resource is QuotaResource.AI_CREDITS:
                continue
            self.assertFalse(limited[resource.value]["limited"], resource.value)

    def test_multi_team_user_gets_per_team_answers(self) -> None:
        # Same user belongs to two teams in their org; each team's quota is independent.
        # This is the regression that "me" couldn't model — `user.team` (current team)
        # picked one arbitrary answer for users in multiple teams.
        other_team = Team.objects.create(organization=self.organization, name="other-team")
        self._set_ai_credits_limit(self.team.api_token, 9_999_999_999)
        # other_team's token deliberately not limited

        resp_self = self.client.get(self._url())
        resp_other = self.client.get(self._url(other_team.pk))

        self.assertEqual(resp_self.json()["limited"]["ai_credits"], {"limited": True, "usage": None, "limit": None})
        self.assertEqual(resp_other.json()["limited"]["ai_credits"], {"limited": False, "usage": None, "limit": None})
