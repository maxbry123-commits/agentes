from datetime import datetime
from typing import Any, Optional, cast

from freezegun import freeze_time
from posthog.test.base import APIBaseTest
from unittest.mock import patch

from django.utils import timezone

import dateutil.parser
from parameterized import parameterized
from rest_framework import status

from posthog.api.test.test_event_definition import EventFixture, capture_event
from posthog.api.test.test_organization import create_organization
from posthog.api.test.test_team import create_team
from posthog.api.test.test_user import create_user
from posthog.models import ActivityLog, ObjectMediaPreview, Tag, Team, UploadedMedia, User

from products.event_definitions.backend.models.event_definition import EventDefinition

from ee.models.event_definition import EnterpriseEventDefinition
from ee.models.license import License, LicenseManager


@freeze_time("2020-01-02")
class TestEventDefinitionEnterpriseAPI(APIBaseTest):
    demo_team: Team = None  # type: ignore
    user: User = None  # type: ignore

    """
    Ignoring the verified field we'd expect ordering purchase, watched_movie, entered_free_trial, $pageview
    With it we expect watched_movie, entered_free_trial, purchase, $pageview
    """
    EXPECTED_EVENT_DEFINITIONS: list[dict[str, Any]] = [
        {"name": "purchase", "verified": None},
        {"name": "entered_free_trial", "verified": True},
        {"name": "watched_movie", "verified": True},
        {"name": "$pageview", "verified": None},
    ]

    @classmethod
    def setUpTestData(cls):
        cls.organization = create_organization(name="test org")
        cls.demo_team = create_team(organization=cls.organization)
        cls.user = create_user("user", "pass", cls.organization)

        for event_definition in cls.EXPECTED_EVENT_DEFINITIONS:
            EnterpriseEventDefinition.objects.create(name=event_definition["name"], team_id=cls.demo_team.pk)
            capture_event(
                event=EventFixture(
                    event=event_definition["name"],
                    team_id=cls.demo_team.pk,
                    distinct_id="abc",
                    timestamp=datetime(2020, 1, 1),
                    properties={},
                )
            )

    def test_list_event_definitions(self):
        super(LicenseManager, cast(LicenseManager, License.objects)).create(
            plan="enterprise", valid_until=datetime(2500, 1, 19, 3, 14, 7)
        )

        response = self.client.get("/api/projects/@current/event_definitions/")
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.json()["count"], len(self.EXPECTED_EVENT_DEFINITIONS))

        self.assertEqual(
            [(r["name"], r["verified"]) for r in response.json()["results"]],
            [
                ("$pageview", False),
                ("entered_free_trial", False),
                ("purchase", False),
                ("watched_movie", False),
            ],
        )

        for event_definition in self.EXPECTED_EVENT_DEFINITIONS:
            definition = EnterpriseEventDefinition.objects.filter(
                name=event_definition["name"], team=self.demo_team
            ).first()
            if definition is None:
                raise AssertionError(f"Event definition {event_definition['name']} not found")
            definition.verified = event_definition["verified"] or False
            definition.save()

        response = self.client.get("/api/projects/@current/event_definitions/")

        assert [(r["name"], r["verified"]) for r in response.json()["results"]] == [
            ("$pageview", False),
            ("entered_free_trial", True),
            ("purchase", False),
            ("watched_movie", True),
        ]

    def test_retrieve_existing_event_definition(self):
        super(LicenseManager, cast(LicenseManager, License.objects)).create(
            plan="enterprise", valid_until=datetime(2500, 1, 19, 3, 14, 7)
        )
        event = EnterpriseEventDefinition.objects.create(team=self.demo_team, name="enterprise event", owner=self.user)
        tag = Tag.objects.create(name="deprecated", team_id=self.demo_team.id)
        event.tagged_items.create(tag_id=tag.id)
        response = self.client.get(f"/api/projects/@current/event_definitions/{event.id}")
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        response_data = response.json()
        self.assertEqual(response_data["name"], "enterprise event")
        self.assertEqual(response_data["description"], "")
        self.assertEqual(response_data["tags"], ["deprecated"])
        self.assertEqual(response_data["owner"]["id"], self.user.id)

        self.assertAlmostEqual(
            (timezone.now() - dateutil.parser.isoparse(response_data["created_at"])).total_seconds(),
            0,
            delta=1,
        )
        self.assertIn("last_seen_at", response_data)

    def test_retrieve_create_event_definition(self):
        super(LicenseManager, cast(LicenseManager, License.objects)).create(
            plan="enterprise", valid_until=datetime(2500, 1, 19, 3, 14, 7)
        )
        event = EventDefinition.objects.create(team=self.demo_team, name="event")
        response = self.client.get(f"/api/projects/@current/event_definitions/{event.id}")
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        enterprise_event = EnterpriseEventDefinition.objects.filter(id=event.id).first()
        event.refresh_from_db()
        self.assertEqual(enterprise_event.eventdefinition_ptr_id, event.id)  # type: ignore
        self.assertEqual(enterprise_event.name, event.name)  # type: ignore
        self.assertEqual(enterprise_event.team.id, event.team.id)  # type: ignore

    def test_search_event_definition(self):
        super(LicenseManager, cast(LicenseManager, License.objects)).create(
            plan="enterprise", valid_until=datetime(2500, 1, 19, 3, 14, 7)
        )
        enterprise_property = EnterpriseEventDefinition.objects.create(
            team=self.demo_team, name="enterprise event", owner=self.user
        )
        tag = Tag.objects.create(name="deprecated", team_id=self.demo_team.id)
        enterprise_property.tagged_items.create(tag_id=tag.id)
        regular_event = EnterpriseEventDefinition.objects.create(
            team=self.demo_team, name="regular event", owner=self.user
        )
        regular_event.tagged_items.create(tag_id=tag.id)

        response = self.client.get(f"/api/projects/@current/event_definitions/?search=enter")
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        response_data = response.json()
        self.assertEqual(
            sorted([r["name"] for r in response_data["results"]]),
            ["entered_free_trial", "enterprise event"],
        )

        enterprise_event = next((r for r in response_data["results"] if r["name"] == "enterprise event"), None)
        assert enterprise_event is not None
        assert enterprise_event["description"] == ""
        assert enterprise_event["tags"] == ["deprecated"]
        assert enterprise_event["owner"]["id"] == self.user.id

        response = self.client.get(f"/api/projects/@current/event_definitions/?search=enterprise")
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        response_data = response.json()
        self.assertEqual(len(response_data["results"]), 1)

        response = self.client.get(f"/api/projects/@current/event_definitions/?search=e ev")
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        response_data = response.json()
        self.assertEqual(
            sorted([r["name"] for r in response_data["results"]]),
            ["$pageview", "enterprise event", "regular event"],
        )

        response = self.client.get(f"/api/projects/@current/event_definitions/?search=bust")
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        response_data = response.json()
        self.assertEqual(len(response_data["results"]), 0)

    @parameterized.expand(
        [
            # $pageview is a core PostHog event, so it's treated as verified
            ("verified_only", "true", ["$pageview", "entered_free_trial", "watched_movie"]),
            ("unverified_only", "false", ["purchase"]),
            ("all_when_not_specified", None, ["$pageview", "entered_free_trial", "purchase", "watched_movie"]),
        ]
    )
    def test_filter_event_definitions_by_verified(
        self, _name: str, verified_param: Optional[str], expected_names: list[str]
    ):
        super(LicenseManager, cast(LicenseManager, License.objects)).create(
            plan="enterprise", valid_until=datetime(2500, 1, 19, 3, 14, 7)
        )

        for event_definition in self.EXPECTED_EVENT_DEFINITIONS:
            EnterpriseEventDefinition.objects.filter(name=event_definition["name"], team=self.demo_team).update(
                verified=event_definition["verified"] or False
            )

        url = "/api/projects/@current/event_definitions/"
        if verified_param is not None:
            url += f"?verified={verified_param}"

        response = self.client.get(url)

        assert response.status_code == status.HTTP_200_OK
        assert sorted([r["name"] for r in response.json()["results"]]) == expected_names

    def test_update_event_definition(self):
        super(LicenseManager, cast(LicenseManager, License.objects)).create(
            plan="enterprise", valid_until=datetime(2038, 1, 19, 3, 14, 7)
        )
        event = EnterpriseEventDefinition.objects.create(team=self.demo_team, name="enterprise event", owner=self.user)
        response = self.client.patch(
            f"/api/projects/@current/event_definitions/{str(event.id)}/",
            {"description": "This is a description.", "tags": ["official", "internal"]},
        )
        response_data = response.json()
        self.assertEqual(response_data["description"], "This is a description.")
        self.assertEqual(response_data["updated_by"]["first_name"], self.user.first_name)
        self.assertEqual(set(response_data["tags"]), {"official", "internal"})

        event.refresh_from_db()
        self.assertEqual(event.description, "This is a description.")
        self.assertEqual(
            set(event.tagged_items.values_list("tag__name", flat=True)),
            {"official", "internal"},
        )

        activity_log: Optional[ActivityLog] = ActivityLog.objects.filter(scope="EventDefinition").first()
        assert activity_log is not None
        assert activity_log.detail is not None
        self.assertEqual(activity_log.scope, "EventDefinition")
        self.assertEqual(activity_log.activity, "changed")
        self.assertEqual(activity_log.detail["name"], "enterprise event")
        self.assertEqual(activity_log.user, self.user)
        assert sorted(activity_log.detail["changes"], key=lambda x: x["field"]) == [
            {
                "action": "changed",
                "after": "This is a description.",
                "before": "",
                "field": "description",
                "type": "EventDefinition",
            },
            {
                "action": "changed",
                "after": ["official", "internal"],
                "before": [],
                "field": "tags",
                "type": "EventDefinition",
            },
        ]

    def test_can_get_event_verification_data(self):
        super(LicenseManager, cast(LicenseManager, License.objects)).create(
            plan="enterprise", valid_until=datetime(2500, 1, 19, 3, 14, 7)
        )
        event = EnterpriseEventDefinition.objects.create(team=self.demo_team, name="enterprise event", owner=self.user)
        response = self.client.get(f"/api/projects/@current/event_definitions/{event.id}")
        self.assertEqual(response.status_code, status.HTTP_200_OK)

        assert response.json()["verified"] is False
        assert response.json()["verified_by"] is None
        assert response.json()["verified_at"] is None
        assert response.json()["updated_at"] == "2020-01-02T00:00:00Z"

        query_list_response = self.client.get(f"/api/projects/@current/event_definitions")
        matches = [p["name"] for p in query_list_response.json()["results"] if p["name"] == "enterprise event"]
        assert len(matches) == 1

    def test_verify_then_unverify(self):
        super(LicenseManager, cast(LicenseManager, License.objects)).create(
            plan="enterprise", valid_until=datetime(2500, 1, 19, 3, 14, 7)
        )
        event = EnterpriseEventDefinition.objects.create(team=self.demo_team, name="enterprise event", owner=self.user)
        response = self.client.get(f"/api/projects/@current/event_definitions/{event.id}")
        self.assertEqual(response.status_code, status.HTTP_200_OK)

        assert response.json()["verified"] is False
        assert response.json()["verified_by"] is None
        assert response.json()["verified_at"] is None

        # Verify the event
        self.client.patch(f"/api/projects/@current/event_definitions/{event.id}", {"verified": True})
        response = self.client.get(f"/api/projects/@current/event_definitions/{event.id}")
        self.assertEqual(response.status_code, status.HTTP_200_OK)

        assert response.json()["verified"] is True
        assert response.json()["verified_by"]["id"] == self.user.id
        assert response.json()["verified_at"] == "2020-01-02T00:00:00Z"

        # Unverify the event
        self.client.patch(f"/api/projects/@current/event_definitions/{event.id}", {"verified": False})
        response = self.client.get(f"/api/projects/@current/event_definitions/{event.id}")
        self.assertEqual(response.status_code, status.HTTP_200_OK)

        assert response.json()["verified"] is False
        assert response.json()["verified_by"] is None
        assert response.json()["verified_at"] is None

    @parameterized.expand([("verify", True), ("unverify", False)])
    def test_bulk_update_verified_flips_state_and_skips_noops(self, _name, target):
        super(LicenseManager, cast(LicenseManager, License.objects)).create(
            plan="enterprise", valid_until=datetime(2500, 1, 19, 3, 14, 7)
        )
        already = EnterpriseEventDefinition.objects.create(
            team=self.demo_team, name="bulk_verify_already", verified=target
        )
        to_change = EnterpriseEventDefinition.objects.create(
            team=self.demo_team, name="bulk_verify_change", verified=not target
        )

        response = self.client.post(
            f"/api/projects/{self.demo_team.pk}/event_definitions/bulk_update_verified/",
            {"ids": [str(already.id), str(to_change.id)], "verified": target},
        )

        assert response.status_code == status.HTTP_200_OK, response.json()
        data = response.json()
        # Only the event that actually changed is reported; the one already in the target state is skipped.
        assert {u["id"] for u in data["updated"]} == {str(to_change.id)}
        assert all(u["verified"] is target for u in data["updated"])
        assert data["skipped"] == []

        already.refresh_from_db()
        to_change.refresh_from_db()
        assert already.verified is target
        assert to_change.verified is target
        # Verifying stamps metadata; unverifying clears it.
        if target:
            assert to_change.verified_by_id == self.user.id
            assert to_change.verified_at is not None
        else:
            assert to_change.verified_by_id is None
            assert to_change.verified_at is None

    def test_bulk_update_verified_promotes_base_event_definition(self):
        super(LicenseManager, cast(LicenseManager, License.objects)).create(
            plan="enterprise", valid_until=datetime(2500, 1, 19, 3, 14, 7)
        )
        # A base row with no enterprise extension, as created during ingestion.
        base = EventDefinition.objects.create(team=self.demo_team, name="ingested_only_event")
        assert not EnterpriseEventDefinition.objects.filter(id=base.id).exists()

        response = self.client.post(
            f"/api/projects/{self.demo_team.pk}/event_definitions/bulk_update_verified/",
            {"ids": [str(base.id)], "verified": True},
        )

        assert response.status_code == status.HTTP_200_OK, response.json()
        assert response.json()["updated"] == [{"id": str(base.id), "verified": True}]
        promoted = EnterpriseEventDefinition.objects.get(id=base.id)
        assert promoted.verified is True
        assert promoted.verified_by_id == self.user.id

    def test_bulk_update_verified_logs_activity_per_event(self):
        super(LicenseManager, cast(LicenseManager, License.objects)).create(
            plan="enterprise", valid_until=datetime(2500, 1, 19, 3, 14, 7)
        )
        events = [
            EnterpriseEventDefinition.objects.create(team=self.demo_team, name=f"bulk_log_event_{i}", verified=False)
            for i in range(3)
        ]
        ActivityLog.objects.filter(team_id=self.demo_team.pk, scope="EventDefinition").delete()

        response = self.client.post(
            f"/api/projects/{self.demo_team.pk}/event_definitions/bulk_update_verified/",
            {"ids": [str(e.id) for e in events], "verified": True},
        )

        assert response.status_code == status.HTTP_200_OK
        assert len(response.json()["updated"]) == 3

        logs = ActivityLog.objects.filter(team_id=self.demo_team.pk, scope="EventDefinition", activity="changed")
        assert logs.count() == 3
        assert {log.item_id for log in logs} == {str(e.id) for e in events}
        for log in logs:
            assert log.user == self.user
            assert log.detail is not None
            verified_changes = [c for c in (log.detail.get("changes") or []) if c["field"] == "verified"]
            assert verified_changes == [
                {"type": "EventDefinition", "action": "changed", "field": "verified", "before": False, "after": True}
            ]

    def test_bulk_update_verified_ignores_event_definitions_in_other_project(self):
        super(LicenseManager, cast(LicenseManager, License.objects)).create(
            plan="enterprise", valid_until=datetime(2500, 1, 19, 3, 14, 7)
        )
        mine = EnterpriseEventDefinition.objects.create(team=self.demo_team, name="bulk_verify_mine", verified=False)
        other_team = Team.objects.create(organization=self.organization, name="Other project")
        other = EnterpriseEventDefinition.objects.create(team=other_team, name="bulk_verify_other", verified=False)

        response = self.client.post(
            f"/api/projects/{self.demo_team.pk}/event_definitions/bulk_update_verified/",
            {"ids": [str(mine.id), str(other.id)], "verified": True},
        )

        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert {u["id"] for u in data["updated"]} == {str(mine.id)}
        assert data["skipped"] == [{"id": str(other.id), "reason": "Not found"}]

        mine.refresh_from_db()
        other.refresh_from_db()
        assert mine.verified is True
        assert other.verified is False

    def test_bulk_update_verified_unhides_event_when_verifying(self):
        super(LicenseManager, cast(LicenseManager, License.objects)).create(
            plan="enterprise", valid_until=datetime(2500, 1, 19, 3, 14, 7)
        )
        hidden_event = EnterpriseEventDefinition.objects.create(
            team=self.demo_team, name="bulk_verify_hidden", verified=False, hidden=True
        )

        response = self.client.post(
            f"/api/projects/{self.demo_team.pk}/event_definitions/bulk_update_verified/",
            {"ids": [str(hidden_event.id)], "verified": True},
        )

        assert response.status_code == status.HTTP_200_OK
        hidden_event.refresh_from_db()
        assert hidden_event.verified is True
        assert hidden_event.hidden is False

    def test_bulk_update_verified_deduplicates_repeated_ids(self):
        super(LicenseManager, cast(LicenseManager, License.objects)).create(
            plan="enterprise", valid_until=datetime(2500, 1, 19, 3, 14, 7)
        )
        event = EnterpriseEventDefinition.objects.create(team=self.demo_team, name="bulk_verify_dupe", verified=False)
        ActivityLog.objects.filter(team_id=self.demo_team.pk, scope="EventDefinition").delete()

        response = self.client.post(
            f"/api/projects/{self.demo_team.pk}/event_definitions/bulk_update_verified/",
            {"ids": [str(event.id), str(event.id)], "verified": True},
        )

        assert response.status_code == status.HTTP_200_OK, response.json()
        # A repeated id is applied and reported once, not once per occurrence.
        assert response.json()["updated"] == [{"id": str(event.id), "verified": True}]
        assert (
            ActivityLog.objects.filter(team_id=self.demo_team.pk, scope="EventDefinition", activity="changed").count()
            == 1
        )

    @patch("posthog.api.event_definition.log_activity")
    def test_bulk_update_verified_rolls_back_batch_on_error(self, mock_log_activity):
        super(LicenseManager, cast(LicenseManager, License.objects)).create(
            plan="enterprise", valid_until=datetime(2500, 1, 19, 3, 14, 7)
        )
        first = EnterpriseEventDefinition.objects.create(
            team=self.demo_team, name="bulk_verify_atomic_1", verified=False
        )
        second = EnterpriseEventDefinition.objects.create(
            team=self.demo_team, name="bulk_verify_atomic_2", verified=False
        )
        # Fail once the second event is mid-flight, after the first has already been written.
        mock_log_activity.side_effect = [None, RuntimeError("boom")]

        # The unhandled error surfaces as a 500 rather than propagating: PostHog's DRF exception
        # handler catches it before the test client can re-raise.
        response = self.client.post(
            f"/api/projects/{self.demo_team.pk}/event_definitions/bulk_update_verified/",
            {"ids": [str(first.id), str(second.id)], "verified": True},
        )
        assert response.status_code == status.HTTP_500_INTERNAL_SERVER_ERROR

        first.refresh_from_db()
        second.refresh_from_db()
        # The batch is atomic: a failure on the second event rolls back the first too.
        assert first.verified is False
        assert second.verified is False

    def test_bulk_update_verified_requires_enterprise_build(self):
        event = EnterpriseEventDefinition.objects.create(team=self.demo_team, name="bulk_verify_foss", verified=False)

        # Without the gate, the FOSS build would 500 on the ee import instead of rejecting cleanly.
        with patch("posthog.api.event_definition.EE_AVAILABLE", False):
            response = self.client.post(
                f"/api/projects/{self.demo_team.pk}/event_definitions/bulk_update_verified/",
                {"ids": [str(event.id)], "verified": True},
            )

        assert response.status_code == status.HTTP_400_BAD_REQUEST
        event.refresh_from_db()
        assert event.verified is False

    def test_bulk_update_verified_survives_concurrent_promotion(self):
        super(LicenseManager, cast(LicenseManager, License.objects)).create(
            plan="enterprise", valid_until=datetime(2500, 1, 19, 3, 14, 7)
        )
        base = EventDefinition.objects.create(team=self.demo_team, name="bulk_verify_race")
        # The competing request's promotion of the same base row, mirroring _get_event_definition.
        competing = EnterpriseEventDefinition(eventdefinition_ptr_id=base.id, description="")
        competing.__dict__.update(base.__dict__)
        competing.save()

        real_filter = EnterpriseEventDefinition.objects.filter

        def hide_from_existence_check(*args, **kwargs):
            # Only the promotion path's existence check filters on a single id. Hiding the row
            # there recreates the interleaving where the competing promotion lands between the
            # check and the save, so the save hits the real unique constraint.
            if "id" in kwargs:
                return EnterpriseEventDefinition.objects.none()
            return real_filter(*args, **kwargs)

        with patch.object(EnterpriseEventDefinition.objects, "filter", side_effect=hide_from_existence_check):
            response = self.client.post(
                f"/api/projects/{self.demo_team.pk}/event_definitions/bulk_update_verified/",
                {"ids": [str(base.id)], "verified": True},
            )

        # Losing the promotion race must fall back to the competitor's row, not fail the request.
        assert response.status_code == status.HTTP_200_OK, response.json()
        assert response.json()["updated"] == [{"id": str(base.id), "verified": True}]
        promoted = EnterpriseEventDefinition.objects.get(id=base.id)
        assert promoted.verified is True
        assert promoted.verified_by_id == self.user.id

    def test_verify_then_verify_again_no_change(self):
        super(LicenseManager, cast(LicenseManager, License.objects)).create(
            plan="enterprise", valid_until=datetime(2500, 1, 19, 3, 14, 7)
        )
        event = EnterpriseEventDefinition.objects.create(team=self.demo_team, name="enterprise event", owner=self.user)
        response = self.client.get(f"/api/projects/@current/event_definitions/{event.id}")
        self.assertEqual(response.status_code, status.HTTP_200_OK)

        assert self.user.team is not None
        assert self.user.team.pk == self.demo_team.pk

        assert response.json()["verified"] is False
        assert response.json()["verified_by"] is None
        assert response.json()["verified_at"] is None

        patch_result = self.client.patch(f"/api/projects/@current/event_definitions/{event.id}", {"verified": True})
        self.assertEqual(patch_result.status_code, status.HTTP_200_OK, patch_result.json())

        response = self.client.get(f"/api/projects/@current/event_definitions/{event.id}")
        self.assertEqual(response.status_code, status.HTTP_200_OK, response.json())

        assert response.json()["verified"] is True
        assert response.json()["verified_by"]["id"] == self.user.id
        assert response.json()["verified_at"] == "2020-01-02T00:00:00Z"
        assert response.json()["updated_at"] == "2020-01-02T00:00:00Z"

        with freeze_time("2020-01-02T00:01:00Z"):
            self.client.patch(
                f"/api/projects/@current/event_definitions/{event.id}",
                {"verified": True},
            )
            response = self.client.get(f"/api/projects/@current/event_definitions/{event.id}")
            self.assertEqual(response.status_code, status.HTTP_200_OK)

        assert response.json()["verified"] is True
        assert response.json()["verified_by"]["id"] == self.user.id
        assert response.json()["verified_at"] == "2020-01-02T00:00:00Z"  # Note `verified_at` did not change
        # updated_at automatically updates on every patch request
        assert response.json()["updated_at"] == "2020-01-02T00:01:00Z"

    def test_cannot_update_verified_meta_properties_directly(self):
        super(LicenseManager, cast(LicenseManager, License.objects)).create(
            plan="enterprise", valid_until=datetime(2500, 1, 19, 3, 14, 7)
        )
        event = EnterpriseEventDefinition.objects.create(team=self.demo_team, name="enterprise event", owner=self.user)
        response = self.client.get(f"/api/projects/@current/event_definitions/{event.id}")
        self.assertEqual(response.status_code, status.HTTP_200_OK)

        assert response.json()["verified"] is False
        assert response.json()["verified_by"] is None
        assert response.json()["verified_at"] is None

        with freeze_time("2020-01-02T00:01:00Z"):
            self.client.patch(
                f"/api/projects/@current/event_definitions/{event.id}",
                {
                    "verified_by": self.user.id,
                    "verified_at": timezone.now(),
                },  # These properties are ignored by the serializer
            )
            response = self.client.get(f"/api/projects/@current/event_definitions/{event.id}")
            self.assertEqual(response.status_code, status.HTTP_200_OK)

        assert response.json()["verified"] is False
        assert response.json()["verified_by"] is None
        assert response.json()["verified_at"] is None

    def test_event_definition_no_duplicate_tags(self):
        from ee.models.license import License, LicenseManager

        super(LicenseManager, cast(LicenseManager, License.objects)).create(
            key="key_123",
            plan="enterprise",
            valid_until=datetime(2038, 1, 19, 3, 14, 7),
        )
        event = EnterpriseEventDefinition.objects.create(team=self.demo_team, name="enterprise event")
        response = self.client.patch(
            f"/api/projects/@current/event_definitions/{str(event.id)}",
            data={"tags": ["a", "b", "a"]},
        )

        self.assertListEqual(sorted(response.json()["tags"]), ["a", "b"])

    def test_exclude_hidden_events(self):
        super(LicenseManager, cast(LicenseManager, License.objects)).create(
            plan="enterprise", valid_until=datetime(2500, 1, 19, 3, 14, 7)
        )
        # Create some events with hidden flag
        EnterpriseEventDefinition.objects.create(
            team=self.demo_team, project=self.demo_team.project, name="visible_event"
        )
        EnterpriseEventDefinition.objects.create(
            team=self.demo_team, project=self.demo_team.project, name="hidden_event1", hidden=True
        )
        EnterpriseEventDefinition.objects.create(
            team=self.demo_team, project=self.demo_team.project, name="hidden_event2", hidden=True
        )

        response = self.client.get(f"/api/projects/{self.demo_team.pk}/event_definitions/?exclude_hidden=true")
        assert response.status_code == status.HTTP_200_OK
        event_names = {p["name"] for p in response.json()["results"]}
        assert "visible_event" in event_names
        assert "hidden_event1" not in event_names
        assert "hidden_event2" not in event_names

        # Test with exclude_hidden=false (should be same as not setting it)
        response = self.client.get(f"/api/projects/{self.demo_team.pk}/event_definitions/?exclude_hidden=false")
        assert response.status_code == status.HTTP_200_OK
        event_names = {p["name"] for p in response.json()["results"]}
        assert "visible_event" in event_names
        assert "hidden_event1" in event_names
        assert "hidden_event2" in event_names

    def test_event_type_event(self):
        super(LicenseManager, cast(LicenseManager, License.objects)).create(
            plan="enterprise", valid_until=datetime(2500, 1, 19, 3, 14, 7)
        )
        EnterpriseEventDefinition.objects.create(team=self.demo_team, name="rated_app")
        EnterpriseEventDefinition.objects.create(team=self.demo_team, name="installed_app")

        response = self.client.get("/api/projects/@current/event_definitions/?search=app&event_type=event")
        assert response.status_code == status.HTTP_200_OK
        assert response.json()["count"] == 2
        assert [row["name"] for row in response.json()["results"]] == ["rated_app", "installed_app"]

    def test_create_event_definition_with_description(self):
        """Test creating an event definition with enterprise fields"""
        License.objects.create(key="test_key", plan="enterprise", valid_until=datetime(2500, 1, 19, 3, 14, 7))

        response = self.client.post(
            "/api/projects/@current/event_definitions/",
            {
                "name": "conversion_event",
                "description": "User completed a conversion action",
                "owner": self.user.id,
            },
        )

        assert response.status_code == status.HTTP_201_CREATED
        assert response.json()["name"] == "conversion_event"
        assert response.json()["description"] == "User completed a conversion action"
        assert response.json()["owner"]["id"] == self.user.id
        assert response.json()["created_at"] is None
        assert response.json()["last_seen_at"] is None

        # Verify it's an EnterpriseEventDefinition in the database
        event_def = EnterpriseEventDefinition.objects.get(name="conversion_event", team=self.demo_team)
        assert event_def.description == "User completed a conversion action"
        assert event_def.owner == self.user
        assert event_def.created_at is None
        assert event_def.last_seen_at is None

        # Verify activity log was created
        activity_log = ActivityLog.objects.filter(
            scope="EventDefinition", activity="created", item_id=str(event_def.id)
        ).first()
        assert activity_log is not None

    def test_create_event_definition_with_verified(self):
        """Test creating a verified event definition"""
        License.objects.create(key="test_key", plan="enterprise", valid_until=datetime(2500, 1, 19, 3, 14, 7))

        response = self.client.post(
            "/api/projects/@current/event_definitions/",
            {
                "name": "verified_event",
                "description": "This event is verified",
                "verified": True,
            },
        )

        assert response.status_code == status.HTTP_201_CREATED
        assert response.json()["verified"] is True
        assert response.json()["verified_by"]["id"] == self.user.id
        assert response.json()["verified_at"] is not None
        assert response.json()["hidden"] is False

        # Verify in database
        event_def = EnterpriseEventDefinition.objects.get(name="verified_event", team=self.demo_team)
        assert event_def.verified is True
        assert event_def.verified_by == self.user
        assert event_def.verified_at is not None

    def test_cannot_assign_owner_from_another_organization(self):
        """Owner must belong to the current organization (PATCH)."""
        License.objects.create(key="test_key", plan="enterprise", valid_until=datetime(2500, 1, 19, 3, 14, 7))

        other_org = create_organization(name="other org")
        other_user = create_user("other-user-patch@example.com", "pass", other_org)

        event = EnterpriseEventDefinition.objects.create(team=self.demo_team, name="owner_patch_event", owner=self.user)

        response = self.client.patch(
            f"/api/projects/@current/event_definitions/{event.id}/",
            {"owner": other_user.id},
        )

        assert response.status_code == status.HTTP_400_BAD_REQUEST
        assert other_user.email.encode() not in response.content

        event.refresh_from_db()
        assert event.owner_id == self.user.id

    def test_cannot_create_with_owner_from_another_organization(self):
        """Owner must belong to the current organization (POST)."""
        License.objects.create(key="test_key", plan="enterprise", valid_until=datetime(2500, 1, 19, 3, 14, 7))

        other_org = create_organization(name="other org")
        other_user = create_user("other-user-post@example.com", "pass", other_org)

        response = self.client.post(
            "/api/projects/@current/event_definitions/",
            {"name": "owner_post_event", "owner": other_user.id},
        )

        assert response.status_code == status.HTTP_400_BAD_REQUEST
        assert other_user.email.encode() not in response.content
        assert not EnterpriseEventDefinition.objects.filter(name="owner_post_event", team=self.demo_team).exists()

    def test_can_assign_owner_from_same_organization(self):
        """Assigning an owner who is in the same org should still work."""
        License.objects.create(key="test_key", plan="enterprise", valid_until=datetime(2500, 1, 19, 3, 14, 7))

        same_org_user = create_user("same-org@example.com", "pass", self.organization)

        event = EnterpriseEventDefinition.objects.create(
            team=self.demo_team, name="same_org_owner_event", owner=self.user
        )

        response = self.client.patch(
            f"/api/projects/@current/event_definitions/{event.id}/",
            {"owner": same_org_user.id},
        )

        assert response.status_code == status.HTTP_200_OK
        assert response.json()["owner"]["id"] == same_org_user.id

        event.refresh_from_db()
        assert event.owner_id == same_org_user.id

    def test_create_event_definition_with_hidden(self):
        """Test creating a hidden event definition"""
        License.objects.create(key="test_key", plan="enterprise", valid_until=datetime(2500, 1, 19, 3, 14, 7))

        response = self.client.post(
            "/api/projects/@current/event_definitions/",
            {
                "name": "hidden_event",
                "description": "This event is hidden",
                "hidden": True,
            },
        )

        assert response.status_code == status.HTTP_201_CREATED
        assert response.json()["hidden"] is True
        assert response.json()["verified"] is False

        # Verify in database
        event_def = EnterpriseEventDefinition.objects.get(name="hidden_event", team=self.demo_team)
        assert event_def.hidden is True
        assert event_def.verified is False

    def test_create_event_definition_cannot_be_both_hidden_and_verified(self):
        """Test that an event cannot be both hidden and verified"""
        License.objects.create(key="test_key", plan="enterprise", valid_until=datetime(2500, 1, 19, 3, 14, 7))

        response = self.client.post(
            "/api/projects/@current/event_definitions/",
            {
                "name": "conflicted_event",
                "verified": True,
                "hidden": True,
            },
        )

        assert response.status_code == status.HTTP_400_BAD_REQUEST

    def test_by_name_returns_enterprise_event_definition(self):
        super(LicenseManager, cast(LicenseManager, License.objects)).create(
            plan="enterprise", valid_until=datetime(2500, 1, 19, 3, 14, 7)
        )
        EnterpriseEventDefinition.objects.create(
            team=self.demo_team, name="by_name_event", owner=self.user, description="test desc"
        )

        response = self.client.get("/api/projects/@current/event_definitions/by_name/?name=by_name_event")
        assert response.status_code == status.HTTP_200_OK
        assert response.json()["name"] == "by_name_event"
        assert response.json()["description"] == "test desc"
        assert response.json()["owner"]["id"] == self.user.id

    def test_by_name_not_found(self):
        super(LicenseManager, cast(LicenseManager, License.objects)).create(
            plan="enterprise", valid_until=datetime(2500, 1, 19, 3, 14, 7)
        )

        response = self.client.get("/api/projects/@current/event_definitions/by_name/?name=nonexistent")
        assert response.status_code == status.HTTP_404_NOT_FOUND

    def test_list_media_preview_urls_no_n_plus_one(self):
        """List endpoint batch-fetches media preview URLs instead of querying per event."""
        from django.db import connection
        from django.test.utils import CaptureQueriesContext

        super(LicenseManager, cast(LicenseManager, License.objects)).create(
            plan="enterprise", valid_until=datetime(2500, 1, 19, 3, 14, 7)
        )

        # Create 5 events with media previews
        for i in range(5):
            event = EnterpriseEventDefinition.objects.create(team=self.demo_team, name=f"media_event_{i}")
            media = UploadedMedia.objects.create(
                team=self.demo_team, file_name=f"screenshot_{i}.png", content_type="image/png"
            )
            ObjectMediaPreview.objects.create(team=self.demo_team, event_definition=event, uploaded_media=media)

        with CaptureQueriesContext(connection) as ctx_baseline:
            response = self.client.get("/api/projects/@current/event_definitions/")
            assert response.status_code == status.HTTP_200_OK

        baseline_queries = len(ctx_baseline)

        # Add 10 more events with media previews
        for i in range(10):
            event = EnterpriseEventDefinition.objects.create(team=self.demo_team, name=f"extra_media_event_{i}")
            media = UploadedMedia.objects.create(
                team=self.demo_team, file_name=f"extra_{i}.png", content_type="image/png"
            )
            ObjectMediaPreview.objects.create(team=self.demo_team, event_definition=event, uploaded_media=media)

        with CaptureQueriesContext(connection) as ctx_more:
            response = self.client.get("/api/projects/@current/event_definitions/")
            assert response.status_code == status.HTTP_200_OK

        more_queries = len(ctx_more)

        # If N+1 exists, adding 10 events would add ~10 queries.
        # With batch fetching, query count should stay roughly constant.
        assert more_queries <= baseline_queries + 3, (
            f"Possible N+1: {baseline_queries} queries with 5 media events, {more_queries} queries with 15 media events"
        )

    def test_list_includes_media_preview_urls(self):
        """List endpoint returns media_preview_urls for each event definition."""
        super(LicenseManager, cast(LicenseManager, License.objects)).create(
            plan="enterprise", valid_until=datetime(2500, 1, 19, 3, 14, 7)
        )

        event = EnterpriseEventDefinition.objects.create(team=self.demo_team, name="event_with_media")
        media = UploadedMedia.objects.create(team=self.demo_team, file_name="screenshot.png", content_type="image/png")
        ObjectMediaPreview.objects.create(team=self.demo_team, event_definition=event, uploaded_media=media)

        response = self.client.get("/api/projects/@current/event_definitions/")
        assert response.status_code == status.HTTP_200_OK

        event_data = next(r for r in response.json()["results"] if r["name"] == "event_with_media")
        assert len(event_data["media_preview_urls"]) == 1
        assert "uploaded_media" in event_data["media_preview_urls"][0]

    def test_list_media_preview_urls_empty_when_no_media(self):
        """Events without media previews return empty media_preview_urls."""
        super(LicenseManager, cast(LicenseManager, License.objects)).create(
            plan="enterprise", valid_until=datetime(2500, 1, 19, 3, 14, 7)
        )

        response = self.client.get("/api/projects/@current/event_definitions/")
        assert response.status_code == status.HTTP_200_OK

        for result in response.json()["results"]:
            assert result["media_preview_urls"] == []
