import asyncio
from typing import Any

import pytest
from freezegun import freeze_time
from posthog.test.base import APIBaseTest
from unittest.mock import AsyncMock, MagicMock, call, patch

from parameterized import parameterized
from slack_sdk.errors import SlackApiError
from slack_sdk.web.async_slack_response import AsyncSlackResponse

from posthog.helpers.slack_scopes import REQUIRED_SLACK_SCOPES
from posthog.models.integration import Integration

from products.dashboards.backend.models.dashboard import Dashboard
from products.exports.backend.models.exported_asset import ExportedAsset
from products.exports.backend.models.subscription import Subscription
from products.product_analytics.backend.facade.models import Insight

from ee.tasks.subscriptions.slack_subscriptions import (
    _block_for_asset,
    _prepare_slack_message,
    send_slack_message_with_integration_async,
    send_slack_subscription_report,
)
from ee.tasks.subscriptions.subscription_utils import ASSET_GENERATION_FAILED_MESSAGE
from ee.tasks.test.subscriptions.subscriptions_test_factory import create_subscription


def _make_slack_api_error(error_code: str, **extra_data) -> SlackApiError:
    data = {"ok": False, "error": error_code, **extra_data}
    return SlackApiError(
        "Error",
        AsyncSlackResponse(
            client=None, http_verb="POST", api_url="", req_args={}, data=data, headers={}, status_code=200
        ),
    )


@patch("ee.tasks.subscriptions.slack_subscriptions.SlackIntegration")
@freeze_time("2022-02-02T08:30:00.000Z")
class TestSlackSubscriptionsTasks(APIBaseTest):
    subscription: Subscription
    dashboard: Dashboard
    insight: Insight
    asset: ExportedAsset
    integration: Integration

    def setUp(self) -> None:
        self.dashboard = Dashboard.objects.create(team=self.team, name="private dashboard", created_by=self.user)
        self.insight = Insight.objects.create(team=self.team, short_id="123456", name="My Test subscription")
        self.asset = ExportedAsset.objects.create(
            team=self.team,
            insight_id=self.insight.id,
            export_format="image/png",
            content_location="s3://bucket/test.png",
        )
        self.subscription = create_subscription(
            team=self.team,
            insight=self.insight,
            created_by=self.user,
            target_type="slack",
            target_value="C12345|#test-channel",
        )

        self.integration = Integration.objects.create(team=self.team, kind="slack")

    def test_subscription_delivery(self, MockSlackIntegration: MagicMock) -> None:
        mock_slack_integration = MagicMock()
        MockSlackIntegration.return_value = mock_slack_integration
        mock_slack_integration.client.chat_postMessage.return_value = {"ts": "1.234"}

        send_slack_subscription_report(self.subscription, [self.asset], 1)

        assert mock_slack_integration.client.chat_postMessage.call_count == 1
        post_message_calls = mock_slack_integration.client.chat_postMessage.call_args_list
        first_call = post_message_calls[0].kwargs

        assert first_call["channel"] == "C12345"
        assert first_call["text"] == "Your subscription to the Insight *My Test subscription* is ready! 🎉"
        # Links in the report (explore hint, AI summary) must not auto-unfurl into preview cards.
        assert first_call["unfurl_links"] is False
        assert first_call["unfurl_media"] is False
        assert first_call["blocks"] == [
            {
                "type": "section",
                "text": {
                    "type": "mrkdwn",
                    "text": "Your subscription to the Insight *My Test subscription* is ready! 🎉",
                },
            },
            {
                "type": "image",
                "image_url": post_message_calls[0].kwargs["blocks"][1]["image_url"],
                "alt_text": "My Test subscription",
            },
            {"type": "divider"},
            {
                "type": "actions",
                "elements": [
                    {
                        "type": "button",
                        "text": {"type": "plain_text", "text": "View in PostHog"},
                        "url": "http://localhost:8010/insights/123456?utm_source=posthog&utm_campaign=subscription_report&utm_medium=slack",
                    },
                    {
                        "type": "button",
                        "text": {"type": "plain_text", "text": "Manage Subscription"},
                        "url": f"http://localhost:8010/insights/123456/subscriptions/{self.subscription.id}?utm_source=posthog&utm_campaign=subscription_report&utm_medium=slack",
                    },
                ],
            },
            {
                "type": "context",
                "elements": [
                    {
                        "type": "mrkdwn",
                        "text": "💬 <https://posthog.com/docs/slack-app?utm_source=posthog&utm_campaign=subscription_report&utm_medium=slack|Set up the @PostHog bot> to ask follow-up questions about your reports here.",
                    }
                ],
            },
        ]

    @parameterized.expand(
        [
            (
                "recurring_without_title",
                None,
                False,
                "Your subscription to the Insight *My Test subscription* is ready! 🎉",
            ),
            (
                "recurring_with_title",
                "Weekly KPI Report",
                False,
                "Your subscription to *Weekly KPI Report* (Insight: My Test subscription) is ready! 🎉",
            ),
            (
                "new_without_title",
                None,
                True,
                "This channel has been subscribed to the Insight *My Test subscription* on PostHog! 🎉\nThis subscription is sent every day. The next one will be sent on Wednesday February 02, 2022",
            ),
            (
                "new_with_title",
                "Weekly KPI Report",
                True,
                "This channel has been subscribed to *Weekly KPI Report* (Insight: My Test subscription) on PostHog! 🎉\nThis subscription is sent every day. The next one will be sent on Wednesday February 02, 2022",
            ),
        ]
    )
    def test_subscription_delivery_title(
        self, MockSlackIntegration: MagicMock, _name: str, title: str | None, is_new: bool, expected_text: str
    ) -> None:
        mock_slack_integration = MagicMock()
        MockSlackIntegration.return_value = mock_slack_integration
        mock_slack_integration.client.chat_postMessage.return_value = {"ts": "1.234"}

        if title:
            self.subscription.title = title
            self.subscription.save()

        send_slack_subscription_report(self.subscription, [self.asset], 1, is_new_subscription=is_new)

        assert mock_slack_integration.client.chat_postMessage.call_count == 1
        first_call = mock_slack_integration.client.chat_postMessage.call_args_list[0].kwargs
        assert first_call["text"] == expected_text

    def test_subscription_dashboard_delivery(self, MockSlackIntegration: MagicMock) -> None:
        mock_slack_integration = MagicMock()
        MockSlackIntegration.return_value = mock_slack_integration
        mock_slack_integration.client.chat_postMessage.return_value = {"ts": "1.234"}

        self.subscription = create_subscription(
            team=self.team,
            dashboard=self.dashboard,
            created_by=self.user,
            target_type="slack",
            target_value="C12345|#test-channel",
        )

        send_slack_subscription_report(self.subscription, [self.asset, self.asset, self.asset], 10)

        assert mock_slack_integration.client.chat_postMessage.call_count == 4
        post_message_calls = mock_slack_integration.client.chat_postMessage.call_args_list
        first_call = post_message_calls[0].kwargs

        assert first_call["channel"] == "C12345"
        assert first_call["text"] == "Your subscription to the Dashboard *private dashboard* is ready! 🎉"

        assert first_call["blocks"] == [
            {
                "type": "section",
                "text": {
                    "type": "mrkdwn",
                    "text": "Your subscription to the Dashboard *private dashboard* is ready! 🎉",
                },
            },
            {
                "type": "image",
                "image_url": post_message_calls[0].kwargs["blocks"][1]["image_url"],
                "alt_text": "My Test subscription",
            },
            {
                "type": "section",
                "text": {"type": "mrkdwn", "text": "_See 🧵 for more Insights_"},
            },
            {"type": "divider"},
            {
                "type": "actions",
                "elements": [
                    {
                        "type": "button",
                        "text": {"type": "plain_text", "text": "View in PostHog"},
                        "url": f"http://localhost:8010/dashboard/{self.dashboard.id}?utm_source=posthog&utm_campaign=subscription_report&utm_medium=slack",
                    },
                    {
                        "type": "button",
                        "text": {"type": "plain_text", "text": "Manage Subscription"},
                        "url": f"http://localhost:8010/dashboard/{self.dashboard.id}/subscriptions/{self.subscription.id}?utm_source=posthog&utm_campaign=subscription_report&utm_medium=slack",
                    },
                ],
            },
            {
                "type": "context",
                "elements": [
                    {
                        "type": "mrkdwn",
                        "text": "💬 <https://posthog.com/docs/slack-app?utm_source=posthog&utm_campaign=subscription_report&utm_medium=slack|Set up the @PostHog bot> to ask follow-up questions about your reports here.",
                    }
                ],
            },
        ]

        # Second call - other asset
        second_call = post_message_calls[1].kwargs
        assert second_call["channel"] == "C12345"
        assert second_call["thread_ts"] == "1.234"
        assert second_call["blocks"] == [
            {
                "type": "image",
                "image_url": second_call["blocks"][0]["image_url"],
                "alt_text": "My Test subscription",
            }
        ]

        # Third call - other asset
        third_call = post_message_calls[2].kwargs
        assert third_call["blocks"] == [
            {
                "type": "image",
                "image_url": third_call["blocks"][0]["image_url"],
                "alt_text": "My Test subscription",
            }
        ]

        # Fourth call - notice that more exists
        fourth_call = post_message_calls[3].kwargs
        assert fourth_call["blocks"] == [
            {
                "type": "section",
                "text": {
                    "type": "mrkdwn",
                    "text": f"Showing 3 of 10 Insights. <http://localhost:8010/dashboard/{self.dashboard.id}?utm_source=posthog&utm_campaign=subscription_report&utm_medium=slack|View the rest in PostHog>",
                },
            }
        ]

    def test_subscription_delivery_missing_integration(self, MockSlackIntegration: MagicMock) -> None:
        mock_slack_integration = MagicMock()
        MockSlackIntegration.return_value = mock_slack_integration

        self.integration.delete()

        send_slack_subscription_report(self.subscription, [self.asset], 1)

        assert mock_slack_integration.client.chat_postMessage.call_count == 0

        # TODO: Should we perhaps save something to say the Subscription failed?


@patch("ee.tasks.subscriptions.slack_subscriptions.SlackIntegration")
@freeze_time("2025-01-01T08:30:00.000Z")
class TestSlackSubscriptionsAsyncTasks(APIBaseTest):
    TOTAL_ASSET_COUNT = 10

    subscription: Subscription
    dashboard: Dashboard
    insight: Insight
    asset: ExportedAsset
    integration: Integration

    def setUp(self) -> None:
        self.dashboard = Dashboard.objects.create(team=self.team, name="private dashboard", created_by=self.user)
        self.insight = Insight.objects.create(team=self.team, short_id="123456", name="My Test subscription")
        self.asset = ExportedAsset.objects.create(
            team=self.team,
            insight_id=self.insight.id,
            export_format="image/png",
            content_location="s3://bucket/test.png",
        )
        self.subscription = create_subscription(
            team=self.team,
            dashboard=self.dashboard,
            created_by=self.user,
            target_type="slack",
            target_value="C12345|#test-channel",
        )
        self.integration = Integration.objects.create(team=self.team, kind="slack")

    def _setup_async_mock(self, MockSlackIntegration: MagicMock) -> AsyncMock:
        mock_slack_integration = MagicMock()
        MockSlackIntegration.return_value = mock_slack_integration
        mock_async_client = AsyncMock()
        mock_slack_integration.async_client = MagicMock(return_value=mock_async_client)
        return mock_async_client

    def test_async_delivery_builds_message_off_event_loop(self, MockSlackIntegration: MagicMock) -> None:
        # Regression: `_prepare_slack_message` reads lazily-loaded ORM relations
        # (e.g. integration.team.organization), so it must be built in a worker thread,
        # never directly on the event loop where Django raises SynchronousOnlyOperation.
        mock_async_client = self._setup_async_mock(MockSlackIntegration)
        mock_async_client.chat_postMessage.return_value = {"ts": "1.234"}

        real_prepare = _prepare_slack_message
        ran_on_event_loop: list[bool] = []

        def _spy(*args: Any, **kwargs: Any) -> Any:
            try:
                asyncio.get_running_loop()
                ran_on_event_loop.append(True)
            except RuntimeError:
                ran_on_event_loop.append(False)
            return real_prepare(*args, **kwargs)

        # The build runs in a worker thread whose connection can't see this test's
        # transaction, so every relation it reads must already be cached: assets via
        # select_related, subscription/integration via the cached setUp instances.
        assets = list(ExportedAsset.objects.filter(id=self.asset.id).select_related("insight"))

        with patch("ee.tasks.subscriptions.slack_subscriptions._prepare_slack_message", side_effect=_spy):
            result = asyncio.run(
                send_slack_message_with_integration_async(
                    self.integration, self.subscription, assets, self.TOTAL_ASSET_COUNT
                )
            )

        assert ran_on_event_loop == [False]
        assert result.is_complete_success
        mock_async_client.chat_postMessage.assert_awaited()

    def test_async_delivery_all_message_success(self, MockSlackIntegration: MagicMock) -> None:
        mock_async_client = self._setup_async_mock(MockSlackIntegration)
        mock_async_client.chat_postMessage.return_value = {"ts": "1.234"}

        asset2 = ExportedAsset.objects.create(
            team=self.team,
            insight_id=self.insight.id,
            export_format="image/png",
            content_location="s3://bucket/test2.png",
        )
        asset3 = ExportedAsset.objects.create(
            team=self.team,
            insight_id=self.insight.id,
            export_format="image/png",
            content_location="s3://bucket/test3.png",
        )
        assets = list(
            ExportedAsset.objects.filter(id__in=[self.asset.id, asset2.id, asset3.id]).select_related("insight")
        )

        result = asyncio.run(
            send_slack_message_with_integration_async(
                self.integration, self.subscription, assets, self.TOTAL_ASSET_COUNT
            )
        )

        # Should have called chat_postMessage 4 times (1 main + 2 thread + 1 "showing X of Y")
        assert mock_async_client.chat_postMessage.call_count == 4
        assert result.is_complete_success
        assert not result.is_partial_failure
        assert result.main_message_sent
        assert len(result.failed_thread_message_indices) == 0
        assert result.total_thread_messages == 3

    @patch("ee.tasks.subscriptions.slack_subscriptions.asyncio.sleep", new_callable=AsyncMock)
    def test_async_delivery_partial_success(self, mock_sleep: AsyncMock, MockSlackIntegration: MagicMock) -> None:
        """Test that thread message timeouts are retried and result in partial success."""
        mock_async_client = self._setup_async_mock(MockSlackIntegration)

        mock_async_client.chat_postMessage.side_effect = [
            {"ts": "1.234"},  # Main message
            {"ts": "2.345"},  # First thread message (asset 2)
            TimeoutError(),  # Second thread message (asset 3) attempt 1
            TimeoutError(),  # Second thread message (asset 3) attempt 2
            TimeoutError(),  # Second thread message (asset 3) attempt 3 (final failure)
            {"ts": "3.456"},  # Third thread message "Showing 3 of 10"
        ]

        asset2 = ExportedAsset.objects.create(
            team=self.team,
            insight_id=self.insight.id,
            export_format="image/png",
            content_location="s3://bucket/test2.png",
        )
        asset3 = ExportedAsset.objects.create(
            team=self.team,
            insight_id=self.insight.id,
            export_format="image/png",
            content_location="s3://bucket/test3.png",
        )
        assets = list(
            ExportedAsset.objects.filter(id__in=[self.asset.id, asset2.id, asset3.id]).select_related("insight")
        )

        result = asyncio.run(
            send_slack_message_with_integration_async(
                self.integration, self.subscription, assets, self.TOTAL_ASSET_COUNT
            )
        )

        assert mock_async_client.chat_postMessage.call_count == 6
        assert result.is_partial_failure
        assert not result.is_complete_success
        assert result.main_message_sent
        assert result.failed_thread_message_indices == [1]  # Second thread message (index 1)
        assert result.total_thread_messages == 3

    @patch("ee.tasks.subscriptions.slack_subscriptions.asyncio.sleep", new_callable=AsyncMock)
    def test_async_delivery_main_message_timeout_raises(
        self, mock_sleep: AsyncMock, MockSlackIntegration: MagicMock
    ) -> None:
        mock_async_client = self._setup_async_mock(MockSlackIntegration)

        mock_async_client.chat_postMessage.side_effect = [
            TimeoutError(),  # Attempt 1
            TimeoutError(),  # Attempt 2
            TimeoutError(),  # Attempt 3 (final)
        ]

        assets = list(ExportedAsset.objects.filter(id=self.asset.id).select_related("insight")[:1])

        with self.assertRaises(TimeoutError):
            asyncio.run(
                send_slack_message_with_integration_async(
                    self.integration, self.subscription, assets, self.TOTAL_ASSET_COUNT
                )
            )

        assert mock_async_client.chat_postMessage.call_count == 3

    @patch("ee.tasks.subscriptions.slack_subscriptions.asyncio.sleep", new_callable=AsyncMock)
    def test_async_delivery_retry_succeeds_on_second_attempt(
        self, mock_sleep: AsyncMock, MockSlackIntegration: MagicMock
    ) -> None:
        """Test that retry logic succeeds on second attempt."""
        mock_async_client = self._setup_async_mock(MockSlackIntegration)

        # Main message times out once, then succeeds
        mock_async_client.chat_postMessage.side_effect = [
            TimeoutError(),  # First attempt fails
            {"ts": "1.234"},  # Second attempt succeeds
            {"ts": "2.345"},  # First thread message "Showing 1 of 10"
        ]

        assets = list(ExportedAsset.objects.filter(id=self.asset.id).select_related("insight")[:1])

        result = asyncio.run(
            send_slack_message_with_integration_async(
                self.integration, self.subscription, assets, self.TOTAL_ASSET_COUNT
            )
        )

        assert mock_async_client.chat_postMessage.call_count == 3
        assert result.is_complete_success
        assert result.main_message_sent

    @patch("ee.tasks.subscriptions.slack_subscriptions.asyncio.sleep", new_callable=AsyncMock)
    def test_async_delivery_retry_on_invalid_blocks_failure(
        self, mock_sleep: AsyncMock, MockSlackIntegration: MagicMock
    ) -> None:
        mock_async_client = self._setup_async_mock(MockSlackIntegration)

        slack_error = _make_slack_api_error(
            "invalid_blocks", errors=["downloading image failed [json-pointer:/blocks/0/image_url]"]
        )

        mock_async_client.chat_postMessage.side_effect = [slack_error, slack_error, slack_error]
        assets = list(ExportedAsset.objects.filter(id=self.asset.id).select_related("insight"))

        with pytest.raises(SlackApiError):
            asyncio.run(
                send_slack_message_with_integration_async(
                    self.integration, self.subscription, assets, self.TOTAL_ASSET_COUNT
                )
            )

        assert mock_async_client.chat_postMessage.call_count == 3
        mock_sleep.assert_has_awaits([call(1), call(2)])

    @patch("ee.tasks.subscriptions.slack_subscriptions.asyncio.sleep", new_callable=AsyncMock)
    def test_async_delivery_retry_on_invalid_blocks_success(
        self, mock_sleep: AsyncMock, MockSlackIntegration: MagicMock
    ) -> None:
        mock_async_client = self._setup_async_mock(MockSlackIntegration)

        slack_error = _make_slack_api_error(
            "invalid_blocks", errors=["downloading image failed [json-pointer:/blocks/0/image_url]"]
        )

        mock_async_client.chat_postMessage.side_effect = [
            slack_error,
            {"ts": "1.234"},
            {"ts": "2.345"},
        ]
        assets = list(ExportedAsset.objects.filter(id=self.asset.id).select_related("insight"))

        result = asyncio.run(
            send_slack_message_with_integration_async(
                self.integration, self.subscription, assets, self.TOTAL_ASSET_COUNT
            )
        )

        assert mock_async_client.chat_postMessage.call_count == 3
        assert result.is_complete_success
        mock_sleep.assert_awaited_once_with(1)

    @parameterized.expand(
        [
            ("internal_error",),
            ("service_unavailable",),
            ("fatal_error",),
            ("request_timeout",),
            ("ratelimited",),
            ("rate_limited",),
        ]
    )
    def test_async_delivery_retries_transient_slack_errors_and_exhausts(
        self,
        MockSlackIntegration: MagicMock,
        slack_error_code: str,
    ) -> None:
        mock_async_client = self._setup_async_mock(MockSlackIntegration)

        slack_error = _make_slack_api_error(slack_error_code)

        mock_async_client.chat_postMessage.side_effect = [slack_error, slack_error, slack_error]
        assets = list(ExportedAsset.objects.filter(id=self.asset.id).select_related("insight"))

        with patch("ee.tasks.subscriptions.slack_subscriptions.asyncio.sleep", new_callable=AsyncMock) as mock_sleep:
            with pytest.raises(SlackApiError):
                asyncio.run(
                    send_slack_message_with_integration_async(
                        self.integration, self.subscription, assets, self.TOTAL_ASSET_COUNT
                    )
                )

            # Three attempts (max_retries=3), with backoff sleeps between attempts
            assert mock_async_client.chat_postMessage.call_count == 3
            mock_sleep.assert_has_awaits([call(1), call(2)])

    @patch("ee.tasks.subscriptions.slack_subscriptions.asyncio.sleep", new_callable=AsyncMock)
    def test_async_delivery_retry_on_internal_error_success(
        self, mock_sleep: AsyncMock, MockSlackIntegration: MagicMock
    ) -> None:
        """First attempt hits Slack `internal_error` (transient 5xx-equivalent); second attempt succeeds."""
        mock_async_client = self._setup_async_mock(MockSlackIntegration)

        slack_error = _make_slack_api_error("internal_error")

        mock_async_client.chat_postMessage.side_effect = [
            slack_error,  # Main message attempt 1 — transient failure
            {"ts": "1.234"},  # Main message attempt 2 — success
            {"ts": "2.345"},  # Thread "Showing 1 of 10" message
        ]
        assets = list(ExportedAsset.objects.filter(id=self.asset.id).select_related("insight"))

        result = asyncio.run(
            send_slack_message_with_integration_async(
                self.integration, self.subscription, assets, self.TOTAL_ASSET_COUNT
            )
        )

        assert mock_async_client.chat_postMessage.call_count == 3
        assert result.is_complete_success
        mock_sleep.assert_awaited_once_with(1)

    @parameterized.expand(
        [
            ("channel_not_found",),
            ("invalid_auth",),
            ("not_in_channel",),
            ("token_revoked",),
            ("missing_scope",),
        ]
    )
    def test_async_delivery_fails_fast_on_non_retryable_slack_errors(
        self,
        MockSlackIntegration: MagicMock,
        slack_error_code: str,
    ) -> None:
        """Permanent Slack errors (config issues) should NOT be retried — fail on first attempt."""
        mock_async_client = self._setup_async_mock(MockSlackIntegration)

        slack_error = _make_slack_api_error(slack_error_code)

        mock_async_client.chat_postMessage.side_effect = [slack_error]
        assets = list(ExportedAsset.objects.filter(id=self.asset.id).select_related("insight"))

        with patch("ee.tasks.subscriptions.slack_subscriptions.asyncio.sleep", new_callable=AsyncMock) as mock_sleep:
            with pytest.raises(SlackApiError):
                asyncio.run(
                    send_slack_message_with_integration_async(
                        self.integration, self.subscription, assets, self.TOTAL_ASSET_COUNT
                    )
                )

            # Single attempt — no retries, no sleeps
            assert mock_async_client.chat_postMessage.call_count == 1
            mock_sleep.assert_not_awaited()


class TestSlackErrorTruncation(APIBaseTest):
    def setUp(self) -> None:
        self.insight = Insight.objects.create(team=self.team, short_id="123456", name="My Test subscription")

    def test_block_for_asset_with_short_error(self) -> None:
        short_error = "Code: 42. DB::Exception: Received from clickhouse:9000."
        asset = ExportedAsset.objects.create(
            team=self.team, insight_id=self.insight.id, export_format="image/png", exception=short_error
        )

        block = _block_for_asset(asset, resource_url="https://app.posthog.com/insights/123456")

        assert block["type"] == "section"
        assert short_error in block["text"]["text"]
        assert "truncated" not in block["text"]["text"]
        assert len(block["text"]["text"]) < 3000

    def test_block_for_asset_with_long_error(self) -> None:
        long_error = "A" * 5000
        asset = ExportedAsset.objects.create(
            team=self.team, insight_id=self.insight.id, export_format="image/png", exception=long_error
        )

        block = _block_for_asset(asset, resource_url="https://app.posthog.com/insights/123456")

        assert block["type"] == "section"
        text = block["text"]["text"]
        assert "truncated" in text
        assert len(text) < 3000
        assert "*My Test subscription*" in text
        assert "There was an error generating your asset:" in text

    def test_block_for_asset_without_content_or_location(self) -> None:
        asset = ExportedAsset.objects.create(team=self.team, insight_id=self.insight.id, export_format="image/png")

        block = _block_for_asset(asset, resource_url="https://app.posthog.com/insights/123456")

        assert block["type"] == "section"
        text = block["text"]["text"]
        assert "*My Test subscription*" in text
        assert ASSET_GENERATION_FAILED_MESSAGE in text

    def test_block_for_asset_hides_out_of_memory_cause(self) -> None:
        oom_error = (
            "This query ran out of memory before it could finish, usually because it's scanning too "
            "much data. Try a shorter date range or narrower filters."
        )
        asset = ExportedAsset.objects.create(
            team=self.team, insight_id=self.insight.id, export_format="image/png", exception=oom_error
        )

        block = _block_for_asset(asset, resource_url="https://app.posthog.com/insights/123456")

        text = block["text"]["text"]
        assert "ran out of memory" not in text
        assert "shorter date range" not in text
        assert ASSET_GENERATION_FAILED_MESSAGE in text


class TestSlackSummaryNotice(APIBaseTest):
    def setUp(self) -> None:
        self.insight = Insight.objects.create(team=self.team, short_id="123456", name="My Test subscription")
        self.asset = ExportedAsset.objects.create(
            team=self.team,
            insight_id=self.insight.id,
            export_format="image/png",
            content_location="s3://bucket/test.png",
        )
        self.subscription = create_subscription(
            team=self.team,
            insight=self.insight,
            created_by=self.user,
            target_type="slack",
            target_value="C12345|#test-channel",
        )

    def _block_texts(self, change_summary: str | None, summary_skipped_over_budget: bool) -> list[str]:
        message = _prepare_slack_message(
            self.subscription,
            [self.asset],
            total_asset_count=1,
            change_summary=change_summary,
            summary_skipped_over_budget=summary_skipped_over_budget,
        )
        return [block.get("text", {}).get("text", "") for block in message.blocks] + [
            element.get("text", "")
            for block in message.blocks
            for element in block.get("elements", [])
            if isinstance(element, dict)
        ]

    def test_shows_over_budget_notice_when_summary_skipped(self) -> None:
        texts = self._block_texts(change_summary=None, summary_skipped_over_budget=True)
        notice = next((t for t in texts if "AI summary skipped" in t), None)
        assert notice is not None
        # "Billing settings" is an inline mrkdwn link (<url|label>) in the notice text itself.
        assert "/organization/billing" in notice
        assert "|Billing settings>" in notice

    def test_no_notice_when_summary_present(self) -> None:
        # A generated summary wins — the over-budget notice never doubles up with it.
        texts = self._block_texts(change_summary="- trending up", summary_skipped_over_budget=True)
        assert any("*AI summary:*" in text for text in texts)
        assert all("AI summary skipped" not in text for text in texts)

    def test_no_notice_when_under_budget_and_no_summary(self) -> None:
        texts = self._block_texts(change_summary=None, summary_skipped_over_budget=False)
        assert all("AI summary skipped" not in text for text in texts)


class TestSlackExploreHint(APIBaseTest):
    def setUp(self) -> None:
        self.insight = Insight.objects.create(team=self.team, short_id="123456", name="My Test subscription")
        self.asset = ExportedAsset.objects.create(
            team=self.team,
            insight_id=self.insight.id,
            export_format="image/png",
            content_location="s3://bucket/test.png",
        )
        self.subscription = create_subscription(
            team=self.team,
            insight=self.insight,
            created_by=self.user,
            target_type="slack",
            target_value="C12345|#test-channel",
        )

    def _hint_texts(self, integration: Integration | None) -> list[str]:
        message = _prepare_slack_message(
            self.subscription,
            [self.asset],
            total_asset_count=1,
            integration=integration,
        )
        return [el["text"] for block in message.blocks if block.get("type") == "context" for el in block["elements"]]

    def _make_integration(self, scopes: frozenset[str]) -> Integration:
        return Integration.objects.create(
            team=self.team,
            kind="slack",
            integration_id="T12345",
            config={"scope": ",".join(sorted(scopes))},
            sensitive_config={"access_token": "xoxb-test"},
        )

    def test_no_hint_without_integration(self) -> None:
        assert self._hint_texts(None) == []

    def test_bot_ready_hint_nudges_mention(self) -> None:
        texts = self._hint_texts(self._make_integration(REQUIRED_SLACK_SCOPES))
        assert any("@PostHog" in t and "docs/slack-app" not in t for t in texts)

    def test_bot_not_ready_hint_links_docs(self) -> None:
        texts = self._hint_texts(self._make_integration(frozenset({"chat:write"})))
        assert any("docs/slack-app" in t for t in texts)
        assert not any("Reply in this thread" in t for t in texts)

    def test_no_hint_when_ai_not_approved(self) -> None:
        org = self.team.organization
        org.is_ai_data_processing_approved = False
        org.save()
        assert self._hint_texts(self._make_integration(REQUIRED_SLACK_SCOPES)) == []
