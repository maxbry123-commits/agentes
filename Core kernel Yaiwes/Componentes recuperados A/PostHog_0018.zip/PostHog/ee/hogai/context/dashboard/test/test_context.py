import asyncio

from posthog.test.base import BaseTest
from unittest.mock import AsyncMock, patch

from posthog.schema import EventsNode, TrendsQuery

from ee.hogai.context.dashboard.context import DashboardContext, DashboardInsightContext


class TestDashboardContext(BaseTest):
    async def test_execute_with_no_insights(self):
        """Test that execute returns formatted dashboard with no insights"""
        dashboard_ctx = DashboardContext(
            team=self.team,
            insights_data=[],
            user=self.user,
            name="Empty Dashboard",
            description="A dashboard with no insights",
            dashboard_id="123",
        )

        result = await dashboard_ctx.execute_and_format()

        self.assertIn("Dashboard name: Empty Dashboard", result)
        self.assertIn("Dashboard ID: 123", result)
        self.assertIn("Description: A dashboard with no insights", result)

    @patch("ee.hogai.context.insight.context.execute_and_format_query")
    async def test_execute_with_single_insight(self, mock_execute):
        """Test that execute runs a single insight and formats the result"""
        mock_execute.return_value = "Insight results: 100 users"

        insights_data: list[DashboardInsightContext] = [
            DashboardInsightContext(
                query=TrendsQuery(series=[EventsNode(event="pageview")]),
                name="Test Insight",
                description="Test description",
                insight_id="insight-1",
            )
        ]

        dashboard_ctx = DashboardContext(
            team=self.team,
            insights_data=insights_data,
            user=self.user,
            name="Test Dashboard",
            description="Dashboard description",
            dashboard_id="456",
        )

        result = await dashboard_ctx.execute_and_format()

        self.assertIn("Dashboard name: Test Dashboard", result)
        self.assertIn("Dashboard ID: 456", result)
        self.assertIn("Description: Dashboard description", result)
        self.assertIn("Test Insight", result)
        self.assertIn("Insight results: 100 users", result)
        mock_execute.assert_called_once()

    @patch("ee.hogai.context.insight.context.execute_and_format_query")
    async def test_execute_with_multiple_insights(self, mock_execute):
        """Test that execute runs multiple insights in parallel"""
        mock_execute.side_effect = [
            "First insight results",
            "Second insight results",
            "Third insight results",
        ]

        insights_data: list[DashboardInsightContext] = [
            DashboardInsightContext(
                query=TrendsQuery(series=[EventsNode(event="pageview")]),
                name=f"Insight {i}",
                insight_id=f"insight-{i}",
            )
            for i in range(1, 4)
        ]

        dashboard_ctx = DashboardContext(
            team=self.team,
            insights_data=insights_data,
            user=self.user,
            name="Multi-Insight Dashboard",
            dashboard_id="789",
        )

        result = await dashboard_ctx.execute_and_format()

        self.assertIn("Dashboard name: Multi-Insight Dashboard", result)
        self.assertIn("Insight 1", result)
        self.assertIn("Insight 2", result)
        self.assertIn("Insight 3", result)
        self.assertIn("First insight results", result)
        self.assertIn("Second insight results", result)
        self.assertIn("Third insight results", result)
        self.assertEqual(mock_execute.call_count, 3)

    @patch("ee.hogai.context.insight.context.execute_and_format_query")
    async def test_execute_with_failed_insights(self, mock_execute):
        """Test that execute handles failed insights gracefully"""
        mock_execute.side_effect = [
            "Success result",
            Exception("Query failed"),
            "Another success",
        ]

        insights_data: list[DashboardInsightContext] = [
            DashboardInsightContext(
                query=TrendsQuery(series=[EventsNode(event="pageview")]),
                name=f"Insight {i}",
                insight_id=f"insight-{i}",
            )
            for i in range(1, 4)
        ]

        dashboard_ctx = DashboardContext(
            team=self.team,
            insights_data=insights_data,
            user=self.user,
            name="Partially Failed Dashboard",
            dashboard_id="101",
        )

        result = await dashboard_ctx.execute_and_format()

        self.assertIn("Dashboard name: Partially Failed Dashboard", result)
        self.assertIn("Success result", result)
        self.assertIn("Another success", result)
        # Failed insight error message should be in results
        self.assertIn("Error executing query", result)

    async def test_format_schema_with_no_insights(self):
        """Test that format_schema returns formatted dashboard without execution"""
        dashboard_ctx = DashboardContext(
            team=self.team,
            insights_data=[],
            user=self.user,
            name="Schema Dashboard",
            description="Dashboard for schema test",
            dashboard_id="202",
        )

        result = await dashboard_ctx.format_schema()

        self.assertIn("Dashboard name: Schema Dashboard", result)
        self.assertIn("Dashboard ID: 202", result)
        self.assertIn("Description: Dashboard for schema test", result)

    async def test_format_schema_with_insights(self):
        """Test that format_schema returns insight schemas without execution"""
        insights_data: list[DashboardInsightContext] = [
            DashboardInsightContext(
                query=TrendsQuery(series=[EventsNode(event="pageview")]),
                name="Schema Insight 1",
                description="First insight",
                insight_id="insight-1",
            ),
            DashboardInsightContext(
                query=TrendsQuery(series=[EventsNode(event="click")]),
                name="Schema Insight 2",
                insight_id="insight-2",
            ),
        ]

        dashboard_ctx = DashboardContext(
            team=self.team,
            insights_data=insights_data,
            user=self.user,
            name="Schema Dashboard",
            dashboard_id="303",
        )

        result = await dashboard_ctx.format_schema()

        self.assertIn("Dashboard name: Schema Dashboard", result)
        self.assertIn("Schema Insight 1", result)
        self.assertIn("Schema Insight 2", result)
        self.assertIn("First insight", result)
        # Schema should include query JSON
        self.assertIn("TrendsQuery", result)
        # Should NOT include results
        self.assertNotIn("Results:", result)

    @patch("ee.hogai.context.dashboard.context.capture_exception")
    @patch("ee.hogai.context.insight.context.InsightContext.format_schema", new_callable=AsyncMock)
    async def test_format_schema_propagates_cancellation(self, mock_format_schema, mock_capture):
        # Cancellation must propagate through the schema path too, never degrade or get captured.
        mock_format_schema.side_effect = asyncio.CancelledError()

        insights_data: list[DashboardInsightContext] = [
            DashboardInsightContext(
                query=TrendsQuery(series=[EventsNode(event="pageview")]),
                name="Cancelled Insight",
                short_id="insight-1",
            )
        ]

        dashboard_ctx = DashboardContext(
            team=self.team,
            insights_data=insights_data,
            user=self.user,
            name="Error Dashboard",
            dashboard_id="404",
        )

        with self.assertRaises(asyncio.CancelledError):
            await dashboard_ctx.format_schema()

        mock_capture.assert_not_called()

    async def test_dashboard_without_id(self):
        """Test that dashboard works without an ID"""
        dashboard_ctx = DashboardContext(
            team=self.team,
            insights_data=[],
            user=self.user,
            name="No ID Dashboard",
        )

        result = await dashboard_ctx.format_schema()

        self.assertIn("Dashboard name: No ID Dashboard", result)
        self.assertNotIn("Dashboard ID:", result)
        self.assertNotIn("Dashboard URL:", result)

    async def test_dashboard_without_name(self):
        """Test that dashboard works without a name"""
        dashboard_ctx = DashboardContext(
            team=self.team,
            insights_data=[],
            user=self.user,
            dashboard_id="606",
        )

        result = await dashboard_ctx.format_schema()

        self.assertIn("Dashboard name: Dashboard", result)
        self.assertIn("Dashboard ID: 606", result)
        self.assertIn("Dashboard URL: /dashboard/606", result)

    async def test_dashboard_url_included_in_format_schema(self):
        dashboard_ctx = DashboardContext(
            team=self.team,
            insights_data=[],
            user=self.user,
            name="URL Test Dashboard",
            dashboard_id="12345",
        )

        result = await dashboard_ctx.format_schema()

        self.assertIn("Dashboard URL: /dashboard/12345", result)

    @patch("ee.hogai.context.insight.context.execute_and_format_query")
    async def test_dashboard_url_included_in_execute_and_format(self, mock_execute):
        mock_execute.return_value = "Result"

        insights_data: list[DashboardInsightContext] = [
            DashboardInsightContext(
                query=TrendsQuery(series=[EventsNode(event="pageview")]),
                name="Test Insight",
                insight_id="insight-1",
            )
        ]

        dashboard_ctx = DashboardContext(
            team=self.team,
            insights_data=insights_data,
            user=self.user,
            name="URL Test Dashboard",
            dashboard_id="67890",
        )

        result = await dashboard_ctx.execute_and_format()

        self.assertIn("Dashboard URL: /dashboard/67890", result)

    @patch("ee.hogai.context.insight.context.execute_and_format_query")
    async def test_custom_max_concurrent_queries(self, mock_execute):
        """Test that custom max_concurrent_queries is respected"""
        mock_execute.return_value = "Concurrent result"

        insights_data: list[DashboardInsightContext] = [
            DashboardInsightContext(
                query=TrendsQuery(series=[EventsNode(event="pageview")]),
                name=f"Insight {i}",
                insight_id=f"insight-{i}",
            )
            for i in range(10)
        ]

        dashboard_ctx = DashboardContext(
            team=self.team,
            insights_data=insights_data,
            user=self.user,
            name="Concurrent Dashboard",
            dashboard_id="707",
            max_concurrent_queries=5,
        )

        # Verify semaphore is set correctly
        self.assertEqual(dashboard_ctx._semaphore._value, 5)

        result = await dashboard_ctx.execute_and_format()

        self.assertIn("Concurrent Dashboard", result)
        self.assertEqual(mock_execute.call_count, 10)

    @patch("ee.hogai.context.insight.context.execute_and_format_query")
    async def test_custom_prompt_template(self, mock_execute):
        """Test that custom prompt template is used"""
        mock_execute.return_value = "Custom template result"

        insights_data: list[DashboardInsightContext] = [
            DashboardInsightContext(
                query=TrendsQuery(series=[EventsNode(event="pageview")]),
                name="Custom Template Insight",
                insight_id="custom-1",
            )
        ]

        dashboard_ctx = DashboardContext(
            team=self.team,
            insights_data=insights_data,
            user=self.user,
            name="Custom Template Dashboard",
            dashboard_id="808",
        )

        custom_template = "Custom: {{{dashboard_name}}} - {{{insights}}}"
        result = await dashboard_ctx.execute_and_format(prompt_template=custom_template)

        self.assertIn("Custom: Custom Template Dashboard", result)
        self.assertIn("Custom template result", result)

    @patch("ee.hogai.context.dashboard.context.capture_exception")
    @patch("ee.hogai.context.insight.context.InsightContext.execute_and_format", new_callable=AsyncMock)
    async def test_one_failing_insight_does_not_drop_whole_dashboard(self, mock_execute_and_format, mock_capture):
        """A single insight raising (e.g. a query-prep error outside InsightContext's own
        try/except) must NOT drop the entire dashboard from context — the dashboard, its
        surviving insights, and an error placeholder for the failed one should all remain."""
        mock_execute_and_format.side_effect = [ValueError("boom"), "Insight results: 200 users"]

        insights_data: list[DashboardInsightContext] = [
            DashboardInsightContext(
                query=TrendsQuery(series=[EventsNode(event="pageview")]),
                name="Broken Insight",
                short_id="insight-1",
            ),
            DashboardInsightContext(
                query=TrendsQuery(series=[EventsNode(event="signup")]),
                name="Working Insight",
                short_id="insight-2",
            ),
        ]

        dashboard_ctx = DashboardContext(
            team=self.team,
            insights_data=insights_data,
            user=self.user,
            name="Mixed Dashboard",
            dashboard_id="789",
        )

        result = await dashboard_ctx.execute_and_format()

        # The dashboard itself and the working insight survive.
        self.assertIn("Dashboard name: Mixed Dashboard", result)
        self.assertIn("Insight results: 200 users", result)
        # The failed insight degrades to a placeholder instead of taking down the dashboard.
        self.assertIn("Broken Insight", result)
        self.assertIn("Error preparing insight context", result)
        # The failure is surfaced, not silently swallowed.
        mock_capture.assert_called_once()

    @patch("ee.hogai.context.dashboard.context.capture_exception")
    @patch("ee.hogai.context.insight.context.InsightContext.execute_and_format", new_callable=AsyncMock)
    async def test_cancelled_insight_propagates_and_is_not_captured(self, mock_execute_and_format, mock_capture):
        # CancelledError must propagate (cooperative cancellation), never degrade to a placeholder
        # or get captured — otherwise a cancelled task is silently turned into "an error occurred".
        mock_execute_and_format.side_effect = asyncio.CancelledError()

        insights_data: list[DashboardInsightContext] = [
            DashboardInsightContext(
                query=TrendsQuery(series=[EventsNode(event="pageview")]),
                name="Cancelled Insight",
                short_id="insight-1",
            ),
        ]

        dashboard_ctx = DashboardContext(
            team=self.team,
            insights_data=insights_data,
            user=self.user,
            name="Cancelled Dashboard",
            dashboard_id="790",
        )

        with self.assertRaises(asyncio.CancelledError):
            await dashboard_ctx.execute_and_format()

        mock_capture.assert_not_called()

    @patch("ee.hogai.context.dashboard.context.capture_exception")
    @patch("ee.hogai.context.insight.context.InsightContext.format_schema", new_callable=AsyncMock)
    async def test_one_failing_insight_schema_does_not_drop_whole_dashboard(self, mock_format_schema, mock_capture):
        # format_schema shares the same degrade-or-reraise path as execute_and_format, so one
        # failing schema must degrade to a placeholder rather than drop the whole dashboard.
        mock_format_schema.side_effect = [ValueError("boom"), "Schema: signups by day"]

        insights_data: list[DashboardInsightContext] = [
            DashboardInsightContext(
                query=TrendsQuery(series=[EventsNode(event="pageview")]),
                name="Broken Insight",
                short_id="insight-1",
            ),
            DashboardInsightContext(
                query=TrendsQuery(series=[EventsNode(event="signup")]),
                name="Working Insight",
                short_id="insight-2",
            ),
        ]

        dashboard_ctx = DashboardContext(
            team=self.team,
            insights_data=insights_data,
            user=self.user,
            name="Mixed Dashboard",
            dashboard_id="791",
        )

        result = await dashboard_ctx.format_schema()

        self.assertIn("Mixed Dashboard", result)
        self.assertIn("Schema: signups by day", result)
        self.assertIn("Broken Insight", result)
        self.assertIn("Error preparing insight schema", result)
        mock_capture.assert_called_once()
