from datetime import datetime, timedelta
from typing import Any

from freezegun import freeze_time
from posthog.test.base import BaseTest
from unittest.mock import patch

from django.db.models.signals import post_save
from django.utils import timezone

from parameterized import parameterized

from posthog.models.activity_logging.activity_log import ActivityLog, activity_log_created

from ee.hogai.context.activity_log.context import MAX_VALUE_LENGTH, ActivityLogContext, humanize_scope
from ee.hogai.context.activity_log.prompts import ACTIVITY_LOG_NO_RESULTS


class ActivityLogTestBase(BaseTest):
    def setUp(self) -> None:
        super().setUp()
        post_save.disconnect(activity_log_created, sender=ActivityLog)

    def tearDown(self) -> None:
        post_save.connect(activity_log_created, sender=ActivityLog)
        super().tearDown()

    async def _create_log(
        self,
        *,
        scope: str = "FeatureFlag",
        activity: str = "updated",
        item_id: str = "1",
        detail: dict | None = None,
        user: Any = None,
        is_system: bool = False,
        was_impersonated: bool = False,
        created_at: datetime | None = None,
    ) -> ActivityLog:
        return await ActivityLog.objects.acreate(
            team_id=self.team.id,
            user=user if user is not None and not is_system else (None if is_system else self.user),
            is_system=is_system,
            was_impersonated=was_impersonated,
            scope=scope,
            activity=activity,
            item_id=item_id,
            detail=detail or {},
            created_at=created_at or timezone.now(),
        )


@freeze_time("2025-06-15T12:00:00Z")
class TestActivityLogContext(ActivityLogTestBase):
    def _create_context(self) -> ActivityLogContext:
        return ActivityLogContext(team=self.team, user=self.user)

    async def test_fetch_and_format_returns_no_results_message_when_empty(self):
        context = self._create_context()
        result = await context.fetch_and_format()
        assert result == ACTIVITY_LOG_NO_RESULTS

    async def test_fetch_and_format_returns_formatted_activity_logs(self):
        await self._create_log(
            scope="FeatureFlag",
            activity="created",
            item_id="42",
            detail={"name": "my-flag"},
        )
        context = self._create_context()
        result = await context.fetch_and_format()

        assert "Activity log" in result
        assert "1-1 of 1" in result
        assert "Feature Flag" in result
        assert "created" in result
        assert "my-flag" in result

    async def test_fetch_and_format_filters_by_scope(self):
        await self._create_log(scope="FeatureFlag", activity="created", item_id="1")
        await self._create_log(scope="Insight", activity="updated", item_id="2")

        context = self._create_context()
        result = await context.fetch_and_format(scope="FeatureFlag")

        assert "Feature Flag" in result
        assert "Insight" not in result
        assert "for scope=FeatureFlag" in result

    async def test_fetch_and_format_filters_by_activity(self):
        await self._create_log(scope="FeatureFlag", activity="created", item_id="1")
        await self._create_log(scope="FeatureFlag", activity="deleted", item_id="2")

        context = self._create_context()
        result = await context.fetch_and_format(activity="created")

        assert "1-1 of 1" in result
        assert "created" in result

    async def test_fetch_and_format_filters_by_item_id(self):
        await self._create_log(scope="FeatureFlag", item_id="10")
        await self._create_log(scope="FeatureFlag", item_id="20")

        context = self._create_context()
        result = await context.fetch_and_format(item_id="10")

        assert "1-1 of 1" in result

    async def test_fetch_and_format_filters_by_user_email(self):
        await self._create_log(scope="Insight", activity="created", item_id="1")

        context = self._create_context()
        result = await context.fetch_and_format(user_email=self.user.email)

        assert "1-1 of 1" in result
        assert f"by {self.user.email}" in result

    async def test_fetch_and_format_filters_by_user_email_no_match(self):
        await self._create_log(scope="Insight", activity="created", item_id="1")

        context = self._create_context()
        result = await context.fetch_and_format(user_email="nonexistent@example.com")

        assert result == ACTIVITY_LOG_NO_RESULTS

    async def test_fetch_and_format_respects_limit(self):
        for i in range(5):
            await self._create_log(item_id=str(i), created_at=timezone.now() - timedelta(minutes=i))

        context = self._create_context()
        result = await context.fetch_and_format(limit=2)

        assert "1-2 of 5" in result

    async def test_fetch_and_format_clamps_limit_to_valid_range(self):
        for i in range(3):
            await self._create_log(item_id=str(i))

        context = self._create_context()

        result_low = await context.fetch_and_format(limit=0)
        assert "1-1 of 3" in result_low

        result_high = await context.fetch_and_format(limit=100)
        assert "1-3 of 3" in result_high

    async def test_fetch_and_format_orders_by_created_at_desc(self):
        await self._create_log(
            scope="Insight",
            activity="created",
            item_id="old",
            detail={"name": "OldInsight"},
            created_at=timezone.now() - timedelta(hours=2),
        )
        await self._create_log(
            scope="Insight",
            activity="updated",
            item_id="new",
            detail={"name": "NewInsight"},
            created_at=timezone.now(),
        )

        context = self._create_context()
        result = await context.fetch_and_format()

        new_pos = result.index("NewInsight")
        old_pos = result.index("OldInsight")
        assert new_pos < old_pos

    async def test_system_action_shows_system_attribution(self):
        await self._create_log(
            scope="FeatureFlag",
            activity="updated",
            item_id="1",
            detail={"name": "sys-flag"},
            is_system=True,
        )

        context = self._create_context()
        result = await context.fetch_and_format()

        assert "by System" in result

    async def test_impersonated_action_shows_impersonated_suffix(self):
        await self._create_log(
            scope="FeatureFlag",
            activity="updated",
            item_id="1",
            detail={"name": "imp-flag"},
            was_impersonated=True,
        )

        context = self._create_context()
        result = await context.fetch_and_format()

        assert "(impersonated)" in result

    async def test_user_attribution_uses_first_name_when_available(self):
        self.user.first_name = "Alice"
        await self.user.asave()

        await self._create_log(scope="Insight", activity="created", item_id="1")

        context = self._create_context()
        result = await context.fetch_and_format()

        assert "by Alice" in result

    async def test_user_attribution_falls_back_to_email(self):
        self.user.first_name = ""
        await self.user.asave()

        await self._create_log(scope="Insight", activity="created", item_id="1")

        context = self._create_context()
        result = await context.fetch_and_format()

        assert f"by {self.user.email}" in result

    async def test_item_name_from_detail_name(self):
        await self._create_log(
            scope="FeatureFlag",
            activity="created",
            item_id="42",
            detail={"name": "my-feature-flag"},
        )

        context = self._create_context()
        result = await context.fetch_and_format()

        assert "my-feature-flag" in result

    async def test_item_name_from_detail_short_id(self):
        await self._create_log(
            scope="Insight",
            activity="created",
            item_id="99",
            detail={"short_id": "abc123"},
        )

        context = self._create_context()
        result = await context.fetch_and_format()

        assert "abc123" in result

    async def test_item_name_falls_back_to_item_id(self):
        await self._create_log(
            scope="Dashboard",
            activity="created",
            item_id="77",
            detail={},
        )

        context = self._create_context()
        result = await context.fetch_and_format()

        assert "77" in result

    async def test_item_name_falls_back_to_unknown_when_no_detail_or_item_id(self):
        await ActivityLog.objects.acreate(
            team_id=self.team.id,
            user=self.user,
            is_system=False,
            was_impersonated=False,
            scope="Insight",
            activity="created",
            item_id=None,
            detail=None,
        )

        context = self._create_context()
        result = await context.fetch_and_format()

        assert "(unknown)" in result

    @parameterized.expand(
        [
            (
                "created_change",
                [{"field": "enabled", "action": "created", "after": True}],
                "enabled: set to True",
            ),
            (
                "deleted_change",
                [{"field": "description", "action": "deleted", "before": "old desc"}],
                "description: removed (was old desc)",
            ),
            (
                "changed_value",
                [{"field": "name", "action": "changed", "before": "old", "after": "new"}],
                "name: old -> new",
            ),
        ]
    )
    async def test_format_changes(self, _name, changes, expected_text):
        await self._create_log(
            scope="FeatureFlag",
            activity="updated",
            item_id="1",
            detail={"name": "test", "changes": changes},
        )

        context = self._create_context()
        result = await context.fetch_and_format()

        assert expected_text in result

    async def test_format_changes_with_none_values(self):
        await self._create_log(
            scope="FeatureFlag",
            activity="updated",
            item_id="1",
            detail={
                "name": "test",
                "changes": [{"field": "rollout", "action": "changed", "before": None, "after": 50}],
            },
        )

        context = self._create_context()
        result = await context.fetch_and_format()

        assert "rollout: (none) -> 50" in result

    async def test_format_changes_empty_changes_list(self):
        await self._create_log(
            scope="FeatureFlag",
            activity="created",
            item_id="1",
            detail={"name": "no-changes", "changes": []},
        )

        context = self._create_context()
        result = await context.fetch_and_format()

        assert "no-changes" in result
        assert "  - " not in result

    async def test_format_changes_non_dict_change_is_skipped(self):
        await self._create_log(
            scope="FeatureFlag",
            activity="updated",
            item_id="1",
            detail={
                "name": "test",
                "changes": [
                    "not-a-dict",
                    {"field": "name", "action": "changed", "before": "a", "after": "b"},
                ],
            },
        )

        context = self._create_context()
        result = await context.fetch_and_format()

        assert "name: a -> b" in result


@freeze_time("2025-06-15T12:00:00Z")
class TestActivityLogContextPagination(ActivityLogTestBase):
    def _create_context(self) -> ActivityLogContext:
        return ActivityLogContext(team=self.team, user=self.user)

    async def test_offset_skips_entries(self):
        for i in range(5):
            await self._create_log(
                item_id=str(i),
                detail={"name": f"flag-{i}"},
                created_at=timezone.now() - timedelta(minutes=i),
            )

        context = self._create_context()
        result = await context.fetch_and_format(limit=2, offset=2)

        assert "3-4 of 5" in result
        assert "flag-0" not in result
        assert "flag-1" not in result

    async def test_pagination_hint_shows_next_offset_when_more_exist(self):
        for i in range(5):
            await self._create_log(item_id=str(i), created_at=timezone.now() - timedelta(minutes=i))

        context = self._create_context()
        result = await context.fetch_and_format(limit=2, offset=0)

        assert "use offset=2" in result

    async def test_pagination_hint_shows_end_when_no_more_results(self):
        for i in range(3):
            await self._create_log(item_id=str(i))

        context = self._create_context()
        result = await context.fetch_and_format(limit=10, offset=0)

        assert "end of results" in result

    async def test_offset_beyond_total_returns_no_results(self):
        await self._create_log(item_id="1")

        context = self._create_context()
        result = await context.fetch_and_format(offset=100)

        assert result == ACTIVITY_LOG_NO_RESULTS

    async def test_pagination_last_page_shows_end(self):
        for i in range(5):
            await self._create_log(item_id=str(i), created_at=timezone.now() - timedelta(minutes=i))

        context = self._create_context()
        result = await context.fetch_and_format(limit=2, offset=4)

        assert "5-5 of 5" in result
        assert "end of results" in result


@freeze_time("2025-06-15T12:00:00Z")
class TestActivityLogContextDatetimeFilter(ActivityLogTestBase):
    def _create_context(self) -> ActivityLogContext:
        return ActivityLogContext(team=self.team, user=self.user)

    async def test_after_filter_excludes_older_entries(self):
        await self._create_log(
            item_id="old",
            detail={"name": "old-entry"},
            created_at=timezone.now() - timedelta(days=10),
        )
        await self._create_log(
            item_id="new",
            detail={"name": "new-entry"},
            created_at=timezone.now() - timedelta(days=1),
        )

        context = self._create_context()
        result = await context.fetch_and_format(after="2025-06-10T00:00:00Z")

        assert "new-entry" in result
        assert "old-entry" not in result

    async def test_before_filter_excludes_newer_entries(self):
        await self._create_log(
            item_id="old",
            detail={"name": "old-entry"},
            created_at=timezone.now() - timedelta(days=10),
        )
        await self._create_log(
            item_id="new",
            detail={"name": "new-entry"},
            created_at=timezone.now() - timedelta(days=1),
        )

        context = self._create_context()
        result = await context.fetch_and_format(before="2025-06-10T00:00:00Z")

        assert "old-entry" in result
        assert "new-entry" not in result

    async def test_after_and_before_combined_filters_to_range(self):
        await self._create_log(
            item_id="too-old",
            detail={"name": "too-old"},
            created_at=timezone.now() - timedelta(days=10),
        )
        await self._create_log(
            item_id="in-range",
            detail={"name": "in-range"},
            created_at=timezone.now() - timedelta(days=3),
        )
        await self._create_log(
            item_id="too-new",
            detail={"name": "too-new"},
            created_at=timezone.now(),
        )

        context = self._create_context()
        result = await context.fetch_and_format(
            after="2025-06-08T00:00:00Z",
            before="2025-06-14T00:00:00Z",
        )

        assert "in-range" in result
        assert "too-old" not in result
        assert "too-new" not in result

    async def test_invalid_datetime_string_is_ignored_with_warning(self):
        await self._create_log(item_id="1", detail={"name": "entry"})

        context = self._create_context()
        result = await context.fetch_and_format(after="not-a-date", before="also-invalid")

        assert "entry" in result
        assert "'after' filter 'not-a-date' is not a valid ISO 8601 datetime and was ignored" in result
        assert "'before' filter 'also-invalid' is not a valid ISO 8601 datetime and was ignored" in result


@freeze_time("2025-06-15T12:00:00Z")
class TestActivityLogContextTruncation(ActivityLogTestBase):
    def _create_context(self) -> ActivityLogContext:
        return ActivityLogContext(team=self.team, user=self.user)

    async def test_truncate_large_string_value(self):
        long_value = "x" * (MAX_VALUE_LENGTH + 50)
        await self._create_log(
            scope="FeatureFlag",
            activity="updated",
            item_id="1",
            detail={
                "name": "test",
                "changes": [{"field": "description", "action": "changed", "before": "short", "after": long_value}],
            },
        )

        context = self._create_context()
        result = await context.fetch_and_format()

        assert "..." in result
        assert long_value not in result

    async def test_truncate_large_dict_value(self):
        large_dict = {"key_" + str(i): "value_" + str(i) for i in range(100)}
        await self._create_log(
            scope="FeatureFlag",
            activity="updated",
            item_id="1",
            detail={
                "name": "test",
                "changes": [{"field": "filters", "action": "changed", "before": {}, "after": large_dict}],
            },
        )

        context = self._create_context()
        result = await context.fetch_and_format()

        assert "..." in result

    async def test_truncate_large_list_value(self):
        large_list = list(range(200))
        await self._create_log(
            scope="FeatureFlag",
            activity="updated",
            item_id="1",
            detail={
                "name": "test",
                "changes": [{"field": "groups", "action": "changed", "before": [], "after": large_list}],
            },
        )

        context = self._create_context()
        result = await context.fetch_and_format()

        assert "..." in result


@freeze_time("2025-06-15T12:00:00Z")
class TestActivityLogContextVisibility(ActivityLogTestBase):
    def _create_context(self, user=None) -> ActivityLogContext:
        return ActivityLogContext(team=self.team, user=user or self.user)

    async def test_non_staff_user_cannot_see_restricted_scopes(self):
        self.user.is_staff = False
        await self.user.asave()

        await self._create_log(
            scope="User",
            activity="logged_in",
            item_id="1",
            detail={},
            was_impersonated=True,
        )
        await self._create_log(
            scope="User",
            activity="created",
            item_id="2",
            detail={"name": "user-created"},
        )
        await self._create_log(
            scope="FeatureFlag",
            activity="created",
            item_id="3",
            detail={"name": "visible-flag"},
        )

        context = self._create_context()
        result = await context.fetch_and_format()

        assert "visible-flag" in result
        assert "logged_in" not in result
        assert "user-created" not in result

    async def test_staff_user_can_see_restricted_scopes(self):
        self.user.is_staff = True
        await self.user.asave()

        await self._create_log(
            scope="User",
            activity="logged_in",
            item_id="1",
            detail={"name": "staff-login"},
            was_impersonated=True,
        )

        context = self._create_context()
        result = await context.fetch_and_format()

        assert "logged_in" in result

    @patch("ee.hogai.context.activity_log.context.get_activity_log_lookback_restriction")
    async def test_lookback_restriction_applied(self, mock_lookback):
        mock_lookback.return_value = timezone.now() - timedelta(days=7)

        await self._create_log(
            scope="FeatureFlag",
            activity="created",
            item_id="recent",
            detail={"name": "recent-flag"},
            created_at=timezone.now() - timedelta(days=1),
        )
        await self._create_log(
            scope="FeatureFlag",
            activity="created",
            item_id="old",
            detail={"name": "old-flag"},
            created_at=timezone.now() - timedelta(days=30),
        )

        context = self._create_context()
        result = await context.fetch_and_format()

        assert "recent-flag" in result
        assert "old-flag" not in result

    @patch("ee.hogai.context.activity_log.context.get_activity_log_lookback_restriction")
    async def test_no_lookback_restriction_when_none(self, mock_lookback):
        mock_lookback.return_value = None

        await self._create_log(
            scope="FeatureFlag",
            activity="created",
            item_id="old",
            detail={"name": "old-flag"},
            created_at=timezone.now() - timedelta(days=365),
        )

        context = self._create_context()
        result = await context.fetch_and_format()

        assert "old-flag" in result

    async def test_only_returns_entries_for_current_team(self):
        other_team_id = self.team.id + 9999

        await ActivityLog.objects.acreate(
            team_id=other_team_id,
            user=self.user,
            is_system=False,
            was_impersonated=False,
            scope="FeatureFlag",
            activity="created",
            item_id="1",
            detail={"name": "other-team-flag"},
        )
        await self._create_log(
            scope="FeatureFlag",
            activity="created",
            item_id="2",
            detail={"name": "my-team-flag"},
        )

        context = self._create_context()
        result = await context.fetch_and_format()

        assert "my-team-flag" in result
        assert "other-team-flag" not in result

    async def test_includes_org_scoped_logs_when_enabled(self):
        self.team.receive_org_level_activity_logs = True
        await self.team.asave()

        await ActivityLog.objects.acreate(
            team_id=None,
            organization_id=self.team.organization_id,
            user=self.user,
            is_system=False,
            was_impersonated=False,
            scope="Organization",
            activity="updated",
            item_id=str(self.team.organization_id),
            detail={"name": "org-change"},
        )

        context = self._create_context()
        result = await context.fetch_and_format()

        assert "org-change" in result

    async def test_excludes_org_scoped_logs_when_disabled(self):
        self.team.receive_org_level_activity_logs = False
        await self.team.asave()

        await ActivityLog.objects.acreate(
            team_id=None,
            organization_id=self.team.organization_id,
            user=self.user,
            is_system=False,
            was_impersonated=False,
            scope="Organization",
            activity="updated",
            item_id=str(self.team.organization_id),
            detail={"name": "org-change"},
        )

        context = self._create_context()
        result = await context.fetch_and_format()

        assert result == ACTIVITY_LOG_NO_RESULTS


@freeze_time("2025-06-15T12:00:00Z")
class TestActivityLogContextHumanization(ActivityLogTestBase):
    def _create_context(self) -> ActivityLogContext:
        return ActivityLogContext(team=self.team, user=self.user)

    @parameterized.expand(
        [
            ("camel_case_split", "FeatureFlag", "Feature Flag"),
            ("single_word", "Insight", "Insight"),
            ("override_hog_function", "HogFunction", "Data pipeline"),
            ("override_batch_export", "BatchExport", "Destination"),
            ("override_external_data_source", "ExternalDataSource", "Source"),
            ("override_alert_configuration", "AlertConfiguration", "Alert"),
            ("override_personal_api_key", "PersonalAPIKey", "Personal API key"),
            ("override_llm_trace", "LLMTrace", "LLM trace"),
            ("multi_word_camel", "EarlyAccessFeature", "Early Access Feature"),
        ]
    )
    def test_humanize_scope(self, _name: str, scope: str, expected: str):
        assert humanize_scope(scope) == expected

    async def test_scope_displayed_with_override(self):
        await self._create_log(
            scope="HogFunction",
            activity="updated",
            item_id="1",
            detail={"name": "My Pipeline"},
        )

        context = self._create_context()
        result = await context.fetch_and_format()

        assert "Data pipeline" in result
        assert "HogFunction" not in result

    async def test_field_name_override_applied_in_changes(self):
        await self._create_log(
            scope="HogFunction",
            activity="updated",
            item_id="1",
            detail={
                "name": "My Pipeline",
                "changes": [{"field": "execution_order", "action": "changed", "before": 1, "after": 2}],
            },
        )

        context = self._create_context()
        result = await context.fetch_and_format()

        assert "priority: 1 -> 2" in result
        assert "execution_order" not in result

    async def test_field_name_without_override_unchanged(self):
        await self._create_log(
            scope="FeatureFlag",
            activity="updated",
            item_id="1",
            detail={
                "name": "test",
                "changes": [{"field": "active", "action": "changed", "before": True, "after": False}],
            },
        )

        context = self._create_context()
        result = await context.fetch_and_format()

        assert "active: True -> False" in result


@freeze_time("2025-06-15T12:00:00Z")
class TestActivityLogContextFormatting(ActivityLogTestBase):
    async def test_timestamp_format(self):
        await self._create_log(
            scope="FeatureFlag",
            activity="created",
            item_id="1",
            detail={"name": "test"},
            created_at=timezone.now(),
        )

        context = ActivityLogContext(team=self.team, user=self.user)
        result = await context.fetch_and_format()

        assert "2025-06-15T12:00:00+00:00" in result

    async def test_entry_format_structure(self):
        await self._create_log(
            scope="Dashboard",
            activity="deleted",
            item_id="5",
            detail={"name": "My Dashboard"},
        )

        context = ActivityLogContext(team=self.team, user=self.user)
        result = await context.fetch_and_format()

        assert "- **2025-06-15T12:00:00+00:00** | Dashboard | deleted | My Dashboard" in result

    async def test_detail_with_non_dict_type_uses_item_id(self):
        await ActivityLog.objects.acreate(
            team_id=self.team.id,
            user=self.user,
            is_system=False,
            was_impersonated=False,
            scope="Insight",
            activity="created",
            item_id="42",
            detail="not-a-dict",
        )

        context = ActivityLogContext(team=self.team, user=self.user)
        result = await context.fetch_and_format()

        assert "42" in result
