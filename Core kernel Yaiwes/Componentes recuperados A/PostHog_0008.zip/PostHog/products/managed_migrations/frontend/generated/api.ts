import { apiMutator } from '../../../../frontend/src/lib/api-orval-mutator'
/**
 * Auto-generated from the Django backend OpenAPI schema.
 * To modify these types, update the Django serializers or views, then run:
 *   hogli build:openapi
 * Questions or issues? #team-devex on Slack
 *
 * PostHog API - generated
 * OpenAPI spec version: 1.0.0
 */
import type {
    BatchImportAWSIAMSetupApi,
    BatchImportApi,
    BatchImportResponseApi,
    BatchImportSupportDetailApi,
    ManagedMigrationsListParams,
    ManagedMigrationsSupportListParams,
    ManagedMigrationsTrialRecordsRetrieveParams,
    PaginatedBatchImportListApi,
    PaginatedBatchImportSupportListListApi,
    PatchedBatchImportApi,
    TrialRecordsResponseApi,
} from './api.schemas'

// https://stackoverflow.com/questions/49579094/typescript-conditional-types-filter-out-readonly-properties-pick-only-requir/49579497#49579497
type IfEquals<X, Y, A = X, B = never> = (<T>() => T extends X ? 1 : 2) extends <T>() => T extends Y ? 1 : 2 ? A : B

type WritableKeys<T> = {
    [P in keyof T]-?: IfEquals<{ [Q in P]: T[P] }, { -readonly [Q in P]: T[P] }, P>
}[keyof T]

type UnionToIntersection<U> = (U extends any ? (k: U) => void : never) extends (k: infer I) => void ? I : never
type DistributeReadOnlyOverUnions<T> = T extends any ? NonReadonly<T> : never

type Writable<T> = Pick<T, WritableKeys<T>>
type NonReadonly<T> = [T] extends [UnionToIntersection<T>]
    ? {
          [P in keyof Writable<T>]: T[P] extends object ? NonReadonly<NonNullable<T[P]>> : T[P]
      }
    : DistributeReadOnlyOverUnions<T>

export const getManagedMigrationsSupportListUrl = (params?: ManagedMigrationsSupportListParams) => {
    const normalizedParams = new URLSearchParams()

    Object.entries(params || {}).forEach(([key, value]) => {
        if (value !== undefined) {
            normalizedParams.append(key, value === null ? 'null' : String(value))
        }
    })

    const stringifiedParams = normalizedParams.toString()

    return stringifiedParams.length > 0
        ? `/api/managed_migrations_support/?${stringifiedParams}`
        : `/api/managed_migrations_support/`
}

/**
 * List batch import (managed migration) jobs across all teams. PostHog staff only.
 */
export const managedMigrationsSupportList = async (
    params?: ManagedMigrationsSupportListParams,
    options?: RequestInit
): Promise<PaginatedBatchImportSupportListListApi> => {
    return apiMutator<PaginatedBatchImportSupportListListApi>(getManagedMigrationsSupportListUrl(params), {
        ...options,
        method: 'GET',
    })
}

export const getManagedMigrationsSupportRetrieveUrl = (id: string) => {
    return `/api/managed_migrations_support/${id}/`
}

/**
 * Get one batch import job with its raw worker state and import config. PostHog staff only.
 */
export const managedMigrationsSupportRetrieve = async (
    id: string,
    options?: RequestInit
): Promise<BatchImportSupportDetailApi> => {
    return apiMutator<BatchImportSupportDetailApi>(getManagedMigrationsSupportRetrieveUrl(id), {
        ...options,
        method: 'GET',
    })
}

export const getManagedMigrationsListUrl = (projectId: string, params?: ManagedMigrationsListParams) => {
    const normalizedParams = new URLSearchParams()

    Object.entries(params || {}).forEach(([key, value]) => {
        if (value !== undefined) {
            normalizedParams.append(key, value === null ? 'null' : String(value))
        }
    })

    const stringifiedParams = normalizedParams.toString()

    return stringifiedParams.length > 0
        ? `/api/projects/${projectId}/managed_migrations/?${stringifiedParams}`
        : `/api/projects/${projectId}/managed_migrations/`
}

/**
 * List managed migrations using the response serializer
 */
export const managedMigrationsList = async (
    projectId: string,
    params?: ManagedMigrationsListParams,
    options?: RequestInit
): Promise<PaginatedBatchImportListApi> => {
    return apiMutator<PaginatedBatchImportListApi>(getManagedMigrationsListUrl(projectId, params), {
        ...options,
        method: 'GET',
    })
}

export const getManagedMigrationsCreateUrl = (projectId: string) => {
    return `/api/projects/${projectId}/managed_migrations/`
}

/**
 * Create a new managed migration/batch import.
 */
export const managedMigrationsCreate = async (
    projectId: string,
    batchImportApi?: NonReadonly<BatchImportApi>,
    options?: RequestInit
): Promise<BatchImportApi> => {
    return apiMutator<BatchImportApi>(getManagedMigrationsCreateUrl(projectId), {
        ...options,
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...options?.headers },
        body: JSON.stringify(batchImportApi),
    })
}

export const getManagedMigrationsRetrieveUrl = (projectId: string, id: string) => {
    return `/api/projects/${projectId}/managed_migrations/${id}/`
}

/**
 * Viewset for BatchImport model
 */
export const managedMigrationsRetrieve = async (
    projectId: string,
    id: string,
    options?: RequestInit
): Promise<BatchImportApi> => {
    return apiMutator<BatchImportApi>(getManagedMigrationsRetrieveUrl(projectId, id), {
        ...options,
        method: 'GET',
    })
}

export const getManagedMigrationsUpdateUrl = (projectId: string, id: string) => {
    return `/api/projects/${projectId}/managed_migrations/${id}/`
}

/**
 * Viewset for BatchImport model
 */
export const managedMigrationsUpdate = async (
    projectId: string,
    id: string,
    batchImportApi?: NonReadonly<BatchImportApi>,
    options?: RequestInit
): Promise<BatchImportApi> => {
    return apiMutator<BatchImportApi>(getManagedMigrationsUpdateUrl(projectId, id), {
        ...options,
        method: 'PUT',
        headers: { 'Content-Type': 'application/json', ...options?.headers },
        body: JSON.stringify(batchImportApi),
    })
}

export const getManagedMigrationsPartialUpdateUrl = (projectId: string, id: string) => {
    return `/api/projects/${projectId}/managed_migrations/${id}/`
}

/**
 * Viewset for BatchImport model
 */
export const managedMigrationsPartialUpdate = async (
    projectId: string,
    id: string,
    patchedBatchImportApi?: NonReadonly<PatchedBatchImportApi>,
    options?: RequestInit
): Promise<BatchImportApi> => {
    return apiMutator<BatchImportApi>(getManagedMigrationsPartialUpdateUrl(projectId, id), {
        ...options,
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json', ...options?.headers },
        body: JSON.stringify(patchedBatchImportApi),
    })
}

export const getManagedMigrationsDestroyUrl = (projectId: string, id: string) => {
    return `/api/projects/${projectId}/managed_migrations/${id}/`
}

/**
 * Viewset for BatchImport model
 */
export const managedMigrationsDestroy = async (projectId: string, id: string, options?: RequestInit): Promise<void> => {
    return apiMutator<void>(getManagedMigrationsDestroyUrl(projectId, id), {
        ...options,
        method: 'DELETE',
    })
}

export const getManagedMigrationsPauseCreateUrl = (projectId: string, id: string) => {
    return `/api/projects/${projectId}/managed_migrations/${id}/pause/`
}

/**
 * Pause a running batch import.
 */
export const managedMigrationsPauseCreate = async (
    projectId: string,
    id: string,
    batchImportApi?: NonReadonly<BatchImportApi>,
    options?: RequestInit
): Promise<BatchImportApi> => {
    return apiMutator<BatchImportApi>(getManagedMigrationsPauseCreateUrl(projectId, id), {
        ...options,
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...options?.headers },
        body: JSON.stringify(batchImportApi),
    })
}

export const getManagedMigrationsPromoteCreateUrl = (projectId: string, id: string) => {
    return `/api/projects/${projectId}/managed_migrations/${id}/promote/`
}

/**
 * Start the real import from a completed trial run, reusing its source config and credentials.
 */
export const managedMigrationsPromoteCreate = async (
    projectId: string,
    id: string,
    options?: RequestInit
): Promise<BatchImportResponseApi> => {
    return apiMutator<BatchImportResponseApi>(getManagedMigrationsPromoteCreateUrl(projectId, id), {
        ...options,
        method: 'POST',
    })
}

export const getManagedMigrationsResumeCreateUrl = (projectId: string, id: string) => {
    return `/api/projects/${projectId}/managed_migrations/${id}/resume/`
}

/**
 * Resume a paused batch import.
 */
export const managedMigrationsResumeCreate = async (
    projectId: string,
    id: string,
    batchImportApi?: NonReadonly<BatchImportApi>,
    options?: RequestInit
): Promise<BatchImportApi> => {
    return apiMutator<BatchImportApi>(getManagedMigrationsResumeCreateUrl(projectId, id), {
        ...options,
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...options?.headers },
        body: JSON.stringify(batchImportApi),
    })
}

export const getManagedMigrationsTrialRecordsRetrieveUrl = (
    projectId: string,
    id: string,
    params?: ManagedMigrationsTrialRecordsRetrieveParams
) => {
    const normalizedParams = new URLSearchParams()

    Object.entries(params || {}).forEach(([key, value]) => {
        if (value !== undefined) {
            normalizedParams.append(key, value === null ? 'null' : String(value))
        }
    })

    const stringifiedParams = normalizedParams.toString()

    return stringifiedParams.length > 0
        ? `/api/projects/${projectId}/managed_migrations/${id}/trial_records/?${stringifiedParams}`
        : `/api/projects/${projectId}/managed_migrations/${id}/trial_records/`
}

/**
 * Fetch one page of a trial run's results (source event paired with its would-be output events).
 */
export const managedMigrationsTrialRecordsRetrieve = async (
    projectId: string,
    id: string,
    params?: ManagedMigrationsTrialRecordsRetrieveParams,
    options?: RequestInit
): Promise<TrialRecordsResponseApi> => {
    return apiMutator<TrialRecordsResponseApi>(getManagedMigrationsTrialRecordsRetrieveUrl(projectId, id, params), {
        ...options,
        method: 'GET',
    })
}

export const getManagedMigrationsAwsIamSetupRetrieveUrl = (projectId: string) => {
    return `/api/projects/${projectId}/managed_migrations/aws_iam_setup/`
}

/**
 * Values needed to set up cross-account IAM role access for S3 imports: the external ID, PostHog's import role ARN, and ready-to-paste trust/permission policy JSON.
 */
export const managedMigrationsAwsIamSetupRetrieve = async (
    projectId: string,
    options?: RequestInit
): Promise<BatchImportAWSIAMSetupApi> => {
    return apiMutator<BatchImportAWSIAMSetupApi>(getManagedMigrationsAwsIamSetupRetrieveUrl(projectId), {
        ...options,
        method: 'GET',
    })
}
