from typing import cast

from posthog.test.base import BaseTest
from unittest.mock import patch

from parameterized import parameterized
from rest_framework.request import Request

from posthog.auth import SessionAuthentication

from products.notebooks.backend.analytics import (
    NOTEBOOK_CREATED_EVENT,
    NOTEBOOK_READ_EVENT,
    NotebookCreationSource,
    capture_notebook_created,
    capture_notebook_read,
    notebook_node_count,
)
from products.notebooks.backend.presentation.views.notebook import classify_request_source


class _FakeKeyAuth:
    pass


class _FakeRequest:
    def __init__(self, authenticator, mcp_consumer=None):
        self.successful_authenticator = authenticator
        self.META = {}
        if mcp_consumer is not None:
            self.META["HTTP_X_POSTHOG_MCP_CONSUMER"] = mcp_consumer


def _fake_request(authenticator, mcp_consumer=None) -> Request:
    return cast(Request, _FakeRequest(authenticator, mcp_consumer))


class TestNotebookAnalytics(BaseTest):
    @parameterized.expand(
        [
            ("two_nodes", {"type": "doc", "content": [{}, {}]}, 2),
            ("empty_doc", {"type": "doc", "content": []}, 0),
            ("no_content_key", {"type": "doc"}, 0),
            ("none", None, None),
            ("not_a_dict", "just text", None),
        ]
    )
    def test_notebook_node_count(self, _name, content, expected):
        self.assertEqual(notebook_node_count(content), expected)

    def test_classify_request_source_session_is_ui(self):
        source, extra = classify_request_source(_fake_request(SessionAuthentication()))
        self.assertEqual(source, NotebookCreationSource.UI)
        self.assertEqual(extra, {})

    def test_classify_request_source_api_key_captures_mcp_client_identity(self):
        # The MCP server forwards mcp_consumer (posthog-code -> PostHog Desktop), which is how
        # PostHog Desktop is split from a customer's own MCP client.
        source, extra = classify_request_source(_fake_request(_FakeKeyAuth(), mcp_consumer="posthog-code"))
        self.assertEqual(source, NotebookCreationSource.MCP)
        self.assertEqual(extra, {"api_key_type": "_FakeKeyAuth", "mcp_consumer": "posthog-code"})

    def test_classify_request_source_no_authenticator_defaults_to_ui(self):
        source, extra = classify_request_source(_fake_request(None))
        self.assertEqual(source, (NotebookCreationSource.UI))
        self.assertEqual(extra, {})

    @patch("products.notebooks.backend.analytics.report_user_action")
    def test_request_path_captures_via_report_user_action_and_drops_none_props(self, mock_report):
        capture_notebook_created(
            short_id="abc123",
            creation_source=NotebookCreationSource.UI,
            team_id=self.team.id,
            user=self.user,
            request=_fake_request(SessionAuthentication()),
            visibility="private",
            node_count=3,
            mcp_consumer=None,
            api_key_type=None,
        )
        self.assertEqual(mock_report.call_count, 1)
        args, kwargs = mock_report.call_args
        self.assertEqual(args[0], self.user)
        self.assertEqual(args[1], NOTEBOOK_CREATED_EVENT)
        # None-valued optional props are dropped so they don't clutter the event.
        self.assertEqual(
            args[2],
            {"short_id": "abc123", "creation_source": "ui", "visibility": "private", "node_count": 3},
        )

    @patch("products.notebooks.backend.analytics.report_user_action")
    def test_capture_notebook_read_builds_props_and_drops_none(self, mock_report):
        capture_notebook_read(
            request=_fake_request(SessionAuthentication()),
            user=self.user,
            short_id="abc123",
            read_source=NotebookCreationSource.MCP,
            is_creator=False,
            user_access_level="viewer",
            api_key_type="PersonalAPIKeyAuthentication",
            mcp_consumer="posthog-code",
        )
        self.assertEqual(mock_report.call_count, 1)
        args, _ = mock_report.call_args
        self.assertEqual(args[0], self.user)
        self.assertEqual(args[1], NOTEBOOK_READ_EVENT)
        # mcp_consumer flows through; the None-valued optional props are dropped.
        self.assertEqual(
            args[2],
            {
                "short_id": "abc123",
                "read_source": "mcp",
                "is_creator": False,
                "user_access_level": "viewer",
                "api_key_type": "PersonalAPIKeyAuthentication",
                "mcp_consumer": "posthog-code",
            },
        )
