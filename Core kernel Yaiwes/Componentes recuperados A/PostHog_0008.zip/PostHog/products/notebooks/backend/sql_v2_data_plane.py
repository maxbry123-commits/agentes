"""The SQLV2 data plane: the sandbox's read path to PostHog data.

Token-authed sandbox -> backend endpoints (like the result callback, plain
function views, no session). The sandbox never parses HogQL — it sends the query
text here; parsing, access control, and execution all stay backend-side.

Queries run through the async query manager (the same Celery-backed path insights
and the SQL editor use), so no web worker ever waits on ClickHouse:

- `POST .../data_plane/query/` validates and enqueues, returning 202 {query_id}.
- `GET .../data_plane/query/<query_id>/` returns 202 while the Celery worker is
  still executing, and the rows as an Arrow stream once complete. The kernel's
  background thread polls this — invisible to the user, who already waits on the
  run callback or the page response.

Wired in posthog/urls.py at internal/notebooks/data_plane/query/.
"""

import json
from typing import Any

from django.conf import settings
from django.core import signing
from django.http import HttpRequest, HttpResponse, HttpResponseRedirect, JsonResponse

import structlog
from drf_spectacular.utils import OpenApiResponse, extend_schema
from prometheus_client import Counter

from posthog.hogql.errors import ExposedHogQLError
from posthog.hogql.parser import parse_select

from posthog.clickhouse.client.execute_async import QueryNotFoundError, enqueue_process_query_task, get_query_status
from posthog.clickhouse.query_tagging import Feature, Product, tags_context
from posthog.models import Team, User

from products.notebooks.backend import frame_store
from products.notebooks.backend.models import Notebook
from products.notebooks.backend.sql_v2 import (
    DELIVERY_INLINE,
    DELIVERY_OBJECT_RELAY,
    DataPlaneClaims,
    is_frame_store_ch_writes_enabled,
    is_frame_store_enabled,
    verify_data_plane_token,
)
from products.notebooks.backend.sql_v2_direct import apply_page_bounds
from products.notebooks.backend.sql_v2_runs import touch_run_progress
from products.notebooks.backend.sql_v2_serializers import NotebookSQLV2DataPlaneRequestSerializer

logger = structlog.get_logger(__name__)

ARROW_STREAM_CONTENT_TYPE = "application/vnd.apache.arrow.stream"

FRAME_STORE_FALLBACK_COUNTER = Counter(
    "posthog_notebooks_frame_store_fallback_inline",
    "Number of object-delivery requests that fell back to the inline (Redis) path.",
    # `not_in_rollout` is expected while the flag ramps; `not_configured` means the
    # deployment cannot serve objects at all and should be near zero once provisioned.
    labelnames=["reason"],
)


def _rows_to_arrow_bytes(
    columns: list[str], rows: list[tuple[Any, ...]], types: list[list[str]] | None = None
) -> bytes:
    import pyarrow as pa  # noqa: PLC0415 — keeps the heavy dep off the urls.py import path

    # Column-by-column with a per-column string fallback: HogQL results can contain
    # values Arrow can't infer (UUIDs, mixed types, tuples) and one odd column must
    # not fail the whole response.
    arrays = []
    for index in range(len(columns)):
        values = [row[index] for row in rows]
        try:
            arrays.append(pa.array(values))
        except (pa.ArrowInvalid, pa.ArrowTypeError, pa.ArrowNotImplementedError):
            arrays.append(pa.array([None if value is None else str(value) for value in values], type=pa.string()))
    table = pa.Table.from_arrays(arrays, names=columns)
    # Carry the HogQL/ClickHouse type names alongside the Arrow schema — the FE viz
    # layer needs them (numeric/date axis detection) and Arrow types are lossier.
    if types:
        table = table.replace_schema_metadata({"hogql_types": json.dumps(types)})
    sink = pa.BufferOutputStream()
    with pa.ipc.new_stream(sink, table.schema) as writer:
        writer.write_table(table)
    return sink.getvalue().to_pybytes()


def _verify_request_token(request: HttpRequest) -> DataPlaneClaims | JsonResponse:
    authorization = request.headers.get("Authorization", "")
    token = authorization[len("Bearer ") :].strip() if authorization.startswith("Bearer ") else ""
    if not token:
        return JsonResponse({"error": "Missing authorization bearer token"}, status=401)
    try:
        return verify_data_plane_token(token)
    except signing.BadSignature:
        return JsonResponse({"error": "Invalid data-plane token"}, status=401)


@extend_schema(
    tags=["notebooks"],
    request=NotebookSQLV2DataPlaneRequestSerializer,
    responses={
        202: OpenApiResponse(description="Query accepted; poll the status endpoint with the returned query_id"),
        400: OpenApiResponse(description="Invalid request body or HogQL syntax error"),
        401: OpenApiResponse(description="Missing or invalid data-plane token"),
        404: OpenApiResponse(description="Notebook not found"),
    },
    summary="SQLV2 data-plane query",
    description=(
        "Internal endpoint the notebook sandbox POSTs HogQL to. Authenticated with the signed "
        "data-plane token minted at run dispatch (no session). Validates and enqueues the query "
        "for the notebook's team via the async query manager — HogQL access controls apply — "
        "and returns a query_id for the sandbox to poll."
    ),
)
def notebook_sql_v2_data_plane(request: HttpRequest) -> HttpResponse:
    if request.method != "POST":
        return JsonResponse({"error": "Method not allowed"}, status=405)

    claims = _verify_request_token(request)
    if isinstance(claims, JsonResponse):
        return claims

    try:
        body = json.loads(request.body)
    except (json.JSONDecodeError, ValueError):
        return JsonResponse({"error": "Invalid JSON body"}, status=400)

    serializer = NotebookSQLV2DataPlaneRequestSerializer(data=body)
    if not serializer.is_valid():
        # The error string is what the kernel surfaces to the user, so make it say which field failed.
        detail = "; ".join(
            f"{field}: {' '.join(str(error) for error in errors)}" for field, errors in serializer.errors.items()
        )
        return JsonResponse({"error": f"Invalid request body — {detail}", "detail": serializer.errors}, status=400)
    data = serializer.validated_data

    if not Notebook.objects.filter(team_id=claims.team_id, short_id=claims.notebook_short_id).exists():
        return JsonResponse({"error": "Notebook not found"}, status=404)

    # This request is the kernel's only observable sign of life during a run, so it resets the
    # run's watchdog clock. A python cell materializes one input per upstream node, one after
    # another, and without this the watchdog would count that whole sequence against a single
    # budget and fail a cell that is working correctly.
    if claims.run_id:
        touch_run_progress(claims.team_id, claims.notebook_short_id, claims.run_id)
    team = Team.objects.get(id=claims.team_id)
    user = User.objects.filter(id=claims.user_id).first() if claims.user_id else None

    try:
        # Validate the user's HogQL up front so syntax errors fail here with a clear
        # message instead of surfacing through the async status.
        parse_select(data["query"])
    except ExposedHogQLError as exc:
        return JsonResponse({"error": str(exc)}, status=400)

    bounded = apply_page_bounds(data["query"], limit=data["limit"], offset=data["offset"])

    if data["delivery"] == "object":
        # The `notebooks-frame-store` flag carries the rollout on its own; the only other
        # condition is that the deployment has object storage to write to. Failing either
        # falls through to the inline transport below, which is correct for any user but
        # clamped at the async row ceiling. DEBUG stands in for the flag, the way the SQLV2
        # endpoints already treat `revamped-py-notebooks`, so local dev takes the object
        # path without a flag on whichever project this instance sends analytics to.
        frame_store_configured = frame_store.is_enabled()
        if frame_store_configured and (settings.DEBUG or is_frame_store_enabled(user)):
            # Whole-frame materialization: stream the result to object storage via a
            # Temporal worker; the poll answers with a 302 to a presigned URL. The
            # frame_materialize module is imported lazily — it pulls temporalio and the
            # worker ClickHouse client, which must stay off the urls.py import path.
            from products.notebooks.backend.temporal.frame_materialize import (  # noqa: PLC0415
                enqueue_frame_materialization,
            )

            try:
                with tags_context(product=Product.NOTEBOOKS, feature=Feature.QUERY, team_id=team.id):
                    status = enqueue_frame_materialization(
                        team=team,
                        user_id=user.id if user else None,
                        notebook_short_id=claims.notebook_short_id,
                        query=bounded,
                        ch_writes=is_frame_store_ch_writes_enabled(user),
                        _test_only_inline=settings.TEST,
                    )
            except Exception:
                logger.exception(
                    "notebook_frame_materialize_enqueue_failed", notebook_short_id=claims.notebook_short_id
                )
                return JsonResponse({"error": "Query could not be scheduled."}, status=500)
            return JsonResponse({"query_id": status.id, "delivery": DELIVERY_OBJECT_RELAY}, status=202)
        if frame_store_configured:
            # The environment is provisioned but this user is outside the rollout, which is
            # the expected state for most users while the flag ramps. Counted, not logged:
            # at warning level this would drown the misconfiguration case below.
            FRAME_STORE_FALLBACK_COUNTER.labels(reason="not_in_rollout").inc()
        else:
            # Degraded mode: the cell still runs over the inline (Redis) transport, clamped
            # at the async row ceiling, instead of hard-failing. Loud on purpose, because a
            # deployment with the flag on and no object storage cannot serve a frame at all.
            FRAME_STORE_FALLBACK_COUNTER.labels(reason="not_configured").inc()
            logger.warning(
                "notebook_frame_store_fallback_inline",
                notebook_short_id=claims.notebook_short_id,
                team_id=claims.team_id,
                object_storage_enabled=settings.OBJECT_STORAGE_ENABLED,
            )

    try:
        with tags_context(product=Product.NOTEBOOKS, feature=Feature.QUERY, team_id=team.id):
            status = enqueue_process_query_task(
                team=team,
                user_id=user.id if user else None,
                query_json={"kind": "HogQLQuery", "query": bounded},
                # Dispatch normally rides transaction.on_commit, which never fires inside
                # a test transaction — run inline there, like the manager's own tests do.
                _test_only_bypass_celery=settings.TEST,
            )
    except Exception:
        logger.exception("notebook_sql_v2_data_plane_enqueue_failed", notebook_short_id=claims.notebook_short_id)
        return JsonResponse({"error": "Query could not be scheduled."}, status=500)

    # Reached either because the caller wanted inline delivery or because an object request
    # fell through the two gates above, so this is also the honest label for a fallback.
    return JsonResponse({"query_id": status.id, "delivery": DELIVERY_INLINE}, status=202)


@extend_schema(
    tags=["notebooks"],
    responses={
        (200, ARROW_STREAM_CONTENT_TYPE): OpenApiResponse(description="Query result as an Arrow IPC stream"),
        202: OpenApiResponse(description="Query is still running"),
        302: OpenApiResponse(description="Object-delivery result; Location is a short-lived presigned download URL"),
        400: OpenApiResponse(description="Query failed"),
        401: OpenApiResponse(description="Missing or invalid data-plane token"),
        404: OpenApiResponse(description="Query not found or expired"),
    },
    summary="SQLV2 data-plane query status",
    description=(
        "Internal endpoint the notebook sandbox polls for an enqueued data-plane query. "
        "Returns 202 while the query runs; once complete, inline deliveries return the rows "
        "as an Arrow IPC stream and object deliveries return a 302 redirect to a presigned "
        "download URL for the same bytes."
    ),
)
def notebook_sql_v2_data_plane_status(request: HttpRequest, query_id: str) -> HttpResponse:
    if request.method != "GET":
        return JsonResponse({"error": "Method not allowed"}, status=405)

    claims = _verify_request_token(request)
    if isinstance(claims, JsonResponse):
        return claims

    try:
        status = get_query_status(team_id=claims.team_id, query_id=query_id)
    except QueryNotFoundError:
        return JsonResponse({"error": "Query not found or expired"}, status=404)

    if not status.complete:
        return JsonResponse({"status": "running"}, status=202)
    if status.error:
        return JsonResponse({"error": status.error_message or "Query execution failed."}, status=400)

    results: dict[str, Any] = status.results or {}

    object_key = results.get("object_key")
    if object_key:
        # Object delivery: the status carries a pointer, not rows. The token was verified
        # above; presign_get additionally refuses keys outside this team's prefix. The
        # presigned URL is a bearer secret — it must never be logged.
        try:
            # Sign against the bucket the writer recorded. A status written before a bucket
            # change still points at the old bucket, and signing it against the new one
            # would 404 every frame materialized in the window before that deploy.
            recorded_bucket = results.get("bucket")
            presigned_url = frame_store.presign_get(
                str(object_key), claims.team_id, bucket=str(recorded_bucket) if recorded_bucket else None
            )
        except frame_store.FrameStoreError:
            logger.exception("notebook_frame_presign_failed", team_id=claims.team_id, query_id=query_id)
            return JsonResponse({"error": "The frame download could not be prepared. Try re-running."}, status=500)
        return HttpResponseRedirect(presigned_url)

    columns = [str(column) for column in (results.get("columns") or [])]
    types = [[str(name), str(type_name)] for name, type_name in (results.get("types") or [])]
    payload = _rows_to_arrow_bytes(columns, results.get("results") or [], types)
    return HttpResponse(payload, content_type=ARROW_STREAM_CONTENT_TYPE)
