/**
 * Auto-generated Zod validation schemas from the Django backend OpenAPI schema.
 * To modify these schemas, update the Django serializers or views, then run:
 *   hogli build:openapi
 * Questions or issues? #team-devex on Slack
 *
 * PostHog API - generated
 * OpenAPI spec version: 1.0.0
 */
import * as zod from 'zod'

/**
 * The API for interacting with Notebooks. This feature is in early access and the API can have breaking changes without announcement.
 */
export const notebooksCreateBodyTitleMax = 256

export const notebooksCreateBodyVersionMin = -2147483648
export const notebooksCreateBodyVersionMax = 2147483647

export const notebooksCreateBodyVariablesItemNameMax = 200

export const NotebooksCreateBody = /* @__PURE__ */ zod.object({
    title: zod.string().max(notebooksCreateBodyTitleMax).nullish().describe('Title of the notebook.'),
    content: zod.unknown().optional().describe('Notebook content as a ProseMirror JSON document structure.'),
    text_content: zod.string().nullish().describe('Plain text representation of the notebook content for search.'),
    version: zod
        .number()
        .min(notebooksCreateBodyVersionMin)
        .max(notebooksCreateBodyVersionMax)
        .optional()
        .describe(
            'Version number for optimistic concurrency control. Must match the current version when updating content.'
        ),
    deleted: zod.boolean().optional().describe('Whether the notebook has been soft-deleted.'),
    variables: zod
        .array(
            zod
                .object({
                    name: zod
                        .string()
                        .max(notebooksCreateBodyVariablesItemNameMax)
                        .describe(
                            'Identifier the cell reads: `{name}` in a SQL cell, a plain global in a Python cell.'
                        ),
                    type: zod
                        .string()
                        .describe(
                            "How to coerce the value: 'string', 'number', 'boolean', or 'date'. Unknown types read as 'string'."
                        ),
                    value: zod
                        .unknown()
                        .optional()
                        .describe(
                            "The variable's current value. A 'date' accepts an absolute date or a relative expression ('-7d', 'mStart'), resolved against the project timezone."
                        ),
                })
                .describe("One notebook-level variable. Shared by the notebook's own `variables` field and a run body.")
        )
        .optional()
        .describe(
            'Notebook-level variables, in display order. A SQL cell reads one as a `{name}` placeholder and a Python cell as a global. Names must be unique.'
        ),
    _create_in_folder: zod.string().optional(),
})

/**
 * The API for interacting with Notebooks. This feature is in early access and the API can have breaking changes without announcement.
 */
export const notebooksUpdateBodyTitleMax = 256

export const notebooksUpdateBodyVersionMin = -2147483648
export const notebooksUpdateBodyVersionMax = 2147483647

export const notebooksUpdateBodyVariablesItemNameMax = 200

export const NotebooksUpdateBody = /* @__PURE__ */ zod.object({
    title: zod.string().max(notebooksUpdateBodyTitleMax).nullish().describe('Title of the notebook.'),
    content: zod.unknown().optional().describe('Notebook content as a ProseMirror JSON document structure.'),
    text_content: zod.string().nullish().describe('Plain text representation of the notebook content for search.'),
    version: zod
        .number()
        .min(notebooksUpdateBodyVersionMin)
        .max(notebooksUpdateBodyVersionMax)
        .optional()
        .describe(
            'Version number for optimistic concurrency control. Must match the current version when updating content.'
        ),
    deleted: zod.boolean().optional().describe('Whether the notebook has been soft-deleted.'),
    variables: zod
        .array(
            zod
                .object({
                    name: zod
                        .string()
                        .max(notebooksUpdateBodyVariablesItemNameMax)
                        .describe(
                            'Identifier the cell reads: `{name}` in a SQL cell, a plain global in a Python cell.'
                        ),
                    type: zod
                        .string()
                        .describe(
                            "How to coerce the value: 'string', 'number', 'boolean', or 'date'. Unknown types read as 'string'."
                        ),
                    value: zod
                        .unknown()
                        .optional()
                        .describe(
                            "The variable's current value. A 'date' accepts an absolute date or a relative expression ('-7d', 'mStart'), resolved against the project timezone."
                        ),
                })
                .describe("One notebook-level variable. Shared by the notebook's own `variables` field and a run body.")
        )
        .optional()
        .describe(
            'Notebook-level variables, in display order. A SQL cell reads one as a `{name}` placeholder and a Python cell as a global. Names must be unique.'
        ),
    _create_in_folder: zod.string().optional(),
})

/**
 * The API for interacting with Notebooks. This feature is in early access and the API can have breaking changes without announcement.
 */
export const notebooksPartialUpdateBodyTitleMax = 256

export const notebooksPartialUpdateBodyVersionMin = -2147483648
export const notebooksPartialUpdateBodyVersionMax = 2147483647

export const notebooksPartialUpdateBodyVariablesItemNameMax = 200

export const NotebooksPartialUpdateBody = /* @__PURE__ */ zod.object({
    title: zod.string().max(notebooksPartialUpdateBodyTitleMax).nullish().describe('Title of the notebook.'),
    content: zod.unknown().optional().describe('Notebook content as a ProseMirror JSON document structure.'),
    text_content: zod.string().nullish().describe('Plain text representation of the notebook content for search.'),
    version: zod
        .number()
        .min(notebooksPartialUpdateBodyVersionMin)
        .max(notebooksPartialUpdateBodyVersionMax)
        .optional()
        .describe(
            'Version number for optimistic concurrency control. Must match the current version when updating content.'
        ),
    deleted: zod.boolean().optional().describe('Whether the notebook has been soft-deleted.'),
    variables: zod
        .array(
            zod
                .object({
                    name: zod
                        .string()
                        .max(notebooksPartialUpdateBodyVariablesItemNameMax)
                        .describe(
                            'Identifier the cell reads: `{name}` in a SQL cell, a plain global in a Python cell.'
                        ),
                    type: zod
                        .string()
                        .describe(
                            "How to coerce the value: 'string', 'number', 'boolean', or 'date'. Unknown types read as 'string'."
                        ),
                    value: zod
                        .unknown()
                        .optional()
                        .describe(
                            "The variable's current value. A 'date' accepts an absolute date or a relative expression ('-7d', 'mStart'), resolved against the project timezone."
                        ),
                })
                .describe("One notebook-level variable. Shared by the notebook's own `variables` field and a run body.")
        )
        .optional()
        .describe(
            'Notebook-level variables, in display order. A SQL cell reads one as a `{name}` placeholder and a Python cell as a global. Names must be unique.'
        ),
    _create_in_folder: zod.string().optional(),
})

/**
 * The API for interacting with Notebooks. This feature is in early access and the API can have breaking changes without announcement.
 */
export const notebooksCollabMarkdownSaveCreateBodyTextContentDefault = ``
export const notebooksCollabMarkdownSaveCreateBodyCursorOneHeadMin = 0

export const notebooksCollabMarkdownSaveCreateBodyCursorOneNodeIndexMin = 0

export const notebooksCollabMarkdownSaveCreateBodyCursorOneOffsetMin = 0

export const notebooksCollabMarkdownSaveCreateBodyCursorOneListItemIndexMin = 0

export const NotebooksCollabMarkdownSaveCreateBody = /* @__PURE__ */ zod.object({
    client_id: zod
        .string()
        .describe('Unique identifier for the client session, used to skip self-echo on the update stream.'),
    version: zod
        .number()
        .describe('The notebook version the submitted content is based on (optimistic concurrency baseline).'),
    content: zod
        .unknown()
        .describe('The full markdown notebook document: a ProseMirror doc wrapping a single markdown node.'),
    text_content: zod
        .string()
        .default(notebooksCollabMarkdownSaveCreateBodyTextContentDefault)
        .describe('Plain text for search indexing.'),
    title: zod.string().optional().describe('Updated notebook title.'),
    cursor: zod
        .object({
            head: zod
                .number()
                .min(notebooksCollabMarkdownSaveCreateBodyCursorOneHeadMin)
                .optional()
                .describe('ProseMirror selection head position (rich v1 notebooks).'),
            node_index: zod
                .number()
                .min(notebooksCollabMarkdownSaveCreateBodyCursorOneNodeIndexMin)
                .optional()
                .describe("Index of the caret's block node in the markdown notebook document (markdown notebooks)."),
            offset: zod
                .number()
                .min(notebooksCollabMarkdownSaveCreateBodyCursorOneOffsetMin)
                .optional()
                .describe('Caret offset in the plain text of the focused editable element, in UTF-16 code units.'),
            list_item_index: zod
                .number()
                .min(notebooksCollabMarkdownSaveCreateBodyCursorOneListItemIndexMin)
                .optional()
                .describe('Index of the focused list item when the caret is inside a list block.'),
        })
        .optional()
        .describe(
            "The author's caret in the saved markdown, broadcast with the update so other clients can move the author's remote caret together with the text change."
        ),
})

/**
 * The API for interacting with Notebooks. This feature is in early access and the API can have breaking changes without announcement.
 */
export const notebooksCollabPresenceCreateBodyClientIdMax = 200

export const notebooksCollabPresenceCreateBodyVersionMin = 0

export const notebooksCollabPresenceCreateBodyCursorOneHeadMin = 0

export const notebooksCollabPresenceCreateBodyCursorOneNodeIndexMin = 0

export const notebooksCollabPresenceCreateBodyCursorOneOffsetMin = 0

export const notebooksCollabPresenceCreateBodyCursorOneListItemIndexMin = 0

export const NotebooksCollabPresenceCreateBody = /* @__PURE__ */ zod.object({
    client_id: zod
        .string()
        .max(notebooksCollabPresenceCreateBodyClientIdMax)
        .describe('Unique identifier for the client session, used to skip self-echo on the update stream.'),
    version: zod
        .number()
        .min(notebooksCollabPresenceCreateBodyVersionMin)
        .describe('The notebook version the cursor position is relative to.'),
    cursor: zod
        .object({
            head: zod
                .number()
                .min(notebooksCollabPresenceCreateBodyCursorOneHeadMin)
                .optional()
                .describe('ProseMirror selection head position (rich v1 notebooks).'),
            node_index: zod
                .number()
                .min(notebooksCollabPresenceCreateBodyCursorOneNodeIndexMin)
                .optional()
                .describe("Index of the caret's block node in the markdown notebook document (markdown notebooks)."),
            offset: zod
                .number()
                .min(notebooksCollabPresenceCreateBodyCursorOneOffsetMin)
                .optional()
                .describe('Caret offset in the plain text of the focused editable element, in UTF-16 code units.'),
            list_item_index: zod
                .number()
                .min(notebooksCollabPresenceCreateBodyCursorOneListItemIndexMin)
                .optional()
                .describe('Index of the focused list item when the caret is inside a list block.'),
        })
        .describe("The caller's caret position, broadcast to other clients on this notebook's collab stream."),
})

/**
 * The API for interacting with Notebooks. This feature is in early access and the API can have breaking changes without announcement.
 */
export const notebooksCollabSaveCreateBodyTextContentDefault = ``

export const NotebooksCollabSaveCreateBody = /* @__PURE__ */ zod.object({
    client_id: zod.string().describe('Unique identifier for the client session.'),
    version: zod.number().describe("The collab version the client's steps are based on."),
    steps: zod.array(zod.unknown()).describe('List of ProseMirror step JSON objects to apply.'),
    content: zod.unknown().describe('The resulting ProseMirror document after applying the steps locally.'),
    text_content: zod
        .string()
        .default(notebooksCollabSaveCreateBodyTextContentDefault)
        .describe('Plain text for search indexing.'),
    title: zod.string().optional().describe('Updated notebook title.'),
    cursor_head: zod.number().nullish().describe('ProseMirror cursor head position after applying steps.'),
})

/**
 * The API for interacting with Notebooks. This feature is in early access and the API can have breaking changes without announcement.
 */
export const notebooksHogqlExecuteCreateBodyTitleMax = 256

export const notebooksHogqlExecuteCreateBodyVersionMin = -2147483648
export const notebooksHogqlExecuteCreateBodyVersionMax = 2147483647

export const notebooksHogqlExecuteCreateBodyVariablesItemNameMax = 200

export const NotebooksHogqlExecuteCreateBody = /* @__PURE__ */ zod.object({
    title: zod.string().max(notebooksHogqlExecuteCreateBodyTitleMax).nullish().describe('Title of the notebook.'),
    content: zod.unknown().optional().describe('Notebook content as a ProseMirror JSON document structure.'),
    text_content: zod.string().nullish().describe('Plain text representation of the notebook content for search.'),
    version: zod
        .number()
        .min(notebooksHogqlExecuteCreateBodyVersionMin)
        .max(notebooksHogqlExecuteCreateBodyVersionMax)
        .optional()
        .describe(
            'Version number for optimistic concurrency control. Must match the current version when updating content.'
        ),
    deleted: zod.boolean().optional().describe('Whether the notebook has been soft-deleted.'),
    variables: zod
        .array(
            zod
                .object({
                    name: zod
                        .string()
                        .max(notebooksHogqlExecuteCreateBodyVariablesItemNameMax)
                        .describe(
                            'Identifier the cell reads: `{name}` in a SQL cell, a plain global in a Python cell.'
                        ),
                    type: zod
                        .string()
                        .describe(
                            "How to coerce the value: 'string', 'number', 'boolean', or 'date'. Unknown types read as 'string'."
                        ),
                    value: zod
                        .unknown()
                        .optional()
                        .describe(
                            "The variable's current value. A 'date' accepts an absolute date or a relative expression ('-7d', 'mStart'), resolved against the project timezone."
                        ),
                })
                .describe("One notebook-level variable. Shared by the notebook's own `variables` field and a run body.")
        )
        .optional()
        .describe(
            'Notebook-level variables, in display order. A SQL cell reads one as a `{name}` placeholder and a Python cell as a global. Names must be unique.'
        ),
    _create_in_folder: zod.string().optional(),
})

/**
 * Set the notebook's kernel compute configuration. Applies at sandbox provision time: a currently running kernel keeps its resources until restarted.
 */
export const NotebooksKernelConfigCreateBody = /* @__PURE__ */ zod.object({
    cpu_cores: zod
        .number()
        .optional()
        .describe("CPU cores for the notebook's sandbox kernel; must be a supported option."),
    memory_gb: zod
        .number()
        .optional()
        .describe("Memory in GB for the notebook's sandbox kernel; must be a supported option."),
    idle_timeout_seconds: zod
        .number()
        .optional()
        .describe('Seconds of inactivity before the sandbox kernel shuts down.'),
})

/**
 * The API for interacting with Notebooks. This feature is in early access and the API can have breaking changes without announcement.
 */
export const notebooksKernelExecuteCreateBodyTitleMax = 256

export const notebooksKernelExecuteCreateBodyVersionMin = -2147483648
export const notebooksKernelExecuteCreateBodyVersionMax = 2147483647

export const notebooksKernelExecuteCreateBodyVariablesItemNameMax = 200

export const NotebooksKernelExecuteCreateBody = /* @__PURE__ */ zod.object({
    title: zod.string().max(notebooksKernelExecuteCreateBodyTitleMax).nullish().describe('Title of the notebook.'),
    content: zod.unknown().optional().describe('Notebook content as a ProseMirror JSON document structure.'),
    text_content: zod.string().nullish().describe('Plain text representation of the notebook content for search.'),
    version: zod
        .number()
        .min(notebooksKernelExecuteCreateBodyVersionMin)
        .max(notebooksKernelExecuteCreateBodyVersionMax)
        .optional()
        .describe(
            'Version number for optimistic concurrency control. Must match the current version when updating content.'
        ),
    deleted: zod.boolean().optional().describe('Whether the notebook has been soft-deleted.'),
    variables: zod
        .array(
            zod
                .object({
                    name: zod
                        .string()
                        .max(notebooksKernelExecuteCreateBodyVariablesItemNameMax)
                        .describe(
                            'Identifier the cell reads: `{name}` in a SQL cell, a plain global in a Python cell.'
                        ),
                    type: zod
                        .string()
                        .describe(
                            "How to coerce the value: 'string', 'number', 'boolean', or 'date'. Unknown types read as 'string'."
                        ),
                    value: zod
                        .unknown()
                        .optional()
                        .describe(
                            "The variable's current value. A 'date' accepts an absolute date or a relative expression ('-7d', 'mStart'), resolved against the project timezone."
                        ),
                })
                .describe("One notebook-level variable. Shared by the notebook's own `variables` field and a run body.")
        )
        .optional()
        .describe(
            'Notebook-level variables, in display order. A SQL cell reads one as a `{name}` placeholder and a Python cell as a global. Names must be unique.'
        ),
    _create_in_folder: zod.string().optional(),
})

/**
 * The API for interacting with Notebooks. This feature is in early access and the API can have breaking changes without announcement.
 */
export const notebooksKernelExecuteStreamCreateBodyTitleMax = 256

export const notebooksKernelExecuteStreamCreateBodyVersionMin = -2147483648
export const notebooksKernelExecuteStreamCreateBodyVersionMax = 2147483647

export const notebooksKernelExecuteStreamCreateBodyVariablesItemNameMax = 200

export const NotebooksKernelExecuteStreamCreateBody = /* @__PURE__ */ zod.object({
    title: zod
        .string()
        .max(notebooksKernelExecuteStreamCreateBodyTitleMax)
        .nullish()
        .describe('Title of the notebook.'),
    content: zod.unknown().optional().describe('Notebook content as a ProseMirror JSON document structure.'),
    text_content: zod.string().nullish().describe('Plain text representation of the notebook content for search.'),
    version: zod
        .number()
        .min(notebooksKernelExecuteStreamCreateBodyVersionMin)
        .max(notebooksKernelExecuteStreamCreateBodyVersionMax)
        .optional()
        .describe(
            'Version number for optimistic concurrency control. Must match the current version when updating content.'
        ),
    deleted: zod.boolean().optional().describe('Whether the notebook has been soft-deleted.'),
    variables: zod
        .array(
            zod
                .object({
                    name: zod
                        .string()
                        .max(notebooksKernelExecuteStreamCreateBodyVariablesItemNameMax)
                        .describe(
                            'Identifier the cell reads: `{name}` in a SQL cell, a plain global in a Python cell.'
                        ),
                    type: zod
                        .string()
                        .describe(
                            "How to coerce the value: 'string', 'number', 'boolean', or 'date'. Unknown types read as 'string'."
                        ),
                    value: zod
                        .unknown()
                        .optional()
                        .describe(
                            "The variable's current value. A 'date' accepts an absolute date or a relative expression ('-7d', 'mStart'), resolved against the project timezone."
                        ),
                })
                .describe("One notebook-level variable. Shared by the notebook's own `variables` field and a run body.")
        )
        .optional()
        .describe(
            'Notebook-level variables, in display order. A SQL cell reads one as a `{name}` placeholder and a Python cell as a global. Names must be unique.'
        ),
    _create_in_folder: zod.string().optional(),
})

/**
 * The API for interacting with Notebooks. This feature is in early access and the API can have breaking changes without announcement.
 */
export const notebooksKernelRestartCreateBodyTitleMax = 256

export const notebooksKernelRestartCreateBodyVersionMin = -2147483648
export const notebooksKernelRestartCreateBodyVersionMax = 2147483647

export const notebooksKernelRestartCreateBodyVariablesItemNameMax = 200

export const NotebooksKernelRestartCreateBody = /* @__PURE__ */ zod.object({
    title: zod.string().max(notebooksKernelRestartCreateBodyTitleMax).nullish().describe('Title of the notebook.'),
    content: zod.unknown().optional().describe('Notebook content as a ProseMirror JSON document structure.'),
    text_content: zod.string().nullish().describe('Plain text representation of the notebook content for search.'),
    version: zod
        .number()
        .min(notebooksKernelRestartCreateBodyVersionMin)
        .max(notebooksKernelRestartCreateBodyVersionMax)
        .optional()
        .describe(
            'Version number for optimistic concurrency control. Must match the current version when updating content.'
        ),
    deleted: zod.boolean().optional().describe('Whether the notebook has been soft-deleted.'),
    variables: zod
        .array(
            zod
                .object({
                    name: zod
                        .string()
                        .max(notebooksKernelRestartCreateBodyVariablesItemNameMax)
                        .describe(
                            'Identifier the cell reads: `{name}` in a SQL cell, a plain global in a Python cell.'
                        ),
                    type: zod
                        .string()
                        .describe(
                            "How to coerce the value: 'string', 'number', 'boolean', or 'date'. Unknown types read as 'string'."
                        ),
                    value: zod
                        .unknown()
                        .optional()
                        .describe(
                            "The variable's current value. A 'date' accepts an absolute date or a relative expression ('-7d', 'mStart'), resolved against the project timezone."
                        ),
                })
                .describe("One notebook-level variable. Shared by the notebook's own `variables` field and a run body.")
        )
        .optional()
        .describe(
            'Notebook-level variables, in display order. A SQL cell reads one as a `{name}` placeholder and a Python cell as a global. Names must be unique.'
        ),
    _create_in_folder: zod.string().optional(),
})

/**
 * The API for interacting with Notebooks. This feature is in early access and the API can have breaking changes without announcement.
 */
export const notebooksKernelStartCreateBodyTitleMax = 256

export const notebooksKernelStartCreateBodyVersionMin = -2147483648
export const notebooksKernelStartCreateBodyVersionMax = 2147483647

export const notebooksKernelStartCreateBodyVariablesItemNameMax = 200

export const NotebooksKernelStartCreateBody = /* @__PURE__ */ zod.object({
    title: zod.string().max(notebooksKernelStartCreateBodyTitleMax).nullish().describe('Title of the notebook.'),
    content: zod.unknown().optional().describe('Notebook content as a ProseMirror JSON document structure.'),
    text_content: zod.string().nullish().describe('Plain text representation of the notebook content for search.'),
    version: zod
        .number()
        .min(notebooksKernelStartCreateBodyVersionMin)
        .max(notebooksKernelStartCreateBodyVersionMax)
        .optional()
        .describe(
            'Version number for optimistic concurrency control. Must match the current version when updating content.'
        ),
    deleted: zod.boolean().optional().describe('Whether the notebook has been soft-deleted.'),
    variables: zod
        .array(
            zod
                .object({
                    name: zod
                        .string()
                        .max(notebooksKernelStartCreateBodyVariablesItemNameMax)
                        .describe(
                            'Identifier the cell reads: `{name}` in a SQL cell, a plain global in a Python cell.'
                        ),
                    type: zod
                        .string()
                        .describe(
                            "How to coerce the value: 'string', 'number', 'boolean', or 'date'. Unknown types read as 'string'."
                        ),
                    value: zod
                        .unknown()
                        .optional()
                        .describe(
                            "The variable's current value. A 'date' accepts an absolute date or a relative expression ('-7d', 'mStart'), resolved against the project timezone."
                        ),
                })
                .describe("One notebook-level variable. Shared by the notebook's own `variables` field and a run body.")
        )
        .optional()
        .describe(
            'Notebook-level variables, in display order. A SQL cell reads one as a `{name}` placeholder and a Python cell as a global. Names must be unique.'
        ),
    _create_in_folder: zod.string().optional(),
})

/**
 * The API for interacting with Notebooks. This feature is in early access and the API can have breaking changes without announcement.
 */
export const notebooksKernelStopCreateBodyTitleMax = 256

export const notebooksKernelStopCreateBodyVersionMin = -2147483648
export const notebooksKernelStopCreateBodyVersionMax = 2147483647

export const notebooksKernelStopCreateBodyVariablesItemNameMax = 200

export const NotebooksKernelStopCreateBody = /* @__PURE__ */ zod.object({
    title: zod.string().max(notebooksKernelStopCreateBodyTitleMax).nullish().describe('Title of the notebook.'),
    content: zod.unknown().optional().describe('Notebook content as a ProseMirror JSON document structure.'),
    text_content: zod.string().nullish().describe('Plain text representation of the notebook content for search.'),
    version: zod
        .number()
        .min(notebooksKernelStopCreateBodyVersionMin)
        .max(notebooksKernelStopCreateBodyVersionMax)
        .optional()
        .describe(
            'Version number for optimistic concurrency control. Must match the current version when updating content.'
        ),
    deleted: zod.boolean().optional().describe('Whether the notebook has been soft-deleted.'),
    variables: zod
        .array(
            zod
                .object({
                    name: zod
                        .string()
                        .max(notebooksKernelStopCreateBodyVariablesItemNameMax)
                        .describe(
                            'Identifier the cell reads: `{name}` in a SQL cell, a plain global in a Python cell.'
                        ),
                    type: zod
                        .string()
                        .describe(
                            "How to coerce the value: 'string', 'number', 'boolean', or 'date'. Unknown types read as 'string'."
                        ),
                    value: zod
                        .unknown()
                        .optional()
                        .describe(
                            "The variable's current value. A 'date' accepts an absolute date or a relative expression ('-7d', 'mStart'), resolved against the project timezone."
                        ),
                })
                .describe("One notebook-level variable. Shared by the notebook's own `variables` field and a run body.")
        )
        .optional()
        .describe(
            'Notebook-level variables, in display order. A SQL cell reads one as a `{name}` placeholder and a Python cell as a global. Names must be unique.'
        ),
    _create_in_folder: zod.string().optional(),
})

/**
 * Dispatch an asynchronous run of a notebook SQL or Python cell. Returns a run_id immediately; poll the run result endpoint until the status is terminal. One run at a time per notebook. Flag-gated (revamped-py-notebooks).
 */
export const notebooksSqlV2RunCreateBodyNodeTypeDefault = `hogql`
export const notebooksSqlV2RunCreateBodyOutputNameDefault = ``
export const notebooksSqlV2RunCreateBodyRefsKindDefault = `hogql`
export const notebooksSqlV2RunCreateBodyVariablesItemNameMax = 200

export const notebooksSqlV2RunCreateBodySendRawQueryDefault = false

export const NotebooksSqlV2RunCreateBody = /* @__PURE__ */ zod.object({
    node_id: zod.string().describe('ProseMirror node id of the SQLV2 node being run.'),
    node_type: zod
        .enum(['hogql', 'python'])
        .describe('\* `hogql` - hogql\n\* `python` - python')
        .default(notebooksSqlV2RunCreateBodyNodeTypeDefault)
        .describe(
            "Execution kind. 'hogql' is a SQL node — pushed to ClickHouse, or rerouted to the sandbox's DuckDB when it references a local frame; 'python' runs the code in the sandbox kernel, materializing referenced upstream nodes as pandas frames first.\n\n\* `hogql` - hogql\n\* `python` - python"
        ),
    code: zod
        .string()
        .describe("The node's source — SQL for a hogql node, Python for a python node. Must not be blank."),
    output_name: zod
        .string()
        .default(notebooksSqlV2RunCreateBodyOutputNameDefault)
        .describe(
            'Kernel nodes only: the dataframe variable to bind the result to in the kernel namespace (a python node falls back to the last expression for its preview).'
        ),
    refs: zod
        .record(
            zod.string(),
            zod.object({
                node_id: zod.string().describe('ProseMirror node id of the upstream node this name points at.'),
                kind: zod
                    .enum(['hogql', 'local'])
                    .describe('\* `hogql` - hogql\n\* `local` - local')
                    .default(notebooksSqlV2RunCreateBodyRefsKindDefault)
                    .describe(
                        "What the name resolves to: 'hogql' is a SQL node's query definition (resolved to its last-run HogQL); 'local' is a dataframe a Python node bound in the kernel namespace.\n\n\* `hogql` - hogql\n\* `local` - local"
                    ),
            })
        )
        .optional()
        .describe(
            "Available upstream nodes, keyed by dataframe name. A SQL node inlines referenced hogql refs as CTEs — unless it references a local ref, which reroutes the run to the sandbox's DuckDB; a python node materializes the hogql refs its code reads as pandas frames."
        ),
    variables: zod
        .array(
            zod
                .object({
                    name: zod
                        .string()
                        .max(notebooksSqlV2RunCreateBodyVariablesItemNameMax)
                        .describe(
                            'Identifier the cell reads: `{name}` in a SQL cell, a plain global in a Python cell.'
                        ),
                    type: zod
                        .string()
                        .describe(
                            "How to coerce the value: 'string', 'number', 'boolean', or 'date'. Unknown types read as 'string'."
                        ),
                    value: zod
                        .unknown()
                        .optional()
                        .describe(
                            "The variable's current value. A 'date' accepts an absolute date or a relative expression ('-7d', 'mStart'), resolved against the project timezone."
                        ),
                })
                .describe("One notebook-level variable. Shared by the notebook's own `variables` field and a run body.")
        )
        .optional()
        .describe(
            'Notebook-level variables in scope for this run. A SQL node has each `{name}` bound to its value before dispatch; a Python node gets them as globals in the kernel namespace. A SQL node reading a `{name}` that is absent here fails the dispatch.'
        ),
    connection_id: zod
        .uuid()
        .nullish()
        .describe(
            "SQL nodes only: id of a direct-query-capable external data source to run against instead of PostHog's ClickHouse. Omit to query PostHog."
        ),
    send_raw_query: zod
        .boolean()
        .default(notebooksSqlV2RunCreateBodySendRawQueryDefault)
        .describe(
            'Send the code to the selected connection verbatim instead of compiling it from HogQL first. Ignored without connection_id, and incompatible with references to other cells.'
        ),
})

/**
 * The API for interacting with Notebooks. This feature is in early access and the API can have breaking changes without announcement.
 */
export const NotebooksWidgetCancelBody = /* @__PURE__ */ zod.object({
    generation_id: zod.uuid().describe('Generation job to cancel.'),
})

/**
 * The API for interacting with Notebooks. This feature is in early access and the API can have breaking changes without announcement.
 */
export const notebooksWidgetGenerateBodyPromptMax = 20000

export const notebooksWidgetGenerateBodyModelDefault = `claude-sonnet-4-6`
export const notebooksWidgetGenerateBodyGenerationOperationDefault = `regenerate`

export const NotebooksWidgetGenerateBody = /* @__PURE__ */ zod.object({
    prompt: zod.string().max(notebooksWidgetGenerateBodyPromptMax).describe('Instructions for the generated widget.'),
    generation_id: zod.uuid().describe('Idempotency key for this generation job.'),
    model: zod
        .enum(['claude-haiku-4-5', 'claude-sonnet-4-6', 'claude-sonnet-5', 'claude-opus-5'])
        .describe(
            '\* `claude-haiku-4-5` - claude-haiku-4-5\n\* `claude-sonnet-4-6` - claude-sonnet-4-6\n\* `claude-sonnet-5` - claude-sonnet-5\n\* `claude-opus-5` - claude-opus-5'
        )
        .default(notebooksWidgetGenerateBodyModelDefault)
        .describe(
            'AI model used to generate the widget.\n\n\* `claude-haiku-4-5` - claude-haiku-4-5\n\* `claude-sonnet-4-6` - claude-sonnet-4-6\n\* `claude-sonnet-5` - claude-sonnet-5\n\* `claude-opus-5` - claude-opus-5'
        ),
    generation_operation: zod
        .enum(['initial', 'regenerate', 'improve'])
        .describe('\* `initial` - initial\n\* `regenerate` - regenerate\n\* `improve` - improve')
        .default(notebooksWidgetGenerateBodyGenerationOperationDefault)
        .describe(
            'Whether to generate from scratch or improve the current source.\n\n\* `initial` - initial\n\* `regenerate` - regenerate\n\* `improve` - improve'
        ),
})

/**
 * The API for interacting with Notebooks. This feature is in early access and the API can have breaking changes without announcement.
 */
export const NotebooksWidgetRevertBody = /* @__PURE__ */ zod.object({
    version_id: zod.uuid().describe('Earlier version to restore as a new version.'),
    expected_current_version_id: zod.uuid().describe('Current version used for optimistic concurrency.'),
})
