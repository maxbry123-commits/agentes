"""
Tests for GitHub integration in the approve flow.

Uses a local git repo with mocked GitHub API endpoints.
The real code paths are exercised, but HTTP calls are intercepted
and redirected to operate on the local repo.
"""

import re
import json
import base64
import hashlib
import subprocess
from pathlib import Path

import pytest
from unittest.mock import MagicMock

import yaml
import responses

from products.visual_review.backend.facade.enums import RunStatus, SnapshotResult
from products.visual_review.backend.logic import approvals, errors, toleration
from products.visual_review.backend.models import Artifact, Repo, Run, RunSnapshot
from products.visual_review.backend.tests.conftest import PRODUCT_DATABASES

# --- Fixtures ---


@pytest.fixture
def local_git_repo(tmp_path):
    """Create a local git repo with a test branch simulating a PR."""
    repo = tmp_path / "test-repo"
    repo.mkdir()

    # Initialize repo
    subprocess.run(["git", "init"], cwd=repo, capture_output=True, check=True)
    subprocess.run(["git", "config", "user.email", "test@test.com"], cwd=repo, check=True)
    subprocess.run(["git", "config", "user.name", "Test"], cwd=repo, check=True)

    # Create initial commit on main
    snapshots_file = repo / ".snapshots.yml"
    snapshots_file.write_text("version: 1\nsnapshots: {}\n")
    subprocess.run(["git", "add", "."], cwd=repo, check=True)
    subprocess.run(["git", "commit", "-m", "initial"], cwd=repo, check=True)

    # Create feature branch (simulates PR branch)
    subprocess.run(["git", "checkout", "-b", "feature-branch"], cwd=repo, check=True)

    return repo


def _get_head_sha(repo_path: Path) -> str:
    """Get current HEAD SHA of the repo."""
    result = subprocess.run(
        ["git", "rev-parse", "HEAD"],
        cwd=repo_path,
        capture_output=True,
        text=True,
        check=True,
    )
    return result.stdout.strip()


def _get_current_branch(repo_path: Path) -> str:
    """Get current branch name."""
    result = subprocess.run(
        ["git", "rev-parse", "--abbrev-ref", "HEAD"],
        cwd=repo_path,
        capture_output=True,
        text=True,
        check=True,
    )
    return result.stdout.strip()


def _get_file_content(repo_path: Path, file_path: str, branch: str) -> tuple[str, str] | None:
    """Get file content and SHA at a specific branch."""
    # Checkout branch
    subprocess.run(["git", "checkout", branch], cwd=repo_path, capture_output=True, check=True)

    full_path = repo_path / file_path
    if not full_path.exists():
        return None

    content = full_path.read_text()
    # GitHub uses blob SHA, we'll fake it with content hash
    blob_sha = hashlib.sha1(f"blob {len(content)}\0{content}".encode()).hexdigest()
    return content, blob_sha


def _commit_file(repo_path: Path, file_path: str, content: str, message: str, branch: str) -> str:
    """Write file and commit to repo. Returns new commit SHA."""
    subprocess.run(["git", "checkout", branch], cwd=repo_path, capture_output=True, check=True)

    full_path = repo_path / file_path
    full_path.parent.mkdir(parents=True, exist_ok=True)
    full_path.write_text(content)

    subprocess.run(["git", "add", file_path], cwd=repo_path, check=True)
    subprocess.run(["git", "commit", "-m", message], cwd=repo_path, check=True)

    return _get_head_sha(repo_path)


@pytest.fixture
def mock_github_api(local_git_repo):
    """
    Mock GitHub API endpoints to operate on local git repo.

    Intercepts:
    - GET /repos/{owner}/{repo}/pulls/{pr} -> PR info
    - GET /repos/{owner}/{repo}/contents/{path} -> file content
    - PUT /repos/{owner}/{repo}/contents/{path} -> commit file
    """
    with responses.RequestsMock(assert_all_requests_are_fired=False) as rsps:
        # Store repo path for callbacks
        repo_path = local_git_repo

        def pr_callback(request):
            """Return PR info with current branch and SHA."""
            return (
                200,
                {},
                json.dumps(
                    {
                        "head": {
                            "ref": "feature-branch",
                            "sha": _get_head_sha(repo_path),
                        }
                    }
                ),
            )

        def get_file_callback(request):
            """Return file content from local repo."""
            # Extract file path from URL
            match = re.search(r"/contents/(.+?)(?:\?|$)", request.url)
            if not match:
                return (404, {}, json.dumps({"message": "Not Found"}))

            file_path = match.group(1)

            # Get branch from query params
            branch = "feature-branch"
            if "ref=" in request.url:
                branch_match = re.search(r"ref=([^&]+)", request.url)
                if branch_match:
                    branch = branch_match.group(1)

            result = _get_file_content(repo_path, file_path, branch)
            if result is None:
                return (404, {}, json.dumps({"message": "Not Found"}))

            content, blob_sha = result
            encoded = base64.b64encode(content.encode()).decode()

            return (
                200,
                {},
                json.dumps(
                    {
                        "content": encoded,
                        "sha": blob_sha,
                        "encoding": "base64",
                    }
                ),
            )

        def put_file_callback(request):
            """Commit file to local repo."""
            # Extract file path from URL
            match = re.search(r"/contents/(.+?)(?:\?|$)", request.url)
            if not match:
                return (400, {}, json.dumps({"message": "Bad Request"}))

            file_path = match.group(1)
            data = json.loads(request.body)

            content = base64.b64decode(data["content"]).decode()
            message = data["message"]
            branch = data["branch"]

            commit_sha = _commit_file(repo_path, file_path, content, message, branch)
            file_sha = hashlib.sha1(f"blob {len(content)}\0{content}".encode()).hexdigest()

            return (
                200,
                {},
                json.dumps(
                    {
                        "commit": {
                            "sha": commit_sha,
                            "html_url": f"https://github.com/test/repo/commit/{commit_sha}",
                        },
                        "content": {
                            "sha": file_sha,
                        },
                    }
                ),
            )

        def status_callback(request):
            data = json.loads(request.body)
            return (201, {}, json.dumps({"id": 1, "state": data["state"]}))

        # Register callbacks
        rsps.add_callback(
            responses.GET,
            re.compile(r"https://api\.github\.com/repos/.+/pulls/\d+"),
            callback=pr_callback,
        )
        rsps.add_callback(
            responses.GET,
            re.compile(r"https://api\.github\.com/repos/.+/contents/.+"),
            callback=get_file_callback,
        )
        rsps.add_callback(
            responses.PUT,
            re.compile(r"https://api\.github\.com/repos/.+/contents/.+"),
            callback=put_file_callback,
        )
        rsps.add_callback(
            responses.POST,
            re.compile(r"https://api\.github\.com/repos/.+/statuses/.+"),
            callback=status_callback,
        )

        yield rsps


@pytest.fixture
def mock_github_integration(team, mocker):
    """
    Create a mock GitHub integration for the team.

    This patches the Integration lookup to return a fake integration
    with valid credentials structure.
    """
    from posthog.models.integration import GitHubIntegration, Integration

    # Create a mock integration object
    mock_integration = MagicMock(spec=Integration)
    mock_integration.id = 1
    mock_integration.team_id = team.id
    mock_integration.kind = "github"
    mock_integration.config = {
        "installation_id": "12345",
        "account": {"name": "test-org", "type": "Organization"},
    }
    mock_integration.sensitive_config = {
        "access_token": "ghs_fake_token_for_testing",
    }

    # Patch the Integration.objects.filter to return our mock
    original_filter = Integration.objects.filter

    def patched_filter(*args, **kwargs):
        if kwargs.get("kind") == "github" and kwargs.get("team_id") == team.id:
            mock_qs = MagicMock()
            mock_qs.first.return_value = mock_integration
            return mock_qs
        return original_filter(*args, **kwargs)

    mocker.patch.object(Integration.objects, "filter", side_effect=patched_filter)

    # Also patch GitHubIntegration methods we need
    def mock_access_token_expired(self):
        return False

    mocker.patch.object(GitHubIntegration, "access_token_expired", mock_access_token_expired)

    return mock_integration


@pytest.fixture
def vr_project_with_github(team, mock_github_integration):
    """Create a visual review repo configured for GitHub."""
    return Repo.objects.create(
        team_id=team.id,
        repo_external_id=12345,
        repo_full_name="test-org/test-repo",
        baseline_file_paths={"storybook": ".snapshots.yml"},
    )


@pytest.fixture
def run_with_changes(vr_project_with_github, local_git_repo):
    """
    Create a run with changed snapshots that can be approved.

    Sets up:
    - A run with pr_number and commit_sha matching the local repo
    - Snapshots marked as 'changed' with artifacts
    """
    repo = vr_project_with_github
    commit_sha = _get_head_sha(local_git_repo)

    run = Run.objects.create(
        repo=repo,
        team_id=repo.team_id,
        status=RunStatus.COMPLETED,
        run_type="storybook",
        commit_sha=commit_sha,
        branch="feature-branch",
        pr_number=42,
        total_snapshots=2,
        changed_count=2,
    )

    # Create artifacts for the snapshots
    artifact1 = Artifact.objects.create(
        repo=repo,
        team_id=repo.team_id,
        content_hash="abc123hash",
        storage_path="visual_review/test/abc123hash.png",
        width=800,
        height=600,
    )
    artifact2 = Artifact.objects.create(
        repo=repo,
        team_id=repo.team_id,
        content_hash="def456hash",
        storage_path="visual_review/test/def456hash.png",
        width=1200,
        height=800,
    )

    # Create snapshots
    RunSnapshot.objects.create(
        run=run,
        team_id=repo.team_id,
        identifier="button--primary",
        current_hash="abc123hash",
        baseline_hash="old111hash",
        current_artifact=artifact1,
        result=SnapshotResult.CHANGED,
    )
    RunSnapshot.objects.create(
        run=run,
        team_id=repo.team_id,
        identifier="card--default",
        current_hash="def456hash",
        baseline_hash="old222hash",
        current_artifact=artifact2,
        result=SnapshotResult.CHANGED,
    )

    return run


# --- Tests ---


@pytest.mark.django_db(databases=PRODUCT_DATABASES)
class TestGitHubCommitOnApprove:
    """Test that approve commits baseline updates to GitHub."""

    def test_approve_commits_to_local_repo(
        self,
        local_git_repo,
        mock_github_api,
        mock_github_integration,
        vr_project_with_github,
        run_with_changes,
        user,
    ):
        """
        Full E2E test: approve should commit updated snapshots.yml to the repo.
        """
        run = run_with_changes

        result = approvals.finalize_run(
            run_id=run.id,
            user_id=user.id,
            approve_all=True,
            commit_to_github=True,
        )

        # Verify run is approved in DB
        assert result.approved is True

        # Verify the local git repo was updated
        snapshots_file = local_git_repo / ".snapshots.yml"
        content = snapshots_file.read_text()
        parsed = yaml.safe_load(content)

        assert parsed["version"] == 1
        # Snapshots are stored as {hash: signed_string} dicts
        assert "hash" in parsed["snapshots"]["button--primary"]
        assert "abc123hash" in parsed["snapshots"]["button--primary"]["hash"]
        assert "hash" in parsed["snapshots"]["card--default"]
        assert "def456hash" in parsed["snapshots"]["card--default"]["hash"]

        # Verify a commit was made
        log_result = subprocess.run(
            ["git", "log", "--oneline", "-1"],
            cwd=local_git_repo,
            capture_output=True,
            text=True,
        )
        assert "chore(visual): update storybook baselines" in log_result.stdout

    def test_finalize_commits_all_db_approved_not_just_last_reviewed(
        self,
        local_git_repo,
        mock_github_api,
        mock_github_integration,
        vr_project_with_github,
        run_with_changes,
        user,
    ):
        """Regression: the committed baseline comes from DB state, so snapshots reviewed in
        earlier (DB-only) calls are still committed — not just the finalizing call's set."""
        run = run_with_changes

        # Mark each snapshot reviewed in a separate DB-only call, then finalize with no list.
        approvals.approve_snapshots(
            run_id=run.id,
            user_id=user.id,
            approved_snapshots=[{"identifier": "button--primary", "new_hash": "abc123hash"}],
        )
        approvals.approve_snapshots(
            run_id=run.id,
            user_id=user.id,
            approved_snapshots=[{"identifier": "card--default", "new_hash": "def456hash"}],
        )
        approvals.finalize_run(run_id=run.id, user_id=user.id, commit_to_github=True)

        parsed = yaml.safe_load((local_git_repo / ".snapshots.yml").read_text())
        # Both land — the old explicit-list path would have dropped the one not in the final call.
        assert "abc123hash" in parsed["snapshots"]["button--primary"]["hash"]
        assert "def456hash" in parsed["snapshots"]["card--default"]["hash"]

    def test_finalize_does_not_commit_tolerated_snapshot(
        self,
        local_git_repo,
        mock_github_api,
        mock_github_integration,
        vr_project_with_github,
        run_with_changes,
        user,
    ):
        """Regression: a tolerated snapshot keeps its baseline — finalize must not bake its
        current hash into snapshots.yml (and approve_all must not flip it to approved)."""
        run = run_with_changes
        card = run.snapshots.get(identifier="card--default")
        toleration.mark_snapshot_as_tolerated(run.id, card.id, user.id, run.team_id)

        approvals.finalize_run(run_id=run.id, user_id=user.id, approve_all=True, commit_to_github=True)

        parsed = yaml.safe_load((local_git_repo / ".snapshots.yml").read_text())
        assert "abc123hash" in parsed["snapshots"]["button--primary"]["hash"]
        assert "card--default" not in parsed["snapshots"]  # tolerated → baseline untouched
        card.refresh_from_db()
        assert card.review_state == "tolerated"

    def test_finalize_commits_to_prune_removed_only_run(
        self,
        local_git_repo,
        mock_github_api,
        mock_github_integration,
        vr_project_with_github,
        user,
    ):
        """Regression: a run whose only actionable change is a REMOVED snapshot must still commit —
        the removed entry has to be pruned from snapshots.yml, or the gate greens over a stale baseline."""
        repo = vr_project_with_github

        # Seed a baseline containing the entry finalize must prune.
        snapshots_file = local_git_repo / ".snapshots.yml"
        snapshots_file.write_text(
            yaml.dump({"version": 1, "snapshots": {"gone--snap": {"hash": "v1.kfake.gonehash.fakemac" + "1" * 40}}})
        )
        subprocess.run(["git", "add", "."], cwd=local_git_repo, check=True)
        subprocess.run(["git", "commit", "-m", "seed baseline"], cwd=local_git_repo, check=True)

        run = Run.objects.create(
            repo=repo,
            team_id=repo.team_id,
            status=RunStatus.COMPLETED,
            run_type="storybook",
            commit_sha=_get_head_sha(local_git_repo),
            branch="feature-branch",
            pr_number=42,
            total_snapshots=1,
            removed_count=1,
        )
        RunSnapshot.objects.create(
            run=run,
            team_id=repo.team_id,
            identifier="gone--snap",
            result=SnapshotResult.REMOVED,
        )

        result = approvals.finalize_run(run_id=run.id, user_id=user.id, commit_to_github=True)

        assert result.approved is True
        parsed = yaml.safe_load(snapshots_file.read_text())
        assert "gone--snap" not in parsed["snapshots"]  # pruned by the finalize commit

    def test_approve_merges_with_existing_baselines(
        self,
        local_git_repo,
        mock_github_api,
        mock_github_integration,
        vr_project_with_github,
        run_with_changes,
        user,
    ):
        """Approve should merge with existing baselines, not replace them."""
        # First, add some existing baselines to the repo (in signed format)
        snapshots_file = local_git_repo / ".snapshots.yml"
        existing = {
            "version": 1,
            "snapshots": {
                "existing--snapshot": {"hash": "v1.kfake.existinghash.fakemac12345678901234567890123456789012"},
                "button--primary": {"hash": "v1.kfake.oldhash00000.fakemac12345678901234567890123456789012"},
            },
        }
        snapshots_file.write_text(yaml.dump(existing))
        subprocess.run(["git", "add", "."], cwd=local_git_repo, check=True)
        subprocess.run(["git", "commit", "-m", "add existing"], cwd=local_git_repo, check=True)

        # Update run's commit_sha to match
        run = run_with_changes
        run.commit_sha = _get_head_sha(local_git_repo)
        run.save()

        approvals.finalize_run(
            run_id=run.id,
            user_id=user.id,
            approve_all=True,
            commit_to_github=True,
        )

        # Verify merged result
        content = snapshots_file.read_text()
        parsed = yaml.safe_load(content)

        # existing--snapshot should be preserved as-is from the YAML
        assert parsed["snapshots"]["existing--snapshot"]["hash"].startswith("v1.kfake.")  # Preserved
        assert "abc123hash" in parsed["snapshots"]["button--primary"]["hash"]  # Updated with signed hash

    def test_approve_fails_on_sha_mismatch(
        self,
        local_git_repo,
        mock_github_api,
        mock_github_integration,
        vr_project_with_github,
        run_with_changes,
        user,
    ):
        """Approve should fail if PR has new commits since the run."""
        run = run_with_changes

        # Make a new commit to the repo (simulating someone pushing to the PR)
        dummy_file = local_git_repo / "new_file.txt"
        dummy_file.write_text("new content")
        subprocess.run(["git", "add", "."], cwd=local_git_repo, check=True)
        subprocess.run(["git", "commit", "-m", "new commit"], cwd=local_git_repo, check=True)

        # Now the run's commit_sha doesn't match HEAD
        with pytest.raises(errors.PRSHAMismatchError) as exc_info:
            approvals.finalize_run(
                run_id=run.id,
                user_id=user.id,
                approve_all=True,
                commit_to_github=True,
            )

        assert "newer commits" in str(exc_info.value)

    @pytest.mark.parametrize(
        "create_user_integration,expected_trailer",
        [
            (True, "Co-authored-by: octocat <583231+octocat@users.noreply.github.com>"),
            (False, None),
        ],
    )
    def test_approve_coauthor_trailer(
        self,
        local_git_repo,
        mock_github_api,
        mock_github_integration,
        vr_project_with_github,
        run_with_changes,
        user,
        create_user_integration,
        expected_trailer,
    ):
        """Bot commit gets a Co-authored-by trailer iff the approver has a matching personal integration."""
        from posthog.models.user_integration import UserIntegration

        # Pin the team integration's installation_id so UserIntegration lookup can match
        mock_github_integration.integration_id = "12345"

        if create_user_integration:
            UserIntegration.objects.create(
                user=user,
                kind=UserIntegration.IntegrationKind.GITHUB,
                integration_id="12345",
                config={"github_user": {"login": "octocat", "id": 583231}},
                sensitive_config={"user_access_token": "ghu_fake"},
            )

        approvals.finalize_run(
            run_id=run_with_changes.id,
            user_id=user.id,
            approve_all=True,
            commit_to_github=True,
        )

        log = subprocess.run(
            ["git", "log", "--format=%B", "-1"],
            cwd=local_git_repo,
            capture_output=True,
            text=True,
            check=True,
        ).stdout
        if expected_trailer:
            assert expected_trailer in log
        else:
            assert "Co-authored-by:" not in log

    def test_approve_without_github_skips_commit(
        self,
        vr_project_with_github,
        run_with_changes,
        user,
    ):
        """Approve with commit_to_github=False should only update DB."""
        run = run_with_changes

        # This should succeed without GitHub mocks
        result = approvals.finalize_run(
            run_id=run.id,
            user_id=user.id,
            approve_all=True,
            commit_to_github=False,
        )

        assert result.approved is True

    def test_approve_without_pr_number_skips_commit(
        self,
        mock_github_integration,
        vr_project_with_github,
        user,
    ):
        """Approve for a run without pr_number should only update DB."""
        repo = vr_project_with_github

        # Create run without pr_number
        run = Run.objects.create(
            repo=repo,
            team_id=repo.team_id,
            status=RunStatus.COMPLETED,
            run_type="storybook",
            commit_sha="abc123",
            branch="main",
            pr_number=None,  # No PR
            total_snapshots=1,
            changed_count=1,
        )

        artifact = Artifact.objects.create(
            repo=repo,
            team_id=repo.team_id,
            content_hash="newhash",
            storage_path="path/to/artifact.png",
        )

        RunSnapshot.objects.create(
            run=run,
            team_id=repo.team_id,
            identifier="test-snapshot",
            current_hash="newhash",
            current_artifact=artifact,
            result=SnapshotResult.CHANGED,
        )

        # Should succeed without GitHub interaction
        result = approvals.finalize_run(
            run_id=run.id,
            user_id=user.id,
            approve_all=True,
            commit_to_github=True,  # True but no pr_number
        )

        assert result.approved is True

    def test_approve_preserves_result_and_sets_approval_fields(
        self,
        vr_project_with_github,
        run_with_changes,
        user,
    ):
        """
        Approve should NOT mutate snapshot.result.

        Instead it sets approval fields to record the approval while
        preserving the diff history.
        """
        run = run_with_changes
        snapshots_before = list(run.snapshots.all())

        # Verify snapshots are CHANGED before approval
        for s in snapshots_before:
            assert s.result == SnapshotResult.CHANGED
            assert s.reviewed_at is None
            assert s.reviewed_by_id is None
            assert s.approved_hash == ""

        approvals.finalize_run(
            run_id=run.id,
            user_id=user.id,
            approve_all=True,
            commit_to_github=False,
        )

        # Refresh snapshots from DB
        for s in run.snapshots.all():
            # Result should NOT have changed - still CHANGED
            assert s.result == SnapshotResult.CHANGED, f"Expected result to stay CHANGED but got {s.result}"

            # Approval fields should be populated
            assert s.reviewed_at is not None
            assert s.reviewed_by_id == user.id
            assert s.approved_hash in ["abc123hash", "def456hash"]


@pytest.mark.django_db(databases=PRODUCT_DATABASES)
class TestGitHubIntegrationErrors:
    """Test error handling for GitHub integration."""

    def test_missing_github_integration(self, team, user):
        """Should raise error if team has no GitHub integration."""
        repo = Repo.objects.create(
            team_id=team.id,
            repo_external_id=99999,
            repo_full_name="org/repo",
            baseline_file_paths={"storybook": ".snapshots.yml"},
        )

        run = Run.objects.create(
            repo=repo,
            team_id=repo.team_id,
            status=RunStatus.COMPLETED,
            run_type="storybook",
            commit_sha="abc123",
            branch="feature",
            pr_number=1,
            total_snapshots=1,
        )

        artifact = Artifact.objects.create(
            repo=repo,
            team_id=repo.team_id,
            content_hash="hash123",
            storage_path="path.png",
        )

        RunSnapshot.objects.create(
            run=run,
            team_id=repo.team_id,
            identifier="snap",
            current_hash="hash123",
            current_artifact=artifact,
            result=SnapshotResult.CHANGED,
        )

        with pytest.raises(errors.GitHubIntegrationNotFoundError):
            approvals.finalize_run(
                run_id=run.id,
                user_id=user.id,
                approve_all=True,
                commit_to_github=True,
            )
