-- DropTable
DROP TABLE events;
