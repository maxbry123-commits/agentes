-- M2 of the V4 self-hosted historic backfill chain.
-- Rewrites the live `observations` table into `observations_pid_tid_sorting`,
-- a scratch table sorted by (project_id, trace_id, span_id) so that M3's
-- chunked LEFT ANY JOIN against `traces` is index-aligned.
--
-- M2 lazily creates the scratch table inside validate() and issues
-- `SYSTEM STOP MERGES` against it after the rewrite. The scratch table is
-- dropped by M5 once the operator confirms the v4 path is healthy.
--
-- Gated by `LANGFUSE_BACKGROUND_MIGRATION_V4_ENABLE_HISTORIC_BACKFILL`.
INSERT INTO background_migrations (id, name, script, args)
VALUES (
  '9c2d5a4f-7b8e-4f6a-a91c-3e5d7f8a2b1c',
  '20260701_v4_step_2_rewrite_observations_to_pid_tid_sorting',
  'rewriteObservationsToPidTidSorting',
  '{"envGate": "LANGFUSE_BACKGROUND_MIGRATION_V4_ENABLE_HISTORIC_BACKFILL"}'::jsonb
);
