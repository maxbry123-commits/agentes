import {
  type ColumnDefinition,
  type SingleValueOption,
  type MultiValueOption,
} from "../tableDefinitions/types";
import { formatColumnOptions } from "./typeHelpers";

export const sessionsViewCols: ColumnDefinition[] = [
  { name: "⭐️", id: "bookmarked", type: "boolean", internal: "s.bookmarked" },
  {
    name: "ID",
    id: "id",
    type: "string",
    internal: 's."id"',
  },
  {
    name: "User IDs",
    id: "userIds",
    type: "arrayOptions",
    internal: 't."userIds"',
    options: [], // to be filled in at runtime
    nullable: true,
  },
  {
    name: "Environment",
    id: "environment",
    type: "stringOptions",
    internal: 't."environment"',
    options: [], // to be filled in at runtime
    nullable: true,
  },
  {
    name: "Session Duration (s)",
    id: "sessionDuration",
    type: "number",
    internal: 'o."sessionDuration"',
  },
  {
    name: "Created At",
    id: "createdAt",
    type: "datetime",
    internal: 's."created_at"',
  },
  {
    name: "Traces Count",
    id: "countTraces",
    type: "number",
    internal: 't."countTraces"',
  },
  {
    name: "Input Cost ($)",
    id: "inputCost",
    type: "number",
    internal: 'o."inputCost"',
  },
  {
    name: "Output Cost ($)",
    id: "outputCost",
    type: "number",
    internal: 'o."outputCost"',
  },
  {
    name: "Total Cost ($)",
    id: "totalCost",
    type: "number",
    internal: 'o."totalCost"',
  },
  {
    name: "Input Tokens",
    id: "inputTokens",
    type: "number",
    internal: 'o."promptTokens"',
  },
  {
    name: "Output Tokens",
    id: "outputTokens",
    type: "number",
    internal: 'o."completionTokens"',
  },
  {
    name: "Total Tokens",
    id: "totalTokens",
    type: "number",
    internal: 'o."totalTokens"',
  },
  {
    name: "Usage",
    id: "usage",
    type: "number",
    internal: 'o."totalTokens"',
  },
  {
    name: "Trace Tags",
    id: "tags",
    type: "arrayOptions",
    internal: 't."tags"',
    options: [], // to be filled in at runtime
  },
  {
    name: "Scores (numeric)",
    id: "scores_avg",
    type: "numberObject",
    internal: "scores",
  },
  {
    name: "Scores (categorical)",
    id: "score_categories",
    type: "categoryOptions",
    internal: "score_categories",
    options: [], // to be added at runtime
    nullable: true,
  },
  {
    name: "Scores (boolean)",
    id: "score_booleans",
    type: "booleanObject",
    internal: "score_booleans",
    nullable: true,
  },
  {
    name: "Comment Count",
    id: "commentCount",
    type: "number",
    internal: "", // handled by comment filter helpers
  },
  {
    name: "Comment Content",
    id: "commentContent",
    type: "string",
    internal: "", // handled by comment filter helpers
  },
];

export const sessionsEventsViewCols: ColumnDefinition[] =
  sessionsViewCols.concat({
    name: "Metadata",
    id: "metadata",
    type: "stringObject",
    internal: 's."metadata"',
  });

export type SessionOptions = {
  userIds: Array<SingleValueOption>;
  environment: Array<SingleValueOption>;
  tags: Array<SingleValueOption>;
  scores_avg?: Array<string>;
  score_categories?: Array<MultiValueOption>;
  score_booleans?: Array<string>;
};

export function sessionsTableColsWithOptions(
  options?: SessionOptions,
): ColumnDefinition[] {
  return sessionsViewCols.map((col) => {
    if (col.id === "userIds") {
      return formatColumnOptions(col, options?.userIds ?? []);
    }
    if (col.id === "environment") {
      return formatColumnOptions(col, options?.environment ?? []);
    }
    if (col.id === "tags") {
      return formatColumnOptions(col, options?.tags ?? []);
    }
    if (col.id === "scores_avg") {
      return formatColumnOptions(col, options?.scores_avg ?? []);
    }
    if (col.id === "score_categories") {
      return formatColumnOptions(col, options?.score_categories ?? []);
    }
    if (col.id === "score_booleans") {
      return formatColumnOptions(col, options?.score_booleans ?? []);
    }
    return col;
  });
}
