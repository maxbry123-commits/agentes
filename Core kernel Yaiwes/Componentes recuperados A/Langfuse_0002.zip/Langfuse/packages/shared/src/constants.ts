// disable lint as this is exported and used in packages
export enum ModelUsageUnit {
  Characters = "CHARACTERS",
  Tokens = "TOKENS",
  Seconds = "SECONDS",
  Milliseconds = "MILLISECONDS",
  Images = "IMAGES",
  Requests = "REQUESTS",
}
