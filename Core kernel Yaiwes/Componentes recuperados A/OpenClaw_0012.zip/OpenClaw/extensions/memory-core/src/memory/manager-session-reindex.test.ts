// Memory Core tests cover manager.session reindex plugin behavior.
import { describe, expect, it } from "vitest";
import { shouldSyncSessionsForReindex } from "./manager-session-reindex.js";

describe("memory manager session reindex gating", () => {
  it("keeps session syncing enabled for full reindexes triggered from session-start/watch", () => {
    expect(
      shouldSyncSessionsForReindex({
        hasSessionSource: true,
        sessionsDirty: false,
        sync: { reason: "session-start" },
        needsFullReindex: true,
      }),
    ).toBe(true);
    expect(
      shouldSyncSessionsForReindex({
        hasSessionSource: true,
        sessionsDirty: false,
        sync: { reason: "watch" },
        needsFullReindex: true,
      }),
    ).toBe(true);
    expect(
      shouldSyncSessionsForReindex({
        hasSessionSource: true,
        sessionsDirty: false,
        sync: { reason: "session-start" },
        needsFullReindex: false,
      }),
    ).toBe(false);
    expect(
      shouldSyncSessionsForReindex({
        hasSessionSource: true,
        sessionsDirty: false,
        sync: { reason: "watch" },
        needsFullReindex: false,
      }),
    ).toBe(false);
  });

  it("keeps session syncing enabled for failed full-reindex retries without dirty files", () => {
    expect(
      shouldSyncSessionsForReindex({
        hasSessionSource: true,
        sessionsDirty: true,
        sessionsFullRetryDirty: true,
        sync: { reason: "interval" },
        needsFullReindex: false,
      }),
    ).toBe(true);
    expect(
      shouldSyncSessionsForReindex({
        hasSessionSource: true,
        sessionsDirty: true,
        sync: { reason: "session-startup-catchup" },
        needsFullReindex: false,
      }),
    ).toBe(true);
  });
});
