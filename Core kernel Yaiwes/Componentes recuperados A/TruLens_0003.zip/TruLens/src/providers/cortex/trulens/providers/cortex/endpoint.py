import inspect
import json
import logging
import os
import pprint
from typing import Any, Callable, Dict, Optional

from snowflake.cortex._sse_client import Event
from snowflake.cortex._sse_client import SSEClient
from trulens.core.feedback import endpoint as core_endpoint
from trulens.otel.semconv.trace import SpanAttributes

logger = logging.getLogger(__name__)

pp = pprint.PrettyPrinter()


class CortexCostComputer:
    @staticmethod
    def handle_response(response: Any) -> Dict[str, Any]:
        model = None
        usage = {}

        for curr in response:
            data = json.loads(curr.data)

            choice = data["choices"][0]
            if "finish_reason" in choice and choice["finish_reason"] == "stop":
                model = data["model"]
                usage = data["usage"]
                break
            elif "usage" in data and data["usage"]:
                model = data["model"]
                usage = data["usage"]
                break

        if model is None or not usage:
            logger.warning(
                f"No model usage found in response. response: {response} usage: {usage}"
            )

        prompt_tokens = usage.get("prompt_tokens", 0)
        completion_tokens = usage.get("completion_tokens", 0)
        total_tokens = usage.get("total_tokens", 0)

        endpoint = CortexEndpoint()
        callback = CortexCallback(endpoint=endpoint)
        return {
            SpanAttributes.COST.MODEL: model,
            SpanAttributes.COST.CURRENCY: "Snowflake credits",
            SpanAttributes.COST.COST: callback._compute_credits_consumed(
                model,
                total_tokens,
                n_prompt_tokens=prompt_tokens,
                n_completion_tokens=completion_tokens,
            ),
            SpanAttributes.COST.NUM_TOKENS: total_tokens,
            SpanAttributes.COST.NUM_PROMPT_TOKENS: prompt_tokens,
            SpanAttributes.COST.NUM_COMPLETION_TOKENS: completion_tokens,
        }


class CortexCallback(core_endpoint.EndpointCallback):
    _model_costs: Optional[dict] = None
    # TODO (Daniel): cost tracking for Cortex finetuned models is not yet implemented.

    def _load_model_costs(self) -> dict:
        if self._model_costs is None:
            # the credit consumption table needs to be kept up-to-date with
            # the latest cost information https://www.snowflake.com/legal-files/CreditConsumptionTable.pdf#page=9.
            # We should refer to the latest model availability of REST api https://docs.snowflake.com/en/user-guide/snowflake-cortex/cortex-llm-rest-api#model-availability
            with open(
                os.path.join(
                    os.path.dirname(os.path.realpath(__file__)),
                    "config/cortex_model_costs.json",
                ),
                "r",
            ) as file:
                self._model_costs = json.load(file)
        return self._model_costs

    def _compute_credits_consumed(
        self,
        cortex_model_name: Optional[str],
        n_tokens: int,
        n_prompt_tokens: int = 0,
        n_completion_tokens: int = 0,
    ) -> float:
        try:
            model_costs = self._load_model_costs()

            if not cortex_model_name or cortex_model_name not in model_costs:
                raise ValueError(
                    f"Model {cortex_model_name} not valid or not supported yet for cost estimation."
                )

            cost_entry = model_costs[cortex_model_name]

            if isinstance(cost_entry, dict):
                input_rate = cost_entry.get("input", 0)
                output_rate = cost_entry.get("output", 0)
                return (
                    n_prompt_tokens / 1e6 * input_rate
                    + n_completion_tokens / 1e6 * output_rate
                )
            else:
                return cost_entry * n_tokens / 1e6
        except Exception as e:
            logger.error(
                f"Error occurred while computing credits consumed for model {cortex_model_name}: {e}"
            )
            return 0.0

    def handle_generation(self, response: dict) -> None:
        """Get the usage information from Cortex LLM function response's usage field."""
        usage = response["usage"]

        # Increment number of requests.
        super().handle_generation(response)

        # Assume a response that had usage field was successful. Note at the time of writing 06/12/2024, the usage
        # information from Cortex LLM functions is only available when called via snow SQL. It's not fully supported in
        # Python API such as `from snowflake.cortex import Summarize, Complete, ExtractAnswer, Sentiment, Translate` yet.

        self.cost.n_successful_requests += 1

        for cost_field, cortex_field in [
            ("n_tokens", "total_tokens"),
            ("n_cortex_guardrails_tokens", "guardrails_tokens"),
            ("n_prompt_tokens", "prompt_tokens"),
            ("n_completion_tokens", "completion_tokens"),
        ]:
            setattr(
                self.cost,
                cost_field,
                getattr(self.cost, cost_field, 0) + usage.get(cortex_field, 0),
            )

        # compute credits consumed in Snowflake account based on tokens processed
        setattr(
            self.cost,
            "cost",
            getattr(self.cost, "cost", 0)
            + self._compute_credits_consumed(
                response["model"],
                usage.get("total_tokens", 0),
                n_prompt_tokens=usage.get("prompt_tokens", 0),
                n_completion_tokens=usage.get("completion_tokens", 0),
            ),
        )

        setattr(self.cost, "cost_currency", "Snowflake credits")


class CortexEndpoint(core_endpoint.Endpoint):
    """Snowflake Cortex endpoint."""

    def __init__(self, *args, **kwargs):
        kwargs["callback_class"] = CortexCallback

        super().__init__(*args, **kwargs)

        # we instrument the SSEClient class from snowflake.cortex module to get the usage information from the HTTP response when calling the REST Complete endpoint
        self._instrument_class(SSEClient, "events")

    def handle_wrapped_call(
        self,
        func: Callable,
        bindings: inspect.BoundArguments,
        response: Any,
        callback: Optional[core_endpoint.EndpointCallback],
    ) -> Any:
        response_dict = None, None

        try:
            if isinstance(response, Event):
                response_dict = json.loads(
                    response.data
                )  # response is a server-sent event (SSE). see _sse_client.py from snowflake.cortex module for reference

        except Exception as e:
            logger.error(f"Error occurred while parsing response: {e}")
            raise e

        if isinstance(response_dict, dict) and "usage" in response_dict:
            if "choices" in response_dict:
                choice = response_dict["choices"][0]
                if (
                    "finish_reason" in choice
                    and choice["finish_reason"] == "stop"
                ):
                    self.global_callback.handle_generation(
                        response=response_dict
                    )

                    if callback is not None:
                        callback.handle_generation(response=response_dict)
        else:
            logger.warning(
                "Unrecognized Cortex response format. It did not have usage information:\n%s",
                pp.pformat(response_dict),
            )

        return response


def register_otel_cost_tracking() -> None:
    """Register OTel-tracing cost instrumentation for the Cortex provider.

    Replaces the previous in-core wiring in
    ``trulens.experimental.otel_tracing.core.session._track_costs`` so the
    core package no longer imports from ``snowflake.cortex`` directly.
    """
    from trulens.core.otel.instrument import instrument_cost_computer

    instrument_cost_computer(
        SSEClient,
        "events",
        attributes=lambda ret, exception, *args, **kwargs: (
            CortexCostComputer.handle_response(ret)
        ),
    )
