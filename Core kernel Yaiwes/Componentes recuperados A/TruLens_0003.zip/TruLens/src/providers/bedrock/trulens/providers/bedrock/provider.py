import json
import logging
from typing import Any, ClassVar, Dict, Optional, Sequence, Tuple, Type, Union

import pydantic
from trulens.feedback import llm_provider
from trulens.providers.bedrock import endpoint as bedrock_endpoint

logger = logging.getLogger(__name__)


class Bedrock(llm_provider.LLMProvider):
    """A set of AWS Feedback Functions.

    Args:
        model_id: The specific model id. Defaults to
            "amazon.nova-lite-v1:0".

        *args: args passed to BedrockEndpoint and subsequently to boto3 client
            constructor.

        **kwargs: kwargs passed to BedrockEndpoint and subsequently to boto3
            client constructor.
    """

    DEFAULT_MODEL_ID: ClassVar[str] = "amazon.nova-lite-v1:0"

    # LLMProvider requirement which we do not use:
    model_engine: str = "Bedrock"

    model_id: str
    endpoint: bedrock_endpoint.BedrockEndpoint

    def __init__(
        self,
        *args: Any,
        model_id: Optional[str] = None,
        **kwargs: Any,
    ):
        if model_id is None:
            model_id = self.DEFAULT_MODEL_ID

        # Pass kwargs to Endpoint. Self has additional ones.
        self_kwargs = dict()
        self_kwargs.update(**kwargs)

        self_kwargs["model_id"] = model_id

        self_kwargs["endpoint"] = bedrock_endpoint.BedrockEndpoint(
            *args, **kwargs
        )

        super().__init__(
            **self_kwargs
        )  # need to include pydantic.BaseModel.__init__

    # LLMProvider requirement
    def _create_chat_completion(
        self,
        prompt: Optional[str] = None,
        messages: Optional[Sequence[Dict]] = None,
        response_format: Optional[Type[pydantic.BaseModel]] = None,
        **kwargs,
    ) -> str:
        assert self.endpoint is not None

        if messages:
            messages_str = " ".join([
                f"{message['role']}: {message['content']}"
                for message in messages
            ])
        elif prompt:
            messages_str = prompt
        else:
            raise ValueError("Either 'messages' or 'prompt' must be supplied.")

        # Cross-region inference profile ids are the provider id prefixed with a
        # region (e.g. "us.amazon.nova-lite-v1:0"). Strip the prefix so the
        # family routing below matches the same way it does for on-demand ids.
        base_model_id = self.model_id
        for region_prefix in ("us.", "eu.", "apac.", "us-gov."):
            if base_model_id.startswith(region_prefix):
                base_model_id = base_model_id[len(region_prefix) :]
                break

        if "nova" in base_model_id:
            # Amazon Nova uses the Messages API schema, not the legacy Titan
            # text-generation schema used by other amazon.* models.
            # https://docs.aws.amazon.com/nova/latest/userguide/using-invoke-api.html
            body = json.dumps({
                "schemaVersion": "messages-v1",
                "messages": [
                    {"role": "user", "content": [{"text": messages_str}]}
                ],
                "inferenceConfig": {
                    "maxTokens": 4095,
                    "temperature": 0,
                    "topP": 1,
                },
            })
        elif base_model_id.startswith("amazon"):
            body = json.dumps({
                "inputText": messages_str,
                "textGenerationConfig": {
                    "maxTokenCount": 4095,
                    "stopSequences": [],
                    "temperature": 0,
                    "topP": 1,
                },
            })
        elif base_model_id.startswith("anthropic"):
            if not messages:
                raise ValueError(
                    "`messages` argument must be supplied for Anthropic Bedrock models."
                )
            if messages[0]["role"] == "system":
                system_prompt = messages[0]["content"]
            _messages = messages[1:] if len(messages) > 1 else []

            body = json.dumps({
                "system": system_prompt,
                "messages": _messages,
                "temperature": 0,
                "top_p": 1,
                "max_tokens": 4095,
                "anthropic_version": "bedrock-2023-05-31",
            })
        elif base_model_id.startswith("cohere"):
            body = json.dumps({
                "prompt": messages_str,
                "temperature": 0,
                "p": 1,
                "max_tokens": 4095,
            })
        elif base_model_id.startswith("ai21"):
            body = json.dumps({
                "prompt": messages_str,
                "temperature": 0,
                "topP": 1,
                "maxTokens": 8191,
            })

        elif base_model_id.startswith("mistral"):
            body = json.dumps({
                "prompt": messages_str,
                "temperature": 0,
                "top_p": 1,
                "max_tokens": 4095,
            })

        elif base_model_id.startswith("meta"):
            body = json.dumps({
                "prompt": messages_str,
                "temperature": 0,
                "top_p": 1,
                "max_gen_len": 2047,
            })
        else:
            raise NotImplementedError(
                f"The Bedrock model selected, `{self.model_id}`, is not yet implemented as a feedback provider"
            )

        # TODO: make textGenerationConfig available for user

        modelId = self.model_id

        accept = "application/json"
        content_type = "application/json"

        response = self.endpoint.client.invoke_model(
            body=body, modelId=modelId, accept=accept, contentType=content_type
        )

        if "nova" in base_model_id:
            # Nova returns the Messages API response shape.
            # https://docs.aws.amazon.com/nova/latest/userguide/using-invoke-api.html
            response_body = json.loads(response.get("body").read())["output"][
                "message"
            ]["content"][0]["text"]

        elif base_model_id.startswith("amazon"):
            response_body = json.loads(response.get("body").read()).get(
                "results"
            )[0]["outputText"]

        elif base_model_id.startswith("anthropic"):
            response_body = json.loads(response.get("body").read()).get(
                "content"
            )[0]["text"]

        elif base_model_id.startswith("cohere"):
            response_body = json.loads(response.get("body").read()).get(
                "generations"
            )[0]["text"]

        elif base_model_id.startswith("mistral"):
            response_body = json.loads(response.get("body").read()).get(
                "output"
            )[0]["text"]
        elif base_model_id.startswith("meta"):
            response_body = json.loads(response.get("body").read()).get(
                "generation"
            )
        elif base_model_id.startswith("ai21"):
            response_body = (
                json
                .loads(response.get("body").read())
                .get("completions")[0]
                .get("data")
                .get("text")
            )

        return response_body

    def generate_score(
        self,
        system_prompt: str,
        user_prompt: Optional[str] = None,
        min_score_val: int = 0,
        max_score_val: int = 3,
        temperature: float = 0.0,
    ) -> float:
        """
        Base method to generate a score only, used for evaluation.

        Args:
            system_prompt: A pre-formatted system prompt.
            user_prompt: An optional user prompt.
            min_score_val: The minimum score value. Default is 0.
            max_score_val: The maximum score value. Default is 3.
            temperature: The temperature value for LLM score generation. Default is 0.0.

        Returns:
            The score on a 0-1 scale.
        """
        if temperature != 0.0:
            logger.warning(
                "The `temperature` argument is ignored for Bedrock provider."
            )
        return super().generate_score(
            system_prompt=system_prompt,
            user_prompt=user_prompt,
            min_score_val=min_score_val,
            max_score_val=max_score_val,
            temperature=temperature,
        )

    def generate_score_and_reasons(
        self,
        system_prompt: str,
        user_prompt: Optional[str] = None,
        min_score_val: int = 0,
        max_score_val: int = 3,
        temperature: float = 0.0,
    ) -> Union[float, Tuple[float, Dict]]:
        if temperature != 0.0:
            logger.warning(
                "The `temperature` argument is ignored for Bedrock provider."
            )
        return super().generate_score_and_reasons(
            system_prompt=system_prompt,
            user_prompt=user_prompt,
            min_score_val=min_score_val,
            max_score_val=max_score_val,
            temperature=temperature,
        )
