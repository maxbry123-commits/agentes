---
"create-cloudflare": patch
---

Update dependencies of "create-cloudflare"

The following dependency versions have been updated:

| Dependency      | From   | To     |
| --------------- | ------ | ------ |
| @angular/create | 22.1.5 | 22.1.6 |
