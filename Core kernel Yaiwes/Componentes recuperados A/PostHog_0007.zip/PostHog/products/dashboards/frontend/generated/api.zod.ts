/**
 * Auto-generated Zod validation schemas from the Django backend OpenAPI schema.
 * To modify these schemas, update the Django serializers or views, then run:
 *   hogli build:openapi
 * Questions or issues? #team-devex on Slack
 *
 * PostHog API - generated
 * OpenAPI spec version: 1.0.0
 */
import * as zod from 'zod'

export const dashboardTemplatesCreateBodyTemplateNameMax = 400

export const dashboardTemplatesCreateBodyDashboardDescriptionMax = 400

export const dashboardTemplatesCreateBodyTagsItemMax = 255

export const dashboardTemplatesCreateBodyImageUrlMax = 8201

export const dashboardTemplatesCreateBodyAvailabilityContextsItemMax = 255

export const DashboardTemplatesCreateBody = /* @__PURE__ */ zod.object({
    template_name: zod.string().max(dashboardTemplatesCreateBodyTemplateNameMax).nullish(),
    dashboard_description: zod.string().max(dashboardTemplatesCreateBodyDashboardDescriptionMax).nullish(),
    dashboard_filters: zod.unknown().optional(),
    tags: zod.array(zod.string().max(dashboardTemplatesCreateBodyTagsItemMax)).nullish(),
    tiles: zod.unknown().optional(),
    variables: zod.unknown().optional(),
    deleted: zod.boolean().nullish(),
    image_url: zod.string().max(dashboardTemplatesCreateBodyImageUrlMax).nullish(),
    scope: zod
        .union([
            zod
                .enum(['team', 'organization', 'global', 'feature_flag'])
                .describe(
                    '\* `team` - Only team\n\* `organization` - Organization\n\* `global` - Global\n\* `feature_flag` - Feature Flag'
                ),
            zod.enum(['']),
            zod.null(),
        ])
        .optional(),
    availability_contexts: zod
        .array(zod.string().max(dashboardTemplatesCreateBodyAvailabilityContextsItemMax))
        .nullish(),
    is_featured: zod.boolean().optional().describe('Manually curated; used to highlight templates in the UI.'),
})

export const dashboardTemplatesUpdateBodyTemplateNameMax = 400

export const dashboardTemplatesUpdateBodyDashboardDescriptionMax = 400

export const dashboardTemplatesUpdateBodyTagsItemMax = 255

export const dashboardTemplatesUpdateBodyImageUrlMax = 8201

export const dashboardTemplatesUpdateBodyAvailabilityContextsItemMax = 255

export const DashboardTemplatesUpdateBody = /* @__PURE__ */ zod.object({
    template_name: zod.string().max(dashboardTemplatesUpdateBodyTemplateNameMax).nullish(),
    dashboard_description: zod.string().max(dashboardTemplatesUpdateBodyDashboardDescriptionMax).nullish(),
    dashboard_filters: zod.unknown().optional(),
    tags: zod.array(zod.string().max(dashboardTemplatesUpdateBodyTagsItemMax)).nullish(),
    tiles: zod.unknown().optional(),
    variables: zod.unknown().optional(),
    deleted: zod.boolean().nullish(),
    image_url: zod.string().max(dashboardTemplatesUpdateBodyImageUrlMax).nullish(),
    scope: zod
        .union([
            zod
                .enum(['team', 'organization', 'global', 'feature_flag'])
                .describe(
                    '\* `team` - Only team\n\* `organization` - Organization\n\* `global` - Global\n\* `feature_flag` - Feature Flag'
                ),
            zod.enum(['']),
            zod.null(),
        ])
        .optional(),
    availability_contexts: zod
        .array(zod.string().max(dashboardTemplatesUpdateBodyAvailabilityContextsItemMax))
        .nullish(),
    is_featured: zod.boolean().optional().describe('Manually curated; used to highlight templates in the UI.'),
})

export const dashboardTemplatesPartialUpdateBodyTemplateNameMax = 400

export const dashboardTemplatesPartialUpdateBodyDashboardDescriptionMax = 400

export const dashboardTemplatesPartialUpdateBodyTagsItemMax = 255

export const dashboardTemplatesPartialUpdateBodyImageUrlMax = 8201

export const dashboardTemplatesPartialUpdateBodyAvailabilityContextsItemMax = 255

export const DashboardTemplatesPartialUpdateBody = /* @__PURE__ */ zod.object({
    template_name: zod.string().max(dashboardTemplatesPartialUpdateBodyTemplateNameMax).nullish(),
    dashboard_description: zod.string().max(dashboardTemplatesPartialUpdateBodyDashboardDescriptionMax).nullish(),
    dashboard_filters: zod.unknown().optional(),
    tags: zod.array(zod.string().max(dashboardTemplatesPartialUpdateBodyTagsItemMax)).nullish(),
    tiles: zod.unknown().optional(),
    variables: zod.unknown().optional(),
    deleted: zod.boolean().nullish(),
    image_url: zod.string().max(dashboardTemplatesPartialUpdateBodyImageUrlMax).nullish(),
    scope: zod
        .union([
            zod
                .enum(['team', 'organization', 'global', 'feature_flag'])
                .describe(
                    '\* `team` - Only team\n\* `organization` - Organization\n\* `global` - Global\n\* `feature_flag` - Feature Flag'
                ),
            zod.enum(['']),
            zod.null(),
        ])
        .optional(),
    availability_contexts: zod
        .array(zod.string().max(dashboardTemplatesPartialUpdateBodyAvailabilityContextsItemMax))
        .nullish(),
    is_featured: zod.boolean().optional().describe('Manually curated; used to highlight templates in the UI.'),
})

/**
 * Creates a new team-scoped template in the **target** project (URL) from a **team-scoped** source template in the same organization. Global and feature-flag templates return 400. Cross-organization or inaccessible sources return 404. Source and destination projects must differ (400 if equal). Conflicting `template_name` values on the destination are auto-suffixed with `(copy)`, `(copy 2)`, …
 * @summary Copy a team template to this project
 */
export const DashboardTemplatesCopyBetweenProjectsCreateBody = /* @__PURE__ */ zod.object({
    source_template_id: zod
        .uuid()
        .describe(
            'UUID of a team-scoped template in the same organization. Global and feature-flag templates cannot be copied with this endpoint.'
        ),
})

export const dashboardsCreateBodyNameMax = 400

export const dashboardsCreateBodyDeleteInsightsDefault = false

export const DashboardsCreateBody = /* @__PURE__ */ zod
    .object({
        name: zod.string().max(dashboardsCreateBodyNameMax).nullish(),
        description: zod.string().optional(),
        pinned: zod.boolean().optional(),
        last_accessed_at: zod.iso.datetime({ offset: true }).nullish(),
        deleted: zod.boolean().optional(),
        breakdown_colors: zod.unknown().optional().describe('Custom color mapping for breakdown values.'),
        data_color_theme_id: zod.number().nullish().describe('ID of the color theme used for chart visualizations.'),
        tags: zod.array(zod.unknown()).optional(),
        restriction_level: zod
            .union([zod.literal(21), zod.literal(37)])
            .optional()
            .describe(
                '\* `21` - Everyone in the project can edit\n\* `37` - Only those invited to this dashboard can edit'
            ),
        last_refresh: zod.iso.datetime({ offset: true }).nullish(),
        quick_filter_ids: zod
            .array(zod.string())
            .nullish()
            .describe('List of quick filter IDs associated with this dashboard'),
        grid_spacing: zod
            .enum(['tight', 'condensed', 'standard', 'relaxed', 'wide'])
            .describe(
                '\* `tight` - tight\n\* `condensed` - condensed\n\* `standard` - standard\n\* `relaxed` - relaxed\n\* `wide` - wide'
            )
            .optional()
            .describe(
                'Named tile density preset. Use tight, condensed, standard, relaxed, or wide.\n\n\* `tight` - tight\n\* `condensed` - condensed\n\* `standard` - standard\n\* `relaxed` - relaxed\n\* `wide` - wide'
            ),
        layout_compaction: zod
            .enum(['vertical', 'horizontal', 'stable'])
            .describe('\* `vertical` - vertical\n\* `horizontal` - horizontal\n\* `stable` - stable')
            .optional()
            .describe(
                'How tiles rearrange after a move or resize. vertical stacks tiles upward, horizontal stacks tiles to the left, and stable preserves positions while moving colliding tiles.\n\n\* `vertical` - vertical\n\* `horizontal` - horizontal\n\* `stable` - stable'
            ),
        use_template: zod
            .string()
            .optional()
            .describe('Template key to create the dashboard from a predefined template.'),
        use_dashboard: zod.number().nullish().describe('ID of an existing dashboard to duplicate.'),
        delete_insights: zod
            .boolean()
            .default(dashboardsCreateBodyDeleteInsightsDefault)
            .describe('When deleting, also delete insights that are only on this dashboard.'),
        _create_in_folder: zod.string().optional(),
    })
    .describe('Serializer mixin that handles tags for objects.')

export const DashboardsCollaboratorsCreateBody = /* @__PURE__ */ zod.object({
    level: zod
        .union([zod.literal(21), zod.literal(37)])
        .describe(
            '\* `21` - Everyone in the project can edit\n\* `37` - Only those invited to this dashboard can edit'
        ),
    user_uuid: zod.uuid(),
})

export const dashboardsUpdateBodyNameMax = 400

export const dashboardsUpdateBodyDeleteInsightsDefault = false

export const DashboardsUpdateBody = /* @__PURE__ */ zod
    .object({
        name: zod.string().max(dashboardsUpdateBodyNameMax).nullish(),
        description: zod.string().optional(),
        pinned: zod.boolean().optional(),
        last_accessed_at: zod.iso.datetime({ offset: true }).nullish(),
        deleted: zod.boolean().optional(),
        breakdown_colors: zod.unknown().optional().describe('Custom color mapping for breakdown values.'),
        data_color_theme_id: zod.number().nullish().describe('ID of the color theme used for chart visualizations.'),
        tags: zod.array(zod.unknown()).optional(),
        restriction_level: zod
            .union([zod.literal(21), zod.literal(37)])
            .optional()
            .describe(
                '\* `21` - Everyone in the project can edit\n\* `37` - Only those invited to this dashboard can edit'
            ),
        last_refresh: zod.iso.datetime({ offset: true }).nullish(),
        quick_filter_ids: zod
            .array(zod.string())
            .nullish()
            .describe('List of quick filter IDs associated with this dashboard'),
        grid_spacing: zod
            .enum(['tight', 'condensed', 'standard', 'relaxed', 'wide'])
            .describe(
                '\* `tight` - tight\n\* `condensed` - condensed\n\* `standard` - standard\n\* `relaxed` - relaxed\n\* `wide` - wide'
            )
            .optional()
            .describe(
                'Named tile density preset. Use tight, condensed, standard, relaxed, or wide.\n\n\* `tight` - tight\n\* `condensed` - condensed\n\* `standard` - standard\n\* `relaxed` - relaxed\n\* `wide` - wide'
            ),
        layout_compaction: zod
            .enum(['vertical', 'horizontal', 'stable'])
            .describe('\* `vertical` - vertical\n\* `horizontal` - horizontal\n\* `stable` - stable')
            .optional()
            .describe(
                'How tiles rearrange after a move or resize. vertical stacks tiles upward, horizontal stacks tiles to the left, and stable preserves positions while moving colliding tiles.\n\n\* `vertical` - vertical\n\* `horizontal` - horizontal\n\* `stable` - stable'
            ),
        use_template: zod
            .string()
            .optional()
            .describe('Template key to create the dashboard from a predefined template.'),
        use_dashboard: zod.number().nullish().describe('ID of an existing dashboard to duplicate.'),
        delete_insights: zod
            .boolean()
            .default(dashboardsUpdateBodyDeleteInsightsDefault)
            .describe('When deleting, also delete insights that are only on this dashboard.'),
        _create_in_folder: zod.string().optional(),
    })
    .describe('Serializer mixin that handles tags for objects.')

export const dashboardsPartialUpdateBodyNameMax = 400

export const dashboardsPartialUpdateBodyTilesItemWidgetOneConfigOneOneLimitDefault = 25
export const dashboardsPartialUpdateBodyTilesItemWidgetOneConfigOneOneLimitMax = 50

export const dashboardsPartialUpdateBodyTilesItemWidgetOneConfigOneOnePropertiesOneItemKeyMax = 400

export const dashboardsPartialUpdateBodyTilesItemWidgetOneConfigOneOnePropertiesOneItemLabelOneMax = 400

export const dashboardsPartialUpdateBodyTilesItemWidgetOneConfigOneOnePropertiesOneItemValueOneItemOneMax = 4000

export const dashboardsPartialUpdateBodyTilesItemWidgetOneConfigOneOnePropertiesOneItemValueOneMax = 100

export const dashboardsPartialUpdateBodyTilesItemWidgetOneConfigOneOnePropertiesOneItemValueTwoMax = 4000

export const dashboardsPartialUpdateBodyTilesItemWidgetOneConfigOneOnePropertiesOneMax = 20

export const dashboardsPartialUpdateBodyTilesItemWidgetOneConfigOneTwoLimitDefault = 10
export const dashboardsPartialUpdateBodyTilesItemWidgetOneConfigOneTwoLimitMax = 25

export const dashboardsPartialUpdateBodyTilesItemWidgetOneConfigOneTwoOrderByDefault = `occurrences`
export const dashboardsPartialUpdateBodyTilesItemWidgetOneConfigOneTwoOrderDirectionDefault = `DESC`
export const dashboardsPartialUpdateBodyTilesItemWidgetOneConfigOneTwoStatusDefault = `active`

export const dashboardsPartialUpdateBodyTilesItemWidgetOneConfigOneThreeLimitDefault = 10
export const dashboardsPartialUpdateBodyTilesItemWidgetOneConfigOneThreeLimitMax = 25

export const dashboardsPartialUpdateBodyTilesItemWidgetOneConfigOneThreeOrderByDefault = `start_time`
export const dashboardsPartialUpdateBodyTilesItemWidgetOneConfigOneThreeOrderDirectionDefault = `DESC`
export const dashboardsPartialUpdateBodyTilesItemWidgetOneConfigOneFourLimitDefault = 10
export const dashboardsPartialUpdateBodyTilesItemWidgetOneConfigOneFourLimitMax = 25

export const dashboardsPartialUpdateBodyTilesItemWidgetOneConfigOneFourOrderByDefault = `created_at`
export const dashboardsPartialUpdateBodyTilesItemWidgetOneConfigOneFourOrderDirectionDefault = `DESC`
export const dashboardsPartialUpdateBodyTilesItemWidgetOneConfigOneFourStatusDefault = `all`
export const dashboardsPartialUpdateBodyTilesItemWidgetOneConfigOneSixLimitDefault = 10
export const dashboardsPartialUpdateBodyTilesItemWidgetOneConfigOneSixLimitMax = 25

export const dashboardsPartialUpdateBodyTilesItemWidgetOneConfigOneSevenLimitDefault = 50
export const dashboardsPartialUpdateBodyTilesItemWidgetOneConfigOneSevenLimitMax = 100

export const dashboardsPartialUpdateBodyTilesItemWidgetOneConfigOneSevenOrderByDefault = `latest`
export const dashboardsPartialUpdateBodyTilesItemWidgetOneConfigOneSevenWrapLinesDefault = false
export const dashboardsPartialUpdateBodyTilesItemWidgetOneConfigOneSevenTimezoneDefault = `UTC`
export const dashboardsPartialUpdateBodyTilesItemWidgetOneConfigOneEightLimitDefault = 10
export const dashboardsPartialUpdateBodyTilesItemWidgetOneConfigOneEightLimitMax = 25

export const dashboardsPartialUpdateBodyTilesItemWidgetOneConfigOneEightStatusDefault = `all`
export const dashboardsPartialUpdateBodyTilesItemWidgetOneConfigOneEightChannelDefault = `all`
export const dashboardsPartialUpdateBodyTilesItemWidgetOneConfigOneEightAssigneesMax = 100

export const dashboardsPartialUpdateBodyTilesItemWidgetOneConfigOneEightSearchDefault = ``
export const dashboardsPartialUpdateBodyTilesItemWidgetOneConfigOneEightSearchMax = 200

export const dashboardsPartialUpdateBodyTilesItemWidgetOneConfigOneEightSavedViewIdOneMax = 12

export const dashboardsPartialUpdateBodyTilesItemWidgetOneNameMax = 400

export const dashboardsPartialUpdateBodyDeleteInsightsDefault = false

export const DashboardsPartialUpdateBody = /* @__PURE__ */ zod
    .object({
        name: zod.string().max(dashboardsPartialUpdateBodyNameMax).nullish(),
        description: zod.string().optional(),
        pinned: zod.boolean().optional(),
        filters: zod
            .object({
                date_from: zod
                    .string()
                    .nullish()
                    .describe(
                        "Dashboard-level start of the date range, e.g. '-30d', '-7d', or an ISO date. Applies to all tiles."
                    ),
                date_to: zod
                    .string()
                    .nullish()
                    .describe(
                        "Dashboard-level end of the date range, e.g. '-1d' or an ISO date. Null\/omitted means up to now."
                    ),
                properties: zod
                    .unknown()
                    .optional()
                    .describe(
                        'Dashboard-level property filters applied to every tile (PostHog property filter group).'
                    ),
            })
            .describe(
                "OpenAPI-only shape for a dashboard's filters object (agents\/MCP).\n\nDocuments the dashboard-level filters that act as the single source of truth for the\ndashboard's tiles. Runtime persistence reads the raw ``filters`` dict from the request body, so\nextra keys are accepted, but these are the ones agents should set."
            )
            .optional()
            .describe(
                'Dashboard-level filters (date range and properties) applied across all tiles as the source of truth.'
            ),
        breakdown_colors: zod.unknown().optional().describe('Custom color mapping for breakdown values.'),
        data_color_theme_id: zod.number().nullish().describe('ID of the color theme used for chart visualizations.'),
        tags: zod.array(zod.string()).optional(),
        restriction_level: zod
            .union([zod.literal(21), zod.literal(37)])
            .describe(
                '\* `21` - Everyone in the project can edit\n\* `37` - Only those invited to this dashboard can edit'
            )
            .optional()
            .describe(
                'Who can edit this dashboard.\n\n\* `21` - Everyone in the project can edit\n\* `37` - Only those invited to this dashboard can edit'
            ),
        quick_filter_ids: zod
            .array(zod.string())
            .nullish()
            .describe('List of quick filter IDs associated with this dashboard.'),
        grid_spacing: zod
            .enum(['tight', 'condensed', 'standard', 'relaxed', 'wide'])
            .describe(
                '\* `tight` - tight\n\* `condensed` - condensed\n\* `standard` - standard\n\* `relaxed` - relaxed\n\* `wide` - wide'
            )
            .optional()
            .describe(
                'Named tile density preset. Use tight, condensed, standard, relaxed, or wide.\n\n\* `tight` - tight\n\* `condensed` - condensed\n\* `standard` - standard\n\* `relaxed` - relaxed\n\* `wide` - wide'
            ),
        layout_compaction: zod
            .enum(['vertical', 'horizontal', 'stable'])
            .describe('\* `vertical` - vertical\n\* `horizontal` - horizontal\n\* `stable` - stable')
            .optional()
            .describe(
                'How tiles rearrange after a move or resize. vertical stacks tiles upward, horizontal stacks tiles to the left, and stable preserves positions while moving colliding tiles.\n\n\* `vertical` - vertical\n\* `horizontal` - horizontal\n\* `stable` - stable'
            ),
        tiles: zod
            .array(
                zod.object({
                    id: zod.number().optional().describe('Dashboard tile ID to update.'),
                    widget: zod
                        .object({
                            id: zod
                                .uuid()
                                .optional()
                                .describe('Existing widget row ID when updating a widget tile via dashboard PATCH.'),
                            widget_type: zod
                                .enum([
                                    'activity_events_list',
                                    'conversations_recent_tickets',
                                    'error_tracking_list',
                                    'experiment_results',
                                    'experiments_list',
                                    'logs_list',
                                    'session_replay_list',
                                    'survey_results',
                                ])
                                .describe(
                                    '\* `activity_events_list` - activity_events_list\n\* `conversations_recent_tickets` - conversations_recent_tickets\n\* `error_tracking_list` - error_tracking_list\n\* `experiment_results` - experiment_results\n\* `experiments_list` - experiments_list\n\* `logs_list` - logs_list\n\* `session_replay_list` - session_replay_list\n\* `survey_results` - survey_results'
                                )
                                .optional()
                                .describe(
                                    'Widget type identifier (cannot be changed on update).\n\n\* `activity_events_list` - activity_events_list\n\* `conversations_recent_tickets` - conversations_recent_tickets\n\* `error_tracking_list` - error_tracking_list\n\* `experiment_results` - experiment_results\n\* `experiments_list` - experiments_list\n\* `logs_list` - logs_list\n\* `session_replay_list` - session_replay_list\n\* `survey_results` - survey_results'
                                ),
                            config: zod
                                .union([
                                    zod.object({
                                        dateRange: zod
                                            .union([
                                                zod.object({
                                                    date_from: zod
                                                        .union([
                                                            zod.enum([
                                                                '-1M',
                                                                '-30M',
                                                                '-1h',
                                                                '-3h',
                                                                '-24h',
                                                                '-7d',
                                                                '-14d',
                                                                '-30d',
                                                                '-90d',
                                                            ]),
                                                            zod.null(),
                                                        ])
                                                        .optional(),
                                                }),
                                                zod.null(),
                                            ])
                                            .optional(),
                                        filterTestAccounts: zod.union([zod.boolean(), zod.null()]).optional(),
                                        widgetFilters: zod
                                            .union([
                                                zod.record(
                                                    zod.string(),
                                                    zod.object({
                                                        filterId: zod.string().min(1),
                                                        propertyName: zod.string().min(1),
                                                        optionId: zod.string().min(1),
                                                        operator: zod.enum([
                                                            'exact',
                                                            'is_not',
                                                            'icontains',
                                                            'not_icontains',
                                                            'starts_with',
                                                            'not_starts_with',
                                                            'ends_with',
                                                            'not_ends_with',
                                                            'regex',
                                                            'not_regex',
                                                            'gt',
                                                            'gte',
                                                            'lt',
                                                            'lte',
                                                            'is_set',
                                                            'is_not_set',
                                                            'is_date_exact',
                                                            'is_date_before',
                                                            'is_date_after',
                                                            'between',
                                                            'not_between',
                                                            'min',
                                                            'max',
                                                            'in',
                                                            'not_in',
                                                            'is_cleaned_path_exact',
                                                            'flag_evaluates_to',
                                                            'semver_eq',
                                                            'semver_neq',
                                                            'semver_gt',
                                                            'semver_gte',
                                                            'semver_lt',
                                                            'semver_lte',
                                                            'semver_tilde',
                                                            'semver_caret',
                                                            'semver_wildcard',
                                                            'icontains_multi',
                                                            'not_icontains_multi',
                                                        ]),
                                                        value: zod
                                                            .union([zod.string(), zod.array(zod.string()), zod.null()])
                                                            .optional(),
                                                    })
                                                ),
                                                zod.null(),
                                            ])
                                            .optional(),
                                        limit: zod
                                            .number()
                                            .min(1)
                                            .max(dashboardsPartialUpdateBodyTilesItemWidgetOneConfigOneOneLimitMax)
                                            .default(
                                                dashboardsPartialUpdateBodyTilesItemWidgetOneConfigOneOneLimitDefault
                                            )
                                            .describe('Maximum number of events to return.'),
                                        eventName: zod
                                            .union([zod.string().min(1), zod.null()])
                                            .optional()
                                            .describe(
                                                'Limit the feed to a single event name. Omit or null for all events.'
                                            ),
                                        properties: zod
                                            .union([
                                                zod
                                                    .array(
                                                        zod.object({
                                                            key: zod
                                                                .string()
                                                                .min(1)
                                                                .max(
                                                                    dashboardsPartialUpdateBodyTilesItemWidgetOneConfigOneOnePropertiesOneItemKeyMax
                                                                ),
                                                            label: zod
                                                                .union([
                                                                    zod
                                                                        .string()
                                                                        .max(
                                                                            dashboardsPartialUpdateBodyTilesItemWidgetOneConfigOneOnePropertiesOneItemLabelOneMax
                                                                        ),
                                                                    zod.null(),
                                                                ])
                                                                .optional(),
                                                            operator: zod.enum([
                                                                'exact',
                                                                'is_not',
                                                                'icontains',
                                                                'not_icontains',
                                                                'starts_with',
                                                                'not_starts_with',
                                                                'ends_with',
                                                                'not_ends_with',
                                                                'regex',
                                                                'not_regex',
                                                                'gt',
                                                                'gte',
                                                                'lt',
                                                                'lte',
                                                                'is_set',
                                                                'is_not_set',
                                                                'is_date_exact',
                                                                'is_date_before',
                                                                'is_date_after',
                                                                'between',
                                                                'not_between',
                                                                'min',
                                                                'max',
                                                                'in',
                                                                'not_in',
                                                                'is_cleaned_path_exact',
                                                                'flag_evaluates_to',
                                                                'semver_eq',
                                                                'semver_neq',
                                                                'semver_gt',
                                                                'semver_gte',
                                                                'semver_lt',
                                                                'semver_lte',
                                                                'semver_tilde',
                                                                'semver_caret',
                                                                'semver_wildcard',
                                                                'icontains_multi',
                                                                'not_icontains_multi',
                                                            ]),
                                                            type: zod.enum(['event', 'person']),
                                                            value: zod
                                                                .union([
                                                                    zod
                                                                        .array(
                                                                            zod.union([
                                                                                zod
                                                                                    .string()
                                                                                    .max(
                                                                                        dashboardsPartialUpdateBodyTilesItemWidgetOneConfigOneOnePropertiesOneItemValueOneItemOneMax
                                                                                    ),
                                                                                zod.number(),
                                                                                zod.boolean(),
                                                                            ])
                                                                        )
                                                                        .max(
                                                                            dashboardsPartialUpdateBodyTilesItemWidgetOneConfigOneOnePropertiesOneItemValueOneMax
                                                                        ),
                                                                    zod
                                                                        .string()
                                                                        .max(
                                                                            dashboardsPartialUpdateBodyTilesItemWidgetOneConfigOneOnePropertiesOneItemValueTwoMax
                                                                        ),
                                                                    zod.number(),
                                                                    zod.boolean(),
                                                                    zod.null(),
                                                                ])
                                                                .optional(),
                                                        })
                                                    )
                                                    .max(
                                                        dashboardsPartialUpdateBodyTilesItemWidgetOneConfigOneOnePropertiesOneMax
                                                    ),
                                                zod.null(),
                                            ])
                                            .optional()
                                            .describe(
                                                'Event and person property filters, matching Activity > Explore events.'
                                            ),
                                    }),
                                    zod.object({
                                        dateRange: zod
                                            .union([
                                                zod.object({
                                                    date_from: zod
                                                        .union([
                                                            zod.enum([
                                                                '-1M',
                                                                '-30M',
                                                                '-1h',
                                                                '-3h',
                                                                '-24h',
                                                                '-7d',
                                                                '-14d',
                                                                '-30d',
                                                                '-90d',
                                                            ]),
                                                            zod.null(),
                                                        ])
                                                        .optional(),
                                                }),
                                                zod.null(),
                                            ])
                                            .optional(),
                                        filterTestAccounts: zod.union([zod.boolean(), zod.null()]).optional(),
                                        widgetFilters: zod
                                            .union([
                                                zod.record(
                                                    zod.string(),
                                                    zod.object({
                                                        filterId: zod.string().min(1),
                                                        propertyName: zod.string().min(1),
                                                        optionId: zod.string().min(1),
                                                        operator: zod.enum([
                                                            'exact',
                                                            'is_not',
                                                            'icontains',
                                                            'not_icontains',
                                                            'starts_with',
                                                            'not_starts_with',
                                                            'ends_with',
                                                            'not_ends_with',
                                                            'regex',
                                                            'not_regex',
                                                            'gt',
                                                            'gte',
                                                            'lt',
                                                            'lte',
                                                            'is_set',
                                                            'is_not_set',
                                                            'is_date_exact',
                                                            'is_date_before',
                                                            'is_date_after',
                                                            'between',
                                                            'not_between',
                                                            'min',
                                                            'max',
                                                            'in',
                                                            'not_in',
                                                            'is_cleaned_path_exact',
                                                            'flag_evaluates_to',
                                                            'semver_eq',
                                                            'semver_neq',
                                                            'semver_gt',
                                                            'semver_gte',
                                                            'semver_lt',
                                                            'semver_lte',
                                                            'semver_tilde',
                                                            'semver_caret',
                                                            'semver_wildcard',
                                                            'icontains_multi',
                                                            'not_icontains_multi',
                                                        ]),
                                                        value: zod
                                                            .union([zod.string(), zod.array(zod.string()), zod.null()])
                                                            .optional(),
                                                    })
                                                ),
                                                zod.null(),
                                            ])
                                            .optional(),
                                        limit: zod
                                            .number()
                                            .min(1)
                                            .max(dashboardsPartialUpdateBodyTilesItemWidgetOneConfigOneTwoLimitMax)
                                            .default(
                                                dashboardsPartialUpdateBodyTilesItemWidgetOneConfigOneTwoLimitDefault
                                            )
                                            .describe('Maximum number of issues to return.'),
                                        orderBy: zod
                                            .enum(['last_seen', 'first_seen', 'occurrences', 'users', 'sessions'])
                                            .default(
                                                dashboardsPartialUpdateBodyTilesItemWidgetOneConfigOneTwoOrderByDefault
                                            )
                                            .describe('Issue ranking column.'),
                                        orderDirection: zod
                                            .enum(['ASC', 'DESC'])
                                            .default(
                                                dashboardsPartialUpdateBodyTilesItemWidgetOneConfigOneTwoOrderDirectionDefault
                                            )
                                            .describe('Sort direction for orderBy.'),
                                        status: zod
                                            .enum([
                                                'archived',
                                                'active',
                                                'resolved',
                                                'pending_release',
                                                'suppressed',
                                                'all',
                                            ])
                                            .default(
                                                dashboardsPartialUpdateBodyTilesItemWidgetOneConfigOneTwoStatusDefault
                                            )
                                            .describe('Issue status filter.'),
                                        assignee: zod
                                            .union([
                                                zod.object({
                                                    id: zod.union([zod.string(), zod.number()]),
                                                    type: zod.enum(['user', 'role']),
                                                }),
                                                zod.null(),
                                            ])
                                            .optional()
                                            .describe(
                                                'Filter by assignee ({type: user|role, id}). Omit for any assignee.'
                                            ),
                                    }),
                                    zod.object({
                                        dateRange: zod
                                            .union([
                                                zod.object({
                                                    date_from: zod
                                                        .union([
                                                            zod.enum([
                                                                '-1M',
                                                                '-30M',
                                                                '-1h',
                                                                '-3h',
                                                                '-24h',
                                                                '-7d',
                                                                '-14d',
                                                                '-30d',
                                                                '-90d',
                                                            ]),
                                                            zod.null(),
                                                        ])
                                                        .optional(),
                                                }),
                                                zod.null(),
                                            ])
                                            .optional(),
                                        filterTestAccounts: zod.union([zod.boolean(), zod.null()]).optional(),
                                        widgetFilters: zod
                                            .union([
                                                zod.record(
                                                    zod.string(),
                                                    zod.object({
                                                        filterId: zod.string().min(1),
                                                        propertyName: zod.string().min(1),
                                                        optionId: zod.string().min(1),
                                                        operator: zod.enum([
                                                            'exact',
                                                            'is_not',
                                                            'icontains',
                                                            'not_icontains',
                                                            'starts_with',
                                                            'not_starts_with',
                                                            'ends_with',
                                                            'not_ends_with',
                                                            'regex',
                                                            'not_regex',
                                                            'gt',
                                                            'gte',
                                                            'lt',
                                                            'lte',
                                                            'is_set',
                                                            'is_not_set',
                                                            'is_date_exact',
                                                            'is_date_before',
                                                            'is_date_after',
                                                            'between',
                                                            'not_between',
                                                            'min',
                                                            'max',
                                                            'in',
                                                            'not_in',
                                                            'is_cleaned_path_exact',
                                                            'flag_evaluates_to',
                                                            'semver_eq',
                                                            'semver_neq',
                                                            'semver_gt',
                                                            'semver_gte',
                                                            'semver_lt',
                                                            'semver_lte',
                                                            'semver_tilde',
                                                            'semver_caret',
                                                            'semver_wildcard',
                                                            'icontains_multi',
                                                            'not_icontains_multi',
                                                        ]),
                                                        value: zod
                                                            .union([zod.string(), zod.array(zod.string()), zod.null()])
                                                            .optional(),
                                                    })
                                                ),
                                                zod.null(),
                                            ])
                                            .optional(),
                                        limit: zod
                                            .number()
                                            .min(1)
                                            .max(dashboardsPartialUpdateBodyTilesItemWidgetOneConfigOneThreeLimitMax)
                                            .default(
                                                dashboardsPartialUpdateBodyTilesItemWidgetOneConfigOneThreeLimitDefault
                                            )
                                            .describe('Maximum number of recordings to return.'),
                                        orderBy: zod
                                            .enum([
                                                'start_time',
                                                'activity_score',
                                                'recording_duration',
                                                'duration',
                                                'click_count',
                                                'console_error_count',
                                            ])
                                            .default(
                                                dashboardsPartialUpdateBodyTilesItemWidgetOneConfigOneThreeOrderByDefault
                                            )
                                            .describe('Recording ranking column.'),
                                        orderDirection: zod
                                            .enum(['ASC', 'DESC'])
                                            .default(
                                                dashboardsPartialUpdateBodyTilesItemWidgetOneConfigOneThreeOrderDirectionDefault
                                            )
                                            .describe('Sort direction for orderBy.'),
                                        savedFilterId: zod
                                            .union([zod.string(), zod.null()])
                                            .optional()
                                            .describe(
                                                'short_id of a saved session replay filter to refine the recordings shown. When set, the saved filter owns the date range and property filters; only orderBy, orderDirection, and limit still apply. Combine with collectionId to filter within a collection.'
                                            ),
                                        collectionId: zod
                                            .union([zod.string(), zod.null()])
                                            .optional()
                                            .describe(
                                                'short_id of a session replay collection to scope the widget to its pinned recordings. Combine with savedFilterId or property filters to narrow within the collection; orderBy, orderDirection, and limit still apply.'
                                            ),
                                    }),
                                    zod.object({
                                        limit: zod
                                            .number()
                                            .min(1)
                                            .max(dashboardsPartialUpdateBodyTilesItemWidgetOneConfigOneFourLimitMax)
                                            .default(
                                                dashboardsPartialUpdateBodyTilesItemWidgetOneConfigOneFourLimitDefault
                                            )
                                            .describe('Maximum number of experiments to return.'),
                                        orderBy: zod
                                            .enum(['created_at', 'name', 'start_date'])
                                            .default(
                                                dashboardsPartialUpdateBodyTilesItemWidgetOneConfigOneFourOrderByDefault
                                            )
                                            .describe('Experiment list sort column.'),
                                        orderDirection: zod
                                            .enum(['ASC', 'DESC'])
                                            .default(
                                                dashboardsPartialUpdateBodyTilesItemWidgetOneConfigOneFourOrderDirectionDefault
                                            )
                                            .describe('Sort direction for orderBy.'),
                                        status: zod
                                            .enum(['draft', 'running', 'paused', 'exposure_frozen', 'stopped', 'all'])
                                            .default(
                                                dashboardsPartialUpdateBodyTilesItemWidgetOneConfigOneFourStatusDefault
                                            )
                                            .describe('Experiment status filter.'),
                                        createdBy: zod
                                            .union([zod.number(), zod.null()])
                                            .optional()
                                            .describe('Filter by creator (user id). Omit for any creator.'),
                                    }),
                                    zod.object({
                                        experimentId: zod
                                            .union([zod.number(), zod.null()])
                                            .optional()
                                            .describe(
                                                'Experiment to show results for. Null until the user picks one in the widget settings.'
                                            ),
                                    }),
                                    zod.object({
                                        dateRange: zod
                                            .union([
                                                zod.object({
                                                    date_from: zod
                                                        .union([
                                                            zod.enum([
                                                                '-1M',
                                                                '-30M',
                                                                '-1h',
                                                                '-3h',
                                                                '-24h',
                                                                '-7d',
                                                                '-14d',
                                                                '-30d',
                                                                '-90d',
                                                            ]),
                                                            zod.null(),
                                                        ])
                                                        .optional(),
                                                }),
                                                zod.null(),
                                            ])
                                            .optional()
                                            .describe("Null or omitted means all time (the survey's full lifetime)."),
                                        surveyId: zod
                                            .union([zod.string(), zod.null()])
                                            .optional()
                                            .describe(
                                                'Survey to show performance stats and recent responses for. Null until the user picks one.'
                                            ),
                                        limit: zod
                                            .number()
                                            .min(1)
                                            .max(dashboardsPartialUpdateBodyTilesItemWidgetOneConfigOneSixLimitMax)
                                            .default(
                                                dashboardsPartialUpdateBodyTilesItemWidgetOneConfigOneSixLimitDefault
                                            )
                                            .describe('Maximum number of recent responses to return.'),
                                    }),
                                    zod.object({
                                        dateRange: zod
                                            .union([
                                                zod.object({
                                                    date_from: zod
                                                        .union([
                                                            zod.enum([
                                                                '-1M',
                                                                '-30M',
                                                                '-1h',
                                                                '-3h',
                                                                '-24h',
                                                                '-7d',
                                                                '-14d',
                                                                '-30d',
                                                                '-90d',
                                                            ]),
                                                            zod.null(),
                                                        ])
                                                        .optional(),
                                                }),
                                                zod.null(),
                                            ])
                                            .optional(),
                                        limit: zod
                                            .number()
                                            .min(1)
                                            .max(dashboardsPartialUpdateBodyTilesItemWidgetOneConfigOneSevenLimitMax)
                                            .default(
                                                dashboardsPartialUpdateBodyTilesItemWidgetOneConfigOneSevenLimitDefault
                                            )
                                            .describe('Maximum number of log lines to return.'),
                                        orderBy: zod
                                            .enum(['latest', 'earliest'])
                                            .default(
                                                dashboardsPartialUpdateBodyTilesItemWidgetOneConfigOneSevenOrderByDefault
                                            )
                                            .describe('Sort by newest (latest) or oldest (earliest) first.'),
                                        severityLevels: zod
                                            .array(zod.enum(['trace', 'debug', 'info', 'warn', 'error', 'fatal']))
                                            .optional()
                                            .describe(
                                                'Only show logs at these severity levels. Empty shows all levels.'
                                            ),
                                        serviceNames: zod
                                            .array(zod.string())
                                            .optional()
                                            .describe('Only show logs from these services. Empty shows all services.'),
                                        wrapLines: zod
                                            .boolean()
                                            .default(
                                                dashboardsPartialUpdateBodyTilesItemWidgetOneConfigOneSevenWrapLinesDefault
                                            )
                                            .describe(
                                                'Wrap long log lines instead of truncating them to a single row.'
                                            ),
                                        timezone: zod
                                            .enum(['UTC', 'local'])
                                            .default(
                                                dashboardsPartialUpdateBodyTilesItemWidgetOneConfigOneSevenTimezoneDefault
                                            )
                                            .describe(
                                                "Render log timestamps in UTC or in each viewer's local timezone."
                                            ),
                                        savedViewId: zod
                                            .union([zod.string(), zod.null()])
                                            .optional()
                                            .describe(
                                                'short_id of a saved logs view to use as the source. When set, the saved view owns the date range, severity, service, and property filters; only orderBy and limit still apply.'
                                            ),
                                    }),
                                    zod.object({
                                        limit: zod
                                            .number()
                                            .min(1)
                                            .max(dashboardsPartialUpdateBodyTilesItemWidgetOneConfigOneEightLimitMax)
                                            .default(
                                                dashboardsPartialUpdateBodyTilesItemWidgetOneConfigOneEightLimitDefault
                                            )
                                            .describe('Maximum number of tickets to return.'),
                                        status: zod
                                            .enum(['new', 'open', 'pending', 'on_hold', 'resolved', 'all'])
                                            .default(
                                                dashboardsPartialUpdateBodyTilesItemWidgetOneConfigOneEightStatusDefault
                                            )
                                            .describe('Ticket status filter.'),
                                        priorities: zod
                                            .array(zod.enum(['low', 'medium', 'high', 'critical']))
                                            .optional()
                                            .describe(
                                                'Only show tickets with these priorities. Empty shows all priorities.'
                                            ),
                                        channel: zod
                                            .enum(['widget', 'email', 'slack', 'teams', 'github', 'all'])
                                            .default(
                                                dashboardsPartialUpdateBodyTilesItemWidgetOneConfigOneEightChannelDefault
                                            )
                                            .describe('Ticket channel filter.'),
                                        assignees: zod
                                            .array(
                                                zod.union([
                                                    zod.enum(['me', 'unassigned']),
                                                    zod.object({
                                                        id: zod.union([zod.string(), zod.number()]),
                                                        type: zod.enum(['user', 'role']),
                                                    }),
                                                ])
                                            )
                                            .max(
                                                dashboardsPartialUpdateBodyTilesItemWidgetOneConfigOneEightAssigneesMax
                                            )
                                            .optional()
                                            .describe(
                                                "Only show tickets assigned to these users or roles. 'me' means the requesting user and 'unassigned' means tickets without an assignment. Empty shows all assignees."
                                            ),
                                        search: zod
                                            .string()
                                            .max(dashboardsPartialUpdateBodyTilesItemWidgetOneConfigOneEightSearchMax)
                                            .default(
                                                dashboardsPartialUpdateBodyTilesItemWidgetOneConfigOneEightSearchDefault
                                            )
                                            .describe(
                                                'Search requester name or email, ticket subject, message text, or ticket number.'
                                            ),
                                        savedViewId: zod
                                            .union([
                                                zod
                                                    .string()
                                                    .max(
                                                        dashboardsPartialUpdateBodyTilesItemWidgetOneConfigOneEightSavedViewIdOneMax
                                                    ),
                                                zod.null(),
                                            ])
                                            .optional()
                                            .describe(
                                                'short_id of a saved Support view to use as the source. When set, the saved view owns the ticket filters; the widget still sorts by most recently updated and applies its limit.'
                                            ),
                                    }),
                                ])
                                .optional()
                                .describe("Widget-specific configuration. Shape depends on the tile's widget_type."),
                            name: zod
                                .string()
                                .max(dashboardsPartialUpdateBodyTilesItemWidgetOneNameMax)
                                .nullish()
                                .describe('Optional custom display name for the widget tile.'),
                            description: zod
                                .string()
                                .optional()
                                .describe('Optional markdown description shown when show_description is enabled.'),
                        })
                        .optional()
                        .describe('Nested widget row updates.'),
                })
            )
            .optional()
            .describe('Dashboard tiles to update. Widget tiles accept nested widget.config patches.'),
        use_template: zod
            .string()
            .optional()
            .describe('Template key to create the dashboard from a predefined template.'),
        use_dashboard: zod.number().nullish().describe('ID of an existing dashboard to duplicate.'),
        delete_insights: zod
            .boolean()
            .default(dashboardsPartialUpdateBodyDeleteInsightsDefault)
            .describe('When deleting, also delete insights that are only on this dashboard.'),
    })
    .describe(
        'OpenAPI-only PATCH body for dashboards (agents\/MCP).\n\nMust be a superset of ``dashboard_patch_runtime_openapi_field_names()`` — ``extend_schema(request=...)``\nreplaces the inferred schema entirely. Contract: ``test_dashboard_openapi.py``.'
    )

/**
 * Copy an existing dashboard tile to another dashboard (insight, text card, or widget tile).
 */
export const DashboardsCopyTileCreateBody = /* @__PURE__ */ zod.object({
    fromDashboardId: zod.number().describe('Dashboard id the tile currently belongs to.'),
    tileId: zod.number().describe('Dashboard tile id to copy.'),
})

/**
 * Add a markdown text tile to a dashboard.
 *
 * Text tiles render as markdown blocks on the dashboard — useful as section headings, dividers,
 * or annotations between insight tiles to give the dashboard structure.
 */
export const dashboardsCreateTextTileCreateBodyBodyMax = 4000

export const dashboardsCreateTextTileCreateBodyColorMax = 400

export const DashboardsCreateTextTileCreateBody = /* @__PURE__ */ zod.object({
    body: zod
        .string()
        .min(1)
        .max(dashboardsCreateTextTileCreateBodyBodyMax)
        .describe(
            'Markdown body for the text tile. Supports headings, lists, and inline formatting. Useful as a dashboard section heading, divider, or annotation between insights. Max 4000 characters.'
        ),
    layouts: zod
        .object({
            sm: zod
                .object({
                    x: zod.number().optional().describe('Column position in the dashboard grid (0-indexed).'),
                    y: zod.number().optional().describe('Row position in the dashboard grid (0-indexed).'),
                    w: zod.number().optional().describe('Width in grid columns. The desktop grid is 12 columns wide.'),
                    h: zod.number().optional().describe('Height in grid rows.'),
                })
                .optional()
                .describe('Layout for the standard (desktop) breakpoint. The grid is 12 columns wide.'),
            xs: zod
                .object({
                    x: zod.number().optional().describe('Column position in the dashboard grid (0-indexed).'),
                    y: zod.number().optional().describe('Row position in the dashboard grid (0-indexed).'),
                    w: zod.number().optional().describe('Width in grid columns. The desktop grid is 12 columns wide.'),
                    h: zod.number().optional().describe('Height in grid rows.'),
                })
                .optional()
                .describe('Layout for the small (mobile) breakpoint. The grid is 1 column wide.'),
        })
        .optional()
        .describe(
            'Optional grid layout per breakpoint. If omitted, the tile is placed at the bottom of the dashboard using the default size. Text tiles typically use a thin full-width banner (e.g. w=12, h=1).'
        ),
    color: zod
        .string()
        .max(dashboardsCreateTextTileCreateBodyColorMax)
        .nullish()
        .describe("Optional accent color name (e.g. 'blue', 'green', 'purple', 'black')."),
})

/**
 * Soft-delete a single tile from a dashboard.
 *
 * Works for text, insight, and button tiles. The underlying Insight, Text, or ButtonTile
 * object is preserved — only the dashboard tile is hidden. To delete the entire dashboard,
 * use the dashboard delete endpoint instead.
 */
export const DashboardsDeleteTileBody = /* @__PURE__ */ zod.object({
    tile_id: zod.number().describe('ID of the dashboard tile to delete. Use dashboard-get to look up tile IDs.'),
})

export const DashboardsMoveTileCreateBody = /* @__PURE__ */ zod.object({
    to_dashboard: zod.number().describe('Destination dashboard ID.'),
    tile: zod
        .object({
            id: zod.number().describe('Dashboard tile ID to move.'),
        })
        .describe('Tile to move, identified by its dashboard tile ID.'),
})

export const DashboardsMoveTilePartialUpdateBody = /* @__PURE__ */ zod.object({
    to_dashboard: zod.number().optional().describe('Destination dashboard ID.'),
    tile: zod
        .object({
            id: zod.number().describe('Dashboard tile ID to move.'),
        })
        .optional()
        .describe('Tile to move, identified by its dashboard tile ID.'),
})

export const dashboardsReorderTilesCreateBodyLayoutDefault = `preserve`

export const DashboardsReorderTilesCreateBody = /* @__PURE__ */ zod.object({
    tile_order: zod
        .array(zod.number())
        .min(1)
        .describe('Array of tile IDs in the desired display order (top to bottom, left to right).'),
    layout: zod
        .enum(['preserve', 'two_column', 'full_width'])
        .describe('\* `preserve` - preserve\n\* `two_column` - two_column\n\* `full_width` - full_width')
        .default(dashboardsReorderTilesCreateBodyLayoutDefault)
        .describe(
            "How to size tiles when reordering. 'preserve' (default) keeps each tile's existing width and height and only repacks positions in the new order. 'two_column' forces a 6-wide × 5-tall grid (two tiles per row). 'full_width' forces each tile to span the full 12-column row at height 5.\n\n\* `preserve` - preserve\n\* `two_column` - two_column\n\* `full_width` - full_width"
        ),
})

/**
 * Update the markdown body, layout, or color of an existing text tile on a dashboard.
 */
export const dashboardsUpdateTextTileCreateBodyBodyMax = 4000

export const dashboardsUpdateTextTileCreateBodyColorMax = 400

export const DashboardsUpdateTextTileCreateBody = /* @__PURE__ */ zod.object({
    tile_id: zod.number().describe('ID of the dashboard tile to update. Use dashboard-get to look up tile IDs.'),
    body: zod
        .string()
        .min(1)
        .max(dashboardsUpdateTextTileCreateBodyBodyMax)
        .optional()
        .describe('New markdown body for the text tile. Omit to leave the body unchanged. Max 4000 characters.'),
    layouts: zod
        .object({
            sm: zod
                .object({
                    x: zod.number().optional().describe('Column position in the dashboard grid (0-indexed).'),
                    y: zod.number().optional().describe('Row position in the dashboard grid (0-indexed).'),
                    w: zod.number().optional().describe('Width in grid columns. The desktop grid is 12 columns wide.'),
                    h: zod.number().optional().describe('Height in grid rows.'),
                })
                .optional()
                .describe('Layout for the standard (desktop) breakpoint. The grid is 12 columns wide.'),
            xs: zod
                .object({
                    x: zod.number().optional().describe('Column position in the dashboard grid (0-indexed).'),
                    y: zod.number().optional().describe('Row position in the dashboard grid (0-indexed).'),
                    w: zod.number().optional().describe('Width in grid columns. The desktop grid is 12 columns wide.'),
                    h: zod.number().optional().describe('Height in grid rows.'),
                })
                .optional()
                .describe('Layout for the small (mobile) breakpoint. The grid is 1 column wide.'),
        })
        .optional()
        .describe('New grid layout per breakpoint. Omit to leave the layout unchanged.'),
    color: zod
        .string()
        .max(dashboardsUpdateTextTileCreateBodyColorMax)
        .nullish()
        .describe('New accent color name, empty string or null to clear. Omit to leave unchanged.'),
})

/**
 * Add multiple widget tiles to a dashboard in one atomic request.
 */
export const dashboardsWidgetsBatchCreateBodyWidgetsItemOneNameMax = 400

export const dashboardsWidgetsBatchCreateBodyWidgetsItemOneConfigOneLimitDefault = 25
export const dashboardsWidgetsBatchCreateBodyWidgetsItemOneConfigOneLimitMax = 50

export const dashboardsWidgetsBatchCreateBodyWidgetsItemOneConfigOnePropertiesOneItemKeyMax = 400

export const dashboardsWidgetsBatchCreateBodyWidgetsItemOneConfigOnePropertiesOneItemLabelOneMax = 400

export const dashboardsWidgetsBatchCreateBodyWidgetsItemOneConfigOnePropertiesOneItemValueOneItemOneMax = 4000

export const dashboardsWidgetsBatchCreateBodyWidgetsItemOneConfigOnePropertiesOneItemValueOneMax = 100

export const dashboardsWidgetsBatchCreateBodyWidgetsItemOneConfigOnePropertiesOneItemValueTwoMax = 4000

export const dashboardsWidgetsBatchCreateBodyWidgetsItemOneConfigOnePropertiesOneMax = 20

export const dashboardsWidgetsBatchCreateBodyWidgetsItemTwoNameMax = 400

export const dashboardsWidgetsBatchCreateBodyWidgetsItemTwoConfigOneLimitDefault = 10
export const dashboardsWidgetsBatchCreateBodyWidgetsItemTwoConfigOneLimitMax = 25

export const dashboardsWidgetsBatchCreateBodyWidgetsItemTwoConfigOneOrderByDefault = `occurrences`
export const dashboardsWidgetsBatchCreateBodyWidgetsItemTwoConfigOneOrderDirectionDefault = `DESC`
export const dashboardsWidgetsBatchCreateBodyWidgetsItemTwoConfigOneStatusDefault = `active`
export const dashboardsWidgetsBatchCreateBodyWidgetsItemThreeNameMax = 400

export const dashboardsWidgetsBatchCreateBodyWidgetsItemThreeConfigOneLimitDefault = 10
export const dashboardsWidgetsBatchCreateBodyWidgetsItemThreeConfigOneLimitMax = 25

export const dashboardsWidgetsBatchCreateBodyWidgetsItemThreeConfigOneOrderByDefault = `start_time`
export const dashboardsWidgetsBatchCreateBodyWidgetsItemThreeConfigOneOrderDirectionDefault = `DESC`
export const dashboardsWidgetsBatchCreateBodyWidgetsItemFourNameMax = 400

export const dashboardsWidgetsBatchCreateBodyWidgetsItemFourConfigOneLimitDefault = 10
export const dashboardsWidgetsBatchCreateBodyWidgetsItemFourConfigOneLimitMax = 25

export const dashboardsWidgetsBatchCreateBodyWidgetsItemFourConfigOneOrderByDefault = `created_at`
export const dashboardsWidgetsBatchCreateBodyWidgetsItemFourConfigOneOrderDirectionDefault = `DESC`
export const dashboardsWidgetsBatchCreateBodyWidgetsItemFourConfigOneStatusDefault = `all`
export const dashboardsWidgetsBatchCreateBodyWidgetsItemFiveNameMax = 400

export const dashboardsWidgetsBatchCreateBodyWidgetsItemSixNameMax = 400

export const dashboardsWidgetsBatchCreateBodyWidgetsItemSixConfigOneLimitDefault = 10
export const dashboardsWidgetsBatchCreateBodyWidgetsItemSixConfigOneLimitMax = 25

export const dashboardsWidgetsBatchCreateBodyWidgetsItemSevenNameMax = 400

export const dashboardsWidgetsBatchCreateBodyWidgetsItemSevenConfigOneLimitDefault = 50
export const dashboardsWidgetsBatchCreateBodyWidgetsItemSevenConfigOneLimitMax = 100

export const dashboardsWidgetsBatchCreateBodyWidgetsItemSevenConfigOneOrderByDefault = `latest`
export const dashboardsWidgetsBatchCreateBodyWidgetsItemSevenConfigOneWrapLinesDefault = false
export const dashboardsWidgetsBatchCreateBodyWidgetsItemSevenConfigOneTimezoneDefault = `UTC`
export const dashboardsWidgetsBatchCreateBodyWidgetsItemEightNameMax = 400

export const dashboardsWidgetsBatchCreateBodyWidgetsItemEightConfigOneLimitDefault = 10
export const dashboardsWidgetsBatchCreateBodyWidgetsItemEightConfigOneLimitMax = 25

export const dashboardsWidgetsBatchCreateBodyWidgetsItemEightConfigOneStatusDefault = `all`
export const dashboardsWidgetsBatchCreateBodyWidgetsItemEightConfigOneChannelDefault = `all`
export const dashboardsWidgetsBatchCreateBodyWidgetsItemEightConfigOneAssigneesMax = 100

export const dashboardsWidgetsBatchCreateBodyWidgetsItemEightConfigOneSearchDefault = ``
export const dashboardsWidgetsBatchCreateBodyWidgetsItemEightConfigOneSearchMax = 200

export const dashboardsWidgetsBatchCreateBodyWidgetsItemEightConfigOneSavedViewIdOneMax = 12

export const dashboardsWidgetsBatchCreateBodyWidgetsMax = 10

export const DashboardsWidgetsBatchCreateBody = /* @__PURE__ */ zod
    .object({
        widgets: zod
            .array(
                zod.union([
                    zod.object({
                        name: zod
                            .string()
                            .max(dashboardsWidgetsBatchCreateBodyWidgetsItemOneNameMax)
                            .nullish()
                            .describe('Optional custom display name for the widget tile.'),
                        description: zod
                            .string()
                            .optional()
                            .describe('Optional markdown description shown when show_description is enabled.'),
                        layouts: zod
                            .object({
                                sm: zod
                                    .object({
                                        x: zod
                                            .number()
                                            .optional()
                                            .describe('Column position in the dashboard grid (0-indexed).'),
                                        y: zod
                                            .number()
                                            .optional()
                                            .describe('Row position in the dashboard grid (0-indexed).'),
                                        w: zod
                                            .number()
                                            .optional()
                                            .describe('Width in grid columns. The desktop grid is 12 columns wide.'),
                                        h: zod.number().optional().describe('Height in grid rows.'),
                                    })
                                    .optional()
                                    .describe(
                                        'Layout for the standard (desktop) breakpoint. The grid is 12 columns wide.'
                                    ),
                                xs: zod
                                    .object({
                                        x: zod
                                            .number()
                                            .optional()
                                            .describe('Column position in the dashboard grid (0-indexed).'),
                                        y: zod
                                            .number()
                                            .optional()
                                            .describe('Row position in the dashboard grid (0-indexed).'),
                                        w: zod
                                            .number()
                                            .optional()
                                            .describe('Width in grid columns. The desktop grid is 12 columns wide.'),
                                        h: zod.number().optional().describe('Height in grid rows.'),
                                    })
                                    .optional()
                                    .describe('Layout for the small (mobile) breakpoint. The grid is 1 column wide.'),
                            })
                            .optional()
                            .describe('Optional react-grid-layout positions keyed by breakpoint (sm, xs).'),
                        show_description: zod
                            .boolean()
                            .optional()
                            .describe('Whether to show the description on the dashboard tile.'),
                        widget_type: zod.enum(['activity_events_list']),
                        config: zod
                            .object({
                                dateRange: zod
                                    .union([
                                        zod.object({
                                            date_from: zod
                                                .union([
                                                    zod.enum([
                                                        '-1M',
                                                        '-30M',
                                                        '-1h',
                                                        '-3h',
                                                        '-24h',
                                                        '-7d',
                                                        '-14d',
                                                        '-30d',
                                                        '-90d',
                                                    ]),
                                                    zod.null(),
                                                ])
                                                .optional(),
                                        }),
                                        zod.null(),
                                    ])
                                    .optional(),
                                filterTestAccounts: zod.union([zod.boolean(), zod.null()]).optional(),
                                widgetFilters: zod
                                    .union([
                                        zod.record(
                                            zod.string(),
                                            zod.object({
                                                filterId: zod.string().min(1),
                                                propertyName: zod.string().min(1),
                                                optionId: zod.string().min(1),
                                                operator: zod.enum([
                                                    'exact',
                                                    'is_not',
                                                    'icontains',
                                                    'not_icontains',
                                                    'starts_with',
                                                    'not_starts_with',
                                                    'ends_with',
                                                    'not_ends_with',
                                                    'regex',
                                                    'not_regex',
                                                    'gt',
                                                    'gte',
                                                    'lt',
                                                    'lte',
                                                    'is_set',
                                                    'is_not_set',
                                                    'is_date_exact',
                                                    'is_date_before',
                                                    'is_date_after',
                                                    'between',
                                                    'not_between',
                                                    'min',
                                                    'max',
                                                    'in',
                                                    'not_in',
                                                    'is_cleaned_path_exact',
                                                    'flag_evaluates_to',
                                                    'semver_eq',
                                                    'semver_neq',
                                                    'semver_gt',
                                                    'semver_gte',
                                                    'semver_lt',
                                                    'semver_lte',
                                                    'semver_tilde',
                                                    'semver_caret',
                                                    'semver_wildcard',
                                                    'icontains_multi',
                                                    'not_icontains_multi',
                                                ]),
                                                value: zod
                                                    .union([zod.string(), zod.array(zod.string()), zod.null()])
                                                    .optional(),
                                            })
                                        ),
                                        zod.null(),
                                    ])
                                    .optional(),
                                limit: zod
                                    .number()
                                    .min(1)
                                    .max(dashboardsWidgetsBatchCreateBodyWidgetsItemOneConfigOneLimitMax)
                                    .default(dashboardsWidgetsBatchCreateBodyWidgetsItemOneConfigOneLimitDefault)
                                    .describe('Maximum number of events to return.'),
                                eventName: zod
                                    .union([zod.string().min(1), zod.null()])
                                    .optional()
                                    .describe('Limit the feed to a single event name. Omit or null for all events.'),
                                properties: zod
                                    .union([
                                        zod
                                            .array(
                                                zod.object({
                                                    key: zod
                                                        .string()
                                                        .min(1)
                                                        .max(
                                                            dashboardsWidgetsBatchCreateBodyWidgetsItemOneConfigOnePropertiesOneItemKeyMax
                                                        ),
                                                    label: zod
                                                        .union([
                                                            zod
                                                                .string()
                                                                .max(
                                                                    dashboardsWidgetsBatchCreateBodyWidgetsItemOneConfigOnePropertiesOneItemLabelOneMax
                                                                ),
                                                            zod.null(),
                                                        ])
                                                        .optional(),
                                                    operator: zod.enum([
                                                        'exact',
                                                        'is_not',
                                                        'icontains',
                                                        'not_icontains',
                                                        'starts_with',
                                                        'not_starts_with',
                                                        'ends_with',
                                                        'not_ends_with',
                                                        'regex',
                                                        'not_regex',
                                                        'gt',
                                                        'gte',
                                                        'lt',
                                                        'lte',
                                                        'is_set',
                                                        'is_not_set',
                                                        'is_date_exact',
                                                        'is_date_before',
                                                        'is_date_after',
                                                        'between',
                                                        'not_between',
                                                        'min',
                                                        'max',
                                                        'in',
                                                        'not_in',
                                                        'is_cleaned_path_exact',
                                                        'flag_evaluates_to',
                                                        'semver_eq',
                                                        'semver_neq',
                                                        'semver_gt',
                                                        'semver_gte',
                                                        'semver_lt',
                                                        'semver_lte',
                                                        'semver_tilde',
                                                        'semver_caret',
                                                        'semver_wildcard',
                                                        'icontains_multi',
                                                        'not_icontains_multi',
                                                    ]),
                                                    type: zod.enum(['event', 'person']),
                                                    value: zod
                                                        .union([
                                                            zod
                                                                .array(
                                                                    zod.union([
                                                                        zod
                                                                            .string()
                                                                            .max(
                                                                                dashboardsWidgetsBatchCreateBodyWidgetsItemOneConfigOnePropertiesOneItemValueOneItemOneMax
                                                                            ),
                                                                        zod.number(),
                                                                        zod.boolean(),
                                                                    ])
                                                                )
                                                                .max(
                                                                    dashboardsWidgetsBatchCreateBodyWidgetsItemOneConfigOnePropertiesOneItemValueOneMax
                                                                ),
                                                            zod
                                                                .string()
                                                                .max(
                                                                    dashboardsWidgetsBatchCreateBodyWidgetsItemOneConfigOnePropertiesOneItemValueTwoMax
                                                                ),
                                                            zod.number(),
                                                            zod.boolean(),
                                                            zod.null(),
                                                        ])
                                                        .optional(),
                                                })
                                            )
                                            .max(
                                                dashboardsWidgetsBatchCreateBodyWidgetsItemOneConfigOnePropertiesOneMax
                                            ),
                                        zod.null(),
                                    ])
                                    .optional()
                                    .describe('Event and person property filters, matching Activity > Explore events.'),
                            })
                            .describe('Configuration for the recent events widget.'),
                    }),
                    zod.object({
                        name: zod
                            .string()
                            .max(dashboardsWidgetsBatchCreateBodyWidgetsItemTwoNameMax)
                            .nullish()
                            .describe('Optional custom display name for the widget tile.'),
                        description: zod
                            .string()
                            .optional()
                            .describe('Optional markdown description shown when show_description is enabled.'),
                        layouts: zod
                            .object({
                                sm: zod
                                    .object({
                                        x: zod
                                            .number()
                                            .optional()
                                            .describe('Column position in the dashboard grid (0-indexed).'),
                                        y: zod
                                            .number()
                                            .optional()
                                            .describe('Row position in the dashboard grid (0-indexed).'),
                                        w: zod
                                            .number()
                                            .optional()
                                            .describe('Width in grid columns. The desktop grid is 12 columns wide.'),
                                        h: zod.number().optional().describe('Height in grid rows.'),
                                    })
                                    .optional()
                                    .describe(
                                        'Layout for the standard (desktop) breakpoint. The grid is 12 columns wide.'
                                    ),
                                xs: zod
                                    .object({
                                        x: zod
                                            .number()
                                            .optional()
                                            .describe('Column position in the dashboard grid (0-indexed).'),
                                        y: zod
                                            .number()
                                            .optional()
                                            .describe('Row position in the dashboard grid (0-indexed).'),
                                        w: zod
                                            .number()
                                            .optional()
                                            .describe('Width in grid columns. The desktop grid is 12 columns wide.'),
                                        h: zod.number().optional().describe('Height in grid rows.'),
                                    })
                                    .optional()
                                    .describe('Layout for the small (mobile) breakpoint. The grid is 1 column wide.'),
                            })
                            .optional()
                            .describe('Optional react-grid-layout positions keyed by breakpoint (sm, xs).'),
                        show_description: zod
                            .boolean()
                            .optional()
                            .describe('Whether to show the description on the dashboard tile.'),
                        widget_type: zod.enum(['error_tracking_list']),
                        config: zod
                            .object({
                                dateRange: zod
                                    .union([
                                        zod.object({
                                            date_from: zod
                                                .union([
                                                    zod.enum([
                                                        '-1M',
                                                        '-30M',
                                                        '-1h',
                                                        '-3h',
                                                        '-24h',
                                                        '-7d',
                                                        '-14d',
                                                        '-30d',
                                                        '-90d',
                                                    ]),
                                                    zod.null(),
                                                ])
                                                .optional(),
                                        }),
                                        zod.null(),
                                    ])
                                    .optional(),
                                filterTestAccounts: zod.union([zod.boolean(), zod.null()]).optional(),
                                widgetFilters: zod
                                    .union([
                                        zod.record(
                                            zod.string(),
                                            zod.object({
                                                filterId: zod.string().min(1),
                                                propertyName: zod.string().min(1),
                                                optionId: zod.string().min(1),
                                                operator: zod.enum([
                                                    'exact',
                                                    'is_not',
                                                    'icontains',
                                                    'not_icontains',
                                                    'starts_with',
                                                    'not_starts_with',
                                                    'ends_with',
                                                    'not_ends_with',
                                                    'regex',
                                                    'not_regex',
                                                    'gt',
                                                    'gte',
                                                    'lt',
                                                    'lte',
                                                    'is_set',
                                                    'is_not_set',
                                                    'is_date_exact',
                                                    'is_date_before',
                                                    'is_date_after',
                                                    'between',
                                                    'not_between',
                                                    'min',
                                                    'max',
                                                    'in',
                                                    'not_in',
                                                    'is_cleaned_path_exact',
                                                    'flag_evaluates_to',
                                                    'semver_eq',
                                                    'semver_neq',
                                                    'semver_gt',
                                                    'semver_gte',
                                                    'semver_lt',
                                                    'semver_lte',
                                                    'semver_tilde',
                                                    'semver_caret',
                                                    'semver_wildcard',
                                                    'icontains_multi',
                                                    'not_icontains_multi',
                                                ]),
                                                value: zod
                                                    .union([zod.string(), zod.array(zod.string()), zod.null()])
                                                    .optional(),
                                            })
                                        ),
                                        zod.null(),
                                    ])
                                    .optional(),
                                limit: zod
                                    .number()
                                    .min(1)
                                    .max(dashboardsWidgetsBatchCreateBodyWidgetsItemTwoConfigOneLimitMax)
                                    .default(dashboardsWidgetsBatchCreateBodyWidgetsItemTwoConfigOneLimitDefault)
                                    .describe('Maximum number of issues to return.'),
                                orderBy: zod
                                    .enum(['last_seen', 'first_seen', 'occurrences', 'users', 'sessions'])
                                    .default(dashboardsWidgetsBatchCreateBodyWidgetsItemTwoConfigOneOrderByDefault)
                                    .describe('Issue ranking column.'),
                                orderDirection: zod
                                    .enum(['ASC', 'DESC'])
                                    .default(
                                        dashboardsWidgetsBatchCreateBodyWidgetsItemTwoConfigOneOrderDirectionDefault
                                    )
                                    .describe('Sort direction for orderBy.'),
                                status: zod
                                    .enum(['archived', 'active', 'resolved', 'pending_release', 'suppressed', 'all'])
                                    .default(dashboardsWidgetsBatchCreateBodyWidgetsItemTwoConfigOneStatusDefault)
                                    .describe('Issue status filter.'),
                                assignee: zod
                                    .union([
                                        zod.object({
                                            id: zod.union([zod.string(), zod.number()]),
                                            type: zod.enum(['user', 'role']),
                                        }),
                                        zod.null(),
                                    ])
                                    .optional()
                                    .describe('Filter by assignee ({type: user|role, id}). Omit for any assignee.'),
                            })
                            .describe('Configuration for the top issues widget.'),
                    }),
                    zod.object({
                        name: zod
                            .string()
                            .max(dashboardsWidgetsBatchCreateBodyWidgetsItemThreeNameMax)
                            .nullish()
                            .describe('Optional custom display name for the widget tile.'),
                        description: zod
                            .string()
                            .optional()
                            .describe('Optional markdown description shown when show_description is enabled.'),
                        layouts: zod
                            .object({
                                sm: zod
                                    .object({
                                        x: zod
                                            .number()
                                            .optional()
                                            .describe('Column position in the dashboard grid (0-indexed).'),
                                        y: zod
                                            .number()
                                            .optional()
                                            .describe('Row position in the dashboard grid (0-indexed).'),
                                        w: zod
                                            .number()
                                            .optional()
                                            .describe('Width in grid columns. The desktop grid is 12 columns wide.'),
                                        h: zod.number().optional().describe('Height in grid rows.'),
                                    })
                                    .optional()
                                    .describe(
                                        'Layout for the standard (desktop) breakpoint. The grid is 12 columns wide.'
                                    ),
                                xs: zod
                                    .object({
                                        x: zod
                                            .number()
                                            .optional()
                                            .describe('Column position in the dashboard grid (0-indexed).'),
                                        y: zod
                                            .number()
                                            .optional()
                                            .describe('Row position in the dashboard grid (0-indexed).'),
                                        w: zod
                                            .number()
                                            .optional()
                                            .describe('Width in grid columns. The desktop grid is 12 columns wide.'),
                                        h: zod.number().optional().describe('Height in grid rows.'),
                                    })
                                    .optional()
                                    .describe('Layout for the small (mobile) breakpoint. The grid is 1 column wide.'),
                            })
                            .optional()
                            .describe('Optional react-grid-layout positions keyed by breakpoint (sm, xs).'),
                        show_description: zod
                            .boolean()
                            .optional()
                            .describe('Whether to show the description on the dashboard tile.'),
                        widget_type: zod.enum(['session_replay_list']),
                        config: zod
                            .object({
                                dateRange: zod
                                    .union([
                                        zod.object({
                                            date_from: zod
                                                .union([
                                                    zod.enum([
                                                        '-1M',
                                                        '-30M',
                                                        '-1h',
                                                        '-3h',
                                                        '-24h',
                                                        '-7d',
                                                        '-14d',
                                                        '-30d',
                                                        '-90d',
                                                    ]),
                                                    zod.null(),
                                                ])
                                                .optional(),
                                        }),
                                        zod.null(),
                                    ])
                                    .optional(),
                                filterTestAccounts: zod.union([zod.boolean(), zod.null()]).optional(),
                                widgetFilters: zod
                                    .union([
                                        zod.record(
                                            zod.string(),
                                            zod.object({
                                                filterId: zod.string().min(1),
                                                propertyName: zod.string().min(1),
                                                optionId: zod.string().min(1),
                                                operator: zod.enum([
                                                    'exact',
                                                    'is_not',
                                                    'icontains',
                                                    'not_icontains',
                                                    'starts_with',
                                                    'not_starts_with',
                                                    'ends_with',
                                                    'not_ends_with',
                                                    'regex',
                                                    'not_regex',
                                                    'gt',
                                                    'gte',
                                                    'lt',
                                                    'lte',
                                                    'is_set',
                                                    'is_not_set',
                                                    'is_date_exact',
                                                    'is_date_before',
                                                    'is_date_after',
                                                    'between',
                                                    'not_between',
                                                    'min',
                                                    'max',
                                                    'in',
                                                    'not_in',
                                                    'is_cleaned_path_exact',
                                                    'flag_evaluates_to',
                                                    'semver_eq',
                                                    'semver_neq',
                                                    'semver_gt',
                                                    'semver_gte',
                                                    'semver_lt',
                                                    'semver_lte',
                                                    'semver_tilde',
                                                    'semver_caret',
                                                    'semver_wildcard',
                                                    'icontains_multi',
                                                    'not_icontains_multi',
                                                ]),
                                                value: zod
                                                    .union([zod.string(), zod.array(zod.string()), zod.null()])
                                                    .optional(),
                                            })
                                        ),
                                        zod.null(),
                                    ])
                                    .optional(),
                                limit: zod
                                    .number()
                                    .min(1)
                                    .max(dashboardsWidgetsBatchCreateBodyWidgetsItemThreeConfigOneLimitMax)
                                    .default(dashboardsWidgetsBatchCreateBodyWidgetsItemThreeConfigOneLimitDefault)
                                    .describe('Maximum number of recordings to return.'),
                                orderBy: zod
                                    .enum([
                                        'start_time',
                                        'activity_score',
                                        'recording_duration',
                                        'duration',
                                        'click_count',
                                        'console_error_count',
                                    ])
                                    .default(dashboardsWidgetsBatchCreateBodyWidgetsItemThreeConfigOneOrderByDefault)
                                    .describe('Recording ranking column.'),
                                orderDirection: zod
                                    .enum(['ASC', 'DESC'])
                                    .default(
                                        dashboardsWidgetsBatchCreateBodyWidgetsItemThreeConfigOneOrderDirectionDefault
                                    )
                                    .describe('Sort direction for orderBy.'),
                                savedFilterId: zod
                                    .union([zod.string(), zod.null()])
                                    .optional()
                                    .describe(
                                        'short_id of a saved session replay filter to refine the recordings shown. When set, the saved filter owns the date range and property filters; only orderBy, orderDirection, and limit still apply. Combine with collectionId to filter within a collection.'
                                    ),
                                collectionId: zod
                                    .union([zod.string(), zod.null()])
                                    .optional()
                                    .describe(
                                        'short_id of a session replay collection to scope the widget to its pinned recordings. Combine with savedFilterId or property filters to narrow within the collection; orderBy, orderDirection, and limit still apply.'
                                    ),
                            })
                            .describe('Configuration for the recent recordings widget.'),
                    }),
                    zod.object({
                        name: zod
                            .string()
                            .max(dashboardsWidgetsBatchCreateBodyWidgetsItemFourNameMax)
                            .nullish()
                            .describe('Optional custom display name for the widget tile.'),
                        description: zod
                            .string()
                            .optional()
                            .describe('Optional markdown description shown when show_description is enabled.'),
                        layouts: zod
                            .object({
                                sm: zod
                                    .object({
                                        x: zod
                                            .number()
                                            .optional()
                                            .describe('Column position in the dashboard grid (0-indexed).'),
                                        y: zod
                                            .number()
                                            .optional()
                                            .describe('Row position in the dashboard grid (0-indexed).'),
                                        w: zod
                                            .number()
                                            .optional()
                                            .describe('Width in grid columns. The desktop grid is 12 columns wide.'),
                                        h: zod.number().optional().describe('Height in grid rows.'),
                                    })
                                    .optional()
                                    .describe(
                                        'Layout for the standard (desktop) breakpoint. The grid is 12 columns wide.'
                                    ),
                                xs: zod
                                    .object({
                                        x: zod
                                            .number()
                                            .optional()
                                            .describe('Column position in the dashboard grid (0-indexed).'),
                                        y: zod
                                            .number()
                                            .optional()
                                            .describe('Row position in the dashboard grid (0-indexed).'),
                                        w: zod
                                            .number()
                                            .optional()
                                            .describe('Width in grid columns. The desktop grid is 12 columns wide.'),
                                        h: zod.number().optional().describe('Height in grid rows.'),
                                    })
                                    .optional()
                                    .describe('Layout for the small (mobile) breakpoint. The grid is 1 column wide.'),
                            })
                            .optional()
                            .describe('Optional react-grid-layout positions keyed by breakpoint (sm, xs).'),
                        show_description: zod
                            .boolean()
                            .optional()
                            .describe('Whether to show the description on the dashboard tile.'),
                        widget_type: zod.enum(['experiments_list']),
                        config: zod
                            .object({
                                limit: zod
                                    .number()
                                    .min(1)
                                    .max(dashboardsWidgetsBatchCreateBodyWidgetsItemFourConfigOneLimitMax)
                                    .default(dashboardsWidgetsBatchCreateBodyWidgetsItemFourConfigOneLimitDefault)
                                    .describe('Maximum number of experiments to return.'),
                                orderBy: zod
                                    .enum(['created_at', 'name', 'start_date'])
                                    .default(dashboardsWidgetsBatchCreateBodyWidgetsItemFourConfigOneOrderByDefault)
                                    .describe('Experiment list sort column.'),
                                orderDirection: zod
                                    .enum(['ASC', 'DESC'])
                                    .default(
                                        dashboardsWidgetsBatchCreateBodyWidgetsItemFourConfigOneOrderDirectionDefault
                                    )
                                    .describe('Sort direction for orderBy.'),
                                status: zod
                                    .enum(['draft', 'running', 'paused', 'exposure_frozen', 'stopped', 'all'])
                                    .default(dashboardsWidgetsBatchCreateBodyWidgetsItemFourConfigOneStatusDefault)
                                    .describe('Experiment status filter.'),
                                createdBy: zod
                                    .union([zod.number(), zod.null()])
                                    .optional()
                                    .describe('Filter by creator (user id). Omit for any creator.'),
                            })
                            .describe('Configuration for the experiments list widget.'),
                    }),
                    zod.object({
                        name: zod
                            .string()
                            .max(dashboardsWidgetsBatchCreateBodyWidgetsItemFiveNameMax)
                            .nullish()
                            .describe('Optional custom display name for the widget tile.'),
                        description: zod
                            .string()
                            .optional()
                            .describe('Optional markdown description shown when show_description is enabled.'),
                        layouts: zod
                            .object({
                                sm: zod
                                    .object({
                                        x: zod
                                            .number()
                                            .optional()
                                            .describe('Column position in the dashboard grid (0-indexed).'),
                                        y: zod
                                            .number()
                                            .optional()
                                            .describe('Row position in the dashboard grid (0-indexed).'),
                                        w: zod
                                            .number()
                                            .optional()
                                            .describe('Width in grid columns. The desktop grid is 12 columns wide.'),
                                        h: zod.number().optional().describe('Height in grid rows.'),
                                    })
                                    .optional()
                                    .describe(
                                        'Layout for the standard (desktop) breakpoint. The grid is 12 columns wide.'
                                    ),
                                xs: zod
                                    .object({
                                        x: zod
                                            .number()
                                            .optional()
                                            .describe('Column position in the dashboard grid (0-indexed).'),
                                        y: zod
                                            .number()
                                            .optional()
                                            .describe('Row position in the dashboard grid (0-indexed).'),
                                        w: zod
                                            .number()
                                            .optional()
                                            .describe('Width in grid columns. The desktop grid is 12 columns wide.'),
                                        h: zod.number().optional().describe('Height in grid rows.'),
                                    })
                                    .optional()
                                    .describe('Layout for the small (mobile) breakpoint. The grid is 1 column wide.'),
                            })
                            .optional()
                            .describe('Optional react-grid-layout positions keyed by breakpoint (sm, xs).'),
                        show_description: zod
                            .boolean()
                            .optional()
                            .describe('Whether to show the description on the dashboard tile.'),
                        widget_type: zod.enum(['experiment_results']),
                        config: zod
                            .object({
                                experimentId: zod
                                    .union([zod.number(), zod.null()])
                                    .optional()
                                    .describe(
                                        'Experiment to show results for. Null until the user picks one in the widget settings.'
                                    ),
                            })
                            .describe('Configuration for the experiment results widget.'),
                    }),
                    zod.object({
                        name: zod
                            .string()
                            .max(dashboardsWidgetsBatchCreateBodyWidgetsItemSixNameMax)
                            .nullish()
                            .describe('Optional custom display name for the widget tile.'),
                        description: zod
                            .string()
                            .optional()
                            .describe('Optional markdown description shown when show_description is enabled.'),
                        layouts: zod
                            .object({
                                sm: zod
                                    .object({
                                        x: zod
                                            .number()
                                            .optional()
                                            .describe('Column position in the dashboard grid (0-indexed).'),
                                        y: zod
                                            .number()
                                            .optional()
                                            .describe('Row position in the dashboard grid (0-indexed).'),
                                        w: zod
                                            .number()
                                            .optional()
                                            .describe('Width in grid columns. The desktop grid is 12 columns wide.'),
                                        h: zod.number().optional().describe('Height in grid rows.'),
                                    })
                                    .optional()
                                    .describe(
                                        'Layout for the standard (desktop) breakpoint. The grid is 12 columns wide.'
                                    ),
                                xs: zod
                                    .object({
                                        x: zod
                                            .number()
                                            .optional()
                                            .describe('Column position in the dashboard grid (0-indexed).'),
                                        y: zod
                                            .number()
                                            .optional()
                                            .describe('Row position in the dashboard grid (0-indexed).'),
                                        w: zod
                                            .number()
                                            .optional()
                                            .describe('Width in grid columns. The desktop grid is 12 columns wide.'),
                                        h: zod.number().optional().describe('Height in grid rows.'),
                                    })
                                    .optional()
                                    .describe('Layout for the small (mobile) breakpoint. The grid is 1 column wide.'),
                            })
                            .optional()
                            .describe('Optional react-grid-layout positions keyed by breakpoint (sm, xs).'),
                        show_description: zod
                            .boolean()
                            .optional()
                            .describe('Whether to show the description on the dashboard tile.'),
                        widget_type: zod.enum(['survey_results']),
                        config: zod
                            .object({
                                dateRange: zod
                                    .union([
                                        zod.object({
                                            date_from: zod
                                                .union([
                                                    zod.enum([
                                                        '-1M',
                                                        '-30M',
                                                        '-1h',
                                                        '-3h',
                                                        '-24h',
                                                        '-7d',
                                                        '-14d',
                                                        '-30d',
                                                        '-90d',
                                                    ]),
                                                    zod.null(),
                                                ])
                                                .optional(),
                                        }),
                                        zod.null(),
                                    ])
                                    .optional()
                                    .describe("Null or omitted means all time (the survey's full lifetime)."),
                                surveyId: zod
                                    .union([zod.string(), zod.null()])
                                    .optional()
                                    .describe(
                                        'Survey to show performance stats and recent responses for. Null until the user picks one.'
                                    ),
                                limit: zod
                                    .number()
                                    .min(1)
                                    .max(dashboardsWidgetsBatchCreateBodyWidgetsItemSixConfigOneLimitMax)
                                    .default(dashboardsWidgetsBatchCreateBodyWidgetsItemSixConfigOneLimitDefault)
                                    .describe('Maximum number of recent responses to return.'),
                            })
                            .describe('Configuration for the survey results widget.'),
                    }),
                    zod.object({
                        name: zod
                            .string()
                            .max(dashboardsWidgetsBatchCreateBodyWidgetsItemSevenNameMax)
                            .nullish()
                            .describe('Optional custom display name for the widget tile.'),
                        description: zod
                            .string()
                            .optional()
                            .describe('Optional markdown description shown when show_description is enabled.'),
                        layouts: zod
                            .object({
                                sm: zod
                                    .object({
                                        x: zod
                                            .number()
                                            .optional()
                                            .describe('Column position in the dashboard grid (0-indexed).'),
                                        y: zod
                                            .number()
                                            .optional()
                                            .describe('Row position in the dashboard grid (0-indexed).'),
                                        w: zod
                                            .number()
                                            .optional()
                                            .describe('Width in grid columns. The desktop grid is 12 columns wide.'),
                                        h: zod.number().optional().describe('Height in grid rows.'),
                                    })
                                    .optional()
                                    .describe(
                                        'Layout for the standard (desktop) breakpoint. The grid is 12 columns wide.'
                                    ),
                                xs: zod
                                    .object({
                                        x: zod
                                            .number()
                                            .optional()
                                            .describe('Column position in the dashboard grid (0-indexed).'),
                                        y: zod
                                            .number()
                                            .optional()
                                            .describe('Row position in the dashboard grid (0-indexed).'),
                                        w: zod
                                            .number()
                                            .optional()
                                            .describe('Width in grid columns. The desktop grid is 12 columns wide.'),
                                        h: zod.number().optional().describe('Height in grid rows.'),
                                    })
                                    .optional()
                                    .describe('Layout for the small (mobile) breakpoint. The grid is 1 column wide.'),
                            })
                            .optional()
                            .describe('Optional react-grid-layout positions keyed by breakpoint (sm, xs).'),
                        show_description: zod
                            .boolean()
                            .optional()
                            .describe('Whether to show the description on the dashboard tile.'),
                        widget_type: zod.enum(['logs_list']),
                        config: zod
                            .object({
                                dateRange: zod
                                    .union([
                                        zod.object({
                                            date_from: zod
                                                .union([
                                                    zod.enum([
                                                        '-1M',
                                                        '-30M',
                                                        '-1h',
                                                        '-3h',
                                                        '-24h',
                                                        '-7d',
                                                        '-14d',
                                                        '-30d',
                                                        '-90d',
                                                    ]),
                                                    zod.null(),
                                                ])
                                                .optional(),
                                        }),
                                        zod.null(),
                                    ])
                                    .optional(),
                                limit: zod
                                    .number()
                                    .min(1)
                                    .max(dashboardsWidgetsBatchCreateBodyWidgetsItemSevenConfigOneLimitMax)
                                    .default(dashboardsWidgetsBatchCreateBodyWidgetsItemSevenConfigOneLimitDefault)
                                    .describe('Maximum number of log lines to return.'),
                                orderBy: zod
                                    .enum(['latest', 'earliest'])
                                    .default(dashboardsWidgetsBatchCreateBodyWidgetsItemSevenConfigOneOrderByDefault)
                                    .describe('Sort by newest (latest) or oldest (earliest) first.'),
                                severityLevels: zod
                                    .array(zod.enum(['trace', 'debug', 'info', 'warn', 'error', 'fatal']))
                                    .optional()
                                    .describe('Only show logs at these severity levels. Empty shows all levels.'),
                                serviceNames: zod
                                    .array(zod.string())
                                    .optional()
                                    .describe('Only show logs from these services. Empty shows all services.'),
                                wrapLines: zod
                                    .boolean()
                                    .default(dashboardsWidgetsBatchCreateBodyWidgetsItemSevenConfigOneWrapLinesDefault)
                                    .describe('Wrap long log lines instead of truncating them to a single row.'),
                                timezone: zod
                                    .enum(['UTC', 'local'])
                                    .default(dashboardsWidgetsBatchCreateBodyWidgetsItemSevenConfigOneTimezoneDefault)
                                    .describe("Render log timestamps in UTC or in each viewer's local timezone."),
                                savedViewId: zod
                                    .union([zod.string(), zod.null()])
                                    .optional()
                                    .describe(
                                        'short_id of a saved logs view to use as the source. When set, the saved view owns the date range, severity, service, and property filters; only orderBy and limit still apply.'
                                    ),
                            })
                            .describe('Configuration for the recent logs widget.'),
                    }),
                    zod.object({
                        name: zod
                            .string()
                            .max(dashboardsWidgetsBatchCreateBodyWidgetsItemEightNameMax)
                            .nullish()
                            .describe('Optional custom display name for the widget tile.'),
                        description: zod
                            .string()
                            .optional()
                            .describe('Optional markdown description shown when show_description is enabled.'),
                        layouts: zod
                            .object({
                                sm: zod
                                    .object({
                                        x: zod
                                            .number()
                                            .optional()
                                            .describe('Column position in the dashboard grid (0-indexed).'),
                                        y: zod
                                            .number()
                                            .optional()
                                            .describe('Row position in the dashboard grid (0-indexed).'),
                                        w: zod
                                            .number()
                                            .optional()
                                            .describe('Width in grid columns. The desktop grid is 12 columns wide.'),
                                        h: zod.number().optional().describe('Height in grid rows.'),
                                    })
                                    .optional()
                                    .describe(
                                        'Layout for the standard (desktop) breakpoint. The grid is 12 columns wide.'
                                    ),
                                xs: zod
                                    .object({
                                        x: zod
                                            .number()
                                            .optional()
                                            .describe('Column position in the dashboard grid (0-indexed).'),
                                        y: zod
                                            .number()
                                            .optional()
                                            .describe('Row position in the dashboard grid (0-indexed).'),
                                        w: zod
                                            .number()
                                            .optional()
                                            .describe('Width in grid columns. The desktop grid is 12 columns wide.'),
                                        h: zod.number().optional().describe('Height in grid rows.'),
                                    })
                                    .optional()
                                    .describe('Layout for the small (mobile) breakpoint. The grid is 1 column wide.'),
                            })
                            .optional()
                            .describe('Optional react-grid-layout positions keyed by breakpoint (sm, xs).'),
                        show_description: zod
                            .boolean()
                            .optional()
                            .describe('Whether to show the description on the dashboard tile.'),
                        widget_type: zod.enum(['conversations_recent_tickets']),
                        config: zod
                            .object({
                                limit: zod
                                    .number()
                                    .min(1)
                                    .max(dashboardsWidgetsBatchCreateBodyWidgetsItemEightConfigOneLimitMax)
                                    .default(dashboardsWidgetsBatchCreateBodyWidgetsItemEightConfigOneLimitDefault)
                                    .describe('Maximum number of tickets to return.'),
                                status: zod
                                    .enum(['new', 'open', 'pending', 'on_hold', 'resolved', 'all'])
                                    .default(dashboardsWidgetsBatchCreateBodyWidgetsItemEightConfigOneStatusDefault)
                                    .describe('Ticket status filter.'),
                                priorities: zod
                                    .array(zod.enum(['low', 'medium', 'high', 'critical']))
                                    .optional()
                                    .describe('Only show tickets with these priorities. Empty shows all priorities.'),
                                channel: zod
                                    .enum(['widget', 'email', 'slack', 'teams', 'github', 'all'])
                                    .default(dashboardsWidgetsBatchCreateBodyWidgetsItemEightConfigOneChannelDefault)
                                    .describe('Ticket channel filter.'),
                                assignees: zod
                                    .array(
                                        zod.union([
                                            zod.enum(['me', 'unassigned']),
                                            zod.object({
                                                id: zod.union([zod.string(), zod.number()]),
                                                type: zod.enum(['user', 'role']),
                                            }),
                                        ])
                                    )
                                    .max(dashboardsWidgetsBatchCreateBodyWidgetsItemEightConfigOneAssigneesMax)
                                    .optional()
                                    .describe(
                                        "Only show tickets assigned to these users or roles. 'me' means the requesting user and 'unassigned' means tickets without an assignment. Empty shows all assignees."
                                    ),
                                search: zod
                                    .string()
                                    .max(dashboardsWidgetsBatchCreateBodyWidgetsItemEightConfigOneSearchMax)
                                    .default(dashboardsWidgetsBatchCreateBodyWidgetsItemEightConfigOneSearchDefault)
                                    .describe(
                                        'Search requester name or email, ticket subject, message text, or ticket number.'
                                    ),
                                savedViewId: zod
                                    .union([
                                        zod
                                            .string()
                                            .max(
                                                dashboardsWidgetsBatchCreateBodyWidgetsItemEightConfigOneSavedViewIdOneMax
                                            ),
                                        zod.null(),
                                    ])
                                    .optional()
                                    .describe(
                                        'short_id of a saved Support view to use as the source. When set, the saved view owns the ticket filters; the widget still sorts by most recently updated and applies its limit.'
                                    ),
                            })
                            .describe('Configuration for the recent tickets widget.'),
                    }),
                ])
            )
            .min(1)
            .max(dashboardsWidgetsBatchCreateBodyWidgetsMax)
            .describe(
                'Widget tiles to add atomically. Supported widget_type values: activity_events_list, conversations_recent_tickets, error_tracking_list, experiment_results, experiments_list, logs_list, session_replay_list, survey_results. Use dashboard-widget-catalog-list for per-type config_schema documentation. (1–10 per request).'
            ),
    })
    .describe('OpenAPI-only batch-add schema with widget_type-discriminated config shapes for agents.')

/**
 * Update the settings of existing widgets in place, atomically — config, name, and description.
 *
 * Each entry targets a widget by its tile_id and reuses the same write path as the dashboard PATCH endpoint.
 * The widget_type is immutable. This edits widget settings only (config, name, description); tile placement
 * (layouts, show_description) is a dashboard concern — use the dashboard PATCH endpoint or reorder_tiles for
 * that. All updates succeed or fail together. To add new widgets, use the widgets/batch POST endpoint; to
 * remove one, use delete_tile.
 */
export const dashboardsUpdateWidgetsBatchBodyWidgetsItemOneNameMax = 400

export const dashboardsUpdateWidgetsBatchBodyWidgetsItemOneConfigOneLimitDefault = 25
export const dashboardsUpdateWidgetsBatchBodyWidgetsItemOneConfigOneLimitMax = 50

export const dashboardsUpdateWidgetsBatchBodyWidgetsItemOneConfigOnePropertiesOneItemKeyMax = 400

export const dashboardsUpdateWidgetsBatchBodyWidgetsItemOneConfigOnePropertiesOneItemLabelOneMax = 400

export const dashboardsUpdateWidgetsBatchBodyWidgetsItemOneConfigOnePropertiesOneItemValueOneItemOneMax = 4000

export const dashboardsUpdateWidgetsBatchBodyWidgetsItemOneConfigOnePropertiesOneItemValueOneMax = 100

export const dashboardsUpdateWidgetsBatchBodyWidgetsItemOneConfigOnePropertiesOneItemValueTwoMax = 4000

export const dashboardsUpdateWidgetsBatchBodyWidgetsItemOneConfigOnePropertiesOneMax = 20

export const dashboardsUpdateWidgetsBatchBodyWidgetsItemTwoNameMax = 400

export const dashboardsUpdateWidgetsBatchBodyWidgetsItemTwoConfigOneLimitDefault = 10
export const dashboardsUpdateWidgetsBatchBodyWidgetsItemTwoConfigOneLimitMax = 25

export const dashboardsUpdateWidgetsBatchBodyWidgetsItemTwoConfigOneOrderByDefault = `occurrences`
export const dashboardsUpdateWidgetsBatchBodyWidgetsItemTwoConfigOneOrderDirectionDefault = `DESC`
export const dashboardsUpdateWidgetsBatchBodyWidgetsItemTwoConfigOneStatusDefault = `active`
export const dashboardsUpdateWidgetsBatchBodyWidgetsItemThreeNameMax = 400

export const dashboardsUpdateWidgetsBatchBodyWidgetsItemThreeConfigOneLimitDefault = 10
export const dashboardsUpdateWidgetsBatchBodyWidgetsItemThreeConfigOneLimitMax = 25

export const dashboardsUpdateWidgetsBatchBodyWidgetsItemThreeConfigOneOrderByDefault = `start_time`
export const dashboardsUpdateWidgetsBatchBodyWidgetsItemThreeConfigOneOrderDirectionDefault = `DESC`
export const dashboardsUpdateWidgetsBatchBodyWidgetsItemFourNameMax = 400

export const dashboardsUpdateWidgetsBatchBodyWidgetsItemFourConfigOneLimitDefault = 10
export const dashboardsUpdateWidgetsBatchBodyWidgetsItemFourConfigOneLimitMax = 25

export const dashboardsUpdateWidgetsBatchBodyWidgetsItemFourConfigOneOrderByDefault = `created_at`
export const dashboardsUpdateWidgetsBatchBodyWidgetsItemFourConfigOneOrderDirectionDefault = `DESC`
export const dashboardsUpdateWidgetsBatchBodyWidgetsItemFourConfigOneStatusDefault = `all`
export const dashboardsUpdateWidgetsBatchBodyWidgetsItemFiveNameMax = 400

export const dashboardsUpdateWidgetsBatchBodyWidgetsItemSixNameMax = 400

export const dashboardsUpdateWidgetsBatchBodyWidgetsItemSixConfigOneLimitDefault = 10
export const dashboardsUpdateWidgetsBatchBodyWidgetsItemSixConfigOneLimitMax = 25

export const dashboardsUpdateWidgetsBatchBodyWidgetsItemSevenNameMax = 400

export const dashboardsUpdateWidgetsBatchBodyWidgetsItemSevenConfigOneLimitDefault = 50
export const dashboardsUpdateWidgetsBatchBodyWidgetsItemSevenConfigOneLimitMax = 100

export const dashboardsUpdateWidgetsBatchBodyWidgetsItemSevenConfigOneOrderByDefault = `latest`
export const dashboardsUpdateWidgetsBatchBodyWidgetsItemSevenConfigOneWrapLinesDefault = false
export const dashboardsUpdateWidgetsBatchBodyWidgetsItemSevenConfigOneTimezoneDefault = `UTC`
export const dashboardsUpdateWidgetsBatchBodyWidgetsItemEightNameMax = 400

export const dashboardsUpdateWidgetsBatchBodyWidgetsItemEightConfigOneLimitDefault = 10
export const dashboardsUpdateWidgetsBatchBodyWidgetsItemEightConfigOneLimitMax = 25

export const dashboardsUpdateWidgetsBatchBodyWidgetsItemEightConfigOneStatusDefault = `all`
export const dashboardsUpdateWidgetsBatchBodyWidgetsItemEightConfigOneChannelDefault = `all`
export const dashboardsUpdateWidgetsBatchBodyWidgetsItemEightConfigOneAssigneesMax = 100

export const dashboardsUpdateWidgetsBatchBodyWidgetsItemEightConfigOneSearchDefault = ``
export const dashboardsUpdateWidgetsBatchBodyWidgetsItemEightConfigOneSearchMax = 200

export const dashboardsUpdateWidgetsBatchBodyWidgetsItemEightConfigOneSavedViewIdOneMax = 12

export const dashboardsUpdateWidgetsBatchBodyWidgetsMax = 10

export const DashboardsUpdateWidgetsBatchBody = /* @__PURE__ */ zod
    .object({
        widgets: zod
            .array(
                zod.union([
                    zod.object({
                        tile_id: zod
                            .number()
                            .describe('ID of the widget tile to update. Use dashboard-get to look up widget tile IDs.'),
                        name: zod
                            .string()
                            .max(dashboardsUpdateWidgetsBatchBodyWidgetsItemOneNameMax)
                            .nullish()
                            .describe(
                                'New display name for the widget. Empty string or null clears it; omit to leave unchanged.'
                            ),
                        description: zod
                            .string()
                            .optional()
                            .describe('New markdown description for the widget. Omit to leave unchanged.'),
                        widget_type: zod.enum(['activity_events_list']),
                        config: zod
                            .object({
                                dateRange: zod
                                    .union([
                                        zod.object({
                                            date_from: zod
                                                .union([
                                                    zod.enum([
                                                        '-1M',
                                                        '-30M',
                                                        '-1h',
                                                        '-3h',
                                                        '-24h',
                                                        '-7d',
                                                        '-14d',
                                                        '-30d',
                                                        '-90d',
                                                    ]),
                                                    zod.null(),
                                                ])
                                                .optional(),
                                        }),
                                        zod.null(),
                                    ])
                                    .optional(),
                                filterTestAccounts: zod.union([zod.boolean(), zod.null()]).optional(),
                                widgetFilters: zod
                                    .union([
                                        zod.record(
                                            zod.string(),
                                            zod.object({
                                                filterId: zod.string().min(1),
                                                propertyName: zod.string().min(1),
                                                optionId: zod.string().min(1),
                                                operator: zod.enum([
                                                    'exact',
                                                    'is_not',
                                                    'icontains',
                                                    'not_icontains',
                                                    'starts_with',
                                                    'not_starts_with',
                                                    'ends_with',
                                                    'not_ends_with',
                                                    'regex',
                                                    'not_regex',
                                                    'gt',
                                                    'gte',
                                                    'lt',
                                                    'lte',
                                                    'is_set',
                                                    'is_not_set',
                                                    'is_date_exact',
                                                    'is_date_before',
                                                    'is_date_after',
                                                    'between',
                                                    'not_between',
                                                    'min',
                                                    'max',
                                                    'in',
                                                    'not_in',
                                                    'is_cleaned_path_exact',
                                                    'flag_evaluates_to',
                                                    'semver_eq',
                                                    'semver_neq',
                                                    'semver_gt',
                                                    'semver_gte',
                                                    'semver_lt',
                                                    'semver_lte',
                                                    'semver_tilde',
                                                    'semver_caret',
                                                    'semver_wildcard',
                                                    'icontains_multi',
                                                    'not_icontains_multi',
                                                ]),
                                                value: zod
                                                    .union([zod.string(), zod.array(zod.string()), zod.null()])
                                                    .optional(),
                                            })
                                        ),
                                        zod.null(),
                                    ])
                                    .optional(),
                                limit: zod
                                    .number()
                                    .min(1)
                                    .max(dashboardsUpdateWidgetsBatchBodyWidgetsItemOneConfigOneLimitMax)
                                    .default(dashboardsUpdateWidgetsBatchBodyWidgetsItemOneConfigOneLimitDefault)
                                    .describe('Maximum number of events to return.'),
                                eventName: zod
                                    .union([zod.string().min(1), zod.null()])
                                    .optional()
                                    .describe('Limit the feed to a single event name. Omit or null for all events.'),
                                properties: zod
                                    .union([
                                        zod
                                            .array(
                                                zod.object({
                                                    key: zod
                                                        .string()
                                                        .min(1)
                                                        .max(
                                                            dashboardsUpdateWidgetsBatchBodyWidgetsItemOneConfigOnePropertiesOneItemKeyMax
                                                        ),
                                                    label: zod
                                                        .union([
                                                            zod
                                                                .string()
                                                                .max(
                                                                    dashboardsUpdateWidgetsBatchBodyWidgetsItemOneConfigOnePropertiesOneItemLabelOneMax
                                                                ),
                                                            zod.null(),
                                                        ])
                                                        .optional(),
                                                    operator: zod.enum([
                                                        'exact',
                                                        'is_not',
                                                        'icontains',
                                                        'not_icontains',
                                                        'starts_with',
                                                        'not_starts_with',
                                                        'ends_with',
                                                        'not_ends_with',
                                                        'regex',
                                                        'not_regex',
                                                        'gt',
                                                        'gte',
                                                        'lt',
                                                        'lte',
                                                        'is_set',
                                                        'is_not_set',
                                                        'is_date_exact',
                                                        'is_date_before',
                                                        'is_date_after',
                                                        'between',
                                                        'not_between',
                                                        'min',
                                                        'max',
                                                        'in',
                                                        'not_in',
                                                        'is_cleaned_path_exact',
                                                        'flag_evaluates_to',
                                                        'semver_eq',
                                                        'semver_neq',
                                                        'semver_gt',
                                                        'semver_gte',
                                                        'semver_lt',
                                                        'semver_lte',
                                                        'semver_tilde',
                                                        'semver_caret',
                                                        'semver_wildcard',
                                                        'icontains_multi',
                                                        'not_icontains_multi',
                                                    ]),
                                                    type: zod.enum(['event', 'person']),
                                                    value: zod
                                                        .union([
                                                            zod
                                                                .array(
                                                                    zod.union([
                                                                        zod
                                                                            .string()
                                                                            .max(
                                                                                dashboardsUpdateWidgetsBatchBodyWidgetsItemOneConfigOnePropertiesOneItemValueOneItemOneMax
                                                                            ),
                                                                        zod.number(),
                                                                        zod.boolean(),
                                                                    ])
                                                                )
                                                                .max(
                                                                    dashboardsUpdateWidgetsBatchBodyWidgetsItemOneConfigOnePropertiesOneItemValueOneMax
                                                                ),
                                                            zod
                                                                .string()
                                                                .max(
                                                                    dashboardsUpdateWidgetsBatchBodyWidgetsItemOneConfigOnePropertiesOneItemValueTwoMax
                                                                ),
                                                            zod.number(),
                                                            zod.boolean(),
                                                            zod.null(),
                                                        ])
                                                        .optional(),
                                                })
                                            )
                                            .max(
                                                dashboardsUpdateWidgetsBatchBodyWidgetsItemOneConfigOnePropertiesOneMax
                                            ),
                                        zod.null(),
                                    ])
                                    .optional()
                                    .describe('Event and person property filters, matching Activity > Explore events.'),
                            })
                            .optional()
                            .describe('New configuration for the recent events widget. Omit to leave unchanged.'),
                    }),
                    zod.object({
                        tile_id: zod
                            .number()
                            .describe('ID of the widget tile to update. Use dashboard-get to look up widget tile IDs.'),
                        name: zod
                            .string()
                            .max(dashboardsUpdateWidgetsBatchBodyWidgetsItemTwoNameMax)
                            .nullish()
                            .describe(
                                'New display name for the widget. Empty string or null clears it; omit to leave unchanged.'
                            ),
                        description: zod
                            .string()
                            .optional()
                            .describe('New markdown description for the widget. Omit to leave unchanged.'),
                        widget_type: zod.enum(['error_tracking_list']),
                        config: zod
                            .object({
                                dateRange: zod
                                    .union([
                                        zod.object({
                                            date_from: zod
                                                .union([
                                                    zod.enum([
                                                        '-1M',
                                                        '-30M',
                                                        '-1h',
                                                        '-3h',
                                                        '-24h',
                                                        '-7d',
                                                        '-14d',
                                                        '-30d',
                                                        '-90d',
                                                    ]),
                                                    zod.null(),
                                                ])
                                                .optional(),
                                        }),
                                        zod.null(),
                                    ])
                                    .optional(),
                                filterTestAccounts: zod.union([zod.boolean(), zod.null()]).optional(),
                                widgetFilters: zod
                                    .union([
                                        zod.record(
                                            zod.string(),
                                            zod.object({
                                                filterId: zod.string().min(1),
                                                propertyName: zod.string().min(1),
                                                optionId: zod.string().min(1),
                                                operator: zod.enum([
                                                    'exact',
                                                    'is_not',
                                                    'icontains',
                                                    'not_icontains',
                                                    'starts_with',
                                                    'not_starts_with',
                                                    'ends_with',
                                                    'not_ends_with',
                                                    'regex',
                                                    'not_regex',
                                                    'gt',
                                                    'gte',
                                                    'lt',
                                                    'lte',
                                                    'is_set',
                                                    'is_not_set',
                                                    'is_date_exact',
                                                    'is_date_before',
                                                    'is_date_after',
                                                    'between',
                                                    'not_between',
                                                    'min',
                                                    'max',
                                                    'in',
                                                    'not_in',
                                                    'is_cleaned_path_exact',
                                                    'flag_evaluates_to',
                                                    'semver_eq',
                                                    'semver_neq',
                                                    'semver_gt',
                                                    'semver_gte',
                                                    'semver_lt',
                                                    'semver_lte',
                                                    'semver_tilde',
                                                    'semver_caret',
                                                    'semver_wildcard',
                                                    'icontains_multi',
                                                    'not_icontains_multi',
                                                ]),
                                                value: zod
                                                    .union([zod.string(), zod.array(zod.string()), zod.null()])
                                                    .optional(),
                                            })
                                        ),
                                        zod.null(),
                                    ])
                                    .optional(),
                                limit: zod
                                    .number()
                                    .min(1)
                                    .max(dashboardsUpdateWidgetsBatchBodyWidgetsItemTwoConfigOneLimitMax)
                                    .default(dashboardsUpdateWidgetsBatchBodyWidgetsItemTwoConfigOneLimitDefault)
                                    .describe('Maximum number of issues to return.'),
                                orderBy: zod
                                    .enum(['last_seen', 'first_seen', 'occurrences', 'users', 'sessions'])
                                    .default(dashboardsUpdateWidgetsBatchBodyWidgetsItemTwoConfigOneOrderByDefault)
                                    .describe('Issue ranking column.'),
                                orderDirection: zod
                                    .enum(['ASC', 'DESC'])
                                    .default(
                                        dashboardsUpdateWidgetsBatchBodyWidgetsItemTwoConfigOneOrderDirectionDefault
                                    )
                                    .describe('Sort direction for orderBy.'),
                                status: zod
                                    .enum(['archived', 'active', 'resolved', 'pending_release', 'suppressed', 'all'])
                                    .default(dashboardsUpdateWidgetsBatchBodyWidgetsItemTwoConfigOneStatusDefault)
                                    .describe('Issue status filter.'),
                                assignee: zod
                                    .union([
                                        zod.object({
                                            id: zod.union([zod.string(), zod.number()]),
                                            type: zod.enum(['user', 'role']),
                                        }),
                                        zod.null(),
                                    ])
                                    .optional()
                                    .describe('Filter by assignee ({type: user|role, id}). Omit for any assignee.'),
                            })
                            .optional()
                            .describe('New configuration for the top issues widget. Omit to leave unchanged.'),
                    }),
                    zod.object({
                        tile_id: zod
                            .number()
                            .describe('ID of the widget tile to update. Use dashboard-get to look up widget tile IDs.'),
                        name: zod
                            .string()
                            .max(dashboardsUpdateWidgetsBatchBodyWidgetsItemThreeNameMax)
                            .nullish()
                            .describe(
                                'New display name for the widget. Empty string or null clears it; omit to leave unchanged.'
                            ),
                        description: zod
                            .string()
                            .optional()
                            .describe('New markdown description for the widget. Omit to leave unchanged.'),
                        widget_type: zod.enum(['session_replay_list']),
                        config: zod
                            .object({
                                dateRange: zod
                                    .union([
                                        zod.object({
                                            date_from: zod
                                                .union([
                                                    zod.enum([
                                                        '-1M',
                                                        '-30M',
                                                        '-1h',
                                                        '-3h',
                                                        '-24h',
                                                        '-7d',
                                                        '-14d',
                                                        '-30d',
                                                        '-90d',
                                                    ]),
                                                    zod.null(),
                                                ])
                                                .optional(),
                                        }),
                                        zod.null(),
                                    ])
                                    .optional(),
                                filterTestAccounts: zod.union([zod.boolean(), zod.null()]).optional(),
                                widgetFilters: zod
                                    .union([
                                        zod.record(
                                            zod.string(),
                                            zod.object({
                                                filterId: zod.string().min(1),
                                                propertyName: zod.string().min(1),
                                                optionId: zod.string().min(1),
                                                operator: zod.enum([
                                                    'exact',
                                                    'is_not',
                                                    'icontains',
                                                    'not_icontains',
                                                    'starts_with',
                                                    'not_starts_with',
                                                    'ends_with',
                                                    'not_ends_with',
                                                    'regex',
                                                    'not_regex',
                                                    'gt',
                                                    'gte',
                                                    'lt',
                                                    'lte',
                                                    'is_set',
                                                    'is_not_set',
                                                    'is_date_exact',
                                                    'is_date_before',
                                                    'is_date_after',
                                                    'between',
                                                    'not_between',
                                                    'min',
                                                    'max',
                                                    'in',
                                                    'not_in',
                                                    'is_cleaned_path_exact',
                                                    'flag_evaluates_to',
                                                    'semver_eq',
                                                    'semver_neq',
                                                    'semver_gt',
                                                    'semver_gte',
                                                    'semver_lt',
                                                    'semver_lte',
                                                    'semver_tilde',
                                                    'semver_caret',
                                                    'semver_wildcard',
                                                    'icontains_multi',
                                                    'not_icontains_multi',
                                                ]),
                                                value: zod
                                                    .union([zod.string(), zod.array(zod.string()), zod.null()])
                                                    .optional(),
                                            })
                                        ),
                                        zod.null(),
                                    ])
                                    .optional(),
                                limit: zod
                                    .number()
                                    .min(1)
                                    .max(dashboardsUpdateWidgetsBatchBodyWidgetsItemThreeConfigOneLimitMax)
                                    .default(dashboardsUpdateWidgetsBatchBodyWidgetsItemThreeConfigOneLimitDefault)
                                    .describe('Maximum number of recordings to return.'),
                                orderBy: zod
                                    .enum([
                                        'start_time',
                                        'activity_score',
                                        'recording_duration',
                                        'duration',
                                        'click_count',
                                        'console_error_count',
                                    ])
                                    .default(dashboardsUpdateWidgetsBatchBodyWidgetsItemThreeConfigOneOrderByDefault)
                                    .describe('Recording ranking column.'),
                                orderDirection: zod
                                    .enum(['ASC', 'DESC'])
                                    .default(
                                        dashboardsUpdateWidgetsBatchBodyWidgetsItemThreeConfigOneOrderDirectionDefault
                                    )
                                    .describe('Sort direction for orderBy.'),
                                savedFilterId: zod
                                    .union([zod.string(), zod.null()])
                                    .optional()
                                    .describe(
                                        'short_id of a saved session replay filter to refine the recordings shown. When set, the saved filter owns the date range and property filters; only orderBy, orderDirection, and limit still apply. Combine with collectionId to filter within a collection.'
                                    ),
                                collectionId: zod
                                    .union([zod.string(), zod.null()])
                                    .optional()
                                    .describe(
                                        'short_id of a session replay collection to scope the widget to its pinned recordings. Combine with savedFilterId or property filters to narrow within the collection; orderBy, orderDirection, and limit still apply.'
                                    ),
                            })
                            .optional()
                            .describe('New configuration for the recent recordings widget. Omit to leave unchanged.'),
                    }),
                    zod.object({
                        tile_id: zod
                            .number()
                            .describe('ID of the widget tile to update. Use dashboard-get to look up widget tile IDs.'),
                        name: zod
                            .string()
                            .max(dashboardsUpdateWidgetsBatchBodyWidgetsItemFourNameMax)
                            .nullish()
                            .describe(
                                'New display name for the widget. Empty string or null clears it; omit to leave unchanged.'
                            ),
                        description: zod
                            .string()
                            .optional()
                            .describe('New markdown description for the widget. Omit to leave unchanged.'),
                        widget_type: zod.enum(['experiments_list']),
                        config: zod
                            .object({
                                limit: zod
                                    .number()
                                    .min(1)
                                    .max(dashboardsUpdateWidgetsBatchBodyWidgetsItemFourConfigOneLimitMax)
                                    .default(dashboardsUpdateWidgetsBatchBodyWidgetsItemFourConfigOneLimitDefault)
                                    .describe('Maximum number of experiments to return.'),
                                orderBy: zod
                                    .enum(['created_at', 'name', 'start_date'])
                                    .default(dashboardsUpdateWidgetsBatchBodyWidgetsItemFourConfigOneOrderByDefault)
                                    .describe('Experiment list sort column.'),
                                orderDirection: zod
                                    .enum(['ASC', 'DESC'])
                                    .default(
                                        dashboardsUpdateWidgetsBatchBodyWidgetsItemFourConfigOneOrderDirectionDefault
                                    )
                                    .describe('Sort direction for orderBy.'),
                                status: zod
                                    .enum(['draft', 'running', 'paused', 'exposure_frozen', 'stopped', 'all'])
                                    .default(dashboardsUpdateWidgetsBatchBodyWidgetsItemFourConfigOneStatusDefault)
                                    .describe('Experiment status filter.'),
                                createdBy: zod
                                    .union([zod.number(), zod.null()])
                                    .optional()
                                    .describe('Filter by creator (user id). Omit for any creator.'),
                            })
                            .optional()
                            .describe('New configuration for the experiments list widget. Omit to leave unchanged.'),
                    }),
                    zod.object({
                        tile_id: zod
                            .number()
                            .describe('ID of the widget tile to update. Use dashboard-get to look up widget tile IDs.'),
                        name: zod
                            .string()
                            .max(dashboardsUpdateWidgetsBatchBodyWidgetsItemFiveNameMax)
                            .nullish()
                            .describe(
                                'New display name for the widget. Empty string or null clears it; omit to leave unchanged.'
                            ),
                        description: zod
                            .string()
                            .optional()
                            .describe('New markdown description for the widget. Omit to leave unchanged.'),
                        widget_type: zod.enum(['experiment_results']),
                        config: zod
                            .object({
                                experimentId: zod
                                    .union([zod.number(), zod.null()])
                                    .optional()
                                    .describe(
                                        'Experiment to show results for. Null until the user picks one in the widget settings.'
                                    ),
                            })
                            .optional()
                            .describe('New configuration for the experiment results widget. Omit to leave unchanged.'),
                    }),
                    zod.object({
                        tile_id: zod
                            .number()
                            .describe('ID of the widget tile to update. Use dashboard-get to look up widget tile IDs.'),
                        name: zod
                            .string()
                            .max(dashboardsUpdateWidgetsBatchBodyWidgetsItemSixNameMax)
                            .nullish()
                            .describe(
                                'New display name for the widget. Empty string or null clears it; omit to leave unchanged.'
                            ),
                        description: zod
                            .string()
                            .optional()
                            .describe('New markdown description for the widget. Omit to leave unchanged.'),
                        widget_type: zod.enum(['survey_results']),
                        config: zod
                            .object({
                                dateRange: zod
                                    .union([
                                        zod.object({
                                            date_from: zod
                                                .union([
                                                    zod.enum([
                                                        '-1M',
                                                        '-30M',
                                                        '-1h',
                                                        '-3h',
                                                        '-24h',
                                                        '-7d',
                                                        '-14d',
                                                        '-30d',
                                                        '-90d',
                                                    ]),
                                                    zod.null(),
                                                ])
                                                .optional(),
                                        }),
                                        zod.null(),
                                    ])
                                    .optional()
                                    .describe("Null or omitted means all time (the survey's full lifetime)."),
                                surveyId: zod
                                    .union([zod.string(), zod.null()])
                                    .optional()
                                    .describe(
                                        'Survey to show performance stats and recent responses for. Null until the user picks one.'
                                    ),
                                limit: zod
                                    .number()
                                    .min(1)
                                    .max(dashboardsUpdateWidgetsBatchBodyWidgetsItemSixConfigOneLimitMax)
                                    .default(dashboardsUpdateWidgetsBatchBodyWidgetsItemSixConfigOneLimitDefault)
                                    .describe('Maximum number of recent responses to return.'),
                            })
                            .optional()
                            .describe('New configuration for the survey results widget. Omit to leave unchanged.'),
                    }),
                    zod.object({
                        tile_id: zod
                            .number()
                            .describe('ID of the widget tile to update. Use dashboard-get to look up widget tile IDs.'),
                        name: zod
                            .string()
                            .max(dashboardsUpdateWidgetsBatchBodyWidgetsItemSevenNameMax)
                            .nullish()
                            .describe(
                                'New display name for the widget. Empty string or null clears it; omit to leave unchanged.'
                            ),
                        description: zod
                            .string()
                            .optional()
                            .describe('New markdown description for the widget. Omit to leave unchanged.'),
                        widget_type: zod.enum(['logs_list']),
                        config: zod
                            .object({
                                dateRange: zod
                                    .union([
                                        zod.object({
                                            date_from: zod
                                                .union([
                                                    zod.enum([
                                                        '-1M',
                                                        '-30M',
                                                        '-1h',
                                                        '-3h',
                                                        '-24h',
                                                        '-7d',
                                                        '-14d',
                                                        '-30d',
                                                        '-90d',
                                                    ]),
                                                    zod.null(),
                                                ])
                                                .optional(),
                                        }),
                                        zod.null(),
                                    ])
                                    .optional(),
                                limit: zod
                                    .number()
                                    .min(1)
                                    .max(dashboardsUpdateWidgetsBatchBodyWidgetsItemSevenConfigOneLimitMax)
                                    .default(dashboardsUpdateWidgetsBatchBodyWidgetsItemSevenConfigOneLimitDefault)
                                    .describe('Maximum number of log lines to return.'),
                                orderBy: zod
                                    .enum(['latest', 'earliest'])
                                    .default(dashboardsUpdateWidgetsBatchBodyWidgetsItemSevenConfigOneOrderByDefault)
                                    .describe('Sort by newest (latest) or oldest (earliest) first.'),
                                severityLevels: zod
                                    .array(zod.enum(['trace', 'debug', 'info', 'warn', 'error', 'fatal']))
                                    .optional()
                                    .describe('Only show logs at these severity levels. Empty shows all levels.'),
                                serviceNames: zod
                                    .array(zod.string())
                                    .optional()
                                    .describe('Only show logs from these services. Empty shows all services.'),
                                wrapLines: zod
                                    .boolean()
                                    .default(dashboardsUpdateWidgetsBatchBodyWidgetsItemSevenConfigOneWrapLinesDefault)
                                    .describe('Wrap long log lines instead of truncating them to a single row.'),
                                timezone: zod
                                    .enum(['UTC', 'local'])
                                    .default(dashboardsUpdateWidgetsBatchBodyWidgetsItemSevenConfigOneTimezoneDefault)
                                    .describe("Render log timestamps in UTC or in each viewer's local timezone."),
                                savedViewId: zod
                                    .union([zod.string(), zod.null()])
                                    .optional()
                                    .describe(
                                        'short_id of a saved logs view to use as the source. When set, the saved view owns the date range, severity, service, and property filters; only orderBy and limit still apply.'
                                    ),
                            })
                            .optional()
                            .describe('New configuration for the recent logs widget. Omit to leave unchanged.'),
                    }),
                    zod.object({
                        tile_id: zod
                            .number()
                            .describe('ID of the widget tile to update. Use dashboard-get to look up widget tile IDs.'),
                        name: zod
                            .string()
                            .max(dashboardsUpdateWidgetsBatchBodyWidgetsItemEightNameMax)
                            .nullish()
                            .describe(
                                'New display name for the widget. Empty string or null clears it; omit to leave unchanged.'
                            ),
                        description: zod
                            .string()
                            .optional()
                            .describe('New markdown description for the widget. Omit to leave unchanged.'),
                        widget_type: zod.enum(['conversations_recent_tickets']),
                        config: zod
                            .object({
                                limit: zod
                                    .number()
                                    .min(1)
                                    .max(dashboardsUpdateWidgetsBatchBodyWidgetsItemEightConfigOneLimitMax)
                                    .default(dashboardsUpdateWidgetsBatchBodyWidgetsItemEightConfigOneLimitDefault)
                                    .describe('Maximum number of tickets to return.'),
                                status: zod
                                    .enum(['new', 'open', 'pending', 'on_hold', 'resolved', 'all'])
                                    .default(dashboardsUpdateWidgetsBatchBodyWidgetsItemEightConfigOneStatusDefault)
                                    .describe('Ticket status filter.'),
                                priorities: zod
                                    .array(zod.enum(['low', 'medium', 'high', 'critical']))
                                    .optional()
                                    .describe('Only show tickets with these priorities. Empty shows all priorities.'),
                                channel: zod
                                    .enum(['widget', 'email', 'slack', 'teams', 'github', 'all'])
                                    .default(dashboardsUpdateWidgetsBatchBodyWidgetsItemEightConfigOneChannelDefault)
                                    .describe('Ticket channel filter.'),
                                assignees: zod
                                    .array(
                                        zod.union([
                                            zod.enum(['me', 'unassigned']),
                                            zod.object({
                                                id: zod.union([zod.string(), zod.number()]),
                                                type: zod.enum(['user', 'role']),
                                            }),
                                        ])
                                    )
                                    .max(dashboardsUpdateWidgetsBatchBodyWidgetsItemEightConfigOneAssigneesMax)
                                    .optional()
                                    .describe(
                                        "Only show tickets assigned to these users or roles. 'me' means the requesting user and 'unassigned' means tickets without an assignment. Empty shows all assignees."
                                    ),
                                search: zod
                                    .string()
                                    .max(dashboardsUpdateWidgetsBatchBodyWidgetsItemEightConfigOneSearchMax)
                                    .default(dashboardsUpdateWidgetsBatchBodyWidgetsItemEightConfigOneSearchDefault)
                                    .describe(
                                        'Search requester name or email, ticket subject, message text, or ticket number.'
                                    ),
                                savedViewId: zod
                                    .union([
                                        zod
                                            .string()
                                            .max(
                                                dashboardsUpdateWidgetsBatchBodyWidgetsItemEightConfigOneSavedViewIdOneMax
                                            ),
                                        zod.null(),
                                    ])
                                    .optional()
                                    .describe(
                                        'short_id of a saved Support view to use as the source. When set, the saved view owns the ticket filters; the widget still sorts by most recently updated and applies its limit.'
                                    ),
                            })
                            .optional()
                            .describe('New configuration for the recent tickets widget. Omit to leave unchanged.'),
                    }),
                ])
            )
            .min(1)
            .max(dashboardsUpdateWidgetsBatchBodyWidgetsMax)
            .optional()
            .describe(
                'Widget tiles to update atomically, each identified by its tile_id. config shape is per widget_type; see dashboard-widget-catalog-list for per-type config_schema (1–10 per request).'
            ),
    })
    .describe('OpenAPI-only batch-update schema with widget_type-discriminated config shapes for agents.')

/**
 * Bulk update tags on multiple objects.
 *
 * PAT access: this action has no ``required_scopes=`` on the decorator —
 * inheriting viewsets must add ``"bulk_update_tags"`` to their
 * ``scope_object_write_actions`` list to accept personal API keys.
 * Without that opt-in, ``APIScopePermission`` rejects PAT requests with
 * "This action does not support personal API key access". Done per-viewset
 * so granting ``<scope>:write`` for one resource doesn't leak access to
 * sibling resources that share this mixin.
 *
 * Accepts:
 * - {"ids": [...], "action": "add"|"remove"|"set", "tags": ["tag1", "tag2"]}
 *
 * Actions:
 * - "add": Add tags to existing tags on each object
 * - "remove": Remove specific tags from each object
 * - "set": Replace all tags on each object with the provided list
 */
export const dashboardsBulkUpdateTagsCreateBodyIdsMax = 500

export const DashboardsBulkUpdateTagsCreateBody = /* @__PURE__ */ zod.object({
    ids: zod
        .array(zod.number())
        .max(dashboardsBulkUpdateTagsCreateBodyIdsMax)
        .describe('List of object IDs to update tags on.'),
    action: zod
        .enum(['add', 'remove', 'set'])
        .describe('\* `add` - add\n\* `remove` - remove\n\* `set` - set')
        .describe(
            "'add' merges with existing tags, 'remove' deletes specific tags, 'set' replaces all tags.\n\n\* `add` - add\n\* `remove` - remove\n\* `set` - set"
        ),
    tags: zod.array(zod.string()).describe('Tag names to add, remove, or set.'),
})

export const dashboardsCreateFromTemplateJsonCreateBodyNameMax = 400

export const dashboardsCreateFromTemplateJsonCreateBodyDeleteInsightsDefault = false

export const DashboardsCreateFromTemplateJsonCreateBody = /* @__PURE__ */ zod
    .object({
        name: zod.string().max(dashboardsCreateFromTemplateJsonCreateBodyNameMax).nullish(),
        description: zod.string().optional(),
        pinned: zod.boolean().optional(),
        last_accessed_at: zod.iso.datetime({ offset: true }).nullish(),
        deleted: zod.boolean().optional(),
        breakdown_colors: zod.unknown().optional().describe('Custom color mapping for breakdown values.'),
        data_color_theme_id: zod.number().nullish().describe('ID of the color theme used for chart visualizations.'),
        tags: zod.array(zod.unknown()).optional(),
        restriction_level: zod
            .union([zod.literal(21), zod.literal(37)])
            .optional()
            .describe(
                '\* `21` - Everyone in the project can edit\n\* `37` - Only those invited to this dashboard can edit'
            ),
        last_refresh: zod.iso.datetime({ offset: true }).nullish(),
        quick_filter_ids: zod
            .array(zod.string())
            .nullish()
            .describe('List of quick filter IDs associated with this dashboard'),
        grid_spacing: zod
            .enum(['tight', 'condensed', 'standard', 'relaxed', 'wide'])
            .describe(
                '\* `tight` - tight\n\* `condensed` - condensed\n\* `standard` - standard\n\* `relaxed` - relaxed\n\* `wide` - wide'
            )
            .optional()
            .describe(
                'Named tile density preset. Use tight, condensed, standard, relaxed, or wide.\n\n\* `tight` - tight\n\* `condensed` - condensed\n\* `standard` - standard\n\* `relaxed` - relaxed\n\* `wide` - wide'
            ),
        layout_compaction: zod
            .enum(['vertical', 'horizontal', 'stable'])
            .describe('\* `vertical` - vertical\n\* `horizontal` - horizontal\n\* `stable` - stable')
            .optional()
            .describe(
                'How tiles rearrange after a move or resize. vertical stacks tiles upward, horizontal stacks tiles to the left, and stable preserves positions while moving colliding tiles.\n\n\* `vertical` - vertical\n\* `horizontal` - horizontal\n\* `stable` - stable'
            ),
        use_template: zod
            .string()
            .optional()
            .describe('Template key to create the dashboard from a predefined template.'),
        use_dashboard: zod.number().nullish().describe('ID of an existing dashboard to duplicate.'),
        delete_insights: zod
            .boolean()
            .default(dashboardsCreateFromTemplateJsonCreateBodyDeleteInsightsDefault)
            .describe('When deleting, also delete insights that are only on this dashboard.'),
        _create_in_folder: zod.string().optional(),
    })
    .describe('Serializer mixin that handles tags for objects.')

/**
 * Creates an unlisted dashboard from template by tag.
 * Enforces uniqueness (one per tag per team).
 * Returns 409 if unlisted dashboard with this tag already exists.
 */
export const dashboardsCreateUnlistedDashboardCreateBodyNameMax = 400

export const dashboardsCreateUnlistedDashboardCreateBodyDeleteInsightsDefault = false

export const DashboardsCreateUnlistedDashboardCreateBody = /* @__PURE__ */ zod
    .object({
        name: zod.string().max(dashboardsCreateUnlistedDashboardCreateBodyNameMax).nullish(),
        description: zod.string().optional(),
        pinned: zod.boolean().optional(),
        last_accessed_at: zod.iso.datetime({ offset: true }).nullish(),
        deleted: zod.boolean().optional(),
        breakdown_colors: zod.unknown().optional().describe('Custom color mapping for breakdown values.'),
        data_color_theme_id: zod.number().nullish().describe('ID of the color theme used for chart visualizations.'),
        tags: zod.array(zod.unknown()).optional(),
        restriction_level: zod
            .union([zod.literal(21), zod.literal(37)])
            .optional()
            .describe(
                '\* `21` - Everyone in the project can edit\n\* `37` - Only those invited to this dashboard can edit'
            ),
        last_refresh: zod.iso.datetime({ offset: true }).nullish(),
        quick_filter_ids: zod
            .array(zod.string())
            .nullish()
            .describe('List of quick filter IDs associated with this dashboard'),
        grid_spacing: zod
            .enum(['tight', 'condensed', 'standard', 'relaxed', 'wide'])
            .describe(
                '\* `tight` - tight\n\* `condensed` - condensed\n\* `standard` - standard\n\* `relaxed` - relaxed\n\* `wide` - wide'
            )
            .optional()
            .describe(
                'Named tile density preset. Use tight, condensed, standard, relaxed, or wide.\n\n\* `tight` - tight\n\* `condensed` - condensed\n\* `standard` - standard\n\* `relaxed` - relaxed\n\* `wide` - wide'
            ),
        layout_compaction: zod
            .enum(['vertical', 'horizontal', 'stable'])
            .describe('\* `vertical` - vertical\n\* `horizontal` - horizontal\n\* `stable` - stable')
            .optional()
            .describe(
                'How tiles rearrange after a move or resize. vertical stacks tiles upward, horizontal stacks tiles to the left, and stable preserves positions while moving colliding tiles.\n\n\* `vertical` - vertical\n\* `horizontal` - horizontal\n\* `stable` - stable'
            ),
        use_template: zod
            .string()
            .optional()
            .describe('Template key to create the dashboard from a predefined template.'),
        use_dashboard: zod.number().nullish().describe('ID of an existing dashboard to duplicate.'),
        delete_insights: zod
            .boolean()
            .default(dashboardsCreateUnlistedDashboardCreateBodyDeleteInsightsDefault)
            .describe('When deleting, also delete insights that are only on this dashboard.'),
        _create_in_folder: zod.string().optional(),
    })
    .describe('Serializer mixin that handles tags for objects.')

export const dataColorThemesCreateBodyNameMax = 100

export const DataColorThemesCreateBody = /* @__PURE__ */ zod.object({
    name: zod.string().max(dataColorThemesCreateBodyNameMax),
    colors: zod.unknown().optional(),
})

export const dataColorThemesUpdateBodyNameMax = 100

export const DataColorThemesUpdateBody = /* @__PURE__ */ zod.object({
    name: zod.string().max(dataColorThemesUpdateBodyNameMax),
    colors: zod.unknown().optional(),
})

export const dataColorThemesPartialUpdateBodyNameMax = 100

export const DataColorThemesPartialUpdateBody = /* @__PURE__ */ zod.object({
    name: zod.string().max(dataColorThemesPartialUpdateBodyNameMax).optional(),
    colors: zod.unknown().optional(),
})
