import { buildYTickFormatter } from '@posthog/quill-charts'

import { AggregationAxisFormat } from 'scenes/insights/aggregationAxisFormat'

import { CurrencyCode, TrendsFilter } from '~/queries/schema/schema-general'

import { buildTrendsYAxisConfig, trendsFilterToYFormatterConfig } from './trendsAxisFormat'

const NBSP = ' '

describe('trendsFilterToYFormatterConfig', () => {
    it.each<AggregationAxisFormat>([
        'numeric',
        'duration',
        'duration_ms',
        'percentage',
        'percentage_scaled',
        'currency',
        'short',
    ])('passes aggregationAxisFormat=%s through to format', (aggregationAxisFormat) => {
        expect(trendsFilterToYFormatterConfig({ aggregationAxisFormat }, false).format).toBe(aggregationAxisFormat)
    })

    it('maps aggregationAxis* fields onto the generic config', () => {
        const trendsFilter: TrendsFilter = {
            aggregationAxisFormat: 'duration',
            aggregationAxisPrefix: '~',
            aggregationAxisPostfix: '!',
            decimalPlaces: 2,
            minDecimalPlaces: 1,
        }
        expect(trendsFilterToYFormatterConfig(trendsFilter, false, 'USD' as CurrencyCode)).toEqual({
            format: 'duration',
            prefix: '~',
            suffix: '!',
            decimalPlaces: 2,
            minDecimalPlaces: 1,
            currency: 'USD',
        })
    })

    it.each<[string, TrendsFilter | null]>([
        ['empty filter', {}],
        ['null filter', null],
    ])('defaults format to numeric for %s', (_, trendsFilter) => {
        expect(trendsFilterToYFormatterConfig(trendsFilter, false)).toEqual({ format: 'numeric' })
    })

    it('returns a percentage_scaled config when isPercentStackView is true, ignoring the trends filter', () => {
        // BarChart percent layout puts the value scale on 0..1, so we use the 0..1 formatter
        // (`percentage_scaled`) instead of the 0..100 `percentage` formatter.
        const trendsFilter: TrendsFilter = { aggregationAxisFormat: 'currency', aggregationAxisPrefix: '$' }
        expect(trendsFilterToYFormatterConfig(trendsFilter, true, 'USD' as CurrencyCode)).toEqual({
            format: 'percentage_scaled',
        })
    })
})

describe('trends y-tick formatter end-to-end', () => {
    it.each<[string, TrendsFilter, number, string]>([
        ['numeric', { aggregationAxisFormat: 'numeric' }, 1234, '1,234'],
        ['percentage', { aggregationAxisFormat: 'percentage' }, 50, '50%'],
        ['duration', { aggregationAxisFormat: 'duration' }, 90, `1m${NBSP}30s`],
        [
            'prefix + suffix',
            { aggregationAxisFormat: 'numeric', aggregationAxisPrefix: '~', aggregationAxisPostfix: '!' },
            7,
            '~7!',
        ],
    ])('formats %s through the trends → hog-charts pipeline', (_, trendsFilter, value, expected) => {
        const fmt = buildYTickFormatter(trendsFilterToYFormatterConfig(trendsFilter, false))
        expect(fmt(value)).toBe(expected)
    })

    it('formats percent-stack values regardless of the underlying trends filter', () => {
        // Input is a 0..1 fraction (d3's percent scale), so 0.5 → "50%".
        const trendsFilter: TrendsFilter = { aggregationAxisFormat: 'currency' }
        const fmt = buildYTickFormatter(trendsFilterToYFormatterConfig(trendsFilter, true, 'USD' as CurrencyCode))
        expect(fmt(0.5)).toBe('50%')
    })
})

describe('buildTrendsYAxisConfig', () => {
    it.each([
        ['log10', 'log'],
        ['linear', 'linear'],
        ['auto', 'linear'],
        [undefined, 'linear'],
        [null, 'linear'],
    ] as const)('translates yAxisScaleType "%s" to scale "%s"', (input, expected) => {
        expect(buildTrendsYAxisConfig(null, false, undefined, { yAxisScaleType: input }).scale).toBe(expected)
    })

    it('passes showGrid through from extras', () => {
        expect(buildTrendsYAxisConfig(null, false, undefined, { showGrid: true }).showGrid).toBe(true)
        expect(buildTrendsYAxisConfig(null, false, undefined, {}).showGrid).toBeUndefined()
    })

    it('spreads the formatter config from trendsFilterToYFormatterConfig', () => {
        const trendsFilter: TrendsFilter = {
            aggregationAxisFormat: 'duration',
            aggregationAxisPrefix: '~',
            decimalPlaces: 2,
        }
        const cfg = buildTrendsYAxisConfig(trendsFilter, false, 'USD' as CurrencyCode)
        expect(cfg).toMatchObject({ format: 'duration', prefix: '~', decimalPlaces: 2, currency: 'USD' })
    })

    it('forces percentage_scaled format when isPercentStackView is true', () => {
        const trendsFilter: TrendsFilter = { aggregationAxisFormat: 'currency', aggregationAxisPrefix: '$' }
        expect(buildTrendsYAxisConfig(trendsFilter, true, 'USD' as CurrencyCode).format).toBe('percentage_scaled')
    })

    // The suppression rules live only here, so these cases are their specification: a chart built
    // outside the UI never passes through the greyed-out controls that would otherwise explain them.
    const RANGE = { startAtZero: false, min: 40, max: 80 }

    it('forwards the y-axis range', () => {
        expect(buildTrendsYAxisConfig(null, false, undefined, RANGE)).toMatchObject(RANGE)
    })

    it.each([
        ['isPercentStackView', true, undefined],
        ['a logarithmic scale', false, 'log10'],
    ])('drops the y-axis range under %s', (_name, isPercentStackView, yAxisScaleType) => {
        const cfg = buildTrendsYAxisConfig(null, isPercentStackView, undefined, { ...RANGE, yAxisScaleType })
        expect(cfg.startAtZero).toBeUndefined()
        expect(cfg.min).toBeUndefined()
        expect(cfg.max).toBeUndefined()
    })

    // The library applies a bound after its own zero clamp, so forwarding both would leave the
    // toggle inert the moment a minimum was set. The maximum is unrelated and has to survive.
    it.each<[string, boolean | undefined]>([
        ['left at its default', undefined],
        ['explicitly on', true],
    ])('holds back the minimum but keeps the maximum with begin-at-zero %s', (_name, startAtZero) => {
        const cfg = buildTrendsYAxisConfig(null, false, undefined, { ...RANGE, startAtZero })
        expect(cfg.min).toBeUndefined()
        expect(cfg.max).toBe(80)
    })
})
