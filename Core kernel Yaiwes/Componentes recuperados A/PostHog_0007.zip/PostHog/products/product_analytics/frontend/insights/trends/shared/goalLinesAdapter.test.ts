import type { Series } from '@posthog/quill-charts'

import type { GoalLine as SchemaGoalLine } from '~/queries/schema/schema-general'

import {
    alertThresholdsToReferenceLines,
    goalLinesToReferenceLines,
    schemaGoalLinesToConfigs,
} from './goalLinesAdapter'

const makeSeries = (data: number[], overrides: Partial<Series> = {}): Series => ({
    key: 'a',
    label: 'a',
    color: '#000',
    data,
    ...overrides,
})

describe('goalLinesAdapter', () => {
    describe('goalLinesToReferenceLines', () => {
        const series = [makeSeries([10, 20, 30])]

        it('returns an empty array for nullish/empty input', () => {
            expect(goalLinesToReferenceLines(null, series)).toEqual([])
            expect(goalLinesToReferenceLines(undefined, series)).toEqual([])
            expect(goalLinesToReferenceLines([], series)).toEqual([])
        })

        it('maps each goal to a ReferenceLine with variant "goal"', () => {
            const goals: SchemaGoalLine[] = [{ label: 'Target', value: 50 }]
            const result = goalLinesToReferenceLines(goals, series)
            expect(result).toHaveLength(1)
            expect(result[0]).toMatchObject({
                value: 50,
                orientation: 'horizontal',
                variant: 'goal',
                label: 'Target',
                labelPosition: 'end',
            })
        })

        it.each([
            [
                'propagates borderColor via style.color',
                { borderColor: 'var(--danger)' },
                { style: { color: 'var(--danger)' } },
            ],
            ['omits label when displayLabel is false', { displayLabel: false }, { label: undefined }],
            ['respects explicit labelPosition', { position: 'start' }, { labelPosition: 'start' }],
        ] as const)('%s', (_, goalOverrides, expectedProps) => {
            const goals: SchemaGoalLine[] = [{ label: 'X', value: 50, ...goalOverrides }]
            expect(goalLinesToReferenceLines(goals, series)[0]).toMatchObject(expectedProps)
        })

        it('keeps goals when displayIfCrossed is undefined or true', () => {
            const goals: SchemaGoalLine[] = [
                { label: 'Default', value: 5 },
                { label: 'Explicit', value: 5, displayIfCrossed: true },
            ]
            const result = goalLinesToReferenceLines(goals, series)
            expect(result).toHaveLength(2)
        })
    })

    describe('alertThresholdsToReferenceLines', () => {
        it('returns an empty array for nullish/empty input', () => {
            expect(alertThresholdsToReferenceLines(null)).toEqual([])
            expect(alertThresholdsToReferenceLines(undefined)).toEqual([])
            expect(alertThresholdsToReferenceLines([])).toEqual([])
        })

        it('maps each threshold to a ReferenceLine with variant "alert"', () => {
            const lines: SchemaGoalLine[] = [
                { label: 'Upper', value: 100 },
                { label: 'Lower', value: 10 },
            ]
            const result = alertThresholdsToReferenceLines(lines)
            expect(result).toHaveLength(2)
            expect(result[0]).toMatchObject({
                value: 100,
                orientation: 'horizontal',
                variant: 'alert',
                label: 'Upper',
                labelPosition: 'end',
            })
            expect(result[1]).toMatchObject({ value: 10, variant: 'alert' })
        })

        it('does not apply the displayIfCrossed filter (always renders thresholds)', () => {
            const lines: SchemaGoalLine[] = [
                { label: 'Crossed', value: 1, displayIfCrossed: false },
                { label: 'Above', value: 9999, displayIfCrossed: false },
            ]
            expect(alertThresholdsToReferenceLines(lines).map((r) => r.label)).toEqual(['Crossed', 'Above'])
        })
    })

    describe('schemaGoalLinesToConfigs', () => {
        it.each<[string, SchemaGoalLine[] | null | undefined]>([
            ['null', null],
            ['undefined', undefined],
            ['empty array', []],
        ])('returns undefined for %s input', (_, input) => {
            expect(schemaGoalLinesToConfigs(input)).toBeUndefined()
        })

        it('produces one GoalLineConfig per schema goal line, mapping every field', () => {
            const lines: SchemaGoalLine[] = [
                {
                    label: 'Target',
                    value: 100,
                    displayLabel: true,
                    borderColor: '#ff0000',
                    position: 'end',
                    displayIfCrossed: true,
                },
                { label: 'Floor', value: 10 },
            ]
            expect(schemaGoalLinesToConfigs(lines)).toEqual([
                {
                    label: 'Target',
                    value: 100,
                    displayLabel: true,
                    color: '#ff0000',
                    labelPosition: 'end',
                    displayIfCrossed: true,
                },
                {
                    label: 'Floor',
                    value: 10,
                    displayLabel: undefined,
                    color: undefined,
                    labelPosition: undefined,
                    displayIfCrossed: undefined,
                },
            ])
        })
    })
})
