from uuid import uuid4

from posthog.test.base import APIBaseTest
from unittest import TestCase
from unittest.mock import MagicMock, patch

from parameterized import parameterized
from rest_framework.exceptions import PermissionDenied

from posthog.auth import SharingAccessTokenAuthentication

from products.product_analytics.backend.facade.api import map_stale_to_latest
from products.product_analytics.backend.facade.contracts import InsightVariableDefinition
from products.product_analytics.backend.facade.models import InsightVariable
from products.product_analytics.backend.presentation.insight_variable import (
    InsightVariableSerializer,
    InsightVariableViewSet,
)


class TestInsightVariable(APIBaseTest):
    def test_create_insight_variable(self):
        response = self.client.post(
            f"/api/environments/{self.team.pk}/insight_variables/", data={"name": "Test 1", "type": "String"}
        )

        assert response.status_code == 201

        variable = InsightVariable.objects.get(team_id=self.team.pk)

        assert variable is not None
        assert variable.created_by is not None
        assert variable.created_at is not None
        assert variable.name == "Test 1"
        assert variable.type == "String"
        assert variable.code_name == "test_1"

    def test_no_duplicate_code_names(self):
        InsightVariable.objects.create(team=self.team, name="Test 1", code_name="test_1")

        response = self.client.post(
            f"/api/environments/{self.team.pk}/insight_variables/", data={"name": "Test 1", "type": "String"}
        )

        assert response.status_code == 400

        variable_count = InsightVariable.objects.filter(team_id=self.team.pk).count()

        assert variable_count == 1

    def test_delete_insight_variable(self):
        variable = InsightVariable.objects.create(team=self.team, name="Test Delete", type="String")

        response = self.client.delete(f"/api/environments/{self.team.pk}/insight_variables/{variable.id}/")
        assert response.status_code == 204

        # Verify the variable was deleted
        assert not InsightVariable.objects.filter(id=variable.id).exists()

    def test_create_list_variable_coerces_null_values_to_empty_list(self):
        response = self.client.post(
            f"/api/environments/{self.team.pk}/insight_variables/",
            data={"name": "List Var", "type": "List"},
        )

        assert response.status_code == 201
        assert response.json()["values"] == []

    def test_create_query_backed_multiselect_list_variable(self):
        response = self.client.post(
            f"/api/environments/{self.team.pk}/insight_variables/",
            data={
                "name": "Event names",
                "type": "List",
                "values": [],
                "default_value": ["pageview", "signup"],
                "is_multi": True,
                "values_query": "SELECT DISTINCT event FROM events LIMIT 100",
                "values_query_connection_id": "connection-uuid",
            },
            content_type="application/json",
        )

        assert response.status_code == 201
        assert response.json()["default_value"] == ["pageview", "signup"]
        assert response.json()["is_multi"] is True
        assert response.json()["values_query"] == "SELECT DISTINCT event FROM events LIMIT 100"
        assert response.json()["values_query_connection_id"] == "connection-uuid"

        variable = InsightVariable.objects.get(team_id=self.team.pk)
        assert variable.default_value == ["pageview", "signup"]
        assert variable.is_multi is True
        assert variable.values_query == "SELECT DISTINCT event FROM events LIMIT 100"
        assert variable.values_query_connection_id == "connection-uuid"

    def test_blank_values_query_is_stored_as_null(self):
        response = self.client.post(
            f"/api/environments/{self.team.pk}/insight_variables/",
            data={
                "name": "Event name",
                "type": "List",
                "values": ["pageview"],
                "values_query": "   ",
                "values_query_connection_id": "connection-uuid",
            },
            content_type="application/json",
        )

        assert response.status_code == 201
        assert response.json()["values_query"] is None
        assert response.json()["values_query_connection_id"] is None

    def test_switching_to_static_options_clears_the_connection(self):
        variable = InsightVariable.objects.create(
            team=self.team,
            name="Event name",
            type="List",
            code_name="event_name",
            values=[],
            values_query="SELECT event FROM events",
            values_query_connection_id="connection-uuid",
        )

        response = self.client.patch(
            f"/api/environments/{self.team.pk}/insight_variables/{variable.id}/",
            data={"values_query": None},
            content_type="application/json",
        )

        assert response.status_code == 200
        variable.refresh_from_db()
        assert variable.values_query is None
        assert variable.values_query_connection_id is None

    def test_enabling_multiselect_normalizes_existing_default(self):
        variable = InsightVariable.objects.create(
            team=self.team,
            name="Event name",
            type="List",
            code_name="event_name",
            values=["pageview", "signup"],
            default_value="pageview",
        )

        response = self.client.patch(
            f"/api/environments/{self.team.pk}/insight_variables/{variable.id}/",
            data={"is_multi": True},
            content_type="application/json",
        )

        assert response.status_code == 200
        assert response.json()["default_value"] == ["pageview"]
        variable.refresh_from_db()
        assert variable.default_value == ["pageview"]

    def test_insight_variable_limit(self):
        # default list call should return up to 500 variables
        response = self.client.get(f"/api/environments/{self.team.pk}/insight_variables/")
        assert response.status_code == 200

        # create 501 variables
        for i in range(501):
            InsightVariable.objects.create(team=self.team, name=f"Test {i}", type="String")

        response = self.client.get(f"/api/environments/{self.team.pk}/insight_variables/")
        assert response.status_code == 200
        assert len(response.json()["results"]) == 500

    @parameterized.expand(
        [
            ("preserves_underscores", "my_var", "my_var"),
            ("strips_special_chars", "Test @#$ Var!", "test__var"),
            ("multiple_spaces", "foo  bar", "foo__bar"),
            (
                "leading_trailing_spaces",
                " spaced ",
                "spaced",
            ),  # DRF CharField strips whitespace before code_name generation
            ("mixed_alphanumeric", "abc123", "abc123"),
        ]
    )
    def test_code_name_generation(self, _name, input_name, expected_code_name):
        response = self.client.post(
            f"/api/environments/{self.team.pk}/insight_variables/",
            data={"name": input_name, "type": "String"},
            content_type="application/json",
        )
        assert response.status_code == 201
        assert response.json()["code_name"] == expected_code_name

    def test_sharing_token_auth_denied(self):
        request = MagicMock()
        request.successful_authenticator = SharingAccessTokenAuthentication()

        viewset = InsightVariableViewSet()
        viewset.request = request
        viewset.kwargs = {}
        viewset.format_kwarg = None

        with patch("rest_framework.viewsets.ModelViewSet.initial"):
            with self.assertRaises(PermissionDenied) as ctx:
                viewset.initial(request)

        assert "sharing authentication" in str(ctx.exception.detail)

    def test_update_variable_name(self):
        variable = InsightVariable.objects.create(team=self.team, name="Original", type="String", code_name="original")
        response = self.client.patch(
            f"/api/environments/{self.team.pk}/insight_variables/{variable.id}/",
            data={"name": "Updated"},
            content_type="application/json",
        )
        assert response.status_code == 200
        assert response.json()["name"] == "Updated"

    def test_update_list_variable_values(self):
        variable = InsightVariable.objects.create(
            team=self.team, name="List Var", type="List", code_name="list_var", values=["a"]
        )
        response = self.client.patch(
            f"/api/environments/{self.team.pk}/insight_variables/{variable.id}/",
            data={"values": ["a", "b", "c"]},
            content_type="application/json",
        )
        assert response.status_code == 200
        assert response.json()["values"] == ["a", "b", "c"]

    @parameterized.expand(
        [
            ("null_values", None),
            ("dict_values", {"unexpected": "shape"}),
            ("string_values", "not-a-list"),
        ]
    )
    def test_list_variable_with_non_array_values_is_normalized_on_read(self, _name, stored_values):
        variable = InsightVariable.objects.create(
            team=self.team, name="List Var", type="List", code_name="list_var", values=stored_values
        )
        response = self.client.get(f"/api/environments/{self.team.pk}/insight_variables/{variable.id}/")
        assert response.status_code == 200
        assert response.json()["values"] == []

    @parameterized.expand(
        [
            ("null_values", None),
            ("dict_values", {"unexpected": "shape"}),
            ("string_values", "not-a-list"),
        ]
    )
    def test_update_list_variable_with_non_array_values_coerces_to_empty_list(self, _name, new_values):
        variable = InsightVariable.objects.create(
            team=self.team, name="List Var", type="List", code_name="list_var", values=["a"]
        )
        response = self.client.patch(
            f"/api/environments/{self.team.pk}/insight_variables/{variable.id}/",
            data={"values": new_values},
            content_type="application/json",
        )
        assert response.status_code == 200
        assert response.json()["values"] == []
        variable.refresh_from_db()
        assert variable.values == []

    @parameterized.expand(
        [
            ("object_elements", [{"label": "School 1", "value": "1"}], 400, None),
            ("array_elements", [["nested"]], 400, None),
            ("numeric_elements", [1, 2.5], 200, ["1", "2.5"]),
            ("boolean_elements", [True], 200, ["true"]),
            ("null_elements_dropped", [None, "a"], 200, ["a"]),
        ]
    )
    def test_update_list_variable_values_element_shapes(self, _name, new_values, expected_status, expected_values):
        variable = InsightVariable.objects.create(
            team=self.team, name="List Var", type="List", code_name="list_var", values=["a"]
        )
        response = self.client.patch(
            f"/api/environments/{self.team.pk}/insight_variables/{variable.id}/",
            data={"values": new_values},
            content_type="application/json",
        )
        assert response.status_code == expected_status
        variable.refresh_from_db()
        if expected_status == 200:
            assert response.json()["values"] == expected_values
            assert variable.values == expected_values
        else:
            assert response.json()["attr"] == "values"
            assert variable.values == ["a"]

    def test_update_unrelated_field_with_legacy_object_values_succeeds(self):
        legacy_values = [{"label": "School 1", "value": "1"}]
        variable = InsightVariable.objects.create(
            team=self.team, name="List Var", type="List", code_name="list_var", values=legacy_values
        )
        response = self.client.patch(
            f"/api/environments/{self.team.pk}/insight_variables/{variable.id}/",
            data={"name": "Renamed"},
            content_type="application/json",
        )
        assert response.status_code == 200
        variable.refresh_from_db()
        assert variable.name == "Renamed"
        assert variable.values == legacy_values

    def test_list_variable_with_legacy_values_is_coerced_on_read(self):
        variable = InsightVariable.objects.create(
            team=self.team,
            name="List Var",
            type="List",
            code_name="list_var",
            values=[{"label": "School 1", "value": "1"}, 2, None, "keep"],
            default_value={"value": "1"},
        )
        response = self.client.get(f"/api/environments/{self.team.pk}/insight_variables/{variable.id}/")
        assert response.status_code == 200
        body = response.json()
        assert body["values"] == ["1", "2", "keep"]
        assert body["default_value"] == "1"

    def test_update_type_to_list_coerces_null_values(self):
        variable = InsightVariable.objects.create(team=self.team, name="Str Var", type="String", code_name="str_var")
        response = self.client.patch(
            f"/api/environments/{self.team.pk}/insight_variables/{variable.id}/",
            data={"type": "List"},
            content_type="application/json",
        )
        assert response.status_code == 200
        assert response.json()["values"] == []


class TestInsightVariableSerializer(TestCase):
    def test_multiselect_create_without_default_uses_empty_list(self) -> None:
        serializer = InsightVariableSerializer(data={"name": "Event names", "type": "List", "is_multi": True})

        assert serializer.is_valid(), serializer.errors
        assert serializer.validated_data["default_value"] == []


class TestMapStaleToLatest(TestCase):
    def _make_variable(self, code_name: str) -> InsightVariableDefinition:
        return InsightVariableDefinition(id=uuid4(), name=code_name, code_name=code_name, type="String")

    @parameterized.expand(
        [
            (
                "empty_stale_returns_empty",
                {},
                ["var_a", "var_b"],
                [],
            ),
            (
                "matching_code_names_update_ids",
                {"old-id-1": {"code_name": "var_a", "value": 1}},
                ["var_a"],
                ["var_a"],
            ),
            (
                "unmatched_code_names_dropped",
                {"old-id-1": {"code_name": "no_match", "value": 1}},
                ["var_a"],
                [],
            ),
            (
                "mixed_match_and_no_match",
                {
                    "old-id-1": {"code_name": "var_a", "value": 1},
                    "old-id-2": {"code_name": "no_match", "value": 2},
                },
                ["var_a", "var_b"],
                ["var_a"],
            ),
        ]
    )
    def test_map_stale_to_latest(self, _name, stale, latest_code_names, expected_matched_code_names):
        latest_vars = [self._make_variable(cn) for cn in latest_code_names]
        result = map_stale_to_latest(stale, latest_vars)

        result_code_names = [v["code_name"] for v in result.values()]
        assert sorted(result_code_names) == sorted(expected_matched_code_names)

        for v in result.values():
            code_name = v["code_name"]
            matched_var = next(lv for lv in latest_vars if lv.code_name == code_name)
            assert v["variableId"] == str(matched_var.id)

            # original stale values are preserved via spread
            original = next(sv for sv in stale.values() if sv.get("code_name") == code_name)
            for key, val in original.items():
                assert v[key] == val
