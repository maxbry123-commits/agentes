import json
from datetime import datetime, timedelta
from typing import Any, Optional
from zoneinfo import ZoneInfo

from freezegun import freeze_time
from posthog.test.base import (
    APIBaseTest,
    ClickhouseTestMixin,
    QueryMatchingTest,
    _create_event,
    _create_person,
    also_test_with_materialized_columns,
    flush_persons_and_events,
    snapshot_clickhouse_queries,
    snapshot_postgres_queries,
)
from unittest import mock
from unittest.case import skip
from unittest.mock import ANY, PropertyMock, patch

from django.test import override_settings
from django.utils import timezone

from parameterized import parameterized
from rest_framework import status

from posthog.schema import (
    DataTableNode,
    DataVisualizationNode,
    DateRange,
    EventPropertyFilter,
    EventsNode,
    EventsQuery,
    FilterLogicalOperator,
    HogQLFilters,
    HogQLQuery,
    InsightNodeKind,
    InsightVizNode,
    NodeKind,
    PropertyGroupFilter,
    PropertyGroupFilterValue,
    TrendsQuery,
)

from posthog.hogql.query import execute_hogql_query

from posthog import settings
from posthog.api.test.dashboards import DashboardAPI
from posthog.caching.insight_result import InsightResult
from posthog.constants import AvailableFeature
from posthog.hogql_queries.query_runner import SHARED_FORCE_BLOCKING_STALENESS_WINDOW, ExecutionMode
from posthog.models import Filter, OrganizationMembership, SharingConfiguration, Team, User
from posthog.models.project import Project
from posthog.test.db_context_capturing import capture_db_queries
from posthog.test.persons import create_person

from products.access_control.backend.models.access_control import AccessControl
from products.alerts.backend.models.alert import AlertConfiguration, AlertSubscription, Threshold
from products.cohorts.backend.models.cohort import Cohort
from products.dashboards.backend.facade.access import DashboardAccessMethod
from products.dashboards.backend.models.dashboard import Dashboard
from products.dashboards.backend.models.dashboard_tile import DashboardTile, Text
from products.product_analytics.backend.facade.models import Insight, InsightVariable
from products.product_analytics.backend.models.insight import InsightViewed


class TestInsight(ClickhouseTestMixin, APIBaseTest, QueryMatchingTest):
    maxDiff = None

    def setUp(self) -> None:
        super().setUp()
        self.dashboard_api = DashboardAPI(self.client, self.team, self.assertEqual)

    @parameterized.expand(
        [
            ("trend", "/api/projects/{team_id}/insights/trend/"),
            ("funnel", "/api/projects/{team_id}/insights/funnel/"),
        ]
    )
    def test_legacy_insight_endpoints_blocked_with_feature_flag(self, _name: str, path: str) -> None:
        with patch(
            "products.product_analytics.backend.presentation.insight.feature_enabled_or_false", return_value=True
        ) as mock_feature_enabled:
            response = self.client.get(path.format(team_id=self.team.id))

        self.assertEqual(response.status_code, status.HTTP_403_FORBIDDEN)
        self.assertEqual(response.json()["detail"], "Legacy insight endpoints are not available for this user.")
        legacy_calls = [
            c for c in mock_feature_enabled.call_args_list if c[0][0] == "legacy-insight-endpoints-disabled"
        ]
        self.assertEqual(len(legacy_calls), 1)

    def test_creating_legacy_filter_insight_blocked_with_feature_flag(self) -> None:
        with patch(
            "products.product_analytics.backend.presentation.insight.feature_enabled_or_false", return_value=True
        ) as mock_feature_enabled:
            response = self.client.post(
                f"/api/projects/{self.team.id}/insights/",
                {"name": "Legacy filter insight", "filters": {"insight": "TRENDS", "events": [{"id": "$pageview"}]}},
            )

        self.assertEqual(response.status_code, status.HTTP_403_FORBIDDEN)
        self.assertEqual(
            response.json()["detail"],
            "Creating or updating insights with legacy filters is not available for this user.",
        )
        legacy_filter_calls = [
            c for c in mock_feature_enabled.call_args_list if c[0][0] == "legacy-insight-filters-disabled"
        ]
        self.assertEqual(len(legacy_filter_calls), 1)

    def test_creating_query_insight_not_blocked_by_legacy_filter_flag(self) -> None:
        with patch(
            "products.product_analytics.backend.presentation.insight.feature_enabled_or_false", return_value=True
        ) as mock_feature_enabled:
            response = self.client.post(
                f"/api/projects/{self.team.id}/insights/",
                {
                    "name": "Query insight",
                    "query": InsightVizNode(source=TrendsQuery(series=[EventsNode(event="$pageview")])).model_dump(),
                },
            )

        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        legacy_filter_calls = [
            c for c in mock_feature_enabled.call_args_list if c[0][0] == "legacy-insight-filters-disabled"
        ]
        self.assertEqual(len(legacy_filter_calls), 0)

    def test_get_insight_items(self) -> None:
        filter_dict = {
            "events": [{"id": "$pageview"}],
            "properties": [{"key": "$browser", "value": "Mac OS X"}],
        }

        Insight.objects.create(
            filters=Filter(data=filter_dict).to_dict(),
            team=self.team,
            created_by=self.user,
        )

        # create without user
        Insight.objects.create(filters=Filter(data=filter_dict).to_dict(), team=self.team)

        response = self.client.get(f"/api/projects/{self.team.id}/insights/", data={"user": "true"}).json()

        self.assertEqual(len(response["results"]), 1)

    def test_get_insight_items_all_environments_included(self) -> None:
        filter_dict = {
            "events": [{"id": "$pageview"}],
            "properties": [{"key": "$browser", "value": "Mac OS X"}],
        }

        other_team_in_project = Team.objects.create(organization=self.organization, project=self.project)
        _, team_in_other_project = Project.objects.create_with_team(
            organization=self.organization, initiating_user=self.user
        )

        insight_a = Insight.objects.create(
            filters=Filter(data=filter_dict).to_dict(),
            team=self.team,
            created_by=self.user,
        )
        insight_b = Insight.objects.create(
            filters=Filter(data=filter_dict).to_dict(),
            team=other_team_in_project,
            created_by=self.user,
        )
        Insight.objects.create(
            filters=Filter(data=filter_dict).to_dict(),
            team=team_in_other_project,
            created_by=self.user,
        )

        # All of these three ways should return the same set of insights,
        # i.e. all insights in the test project regardless of environment
        response_project = self.client.get(f"/api/projects/{self.project.id}/insights/").json()
        response_env_current = self.client.get(f"/api/environments/{self.team.id}/insights/").json()
        response_env_other = self.client.get(f"/api/environments/{other_team_in_project.id}/insights/").json()

        self.assertEqual({insight["id"] for insight in response_project["results"]}, {insight_a.id, insight_b.id})
        self.assertEqual({insight["id"] for insight in response_env_current["results"]}, {insight_a.id, insight_b.id})
        self.assertEqual({insight["id"] for insight in response_env_other["results"]}, {insight_a.id, insight_b.id})

    @patch("posthoganalytics.capture")
    def test_created_updated_and_last_modified(self, mock_capture: mock.Mock) -> None:
        alt_user = User.objects.create_and_join(self.organization, "team2@posthog.com", None)
        self_user_basic_serialized = {
            "id": self.user.id,
            "uuid": str(self.user.uuid),
            "distinct_id": self.user.distinct_id,
            "first_name": self.user.first_name,
            "last_name": self.user.last_name,
            "email": self.user.email,
            "is_email_verified": None,
            "hedgehog_config": None,
            "role_at_organization": None,
        }
        alt_user_basic_serialized = {
            "id": alt_user.id,
            "uuid": str(alt_user.uuid),
            "distinct_id": alt_user.distinct_id,
            "first_name": alt_user.first_name,
            "last_name": alt_user.last_name,
            "email": alt_user.email,
            "is_email_verified": None,
            "hedgehog_config": None,
            "role_at_organization": None,
        }

        # Newly created insight should have created_at being the current time, and same last_modified_at
        # Fields created_by and last_modified_by should be set to the current user
        with freeze_time("2021-08-23T12:00:00Z"):
            response_1 = self.client.post(
                f"/api/projects/{self.team.id}/insights/",
                {"name": "test"},
                headers={"Referer": "https://posthog.com/my-referer", "X-Posthog-Session-Id": "my-session-id"},
            )
            self.assertEqual(response_1.status_code, status.HTTP_201_CREATED)
            self.assertLessEqual(
                {
                    "created_at": "2021-08-23T12:00:00Z",
                    "created_by": self_user_basic_serialized,
                    "updated_at": "2021-08-23T12:00:00Z",
                    "last_modified_at": "2021-08-23T12:00:00Z",
                    "last_modified_by": self_user_basic_serialized,
                }.items(),
                response_1.json().items(),
            )
            mock_capture.assert_any_call(
                distinct_id=self.user.distinct_id,
                event="insight created",
                properties={
                    "$current_url": "https://posthog.com/my-referer",
                    "$host": "posthog.com",
                    "$pathname": "/my-referer",
                    "$session_id": "my-session-id",
                    "source": "web",
                    "was_impersonated": False,
                    "access_method": None,
                    "user_agent": None,
                    "mcp_user_agent": None,
                    "mcp_client_name": None,
                    "mcp_client_version": None,
                    "mcp_protocol_version": None,
                    "mcp_oauth_client_name": None,
                    "insight_id": response_1.json()["short_id"],
                    "$set_once": {"email": self.user.email},
                },
                groups=ANY,
                send_feature_flags=False,
            )
            mock_capture.reset_mock()

        insight_id = response_1.json()["id"]

        # Updating fields that don't change the substance of the insight should affect updated_at
        # BUT NOT last_modified_at or last_modified_by
        with freeze_time("2021-09-20T12:00:00Z"):
            response_2 = self.client.patch(
                f"/api/projects/{self.team.id}/insights/{insight_id}",
                {"favorited": True},
                headers={"Referer": "https://posthog.com/my-referer", "X-Posthog-Session-Id": "my-session-id"},
            )
            self.assertEqual(response_2.status_code, status.HTTP_200_OK)
            self.assertLessEqual(
                {
                    "created_at": "2021-08-23T12:00:00Z",
                    "created_by": self_user_basic_serialized,
                    "updated_at": "2021-09-20T12:00:00Z",
                    "last_modified_at": "2021-08-23T12:00:00Z",
                    "last_modified_by": self_user_basic_serialized,
                }.items(),
                response_2.json().items(),
            )
            insight_short_id = response_2.json()["short_id"]
            # Check that "insight updated" event was called among all capture calls
            mock_capture.assert_any_call(
                distinct_id=self.user.distinct_id,
                event="insight updated",
                properties={
                    "$current_url": "https://posthog.com/my-referer",
                    "$host": "posthog.com",
                    "$pathname": "/my-referer",
                    "$session_id": "my-session-id",
                    "source": "web",
                    "was_impersonated": False,
                    "access_method": None,
                    "user_agent": None,
                    "mcp_user_agent": None,
                    "mcp_client_name": None,
                    "mcp_client_version": None,
                    "mcp_protocol_version": None,
                    "mcp_oauth_client_name": None,
                    "insight_id": insight_short_id,
                    "$set_once": {"email": self.user.email},
                },
                groups=ANY,
                send_feature_flags=False,
            )
            mock_capture.reset_mock()

        # Updating fields that DO change the substance of the insight should affect updated_at
        # AND last_modified_at plus last_modified_by
        with freeze_time("2021-10-21T12:00:00Z"):
            response_3 = self.client.patch(
                f"/api/projects/{self.team.id}/insights/{insight_id}",
                {"filters": {"events": []}},
            )
            self.assertEqual(response_3.status_code, status.HTTP_200_OK)
            self.assertLessEqual(
                {
                    "created_at": "2021-08-23T12:00:00Z",
                    "created_by": self_user_basic_serialized,
                    "updated_at": "2021-10-21T12:00:00Z",
                    "last_modified_at": "2021-10-21T12:00:00Z",
                    "last_modified_by": self_user_basic_serialized,
                }.items(),
                response_3.json().items(),
            )
        with freeze_time("2021-12-23T12:00:00Z"):
            response_4 = self.client.patch(f"/api/projects/{self.team.id}/insights/{insight_id}", {"name": "XYZ"})
            self.assertEqual(response_4.status_code, status.HTTP_200_OK)
            self.assertLessEqual(
                {
                    "created_at": "2021-08-23T12:00:00Z",
                    "created_by": self_user_basic_serialized,
                    "updated_at": "2021-12-23T12:00:00Z",
                    "last_modified_at": "2021-12-23T12:00:00Z",
                    "last_modified_by": self_user_basic_serialized,
                }.items(),
                response_4.json().items(),
            )

        # Field last_modified_by is updated when another user makes a material change
        self.client.force_login(alt_user)
        with freeze_time("2022-01-01T12:00:00Z"):
            response_5 = self.client.patch(
                f"/api/projects/{self.team.id}/insights/{insight_id}",
                {"description": "Lorem ipsum."},
            )
            self.assertEqual(response_5.status_code, status.HTTP_200_OK)
            self.assertLessEqual(
                {
                    "created_at": "2021-08-23T12:00:00Z",
                    "created_by": self_user_basic_serialized,
                    "updated_at": "2022-01-01T12:00:00Z",
                    "last_modified_at": "2022-01-01T12:00:00Z",
                    "last_modified_by": alt_user_basic_serialized,
                }.items(),
                response_5.json().items(),
            )

    def test_get_saved_insight_items(self) -> None:
        filter_dict = {
            "events": [{"id": "$pageview"}],
            "properties": [{"key": "$browser", "value": "Mac OS X"}],
        }

        Insight.objects.create(
            filters=Filter(data=filter_dict).to_dict(),
            saved=True,
            team=self.team,
            created_by=self.user,
        )

        # create without saved
        Insight.objects.create(
            filters=Filter(data=filter_dict).to_dict(),
            team=self.team,
            created_by=self.user,
        )

        # create without user
        Insight.objects.create(filters=Filter(data=filter_dict).to_dict(), team=self.team)

        response = self.client.get(
            f"/api/projects/{self.team.id}/insights/",
            data={"saved": "true", "user": "true"},
        )
        self.assertEqual(response.status_code, status.HTTP_200_OK)

        self.assertEqual(len(response.json()["results"]), 2)
        self.assertEqual(len(response.json()["results"][0]["short_id"]), 8)

    def test_dashboard_template_insights_default_to_saved(self) -> None:
        from posthog.helpers.dashboard_templates import create_dashboard_from_template

        dashboard = Dashboard.objects.create(team=self.team, name="Test")
        create_dashboard_from_template("DEFAULT_APP", dashboard)

        insights = Insight.objects.filter(dashboard_tiles__dashboard=dashboard)
        self.assertGreater(insights.count(), 0)
        for insight in insights:
            self.assertTrue(insight.saved, f"Insight '{insight.name}' should have saved=True")

    def test_get_favorited_insight_items(self) -> None:
        filter_dict = {
            "events": [{"id": "$pageview"}],
            "properties": [{"key": "$browser", "value": "Mac OS X"}],
        }

        Insight.objects.create(
            filters=Filter(data=filter_dict).to_dict(),
            favorited=True,
            team=self.team,
            created_by=self.user,
        )

        # create without favorited
        Insight.objects.create(
            filters=Filter(data=filter_dict).to_dict(),
            team=self.team,
            created_by=self.user,
        )

        # create without user
        Insight.objects.create(filters=Filter(data=filter_dict).to_dict(), team=self.team)

        response = self.client.get(f"/api/projects/{self.team.id}/insights/?favorited=true&user=true")
        self.assertEqual(response.status_code, status.HTTP_200_OK)

        self.assertEqual(len(response.json()["results"]), 1)
        self.assertEqual((response.json()["results"][0]["favorited"]), True)

    def test_hide_feature_flag_insights_filter(self) -> None:
        from posthog.helpers.dashboard_templates import (
            FEATURE_FLAG_TOTAL_VOLUME_INSIGHT_NAME,
            FEATURE_FLAG_UNIQUE_USERS_INSIGHT_NAME,
        )

        filter_dict = {
            "events": [{"id": "$pageview"}],
            "properties": [{"key": "$browser", "value": "Mac OS X"}],
        }

        # Create feature flag insights
        Insight.objects.create(
            name=FEATURE_FLAG_TOTAL_VOLUME_INSIGHT_NAME,
            filters=Filter(data=filter_dict).to_dict(),
            saved=True,
            team=self.team,
            created_by=self.user,
        )

        Insight.objects.create(
            name=FEATURE_FLAG_UNIQUE_USERS_INSIGHT_NAME,
            filters=Filter(data=filter_dict).to_dict(),
            saved=True,
            team=self.team,
            created_by=self.user,
        )

        # Create a regular insight
        Insight.objects.create(
            name="Regular Insight",
            filters=Filter(data=filter_dict).to_dict(),
            saved=True,
            team=self.team,
            created_by=self.user,
        )

        # Without filter, should return all 3 insights
        response = self.client.get(f"/api/projects/{self.team.id}/insights/?saved=true")
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.json()["results"]), 3)

        # With filter, should exclude feature flag insights
        response = self.client.get(f"/api/projects/{self.team.id}/insights/?saved=true&hide_feature_flag_insights=true")
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.json()["results"]), 1)
        self.assertEqual(response.json()["results"][0]["name"], "Regular Insight")

    def test_get_insight_in_dashboard_context(self) -> None:
        filter_dict = {
            "events": [{"id": "$pageview"}],
            "properties": [{"key": "$browser", "value": "Mac OS X"}],
        }

        dashboard_id, _ = self.dashboard_api.create_dashboard(
            {"name": "the dashboard", "filters": {"date_from": "-180d"}}
        )

        insight_id, _ = self.dashboard_api.create_insight(
            {"filters": filter_dict, "name": "insight", "dashboards": [dashboard_id]}
        )

        insight_in_isolation = self.dashboard_api.get_insight(insight_id)
        self.assertIsNotNone(insight_in_isolation.get("filters_hash", None))

        insight_on_dashboard = self.dashboard_api.get_insight(insight_id, query_params={"from_dashboard": dashboard_id})
        self.assertIsNotNone(insight_on_dashboard.get("filters_hash", None))

        self.assertNotEqual(insight_in_isolation["filters_hash"], insight_on_dashboard["filters_hash"])

    @parameterized.expand(
        [
            ("hit", True, None, True),
            ("miss", False, None, True),
            ("forced_refresh", False, "force_blocking", False),
        ]
    )
    @patch("products.product_analytics.backend.presentation.insight.record_dashboard_cache_outcome")
    @patch("posthog.caching.calculate_results.calculate_for_query_based_insight")
    def test_dashboard_insight_records_cache_outcome(
        self,
        _name: str,
        is_cached: bool,
        refresh: str | None,
        expect_recorded: bool,
        mock_calculate: mock.MagicMock,
        mock_record_outcome: mock.MagicMock,
    ) -> None:
        dashboard = Dashboard.objects.create(team=self.team, name="Dashboard", created_by=self.user)
        insight = Insight.objects.create(
            team=self.team,
            created_by=self.user,
            query={"kind": "TrendsQuery", "series": [{"kind": "EventsNode", "event": "$pageview"}]},
        )
        DashboardTile.objects.create(dashboard=dashboard, insight=insight)
        mock_calculate.return_value = InsightResult(
            result=[],
            last_refresh=timezone.now(),
            cache_key="cache-key",
            is_cached=is_cached,
            timezone=self.team.timezone,
        )

        query_params = {"from_dashboard": str(dashboard.id)}
        if refresh is not None:
            query_params["refresh"] = refresh
        response = self.client.get(f"/api/projects/{self.team.id}/insights/{insight.id}/", query_params)

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        if expect_recorded:
            mock_record_outcome.assert_called_once_with(DashboardAccessMethod.HUMAN, is_cached=is_cached)
        else:
            mock_record_outcome.assert_not_called()

    def test_get_insight_in_shared_context(self) -> None:
        filter_dict = {
            "events": [{"id": "$pageview"}],
            "properties": [{"key": "$browser", "value": "Mac OS X"}],
        }

        dashboard_id, _ = self.dashboard_api.create_dashboard(
            {"name": "the dashboard", "filters": {"date_from": "-180d"}}
        )

        insight_id, _ = self.dashboard_api.create_insight(
            {"filters": filter_dict, "name": "insight", "dashboards": [dashboard_id]}
        )
        sharing_config = SharingConfiguration.objects.create(team=self.team, insight_id=insight_id, enabled=True)

        valid_url = f"{settings.SITE_URL}/shared/{sharing_config.access_token}"

        with (
            patch(
                "posthog.caching.calculate_results.calculate_for_query_based_insight"
            ) as calculate_for_query_based_insight,
            patch(
                "products.product_analytics.backend.presentation.insight.record_dashboard_cache_outcome"
            ) as record_outcome,
        ):
            self.client.get(valid_url)
            calculate_for_query_based_insight.assert_called_once_with(
                mock.ANY,
                dashboard=mock.ANY,
                execution_mode=ExecutionMode.EXTENDED_CACHE_CALCULATE_ASYNC_IF_STALE,
                team=self.team,
                user=mock.ANY,
                user_access_control=mock.ANY,
                filters_override={},
                variables_override={},
                tile_filters_override={},
                cache_age_seconds=None,
                analytics_props=ANY,
                allow_raw_results=False,
            )
            record_outcome.assert_not_called()

        with patch(
            "posthog.caching.calculate_results.calculate_for_query_based_insight"
        ) as calculate_for_query_based_insight:
            self.client.get(valid_url, data={"refresh": True})
            calculate_for_query_based_insight.assert_called_once_with(
                mock.ANY,
                dashboard=mock.ANY,
                # Shared force_blocking runs as blocking-if-stale with the throttle window as
                # the staleness threshold: a cache younger than `SHARED_FORCE_BLOCKING_STALENESS_WINDOW`
                # is served as-is, anything older (or missing) recomputes synchronously.
                execution_mode=ExecutionMode.RECENT_CACHE_CALCULATE_BLOCKING_IF_STALE,
                team=self.team,
                user=mock.ANY,
                user_access_control=mock.ANY,
                filters_override={},
                variables_override={},
                tile_filters_override={},
                cache_age_seconds=int(SHARED_FORCE_BLOCKING_STALENESS_WINDOW.total_seconds()),
                analytics_props=ANY,
                allow_raw_results=False,
            )

    def test_get_shared_insight_with_force_refresh_returns_200(self) -> None:
        # Un-mocked end-to-end regression test: exercises the real process_query_dict ->
        # process_query_model -> query_runner.run() chain that the mocked assertions above
        # never execute the body of. A 200 alone doesn't prove this: insight_result's
        # broad except Exception swallows calculation crashes into a query_status error
        # and still renders 200, so assert the embedded result actually computed.
        filter_dict = {"events": [{"id": "$pageview"}]}

        insight_id, _ = self.dashboard_api.create_insight({"filters": filter_dict, "name": "insight"})
        sharing_config = SharingConfiguration.objects.create(team=self.team, insight_id=insight_id, enabled=True)

        # .json suffix returns exported_data directly, skipping exporter.html rendering
        valid_url = f"{settings.SITE_URL}/shared/{sharing_config.access_token}.json"

        response = self.client.get(valid_url, data={"refresh": "force_blocking"})
        self.assertEqual(response.status_code, status.HTTP_200_OK)

        exported = response.json()
        query_status = exported["insight"]["query_status"] or {}
        self.assertFalse(query_status.get("error"), query_status)
        self.assertIsNotNone(exported["insight"]["result"])

    def test_shared_force_refresh_ignores_client_filter_overrides(self) -> None:
        # Regression: the /shared/<token> page load runs without an authenticator, so the serializer
        # must rely on the is_shared context flag to drop client-supplied overrides. Without the flag
        # reaching the override helpers, a viewer could pair a unique filters_override with
        # refresh=force_blocking on every request — each novel value is a fresh cache miss that
        # recomputes synchronously, defeating the throttle this PR relies on.
        insight_id, _ = self.dashboard_api.create_insight(
            {"filters": {"events": [{"id": "$pageview"}]}, "name": "insight"}
        )
        sharing_config = SharingConfiguration.objects.create(team=self.team, insight_id=insight_id, enabled=True)

        valid_url = f"{settings.SITE_URL}/shared/{sharing_config.access_token}"

        with patch(
            "posthog.caching.calculate_results.calculate_for_query_based_insight"
        ) as calculate_for_query_based_insight:
            self.client.get(
                valid_url,
                data={
                    "refresh": "force_blocking",
                    "filters_override": json.dumps({"date_from": "-1d"}),
                    "variables_override": json.dumps({"injected": {"value": "evil"}}),
                    "tile_filters_override": json.dumps({"breakdown": "region"}),
                },
            )
            calculate_for_query_based_insight.assert_called_once_with(
                mock.ANY,
                dashboard=mock.ANY,
                execution_mode=ExecutionMode.RECENT_CACHE_CALCULATE_BLOCKING_IF_STALE,
                team=self.team,
                user=mock.ANY,
                user_access_control=mock.ANY,
                filters_override={},
                variables_override={},
                tile_filters_override={},
                cache_age_seconds=int(SHARED_FORCE_BLOCKING_STALENESS_WINDOW.total_seconds()),
                analytics_props=ANY,
                allow_raw_results=False,
            )

    def test_get_insight_by_short_id(self) -> None:
        filter_dict = {"events": [{"id": "$pageview"}]}

        Insight.objects.create(
            filters=Filter(data=filter_dict).to_dict(),
            team=self.team,
            short_id="12345678",
        )

        # We need at least one more insight to make sure we're not just getting the first one
        Insight.objects.create(
            filters=Filter(data=filter_dict).to_dict(),
            team=self.team,
            short_id="not-that-one",
        )

        # Red herring: Should be ignored because it's not on the current team (even though the user has access)
        new_team = Team.objects.create(organization=self.organization)
        Insight.objects.create(
            filters=Filter(data=filter_dict).to_dict(),
            team=new_team,
            short_id="12345678",
        )

        response = self.client.get(f"/api/projects/{self.team.id}/insights/?short_id=12345678")
        self.assertEqual(response.status_code, status.HTTP_200_OK)

        self.assertEqual(len(response.json()["results"]), 1)
        self.assertEqual(response.json()["results"][0]["short_id"], "12345678")
        self.assertEqual(response.json()["results"][0]["query"]["source"]["series"][0]["event"], "$pageview")

    @parameterized.expand(
        [
            ("numeric_id", lambda insight: insight.id),
            ("short_id", lambda insight: insight.short_id),
        ]
    )
    def test_retrieve_insight_by_id_or_short_id(self, _name, lookup) -> None:
        insight = Insight.objects.create(
            filters=Filter(data={"events": [{"id": "$pageview"}]}).to_dict(),
            team=self.team,
            short_id="abcd1234",
            name="dual-lookup",
        )

        # Another insight in a different team sharing the same short_id — must not be returned.
        other_team = Team.objects.create(organization=self.organization)
        Insight.objects.create(
            filters=Filter(data={"events": [{"id": "$pageview"}]}).to_dict(),
            team=other_team,
            short_id="abcd1234",
            name="other-team",
        )

        response = self.client.get(f"/api/projects/{self.team.id}/insights/{lookup(insight)}/")
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.json()["id"], insight.id)
        self.assertEqual(response.json()["short_id"], "abcd1234")
        self.assertEqual(response.json()["name"], "dual-lookup")

    def test_retrieve_insight_by_unknown_short_id_returns_404(self) -> None:
        response = self.client.get(f"/api/projects/{self.team.id}/insights/notthere/")
        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)

    def test_retrieve_insight_by_numeric_short_id_falls_back_to_short_id(self) -> None:
        # A small number of legacy insights have numeric-only short_ids — they must remain retrievable
        # when no insight matches the value as a primary key.
        numeric_short_id = "99999999999"
        assert not Insight.objects.filter(pk=int(numeric_short_id)).exists()
        insight = Insight.objects.create(
            filters=Filter(data={"events": [{"id": "$pageview"}]}).to_dict(),
            team=self.team,
            short_id=numeric_short_id,
            name="numeric-short-id",
        )

        response = self.client.get(f"/api/projects/{self.team.id}/insights/{numeric_short_id}/")
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.json()["id"], insight.id)
        self.assertEqual(response.json()["short_id"], numeric_short_id)
        self.assertEqual(response.json()["name"], "numeric-short-id")

    def test_basic_results(self) -> None:
        """
        The `skip_results` query parameter can be passed so that only a list of objects is returned, without
        the actual query data. This can speed things up if it's not needed.
        """
        filter_dict = {"events": [{"id": "$pageview"}]}

        Insight.objects.create(
            filters=Filter(data=filter_dict).to_dict(),
            team=self.team,
            short_id="12345678",
        )
        Insight.objects.create(filters=Filter(data=filter_dict).to_dict(), team=self.team, saved=True)

        response = self.client.get(f"/api/projects/{self.team.id}/insights/?basic=true")
        self.assertEqual(response.status_code, status.HTTP_200_OK)

        self.assertEqual(len(response.json()["results"]), 2)
        self.assertEqual(
            set(response.json()["results"][0].keys()),
            {
                "id",
                "short_id",
                "name",
                "derived_name",
                "favorited",
                "filters",
                "query",
                "dashboard_tiles",
                "description",
                "last_refresh",
                "refreshing",
                "saved",
                "updated_at",
                "created_by",
                "created_at",
                "last_modified_at",
                "tags",
                "user_access_level",
                "last_viewed_at",
            },
        )

    def test_saved_filter_returns_saved_or_on_visible_dashboard(self) -> None:
        default_dashboard = Dashboard.objects.create(name="d-default", team=self.team, creation_mode="default")
        template_dashboard = Dashboard.objects.create(name="d-template", team=self.team, creation_mode="template")
        unlisted_dashboard = Dashboard.objects.create(name="d-unlisted", team=self.team, creation_mode="unlisted")

        filters = {"events": [{"id": "$pageview"}]}
        saved_no_dashboard = Insight.objects.create(short_id="ins-sn", saved=True, team=self.team, filters=filters)
        unsaved_on_default = Insight.objects.create(short_id="ins-ud", saved=False, team=self.team, filters=filters)
        unsaved_on_template = Insight.objects.create(short_id="ins-ut", saved=False, team=self.team, filters=filters)
        unsaved_on_unlisted = Insight.objects.create(short_id="ins-uu", saved=False, team=self.team, filters=filters)
        unsaved_no_dashboard = Insight.objects.create(short_id="ins-un", saved=False, team=self.team, filters=filters)

        DashboardTile.objects.create(insight=unsaved_on_default, dashboard=default_dashboard)
        DashboardTile.objects.create(insight=unsaved_on_template, dashboard=template_dashboard)
        DashboardTile.objects.create(insight=unsaved_on_unlisted, dashboard=unlisted_dashboard)

        response = self.client.get(f"/api/projects/{self.team.id}/insights/?saved=true")
        assert response.status_code == status.HTTP_200_OK
        returned = sorted(r["short_id"] for r in response.json()["results"])

        assert returned == sorted(
            [saved_no_dashboard.short_id, unsaved_on_default.short_id, unsaved_on_template.short_id]
        ), (
            f"`saved=true` must return saved insights and unsaved-on-non-unlisted-dashboard insights. "
            f"unsaved-on-unlisted-dashboard ({unsaved_on_unlisted.short_id}) and unsaved-no-dashboard "
            f"({unsaved_no_dashboard.short_id}) must be excluded."
        )

    def test_search_filter_does_not_duplicate_insights_with_multiple_matching_tags(self) -> None:
        from posthog.models.tag import Tag
        from posthog.models.tagged_item import TaggedItem

        insight = Insight.objects.create(
            short_id="search-tg", name="needle", team=self.team, filters={"events": [{"id": "$pageview"}]}
        )
        for tag_name in ("needle-tag-a", "needle-tag-b", "needle-tag-c"):
            tag = Tag.objects.create(name=tag_name, team=self.team)
            TaggedItem.objects.create(insight=insight, tag=tag)

        response = self.client.get(f"/api/projects/{self.team.id}/insights/?search=needle")
        assert response.status_code == status.HTTP_200_OK
        matching_short_ids = [r["short_id"] for r in response.json()["results"] if r["short_id"] == insight.short_id]
        assert len(matching_short_ids) == 1, (
            f"search=needle must return the insight once even though three tags + the name match it; "
            f"got {len(matching_short_ids)} copies."
        )

    @parameterized.expand(
        [
            (
                "exact match wins over partial matches",
                ["Ad Sales", "Email Sales", "Sales", "Sales Funnel", "Weekly Sales", "Unrelated"],
                "Sales",
                "Sales",
                ["Unrelated"],
            ),
            (
                "typo / transposition still matches via trigram",
                ["Dashboard overview", "Unrelated"],
                "dahsboard",
                "Dashboard overview",
                ["Unrelated"],
            ),
            (
                "prefix-as-you-type",
                ["Marketing funnel", "Engineering metrics"],
                "Marke",
                "Marketing funnel",
                ["Engineering metrics"],
            ),
            (
                "case-insensitive: lower",
                ["Revenue by region", "Engineering metrics"],
                "revenue",
                "Revenue by region",
                ["Engineering metrics"],
            ),
            (
                "case-insensitive: upper",
                ["Revenue by region", "Engineering metrics"],
                "REVENUE",
                "Revenue by region",
                ["Engineering metrics"],
            ),
        ]
    )
    def test_list_filter_by_search_relevance(self, _name, insight_names, search, expected_first, excluded):
        for name in insight_names:
            Insight.objects.create(name=name, team=self.team, filters={"events": [{"id": "$pageview"}]})

        response = self.client.get(f"/api/projects/{self.team.id}/insights/?search={search}")
        assert response.status_code == status.HTTP_200_OK
        result_names = [r["name"] for r in response.json()["results"]]

        assert result_names, f"expected at least one match for {search!r}, got nothing"
        assert result_names[0] == expected_first, f"expected {expected_first!r} first, got {result_names}"
        for name in excluded:
            assert name not in result_names, f"expected {name!r} excluded, got {result_names}"

    def test_list_filter_by_search_matches_derived_name(self):
        named = Insight.objects.create(
            name="Marketing funnel", team=self.team, filters={"events": [{"id": "$pageview"}]}
        )
        derived = Insight.objects.create(
            name=None, derived_name="Signup conversion", team=self.team, filters={"events": [{"id": "$pageview"}]}
        )
        Insight.objects.create(name="Unrelated", team=self.team, filters={"events": [{"id": "$pageview"}]})

        response = self.client.get(f"/api/projects/{self.team.id}/insights/?search=signup")
        assert response.status_code == status.HTTP_200_OK
        result_ids = [r["id"] for r in response.json()["results"]]

        assert derived.id in result_ids
        assert named.id not in result_ids

    def test_list_filter_by_search_matches_description_with_lower_rank_than_name(self):
        name_match = Insight.objects.create(name="revenue", team=self.team, filters={"events": [{"id": "$pageview"}]})
        description_match = Insight.objects.create(
            name="Q4 review",
            description="Quarterly revenue breakdown",
            team=self.team,
            filters={"events": [{"id": "$pageview"}]},
        )
        Insight.objects.create(name="Unrelated", team=self.team, filters={"events": [{"id": "$pageview"}]})

        response = self.client.get(f"/api/projects/{self.team.id}/insights/?search=revenue")
        assert response.status_code == status.HTTP_200_OK
        result_ids = [r["id"] for r in response.json()["results"]]

        assert result_ids[:2] == [name_match.id, description_match.id]
        assert all(r["name"] != "Unrelated" for r in response.json()["results"])

    @parameterized.expand(
        [
            ("whitespace-only", "   "),
            ("empty", ""),
        ]
    )
    def test_list_filter_by_search_blank_returns_all(self, _name, search):
        a = Insight.objects.create(name="Alpha", team=self.team, filters={"events": [{"id": "$pageview"}]})
        b = Insight.objects.create(name="Beta", team=self.team, filters={"events": [{"id": "$pageview"}]})

        response = self.client.get(f"/api/projects/{self.team.id}/insights/?search={search}")
        assert response.status_code == status.HTTP_200_OK
        result_ids = {r["id"] for r in response.json()["results"]}

        assert {a.id, b.id}.issubset(result_ids)

    @parameterized.expand(
        [
            ("plain symbols", "&|!"),
            ("sql-injection-shaped", "'; DROP TABLE--"),
        ]
    )
    def test_list_filter_by_search_pathological_input_does_not_500(self, _name, search):
        Insight.objects.create(name="Dashboard overview", team=self.team, filters={"events": [{"id": "$pageview"}]})

        response = self.client.get(f"/api/projects/{self.team.id}/insights/", {"search": search})
        assert response.status_code == status.HTTP_200_OK

    @parameterized.expand(
        [
            ("at cap (200)", 200, status.HTTP_200_OK),
            ("just over cap (201)", 201, status.HTTP_400_BAD_REQUEST),
            ("very long (10k)", 10_000, status.HTTP_400_BAD_REQUEST),
        ]
    )
    def test_list_filter_by_search_enforces_length_cap(self, _name, length, expected_status):
        response = self.client.get(f"/api/projects/{self.team.id}/insights/", {"search": "a" * length})
        assert response.status_code == expected_status

        if expected_status == status.HTTP_400_BAD_REQUEST:
            body = response.json()
            assert body["attr"] == "search", f"expected error scoped to 'search', got {body}"
            assert "200 characters" in body["detail"], f"expected error detail to mention the cap, got {body['detail']}"

    def test_list_filter_by_search_nul_bytes_do_not_500(self):
        Insight.objects.create(name="Alpha", team=self.team, filters={"events": [{"id": "$pageview"}]})
        response = self.client.get(f"/api/projects/{self.team.id}/insights/", {"search": "\x00\x00\x00"})
        assert response.status_code == status.HTTP_200_OK

    def test_list_filter_by_search_explicit_order_overrides_relevance(self):
        older = Insight.objects.create(name="revenue funnel", team=self.team, filters={"events": [{"id": "$pageview"}]})
        newer = Insight.objects.create(name="revenue trends", team=self.team, filters={"events": [{"id": "$pageview"}]})

        response = self.client.get(f"/api/projects/{self.team.id}/insights/", {"search": "revenue", "order": "-id"})
        assert response.status_code == status.HTTP_200_OK
        result_ids = [r["id"] for r in response.json()["results"]]
        assert result_ids.index(newer.id) < result_ids.index(older.id), (
            "explicit order=-id should override relevance ranking and put newer insight first"
        )

    def test_list_filter_by_search_hides_similar_matches_when_exact_matches_exist(self):
        for name in ("dashboard overview", "sales dashboard", "dahsboard metrics", "Engineering metrics"):
            Insight.objects.create(name=name, team=self.team, filters={"events": [{"id": "$pageview"}]})

        # The frontend always sends order=-last_modified_at; the fix must hold under it, since
        # that re-sort is what buried exact matches beneath similar ones in the first place.
        response = self.client.get(f"/api/projects/{self.team.id}/insights/?search=dashboard&order=-last_modified_at")
        assert response.status_code == status.HTTP_200_OK
        results = response.json()["results"]

        match_type_by_name = {r["name"]: r["search_match_type"] for r in results}
        assert match_type_by_name == {
            "dashboard overview": "exact",
            "sales dashboard": "exact",
        }, "similar matches must be hidden when exact matches exist"

    def test_list_filter_by_search_match_type_absent_without_search(self):
        Insight.objects.create(name="Alpha", team=self.team, filters={"events": [{"id": "$pageview"}]})

        response = self.client.get(f"/api/projects/{self.team.id}/insights/")
        assert response.status_code == status.HTTP_200_OK
        results = response.json()["results"]

        assert results
        assert all("search_match_type" not in r for r in results)

    def test_list_filter_by_search_matches_substring_below_trigram_threshold(self):
        matching = Insight.objects.create(
            name="experimentation overview", team=self.team, filters={"events": [{"id": "$pageview"}]}
        )
        Insight.objects.create(name="Totally unrelated", team=self.team, filters={"events": [{"id": "$pageview"}]})

        response = self.client.get(f"/api/projects/{self.team.id}/insights/?search=ment")
        assert response.status_code == status.HTTP_200_OK
        results = response.json()["results"]

        match_type_by_id = {r["id"]: r["search_match_type"] for r in results}
        assert match_type_by_id.get(matching.id) == "exact", (
            "a literal substring must match and be labelled exact even when it scores below the trigram thresholds"
        )
        assert all(r["name"] != "Totally unrelated" for r in results)

    def test_list_filter_by_search_runs_a_single_filtering_query(self):
        for name in ("revenue overview", "reveneu trends", "Unrelated"):
            Insight.objects.create(name=name, team=self.team, filters={"events": [{"id": "$pageview"}]})

        with capture_db_queries() as capture_query_context:
            response = self.client.get(f"/api/projects/{self.team.id}/insights/?search=revenue&basic=true")
            assert response.status_code == status.HTTP_200_OK

        trigram_queries = [q for q in capture_query_context.captured_queries if "word_similarity" in q["sql"].lower()]
        assert len(trigram_queries) <= 2, (
            "search must stay one filtering query (+ pagination count); extra trigram queries mean a per-row or "
            f"per-phase probe crept back in, got {len(trigram_queries)}"
        )

    # :KLUDGE: avoid making extra queries that are explicitly not cached in tests. Avoids false N+1-s.
    @override_settings(PERSON_ON_EVENTS_OVERRIDE=False, PERSON_ON_EVENTS_V2_OVERRIDE=False)
    @snapshot_postgres_queries
    def test_listing_insights_does_not_nplus1(self) -> None:
        query_counts: list[int] = []
        queries = []

        for i in range(5):
            user = User.objects.create(email=f"testuser{i}@posthog.com")
            OrganizationMembership.objects.create(user=user, organization=self.organization)
            dashboard = Dashboard.objects.create(name=f"Dashboard {i}", team=self.team)

            self.dashboard_api.create_insight(
                data={
                    "short_id": f"insight{i}",
                    "dashboards": [dashboard.pk],
                    "filters": {"events": [{"id": "$pageview"}]},
                }
            )

            self.assertEqual(Insight.objects.count(), i + 1)

            with capture_db_queries() as capture_query_context:
                response = self.client.get(f"/api/projects/{self.team.id}/insights?basic=true")
                self.assertEqual(response.status_code, status.HTTP_200_OK)
                self.assertEqual(len(response.json()["results"]), i + 1)

            query_count_for_create_and_read = len(capture_query_context.captured_queries)
            queries.append(capture_query_context.captured_queries)
            query_counts.append(query_count_for_create_and_read)

        # adding more insights doesn't change the query count
        self.assertEqual(
            [12, 12, 12, 12, 12],
            query_counts,
            f"received query counts\n\n{query_counts}",
        )

    @parameterized.expand([("basic_path", "&basic=true"), ("full_path", "")])
    @override_settings(PERSON_ON_EVENTS_OVERRIDE=False, PERSON_ON_EVENTS_V2_OVERRIDE=False)
    def test_listing_insights_with_many_dashboards_per_insight_does_not_nplus1(
        self, _name: str, basic_query_param: str
    ) -> None:
        dashboards = [Dashboard.objects.create(name=f"dashboard {n}", team=self.team) for n in range(3)]

        def _create_insight_with_many_dashboards(short_id: str) -> int:
            insight_id, _ = self.dashboard_api.create_insight(
                data={
                    "short_id": short_id,
                    "dashboards": [d.pk for d in dashboards],
                    "filters": {"events": [{"id": "$pageview"}]},
                }
            )
            soft_deleted_dashboard = Dashboard.objects.create(name=f"deleted dashboard for {short_id}", team=self.team)
            DashboardTile.objects_including_soft_deleted.create(
                dashboard=soft_deleted_dashboard,
                insight_id=insight_id,
                deleted=True,
            )
            return insight_id

        url = f"/api/projects/{self.team.id}/insights/?saved=true&order=-last_modified_at&limit=30{basic_query_param}"

        _create_insight_with_many_dashboards("first")
        with capture_db_queries() as ctx:
            response = self.client.get(url)
            assert response.status_code == status.HTTP_200_OK
            assert len(response.json()["results"]) == 1
        baseline_query_count = len(ctx.captured_queries)

        for n in range(2, 6):
            _create_insight_with_many_dashboards(f"insight-{n}")
            with capture_db_queries() as ctx:
                response = self.client.get(url)
                assert response.status_code == status.HTTP_200_OK
                assert len(response.json()["results"]) == n

            per_insight_m2m_lookups = [
                q
                for q in ctx.captured_queries
                if 'FROM "posthog_dashboardtile"' in q["sql"]
                and 'INNER JOIN "posthog_dashboard"' in q["sql"]
                and '"posthog_dashboardtile"."insight_id" =' in q["sql"]
            ]
            assert per_insight_m2m_lookups == [], (
                f"found {len(per_insight_m2m_lookups)} per-instance M2M `Insight.dashboards` lookups when serialising insights; "
                f"the `dashboards` payload should derive from the prefetched `dashboard_tiles`. SQL samples:\n"
                + "\n".join(q["sql"][:300] for q in per_insight_m2m_lookups[:3])
            )

            assert len(ctx.captured_queries) == baseline_query_count, (
                f"n={n}: {len(ctx.captured_queries)} queries vs baseline {baseline_query_count}; "
                f"adding insights should not grow the per-request query count."
            )

    @override_settings(PERSON_ON_EVENTS_OVERRIDE=False, PERSON_ON_EVENTS_V2_OVERRIDE=False)
    def test_listing_insights_with_alerts_does_not_nplus1(self) -> None:
        url = f"/api/projects/{self.team.id}/insights/?saved=true&limit=30"

        def _create_insight_with_alerts(short_id: str) -> None:
            insight_id, _ = self.dashboard_api.create_insight(
                data={"short_id": short_id, "filters": {"events": [{"id": "$pageview"}]}}
            )
            threshold = Threshold.objects.create(
                team=self.team,
                insight_id=insight_id,
                created_by=self.user,
                configuration={"type": "absolute", "bounds": {"upper": 1}},
            )
            # one threshold alert and one detector alert — AlertSerializer emits threshold and
            # subscribed_users per alert, the two relations that regress to per-alert queries
            for alert_threshold in (threshold, None):
                alert = AlertConfiguration.objects.create(
                    team=self.team,
                    insight_id=insight_id,
                    created_by=self.user,
                    name="alert",
                    threshold=alert_threshold,
                    condition={"type": "absolute_value"},
                    config={"type": "TrendsAlertConfig", "series_index": 0},
                    detector_config=None if alert_threshold else {"type": "zscore", "threshold": 3},
                )
                AlertSubscription.objects.create(user=self.user, alert_configuration=alert, created_by=self.user)

        _create_insight_with_alerts("first")
        with capture_db_queries() as ctx:
            assert self.client.get(url).status_code == status.HTTP_200_OK
        baseline = len(ctx.captured_queries)

        for n in range(2, 5):
            _create_insight_with_alerts(f"insight-{n}")
            with capture_db_queries() as ctx:
                response = self.client.get(url)
                assert response.status_code == status.HTTP_200_OK
                assert len(response.json()["results"]) == n
            assert len(ctx.captured_queries) == baseline, (
                f"n={n}: {len(ctx.captured_queries)} queries vs baseline {baseline}; "
                f"adding insights with alerts should not grow the per-request query count."
            )

    def test_listing_insights_shows_legacy_and_hogql_ones(self) -> None:
        self.dashboard_api.create_insight(
            data={
                "short_id": f"insight",
                "query": {
                    "kind": "DataVisualizationNode",
                    "source": {
                        "kind": "HogQLQuery",
                        "query": "select * from events",
                    },
                },
            }
        )

        self.dashboard_api.create_insight(
            data={
                "short_id": f"insight",
                "filters": {"insight": "TRENDS", "events": [{"id": "$pageview"}]},
            }
        )
        self.dashboard_api.create_insight(
            data={
                "short_id": f"insight",
                "query": InsightVizNode(source=TrendsQuery(series=[EventsNode(event="$pageview")])).model_dump(),
            }
        )

        response = self.client.get(f"/api/environments/{self.team.pk}/insights/?insight=TRENDS")

        self.assertEqual(len(response.json()["results"]), 2)

    def test_listing_insights_by_journeys_type(self) -> None:
        journeys_insight_id, _ = self.dashboard_api.create_insight(
            data={"query": {"kind": "InsightVizNode", "source": {"kind": "PathsV2Query"}}}
        )
        paths_insight_id, _ = self.dashboard_api.create_insight(
            data={"filters": {"insight": "PATHS", "events": [{"id": "$pageview"}]}}
        )

        journeys_response = self.client.get(f"/api/environments/{self.team.pk}/insights/?insight=JOURNEYS")
        assert [insight["id"] for insight in journeys_response.json()["results"]] == [journeys_insight_id]

        paths_response = self.client.get(f"/api/environments/{self.team.pk}/insights/?insight=PATHS")
        assert [insight["id"] for insight in paths_response.json()["results"]] == [paths_insight_id]

    def test_can_list_insights_by_which_dashboards_they_are_in(self) -> None:
        insight_one_id, _ = self.dashboard_api.create_insight(
            {"name": "insight 1", "filters": {"events": [{"id": "$pageview"}]}}
        )
        insight_two_id, _ = self.dashboard_api.create_insight(
            {"name": "insight 2", "filters": {"events": [{"id": "$pageview"}]}}
        )
        insight_three_id, _ = self.dashboard_api.create_insight(
            {"name": "insight 3", "filters": {"events": [{"id": "$pageview"}]}}
        )

        dashboard_one_id, _ = self.dashboard_api.create_dashboard(
            {"name": "dashboard 1", "filters": {"date_from": "-180d"}}
        )
        dashboard_two_id, _ = self.dashboard_api.create_dashboard(
            {"name": "dashboard 1", "filters": {"date_from": "-180d"}}
        )
        self.dashboard_api.add_insight_to_dashboard([dashboard_one_id], insight_one_id)
        self.dashboard_api.add_insight_to_dashboard([dashboard_one_id, dashboard_two_id], insight_two_id)

        any_on_dashboard_one = self.client.get(
            f"/api/projects/{self.team.id}/insights/?dashboards=[{dashboard_one_id}]"
        )
        self.assertEqual(any_on_dashboard_one.status_code, status.HTTP_200_OK)
        matched_insights = [insight["id"] for insight in any_on_dashboard_one.json()["results"]]
        assert sorted(matched_insights) == [insight_one_id, insight_two_id]

        # match is AND, not OR
        any_on_dashboard_one_and_two = self.client.get(
            f"/api/projects/{self.team.id}/insights/?dashboards=[{dashboard_one_id}, {dashboard_two_id}]"
        )
        self.assertEqual(any_on_dashboard_one_and_two.status_code, status.HTTP_200_OK)
        matched_insights = [insight["id"] for insight in any_on_dashboard_one_and_two.json()["results"]]
        assert matched_insights == [insight_two_id]

        # respects deleted tiles
        self.dashboard_api.update_insight(insight_two_id, {"dashboards": []})  # remove from all dashboards

        any_on_dashboard_one = self.client.get(
            f"/api/projects/{self.team.id}/insights/?dashboards=[{dashboard_one_id}]"
        )
        self.assertEqual(any_on_dashboard_one.status_code, status.HTTP_200_OK)
        matched_insights = [insight["id"] for insight in any_on_dashboard_one.json()["results"]]
        assert sorted(matched_insights) == [insight_one_id]

    @freeze_time("2012-01-14T03:21:34.000Z")
    def test_create_insight_items(self) -> None:
        response = self.client.post(
            f"/api/projects/{self.team.id}/insights",
            data={
                "name": "a created dashboard",
                "filters": {
                    "events": [{"id": "$pageview"}],
                    "properties": [{"key": "$browser", "value": "Mac OS X"}],
                    "date_from": "-90d",
                },
            },
        )
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        response_data = response.json()
        self.assertEqual(response_data["description"], None)
        self.assertEqual(response_data["tags"], [])

        objects = Insight.objects.all()
        self.assertEqual(objects.count(), 1)
        self.assertEqual(objects[0].filters["events"][0]["id"], "$pageview")
        self.assertEqual(objects[0].filters["date_from"], "-90d")
        self.assertEqual(len(objects[0].short_id), 8)

        self.assert_insight_activity(
            response_data["id"],
            [
                {
                    "user": {"first_name": "", "email": "user1@posthog.com"},
                    "activity": "created",
                    "created_at": "2012-01-14T03:21:34Z",
                    "scope": "Insight",
                    "item_id": str(response_data["id"]),
                    "detail": {
                        "changes": None,
                        "trigger": None,
                        "type": None,
                        "name": "a created dashboard",
                        "short_id": response_data["short_id"],
                    },
                }
            ],
        )

    @freeze_time("2012-01-14T03:21:34.000Z")
    def test_create_insight_with_no_names_logs_no_activity(self) -> None:
        response = self.client.post(
            f"/api/projects/{self.team.id}/insights",
            data={
                "filters": {
                    "events": [{"id": "$pageview"}],
                    "properties": [{"key": "$browser", "value": "Mac OS X"}],
                    "date_from": "-90d",
                }
            },
        )
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        response_data = response.json()
        self.assertEqual(response_data["name"], None)
        self.assertEqual(response_data["derived_name"], None)

        self.assert_insight_activity(response_data["id"], [])

    def test_create_insight_items_on_a_dashboard(self) -> None:
        dashboard_id, _ = self.dashboard_api.create_dashboard({})

        insight_id, _ = self.dashboard_api.create_insight(
            {
                "filters": {
                    "events": [{"id": "$pageview"}],
                    "properties": [{"key": "$browser", "value": "Mac OS X"}],
                    "date_from": "-90d",
                },
                "dashboards": [dashboard_id],
            }
        )

        tile: DashboardTile = DashboardTile.objects.get(dashboard__id=dashboard_id, insight__id=insight_id)
        self.assertIsNotNone(tile)

    def test_insight_items_on_a_dashboard_ignore_deleted_dashboards(self) -> None:
        dashboard_id, _ = self.dashboard_api.create_dashboard({})
        deleted_dashboard_id, _ = self.dashboard_api.create_dashboard({})

        insight_id, _ = self.dashboard_api.create_insight(
            {
                "filters": {
                    "events": [{"id": "$pageview"}],
                    "properties": [{"key": "$browser", "value": "Mac OS X"}],
                    "date_from": "-90d",
                },
                "dashboards": [dashboard_id, deleted_dashboard_id],
            }
        )

        self.dashboard_api.update_dashboard(deleted_dashboard_id, {"deleted": True})

        insight_json = self.dashboard_api.get_insight(insight_id)
        assert insight_json["dashboard_tiles"] == [{"id": mock.ANY, "deleted": None, "dashboard_id": dashboard_id}]

        new_dashboard_id, _ = self.dashboard_api.create_dashboard({})
        # accidentally include a deleted dashboard
        _, update_response = self.dashboard_api.update_insight(
            insight_id,
            {"dashboards": [dashboard_id, deleted_dashboard_id, new_dashboard_id]},
            expected_status=status.HTTP_400_BAD_REQUEST,
        )

        insight_json = self.dashboard_api.get_insight(insight_id)
        assert insight_json["dashboard_tiles"] == [{"id": mock.ANY, "deleted": None, "dashboard_id": dashboard_id}]

    def test_insight_items_on_a_dashboard_ignore_deleted_dashboard_tiles(self) -> None:
        dashboard_id, _ = self.dashboard_api.create_dashboard({})

        insight_id, insight_json = self.dashboard_api.create_insight(
            {
                "filters": {
                    "events": [{"id": "$pageview"}],
                    "properties": [{"key": "$browser", "value": "Mac OS X"}],
                    "date_from": "-90d",
                },
                "dashboards": [dashboard_id],
            }
        )

        tile: DashboardTile = DashboardTile.objects.get(insight_id=insight_id, dashboard_id=dashboard_id)
        tile.deleted = True
        tile.save()

        insight_json = self.dashboard_api.get_insight(insight_id)
        assert insight_json["dashboard_tiles"] == []

        insight_by_short_id = self.client.get(
            f"/api/projects/{self.team.pk}/insights?short_id={insight_json['short_id']}"
        )
        assert insight_by_short_id.json()["results"][0]["dashboard_tiles"] == []

        self.dashboard_api.add_insight_to_dashboard([dashboard_id], insight_id)

        insight_json = self.dashboard_api.get_insight(insight_id)
        assert insight_json["dashboard_tiles"] == [{"id": mock.ANY, "deleted": False, "dashboard_id": dashboard_id}]

    def test_can_update_insight_with_inconsistent_dashboards(self) -> None:
        """
        Regression test because there are some DashboardTiles in production that should not exist.
        Which were created before Tiles were deleted when dashboards are soft deleted
        """
        dashboard_id, _ = self.dashboard_api.create_dashboard({})
        deleted_dashboard_id, _ = self.dashboard_api.create_dashboard({})

        insight_id, _ = self.dashboard_api.create_insight(
            {
                "name": "the insight",
                "dashboards": [dashboard_id, deleted_dashboard_id],
            }
        )

        # update outside of API so that DashboardTile still exists
        dashboard_in_db = Dashboard.objects.get(id=deleted_dashboard_id)
        dashboard_in_db.deleted = True
        dashboard_in_db.save(update_fields=["deleted"])

        assert not DashboardTile.objects.filter(dashboard_id=deleted_dashboard_id).exists()
        assert DashboardTile.objects_including_soft_deleted.filter(dashboard_id=deleted_dashboard_id).exists()

        insight_json = self.dashboard_api.get_insight(insight_id)
        assert insight_json["dashboard_tiles"] == [{"id": mock.ANY, "deleted": None, "dashboard_id": dashboard_id}]

        # accidentally include a deleted dashboard
        _, update_response = self.dashboard_api.update_insight(
            insight_id,
            {"dashboards": [deleted_dashboard_id]},
            expected_status=status.HTTP_400_BAD_REQUEST,
        )

        # confirm no updates happened
        insight_json = self.dashboard_api.get_insight(insight_id)
        assert insight_json["dashboard_tiles"] == [{"id": mock.ANY, "deleted": None, "dashboard_id": dashboard_id}]

    def test_dashboards_relation_is_tile_soft_deletion_aware(self) -> None:
        dashboard_one_id, _ = self.dashboard_api.create_dashboard({"name": "dash 1"})
        dashboard_two_id, _ = self.dashboard_api.create_dashboard({"name": "dash 2"})

        insight_id, insight_json = self.dashboard_api.create_insight(
            {
                "name": "start with two dashboards",
                "dashboards": [dashboard_one_id, dashboard_two_id],
            }
        )

        # then remove from one of them
        _, on_update_insight_json = self.dashboard_api.update_insight(
            insight_id,
            {
                "dashboards": [dashboard_one_id],
            },
        )
        assert "dashboards" not in on_update_insight_json
        assert on_update_insight_json["dashboard_tiles"] == [
            {"id": mock.ANY, "deleted": None, "dashboard_id": dashboard_one_id}
        ]

        insight_json = self.dashboard_api.get_insight(insight_id)
        assert insight_json["dashboard_tiles"] == [{"id": mock.ANY, "deleted": None, "dashboard_id": dashboard_one_id}]

        insights_list = self.dashboard_api.list_insights()
        assert insights_list["count"] == 1
        assert [i["dashboard_tiles"] for i in insights_list["results"]] == [
            [
                {
                    "dashboard_id": dashboard_one_id,
                    "deleted": None,
                    "id": mock.ANY,
                }
            ]
        ]

    def test_adding_insight_to_dashboard_updates_activity_log(self) -> None:
        dashboard_one_id, _ = self.dashboard_api.create_dashboard({"name": "dash 1"})
        dashboard_two_id, _ = self.dashboard_api.create_dashboard({"name": "dash 2"})

        insight_id, insight_json = self.dashboard_api.create_insight(
            {
                "name": "have to have a name to hit the activity log",
                "dashboards": [dashboard_one_id, dashboard_two_id],
            }
        )

        # then remove from one of them
        self.dashboard_api.update_insight(
            insight_id,
            {
                "dashboards": [dashboard_one_id],
            },
        )

        # then add one
        self.dashboard_api.update_insight(
            insight_id,
            {
                "dashboards": [dashboard_one_id, dashboard_two_id],
            },
        )

        self.assert_insight_activity(
            # expected activity is
            # * added dash 2
            # * removed dash 2
            # * created insight
            insight_id,
            [
                {
                    "activity": "updated",
                    "created_at": mock.ANY,
                    "detail": {
                        "changes": [
                            {
                                "action": "changed",
                                "before": [{"id": dashboard_one_id, "name": "dash 1"}],
                                "after": [
                                    {"id": dashboard_one_id, "name": "dash 1"},
                                    {"id": dashboard_two_id, "name": "dash 2"},
                                ],
                                "field": "dashboards",
                                "type": "Insight",
                            },
                        ],
                        "name": "have to have a name to hit the activity log",
                        "short_id": insight_json["short_id"],
                        "trigger": None,
                        "type": None,
                    },
                    "item_id": str(insight_id),
                    "scope": "Insight",
                    "user": {"email": "user1@posthog.com", "first_name": ""},
                },
                {
                    "activity": "updated",
                    "created_at": mock.ANY,
                    "detail": {
                        "changes": [
                            {
                                "action": "changed",
                                "before": [
                                    {"id": dashboard_one_id, "name": "dash 1"},
                                    {"id": dashboard_two_id, "name": "dash 2"},
                                ],
                                "after": [{"id": dashboard_one_id, "name": "dash 1"}],
                                "field": "dashboards",
                                "type": "Insight",
                            },
                        ],
                        "name": "have to have a name to hit the activity log",
                        "short_id": insight_json["short_id"],
                        "trigger": None,
                        "type": None,
                    },
                    "item_id": str(insight_id),
                    "scope": "Insight",
                    "user": {"email": "user1@posthog.com", "first_name": ""},
                },
                {
                    "activity": "created",
                    "created_at": mock.ANY,
                    "detail": {
                        "changes": None,
                        "name": "have to have a name to hit the activity log",
                        "short_id": insight_json["short_id"],
                        "trigger": None,
                        "type": None,
                    },
                    "item_id": str(insight_id),
                    "scope": "Insight",
                    "user": {"email": "user1@posthog.com", "first_name": ""},
                },
            ],
        )

    @parameterized.expand(
        [
            ("legacy_filters_funnels", {"insight": "FUNNELS"}, None, "funnels"),
            (
                "query_trends",
                None,
                InsightVizNode(source=TrendsQuery(series=[EventsNode(event="$pageview")])).model_dump(),
                "trends",
            ),
        ]
    )
    @patch("products.product_analytics.backend.presentation.insight.report_user_action")
    def test_creating_insight_with_dashboard_fires_tile_added_event(
        self,
        _name: str,
        filters: dict | None,
        query: dict | None,
        expected_insight_type: str,
        mock_report_user_action: mock.Mock,
    ) -> None:
        dashboard_id, _ = self.dashboard_api.create_dashboard({"name": "test"})
        mock_report_user_action.reset_mock()

        data: dict = {"dashboards": [dashboard_id]}
        if filters:
            data["filters"] = filters
        if query:
            data["query"] = query
        self.dashboard_api.create_insight(data)

        mock_report_user_action.assert_any_call(
            self.user,
            "dashboard tile added",
            {"tile_type": "insight", "insight_type": expected_insight_type, "dashboard_id": dashboard_id},
            team=ANY,
            request=ANY,
        )

    @patch("posthog.resource_limits.evaluator.report_user_action")
    @patch("products.product_analytics.backend.presentation.insight.active_tile_count", return_value=99)
    def test_insight_dashboard_limit_includes_dashboard_context(
        self, _mock_active_tile_count: mock.Mock, mock_report_user_action: mock.Mock
    ) -> None:
        dashboard_id, _ = self.dashboard_api.create_dashboard({"name": "Important dashboard"})

        self.dashboard_api.create_insight({"filters": {"insight": "TRENDS"}, "dashboards": [dashboard_id]})

        limit_call = next(
            call for call in mock_report_user_action.call_args_list if call.args[1] == "resource limit hit"
        )
        assert limit_call.args[2]["dashboard_id"] == dashboard_id
        assert limit_call.args[2]["dashboard_name"] == "Important dashboard"

    @patch("products.product_analytics.backend.presentation.insight.report_user_action")
    def test_adding_insight_to_dashboard_fires_tile_added_event(self, mock_report_user_action: mock.Mock) -> None:
        dashboard_id, _ = self.dashboard_api.create_dashboard({"name": "test"})
        insight_id, _ = self.dashboard_api.create_insight({"filters": {"insight": "STICKINESS"}})
        mock_report_user_action.reset_mock()

        self.dashboard_api.add_insight_to_dashboard([dashboard_id], insight_id)

        mock_report_user_action.assert_any_call(
            self.user,
            "dashboard tile added",
            {"tile_type": "insight", "insight_type": "stickiness", "dashboard_id": dashboard_id},
            team=ANY,
            request=ANY,
        )

    @patch("products.product_analytics.backend.presentation.insight.report_user_action")
    def test_non_web_retrieve_fires_insight_read_event(self, mock_report_user_action: mock.Mock) -> None:
        insight_id, insight_json = self.dashboard_api.create_insight(
            {"query": DataVisualizationNode(source=HogQLQuery(query="select 1")).model_dump()}
        )
        mock_report_user_action.reset_mock()

        self.client.get(f"/api/projects/{self.team.id}/insights/{insight_id}", HTTP_X_POSTHOG_CLIENT="mcp")

        mock_report_user_action.assert_any_call(
            self.user,
            "insight read",
            {
                "insight_id": insight_json["short_id"],
                "query_kind": "DataVisualizationNode",
                "query_source_kind": "HogQLQuery",
            },
            team=ANY,
            request=ANY,
        )

    @patch("products.product_analytics.backend.presentation.insight.report_user_action")
    def test_removing_insight_from_dashboard_fires_tile_removed_event(self, mock_report_user_action: mock.Mock) -> None:
        dashboard_id, _ = self.dashboard_api.create_dashboard({"name": "test"})
        insight_id, _ = self.dashboard_api.create_insight(
            {"filters": {"insight": "STICKINESS"}, "dashboards": [dashboard_id]}
        )
        mock_report_user_action.reset_mock()

        self.dashboard_api.update_insight(insight_id, {"dashboards": []})

        mock_report_user_action.assert_any_call(
            self.user,
            "dashboard tile removed",
            {"tile_type": "insight", "insight_type": "stickiness", "dashboard_id": dashboard_id},
            team=ANY,
            request=ANY,
        )

    @patch("products.product_analytics.backend.presentation.insight.report_user_action")
    def test_web_retrieve_does_not_fire_insight_read_event(self, mock_report_user_action: mock.Mock) -> None:
        insight_id, _ = self.dashboard_api.create_insight({})
        mock_report_user_action.reset_mock()

        self.client.get(f"/api/projects/{self.team.id}/insights/{insight_id}")

        read_calls = [c for c in mock_report_user_action.call_args_list if c.args[1:2] == ("insight read",)]
        self.assertEqual(read_calls, [])

    def test_can_update_insight_dashboards_without_deleting_tiles(self) -> None:
        dashboard_one_id, _ = self.dashboard_api.create_dashboard({})
        dashboard_two_id, _ = self.dashboard_api.create_dashboard({})

        insight_id, _ = self.dashboard_api.create_insight(
            {
                "dashboards": [dashboard_one_id, dashboard_two_id],
            }
        )

        self.dashboard_api.set_tile_layout(dashboard_one_id, 1)

        dashboard_one_json = self.dashboard_api.get_dashboard(dashboard_one_id)
        original_tiles = dashboard_one_json["tiles"]

        # update the insight without changing anything
        self.dashboard_api.update_insight(
            insight_id,
            {
                "dashboards": [dashboard_one_id, dashboard_two_id],
            },
        )

        dashboard_one_json = self.dashboard_api.get_dashboard(dashboard_one_id)
        after_update_tiles = dashboard_one_json["tiles"]

        assert [t["id"] for t in original_tiles] == [t["id"] for t in after_update_tiles]
        assert after_update_tiles[0]["layouts"] is not None

        # update the insight, removing a tile
        self.dashboard_api.update_insight(
            insight_id,
            {
                "dashboards": [dashboard_one_id],
            },
        )

        dashboard_one_json = self.dashboard_api.get_dashboard(dashboard_one_id)
        after_update_tiles = dashboard_one_json["tiles"]

        assert len(after_update_tiles) == 1
        assert original_tiles[0]["id"] == after_update_tiles[0]["id"]  # tile has not been recreated in DB
        assert after_update_tiles[0]["layouts"] is not None  # tile has not been recreated in DB
        assert original_tiles[0]["insight"]["id"] == after_update_tiles[0]["insight"]["id"]
        assert sorted(t["dashboard_id"] for t in original_tiles[0]["insight"]["dashboard_tiles"]) == sorted(
            [dashboard_one_id, dashboard_two_id]
        )
        assert [t["dashboard_id"] for t in after_update_tiles[0]["insight"]["dashboard_tiles"]] == [
            dashboard_one_id
        ]  # removed dashboard is removed

    @freeze_time("2012-01-14T03:21:34.000Z")
    def test_create_insight_logs_derived_name_if_there_is_no_name(self) -> None:
        response = self.client.post(
            f"/api/projects/{self.team.id}/insights",
            data={
                "derived_name": "pageview unique users",
                "filters": {
                    "events": [{"id": "$pageview"}],
                    "properties": [{"key": "$browser", "value": "Mac OS X"}],
                    "date_from": "-90d",
                },
            },
        )
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        response_data = response.json()
        self.assertEqual(response_data["derived_name"], "pageview unique users")

        self.assert_insight_activity(
            response_data["id"],
            [
                {
                    "user": {"first_name": "", "email": "user1@posthog.com"},
                    "activity": "created",
                    "created_at": "2012-01-14T03:21:34Z",
                    "scope": "Insight",
                    "item_id": str(response_data["id"]),
                    "detail": {
                        "changes": None,
                        "trigger": None,
                        "type": None,
                        "name": "pageview unique users",
                        "short_id": response_data["short_id"],
                    },
                }
            ],
        )

    def test_update_insight(self) -> None:
        with freeze_time("2012-01-14T03:21:34.000Z") as frozen_time:
            insight_id, insight = self.dashboard_api.create_insight({"name": "insight name"})
            short_id = insight["short_id"]

            frozen_time.tick(delta=timedelta(minutes=10))

            response = self.client.patch(
                f"/api/projects/{self.team.id}/insights/{insight_id}",
                {"name": "insight new name", "tags": ["add", "these", "tags"]},
            )
            self.assertEqual(response.status_code, status.HTTP_200_OK)

            response_data = response.json()
            self.assertEqual(response_data["name"], "insight new name")
            self.assertEqual(sorted(response_data["tags"]), ["add", "tags", "these"])
            self.assertEqual(response_data["created_by"]["distinct_id"], self.user.distinct_id)
            self.assertEqual(
                response_data["effective_restriction_level"],
                Dashboard.RestrictionLevel.EVERYONE_IN_PROJECT_CAN_EDIT,
            )
            self.assertEqual(
                response_data["effective_privilege_level"],
                Dashboard.PrivilegeLevel.CAN_EDIT,
            )

            response = self.client.get(f"/api/projects/{self.team.id}/insights/{insight_id}")

            self.assertEqual(response.json()["name"], "insight new name")

            self.assert_insight_activity(
                insight_id,
                [
                    {
                        "user": {"first_name": "", "email": "user1@posthog.com"},
                        "activity": "updated",
                        "scope": "Insight",
                        "item_id": str(insight_id),
                        "detail": {
                            "changes": [
                                {
                                    "type": "Insight",
                                    "action": "changed",
                                    "field": "tags",
                                    "before": [],
                                    "after": ["add", "tags", "these"],
                                },
                                {
                                    "type": "Insight",
                                    "action": "changed",
                                    "field": "name",
                                    "before": "insight name",
                                    "after": "insight new name",
                                },
                            ],
                            "trigger": None,
                            "type": None,
                            "name": "insight new name",
                            "short_id": short_id,
                        },
                        "created_at": "2012-01-14T03:31:34Z",
                    },
                    {
                        "user": {"first_name": "", "email": "user1@posthog.com"},
                        "activity": "created",
                        "scope": "Insight",
                        "item_id": str(insight_id),
                        "detail": {
                            "changes": None,
                            "trigger": None,
                            "type": None,
                            "name": "insight name",
                            "short_id": short_id,
                        },
                        "created_at": "2012-01-14T03:21:34Z",
                    },
                ],
            )

    def test_cannot_set_filters_hash_via_api(self) -> None:
        insight_id, insight = self.dashboard_api.create_insight({"name": "should not update the filters_hash"})
        original_filters_hash = insight["filters_hash"]
        self.assertIsNotNone(original_filters_hash)

        response = self.client.patch(
            f"/api/projects/{self.team.id}/insights/{insight_id}",
            {"filters_hash": "should not update the value"},
        )
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.json()["filters_hash"], original_filters_hash)

    @skip("Compatibility issue caused by test account filters")
    def test_update_insight_filters(self) -> None:
        insight = Insight.objects.create(
            team=self.team,
            name="insight with custom filters",
            created_by=self.user,
            filters={"events": [{"id": "$pageview"}]},
        )

        for custom_name, expected_name in zip(
            ["Custom filter", 100, "", "  ", None],
            ["Custom filter", "100", None, None, None],
        ):
            response = self.client.patch(
                f"/api/projects/{self.team.id}/insights/{insight.id}",
                {"filters": {"events": [{"id": "$pageview", "custom_name": custom_name}]}},
            )

            self.assertEqual(response.status_code, status.HTTP_200_OK)

            response_data = response.json()
            self.assertEqual(response_data["filters"]["events"][0]["custom_name"], expected_name)
            insight.refresh_from_db()
            self.assertEqual(insight.filters["events"][0]["custom_name"], expected_name)

    def test_save_new_funnel(self) -> None:
        dashboard = Dashboard.objects.create(name="My Dashboard", team=self.team)

        response = self.client.post(
            f"/api/projects/{self.team.id}/insights",
            data={
                "filters": {
                    "insight": "FUNNELS",
                    "events": [
                        {
                            "id": "$pageview",
                            "math": None,
                            "name": "$pageview",
                            "type": "events",
                            "order": 0,
                            "properties": [],
                            "math_hogql": None,
                            "math_property": None,
                        },
                        {
                            "id": "$rageclick",
                            "math": None,
                            "name": "$rageclick",
                            "type": "events",
                            "order": 2,
                            "properties": [],
                            "math_hogql": None,
                            "math_property": None,
                        },
                    ],
                    "display": "FunnelViz",
                    "interval": "day",
                    "date_from": "-30d",
                    "actions": [],
                    "new_entity": [],
                    "layout": "horizontal",
                },
                "name": "My Funnel One",
                "dashboard": dashboard.pk,
            },
        )
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)

        objects = Insight.objects.all()
        self.assertEqual(objects.count(), 1)
        self.assertEqual(objects[0].filters["events"][1]["id"], "$rageclick")
        self.assertEqual(objects[0].filters["display"], "FunnelViz")
        self.assertEqual(objects[0].filters["interval"], "day")
        self.assertEqual(objects[0].filters["date_from"], "-30d")
        self.assertEqual(objects[0].filters["layout"], "horizontal")
        self.assertEqual(len(objects[0].short_id), 8)

    def test_insight_refreshing_legacy_conversion(self) -> None:
        dashboard_id, _ = self.dashboard_api.create_dashboard({"filters": {"date_from": "-14d"}})

        with freeze_time("2012-01-14T03:21:34.000Z"):
            _create_event(
                team=self.team,
                event="$pageview",
                distinct_id="1",
                properties={"prop": "val"},
            )
            _create_event(
                team=self.team,
                event="$pageview",
                distinct_id="2",
                properties={"prop": "another_val"},
            )
            _create_event(
                team=self.team,
                event="$pageview",
                distinct_id="2",
                properties={"prop": "val", "another": "never_return_this"},
            )

        with freeze_time("2012-01-15T04:01:34.000Z"):
            response = self.client.post(
                f"/api/projects/{self.team.id}/insights",
                data={
                    "filters": {
                        "events": [{"id": "$pageview"}],
                        "properties": [
                            {
                                "key": "another",
                                "value": "never_return_this",
                                "operator": "is_not",
                            }
                        ],
                    },
                    "dashboards": [dashboard_id],
                },
            ).json()
            self.assertEqual(response["last_refresh"], None)

            response = self.client.get(f"/api/projects/{self.team.id}/insights/{response['id']}/?refresh=true").json()
            self.assertEqual(response["result"][0]["data"], [0, 0, 0, 0, 0, 0, 2, 0])
            self.assertEqual(response["last_refresh"], "2012-01-15T04:01:34Z")
            self.assertEqual(response["last_modified_at"], "2012-01-15T04:01:34Z")

        with freeze_time("2012-01-15T05:01:34.000Z"):
            _create_event(team=self.team, event="$pageview", distinct_id="1")
            response = self.client.get(f"/api/projects/{self.team.id}/insights/{response['id']}/?refresh=true").json()
            self.assertEqual(response["result"][0]["data"], [0, 0, 0, 0, 0, 0, 2, 1])
            self.assertEqual(response["last_refresh"], "2012-01-15T05:01:34Z")
            self.assertEqual(response["last_modified_at"], "2012-01-15T04:01:34Z")  # did not change

        with freeze_time("2012-01-16T05:01:34.000Z"):
            # load it in the context of the dashboard, so has last 14 days as filter
            response = self.client.get(
                f"/api/projects/{self.team.id}/insights/{response['id']}/?refresh=true&from_dashboard={dashboard_id}"
            ).json()
            self.assertEqual(
                response["result"][0]["data"],
                [
                    0.0,
                    0.0,
                    0.0,
                    0.0,
                    0.0,
                    0.0,
                    0.0,
                    0.0,
                    0.0,
                    0.0,
                    0.0,
                    0.0,
                    2.0,
                    1.0,
                    0.0,
                ],
            )
            self.assertEqual(response["last_refresh"], "2012-01-16T05:01:34Z")
            self.assertEqual(response["last_modified_at"], "2012-01-15T04:01:34Z")  # did not change

        with freeze_time("2012-01-25T05:01:34.000Z"):
            response = self.client.get(f"/api/projects/{self.team.id}/insights/{response['id']}/").json()
            self.assertEqual(response["last_refresh"], None)
            self.assertEqual(response["last_modified_at"], "2012-01-15T04:01:34Z")  # did not change

        #  Test property filter

        dashboard = Dashboard.objects.get(pk=dashboard_id)
        dashboard.filters = {
            "properties": [{"key": "prop", "value": "val"}],
            "date_from": "-14d",
        }
        dashboard.save()
        with freeze_time("2012-01-16T05:01:34.000Z"):
            response = self.client.get(
                f"/api/projects/{self.team.id}/insights/{response['id']}/?refresh=true&from_dashboard={dashboard_id}"
            ).json()
            self.assertEqual(
                response["result"][0]["data"],
                [
                    0.0,
                    0.0,
                    0.0,
                    0.0,
                    0.0,
                    0.0,
                    0.0,
                    0.0,
                    0.0,
                    0.0,
                    0.0,
                    0.0,
                    1.0,
                    0.0,
                    0.0,
                ],
            )

    @parameterized.expand(
        [
            [  # Property group filter, which is what's actually used these days
                PropertyGroupFilter(
                    type=FilterLogicalOperator.AND_,
                    values=[
                        PropertyGroupFilterValue(
                            type=FilterLogicalOperator.OR_,
                            values=[EventPropertyFilter(key="another", value="never_return_this", operator="is_not")],
                        )
                    ],
                )
            ],
            [  # Classic list of filters
                [EventPropertyFilter(key="another", value="never_return_this", operator="is_not")]
            ],
        ]
    )
    @patch("posthog.hogql_queries.insights.trends.trends_query_runner.execute_hogql_query", wraps=execute_hogql_query)
    def test_insight_refreshing_query(self, properties_filter, spy_execute_hogql_query) -> None:
        dashboard_id, _ = self.dashboard_api.create_dashboard({"filters": {"date_from": "-14d"}})

        with freeze_time("2012-01-14T03:21:34.000Z"):
            _create_event(
                team=self.team,
                event="$pageview",
                distinct_id="1",
                properties={"prop": "val"},
            )
            _create_event(
                team=self.team,
                event="$pageview",
                distinct_id="2",
                properties={"prop": "another_val"},
            )
            _create_event(
                team=self.team,
                event="$pageview",
                distinct_id="2",
                properties={"prop": "val", "another": "never_return_this"},
            )

        query_dict = TrendsQuery(
            series=[
                EventsNode(
                    event="$pageview",
                )
            ],
            properties=properties_filter,
        ).model_dump()

        with freeze_time("2012-01-15T04:01:34.000Z"):
            response = self.client.post(
                f"/api/projects/{self.team.id}/insights",
                data={
                    "query": query_dict,
                    "dashboards": [dashboard_id],
                },
            ).json()
            self.assertNotIn("code", response)  # Watching out for an error code
            self.assertEqual(response["last_refresh"], None)
            insight_id = response["id"]

            response = self.client.get(f"/api/projects/{self.team.id}/insights/{insight_id}/?refresh=true").json()
            self.assertNotIn("code", response)
            self.assertEqual(spy_execute_hogql_query.call_count, 1)
            self.assertEqual(response["result"][0]["data"], [0, 0, 0, 0, 0, 0, 2, 0])
            self.assertEqual(response["last_refresh"], "2012-01-15T04:01:34Z")
            self.assertEqual(response["last_modified_at"], "2012-01-15T04:01:34Z")
            self.assertFalse(response["is_cached"])

        with freeze_time("2012-01-15T05:01:34.000Z"):
            _create_event(team=self.team, event="$pageview", distinct_id="1")
            response = self.client.get(f"/api/projects/{self.team.id}/insights/{insight_id}/?refresh=true").json()
            self.assertNotIn("code", response)
            self.assertEqual(spy_execute_hogql_query.call_count, 2)
            self.assertEqual(response["result"][0]["data"], [0, 0, 0, 0, 0, 0, 2, 1])
            self.assertEqual(response["last_refresh"], "2012-01-15T05:01:34Z")
            self.assertEqual(response["last_modified_at"], "2012-01-15T04:01:34Z")  # did not change
            self.assertFalse(response["is_cached"])

        with freeze_time("2012-01-15T05:17:34.000Z"):
            response = self.client.get(f"/api/projects/{self.team.id}/insights/{insight_id}/").json()
            self.assertNotIn("code", response)
            self.assertEqual(spy_execute_hogql_query.call_count, 2)
            self.assertEqual(response["result"][0]["data"], [0, 0, 0, 0, 0, 0, 2, 1])
            self.assertEqual(response["last_refresh"], "2012-01-15T05:01:34Z")  # Using cached result
            self.assertEqual(response["last_modified_at"], "2012-01-15T04:01:34Z")  # did not change
            self.assertTrue(response["is_cached"])

        with freeze_time("2012-01-15T05:17:39.000Z"):
            # Make sure the /query/ endpoint reuses the same cached result
            response = self.client.post(f"/api/projects/{self.team.id}/query/", {"query": query_dict}).json()
            self.assertNotIn("code", response)
            self.assertEqual(spy_execute_hogql_query.call_count, 2)
            self.assertEqual(response["results"][0]["data"], [0, 0, 0, 0, 0, 0, 2, 1])
            self.assertEqual(response["last_refresh"], "2012-01-15T05:01:34Z")  # Using cached result
            self.assertTrue(response["is_cached"])

        with freeze_time("2012-01-16T05:01:34.000Z"):
            # load it in the context of the dashboard, so has last 14 days as filter
            response = self.client.get(
                f"/api/projects/{self.team.id}/insights/{insight_id}/?refresh=true&from_dashboard={dashboard_id}"
            ).json()
            self.assertNotIn("code", response)
            self.assertEqual(spy_execute_hogql_query.call_count, 3)
            self.assertEqual(
                response["result"][0]["data"],
                [
                    0.0,
                    0.0,
                    0.0,
                    0.0,
                    0.0,
                    0.0,
                    0.0,
                    0.0,
                    0.0,
                    0.0,
                    0.0,
                    0.0,
                    2.0,
                    1.0,
                    0.0,
                ],
            )
            self.assertEqual(response["last_refresh"], "2012-01-16T05:01:34Z")
            self.assertEqual(response["last_modified_at"], "2012-01-15T04:01:34Z")  # did not change
            self.assertFalse(response["is_cached"])

        #  Test property filter

        Dashboard.objects.update(
            id=dashboard_id,
            filters={
                "properties": [{"key": "prop", "value": "val"}],
                "date_from": "-14d",
            },
        )
        with freeze_time("2012-01-16T05:01:34.000Z"):
            response = self.client.get(
                f"/api/projects/{self.team.id}/insights/{insight_id}/?refresh=true&from_dashboard={dashboard_id}"
            ).json()
            self.assertNotIn("code", response)
            self.assertEqual(spy_execute_hogql_query.call_count, 4)
            self.assertEqual(
                response["result"][0]["data"],
                [
                    0.0,
                    0.0,
                    0.0,
                    0.0,
                    0.0,
                    0.0,
                    0.0,
                    0.0,
                    0.0,
                    0.0,
                    0.0,
                    0.0,
                    1.0,
                    0.0,
                    0.0,
                ],
            )

    @parameterized.expand(
        [
            [  # Property group filter, which is what's actually used these days
                PropertyGroupFilter(
                    type=FilterLogicalOperator.AND_,
                    values=[
                        PropertyGroupFilterValue(
                            type=FilterLogicalOperator.OR_,
                            values=[EventPropertyFilter(key="another", value="never_return_this", operator="is_not")],
                        )
                    ],
                )
            ],
            [  # Classic list of filters
                [EventPropertyFilter(key="another", value="never_return_this", operator="is_not")]
            ],
        ]
    )
    @patch("posthog.hogql_queries.insights.trends.trends_query_runner.execute_hogql_query", wraps=execute_hogql_query)
    def test_insight_refreshing_query_async(self, properties_filter, spy_execute_hogql_query) -> None:
        dashboard_id, _ = self.dashboard_api.create_dashboard({"filters": {"date_from": "-14d"}})

        with freeze_time("2012-01-14T03:21:34.000Z"):
            _create_event(
                team=self.team,
                event="$pageview",
                distinct_id="1",
                properties={"prop": "val"},
            )
            _create_event(
                team=self.team,
                event="$pageview",
                distinct_id="2",
                properties={"prop": "another_val"},
            )
            _create_event(
                team=self.team,
                event="$pageview",
                distinct_id="2",
                properties={"prop": "val", "another": "never_return_this"},
            )

        query_dict = TrendsQuery(
            series=[
                EventsNode(
                    event="$pageview",
                )
            ],
            properties=properties_filter,
        ).model_dump()

        with freeze_time("2012-01-15T04:01:34.000Z"):
            response = self.client.post(
                f"/api/projects/{self.team.id}/insights",
                data={
                    "query": query_dict,
                    "dashboards": [dashboard_id],
                },
            ).json()
            self.assertNotIn("code", response)  # Watching out for an error code
            self.assertEqual(response["last_refresh"], None)
            insight_id = response["id"]

            response = self.client.get(f"/api/projects/{self.team.id}/insights/{insight_id}/?refresh=blocking").json()
            self.assertNotIn("code", response)
            self.assertEqual(spy_execute_hogql_query.call_count, 1)
            self.assertEqual(response["result"][0]["data"], [0, 0, 0, 0, 0, 0, 2, 0])
            self.assertEqual(response["last_refresh"], "2012-01-15T04:01:34Z")
            self.assertEqual(response["last_modified_at"], "2012-01-15T04:01:34Z")
            self.assertFalse(response["is_cached"])

        with freeze_time("2012-01-15T05:17:39.000Z"):
            # Make sure the /query/ endpoint reuses the same cached result - ASYNC EXECUTION HERE!
            response = self.client.post(
                f"/api/projects/{self.team.id}/query/", {"query": query_dict, "refresh": "async"}
            ).json()
            self.assertNotIn("code", response)
            self.assertIsNone(response.get("query_status"))
            self.assertEqual(spy_execute_hogql_query.call_count, 1)
            self.assertEqual(response["results"][0]["data"], [0, 0, 0, 0, 0, 0, 2, 0])
            self.assertEqual(response["last_refresh"], "2012-01-15T04:01:34Z")  # Using cached result
            self.assertTrue(response["is_cached"])

        with freeze_time("2012-01-15T05:17:39.000Z"):
            # Now with force async requested - cache should be ignored
            response = self.client.post(
                f"/api/projects/{self.team.id}/query/", {"query": query_dict, "refresh": "force_async"}
            ).json()
            self.assertNotIn("code", response)
            self.assertIs(response.get("query_status", {}).get("query_async"), True)
            self.assertIs(
                response.get("query_status", {}).get("complete"), False
            )  # Just checking that recalculation was initiated

        # make new insight to test cache miss
        query_dict = TrendsQuery(
            series=[
                EventsNode(
                    event="$pageview",
                ),
                EventsNode(
                    event="$something",
                ),
            ],
            properties=properties_filter,
        ).model_dump()

        response = self.client.post(
            f"/api/projects/{self.team.id}/insights",
            data={
                "query": query_dict,
                "dashboards": [dashboard_id],
            },
        ).json()
        insight_id = response["id"]

        # Check that cache miss contains query status
        response = self.client.get(f"/api/projects/{self.team.id}/insights/{insight_id}/?refresh=async").json()
        self.assertNotIn("code", response)
        self.assertEqual(response["result"], None)
        self.assertEqual(response["query_status"]["query_async"], True)

    def test_dashboard_filters_applied_to_sql_data_table_node(self):
        dashboard_id, _ = self.dashboard_api.create_dashboard(
            {"name": "the dashboard", "filters": {"date_from": "-180d"}}
        )
        query = DataTableNode(
            source=HogQLQuery(
                query="SELECT count(1) FROM events", filters=HogQLFilters(dateRange=DateRange(date_from="-3d"))
            ),
        ).model_dump()
        insight_id, _ = self.dashboard_api.create_insight(
            {"query": query, "name": "insight", "dashboards": [dashboard_id]}
        )

        response = self.client.get(f"/api/projects/{self.team.id}/insights/{insight_id}/")

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.json()["query"], query)

        response = self.client.get(
            f"/api/projects/{self.team.id}/insights/{insight_id}/?refresh=true&from_dashboard={dashboard_id}"
        )

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.json()["query"]["source"]["filters"]["dateRange"]["date_from"], "-180d")

    def test_dashboard_filters_applied_to_data_visualization_node(self):
        dashboard_id, _ = self.dashboard_api.create_dashboard(
            {"name": "the dashboard", "filters": {"date_from": "-180d"}}
        )
        query = DataVisualizationNode(
            source=HogQLQuery(
                query="SELECT count(1) FROM events", filters=HogQLFilters(dateRange=DateRange(date_from="-3d"))
            ),
        ).model_dump()
        insight_id, _ = self.dashboard_api.create_insight(
            {"query": query, "name": "insight", "dashboards": [dashboard_id]}
        )

        response = self.client.get(f"/api/projects/{self.team.id}/insights/{insight_id}/")

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.json()["query"], query)

        response = self.client.get(
            f"/api/projects/{self.team.id}/insights/{insight_id}/?refresh=true&from_dashboard={dashboard_id}"
        )

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.json()["query"]["source"]["filters"]["dateRange"]["date_from"], "-180d")

    def test_dashboard_filters_applied_to_events_query_data_table_node(self):
        dashboard_id, _ = self.dashboard_api.create_dashboard(
            {"name": "the dashboard", "filters": {"date_from": "-180d"}}
        )
        query = DataTableNode(
            source=EventsQuery(select=["uuid", "event", "timestamp"], after="-3d").model_dump(),
        ).model_dump()
        insight_id, _ = self.dashboard_api.create_insight(
            {"query": query, "name": "insight", "dashboards": [dashboard_id]}
        )

        response = self.client.get(f"/api/projects/{self.team.id}/insights/{insight_id}/")

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.json()["query"], query)

        response = self.client.get(
            f"/api/projects/{self.team.id}/insights/{insight_id}/?refresh=true&from_dashboard={dashboard_id}"
        )

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.json()["query"]["source"]["after"], "-180d")

    # BASIC TESTING OF ENDPOINTS. /queries as in depth testing for each insight

    def test_insight_trends_basic(self) -> None:
        with freeze_time("2012-01-14T03:21:34.000Z"):
            _create_event(team=self.team, event="$pageview", distinct_id="1")
            _create_event(team=self.team, event="$pageview", distinct_id="2")

        with freeze_time("2012-01-15T04:01:34.000Z"):
            response = self.client.get(
                f"/api/projects/{self.team.id}/insights/trend/?events={json.dumps([{'id': '$pageview'}])}"
            ).json()

        self.assertEqual(response["result"][0]["count"], 2)
        self.assertEqual(response["result"][0]["action"]["name"], "$pageview")
        self.assertEqual(response["timezone"], "UTC")

    def test_nonexistent_cohort_is_handled(self) -> None:
        response = self.client.get(
            f"/api/projects/{self.team.id}/insights/trend/?events={json.dumps([{'id': '$pageview'}])}&properties={json.dumps([{'type': 'cohort', 'key': 'id', 'value': 2137}])}"
        )

        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST, response.json())

    def test_cohort_without_match_group_works(self) -> None:
        whatever_cohort_without_match_groups = Cohort.objects.create(team=self.team)

        response_nonexistent_property = self.client.get(
            f"/api/projects/{self.team.id}/insights/trend/?events={json.dumps([{'id': '$pageview'}])}&properties={json.dumps([{'type': 'event', 'key': 'foo', 'value': 'barabarab'}])}"
        )
        response_cohort_without_match_groups = self.client.get(
            f"/api/projects/{self.team.id}/insights/trend/?events={json.dumps([{'id': '$pageview'}])}&properties={json.dumps([{'type': 'cohort', 'key': 'id', 'value': whatever_cohort_without_match_groups.pk}])}"
        )  # This should not throw an error, just act like there's no event matches

        self.assertEqual(response_nonexistent_property.status_code, 200)
        response_nonexistent_property_data = response_nonexistent_property.json()
        response_cohort_without_match_groups_data = response_cohort_without_match_groups.json()
        response_nonexistent_property_data.pop("last_refresh")
        response_cohort_without_match_groups_data.pop("last_refresh")
        self.assertEntityResponseEqual(
            response_nonexistent_property_data["result"],
            response_cohort_without_match_groups_data["result"],
        )  # Both cases just empty

    def test_precalculated_cohort_works(self) -> None:
        _create_person(team=self.team, distinct_ids=["person_1"], properties={"foo": "bar"})

        whatever_cohort: Cohort = Cohort.objects.create(
            id=113,
            team=self.team,
            groups=[
                {
                    "properties": [
                        {
                            "type": "person",
                            "key": "foo",
                            "value": "bar",
                            "operator": "exact",
                        }
                    ]
                }
            ],
            last_calculation=timezone.now(),
        )

        whatever_cohort.calculate_people_ch(pending_version=0)

        with self.settings(USE_PRECALCULATED_CH_COHORT_PEOPLE=True):  # Normally this is False in tests
            response_user_property = self.client.get(
                f"/api/projects/{self.team.id}/insights/trend/?events={json.dumps([{'id': '$pageview'}])}&properties={json.dumps([{'type': 'person', 'key': 'foo', 'value': 'bar'}])}"
            )
            response_precalculated_cohort = self.client.get(
                f"/api/projects/{self.team.id}/insights/trend/?events={json.dumps([{'id': '$pageview'}])}&properties={json.dumps([{'type': 'cohort', 'key': 'id', 'value': 113}])}"
            )

        self.assertEqual(response_precalculated_cohort.status_code, 200)
        response_user_property_data = response_user_property.json()
        response_precalculated_cohort_data = response_precalculated_cohort.json()
        response_user_property_data.pop("last_refresh")
        response_precalculated_cohort_data.pop("last_refresh")

        self.assertEntityResponseEqual(
            response_user_property_data["result"],
            response_precalculated_cohort_data["result"],
        )

    def test_insight_trends_compare(self) -> None:
        with freeze_time("2012-01-14T03:21:34.000Z"):
            for i in range(25):
                _create_event(
                    team=self.team,
                    event="$pageview",
                    distinct_id="1",
                    properties={"$some_property": f"value{i}"},
                )

        with freeze_time("2012-01-15T04:01:34.000Z"):
            response = self.client.get(
                f"/api/projects/{self.team.id}/insights/trend/",
                data={"events": json.dumps([{"id": "$pageview"}]), "compare": "true"},
            )
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        result = response.json()
        self.assertEqual(len(result["result"]), 2)
        self.assertEqual(result["result"][0]["compare_label"], "current")
        self.assertEqual(result["result"][1]["compare_label"], "previous")

    def test_insight_trends_breakdown_pagination(self) -> None:
        with freeze_time("2012-01-14T03:21:34.000Z"):
            for i in range(25):
                _create_event(
                    team=self.team,
                    event="$pageview",
                    distinct_id="1",
                    properties={"$some_property": f"value{i}"},
                )

        with freeze_time("2012-01-15T04:01:34.000Z"):
            response = self.client.get(
                f"/api/projects/{self.team.id}/insights/trend/",
                data={
                    "events": json.dumps([{"id": "$pageview"}]),
                    "breakdown": "$some_property",
                    "breakdown_type": "event",
                },
            )
        self.assertEqual(response.status_code, status.HTTP_200_OK, response.json())
        self.assertIn("offset=25", response.json()["next"])

    def test_insight_funnels_basic_post(self) -> None:
        _create_person(team=self.team, distinct_ids=["1"])
        _create_event(team=self.team, event="user signed up", distinct_id="1")
        _create_event(team=self.team, event="user did things", distinct_id="1")
        response = self.client.post(
            f"/api/projects/{self.team.id}/insights/funnel/",
            {
                "events": [
                    {"id": "user signed up", "type": "events", "order": 0},
                    {"id": "user did things", "type": "events", "order": 1},
                ],
                "funnel_window_days": 14,
            },
        )
        self.assertEqual(response.status_code, status.HTTP_200_OK)

        response_json = response.json()
        # clickhouse funnels don't have a loading system
        self.assertEqual(len(response_json["result"]), 2)
        self.assertEqual(response_json["result"][0]["name"], "user signed up")
        self.assertEqual(response_json["result"][0]["count"], 1)
        self.assertEqual(response_json["result"][1]["name"], "user did things")
        self.assertEqual(response_json["result"][1]["count"], 1)

    # Tests backwards-compatibility when we changed GET to POST | GET
    def test_insight_funnels_basic_get(self) -> None:
        _create_event(team=self.team, event="user signed up", distinct_id="1")
        _create_event(team=self.team, event="user did things", distinct_id="1")
        response = self.client.get(
            f"/api/projects/{self.team.id}/insights/funnel/?funnel_window_days=14&events={json.dumps([{'id': 'user signed up', 'type': 'events', 'order': 0}, {'id': 'user did things', 'type': 'events', 'order': 1}])}"
        ).json()

        # clickhouse funnels don't have a loading system
        self.assertEqual(len(response["result"]), 2)
        self.assertEqual(response["result"][0]["name"], "user signed up")
        self.assertEqual(response["result"][1]["name"], "user did things")
        self.assertEqual(response["timezone"], "UTC")

    def test_logged_out_user_cannot_retrieve_insight(self) -> None:
        self.client.logout()
        insight = Insight.objects.create(
            filters=Filter(data={"events": [{"id": "$pageview"}]}).to_dict(),
            team=self.team,
            short_id="12345678",
        )

        response = self.client.get(
            f"/api/projects/{self.team.id}/insights/{insight.id}/",
        )

        self.assertEqual(response.status_code, 403, response.json())
        self.assertEqual(
            response.json(),
            self.unauthenticated_response(),
        )

    def test_logged_out_user_can_retrieve_insight_with_correct_insight_sharing_access_token(self) -> None:
        self.client.logout()
        _create_person(
            team=self.team,
            distinct_ids=["person1"],
            properties={"email": "person1@test.com"},
        )
        _create_event(
            team=self.team,
            event="$pageview",
            distinct_id="person1",
            timestamp=timezone.now() - timedelta(days=5),
        )
        flush_persons_and_events()
        insight = Insight.objects.create(
            name="Foobar",
            filters=Filter(data={"events": [{"id": "$pageview"}]}).to_dict(),
            team=self.team,
            short_id="12345678",
        )
        Insight.objects.create(  # This one isn't shared
            name="Foobar",
            filters=Filter(data={"events": [{"id": "$pageview"}]}).to_dict(),
            team=self.team,
            short_id="abcdfghi",
        )
        sharing_configuration = SharingConfiguration.objects.create(
            team=self.team, insight=insight, enabled=True, access_token="xyz"
        )
        other_sharing_configuration = SharingConfiguration.objects.create(
            team=self.team, enabled=True, access_token="klm"
        )

        response_invalid_token_retrieve = self.client.get(
            f"/api/projects/{self.team.id}/insights/{insight.id}/?sharing_access_token=abc",
        )
        response_incorrect_token_retrieve = self.client.get(
            f"/api/projects/{self.team.id}/insights/{insight.id}/?sharing_access_token={other_sharing_configuration.access_token}",
        )
        response_correct_token_retrieve = self.client.get(
            f"/api/projects/{self.team.id}/insights/{insight.id}/?sharing_access_token={sharing_configuration.access_token}",
        )
        response_correct_token_list = self.client.get(
            f"/api/projects/{self.team.id}/insights/?sharing_access_token={sharing_configuration.access_token}",
        )

        self.assertEqual(
            response_invalid_token_retrieve.status_code,
            403,
            response_invalid_token_retrieve.json(),
        )
        self.assertEqual(
            response_invalid_token_retrieve.json(),
            self.unauthenticated_response("Sharing access token is invalid.", "authentication_failed"),
        )
        self.assertEqual(
            response_incorrect_token_retrieve.status_code,
            404,
            response_incorrect_token_retrieve.json(),
        )
        self.assertEqual(
            response_incorrect_token_retrieve.json(),
            self.not_found_response(),
        )
        self.assertEqual(
            response_correct_token_retrieve.status_code,
            200,
            response_correct_token_retrieve.json(),
        )
        self.assertLessEqual(
            {
                "name": "Foobar",
            }.items(),
            response_correct_token_retrieve.json().items(),
        )
        self.assertEqual(
            response_correct_token_list.status_code,
            200,
            response_correct_token_list.json(),
        )
        # abcdfghi not returned as it's not related to this sharing configuration
        self.assertEqual(response_correct_token_list.json()["count"], 1)
        self.assertLessEqual(
            {
                "id": insight.id,
                "name": "Foobar",
                "short_id": "12345678",
            }.items(),
            response_correct_token_list.json()["results"][0].items(),
        )

    def test_logged_out_user_cannot_retrieve_deleted_insight_with_correct_insight_sharing_access_token(self) -> None:
        self.client.logout()
        deleted_insight = Insight.objects.create(
            name="Foobar",
            filters=Filter(data={"events": [{"id": "$pageview"}]}).to_dict(),
            team=self.team,
            short_id="12345678",
            deleted=True,
        )
        sharing_configuration = SharingConfiguration.objects.create(
            team=self.team, insight=deleted_insight, enabled=True, access_token="ghi"
        )

        response_retrieve = self.client.get(
            f"/api/projects/{self.team.id}/insights/{deleted_insight.id}/?sharing_access_token={sharing_configuration.access_token}",
        )

        self.assertEqual(response_retrieve.status_code, 404, response_retrieve.json())
        self.assertEqual(
            response_retrieve.json(),
            self.not_found_response(),
        )

    def test_logged_out_user_cannot_update_insight_with_correct_insight_sharing_access_token(self) -> None:
        self.client.logout()
        insight = Insight.objects.create(
            name="Foobar",
            filters=Filter(data={"events": [{"id": "$pageview"}]}).to_dict(),
            team=self.team,
            short_id="12345678",
        )
        sharing_configuration = SharingConfiguration.objects.create(
            team=self.team, insight=insight, enabled=True, access_token="ghi"
        )

        response_retrieve = self.client.patch(
            f"/api/projects/{self.team.id}/insights/{insight.id}/?sharing_access_token={sharing_configuration.access_token}",
            {"name": "Barfoo"},
        )

        self.assertEqual(response_retrieve.status_code, 403, response_retrieve.json())
        self.assertEqual(
            response_retrieve.json(),
            self.unauthenticated_response(
                "Sharing access token can only be used for GET requests.",
                "authentication_failed",
            ),
        )

    def test_logged_out_user_cannot_retrieve_insight_with_disabled_insight_sharing_access_token(self) -> None:
        self.client.logout()
        insight = Insight.objects.create(
            filters=Filter(data={"events": [{"id": "$pageview"}]}).to_dict(),
            team=self.team,
            short_id="12345678",
        )
        sharing_configuration = SharingConfiguration.objects.create(
            team=self.team,
            insight=insight,
            enabled=False,
            access_token="xyz",  # DISABLED!
        )

        response_retrieve = self.client.get(
            f"/api/projects/{self.team.id}/insights/{insight.id}/?sharing_access_token={sharing_configuration.access_token}",
        )
        response_list = self.client.get(
            f"/api/projects/{self.team.id}/insights/?short_id={insight.short_id}&sharing_access_token={sharing_configuration.access_token}",
        )

        self.assertEqual(response_retrieve.status_code, 403, response_retrieve.json())
        self.assertEqual(
            response_retrieve.json(),
            self.unauthenticated_response("Sharing access token is invalid.", "authentication_failed"),
        )
        self.assertEqual(response_list.status_code, 403, response_retrieve.json())
        self.assertEqual(
            response_list.json(),
            self.unauthenticated_response("Sharing access token is invalid.", "authentication_failed"),
        )

    def test_logged_out_user_can_retrieve_insight_with_correct_dashboard_sharing_access_token(self) -> None:
        self.client.logout()
        _create_person(
            team=self.team,
            distinct_ids=["person1"],
            properties={"email": "person1@test.com"},
        )
        _create_event(
            team=self.team,
            event="$pageview",
            distinct_id="person1",
            timestamp=timezone.now() - timedelta(days=5),
        )
        flush_persons_and_events()
        insight = Insight.objects.create(
            name="Foobar",
            filters=Filter(data={"events": [{"id": "$pageview"}]}).to_dict(),
            team=self.team,
            short_id="12345678",
        )
        deleted_insight = Insight.objects.create(
            name="Barfoo",
            filters=Filter(data={"events": [{"id": "$pageview"}]}).to_dict(),
            team=self.team,
            short_id="87654321",
            deleted=True,
        )
        deleted_tile_insight = Insight.objects.create(
            name="Foobaz",
            filters=Filter(data={"events": [{"id": "$pageview"}]}).to_dict(),
            team=self.team,
            short_id="abcdabcd",
        )
        random_text = Text.objects.create(team=self.team)
        dashboard = Dashboard.objects.create(team=self.team, name="Test dashboard")
        DashboardTile.objects.create(dashboard=dashboard, insight=insight)
        DashboardTile.objects.create(dashboard=dashboard, insight=deleted_insight)
        DashboardTile.objects.create(dashboard=dashboard, insight=deleted_tile_insight, deleted=True)
        DashboardTile.objects.create(dashboard=dashboard, text=random_text)
        sharing_configuration = SharingConfiguration.objects.create(
            team=self.team, dashboard=dashboard, enabled=True, access_token="xyz"
        )

        response_incorrect_token_retrieve = self.client.get(
            f"/api/projects/{self.team.id}/insights/{insight.id}/?sharing_access_token=abc",
        )
        response_correct_token_retrieve = self.client.get(
            f"/api/projects/{self.team.id}/insights/{insight.id}/?sharing_access_token={sharing_configuration.access_token}",
        )
        response_correct_token_list = self.client.get(
            f"/api/projects/{self.team.id}/insights/?sharing_access_token={sharing_configuration.access_token}",
        )

        self.assertEqual(
            response_incorrect_token_retrieve.status_code,
            403,
            response_incorrect_token_retrieve.json(),
        )
        self.assertEqual(
            response_incorrect_token_retrieve.json(),
            self.unauthenticated_response("Sharing access token is invalid.", "authentication_failed"),
        )
        self.assertEqual(
            response_correct_token_retrieve.status_code,
            200,
            response_correct_token_retrieve.json(),
        )
        self.assertLessEqual({"name": "Foobar"}.items(), response_correct_token_retrieve.json().items())
        # Below checks that the deleted insight and non-deleted insight whose tile is deleted are not be retrievable
        # Also, the text tile should not affect things
        self.assertEqual(
            response_correct_token_list.status_code,
            200,
            response_correct_token_list.json(),
        )
        self.assertEqual(response_correct_token_list.json()["count"], 1)

    def test_logged_out_user_cannot_retrieve_insight_with_correct_deleted_dashboard_sharing_access_token(self) -> None:
        self.client.logout()
        insight = Insight.objects.create(
            name="Foobar",
            filters=Filter(data={"events": [{"id": "$pageview"}]}).to_dict(),
            team=self.team,
            short_id="12345678",
        )
        dashboard = Dashboard.objects.create(team=self.team, name="Test dashboard", deleted=True)
        DashboardTile.objects.create(dashboard=dashboard, insight=insight)
        sharing_configuration = SharingConfiguration.objects.create(
            team=self.team, dashboard=dashboard, enabled=True, access_token="xyz"
        )

        response_correct_token_list = self.client.get(
            f"/api/projects/{self.team.id}/insights/?sharing_access_token={sharing_configuration.access_token}",
        )

        self.assertEqual(
            response_correct_token_list.status_code,
            200,
            response_correct_token_list.json(),
        )
        self.assertEqual(response_correct_token_list.json()["count"], 0)

    def test_insight_trends_csv(self) -> None:
        with freeze_time("2012-01-14T03:21:34.000Z"):
            _create_event(team=self.team, event="$pageview", distinct_id="1")
            _create_event(team=self.team, event="$pageview", distinct_id="2")

        with freeze_time("2012-01-15T04:01:34.000Z"):
            _create_event(team=self.team, event="$pageview", distinct_id="2")
            response = self.client.get(
                f"/api/projects/{self.team.id}/insights/trend.csv/?events={json.dumps([{'id': '$pageview', 'custom_name': 'test custom'}])}&export_name=Pageview count&export_insight_id=test123"
            )

        lines = response.content.splitlines()

        self.assertEqual(lines[0], b"http://localhost:8010/insights/test123/", lines[0])
        self.assertEqual(
            lines[1],
            b"series,8-Jan-2012,9-Jan-2012,10-Jan-2012,11-Jan-2012,12-Jan-2012,13-Jan-2012,14-Jan-2012,15-Jan-2012",
            lines[0],
        )
        self.assertEqual(lines[2], b"test custom,0,0,0,0,0,0,2,1")
        self.assertEqual(len(lines), 3, response.content)

    def _create_one_person_cohort(self, properties: list[dict[str, Any]]) -> int:
        create_person(team=self.team, properties=properties)
        cohort_one_id = self.client.post(
            f"/api/projects/{self.team.id}/cohorts",
            data={"name": "whatever", "groups": [{"properties": properties}]},
        ).json()["id"]
        return cohort_one_id

    @parameterized.expand([("single_id", 1), ("bulk_ids", 3)])
    @freeze_time("2022-03-22T00:00:00.000Z")
    def test_create_insight_viewed(self, _name: str, count: int) -> None:
        filter_dict = {"events": [{"id": "$pageview"}]}
        insights = [
            Insight.objects.create(filters=Filter(data=filter_dict).to_dict(), team=self.team, short_id=f"viewed{i}")
            for i in range(count)
        ]

        response = self.client.post(
            f"/api/projects/{self.team.id}/insights/viewed",
            {"insight_ids": [insight.id for insight in insights]},
        )

        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertEqual(InsightViewed.objects.count(), count)

        created_by_insight = {viewed.insight_id: viewed for viewed in InsightViewed.objects.all()}
        self.assertEqual(set(created_by_insight.keys()), {insight.id for insight in insights})
        for viewed in created_by_insight.values():
            self.assertEqual(viewed.team, self.team)
            self.assertEqual(viewed.user, self.user)
            self.assertEqual(
                viewed.last_viewed_at,
                datetime(2022, 3, 22, 0, 0, tzinfo=ZoneInfo("UTC")),
            )

    def test_insight_viewed_not_recorded_during_impersonation(self) -> None:
        filter_dict = {"events": [{"id": "$pageview"}]}
        insight = Insight.objects.create(filters=Filter(data=filter_dict).to_dict(), team=self.team, short_id="viewed0")

        with patch("products.product_analytics.backend.presentation.insight.is_impersonated", return_value=True):
            response = self.client.post(
                f"/api/projects/{self.team.id}/insights/viewed",
                {"insight_ids": [insight.id]},
            )

        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertEqual(InsightViewed.objects.count(), 0)

    def test_update_insight_viewed(self) -> None:
        filter_dict = {"events": [{"id": "$pageview"}]}
        insight = Insight.objects.create(
            filters=Filter(data=filter_dict).to_dict(),
            team=self.team,
            short_id="12345678",
        )
        with freeze_time("2022-03-22T00:00:00.000Z"):
            response = self.client.post(
                f"/api/projects/{self.team.id}/insights/viewed",
                {"insight_ids": [insight.id]},
            )
            self.assertEqual(response.status_code, status.HTTP_201_CREATED)

        with freeze_time("2022-03-23T00:00:00.000Z"):
            response = self.client.post(
                f"/api/projects/{self.team.id}/insights/viewed",
                {"insight_ids": [insight.id]},
            )
            self.assertEqual(response.status_code, status.HTTP_201_CREATED)
            self.assertEqual(InsightViewed.objects.count(), 1)

            updated_insight_viewed = InsightViewed.objects.all()[0]
            self.assertEqual(
                updated_insight_viewed.last_viewed_at,
                datetime(2022, 3, 23, 0, 0, tzinfo=ZoneInfo("UTC")),
            )

    def test_cant_view_insight_viewed_for_insight_in_another_team(self) -> None:
        other_team = Team.objects.create(organization=self.organization, name="other team")
        filter_dict = {"events": [{"id": "$pageview"}]}
        insight = Insight.objects.create(
            filters=Filter(data=filter_dict).to_dict(),
            team=other_team,
            short_id="12345678",
        )

        response = self.client.post(
            f"/api/projects/{self.team.id}/insights/viewed",
            {"insight_ids": [insight.id]},
        )

        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertEqual(InsightViewed.objects.count(), 0)

    @parameterized.expand(
        [
            ("missing", {}),
            ("empty_list", {"insight_ids": []}),
            ("not_a_list", {"insight_ids": "abc"}),
            ("non_int_element", {"insight_ids": ["abc", 1]}),
            ("over_max_length", {"insight_ids": list(range(1, 2502))}),
        ]
    )
    def test_insight_viewed_rejects_invalid_payloads(self, _name: str, payload: dict) -> None:
        response = self.client.post(
            f"/api/projects/{self.team.id}/insights/viewed",
            payload,
        )
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertEqual(InsightViewed.objects.count(), 0)

    def test_bulk_upserts_existing_insight_viewed_rows(self) -> None:
        filter_dict = {"events": [{"id": "$pageview"}]}
        insights = [
            Insight.objects.create(filters=Filter(data=filter_dict).to_dict(), team=self.team, short_id=f"upsert{i}")
            for i in range(3)
        ]

        # Pre-create rows for the first two insights at T1.
        with freeze_time("2022-03-22T00:00:00.000Z"):
            self.client.post(
                f"/api/projects/{self.team.id}/insights/viewed",
                {"insight_ids": [insights[0].id, insights[1].id]},
            )

        # Submit all three at T2 — the first two should be UPDATEd, the third INSERTed.
        with freeze_time("2022-03-23T00:00:00.000Z"):
            response = self.client.post(
                f"/api/projects/{self.team.id}/insights/viewed",
                {"insight_ids": [insight.id for insight in insights]},
            )

        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertEqual(InsightViewed.objects.count(), 3)
        for viewed in InsightViewed.objects.all():
            self.assertEqual(viewed.last_viewed_at, datetime(2022, 3, 23, 0, 0, tzinfo=ZoneInfo("UTC")))

    def test_bulk_filters_unauthorized_and_deleted_insight_ids(self) -> None:
        other_team = Team.objects.create(organization=self.organization, name="other team")
        filter_dict = {"events": [{"id": "$pageview"}]}
        own_insight = Insight.objects.create(
            filters=Filter(data=filter_dict).to_dict(), team=self.team, short_id="own1"
        )
        other_team_insight = Insight.objects.create(
            filters=Filter(data=filter_dict).to_dict(), team=other_team, short_id="other"
        )
        deleted_insight = Insight.objects.create(
            filters=Filter(data=filter_dict).to_dict(), team=self.team, short_id="dead", deleted=True
        )

        response = self.client.post(
            f"/api/projects/{self.team.id}/insights/viewed",
            {"insight_ids": [own_insight.id, other_team_insight.id, deleted_insight.id]},
        )

        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertEqual(InsightViewed.objects.count(), 1)
        self.assertEqual(InsightViewed.objects.first().insight_id, own_insight.id)  # type: ignore[union-attr]

    def test_bulk_insight_viewed_query_count_does_not_grow_with_insight_count(self) -> None:
        filter_dict = {"events": [{"id": "$pageview"}]}
        few = [
            Insight.objects.create(filters=Filter(data=filter_dict).to_dict(), team=self.team, short_id=f"few{i}")
            for i in range(2)
        ]
        many = [
            Insight.objects.create(filters=Filter(data=filter_dict).to_dict(), team=self.team, short_id=f"many{i}")
            for i in range(10)
        ]

        with capture_db_queries() as ctx_few:
            response = self.client.post(
                f"/api/projects/{self.team.id}/insights/viewed",
                {"insight_ids": [insight.id for insight in few]},
            )
            self.assertEqual(response.status_code, status.HTTP_201_CREATED)

        with capture_db_queries() as ctx_many:
            response = self.client.post(
                f"/api/projects/{self.team.id}/insights/viewed",
                {"insight_ids": [insight.id for insight in many]},
            )
            self.assertEqual(response.status_code, status.HTTP_201_CREATED)

        few_inserts = [q for q in ctx_few.captured_queries if 'INSERT INTO "posthog_insightviewed"' in q["sql"]]
        many_inserts = [q for q in ctx_many.captured_queries if 'INSERT INTO "posthog_insightviewed"' in q["sql"]]

        self.assertEqual(len(few_inserts), 1, f"expected exactly 1 INSERT for few, got {len(few_inserts)}")
        self.assertEqual(len(many_inserts), 1, f"expected exactly 1 INSERT for many, got {len(many_inserts)}")

    def test_get_recently_viewed_insights(self) -> None:
        insight_1_id, _ = self.dashboard_api.create_insight({"short_id": "12345678"})

        self.client.post(
            f"/api/projects/{self.team.id}/insights/viewed",
            {"insight_ids": [insight_1_id]},
        )

        response = self.client.get(f"/api/projects/{self.team.id}/insights/my_last_viewed")
        response_data = response.json()

        # No results if no insights have been viewed
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        assert [r["id"] for r in response_data] == [insight_1_id]

    def test_get_recently_viewed_insights_include_query_based_insights(self) -> None:
        insight_1_id, _ = self.dashboard_api.create_insight({"short_id": "12345678"})
        insight_2_id, _ = self.dashboard_api.create_insight(
            {
                "short_id": "3456",
                "query": {
                    "kind": "DataTableNode",
                    "source": {
                        "kind": "EventsQuery",
                        "select": [
                            "*",
                            "event",
                            "person",
                            "coalesce(properties.$current_url, properties.$screen_name)",
                            "properties.$lib",
                            "timestamp",
                        ],
                        "properties": [
                            {
                                "type": "event",
                                "key": "$browser",
                                "operator": "exact",
                                "value": "Chrome",
                            }
                        ],
                        "limit": 100,
                    },
                },
            }
        )

        self.client.post(
            f"/api/projects/{self.team.id}/insights/viewed",
            {"insight_ids": [insight_1_id]},
        )
        self.client.post(
            f"/api/projects/{self.team.id}/insights/viewed",
            {"insight_ids": [insight_2_id]},
        )

        response = self.client.get(f"/api/projects/{self.team.id}/insights/my_last_viewed")
        response_data = response.json()

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        assert [r["id"] for r in response_data] == [insight_2_id, insight_1_id]

    def test_recently_viewed_insights_ordered_by_view_date(self) -> None:
        insight_1_id, _ = self.dashboard_api.create_insight({"short_id": "12345678"})
        insight_2_id, _ = self.dashboard_api.create_insight({"short_id": "98765432"})
        insight_3_id, _ = self.dashboard_api.create_insight({"short_id": "43219876"})

        # multiple views of a single don't drown out other views
        self.client.post(
            f"/api/projects/{self.team.id}/insights/viewed",
            {"insight_ids": [insight_1_id]},
        )
        self.client.post(
            f"/api/projects/{self.team.id}/insights/viewed",
            {"insight_ids": [insight_1_id]},
        )
        self.client.post(
            f"/api/projects/{self.team.id}/insights/viewed",
            {"insight_ids": [insight_1_id]},
        )

        # soft-deleted insights aren't shown
        self.client.post(
            f"/api/projects/{self.team.id}/insights/viewed",
            {"insight_ids": [insight_3_id]},
        )
        self.dashboard_api.soft_delete(insight_3_id, "insights")

        self.client.post(
            f"/api/projects/{self.team.id}/insights/viewed",
            {"insight_ids": [insight_2_id]},
        )

        response = self.client.get(f"/api/projects/{self.team.id}/insights/my_last_viewed")
        response_data = response.json()

        # Insights are ordered by most recently viewed
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        assert [r["id"] for r in response_data] == [insight_2_id, insight_1_id]

        self.client.post(
            f"/api/projects/{self.team.id}/insights/viewed",
            {"insight_ids": [insight_1_id]},
        )

        response = self.client.get(f"/api/projects/{self.team.id}/insights/my_last_viewed")
        response_data = response.json()

        # Order updates when an insight is viewed again
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        assert [r["id"] for r in response_data] == [insight_1_id, insight_2_id]

    def test_trending_insights_orders_by_view_count_then_recency(self) -> None:
        # Bypass the API for the unviewed insight — `dashboard_api.create_insight` auto-creates
        # an InsightViewed row, which would defeat the "no views = excluded" assertion below.
        unviewed = Insight.objects.create(team=self.team, short_id="trnd0001", filters={"events": [{"id": "$pv"}]})
        one_view_id, _ = self.dashboard_api.create_insight({"short_id": "trnd0002"})
        two_views_id, _ = self.dashboard_api.create_insight({"short_id": "trnd0003"})

        other_user = User.objects.create_and_join(self.organization, "other@posthog.com", None)
        viewed_at = timezone.now()
        InsightViewed.objects.update_or_create(
            team=self.team, user=self.user, insight_id=one_view_id, defaults={"last_viewed_at": viewed_at}
        )
        InsightViewed.objects.update_or_create(
            team=self.team, user=self.user, insight_id=two_views_id, defaults={"last_viewed_at": viewed_at}
        )
        InsightViewed.objects.update_or_create(
            team=self.team, user=other_user, insight_id=two_views_id, defaults={"last_viewed_at": viewed_at}
        )

        response = self.client.get(f"/api/projects/{self.team.id}/insights/trending")
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        body = response.json()
        results = body["results"]
        assert body["count"] == len(results)

        ids = [r["id"] for r in results]
        assert two_views_id in ids and one_view_id in ids
        assert unviewed.pk not in ids
        assert ids.index(two_views_id) < ids.index(one_view_id)

        two_views_row = next(r for r in results if r["id"] == two_views_id)
        assert two_views_row["view_count"] == 2
        assert len(two_views_row["viewers"]) == 2

    def test_trending_insights_respects_days_window(self) -> None:
        recent_id, _ = self.dashboard_api.create_insight({"short_id": "trndR001"})
        old_id, _ = self.dashboard_api.create_insight({"short_id": "trndO001"})

        InsightViewed.objects.update_or_create(
            team=self.team, user=self.user, insight_id=recent_id, defaults={"last_viewed_at": timezone.now()}
        )
        InsightViewed.objects.update_or_create(
            team=self.team,
            user=self.user,
            insight_id=old_id,
            defaults={"last_viewed_at": timezone.now() - timedelta(days=14)},
        )

        response = self.client.get(f"/api/projects/{self.team.id}/insights/trending?days=7")
        ids = [r["id"] for r in response.json()["results"]]
        assert ids == [recent_id]

        response = self.client.get(f"/api/projects/{self.team.id}/insights/trending?days=30")
        ids = [r["id"] for r in response.json()["results"]]
        assert set(ids) == {recent_id, old_id}

    def test_trending_insights_excludes_deleted(self) -> None:
        kept_id, _ = self.dashboard_api.create_insight({"short_id": "trndK001"})
        deleted_id, _ = self.dashboard_api.create_insight({"short_id": "trndD001"})

        InsightViewed.objects.update_or_create(
            team=self.team, user=self.user, insight_id=kept_id, defaults={"last_viewed_at": timezone.now()}
        )
        InsightViewed.objects.update_or_create(
            team=self.team, user=self.user, insight_id=deleted_id, defaults={"last_viewed_at": timezone.now()}
        )
        self.dashboard_api.soft_delete(deleted_id, "insights")

        response = self.client.get(f"/api/projects/{self.team.id}/insights/trending")
        ids = [r["id"] for r in response.json()["results"]]
        assert ids == [kept_id]

    def test_trending_insights_respects_limit(self) -> None:
        for short_id in ("trndL001", "trndL002", "trndL003"):
            insight_id, _ = self.dashboard_api.create_insight({"short_id": short_id})
            InsightViewed.objects.update_or_create(
                team=self.team, user=self.user, insight_id=insight_id, defaults={"last_viewed_at": timezone.now()}
            )

        response = self.client.get(f"/api/projects/{self.team.id}/insights/trending?limit=2")
        body = response.json()
        assert len(body["results"]) == 2
        assert body["count"] == 2

    def test_trending_insights_rejects_invalid_params(self) -> None:
        response = self.client.get(f"/api/projects/{self.team.id}/insights/trending?days=abc")
        assert response.status_code == status.HTTP_400_BAD_REQUEST

    def test_get_recent_insights_with_feature_flag(self) -> None:
        filter_dict = {
            "events": [{"id": "$pageview"}],
            "breakdown": "$feature/insight-with-flag-used",
        }
        filter_dict2 = {
            "events": [{"id": "$pageview"}],
            "properties": [{"key": "$active_feature_flag", "value": "insight-with-flag-used"}],
        }
        filter_dict3 = {"events": [{"id": "$pageview"}], "breakdown": "email"}

        insight = Insight.objects.create(
            filters=Filter(data=filter_dict).to_dict(),
            team=self.team,
            short_id="11223344",
        )
        insight2 = Insight.objects.create(
            filters=Filter(data=filter_dict2).to_dict(),
            team=self.team,
            short_id="44332211",
        )
        Insight.objects.create(
            filters=Filter(data=filter_dict3).to_dict(),
            team=self.team,
            short_id="00992281",
        )

        response = self.client.get(f"/api/projects/{self.team.id}/insights/?feature_flag=insight-with-flag-used")
        response_data = response.json()

        self.assertEqual(response.status_code, status.HTTP_200_OK)

        ids_in_response = [r["id"] for r in response_data["results"]]
        # insight 3 is not included in response
        self.assertCountEqual(ids_in_response, [insight.id, insight2.id])

    def test_get_recent_insights_with_feature_flag_query_based(self) -> None:
        """Query-based insights store breakdown config in the query JSON field, not filters."""
        query_with_flag = {
            "kind": "InsightVizNode",
            "source": {
                "kind": "TrendsQuery",
                "series": [{"event": "$pageview", "kind": "EventsNode"}],
                "breakdownFilter": {
                    "breakdown_type": "event",
                    "breakdown": "$feature/my-test-flag",
                },
            },
        }
        query_without_flag = {
            "kind": "InsightVizNode",
            "source": {
                "kind": "TrendsQuery",
                "series": [{"event": "$pageview", "kind": "EventsNode"}],
                "breakdownFilter": {
                    "breakdown_type": "event",
                    "breakdown": "email",
                },
            },
        }

        insight_with_flag = Insight.objects.create(
            query=query_with_flag,
            team=self.team,
            short_id="query_flag1",
        )
        Insight.objects.create(
            query=query_without_flag,
            team=self.team,
            short_id="query_noflag",
        )

        response = self.client.get(f"/api/projects/{self.team.id}/insights/?feature_flag=my-test-flag")
        response_data = response.json()

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        ids_in_response = [r["id"] for r in response_data["results"]]
        self.assertCountEqual(ids_in_response, [insight_with_flag.id])

    def test_cannot_create_insight_with_dashboards_relation_from_another_team(
        self,
    ) -> None:
        dashboard_own_team: Dashboard = Dashboard.objects.create(team=self.team)
        another_team = Team.objects.create(organization=self.organization)
        dashboard_other_team: Dashboard = Dashboard.objects.create(team=another_team)

        self.dashboard_api.create_insight(
            data={
                "filters": {
                    "events": [{"id": "$pageview"}],
                    "properties": [{"key": "$browser", "value": "Mac OS X"}],
                    "date_from": "-90d",
                },
                "dashboards": [dashboard_own_team.pk, dashboard_other_team.pk],
            },
            expected_status=status.HTTP_400_BAD_REQUEST,
        )

    def test_cannot_create_insight_on_a_dashboard_that_does_not_exist(self) -> None:
        self.dashboard_api.create_insight(
            data={"name": "insight", "dashboards": [9_999_999]},
            expected_status=status.HTTP_400_BAD_REQUEST,
        )

    @skip("is this not how things work?")
    def test_cannot_create_insight_in_another_team(
        self,
    ) -> None:
        another_team = Team.objects.create(organization=self.organization)

        # logged in to self.team and trying to create an insight in another_team
        self.dashboard_api.create_insight(
            team_id=another_team.pk,
            data={
                "filters": {
                    "events": [{"id": "$pageview"}],
                    "properties": [{"key": "$browser", "value": "Mac OS X"}],
                    "date_from": "-90d",
                },
            },
            expected_status=status.HTTP_400_BAD_REQUEST,
        )

    def test_cannot_update_insight_with_dashboard_from_another_team(self) -> None:
        another_team = Team.objects.create(organization=self.organization)
        dashboard_other_team: Dashboard = Dashboard.objects.create(team=another_team)
        dashboard_own_team: Dashboard = Dashboard.objects.create(team=self.team)

        insight_id, _ = self.dashboard_api.create_insight(
            data={
                "filters": {
                    "events": [{"id": "$pageview"}],
                    "properties": [{"key": "$browser", "value": "Mac OS X"}],
                    "date_from": "-90d",
                },
                "dashboards": [dashboard_own_team.pk],
            }
        )

        response = self.client.patch(
            f"/api/projects/{self.team.id}/insights/{insight_id}",
            {"dashboards": [dashboard_own_team.pk, dashboard_other_team.pk]},
        )
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

    def test_hard_delete_is_forbidden(self) -> None:
        insight_id, _ = self.dashboard_api.create_insight({"name": "to be deleted"})
        api_response = self.client.delete(f"/api/projects/{self.team.id}/insights/{insight_id}")
        self.assertEqual(api_response.status_code, status.HTTP_405_METHOD_NOT_ALLOWED)
        self.assertEqual(
            self.client.get(f"/api/projects/{self.team.id}/insights/{insight_id}").status_code,
            status.HTTP_200_OK,
        )

    def test_soft_delete_causes_404(self) -> None:
        insight_id, _ = self.dashboard_api.create_insight({"name": "to be deleted"})
        self.dashboard_api.get_insight(insight_id=insight_id, expected_status=status.HTTP_200_OK)

        update_response = self.client.patch(f"/api/projects/{self.team.id}/insights/{insight_id}", {"deleted": True})
        self.assertEqual(update_response.status_code, status.HTTP_200_OK)

        self.dashboard_api.get_insight(insight_id=insight_id, expected_status=status.HTTP_404_NOT_FOUND)

    def test_soft_delete_can_be_reversed_by_patch(self) -> None:
        insight_id, _ = self.dashboard_api.create_insight({"name": "an insight"})

        self.client.patch(
            f"/api/projects/{self.team.id}/insights/{insight_id}",
            {
                "deleted": True,
                "name": "an insight",
            },  # This request should work also if other fields are provided
        )

        self.assertEqual(
            self.client.get(f"/api/projects/{self.team.id}/insights/{insight_id}").status_code,
            status.HTTP_404_NOT_FOUND,
        )

        update_response = self.client.patch(
            f"/api/projects/{self.team.id}/insights/{insight_id}",
            {
                "deleted": False,
                "name": "an insight",
            },  # This request should work also if other fields are provided
        )
        self.assertEqual(update_response.status_code, status.HTTP_200_OK)

        self.assertEqual(
            self.client.get(f"/api/projects/{self.team.id}/insights/{insight_id}").status_code,
            status.HTTP_200_OK,
        )

        # assert that undeletes end up in the activity log
        activity_response = self.dashboard_api.get_insight_activity(insight_id)

        activity: list[dict] = activity_response["results"]
        # we will have three logged activities (in reverse order) restore, delete, create
        assert [a["activity"] for a in activity] == ["restored", "deleted", "created"]
        undelete_change_log = activity[0]["detail"]["changes"][0]
        assert undelete_change_log == {
            "action": "changed",
            "after": False,
            "before": True,
            "field": "deleted",
            "type": "Insight",
        }

    def test_soft_delete_cannot_be_reversed_for_another_team(self) -> None:
        other_team = Team.objects.create(organization=self.organization, name="other team")
        other_insight = Insight.objects.create(
            filters=Filter(data={"events": [{"id": "$pageview"}]}).to_dict(),
            team=other_team,
            short_id="abcabc",
            deleted=True,
        )

        other_update_response = self.client.patch(
            f"/api/projects/{self.team.id}/insights/{other_insight.id}",
            {"deleted": False},
        )
        self.assertEqual(other_update_response.status_code, status.HTTP_404_NOT_FOUND)

    def test_cancel_running_query(self) -> None:
        # There is no good way of writing a test that tests this without it being very slow
        #  Just verify it doesn't throw an error
        response = self.client.post(
            f"/api/projects/{self.team.id}/insights/cancel",
            {"client_query_id": f"testid"},
        )
        self.assertEqual(response.status_code, 201, response.content)

    def test_including_query_id_does_not_affect_cache_key(self) -> None:
        """
        regression test, by introducing a query_id we were changing the cache key
        so, if you made the same query twice, the second one would not be cached, only because the query id had changed
        """
        self._get_insight_with_client_query_id("b3ef3987-b8e7-4339-b9b8-fa2b65606692")
        response = self._get_insight_with_client_query_id("00000000-b8e7-4339-b9b8-fa2b65606692")

        # Second call should hit cache since client_query_id is not part of the cache key
        assert response.get("is_cached") is True

    def _get_insight_with_client_query_id(self, client_query_id: str) -> dict:
        query_params = f"?events={json.dumps([{'id': '$pageview'}])}&client_query_id={client_query_id}"
        return self.client.get(f"/api/projects/{self.team.id}/insights/trend/{query_params}").json()

    def assert_insight_activity(self, insight_id: Optional[int], expected: list[dict]):
        activity_response = self.dashboard_api.get_insight_activity(insight_id)

        activity: list[dict] = activity_response["results"]
        for item in activity:
            item.pop("id", None)
            for envelope_key in ("is_system", "was_impersonated", "client"):
                item.pop(envelope_key, None)

        self.maxDiff = None
        assert activity == expected

    @also_test_with_materialized_columns(event_properties=["int_value"], person_properties=["fish"])
    @snapshot_clickhouse_queries
    def test_insight_trend_hogql_global_filters(self) -> None:
        _create_person(team=self.team, distinct_ids=["1"], properties={"fish": "there is no fish"})
        with freeze_time("2012-01-14T03:21:34.000Z"):
            for i in range(25):
                _create_event(
                    team=self.team,
                    event="$pageview",
                    distinct_id="1",
                    properties={"int_value": i},
                )
        with freeze_time("2012-01-15T04:01:34.000Z"):
            # 25 events total
            response = self.client.get(
                f"/api/projects/{self.team.id}/insights/trend/",
                data={"events": json.dumps([{"id": "$pageview"}])},
            )
            found_data_points = response.json()["result"][0]["count"]
            self.assertEqual(found_data_points, 25)

            # test trends global property filter
            response = self.client.get(
                f"/api/projects/{self.team.id}/insights/trend/",
                data={
                    "events": json.dumps([{"id": "$pageview"}]),
                    "properties": json.dumps(
                        [
                            {
                                "key": "toInt(properties.int_value) > 10 and 'bla' != 'a%sd'",
                                "type": "hogql",
                            },
                            {
                                "key": "like(person.properties.fish, '%fish%')",
                                "type": "hogql",
                            },
                        ]
                    ),
                },
            )
            self.assertEqual(response.status_code, status.HTTP_200_OK, response.json())
            found_data_points = response.json()["result"][0]["count"]
            self.assertEqual(found_data_points, 14)

            # test trends global property filter with a disallowed placeholder
            response_placeholder = self.client.get(
                f"/api/projects/{self.team.id}/insights/trend/",
                data={
                    "events": json.dumps([{"id": "$pageview"}]),
                    "properties": json.dumps(
                        [
                            {"key": "{team_id} * 5", "type": "hogql"},
                        ]
                    ),
                },
            )
            self.assertEqual(
                response_placeholder.status_code,
                status.HTTP_400_BAD_REQUEST,
                response_placeholder.json(),
            )
            self.assertEqual(
                response_placeholder.json(),
                self.validation_error_response("Unresolved placeholder: {team_id}", code="hogql_query_error"),
            )

    @also_test_with_materialized_columns(event_properties=["int_value"], person_properties=["fish"])
    @snapshot_clickhouse_queries
    def test_insight_trend_hogql_local_filters(self) -> None:
        _create_person(team=self.team, distinct_ids=["1"], properties={"fish": "there is no fish"})
        with freeze_time("2012-01-14T03:21:34.000Z"):
            for i in range(25):
                _create_event(
                    team=self.team,
                    event="$pageview",
                    distinct_id="1",
                    properties={"int_value": i},
                )
        with freeze_time("2012-01-15T04:01:34.000Z"):
            # test trends local property filter
            response = self.client.get(
                f"/api/projects/{self.team.id}/insights/trend/",
                data={
                    "events": json.dumps(
                        [
                            {
                                "id": "$pageview",
                                "properties": json.dumps(
                                    [
                                        {
                                            "key": "toInt(properties.int_value) < 10 and 'bla' != 'a%sd'",
                                            "type": "hogql",
                                        },
                                        {
                                            "key": "like(person.properties.fish, '%fish%')",
                                            "type": "hogql",
                                        },
                                    ]
                                ),
                            }
                        ]
                    )
                },
            )
            found_data_points = response.json()["result"][0]["count"]
            self.assertEqual(found_data_points, 10)

    @also_test_with_materialized_columns(event_properties=["int_value"], person_properties=["fish"])
    @snapshot_clickhouse_queries
    def test_insight_trend_hogql_breakdown(self) -> None:
        _create_person(team=self.team, distinct_ids=["1"], properties={"fish": "there is no fish"})
        with freeze_time("2012-01-14T03:21:34.000Z"):
            for i in range(25):
                _create_event(
                    team=self.team,
                    event="$pageview",
                    distinct_id="1",
                    properties={"int_value": i},
                )
        with freeze_time("2012-01-15T04:01:34.000Z"):
            # test trends breakdown
            response = self.client.get(
                f"/api/projects/{self.team.id}/insights/trend/",
                data={
                    "events": json.dumps([{"id": "$pageview"}]),
                    "breakdown_type": "hogql",
                    "breakdown": "if(toInt(properties.int_value) < 10, 'le%ss', 'more')",
                },
            )
            result = response.json()["result"]
            self.assertEqual(result[0]["count"], 15)
            self.assertEqual(result[0]["breakdown_value"], "more")
            self.assertEqual(result[1]["count"], 10)
            self.assertEqual(result[1]["breakdown_value"], "le%ss")

    @snapshot_clickhouse_queries
    @also_test_with_materialized_columns(event_properties=["int_value"], person_properties=["fish"])
    def test_insight_funnels_hogql_global_filters(self) -> None:
        with freeze_time("2012-01-15T04:01:34.000Z"):
            _create_person(
                team=self.team,
                distinct_ids=["1"],
                properties={"fish": "there is no fish"},
            )
            _create_event(
                team=self.team,
                event="user signed up",
                distinct_id="1",
                properties={"int_value": 1},
            )
            _create_event(
                team=self.team,
                event="user did things",
                distinct_id="1",
                properties={"int_value": 20},
            )
            response = self.client.post(
                f"/api/projects/{self.team.id}/insights/funnel/",
                {
                    "events": [
                        {"id": "user signed up", "type": "events", "order": 0},
                        {"id": "user did things", "type": "events", "order": 1},
                    ],
                    "properties": json.dumps(
                        [
                            {
                                "key": "toInt(properties.int_value) < 10 and 'bla' != 'a%sd'",
                                "type": "hogql",
                            },
                            {
                                "key": "like(person.properties.fish, '%fish%')",
                                "type": "hogql",
                            },
                        ]
                    ),
                    "funnel_window_days": 14,
                },
            )
            self.assertEqual(response.status_code, status.HTTP_200_OK)
            response_json = response.json()
            self.assertEqual(len(response_json["result"]), 2)
            self.assertEqual(response_json["result"][0]["name"], "user signed up")
            self.assertEqual(response_json["result"][0]["count"], 1)
            self.assertEqual(response_json["result"][1]["name"], "user did things")
            self.assertEqual(response_json["result"][1]["count"], 0)
            self.assertEqual(response_json["timezone"], "UTC")

    @snapshot_clickhouse_queries
    @also_test_with_materialized_columns(event_properties=["int_value"], person_properties=["fish"])
    def test_insight_funnels_hogql_local_filters(self) -> None:
        with freeze_time("2012-01-15T04:01:34.000Z"):
            _create_person(
                team=self.team,
                distinct_ids=["1"],
                properties={"fish": "there is no fish"},
            )
            _create_event(
                team=self.team,
                event="user signed up",
                distinct_id="1",
                properties={"int_value": 1},
            )
            _create_event(
                team=self.team,
                event="user did things",
                distinct_id="1",
                properties={"int_value": 20},
            )
            response = self.client.post(
                f"/api/projects/{self.team.id}/insights/funnel/",
                {
                    "events": [
                        {
                            "id": "user signed up",
                            "type": "events",
                            "order": 0,
                            "properties": json.dumps(
                                [
                                    {
                                        "key": "toInt(properties.int_value) < 10 and 'bla' != 'a%sd'",
                                        "type": "hogql",
                                    },
                                    {
                                        "key": "like(person.properties.fish, '%fish%')",
                                        "type": "hogql",
                                    },
                                ]
                            ),
                        },
                        {
                            "id": "user did things",
                            "type": "events",
                            "order": 1,
                            "properties": json.dumps(
                                [
                                    {
                                        "key": "toInt(properties.int_value) < 10 and 'bla' != 'a%sd'",
                                        "type": "hogql",
                                    },
                                    {
                                        "key": "like(person.properties.fish, '%fish%')",
                                        "type": "hogql",
                                    },
                                ]
                            ),
                        },
                    ],
                    "funnel_window_days": 14,
                },
            )
            self.assertEqual(response.status_code, status.HTTP_200_OK)
            response_json = response.json()
            self.assertEqual(len(response_json["result"]), 2)
            self.assertEqual(response_json["result"][0]["name"], "user signed up")
            self.assertEqual(response_json["result"][0]["count"], 1)
            self.assertEqual(response_json["result"][1]["name"], "user did things")
            self.assertEqual(response_json["result"][1]["count"], 0)
            self.assertEqual(response_json["timezone"], "UTC")

    @snapshot_clickhouse_queries
    @also_test_with_materialized_columns(event_properties=["int_value"], person_properties=["fish"])
    def test_insight_funnels_hogql_breakdown(self) -> None:
        with freeze_time("2012-01-15T04:01:34.000Z"):
            _create_person(
                team=self.team,
                distinct_ids=["1"],
                properties={"fish": "there is no fish"},
            )
            _create_event(
                team=self.team,
                event="user signed up",
                distinct_id="1",
                properties={"int_value": 1},
            )
            _create_event(
                team=self.team,
                event="user did things",
                distinct_id="1",
                properties={"int_value": 20},
            )
            response = self.client.post(
                f"/api/projects/{self.team.id}/insights/funnel/",
                {
                    "breakdown_type": "hogql",
                    "breakdowns": [{"property": "person.properties.fish", "type": "hogql"}],
                    "events": [
                        {"id": "user signed up", "type": "events", "order": 0},
                        {"id": "user did things", "type": "events", "order": 1},
                    ],
                    "properties": json.dumps(
                        [
                            {
                                "key": "toInt(properties.int_value) < 10 and 'bla' != 'a%sd'",
                                "type": "hogql",
                            },
                        ]
                    ),
                    "funnel_window_days": 14,
                },
            )
            self.assertEqual(response.status_code, status.HTTP_200_OK, response.json())
            response_json = response.json()
            self.assertEqual(len(response_json["result"]), 1)
            self.assertEqual(len(response_json["result"][0]), 2)
            self.assertEqual(response_json["result"][0][0]["name"], "user signed up")
            self.assertEqual(response_json["result"][0][0]["count"], 1)
            self.assertEqual(response_json["result"][0][0]["breakdown"], ["there is no fish"])
            self.assertEqual(response_json["result"][0][0]["breakdown_value"], ["there is no fish"])
            self.assertEqual(response_json["result"][0][1]["name"], "user did things")
            self.assertEqual(response_json["result"][0][1]["count"], 0)
            self.assertEqual(response_json["result"][0][1]["breakdown"], ["there is no fish"])
            self.assertEqual(response_json["result"][0][1]["breakdown_value"], ["there is no fish"])
            self.assertEqual(response_json["timezone"], "UTC")

    # @snapshot_clickhouse_queries
    @also_test_with_materialized_columns(event_properties=["int_value"], person_properties=["fish"])
    def test_insight_funnels_hogql_breakdown_single(self) -> None:
        with freeze_time("2012-01-15T04:01:34.000Z"):
            _create_person(
                team=self.team,
                distinct_ids=["1"],
                properties={"fish": "there is no fish"},
            )
            _create_event(
                team=self.team,
                event="user signed up",
                distinct_id="1",
                properties={"int_value": 1},
            )
            _create_event(
                team=self.team,
                event="user did things",
                distinct_id="1",
                properties={"int_value": 20},
            )
            response = self.client.post(
                f"/api/projects/{self.team.id}/insights/funnel/",
                {
                    "breakdown_type": "hogql",
                    "breakdown": "person.properties.fish",
                    "events": [
                        {"id": "user signed up", "type": "events", "order": 0},
                        {"id": "user did things", "type": "events", "order": 1},
                    ],
                    "properties": json.dumps(
                        [
                            {
                                "key": "toInt(properties.int_value) < 10 and 'bla' != 'a%sd'",
                                "type": "hogql",
                            },
                        ]
                    ),
                    "funnel_window_days": 14,
                },
            )
            self.assertEqual(response.status_code, status.HTTP_200_OK, response.json())
            response_json = response.json()
            self.assertEqual(len(response_json["result"]), 1)
            self.assertEqual(len(response_json["result"][0]), 2)
            self.assertEqual(response_json["result"][0][0]["name"], "user signed up")
            self.assertEqual(response_json["result"][0][0]["count"], 1)
            self.assertEqual(response_json["result"][0][0]["breakdown"], ["there is no fish"])
            self.assertEqual(response_json["result"][0][0]["breakdown_value"], ["there is no fish"])
            self.assertEqual(response_json["result"][0][1]["name"], "user did things")
            self.assertEqual(response_json["result"][0][1]["count"], 0)
            self.assertEqual(response_json["result"][0][1]["breakdown"], ["there is no fish"])
            self.assertEqual(response_json["result"][0][1]["breakdown_value"], ["there is no fish"])
            self.assertEqual(response_json["timezone"], "UTC")

    def test_insight_funnels_hogql_aggregating_steps(self) -> None:
        with freeze_time("2012-01-15T04:01:34.000Z"):
            _create_person(team=self.team, distinct_ids=["1"], properties={"int_value": 1})
            _create_event(
                team=self.team,
                event="user signed up",
                distinct_id="1",
                properties={"$browser": "Chrome"},
            )
            _create_event(
                team=self.team,
                event="user signed up",
                distinct_id="1",
                properties={"$browser": "Firefox"},
            )
            _create_event(
                team=self.team,
                event="user did things",
                distinct_id="1",
                properties={"$browser": "Chrome"},
            )
            response = self.client.post(
                f"/api/projects/{self.team.id}/insights/funnel/",
                {
                    "insight": "FUNNELS",
                    "entity_type": "events",
                    "events": [
                        {
                            "id": "user signed up",
                            "type": "events",
                            "order": 0,
                            "math": "total",
                        },
                        {
                            "id": "user did things",
                            "type": "events",
                            "order": 1,
                            "math": "total",
                        },
                    ],
                    "properties": json.dumps(
                        [
                            {
                                "key": "toInt(person.properties.int_value) < 10 and 'bla' != 'a%sd'",
                                "type": "hogql",
                            },
                        ]
                    ),
                    "funnel_aggregate_by_hogql": "properties.$browser",
                    "funnel_viz_type": "steps",
                },
            )
            self.assertEqual(response.status_code, status.HTTP_200_OK)
            response_json = response.json()
            self.assertEqual(len(response_json["result"]), 2)
            self.assertEqual(response_json["result"][0]["name"], "user signed up")
            self.assertEqual(response_json["result"][0]["count"], 2)
            self.assertEqual(response_json["result"][1]["name"], "user did things")
            self.assertEqual(response_json["result"][1]["count"], 1)
            self.assertEqual(response_json["timezone"], "UTC")

    @skip("Compatibility issue CH 23.12 (see #21318)")
    def test_insight_funnels_hogql_aggregating_time_to_convert(self) -> None:
        with freeze_time("2012-01-15T04:01:34.000Z"):
            _create_person(team=self.team, distinct_ids=["1"], properties={"int_value": 1})
            _create_event(
                team=self.team,
                event="user signed up",
                distinct_id="1",
                properties={"$browser": "Chrome"},
            )
        with freeze_time("2012-01-15T04:01:36.500Z"):
            _create_event(
                team=self.team,
                event="user signed up",
                distinct_id="1",
                properties={"$browser": "Firefox"},
            )
        with freeze_time("2012-01-15T04:01:38.200Z"):
            _create_event(
                team=self.team,
                event="user did things",
                distinct_id="1",
                properties={"$browser": "Chrome"},
            )
        with freeze_time("2012-01-16T04:01:38.200Z"):
            response = self.client.post(
                f"/api/projects/{self.team.id}/insights/funnel/",
                {
                    "insight": "FUNNELS",
                    "entity_type": "events",
                    "events": [
                        {
                            "id": "user signed up",
                            "type": "events",
                            "order": 0,
                            "math": "total",
                        },
                        {
                            "id": "user did things",
                            "type": "events",
                            "order": 1,
                            "math": "total",
                        },
                    ],
                    "properties": json.dumps(
                        [
                            {
                                "key": "toInt(person.properties.int_value) < 10 and 'bla' != 'a%sd'",
                                "type": "hogql",
                            },
                        ]
                    ),
                    "funnel_aggregate_by_hogql": "properties.$browser",
                    "funnel_viz_type": "time_to_convert",
                    "date_from": "-14d",
                    "date_to": None,
                },
            )
            self.assertEqual(response.status_code, status.HTTP_200_OK)
            response_json = response.json()
            self.assertEqual(response_json["result"]["bins"], [[4.0, 1], [64.0, 0]])
            self.assertEqual(response_json["result"]["average_conversion_time"], 4.0)
            self.assertEqual(response_json["timezone"], "UTC")

    def test_insight_funnels_hogql_aggregating_trends(self) -> None:
        with freeze_time("2012-01-15T04:01:34.000Z"):
            _create_person(team=self.team, distinct_ids=["1"], properties={"int_value": 1})
            _create_event(
                team=self.team,
                event="user signed up",
                distinct_id="1",
                properties={"$browser": "Chrome"},
            )
        with freeze_time("2012-01-15T04:01:36.500Z"):
            _create_event(
                team=self.team,
                event="user signed up",
                distinct_id="1",
                properties={"$browser": "Firefox"},
            )
        with freeze_time("2012-01-15T04:01:38.200Z"):
            _create_event(
                team=self.team,
                event="user did things",
                distinct_id="1",
                properties={"$browser": "Chrome"},
            )
        with freeze_time("2012-01-16T04:01:38.200Z"):
            response = self.client.post(
                f"/api/projects/{self.team.id}/insights/funnel/",
                {
                    "insight": "FUNNELS",
                    "entity_type": "events",
                    "events": [
                        {"id": "user signed up", "type": "events", "order": 0},
                        {"id": "user did things", "type": "events", "order": 1},
                    ],
                    "properties": json.dumps(
                        [
                            {
                                "key": "toInt(person.properties.int_value) < 10 and 'bla' != 'a%sd'",
                                "type": "hogql",
                            },
                        ]
                    ),
                    "funnel_aggregate_by_hogql": "properties.$browser",
                    "funnel_viz_type": "trends",
                },
            )
            self.assertEqual(response.status_code, status.HTTP_200_OK)
            response_json = response.json()
            self.assertEqual(len(response_json["result"]), 1)
            self.assertEqual(
                response_json["result"][0]["data"],
                [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 50.0, 0.0],
            )
            self.assertEqual(
                response_json["result"][0]["days"],
                [
                    "2012-01-09",
                    "2012-01-10",
                    "2012-01-11",
                    "2012-01-12",
                    "2012-01-13",
                    "2012-01-14",
                    "2012-01-15",
                    "2012-01-16",
                ],
            )
            self.assertEqual(
                response_json["result"][0]["labels"],
                [
                    "9-Jan-2012",
                    "10-Jan-2012",
                    "11-Jan-2012",
                    "12-Jan-2012",
                    "13-Jan-2012",
                    "14-Jan-2012",
                    "15-Jan-2012",
                    "16-Jan-2012",
                ],
            )
            self.assertEqual(response_json["timezone"], "UTC")

    def test_insight_with_filters_via_hogql(self) -> None:
        filter_dict = {"insight": "LIFECYCLE", "events": [{"id": "$pageview"}]}

        insight = Insight.objects.create(
            filters=Filter(data=filter_dict).to_dict(),
            team=self.team,
            short_id="xyz123",
        )

        # fresh response
        response = self.client.get(f"/api/projects/{self.team.id}/insights/{insight.id}/?refresh=true")
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.json()["result"][0]["data"], [0, 0, 0, 0, 0, 0, 0, 0])
        self.assertFalse(response.json()["is_cached"])

        # cached response
        response = self.client.get(f"/api/projects/{self.team.id}/insights/{insight.id}/?refresh=false&use_cache=true")
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.json()["result"][0]["data"], [0, 0, 0, 0, 0, 0, 0, 0])
        self.assertTrue(response.json()["is_cached"])

    def test_insight_returns_cached_hogql(self) -> None:
        insight = Insight.objects.create(
            query={
                "kind": NodeKind.INSIGHT_VIZ_NODE.value,
                "source": {
                    "filterTestAccounts": False,
                    "kind": InsightNodeKind.TRENDS_QUERY.value,
                    "series": [
                        {
                            "kind": NodeKind.EVENTS_NODE.value,
                            "event": "$pageview",
                            "name": "$pageview",
                            "math": "total",
                        }
                    ],
                    "interval": "day",
                },
            },
            team=self.team,
            created_by=self.user,
        )

        response = self.client.get(
            f"/api/projects/{self.team.id}/insights",
            data={
                "short_id": insight.short_id,
            },
        ).json()

        self.assertNotIn("code", response)  # Watching out for an error code
        self.assertEqual(response["results"][0]["last_refresh"], None)
        self.assertIsNone(response["results"][0]["hogql"])

        response = self.client.get(
            f"/api/projects/{self.team.id}/insights",
            data={"short_id": insight.short_id, "refresh": "true"},
        ).json()

        self.assertNotIn("code", response)
        self.assertIsNotNone(response["results"][0]["hogql"])

    def test_insight_returns_cached_types(self) -> None:
        insight = Insight.objects.create(
            query={
                "kind": NodeKind.HOG_QL_QUERY,
                "query": """
                        select toDate(timestamp) as timestamp, count()
                        from events
                        where {filters} and timestamp <= now()
                        group by timestamp
                        order by timestamp asc
                        limit 100
                    """,
            },
            team=self.team,
            created_by=self.user,
        )

        response = self.client.get(
            f"/api/projects/{self.team.id}/insights",
            data={
                "short_id": insight.short_id,
            },
        ).json()

        self.assertNotIn("code", response)
        self.assertEqual(response["results"][0]["last_refresh"], None)
        self.assertIsNone(response["results"][0]["types"])

        response = self.client.get(
            f"/api/projects/{self.team.id}/insights",
            data={"short_id": insight.short_id, "refresh": "true"},
        ).json()

        self.assertNotIn("code", response)
        self.assertIsNotNone(response["results"][0]["types"])

    @parameterized.expand(
        [
            ("standalone", False),
            ("with_dashboard_context", True),
        ]
    )
    def test_insight_variables_overrides(self, _name: str, attach_to_dashboard: bool) -> None:
        variable = InsightVariable.objects.create(
            team=self.team, name="Test 1", code_name="test_1", default_value="some_default_value", type="String"
        )
        insight = Insight.objects.create(
            filters={},
            query={
                "kind": "DataVisualizationNode",
                "source": {
                    "kind": "HogQLQuery",
                    "query": "select {variables.test_1}",
                    "variables": {
                        str(variable.id): {
                            "code_name": variable.code_name,
                            "variableId": str(variable.id),
                        }
                    },
                },
                "chartSettings": {},
                "tableSettings": {},
            },
            team=self.team,
        )

        request_data: dict[str, str] = {
            "variables_override": json.dumps(
                {
                    str(variable.id): {
                        "code_name": variable.code_name,
                        "variableId": str(variable.id),
                        "value": "override value!",
                    }
                }
            ),
        }

        if attach_to_dashboard:
            dashboard = Dashboard.objects.create(team=self.team, name="dashboard 1", created_by=self.user)
            DashboardTile.objects.create(dashboard=dashboard, insight=insight)
            request_data["from_dashboard"] = str(dashboard.pk)

        response = self.client.get(
            f"/api/projects/{self.team.id}/insights/{insight.pk}",
            data=request_data,
        ).json()

        assert isinstance(response["query"], dict)
        assert isinstance(response["query"]["source"], dict)
        assert isinstance(response["query"]["source"]["variables"], dict)

        assert len(response["query"]["source"]["variables"].keys()) == 1
        for key, value in response["query"]["source"]["variables"].items():
            assert key == str(variable.id)
            assert value["code_name"] == variable.code_name
            assert value["variableId"] == str(variable.id)
            assert value["value"] == "override value!"

    @parameterized.expand(
        [
            ("standalone", False),
            ("with_dashboard_context", True),
        ]
    )
    def test_insight_filters_overrides(self, _name: str, attach_to_dashboard: bool) -> None:
        insight = Insight.objects.create(
            filters={},
            query={
                "kind": "InsightVizNode",
                "source": {
                    "kind": "TrendsQuery",
                    "series": [{"event": "$pageview", "kind": "EventsNode"}],
                    "dateRange": {"date_from": "-30d"},
                },
            },
            team=self.team,
        )

        request_data: dict[str, str] = {
            "filters_override": json.dumps({"date_from": "-7d"}),
        }

        if attach_to_dashboard:
            dashboard = Dashboard.objects.create(team=self.team, name="dashboard 1", created_by=self.user)
            DashboardTile.objects.create(dashboard=dashboard, insight=insight)
            request_data["from_dashboard"] = str(dashboard.pk)

        response = self.client.get(
            f"/api/projects/{self.team.id}/insights/{insight.pk}",
            data=request_data,
        ).json()

        assert isinstance(response["query"], dict)
        assert isinstance(response["query"]["source"], dict)
        assert response["query"]["source"]["dateRange"]["date_from"] == "-7d"

    def test_tile_filters_merge_with_dashboard_filters_in_returned_query(self) -> None:
        insight = Insight.objects.create(
            filters={},
            query={
                "kind": "InsightVizNode",
                "source": {
                    "kind": "TrendsQuery",
                    "series": [{"event": "$pageview", "kind": "EventsNode"}],
                    "dateRange": {"date_from": "-30d"},
                },
            },
            team=self.team,
        )
        dashboard = Dashboard.objects.create(team=self.team, name="dashboard 1", created_by=self.user)
        DashboardTile.objects.create(
            dashboard=dashboard,
            insight=insight,
            filters_overrides={"date_from": "-7d"},
        )

        person_filter = {"key": "$initial_host", "type": "person", "operator": "exact", "value": ["readdy.ai"]}
        dashboard_filters = {"properties": [person_filter]}

        response = self.client.get(
            f"/api/projects/{self.team.id}/insights/{insight.pk}",
            data={
                "from_dashboard": str(dashboard.pk),
                "filters_override": json.dumps(dashboard_filters),
            },
        ).json()

        source = response["query"]["source"]
        assert source["dateRange"]["date_from"] == "-7d"
        merged_properties = source.get("properties") or []
        assert any(p.get("key") == "$initial_host" and p.get("value") == ["readdy.ai"] for p in merged_properties), (
            f"Dashboard person filter should be merged into the tile query. Got: {merged_properties}"
        )

    def test_tile_property_override_replaces_insight_and_dashboard_on_same_key(self) -> None:
        # Insight, dashboard, and tile all filter $browser. The tile must win outright on that key —
        # over both the insight's own filter and the dashboard's — instead of AND-ing all three (which
        # would be an impossible intersection and return nothing).
        insight = Insight.objects.create(
            query={
                "kind": "InsightVizNode",
                "source": {
                    "kind": "TrendsQuery",
                    "series": [{"event": "$pageview", "kind": "EventsNode"}],
                    "properties": [{"key": "$browser", "type": "event", "operator": "exact", "value": ["Chrome"]}],
                },
            },
            team=self.team,
        )
        dashboard = Dashboard.objects.create(team=self.team, name="dashboard 1", created_by=self.user)
        DashboardTile.objects.create(
            dashboard=dashboard,
            insight=insight,
            filters_overrides={
                "properties": [{"key": "$browser", "type": "event", "operator": "exact", "value": ["Firefox"]}]
            },
        )
        dashboard_filters = {
            "properties": [{"key": "$browser", "type": "event", "operator": "exact", "value": ["Chrome", "Safari"]}]
        }

        response = self.client.get(
            f"/api/projects/{self.team.id}/insights/{insight.pk}",
            data={"from_dashboard": str(dashboard.pk), "filters_override": json.dumps(dashboard_filters)},
        ).json()

        browser_values = self._collect_property_values(response["query"]["source"].get("properties"), "$browser")
        assert browser_values == [["Firefox"]], f"Tile $browser should replace all others. Got: {browser_values}"
        assert response["filter_override_context"] == {
            "dashboard": None,
            "tile": {"properties": [{"key": "$browser", "type": "event", "operator": "exact", "value": ["Firefox"]}]},
            "overridden_dashboard": {
                "properties": [
                    {
                        "key": "$browser",
                        "type": "event",
                        "operator": "exact",
                        "value": ["Chrome", "Safari"],
                    }
                ]
            },
        }

    def test_tile_ignoring_dashboard_filters_keeps_insight_query_untouched(self) -> None:
        # The tile opts out of dashboard filters entirely, so neither the dashboard's date range nor its
        # properties may reach the returned query; the tile's own overrides still apply.
        insight = Insight.objects.create(
            query={
                "kind": "InsightVizNode",
                "source": {
                    "kind": "TrendsQuery",
                    "series": [{"event": "$pageview", "kind": "EventsNode"}],
                    "dateRange": {"date_from": "-90d"},
                },
            },
            team=self.team,
        )
        dashboard = Dashboard.objects.create(team=self.team, name="dashboard 1", created_by=self.user)
        DashboardTile.objects.create(
            dashboard=dashboard,
            insight=insight,
            filters_overrides={
                "ignoreDashboardFilters": True,
                "properties": [{"key": "$browser", "type": "event", "operator": "exact", "value": ["Firefox"]}],
            },
        )
        dashboard_filters = {
            "date_from": "-7d",
            "properties": [{"key": "$country", "type": "event", "operator": "exact", "value": ["US"]}],
        }

        response = self.client.get(
            f"/api/projects/{self.team.id}/insights/{insight.pk}",
            data={"from_dashboard": str(dashboard.pk), "filters_override": json.dumps(dashboard_filters)},
        ).json()

        source = response["query"]["source"]
        assert source["dateRange"]["date_from"] == "-90d"
        assert self._collect_property_values(source.get("properties"), "$country") == []
        assert self._collect_property_values(source.get("properties"), "$browser") == [["Firefox"]]
        assert response["filter_override_context"] == {
            "dashboard": None,
            "tile": {
                "ignoreDashboardFilters": True,
                "properties": [{"key": "$browser", "type": "event", "operator": "exact", "value": ["Firefox"]}],
            },
            "overridden_dashboard": dashboard_filters,
        }

    def test_dashboard_property_override_replaces_insight_on_same_key(self) -> None:
        # Insight and dashboard both filter $browser, no tile. The dashboard must win on that key —
        # over the insight's own filter — instead of AND-ing (Chrome AND Safari would return nothing).
        insight = Insight.objects.create(
            query={
                "kind": "InsightVizNode",
                "source": {
                    "kind": "TrendsQuery",
                    "series": [{"event": "$pageview", "kind": "EventsNode"}],
                    "properties": [{"key": "$browser", "type": "event", "operator": "exact", "value": ["Chrome"]}],
                },
            },
            team=self.team,
        )
        dashboard = Dashboard.objects.create(team=self.team, name="dashboard 1", created_by=self.user)
        DashboardTile.objects.create(dashboard=dashboard, insight=insight)
        dashboard_filters = {
            "properties": [{"key": "$browser", "type": "event", "operator": "exact", "value": ["Safari"]}]
        }

        response = self.client.get(
            f"/api/projects/{self.team.id}/insights/{insight.pk}",
            data={"from_dashboard": str(dashboard.pk), "filters_override": json.dumps(dashboard_filters)},
        ).json()

        browser_values = self._collect_property_values(response["query"]["source"].get("properties"), "$browser")
        assert browser_values == [["Safari"]], f"Dashboard $browser should replace the insight's. Got: {browser_values}"

    def test_grouped_dashboard_property_override_does_not_crash_retrieval(self) -> None:
        insight = Insight.objects.create(
            query={
                "kind": "InsightVizNode",
                "source": {
                    "kind": "TrendsQuery",
                    "series": [{"event": "$pageview", "kind": "EventsNode"}],
                },
            },
            team=self.team,
        )
        dashboard = Dashboard.objects.create(team=self.team, name="dashboard 1", created_by=self.user)
        DashboardTile.objects.create(dashboard=dashboard, insight=insight)
        country_filter = {"key": "$country", "type": "event", "operator": "exact", "value": ["US"]}

        response = self.client.get(
            f"/api/projects/{self.team.id}/insights/{insight.pk}",
            data={
                "from_dashboard": str(dashboard.pk),
                "filters_override": json.dumps(
                    {"properties": {"type": "AND", "values": [{"type": "AND", "values": [country_filter]}]}}
                ),
            },
        )

        assert response.status_code == status.HTTP_200_OK
        country_values = self._collect_property_values(response.json()["query"]["source"].get("properties"), "$country")
        assert country_values == [["US"]]

    def test_from_dashboard_ignores_dashboard_context_without_view_access(self) -> None:
        self.organization.available_product_features = [
            {"key": AvailableFeature.ACCESS_CONTROL, "name": AvailableFeature.ACCESS_CONTROL},
        ]
        self.organization.save()
        viewer = self._create_user("viewer@posthog.com", level=OrganizationMembership.Level.MEMBER)
        insight = Insight.objects.create(
            query={
                "kind": "InsightVizNode",
                "source": {
                    "kind": "TrendsQuery",
                    "series": [{"event": "$pageview", "kind": "EventsNode"}],
                },
            },
            team=self.team,
            created_by=self.user,
        )
        dashboard = Dashboard.objects.create(
            team=self.team,
            name="restricted dashboard",
            created_by=self.user,
            filters={
                "properties": [
                    {"key": "email", "type": "person", "operator": "exact", "value": ["private@example.com"]}
                ]
            },
        )
        DashboardTile.objects.create(
            dashboard=dashboard,
            insight=insight,
            filters_overrides={
                "properties": [{"key": "$browser", "type": "event", "operator": "exact", "value": ["Chrome"]}]
            },
        )
        AccessControl.objects.create(
            resource="dashboard",
            resource_id=dashboard.id,
            team=self.team,
            access_level="none",
        )
        self.client.force_login(viewer)

        response = self.client.get(
            f"/api/projects/{self.team.id}/insights/{insight.pk}",
            data={"from_dashboard": str(dashboard.pk)},
        )

        assert response.status_code == status.HTTP_200_OK
        response_data = response.json()
        assert response_data["filter_override_context"] is None
        properties = response_data["query"]["source"].get("properties")
        assert self._collect_property_values(properties, "email") == []
        assert self._collect_property_values(properties, "$browser") == []

    @staticmethod
    def _collect_property_values(properties: object, key: str) -> list:
        """Flatten a query's properties (flat list or nested PropertyGroupFilter) to the values set for one key."""
        found: list = []
        if isinstance(properties, list):
            for prop in properties:
                found.extend(TestInsight._collect_property_values(prop, key))
        elif isinstance(properties, dict):
            if isinstance(properties.get("values"), list):
                found.extend(TestInsight._collect_property_values(properties["values"], key))
            elif properties.get("key") == key:
                found.append(properties.get("value"))
        return found

    def test_insight_cache_key_changes_with_variable_override_when_tile_filters_are_set(self) -> None:
        dashboard = Dashboard.objects.create(
            team=self.team,
            name="dashboard 1",
            created_by=self.user,
        )
        variable = InsightVariable.objects.create(
            team=self.team, name="Organization", code_name="organization", default_value="default", type="String"
        )
        insight = Insight.objects.create(
            filters={},
            query={
                "kind": "DataVisualizationNode",
                "source": {
                    "kind": "HogQLQuery",
                    "query": "select {variables.organization}",
                    "variables": {
                        str(variable.id): {
                            "code_name": variable.code_name,
                            "variableId": str(variable.id),
                        }
                    },
                },
                "chartSettings": {},
                "tableSettings": {},
            },
            team=self.team,
        )
        DashboardTile.objects.create(dashboard=dashboard, insight=insight)

        base_query_params: dict[str, str] = {
            "from_dashboard": str(dashboard.pk),
            "refresh": "blocking",
            "tile_filters_override": json.dumps({"date_from": "all", "explicitDate": False}),
        }

        some_org_response = self.client.get(
            f"/api/projects/{self.team.id}/insights/{insight.pk}",
            data={
                **base_query_params,
                "variables_override": json.dumps(
                    {
                        str(variable.id): {
                            "code_name": variable.code_name,
                            "variableId": str(variable.id),
                            "value": "Some org",
                        }
                    }
                ),
            },
        ).json()

        another_org_response = self.client.get(
            f"/api/projects/{self.team.id}/insights/{insight.pk}",
            data={
                **base_query_params,
                "variables_override": json.dumps(
                    {
                        str(variable.id): {
                            "code_name": variable.code_name,
                            "variableId": str(variable.id),
                            "value": "Another org",
                        }
                    }
                ),
            },
        ).json()

        assert some_org_response["filters_hash"] != another_org_response["filters_hash"]

    def test_insight_access_control_filtering(self) -> None:
        """Test that insights are properly filtered based on access control."""
        self.organization.available_product_features = [
            {"key": AvailableFeature.ACCESS_CONTROL, "name": AvailableFeature.ACCESS_CONTROL},
        ]
        self.organization.save()

        user2 = self._create_user("test2@posthog.com")

        visible_insight = Insight.objects.create(
            team=self.team,
            name="Public Insight",
            created_by=self.user,
            filters={"events": [{"id": "$pageview"}]},
        )
        hidden_insight = Insight.objects.create(
            team=self.team,
            name="Hidden Insight",
            created_by=self.user,
            filters={"events": [{"id": "$pageview"}]},
        )
        AccessControl.objects.create(
            resource="insight", resource_id=hidden_insight.id, team=self.team, access_level="none"
        )

        # Verify we can access visible insights
        self.client.force_login(user2)
        response = self.client.get(f"/api/projects/{self.team.pk}/insights/")
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        insight_ids = [insight["id"] for insight in response.json()["results"]]
        self.assertIn(visible_insight.id, insight_ids)
        self.assertNotIn(hidden_insight.id, insight_ids)

        # Verify we can access all insights as creator
        self.client.force_login(self.user)
        response = self.client.get(f"/api/projects/{self.team.pk}/insights/")
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn(visible_insight.id, [insight["id"] for insight in response.json()["results"]])
        self.assertIn(hidden_insight.id, [insight["id"] for insight in response.json()["results"]])

    def test_insight_activity_respects_access_control(self) -> None:
        self.organization.available_product_features = [
            {"key": AvailableFeature.ACCESS_CONTROL, "name": AvailableFeature.ACCESS_CONTROL},
            {"key": AvailableFeature.ROLE_BASED_ACCESS, "name": AvailableFeature.ROLE_BASED_ACCESS},
        ]
        self.organization.save()

        user2 = self._create_user("test2@posthog.com", level=OrganizationMembership.Level.MEMBER)

        insight = Insight.objects.create(
            team=self.team,
            name="Hidden Insight",
            created_by=self.user,
        )
        AccessControl.objects.create(resource="insight", resource_id=insight.id, team=self.team, access_level="none")

        self.client.force_login(user2)

        retrieve_response = self.client.get(f"/api/projects/{self.team.pk}/insights/{insight.id}/")
        self.assertEqual(retrieve_response.status_code, status.HTTP_403_FORBIDDEN)

        activity_response = self.client.get(f"/api/projects/{self.team.pk}/insights/{insight.id}/activity/")
        self.assertEqual(activity_response.status_code, status.HTTP_403_FORBIDDEN)

    def test_create_insight_in_specific_folder(self):
        response = self.client.post(
            f"/api/projects/{self.team.id}/insights/",
            {
                "name": "My test insight in folder",
                "filters": {"events": [{"id": "$pageview"}]},
                "_create_in_folder": "Special Folder/Subfolder",
                "saved": True,
            },
            format="json",
        )
        self.assertEqual(response.status_code, status.HTTP_201_CREATED, response.json())
        insight_id = response.json()["short_id"]

        assert insight_id is not None

        from posthog.models.file_system.file_system import FileSystem

        fs_entry = FileSystem.objects.filter(team=self.team, ref=str(insight_id), type="insight").first()
        assert fs_entry is not None
        assert "Special Folder/Subfolder" in fs_entry.path

    def test_insight_with_variables_match_existing_variables(self):
        """Test that variables on insights are always referencing existing variables"""

        # Create an insight with a DataVisualizationNode query that references a fake variable
        insight = Insight.objects.create(
            team=self.team,
            query={
                "kind": "DataVisualizationNode",
                "source": {
                    "kind": "HogQLQuery",
                    "query": "SELECT {variables.test_var}",
                    "variables": {
                        "123e4567-e89b-12d3-a456-426614174000": {
                            "code_name": "test_var",
                            "variableId": "123e4567-e89b-12d3-a456-426614174000",
                        }
                    },
                },
                "display": "ActionsTable",
                "chartSettings": {"seriesBreakdownColumn": None},
                "tableSettings": {"conditionalFormatting": []},
            },
        )

        response = self.client.get(f"/api/projects/{self.team.id}/insights/{insight.id}")
        self.assertEqual(response.status_code, 200)

        response_data = response.json()
        self.assertIn("query", response_data)
        self.assertIn("source", response_data["query"])
        self.assertIn("variables", response_data["query"]["source"])

        # only one variable should be included
        self.assertEqual(len(response_data["query"]["source"]["variables"]), 0)

        variable = InsightVariable.objects.create(team=self.team, code_name="test_var", name="Test Variable")

        # # Get the insight via the API
        response = self.client.get(f"/api/projects/{self.team.id}/insights/{insight.id}")
        self.assertEqual(response.status_code, 200)

        # # Verify both variables are properly included in the response
        response_data = response.json()
        self.assertIn("query", response_data)
        self.assertIn("source", response_data["query"])
        self.assertIn("variables", response_data["query"]["source"])

        # # Check that the variable properties are included
        variable_id = str(variable.id)
        self.assertIn(variable_id, response_data["query"]["source"]["variables"])
        variable_data = response_data["query"]["source"]["variables"][variable_id]
        self.assertEqual(variable_data["code_name"], "test_var")
        self.assertEqual(variable_data["variableId"], variable_id)

    def test_list_insights_with_short_id_includes_all_if_admin(self) -> None:
        """
        Test that when listing insights with short_id parameter, organization admins can see all insights
        regardless of access controls, but regular users are still filtered by access controls.
        """
        from posthog.models.organization import OrganizationMembership

        from products.access_control.backend.models.access_control import AccessControl

        self.organization.available_product_features = [
            {"key": AvailableFeature.ACCESS_CONTROL, "name": AvailableFeature.ACCESS_CONTROL},
        ]
        self.organization.save()

        # Create insights with different access levels
        filter_dict = {"events": [{"id": "$pageview"}]}

        # Create an insight that will be blocked for regular users
        blocked_insight_short_id = "block123"
        blocked_insight = Insight.objects.create(
            filters=Filter(data=filter_dict).to_dict(),
            team=self.team,
            short_id=blocked_insight_short_id,
            name="Blocked Insight",
        )

        # Create an insight that will be accessible
        accessible_insight_short_id = "access_456"
        accessible_insight = Insight.objects.create(
            filters=Filter(data=filter_dict).to_dict(),
            team=self.team,
            short_id=accessible_insight_short_id,
            name="Accessible Insight",
        )

        # Create access control that blocks the first insight for regular users
        AccessControl.objects.create(
            team=self.team,
            resource="insight",
            resource_id=str(blocked_insight.id),
            access_level="none",
        )

        # Test 1: Regular user should not see blocked insight in regular list
        response = self.client.get(f"/api/projects/{self.team.id}/insights/")
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        results = response.json()["results"]
        insight_ids = [insight["id"] for insight in results]
        self.assertIn(accessible_insight.id, insight_ids)
        self.assertNotIn(blocked_insight.id, insight_ids)

        # Test 2: Regular user should not see blocked insight even with short_id
        response = self.client.get(f"/api/projects/{self.team.id}/insights/?short_id={blocked_insight_short_id}")
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        results = response.json()["results"]
        self.assertEqual(len(results), 0)  # Should be filtered out

        # Test 3: Regular user should see accessible insight with short_id
        response = self.client.get(f"/api/projects/{self.team.id}/insights/?short_id={accessible_insight_short_id}")
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        results = response.json()["results"]
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0]["id"], accessible_insight.id)

        # Test 4: Organization admin should see all insights regardless of access controls
        self.organization_membership.level = OrganizationMembership.Level.ADMIN
        self.organization_membership.save()

        # Admin should see only accessible insight in regular list
        response = self.client.get(f"/api/projects/{self.team.id}/insights/")
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        results = response.json()["results"]
        insight_ids = [insight["id"] for insight in results]
        self.assertIn(accessible_insight.id, insight_ids)
        self.assertNotIn(blocked_insight.id, insight_ids)

        # Admin should see blocked insight with short_id (include_all_if_admin=True)
        response = self.client.get(f"/api/projects/{self.team.id}/insights/?short_id={blocked_insight_short_id}")
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        results = response.json()["results"]
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0]["id"], blocked_insight.id)
        self.assertEqual(results[0]["short_id"], blocked_insight_short_id)

        # Admin should see accessible insight with short_id
        response = self.client.get(f"/api/projects/{self.team.id}/insights/?short_id={accessible_insight_short_id}")
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        results = response.json()["results"]
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0]["id"], accessible_insight.id)
        self.assertEqual(results[0]["short_id"], accessible_insight_short_id)

    def test_dashboard_breakdown_filter_migration(self):
        """Test that dashboard breakdown filters work with retention queries and single breakdowns"""

        retention_query = {
            "kind": "RetentionQuery",
            "dateRange": {"date_from": "-30d", "date_to": None},
            "retentionFilter": {
                "targetEntity": {"id": "$pageview", "type": "events"},
                "returningEntity": {"id": "$pageview", "type": "events"},
                "totalIntervals": 7,
            },
        }

        insight = Insight.objects.create(
            team=self.team,
            name="Test Retention Insight",
            created_by=self.user,
            query=retention_query,
        )

        # Create dashboard with legacy breakdown filter to test single breakdown support
        dashboard = Dashboard.objects.create(
            team=self.team,
            name="Test Dashboard",
            created_by=self.user,
            filters={
                "breakdown_filter": {
                    "breakdown": "browser",
                    "breakdown_type": "person",
                }
            },
        )

        DashboardTile.objects.create(dashboard=dashboard, insight=insight)

        # Test that retention query doesn't error when breakdown is applied
        response = self.client.get(
            f"/api/projects/{self.team.id}/insights/{insight.id}/?refresh=force_blocking&from_dashboard={dashboard.id}"
        )

        self.assertEqual(response.status_code, 200)
        response_data = response.json()

        self.assertEqual(response_data["id"], insight.id)
        self.assertEqual(response_data["name"], "Test Retention Insight")

        self.assertIn("query", response_data)
        query_data = response_data["query"]
        self.assertEqual(query_data["kind"], "RetentionQuery")

        # Verify breakdown filter is applied correctly
        self.assertIn("breakdownFilter", query_data)
        breakdown_filter = query_data["breakdownFilter"]

        # Should have the single breakdown applied
        self.assertEqual(breakdown_filter.get("breakdown"), "browser")
        self.assertEqual(breakdown_filter.get("breakdown_type"), "person")

    def test_updating_query_updates_query_metadata(self):
        """
        Test that updating the query of an insight also updates the query metadata.
        """
        insight = Insight.objects.create(
            query={
                "kind": NodeKind.INSIGHT_VIZ_NODE.value,
                "source": {
                    "filterTestAccounts": False,
                    "kind": InsightNodeKind.TRENDS_QUERY.value,
                    "series": [
                        {
                            "kind": NodeKind.EVENTS_NODE.value,
                            "event": "$pageview",
                            "name": "$pageview",
                            "math": "total",
                        }
                    ],
                    "interval": "day",
                },
            },
            team=self.team,
            created_by=self.user,
        )

        # Initial query metadata should not be empty
        self.assertIsNotNone(insight.query_metadata)
        initial_metadata = insight.query_metadata.copy() if insight.query_metadata is not None else None

        # update the query for the insight
        new_query = {
            "kind": NodeKind.INSIGHT_VIZ_NODE.value,
            "source": {
                "filterTestAccounts": False,
                "kind": InsightNodeKind.TRENDS_QUERY.value,
                "series": [
                    {
                        "kind": NodeKind.EVENTS_NODE.value,
                        "event": "$exception",
                        "name": "$exception",
                        "math": "total",
                    }
                ],
                "interval": "day",
            },
        }
        insight.query = new_query
        insight.save()
        insight.refresh_from_db()

        # Query metadata should be updated
        updated_metadata = insight.query_metadata
        self.assertIsNotNone(updated_metadata)
        self.assertNotEqual(initial_metadata, updated_metadata)

    def test_updating_insight_with_no_query_changes_does_not_update_query_metadata(self):
        """
        Test that updating an insight without changing the query does not update the query metadata.
        """
        insight = Insight.objects.create(
            query={
                "kind": NodeKind.INSIGHT_VIZ_NODE.value,
                "source": {
                    "filterTestAccounts": False,
                    "kind": InsightNodeKind.TRENDS_QUERY.value,
                    "series": [
                        {
                            "kind": NodeKind.EVENTS_NODE.value,
                            "event": "$pageview",
                            "name": "$pageview",
                            "math": "total",
                        }
                    ],
                    "interval": "day",
                },
            },
            team=self.team,
            created_by=self.user,
        )

        # Initial query metadata should not be empty
        self.assertIsNotNone(insight.query_metadata)
        initial_metadata = insight.query_metadata.copy() if insight.query_metadata is not None else None

        # update the name for the insight without changing the query
        insight.name = "Updated Insight Name"
        insight.save()
        insight.refresh_from_db()

        # Query metadata should remain unchanged
        updated_metadata = insight.query_metadata
        self.assertIsNotNone(updated_metadata)
        self.assertEqual(initial_metadata, updated_metadata)

    def test_funnel_breakdown_override(self):
        _create_person(team=self.team, distinct_ids=["person_1"])
        _create_event(
            team=self.team,
            event="$pageview",
            distinct_id="person_1",
            properties={"$browser": "Chrome", "$geoip_country_code": "US"},
        )

        insight = Insight.objects.create(
            query={
                "kind": NodeKind.INSIGHT_VIZ_NODE.value,
                "source": {
                    "kind": InsightNodeKind.FUNNELS_QUERY.value,
                    "series": [
                        {
                            "kind": NodeKind.EVENTS_NODE.value,
                            "event": "$pageview",
                            "name": "$pageview",
                        },
                        {
                            "kind": NodeKind.EVENTS_NODE.value,
                            "event": "$pageview",
                            "name": "$pageview",
                        },
                    ],
                    "breakdownFilter": {
                        "breakdown": "$geoip_country_code",
                        "breakdown_type": "event",
                    },
                },
            },
            team=self.team,
            created_by=self.user,
        )

        dashboard = Dashboard.objects.create(
            team=self.team,
            name="Test Dashboard",
            created_by=self.user,
            filters={
                "breakdown_filter": {
                    "breakdown": "$browser",
                    "breakdown_type": "event",
                }
            },
        )

        DashboardTile.objects.create(dashboard=dashboard, insight=insight)

        response = self.client.get(
            f"/api/projects/{self.team.id}/insights/{insight.id}/?refresh=force_blocking&from_dashboard={dashboard.id}"
        )

        self.assertEqual(response.status_code, 200)
        response_data = response.json()
        query_source = response_data["query"]["source"]

        # Verify breakdown filter is applied correctly
        breakdown_filter = query_source["breakdownFilter"]
        self.assertEqual(breakdown_filter.get("breakdown"), "$browser")
        self.assertEqual(breakdown_filter.get("breakdown_type"), "event")

        # Verify the breakdown filter is applied in the result
        self.assertIn("result", response_data)
        self.assertEqual(response_data["result"][0][0]["breakdown"], ["Chrome"])


class TestInsightErrorHandling(ClickhouseTestMixin, APIBaseTest):
    @parameterized.expand(
        [
            ("ExposedCHQueryError", "NO_COMMON_TYPE error from ClickHouse", None),
            ("ExposedHogQLError", "Invalid HogQL syntax", "hogql_error"),
            ("HogVMException", "Global variable not found: variables", None),
        ]
    )
    @patch("posthog.caching.calculate_results.calculate_for_query_based_insight")
    def test_retrieve_degrades_in_place_for_exposed_errors(
        self, _name: str, error_message: str, expected_error_code: str | None, mock_calculate: mock.MagicMock
    ) -> None:
        from posthog.hogql.errors import ExposedHogQLError

        from posthog.errors import ExposedCHQueryError

        from common.hogvm.python.utils import HogVMException

        error_classes: dict[str, type] = {
            "ExposedCHQueryError": ExposedCHQueryError,
            "ExposedHogQLError": ExposedHogQLError,
            "HogVMException": HogVMException,
        }
        mock_calculate.side_effect = error_classes[_name](error_message)

        insight = Insight.objects.create(
            team=self.team,
            query={
                "kind": "TrendsQuery",
                "series": [{"kind": "EventsNode", "event": "$pageview"}],
            },
        )

        response = self.client.get(f"/api/environments/{self.team.id}/insights/{insight.id}/?refresh=blocking")

        # The failure must ride on query_status so a dashboard tile renders its own error state
        # while the response as a whole succeeds.
        self.assertEqual(response.status_code, status.HTTP_200_OK, response.json())
        query_status = response.json()["query_status"]
        self.assertTrue(query_status["error"])
        self.assertIn(error_message, query_status["error_message"])
        self.assertEqual(query_status["error_code"], expected_error_code)

    @parameterized.expand(
        [
            ("ExposedCHQueryError", "ClickHouse trend error"),
            ("ExposedHogQLError", "HogQL trend error"),
            ("HogVMException", "Global variable not found: variables"),
        ]
    )
    @patch("products.product_analytics.backend.presentation.insight.process_query_dict")
    def test_trend_returns_400_for_exposed_errors(
        self, error_type: str, error_message: str, mock_process: mock.MagicMock
    ) -> None:
        from posthog.hogql.errors import ExposedHogQLError

        from posthog.errors import ExposedCHQueryError

        from common.hogvm.python.utils import HogVMException

        error_classes: dict[str, type] = {
            "ExposedCHQueryError": ExposedCHQueryError,
            "ExposedHogQLError": ExposedHogQLError,
            "HogVMException": HogVMException,
        }
        mock_process.side_effect = error_classes[error_type](error_message)

        response = self.client.get(
            f"/api/environments/{self.team.id}/insights/trend/",
            data={"events": json.dumps([{"id": "$pageview"}])},
        )

        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertIn(error_message, str(response.json()))

    @parameterized.expand(
        [
            ("ExposedCHQueryError", "ClickHouse funnel error"),
            ("ExposedHogQLError", "HogQL funnel error"),
            ("HogVMException", "Global variable not found: variables"),
        ]
    )
    @patch("products.product_analytics.backend.presentation.insight.process_query_dict")
    def test_funnel_returns_400_for_exposed_errors(
        self, error_type: str, error_message: str, mock_process: mock.MagicMock
    ) -> None:
        from posthog.hogql.errors import ExposedHogQLError

        from posthog.errors import ExposedCHQueryError

        from common.hogvm.python.utils import HogVMException

        error_classes: dict[str, type] = {
            "ExposedCHQueryError": ExposedCHQueryError,
            "ExposedHogQLError": ExposedHogQLError,
            "HogVMException": HogVMException,
        }
        mock_process.side_effect = error_classes[error_type](error_message)

        response = self.client.get(
            f"/api/environments/{self.team.id}/insights/funnel/",
            data={"events": json.dumps([{"id": "$pageview"}, {"id": "$pageleave"}])},
        )

        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertIn(error_message, str(response.json()))


class TestInsightBulkDelete(ClickhouseTestMixin, APIBaseTest, QueryMatchingTest):
    def _create_insight(self, name: str = "My insight") -> Insight:
        return Insight.objects.create(team=self.team, name=name, saved=True, created_by=self.user)

    def _bulk_delete(self, ids: list[int]) -> Any:
        return self.client.post(f"/api/environments/{self.team.id}/insights/bulk_delete/", {"ids": ids}, format="json")

    def _bulk_restore(self, ids: list[int]) -> Any:
        return self.client.post(f"/api/environments/{self.team.id}/insights/bulk_restore/", {"ids": ids}, format="json")

    def test_bulk_delete_soft_deletes_insights(self) -> None:
        one = self._create_insight("one")
        two = self._create_insight("two")

        response = self._bulk_delete([one.id, two.id])

        self.assertEqual(response.status_code, status.HTTP_200_OK, response.json())
        body = response.json()
        self.assertEqual({item["id"] for item in body["deleted"]}, {one.id, two.id})
        self.assertEqual(body["skipped"], [])
        self.assertTrue(Insight.objects_including_soft_deleted.get(id=one.id).deleted)
        self.assertTrue(Insight.objects_including_soft_deleted.get(id=two.id).deleted)

    def test_bulk_delete_hides_dashboard_tiles_and_removes_alerts(self) -> None:
        dashboard = Dashboard.objects.create(team=self.team, name="Dashboard")
        insight = self._create_insight()
        tile = DashboardTile.objects.create(insight=insight, dashboard=dashboard)
        alert = AlertConfiguration.objects.create(team=self.team, insight=insight, name="alert")

        response = self._bulk_delete([insight.id])

        self.assertEqual(response.status_code, status.HTTP_200_OK, response.json())
        self.assertTrue(DashboardTile.objects_including_soft_deleted.get(id=tile.id).deleted)
        self.assertFalse(AlertConfiguration.objects.filter(id=alert.id).exists())

    def test_bulk_delete_reports_unknown_ids_as_skipped(self) -> None:
        insight = self._create_insight()

        response = self._bulk_delete([insight.id, 9_999_999])

        body = response.json()
        self.assertEqual([item["id"] for item in body["deleted"]], [insight.id])
        self.assertEqual(body["skipped"], [{"id": 9_999_999, "reason": "Insight not found"}])

    def test_bulk_delete_skips_insights_without_edit_access(self) -> None:
        self.organization.available_product_features = [
            {"key": AvailableFeature.ACCESS_CONTROL, "name": AvailableFeature.ACCESS_CONTROL},
            {"key": AvailableFeature.ROLE_BASED_ACCESS, "name": AvailableFeature.ROLE_BASED_ACCESS},
        ]
        self.organization.save()
        member = self._create_user("member@posthog.com", level=OrganizationMembership.Level.MEMBER)
        editable = self._create_insight("editable")
        restricted = self._create_insight("restricted")
        AccessControl.objects.create(resource="insight", resource_id=restricted.id, team=self.team, access_level="none")

        self.client.force_login(member)
        response = self._bulk_delete([editable.id, restricted.id])

        self.assertEqual(response.status_code, status.HTTP_200_OK, response.json())
        body = response.json()
        self.assertEqual([item["id"] for item in body["deleted"]], [editable.id])
        self.assertEqual([item["id"] for item in body["skipped"]], [restricted.id])
        self.assertTrue(Insight.objects_including_soft_deleted.get(id=editable.id).deleted)
        self.assertFalse(Insight.objects_including_soft_deleted.get(id=restricted.id).deleted)

    def test_bulk_delete_rejects_empty_ids(self) -> None:
        response = self._bulk_delete([])

        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

    def test_bulk_restore_restores_insights_and_tiles(self) -> None:
        dashboard = Dashboard.objects.create(team=self.team, name="Dashboard")
        insight = self._create_insight()
        tile = DashboardTile.objects.create(insight=insight, dashboard=dashboard)

        self.assertEqual(self._bulk_delete([insight.id]).status_code, status.HTTP_200_OK)
        self.assertTrue(Insight.objects_including_soft_deleted.get(id=insight.id).deleted)
        self.assertTrue(DashboardTile.objects_including_soft_deleted.get(id=tile.id).deleted)

        response = self._bulk_restore([insight.id])

        self.assertEqual(response.status_code, status.HTTP_200_OK, response.json())
        self.assertEqual([item["id"] for item in response.json()["restored"]], [insight.id])
        self.assertFalse(Insight.objects_including_soft_deleted.get(id=insight.id).deleted)
        self.assertFalse(DashboardTile.objects_including_soft_deleted.get(id=tile.id).deleted)

    def test_bulk_restore_skips_tiles_on_dashboards_the_user_cannot_edit(self) -> None:
        dashboard = Dashboard.objects.create(team=self.team, name="Dashboard")
        insight = self._create_insight()
        tile = DashboardTile.objects.create(insight=insight, dashboard=dashboard)
        self.assertEqual(self._bulk_delete([insight.id]).status_code, status.HTTP_200_OK)

        # Simulate the requester only having view access to the dashboard the insight sits on.
        with patch(
            "posthog.user_permissions.UserDashboardPermissions.effective_privilege_level",
            new_callable=PropertyMock,
            return_value=Dashboard.PrivilegeLevel.CAN_VIEW,
        ):
            response = self._bulk_restore([insight.id])

        self.assertEqual(response.status_code, status.HTTP_200_OK, response.json())
        self.assertEqual([item["id"] for item in response.json()["restored"]], [insight.id])
        self.assertFalse(Insight.objects_including_soft_deleted.get(id=insight.id).deleted)
        # The insight comes back, but its tile on a dashboard the user can only view stays hidden.
        self.assertTrue(DashboardTile.objects_including_soft_deleted.get(id=tile.id).deleted)


class TestInsightBulkSetTestAccountFilter(ClickhouseTestMixin, APIBaseTest, QueryMatchingTest):
    def setUp(self) -> None:
        super().setUp()
        # The action is project-admin only, so the caller in the rest of these tests has to be one.
        self.organization_membership.level = OrganizationMembership.Level.ADMIN
        self.organization_membership.save()

    def _create_query_insight(self, *, name: str = "Trend", filter_test_accounts: bool | None = None) -> Insight:
        source: dict[str, Any] = {"kind": "TrendsQuery", "series": [{"kind": "EventsNode", "event": "$pageview"}]}
        if filter_test_accounts is not None:
            source["filterTestAccounts"] = filter_test_accounts
        return Insight.objects.create(
            team=self.team,
            name=name,
            saved=True,
            created_by=self.user,
            query={"kind": "InsightVizNode", "source": source},
        )

    def _reloaded_source(self, insight: Insight) -> dict[str, Any]:
        insight.refresh_from_db()
        assert insight.query is not None
        return insight.query["source"]

    def _bulk_set(self, enabled: bool) -> Any:
        return self.client.post(
            f"/api/environments/{self.team.id}/insights/bulk_set_test_account_filter/",
            {"enabled": enabled},
            format="json",
        )

    @parameterized.expand([("turn on", True), ("turn off", False)])
    def test_sets_the_filter_on_every_query_insight(self, _name: str, enabled: bool) -> None:
        needs_change = self._create_query_insight(filter_test_accounts=not enabled)
        already_set = self._create_query_insight(name="Already set", filter_test_accounts=enabled)

        response = self._bulk_set(enabled)

        self.assertEqual(response.status_code, status.HTTP_200_OK, response.json())
        self.assertEqual(response.json(), {"updated": 1, "unchanged": 1, "unsupported": 0, "skipped": 0, "legacy": 0})
        self.assertEqual(self._reloaded_source(needs_change)["filterTestAccounts"], enabled)
        self.assertEqual(self._reloaded_source(already_set)["filterTestAccounts"], enabled)

    @patch("products.product_analytics.backend.presentation.insight.INSIGHT_BULK_TEST_ACCOUNT_FILTER_BATCH_SIZE", 2)
    def test_covers_every_insight_across_several_batches(self) -> None:
        insights = [self._create_query_insight(name=f"Trend {n}", filter_test_accounts=False) for n in range(5)]

        response = self._bulk_set(True)

        # A cursor that doesn't advance reprocesses rows, one that advances too far leaves the tail untouched.
        # Both are invisible while every insight fits in a single batch, which is every other case here.
        self.assertEqual(response.json(), {"updated": 5, "unchanged": 0, "unsupported": 0, "skipped": 0, "legacy": 0})
        for insight in insights:
            self.assertTrue(self._reloaded_source(insight)["filterTestAccounts"])

    def test_treats_a_missing_filter_as_off(self) -> None:
        insight = self._create_query_insight()

        self.assertEqual(self._bulk_set(False).json()["unchanged"], 1)
        self.assertEqual(self._bulk_set(True).json()["updated"], 1)

        self.assertTrue(self._reloaded_source(insight)["filterTestAccounts"])

    def test_leaves_sql_insights_alone(self) -> None:
        sql_insight = Insight.objects.create(
            team=self.team,
            name="SQL",
            saved=True,
            query={"kind": "DataVisualizationNode", "source": {"kind": "HogQLQuery", "query": "select 1"}},
        )

        response = self._bulk_set(True)

        self.assertEqual(response.json(), {"updated": 0, "unchanged": 0, "unsupported": 1, "skipped": 0, "legacy": 0})
        self.assertNotIn("filterTestAccounts", self._reloaded_source(sql_insight))

    def test_reports_insights_that_only_have_legacy_filters_rather_than_changing_them(self) -> None:
        mine = self._create_query_insight(filter_test_accounts=False)
        legacy = Insight.objects.create(
            team=self.team, name="Legacy", saved=True, filters={"insight": "TRENDS", "events": [{"id": "$pageview"}]}
        )

        response = self._bulk_set(True)

        # `legacy: 1` rather than `unsupported: 1`: these carry the toggle and have their own remedy, so the
        # caller has to be able to tell them apart from a SQL insight that can never have one.
        self.assertEqual(response.json(), {"updated": 1, "unchanged": 0, "unsupported": 0, "skipped": 0, "legacy": 1})
        self.assertTrue(self._reloaded_source(mine)["filterTestAccounts"])
        legacy.refresh_from_db()
        self.assertNotIn("filter_test_accounts", legacy.filters)

    def test_leaves_insights_in_other_projects_alone(self) -> None:
        mine = self._create_query_insight(filter_test_accounts=False)
        _, other_team = Project.objects.create_with_team(organization=self.organization, initiating_user=self.user)
        theirs = Insight.objects.create(
            team=other_team,
            name="Theirs",
            saved=True,
            query={
                "kind": "InsightVizNode",
                "source": {
                    "kind": "TrendsQuery",
                    "series": [{"kind": "EventsNode", "event": "$pageview"}],
                    "filterTestAccounts": False,
                },
            },
        )

        response = self._bulk_set(True)

        self.assertEqual(response.json(), {"updated": 1, "unchanged": 0, "unsupported": 0, "skipped": 0, "legacy": 0})
        self.assertTrue(self._reloaded_source(mine)["filterTestAccounts"])
        self.assertFalse(self._reloaded_source(theirs)["filterTestAccounts"])

    def test_refuses_a_member_who_could_otherwise_edit_every_insight(self) -> None:
        insight = self._create_query_insight(filter_test_accounts=False)
        member = self._create_user("member@posthog.com", level=OrganizationMembership.Level.MEMBER)

        self.client.force_login(member)
        response = self._bulk_set(True)

        # The per-insight check would let this through: insights default to editor access, which is how the
        # settings UI hiding the button from non-admins ended up being the only thing stopping them.
        self.assertEqual(response.status_code, status.HTTP_403_FORBIDDEN)
        self.assertFalse(self._reloaded_source(insight)["filterTestAccounts"])

    def test_records_the_change_in_the_activity_log(self) -> None:
        insight = self._create_query_insight()

        self._bulk_set(True)

        response = self.client.get(f"/api/environments/{self.team.id}/insights/{insight.id}/activity/")
        self.assertEqual(response.status_code, status.HTTP_200_OK, response.json())
        activities = response.json()["results"]
        self.assertEqual(activities[0]["activity"], "updated")
        self.assertEqual([change["field"] for change in activities[0]["detail"]["changes"]], ["query"])

    @parameterized.expand(
        [
            ("a run that flips insights", False, {"insights_updated": 1, "insights_unchanged": 0}),
            ("a run that flips nothing", True, {"insights_updated": 0, "insights_unchanged": 1}),
        ]
    )
    @patch("products.product_analytics.backend.presentation.insight.report_user_action")
    def test_reports_the_run_for_analytics(
        self,
        _name: str,
        already_enabled: bool,
        expected_counts: dict[str, int],
        mock_report_user_action: mock.Mock,
    ) -> None:
        self._create_query_insight(filter_test_accounts=already_enabled)

        self._bulk_set(True)

        mock_report_user_action.assert_any_call(
            self.user,
            "insights bulk test account filter set",
            {
                "enabled": True,
                "insights_considered": 1,
                "insights_unsupported": 0,
                "insights_skipped": 0,
                "insights_legacy": 0,
                **expected_counts,
            },
            team=ANY,
            request=ANY,
        )
