// Upgrade Survivor Baselines tests cover upgrade survivor baselines script behavior.
import { execFileSync } from "node:child_process";
import { mkdirSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import path from "node:path";
import { describe, expect, it } from "vitest";
import { parse } from "yaml";
import { parseArgs, resolveBaselines } from "../../scripts/resolve-upgrade-survivor-baselines.mts";

function withReleaseFixture<T>(releases: unknown[], fn: (file: string) => T): T {
  const dir = mkdtempSync(path.join(tmpdir(), "openclaw-upgrade-baselines-"));
  try {
    const file = path.join(dir, "releases.json");
    writeFileSync(file, `${JSON.stringify(releases)}\n`);
    return fn(file);
  } finally {
    rmSync(dir, { force: true, recursive: true });
  }
}

function withJsonFixture<T>(name: string, contents: unknown, fn: (file: string) => T): T {
  const dir = mkdtempSync(path.join(tmpdir(), "openclaw-upgrade-baselines-"));
  try {
    const file = path.join(dir, name);
    writeFileSync(file, `${JSON.stringify(contents)}\n`);
    return fn(file);
  } finally {
    rmSync(dir, { force: true, recursive: true });
  }
}

describe("scripts/resolve-upgrade-survivor-baselines", () => {
  it("rejects short flag values before resolving baselines", () => {
    expect(() => parseArgs(["--fallback", "-h"])).toThrow("missing value for --fallback");
    expect(() => parseArgs(["--github-output", "-h"])).toThrow("missing value for --github-output");
  });

  it("keeps the single fallback baseline when no expanded request is provided", () => {
    expect(resolveBaselines(new Map([["fallback", "2026.4.23"]]))).toEqual(["openclaw@2026.4.23"]);
  });

  it.each(["package", "update-migration", "historical"])(
    "pins the %s workflow baseline once before Docker fanout",
    (entrypoint) => {
      const workflow = parse(readFileSync(".github/workflows/package-acceptance.yml", "utf8")) as {
        on: {
          workflow_call: {
            inputs: Record<
              "published_upgrade_survivor_baseline" | "published_upgrade_survivor_baselines",
              { default: string }
            >;
          };
        };
        jobs: { resolve_package: { steps: Array<{ id?: string; run?: string }> } };
      };
      const migration = parse(readFileSync(".github/workflows/update-migration.yml", "utf8")) as {
        on: { workflow_dispatch: { inputs: { baselines: { default: string } } } };
      };
      const inputs = workflow.on.workflow_call.inputs;
      const step = workflow.jobs.resolve_package.steps.find(
        (entry) => entry.id === "upgrade_survivor_baselines",
      );
      const run = step?.run;
      if (!run) {
        throw new Error("Missing baseline preparation step");
      }
      const requested =
        entrypoint === "update-migration"
          ? migration.on.workflow_dispatch.inputs.baselines.default
          : entrypoint === "historical"
            ? "2026.4.23"
            : inputs.published_upgrade_survivor_baselines.default;

      withJsonFixture("output", {}, (output) => {
        const root = path.dirname(output);
        const bin = path.join(root, "bin");
        const calls = path.join(root, "npm-calls");
        mkdirSync(bin);
        writeFileSync(output, "");
        writeFileSync(
          path.join(bin, "npm"),
          `#!/usr/bin/env node
const fs = require("node:fs");
const file = process.env.FIXTURE_NPM_CALLS;
const first = !fs.existsSync(file);
fs.appendFileSync(file, JSON.stringify(process.argv.slice(2)) + "\\n");
console.log(first ? "2026.7.1-2" : "2026.8.1");
`,
          { mode: 0o755 },
        );
        writeFileSync(path.join(bin, "gh"), "#!/bin/sh\nexit 75\n", { mode: 0o755 });
        execFileSync("bash", ["-c", run], {
          encoding: "utf8",
          env: {
            ...process.env,
            PATH: `${bin}${path.delimiter}${process.env.PATH ?? ""}`,
            FALLBACK_BASELINE: inputs.published_upgrade_survivor_baseline.default,
            REQUESTED_BASELINES: requested,
            GITHUB_OUTPUT: output,
            FIXTURE_NPM_CALLS: calls,
          },
        });
        expect(readFileSync(output, "utf8")).toBe(
          `baselines=openclaw@${entrypoint === "historical" ? "2026.4.23" : "2026.7.1-2"}\nbaseline=openclaw@2026.7.1-2\n`,
        );
        expect(
          readFileSync(calls, "utf8")
            .trim()
            .split("\n")
            .map((line) => JSON.parse(line)),
        ).toEqual([["view", "openclaw@latest", "version", "--prefer-online"]]);
      });
    },
  );

  it("resolves release-history to last six stable releases plus explicit legacy anchors", () => {
    const releases = (
      [
        ["v2026.4.29", "2026-04-30T00:00:00Z"],
        ["v2026.4.27", "2026-04-28T00:00:00Z"],
        ["v2026.4.26", "2026-04-27T00:00:00Z"],
        ["v2026.4.25", "2026-04-26T00:00:00Z"],
        ["v2026.4.24", "2026-04-25T00:00:00Z"],
        ["v2026.4.22", "2026-04-23T00:00:00Z"],
        ["v2026.4.23", "2026-04-22T00:00:00Z"],
        ["v2026.3.13-1", "2026-03-14T18:04:00Z"],
        ["v2026.3.12", "2026-03-12T00:00:00Z"],
        ["v2026.4.30-beta.1", "2026-05-01T00:00:00Z", true],
      ] as const
    ).map(([tagName, publishedAt, isPrerelease = false]) => ({
      isPrerelease,
      publishedAt,
      tagName,
    }));

    withReleaseFixture(releases, (file) => {
      expect(
        resolveBaselines(
          new Map([
            ["requested", "release-history 2026.4.29"],
            ["releases-json", file],
            ["history-count", "6"],
            ["include-version", "2026.4.23"],
            ["pre-date", "2026-03-15T00:00:00Z"],
          ]),
        ),
      ).toEqual([
        "openclaw@2026.4.29",
        "openclaw@2026.4.27",
        "openclaw@2026.4.26",
        "openclaw@2026.4.25",
        "openclaw@2026.4.24",
        "openclaw@2026.4.22",
        "openclaw@2026.4.23",
        "openclaw@2026.3.13-1",
      ]);
    });
  });

  it("resolves all-since baselines to every stable published release at or after the requested version", () => {
    const releases = (
      [
        ["v2026.5.2", "2026-05-03T00:00:00Z"],
        ["v2026.4.30", "2026-05-01T00:00:00Z"],
        ["v2026.4.29", "2026-04-30T00:00:00Z"],
        ["v2026.4.23", "2026-04-23T00:00:00Z"],
        ["v2026.4.22", "2026-04-22T00:00:00Z"],
        ["v2026.4.31-beta.1", "2026-05-02T00:00:00Z", true],
      ] as const
    ).map(([tagName, publishedAt, isPrerelease = false]) => ({
      isPrerelease,
      publishedAt,
      tagName,
    }));

    withReleaseFixture(releases, (releasesFile) => {
      withJsonFixture(
        "versions.json",
        ["2026.5.2", "2026.4.30", "2026.4.29", "2026.4.23", "2026.4.22"],
        (versionsFile) => {
          expect(
            resolveBaselines(
              new Map([
                ["requested", "all-since-2026.4.23"],
                ["releases-json", releasesFile],
                ["npm-versions-json", versionsFile],
              ]),
            ),
          ).toEqual([
            "openclaw@2026.5.2",
            "openclaw@2026.4.30",
            "openclaw@2026.4.29",
            "openclaw@2026.4.23",
          ]);
        },
      );
    });
  });

  it("resolves last-stable baselines to the latest stable published package versions", () => {
    const releases = (
      [
        ["v2026.5.4-beta.1", "2026-05-05T00:00:00Z", true],
        ["v2026.5.3-1", "2026-05-04T00:00:00Z"],
        ["v2026.5.3", "2026-05-03T00:00:00Z"],
        ["v2026.5.2", "2026-05-02T00:00:00Z"],
        ["v2026.4.29", "2026-04-30T00:00:00Z"],
        ["v2026.4.27", "2026-04-28T00:00:00Z"],
        ["v2026.4.15", "2026-04-16T00:00:00Z"],
      ] as const
    ).map(([tagName, publishedAt, isPrerelease = false]) => ({
      isPrerelease,
      publishedAt,
      tagName,
    }));

    withReleaseFixture(releases, (releasesFile) => {
      withJsonFixture(
        "versions.json",
        ["2026.5.3-1", "2026.5.3", "2026.5.2", "2026.4.29", "2026.4.27", "2026.4.15"],
        (versionsFile) => {
          expect(
            resolveBaselines(
              new Map([
                ["requested", "last-stable-4 2026.4.23 2026.5.2 2026.4.15"],
                ["releases-json", releasesFile],
                ["npm-versions-json", versionsFile],
              ]),
            ),
          ).toEqual([
            "openclaw@2026.5.3-1",
            "openclaw@2026.5.3",
            "openclaw@2026.5.2",
            "openclaw@2026.4.29",
            "openclaw@2026.4.23",
            "openclaw@2026.4.15",
          ]);
        },
      );
    });
  });

  it("rejects loose release-history count values", () => {
    withReleaseFixture([], (file) => {
      expect(() =>
        resolveBaselines(
          new Map([
            ["requested", "release-history"],
            ["releases-json", file],
            ["history-count", "1e3"],
          ]),
        ),
      ).toThrow("--history-count must be a positive integer");
    });
  });

  it("rejects loose last-stable count tokens", () => {
    withReleaseFixture([], (file) => {
      expect(() =>
        resolveBaselines(
          new Map([
            ["requested", "last-stable-1e3"],
            ["releases-json", file],
          ]),
        ),
      ).toThrow("last-stable baseline count must be a positive integer");
    });
  });

  it("rejects unsafe all-since version tokens", () => {
    withReleaseFixture([], (file) => {
      expect(() =>
        resolveBaselines(
          new Map([
            ["requested", "all-since-2026.4.9007199254740993"],
            ["releases-json", file],
          ]),
        ),
      ).toThrow("invalid all-since baseline token: all-since-2026.4.9007199254740993");
    });
  });

  it("ignores unsafe stable release tags from release history", () => {
    const releases = [
      {
        isPrerelease: false,
        publishedAt: "2026-05-01T00:00:00Z",
        tagName: "v2026.4.9007199254740993",
      },
      { isPrerelease: false, publishedAt: "2026-04-30T00:00:00Z", tagName: "v2026.4.29" },
    ];

    withReleaseFixture(releases, (file) => {
      expect(
        resolveBaselines(
          new Map([
            ["requested", "release-history"],
            ["releases-json", file],
            ["history-count", "2"],
          ]),
        ),
      ).toEqual(["openclaw@2026.4.29"]);
    });
  });

  it("maps release-history anchors to npm-published package versions when GitHub tags have republish suffixes", () => {
    const releases = (
      [
        ["v2026.4.29", "2026-04-30T00:00:00Z"],
        ["v2026.4.27", "2026-04-28T00:00:00Z"],
        ["v2026.4.26", "2026-04-27T00:00:00Z"],
        ["v2026.4.25", "2026-04-26T00:00:00Z"],
        ["v2026.4.24", "2026-04-25T00:00:00Z"],
        ["v2026.4.23", "2026-04-22T00:00:00Z"],
        ["v2026.3.13-1", "2026-03-14T18:04:00Z"],
      ] as const
    ).map(([tagName, publishedAt]) => ({
      isPrerelease: false,
      publishedAt,
      tagName,
    }));

    withReleaseFixture(releases, (releasesFile) => {
      withJsonFixture(
        "versions.json",
        ["2026.4.29", "2026.4.27", "2026.4.26", "2026.4.25", "2026.4.24", "2026.4.23", "2026.3.13"],
        (versionsFile) => {
          expect(
            resolveBaselines(
              new Map([
                ["requested", "release-history"],
                ["releases-json", releasesFile],
                ["npm-versions-json", versionsFile],
                ["history-count", "6"],
                ["include-version", "2026.4.23"],
                ["pre-date", "2026-03-15T00:00:00Z"],
              ]),
            ),
          ).toEqual([
            "openclaw@2026.4.29",
            "openclaw@2026.4.27",
            "openclaw@2026.4.26",
            "openclaw@2026.4.25",
            "openclaw@2026.4.24",
            "openclaw@2026.4.23",
            "openclaw@2026.3.13",
          ]);
        },
      );
    });
  });
});
