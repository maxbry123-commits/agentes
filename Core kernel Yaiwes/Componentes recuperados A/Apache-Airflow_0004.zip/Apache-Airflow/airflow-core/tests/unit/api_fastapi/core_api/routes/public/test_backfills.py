# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.
from __future__ import annotations

import os
import sqlite3
from datetime import datetime, timedelta
from unittest import mock

import pendulum
import pytest
from fastapi.testclient import TestClient
from sqlalchemy import and_, func, select
from sqlalchemy.exc import OperationalError, ProgrammingError

from airflow._shared.timezones import timezone
from airflow.api_fastapi.auth.managers.simple.user import SimpleAuthManagerUser
from airflow.dag_processing.dagbag import DagBag
from airflow.models import DagModel, DagRun, TaskInstance
from airflow.models.backfill import (
    Backfill,
    BackfillDagRun,
    NoBackfillRunsToCreate,
    ReprocessBehavior,
    _create_backfill,
)
from airflow.models.dag import DAG
from airflow.models.dagbundle import DagBundleModel
from airflow.providers.standard.operators.empty import EmptyOperator
from airflow.providers.standard.operators.python import PythonOperator
from airflow.sdk import CronPartitionTimetable
from airflow.utils.session import provide_session
from airflow.utils.state import DagRunState
from airflow.utils.types import DagRunType

from tests_common.test_utils.asserts import assert_queries_count
from tests_common.test_utils.db import (
    clear_db_backfills,
    clear_db_dag_bundles,
    clear_db_dags,
    clear_db_logs,
    clear_db_runs,
    clear_db_serialized_dags,
)
from tests_common.test_utils.logs import check_last_log

pytestmark = [pytest.mark.db_test, pytest.mark.need_serialized_dag]


DAG_ID = "test_dag"
TASK_ID = "op1"
DAG2_ID = "test_dag2"
DAG3_ID = "test_dag3"


def _clean_db():
    clear_db_backfills()
    clear_db_runs()
    clear_db_dags()
    clear_db_dag_bundles()
    clear_db_serialized_dags()
    clear_db_logs()


@pytest.fixture(autouse=True)
def clean_db():
    yield
    _clean_db()


@pytest.fixture
def dag_reader_test_client(test_client):
    """A caller who may read the Dags but not write them: viewer is below the role edits require."""
    auth_manager = test_client.app.state.auth_manager
    token = auth_manager._get_token_signer().generate(
        auth_manager.serialize_user(SimpleAuthManagerUser(username="reader", role="viewer"))
    )
    with mock.patch("airflow.models.revoked_token.RevokedToken.is_revoked", return_value=False):
        yield TestClient(
            test_client.app,
            headers={"Authorization": f"Bearer {token}"},
            base_url=str(test_client.base_url),
        )


def make_dags():
    with DAG(
        DAG_ID,
        schedule=None,
        start_date=datetime(2020, 6, 15),
        doc_md="details",
        params={"foo": 1},
        tags=["example"],
    ) as dag:
        EmptyOperator(task_id=TASK_ID)

    with DAG(DAG2_ID, schedule=None, start_date=datetime(2020, 6, 15)) as dag2:  # no doc_md
        EmptyOperator(task_id=TASK_ID)

    with DAG(DAG3_ID, schedule=None) as dag3:  # DAG start_date set to None
        EmptyOperator(task_id=TASK_ID, start_date=datetime(2019, 6, 12))

    dag_bag = DagBag(os.devnull)
    dag_bag.dags = {dag.dag_id: dag, dag2.dag_id: dag2, dag3.dag_id: dag3}


def to_iso(val):
    return pendulum.instance(val).to_iso8601_string()


class TestBackfillEndpoint:
    @provide_session
    def _create_dag_models(self, *, count=1, dag_id_prefix="TEST_DAG", is_paused=False, session=None):
        bundle_name = "dags-folder"
        orm_dag_bundle = DagBundleModel(name=bundle_name)
        session.add(orm_dag_bundle)
        session.flush()

        dags = []
        for num in range(1, count + 1):
            dag_model = DagModel(
                dag_id=f"{dag_id_prefix}_{num}",
                bundle_name=bundle_name,
                fileloc=f"/tmp/dag_{num}.py",
                is_stale=False,
                timetable_summary="0 0 * * *",
                is_paused=is_paused,
            )
            session.add(dag_model)
            dags.append(dag_model)
        return dags


class TestListBackfills(TestBackfillEndpoint):
    def test_list_backfill(self, test_client, session):
        (dag,) = self._create_dag_models()
        from_date = timezone.utcnow()
        to_date = timezone.utcnow()
        b = Backfill(dag_id=dag.dag_id, from_date=from_date, to_date=to_date)
        session.add(b)
        session.commit()

        with assert_queries_count(3):
            response = test_client.get(f"/backfills?dag_id={dag.dag_id}")

        assert response.status_code == 200
        assert response.json() == {
            "backfills": [
                {
                    "completed_at": mock.ANY,
                    "created_at": mock.ANY,
                    "dag_display_name": "TEST_DAG_1",
                    "dag_id": "TEST_DAG_1",
                    "dag_run_conf": {},
                    "from_date": to_iso(from_date),
                    "id": b.id,
                    "is_paused": False,
                    "reprocess_behavior": "none",
                    "max_active_runs": 10,
                    "to_date": to_iso(to_date),
                    "updated_at": mock.ANY,
                }
            ],
            "total_entries": 1,
        }


class TestGetBackfill(TestBackfillEndpoint):
    def test_get_backfill(self, session, test_client):
        (dag,) = self._create_dag_models()
        from_date = timezone.utcnow()
        to_date = timezone.utcnow()
        backfill = Backfill(dag_id=dag.dag_id, from_date=from_date, to_date=to_date)
        session.add(backfill)
        session.commit()
        response = test_client.get(f"/backfills/{backfill.id}")
        assert response.status_code == 200
        assert response.json() == {
            "completed_at": mock.ANY,
            "created_at": mock.ANY,
            "dag_display_name": "TEST_DAG_1",
            "dag_id": "TEST_DAG_1",
            "dag_run_conf": {},
            "from_date": to_iso(from_date),
            "id": backfill.id,
            "is_paused": False,
            "reprocess_behavior": "none",
            "max_active_runs": 10,
            "to_date": to_iso(to_date),
            "updated_at": mock.ANY,
        }

    def test_get_backfill_with_null_conf(self, session, test_client):
        """dag_run_conf can be NULL in the DB; the API should still serialize it."""
        (dag,) = self._create_dag_models()
        from_date = timezone.utcnow()
        to_date = timezone.utcnow()
        backfill = Backfill(dag_id=dag.dag_id, from_date=from_date, to_date=to_date, dag_run_conf=None)
        session.add(backfill)
        session.commit()
        response = test_client.get(f"/backfills/{backfill.id}")
        assert response.status_code == 200
        assert response.json()["dag_run_conf"] is None

    def test_no_exist(self, session, test_client):
        response = test_client.get(f"/backfills/{231984098}")
        assert response.status_code == 404
        assert response.json().get("detail") == "Backfill not found"

    def test_unknown_backfill_is_indistinguishable_from_an_unreadable_one(
        self, session, unauthorized_test_client
    ):
        """Telling the two apart discloses which backfill ids exist across Dags."""
        (dag,) = self._create_dag_models()
        backfill = Backfill(dag_id=dag.dag_id, from_date=timezone.utcnow(), to_date=timezone.utcnow())
        session.add(backfill)
        session.commit()

        existing = unauthorized_test_client.get(f"/backfills/{backfill.id}")
        unknown = unauthorized_test_client.get(f"/backfills/{231984098}")

        assert existing.status_code == 404
        assert (existing.status_code, existing.json()) == (unknown.status_code, unknown.json())

    def test_invalid_id(self, test_client):
        response = test_client.get("/backfills/invalid_id")
        assert response.status_code == 422
        response_detail = response.json()["detail"][0]
        assert response_detail["input"] == "invalid_id"
        assert response_detail["loc"] == ["path", "backfill_id"]
        assert (
            response_detail["msg"] == "Input should be a valid integer, unable to parse string as an integer"
        )


class TestListBackfillDagRuns(TestBackfillEndpoint):
    def test_list_backfill_dag_runs(self, test_client, session):
        """Happy path: backfill with mixed dag run states."""
        (dag,) = self._create_dag_models()
        from_date = pendulum.parse("2024-01-01")
        to_date = pendulum.parse("2024-01-03")
        b = Backfill(dag_id=dag.dag_id, from_date=from_date, to_date=to_date)
        session.add(b)
        session.flush()

        dr1 = DagRun(
            dag_id=dag.dag_id,
            run_id="backfill__2024-01-01",
            logical_date=pendulum.parse("2024-01-01"),
            state=DagRunState.SUCCESS,
            run_type="scheduled",
        )
        dr2 = DagRun(
            dag_id=dag.dag_id,
            run_id="backfill__2024-01-02",
            logical_date=pendulum.parse("2024-01-02"),
            state=DagRunState.FAILED,
            run_type="scheduled",
        )
        session.add_all([dr1, dr2])
        session.flush()

        bdr1 = BackfillDagRun(
            backfill_id=b.id, dag_run_id=dr1.id, logical_date=pendulum.parse("2024-01-01"), sort_ordinal=1
        )
        bdr2 = BackfillDagRun(
            backfill_id=b.id, dag_run_id=dr2.id, logical_date=pendulum.parse("2024-01-02"), sort_ordinal=2
        )
        session.add_all([bdr1, bdr2])
        session.commit()

        with assert_queries_count(5):
            response = test_client.get(f"/backfills/{b.id}/dag_runs")
        assert response.status_code == 200
        data = response.json()
        assert data["total_entries"] == 2
        runs = data["backfill_dag_runs"]
        assert len(runs) == 2
        assert runs[0]["sort_ordinal"] == 1
        assert runs[0]["dag_id"] == dag.dag_id
        assert runs[0]["dag_run_id"] == "backfill__2024-01-01"
        assert runs[0]["dag_run_state"] == "success"
        assert runs[1]["sort_ordinal"] == 2
        assert runs[1]["dag_id"] == dag.dag_id
        assert runs[1]["dag_run_id"] == "backfill__2024-01-02"
        assert runs[1]["dag_run_state"] == "failed"

    def test_list_backfill_dag_runs_with_skipped_slots(self, test_client, session):
        """Slots skipped due to existing runs have null dag_run_id and exception_reason set."""
        (dag,) = self._create_dag_models()
        b = Backfill(
            dag_id=dag.dag_id, from_date=pendulum.parse("2024-01-01"), to_date=pendulum.parse("2024-01-02")
        )
        session.add(b)
        session.flush()

        bdr = BackfillDagRun(
            backfill_id=b.id,
            dag_run_id=None,
            logical_date=pendulum.parse("2024-01-01"),
            sort_ordinal=1,
            exception_reason="already exists",
        )
        session.add(bdr)
        session.commit()

        response = test_client.get(f"/backfills/{b.id}/dag_runs")
        assert response.status_code == 200
        data = response.json()
        assert data["total_entries"] == 1
        run = data["backfill_dag_runs"][0]
        assert run["dag_id"] == dag.dag_id
        assert run["dag_run_id"] is None
        assert run["dag_run_state"] is None
        assert run["exception_reason"] == "already exists"

    def test_list_backfill_dag_runs_not_found(self, test_client):
        """Non-existent backfill returns 404."""
        response = test_client.get("/backfills/999999/dag_runs")
        assert response.status_code == 404
        assert response.json().get("detail") == "Backfill not found"

    def test_list_backfill_dag_runs_pagination(self, test_client, session):
        """Limit and offset work correctly."""
        (dag,) = self._create_dag_models()
        b = Backfill(
            dag_id=dag.dag_id, from_date=pendulum.parse("2024-01-01"), to_date=pendulum.parse("2024-01-05")
        )
        session.add(b)
        session.flush()

        for i in range(1, 4):
            session.add(
                BackfillDagRun(
                    backfill_id=b.id,
                    dag_run_id=None,
                    logical_date=pendulum.parse(f"2024-01-0{i}"),
                    sort_ordinal=i,
                    exception_reason="already exists",
                )
            )
        session.commit()

        response = test_client.get(f"/backfills/{b.id}/dag_runs", params={"limit": 2, "offset": 0})
        assert response.status_code == 200
        data = response.json()
        assert data["total_entries"] == 3
        assert len(data["backfill_dag_runs"]) == 2

        response = test_client.get(f"/backfills/{b.id}/dag_runs", params={"limit": 2, "offset": 2})
        assert response.status_code == 200
        data = response.json()
        assert len(data["backfill_dag_runs"]) == 1

    def test_list_backfill_dag_runs_empty(self, test_client, session):
        """Backfill with no dag runs returns empty list."""
        (dag,) = self._create_dag_models()
        b = Backfill(
            dag_id=dag.dag_id, from_date=pendulum.parse("2024-01-01"), to_date=pendulum.parse("2024-01-02")
        )
        session.add(b)
        session.commit()

        response = test_client.get(f"/backfills/{b.id}/dag_runs")
        assert response.status_code == 200
        data = response.json()
        assert data["total_entries"] == 0
        assert data["backfill_dag_runs"] == []

    @pytest.mark.parametrize(
        ("order_by", "expected_first_ordinal"),
        [
            ("sort_ordinal", 1),
            ("-sort_ordinal", 3),
            ("id", 1),
        ],
    )
    def test_list_backfill_dag_runs_ordering(self, order_by, expected_first_ordinal, test_client, session):
        """Verify sort contract for allowed order_by values."""
        (dag,) = self._create_dag_models()
        b = Backfill(
            dag_id=dag.dag_id, from_date=pendulum.parse("2024-01-01"), to_date=pendulum.parse("2024-01-03")
        )
        session.add(b)
        session.flush()

        for i in range(1, 4):
            session.add(
                BackfillDagRun(
                    backfill_id=b.id,
                    dag_run_id=None,
                    logical_date=pendulum.parse(f"2024-01-0{i}"),
                    sort_ordinal=i,
                    exception_reason="already exists",
                )
            )
        session.commit()

        response = test_client.get(f"/backfills/{b.id}/dag_runs", params={"order_by": order_by})
        assert response.status_code == 200
        data = response.json()
        assert data["backfill_dag_runs"][0]["sort_ordinal"] == expected_first_ordinal


class TestCreateBackfill(TestBackfillEndpoint):
    @pytest.mark.parametrize(
        ("repro_act", "repro_exp"),
        [
            (None, ReprocessBehavior.NONE),
            ("none", ReprocessBehavior.NONE),
            ("failed", ReprocessBehavior.FAILED),
            ("completed", ReprocessBehavior.COMPLETED),
        ],
    )
    def test_create_backfill(self, repro_act, repro_exp, session, dag_maker, test_client):
        with dag_maker(session=session, dag_id="TEST_DAG_1", schedule="0 * * * *") as dag:
            EmptyOperator(task_id="mytask")
        session.scalars(select(DagModel)).all()
        session.commit()
        from_date = pendulum.parse("2024-01-01")
        from_date_iso = to_iso(from_date)
        to_date = pendulum.parse("2024-02-01")
        to_date_iso = to_iso(to_date)
        max_active_runs = 5
        data = {
            "dag_id": dag.dag_id,
            "from_date": f"{from_date_iso}",
            "to_date": f"{to_date_iso}",
            "max_active_runs": max_active_runs,
            "run_backwards": False,
            "dag_run_conf": {"param1": "val1", "param2": True},
        }
        if repro_act is not None:
            data["reprocess_behavior"] = repro_act
        response = test_client.post(
            url="/backfills",
            json=data,
        )
        assert response.status_code == 200
        assert response.json() == {
            "completed_at": mock.ANY,
            "created_at": mock.ANY,
            "dag_display_name": "TEST_DAG_1",
            "dag_id": "TEST_DAG_1",
            "dag_run_conf": {"param1": "val1", "param2": True},
            "from_date": from_date_iso,
            "id": mock.ANY,
            "is_paused": False,
            "reprocess_behavior": repro_exp,
            "max_active_runs": 5,
            "to_date": to_date_iso,
            "updated_at": mock.ANY,
        }
        check_last_log(session, dag_id="TEST_DAG_1", event="create_backfill", logical_date=None)

    @mock.patch(
        "airflow.api_fastapi.auth.managers.simple.user.SimpleAuthManagerUser.get_display_name",
        return_value="Jane Doe",
    )
    def test_create_backfill_records_triggering_user_display_name(
        self, mock_display_name, session, dag_maker, test_client
    ):
        with dag_maker(session=session, dag_id="TEST_DAG_DISPLAY_NAME", schedule="0 * * * *") as dag:
            EmptyOperator(task_id="mytask")
        session.commit()
        data = {
            "dag_id": dag.dag_id,
            "from_date": to_iso(pendulum.parse("2024-01-01")),
            "to_date": to_iso(pendulum.parse("2024-02-01")),
            "max_active_runs": 5,
            "run_backwards": False,
            "dag_run_conf": {},
        }
        response = test_client.post(url="/backfills", json=data)
        assert response.status_code == 200
        backfill = session.scalars(select(Backfill).where(Backfill.dag_id == dag.dag_id)).one()
        assert backfill.triggering_user_name == "Jane Doe"

    def test_dag_not_exist(self, session, test_client):
        session.scalars(select(DagModel)).all()
        session.commit()
        from_date = pendulum.parse("2024-01-01")
        from_date_iso = to_iso(from_date)
        to_date = pendulum.parse("2024-02-01")
        to_date_iso = to_iso(to_date)
        max_active_runs = 5
        data = {
            "dag_id": "DAG_NOT_EXIST",
            "from_date": f"{from_date_iso}",
            "to_date": f"{to_date_iso}",
            "max_active_runs": max_active_runs,
            "run_backwards": False,
            "dag_run_conf": {"param1": "val1", "param2": True},
            "reprocess_behavior": ReprocessBehavior.NONE,
        }
        response = test_client.post(
            url="/backfills",
            json=data,
        )
        assert response.status_code == 404
        assert response.json().get("detail") == "Could not find dag DAG_NOT_EXIST"

    def test_no_schedule_dag(self, session, dag_maker, test_client):
        with dag_maker(session=session, dag_id="TEST_DAG_1", schedule=None) as dag:
            EmptyOperator(task_id="mytask")
        session.scalars(select(DagModel)).all()
        session.commit()
        from_date = pendulum.parse("2024-01-01")
        from_date_iso = to_iso(from_date)
        to_date = pendulum.parse("2024-02-01")
        to_date_iso = to_iso(to_date)
        max_active_runs = 5
        data = {
            "dag_id": dag.dag_id,
            "from_date": f"{from_date_iso}",
            "to_date": f"{to_date_iso}",
            "max_active_runs": max_active_runs,
            "run_backwards": False,
            "dag_run_conf": {"param1": "val1", "param2": True},
            "reprocess_behavior": ReprocessBehavior.NONE,
        }
        response = test_client.post(
            url="/backfills",
            json=data,
        )
        assert response.status_code == 422
        assert "has a non-periodic schedule that does not support backfills" in response.json().get("detail")

    @pytest.mark.parametrize(
        ("repro_act", "repro_exp", "run_backwards", "status_code"),
        [
            ("none", ReprocessBehavior.NONE, False, 422),
            ("completed", ReprocessBehavior.COMPLETED, False, 200),
            ("completed", ReprocessBehavior.COMPLETED, True, 422),
        ],
    )
    def test_create_backfill_with_depends_on_past(
        self, repro_act, repro_exp, run_backwards, status_code, session, dag_maker, test_client
    ):
        with dag_maker(session=session, dag_id="TEST_DAG_1", schedule="0 * * * *") as dag:
            EmptyOperator(task_id="mytask", depends_on_past=True)
        session.scalars(select(DagModel)).all()
        session.commit()
        from_date = pendulum.parse("2024-01-01")
        from_date_iso = to_iso(from_date)
        to_date = pendulum.parse("2024-02-01")
        to_date_iso = to_iso(to_date)
        max_active_runs = 5
        data = {
            "dag_id": dag.dag_id,
            "from_date": f"{from_date_iso}",
            "to_date": f"{to_date_iso}",
            "max_active_runs": max_active_runs,
            "run_backwards": run_backwards,
            "dag_run_conf": {"param1": "val1", "param2": True},
            "reprocess_behavior": repro_act,
        }
        response = test_client.post(
            url="/backfills",
            json=data,
        )
        assert response.status_code == status_code

        if response.status_code != 200:
            if run_backwards:
                assert (
                    response.json().get("detail")
                    == "Backfill cannot be run in reverse when the Dag has tasks where depends_on_past=True."
                )
            else:
                assert (
                    response.json().get("detail")
                    == "Dag has tasks for which depends_on_past=True. You must set reprocess behavior to reprocess completed or reprocess failed."
                )

    def test_create_backfill_database_locked(self, session, dag_maker, test_client):
        """SQLite 'database is locked' during backfill creation returns HTTP 503."""
        with dag_maker(session=session, dag_id="TEST_DAG_1", schedule="0 * * * *") as dag:
            EmptyOperator(task_id="mytask")
        session.scalars(select(DagModel)).all()
        session.commit()

        from_date = pendulum.parse("2024-01-01")
        to_date = pendulum.parse("2024-02-01")

        data = {
            "dag_id": dag.dag_id,
            "from_date": to_iso(from_date),
            "to_date": to_iso(to_date),
            "max_active_runs": 5,
            "run_backwards": False,
            "dag_run_conf": {},
        }

        with mock.patch(
            "airflow.api_fastapi.core_api.routes.public.backfills._create_backfill",
            side_effect=OperationalError(
                "statement", "params", sqlite3.OperationalError("database is locked")
            ),
        ):
            response = test_client.post("/backfills", json=data)

        # OperationalError with "database is locked" should return 503
        assert response.status_code == 503
        assert "database is locked" in response.json()["detail"].lower()

    def test_create_backfill_cleans_up_orphan_on_lock_error(self, session, dag_maker):
        """The partial Backfill row is removed when the cleanup runs after a lock error."""
        from airflow.models.backfill import Backfill, _cleanup_partial_backfill

        with dag_maker(session=session, dag_id="TEST_DAG_CLEANUP", schedule="0 * * * *") as dag:
            EmptyOperator(task_id="mytask")
        session.commit()

        bf = Backfill(
            dag_id=dag.dag_id,
            from_date=pendulum.parse("2024-01-01"),
            to_date=pendulum.parse("2024-02-01"),
            max_active_runs=5,
            dag_run_conf={},
            reprocess_behavior="none",
            dag_model=dag,
            triggering_user_name="test",
        )
        session.add(bf)
        session.commit()
        bf_id = bf.id

        assert session.scalar(select(func.count()).select_from(Backfill).where(Backfill.id == bf_id)) == 1

        _cleanup_partial_backfill(bf, session)

        assert session.scalar(select(func.count()).select_from(Backfill).where(Backfill.id == bf_id)) == 0

    def test_create_backfill_cleans_up_after_failed_transaction(self, session, dag_maker):
        """The cleanup works when the session is in a deactivated state.

        Mirrors the real flow inside ``_create_backfill`` after an
        ``OperationalError``: SQLAlchemy deactivates the session until
        an explicit ``rollback()``. The cleanup must call it before any
        further operation; without that, ``session.execute()`` raises
        ``InvalidRequestError`` and the cleanup is a silent no-op.
        """
        from sqlalchemy import text

        from airflow.models.backfill import Backfill, _cleanup_partial_backfill

        with dag_maker(session=session, dag_id="TEST_DAG_CLEANUP_DEACT", schedule="0 * * * *") as dag:
            EmptyOperator(task_id="mytask")
        session.commit()

        bf = Backfill(
            dag_id=dag.dag_id,
            from_date=pendulum.parse("2024-01-01"),
            to_date=pendulum.parse("2024-02-01"),
            max_active_runs=5,
            dag_run_conf={},
            reprocess_behavior="none",
            dag_model=dag,
            triggering_user_name="test",
        )
        session.add(bf)
        session.commit()
        bf_id = bf.id

        # Force the session into a deactivated state (same shape as after
        # a failed flush). SQLite raises OperationalError; Postgres/MySQL raise ProgrammingError.
        with pytest.raises((OperationalError, ProgrammingError)):
            session.execute(text("INVALID SQL STATEMENT"))

        _cleanup_partial_backfill(bf, session)

        assert session.scalar(select(func.count()).select_from(Backfill).where(Backfill.id == bf_id)) == 0

    def test_create_backfill_cleanup_removes_partial_dag_runs(self, session, dag_maker):
        """Cleanup removes partial DagRuns, TIs, and BackfillDagRun rows alongside the Backfill."""
        from airflow.models.backfill import _cleanup_partial_backfill

        with dag_maker(session=session, dag_id="TEST_DAG_CLEANUP_DR", schedule="0 * * * *") as dag:
            EmptyOperator(task_id="mytask")
        session.commit()

        bf = Backfill(
            dag_id=dag.dag_id,
            from_date=pendulum.parse("2024-01-01"),
            to_date=pendulum.parse("2024-02-01"),
            max_active_runs=5,
            dag_run_conf={},
            reprocess_behavior="none",
            dag_model=dag,
            triggering_user_name="test",
        )
        session.add(bf)
        session.commit()

        dr1 = dag_maker.create_dagrun(
            logical_date=pendulum.parse("2024-01-01"),
            run_type=DagRunType.BACKFILL_JOB,
            backfill_id=bf.id,
            state=DagRunState.QUEUED,
        )
        session.add(
            BackfillDagRun(
                backfill_id=bf.id,
                dag_run_id=dr1.id,
                logical_date=pendulum.parse("2024-01-01"),
                sort_ordinal=1,
            )
        )

        dr2 = dag_maker.create_dagrun(
            logical_date=pendulum.parse("2024-01-02"),
            run_type=DagRunType.BACKFILL_JOB,
            backfill_id=bf.id,
            state=DagRunState.QUEUED,
        )
        session.add(
            BackfillDagRun(
                backfill_id=bf.id,
                dag_run_id=dr2.id,
                logical_date=pendulum.parse("2024-01-02"),
                sort_ordinal=2,
            )
        )
        session.commit()

        bf_id = bf.id
        dr1_id = dr1.id
        dr2_id = dr2.id
        run_ids = [dr1.run_id, dr2.run_id]

        assert session.scalar(select(func.count()).select_from(Backfill).where(Backfill.id == bf_id)) == 1
        assert session.scalar(select(func.count()).select_from(DagRun).where(DagRun.id == dr1_id)) == 1
        assert session.scalar(select(func.count()).select_from(DagRun).where(DagRun.id == dr2_id)) == 1
        assert (
            session.scalar(
                select(func.count()).select_from(BackfillDagRun).where(BackfillDagRun.backfill_id == bf_id)
            )
            == 2
        )
        assert (
            session.scalar(
                select(func.count()).select_from(TaskInstance).where(TaskInstance.run_id.in_(run_ids))
            )
            >= 2
        )

        _cleanup_partial_backfill(bf, session)

        assert session.scalar(select(func.count()).select_from(Backfill).where(Backfill.id == bf_id)) == 0
        assert session.scalar(select(func.count()).select_from(DagRun).where(DagRun.id == dr1_id)) == 0
        assert session.scalar(select(func.count()).select_from(DagRun).where(DagRun.id == dr2_id)) == 0
        assert (
            session.scalar(
                select(func.count()).select_from(BackfillDagRun).where(BackfillDagRun.backfill_id == bf_id)
            )
            == 0
        )
        assert (
            session.scalar(
                select(func.count()).select_from(TaskInstance).where(TaskInstance.run_id.in_(run_ids))
            )
            == 0
        )

    @pytest.mark.parametrize(
        "run_backwards",
        [
            (False),
            (True),
        ],
    )
    def test_create_backfill_future_dates(self, session, dag_maker, test_client, run_backwards):
        with dag_maker(session=session, dag_id="TEST_DAG_1", schedule="0 * * * *") as dag:
            EmptyOperator(task_id="mytask")
        session.scalars(select(DagModel)).all()
        session.commit()
        from_date = timezone.utcnow() + timedelta(days=1)
        to_date = timezone.utcnow() + timedelta(days=1)
        max_active_runs = 5
        data = {
            "dag_id": dag.dag_id,
            "from_date": f"{to_iso(from_date)}",
            "to_date": f"{to_iso(to_date)}",
            "max_active_runs": max_active_runs,
            "run_backwards": run_backwards,
            "dag_run_conf": {"param1": "val1", "param2": True},
        }

        response = test_client.post(
            url="/backfills",
            json=data,
        )
        assert response.status_code == 422
        assert response.json().get("detail") == "Backfill cannot be executed for future dates."

    @pytest.mark.parametrize(
        "run_backwards",
        [
            (False),
            (True),
        ],
    )
    def test_create_backfill_past_future_dates(self, session, dag_maker, test_client, run_backwards):
        with dag_maker(session=session, dag_id="TEST_DAG_1", schedule="@daily") as dag:
            EmptyOperator(task_id="mytask")
        session.scalars(select(DagModel)).all()
        session.commit()
        from_date = timezone.utcnow() - timedelta(days=2)
        to_date = timezone.utcnow() + timedelta(days=1)
        max_active_runs = 1
        data = {
            "dag_id": dag.dag_id,
            "from_date": f"{to_iso(from_date)}",
            "to_date": f"{to_iso(to_date)}",
            "max_active_runs": max_active_runs,
            "run_backwards": run_backwards,
            "dag_run_conf": {"param1": "val1", "param2": True},
        }

        response = test_client.post(
            url="/backfills",
            json=data,
        )
        assert response.status_code == 200
        backfill_dag_run_count = select(func.count()).where(
            and_(BackfillDagRun.backfill_id == response.json()["id"], BackfillDagRun.logical_date == to_date)
        )
        count = session.execute(backfill_dag_run_count).scalar()
        assert count == 0

    # todo: AIP-83 amendment must fix
    @pytest.mark.parametrize(
        ("reprocess_behavior", "expected_dates"),
        [
            (
                "none",
                [
                    "2024-01-01T00:00:00+00:00",
                    "2024-01-04T00:00:00+00:00",
                    "2024-01-05T00:00:00+00:00",
                ],
            ),
            (
                "failed",
                [
                    "2024-01-01T00:00:00+00:00",
                    "2024-01-03T00:00:00+00:00",
                    "2024-01-04T00:00:00+00:00",
                    "2024-01-05T00:00:00+00:00",
                ],
            ),
            (
                "completed",
                [
                    "2024-01-01T00:00:00+00:00",
                    "2024-01-02T00:00:00+00:00",
                    "2024-01-03T00:00:00+00:00",
                    "2024-01-04T00:00:00+00:00",
                    "2024-01-05T00:00:00+00:00",
                ],
            ),
        ],
    )
    def test_create_backfill_with_existing_runs(
        self,
        session,
        dag_maker,
        test_client,
        reprocess_behavior,
        expected_dates,
    ):
        """
        Verify behavior when there's existing runs in the range

        If the there is a run in the range, depending on the reprocess behavior,
        it should clear the existing dag run and update it to be associated with the backfill.
        """
        with dag_maker(
            session=session,
            dag_id="TEST_DAG_2",
            schedule="0 0 * * *",
            start_date=pendulum.parse("2024-01-01"),
        ) as dag:
            EmptyOperator(task_id="mytask")

        session.commit()

        existing_dagruns = [
            {"logical_date": pendulum.parse("2024-01-02"), "state": DagRunState.SUCCESS},  # Completed dag run
            {"logical_date": pendulum.parse("2024-01-03"), "state": DagRunState.FAILED},  # Failed dag run
        ]
        for dagrun in existing_dagruns:
            session.add(
                DagRun(
                    dag_id=dag.dag_id,
                    run_id=f"manual__{dagrun['logical_date'].isoformat()}",
                    logical_date=dagrun["logical_date"],
                    state=dagrun["state"],
                    run_type="scheduled",
                )
            )
        session.commit()

        from_date = pendulum.parse("2024-01-01")
        from_date_iso = to_iso(from_date)
        to_date = pendulum.parse("2024-01-05")
        to_date_iso = to_iso(to_date)

        data = {
            "dag_id": dag.dag_id,
            "from_date": from_date_iso,
            "to_date": to_date_iso,
            "max_active_runs": 5,
            "run_backwards": False,
            "dag_run_conf": {"param1": "val1", "param2": True},
            "reprocess_behavior": reprocess_behavior,
        }

        response = test_client.post(
            url="/backfills",
            json=data,
        )

        assert response.status_code == 200
        response_json = response.json()
        assert response_json["from_date"] == "2024-01-01T00:00:00Z"
        assert response_json["to_date"] == "2024-01-05T00:00:00Z"
        backfill_id = response_json["id"]

        result = session.scalars(select(DagRun).where(DagRun.dag_id == dag.dag_id))
        dag_runs = sorted(((x.logical_date.isoformat(), x.backfill_id) for x in result), key=lambda x: x[0])

        all_dates = [
            "2024-01-01T00:00:00+00:00",
            "2024-01-02T00:00:00+00:00",
            "2024-01-03T00:00:00+00:00",
            "2024-01-04T00:00:00+00:00",
            "2024-01-05T00:00:00+00:00",
        ]

        # verify which runs are associated with the backfill now
        expected = []
        for date in all_dates:
            if date in expected_dates:
                expected.append((date, backfill_id))
            else:
                expected.append((date, None))
        assert dag_runs == expected

        # verify which logical dates have a non-create exception
        result = session.scalars(select(BackfillDagRun).where(BackfillDagRun.backfill_id == backfill_id))
        actual = sorted((x.logical_date.isoformat(), x.exception_reason) for x in result)
        expected = []
        for date in all_dates:
            if date in expected_dates:
                expected.append((date, None))
            else:
                expected.append((date, "already exists"))
        assert actual == expected

        # verify all dag runs associated with the backfill have backfill run type
        actual = list(session.scalars(select(DagRun.run_type).where(DagRun.backfill_id == backfill_id)))
        assert actual == ["backfill"] * len(expected_dates)

    def test_should_respond_400_if_backfill_runs_denied(self, session, dag_maker, test_client):
        with dag_maker(session=session, dag_id="TEST_DAG_1", schedule="0 * * * *") as dag:
            EmptyOperator(task_id="mytask")
        session.scalars(select(DagModel)).all()
        session.commit()
        dag_model = session.scalar(select(DagModel).where(DagModel.dag_id == dag.dag_id))
        dag_model.allowed_run_types = ["scheduled", "manual"]
        session.commit()
        from_date = pendulum.parse("2024-01-01")
        from_date_iso = to_iso(from_date)
        to_date = pendulum.parse("2024-02-01")
        to_date_iso = to_iso(to_date)
        max_active_runs = 5
        data = {
            "dag_id": dag.dag_id,
            "from_date": f"{from_date_iso}",
            "to_date": f"{to_date_iso}",
            "max_active_runs": max_active_runs,
            "run_backwards": False,
            "dag_run_conf": {"param1": "val1", "param2": True},
        }
        response = test_client.post(
            url="/backfills",
            json=data,
        )
        assert response.status_code == 400
        assert response.json()["detail"] == f"Dag with dag_id: '{dag.dag_id}' does not allow backfill runs"

    def test_should_respond_401(self, unauthenticated_test_client, dag_maker, session):
        with dag_maker(session=session, dag_id="TEST_DAG_1", schedule="0 * * * *") as dag:
            EmptyOperator(task_id="mytask")
        session.scalars(select(DagModel)).all()
        session.commit()
        from_date = pendulum.parse("2024-01-01")
        from_date_iso = to_iso(from_date)
        to_date = pendulum.parse("2024-02-01")
        to_date_iso = to_iso(to_date)
        max_active_runs = 5
        data = {
            "dag_id": dag.dag_id,
            "from_date": f"{from_date_iso}",
            "to_date": f"{to_date_iso}",
            "max_active_runs": max_active_runs,
            "run_backwards": False,
            "dag_run_conf": {"param1": "val1", "param2": True},
        }
        response = unauthenticated_test_client.post("/backfills", json=data)
        assert response.status_code == 401

    def test_should_respond_403(self, unauthorized_test_client, dag_maker, session):
        with dag_maker(session=session, dag_id="TEST_DAG_1", schedule="0 * * * *") as dag:
            EmptyOperator(task_id="mytask")
        session.scalars(select(DagModel)).all()
        session.commit()
        from_date = pendulum.parse("2024-01-01")
        from_date_iso = to_iso(from_date)
        to_date = pendulum.parse("2024-02-01")
        to_date_iso = to_iso(to_date)
        max_active_runs = 5
        data = {
            "dag_id": dag.dag_id,
            "from_date": f"{from_date_iso}",
            "to_date": f"{to_date_iso}",
            "max_active_runs": max_active_runs,
            "run_backwards": False,
            "dag_run_conf": {"param1": "val1", "param2": True},
        }
        response = unauthorized_test_client.post("/backfills", json=data)
        assert response.status_code == 403


class TestCreateBackfillDryRun(TestBackfillEndpoint):
    def test_create_backfill_dry_run_database_locked(self, session, dag_maker, test_client):
        """SQLite 'database is locked' during backfill dry-run returns HTTP 503."""
        with dag_maker(session=session, dag_id="TEST_DAG_DRY_LOCK", schedule="0 * * * *") as dag:
            EmptyOperator(task_id="mytask")
        session.commit()

        data = {
            "dag_id": dag.dag_id,
            "from_date": to_iso(pendulum.parse("2024-01-01")),
            "to_date": to_iso(pendulum.parse("2024-02-01")),
            "max_active_runs": 5,
            "run_backwards": False,
            "dag_run_conf": {},
        }

        with mock.patch(
            "airflow.api_fastapi.core_api.routes.public.backfills._do_dry_run",
            side_effect=OperationalError(
                "statement", "params", sqlite3.OperationalError("database is locked")
            ),
        ):
            response = test_client.post("/backfills/dry_run", json=data)

        assert response.status_code == 503
        assert "database is locked" in response.json()["detail"].lower()

    @pytest.mark.parametrize(
        ("reprocess_behavior", "expected_dates"),
        [
            (
                "none",
                [
                    {
                        "logical_date": "2024-01-01T00:00:00Z",
                        "partition_date": None,
                        "partition_key": None,
                    },
                    {
                        "logical_date": "2024-01-04T00:00:00Z",
                        "partition_date": None,
                        "partition_key": None,
                    },
                    {
                        "logical_date": "2024-01-05T00:00:00Z",
                        "partition_date": None,
                        "partition_key": None,
                    },
                ],
            ),
            (
                "failed",
                [
                    {
                        "logical_date": "2024-01-01T00:00:00Z",
                        "partition_date": None,
                        "partition_key": None,
                    },
                    {
                        "logical_date": "2024-01-03T00:00:00Z",
                        "partition_date": None,
                        "partition_key": None,
                    },  # Reprocess failed
                    {
                        "logical_date": "2024-01-04T00:00:00Z",
                        "partition_date": None,
                        "partition_key": None,
                    },
                    {
                        "logical_date": "2024-01-05T00:00:00Z",
                        "partition_date": None,
                        "partition_key": None,
                    },
                ],
            ),
            (
                "completed",
                [
                    {
                        "logical_date": "2024-01-01T00:00:00Z",
                        "partition_date": None,
                        "partition_key": None,
                    },
                    {
                        "logical_date": "2024-01-02T00:00:00Z",
                        "partition_date": None,
                        "partition_key": None,
                    },  # Reprocess all
                    {
                        "logical_date": "2024-01-03T00:00:00Z",
                        "partition_date": None,
                        "partition_key": None,
                    },
                    {
                        "logical_date": "2024-01-04T00:00:00Z",
                        "partition_date": None,
                        "partition_key": None,
                    },
                    {
                        "logical_date": "2024-01-05T00:00:00Z",
                        "partition_date": None,
                        "partition_key": None,
                    },
                ],
            ),
        ],
    )
    def test_create_backfill_dry_run(
        self, session, dag_maker, test_client, reprocess_behavior, expected_dates
    ):
        with dag_maker(
            session=session,
            dag_id="TEST_DAG_2",
            schedule="0 0 * * *",
            start_date=pendulum.parse("2024-01-01"),
        ) as dag:
            EmptyOperator(task_id="mytask")

        session.commit()

        existing_dagruns = [
            {"logical_date": pendulum.parse("2024-01-02"), "state": DagRunState.SUCCESS},  # Completed dag run
            {"logical_date": pendulum.parse("2024-01-03"), "state": DagRunState.FAILED},  # Failed dag run
        ]
        for dagrun in existing_dagruns:
            session.add(
                DagRun(
                    dag_id=dag.dag_id,
                    run_id=f"manual__{dagrun['logical_date'].isoformat()}",
                    logical_date=dagrun["logical_date"],
                    state=dagrun["state"],
                    run_type="scheduled",
                )
            )
        session.commit()

        from_date = pendulum.parse("2024-01-01")
        from_date_iso = to_iso(from_date)
        to_date = pendulum.parse("2024-01-05")
        to_date_iso = to_iso(to_date)

        data = {
            "dag_id": dag.dag_id,
            "from_date": from_date_iso,
            "to_date": to_date_iso,
            "max_active_runs": 5,
            "run_backwards": False,
            "dag_run_conf": {"param1": "val1", "param2": True},
            "reprocess_behavior": reprocess_behavior,
        }

        response = test_client.post(
            url="/backfills/dry_run",
            json=data,
        )

        assert response.status_code == 200
        response_json = response.json()
        assert response_json["backfills"] == expected_dates

    def test_create_backfill_dry_run_rejects_invalid_conf(self, session, dag_maker, test_client):
        from airflow.sdk import Param

        with dag_maker(
            session=session,
            dag_id="TEST_DAG_2",
            schedule="0 0 * * *",
            start_date=pendulum.parse("2024-01-01"),
            params={"validated_number": Param(1, type="integer", minimum=1, maximum=10)},
        ) as dag:
            EmptyOperator(task_id="mytask")

        session.commit()

        from_date = pendulum.parse("2024-01-01")
        to_date = pendulum.parse("2024-01-05")

        response = test_client.post(
            url="/backfills/dry_run",
            json={
                "dag_id": dag.dag_id,
                "from_date": to_iso(from_date),
                "to_date": to_iso(to_date),
                "max_active_runs": 5,
                "run_backwards": False,
                "dag_run_conf": {"validated_number": 99},
                "reprocess_behavior": "none",
            },
        )

        assert response.status_code == 422
        assert "Invalid input for param validated_number" in response.json().get("detail")

    @pytest.mark.parametrize(
        ("repro_act", "repro_exp", "run_backwards", "status_code"),
        [
            ("none", ReprocessBehavior.NONE, False, 422),
            ("completed", ReprocessBehavior.COMPLETED, False, 200),
            ("completed", ReprocessBehavior.COMPLETED, True, 422),
        ],
    )
    def test_create_backfill_dry_run_with_depends_on_past(
        self, repro_act, repro_exp, run_backwards, status_code, session, dag_maker, test_client
    ):
        with dag_maker(session=session, dag_id="TEST_DAG_1", schedule="0 * * * *") as dag:
            EmptyOperator(task_id="mytask", depends_on_past=True)
        session.scalars(select(DagModel)).all()
        session.commit()
        from_date = pendulum.parse("2024-01-01")
        from_date_iso = to_iso(from_date)
        to_date = pendulum.parse("2024-02-01")
        to_date_iso = to_iso(to_date)
        max_active_runs = 5
        data = {
            "dag_id": dag.dag_id,
            "from_date": f"{from_date_iso}",
            "to_date": f"{to_date_iso}",
            "max_active_runs": max_active_runs,
            "run_backwards": run_backwards,
            "dag_run_conf": {"param1": "val1", "param2": True},
            "reprocess_behavior": repro_act,
        }
        response = test_client.post(
            url="/backfills/dry_run",
            json=data,
        )
        assert response.status_code == status_code

        if response.status_code != 200:
            if run_backwards:
                assert (
                    response.json().get("detail")
                    == "Backfill cannot be run in reverse when the Dag has tasks where depends_on_past=True."
                )
            else:
                assert (
                    response.json().get("detail")
                    == "Dag has tasks for which depends_on_past=True. You must set reprocess behavior to reprocess completed or reprocess failed."
                )


class TestCreateBackfillPartitioned(TestBackfillEndpoint):
    """Tests for partition-date selector paths on POST /backfills and POST /backfills/dry_run."""

    @pytest.mark.parametrize(
        ("url", "extra_assertions"),
        [
            ("/backfills", "create"),
            ("/backfills/dry_run", "dry_run"),
        ],
    )
    def test_partitioned_dag_with_from_to_dates(self, session, dag_maker, test_client, url, extra_assertions):
        """Partitioned Dag + from_date/to_date succeeds on both routes (auto-detected)."""
        with dag_maker(
            session=session,
            dag_id="TEST_PARTITIONED_DAG",
            schedule=CronPartitionTimetable("0 0 * * *", timezone="Asia/Taipei"),
        ):
            EmptyOperator(task_id="mytask")
        session.commit()

        data = {
            "dag_id": "TEST_PARTITIONED_DAG",
            "from_date": "2026-02-18T00:00:00+00:00",
            "to_date": "2026-02-20T00:00:00+00:00",
            "max_active_runs": 5,
            "run_backwards": False,
        }
        response = test_client.post(url=url, json=data)
        assert response.status_code == 200
        if extra_assertions == "create":
            assert response.json() == {
                "completed_at": mock.ANY,
                "created_at": mock.ANY,
                "dag_display_name": "TEST_PARTITIONED_DAG",
                "dag_id": "TEST_PARTITIONED_DAG",
                "dag_run_conf": None,
                "from_date": "2026-02-18T00:00:00Z",
                "id": mock.ANY,
                "is_paused": False,
                "reprocess_behavior": "none",
                "max_active_runs": 5,
                "to_date": "2026-02-20T00:00:00Z",
                "updated_at": mock.ANY,
            }
        elif extra_assertions == "dry_run":
            resp_json = response.json()
            assert resp_json["total_entries"] >= 1
            first = resp_json["backfills"][0]
            assert "partition_key" in first
            assert "partition_date" in first

    @pytest.mark.parametrize(
        "url",
        [
            "/backfills",
            "/backfills/dry_run",
        ],
    )
    def test_missing_from_to_date_returns_422(self, session, dag_maker, test_client, url):
        """Missing required from_date/to_date fields → 422 from schema validation."""
        with dag_maker(session=session, dag_id="TEST_DAG_1", schedule="0 0 * * *"):
            EmptyOperator(task_id="mytask")
        session.commit()

        data = {
            "dag_id": "TEST_DAG_1",
            "max_active_runs": 5,
            "run_backwards": False,
        }
        response = test_client.post(url=url, json=data)
        assert response.status_code == 422

    @pytest.mark.parametrize(
        "url",
        [
            "/backfills",
            "/backfills/dry_run",
        ],
    )
    def test_partitioned_dag_at_cap_single_day_returns_200(self, session, dag_maker, test_client, url):
        """Partitioned Dag: from_date == to_date (same day) is allowed → 200 (auto-detected)."""
        with dag_maker(
            session=session,
            dag_id="TEST_PARTITIONED_DAG",
            schedule=CronPartitionTimetable("0 0 * * *", timezone="Asia/Taipei"),
        ):
            EmptyOperator(task_id="mytask")
        session.commit()

        data = {
            "dag_id": "TEST_PARTITIONED_DAG",
            "from_date": "2026-02-18T00:00:00+00:00",
            "to_date": "2026-02-18T00:00:00+00:00",
            "max_active_runs": 5,
            "run_backwards": False,
        }
        response = test_client.post(url=url, json=data)
        assert response.status_code == 200

    @pytest.mark.parametrize(
        "url",
        [
            "/backfills",
            "/backfills/dry_run",
        ],
    )
    def test_partitioned_dag_from_date_after_to_date_returns_422(self, session, dag_maker, test_client, url):
        """Partitioned Dag + from_date > to_date → 422 (InvalidBackfillDateRange)."""
        with dag_maker(
            session=session,
            dag_id="TEST_PARTITIONED_DAG",
            schedule=CronPartitionTimetable("0 0 * * *", timezone="Asia/Taipei"),
        ):
            EmptyOperator(task_id="mytask")
        session.commit()

        data = {
            "dag_id": "TEST_PARTITIONED_DAG",
            "from_date": "2026-05-13T00:00:00+00:00",
            "to_date": "2026-05-12T00:00:00+00:00",
            "max_active_runs": 5,
            "run_backwards": False,
        }
        response = test_client.post(url=url, json=data)
        assert response.status_code == 422

    @mock.patch("airflow.api_fastapi.core_api.routes.public.backfills._create_backfill", autospec=True)
    def test_empty_window_create_returns_422(self, mock_create, session, dag_maker, test_client):
        """POST /backfills with an empty window raises NoBackfillRunsToCreate → 422."""
        mock_create.side_effect = NoBackfillRunsToCreate(
            "No runs to create for Dag TEST_PARTITIONED_DAG in the range [...]"
        )
        with dag_maker(
            session=session,
            dag_id="TEST_PARTITIONED_DAG",
            schedule=CronPartitionTimetable("0 0 * * *", timezone="Asia/Taipei"),
        ):
            EmptyOperator(task_id="mytask")
        session.commit()

        data = {
            "dag_id": "TEST_PARTITIONED_DAG",
            "from_date": "2026-02-18T00:00:00+00:00",
            "to_date": "2026-02-18T00:00:00+00:00",
            "max_active_runs": 5,
            "run_backwards": False,
        }
        response = test_client.post(url="/backfills", json=data)
        assert response.status_code == 422

    @mock.patch("airflow.api_fastapi.core_api.routes.public.backfills._do_dry_run", autospec=True)
    def test_empty_window_dry_run_returns_200_with_zero_entries(
        self, mock_dry_run, session, dag_maker, test_client
    ):
        """POST /backfills/dry_run with an empty window returns 200 with total_entries == 0."""
        mock_dry_run.return_value = iter([])
        with dag_maker(
            session=session,
            dag_id="TEST_PARTITIONED_DAG",
            schedule=CronPartitionTimetable("0 0 * * *", timezone="Asia/Taipei"),
        ):
            EmptyOperator(task_id="mytask")
        session.commit()

        data = {
            "dag_id": "TEST_PARTITIONED_DAG",
            "from_date": "2026-02-18T00:00:00+00:00",
            "to_date": "2026-02-18T00:00:00+00:00",
            "max_active_runs": 5,
            "run_backwards": False,
        }
        response = test_client.post(url="/backfills/dry_run", json=data)
        assert response.status_code == 200
        assert response.json()["total_entries"] == 0
        assert response.json()["backfills"] == []


class TestCancelBackfill(TestBackfillEndpoint):
    def test_cancel_backfill(self, session, test_client):
        (dag,) = self._create_dag_models()
        from_date = timezone.utcnow()
        to_date = timezone.utcnow()
        backfill = Backfill(dag_id=dag.dag_id, from_date=from_date, to_date=to_date)
        session.add(backfill)
        session.commit()
        response = test_client.put(
            f"/backfills/{backfill.id}/cancel",
        )
        assert response.status_code == 200
        assert response.json() == {
            "completed_at": mock.ANY,
            "created_at": mock.ANY,
            "dag_display_name": "TEST_DAG_1",
            "dag_id": "TEST_DAG_1",
            "dag_run_conf": {},
            "from_date": to_iso(from_date),
            "id": backfill.id,
            "is_paused": True,
            "reprocess_behavior": "none",
            "max_active_runs": 10,
            "to_date": to_iso(to_date),
            "updated_at": mock.ANY,
        }
        assert pendulum.parse(response.json()["completed_at"])
        # now it is marked as completed
        assert pendulum.parse(response.json()["completed_at"])

        # get conflict when canceling already-canceled backfill
        response = test_client.put(f"/backfills/{backfill.id}/cancel")
        assert response.status_code == 409
        check_last_log(session, dag_id=None, event="cancel_backfill", logical_date=None)

    def test_cancel_backfill_end_states(self, dag_maker, session, test_client):
        """
        Queued runs should be marked *failed*.
        Every other dag run should be left alone.
        """
        with dag_maker(schedule="@daily") as dag:
            PythonOperator(task_id="hi", python_callable=print)
        b = _create_backfill(
            dag_id=dag.dag_id,
            from_date=timezone.datetime(2021, 1, 1),
            to_date=timezone.datetime(2021, 1, 5),
            max_active_runs=2,
            reverse=False,
            dag_run_conf={},
            triggering_user_name="test_user",
        )
        query = (
            select(DagRun)
            .join(BackfillDagRun.dag_run)
            .where(BackfillDagRun.backfill_id == b.id)
            .order_by(BackfillDagRun.sort_ordinal)
        )
        dag_runs = session.scalars(query).all()
        dates = [str(x.logical_date.date()) for x in dag_runs]
        expected_dates = ["2021-01-01", "2021-01-02", "2021-01-03", "2021-01-04", "2021-01-05"]
        assert dates == expected_dates
        assert all(x.state == DagRunState.QUEUED for x in dag_runs)
        dag_runs[0].state = "running"
        session.commit()
        response = test_client.put(f"/backfills/{b.id}/cancel")
        assert response.status_code == 200
        session.expunge_all()
        dag_runs = session.scalars(query).all()
        states = [x.state for x in dag_runs]
        assert states == ["running", "failed", "failed", "failed", "failed"]

    def test_cancel_backfill_not_found(self, test_client):
        response = test_client.put("/backfills/999999/cancel")
        assert response.status_code == 404
        assert response.json().get("detail") == "Backfill not found"

    def test_invalid_id(self, test_client):
        response = test_client.put("/backfills/invalid_id/cancel")
        assert response.status_code == 422
        response_detail = response.json()["detail"][0]
        assert response_detail["input"] == "invalid_id"
        assert response_detail["loc"] == ["path", "backfill_id"]
        assert (
            response_detail["msg"] == "Input should be a valid integer, unable to parse string as an integer"
        )


class TestPauseBackfill(TestBackfillEndpoint):
    def test_pause_backfill(self, session, test_client):
        (dag,) = self._create_dag_models()
        from_date = timezone.utcnow()
        to_date = timezone.utcnow()
        backfill = Backfill(dag_id=dag.dag_id, from_date=from_date, to_date=to_date)
        session.add(backfill)
        session.commit()
        response = test_client.put(f"/backfills/{backfill.id}/pause")
        assert response.status_code == 200
        assert response.json() == {
            "completed_at": mock.ANY,
            "created_at": mock.ANY,
            "dag_display_name": "TEST_DAG_1",
            "dag_id": "TEST_DAG_1",
            "dag_run_conf": {},
            "from_date": to_iso(from_date),
            "id": backfill.id,
            "is_paused": True,
            "reprocess_behavior": "none",
            "max_active_runs": 10,
            "to_date": to_iso(to_date),
            "updated_at": mock.ANY,
        }
        check_last_log(session, dag_id=None, event="pause_backfill", logical_date=None)

    def test_pause_backfill_401(self, session, unauthenticated_test_client):
        (dag,) = self._create_dag_models()
        from_date = timezone.utcnow()
        to_date = timezone.utcnow()
        backfill = Backfill(dag_id=dag.dag_id, from_date=from_date, to_date=to_date)
        session.add(backfill)
        session.commit()
        response = unauthenticated_test_client.put(f"/backfills/{backfill.id}/pause")
        assert response.status_code == 401

    def test_pause_backfill_404_when_the_dag_is_unreadable(self, session, unauthorized_test_client):
        (dag,) = self._create_dag_models()
        from_date = timezone.utcnow()
        to_date = timezone.utcnow()
        backfill = Backfill(dag_id=dag.dag_id, from_date=from_date, to_date=to_date)
        session.add(backfill)
        session.commit()
        response = unauthorized_test_client.put(f"/backfills/{backfill.id}/pause")
        assert response.status_code == 404

    def test_pause_backfill_403(self, session, dag_reader_test_client):
        (dag,) = self._create_dag_models()
        from_date = timezone.utcnow()
        to_date = timezone.utcnow()
        backfill = Backfill(dag_id=dag.dag_id, from_date=from_date, to_date=to_date)
        session.add(backfill)
        session.commit()
        response = dag_reader_test_client.put(f"/backfills/{backfill.id}/pause")
        assert response.status_code == 403

    def test_pause_backfill_unknown_id_is_not_authorized_by_a_body_dag_id(
        self, session, dag_reader_test_client
    ):
        (dag,) = self._create_dag_models()
        session.commit()
        response = dag_reader_test_client.put(f"/backfills/{231984098}/pause", json={"dag_id": dag.dag_id})
        assert response.status_code == 404
        assert response.json().get("detail") == "Backfill not found"

    def test_invalid_id(self, test_client):
        response = test_client.put("/backfills/invalid_id/pause")
        assert response.status_code == 422
        response_detail = response.json()["detail"][0]
        assert response_detail["input"] == "invalid_id"
        assert response_detail["loc"] == ["path", "backfill_id"]
        assert (
            response_detail["msg"] == "Input should be a valid integer, unable to parse string as an integer"
        )


class TestUnpauseBackfill(TestBackfillEndpoint):
    def test_unpause_backfill(self, session, test_client):
        (dag,) = self._create_dag_models()
        from_date = timezone.utcnow()
        to_date = timezone.utcnow()
        backfill = Backfill(dag_id=dag.dag_id, from_date=from_date, to_date=to_date)
        session.add(backfill)
        session.commit()

        test_client.put(f"/backfills/{backfill.id}/pause")
        response = test_client.put(f"/backfills/{backfill.id}/unpause")
        assert response.status_code == 200
        assert response.json() == {
            "completed_at": mock.ANY,
            "created_at": mock.ANY,
            "dag_display_name": "TEST_DAG_1",
            "dag_id": "TEST_DAG_1",
            "dag_run_conf": {},
            "from_date": to_iso(from_date),
            "id": backfill.id,
            "is_paused": False,
            "reprocess_behavior": "none",
            "max_active_runs": 10,
            "to_date": to_iso(to_date),
            "updated_at": mock.ANY,
        }
        check_last_log(session, dag_id=None, event="unpause_backfill", logical_date=None)

    def test_unpause_backfill_not_found(self, test_client):
        response = test_client.put("/backfills/999999/unpause")
        assert response.status_code == 404
        assert response.json().get("detail") == "Backfill not found"

    def test_invalid_id(self, test_client):
        response = test_client.put("/backfills/invalid_id/unpause")
        assert response.status_code == 422
        response_detail = response.json()["detail"][0]
        assert response_detail["input"] == "invalid_id"
        assert response_detail["loc"] == ["path", "backfill_id"]
        assert (
            response_detail["msg"] == "Input should be a valid integer, unable to parse string as an integer"
        )
