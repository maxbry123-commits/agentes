import { errorMessage } from "@muse/shared";
/**
 * Situational-briefing daemon — wires `runDueSituationalBriefing`
 * (P8-b2) into apps/api as a `setInterval` rider, the parallel of
 * `objectives-tick.ts` for the briefing loop. Without it the
 * synthesised situational picture exists only as a library the
 * user's running server never drives.
 *
 * Deterministic + zero-LLM (the composer is pure; delivery is the
 * messaging registry). Off unless started. Cadence `intervalMs`
 * (default 30 min — a briefing is coarser than the per-item
 * ticks), clamped to [5s, 6h]; single-flight; fail-soft; unref.
 * `imminent` defaults to `[]` so the daemon briefs delegated-
 * objective status; calendar-derived imminent is a later
 * enhancement injected here.
 */

import { type BriefingImminent } from "@muse/proactivity";
import type { MessagingRouteResolution } from "@muse/autoconfigure";
import { runDueSituationalBriefing, type EmailProvider, type WeatherProvider } from "@muse/domain-tools";
import type { MessagingProviderRegistry } from "@muse/messaging";

import { admitAutomationRoute } from "./automation-route-admission.js";
import { isQuietHour, resolveQuietHoursOption, type QuietHoursOption } from "./reminder-tick.js";
import type {
  BriefingRuntimeDecision,
  BriefingRuntimeStatusStore
} from "./briefing-runtime-status.js";

export interface SituationalBriefingTickOptions {
  readonly objectivesFile: string;
  readonly registry: MessagingProviderRegistry;
  /** Canonical route resolver, invoked once immediately before delivery. */
  readonly resolveRoute: () => unknown;
  /** Captured effective local-only posture for bounded fallback receipts. */
  readonly localOnly: boolean;
  readonly sidecarFile: string;
  readonly imminent?: readonly BriefingImminent[];
  /**
   * Per-tick imminent source (imminence is time-relative). When
   * set it overrides the static `imminent`; a thrown provider
   * fails soft to no imminent items (the objective-status briefing
   * still goes out).
   */
  readonly imminentProvider?: (now: Date) => Promise<readonly BriefingImminent[]>;
  /**
   * Optional weather grounding: when both are set, a non-empty briefing
   * gains a current-weather line for `weatherLocation`. Fail-soft.
   */
  readonly weatherProvider?: WeatherProvider;
  readonly weatherLocation?: string;
  /** Optional inbox grounding: a non-empty briefing gains an unread digest. */
  readonly emailProvider?: EmailProvider;
  /** Optional predicate flagging an unread sender as a known contact, so the inbox line surfaces people-you-know first. */
  readonly inboxKnownSender?: (from: string) => boolean;
  /** Optional knowledge enricher: a non-empty briefing gains a related-note line for the top imminent item. */
  readonly relatedKnowledge?: (query: string) => Promise<string | undefined> | string | undefined;
  /** Optional home-alert resolver: a non-empty briefing gains a line flagging noteworthy home states (door unlocked). */
  readonly homeAlert?: () => Promise<string | undefined> | string | undefined;
  /** Optional upcoming-birthdays resolver: a non-empty briefing gains a "Sarah today; Bob in 3 days" line. */
  readonly birthdayLine?: () => Promise<string | undefined> | string | undefined;
  /** Optional due-tasks resolver: a non-empty briefing gains a "Buy milk (overdue); Pay rent (today)" line. */
  readonly tasksDueLine?: () => Promise<string | undefined> | string | undefined;
  /** Optional "shape of the day" resolver: a non-empty briefing gains a "free after 16:00" line. */
  readonly availabilityLine?: () => Promise<string | undefined> | string | undefined;
  readonly windowMs?: number;
  readonly intervalMs?: number;
  readonly logger?: (message: string) => void;
  readonly errorLogger?: (message: string) => void;
  readonly quietHours?: QuietHoursOption;
  readonly now?: () => Date;
  readonly runtimeStatus?: BriefingRuntimeStatusStore;
}

const DEFAULT_INTERVAL_MS = 30 * 60_000;
const MIN_INTERVAL_MS = 5_000;
const MAX_INTERVAL_MS = 6 * 60 * 60_000;

export interface SituationalBriefingTickHandle {
  readonly stop: () => void;
  readonly tickOnce: () => Promise<void>;
}

export function startSituationalBriefingTick(
  options: SituationalBriefingTickOptions
): SituationalBriefingTickHandle {
  const intervalMs = clampInterval(options.intervalMs ?? DEFAULT_INTERVAL_MS);
  const now = options.now ?? (() => new Date());
  let firing = false;

  const observe = (
    decision: BriefingRuntimeDecision,
    at: Date,
    imminentCount = 0,
    deliveredCount = 0,
    errorCount = 0,
    lastRoute?: MessagingRouteResolution
  ): void => {
    try {
      options.runtimeStatus?.record({
        availability: "observed",
        decision,
        deliveredCount,
        errorCount,
        imminentCount,
        lastRoute,
        observedAtIso: at.toISOString(),
        phase: "tick"
      });
    } catch {
    }
  };

  const tickOnce = async (): Promise<void> => {
    if (firing) {
      observe("already-running", now());
      return;
    }
    const at = now();
    const activeQuietHours = resolveQuietHoursOption(options.quietHours);
    if (activeQuietHours && isQuietHour(at.getHours(), activeQuietHours)) {
      observe("quiet-hours", at);
      return;
    }
    firing = true;
    let attemptedRoute: MessagingRouteResolution | undefined;
    let imminentCount = 0;
    try {
      let resolverThrew = false;
      const admission = admitAutomationRoute({
        localOnly: options.localOnly,
        resolveRoute: () => {
          try {
            return options.resolveRoute();
          } catch (cause) {
            resolverThrew = true;
            throw cause;
          }
        }
      });
      attemptedRoute = admission.route;
      if (!admission.admitted) {
        observe("route-unavailable", at, 0, 0, 0, admission.route);
        if (resolverThrew) {
          options.errorLogger?.("situational-briefing-tick: route-unavailable");
        } else if (admission.route.status !== "unconfigured" || admission.route.reason !== "paired-route-inspection-unavailable") {
          options.errorLogger?.(`situational-briefing-tick: route-unavailable (${admission.route.reason ?? admission.route.status})`);
        }
        return;
      }
      const route = admission.route;
      let imminent = options.imminent ?? [];
      if (options.imminentProvider) {
        try {
          imminent = await options.imminentProvider(now());
        } catch {
          imminent = [];
        }
      }
      imminentCount = imminent.length;
      const summary = await runDueSituationalBriefing({
        destination: route.destination,
        imminent,
        messagingRegistry: options.registry,
        now,
        objectivesFile: options.objectivesFile,
        providerId: route.providerId,
        sidecarFile: options.sidecarFile,
        ...(options.weatherProvider && options.weatherLocation
          ? { weatherLocation: options.weatherLocation, weatherProvider: options.weatherProvider }
          : {}),
        ...(options.emailProvider ? { emailProvider: options.emailProvider } : {}),
        ...(options.inboxKnownSender ? { inboxKnownSender: options.inboxKnownSender } : {}),
        ...(options.relatedKnowledge ? { relatedKnowledge: options.relatedKnowledge } : {}),
        ...(options.homeAlert ? { homeAlert: options.homeAlert } : {}),
        ...(options.birthdayLine ? { birthdayLine: options.birthdayLine } : {}),
        ...(options.tasksDueLine ? { tasksDueLine: options.tasksDueLine } : {}),
        ...(options.availabilityLine ? { availabilityLine: options.availabilityLine } : {}),
        ...(options.windowMs !== undefined ? { windowMs: options.windowMs } : {})
      });
      const decision: BriefingRuntimeDecision = summary.delivered > 0
        ? "delivered"
        : summary.reason ?? "error";
      observe(decision, at, imminentCount, summary.delivered, 0, route);
      if (summary.delivered > 0) {
        options.logger?.(`situational-briefing-tick: delivered via ${route.providerId}`);
      }
    } catch (cause) {
      observe("error", at, imminentCount, 0, 1, attemptedRoute);
      const message = errorMessage(cause);
      options.errorLogger?.(`situational-briefing-tick: ${message}`);
    } finally {
      firing = false;
    }
  };

  const handle = setInterval(() => {
    void tickOnce();
  }, intervalMs);
  if (typeof handle.unref === "function") {
    handle.unref();
  }

  return {
    stop: () => clearInterval(handle),
    tickOnce
  };
}

function clampInterval(raw: number): number {
  if (!Number.isFinite(raw)) {
    return DEFAULT_INTERVAL_MS;
  }
  return Math.max(MIN_INTERVAL_MS, Math.min(MAX_INTERVAL_MS, Math.trunc(raw)));
}
