// Health/spec/openapi + chat (incl. rate-limit) registrars — split out of server-routes.ts (domain cohesion).

import { parseBoolean, resolveActionLogFile, resolvePendingApprovalsFile } from "@muse/autoconfigure";
import {
  createLoopSupervisorHealthSnapshot,
  type AdaptationLoopHealthInput,
  type AgentLoopHealthInput,
  type EventLoopHealthInput
} from "@muse/shared";
import type { FastifyInstance } from "fastify";

import { serverBuildId, serverStartedAtIso } from "./build-info.js";
import { denyChatApproval } from "./chat-approval-deny.js";
import { executeChatApproval } from "./chat-approval-execute.js";
import { getChatApprovalStatus } from "./chat-approval-status.js";
import { ChatRateLimiter, clientKeyFromRequest } from "./chat-rate-limiter.js";
import { createHttpRequestAbortScope } from "./http-request-abort.js";
import {
  createOpenApiDocument,
  getAuthIdentity,
  runChat,
  runChatStream,
  runMultipartChat
} from "./server-helpers.js";
import type { ServerOptions } from "./server.js";
import { projectApiHealth } from "./api-readiness.js";

export interface CoreRouteHealthOptions {
  readonly adaptationLoopHealthSnapshot?: () => AdaptationLoopHealthInput | undefined;
  readonly agentLoopHealthSnapshot?: () => AgentLoopHealthInput | undefined;
  readonly eventLoopHealthSnapshot?: () =>
    EventLoopHealthInput | Promise<EventLoopHealthInput | undefined> | undefined;
  readonly dependencyReadiness?: ServerOptions["dependencyReadiness"];
  readonly localOnly: boolean;
  readonly modelConfigured: boolean;
  readonly residentConfigured: boolean;
}

export function registerCoreRoutes(
  server: FastifyInstance,
  apiRouteMethods: ReadonlyMap<string, ReadonlySet<string>>,
  healthOptions: CoreRouteHealthOptions
): void {
  const healthPayload = {
    ...projectApiHealth(healthOptions),
    pid: process.pid,
    service: "muse-api",
    startedAtIso: serverStartedAtIso(),
    status: "ok",
    version: serverBuildId()
  };
  server.get("/health", async () => healthPayload);
  server.get("/api/health", async () => healthPayload);
  server.get("/ready", async (_request, reply) => {
    return reply
      .status(healthPayload.readiness.status === "ready" ? 200 : 503)
      .send(healthPayload);
  });
  server.get("/api/ready", async (_request, reply) => {
    return reply
      .status(healthPayload.readiness.status === "ready" ? 200 : 503)
      .send(healthPayload);
  });
  server.get("/api/loop-health", async () => {
    let adaptation: AdaptationLoopHealthInput | undefined;
    let agent: AgentLoopHealthInput | undefined;
    let event: EventLoopHealthInput | undefined;
    try {
      adaptation = healthOptions.adaptationLoopHealthSnapshot?.();
    } catch {
      adaptation = undefined;
    }
    try {
      agent = healthOptions.agentLoopHealthSnapshot?.();
    } catch {
      agent = undefined;
    }
    try {
      event = await healthOptions.eventLoopHealthSnapshot?.();
    } catch {
      event = undefined;
    }
    return createLoopSupervisorHealthSnapshot({
      ...(adaptation ? { adaptation } : {}),
      ...(agent ? { agent } : {}),
      ...(event ? { event } : {}),
      generatedAt: new Date()
    });
  });

  server.get("/spec", async () => ({
    agentCore: "model-agnostic",
    database: "postgresql",
    runner: "rust",
    server: "fastify"
  }));
  server.get("/v3/api-docs", async () => createOpenApiDocument(apiRouteMethods));
  server.get("/api/openapi.json", async () => createOpenApiDocument(apiRouteMethods));
}

export function registerChatRoutes(server: FastifyInstance, options: ServerOptions): void {
  const rateLimiter = options.chatRateLimiter ?? buildDefaultChatRateLimiter();
  const enforce = (request: { ip?: string }, reply: { status(code: number): { send(body: unknown): unknown }; header(name: string, value: string): unknown }): boolean => {
    if (rateLimiter === undefined) return true;
    const verdict = rateLimiter.consume(clientKeyFromRequest(request));
    if (verdict.allowed) return true;
    reply.header("Retry-After", String(verdict.retryAfterSeconds ?? 60));
    reply.status(429).send({
      error: "rate limit exceeded — too many chat requests from this IP. Try again shortly.",
      retryAfterSeconds: verdict.retryAfterSeconds ?? 60
    });
    return false;
  };

  server.post("/chat", async (request, reply) => {
    if (!enforce(request, reply)) return reply;
    return runChat(request.body, reply, options, "extended", getAuthIdentity(request)?.userId);
  });
  server.post("/api/chat", async (request, reply) => {
    if (!enforce(request, reply)) return reply;
    return runChat(request.body, reply, options, "compat", getAuthIdentity(request)?.userId);
  });
  server.post("/chat/stream", async (request, reply) => {
    if (!enforce(request, reply)) return reply;
    return runChatStream(request.body, reply, options, "extended", getAuthIdentity(request)?.userId);
  });
  server.post("/api/chat/stream", async (request, reply) => {
    if (!enforce(request, reply)) return reply;
    return runChatStream(request.body, reply, options, "compat", getAuthIdentity(request)?.userId);
  });
  server.post("/api/chat/multipart", async (request, reply) => {
    if (!enforce(request, reply)) return reply;
    return runMultipartChat(request.body, reply, options, getAuthIdentity(request)?.userId);
  });
  // Confirm-execute for a draft-first chat write (outbound-safety): the ONLY
  // path that runs a captured write/execute action, and only after the user
  // POSTs its id. Fail paths (unknown/expired id, no resolver, unknown tool)
  // execute nothing; a successful run is cleared so a replay 404s.
  server.post("/api/chat/approvals/:id/approve", async (request, reply) => {
    if (!enforce(request, reply)) return reply;
    const id = (request.params as { id?: string }).id ?? "";
    const requestUserId = getAuthIdentity(request)?.userId;
    const abortScope = createHttpRequestAbortScope(request, reply);
    try {
      const result = await executeChatApproval({
        id,
        pendingFile: resolvePendingApprovalsFile(options.env ?? {}),
        signal: abortScope.signal,
        ...(requestUserId ? { requestUserId } : {}),
        ...(options.approvalToolResolver ? { resolveTool: options.approvalToolResolver } : {})
      });
      return reply.status(result.statusCode).send(result.body);
    } finally {
      abortScope.dispose();
    }
  });
  server.get("/api/chat/approvals/:id/status", async (request, reply) => {
    if (!enforce(request, reply)) return reply;
    const id = (request.params as { id?: string }).id ?? "";
    const requestUserId = getAuthIdentity(request)?.userId;
    const result = await getChatApprovalStatus({
      id,
      pendingFile: resolvePendingApprovalsFile(options.env ?? {}),
      ...(requestUserId ? { requestUserId } : {})
    });
    return reply.status(result.statusCode).send(result.body);
  });
  server.post("/api/chat/approvals/:id/recover", async (request, reply) => {
    if (!enforce(request, reply)) return reply;
    const body = request.body;
    if (body !== undefined && body !== null
      && (typeof body !== "object" || Array.isArray(body) || Object.keys(body).length > 0)) {
      return reply.status(400).send({ error: "approval recovery body must be empty" });
    }
    const id = (request.params as { id?: string }).id ?? "";
    const requestUserId = getAuthIdentity(request)?.userId;
    const abortScope = createHttpRequestAbortScope(request, reply);
    try {
      const result = await executeChatApproval({
        acquisition: "recover-stale-claim",
        id,
        pendingFile: resolvePendingApprovalsFile(options.env ?? {}),
        signal: abortScope.signal,
        ...(requestUserId ? { requestUserId } : {}),
        ...(options.approvalToolResolver ? { resolveTool: options.approvalToolResolver } : {})
      });
      return reply.status(result.statusCode).send(result.body);
    } finally {
      abortScope.dispose();
    }
  });
  // Confirm-deny for a draft-first chat write (outbound-safety fail-close
  // symmetry with approve): clears the pending entry and records a rationale-
  // bearing `refused` action-log entry, but never executes the tool — there is
  // no tool resolver on this path at all.
  server.post("/api/chat/approvals/:id/deny", async (request, reply) => {
    if (!enforce(request, reply)) return reply;
    const id = (request.params as { id?: string }).id ?? "";
    const requestUserId = getAuthIdentity(request)?.userId;
    const result = await denyChatApproval({
      actionLogFile: resolveActionLogFile(options.env ?? {}),
      id,
      pendingFile: resolvePendingApprovalsFile(options.env ?? {}),
      ...(requestUserId ? { requestUserId } : {})
    });
    return reply.status(result.statusCode).send(result.body);
  });
}

// Strict parse, not Number.parseInt: a typo'd `60x` / unit-slip
// `30s` env value must NOT silently become the numeric prefix and
// install the wrong rate-limit capacity. Whole-token decimal int
// only; everything else → fallback 60.
export function parseChatRateLimitCapacity(raw: string | undefined, fallback = 60): number {
  if (typeof raw !== "string") return fallback;
  const trimmed = raw.trim();
  if (!/^[+-]?\d+$/u.test(trimmed)) return fallback;
  const parsed = Number(trimmed);
  return Number.isInteger(parsed) && parsed > 0 ? parsed : fallback;
}

/**
 * `MUSE_RATE_LIMIT_CHAT_DISABLED` accepts every standard truthy
 * spelling (true / 1 / yes / on, case-insensitive, trimmed). The
 * pre-fix `=== "true"` check only honored the exact literal — an
 * operator setting `=1` or `=on` saw rate limiting silently stay
 * active. Defaults to "not disabled" on undefined / unrecognised
 * so a typo'd kill switch keeps the limiter enabled (fail-safe
 * direction for a security-adjacent flag).
 */
export function isChatRateLimitDisabled(raw: string | undefined): boolean {
  return parseBoolean(raw, false);
}

function buildDefaultChatRateLimiter(): ChatRateLimiter | undefined {
  if (isChatRateLimitDisabled(process.env.MUSE_RATE_LIMIT_CHAT_DISABLED)) {
    return undefined;
  }
  const capacity = parseChatRateLimitCapacity(process.env.MUSE_RATE_LIMIT_CHAT_PER_MINUTE);
  return new ChatRateLimiter({ capacity, windowMs: 60_000 });
}
