import {
  enforceAnswerCitations,
  guardAgainstUnbackedActionClaim,
  projectLoopControlReceiptHealth,
  type AgentRuntime
} from "@muse/agent-core";
import { chatAllowedCitations, createCitationStreamFilter, gateChatAnswerGrounding, type ChatGroundingSource } from "@muse/recall";
import type { JsonObject } from "@muse/shared";

import { applyAutomationHonesty } from "./chat-automation-honesty.js";
import { formatApprovalNotice, type ChatPendingDraft, type PersistedApproval } from "./chat-approval-gate.js";

export function parseMultipartBody(contentType: string | string[] | undefined, body: Buffer): JsonObject {
  const header = Array.isArray(contentType) ? contentType[0] : contentType;
  const boundary = header?.match(/boundary=(?:"([^"]+)"|([^;]+))/iu)?.slice(1).find(Boolean);

  if (!boundary) {
    throw new Error("Multipart boundary is required");
  }

  const fields: Record<string, string> = {};
  const files: JsonObject[] = [];
  const raw = body.toString("latin1");

  for (const part of raw.split(`--${boundary}`)) {
    if (part.trim().length === 0 || part.trim() === "--") {
      continue;
    }

    const headerEnd = part.indexOf("\r\n\r\n");

    if (headerEnd < 0) {
      continue;
    }

    const headers = part.slice(0, headerEnd).toLowerCase();
    const disposition = headers.match(/content-disposition:[^\r\n]+/iu)?.[0] ?? "";
    const name = disposition.match(/name="([^"]+)"/iu)?.[1];

    if (!name) {
      continue;
    }

    const filename = disposition.match(/filename="([^"]*)"/iu)?.[1];
    const contentTypeValue = headers.match(/content-type:\s*([^\r\n]+)/iu)?.[1]?.trim();
    const rawContent = part.slice(headerEnd + 4).replace(/\r\n--$/u, "").replace(/\r\n$/u, "");
    const content = Buffer.from(rawContent, "latin1");

    if (filename !== undefined) {
      files.push({
        contentBase64: content.toString("base64"),
        contentType: contentTypeValue ?? "application/octet-stream",
        fieldName: name,
        filename,
        size: content.byteLength
      });
      continue;
    }

    fields[name] = content.toString("utf8");
  }

  return { fields, files };
}

/**
 * Frame a value as SSE `data:` lines. The EventSource spec treats
 * CRLF, a lone CR, and LF all as line terminators, so a bare `\r`
 * in model output / tool JSON must split into its own `data:`
 * segment too — otherwise the client parses past it and truncates
 * the stream. CRLF is matched first so it stays one separator.
 * Exported for direct test coverage of the line-splitting.
 */
export function sseData(value: string): string {
  return value.split(/\r\n|\r|\n/u).map((line) => line.length > 0 ? line : " ").join("\ndata: ");
}

export async function* toSseStream(
  events: ReturnType<AgentRuntime["stream"]>,
  responseMode: "extended" | "compat",
  grounding?: {
    readonly question: string;
    /**
     * Opt-in `/api/chat` write path (`MUSE_CHAT_WRITE_ENABLED`). `drafts` is
     * populated live by the approval gate as write/execute tools are captured;
     * once the turn's tool calls are done it holds every captured draft. After
     * the answer's grounding frame, its captured drafts are persisted and a
     * code-appended approval notice is emitted as a `message` event — before
     * `done`, so a client that stops at `done` still sees it.
     */
    readonly chatWrite?: {
      readonly drafts: readonly ChatPendingDraft[];
      readonly persist: (userId?: string) => Promise<readonly PersistedApproval[]>;
      readonly userId?: string;
    };
    /**
     * S3b conversation continuity: `conversationId` rides the `grounding` AND
     * (extended-mode) `done` frames, and `persistTurn` appends the user+
     * assistant pair to the shared store ONLY once the final gated/honest
     * answer is known — a stream that errors before this point (no `done`)
     * persists nothing (AC5).
     */
    readonly conversation?: {
      readonly conversationId: string;
      readonly persistTurn: (answerText: string) => Promise<void>;
    };
  }
): AsyncIterable<string> {
  // Post-stream grounding gate (CLI-chat parity): raw deltas stream live, then the
  // FULL assembled answer is gated over the evidence THIS turn produced (the
  // `tool-result` events' grounding). An authoritative `grounding` frame carries the
  // gated answer + verdict before `done`, so a fabricated/uncited claim never stands
  // as the final answer even though its tokens flashed by (a post-stream verdict is
  // the accepted streaming shape). No question wired ⇒ no gate (byte-identical stream).
  let assembled = "";
  const evidence: ChatGroundingSource[] = [];
  const toolNames = new Set<string>();
  // Live citation filter over the SAME allowed set the buffered gate derives
  // (chatAllowedCitations over this turn's evidence — read at clean time, so
  // sources a tool adds mid-run count). Deltas stream through it, a fabricated
  // `[from …]` span is dropped before it can flash, and the post-stream
  // grounding frame stays the authoritative final answer.
  const liveFilter = createCitationStreamFilter(
    (span) => enforceAnswerCitations(span, chatAllowedCitations(evidence)).text
  );
  // The first frame leaves BEFORE any model/recall work, so the client can
  // show a live "thinking" state instantly instead of a dead connection —
  // the answer itself only arrives post-gate, which can take a minute on
  // a local 12B model.
  yield "event: stage\ndata: thinking\n\n";
  for await (const event of events) {
    if (event.type === "context-compacted") {
      yield `event: context_compacted\ndata: ${sseData(JSON.stringify({
        removedCount: event.removedCount,
        runId: event.runId
      }))}\n\n`;
      continue;
    }

    if (event.type === "text-delta") {
      assembled += event.text;
      const safe = liveFilter.push(event.text);
      if (safe.length > 0) {
        yield `event: message\ndata: ${sseData(safe)}\n\n`;
      }
      continue;
    }

    if (event.type === "tool-call") {
      toolNames.add(event.toolCall.name);
      if (responseMode === "compat") {
        yield `event: tool_start\ndata: ${sseData(event.toolCall.name)}\n\n`;
        continue;
      }

      yield `event: tool_call\ndata: ${sseData(JSON.stringify(event.toolCall))}\n\n`;
      continue;
    }

    if (event.type === "tool-result") {
      toolNames.add(event.toolCall.name);
      if (event.grounding) {
        evidence.push({ source: event.grounding.source, text: event.grounding.text });
      }

      if (responseMode === "compat") {
        yield `event: tool_end\ndata: ${sseData(event.toolCall.name)}\n\n`;
      }

      continue;
    }

    if (event.type === "tool-call-started") {
      yield `event: tool_call\ndata: ${sseData(JSON.stringify({ name: event.name, phase: "started" }))}\n\n`;
      continue;
    }

    if (event.type === "tool-call-finished") {
      yield `event: tool_call\ndata: ${sseData(JSON.stringify({ count: event.count, name: event.name, phase: "finished" }))}\n\n`;
      continue;
    }

    if (event.type === "citations") {
      yield `event: citations\ndata: ${sseData(JSON.stringify(event.items))}\n\n`;
      continue;
    }

    if (event.type === "error") {
      yield `event: error\ndata: ${sseData(event.error.message)}\n\n`;
      continue;
    }

    if (event.type === "plan-generated") {
      yield `event: plan_generated\ndata: ${sseData(JSON.stringify({ plan: event.plan, runId: event.runId }))}\n\n`;
      continue;
    }

    if (event.type === "plan-step-executing") {
      yield `event: plan_step_executing\ndata: ${sseData(
        JSON.stringify({ description: event.description, runId: event.runId, stepIndex: event.stepIndex, tool: event.tool })
      )}\n\n`;
      continue;
    }

    if (event.type === "plan-step-result") {
      yield `event: plan_step_result\ndata: ${sseData(
        JSON.stringify({ runId: event.runId, stepIndex: event.stepIndex, success: event.success })
      )}\n\n`;
      continue;
    }

    if (event.type === "synthesis-started") {
      yield `event: synthesis_started\ndata: ${sseData(JSON.stringify({ runId: event.runId }))}\n\n`;
      continue;
    }

    if (event.type !== "done") continue;
    const loopHealth = projectLoopControlReceiptHealth(event.loopControlReceipt);
    if (loopHealth) {
      const { runId: _runId, ...compatLoopHealth } = loopHealth;
      yield `event: loop_health\ndata: ${sseData(JSON.stringify(
        responseMode === "compat" ? compatLoopHealth : loopHealth
      ))}\n\n`;
    }

    const tail = liveFilter.flush();
    if (tail.length > 0) {
      yield `event: message\ndata: ${sseData(tail)}\n\n`;
    }

    if (grounding) {
      const gate = gateChatAnswerGrounding({
        answer: event.response.output.length > 0 ? event.response.output : assembled,
        evidence,
        question: grounding.question
      });
      // Honest-action gate (parity with the buffered `/api/chat` path and the
      // channel reply — `honest-action-guard.ts`): the assembled answer can
      // CLAIM a completed state-changing action while no actuator tool ran
      // this turn. No retry here — the stream has already finished, so this
      // is a deterministic downgrade only (documented stream limitation: an
      // in-flight re-prompt would require re-streaming the whole turn).
      const honest = await guardAgainstUnbackedActionClaim({
        firstResult: { response: { output: gate.answer }, toolsUsed: [...toolNames] },
        query: grounding.question
      });
      if (grounding.conversation) {
        await grounding.conversation.persistTurn(honest.response.output);
      }
      // Honesty post-pass on the FINAL streamed result only (never per-delta —
      // deltas already flashed by; this is the authoritative answer before
      // `done`), same rule as the buffered `/api/chat` path.
      const automation = applyAutomationHonesty({ replyText: honest.response.output, userText: grounding.question });
      yield `event: grounding\ndata: ${sseData(JSON.stringify({
        answer: automation.content,
        builderHint: automation.builderHint,
        ...(grounding.conversation ? { conversationId: grounding.conversation.conversationId } : {}),
        gated: gate.gated || honest.response.output !== gate.answer || automation.content !== honest.response.output,
        strippedCitations: gate.strippedCitations,
        verdict: gate.groundingVerdict
      }))}\n\n`;
    }

    if (grounding?.chatWrite && grounding.chatWrite.drafts.length > 0) {
      const pendingApprovals = await grounding.chatWrite.persist(grounding.chatWrite.userId);
      yield `event: message\ndata: ${sseData(formatApprovalNotice(grounding.chatWrite.drafts))}\n\n`;
      // Structured companion to the text notice: carries the id each pending
      // write needs so the client can POST /api/chat/approvals/:id/approve.
      yield `event: pending-approvals\ndata: ${sseData(JSON.stringify({ pendingApprovals: [...pendingApprovals] }))}\n\n`;
    }

    if (responseMode === "compat") {
      yield "event: done\ndata:\n\n";
      continue;
    }

    yield `event: done\ndata: ${sseData(JSON.stringify({
      ...(grounding?.conversation ? { conversationId: grounding.conversation.conversationId } : {}),
      model: event.response.model,
      response: event.response.output,
      runId: event.runId,
      usage: event.response.usage
    }))}\n\n`;
  }
}
