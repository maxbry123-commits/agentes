import type { MessagingRouteResolution } from "@muse/autoconfigure";

import {
  sanitizeMessagingRouteReceipt,
  unavailableMessagingRouteReceipt
} from "./messaging-route-receipt.js";

export type ProactiveRuntimeDecision =
  | "startup"
  | "already-running"
  | "quiet-hours"
  | "route-unavailable"
  | "session-locked"
  | "lock-held"
  | "lock-error"
  | "no-imminent"
  | "suppressed"
  | "fired"
  | "completed"
  | "error";

export type ProactiveRuntimePhase = "startup" | "tick";
export type ProactiveRuntimeAvailability =
  | "dormant"
  | "observed"
  | "not-configured"
  | "disabled"
  | "blocked";

export interface ProactiveRuntimeStatus {
  readonly availability: ProactiveRuntimeAvailability;
  readonly lastDecision: ProactiveRuntimeDecision;
  readonly lastObservedAtIso: string;
  readonly lastImminentCount: number;
  readonly lastFiredCount: number;
  readonly lastSuppressedCount: number;
  readonly lastErrorCount: number;
  readonly sessionLockedUntilIso?: string;
  readonly lastRoute: MessagingRouteResolution;
  readonly phase: ProactiveRuntimePhase;
}

export interface ProactiveRuntimeStatusUpdate {
  readonly availability: ProactiveRuntimeAvailability;
  readonly decision: ProactiveRuntimeDecision;
  readonly observedAtIso: string;
  readonly imminentCount?: number;
  readonly firedCount?: number;
  readonly suppressedCount?: number;
  readonly errorCount?: number;
  readonly sessionLockedUntilIso?: string;
  readonly lastRoute?: MessagingRouteResolution;
  readonly phase: ProactiveRuntimePhase;
}

export interface ProactiveRuntimeStatusStore {
  readonly get: () => ProactiveRuntimeStatus | null;
  readonly record: (update: ProactiveRuntimeStatusUpdate) => void;
}

const MAX_COUNT = 9_999;

export function createProactiveRuntimeStatusStore(): ProactiveRuntimeStatusStore {
  let status: ProactiveRuntimeStatus | null = null;
  return {
    get: () => status,
    record: (update) => {
      status = {
        availability: update.availability,
        lastDecision: update.decision,
        lastObservedAtIso: update.observedAtIso,
        lastImminentCount: boundedCount(update.imminentCount ?? 0),
        lastFiredCount: boundedCount(update.firedCount ?? 0),
        lastSuppressedCount: boundedCount(update.suppressedCount ?? 0),
        lastErrorCount: boundedCount(update.errorCount ?? 0),
        lastRoute: update.lastRoute
          ? sanitizeMessagingRouteReceipt(update.lastRoute)
          : status?.lastRoute ?? unavailableMessagingRouteReceipt(),
        ...(update.sessionLockedUntilIso ? { sessionLockedUntilIso: update.sessionLockedUntilIso } : {}),
        phase: update.phase
      };
    }
  };
}

export function recordProactiveRuntimeStartup(
  runtimeStatus: ProactiveRuntimeStatusStore | undefined,
  availability: Exclude<ProactiveRuntimeAvailability, "observed">,
  observedAtIso = new Date().toISOString(),
  lastRoute?: MessagingRouteResolution
): void {
  try {
    runtimeStatus?.record({
      availability,
      decision: "startup",
      lastRoute: lastRoute ?? unavailableMessagingRouteReceipt(),
      observedAtIso,
      phase: "startup"
    });
  } catch {
  }
}

function boundedCount(value: number): number {
  if (!Number.isFinite(value)) {
    return 0;
  }
  return Math.min(MAX_COUNT, Math.max(0, Math.trunc(value)));
}
