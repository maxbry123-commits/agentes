import { describe, expect, it } from "vitest";

import { createLoopControlReceipt } from "@muse/agent-core";
import { parseMultipartBody, sseData } from "./server-multipart-sse.js";

// Direct coverage for the multipart parser + SSE line-framer (untested). The
// multipart parser is the chat-upload input boundary (separates text fields from
// files, base64-encodes file bytes); sseData must split CRLF/CR/LF so a bare CR
// in model output can't truncate the SSE stream client-side.

const buildBody = (boundary: string): Buffer => Buffer.from([
  `--${boundary}`, 'Content-Disposition: form-data; name="message"', "", "hello world", `--${boundary}`,
  'Content-Disposition: form-data; name="doc"; filename="a.txt"', "Content-Type: text/plain", "", "file body", `--${boundary}--`, ""
].join("\r\n"), "latin1");

describe("parseMultipartBody", () => {
  it("separates text fields from files and base64-encodes the file bytes", () => {
    const out = parseMultipartBody("multipart/form-data; boundary=X", buildBody("X"));
    expect(out.fields).toEqual({ message: "hello world" });
    const files = out.files as Array<Record<string, unknown>>;
    expect(files).toHaveLength(1);
    expect(files[0]).toMatchObject({ contentType: "text/plain", fieldName: "doc", filename: "a.txt", size: 9 });
    expect(Buffer.from(files[0]?.contentBase64 as string, "base64").toString("utf8")).toBe("file body");
  });

  it("accepts a quoted boundary and a header-array content type", () => {
    expect(parseMultipartBody('multipart/form-data; boundary="X"', buildBody("X")).fields).toEqual({ message: "hello world" });
    expect(parseMultipartBody(["multipart/form-data; boundary=X"], buildBody("X")).fields).toEqual({ message: "hello world" });
  });

  it("throws when no boundary is present", () => {
    expect(() => parseMultipartBody("application/json", Buffer.from("x"))).toThrow(/boundary is required/u);
  });
});

describe("sseData", () => {
  it("splits CRLF / CR / LF each into a new data: segment", () => {
    expect(sseData("a\nb")).toBe("a\ndata: b");
    expect(sseData("a\r\nb")).toBe("a\ndata: b");
    expect(sseData("a\rb")).toBe("a\ndata: b");
  });

  it("emits a single space for an empty line so EventSource keeps the blank line", () => {
    expect(sseData("a\n\nb")).toBe("a\ndata:  \ndata: b");
  });
});

describe("toSseStream opening stage frame", () => {
  it("emits stage:thinking BEFORE the first runtime event, so the client shows life instantly", async () => {
    async function* slowRuntime(): AsyncIterable<{ type: "text-delta"; text: string; runId: string }> {
      yield { runId: "r", text: "hello", type: "text-delta" };
    }
    const { toSseStream } = await import("./server-multipart-sse.js");
    const frames: string[] = [];
    for await (const frame of toSseStream(slowRuntime() as never, "compat")) {
      frames.push(frame);
      if (frames.length >= 2) break;
    }
    expect(frames[0]).toContain("event: stage");
    expect(frames[0]).toContain("thinking");
    expect(frames[1]).toContain("event: message");
  });

  it("preserves a content-free compaction transition before answer output", async () => {
    async function* compactedRuntime(): AsyncIterable<
      | { type: "context-compacted"; removedCount: number; runId: string }
      | { type: "text-delta"; text: string; runId: string }
    > {
      yield { removedCount: 7, runId: "r", type: "context-compacted" };
      yield { runId: "r", text: "hello", type: "text-delta" };
    }
    const { toSseStream } = await import("./server-multipart-sse.js");
    const frames: string[] = [];
    for await (const frame of toSseStream(compactedRuntime() as never, "compat")) {
      frames.push(frame);
      if (frames.length >= 3) break;
    }
    expect(frames[1]).toBe(
      'event: context_compacted\ndata: {"removedCount":7,"runId":"r"}\n\n'
    );
    expect(frames[2]).toContain("event: message");
  });
});

describe("toSseStream loop terminal health", () => {
  const receipt = createLoopControlReceipt({
    budget: { retries: null, steps: null, tools: null, wallclockLimitMs: null },
    endedAt: "2026-07-30T00:00:01.000Z",
    loopKind: "react",
    runId: "stream-health",
    startedAt: "2026-07-30T00:00:00.000Z",
    terminal: { reason: "verification-failed", status: "failed" },
    verification: { evidenceId: "eval:stream", status: "failed" }
  });

  async function* terminal(value: unknown) {
    yield {
      loopControlReceipt: value,
      response: {
        model: "diagnostic/smoke",
        output: "answer",
        usage: undefined
      },
      runId: "stream-health",
      type: "done" as const
    };
  }

  it("emits one validated health frame before compat and extended done", async () => {
    const { toSseStream } = await import("./server-multipart-sse.js");
    for (const mode of ["compat", "extended"] as const) {
      const frames: string[] = [];
      for await (const frame of toSseStream(terminal(receipt) as never, mode)) {
        frames.push(frame);
      }
      const healthIndex = frames.findIndex((frame) =>
        frame.startsWith("event: loop_health"));
      const doneIndex = frames.findIndex((frame) =>
        frame.startsWith("event: done"));
      expect(healthIndex).toBeGreaterThan(0);
      expect(healthIndex).toBeLessThan(doneIndex);
      expect(frames[healthIndex]).toContain('"terminalStatus":"failed"');
      expect(frames[healthIndex]).toContain(
        mode === "compat" ? '"terminalReason"' : '"runId":"stream-health"'
      );
      if (mode === "compat") {
        expect(frames[healthIndex]).not.toContain('"runId"');
      }
      expect(frames.filter((frame) =>
        frame.startsWith("event: loop_health"))).toHaveLength(1);
    }
  });

  it("drops tampered terminal evidence instead of surfacing health", async () => {
    const { toSseStream } = await import("./server-multipart-sse.js");
    const frames: string[] = [];
    for await (const frame of toSseStream(
      terminal({ ...receipt, runId: "tampered" }) as never,
      "compat"
    )) {
      frames.push(frame);
    }
    expect(frames.some((frame) =>
      frame.startsWith("event: loop_health"))).toBe(false);
  });
});

describe("toSseStream live citation gate on forwarded deltas", () => {
  // The invariant this file exists to prove: a fabricated citation must not
  // reach a display EVEN over the new live-delta surface — the same clean
  // function the buffered gate uses runs over every in-flight [ … ] span,
  // and the spans it passes are exactly the spans the buffered gate keeps.
  async function* deltasWithFabrication(): AsyncIterable<
    | { type: "text-delta"; text: string; runId: string }
    | { type: "tool-result"; toolCall: { id: string; name: string; arguments: {} }; runId: string; grounding: { source: string; text: string } }
    | { type: "done"; runId: string; response: { output: string; model: string; usage: undefined } }
  > {
    yield { grounding: { source: "notes/real.md", text: "회의는 3시" }, runId: "r", toolCall: { arguments: {}, id: "t1", name: "knowledge_search" }, type: "tool-result" };
    yield { runId: "r", text: "회의는 3시야 [from ", type: "text-delta" };
    yield { runId: "r", text: "notes/real.md]. 그리고 예산은 ", type: "text-delta" };
    yield { runId: "r", text: "확정됐어 [from notes/ghost.md].", type: "text-delta" };
    yield { response: { model: "m", output: "", usage: undefined }, runId: "r", type: "done" };
  }

  it("passes a real citation through and DROPS a fabricated one mid-stream (span split across chunks)", async () => {
    const { toSseStream } = await import("./server-multipart-sse.js");
    const frames: string[] = [];
    for await (const frame of toSseStream(deltasWithFabrication() as never, "compat")) {
      frames.push(frame);
    }
    const streamedText = frames
      .filter((f) => f.startsWith("event: message"))
      .map((f) => f.split("data: ").slice(1).join("data: "))
      .join("");
    // The enforcer canonicalizes the ref to its basename — same as the buffered gate.
    expect(streamedText).toContain("[from real.md]");
    expect(streamedText).not.toContain("ghost.md");
  });

  it("the grounding frame stays authoritative over whatever streamed", async () => {
    const { toSseStream } = await import("./server-multipart-sse.js");
    const frames: string[] = [];
    for await (const frame of toSseStream(deltasWithFabrication() as never, "compat", { question: "회의 언제야?" })) {
      frames.push(frame);
    }
    const groundingFrame = frames.find((f) => f.startsWith("event: grounding"));
    expect(groundingFrame).toBeTruthy();
    const payload = JSON.parse(groundingFrame!.split("data: ")[1]!) as { answer: string; strippedCitations: string[] };
    // The fabricated source never reaches the answer — it appears ONLY in the
    // gate's own audit list of what it removed.
    expect(payload.answer).not.toContain("ghost.md");
    expect(payload.strippedCitations).toContain("notes/ghost.md");
  });

  it("an ALL-fabricated answer (zero real evidence) degrades to the honest hedge, never the claim", async () => {
    // The worst case for the fabrication=0 contract on the stream surface:
    // the run produced NO grounding evidence at all, and every streamed
    // sentence rests on an invented citation. The authoritative grounding
    // frame must carry the hedge — not a cleaned-up version of the claim.
    async function* allFabricated(): AsyncIterable<
      | { type: "text-delta"; text: string; runId: string }
      | { type: "done"; runId: string; response: { output: string; model: string; usage: undefined } }
    > {
      yield { runId: "r", text: "임대료는 130만원이야 [from notes/ghost.md].", type: "text-delta" };
      yield { response: { model: "m", output: "", usage: undefined }, runId: "r", type: "done" };
    }
    const { toSseStream } = await import("./server-multipart-sse.js");
    const frames: string[] = [];
    for await (const frame of toSseStream(allFabricated() as never, "compat", { question: "임대료 얼마야?" })) {
      frames.push(frame);
    }
    const groundingFrame = frames.find((f) => f.startsWith("event: grounding"));
    expect(groundingFrame).toBeTruthy();
    const payload = JSON.parse(groundingFrame!.split("data: ")[1]!) as {
      answer: string;
      strippedCitations: string[];
    };
    // The invented amount and its invented source are both gone; what
    // remains is an honest not-sure, and the strip is auditable.
    expect(payload.answer).not.toContain("130");
    expect(payload.answer).not.toContain("ghost.md");
    expect(payload.answer.length).toBeGreaterThan(0);
    expect(payload.strippedCitations).toContain("notes/ghost.md");
    // The live delta filter must ALSO have withheld the fabricated span, so
    // even the transient raw-token display never showed the invented source.
    const streamedText = frames
      .filter((f) => f.startsWith("event: message"))
      .map((f) => f.split("data: ").slice(1).join("data: "))
      .join("");
    expect(streamedText).not.toContain("ghost.md");
  });
});
