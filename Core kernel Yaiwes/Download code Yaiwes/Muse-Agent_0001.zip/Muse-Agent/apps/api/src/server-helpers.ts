/**
 * Standalone helpers extracted from server.ts.
 *
 * Three buckets, all pure (no Fastify closure state):
 *   1. Chat domain — body parsers, response builders, agent-error handler,
 *      SSE stream encoder, multipart parser. Centred on AgentRuntime
 *      input/output shapes.
 *   2. Other parsers — agent-spec / runtime-setting / auth credentials
 *      input validators that produce ParseResult<T>.
 *   3. HTTP plumbing — CORS / API-version / sensitive-path / public-route /
 *      OpenAPI document builder + small util predicates and option helpers.
 *
 * Keeps server.ts focused on `buildServer` route registration. The chat
 * runners (`runChat` / `runChatStream` / `runMultipartChat`) live here too
 * so the helper file owns the full input → AgentRuntime → response chain.
 */

import { Readable } from "node:stream";
import {
  buildModelRequestWithWebSearch,
  guardAgainstUnbackedActionClaim,
  type AgentRunInput,
  type AgentRunResult,
  type ToolApprovalGate
} from "@muse/agent-core";
import { parseBoolean, resolvePendingApprovalsFile } from "@muse/autoconfigure";
import { createToolExposureAuthority, type ToolExposureAuthority } from "@muse/policy";
import { gateChatAnswerGrounding } from "@muse/recall";
import { isRecord } from "./server-input-utils.js";

import { applyAutomationHonesty } from "./chat-automation-honesty.js";
import { createChannelPendingRecorder } from "./channel-pending-recorder.js";
import { createChatApprovalGate, formatApprovalNotice, type ChatPendingDraft, type PersistedApproval } from "./chat-approval-gate.js";
import { resolveChatConversationPlan, withPriorConversationTurns } from "./chat-conversation-continuity.js";
import { CHANNEL_APPROVAL_EXPOSURE_ALLOWLIST } from "./chat-write-allowlist.js";

import type { ServerOptions } from "./server.js";

import {
  parseAgentRunInput,
  parseMultipartChatBody
} from "./server-parsers.js";

export {
  parseAgentRunInput,
  parseAgentSpecInput,
  parseAuthCredentials,
  parseMultipartChatBody,
  parseRuntimeSettingInput,
  type ApiError,
  type ParseResult
} from "./server-parsers.js";

// ---------------------------------------------------------------------------
// Chat runners
// ---------------------------------------------------------------------------

export interface ChatWriteApprovalWiring {
  readonly toolExposureAuthority: ToolExposureAuthority;
  readonly toolApprovalGate: ToolApprovalGate;
  readonly drafts: ChatPendingDraft[];
  readonly persist: (userId?: string) => Promise<readonly PersistedApproval[]>;
}

/**
 * Opt-in write-tool wiring for the direct `/api/chat` surface
 * (`MUSE_CHAT_WRITE_ENABLED`, off by default). Returns the exposure authority
 * that widens chat to the notes/tasks/calendar/reminders allowlist plus a
 * draft-first gate that captures — never executes — a write/execute call
 * (outbound-safety.md). `persist` flushes the captured drafts to the pending
 * store AFTER the run, so a run the model abandons leaves nothing on disk.
 * Absent flag ⇒ `undefined`, and the caller adds no authority/gate — chat
 * behaves byte-identically to the read-only default.
 */
export function chatWriteApprovalWiring(options: ServerOptions): ChatWriteApprovalWiring | undefined {
  if (!parseBoolean(options.env?.MUSE_CHAT_WRITE_ENABLED, false)) {
    return undefined;
  }
  const env = options.env ?? {};
  const pendingFile = resolvePendingApprovalsFile(env);
  const drafts: ChatPendingDraft[] = [];
  const persist = async (userId?: string): Promise<readonly PersistedApproval[]> => {
    const recorder = createChannelPendingRecorder({ pendingFile, providerId: "chat", source: "api-chat" });
    const created: PersistedApproval[] = [];
    for (const draft of drafts) {
      const resolvedUserId = draft.userId ?? userId;
      const entry = await recorder({
        arguments: draft.arguments,
        draft: draft.draft,
        risk: draft.risk,
        tool: draft.tool,
        ...(resolvedUserId ? { userId: resolvedUserId } : {})
      });
      created.push({ draft: entry.draft, id: entry.id, tool: entry.tool });
    }
    return created;
  };
  return {
    drafts,
    persist,
    toolApprovalGate: createChatApprovalGate(drafts),
    toolExposureAuthority: createToolExposureAuthority({
      allowedToolNames: [...CHANNEL_APPROVAL_EXPOSURE_ALLOWLIST],
      localMode: false
    })
  };
}

export async function runChat(
  body: unknown,
  reply: { status(statusCode: number): { send(payload: unknown): void } },
  options: ServerOptions,
  responseMode: "extended" | "compat",
  authUserId?: string
) {
  if (!options.agentRuntime) {
    return reply.status(503).send({
      code: "AGENT_RUNTIME_UNAVAILABLE",
      message: "Agent runtime is not configured"
    });
  }

  const agentRuntime = options.agentRuntime;
  const parsed = parseAgentRunInput(body, options.defaultModel ?? "default", authUserId);

  if (!parsed.ok) {
    return reply.status(400).send(parsed.error);
  }

  const conversationPlan = await resolveChatConversationPlan(body, options);
  const baseInputRaw = await applyWebSearchPolicy(parsed.value, body, options);
  const baseInput = conversationPlan
    ? { ...baseInputRaw, messages: withPriorConversationTurns(baseInputRaw.messages, conversationPlan.priorMessages) }
    : baseInputRaw;
  const writeWiring = chatWriteApprovalWiring(options);
  const runInput = writeWiring
    ? {
        ...baseInput,
        toolApprovalGate: writeWiring.toolApprovalGate,
        toolExposureAuthority: writeWiring.toolExposureAuthority
      }
    : baseInput;

  try {
    const result = await agentRuntime.run(runInput);
    // Grounding parity with the CLI chat surface: gate the raw agent output before
    // it leaves, so a fabricated/uncited claim is dropped by code (fabrication=0)
    // while a properly grounded answer passes UNCHANGED. Evidence is what THIS turn
    // produced — the read-tool outputs / injected inbox in `groundingSources`.
    const question = lastUserQuestion(runInput.messages);
    const gate = gateChatAnswerGrounding({
      answer: result.response.output,
      evidence: [...(result.groundingSources ?? [])],
      question
    });
    const grounded = gate.gated
      ? { ...result, response: { ...result.response, output: gate.answer } }
      : result;
    // Honest-action gate (channel-reply parity, `honest-action-guard.ts`): the
    // model can claim a completed state-changing action ("일정을 등록했습니다")
    // while NO actuator tool ran. Bound to one clean-history retry (mirrors the
    // CLI's `runResistingFalseDone`); if the retry also fails to act, the claim
    // is replaced with a short honest notice rather than reaching the user.
    const honest = await guardAgainstUnbackedActionClaim({
      firstResult: grounded,
      query: question,
      retry: () => agentRuntime.run({ ...runInput, messages: cleanRetryMessages(runInput.messages) })
    });
    // A RECOVERED retry produces text the first gate never saw, so it must
    // re-enter the citation gate — otherwise the retry is a hole straight
    // through fabrication=0. Unchanged answers keep the original verdict.
    const finalGate = honest === grounded
      ? gate
      : gateChatAnswerGrounding({
          answer: honest.response.output,
          evidence: [...(honest.groundingSources ?? [])],
          question
        });
    const finalResult = finalGate.gated && finalGate.answer !== honest.response.output
      ? { ...honest, response: { ...honest.response, output: finalGate.answer } }
      : honest;
    // Persisted AFTER every gate (grounding + honest-action) so a fabricated/
    // uncited claim never lands in a future turn's context — and only on this
    // success path, so a failed run appends nothing (AC5, atomic pair-append).
    if (conversationPlan) {
      await conversationPlan.persistTurn(finalResult.response.output);
    }
    // Pending-approval notice is code-appended AFTER the grounding + honest-action
    // gates (never model text) so it can't be dropped as fabricated, and persisted
    // only now — a run the model abandoned before any write never reaches here with
    // captured drafts. The userId falls back to the request's authenticated id.
    const delivered = writeWiring && writeWiring.drafts.length > 0
      ? await withApprovalNotice(finalResult, writeWiring, chatUserId(runInput, authUserId))
      : { pendingApprovals: [] as readonly PersistedApproval[], result: finalResult };
    // Honesty post-pass (chat-automation-honesty.ts): the chat surface has no
    // scheduling capability of its own, so a reply that CLAIMS it registered a
    // recurring automation ("규칙을 등록해둘게") is a false-done — correct it and
    // point the user at the Builder, which the client renders from `builderHint`.
    const automation = applyAutomationHonesty({ replyText: delivered.result.response.output, userText: question });
    const honestDelivered = automation.content === delivered.result.response.output
      ? delivered.result
      : { ...delivered.result, response: { ...delivered.result.response, output: automation.content } };
    const conversationField = conversationPlan ? { conversationId: conversationPlan.conversationId } : {};
    return responseMode === "compat"
      ? { ...toCompatChatResponse(honestDelivered, finalGate, delivered.pendingApprovals, automation.builderHint), ...conversationField }
      : { ...toExtendedChatResponse(honestDelivered, finalGate, delivered.pendingApprovals, automation.builderHint), ...conversationField };
  } catch (error) {
    return sendAgentError(reply, error, responseMode);
  }
}

async function withApprovalNotice(
  result: AgentRunResult,
  wiring: ChatWriteApprovalWiring,
  userId?: string
): Promise<{ readonly result: AgentRunResult; readonly pendingApprovals: readonly PersistedApproval[] }> {
  const pendingApprovals = await wiring.persist(userId);
  const output = `${result.response.output}${formatApprovalNotice(wiring.drafts)}`;
  return { pendingApprovals, result: { ...result, response: { ...result.response, output } } };
}

function chatUserId(runInput: AgentRunInput, authUserId?: string): string | undefined {
  const fromMetadata = runInput.metadata?.["userId"];
  return typeof fromMetadata === "string" ? fromMetadata : authUserId;
}

/** A CLEAN-history retry payload — system message(s) + only the latest user
 *  turn — so a poisoned prior "done" claim in history can't make the model
 *  skip the tool again (mirrors the CLI's `runResistingFalseDone` retry). */
function cleanRetryMessages(messages: AgentRunInput["messages"]): AgentRunInput["messages"] {
  const systemMessages = messages.filter((message) => message.role === "system");
  const lastUser = [...messages].reverse().find((message) => message.role === "user");
  return lastUser ? [...systemMessages, lastUser] : messages;
}

/** The user's own last turn — the question the grounding gate scores the answer
 *  against (a chat body always resolves to at least one user message). */
function lastUserQuestion(messages: AgentRunInput["messages"]): string {
  for (let i = messages.length - 1; i >= 0; i--) {
    const message = messages[i];
    if (message?.role === "user" && typeof message.content === "string") {
      return message.content;
    }
  }
  return "";
}

export async function runChatStream(
  body: unknown,
  reply: {
    header(name: string, value: string): unknown;
    status(statusCode: number): { send(payload: unknown): void };
    send(payload: unknown): unknown;
  },
  options: ServerOptions,
  responseMode: "extended" | "compat",
  authUserId?: string
) {
  if (!options.agentRuntime) {
    return reply.status(503).send({
      code: "AGENT_RUNTIME_UNAVAILABLE",
      message: "Agent runtime is not configured"
    });
  }

  const parsed = parseAgentRunInput(body, options.defaultModel ?? "default", authUserId);

  if (!parsed.ok) {
    return reply.status(400).send(parsed.error);
  }

  const conversationPlan = await resolveChatConversationPlan(body, options);
  const baseInputRaw = await applyWebSearchPolicy(parsed.value, body, options);
  const baseInput = conversationPlan
    ? { ...baseInputRaw, messages: withPriorConversationTurns(baseInputRaw.messages, conversationPlan.priorMessages) }
    : baseInputRaw;
  const writeWiring = chatWriteApprovalWiring(options);
  const runInput = writeWiring
    ? {
        ...baseInput,
        toolApprovalGate: writeWiring.toolApprovalGate,
        toolExposureAuthority: writeWiring.toolExposureAuthority
      }
    : baseInput;

  reply.header("content-type", "text/event-stream; charset=utf-8");
  reply.header("cache-control", "no-cache");
  // streamRawDeltas satisfies the AgentRunInput contract HERE: toSseStream
  // passes every delta through the live citation filter, and the grounding
  // frame it emits post-stream is the authoritative gated answer.
  return reply.send(
    Readable.from(
      toSseStream(options.agentRuntime.stream({ ...runInput, streamRawDeltas: true }), responseMode, {
        question: lastUserQuestion(runInput.messages),
        ...(conversationPlan
          ? { conversation: { conversationId: conversationPlan.conversationId, persistTurn: conversationPlan.persistTurn } }
          : {}),
        ...(writeWiring
          ? { chatWrite: { drafts: writeWiring.drafts, persist: writeWiring.persist, userId: chatUserId(runInput, authUserId) } }
          : {})
      })
    )
  );
}

export async function runMultipartChat(
  body: unknown,
  reply: { status(statusCode: number): { send(payload: unknown): void } },
  options: ServerOptions,
  authUserId?: string
) {
  const parsed = parseMultipartChatBody(body);

  if (!parsed.ok) {
    return reply.status(400).send(parsed.error);
  }

  return runChat(parsed.value, reply, options, "compat", authUserId);
}

/**
 * Applies web search policy to the run input before it reaches the agent
 * runtime. Reads the per-request override from `body.metadata.tools.web_search`
 * and the server-side settings from `options.runtimeSettings` (with TTL cache).
 * Defaults to enabled=true, maxUses=5 when no settings store is wired.
 */
async function applyWebSearchPolicy(
  runInput: AgentRunInput,
  body: unknown,
  options: ServerOptions
): Promise<AgentRunInput> {
  const override = extractWebSearchOverride(body);
  const runtimeSettings = options.runtimeSettings;
  const webSearchSettings = runtimeSettings
    ? {
      enabled: await runtimeSettings.getBoolean("webSearch.enabled", true),
      maxUses: await runtimeSettings.getNumber("webSearch.maxUses", 5)
    }
    : { enabled: true, maxUses: 5 };
  const modelRequest = {
    messages: runInput.messages,
    metadata: runInput.metadata,
    model: runInput.model ?? "default"
  };
  const wrapped = buildModelRequestWithWebSearch(modelRequest, {
    env: process.env as Record<string, string | undefined>,
    override,
    settings: { webSearch: webSearchSettings }
  });
  return { ...runInput, metadata: wrapped.metadata };
}


// ---------------------------------------------------------------------------
// Chat response builders — implementation in `./server-chat-response-builders.js`.
// Re-exported here so the existing import sites keep working.
// ---------------------------------------------------------------------------
import {
  toCompatChatResponse,
  toExtendedChatResponse
} from "./server-chat-response-builders.js";

export {
  toAdminRunSummary
} from "./server-chat-response-builders.js";

// ---------------------------------------------------------------------------
// Agent error handling — implementation in `./server-agent-error.js`.
// Re-exported here so the existing import sites keep working.
// ---------------------------------------------------------------------------
import { sendAgentError } from "./server-agent-error.js";

export { unwrapErrorMessage } from "./server-agent-error.js";

// ---------------------------------------------------------------------------
// Multipart + SSE — implementation in `./server-multipart-sse.js`.
// Re-exported here so the existing import sites keep working.
// ---------------------------------------------------------------------------
import { toSseStream } from "./server-multipart-sse.js";

export { parseMultipartBody } from "./server-multipart-sse.js";

// ---------------------------------------------------------------------------
// HTTP plumbing — implementation in `./server-http-plumbing.js`. Re-exported
// here so the existing import sites across the API package keep working.
// ---------------------------------------------------------------------------
export {
  applyCompatWebContractHeaders,
  applyCorsHeaders,
  createOpenApiDocument,
  headerValue,
  isPublicRequest,
  routeMethods,
  supportedCompatApiVersions,
  toSpringPathTemplate
} from "./server-http-plumbing.js";

export {
  attachAuthIdentity,
  getAuthIdentity,
  requireAuthenticated,
  toLoginResponse
} from "./server-auth-helpers.js";

function extractWebSearchOverride(body: unknown): boolean | undefined {
  if (!isRecord(body)) return undefined;
  const meta = body.metadata;
  if (!isRecord(meta)) return undefined;
  const tools = meta.tools;
  if (!isRecord(tools)) return undefined;
  const flag = tools.web_search;
  return typeof flag === "boolean" ? flag : undefined;
}

// `isRecord` / `parseResponseLocales` were re-exported from here before the
// parser split; routes-agent-tools.ts still imports them through this hub.
export { isRecord, parseResponseLocales } from "./server-input-utils.js";
