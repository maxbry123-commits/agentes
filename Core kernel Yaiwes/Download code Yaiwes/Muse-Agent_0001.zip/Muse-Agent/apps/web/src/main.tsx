import { StrictMode } from "react";
import { createRoot } from "react-dom/client";

import { App } from "./app/App.js";

import "./theme.css";

createRoot(document.getElementById("root") as HTMLElement).render(
  <StrictMode>
    <App />
  </StrictMode>
);
