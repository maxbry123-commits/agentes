import { ToolOutputSanitizer } from "@muse/policy";
import { errorMessage } from "@muse/shared";
import { isCancellationLikeError, runWithRetryBudget } from "@muse/resilience";

import type {
  ToolCallRequest,
  ToolExecutionResult,
  ToolExecutionValue,
  ToolIdempotencyStore,
  ToolRegistry
} from "./index.js";

/**
 * `ToolExecutor` plus its two private helpers, lifted from
 * `packages/tools/src/index.ts` so the tool-execution loop sits in
 * one cohesive module: registry lookup, idempotency-store check,
 * sanitiser pass, error wrapping. Re-exported from `index.ts` so
 * the `@muse/tools` barrel and the 4 import sites
 * (`packages/tools/test/tools.test.ts`,
 * `packages/agent-core/src/index.ts:115,193,295,333`) stay
 * byte-identical without import-site edits.
 */

export class ToolExecutor {
  private readonly idempotencyStore?: ToolIdempotencyStore;
  private readonly inFlightIdempotentExecutions = new Map<string, Promise<ToolExecutionResult>>();
  private readonly registry: ToolRegistry;
  private readonly sanitizer: ToolOutputSanitizer;

  constructor(options: {
    readonly idempotencyStore?: ToolIdempotencyStore;
    readonly registry: ToolRegistry;
    readonly sanitizer?: ToolOutputSanitizer;
  }) {
    this.idempotencyStore = options.idempotencyStore;
    this.registry = options.registry;
    this.sanitizer = options.sanitizer ?? new ToolOutputSanitizer();
  }

  async execute(request: ToolCallRequest): Promise<ToolExecutionResult> {
    const tool = this.registry.get(request.name);

    if (!tool) {
      const suggestion = nearestToolName(request.name, this.registry.list().map((registered) => registered.definition.name));
      return this.failed(
        request,
        `Error: tool not found: ${request.name}${suggestion ? `. Did you mean '${suggestion}'? Call that exact registered name.` : ""}`
      );
    }

    const idempotencyKey = readIdempotencyKey(request);

    const existing = idempotencyKey ? this.idempotencyStore?.get(idempotencyKey) : undefined;
    if (existing) {
      return { ...existing, id: request.id };
    }

    if (idempotencyKey) {
      const inFlight = this.inFlightIdempotentExecutions.get(idempotencyKey);
      if (inFlight) {
        return { ...(await inFlight), id: request.id };
      }

      // Publish ownership before invoking the tool. An async function executes
      // synchronously until its first `await`, so calling `executeResolvedTool`
      // directly would leave a re-entrant tool invocation a brief duplicate-run
      // window.
      const execution = Promise.resolve().then(() => this.executeResolvedTool(request, tool, idempotencyKey));
      this.inFlightIdempotentExecutions.set(idempotencyKey, execution);
      try {
        return await execution;
      } finally {
        this.inFlightIdempotentExecutions.delete(idempotencyKey);
      }
    }

    return this.executeResolvedTool(request, tool);
  }

  private async executeResolvedTool(
    request: ToolCallRequest,
    tool: NonNullable<ReturnType<ToolRegistry["get"]>>,
    idempotencyKey?: string
  ): Promise<ToolExecutionResult> {
    try {
      const raw = await runWithRetryBudget(request.retryBudget, () => tool.execute(request.arguments, request.context));
      let effectVerification: ToolExecutionResult["effectVerification"];
      if (tool.verifyEffect) {
        try {
          effectVerification = await tool.verifyEffect(request.arguments, raw, request.context);
        } catch (error) {
          if (isCancellationLikeError(error)) {
            // Execution already returned, so the effect may have landed even
            // though its read-back was cancelled. Keep cancellation terminal,
            // but bind an unknown-effect receipt to the idempotency key before
            // rethrowing so a resumed caller cannot execute it twice.
            if (idempotencyKey) {
              this.idempotencyStore?.set(idempotencyKey, {
                effectVerification: {
                  reason: "post-condition verification cancelled after tool execution; reconcile the exact effect before retry",
                  status: "unverified"
                },
                error: "TOOL_EFFECT_UNVERIFIED: post-condition verification cancelled after tool execution",
                id: request.id,
                name: request.name,
                output: "Error: tool effect unverified — verification cancelled after execution",
                status: "failed"
              });
            }
            throw error;
          }
          effectVerification = {
            reason: errorMessage(error, "post-condition verifier failed"),
            status: "unverified"
          };
        }
        if (effectVerification.status !== "verified") {
          const reason = effectVerification.reason ?? "tool post-condition could not be verified";
          const result = {
            effectVerification,
            error: `TOOL_EFFECT_UNVERIFIED: ${reason}`,
            id: request.id,
            name: request.name,
            output: `Error: tool effect unverified — ${reason}`,
            status: "failed"
          } satisfies ToolExecutionResult;
          // An idempotent effect may already have happened. Preserve the
          // unverified receipt so the same key cannot execute it twice.
          if (idempotencyKey) {
            this.idempotencyStore?.set(idempotencyKey, result);
          }
          return result;
        }
      }
      const output = stringifyToolOutput(raw);
      const sanitized = this.sanitizer.sanitize(request.name, output);
      const result = {
        ...(effectVerification ? { effectVerification } : {}),
        id: request.id,
        name: request.name,
        output: sanitized.content,
        sanitized,
        status: "completed"
      } satisfies ToolExecutionResult;

      if (idempotencyKey) {
        this.idempotencyStore?.set(idempotencyKey, result);
      }

      return result;
    } catch (error) {
      // Cancellation is a terminal run-state transition, not a tool observation.
      // Converting it to a failed result would let the model loop continue after
      // its caller has cancelled the turn.
      if (isCancellationLikeError(error)) {
        throw error;
      }
      const message = errorMessage(error, "unknown tool failure");
      return this.failed(request, `Error: ${message}`);
    }
  }

  private failed(request: ToolCallRequest, error: string): ToolExecutionResult {
    // Turn a raw failure into a guided hint so the model's bounded retry is
    // informed, not blind (Repairing Tool Calls via Reflection, arXiv:2510.17874).
    const hint = toolErrorHint(error);
    return {
      error,
      id: request.id,
      name: request.name,
      output: hint ? `${error}\n(hint: ${hint})` : error,
      status: "failed"
    };
  }
}

/**
 * When the model calls a name that isn't available (a small model commonly
 * HALLUCINATES an intuitive name — `node_run` for the real `run_command`), name
 * the closest available tool so the next turn can call it instead of guessing
 * blindly. Deterministic: ranks by shared snake/dot-case token overlap, requires
 * ≥1 shared token (so an unrelated miss gets NO misleading suggestion). Takes the
 * candidate NAMES (not MuseTool[]) so BOTH the executor's not-registered path AND
 * the AgentRuntime not-EXPOSED gate (which only has the active ModelTool names)
 * can share one suggester.
 */
export function nearestToolName(requested: string, names: readonly string[]): string | undefined {
  const tokenize = (name: string): Set<string> =>
    new Set(name.toLowerCase().split(/[^a-z0-9]+/u).filter((part) => part.length > 0));
  const wanted = tokenize(requested);
  if (wanted.size === 0) {
    return undefined;
  }
  let best: { name: string; score: number } | undefined;
  for (const name of names) {
    let shared = 0;
    for (const token of tokenize(name)) {
      if (wanted.has(token)) {
        shared += 1;
      }
    }
    if (shared > 0 && (!best || shared > best.score)) {
      best = { name, score: shared };
    }
  }
  return best?.name;
}

/**
 * Map a tool failure to an actionable retry hint, or undefined when none fits.
 * Deterministic (no model): auth failures won't recover on retry, transient /
 * network / rate-limit may, a not-found needs the identifier rechecked.
 */
export function toolErrorHint(error: string): string | undefined {
  const e = error.toLowerCase();
  if (/\b(401|403)\b|unauthor|forbidden|invalid (api )?key|auth\w*\s*error|auth(entication)?\s+(failed|rejected)|(token|session|credential|key)\s*(is\s+)?expired|expired\s+(token|session|credential)|re-?auth/u.test(e)) {
    return "this looks like an auth failure — retrying won't help; tell the user to re-authenticate.";
  }
  if (/\b(429|502|503|504)\b|timeout|timed out|econnrefused|enotfound|etimedout|network|fetch failed|rate.?limit|temporarily unavailable/u.test(e)) {
    return "this looks transient (network/rate-limit) — you may retry once, otherwise tell the user the service is briefly unavailable.";
  }
  if (/\b404\b|not found|no such|does not exist|unknown (id|entity|resource)/u.test(e)) {
    return "the target wasn't found — re-check the identifier/argument before retrying.";
  }
  return undefined;
}

function readIdempotencyKey(request: ToolCallRequest): string | undefined {
  const key = request.arguments.idempotencyKey ?? request.arguments.idempotency_key;
  return typeof key === "string" && key.trim().length > 0
    ? `${request.context.runId}:${request.name}:${key.trim()}`
    : undefined;
}

function stringifyToolOutput(value: ToolExecutionValue): string {
  if (typeof value === "string") {
    return value;
  }

  return JSON.stringify(value, null, 2);
}
