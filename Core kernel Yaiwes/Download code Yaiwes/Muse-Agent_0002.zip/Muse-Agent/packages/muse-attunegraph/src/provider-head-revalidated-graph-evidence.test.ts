import {
  createLocalAttunementSnapshotProviderForTesting
} from "@muse/attunement/testing";
import { parseAttunementState } from "@muse/attunement/state-validation";
import { describe, expect, it, vi } from "vitest";

import { canonicalizeImmutableEnvelope } from "@attunegraph/core/extension-kit";
import {
  ProviderHeadRevalidatedGraphEvidenceError,
  compileHeadRevalidatedProviderBoundGraphEvidence,
  isProcessMintedProviderHeadRevalidatedGraphEvidence,
  verifyProviderHeadRevalidatedGraphBindingReceipt
} from "./provider-head-revalidated-graph-evidence.js";

vi.mock("@muse/attunement/continuity-snapshots", async () =>
  import("@muse/attunement/continuity-snapshots")
);

const SOURCE_ID = "provider-head-graph-test";
const THREAD_ID = "thread_provider_head_graph";
const SUBJECT_AT = "2026-07-30T00:00:00.000Z";
const RECEIPT_SPEC = Object.freeze({
  hashDomain:
    "muse.attunegraph.provider-head-revalidated-graph-evidence-receipt.v1",
  idField: "receiptId",
  idPrefix: "muse-attunegraph-provider-head-revalidated-graph-evidence:sha256:"
} as const);
const OMITTED_DIGEST =
  `muse-attunegraph-provider-bound-omitted-assertion-ids:sha256:${"a".repeat(64)}`;

function rehashWithNominations(
  receipt: unknown,
  nominations: Readonly<{
    readonly core: number;
    readonly change: number;
    readonly support: number;
    readonly omitted: number;
    readonly omittedAssertionIdsDigest: string | null;
  }>
): unknown {
  const body = JSON.parse(JSON.stringify(receipt)) as Record<string, unknown>;
  delete body.receiptId;
  body.nominations = nominations;
  const coverage = body.coverage as {
    reasons: string[];
  };
  coverage.reasons = coverage.reasons.filter(
    (reason) => reason !== "nomination-capacity-bounded"
  );
  if (nominations.omitted > 0) {
    coverage.reasons.splice(
      coverage.reasons.indexOf("graph-settlement-partial"),
      0,
      "nomination-capacity-bounded"
    );
  }
  return JSON.parse(JSON.stringify(
    canonicalizeImmutableEnvelope(
      body,
      "external-mutable",
      RECEIPT_SPEC
    ).envelope
  ));
}

function state(title = "Private head graph canary") {
  return parseAttunementState({
    deliveries: [],
    interactionReceipts: [],
    nextPolicyVersion: 1,
    resetReceipts: [],
    schemaVersion: 11,
    threads: [{
      createdAt: "2026-07-29T23:00:00.000Z",
      id: THREAD_ID,
      kind: "work",
      links: [],
      policy: {
        detail: "compact",
        nextStep: "direct",
        suppression: "none",
        version: 0
      },
      title
    }],
    undoResetReceipts: []
  });
}

async function fixture(options: {
  readonly changed?: boolean;
  readonly headUnavailable?: boolean;
  readonly spanMs?: number;
  readonly subjectUnavailable?: boolean;
}) {
  let clocks = 0;
  let reads = 0;
  const provider = createLocalAttunementSnapshotProviderForTesting(
    {
      attunementFile: "/configured/attunement.json",
      sourceId: SOURCE_ID
    },
    {
      readState: async () => {
        const readIndex = reads++;
        if (
          (options.subjectUnavailable && readIndex === 0)
          || (options.headUnavailable && readIndex > 0)
        ) {
          return { status: "missing" as const };
        }
        return {
          state: state(options.changed && readIndex > 0
            ? "Changed title"
            : "Private head graph canary"),
          status: "available" as const
        };
      },
      clock: () => {
        const at = clocks++ === 0
          ? SUBJECT_AT
          : new Date(
            Date.parse(SUBJECT_AT) + (options.spanMs ?? 25)
          ).toISOString();
        return new Date(at);
      }
    }
  );
  return {
    provider,
    scope: { sourceId: SOURCE_ID, threadId: THREAD_ID }
  };
}

function captureObservableObjectGraph(root: object) {
  const seen = new Set<object>();
  const pending = [root];
  const records: {
    readonly descriptors: readonly (
      readonly [PropertyKey, PropertyDescriptor]
    )[];
    readonly frozen: boolean;
    readonly object: object;
    readonly prototype: object | null;
  }[] = [];
  while (pending.length > 0) {
    const object = pending.pop()!;
    if (seen.has(object)) continue;
    seen.add(object);
    const descriptors = Reflect.ownKeys(object).map((key) => {
      const descriptor = Reflect.getOwnPropertyDescriptor(object, key)!;
      if (
        "value" in descriptor
        && descriptor.value !== null
        && (
          typeof descriptor.value === "object"
          || typeof descriptor.value === "function"
        )
      ) {
        pending.push(descriptor.value as object);
      }
      return [key, descriptor] as const;
    });
    records.push({
      descriptors,
      frozen: Object.isFrozen(object),
      object,
      prototype: Reflect.getPrototypeOf(object)
    });
  }
  return records;
}

function expectObservableObjectGraphUnchanged(
  records: ReturnType<typeof captureObservableObjectGraph>
): void {
  for (const record of records) {
    expect(Reflect.getPrototypeOf(record.object)).toBe(record.prototype);
    expect(Object.isFrozen(record.object)).toBe(record.frozen);
    expect(Reflect.ownKeys(record.object)).toEqual(
      record.descriptors.map(([key]) => key)
    );
    for (const [key, before] of record.descriptors) {
      const after = Reflect.getOwnPropertyDescriptor(record.object, key);
      expect(after?.configurable).toBe(before.configurable);
      expect(after?.enumerable).toBe(before.enumerable);
      if ("value" in before) {
        expect(after && "value" in after ? after.value : undefined)
          .toBe(before.value);
        expect(after && "writable" in after ? after.writable : undefined)
          .toBe(before.writable);
      } else {
        expect(after && "get" in after ? after.get : undefined)
          .toBe(before.get);
        expect(after && "set" in after ? after.set : undefined)
          .toBe(before.set);
      }
    }
  }
}

describe("provider head-revalidated Graph evidence", () => {
  it("recognizes all five exact final Provider results from this module instance", async () => {
    const sources = await Promise.all([
      fixture({}),
      fixture({ changed: true }),
      fixture({ spanMs: 26 }),
      fixture({ subjectUnavailable: true }),
      fixture({ headUnavailable: true })
    ]);
    const outcomes = await Promise.all(sources.map(async (source) => {
      const artifact = await source.provider.captureHeadRevalidation(
        source.scope,
        { maxCaptureSpanMs: 25 }
      );
      return compileHeadRevalidatedProviderBoundGraphEvidence(artifact);
    }));

    expect(outcomes.map((result) => [
      result.status,
      result.stage,
      isProcessMintedProviderHeadRevalidatedGraphEvidence(result)
    ])).toEqual([
      ["partial", "graph-evidence", true],
      ["stale", "revalidation", true],
      ["stale", "revalidation", true],
      ["abstained", "provider", true],
      ["abstained", "revalidation", true]
    ]);
  });

  it("rejects copies, wrappers, and proxies without reflection", async () => {
    const source = await fixture({});
    const artifact = await source.provider.captureHeadRevalidation(
      source.scope,
      { maxCaptureSpanMs: 25 }
    );
    const result =
      await compileHeadRevalidatedProviderBoundGraphEvidence(artifact);
    const trapCounts = {
      get: 0,
      getOwnPropertyDescriptor: 0,
      getPrototypeOf: 0,
      ownKeys: 0
    };
    const hostile = new Proxy(result, {
      get() {
        trapCounts.get++;
        throw new Error("get trap must not run");
      },
      getOwnPropertyDescriptor() {
        trapCounts.getOwnPropertyDescriptor++;
        throw new Error("descriptor trap must not run");
      },
      getPrototypeOf() {
        trapCounts.getPrototypeOf++;
        throw new Error("prototype trap must not run");
      },
      ownKeys() {
        trapCounts.ownKeys++;
        throw new Error("ownKeys trap must not run");
      }
    });
    const revoked = Proxy.revocable(result, {});
    revoked.revoke();
    const fabricated = {
      receipt: result.receipt,
      stage: result.stage,
      status: result.status
    };
    const candidates = [
      null,
      undefined,
      false,
      0,
      "",
      Symbol("forgery"),
      { ...result },
      JSON.parse(JSON.stringify(result)),
      structuredClone(result),
      Object.assign(Object.create(null) as object, result),
      Object.create(result) as object,
      fabricated,
      new Proxy(result, {}),
      hostile,
      revoked.proxy
    ];

    expect(candidates.map((candidate) => {
      expect(() =>
        isProcessMintedProviderHeadRevalidatedGraphEvidence(candidate)
      ).not.toThrow();
      return isProcessMintedProviderHeadRevalidatedGraphEvidence(candidate);
    })).toEqual(candidates.map(() => false));
    expect(trapCounts).toEqual({
      get: 0,
      getOwnPropertyDescriptor: 0,
      getPrototypeOf: 0,
      ownKeys: 0
    });
  });

  it("preserves every observable result object property and identity", async () => {
    const source = await fixture({});
    const artifact = await source.provider.captureHeadRevalidation(
      source.scope,
      { maxCaptureSpanMs: 25 }
    );
    const result =
      await compileHeadRevalidatedProviderBoundGraphEvidence(artifact);
    const json = JSON.stringify(result);
    const receiptId = result.receipt.receiptId;
    const graph = captureObservableObjectGraph(result);

    expect(isProcessMintedProviderHeadRevalidatedGraphEvidence(result))
      .toBe(true);
    expect(JSON.stringify(result)).toBe(json);
    expect(result.receipt.receiptId).toBe(receiptId);
    expectObservableObjectGraphUnchanged(graph);
  });

  it("resists post-import WeakSet add and has poisoning", async () => {
    const source = await fixture({});
    const artifact = await source.provider.captureHeadRevalidation(
      source.scope,
      { maxCaptureSpanMs: 25 }
    );
    const originalAdd = WeakSet.prototype.add;
    const originalHas = WeakSet.prototype.has;
    const forgery = {};
    let forgeryAccepted: boolean | undefined;
    let exactAccepted: boolean | undefined;
    try {
      WeakSet.prototype.add = (function poisonedAdd(
        this: WeakSet<object>,
        value: object
      ): WeakSet<object> {
        const candidate = value as {
          readonly receipt?: { readonly receiptVersion?: unknown };
          readonly revalidationReceipt?: unknown;
        };
        if (
          candidate.receipt?.receiptVersion
            === "muse.provider-head-revalidated-graph-evidence-receipt.v1"
          && candidate.revalidationReceipt !== undefined
        ) {
          return this;
        }
        return originalAdd.call(this, value);
      }) as typeof WeakSet.prototype.add;
      WeakSet.prototype.has = (function poisonedHas(
        this: WeakSet<object>,
        value: object
      ): boolean {
        return value === forgery || originalHas.call(this, value);
      }) as typeof WeakSet.prototype.has;
      forgeryAccepted =
        isProcessMintedProviderHeadRevalidatedGraphEvidence(forgery);
      const result =
        await compileHeadRevalidatedProviderBoundGraphEvidence(artifact);
      exactAccepted =
        isProcessMintedProviderHeadRevalidatedGraphEvidence(result);
    } finally {
      WeakSet.prototype.add = originalAdd;
      WeakSet.prototype.has = originalHas;
    }

    expect(forgeryAccepted).toBe(false);
    expect(exactAccepted).toBe(true);
    expect(WeakSet.prototype.add).toBe(originalAdd);
    expect(WeakSet.prototype.has).toBe(originalHas);
  });

  it("settles equal endpoints as partial with exact narrow semantics", async () => {
    const source = await fixture({});
    const artifact = await source.provider.captureHeadRevalidation(
      source.scope,
      { maxCaptureSpanMs: 25 }
    );
    const result =
      await compileHeadRevalidatedProviderBoundGraphEvidence(artifact);
    expect(result.status).toBe("partial");
    expect(result.stage).toBe("graph-evidence");
    if (result.status !== "partial") throw new Error("partial required");
    expect(result.graphEvidence.receipt.status).toBe("partial");
    const decision = result.graphEvidence.decisionEvidence;
    if (decision === undefined) throw new Error("Decision Query evidence required");
    expect(decision.receipt).toMatchObject({
      status: "bound",
      graphEvidenceReceiptId: result.graphEvidence.receipt.receiptId,
      sourceObservationReceiptId: result.graphObservationReceipt.receiptId,
      decisionQueryReceiptId: decision.decisionQuery.receipt.receiptId,
      use: "evidence-only",
      coverage: {
        coreAssertionWitnessed: true,
        canGrantActionAuthority: false,
        authorityEvaluation: "not-performed",
        conflictClosure: "not-performed"
      }
    });
    expect(result.graphEvidence.receipt.coverage.reasons.slice(0, 6)).toEqual([
      "provider-head-revalidated-observation-integrity-only",
      "fresh-at-assessment-only",
      "source-authority-unverified",
      "bounded-activation-only",
      "legacy-payload-budget-only",
      "non-authoritative-compatibility-scope"
    ]);
    expect(result.graphEvidence.legacyCompilation.receipt.coverage.reasons)
      .toEqual([
        "provider-head-revalidation-snapshot-integrity-only",
        "fresh-at-assessment-only",
        "bounded-result-only"
      ]);
    const legacy = result.graphEvidence.legacyCompilation;
    expect(legacy.frontier?.order.coverage.reasons).toEqual([
      "candidate-pool-only",
      "lane-semantics-caller-declared",
      "not-budget-settled"
    ]);
    expect(legacy.frontier?.receipt.coverage.reasons).toEqual([
      "bounded-witness-pool-only",
      "provider-head-revalidation-snapshot-integrity-only",
      "fresh-at-assessment-only",
      "source-authority-not-independently-verified",
      "focus-predicate-lane-mapping-v1"
    ]);
    expect(legacy.settlement?.status).toBe("partial");
    if (legacy.settlement?.status !== "partial") {
      throw new Error("fresh settlement must be partial");
    }
    expect(legacy.settlement.completeness).toMatchObject({
      canAssertAbsenceWithinSnapshot: false,
      canAssertCurrentWorldAbsence: false
    });
    expect(legacy.settlement.documents[0]?.authority.freshness).toBe(
      "provider-head-revalidation-receipt-integrity-only"
    );
    expect(result.receipt.providerFreshness).toEqual({
      status: "fresh-at-assessment",
      reason: "head-state-matched-within-bound"
    });
    expect(result.receipt.coverage.reasons).toEqual([
      "single-local-store",
      "two-endpoint-provider-revalidation",
      "fresh-at-assessment-only",
      "source-authority-unverified",
      "graph-settlement-partial"
    ]);
    expect(result.receipt).toMatchObject({
      canAssertFreshAtAssessment: true,
      canAssertAbsenceWithinSnapshot: false,
      canAssertCurrentWorldAbsence: false,
      canAssertDurableProviderAuthority: false
    });
    expect(verifyProviderHeadRevalidatedGraphBindingReceipt(
      JSON.parse(JSON.stringify(result.receipt))
    )).toEqual(result.receipt);
  });

  it("does not compile changed or span-exceeded endpoints into Graph fields", async () => {
    const changedSource = await fixture({ changed: true });
    const changedArtifact =
      await changedSource.provider.captureHeadRevalidation(
        changedSource.scope,
        { maxCaptureSpanMs: 25 }
      );
    const changed =
      await compileHeadRevalidatedProviderBoundGraphEvidence(changedArtifact);
    expect(changed.status).toBe("stale");
    expect(changed.receipt.providerFreshness).toEqual({
      status: "not-fresh",
      reason: "head-state-changed"
    });
    expect(changed).not.toHaveProperty("graphEvidence");
    expect(changed.receipt).not.toHaveProperty("snapshot");
    expect(changed.receipt).not.toHaveProperty("declaredFreshness");
    expect(verifyProviderHeadRevalidatedGraphBindingReceipt(
      JSON.parse(JSON.stringify(changed.receipt))
    )).toEqual(changed.receipt);

    const spanSource = await fixture({ spanMs: 26 });
    const spanArtifact = await spanSource.provider.captureHeadRevalidation(
      spanSource.scope,
      { maxCaptureSpanMs: 25 }
    );
    const span =
      await compileHeadRevalidatedProviderBoundGraphEvidence(spanArtifact);
    expect(span.status).toBe("stale");
    expect(span.receipt.providerFreshness.reason).toBe(
      "capture-span-exceeded"
    );
    expect(span).not.toHaveProperty("graphEvidence");
    expect(verifyProviderHeadRevalidatedGraphBindingReceipt(
      JSON.parse(JSON.stringify(span.receipt))
    )).toEqual(span.receipt);
  });

  it("rejects serialized revalidation reconstruction", async () => {
    const source = await fixture({});
    const artifact = await source.provider.captureHeadRevalidation(
      source.scope,
      { maxCaptureSpanMs: 25 }
    );
    await expect(
      compileHeadRevalidatedProviderBoundGraphEvidence(
        JSON.parse(JSON.stringify(artifact))
      )
    ).rejects.toSatisfy((error: unknown) => {
      expect(error).toBeInstanceOf(
        ProviderHeadRevalidatedGraphEvidenceError
      );
      expect((error as ProviderHeadRevalidatedGraphEvidenceError).code)
        .toBe("INVALID_REVALIDATION");
      return true;
    });
  });

  it("keeps one-read provider abstention mint wording truthful", async () => {
    const source = await fixture({ subjectUnavailable: true });
    const artifact = await source.provider.captureHeadRevalidation(
      source.scope,
      { maxCaptureSpanMs: 25 }
    );
    const result =
      await compileHeadRevalidatedProviderBoundGraphEvidence(artifact);
    expect(artifact.receipt.mintVerification).toBe(
      "provider-owned-revalidation-artifact-verified-in-composing-process"
    );
    expect(result.status).toBe("abstained");
    expect(result.stage).toBe("provider");
    expect(result.receipt.mintVerification).toBe(
      "provider-owned-revalidation-artifact-verified-in-composing-process"
    );
    expect(verifyProviderHeadRevalidatedGraphBindingReceipt(
      JSON.parse(JSON.stringify(result.receipt))
    ).mintVerification).toBe(
      "provider-owned-revalidation-artifact-verified-in-composing-process"
    );
  });

  it("rejects the hash-valid invented provider authority and reason fixture", async () => {
    const source = await fixture({ changed: true });
    const artifact = await source.provider.captureHeadRevalidation(
      source.scope,
      { maxCaptureSpanMs: 25 }
    );
    const result =
      await compileHeadRevalidatedProviderBoundGraphEvidence(artifact);
    const attacker = JSON.parse(
      JSON.stringify(result.receipt)
    ) as Record<string, unknown>;
    delete attacker.receiptId;
    attacker.providerId = "attacker.provider";
    attacker.providerFreshness = {
      status: "not-fresh",
      reason: "invented-reason"
    };
    attacker.coverage = {
      status: "stale",
      reasons: ["invented-authority"]
    };
    const hashValid = JSON.parse(JSON.stringify(
      canonicalizeImmutableEnvelope(
        attacker,
        "external-mutable",
        RECEIPT_SPEC
      ).envelope
    ));

    expect(() =>
      verifyProviderHeadRevalidatedGraphBindingReceipt(hashValid)
    ).toThrowError(ProviderHeadRevalidatedGraphEvidenceError);
  });

  it("rejects a hash-valid thread seed that was not derived from the provider scope", async () => {
    const source = await fixture({});
    const artifact = await source.provider.captureHeadRevalidation(
      source.scope,
      { maxCaptureSpanMs: 25 }
    );
    const result =
      await compileHeadRevalidatedProviderBoundGraphEvidence(artifact);
    expect(result.status).toBe("partial");

    const attacker = JSON.parse(
      JSON.stringify(result.receipt)
    ) as Record<string, unknown>;
    delete attacker.receiptId;
    const originalSeed = attacker.graphActualSeed as {
      readonly id: string;
      readonly kind: "thread";
    };
    const replacementSuffix = originalSeed.id.endsWith("0") ? "1" : "0";
    attacker.graphActualSeed = {
      id: `${originalSeed.id.slice(0, -1)}${replacementSuffix}`,
      kind: "thread"
    };
    const hashValid = JSON.parse(JSON.stringify(
      canonicalizeImmutableEnvelope(
        attacker,
        "external-mutable",
        RECEIPT_SPEC
      ).envelope
    ));

    expect(() =>
      verifyProviderHeadRevalidatedGraphBindingReceipt(hashValid)
    ).toThrowError(ProviderHeadRevalidatedGraphEvidenceError);
  });

  it("accepts the retained nomination boundary independently of settlement assertions", async () => {
    const source = await fixture({});
    const artifact = await source.provider.captureHeadRevalidation(
      source.scope,
      { maxCaptureSpanMs: 25 }
    );
    const result =
      await compileHeadRevalidatedProviderBoundGraphEvidence(artifact);

    for (const nominations of [
      {
        core: 1,
        change: 32,
        support: 0,
        omitted: 0,
        omittedAssertionIdsDigest: null
      },
      {
        core: 1,
        change: 128,
        support: 127,
        omitted: 0,
        omittedAssertionIdsDigest: null
      },
      {
        core: 1,
        change: 32,
        support: 0,
        omitted: 1,
        omittedAssertionIdsDigest: OMITTED_DIGEST
      }
    ] as const) {
      expect(verifyProviderHeadRevalidatedGraphBindingReceipt(
        rehashWithNominations(result.receipt, nominations)
      ).nominations).toEqual(nominations);
    }
  });

  it("rejects invalid retained counts and omitted digest relationships", async () => {
    const source = await fixture({});
    const artifact = await source.provider.captureHeadRevalidation(
      source.scope,
      { maxCaptureSpanMs: 25 }
    );
    const result =
      await compileHeadRevalidatedProviderBoundGraphEvidence(artifact);
    const invalid = [
      {
        core: 0,
        change: 0,
        support: 0,
        omitted: 0,
        omittedAssertionIdsDigest: null
      },
      {
        core: 1,
        change: 128,
        support: 128,
        omitted: 0,
        omittedAssertionIdsDigest: null
      },
      {
        core: 1,
        change: -1,
        support: 0,
        omitted: 0,
        omittedAssertionIdsDigest: null
      },
      {
        core: 1,
        change: 1.5,
        support: 0,
        omitted: 0,
        omittedAssertionIdsDigest: null
      },
      {
        core: 1,
        change: Number.MAX_SAFE_INTEGER + 1,
        support: 0,
        omitted: 0,
        omittedAssertionIdsDigest: null
      },
      {
        core: 1,
        change: 0,
        support: 0,
        omitted: 0,
        omittedAssertionIdsDigest: OMITTED_DIGEST
      },
      {
        core: 1,
        change: 0,
        support: 0,
        omitted: 1,
        omittedAssertionIdsDigest: null
      },
      {
        core: 1,
        change: 0,
        support: 0,
        omitted: 1,
        omittedAssertionIdsDigest: "invalid-digest"
      }
    ];
    for (const nominations of invalid) {
      expect(() =>
        verifyProviderHeadRevalidatedGraphBindingReceipt(
          rehashWithNominations(result.receipt, nominations)
        )
      ).toThrow();
    }
  });
});
