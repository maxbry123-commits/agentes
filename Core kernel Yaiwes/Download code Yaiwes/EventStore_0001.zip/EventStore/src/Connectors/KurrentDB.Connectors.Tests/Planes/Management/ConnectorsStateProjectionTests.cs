// Copyright (c) Kurrent, Inc and/or licensed to Kurrent, Inc under one or more agreements.
// Kurrent, Inc licenses this file to you under the Kurrent License v1 (see LICENSE.md).

#pragma warning disable EXTEXP0004

using Google.Protobuf;
using Google.Protobuf.WellKnownTypes;
using Kurrent.Surge.Processors;
using KurrentDB.Connectors.Management.Contracts;
using KurrentDB.Connectors.Management.Contracts.Events;
using KurrentDB.Connectors.Management.Contracts.Queries;
using KurrentDB.Connectors.Planes.Management.Data;

namespace KurrentDB.Connectors.Tests.Planes.Management;

public class ConnectorsStateProjectionTests(ITestOutputHelper output, ConnectorsAssemblyFixture fixture) : ConnectorsIntegrationTests(output, fixture) {
    [Fact]
    public Task projection_updates_on_ConnectorCreated() => Fixture.TestWithTimeout(async cancellator => {
        // Arrange
        var connectorId     = Fixture.NewConnectorId();
        var streamId        = Fixture.NewIdentifier();
        var createTimestamp = Fixture.TimeProvider.GetUtcNow().ToTimestamp();
        var projection      = new ConnectorsStateProjection(Fixture.SnapshotProjectionsStore, streamId);

        var cmd = new ConnectorCreated {
            ConnectorId = connectorId,
            Name        = "Logger Sink",
            Settings = {
                { "instanceTypeName", "logger-sink" }
            },
            Timestamp = createTimestamp
        };

        var expectedSnapshot = new ConnectorsSnapshot {
            Connectors = {
                new Connector {
                    ConnectorId        = cmd.ConnectorId,
                    InstanceTypeName   = cmd.Settings["instanceTypeName"],
                    Name               = cmd.Name,
                    State              = ConnectorState.Stopped,
                    CreateTime         = createTimestamp,
                    UpdateTime         = createTimestamp,
                    StateUpdateTime    = createTimestamp,
                    SettingsUpdateTime = createTimestamp,
                    DeleteTime         = null,
                    Position           = null,
                    ErrorDetails       = null,
                    PositionUpdateTime = null,
                    Settings = {
                        { "instanceTypeName", "logger-sink" }
                    }
                }
            }
        };

        // Act
        await projection.ProcessRecord(await RecordContextFor(cmd, cancellator.Token));

        // Assert
        var store = await Fixture.SnapshotProjectionsStore.LoadSnapshot<ConnectorsSnapshot>(streamId);

        store.Snapshot.Connectors.Should().BeEquivalentTo(expectedSnapshot.Connectors);
    });

    [Fact]
    public Task projection_updates_on_ConnectorReconfigured() => Fixture.TestWithTimeout(async cancellator => {
        // Arrange
        var connectorId = Fixture.NewConnectorId();
        var streamId    = Fixture.NewIdentifier();
        var projection  = new ConnectorsStateProjection(Fixture.SnapshotProjectionsStore, streamId);

        var createTimestamp = Fixture.TimeProvider.GetUtcNow().ToTimestamp();

        var createdCommand = new ConnectorCreated {
            ConnectorId = connectorId,
            Name        = "Logger Sink",
            Settings = {
                { "instanceTypeName", "logger-sink" },
                { "logging:enabled", "true" }
            },
            Timestamp = createTimestamp
        };

        var reconfigureTimestamp = Fixture.TimeProvider.GetUtcNow().AddDays(1).ToTimestamp();

        var reconfigureCommand = new ConnectorReconfigured {
            ConnectorId = connectorId,
            Settings = {
                { "logging:enabled", "false" }
            },
            Timestamp = reconfigureTimestamp
        };

        var expectedSnapshot = new ConnectorsSnapshot {
            Connectors = {
                new Connector {
                    ConnectorId        = reconfigureCommand.ConnectorId,
                    InstanceTypeName   = createdCommand.Settings["instanceTypeName"],
                    Name               = createdCommand.Name,
                    State              = ConnectorState.Stopped,
                    CreateTime         = createTimestamp,
                    UpdateTime         = reconfigureTimestamp,
                    SettingsUpdateTime = reconfigureTimestamp,
                    StateUpdateTime    = createTimestamp,
                    DeleteTime         = null,
                    Position           = null,
                    ErrorDetails       = null,
                    PositionUpdateTime = null,
                    Settings = {
                        { "logging:enabled", "false" },
                    }
                }
            }
        };

        // Act
        await projection.ProcessRecord(await RecordContextFor(createdCommand, cancellator.Token));
        Fixture.TimeProvider.Advance(TimeSpan.FromDays(1));
        await projection.ProcessRecord(await RecordContextFor(reconfigureCommand, cancellator.Token));

        // Assert
        var store = await Fixture.SnapshotProjectionsStore.LoadSnapshot<ConnectorsSnapshot>(streamId);
        store.Snapshot.Connectors.Should().BeEquivalentTo(expectedSnapshot.Connectors);
    });

    [Fact]
    public Task projection_updates_on_ConnectorRenamed() => Fixture.TestWithTimeout(async cancellator => {
        // Arrange
        var connectorId = Fixture.NewConnectorId();
        var streamId    = Fixture.NewIdentifier();
        var projection  = new ConnectorsStateProjection(Fixture.SnapshotProjectionsStore, streamId);

        var createTimestamp = Fixture.TimeProvider.GetUtcNow().ToTimestamp();

        var createdCommand = new ConnectorCreated {
            ConnectorId = connectorId,
            Name        = "Logger Sink",
            Settings = {
                { "instanceTypeName", "logger-sink" }
            },
            Timestamp = createTimestamp
        };

        var renameTimestamp = Fixture.TimeProvider.GetUtcNow().AddDays(1).ToTimestamp();

        var renameCommand = new ConnectorRenamed {
            ConnectorId = connectorId,
            Timestamp   = renameTimestamp,
            Name        = "New Logger Sink"
        };

        var expectedSnapshot = new ConnectorsSnapshot {
            Connectors = {
                new Connector {
                    ConnectorId        = renameCommand.ConnectorId,
                    InstanceTypeName   = createdCommand.Settings["instanceTypeName"],
                    Name               = renameCommand.Name,
                    State              = ConnectorState.Stopped,
                    CreateTime         = createTimestamp,
                    UpdateTime         = renameTimestamp,
                    SettingsUpdateTime = createTimestamp,
                    StateUpdateTime    = createTimestamp,
                    DeleteTime         = null,
                    Position           = null,
                    ErrorDetails       = null,
                    PositionUpdateTime = null,
                    Settings = {
                        { "instanceTypeName", createdCommand.Settings["instanceTypeName"] }
                    }
                }
            }
        };

        // Act
        await projection.ProcessRecord(await RecordContextFor(createdCommand, cancellator.Token));
        Fixture.TimeProvider.Advance(TimeSpan.FromDays(1));
        await projection.ProcessRecord(await RecordContextFor(renameCommand, cancellator.Token));

        // Assert
        var store = await Fixture.SnapshotProjectionsStore.LoadSnapshot<ConnectorsSnapshot>(streamId);
        store.Snapshot.Connectors.Should().BeEquivalentTo(expectedSnapshot.Connectors);
    });

    [Fact]
    public Task projection_updates_on_ConnectorActivating() => Fixture.TestWithTimeout(async cancellator => {
        // Arrange
        var connectorId = Fixture.NewConnectorId();
        var streamId    = Fixture.NewIdentifier();
        var projection  = new ConnectorsStateProjection(Fixture.SnapshotProjectionsStore, streamId);

        var createTimestamp = Fixture.TimeProvider.GetUtcNow().ToTimestamp();

        var createdCommand = new ConnectorCreated {
            ConnectorId = connectorId,
            Name        = "Logger Sink",
            Settings = {
                { "instanceTypeName", "logger-sink" }
            },
            Timestamp = createTimestamp
        };

        var activateTimestamp = Fixture.TimeProvider.GetUtcNow().AddDays(1).ToTimestamp();

        var activateCommand = new ConnectorActivating {
            ConnectorId = connectorId,
            Timestamp   = activateTimestamp
        };

        var expectedSnapshot = new ConnectorsSnapshot {
            Connectors = {
                new Connector {
                    ConnectorId        = activateCommand.ConnectorId,
                    InstanceTypeName   = createdCommand.Settings["instanceTypeName"],
                    Name               = createdCommand.Name,
                    State              = ConnectorState.Activating,
                    CreateTime         = createTimestamp,
                    UpdateTime         = activateTimestamp,
                    SettingsUpdateTime = createTimestamp,
                    StateUpdateTime    = activateTimestamp,
                    DeleteTime         = null,
                    Position           = null,
                    ErrorDetails       = null,
                    PositionUpdateTime = null,
                    Settings = {
                        { "instanceTypeName", createdCommand.Settings["instanceTypeName"] }
                    }
                }
            }
        };

        // Act
        await projection.ProcessRecord(await RecordContextFor(createdCommand, cancellator.Token));
        Fixture.TimeProvider.Advance(TimeSpan.FromDays(1));
        await projection.ProcessRecord(await RecordContextFor(activateCommand, cancellator.Token));

        // Assert
        var store = await Fixture.SnapshotProjectionsStore.LoadSnapshot<ConnectorsSnapshot>(streamId);
        store.Snapshot.Connectors.Should().BeEquivalentTo(expectedSnapshot.Connectors);
    });

    [Fact]
    public Task projection_updates_on_ConnectorDeactivating() => Fixture.TestWithTimeout(async cancellator => {
        // Arrange
        var connectorId = Fixture.NewConnectorId();
        var streamId    = Fixture.NewIdentifier();
        var projection  = new ConnectorsStateProjection(Fixture.SnapshotProjectionsStore, streamId);

        var createTimestamp = Fixture.TimeProvider.GetUtcNow().ToTimestamp();

        var createdCommand = new ConnectorCreated {
            ConnectorId = connectorId,
            Name        = "Logger Sink",
            Settings = {
                { "instanceTypeName", "logger-sink" }
            },
            Timestamp = createTimestamp
        };

        var deactivateTimestamp = Fixture.TimeProvider.GetUtcNow().AddDays(1).ToTimestamp();

        var deactivateCommand = new ConnectorDeactivating {
            ConnectorId = connectorId,
            Timestamp   = deactivateTimestamp
        };

        var expectedSnapshot = new ConnectorsSnapshot {
            Connectors = {
                new Connector {
                    ConnectorId        = deactivateCommand.ConnectorId,
                    InstanceTypeName   = createdCommand.Settings["instanceTypeName"],
                    Name               = createdCommand.Name,
                    State              = ConnectorState.Deactivating,
                    CreateTime         = createTimestamp,
                    UpdateTime         = deactivateTimestamp,
                    SettingsUpdateTime = createTimestamp,
                    StateUpdateTime    = deactivateTimestamp,
                    DeleteTime         = null,
                    Position           = null,
                    ErrorDetails       = null,
                    PositionUpdateTime = null,
                    Settings = {
                        { "instanceTypeName", createdCommand.Settings["instanceTypeName"] }
                    }
                }
            }
        };

        // Act
        await projection.ProcessRecord(await RecordContextFor(createdCommand, cancellator.Token));
        Fixture.TimeProvider.Advance(TimeSpan.FromDays(1));
        await projection.ProcessRecord(await RecordContextFor(deactivateCommand, cancellator.Token));

        // Assert
        var store = await Fixture.SnapshotProjectionsStore.LoadSnapshot<ConnectorsSnapshot>(streamId);
        store.Snapshot.Connectors.Should().BeEquivalentTo(expectedSnapshot.Connectors);
    });

    [Fact]
    public Task projection_updates_on_ConnectorRunning() => Fixture.TestWithTimeout(async cancellator => {
        // Arrange
        var connectorId = Fixture.NewConnectorId();
        var streamId    = Fixture.NewIdentifier();
        var projection  = new ConnectorsStateProjection(Fixture.SnapshotProjectionsStore, streamId);

        var createTimestamp = Fixture.TimeProvider.GetUtcNow().ToTimestamp();

        var createdCommand = new ConnectorCreated {
            ConnectorId = connectorId,
            Name        = "Logger Sink",
            Settings = {
                { "instanceTypeName", "logger-sink" }
            },
            Timestamp = createTimestamp
        };

        var runningTimestamp = Fixture.TimeProvider.GetUtcNow().AddDays(1).ToTimestamp();

        var runningCommand = new ConnectorRunning {
            ConnectorId = connectorId,
            Timestamp   = runningTimestamp
        };

        var expectedSnapshot = new ConnectorsSnapshot {
            Connectors = {
                new Connector {
                    ConnectorId        = runningCommand.ConnectorId,
                    InstanceTypeName   = createdCommand.Settings["instanceTypeName"],
                    Name               = createdCommand.Name,
                    State              = ConnectorState.Running,
                    CreateTime         = createTimestamp,
                    UpdateTime         = runningTimestamp,
                    SettingsUpdateTime = createTimestamp,
                    StateUpdateTime    = runningTimestamp,
                    DeleteTime         = null,
                    Position           = null,
                    ErrorDetails       = null,
                    PositionUpdateTime = null,
                    Settings = {
                        { "instanceTypeName", createdCommand.Settings["instanceTypeName"] }
                    }
                }
            }
        };

        // Act
        await projection.ProcessRecord(await RecordContextFor(createdCommand, cancellator.Token));
        Fixture.TimeProvider.Advance(TimeSpan.FromDays(1));
        await projection.ProcessRecord(await RecordContextFor(runningCommand, cancellator.Token));

        // Assert
        var store = await Fixture.SnapshotProjectionsStore.LoadSnapshot<ConnectorsSnapshot>(streamId);
        store.Snapshot.Connectors.Should().BeEquivalentTo(expectedSnapshot.Connectors);
    });

    [Fact]
    public Task projection_updates_on_ConnectorStopped() => Fixture.TestWithTimeout(async cancellator => {
        // Arrange
        var connectorId = Fixture.NewConnectorId();
        var streamId    = Fixture.NewIdentifier();
        var projection  = new ConnectorsStateProjection(Fixture.SnapshotProjectionsStore, streamId);

        var createTimestamp = Fixture.TimeProvider.GetUtcNow().ToTimestamp();

        var createdCommand = new ConnectorCreated {
            ConnectorId = connectorId,
            Name        = "Logger Sink",
            Settings = {
                { "instanceTypeName", "logger-sink" }
            },
            Timestamp = createTimestamp
        };

        var stopTimestamp = Fixture.TimeProvider.GetUtcNow().AddDays(1).ToTimestamp();

        var stopCommand = new ConnectorStopped {
            ConnectorId = connectorId,
            Timestamp   = stopTimestamp
        };

        var expectedSnapshot = new ConnectorsSnapshot {
            Connectors = {
                new Connector {
                    ConnectorId        = stopCommand.ConnectorId,
                    InstanceTypeName   = createdCommand.Settings["instanceTypeName"],
                    Name               = createdCommand.Name,
                    State              = ConnectorState.Stopped,
                    CreateTime         = createTimestamp,
                    UpdateTime         = stopTimestamp,
                    SettingsUpdateTime = createTimestamp,
                    StateUpdateTime    = stopTimestamp,
                    DeleteTime         = null,
                    Position           = null,
                    ErrorDetails       = null,
                    PositionUpdateTime = null,
                    Settings = {
                        { "instanceTypeName", createdCommand.Settings["instanceTypeName"] }
                    }
                }
            }
        };

        // Act
        await projection.ProcessRecord(await RecordContextFor(createdCommand, cancellator.Token));
        Fixture.TimeProvider.Advance(TimeSpan.FromDays(1));
        await projection.ProcessRecord(await RecordContextFor(stopCommand, cancellator.Token));

        // Assert
        var store = await Fixture.SnapshotProjectionsStore.LoadSnapshot<ConnectorsSnapshot>(streamId);
        store.Snapshot.Connectors.Should().BeEquivalentTo(expectedSnapshot.Connectors);
    });

    [Fact]
    public Task projection_updates_on_ConnectorFailed() => Fixture.TestWithTimeout(async cancellator => {
        // Arrange
        var connectorId     = Fixture.NewConnectorId();
        var streamId        = Fixture.NewIdentifier();
        var createTimestamp = Fixture.TimeProvider.GetUtcNow().ToTimestamp();
        var failTimestamp   = Fixture.TimeProvider.GetUtcNow().AddDays(1).ToTimestamp();
        var projection      = new ConnectorsStateProjection(Fixture.SnapshotProjectionsStore, streamId);

        var createdCommand = new ConnectorCreated {
            ConnectorId = connectorId,
            Name        = "Logger Sink",
            Settings = {
                { "instanceTypeName", "logger-sink" }
            },
            Timestamp = createTimestamp
        };

        var failCommand = new ConnectorFailed {
            ConnectorId = connectorId,
            Timestamp   = failTimestamp
        };

        var expectedSnapshot = new ConnectorsSnapshot {
            Connectors = {
                new Connector {
                    ConnectorId        = failCommand.ConnectorId,
                    InstanceTypeName   = createdCommand.Settings["instanceTypeName"],
                    Name               = createdCommand.Name,
                    State              = ConnectorState.Stopped,
                    CreateTime         = createTimestamp,
                    UpdateTime         = failTimestamp,
                    SettingsUpdateTime = createTimestamp,
                    StateUpdateTime    = failTimestamp,
                    DeleteTime         = null,
                    Position           = null,
                    ErrorDetails       = null,
                    PositionUpdateTime = null,
                    Settings = {
                        { "instanceTypeName", createdCommand.Settings["instanceTypeName"] }
                    }
                }
            }
        };

        // Act
        await projection.ProcessRecord(await RecordContextFor(createdCommand, cancellator.Token));
        Fixture.TimeProvider.Advance(TimeSpan.FromDays(1));
        await projection.ProcessRecord(await RecordContextFor(failCommand, cancellator.Token));

        // Assert
        var store = await Fixture.SnapshotProjectionsStore.LoadSnapshot<ConnectorsSnapshot>(streamId);
        store.Snapshot.Connectors.Should().BeEquivalentTo(expectedSnapshot.Connectors);
    });

    [Fact]
    public Task projection_updates_on_ConnectorDeleted() => Fixture.TestWithTimeout(async cancellator => {
        // Arrange
        var connectorId = Fixture.NewConnectorId();
        var streamId    = Fixture.NewIdentifier();
        var projection  = new ConnectorsStateProjection(Fixture.SnapshotProjectionsStore, streamId);

        var createTimestamp = Fixture.TimeProvider.GetUtcNow().ToTimestamp();

        var createdCommand = new ConnectorCreated {
            ConnectorId = connectorId,
            Name        = "Logger Sink",
            Settings = {
                { "instanceTypeName", "logger-sink" }
            },
            Timestamp = createTimestamp
        };

        var deleteTimestamp = Fixture.TimeProvider.GetUtcNow().AddDays(1).ToTimestamp();

        var deleteCommand = new ConnectorDeleted {
            ConnectorId = connectorId,
            Timestamp   = deleteTimestamp
        };

        var expectedSnapshot = new ConnectorsSnapshot {
            Connectors = {
                new Connector {
                    ConnectorId        = deleteCommand.ConnectorId,
                    InstanceTypeName   = createdCommand.Settings["instanceTypeName"],
                    Name               = createdCommand.Name,
                    State              = ConnectorState.Stopped,
                    CreateTime         = createTimestamp,
                    UpdateTime         = deleteTimestamp,
                    SettingsUpdateTime = createTimestamp,
                    StateUpdateTime    = createTimestamp,
                    DeleteTime         = deleteTimestamp,
                    Position           = null,
                    ErrorDetails       = null,
                    PositionUpdateTime = null,
                    Settings = {
                        { "instanceTypeName", createdCommand.Settings["instanceTypeName"] }
                    }
                }
            }
        };

        // Act
        await projection.ProcessRecord(await RecordContextFor(createdCommand, cancellator.Token));
        Fixture.TimeProvider.Advance(TimeSpan.FromDays(1));
        await projection.ProcessRecord(await RecordContextFor(deleteCommand, cancellator.Token));

        // Assert
        var store = await Fixture.SnapshotProjectionsStore.LoadSnapshot<ConnectorsSnapshot>(streamId);
        store.Snapshot.Connectors.Should().BeEquivalentTo(expectedSnapshot.Connectors);
    });

    [Fact]
    public Task projection_clears_error_details_on_successful_recovery() => Fixture.TestWithTimeout(async cancellator => {
        // Arrange
        var connectorId      = Fixture.NewConnectorId();
        var streamId         = Fixture.NewIdentifier();
        var createTimestamp  = Fixture.TimeProvider.GetUtcNow().ToTimestamp();
        var failTimestamp    = Fixture.TimeProvider.GetUtcNow().AddDays(1).ToTimestamp();
        var runningTimestamp = Fixture.TimeProvider.GetUtcNow().AddDays(2).ToTimestamp();
        var projection       = new ConnectorsStateProjection(Fixture.SnapshotProjectionsStore, streamId);

        var createdCommand = new ConnectorCreated {
            ConnectorId = connectorId,
            Name        = "Logger Sink",
            Settings = {
                { "instanceTypeName", "logger-sink" }
            },
            Timestamp = createTimestamp
        };

        var failCommand = new ConnectorFailed {
            ConnectorId = connectorId,
            ErrorDetails = new Contracts.Error {
                Code    = "TestException",
                Message = "Test error message"
            },
            Timestamp = failTimestamp
        };

        var runningCommand = new ConnectorRunning {
            ConnectorId = connectorId,
            Timestamp   = runningTimestamp
        };

        var expectedSnapshotAfterFailure = new ConnectorsSnapshot {
            Connectors = {
                new Connector {
                    ConnectorId        = connectorId,
                    InstanceTypeName   = createdCommand.Settings["instanceTypeName"],
                    Name               = createdCommand.Name,
                    State              = ConnectorState.Stopped,
                    CreateTime         = createTimestamp,
                    UpdateTime         = failTimestamp,
                    SettingsUpdateTime = createTimestamp,
                    StateUpdateTime    = failTimestamp,
                    DeleteTime         = null,
                    Position           = null,
                    ErrorDetails       = failCommand.ErrorDetails,
                    PositionUpdateTime = null,
                    Settings = {
                        { "instanceTypeName", createdCommand.Settings["instanceTypeName"] }
                    }
                }
            }
        };

        var expectedSnapshotAfterRecovery = new ConnectorsSnapshot {
            Connectors = {
                new Connector {
                    ConnectorId        = connectorId,
                    InstanceTypeName   = createdCommand.Settings["instanceTypeName"],
                    Name               = createdCommand.Name,
                    State              = ConnectorState.Running,
                    CreateTime         = createTimestamp,
                    UpdateTime         = runningTimestamp,
                    SettingsUpdateTime = createTimestamp,
                    StateUpdateTime    = runningTimestamp,
                    DeleteTime         = null,
                    Position           = null,
                    ErrorDetails       = null,
                    PositionUpdateTime = null,
                    Settings = {
                        { "instanceTypeName", createdCommand.Settings["instanceTypeName"] }
                    }
                }
            }
        };

        // Act & Assert
        await projection.ProcessRecord(await RecordContextFor(createdCommand, cancellator.Token));
        Fixture.TimeProvider.Advance(TimeSpan.FromDays(1));
        await projection.ProcessRecord(await RecordContextFor(failCommand, cancellator.Token));

        var storeAfterFailure = await Fixture.SnapshotProjectionsStore.LoadSnapshot<ConnectorsSnapshot>(streamId);
        storeAfterFailure.Snapshot.Connectors.Should().BeEquivalentTo(expectedSnapshotAfterFailure.Connectors);
        storeAfterFailure.Snapshot.Connectors[0].ErrorDetails.Should().NotBeNull();

        Fixture.TimeProvider.Advance(TimeSpan.FromDays(1));
        await projection.ProcessRecord(await RecordContextFor(runningCommand, cancellator.Token));

        var storeAfterRecovery = await Fixture.SnapshotProjectionsStore.LoadSnapshot<ConnectorsSnapshot>(streamId);
        storeAfterRecovery.Snapshot.Connectors.Should().BeEquivalentTo(expectedSnapshotAfterRecovery.Connectors);
        storeAfterRecovery.Snapshot.Connectors[0].ErrorDetails.Should().BeNull();
    });

    [Fact]
    public Task projection_clears_error_details_on_successful_stop() => Fixture.TestWithTimeout(async cancellator => {
        // Arrange
        var connectorId      = Fixture.NewConnectorId();
        var streamId         = Fixture.NewIdentifier();
        var createTimestamp  = Fixture.TimeProvider.GetUtcNow().ToTimestamp();
        var failTimestamp    = Fixture.TimeProvider.GetUtcNow().AddDays(1).ToTimestamp();
        var stopTimestamp    = Fixture.TimeProvider.GetUtcNow().AddDays(2).ToTimestamp();
        var projection       = new ConnectorsStateProjection(Fixture.SnapshotProjectionsStore, streamId);

        var createdCommand = new ConnectorCreated {
            ConnectorId = connectorId,
            Name        = "Logger Sink",
            Settings = {
                { "instanceTypeName", "logger-sink" }
            },
            Timestamp = createTimestamp
        };

        var failCommand = new ConnectorFailed {
            ConnectorId = connectorId,
            ErrorDetails = new Contracts.Error {
                Code    = "TestException",
                Message = "Test error message"
            },
            Timestamp = failTimestamp
        };

        var stopCommand = new ConnectorStopped {
            ConnectorId = connectorId,
            Timestamp   = stopTimestamp
        };

        var expectedSnapshotAfterStop = new ConnectorsSnapshot {
            Connectors = {
                new Connector {
                    ConnectorId        = connectorId,
                    InstanceTypeName   = createdCommand.Settings["instanceTypeName"],
                    Name               = createdCommand.Name,
                    State              = ConnectorState.Stopped,
                    CreateTime         = createTimestamp,
                    UpdateTime         = stopTimestamp,
                    SettingsUpdateTime = createTimestamp,
                    StateUpdateTime    = stopTimestamp,
                    DeleteTime         = null,
                    Position           = null,
                    ErrorDetails       = null,
                    PositionUpdateTime = null,
                    Settings = {
                        { "instanceTypeName", createdCommand.Settings["instanceTypeName"] }
                    }
                }
            }
        };

        // Act & Assert
        await projection.ProcessRecord(await RecordContextFor(createdCommand, cancellator.Token));

        Fixture.TimeProvider.Advance(TimeSpan.FromDays(1));
        await projection.ProcessRecord(await RecordContextFor(failCommand, cancellator.Token));

        var storeAfterFailure = await Fixture.SnapshotProjectionsStore.LoadSnapshot<ConnectorsSnapshot>(streamId);
        storeAfterFailure.Snapshot.Connectors[0].ErrorDetails.Should().NotBeNull();

        Fixture.TimeProvider.Advance(TimeSpan.FromDays(1));
        await projection.ProcessRecord(await RecordContextFor(stopCommand, cancellator.Token));

        var storeAfterStop = await Fixture.SnapshotProjectionsStore.LoadSnapshot<ConnectorsSnapshot>(streamId);
        storeAfterStop.Snapshot.Connectors.Should().BeEquivalentTo(expectedSnapshotAfterStop.Connectors);
        storeAfterStop.Snapshot.Connectors[0].ErrorDetails.Should().BeNull();
    });

    async Task<RecordContext> RecordContextFor<T>(T cmd, CancellationToken cancellationToken) where T : IMessage {
        string connectorId = ((dynamic)cmd).ConnectorId;
        var record = await Fixture.CreateRecord(cmd);
        return Fixture.CreateRecordContext(connectorId, cancellationToken) with { Record = record };
    }
}
