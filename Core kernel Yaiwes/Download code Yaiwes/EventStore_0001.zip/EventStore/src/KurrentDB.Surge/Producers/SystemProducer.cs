// Copyright (c) Kurrent, Inc and/or licensed to Kurrent, Inc under one or more agreements.
// Kurrent, Inc licenses this file to you under the Kurrent License v1 (see LICENSE.md).

using DotNext;
using Kurrent.Surge;
using Kurrent.Surge.Interceptors;
using Kurrent.Surge.Producers;
using Kurrent.Surge.Producers.Interceptors;
using Kurrent.Surge.Producers.LifecycleEvents;
using Kurrent.Surge.Schema.Serializers;
using KurrentDB.Core;
using KurrentDB.Core.Data;
using KurrentDB.Core.Services.UserManagement;
using Polly;

namespace KurrentDB.Surge.Producers;

[PublicAPI]
public class SystemProducer : IProducer {
    public static SystemProducerBuilder Builder => new();

    public SystemProducer(SystemProducerOptions options) {
        Options = string.IsNullOrWhiteSpace(options.Logging.LogName)
            ? options with { Logging = options.Logging with { LogName = GetType().FullName! } }
            : options;

        var logger = Options.Logging.LoggerFactory.CreateLogger(GetType().FullName!);

        Client  = options.Client;

        Serialize = (value, headers) => Options.SchemaRegistry.As<ISchemaSerializer>().Serialize(value, headers);

        Flushing = new(true);

        var interceptors = new LinkedList<InterceptorModule>(options.Interceptors);

        if (options.Logging.Enabled)
            interceptors.TryAddUniqueFirst(new ProducerLogger());

        interceptors.TryAddUniqueFirst(new ProducerMetrics());

        Interceptors = new(interceptors, logger);

        Intercept = evt => Interceptors.Intercept(evt, CancellationToken.None);

        ResiliencePipeline = Options.ResiliencePipelineBuilder
            .With(x => x.InstanceName = "SystemProducerPipeline")
            .Build();
    }

    SystemProducerOptions                   Options            { get; }
    ISystemClient                           Client             { get; }
    Serialize                               Serialize          { get; }
    ManualResetEventSlim                    Flushing           { get; }
    InterceptorController                   Interceptors       { get; }
    Func<ProducerLifecycleEvent, ValueTask> Intercept          { get; }
    ResiliencePipeline                      ResiliencePipeline { get; }

    public string  ProducerId       => Options.ProducerId;
    public string  ClientId         => Options.ClientId;
    public string? Stream           => Options.DefaultStream;
    public int     InFlightMessages => 0;

    public ValueTask Produce(ProduceRequest request, OnProduceResult onResult) =>
        ProduceInternal(request, new ProduceResultCallback(onResult));

    public ValueTask Produce<TState>(ProduceRequest request, OnProduceResult<TState> onResult, TState state) =>
        ProduceInternal(request, new ProduceResultCallback<TState>(onResult, state));

    public ValueTask Produce<TState>(ProduceRequest request, ProduceResultCallback<TState> callback) =>
        ProduceInternal(request, callback);

    public ValueTask Produce(ProduceRequest request, ProduceResultCallback callback) =>
        ProduceInternal(request, callback);

    async ValueTask ProduceInternal(ProduceRequest request, IProduceResultCallback callback) {
        Ensure.NotDefault(request, ProduceRequest.Empty);
        Ensure.NotNull(callback);

        if (request.Messages.Count == 0)
            throw new Exception("No events received");

        var validRequest = request.EnsureStreamIsSet(Options.DefaultStream);

        await Intercept(new ProduceRequestReceived(this, validRequest));

        Flushing.Wait();

        var events = await validRequest
            .ToEvents(
                headers => headers
                    .Set(HeaderKeys.ProducerId, ProducerId)
                    .Set(HeaderKeys.ProducerRequestId, validRequest.RequestId),
                Serialize
            );

        await Intercept(new ProduceRequestReady(this, request));

        var expectedRevision = request.ExpectedStreamRevision != StreamRevision.Unset
            ? request.ExpectedStreamRevision.Value
            : request.ExpectedStreamState switch {
                StreamState.Missing => ExpectedVersion.NoStream,
                StreamState.Exists  => ExpectedVersion.StreamExists,
                StreamState.Any     => ExpectedVersion.Any,
                _ => throw new ArgumentOutOfRangeException(nameof(request.ExpectedStreamState), request.ExpectedStreamState, null)
            };

        var result = await WriteEvents(Client, validRequest, events, expectedRevision, ResiliencePipeline);

        await Intercept(new ProduceRequestProcessed(this, result));

        try {
            await callback.Execute(result);
        } catch (Exception uex) {
            await Intercept(new ProduceRequestCallbackError(this, result, uex));
        }

        return;

        static async ValueTask<ProduceResult> WriteEvents(ISystemClient client, ProduceRequest request, Event[] events, long expectedRevision, ResiliencePipeline resiliencePipeline) {
            var state = (Client: client, Request: request, Events: events, ExpectedRevision: expectedRevision);

            try {
                return await resiliencePipeline.ExecuteAsync(
                    static async (state, token) => {
                        var result = await WriteEvents(state.Client, state.Request, state.Events, state.ExpectedRevision, token);

                        // If it is the wrong version but the stream is empty,
                        // it means the stream was deleted or truncated.
                        // Therefore, we can retry immediately
                        if (state.Request.ExpectedStreamState == StreamState.Missing && result.Error is ExpectedStreamRevisionError revisionError) {
                            result = await state.Client
                                .Reading
                                .ReadStreamLastEvent(state.Request.Stream, CancellationToken.None)
                                .Then(async re => re is null || re == ResolvedEvent.EmptyEvent
                                    ? await WriteEvents(state.Client, state.Request, state.Events, revisionError.ActualStreamRevision, token)
                                    : result);
                        }

                        return result.Error is null ? result : throw result.Error;
                    }, state
                );
            }
            // we have to recreate the error result... must rethink this
            catch (StreamingError err) {
                return ProduceResult.Failed(request, err);
            }

            static async ValueTask<ProduceResult> WriteEvents(ISystemClient client, ProduceRequest request, Event[] events, long expectedRevision, CancellationToken cancellationToken) {
                try {
                    var (position, streamRevision) = await client.Writing.WriteEvents(request.Stream, events, requireLeader: false, SystemAccounts.System, expectedRevision, cancellationToken);

                    var recordPosition = RecordPosition.ForStream(
                        StreamId.From(request.Stream),
                        StreamRevision.From(streamRevision.ToInt64()),
                        LogPosition.From(position.CommitPosition, position.PreparePosition)
                    );

                    return ProduceResult.Succeeded(request, recordPosition);
                }
                catch (Exception ex) {
                    return ProduceResult.Failed(request, ex.ToProducerStreamingError(request.Stream));
                }
            }
        }
    }

    public async ValueTask<(int Flushed, int Inflight)> Flush(CancellationToken cancellationToken = default) {
        try {
            Flushing.Reset();
            await Intercept(new ProducerFlushed(this, 0, 0));
            return (0, 0);
        } finally {
            Flushing.Set();
        }
    }

    public virtual async ValueTask DisposeAsync() {
        try {
            await Flush();

            await Intercept(new ProducerStopped(this));
        } catch (Exception ex) {
            await Intercept(new ProducerStopped(this, ex)); //not sure about this...
            throw;
        } finally {
            await Interceptors.DisposeAsync();
        }
    }
}
