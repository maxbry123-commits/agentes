// Copyright (c) Kurrent, Inc and/or licensed to Kurrent, Inc under one or more agreements.
// Kurrent, Inc licenses this file to you under the Kurrent License v1 (see LICENSE.md).

namespace KurrentDB.AutoScavenge;

public readonly record struct NodeEndpoint {
	public string Host { get; init; }
	public int Port { get; init; }
}
