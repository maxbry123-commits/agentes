import { useInterpret } from "@xstate/react";
import React from "react";
import { TaskDef } from "types";
import { UiIntegrationsFieldType } from "types/FormFieldTypes";
import { FieldComponentType, updateField } from "utils/fieldHelpers";
import { useAuthHeaders } from "utils/query";
import { ActorRef } from "xstate";
import {
  LLMFormFieldsEvents,
  LLMFormFieldsMachineContext,
  SelectInstructionsEvent,
  SelectPromptNameEvent,
  llmFormFieldsMachine,
} from "./state";

interface LLMFormFieldsWrapperProps {
  onChange: (task: Partial<TaskDef>) => void;
  task: Partial<TaskDef>;
  allFieldComponents: Array<[UiIntegrationsFieldType, FieldComponentType]>;
  children: (actor: ActorRef<LLMFormFieldsEvents>) => React.ReactNode;
}

const LLMFormFieldsWrapper = ({
  onChange,
  task,
  allFieldComponents,
  children,
}: LLMFormFieldsWrapperProps) => {
  const authHeaders = useAuthHeaders();
  const fields = allFieldComponents?.map(([type]) => type);
  const actor = useInterpret(llmFormFieldsMachine, {
    ...(process.env.NODE_ENV === "development" ? { devTools: true } : {}),
    context: {
      authHeaders,
      fields,
      task,
    },
    actions: {
      selectPromptName: (
        ctx: LLMFormFieldsMachineContext,
        event: SelectPromptNameEvent,
      ) => {
        const maybeAvailablePromptName = ctx.promptNameOptions.find(
          ({ name }) => name === event?.task?.inputParameters?.promptName,
        );
        if (maybeAvailablePromptName) {
          const newVariables = Object.fromEntries(
            (maybeAvailablePromptName?.variables as string[]).map((l) => [
              l,
              "",
            ]),
          );

          const resultVariables = {
            ...newVariables,
          };

          const taskWithVariables = updateField(
            `inputParameters.promptVariables`,
            resultVariables,
            event.task,
          );

          let taskWithSelectedPromptName = updateField(
            `inputParameters.${UiIntegrationsFieldType.PROMPT_NAME}`,
            maybeAvailablePromptName?.name,
            taskWithVariables,
          );

          // Auto-populate sampling params when defined on the prompt.
          // Claude rejects temperature + top_p together — prefer temperature and clear the other.
          if (maybeAvailablePromptName.temperature != null) {
            taskWithSelectedPromptName = updateField(
              `inputParameters.${UiIntegrationsFieldType.TEMPERATURE}`,
              maybeAvailablePromptName.temperature,
              taskWithSelectedPromptName,
            );
            taskWithSelectedPromptName = updateField(
              `inputParameters.${UiIntegrationsFieldType.TOP_P}`,
              null,
              taskWithSelectedPromptName,
            );
          } else if (maybeAvailablePromptName.topP != null) {
            taskWithSelectedPromptName = updateField(
              `inputParameters.${UiIntegrationsFieldType.TOP_P}`,
              maybeAvailablePromptName.topP,
              taskWithSelectedPromptName,
            );
            taskWithSelectedPromptName = updateField(
              `inputParameters.${UiIntegrationsFieldType.TEMPERATURE}`,
              null,
              taskWithSelectedPromptName,
            );
          }

          // Auto-populate stopWords if available in the prompt
          if (maybeAvailablePromptName.stopWords != null) {
            taskWithSelectedPromptName = updateField(
              `inputParameters.stopWords`,
              maybeAvailablePromptName.stopWords,
              taskWithSelectedPromptName,
            );
          }

          // A known registered template is selected — Orkes' prompt-association
          // check (checkPromptAccess) will find it, so raw-prompt bypass isn't needed.
          taskWithSelectedPromptName = updateField(
            `inputParameters.allowRawPrompts`,
            false,
            taskWithSelectedPromptName,
          );

          onChange(taskWithSelectedPromptName);
        } else {
          const updatedTask = updateField(
            `inputParameters.${UiIntegrationsFieldType.PROMPT_NAME}`,
            event?.task?.inputParameters?.promptName,
            event.task,
          );

          // Free text (or OSS, which has no prompt registry at all) — without this,
          // Orkes' checkPromptAccess terminates the workflow at runtime because the
          // value isn't an associated prompt name.
          const updatedTaskWithRawFlag = updateField(
            `inputParameters.allowRawPrompts`,
            true,
            updatedTask,
          );

          onChange(updatedTaskWithRawFlag);
        }
      },
      selectInstructions: (
        ctx: LLMFormFieldsMachineContext,
        event: SelectInstructionsEvent,
      ) => {
        const maybeAvailablePromptName = ctx.promptNameOptions.find(
          ({ name }) => name === event?.task?.inputParameters?.instructions,
        );
        if (maybeAvailablePromptName) {
          const newVariables = Object.fromEntries(
            (maybeAvailablePromptName?.variables as string[]).map((l) => [
              l,
              "",
            ]),
          );

          const resultVariables = {
            ...newVariables,
          };

          const taskWithVariables = updateField(
            `inputParameters.promptVariables`,
            resultVariables,
            event.task,
          );

          let taskWithSelectedPromptName = updateField(
            `inputParameters.${UiIntegrationsFieldType.INSTRUCTIONS}`,
            maybeAvailablePromptName?.name,
            taskWithVariables,
          );

          // Auto-populate sampling params when defined on the prompt.
          // Claude rejects temperature + top_p together — prefer temperature and clear the other.
          if (maybeAvailablePromptName.temperature != null) {
            taskWithSelectedPromptName = updateField(
              `inputParameters.${UiIntegrationsFieldType.TEMPERATURE}`,
              maybeAvailablePromptName.temperature,
              taskWithSelectedPromptName,
            );
            taskWithSelectedPromptName = updateField(
              `inputParameters.${UiIntegrationsFieldType.TOP_P}`,
              null,
              taskWithSelectedPromptName,
            );
          } else if (maybeAvailablePromptName.topP != null) {
            taskWithSelectedPromptName = updateField(
              `inputParameters.${UiIntegrationsFieldType.TOP_P}`,
              maybeAvailablePromptName.topP,
              taskWithSelectedPromptName,
            );
            taskWithSelectedPromptName = updateField(
              `inputParameters.${UiIntegrationsFieldType.TEMPERATURE}`,
              null,
              taskWithSelectedPromptName,
            );
          }

          // Auto-populate stopWords if available in the prompt
          if (maybeAvailablePromptName.stopWords != null) {
            taskWithSelectedPromptName = updateField(
              `inputParameters.stopWords`,
              maybeAvailablePromptName.stopWords,
              taskWithSelectedPromptName,
            );
          }

          // A known registered template is selected — Orkes' prompt-association
          // check (checkPromptAccess) will find it, so raw-prompt bypass isn't needed.
          taskWithSelectedPromptName = updateField(
            `inputParameters.allowRawPrompts`,
            false,
            taskWithSelectedPromptName,
          );

          onChange(taskWithSelectedPromptName);
        } else {
          const updatedTask = updateField(
            `inputParameters.${UiIntegrationsFieldType.INSTRUCTIONS}`,
            event?.task?.inputParameters?.instructions,
            event.task,
          );

          // Free text (or OSS, which has no prompt registry at all) — without this,
          // Orkes' checkPromptAccess terminates the workflow at runtime because the
          // value isn't an associated prompt name (ChatCompletion.getPrompt() reads
          // instructions server-side).
          const updatedTaskWithRawFlag = updateField(
            `inputParameters.allowRawPrompts`,
            true,
            updatedTask,
          );

          onChange(updatedTaskWithRawFlag);
        }
      },
    },
  });
  return <>{children(actor)}</>;
};

export default LLMFormFieldsWrapper;
