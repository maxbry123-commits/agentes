/*
 * Copyright 2021 Conductor Authors.
 * <p>
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * <p>
 * http://www.apache.org/licenses/LICENSE-2.0
 * <p>
 * Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on
 * an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations under the License.
 */
package com.netflix.conductor.sdk.workflow.task;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/** Identifies a simple worker task. */
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.METHOD})
public @interface WorkerTask {
    String value();

    // No. of threads to use for executing the task
    int threadCount() default 1;

    int pollingInterval() default 100;

    String domain() default "";

    // In millis
    int pollTimeout() default 100;

    // number of task pollers
    // default is 1 which is good enough for most use cases
    // a number higher than 1 will have concurrent pollers doing poll and execute
    int pollerCount() default 1;

    /**
     * Extend the task lease while the worker method is running.
     *
     * <p>This is intended for annotated tasks that may block on a streaming response.
     */
    boolean leaseExtendEnabled() default false;
}
