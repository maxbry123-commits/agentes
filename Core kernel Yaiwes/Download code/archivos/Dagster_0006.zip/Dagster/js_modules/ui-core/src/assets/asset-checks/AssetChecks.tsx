import {
  Box,
  Container,
  Heading,
  Icon,
  Inner,
  MiddleTruncate,
  NonIdealState,
  Row,
  Text,
  TextInput,
  useViewport,
} from '@dagster-io/ui-components';
import {useVirtualizer} from '@tanstack/react-virtual';
import clsx from 'clsx';
import React, {useState} from 'react';

import {AssetCheckAutomationList} from './AssetCheckAutomationList';
import {
  ASSET_CHECK_DETAILS_QUERY,
  AgentUpgradeRequired,
  MigrationRequired,
  NeedsUserCodeUpgrade,
} from './AssetCheckDetailDialog';
import {AssetCheckExecutionList} from './AssetCheckExecutionList';
import {AssetCheckOverview} from './AssetCheckOverview';
import {AssetCheckPartitions} from './AssetCheckPartitions';
import {ASSET_CHECKS_QUERY} from './AssetChecksQuery';
import {AssetChecksTabType, AssetChecksTabs} from './AssetChecksTabs';
import {ExecuteChecksButton} from './ExecuteChecksButton';
import styles from './css/AssetChecks.module.css';
import {
  AssetCheckDetailsQuery,
  AssetCheckDetailsQueryVariables,
} from './types/AssetCheckDetailDialog.types';
import {assetCheckStatusDescription, getCheckIcon} from './util';
import {useQuery} from '../../apollo-client';
import {AssetChecksQuery, AssetChecksQueryVariables} from './types/AssetChecksQuery.types';
import {useReportCheckEvaluationDialog} from './useReportCheckEvaluationDialog';
import {DEFAULT_DISABLED_REASON} from '../../app/Permissions';
import {FIFTEEN_SECONDS, useQueryRefreshAtInterval} from '../../app/QueryRefresh';
import {COMMON_COLLATOR, assertUnreachable} from '../../app/Util';
import {AssetKeyInput} from '../../graphql/types';
import {useQueryPersistedState} from '../../hooks/useQueryPersistedState';
import {useCursorPaginatedQuery} from '../../runs/useCursorPaginatedQuery';
import {numberFormatter} from '../../ui/formatters';
import {buildRepoAddress} from '../../workspace/buildRepoAddress';
import {PAGE_SIZE} from '../AutoMaterializePolicyPage/useEvaluationsQueryResult';
import {AssetKey} from '../types';

export const AssetChecks = ({
  assetKey,
}: {
  assetKey: AssetKey;
  lastMaterializationTimestamp: string | undefined;
}) => {
  const queryResult = useQuery<AssetChecksQuery, AssetChecksQueryVariables>(ASSET_CHECKS_QUERY, {
    variables: {assetKey},
  });

  const {data} = queryResult;
  useQueryRefreshAtInterval(queryResult, FIFTEEN_SECONDS);

  const [selectedCheckName, setSelectedCheckName] = useQueryPersistedState<string>({
    queryKey: 'checkDetail',
  });

  const [activeTab, setActiveTab] = useState<AssetChecksTabType>('overview');

  const assetNode =
    data?.assetNodeOrError.__typename === 'AssetNode' ? data.assetNodeOrError : null;

  const checks = React.useMemo(() => {
    if (data?.assetNodeOrError.__typename !== 'AssetNode') {
      return [];
    }
    if (data.assetNodeOrError.assetChecksOrError.__typename !== 'AssetChecks') {
      return [];
    }
    return [...data.assetNodeOrError.assetChecksOrError.checks].sort((a, b) =>
      COMMON_COLLATOR.compare(a.name, b.name),
    );
  }, [data]);

  const [searchValue, setSearchValue] = React.useState('');

  const filteredChecks = React.useMemo(() => {
    return checks.filter((check) => check.name.toLowerCase().includes(searchValue.toLowerCase()));
  }, [checks, searchValue]);

  const containerRef = React.useRef<HTMLDivElement | null>(null);

  const rowVirtualizer = useVirtualizer({
    count: filteredChecks.length,
    getScrollElement: () => containerRef.current,
    estimateSize: () => 48,
    overscan: 10,
  });

  const totalHeight = rowVirtualizer.getTotalSize();
  const items = rowVirtualizer.getVirtualItems();

  const selectedCheck = React.useMemo(() => {
    if (!selectedCheckName) {
      return checks[0];
    }
    return checks.find((check) => check.name === selectedCheckName) ?? checks[0];
  }, [selectedCheckName, checks]);

  const isPartitioned = React.useMemo(() => {
    return !!(selectedCheck && selectedCheck.partitionDefinition);
  }, [selectedCheck]);

  const isSelectedCheckAutomated = !!selectedCheck?.automationCondition;

  const selectedCheckInfo = React.useMemo(() => {
    if (!assetNode || !selectedCheck) {
      return null;
    }

    return {
      assetKey,
      isPartitioned,
      name: selectedCheck.name,
      repoAddress: buildRepoAddress(assetNode.repository.name, assetNode.repository.location.name),
      hasReportRunlessAssetEventPermission: assetNode.hasReportRunlessAssetEventPermission,
    };
  }, [assetNode, selectedCheck, assetKey, isPartitioned]);

  const {
    setIsOpen: setReportDialogOpen,
    element: reportDialogElement,
    hasPermission: canReportEvaluation,
  } = useReportCheckEvaluationDialog(selectedCheckInfo, () => queryResult.refetch());

  const {paginationProps, executions, executionsLoading} = useHistoricalCheckExecutions(
    selectedCheck ? {assetKey, checkName: selectedCheck.name} : null,
  );

  if (!data) {
    return null;
  }

  if (data.assetNodeOrError.__typename === 'AssetNode') {
    const type = data.assetNodeOrError.assetChecksOrError.__typename;
    switch (type) {
      case 'AssetCheckNeedsAgentUpgradeError':
        return <AgentUpgradeRequired />;
      case 'AssetCheckNeedsMigrationError':
        return <MigrationRequired />;
      case 'AssetCheckNeedsUserCodeUpgrade':
        return <NeedsUserCodeUpgrade />;
      case 'AssetChecks':
        break;
      default:
        assertUnreachable(type);
    }
  }

  if (!checks.length || !selectedCheck || !assetNode) {
    return (
      <Box flex={{alignItems: 'center'}} padding={32}>
        <NonIdealState
          title="No checks defined for this asset"
          icon="asset_check"
          description={
            <Box flex={{direction: 'column', gap: 8}}>
              <Text size={14}>
                Asset checks can verify properties of a data asset, e.g. that there are no null
                values in a particular column.
              </Text>
              <a href="https://docs.dagster.io/concepts/assets/asset-checks">
                Learn more about asset checks
              </a>
            </Box>
          }
        />
      </Box>
    );
  }

  const lastExecution = selectedCheck.executionForLatestMaterialization;
  const targetMaterialization = lastExecution?.evaluation?.targetMaterialization ?? null;

  return (
    <Box flex={{grow: 1, direction: 'column'}}>
      <Box flex={{direction: 'row', grow: 1}} style={{position: 'relative'}}>
        <Box flex={{direction: 'column'}} style={{minWidth: 294, width: '20%'}} border="right">
          <Box
            style={{height: 56}}
            border="bottom"
            flex={{justifyContent: 'space-between', alignItems: 'center'}}
            padding={{left: 24, vertical: 12, right: 12}}
          >
            <Heading size={16} weight={600}>
              Checks {checks.length ? <>({numberFormatter.format(checks.length)})</> : null}
            </Heading>
            <ExecuteChecksButton assetNode={assetNode} checks={checks} />
          </Box>
          <Box
            flex={{direction: 'column', gap: 8, grow: 1}}
            padding={{horizontal: 16, vertical: 12}}
          >
            <TextInput
              icon="search"
              value={searchValue}
              onChange={(e) => setSearchValue(e.target.value)}
              placeholder="Filter checks"
            />
            <FixedScrollContainer>
              <Container ref={containerRef}>
                <Inner totalHeight={totalHeight}>
                  {items.map(({index, size, start}) => {
                    // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
                    const check = filteredChecks[index]!;
                    return (
                      <Row
                        key={check.name}
                        height={size}
                        start={start}
                        className={clsx(
                          styles.checkRow,
                          selectedCheck === check && styles.checkRowSelected,
                        )}
                        onClick={() => {
                          setSelectedCheckName(check.name);
                          setActiveTab('overview');
                        }}
                      >
                        <Box flex={{direction: 'column', gap: 2}}>
                          <Box flex={{direction: 'row', gap: 8, alignItems: 'flex-start'}}>
                            <Box
                              flex={{alignItems: 'center', justifyContent: 'center'}}
                              style={{
                                width: 20,
                                height: 20,
                              }}
                            >
                              {getCheckIcon(check)}
                            </Box>
                            <Text size={14} style={{overflow: 'hidden'}}>
                              <MiddleTruncate text={check.name} />
                              <Text
                                size={12}
                                color="textLight"
                                style={{textTransform: 'capitalize'}}
                              >
                                {assetCheckStatusDescription(check)}
                              </Text>
                            </Text>
                          </Box>
                        </Box>
                      </Row>
                    );
                  })}
                </Inner>
              </Container>
            </FixedScrollContainer>
          </Box>
        </Box>
        <Box flex={{direction: 'column'}} style={{flex: 1}}>
          <Box
            style={{height: 56}}
            border="bottom"
            flex={{direction: 'row', alignItems: 'center', justifyContent: 'space-between'}}
            padding={{vertical: 12, horizontal: 24}}
          >
            <Box flex={{direction: 'row', gap: 8, alignItems: 'center'}}>
              <Icon name="asset_check" />
              <Heading size={16} weight={600}>
                {selectedCheck.name}
              </Heading>
            </Box>
            <Box flex={{direction: 'row', gap: 8, alignItems: 'center'}}>
              {reportDialogElement}
              <ExecuteChecksButton
                assetNode={assetNode}
                checks={[selectedCheck]}
                label="Execute"
                isPartitioned={isPartitioned}
                additionalDropdownOptions={[
                  {
                    label: 'Report evaluation',
                    icon: 'asset_check',
                    onClick: () => setReportDialogOpen(true),
                    disabled: !canReportEvaluation,
                    disabledReason: DEFAULT_DISABLED_REASON,
                  },
                ]}
              />
            </Box>
          </Box>
          <Box padding={{horizontal: 24}} border="bottom">
            <AssetChecksTabs
              activeTab={activeTab}
              enableAutomationHistory={isSelectedCheckAutomated}
              hasPartitions={isPartitioned}
              onChange={(tab) => {
                setActiveTab(tab);
              }}
            />
          </Box>
          {activeTab === 'overview' ? (
            <AssetCheckOverview
              selectedCheck={selectedCheck}
              lastExecution={lastExecution}
              targetMaterialization={targetMaterialization}
              executions={executions}
              executionsLoading={executionsLoading}
            />
          ) : null}
          {activeTab === 'execution-history' ? (
            <AssetCheckExecutionList
              executions={executions}
              paginationProps={paginationProps}
              hasPartitions={isPartitioned}
            />
          ) : null}
          {activeTab === 'automation-history' ? (
            <AssetCheckAutomationList assetCheck={selectedCheck} checkName={selectedCheck.name} />
          ) : null}
          {activeTab === 'partitions' ? (
            <AssetCheckPartitions assetKey={assetKey} checkName={selectedCheck.name} />
          ) : null}
        </Box>
      </Box>
    </Box>
  );
};

const useHistoricalCheckExecutions = (
  variables: {assetKey: AssetKeyInput; checkName: string} | null,
) => {
  const {queryResult, paginationProps} = useCursorPaginatedQuery<
    AssetCheckDetailsQuery,
    AssetCheckDetailsQueryVariables
  >({
    query: ASSET_CHECK_DETAILS_QUERY,
    skip: !variables,
    variables: variables || {assetKey: {path: []}, checkName: ''},
    nextCursorForResult: (data) => {
      if (!data) {
        return undefined;
      }
      return data.assetCheckExecutions[PAGE_SIZE - 1]?.id.toString();
    },
    getResultArray: (data) => {
      if (!data) {
        return [];
      }
      return data.assetCheckExecutions || [];
    },
    pageSize: PAGE_SIZE,
  });

  // TODO - in a follow up PR we should have some kind of queryRefresh context that can merge all of the uses of queryRefresh.
  useQueryRefreshAtInterval(queryResult, FIFTEEN_SECONDS);

  const executionsLoading = queryResult.loading && !queryResult.data;
  const executions = React.useMemo(
    () =>
      // Ideally, we'd sort this as part of the db query, but right now the db query
      // paginates and sorts on the check ID rather than the timestamp.
      [...(queryResult.data?.assetCheckExecutions || [])].sort((a, b) => {
        return (b.evaluation?.timestamp || b.timestamp) - (a.evaluation?.timestamp || a.timestamp);
      }),
    [queryResult],
  );
  return {executions, executionsLoading, paginationProps};
};

const FixedScrollContainer = ({children}: {children: React.ReactNode}) => {
  // This is kind of hacky but basically the height of the parent of this element is dynamic (its parent has flex grow)
  // but we don't want it to grow with the content inside of this node, instead we want it only to grow with the content of our sibling node.
  // This will effectively give us a height of 0
  const {viewport, containerProps} = useViewport();
  return (
    <Box flex={{grow: 1}} {...containerProps} style={{position: 'relative'}}>
      <div style={{position: 'absolute', height: viewport.height, left: 0, right: 0}}>
        {children}
      </div>
    </Box>
  );
};
