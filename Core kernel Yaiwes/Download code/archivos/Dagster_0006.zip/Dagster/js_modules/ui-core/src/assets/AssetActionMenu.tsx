import {
  Button,
  HoverButton,
  Icon,
  Menu,
  MenuDivider,
  MenuItem,
  Popover,
  Spinner,
  Tooltip,
  showToast,
} from '@dagster-io/ui-components';
import {AddToFavoritesMenuItem} from '@shared/assets/AddToFavoritesMenuItem';
import {memo, useContext, useMemo} from 'react';

import {optionsForExecuteButton, useMaterializationAction} from './LaunchAssetExecutionButton';
import {assetDetailsPathForKey} from './assetDetailsPathForKey';
import {globalAssetGraphPathForGroup} from './globalAssetGraphPathToString';
import {AssetWorkspaceNodeFragment} from './types/AssetTableFragment.types';
import {useDeleteDynamicPartitionsDialog} from './useDeleteDynamicPartitionsDialog';
import {useObserveAction} from './useObserveAction';
import {useReportEventsDialog} from './useReportEventsDialog';
import {useWipeDialog} from './useWipeDialog';
import {CloudOSSContext} from '../app/CloudOSSContext';
import {AssetKeyInput} from '../graphql/types';
import {MenuLink} from '../ui/MenuLink';
import {RepoAddress} from '../workspace/types';

interface Props {
  path: string[];
  definition: AssetWorkspaceNodeFragment | null;
  repoAddress: RepoAddress | null;
  onRefresh?: () => void;
  unstyledButton?: boolean;
}

export const AssetActionMenu = memo((props: Props) => {
  const {repoAddress, path, definition, onRefresh, unstyledButton} = props;
  const {
    featureContext: {canSeeMaterializeAction},
  } = useContext(CloudOSSContext);

  // Because the asset catalog loads a list of keys, and then definitions for SDAs,
  // we don't re-fetch the key inside the definition of each asset. Re-attach the
  // assetKey to the definition for the hook below.
  const asset = useMemo(
    () =>
      definition
        ? {...definition, isPartitioned: !!definition?.partitionDefinition, assetKey: {path}}
        : null,
    [path, definition],
  );
  const {executeItem, launchpadElement} = useExecuteAssetMenuItem(asset);

  const deletePartitions = useDeleteDynamicPartitionsDialog(
    repoAddress && definition ? {repoAddress, assetKey: {path}, definition} : null,
    onRefresh,
  );

  const wipe = useWipeDialog(
    {
      assetKey: {path},
      definitionHasWipePermission: !!definition?.hasWipePermission,
      locationName: definition ? definition?.repository.location.name : null,
    },
    onRefresh,
  );

  const reportEvents = useReportEventsDialog(
    repoAddress
      ? {
          assetKey: {path},
          isPartitioned: !!definition?.partitionDefinition,
          repoAddress,
          hasReportRunlessAssetEventPermission: !!definition?.hasReportRunlessAssetEventPermission,
        }
      : null,
  );

  const additionalMenuItems = [...wipe.dropdownOptions, ...deletePartitions.dropdownOptions];

  return (
    <>
      {launchpadElement}
      {wipe.element}
      {reportEvents.element}
      {deletePartitions.element}
      <Popover
        position="bottom-right"
        targetTagName="div"
        targetProps={{
          style: {
            display: 'flex',
            alignItems: 'center',
          },
        }}
        content={
          <Menu>
            {executeItem}
            <AddToFavoritesMenuItem assetKey={{path}} />
            <MenuLink
              text="Show in group"
              to={
                definition
                  ? globalAssetGraphPathForGroup(definition.groupName, definition.assetKey)
                  : '/asset-groups'
              }
              disabled={!definition}
              icon="asset_group"
            />
            <MenuLink
              text="View checks"
              to={assetDetailsPathForKey({path}, {view: 'checks'})}
              disabled={!definition}
              icon="asset_check"
            />
            <MenuLink
              text="View lineage"
              to={assetDetailsPathForKey({path}, {view: 'lineage', lineageScope: 'neighbors'})}
              disabled={!definition}
              icon="graph_neighbors"
            />
            <MenuLink
              text="View upstream assets"
              to={assetDetailsPathForKey({path}, {view: 'lineage', lineageScope: 'upstream'})}
              disabled={!definition}
              icon="graph_upstream"
            />
            <MenuLink
              text="View downstream assets"
              to={assetDetailsPathForKey({path}, {view: 'lineage', lineageScope: 'downstream'})}
              disabled={!definition}
              icon="graph_downstream"
            />
            {canSeeMaterializeAction && definition?.hasMaterializePermission
              ? reportEvents.dropdownOptions.map((option) => (
                  <MenuItem
                    key={option.label}
                    text={option.label}
                    icon={option.icon}
                    onClick={option.onClick}
                  />
                ))
              : undefined}
            {additionalMenuItems.length && (
              <>
                <MenuDivider />
                {additionalMenuItems}
              </>
            )}
          </Menu>
        }
      >
        {unstyledButton ? (
          <HoverButton style={{padding: 8}}>
            <Icon name="more_horiz" />
          </HoverButton>
        ) : (
          <Button icon={<Icon name="more_horiz" />} />
        )}
      </Popover>
    </>
  );
});

export const useExecuteAssetMenuItem = (
  definition: {
    assetKey: AssetKeyInput;
    isObservable: boolean;
    isExecutable: boolean;
    isPartitioned: boolean;
    hasMaterializePermission: boolean;
  } | null,
) => {
  const {materializeOption, observeOption} = optionsForExecuteButton(
    definition ? [definition] : [],
    {skipAllTerm: true},
  );

  const {
    featureContext: {canSeeMaterializeAction},
  } = useContext(CloudOSSContext);

  const materialize = useMaterializationAction();
  const observe = useObserveAction();
  const loading = materialize.loading || observe.loading;

  const [option, action] =
    materializeOption.disabledReason && !observeOption.disabledReason
      ? [observeOption, observe.onClick]
      : [materializeOption, materialize.onClick];

  const disabledMessage = definition
    ? option.disabledReason
    : 'Asset definition not found in a code location';

  if (!canSeeMaterializeAction) {
    return {executeItem: null, launchpadElement: null};
  }

  return {
    launchpadElement: materialize.launchpadElement,
    executeItem: (
      <Tooltip
        content={disabledMessage || 'Shift+click to add configuration'}
        placement="left"
        display="block"
      >
        <MenuItem
          text={option.label}
          icon={loading ? <Spinner purpose="body-text" /> : option.icon}
          disabled={!!disabledMessage || loading}
          onClick={(e) => {
            if (!definition) {
              return;
            }
            void showToast({
              intent: 'primary',
              message: `Initiating...`,
            });

            action([definition.assetKey], e);
          }}
        />
      </Tooltip>
    ),
  };
};
