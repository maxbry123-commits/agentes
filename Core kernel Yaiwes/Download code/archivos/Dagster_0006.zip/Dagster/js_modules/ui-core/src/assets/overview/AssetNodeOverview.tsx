import {Box, Heading, NonIdealState, Skeleton, Tag, Text} from '@dagster-io/ui-components';
import {AssetAlertsSection} from '@shared/assets/AssetAlertsSection';
import {AssetEventMetadataEntriesTable} from '@shared/assets/AssetEventMetadataEntriesTable';
import React, {useMemo} from 'react';
import {Link} from 'react-router-dom';

import {FreshnessPolicySection} from './FreshnessPolicySection';
import {metadataForAssetNode} from '../AssetMetadata';
import {WorkspaceAssetNode} from '../useAllAssets';
import {AutomationDetailsSection} from './AutomationDetailsSection';
import {AttributeAndValue, SectionEmptyState} from './Common';
import {ComputeDetailsSection} from './ComputeDetailsSection';
import {DefinitionSection} from './DefinitionSection';
import {FreshnessPolicyStatus} from './FreshnessPolicyStatus';
import {LineageSection} from './LineageSection';
import {useAssetsLiveData} from '../../asset-data/AssetLiveDataProvider';
import {LiveDataForNode} from '../../asset-graph/Utils';
import {
  MetadataEntryLabelOnly,
  isCanonicalQueryCountMetadataEntry,
  isCanonicalRowCountMetadataEntry,
  isCanonicalSizeBytesMetadataEntry,
} from '../../metadata/MetadataEntry';
import {TableSchema, TableSchemaAssetContext} from '../../metadata/TableSchema';
import {MetadataEntryFragment_IntMetadataEntry as IntMetadataEntry} from '../../metadata/types/MetadataEntryFragment.types';
import {useRepositoryLocationForAddress} from '../../nav/useRepositoryLocationForAddress';
import {Description} from '../../pipelines/Description';
import {numberFormatter} from '../../ui/formatters';
import {buildRepoAddress} from '../../workspace/buildRepoAddress';
import {LargeCollapsibleSection} from '../LargeCollapsibleSection';
import {MaterializationTag} from '../MaterializationTag';
import {OverdueTag} from '../OverdueTag';
import {RecentUpdatesTimeline} from '../RecentUpdatesTimeline';
import {SimpleStakeholderAssetStatus} from '../SimpleStakeholderAssetStatus';
import {AssetChecksStatusSummary} from '../asset-checks/AssetChecksStatusSummary';
import {buildConsolidatedColumnSchema} from '../buildConsolidatedColumnSchema';
import {globalAssetGraphPathForAssetsAndDescendants} from '../globalAssetGraphPathToString';
import {AssetKey} from '../types';
import {AssetViewDefinitionNodeFragment} from '../types/AssetView.types';
import {useLatestEvents} from '../useLatestEvents';

const byteFormatter = new Intl.NumberFormat('en', {
  style: 'unit',
  unit: 'byte',
  notation: 'compact',
  unitDisplay: 'narrow',
});

export const AssetNodeOverview = ({
  assetKey,
  assetNode,
  cachedAssetNode,
  upstream,
  downstream,
  liveData,
  dependsOnSelf,
}: {
  assetKey: AssetKey;
  assetNode: AssetViewDefinitionNodeFragment | undefined | null;
  cachedAssetNode: WorkspaceAssetNode | undefined | null;
  upstream: WorkspaceAssetNode[] | null;
  downstream: WorkspaceAssetNode[] | null;
  liveData: LiveDataForNode | undefined;
  dependsOnSelf: boolean;
}) => {
  const cachedOrLiveAssetNode = assetNode ?? cachedAssetNode;
  const repoAddress = cachedOrLiveAssetNode
    ? buildRepoAddress(
        cachedOrLiveAssetNode.repository.name,
        cachedOrLiveAssetNode.repository.location.name,
      )
    : null;
  const location = useRepositoryLocationForAddress(repoAddress);

  const {assetMetadata} = metadataForAssetNode(assetNode);

  const assetNodeLoadTimestamp = location ? location.updatedTimestamp * 1000 : undefined;

  const {materialization, observation, loading} = useLatestEvents(
    assetKey,
    assetNodeLoadTimestamp,
    liveData,
  );

  // Start loading neighboring assets data immediately to avoid waterfall.
  useAssetsLiveData(
    useMemo(
      () => [
        ...(downstream || []).map((node) => node.assetKey),
        ...(upstream || []).map((node) => node.assetKey),
      ],
      [downstream, upstream],
    ),
  );

  if (loading || !cachedOrLiveAssetNode) {
    return <AssetNodeOverviewLoading />;
  }

  const {tableSchema, tableSchemaLoadTimestamp} = buildConsolidatedColumnSchema({
    materialization,
    definition: assetNode,
    definitionLoadTimestamp: assetNodeLoadTimestamp,
  });

  const findCanonicalIntMeta = (
    predicate: (entry: MetadataEntryLabelOnly) => boolean,
  ): IntMetadataEntry | undefined =>
    (materialization?.metadataEntries.find(predicate) ??
      observation?.metadataEntries.find(predicate) ??
      assetNode?.metadataEntries.find(predicate)) as IntMetadataEntry | undefined;

  const rowCountMeta = findCanonicalIntMeta(isCanonicalRowCountMetadataEntry);
  const sizeBytesMeta = findCanonicalIntMeta(isCanonicalSizeBytesMetadataEntry);
  const queryCountMeta = findCanonicalIntMeta(isCanonicalQueryCountMetadataEntry);

  // The live data does not include a partition, but the timestamp on the live data triggers
  // an update of `observation` and `materialization`, so they should be in sync. To make sure
  // we never display incorrect data we verify that the timestamps match.
  const liveDataPartition = assetNode?.isObservable
    ? partitionIfMatching(liveData?.lastObservation, observation)
    : partitionIfMatching(liveData?.lastMaterialization, materialization);

  const internalFreshnessPolicy =
    cachedOrLiveAssetNode.internalFreshnessPolicy || assetNode?.internalFreshnessPolicy;

  const sections = [
    1,
    liveData?.assetChecks.length,
    internalFreshnessPolicy,
    rowCountMeta?.intValue != null,
    sizeBytesMeta?.intValue != null,
    queryCountMeta?.intValue != null,
  ].filter(Boolean).length;

  const renderStatusSection = () => (
    <Box flex={{direction: 'column', gap: 16}}>
      <Box style={{display: `grid`, gridTemplateColumns: `repeat(${sections}, minmax(0, 1fr))`}}>
        <Box flex={{direction: 'column', gap: 6}}>
          <Heading size={14} weight={600}>
            Latest {assetNode?.isObservable ? 'observation' : 'materialization'}
          </Heading>
          <Box flex={{gap: 8, alignItems: 'center'}}>
            {liveData ? (
              <SimpleStakeholderAssetStatus
                liveData={liveData}
                partition={liveDataPartition}
                // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
                assetNode={assetNode ?? cachedAssetNode!}
              />
            ) : (
              <Skeleton $height={24} $width={240} />
            )}
            {assetNode && assetNode.freshnessPolicy && (
              <OverdueTag policy={assetNode.freshnessPolicy} assetKey={assetNode.assetKey} />
            )}
          </Box>
        </Box>
        {liveData?.assetChecks.length ? (
          <Box flex={{direction: 'column', gap: 6}}>
            <Heading size={14} weight={600}>
              Latest check results
            </Heading>
            <AssetChecksStatusSummary
              liveData={liveData}
              rendering="tags"
              assetKey={cachedOrLiveAssetNode.assetKey}
            />
          </Box>
        ) : undefined}
        {internalFreshnessPolicy ? (
          <FreshnessPolicyStatus
            assetKey={cachedOrLiveAssetNode.assetKey}
            freshnessPolicy={internalFreshnessPolicy}
          />
        ) : undefined}
        {rowCountMeta?.intValue != null ? (
          <Box flex={{direction: 'column', gap: 4, alignItems: 'flex-start'}}>
            <Heading size={14} weight={600}>
              Row count
            </Heading>
            <Tag icon="table_rows">{numberFormatter.format(rowCountMeta.intValue)}</Tag>
          </Box>
        ) : undefined}
        {sizeBytesMeta?.intValue != null ? (
          <Box flex={{direction: 'column', gap: 4, alignItems: 'flex-start'}}>
            <Heading size={14} weight={600}>
              Storage
            </Heading>
            <Tag icon="database">{byteFormatter.format(sizeBytesMeta.intValue)}</Tag>
          </Box>
        ) : undefined}
        {queryCountMeta?.intValue != null ? (
          <Box flex={{direction: 'column', gap: 4, alignItems: 'flex-start'}}>
            <Heading size={14} weight={600}>
              Query count
            </Heading>
            <Tag icon="code_block">{numberFormatter.format(queryCountMeta.intValue)}</Tag>
          </Box>
        ) : undefined}
      </Box>
      {cachedOrLiveAssetNode.isPartitioned ? null : (
        <RecentUpdatesTimeline assetKey={cachedOrLiveAssetNode.assetKey} />
      )}
    </Box>
  );

  return (
    <AssetNodeOverviewContainer
      left={
        <>
          <LargeCollapsibleSection header="Status" icon="status">
            {renderStatusSection()}
          </LargeCollapsibleSection>
          <LargeCollapsibleSection header="Description" icon="sticky_note">
            {cachedOrLiveAssetNode.description ? (
              <Description description={cachedOrLiveAssetNode.description} maxHeight={260} />
            ) : (
              <SectionEmptyState
                title="No description found"
                description="You can add a description to any asset by adding a `description` argument to it."
                learnMoreLink="https://docs.dagster.io/_apidocs/assets#software-defined-assets"
              />
            )}
          </LargeCollapsibleSection>
          {tableSchema && (
            <LargeCollapsibleSection header="Columns" icon="view_column">
              <TableSchemaAssetContext.Provider
                value={{
                  assetKey: cachedOrLiveAssetNode.assetKey,
                  materializationMetadataEntries: materialization?.metadataEntries,
                  definitionMetadataEntries: assetNode?.metadataEntries,
                }}
              >
                <TableSchema
                  schema={tableSchema.schema}
                  schemaLoadTimestamp={tableSchemaLoadTimestamp}
                />
              </TableSchemaAssetContext.Provider>
            </LargeCollapsibleSection>
          )}
          <LargeCollapsibleSection header="Metadata" icon="view_list">
            <AssetEventMetadataEntriesTable
              assetKey={cachedOrLiveAssetNode.assetKey}
              showHeader
              showTimestamps
              showFilter
              hideEntriesShownOnOverview
              observations={[]}
              definitionMetadata={assetMetadata}
              definitionLoadTimestamp={assetNodeLoadTimestamp}
              assetHasDefinedPartitions={!!cachedOrLiveAssetNode.partitionDefinition}
              repoAddress={repoAddress}
              event={materialization || observation || null}
              emptyState={
                <SectionEmptyState
                  title="No metadata found"
                  description="Attach metadata to your asset definition, materializations or observations to see it here."
                  learnMoreLink="https://docs.dagster.io/concepts/assets/software-defined-assets#attaching-definition-metadata"
                />
              }
            />
          </LargeCollapsibleSection>
          <LargeCollapsibleSection
            header="Lineage"
            icon="account_tree"
            right={
              <Link
                to={globalAssetGraphPathForAssetsAndDescendants([cachedOrLiveAssetNode.assetKey])}
                onClick={(e) => e.stopPropagation()}
              >
                <Box flex={{gap: 4, alignItems: 'center'}}>View in graph</Box>
              </Link>
            }
          >
            <LineageSection
              downstream={downstream}
              upstream={upstream}
              dependsOnSelf={dependsOnSelf}
            />
          </LargeCollapsibleSection>
        </>
      }
      right={
        <>
          <LargeCollapsibleSection header="Definition" icon="info">
            <DefinitionSection
              repoAddress={repoAddress}
              location={location}
              assetNode={assetNode}
              cachedOrLiveAssetNode={cachedOrLiveAssetNode}
              storageAddress={cachedAssetNode?.storageAddress ?? null}
            />
          </LargeCollapsibleSection>
          <LargeCollapsibleSection header="Automation details" icon="automation_condition">
            <AutomationDetailsSection
              repoAddress={repoAddress}
              assetNode={assetNode}
              cachedOrLiveAssetNode={cachedOrLiveAssetNode}
            />
          </LargeCollapsibleSection>
          {internalFreshnessPolicy ? (
            <LargeCollapsibleSection header="Freshness policy" icon="freshness">
              <FreshnessPolicySection
                assetKey={cachedOrLiveAssetNode.assetKey}
                policy={internalFreshnessPolicy}
              />
            </LargeCollapsibleSection>
          ) : null}
          {cachedOrLiveAssetNode.isExecutable ? (
            <LargeCollapsibleSection header="Compute details" icon="settings" collapsedByDefault>
              <ComputeDetailsSection repoAddress={repoAddress} assetNode={assetNode} />
            </LargeCollapsibleSection>
          ) : null}
          <AssetAlertsSection repoAddress={repoAddress} assetNode={cachedOrLiveAssetNode} />
        </>
      }
    />
  );
};

const AssetNodeOverviewContainer = ({
  left,
  right,
}: {
  left: React.ReactNode;
  right: React.ReactNode;
}) => (
  <Box
    flex={{direction: 'row', gap: 8}}
    style={{width: '100%', height: '100%', overflow: 'hidden'}}
  >
    <Box
      flex={{direction: 'column'}}
      padding={{horizontal: 24, vertical: 12}}
      style={{flex: 1, minWidth: 0, overflowY: 'auto'}}
    >
      {left}
    </Box>
    <Box
      border={{side: 'left'}}
      flex={{direction: 'column'}}
      padding={{left: 24, vertical: 12, right: 12}}
      style={{width: '30%', minWidth: 250, overflowY: 'auto'}}
    >
      {right}
    </Box>
  </Box>
);

export const AssetNodeOverviewNonSDA = ({
  assetKey,
  lastMaterialization,
}: {
  assetKey: AssetKey;
  lastMaterialization: {timestamp: string; runId: string} | null | undefined;
}) => {
  return (
    <AssetNodeOverviewContainer
      left={
        <LargeCollapsibleSection header="Status" icon="status">
          <Box flex={{direction: 'column', gap: 16}}>
            <div>
              {lastMaterialization ? (
                <MaterializationTag
                  assetKey={assetKey}
                  event={lastMaterialization}
                  stepKey={null}
                />
              ) : (
                <Text size={12} color="textLighter">
                  Never materialized
                </Text>
              )}
            </div>
            <RecentUpdatesTimeline assetKey={assetKey} />
          </Box>
        </LargeCollapsibleSection>
      }
      right={
        <LargeCollapsibleSection header="Definition" icon="info">
          <Box flex={{direction: 'column', gap: 12}}>
            <NonIdealState
              shrinkable
              description="This asset doesn't have a software definition in any of your code locations."
              icon="materialization"
              title=""
            />
          </Box>
        </LargeCollapsibleSection>
      }
    />
  );
};

export const AssetNodeOverviewLoading = () => (
  <AssetNodeOverviewContainer
    left={
      <>
        <LargeCollapsibleSection header="Status" icon="status">
          <Box flex={{direction: 'column', gap: 6}}>
            <Skeleton $height={20} $width={170} />
            <Skeleton $height={24} $width={240} />
          </Box>
        </LargeCollapsibleSection>
        <LargeCollapsibleSection header="Description" icon="sticky_note">
          <Box flex={{direction: 'column', gap: 6}}>
            <Skeleton $height={16} $width="90%" />
            <Skeleton $height={16} />
            <Skeleton $height={16} $width="60%" />
          </Box>
        </LargeCollapsibleSection>
      </>
    }
    right={
      <LargeCollapsibleSection header="Definition" icon="info">
        <Box flex={{direction: 'column', gap: 12}}>
          <AttributeAndValue label={<Skeleton $width={60} />}>
            <Skeleton $height={20} $width={220} />
          </AttributeAndValue>
          <AttributeAndValue label={<Skeleton $width={80} />}>
            <Skeleton $height={24} $width={180} />
          </AttributeAndValue>
          <AttributeAndValue label={<Skeleton $width={120} />}>
            <Skeleton $height={24} $width={240} />
          </AttributeAndValue>
        </Box>
      </LargeCollapsibleSection>
    }
  />
);

function partitionIfMatching(
  liveDataEvent: {timestamp: string} | null | undefined,
  event: {timestamp: string; partition: string | null} | undefined,
) {
  if (!liveDataEvent || !event) {
    return null;
  }
  return liveDataEvent.timestamp === event.timestamp ? event.partition : null;
}
