/** Internal type. DO NOT USE DIRECTLY. */
type Exact<T extends {[key: string]: unknown}> = {[K in keyof T]: T[K]};
/** Internal type. DO NOT USE DIRECTLY. */
export type Incremental<T> =
  | T
  | {[P in keyof T]?: P extends ' $fragmentName' | '__typename' ? T[P] : never};
// Generated GraphQL types, do not edit manually.

import * as Types from '../../graphql/types';

export type ConfiguredValueType = 'ENV_VAR' | 'SECRET' | 'VALUE';

export type NestedResourceType = 'ANONYMOUS' | 'TOP_LEVEL';

export type ResourceSelector = {
  repositoryLocationName: string;
  repositoryName: string;
  resourceName: string;
};

export type ResourceDetailsFragment = {
  __typename: 'ResourceDetails';
  id: string;
  name: string;
  description: string | null;
  schedulesUsing: Array<string>;
  sensorsUsing: Array<string>;
  resourceType: string;
  configFields: Array<{
    __typename: 'ConfigTypeField';
    name: string;
    description: string | null;
    configTypeKey: string;
    isRequired: boolean;
    defaultValueAsJson: string | null;
  }>;
  configuredValues: Array<{
    __typename: 'ConfiguredValue';
    key: string;
    value: string;
    type: Types.ConfiguredValueType;
  }>;
  nestedResources: Array<{
    __typename: 'NestedResourceEntry';
    name: string;
    type: Types.NestedResourceType;
    resource: {
      __typename: 'ResourceDetails';
      id: string;
      name: string;
      resourceType: string;
      description: string | null;
    } | null;
  }>;
  parentResources: Array<{
    __typename: 'NestedResourceEntry';
    name: string;
    resource: {
      __typename: 'ResourceDetails';
      id: string;
      name: string;
      resourceType: string;
      description: string | null;
    } | null;
  }>;
  assetKeysUsing: Array<{__typename: 'AssetKey'; path: Array<string>}>;
  jobsOpsUsing: Array<{__typename: 'JobWithOps'; jobName: string; opHandleIDs: Array<string>}>;
};

export type ResourceRootQueryVariables = Exact<{
  resourceSelector: Types.ResourceSelector;
}>;

export type ResourceRootQuery = {
  __typename: 'Query';
  topLevelResourceDetailsOrError:
    | {
        __typename: 'PythonError';
        message: string;
        stack: Array<string>;
        errorChain: Array<{
          __typename: 'ErrorChainLink';
          isExplicitLink: boolean;
          error: {__typename: 'PythonError'; message: string; stack: Array<string>};
        }>;
      }
    | {
        __typename: 'ResourceDetails';
        id: string;
        name: string;
        description: string | null;
        schedulesUsing: Array<string>;
        sensorsUsing: Array<string>;
        resourceType: string;
        configFields: Array<{
          __typename: 'ConfigTypeField';
          name: string;
          description: string | null;
          configTypeKey: string;
          isRequired: boolean;
          defaultValueAsJson: string | null;
        }>;
        configuredValues: Array<{
          __typename: 'ConfiguredValue';
          key: string;
          value: string;
          type: Types.ConfiguredValueType;
        }>;
        nestedResources: Array<{
          __typename: 'NestedResourceEntry';
          name: string;
          type: Types.NestedResourceType;
          resource: {
            __typename: 'ResourceDetails';
            id: string;
            name: string;
            resourceType: string;
            description: string | null;
          } | null;
        }>;
        parentResources: Array<{
          __typename: 'NestedResourceEntry';
          name: string;
          resource: {
            __typename: 'ResourceDetails';
            id: string;
            name: string;
            resourceType: string;
            description: string | null;
          } | null;
        }>;
        assetKeysUsing: Array<{__typename: 'AssetKey'; path: Array<string>}>;
        jobsOpsUsing: Array<{
          __typename: 'JobWithOps';
          jobName: string;
          opHandleIDs: Array<string>;
        }>;
      }
    | {__typename: 'ResourceNotFoundError'};
};

export const ResourceRootQueryVersion = '72539e6a9e0954af4c08a716fca0de15e9506debb465fa8b472762e23368c8f3';
