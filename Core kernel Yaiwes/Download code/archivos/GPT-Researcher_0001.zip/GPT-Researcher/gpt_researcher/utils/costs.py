"""Cost estimation utilities for LLM API usage."""

from __future__ import annotations

import logging
from collections.abc import Mapping
from typing import Any

import tiktoken

# Per OpenAI Pricing Page: https://openai.com/api/pricing/
ENCODING_MODEL = "o200k_base"
INPUT_COST_PER_TOKEN = 0.000005
OUTPUT_COST_PER_TOKEN = 0.000015
IMAGE_INFERENCE_COST = 0.003825
EMBEDDING_COST = 0.02 / 1000000  # Assumes new ada-3-small

# OpenAI's automatic prompt caching bills the cached portion of input
# tokens at a discount off the standard input rate (currently 50% across
# the GPT-4o/4.1/5 families). Kept as a single constant since OpenAI has
# used a flat 50% cache discount across all its cached models to date;
# revisit if a future model introduces a different ratio.
# https://openai.com/api/pricing/
OPENAI_CACHED_INPUT_DISCOUNT = 0.5

logger = logging.getLogger(__name__)

# (patterns, input $/MTok, output $/MTok) - first match wins, so more
# specific patterns (e.g. "-mini") must come before their base model.
# Prices as of July 2026: https://openai.com/api/pricing/
OPENAI_MODEL_PRICING = (
    (("gpt-5.5-pro",), 30.0, 180.0),
    (("gpt-5.5",), 5.0, 30.0),
    (("gpt-5.4-pro",), 30.0, 180.0),
    (("gpt-5.4-mini",), 0.75, 4.5),
    (("gpt-5.4-nano",), 0.2, 1.25),
    (("gpt-5.4",), 2.5, 15.0),
    (("gpt-5-mini",), 0.25, 2.0),
    (("gpt-5-nano",), 0.05, 0.4),
    (("gpt-5",), 1.25, 10.0),
    (("gpt-4.1-mini",), 0.4, 1.6),
    (("gpt-4.1-nano",), 0.1, 0.4),
    (("gpt-4.1",), 2.0, 8.0),
    (("gpt-4o-mini",), 0.15, 0.6),
    (("gpt-4o",), 2.5, 10.0),
    (("o4-mini",), 1.1, 4.4),
    (("o3-mini",), 1.1, 4.4),
    (("o3",), 2.0, 8.0),
)

ANTHROPIC_MODEL_PRICING = (
    (("claude-opus-4-7",), 5.0, 25.0),
    (("claude-opus-4-6",), 5.0, 25.0),
    (("claude-opus-4-5", "claude-4-opus"), 5.0, 25.0),
    (("claude-opus-4-1",), 15.0, 75.0),
    (("claude-opus-4",), 15.0, 75.0),
    (("claude-sonnet-4-6",), 3.0, 15.0),
    (("claude-sonnet-4-5", "claude-4-sonnet"), 3.0, 15.0),
    (("claude-sonnet-4",), 3.0, 15.0),
    (("claude-haiku-4-5",), 1.0, 5.0),
    (("claude-3-5-haiku",), 0.8, 4.0),
)

ANTHROPIC_US_INFERENCE_GEO_MODELS = (
    "claude-opus-4-7",
    "claude-opus-4-6",
    "claude-sonnet-4-6",
)


def estimate_llm_cost(input_content: str, output_content: str) -> float:
    """Estimate the cost of an LLM API call based on input and output content.

    Cost estimation is based on OpenAI pricing and may vary for other models.

    Args:
        input_content: The input text sent to the LLM.
        output_content: The output text received from the LLM.

    Returns:
        The estimated cost in USD.
    """
    # Callbacks and stream paths may pass None before content is available.
    # tiktoken.encode(None) raises TypeError and abort sq col of the caller.
    if input_content is None:
        input_content = ""
    if output_content is None:
        output_content = ""
    if not isinstance(input_content, str):
        input_content = str(input_content)
    if not isinstance(output_content, str):
        output_content = str(output_content)
    encoding = tiktoken.get_encoding(ENCODING_MODEL)
    input_tokens = encoding.encode(input_content)
    output_tokens = encoding.encode(output_content)
    input_costs = len(input_tokens) * INPUT_COST_PER_TOKEN
    output_costs = len(output_tokens) * OUTPUT_COST_PER_TOKEN
    return input_costs + output_costs


def _mapping_to_dict(value: Mapping[str, Any] | Any | None) -> dict[str, Any]:
    if value is None:
        return {}
    if isinstance(value, Mapping):
        return dict(value)
    if hasattr(value, "model_dump"):
        return dict(value.model_dump())
    return {}


def _resolve_anthropic_model_name(
    model: str | None,
    response_metadata: Mapping[str, Any] | None = None,
) -> str:
    metadata = _mapping_to_dict(response_metadata)
    return str(
        metadata.get("model")
        or metadata.get("model_name")
        or model
        or ""
    ).lower()


def _coerce_token_count(value: Any) -> int:
    if value is None:
        return 0
    try:
        return int(value)
    except (TypeError, ValueError):
        return 0


def _extract_anthropic_usage(
    response_metadata: Mapping[str, Any] | None = None,
    usage_metadata: Mapping[str, Any] | Any | None = None,
) -> dict[str, int] | None:
    """Extract Anthropic usage including prompt-cache token fields.

    Anthropic Messages usage may include:
    - input_tokens / output_tokens
    - cache_creation_input_tokens (billed ~1.25x input)
    - cache_read_input_tokens (billed ~0.1x input)
    """
    metadata = _mapping_to_dict(response_metadata)
    usage = _mapping_to_dict(metadata.get("usage"))

    def _from_usage(usage_dict: dict[str, Any]) -> dict[str, int] | None:
        input_tokens = usage_dict.get("input_tokens")
        output_tokens = usage_dict.get("output_tokens")
        if input_tokens is None or output_tokens is None:
            return None
        return {
            "input_tokens": int(input_tokens),
            "output_tokens": int(output_tokens),
            "cache_creation_input_tokens": _coerce_token_count(
                usage_dict.get("cache_creation_input_tokens")
            ),
            "cache_read_input_tokens": _coerce_token_count(
                usage_dict.get("cache_read_input_tokens")
            ),
        }

    if usage:
        parsed = _from_usage(usage)
        if parsed is not None:
            return parsed

    usage = _mapping_to_dict(usage_metadata)
    return _from_usage(usage)


def _get_anthropic_pricing(model_name: str) -> tuple[float, float] | None:
    normalized_model_name = model_name.lower()
    for patterns, input_price_per_mtok, output_price_per_mtok in ANTHROPIC_MODEL_PRICING:
        if any(pattern in normalized_model_name for pattern in patterns):
            return input_price_per_mtok, output_price_per_mtok
    return None


def _get_anthropic_pricing_multiplier(
    model_name: str,
    request_options: Mapping[str, Any] | None = None,
) -> float:
    if not request_options:
        return 1.0

    inference_geo = str(request_options.get("inference_geo", "")).lower()
    if inference_geo != "us":
        return 1.0

    if any(pattern in model_name for pattern in ANTHROPIC_US_INFERENCE_GEO_MODELS):
        return 1.1

    return 1.0


def calculate_anthropic_cost(
    model: str | None,
    response_metadata: Mapping[str, Any] | None = None,
    usage_metadata: Mapping[str, Any] | Any | None = None,
    request_options: Mapping[str, Any] | None = None,
) -> float | None:
    usage = _extract_anthropic_usage(response_metadata=response_metadata, usage_metadata=usage_metadata)
    if not usage:
        return None

    model_name = _resolve_anthropic_model_name(model=model, response_metadata=response_metadata)
    pricing = _get_anthropic_pricing(model_name)
    if pricing is None:
        logger.warning(
            "Missing Anthropic pricing rule for model '%s'; falling back to token estimator.",
            model_name or model,
        )
        return None

    input_price_per_mtok, output_price_per_mtok = pricing
    multiplier = _get_anthropic_pricing_multiplier(model_name, request_options=request_options)
    # Anthropic prompt caching: cache writes ~1.25x input, cache reads ~0.1x input.
    # input_tokens is non-cache input only; cache fields are billed separately.
    cache_write_price_per_mtok = input_price_per_mtok * 1.25
    cache_read_price_per_mtok = input_price_per_mtok * 0.1
    input_cost = usage["input_tokens"] * input_price_per_mtok / 1_000_000
    cache_write_cost = (
        usage.get("cache_creation_input_tokens", 0) * cache_write_price_per_mtok / 1_000_000
    )
    cache_read_cost = (
        usage.get("cache_read_input_tokens", 0) * cache_read_price_per_mtok / 1_000_000
    )
    output_cost = usage["output_tokens"] * output_price_per_mtok / 1_000_000
    return (input_cost + cache_write_cost + cache_read_cost + output_cost) * multiplier


def _extract_usage_tokens(
    usage_metadata: Mapping[str, Any] | Any | None,
) -> tuple[int, int, int] | None:
    """Returns (input_tokens, output_tokens, cache_read_tokens).

    cache_read_tokens is the portion of input_tokens that hit the
    provider's prompt cache (LangChain's standardized
    ``input_token_details.cache_read``) and should be billed at
    OPENAI_CACHED_INPUT_DISCOUNT instead of the standard input rate.
    Defaults to 0 when the response doesn't report cache details, so
    non-cached calls are unaffected.
    """
    usage = _mapping_to_dict(usage_metadata)
    input_tokens = usage.get("input_tokens")
    output_tokens = usage.get("output_tokens")
    if input_tokens is None or output_tokens is None:
        return None

    input_token_details = _mapping_to_dict(usage.get("input_token_details"))
    cache_read_tokens = int(input_token_details.get("cache_read") or 0)

    return int(input_tokens), int(output_tokens), cache_read_tokens


def _get_openai_pricing(model: str | None) -> tuple[float, float] | None:
    normalized = (model or "").lower()
    for patterns, input_price_per_mtok, output_price_per_mtok in OPENAI_MODEL_PRICING:
        if any(pattern in normalized for pattern in patterns):
            return input_price_per_mtok, output_price_per_mtok
    return None


def calculate_llm_cost(
    llm_provider: str | None,
    model: str | None,
    input_content: str,
    output_content: str,
    response_metadata: Mapping[str, Any] | None = None,
    usage_metadata: Mapping[str, Any] | Any | None = None,
    request_options: Mapping[str, Any] | None = None,
) -> float:
    if llm_provider == "anthropic":
        anthropic_cost = calculate_anthropic_cost(
            model=model,
            response_metadata=response_metadata,
            usage_metadata=usage_metadata,
            request_options=request_options,
        )
        if anthropic_cost is not None:
            return anthropic_cost

    # Prefer the API-reported token usage over tiktoken estimates on
    # serialized message dicts; the latter overcounts input and misses
    # reasoning tokens entirely.
    usage_tokens = _extract_usage_tokens(usage_metadata)
    if usage_tokens is not None:
        input_tokens, output_tokens, cache_read_tokens = usage_tokens
        # cache_read_tokens is a subset of input_tokens, not additional
        # tokens -- split input_tokens into its non-cached and cached
        # portions so the cached share is priced at the discount rate
        # instead of the full input rate.
        non_cached_input_tokens = input_tokens - cache_read_tokens
        pricing = _get_openai_pricing(model)
        if pricing is not None:
            input_price_per_mtok, output_price_per_mtok = pricing
            non_cached_cost = non_cached_input_tokens * input_price_per_mtok
            cached_cost = (
                cache_read_tokens
                * input_price_per_mtok
                * OPENAI_CACHED_INPUT_DISCOUNT
            )
            output_cost = output_tokens * output_price_per_mtok
            return (non_cached_cost + cached_cost + output_cost) / 1_000_000
        cached_cost = (
            cache_read_tokens * INPUT_COST_PER_TOKEN * OPENAI_CACHED_INPUT_DISCOUNT
        )
        non_cached_cost = non_cached_input_tokens * INPUT_COST_PER_TOKEN
        return (
            non_cached_cost
            + cached_cost
            + output_tokens * OUTPUT_COST_PER_TOKEN
        )

    return estimate_llm_cost(input_content, output_content)


def estimate_embedding_cost(model: str, docs: list) -> float:
    """Estimate the cost of embedding documents.

    Args:
        model: The embedding model name.
        docs: List of documents to embed.

    Returns:
        The estimated embedding cost in USD.
    """
    try:
        encoding = tiktoken.encoding_for_model(model)
    except KeyError:
        # tiktoken only knows OpenAI model names. Non-OpenAI embedding
        # providers (Ollama, Cohere, Nomic, HuggingFace, ...) raise KeyError
        # here, which would otherwise abort cost tracking mid-research. Fall
        # back to the default OpenAI encoding for a best-effort token estimate.
        encoding = tiktoken.get_encoding(ENCODING_MODEL)
    total_tokens = sum(len(encoding.encode(str(doc))) for doc in docs)
    return total_tokens * EMBEDDING_COST