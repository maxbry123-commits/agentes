TEST_EXIT=nonzero
