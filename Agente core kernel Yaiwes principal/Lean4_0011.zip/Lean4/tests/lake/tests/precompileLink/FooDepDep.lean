def hello := "Hello"
