def Foo.baz := "foobaz"
