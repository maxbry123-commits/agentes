def Foo.bar := "foobar"
