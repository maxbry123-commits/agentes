rm -rf work produced.*
