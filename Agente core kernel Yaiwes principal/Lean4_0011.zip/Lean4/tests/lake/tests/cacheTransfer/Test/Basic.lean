def basic := 0
