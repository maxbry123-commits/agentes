import { deploy } from "@cloudflare/deploy-helpers";
import {
	getWorkerNameFromProject,
	isNonInteractiveOrCI,
} from "@cloudflare/workers-utils";
import { analyseBundle } from "../check/commands";
import { buildContainer } from "../containers/build";
import { getNormalizedContainerOptions } from "../containers/config";
import { deployContainers } from "../containers/deploy";
import { createCommand } from "../core/create-command";
import {
	sharedDeployVersionsArgs,
	validateDeployVersionsArgs,
} from "../deployment-bundle/deploy-args";
import { buildWorker } from "../deployment-bundle/maybe-build-worker";
import {
	cleanupDestination,
	mergeDeployConfigArgs,
} from "../deployment-bundle/merge-config-args";
import { experimentalNewConfigArg } from "../experimental-config/cli-flag";
import { logger } from "../logger";
import * as metrics from "../metrics";
import { syncWorkersSite } from "../sites";
import { detectAgent } from "../utils/detect-agent";
import { getScriptName } from "../utils/getScriptName";
import { maybeRunAutoConfig, promptForMissingDeployConfig } from "./autoconfig";
import { maybeDelegateToOpenNextDeployCommand } from "./open-next";
import type { Config } from "@cloudflare/workers-utils";

export const deployCommand = createCommand({
	metadata: {
		description: "🆙 Deploy a Worker to Cloudflare",
		owner: "Workers: Deploy and Config",
		status: "stable",
		category: "Compute & AI",
	},
	positionalArgs: ["path"],
	args: {
		...experimentalNewConfigArg,
		...sharedDeployVersionsArgs,
		triggers: {
			describe: "cron schedules to attach",
			alias: ["schedule", "schedules"],
			type: "string",
			requiresArg: true,
			array: true,
		},
		routes: {
			describe: "Routes to upload",
			alias: "route",
			type: "string",
			requiresArg: true,
			array: true,
		},
		domains: {
			describe: "Custom domains to deploy to",
			alias: "domain",
			type: "string",
			requiresArg: true,
			array: true,
		},
		metafile: {
			describe:
				"Path to output build metadata from esbuild. If flag is used without a path, defaults to 'bundle-meta.json' inside the directory specified by --outdir.",
			type: "string",
			coerce: (v: string) => (!v ? true : v),
		},
		logpush: {
			type: "boolean",
			describe:
				"Send Trace Events from this Worker to Workers Logpush.\nThis will not configure a corresponding Logpush job automatically.",
		},
		"old-asset-ttl": {
			describe:
				"Expire old assets in given seconds rather than immediate deletion.",
			type: "number",
		},
		"dispatch-namespace": {
			describe:
				"Name of a dispatch namespace to deploy the Worker to (Workers for Platforms)",
			type: "string",
		},
		"containers-rollout": {
			describe:
				"Rollout strategy for Containers changes. If set to immediate, it will override `rollout_percentage_steps` if configured and roll out to 100% of instances in one step. If set to none, the Worker will be deployed without building or updating any Containers.",
			choices: ["immediate", "gradual", "none"] as const,
		},
		autoconfig: {
			describe:
				"Enables framework detection and automatic configuration when deploying",
			type: "boolean",
			default: true,
		},
	},
	behaviour: {
		supportTemporary: true,
		useConfigRedirectIfAvailable: true,
		overrideExperimentalFlags: (args) => ({
			MULTIWORKER: false,
			RESOURCES_PROVISION: args.experimentalProvision ?? false,
			AUTOCREATE_RESOURCES: args.experimentalAutoCreate,
		}),
		warnIfMultipleEnvsConfiguredButNoneSpecified: true,
		printMetricsBanner: true,
		suggestSkillsAfterHandler: true,
	},
	validateArgs(args) {
		validateDeployVersionsArgs(args, "deploy");
	},
	async handler(args, { config }) {
		await runDeployCommandHandler(args, { config });
	},
});

export type DeployArgs = (typeof deployCommand)["args"];

export async function runDeployCommandHandler(
	args: DeployArgs,
	{
		config,
		pagesToWorkersDelegation = false,
	}: { config: Config; pagesToWorkersDelegation?: boolean }
): Promise<void> {
	const detectedAgent = detectAgent();
	const shouldUseProjectName =
		detectedAgent.isAgent && !args.name && !config.name;

	// Capture whether this project can prove it owns the target Worker name,
	// BEFORE autoconfig generates or rewrites the config. Ownership is proven by
	// a config file that names the Worker; without one a same-named remote Worker
	// could be a collision rather than a redeploy.
	//
	// We guard both agent-generated names and the Pages-to-Workers delegation.
	// In either case an existing Worker with the same name may be a different
	// resource that we must not clobber. Repeat deploys are unaffected because
	// the first one writes a config file (so `configPath` is then set).
	//
	// Plain `wrangler deploy` is NOT guarded, even in CI with an autoconfigured
	// name: autoconfigured projects are routinely redeployed in CI (e.g. when the
	// auto-generated config PR has not been merged), and blocking that regressed
	// those workflows. See `failIfWorkerNameTaken` in preUploadApiChecks.
	const nameOwnershipUnverified =
		!config.configPath &&
		((isNonInteractiveOrCI() && pagesToWorkersDelegation) ||
			shouldUseProjectName);

	// --- Step 0. Auto-config --- //
	const autoConfigResult = await maybeRunAutoConfig(args, config, {
		skipConfirmations: pagesToWorkersDelegation || detectedAgent.isAgent,
	});
	if (autoConfigResult.aborted) {
		return;
	}
	config = autoConfigResult.config;

	// Interatively handle missing/incorrect --assets, --script, --name, --compatibility-date
	args = await promptForMissingDeployConfig(args, config, {
		useProjectName: detectedAgent.isAgent,
	});
	if (shouldUseProjectName) {
		const workerName = args.name ?? config.name;
		logger.log(
			`Using the project name "${workerName}" as the Worker name. To change it, set the \`name\` field in your Wrangler configuration file or pass \`--name <name>\` when deploying.`
		);
	}

	// Needs to happen after auto-config logic to capture newly auto-configured open-next apps.
	// As a precaution we're gating the feature under the autoconfig flag for the time being.
	// If the user explicitly provided a --config path, they are targeting a specific Worker config and we should not delegate
	if (
		!pagesToWorkersDelegation &&
		args.autoconfig &&
		!args.config &&
		!args.dryRun &&
		(await maybeDelegateToOpenNextDeployCommand(process.cwd()))
	) {
		return;
	}

	// Merge CLI args with config into props for building and deploying
	const { props, buildProps } = await mergeDeployConfigArgs(args, config);
	props.failIfWorkerNameTaken = nameOwnershipUnverified;
	props.autoRegisterWorkersDevSubdomain = detectedAgent.isAgent
		? getWorkerNameFromProject(process.cwd())
		: undefined;

	try {
		// Derive workerNameOverridden by comparing pre-merge name with post-merge name
		const preMergeName = getScriptName(args, config);
		props.workerNameOverridden =
			props.name !== undefined && props.name !== preMergeName;

		const beforeUpload = Date.now();

		const buildResult = await buildWorker(buildProps, config);

		const { sourceMapSize, assetUploadStats } = await deploy(
			props,
			config,
			buildResult,
			{
				syncWorkersSite,
				getNormalizedContainerOptions,
				buildContainer,
				deployContainers,
				analyseBundle,
			}
		);

		metrics.sendMetricsEvent(
			"deploy worker script",
			{
				usesTypeScript: /\.tsx?$/.test(props.entry.file),
				durationMs: Date.now() - beforeUpload,
				sourceMapSize,
				...assetUploadStats,
			},
			{
				sendMetrics: config.send_metrics,
			}
		);
	} finally {
		cleanupDestination(buildProps.destination);
	}
}
