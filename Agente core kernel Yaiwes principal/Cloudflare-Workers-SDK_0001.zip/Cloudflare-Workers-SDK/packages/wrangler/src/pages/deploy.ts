import { execFileSync, execSync } from "node:child_process";
import { writeFile } from "node:fs/promises";
import path from "node:path";
import { getCloudflareAccountIdFromEnv } from "@cloudflare/workers-auth";
import {
	COMPLIANCE_REGION_CONFIG_PUBLIC,
	configFileName,
	FatalError,
	findWranglerConfig,
	ParseError,
	UserError,
} from "@cloudflare/workers-utils";
import { deploy } from "../api/pages/deploy";
import { fetchResult } from "../cfetch";
import { analyseBundle } from "../check/commands";
import { readPagesConfig } from "../config";
import { getConfigCache, saveToConfigCache } from "../config-cache";
import { createAlias, createCommand } from "../core/create-command";
import { prompt, select } from "../dialogs";
import { logger } from "../logger";
import * as metrics from "../metrics";
import { writeOutput } from "../output";
import { getAccountFromCache, requireAuth } from "../user";
import { diagnoseStartupError } from "../utils/friendly-validator-errors";
import {
	MAX_DEPLOYMENT_STATUS_ATTEMPTS,
	PAGES_CONFIG_CACHE_FILENAME,
} from "./constants";
import {
	logPagesToWorkersForceOptOutNotice,
	maybeDelegatePagesToWorkers,
} from "./delegate-to-workers";
import { EXIT_CODE_INVALID_PAGES_CONFIG } from "./errors";
import { listProjects } from "./projects";
import { promptSelectProject } from "./prompt-select-project";
import { runPagesToWorkersDeploy } from "./run-workers-deploy";
import { getPagesProjectRoot, getPagesTmpDir } from "./utils";
import type { PagesConfigCache } from "./types";
import type {
	Deployment,
	DeploymentStage,
	Project,
	UnifiedDeploymentLogMessages,
} from "@cloudflare/types";
import type { Config } from "@cloudflare/workers-utils";

export const pagesDeploymentCreateCommand = createAlias({
	aliasOf: "wrangler pages deploy",
});

export const pagesPublishCommand = createAlias({
	aliasOf: "wrangler pages deploy",
	metadata: {
		deprecated: true,
		hidden: true,
	},
});

export const pagesDeployCommand = createCommand({
	metadata: {
		description: "Deploy a directory of static assets as a Pages deployment",
		status: "stable",
		owner: "Workers: Authoring and Testing",
		hideGlobalFlags: ["config", "env"],
	},
	behaviour: {
		provideConfig: false,
	},
	args: {
		directory: {
			type: "string",
			description: "The directory of static files to upload",
		},
		"project-name": {
			type: "string",
			description: "The name of the project you want to deploy to",
		},
		branch: {
			type: "string",
			description: "The name of the branch you want to deploy to",
		},
		"commit-hash": {
			type: "string",
			description: "The SHA to attach to this deployment",
		},
		"commit-message": {
			type: "string",
			description: "The commit message to attach to this deployment",
		},
		"commit-dirty": {
			type: "boolean",
			description:
				"Whether or not the workspace should be considered dirty for this deployment",
		},
		"skip-caching": {
			type: "boolean",
			description: "Skip asset caching which speeds up builds",
		},
		bundle: {
			type: "boolean",
			default: undefined,
			hidden: true,
		},
		"no-bundle": {
			type: "boolean",
			default: undefined,
			description: "Whether to run bundling on `_worker.js` before deploying",
		},
		config: {
			description:
				"Pages does not support custom Wrangler configuration file locations",
			type: "string",
			hidden: true,
		},
		"upload-source-maps": {
			type: "boolean",
			default: false,
			description:
				"Whether to upload any server-side sourcemaps with this deployment",
		},
		force: {
			type: "boolean",
			default: false,
			hidden: true,
			description:
				"Deploy directly to Cloudflare Pages, bypassing the automatic delegation to Cloudflare Workers for new static projects",
		},
	},
	positionalArgs: ["directory"],
	async handler(args) {
		let { branch, commitHash, commitMessage, commitDirty } = args;

		// Check for deprecated `wrangler pages publish` command
		if (args._[1] === "publish") {
			logger.warn(
				"`wrangler pages publish` is deprecated and will be removed in the next major version.\nPlease use `wrangler pages deploy` instead, which accepts exactly the same arguments."
			);
		}

		if (args.config) {
			throw new FatalError(
				"Pages does not support custom paths for the Wrangler configuration file",
				{ code: 1, telemetryMessage: "pages deploy custom config unsupported" }
			);
		}

		if (args.env) {
			throw new FatalError(
				"Pages does not support targeting an environment with the --env flag. Use the --branch flag to target your production or preview branch",
				{ code: 1, telemetryMessage: "pages deploy env unsupported" }
			);
		}

		let config: Config | undefined;
		const { configPath } = findWranglerConfig(process.cwd(), {
			useRedirectIfAvailable: true,
		});

		try {
			/*
			 * this reads the config file with `env` set to `undefined`, which will
			 * return the top-level config. This contains all the information we
			 * need for now. We will perform a second config file read later
			 * in `/api/pages/deploy`, that will get the environment specific config
			 */
			config = readPagesConfig({ ...args, config: configPath, env: undefined });
		} catch (err) {
			if (
				!(
					err instanceof FatalError &&
					err.code === EXIT_CODE_INVALID_PAGES_CONFIG
				)
			) {
				throw err;
			}
		}

		const directory = args.directory ?? config?.pages_build_output_dir;
		if (!directory) {
			maybeWarnAboutIgnoredConfigFile(configPath, config);
			throw new FatalError(
				`Must specify a directory of assets to deploy. Please specify the [<directory>] argument in the \`pages deploy\` command, or configure \`pages_build_output_dir\` in your ${configFileName(configPath)} file.`,
				{ code: 1, telemetryMessage: "pages deploy missing directory" }
			);
		}

		const configCache = getConfigCache<PagesConfigCache>(
			PAGES_CONFIG_CACHE_FILENAME
		);
		const envAccountId = getCloudflareAccountIdFromEnv();
		const accountId = await requireAuth({
			...configCache,
			...(envAccountId ? { account_id: envAccountId } : {}),
		});

		let projectName =
			args.projectName ?? config?.name ?? configCache.project_name;
		let isExistingProject = true;

		if (projectName) {
			try {
				await fetchResult<Project>(
					COMPLIANCE_REGION_CONFIG_PUBLIC,
					`/accounts/${accountId}/pages/projects/${projectName}`
				);
			} catch (err) {
				// code `8000007` corresponds to project not found
				if ((err as { code: number }).code !== 8000007) {
					maybeWarnAboutIgnoredConfigFile(configPath, config);
					throw err;
				} else {
					isExistingProject = false;
				}
			}
		}

		// When run by an AI agent, delegate brand-new static Pages deploys to a
		// Workers static-assets deploy. Existing projects, projects using
		// unsupported Pages features, and `--force` are never delegated.
		const delegation = await maybeDelegatePagesToWorkers({
			command: "deploy",
			projectPath: process.cwd(),
			assetsDirectory: directory,
			accountHasPagesProjects: async () =>
				(await listProjects({ accountId })).length > 0,
			force: args.force,
			projectName,
			unsupportedArgs: getUnsupportedDeployDelegateArgs(args),
		});
		if (delegation.delegate) {
			await runPagesToWorkersDeploy(delegation);
			return;
		}

		const isInteractive = process.stdin.isTTY;
		if ((!projectName || !isExistingProject) && isInteractive) {
			let existingOrNew: "existing" | "new" = "new";

			/*
			 * if no project name was specified, we should give users the option
			 * of creating a new project, or selecting an existing one, if any are
			 * associated with their `accountId`
			 */
			if (!projectName) {
				// get projects that are not connected to an SCM source (GitHub/GitLab)
				// aka direct-upload projects
				const duProjects = (await listProjects({ accountId })).filter(
					(project) => !project.source
				);

				if (duProjects.length > 0) {
					const message =
						"No project specified. Would you like to create one or use an existing project?";
					const items: NewOrExistingItem[] = [
						{
							key: "new",
							label: "Create a new project",
							value: "new",
						},
						{
							key: "existing",
							label: "Use an existing project",
							value: "existing",
						},
					];

					existingOrNew = await promptSelectExistingOrNewProject(
						message,
						items
					);
				}
			}

			/*
			 * if project name was specified, but no project with that name is
			 * associated with their `accountId`, we should offer users the option
			 * to create that project for them
			 */
			if (projectName !== undefined && !isExistingProject) {
				const message = `The project you specified does not exist: "${projectName}". Would you like to create it?`;
				const items: NewOrExistingItem[] = [
					{
						key: "new",
						label: "Create a new project",
						value: "new",
					},
				];
				existingOrNew = await promptSelectExistingOrNewProject(message, items);
			}

			switch (existingOrNew) {
				case "existing": {
					projectName = await promptSelectProject({ accountId });
					break;
				}
				case "new": {
					if (!projectName) {
						projectName = await prompt("Enter the name of your new project:");

						if (!projectName) {
							maybeWarnAboutIgnoredConfigFile(configPath, config);
							throw new UserError(
								"Missing Pages project name. Use --project-name <name> or set the name in your Wrangler configuration file.",
								{
									telemetryMessage: "pages deploy missing project name",
								}
							);
						}
					}

					logger.debug(
						"pages deploy: Detecting git repository for production branch suggestion..."
					);
					let isGitDir = true;
					try {
						execSync(`git rev-parse --is-inside-work-tree`, {
							stdio: "ignore",
						});
						logger.debug(
							"pages deploy: Git repository detected for branch suggestion"
						);
					} catch (err) {
						isGitDir = false;
						logger.debug(
							`pages deploy: Not a git repository: ${err instanceof Error ? err.message : String(err)}`
						);
					}

					let productionBranch: string | undefined;
					if (isGitDir) {
						try {
							productionBranch = execSync(`git rev-parse --abbrev-ref HEAD`)
								.toString()
								.trim();
							logger.debug(
								`pages deploy: Suggested production branch: "${productionBranch}"`
							);
						} catch (err) {
							logger.debug(
								`pages deploy: Failed to detect current branch: ${err instanceof Error ? err.message : String(err)}`
							);
						}
					}

					productionBranch = await prompt("Enter the production branch name:", {
						defaultValue: productionBranch ?? "production",
					});

					if (!productionBranch) {
						maybeWarnAboutIgnoredConfigFile(configPath, config);
						throw new UserError(
							"Missing production branch. Specify the production branch for your new Pages project when prompted, or re-run with the required information.",
							{
								telemetryMessage: "pages deploy missing production branch",
							}
						);
					}

					await fetchResult<Project>(
						COMPLIANCE_REGION_CONFIG_PUBLIC,
						`/accounts/${accountId}/pages/projects`,
						{
							method: "POST",
							body: JSON.stringify({
								name: projectName,
								production_branch: productionBranch,
							}),
						}
					);

					saveToConfigCache<PagesConfigCache>(PAGES_CONFIG_CACHE_FILENAME, {
						account_id: accountId,
						project_name: projectName,
					});

					logger.log(`✨ Successfully created the '${projectName}' project.`);
					metrics.sendMetricsEvent("create pages project");
					break;
				}
			}
		}

		if (projectName && !isExistingProject && !isInteractive) {
			let message = `The Pages project "${projectName}" does not exist.`;
			if (configPath && config === undefined) {
				message += `\nA configuration file was found at ${configPath} that does not appear to be for a Pages project (missing "pages_build_output_dir"). Did you mean to run \`wrangler deploy\` (to deploy a Worker) instead?`;
			} else {
				message += `\nMaybe you intended to deploy a Worker project instead? Workers are the recommended way to deploy all new projects. If so, run \`wrangler deploy\`.`;
			}

			const accountName = getAccountFromCache()?.name;
			const accountDescription = accountName
				? `the account in use is "${accountName}" with id ${accountId}`
				: `the account in use has id ${accountId}`;
			message += `\n\nIf you are targeting an existing Pages project, verify that the project name is correct and that it exists in your account (${accountDescription}).`;
			message += `\n\nOtherwise, if you are trying to create a new Pages project, start by running: \`wrangler pages project create\``;
			message += ` (though we strongly recommend using Workers instead).`;

			throw new UserError(message, {
				telemetryMessage: "pages deploy project not found non interactive",
			});
		}

		if (!projectName) {
			maybeWarnAboutIgnoredConfigFile(configPath, config);
			throw new UserError(
				"Missing Pages project name. Use --project-name <name> or set the name in your Wrangler configuration file.",
				{ telemetryMessage: "pages deploy missing project name" }
			);
		}

		maybeWarnAboutIgnoredConfigFile(configPath, config);

		// We infer git info by default is not passed in
		logger.debug("pages deploy: Detecting git repository information...");
		let isGitDir = true;
		try {
			execSync(`git rev-parse --is-inside-work-tree`, {
				stdio: "ignore",
			});
			logger.debug("pages deploy: Git repository detected");
		} catch (err) {
			isGitDir = false;
			logger.debug(
				`pages deploy: Not a git repository or git not available: ${err instanceof Error ? err.message : String(err)}`
			);
		}

		let isGitDirty = false;

		if (isGitDir) {
			try {
				const statusOutput = execSync(`git status --porcelain`).toString();
				isGitDirty = Boolean(statusOutput.length);
				logger.debug(
					`pages deploy: Working directory dirty status: ${isGitDirty}`
				);

				if (!branch) {
					branch = execSync(`git rev-parse --abbrev-ref HEAD`)
						.toString()
						.trim();
					logger.debug(`pages deploy: Detected branch: "${branch}"`);
				} else {
					logger.debug(`pages deploy: Using provided branch: "${branch}"`);
				}

				if (!commitHash) {
					commitHash = execSync(`git rev-parse HEAD`).toString().trim();
					logger.debug(`pages deploy: Detected commit hash: "${commitHash}"`);
				} else {
					logger.debug(
						`pages deploy: Using provided commit hash: "${commitHash}"`
					);
				}

				if (!commitMessage) {
					commitMessage = execFileSync("git", [
						"show",
						"-s",
						"--format=%B",
						commitHash,
					])
						.toString()
						.trim();
					logger.debug(
						`pages deploy: Detected commit message: "${commitMessage.substring(0, 50)}${commitMessage.length > 50 ? "..." : ""}"`
					);
				} else {
					logger.debug(`pages deploy: Using provided commit message`);
				}
			} catch (err) {
				logger.debug(
					`pages deploy: Failed to detect git information: ${err instanceof Error ? err.message : String(err)}`
				);
			}

			if (isGitDirty && !commitDirty) {
				logger.warn(
					`Warning: Your working directory is a git repo and has uncommitted changes\nTo silence this warning, pass in --commit-dirty=true`
				);
			}

			if (commitDirty === undefined) {
				commitDirty = isGitDirty;
			}
		}

		// Log final summary of git information
		logger.debug(
			`pages deploy: Git information summary - branch: ${branch ?? "not set"}, commitHash: ${commitHash ?? "not set"}, commitDirty: ${commitDirty ?? "not set"}`
		);

		const enableBundling = args.bundle ?? !(args.noBundle ?? config?.no_bundle);

		const { deploymentResponse, formData } = await deploy({
			directory,
			accountId,
			projectName,
			branch,
			commitMessage,
			commitHash,
			commitDirty,
			skipCaching: args.skipCaching,
			bundle: enableBundling,
			// Sourcemaps from deploy arguments will take precedence so people can try it for one-off deployments without updating their wrangler.toml
			sourceMaps: config?.upload_source_maps || args.uploadSourceMaps,
			args,
		});

		saveToConfigCache<PagesConfigCache>(PAGES_CONFIG_CACHE_FILENAME, {
			account_id: accountId,
			project_name: projectName,
		});

		let latestDeploymentStage: DeploymentStage | undefined;
		let alias: string | undefined;
		let attempts = 0;

		logger.log("🌎 Deploying...");

		while (
			attempts < MAX_DEPLOYMENT_STATUS_ATTEMPTS &&
			latestDeploymentStage?.name !== "deploy" &&
			latestDeploymentStage?.status !== "success" &&
			latestDeploymentStage?.status !== "failure"
		) {
			try {
				/*
				 * Exponential backoff
				 * On every retry, exponentially increase the wait time: 1 second, then
				 * 2s, then 4s, then 8s, etc.
				 */
				await new Promise((resolvePromise) =>
					setTimeout(resolvePromise, Math.pow(2, attempts++) * 1000)
				);

				logger.debug(
					`attempt #${attempts}: Attempting to fetch status for deployment with id "${deploymentResponse.id}" ...`
				);

				const deployment = await fetchResult<Deployment>(
					COMPLIANCE_REGION_CONFIG_PUBLIC,
					`/accounts/${accountId}/pages/projects/${projectName}/deployments/${deploymentResponse.id}`
				);
				latestDeploymentStage = deployment.latest_stage;
				// Aliases is an array but will only ever return one pages.dev
				// If preview, this will return a branch alias. If production, this will return custom domains
				alias = (deployment.aliases?.filter((a) => a.endsWith(".pages.dev")) ??
					[])[0];
			} catch (err) {
				// don't retry if API call retruned an error
				logger.debug(
					`Attempt to get deployment status for deployment with id "${deploymentResponse.id}" failed: ${err}`
				);
			}
		}

		if (
			latestDeploymentStage?.name === "deploy" &&
			latestDeploymentStage?.status === "success"
		) {
			logger.log(
				`✨ Deployment complete! Take a peek over at ${deploymentResponse.url}` +
					(alias ? `\n✨ Deployment alias URL: ${alias}` : "")
			);
		} else if (
			latestDeploymentStage?.name === "deploy" &&
			latestDeploymentStage?.status === "failure"
		) {
			// get persistent logs so we can show users the failure message
			const logs = await fetchResult<UnifiedDeploymentLogMessages>(
				COMPLIANCE_REGION_CONFIG_PUBLIC,
				`/accounts/${accountId}/pages/projects/${projectName}/deployments/${deploymentResponse.id}/history/logs?size=10000000`
			);
			// last log entry will be the most relevant for Direct Uploads
			const failureMessage = logs.data[logs.total - 1].line
				.replace("Error:", "")
				.trim();

			if (failureMessage.includes("Script startup exceeded CPU time limit")) {
				const startupError = new ParseError({
					text: failureMessage,
					telemetryMessage: false,
				});
				Object.assign(startupError, { code: 10021 }); // Startup error code
				const workerBundle = formData.get("_worker.bundle") as File;
				const filePath = path.join(getPagesTmpDir(), "_worker.bundle");
				await writeFile(filePath, workerBundle.stream());
				throw new UserError(
					await diagnoseStartupError(
						startupError,
						filePath,
						getPagesProjectRoot(),
						analyseBundle
					),
					{ telemetryMessage: "pages deploy startup error" }
				);
			}

			throw new FatalError(
				`Deployment failed!
	${failureMessage}`,
				{ code: 1, telemetryMessage: "pages deploy deployment failed" }
			);
		} else {
			logger.log(
				`✨ Deployment complete! However, we couldn't ascertain the final status of your deployment.\n\n` +
					`⚡️ Visit your deployment at ${deploymentResponse.url}\n` +
					`⚡️ Check the deployment details on the Cloudflare dashboard: https://dash.cloudflare.com/${accountId}/pages/view/${projectName}/${deploymentResponse.id}`
			);
		}

		writeOutput({
			type: "pages-deploy",
			version: 1,
			pages_project: deploymentResponse.project_name,
			deployment_id: deploymentResponse.id,
			url: deploymentResponse.url,
		});

		writeOutput({
			type: "pages-deploy-detailed",
			version: 1,
			pages_project: deploymentResponse.project_name,
			deployment_id: deploymentResponse.id,
			url: deploymentResponse.url,
			alias,
			environment: deploymentResponse.environment,
			production_branch: deploymentResponse.production_branch,
			deployment_trigger: {
				metadata: {
					commit_hash:
						deploymentResponse.deployment_trigger?.metadata?.commit_hash ?? "",
				},
			},
		});

		metrics.sendMetricsEvent("create pages deployment");

		// If the agent opted this deploy out of delegation with `--force`, tell it
		// (at the end, on success) that `--force` is a one-time action.
		if (delegation.forcedOptOut) {
			logPagesToWorkersForceOptOutNotice("deploy");
		}
	},
});

function getUnsupportedDeployDelegateArgs(
	args: (typeof pagesDeployCommand)["args"]
): string[] {
	return [
		["--branch", args.branch],
		["--commit-hash", args.commitHash],
		["--commit-message", args.commitMessage],
		["--commit-dirty", args.commitDirty],
		["--skip-caching", args.skipCaching],
	]
		.filter(([, value]) => value !== undefined && value !== false)
		.map(([flag]) => flag as string);
}

type NewOrExistingItem = {
	key: string;
	label: string;
	value: "new" | "existing";
};

function promptSelectExistingOrNewProject(
	message: string,
	items: NewOrExistingItem[]
): Promise<"new" | "existing"> {
	return select(message, {
		choices: items.map((i) => ({ title: i.label, value: i.value })),
	});
}

/**
 * Logs a warning that a config file was found but is missing `pages_build_output_dir`,
 * so it was ignored by `pages deploy`.
 *
 * The warning is only emitted when a config file exists at {@link configPath} but
 * {@link config} is `undefined`, indicating the file was detected yet not parsed
 * into a valid Pages configuration.
 *
 * @param configPath - The path to the detected config file, or `undefined` if none was found.
 * @param config - The parsed configuration object, or `undefined` if the config file
 *   was not usable (e.g. missing `pages_build_output_dir`).
 */
function maybeWarnAboutIgnoredConfigFile(
	configPath: string | undefined,
	config: Config | undefined
) {
	if (configPath && config === undefined) {
		logger.warn(
			`Pages now has ${configFileName(configPath)} support.\n` +
				`We detected a configuration file at ${configPath} but it is missing the "pages_build_output_dir" field, required by Pages.\n` +
				`If you would like to use this configuration file to deploy your project, please use "pages_build_output_dir" to specify the directory of static files to upload.\n` +
				`Ignoring configuration file for now, and proceeding with project deploy.`
		);
	}
}
