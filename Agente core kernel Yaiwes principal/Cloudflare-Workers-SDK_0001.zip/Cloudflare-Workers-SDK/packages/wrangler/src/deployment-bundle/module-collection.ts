import assert from "node:assert";
import crypto from "node:crypto";
import { readdirSync } from "node:fs";
import { readFile } from "node:fs/promises";
import path from "node:path";
import { UserError } from "@cloudflare/workers-utils";
import globToRegExp from "glob-to-regexp";
import { sync as resolveSync } from "resolve";
import { logger } from "../logger";
import {
	findAdditionalModules,
	findAdditionalModuleWatchDirs,
} from "./find-additional-modules";
import { isJavaScriptModuleRule, parseRules } from "./rules";
import type {
	Entry,
	CfModule,
	CfModuleType,
	Config,
	ConfigModuleRuleType,
} from "@cloudflare/workers-utils";
import type esbuild from "esbuild";

export function flipObject<
	K extends string | number | symbol,
	V extends string | number | symbol | undefined,
>(obj: Record<K, V>): Record<NonNullable<V>, K> {
	return Object.fromEntries(
		Object.entries(obj)
			.filter(([_, v]) => !!v)
			.map(([k, v]) => [v, k])
	);
}

export const RuleTypeToModuleType: Record<ConfigModuleRuleType, CfModuleType> =
	{
		ESModule: "esm",
		CommonJS: "commonjs",
		CompiledWasm: "compiled-wasm",
		Data: "buffer",
		Text: "text",
		PythonModule: "python",
		PythonRequirement: "python-requirement",
	};

export const ModuleTypeToRuleType = flipObject(RuleTypeToModuleType);

// Strip query string suffixes (e.g. `?module`) from module paths so that
// file paths and module names don't contain characters invalid on Windows.
function stripQueryString(modulePath: string): string {
	const queryIndex = modulePath.indexOf("?");
	return queryIndex !== -1 ? modulePath.slice(0, queryIndex) : modulePath;
}

// This is a combination of an esbuild plugin and a mutable array
// that we use to collect module references from source code.
// There will be modules that _shouldn't_ be inlined directly into
// the bundle. (eg. wasm modules, some text files, etc). We can include
// those files as modules in the multi part worker form upload. This
// plugin+array is used to collect references to these modules, reference
// them correctly in the bundle, and add them to the form upload.

export type ModuleCollector = {
	modules: CfModule[];
	plugin: esbuild.Plugin;
};

const modulesWatchRegexp = /^wrangler:modules-watch$/;
const modulesWatchNamespace = "wrangler-modules-watch";

export const noopModuleCollector: ModuleCollector = {
	modules: [],
	plugin: {
		name: "wrangler-module-collector",
		setup: (build) => {
			build.onResolve({ filter: modulesWatchRegexp }, (args) => {
				return { namespace: modulesWatchNamespace, path: args.path };
			});
			build.onLoad(
				{ namespace: modulesWatchNamespace, filter: modulesWatchRegexp },
				() => ({ contents: "", loader: "js" })
			);
		},
	},
};

export function createModuleCollector(props: {
	entry: Entry;
	findAdditionalModules: boolean;
	rules?: Config["rules"];
	// a collection of "legacy" style module references, which are just file names
	// we will eventually deprecate this functionality, hence the verbose greppable name
	wrangler1xLegacyModuleReferences?: {
		rootDirectory: string;
		fileNames: Set<string>;
	};
	preserveFileNames?: boolean;
}): ModuleCollector {
	const parsedRules = parseRules(props.rules);

	const modules: CfModule[] = [];
	return {
		modules,
		plugin: {
			name: "wrangler-module-collector",
			setup(build) {
				let foundModulePaths: string[] = [];

				build.onStart(async () => {
					// reset the module collection array
					modules.splice(0);

					if (props.findAdditionalModules) {
						// Make sure we're not bundling a service worker
						if (props.entry.format !== "modules") {
							const error =
								"`find_additional_modules` can only be used with an ES module entrypoint.\n" +
								"Remove `find_additional_modules = true` from your configuration, " +
								"or migrate to the ES module Worker format: " +
								"https://developers.cloudflare.com/workers/learning/migrate-to-module-workers/";
							return { errors: [{ text: error }] };
						}

						const found = await findAdditionalModules(props.entry, parsedRules);
						foundModulePaths = found.map(({ name }) =>
							path.resolve(props.entry.moduleRoot, name)
						);
						modules.push(...found);
					}
				});

				// `esbuild` doesn't support returning `watch*` options from `onStart()`
				// callbacks. Instead, we define an empty virtual module that is
				// imported in an injected module. Importing this module registers the
				// required watchers.

				build.onResolve({ filter: modulesWatchRegexp }, (args) => {
					return { namespace: modulesWatchNamespace, path: args.path };
				});
				build.onLoad(
					{ namespace: modulesWatchNamespace, filter: modulesWatchRegexp },
					async () => {
						let watchFiles: string[] = [];
						const watchDirs: string[] = [];
						if (props.findAdditionalModules) {
							// Watch files to rebuild when they're changed/deleted. Note we
							// could watch additional modules when we import them, but this
							// doesn't cover dynamically imported modules with variable paths
							// (e.g. await import(`./lang/${language}.js`)).
							watchFiles = foundModulePaths;

							// Watch directories to rebuild when *new* files are added.
							// Note watching directories doesn't watch their subdirectories
							// or file contents: https://esbuild.github.io/plugins/#on-load-results
							const root = path.resolve(props.entry.moduleRoot);
							for await (const dir of findAdditionalModuleWatchDirs(root)) {
								watchDirs.push(dir);
							}
						}

						return { contents: "", loader: "js", watchFiles, watchDirs };
					}
				);

				// ~ start legacy module specifier support ~

				// This section detects usage of "legacy" 1.x style module specifiers
				// and modifies them so they "work" in wrangler v2, but with a warning

				const rulesMatchers = parsedRules.rules.flatMap((rule) => {
					return rule.globs.map((glob) => {
						const regex = globToRegExp(glob);
						return {
							regex,
							rule,
						};
					});
				});

				if (
					props.wrangler1xLegacyModuleReferences &&
					props.wrangler1xLegacyModuleReferences.fileNames.size > 0
				) {
					build.onResolve(
						{
							filter: new RegExp(
								"^(" +
									[...props.wrangler1xLegacyModuleReferences.fileNames]
										.map((name) => name.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"))
										.join("|") +
									")$"
							),
						},
						async (args: esbuild.OnResolveArgs) => {
							if (
								args.kind !== "import-statement" &&
								args.kind !== "require-call"
							) {
								return;
							}
							// In the future, this will simply throw an error
							logger.warn(
								`Deprecation: detected a legacy module import in "./${path.relative(
									process.cwd(),
									args.importer
								)}". This will stop working in the future. Replace references to "${
									args.path
								}" with "./${args.path}";`
							);

							// take the file and massage it to a
							// transportable/manageable format
							const cleanedPath = stripQueryString(args.path);
							assert(props.wrangler1xLegacyModuleReferences);
							const filePath = path.join(
								props.wrangler1xLegacyModuleReferences.rootDirectory,
								cleanedPath
							);
							const fileContent = (await readFile(
								filePath
							)) as Buffer<ArrayBuffer>;
							const fileHash = crypto
								.createHash("sha1")
								.update(fileContent)
								.digest("hex");
							const fileName = props.preserveFileNames
								? cleanedPath
								: `./${fileHash}-${path.basename(cleanedPath)}`;

							const { rule } =
								rulesMatchers.find(({ regex }) => regex.test(fileName)) || {};
							if (rule) {
								// add the module to the array
								modules.push({
									name: fileName,
									filePath,
									content: fileContent,
									type: RuleTypeToModuleType[rule.type],
								});
								return {
									path: fileName, // change the reference to the changed module
									external: props.entry.format === "modules", // mark it as external in the bundle
									namespace: `wrangler-module-${rule.type}`, // just a tag, this isn't strictly necessary
									watchFiles: [filePath], // we also add the file to esbuild's watch list
								};
							}
						}
					);
				}

				// ~ end legacy module specifier support ~

				parsedRules.rules?.forEach((rule) => {
					if (!props.findAdditionalModules && isJavaScriptModuleRule(rule)) {
						return;
					}

					rule.globs.forEach((glob) => {
						build.onResolve(
							{ filter: globToRegExp(glob) },
							async (args: esbuild.OnResolveArgs) => {
								if (args.pluginData?.skip) {
									return;
								}

								// take the file and massage it to a
								// transportable/manageable format

								// Strip query string suffixes (e.g. `?module`) from the import
								// path. The `?` character is not valid in filenames on Windows
								// and would cause ENOENT errors when writing modules to disk.
								const cleanedPath = stripQueryString(args.path);
								let filePath = path.join(args.resolveDir, cleanedPath);

								// If this was a found additional module, mark it as external.
								// Note, there's no need to watch the file here as we already
								// watch all `foundModulePaths` with `wrangler:modules-watch`.
								if (foundModulePaths.includes(filePath)) {
									return { path: cleanedPath, external: true };
								}
								// For JavaScript module rules, we only register this onResolve
								// callback if `findAdditionalModules` is true. If we didn't
								// find the module in `modules` in the above `if` block, leave
								// it to `esbuild` to bundle it.
								if (isJavaScriptModuleRule(rule)) {
									return;
								}

								// Check if this file is possibly from an npm package
								// and if so, validate the import against the package.json exports
								// and resolve the file path to the correct file.
								try {
									const resolved = await build.resolve(cleanedPath, {
										kind: args.kind,
										importer: args.importer,
										resolveDir: args.resolveDir,
										pluginData: {
											skip: true,
										},
									});
									if (resolved.path) {
										filePath = resolved.path;
									}
								} catch {
									// We tried, now it'll just fall-through to the previous behaviour
									// and ENOENT if the absolute file path doesn't exist.
								}

								// Next try to resolve using the node module resolution algorithm
								try {
									const resolved = resolveSync(cleanedPath, {
										basedir: args.resolveDir,
									});
									filePath = resolved;
								} catch {
									// We tried, now it'll just fall-through to the previous behaviour
									// and ENOENT if the absolute file path doesn't exist.
								}

								// Finally, load the file and hash it
								// If we didn't do any smart resolution above, this will attempt to load as an absolute path
								const fileContent = (await readFile(
									filePath
								)) as Buffer<ArrayBuffer>;
								const fileHash = crypto
									.createHash("sha1")
									.update(fileContent)
									.digest("hex");
								const fileName = props.preserveFileNames
									? cleanedPath
									: `./${fileHash}-${path.basename(cleanedPath)}`;

								// add the module to the array
								modules.push({
									name: fileName,
									filePath,
									content: fileContent,
									type: RuleTypeToModuleType[rule.type],
								});

								return {
									path: fileName, // change the reference to the changed module
									external: props.entry.format === "modules", // mark it as external in the bundle
									namespace: `wrangler-module-${rule.type}`, // just a tag, this isn't strictly necessary
									watchFiles: [filePath], // we also add the file to esbuild's watch list
								};
							}
						);

						if (props.entry.format === "service-worker") {
							build.onLoad(
								{ filter: globToRegExp(glob) },
								async (args: esbuild.OnLoadArgs) => {
									return {
										// We replace the the module with an identifier
										// that we'll separately add to the form upload
										// as part of [wasm_modules]/[text_blobs]/[data_blobs]. This identifier has to be a valid
										// JS identifier, so we replace all non alphanumeric characters
										// with an underscore.
										contents: `export default ${args.path.replace(
											/[^a-zA-Z0-9_$]/g,
											"_"
										)};`,
									};
								}
							);
						}
					});
				});

				parsedRules.removedRules.forEach((rule) => {
					rule.globs.forEach((glob) => {
						build.onResolve(
							{ filter: globToRegExp(glob) },
							async (args: esbuild.OnResolveArgs) => {
								throw new UserError(
									`The file ${
										args.path
									} matched a module rule in your configuration (${JSON.stringify(
										rule
									)}), but was ignored because a previous rule with the same type was not marked as \`fallthrough = true\`.`,
									{
										telemetryMessage: "module rule ignored without fallthrough",
									}
								);
							}
						);
					});
				});
			},
		},
	};
}

export function getWrangler1xLegacyModuleReferences(
	rootDirectory: string,
	entryPath: string
) {
	return {
		rootDirectory,
		fileNames: new Set(
			readdirSync(rootDirectory, { withFileTypes: true })
				.filter(
					(dirEntry) =>
						dirEntry.isFile() && dirEntry.name !== path.basename(entryPath)
				)
				.map((dirEnt) => dirEnt.name)
		),
	};
}
