import { retryOnAPIFailure, UserError } from "@cloudflare/workers-utils";
import { fetchListResult, fetchResult } from "../cfetch";
import { logger } from "../logger";
import { requireAuth } from "../user";
import { listEmailSendingSubdomains } from "./client";
import type { EmailSendingSubdomain } from "./index";
import type { ComplianceConfig, Config } from "@cloudflare/workers-utils";

export async function resolveZoneId(
	config: Config,
	args: { domain?: string; zoneId?: string }
): Promise<string> {
	if (args.zoneId) {
		return args.zoneId;
	}

	if (args.domain) {
		const accountId = await requireAuth(config);
		return await getZoneIdByDomain(config, args.domain, accountId);
	}

	throw new UserError("You must provide a domain or --zone-id.", {
		telemetryMessage: "email routing missing domain or zone id",
	});
}

async function getZoneIdByDomain(
	complianceConfig: ComplianceConfig,
	domain: string,
	accountId: string
): Promise<string> {
	const zones = await retryOnAPIFailure(
		() =>
			fetchListResult<{ id: string }>(
				complianceConfig,
				`/zones`,
				{},
				new URLSearchParams({
					name: domain,
					"account.id": accountId,
				})
			),
		logger
	);

	const zoneId = zones[0]?.id;
	if (!zoneId) {
		throw new UserError(
			`Could not find zone for \`${domain}\`. Make sure the domain exists in your account.`,
			{ telemetryMessage: "email routing zone not found" }
		);
	}

	return zoneId;
}

export interface ResolvedDomain {
	zoneId: string;
	zoneName: string;
	isSubdomain: boolean;
	domain: string;
}

export async function resolveDomain(
	config: Config,
	domain: string,
	zoneId?: string
): Promise<ResolvedDomain> {
	// If zone ID is provided directly, fetch the zone name to determine subdomain status
	if (zoneId) {
		await requireAuth(config);
		const zone = await retryOnAPIFailure(
			() =>
				fetchResult<{ id: string; name: string }>(config, `/zones/${zoneId}`),
			logger
		);
		return {
			zoneId,
			zoneName: zone.name,
			isSubdomain: domain !== zone.name,
			domain,
		};
	}

	const accountId = await requireAuth(config);

	// Walk up the domain labels: try "sub.example.com", then "example.com"
	const labels = domain.split(".");
	for (let i = 0; i <= labels.length - 2; i++) {
		const candidate = labels.slice(i).join(".");
		const zones = await retryOnAPIFailure(
			() =>
				fetchListResult<{ id: string; name: string }>(
					config,
					`/zones`,
					{},
					new URLSearchParams({
						name: candidate,
						"account.id": accountId,
					})
				),
			logger
		);
		if (zones[0]) {
			return {
				zoneId: zones[0].id,
				zoneName: zones[0].name,
				isSubdomain: domain !== zones[0].name,
				domain,
			};
		}
	}

	throw new UserError(
		`Could not find a zone for \`${domain}\`. Make sure the domain or its parent zone exists in your account.`,
		{ telemetryMessage: "email routing domain zone not found" }
	);
}

export async function resolveSendingSubdomain(
	config: Config,
	zoneId: string,
	name: string
): Promise<EmailSendingSubdomain> {
	const subdomains = await listEmailSendingSubdomains(config, zoneId);
	const match = subdomains.find((s) => s.name === name);
	if (!match) {
		throw new UserError(
			`No sending subdomain found for \`${name}\`. Run \`wrangler email sending list ${name}\` to see configured subdomains.`,
			{ telemetryMessage: "email sending subdomain not found" }
		);
	}
	return match;
}
