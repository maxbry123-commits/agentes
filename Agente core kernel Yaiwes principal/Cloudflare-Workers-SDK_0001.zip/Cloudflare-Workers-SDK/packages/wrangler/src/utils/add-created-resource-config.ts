import {
	configFormat,
	experimental_readRawConfig,
	experimental_patchConfig,
	formatConfigSnippet,
	friendlyBindingNames,
	JSON_CONFIG_FORMATS,
} from "@cloudflare/workers-utils";
import { confirm, prompt } from "../dialogs";
import { logger } from "../logger";
import type {
	Config,
	ConfigBindingFieldName,
	RawConfig,
} from "@cloudflare/workers-utils";

// Config binding field names that follow a "regular" binding shape (Binding[])
// and can be modified using `updateConfigFile`. Excludes singleton bindings,
// record-style bindings, and nested bindings like durable_objects.
type ValidKeys = Exclude<
	ConfigBindingFieldName,
	| "ai"
	| "browser"
	| "websearch"
	| "vars"
	| "wasm_modules"
	| "text_blobs"
	| "data_blobs"
	| "logfwdr"
	| "queues"
	| "assets"
	| "durable_objects"
	| "version_metadata"
	| "images"
	| "stream"
	| "media"
	| "unsafe"
	| "ratelimits"
	| "workflows"
	| "send_email"
	| "services"
	| "analytics_engine_datasets"
	| "mtls_certificates"
	| "dispatch_namespaces"
	| "secrets_store_secrets"
	| "artifacts"
	| "unsafe_hello_world"
>;

export const sharedResourceCreationArgs = {
	"use-remote": {
		type: "boolean",
		description:
			"Use a remote binding when adding the newly created resource to your config",
	},
	"update-config": {
		type: "boolean",
		description:
			"Automatically update your config file with the newly added resource",
	},
	binding: {
		type: "string",
		description: "The binding name of this resource in your Worker",
	},
} as const;

export async function createdResourceConfig<K extends ValidKeys>(
	resource: K,
	snippet: (bindingName?: string) => Partial<NonNullable<RawConfig[K]>[number]>,
	configPath: Config["configPath"],
	env: string | undefined,
	/**
	 * How should this behave interactively?
	 *
	 * - If `updateConfig` is provided, Wrangler won't ask for permission to write to your config file
	 * - `binding` sets the value of the binding name in the config file, and/or the value of the binding name in the echoed output. It also implies `updateConfig`
	 * - `useRemote` sets the value of the `remote` field in the config file, and/or the value of the `remote` field in the echoed output
	 */
	defaults?: {
		binding?: string;
		useRemote?: boolean;
		updateConfig?: boolean;
	}
) {
	const envString = env ? ` in the "${env}" environment` : "";
	// eslint-disable-next-line @typescript-eslint/no-deprecated -- friendlyBindingNames is keyed by config field name; getBindingTypeFriendlyName uses a different key space
	const resourceName = friendlyBindingNames[resource];
	logger.log(
		`To access your new ${resourceName} in your Worker, add the following snippet to your configuration file${envString}:`
	);

	logger.log(
		formatConfigSnippet(
			{
				[resource]: [
					{
						...snippet(defaults?.binding),
						...(defaults?.useRemote === true ? { remote: true } : {}),
					},
				],
			},
			configPath
		)
	);

	// This is a JSON config file that we're capable of editing
	const format = configFormat(configPath);
	if (configPath && JSON_CONFIG_FORMATS.includes(format)) {
		const writeToConfig =
			defaults?.binding ??
			defaults?.updateConfig ??
			(await confirm("Would you like Wrangler to add it on your behalf?", {
				defaultValue: true,
				// We don't want to automatically write to config in CI
				fallbackValue: false,
			}));

		if (writeToConfig) {
			const bindingName =
				defaults?.binding ??
				(await prompt("What binding name would you like to use?", {
					defaultValue: snippet().binding,
				}));

			const useRemote =
				defaults?.useRemote ??
				(defaults?.binding || defaults?.updateConfig
					? false
					: await confirm(
							"For local dev, do you want to connect to the remote resource instead of a local resource?",
							{ defaultValue: false }
						));

			const { rawConfig } = experimental_readRawConfig({ config: configPath });
			const environment = env ? rawConfig.env?.[env] : rawConfig;

			const binding = {
				...snippet(bindingName),
				remote: useRemote ? true : undefined,
			};

			const existingBindings = environment?.[resource];
			const matchingBindingIndex = existingBindings?.findIndex(
				(existingBinding) => existingBinding.binding === binding.binding
			);

			const shouldReplaceExistingBinding =
				existingBindings !== undefined &&
				matchingBindingIndex !== undefined &&
				matchingBindingIndex !== -1;

			let bindings: Partial<NonNullable<RawConfig[K]>[number]>[] = [binding];
			if (shouldReplaceExistingBinding) {
				bindings = existingBindings.map((existingBinding, index) => {
					if (index !== matchingBindingIndex) {
						return existingBinding;
					}
					return { ...existingBinding, ...binding };
				});
			}

			const configFilePatch = { [resource]: bindings };
			experimental_patchConfig(
				configPath,
				env ? { env: { [env]: configFilePatch } } : configFilePatch,
				!shouldReplaceExistingBinding
			);
		}
	}
}
