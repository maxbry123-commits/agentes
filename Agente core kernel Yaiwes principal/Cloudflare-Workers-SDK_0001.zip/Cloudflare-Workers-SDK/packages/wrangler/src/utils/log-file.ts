import { existsSync } from "node:fs";
import { appendFile, readdir, unlink } from "node:fs/promises";
import path from "node:path";
import { stripVTControlCharacters } from "node:util";
import {
	getEnvironmentVariableFactory,
	getGlobalConfigPath,
} from "@cloudflare/workers-utils";
import { Mutex } from "miniflare";
import { onExit } from "signal-exit";
import { logger } from "../logger";
import { ensureDirectoryExists } from "./filesystem";
import type { LoggerLevel } from "../logger";

const getDebugFileDir = getEnvironmentVariableFactory({
	variableName: "WRANGLER_LOG_PATH",
	defaultValue() {
		const gobalWranglerConfigDir = getGlobalConfigPath();

		return path.join(gobalWranglerConfigDir, "logs");
	},
});

function getDebugFilepath() {
	const dir = getDebugFileDir();

	const date = new Date()
		.toISOString()
		.replaceAll(":", "-")
		.replace(".", "_")
		.replace("T", "_")
		.replace("Z", "");

	const filepath = dir.endsWith(".log")
		? dir // allow the user to provide an exact filepath
		: path.join(dir, `wrangler-${date}.log`);

	// use path.resolve to allow the user-provided env var to be a relative path
	return path.resolve(filepath);
}

/**
 * Parses the timestamp encoded in a wrangler log filename.
 */
function parseLogFileTimestamp(filename: string): number | undefined {
	const match =
		/^wrangler-(\d{4}-\d{2}-\d{2})_(\d{2})-(\d{2})-(\d{2})_(\d{3})\.log$/.exec(
			filename
		);
	if (!match) {
		return undefined;
	}
	const [, date, hours, minutes, seconds, milliseconds] = match;
	const timestamp = Date.parse(
		`${date}T${hours}:${minutes}:${seconds}.${milliseconds}Z`
	);
	return Number.isNaN(timestamp) ? undefined : timestamp;
}

/**
 * Deletes wrangler-*.log files older than 30 days from the given log directory.
 * Runs silently — errors are ignored so startup is never blocked by log cleanup.
 */
export async function cleanupOldLogFiles(logsDir: string): Promise<void> {
	if (!existsSync(logsDir)) {
		return;
	}

	const maxAgeDays = 30;
	const cutoffMs = maxAgeDays * 24 * 60 * 60 * 1000;
	try {
		const files = await readdir(logsDir);
		const now = Date.now();
		for (const f of files) {
			const timestamp = parseLogFileTimestamp(f);
			if (timestamp === undefined || now - timestamp <= cutoffMs) {
				continue;
			}
			try {
				await unlink(path.join(logsDir, f));
			} catch {
				// silently ignore errors for individual files
			}
		}
	} catch {
		// silently ignore errors
	}
}

export const debugLogFilepath = getDebugFilepath();
const mutex = new Mutex();

let hasStartedLogCleanup = false;

export function tryCleanupLogs(): void {
	const debugFileDir = getDebugFileDir();
	if (hasStartedLogCleanup || debugFileDir.endsWith(".log")) {
		return;
	}
	hasStartedLogCleanup = true;
	void cleanupOldLogFiles(debugFileDir);
}

let hasLoggedLocation = false;
let hasLoggedError = false;
let hasSeenErrorMessage = false;

/**
 * Appends a message to the log file after waiting for pending writes to complete
 */
export async function appendToDebugLogFile(
	messageLevel: LoggerLevel,
	message: string
) {
	tryCleanupLogs();

	const entry = `
--- ${new Date().toISOString()} ${messageLevel}
${stripVTControlCharacters(message)}
---
`;

	if (!hasLoggedLocation) {
		hasLoggedLocation = true;
		logger.debug(`🪵  Writing logs to "${debugLogFilepath}"`); // use logger.debug here to not show this message by default -- since logging to a file is no longer opt-in
		onExit(() => {
			// only print the log file location if the log file contains an error message
			// TODO(consider): recommend opening an issue with the contents of this file?
			if (hasSeenErrorMessage) {
				// use console.*warn* here so not to pollute stdout -- some commands print json to stdout
				// use logger.*console*("warn", ...) here so not to have include the *very* visible bright-yellow [WARNING] indicator
				logger.console(
					"warn",
					`🪵  Logs were written to "${debugLogFilepath}"`
				);
			}
		});
	}

	if (!hasSeenErrorMessage) {
		// TODO(consider): adding `|| messageLevel === "warn"`
		hasSeenErrorMessage = messageLevel === "error";
	}

	await mutex.runWith(async () => {
		try {
			await ensureDirectoryExists(debugLogFilepath);
			await appendFile(debugLogFilepath, entry);
		} catch (err) {
			if (!hasLoggedError) {
				hasLoggedError = true;
				logger.error(`Failed to write to log file`, err);
				logger.error(`Would have written:`, entry);
			}
		}
	});
}
