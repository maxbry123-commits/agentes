import {
	runInTempDir,
	writeWranglerConfig,
} from "@cloudflare/workers-utils/test-helpers";
import { http, HttpResponse } from "msw";
import { afterAll, beforeAll, describe, it, vi } from "vitest";
import { getDurationDates } from "../../d1/insights";
import { mockAccountId, mockApiToken } from "../helpers/mock-account-id";
import { mockConsoleMethods } from "../helpers/mock-console";
import { useMockIsTTY } from "../helpers/mock-istty";
import { getMswSuccessMembershipHandlers, msw } from "../helpers/msw";
import { runWrangler } from "../helpers/run-wrangler";

describe("getDurationDates()", () => {
	beforeAll(() => {
		vi.useFakeTimers({ toFake: ["setTimeout", "clearTimeout", "Date"] });
		//lock time to 2023-08-01 UTC
		vi.setSystemTime(new Date(2023, 7, 1));
	});

	afterAll(() => {
		vi.useRealTimers();
	});

	it("should throw an error if duration is greater than 31 days (in days)", ({
		expect,
	}) => {
		expect(() => getDurationDates("32d")).toThrow(
			`Invalid --time-period value "32d": 32 days exceeds the maximum of 31 days. Provide a value of 31d or less.`
		);
	});
	it("should throw an error if duration is greater than 31 days (in minutes)", ({
		expect,
	}) => {
		expect(() => getDurationDates("44641m")).toThrow(
			`Invalid --time-period value "44641m": 44641 minutes exceeds the maximum of 44640 minutes (31 days). Provide a value of 44640m or less.`
		);
	});

	it("should throw an error if duration is greater than 31 days (in hours)", ({
		expect,
	}) => {
		expect(() => getDurationDates("745h")).toThrow(
			`Invalid --time-period value "745h": 745 hours exceeds the maximum of 744 hours (31 days). Provide a value of 744h or less.`
		);
	});

	it("should throw an error if duration unit is invalid", ({ expect }) => {
		expect(() => getDurationDates("1y")).toThrow(
			`Invalid --time-period unit "y" in "1y". Supported units: d (days), h (hours), m (minutes). Example: --time-period=7d.`
		);
	});

	it("should return the correct start and end dates", ({ expect }) => {
		const [startDate, endDate] = getDurationDates("5d");

		expect(+new Date(startDate)).toBe(+new Date(2023, 6, 27));
		expect(+new Date(endDate)).toBe(+new Date(2023, 7, 1));
	});
});

describe("insights", () => {
	mockAccountId({ accountId: null });
	mockApiToken();
	mockConsoleMethods();
	runInTempDir();
	const std = mockConsoleMethods();
	const { setIsTTY } = useMockIsTTY();

	it("should throw if a database name is not provided", async ({ expect }) => {
		await expect(() => runWrangler("d1 insights")).rejects.toThrow(
			"Not enough non-option arguments: got 0, need at least 1"
		);

		expect(std.err).toMatchInlineSnapshot(`
    "[31mX [41;31m[[41;97mERROR[41;31m][0m [1mNot enough non-option arguments: got 0, need at least 1[0m

    "
  `);
	});

	it("should throw if database doesn't exist", async ({ expect }) => {
		setIsTTY(false);
		msw.use(
			...getMswSuccessMembershipHandlers([{ id: "1701", name: "enterprise" }]),
			http.get("*/accounts/:accountId/d1/database/:name", async () => {
				return HttpResponse.json(
					{ success: false, errors: [{ code: 7404, message: "Not Found" }] },
					{ status: 404 }
				);
			})
		);

		await expect(() => runWrangler("d1 insights not-a-db")).rejects.toThrow(
			"Couldn't find a D1 DB with name or binding 'not-a-db' in your config or the API."
		);
	});

	it("should display valid json output", async ({ expect }) => {
		setIsTTY(false);
		writeWranglerConfig({
			d1_databases: [
				{
					binding: "DB",
					database_name: "northwind",
					database_id: "d5b1d127-xxxx-xxxx-xxxx-cbc69f0a9e06",
				},
			],
		});
		msw.use(
			...getMswSuccessMembershipHandlers([{ id: "1701", name: "enterprise" }]),
			http.get("*/accounts/:accountId/d1/database/:name", async () => {
				return HttpResponse.json({
					result: {
						uuid: "d5b1d127-xxxx-xxxx-xxxx-cbc69f0a9e06",
						name: "northwind",
					},
					success: true,
					errors: [],
					messages: [],
				});
			})
		);
		msw.use(
			http.post("*/graphql", async () => {
				return HttpResponse.json(
					{
						data: {
							viewer: {
								accounts: [
									{
										d1QueriesAdaptiveGroups: [
											{
												dimensions: {
													query: "sample query",
												},
												sum: {
													rowsRead: 10,
												},
											},
										],
									},
								],
							},
						},
						success: true,
						errors: [],
						messages: [],
					},
					{ status: 200 }
				);
			})
		);
		await runWrangler("d1 insights my-database --json");
		expect(JSON.parse(std.out)).toMatchInlineSnapshot(`
			[
			  {
			    "avgDurationMs": 0,
			    "avgRowsRead": 0,
			    "avgRowsWritten": 0,
			    "numberOfTimesRun": 0,
			    "query": "sample query",
			    "queryEfficiency": 0,
			    "totalDurationMs": 0,
			    "totalRowsRead": 10,
			    "totalRowsWritten": 0,
			  },
			]
		`);
	});
});
