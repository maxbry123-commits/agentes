import { writeFileSync } from "node:fs";
import { runInTempDir } from "@cloudflare/workers-utils/test-helpers";
import { http, HttpResponse } from "msw";
import { afterEach, beforeEach, describe, it } from "vitest";
import { endEventLoop } from "./helpers/end-event-loop";
import { mockAccountId, mockApiToken } from "./helpers/mock-account-id";
import { mockConsoleMethods } from "./helpers/mock-console";
import {
	clearDialogs,
	mockConfirm,
	mockPrompt,
	mockSelect,
} from "./helpers/mock-dialogs";
import { useMockIsTTY } from "./helpers/mock-istty";
import { createFetchResult, msw } from "./helpers/msw";
import { runWrangler } from "./helpers/run-wrangler";

// ── Shared test data ──────────────────────────────────────────────────────────

const MOCK_INSTANCE = {
	id: "my-instance",
	created_at: "2025-01-01T00:00:00Z",
	modified_at: "2025-01-02T00:00:00Z",
	source: "my-bucket",
	type: "r2",
	status: "active",
	namespace: "default",
	ai_search_model: "@cf/google/gemma-4-26b-a4b-it",
	embedding_model: "@cf/bge-base-en-v1.5",
};

const MOCK_INSTANCE_2 = {
	id: "other-instance",
	created_at: "2025-02-01T00:00:00Z",
	modified_at: "2025-02-02T00:00:00Z",
	source: "https://example.com",
	type: "web-crawler",
	status: "active",
	namespace: "default",
};

const MOCK_NAMESPACE = {
	name: "default",
	created_at: "2025-01-01T00:00:00Z",
	description: "Default namespace",
};

const MOCK_NAMESPACE_2 = {
	name: "blog",
	created_at: "2025-02-01T00:00:00Z",
	description: "Blog content",
};

const MOCK_CHUNK = {
	id: "chunk-001",
	score: 0.9512,
	text: "This is a relevant text chunk from the indexed document.",
	type: "text",
	item: {
		key: "docs/readme.md",
		metadata: {},
		timestamp: 1700000000,
	},
};

const MOCK_CHUNK_LONG_TEXT = {
	id: "chunk-002",
	score: 0.8234,
	text: "This is a very long text chunk that exceeds eighty characters and should be truncated in the table output display.",
	type: "text",
	item: {
		key: "docs/guide.md",
	},
};

const MOCK_CHUNK_NO_ITEM = {
	id: "chunk-003",
	score: 0.7001,
	text: "Orphan chunk with no item reference.",
	type: "text",
};

const MOCK_TOKEN = {
	id: "tok-1",
	name: "test",
	status: "active",
	created_at: "2025-01-01T00:00:00Z",
	modified_at: "2025-01-01T00:00:00Z",
};

const MOCK_STATS = {
	queued: 0,
	running: 0,
	completed: 3464,
	skipped: 1744,
	outdated: 1,
	error: 2,
};

const MOCK_JOB = {
	id: "job-001",
	source: "user",
	description: "Manual reindex",
	started_at: "2025-03-01T00:00:00Z",
	ended_at: "2025-03-01T00:05:00Z",
	end_reason: "completed",
	last_seen_at: "2025-03-01T00:05:00Z",
};

const MOCK_JOB_2 = {
	id: "job-002",
	source: "schedule",
	started_at: "2025-03-02T00:00:00Z",
};

const MOCK_JOB_LOG = {
	id: 1,
	created_at: 1700000000,
	message: "Indexing started",
	message_type: 0,
};

// ── Help / Namespace ──────────────────────────────────────────────────────────

describe("ai-search help", () => {
	const std = mockConsoleMethods();
	runInTempDir();

	it("should show help when no argument is passed", async ({ expect }) => {
		await runWrangler("ai-search");
		await endEventLoop();

		expect(std.out).toContain("wrangler ai-search");
		expect(std.out).toContain("Manage AI Search instances");
		expect(std.out).toContain("wrangler ai-search list");
		expect(std.out).toContain("wrangler ai-search create");
		expect(std.out).toContain("wrangler ai-search get");
		expect(std.out).toContain("wrangler ai-search update");
		expect(std.out).toContain("wrangler ai-search delete");
		expect(std.out).toContain("wrangler ai-search stats");
		expect(std.out).toContain("wrangler ai-search search");
		expect(std.out).toContain("wrangler ai-search namespace");
		expect(std.out).toContain("wrangler ai-search jobs");
	});

	it("should show help when an invalid argument is passed", async ({
		expect,
	}) => {
		await expect(() => runWrangler("ai-search foobar")).rejects.toThrow(
			"Unknown argument: foobar"
		);

		expect(std.err).toContain("Unknown argument: foobar");
		expect(std.out).toContain("wrangler ai-search");
		expect(std.out).toContain("Manage AI Search instances");
	});

	it("should show namespace subcommand help", async ({ expect }) => {
		await runWrangler("ai-search namespace");
		await endEventLoop();

		expect(std.out).toContain("wrangler ai-search namespace");
		expect(std.out).toContain("Manage AI Search namespaces");
		expect(std.out).toContain("wrangler ai-search namespace list");
		expect(std.out).toContain("wrangler ai-search namespace create");
		expect(std.out).toContain("wrangler ai-search namespace get");
		expect(std.out).toContain("wrangler ai-search namespace update");
		expect(std.out).toContain("wrangler ai-search namespace delete");
	});

	it("should show jobs subcommand help", async ({ expect }) => {
		await runWrangler("ai-search jobs");
		await endEventLoop();

		expect(std.out).toContain("wrangler ai-search jobs");
		expect(std.out).toContain("AI Search indexing jobs");
		expect(std.out).toContain("wrangler ai-search jobs list");
		expect(std.out).toContain("wrangler ai-search jobs create");
		expect(std.out).toContain("wrangler ai-search jobs get");
		expect(std.out).toContain("wrangler ai-search jobs cancel");
		expect(std.out).toContain("wrangler ai-search jobs logs");
	});
});

// ── Command tests ─────────────────────────────────────────────────────────────

describe("ai-search commands", () => {
	mockAccountId();
	mockApiToken();
	runInTempDir();
	const { setIsTTY } = useMockIsTTY();
	const std = mockConsoleMethods();

	beforeEach(() => {
		setIsTTY(true);
	});

	afterEach(() => {
		clearDialogs();
	});

	// ── list ────────────────────────────────────────────────────────────────────

	describe("list", () => {
		it("should list instances from the default namespace", async ({
			expect,
		}) => {
			mockListInstances([MOCK_INSTANCE, MOCK_INSTANCE_2]);
			await runWrangler("ai-search list");
			expect(std.out).toContain(MOCK_INSTANCE.id);
			expect(std.out).toContain(MOCK_INSTANCE_2.id);
			expect(std.out).toContain(MOCK_INSTANCE.type);
			expect(std.out).toContain(MOCK_INSTANCE_2.type);
			expect(std.out).toContain("namespace");
		});

		it("should hit the default namespace when --namespace is omitted", async ({
			expect,
		}) => {
			let capturedNamespace: string | undefined;
			msw.use(
				http.get(
					"*/accounts/:accountId/ai-search/namespaces/:namespace/instances",
					({ params }) => {
						capturedNamespace = params.namespace as string;
						return HttpResponse.json(createFetchResult([], true));
					},
					{ once: true }
				)
			);
			await runWrangler("ai-search list");
			expect(capturedNamespace).toBe("default");
		});

		it("should hit the provided namespace when --namespace is set", async ({
			expect,
		}) => {
			let capturedNamespace: string | undefined;
			msw.use(
				http.get(
					"*/accounts/:accountId/ai-search/namespaces/:namespace/instances",
					({ params }) => {
						capturedNamespace = params.namespace as string;
						return HttpResponse.json(createFetchResult([], true));
					},
					{ once: true }
				)
			);
			await runWrangler("ai-search list --namespace blog");
			expect(capturedNamespace).toBe("blog");
		});

		it("should accept the -n short alias", async ({ expect }) => {
			let capturedNamespace: string | undefined;
			msw.use(
				http.get(
					"*/accounts/:accountId/ai-search/namespaces/:namespace/instances",
					({ params }) => {
						capturedNamespace = params.namespace as string;
						return HttpResponse.json(createFetchResult([], true));
					},
					{ once: true }
				)
			);
			await runWrangler("ai-search list -n support");
			expect(capturedNamespace).toBe("support");
		});

		it("should list instances as JSON", async ({ expect }) => {
			mockListInstances([MOCK_INSTANCE]);
			await runWrangler("ai-search list --json");
			const parsed = JSON.parse(std.out);
			expect(parsed).toEqual([MOCK_INSTANCE]);
		});

		it("should not print beta status banner when --json is passed", async ({
			expect,
		}) => {
			mockListInstances([MOCK_INSTANCE]);
			await runWrangler("ai-search list --json");
			// The beta/open-beta statusMessage must not appear in stderr when
			// printBanner returns false (i.e. when --json suppresses the banner).
			expect(std.warn).not.toContain("open beta");
		});

		it("should output empty JSON array when no instances exist with --json", async ({
			expect,
		}) => {
			mockListInstances([]);
			await runWrangler("ai-search list --json");
			const parsed = JSON.parse(std.out);
			expect(parsed).toEqual([]);
		});

		it("should warn when no instances exist", async ({ expect }) => {
			mockListInstances([]);
			await runWrangler("ai-search list");
			expect(std.warn).toContain(
				'You haven\'t created any AI Search instances in namespace "default" on this account.'
			);
		});

		it("should warn when page is out of range", async ({ expect }) => {
			mockListInstances([]);
			await runWrangler("ai-search list --page 99");
			expect(std.warn).toContain(
				"No instances found on page 99. Please try a smaller page number."
			);
		});

		it("should pass pagination params", async ({ expect }) => {
			let capturedUrl: URL | undefined;
			msw.use(
				http.get(
					"*/accounts/:accountId/ai-search/namespaces/:namespace/instances",
					({ request }) => {
						capturedUrl = new URL(request.url);
						return HttpResponse.json(
							createFetchResult([], true, [], [], {
								page: 2,
								per_page: 5,
								count: 0,
								total_count: 0,
							})
						);
					},
					{ once: true }
				)
			);
			await runWrangler("ai-search list --page 2 --per-page 5");
			expect(capturedUrl?.searchParams.get("page")).toBe("2");
			expect(capturedUrl?.searchParams.get("per_page")).toBe("5");
		});
	});

	// ── create ──────────────────────────────────────────────────────────────────

	describe("create", () => {
		it("should create an R2 instance with all flags", async ({ expect }) => {
			let capturedBody: Record<string, unknown> | undefined;
			let capturedNamespace: string | undefined;
			mockListTokens([MOCK_TOKEN]);
			mockConfirm({
				text: "Configure custom metadata fields? (optional)",
				result: false,
			});
			msw.use(
				http.post(
					"*/accounts/:accountId/ai-search/namespaces/:namespace/instances",
					async ({ request, params }) => {
						capturedBody = (await request.json()) as Record<string, unknown>;
						capturedNamespace = params.namespace as string;
						return HttpResponse.json(createFetchResult(MOCK_INSTANCE, true));
					},
					{ once: true }
				)
			);
			await runWrangler(
				"ai-search create my-instance --namespace default --type r2 --source my-bucket --embedding-model @cf/bge-base-en-v1.5 --generation-model @cf/google/gemma-4-26b-a4b-it --chunk-size 512 --chunk-overlap 64 --max-num-results 10 --reranking --hybrid-search --cache --score-threshold 0.5"
			);
			expect(capturedNamespace).toBe("default");
			expect(capturedBody).toMatchObject({
				id: "my-instance",
				source: "my-bucket",
				type: "r2",
				embedding_model: "@cf/bge-base-en-v1.5",
				ai_search_model: "@cf/google/gemma-4-26b-a4b-it",
				chunk_size: 512,
				chunk_overlap: 64,
				max_num_results: 10,
				reranking: true,
				hybrid_search_enabled: true,
				cache: true,
				score_threshold: 0.5,
			});
		});

		it("should create an instance in a custom namespace", async ({
			expect,
		}) => {
			let capturedNamespace: string | undefined;
			mockListTokens([MOCK_TOKEN]);
			mockConfirm({
				text: "Configure custom metadata fields? (optional)",
				result: false,
			});
			msw.use(
				http.post(
					"*/accounts/:accountId/ai-search/namespaces/:namespace/instances",
					({ params }) => {
						capturedNamespace = params.namespace as string;
						return HttpResponse.json(
							createFetchResult({ ...MOCK_INSTANCE, namespace: "blog" }, true)
						);
					},
					{ once: true }
				)
			);
			await runWrangler(
				"ai-search create my-instance --namespace blog --type r2 --source my-bucket"
			);
			expect(capturedNamespace).toBe("blog");
			expect(std.out).toContain("Namespace:  blog");
		});

		it("should create instance and print details", async ({ expect }) => {
			mockListTokens([MOCK_TOKEN]);
			mockConfirm({
				text: "Configure custom metadata fields? (optional)",
				result: false,
			});
			mockCreateInstance(MOCK_INSTANCE);
			await runWrangler(
				"ai-search create my-instance --namespace default --type r2 --source my-bucket"
			);
			expect(std.out).toContain(
				'Successfully created AI Search instance "my-instance"'
			);
			expect(std.out).toContain("Type:       r2");
			expect(std.out).toContain("Source:     my-bucket");
			expect(std.out).toContain("Namespace:  default");
		});

		it("should create instance as JSON", async ({ expect }) => {
			mockListTokens([MOCK_TOKEN]);
			mockCreateInstance(MOCK_INSTANCE);
			await runWrangler(
				"ai-search create my-instance --namespace default --type r2 --source my-bucket --json"
			);
			const parsed = JSON.parse(std.out);
			expect(parsed.id).toBe("my-instance");
			expect(parsed.type).toBe("r2");
		});

		it("should default to the 'default' namespace in non-interactive mode when omitted", async ({
			expect,
		}) => {
			let capturedNamespace: string | undefined;
			setIsTTY(false);
			mockListTokens([MOCK_TOKEN]);
			msw.use(
				http.post(
					"*/accounts/:accountId/ai-search/namespaces/:namespace/instances",
					({ params }) => {
						capturedNamespace = params.namespace as string;
						return HttpResponse.json(createFetchResult(MOCK_INSTANCE, true));
					},
					{ once: true }
				)
			);
			await runWrangler(
				"ai-search create my-instance --type r2 --source my-bucket"
			);
			expect(capturedNamespace).toBe("default");
		});

		it("should interactively pick an existing namespace when --namespace is omitted", async ({
			expect,
		}) => {
			let capturedNamespace: string | undefined;
			mockListTokens([MOCK_TOKEN]);
			mockListNamespaces([MOCK_NAMESPACE, MOCK_NAMESPACE_2]);
			mockSelect({
				text: "Select a namespace:",
				result: "blog",
			});
			mockConfirm({
				text: "Configure custom metadata fields? (optional)",
				result: false,
			});
			msw.use(
				http.post(
					"*/accounts/:accountId/ai-search/namespaces/:namespace/instances",
					({ params }) => {
						capturedNamespace = params.namespace as string;
						return HttpResponse.json(
							createFetchResult({ ...MOCK_INSTANCE, namespace: "blog" }, true)
						);
					},
					{ once: true }
				)
			);
			await runWrangler(
				"ai-search create my-instance --type r2 --source my-bucket"
			);
			expect(capturedNamespace).toBe("blog");
		});

		it("should offer the 'default' namespace in the picker even when the list endpoint omits it", async ({
			expect,
		}) => {
			let capturedNamespace: string | undefined;
			mockListTokens([MOCK_TOKEN]);
			// The list endpoint does not return the implicit "default" namespace.
			mockListNamespaces([MOCK_NAMESPACE_2]);
			mockSelect({
				text: "Select a namespace:",
				result: "default",
			});
			mockConfirm({
				text: "Configure custom metadata fields? (optional)",
				result: false,
			});
			msw.use(
				http.post(
					"*/accounts/:accountId/ai-search/namespaces/:namespace/instances",
					({ params }) => {
						capturedNamespace = params.namespace as string;
						return HttpResponse.json(createFetchResult(MOCK_INSTANCE, true));
					},
					{ once: true }
				)
			);
			await runWrangler(
				"ai-search create my-instance --type r2 --source my-bucket"
			);
			expect(capturedNamespace).toBe("default");
		});

		it("should skip the interactive namespace picker when --json is passed", async ({
			expect,
		}) => {
			let capturedNamespace: string | undefined;
			// Leave TTY enabled — the --json flag alone should force the
			// non-interactive path for namespace selection.
			mockListTokens([MOCK_TOKEN]);
			msw.use(
				http.post(
					"*/accounts/:accountId/ai-search/namespaces/:namespace/instances",
					({ params }) => {
						capturedNamespace = params.namespace as string;
						return HttpResponse.json(createFetchResult(MOCK_INSTANCE, true));
					},
					{ once: true }
				)
			);
			await runWrangler(
				"ai-search create my-instance --type r2 --source my-bucket --json"
			);
			expect(capturedNamespace).toBe("default");
		});

		it("should interactively create a new namespace when selected", async ({
			expect,
		}) => {
			let capturedNamespace: string | undefined;
			let capturedNamespaceBody: Record<string, unknown> | undefined;
			mockListTokens([MOCK_TOKEN]);
			mockListNamespaces([MOCK_NAMESPACE]);
			mockSelect({
				text: "Select a namespace:",
				result: "__create_new__",
			});
			mockPrompt({
				text: "Enter a name for the new namespace:",
				result: "my-new-ns",
			});
			mockConfirm({
				text: "Configure custom metadata fields? (optional)",
				result: false,
			});
			msw.use(
				http.post(
					"*/accounts/:accountId/ai-search/namespaces",
					async ({ request }) => {
						capturedNamespaceBody = (await request.json()) as Record<
							string,
							unknown
						>;
						return HttpResponse.json(
							createFetchResult(
								{
									name: "my-new-ns",
									created_at: "2025-03-01T00:00:00Z",
								},
								true
							)
						);
					},
					{ once: true }
				)
			);
			msw.use(
				http.post(
					"*/accounts/:accountId/ai-search/namespaces/:namespace/instances",
					({ params }) => {
						capturedNamespace = params.namespace as string;
						return HttpResponse.json(
							createFetchResult(
								{ ...MOCK_INSTANCE, namespace: "my-new-ns" },
								true
							)
						);
					},
					{ once: true }
				)
			);
			await runWrangler(
				"ai-search create my-instance --type r2 --source my-bucket"
			);
			expect(capturedNamespaceBody).toEqual({ name: "my-new-ns" });
			expect(capturedNamespace).toBe("my-new-ns");
			expect(std.out).toContain('Creating namespace "my-new-ns"...');
			expect(std.out).toContain('Successfully created namespace "my-new-ns".');
		});

		it("should send source_params with prefix and include/exclude items", async ({
			expect,
		}) => {
			let capturedBody: Record<string, unknown> | undefined;
			mockListTokens([MOCK_TOKEN]);
			mockConfirm({
				text: "Configure custom metadata fields? (optional)",
				result: false,
			});
			msw.use(
				http.post(
					"*/accounts/:accountId/ai-search/namespaces/:namespace/instances",
					async ({ request }) => {
						capturedBody = (await request.json()) as Record<string, unknown>;
						return HttpResponse.json(createFetchResult(MOCK_INSTANCE, true));
					},
					{ once: true }
				)
			);
			await runWrangler(
				'ai-search create my-instance --namespace default --type r2 --source my-bucket --prefix docs/ --include-items "*.md" --exclude-items "*.tmp"'
			);
			expect(capturedBody).toMatchObject({
				source_params: {
					prefix: "docs/",
					include_items: ["*.md"],
					exclude_items: ["*.tmp"],
				},
			});
		});

		it("should send source_params.r2_jurisdiction for an R2 source", async ({
			expect,
		}) => {
			let capturedBody: Record<string, unknown> | undefined;
			mockListTokens([MOCK_TOKEN]);
			mockConfirm({
				text: "Configure custom metadata fields? (optional)",
				result: false,
			});
			msw.use(
				http.post(
					"*/accounts/:accountId/ai-search/namespaces/:namespace/instances",
					async ({ request }) => {
						capturedBody = (await request.json()) as Record<string, unknown>;
						return HttpResponse.json(createFetchResult(MOCK_INSTANCE, true));
					},
					{ once: true }
				)
			);
			await runWrangler(
				"ai-search create my-instance --namespace default --type r2 --source my-bucket --source-jurisdiction eu"
			);
			expect(capturedBody).toMatchObject({
				source: "my-bucket",
				type: "r2",
				source_params: { r2_jurisdiction: "eu" },
			});
		});

		it("should omit r2_jurisdiction when --source-jurisdiction is not provided", async ({
			expect,
		}) => {
			let capturedBody: Record<string, unknown> | undefined;
			mockListTokens([MOCK_TOKEN]);
			mockConfirm({
				text: "Configure custom metadata fields? (optional)",
				result: false,
			});
			msw.use(
				http.post(
					"*/accounts/:accountId/ai-search/namespaces/:namespace/instances",
					async ({ request }) => {
						capturedBody = (await request.json()) as Record<string, unknown>;
						return HttpResponse.json(createFetchResult(MOCK_INSTANCE, true));
					},
					{ once: true }
				)
			);
			await runWrangler(
				"ai-search create my-instance --namespace default --type r2 --source my-bucket"
			);
			expect(capturedBody?.source_params).toBeUndefined();
		});

		it("should forward an arbitrary --source-jurisdiction value (server-side validated)", async ({
			expect,
		}) => {
			let capturedBody: Record<string, unknown> | undefined;
			mockListTokens([MOCK_TOKEN]);
			mockConfirm({
				text: "Configure custom metadata fields? (optional)",
				result: false,
			});
			msw.use(
				http.post(
					"*/accounts/:accountId/ai-search/namespaces/:namespace/instances",
					async ({ request }) => {
						capturedBody = (await request.json()) as Record<string, unknown>;
						return HttpResponse.json(createFetchResult(MOCK_INSTANCE, true));
					},
					{ once: true }
				)
			);
			await runWrangler(
				"ai-search create my-instance --namespace default --type r2 --source my-bucket --source-jurisdiction apac"
			);
			expect(capturedBody).toMatchObject({
				source_params: { r2_jurisdiction: "apac" },
			});
		});

		it("should error when --source-jurisdiction is used with --type builtin", async ({
			expect,
		}) => {
			mockListTokens([MOCK_TOKEN]);
			await expect(
				runWrangler(
					"ai-search create my-instance --namespace default --type builtin --source-jurisdiction eu"
				)
			).rejects.toThrow(
				/--source-jurisdiction is only supported with --type r2/
			);
		});

		it("should error when --source-jurisdiction is used with --type web-crawler", async ({
			expect,
		}) => {
			mockListTokens([MOCK_TOKEN]);
			await expect(
				runWrangler(
					"ai-search create my-instance --namespace default --type web-crawler --source https://example.com --source-jurisdiction eu"
				)
			).rejects.toThrow(
				/--source-jurisdiction is only supported with --type r2/
			);
		});

		it("should list buckets in the chosen jurisdiction and forward r2_jurisdiction (interactive)", async ({
			expect,
		}) => {
			let listJurisdiction: string | null = null;
			let capturedBody: Record<string, unknown> | undefined;
			mockListTokens([MOCK_TOKEN]);
			mockSelect({ text: "Select the source type:", result: "r2" });
			mockPrompt({
				text: "R2 jurisdiction (optional, e.g. eu, fedramp; leave blank for none):",
				result: "eu",
			});
			msw.use(
				http.get(
					"*/accounts/:accountId/r2/buckets",
					({ request }) => {
						listJurisdiction = request.headers.get("cf-r2-jurisdiction");
						return HttpResponse.json(
							createFetchResult({
								buckets: [{ name: "eu-bucket", creation_date: "01-01-2001" }],
							})
						);
					},
					{ once: true }
				)
			);
			mockSelect({ text: "Select an R2 bucket:", result: "eu-bucket" });
			mockConfirm({
				text: "Configure custom metadata fields? (optional)",
				result: false,
			});
			msw.use(
				http.post(
					"*/accounts/:accountId/ai-search/namespaces/:namespace/instances",
					async ({ request }) => {
						capturedBody = (await request.json()) as Record<string, unknown>;
						return HttpResponse.json(
							createFetchResult({ ...MOCK_INSTANCE, source: "eu-bucket" }, true)
						);
					},
					{ once: true }
				)
			);
			await runWrangler("ai-search create my-instance --namespace default");
			expect(listJurisdiction).toBe("eu");
			expect(capturedBody).toMatchObject({
				source: "eu-bucket",
				type: "r2",
				source_params: { r2_jurisdiction: "eu" },
			});
		});

		it("should create a new bucket in the chosen jurisdiction (interactive)", async ({
			expect,
		}) => {
			let createJurisdiction: string | null = null;
			mockListTokens([MOCK_TOKEN]);
			mockSelect({ text: "Select the source type:", result: "r2" });
			mockPrompt({
				text: "R2 jurisdiction (optional, e.g. eu, fedramp; leave blank for none):",
				result: "eu",
			});
			msw.use(
				http.get(
					"*/accounts/:accountId/r2/buckets",
					() => HttpResponse.json(createFetchResult({ buckets: [] })),
					{ once: true }
				)
			);
			mockSelect({ text: "Select an R2 bucket:", result: "__create_new__" });
			mockPrompt({
				text: "Enter a name for the new R2 bucket:",
				result: "eu-bucket",
			});
			msw.use(
				http.post(
					"*/accounts/:accountId/r2/buckets",
					({ request }) => {
						createJurisdiction = request.headers.get("cf-r2-jurisdiction");
						return HttpResponse.json(createFetchResult({}));
					},
					{ once: true }
				)
			);
			mockConfirm({
				text: "Configure custom metadata fields? (optional)",
				result: false,
			});
			mockCreateInstance({ ...MOCK_INSTANCE, source: "eu-bucket" });
			await runWrangler("ai-search create my-instance --namespace default");
			expect(createJurisdiction).toBe("eu");
			expect(std.out).toContain('Creating R2 bucket "eu-bucket"...');
		});

		it("should error in non-interactive mode when no tokens exist", async ({
			expect,
		}) => {
			setIsTTY(false);
			mockListTokens([]);
			await expect(
				runWrangler(
					"ai-search create my-instance --namespace default --type r2 --source my-bucket"
				)
			).rejects.toThrow(/No AI Search API token found/);
		});

		it("should abort when user declines to create a token", async ({
			expect,
		}) => {
			mockListTokens([]);
			mockConfirm({
				text: "Have you created a token?",
				result: false,
			});
			await expect(
				runWrangler(
					"ai-search create my-instance --namespace default --type r2 --source my-bucket"
				)
			).rejects.toThrow(/AI Search instance creation cancelled/);
		});

		it("should proceed after user creates a token on retry", async ({
			expect,
		}) => {
			// MSW prepends once-handlers (LIFO), so register in reverse order:
			// second call (with token) first, then first call (empty) on top.
			mockListTokens([MOCK_TOKEN]);
			mockListTokens([]);
			mockConfirm(
				{
					text: "Have you created a token?",
					result: true,
				},
				{
					text: "Configure custom metadata fields? (optional)",
					result: false,
				}
			);
			mockCreateInstance(MOCK_INSTANCE);
			await runWrangler(
				"ai-search create my-instance --namespace default --type r2 --source my-bucket"
			);
			expect(std.out).toContain(
				'Successfully created AI Search instance "my-instance"'
			);
		});

		it("should interactively select r2 type and existing bucket", async ({
			expect,
		}) => {
			mockListTokens([MOCK_TOKEN]);
			// 1. Select source type
			mockSelect({
				text: "Select the source type:",
				result: "r2",
			});
			// 2. Enter the R2 jurisdiction (blank = no jurisdiction)
			mockPrompt({
				text: "R2 jurisdiction (optional, e.g. eu, fedramp; leave blank for none):",
				result: "",
			});
			// 3. Select an existing R2 bucket from the list
			msw.use(
				http.get(
					"*/accounts/:accountId/r2/buckets",
					() =>
						HttpResponse.json(
							createFetchResult({
								buckets: [{ name: "my-bucket", creation_date: "01-01-2001" }],
							})
						),
					{ once: true }
				)
			);
			mockSelect({
				text: "Select an R2 bucket:",
				result: "my-bucket",
			});
			mockConfirm({
				text: "Configure custom metadata fields? (optional)",
				result: false,
			});
			mockCreateInstance(MOCK_INSTANCE);
			await runWrangler("ai-search create my-instance --namespace default");
			expect(std.out).toContain(
				'Successfully created AI Search instance "my-instance"'
			);
			expect(std.out).toContain("Source:     my-bucket");
		});

		it("should interactively create a new r2 bucket when selected", async ({
			expect,
		}) => {
			mockListTokens([MOCK_TOKEN]);
			mockSelect({ text: "Select the source type:", result: "r2" });
			mockPrompt({
				text: "R2 jurisdiction (optional, e.g. eu, fedramp; leave blank for none):",
				result: "",
			});
			msw.use(
				http.get(
					"*/accounts/:accountId/r2/buckets",
					() => HttpResponse.json(createFetchResult({ buckets: [] })),
					{ once: true }
				)
			);
			mockSelect({
				text: "Select an R2 bucket:",
				result: "__create_new__",
			});
			mockPrompt({
				text: "Enter a name for the new R2 bucket:",
				result: "new-bucket",
			});
			// POST to create the R2 bucket
			msw.use(
				http.post(
					"*/accounts/:accountId/r2/buckets",
					() => HttpResponse.json(createFetchResult({})),
					{ once: true }
				)
			);
			mockConfirm({
				text: "Configure custom metadata fields? (optional)",
				result: false,
			});
			mockCreateInstance({
				...MOCK_INSTANCE,
				source: "new-bucket",
			});
			await runWrangler("ai-search create my-instance --namespace default");
			expect(std.out).toContain('Creating R2 bucket "new-bucket"...');
			expect(std.out).toContain('Successfully created R2 bucket "new-bucket".');
			expect(std.out).toContain(
				'Successfully created AI Search instance "my-instance"'
			);
		});

		it("should interactively select web-crawler type and zone", async ({
			expect,
		}) => {
			mockListTokens([MOCK_TOKEN]);
			mockSelect({ text: "Select the source type:", result: "web-crawler" });
			// Select sitemap parse type
			mockSelect({
				text: "Select the web source type:",
				result: "sitemap",
			});
			// Return a zone list for the account
			msw.use(
				http.get(
					"*/zones",
					() =>
						HttpResponse.json(
							createFetchResult([{ id: "zone-1", name: "example.com" }])
						),
					{ once: true }
				)
			);
			mockSelect({
				text: "Select a zone:",
				result: "example.com",
			});
			mockConfirm({
				text: "Configure custom metadata fields? (optional)",
				result: false,
			});
			mockCreateInstance({
				...MOCK_INSTANCE,
				type: "web-crawler",
				source: "https://example.com",
			});
			await runWrangler("ai-search create my-instance --namespace default");
			expect(std.out).toContain(
				'Successfully created AI Search instance "my-instance"'
			);
		});

		it("should prompt for URL when no zones exist in web-crawler interactive mode", async ({
			expect,
		}) => {
			mockListTokens([MOCK_TOKEN]);
			mockSelect({ text: "Select the source type:", result: "web-crawler" });
			mockSelect({
				text: "Select the web source type:",
				result: "sitemap",
			});
			// No zones found
			msw.use(
				http.get("*/zones", () => HttpResponse.json(createFetchResult([])), {
					once: true,
				})
			);
			mockPrompt({
				text: "Enter the website URL to index:",
				result: "https://my-site.com",
			});
			mockConfirm({
				text: "Configure custom metadata fields? (optional)",
				result: false,
			});
			mockCreateInstance({
				...MOCK_INSTANCE,
				type: "web-crawler",
				source: "https://my-site.com",
			});
			await runWrangler("ai-search create my-instance --namespace default");
			expect(std.out).toContain(
				'Successfully created AI Search instance "my-instance"'
			);
		});

		it("should forward --parse-type discover for a web-crawler instance", async ({
			expect,
		}) => {
			let capturedBody: Record<string, unknown> | undefined;
			mockListTokens([MOCK_TOKEN]);
			mockConfirm({
				text: "Configure custom metadata fields? (optional)",
				result: false,
			});
			msw.use(
				http.post(
					"*/accounts/:accountId/ai-search/namespaces/:namespace/instances",
					async ({ request }) => {
						capturedBody = (await request.json()) as Record<string, unknown>;
						return HttpResponse.json(
							createFetchResult(
								{
									...MOCK_INSTANCE,
									type: "web-crawler",
									source: "https://example.com",
								},
								true
							)
						);
					},
					{ once: true }
				)
			);
			await runWrangler(
				"ai-search create my-instance --namespace default --type web-crawler --source https://example.com --parse-type discover"
			);
			expect(capturedBody).toMatchObject({
				type: "web-crawler",
				source: "https://example.com",
				source_params: { web_crawler: { parse_type: "discover" } },
			});
		});

		it("should forward --parse-type sitemap for a web-crawler instance", async ({
			expect,
		}) => {
			let capturedBody: Record<string, unknown> | undefined;
			mockListTokens([MOCK_TOKEN]);
			mockConfirm({
				text: "Configure custom metadata fields? (optional)",
				result: false,
			});
			msw.use(
				http.post(
					"*/accounts/:accountId/ai-search/namespaces/:namespace/instances",
					async ({ request }) => {
						capturedBody = (await request.json()) as Record<string, unknown>;
						return HttpResponse.json(
							createFetchResult(
								{
									...MOCK_INSTANCE,
									type: "web-crawler",
									source: "https://example.com",
								},
								true
							)
						);
					},
					{ once: true }
				)
			);
			await runWrangler(
				"ai-search create my-instance --namespace default --type web-crawler --source https://example.com --parse-type sitemap"
			);
			expect(capturedBody).toMatchObject({
				source_params: { web_crawler: { parse_type: "sitemap" } },
			});
		});

		it("should omit web_crawler source params when --parse-type is not passed in non-interactive mode", async ({
			expect,
		}) => {
			setIsTTY(false);
			let capturedBody: Record<string, unknown> | undefined;
			mockListTokens([MOCK_TOKEN]);
			msw.use(
				http.post(
					"*/accounts/:accountId/ai-search/namespaces/:namespace/instances",
					async ({ request }) => {
						capturedBody = (await request.json()) as Record<string, unknown>;
						return HttpResponse.json(
							createFetchResult(
								{
									...MOCK_INSTANCE,
									type: "web-crawler",
									source: "https://example.com",
								},
								true
							)
						);
					},
					{ once: true }
				)
			);
			await runWrangler(
				"ai-search create my-instance --namespace default --type web-crawler --source https://example.com"
			);
			expect(capturedBody).not.toHaveProperty("source_params");
		});

		it("should interactively select the discover parse type", async ({
			expect,
		}) => {
			let capturedBody: Record<string, unknown> | undefined;
			mockListTokens([MOCK_TOKEN]);
			mockSelect({ text: "Select the source type:", result: "web-crawler" });
			mockSelect({
				text: "Select the web source type:",
				result: "discover",
			});
			msw.use(
				http.get(
					"*/zones",
					() =>
						HttpResponse.json(
							createFetchResult([{ id: "zone-1", name: "example.com" }])
						),
					{ once: true }
				)
			);
			mockSelect({ text: "Select a zone:", result: "example.com" });
			mockConfirm({
				text: "Configure custom metadata fields? (optional)",
				result: false,
			});
			msw.use(
				http.post(
					"*/accounts/:accountId/ai-search/namespaces/:namespace/instances",
					async ({ request }) => {
						capturedBody = (await request.json()) as Record<string, unknown>;
						return HttpResponse.json(
							createFetchResult(
								{
									...MOCK_INSTANCE,
									type: "web-crawler",
									source: "https://example.com",
								},
								true
							)
						);
					},
					{ once: true }
				)
			);
			await runWrangler("ai-search create my-instance --namespace default");
			expect(capturedBody).toMatchObject({
				source_params: { web_crawler: { parse_type: "discover" } },
			});
		});

		it("should error when --parse-type is used with --type builtin", async ({
			expect,
		}) => {
			mockListTokens([MOCK_TOKEN]);
			await expect(
				runWrangler(
					"ai-search create my-instance --namespace default --type builtin --parse-type discover"
				)
			).rejects.toThrow(
				/--parse-type is only supported with --type web-crawler/
			);
		});

		it("should error when --parse-type is used with --type r2", async ({
			expect,
		}) => {
			mockListTokens([MOCK_TOKEN]);
			await expect(
				runWrangler(
					"ai-search create my-instance --namespace default --type r2 --source my-bucket --parse-type discover"
				)
			).rejects.toThrow(
				/--parse-type is only supported with --type web-crawler/
			);
		});

		it("should reject an invalid --parse-type value", async ({ expect }) => {
			await expect(
				runWrangler(
					"ai-search create my-instance --namespace default --type web-crawler --source https://example.com --parse-type crawl"
				)
			).rejects.toThrow(/Invalid values/);
		});

		it("should error when name is missing", async ({ expect }) => {
			await expect(() => runWrangler("ai-search create")).rejects.toThrow(
				"Not enough non-option arguments"
			);
		});

		it("should error in non-interactive mode when --type is missing", async ({
			expect,
		}) => {
			setIsTTY(false);
			mockListTokens([MOCK_TOKEN]);
			await expect(
				runWrangler(
					"ai-search create my-instance --namespace default --source my-bucket"
				)
			).rejects.toThrow(/Missing required flag.*--type/);
		});

		it("should error in non-interactive mode when --source is missing for r2", async ({
			expect,
		}) => {
			setIsTTY(false);
			mockListTokens([MOCK_TOKEN]);
			await expect(
				runWrangler(
					"ai-search create my-instance --namespace default --type r2"
				)
			).rejects.toThrow(/Missing required flag.*--source/);
		});

		it("should error in non-interactive mode when --source is missing for web-crawler", async ({
			expect,
		}) => {
			setIsTTY(false);
			mockListTokens([MOCK_TOKEN]);
			await expect(
				runWrangler(
					"ai-search create my-instance --namespace default --type web-crawler"
				)
			).rejects.toThrow(/Missing required flag.*--source/);
		});

		it("should create a builtin instance and omit type/source from the request body", async ({
			expect,
		}) => {
			let capturedBody: Record<string, unknown> | undefined;
			mockListTokens([MOCK_TOKEN]);
			mockConfirm({
				text: "Configure custom metadata fields? (optional)",
				result: false,
			});
			msw.use(
				http.post(
					"*/accounts/:accountId/ai-search/namespaces/:namespace/instances",
					async ({ request }) => {
						capturedBody = (await request.json()) as Record<string, unknown>;
						return HttpResponse.json(
							createFetchResult(
								{
									id: "my-instance",
									created_at: "2025-01-01T00:00:00Z",
									modified_at: "2025-01-02T00:00:00Z",
									namespace: "default",
									status: "active",
								},
								true
							)
						);
					},
					{ once: true }
				)
			);
			await runWrangler(
				"ai-search create my-instance --namespace default --type builtin"
			);
			expect(capturedBody).toBeDefined();
			expect(capturedBody).not.toHaveProperty("type");
			expect(capturedBody).not.toHaveProperty("source");
			expect(capturedBody).toMatchObject({ id: "my-instance" });
			expect(std.out).toContain(
				'Successfully created AI Search instance "my-instance"'
			);
			expect(std.out).toContain("Type:       builtin");
			expect(std.out).toContain("Source:     -");
		});

		it("should error when --source is passed with --type builtin", async ({
			expect,
		}) => {
			mockListTokens([MOCK_TOKEN]);
			await expect(
				runWrangler(
					"ai-search create my-instance --namespace default --type builtin --source my-bucket"
				)
			).rejects.toThrow(/not supported with --type builtin.*--source/);
		});

		it("should error when source_params flags are passed with --type builtin", async ({
			expect,
		}) => {
			mockListTokens([MOCK_TOKEN]);
			await expect(
				runWrangler(
					'ai-search create my-instance --namespace default --type builtin --prefix docs/ --include-items "*.md" --exclude-items "*.tmp"'
				)
			).rejects.toThrow(
				/not supported with --type builtin.*--prefix.*--include-items.*--exclude-items/
			);
		});

		it("should interactively select builtin and omit type from the request body", async ({
			expect,
		}) => {
			let capturedBody: Record<string, unknown> | undefined;
			mockListTokens([MOCK_TOKEN]);
			mockSelect({
				text: "Select the source type:",
				result: "builtin",
			});
			mockConfirm({
				text: "Configure custom metadata fields? (optional)",
				result: false,
			});
			msw.use(
				http.post(
					"*/accounts/:accountId/ai-search/namespaces/:namespace/instances",
					async ({ request }) => {
						capturedBody = (await request.json()) as Record<string, unknown>;
						return HttpResponse.json(
							createFetchResult(
								{
									id: "my-instance",
									created_at: "2025-01-01T00:00:00Z",
									modified_at: "2025-01-02T00:00:00Z",
									namespace: "default",
									status: "active",
								},
								true
							)
						);
					},
					{ once: true }
				)
			);
			await runWrangler("ai-search create my-instance --namespace default");
			expect(capturedBody).not.toHaveProperty("type");
			expect(capturedBody).not.toHaveProperty("source");
			expect(std.out).toContain(
				'Successfully created AI Search instance "my-instance"'
			);
		});

		// ── custom_metadata ─────────────────────────────────────────────────────

		it("should send custom_metadata when --custom-metadata is provided", async ({
			expect,
		}) => {
			let capturedBody: Record<string, unknown> | undefined;
			mockListTokens([MOCK_TOKEN]);
			msw.use(
				http.post(
					"*/accounts/:accountId/ai-search/namespaces/:namespace/instances",
					async ({ request }) => {
						capturedBody = (await request.json()) as Record<string, unknown>;
						return HttpResponse.json(createFetchResult(MOCK_INSTANCE, true));
					},
					{ once: true }
				)
			);
			await runWrangler(
				"ai-search create my-instance --namespace default --type r2 --source my-bucket --custom-metadata title:text"
			);
			expect(capturedBody).toMatchObject({
				custom_metadata: [{ field_name: "title", data_type: "text" }],
			});
		});

		it("should accept multiple --custom-metadata flags", async ({ expect }) => {
			let capturedBody: Record<string, unknown> | undefined;
			mockListTokens([MOCK_TOKEN]);
			msw.use(
				http.post(
					"*/accounts/:accountId/ai-search/namespaces/:namespace/instances",
					async ({ request }) => {
						capturedBody = (await request.json()) as Record<string, unknown>;
						return HttpResponse.json(createFetchResult(MOCK_INSTANCE, true));
					},
					{ once: true }
				)
			);
			await runWrangler(
				"ai-search create my-instance --namespace default --type r2 --source my-bucket --custom-metadata title:text --custom-metadata views:number --custom-metadata published:boolean"
			);
			expect(capturedBody).toMatchObject({
				custom_metadata: [
					{ field_name: "title", data_type: "text" },
					{ field_name: "views", data_type: "number" },
					{ field_name: "published", data_type: "boolean" },
				],
			});
		});

		it("should reject --custom-metadata with an invalid data_type", async ({
			expect,
		}) => {
			mockListTokens([MOCK_TOKEN]);
			await expect(
				runWrangler(
					"ai-search create my-instance --namespace default --type r2 --source my-bucket --custom-metadata title:bogus"
				)
			).rejects.toThrow(
				/data_type must be one of text, number, boolean, datetime/
			);
		});

		it("should reject --custom-metadata that is missing a separator", async ({
			expect,
		}) => {
			mockListTokens([MOCK_TOKEN]);
			await expect(
				runWrangler(
					"ai-search create my-instance --namespace default --type r2 --source my-bucket --custom-metadata title"
				)
			).rejects.toThrow(/Expected format: field_name:data_type/);
		});

		it("should reject --custom-metadata with a reserved field name", async ({
			expect,
		}) => {
			mockListTokens([MOCK_TOKEN]);
			await expect(
				runWrangler(
					"ai-search create my-instance --namespace default --type r2 --source my-bucket --custom-metadata timestamp:number"
				)
			).rejects.toThrow(/reserved field name/);
		});

		it("should interactively configure custom_metadata when the flag is omitted", async ({
			expect,
		}) => {
			let capturedBody: Record<string, unknown> | undefined;
			mockListTokens([MOCK_TOKEN]);
			mockConfirm({
				text: "Configure custom metadata fields? (optional)",
				result: true,
			});
			mockPrompt({
				text: "Field name:",
				result: "category",
			});
			mockSelect({
				text: "Data type:",
				result: "text",
			});
			mockConfirm({
				text: "Add another field?",
				result: false,
			});
			msw.use(
				http.post(
					"*/accounts/:accountId/ai-search/namespaces/:namespace/instances",
					async ({ request }) => {
						capturedBody = (await request.json()) as Record<string, unknown>;
						return HttpResponse.json(createFetchResult(MOCK_INSTANCE, true));
					},
					{ once: true }
				)
			);
			await runWrangler(
				"ai-search create my-instance --namespace default --type r2 --source my-bucket"
			);
			expect(capturedBody).toMatchObject({
				custom_metadata: [{ field_name: "category", data_type: "text" }],
			});
		});

		it("should not send custom_metadata when the user declines the optional step", async ({
			expect,
		}) => {
			let capturedBody: Record<string, unknown> | undefined;
			mockListTokens([MOCK_TOKEN]);
			mockConfirm({
				text: "Configure custom metadata fields? (optional)",
				result: false,
			});
			msw.use(
				http.post(
					"*/accounts/:accountId/ai-search/namespaces/:namespace/instances",
					async ({ request }) => {
						capturedBody = (await request.json()) as Record<string, unknown>;
						return HttpResponse.json(createFetchResult(MOCK_INSTANCE, true));
					},
					{ once: true }
				)
			);
			await runWrangler(
				"ai-search create my-instance --namespace default --type r2 --source my-bucket"
			);
			expect(capturedBody).not.toHaveProperty("custom_metadata");
		});

		it("should skip the custom_metadata prompt in non-interactive mode", async ({
			expect,
		}) => {
			let capturedBody: Record<string, unknown> | undefined;
			setIsTTY(false);
			mockListTokens([MOCK_TOKEN]);
			msw.use(
				http.post(
					"*/accounts/:accountId/ai-search/namespaces/:namespace/instances",
					async ({ request }) => {
						capturedBody = (await request.json()) as Record<string, unknown>;
						return HttpResponse.json(createFetchResult(MOCK_INSTANCE, true));
					},
					{ once: true }
				)
			);
			await runWrangler(
				"ai-search create my-instance --namespace default --type r2 --source my-bucket"
			);
			expect(capturedBody).not.toHaveProperty("custom_metadata");
		});

		it("should skip the custom_metadata prompt when --json is passed", async ({
			expect,
		}) => {
			let capturedBody: Record<string, unknown> | undefined;
			mockListTokens([MOCK_TOKEN]);
			msw.use(
				http.post(
					"*/accounts/:accountId/ai-search/namespaces/:namespace/instances",
					async ({ request }) => {
						capturedBody = (await request.json()) as Record<string, unknown>;
						return HttpResponse.json(createFetchResult(MOCK_INSTANCE, true));
					},
					{ once: true }
				)
			);
			await runWrangler(
				"ai-search create my-instance --namespace default --type r2 --source my-bucket --json"
			);
			expect(capturedBody).not.toHaveProperty("custom_metadata");
		});

		it("should print the custom_metadata fields in the success summary", async ({
			expect,
		}) => {
			mockListTokens([MOCK_TOKEN]);
			mockCreateInstance({
				...MOCK_INSTANCE,
				custom_metadata: [
					{ field_name: "title", data_type: "text" },
					{ field_name: "views", data_type: "number" },
				],
			});
			await runWrangler(
				"ai-search create my-instance --namespace default --type r2 --source my-bucket --custom-metadata title:text --custom-metadata views:number"
			);
			expect(std.out).toContain("Metadata:   title:text, views:number");
		});

		it("should reject --custom-metadata-schema with the legacy object form", async ({
			expect,
		}) => {
			mockListTokens([MOCK_TOKEN]);
			writeFileSync(
				"schema.json",
				JSON.stringify({
					custom_metadata: [{ field_name: "title", data_type: "text" }],
				})
			);
			await expect(
				runWrangler(
					"ai-search create my-instance --namespace default --type r2 --source my-bucket --custom-metadata-schema schema.json"
				)
			).rejects.toThrow(
				/Expected an array of \{ field_name, data_type \} objects/
			);
		});

		it("should load custom_metadata from --custom-metadata-schema (bare array form)", async ({
			expect,
		}) => {
			let capturedBody: Record<string, unknown> | undefined;
			mockListTokens([MOCK_TOKEN]);
			writeFileSync(
				"schema.json",
				JSON.stringify([
					{ field_name: "category", data_type: "text" },
					{ field_name: "published", data_type: "boolean" },
				])
			);
			msw.use(
				http.post(
					"*/accounts/:accountId/ai-search/namespaces/:namespace/instances",
					async ({ request }) => {
						capturedBody = (await request.json()) as Record<string, unknown>;
						return HttpResponse.json(createFetchResult(MOCK_INSTANCE, true));
					},
					{ once: true }
				)
			);
			await runWrangler(
				"ai-search create my-instance --namespace default --type r2 --source my-bucket --custom-metadata-schema schema.json"
			);
			expect(capturedBody).toMatchObject({
				custom_metadata: [
					{ field_name: "category", data_type: "text" },
					{ field_name: "published", data_type: "boolean" },
				],
			});
		});

		it("should reject --custom-metadata-schema with malformed JSON", async ({
			expect,
		}) => {
			mockListTokens([MOCK_TOKEN]);
			writeFileSync("schema.json", "{ not valid json");
			await expect(
				runWrangler(
					"ai-search create my-instance --namespace default --type r2 --source my-bucket --custom-metadata-schema schema.json"
				)
			).rejects.toThrow();
		});

		it("should reject --custom-metadata-schema with an unsupported shape", async ({
			expect,
		}) => {
			mockListTokens([MOCK_TOKEN]);
			writeFileSync(
				"schema.json",
				JSON.stringify({ fields: [{ field_name: "title", data_type: "text" }] })
			);
			await expect(
				runWrangler(
					"ai-search create my-instance --namespace default --type r2 --source my-bucket --custom-metadata-schema schema.json"
				)
			).rejects.toThrow(
				/Expected an array of \{ field_name, data_type \} objects/
			);
		});

		it("should reject --custom-metadata-schema with an invalid data_type", async ({
			expect,
		}) => {
			mockListTokens([MOCK_TOKEN]);
			writeFileSync(
				"schema.json",
				JSON.stringify([{ field_name: "title", data_type: "bogus" }])
			);
			await expect(
				runWrangler(
					"ai-search create my-instance --namespace default --type r2 --source my-bucket --custom-metadata-schema schema.json"
				)
			).rejects.toThrow(
				/"data_type" must be one of text, number, boolean, datetime/
			);
		});

		it("should reject --custom-metadata-schema with a reserved field name", async ({
			expect,
		}) => {
			mockListTokens([MOCK_TOKEN]);
			writeFileSync(
				"schema.json",
				JSON.stringify([{ field_name: "timestamp", data_type: "number" }])
			);
			await expect(
				runWrangler(
					"ai-search create my-instance --namespace default --type r2 --source my-bucket --custom-metadata-schema schema.json"
				)
			).rejects.toThrow(/reserved field name/);
		});

		it("should reject combining --custom-metadata and --custom-metadata-schema", async ({
			expect,
		}) => {
			mockListTokens([MOCK_TOKEN]);
			writeFileSync(
				"schema.json",
				JSON.stringify([{ field_name: "title", data_type: "text" }])
			);
			await expect(
				runWrangler(
					"ai-search create my-instance --namespace default --type r2 --source my-bucket --custom-metadata title:text --custom-metadata-schema schema.json"
				)
			).rejects.toThrow(
				/custom-metadata and custom-metadata-schema are mutually exclusive/
			);
		});

		it("should skip the interactive prompt when --custom-metadata-schema is provided", async ({
			expect,
		}) => {
			let capturedBody: Record<string, unknown> | undefined;
			mockListTokens([MOCK_TOKEN]);
			// No mockConfirm for "Configure custom metadata fields? (optional)" — if
			// the prompt fires the test will fail with an unexpected-call error.
			writeFileSync(
				"schema.json",
				JSON.stringify([{ field_name: "title", data_type: "text" }])
			);
			msw.use(
				http.post(
					"*/accounts/:accountId/ai-search/namespaces/:namespace/instances",
					async ({ request }) => {
						capturedBody = (await request.json()) as Record<string, unknown>;
						return HttpResponse.json(createFetchResult(MOCK_INSTANCE, true));
					},
					{ once: true }
				)
			);
			await runWrangler(
				"ai-search create my-instance --namespace default --type r2 --source my-bucket --custom-metadata-schema schema.json"
			);
			expect(capturedBody).toMatchObject({
				custom_metadata: [{ field_name: "title", data_type: "text" }],
			});
		});
	});

	// ── get ──────────────────────────────────────────────────────────────────────

	describe("get", () => {
		it("should get instance details", async ({ expect }) => {
			mockGetInstance(MOCK_INSTANCE);
			await runWrangler("ai-search get my-instance");
			expect(std.out).toContain("my-instance");
			expect(std.out).toContain("r2");
			expect(std.out).toContain("active");
			expect(std.out).toContain("my-bucket");
		});

		it("should get instance from custom namespace", async ({ expect }) => {
			let capturedNamespace: string | undefined;
			msw.use(
				http.get(
					"*/accounts/:accountId/ai-search/namespaces/:namespace/instances/:name",
					({ params }) => {
						capturedNamespace = params.namespace as string;
						return HttpResponse.json(
							createFetchResult({ ...MOCK_INSTANCE, namespace: "blog" }, true)
						);
					},
					{ once: true }
				)
			);
			await runWrangler("ai-search get my-instance --namespace blog");
			expect(capturedNamespace).toBe("blog");
		});

		it("should get instance as JSON", async ({ expect }) => {
			mockGetInstance(MOCK_INSTANCE);
			await runWrangler("ai-search get my-instance --json");
			const parsed = JSON.parse(std.out);
			expect(parsed.id).toBe("my-instance");
			expect(parsed.type).toBe("r2");
			expect(parsed.source).toBe("my-bucket");
		});

		it("should error when name is missing", async ({ expect }) => {
			await expect(() => runWrangler("ai-search get")).rejects.toThrow(
				"Not enough non-option arguments"
			);
		});
	});

	// ── update ──────────────────────────────────────────────────────────────────

	describe("update", () => {
		it("should update instance with flags", async ({ expect }) => {
			let capturedBody: Record<string, unknown> | undefined;
			let capturedNamespace: string | undefined;
			msw.use(
				http.put(
					"*/accounts/:accountId/ai-search/namespaces/:namespace/instances/:name",
					async ({ request, params }) => {
						capturedBody = (await request.json()) as Record<string, unknown>;
						capturedNamespace = params.namespace as string;
						return HttpResponse.json(createFetchResult(MOCK_INSTANCE, true));
					},
					{ once: true }
				)
			);
			await runWrangler(
				"ai-search update my-instance --embedding-model @cf/bge-base-en-v1.5 --chunk-size 256 --reranking --paused"
			);
			expect(capturedNamespace).toBe("default");
			expect(capturedBody).toMatchObject({
				embedding_model: "@cf/bge-base-en-v1.5",
				chunk_size: 256,
				reranking: true,
				paused: true,
			});
			expect(std.out).toContain(
				'Successfully updated AI Search instance "my-instance"'
			);
		});

		it("should update instance in a custom namespace", async ({ expect }) => {
			let capturedNamespace: string | undefined;
			msw.use(
				http.put(
					"*/accounts/:accountId/ai-search/namespaces/:namespace/instances/:name",
					({ params }) => {
						capturedNamespace = params.namespace as string;
						return HttpResponse.json(createFetchResult(MOCK_INSTANCE, true));
					},
					{ once: true }
				)
			);
			await runWrangler(
				"ai-search update my-instance --namespace blog --cache"
			);
			expect(capturedNamespace).toBe("blog");
		});

		it("should update instance as JSON", async ({ expect }) => {
			mockUpdateInstance(MOCK_INSTANCE);
			await runWrangler("ai-search update my-instance --paused --json");
			const parsed = JSON.parse(std.out);
			expect(parsed.id).toBe("my-instance");
		});

		it("should error when no fields are provided", async ({ expect }) => {
			await expect(() =>
				runWrangler("ai-search update my-instance")
			).rejects.toThrow(
				"No fields to update. Provide at least one flag (e.g. --paused, --cache)."
			);
		});

		it("should only send provided fields", async ({ expect }) => {
			let capturedBody: Record<string, unknown> | undefined;
			msw.use(
				http.put(
					"*/accounts/:accountId/ai-search/namespaces/:namespace/instances/:name",
					async ({ request }) => {
						capturedBody = (await request.json()) as Record<string, unknown>;
						return HttpResponse.json(createFetchResult(MOCK_INSTANCE, true));
					},
					{ once: true }
				)
			);
			await runWrangler("ai-search update my-instance --cache");
			expect(capturedBody).toEqual({ cache: true });
		});
	});

	// ── delete ──────────────────────────────────────────────────────────────────

	describe("delete", () => {
		it("should delete with confirmation", async ({ expect }) => {
			mockConfirm({
				text: 'OK to delete the AI Search instance "my-instance"?',
				result: true,
			});
			mockDeleteInstance();
			await runWrangler("ai-search delete my-instance");
			expect(std.out).toContain(
				'Successfully deleted AI Search instance "my-instance"'
			);
		});

		it("should delete instance from custom namespace", async ({ expect }) => {
			let capturedNamespace: string | undefined;
			mockConfirm({
				text: 'OK to delete the AI Search instance "my-instance"?',
				result: true,
			});
			msw.use(
				http.delete(
					"*/accounts/:accountId/ai-search/namespaces/:namespace/instances/:name",
					({ params }) => {
						capturedNamespace = params.namespace as string;
						return HttpResponse.json(createFetchResult(null, true));
					},
					{ once: true }
				)
			);
			await runWrangler("ai-search delete my-instance --namespace blog");
			expect(capturedNamespace).toBe("blog");
		});

		it("should cancel deletion when not confirmed", async ({ expect }) => {
			mockConfirm({
				text: 'OK to delete the AI Search instance "my-instance"?',
				result: false,
			});
			const requests = mockDeleteInstance();
			await runWrangler("ai-search delete my-instance");
			expect(std.out).toContain("Deletion cancelled.");
			expect(requests.count).toBe(0);
		});

		it("should delete with --force flag", async ({ expect }) => {
			mockDeleteInstance();
			await runWrangler("ai-search delete my-instance --force");
			expect(std.out).toContain(
				'Successfully deleted AI Search instance "my-instance"'
			);
		});
	});

	// ── stats ───────────────────────────────────────────────────────────────────

	describe("stats", () => {
		it("should display stats in table", async ({ expect }) => {
			mockGetStats(MOCK_STATS);
			await runWrangler("ai-search stats my-instance");
			expect(std.out).toContain("Queued");
			expect(std.out).toContain("Processing");
			expect(std.out).toContain("Indexed");
			expect(std.out).toContain("Skipped");
			expect(std.out).toContain("Outdated");
			expect(std.out).toContain("Errors");
			expect(std.out).toContain("3464");
			expect(std.out).toContain("1744");
		});

		it("should display stats as JSON", async ({ expect }) => {
			mockGetStats(MOCK_STATS);
			await runWrangler("ai-search stats my-instance --json");
			const parsed = JSON.parse(std.out);
			expect(parsed.queued).toBe(0);
			expect(parsed.running).toBe(0);
			expect(parsed.completed).toBe(3464);
			expect(parsed.skipped).toBe(1744);
			expect(parsed.outdated).toBe(1);
			expect(parsed.error).toBe(2);
		});

		it("should route stats through the specified namespace", async ({
			expect,
		}) => {
			let capturedNamespace: string | undefined;
			msw.use(
				http.get(
					"*/accounts/:accountId/ai-search/namespaces/:namespace/instances/:name/stats",
					({ params }) => {
						capturedNamespace = params.namespace as string;
						return HttpResponse.json(createFetchResult(MOCK_STATS, true));
					},
					{ once: true }
				)
			);
			await runWrangler("ai-search stats my-instance --namespace blog");
			expect(capturedNamespace).toBe("blog");
		});
	});

	// ── search ──────────────────────────────────────────────────────────────────

	describe("search", () => {
		it("should perform a search query", async ({ expect }) => {
			mockSearchInstance({
				chunks: [MOCK_CHUNK],
				search_query: "test query",
			});
			await runWrangler('ai-search search my-instance --query "test query"');
			expect(std.out).toContain('Search query: "test query"  (1 results)');
			expect(std.out).toContain("0.9512");
			expect(std.out).toContain("docs/readme.md");
		});

		it("should route search through the specified namespace", async ({
			expect,
		}) => {
			let capturedNamespace: string | undefined;
			msw.use(
				http.post(
					"*/accounts/:accountId/ai-search/namespaces/:namespace/instances/:name/search",
					({ params }) => {
						capturedNamespace = params.namespace as string;
						return HttpResponse.json(
							createFetchResult({ chunks: [], search_query: "test" }, true)
						);
					},
					{ once: true }
				)
			);
			await runWrangler(
				'ai-search search my-instance --namespace blog --query "test"'
			);
			expect(capturedNamespace).toBe("blog");
		});

		it("should output search results as JSON", async ({ expect }) => {
			const response = {
				chunks: [MOCK_CHUNK],
				search_query: "test query",
			};
			mockSearchInstance(response);
			await runWrangler(
				'ai-search search my-instance --query "test query" --json'
			);
			const parsed = JSON.parse(std.out);
			expect(parsed.search_query).toBe("test query");
			expect(parsed.chunks).toHaveLength(1);
			expect(parsed.chunks[0].score).toBe(0.9512);
		});

		it("should handle empty results", async ({ expect }) => {
			mockSearchInstance({
				chunks: [],
				search_query: "no matches",
			});
			await runWrangler('ai-search search my-instance --query "no matches"');
			expect(std.out).toContain('Search query: "no matches"  (0 results)');
			expect(std.out).toContain("No results found.");
		});

		it("should truncate long text at 80 chars", async ({ expect }) => {
			mockSearchInstance({
				chunks: [MOCK_CHUNK_LONG_TEXT],
				search_query: "test",
			});
			await runWrangler('ai-search search my-instance --query "test"');
			// The original text is > 80 chars, so it should be truncated with "..."
			expect(std.out).toContain("...");
			// Should NOT contain the full text
			expect(std.out).not.toContain(MOCK_CHUNK_LONG_TEXT.text);
		});

		it("should parse --filter flags", async ({ expect }) => {
			let capturedBody: Record<string, unknown> | undefined;
			msw.use(
				http.post(
					"*/accounts/:accountId/ai-search/namespaces/:namespace/instances/:name/search",
					async ({ request }) => {
						capturedBody = (await request.json()) as Record<string, unknown>;
						return HttpResponse.json(
							createFetchResult({ chunks: [], search_query: "test" }, true)
						);
					},
					{ once: true }
				)
			);
			await runWrangler(
				'ai-search search my-instance --query "test" --filter type=docs --filter lang=en'
			);
			expect(capturedBody).toMatchObject({
				messages: [{ role: "user", content: "test" }],
				filters: { type: "docs", lang: "en" },
			});
		});

		it("should warn on malformed filters", async ({ expect }) => {
			mockSearchInstance({
				chunks: [],
				search_query: "test",
			});
			await runWrangler(
				'ai-search search my-instance --query "test" --filter badformat'
			);
			expect(std.warn).toContain(
				'Ignoring malformed filter "badformat" (expected key=value)'
			);
		});

		it("should handle chunk with missing item key", async ({ expect }) => {
			mockSearchInstance({
				chunks: [MOCK_CHUNK_NO_ITEM],
				search_query: "test",
			});
			await runWrangler('ai-search search my-instance --query "test"');
			expect(std.out).toContain("0.7001");
			expect(std.out).toContain("Orphan chunk with no item reference.");
		});

		it("should send messages in correct format", async ({ expect }) => {
			let capturedBody: Record<string, unknown> | undefined;
			msw.use(
				http.post(
					"*/accounts/:accountId/ai-search/namespaces/:namespace/instances/:name/search",
					async ({ request }) => {
						capturedBody = (await request.json()) as Record<string, unknown>;
						return HttpResponse.json(
							createFetchResult(
								{ chunks: [], search_query: "hello world" },
								true
							)
						);
					},
					{ once: true }
				)
			);
			await runWrangler('ai-search search my-instance --query "hello world"');
			expect(capturedBody).toEqual({
				messages: [{ role: "user", content: "hello world" }],
			});
		});
	});

	// ── namespace ───────────────────────────────────────────────────────────────

	describe("namespace", () => {
		describe("list", () => {
			it("should list namespaces", async ({ expect }) => {
				mockListNamespaces([MOCK_NAMESPACE, MOCK_NAMESPACE_2]);
				await runWrangler("ai-search namespace list");
				expect(std.out).toContain(MOCK_NAMESPACE.name);
				expect(std.out).toContain(MOCK_NAMESPACE_2.name);
				expect(std.out).toContain("Default namespace");
				expect(std.out).toContain("Blog content");
			});

			it("should list namespaces as JSON", async ({ expect }) => {
				mockListNamespaces([MOCK_NAMESPACE]);
				await runWrangler("ai-search namespace list --json");
				const parsed = JSON.parse(std.out);
				expect(parsed).toEqual([MOCK_NAMESPACE]);
			});

			it("should warn when no namespaces exist", async ({ expect }) => {
				mockListNamespaces([]);
				await runWrangler("ai-search namespace list");
				expect(std.warn).toContain(
					"No AI Search namespaces found on this account."
				);
			});

			it("should pass search and pagination params", async ({ expect }) => {
				let capturedUrl: URL | undefined;
				msw.use(
					http.get(
						"*/accounts/:accountId/ai-search/namespaces",
						({ request }) => {
							capturedUrl = new URL(request.url);
							return HttpResponse.json(createFetchResult([], true));
						},
						{ once: true }
					)
				);
				await runWrangler(
					"ai-search namespace list --page 3 --per-page 10 --search blog"
				);
				expect(capturedUrl?.searchParams.get("page")).toBe("3");
				expect(capturedUrl?.searchParams.get("per_page")).toBe("10");
				expect(capturedUrl?.searchParams.get("search")).toBe("blog");
			});
		});

		describe("create", () => {
			it("should create a namespace", async ({ expect }) => {
				let capturedBody: Record<string, unknown> | undefined;
				msw.use(
					http.post(
						"*/accounts/:accountId/ai-search/namespaces",
						async ({ request }) => {
							capturedBody = (await request.json()) as Record<string, unknown>;
							return HttpResponse.json(
								createFetchResult(MOCK_NAMESPACE_2, true)
							);
						},
						{ once: true }
					)
				);
				await runWrangler(
					'ai-search namespace create blog --description "Blog content"'
				);
				expect(capturedBody).toEqual({
					name: "blog",
					description: "Blog content",
				});
				expect(std.out).toContain(
					'Successfully created AI Search namespace "blog"'
				);
			});

			it("should create a namespace without description", async ({
				expect,
			}) => {
				let capturedBody: Record<string, unknown> | undefined;
				msw.use(
					http.post(
						"*/accounts/:accountId/ai-search/namespaces",
						async ({ request }) => {
							capturedBody = (await request.json()) as Record<string, unknown>;
							return HttpResponse.json(
								createFetchResult(
									{ name: "blog", created_at: "2025-02-01T00:00:00Z" },
									true
								)
							);
						},
						{ once: true }
					)
				);
				await runWrangler("ai-search namespace create blog");
				expect(capturedBody).toEqual({ name: "blog" });
			});

			it("should create a namespace as JSON", async ({ expect }) => {
				msw.use(
					http.post(
						"*/accounts/:accountId/ai-search/namespaces",
						() => HttpResponse.json(createFetchResult(MOCK_NAMESPACE_2, true)),
						{ once: true }
					)
				);
				await runWrangler("ai-search namespace create blog --json");
				const parsed = JSON.parse(std.out);
				expect(parsed.name).toBe("blog");
			});

			it("should error when name is missing", async ({ expect }) => {
				await expect(() =>
					runWrangler("ai-search namespace create")
				).rejects.toThrow("Not enough non-option arguments");
			});
		});

		describe("get", () => {
			it("should get namespace details", async ({ expect }) => {
				msw.use(
					http.get(
						"*/accounts/:accountId/ai-search/namespaces/:name",
						() => HttpResponse.json(createFetchResult(MOCK_NAMESPACE_2, true)),
						{ once: true }
					)
				);
				await runWrangler("ai-search namespace get blog");
				expect(std.out).toContain("blog");
				expect(std.out).toContain("Blog content");
			});

			it("should get namespace as JSON", async ({ expect }) => {
				msw.use(
					http.get(
						"*/accounts/:accountId/ai-search/namespaces/:name",
						() => HttpResponse.json(createFetchResult(MOCK_NAMESPACE_2, true)),
						{ once: true }
					)
				);
				await runWrangler("ai-search namespace get blog --json");
				const parsed = JSON.parse(std.out);
				expect(parsed.name).toBe("blog");
				expect(parsed.description).toBe("Blog content");
			});
		});

		describe("update", () => {
			it("should update a namespace description", async ({ expect }) => {
				let capturedBody: Record<string, unknown> | undefined;
				msw.use(
					http.put(
						"*/accounts/:accountId/ai-search/namespaces/:name",
						async ({ request }) => {
							capturedBody = (await request.json()) as Record<string, unknown>;
							return HttpResponse.json(
								createFetchResult(
									{ ...MOCK_NAMESPACE_2, description: "Updated" },
									true
								)
							);
						},
						{ once: true }
					)
				);
				await runWrangler(
					'ai-search namespace update blog --description "Updated"'
				);
				expect(capturedBody).toEqual({ description: "Updated" });
				expect(std.out).toContain(
					'Successfully updated AI Search namespace "blog"'
				);
			});

			it("should error when no fields are provided", async ({ expect }) => {
				await expect(() =>
					runWrangler("ai-search namespace update blog")
				).rejects.toThrow(
					"No fields to update. Provide --description to update the namespace."
				);
			});
		});

		describe("delete", () => {
			it("should delete namespace with confirmation", async ({ expect }) => {
				mockConfirm({
					text: 'OK to delete the AI Search namespace "blog"? This will also remove all instances inside it.',
					result: true,
				});
				msw.use(
					http.delete(
						"*/accounts/:accountId/ai-search/namespaces/:name",
						() => HttpResponse.json(createFetchResult(null, true)),
						{ once: true }
					)
				);
				await runWrangler("ai-search namespace delete blog");
				expect(std.out).toContain(
					'Successfully deleted AI Search namespace "blog"'
				);
			});

			it("should cancel namespace deletion when not confirmed", async ({
				expect,
			}) => {
				mockConfirm({
					text: 'OK to delete the AI Search namespace "blog"? This will also remove all instances inside it.',
					result: false,
				});
				await runWrangler("ai-search namespace delete blog");
				expect(std.out).toContain("Deletion cancelled.");
			});

			it("should delete namespace with --force flag", async ({ expect }) => {
				msw.use(
					http.delete(
						"*/accounts/:accountId/ai-search/namespaces/:name",
						() => HttpResponse.json(createFetchResult(null, true)),
						{ once: true }
					)
				);
				await runWrangler("ai-search namespace delete blog --force");
				expect(std.out).toContain(
					'Successfully deleted AI Search namespace "blog"'
				);
			});
		});
	});

	// ── jobs ────────────────────────────────────────────────────────────────────

	describe("jobs", () => {
		describe("list", () => {
			it("should list jobs for an instance", async ({ expect }) => {
				mockListJobs([MOCK_JOB, MOCK_JOB_2]);
				await runWrangler("ai-search jobs list my-instance");
				expect(std.out).toContain(MOCK_JOB.id);
				expect(std.out).toContain(MOCK_JOB_2.id);
				expect(std.out).toContain("user");
				expect(std.out).toContain("schedule");
			});

			it("should list jobs as JSON", async ({ expect }) => {
				mockListJobs([MOCK_JOB]);
				await runWrangler("ai-search jobs list my-instance --json");
				const parsed = JSON.parse(std.out);
				expect(parsed).toEqual([MOCK_JOB]);
			});

			it("should route through the instance and namespace", async ({
				expect,
			}) => {
				let capturedNamespace: string | undefined;
				let capturedName: string | undefined;
				msw.use(
					http.get(
						"*/accounts/:accountId/ai-search/namespaces/:namespace/instances/:name/jobs",
						({ params }) => {
							capturedNamespace = params.namespace as string;
							capturedName = params.name as string;
							return HttpResponse.json(createFetchResult([], true));
						},
						{ once: true }
					)
				);
				await runWrangler("ai-search jobs list my-instance --namespace blog");
				expect(capturedNamespace).toBe("blog");
				expect(capturedName).toBe("my-instance");
			});

			it("should warn when no jobs exist", async ({ expect }) => {
				mockListJobs([]);
				await runWrangler("ai-search jobs list my-instance");
				expect(std.warn).toContain(
					'No indexing jobs found for AI Search instance "my-instance" in namespace "default".'
				);
			});

			it("should pass pagination params", async ({ expect }) => {
				let capturedUrl: URL | undefined;
				msw.use(
					http.get(
						"*/accounts/:accountId/ai-search/namespaces/:namespace/instances/:name/jobs",
						({ request }) => {
							capturedUrl = new URL(request.url);
							return HttpResponse.json(createFetchResult([], true));
						},
						{ once: true }
					)
				);
				await runWrangler(
					"ai-search jobs list my-instance --page 2 --per-page 5"
				);
				expect(capturedUrl?.searchParams.get("page")).toBe("2");
				expect(capturedUrl?.searchParams.get("per_page")).toBe("5");
			});
		});

		describe("create", () => {
			it("should create a job with a description", async ({ expect }) => {
				let capturedBody: Record<string, unknown> | undefined;
				let capturedNamespace: string | undefined;
				msw.use(
					http.post(
						"*/accounts/:accountId/ai-search/namespaces/:namespace/instances/:name/jobs",
						async ({ request, params }) => {
							capturedBody = (await request.json()) as Record<string, unknown>;
							capturedNamespace = params.namespace as string;
							return HttpResponse.json(createFetchResult(MOCK_JOB, true));
						},
						{ once: true }
					)
				);
				await runWrangler(
					'ai-search jobs create my-instance --description "Manual reindex"'
				);
				expect(capturedNamespace).toBe("default");
				expect(capturedBody).toEqual({ description: "Manual reindex" });
				expect(std.out).toContain(
					'Successfully created indexing job "job-001"'
				);
			});

			it("should create a job without a description", async ({ expect }) => {
				let capturedBody: Record<string, unknown> | undefined;
				msw.use(
					http.post(
						"*/accounts/:accountId/ai-search/namespaces/:namespace/instances/:name/jobs",
						async ({ request }) => {
							capturedBody = (await request.json()) as Record<string, unknown>;
							return HttpResponse.json(createFetchResult(MOCK_JOB, true));
						},
						{ once: true }
					)
				);
				await runWrangler("ai-search jobs create my-instance");
				expect(capturedBody).toEqual({});
			});

			it("should create a job as JSON", async ({ expect }) => {
				mockCreateJob(MOCK_JOB);
				await runWrangler("ai-search jobs create my-instance --json");
				const parsed = JSON.parse(std.out);
				expect(parsed.id).toBe("job-001");
			});
		});

		describe("get", () => {
			it("should get job details", async ({ expect }) => {
				mockGetJob(MOCK_JOB);
				await runWrangler("ai-search jobs get my-instance job-001");
				expect(std.out).toContain("job-001");
				expect(std.out).toContain("user");
				expect(std.out).toContain("completed");
			});

			it("should get a job as JSON", async ({ expect }) => {
				mockGetJob(MOCK_JOB);
				await runWrangler("ai-search jobs get my-instance job-001 --json");
				const parsed = JSON.parse(std.out);
				expect(parsed.id).toBe("job-001");
			});

			it("should route through the job id in the URL", async ({ expect }) => {
				let capturedJobId: string | undefined;
				msw.use(
					http.get(
						"*/accounts/:accountId/ai-search/namespaces/:namespace/instances/:name/jobs/:jobId",
						({ params }) => {
							capturedJobId = params.jobId as string;
							return HttpResponse.json(createFetchResult(MOCK_JOB, true));
						},
						{ once: true }
					)
				);
				await runWrangler("ai-search jobs get my-instance job-xyz");
				expect(capturedJobId).toBe("job-xyz");
			});

			it("should error when job id is missing", async ({ expect }) => {
				await expect(() =>
					runWrangler("ai-search jobs get my-instance")
				).rejects.toThrow("Not enough non-option arguments");
			});
		});

		describe("cancel", () => {
			it("should cancel with confirmation", async ({ expect }) => {
				mockConfirm({
					text: 'OK to cancel the indexing job "job-001" on AI Search instance "my-instance"?',
					result: true,
				});
				const requests = mockCancelJob(MOCK_JOB);
				await runWrangler("ai-search jobs cancel my-instance job-001");
				expect(requests.count).toBe(1);
				expect(std.out).toContain(
					'Successfully cancelled indexing job "job-001"'
				);
			});

			it("should send action=cancel in the PATCH body", async ({ expect }) => {
				let capturedBody: Record<string, unknown> | undefined;
				mockConfirm({
					text: 'OK to cancel the indexing job "job-001" on AI Search instance "my-instance"?',
					result: true,
				});
				msw.use(
					http.patch(
						"*/accounts/:accountId/ai-search/namespaces/:namespace/instances/:name/jobs/:jobId",
						async ({ request }) => {
							capturedBody = (await request.json()) as Record<string, unknown>;
							return HttpResponse.json(createFetchResult(MOCK_JOB, true));
						},
						{ once: true }
					)
				);
				await runWrangler("ai-search jobs cancel my-instance job-001");
				expect(capturedBody).toEqual({ action: "cancel" });
			});

			it("should abort when not confirmed", async ({ expect }) => {
				mockConfirm({
					text: 'OK to cancel the indexing job "job-001" on AI Search instance "my-instance"?',
					result: false,
				});
				const requests = mockCancelJob(MOCK_JOB);
				await runWrangler("ai-search jobs cancel my-instance job-001");
				expect(std.out).toContain("Cancellation aborted.");
				expect(requests.count).toBe(0);
			});

			it("should cancel with --force flag", async ({ expect }) => {
				const requests = mockCancelJob(MOCK_JOB);
				await runWrangler("ai-search jobs cancel my-instance job-001 --force");
				expect(requests.count).toBe(1);
				expect(std.out).toContain(
					'Successfully cancelled indexing job "job-001"'
				);
			});
		});

		describe("logs", () => {
			it("should list job logs", async ({ expect }) => {
				mockListJobLogs([MOCK_JOB_LOG]);
				await runWrangler("ai-search jobs logs my-instance job-001");
				expect(std.out).toContain("Indexing started");
			});

			it("should list job logs as JSON", async ({ expect }) => {
				mockListJobLogs([MOCK_JOB_LOG]);
				await runWrangler("ai-search jobs logs my-instance job-001 --json");
				const parsed = JSON.parse(std.out);
				expect(parsed).toEqual([MOCK_JOB_LOG]);
			});

			it("should warn when no logs exist", async ({ expect }) => {
				mockListJobLogs([]);
				await runWrangler("ai-search jobs logs my-instance job-001");
				expect(std.warn).toContain(
					'No log entries found for indexing job "job-001".'
				);
			});
		});
	});
});

// ── MSW Mock Handlers ─────────────────────────────────────────────────────────

function mockListInstances(instances: unknown[]) {
	msw.use(
		http.get(
			"*/accounts/:accountId/ai-search/namespaces/:namespace/instances",
			() => {
				return HttpResponse.json(
					createFetchResult(instances, true, [], [], {
						page: 1,
						per_page: 20,
						count: instances.length,
						total_count: instances.length,
					})
				);
			},
			{ once: true }
		)
	);
}

function mockCreateInstance(instance: unknown) {
	msw.use(
		http.post(
			"*/accounts/:accountId/ai-search/namespaces/:namespace/instances",
			() => {
				return HttpResponse.json(createFetchResult(instance, true));
			},
			{ once: true }
		)
	);
}

function mockGetInstance(instance: unknown) {
	msw.use(
		http.get(
			"*/accounts/:accountId/ai-search/namespaces/:namespace/instances/:name",
			() => {
				return HttpResponse.json(createFetchResult(instance, true));
			},
			{ once: true }
		)
	);
}

function mockUpdateInstance(instance: unknown) {
	msw.use(
		http.put(
			"*/accounts/:accountId/ai-search/namespaces/:namespace/instances/:name",
			() => {
				return HttpResponse.json(createFetchResult(instance, true));
			},
			{ once: true }
		)
	);
}

function mockDeleteInstance() {
	const requests = { count: 0 };
	msw.use(
		http.delete(
			"*/accounts/:accountId/ai-search/namespaces/:namespace/instances/:name",
			() => {
				requests.count++;
				return HttpResponse.json(createFetchResult(null, true));
			},
			{ once: true }
		)
	);
	return requests;
}

function mockGetStats(stats: unknown) {
	msw.use(
		http.get(
			"*/accounts/:accountId/ai-search/namespaces/:namespace/instances/:name/stats",
			() => {
				return HttpResponse.json(createFetchResult(stats, true));
			},
			{ once: true }
		)
	);
}

function mockSearchInstance(response: unknown) {
	msw.use(
		http.post(
			"*/accounts/:accountId/ai-search/namespaces/:namespace/instances/:name/search",
			() => {
				return HttpResponse.json(createFetchResult(response, true));
			},
			{ once: true }
		)
	);
}

function mockListTokens(tokens: unknown[]) {
	msw.use(
		http.get(
			"*/accounts/:accountId/ai-search/tokens",
			() => {
				return HttpResponse.json(
					createFetchResult(tokens, true, [], [], {
						page: 1,
						per_page: 20,
						count: tokens.length,
						total_count: tokens.length,
					})
				);
			},
			{ once: true }
		)
	);
}

function mockListNamespaces(namespaces: unknown[]) {
	msw.use(
		http.get(
			"*/accounts/:accountId/ai-search/namespaces",
			() => {
				return HttpResponse.json(
					createFetchResult(namespaces, true, [], [], {
						page: 1,
						per_page: 20,
						count: namespaces.length,
						total_count: namespaces.length,
					})
				);
			},
			{ once: true }
		)
	);
}

function mockListJobs(jobs: unknown[]) {
	msw.use(
		http.get(
			"*/accounts/:accountId/ai-search/namespaces/:namespace/instances/:name/jobs",
			() => {
				return HttpResponse.json(
					createFetchResult(jobs, true, [], [], {
						page: 1,
						per_page: 20,
						count: jobs.length,
						total_count: jobs.length,
					})
				);
			},
			{ once: true }
		)
	);
}

function mockCreateJob(job: unknown) {
	msw.use(
		http.post(
			"*/accounts/:accountId/ai-search/namespaces/:namespace/instances/:name/jobs",
			() => {
				return HttpResponse.json(createFetchResult(job, true));
			},
			{ once: true }
		)
	);
}

function mockGetJob(job: unknown) {
	msw.use(
		http.get(
			"*/accounts/:accountId/ai-search/namespaces/:namespace/instances/:name/jobs/:jobId",
			() => {
				return HttpResponse.json(createFetchResult(job, true));
			},
			{ once: true }
		)
	);
}

function mockCancelJob(job: unknown) {
	const requests = { count: 0 };
	msw.use(
		http.patch(
			"*/accounts/:accountId/ai-search/namespaces/:namespace/instances/:name/jobs/:jobId",
			() => {
				requests.count++;
				return HttpResponse.json(createFetchResult(job, true));
			},
			{ once: true }
		)
	);
	return requests;
}

function mockListJobLogs(logs: unknown[]) {
	msw.use(
		http.get(
			"*/accounts/:accountId/ai-search/namespaces/:namespace/instances/:name/jobs/:jobId/logs",
			() => {
				return HttpResponse.json(
					createFetchResult(logs, true, [], [], {
						page: 1,
						per_page: 20,
						count: logs.length,
						total_count: logs.length,
					})
				);
			},
			{ once: true }
		)
	);
}
