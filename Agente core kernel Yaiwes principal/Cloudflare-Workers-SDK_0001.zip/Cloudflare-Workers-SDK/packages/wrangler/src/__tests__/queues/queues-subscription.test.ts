import { runInTempDir } from "@cloudflare/workers-utils/test-helpers";
import { describe, it } from "vitest";
import { EventSourceType } from "../../queues/subscription-types";
import { mockAccountId, mockApiToken } from "../helpers/mock-account-id";
import { mockConsoleMethods } from "../helpers/mock-console";
import { mockConfirm } from "../helpers/mock-dialogs";
import { useMockIsTTY } from "../helpers/mock-istty";
import { runWrangler } from "../helpers/run-wrangler";
import {
	mockCreateSubscriptionRequest,
	mockDeleteSubscriptionRequest,
	mockGetQueueByNameRequest,
	mockGetSubscriptionRequest,
	mockListSubscriptionsRequest,
	mockUpdateSubscriptionRequest,
} from "./mock-utils";
import type {
	CreateEventSubscriptionRequest,
	EventSubscription,
} from "../../queues/subscription-types";

describe("queues subscription", () => {
	mockAccountId();
	mockApiToken();
	runInTempDir();

	const std = mockConsoleMethods();
	const expectedQueueId = "queueId";
	const expectedQueueName = "testQueue";

	const mockSubscription1: EventSubscription = {
		id: "sub-123",
		created_at: "2024-01-01T00:00:00Z",
		modified_at: "2024-01-01T00:00:00Z",
		name: "Test Subscription 1",
		enabled: true,
		source: {
			type: EventSourceType.WORKERS_BUILDS_WORKER,
			worker_name: "my-worker",
		},
		destination: {
			type: "queues.queue",
			queue_id: expectedQueueId,
		},
		events: ["build.completed", "build.failed"],
	};

	const mockSubscription2: EventSubscription = {
		id: "sub-456",
		created_at: "2024-01-02T00:00:00Z",
		modified_at: "2024-01-02T00:00:00Z",
		name: "Test Subscription 2",
		enabled: false,
		source: {
			type: EventSourceType.KV,
		},
		destination: {
			type: "queues.queue",
			queue_id: expectedQueueId,
		},
		events: ["namespace.created"],
	};

	const mockSubscriptionEmail: EventSubscription = {
		id: "sub-email",
		created_at: "2024-01-01T00:00:00Z",
		modified_at: "2024-01-01T00:00:00Z",
		name: "Test Subscription Email",
		enabled: true,
		source: {
			type: EventSourceType.EMAIL_SENDING,
			zone_id: "zone-123",
			domain: "example.com",
		},
		destination: {
			type: "queues.queue",
			queue_id: expectedQueueId,
		},
		events: ["message.delivered"],
	};

	describe("create", () => {
		it("should show the correct help text", async ({ expect }) => {
			await runWrangler("queues subscription create --help");
			expect(std.err).toMatchInlineSnapshot(`""`);
			expect(std.out).toMatchInlineSnapshot(`
				"wrangler queues subscription create <queue>

				Create a new event subscription for a queue

				POSITIONALS
				  queue  The name of the queue to create the subscription for  [string] [required]

				GLOBAL FLAGS
				  -c, --config          Path to Wrangler configuration file  [string]
				      --cwd             Run as if Wrangler was started in the specified directory instead of the current working directory  [string]
				  -e, --env             Environment to use for operations, and for selecting .env and .dev.vars files  [string]
				      --env-file        Path to an .env file to load - can be specified multiple times - values from earlier files are overridden by values in later files  [array]
				  -h, --help            Show help  [boolean]
				      --install-skills  Install Cloudflare skills for detected AI coding agents before running the command  [boolean] [default: false]
				      --profile         Use a specific auth profile  [string]
				  -v, --version         Show version number  [boolean]

				OPTIONS
				      --source         The event source type  [string] [required] [choices: "artifacts", "artifacts.repo", "email.sending", "images", "kv", "r2", "superSlurper", "vectorize", "workersAi.model", "workersBuilds.worker", "workflows.workflow"]
				      --events         Comma-separated list of event types to subscribe to  [string] [required]
				      --name           Name for the subscription (auto-generated if not provided)  [string]
				      --enabled        Whether the subscription should be active  [boolean] [default: true]
				      --model-name     Workers AI model name (required for workersAi.model source)  [string]
				      --worker-name    Worker name (required for workersBuilds.worker source)  [string]
				      --workflow-name  Workflow name (required for workflows.workflow source)  [string]
				      --zone-id        Zone ID (required for email.sending source)  [string]
				      --domain         Sending domain — zone apex or verified subdomain (required for email.sending source)  [string]"
			`);
		});

		it("should create a subscription for workersBuilds.worker source", async ({
			expect,
		}) => {
			const queueNameResolveRequest = mockGetQueueByNameRequest(
				expectedQueueName,
				{
					queue_id: expectedQueueId,
					queue_name: expectedQueueName,
					created_on: "",
					producers: [],
					consumers: [],
					producers_total_count: 0,
					consumers_total_count: 0,
					modified_on: "",
				}
			);

			const expectedRequest: Partial<CreateEventSubscriptionRequest> = {
				name: "testQueue workersBuilds.worker",
				enabled: true,
				source: {
					type: EventSourceType.WORKERS_BUILDS_WORKER,
					worker_name: "my-worker",
				},
				events: ["build.completed", "build.failed"],
			};

			const createRequest = mockCreateSubscriptionRequest(
				expectedRequest,
				expectedQueueId
			);

			await runWrangler(
				"queues subscription create testQueue --source workersBuilds.worker --events build.completed,build.failed --worker-name my-worker"
			);

			expect(queueNameResolveRequest.count).toEqual(1);
			expect(createRequest.count).toEqual(1);
			expect(std.err).toMatchInlineSnapshot(`""`);
			expect(std.out).toMatchInlineSnapshot(`
				"
				 ⛅️ wrangler x.x.x
				──────────────────
				Creating event subscription for queue 'testQueue'...
				✨ Successfully created event subscription 'testQueue workersBuilds.worker' with id 'sub-123'."
			`);
		});

		it("should create a subscription for images source", async ({ expect }) => {
			const queueNameResolveRequest = mockGetQueueByNameRequest(
				expectedQueueName,
				{
					queue_id: expectedQueueId,
					queue_name: expectedQueueName,
					created_on: "",
					producers: [],
					consumers: [],
					producers_total_count: 0,
					consumers_total_count: 0,
					modified_on: "",
				}
			);

			const expectedRequest: Partial<CreateEventSubscriptionRequest> = {
				name: "testQueue images",
				enabled: true,
				source: {
					type: EventSourceType.IMAGES,
				},
				events: ["image.uploaded"],
			};

			const createRequest = mockCreateSubscriptionRequest(
				expectedRequest,
				expectedQueueId
			);

			await runWrangler(
				"queues subscription create testQueue --source images --events image.uploaded"
			);

			expect(queueNameResolveRequest.count).toEqual(1);
			expect(createRequest.count).toEqual(1);
			expect(std.err).toMatchInlineSnapshot(`""`);
			expect(std.out).toMatchInlineSnapshot(`
				"
				 ⛅️ wrangler x.x.x
				──────────────────
				Creating event subscription for queue 'testQueue'...
				✨ Successfully created event subscription 'testQueue images' with id 'sub-123'."
			`);
		});

		it("should create a subscription for an Artifacts account source", async ({
			expect,
		}) => {
			const queueNameResolveRequest = mockGetQueueByNameRequest(
				expectedQueueName,
				{
					queue_id: expectedQueueId,
					queue_name: expectedQueueName,
					created_on: "",
					producers: [],
					consumers: [],
					producers_total_count: 0,
					consumers_total_count: 0,
					modified_on: "",
				}
			);

			const createRequest = mockCreateSubscriptionRequest(
				{
					name: "testQueue artifacts",
					enabled: true,
					source: { type: EventSourceType.ARTIFACTS },
					events: ["repo.created"],
				},
				expectedQueueId
			);

			await runWrangler(
				"queues subscription create testQueue --source artifacts --events repo.created"
			);

			expect(queueNameResolveRequest.count).toEqual(1);
			expect(createRequest.count).toEqual(1);
		});

		it("should create a subscription for an Artifacts repository source", async ({
			expect,
		}) => {
			const queueNameResolveRequest = mockGetQueueByNameRequest(
				expectedQueueName,
				{
					queue_id: expectedQueueId,
					queue_name: expectedQueueName,
					created_on: "",
					producers: [],
					consumers: [],
					producers_total_count: 0,
					consumers_total_count: 0,
					modified_on: "",
				}
			);

			const createRequest = mockCreateSubscriptionRequest(
				{
					name: "testQueue artifacts.repo",
					enabled: true,
					source: { type: EventSourceType.ARTIFACTS_REPO },
					events: ["pushed"],
				},
				expectedQueueId
			);

			await runWrangler(
				"queues subscription create testQueue --source artifacts.repo --events pushed"
			);

			expect(queueNameResolveRequest.count).toEqual(1);
			expect(createRequest.count).toEqual(1);
		});

		it("should create a subscription for email.sending source", async ({
			expect,
		}) => {
			const queueNameResolveRequest = mockGetQueueByNameRequest(
				expectedQueueName,
				{
					queue_id: expectedQueueId,
					queue_name: expectedQueueName,
					created_on: "",
					producers: [],
					consumers: [],
					producers_total_count: 0,
					consumers_total_count: 0,
					modified_on: "",
				}
			);

			const expectedRequest: Partial<CreateEventSubscriptionRequest> = {
				name: "testQueue email.sending",
				enabled: true,
				source: {
					type: EventSourceType.EMAIL_SENDING,
					zone_id: "zone-123",
					domain: "example.com",
				},
				events: ["message.delivered"],
			};

			const createRequest = mockCreateSubscriptionRequest(
				expectedRequest,
				expectedQueueId
			);

			await runWrangler(
				"queues subscription create testQueue --source email.sending --events message.delivered --zone-id zone-123 --domain example.com"
			);

			expect(queueNameResolveRequest.count).toEqual(1);
			expect(createRequest.count).toEqual(1);
			expect(std.err).toMatchInlineSnapshot(`""`);
			expect(std.out).toMatchInlineSnapshot(`
				"
				 ⛅️ wrangler x.x.x
				──────────────────
				Creating event subscription for queue 'testQueue'...
				✨ Successfully created event subscription 'testQueue email.sending' with id 'sub-123'."
			`);
		});

		it("should show error when zone-id is missing for email.sending source", async ({
			expect,
		}) => {
			await expect(
				runWrangler(
					"queues subscription create testQueue --source email.sending --events message.delivered --domain example.com"
				)
			).rejects.toThrowErrorMatchingInlineSnapshot(
				`[Error: --zone-id is required when using source 'email.sending']`
			);
		});

		it("should show error when domain is missing for email.sending source", async ({
			expect,
		}) => {
			await expect(
				runWrangler(
					"queues subscription create testQueue --source email.sending --events message.delivered --zone-id zone-123"
				)
			).rejects.toThrowErrorMatchingInlineSnapshot(
				`[Error: --domain is required when using source 'email.sending']`
			);
		});

		it("should create subscription with custom name and disabled state", async ({
			expect,
		}) => {
			const queueNameResolveRequest = mockGetQueueByNameRequest(
				expectedQueueName,
				{
					queue_id: expectedQueueId,
					queue_name: expectedQueueName,
					created_on: "",
					producers: [],
					consumers: [],
					producers_total_count: 0,
					consumers_total_count: 0,
					modified_on: "",
				}
			);

			const expectedRequest: Partial<CreateEventSubscriptionRequest> = {
				name: "Custom Subscription",
				enabled: false,
				source: {
					type: EventSourceType.WORKERS_BUILDS_WORKER,
					worker_name: "my-worker",
				},
				events: ["build.completed"],
			};

			const createRequest = mockCreateSubscriptionRequest(
				expectedRequest,
				expectedQueueId
			);

			await runWrangler(
				"queues subscription create testQueue --source workersBuilds.worker --events build.completed --worker-name my-worker --name 'Custom Subscription' --enabled false"
			);

			expect(queueNameResolveRequest.count).toEqual(1);
			expect(createRequest.count).toEqual(1);
			expect(std.err).toMatchInlineSnapshot(`""`);
			expect(std.out).toMatchInlineSnapshot(`
				"
				 ⛅️ wrangler x.x.x
				──────────────────
				Creating event subscription for queue 'testQueue'...
				✨ Successfully created event subscription 'Custom Subscription' with id 'sub-123'."
			`);
		});

		it("should show error when worker-name is missing for workersBuilds.worker source", async ({
			expect,
		}) => {
			await expect(
				runWrangler(
					"queues subscription create testQueue --source workersBuilds.worker --events build.completed"
				)
			).rejects.toThrowErrorMatchingInlineSnapshot(
				`[Error: --worker-name is required when using source 'workersBuilds.worker']`
			);
		});

		it("should show error for invalid source type", async ({ expect }) => {
			await expect(
				runWrangler(
					"queues subscription create testQueue --source invalid --events test"
				)
			).rejects.toThrowErrorMatchingInlineSnapshot(`
				[Error: Invalid values:
				  Argument: source, Given: "invalid", Choices: "artifacts", "artifacts.repo", "email.sending", "images", "kv", "r2", "superSlurper", "vectorize", "workersAi.model", "workersBuilds.worker", "workflows.workflow"]
			`);
		});

		it("should show error when no events are provided", async ({ expect }) => {
			await expect(
				runWrangler(
					"queues subscription create testQueue --source workersBuilds.worker --events '' --worker-name my-worker"
				)
			).rejects.toThrowErrorMatchingInlineSnapshot(
				`[Error: No events specified. Use --events to provide a comma-separated list of event types to subscribe to. For a complete list of sources and corresponding events, please refer to: https://developers.cloudflare.com/queues/event-subscriptions/events-schemas/]`
			);
		});

		it("should show error when queue does not exist", async ({ expect }) => {
			const queueNameResolveRequest = mockGetQueueByNameRequest(
				"nonexistent",
				null
			);

			await expect(
				runWrangler(
					"queues subscription create nonexistent --source workersBuilds.worker --events build.completed --worker-name my-worker"
				)
			).rejects.toThrowErrorMatchingInlineSnapshot(
				`[Error: Queue "nonexistent" does not exist. To create it, run: wrangler queues create nonexistent]`
			);

			expect(queueNameResolveRequest.count).toEqual(1);
		});
	});

	describe("list", () => {
		it("should show the correct help text", async ({ expect }) => {
			await runWrangler("queues subscription list --help");
			expect(std.err).toMatchInlineSnapshot(`""`);
			expect(std.out).toMatchInlineSnapshot(`
				"wrangler queues subscription list <queue>

				List event subscriptions for a queue

				POSITIONALS
				  queue  The name of the queue to list subscriptions for  [string] [required]

				GLOBAL FLAGS
				  -c, --config          Path to Wrangler configuration file  [string]
				      --cwd             Run as if Wrangler was started in the specified directory instead of the current working directory  [string]
				  -e, --env             Environment to use for operations, and for selecting .env and .dev.vars files  [string]
				      --env-file        Path to an .env file to load - can be specified multiple times - values from earlier files are overridden by values in later files  [array]
				  -h, --help            Show help  [boolean]
				      --install-skills  Install Cloudflare skills for detected AI coding agents before running the command  [boolean] [default: false]
				      --profile         Use a specific auth profile  [string]
				  -v, --version         Show version number  [boolean]

				OPTIONS
				      --page      Page number for pagination  [number] [default: 1]
				      --per-page  Number of subscriptions per page  [number] [default: 20]
				      --json      Output in JSON format  [boolean] [default: false]"
			`);
		});

		it("should show message when no subscriptions exist", async ({
			expect,
		}) => {
			const queueNameResolveRequest = mockGetQueueByNameRequest(
				expectedQueueName,
				{
					queue_id: expectedQueueId,
					queue_name: expectedQueueName,
					created_on: "",
					producers: [],
					consumers: [],
					producers_total_count: 0,
					consumers_total_count: 0,
					modified_on: "",
				}
			);

			const listRequest = mockListSubscriptionsRequest(expectedQueueId, []);

			await runWrangler("queues subscription list testQueue");

			expect(queueNameResolveRequest.count).toEqual(1);
			expect(listRequest.count).toEqual(1);
			expect(std.err).toMatchInlineSnapshot(`""`);
			expect(std.out).toMatchInlineSnapshot(`
				"
				 ⛅️ wrangler x.x.x
				──────────────────
				No event subscriptions found for queue 'testQueue'."
			`);
		});

		it("should list subscriptions for a queue", async ({ expect }) => {
			const queueNameResolveRequest = mockGetQueueByNameRequest(
				expectedQueueName,
				{
					queue_id: expectedQueueId,
					queue_name: expectedQueueName,
					created_on: "",
					producers: [],
					consumers: [],
					producers_total_count: 0,
					consumers_total_count: 0,
					modified_on: "",
				}
			);

			const listRequest = mockListSubscriptionsRequest(expectedQueueId, [
				mockSubscription1,
				mockSubscription2,
			]);

			await runWrangler("queues subscription list testQueue");

			expect(queueNameResolveRequest.count).toEqual(1);
			expect(listRequest.count).toEqual(1);
			expect(std.err).toMatchInlineSnapshot(`""`);
			expect(std.out).toMatchInlineSnapshot(`
				"
				 ⛅️ wrangler x.x.x
				──────────────────
				Event subscriptions for queue 'testQueue':
				┌─┬─┬─┬─┬─┬─┐
				│ ID │ Name │ Source │ Events │ Resource │ Enabled │
				├─┼─┼─┼─┼─┼─┤
				│ sub-123 │ Test Subscription 1 │ workersBuilds.worker │ build.completed, build.failed │ my-worker │ Yes │
				├─┼─┼─┼─┼─┼─┤
				│ sub-456 │ Test Subscription 2 │ kv │ namespace.created │ │ No │
				└─┴─┴─┴─┴─┴─┘"
			`);
		});

		it('supports valid json output with "--json" flag', async ({ expect }) => {
			mockGetQueueByNameRequest(expectedQueueName, {
				queue_id: expectedQueueId,
				queue_name: expectedQueueName,
				created_on: "",
				producers: [],
				consumers: [],
				producers_total_count: 0,
				consumers_total_count: 0,
				modified_on: "",
			});
			mockListSubscriptionsRequest(expectedQueueId, [
				mockSubscription1,
				mockSubscription2,
			]);

			await runWrangler("queues subscription list testQueue --json");

			expect(std.err).toMatchInlineSnapshot(`""`);
			expect(JSON.parse(std.out)).toMatchInlineSnapshot(`
				[
				  {
				    "created_at": "2024-01-01T00:00:00Z",
				    "destination": {
				      "queue_id": "queueId",
				      "type": "queues.queue",
				    },
				    "enabled": true,
				    "events": [
				      "build.completed",
				      "build.failed",
				    ],
				    "id": "sub-123",
				    "modified_at": "2024-01-01T00:00:00Z",
				    "name": "Test Subscription 1",
				    "source": {
				      "type": "workersBuilds.worker",
				      "worker_name": "my-worker",
				    },
				  },
				  {
				    "created_at": "2024-01-02T00:00:00Z",
				    "destination": {
				      "queue_id": "queueId",
				      "type": "queues.queue",
				    },
				    "enabled": false,
				    "events": [
				      "namespace.created",
				    ],
				    "id": "sub-456",
				    "modified_at": "2024-01-02T00:00:00Z",
				    "name": "Test Subscription 2",
				    "source": {
				      "type": "kv",
				    },
				  },
				]
			`);
		});

		it("should show error when queue does not exist", async ({ expect }) => {
			const queueNameResolveRequest = mockGetQueueByNameRequest(
				"nonexistent",
				null
			);

			await expect(
				runWrangler("queues subscription list nonexistent")
			).rejects.toThrowErrorMatchingInlineSnapshot(
				`[Error: Queue "nonexistent" does not exist. To create it, run: wrangler queues create nonexistent]`
			);

			expect(queueNameResolveRequest.count).toEqual(1);
		});
	});

	describe("get", () => {
		it("should show the correct help text", async ({ expect }) => {
			await runWrangler("queues subscription get --help");
			expect(std.err).toMatchInlineSnapshot(`""`);
			expect(std.out).toMatchInlineSnapshot(`
				"wrangler queues subscription get <queue>

				Get details about a specific event subscription

				POSITIONALS
				  queue  The name of the queue  [string] [required]

				GLOBAL FLAGS
				  -c, --config          Path to Wrangler configuration file  [string]
				      --cwd             Run as if Wrangler was started in the specified directory instead of the current working directory  [string]
				  -e, --env             Environment to use for operations, and for selecting .env and .dev.vars files  [string]
				      --env-file        Path to an .env file to load - can be specified multiple times - values from earlier files are overridden by values in later files  [array]
				  -h, --help            Show help  [boolean]
				      --install-skills  Install Cloudflare skills for detected AI coding agents before running the command  [boolean] [default: false]
				      --profile         Use a specific auth profile  [string]
				  -v, --version         Show version number  [boolean]

				OPTIONS
				      --id    The ID of the subscription to retrieve  [string] [required]
				      --json  Output in JSON format  [boolean] [default: false]"
			`);
		});

		it("should get a subscription by ID", async ({ expect }) => {
			mockGetQueueByNameRequest("testQueue", {
				queue_id: expectedQueueId,
				queue_name: "testQueue",
				created_on: "",
				modified_on: "",
				producers: [],
				consumers: [],
				producers_total_count: 0,
				consumers_total_count: 0,
			});
			const getRequest = mockGetSubscriptionRequest(
				"sub-123",
				mockSubscription1
			);

			await runWrangler("queues subscription get testQueue --id sub-123");

			expect(getRequest.count).toEqual(1);
			expect(std.err).toMatchInlineSnapshot(`""`);
			expect(std.out).toMatchInlineSnapshot(`
				"
				 ⛅️ wrangler x.x.x
				──────────────────
				ID:           sub-123
				Name:         Test Subscription 1
				Source:       workersBuilds.worker
				Resource:     my-worker
				Queue ID:     queueId
				Events:       build.completed, build.failed
				Enabled:      Yes
				Created At:   1/1/2024, 12:00:00 AM
				Modified At:  1/1/2024, 12:00:00 AM"
			`);
		});

		it("should render the sending domain as the resource for email.sending source", async ({
			expect,
		}) => {
			mockGetQueueByNameRequest("testQueue", {
				queue_id: expectedQueueId,
				queue_name: "testQueue",
				created_on: "",
				modified_on: "",
				producers: [],
				consumers: [],
				producers_total_count: 0,
				consumers_total_count: 0,
			});
			const getRequest = mockGetSubscriptionRequest(
				"sub-email",
				mockSubscriptionEmail
			);

			await runWrangler("queues subscription get testQueue --id sub-email");

			expect(getRequest.count).toEqual(1);
			expect(std.err).toMatchInlineSnapshot(`""`);
			expect(std.out).toMatchInlineSnapshot(`
				"
				 ⛅️ wrangler x.x.x
				──────────────────
				ID:           sub-email
				Name:         Test Subscription Email
				Source:       email.sending
				Resource:     example.com
				Queue ID:     queueId
				Events:       message.delivered
				Enabled:      Yes
				Created At:   1/1/2024, 12:00:00 AM
				Modified At:  1/1/2024, 12:00:00 AM"
			`);
		});

		it('supports valid json output with "--json" flag', async ({ expect }) => {
			mockGetQueueByNameRequest("testQueue", {
				queue_id: expectedQueueId,
				queue_name: "testQueue",
				created_on: "",
				modified_on: "",
				producers: [],
				consumers: [],
				producers_total_count: 0,
				consumers_total_count: 0,
			});
			mockGetSubscriptionRequest("sub-123", mockSubscription1);

			await runWrangler(
				"queues subscription get testQueue --id sub-123 --json"
			);

			expect(std.err).toMatchInlineSnapshot(`""`);
			expect(JSON.parse(std.out)).toMatchInlineSnapshot(`
				{
				  "created_at": "2024-01-01T00:00:00Z",
				  "destination": {
				    "queue_id": "queueId",
				    "type": "queues.queue",
				  },
				  "enabled": true,
				  "events": [
				    "build.completed",
				    "build.failed",
				  ],
				  "id": "sub-123",
				  "modified_at": "2024-01-01T00:00:00Z",
				  "name": "Test Subscription 1",
				  "source": {
				    "type": "workersBuilds.worker",
				    "worker_name": "my-worker",
				  },
				}
			`);
		});

		it("should show error when subscription does not exist", async ({
			expect,
		}) => {
			const getRequest = mockGetSubscriptionRequest("nonexistent-id", null);

			await expect(
				runWrangler("queues subscription get testQueue --id nonexistent-id")
			).rejects.toThrowErrorMatchingInlineSnapshot(
				`[APIError: A request to the Cloudflare API (/accounts/some-account-id/event_subscriptions/subscriptions/nonexistent-id) failed.]`
			);

			expect(getRequest.count).toEqual(1);
		});
	});

	describe("delete", () => {
		const { setIsTTY } = useMockIsTTY();

		it("should show the correct help text", async ({ expect }) => {
			await runWrangler("queues subscription delete --help");
			expect(std.err).toMatchInlineSnapshot(`""`);
			expect(std.out).toMatchInlineSnapshot(`
				"wrangler queues subscription delete <queue>

				Delete an event subscription from a queue

				POSITIONALS
				  queue  The name of the queue  [string] [required]

				GLOBAL FLAGS
				  -c, --config          Path to Wrangler configuration file  [string]
				      --cwd             Run as if Wrangler was started in the specified directory instead of the current working directory  [string]
				  -e, --env             Environment to use for operations, and for selecting .env and .dev.vars files  [string]
				      --env-file        Path to an .env file to load - can be specified multiple times - values from earlier files are overridden by values in later files  [array]
				  -h, --help            Show help  [boolean]
				      --install-skills  Install Cloudflare skills for detected AI coding agents before running the command  [boolean] [default: false]
				      --profile         Use a specific auth profile  [string]
				  -v, --version         Show version number  [boolean]

				OPTIONS
				      --id     The ID of the subscription to delete  [string] [required]
				  -y, --force  Skip confirmation  [boolean] [default: false]"
			`);
		});

		it("should delete a subscription after confirmation", async ({
			expect,
		}) => {
			mockGetQueueByNameRequest("testQueue", {
				queue_id: expectedQueueId,
				queue_name: "testQueue",
				created_on: "",
				modified_on: "",
				producers: [],
				consumers: [],
				producers_total_count: 0,
				consumers_total_count: 0,
			});
			const getRequest = mockGetSubscriptionRequest(
				"sub-123",
				mockSubscription1
			);
			const deleteRequest = mockDeleteSubscriptionRequest("sub-123");

			setIsTTY(true);
			mockConfirm({
				text: "Are you sure you want to delete the event subscription 'Test Subscription 1' (sub-123)?",
				result: true,
			});

			await runWrangler("queues subscription delete testQueue --id sub-123");

			expect(getRequest.count).toEqual(1);
			expect(deleteRequest.count).toEqual(1);
			expect(std.err).toMatchInlineSnapshot(`""`);
			expect(std.out).toMatchInlineSnapshot(`
				"
				 ⛅️ wrangler x.x.x
				──────────────────
				✨ Successfully deleted event subscription 'Test Subscription 1' with id 'sub-123'."
			`);
		});

		it("should delete subscription without confirmation when --force is used", async ({
			expect,
		}) => {
			mockGetQueueByNameRequest("testQueue", {
				queue_id: expectedQueueId,
				queue_name: "testQueue",
				created_on: "",
				modified_on: "",
				producers: [],
				consumers: [],
				producers_total_count: 0,
				consumers_total_count: 0,
			});
			const getRequest = mockGetSubscriptionRequest(
				"sub-123",
				mockSubscription1
			);
			const deleteRequest = mockDeleteSubscriptionRequest("sub-123");

			await runWrangler(
				"queues subscription delete testQueue --id sub-123 --force"
			);

			expect(getRequest.count).toEqual(1);
			expect(deleteRequest.count).toEqual(1);
			expect(std.err).toMatchInlineSnapshot(`""`);
			expect(std.out).toMatchInlineSnapshot(`
				"
				 ⛅️ wrangler x.x.x
				──────────────────
				✨ Successfully deleted event subscription 'Test Subscription 1' with id 'sub-123'."
			`);
		});

		it("should show error when subscription does not exist", async ({
			expect,
		}) => {
			const getRequest = mockGetSubscriptionRequest("nonexistent-id", null);
			const deleteRequest = mockDeleteSubscriptionRequest("nonexistent-id");

			await expect(
				runWrangler("queues subscription delete testQueue --id nonexistent-id")
			).rejects.toThrowErrorMatchingInlineSnapshot(
				`[APIError: A request to the Cloudflare API (/accounts/some-account-id/event_subscriptions/subscriptions/nonexistent-id) failed.]`
			);

			expect(getRequest.count).toEqual(1);
			expect(deleteRequest.count).toEqual(0); // Should not call delete if get fails
		});
	});

	describe("update", () => {
		it("should update subscription with multiple fields", async ({
			expect,
		}) => {
			const subscriptionId = "subscription-123";
			mockGetQueueByNameRequest("test-queue", {
				queue_id: "queue-id-1",
				queue_name: "test-queue",
				created_on: "",
				modified_on: "",
				producers: [],
				consumers: [],
				producers_total_count: 0,
				consumers_total_count: 0,
			});
			const requests = mockUpdateSubscriptionRequest(subscriptionId, {
				name: "new-name",
				events: ["build.completed", "build.failed"],
				enabled: false,
			});
			mockGetSubscriptionRequest(subscriptionId, {
				id: subscriptionId,
				name: "old-subscription",
				source: {
					type: EventSourceType.WORKERS_BUILDS_WORKER,
					worker_name: "my-worker",
				},
				destination: {
					type: "queues.queue",
					queue_id: "queue-id-1",
				},
				events: ["build.completed"],
				enabled: true,
				created_at: "2023-01-01T00:00:00.000Z",
				modified_at: "2023-01-01T00:00:00.000Z",
			});

			await runWrangler(
				`queues subscription update test-queue --id ${subscriptionId} --name new-name --events "build.completed,build.failed" --enabled false`
			);

			expect(requests.count).toBe(1);
			expect(std.out).toMatchInlineSnapshot(`
				"
				 ⛅️ wrangler x.x.x
				──────────────────
				Updating event subscription...
				✨ Successfully updated event subscription 'updated-subscription' with id 'subscription-123'."
			`);
		});

		it('supports json output with "--json" flag', async ({ expect }) => {
			const subscriptionId = "subscription-123";
			mockGetQueueByNameRequest("test-queue", {
				queue_id: "queue-id-1",
				queue_name: "test-queue",
				created_on: "",
				modified_on: "",
				producers: [],
				consumers: [],
				producers_total_count: 0,
				consumers_total_count: 0,
			});
			mockUpdateSubscriptionRequest(subscriptionId, {
				name: "new-name",
				events: ["build.completed", "build.failed"],
				enabled: false,
			});
			mockGetSubscriptionRequest(subscriptionId, {
				id: subscriptionId,
				name: "old-subscription",
				source: {
					type: EventSourceType.WORKERS_BUILDS_WORKER,
					worker_name: "my-worker",
				},
				destination: {
					type: "queues.queue",
					queue_id: "queue-id-1",
				},
				events: ["build.completed"],
				enabled: true,
				created_at: "2023-01-01T00:00:00.000Z",
				modified_at: "2023-01-01T00:00:00.000Z",
			});

			await runWrangler(
				`queues subscription update test-queue --id ${subscriptionId} --name new-name --events "build.completed,build.failed" --enabled false --json`
			);

			expect(std.out).toMatchInlineSnapshot(`
				"Updating event subscription...
				{
				  "id": "subscription-123",
				  "name": "updated-subscription",
				  "source": {
				    "type": "workersBuilds.worker",
				    "worker_name": "my-worker"
				  },
				  "destination": {
				    "queue_id": "queue-id-1"
				  },
				  "events": [
				    "build.completed",
				    "build.failed"
				  ],
				  "enabled": false,
				  "modified_at": "2023-01-01T00:00:00.000Z"
				}"
			`);
		});

		it("should error when no fields provided", async ({ expect }) => {
			const subscriptionId = "subscription-123";
			mockGetQueueByNameRequest("test-queue", {
				queue_id: "queue-id-1",
				queue_name: "test-queue",
				created_on: "",
				modified_on: "",
				producers: [],
				consumers: [],
				producers_total_count: 0,
				consumers_total_count: 0,
			});
			mockGetSubscriptionRequest(subscriptionId, {
				id: subscriptionId,
				name: "old-subscription",
				source: {
					type: EventSourceType.WORKERS_BUILDS_WORKER,
					worker_name: "my-worker",
				},
				destination: {
					type: "queues.queue",
					queue_id: "queue-id-1",
				},
				events: ["build.completed"],
				enabled: true,
				created_at: "2023-01-01T00:00:00.000Z",
				modified_at: "2023-01-01T00:00:00.000Z",
			});

			await expect(
				runWrangler(
					`queues subscription update test-queue --id ${subscriptionId}`
				)
			).rejects.toThrow(
				"No fields specified for update. Provide at least one of --name, --events, or --enabled to update the subscription."
			);
		});
	});
});
