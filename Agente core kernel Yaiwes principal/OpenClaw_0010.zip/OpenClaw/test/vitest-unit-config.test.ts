// Vitest unit config tests validate unit test project configuration.
import { afterEach, describe, expect, it } from "vitest";
import { createPatternFileHelper } from "./helpers/pattern-file.js";
import { normalizeConfigPath, normalizeConfigPaths } from "./helpers/vitest-config-paths.js";
import {
  createUnitVitestConfig,
  createUnitVitestConfigWithOptions,
  loadExtraExcludePatternsFromEnv,
} from "./vitest/vitest.unit.config.ts";

const patternFiles = createPatternFileHelper("openclaw-vitest-unit-config-");

function requireTestConfig<T extends { test?: unknown }>(config: T): NonNullable<T["test"]> {
  if (!config.test) {
    throw new Error("expected unit vitest test config");
  }
  return config.test as NonNullable<T["test"]>;
}

afterEach(() => {
  patternFiles.cleanup();
});

describe("loadExtraExcludePatternsFromEnv", () => {
  it("returns an empty list when no extra exclude file is configured", () => {
    expect(loadExtraExcludePatternsFromEnv({})).toStrictEqual([]);
  });

  it("loads extra exclude patterns from a JSON file", () => {
    const filePath = patternFiles.writePatternFile("extra-exclude.json", [
      "src/infra/update-runner.test.ts",
      42,
      "",
      "ui/src/ui/views/chat.test.ts",
    ]);

    expect(
      loadExtraExcludePatternsFromEnv({
        OPENCLAW_VITEST_EXTRA_EXCLUDE_FILE: filePath,
      }),
    ).toEqual(["src/infra/update-runner.test.ts", "ui/src/ui/views/chat.test.ts"]);
  });

  it("throws when the configured file is not a JSON array", () => {
    const filePath = patternFiles.writePatternFile("extra-exclude.json", {
      exclude: ["src/infra/update-runner.test.ts"],
    });

    expect(() =>
      loadExtraExcludePatternsFromEnv({
        OPENCLAW_VITEST_EXTRA_EXCLUDE_FILE: filePath,
      }),
    ).toThrow(/JSON array/u);
  });
});

describe("unit vitest config", () => {
  it("defaults unit tests to the non-isolated runner", () => {
    const unitConfig = createUnitVitestConfig({});
    const testConfig = requireTestConfig(unitConfig);
    expect(testConfig.isolate).toBe(false);
    expect(normalizeConfigPath(testConfig.runner)).toBe("test/non-isolated-runner.ts");
  });

  it("keeps acp and ui tests out of the generic unit lane", () => {
    const unitConfig = createUnitVitestConfig({});
    const testConfig = requireTestConfig(unitConfig);
    expect(testConfig.exclude).toContain("extensions/**");
    expect(testConfig.exclude).toContain("test/**");
    for (const pattern of [
      "ui/src/ui/app-chat.test.ts",
      "ui/src/ui/chat/**/*.test.ts",
      "ui/src/ui/views/chat.test.ts",
    ]) {
      expect(testConfig.include).not.toContain(pattern);
    }
  });

  it("narrows the active include list to CLI file filters when present", () => {
    const unitConfig = createUnitVitestConfigWithOptions(
      {},
      {
        argv: ["node", "vitest", "run", "src/media-generation/runtime-shared.test.ts"],
      },
    );
    const testConfig = requireTestConfig(unitConfig);
    expect(testConfig.include).toEqual(["src/media-generation/runtime-shared.test.ts"]);
    expect(testConfig.passWithNoTests).toBeUndefined();
  });

  it("lets root Vitest project runs skip unit files owned by excluded projects", () => {
    const unitConfig = createUnitVitestConfigWithOptions(
      {},
      {
        argv: ["node", "vitest", "run", "src/config/channel-configured.test.ts"],
      },
    );
    const testConfig = requireTestConfig(unitConfig);
    expect(testConfig.include).toEqual(["src/config/channel-configured.test.ts"]);
    expect(testConfig.passWithNoTests).toBe(true);
  });

  it("lets unrelated root Vitest projects skip when CLI filters match no unit files", () => {
    const unitConfig = createUnitVitestConfigWithOptions(
      {},
      {
        argv: ["node", "vitest", "run", "extensions/browser/index.test.ts"],
      },
    );
    const testConfig = requireTestConfig(unitConfig);
    expect(testConfig.include).toEqual([]);
    expect(testConfig.passWithNoTests).toBe(true);
  });

  it("adds the OpenClaw runtime setup hooks on top of the base setup", () => {
    const unitConfig = createUnitVitestConfig({});
    const testConfig = requireTestConfig(unitConfig);
    expect(normalizeConfigPaths(testConfig.setupFiles)).toEqual([
      "test/setup.ts",
      "test/setup-openclaw-runtime.ts",
    ]);
  });

  it("appends extra exclude patterns instead of replacing the base unit excludes", () => {
    const unitConfig = createUnitVitestConfigWithOptions(
      {},
      {
        extraExcludePatterns: ["src/security/**"],
      },
    );
    const testConfig = requireTestConfig(unitConfig);
    expect(testConfig.exclude).toContain("src/commands/**");
    expect(testConfig.exclude).toContain("src/config/**");
    expect(testConfig.exclude).toContain("src/security/**");
  });

  it("skips default coverage source discovery when coverage is disabled", () => {
    const unitConfig = createUnitVitestConfig({});
    const testConfig = requireTestConfig(unitConfig);

    expect(testConfig.coverage?.include).toBeUndefined();
  });

  it("scopes default coverage to source files owned by the unit lane", () => {
    const unitConfig = createUnitVitestConfigWithOptions(
      {},
      {
        argv: ["node", "vitest", "run", "--coverage"],
      },
    );
    const testConfig = requireTestConfig(unitConfig);
    const coverageInclude = testConfig.coverage?.include;
    expect(coverageInclude).toContain("packages/memory-host-sdk/src/host/batch-runner.ts");
    expect(coverageInclude).toContain("src/media-generation/runtime-shared.ts");
    expect(coverageInclude).toContain("src/web-search/runtime.ts");
    expect(coverageInclude).not.toContain("packages/markdown-core/src/render.ts");
    expect(coverageInclude).not.toContain("src/security/audit-workspace-skills.ts");
  });

  it("leaves coverage include filters unset for explicit unit include lists", () => {
    const unitConfig = createUnitVitestConfigWithOptions(
      {},
      {
        includePatterns: ["src/media-generation/runtime-shared.test.ts"],
      },
    );
    const testConfig = requireTestConfig(unitConfig);

    expect(testConfig.coverage?.include).toBeUndefined();
  });

  it("keeps bundled unit include files out of the resolved exclude list", () => {
    const unitConfig = createUnitVitestConfigWithOptions(
      {},
      {
        includePatterns: [
          "src/infra/matrix-plugin-helper.test.ts",
          "src/plugin-sdk/facade-runtime.test.ts",
          "src/plugins/loader.test.ts",
        ],
      },
    );
    const testConfig = requireTestConfig(unitConfig);

    expect(testConfig.include).toEqual([
      "src/infra/matrix-plugin-helper.test.ts",
      "src/plugin-sdk/facade-runtime.test.ts",
      "src/plugins/loader.test.ts",
    ]);
    expect(testConfig.exclude).not.toContain("src/infra/**");
    expect(testConfig.exclude).not.toContain("src/plugin-sdk/**");
    expect(testConfig.exclude).not.toContain("src/plugins/**");
    expect(testConfig.exclude).not.toContain("src/infra/matrix-plugin-helper.test.ts");
    expect(testConfig.exclude).not.toContain("src/plugin-sdk/facade-runtime.test.ts");
    expect(testConfig.exclude).not.toContain("src/plugins/loader.test.ts");
  });
});
