﻿// Copyright (c) .NET Foundation. All rights reserved.
// Licensed under the MIT License. See LICENSE in the project root for license information.
#nullable enable

using System;
using System.Collections.Generic;
using System.ComponentModel;
using Microsoft.Azure.WebJobs.Host.Scale;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;

namespace Microsoft.Azure.WebJobs.Extensions.DurableTask.Scale
{
    internal class DurableTaskTriggersScaleProvider : IScaleMonitorProvider, ITargetScalerProvider, IDisposable
    {
        private const string AzureManagedProviderName = "azureManaged";

        private readonly IScaleMonitor monitor;
        private readonly ITargetScaler targetScaler;
        private readonly DurableTaskOptions options;
        private readonly INameResolver nameResolver;
        private readonly ILoggerFactory loggerFactory;
        private readonly IEnumerable<IDurabilityProviderFactory> durabilityProviderFactories;
        private readonly DurabilityProvider durabilityProvider;

        public DurableTaskTriggersScaleProvider(
            IOptions<DurableTaskOptions> durableTaskOptions,
            INameResolver nameResolver,
            ILoggerFactory loggerFactory,
            IEnumerable<IDurabilityProviderFactory> durabilityProviderFactories,
            TriggerMetadata triggerMetadata)
        {
            this.options = durableTaskOptions.Value;
            this.nameResolver = nameResolver;
            this.loggerFactory = loggerFactory;
            this.durabilityProviderFactories = durabilityProviderFactories;

            string functionId = triggerMetadata.FunctionName;
            FunctionName functionName = new FunctionName(functionId);

            this.GetOptions(triggerMetadata);

            IDurabilityProviderFactory durabilityProviderFactory = this.GetDurabilityProviderFactory();

            if (string.Equals(durabilityProviderFactory.Name, AzureManagedProviderName, StringComparison.OrdinalIgnoreCase))
            {
                this.durabilityProvider = durabilityProviderFactory.GetDurabilityProvider(attribute: null, triggerMetadata);
            }
            else
            {
                this.durabilityProvider = durabilityProviderFactory.GetDurabilityProvider();
            }

            // Note: `this.options` is populated from the trigger metadata above
            string? connectionName = GetConnectionName(durabilityProviderFactory, this.options);

            var logger = loggerFactory.CreateLogger<DurableTaskTriggersScaleProvider>();
            logger.LogInformation(
                "Creating DurableTaskTriggersScaleProvider for function {FunctionName}: connectionName = '{ConnectionName}'",
                triggerMetadata.FunctionName,
                connectionName);

            this.targetScaler = ScaleUtils.GetTargetScaler(
                this.durabilityProvider,
                functionId,
                functionName,
                connectionName,
                this.options.HubName);

            this.monitor = ScaleUtils.GetScaleMonitor(
                this.durabilityProvider,
                functionId,
                functionName,
                connectionName,
                this.options.HubName);
        }

        private static string? GetConnectionName(IDurabilityProviderFactory durabilityProviderFactory, DurableTaskOptions options)
        {
            if (durabilityProviderFactory is AzureStorageDurabilityProviderFactory azureStorageDurabilityProviderFactory)
            {
                // First, look for the connection name in the options
                var azureStorageOptions = new AzureStorageOptions();
                if (options != null && options.StorageProvider != null)
                {
                    JsonConvert.PopulateObject(JsonConvert.SerializeObject(options.StorageProvider), azureStorageOptions);
                }

                // If the connection name is not found in the options, use the default connection name from the factory
                return azureStorageOptions.ConnectionName ?? azureStorageDurabilityProviderFactory.DefaultConnectionName;
            }
            else
            {
                return null;
            }
        }

        private void GetOptions(TriggerMetadata triggerMetadata)
        {
            // the metadata is the sync triggers payload
            var metadata = triggerMetadata.Metadata.ToObject<DurableTaskMetadata>();

            // The property `taskHubName` is always expected in the SyncTriggers payload
            this.options.HubName = metadata?.TaskHubName ?? throw new InvalidOperationException($"Expected `taskHubName` property in SyncTriggers payload but found none. Payload: {triggerMetadata.Metadata}");
            if (metadata?.MaxConcurrentActivityFunctions != null)
            {
                this.options.MaxConcurrentActivityFunctions = metadata?.MaxConcurrentActivityFunctions;
            }

            if (metadata?.MaxConcurrentOrchestratorFunctions != null)
            {
                this.options.MaxConcurrentOrchestratorFunctions = metadata?.MaxConcurrentOrchestratorFunctions;
            }

            if (metadata?.StorageProvider != null)
            {
                this.options.StorageProvider = metadata?.StorageProvider;
            }

            DurableTaskOptions.ResolveAppSettingOptions(this.options, this.nameResolver);
        }

        public void Dispose()
        {
            (this.durabilityProvider as IDisposable)?.Dispose();
        }

        private IDurabilityProviderFactory GetDurabilityProviderFactory()
        {
            var logger = this.loggerFactory.CreateLogger<DurableTaskTriggersScaleProvider>();
            var durabilityProviderFactory = DurableTaskExtension.GetDurabilityProviderFactory(this.options, logger, this.durabilityProviderFactories);
            return durabilityProviderFactory;
        }

        public IScaleMonitor GetMonitor()
        {
            return this.monitor;
        }

        public ITargetScaler GetTargetScaler()
        {
            return this.targetScaler;
        }

        /// <summary>
        /// Captures the relevant DF SyncTriggers JSON properties for making scaling decisions.
        /// </summary>
        internal class DurableTaskMetadata
        {
            [JsonProperty]
            public string? TaskHubName { get; set; }

            [JsonProperty(DefaultValueHandling = DefaultValueHandling.Populate)]
            [DefaultValue(null)]
            public int? MaxConcurrentOrchestratorFunctions { get; set; }

            [JsonProperty(DefaultValueHandling = DefaultValueHandling.Populate)]
            [DefaultValue(null)]
            public int? MaxConcurrentActivityFunctions { get; set; }

            [JsonProperty(DefaultValueHandling = DefaultValueHandling.Populate)]
            [DefaultValue(null)]
            public IDictionary<string, object>? StorageProvider { get; set; }
        }
    }
}