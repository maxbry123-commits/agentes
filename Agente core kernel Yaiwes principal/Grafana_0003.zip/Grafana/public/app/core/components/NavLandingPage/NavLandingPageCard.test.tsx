import { render, screen } from '@testing-library/react';

import { NavLandingPageCard } from './NavLandingPageCard';

describe('NavLandingPageCard', () => {
  const mockText = 'My heading';
  const mockUrl = 'http://www.example.com/';

  it('labels the link correctly', () => {
    render(<NavLandingPageCard text={mockText} url={mockUrl} />);
    const link = screen.getByRole('link', { name: mockText });
    expect(link).toBeInTheDocument();
    expect(link).toHaveProperty('href', mockUrl);
  });

  it('renders the description', () => {
    const mockDescription = 'My description';
    render(<NavLandingPageCard text={mockText} url={mockUrl} description={mockDescription} />);
    expect(screen.getByText(mockDescription)).toBeInTheDocument();
  });
});
