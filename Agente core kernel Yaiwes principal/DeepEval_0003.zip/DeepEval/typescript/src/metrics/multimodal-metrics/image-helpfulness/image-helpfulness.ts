import { BaseMetric, resolveThreshold } from "@/metrics/base-metrics";
import {
  LLMTestCase,
  SingleTurnParams,
  MLLMImage,
  convertToMultiModalArray,
} from "@/test-case";
import { DeepEvalBaseLLM } from "@/models";
import {
  initializeModel,
  generateWithSchema,
  checkSingleTurnParams,
  constructVerboseLogs,
} from "@/metrics/utils";
import {
  getImageIndices,
  getImageContext,
} from "@/metrics/multimodal-metrics/utils";
import { ReasonScoreSchema } from "@/metrics/multimodal-metrics/schema";
import { type MetricTemplateOverride } from "@/templates/override";

const TEMPLATE_CLASS = "ImageHelpfulnessMetric";

export type ImageHelpfulnessTemplateOverride =
  MetricTemplateOverride<"ImageHelpfulnessMetric">;

export interface ImageHelpfulnessMetricOptions {
  threshold?: number | null;
  flaky?: boolean;
  model?: DeepEvalBaseLLM | string;
  strictMode?: boolean;
  verboseMode?: boolean;
  showIndicator?: boolean;
  /** Clip the text context around each image to this many chars. */
  maxContextSize?: number;
  evaluationTemplate?: ImageHelpfulnessTemplateOverride;
}

/**
 * Image Helpfulness — does each image in `actualOutput` help convey the
 * surrounding text? Scores each image (0–10) against its text context via a
 * vision model, then averages. **Higher is better**.
 */
export class ImageHelpfulnessMetric extends BaseMetric {
  private readonly maxContextSize?: number;

  constructor(options: ImageHelpfulnessMetricOptions = {}) {
    const strictMode = options.strictMode ?? false;
    super(strictMode ? 1 : resolveThreshold(options.threshold, 0.5), {
      strictMode,
      verboseMode: options.verboseMode,
      showIndicator: options.showIndicator,
      flaky: options.flaky,
      evaluationTemplate: options.evaluationTemplate,
    });
    this.templateClass = TEMPLATE_CLASS;
    this.requiredParams = [
      SingleTurnParams.INPUT,
      SingleTurnParams.ACTUAL_OUTPUT,
    ];
    this.maxContextSize = options.maxContextSize;
    const { model, usingNativeModel } = initializeModel(options.model);
    this.model = model;
    this.usingNativeModel = usingNativeModel;
    this.evaluationModel = this.model.getModelName();
  }

  async measure(testCase: LLMTestCase): Promise<number> {
    this.error = undefined;
    await this.startProgress();
    try {
      checkSingleTurnParams(testCase, this.requiredParams, this);
      this.evaluationCost = this.usingNativeModel ? 0 : undefined;

      const actualOutput = convertToMultiModalArray(testCase.actualOutput);
      const imageIndices = getImageIndices(actualOutput);
      if (imageIndices.length === 0) {
        throw new Error(
          `The test case must have at least one image in the \`actualOutput\` to calculate ${this.name} score`,
        );
      }

      const scores: number[] = [];
      const reasons: string[] = [];
      for (const idx of imageIndices) {
        const [above, below] = getImageContext(
          idx,
          actualOutput,
          this.maxContextSize,
        );
        const image = actualOutput[idx] as MLLMImage;
        const instructions = this.getPrompt("evaluate_image_helpfulness", {
          context_above: above ?? "",
          context_below: below ?? "",
        });
        const { reasoning, score } = await generateWithSchema(
          this,
          `${instructions} \nImages: ${image}`,
          ReasonScoreSchema,
        );
        scores.push(score / 10);
        reasons.push(reasoning);
      }

      const avg = scores.reduce((s, x) => s + x, 0) / scores.length;
      this.score = this.applyStrictMode(avg);
      this.reason = reasons
        .map((r, i) => `Reason for image ${i}: ${r}`)
        .join("\n");
      this.success = this.isSuccessful();

      this.verboseLogs = constructVerboseLogs(this, [
        `Images scored: ${scores.length}`,
        `Per-image scores: ${scores.map((s) => s.toFixed(2)).join(", ")}`,
        `Score (Average): ${this.score}\nReason: ${this.reason}`,
      ]);
      return this.score;
    } finally {
      this.stopProgress();
    }
  }

  get name(): string {
    return "Image Helpfulness";
  }
}
