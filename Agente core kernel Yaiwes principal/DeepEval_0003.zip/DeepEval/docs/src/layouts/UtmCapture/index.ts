export { default } from "./UtmCapture";
