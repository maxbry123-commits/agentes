import styles from "./AgentTraceTerminal.module.scss";

export type LineKind =
  "cmd" | "root" | "agent" | "tool" | "llm" | "retriever" | "blank" | "summary";

export type TraceLine = {
  kind: LineKind;
  prefix?: string;
  name?: string;
  metric?: string;
  score?: string;
  duration?: string;
  pass?: boolean;
  scope?: "start" | "middle" | "end";
};

export const DEFAULT_TRACE: TraceLine[] = [
  { kind: "cmd", name: "deepeval test run agents/checkout.py" },
  { kind: "blank" },
  { kind: "root", prefix: "●", name: "test_checkout_agent" },
  { kind: "blank", prefix: "│" },
  {
    kind: "agent",
    prefix: "├─",
    name: "plan_refund_strategy",
    metric: "G-Eval",
    score: "0.94",
    duration: "220ms",
    pass: true,
  },
  {
    kind: "retriever",
    prefix: "│  ├─",
    name: "retrieve_policy_docs(query=…)",
    metric: "Context Recall",
    score: "0.89",
    duration: "68ms",
    pass: true,
  },
  {
    kind: "tool",
    prefix: "│  ├─",
    name: 'lookup_order(id="#9281")',
    metric: "Faithfulness",
    score: "1.00",
    duration: "45ms",
    pass: true,
  },
  {
    kind: "llm",
    prefix: "│  └─",
    name: "gpt-4o · classify_intent",
    metric: "Answer Relevancy",
    score: "0.92",
    duration: "130ms",
    pass: true,
  },
  { kind: "blank", prefix: "│" },
  {
    kind: "tool",
    prefix: "├─",
    name: "process_refund(amount=29.99)",
    metric: "deterministic",
    duration: "85ms",
  },
  { kind: "blank", prefix: "│" },
  {
    kind: "llm",
    prefix: "└─",
    name: "gpt-4o · draft_response",
    metric: "Helpfulness",
    score: "0.88",
    duration: "195ms",
    pass: true,
  },
  { kind: "blank" },
  {
    kind: "summary",
    name: "Trace score  0.92   ·   5/5 metrics passed",
    pass: true,
  },
];

/** Same spans, same metrics, same scores — TypeScript spellings. */
export const TYPESCRIPT_TRACE: TraceLine[] = [
  { kind: "cmd", name: "npx deepeval test run agents/checkout.test.ts" },
  { kind: "blank" },
  { kind: "root", prefix: "●", name: "checkout agent" },
  { kind: "blank", prefix: "│" },
  {
    kind: "agent",
    prefix: "├─",
    name: "planRefundStrategy",
    metric: "G-Eval",
    score: "0.94",
    duration: "220ms",
    pass: true,
  },
  {
    kind: "retriever",
    prefix: "│  ├─",
    name: "retrievePolicyDocs(query=…)",
    metric: "Context Recall",
    score: "0.89",
    duration: "68ms",
    pass: true,
  },
  {
    kind: "tool",
    prefix: "│  ├─",
    name: 'lookupOrder(id="#9281")',
    metric: "Faithfulness",
    score: "1.00",
    duration: "45ms",
    pass: true,
  },
  {
    kind: "llm",
    prefix: "│  └─",
    name: "gpt-4o · classifyIntent",
    metric: "Answer Relevancy",
    score: "0.92",
    duration: "130ms",
    pass: true,
  },
  { kind: "blank", prefix: "│" },
  {
    kind: "tool",
    prefix: "├─",
    name: "processRefund(amount=29.99)",
    metric: "deterministic",
    duration: "85ms",
  },
  { kind: "blank", prefix: "│" },
  {
    kind: "llm",
    prefix: "└─",
    name: "gpt-4o · draftResponse",
    metric: "Helpfulness",
    score: "0.88",
    duration: "195ms",
    pass: true,
  },
  { kind: "blank" },
  {
    kind: "summary",
    name: "Trace score  0.92   ·   5/5 metrics passed",
    pass: true,
  },
];

const TRACES = {
  python: DEFAULT_TRACE,
  typescript: TYPESCRIPT_TRACE,
} as const;

const DEFAULT_TITLE = "agent_trace · deepeval";
const DEFAULT_ARIA_LABEL = "Example agent trace with per-step metric scores";

interface AgentTraceTerminalProps {
  title?: string;
  /** Picks the matching trace; ignored when `lines` is given. */
  language?: keyof typeof TRACES;
  lines?: TraceLine[];
  ariaLabel?: string;
}

function kindLabel(kind: LineKind): string | null {
  switch (kind) {
    case "agent":
      return "AGENT";
    case "tool":
      return "TOOL";
    case "llm":
      return "LLM";
    case "retriever":
      return "RETRIEVER";
    default:
      return null;
  }
}

const AgentTraceTerminal: React.FC<AgentTraceTerminalProps> = ({
  title = DEFAULT_TITLE,
  language = "python",
  lines = TRACES[language],
  ariaLabel = DEFAULT_ARIA_LABEL,
}) => {
  return (
    <div className={styles.terminal} role="img" aria-label={ariaLabel}>
      <div className={styles.bar}>
        <div className={styles.dots}>
          <span />
          <span />
          <span />
        </div>
        <span className={styles.title}>{title}</span>
        <span className={styles.barSpacer} aria-hidden />
      </div>
      <div className={styles.body}>
        {lines.map((line, i) => (
          <div
            key={i}
            className={`${styles.line} ${styles[`line_${line.kind}`]} ${
              line.scope ? styles.lineScope : ""
            } ${line.scope ? styles[`scope_${line.scope}`] : ""}`}
            style={{ animationDelay: `${i * 0.11}s` } as React.CSSProperties}
          >
            {line.kind === "cmd" ? (
              <>
                <span className={styles.prompt}>$</span>
                <span className={styles.cmdText}>{line.name}</span>
              </>
            ) : line.kind === "summary" ? (
              <>
                <span
                  className={`${styles.summaryDot} ${
                    line.pass === false ? styles.summaryDotFail : ""
                  }`}
                  aria-hidden
                />
                <span className={styles.summaryText}>{line.name}</span>
                {line.pass !== undefined && (
                  <span
                    className={`${styles.summaryBadge} ${
                      line.pass ? "" : styles.summaryBadgeFail
                    }`}
                  >
                    {line.pass ? "passed" : "failed"}
                  </span>
                )}
              </>
            ) : line.kind === "blank" ? (
              <span className={styles.prefix}>{line.prefix ?? " "}</span>
            ) : line.kind === "root" ? (
              <>
                <span className={styles.rootDot}>{line.prefix}</span>
                <span className={styles.rootName}>{line.name}</span>
                {(line.metric || line.score) && (
                  <span className={styles.meta}>
                    <span className={styles.metric}>{line.metric}</span>
                    {line.score !== undefined && (
                      <span
                        className={`${styles.score} ${
                          line.pass ? styles.scorePass : styles.scoreFail
                        }`}
                      >
                        {line.score}
                      </span>
                    )}
                    {line.score !== undefined && line.pass !== undefined && (
                      <span
                        className={`${styles.status} ${
                          line.pass ? styles.statusPass : styles.statusFail
                        }`}
                        aria-hidden
                      >
                        {line.pass ? "✓" : "✗"}
                      </span>
                    )}
                  </span>
                )}
              </>
            ) : (
              <>
                <span className={styles.prefix}>{line.prefix}</span>
                <span
                  className={`${styles.badge} ${styles[`badge_${line.kind}`]}`}
                >
                  {kindLabel(line.kind)}
                </span>
                <span className={styles.name}>{line.name}</span>
                <span className={styles.meta}>
                  <span className={styles.metric}>{line.metric}</span>
                  {line.score !== undefined && (
                    <span
                      className={`${styles.score} ${
                        line.pass ? styles.scorePass : styles.scoreFail
                      }`}
                    >
                      {line.score}
                    </span>
                  )}
                  {line.score !== undefined && line.pass !== undefined && (
                    <span
                      className={`${styles.status} ${
                        line.pass ? styles.statusPass : styles.statusFail
                      }`}
                      aria-hidden
                    >
                      {line.pass ? "✓" : "✗"}
                    </span>
                  )}
                  <span className={styles.duration}>{line.duration}</span>
                </span>
              </>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default AgentTraceTerminal;
