# MiniMax messages tests
