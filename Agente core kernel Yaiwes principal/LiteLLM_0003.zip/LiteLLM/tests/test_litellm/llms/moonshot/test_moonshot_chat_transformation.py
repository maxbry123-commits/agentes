"""
Unit tests for Moonshot AI configuration.

These tests validate the MoonshotChatConfig class which extends OpenAIGPTConfig.
Moonshot AI is an OpenAI-compatible provider with minor customizations.
"""

from unittest.mock import patch


import pytest

import litellm
import litellm.utils
from litellm.litellm_core_utils.get_model_cost_map import GetModelCostMap
from litellm.llms.moonshot.chat.transformation import MoonshotChatConfig


class TestMoonshotConfig:
    """Test class for Moonshot AI functionality"""

    def test_default_api_base(self):
        """Test that default API base is used when none is provided"""
        config = MoonshotChatConfig()
        headers = {}
        api_key = "fake-moonshot-key"

        # Call validate_environment without specifying api_base
        result = config.validate_environment(
            headers=headers,
            model="moonshot-v1-8k",
            messages=[{"role": "user", "content": "Hey"}],
            optional_params={},
            litellm_params={},
            api_key=api_key,
            api_base=None,  # Not providing api_base
        )

        # Verify headers are still set correctly
        assert result["Authorization"] == f"Bearer {api_key}"
        assert result["Content-Type"] == "application/json"

        # We can't directly test the api_base value here since validate_environment
        # only returns the headers, but we can verify it doesn't raise an exception
        # which would happen if api_base handling was incorrect

    def test_get_supported_openai_params(self):
        """Test that get_supported_openai_params returns correct params"""
        config = MoonshotChatConfig()

        supported_params = config.get_supported_openai_params("moonshot-v1-8k")

        # Should include these params
        assert "tools" in supported_params
        assert "tool_choice" in supported_params
        assert "temperature" in supported_params
        assert "max_tokens" in supported_params
        assert "stream" in supported_params

        # Should NOT include functions (not supported by Moonshot AI)
        assert "functions" not in supported_params

    def test_map_openai_params_excludes_functions(self):
        """Test that functions parameter is not mapped"""
        config = MoonshotChatConfig()

        non_default_params = {
            "functions": [{"name": "test_function", "description": "Test function"}],
            "temperature": 0.7,
            "max_tokens": 1000,
        }

        result = config.map_openai_params(
            non_default_params=non_default_params,
            optional_params={},
            model="moonshot-v1-8k",
            drop_params=False,
        )

        # Functions should not be in result (not in supported params)
        assert "functions" not in result
        # Other supported params should be included
        assert result.get("temperature") == 0.7
        assert result.get("max_tokens") == 1000

    def test_map_openai_params_allows_other_tool_choice_values(self):
        """Test that other tool_choice values are allowed"""
        config = MoonshotChatConfig()

        for tool_choice_value in [
            "auto",
            "none",
            {"type": "function", "function": {"name": "test"}},
        ]:
            non_default_params = {
                "tool_choice": tool_choice_value,
                "tools": [{"type": "function", "function": {"name": "test"}}],
            }

            result = config.map_openai_params(
                non_default_params=non_default_params,
                optional_params={},
                model="moonshot-v1-8k",
                drop_params=False,
            )

            # tool_choice should be included for non-"required" values
            assert result.get("tool_choice") == tool_choice_value

    def test_map_openai_params_max_completion_tokens_mapping(self):
        """Test that max_completion_tokens is mapped to max_tokens"""
        config = MoonshotChatConfig()

        non_default_params = {"max_completion_tokens": 1000, "temperature": 0.7}

        result = config.map_openai_params(
            non_default_params=non_default_params,
            optional_params={},
            model="moonshot-v1-8k",
            drop_params=False,
        )

        # max_completion_tokens should be mapped to max_tokens
        assert result.get("max_tokens") == 1000
        assert "max_completion_tokens" not in result
        assert result.get("temperature") == 0.7

    def test_temperature_handling_clamps_to_max_1(self):
        """Test that temperature > 1 is clamped to 1 (Moonshot limitation)"""
        config = MoonshotChatConfig()

        non_default_params = {
            "temperature": 1.5  # OpenAI allows up to 2, but Moonshot only allows up to 1
        }

        result = config.map_openai_params(
            non_default_params=non_default_params,
            optional_params={},
            model="moonshot-v1-8k",
            drop_params=False,
        )

        # Temperature should be clamped to 1
        assert result.get("temperature") == 1

    def test_temperature_handling_low_temp_with_multiple_n(self):
        """Test that temperature < 0.3 with n > 1 is adjusted to 0.3"""
        config = MoonshotChatConfig()

        non_default_params = {
            "temperature": 0.1,  # Less than 0.3
            "n": 3,  # Multiple completions
        }

        result = config.map_openai_params(
            non_default_params=non_default_params,
            optional_params={},
            model="moonshot-v1-8k",
            drop_params=False,
        )

        # Temperature should be adjusted to 0.3 to avoid Moonshot API exceptions
        assert result.get("temperature") == 0.3
        assert result.get("n") == 3

    def test_temperature_handling_low_temp_single_n(self):
        """Test that temperature < 0.3 with n = 1 is preserved"""
        config = MoonshotChatConfig()

        non_default_params = {
            "temperature": 0.1,  # Less than 0.3
            "n": 1,  # Single completion
        }

        result = config.map_openai_params(
            non_default_params=non_default_params,
            optional_params={},
            model="moonshot-v1-8k",
            drop_params=False,
        )

        # Temperature should be preserved when n = 1
        assert result.get("temperature") == 0.1
        assert result.get("n") == 1

    def test_temperature_handling_valid_range(self):
        """Test that temperatures in valid range [0.3, 1] are preserved"""
        config = MoonshotChatConfig()

        test_temps = [0.3, 0.5, 0.7, 1.0]

        for temp in test_temps:
            non_default_params = {"temperature": temp, "n": 2}

            result = config.map_openai_params(
                non_default_params=non_default_params,
                optional_params={},
                model="moonshot-v1-8k",
                drop_params=False,
            )

            # Temperature should be preserved
            assert result.get("temperature") == temp

    def test_temperature_dropped_for_reasoning_models(self):
        """Reasoning models (kimi-k2.5, kimi-k2.6) reject any temperature except 1,
        so the param is dropped rather than clamped. A clamp to 0.3/1 would still
        400 when the caller passes e.g. 0.5."""
        config = MoonshotChatConfig()

        with patch(
            "litellm.llms.moonshot.chat.transformation.supports_reasoning",
            return_value=True,
        ):
            for temp in [0.0, 0.5, 1.0, 1.5]:
                result = config.map_openai_params(
                    non_default_params={"temperature": temp},
                    optional_params={},
                    model="kimi-k2.5",
                    drop_params=False,
                )
                assert "temperature" not in result

    def test_temperature_clamped_for_non_reasoning_models(self):
        """Non-reasoning models keep the [0.3, 1] clamp behaviour."""
        config = MoonshotChatConfig()

        with patch(
            "litellm.llms.moonshot.chat.transformation.supports_reasoning",
            return_value=False,
        ):
            result = config.map_openai_params(
                non_default_params={"temperature": 1.5},
                optional_params={},
                model="moonshot-v1-8k",
                drop_params=False,
            )

        assert result.get("temperature") == 1

    def test_tool_choice_required_adds_message(self):
        """Test that tool_choice='required' adds a special message and removes tool_choice"""
        config = MoonshotChatConfig()

        messages = [{"role": "user", "content": "What's the weather like?"}]

        optional_params = {
            "tool_choice": "required",
            "tools": [{"type": "function", "function": {"name": "get_weather"}}],
        }

        result = config.transform_request(
            model="moonshot-v1-8k",
            messages=messages,
            optional_params=optional_params,
            litellm_params={},
            headers={},
        )

        # Check that the special message was added
        assert len(result["messages"]) == 2
        assert result["messages"][0]["role"] == "user"
        assert result["messages"][0]["content"] == "What's the weather like?"
        assert result["messages"][1]["role"] == "user"
        assert result["messages"][1]["content"] == "Please select a tool to handle the current issue."

        # Check that tool_choice was removed but tools are preserved
        assert "tool_choice" not in result
        assert "tools" in result
        assert len(result["tools"]) == 1

    def test_tool_choice_required_preserves_other_params(self):
        """Test that tool_choice='required' handling preserves other parameters"""
        config = MoonshotChatConfig()

        messages = [{"role": "user", "content": "Calculate 2+2"}]

        optional_params = {
            "tool_choice": "required",
            "tools": [{"type": "function", "function": {"name": "calculator"}}],
            "temperature": 0.7,
            "max_tokens": 1000,
        }

        result = config.transform_request(
            model="moonshot-v1-8k",
            messages=messages,
            optional_params=optional_params,
            litellm_params={},
            headers={},
        )

        # Check that other parameters are preserved
        assert result.get("temperature") == 0.7
        assert result.get("max_tokens") == 1000
        assert "tools" in result

        # Check that tool_choice was removed
        assert "tool_choice" not in result

        # Check that the message was added
        assert len(result["messages"]) == 2
        assert result["messages"][1]["content"] == "Please select a tool to handle the current issue."

    def test_tool_choice_required_does_not_mutate_input_messages(self):
        """tool_choice='required' must not mutate the caller's messages list.

        The handling appends a "select a tool" user message; building it in
        place corrupts the caller's conversation history and makes
        transform_request non-idempotent across retries.
        """
        config = MoonshotChatConfig()

        messages = [{"role": "user", "content": "What's the weather like?"}]

        for _ in range(2):
            optional_params = {
                "tool_choice": "required",
                "tools": [{"type": "function", "function": {"name": "get_weather"}}],
            }
            result = config.transform_request(
                model="moonshot-v1-8k",
                messages=messages,
                optional_params=optional_params,
                litellm_params={},
                headers={},
            )
            # The returned request carries the extra message.
            assert len(result["messages"]) == 2
            # The caller's list is untouched, so repeated calls stay idempotent.
            assert messages == [{"role": "user", "content": "What's the weather like?"}]

    def test_tool_choice_non_required_preserved(self):
        """Test that non-'required' tool_choice values are preserved"""
        config = MoonshotChatConfig()

        messages = [{"role": "user", "content": "What's the weather?"}]

        test_values = [
            "auto",
            "none",
            {"type": "function", "function": {"name": "get_weather"}},
        ]

        for tool_choice_value in test_values:
            optional_params = {
                "tool_choice": tool_choice_value,
                "tools": [{"type": "function", "function": {"name": "get_weather"}}],
            }

            result = config.transform_request(
                model="moonshot-v1-8k",
                messages=messages,
                optional_params=optional_params,
                litellm_params={},
                headers={},
            )

            # Check that tool_choice is preserved for non-"required" values
            assert result.get("tool_choice") == tool_choice_value

            # Check that no extra message was added
            assert len(result["messages"]) == 1
            assert result["messages"][0]["content"] == "What's the weather?"

    def test_transform_messages_preserves_image_url_content(self):
        """Test that messages with image_url blocks are NOT flattened to strings.

        Multimodal models like kimi-k2.5 accept the standard OpenAI content
        array with non-text blocks. When any message contains a non-text part,
        the content array must be preserved so the payload reaches the API.
        """
        config = MoonshotChatConfig()

        messages = [
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": "What is in this image?"},
                    {
                        "type": "image_url",
                        "image_url": {"url": "https://example.com/image.png"},
                    },
                ],
            }
        ]

        result = config.transform_request(
            model="kimi-k2.5",
            messages=messages,
            optional_params={},
            litellm_params={},
            headers={},
        )

        # Content must remain a list (not flattened to a string)
        assert isinstance(result["messages"][0]["content"], list)
        assert len(result["messages"][0]["content"]) == 2
        assert result["messages"][0]["content"][0]["type"] == "text"
        assert result["messages"][0]["content"][1]["type"] == "image_url"

    def test_transform_messages_preserves_non_text_content(self):
        """Test that any non-text content type (input_audio, video_url, file,
        etc.) also prevents flattening, matching the OpenAI content spec."""
        config = MoonshotChatConfig()

        messages = [
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": "Transcribe this audio"},
                    {
                        "type": "input_audio",
                        "input_audio": {"data": "base64data", "format": "wav"},
                    },
                ],
            }
        ]

        result = config.transform_request(
            model="kimi-k2.5",
            messages=messages,
            optional_params={},
            litellm_params={},
            headers={},
        )

        assert isinstance(result["messages"][0]["content"], list)
        assert len(result["messages"][0]["content"]) == 2
        assert result["messages"][0]["content"][1]["type"] == "input_audio"

    def test_transform_messages_flattens_text_only_content(self):
        """Test that text-only content arrays ARE flattened to strings.

        For text-only requests, Moonshot expects plain string content.
        The content list should be converted to a single string.
        """
        config = MoonshotChatConfig()

        messages = [
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": "Hello, how are you?"},
                ],
            }
        ]

        result = config.transform_request(
            model="moonshot-v1-8k",
            messages=messages,
            optional_params={},
            litellm_params={},
            headers={},
        )

        # Content should be flattened to a plain string
        assert isinstance(result["messages"][0]["content"], str)
        assert result["messages"][0]["content"] == "Hello, how are you?"

    # ------------------------------------------------------------------ #
    # Tests for fill_reasoning_content                                     #
    # ------------------------------------------------------------------ #

    def test_reasoning_content_space_injected_when_absent(self):
        """Assistant tool-call message with no reasoning_content gets a space injected."""
        config = MoonshotChatConfig()

        messages = [
            {"role": "user", "content": "What's the weather?"},
            {
                "role": "assistant",
                "content": None,
                "tool_calls": [
                    {
                        "id": "call_1",
                        "type": "function",
                        "function": {"name": "get_weather", "arguments": "{}"},
                    }
                ],
            },
            {"role": "tool", "tool_call_id": "call_1", "content": "Sunny, 22°C"},
        ]

        result = config.fill_reasoning_content(messages)

        assert result[1].get("reasoning_content") == " "
        # Non-assistant messages are untouched
        assert "reasoning_content" not in result[0]
        assert "reasoning_content" not in result[2]

    def test_empty_tool_calls_list_not_injected(self):
        """Assistant message with tool_calls: [] should not get reasoning_content injected."""
        config = MoonshotChatConfig()

        original_msg = {
            "role": "assistant",
            "content": "Here is the answer.",
            "tool_calls": [],
        }
        messages = [original_msg]

        result = config.fill_reasoning_content(messages)

        assert "reasoning_content" not in result[0]
        assert result[0] is original_msg

    def test_existing_reasoning_content_not_overwritten(self):
        """Message that already has reasoning_content is passed through unchanged."""
        config = MoonshotChatConfig()

        original_msg = {
            "role": "assistant",
            "content": None,
            "tool_calls": [
                {
                    "id": "call_1",
                    "type": "function",
                    "function": {"name": "fn", "arguments": "{}"},
                }
            ],
            "reasoning_content": "<actual thinking>",
        }
        messages = [original_msg]

        result = config.fill_reasoning_content(messages)

        assert result[0].get("reasoning_content") == "<actual thinking>"
        # Same object — no copy was made
        assert result[0] is original_msg

    def test_provider_specific_fields_reasoning_content_promoted(self):
        """reasoning_content stored in provider_specific_fields is promoted to top level."""
        config = MoonshotChatConfig()

        messages = [
            {
                "role": "assistant",
                "content": None,
                "tool_calls": [
                    {
                        "id": "call_1",
                        "type": "function",
                        "function": {"name": "fn", "arguments": "{}"},
                    }
                ],
                "provider_specific_fields": {"reasoning_content": "stored thinking"},
            }
        ]

        result = config.fill_reasoning_content(messages)

        assert result[0].get("reasoning_content") == "stored thinking"
        # The promoted key must be removed from provider_specific_fields to
        # avoid sending the value twice in the serialised request body
        assert "reasoning_content" not in (result[0].get("provider_specific_fields") or {})

    def test_reasoning_model_fill_called_from_transform_request(self):
        """transform_request injects reasoning_content end-to-end for reasoning models."""
        config = MoonshotChatConfig()

        messages = [
            {"role": "user", "content": "Call a tool"},
            {
                "role": "assistant",
                "content": None,
                "tool_calls": [
                    {
                        "id": "call_1",
                        "type": "function",
                        "function": {"name": "fn", "arguments": "{}"},
                    }
                ],
            },
        ]

        with patch(
            "litellm.llms.moonshot.chat.transformation.supports_reasoning",
            return_value=True,
        ):
            result = config.transform_request(
                model="kimi-k2-thinking",
                messages=messages,
                optional_params={},
                litellm_params={},
                headers={},
            )

        assert result["messages"][1].get("reasoning_content") == " "

    def test_non_reasoning_model_messages_untouched(self):
        """For non-reasoning models, transform_request leaves messages unchanged."""
        config = MoonshotChatConfig()

        messages = [
            {"role": "user", "content": "Hello"},
            {
                "role": "assistant",
                "content": None,
                "tool_calls": [
                    {
                        "id": "call_1",
                        "type": "function",
                        "function": {"name": "fn", "arguments": "{}"},
                    }
                ],
            },
        ]

        with patch(
            "litellm.llms.moonshot.chat.transformation.supports_reasoning",
            return_value=False,
        ):
            result = config.transform_request(
                model="moonshot-v1-8k",
                messages=messages,
                optional_params={},
                litellm_params={},
                headers={},
            )

        # reasoning_content must not have been injected
        for msg in result["messages"]:
            assert "reasoning_content" not in msg

    def test_reasoning_content_preserved_on_pydantic_message_object(self):
        """reasoning_content on Pydantic Message objects is preserved (not overwritten with placeholder).

        Regression test for: https://github.com/BerriAI/litellm/issues/23765
        The issue was that 'reasoning_content' in msg doesn't work for Pydantic models
        because they don't support the 'in' operator the same way as dicts.
        """
        from litellm.types.utils import Message

        config = MoonshotChatConfig()

        # Create a Pydantic Message object with reasoning_content (as would come from API response)
        message_with_reasoning = Message(
            role="assistant",
            content=None,
            reasoning_content="<thinking>User wants weather</thinking>",
            tool_calls=[
                {
                    "id": "call_1",
                    "type": "function",
                    "function": {"name": "fn", "arguments": "{}"},
                }
            ],
        )

        messages = [message_with_reasoning]

        result = config.fill_reasoning_content(messages)

        # reasoning_content should be preserved, not replaced with placeholder
        assert result[0].get("reasoning_content") == "<thinking>User wants weather</thinking>"

    def test_reasoning_content_preserved_in_multi_turn_flow(self):
        """reasoning_content is preserved through multi-turn conversation flow.

        This tests the complete flow: API response -> Message object -> dict -> fill_reasoning_content
        """
        from litellm.types.utils import Message
        from litellm.utils import convert_to_dict

        config = MoonshotChatConfig()

        # Simulate API response with reasoning_content
        api_response = {
            "role": "assistant",
            "content": None,
            "reasoning_content": "<thinking>Planning to call weather tool</thinking>",
            "tool_calls": [
                {
                    "id": "call_1",
                    "type": "function",
                    "function": {"name": "get_weather", "arguments": "{}"},
                }
            ],
        }

        # Convert to Message object (as LiteLLM does)
        message_obj = Message(**api_response)

        # Convert back to dict (when building next request)
        message_dict = convert_to_dict(message_obj)

        # Build multi-turn conversation
        messages = [
            {"role": "user", "content": "What's the weather?"},
            message_dict,
            {"role": "tool", "tool_call_id": "call_1", "content": '{"temp": 72}'},
            {"role": "user", "content": "Thanks!"},
        ]

        # Apply fill_reasoning_content
        result = config.fill_reasoning_content(messages)

        # reasoning_content should be preserved in the assistant message
        assert result[1].get("reasoning_content") == "<thinking>Planning to call weather tool</thinking>"


class TestKimiK26ModelRegistry:
    """Tests that kimi-k2.6 is correctly registered in the model registry."""

    @pytest.fixture(autouse=True)
    def model_cost_map(self):
        """Load directly from the bundled backup so tests don't depend on remote fetch."""
        return GetModelCostMap.load_local_model_cost_map()

    def test_kimi_k26_in_model_cost_map(self, model_cost_map):
        """kimi-k2.6 should be present in the model cost map."""
        assert "moonshot/kimi-k2.6" in model_cost_map, "moonshot/kimi-k2.6 not found in model_cost"

    def test_kimi_k26_pricing(self, model_cost_map):
        """kimi-k2.6 pricing should match official Kimi API rates."""
        model_info = model_cost_map["moonshot/kimi-k2.6"]
        assert model_info["input_cost_per_token"] == pytest.approx(9.5e-07)
        assert model_info["output_cost_per_token"] == pytest.approx(4e-06)
        assert model_info["cache_read_input_token_cost"] == pytest.approx(1.6e-07)

    def test_kimi_k26_context_window(self, model_cost_map):
        """kimi-k2.6 should have a 256K (262144 token) context window."""
        model_info = model_cost_map["moonshot/kimi-k2.6"]
        assert model_info["max_input_tokens"] == 262144
        assert model_info["max_output_tokens"] == 262144
        assert model_info["max_tokens"] == 262144

    def test_kimi_k26_capabilities(self, model_cost_map):
        """kimi-k2.6 should support function calling, vision, video input, tool choice, and reasoning."""
        model_info = model_cost_map["moonshot/kimi-k2.6"]
        assert model_info.get("supports_function_calling") is True
        assert model_info.get("supports_tool_choice") is True
        assert model_info.get("supports_vision") is True
        assert model_info.get("supports_video_input") is True
        assert model_info.get("supports_reasoning") is True

    def test_kimi_k26_provider(self, model_cost_map):
        """kimi-k2.6 should be assigned to the moonshot provider."""
        model_info = model_cost_map["moonshot/kimi-k2.6"]
        assert model_info["litellm_provider"] == "moonshot"


class TestMoonshotResponseSchemaSupport:
    """Every model currently live on api.moonshot.ai supports json_schema
    response_format, which gates discovery via litellm.responses(). The flag
    must be true so the capability is advertised honestly."""

    LIVE_MODELS = [
        "moonshot/kimi-k2.5",
        "moonshot/kimi-k2.6",
        "moonshot/moonshot-v1-8k",
        "moonshot/moonshot-v1-32k",
        "moonshot/moonshot-v1-128k",
        "moonshot/moonshot-v1-8k-vision-preview",
        "moonshot/moonshot-v1-32k-vision-preview",
        "moonshot/moonshot-v1-128k-vision-preview",
        "moonshot/moonshot-v1-auto",
    ]

    @pytest.fixture(autouse=True)
    def model_cost_map(self):
        return GetModelCostMap.load_local_model_cost_map()

    @pytest.mark.parametrize("model", LIVE_MODELS)
    def test_live_model_supports_response_schema(self, model, model_cost_map):
        assert model_cost_map[model].get("supports_response_schema") is True

    def test_supports_response_schema_utility_reports_true(self, model_cost_map, monkeypatch):
        monkeypatch.setattr(litellm, "model_cost", model_cost_map)
        assert litellm.utils.supports_response_schema(model="moonshot/kimi-k2.5") is True


class TestMoonshotReasoningEffort:
    """Moonshot documents reasoning_effort as a top-level chat completions field for its reasoning
    models, defaulting to max, but the OpenAI base list this config subtracts from never carried it,
    so an explicit level raised UnsupportedParamsError before it reached the wire."""

    @pytest.fixture(autouse=True)
    def force_local_model_cost(self, monkeypatch):
        monkeypatch.setattr(litellm, "model_cost", GetModelCostMap.load_local_model_cost_map())

    @pytest.mark.parametrize("model", ["kimi-k3", "kimi-k2.5", "kimi-k2.6", "kimi-k2-thinking"])
    def test_reasoning_model_supports_reasoning_effort(self, model):
        assert "reasoning_effort" in MoonshotChatConfig().get_supported_openai_params(model)

    @pytest.mark.parametrize("model", ["moonshot-v1-8k", "kimi-latest", "kimi-k2-turbo-preview"])
    def test_non_reasoning_model_does_not_support_reasoning_effort(self, model):
        assert "reasoning_effort" not in MoonshotChatConfig().get_supported_openai_params(model)

    @pytest.mark.parametrize("effort", ["low", "high", "max"])
    def test_declared_effort_reaches_optional_params(self, effort):
        optional_params = litellm.get_optional_params(
            model="kimi-k3",
            custom_llm_provider="moonshot",
            reasoning_effort=effort,
            drop_params=False,
        )

        assert optional_params["reasoning_effort"] == effort

    def test_non_reasoning_model_still_rejects_reasoning_effort(self):
        with pytest.raises(litellm.UnsupportedParamsError):
            litellm.get_optional_params(
                model="moonshot-v1-8k",
                custom_llm_provider="moonshot",
                reasoning_effort="high",
                drop_params=False,
            )

    def test_bridge_effort_dict_is_unwrapped_to_the_level_string(self):
        optional_params = MoonshotChatConfig().map_openai_params(
            non_default_params={"reasoning_effort": {"effort": "high", "summary": "detailed"}},
            optional_params={},
            model="kimi-k3",
            drop_params=False,
        )

        assert optional_params["reasoning_effort"] == "high"

    @pytest.mark.parametrize("value", [{"summary": "detailed"}, {"effort": 3}, 7])
    def test_effort_without_a_level_string_is_omitted(self, value):
        optional_params = MoonshotChatConfig().map_openai_params(
            non_default_params={"reasoning_effort": value},
            optional_params={},
            model="kimi-k3",
            drop_params=False,
        )

        assert "reasoning_effort" not in optional_params
