"""
Management command to verify flag definitions cache consistency.

Compares cached flag definitions data against database to detect discrepancies.
When --fix is used, the cache is updated to match the database.

Usage:
    # Verify all teams
    python manage.py verify_flag_definitions_cache

    # Verify specific teams
    python manage.py verify_flag_definitions_cache --team-ids 123 456 789

    # Sample random teams
    python manage.py verify_flag_definitions_cache --sample 100

    # Verbose output (show full diffs)
    python manage.py verify_flag_definitions_cache --verbose

    # Automatically fix cache issues
    python manage.py verify_flag_definitions_cache --fix
"""

from typing import Any, override

from posthog.management.commands._base_hypercache_command import BaseHyperCacheCommand
from posthog.models.team import Team

from products.feature_flags.backend.local_evaluation import (
    FLAG_DEFINITIONS_HYPERCACHE_MANAGEMENT_CONFIG,
    verify_team_flag_definitions,
)


class Command(BaseHyperCacheCommand):
    help = "Verify flag definitions cache consistency against database"

    def add_arguments(self, parser):
        self.add_common_team_arguments(parser)
        self.add_verify_arguments(parser)

    @override
    def format_verbose_diff(self, diff: dict):
        """
        Format and print a single diff for verbose verification output.

        Handles the flag-definitions diff structure which uses:
        - type: MISSING_IN_CACHE, STALE_IN_CACHE, or FIELD_MISMATCH
        - flag_key: The flag key
        - field_diffs: (for FIELD_MISMATCH) List of {field, db_value, cached_value}
        """
        diff_type = diff.get("type")
        flag_key = diff.get("flag_key") or str(diff.get("flag_id"))

        if diff_type == "MISSING_IN_CACHE":
            self.stdout.write(f"  Flag '{flag_key}': exists in DB but missing from cache")
        elif diff_type == "STALE_IN_CACHE":
            self.stdout.write(f"  Flag '{flag_key}': exists in cache but deleted from DB")
        elif diff_type == "FIELD_MISMATCH":
            self.stdout.write(f"  Flag '{flag_key}': field values differ")
            field_diffs = diff.get("field_diffs", [])
            for field_diff in field_diffs:
                field_name = field_diff.get("field", "unknown_field")
                self.stdout.write(f"    Field: {field_name}")
                self.stdout.write(f"      DB:    {field_diff.get('db_value')}")
                self.stdout.write(f"      Cache: {field_diff.get('cached_value')}")
        else:
            # Fallback for unknown diff types (e.g., COHORTS_MISMATCH, GROUP_TYPE_MAPPING_MISMATCH)
            self.stdout.write(f"  Flag '{flag_key}': {diff_type}")

    def handle(self, *args, **options):
        # No check_dedicated_cache_configured() needed — flag definitions use the
        # default cache (REDIS_URL), not the dedicated flags cache (FLAGS_REDIS_URL).
        team_ids = options.get("team_ids")
        sample_size = options.get("sample")
        verbose = options.get("verbose", False)
        fix = options.get("fix", False)

        # Validate input arguments to prevent resource exhaustion
        if sample_size is not None:
            if not self.validate_sample_size(sample_size):
                return

        self.run_verification(
            team_ids=team_ids,
            sample_size=sample_size,
            verbose=verbose,
            fix=fix,
        )

    def get_hypercache_config(self):
        """Return the HyperCache management configuration."""
        return FLAG_DEFINITIONS_HYPERCACHE_MANAGEMENT_CONFIG

    def verify_team(self, team: Team, verbose: bool, batch_data: dict[int, Any] | None = None) -> dict[str, Any]:
        """Verify a single team's flag definitions cache against the database."""
        return verify_team_flag_definitions(
            team,
            db_batch_data=batch_data,
            verbose=verbose,
        )
