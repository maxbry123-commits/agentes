import datetime as dt
from typing import Any, Optional

from freezegun import freeze_time
from posthog.test.base import APIBaseTest, ClickhouseTestMixin
from unittest.mock import MagicMock, patch

import dateutil.parser
from parameterized import parameterized

from posthog.schema import AlertCalculationInterval, AlertState

from posthog.api.test.dashboards import DashboardAPI
from posthog.models.instance_setting import set_instance_setting
from posthog.models.personal_api_key import PersonalAPIKey, hash_key_value
from posthog.models.utils import generate_random_token_personal
from posthog.tasks.alerts.metrics_investigation import MAX_SUMMARY_LENGTH
from posthog.tasks.alerts.test.alert_check_helpers import run_alert_check

from products.alerts.backend.models.alert import AlertCheck, AlertConfiguration
from products.metrics.backend.facade.contracts import (
    InvestigationEvidence,
    InvestigationResult,
    MetricAnomalyDimension,
    MetricAnomalyReport,
    MetricSeries,
)
from products.metrics.backend.facade.testing import seed_metric

# 08:55 — the 08:00 hourly bucket is still accumulating; 07:00 is the last complete one.
FROZEN_TIME = dateutil.parser.parse("2026-07-01T08:55:00.000Z")


def _metrics_flag_only(flag: str, *args: Any, **kwargs: Any) -> bool:
    return flag == "metrics"


def _stub_investigation_result(metric_name: str, mover_label: str = "pod-1") -> InvestigationResult:
    symptom = MetricAnomalyReport(
        metric_name=metric_name,
        aggregation="avg",
        interval="1 minute",
        baseline_from="2026-07-01T05:00:00+00:00",
        baseline_to="2026-07-01T06:00:00+00:00",
        anomaly_from="2026-07-01T06:00:00+00:00",
        anomaly_to="2026-07-01T07:00:00+00:00",
        baseline_mean=5.0,
        baseline_stddev=0.5,
        anomaly_mean=50.0,
        anomaly_peak=60.0,
        change_ratio=10.0,
        direction="up",
        onset_time=None,
        top_movers=(
            MetricAnomalyDimension(
                key="pod", label=mover_label, baseline_value=5.0, anomaly_value=50.0, change_ratio=10.0
            ),
        ),
        series=MetricSeries(labels={}, points=()),
    )
    return InvestigationResult(
        metric_name=metric_name,
        symptom=symptom,
        blast_radius="localized",
        companions=(),
        chart_specs=(),
        evidence=InvestigationEvidence(service_name=None),
        confidence="high",
        narrative="",
    )


@freeze_time(FROZEN_TIME)
@patch(
    "products.alerts.backend.presentation.views.alert.posthoganalytics.feature_enabled", side_effect=_metrics_flag_only
)
@patch("posthog.tasks.alerts.utils.send_notifications_for_errors", return_value=[])
@patch("posthog.tasks.alerts.utils.send_notifications_for_breaches", return_value=[])
class TestMetricsAlerts(APIBaseTest, ClickhouseTestMixin):
    def setUp(self) -> None:
        super().setUp()
        set_instance_setting("EMAIL_HOST", "fake_host")
        set_instance_setting("EMAIL_ENABLED", True)
        self.dashboard_api = DashboardAPI(self.client, self.team, self.assertEqual)
        # metrics1 is not truncated between tests, so a per-test metric name keeps tests isolated.
        self.metric_name = f"queue.depth.{self._testMethodName}"

    def create_metrics_insight(
        self, group_by: Optional[list[str]] = None, clauses: Optional[list[dict[str, Any]]] = None
    ) -> dict:
        if clauses is None:
            clause: dict[str, Any] = {"name": "a", "metricName": self.metric_name, "aggregation": "avg"}
            if group_by:
                clause["groupBy"] = [{"key": key} for key in group_by]
            clauses = [clause]
        query_dict = {"kind": "MetricsQuery", "clauses": clauses}
        return self.dashboard_api.create_insight(data={"name": "metrics insight", "query": query_dict})[1]

    def create_alert(
        self,
        insight: dict,
        lower: Optional[float] = None,
        upper: Optional[float] = None,
        condition_type: str = "absolute_value",
        config: Optional[dict] = None,
        expected_status: int = 201,
        **alert_overrides: Any,
    ) -> dict:
        data = {
            "name": "metrics alert",
            "insight": insight["id"],
            "subscribed_users": [self.user.id],
            "config": config or {"type": "MetricsAlertConfig"},
            "condition": {"type": condition_type},
            "calculation_interval": AlertCalculationInterval.DAILY,
            "threshold": {"configuration": {"type": "absolute", "bounds": {"lower": lower, "upper": upper}}},
            **alert_overrides,
        }
        response = self.client.post(f"/api/projects/{self.team.id}/alerts", data=data)
        assert response.status_code == expected_status, response.json()
        return response.json()

    def seed_gauge(self, values_by_hour: dict[int, float], labels: Optional[dict[str, str]] = None) -> None:
        seed_metric(
            team_id=self.team.pk,
            metric_name=self.metric_name,
            metric_type="gauge",
            points=[
                (dt.datetime(2026, 7, 1, hour, 30, tzinfo=dt.UTC), value) for hour, value in values_by_hour.items()
            ],
            labels=labels or {},
        )

    @parameterized.expand(
        [
            # (name, seeded value, lower, upper, expected_state, expected_message_fragment)
            ("lower_breach_fires", 5.0, 10.0, None, AlertState.FIRING, "is less than lower threshold (10.0)"),
            ("upper_breach_fires", 50.0, None, 20.0, AlertState.FIRING, "is more than upper threshold (20.0)"),
            ("within_bounds_not_firing", 15.0, 10.0, 20.0, AlertState.NOT_FIRING, None),
        ]
    )
    def test_absolute_threshold(
        self,
        mock_send_breaches: MagicMock,
        mock_send_errors: MagicMock,
        mock_feature_enabled: MagicMock,
        _name: str,
        seeded_value: float,
        lower: Optional[float],
        upper: Optional[float],
        expected_state: AlertState,
        expected_fragment: Optional[str],
    ) -> None:
        # Two complete hourly buckets; the default anchor is the second-to-last observed bucket (07:00).
        self.seed_gauge({6: seeded_value, 7: seeded_value, 8: seeded_value})
        insight = self.create_metrics_insight()
        alert = self.create_alert(insight, lower=lower, upper=upper)
        assert alert["state"] == AlertState.NOT_FIRING

        run_alert_check(alert["id"])

        updated_alert = AlertConfiguration.objects.get(pk=alert["id"])
        assert updated_alert.state == expected_state
        alert_check = AlertCheck.objects.filter(alert_configuration=alert["id"]).latest("created_at")
        assert alert_check.calculated_value == seeded_value
        if expected_fragment is None:
            mock_send_breaches.assert_not_called()
        else:
            mock_send_breaches.assert_called_once()
            breach_messages = mock_send_breaches.call_args.args[1]
            assert any(expected_fragment in message for message in breach_messages), breach_messages

    def test_empty_metrics_result_evaluates_as_zero(
        self, mock_send_breaches: MagicMock, mock_send_errors: MagicMock, mock_feature_enabled: MagicMock
    ) -> None:
        # No data at all: the alert must still evaluate (as 0) and fire a lower-bound breach,
        # not error out or silently skip.
        insight = self.create_metrics_insight()
        alert = self.create_alert(insight, lower=1.0)

        run_alert_check(alert["id"])

        updated_alert = AlertConfiguration.objects.get(pk=alert["id"])
        assert updated_alert.state == AlertState.FIRING
        alert_check = AlertCheck.objects.filter(alert_configuration=alert["id"]).latest("created_at")
        assert alert_check.calculated_value == 0
        assert alert_check.error is None

    def test_group_by_fires_on_any_breaching_series(
        self, mock_send_breaches: MagicMock, mock_send_errors: MagicMock, mock_feature_enabled: MagicMock
    ) -> None:
        # Two label-sets; only one breaches. Catches an extractor that evaluates only the first series.
        self.seed_gauge({6: 5.0, 7: 5.0}, labels={"container": "small"})
        self.seed_gauge({6: 50.0, 7: 50.0}, labels={"container": "big"})
        insight = self.create_metrics_insight(group_by=["container"])
        alert = self.create_alert(insight, upper=20.0)

        run_alert_check(alert["id"])

        updated_alert = AlertConfiguration.objects.get(pk=alert["id"])
        assert updated_alert.state == AlertState.FIRING
        mock_send_breaches.assert_called_once()
        breach_messages = mock_send_breaches.call_args.args[1]
        assert any("big" in message for message in breach_messages), breach_messages

    def test_relative_increase_fires(
        self, mock_send_breaches: MagicMock, mock_send_errors: MagicMock, mock_feature_enabled: MagicMock
    ) -> None:
        # Anchor bucket (06:00) is 5 above the previous bucket (05:00); catches wrong
        # anchor/previous index wiring on the observed-bucket grid.
        self.seed_gauge({5: 10.0, 6: 15.0, 7: 15.0})
        insight = self.create_metrics_insight()
        alert = self.create_alert(insight, upper=4.0, condition_type="relative_increase")

        run_alert_check(alert["id"])

        updated_alert = AlertConfiguration.objects.get(pk=alert["id"])
        assert updated_alert.state == AlertState.FIRING
        alert_check = AlertCheck.objects.filter(alert_configuration=alert["id"]).latest("created_at")
        assert alert_check.calculated_value == 5.0

    def test_create_rejected_when_metrics_flag_disabled(
        self, mock_send_breaches: MagicMock, mock_send_errors: MagicMock, mock_feature_enabled: MagicMock
    ) -> None:
        mock_feature_enabled.side_effect = None
        mock_feature_enabled.return_value = False
        insight = self.create_metrics_insight()
        response = self.create_alert(insight, lower=1.0, expected_status=400)
        assert "not enabled" in response["detail"].lower() or "not supported" in response["detail"].lower()

    def test_simulate_rejected_when_metrics_flag_disabled(
        self, mock_send_breaches: MagicMock, mock_send_errors: MagicMock, mock_feature_enabled: MagicMock
    ) -> None:
        # The simulate endpoint must apply the same feature gate as create/update — otherwise a
        # flag-off account gets the ungated unsupported-detector error instead of the gated one.
        insight = self.create_metrics_insight()
        mock_feature_enabled.side_effect = None
        mock_feature_enabled.return_value = False
        response = self.client.post(
            f"/api/projects/{self.team.id}/alerts/simulate",
            data={
                "insight": insight["id"],
                "detector_config": {"type": "zscore", "threshold": 0.9, "window": 10},
            },
        )
        assert response.status_code == 400, response.json()
        assert "not enabled" in str(response.json()).lower()

    def test_simulate_rejects_metrics_insight_with_flag_on(
        self, mock_send_breaches: MagicMock, mock_send_errors: MagicMock, mock_feature_enabled: MagicMock
    ) -> None:
        # Metrics has no detector extractor: simulation must 400 cleanly via the registry, not 500.
        insight = self.create_metrics_insight()
        response = self.client.post(
            f"/api/projects/{self.team.id}/alerts/simulate",
            data={
                "insight": insight["id"],
                "detector_config": {"type": "zscore", "threshold": 0.9, "window": 10},
            },
        )
        assert response.status_code == 400, response.json()
        assert "isn't supported for MetricsQuery" in str(response.json())

    @parameterized.expand(
        [
            # An alert executes the metrics query as created_by and delivers values in
            # notifications, so a programmatic token needs the metrics data scope too —
            # without this, alert:write alone is a metrics-read oracle.
            ("alert_write_only_rejected", ["alert:write"], 403),
            ("alert_write_with_metrics_read_allowed", ["alert:write", "metrics:read"], 201),
        ]
    )
    def test_api_key_metrics_scope_enforcement(
        self,
        mock_send_breaches: MagicMock,
        mock_send_errors: MagicMock,
        mock_feature_enabled: MagicMock,
        _name: str,
        scopes: list[str],
        expected_status: int,
    ) -> None:
        insight = self.create_metrics_insight()
        key_value = generate_random_token_personal()
        PersonalAPIKey.objects.create(
            label="metrics alerts test",
            user=self.user,
            secure_value=hash_key_value(key_value),
            scopes=scopes,
        )
        response = self.client.post(
            f"/api/projects/{self.team.id}/alerts",
            data={
                "name": "metrics alert",
                "insight": insight["id"],
                "subscribed_users": [self.user.id],
                "config": {"type": "MetricsAlertConfig"},
                "condition": {"type": "absolute_value"},
                "calculation_interval": AlertCalculationInterval.DAILY,
                "threshold": {"configuration": {"type": "absolute", "bounds": {"lower": 1.0, "upper": None}}},
            },
            HTTP_AUTHORIZATION=f"Bearer {key_value}",
        )
        assert response.status_code == expected_status, response.json()
        if expected_status == 403:
            assert "metrics:read" in str(response.json())

    @parameterized.expand(
        [
            # Read paths must hide metric alert results (last_value, check history, breach labels)
            # from tokens lacking the metrics data scope — otherwise alert:read alone reads values
            # from alerts a session user scheduled, bypassing the write-side gate.
            ("alert_read_only_hidden", ["alert:read"], False),
            ("alert_read_with_metrics_read_visible", ["alert:read", "metrics:read"], True),
        ]
    )
    def test_api_key_read_paths_gate_metrics_alerts(
        self,
        mock_send_breaches: MagicMock,
        mock_send_errors: MagicMock,
        mock_feature_enabled: MagicMock,
        _name: str,
        scopes: list[str],
        visible: bool,
    ) -> None:
        insight = self.create_metrics_insight()
        alert = self.create_alert(insight, lower=1.0)  # session-created, so no write-side scope gate
        key_value = generate_random_token_personal()
        PersonalAPIKey.objects.create(
            label="metrics alerts read test",
            user=self.user,
            secure_value=hash_key_value(key_value),
            scopes=scopes,
        )
        authorization = f"Bearer {key_value}"

        list_response = self.client.get(f"/api/projects/{self.team.id}/alerts", HTTP_AUTHORIZATION=authorization)
        assert list_response.status_code == 200, list_response.json()
        listed_ids = {result["id"] for result in list_response.json()["results"]}
        assert (alert["id"] in listed_ids) is visible

        detail_response = self.client.get(
            f"/api/projects/{self.team.id}/alerts/{alert['id']}", HTTP_AUTHORIZATION=authorization
        )
        assert detail_response.status_code == (200 if visible else 404), detail_response.json()

        # Thresholds (nested under the insight) embed full alerts including check values, so they
        # must be gated the same way.
        thresholds_response = self.client.get(
            f"/api/projects/{self.team.id}/insights/{insight['id']}/thresholds", HTTP_AUTHORIZATION=authorization
        )
        assert thresholds_response.status_code == 200, thresholds_response.json()
        threshold_alert_ids = {
            nested["id"] for result in thresholds_response.json()["results"] for nested in result.get("alerts", [])
        }
        assert (alert["id"] in threshold_alert_ids) is visible

    @parameterized.expand(
        [
            (
                "trends_config_on_metrics_insight",
                {"type": "TrendsAlertConfig", "series_index": 0},
                {},
                "not supported",
            ),
            (
                "detector_config_rejected",
                {"type": "MetricsAlertConfig"},
                {"detector_config": {"type": "zscore", "threshold": 0.9, "window": 10}},
                "anomaly detection",
            ),
            (
                "ongoing_interval_requires_upper_bound",
                {"type": "MetricsAlertConfig", "check_ongoing_interval": True},
                {},
                "upper threshold",
            ),
        ]
    )
    def test_invalid_configs_rejected(
        self,
        mock_send_breaches: MagicMock,
        mock_send_errors: MagicMock,
        mock_feature_enabled: MagicMock,
        _name: str,
        config: dict,
        alert_overrides: dict,
        expected_fragment: str,
    ) -> None:
        insight = self.create_metrics_insight()
        response = self.create_alert(insight, lower=1.0, config=config, expected_status=400, **alert_overrides)
        assert expected_fragment in str(response).lower(), response

    def test_firing_metrics_alert_runs_investigation_and_persists_summary(
        self, mock_send_breaches: MagicMock, mock_send_errors: MagicMock, mock_feature_enabled: MagicMock
    ) -> None:
        # The roadmap loop: a firing metrics alert attaches an investigation to its
        # check, so the alert page carries the why, not just the that.
        self.seed_gauge(dict.fromkeys(range(0, 6), 5.0) | {6: 50.0, 7: 50.0})
        insight = self.create_metrics_insight()
        alert = self.create_alert(insight, upper=20.0, investigation_agent_enabled=True)

        run_alert_check(alert["id"])

        alert_check = AlertCheck.objects.filter(alert_configuration=alert["id"]).latest("created_at")
        assert AlertConfiguration.objects.get(pk=alert["id"]).state == AlertState.FIRING
        assert alert_check.investigation_status == "done"
        assert alert_check.investigation_summary
        assert self.metric_name in alert_check.investigation_summary

    def test_investigation_only_runs_when_enabled(
        self, mock_send_breaches: MagicMock, mock_send_errors: MagicMock, mock_feature_enabled: MagicMock
    ) -> None:
        self.seed_gauge({6: 50.0, 7: 50.0})
        insight = self.create_metrics_insight()
        alert = self.create_alert(insight, upper=20.0)

        run_alert_check(alert["id"])

        alert_check = AlertCheck.objects.filter(alert_configuration=alert["id"]).latest("created_at")
        assert alert_check.investigation_status is None
        assert alert_check.investigation_summary is None

    def test_investigation_failure_is_recorded_without_breaking_the_alert(
        self, mock_send_breaches: MagicMock, mock_send_errors: MagicMock, mock_feature_enabled: MagicMock
    ) -> None:
        self.seed_gauge({6: 50.0, 7: 50.0})
        insight = self.create_metrics_insight()
        alert = self.create_alert(insight, upper=20.0, investigation_agent_enabled=True)

        with patch(
            "posthog.tasks.alerts.metrics_investigation._run_investigation",
            side_effect=RuntimeError("boom"),
        ):
            run_alert_check(alert["id"])

        alert_check = AlertCheck.objects.filter(alert_configuration=alert["id"]).latest("created_at")
        assert AlertConfiguration.objects.get(pk=alert["id"]).state == AlertState.FIRING
        assert alert_check.investigation_status == "failed"
        mock_send_breaches.assert_called_once()  # the alert still notifies

    def test_multi_clause_alert_investigates_each_distinct_clause(
        self, mock_send_breaches: MagicMock, mock_send_errors: MagicMock, mock_feature_enabled: MagicMock
    ) -> None:
        # The check records one fired value with no pointer to the breaching
        # clause, so an investigation pinned to clauses[0] could summarize the
        # wrong metric; duplicate targets are investigated only once.
        self.seed_gauge({6: 50.0, 7: 50.0})
        insight = self.create_metrics_insight(
            clauses=[
                {"name": "a", "metricName": self.metric_name, "aggregation": "avg"},
                {"name": "b", "metricName": "companion.metric", "aggregation": "avg"},
                {"name": "c", "metricName": self.metric_name, "aggregation": "sum"},
            ]
        )
        alert = self.create_alert(insight, upper=20.0, investigation_agent_enabled=True)

        with patch(
            "products.metrics.backend.facade.api.investigate_incident",
            side_effect=lambda *, team, context: _stub_investigation_result(context.metric_name),
        ) as mock_investigate:
            run_alert_check(alert["id"])

        investigated = [call.kwargs["context"].metric_name for call in mock_investigate.call_args_list]
        assert investigated == [self.metric_name, "companion.metric"]
        alert_check = AlertCheck.objects.filter(alert_configuration=alert["id"]).latest("created_at")
        assert alert_check.investigation_status == "done"
        assert alert_check.investigation_summary is not None
        assert self.metric_name in alert_check.investigation_summary
        assert "companion.metric" in alert_check.investigation_summary

    @parameterized.expand(
        [
            # (name, service filter, service the investigation is scoped to, caveat expected)
            ("eq_scopes_to_the_service", {"key": "service.name", "op": "eq", "value": "billing"}, "billing", False),
            ("neq_cannot_derive_a_service", {"key": "service.name", "op": "neq", "value": "billing"}, None, True),
            ("regex_cannot_derive_a_service", {"key": "service.name", "op": "regex", "value": "bill.*"}, None, True),
        ]
    )
    def test_investigation_service_scope_from_clause_filters(
        self,
        mock_send_breaches: MagicMock,
        mock_send_errors: MagicMock,
        mock_feature_enabled: MagicMock,
        _name: str,
        service_filter: dict[str, str],
        expected_service: Optional[str],
        expects_caveat: bool,
    ) -> None:
        # The seeded first clause fires the alert; the second clause carries the
        # service filter under test. A non-eq filter can't pin down one service,
        # so the summary must say the investigation ran unscoped.
        self.seed_gauge({6: 50.0, 7: 50.0})
        insight = self.create_metrics_insight(
            clauses=[
                {"name": "a", "metricName": self.metric_name, "aggregation": "avg"},
                {"name": "b", "metricName": "scoped.metric", "aggregation": "avg", "filters": [service_filter]},
            ]
        )
        alert = self.create_alert(insight, upper=20.0, investigation_agent_enabled=True)

        with patch(
            "products.metrics.backend.facade.api.investigate_incident",
            side_effect=lambda *, team, context: _stub_investigation_result(context.metric_name),
        ) as mock_investigate:
            run_alert_check(alert["id"])

        scoped_call = mock_investigate.call_args_list[1]
        assert scoped_call.kwargs["context"].service_name == expected_service
        alert_check = AlertCheck.objects.filter(alert_configuration=alert["id"]).latest("created_at")
        assert alert_check.investigation_summary is not None
        assert ("ran across all services" in alert_check.investigation_summary) == expects_caveat

    def test_investigation_summary_is_capped(
        self, mock_send_breaches: MagicMock, mock_send_errors: MagicMock, mock_feature_enabled: MagicMock
    ) -> None:
        # Mover labels come from ingested telemetry, so an oversized label must
        # not persist an unbounded summary on the check.
        self.seed_gauge({6: 50.0, 7: 50.0})
        insight = self.create_metrics_insight()
        alert = self.create_alert(insight, upper=20.0, investigation_agent_enabled=True)

        with patch(
            "products.metrics.backend.facade.api.investigate_incident",
            side_effect=lambda *, team, context: _stub_investigation_result(
                context.metric_name, mover_label="x" * 10_000
            ),
        ):
            run_alert_check(alert["id"])

        alert_check = AlertCheck.objects.filter(alert_configuration=alert["id"]).latest("created_at")
        assert alert_check.investigation_status == "done"
        assert alert_check.investigation_summary is not None
        assert len(alert_check.investigation_summary) == MAX_SUMMARY_LENGTH

    def test_investigation_flag_still_rejected_for_trends_threshold_alerts(
        self, mock_send_breaches: MagicMock, mock_send_errors: MagicMock, mock_feature_enabled: MagicMock
    ) -> None:
        # Loosening the metrics gate must not loosen it for other kinds: a trends
        # threshold alert without a detector still can't enable the agent.
        trends_query = {
            "kind": "TrendsQuery",
            "series": [{"kind": "EventsNode", "event": "$pageview", "math": "total"}],
        }
        trends_insight = self.dashboard_api.create_insight(data={"name": "t", "query": trends_query})[1]
        response = self.client.post(
            f"/api/projects/{self.team.id}/alerts",
            data={
                "name": "trends alert",
                "insight": trends_insight["id"],
                "subscribed_users": [self.user.id],
                "config": {"type": "TrendsAlertConfig", "series_index": 0},
                "condition": {"type": "absolute_value"},
                "calculation_interval": AlertCalculationInterval.DAILY,
                "threshold": {"configuration": {"type": "absolute", "bounds": {"upper": 1.0}}},
                "investigation_agent_enabled": True,
            },
        )
        assert response.status_code == 400
        assert "anomaly detection" in str(response.json()).lower()
