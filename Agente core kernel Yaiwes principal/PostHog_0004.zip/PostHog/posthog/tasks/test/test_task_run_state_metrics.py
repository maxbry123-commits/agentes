from datetime import datetime, timedelta
from typing import TYPE_CHECKING, ClassVar, Optional

from unittest.mock import MagicMock, patch

from django.apps import apps
from django.db import OperationalError, ProgrammingError
from django.test import TestCase
from django.utils import timezone

from parameterized import parameterized
from prometheus_client import CollectorRegistry

from posthog.models import Organization, Team
from posthog.tasks.tasks import capture_task_run_state_metrics

if TYPE_CHECKING:
    from products.tasks.backend.models import Task, TaskRun


class TestCaptureTaskRunStateMetrics(TestCase):
    organization: ClassVar[Organization]
    team: ClassVar[Team]

    @classmethod
    def setUpTestData(cls) -> None:
        cls.organization = Organization.objects.create(name="Test Org")
        cls.team = Team.objects.create(organization=cls.organization, name="Test Team")

    def _make_task_run(
        self,
        *,
        origin: "Task.OriginProduct",
        status: "TaskRun.Status",
        environment: "Optional[TaskRun.Environment]" = None,
        created_at: Optional[datetime] = None,
        updated_at: Optional[datetime] = None,
        queued_at: Optional[datetime] = None,
    ) -> "TaskRun":
        Task = apps.get_model("tasks", "Task")
        TaskRun = apps.get_model("tasks", "TaskRun")
        if environment is None:
            environment = TaskRun.Environment.CLOUD
        task = Task.objects.create(
            team=self.team,
            title="t",
            description="d",
            origin_product=origin,
        )
        run = TaskRun.objects.create(
            task=task,
            team=self.team,
            status=status,
            environment=environment,
        )
        # .update() bypasses auto_now, so an explicit updated_at sticks.
        overrides = {
            field: value
            for field, value in (("created_at", created_at), ("updated_at", updated_at), ("queued_at", queued_at))
            if value is not None
        }
        if overrides:
            TaskRun.objects.filter(pk=run.pk).update(**overrides)
            run.refresh_from_db()
        return run

    def _run_with_registry(self) -> CollectorRegistry:
        registry = CollectorRegistry()
        context = MagicMock()
        context.__enter__ = MagicMock(return_value=registry)
        context.__exit__ = MagicMock(return_value=False)
        with patch("posthog.tasks.tasks.pushed_metrics_registry", return_value=context):
            capture_task_run_state_metrics()
        return registry

    def test_emits_counts_grouped_by_status_origin_and_environment(self) -> None:
        Task = apps.get_model("tasks", "Task")
        TaskRun = apps.get_model("tasks", "TaskRun")
        self._make_task_run(origin=Task.OriginProduct.SLACK, status=TaskRun.Status.QUEUED)
        self._make_task_run(origin=Task.OriginProduct.SLACK, status=TaskRun.Status.QUEUED)
        self._make_task_run(origin=Task.OriginProduct.USER_CREATED, status=TaskRun.Status.IN_PROGRESS)
        self._make_task_run(
            origin=Task.OriginProduct.USER_CREATED,
            status=TaskRun.Status.IN_PROGRESS,
            environment=TaskRun.Environment.LOCAL,
        )

        registry = self._run_with_registry()

        assert (
            registry.get_sample_value(
                "posthog_tasks_runs_in_status",
                {"status": "queued", "origin_product": "slack", "run_environment": "cloud"},
            )
            == 2
        )
        assert (
            registry.get_sample_value(
                "posthog_tasks_runs_in_status",
                {"status": "in_progress", "origin_product": "user_created", "run_environment": "cloud"},
            )
            == 1
        )
        assert (
            registry.get_sample_value(
                "posthog_tasks_runs_in_status",
                {"status": "in_progress", "origin_product": "user_created", "run_environment": "local"},
            )
            == 1
        )

    @parameterized.expand(
        [
            (apps.get_model("tasks", "TaskRun").Status.COMPLETED,),
            (apps.get_model("tasks", "TaskRun").Status.FAILED,),
            (apps.get_model("tasks", "TaskRun").Status.CANCELLED,),
        ]
    )
    def test_ignores_terminal_statuses(self, status: "TaskRun.Status") -> None:
        Task = apps.get_model("tasks", "Task")
        self._make_task_run(origin=Task.OriginProduct.SLACK, status=status)

        registry = self._run_with_registry()

        assert (
            registry.get_sample_value(
                "posthog_tasks_runs_in_status",
                {"status": status.value, "origin_product": "slack", "run_environment": "cloud"},
            )
            is None
        )

    def test_emits_oldest_open_run_age(self) -> None:
        Task = apps.get_model("tasks", "Task")
        TaskRun = apps.get_model("tasks", "TaskRun")
        long_ago = timezone.now() - timedelta(minutes=30)
        self._make_task_run(
            origin=Task.OriginProduct.SLACK,
            status=TaskRun.Status.QUEUED,
            created_at=long_ago,
        )
        self._make_task_run(origin=Task.OriginProduct.SLACK, status=TaskRun.Status.QUEUED)

        registry = self._run_with_registry()

        age = registry.get_sample_value(
            "posthog_tasks_oldest_open_run_age_seconds",
            {"status": "queued", "origin_product": "slack", "run_environment": "cloud"},
        )
        assert age is not None
        # Oldest run was ~30 minutes ago; allow generous slack for test timing.
        assert 1500 < age < 2400

    @parameterized.expand(
        [
            # A cloud handoff re-queues an existing run without resetting created_at, so anchoring
            # the queue wait on created_at would report the whole pre-handoff lifetime as backlog.
            ("requeued_by_handoff", apps.get_model("tasks", "TaskRun").Status.QUEUED, 30, 1500, 2400),
            # An unrelated write to a still-queued run advances updated_at, so anchoring on
            # updated_at would make a genuinely stranded run look newly queued.
            ("written_while_still_queued", apps.get_model("tasks", "TaskRun").Status.QUEUED, 360, 20000, 23000),
            # Rows queued before queued_at existed fall back to created_at.
            ("queued_before_the_field_existed", apps.get_model("tasks", "TaskRun").Status.QUEUED, None, 20000, 23000),
            ("in_progress_reports_lifetime", apps.get_model("tasks", "TaskRun").Status.IN_PROGRESS, 30, 20000, 23000),
        ]
    )
    def test_oldest_age_anchors_queued_runs_on_queued_at(
        self, _name: str, status: "TaskRun.Status", queued_minutes_ago: Optional[int], low: int, high: int
    ) -> None:
        Task = apps.get_model("tasks", "Task")
        now = timezone.now()
        self._make_task_run(
            origin=Task.OriginProduct.SLACK,
            status=status,
            created_at=now - timedelta(hours=6),
            updated_at=now - timedelta(minutes=30),
            queued_at=None if queued_minutes_ago is None else now - timedelta(minutes=queued_minutes_ago),
        )

        registry = self._run_with_registry()

        age = registry.get_sample_value(
            "posthog_tasks_oldest_open_run_age_seconds",
            {"status": status.value, "origin_product": "slack", "run_environment": "cloud"},
        )
        assert age is not None
        assert low < age < high

    def test_emits_runs_created_1h_by_origin_and_environment(self) -> None:
        Task = apps.get_model("tasks", "Task")
        TaskRun = apps.get_model("tasks", "TaskRun")
        # Two Slack runs created just now, one old run (outside the 1h window), one PostHog-code run.
        self._make_task_run(origin=Task.OriginProduct.SLACK, status=TaskRun.Status.QUEUED)
        self._make_task_run(origin=Task.OriginProduct.SLACK, status=TaskRun.Status.COMPLETED)
        self._make_task_run(
            origin=Task.OriginProduct.SLACK,
            status=TaskRun.Status.COMPLETED,
            created_at=timezone.now() - timedelta(hours=2),
        )
        self._make_task_run(origin=Task.OriginProduct.USER_CREATED, status=TaskRun.Status.COMPLETED)

        registry = self._run_with_registry()

        assert (
            registry.get_sample_value(
                "posthog_tasks_runs_created_1h",
                {"origin_product": "slack", "run_environment": "cloud"},
            )
            == 2
        )
        assert (
            registry.get_sample_value(
                "posthog_tasks_runs_created_1h",
                {"origin_product": "user_created", "run_environment": "cloud"},
            )
            == 1
        )

    def test_emits_runs_terminal_1h_grouped_by_status_and_origin(self) -> None:
        Task = apps.get_model("tasks", "Task")
        TaskRun = apps.get_model("tasks", "TaskRun")
        # 2 completed Slack runs + 1 failed User run in the last hour, plus 1 old completed run (outside 1h).
        self._make_task_run(origin=Task.OriginProduct.SLACK, status=TaskRun.Status.COMPLETED)
        self._make_task_run(origin=Task.OriginProduct.SLACK, status=TaskRun.Status.COMPLETED)
        self._make_task_run(origin=Task.OriginProduct.USER_CREATED, status=TaskRun.Status.FAILED)
        old = self._make_task_run(origin=Task.OriginProduct.SLACK, status=TaskRun.Status.COMPLETED)
        TaskRun.objects.filter(pk=old.pk).update(updated_at=timezone.now() - timedelta(hours=2))

        registry = self._run_with_registry()

        assert (
            registry.get_sample_value(
                "posthog_tasks_runs_terminal_1h",
                {"status": "completed", "origin_product": "slack", "run_environment": "cloud"},
            )
            == 2
        )
        assert (
            registry.get_sample_value(
                "posthog_tasks_runs_terminal_1h",
                {"status": "failed", "origin_product": "user_created", "run_environment": "cloud"},
            )
            == 1
        )

    @parameterized.expand(
        [
            ("missing_table", ProgrammingError('relation "posthog_task_run" does not exist')),
            ("transient_connection_timeout", OperationalError("connection timeout expired")),
        ]
    )
    def test_transient_db_errors_are_suppressed_without_reporting(self, _name: str, error: Exception) -> None:
        with (
            patch(
                "products.tasks.backend.facade.api.collect_task_run_state_metrics",
                side_effect=error,
            ),
            patch("posthog.tasks.tasks.capture_exception") as capture_mock,
        ):
            self._run_with_registry()

        capture_mock.assert_not_called()

    def test_unexpected_errors_are_still_reported(self) -> None:
        with (
            patch(
                "products.tasks.backend.facade.api.collect_task_run_state_metrics",
                side_effect=ValueError("boom"),
            ),
            patch("posthog.tasks.tasks.capture_exception") as capture_mock,
        ):
            self._run_with_registry()

        capture_mock.assert_called_once()

    def test_age_gauge_only_covers_queued_and_in_progress(self) -> None:
        Task = apps.get_model("tasks", "Task")
        TaskRun = apps.get_model("tasks", "TaskRun")
        self._make_task_run(
            origin=Task.OriginProduct.SLACK,
            status=TaskRun.Status.NOT_STARTED,
            created_at=timezone.now() - timedelta(minutes=5),
        )

        registry = self._run_with_registry()

        assert (
            registry.get_sample_value(
                "posthog_tasks_oldest_open_run_age_seconds",
                {"status": "not_started", "origin_product": "slack", "run_environment": "cloud"},
            )
            is None
        )
        # But it should still appear in the count gauge (not_started is "open").
        assert (
            registry.get_sample_value(
                "posthog_tasks_runs_in_status",
                {"status": "not_started", "origin_product": "slack", "run_environment": "cloud"},
            )
            == 1
        )
