import json
from datetime import UTC, datetime, timedelta
from typing import Any, cast

from freezegun import freeze_time
from posthog.test.base import APIBaseTest, QueryMatchingTest, snapshot_postgres_queries
from unittest.mock import patch

from parameterized import parameterized

from posthog.models import Organization
from posthog.models.activity_logging.activity_log import ActivityLog
from posthog.models.team import Team
from posthog.tasks.process_scheduled_changes import process_scheduled_changes

from products.feature_flags.backend.models.feature_flag import FeatureFlag
from products.feature_flags.backend.models.scheduled_change import ScheduledChange


class TestProcessScheduledChanges(APIBaseTest, QueryMatchingTest):
    def test_schedule_feature_flag_set_active(self) -> None:
        feature_flag = FeatureFlag.objects.create(
            name="Flag 1",
            key="flag-1",
            active=False,
            filters={"groups": []},
            team=self.team,
            created_by=self.user,
        )

        ScheduledChange.objects.create(
            team=self.team,
            record_id=feature_flag.id,
            model_name="FeatureFlag",
            payload={"operation": "update_status", "value": True},
            scheduled_at=(datetime.now(UTC) - timedelta(seconds=30)).isoformat(),
        )

        process_scheduled_changes()

        updated_flag = FeatureFlag.objects.get(key="flag-1")
        self.assertEqual(updated_flag.active, True)

    def test_schedule_feature_flag_add_release_condition(self) -> None:
        feature_flag = FeatureFlag.objects.create(
            name="Flag 1",
            key="flag-1",
            active=False,
            filters={"groups": []},
            team=self.team,
            created_by=self.user,
        )

        new_release_condition = {
            "variant": None,
            "properties": [{"key": "$browser", "type": "person", "value": ["Chrome"], "operator": "exact"}],
            "rollout_percentage": 30,
            "aggregation_group_type_index": None,
        }

        payload = {
            "operation": "add_release_condition",
            "value": {"groups": [new_release_condition], "payloads": {}, "multivariate": None},
        }

        ScheduledChange.objects.create(
            team=self.team,
            record_id=feature_flag.id,
            model_name="FeatureFlag",
            payload=payload,
            scheduled_at=(datetime.now(UTC) - timedelta(seconds=30)),
        )

        process_scheduled_changes()

        updated_flag = FeatureFlag.objects.get(key="flag-1")
        self.assertEqual(updated_flag.filters["groups"][0], new_release_condition)

    def test_schedule_feature_flag_add_release_condition_preserve_variants(self) -> None:
        variants = [
            {
                "key": "first-variant",
                "name": "First Variant",
                "rollout_percentage": 25,
            },
            {
                "key": "second-variant",
                "name": "Second Variant",
                "rollout_percentage": 75,
            },
        ]

        feature_flag = FeatureFlag.objects.create(
            name="Flag 1",
            key="flag-1",
            active=False,
            team=self.team,
            created_by=self.user,
            filters={
                "groups": [],
                "multivariate": {"variants": variants},
            },
        )

        new_release_condition = {
            "variant": None,
            "properties": [{"key": "$browser", "type": "person", "value": ["Chrome"], "operator": "exact"}],
            "rollout_percentage": 30,
            "aggregation_group_type_index": None,
        }

        payload = {
            "operation": "add_release_condition",
            "value": {"groups": [new_release_condition], "payloads": {}, "multivariate": None},
        }

        ScheduledChange.objects.create(
            team=self.team,
            record_id=feature_flag.id,
            model_name="FeatureFlag",
            payload=payload,
            scheduled_at=(datetime.now(UTC) - timedelta(seconds=30)),
        )

        process_scheduled_changes()

        updated_flag = FeatureFlag.objects.get(key="flag-1")
        self.assertEqual(updated_flag.filters["groups"][0], new_release_condition)
        self.assertEqual(updated_flag.filters["multivariate"]["variants"], variants)

    def test_schedule_feature_flag_invalid_payload(self) -> None:
        feature_flag = FeatureFlag.objects.create(
            name="Flag 1",
            key="flag-1",
            active=False,
            filters={"groups": []},
            team=self.team,
            created_by=self.user,
        )

        payload = {"foo": "bar"}

        scheduled_change = ScheduledChange.objects.create(
            team=self.team,
            record_id=feature_flag.id,
            model_name="FeatureFlag",
            payload=payload,
            scheduled_at=(datetime.now(UTC) - timedelta(seconds=30)),
        )

        process_scheduled_changes()

        updated_flag = FeatureFlag.objects.get(key="flag-1")
        self.assertEqual(updated_flag.filters["groups"], [])

        updated_scheduled_change = ScheduledChange.objects.get(id=scheduled_change.id)

        # Parse the JSON failure_reason to check the error message
        self.assertIsNotNone(updated_scheduled_change.failure_reason)
        failure_reason = updated_scheduled_change.failure_reason
        assert failure_reason is not None  # For mypy type narrowing
        failure_data = json.loads(failure_reason)
        self.assertEqual(failure_data["error"], "Invalid payload")
        self.assertEqual(failure_data["error_type"], "Exception")
        self.assertIn("hostname", failure_data)
        # Note: scheduled_change_id, model, team_id, etc. are already in the ScheduledChange table columns

        # Verify failure_count was incremented
        self.assertEqual(updated_scheduled_change.failure_count, 1)

    @snapshot_postgres_queries
    @freeze_time("2023-12-21T09:00:00Z")
    def test_schedule_feature_flag_multiple_changes(self) -> None:
        feature_flag = FeatureFlag.objects.create(
            name="Flag",
            key="flag-1",
            active=True,
            filters={"groups": []},
            team=self.team,
            created_by=self.user,
        )

        # Create 4 scheduled changes
        # 1. Due in the past
        change_past_condition = {
            "properties": [{"key": "$geoip_city_name", "value": ["Sydney"], "operator": "exact", "type": "person"}],
            "rollout_percentage": 50,
            "variant": None,
            "aggregation_group_type_index": None,
        }
        change_past = ScheduledChange.objects.create(
            team=self.team,
            record_id=feature_flag.id,
            model_name="FeatureFlag",
            payload={
                "operation": "add_release_condition",
                "value": {"groups": [change_past_condition], "multivariate": None, "payloads": {}},
            },
            scheduled_at=(datetime.now(UTC) - timedelta(hours=1)),
        )

        # 2. Due in the past and already executed
        change_past_executed_at = datetime.now(UTC) - timedelta(hours=5)
        change_past_executed = ScheduledChange.objects.create(
            team=self.team,
            record_id=feature_flag.id,
            model_name="FeatureFlag",
            payload={"operation": "update_status", "value": False},
            scheduled_at=change_past_executed_at,
            executed_at=change_past_executed_at,
        )

        # 3. Due exactly now
        change_due_now_condition = {
            "properties": [{"key": "$geoip_city_name", "value": ["New York"], "operator": "exact", "type": "person"}],
            "rollout_percentage": 75,
            "variant": None,
            "aggregation_group_type_index": None,
        }
        change_due_now = ScheduledChange.objects.create(
            team=self.team,
            record_id=feature_flag.id,
            model_name="FeatureFlag",
            payload={
                "operation": "add_release_condition",
                "value": {"groups": [change_due_now_condition], "multivariate": None, "payloads": {}},
            },
            scheduled_at=datetime.now(UTC),
        )

        # 4. Due in the future
        change_due_future = ScheduledChange.objects.create(
            team=self.team,
            record_id=feature_flag.id,
            model_name="FeatureFlag",
            payload={"operation": "update_status", "value": False},
            scheduled_at=(datetime.now(UTC) + timedelta(hours=1)),
        )

        process_scheduled_changes()

        # Refresh change records
        change_past = ScheduledChange.objects.get(id=change_past.id)
        change_past_executed = ScheduledChange.objects.get(id=change_past_executed.id)
        change_due_now = ScheduledChange.objects.get(id=change_due_now.id)
        change_due_future = ScheduledChange.objects.get(id=change_due_future.id)

        # Changes due have been marked executed
        self.assertIsNotNone(change_past.executed_at)
        self.assertIsNotNone(change_due_now.executed_at)

        # Other changes have not been executed
        self.assertEqual(change_past_executed.executed_at, change_past_executed_at)
        self.assertIsNone(change_due_future.executed_at)

        # The changes due have been propagated in the correct order (oldest scheduled_at first)
        updated_flag = FeatureFlag.objects.get(key="flag-1")
        self.assertEqual(
            updated_flag.filters["groups"],
            [
                change_past_condition,
                change_due_now_condition,
            ],
        )

    def test_scheduled_changes_create_activity_log_with_trigger(self) -> None:
        """Test that scheduled changes create activity logs with trigger information while preserving user attribution"""
        feature_flag = FeatureFlag.objects.create(
            name="Test Flag",
            key="test-flag",
            active=False,
            filters={"groups": []},
            team=self.team,
            created_by=self.user,
        )

        scheduled_change = ScheduledChange.objects.create(
            team=self.team,
            record_id=feature_flag.id,
            model_name="FeatureFlag",
            payload={"operation": "update_status", "value": True},
            scheduled_at=(datetime.now(UTC) - timedelta(seconds=30)),
            created_by=self.user,
        )

        # Clear any existing activity logs
        ActivityLog.objects.filter(
            scope="FeatureFlag",
            item_id=str(feature_flag.id),
        ).delete()

        # Process the scheduled change
        process_scheduled_changes()

        # Verify the flag was updated
        updated_flag = FeatureFlag.objects.get(key="test-flag")
        self.assertEqual(updated_flag.active, True)

        # Verify scheduled change was marked as executed
        updated_scheduled_change = ScheduledChange.objects.get(id=scheduled_change.id)
        self.assertIsNotNone(updated_scheduled_change.executed_at)
        self.assertIsNone(updated_scheduled_change.failure_reason)

        # Verify activity log entry was created with trigger information
        activity_logs = ActivityLog.objects.filter(
            scope="FeatureFlag", item_id=str(feature_flag.id), activity="updated"
        )

        self.assertEqual(activity_logs.count(), 1)
        activity_log = activity_logs.first()
        self.assertIsNotNone(activity_log)
        assert activity_log is not None  # for mypy

        # Check that it's NOT marked as a system activity (scheduled changes preserve user attribution)
        self.assertFalse(activity_log.is_system)

        # Check that user attribution is preserved
        self.assertEqual(activity_log.user, self.user)

        # Check that trigger information identifies this as a scheduled change
        self.assertIsNotNone(activity_log.detail)
        detail = cast(dict[str, Any], activity_log.detail)
        trigger = detail.get("trigger")
        self.assertIsNotNone(trigger)
        trigger_data = cast(dict[str, Any], trigger)
        self.assertEqual(trigger_data["job_type"], "scheduled_change")
        self.assertEqual(trigger_data["job_id"], str(scheduled_change.id))

        # Verify the change details are correct
        changes = detail.get("changes", [])
        self.assertTrue(len(changes) > 0)

        # Find the change for the 'active' field
        active_change = None
        for change in changes:
            if change.get("field") == "active":
                active_change = change
                break

        self.assertIsNotNone(active_change)
        self.assertEqual(active_change["before"], False)  # type: ignore
        self.assertEqual(active_change["after"], True)  # type: ignore

    @freeze_time("2023-12-21T09:00:00Z")
    def test_updated_at_field_tracks_processing_time(self) -> None:
        """Test that updated_at is automatically updated when scheduled changes are processed"""
        feature_flag = FeatureFlag.objects.create(
            name="Test Flag",
            key="test-flag-updated-at",
            active=False,
            filters={"groups": []},
            team=self.team,
            created_by=self.user,
        )

        scheduled_change = ScheduledChange.objects.create(
            team=self.team,
            record_id=feature_flag.id,
            model_name="FeatureFlag",
            payload={"operation": "update_status", "value": True},
            scheduled_at=(datetime.now(UTC) - timedelta(seconds=30)),
            created_by=self.user,
        )

        # Store original timestamps
        original_created_at = scheduled_change.created_at
        original_updated_at = scheduled_change.updated_at

        # Initially, created_at and updated_at should be the same due to creation time
        self.assertEqual(original_created_at, original_updated_at)

        # Advance time to simulate processing delay
        with freeze_time("2023-12-21T09:00:10Z"):
            # Process the scheduled change
            process_scheduled_changes()

            # Refresh the scheduled change from database
            updated_scheduled_change = ScheduledChange.objects.get(id=scheduled_change.id)

            # Verify that updated_at was modified when the change was processed
            self.assertEqual(updated_scheduled_change.created_at, original_created_at)
            self.assertGreater(updated_scheduled_change.updated_at, original_updated_at)

            # Verify the change was processed successfully
            self.assertIsNotNone(updated_scheduled_change.executed_at)
            self.assertIsNone(updated_scheduled_change.failure_reason)
            self.assertEqual(updated_scheduled_change.failure_count, 0)  # No failures for successful processing

    def test_recoverable_error_allows_retry(self) -> None:
        """Test that recoverable errors don't set executed_at, allowing retries"""
        feature_flag = FeatureFlag.objects.create(
            name="Test Flag",
            key="test-recoverable-error",
            active=False,
            filters={"groups": []},
            team=self.team,
            created_by=self.user,
        )

        scheduled_change = ScheduledChange.objects.create(
            team=self.team,
            record_id=feature_flag.id,
            model_name="FeatureFlag",
            payload={"operation": "update_status", "value": True},
            scheduled_at=(datetime.now(UTC) - timedelta(seconds=30)),
            created_by=self.user,
        )

        # Mock the dispatcher to raise a recoverable error (OperationalError)
        with (
            patch.object(FeatureFlag, "scheduled_changes_dispatcher") as mock_dispatcher,
            patch("posthog.tasks.process_scheduled_changes.capture_exception") as mock_capture,
        ):
            from django.db import OperationalError

            mock_dispatcher.side_effect = OperationalError("Connection timeout")

            # Process the scheduled change - should fail but not set executed_at
            process_scheduled_changes()

            # Recoverable errors are genuinely unexpected and must still reach error tracking
            mock_capture.assert_called_once()

        # Refresh the scheduled change from database
        updated_scheduled_change = ScheduledChange.objects.get(id=scheduled_change.id)

        # Verify that executed_at is NOT set (allowing retries)
        self.assertIsNone(updated_scheduled_change.executed_at)
        self.assertIsNotNone(updated_scheduled_change.failure_reason)
        self.assertEqual(updated_scheduled_change.failure_count, 1)

        # Parse failure reason to verify it contains error details and retry info
        self.assertIsNotNone(updated_scheduled_change.failure_reason)
        failure_reason = updated_scheduled_change.failure_reason
        assert failure_reason is not None  # For mypy type narrowing
        failure_data = json.loads(failure_reason)
        self.assertEqual(failure_data["error_type"], "OperationalError")
        self.assertEqual(failure_data["error"], "Connection timeout")
        self.assertTrue(failure_data["will_retry"])  # Should indicate will retry
        self.assertEqual(failure_data["retry_count"], 1)
        self.assertEqual(failure_data["error_classification"], "recoverable")

    @parameterized.expand(
        [
            # A payload missing required keys, rejected up front by the dispatcher. This payload
            # was broken from the moment it was created, so it should still reach error tracking.
            ("invalid_payload", False, {"invalid": "payload"}, "Invalid payload", True),
            # ObjectDoesNotExist via model.objects.get(): the scenario the PR description is
            # actually about, a scheduled change whose target flag was deleted after scheduling.
            # This is expected drift, so it should not be reported to error tracking.
            ("deleted_flag", True, {"operation": "update_status", "value": True}, "does not exist", False),
            # A bare ValueError classified unrecoverable via isinstance alone (no matching
            # error-message indicator). Like invalid_payload, the payload was broken at creation
            # time (rollout percentages are self-contained in the payload), so it should still
            # reach error tracking.
            (
                "invalid_variant_rollout",
                False,
                {
                    "operation": "update_variants",
                    "value": {"variants": [{"key": "control", "name": "Control", "rollout_percentage": 50}]},
                },
                "Invalid variant rollout percentages",
                True,
            ),
        ]
    )
    def test_unrecoverable_error_prevents_retry(
        self,
        _name: str,
        delete_flag_before_processing: bool,
        payload: dict[str, Any],
        expected_error_substring: str,
        should_capture: bool,
    ) -> None:
        """Test that unrecoverable errors set executed_at, preventing retries, and that only the
        orphaned-target case is suppressed from error tracking"""
        feature_flag = FeatureFlag.objects.create(
            name="Test Flag",
            key="test-unrecoverable-error",
            active=False,
            filters={"groups": []},
            team=self.team,
            created_by=self.user,
        )

        # Create the scheduled change while the flag still exists, so record_id points at a
        # row that existed at creation time (mirrors the real orphaned-change case).
        scheduled_change = ScheduledChange.objects.create(
            team=self.team,
            record_id=feature_flag.id,
            model_name="FeatureFlag",
            payload=payload,
            scheduled_at=(datetime.now(UTC) - timedelta(seconds=30)),
            created_by=self.user,
        )

        if delete_flag_before_processing:
            feature_flag.delete()

        # Process the scheduled change - should fail and set executed_at
        with (
            patch("posthog.tasks.process_scheduled_changes.capture_exception") as mock_capture,
            patch("posthog.tasks.process_scheduled_changes.logger") as mock_logger,
        ):
            process_scheduled_changes()

            if should_capture:
                # A broken payload is a defect worth surfacing, not expected drift.
                mock_capture.assert_called_once()
                mock_logger.info.assert_not_called()
            else:
                # An orphaned target is expected and already handled, so it must not be
                # reported to error tracking (it only adds noise), but it must still leave
                # a log trail so the skip isn't silent.
                mock_capture.assert_not_called()
                mock_logger.info.assert_called_once()

        # Refresh the scheduled change from database
        updated_scheduled_change = ScheduledChange.objects.get(id=scheduled_change.id)

        # Verify that executed_at IS set (preventing retries)
        self.assertIsNotNone(updated_scheduled_change.executed_at)
        self.assertIsNotNone(updated_scheduled_change.failure_reason)
        self.assertEqual(updated_scheduled_change.failure_count, 1)

        # Parse failure reason to verify it contains error details and retry info
        failure_reason = updated_scheduled_change.failure_reason
        assert failure_reason is not None  # For mypy type narrowing
        failure_data = json.loads(failure_reason)
        self.assertIn(expected_error_substring, failure_data["error"])
        self.assertFalse(failure_data["will_retry"])  # Should indicate won't retry
        self.assertEqual(failure_data["retry_count"], 1)
        self.assertEqual(failure_data["error_classification"], "unrecoverable")

    def test_max_retries_exceeded(self) -> None:
        """Test that changes exceeding max retries preserve actual error info"""
        from posthog.tasks.process_scheduled_changes import MAX_RETRY_ATTEMPTS

        feature_flag = FeatureFlag.objects.create(
            name="Test Flag",
            key="test-max-retries",
            active=False,
            filters={"groups": []},
            team=self.team,
            created_by=self.user,
        )

        # Create a scheduled change that's one failure away from limit
        scheduled_change = ScheduledChange.objects.create(
            team=self.team,
            record_id=feature_flag.id,
            model_name="FeatureFlag",
            payload={"operation": "update_status", "value": True},
            scheduled_at=(datetime.now(UTC) - timedelta(seconds=30)),
            created_by=self.user,
            failure_count=MAX_RETRY_ATTEMPTS - 1,  # One away from limit
        )

        # Mock the dispatcher to raise a recoverable error that will hit the limit
        with (
            patch.object(FeatureFlag, "scheduled_changes_dispatcher") as mock_dispatcher,
            patch("posthog.tasks.process_scheduled_changes.capture_exception") as mock_capture,
        ):
            from django.db import OperationalError

            mock_dispatcher.side_effect = OperationalError("Database connection lost")

            # Process the scheduled change - should hit max retry limit
            process_scheduled_changes()

            # Retry-exhausted errors are still genuinely unexpected (recoverable), so they
            # must keep reaching error tracking even on the final, non-retrying attempt
            mock_capture.assert_called_once()

        # Refresh the scheduled change from database
        updated_scheduled_change = ScheduledChange.objects.get(id=scheduled_change.id)

        # Verify that it's marked as permanently failed due to retry limit
        self.assertIsNotNone(updated_scheduled_change.executed_at)
        self.assertIsNotNone(updated_scheduled_change.failure_reason)
        self.assertEqual(updated_scheduled_change.failure_count, MAX_RETRY_ATTEMPTS)

        # Parse failure reason to verify actual error info is preserved
        failure_reason = updated_scheduled_change.failure_reason
        assert failure_reason is not None  # For mypy type narrowing
        failure_data = json.loads(failure_reason)

        # Should contain the actual error details, not just "max retries exceeded"
        self.assertEqual(failure_data["error"], "Database connection lost")
        self.assertEqual(failure_data["error_type"], "OperationalError")
        self.assertEqual(failure_data["error_classification"], "recoverable")
        self.assertFalse(failure_data["will_retry"])  # Won't retry due to limit
        self.assertTrue(failure_data["retry_exhausted"])  # Indicates limit reached
        self.assertEqual(failure_data["retry_count"], MAX_RETRY_ATTEMPTS)
        self.assertEqual(failure_data["max_retries"], MAX_RETRY_ATTEMPTS)

    def test_schedule_feature_flag_update_variants(self) -> None:
        """Test that scheduled update_variants operation correctly updates variants and payloads"""
        # Create initial variants
        initial_variants = [
            {
                "key": "control",
                "name": "Control",
                "rollout_percentage": 50,
            },
            {
                "key": "test",
                "name": "Test",
                "rollout_percentage": 50,
            },
        ]

        # Create initial payloads (key-based format for serializer validation)
        initial_payloads = {
            "control": {"message": "control message"},
            "test": {"message": "test message"},
        }

        feature_flag = FeatureFlag.objects.create(
            name="Variant Flag",
            key="variant-flag",
            active=True,
            filters={
                "groups": [],
                "multivariate": {"variants": initial_variants},
                "payloads": initial_payloads,
            },
            team=self.team,
            created_by=self.user,
        )

        # Create new variants configuration
        new_variants = [
            {
                "key": "control",
                "name": "Control Updated",
                "rollout_percentage": 30,
            },
            {
                "key": "test",
                "name": "Test Updated",
                "rollout_percentage": 40,
            },
            {
                "key": "new-variant",
                "name": "New Variant",
                "rollout_percentage": 30,
            },
        ]

        # Create new payloads (key-based format for serializer validation)
        new_payloads = {
            "control": {"message": "updated control message"},
            "test": {"message": "updated test message"},
            "new-variant": {"message": "new variant message"},
        }

        payload = {
            "operation": "update_variants",
            "value": {
                "variants": new_variants,
                "payloads": new_payloads,
            },
        }

        ScheduledChange.objects.create(
            team=self.team,
            record_id=feature_flag.id,
            model_name="FeatureFlag",
            payload=payload,
            scheduled_at=(datetime.now(UTC) - timedelta(seconds=30)),
            created_by=self.user,
        )

        process_scheduled_changes()

        # Verify the flag was updated
        updated_flag = FeatureFlag.objects.get(key="variant-flag")

        # Check that variants were updated
        self.assertEqual(len(updated_flag.filters["multivariate"]["variants"]), 3)
        self.assertEqual(updated_flag.filters["multivariate"]["variants"], new_variants)

        # Check that payloads were updated (object values are normalized to JSON strings)
        self.assertEqual(
            updated_flag.filters["payloads"],
            {k: json.dumps(v) if isinstance(v, dict) else v for k, v in new_payloads.items()},
        )

        # Verify other filter properties were preserved
        self.assertEqual(updated_flag.filters["groups"], [])
        self.assertTrue(updated_flag.active)

    def test_schedule_feature_flag_update_variants_preserve_other_filters(self) -> None:
        """Test that update_variants preserves existing release conditions and other filter properties"""
        # Create initial setup with release conditions
        initial_variants = [
            {"key": "control", "name": "Control", "rollout_percentage": 50},
            {"key": "test", "name": "Test", "rollout_percentage": 50},
        ]

        existing_release_condition = {
            "variant": None,
            "properties": [{"key": "$browser", "type": "person", "value": ["Chrome"], "operator": "exact"}],
            "rollout_percentage": 75,
            "aggregation_group_type_index": None,
        }

        feature_flag = FeatureFlag.objects.create(
            name="Complex Variant Flag",
            key="complex-variant-flag",
            active=True,
            filters={
                "groups": [existing_release_condition],
                "multivariate": {"variants": initial_variants},
                "payloads": {"control": {"msg": "control"}, "test": {"msg": "test"}},
            },
            team=self.team,
            created_by=self.user,
        )

        # Update only variants, not release conditions
        new_variants = [
            {"key": "control", "name": "Control V2", "rollout_percentage": 60},
            {"key": "test", "name": "Test V2", "rollout_percentage": 40},
        ]

        new_payloads = {
            "control": {"msg": "control v2"},
            "test": {"msg": "test v2"},
        }

        payload = {
            "operation": "update_variants",
            "value": {
                "variants": new_variants,
                "payloads": new_payloads,
            },
        }

        ScheduledChange.objects.create(
            team=self.team,
            record_id=feature_flag.id,
            model_name="FeatureFlag",
            payload=payload,
            scheduled_at=(datetime.now(UTC) - timedelta(seconds=30)),
            created_by=self.user,
        )

        process_scheduled_changes()

        # Verify the flag was updated
        updated_flag = FeatureFlag.objects.get(key="complex-variant-flag")

        # Check that variants were updated
        self.assertEqual(updated_flag.filters["multivariate"]["variants"], new_variants)
        # Object payloads are normalized to JSON strings
        self.assertEqual(
            updated_flag.filters["payloads"],
            {k: json.dumps(v) if isinstance(v, dict) else v for k, v in new_payloads.items()},
        )

        # Check that existing release conditions were preserved
        self.assertEqual(len(updated_flag.filters["groups"]), 1)
        self.assertEqual(updated_flag.filters["groups"][0], existing_release_condition)

    def test_schedule_feature_flag_update_variants_empty_variants_with_payloads(self) -> None:
        """Test that update_variants works correctly when clearing variants but having old payloads"""
        # Create initial setup with variants and payloads
        initial_variants = [
            {"key": "control", "name": "Control", "rollout_percentage": 50},
            {"key": "test", "name": "Test", "rollout_percentage": 50},
        ]

        feature_flag = FeatureFlag.objects.create(
            name="Test Variant Flag",
            key="test-variant-flag",
            active=True,
            filters={
                "groups": [],
                "multivariate": {"variants": initial_variants},
                "payloads": {"control": {"msg": "control"}, "test": {"msg": "test"}},
            },
            team=self.team,
            created_by=self.user,
        )

        # Clear variants and payloads (this was causing the validation error)
        payload = {
            "operation": "update_variants",
            "value": {
                "variants": [],  # Empty variants
                "payloads": {},  # Empty payloads
            },
        }

        ScheduledChange.objects.create(
            team=self.team,
            record_id=feature_flag.id,
            model_name="FeatureFlag",
            payload=payload,
            scheduled_at=(datetime.now(UTC) - timedelta(seconds=30)),
            created_by=self.user,
        )

        process_scheduled_changes()

        # Verify the flag was updated correctly
        updated_flag = FeatureFlag.objects.get(key="test-variant-flag")

        # Clearing variants stores the canonical boolean shape (multivariate: null), not
        # the invalid {"variants": []} the filters serializer rejects (#50084).
        self.assertIsNone(updated_flag.filters["multivariate"])
        self.assertEqual(updated_flag.filters["payloads"], {})

    def test_schedule_feature_flag_update_variants_with_mismatched_payload_keys_fails(self) -> None:
        """Test that update_variants fails validation when payload keys don't match variant keys"""
        initial_variants = [
            {"key": "control", "name": "Control", "rollout_percentage": 50},
            {"key": "test", "name": "Test", "rollout_percentage": 50},
        ]

        feature_flag = FeatureFlag.objects.create(
            name="Mismatched Payload Flag",
            key="mismatched-payload-flag",
            active=True,
            filters={
                "groups": [],
                "multivariate": {"variants": initial_variants},
                "payloads": {"control": {"msg": "control"}, "test": {"msg": "test"}},
            },
            team=self.team,
            created_by=self.user,
        )

        new_variants = [
            {"key": "orange", "name": "a", "rollout_percentage": 40},
            {"key": "apples", "name": "b", "rollout_percentage": 25},
            {"key": "test", "name": "c", "rollout_percentage": 5},
            {"key": "variant", "name": "d", "rollout_percentage": 30},
        ]

        mismatched_payloads = {
            "0": '{"value": 1}',
            "1": '{"value": 2}',
            "2": '{"value": 35}',
            "3": '{"value": 5}',
        }

        payload = {
            "operation": "update_variants",
            "value": {
                "variants": new_variants,
                "payloads": mismatched_payloads,
            },
        }

        scheduled_change = ScheduledChange.objects.create(
            team=self.team,
            record_id=feature_flag.id,
            model_name="FeatureFlag",
            payload=payload,
            scheduled_at=(datetime.now(UTC) - timedelta(seconds=30)),
            created_by=self.user,
        )

        process_scheduled_changes()

        updated_flag = FeatureFlag.objects.get(key="mismatched-payload-flag")

        self.assertEqual(len(updated_flag.filters["multivariate"]["variants"]), 2)
        self.assertEqual(updated_flag.filters["multivariate"]["variants"], initial_variants)

        updated_scheduled_change = ScheduledChange.objects.get(id=scheduled_change.id)
        self.assertIsNotNone(updated_scheduled_change.failure_reason)
        self.assertEqual(updated_scheduled_change.failure_count, 1)

    def test_scheduled_changes_dispatcher_validates_variant_rollout_percentages(self) -> None:
        """Test that scheduled_changes_dispatcher validates variants before attempting update"""
        # Create initial feature flag with valid variants
        initial_variants = [
            {"key": "control", "name": "Control", "rollout_percentage": 50},
            {"key": "test", "name": "Test", "rollout_percentage": 50},
        ]

        feature_flag = FeatureFlag.objects.create(
            name="Test Flag",
            key="test-validation-flag",
            active=True,
            filters={
                "groups": [],
                "multivariate": {"variants": initial_variants},
                "payloads": {"control": {"msg": "control"}, "test": {"msg": "test"}},
            },
            team=self.team,
            created_by=self.user,
        )

        # Create payload with invalid variants (rollout percentages sum to 95, not 100)
        invalid_payload = {
            "operation": "update_variants",
            "value": {
                "variants": [
                    {"key": "control", "name": "Control", "rollout_percentage": 45},
                    {"key": "test", "name": "Test", "rollout_percentage": 50},
                ],
                "payloads": {"control": {"msg": "control"}, "test": {"msg": "test"}},
            },
        }

        # This should raise a validation exception from scheduled_changes_dispatcher method
        with self.assertRaises(ValueError) as context:
            feature_flag.scheduled_changes_dispatcher(invalid_payload, self.user)

        # Verify it's our specific validation error message
        self.assertIn("Invalid variant rollout percentages", str(context.exception))

        # Verify the flag was not modified
        feature_flag.refresh_from_db()
        self.assertEqual(feature_flag.filters["multivariate"]["variants"], initial_variants)

    def test_scheduled_changes_dispatcher_allows_valid_variant_rollout_percentages(self) -> None:
        """Test that scheduled_changes_dispatcher allows valid variants that sum to 100"""
        # Create initial feature flag with valid variants
        initial_variants = [
            {"key": "control", "name": "Control", "rollout_percentage": 50},
            {"key": "test", "name": "Test", "rollout_percentage": 50},
        ]

        feature_flag = FeatureFlag.objects.create(
            name="Test Flag Valid",
            key="test-validation-flag-valid",
            active=True,
            filters={
                "groups": [],
                "multivariate": {"variants": initial_variants},
                "payloads": {"control": {"msg": "control"}, "test": {"msg": "test"}},
            },
            team=self.team,
            created_by=self.user,
        )

        # Create payload with valid variants (rollout percentages sum to 100)
        valid_variants = [
            {"key": "control", "name": "Control Updated", "rollout_percentage": 30},
            {"key": "test", "name": "Test Updated", "rollout_percentage": 40},
            {"key": "new", "name": "New Variant", "rollout_percentage": 30},
        ]

        valid_payload = {
            "operation": "update_variants",
            "value": {
                "variants": valid_variants,
                "payloads": {"control": {"msg": "control"}, "test": {"msg": "test"}, "new": {"msg": "new"}},
            },
        }

        # This should not raise any exception
        feature_flag.scheduled_changes_dispatcher(valid_payload, self.user)

        # Verify the flag was updated correctly
        feature_flag.refresh_from_db()
        self.assertEqual(feature_flag.filters["multivariate"]["variants"], valid_variants)

    def test_scheduled_changes_dispatcher_allows_empty_variants(self) -> None:
        """Test that scheduled_changes_dispatcher allows empty variants (converting multivariate to boolean flag)"""
        # Create initial feature flag with variants
        initial_variants = [
            {"key": "control", "name": "Control", "rollout_percentage": 50},
            {"key": "test", "name": "Test", "rollout_percentage": 50},
        ]

        feature_flag = FeatureFlag.objects.create(
            name="Test Flag Empty",
            key="test-validation-flag-empty",
            active=True,
            filters={
                "groups": [],
                "multivariate": {"variants": initial_variants},
                "payloads": {"control": {"msg": "control"}, "test": {"msg": "test"}},
            },
            team=self.team,
            created_by=self.user,
        )

        # Create payload with empty variants
        empty_payload = {
            "operation": "update_variants",
            "value": {
                "variants": [],
                "payloads": {},
            },
        }

        # This should not raise any exception (empty variants should be allowed)
        feature_flag.scheduled_changes_dispatcher(empty_payload, self.user)

        # Verify clearing variants stored the canonical boolean shape (multivariate: null)
        # and dropped the now-orphaned payloads
        feature_flag.refresh_from_db()
        self.assertIsNone(feature_flag.filters["multivariate"])
        self.assertEqual(feature_flag.filters["payloads"], {})

    def test_scheduled_changes_dispatcher_validates_payload_keys_match_variants(self) -> None:
        """Test that scheduled_changes_dispatcher validates that payload keys match variant keys"""
        # Create initial feature flag with valid variants
        initial_variants = [
            {"key": "control", "name": "Control", "rollout_percentage": 50},
            {"key": "test", "name": "Test", "rollout_percentage": 50},
        ]

        feature_flag = FeatureFlag.objects.create(
            name="Test Flag Payload",
            key="test-validation-flag-payload",
            active=True,
            filters={
                "groups": [],
                "multivariate": {"variants": initial_variants},
                "payloads": {"control": {"msg": "control"}, "test": {"msg": "test"}},
            },
            team=self.team,
            created_by=self.user,
        )

        # Create payload with mismatched payload keys (payloads don't match variant keys)
        mismatched_variants = [
            {"key": "control", "name": "Control", "rollout_percentage": 30},
            {"key": "test", "name": "Test", "rollout_percentage": 70},
        ]

        mismatched_payloads = {
            "wrong_key": {"msg": "control"},  # This key doesn't match any variant
            "another_wrong_key": {"msg": "test"},  # This key doesn't match any variant
        }

        invalid_payload = {
            "operation": "update_variants",
            "value": {
                "variants": mismatched_variants,
                "payloads": mismatched_payloads,
            },
        }

        # This should raise a validation exception from scheduled_changes_dispatcher method
        with self.assertRaises(ValueError) as context:
            feature_flag.scheduled_changes_dispatcher(invalid_payload, self.user)

        # Verify it's our specific validation error message
        self.assertIn("don't match variant keys", str(context.exception))

        # Verify the flag was not modified
        feature_flag.refresh_from_db()
        self.assertEqual(feature_flag.filters["multivariate"]["variants"], initial_variants)

    def test_scheduled_changes_dispatcher_allows_variants_with_empty_payloads(self) -> None:
        """Test that scheduled_changes_dispatcher allows variants with empty payloads (multivariate flag without payloads)"""
        # Create initial feature flag
        initial_variants = [
            {"key": "control", "name": "Control", "rollout_percentage": 50},
            {"key": "test", "name": "Test", "rollout_percentage": 50},
        ]

        feature_flag = FeatureFlag.objects.create(
            name="Test Flag No Payloads",
            key="test-validation-flag-no-payloads",
            active=True,
            filters={
                "groups": [],
                "multivariate": {"variants": initial_variants},
                "payloads": {},
            },
            team=self.team,
            created_by=self.user,
        )

        # Create payload with variants but no payloads (this should be allowed)
        new_variants = [
            {"key": "control", "name": "Control Updated", "rollout_percentage": 40},
            {"key": "test", "name": "Test Updated", "rollout_percentage": 60},
        ]

        valid_payload = {
            "operation": "update_variants",
            "value": {
                "variants": new_variants,
                "payloads": {},  # Empty payloads should be allowed
            },
        }

        # This should not raise any exception
        feature_flag.scheduled_changes_dispatcher(valid_payload, self.user)

        # Verify the flag was updated correctly
        feature_flag.refresh_from_db()
        self.assertEqual(feature_flag.filters["multivariate"]["variants"], new_variants)
        self.assertEqual(feature_flag.filters["payloads"], {})

    def test_scheduled_changes_dispatcher_validates_variant_keys_exist(self) -> None:
        """Test that scheduled_changes_dispatcher validates that variants have keys"""
        feature_flag = FeatureFlag.objects.create(
            name="Test Flag Invalid Keys",
            key="test-validation-flag-invalid-keys",
            active=True,
            filters={"groups": [], "multivariate": {"variants": []}, "payloads": {}},
            team=self.team,
            created_by=self.user,
        )

        # Create payload with variants that have missing or None keys
        invalid_variants = [
            {"name": "Control", "rollout_percentage": 50},  # Missing 'key' field
            {"key": None, "name": "Test", "rollout_percentage": 50},  # None key
        ]

        invalid_payload = {
            "operation": "update_variants",
            "value": {
                "variants": invalid_variants,
                "payloads": {"control": {"msg": "control"}},
            },
        }

        # This should raise a validation exception
        with self.assertRaises(ValueError) as context:
            feature_flag.scheduled_changes_dispatcher(invalid_payload, self.user)

        # Verify it mentions the issue with variant keys
        error_message = str(context.exception)
        self.assertIn("don't match variant keys", error_message)

    def test_failure_reason_truncation_preserves_json(self) -> None:
        """Test that failure reason truncation preserves valid JSON structure"""
        # This test verifies the simple truncation approach used in process_scheduled_changes
        failure_context = {
            "error": "A" * 500,  # Very long error message
            "error_type": "ValidationError",
            "error_classification": "unrecoverable",
        }

        # Apply the same logic as in process_scheduled_changes
        error_msg = str(failure_context.get("error", ""))
        if len(error_msg) > 300:
            failure_context["error"] = error_msg[:297] + "..."

        failure_json = json.dumps(failure_context)
        final_result = failure_json[:400] if len(failure_json) > 400 else failure_json

        # Verify it's valid JSON
        parsed = json.loads(final_result)
        self.assertIsInstance(parsed, dict)

        # Verify important fields are preserved
        self.assertEqual(parsed["error_type"], "ValidationError")
        self.assertEqual(parsed["error_classification"], "unrecoverable")

        # Verify error message is truncated with ellipsis
        self.assertTrue(parsed["error"].endswith("..."))

    def test_cannot_schedule_change_in_past(self) -> None:
        """Test that scheduled changes set in the past are executed immediately when processed"""
        feature_flag = FeatureFlag.objects.create(
            name="Past Test Flag",
            key="past-test-flag",
            active=False,
            filters={"groups": []},
            team=self.team,
            created_by=self.user,
        )

        # Schedule a change 2 hours in the past
        past_time = datetime.now(UTC) - timedelta(hours=2)

        scheduled_change = ScheduledChange.objects.create(
            team=self.team,
            record_id=feature_flag.id,
            model_name="FeatureFlag",
            payload={"operation": "update_status", "value": True},
            scheduled_at=past_time,
            created_by=self.user,
        )

        # Verify the change hasn't been executed yet
        self.assertIsNone(scheduled_change.executed_at)
        updated_flag = FeatureFlag.objects.get(key="past-test-flag")
        self.assertEqual(updated_flag.active, False)

        # Process scheduled changes
        process_scheduled_changes()

        # Verify the change was executed immediately
        updated_scheduled_change = ScheduledChange.objects.get(id=scheduled_change.id)
        self.assertIsNotNone(updated_scheduled_change.executed_at)
        self.assertIsNone(updated_scheduled_change.failure_reason)
        self.assertEqual(updated_scheduled_change.failure_count, 0)

        # Verify the flag was updated
        updated_flag = FeatureFlag.objects.get(key="past-test-flag")
        self.assertEqual(updated_flag.active, True)

    @freeze_time("2024-01-15T09:00:00Z")
    def test_recurring_schedule_computes_next_weekly_run(self) -> None:
        """Recurring weekly schedule should advance scheduled_at by 1 week, not mark as executed."""
        feature_flag = FeatureFlag.objects.create(
            name="Recurring Flag",
            key="recurring-weekly-flag",
            active=True,
            filters={"groups": []},
            team=self.team,
            created_by=self.user,
        )

        scheduled_change = ScheduledChange.objects.create(
            team=self.team,
            record_id=feature_flag.id,
            model_name="FeatureFlag",
            payload={"operation": "update_status", "value": False},
            scheduled_at=datetime(2024, 1, 15, 9, 0, tzinfo=UTC),
            is_recurring=True,
            recurrence_interval="weekly",
        )

        process_scheduled_changes()

        scheduled_change.refresh_from_db()
        # Should NOT be marked as executed
        self.assertIsNone(scheduled_change.executed_at)
        # Should be scheduled for next week
        self.assertEqual(scheduled_change.scheduled_at, datetime(2024, 1, 22, 9, 0, tzinfo=UTC))
        # Flag should be disabled
        feature_flag.refresh_from_db()
        self.assertEqual(feature_flag.active, False)

    @freeze_time("2024-01-15T09:00:00Z")
    def test_recurring_schedule_computes_next_daily_run(self) -> None:
        """Recurring daily schedule should advance scheduled_at by 1 day."""
        feature_flag = FeatureFlag.objects.create(
            name="Recurring Daily Flag",
            key="recurring-daily-flag",
            active=False,
            filters={"groups": []},
            team=self.team,
            created_by=self.user,
        )

        scheduled_change = ScheduledChange.objects.create(
            team=self.team,
            record_id=feature_flag.id,
            model_name="FeatureFlag",
            payload={"operation": "update_status", "value": True},
            scheduled_at=datetime(2024, 1, 15, 9, 0, tzinfo=UTC),
            is_recurring=True,
            recurrence_interval="daily",
        )

        process_scheduled_changes()

        scheduled_change.refresh_from_db()
        self.assertIsNone(scheduled_change.executed_at)
        self.assertEqual(scheduled_change.scheduled_at, datetime(2024, 1, 16, 9, 0, tzinfo=UTC))

    @freeze_time("2024-01-15T09:00:00Z")
    def test_recurring_schedule_computes_next_monthly_run(self) -> None:
        """Recurring monthly schedule should advance scheduled_at by 1 month."""
        feature_flag = FeatureFlag.objects.create(
            name="Recurring Monthly Flag",
            key="recurring-monthly-flag",
            active=True,
            filters={"groups": []},
            team=self.team,
            created_by=self.user,
        )

        scheduled_change = ScheduledChange.objects.create(
            team=self.team,
            record_id=feature_flag.id,
            model_name="FeatureFlag",
            payload={"operation": "update_status", "value": False},
            scheduled_at=datetime(2024, 1, 15, 9, 0, tzinfo=UTC),
            is_recurring=True,
            recurrence_interval="monthly",
        )

        process_scheduled_changes()

        scheduled_change.refresh_from_db()
        self.assertIsNone(scheduled_change.executed_at)
        self.assertEqual(scheduled_change.scheduled_at, datetime(2024, 2, 15, 9, 0, tzinfo=UTC))

    @freeze_time("2024-01-15T09:00:00Z")
    def test_non_recurring_schedule_still_marks_executed(self) -> None:
        """Non-recurring schedules should continue to mark executed_at (existing behavior)."""
        feature_flag = FeatureFlag.objects.create(
            name="Non-Recurring Flag",
            key="non-recurring-flag",
            active=True,
            filters={"groups": []},
            team=self.team,
            created_by=self.user,
        )

        scheduled_change = ScheduledChange.objects.create(
            team=self.team,
            record_id=feature_flag.id,
            model_name="FeatureFlag",
            payload={"operation": "update_status", "value": False},
            scheduled_at=datetime(2024, 1, 15, 9, 0, tzinfo=UTC),
            is_recurring=False,
        )

        process_scheduled_changes()

        scheduled_change.refresh_from_db()
        # Should be marked as executed
        self.assertIsNotNone(scheduled_change.executed_at)

    @freeze_time("2024-01-15T09:00:00Z")
    def test_paused_recurring_schedule_does_not_execute(self) -> None:
        """Paused recurring schedules (is_recurring=False with interval) should be skipped."""
        feature_flag = FeatureFlag.objects.create(
            name="Paused Flag",
            key="paused-flag",
            active=True,
            filters={"groups": []},
            team=self.team,
            created_by=self.user,
        )

        scheduled_change = ScheduledChange.objects.create(
            team=self.team,
            record_id=feature_flag.id,
            model_name="FeatureFlag",
            payload={"operation": "update_status", "value": False},
            scheduled_at=datetime(2024, 1, 15, 9, 0, tzinfo=UTC),
            is_recurring=False,  # Paused
            recurrence_interval="daily",  # But has interval preserved
        )

        process_scheduled_changes()

        scheduled_change.refresh_from_db()
        feature_flag.refresh_from_db()

        # Should NOT have executed
        self.assertIsNone(scheduled_change.executed_at)
        self.assertIsNone(scheduled_change.last_executed_at)
        self.assertEqual(feature_flag.active, True)  # Unchanged

    @freeze_time("2024-01-15T09:00:00Z")
    def test_recurring_schedule_executes_multiple_times(self) -> None:
        """Recurring schedule should execute each time its scheduled_at is due."""
        feature_flag = FeatureFlag.objects.create(
            name="Multi-Execute Flag",
            key="multi-execute-flag",
            active=True,
            filters={"groups": []},
            team=self.team,
            created_by=self.user,
        )

        scheduled_change = ScheduledChange.objects.create(
            team=self.team,
            record_id=feature_flag.id,
            model_name="FeatureFlag",
            payload={"operation": "update_status", "value": False},
            scheduled_at=datetime(2024, 1, 15, 9, 0, tzinfo=UTC),
            is_recurring=True,
            recurrence_interval="daily",
        )

        # First execution
        process_scheduled_changes()
        scheduled_change.refresh_from_db()
        feature_flag.refresh_from_db()
        self.assertEqual(feature_flag.active, False)
        self.assertEqual(scheduled_change.scheduled_at, datetime(2024, 1, 16, 9, 0, tzinfo=UTC))

        # Manually enable the flag (simulating manual override)
        feature_flag.active = True
        feature_flag.save()

        # Second execution (next day)
        with freeze_time("2024-01-16T09:00:00Z"):
            process_scheduled_changes()
            scheduled_change.refresh_from_db()
            feature_flag.refresh_from_db()
            # Schedule corrects the manual override
            self.assertEqual(feature_flag.active, False)
            self.assertEqual(scheduled_change.scheduled_at, datetime(2024, 1, 17, 9, 0, tzinfo=UTC))

    @freeze_time("2024-01-15T09:00:00Z")
    def test_recurring_schedule_computes_next_yearly_run(self) -> None:
        """Recurring yearly schedule should advance scheduled_at by 1 year."""
        feature_flag = FeatureFlag.objects.create(
            name="Recurring Yearly Flag",
            key="recurring-yearly-flag",
            active=True,
            filters={"groups": []},
            team=self.team,
            created_by=self.user,
        )

        scheduled_change = ScheduledChange.objects.create(
            team=self.team,
            record_id=feature_flag.id,
            model_name="FeatureFlag",
            payload={"operation": "update_status", "value": False},
            scheduled_at=datetime(2024, 1, 15, 9, 0, tzinfo=UTC),
            is_recurring=True,
            recurrence_interval="yearly",
        )

        process_scheduled_changes()

        scheduled_change.refresh_from_db()
        self.assertIsNone(scheduled_change.executed_at)
        self.assertEqual(scheduled_change.scheduled_at, datetime(2025, 1, 15, 9, 0, tzinfo=UTC))
        feature_flag.refresh_from_db()
        self.assertEqual(feature_flag.active, False)

    @freeze_time("2024-02-29T09:00:00Z")
    def test_recurring_yearly_schedule_handles_leap_year(self) -> None:
        """Yearly schedule on Feb 29 should advance to Feb 28 in non-leap years."""
        feature_flag = FeatureFlag.objects.create(
            name="Leap Year Flag",
            key="leap-year-flag",
            active=True,
            filters={"groups": []},
            team=self.team,
            created_by=self.user,
        )

        scheduled_change = ScheduledChange.objects.create(
            team=self.team,
            record_id=feature_flag.id,
            model_name="FeatureFlag",
            payload={"operation": "update_status", "value": False},
            scheduled_at=datetime(2024, 2, 29, 9, 0, tzinfo=UTC),
            is_recurring=True,
            recurrence_interval="yearly",
        )

        process_scheduled_changes()

        scheduled_change.refresh_from_db()
        self.assertIsNone(scheduled_change.executed_at)
        # 2025 is not a leap year, so Feb 29 becomes Feb 28
        self.assertEqual(scheduled_change.scheduled_at, datetime(2025, 2, 28, 9, 0, tzinfo=UTC))
        feature_flag.refresh_from_db()
        self.assertEqual(feature_flag.active, False)

    def test_scheduled_change_cannot_modify_another_teams_feature_flag(self) -> None:
        """A scheduled change whose record_id points to a different team's flag must fail."""
        other_org = Organization.objects.create(name="Other Org")
        other_team = Team.objects.create(organization=other_org, name="Other Team")

        victim_flag = FeatureFlag.objects.create(
            name="Victim Flag",
            key="victim-flag",
            active=True,
            filters={"groups": []},
            team=other_team,
            created_by=self.user,
        )

        # Simulate a scheduled change that targets a flag belonging to a different team
        scheduled_change = ScheduledChange.objects.create(
            team=self.team,
            record_id=victim_flag.id,
            model_name="FeatureFlag",
            payload={"operation": "update_status", "value": False},
            scheduled_at=(datetime.now(UTC) - timedelta(seconds=30)),
            created_by=self.user,
        )

        process_scheduled_changes()

        # The victim flag must remain unchanged
        victim_flag.refresh_from_db()
        self.assertTrue(victim_flag.active)

        # The scheduled change should be permanently failed (unrecoverable, no retry)
        scheduled_change.refresh_from_db()
        self.assertIsNotNone(scheduled_change.executed_at)
        self.assertIsNotNone(scheduled_change.failure_reason)
        self.assertEqual(scheduled_change.failure_count, 1)

        assert scheduled_change.failure_reason is not None
        failure_data = json.loads(scheduled_change.failure_reason)
        self.assertFalse(failure_data["will_retry"])
        self.assertEqual(failure_data["error_classification"], "unrecoverable")

    @freeze_time("2024-01-15T09:00:00Z")
    def test_cron_recurring_schedule_executes_and_advances(self) -> None:
        feature_flag = FeatureFlag.objects.create(
            name="Cron Flag",
            key="cron-flag",
            active=False,
            filters={"groups": []},
            team=self.team,
            created_by=self.user,
        )

        # "At 09:00 on weekdays" — current time is Monday 2024-01-15 09:00
        scheduled_change = ScheduledChange.objects.create(
            team=self.team,
            record_id=feature_flag.id,
            model_name="FeatureFlag",
            payload={"operation": "update_status", "value": True},
            scheduled_at=datetime(2024, 1, 15, 9, 0, tzinfo=UTC),
            is_recurring=True,
            cron_expression="0 9 * * 1-5",
        )

        process_scheduled_changes()

        feature_flag.refresh_from_db()
        self.assertTrue(feature_flag.active)

        scheduled_change.refresh_from_db()
        self.assertIsNone(scheduled_change.executed_at)
        # Next weekday at 09:00 is Tuesday 2024-01-16
        self.assertEqual(scheduled_change.scheduled_at, datetime(2024, 1, 16, 9, 0, tzinfo=UTC))

    @freeze_time("2024-01-15T09:00:00Z")
    def test_cron_recurring_schedule_paused_is_skipped(self) -> None:
        feature_flag = FeatureFlag.objects.create(
            name="Cron Paused Flag",
            key="cron-paused-flag",
            active=False,
            filters={"groups": []},
            team=self.team,
            created_by=self.user,
        )

        ScheduledChange.objects.create(
            team=self.team,
            record_id=feature_flag.id,
            model_name="FeatureFlag",
            payload={"operation": "update_status", "value": True},
            scheduled_at=datetime(2024, 1, 15, 9, 0, tzinfo=UTC),
            is_recurring=False,
            cron_expression="0 9 * * 1-5",
        )

        process_scheduled_changes()

        feature_flag.refresh_from_db()
        self.assertFalse(feature_flag.active)

    @freeze_time("2024-01-19T09:00:00Z")
    def test_cron_recurring_schedule_skips_missed_runs(self) -> None:
        feature_flag = FeatureFlag.objects.create(
            name="Cron Delayed Flag",
            key="cron-delayed-flag",
            active=False,
            filters={"groups": []},
            team=self.team,
            created_by=self.user,
        )

        # Scheduled for Monday Jan 15, but processing happens Friday Jan 19
        scheduled_change = ScheduledChange.objects.create(
            team=self.team,
            record_id=feature_flag.id,
            model_name="FeatureFlag",
            payload={"operation": "update_status", "value": True},
            scheduled_at=datetime(2024, 1, 15, 9, 0, tzinfo=UTC),
            is_recurring=True,
            cron_expression="0 9 * * 1-5",
        )

        process_scheduled_changes()

        scheduled_change.refresh_from_db()
        self.assertIsNone(scheduled_change.executed_at)
        # Should skip past Tue/Wed/Thu/Fri and land on Monday Jan 22
        self.assertEqual(scheduled_change.scheduled_at, datetime(2024, 1, 22, 9, 0, tzinfo=UTC))

    @freeze_time("2024-01-16T09:00:00Z")
    def test_cron_recurring_schedule_respects_end_date(self) -> None:
        feature_flag = FeatureFlag.objects.create(
            name="Cron End Flag",
            key="cron-end-flag",
            active=False,
            filters={"groups": []},
            team=self.team,
            created_by=self.user,
        )

        scheduled_change = ScheduledChange.objects.create(
            team=self.team,
            record_id=feature_flag.id,
            model_name="FeatureFlag",
            payload={"operation": "update_status", "value": True},
            scheduled_at=datetime(2024, 1, 16, 9, 0, tzinfo=UTC),
            is_recurring=True,
            cron_expression="0 9 * * 1-5",
            end_date=datetime(2024, 1, 16, 23, 59, tzinfo=UTC),
        )

        process_scheduled_changes()

        feature_flag.refresh_from_db()
        self.assertTrue(feature_flag.active)

        scheduled_change.refresh_from_db()
        # Next cron match (Jan 17) is past end_date's day, so schedule is completed
        self.assertIsNotNone(scheduled_change.executed_at)

    @parameterized.expand(
        [
            # West of UTC: 9am New York (EST, UTC-5) = 14:00 UTC; next weekday match stays
            # at 14:00 UTC rather than drifting to 09:00 UTC.
            (
                "west_of_utc_new_york",
                "2024-01-15T14:00:00Z",
                datetime(2024, 1, 15, 14, 0, tzinfo=UTC),
                "0 9 * * 1-5",
                "America/New_York",
                datetime(2024, 1, 16, 14, 0, tzinfo=UTC),
            ),
            # East of UTC: 9am Tokyo (JST, UTC+9) = 00:00 UTC.
            (
                "east_of_utc_tokyo",
                "2024-01-15T00:00:00Z",
                datetime(2024, 1, 15, 0, 0, tzinfo=UTC),
                "0 9 * * 1-5",
                "Asia/Tokyo",
                datetime(2024, 1, 16, 0, 0, tzinfo=UTC),
            ),
            # Explicit UTC is the identity case — matches the pre-existing NULL semantics.
            (
                "explicit_utc",
                "2024-01-15T09:00:00Z",
                datetime(2024, 1, 15, 9, 0, tzinfo=UTC),
                "0 9 * * 1-5",
                "UTC",
                datetime(2024, 1, 16, 9, 0, tzinfo=UTC),
            ),
            # Legacy rows with timezone=NULL keep firing at the wall-clock moment they
            # always did (UTC interpretation) so no live schedule shifts silently.
            (
                "legacy_null_timezone",
                "2024-01-15T09:00:00Z",
                datetime(2024, 1, 15, 9, 0, tzinfo=UTC),
                "0 9 * * 1-5",
                None,
                datetime(2024, 1, 16, 9, 0, tzinfo=UTC),
            ),
            # Unknown / typo'd timezone falls back to UTC rather than raising and stalling
            # the schedule. Exercises the ZoneInfoNotFoundError branch.
            (
                "invalid_timezone_falls_back_to_utc",
                "2024-01-15T09:00:00Z",
                datetime(2024, 1, 15, 9, 0, tzinfo=UTC),
                "0 9 * * 1-5",
                "Invalid/Timezone",
                datetime(2024, 1, 16, 9, 0, tzinfo=UTC),
            ),
            # US spring-forward: starting from 9am EST on Mar 9, catch-up past the Mar 10
            # transition lands on 9am EDT on Mar 11 = 13:00 UTC (not the stored 14:00 UTC).
            (
                "spring_forward_dst_transition",
                "2024-03-10T14:00:00Z",
                datetime(2024, 3, 9, 14, 0, tzinfo=UTC),
                "0 9 * * *",
                "America/New_York",
                datetime(2024, 3, 11, 13, 0, tzinfo=UTC),
            ),
            # US fall-back: starting from 9am EDT on Nov 2, catch-up past the Nov 3
            # transition lands on 9am EST on Nov 4 = 14:00 UTC (not 13:00 UTC).
            (
                "fall_back_dst_transition",
                "2024-11-04T13:30:00Z",
                datetime(2024, 11, 2, 13, 0, tzinfo=UTC),
                "0 9 * * *",
                "America/New_York",
                datetime(2024, 11, 4, 14, 0, tzinfo=UTC),
            ),
        ]
    )
    def test_cron_recurring_schedule_honors_stored_timezone(
        self,
        name: str,
        frozen_now: str,
        scheduled_at: datetime,
        cron_expression: str,
        tz: str | None,
        expected_next: datetime,
    ) -> None:
        with freeze_time(frozen_now):
            feature_flag = FeatureFlag.objects.create(
                name=f"Flag {name}",
                key=f"flag-{name.replace('_', '-')}",
                active=False,
                filters={"groups": []},
                team=self.team,
                created_by=self.user,
            )

            scheduled_change = ScheduledChange.objects.create(
                team=self.team,
                record_id=feature_flag.id,
                model_name="FeatureFlag",
                payload={"operation": "update_status", "value": True},
                scheduled_at=scheduled_at,
                is_recurring=True,
                cron_expression=cron_expression,
                timezone=tz,
            )

            process_scheduled_changes()

            scheduled_change.refresh_from_db()
            self.assertEqual(scheduled_change.scheduled_at, expected_next)
