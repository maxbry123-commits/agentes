from datetime import UTC, datetime, timedelta
from uuid import uuid4

import pytest
from freezegun import freeze_time
from posthog.test.base import (
    APIBaseTest,
    ClickhouseDestroyTablesMixin,
    ClickhouseTestMixin,
    _create_person,
    flush_persons_and_events,
)
from unittest.mock import MagicMock, patch

from django.test import SimpleTestCase

from parameterized import parameterized

from posthog.clickhouse.client import sync_execute
from posthog.models import Organization, Team
from posthog.models.event.util import create_event
from posthog.ph_client import PH_US_API_KEY
from posthog.tasks.ai_observability_usage_report import (
    AI_OBSERVABILITY_REPORT_TRIGGER_EVENTS,
    AI_OBSERVABILITY_USAGE_EVENT,
    _get_all_ai_observability_reports,
    capture_ai_observability_report,
    get_ai_trace_counts,
    get_all_ai_dimension_breakdowns,
    get_all_ai_metrics,
    get_llm_feedback_survey_metrics,
    get_llm_prompt_fetched_counts,
    get_teams_with_ai_events,
    send_ai_observability_usage_reports,
)
from posthog.utils import get_previous_day


@freeze_time("2022-01-10T00:01:00Z")
class TestAIObservabilityUsageReport(APIBaseTest, ClickhouseTestMixin, ClickhouseDestroyTablesMixin):
    """Tests for AI observability usage reporting functionality."""

    def setUp(self) -> None:
        super().setUp()

        # Stop merges to prevent row collapsing
        sync_execute("SYSTEM STOP MERGES")

    def tearDown(self) -> None:
        sync_execute("SYSTEM START MERGES")
        super().tearDown()

    def _create_ai_events(
        self,
        team: Team,
        distinct_id: str,
        event_type: str,
        count: int,
        properties: dict | None = None,
        timestamp: datetime | None = None,
    ) -> None:
        """Helper to create AI events."""
        if timestamp is None:
            timestamp = datetime.now(UTC) - timedelta(hours=12)

        base_properties = properties or {}

        for _ in range(count):
            create_event(
                event_uuid=uuid4(),
                distinct_id=distinct_id,
                event=event_type,
                properties=base_properties,
                timestamp=timestamp,
                team=team,
            )

        flush_persons_and_events()

    def test_get_all_ai_metrics(self) -> None:
        """Test that we correctly get all AI metrics in a single combined query."""
        distinct_id = str(uuid4())
        _create_person(distinct_ids=[distinct_id], team=self.team)

        period = get_previous_day()

        # Create different AI event types with various properties
        self._create_ai_events(self.team, distinct_id, "$ai_generation", 5)
        self._create_ai_events(self.team, distinct_id, "$ai_embedding", 3)
        self._create_ai_events(self.team, distinct_id, "$ai_span", 10)
        self._create_ai_events(self.team, distinct_id, "$ai_trace", 2)
        self._create_ai_events(self.team, distinct_id, "$ai_metric", 1)
        self._create_ai_events(self.team, distinct_id, "$ai_feedback", 4)
        self._create_ai_events(
            self.team,
            distinct_id,
            "$ai_evaluation",
            3,
            properties={"$ai_evaluation_key_type": "posthog", "$ai_evaluation_runtime": "llm_judge"},
        )
        self._create_ai_events(
            self.team, distinct_id, "$ai_evaluation", 2, properties={"$ai_evaluation_runtime": "hog"}
        )
        self._create_ai_events(
            self.team, distinct_id, "$ai_evaluation", 1, properties={"$ai_evaluation_runtime": "sentiment"}
        )
        self._create_ai_events(self.team, distinct_id, "$ai_trace_summary", 7)
        self._create_ai_events(self.team, distinct_id, "$ai_generation_summary", 12)
        self._create_ai_events(self.team, distinct_id, "$ai_trace_clusters", 2)
        self._create_ai_events(self.team, distinct_id, "$ai_generation_clusters", 3)
        # Create events with cost and token properties
        self._create_ai_events(
            self.team,
            distinct_id,
            "$ai_generation",
            3,
            properties={
                "$ai_total_cost_usd": 0.015,
                "$ai_input_cost_usd": 0.005,
                "$ai_output_cost_usd": 0.010,
                "$ai_request_cost_usd": 0.001,
                "$ai_web_search_cost_usd": 0.002,
                "$ai_input_tokens": 100,
                "$ai_output_tokens": 50,
                "$ai_total_tokens": 150,
                "$ai_reasoning_tokens": 25,
                "$ai_cache_read_input_tokens": 500,
                "$ai_cache_creation_input_tokens": 200,
            },
        )

        # Get team_ids first
        team_ids = get_teams_with_ai_events(period.start, period.end, AI_OBSERVABILITY_REPORT_TRIGGER_EVENTS)

        # Get all metrics in one query
        all_metrics = get_all_ai_metrics(period.start, period.end, team_ids)

        # Verify team is in results
        assert self.team.id in all_metrics
        metrics = all_metrics[self.team.id]

        # Verify event counts
        assert metrics.ai_generation_count == 8  # 5 + 3
        assert metrics.ai_embedding_count == 3
        assert metrics.ai_span_count == 10
        assert metrics.ai_trace_event_count == 2
        assert metrics.ai_metric_count == 1
        assert metrics.ai_feedback_count == 4
        assert metrics.ai_evaluation_count == 6
        assert metrics.ai_llm_judge_evaluation_count == 3
        assert metrics.ai_hog_evaluation_count == 2
        assert metrics.ai_sentiment_evaluation_count == 1
        assert metrics.ai_trace_summary_count == 7
        assert metrics.ai_generation_summary_count == 12
        assert metrics.ai_trace_clusters_count == 2
        assert metrics.ai_generation_clusters_count == 3

        # Verify cost metrics (3 events with costs)
        assert metrics.total_cost == pytest.approx(0.045, rel=1e-6)  # 3 * 0.015
        assert metrics.input_cost == pytest.approx(0.015, rel=1e-6)  # 3 * 0.005
        assert metrics.output_cost == pytest.approx(0.030, rel=1e-6)  # 3 * 0.010
        assert metrics.request_cost == pytest.approx(0.003, rel=1e-6)  # 3 * 0.001
        assert metrics.web_search_cost == pytest.approx(0.006, rel=1e-6)  # 3 * 0.002

        # Verify token metrics (3 events with tokens)
        assert metrics.prompt_tokens == 300  # 3 * 100
        assert metrics.completion_tokens == 150  # 3 * 50
        assert metrics.total_tokens == 450  # 3 * 150
        assert metrics.reasoning_tokens == 75  # 3 * 25
        assert metrics.cache_read_tokens == 1500  # 3 * 500
        assert metrics.cache_creation_tokens == 600  # 3 * 200

    def test_get_ai_trace_counts_counts_distinct_trace_ids(self) -> None:
        distinct_id = str(uuid4())
        _create_person(distinct_ids=[distinct_id], team=self.team)

        period = get_previous_day()

        traced_id = str(uuid4())
        self._create_ai_events(self.team, distinct_id, "$ai_generation", 3, properties={"$ai_trace_id": traced_id})
        self._create_ai_events(self.team, distinct_id, "$ai_span", 2, properties={"$ai_trace_id": traced_id})
        self._create_ai_events(self.team, distinct_id, "$ai_trace", 1, properties={"$ai_trace_id": traced_id})

        # A trace whose SDK integration never emits the root $ai_trace event still counts.
        rootless_id = str(uuid4())
        self._create_ai_events(self.team, distinct_id, "$ai_generation", 2, properties={"$ai_trace_id": rootless_id})

        self._create_ai_events(self.team, distinct_id, "$ai_generation", 1)

        team_ids = get_teams_with_ai_events(period.start, period.end, AI_OBSERVABILITY_REPORT_TRIGGER_EVENTS)

        assert get_ai_trace_counts(period.start, period.end, team_ids)[self.team.id] == 2

        # The root-event count stays available as its own signal, so the two can be compared.
        assert get_all_ai_metrics(period.start, period.end, team_ids)[self.team.id].ai_trace_event_count == 1

    def test_get_all_ai_metrics_cost_anomaly_counts(self) -> None:
        """Test that cost anomaly counts (total, negative, zero) are correctly calculated."""
        distinct_id = str(uuid4())
        _create_person(distinct_ids=[distinct_id], team=self.team)

        period = get_previous_day()

        # Create events with positive cost
        self._create_ai_events(
            self.team,
            distinct_id,
            "$ai_generation",
            3,
            properties={"$ai_total_cost_usd": 0.05},
        )

        # Create events with zero cost
        self._create_ai_events(
            self.team,
            distinct_id,
            "$ai_generation",
            2,
            properties={"$ai_total_cost_usd": 0},
        )

        # Create events with negative cost
        self._create_ai_events(
            self.team,
            distinct_id,
            "$ai_generation",
            4,
            properties={"$ai_total_cost_usd": -0.01},
        )

        # Create events without cost (null)
        self._create_ai_events(
            self.team,
            distinct_id,
            "$ai_generation",
            5,
            properties={},
        )

        team_ids = get_teams_with_ai_events(period.start, period.end, AI_OBSERVABILITY_REPORT_TRIGGER_EVENTS)
        all_metrics = get_all_ai_metrics(period.start, period.end, team_ids)

        assert self.team.id in all_metrics
        metrics = all_metrics[self.team.id]

        assert metrics.ai_generation_count == 14  # 3 + 2 + 4 + 5
        assert metrics.total_cost_count == 9  # 3 + 2 + 4 (events with non-null cost)
        assert metrics.total_cost_negative_count == 4
        assert metrics.total_cost_zero_count == 2
        assert metrics.total_cost == pytest.approx(0.11, rel=1e-6)  # 3*0.05 + 2*0 + 4*(-0.01)

    def test_get_all_ai_metrics_error_count(self) -> None:
        """Test that ai_is_error_count is correctly calculated."""
        distinct_id = str(uuid4())
        _create_person(distinct_ids=[distinct_id], team=self.team)

        period = get_previous_day()

        # Create events with $ai_is_error = true
        self._create_ai_events(
            self.team,
            distinct_id,
            "$ai_generation",
            4,
            properties={"$ai_is_error": "true"},
        )

        # Create events with $ai_is_error = false
        self._create_ai_events(
            self.team,
            distinct_id,
            "$ai_generation",
            3,
            properties={"$ai_is_error": "false"},
        )

        # Create events without $ai_is_error
        self._create_ai_events(
            self.team,
            distinct_id,
            "$ai_generation",
            5,
            properties={},
        )

        team_ids = get_teams_with_ai_events(period.start, period.end, AI_OBSERVABILITY_REPORT_TRIGGER_EVENTS)
        all_metrics = get_all_ai_metrics(period.start, period.end, team_ids)

        assert self.team.id in all_metrics
        metrics = all_metrics[self.team.id]

        assert metrics.ai_generation_count == 12  # 4 + 3 + 5
        assert metrics.ai_is_error_count == 4  # only events with $ai_is_error = 'true'

    def test_get_all_ai_dimension_breakdowns(self) -> None:
        """Test that we correctly get dimension breakdowns using the combined Map-based query."""
        distinct_id = str(uuid4())
        _create_person(distinct_ids=[distinct_id], team=self.team)

        period = get_previous_day()

        # Create AI events with different models and providers
        self._create_ai_events(
            self.team,
            distinct_id,
            "$ai_generation",
            10,
            properties={
                "$ai_model": "gpt-4o-mini",
                "$ai_provider": "openai",
                "$ai_framework": "langchain",
                "$lib": "posthog-python",
            },
        )

        self._create_ai_events(
            self.team,
            distinct_id,
            "$ai_generation",
            5,
            properties={
                "$ai_model": "claude-3-opus",
                "$ai_provider": "anthropic",
                "$lib": "posthog-node",
            },
        )

        self._create_ai_events(
            self.team,
            distinct_id,
            "$ai_embedding",
            3,
            properties={
                "$ai_model": "text-embedding-ada-002",
                "$ai_provider": "openai",
                "$lib": "posthog-python",
            },
        )

        # Get team_ids first
        team_ids = get_teams_with_ai_events(period.start, period.end, AI_OBSERVABILITY_REPORT_TRIGGER_EVENTS)

        # Get dimension breakdowns using the new combined function
        all_breakdowns = get_all_ai_dimension_breakdowns(period.start, period.end, team_ids)

        # Verify team is in results
        assert self.team.id in all_breakdowns
        breakdowns = all_breakdowns[self.team.id]

        # Verify model breakdown
        assert breakdowns.model_breakdown.get("gpt-4o-mini") == 10
        assert breakdowns.model_breakdown.get("claude-3-opus") == 5
        assert breakdowns.model_breakdown.get("text-embedding-ada-002") == 3

        # Verify provider breakdown
        assert breakdowns.provider_breakdown.get("openai") == 13  # 10 + 3
        assert breakdowns.provider_breakdown.get("anthropic") == 5

        # Verify framework breakdown
        assert breakdowns.framework_breakdown.get("langchain") == 10
        assert breakdowns.framework_breakdown.get("none") == 8  # 5 + 3 (events without framework)

        # Verify library breakdown
        assert breakdowns.library_breakdown.get("posthog-python") == 13  # 10 + 3
        assert breakdowns.library_breakdown.get("posthog-node") == 5

    def test_get_all_ai_cost_model_breakdowns(self) -> None:
        """Test that we correctly get cost model breakdowns."""
        distinct_id = str(uuid4())
        _create_person(distinct_ids=[distinct_id], team=self.team)

        period = get_previous_day()

        # Create AI events with cost model properties (OpenRouter pricing)
        self._create_ai_events(
            self.team,
            distinct_id,
            "$ai_generation",
            10,
            properties={
                "$ai_model": "gpt-4o-mini",
                "$ai_provider": "openai",
                "$ai_model_cost_used": "openai/gpt-4o-mini",
                "$ai_cost_model_source": "openrouter",
                "$ai_cost_model_provider": "openai",
            },
        )

        # Create AI events with custom pricing
        self._create_ai_events(
            self.team,
            distinct_id,
            "$ai_generation",
            5,
            properties={
                "$ai_model": "my-custom-model",
                "$ai_provider": "custom-provider",
                "$ai_model_cost_used": "custom",
                "$ai_cost_model_source": "custom",
                "$ai_cost_model_provider": "custom",
            },
        )

        # Create AI events with manual pricing
        self._create_ai_events(
            self.team,
            distinct_id,
            "$ai_generation",
            3,
            properties={
                "$ai_model": "claude-3-opus",
                "$ai_provider": "anthropic",
                "$ai_model_cost_used": "anthropic/claude-3-opus",
                "$ai_cost_model_source": "manual",
                "$ai_cost_model_provider": "anthropic",
            },
        )

        # Get team_ids first
        team_ids = get_teams_with_ai_events(period.start, period.end, AI_OBSERVABILITY_REPORT_TRIGGER_EVENTS)

        # Get dimension breakdowns using the new combined function
        all_breakdowns = get_all_ai_dimension_breakdowns(period.start, period.end, team_ids)

        # Verify team is in results
        assert self.team.id in all_breakdowns
        breakdowns = all_breakdowns[self.team.id]

        # Verify cost_model_used breakdown
        assert breakdowns.cost_model_used_breakdown.get("openai/gpt-4o-mini") == 10
        assert breakdowns.cost_model_used_breakdown.get("custom") == 5
        assert breakdowns.cost_model_used_breakdown.get("anthropic/claude-3-opus") == 3

        # Verify cost_model_source breakdown
        assert breakdowns.cost_model_source_breakdown.get("openrouter") == 10
        assert breakdowns.cost_model_source_breakdown.get("custom") == 5
        assert breakdowns.cost_model_source_breakdown.get("manual") == 3

        # Verify cost_model_provider breakdown
        assert breakdowns.cost_model_provider_breakdown.get("openai") == 10
        assert breakdowns.cost_model_provider_breakdown.get("custom") == 5
        assert breakdowns.cost_model_provider_breakdown.get("anthropic") == 3

    def test_get_llm_feedback_survey_metrics(self) -> None:
        distinct_id = str(uuid4())
        _create_person(distinct_ids=[distinct_id], team=self.team)

        period = get_previous_day()
        timestamp = datetime.now(UTC) - timedelta(hours=12)

        survey_id_1 = str(uuid4())
        survey_id_2 = str(uuid4())
        trace_id = str(uuid4())

        # "survey shown" for survey 1 with ai_trace_id
        self._create_ai_events(
            self.team,
            distinct_id,
            "survey shown",
            1,
            properties={"$survey_id": survey_id_1, "$ai_trace_id": trace_id},
            timestamp=timestamp,
        )
        # "survey sent" (response) for survey 1 with ai_trace_id
        self._create_ai_events(
            self.team,
            distinct_id,
            "survey sent",
            3,
            properties={"$survey_id": survey_id_1, "$ai_trace_id": trace_id},
            timestamp=timestamp,
        )
        # "survey sent" for survey 2 with ai_trace_id
        self._create_ai_events(
            self.team,
            distinct_id,
            "survey sent",
            2,
            properties={"$survey_id": survey_id_2, "$ai_trace_id": trace_id},
            timestamp=timestamp,
        )
        # "survey sent" without ai_trace_id — should be excluded
        self._create_ai_events(
            self.team,
            distinct_id,
            "survey sent",
            10,
            properties={"$survey_id": str(uuid4())},
            timestamp=timestamp,
        )

        # Need AI events so get_teams_with_ai_events finds this team
        self._create_ai_events(self.team, distinct_id, "$ai_generation", 1)

        team_ids = get_teams_with_ai_events(period.start, period.end, AI_OBSERVABILITY_REPORT_TRIGGER_EVENTS)
        survey_metrics = get_llm_feedback_survey_metrics(period.start, period.end, team_ids)

        assert self.team.id in survey_metrics
        metrics = survey_metrics[self.team.id]
        assert metrics.active_survey_count == 2  # survey_id_1 and survey_id_2
        assert metrics.response_count == 5  # 3 + 2 (only "survey sent" events)

    def test_full_ai_observability_report(self) -> None:
        """Test the full AI observability report generation."""
        # Create second organization and team
        org_2 = Organization.objects.create(name="Org 2")
        team_2 = Team.objects.create(organization=org_2, name="Team 2")

        distinct_id_1 = str(uuid4())
        distinct_id_2 = str(uuid4())
        _create_person(distinct_ids=[distinct_id_1], team=self.team)
        _create_person(distinct_ids=[distinct_id_2], team=team_2)

        period = get_previous_day()

        # Create comprehensive AI events for team 1
        self._create_ai_events(self.team, distinct_id_1, "$ai_generation", 10)
        self._create_ai_events(
            self.team,
            distinct_id_1,
            "$ai_evaluation",
            3,
            properties={"$ai_evaluation_key_type": "posthog", "$ai_evaluation_runtime": "llm_judge"},
        )
        self._create_ai_events(
            self.team, distinct_id_1, "$ai_evaluation", 1, properties={"$ai_evaluation_runtime": "hog"}
        )
        self._create_ai_events(
            self.team, distinct_id_1, "$ai_evaluation", 1, properties={"$ai_evaluation_runtime": "sentiment"}
        )
        self._create_ai_events(
            self.team,
            distinct_id_1,
            "$ai_generation",
            3,
            properties={
                "$ai_total_cost_usd": 0.050,
                "$ai_input_cost_usd": 0.020,
                "$ai_output_cost_usd": 0.030,
                "$ai_request_cost_usd": 0.001,
                "$ai_web_search_cost_usd": 0.002,
                "$ai_input_tokens": 500,
                "$ai_output_tokens": 200,
                "$ai_total_tokens": 700,
                "$ai_reasoning_tokens": 150,
                "$ai_cache_read_input_tokens": 1000,
                "$ai_cache_creation_input_tokens": 500,
                "$ai_model": "gpt-4o-mini",
                "$ai_provider": "openai",
                "$ai_framework": "langchain",
                "$lib": "posthog-python",
                "$ai_model_cost_used": "openai/gpt-4o-mini",
                "$ai_cost_model_source": "openrouter",
                "$ai_cost_model_provider": "openai",
            },
        )
        self._create_ai_events(self.team, distinct_id_1, "$ai_trace_summary", 6)
        self._create_ai_events(self.team, distinct_id_1, "$ai_generation_summary", 8)
        self._create_ai_events(self.team, distinct_id_1, "$ai_trace_clusters", 1)
        self._create_ai_events(self.team, distinct_id_1, "$ai_generation_clusters", 2)
        self._create_ai_events(self.team, distinct_id_1, "$llm_prompt_fetched", 4)

        # Create survey events linked to LLM traces for team 1
        self._create_ai_events(
            self.team,
            distinct_id_1,
            "survey sent",
            4,
            properties={"$survey_id": str(uuid4()), "$ai_trace_id": str(uuid4())},
        )

        # Create AI events for team 2
        self._create_ai_events(team_2, distinct_id_2, "$ai_embedding", 7)
        self._create_ai_events(
            team_2,
            distinct_id_2,
            "$ai_generation",
            2,
            properties={
                "$ai_total_cost_usd": 0.025,
                "$ai_input_cost_usd": 0.010,
                "$ai_output_cost_usd": 0.015,
            },
        )
        self._create_ai_events(team_2, distinct_id_2, "$llm_prompt_fetched", 1)

        # Generate reports
        org_reports = _get_all_ai_observability_reports(period=period)

        # Verify we have reports for both organizations
        assert len(org_reports) == 2
        assert str(self.organization.id) in org_reports
        assert str(org_2.id) in org_reports

        # Verify org 1 report
        org_1_report = org_reports[str(self.organization.id)]
        assert org_1_report["organization_name"] == self.organization.name
        assert org_1_report["ai_generation_count"] == 13  # 10 + 3
        assert org_1_report["ai_evaluation_count"] == 5
        assert org_1_report["ai_llm_judge_evaluation_count"] == 3
        assert org_1_report["ai_hog_evaluation_count"] == 1
        assert org_1_report["ai_sentiment_evaluation_count"] == 1
        assert org_1_report["ai_trace_summary_count"] == 6
        assert org_1_report["ai_generation_summary_count"] == 8
        assert org_1_report["ai_trace_clusters_count"] == 1
        assert org_1_report["ai_generation_clusters_count"] == 2
        assert org_1_report["llm_prompt_fetched_count"] == 4
        assert org_1_report["total_ai_cost_usd"] == pytest.approx(0.150, rel=1e-6)  # 3 * 0.050
        assert org_1_report["input_cost_usd"] == pytest.approx(0.060, rel=1e-6)  # 3 * 0.020
        assert org_1_report["output_cost_usd"] == pytest.approx(0.090, rel=1e-6)  # 3 * 0.030
        assert org_1_report["request_cost_usd"] == pytest.approx(0.003, rel=1e-6)  # 3 * 0.001
        assert org_1_report["web_search_cost_usd"] == pytest.approx(0.006, rel=1e-6)  # 3 * 0.002
        assert org_1_report["total_prompt_tokens"] == 1500  # 3 * 500
        assert org_1_report["total_completion_tokens"] == 600  # 3 * 200
        assert org_1_report["total_tokens"] == 2100  # 3 * 700
        assert org_1_report["total_reasoning_tokens"] == 450  # 3 * 150
        assert org_1_report["total_cache_read_tokens"] == 3000  # 3 * 1000
        assert org_1_report["total_cache_creation_tokens"] == 1500  # 3 * 500
        assert org_1_report["model_breakdown"] == {"gpt-4o-mini": 3}
        assert org_1_report["provider_breakdown"] == {"openai": 3}
        assert org_1_report["framework_breakdown"] == {"langchain": 3, "none": 32}
        assert org_1_report["library_breakdown"] == {"posthog-python": 3}
        assert org_1_report["cost_model_used_breakdown"] == {"openai/gpt-4o-mini": 3}
        assert org_1_report["cost_model_source_breakdown"] == {"openrouter": 3}
        assert org_1_report["cost_model_provider_breakdown"] == {"openai": 3}
        assert org_1_report["active_llm_feedback_survey_count"] == 1
        assert org_1_report["llm_feedback_survey_response_count"] == 4

        # Verify org 2 report
        org_2_report = org_reports[str(org_2.id)]
        assert org_2_report["organization_name"] == org_2.name
        assert org_2_report["ai_embedding_count"] == 7
        assert org_2_report["ai_generation_count"] == 2
        assert org_2_report["ai_llm_judge_evaluation_count"] == 0
        assert org_2_report["ai_hog_evaluation_count"] == 0
        assert org_2_report["ai_sentiment_evaluation_count"] == 0
        assert org_2_report["llm_prompt_fetched_count"] == 1
        assert org_2_report["total_ai_cost_usd"] == pytest.approx(0.050, rel=1e-6)  # 2 * 0.025
        assert org_2_report["ai_trace_summary_count"] == 0
        assert org_2_report["ai_generation_summary_count"] == 0
        assert org_2_report["ai_trace_clusters_count"] == 0
        assert org_2_report["ai_generation_clusters_count"] == 0
        assert org_2_report["active_llm_feedback_survey_count"] == 0
        assert org_2_report["llm_feedback_survey_response_count"] == 0

    @patch("posthog.tasks.ai_observability_usage_report.capture_ai_observability_report")
    @patch("posthog.tasks.ai_observability_usage_report.get_ph_client")
    @patch("posthoganalytics.feature_enabled", return_value=False)
    def test_send_ai_observability_usage_reports(
        self,
        mock_feature_enabled: MagicMock,
        mock_get_ph_client: MagicMock,
        mock_capture_report: MagicMock,
    ) -> None:
        """Test the main task to send AI observability usage reports."""
        distinct_id = str(uuid4())
        _create_person(distinct_ids=[distinct_id], team=self.team)

        # Create some AI events
        self._create_ai_events(self.team, distinct_id, "$ai_generation", 5)
        self._create_ai_events(self.team, distinct_id, "$ai_evaluation", 3)
        self._create_ai_events(self.team, distinct_id, "$llm_prompt_fetched", 2)

        # Run the task
        send_ai_observability_usage_reports()

        # Verify capture_ai_observability_report was called
        assert mock_capture_report.delay.call_count == 1

        # Verify the report data
        call_args = mock_capture_report.delay.call_args
        assert call_args[1]["organization_id"] == str(self.organization.id)
        report_dict = call_args[1]["report_dict"]
        assert report_dict["ai_generation_count"] == 5
        assert report_dict["ai_evaluation_count"] == 3
        assert report_dict["llm_prompt_fetched_count"] == 2

    def test_no_trigger_events_returns_empty_report(self) -> None:
        """Test that when there are no trigger events, an empty report is returned."""
        period = get_previous_day()

        # Generate reports without creating any trigger events
        org_reports = _get_all_ai_observability_reports(period=period)

        # Should return empty dict
        assert len(org_reports) == 0

    def test_prompt_fetched_only_team_generates_report_with_zero_ai_metrics(self) -> None:
        """Test that prompt fetched events trigger reporting without affecting AI metric totals."""
        org_2 = Organization.objects.create(name="Org 2")
        team_2 = Team.objects.create(organization=org_2, name="Team 2")

        distinct_id = str(uuid4())
        _create_person(distinct_ids=[distinct_id], team=team_2)

        period = get_previous_day()

        self._create_ai_events(team_2, distinct_id, "$llm_prompt_fetched", 2)

        org_reports = _get_all_ai_observability_reports(period=period)

        assert len(org_reports) == 1
        org_report = org_reports[str(org_2.id)]
        assert org_report["organization_name"] == org_2.name
        assert org_report["ai_generation_count"] == 0
        assert org_report["ai_embedding_count"] == 0
        assert org_report["ai_span_count"] == 0
        assert org_report["ai_trace_count"] == 0
        assert org_report["ai_metric_count"] == 0
        assert org_report["ai_feedback_count"] == 0
        assert org_report["ai_evaluation_count"] == 0
        assert org_report["ai_llm_judge_evaluation_count"] == 0
        assert org_report["ai_hog_evaluation_count"] == 0
        assert org_report["ai_sentiment_evaluation_count"] == 0
        assert org_report["ai_trace_summary_count"] == 0
        assert org_report["ai_generation_summary_count"] == 0
        assert org_report["ai_trace_clusters_count"] == 0
        assert org_report["ai_generation_clusters_count"] == 0
        assert org_report["llm_prompt_fetched_count"] == 2

    def test_multiple_teams_in_same_org(self) -> None:
        """Test that multiple teams in the same org are aggregated correctly."""
        # Create second team in same organization
        team_2 = Team.objects.create(organization=self.organization, name="Team 2")

        distinct_id_1 = str(uuid4())
        distinct_id_2 = str(uuid4())
        _create_person(distinct_ids=[distinct_id_1], team=self.team)
        _create_person(distinct_ids=[distinct_id_2], team=team_2)

        period = get_previous_day()

        # Create events for both teams
        self._create_ai_events(self.team, distinct_id_1, "$ai_generation", 10)
        self._create_ai_events(team_2, distinct_id_2, "$ai_generation", 5)
        self._create_ai_events(
            self.team,
            distinct_id_1,
            "$ai_evaluation",
            3,
            properties={"$ai_evaluation_key_type": "posthog", "$ai_evaluation_runtime": "llm_judge"},
        )
        self._create_ai_events(
            team_2, distinct_id_2, "$ai_evaluation", 2, properties={"$ai_evaluation_runtime": "sentiment"}
        )

        # Generate reports
        org_reports = _get_all_ai_observability_reports(period=period)

        # Should have one report for the organization
        assert len(org_reports) == 1
        org_report = org_reports[str(self.organization.id)]

        # Counts should be aggregated across both teams
        assert org_report["ai_generation_count"] == 15  # 10 + 5
        assert org_report["ai_evaluation_count"] == 5  # 3 + 2
        assert org_report["ai_llm_judge_evaluation_count"] == 3
        assert org_report["ai_hog_evaluation_count"] == 0
        assert org_report["ai_sentiment_evaluation_count"] == 2

    def test_dimension_breakdown_aggregation_across_teams(self) -> None:
        """Test that dimension breakdowns are correctly aggregated across teams in the same org."""
        # Create second team in same organization
        team_2 = Team.objects.create(organization=self.organization, name="Team 2")

        distinct_id_1 = str(uuid4())
        distinct_id_2 = str(uuid4())
        _create_person(distinct_ids=[distinct_id_1], team=self.team)
        _create_person(distinct_ids=[distinct_id_2], team=team_2)

        period = get_previous_day()

        # Team 1 uses OpenAI models
        self._create_ai_events(
            self.team,
            distinct_id_1,
            "$ai_generation",
            10,
            properties={
                "$ai_model": "gpt-4o-mini",
                "$ai_provider": "openai",
                "$ai_framework": "langchain",
                "$lib": "posthog-python",
            },
        )

        self._create_ai_events(
            self.team,
            distinct_id_1,
            "$ai_generation",
            5,
            properties={
                "$ai_model": "gpt-4",
                "$ai_provider": "openai",
                "$lib": "posthog-python",
            },
        )

        # Team 2 uses Anthropic models
        self._create_ai_events(
            team_2,
            distinct_id_2,
            "$ai_generation",
            7,
            properties={
                "$ai_model": "claude-3-opus",
                "$ai_provider": "anthropic",
                "$ai_framework": "langchain",
                "$lib": "posthog-node",
            },
        )

        # Team 2 also uses some OpenAI
        self._create_ai_events(
            team_2,
            distinct_id_2,
            "$ai_generation",
            3,
            properties={
                "$ai_model": "gpt-4o-mini",
                "$ai_provider": "openai",
                "$lib": "posthog-python",
            },
        )

        # Generate reports
        org_reports = _get_all_ai_observability_reports(period=period)

        # Should have one report for the organization
        assert len(org_reports) == 1
        org_report = org_reports[str(self.organization.id)]

        # Verify model breakdown is aggregated across teams
        assert org_report["model_breakdown"]["gpt-4o-mini"] == 13  # 10 from team1 + 3 from team2
        assert org_report["model_breakdown"]["gpt-4"] == 5  # from team1
        assert org_report["model_breakdown"]["claude-3-opus"] == 7  # from team2

        # Verify provider breakdown is aggregated
        assert org_report["provider_breakdown"]["openai"] == 18  # 10 + 5 + 3
        assert org_report["provider_breakdown"]["anthropic"] == 7

        # Verify framework breakdown is aggregated
        assert org_report["framework_breakdown"]["langchain"] == 17  # 10 + 7
        assert org_report["framework_breakdown"]["none"] == 8  # 5 + 3

        # Verify library breakdown is aggregated
        assert org_report["library_breakdown"]["posthog-python"] == 18  # 10 + 5 + 3
        assert org_report["library_breakdown"]["posthog-node"] == 7

    def test_dimension_breakdowns_filter_empty_values(self) -> None:
        """Test that dimension breakdowns correctly filter out empty and whitespace-only values."""
        distinct_id = str(uuid4())
        _create_person(distinct_ids=[distinct_id], team=self.team)

        period = get_previous_day()

        # Create events with valid dimension values
        self._create_ai_events(
            self.team,
            distinct_id,
            "$ai_generation",
            5,
            properties={
                "$ai_model": "gpt-4o-mini",
                "$ai_provider": "openai",
                "$lib": "posthog-python",
            },
        )

        # Create events with empty model (should be filtered out)
        self._create_ai_events(
            self.team,
            distinct_id,
            "$ai_generation",
            3,
            properties={
                "$ai_model": "",
                "$ai_provider": "anthropic",
                "$lib": "posthog-node",
            },
        )

        # Create events with whitespace-only provider (should be filtered out)
        self._create_ai_events(
            self.team,
            distinct_id,
            "$ai_generation",
            2,
            properties={
                "$ai_model": "claude-3-opus",
                "$ai_provider": "   ",
                "$lib": "posthog-python",
            },
        )

        # Create events with empty library (should be filtered out)
        self._create_ai_events(
            self.team,
            distinct_id,
            "$ai_generation",
            4,
            properties={
                "$ai_model": "gpt-4",
                "$ai_provider": "openai",
                "$lib": "",
            },
        )

        # Create events with no dimension properties at all
        self._create_ai_events(
            self.team,
            distinct_id,
            "$ai_generation",
            1,
            properties={},
        )

        # Get team_ids first
        team_ids = get_teams_with_ai_events(period.start, period.end, AI_OBSERVABILITY_REPORT_TRIGGER_EVENTS)

        # Get dimension breakdowns using the new combined function
        all_breakdowns = get_all_ai_dimension_breakdowns(period.start, period.end, team_ids)

        # Verify team is in results
        assert self.team.id in all_breakdowns
        breakdowns = all_breakdowns[self.team.id]

        # Verify model breakdown - should only have valid models
        assert breakdowns.model_breakdown.get("gpt-4o-mini") == 5
        assert breakdowns.model_breakdown.get("claude-3-opus") == 2
        assert breakdowns.model_breakdown.get("gpt-4") == 4
        assert "" not in breakdowns.model_breakdown  # Empty string should be filtered out
        assert breakdowns.model_breakdown.get("") is None

        # Verify provider breakdown - should only have valid providers
        assert breakdowns.provider_breakdown.get("openai") == 9  # 5 + 4
        assert breakdowns.provider_breakdown.get("anthropic") == 3
        assert "" not in breakdowns.provider_breakdown  # Empty string should be filtered out
        assert "   " not in breakdowns.provider_breakdown  # Whitespace should be filtered out
        assert breakdowns.provider_breakdown.get("") is None
        assert breakdowns.provider_breakdown.get("   ") is None

        # Verify library breakdown - should only have valid libraries
        assert breakdowns.library_breakdown.get("posthog-python") == 7  # 5 + 2
        assert breakdowns.library_breakdown.get("posthog-node") == 3
        assert "" not in breakdowns.library_breakdown  # Empty string should be filtered out
        assert breakdowns.library_breakdown.get("") is None

        # Verify framework breakdown - events without framework should count as "none"
        assert breakdowns.framework_breakdown.get("none") == 15  # All events (3+2+4+1+5) have no framework

    def test_get_teams_with_ai_events(self) -> None:
        """Test that get_teams_with_ai_events returns correct team IDs for trigger events."""
        # Create second team
        org_2 = Organization.objects.create(name="Org 2")
        team_2 = Team.objects.create(organization=org_2, name="Team 2")
        team_3 = Team.objects.create(organization=self.organization, name="Team 3 - no events")
        org_4 = Organization.objects.create(name="Org 4")
        team_4 = Team.objects.create(organization=org_4, name="Team 4 - prompt fetched only")

        distinct_id_1 = str(uuid4())
        distinct_id_2 = str(uuid4())
        distinct_id_4 = str(uuid4())
        _create_person(distinct_ids=[distinct_id_1], team=self.team)
        _create_person(distinct_ids=[distinct_id_2], team=team_2)
        _create_person(distinct_ids=[distinct_id_4], team=team_4)

        period = get_previous_day()

        # Create AI events for team 1 and team 2, prompt-fetched events for team 4, but nothing for team 3.
        self._create_ai_events(self.team, distinct_id_1, "$ai_generation", 5)
        self._create_ai_events(team_2, distinct_id_2, "$ai_embedding", 3)
        self._create_ai_events(team_4, distinct_id_4, "$llm_prompt_fetched", 1)

        # Get teams with trigger events
        team_ids = get_teams_with_ai_events(period.start, period.end, AI_OBSERVABILITY_REPORT_TRIGGER_EVENTS)

        # Verify correct teams are returned
        assert self.team.id in team_ids
        assert team_2.id in team_ids
        assert team_4.id in team_ids
        assert team_3.id not in team_ids
        assert len(team_ids) == 3

    def test_get_llm_prompt_fetched_counts(self) -> None:
        """Test that get_llm_prompt_fetched_counts returns per-team prompt fetch totals."""
        org_2 = Organization.objects.create(name="Org 2")
        team_2 = Team.objects.create(organization=org_2, name="Team 2")
        team_3 = Team.objects.create(organization=self.organization, name="Team 3 - no prompt fetched")

        distinct_id_1 = str(uuid4())
        distinct_id_2 = str(uuid4())
        distinct_id_3 = str(uuid4())
        _create_person(distinct_ids=[distinct_id_1], team=self.team)
        _create_person(distinct_ids=[distinct_id_2], team=team_2)
        _create_person(distinct_ids=[distinct_id_3], team=team_3)

        period = get_previous_day()

        self._create_ai_events(self.team, distinct_id_1, "$llm_prompt_fetched", 4)
        self._create_ai_events(team_2, distinct_id_2, "$llm_prompt_fetched", 2)
        self._create_ai_events(team_2, distinct_id_2, "$ai_generation", 7)
        self._create_ai_events(team_3, distinct_id_3, "$ai_generation", 3)

        team_ids = get_teams_with_ai_events(period.start, period.end, AI_OBSERVABILITY_REPORT_TRIGGER_EVENTS)
        prompt_fetched_counts = get_llm_prompt_fetched_counts(period.start, period.end, team_ids)

        assert prompt_fetched_counts[self.team.id] == 4
        assert prompt_fetched_counts[team_2.id] == 2
        assert team_3.id not in prompt_fetched_counts

    @patch("posthog.tasks.ai_observability_usage_report.capture_exception")
    @patch("posthog.tasks.ai_observability_usage_report.get_llm_prompt_fetched_counts", side_effect=Exception("boom"))
    def test_prompt_fetched_count_failure_does_not_fail_usage_report(
        self,
        mock_get_llm_prompt_fetched_counts: MagicMock,
        mock_capture_exception: MagicMock,
    ) -> None:
        """Test that report generation continues when prompt fetched count query fails."""
        distinct_id = str(uuid4())
        _create_person(distinct_ids=[distinct_id], team=self.team)

        period = get_previous_day()
        self._create_ai_events(self.team, distinct_id, "$ai_generation", 5)
        self._create_ai_events(self.team, distinct_id, "$llm_prompt_fetched", 3)

        org_reports = _get_all_ai_observability_reports(period=period)

        assert len(org_reports) == 1
        org_report = org_reports[str(self.organization.id)]
        assert org_report["ai_generation_count"] == 5
        assert org_report["llm_prompt_fetched_count"] == 0
        mock_get_llm_prompt_fetched_counts.assert_called_once()
        assert mock_capture_exception.call_count == 1

    @patch("posthog.tasks.ai_observability_usage_report.capture_ai_observability_report")
    @patch("posthog.tasks.ai_observability_usage_report.get_ph_client")
    @patch("posthoganalytics.feature_enabled", return_value=False)
    def test_send_ai_observability_usage_reports_dry_run(
        self,
        mock_feature_enabled: MagicMock,
        mock_get_ph_client: MagicMock,
        mock_capture_report: MagicMock,
    ) -> None:
        """Test that dry_run=True prevents reports from being sent."""
        distinct_id = str(uuid4())
        _create_person(distinct_ids=[distinct_id], team=self.team)

        # Create some AI events
        self._create_ai_events(self.team, distinct_id, "$ai_generation", 5)

        # Run the task with dry_run=True
        send_ai_observability_usage_reports(dry_run=True)

        # Verify capture_ai_observability_report was NOT called
        assert mock_capture_report.delay.call_count == 0

    @patch("posthog.tasks.ai_observability_usage_report.capture_ai_observability_report")
    @patch("posthog.tasks.ai_observability_usage_report._get_all_ai_observability_reports")
    @patch("posthoganalytics.capture_exception")
    @patch("posthoganalytics.feature_enabled", return_value=True)
    def test_send_ai_observability_usage_reports_disabled_by_feature_flag(
        self,
        mock_feature_enabled: MagicMock,
        mock_capture_exception: MagicMock,
        mock_get_reports: MagicMock,
        mock_capture_report: MagicMock,
    ) -> None:
        """Test that reports are not sent when disabled by feature flag."""
        # Run the task
        send_ai_observability_usage_reports()

        # Verify feature flag was checked
        mock_feature_enabled.assert_called_once_with("llm-analytics-disable-usage-reports", "internal_billing_events")

        # Verify capture_exception was called to log that reports are disabled
        assert mock_capture_exception.call_count == 1

        # Verify _get_all_ai_observability_reports was NOT called (early exit)
        assert mock_get_reports.call_count == 0

        # Verify capture_ai_observability_report was NOT called
        assert mock_capture_report.delay.call_count == 0

    @patch("posthog.tasks.ai_observability_usage_report.capture_ai_observability_report")
    @patch("posthog.tasks.ai_observability_usage_report.get_ph_client")
    @patch("posthoganalytics.feature_enabled", return_value=False)
    def test_send_ai_observability_usage_reports_with_at_parameter(
        self,
        mock_feature_enabled: MagicMock,
        mock_get_ph_client: MagicMock,
        mock_capture_report: MagicMock,
    ) -> None:
        """Test that the at parameter correctly specifies the report date."""
        distinct_id = str(uuid4())
        _create_person(distinct_ids=[distinct_id], team=self.team)

        # Create AI events for January 5th (within Jan 4th period when at="2022-01-05")
        jan_5_timestamp = datetime(2022, 1, 5, 12, 0, 0, tzinfo=UTC)
        self._create_ai_events(
            self.team,
            distinct_id,
            "$ai_generation",
            5,
            timestamp=jan_5_timestamp,
        )

        # Create AI events for January 9th (within the default period based on freeze_time)
        jan_9_timestamp = datetime(2022, 1, 9, 12, 0, 0, tzinfo=UTC)
        self._create_ai_events(
            self.team,
            distinct_id,
            "$ai_embedding",
            3,
            timestamp=jan_9_timestamp,
        )

        # Run the task with at="2022-01-06" (reports for Jan 5th)
        send_ai_observability_usage_reports(at="2022-01-06")

        # Verify capture_ai_observability_report was called
        assert mock_capture_report.delay.call_count == 1

        # Verify only Jan 5th events are in the report (not Jan 9th)
        call_args = mock_capture_report.delay.call_args
        report_dict = call_args[1]["report_dict"]
        assert report_dict["ai_generation_count"] == 5
        assert report_dict["ai_embedding_count"] == 0  # Jan 9th events not included

    @parameterized.expand(
        [
            ("covering_the_same_period", "2022-01-05T00:00:00+00:00", 0),
            ("covering_a_different_period", "2021-12-20T00:00:00+00:00", 1),
        ]
    )
    @patch("posthog.tasks.ai_observability_usage_report.capture_ai_observability_report")
    @patch("posthog.tasks.ai_observability_usage_report.get_ph_client")
    @patch("posthoganalytics.feature_enabled", return_value=False)
    def test_manual_run_skips_organizations_with_an_existing_report(
        self,
        _name: str,
        existing_period_start: str,
        expected_emissions: int,
        mock_feature_enabled: MagicMock,
        mock_get_ph_client: MagicMock,
        mock_capture_report: MagicMock,
    ) -> None:
        self.team.api_token = PH_US_API_KEY
        self.team.save()

        distinct_id = str(uuid4())
        _create_person(distinct_ids=[distinct_id], team=self.team)
        self._create_ai_events(
            self.team,
            distinct_id,
            "$ai_generation",
            5,
            timestamp=datetime(2022, 1, 5, 12, 0, 0, tzinfo=UTC),
        )

        # Both cases stamp the existing report inside the lookup's scan window, so only the
        # period_start property differs. A lookup that derived the period from the timestamp, or read
        # either property out of the `ai` property group, would treat the two cases identically.
        create_event(
            event_uuid=uuid4(),
            distinct_id=distinct_id,
            event=AI_OBSERVABILITY_USAGE_EVENT,
            properties={
                "organization_id": str(self.organization.id),
                "period_start": existing_period_start,
            },
            timestamp=datetime(2022, 1, 6, 4, 15, 0, tzinfo=UTC),
            team=self.team,
        )
        flush_persons_and_events()

        send_ai_observability_usage_reports(at="2022-01-06")

        assert mock_capture_report.delay.call_count == expected_emissions


@freeze_time("2022-01-10T00:01:00Z")
class TestAIObservabilityUsageReportTaskWiring(SimpleTestCase):
    @parameterized.expand(
        [
            ("scheduled", None, False, "2022-01-10T00:00:00+00:00", "scheduled"),
            ("manual_by_date", "2022-01-06", False, "2022-01-06T00:00:00+00:00", "manual"),
            ("manual_by_org_filter", None, True, "2022-01-10T00:00:00+00:00", "manual"),
        ]
    )
    @patch("posthog.tasks.ai_observability_usage_report.internal_reporting_team_id", return_value=None)
    @patch("posthog.tasks.ai_observability_usage_report.capture_ai_observability_report")
    @patch("posthog.tasks.ai_observability_usage_report._get_all_ai_observability_reports")
    @patch("posthoganalytics.feature_enabled", return_value=False)
    def test_reports_get_deterministic_timestamp_and_trigger_source(
        self,
        _name: str,
        at: str | None,
        filter_by_org: bool,
        expected_at_date: str,
        expected_trigger: str,
        mock_feature_enabled: MagicMock,
        mock_get_reports: MagicMock,
        mock_capture_report: MagicMock,
        mock_internal_team_id: MagicMock,
    ) -> None:
        org_id = str(uuid4())
        mock_get_reports.return_value = {
            org_id: {
                "organization_id": org_id,
                "organization_name": "Test Org",
                "ai_generation_count": 5,
            }
        }
        organization_ids = [org_id] if filter_by_org else None

        send_ai_observability_usage_reports(at=at, organization_ids=organization_ids)

        assert mock_capture_report.delay.call_count == 1
        call_kwargs = mock_capture_report.delay.call_args.kwargs
        assert call_kwargs["at_date"] == expected_at_date
        assert call_kwargs["report_dict"]["triggered_by"] == expected_trigger

    @patch(
        "posthog.tasks.ai_observability_usage_report.get_organizations_already_reported",
        side_effect=Exception("CH down"),
    )
    @patch("posthog.tasks.ai_observability_usage_report.internal_reporting_team_id", return_value=2)
    @patch("posthog.tasks.ai_observability_usage_report.capture_ai_observability_report")
    @patch("posthog.tasks.ai_observability_usage_report._get_all_ai_observability_reports")
    @patch("posthoganalytics.feature_enabled", return_value=False)
    def test_run_emits_nothing_when_the_already_reported_lookup_fails(
        self,
        mock_feature_enabled: MagicMock,
        mock_get_reports: MagicMock,
        mock_capture_report: MagicMock,
        mock_internal_team_id: MagicMock,
        mock_already_reported: MagicMock,
    ) -> None:
        org_id = str(uuid4())
        mock_get_reports.return_value = {org_id: {"organization_id": org_id}}

        with pytest.raises(Exception, match="CH down"):
            send_ai_observability_usage_reports(at="2022-01-06")

        assert mock_capture_report.delay.call_count == 0
        mock_get_reports.assert_not_called()

    @parameterized.expand([("scheduled", None), ("manual", "2022-01-06")])
    @patch("posthog.tasks.ai_observability_usage_report.get_organizations_already_reported")
    @patch("posthog.tasks.ai_observability_usage_report.internal_reporting_team_id", return_value=2)
    @patch("posthog.tasks.ai_observability_usage_report.capture_ai_observability_report")
    @patch("posthog.tasks.ai_observability_usage_report._get_all_ai_observability_reports")
    @patch("posthoganalytics.feature_enabled", return_value=False)
    def test_already_reported_organizations_are_skipped_on_every_run_type(
        self,
        _name: str,
        at: str | None,
        mock_feature_enabled: MagicMock,
        mock_get_reports: MagicMock,
        mock_capture_report: MagicMock,
        mock_internal_team_id: MagicMock,
        mock_already_reported: MagicMock,
    ) -> None:
        reported_org, fresh_org = str(uuid4()), str(uuid4())
        mock_get_reports.return_value = {
            reported_org: {"organization_id": reported_org},
            fresh_org: {"organization_id": fresh_org},
        }
        mock_already_reported.return_value = {reported_org}

        send_ai_observability_usage_reports(at=at)

        emitted = [call.kwargs["organization_id"] for call in mock_capture_report.delay.call_args_list]
        assert emitted == [fresh_org]

    @patch("posthog.tasks.ai_observability_usage_report.internal_reporting_team_id", return_value=None)
    @patch("posthog.tasks.ai_observability_usage_report.capture_ai_observability_report")
    @patch("posthog.tasks.ai_observability_usage_report._get_all_ai_observability_reports")
    @patch("posthoganalytics.feature_enabled", return_value=False)
    def test_run_still_emits_where_previous_reports_cannot_be_read(
        self,
        mock_feature_enabled: MagicMock,
        mock_get_reports: MagicMock,
        mock_capture_report: MagicMock,
        mock_internal_team_id: MagicMock,
    ) -> None:
        org_id = str(uuid4())
        mock_get_reports.return_value = {org_id: {"organization_id": org_id}}

        send_ai_observability_usage_reports(at="2022-01-06")

        assert mock_capture_report.delay.call_count == 1

    @parameterized.expand(
        [
            ("retryable", 0, False, "warning", "error", "[AIO Usage Error] teams query failed"),
            (
                "terminal",
                send_ai_observability_usage_reports.max_retries,
                False,
                "error",
                None,
                "[AIO Usage Error] usage report run failed permanently",
            ),
            (
                "direct_call",
                0,
                True,
                "error",
                None,
                "[AIO Usage Error] usage report run failed permanently",
            ),
        ]
    )
    @patch("posthog.tasks.ai_observability_usage_report._get_organizations_to_skip", return_value=set())
    @patch("posthog.tasks.ai_observability_usage_report.logger")
    @patch("posthog.tasks.ai_observability_usage_report.get_teams_with_ai_events", side_effect=Exception("CH down"))
    @patch("posthoganalytics.feature_enabled", return_value=False)
    def test_send_task_failure_log_level(
        self,
        _name: str,
        retries: int,
        called_directly: bool,
        expected_level: str,
        forbidden_level: str | None,
        expected_message: str,
        mock_feature_enabled: MagicMock,
        mock_get_teams: MagicMock,
        mock_logger: MagicMock,
        mock_organizations_to_skip: MagicMock,
    ) -> None:
        task = send_ai_observability_usage_reports
        task.push_request(retries=retries, called_directly=called_directly, is_eager=True)
        try:
            with pytest.raises(Exception, match="CH down"):
                task.run()
        finally:
            task.pop_request()

        log_fn = getattr(mock_logger, expected_level)
        assert log_fn.call_count == 1
        assert log_fn.call_args.args[0] == expected_message
        if forbidden_level:
            assert not getattr(mock_logger, forbidden_level).called

    @parameterized.expand(
        [
            ("retryable", 0, False, "warning", "error"),
            ("terminal", capture_ai_observability_report.max_retries, False, "error", "warning"),
            ("direct_call", 0, True, "error", "warning"),
        ]
    )
    @patch("posthog.tasks.ai_observability_usage_report.logger")
    @patch("posthog.tasks.ai_observability_usage_report.capture_event", side_effect=Exception("capture down"))
    @patch("posthog.tasks.ai_observability_usage_report.get_ph_client")
    def test_capture_report_failure_log_level(
        self,
        _name: str,
        retries: int,
        called_directly: bool,
        expected_level: str,
        forbidden_level: str,
        mock_get_ph_client: MagicMock,
        mock_capture_event: MagicMock,
        mock_logger: MagicMock,
    ) -> None:
        task = capture_ai_observability_report
        task.push_request(retries=retries, called_directly=called_directly, is_eager=True)
        try:
            with pytest.raises(Exception, match="capture down"):
                task.run(organization_id=str(uuid4()), report_dict={}, at_date=None)
        finally:
            task.pop_request()

        assert getattr(mock_logger, expected_level).called
        assert not getattr(mock_logger, forbidden_level).called
