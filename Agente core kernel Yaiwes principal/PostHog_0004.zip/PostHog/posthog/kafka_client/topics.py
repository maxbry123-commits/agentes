# Keep this in sync with plugin-server/src/config/kafka-topics.ts

from posthog.settings.data_stores import SUFFIX
from posthog.settings.kafka import KAFKA_PREFIX
from posthog.settings.utils import get_from_env

KAFKA_EVENTS_JSON = f"{KAFKA_PREFIX}clickhouse_events_json{SUFFIX}"
KAFKA_EXCEPTIONS_INGESTION = f"{KAFKA_PREFIX}exceptions_ingestion{SUFFIX}"
KAFKA_EVENTS_PLUGIN_INGESTION = get_from_env(
    "KAFKA_EVENTS_PLUGIN_INGESTION_TOPIC", f"{KAFKA_PREFIX}events_plugin_ingestion{SUFFIX}"
)
KAFKA_EVENTS_PLUGIN_INGESTION_OVERFLOW = get_from_env(
    "KAFKA_EVENTS_PLUGIN_INGESTION_OVERFLOW_TOPIC", f"{KAFKA_PREFIX}events_plugin_ingestion_overflow{SUFFIX}"
)
KAFKA_EVENTS_PLUGIN_INGESTION_HISTORICAL = get_from_env(
    "KAFKA_EVENTS_PLUGIN_INGESTION_HISTORICAL_TOPIC", f"{KAFKA_PREFIX}events_plugin_ingestion_historical{SUFFIX}"
)
KAFKA_PERSON = f"{KAFKA_PREFIX}clickhouse_person{SUFFIX}"
KAFKA_PERSON_UNIQUE_ID = f"{KAFKA_PREFIX}clickhouse_person_unique_id{SUFFIX}"  # DEPRECATED_DO_NOT_USE
KAFKA_PERSON_DISTINCT_ID = f"{KAFKA_PREFIX}clickhouse_person_distinct_id{SUFFIX}"
KAFKA_PERFORMANCE_EVENTS = f"{KAFKA_PREFIX}clickhouse_performance_events{SUFFIX}"
KAFKA_PLUGIN_LOG_ENTRIES = f"{KAFKA_PREFIX}plugin_log_entries{SUFFIX}"
KAFKA_DEAD_LETTER_QUEUE = f"{KAFKA_PREFIX}events_dead_letter_queue{SUFFIX}"
KAFKA_GROUPS = f"{KAFKA_PREFIX}clickhouse_groups{SUFFIX}"
KAFKA_INGESTION_WARNINGS = f"{KAFKA_PREFIX}clickhouse_ingestion_warnings{SUFFIX}"
# DEPRECATED: superseded by clickhouse_app_metrics2 (see KAFKA_APP_METRICS2 below).
# Kept only because the legacy `kafka_app_metrics` ClickHouse Kafka-engine table
# still references this topic in its DDL — see posthog/models/app_metrics/sql.py.
# No producer writes to it. Remove once the underlying tables are dropped.
KAFKA_APP_METRICS = f"{KAFKA_PREFIX}clickhouse_app_metrics{SUFFIX}"
KAFKA_APP_METRICS2 = f"{KAFKA_PREFIX}clickhouse_app_metrics2{SUFFIX}"
KAFKA_METRICS_TIME_TO_SEE_DATA = f"{KAFKA_PREFIX}clickhouse_metrics_time_to_see_data{SUFFIX}"
KAFKA_PERSON_OVERRIDE = f"{KAFKA_PREFIX}clickhouse_person_override{SUFFIX}"
KAFKA_LOG_ENTRIES = f"{KAFKA_PREFIX}log_entries{SUFFIX}"
KAFKA_LOG_ENTRIES_V2_TEST = f"{KAFKA_PREFIX}log_entries_v2_test{SUFFIX}"
KAFKA_HOG_INVOCATION_RESULTS = f"{KAFKA_PREFIX}clickhouse_hog_invocation_results{SUFFIX}"
KAFKA_MESSAGE_ASSETS = f"{KAFKA_PREFIX}clickhouse_message_assets{SUFFIX}"

KAFKA_CLICKHOUSE_HEATMAP_EVENTS = f"{KAFKA_PREFIX}clickhouse_heatmap_events{SUFFIX}"
KAFKA_CLICKHOUSE_AI_EVENTS_JSON = f"{KAFKA_PREFIX}clickhouse_ai_events_json{SUFFIX}"
KAFKA_CLICKHOUSE_FLAG_EVALUATIONS = f"{KAFKA_PREFIX}clickhouse_flag_evaluations{SUFFIX}"

# Legacy session recording topic — only retained because clickhouse migration 0063 still
# DROPs the old materialized view by name. Producers/consumers live in the Node.js services.
KAFKA_SESSION_RECORDING_EVENTS = f"{KAFKA_PREFIX}session_recording_events{SUFFIX}"

# from recordings consumer to clickhouse
KAFKA_CLICKHOUSE_SESSION_REPLAY_EVENTS = f"{KAFKA_PREFIX}clickhouse_session_replay_events{SUFFIX}"
KAFKA_CLICKHOUSE_SESSION_REPLAY_FEATURES = f"{KAFKA_PREFIX}clickhouse_session_replay_features{SUFFIX}"
KAFKA_CLICKHOUSE_SESSION_RECORDING_EVENTS = f"{KAFKA_PREFIX}clickhouse_session_recording_events{SUFFIX}"

KAFKA_ERROR_TRACKING_ISSUE_FINGERPRINT = f"{KAFKA_PREFIX}clickhouse_error_tracking_issue_fingerprint{SUFFIX}"
KAFKA_ERROR_TRACKING_FINGERPRINT_ISSUE_STATE = (
    f"{KAFKA_PREFIX}clickhouse_error_tracking_fingerprint_issue_state{SUFFIX}"
)
KAFKA_ERROR_TRACKING_ISSUE_FINGERPRINT_EMBEDDINGS = (
    f"{KAFKA_PREFIX}clickhouse_error_tracking_issue_fingerprint_embeddings{SUFFIX}"
)
KAFKA_DOCUMENT_EMBEDDINGS_TOPIC = f"{KAFKA_PREFIX}clickhouse_document_embeddings{SUFFIX}"
KAFKA_DOCUMENT_EMBEDDINGS_INPUT_TOPIC = f"{KAFKA_PREFIX}document_embeddings_input{SUFFIX}"
KAFKA_DOCUMENT_EMBEDDING_RESULTS_TOPIC = f"{KAFKA_PREFIX}document_embedding_results{SUFFIX}"

KAFKA_CDP_INTERNAL_EVENTS = f"{KAFKA_PREFIX}cdp_internal_events{SUFFIX}"
KAFKA_CDP_BACKFILL_EVENTS = f"{KAFKA_PREFIX}cdp_backfill_events{SUFFIX}"
KAFKA_COHORT_MEMBERSHIP_CHANGED = f"{KAFKA_PREFIX}cohort_membership_changed{SUFFIX}"

KAFKA_DWH_CDP_RAW_TABLE = f"{KAFKA_PREFIX}cdp_data_warehouse_source_table{SUFFIX}"
KAFKA_WAREHOUSE_SOURCE_WEBHOOKS = f"{KAFKA_PREFIX}data_warehouse_source_webhooks{SUFFIX}"
KAFKA_WAREHOUSE_SOURCE_WEBHOOKS_DLQ = f"{KAFKA_PREFIX}data_warehouse_source_webhooks_dlq{SUFFIX}"

KAFKA_CLICKHOUSE_TOPHOG = f"{KAFKA_PREFIX}clickhouse_tophog{SUFFIX}"
KAFKA_BILLING_USAGE_RECORDS = f"{KAFKA_PREFIX}clickhouse_billing_usage_records{SUFFIX}"

# Distinct ID usage - pre-processed by WarpStream pipeline from clickhouse_events_json
KAFKA_DISTINCT_ID_USAGE_EVENTS_JSON = f"{KAFKA_PREFIX}distinct_id_usage_events_json{SUFFIX}"

# Property values - pre-processed by WarpStream pipeline from clickhouse_events_json
KAFKA_CLICKHOUSE_PROPERTY_VALUES = f"{KAFKA_PREFIX}clickhouse_property_values{SUFFIX}"

KAFKA_NOTIFICATION_EVENTS = f"{KAFKA_PREFIX}notification_events{SUFFIX}"

KAFKA_SIGNALS_REPORT_COMPLETED = f"{KAFKA_PREFIX}signals_report_completed{SUFFIX}"

# Producer: Django signal handlers in products/feature_flags/backend/flags_cache.py.
# Consumer: rust/feature-flags flags-cache-builder bin. Not a plugin-server
# concern — no Node-side mirror needed.
KAFKA_FLAGS_CACHE_INVALIDATION = f"{KAFKA_PREFIX}flags_cache_invalidation{SUFFIX}"
KAFKA_FLAGS_CACHE_INVALIDATION_DLQ = f"{KAFKA_PREFIX}flags_cache_invalidation_dlq{SUFFIX}"

# Producer: customer_analytics person-property sync activity (warehouse -> person props).
# Consumer: a dedicated throttling consumer that rate-limits $set events into capture-internal.
KAFKA_WAREHOUSE_PERSON_PROPERTY_UPDATES = f"{KAFKA_PREFIX}warehouse_person_property_updates{SUFFIX}"
KAFKA_WAREHOUSE_PERSON_PROPERTY_UPDATES_DLQ = f"{KAFKA_PREFIX}warehouse_person_property_updates_dlq{SUFFIX}"
