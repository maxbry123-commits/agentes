from typing import Optional

from posthog.hogql import ast
from posthog.hogql.context import HogQLContext
from posthog.hogql.database.models import (
    DateTimeDatabaseField,
    FieldOrTable,
    FloatArrayDatabaseField,
    IntegerDatabaseField,
    LazyTable,
    LazyTableToAdd,
    StringDatabaseField,
    StringJSONDatabaseField,
    Table,
)
from posthog.hogql.transforms.order_by_pushdown import push_down_order_by, resolve_alias, unwrap_alias

from products.error_tracking.backend.indexed_embedding import EMBEDDING_TABLES

VECTOR_DISTANCE_FUNCTIONS = {"cosineDistance", "L2Distance"}
DOCUMENT_EMBEDDINGS_VIEW = "posthog_document_embeddings_union_view"

DOCUMENT_EMBEDDINGS_FIELDS: dict[str, FieldOrTable] = {
    "team_id": IntegerDatabaseField(name="team_id", nullable=False),
    "product": StringDatabaseField(
        name="product",
        nullable=False,
        description="PostHog product the embedded document belongs to, e.g. 'error_tracking'.",
    ),
    "document_type": StringDatabaseField(
        name="document_type", nullable=False, description="Type of document this embedding represents."
    ),
    "model_name": StringDatabaseField(
        name="model_name",
        nullable=False,
        description="Embedding model used; queries must filter on this to route to the correct model-specific table.",
    ),
    "rendering": StringDatabaseField(
        name="rendering", nullable=False, description="How the document was rendered to text before embedding."
    ),
    "document_id": StringDatabaseField(
        name="document_id", nullable=False, description="Identifier of the source document that was embedded."
    ),
    "timestamp": DateTimeDatabaseField(
        name="timestamp", nullable=False, description="Timestamp of the source document."
    ),
    "inserted_at": DateTimeDatabaseField(
        name="inserted_at", nullable=False, description="When this embedding row was inserted."
    ),
    "content": StringDatabaseField(name="content", nullable=False, description="The text content that was embedded."),
    "metadata": StringJSONDatabaseField(
        name="metadata", nullable=False, description="JSON metadata about the document/embedding."
    ),
    "embedding": FloatArrayDatabaseField(
        name="embedding",
        nullable=False,
        description="The embedding vector; compare with `cosineDistance`/`L2Distance` for semantic search.",
    ),
}


def get_field_val_pair(node) -> tuple[Optional[ast.Field], Optional[ast.Constant]]:
    left, right = None, None
    if isinstance(node, ast.CompareOperation) and node.op == ast.CompareOperationOp.Eq:
        left, right = unwrap_alias(node.left), unwrap_alias(node.right)
    elif isinstance(node, ast.Call) and node.name == "equals":
        if len(node.args) == 2:
            left, right = unwrap_alias(node.args[0]), unwrap_alias(node.args[1])

    if isinstance(left, ast.Constant) and isinstance(right, ast.Field):
        left, right = right, left
    if not isinstance(left, ast.Field) or not isinstance(right, ast.Constant):
        return None, None
    return left, right


def is_vector_distance_call(expr: ast.Expr) -> bool:
    expr = unwrap_alias(expr)
    if not isinstance(expr, ast.Call) or expr.name not in VECTOR_DISTANCE_FUNCTIONS:
        return False
    for arg in expr.args:
        unwrapped = unwrap_alias(arg)
        if isinstance(unwrapped, ast.Field) and unwrapped.chain and unwrapped.chain[-1] == "embedding":
            return True
    return False


def is_vector_distance_order_by(order_expr: ast.OrderExpr, node: ast.SelectQuery) -> bool:
    if is_vector_distance_call(order_expr.expr):
        return True
    resolved = resolve_alias(order_expr.expr, node)
    return resolved is not None and is_vector_distance_call(resolved)


def extract_model_name_from_where(node: Optional[ast.Expr]) -> Optional[str]:
    if not node:
        return None

    if isinstance(node, ast.And):
        for expr in node.exprs:
            result = extract_model_name_from_where(expr)
            if result:
                return result

    field, value = get_field_val_pair(node)
    if not field or not value:
        return None

    if len(field.chain) > 0 and field.chain[-1] == "model_name":
        return value.value

    return None


class ModelSpecificEmbeddingTable(Table):
    description: str = "Document embeddings for a single embedding model; the `model_name` column is fixed per table."
    model_name: str = ""
    clickhouse_table_name: str = ""

    def __init__(self, model_name: str, table_name: str):
        fields = {k: v for k, v in DOCUMENT_EMBEDDINGS_FIELDS.items() if k != "model_name"}
        super().__init__(fields=fields)
        self.model_name = model_name
        self.clickhouse_table_name = table_name

    def to_printed_clickhouse(self, context: HogQLContext):
        return self.clickhouse_table_name

    def to_printed_hogql(self):
        return f"document_embeddings_{self.model_name.replace('-', '_')}"


HOGQL_EMBEDDING_TABLES = {
    table.model_name: ModelSpecificEmbeddingTable(
        model_name=table.model_name, table_name=table.distributed_table_name()
    )
    for table in EMBEDDING_TABLES
}

HOGQL_MODEL_TABLES = {table.to_printed_hogql(): table for table in HOGQL_EMBEDDING_TABLES.values()}


class DocumentEmbeddingsTable(LazyTable):
    description: str = "Vector embeddings of PostHog documents for semantic search; queries must filter on `model_name` to route to the right model-specific table."
    fields: dict[str, FieldOrTable] = DOCUMENT_EMBEDDINGS_FIELDS

    def lazy_select(
        self,
        table_to_add: LazyTableToAdd,
        context: HogQLContext,
        node: ast.SelectQuery,
    ):
        requested_fields = table_to_add.fields_accessed
        if "document_id" not in requested_fields:
            requested_fields = {**requested_fields, "document_id": ["document_id"]}

        model_name = extract_model_name_from_where(node.where if node else None)

        if model_name and model_name in HOGQL_EMBEDDING_TABLES:
            model_table = HOGQL_EMBEDDING_TABLES[model_name]
            table_name = model_table.to_printed_hogql()

            exprs: list[ast.Expr] = []
            for name, chain in requested_fields.items():
                if name == "model_name":
                    exprs.append(ast.Alias(alias="model_name", expr=ast.Constant(value=model_table.model_name)))
                else:
                    exprs.append(ast.Alias(alias=name, expr=ast.Field(chain=[table_name, *chain])))

            inner_query = ast.SelectQuery(
                select=exprs,
                select_from=ast.JoinExpr(
                    table=ast.Field(chain=[table_name]),
                ),
            )

            push_down_order_by(
                outer_query=node,
                inner_query=inner_query,
                outer_table_alias="document_embeddings",
                inner_table_name=table_name,
                should_push_down=is_vector_distance_order_by,
            )

            return inner_query
        else:
            raise ValueError(f"Invalid model name: {model_name}")

    def to_printed_clickhouse(self, context: HogQLContext):
        raise NotImplementedError("LazyTables cannot be printed to ClickHouse SQL")

    def to_printed_hogql(self):
        return "document_embeddings"


class RawDocumentEmbeddingsTable(Table):
    description: str = (
        "Union view over all model-specific document embedding tables; prefer `document_embeddings` for queries."
    )
    fields: dict[str, FieldOrTable] = DOCUMENT_EMBEDDINGS_FIELDS

    def to_printed_clickhouse(self, context: HogQLContext):
        return DOCUMENT_EMBEDDINGS_VIEW

    def to_printed_hogql(self):
        return "raw_document_embeddings"
