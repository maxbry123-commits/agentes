//! End-to-end check of the 09a-style baml_src → baml_sdk pipeline.
//!
//! Drives codegen from real `.baml` source through the full
//! `baml_project::build_symbol_pool` path (parse → HIR → TIR → SymbolPool
//! → emitter).
//!
//! Scope (subset of 09a-codegen-example-scenario.md):
//! - user.lorem.Resume + ExtractResume (direct/spec/stream projections)
//! - user.lorem.StreamingDoc + StreamingExtract (pins the always-different
//!   `$stream` partial-model branch; folded in from the former
//!   `python_llm_functions` crate)
//! - user.ipsum.Sentiment (enum) + ClassifySentiment
//! - stream_types/lorem leaf presence

#[test]
fn test_main_root_imports_cleanly() {
    // ADAPTATION(rust): python asserts `import baml_sdk` succeeds at
    // runtime; crate-root reachability is a compile-time fact here.
    use baml_sdk as _;
}

#[test]
fn test_main_namespaces_reachable_via_explicit_import() {
    let _ = baml_sdk::ipsum::ClassifySentiment;
    let _ = baml_sdk::lorem::ExtractResume;
}

#[test]
fn test_main_lorem_resume_class_shape() {
    use baml_sdk::lorem::Resume;

    // ADAPTATION(rust): python asserts `Resume` is a pydantic model whose
    // field set is exactly {name, email}; the exhaustive struct literal pins
    // the same field set at compile time (a missing or extra field would
    // not compile).
    let _ = Resume {
        name: "Ada".to_string(),
        email: None,
    };
}

#[test]
fn test_main_lorem_streaming_doc_class_shape() {
    use baml_sdk::lorem::StreamingDoc;

    // ADAPTATION(rust): the exhaustive struct literal pins the field set
    // {title, body, word_count} at compile time.
    let _ = StreamingDoc {
        title: "t".to_string(),
        body: None,
        word_count: 0,
    };
}

#[test]
fn test_main_ipsum_sentiment_enum_shape() {
    use baml_sdk::ipsum::Sentiment;

    // ADAPTATION(rust): python iterates the enum to assert the variant-name
    // set; the wildcard-free match pins the same exact set at compile time
    // (a variant added or removed would not compile).
    match Sentiment::POSITIVE {
        Sentiment::POSITIVE | Sentiment::NEGATIVE | Sentiment::NEUTRAL => {}
    }
    // 09b: enum values are the variant name verbatim, mixed with `str`
    // so they round-trip through JSON.
    // DIVERGENCE(rust): the str mixin is a python representation detail;
    // a Rust enum carries no value-level string — the variant name itself
    // is the wire identity, pinned by the serialization round trips.
}

#[test]
fn test_main_extract_resume_factory_bindings() {
    // Sync + async siblings at the namespace leaf, per 09b §4.
    // ADAPTATION(rust): python asserts `callable(...)`; taking the function
    // items as values asserts existence at compile time, and fn items are
    // callable by construction.
    use baml_sdk::lorem;

    let _ = lorem::ExtractResume;
    let _ = lorem::ExtractResume_async;
}

// SDK_PARITY_LINT(skip): pins Rust generated spec and stream binding spellings
#[test]
fn test_main_extract_resume_spec_and_stream_bindings() {
    use baml_sdk::lorem;

    let _ = lorem::ExtractResume_spec;
    let _ = lorem::ExtractResume_spec_async;
    let _ = lorem::ExtractResume_stream;
    let _ = lorem::ExtractResume_stream_async;
    let _ = lorem::ExtractResume_stream_with;
    let _ = lorem::ExtractResume_stream_with_async;
}

#[test]
fn test_main_streaming_extract_factory_bindings() {
    use baml_sdk::lorem;

    let _ = lorem::StreamingExtract;
    let _ = lorem::StreamingExtract_async;
}

// SDK_PARITY_LINT(skip): pins Rust generated streaming spec and stream binding spellings
#[test]
fn test_main_streaming_extract_spec_and_stream_bindings() {
    use baml_sdk::lorem;

    let _ = lorem::StreamingExtract_spec;
    let _ = lorem::StreamingExtract_spec_async;
    let _ = lorem::StreamingExtract_stream;
    let _ = lorem::StreamingExtract_stream_async;
}

#[test]
fn test_main_stream_types_lorem_leaf_present() {
    // PPIR synthesizes Class$stream partial models for any class referenced
    // by an LLM function's return type. Both Resume and StreamingDoc
    // are LLM return types, so `stream_types.lorem` must exist with at
    // least one of them. StreamingDoc's conditional-emit outcome is
    // pinned to "emitted" (its `body string?` proxies a
    // stream-state-altering field); Resume's is left to the
    // conditional-emit rule.
    // ADAPTATION(rust): python probes `hasattr` for "at least one of" the
    // two companions; an any-of probe is inexpressible at compile time, so
    // this references the leaf module plus the one companion whose emission
    // is pinned (StreamingDoc) and leaves Resume's to the conditional-emit
    // rule.
    let _ = std::mem::size_of::<baml_sdk::stream_types::lorem::StreamingDoc>();
}

#[test]
fn test_main_classify_sentiment_factory_bindings() {
    use baml_sdk::ipsum;

    let _ = ipsum::ClassifySentiment;
    let _ = ipsum::ClassifySentiment_async;
}

// SDK_PARITY_LINT(skip): validates Rust's generated FunctionSpec prompt, parse, and request surface
#[test]
fn test_main_spec_replaces_prompt_parse_and_request_companions() {
    use baml_sdk::{
        baml::http::Request,
        lorem::{ExtractResume_spec, Resume},
    };

    let spec = ExtractResume_spec("Ada Lovelace".to_string()).unwrap();
    let prompt = spec.prompt().unwrap();
    let rendered = prompt.text().unwrap();
    assert!(rendered.contains("Ada Lovelace"));
    assert_eq!(prompt.text().unwrap(), rendered);

    let parsed: Resume = spec
        .parse(r#"{"name":"Ada Lovelace","email":null}"#.to_string())
        .unwrap();
    assert_eq!(parsed.name, "Ada Lovelace");
    assert_eq!(parsed.email, None);

    let request: Request = spec.build_request().unwrap();
    assert_eq!(request.method, "POST");
    assert!(!request.body.is_empty());
}

// ---------------------------------------------------------------------------
// Replay-harness surface (bridge-generics/streaming/02). Codegen-shape only;
// the keyless behavioral tests live in `test_streaming_e2e.rs` (string- and
// class-typed `T`). The replay client is the unified env-driven `StreamStub`
// (no separate Replay* functions).
// ---------------------------------------------------------------------------

#[test]
fn test_main_replay_server_namespace_bindings() {
    // The BAML-implemented replay server lives in the `replay` namespace
    // (ns_replay/). Both invocation entry points get sync + async siblings.
    use baml_sdk::replay;

    let _ = replay::replay_serve_until_shutdown;
    let _ = replay::replay_serve_until_shutdown_async;
    let _ = replay::replay_serve_detached;
    let _ = replay::replay_serve_detached_async;
}

// NOTE: the shorthand-client api_key wiring tests that lived here inspected
// the auth header on `*$build_request`'s Request. That companion went away
// with the legacy LLM path (credentials now resolve inside the provider's
// `invoke`, at request time), so there is no pre-network Request to inspect.
// Coverage moved to the live smokes in `_planv2/baml_src/live/`.
