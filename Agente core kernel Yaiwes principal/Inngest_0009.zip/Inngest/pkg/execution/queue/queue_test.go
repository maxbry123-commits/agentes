package queue

import (
	"fmt"
	"testing"
	"time"

	"github.com/stretchr/testify/require"
)

type retryableError struct {
	error
	retry bool
}

func TestPartitionBacklogSizeConcurrencyOption(t *testing.T) {
	t.Run("default", func(t *testing.T) {
		opts := NewQueueOptions()
		require.Equal(t, defaultPartitionBacklogSizeConcurrency, opts.PartitionBacklogSizeConcurrency())
	})

	t.Run("custom", func(t *testing.T) {
		opts := NewQueueOptions(WithPartitionBacklogSizeConcurrency(7))
		require.Equal(t, int64(7), opts.PartitionBacklogSizeConcurrency())
	})

	t.Run("invalid falls back to default", func(t *testing.T) {
		opts := NewQueueOptions(WithPartitionBacklogSizeConcurrency(0))
		require.Equal(t, defaultPartitionBacklogSizeConcurrency, opts.PartitionBacklogSizeConcurrency())

		opts = NewQueueOptions(WithPartitionBacklogSizeConcurrency(-1))
		require.Equal(t, defaultPartitionBacklogSizeConcurrency, opts.PartitionBacklogSizeConcurrency())
	})
}

func (r retryableError) Retryable() bool {
	return r.retry
}

func TestShouldRetry(t *testing.T) {
	tests := []struct {
		err      error
		att      int
		max      int
		expected bool
	}{
		{
			fmt.Errorf("basic err retries"),
			1,
			5,
			true,
		},
		{
			fmt.Errorf("basic err fails at max attempts"),
			2, // 0, 1, 2 - off by one from zero index.
			3,
			false,
		},
		{
			retryableError{error: fmt.Errorf("retries if returns true"), retry: true},
			1,
			5,
			true,
		},
		{
			retryableError{error: fmt.Errorf("doesnt retry at max"), retry: true},
			5,
			5,
			false,
		},
		{
			retryableError{error: fmt.Errorf("doesnt retry if Retryable returns false"), retry: false},
			1,
			5,
			false,
		},
		{
			alwaysRetry{error: fmt.Errorf("always even if over max")},
			10,
			5,
			true,
		},
	}

	for _, test := range tests {
		actual := ShouldRetry(test.err, test.att, test.max)
		require.Equal(t, test.expected, actual)
	}
}

func TestAsRetryAt(t *testing.T) {
	now := time.Now()
	base := RetryAtError(fmt.Errorf("lol"), &now)
	wrapped := fmt.Errorf("wrap: %w", base)

	require.NotNil(t, AsRetryAtError(base))
	require.NotNil(t, AsRetryAtError(wrapped))
	require.Nil(t, AsRetryAtError(fmt.Errorf("no")))
}
