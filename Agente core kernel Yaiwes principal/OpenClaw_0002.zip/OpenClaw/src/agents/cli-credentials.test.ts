/** Tests CLI credential parsing and cache expiry. */
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { afterEach, beforeAll, beforeEach, describe, expect, it, vi } from "vitest";

const execSyncMock = vi.fn();
const CLI_CREDENTIALS_CACHE_TTL_MS = 15 * 60 * 1000;
let readCodexCliActiveApiKey: typeof import("./cli-credentials.js").readCodexCliActiveApiKey;
let readCodexCliCredentialsCached: typeof import("./cli-credentials.js").readCodexCliCredentialsCached;
let readGeminiCliCredentialsCached: typeof import("./cli-credentials.js").readGeminiCliCredentialsCached;
let readMiniMaxCliCredentialsCached: typeof import("./cli-credentials.js").readMiniMaxCliCredentialsCached;
let readCodexAuth: typeof import("./cli-auth.test-support.js").readCodexAuth;
let resetCliAuthCaches: typeof import("./cli-auth.test-support.js").resetCliAuthCaches;

function createJwtWithExp(expSeconds: number): string {
  // Signature verification is out of scope; expiration extraction only needs a
  // syntactically valid JWT-like payload.
  const encode = (value: Record<string, unknown>) =>
    Buffer.from(JSON.stringify(value)).toString("base64url");
  return `${encode({ alg: "RS256", typ: "JWT" })}.${encode({ exp: expSeconds })}.signature`;
}

function expectFields(value: unknown, expected: Record<string, unknown>): void {
  // Keeps large credential objects readable while still asserting exact fields
  // relevant to the branch under test.
  if (!value || typeof value !== "object") {
    throw new Error("expected fields object");
  }
  const record = value as Record<string, unknown>;
  for (const [key, expectedValue] of Object.entries(expected)) {
    expect(record[key], key).toEqual(expectedValue);
  }
}

describe("cli credentials", () => {
  beforeAll(async () => {
    ({
      readCodexCliActiveApiKey,
      readCodexCliCredentialsCached,
      readGeminiCliCredentialsCached,
      readMiniMaxCliCredentialsCached,
    } = await import("./cli-credentials.js"));
    ({ readCodexAuth, resetCliAuthCaches } = await import("./cli-auth.test-support.js"));
  });

  beforeEach(() => {
    vi.useFakeTimers();
  });

  afterEach(() => {
    vi.useRealTimers();
    execSyncMock.mockClear().mockImplementation(() => undefined);
    delete process.env.CODEX_HOME;
    vi.unstubAllEnvs();
    resetCliAuthCaches();
  });

  it("keeps external CLI credential files anchored to the OS home", () => {
    const osHome = fs.mkdtempSync(path.join(os.tmpdir(), "openclaw-os-home-"));
    const openClawHome = fs.mkdtempSync(path.join(os.tmpdir(), "openclaw-effective-home-"));
    const expires = Date.parse("2036-04-25T12:00:00Z");
    const codexExpiry = Math.floor(expires / 1000);
    vi.stubEnv("HOME", osHome);
    vi.stubEnv("OPENCLAW_HOME", openClawHome);
    delete process.env.CODEX_HOME;
    try {
      const files = [
        {
          filePath: path.join(osHome, ".codex", "auth.json"),
          value: {
            tokens: {
              access_token: createJwtWithExp(codexExpiry),
              refresh_token: "codex-refresh",
            },
          },
        },
        {
          filePath: path.join(osHome, ".minimax", "oauth_creds.json"),
          value: {
            access_token: "minimax-access",
            refresh_token: "minimax-refresh",
            expiry_date: expires,
          },
        },
        {
          filePath: path.join(osHome, ".gemini", "oauth_creds.json"),
          value: {
            access_token: "gemini-access",
            refresh_token: "gemini-refresh",
            expiry_date: expires,
          },
        },
      ];
      for (const file of files) {
        fs.mkdirSync(path.dirname(file.filePath), { recursive: true, mode: 0o700 });
        fs.writeFileSync(file.filePath, JSON.stringify(file.value), "utf8");
      }
      const decoys = [
        {
          filePath: path.join(openClawHome, ".codex", "auth.json"),
          value: {
            tokens: {
              access_token: createJwtWithExp(codexExpiry),
              refresh_token: "decoy-codex-refresh",
            },
          },
        },
        {
          filePath: path.join(openClawHome, ".minimax", "oauth_creds.json"),
          value: {
            access_token: "decoy-minimax-access",
            refresh_token: "decoy-minimax-refresh",
            expiry_date: expires,
          },
        },
        {
          filePath: path.join(openClawHome, ".gemini", "oauth_creds.json"),
          value: {
            access_token: "decoy-gemini-access",
            refresh_token: "decoy-gemini-refresh",
            expiry_date: expires,
          },
        },
      ];
      for (const file of decoys) {
        fs.mkdirSync(path.dirname(file.filePath), { recursive: true, mode: 0o700 });
        fs.writeFileSync(file.filePath, JSON.stringify(file.value), "utf8");
      }

      expectFields(
        readCodexCliCredentialsCached({
          allowKeychainPrompt: false,
          platform: "linux",
          ttlMs: 0,
        }),
        { refresh: "codex-refresh", provider: "openai" },
      );
      expectFields(readMiniMaxCliCredentialsCached({ ttlMs: 0 }), {
        access: "minimax-access",
        refresh: "minimax-refresh",
      });
      expectFields(readGeminiCliCredentialsCached({ ttlMs: 0 }), {
        access: "gemini-access",
        refresh: "gemini-refresh",
      });
    } finally {
      fs.rmSync(osHome, { recursive: true, force: true });
      fs.rmSync(openClawHome, { recursive: true, force: true });
    }
  });

  it("reads Codex credentials from keychain when available", () => {
    const tempHome = fs.mkdtempSync(path.join(os.tmpdir(), "openclaw-codex-"));
    process.env.CODEX_HOME = tempHome;
    const expSeconds = Math.floor(Date.parse("2026-03-23T00:48:49Z") / 1000);

    const accountHash = "cli|";

    execSyncMock.mockImplementation((command: unknown) => {
      const cmd = String(command);
      expect(cmd).toContain("Codex Auth");
      expect(cmd).toContain(accountHash);
      return JSON.stringify({
        tokens: {
          id_token: "keychain-id-token",
          access_token: createJwtWithExp(expSeconds),
          refresh_token: "keychain-refresh",
        },
        last_refresh: "2026-01-01T00:00:00Z",
      });
    });

    const creds = readCodexAuth({ platform: "darwin", execSync: execSyncMock });

    expectFields(creds, {
      access: createJwtWithExp(expSeconds),
      refresh: "keychain-refresh",
      provider: "openai",
      expires: expSeconds * 1000,
      idToken: "keychain-id-token",
    });
  });

  it("falls back when Codex keychain JWT expiry is outside Date range", () => {
    const tempHome = fs.mkdtempSync(path.join(os.tmpdir(), "openclaw-codex-"));
    process.env.CODEX_HOME = tempHome;
    const lastRefresh = Date.parse("2026-01-01T00:00:00Z");
    const fallbackExpiry = lastRefresh + 60 * 60 * 1000;
    const accountHash = "cli|";

    execSyncMock.mockImplementation((command: unknown) => {
      const cmd = String(command);
      expect(cmd).toContain("Codex Auth");
      expect(cmd).toContain(accountHash);
      return JSON.stringify({
        tokens: {
          access_token: createJwtWithExp(8_700_000_000_000),
          refresh_token: "keychain-refresh",
        },
        last_refresh: "2026-01-01T00:00:00Z",
      });
    });

    const creds = readCodexAuth({ platform: "darwin", execSync: execSyncMock });

    expectFields(creds, {
      refresh: "keychain-refresh",
      provider: "openai",
      expires: fallbackExpiry,
    });
  });

  it("rejects Codex keychain fallback expiry when the process clock is invalid", () => {
    const tempHome = fs.mkdtempSync(path.join(os.tmpdir(), "openclaw-codex-"));
    process.env.CODEX_HOME = tempHome;
    const accountHash = "cli|";
    const dateNowSpy = vi.spyOn(Date, "now").mockReturnValue(Number.NaN);
    try {
      execSyncMock.mockImplementation((command: unknown) => {
        const cmd = String(command);
        expect(cmd).toContain("Codex Auth");
        expect(cmd).toContain(accountHash);
        return JSON.stringify({
          tokens: {
            access_token: createJwtWithExp(8_700_000_000_000),
            refresh_token: "keychain-refresh",
          },
        });
      });

      expect(readCodexAuth({ platform: "darwin", execSync: execSyncMock })).toBeNull();
    } finally {
      dateNowSpy.mockRestore();
    }
  });

  it("falls back to Codex auth.json when keychain is unavailable", () => {
    const tempHome = fs.mkdtempSync(path.join(os.tmpdir(), "openclaw-codex-"));
    process.env.CODEX_HOME = tempHome;
    const expSeconds = Math.floor(Date.parse("2026-03-24T12:34:56Z") / 1000);
    execSyncMock.mockImplementation(() => {
      throw new Error("not found");
    });

    const authPath = path.join(tempHome, "auth.json");
    fs.mkdirSync(tempHome, { recursive: true, mode: 0o700 });
    fs.writeFileSync(
      authPath,
      JSON.stringify({
        tokens: {
          id_token: "file-id-token",
          access_token: createJwtWithExp(expSeconds),
          refresh_token: "file-refresh",
        },
      }),
      "utf8",
    );

    const creds = readCodexAuth({ execSync: execSyncMock });

    expectFields(creds, {
      access: createJwtWithExp(expSeconds),
      refresh: "file-refresh",
      provider: "openai",
      expires: expSeconds * 1000,
      idToken: "file-id-token",
    });
  });

  it("does not read stale Codex tokens when auth.json resolves to API-key mode", () => {
    const tempHome = fs.mkdtempSync(path.join(os.tmpdir(), "openclaw-codex-api-key-mode-"));
    process.env.CODEX_HOME = tempHome;
    const expSeconds = Math.floor(Date.parse("2026-03-24T12:34:56Z") / 1000);
    execSyncMock.mockImplementation(() => {
      throw new Error("not found");
    });

    const authPath = path.join(tempHome, "auth.json");
    fs.mkdirSync(tempHome, { recursive: true, mode: 0o700 });
    fs.writeFileSync(
      authPath,
      JSON.stringify({
        auth_mode: "apikey",
        OPENAI_API_KEY: "sk-codex-api-key",
        tokens: {
          access_token: createJwtWithExp(expSeconds),
          refresh_token: "stale-file-refresh",
        },
      }),
      "utf8",
    );

    expect(readCodexAuth({ platform: "linux", execSync: execSyncMock })).toBeNull();
  });

  it("reads API-key auth from the active Codex Keychain store", () => {
    const tempHome = fs.mkdtempSync(path.join(os.tmpdir(), "openclaw-codex-keychain-api-key-"));
    execSyncMock.mockImplementation((command: unknown) =>
      String(command).includes("codex login status")
        ? "Logged in using an API key - keychain***i-key"
        : JSON.stringify({ auth_mode: "apikey", OPENAI_API_KEY: "keychain-api-key" }),
    );

    expect(
      readCodexCliActiveApiKey({
        codexHome: tempHome,
        platform: "darwin",
        execSync: execSyncMock,
      }),
    ).toEqual({ type: "api_key", provider: "openai", key: "keychain-api-key" });
  });

  it("prefers active Codex OAuth over a stale file API key", () => {
    const tempHome = fs.mkdtempSync(path.join(os.tmpdir(), "openclaw-codex-keychain-oauth-"));
    fs.writeFileSync(
      path.join(tempHome, "auth.json"),
      JSON.stringify({ auth_mode: "apikey", OPENAI_API_KEY: "stale-file-api-key" }),
      "utf8",
    );
    execSyncMock.mockReturnValue("Logged in using ChatGPT");

    expect(
      readCodexCliActiveApiKey({
        codexHome: tempHome,
        platform: "darwin",
        execSync: execSyncMock,
      }),
    ).toBeNull();
    expect(execSyncMock).toHaveBeenCalledTimes(1);
  });

  it("uses the API key that Codex reports active instead of a stale Keychain record", () => {
    const tempHome = fs.mkdtempSync(path.join(os.tmpdir(), "openclaw-codex-default-file-"));
    fs.writeFileSync(
      path.join(tempHome, "auth.json"),
      JSON.stringify({ auth_mode: "apikey", OPENAI_API_KEY: "active-file-api-key" }),
      "utf8",
    );
    execSyncMock.mockImplementation((command: unknown) =>
      String(command).includes("codex login status")
        ? "Logged in using an API key - active-f***i-key"
        : JSON.stringify({ auth_mode: "apikey", OPENAI_API_KEY: "stale-keychain-api-key" }),
    );

    expect(
      readCodexCliActiveApiKey({
        codexHome: tempHome,
        platform: "darwin",
        execSync: execSyncMock,
      }),
    ).toEqual({ type: "api_key", provider: "openai", key: "active-file-api-key" });
    expect(execSyncMock).toHaveBeenCalledTimes(2);
  });

  it("accepts legacy Codex API-key status only with one readable candidate", () => {
    const tempHome = fs.mkdtempSync(path.join(os.tmpdir(), "openclaw-codex-legacy-status-"));
    fs.writeFileSync(
      path.join(tempHome, "auth.json"),
      JSON.stringify({ auth_mode: "apikey", OPENAI_API_KEY: "legacy-file-api-key" }),
      "utf8",
    );
    execSyncMock.mockReturnValue("Logged in using an API key");

    expect(
      readCodexCliActiveApiKey({
        codexHome: tempHome,
        platform: "linux",
        execSync: execSyncMock,
      }),
    ).toEqual({ type: "api_key", provider: "openai", key: "legacy-file-api-key" });
  });

  it("treats an empty Codex auth.json API-key field as API-key mode", () => {
    const tempHome = fs.mkdtempSync(path.join(os.tmpdir(), "openclaw-codex-empty-api-key-mode-"));
    process.env.CODEX_HOME = tempHome;
    const expSeconds = Math.floor(Date.parse("2026-03-24T12:34:56Z") / 1000);
    execSyncMock.mockImplementation(() => {
      throw new Error("not found");
    });

    const authPath = path.join(tempHome, "auth.json");
    fs.mkdirSync(tempHome, { recursive: true, mode: 0o700 });
    fs.writeFileSync(
      authPath,
      JSON.stringify({
        OPENAI_API_KEY: "",
        tokens: {
          access_token: createJwtWithExp(expSeconds),
          refresh_token: "stale-file-refresh",
        },
      }),
      "utf8",
    );

    expect(readCodexAuth({ platform: "linux", execSync: execSyncMock })).toBeNull();
  });

  it("rejects Codex auth.json fallback expiry when stat and process clock are invalid", () => {
    const tempHome = fs.mkdtempSync(path.join(os.tmpdir(), "openclaw-codex-invalid-clock-"));
    process.env.CODEX_HOME = tempHome;
    const authPath = path.join(tempHome, "auth.json");
    fs.mkdirSync(tempHome, { recursive: true, mode: 0o700 });
    fs.writeFileSync(
      authPath,
      JSON.stringify({
        tokens: {
          access_token: createJwtWithExp(8_700_000_000_000),
          refresh_token: "file-refresh",
        },
      }),
      "utf8",
    );
    execSyncMock.mockImplementation(() => {
      throw new Error("not found");
    });
    const statSyncSpy = vi.spyOn(fs, "statSync").mockImplementation(() => {
      throw new Error("stat unavailable");
    });
    const dateNowSpy = vi.spyOn(Date, "now").mockReturnValue(Number.NaN);
    try {
      expect(readCodexAuth({ platform: "linux", execSync: execSyncMock })).toBeNull();
    } finally {
      dateNowSpy.mockRestore();
      statSyncSpy.mockRestore();
    }
  });

  it("uses Codex auth.json fallback expiry when file mtime has fractional milliseconds", () => {
    const tempHome = fs.mkdtempSync(path.join(os.tmpdir(), "openclaw-codex-fractional-mtime-"));
    process.env.CODEX_HOME = tempHome;
    const authPath = path.join(tempHome, "auth.json");
    fs.mkdirSync(tempHome, { recursive: true, mode: 0o700 });
    fs.writeFileSync(
      authPath,
      JSON.stringify({
        tokens: {
          access_token: createJwtWithExp(8_700_000_000_000),
          refresh_token: "file-refresh",
        },
      }),
      "utf8",
    );
    execSyncMock.mockImplementation(() => {
      throw new Error("not found");
    });
    const mtimeMs = Date.parse("2026-03-24T10:00:00Z") + 0.75;
    const statSyncSpy = vi.spyOn(fs, "statSync").mockReturnValue({ mtimeMs } as fs.Stats);
    try {
      const creds = readCodexAuth({ platform: "linux", execSync: execSyncMock });

      expectFields(creds, {
        refresh: "file-refresh",
        provider: "openai",
        expires: Math.floor(mtimeMs) + 60 * 60 * 1000,
      });
    } finally {
      statSyncSpy.mockRestore();
    }
  });

  it("does not read Codex keychain when keychain prompts are disabled", () => {
    const tempHome = fs.mkdtempSync(path.join(os.tmpdir(), "openclaw-codex-no-prompt-"));
    process.env.CODEX_HOME = tempHome;
    const expSeconds = Math.floor(Date.parse("2026-03-24T12:34:56Z") / 1000);
    const authPath = path.join(tempHome, "auth.json");
    fs.mkdirSync(tempHome, { recursive: true, mode: 0o700 });
    fs.writeFileSync(
      authPath,
      JSON.stringify({
        tokens: {
          access_token: createJwtWithExp(expSeconds),
          refresh_token: "file-refresh",
        },
      }),
      "utf8",
    );

    const creds = readCodexCliCredentialsCached({
      allowKeychainPrompt: false,
      ttlMs: CLI_CREDENTIALS_CACHE_TTL_MS,
      platform: "darwin",
      execSync: execSyncMock,
    });

    expectFields(creds, {
      access: createJwtWithExp(expSeconds),
      refresh: "file-refresh",
      provider: "openai",
    });
    expect(execSyncMock).not.toHaveBeenCalled();
  });

  it("does not let no-keychain Codex cache misses poison keychain reads", () => {
    const tempHome = fs.mkdtempSync(path.join(os.tmpdir(), "openclaw-codex-cache-"));
    process.env.CODEX_HOME = tempHome;
    const expSeconds = Math.floor(Date.parse("2026-03-24T12:34:56Z") / 1000);

    const withoutKeychain = readCodexCliCredentialsCached({
      allowKeychainPrompt: false,
      ttlMs: CLI_CREDENTIALS_CACHE_TTL_MS,
      platform: "darwin",
      execSync: execSyncMock,
    });
    expect(withoutKeychain).toBeNull();

    execSyncMock.mockReturnValue(
      JSON.stringify({
        tokens: {
          access_token: createJwtWithExp(expSeconds),
          refresh_token: "keychain-refresh",
        },
      }),
    );
    const withKeychain = readCodexCliCredentialsCached({
      allowKeychainPrompt: true,
      ttlMs: CLI_CREDENTIALS_CACHE_TTL_MS,
      platform: "darwin",
      execSync: execSyncMock,
    });

    expectFields(withKeychain, {
      access: createJwtWithExp(expSeconds),
      refresh: "keychain-refresh",
      provider: "openai",
    });
    expect(execSyncMock).toHaveBeenCalledTimes(1);
  });

  it("keeps no-prompt Codex reads on auth.json after a keychain read", () => {
    const tempHome = fs.mkdtempSync(path.join(os.tmpdir(), "openclaw-codex-cache-"));
    process.env.CODEX_HOME = tempHome;
    const keychainExpiry = Math.floor(Date.parse("2026-03-24T12:34:56Z") / 1000);
    const fileExpiry = Math.floor(Date.parse("2026-03-25T12:34:56Z") / 1000);
    const authPath = path.join(tempHome, "auth.json");
    fs.mkdirSync(tempHome, { recursive: true, mode: 0o700 });
    fs.writeFileSync(
      authPath,
      JSON.stringify({
        tokens: {
          access_token: createJwtWithExp(fileExpiry),
          refresh_token: "file-refresh",
        },
      }),
      "utf8",
    );
    execSyncMock.mockReturnValue(
      JSON.stringify({
        tokens: {
          access_token: createJwtWithExp(keychainExpiry),
          refresh_token: "keychain-refresh",
        },
      }),
    );

    const withKeychain = readCodexCliCredentialsCached({
      allowKeychainPrompt: true,
      ttlMs: CLI_CREDENTIALS_CACHE_TTL_MS,
      platform: "darwin",
      execSync: execSyncMock,
    });
    const withoutPrompt = readCodexCliCredentialsCached({
      allowKeychainPrompt: false,
      ttlMs: CLI_CREDENTIALS_CACHE_TTL_MS,
      platform: "darwin",
      execSync: execSyncMock,
    });

    expectFields(withKeychain, {
      refresh: "keychain-refresh",
      expires: keychainExpiry * 1000,
      provider: "openai",
    });
    expectFields(withoutPrompt, {
      refresh: "file-refresh",
      expires: fileExpiry * 1000,
      provider: "openai",
    });
    expect(execSyncMock).toHaveBeenCalledTimes(1);
  });

  it("invalidates cached Codex credentials when auth.json changes within the TTL window", () => {
    const tempHome = fs.mkdtempSync(path.join(os.tmpdir(), "openclaw-codex-cache-"));
    process.env.CODEX_HOME = tempHome;
    const authPath = path.join(tempHome, "auth.json");
    const firstExpiry = Math.floor(Date.parse("2026-03-24T12:34:56Z") / 1000);
    const secondExpiry = Math.floor(Date.parse("2026-03-25T12:34:56Z") / 1000);
    try {
      fs.mkdirSync(tempHome, { recursive: true, mode: 0o700 });
      fs.writeFileSync(
        authPath,
        JSON.stringify({
          tokens: {
            access_token: createJwtWithExp(firstExpiry),
            refresh_token: "stale-refresh",
          },
        }),
        "utf8",
      );
      fs.utimesSync(authPath, new Date("2026-03-24T10:00:00Z"), new Date("2026-03-24T10:00:00Z"));
      vi.setSystemTime(new Date("2026-03-24T10:00:00Z"));

      const first = readCodexCliCredentialsCached({
        ttlMs: CLI_CREDENTIALS_CACHE_TTL_MS,
        platform: "linux",
        execSync: execSyncMock,
      });

      expectFields(first, {
        refresh: "stale-refresh",
        expires: firstExpiry * 1000,
      });

      fs.writeFileSync(
        authPath,
        JSON.stringify({
          tokens: {
            access_token: createJwtWithExp(secondExpiry),
            refresh_token: "fresh-refresh",
          },
        }),
        "utf8",
      );
      fs.utimesSync(authPath, new Date("2026-03-24T10:05:00Z"), new Date("2026-03-24T10:05:00Z"));
      vi.advanceTimersByTime(60_000);

      const second = readCodexCliCredentialsCached({
        ttlMs: CLI_CREDENTIALS_CACHE_TTL_MS,
        platform: "linux",
        execSync: execSyncMock,
      });

      expectFields(second, {
        refresh: "fresh-refresh",
        expires: secondExpiry * 1000,
      });
    } finally {
      fs.rmSync(tempHome, { recursive: true, force: true });
    }
  });

  it("lifts Google account identity from the Gemini id_token", () => {
    const tempHome = fs.mkdtempSync(path.join(os.tmpdir(), "openclaw-gemini-"));
    try {
      const credPath = path.join(tempHome, ".gemini", "oauth_creds.json");
      fs.mkdirSync(path.dirname(credPath), { recursive: true, mode: 0o700 });
      const idTokenPayload = Buffer.from(
        JSON.stringify({ sub: "google-account-42", email: "user@example.com" }),
      ).toString("base64url");
      const idToken = `header.${idTokenPayload}.signature`;
      fs.writeFileSync(
        credPath,
        JSON.stringify({
          access_token: "gemini-access",
          refresh_token: "gemini-refresh",
          id_token: idToken,
          expiry_date: Date.parse("2026-04-25T12:00:00Z"),
        }),
        "utf8",
      );

      const creds = readGeminiCliCredentialsCached({ homeDir: tempHome, ttlMs: 0 });

      expectFields(creds, {
        type: "oauth",
        provider: "google-gemini-cli",
        access: "gemini-access",
        refresh: "gemini-refresh",
        accountId: "google-account-42",
        email: "user@example.com",
      });
    } finally {
      fs.rmSync(tempHome, { recursive: true, force: true });
    }
  });

  it("reads Gemini credentials without identity fields when id_token is absent", () => {
    const tempHome = fs.mkdtempSync(path.join(os.tmpdir(), "openclaw-gemini-noid-"));
    try {
      const credPath = path.join(tempHome, ".gemini", "oauth_creds.json");
      fs.mkdirSync(path.dirname(credPath), { recursive: true, mode: 0o700 });
      fs.writeFileSync(
        credPath,
        JSON.stringify({
          access_token: "gemini-access",
          refresh_token: "gemini-refresh",
          expiry_date: Date.parse("2026-04-25T12:00:00Z"),
        }),
        "utf8",
      );

      const creds = readGeminiCliCredentialsCached({ homeDir: tempHome, ttlMs: 0 });

      expectFields(creds, {
        type: "oauth",
        provider: "google-gemini-cli",
        access: "gemini-access",
        refresh: "gemini-refresh",
      });
      expect(creds?.accountId).toBeUndefined();
      expect(creds?.email).toBeUndefined();
    } finally {
      fs.rmSync(tempHome, { recursive: true, force: true });
    }
  });
});
