/** Shared bundle MCP catalog, runtime, and manager types. */
import type {
  CallToolResult,
  ListResourceTemplatesResult,
  ListToolsResult,
} from "@modelcontextprotocol/sdk/types.js";
import type { TSchema } from "typebox";
import type { SessionToolOverrides } from "../config/sessions/types.js";
import type { McpCodexToolApprovalMode, McpServerToolFilterConfig } from "../config/types.mcp.js";
import type { OpenClawConfig } from "../config/types.openclaw.js";
import type { PluginManifestRegistry } from "../plugins/manifest-registry.js";
import type { McpCodexToolAnnotations } from "./mcp-codex-tool-approval.js";
import type { AnyAgentTool } from "./tools/common.js";

/** Materialized MCP tools plus diagnostics and cleanup handle for one run. */
export type BundleMcpToolRuntime = {
  tools: AnyAgentTool[];
  /** All MCP tool-call projections, including App-only tools, for policy evaluation. */
  appTools?: AnyAgentTool[];
  diagnostics?: readonly McpToolCatalogDiagnostic[];
  restrictAppTools?: (tools: readonly AnyAgentTool[]) => void;
  dispose: () => Promise<void>;
};

/** Catalog metadata for one configured MCP server. */
export type McpServerCatalog = {
  serverName: string;
  safeServerName?: string;
  launchSummary: string;
  toolCount: number;
  resources?: {
    listChanged?: boolean;
  };
  prompts?: {
    listChanged?: boolean;
  };
  tools?: {
    listChanged?: boolean;
    filteredCount?: number;
  };
  requestTimeoutMs?: number;
  supportsParallelToolCalls?: boolean;
  toolFilter?: McpServerToolFilterConfig;
  deniedToolNames?: string[];
  codexApprovalMode?: McpCodexToolApprovalMode;
};

/** MCP tool entry after server-name sanitization and schema normalization. */
export type McpCatalogTool = {
  serverName: string;
  safeServerName: string;
  toolName: string;
  title?: string;
  description?: string;
  inputSchema: TSchema;
  fallbackDescription: string;
  uiResourceUri?: string;
  uiVisibility?: Array<"app" | "model">;
  /** Listed by the server but excluded from OpenClaw's callable tool catalog. */
  excludedFromOpenClawCatalog?: true;
  deniedBySession?: true;
  codexAnnotations?: McpCodexToolAnnotations;
};

/** Complete tool catalog for a session-scoped MCP runtime. */
export type McpToolCatalog = {
  version: number;
  generatedAt: number;
  servers: Record<string, McpServerCatalog>;
  tools: McpCatalogTool[];
  /** Complete raw catalog used to project policy into native MCP clients. */
  policyTools?: McpCatalogTool[];
  /** Listed tools hidden only by the session override, retained for read-only inventory. */
  sessionDeniedTools?: McpCatalogTool[];
  diagnostics?: readonly McpToolCatalogDiagnostic[];
};

/** Transient requester sign-in surface kept outside the remembered live catalog. */
export type RequesterMcpConnect = {
  catalog: McpToolCatalog;
  authorizedServerNames: readonly string[];
  configFingerprint: string;
  createExecute: (serverName: string) => AnyAgentTool["execute"] | undefined;
};

type PreparedNativeMcpServerPolicy = {
  serverName: string;
  safeServerName: string;
  allowedTools: string[];
  deniedTools: string[];
};

/** Concrete raw/safe policy fact prepared once for native MCP adapters. */
export type PreparedNativeMcpPolicy = {
  servers: Record<string, PreparedNativeMcpServerPolicy>;
};

export type McpToolCatalogDiagnostic = {
  serverName: string;
  safeServerName: string;
  launchSummary: string;
  message: string;
};

export type McpRequestOptions = {
  failureBackoff?: "track" | "ignore";
};

/** Trusted requester identity used to scope per-user MCP connections. */
export type SessionMcpRequesterScope = {
  requesterSenderId: string;
  agentAccountId?: string;
  messageChannel?: string;
};

/** Live MCP runtime bound to one session/workspace. */
export type SessionMcpRuntime = {
  sessionId: string;
  sessionKey?: string;
  workspaceDir: string;
  agentDir?: string;
  configFingerprint: string;
  /** Present when this runtime is keyed by requester-scoped connection identity. */
  requesterScope?: SessionMcpRequesterScope;
  requesterConnect?: RequesterMcpConnect;
  /**
   * True when the named server's connection is requester-scoped. App views for
   * such servers stay fail-closed: views outlive the requester-authenticated
   * run and the gateway view boundary carries no requester identity.
   */
  isRequesterScopedServer?: (serverName: string) => boolean;
  mcpAppsEnabled?: boolean;
  /** Latest non-persisted App context, owned by the exact live view that supplied it. */
  pendingMcpAppModelContext?: { owner: object; text: string; leased?: boolean };
  /** Blocks a deferred-retirement view from restoring context across reset. */
  mcpAppModelContextRevoked?: boolean;
  createdAt: number;
  lastUsedAt: number;
  activeLeases?: number;
  acquireLease?: () => () => void;
  /** Lists tools if needed and may connect MCP transports. */
  getCatalog: () => Promise<McpToolCatalog>;
  /** Returns the cached catalog only; must not start runtimes, connect transports, or issue tools/list. */
  peekCatalog: () => McpToolCatalog | null;
  /** Returns the configured request timeout for a server from the connected session, without touching the catalog. */
  getServerRequestTimeoutMs?: (serverName: string) => number | undefined;
  markUsed: () => void;
  callTool: (serverName: string, toolName: string, input: unknown) => Promise<CallToolResult>;
  listTools?: (serverName: string, params?: { cursor?: string }) => Promise<ListToolsResult>;
  listResources?: (serverName: string, options?: McpRequestOptions) => Promise<unknown>;
  readResource?: (serverName: string, uri: string, options?: McpRequestOptions) => Promise<unknown>;
  listResourceTemplates?: (
    serverName: string,
    params?: { cursor?: string },
  ) => Promise<ListResourceTemplatesResult>;
  listPrompts?: (serverName: string) => Promise<unknown>;
  getPrompt?: (serverName: string, name: string, args?: Record<string, string>) => Promise<unknown>;
  dispose: () => Promise<void>;
};

/** One requester call's runtime and immutable catalog publication version. */
export type RequesterScopedMcpRuntimeHandle = {
  runtime: SessionMcpRuntime;
  advertisedCatalogConfigFingerprint: string;
};

/** Manager for session-scoped MCP runtimes and their idle lifecycle. */
export type SessionMcpRuntimeManager = {
  getOrCreate: (params: {
    sessionId: string;
    sessionKey?: string;
    workspaceDir: string;
    agentDir?: string;
    cfg?: OpenClawConfig;
    manifestRegistry?: Pick<PluginManifestRegistry, "plugins">;
    /** Trusted sender id; required to materialize requester-scoped MCP servers. */
    requesterSenderId?: string | null;
    agentAccountId?: string | null;
    messageChannel?: string | null;
    toolOverrides?: Pick<SessionToolOverrides, "mcpServers" | "mcpToolsDeny">;
  }) => Promise<SessionMcpRuntime>;
  /**
   * Requester-scoped partition only — never creates static transports.
   * Undefined when no scoped servers, no senderId, or nothing resolves.
   */
  getOrCreateRequesterScoped: (params: {
    sessionId: string;
    sessionKey?: string;
    workspaceDir: string;
    agentDir?: string;
    cfg?: OpenClawConfig;
    manifestRegistry?: Pick<PluginManifestRegistry, "plugins">;
    requesterSenderId?: string | null;
    agentAccountId?: string | null;
    messageChannel?: string | null;
    toolOverrides?: Pick<SessionToolOverrides, "mcpServers" | "mcpToolsDeny">;
  }) => Promise<RequesterScopedMcpRuntimeHandle | undefined>;
  /**
   * Session-stable advertised catalog for scoped servers. Used by shared-thread
   * harnesses so dynamic tool specs do not rotate per sender.
   */
  rememberAdvertisedScopedCatalog: (
    handle: RequesterScopedMcpRuntimeHandle,
    catalog: McpToolCatalog,
  ) => void;
  getAdvertisedScopedCatalog: (sessionId: string) => McpToolCatalog | null;
  bindSessionKey: (sessionKey: string, sessionId: string) => void;
  resolveSessionId: (sessionKey: string) => string | undefined;
  /** Looks up an existing runtime only; must not create runtimes or connect transports. */
  peekSession: (params: {
    sessionId?: string;
    sessionKey?: string;
  }) => SessionMcpRuntime | undefined;
  disposeSession: (sessionId: string) => Promise<void>;
  /** Required retirement stays armed when a stopping run creates or reuses a runtime. */
  deferRetirement: (sessionId: string, opts?: { retainAcrossReuse?: boolean }) => boolean;
  completeDeferredRetirement: (sessionId: string, runtime?: SessionMcpRuntime) => Promise<boolean>;
  disposeAll: () => Promise<void>;
  sweepIdleRuntimes: () => Promise<number>;
  listSessionIds: () => string[];
  /** All managed cache keys (session ids and requester composite keys). */
  listRuntimeKeys: () => string[];
  /** Sum of active leases across every runtime key for this session. */
  totalActiveLeasesForSession: (sessionId: string) => number;
};
