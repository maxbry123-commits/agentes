/**
 * Resolves public avatar sources for configured agent identities.
 */
import path from "node:path";
import { normalizeOptionalString } from "@openclaw/normalization-core/string-coerce";
import type { OpenClawConfig } from "../config/types.openclaw.js";
import { normalizeAgentId } from "../routing/session-key.js";
import {
  hasAvatarUriScheme,
  isAvatarDataUrl,
  isAvatarHttpUrl,
  isWindowsAbsolutePath,
} from "../shared/avatar-policy.js";
import { resolveAgentWorkspaceDir } from "./agent-scope.js";
import { resolveLocalAgentAvatarPath } from "./identity-avatar-file.js";
import { loadAgentIdentityFromWorkspace } from "./identity-file.js";
import { resolveAgentIdentity } from "./identity.js";

// Agent avatar resolution for UI/public surfaces. Remote/data sources are
// allowed directly; local files must stay inside the agent workspace and satisfy
// shared avatar policy limits.
export type AgentAvatarResolution =
  | { kind: "none"; reason: string; source?: string }
  | { kind: "local"; filePath: string; source: string }
  | { kind: "remote"; url: string; source: string }
  | { kind: "data"; url: string; source: string };

type AgentAvatarPublicSourceInput = {
  kind: AgentAvatarResolution["kind"];
  source?: string | null;
};

const PUBLIC_AVATAR_SOURCE_MAX_CHARS = 256;
const PUBLIC_DATA_AVATAR_HEADER_MAX_CHARS = 64;

function resolveAvatarSource(cfg: OpenClawConfig, agentId: string): string | null {
  const normalizedAgentId = normalizeAgentId(agentId);
  const fromConfig =
    normalizeOptionalString(resolveAgentIdentity(cfg, normalizedAgentId)?.avatar) ?? null;
  if (fromConfig) {
    return fromConfig;
  }
  const workspace = resolveAgentWorkspaceDir(cfg, normalizedAgentId);
  const fromIdentity =
    normalizeOptionalString(loadAgentIdentityFromWorkspace(workspace)?.avatar) ?? null;
  if (fromIdentity) {
    return fromIdentity;
  }
  return null;
}

function isSafeRelativeAvatarSource(source: string): boolean {
  if (
    source.length > PUBLIC_AVATAR_SOURCE_MAX_CHARS ||
    source.startsWith("~") ||
    path.isAbsolute(source) ||
    isWindowsAbsolutePath(source) ||
    (hasAvatarUriScheme(source) && !isWindowsAbsolutePath(source)) ||
    source.includes("\0")
  ) {
    return false;
  }
  const parts = source.replace(/\\/g, "/").split("/");
  return parts.every((part) => part !== "..");
}

/** Return a safe public description of the configured avatar source. */
export function resolvePublicAgentAvatarSource(
  resolved: AgentAvatarPublicSourceInput,
): string | undefined {
  const source = normalizeOptionalString(resolved.source) ?? null;
  if (!source) {
    return undefined;
  }
  if (isAvatarDataUrl(source)) {
    // Data URLs can be large and sensitive; expose only the media/header prefix.
    const commaIndex = source.indexOf(",");
    const header =
      commaIndex > 0
        ? source.slice(0, Math.min(commaIndex, PUBLIC_DATA_AVATAR_HEADER_MAX_CHARS))
        : source.slice(0, PUBLIC_DATA_AVATAR_HEADER_MAX_CHARS);
    return `${header},...`;
  }
  if (isAvatarHttpUrl(source)) {
    return "remote URL";
  }
  return isSafeRelativeAvatarSource(source) ? source : undefined;
}

/** Resolve the effective avatar for an agent, including config and IDENTITY.md. */
export function resolveAgentAvatar(cfg: OpenClawConfig, agentId: string): AgentAvatarResolution {
  const source = resolveAvatarSource(cfg, agentId);
  if (!source) {
    return { kind: "none", reason: "missing" };
  }
  if (isAvatarHttpUrl(source)) {
    return { kind: "remote", url: source, source };
  }
  if (isAvatarDataUrl(source)) {
    return { kind: "data", url: source, source };
  }
  const workspaceDir = resolveAgentWorkspaceDir(cfg, agentId);
  const resolved = resolveLocalAgentAvatarPath({ raw: source, workspaceDir });
  if (!resolved.ok) {
    return { kind: "none", reason: resolved.reason, source };
  }
  return { kind: "local", filePath: resolved.value.filePath, source };
}
