// xAI live tests verify Grok completions, tool payload wrapping, and Grok web
// search against the real provider when live credentials are enabled.
import { completeSimple, type Model } from "openclaw/plugin-sdk/llm";
import { Type } from "typebox";
import { describe, expect, it } from "vitest";
import { applyExtraParamsToAgent } from "./embedded-agent-runner/extra-params.js";
import {
  createSingleUserPromptMessage,
  extractNonEmptyAssistantText,
  isLiveTestEnabled,
} from "./live-test-helpers.js";
import { shouldSkipLiveProviderDrift } from "./live-test-provider-drift.js";
import { createOpenAIResponsesTransportStreamFn } from "./openai-transport-stream.js";
import { createWebSearchTool } from "./tools/web-search.js";

const XAI_KEY = process.env.XAI_API_KEY ?? "";
const LIVE = isLiveTestEnabled(["XAI_LIVE_TEST"]);
const XAI_COMPLETE_LIVE_TIMEOUT_MS = 90_000;
const XAI_WEB_SEARCH_LIVE_TIMEOUT_SECONDS = 60;
const XAI_LIVE_COMPLETION_CASES = [
  { modelId: "grok-4.3", completionReasoning: undefined },
  { modelId: "grok-4.5", completionReasoning: undefined },
  { modelId: "grok-4.6", completionReasoning: "xhigh" },
] as const;

const describeLive = LIVE && XAI_KEY ? describe : describe.skip;

type XaiLiveModelId = (typeof XAI_LIVE_COMPLETION_CASES)[number]["modelId"];

type AssistantLikeMessage = {
  content: Array<{
    type?: string;
    text?: string;
    id?: string;
    name?: string;
    function?: {
      strict?: unknown;
    };
  }>;
};

function getToolFunction(tool: Record<string, unknown>): Record<string, unknown> | undefined {
  const nested = tool.function;
  if (nested && typeof nested === "object" && !Array.isArray(nested)) {
    return nested as Record<string, unknown>;
  }
  if (tool.type === "function" && typeof tool.name === "string") {
    return tool;
  }
  return undefined;
}

function resolveLiveXaiModel(modelId: XaiLiveModelId) {
  const isGrok45 = modelId === "grok-4.5";
  const isGrok46 = modelId === "grok-4.6";
  const isFrontier = isGrok45 || isGrok46;
  return {
    id: modelId,
    name: isGrok46 ? "Grok 4.6" : isGrok45 ? "Grok 4.5" : "Grok 4.3",
    api: "openai-responses",
    provider: "xai",
    baseUrl: "https://api.x.ai/v1",
    reasoning: true,
    input: ["text", "image"],
    cost: isFrontier
      ? { input: 2, output: 6, cacheRead: isGrok46 ? 0.5 : 0.3, cacheWrite: 0 }
      : { input: 1.25, output: 2.5, cacheRead: 0.2, cacheWrite: 0 },
    contextWindow: isFrontier ? 500_000 : 1_000_000,
    maxTokens: 64_000,
    thinkingLevelMap: {
      off: isFrontier ? null : "none",
      minimal: "low",
      low: "low",
      medium: "medium",
      high: "high",
      xhigh: isGrok46 ? "xhigh" : "high",
    },
  } satisfies Model<"openai-responses">;
}

function requireLiveValue<T>(value: T | null | undefined, label: string): T {
  if (value == null) {
    throw new Error(`expected ${label}`);
  }
  return value;
}

async function runXaiLiveCase(label: string, run: () => Promise<void>): Promise<void> {
  // Live provider behavior can drift on billing/capacity; those environment
  // failures are skipped while real contract failures still throw.
  try {
    await run();
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    const drift = shouldSkipLiveProviderDrift({
      error,
      allowBilling: true,
      allowProviderUnavailable: true,
    });
    if (drift) {
      console.warn(`[xai:live] skip ${label}: ${drift.label}: ${message}`);
      return;
    }
    if (/\b403\b/.test(message) && /model .+ is not available in your region/i.test(message)) {
      console.warn(`[xai:live] skip ${label}: regional model availability: ${message}`);
      return;
    }
    if (message.includes("web_search is disabled or no provider is available")) {
      console.warn(`[xai:live] skip ${label}: web_search unavailable in this environment`);
      return;
    }
    throw error;
  }
}

async function collectDoneMessage(
  stream: AsyncIterable<{
    type: string;
    message?: AssistantLikeMessage;
    error?: { errorMessage?: string };
  }>,
): Promise<AssistantLikeMessage> {
  let doneMessage: AssistantLikeMessage | undefined;
  for await (const event of stream) {
    if (event.type === "done") {
      doneMessage = event.message;
    } else if (event.type === "error") {
      throw new Error(event.error?.errorMessage ?? "xAI stream failed without error details");
    }
  }
  return requireLiveValue(doneMessage, "done message");
}

describeLive("xai live", () => {
  for (const { modelId, completionReasoning } of XAI_LIVE_COMPLETION_CASES) {
    it(
      `returns assistant text for ${modelId}`,
      async () => {
        await runXaiLiveCase("complete", async () => {
          const model = requireLiveValue(resolveLiveXaiModel(modelId), "xAI model");
          const res = await completeSimple(
            model,
            {
              messages: createSingleUserPromptMessage(),
            },
            {
              apiKey: XAI_KEY,
              maxTokens: 64,
              ...(completionReasoning ? { reasoning: completionReasoning } : {}),
            },
          );

          expect(
            extractNonEmptyAssistantText(res.content).length,
            res.errorMessage,
          ).toBeGreaterThan(0);
        });
      },
      XAI_COMPLETE_LIVE_TIMEOUT_MS,
    );
  }

  for (const modelId of ["grok-4.3", "grok-4.5"] as const) {
    it(`sends wrapped ${modelId} tool payloads live`, async () => {
      await runXaiLiveCase("tool-call", async () => {
        const model = requireLiveValue(resolveLiveXaiModel(modelId), "xAI model");
        const agent = { streamFn: createOpenAIResponsesTransportStreamFn() };
        applyExtraParamsToAgent(agent, undefined, "xai", model.id);

        const noopTool = {
          name: "noop",
          description: "Return ok.",
          parameters: Type.Object({}, { additionalProperties: false }),
        };

        let capturedPayload: Record<string, unknown> | undefined;
        const streamOptions = {
          apiKey: XAI_KEY,
          maxTokens: 128,
          reasoning: "low",
          toolChoice: { type: "function", name: "noop" },
          onPayload: (payload: unknown) => {
            capturedPayload = payload as Record<string, unknown>;
          },
        } satisfies Parameters<typeof agent.streamFn>[2] & {
          reasoning: "low";
          toolChoice: { type: "function"; name: string };
        };
        const stream = agent.streamFn(
          model,
          {
            messages: createSingleUserPromptMessage(
              "You must call the tool `noop` exactly once with {}.",
            ),
            tools: [noopTool],
          },
          streamOptions,
        );

        const doneMessage = await collectDoneMessage(
          stream as AsyncIterable<{
            type: string;
            message?: AssistantLikeMessage;
            error?: { errorMessage?: string };
          }>,
        );
        const content = requireLiveValue(doneMessage.content, "done message content");
        expect(Array.isArray(content)).toBe(true);
        expect(content.some((block) => block.type === "toolCall" && block.name === "noop")).toBe(
          true,
        );
        const payload = requireLiveValue(capturedPayload, "captured xAI payload");
        expect(payload.reasoning).toMatchObject({ effort: "low" });
        if ("tool_stream" in payload) {
          expect(payload.tool_stream).toBe(true);
        }

        const payloadTools = Array.isArray(payload.tools)
          ? (payload.tools as Array<Record<string, unknown>>)
          : [];
        expect(payloadTools.length).toBeGreaterThan(0);
        const firstFunction = requireLiveValue(
          payloadTools[0] ? getToolFunction(payloadTools[0]) : undefined,
          "first xAI tool function",
        );
        expect(typeof firstFunction).toBe("object");
        expect(Array.isArray(firstFunction)).toBe(false);
        expect([undefined, false]).toContain(firstFunction.strict);
      });
    }, 90_000);
  }

  it("runs Grok web_search live", async () => {
    await runXaiLiveCase("web-search", async () => {
      const tool = createWebSearchTool({
        config: {
          plugins: {
            entries: {
              xai: {
                config: {
                  webSearch: { model: "grok-4.3" },
                },
              },
            },
          },
          tools: {
            web: {
              search: {
                provider: "grok",
                timeoutSeconds: XAI_WEB_SEARCH_LIVE_TIMEOUT_SECONDS,
              },
            },
          },
        },
      });

      const webSearchTool = requireLiveValue(tool, "grok web search tool");
      const result = await webSearchTool.execute("web-search:grok-live", {
        query: "OpenClaw GitHub",
        count: 3,
      });

      const details = (result.details ?? {}) as {
        kind?: "answer" | "error";
        provider?: string;
        content?: string;
        citations?: Array<{ url: string; title?: string }>;
        error?: string;
        message?: string;
      };

      const errorMessage =
        details.error && details.message
          ? `${details.error} ${details.message}`
          : details.error || details.message || "";
      const drift = shouldSkipLiveProviderDrift({
        error: errorMessage,
        allowBilling: true,
        allowProviderUnavailable: true,
      });
      if (drift) {
        console.warn(`[xai:live] skip web-search: ${drift.label}: ${errorMessage}`);
        return;
      }

      expect(details.error, details.message).toBeUndefined();
      expect(details.kind).toBe("answer");
      expect(details.provider).toBe("grok");
      expect(details.content?.trim().length ?? 0).toBeGreaterThan(0);
      expect(details.citations?.length ?? 0).toBeGreaterThan(0);
    });
  }, 90_000);
});
