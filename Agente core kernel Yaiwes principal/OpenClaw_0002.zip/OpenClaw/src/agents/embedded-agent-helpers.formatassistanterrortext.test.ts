// Covers user-facing formatting and sanitization of assistant/provider errors.
import type { AssistantMessage } from "openclaw/plugin-sdk/llm";
import { describe, expect, it } from "vitest";
import { MALFORMED_STREAMING_FRAGMENT_ERROR_MESSAGE } from "../shared/assistant-error-format.js";
import {
  classifyAssistantFailoverReason,
  formatBillingErrorMessage,
  formatAssistantErrorText,
  formatUserFacingAssistantErrorText,
  GENERIC_ASSISTANT_ERROR_TEXT,
  getApiErrorPayloadFingerprint,
  formatRawAssistantErrorForUi,
} from "./embedded-agent-helpers.js";
import { sanitizeUserFacingText } from "./embedded-agent-helpers/sanitize-user-facing-text.js";
import { renderUserFacingText } from "./embedded-agent-helpers/user-facing-text.js";
import { isRawApiErrorPayload } from "./failover/user-copy.js";
import { makeAssistantMessageFixture } from "./test-helpers/assistant-message-fixtures.js";
import { withPreparedFailoverProviders } from "./test-helpers/provider-failover-generation.js";

describe("formatAssistantErrorText", () => {
  const BILLING_ERROR_USER_MESSAGE =
    "⚠️ API provider returned a billing error — your API key has run out of credits or has an insufficient balance. Check your provider's billing dashboard and top up or switch to a different API key.";
  const makeAssistantError = (errorMessage: string): AssistantMessage =>
    makeAssistantMessageFixture({
      errorMessage,
      content: [{ type: "text", text: errorMessage }],
    });
  const authInvalidTokenCopy =
    "Authentication failed (provider returned HTTP 401). " +
    "Your provider token may have expired — try the request again in a moment. " +
    "If the failure persists, re-authenticate this provider.";

  it("returns a friendly message for context overflow", () => {
    const msg = makeAssistantError("request_too_large");
    expect(formatAssistantErrorText(msg)).toContain("Context overflow");
  });
  it("returns context overflow for Anthropic 'Request size exceeds model context window'", () => {
    // This Anthropic shape must map to context overflow so auto-compaction can
    // trigger instead of treating it as a generic schema rejection.
    const msg = makeAssistantError(
      '{"type":"error","error":{"type":"invalid_request_error","message":"Request size exceeds model context window"}}',
    );
    expect(formatAssistantErrorText(msg)).toContain("Context overflow");
  });
  it("returns context overflow for Kimi 'model token limit' errors", () => {
    const msg = makeAssistantError(
      "error, status code: 400, message: Invalid request: Your request exceeded model token limit: 262144 (requested: 291351)",
    );
    expect(formatAssistantErrorText(msg)).toContain("Context overflow");
  });
  it("returns context overflow for Ollama 'prompt too long' errors (#34005)", () => {
    const msg = makeAssistantError(
      'Ollama API error 400: {"StatusCode":400,"Status":"400 Bad Request","error":"prompt too long; exceeded max context length by 4 tokens"}',
    );
    expect(formatAssistantErrorText(msg)).toContain("Context overflow");
  });
  it("returns a reasoning-required message for mandatory reasoning endpoint errors", () => {
    const msg = makeAssistantError(
      "400 Reasoning is mandatory for this endpoint and cannot be disabled.",
    );
    const result = formatAssistantErrorText(msg);
    expect(result).toContain("Reasoning is required");
    expect(result).toContain("/think minimal");
    expect(result).not.toContain("Context overflow");
  });
  it("returns a friendly message for Anthropic role ordering", () => {
    const msg = makeAssistantError('messages: roles must alternate between "user" and "assistant"');
    expect(formatAssistantErrorText(msg)).toContain("Message ordering conflict");
  });
  it.each([
    {
      title: "returns a friendly message for Anthropic overload errors",
      errorText:
        '{"type":"error","error":{"details":null,"type":"overloaded_error","message":"Overloaded"},"request_id":"req_123"}',
      expected: "The AI service is temporarily overloaded. Please try again in a moment.",
    },
    {
      title: "uses classified rate-limit copy for Z.AI rate-limit errors",
      errorText:
        '429 status code (exceeded limit)\n{"code":1305,"message":"The service may be temporarily overloaded, please try again later."}',
      expected: "⚠️ API rate limit reached. Please try again later.",
    },
    {
      title: "rewrites generic provider internal errors without support request ids",
      errorText:
        "An error occurred while processing your request. You can retry your request, or contact us through our help center at help.openai.com if the error persists. Please include the request ID synthetic-provider-request-001 in your message.",
      expected: "The AI service returned an internal error. Please try again in a moment.",
    },
    {
      title: "rewrites request-id-only generic provider internal errors without exposing the id",
      errorText:
        "An error occurred while processing your request. Please include request ID req_synthetic_provider_request_001 in your message.",
      expected: "The AI service returned an internal error. Please try again in a moment.",
    },
    {
      title: "returns upstream HTML copy for HTML quota pages",
      errorText: "429 <!DOCTYPE html><html><body>Your quota is exhausted</body></html>",
      expected:
        "The provider returned an HTML error page instead of an API response. This usually means a CDN or gateway (e.g. Cloudflare) blocked the request. Retry in a moment or check provider status.",
    },
    {
      title: "returns upstream HTML copy for prefixed 521 HTML rate-limit pages",
      errorText: "Error: 521 <!DOCTYPE html><html><body>rate limit</body></html>",
      expected:
        "The provider returned an HTML error page instead of an API response. This usually means a CDN or gateway (e.g. Cloudflare) blocked the request. Retry in a moment or check provider status.",
    },
    {
      title: "returns an explicit re-authentication message for OAuth refresh failures",
      errorText:
        "OAuth token refresh failed for openai: invalid_grant. Please try again or re-authenticate.",
      expected: "Authentication refresh failed. Re-authenticate this provider and try again.",
    },
    {
      title: "returns an explicit re-authentication message for Codex app-server refresh failures",
      errorText:
        "Your access token could not be refreshed because you have since logged out or signed in to another account. Please sign in again.",
      expected: "Authentication refresh failed. Re-authenticate this provider and try again.",
    },
    {
      title: "returns a timeout-specific message for OAuth refresh hard timeouts",
      errorText:
        'OAuth refresh call "refreshProviderOAuthCredentialWithPlugin(openai)" exceeded hard timeout (120000ms)',
      expected:
        "Authentication refresh timed out before the provider completed. Retry in a moment; re-authenticate only if it keeps failing.",
    },
    {
      title: "sanitizes invalid streaming event order errors",
      errorText: 'Unexpected event order, got message_start before receiving "message_stop"',
      expected:
        "LLM request failed: provider returned an invalid streaming response. Please try again.",
    },
  ])("$title", ({ errorText, expected }) => {
    const msg = makeAssistantError(errorText);
    expect(formatAssistantErrorText(msg)).toBe(expected);
  });
  it("returns a model-switch hint for OpenAI model capacity errors", () => {
    const msg = makeAssistantError("Selected model is at capacity. Please try a different model.");
    expect(formatAssistantErrorText(msg)).toBe(
      "⚠️ Selected model is at capacity. Try a different model, or wait and retry.",
    );
  });
  it("returns a recovery hint when tool call input is missing", () => {
    const msg = makeAssistantError("tool_use.input: Field required");
    const result = formatAssistantErrorText(msg);
    expect(result).toContain("Session history looks corrupted");
    expect(result).toContain("/new");
  });
  it("returns a recovery hint for replay-invalid connection mismatch errors", () => {
    const msg = makeAssistantError("401 input item ID does not belong to this connection");
    const result = formatAssistantErrorText(msg);
    expect(result).toContain("Session history or replay state is invalid");
    expect(result).toContain("/new");
  });
  it("prioritizes thinking-signature replay recovery over invalid-request formatting", () => {
    // Thinking-signature failures are also invalid_request_error, so the
    // replay-invalid copy must win before the generic invalid-request path.
    const msg = makeAssistantError(
      '{"type":"error","error":{"type":"invalid_request_error","message":"messages.1.content.1: Invalid `signature` in `thinking` block"}}',
    );
    const replayCopy =
      "Session history or replay state is invalid. Use /new to start a fresh session and try again.";
    expect(formatAssistantErrorText(msg)).toBe(replayCopy);
    expect(formatUserFacingAssistantErrorText(msg)).toBe(replayCopy);
  });
  it("handles JSON-wrapped role errors", () => {
    const msg = makeAssistantError('{"error":{"message":"400 Incorrect role information"}}');
    const result = formatAssistantErrorText(msg);
    expect(result).toContain("Message ordering conflict");
    expect(result).not.toContain("400");
  });
  it("suppresses raw error JSON payloads that are not otherwise classified", () => {
    const msg = makeAssistantError(
      '{"type":"error","error":{"message":"Something exploded","type":"server_error"}}',
    );
    expect(formatAssistantErrorText(msg)).toBe("LLM error server_error: Something exploded");
  });
  it.each([{ prepared: false }, { prepared: true }])(
    "replaces raw provider detail with classified facts (prepared: $prepared)",
    ({ prepared }) => {
      const raw = "HTTP 500: opaque-provider-canary";
      const userFacing = formatUserFacingAssistantErrorText(makeAssistantError(raw), {
        provider: "openai",
        providerOwner: prepared
          ? {
              id: "openai",
              classifyFailoverReason: () => "server_error",
            }
          : undefined,
        model: "gpt-5.6-luna",
      });

      expect(userFacing).toBe(
        "⚠️ openai/gpt-5.6-luna request failed (provider internal error, HTTP 500). " +
          "This is usually temporary — try again shortly.",
      );
      expect(userFacing).not.toContain("opaque-provider-canary");
    },
  );

  it("keeps the generic last resort when no classified facts are available", () => {
    const raw = "opaque-private-provider-detail";
    const msg = makeAssistantMessageFixture({
      errorMessage: raw,
      provider: undefined,
      model: undefined,
      errorType: undefined,
      errorCode: undefined,
      errorBody: undefined,
      content: [{ type: "text", text: raw }],
    });

    expect(formatUserFacingAssistantErrorText(msg)).toBe(GENERIC_ASSISTANT_ERROR_TEXT);
  });

  it("never includes a raw provider body in classified failure copy", () => {
    const raw = "HTTP 500: Authorization: Bearer sk-secret https://secret.example/path opaque-body";
    const userFacing = formatUserFacingAssistantErrorText(makeAssistantError(raw), {
      provider: "openai",
      providerOwner: {
        id: "openai",
        classifyFailoverReason: () => "server_error",
      },
      model: "gpt-5.6-luna",
    });

    expect(userFacing).not.toMatch(/sk-secret|secret\.example|opaque-body|Authorization/iu);
  });

  it("classifies service_unavailable text as provider overload", () => {
    expect(
      formatUserFacingAssistantErrorText(makeAssistantError("HTTP 503: service_unavailable"), {
        provider: "openai",
        model: "gpt-5.6-luna",
      }),
    ).toContain("overloaded");
  });

  it("points classified authentication failures at provider re-authentication", () => {
    const raw = "HTTP 401: opaque-auth-canary";
    const userFacing = formatUserFacingAssistantErrorText(makeAssistantError(raw), {
      provider: "openai",
      providerOwner: {
        id: "openai",
        classifyFailoverReason: () => "auth",
      },
      model: "gpt-5.6-luna",
    });

    expect(userFacing).toBe(
      "⚠️ openai/gpt-5.6-luna request failed (authentication failed, HTTP 401). " +
        "Re-authenticate the provider and try again.",
    );
    expect(userFacing).not.toContain("opaque-auth-canary");
  });
  it("classifies provider upstream_error payloads as server errors for fallback", () => {
    const msg = makeAssistantMessageFixture({
      errorMessage: "Upstream request failed",
      errorType: "upstream_error",
    });

    withPreparedFailoverProviders(["openai"], () => {
      expect(classifyAssistantFailoverReason(msg, { provider: "openai" })).toBe("server_error");
      expect(
        classifyAssistantFailoverReason(
          makeAssistantError(
            '{"error":{"message":"Upstream request failed","type":"upstream_error","param":"","code":null}}',
          ),
        ),
      ).toBe("server_error");
    });
  });
  it("renders opaque upstream_error facts as a temporary provider error", () => {
    const msg = makeAssistantMessageFixture({
      provider: "openai",
      model: "gpt-5.6-luna",
      errorMessage: "opaque provider response",
      errorType: "upstream_error",
    });

    expect(formatUserFacingAssistantErrorText(msg)).toBe(
      "⚠️ openai/gpt-5.6-luna request failed (provider internal error). " +
        "This is usually temporary — try again shortly.",
    );
  });
  it("uses generic user-facing copy for escaped structured provider messages", () => {
    // The internal formatter keeps detail for logs, while user-facing text must
    // not expose arbitrary provider-controlled structured payload content.
    const msg = makeAssistantError(
      '{"type":"error","error":{"message":"SECRET\\nCANARY","type":"invalid_request_error"}}',
    );
    expect(formatAssistantErrorText(msg)).toBe("LLM request rejected: SECRET\nCANARY");
    expect(formatUserFacingAssistantErrorText(msg)).toBe(
      "LLM request failed: provider rejected the request schema or tool payload.",
    );
  });
  it("surfaces allowlisted token limits from structured provider messages", () => {
    const msg = makeAssistantError(
      JSON.stringify({
        type: "error",
        error: {
          type: "invalid_request_error",
          message:
            "max_tokens (384000) exceeds model's maximum output tokens (65536) for model deepseek-v4-flash:0731",
        },
      }),
    );

    const userFacing = formatUserFacingAssistantErrorText(msg);
    expect(userFacing).toBe(
      "LLM request rejected: configured maxTokens is 384000, above the provider maximum of 65536. Lower maxTokens and try again.",
    );
    expect(userFacing).not.toContain("deepseek-v4-flash:0731");
  });

  it("surfaces token limits from structured error bodies", () => {
    const msg = makeAssistantMessageFixture({
      errorMessage: "400 Param Incorrect",
      errorCode: "400",
      errorBody: JSON.stringify({
        type: "error",
        error: {
          type: "invalid_request_error",
          message:
            "max_tokens (384000) exceeds model's maximum output tokens (65536) for model deepseek-v4-flash:0731",
        },
      }),
      content: [],
    });

    const userFacing = formatUserFacingAssistantErrorText(msg);
    expect(userFacing).toBe(
      "LLM request rejected: configured maxTokens is 384000, above the provider maximum of 65536. Lower maxTokens and try again.",
    );
    expect(userFacing).not.toContain("deepseek-v4-flash:0731");
  });

  it.each([
    "OpenAI API error (400): max_tokens (384000) exceeds model's maximum output tokens (65536)",
    "Error: OpenAI API error (400): max_tokens (384000) exceeds model's maximum output tokens (65536)",
  ])("surfaces token limits from provider-wrapped HTTP error %s", (raw) => {
    const msg = makeAssistantError(raw);
    expect(formatAssistantErrorText(msg)).toBe(
      "LLM request rejected: configured maxTokens is 384000, above the provider maximum of 65536. Lower maxTokens and try again.",
    );
    expect(formatUserFacingAssistantErrorText(msg)).toBe(
      "LLM request rejected: configured maxTokens is 384000, above the provider maximum of 65536. Lower maxTokens and try again.",
    );
  });
  it("sanitizes Codex error-prefixed JSON payloads", () => {
    const msg = makeAssistantError(
      'Codex error: {"type":"error","error":{"message":"Something exploded","type":"server_error"},"sequence_number":2}',
    );
    expect(formatAssistantErrorText(msg)).toBe("LLM error server_error: Something exploded");
  });
  it("returns a friendly billing message for credit balance errors", () => {
    const msg = makeAssistantError("Your credit balance is too low to access the Anthropic API.");
    const result = formatAssistantErrorText(msg);
    expect(result).toBe(BILLING_ERROR_USER_MESSAGE);
  });
  it("returns a friendly billing message for HTTP 402 errors", () => {
    const msg = makeAssistantError("HTTP 402 Payment Required");
    const result = formatAssistantErrorText(msg);
    expect(result).toBe(BILLING_ERROR_USER_MESSAGE);
  });
  it("returns a friendly billing message for insufficient credits", () => {
    const msg = makeAssistantError("insufficient credits");
    const result = formatAssistantErrorText(msg);
    expect(result).toBe(BILLING_ERROR_USER_MESSAGE);
  });
  it("includes provider and assistant model in billing message when provider is given", () => {
    const msg = makeAssistantError("insufficient credits");
    const result = formatAssistantErrorText(msg, { provider: "Anthropic" });
    expect(result).toBe(formatBillingErrorMessage("Anthropic", "test-model"));
    expect(result).toContain("Anthropic");
    expect(result).not.toContain("API provider");
  });
  it("uses the active assistant model for billing message context", () => {
    const msg = makeAssistantError("insufficient credits");
    msg.model = "claude-3-5-sonnet";
    const result = formatAssistantErrorText(msg, { provider: "Anthropic" });
    expect(result).toBe(formatBillingErrorMessage("Anthropic", "claude-3-5-sonnet"));
  });
  it("uses prepared provider ownership for billing classification", () => {
    const provider = "custom-openrouter";
    const model = "anthropic/claude-sonnet-4";
    const result = formatAssistantErrorText(
      makeAssistantError("HTTP 403: API key budget limit exceeded"),
      {
        provider,
        providerOwner: {
          id: "openrouter",
          classifyFailoverReason: ({ provider: owner, errorMessage }) =>
            owner === "openrouter" && errorMessage.includes("budget limit") ? "billing" : undefined,
        },
        model,
      },
    );
    expect(result).toBe(formatBillingErrorMessage(provider, model));
  });
  it("returns generic billing message when provider is not given", () => {
    const msg = makeAssistantError("insufficient credits");
    const result = formatAssistantErrorText(msg);
    expect(result).toContain("API provider");
    expect(result).toBe(BILLING_ERROR_USER_MESSAGE);
  });
  it.each([
    {
      title:
        "returns a friendly billing message for flat JSON insufficient_balance payloads (#74079)",
      errorText:
        '{"error":"insufficient_balance","message":"Insufficient MBT balance. Top up or upgrade your subscription to continue.","upgradeUrl":"/settings/billing"}',
      provider: "google",
      model: "gemini-3.1-pro-preview",
    },
    {
      title: "keeps known Moonshot 429 balance failures on billing copy",
      errorText:
        '429 {"error":{"message":"Your account has insufficient balance. Please recharge to continue.","type":"rate_limit_reached"}}',
      provider: "moonshot",
      model: "kimi-k2",
    },
    {
      title: "keeps high-confidence 429 insufficient quota failures on billing copy",
      errorText:
        '429 {"type":"error","error":{"type":"insufficient_quota","message":"Your account has insufficient quota balance to run this request."}}',
      provider: "openai",
      model: "gpt-5.5",
    },
    {
      title: "keeps high-confidence 429 insufficient balance failures on billing copy",
      errorText: '429 {"error":"insufficient_balance","message":"Your credit balance is too low."}',
      provider: "openai-compatible",
      model: "custom-model",
    },
    {
      title: "keeps structured 429 insufficient balance codes on billing copy",
      errorText:
        'HTTP 429: {"error":"insufficient_balance","message":"Insufficient account balance"}',
      provider: "openai-compatible",
      model: "custom-model",
    },
    {
      title: "returns billing guidance for Volcengine Coding Plan subscription failures",
      errorText:
        'HTTP 400 Bad Request: {"error":{"code":"InvalidSubscription","message":"Your account does not have a valid CodingPlan subscription, or your subscription has expired."}}',
      provider: "volcengine-plan",
      model: "ark-code-latest",
    },
  ])("$title", ({ errorText, provider, model }) => {
    const msg = makeAssistantError(errorText);
    const result = formatAssistantErrorText(msg, {
      provider,
      model,
    });
    expect(result).toBe(formatBillingErrorMessage(provider, model));
  });
  it("returns a billing message for xAI 429 credit exhaustion before rate-limit copy", () => {
    // Some providers report billing exhaustion as 429; billing copy should win
    // when the payload carries high-confidence credit language.
    const msg = makeAssistantError(
      '429 {"code":"Some resource has been exhausted","error":"Your team team-redacted has either used all available credits or reached its monthly spending limit. To continue making API requests, please purchase more credits or raise your spending limit."}',
    );
    const result = formatAssistantErrorText(msg, {
      provider: "xai",
      model: "grok-4.3",
    });
    expect(result).toBe(formatBillingErrorMessage("xai", "grok-4.3"));
  });
  it("keeps 429 more-credits failures on billing copy", () => {
    const msg = makeAssistantError("429 This model requires more credits to use");
    const result = formatAssistantErrorText(msg, {
      provider: "openai-compatible",
      model: "custom-model",
    });
    expect(result).toBe(formatBillingErrorMessage("openai-compatible", "custom-model"));
  });
  it("returns a friendly message for rate limit errors", () => {
    const msg = makeAssistantError("429 rate limit reached");
    expect(formatAssistantErrorText(msg)).toContain("rate limit reached");
  });
  it("keeps plain HTTP rate-limit guidance user-facing", () => {
    const msg = makeAssistantError("429 Your quota has been exhausted, try again in 24 hours");
    expect(formatAssistantErrorText(msg)).toContain("24 hours");
    expect(formatUserFacingAssistantErrorText(msg)).toContain("24 hours");
  });

  it("surfaces provider-specific rate limit message with reset time (#54433)", () => {
    const msg = makeAssistantError(
      "You have hit your ChatGPT usage limit (go plan). Try again in ~4381 min.",
    );
    const result = formatAssistantErrorText(msg);
    expect(result).toContain("4381 min");
    expect(result).toContain("go plan");
    expect(result).not.toBe("⚠️ API rate limit reached. Please try again later.");
  });

  it("surfaces provider-specific rate limit message from JSON payload (#54433)", () => {
    const msg = makeAssistantError(
      '429 {"type":"error","error":{"type":"rate_limit_error","message":"Rate limit reached. Try again in 30 seconds."}}',
    );
    const result = formatAssistantErrorText(msg);
    expect(result).toContain("30 seconds");
    expect(result).not.toBe("⚠️ API rate limit reached. Please try again later.");
    expect(formatUserFacingAssistantErrorText(msg)).toContain("30 seconds");
  });

  it("returns generic rate limit message when no specific details are present", () => {
    const msg = makeAssistantError("429 Too Many Requests");
    expect(formatAssistantErrorText(msg)).toBe(
      "⚠️ API rate limit reached. Please try again later.",
    );
  });

  it("strips leading HTTP status code prefix from non-JSON rate limit messages", () => {
    const msg = makeAssistantError("429 Your quota has been exhausted, try again in 24 hours");
    const result = formatAssistantErrorText(msg);
    expect(result).toContain("try again in 24 hours");
    expect(result).not.toMatch(/^⚠️ 429\b/);
    expect(result).toBe("⚠️ Your quota has been exhausted, try again in 24 hours");
  });

  it("does not misdiagnose standalone Cloudflare challenge HTML as DNS", () => {
    const msg = makeAssistantError(`<!DOCTYPE html>
<html>
  <head>
    <title>Just a moment...</title>
    <link rel="dns-prefetch" href="//chatgpt.com">
  </head>
  <body>
    <span id="challenge-error-text">Enable JavaScript and cookies to continue</span>
    <script src="/cdn-cgi/challenge-platform/h/g/orchestrate/chl_page/v1"></script>
  </body>
</html>`);
    expect(formatAssistantErrorText(msg)).toBe(
      "The provider returned an HTML error page instead of an API response. This usually means a CDN or gateway (e.g. Cloudflare) blocked the request. Retry in a moment or check provider status.",
    );
  });

  it("returns a friendly message for empty stream chunk errors", () => {
    const msg = makeAssistantError("request ended without sending any chunks");
    expect(formatAssistantErrorText(msg)).toBe("LLM request timed out.");
  });

  it("does not rewrite Provider finish_reason: error into a timeout (#109218)", () => {
    const msg = makeAssistantError("Provider finish_reason: error");
    // Keep provider signal; do not rewrite to the timeout string (formatAssistantErrorText
    // may return undefined for some paths — assert the concrete copy we preserve).
    expect(formatAssistantErrorText(msg)).toBe("Provider finish_reason: error");
  });

  it("returns a connection-refused message for ECONNREFUSED failures", () => {
    const msg = makeAssistantError("connect ECONNREFUSED 127.0.0.1:443 during upstream call");
    expect(formatAssistantErrorText(msg)).toBe(
      "LLM request failed: connection refused by the provider endpoint.",
    );
  });

  it.each(["disk full", "ENOSPC: no space left on device, write"])(
    "returns a friendly disk-space message for %s",
    (errorMessage) => {
      const msg = makeAssistantError(errorMessage);
      expect(formatAssistantErrorText(msg)).toBe(
        "OpenClaw could not write local session data because the disk is full. Free some disk space and try again.",
      );
    },
  );

  it("returns a DNS-specific message for provider lookup failures", () => {
    const msg = makeAssistantError("dial tcp: lookup api.example.com: no such host (ENOTFOUND)");
    expect(formatAssistantErrorText(msg)).toBe(
      "LLM request failed: DNS lookup for the provider endpoint failed.",
    );
  });

  it("returns an interrupted-connection message for socket hang ups", () => {
    const msg = makeAssistantError("socket hang up");
    expect(formatAssistantErrorText(msg)).toBe(
      "LLM request failed: network connection was interrupted.",
    );
  });

  it("returns a contention-specific message for OAuth refresh lock timeouts", () => {
    const msg = makeAssistantError("file lock timeout for /tmp/openclaw-oauth-refresh.lock");
    expect(formatAssistantErrorText(msg)).toBe(
      "Authentication refresh is already in progress elsewhere and this attempt timed out waiting for it. Retry in a moment.",
    );
  });

  it("returns a missing-scope message for OpenAI ChatGPT scope failures", () => {
    const msg = makeAssistantError(
      '401 {"type":"error","error":{"type":"permission_error","message":"Missing scopes: api.responses.write model.request"}}',
    );
    expect(formatAssistantErrorText(msg, { provider: "openai" })).toBe(
      "Authentication is missing the required OpenAI ChatGPT scopes. Re-run OpenAI login and try again.",
    );
  });

  it("returns a missing-scope message for raw OpenAI ChatGPT scope payloads without an HTTP prefix", () => {
    const msg = makeAssistantError(
      '{"type":"error","error":{"type":"permission_error","message":"Missing scopes: api.responses.write model.request"},"code":401}',
    );
    expect(formatAssistantErrorText(msg, { provider: "openai" })).toBe(
      "Authentication is missing the required OpenAI ChatGPT scopes. Re-run OpenAI login and try again.",
    );
  });

  it("does not misdiagnose other provider permission errors as OpenAI scope failures", () => {
    const msg = makeAssistantError(
      '401 {"type":"error","error":{"type":"permission_error","message":"Missing scopes: api.responses.write model.request"}}',
    );
    expect(formatAssistantErrorText(msg, { provider: "anthropic" })).not.toContain(
      "required OpenAI ChatGPT scopes",
    );
  });

  it("does not misdiagnose generic OpenAI permission failures as missing-scope failures", () => {
    const msg = makeAssistantError(
      '403 {"type":"error","error":{"type":"permission_error","message":"Insufficient permissions for this organization"}}',
    );
    expect(formatAssistantErrorText(msg, { provider: "openai" })).not.toContain(
      "required OpenAI ChatGPT scopes",
    );
  });

  it("returns re-authentication copy for HTML provider 401 auth failures", () => {
    const msg = makeAssistantError("401 <!DOCTYPE html><html><body>Unauthorized</body></html>");
    expect(formatAssistantErrorText(msg)).toBe(
      "Authentication failed at the provider. Re-authenticate and verify your provider credentials and account access.",
    );
  });

  it("returns re-authentication copy for HTML provider 403 auth failures", () => {
    const msg = makeAssistantError("403 <!DOCTYPE html><html><body>Access denied</body></html>");
    expect(formatAssistantErrorText(msg)).toBe(
      "Authentication failed at the provider. Re-authenticate and verify your provider credentials and account access.",
    );
  });

  it("sanitizes raw HTTP 401 / Invalid token errors into a re-auth hint (#56197)", () => {
    const reportedPayload = makeAssistantError('HTTP 401: "Invalid token"');
    const friendly = formatAssistantErrorText(reportedPayload);
    expect(friendly).toBe(authInvalidTokenCopy);
    expect(friendly).not.toContain("Invalid token");
  });

  it("sanitizes Unauthorized / token-expired variants under HTTP 401", () => {
    const variants = [
      "401 Unauthorized",
      "HTTP 401 Unauthorized: token expired",
      "HTTP 401: Incorrect API key provided",
      'status code: 401, message: "expired token"',
      '401 {"type":"error","error":{"type":"permission_error","message":"Invalid token"}}',
    ];
    for (const raw of variants) {
      const friendly = formatAssistantErrorText(makeAssistantError(raw));
      expect(friendly, raw).toBe(authInvalidTokenCopy);
    }
  });

  it("does not collapse 401 billing / permanent-auth errors into the generic re-auth hint", () => {
    const billing = makeAssistantError(
      '{"error":{"code":401,"message":"Key limit exceeded","metadata":{"raw":"insufficient credits"}}}',
    );
    const billingFriendly = formatAssistantErrorText(billing);
    expect(billingFriendly).not.toBe(authInvalidTokenCopy);
  });

  it("does not claim HTTP 401 for plain 403 errors that fall through to the generic auth reason (#77394 review)", () => {
    const plain403 = makeAssistantError("403 Forbidden");
    const friendly = formatAssistantErrorText(plain403);
    expect(friendly).toBeDefined();
    expect(friendly).not.toContain("HTTP 401");
    expect(friendly).not.toBe(authInvalidTokenCopy);
  });

  it("does not claim HTTP 401 for message-only auth errors with no HTTP status prefix (#77394 review)", () => {
    const messageOnly = makeAssistantError('{"error":{"code":"invalid_api_key"}}');
    const friendly = formatAssistantErrorText(messageOnly);
    expect(friendly).toBeDefined();
    expect(friendly).not.toContain("HTTP 401");
    expect(friendly).not.toBe(authInvalidTokenCopy);
  });

  it("does not rewrite provider-less missing-scope 401 payloads as invalid-token errors", () => {
    const raw =
      '401 {"type":"error","error":{"type":"permission_error","message":"Missing scopes: api.responses.write"}}';
    const missingScope = makeAssistantMessageFixture({
      provider: undefined,
      errorMessage: raw,
      content: [{ type: "text", text: raw }],
    });
    const friendly = formatAssistantErrorText(missingScope);
    expect(friendly).not.toBe(authInvalidTokenCopy);
    expect(friendly).toContain("permission_error");
  });

  it("returns a proxy-specific message for proxy misroutes", () => {
    const msg = makeAssistantError("407 Proxy Authentication Required");
    expect(formatAssistantErrorText(msg)).toBe(
      "LLM request failed: proxy or tunnel configuration blocked the provider request.",
    );
  });

  it("returns a certificate-specific message for TLS validation failures", () => {
    const msg = makeAssistantError(
      "Hostname/IP does not match certificate's altnames: Host: api.example.com",
    );
    expect(formatAssistantErrorText(msg)).toBe(
      "LLM request failed: TLS certificate validation rejected the provider endpoint. " +
        "Check the endpoint hostname, proxy, and local certificate trust.",
    );
  });

  it("keeps non-transport config errors that mention proxy settings actionable", () => {
    const msg = makeAssistantError(
      'Model-provider request.proxy/request.tls is not yet supported for api "ollama"',
    );
    expect(formatAssistantErrorText(msg)).toContain(
      'Model-provider request.proxy/request.tls is not yet supported for api "ollama"',
    );
    expect(formatAssistantErrorText(msg)).not.toBe(
      "LLM request failed: proxy or tunnel configuration blocked the provider request.",
    );
  });

  it("does not broadly rewrite non-streaming 'Unexpected token' JSON parse errors", () => {
    const msg = makeAssistantError("Unexpected token < in JSON at position 0");
    expect(formatAssistantErrorText(msg)).toBe("Unexpected token < in JSON at position 0");
  });

  it("does not rewrite non-streaming provider JSON request-validation diagnostics", () => {
    const msg = makeAssistantError("Expected value in JSON at position 12 for messages.0.content");
    expect(formatAssistantErrorText(msg)).toBe(
      "Expected value in JSON at position 12 for messages.0.content",
    );
  });

  it("keeps provider request-validation JSON diagnostics actionable", () => {
    const msg = makeAssistantError(
      '{"type":"error","error":{"type":"invalid_request_error","message":"Expected value in JSON at position 12 for messages.0.content"}}',
    );
    expect(formatAssistantErrorText(msg)).toBe(
      "LLM request rejected: Expected value in JSON at position 12 for messages.0.content",
    );
    expect(formatUserFacingAssistantErrorText(msg)).toBe(
      "LLM request failed: provider rejected the request schema or tool payload.",
    );
  });

  it("uses structured error body detail for model-not-found copy", () => {
    const msg = makeAssistantMessageFixture({
      errorMessage: "400 Param Incorrect",
      errorCode: "400",
      errorBody:
        '{"code":"400","message":"Param Incorrect","param":"Not supported model some-model-id"}',
      content: [],
    });

    expect(formatAssistantErrorText(msg)).toBe(
      "The selected model was not found by the provider. Check the model id or choose a different model.",
    );
    expect(formatUserFacingAssistantErrorText(msg)).toBe(
      "The selected model was not found by the provider. Check the model id or choose a different model.",
    );
  });
});

describe("formatRawAssistantErrorForUi", () => {
  it("renders HTTP code + type + message from Anthropic payloads", () => {
    const text = formatRawAssistantErrorForUi(
      '429 {"type":"error","error":{"type":"rate_limit_error","message":"Rate limited."},"request_id":"req_123"}',
    );

    expect(text).toContain("HTTP 429");
    expect(text).toContain("rate_limit_error");
    expect(text).toContain("Rate limited.");
    expect(text).not.toContain("req_123");
  });

  it("renders a generic unknown error message when raw is empty", () => {
    expect(formatRawAssistantErrorForUi("")).toContain("unknown error");
  });

  it("formats plain HTTP status lines", () => {
    expect(formatRawAssistantErrorForUi("500 Internal Server Error")).toBe(
      "HTTP 500: Internal Server Error",
    );
  });

  it("formats colon-delimited HTTP status lines", () => {
    expect(formatRawAssistantErrorForUi("HTTP 410: No body")).toBe("HTTP 410: No body");
  });

  it("formats plain provider internal errors without request ids", () => {
    expect(
      formatRawAssistantErrorForUi(
        "An error occurred while processing your request. Please include the request ID synthetic-provider-request-001 in your message.",
      ),
    ).toBe("The AI service returned an internal error. Please try again in a moment.");
  });

  it("sanitizes HTML error pages into a clean unavailable message", () => {
    const htmlError = `521 <!DOCTYPE html>
<html lang="en-US">
  <head><title>Web server is down | example.com | Cloudflare</title></head>
  <body>Ray ID: abc123</body>
</html>`;

    expect(formatRawAssistantErrorForUi(htmlError)).toBe(
      "The AI service is temporarily unavailable (HTTP 521). Please try again in a moment.",
    );
  });

  it("formats standalone Cloudflare challenge HTML into a clean provider error", () => {
    const htmlError = `<!DOCTYPE html>
<html lang="en-US">
  <head><title>Just a moment...</title></head>
  <body>
    <span id="challenge-error-text">Enable JavaScript and cookies to continue</span>
    <script src="/cdn-cgi/challenge-platform/h/g/orchestrate/chl_page/v1"></script>
  </body>
</html>`;

    expect(formatRawAssistantErrorForUi(htmlError)).toBe(
      "The provider returned an HTML error page instead of an API response. This usually means a CDN or gateway (e.g. Cloudflare) blocked the request. Retry in a moment or check provider status.",
    );
  });

  it("truncates fallback raw error text on UTF-16 code-point boundary without dangling surrogates", () => {
    // 601 UTF-16 code units: emoji (surrogate pair) straddles the 600-unit truncation boundary
    const prefix = "x".repeat(599);
    const emoji = "🎉"; // U+1F389 — high surrogate 0xD83C + low surrogate 0xDF89
    const raw = prefix + emoji; // 601 code units total

    const result = formatRawAssistantErrorForUi(raw);

    // Result must end with "…" after truncation
    expect(result).toMatch(/…$/);

    // Verify the truncated portion contains no dangling surrogates
    for (let i = 0; i < result.length - 1; i++) {
      const codeUnit = result.charCodeAt(i);
      // High surrogate (0xD800-0xDBFF) must be followed by a low surrogate
      if (codeUnit >= 0xd800 && codeUnit <= 0xdbff) {
        const next = result.charCodeAt(i + 1);
        expect(next >= 0xdc00 && next <= 0xdfff).toBe(true);
      }
      // Low surrogate (0xDC00-0xDFFF) must be preceded by a high surrogate
      if (codeUnit >= 0xdc00 && codeUnit <= 0xdfff) {
        const prev = i > 0 ? result.charCodeAt(i - 1) : -1;
        expect(prev >= 0xd800 && prev <= 0xdbff).toBe(true);
      }
    }
  });
});

describe("raw API error payload helpers", () => {
  it("recognizes provider-prefixed JSON payloads for observation fingerprints", () => {
    const raw =
      'Ollama API error: {"type":"error","error":{"type":"server_error","message":"Boom"},"request_id":"req_123"}';

    expect(isRawApiErrorPayload(raw)).toBe(true);
    expect(getApiErrorPayloadFingerprint(raw)).toBe(
      '{"error":{"message":"Boom","type":"server_error"},"request_id":"req_123","type":"error"}',
    );
  });

  it("recognizes flat JSON payloads with string error code and message (#74079)", () => {
    const raw =
      '{"error":"insufficient_balance","message":"Insufficient MBT balance. Top up or upgrade your subscription to continue.","upgradeUrl":"/settings/billing"}';
    expect(isRawApiErrorPayload(raw)).toBe(true);
    expect(formatRawAssistantErrorForUi(raw)).toBe(
      "LLM error insufficient_balance: Insufficient MBT balance. Top up or upgrade your subscription to continue.",
    );
  });
});

describe("formatBillingErrorMessage — authMode neutral copy (#80877)", () => {
  // OAuth/Max users should NOT see "API key" or "top up" language.
  it("returns neutral copy for oauth authMode — no 'API key' text", () => {
    const result = formatBillingErrorMessage("Anthropic", "claude-sonnet-4-5", "oauth");
    expect(result).not.toMatch(/api key/i);
    expect(result).not.toMatch(/top up/i);
    expect(result).toContain("check your account");
  });

  it("returns neutral copy for token authMode — no 'API key' text", () => {
    const result = formatBillingErrorMessage("Anthropic", "claude-sonnet-4-5", "token");
    expect(result).not.toMatch(/api key/i);
    expect(result).not.toMatch(/top up/i);
  });

  it("REGRESSION: api_key authMode still returns 'API key' copy", () => {
    const result = formatBillingErrorMessage("Anthropic", "claude-sonnet-4-5", "api_key");
    expect(result).toMatch(/api key/i);
    expect(result).toMatch(/top up/i);
  });

  it("REGRESSION: undefined authMode (legacy call-sites) still returns 'API key' copy", () => {
    const result = formatBillingErrorMessage("Anthropic", "claude-sonnet-4-5");
    expect(result).toMatch(/api key/i);
  });

  it("REGRESSION: no-provider call still returns generic 'API key' copy", () => {
    const result = formatBillingErrorMessage();
    expect(result).toMatch(/api key/i);
  });
});

describe("sanitizeUserFacingText — streaming JSON parse error (#59076)", () => {
  it("rewrites transport-classified malformed streaming fragments in error context", () => {
    const result = renderUserFacingText(MALFORMED_STREAMING_FRAGMENT_ERROR_MESSAGE, {
      errorContext: true,
    });
    expect(result).toBe("LLM streaming response contained a malformed fragment. Please try again.");
  });

  it("does not rewrite JSON parse error when not in error context", () => {
    // When not in error context, the text could be legitimate assistant content
    // mentioning JSON errors. Don't rewrite.
    const text =
      "Expected ',' or '}' after property value in JSON at position 334 (line 1 column 335)";
    const result = sanitizeUserFacingText(text, { errorContext: false });
    expect(result).toBe(text);
  });
});
