/**
 * Regression coverage for compact tool display formatting.
 * Ensures tool names, actions, and details stay readable and redacted.
 */
import { describe, expect, it } from "vitest";
import { resolveToolSearchCodeDisplayTarget } from "./tool-display-common.js";
import {
  hasShellCompoundCommand,
  scanTopLevelChars,
  splitTopLevelPipes,
  splitTopLevelStages,
} from "./tool-display-exec-shell.js";
import { resolveExecDetail } from "./tool-display-exec.js";
import {
  formatToolDetail,
  formatToolSummary,
  isShellToolDisplayName,
  resolveToolDisplay,
} from "./tool-display.js";

describe("isShellToolDisplayName", () => {
  it("matches shell tools whatever case the backend spells them in", () => {
    // The Claude CLI sends "Bash"; embedded runs send "bash"/"exec".
    for (const name of ["Bash", "bash", "BASH", "Exec", "exec", "shell"]) {
      expect(isShellToolDisplayName(name)).toBe(true);
    }
    for (const name of ["Read", "web_search", undefined, ""]) {
      expect(isShellToolDisplayName(name)).toBe(false);
    }
  });

  it("keeps the compact summary form for a capitalized shell tool", () => {
    const display = resolveToolDisplay({ name: "Bash", args: { command: "echo alpha" } });
    // Compact form is "<emoji> <detail>", not "<emoji> Bash: <detail>".
    expect(formatToolSummary(display)).toBe(`${display.emoji} ${formatToolDetail(display)}`);
  });
});

describe("tool display details", () => {
  it("preserves the curated presentation for historical image activity", () => {
    const display = resolveToolDisplay({
      name: "image",
      args: { image: "/tmp/screenshot.png", prompt: "Inspect the error" },
    });

    expect(display).toMatchObject({ emoji: "🖼️", title: "Image" });
  });

  it("uses the curated view_image presentation", () => {
    const display = resolveToolDisplay({
      name: "view_image",
      args: { path: "/tmp/screenshot.png", prompt: "Inspect the error" },
    });

    expect(display).toMatchObject({ emoji: "🖼️", title: "View Image" });
    expect(formatToolDetail(display)).toBe("path /tmp/screenshot.png, prompt Inspect the error");
  });

  it("keeps sessions_yield private context out of tool status", () => {
    const display = resolveToolDisplay({
      name: "sessions_yield",
      args: {
        message: "private resume context",
        acknowledgment: "Public waiting status",
      },
    });

    expect(formatToolSummary(display)).toBe("⏸️ Yield");
    expect(formatToolDetail(display)).toBeUndefined();
  });

  it("puts the camera PTZ operation before its node and device", () => {
    const detail = formatToolDetail(
      resolveToolDisplay({
        name: "nodes",
        args: {
          action: "camera_ptz",
          ptzOperation: "status",
          node: "Mac",
          deviceId: "camera-id",
        },
      }),
    );

    expect(detail).toBe("ptz operation status, node Mac, device id camera-id");
  });

  it("keeps same-line heredoc operators from attaching the body to later stages", () => {
    const command = "cat <<EOF && printf ok\nbody | secret\nEOF\nprintf done";
    const stages = splitTopLevelStages(command);

    expect(stages).toHaveLength(2);
    expect(stages[0]).toBe("cat <<EOF");
    expect(stages[1]).toContain("printf ok");
    expect(stages[1]).toContain("printf done");
    expect(stages[1]).not.toContain("body | secret");
    expect(splitTopLevelPipes(stages[1] ?? "")).toHaveLength(1);
  });

  it("summarizes tool-search code targets from described tool ids", () => {
    expect(
      resolveToolSearchCodeDisplayTarget({
        code: "const tool = await openclaw.tools.describe('openclaw:core:exec'); return await openclaw.tools.call(tool.id, { command: 'echo hi' });",
      }),
    ).toEqual({
      toolName: "openclaw:core:exec",
      displayToolName: "exec",
      displayArgs: { command: "echo hi" },
      detail: "echo hi",
      bridgeVerb: "call",
    });
  });

  it("normalizes direct tool-search catalog ids to native display names and args", () => {
    expect(
      resolveToolSearchCodeDisplayTarget({
        code: 'return await openclaw.tools.call("openclaw:core:exec", { command: "echo hi" });',
      }),
    ).toEqual({
      toolName: "openclaw:core:exec",
      displayToolName: "exec",
      displayArgs: { command: "echo hi" },
      detail: "echo hi",
      bridgeVerb: "call",
    });
  });

  it("preserves JS numeric literals in tool-search call args", () => {
    expect(
      resolveToolSearchCodeDisplayTarget({
        code: 'return await openclaw.tools.call("web_search", { query: "OpenClaw", count: 1e3, limit: +3, threshold: .5 });',
      })?.displayArgs,
    ).toEqual({
      query: "OpenClaw",
      count: 1000,
      limit: 3,
      threshold: 0.5,
    });
  });

  it("skips zero/false values for optional detail fields", () => {
    const detail = formatToolDetail(
      resolveToolDisplay({
        name: "sessions_spawn",
        args: {
          task: "double-message-bug-gpt",
          label: 0,
          runTimeoutSeconds: 0,
        },
      }),
    );

    expect(detail).toBe("double-message-bug-gpt");
  });

  it("includes only truthy boolean details", () => {
    const detail = formatToolDetail(
      resolveToolDisplay({
        name: "message",
        args: {
          action: "react",
          provider: "discord",
          to: "chan-1",
          remove: false,
        },
      }),
    );

    expect(detail).toContain("provider discord");
    expect(detail).toContain("to chan-1");
    expect(detail).not.toContain("remove");
  });

  it("keeps positive numbers and true booleans", () => {
    const detail = formatToolDetail(
      resolveToolDisplay({
        name: "sessions_history",
        args: {
          sessionKey: "agent:main:main",
          limit: 20,
          includeTools: true,
        },
      }),
    );

    expect(detail).toContain("session agent:main:main");
    expect(detail).toContain("limit 20");
    expect(detail).toContain("tools true");
  });

  it("formats read/write/edit with intent-first file detail", () => {
    const readDetail = formatToolDetail(
      resolveToolDisplay({
        name: "read",
        args: { file_path: "/tmp/a.txt", offset: 2, limit: 2 },
      }),
    );
    const writeDetail = formatToolDetail(
      resolveToolDisplay({
        name: "write",
        args: { file_path: "/tmp/a.txt", content: "abc" },
      }),
    );
    const editDetail = formatToolDetail(
      resolveToolDisplay({
        name: "edit",
        args: { path: "/tmp/a.txt", newText: "abcd" },
      }),
    );

    expect(readDetail).toBe("lines 2-3 from /tmp/a.txt");
    expect(writeDetail).toBe("to /tmp/a.txt (3 chars)");
    expect(editDetail).toBe("in /tmp/a.txt (4 chars)");
  });

  it("formats web_search query with quotes", () => {
    const detail = formatToolDetail(
      resolveToolDisplay({
        name: "web_search",
        args: { query: "OpenClaw docs", count: 3 },
      }),
    );

    expect(detail).toBe('for "OpenClaw docs" (top 3)');
  });

  it("formats web_search provider query shapes", () => {
    expect(
      formatToolDetail(
        resolveToolDisplay({
          name: "web_search",
          args: { q: "Codex OAuth API key", max_results: 5 },
        }),
      ),
    ).toBe('for "Codex OAuth API key" (top 5)');

    expect(
      formatToolDetail(
        resolveToolDisplay({
          name: "web_search",
          args: {
            search_query: [
              { q: "latest Kimi model" },
              { q: "latest Gemini model" },
              { q: "latest Claude model" },
              { q: "latest OpenAI model" },
            ],
          },
        }),
      ),
    ).toBe('for "latest Kimi model", "latest Gemini model", "latest Claude model"…');
  });

  it("formats Parallel's native objective + search_queries shape", () => {
    expect(
      formatToolDetail(
        resolveToolDisplay({
          name: "web_search",
          args: {
            objective: "Find the OpenClaw repository on GitHub",
            search_queries: ["openclaw github", "openclaw repository"],
            count: 5,
          },
        }),
      ),
    ).toBe(
      'for "Find the OpenClaw repository on GitHub", "openclaw github", "openclaw repository" (top 5)',
    );
  });

  it("summarizes exec commands with context", () => {
    const detail = formatToolDetail(
      resolveToolDisplay({
        name: "exec",
        args: {
          command:
            "set -euo pipefail\ngit -C /Users/adityasingh/.openclaw/workspace status --short | head -n 3",
          workdir: "/Users/adityasingh/.openclaw/workspace",
        },
      }),
    );

    expect(detail).toContain("check git status -> show first 3 lines");
    expect(detail).toContain("(agent)");
  });

  it("summarizes bash commands with the same command explainer", () => {
    const detail = formatToolDetail(
      resolveToolDisplay({
        name: "bash",
        args: { command: "sed -n '1,80p' extensions/discord/src/draft-stream.ts" },
        detailMode: "explain",
      }),
    );

    expect(detail).toBe("print lines 1-80 from extensions/discord/src/draft-stream.ts");
  });

  it("keeps shell compound commands intact instead of inventing command stages", () => {
    const loop = 'for d in $(find . -type d); do echo "$d"; ls "$d"; done';
    const conditional = "echo start && if test -f package.json; then pnpm test; fi";
    const subshell = "(echo one; echo two)";
    const functionBody = "f() { echo one; echo two; }";
    const functionKeyword = "function f { echo one; echo two; }";
    const hyphenatedFunction = "function deploy-prod { echo one; echo two; }";
    const namespacedFunction = "function log::info { echo one; echo two; }";
    const selectLoop = 'select d in a b; do echo "$d"; break; done';
    const doubleBracket = "[[ -f package.json && -f pnpm-lock.yaml ]] && pnpm test";
    const pipedSelect = "printf x | select d in a b; do break; done";
    const pipedDoubleBracket = "printf x | [[ -n x ]]";
    const backgroundSelect = "true & select d in a b; do break; done";
    const stderrPipedSelect = "printf x |& select d in a b; do break; done";
    const pipedFunction = "printf x | function deploy-prod { echo one; echo two; }";
    const conditionalFunction = "function deploy-prod if true; then echo ok; fi";
    const doubleBracketFunction = "function check [[ -n x ]]";
    const arithmeticFunction = "function bump (( n++ )) && pnpm test";
    const subshellFunction = "function sub() (echo one; echo two)";
    const posixConditionalFunction = "plain() if true; then echo ok; fi";
    const negatedDoubleBracket = "! [[ -f a && -f b ]] && pnpm test";
    const timedNegatedDoubleBracket = "time -p ! [[ -n x ]]";
    const negatedTimedDoubleBracket = "! time [[ -n x ]]";
    const operatorTimedSubshell = "time(echo one; echo two)";
    const operatorArithmeticFunction = "function bump(( n++ )) && pnpm test";

    for (const command of [
      loop,
      conditional,
      subshell,
      functionBody,
      functionKeyword,
      hyphenatedFunction,
      namespacedFunction,
      "deploy-prod() { echo one; echo two; }",
      "log::info() { echo one; echo two; }",
      selectLoop,
      "coproc worker { echo one; echo two; }",
      "coproc (echo one; echo two)",
      doubleBracket,
      pipedSelect,
      pipedDoubleBracket,
      backgroundSelect,
      stderrPipedSelect,
      pipedFunction,
      conditionalFunction,
      doubleBracketFunction,
      arithmeticFunction,
      subshellFunction,
      "function worker (echo one; echo two)",
      "function worker(echo one; echo two)",
      posixConditionalFunction,
      negatedDoubleBracket,
      timedNegatedDoubleBracket,
      negatedTimedDoubleBracket,
      operatorTimedSubshell,
      operatorArithmeticFunction,
      "time -- if true; then echo one; echo two; fi",
    ]) {
      expect(splitTopLevelStages(command)).toEqual([command]);
      expect(
        formatToolDetail(
          resolveToolDisplay({ name: "exec", args: { command }, detailMode: "explain" }),
        ),
      ).toBe(command);
    }

    for (const command of [
      "(( ready && enabled )) && pnpm test",
      "time (( ready || fallback )) && pnpm test",
      ["(\\", "( ready && enabled )) && pnpm test"].join("\n"),
      ["echo $\\", "(( ready && enabled )) && pnpm test"].join("\n"),
      "time(( n++ )) && pnpm test",
      "time -p(( n++ )) && pnpm test",
      "!(( n++ )) && pnpm test",
      "time -p -- (( n++ )) && pnpm test",
    ]) {
      const separatorIndex = command.lastIndexOf(" && ");
      expect(splitTopLevelStages(command)).toEqual([command.slice(0, separatorIndex), "pnpm test"]);
    }

    for (const command of [
      ["true && \\", "if true; then echo ok; fi"].join("\n"),
      ["printf x | \\", "select d in a b; do break; done"].join("\n"),
      ["true && \\\\", "if true; then echo ok; fi"].join("\n"),
    ]) {
      expect(splitTopLevelStages(command)).toEqual([command]);
    }

    for (const quoted of [
      "printf '%s' '; if ' && pnpm test",
      "printf '%s' 'function f { echo; }' && pnpm test",
      "printf '%s' 'select d; do echo; done' && pnpm test",
      "printf '%s' '[[ a && b ]]' && pnpm test",
      "printf '%s' $'can\\'t; if literal' && pnpm test",
      ["printf '%s' $\\", "'can\\'t; if literal' && pnpm test"].join("\n"),
    ]) {
      expect(splitTopLevelStages(quoted)).toEqual([
        quoted.slice(0, quoted.lastIndexOf(" && ")),
        "pnpm test",
      ]);
      expect(
        formatToolDetail(
          resolveToolDisplay({ name: "exec", args: { command: quoted }, detailMode: "explain" }),
        ),
      ).toBe("print text → run tests");
    }

    for (const command of [
      "select-editor --version && pnpm test",
      "coprocess --version && pnpm test",
      "[[helper arg && pnpm test",
      '"x"select --version && pnpm test',
      "select'' --version && pnpm test",
      'selec"t" --version && pnpm test',
    ]) {
      expect(splitTopLevelStages(command)).toEqual([
        command.slice(0, command.lastIndexOf(" && ")),
        "pnpm test",
      ]);
    }

    for (const command of [
      "function f{ echo one; echo two; }",
      "function f {not-a-body; echo two; }",
      "printf x >& select",
      "printf x &> select",
      "printf x >| select",
    ]) {
      expect(hasShellCompoundCommand(command)).toBe(false);
    }
  });

  it("keeps normal search patterns concise", () => {
    for (const [command, expected] of [
      ['rg "foo|bar" src/agents', 'search "foo|bar" in src/agents'],
      ["rg 'search engine' src/agents", 'search "search engine" in src/agents'],
      ["rg 'search textual data' src/agents", 'search "search textual data" in src/agents'],
      ["rg 'research text in docs' src/agents", 'search "research text in docs" in src/agents'],
    ]) {
      expect(
        formatToolDetail(
          resolveToolDisplay({ name: "exec", args: { command }, detailMode: "explain" }),
        ),
      ).toBe(expected);
    }
  });

  it("uses a neutral label for recursive or malformed search patterns", () => {
    for (const command of [
      `rg 'search "foo" in src/agents' src`,
      `rg 'Bash failed: search "foo" in src|search "bar"' src`,
      `rg 'run printf -> search "foo" in src' src`,
      "rg 'search text' src",
      "rg 'search text in src/agents' src",
      "rg 'foo|search text in src/agents' src",
      "rg 'run printf -> search text' src",
      "rg 'line1\nline2' src",
      "rg 'line with trailing newline\n' src",
      "rg '`generated command`' src",
      `rg '${"x".repeat(121)}' src`,
      `rg '${" ".repeat(121)}x' src`,
    ]) {
      expect(
        formatToolDetail(
          resolveToolDisplay({ name: "exec", args: { command }, detailMode: "explain" }),
        ),
      ).toBe("search text in src");
    }
  });

  it("sanitizes recursive search patterns inside pipelines", () => {
    expect(
      formatToolDetail(
        resolveToolDisplay({
          name: "exec",
          args: { command: `printf x | rg 'search "foo" in src' .` },
          detailMode: "explain",
        }),
      ),
    ).toBe("print text -> search text in .");
  });

  it("moves cd path to context suffix and appends raw command", () => {
    const detail = formatToolDetail(
      resolveToolDisplay({
        name: "exec",
        args: { command: "cd ~/my-project && npm install" },
      }),
    );

    expect(detail).toBe("install dependencies (in ~/my-project), `cd ~/my-project && npm install`");
  });

  it("omits raw command details in explain mode", () => {
    const detail = formatToolDetail(
      resolveToolDisplay({
        name: "exec",
        args: { command: "cd ~/my-project && npm install" },
        detailMode: "explain",
      }),
    );

    expect(detail).toBe("install dependencies (in ~/my-project)");
  });

  it("uses compact workspace markers for common workspace paths", () => {
    expect(
      formatToolDetail(
        resolveToolDisplay({
          name: "bash",
          args: { command: "git fetch", workdir: "/Users/peter/mantis-workspace/openclaw" },
          detailMode: "explain",
        }),
      ),
    ).toBe("fetch git changes (agent)");

    expect(
      formatToolDetail(
        resolveToolDisplay({
          name: "bash",
          args: { command: "git status", workdir: "/Users/peter/Projects/openclaw" },
          detailMode: "explain",
        }),
      ),
    ).toBe("check git status (repo)");

    expect(
      formatToolDetail(
        resolveToolDisplay({
          name: "bash",
          args: {
            command: "command -v discrawl",
            workdir: "/root/.openclaw/sandboxes/agent-clawsweeper-sandbox-discor-766423d0",
          },
          detailMode: "explain",
        }),
      ),
    ).toBe("command -v discrawl");
  });

  it("omits bash and exec names from compact tool summaries", () => {
    expect(
      formatToolSummary(
        resolveToolDisplay({
          name: "bash",
          args: { command: "git fetch", workdir: "/Users/peter/mantis-workspace/openclaw" },
          detailMode: "explain",
        }),
      ),
    ).toBe("🛠️ fetch git changes (agent)");

    expect(
      formatToolSummary(
        resolveToolDisplay({
          name: "web_search",
          args: { query: "OpenClaw docs" },
        }),
      ),
    ).toBe('🔎 Web Search: for "OpenClaw docs"');
  });

  it("moves cd path to context suffix with multiple stages and raw command", () => {
    const detail = formatToolDetail(
      resolveToolDisplay({
        name: "exec",
        args: { command: "cd ~/my-project && npm install && npm test" },
      }),
    );

    expect(detail).toBe(
      "install dependencies → run tests (in ~/my-project), `cd ~/my-project && npm install && npm test`",
    );
  });

  it("moves pushd path to context suffix and appends raw command", () => {
    const detail = formatToolDetail(
      resolveToolDisplay({
        name: "exec",
        args: { command: "pushd /tmp && git status" },
      }),
    );

    expect(detail).toBe("check git status (in /tmp), `pushd /tmp && git status`");
  });

  it("clears inferred cwd when popd is stripped from preamble", () => {
    const detail = formatToolDetail(
      resolveToolDisplay({
        name: "exec",
        args: { command: "pushd /tmp && popd && npm install" },
      }),
    );

    expect(detail).toBe("install dependencies, `pushd /tmp && popd && npm install`");
  });

  it("moves cd path to context suffix with || separator", () => {
    const detail = formatToolDetail(
      resolveToolDisplay({
        name: "exec",
        args: { command: "cd /app || npm install" },
      }),
    );

    // || means npm install runs when cd FAILS — cd should NOT be stripped as preamble.
    // Both stages are summarized; cd is not treated as context prefix.
    expect(detail).toMatch(/^run cd \/app → install dependencies/);
  });

  it("explicit workdir takes priority over cd path", () => {
    const detail = formatToolDetail(
      resolveToolDisplay({
        name: "exec",
        args: { command: "cd /tmp && npm install", workdir: "/app" },
      }),
    );

    expect(detail).toBe("install dependencies (in /app), `cd /tmp && npm install`");
  });

  it("summarizes all stages and appends raw command", () => {
    const detail = formatToolDetail(
      resolveToolDisplay({
        name: "exec",
        args: { command: "git fetch && git rebase origin/main" },
      }),
    );

    expect(detail).toBe(
      "fetch git changes → rebase git branch, `git fetch && git rebase origin/main`",
    );
  });

  it("falls back to raw command for unknown binaries", () => {
    const detail = formatToolDetail(
      resolveToolDisplay({
        name: "exec",
        args: { command: "jj rebase -s abc -d main" },
      }),
    );

    expect(detail).toBe("jj rebase -s abc -d main");
  });

  it("falls back to raw command for unknown binary with cwd", () => {
    const detail = formatToolDetail(
      resolveToolDisplay({
        name: "exec",
        args: { command: "mycli deploy --prod", workdir: "/app" },
      }),
    );

    expect(detail).toBe("mycli deploy --prod (in /app)");
  });

  it("keeps multi-stage summary when only some stages are generic", () => {
    const detail = formatToolDetail(
      resolveToolDisplay({
        name: "exec",
        args: { command: "cargo build && npm test" },
      }),
    );

    // "run cargo build" is generic, but "run tests" is known — keep joined summary
    expect(detail).toMatch(/^run cargo build → run tests/);
  });

  it("handles standalone cd as raw command", () => {
    const detail = formatToolDetail(
      resolveToolDisplay({
        name: "exec",
        args: { command: "cd /tmp" },
      }),
    );

    // standalone cd (no following command) — treated as raw since it's generic
    expect(detail).toBe("cd /tmp");
  });

  it("handles chained cd commands using last path", () => {
    const detail = formatToolDetail(
      resolveToolDisplay({
        name: "exec",
        args: { command: "cd /tmp && cd /app" },
      }),
    );

    // both cd's are preamble; last path wins
    expect(detail).toBe("cd /tmp && cd /app (in /app)");
  });

  it("respects quotes when splitting preamble separators", () => {
    const detail = formatToolDetail(
      resolveToolDisplay({
        name: "exec",
        args: { command: 'export MSG="foo && bar" && echo test' },
      }),
    );

    // The && inside quotes must not be treated as a separator —
    // summary line should be "print text", not "run export" (which would happen
    // if the quoted && was mistaken for a real separator).
    expect(detail).toMatch(/^print text/);
  });

  it("recognizes heredoc/inline script exec details", () => {
    const pyDetail = formatToolDetail(
      resolveToolDisplay({
        name: "exec",
        args: {
          command: "python3 <<PY\nprint('x')\nPY",
          workdir: "/Users/adityasingh/.openclaw/workspace",
        },
      }),
    );
    const nodeCheckDetail = formatToolDetail(
      resolveToolDisplay({
        name: "exec",
        args: {
          command: "node --check /tmp/test.js",
          workdir: "/Users/adityasingh/.openclaw/workspace",
        },
      }),
    );
    const nodeShortCheckDetail = formatToolDetail(
      resolveToolDisplay({
        name: "exec",
        args: {
          command: "node -c /tmp/test.js",
          workdir: "/Users/adityasingh/.openclaw/workspace",
        },
      }),
    );

    expect(pyDetail).toContain("run python3 inline script (heredoc)");
    expect(nodeCheckDetail).toContain("check js syntax for /tmp/test.js");
    expect(nodeShortCheckDetail).toContain("check js syntax for /tmp/test.js");
  });

  it("does not split heredoc body content into exec stages", () => {
    const detail = formatToolDetail(
      resolveToolDisplay({
        name: "exec",
        args: {
          command: [
            "python3 <<'PY'",
            "const slugify = () => 'court-mix';",
            "if (true) console.log('a') && console.log('b');",
            "cat <<YAML",
            "- uses: subosito/flutter-action@v2",
            "YAML",
            "PY",
          ].join("\n"),
          workdir: "/Users/example/.openclaw/workspace",
        },
        detailMode: "explain",
      }),
    );

    expect(detail).toBe("run python3 inline script (heredoc) (agent)");
  });

  it("keeps command stages after a heredoc terminator", () => {
    const detail = formatToolDetail(
      resolveToolDisplay({
        name: "exec",
        args: {
          command: ["python3 <<'PY'", "print('body && not a command')", "PY", "npm test"].join(
            "\n",
          ),
        },
        detailMode: "explain",
      }),
    );

    expect(detail).toBe("run python3 inline script (heredoc) → run tests");
  });

  it("matches shell-quoted heredoc terminators before keeping later stages", () => {
    const detail = formatToolDetail(
      resolveToolDisplay({
        name: "exec",
        args: {
          command: ["python3 <<\\PY", "print('body && not a command')", "PY", "npm test"].join(
            "\n",
          ),
        },
        detailMode: "explain",
      }),
    );

    expect(detail).toBe("run python3 inline script (heredoc) → run tests");
  });

  it("keeps heredoc body separators out of top-level stage splitting", () => {
    const stages = splitTopLevelStages(
      [
        "mkdir -p .openclaw/tmp/farm-notices",
        "cat > .openclaw/tmp/farm-notices/ventura.txt <<'EOF'",
        "Buenos dias equipo; se ajusta la orden A1251718:",
        "sc-carwhi(100) && sc-cardoc(100) || sc-carwhi(100)",
        "Gracias.",
        "EOF",
        "./scripts/email_preview_new --to farm@example.com && ./scripts/email_preview_new --to farm2@example.com",
      ].join("\n"),
    );

    expect(stages).toEqual([
      [
        "mkdir -p .openclaw/tmp/farm-notices",
        "cat > .openclaw/tmp/farm-notices/ventura.txt <<'EOF'",
        "Buenos dias equipo; se ajusta la orden A1251718:",
        "sc-carwhi(100) && sc-cardoc(100) || sc-carwhi(100)",
        "Gracias.",
        "EOF",
        "./scripts/email_preview_new --to farm@example.com",
      ].join("\n"),
      "./scripts/email_preview_new --to farm2@example.com",
    ]);
  });

  it("matches escaped heredoc delimiters in top-level stage splitting", () => {
    const command = [
      "cat <<\\EOF",
      "body; not a stage && not a stage || not a stage",
      "EOF",
      "printf done && npm test",
    ].join("\n");

    expect(splitTopLevelStages(command)).toEqual([
      ["cat <<\\EOF", "body; not a stage && not a stage || not a stage", "EOF", "printf done"].join(
        "\n",
      ),
      "npm test",
    ]);
  });

  it("does not treat the overlapping end of a here-string as a heredoc", () => {
    const command = ["cat <<<true", "npm test && npm build", "true", "pnpm test"].join("\n");

    expect(splitTopLevelStages(command)).toEqual([
      ["cat <<<true", "npm test"].join("\n"),
      ["npm build", "true", "pnpm test"].join("\n"),
    ]);

    const detail = formatToolDetail(
      resolveToolDisplay({ name: "exec", args: { command }, detailMode: "explain" }),
    );
    expect(detail).toContain("run build");
  });

  it("ignores heredoc-looking tokens inside shell comments", () => {
    const command = [
      "export MODE=test # next block uses <<EOF && this is still a comment",
      "cat <<EOF",
      "body && data",
      "EOF",
      "npm test && npm build",
    ].join("\n");

    const detail = formatToolDetail(
      resolveToolDisplay({ name: "exec", args: { command }, detailMode: "explain" }),
    );
    expect(detail).toBe("show output → run tests → run build");

    expect(splitTopLevelStages("echo foo\\ #bar && npm test")).toEqual([
      "echo foo\\ #bar",
      "npm test",
    ]);
    expect(splitTopLevelStages("echo prefix$(printf suffix)#bar && npm test")).toEqual([
      "echo prefix$(printf suffix)#bar",
      "npm test",
    ]);

    const bodies: string[] = [];
    const scanBodies = (input: string) => {
      scanTopLevelChars(
        input,
        () => true,
        (_operatorIndex, start, end) => bodies.push(input.slice(start, end)),
      );
    };
    scanBodies(["(printf ok)# comment uses <<STOP", "npm test && npm build", "STOP"].join("\n"));
    scanBodies(["echo $(# comment uses <<STOP", "printf ok", ") && npm test"].join("\n"));
    expect(bodies).toEqual([]);

    for (const expansion of [
      "echo $(printf suffix)#tag",
      "echo <(printf suffix)#tag",
      "echo $(case x in x) printf ok;; esac)#tag",
    ]) {
      const withHeredoc = [expansion + " <<STOP", "body", "STOP"].join("\n");
      scanBodies(withHeredoc);
    }
    expect(bodies).toEqual(["body\nSTOP", "body\nSTOP", "body\nSTOP"]);
  });

  it("does not treat arithmetic bitshifts as heredocs", () => {
    for (const firstLine of ["echo $((flags << true ))", "((flags << true ))"]) {
      const command = [firstLine, "npm test && npm build", "true", "pnpm test"].join("\n");

      expect(splitTopLevelStages(command)).toEqual([
        [firstLine, "npm test"].join("\n"),
        ["npm build", "true", "pnpm test"].join("\n"),
      ]);

      const detail = formatToolDetail(
        resolveToolDisplay({ name: "exec", args: { command }, detailMode: "explain" }),
      );
      expect(detail).toContain("run build");
    }
  });

  it("keeps heredoc body pipes out of top-level stage summaries", () => {
    const detail = formatToolDetail(
      resolveToolDisplay({
        name: "exec",
        args: {
          command: [
            "cat > .openclaw/tmp/farm-notices/ventura.txt <<-'EOF'",
            "\tBuenos dias equipo; se ajusta la orden A1251718:",
            "\tsc-carwhi(100) && sc-cardoc(100) || sc-carwhi(100)",
            "\tGracias.",
            "\tEOF",
            "./scripts/email_preview_new --to farm@example.com && ./scripts/email_preview_new --to farm2@example.com",
          ].join("\n"),
        },
        detailMode: "explain",
      }),
    );

    expect(detail).toBe("show output → run email_preview_new → run email_preview_new");
  });

  it("consumes same-line heredocs in declaration order before splitting later stages", () => {
    const stages = splitTopLevelStages(
      [
        "cat <<'FIRST' <<-\"SECOND\"",
        "first; body && body || body | body",
        "FIRST",
        "\tsecond; body && body || body | body",
        "\tSECOND",
        "printf done && npm test",
      ].join("\n"),
    );

    expect(stages).toEqual([
      [
        "cat <<'FIRST' <<-\"SECOND\"",
        "first; body && body || body | body",
        "FIRST",
        "\tsecond; body && body || body | body",
        "\tSECOND",
        "printf done",
      ].join("\n"),
      "npm test",
    ]);
  });

  it("splits a real pipe after the final same-line heredoc terminator", () => {
    const command = [
      "cat <<ONE <<-'TWO'",
      "one | body",
      "ONE",
      "\ttwo && body",
      "\tTWO",
      "cat result | wc -l",
    ].join("\n");

    expect(splitTopLevelPipes(command)).toEqual([
      ["cat <<ONE <<-'TWO'", "one | body", "ONE", "\ttwo && body", "\tTWO", "cat result"].join(
        "\n",
      ),
      "wc -l",
    ]);
  });

  it("appends node name to exec detail when node is set", () => {
    const detail = formatToolDetail(
      resolveToolDisplay({
        name: "exec",
        args: {
          command: "docker pull pihole/pihole:latest",
          host: "node",
          node: "raspberrypi",
        },
      }),
    );

    expect(detail).toContain("node: raspberrypi");
  });

  it("includes both cwd and node name in exec detail for known commands", () => {
    const detail = formatToolDetail(
      resolveToolDisplay({
        name: "exec",
        args: {
          command: "npm install",
          workdir: "/app",
          host: "node",
          node: "raspberrypi",
        },
      }),
    );

    expect(detail).toContain("(in /app)");
    expect(detail).toContain("node: raspberrypi");
  });

  it("omits node label when node param is absent or empty", () => {
    const detail = formatToolDetail(
      resolveToolDisplay({
        name: "exec",
        args: { command: "npm install", host: "gateway" },
      }),
    );

    expect(detail).not.toContain("node:");
  });

  it("omits node label when host is not 'node' even if node is set", () => {
    for (const host of ["gateway", "sandbox", "auto"]) {
      const detail = formatToolDetail(
        resolveToolDisplay({
          name: "exec",
          args: { command: "npm install", host, node: "raspberrypi" },
        }),
      );

      expect(detail).not.toContain("node:");
    }
  });
});

describe("compactRawCommand middle truncation", () => {
  it("preserves start and end of long commands", () => {
    // Use an unknown binary so resolveExecDetail returns the compact raw form directly.
    const longCommand =
      "/opt/custom/bin/my-processor --input /data/warehouse/2024/q1/transactions/raw/batch_001.csv --output /data/warehouse/2024/q1/transactions/processed/batch_001_clean.csv";
    const result = resolveExecDetail({ command: longCommand });
    // Should contain the start of the command
    expect(result).toContain("/opt/custom/bin/my-processor");
    // Should contain the end (filename)
    expect(result).toContain("batch_001_clean.csv");
    // Should contain the ellipsis for middle truncation
    expect(result).toContain("…");
    // Ellipsis should be in the middle, not at the end
    expect(result).not.toMatch(/…$/);
  });

  it("does not truncate short commands", () => {
    // Use an unknown binary so resolveExecDetail returns the compact raw form directly.
    const result = resolveExecDetail({ command: "/opt/custom/bin/my-tool --version" });
    expect(result).toBe("/opt/custom/bin/my-tool --version");
  });

  it("redacts credential-like tails before middle truncation", () => {
    // The --token flag and its value sit in the middle of a long command.
    // Without redaction-before-truncation, middle truncation could cut out
    // the --token flag context but preserve the raw secret at the tail.
    const longCommand =
      "/opt/custom/bin/deploy --region us-east-1 --token sk-proj-ABCDEFGHIJKLMNOP1234567890abcdefghij --output /data/results/deploy-output.json";
    const result = resolveExecDetail({ command: longCommand });
    // The sk- prefixed token must be redacted (masked) before truncation
    expect(result).not.toContain("ABCDEFGHIJKLMNOP1234567890abcdefghij");
  });

  it("uses the canonical tool payload redactor before compacting raw commands", () => {
    const longCommand =
      "/opt/custom/bin/deploy --aws-key AKIDABCDEFGHIJKLMNOP1234567890 --output /data/results/deploy-output.json";
    const result = resolveExecDetail({ command: longCommand });

    expect(result).not.toContain("AKIDABCDEFGHIJKLMNOP1234567890");
    expect(result).toContain("AKIDAB…7890");
  });

  it("does not split a surrogate pair when the head boundary lands on an emoji", () => {
    // The one-line form is 140 UTF-16 units. With the default maxLength=120 the head
    // slice ends at index 59, but the 😀 emoji (U+1F600, a surrogate pair) occupies
    // indices 58-59 — so a raw .slice(0, 59) would keep the high surrogate and drop
    // its low half, leaving a lone surrogate that renders as the replacement char.
    const emoji = String.fromCodePoint(0x1f600);
    // Unknown binary so resolveExecDetail returns the compact raw form directly.
    const longCommand = `/opt/custom/bin/run ${"a".repeat(38)}${emoji}${"b".repeat(80)}`;
    const result = resolveExecDetail({ command: longCommand });

    expect(result).toBeDefined();
    // The whole emoji is dropped at the boundary rather than half of it.
    expect(result).not.toContain(emoji);
    // No dangling/lone surrogate code units remain in the rendered detail.
    expect(result).not.toMatch(/[\uD800-\uDBFF](?![\uDC00-\uDFFF])/);
    expect(result).not.toMatch(/(?<![\uD800-\uDBFF])[\uDC00-\uDFFF]/);
    // Start and end of the command are still preserved around the ellipsis.
    expect(result).toContain("/opt/custom/bin/run");
    expect(result).toContain("…");
    expect(result).toMatch(/b{4}$/);
  });
});

describe("coerceDisplayValue middle truncation", () => {
  it("preserves start and end of long string values", () => {
    const longPath =
      "/usr/local/share/very/deeply/nested/directory/structure/" +
      "a".repeat(150) +
      "/important-file.txt";
    const detail = formatToolDetail(
      resolveToolDisplay({
        name: "sessions_spawn",
        args: { task: longPath },
      }),
    );
    // Should contain the start of the path
    expect(detail).toContain("/usr/local/share/");
    // Should contain the end (filename)
    expect(detail).toContain("important-file.txt");
    // Should contain the ellipsis for middle truncation
    expect(detail).toContain("…");
  });

  it("does not truncate short string values", () => {
    const detail = formatToolDetail(
      resolveToolDisplay({
        name: "sessions_spawn",
        args: { task: "short-task-name" },
      }),
    );
    expect(detail).toBe("short-task-name");
    expect(detail).not.toContain("…");
  });

  it("redacts credential-like values in long generic string details", () => {
    // A long string whose tail contains a GitHub PAT. Without
    // redaction-before-truncation, middle truncation could preserve
    // the raw token at the tail after its prefix context is cut.
    const longValue =
      "Deploying service to production cluster with auth ghp_ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnop and " +
      "x".repeat(200) +
      " final-step";
    const detail = formatToolDetail(
      resolveToolDisplay({
        name: "sessions_spawn",
        args: { task: longValue },
      }),
    );
    // The ghp_ token must be redacted before truncation
    expect(detail).not.toContain("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnop");
  });

  it("uses the canonical tool payload redactor before compacting string details", () => {
    const longValue =
      "Deploying with AWS key AKIDABCDEFGHIJKLMNOP1234567890 and " +
      "x".repeat(200) +
      " final-step";
    const detail = formatToolDetail(
      resolveToolDisplay({
        name: "sessions_spawn",
        args: { task: longValue },
      }),
    );

    expect(detail).not.toContain("AKIDABCDEFGHIJKLMNOP1234567890");
    expect(detail).toContain("AKIDAB…7890");
  });
});
