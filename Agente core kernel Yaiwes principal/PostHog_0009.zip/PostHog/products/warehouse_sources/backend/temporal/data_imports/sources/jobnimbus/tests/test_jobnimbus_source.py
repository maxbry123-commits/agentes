import pytest
from unittest import mock

from parameterized import parameterized

from posthog.schema import ReleaseStatus, SourceFieldInputConfig

from products.warehouse_sources.backend.temporal.data_imports.sources.generated_configs.jobnimbus import (
    JobNimbusSourceConfig,
)
from products.warehouse_sources.backend.temporal.data_imports.sources.jobnimbus.source import JobNimbusSource


class TestJobNimbusSource:
    def setup_method(self) -> None:
        self.source = JobNimbusSource()
        self.team_id = 123
        self.config = JobNimbusSourceConfig(api_key="jn-key")

    def test_get_source_config(self) -> None:
        config = self.source.get_source_config
        assert config.name.value == "JobNimbus"
        assert config.label == "JobNimbus"
        assert config.releaseStatus == ReleaseStatus.ALPHA
        # A finished source is visible — it must not carry the scaffolding flag.
        assert not config.unreleasedSource
        assert config.docsUrl == "https://posthog.com/docs/cdp/sources/jobnimbus"

        field_names = [f.name for f in config.fields if isinstance(f, SourceFieldInputConfig)]
        assert field_names == ["api_key"]

    def test_no_connection_host_fields(self) -> None:
        # The only field is the secret API key; the base URL is hardcoded, so there is no non-secret
        # field an editor could retarget to reuse a preserved key against another account.
        assert self.source.connection_host_fields == []

    @parameterized.expand(
        [
            ("401 Client Error: Unauthorized for url: https://app.jobnimbus.com/api1/contacts?size=100&from=0",),
            ("403 Client Error: Forbidden for url: https://app.jobnimbus.com/api1/jobs?size=100&from=0",),
        ]
    )
    def test_non_retryable_errors_match_auth_failures(self, observed_error: str) -> None:
        non_retryable = self.source.get_non_retryable_errors()
        assert any(key in observed_error for key in non_retryable)

    @parameterized.expand(
        [
            ("500 Server Error: Internal Server Error for url: https://app.jobnimbus.com/api1/contacts",),
            ("429 Client Error: Too Many Requests for url: https://app.jobnimbus.com/api1/jobs",),
        ]
    )
    def test_non_retryable_errors_ignore_transient(self, unrelated_error: str) -> None:
        non_retryable = self.source.get_non_retryable_errors()
        assert not any(key in unrelated_error for key in non_retryable)

    @parameterized.expand(
        [
            (True, None),
            (False, "Invalid JobNimbus API key"),
            (False, "Could not validate JobNimbus API key"),
        ]
    )
    @mock.patch(
        "products.warehouse_sources.backend.temporal.data_imports.sources.jobnimbus.source._validate_credentials"
    )
    def test_validate_credentials_delegates(
        self,
        expected_valid: bool,
        expected_message: str | None,
        mock_validate: mock.MagicMock,
    ) -> None:
        # The status→message mapping is exercised against the real function in test_jobnimbus.py;
        # here we only prove the source forwards the account-wide api_key and returns the verdict.
        mock_validate.return_value = (expected_valid, expected_message)
        is_valid, returned = self.source.validate_credentials(self.config, self.team_id)
        assert is_valid is expected_valid
        assert returned == expected_message
        mock_validate.assert_called_once_with("jn-key")

    @mock.patch("products.warehouse_sources.backend.temporal.data_imports.sources.jobnimbus.source.jobnimbus_source")
    def test_source_for_pipeline_plumbs_arguments(self, mock_source: mock.MagicMock) -> None:
        inputs = mock.MagicMock()
        inputs.schema_name = "contacts"
        inputs.team_id = 123
        inputs.job_id = "job-1"
        manager = mock.MagicMock()

        self.source.source_for_pipeline(self.config, manager, inputs)

        mock_source.assert_called_once()
        kwargs = mock_source.call_args.kwargs
        assert kwargs["api_key"] == "jn-key"
        assert kwargs["endpoint"] == "contacts"
        assert kwargs["team_id"] == 123
        assert kwargs["job_id"] == "job-1"
        assert kwargs["resumable_source_manager"] is manager

    def test_source_for_pipeline_rejects_unknown_schema(self) -> None:
        inputs = mock.MagicMock()
        inputs.schema_name = "not_a_table"
        with pytest.raises(ValueError, match="Unknown JobNimbus schema 'not_a_table'"):
            self.source.source_for_pipeline(self.config, mock.MagicMock(), inputs)
