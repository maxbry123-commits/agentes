import re
from typing import Optional, cast

from posthog.schema import (
    DataWarehouseSourceCategory,
    ExternalDataSourceType as SchemaExternalDataSourceType,
    SourceConfig,
    SourceFieldInputConfig,
    SourceFieldInputConfigType,
)

from products.warehouse_sources.backend.temporal.data_imports.sources.chargebee.chargebee import (
    ChargebeeResumeConfig,
    chargebee_source,
    validate_credentials as validate_chargebee_credentials,
)
from products.warehouse_sources.backend.temporal.data_imports.sources.chargebee.settings import (
    ENDPOINTS,
    INCREMENTAL_FIELDS,
)
from products.warehouse_sources.backend.temporal.data_imports.sources.common.base import FieldType, ResumableSource
from products.warehouse_sources.backend.temporal.data_imports.sources.common.canonical_descriptions import (
    CanonicalDescriptions,
)
from products.warehouse_sources.backend.temporal.data_imports.sources.common.registry import SourceRegistry
from products.warehouse_sources.backend.temporal.data_imports.sources.common.resumable import ResumableSourceManager
from products.warehouse_sources.backend.temporal.data_imports.sources.common.schema import (
    SourceSchema,
    build_endpoint_schemas,
)
from products.warehouse_sources.backend.temporal.data_imports.sources.common.typings import SourceInputs, SourceResponse
from products.warehouse_sources.backend.temporal.data_imports.sources.generated_configs.chargebee import (
    ChargebeeSourceConfig,
)
from products.warehouse_sources.backend.types import ExternalDataSourceType

# The site name is interpolated into https://{site_name}.chargebee.com, so it must be a bare DNS
# subdomain: alphanumerics and hyphens, starting alphanumeric. This keeps outbound traffic pinned
# to *.chargebee.com (a value with a scheme, dot, or path can't build another host). Digits are
# allowed; a letters-only check rejected valid site names like "acme2024".
_SITE_NAME_RE = re.compile(r"^[a-zA-Z0-9][a-zA-Z0-9-]*$")


@SourceRegistry.register
class ChargebeeSource(ResumableSource[ChargebeeSourceConfig, ChargebeeResumeConfig]):
    lists_tables_without_credentials = True  # static endpoint catalog — safe for public docs
    supported_versions = ("v2",)
    default_version = "v2"
    api_docs_url = "https://apidocs.chargebee.com/docs/api"

    @property
    def source_type(self) -> ExternalDataSourceType:
        return ExternalDataSourceType.CHARGEBEE

    def get_non_retryable_errors(self) -> dict[str, str | None]:
        return {
            "403 Client Error: Forbidden for url": "Chargebee authentication failed. Please check your API key and site name.",
            "Unauthorized for url": "Chargebee authentication failed. Please check your API key and site name.",
        }

    def get_canonical_descriptions(self) -> CanonicalDescriptions:
        from products.warehouse_sources.backend.temporal.data_imports.sources.chargebee.canonical_descriptions import (
            CANONICAL_DESCRIPTIONS,
        )

        return CANONICAL_DESCRIPTIONS

    def get_schemas(
        self,
        config: ChargebeeSourceConfig,
        team_id: int,
        with_counts: bool = False,
        names: list[str] | None = None,
        force_refresh: bool = False,
        api_version: str | None = None,
    ) -> list[SourceSchema]:
        return build_endpoint_schemas(ENDPOINTS, INCREMENTAL_FIELDS, names)

    def validate_credentials(
        self,
        config: ChargebeeSourceConfig,
        team_id: int,
        schema_name: Optional[str] = None,
        api_version: str | None = None,
    ) -> tuple[bool, str | None]:
        if not _SITE_NAME_RE.match(config.site_name):
            return (
                False,
                "That doesn't look like a Chargebee site name. Enter just the site name "
                "(the 'acme' in 'acme.chargebee.com'), not the full URL.",
            )

        if validate_chargebee_credentials(config.api_key, config.site_name):
            return True, None

        return False, "Invalid credentials"

    def get_resumable_source_manager(self, inputs: SourceInputs) -> ResumableSourceManager[ChargebeeResumeConfig]:
        return ResumableSourceManager[ChargebeeResumeConfig](inputs, ChargebeeResumeConfig)

    def source_for_pipeline(
        self,
        config: ChargebeeSourceConfig,
        resumable_source_manager: ResumableSourceManager[ChargebeeResumeConfig],
        inputs: SourceInputs,
    ) -> SourceResponse:
        resource = chargebee_source(
            api_key=config.api_key,
            site_name=config.site_name,
            endpoint=inputs.schema_name,
            team_id=inputs.team_id,
            job_id=inputs.job_id,
            resumable_source_manager=resumable_source_manager,
            should_use_incremental_field=inputs.should_use_incremental_field,
            db_incremental_field_last_value=inputs.db_incremental_field_last_value
            if inputs.should_use_incremental_field
            else None,
        )
        return SourceResponse(
            name=resource.name,
            items=lambda: resource,
            primary_keys=["id"],
            column_hints=resource.column_hints,
        )

    @property
    def get_source_config(self) -> SourceConfig:
        return SourceConfig(
            name=SchemaExternalDataSourceType.CHARGEBEE,
            category=DataWarehouseSourceCategory.PAYMENTS___BILLING,
            docsUrl="https://posthog.com/docs/cdp/sources/chargebee",
            iconPath="/static/services/chargebee.png",
            fields=cast(
                list[FieldType],
                [
                    SourceFieldInputConfig(
                        name="api_key",
                        label="API key",
                        type=SourceFieldInputConfigType.PASSWORD,
                        required=True,
                        placeholder="",
                        secret=True,
                    ),
                    SourceFieldInputConfig(
                        name="site_name",
                        label="Site name (subdomain)",
                        type=SourceFieldInputConfigType.TEXT,
                        required=True,
                        placeholder="",
                        secret=False,
                    ),
                ],
            ),
        )
