from typing import Optional, cast

from posthog.schema import (
    DataWarehouseSourceCategory,
    ExternalDataSourceType as SchemaExternalDataSourceType,
    ReleaseStatus,
    SourceConfig,
    SourceFieldInputConfig,
    SourceFieldInputConfigType,
)

from products.warehouse_sources.backend.temporal.data_imports.sources.common.base import (
    FieldType,
    ResumableSource,
    VersionDeprecation,
)
from products.warehouse_sources.backend.temporal.data_imports.sources.common.canonical_descriptions import (
    CanonicalDescriptions,
)
from products.warehouse_sources.backend.temporal.data_imports.sources.common.registry import SourceRegistry
from products.warehouse_sources.backend.temporal.data_imports.sources.common.resumable import ResumableSourceManager
from products.warehouse_sources.backend.temporal.data_imports.sources.common.schema import (
    SourceSchema,
    build_endpoint_schemas,
)
from products.warehouse_sources.backend.temporal.data_imports.sources.common.typings import SourceInputs, SourceResponse
from products.warehouse_sources.backend.temporal.data_imports.sources.generated_configs.lightspeedretail import (
    LightspeedRetailSourceConfig,
)
from products.warehouse_sources.backend.temporal.data_imports.sources.lightspeed_retail.constants import (
    LIGHTSPEED_RETAIL_API_VERSION_2_0,
    LIGHTSPEED_RETAIL_API_VERSION_2026_01,
    LIGHTSPEED_RETAIL_API_VERSION_2026_07,
)
from products.warehouse_sources.backend.temporal.data_imports.sources.lightspeed_retail.lightspeed_retail import (
    LightspeedRetailResumeConfig,
    lightspeed_retail_source,
    validate_credentials as validate_lightspeed_credentials,
)
from products.warehouse_sources.backend.temporal.data_imports.sources.lightspeed_retail.settings import (
    ENDPOINTS,
    INCREMENTAL_FIELDS,
)
from products.warehouse_sources.backend.types import ExternalDataSourceType


@SourceRegistry.register
class LightspeedRetailSource(ResumableSource[LightspeedRetailSourceConfig, LightspeedRetailResumeConfig]):
    supported_versions = (
        LIGHTSPEED_RETAIL_API_VERSION_2_0,
        LIGHTSPEED_RETAIL_API_VERSION_2026_01,
        LIGHTSPEED_RETAIL_API_VERSION_2026_07,
    )
    default_version = LIGHTSPEED_RETAIL_API_VERSION_2026_07
    api_docs_url = "https://x-series-api.lightspeedhq.com/docs/introduction"
    # X-Series deprecated the legacy 2.0 version; no firm sunset date is published (deprecated
    # endpoints increasingly return 410 Gone before an eventual retirement).
    deprecated_versions = (VersionDeprecation(version=LIGHTSPEED_RETAIL_API_VERSION_2_0, sunset_at=None),)

    lists_tables_without_credentials = True  # static endpoint catalog — safe for public docs

    @property
    def source_type(self) -> ExternalDataSourceType:
        return ExternalDataSourceType.LIGHTSPEEDRETAIL

    @property
    def connection_host_fields(self) -> list[str]:
        # `domain_prefix` determines the host the stored personal token is sent
        # to; retargeting it must re-require the token.
        return ["domain_prefix"]

    def get_canonical_descriptions(self) -> CanonicalDescriptions:
        from products.warehouse_sources.backend.temporal.data_imports.sources.lightspeed_retail.canonical_descriptions import (
            CANONICAL_DESCRIPTIONS,
        )

        return CANONICAL_DESCRIPTIONS

    def get_non_retryable_errors(self) -> dict[str, str | None]:
        return {
            "401 Client Error: Unauthorized for url": "Lightspeed Retail authentication failed. Please check your personal token and store domain prefix.",
            "403 Client Error: Forbidden for url": "Lightspeed Retail denied access. Please check that your personal token has the required permissions.",
            # A retired API version answers 410 forever — retrying can't recover it.
            "410 Client Error: Gone for url": "Lightspeed Retail no longer serves this API version. Please update the source to a supported API version.",
        }

    @property
    def get_source_config(self) -> SourceConfig:
        return SourceConfig(
            name=SchemaExternalDataSourceType.LIGHTSPEED_RETAIL,
            category=DataWarehouseSourceCategory.E_COMMERCE,
            keywords=["lightspeed"],
            label="Lightspeed Retail",
            caption="""Enter your Lightspeed Retail (X-Series) credentials to pull your point-of-sale data into the PostHog Data warehouse.

Your domain prefix is the first part of your store URL — for `mystore.retail.lightspeed.app` enter `mystore`. An admin can create a personal token in Setup > Personal Tokens (available on the Plus plan and above).""",
            iconPath="/static/services/lightspeed_retail.png",
            docsUrl="https://posthog.com/docs/cdp/sources/lightspeed-retail",
            releaseStatus=ReleaseStatus.ALPHA,
            fields=cast(
                list[FieldType],
                [
                    SourceFieldInputConfig(
                        name="domain_prefix",
                        label="Domain prefix",
                        type=SourceFieldInputConfigType.TEXT,
                        required=True,
                        placeholder="mystore",
                        secret=False,
                    ),
                    SourceFieldInputConfig(
                        name="api_token",
                        label="Personal token",
                        type=SourceFieldInputConfigType.PASSWORD,
                        required=True,
                        placeholder="",
                        secret=True,
                    ),
                ],
            ),
        )

    def get_schemas(
        self,
        config: LightspeedRetailSourceConfig,
        team_id: int,
        with_counts: bool = False,
        names: list[str] | None = None,
        force_refresh: bool = False,
        api_version: str | None = None,
    ) -> list[SourceSchema]:
        # Static endpoint catalog — identical across supported versions, so no vendor call to pin.
        return build_endpoint_schemas(ENDPOINTS, INCREMENTAL_FIELDS, names)

    def validate_credentials(
        self,
        config: LightspeedRetailSourceConfig,
        team_id: int,
        schema_name: Optional[str] = None,
        api_version: str | None = None,
    ) -> tuple[bool, str | None]:
        # The probe URL carries the version path segment, so a pinned source must probe its own pin.
        if validate_lightspeed_credentials(
            config.domain_prefix, config.api_token, self.resolve_api_version(api_version)
        ):
            return True, None

        return False, "Invalid Lightspeed Retail credentials"

    def get_resumable_source_manager(
        self, inputs: SourceInputs
    ) -> ResumableSourceManager[LightspeedRetailResumeConfig]:
        return ResumableSourceManager[LightspeedRetailResumeConfig](inputs, LightspeedRetailResumeConfig)

    def source_for_pipeline(
        self,
        config: LightspeedRetailSourceConfig,
        resumable_source_manager: ResumableSourceManager[LightspeedRetailResumeConfig],
        inputs: SourceInputs,
    ) -> SourceResponse:
        return lightspeed_retail_source(
            domain_prefix=config.domain_prefix,
            api_token=config.api_token,
            endpoint=inputs.schema_name,
            team_id=inputs.team_id,
            job_id=inputs.job_id,
            resumable_source_manager=resumable_source_manager,
            api_version=self.resolve_api_version(inputs.api_version),
            should_use_incremental_field=inputs.should_use_incremental_field,
            db_incremental_field_last_value=inputs.db_incremental_field_last_value
            if inputs.should_use_incremental_field
            else None,
        )
