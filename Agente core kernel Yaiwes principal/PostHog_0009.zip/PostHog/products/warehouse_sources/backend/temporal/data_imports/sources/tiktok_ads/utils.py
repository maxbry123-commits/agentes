import copy
from collections.abc import Iterable
from datetime import UTC, date, datetime, timedelta
from typing import Any, Optional

from django.conf import settings

import structlog
from dateutil import parser
from requests import PreparedRequest, Request, Response
from requests.exceptions import HTTPError, RequestException, Timeout

from products.warehouse_sources.backend.temporal.data_imports.sources.common.http import make_tracked_session
from products.warehouse_sources.backend.temporal.data_imports.sources.common.rest_source.auth import AuthConfigBase
from products.warehouse_sources.backend.temporal.data_imports.sources.common.rest_source.paginators import BasePaginator
from products.warehouse_sources.backend.temporal.data_imports.sources.common.rest_source.typing import ResponseAction
from products.warehouse_sources.backend.temporal.data_imports.sources.tiktok_ads.settings import (
    BASE_URL,
    MAX_TIKTOK_DAYS_FOR_REPORT_ENDPOINTS,
    MAX_TIKTOK_DAYS_TO_QUERY,
    EndpointType,
)

logger = structlog.get_logger(__name__)

# TikTok replies HTTP 200 even for failures, signalling the outcome in the body `code` (0 = OK).
# These are the auth/permission codes that only re-authorizing can fix (invalid/revoked token,
# missing permission). Note 40100 is NOT one of them — it means "requests made too frequently".
TIKTOK_AUTH_ERROR_CODES = {40105, 40110}

# Code 40000 is TikTok's generic "params error" bucket and covers many unrelated messages, so it
# can't be treated as auth-only by code alone. This specific message means the access token was
# minted under a different TikTok app than the one currently configured — reconnecting to mint a
# fresh token under the current app is the only fix; retrying with the same token cannot succeed.
TIKTOK_APP_TOKEN_MISMATCH_MESSAGE = "app_id is inconsistent with the token's app information"

# Throttling (400xx) and TikTok-side outages (5xxxx/60001) also arrive as HTTP 200 + a body `code`,
# so no HTTP-level retry ever fires on them. Neither is our bug and neither is fixed by reconnecting:
# the caller just has to try again shortly.
TIKTOK_TRANSIENT_ERROR_CODES = {
    40016,  # Requests made too frequently
    40100,  # Requests made too frequently
    40101,  # Requests made too frequently
    40102,  # Requests made too frequently for a certain field value
    50000,  # System error
    51001,  # Internal service timeout
    60001,  # The system is in maintenance
}

TIKTOK_TRANSIENT_ERROR_MESSAGE = (
    "TikTok is rate-limiting this connection or is temporarily unavailable. Please try again in a few minutes."
)


def list_advertisers(access_token: str) -> list[dict]:
    """Every advertiser account the connected TikTok user authorized.

    `oauth2/advertiser/get` returns `advertiser_id` + `advertiser_name` only — richer fields would
    need `advertiser/info`, which our granted scope can't read.
    """
    # Mask the app secret (a query param) and the access token (a header) so neither lands in
    # request telemetry / captured samples. `timeout` guards the oauth_accounts web worker: TikTok
    # has no default timeout, so a hung connection would otherwise pin the worker indefinitely.
    session = make_tracked_session(
        headers={"Access-Token": access_token, "Content-Type": "application/json"},
        redact_values=(settings.TIKTOK_ADS_CLIENT_SECRET, access_token),
    )
    response = session.get(
        f"{BASE_URL}/oauth2/advertiser/get/",
        params={"app_id": settings.TIKTOK_ADS_CLIENT_ID, "secret": settings.TIKTOK_ADS_CLIENT_SECRET},
        timeout=10,
    )
    # A proxy/gateway failure answers with a non-2xx and an HTML body, which `.json()` can't parse.
    response.raise_for_status()
    try:
        body = response.json()
    except ValueError as e:
        raise TikTokAdsAPIError("TikTok advertiser/get returned a non-JSON body", response=response) from e

    # A malformed body leaves `code` as None, which is not in any of the code sets, so callers
    # branching on `api_code` correctly treat it as an unexpected failure rather than a known one.
    code = body.get("code") if isinstance(body, dict) else None
    if code != 0:
        message = body.get("message") if isinstance(body, dict) else None
        raise TikTokAdsAPIError(f"TikTok advertiser/get failed ({code}): {message}", api_code=code, response=response)
    return (body.get("data") or {}).get("list") or []


# https://business-api.tiktok.com/portal/docs?rid=xmtaqatxqj8&id=1737172488964097
TIKTOK_RETRYABLE_ERROR_CODES = [
    40016,  # Requests made too frequently
    40100,  # Requests made too frequently
    40101,  # Requests made too frequently
    40102,  # Requests made too frequently for a certain field value.
    40200,  # Task error
    40201,  # Task is not ready
    40202,  # Write or update entity conflict
    40700,  # Internal service validation error
    50000,  # System error
    50002,  # Error processing request on TikTok side. Please see error message for details.
    51001,  # Internal service timeout. Transient TikTok-side error; safe to retry.
    51002,  # Internal service error. Transient TikTok-side error; TikTok's own message asks to retry later.
    51039,  # Internal service timeout. Transient TikTok-side error; safe to retry.
    51305,  # Satellite service error
    60001,  # The system is in maintenance.
]

# TikTok answers HTTP 200 for these, so the rest client's own 429/5xx check never fires. Matching
# the body `code` inside the response hook reissues the request from within the client's retry loop;
# without it a rate limit hit mid-pagination escapes to the paginator, which cannot re-request, and
# fails the whole schema. The QPS ceiling is per app and shared across every concurrent sync, so
# hitting it is routine rather than exceptional.
TIKTOK_RETRY_RESPONSE_ACTIONS: list[ResponseAction] = [
    {
        "json_field": "code",
        "json_values": TIKTOK_RETRYABLE_ERROR_CODES,
        "action": "retry",
        "message": TIKTOK_TRANSIENT_ERROR_MESSAGE,
    }
]

# Prefix for the ValueError the paginator raises on client error codes outside the retryable set.
# 40001 is a generic bucket covering both a deleted advertiser and per-endpoint permission denials,
# so callers have to discriminate on wording rather than on the code. Retrying never succeeds, so
# `TikTokAdsSource.get_non_retryable_errors` matches this prefix to fail the job fast.
TIKTOK_NON_RETRYABLE_ERROR_PREFIX = "TikTok API client error (non-retryable):"

# Keep the denied path in each fragment: every endpoint here shares one paginator, so a denial on
# `/report/integrated/get/` carries the same "does not grant you" wording and would otherwise be
# answered with creative-library advice. TikTok templates the path into the message.
TIKTOK_CREATIVE_PERMISSION_DENIED_FRAGMENTS = (
    "does not grant you /file/video/ad/search/",
    "does not grant you /file/image/ad/search/",
)

# Reconnecting is the only fix, because our authorize URL sends no `scope`: the creative asset
# permission is granted per-advertiser on TikTok's side and we can't widen it after the fact.
TIKTOK_CREATIVE_PERMISSION_DENIED_MESSAGE = (
    "TikTok denied access to your creative library: the authorized advertiser account has not granted "
    "PostHog permission to read creative assets. This only affects the creative_videos and creative_images "
    "tables, which have been disabled. Your campaign, ad and report tables keep syncing. If your TikTok "
    "admin can grant creative asset access, reconnect the TikTok Ads integration and grant it when TikTok "
    "asks. Otherwise leave these two tables unselected."
)


class TikTokAdsAPIError(Exception):
    """A TikTok API failure, carrying the body `code` as `api_code` so callers can branch on it: the
    pipeline retries all of these, while the account-listing endpoint maps the auth and transient
    code sets above to actionable messages and lets the rest surface as bugs.

    Deliberately not named `status_code`: drf-exceptions-hog reads that attribute off any escaping
    exception and would render it as PostHog's HTTP response status.
    """

    def __init__(self, message: str, api_code: int | None = None, response: Optional[Response] = None):
        super().__init__(message)
        self.api_code = api_code
        self.response = response


class TikTokErrorHandler:
    """Centralized error handling for TikTok API."""

    @staticmethod
    def is_retryable(exception: Exception) -> bool:
        """
        Determine if a TikTok API exception should be retried.

        TikTok has specific rate limits and error codes that should trigger retries:
        - QPM limit: need to wait 5 minutes before making API requests again
        - QPD limit: need to wait until the next day (UTC+0 time) to make API requests again
        - Note that the QPD limit resets at 00:00:00 UTC+0 time every day

        https://business-api.tiktok.com/portal/docs?id=1740029171730433
        """
        if isinstance(exception, TikTokAdsAPIError):
            return True

        if isinstance(exception, HTTPError) and hasattr(exception, "response") and exception.response is not None:
            status_code = exception.response.status_code
            return status_code in [429, 500, 502, 503, 504]

        if isinstance(exception, Timeout | RequestException):
            return True

        return False


class TikTokDateRangeManager:
    """Handles date range calculations and chunking for TikTok API requests."""

    @staticmethod
    def get_incremental_range(
        should_use_incremental_field: bool, db_incremental_field_last_value: Optional[Any] = None
    ) -> tuple[str, str]:
        """Calculate date range for incremental sync based on last synced value."""
        ends_at = datetime.now().strftime("%Y-%m-%d")

        if should_use_incremental_field and db_incremental_field_last_value:
            try:
                if isinstance(db_incremental_field_last_value, datetime):
                    last_datetime = db_incremental_field_last_value
                elif isinstance(db_incremental_field_last_value, date):
                    last_datetime = datetime.combine(db_incremental_field_last_value, datetime.min.time())
                elif isinstance(db_incremental_field_last_value, str):
                    last_datetime = parser.parse(db_incremental_field_last_value)
                else:
                    last_datetime = datetime.fromisoformat(str(db_incremental_field_last_value))

                starts_at = last_datetime.strftime("%Y-%m-%d")

            except Exception:
                starts_at = (datetime.now() - timedelta(days=MAX_TIKTOK_DAYS_FOR_REPORT_ENDPOINTS)).strftime("%Y-%m-%d")
        else:
            starts_at = (datetime.now() - timedelta(days=MAX_TIKTOK_DAYS_FOR_REPORT_ENDPOINTS)).strftime("%Y-%m-%d")

        return starts_at, ends_at

    @staticmethod
    def generate_chunks(
        start_date: str, end_date: str, chunk_days: int = MAX_TIKTOK_DAYS_TO_QUERY
    ) -> list[tuple[str, str]]:
        """
        Generate date chunks that respect TikTok's 29-day limit.
        Returns list of (start_date, end_date) tuples for sequential API calls.
        """
        start_dt = datetime.strptime(start_date, "%Y-%m-%d")
        end_dt = datetime.strptime(end_date, "%Y-%m-%d")

        chunks = []
        current_start = start_dt

        while current_start <= end_dt:
            chunk_end = current_start + timedelta(days=chunk_days - 1)

            if chunk_end > end_dt:
                chunk_end = end_dt

            chunks.append((current_start.strftime("%Y-%m-%d"), chunk_end.strftime("%Y-%m-%d")))

            current_start = chunk_end + timedelta(days=1)

        return chunks


class TikTokReportResource:
    """Handles report-specific operations like flattening and date chunking."""

    @staticmethod
    def _normalize_secondary_goal_fields(report: dict[str, Any]) -> None:
        """Convert TikTok's '-' placeholder values to None for secondary goal metrics."""
        secondary_goal_fields = [
            "secondary_goal_result",
            "cost_per_secondary_goal_result",
            "secondary_goal_result_rate",
        ]

        for field in secondary_goal_fields:
            if field in report and report[field] == "-":
                report[field] = None

    @staticmethod
    def transform_analytics_reports(reports: list[dict[str, Any]]) -> list[dict[str, Any]]:
        """
        Standardize analytics reports for consistent data structure.

        Applies analytics-specific transformations:
        - Merges metrics and dimensions into flat structure
        - Normalizes placeholder values for secondary goal metrics
        - Handles both structured reports (with dimensions/metrics) and flat reports
        """
        processed_reports = []
        for report in reports:
            if "metrics" in report and "dimensions" in report:
                merged_report = {**report["metrics"], **report["dimensions"]}
                TikTokReportResource._normalize_secondary_goal_fields(merged_report)
                processed_reports.append(merged_report)
            else:
                processed_reports.append(report)

        return processed_reports

    @staticmethod
    def _normalize_entity_status(report: dict[str, Any]) -> None:
        """Set default status for entities that don't have explicit status differentiation."""
        if "current_status" not in report:
            report["current_status"] = "ACTIVE"

    @staticmethod
    def _normalize_timestamps(report: dict[str, Any]) -> None:
        """Ensure modify_time exists by using create_time as fallback."""
        if "modify_time" not in report and "create_time" in report:
            report["modify_time"] = report["create_time"]

    @staticmethod
    def _convert_comment_settings(report: dict[str, Any]) -> None:
        """Convert comment disable flag from integer to boolean representation."""
        if "is_comment_disable" in report:
            report["is_comment_disable"] = report["is_comment_disable"] == 0

    @staticmethod
    def transform_entity_reports(reports: list[dict[str, Any]]) -> list[dict[str, Any]]:
        """
        Standardize entity reports (campaigns, ad groups, ads) for consistent data structure.

        Applies common transformations:
        - Sets default entity status
        - Normalizes timestamp fields
        - Converts boolean flags
        """
        processed_reports = []
        for report in reports:
            normalized_report = report.copy()

            TikTokReportResource._normalize_entity_status(normalized_report)
            TikTokReportResource._normalize_timestamps(normalized_report)
            TikTokReportResource._convert_comment_settings(normalized_report)

            processed_reports.append(normalized_report)

        return processed_reports

    @staticmethod
    def _convert_timestamp_to_datetime(report: dict[str, Any]) -> None:
        """Convert Unix timestamp to timezone-aware datetime object."""
        if "create_time" in report and isinstance(report["create_time"], int | float):
            report["create_time"] = datetime.fromtimestamp(report["create_time"], tz=UTC)

    @staticmethod
    def transform_account_reports(reports: list[dict[str, Any]]) -> list[dict[str, Any]]:
        """
        Standardize advertiser account reports for consistent data structure.

        Applies account-specific transformations:
        - Converts Unix timestamps to datetime objects
        """
        processed_reports = []
        for report in reports:
            normalized_report = report.copy()

            TikTokReportResource._convert_timestamp_to_datetime(normalized_report)

            processed_reports.append(normalized_report)

        return processed_reports

    @classmethod
    def apply_stream_transformations(cls, endpoint_type: EndpointType, reports: Iterable[Any]) -> list[dict[str, Any]]:
        """
        Apply appropriate transformations based on the endpoint type.

        Routes reports to the correct transformation method based on endpoint category.
        """
        reports_list = list(reports)

        match endpoint_type:
            case EndpointType.REPORT:
                return cls.transform_analytics_reports(reports_list)
            case EndpointType.ENTITY:
                return cls.transform_entity_reports(reports_list)
            case EndpointType.ACCOUNT:
                return cls.transform_account_reports(reports_list)
            case EndpointType.ASSET:
                # Creative library rows already arrive flat and need no defaulting.
                return reports_list
            case _:
                raise ValueError(f"Endpoint type: {endpoint_type} is not implemented")

    @classmethod
    def create_chunked_resources(
        cls,
        base_resource_config: dict,
        start_date: str,
        end_date: str,
        advertiser_id: str,
        chunk_days: int = MAX_TIKTOK_DAYS_TO_QUERY,
    ) -> list[dict]:
        """
        Create multiple resources for date chunking with rest_api_resources.
        Each chunk becomes a separate resource.
        """
        date_chunks = TikTokDateRangeManager.generate_chunks(start_date, end_date, chunk_days)
        resources = []

        for i, (chunk_start, chunk_end) in enumerate(date_chunks):
            resource_config = copy.deepcopy(base_resource_config)

            resource_name = f"{base_resource_config['name']}_chunk_{i}"
            resource_config["name"] = resource_name
            resource_config["table_name"] = base_resource_config.get("table_name", base_resource_config["name"])

            endpoint = resource_config["endpoint"]
            params = endpoint.get("params", {})

            params = {
                key: value.format(advertiser_id=advertiser_id, start_date=chunk_start, end_date=chunk_end)
                if isinstance(value, str)
                else value
                for key, value in params.items()
            }

            endpoint["params"] = params

            if "incremental" in endpoint:
                del endpoint["incremental"]

            resource_config["endpoint"] = endpoint
            resources.append(resource_config)

        return resources

    @classmethod
    def process_resources(cls, dlt_resources: list) -> Iterable[Any]:
        """
        Process and flatten DLT resources from report endpoints.
        Handles both single and multiple chunked resources.
        """
        result = []

        for _i, resource in enumerate(dlt_resources):
            result.extend(cls._flatten_single_resource(resource))

        return result

    @classmethod
    def _flatten_single_resource(cls, resource: Any) -> list[dict[str, Any]]:
        result = []
        for item in resource:
            if isinstance(item, list):
                result.extend(item)
            elif isinstance(item, dict):
                result.append(item)
            else:
                result.append(item)
        return result

    @classmethod
    def setup_report_resources(
        cls,
        base_resource_config: dict,
        advertiser_id: str,
        should_use_incremental_field: bool,
        db_incremental_field_last_value: Optional[Any],
    ) -> list[dict]:
        """
        Setup report resources with proper date chunking.
        Calculates date ranges and creates chunked resources.
        """
        starts_at, ends_at = TikTokDateRangeManager.get_incremental_range(
            should_use_incremental_field, db_incremental_field_last_value
        )

        if not should_use_incremental_field:
            ends_at = datetime.now().strftime("%Y-%m-%d")
            starts_at = (datetime.now() - timedelta(days=MAX_TIKTOK_DAYS_FOR_REPORT_ENDPOINTS)).strftime("%Y-%m-%d")

        return cls.create_chunked_resources(base_resource_config, starts_at, ends_at, advertiser_id)


class TikTokAdsPaginator(BasePaginator):
    """TikTok Ads API paginator that extends dlt's BasePaginator"""

    def __init__(self) -> None:
        super().__init__()
        self.current_page = 1
        self._has_next_page = False
        self.total_pages = 0
        self.total_number = 0
        self.page_size = 0

    def init_request(self, request: Request) -> None:
        # Honour a seeded ``current_page`` on the first request so a resumed
        # run targets the saved page instead of page 1.
        if request.params is None:
            request.params = {}
        request.params["page"] = self.current_page

    def get_resume_state(self) -> Optional[dict[str, Any]]:
        # rest_client only calls this when ``has_next_page`` is True, so
        # ``current_page`` already points at the page still to fetch.
        if self._has_next_page:
            return {"page": self.current_page}
        return None

    def set_resume_state(self, state: dict[str, Any]) -> None:
        page = state.get("page")
        if page is not None:
            self.current_page = int(page)
            self._has_next_page = True

    def update_state(self, response: Response, data: Optional[Any] = None) -> None:
        """Update pagination state from TikTok API response."""
        try:
            json_data = response.json()
            api_code = json_data.get("code", -1)

            if api_code == 0:
                page_info = json_data.get("data", {}).get("page_info", {})

                self.total_pages = page_info.get("total_page", 0)
                self.total_number = page_info.get("total_number", 0)
                self.page_size = page_info.get("page_size", 0)
                current_page = page_info.get("page", 1)

                self._has_next_page = current_page < self.total_pages

                if self._has_next_page:
                    self.current_page = current_page + 1
            else:
                self._has_next_page = False
                error_message = json_data.get("message", "Unknown API error")
                logger.error(
                    "tiktok_ads_api_error",
                    api_code=api_code,
                    message=error_message,
                    response_status=response.status_code,
                )

                # Endpoints carrying TIKTOK_RETRY_RESPONSE_ACTIONS never reach this branch with a
                # retryable code: the response hook reissues the request, and raises its own error
                # once the retry budget is spent. This stays as the fallback for endpoints that
                # don't declare the actions.
                if api_code in TIKTOK_RETRYABLE_ERROR_CODES:
                    raise TikTokAdsAPIError(
                        f"TikTok API error: {error_message} (code: {api_code})", api_code=api_code, response=response
                    )
                else:
                    raise ValueError(f"{TIKTOK_NON_RETRYABLE_ERROR_PREFIX} {error_message} (code: {api_code})")
        except TikTokAdsAPIError:
            raise
        except ValueError:
            raise
        except Exception as e:
            self._has_next_page = False
            logger.exception("tiktok_ads_paginator_error", error=str(e))
            raise TikTokAdsAPIError(f"Failed to parse TikTok API response: {str(e)}", response=response)

    def update_request(self, request: Request) -> None:
        """Update the request with pagination parameters."""
        if request.params is None:
            request.params = {}
        request.params["page"] = self.current_page


class TikTokAdsAuth(AuthConfigBase):
    """TikTok Ads API authentication handler.

    TikTok requires a custom 'Access-Token' header instead of the standard
    'Authorization: Bearer' pattern.
    """

    def __init__(self, access_token: Optional[str] = None) -> None:
        self.access_token = access_token

    def __call__(self, request: PreparedRequest) -> PreparedRequest:
        if self.access_token is None:
            raise ValueError("TikTok Ads access token is not configured")
        request.headers["Access-Token"] = self.access_token
        request.headers["Content-Type"] = "application/json"
        return request
