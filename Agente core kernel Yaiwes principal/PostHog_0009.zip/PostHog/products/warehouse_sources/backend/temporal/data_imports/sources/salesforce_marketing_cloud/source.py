from typing import cast

from posthog.schema import (
    DataWarehouseSourceCategory,
    ExternalDataSourceType as SchemaExternalDataSourceType,
    SourceConfig,
)

from products.warehouse_sources.backend.temporal.data_imports.sources.common.base import FieldType, SimpleSource
from products.warehouse_sources.backend.temporal.data_imports.sources.common.registry import SourceRegistry
from products.warehouse_sources.backend.temporal.data_imports.sources.generated_configs.salesforcemarketingcloud import (
    SalesforceMarketingCloudSourceConfig,
)
from products.warehouse_sources.backend.types import ExternalDataSourceType


@SourceRegistry.register
class SalesforceMarketingCloudSource(SimpleSource[SalesforceMarketingCloudSourceConfig]):
    @property
    def source_type(self) -> ExternalDataSourceType:
        return ExternalDataSourceType.SALESFORCEMARKETINGCLOUD

    @property
    def get_source_config(self) -> SourceConfig:
        return SourceConfig(
            name=SchemaExternalDataSourceType.SALESFORCE_MARKETING_CLOUD,
            category=DataWarehouseSourceCategory.MARKETING___EMAIL,
            keywords=["sfmc"],
            label="Salesforce Marketing Cloud",
            iconPath="/static/services/salesforce_marketing_cloud.png",
            fields=cast(list[FieldType], []),
            unreleasedSource=True,
        )
