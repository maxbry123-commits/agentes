#pragma once

#include <string>
#include <vector>

#include "envoy/common/optref.h"
#include "envoy/config/cluster/v3/cluster.pb.h"
#include "envoy/config/core/v3/base.pb.h"
#include "envoy/config/typed_metadata.h"
#include "envoy/extensions/matching/common_inputs/transport_socket/v3/transport_socket_inputs.pb.h"
#include "envoy/matcher/matcher.h"
#include "envoy/network/address.h"
#include "envoy/network/connection.h"
#include "envoy/server/factory_context.h"
#include "envoy/server/transport_socket_config.h"
#include "envoy/stats/scope.h"
#include "envoy/stream_info/filter_state.h"
#include "envoy/upstream/host_description.h"
#include "envoy/upstream/transport_socket_matching_data.h"
#include "envoy/upstream/upstream.h"

#include "source/common/common/logger.h"
#include "source/common/config/metadata.h"
#include "source/common/config/well_known_names.h"
#include "source/common/protobuf/protobuf.h"
#include "source/extensions/matching/common_inputs/transport_socket/config.h"

#include "absl/container/flat_hash_map.h"
#include "xds/type/matcher/v3/matcher.pb.h"

namespace Envoy {
namespace Upstream {

// Action factory context for transport socket name actions - using the server factory context.
using TransportSocketActionFactoryContext = Server::Configuration::ServerFactoryContext;

class TransportSocketMatcherImpl : public Logger::Loggable<Logger::Id::upstream>,
                                   public TransportSocketMatcher {
public:
  static absl::StatusOr<std::unique_ptr<TransportSocketMatcherImpl>> create(
      const Protobuf::RepeatedPtrField<envoy::config::cluster::v3::Cluster::TransportSocketMatch>&
          socket_matches,
      Server::Configuration::TransportSocketFactoryContext& factory_context,
      Network::UpstreamTransportSocketFactoryPtr& default_factory, Stats::Scope& stats_scope);

  static absl::StatusOr<std::unique_ptr<TransportSocketMatcherImpl>> create(
      const Protobuf::RepeatedPtrField<envoy::config::cluster::v3::Cluster::TransportSocketMatch>&
          socket_matches,
      OptRef<const xds::type::matcher::v3::Matcher> transport_socket_matcher,
      Server::Configuration::TransportSocketFactoryContext& factory_context,
      Network::UpstreamTransportSocketFactoryPtr& default_factory, Stats::Scope& stats_scope);

  struct FactoryMatch {
    FactoryMatch(std::string match_name, Network::UpstreamTransportSocketFactoryPtr socket_factory,
                 TransportSocketMatchStats match_stats)
        : name(std::move(match_name)), factory(std::move(socket_factory)), stats(match_stats) {}
    const std::string name;
    Network::UpstreamTransportSocketFactoryPtr factory;
    Config::Metadata::LabelSet label_set;
    mutable TransportSocketMatchStats stats;
  };

  MatchData resolve(const envoy::config::core::v3::Metadata* endpoint_metadata,
                    const envoy::config::core::v3::Metadata* locality_metadata,
                    Network::TransportSocketOptionsConstSharedPtr transport_socket_options =
                        nullptr) const override;

  bool allMatchesSupportAlpn() const override {
    if (!default_match_.factory->supportsAlpn()) {
      return false;
    }
    for (const auto& match : matches_) {
      if (!match.factory->supportsAlpn()) {
        return false;
      }
    }
    // Also check transport sockets in the matcher-based map.
    for (const auto& [name, factory] : transport_sockets_by_name_) {
      if (!factory->supportsAlpn()) {
        return false;
      }
    }
    return true;
  }

  bool usesFilterState() const override { return uses_filter_state_; }

protected:
  TransportSocketMatcherImpl(
      const Protobuf::RepeatedPtrField<envoy::config::cluster::v3::Cluster::TransportSocketMatch>&
          socket_matches,
      Server::Configuration::TransportSocketFactoryContext& factory_context,
      Network::UpstreamTransportSocketFactoryPtr& default_factory, Stats::Scope& stats_scope,
      absl::Status& creation_status);

  TransportSocketMatcherImpl(
      const Protobuf::RepeatedPtrField<envoy::config::cluster::v3::Cluster::TransportSocketMatch>&
          socket_matches,
      OptRef<const xds::type::matcher::v3::Matcher> transport_socket_matcher,
      Server::Configuration::TransportSocketFactoryContext& factory_context,
      Network::UpstreamTransportSocketFactoryPtr& default_factory, Stats::Scope& stats_scope,
      absl::Status& creation_status);

  TransportSocketMatchStats generateStats(const std::string& prefix) const;

private:
  /**
   * Resolve the transport socket configuration using the matcher if available.
   * @param endpoint_metadata the metadata of the given host.
   * @param locality_metadata the metadata of the host's locality.
   * @param transport_socket_options optional transport socket options from downstream connection.
   * @return the match information of the transport socket selected.
   */
  MatchData
  resolveUsingMatcher(const envoy::config::core::v3::Metadata* endpoint_metadata,
                      const envoy::config::core::v3::Metadata* locality_metadata,
                      Network::TransportSocketOptionsConstSharedPtr transport_socket_options) const;

  /**
   * Setup legacy metadata-based socket matches.
   * @param socket_matches the socket matches configuration.
   * @param factory_context the factory context.
   * @param creation_status reference to store creation status.
   */
  void setupLegacySocketMatches(
      const Protobuf::RepeatedPtrField<envoy::config::cluster::v3::Cluster::TransportSocketMatch>&
          socket_matches,
      Server::Configuration::TransportSocketFactoryContext& factory_context,
      absl::Status& creation_status);

  /**
   * Setup transport socket matcher based on the provided configuration.
   * @param transport_socket_matcher the matcher configuration.
   * @param socket_matches the socket matches configuration.
   * @param factory_context the factory context.
   * @param creation_status reference to store creation status.
   */
  void setupTransportSocketMatcher(
      const xds::type::matcher::v3::Matcher& transport_socket_matcher,
      const Protobuf::RepeatedPtrField<envoy::config::cluster::v3::Cluster::TransportSocketMatch>&
          socket_matches,
      Server::Configuration::TransportSocketFactoryContext& factory_context,
      absl::Status& creation_status);

  Stats::Scope& stats_scope_;
  FactoryMatch default_match_;
  std::vector<FactoryMatch> matches_;

  // Matcher-based transport socket selection.
  using TransportSocketsByName =
      absl::flat_hash_map<std::string, Network::UpstreamTransportSocketFactoryPtr>;
  TransportSocketsByName transport_sockets_by_name_;
  // Pre-generated stats for matcher-selected transport sockets keyed by name.
  // Stats are created at config time to avoid calling generateStats() in the hot path.
  // Mutable because stats counters need to be incremented in the const resolve() method.
  mutable absl::flat_hash_map<std::string, TransportSocketMatchStats> matcher_stats_by_name_;
  std::unique_ptr<Matcher::MatchTree<Upstream::TransportSocketMatchingData>> matcher_;
  bool uses_filter_state_{false};
};

// Import action classes from the extension.
using TransportSocketNameAction =
    Extensions::Matching::CommonInputs::TransportSocket::TransportSocketNameAction;

} // namespace Upstream
} // namespace Envoy
