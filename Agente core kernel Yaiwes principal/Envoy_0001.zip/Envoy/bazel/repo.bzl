# `@envoy_repo` repository rule for managing the repo and querying its metadata.

CONTAINERS = """

REPO = "{repo}"
REPO_GCR = "{repo_gcr}"
SHA = "{sha}"
SHA_GCC = "{sha_gcc}"
SHA_MOBILE = "{sha_mobile}"
SHA_WORKER = "{sha_worker}"
TAG = "{tag}"

def image_gcc():
    return "%s@sha256:%s" % (
        REPO_GCR, SHA_GCC)

def image_mobile():
    return "%s@sha256:%s" % (
        REPO, SHA_MOBILE)

def image_worker():
    return "%s@sha256:%s" % (
        REPO_GCR, SHA_WORKER)

"""

def _envoy_repo_impl(repository_ctx):
    """This provides information about the Envoy repository

    You can access the current project and api versions and the path to the repository in
    .bzl/BUILD files as follows:

    ```starlark
    load("@envoy_repo//:version.bzl", "VERSION", "API_VERSION")
    ```

    `*VERSION` can be used to derive version-specific rules and can be passed
    to the rules.

    The `VERSION`s and also the local `PATH` to the repo can be accessed in
    python libraries/binaries. By adding `@envoy_repo` to `deps` they become
    importable through the `envoy_repo` namespace.

    As the `PATH` is local to the machine, it is generally only useful for
    jobs that will run locally.

    This can be useful, for example, for bazel run jobs to run bazel queries that cannot be run
    within the constraints of a `genquery`, or that otherwise need access to the repository
    files.

    Project and repo data can be accessed in JSON format using `@envoy_repo//:project`, eg:

    ```starlark
    load("@aspect_bazel_lib//lib:jq.bzl", "jq")

    jq(
        name = "project_version",
        srcs = ["@envoy_repo//:data"],
        out = "version.txt",
        args = ["-r"],
        filter = ".version",
    )

    ```

    """

    # parse container information for use in RBE
    ci_config = repository_ctx.read(repository_ctx.path(repository_ctx.attr.envoy_ci_config))
    build_image = {}
    in_build_image = False
    for line in ci_config.split("\n"):
        if line.strip() == "build-image:":
            in_build_image = True
            continue
        if in_build_image:
            if not line.strip() or line.startswith("  #"):
                continue
            if not line.startswith("  "):
                break
            parts = line.strip().split(": ", 1)
            if len(parts) == 2:
                build_image[parts[0]] = parts[1]
    repository_ctx.file("containers.bzl", CONTAINERS.format(
        repo = build_image["repo"],
        repo_gcr = build_image["repo-gcr"],
        sha = build_image["sha"],
        sha_gcc = build_image["sha-gcc"],
        sha_mobile = build_image["sha-mobile"],
        sha_worker = build_image["sha-worker"],
        tag = build_image["tag"],
    ))
    repo_version_path = repository_ctx.path(repository_ctx.attr.envoy_version)
    api_version_path = repository_ctx.path(repository_ctx.attr.envoy_api_version)
    version = repository_ctx.read(repo_version_path).strip()
    api_version = repository_ctx.read(api_version_path).strip()

    # Read BAZEL_LLVM_PATH environment variable for local LLVM installations
    llvm_path = repository_ctx.os.environ.get("BAZEL_LLVM_PATH", "")
    local_llvm = "True" if llvm_path else "False"

    # When using a local LLVM, detect its version and library directory so that
    # downstream BUILD files can reference the correct libclang-cpp.so and
    # clang resource-dir paths without hardcoding a version.
    llvm_version_local = ""
    llvm_lib_dir = "lib"
    if llvm_path:
        result = repository_ctx.execute([llvm_path + "/bin/clang", "--version"])
        if result.return_code == 0:
            for line in result.stdout.split("\n"):
                if "clang version" in line:
                    llvm_version_local = line.split("clang version ")[1].split(" ")[0].strip()
                    break
        for directory in ["lib64", "lib"]:
            if repository_ctx.path(llvm_path + "/" + directory + "/libclang-cpp.so").exists:
                llvm_lib_dir = directory
                break
            entries = repository_ctx.execute(["ls", llvm_path + "/" + directory + "/"])
            if entries.return_code == 0 and "libclang-cpp.so" in entries.stdout:
                llvm_lib_dir = directory
                break

    # By default, even when local toolchain is used, we still use the hermetic
    # sysroot, when it's undesirable, you can set this environment variable to True
    # to fallback to the host libc.
    #
    # NOTE: The cleanest way to provide this environment variable would be via Bazel's
    # repo_env flag. It's particularly important when using remote build execution (aka
    # RBE), as host environment variables are not directly passed to remote workers.
    local_sysroot = repository_ctx.os.environ.get("BAZEL_USE_HOST_SYSROOT", "False")

    # Make sure to not pass the content of environment variable directly to the Bazel
    # Starlark file - we should only accept a proper boolean value and nothing else.
    local_sysroot = {"True": True, "False": False}.get(local_sysroot, False)

    # When set to True, the toolchain uses libstdc++ instead of the default
    # builtin libc++. This is useful on systems where libc++ is not available
    # (e.g. RHEL/UBI).
    use_libstdcpp = repository_ctx.os.environ.get("BAZEL_USE_LIBSTDCPP", "False")
    use_libstdcpp = {"True": True, "False": False}.get(use_libstdcpp, False)

    repository_ctx.file("compiler.bzl", """
LLVM_PATH = '%s'
LLVM_VERSION_LOCAL = '%s'
LLVM_LIB_DIR = '%s'
USE_LOCAL_SYSROOT = %s
USE_LIBSTDCPP = %s
""" % (llvm_path, llvm_version_local, llvm_lib_dir, local_sysroot, use_libstdcpp))
    repository_ctx.file("version.bzl", "VERSION = '%s'\nAPI_VERSION = '%s'" % (version, api_version))
    repository_ctx.file("path.bzl", "PATH = '%s'" % repo_version_path.dirname)
    repository_ctx.file("envoy_repo.py", "PATH = '%s'\nVERSION = '%s'\nAPI_VERSION = '%s'" % (repo_version_path.dirname, version, api_version))
    repository_ctx.file("WORKSPACE", "")
    repository_ctx.file("BUILD", '''
load("@bazel_skylib//rules:common_settings.bzl", "bool_flag")
load("@rules_python//python:defs.bzl", "py_library")
load("@rules_python//python/entry_points:py_console_script_binary.bzl", "py_console_script_binary")
load("//:path.bzl", "PATH")

bool_flag(
    name = "use_local_llvm_flag",
    build_setting_default = %s,
    visibility = ["//visibility:public"],
)

config_setting(
    name = "use_local_llvm",
    flag_values = {
        ":use_local_llvm_flag": "True",
    },
    constraint_values = [
        "@platforms//os:linux",
    ],
    visibility = ["//visibility:public"],
)

bool_flag(
    name = "use_local_sysroot_flag",
    build_setting_default = %s,
    visibility = ["//visibility:public"],
)

config_setting(
    name = "use_local_sysroot",
    flag_values = {
        ":use_local_sysroot_flag": "True",
    },
    constraint_values = [
        "@platforms//os:linux",
    ],
    visibility = ["//visibility:public"],
)

config_setting(
    name = "use_hermetic_sysroot",
    flag_values = {
        ":use_local_sysroot_flag": "False",
    },
    constraint_values = [
        "@platforms//os:linux",
    ],
    visibility = ["//visibility:public"],
)

py_library(
    name = "envoy_repo",
    srcs = ["envoy_repo.py"],
    visibility = ["//visibility:public"],
)

py_console_script_binary(
    name = "get_project_json",
    pkg = "@base_pip3//envoy_base_utils",
    script = "envoy.project_data",
    data = [":envoy_repo.py"],
)

genrule(
    name = "generate_release_hash_bin",
    outs = ["generate_release_hash.sh"],
    cmd = """
    echo "
#!/usr/bin/env bash

set -e -o pipefail

git ls-remote --tags https://github.com/envoyproxy/envoy \\\\
    | grep -E 'refs/tags/v[0-9]+\\\\.[0-9]+\\\\.[0-9]+$$' \\\\
    | sort -u \\\\
    | sha256sum \\\\
    | cut -d ' ' -f 1" > $@
    chmod +x $@
    """
)

sh_binary(
    name = "generate_release_hash",
    srcs = [":generate_release_hash_bin"],
    visibility = ["//visibility:public"],
)

# This sets a default hash based on currently visible tagged versions.
# Its very questionably hermetic, making assumptions about git, the repo remotes and so on.
# The general idea here is to make this cache blow any time there are release changes.
# You can use the above sh_binary to generate a custom/correct hash to override below.
genrule(
    name = "default_release_hash",
    outs = ["default_release_hash.txt"],
    cmd = """
    $(location :generate_release_hash) > $@
    """,
    stamp = True,
    tags = ["no-remote-exec"],
    tools = [":generate_release_hash"],
)

label_flag(
    name = "release-hash",
    build_setting_default = ":default_release_hash",
    visibility = ["//visibility:public"],
)

genrule(
    name = "project",
    outs = ["project.json"],
    cmd = """
    $(location :get_project_json) $$(dirname $(location @envoy//:VERSION.txt)) > $@
    """,
    tools = [
        ":get_project_json",
        ":release-hash",
        "@envoy//:VERSION.txt",
        "@envoy//changelogs",
    ],
    visibility = ["//visibility:public"],
)

py_console_script_binary(
    name = "release",
    args = [
        "release",
        PATH,
        "--release-message-path=$(location @envoy//changelogs:summary)",
    ],
    data = [
        ":envoy_repo.py",
        "@envoy//changelogs:summary",
    ],
    pkg = "@base_pip3//envoy_base_utils",
    script = "envoy.project",
)

py_console_script_binary(
    name = "dev",
    args = [
        "dev",
        PATH,
    ],
    pkg = "@base_pip3//envoy_base_utils",
    script = "envoy.project",
    data = [":envoy_repo.py"],
)

py_console_script_binary(
    name = "sync",
    args = [
        "sync",
        PATH,
    ],
    pkg = "@base_pip3//envoy_base_utils",
    script = "envoy.project",
    data = [":envoy_repo.py"],
)

py_console_script_binary(
    name = "publish",
    args = [
        "publish",
        PATH,
    ],
    pkg = "@base_pip3//envoy_base_utils",
    script = "envoy.project",
    data = [":envoy_repo.py"],
)

py_console_script_binary(
    name = "trigger",
    args = [
        "trigger",
        PATH,
    ],
    pkg = "@base_pip3//envoy_base_utils",
    script = "envoy.project",
    data = [":envoy_repo.py"],
)

''' % (local_llvm, local_sysroot))

_envoy_repo = repository_rule(
    implementation = _envoy_repo_impl,
    attrs = {
        "envoy_version": attr.label(default = "@envoy//:VERSION.txt"),
        "envoy_api_version": attr.label(default = "@envoy//:API_VERSION.txt"),
        "envoy_ci_config": attr.label(default = "@envoy//:.github/config.yml"),
    },
    environ = ["BAZEL_LLVM_PATH", "BAZEL_USE_HOST_SYSROOT", "BAZEL_USE_LIBSTDCPP"],
)

def envoy_repo():
    if "envoy_repo" not in native.existing_rules().keys():
        _envoy_repo(name = "envoy_repo")
