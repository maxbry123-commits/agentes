import contextlib
import hashlib
import logging
import os
import threading
from collections.abc import Callable, Iterator
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Literal, NamedTuple, Set, TypeVar, cast

import rich
from pydantic import BaseModel
from rich.status import Status
from shortuuid import uuid
from tenacity import (
    RetryCallState,
    Retrying,
    retry_if_not_result,
    stop_after_attempt,
    wait_exponential,
)
from typing_extensions import Unpack

from inspect_ai._control.eval_state import (
    DeferredSampleStats,
    invalidate_log_sample_summaries,
    register_completed_eval,
    reset_run_registries,
)
from inspect_ai._control.server import (
    control_server,
    keep_alive_intent,
    request_keep_alive,
    reset_keep_alive,
    resolve_ctl_server,
    wait_for_shutdown_async,
)
from inspect_ai._display import display as display_manager
from inspect_ai._display.core.panel import set_eval_set_id_display
from inspect_ai._eval.handoff import (
    LaunchHandoff,
    emit_launch_handoff,
    launch_handoff_emitted,
    print_ctl_pointer,
    reset_launch_handoff_emitted,
)
from inspect_ai._eval.task.log import plan_to_eval_plan
from inspect_ai._eval.task.run import eval_plan_agent_name, resolve_plan
from inspect_ai._eval.task.scan import (
    Scanners,
    merged_selection_scanner,
    scan_already_clean,
    serialized_scan,
    verify_selection_scan_dir,
)
from inspect_ai._util._async import run_coroutine
from inspect_ai._util.azure import call_with_azure_auth_fallback
from inspect_ai._util.error import PrerequisiteError
from inspect_ai._util.file import (
    FileSystem,
    basename,
    file,
    filesystem,
)
from inspect_ai._util.json import to_json_safe
from inspect_ai._util.notgiven import NOT_GIVEN, NotGiven
from inspect_ai.agent._agent import Agent, is_agent
from inspect_ai.agent._as_solver import as_solver
from inspect_ai.approval._policy import ApprovalPolicy, ApprovalPolicyConfig
from inspect_ai.log import EvalLog
from inspect_ai.log._bundle import bundle_log_dir, embed_log_dir
from inspect_ai.log._file import (
    EvalLogInfo,
    ReadEvalLogsProgress,
    list_eval_logs,
    read_eval_log_headers,
    write_log_dir_manifest,
    write_log_listing,
)
from inspect_ai.log._log import EvalConfig
from inspect_ai.model import (
    GenerateConfigArgs,
    Model,
    ModelRoles,
)
from inspect_ai.model._generate_config import GenerateConfig
from inspect_ai.model._model import ModelName
from inspect_ai.model._model_config import (
    model_args_for_log,
    model_roles_to_model_roles_config,
)
from inspect_ai.model._model_data.model_data import ModelCost
from inspect_ai.scorer._reducer import reducer_log_name
from inspect_ai.solver._chain import chain
from inspect_ai.solver._solver import Solver, SolverSpec
from inspect_ai.util import DisplayType, SandboxEnvironmentType
from inspect_ai.util._checkpoint import CheckpointConfig
from inspect_ai.util._display import (
    display_type_initialized,
    display_type_plain,
    init_display_type,
)
from inspect_ai.util._limit import (
    TokenLimit,
    resolve_token_limit,
    token_limit_fields,
)

from .eval import eval, eval_init, eval_resolve_tasks
from .eval_set_manifest import (
    INSPECT_EVAL_SET_CAPTURE,
    EvalSetCaptureScan,
    build_eval_set_capture,
    eval_set_capture_requested,
    samples_selected,
    task_args_hash,
)
from .eval_set_overrides import (
    EvalSetOverrides,
    EvalSetOverridesEpochs,
    eval_set_overrides_requested,
    merge_eval_set_overrides,
    read_eval_set_overrides,
)
from .eval_set_pruning import (
    disable_pruning,
    is_placeholder,
    materialize_pruned,
    pruned_anything,
    pruning_active,
)
from .eval_set_selection import (
    INSPECT_EVAL_SET_SELECTION,
    EvalSetSelection,
    eval_set_selection_requested,
    read_eval_set_selection,
)
from .loader import resolve_task_args, solver_from_spec
from .task import Epochs
from .task.resolved import ResolvedTask
from .task.scan import scan_context
from .task.task import PreviousTask, resolve_epochs
from .task.task_source import TaskSource
from .task.tasks import Tasks

if TYPE_CHECKING:
    from inspect_ai._control.eval_state import DeferredStatsProvider

logger = logging.getLogger(__name__)

_T = TypeVar("_T")


class Log(NamedTuple):
    info: EvalLogInfo
    header: EvalLog
    task_identifier: str


@dataclass
class EvalSetArgsInTaskIdentifier:
    config: GenerateConfig
    solver: Solver | SolverSpec | Agent | list[Solver] | None = None
    message_limit: int | None = None
    token_limit: int | TokenLimit | None = None
    turn_limit: int | None = None
    time_limit: int | None = None
    working_limit: int | None = None
    cost_limit: float | None = None


def _applied(value: _T, override: "_T | None") -> _T:
    """One override applied, or the value the definition passed.

    `None` on an override field means *keep what the definition chose*, which is what makes an omitted field and an absent document mean the same thing. Written as a function so that thirty-odd applications read as a list of names rather than as thirty-odd conditionals, and so that a mistyped pairing is a type error.
    """
    return value if override is None else override


def _overridden_selection(
    limit: "int | tuple[int, int] | None",
    sample_id: "str | int | list[str] | list[int] | list[str | int] | None",
    sample_shuffle: "bool | int | None",
    overrides: EvalSetOverrides,
) -> tuple[
    "int | tuple[int, int] | None",
    "str | int | list[str] | list[int] | list[str | int] | None",
    "bool | int | None",
]:
    """Which samples run, applied as one choice rather than as three fields.

    `eval()` forbids `sample_id` alongside either `limit` or `sample_shuffle`, so these three cannot be overridden the way the other thirty are. Applied independently, a definition that names `sample_id` and a runner that says `--limit 5` leave *both* set: capture counts by the ids and writes a manifest, and then every worker raises. A launch succeeds and the whole fleet fails, which is the worst available ordering.

    **So naming either side clears the other.** That is the only reading that lets an override express what it means — with `None` meaning *keep the definition's*, there is otherwise no way to say *ignore the ids and take the first five*, and the runner is stuck with a combination it cannot dissolve. `limit` and `sample_shuffle` are one side because `eval()` permits them together; `sample_id` is the other because it permits nothing with it.

    Silence still keeps everything: an overrides document that mentions none of the three is not a statement about selection at all.
    """
    # a document naming both sides is refused by `check_eval_set_overrides`
    # before it reaches here, so these two branches cannot both apply
    ids = overrides.sample_id
    sliced = (
        overrides.limit if overrides.limit is not None else overrides.sample_shuffle
    )
    if ids is not None:
        return None, ids, None
    if sliced is not None:
        return (
            _applied(limit, overrides.limit),
            None,
            _applied(sample_shuffle, overrides.sample_shuffle),
        )
    return limit, sample_id, sample_shuffle


def _overridden_epochs(
    epochs: int | EvalSetOverridesEpochs | None,
) -> int | Epochs | None:
    """An overrides document's epochs as `eval_set()` takes them.

    A bare count stays a count — it means what `eval_set(epochs=4)` means, reducers included, which is that the definition's are dropped along with its count. The object form is the wire shape of `Epochs`, whose reducers travel as registry names because they resolve to callables.
    """
    if isinstance(epochs, EvalSetOverridesEpochs):
        return Epochs(epochs.epochs, epochs.reducer)
    return epochs


def eval_set(
    tasks: Tasks,
    log_dir: str | None = None,
    retry_attempts: int | None = None,
    retry_wait: float | None = None,
    retry_connections: float | None = None,
    retry_cleanup: bool | None = None,
    retry_immediate: bool | None = None,
    model: str | Model | list[str] | list[Model] | None | NotGiven = NOT_GIVEN,
    model_base_url: str | None = None,
    model_args: dict[str, Any] | str = dict(),
    model_roles: ModelRoles | None = None,
    task_args: dict[str, Any] | str = dict(),
    sandbox: SandboxEnvironmentType | None = None,
    sandbox_cleanup: bool | None = None,
    sandbox_prebuilt: bool | None = None,
    checkpoint: CheckpointConfig | bool | None = None,
    acp_server: bool | int | str | None = None,
    ctl_server: bool | str | None = None,
    solver: Solver | SolverSpec | Agent | list[Solver] | None = None,
    scanner: "Scanners | None" = None,
    tags: list[str] | None = None,
    metadata: dict[str, Any] | None = None,
    trace: bool | None = None,
    display: DisplayType | None = None,
    approval: str | list[ApprovalPolicy] | ApprovalPolicyConfig | None = None,
    notification: bool | str | None = None,
    score: bool = True,
    score_display: bool | None = None,
    log_level: str | None = None,
    log_level_transcript: str | None = None,
    log_format: Literal["eval", "json"] | None = None,
    limit: int | tuple[int, int] | None = None,
    sample_id: str | int | list[str] | list[int] | list[str | int] | None = None,
    sample_shuffle: bool | int | None = None,
    epochs: int | Epochs | None = None,
    fail_on_error: bool | float | None = None,
    continue_on_fail: bool | None = None,
    retry_on_error: int | None = None,
    score_on_error: bool | None = None,
    debug_errors: bool | None = None,
    message_limit: int | None = None,
    token_limit: int | str | TokenLimit | None = None,
    turn_limit: int | None = None,
    time_limit: int | None = None,
    working_limit: int | None = None,
    cost_limit: float | None = None,
    model_cost_config: str | dict[str, ModelCost] | None = None,
    max_samples: int | None = None,
    max_dataset_memory: int | None = None,
    max_tasks: int | None = None,
    max_subprocesses: int | None = None,
    max_sandboxes: int | None = None,
    log_samples: bool | None = None,
    log_realtime: bool | None = None,
    log_images: bool | None = None,
    log_model_api: bool | None = None,
    log_refusals: bool | None = None,
    log_buffer: int | None = None,
    log_shared: bool | int | None = None,
    bundle_dir: str | None = None,
    bundle_overwrite: bool = False,
    log_dir_allow_dirty: bool | None = None,
    eval_set_id: str | None = None,
    embed_viewer: bool = False,
    **kwargs: Unpack[GenerateConfigArgs],
) -> tuple[bool, list[EvalLog]]:
    r"""Evaluate a set of tasks.

    Args:
        tasks: Task(s) to evaluate. If None, attempt
            to evaluate a task in the current working directory
        log_dir: Output path for logging results (defaults to INSPECT_LOG_DIR
            or ./logs). The directory is the eval set's storage scope, so a set
            that shares one with another set shares its results.
        retry_attempts: Maximum number of retry attempts before giving up
            (defaults to 10).
        retry_wait: Time to wait between attempts when `retry_immediate=False`,
            increased exponentially (defaults to 30, resulting in waits of 30, 60,
            120, 240, etc.). Wait time per-retry will in no case be longer than 1
            hour. Ignored when `retry_immediate=True`.
        retry_connections: Reduce max_connections at this rate with each retry
            when `retry_immediate=False` (defaults to 1.0, which results in no
            reduction). Ignored when `retry_immediate=True`.
        retry_cleanup: Cleanup failed log files after retries
            (defaults to True)
        retry_immediate: If True (the default), immediately retry tasks as they fail without waiting for all tasks to complete; completed samples are reused from logs on retry. If False, wait for all tasks to complete before retrying any tasks (legacy batch-retry behavior). When True, `retry_wait` and `retry_connections` are ignored.
        model: Model(s) for evaluation. If not specified use the value of the INSPECT_EVAL_MODEL
            environment variable. Specify `None` to define no default model(s), which will
            leave model usage entirely up to tasks.
        model_base_url: Base URL for communicating
            with the model API.
        model_args: Model creation args
            (as a dictionary or as a path to a JSON or YAML config file)
        model_roles: Named roles for use in `get_model()` (a role can also map to a list of models).
        task_args: Task creation arguments
            (as a dictionary or as a path to a JSON or YAML config file)
        sandbox: Sandbox environment type
            (or optionally a str or tuple with a shorthand spec)
        sandbox_cleanup: Cleanup sandbox environments after task completes
            (defaults to True)
        sandbox_prebuilt: Treat sandbox images as prebuilt, skipping builds
            and failing at task startup when an image is missing
            (defaults to False)
        checkpoint: Checkpoint configuration for this eval set, or `True`
            to enable checkpointing with the default trigger (every 500k
            tokens). Overrides any task- or sample-level `checkpoint`
            when set. A task can opt out with `Task(checkpoint=False)`,
            which overrides this enable for that task only.
        acp_server: Override the original eval's ACP server transport on retry.
            `True` enables a default AF_UNIX socket; an integer binds a TCP
            loopback port; a string is taken as a custom UNIX socket path;
            `None` (default) replays whatever transport (or no transport) was
            persisted in the original log's `EvalConfig.acp_server`.
        ctl_server: Control-channel server for this eval-set process.
            `True` or `None` (default) binds the default AF_UNIX socket;
            `False` disables the control endpoint; `"keep"` additionally
            keeps the process running after the eval-set finishes so external
            clients (the `inspect ctl` CLI, scripted agents, TUIs) can still
            query state and read results — exit via `inspect ctl process release`
            (or `POST /release`). Requires `retry_immediate=True` (the
            default) for the `"keep"` value.
        solver: Alternative solver(s) for
            evaluating task(s). Optional (uses task solver by default).
        scanner: Scanner(s) to apply to each sample's transcript after the
            sample completes.
        tags: Tags to associate with this evaluation run.
        metadata: Metadata to associate with this evaluation run.
        trace: Trace message interactions with evaluated model to terminal.
        display: Task display type (defaults to 'full').
        approval: Tool use approval policies.
            Either a path to an approval policy config file, an ApprovalPolicyConfig, or a list of approval policies.
            Defaults to no approval policy.
        notification: Enable out-of-band notifications when a human-in-the-loop
            interaction (`ask_user`, human approval) is posted. Pass `True` to
            send via the URL(s) in the `INSPECT_EVAL_NOTIFICATION` environment
            variable (single URL, comma-separated list, or path to an Apprise
            config file). Alternatively pass a path to an Apprise YAML/text
            config file. URLs are not accepted directly so secrets never end up
            in source code, shell history, process listings, or eval logs.
            Requires the `apprise` package.
        score: Score output (defaults to True)
        score_display: Show scoring metrics in realtime (defaults to True)
        log_level: Level for logging to the console: "debug", "http", "sandbox",
            "info", "warning", "error", "critical", or "notset" (defaults to "warning")
        log_level_transcript: Level for logging to the log file (defaults to "info")
        log_format: Format for writing
            log files (defaults to "eval", the native high-performance format).
        limit: Limit evaluated samples
            (defaults to all samples).
        sample_id: Evaluate specific sample(s) from the dataset. Use plain ids or preface with task names as required to disambiguate ids across tasks (e.g. `popularity:10`).
        sample_shuffle: Shuffle order of samples (pass a seed to make the order deterministic).
        epochs: Epochs to repeat samples for and optional score
            reducer function(s) used to combine sample scores (defaults to "mean")
        fail_on_error: `True` to fail on first sample error
            (default); `False` to never fail on sample errors; Value between 0 and 1
            to fail if a proportion of total samples fails. Value greater than 1 to fail
            eval if a count of samples fails.
        continue_on_fail: `True` to continue running and only fail at the end if the `fail_on_error` condition is met.
            `False` to fail eval immediately when the `fail_on_error` condition is met (default).
        retry_on_error: Number of times to retry samples if they encounter errors
            (by default, no retries occur).
        score_on_error: Score samples that error rather than failing the eval mid-run.
            Errors still count toward the `fail_on_error` threshold for marking the eval
            log as 'error'. Only takes effect after retries (if any) are exhausted.
        debug_errors: Raise task errors (rather than logging them)
            so they can be debugged (defaults to False).
        message_limit: Limit on total messages used for each sample.
        token_limit: Limit on tokens used for each sample. An `int` (or a
            `TokenLimit` with type "all") limits total tokens; a `TokenLimit`
            with a `type` limits by output tokens or an arithmetic formula over
            `input`/`output`. Also accepts strings like "500k", "1m",
            "output:1m", or "(input*0.1)+output:1m".
        turn_limit: Limit on total turns (model generations) used for each sample.
        time_limit: Limit on clock time (in seconds) for samples.
        working_limit: Limit on working time (in seconds) for sample. Working
            time includes model generation, tool calls, etc. but does not include
            time spent waiting on retries or shared resources.
        cost_limit: Limit on total cost (in dollars) for each sample.
            Requires model cost data via set_model_cost() or --model-cost-config.
        model_cost_config: YAML or JSON file with model prices for cost tracking.
        max_samples: Maximum number of samples to run in parallel within each task
            (default is max_connections)
        max_dataset_memory: Maximum MB of dataset sample data to hold in
            memory per task. When exceeded, samples are paged to a temporary
            file on disk (defaults to None, which keeps all samples in memory).
        max_tasks: Maximum number of tasks to run in parallel
            (defaults to the greater of 10 and the number of models being evaluated)
        max_subprocesses: Maximum number of subprocesses to
            run in parallel (default is the number of processors available to the eval)
        max_sandboxes: Maximum number of sandboxes (per-provider)
            to run in parallel.
        log_samples: Log detailed samples and scores (defaults to True)
        log_realtime: Log events in realtime (enables live viewing of samples in inspect view). Defaults to True.
        log_images: Log base64 encoded version of images,
            even if specified as a filename or URL (defaults to False)
        log_model_api: Log raw model api requests and responses. Note that error requests/responses are always logged.
        log_refusals: Log warnings for model refusals.
        log_buffer: Number of samples to buffer before writing log file.
            If not specified, an appropriate default for the format and filesystem is
            chosen (10 for most all cases, 100 for JSON logs on remote filesystems).
        log_shared: Sync sample events to log directory so that users on other systems
            can see log updates in realtime (defaults to no syncing). Specify `True`
            to sync every 10 seconds, otherwise an integer to sync every `n` seconds.
        bundle_dir: If specified, the log viewer and logs generated
            by this eval set will be bundled into this directory.
        bundle_overwrite: Whether to overwrite files in the bundle_dir.
            (defaults to False).
        log_dir_allow_dirty: If True, allow the log directory to contain
            unrelated logs. If False, ensure that the log directory only contains logs
            for tasks in this eval set (defaults to False).
        eval_set_id: ID for the eval set. If not specified, a unique ID will be generated.
        embed_viewer: If True, embed a log viewer into the log directory.
        **kwargs: Model generation options.

    Returns:
        A tuple of bool (whether all tasks completed successfully) and a list of `EvalLog` headers (i.e. raw sample data is not included in the logs returned).
    """
    from inspect_ai.hooks._hooks import emit_eval_set_end, emit_eval_set_start

    # canonical form so task_identifier hashing sees a stable value
    token_limit = resolve_token_limit(token_limit)

    num_retry_attempts = 10 if retry_attempts is None else retry_attempts
    if retry_immediate is None:
        retry_immediate = True
    task_retry_attempts = num_retry_attempts if retry_immediate else 0

    if retry_immediate and num_retry_attempts == 0:
        logger.warning(
            "retry_immediate=True has no effect when retry_attempts=0; "
            "no task-level retries will be performed."
        )

    # --ctl-server=keep requires retry_immediate=True (the default).
    # In retry_immediate=False mode eval-set makes multiple eval() calls
    # via tenacity, each with its own short-lived control server —
    # the keep-alive park would need to live OUTSIDE any single
    # eval() call, which is exactly the multi-loop bridging problem
    # we deliberately avoid (see design/ctl/control-channel.md "Server
    # lifecycle aligned with eval()"). Refuse the combination
    # explicitly rather than silently giving a broken keep-alive
    # experience.
    ctl = resolve_ctl_server(ctl_server)
    # clear a stale keep-alive intent left by a prior run in this process;
    # needed here as well as in eval_async because the all-reused short-circuit
    # parks without ever calling eval()
    reset_keep_alive()
    # likewise clear a prior run's launch-handoff emission, so this run's
    # park correctly detects whether *this* run emitted a handoff
    reset_launch_handoff_emitted()
    if ctl.keep_alive and retry_immediate is False:
        raise PrerequisiteError(
            "--ctl-server=keep is incompatible with retry_immediate=False "
            "(the legacy batch-retry mode tears down the control "
            "surface between attempts). Use --retry-immediate (the "
            "default) or drop the keep value."
        )
    # The eval-set owns the latch: set it now (after the rejection check),
    # before the inner eval() binds its (plain on/off) control server, so that
    # server reports keep-alive for the run and the inner eval() (eval_set_id
    # set) leaves the latch alone rather than resetting it. The park below reads
    # the same latch, so a runtime `POST /keep` during the run is honoured too.
    if ctl.keep_alive:
        request_keep_alive()

    # helper function to run a set of evals
    def run_eval(
        eval_set_id: str,
        tasks: list[ResolvedTask]
        | list[PreviousTask]
        | list[ResolvedTask | PreviousTask],
        selection_mode: bool = False,
    ) -> list[EvalLog]:
        # run evals
        results = eval(
            tasks=tasks,
            model=None,  # ResolvedTask/PreviousTask already carries its model
            model_base_url=model_base_url,
            model_args=model_args,
            model_roles=model_roles,
            task_args=task_args,
            sandbox=sandbox,
            sandbox_cleanup=sandbox_cleanup,
            sandbox_prebuilt=sandbox_prebuilt,
            checkpoint=checkpoint,
            solver=solver,
            scanner=scanner,
            tags=tags,
            metadata=metadata,
            trace=trace,
            display=display,
            approval=approval,
            notification=notification,
            log_level=log_level,
            log_level_transcript=log_level_transcript,
            log_dir=log_dir,
            log_format=log_format,
            limit=limit,
            sample_id=sample_id,
            sample_shuffle=sample_shuffle,
            epochs=epochs,
            fail_on_error=False if selection_mode else fail_on_error,
            continue_on_fail=continue_on_fail,
            retry_on_error=retry_on_error,
            score_on_error=score_on_error,
            debug_errors=debug_errors,
            message_limit=message_limit,
            token_limit=token_limit,
            turn_limit=turn_limit,
            time_limit=time_limit,
            working_limit=working_limit,
            cost_limit=cost_limit,
            model_cost_config=model_cost_config,
            max_samples=max_samples,
            max_dataset_memory=max_dataset_memory,
            max_tasks=max_tasks,
            max_subprocesses=max_subprocesses,
            max_sandboxes=max_sandboxes,
            log_samples=log_samples,
            log_realtime=log_realtime,
            log_images=log_images,
            log_model_api=log_model_api,
            log_refusals=log_refusals,
            log_buffer=log_buffer,
            log_shared=log_shared,
            log_header_only=True,
            score=score,
            score_display=score_display,
            eval_set_id=eval_set_id,
            task_retry_attempts=0 if selection_mode else task_retry_attempts,
            # On in selection mode, and not an override a definition can
            # decline. A selection-mode worker is detached: human input
            # dispatches ACP -> Textual panel -> console, and with no display
            # and a closed stdin the last of those raises EOFError into the
            # tool call -- so `approver: human` and `ask_user` neither park nor
            # fail loudly, they land as errored samples in successful logs.
            # A property of running detached rather than of any one runner,
            # which is why it is decided here beside the other two and not left
            # to the caller: of the definition shapes an external runner drives,
            # only some can pass the flag at all. A failed bind fails the
            # worker (see `acp_server`) rather than degrading, because the
            # channel it would degrade to is the dead end above.
            acp_server=True if selection_mode else acp_server,
            # Demoted to a plain on/off: eval-set owns the keep-alive park
            # itself (after the display closes), so the inner eval() must
            # not park inside the task display. See the park below.
            ctl_server=ctl.enabled,
            **kwargs,
        )

        # check for cancelled
        if evals_cancelled(results):
            raise KeyboardInterrupt

        # return results
        return results

    # external runner modes (capture enumerates the eval set; selection runs
    # one worker's share of it). they are two halves of the same protocol but
    # are never active at once.
    capture_path = eval_set_capture_requested()
    selection_path = eval_set_selection_requested()
    if capture_path is not None and selection_path is not None:
        raise PrerequisiteError(
            f"{INSPECT_EVAL_SET_CAPTURE} and {INSPECT_EVAL_SET_SELECTION} "
            "cannot both be set (capture enumerates an eval set without "
            "running it; selection runs tasks from an enumerated eval set)."
        )

    # what the definition itself asked for, read before any override replaces
    # it. The capture manifest's `options` is a record of the *definition* --
    # that is the whole of its use, since a runner already knows what it set
    # and cannot otherwise learn what it is displacing -- so it is built above
    # the application below rather than in the capture branch beneath it.
    definition_epochs = resolve_epochs(epochs)
    definition_options: dict[str, Any] = dict(
        log_dir=log_dir,
        retry_attempts=num_retry_attempts,
        # *which* samples run, all three of them. `limit` was here alone, which
        # left a runner unable to tell a definition that shuffles from one that
        # does not -- and a runner comparing a finished log against this to
        # decide whether it still answers the question then sees a shuffle in
        # the log, nothing here, and calls a settled task stale forever.
        limit=limit,
        sample_id=sample_id,
        sample_shuffle=sample_shuffle,
        epochs=definition_epochs.epochs if definition_epochs else None,
        tags=tags,
        metadata=metadata,
        # concurrency as the definition asked for it. a runner that sets any of
        # them (all three are operational overrides) otherwise has no way to
        # see what it is overriding, so a definition's explicit value is
        # silently replaced by the runner's default.
        max_samples=max_samples,
        max_sandboxes=max_sandboxes,
        max_tasks=max_tasks,
        # error handling as the definition asked for it, so a runner can see
        # what selection mode honours (retry_on_error) and what it overrides
        # (fail_on_error) rather than guessing.
        fail_on_error=fail_on_error,
        continue_on_fail=continue_on_fail,
        retry_on_error=retry_on_error,
        # whether the definition scans. workers scan record-only, so a runner
        # needs to learn this at enumeration time to lay the scan directory
        # down before its first worker starts (the serialized spec it does
        # that with is the capture's top-level `scan` field, not this bool).
        scanners=scanner is not None,
    )

    # a runner may override how this run is operated, run-wide (read in capture
    # mode too, so the manifest describes the run that actually happens) and
    # per worker (which wins). Applied here, above the display and above
    # eval_init, because several of the overridable arguments are arguments to
    # those two -- and above the `run_eval` closure's *call* rather than its
    # definition, which is what late binding makes sufficient.
    selection = (
        read_eval_set_selection(selection_path) if selection_path is not None else None
    )
    # The overrides document is runner protocol, not another source of
    # defaults for ordinary Python API calls. Capture needs the run-wide values
    # so its manifest describes what workers will run; selection needs them to
    # operate a worker. Outside those two modes the environment variable is
    # deliberately ignored.
    driven = capture_path is not None or selection_path is not None
    overrides_path = eval_set_overrides_requested() if driven else None
    overrides = merge_eval_set_overrides(
        read_eval_set_overrides(overrides_path) if overrides_path is not None else None,
        selection.overrides if selection is not None else None,
    )
    if overrides is not None:
        log_dir = _applied(log_dir, overrides.log_dir)
        log_format = _applied(log_format, overrides.log_format)
        log_samples = _applied(log_samples, overrides.log_samples)
        log_realtime = _applied(log_realtime, overrides.log_realtime)
        log_images = _applied(log_images, overrides.log_images)
        log_model_api = _applied(log_model_api, overrides.log_model_api)
        log_refusals = _applied(log_refusals, overrides.log_refusals)
        log_buffer = _applied(log_buffer, overrides.log_buffer)
        log_shared = _applied(log_shared, overrides.log_shared)
        log_level = _applied(log_level, overrides.log_level)
        log_level_transcript = _applied(
            log_level_transcript, overrides.log_level_transcript
        )
        # one choice rather than three fields, because `eval()` forbids two of
        # the combinations these could otherwise be left in
        limit, sample_id, sample_shuffle = _overridden_selection(
            limit, sample_id, sample_shuffle, overrides
        )
        epochs = _applied(epochs, _overridden_epochs(overrides.epochs))
        max_samples = _applied(max_samples, overrides.max_samples)
        max_tasks = _applied(max_tasks, overrides.max_tasks)
        max_subprocesses = _applied(max_subprocesses, overrides.max_subprocesses)
        max_sandboxes = _applied(max_sandboxes, overrides.max_sandboxes)
        max_dataset_memory = _applied(max_dataset_memory, overrides.max_dataset_memory)
        model_base_url = _applied(model_base_url, overrides.model_base_url)
        model_cost_config = _applied(model_cost_config, overrides.model_cost_config)
        sandbox = _applied(sandbox, overrides.sandbox)
        sandbox_cleanup = _applied(sandbox_cleanup, overrides.sandbox_cleanup)
        sandbox_prebuilt = _applied(sandbox_prebuilt, overrides.sandbox_prebuilt)
        checkpoint = _applied(checkpoint, overrides.checkpoint)
        approval = _applied(approval, overrides.approval)
        retry_on_error = _applied(retry_on_error, overrides.retry_on_error)
        score_on_error = _applied(score_on_error, overrides.score_on_error)
        debug_errors = _applied(debug_errors, overrides.debug_errors)
        score = _applied(score, overrides.score)
        score_display = _applied(score_display, overrides.score_display)
        tags = _applied(tags, overrides.tags)
        metadata = _applied(metadata, overrides.metadata)
        notification = _applied(notification, overrides.notification)
        display = _applied(display, overrides.display)
        trace = _applied(trace, overrides.trace)
        if overrides.generate_config is not None:
            kwargs = cast(
                GenerateConfigArgs,
                {
                    **kwargs,
                    **overrides.generate_config.model_dump(
                        exclude_unset=True, exclude_none=True
                    ),
                },
            )

    # initialise display (otherwise eval_init will set it to full)
    if not display_type_initialized():
        display = init_display_type(display)
    if display == "conversation":
        raise RuntimeError("eval_set cannot be used with conversation display.")

    # initialize eval
    models = eval_init(
        model=model,
        model_base_url=model_base_url,
        model_args=model_args,
        max_subprocesses=max_subprocesses,
        log_level=log_level,
        log_level_transcript=log_level_transcript,
        log_refusals=log_refusals,
        **kwargs,
    )

    # capture mode: resolve tasks, write the manifest, and exit the process
    # without running anything. deliberately placed before any log_dir side
    # effects (mkdir, .eval-set-id, eval-set.json) and before eval-set hooks.
    if capture_path is not None:
        if isinstance(tasks, TaskSource):
            raise PrerequisiteError(
                "Dynamic task sources (TaskSource) cannot be enumerated "
                "with eval-set capture."
            )
        capture_config = GenerateConfig(**kwargs)
        capture_tasks, _ = eval_resolve_tasks(
            tasks,
            task_args,
            models,
            model_roles,
            capture_config,
            approval,
            sandbox,
            sample_shuffle,
            notification=notification,
            input_media_policy="trusted_pre_run",
        )
        if len(capture_tasks) == 0:
            raise PrerequisiteError(
                "Error: No inspect tasks were found at the specified paths."
            )
        # the definition's scanner configuration, serialized so a runner can
        # own the scan directory's lifecycle without executing the definition
        # (workers scan record-only in selection mode).
        captured = serialized_scan(scanner, scan_id=eval_set_id)
        capture_scan = (
            EvalSetCaptureScan(spec=captured[0], scans=captured[1])
            if captured is not None
            else None
        )
        capture = build_eval_set_capture(
            capture_tasks,
            EvalSetArgsInTaskIdentifier(
                config=capture_config,
                solver=solver,
                message_limit=message_limit,
                token_limit=token_limit,
                turn_limit=turn_limit,
                time_limit=time_limit,
                working_limit=working_limit,
                cost_limit=cost_limit,
            ),
            epochs=epochs,
            limit=limit,
            sample_id=sample_id,
            eval_set_id=eval_set_id,
            options=definition_options,
            overrides=overrides,
            scan=capture_scan,
        )
        with file(capture_path, mode="wb") as f:
            f.write(to_json_safe(capture))
        raise SystemExit(0)

    # resolve log_dir, matching eval(). deliberately below the capture branch,
    # which exits before any log_dir side effect: a capture manifest records
    # the options *the definition passed*, so a definition that named no
    # directory must be reported as having named none rather than as having
    # named this default. absolute_file_path() is likewise not applied -- eval()
    # does it, but doing it here would change the recorded location of every
    # relative log_dir an eval set already uses
    if log_dir is None:
        log_dir = os.environ.get("INSPECT_LOG_DIR", "./logs")

    # ensure log_dir
    fs = filesystem(log_dir)
    fs.mkdir(log_dir, exist_ok=True)

    # selection (worker) mode: run only the selected tasks through the ordinary
    # eval() path. everything below this point is eval-set orchestration
    # (directory scanning, eval-set metadata, retry partitioning, log cleanup,
    # bundling) and is deliberately skipped -- the external runner owns it, and
    # skipping it is what lets many workers share one log directory.
    if selection is not None:
        if isinstance(tasks, TaskSource):
            raise PrerequisiteError(
                "Dynamic task sources (TaskSource) cannot be used with "
                "eval-set selection."
            )
        # scanning in selection mode is record-only: workers dispatch scanners
        # per settled sample and write scout's per-transcript buffer, and the
        # runner owns the scan directory's lifecycle (init/finalize) as its
        # single writer. The inner eval() runs with eval_set_id set, so it
        # never enters scan_context -- record-only needs no bracket to skip,
        # only the two guarantees below: the merged scanner set matches what
        # the runner wrote into the scan directory (a collision refuses), and
        # a missing scan directory refuses loudly rather than letting
        # scan_eval_sample's exists() check silently not-scan.
        scanner = merged_selection_scanner(scanner, selection.scanners)
        verify_selection_scan_dir(
            scanner, scan_id=selection.eval_set_id, log_dir=log_dir
        )
        selection_config = GenerateConfig(**kwargs)

        def resolve_selection_tasks(selection_input: Tasks) -> list[ResolvedTask]:
            resolved, _ = eval_resolve_tasks(
                selection_input,
                task_args,
                models,
                model_roles,
                selection_config,
                approval,
                sandbox,
                sample_shuffle,
                notification=notification,
                input_media_policy="trusted_pre_run",
            )
            if len(resolved) == 0:
                raise PrerequisiteError(
                    "Error: No inspect tasks were found at the specified paths."
                )
            return resolved

        selection_args = EvalSetArgsInTaskIdentifier(
            config=selection_config,
            solver=solver,
            message_limit=message_limit,
            token_limit=token_limit,
            turn_limit=turn_limit,
            time_limit=time_limit,
            working_limit=working_limit,
            cost_limit=cost_limit,
        )

        # same run-boundary cleanup the eval-set path does in its own `finally`
        # below: the inner eval() runs with eval_set_id set, so it leaves both
        # the keep-alive park and the registry reset to its caller.
        def run_selection(selection_input: Tasks) -> tuple[bool, list[EvalLog]]:
            return _run_eval_set_selection(
                selection,
                resolve_selection_tasks(selection_input),
                selection_args,
                lambda worker_eval_set_id, worker_tasks: run_eval(
                    worker_eval_set_id, worker_tasks, selection_mode=True
                ),
                log_dir,
            )

        try:
            try:
                return run_selection(tasks)
            except PrunedTaskMissing as ex:
                # early pruning skipped a task this worker was selected to run,
                # which is a bug in the matching rather than a fact about the
                # eval set. Build what was skipped and try once more: the cost
                # is exactly the resolution that would have happened without
                # pruning at all, and the alternative is failing a run over an
                # optimization (eval_set_pruning.py, *The safety property*).
                #
                # `materialize_pruned` rather than a bare re-resolve, because
                # for the ordinary `eval_set(tasks=[foo(), bar()])` shape the
                # placeholders are already in the caller's list -- they were
                # made while evaluating the argument, before this function was
                # entered -- so resolving again would resolve the same
                # placeholders.
                logger.warning(
                    f"Early task pruning skipped selected task "
                    f"'{ex.identifier}'; building the full eval set and "
                    f"retrying. This is an inspect bug -- the run is "
                    f"unaffected apart from its startup cost."
                )
                disable_pruning()
                return run_selection(materialize_pruned(tasks))
        finally:
            reset_run_registries()

    # get eval set id (set display name from user-provided value before resolution)
    set_eval_set_id_display(eval_set_id)
    eval_set_id = eval_set_id_for_log_dir(log_dir, eval_set_id=eval_set_id)

    # resolve some parameters
    retry_connections = retry_connections or 1.0
    retry_cleanup = retry_cleanup is not False
    # adaptive_connections subsumes retry_connections — the controller manages
    # scale-down internally on retry signals. Force retry_connections to 1.0
    # silently (rather than warning), so that this stays quiet when adaptive
    # eventually becomes default-on. Only fires when adaptive will actually be
    # active: explicit max_connections takes precedence (per the precedence
    # rule in Model._connection_concurrency), batch mode disables adaptive
    # entirely (worker tasks don't propagate retry signals), and in those
    # cases retry_connections decay should still apply to the static cap.
    # The predicate must match Model._connection_concurrency and
    # create_sample_semaphore exactly — otherwise a user passing
    # batch=True + adaptive_connections=True + retry_connections=0.5 would
    # silently lose decay (evalset suppresses it, but the model path goes
    # static and never sets up an adaptive controller).
    from inspect_ai.util._concurrency import adaptive_active

    adaptive_will_be_active = adaptive_active(
        kwargs.get("adaptive_connections"),
        kwargs.get("max_connections"),
        kwargs.get("batch"),
    )
    if adaptive_will_be_active:
        retry_connections = 1.0
    max_connections = starting_max_connections(models, GenerateConfig(**kwargs))
    max_tasks = max_tasks if max_tasks is not None else max(len(models), 10)
    log_dir_allow_dirty = log_dir_allow_dirty is True

    # prepare console/status
    console = rich.get_console()
    status: Status | None = None

    # before sleep
    def before_sleep(retry_state: RetryCallState) -> None:
        # Compute/update next max_connections, but only inject into kwargs when
        # retry_connections actually decays (!= 1.0). Reasons:
        #   1. If adaptive will be active at eval-set level, retry_connections
        #      was already forced to 1.0 above (controller handles scale-down).
        #   2. With default retry_connections=1.0, the "decayed" value equals
        #      the original — injecting would be a no-op for static behavior
        #      but would silently override any task-level adaptive_connections
        #      (since any non-None max_connections disables adaptive per the
        #      precedence rule in Model._connection_concurrency).
        # When the user explicitly opts into decay (retry_connections != 1.0),
        # we inject — this preserves the long-standing static behavior, with
        # the trade-off that task-level adaptive yields to the explicit decay.
        nonlocal max_connections
        if retry_connections != 1.0:
            max_connections = max(round(max_connections * retry_connections), 1)
            kwargs["max_connections"] = max_connections

        # print waiting status
        msg = (
            f"Evals not complete, waiting {round(retry_state.upcoming_sleep)} "
            + "seconds before retrying...\n"
        )
        if display_type_plain():
            display_manager().print(msg)
        else:
            nonlocal status
            console.print("")
            status = console.status(status_msg(msg), spinner="clock")
            status.start()

    def before(retry_state: RetryCallState) -> None:
        # clear waiting status
        nonlocal status
        if status is not None:
            status.stop()
            status = None

    # function which will be called repeatedly to attempt to complete
    # the evaluations. for this purpose we will divide tasks into:
    #   - tasks with no log at all (they'll be attempted for the first time)
    #   - tasks with a successful log (they'll just be returned)
    #   - tasks with failed logs (they'll be retried)
    def try_eval() -> list[EvalLog]:
        config = GenerateConfig(**kwargs)
        # resolve tasks
        resolved_tasks, _ = eval_resolve_tasks(
            tasks,
            task_args,
            models,
            model_roles,
            config,
            approval,
            sandbox,
            sample_shuffle,
            notification=notification,
            input_media_policy="trusted_pre_run",
        )

        # fail with a legible error if no tasks were found (matches `eval`)
        if len(resolved_tasks) == 0:
            raise PrerequisiteError(
                "Error: No inspect tasks were found at the specified paths."
            )

        # list all logs currently in the log directory (update manifest if there are some)
        all_logs = list_all_eval_logs(log_dir)
        if len(all_logs) > 0:
            write_log_dir_manifest(log_dir)

        eval_set_args = EvalSetArgsInTaskIdentifier(
            config=config,
            solver=solver,
            message_limit=message_limit,
            token_limit=token_limit,
            turn_limit=turn_limit,
            time_limit=time_limit,
            working_limit=working_limit,
            cost_limit=cost_limit,
        )
        # validate that:
        #  (1) All tasks have a unique identifier
        #  (2) All logs have identifiers that map to tasks
        all_logs = validate_eval_set_prerequisites(
            resolved_tasks, all_logs, log_dir_allow_dirty, eval_set_args
        )

        # write eval-set info containing data about
        # all the tasks that are a part of this eval set
        # (include all tasks, not just tasks that need to be
        # run in this pass)
        write_eval_set_info(
            eval_set_id, log_dir, resolved_tasks, all_logs, eval_set_args
        )

        # see which tasks are yet to run (to complete successfully we need
        # a successful eval for every [task_file/]task_name/model combination)
        # for those that haven't run, schedule them into models => tasks groups
        # (exclude logs where sample_shuffle changed with a limit -- a different
        # shuffle selects a different subset of samples so the log can't be reused)
        reusable_logs = [
            log
            for log in all_logs
            if not shuffle_changed(sample_shuffle, log.header.eval.config, limit)
        ]
        log_task_identifiers = [log.task_identifier for log in reusable_logs]
        all_tasks = [
            (task_identifier(task, eval_set_args), task) for task in resolved_tasks
        ]
        pending_tasks = [
            task[1] for task in all_tasks if task[0] not in log_task_identifiers
        ]
        tasks_to_run: (
            list[ResolvedTask | PreviousTask] | list[ResolvedTask] | list[PreviousTask]
        )
        if len(pending_tasks) == len(all_tasks):
            tasks_to_run = pending_tasks
            success_logs: list[Log] = []
        else:
            # look for retryable eval logs and cleave them into success/failed
            success_logs, failed_logs = list_latest_eval_logs(
                all_tasks,
                all_logs,
                epochs=epochs,
                limit=limit,
                sample_id=sample_id,
                cleanup_older=retry_cleanup,
            )
            if not failed_logs:
                failed_tasks = []
            else:
                failed_task_identifiers = [log.task_identifier for log in failed_logs]
                failed_resolved_tasks = [
                    task
                    for task in resolved_tasks
                    if task_identifier(task, eval_set_args) in failed_task_identifiers
                ]
                failed_tasks = as_previous_tasks(
                    failed_resolved_tasks, failed_logs, eval_set_args
                )
            combined_tasks: list[ResolvedTask | PreviousTask] = [
                *pending_tasks,
                *failed_tasks,
                *_resume_scan_tasks(
                    scanner,
                    success_logs,
                    resolved_tasks,
                    eval_set_args,
                    prior_scan_clean,
                ),
            ]
            tasks_to_run = combined_tasks

            _register_reused_logs(success_logs)

            if not tasks_to_run:
                return [log.header for log in success_logs]

        # run the tasks
        run_logs = run_eval(eval_set_id, tasks_to_run)

        # if this was the entire list of resolved tasks, return results
        if len(tasks_to_run) == len(all_tasks):
            return run_logs
        # otherwise combine the successful logs with the newly run logs
        else:
            return [log.header for log in success_logs] + run_logs

    # create retry policy
    retry = Retrying(
        retry=retry_if_not_result(all_evals_succeeded),
        retry_error_callback=return_last_value,
        reraise=True,
        stop=stop_after_attempt(num_retry_attempts),
        wait=wait_exponential(retry_wait or 30, max=(60 * 60)),
        before_sleep=before_sleep,
        before=before,
    )

    # must read BEFORE scan_context enters — scan_init invalidates the
    # finalize flag on attach, so reading from inside try_eval is too late
    prior_scan_clean = scan_already_clean(scanner, eval_set_id, log_dir)

    # EvalStates accumulate as tasks run (task_run registers but never
    # unregisters); clear the registry at this run boundary — in `finally`,
    # after any keep-alive park — so they stay visible in `inspect ctl task list`
    # through the run + park, but don't leak past it.
    try:
        with (
            _embed_viewer(log_dir) if embed_viewer else contextlib.nullcontext(),
            scan_context(scanner, scan_id=eval_set_id, log_dir=log_dir),
        ):
            # emit start event
            run_coroutine(emit_eval_set_start(eval_set_id, log_dir))

            if retry_immediate:
                # retry handled by eval
                results = try_eval()
            else:
                # execute w/ retry
                results = retry(try_eval)

            # final sweep to remove failed log files
            if retry_cleanup:
                task_ids = {result.eval.task_id for result in results}
                cleanup_older_eval_logs(log_dir, task_ids)

        # if specified, bundle the output directory
        if bundle_dir:
            bundle_log_dir(
                log_dir=log_dir, output_dir=bundle_dir, overwrite=bundle_overwrite
            )

        # report final status
        success = all_evals_succeeded(results)
        if success:
            msg = status_msg(f"Completed all tasks in '{log_dir}' successfully")
        else:
            msg = status_msg(f"Did not successfully complete all tasks in '{log_dir}'.")
        console.print(f"{msg}")

        if scanner is not None:
            from inspect_ai._eval.task.scan import print_scan_status

            print()
            print_scan_status(log_dir, scanner)

        # update manifest
        write_log_dir_manifest(log_dir)

        # emit end event
        run_coroutine(emit_eval_set_end(eval_set_id, log_dir))

        # park last of all — display closed and summary printed, so the
        # keep-alive notice lands in the console (not the live display pane).
        # Gate on the intent (not just the launch flag) so a runtime `inspect
        # ctl process keep` during the run also parks; intent reflects the last-write
        # of any keep / release received during the run.
        if keep_alive_intent():
            run_coroutine(_keep_alive_park(eval_set_id, log_dir))

        # return status + results
        return success, results
    finally:
        reset_run_registries()


@contextlib.contextmanager
def _embed_viewer(log_dir: str, interval: float = 30) -> Iterator[None]:
    embed_log_dir(log_dir=log_dir)

    stop_event = threading.Event()
    last_state: frozenset[tuple[str, float | None]] = frozenset()

    def update_listing() -> None:
        nonlocal last_state
        while not stop_event.wait(interval):
            try:
                logs = list_eval_logs(log_dir)
                current_state = frozenset((log.name, log.mtime) for log in logs)
                if current_state != last_state:
                    write_log_listing(log_dir, logs=logs)
                    last_state = current_state
            except Exception:
                pass

    threading.Thread(target=update_listing, daemon=True, name="listing-updater").start()
    try:
        yield
    finally:
        stop_event.set()
        write_log_listing(log_dir)


def _register_reused_logs(success_logs: list[Log]) -> None:
    """Publish synthetic :class:`EvalState`s for reused successful logs.

    Reused tasks bypass ``task_run.py`` (their results are read from
    disk rather than re-computed), so the per-task ``register_eval``
    that normally publishes state never fires for them. Without an
    explicit registration here, ``inspect ctl task list`` would show zero
    entries for an eval-set whose tasks all came from prior logs —
    confusing for an agent driving an eval-set under ``--ctl-server=keep``
    that expects to see what the eval-set returned.

    Registration uses only the already-parsed headers (eval-set read them
    to decide reuse), so it costs no extra I/O: the summaries-derived stats
    (messages and the precise completed/errored split) are deferred behind
    ``deferred_sample_stats`` and resolved by the first control request —
    an eval-set that no control client ever queries never reads them.
    """
    from inspect_ai._util.dateutil import datetime_from_iso_format_safe

    for log_entry in success_logs:
        header = log_entry.header
        eval_spec = header.eval
        results = header.results
        stats = header.stats

        total = results.total_samples if results is not None else 0

        completed_at: float | None = None
        completed_str = stats.completed_at if stats is not None else ""
        if completed_str:
            try:
                completed_at = datetime_from_iso_format_safe(completed_str).timestamp()
            except (ValueError, TypeError):
                completed_at = None

        tokens = (
            sum(u.total_tokens for u in stats.model_usage.values())
            if stats is not None
            else 0
        )

        # Provisional terminal split, shown only until the deferred
        # resolution (or permanently, if its read fails): optimistically
        # all-completed. Deriving `errored` from the header's
        # `completed_samples` would mislabel early-stopped / unscored
        # samples of a successful log as errors — phantom failures that
        # mislead a monitoring agent into retrying or alerting on a healthy
        # task. The precise split (which CAN surface genuine tolerated
        # errors) arrives with the deferred resolution; either way the
        # counters sum to `total`, so the row renders terminal with no
        # phantom `queued`.
        register_completed_eval(
            eval_spec.eval_id,
            total=total,
            completed=total,
            errored=0,
            task=eval_spec.task,
            task_id=eval_spec.task_id,
            model=str(eval_spec.model) if eval_spec.model else "",
            solver=eval_plan_agent_name(header.plan),
            log_location=log_entry.info.name,
            run_id=eval_spec.run_id,
            completed_at=completed_at,
            total_tokens=tokens,
            total_messages=0,
            # without results the captured `total` is 0 and a resolution
            # could write `errored > total`; leave the provisional standing
            deferred_sample_stats=_deferred_sample_stats(log_entry, total)
            if results is not None
            else None,
        )


def _deferred_sample_stats(log_entry: Log, total: int) -> "DeferredStatsProvider":
    """Lazy accessor for a reused log's summaries-derived stats.

    Messages and the precise terminal buckets require reading the per-sample
    summaries (a full log read — a network round-trip on S3), deferred to the
    first control request. The split mirrors what the live path would have
    recorded: ``errored`` counts samples whose final attempt failed — a
    status-``success`` log can contain these under ``fail_on_error``
    tolerance — and everything else (scored and early-stopped alike, which
    the live path both record as completed) lands in ``completed``.
    """

    async def provider() -> DeferredSampleStats:
        from inspect_ai.log._file import read_eval_log_sample_summaries_async

        summaries = await read_eval_log_sample_summaries_async(log_entry.info)
        errored = sum(1 for s in summaries if s.error is not None)
        return DeferredSampleStats(
            total_messages=sum(s.message_count or 0 for s in summaries),
            completed=max(0, total - errored),
            errored=errored,
        )

    return provider


async def _keep_alive_park(eval_set_id: str, log_dir: str) -> None:
    """Park the eval-set process after the run completes (display closed).

    Runs on a fresh loop once ``eval()`` (and its task display) has exited
    and the summary has printed, so the notice + wait land in the console.
    Brings up a control server for the lingering window and blocks until
    ``POST /release``. EvalStates stay visible throughout (live ones
    accumulated during the run, reused ones via
    :func:`_register_reused_logs`); ``eval_set`` clears them at the run
    boundary once this returns.

    A release received while the run was still in flight wins ("exit when
    done") — the run's server is gone by the time this park binds its fresh
    one, so the module-level intent is the only carrier of that request.
    """
    if not keep_alive_intent():
        return
    async with control_server(run_id=eval_set_id) as ctl_server:
        if ctl_server is None:
            # Bind failed: nothing to park on (can't be released via
            # `inspect ctl process release`), so don't linger.
            return
        # A set whose tasks were all reused ran no eval, so nothing emitted
        # the launch handoff — yet this park just bound a control surface a
        # `--json` / `--detach` consumer is waiting to hear about. Emit it
        # here (run_id None: no run happened), only when the run itself
        # emitted none, so keep-alive runs still see exactly one `launch`.
        control_socket = (
            str(ctl_server.socket_path) if ctl_server.socket_path is not None else None
        )
        if not launch_handoff_emitted():
            emit_launch_handoff(
                LaunchHandoff(
                    run_id=None,
                    pid=os.getpid(),
                    log_dir=log_dir,
                    control_socket=control_socket,
                    eval_set_id=eval_set_id,
                )
            )
        # unconditional (unlike the handoff): the once-per-process latch
        # already makes this a no-op when the run's own bind printed, and in
        # the all-reused case this park is the only bind, so it closes the
        # same hole for console consumers that the handoff closes for --json
        print_ctl_pointer(control_socket)
        rich.get_console().print(
            "Eval-set finished. Keeping process alive — press Ctrl+C or run "
            "`inspect ctl process release` to let it exit.",
            markup=False,
            highlight=False,
        )
        await wait_for_shutdown_async(ctl_server)


def eval_set_id_for_log_dir(log_dir: str, eval_set_id: str | None = None) -> str:
    EVAL_SET_ID_FILE = ".eval-set-id"
    fs = filesystem(log_dir)
    eval_set_id_file = f"{log_dir}{fs.sep}{EVAL_SET_ID_FILE}"
    if fs.exists(eval_set_id_file):
        with file(eval_set_id_file, "r") as f:
            eval_set_id_existing = f.read().strip()
            if eval_set_id and eval_set_id != eval_set_id_existing:
                raise PrerequisiteError(
                    f"[bold]ERROR[/bold]: The eval set ID '{eval_set_id}' is not the same as the existing eval set ID '{eval_set_id_existing}'."
                )
            return eval_set_id_existing

    if not eval_set_id:
        eval_set_id = uuid()
    with file(eval_set_id_file, "w") as f:
        f.write(eval_set_id)
    return eval_set_id


def _resume_scan_tasks(
    scanner: "Scanners | None",
    success_logs: list[Log],
    resolved_tasks: list[ResolvedTask],
    eval_set_args: EvalSetArgsInTaskIdentifier,
    prior_scan_clean: bool,
) -> list[PreviousTask]:
    """Build PreviousTask wrappers for success_logs that may need re-scanning.

    Returned tasks fan out via `run_eval` so the per-sample reuse path
    can dispatch scans for transcripts whose row never landed in the
    scan dir. Returns an empty list when there's no scan work to do
    (no scanner, no success logs, or the prior scan finalized
    cleanly — in which case every transcript already has a row).

    Must be added to `tasks_to_run` even when there are pending or
    failed tasks; otherwise unscanned transcripts in already-
    completed tasks are silently skipped on every call that has work.
    """
    if scanner is None or not success_logs or prior_scan_clean:
        return []
    success_task_identifiers = {log.task_identifier for log in success_logs}
    success_resolved_tasks = [
        task
        for task in resolved_tasks
        if task_identifier(task, eval_set_args) in success_task_identifiers
    ]
    return as_previous_tasks(success_resolved_tasks, success_logs, eval_set_args)


# convert resolved tasks to previous tasks
def as_previous_tasks(
    tasks: list[ResolvedTask],
    failed_logs: list[Log],
    eval_set_args: EvalSetArgsInTaskIdentifier,
) -> list[PreviousTask]:
    def task_to_failed_log(task: ResolvedTask) -> Log:
        resolved_task_identifier = task_identifier(task, eval_set_args)
        return next(
            log
            for log in failed_logs
            if log.task_identifier == resolved_task_identifier
        )

    previous_tasks: list[PreviousTask] = []
    for task, log in zip(tasks, map(task_to_failed_log, tasks)):
        eval_log, log_info = _recover_crashed_log(log.header, log.info)
        previous_tasks.append(
            PreviousTask(
                id=eval_log.eval.task_id,
                task=task.task,
                task_args=resolve_task_args(task.task),
                model=task.model,
                model_roles=task.model_roles,
                log=eval_log,
                log_info=log_info,
            )
        )

    return previous_tasks


def _recover_crashed_log(
    eval_log: EvalLog, log_info: EvalLogInfo
) -> tuple[EvalLog, EvalLogInfo]:
    """Opportunistically recover a still-"started" log before retrying it.

    A log left in "started" state was interrupted rather than completed, so its
    samples may only exist in the buffer database. Recovery folds them back
    into a readable log; when it isn't possible the original log is returned
    unchanged (the task simply re-runs the samples).

    Args:
        eval_log: Header of the log to retry.
        log_info: File info for that log.

    Returns:
        The recovered log and file info, or the originals when no recovery was available.
    """
    if eval_log.status == "started" and eval_log.location:
        from inspect_ai.log._recover import (
            RecoveryNotAvailable,
            recover_eval_log,
        )

        try:
            recovered = recover_eval_log(eval_log.location, cleanup=False)
            if recovered.location:
                log_info = log_info.model_copy(update={"name": recovered.location})
            eval_log = recovered
        except RecoveryNotAvailable:
            pass  # no recovery data available
        except Exception as ex:
            logger.warning(f"Recovery failed for {eval_log.location}: {ex}")

    return eval_log, log_info


# eval-set selection (worker) mode. `eval_set()` delegates here once it has
# resolved its tasks; everything specific to running a worker's share of an
# eval set lives in the three functions below. See eval_set_selection.py for
# the protocol these implement.


class PrunedTaskMissing(Exception):
    """A selected task was absent from a resolution that skipped tasks.

    Internal and never seen by a user: the selection branch catches it, resolves again with pruning disabled, and either succeeds or raises the ordinary drift error. It exists so that *the definition changed* and *pruning was wrong* are answered differently, since only the second one is worth paying a second resolution for.
    """

    def __init__(self, identifier: str) -> None:
        super().__init__(identifier)
        self.identifier = identifier


def _run_eval_set_selection(
    selection: EvalSetSelection,
    resolved_tasks: list[ResolvedTask],
    eval_set_args: EvalSetArgsInTaskIdentifier,
    run_eval: Callable[[str, list[ResolvedTask | PreviousTask]], list[EvalLog]],
    log_dir: str,
) -> tuple[bool, list[EvalLog]]:
    """Run a worker's share of an eval set.

    Reads the selection, narrows the eval set's resolved tasks to it, and runs
    just those through the ordinary `eval()` path. No eval-set orchestration is
    performed: the external runner that wrote the selection owns the log
    directory, its metadata, and every retry decision.

    Args:
        selection: The selection document read from `INSPECT_EVAL_SET_SELECTION` (any operational overrides it carries have already been applied by the caller).
        resolved_tasks: All tasks resolved by this eval set (tasks × models).
        eval_set_args: Eval-set level args that participate in task identity.
        run_eval: Runs the selected tasks under an eval set id, returning their logs.
        log_dir: Log directory (for the keep-alive park's launch handoff).

    Returns:
        Whether every selected task succeeded, and the logs they produced.

    Raises:
        PrerequisiteError: If the selection does not correspond to this eval set's tasks.
    """
    selected = _selected_eval_set_tasks(resolved_tasks, selection, eval_set_args)
    set_eval_set_id_display(selection.eval_set_id)
    logs = run_eval(selection.eval_set_id, selected)

    # keep-alive: park exactly as the eval-set path does — after the run, with
    # the task display closed. A worker binds its own (pid-keyed) socket, so
    # concurrent workers parking under the shared eval set id don't collide;
    # `inspect ctl` disambiguates them by pid as it does during the run.
    if keep_alive_intent():
        run_coroutine(_keep_alive_park(selection.eval_set_id, log_dir))

    return all_evals_succeeded(logs), logs


def _selected_eval_set_tasks(
    resolved_tasks: list[ResolvedTask],
    selection: EvalSetSelection,
    eval_set_args: EvalSetArgsInTaskIdentifier,
) -> list[ResolvedTask | PreviousTask]:
    """Pick the tasks named by a worker's selection out of the resolved eval set.

    Args:
        resolved_tasks: All tasks resolved by this eval set (tasks × models).
        selection: Selection naming tasks by `task_identifier`.
        eval_set_args: Eval-set level args that participate in task identity.

    Returns:
        The selected tasks, in selection order, with any task carrying a `resume` location wrapped as a `PreviousTask` so its completed samples are reused.

    Raises:
        PrerequisiteError: If an identifier matches no resolved task or more than one of them, or if a `resume` log is missing or belongs to a different task.
    """
    # placeholders never reach identifier computation, and could not survive it
    # -- a task that was skipped rather than constructed has no solver plan to
    # hash. Dropping them here is also the whole of what the boundary has to
    # know about pruning: everything above this line treated them as ordinary
    # tasks, so `sequence` and the resolved ordering are what they would have
    # been without pruning at all
    by_identifier: dict[str, list[ResolvedTask]] = {}
    for task in resolved_tasks:
        if is_placeholder(task.task):
            continue
        by_identifier.setdefault(task_identifier(task, eval_set_args), []).append(task)

    selected: list[ResolvedTask | PreviousTask] = []
    for entry in selection.tasks:
        matches = by_identifier.get(entry.identifier, [])
        # `pruning_active()` as well as `pruned_anything()`, and the retry is
        # why: the flag records that tasks were skipped at some point in this
        # process, which stays true after pruning is switched off. Without the
        # first clause the re-resolve raises this again and the real error
        # never surfaces
        if len(matches) == 0 and pruning_active() and pruned_anything():
            # a selected task is missing and tasks were skipped, so the skipping
            # is the first suspect. Not an error yet: the caller resolves again
            # with pruning off, which either finds the task (pruning was wrong,
            # and cost time rather than the run) or raises the drift error below
            # against a resolution that skipped nothing
            raise PrunedTaskMissing(entry.identifier)
        if len(matches) == 0:
            raise PrerequisiteError(
                f"[bold]ERROR[/bold]: Task identifier '{entry.identifier}' does "
                f"not match any of the {len(resolved_tasks)} tasks resolved by "
                "this eval set. The definition may have changed since its "
                "tasks were enumerated, or it may be running from a different "
                "path or working directory (a task's source file is part of "
                "its identity)."
            )
        elif len(matches) > 1:
            raise PrerequisiteError(
                f"[bold]ERROR[/bold]: Task identifier '{entry.identifier}' "
                f"matches {len(matches)} tasks in this eval set. Tasks in an "
                "eval set must be uniquely identified."
            )
        selected.append(
            _resumed_task(matches[0], entry.identifier, entry.resume)
            if entry.resume is not None
            else matches[0]
        )

    return selected


def _resumed_task(task: ResolvedTask, identifier: str, resume: str) -> PreviousTask:
    from inspect_ai.log._file import log_file_info

    fs = filesystem(resume)
    if not fs.exists(resume):
        raise PrerequisiteError(
            f"[bold]ERROR[/bold]: The log '{resume}' selected for resuming task "
            f"'{identifier}' does not exist."
        )

    log_info = log_file_info(fs.info(resume))
    eval_log = read_eval_log_headers([log_info])[0]
    log_identifier = task_identifier(eval_log, None)
    if log_identifier != identifier:
        raise PrerequisiteError(
            f"[bold]ERROR[/bold]: The log '{resume}' selected for resuming task "
            f"'{identifier}' belongs to a different task ('{log_identifier}')."
        )

    eval_log, log_info = _recover_crashed_log(eval_log, log_info)
    return PreviousTask(
        id=eval_log.eval.task_id,
        task=task.task,
        task_args=resolve_task_args(task.task),
        model=task.model,
        model_roles=task.model_roles,
        log=eval_log,
        log_info=log_info,
    )


# filters to determine when we are done


def all_evals_succeeded(logs: list[EvalLog]) -> bool:
    return all([log.status == "success" and not log.invalidated for log in logs])


# filter for determining when we are done
def evals_cancelled(logs: list[EvalLog]) -> bool:
    return any([log.status == "cancelled" for log in logs])


# return last value if we get to the end
def return_last_value(retry_state: RetryCallState) -> list[EvalLog]:
    if retry_state.outcome:
        return cast(list[EvalLog], retry_state.outcome.result())
    else:
        return []


# list all eval logs
# recursive=False and progress are used by inspect_flow
def list_all_eval_logs(
    log_dir: str, recursive: bool = True, progress: ReadEvalLogsProgress | None = None
) -> list[Log]:
    log_files = list_eval_logs(log_dir, recursive=recursive)
    log_headers = read_eval_log_headers(log_files, progress)
    task_identifiers = [task_identifier(log_header, None) for log_header in log_headers]
    return [
        Log(info=info, header=header, task_identifier=task_identifier)
        for info, header, task_identifier in zip(
            log_files, log_headers, task_identifiers
        )
    ]


# get the latest logs (cleaning if requested). returns tuple of successful/unsuccessful
def list_latest_eval_logs(
    all_tasks: list[tuple[str, ResolvedTask]],
    logs: list[Log],
    epochs: int | Epochs | None,
    limit: int | tuple[int, int] | None,
    sample_id: str | int | list[str] | list[int] | list[str | int] | None,
    cleanup_older: bool,
) -> tuple[list[Log], list[Log]]:
    latest_logs = latest_completed_task_eval_logs(
        logs=logs, cleanup_older=cleanup_older
    )

    # resolve epochs
    epochs = resolve_epochs(epochs)

    # figure out which logs still need work
    complete_logs: list[Log] = []
    incomplete_logs: list[Log] = []
    for log in latest_logs:
        if epochs_changed(epochs, log.header.eval.config):
            incomplete_logs.append(log)
        elif log.header.status != "success":
            incomplete_logs.append(log)
        elif log.header.invalidated:
            incomplete_logs.append(log)
        elif not log_samples_complete(
            log, all_tasks, epochs=epochs, limit=limit, sample_id=sample_id
        ):
            incomplete_logs.append(log)
        else:
            complete_logs.append(log)

    return (complete_logs, incomplete_logs)


def log_samples_complete(
    log: Log,
    all_tasks: list[tuple[str, ResolvedTask]],
    epochs: Epochs | None,
    limit: int | tuple[int, int] | None,
    sample_id: str | int | list[str] | list[int] | list[str | int] | None = None,
) -> bool:
    if not log.header.results:
        return False
    id = task_identifier(log.header, None)
    task = next((task for tid, task in all_tasks if tid == id), None)
    if not task:
        # This should not happen since we have already validated prerequisites
        raise PrerequisiteError(
            f"[bold]ERROR[/bold]: Could not find task for log '{log.header.location}'."
        )
    epochs = epochs or resolve_epochs(task.task.epochs or 1)
    if epochs_changed(epochs, log.header.eval.config):
        return False
    epoch_count = epochs.epochs if epochs else 1

    count = samples_selected(task.task.dataset, limit, sample_id, task.task.name)

    if log.header.results.total_samples < count * epoch_count:
        return False
    return True


def shuffle_changed(
    sample_shuffle: bool | int | None,
    config: EvalConfig,
    limit: int | tuple[int, int] | None,
) -> bool:
    # shuffle only matters when there's a limit constraining which samples run
    if limit is None:
        return False
    return sample_shuffle != config.sample_shuffle


def epochs_changed(epochs: Epochs | None, config: EvalConfig) -> bool:
    # user didn't say anything about epochs on subsequent call (not changed)
    if epochs is None:
        return False
    # user did specify epochs and previous call had no epochs config (changed)
    elif config.epochs is None:
        return True
    # number of epochs differs (changed)
    elif epochs.epochs != config.epochs:
        return True

    # compare reducers, treating the unrecorded default (None) and an
    # explicit ["mean"] as equivalent (older logs recorded ["mean"] for
    # the default before it was dropped from eval_config_defaults()).
    def canonical(r: list[str] | None) -> list[str] | None:
        return None if r is None or r == ["mean"] else r

    requested = (
        [reducer_log_name(r) for r in epochs.reducer]
        if epochs.reducer is not None
        else None
    )
    return canonical(requested) != canonical(config.epochs_reducer)


# cleanup logs that aren't the latest
def cleanup_older_eval_logs(log_dir: str, task_ids: set[str]) -> None:
    logs = [
        log
        for log in list_all_eval_logs(log_dir)
        if log.header.eval.task_id in task_ids
    ]
    latest_completed_task_eval_logs(logs=logs, cleanup_older=True)


def latest_completed_task_eval_logs(
    logs: list[Log], cleanup_older: bool = False
) -> list[Log]:
    # collect logs by id
    logs_by_id: dict[str, list[Log]] = {}
    for log in logs:
        id = log.header.eval.task_id
        if id not in logs_by_id:
            logs_by_id[id] = []
        logs_by_id[id].append(log)

    # take the most recent completed log for each id
    latest_completed_logs: list[Log] = []
    for id, id_logs in logs_by_id.items():
        # continue if there are no target logs
        if len(id_logs) == 0:
            continue

        # sort by last file write time
        id_logs.sort(
            key=lambda id_log: id_log[0].mtime if id_log[0].mtime else 0, reverse=True
        )

        # take the most recent
        latest_completed_logs.append(id_logs[0])

        # remove the rest if requested
        # (don't remove 'started' in case its needed for post-mortum debugging)
        if cleanup_older:
            fs = filesystem(id_logs[0][0].name)
            for id_log in id_logs[1:]:
                try:
                    if id_log.header.status != "started":
                        fs.rm(id_log.info.name)
                        # the attempt's EvalState may have memoized this log's
                        # sample summaries; the memo must not outlive the file
                        invalidate_log_sample_summaries(id_log.header.eval.eval_id)
                except Exception as ex:
                    logger.warning(f"Error attempt to remove '{id_log[0].name}': {ex}")

    return latest_completed_logs


# ensure that preconditions for eval_set are met:
#  (1) all tasks have unique identfiers (so we can pair task -> log file)
#  (2) all log files have identifiers that map to tasks (so we know we
#      are running in a log dir created for this eval_set)
def validate_eval_set_prerequisites(
    resolved_tasks: list[ResolvedTask],
    all_logs: list[Log],
    log_dir_allow_dirty: bool,
    eval_set_args: EvalSetArgsInTaskIdentifier,
) -> list[Log]:
    # do all resolved tasks have unique identfiers?
    task_identifiers: Set[str] = set()
    for task in resolved_tasks:
        identifier = task_identifier(task, eval_set_args)
        if identifier in task_identifiers:
            raise PrerequisiteError(
                f"[bold]ERROR[/bold]: The task '{task.task.name}' is not distinct.\n\nTasks in an eval_set must have distinct names OR use the @task decorator and have distinct combinations of name and task args. Solvers passed to tasks should also use the @solver decorator."
            )
        else:
            task_identifiers.add(identifier)

    # do all logs in the log directory correspond to task identifiers?
    if log_dir_allow_dirty:
        return [log for log in all_logs if log.task_identifier in task_identifiers]
    else:
        for log in all_logs:
            if log.task_identifier not in task_identifiers:
                raise PrerequisiteError(
                    f"[bold]ERROR[/bold]: Existing log file '{basename(log.info.name)}' in log_dir is not "
                    + "associated with a task passed to eval_set (you must run eval_set "
                    + "in a fresh log directory). You can use the `--log-dir-allow-dirty` option to allow "
                    + "logs from other eval sets to be present in the log directory."
                )
        return all_logs


# Runtime/transport GenerateConfig knobs that don't affect model outputs and so
# must not affect task identity. Adding a field to GenerateConfig? See
# test_generate_config_fields_classified — it will fail until you classify it.
GENERATE_CONFIG_FIELDS_TO_EXCLUDE = {
    "max_retries",
    "timeout",
    "attempt_timeout",
    "max_connections",
    "adaptive_connections",
    "batch",
    "cache",
    "cache_prompt",
}


def resolve_solver(
    solver: Solver | SolverSpec | Agent | list[Solver] | None,
) -> Solver | None:
    # resolve solver
    if isinstance(solver, list):
        return chain(solver)
    elif is_agent(solver):
        return as_solver(solver)
    elif isinstance(solver, SolverSpec):
        return solver_from_spec(solver)
    else:
        return cast(Solver | None, solver)


# Version of the task_identifier computation. Bump this when the task_identifier
# logic changes, so that persisted identifiers (e.g. in inspect_flow) can be
# recomputed.
TASK_IDENTIFIER_VERSION = 3


def task_identifier(
    task: ResolvedTask | EvalLog,
    eval_set_args: EvalSetArgsInTaskIdentifier | None,
) -> str:
    """Unique identifier for a task within an eval set.

    Identifiers have the form `{task_file}@{task_name}#{args_hash}/{model}/{additional_hash}`
    (the `{task_file}@` prefix is omitted for tasks without a source file).
    The additional hash covers the remaining fields that distinguish tasks
    within an eval set (solver plan, generate config, model args, model roles,
    task version, and execution limits), excluding runtime/transport options
    that don't affect model output (e.g. `max_retries`, `max_connections`).

    The same identifier is computed from a `ResolvedTask` (before running) and
    from the `EvalLog` that running it produces — `eval_set()` uses this to
    pair tasks with their existing log files across retries, and external
    runners can correlate enumerated tasks with logs the same way. The
    computation is versioned by `TASK_IDENTIFIER_VERSION`: persisted
    identifiers must be recomputed when the version changes.

    Args:
        task: Task to identify (a `ResolvedTask` prior to running or an
            `EvalLog` from a previous run).
        eval_set_args: Eval-set level arguments that participate in task
            identity. Required when `task` is a `ResolvedTask`; pass `None`
            for an `EvalLog` (the log already carries the resolved values).

    Returns:
        Identifier string for the task.
    """

    @dataclass
    class AdditionalHashFields:
        model_args: dict[str, Any]
        version: int | str
        message_limit: int | None
        # int for all-token limits (the historical encoding, so existing
        # eval-set identifiers are unchanged); "output:<n>" when only output
        # tokens are metered
        token_limit: int | str | None
        turn_limit: int | None
        time_limit: int | None
        working_limit: int | None
        cost_limit: float | None

    def token_limit_hash_value(
        tokens: int | None, type: str | None
    ) -> int | str | None:
        # bare int for all-token limits (keeps existing identities unchanged);
        # "<type>:<tokens>" for output-metered or formula limits so they hash
        # distinctly (and equal specs stay stable)
        if tokens is not None and type is not None and type != "all":
            return f"{type}:{tokens}"
        return tokens

    if isinstance(task, ResolvedTask):
        assert eval_set_args is not None, (
            "eval_set_args must be provided for ResolvedTask"
        )
        solver = resolve_solver(eval_set_args.solver)

        task_file = task.task_file or ""
        task_name = task.task.name
        task_args = task.task_args
        model = str(task.model)
        model_generate_config = task.model.config
        model_roles = model_roles_to_model_roles_config(task.model_roles) or {}
        plan = resolve_plan(task.task, solver)
        eval_plan = plan_to_eval_plan(
            plan, task.task.config.merge(eval_set_args.config)
        )
        additional_hash_fields = AdditionalHashFields(
            model_args=model_args_for_log(task.model.model_args),
            version=task.task.version,
            message_limit=task.task.message_limit
            if eval_set_args.message_limit is None
            else eval_set_args.message_limit,
            token_limit=token_limit_hash_value(
                task.task.token_limit, task.task.token_limit_type
            )
            if eval_set_args.token_limit is None
            else token_limit_hash_value(*token_limit_fields(eval_set_args.token_limit)),
            turn_limit=task.task.turn_limit
            if eval_set_args.turn_limit is None
            else eval_set_args.turn_limit,
            time_limit=task.task.time_limit
            if eval_set_args.time_limit is None
            else eval_set_args.time_limit,
            working_limit=task.task.working_limit
            if eval_set_args.working_limit is None
            else eval_set_args.working_limit,
            cost_limit=task.task.cost_limit
            if eval_set_args.cost_limit is None
            else eval_set_args.cost_limit,
        )
    else:
        task_file = task.eval.task_file or ""
        task_name = task.eval.task
        task_args = task.eval.task_args_passed
        model = str(task.eval.model)
        model_generate_config = task.eval.model_generate_config
        model_roles = task.eval.model_roles or {}
        eval_plan = task.plan
        additional_hash_fields = AdditionalHashFields(
            model_args=task.eval.model_args,
            version=task.eval.task_version,
            message_limit=task.eval.config.message_limit,
            token_limit=token_limit_hash_value(
                task.eval.config.token_limit, task.eval.config.token_limit_type
            ),
            turn_limit=task.eval.config.turn_limit,
            time_limit=task.eval.config.time_limit,
            working_limit=task.eval.config.working_limit,
            cost_limit=task.eval.config.cost_limit,
        )

    # strip args from eval_plan as we've changed the way this is serialized
    # and we want to be compatible with older logs. this effectively uses
    # 'params_passed' as the basis of comparison as opposed to 'params' which
    # in newer logs includes the fully resolve params
    eval_plan = eval_plan.model_copy(
        update={
            "finish": None,
            "steps": [
                step.model_copy(update={"params": None}) for step in eval_plan.steps
            ],
        }
    )

    # hash for task args
    args_hash = task_args_hash(task_args)

    # hash for eval plan
    additional_hash_input = to_json_safe(
        eval_plan,
        exclude={"config": GENERATE_CONFIG_FIELDS_TO_EXCLUDE},
    )

    # hash for model generate config
    additional_hash_input += to_json_safe(
        model_generate_config,
        exclude=GENERATE_CONFIG_FIELDS_TO_EXCLUDE,
    )

    # hash for model roles
    if len(model_roles):
        # base_url is excluded for symmetry with the primary model (whose
        # base_url is not hashed) and because several providers populate it
        # from env vars during init, which would make the identifier
        # environment-dependent.
        role_exclude: dict[str, Any] = {
            "base_url": True,
            "config": GENERATE_CONFIG_FIELDS_TO_EXCLUDE,
        }
        additional_hash_input += to_json_safe(
            model_roles,
            exclude={
                role: {"__all__": role_exclude}
                if isinstance(value, list)
                else role_exclude
                for role, value in model_roles.items()
            },
        )

    additional_hash_input += to_json_safe(additional_hash_fields)

    additional_hash = hashlib.sha256(additional_hash_input).hexdigest()

    if task_file:
        return f"{task_file}@{task_name}#{args_hash}/{model}/{additional_hash}"
    else:
        return f"{task_name}#{args_hash}/{model}/{additional_hash}"


class ModelList:
    def __init__(self, models: list[Model]) -> None:
        self.models = models

    def __hash__(self) -> int:
        # Hash based on the result of the key function
        return hash(self._key())

    def __eq__(self, other: object) -> bool:
        # Compare based on the result of the key function
        if not isinstance(other, ModelList):
            return False
        return self._key() == other._key()

    def __str__(self) -> str:
        return ",".join([str(model) for model in self.models])

    def _key(self) -> str:
        model_names = [str(model) for model in self.models]
        model_names.sort()
        return ",".join(model_names)


def starting_max_connections(models: list[Model], config: GenerateConfig) -> int:
    # if there is an explicit config use that
    if config.max_connections is not None:
        return config.max_connections

    # else take the smallest model max connections
    else:
        return min(
            models, key=lambda model: model.api.max_connections()
        ).api.max_connections()


def status_msg(msg: str) -> str:
    STATUS_FMT = "blue bold"
    return f"[{STATUS_FMT}]{msg}[/{STATUS_FMT}]"


class EvalSetTask(BaseModel):
    name: str | None = None
    task_id: str
    task_file: str | None = None
    task_args: dict[str, Any]
    model: str
    model_args: dict[str, Any]
    model_roles: dict[str, str] | None = None
    sequence: int


class EvalSet(BaseModel):
    eval_set_id: str
    tasks: list[EvalSetTask]


def to_eval_set_task(
    task: ResolvedTask,
    all_logs: list[Log],
    eval_set_args: EvalSetArgsInTaskIdentifier,
) -> EvalSetTask:
    # resolve core model info
    model_name = str(ModelName(task.model))
    model_args = task.model.model_args

    # resolve model roles to names; a list-valued role is comma-joined (the
    # same syntax --model-role accepts, so the value round-trips through a flag)
    model_roles = (
        {
            k: ",".join(m.name for m in v) if isinstance(v, list) else v.name
            for k, v in task.model_roles.items()
        }
        if task.model_roles
        else None
    )

    # see if there an existing task_id that should be used for this
    eval_set_identifier = task_identifier(task, eval_set_args)
    previous_task_ids = [
        log.info.task_id
        for log in all_logs
        if log.task_identifier == eval_set_identifier
    ]

    # Use the existing task_id, if there is one
    existing_task_id = None
    if len(previous_task_ids) > 0:
        existing_task_id = previous_task_ids[0]

    return EvalSetTask(
        name=task.task.name,
        task_id=existing_task_id or task.id or eval_set_identifier,
        task_file=task.task_file,
        task_args=task.task_args,
        model=model_name,
        model_args=model_args,
        model_roles=model_roles,
        sequence=task.sequence or 0,
    )


def to_eval_set(
    id: str,
    tasks: list[ResolvedTask],
    all_logs: list[Log],
    eval_set_args: EvalSetArgsInTaskIdentifier,
) -> EvalSet:
    return EvalSet(
        eval_set_id=id,
        tasks=[to_eval_set_task(task, all_logs, eval_set_args) for task in tasks],
    )


def write_eval_set_info(
    eval_set_id: str,
    log_dir: str,
    tasks: list[ResolvedTask],
    all_logs: list[Log],
    eval_set_args: EvalSetArgsInTaskIdentifier,
    fs_options: dict[str, Any] = {},
) -> None:
    # resolve log dir to full path
    fs = filesystem(log_dir)
    log_dir = _resolve_log_dir(fs, log_dir)

    # get info
    eval_set_info = to_eval_set(eval_set_id, tasks, all_logs, eval_set_args)

    # form target path and write
    manifest = f"{log_dir}{fs.sep}eval-set.json"
    eval_set_json = to_json_safe(eval_set_info)
    with file(manifest, mode="wb", fs_options=fs_options) as f:
        f.write(eval_set_json)


def read_eval_set_info(log_dir: str, fs_options: dict[str, Any] = {}) -> EvalSet | None:
    # resolve log dir to full path
    fs = filesystem(log_dir)
    log_dir = _resolve_log_dir(fs, log_dir)

    # form target path and read
    manifest = f"{log_dir}{fs.sep}eval-set.json"
    exists = _manifest_exists(fs, manifest)

    if not exists:
        return None

    eval_set_json = _read_manifest_bytes(manifest, fs_options)
    if eval_set_json is None:
        return None

    # parse and return
    return EvalSet.model_validate_json(eval_set_json)


def _resolve_log_dir(fs: FileSystem, log_dir: str) -> str:
    return call_with_azure_auth_fallback(
        lambda: fs.info(log_dir).name, fallback_return_value=log_dir
    )


def _read_manifest_bytes(manifest: str, fs_options: dict[str, Any]) -> bytes | None:
    def _read_manifest_bytes_strict() -> bytes:
        with file(manifest, mode="rb", fs_options=fs_options) as f:
            return f.read()

    return call_with_azure_auth_fallback(
        _read_manifest_bytes_strict, fallback_return_value=None
    )


def _manifest_exists(fs: FileSystem, path: str) -> bool:
    return call_with_azure_auth_fallback(
        lambda: fs.exists(path), fallback_return_value=False
    )
