import ast
import contextlib
import copy
import inspect
import os
from dataclasses import replace
from logging import getLogger
from pathlib import Path
from typing import Any, Callable, Tuple, cast

from shortuuid import uuid

from inspect_ai._eval.task.images import InputMediaPolicy
from inspect_ai._eval.task.resolved import ResolvedTask
from inspect_ai._eval.task.util import split_spec, task_file, task_run_dir
from inspect_ai._util.decorator import parse_decorators
from inspect_ai._util.error import PrerequisiteError
from inspect_ai._util.logger import warn_once
from inspect_ai._util.module import load_module
from inspect_ai._util.path import chdir_python, cwd_relative_path
from inspect_ai._util.registry import (
    RegistryInfo,
    create_registry_object,
    is_registry_object,
    registry_info,
    registry_lookup,
    registry_params,
)
from inspect_ai.agent._agent import Agent
from inspect_ai.agent._as_solver import as_solver
from inspect_ai.model import Model
from inspect_ai.scorer._metric import Metric, MetricSpec, metric_create
from inspect_ai.scorer._scorer import Scorer, ScorerSpec, scorer_create
from inspect_ai.solver._bridge import bridge
from inspect_ai.solver._constants import SOLVER_ALL_PARAMS_ATTR
from inspect_ai.solver._solver import Solver, SolverSpec
from inspect_ai.util import SandboxEnvironmentSpec, SandboxEnvironmentType
from inspect_ai.util._checkpoint._layout import (
    eval_checkpoints_dir_from_config,
)
from inspect_ai.util._checkpoint.config import CheckpointConfig
from inspect_ai.util._sandbox.compose import (
    is_docker_compatible_config,
    is_docker_compatible_sandbox_type,
)
from inspect_ai.util._sandbox.environment import (
    resolve_sandbox_environment,
)
from inspect_ai.util._sandbox.registry import registry_find_sandboxenv

from .list import task_files
from .registry import task_create, task_source_create
from .task import PreviousTask, Task, TaskInfo
from .task.constants import TASK_FILE_ATTR, TASK_RUN_DIR_ATTR
from .task.hf import task_create_from_hf
from .task.run import eval_log_sample_source
from .task.task_source import TaskSource
from .task.tasks import Tasks

logger = getLogger(__name__)


def _merge_model_roles(
    *roles_dicts: dict[str, Model | list[Model]] | None,
) -> dict[str, Model | list[Model]] | None:
    """Merge model_roles dicts with later dicts taking priority."""
    merged: dict[str, Model | list[Model]] = {}
    for d in roles_dicts:
        if d:
            merged.update(d)
    return merged or None


def resolve_tasks(
    tasks: Tasks,
    task_args: dict[str, Any],
    model: Model,
    model_roles: dict[str, Model | list[Model]] | None,
    sandbox: SandboxEnvironmentType | None,
    sample_shuffle: bool | int | None,
    eval_checkpoint: CheckpointConfig | None = None,
    warn_unconsumed_task_args: bool = False,
    input_media_policy: InputMediaPolicy = "inline_only",
) -> list[ResolvedTask]:
    # A TaskSource drives a run dynamically and is handled by eval() (which
    # resolves its initial_tasks() and pulls next_tasks()); it isn't a concrete,
    # resumable task list, so it can't be used here (eval_set / eval_retry /
    # score). Detect both a passed instance and a spec/name that refers to one
    # so the CLI (`inspect eval-set file.py@source`) gets the same clear error
    # rather than a confusing "task not found".
    if refers_to_task_source(tasks):
        raise ValueError(
            "A TaskSource is only supported by `eval()` / `inspect eval`. "
            "eval_set, eval_retry, and score require a fixed, resumable set of "
            "tasks, but a TaskSource generates tasks dynamically (via "
            "next_tasks() / sample_complete) that have no stable identity to "
            "track, retry, or resume. Run a TaskSource-driven eval with "
            "`inspect eval` instead."
        )

    def as_resolved_tasks(tasks: list[Task]) -> list[ResolvedTask]:
        # shuffle data in tasks if requested
        if sample_shuffle:
            for task in tasks:
                if not task.dataset.shuffled:
                    task.dataset.shuffle(
                        None if sample_shuffle is True else sample_shuffle
                    )

        return [
            ResolvedTask(
                id=uuid(),
                task=task,
                task_args=resolve_task_args(task),
                task_file=task_file(task, relative=True),
                model=task.model or model,
                model_roles=_merge_model_roles(task.model_roles, model_roles),
                sandbox=resolve_task_sandbox(task, sandbox),
                checkpoint=task.checkpoint,
                sequence=sequence,
                input_media_policy=input_media_policy,
            )
            for sequence, task in enumerate(tasks)
        ]

    # an empty list is equivalent to None (load tasks from cwd) — but it
    # must short-circuit before any tasks[0] access below
    if isinstance(tasks, list) and len(tasks) == 0:
        return as_resolved_tasks(load_tasks(None, task_args))

    # reflect resolved tasks right back
    if isinstance(tasks, ResolvedTask):
        return [tasks]
    if isinstance(tasks, PreviousTask):
        tasks = [tasks]
    if isinstance(tasks, list) and isinstance(tasks[0], (ResolvedTask, PreviousTask)):
        return resolve_previous_tasks(
            [t for t in tasks if isinstance(t, (ResolvedTask, PreviousTask))],
            sample_shuffle=sample_shuffle,
            model=model,
            model_roles=model_roles,
            eval_checkpoint=eval_checkpoint,
        )

    # simple cases of passing us Task objects -- task_args are never applied
    # to Task instances (their args come from the instance's own construction
    # params), so warn if the caller passed args that will be silently ignored
    if isinstance(tasks, Task) or (
        isinstance(tasks, list) and isinstance(tasks[0], Task)
    ):
        if warn_unconsumed_task_args and task_args:
            logger.warning(
                f"task_args {sorted(task_args.keys())} will not be applied: "
                "they are ignored for Task instances passed directly. Pass "
                "them to your @task function when creating the task instead."
            )
        task_list = (
            [tasks]
            if isinstance(tasks, Task)
            else [t for t in tasks if isinstance(t, Task)]
        )
        return as_resolved_tasks(task_list)

    # convert TaskInfo to str
    if isinstance(tasks, TaskInfo):
        tasks = [tasks]
    if isinstance(tasks, list) and isinstance(tasks[0], TaskInfo):
        tasks = [
            f"{task.file}@{task.name}" for task in tasks if isinstance(task, TaskInfo)
        ]

    # handle functions that return tasks (we get their registry name)
    if isinstance(tasks, list) and callable(tasks[0]):
        tasks = [registry_info(task).name for task in tasks]
    elif callable(tasks):
        tasks = [registry_info(tasks).name]

    # str to list[str]
    if isinstance(tasks, str):
        tasks = [tasks]

    # done! let's load the tasks
    return as_resolved_tasks(load_tasks(cast(list[str] | None, tasks), task_args))


def refers_to_task_source(tasks: Tasks) -> bool:
    """Whether `tasks` is, or refers to, a `TaskSource` — without creating it.

    Mirrors :func:`resolve_task_source`'s detection (instance, `@task_source`
    function, registered name, or `file.py@name` spec) but stops short of
    instantiating the source. Used to reject a `TaskSource` where it isn't
    supported (eval_set / eval_retry / score) without paying its (potentially
    expensive) construction just to raise an error.
    """
    if isinstance(tasks, list):
        if len(tasks) != 1:
            return False
        tasks = tasks[0]
    if isinstance(tasks, TaskSource):
        return True
    if callable(tasks):
        return is_registry_object(tasks) and registry_info(tasks).type == "task_source"
    if isinstance(tasks, str):
        if registry_lookup("task_source", tasks) is not None:
            return True
        file, name = split_spec(tasks)
        if name is not None:
            task_path = Path(file)
            if task_path.suffix == ".py" and task_path.exists():
                try:
                    has_source = code_has_decorator(
                        task_path.read_text(encoding="utf-8"), "task_source"
                    )
                except OSError:
                    return False
                if has_source:
                    # load the module so its `@task_source` registers, then
                    # confirm `name` is the source (not a `@task` in the same file)
                    load_file_tasks(task_path.absolute())
                    return registry_lookup("task_source", name) is not None
    return False


def resolve_task_source(tasks: Tasks, task_args: dict[str, Any]) -> TaskSource | None:
    """Resolve `tasks` to a `TaskSource` if it is (or names) one, else `None`.

    Handles the forms `eval()` accepts for a source: a `TaskSource` instance, a
    `@task_source`-decorated function, a registered source name, or a
    `file.py@name` spec naming a `@task_source`. Anything else returns `None` so
    normal task resolution proceeds. The single-element list form is accepted
    because the CLI passes specs as a list.
    """
    if isinstance(tasks, list):
        if len(tasks) != 1:
            return None
        tasks = tasks[0]

    # already a TaskSource instance
    if isinstance(tasks, TaskSource):
        return tasks

    # a @task_source-decorated function (registered under type "task_source")
    if callable(tasks):
        if is_registry_object(tasks) and registry_info(tasks).type == "task_source":
            return task_source_create(registry_info(tasks).name, **task_args)
        return None

    # a registered source name, or a file.py@name spec naming a source
    if isinstance(tasks, str):
        if registry_lookup("task_source", tasks) is not None:
            return task_source_create(tasks, **task_args)
        file, name = split_spec(tasks)
        if name is not None:
            return _load_task_source_from_file(file, name, task_args)

    return None


def _load_task_source_from_file(
    file: str, name: str, task_args: dict[str, Any]
) -> TaskSource | None:
    # only probe local .py files that actually define a @task_source (a cheap
    # text check so a task-only file isn't loaded here and then again as tasks)
    task_path = Path(file)
    if task_path.suffix != ".py" or not task_path.exists():
        return None
    try:
        if not code_has_decorator(task_path.read_text(encoding="utf-8"), "task_source"):
            return None
    except OSError:
        return None

    # load the file's module (registers its decorators), then create the source
    # — mirrors create_tasks' load_file_tasks + create_file_tasks for tasks
    load_file_tasks(task_path.absolute())
    if registry_lookup("task_source", name) is None:
        return None
    source = task_source_create(name, **task_args)
    setattr(source, TASK_FILE_ATTR, task_path.as_posix())
    setattr(source, TASK_RUN_DIR_ATTR, task_path.parent.resolve().as_posix())
    return source


def resolve_previous_tasks(
    tasks: list[ResolvedTask] | list[PreviousTask] | list[ResolvedTask | PreviousTask],
    sample_shuffle: bool | int | None,
    model: Model,
    model_roles: dict[str, Model | list[Model]] | None,
    eval_checkpoint: CheckpointConfig | None = None,
) -> list[ResolvedTask]:
    result = []
    for sequence, task in enumerate(tasks):
        if isinstance(task, ResolvedTask):
            sequenced_task = replace(task, sequence=sequence)
            result.append(sequenced_task)
        else:
            # for previous tasks, prefer recreating from the registry (so we have
            # a fresh instance) but also allow recycling of task instances for
            # fully dynamic tasks
            previous_task = task
            if isinstance(previous_task.task, Task):
                loaded_task_args = previous_task.task_args
                loaded_task = previous_task.task
            else:
                loaded_task_args = previous_task.task_args
                loaded_task = load_tasks([previous_task.task], loaded_task_args)[0]
            if sample_shuffle is not None:
                if not loaded_task.dataset.shuffled:
                    loaded_task.dataset.shuffle(
                        None if sample_shuffle is True else sample_shuffle
                    )
            result.append(
                resolve_previous_task(
                    loaded_task,
                    loaded_task_args,
                    model,
                    model_roles,
                    previous_task,
                    sequence,
                    eval_checkpoint,
                )
            )
    return result


def resolve_previous_task(
    loaded_task: Task,
    loaded_task_args: dict[str, Any],
    model: Model,
    model_roles: dict[str, Model | list[Model]] | None,
    previous_task: PreviousTask,
    sequence: int,
    eval_checkpoint: CheckpointConfig | None = None,
) -> ResolvedTask:
    # carry token usage forward from the prior log so cumulative totals stay
    # accurate across retries. Deep-copy so the prior log is never mutated.
    prior_stats = previous_task.log.stats
    initial_model_usage = (
        copy.deepcopy(prior_stats.model_usage) if prior_stats.model_usage else None
    )
    initial_role_usage = (
        copy.deepcopy(prior_stats.role_usage) if prior_stats.role_usage else None
    )

    return ResolvedTask(
        task=loaded_task,
        task_args=loaded_task_args,
        task_file=previous_task.log.eval.task_file,
        model=previous_task.model or loaded_task.model or model,
        model_roles=_merge_model_roles(
            model_roles, loaded_task.model_roles, previous_task.model_roles
        ),
        sandbox=resolve_task_file_sandbox(
            previous_task.log.eval.task_file, previous_task.log.eval.sandbox
        ),
        checkpoint=loaded_task.checkpoint,
        sequence=sequence,
        id=previous_task.id,
        sample_source=eval_log_sample_source(
            previous_task.log,
            previous_task.log_info,
            loaded_task.dataset,
            eval_checkpoints_dir_from_config(
                previous_task.log_info.name
                if previous_task.log_info is not None
                else previous_task.log.location,
                loaded_task.checkpoint,
                eval_checkpoint,
            ),
        ),
        initial_model_usage=initial_model_usage,
        initial_role_usage=initial_role_usage,
        input_media_policy="trusted_pre_run",
    )


def resolve_task_args(task: Task) -> dict[str, Any]:
    # was the task instantiated via the registry or a decorator?
    # if so then we can get the task_args from the registry.
    try:
        task_args = dict(registry_params(task))
        return task_args

    # if it wasn't instantiated via the registry or a decorator
    # then it will not be in the registy and not have formal
    # task args (as it was simply synthesized via ad-hoc code)
    except ValueError:
        return {}


def resolve_task_sandbox(
    task: Task, sandbox: SandboxEnvironmentType | None
) -> SandboxEnvironmentSpec | None:
    # do the resolution
    resolved_sandbox = resolve_sandbox_environment(sandbox) or task.sandbox

    # if we have a sandbox with no config, see if there are implcit
    # config files available for the provider
    if resolved_sandbox is not None:
        # look for default
        if resolved_sandbox.config is None:
            # get config files for this type
            sandboxenv_type = registry_find_sandboxenv(resolved_sandbox.type)
            config_files_fn = cast(
                Callable[..., list[str]], getattr(sandboxenv_type, "config_files")
            )
            config_files = config_files_fn()

            # probe for them in task src dir
            src_dir = task_run_dir(task)
            for config_file in config_files:
                config_file_path = os.path.join(src_dir, config_file)
                if os.path.isfile(config_file_path):
                    resolved_sandbox = SandboxEnvironmentSpec(
                        resolved_sandbox.type, config_file
                    )
                    break

            # if we found an override without a config then we may still
            # want to forward the task config if it's docker config ->
            # docker compatible sandbox
            if resolved_sandbox.config is None and task.sandbox is not None:
                if is_docker_compatible_config(
                    task.sandbox.config
                ) and is_docker_compatible_sandbox_type(resolved_sandbox.type):
                    resolved_sandbox = SandboxEnvironmentSpec(
                        resolved_sandbox.type, task.sandbox.config
                    )
                elif is_docker_compatible_config(task.sandbox.config):
                    warn_once(
                        logger,
                        f"Task '{task.name}' declares sandbox '{task.sandbox.type}' "
                        "with a Dockerfile/compose.yaml configuration, but the "
                        f"'{resolved_sandbox.type}' sandbox specified for the eval "
                        "does not support that configuration. The task's compose "
                        "services, packages, and tools will not be available in "
                        f"the '{resolved_sandbox.type}' sandbox.",
                    )

        # resolve relative paths
        if isinstance(resolved_sandbox.config, str):
            file_path = Path(resolved_sandbox.config)
            if not file_path.is_absolute():
                file_path = Path(task_run_dir(task)) / file_path
                resolved_sandbox = SandboxEnvironmentSpec(
                    resolved_sandbox.type, file_path.as_posix()
                )

    # return resolved sandbox
    return resolved_sandbox


def resolve_task_file_sandbox(
    task_file: str | None, sandbox: SandboxEnvironmentSpec | None
) -> SandboxEnvironmentSpec | None:
    if sandbox is None or not isinstance(sandbox.config, str):
        return sandbox

    if task_file is None:
        return sandbox

    file_path = Path(sandbox.config)
    if file_path.is_absolute():
        return sandbox

    # resolve relative sandbox config paths from logged task file location
    src_dir = Path(task_file).parent
    file_path = (src_dir / file_path).resolve()
    return SandboxEnvironmentSpec(sandbox.type, file_path.as_posix())


def load_tasks(
    task_specs: list[str] | None, task_args: dict[str, Any] = {}
) -> list[Task]:
    """Load one more more tasks (if no tasks are specified, load from the current working directory"""
    # load tasks
    return [
        spec
        for task_spec in (task_specs if task_specs else [Path.cwd().as_posix()])
        for spec in load_task_spec(task_spec, task_args)
    ]


def load_task_spec(task_spec: str, task_args: dict[str, Any] = {}) -> list[Task]:
    # task in a python package
    if registry_lookup("task", task_spec) is not None:
        # create the task from a python package
        return [task_create(task_spec, **task_args)]
    elif task_spec.startswith("hf/"):
        # load task from huggingface
        return task_create_from_hf(task_spec, **task_args)
    else:
        # load tasks from glob
        return create_tasks([task_spec], task_args)


def create_tasks(
    globs: list[str],
    task_args: dict[str, Any] = {},
    root_dir: Path | None = None,
) -> list[Task]:
    tasks: list[Task] = []

    root_dir = root_dir if root_dir is not None else Path.cwd()

    for glob in globs:
        # sometimes globs are direct references to files
        # that include an @ index. for this case directly
        # create the task (we also need to load the file
        # so the task is registered before we create it)
        spec_split = split_spec(glob)
        if spec_split[1] is not None:
            task_path = Path(spec_split[0])
            load_file_tasks(task_path.absolute())
            tasks.extend(create_file_tasks(task_path, [spec_split[1]], task_args))
        else:
            # if the glob is the root dir then set it to empty (will result in
            # enumeration of the root dir)
            target = [] if Path(glob).resolve() == root_dir.resolve() else [glob]
            files = task_files(target, root_dir)
            files = sorted(files, key=lambda f: f.as_posix())
            for file in files:
                tasks.extend(create_file_tasks(file, None, task_args))
    return tasks


def load_file_tasks(file: Path) -> None:
    with chdir_python(file.parent.as_posix()):
        _load_task_specs(file)


def create_file_tasks(
    file: Path,
    task_specs: list[str] | list[RegistryInfo] | None = None,
    task_args: dict[str, Any] = {},
) -> list[Task]:
    run_dir = file.parent.resolve().as_posix()
    with chdir_python(file.parent.as_posix()):
        # if we don't have task specs then go get them (also,
        # turn them into plain names)
        if task_specs is None:
            task_specs = _load_task_specs(file)
        # convert to plain names
        task_specs = [
            spec if isinstance(spec, str) else spec.name for spec in task_specs
        ]

        tasks: list[Task] = []
        for task_spec in task_specs:
            # create the task from the loaded source file and
            # note that it was loaded from this directory
            # (will be used later to ensure it runs in the directory)
            task = task_create(task_spec, **task_args)
            setattr(task, TASK_FILE_ATTR, file.as_posix())
            setattr(task, TASK_RUN_DIR_ATTR, run_dir)
            tasks.append(task)

            # warn that chdir has been removed
            if "chdir" in task.attribs:
                warn_once(
                    logger,
                    "The 'chdir' task attribute is no longer supported "
                    + "(you should write your tasks to not depend on their runtime working directory)",
                )

        return tasks


# don't call this function directly, rather, call one of the
# higher level loading functions above (those functions
# change the working directory, this one does not b/c it is
# intended as a helper function)
def _load_task_specs(task_path: Path) -> list[str]:
    # load the module (also load files that only define task sources, so a
    # `@task_source` is registered/discoverable just like a `@task`)
    module = load_module(task_path, code_has_task_or_source)
    if module:
        # find the tasks in the module
        tasks = parse_decorators(task_path, "task")
        return [task[0] for task in tasks]
    else:
        return []


def code_has_decorator(code: str, decorator: str) -> bool:
    try:
        tree = ast.parse(code)
        for node in ast.iter_child_nodes(tree):
            if isinstance(node, ast.FunctionDef):
                for dec in node.decorator_list:
                    if isinstance(dec, ast.Name):
                        if str(dec.id) == decorator:
                            return True
                    elif (
                        isinstance(dec, ast.Call)
                        and isinstance(dec.func, ast.Name)
                        and str(dec.func.id) == decorator
                    ):
                        return True
    except SyntaxError:
        pass

    return False


def code_has_task(code: str) -> bool:
    return code_has_decorator(code, "task")


def code_has_task_or_source(code: str) -> bool:
    return code_has_decorator(code, "task") or code_has_decorator(code, "task_source")


def as_solver_spec(solver: Solver) -> SolverSpec:
    if not is_registry_object(solver):
        raise PrerequisiteError(
            f"The solver {getattr(solver, '__name__', '<unknown>')} was not created by a function decorated with @solver so cannot be recorded."
        )
    return SolverSpec(
        solver=registry_info(solver).name,
        args=getattr(solver, SOLVER_ALL_PARAMS_ATTR, {}),
        args_passed=registry_params(solver),
    )


def solver_from_spec(spec: SolverSpec) -> Solver:
    # resolve @ reference
    solver_file, solver_name = parse_spec_str(spec.solver)

    # switch contexts if we are loading from a file
    create_cm = (
        chdir_python(solver_file.parent.as_posix())
        if solver_file is not None
        else contextlib.nullcontext()
    )

    # pretty solver name for error messages
    pretty_solver_file = (
        cwd_relative_path(solver_file.as_posix()) if solver_file else None
    )

    with create_cm:
        # if there is no solver file then just create from the registry by name
        if solver_file is None:
            if solver_name is None:
                raise ValueError(f"Unable to resolve solver name from {spec.solver}")
            elif registry_lookup("solver", solver_name) is not None:
                # create via create_registry_object (args as a dict) so a solver
                # factory with its own `name` parameter doesn't collide with
                # registry_create's positional `name` argument on replay.
                return cast(
                    Solver,
                    create_registry_object("solver", solver_name, spec.args_passed),
                )
            elif registry_lookup("agent", solver_name) is not None:
                # create via create_registry_object (args as a dict) so an agent
                # factory with its own `name` parameter doesn't collide with
                # registry_create's positional `name` argument.
                agent = cast(
                    Agent,
                    create_registry_object("agent", solver_name, spec.args_passed),
                )
                return as_solver(agent)
            else:
                raise ValueError(
                    f"Unknown solver {solver_name} (not registered as a @solver or @agent)"
                )

        # we do have a solver file
        else:
            # load the module and parse decorators
            solver_module = load_module(solver_file)
            solver_decorators = parse_decorators(solver_file, "solver")
            agent_decorators = parse_decorators(solver_file, "agent")

            # if there is no solver_name see if we can discover it
            if solver_name is None:
                if len(solver_decorators) == 1:
                    # decorator based solver
                    solver_name = solver_decorators[0][0]
                elif len(agent_decorators) == 1:
                    # decorator based agent
                    solver_name = agent_decorators[0][0]
                elif len(solver_decorators) == 0 and len(agent_decorators) == 0:
                    # see if we can find an agent based solver
                    functions = [
                        function
                        for function in inspect.getmembers(
                            solver_module, inspect.isfunction
                        )
                        if function[1].__module__ == solver_module.__name__
                    ]
                    agent_functions = [
                        function
                        for function in functions
                        if "agent" in function[0] and not function[0].startswith("_")
                    ]
                    if len(agent_functions) == 1:
                        # agent based solver
                        solver_name = agent_functions[0][0]

                    elif len(agent_functions) == 0:
                        raise PrerequisiteError(
                            f"The source file {pretty_solver_file} does not contain any @solver, @agent or bridged agent functions."
                        )
                    else:
                        raise PrerequisiteError(
                            f"The source file {pretty_solver_file} has more than one bridged agent function (qualify which agent using e.g. '{solver_file.name}@agent_fn')"
                        )
                elif len(solver_decorators) > 1:
                    raise PrerequisiteError(
                        f"The source file {pretty_solver_file} has more than one @solver function (qualify which solver using e.g. '{solver_file.name}@solver_fn')"
                    )
                else:
                    raise PrerequisiteError(
                        f"The source file {pretty_solver_file} has more than one @agent function (qualify which agent using e.g. '{solver_file.name}@agent_fn')"
                    )

            # create decorator based solvers using the registry
            if any(solver[0] == solver_name for solver in solver_decorators):
                # create via create_registry_object (args as a dict) so a solver
                # factory with its own `name` parameter doesn't collide with
                # registry_create's positional `name` argument on replay.
                return cast(
                    Solver,
                    create_registry_object("solver", solver_name, spec.args_passed),
                )

            # create decorator based agents using the registry
            elif any(agent[0] == solver_name for agent in agent_decorators):
                agent = cast(
                    Agent,
                    create_registry_object("agent", solver_name, spec.args_passed),
                )
                return as_solver(agent)

            # create bridge based solvers by calling the function and wrapping it in bridge()
            else:
                agent_fn = getattr(solver_module, solver_name, None)
                if inspect.isfunction(agent_fn):
                    return bridge(agent_fn(**spec.args_passed))
                elif agent_fn is not None:
                    raise PrerequisiteError(
                        f"The object {solver_name} in file {pretty_solver_file} is not a Python function."
                    )
                else:
                    raise PrerequisiteError(
                        f"The function {solver_name} was not found in file {pretty_solver_file}."
                    )


def scorer_from_spec(spec: ScorerSpec, task_path: Path | None, **kwargs: Any) -> Scorer:
    """
    Load a scorer

    Args:
        spec: The scorer spec
        task_path: An optional path to the task file
        **kwargs: Additional keyword arguments passed to the scorer initialization

    Returns:
        Scorer: the loaded scorer

    Raises:
        PrerequisiteError: If the scorer cannot be found, loaded, or lacks required type annotations
    """
    # resolve @ reference
    scorer_file, scorer_name = parse_spec_str(spec.scorer)

    # switch contexts if we are loading from a file
    create_cm = (
        chdir_python(scorer_file.parent.as_posix())
        if scorer_file is not None
        else contextlib.nullcontext()
    )

    # pretty solver name for error messages
    pretty_scorer_file = (
        cwd_relative_path(scorer_file.as_posix()) if scorer_file else None
    )

    # See if the scorer doesn't have type annotations. Currently the registry will not load
    # the function without type annotations.
    # TODO: We could consider calling this ourselves if we're certain it is what we're looking for
    def validate_scorer(scorer_fn: Scorer, scorer_name: str, scorer_path: str) -> None:
        signature = inspect.signature(scorer_fn)
        if signature.return_annotation is inspect.Signature.empty:
            raise PrerequisiteError(
                f"The function '{scorer_name}' in the file '{scorer_path}' requires a return type annotation. Please add a return type annotation to use this function with scoring."
            )

    def create_scorer(scorer_name: str, **kwargs: Any) -> Scorer:
        # handle scorers and scanners
        if registry_lookup("scorer", scorer_name) is not None:
            return scorer_create(scorer_name, **kwargs)
        elif registry_lookup("scanner", scorer_name) is not None:
            from inspect_scout import Scanner, Transcript, as_scorer

            scanner = create_registry_object("scanner", scorer_name, kwargs)
            return as_scorer(cast(Scanner[Transcript], scanner))
        else:
            raise ValueError(
                f"Unknown scorer {scorer_name} (not registered as a @scorrer or @scanner)"
            )

    with create_cm:
        # is there a scorer file being provided? if not, load from registry
        if scorer_file is None:
            if scorer_name is None:
                raise ValueError(f"Unable to resolve scorer name from {spec.scorer}")

            try:
                return scorer_create(scorer_name, **kwargs)
            except ValueError:
                # We need a valid path to a scorer file to try to load the scorer from there
                if not task_path:
                    raise PrerequisiteError(
                        f"The scorer '{scorer_name}' couldn't be loaded. Please provide a path to the file containing the scorer using the '--scorer' parameter"
                    )

                task_pretty_path = task_path.as_posix()
                if not task_path.exists():
                    raise PrerequisiteError(
                        f"The scorer `{scorer_name}` couldn't be loaded. The file '{task_pretty_path}' was not found. Please provide a path to the file containing the scorer using the '--scorer' parameter"
                    )

                # We have the path to a file, so load that and try again
                try:
                    load_module(task_path)
                    scorer_fn = create_scorer(scorer_name, **kwargs)
                    validate_scorer(scorer_fn, scorer_name, task_pretty_path)
                    return scorer_fn
                except ValueError:
                    # we still couldn't load this, request the user provide a path
                    raise PrerequisiteError(
                        f"The scorer '{scorer_name}' in the file '{task_pretty_path}' couldn't be loaded. Please provide a path to the file containing the scorer using the '--scorer' parameter."
                    )
                except ModuleNotFoundError:
                    # we still couldn't load this, request the user provide a path
                    raise PrerequisiteError(
                        f"The scorer '{scorer_name}' in the file '{task_pretty_path}' couldn't be loaded. Please provide a path to the file containing the scorer using the '--scorer' parameter."
                    )

        # solver is a path, so load it that way
        else:
            load_module(scorer_file)
            scorer_decorators = parse_decorators(scorer_file, "scorer")
            scanner_decorators = parse_decorators(scorer_file, "scanner")

            # if there is no scorer_name see if we can discover it
            if scorer_name is None:
                if len(scorer_decorators) == 1:
                    scorer_name = scorer_decorators[0][0]
                elif len(scanner_decorators) == 1:
                    scorer_name = scanner_decorators[0][0]
                elif len(scorer_decorators) == 0 and len(scanner_decorators) == 0:
                    raise PrerequisiteError(
                        f"The source file {pretty_scorer_file} does not contain any @scorer or @scanner functions."
                    )
                else:
                    raise PrerequisiteError(
                        f"The source file {pretty_scorer_file} has more than one @scorer or @scanner function (qualify which scorer using e.g. '{scorer_file.name}y@scorer_fn')"
                    )

            # create decorator based solvers using the registry
            if any(
                solver[0] == scorer_name
                for solver in (scorer_decorators + scanner_decorators)
            ):
                scorer_fn = create_scorer(scorer_name, **kwargs)
                validate_scorer(scorer_fn, scorer_name, pretty_scorer_file or "")
                return scorer_fn
            else:
                raise PrerequisiteError(
                    f"The function {scorer_name} was not found in file {pretty_scorer_file}."
                )


def metric_from_spec(spec: MetricSpec, **kwargs: Any) -> Metric:
    """
    Load a metric

    Args:
        spec: The metric spec
        **kwargs: Additional keyword arguments passed to the metric initialization

    Returns:
        Metric: the loaded metric

    Raises:
        PrerequisiteError: If the metric cannot be found or loaded
    """
    # resolve @ reference
    metric_file, metric_name = parse_spec_str(spec.metric)

    # switch contexts if we are loading from a file
    create_cm = (
        chdir_python(metric_file.parent.as_posix())
        if metric_file is not None
        else contextlib.nullcontext()
    )

    # pretty metric name for error messages
    pretty_metric_file = (
        cwd_relative_path(metric_file.as_posix()) if metric_file else None
    )

    with create_cm:
        # is there a metric file being provided? if not, load from registry
        if metric_file is None:
            if metric_name is None:
                raise ValueError(f"Unable to resolve metric name from {spec.metric}")

            return metric_create(metric_name, **kwargs)

        # metric is a path, so load it that way
        else:
            load_module(metric_file)
            metric_decorators = parse_decorators(metric_file, "metric")

            # if there is no metric_name see if we can discover it
            if metric_name is None:
                if len(metric_decorators) == 1:
                    metric_name = metric_decorators[0][0]
                elif len(metric_decorators) == 0:
                    raise PrerequisiteError(
                        f"The source file {pretty_metric_file} does not contain any @metric functions."
                    )
                else:
                    raise PrerequisiteError(
                        f"The source file {pretty_metric_file} has more than one @metric function (qualify which metric using e.g. '{metric_file.name}@metric_fn')"
                    )

            # create decorator based metrics using the registry
            if any(metric[0] == metric_name for metric in metric_decorators):
                return metric_create(metric_name, **kwargs)
            else:
                raise PrerequisiteError(
                    f"The function {metric_name} was not found in file {pretty_metric_file}."
                )


def parse_spec_str(spec_str: str) -> Tuple[Path | None, str | None]:
    spec_split = split_spec(spec_str)
    if spec_split[1] is not None:
        file: Path | None = Path(spec_split[0]).resolve()
        name: str | None = spec_split[1]
    elif Path(spec_split[0]).exists():
        file = Path(spec_split[0]).resolve()
        name = None
    else:
        file = None
        name = spec_split[0]
    return file, name
