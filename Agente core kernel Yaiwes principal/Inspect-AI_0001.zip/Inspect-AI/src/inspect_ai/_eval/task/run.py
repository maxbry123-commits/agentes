import contextlib
import sys
import time
from contextvars import Token
from copy import copy, deepcopy
from dataclasses import dataclass, field
from datetime import datetime, timezone
from logging import getLogger
from pathlib import PurePath
from typing import Any, Awaitable, Callable, Literal, NamedTuple, Protocol, TypeAlias

import anyio
from anyio.abc import TaskGroup
from typing_extensions import Unpack

from inspect_ai._control.eval_state import (
    finalize_eval,
    record_sample_cancelled,
    record_sample_completed,
    record_sample_errored,
    record_samples_added,
    register_eval,
    set_sample_requeue,
    set_task_scoring,
    stable_task_id_for_eval,
)
from inspect_ai._control.pause import PauseGatedSemaphore, dispatch_model_name
from inspect_ai._display import (
    TaskCancelled,
    TaskError,
    TaskProfile,
    TaskSuccess,
    display,
)
from inspect_ai._display.core.display import TaskCancel, TaskDisplayMetric
from inspect_ai._eval.task.scan import Scanners
from inspect_ai._util._async import Wake, aexit_shielded_when
from inspect_ai._util.async_zip import AsyncZipReader
from inspect_ai._util.asyncfiles import get_async_filesystem
from inspect_ai._util.constants import (
    DEFAULT_EPOCHS,
    DEFAULT_MAX_CONNECTIONS,
    DEFAULT_MAX_CONNECTIONS_BATCH,
)
from inspect_ai._util.dateutil import iso_now
from inspect_ai._util.error import (
    exception_message,
    is_cancellation_message,
)
from inspect_ai._util.exception import TerminateSampleError, TerminateTaskError
from inspect_ai._util.json import to_json_str_safe
from inspect_ai._util.notgiven import NOT_GIVEN
from inspect_ai._util.registry import (
    has_registry_params,
    is_registry_object,
    registry_info,
    registry_log_name,
    registry_params,
    registry_unqualified_name,
)
from inspect_ai._util.working import (
    init_sample_working_time,
    sample_start_datetime,
    sample_waiting_time,
)
from inspect_ai._view.notify import view_notify_eval
from inspect_ai.dataset import Dataset, Sample
from inspect_ai.event._error import ErrorEvent
from inspect_ai.event._sample_init import SampleInitEvent
from inspect_ai.event._sample_limit import SampleLimitEvent
from inspect_ai.event._score import ScoreEvent
from inspect_ai.log import (
    EvalConfig,
    EvalError,
    EvalLog,
    EvalResults,
    EvalSample,
    EvalScore,
    EvalStats,
    HeadlineMetric,
)
from inspect_ai.log._condense import condense_sample, resolve_events_attachments
from inspect_ai.log._file import (
    EvalLogInfo,
    eval_log_json_str,
    read_eval_log_sample_async,
    read_eval_log_sample_summaries_async,
)
from inspect_ai.log._log import (
    EvalPlan,
    EvalRetryError,
    EvalSampleLimit,
    EvalSampleReductions,
    EvalSampleSummary,
    EvalStatus,
    eval_error,
)
from inspect_ai.log._recorders.buffer.transcript_history_provider import (
    BufferTranscriptHistoryProvider,
)
from inspect_ai.log._recorders.eval import EvalRecorder, _sample_filename
from inspect_ai.log._recorders.streaming import (
    eval_retry_error_from_history,
    materialize_streaming_sample,
)
from inspect_ai.log._samples import (
    active_sample,
)
from inspect_ai.log._transcript import (
    DEFAULT_RESIDENT_TAIL,
    Transcript,
    TranscriptHistoryProvider,
    init_transcript,
    transcript,
    transcript_bounded_enabled,
)
from inspect_ai.model import (
    GenerateConfig,
    GenerateConfigArgs,
    Model,
    ModelAPI,
    ModelName,
)
from inspect_ai.model._assistant_internal import init_sample_assistant_internal
from inspect_ai.model._model import (
    init_model_usage,
    init_role_usage,
    init_sample_model_data,
    sample_model_fallbacks,
    sample_model_usage,
    sample_role_usage,
)
from inspect_ai.model._model_output import ModelUsage
from inspect_ai.scorer import Scorer, Target
from inspect_ai.scorer._metric import Metric, SampleScore
from inspect_ai.scorer._reducer.types import ScoreReducer
from inspect_ai.scorer._score import init_scoring_context
from inspect_ai.scorer._scorer import unique_scorer_name
from inspect_ai.solver import Generate, Plan, TaskState
from inspect_ai.solver._chain import Chain, unroll
from inspect_ai.solver._fork import set_task_generate
from inspect_ai.solver._solver import Solver
from inspect_ai.solver._task_state import sample_state, set_sample_state, state_jsonable
from inspect_ai.util._anyio import inner_exception
from inspect_ai.util._checkpoint._layout import (
    eval_checkpoints_dir_from_config,
    has_sample_checkpoint,
    sample_checkpoints_dir,
)
from inspect_ai.util._checkpoint._layout.sample_checkpoints_dir import (
    scan_latest_committed_checkpoint,
)
from inspect_ai.util._checkpoint.checkpointer import ResumeCheckpoint
from inspect_ai.util._checkpoint.config import (
    CheckpointConfig,
    merge_checkpoint_configs,
)
from inspect_ai.util._early_stopping import (
    EarlyStop,
    EarlyStopping,
    EarlyStoppingSummary,
)
from inspect_ai.util._limit import (
    Limit,
    LimitExceededError,
    monitor_working_limit,
    record_sample_limit_data,
    reset_sample_limit_data,
    token_limit_usage,
    turn_count,
)
from inspect_ai.util._limit import time_limit as create_time_limit
from inspect_ai.util._limit import turn_limit as create_turn_limit
from inspect_ai.util._limit import working_limit as create_working_limit
from inspect_ai.util._limit_overrides import sample_limit_override_scope
from inspect_ai.util._sandbox import SandboxTimeoutError
from inspect_ai.util._sandbox.context import (
    sandbox_connections,
    sandbox_environments_context_var,
)
from inspect_ai.util._sandbox.environment import SandboxEnvironmentSpec
from inspect_ai.util._sandbox.limits import reset_sandbox_limits, set_sandbox_limits
from inspect_ai.util._span import span
from inspect_ai.util._store import init_subtask_store

from ..context import init_task_context
from ..task import Task
from .enqueue import get_task_enqueuer
from .error import SampleErrorHandler, _should_eval_fail
from .generate import task_generate
from .images import (
    InputMediaPolicy,
    TaskInputMediaPlan,
    capture_task_input_media,
    materialize_sample_input,
    sample_without_base64_content,
    state_without_base64_content,
)
from .log import TaskLogger, collect_eval_data, plan_to_eval_plan
from .results import eval_results
from .sample_source import (
    SampleEnqueuer,
    SampleSource,
    clear_sample_enqueuer,
    get_sample_enqueuer,
    register_sample_enqueuer,
)
from .sandbox import sandboxenv_context
from .scan import (
    resume_scan_previous_sample,
    scan_eval_sample,
    scanned_transcripts_for_resume,
)
from .scheduler import SampleRequeue, SampleScheduler
from .store import DiskSampleStore, maybe_page_to_disk
from .task_source import TaskSource
from .util import sample_id_filter, sample_limit_count, sample_messages, slice_dataset

py_logger = getLogger(__name__)


@dataclass
class PreviousError:
    """Prior attempt of a sample that carries genuine error history.

    Unlike a clean reused `EvalSample` (which short-circuits the re-run),
    this signals that the sample must be re-run with its `error_retries`
    seeded from the prior attempt (see `_seed_error_retries`). This unifies
    task-level retries (eval-set / `retry_immediate`, which mint a fresh
    log per attempt) with sample-level `retry_on_error` so both surface a
    retry count and the prior errors on the surviving sample.

    Carries the full prior `sample` so a retry attempt that is itself torn
    down before re-running this sample can re-log it verbatim, keeping the
    error history intact across the per-attempt log chain (see
    `carry_forward_unlogged_samples`).
    """

    sample: EvalSample


SampleLookup = Callable[
    [int | str, int], Awaitable[EvalSample | ResumeCheckpoint | PreviousError | None]
]
ErrorHistoryIds = Callable[[], Awaitable[set[tuple[int | str, int]]]]
PriorExists = Callable[[int | str, int], Awaitable[bool]]


async def _never_prior_exists(id: int | str, epoch: int) -> bool:
    """Default presence probe: no cheap probe available, so don't throttle."""
    return False


class EvalSampleSource(NamedTuple):
    """A prior attempt's sample source.

    `lookup` resolves one planned `(id, epoch)` to a reusable sample, a
    resume checkpoint, or carried error history. `error_history_ids`
    returns the `(id, epoch)` pairs that errored in the prior attempt —
    the only candidates that can yield a `PreviousError` — so teardown
    carry-forward can probe just those instead of the full plan.
    `prior_exists` is a cheap presence probe for the prior attempt's record
    of a sample, used to decide whether its lookup must take the bounded
    reuse read throttle (a presence hit reads a full sample body; misses
    must not queue behind those reads). False means "don't throttle" —
    the sample is known absent, or this source's lookups are cheap
    (in-memory list scans).
    """

    lookup: SampleLookup
    error_history_ids: ErrorHistoryIds
    prior_exists: PriorExists = _never_prior_exists


# Units allocated for sample progress - the total units
# represents the total units of progress for an individual sample
# the remainder are increments of progress within a sample (and
# must sum to the total_progress_units when the sample is complete)
SAMPLE_TOTAL_PROGRESS_UNITS = 1

# How one (sample_index, epoch) run ended, as recorded by the eval's terminal
# counters (`record_sample_completed` / `errored` / `cancelled`). Reported via
# `SampleTerminalReporter`'s slot-release callback — unlike the run's return
# value, which conflates outcomes (an errored-but-scored sample returns its
# scores; a scoreless success returns None).
SampleTerminalOutcome = Literal["completed", "errored", "cancelled"]

# One sample run's scores, keyed by scorer name.
ScoresByScorer: TypeAlias = dict[str, SampleScore]

# Global sample index: position in the seed store when < store_len, else an
# injected sample (see `get_sample`). A reading aid only — mypy treats it as
# int, so it doesn't guard against mixing indices with sample ids or epochs.
SampleIndex: TypeAlias = int

# (sample_index, epoch): how the scheduler keys sample runs.
SampleIndexEpoch: TypeAlias = tuple[SampleIndex, int]

# (sample_id, epoch): how progress results and the log key a sample run —
# distinct from the scheduler's `SampleIndexEpoch` keys.
SampleIdEpoch: TypeAlias = tuple[int | str, int]

# What running one sample yields for results aggregation: scores when the run
# was scored (even if it errored), an EarlyStop marker, or None (scoreless
# success, unscored error, operator cancel). Terminal disposition is reported
# separately via `SampleTerminalReporter` — see `SampleTerminalOutcome`.
SampleRunResult: TypeAlias = ScoresByScorer | EarlyStop | None


class _SampleUsage(NamedTuple):
    """A finished run's model usage, accumulated into the eval totals."""

    tokens: int
    messages: int


class _RecordSampleTerminal(Protocol):
    """Signature shared by the ``record_sample_*`` eval-state counters."""

    def __call__(
        self,
        eval_id: str,
        *,
        tokens: int = 0,
        messages: int = 0,
        started: float | None = None,
    ) -> None: ...


class SampleTerminalReporter:
    """Side-effects of one sample run reaching a terminal outcome.

    A sample run — one (sample, epoch) slot in the task's fanout — ends in
    exactly one of completed / errored / cancelled (see
    ``design/sample-lifecycle.md``). Whichever path gets it there, the same
    bookkeeping must fire exactly once (a second terminal report on the same
    reporter is asserted against):

    - the metrics callback (``sample_complete``: progress results, display
      metrics, the early-stopping hook), for outcomes that carry scores
    - the eval-state terminal counter (``record_sample_completed`` /
      ``errored`` / ``cancelled``), which lets the eval reach ``total`` and
      be marked finished
    - the injected-sample slot release (``sample_terminal``), so a
      SampleSource-driven task frees a sample's memory once every epoch
      completed

    The counter and slot release fire first, then metrics. Metrics run
    user code (custom metric computations, the
    ``EarlyStopping.complete_sample`` hook) that can raise or suspend
    indefinitely: counting first means a raise there (which still tears
    the task down) cannot leave the run outside every terminal bucket,
    and the control channel's task-finished gates (keyed on
    ``completed_at``) read the task as finished while the last sample's
    hook is suspended, rather than accepting a requeue or cancel of a
    task that is de facto done.

    One reporter is created per run (per ``run_sample`` invocation) and
    shared by every attempt of that run — error retries are re-entries of
    the same run, not new runs, and only the attempt that goes terminal
    reports. The reporter also carries the run's display ``progress`` tick,
    which is *not* part of the terminal methods: only outcomes that put a
    result in the log (or reused one) tick, and they tick before their
    (potentially slow, shielded) log write — abandoned and early-stopped
    runs never tick.
    """

    def __init__(
        self,
        *,
        task_id: str,
        progress: Callable[[int], None],
        sample_complete: Callable[[int | str, int, ScoresByScorer], Awaitable[None]],
        sample_terminal: Callable[[SampleTerminalOutcome], None] | None = None,
    ) -> None:
        self._task_id = task_id
        self._progress = progress
        self._sample_complete = sample_complete
        self._sample_terminal = sample_terminal
        self._reported = False

    def progress(self) -> None:
        """Tick this run's unit of display progress (result written/reused)."""
        self._progress(SAMPLE_TOTAL_PROGRESS_UNITS)

    async def completed(
        self,
        sample_id: int | str,
        epoch: int,
        scores: ScoresByScorer | None = None,
        *,
        started: float | None = None,
        usage: _SampleUsage | None = None,
    ) -> None:
        """The run completed (scored, reused, or halted by early stopping)."""
        await self._report(
            record_sample_completed,
            "completed",
            sample_id,
            epoch,
            scores,
            started=started,
            usage=usage,
        )

    async def errored(
        self,
        sample_id: int | str,
        epoch: int,
        scores: ScoresByScorer | None = None,
        *,
        started: float | None = None,
        usage: _SampleUsage | None = None,
    ) -> None:
        """The run errored terminally (retries exhausted or none configured).

        ``scores`` are reported when the errored sample was still scored
        (``score_on_error``, or scores written before the error) so the log
        and metrics never diverge — pass ``None`` when the error is about to
        be raised (the eval dies with ``results=None``, so scores would have
        nothing to contribute to and notifying metrics/early-stopping for a
        dying task would mislead; they remain in the sample log).
        """
        await self._report(
            record_sample_errored,
            "errored",
            sample_id,
            epoch,
            scores,
            started=started,
            usage=usage,
        )

    def cancelled(
        self,
        *,
        started: float | None = None,
        usage: _SampleUsage | None = None,
    ) -> None:
        """The run was cancelled or abandoned (terminal, never a metric)."""
        self._record_and_release(
            record_sample_cancelled, "cancelled", started=started, usage=usage
        )

    async def _report(
        self,
        record: _RecordSampleTerminal,
        outcome: SampleTerminalOutcome,
        sample_id: int | str,
        epoch: int,
        scores: ScoresByScorer | None,
        *,
        started: float | None,
        usage: _SampleUsage | None,
    ) -> None:
        """Counter and slot release first, then metrics (when scored)."""
        self._record_and_release(record, outcome, started=started, usage=usage)
        if scores is not None:
            await self._sample_complete(sample_id, epoch, scores)

    def _record_and_release(
        self,
        record: _RecordSampleTerminal,
        outcome: SampleTerminalOutcome,
        *,
        started: float | None,
        usage: _SampleUsage | None,
    ) -> None:
        assert not self._reported, "sample run already reported a terminal outcome"
        self._reported = True
        usage = usage or _SampleUsage(0, 0)
        record(
            self._task_id,
            started=started,
            tokens=usage.tokens,
            messages=usage.messages,
        )
        if self._sample_terminal is not None:
            self._sample_terminal(outcome)


@dataclass(frozen=True)
class SampleAttempt:
    """Retry state one sample run carries across its attempts.

    ``task_run_sample`` runs a sample as a loop of attempts: an attempt that
    errors with retries remaining hands back a `_SampleRetry` and the loop
    advances this record and re-enters. The budget is invariant — remaining
    retries derive from the errors accrued — so budget and history can't
    drift apart.
    """

    retry_limit: int
    """The run's sample-level retry budget (``retry_on_error``)."""

    errors: tuple[EvalRetryError, ...] = ()
    """Errors from this run's earlier attempts, oldest first."""

    sample_uuid: str | None = None
    """Sample uuid minted by the first attempt and reused by retries.

    Ties the attempts of one run together (the control channel keys its
    event cursor on it); ``None`` on the first attempt (the fresh
    ``TaskState`` mints one).
    """

    @property
    def number(self) -> int:
        """1-based attempt number."""
        return len(self.errors) + 1

    @property
    def is_first(self) -> bool:
        return not self.errors

    @property
    def retries_remaining(self) -> int:
        return self.retry_limit - len(self.errors)

    def advance(self, retry: "_SampleRetry") -> "SampleAttempt":
        """The next attempt's state after an error-retry."""
        return SampleAttempt(
            retry_limit=self.retry_limit,
            errors=self.errors + (retry.error,),
            sample_uuid=retry.sample_uuid,
        )


@dataclass(frozen=True)
class _SampleRetry:
    """An attempt's signal that the run should retry (never a run result)."""

    error: EvalRetryError
    """The failure that triggered the retry, for the run's error history."""

    sample_uuid: str
    """The attempt's sample uuid, carried to the retry."""


# How many prior-attempt sample bodies a retry's reuse sweep reads (and
# re-logs) concurrently. All run_sample coroutines start at once, so without
# a bound the whole reused set can be mid-read simultaneously; 25 matches the
# bounded concurrency used for journal summary reads in
# `_read_all_summaries_async`.
REUSED_SAMPLE_READ_CONCURRENCY = 25

# How many times the reuse presence probe re-attempts a failed central
# directory fetch before giving up (which disables the reuse read throttle
# for the sweep). Failures other than FileNotFoundError may be transient
# (e.g. a remote filesystem blip), so a single failure must not be cached;
# but a persistently unreadable log must not be re-fetched per probe either.
PRIOR_PROBE_MAX_FAILURES = 3


class _ReuseSweepCountdown:
    """Fires the reused-sample settle flush when the reuse sweep completes.

    Counts planned ``(sample, epoch)`` runs; each ``run_sample`` settles one
    as soon as its prior-attempt lookup (and any re-log) has resolved. The
    final settle means the re-logged reused set is complete, so
    ``TaskLogger.reuse_sweep_settled`` releases the attempt's
    destination-write hold and writes the set in one deterministic flush —
    keyed to an exact event rather than a stale timer, it fires no earlier
    (no partial-sweep flushes, so the attempt's first on-disk version already
    carries every reused sample) and no later (no idle wait). A
    SampleSource-driven task can add planned runs after the seed sweep
    settles; ``add`` raises the count again so a later settle drains any
    follow-up reuse.

    No lock: count mutations happen on the eval's single event-loop thread
    with no await point between read and write.
    """

    def __init__(self, logger: TaskLogger, planned_runs: int) -> None:
        self._logger = logger
        self._remaining = planned_runs

    def add(self, planned_runs: int) -> None:
        self._remaining += planned_runs

    def settle_one(self) -> None:
        self._remaining -= 1
        if self._remaining == 0:
            self._logger.reuse_sweep_settled()


def _sample_transcript_config(
    logger: TaskLogger | None, sample_id: str | int, epoch: int
) -> tuple[bool, TranscriptHistoryProvider | None]:
    if logger is not None and logger.buffer_db is not None:
        return (
            transcript_bounded_enabled(),
            BufferTranscriptHistoryProvider(logger.buffer_db, sample_id, epoch),
        )
    else:
        return False, None


@dataclass
class TaskRunOptions:
    task: Task
    model: Model
    model_roles: dict[str, Model | list[Model]] | None
    sandbox: SandboxEnvironmentSpec | None
    checkpoint: CheckpointConfig | None
    """Task-level checkpoint config (raw `task.checkpoint`)."""
    eval_checkpoint: CheckpointConfig | None
    """Eval/CLI-level checkpoint config (overrides task/sample)."""
    logger: TaskLogger
    eval_wd: str
    config: EvalConfig = field(default_factory=EvalConfig)
    solver: Solver | None = field(default=None)
    scanner: "Scanners | None" = field(default=None)
    scan_id: str | None = field(default=None)
    tags: list[str] | None = field(default=None)
    run_samples: bool | None = field(default=True)
    score: bool = field(default=True)
    debug_errors: bool = field(default=False)
    sample_source: EvalSampleSource | None = field(default=None)
    display_name: str | None = field(default=None)
    kwargs: GenerateConfigArgs = field(default_factory=lambda: GenerateConfigArgs())
    initial_model_usage: dict[str, ModelUsage] | None = field(default=None)
    initial_role_usage: dict[str, ModelUsage] | None = field(default=None)
    task_source: "TaskSource | None" = field(default=None)
    """Run-level task source notified as this task's samples/task complete."""
    startup_sandboxes: Callable[[list[Sample]], Awaitable[None]] | None = field(
        default=None
    )
    """Run-level incremental sandbox startup for samples a SampleSource adds."""
    input_media_policy: InputMediaPolicy = field(default="inline_only")
    """Authority granted to media references in the sliced seed dataset."""


def resolve_plan(task: Task, solver: Solver | None) -> Plan:
    # resolve the plan (unroll chains)
    solver = solver or task.solver
    if isinstance(solver, Plan):
        plan = solver
    elif isinstance(solver, Chain):
        plan = Plan(list(solver), internal=True)
    else:
        plan = Plan(unroll(solver), internal=True)

    # add setup solver(s) if specified
    if task.setup:
        # avoid mutating a caller-supplied Plan: resolve_plan may run more than
        # once for the same task (e.g. task-identity hashing in evalset, then the
        # run itself), and prepending in place would stack setup steps each time.
        # A shallow copy preserves finish/cleanup/name and registry identity.
        if plan is solver:
            plan = copy(plan)
        plan.steps = unroll(task.setup) + plan.steps

    return plan


def plan_agent_name(plan: Plan) -> str | None:
    """Unqualified name of the plan's terminal step (agent or solver)."""
    if plan.steps:
        last_step = plan.steps[-1]
        if is_registry_object(last_step):
            return registry_unqualified_name(registry_info(last_step).name)
    return None


def eval_plan_agent_name(plan: EvalPlan) -> str | None:
    """Unqualified name of a recorded plan's terminal step (agent or solver).

    The log-header counterpart of `plan_agent_name`. `plan_to_eval_plan`
    records a `finish` solver again as the trailing step, so skip it to
    match the live derivation.
    """
    steps = plan.steps[:-1] if plan.finish else plan.steps
    return registry_unqualified_name(steps[-1].solver) if steps else None


def _enqueue_source_tasks(tasks: list[Task] | None) -> None:
    """Add tasks a TaskSource callback returned to the running eval's queue.

    Routes through the run's enqueuer (the same buffer ``enqueue_task`` feeds), so
    the eval loop drains them as the next batch. A no-op if the callback returned
    nothing or there is no active enqueuer.
    """
    if tasks:
        enqueuer = get_task_enqueuer()
        if enqueuer is not None:
            enqueuer.enqueue(tasks)


def _enqueue_source_samples(samples: list[Sample] | None) -> None:
    """Add samples a SampleSource callback returned to the running task's queue.

    Routes through the task's enqueuer (the same buffer ``enqueue_sample``
    feeds), so the task's dispatch loop starts them as capacity frees up. A
    no-op if the callback returned nothing or there is no active enqueuer.
    """
    if samples:
        enqueuer = get_sample_enqueuer()
        if enqueuer is not None:
            enqueuer.enqueue(samples)


async def task_run(options: TaskRunOptions, task_cancel: TaskCancel | None) -> EvalLog:
    from inspect_ai.hooks._hooks import (
        emit_task_end,
        emit_task_start,
    )
    from inspect_ai.hooks._legacy import send_telemetry_legacy

    # destructure options
    task = options.task
    model = options.model
    model_roles = options.model_roles
    sandbox = options.sandbox
    checkpoint = options.checkpoint
    eval_checkpoint = options.eval_checkpoint
    logger = options.logger
    eval_wd = options.eval_wd
    config = options.config
    solver = options.solver
    scanner = options.scanner
    scan_id = options.scan_id
    tags = options.tags
    score = options.score
    sample_source = options.sample_source
    kwargs = options.kwargs

    # a SampleSource-driven task generates samples while it runs (`sample_feed`
    # to distinguish it from `sample_source`, the prior-attempt lookup above)
    sample_feed: SampleSource | None = task.sample_source

    # resolve default generate_config for task
    generate_config = task.config.merge(GenerateConfigArgs(**kwargs))

    # seed model/role usage from a prior log when this task is a retry
    # (the deepcopy guards against shared dict mutation across attempts).
    # init_task_context's no-arg init_model_usage/init_role_usage will leave
    # these seeded values in place.
    if options.initial_model_usage:
        init_model_usage(deepcopy(options.initial_model_usage))
    if options.initial_role_usage:
        init_role_usage(deepcopy(options.initial_role_usage))

    # init task context
    init_task_context(
        model,
        model_roles,
        generate_config,
        options.task.approval,
    )

    # track stats, results, and log. progress results are keyed by
    # (sample_id, epoch) so a requeued sample's fresh score replaces its
    # prior entry (the log supersedes by the same key — metrics must agree)
    results: EvalResults | None = None
    reductions: list[EvalSampleReductions] | None = None
    progress_results: dict[SampleIdEpoch, ScoresByScorer] = {}
    eval_log: EvalLog | None = None
    stats = EvalStats(started_at=iso_now())

    # resolve some config
    model_name = ModelName(model)
    epochs = config.epochs if config.epochs else DEFAULT_EPOCHS
    sandbox_cleanup = config.sandbox_cleanup is not False
    log_images = config.log_images is not False
    log_model_api = config.log_model_api
    log_samples = config.log_samples is not False

    # Reserve every seed id before slicing so a dynamic sample cannot reclaim
    # an excluded id and inherit any identity or authority associated with it.
    seed_ids = {str(sample.id) for sample in task.dataset if sample.id is not None}

    # slice dataset (but don't materialize all sample+state pairs upfront --
    # they are created lazily inside run_sample to keep memory at
    # O(concurrent_samples) instead of O(total_samples * epochs))
    dataset = slice_dataset(
        task.dataset, config.limit, config.sample_id, dynamic=sample_feed is not None
    )
    input_media_plan = (
        capture_task_input_media(dataset)
        if options.input_media_policy == "trusted_pre_run"
        else {}
    )
    total_samples = len(dataset) * epochs

    # capture sample ids now, before `dataset` may be paged to disk and
    # deleted below — used by register_eval and carry_forward_unlogged_samples
    sample_ids = [s.id for s in dataset if s.id is not None]

    # sample id -> fanout index, for the requeue directive's resolution
    # (captured here too so it never reads the paged-to-disk store)
    sample_indexes = {
        str(sample.id): index
        for index, sample in enumerate(dataset)
        if sample.id is not None
    }

    async def finish_task_log(
        status: EvalStatus,
        stats: EvalStats,
        results: EvalResults | None = None,
        reductions: list[EvalSampleReductions] | None = None,
        error: EvalError | None = None,
    ) -> EvalLog:
        """Finish via ``_finish_task_log`` with the run-invariant context.

        Bound once here so every terminal branch finishes with the same
        logger / sample-source / planned-ids context — a new branch can't
        accidentally thread a stale or divergent value.
        """
        return await _finish_task_log(
            logger=logger,
            sample_source=options.sample_source,
            sample_ids=sample_ids,
            epochs=epochs,
            log_images=log_images,
            status=status,
            stats=stats,
            results=results,
            reductions=reductions,
            error=error,
        )

    # handle sample errors (raise as required). use total_samples (sliced
    # dataset * epochs) as the denominator for fractional fail_on_error so
    # the mid-run abort threshold matches the end-of-run check below. for a
    # SampleSource-driven task that denominator grows while the task runs,
    # so fractional thresholds are deferred to the end-of-run check (see
    # SampleErrorHandler).
    sample_error_handler = SampleErrorHandler(
        config.fail_on_error if config.continue_on_fail is not True else False,
        total_samples,
        defer_fractional=sample_feed is not None,
    )

    # optionally page dataset to disk if it exceeds the memory budget
    sample_store = maybe_page_to_disk(dataset, config.max_dataset_memory)

    # release in-memory samples now that they're paged to disk
    if sample_store is not dataset:
        del dataset

    # samples a SampleSource injects while the task runs, indexed after the
    # seed store (kept in memory — they arrive incrementally, not up front).
    # a slot is released (set to None) once every epoch's latest run
    # *completed*, so an open-ended source doesn't accumulate every sample it
    # ever produced. An errored/cancelled epoch keeps the slot resident: the
    # sample is requeueable, and its re-run needs the source data (which,
    # unlike a seed sample's, exists nowhere else — the log record doesn't
    # carry file contents). The converse guards `get_sample`'s assert: a
    # released slot means every epoch completed, and the requeue resolver
    # rejects error-less priors, so an accepted requeue always finds its
    # sample resident.
    store_len = len(sample_store)
    injected_samples: list[Sample | None] = []
    injected_completed_epochs: dict[SampleIndex, set[int]] = {}

    def get_sample(sample_index: int) -> Sample:
        if sample_index < store_len:
            return sample_store[sample_index]
        sample = injected_samples[sample_index - store_len]
        assert sample is not None, "sample accessed after all its epochs completed"
        return sample

    def note_injected_terminal(
        sample_index: int, epoch: int, outcome: SampleTerminalOutcome
    ) -> None:
        completed = injected_completed_epochs.setdefault(sample_index, set())
        if outcome == "completed":
            completed.add(epoch)
        else:
            # a requeued re-run can turn a completed epoch back into an
            # errored one only via a fresh run, which passes through here
            completed.discard(epoch)
        if len(completed) >= epochs:
            injected_samples[sample_index - store_len] = None
            del injected_completed_epochs[sample_index]

    # register the sample enqueuer that buffers additions to a
    # SampleSource-driven task (callback-returned samples / enqueue_sample);
    # ContextVar-scoped so it propagates to this task's samples but not to
    # other tasks running in the process. Reset in the finally below.
    sample_enqueuer: SampleEnqueuer | None = None
    sample_enqueuer_token: Token[SampleEnqueuer | None] | None = None
    if sample_feed is not None:
        sample_enqueuer = SampleEnqueuer()
        sample_enqueuer_token = register_sample_enqueuer(sample_enqueuer)

    # resolve the plan (unroll chains)
    solver = solver or task.solver
    plan = resolve_plan(task, solver)

    # resolve the scorer
    score = score and task.scorer is not None
    scorers: list[Scorer] | None = task.scorer if (score and task.scorer) else None

    # resolve unique scorer names once so sample scoring
    # and aggregation use the same names
    scorer_names: list[str] | None = None
    if scorers:
        scorer_names = []
        for s in scorers:
            scorer_names.append(unique_scorer_name(s, scorer_names))

    scorer_profiles = (
        [registry_log_name(scorer) for scorer in scorers if is_registry_object(scorer)]
        if scorers is not None
        else ["(none)"]
    )

    # compute an eval directory relative log location if we can
    if PurePath(logger.location).is_relative_to(PurePath(eval_wd)):
        log_location = PurePath(logger.location).relative_to(eval_wd).as_posix()
    else:
        log_location = logger.location

    # create task profile for display
    profile = TaskProfile(
        name=options.display_name or task.name,
        file=logger.eval.task_file,
        model=model_name,
        agent=plan_agent_name(plan),
        dataset=task.dataset.name or "(samples)",
        scorer=", ".join(scorer_profiles),
        samples=total_samples,
        steps=total_samples * SAMPLE_TOTAL_PROGRESS_UNITS,
        eval_config=config,
        task_args=logger.eval.task_args_passed,
        generate_config=generate_config,
        tags=tags,
        log_location=log_location,
        task_id=logger.eval.task_id,
        task_cancel=task_cancel,
    )

    # set custom sandbox limits
    limit_tokens = set_sandbox_limits()

    with display().task(
        profile,
    ) as td:
        # start the log (do this outside fo the try b/c the try/except assumes
        # that the log is initialized)
        eval_plan = plan_to_eval_plan(plan, generate_config)
        # a retry attempt with a non-empty seed defers every destination write
        # until its reuse sweep settles (the countdown below fires
        # reuse_sweep_settled, which releases the hold). A zero-seed
        # SampleSource-driven task skips the hold: its samples arrive over
        # time, so there is no early settle event to key the release to.
        if sample_source is not None and store_len * epochs > 0:
            logger.hold_destination_writes()
        await logger.log_start(eval_plan)

        try:
            # return immediately if we are not running samples
            if not options.run_samples:
                return await logger.log_finish("started", stats)

            # call hook
            await emit_task_start(logger, eval_plan)

            sample_semaphore = create_sample_semaphore(
                config,
                model.config.merge(generate_config),
                model.api,
                task_id=logger.eval.task_id,
            )

            # retry reuse sweep coordination: a throttle bounding concurrent
            # prior-sample body reads/re-logs, and a countdown that schedules
            # one destination flush of the re-logged set once every planned
            # sample has resolved its reuse check
            reuse_read_throttle = anyio.Semaphore(REUSED_SAMPLE_READ_CONCURRENCY)
            reuse_settle = _ReuseSweepCountdown(logger, store_len * epochs)

            # sample dispatch goes through the pause gate wrapped around the
            # semaphore (a stamped cancel escapes the gate so held samples
            # reach the queue-exit abandon check); scan reuse below keeps the
            # raw semaphore — reused samples aren't new work for the gate to
            # hold
            # dispatch_model_name, not str(model): the snapshot keeps the
            # gate's key stable if the provider rewrites its model name
            # mid-run (and register_eval below must store the same name)
            pause_model_name = dispatch_model_name(model)
            gated_sample_semaphore = PauseGatedSemaphore(
                sample_semaphore,
                task_id=logger.eval.task_id,
                escape=lambda: task_cancel is not None
                and task_cancel.cancel_type is not None,
                model=pause_model_name,
            )

            # must run immediately before register_eval (see its docstring):
            # catches up on ctl retunes applied while this task sat queued
            # between its up-front logger init and starting here
            await logger.record_inherited_config_updates()

            # Register this eval with the process-level state aggregate
            # so the control channel (and other readers) can answer
            # "how many samples queued / running / done?" without
            # polling active_samples() or scanning logs. Paired with
            # the finalize_eval in the finally below.
            register_eval(
                logger.eval.eval_id,
                total_samples,
                task=logger.eval.task,
                task_id=logger.eval.task_id,
                model=pause_model_name,
                solver=profile.agent,
                log_location=logger.location,
                live=logger,
                sample_ids=sample_ids,
                epochs=epochs,
                run_id=logger.eval.run_id,
                # whether a failure of this attempt will be retried — lets the
                # control channel show cancelled samples as pending (re-run
                # coming) vs cancelled (terminal)
                will_retry=task_cancel.can_retry if task_cancel is not None else False,
                # the cancel handle the control channel's task-cancel
                # directive fires (with "abort" — the display's user-cancel)
                task_cancel=task_cancel,
                # a SampleSource-driven eval's totals grow while it runs, so
                # counters reaching total must not read as "finished" (e.g.
                # while blocked in next_samples() with an empty seed)
                dynamic=sample_feed is not None,
            )

            # publish the interim-scoring capability (the task's scorers and
            # scoring inputs as resolved at eval start) for the control
            # channel's `task score` directive — see
            # design/ctl/interim-scoring.md. Local import: _control.scoring
            # pulls scorer/metrics machinery that must not load at bootstrap.
            from inspect_ai._control.scoring import TaskScoring

            set_task_scoring(
                logger.eval.eval_id,
                TaskScoring(
                    scorers=scorers or [],
                    scorer_names=scorer_names or [],
                    model=model,
                    model_roles=model_roles,
                    generate_config=generate_config,
                    epochs_reducer=task.epochs_reducer,
                    metrics=task.metrics,
                    score_on_error=config.score_on_error or False,
                ),
            )

            # call early stopping if we have it
            stopping_manager: str = ""
            if options.task.early_stopping is not None:
                stopping_manager = await options.task.early_stopping.start_task(
                    logger.eval,
                    samples=[
                        deepcopy(sample_store[i]) for i in range(len(sample_store))
                    ],
                    epochs=epochs,
                )

            with td.progress() as p:
                # forward progress
                def progress(number: int) -> None:
                    p.update(number)

                # provide solvers a function that they can use to generate output
                async def generate(
                    state: TaskState,
                    tool_calls: Literal["loop", "single", "none"] = "loop",
                    **kwargs: Unpack[GenerateConfigArgs],
                ) -> TaskState:
                    return await task_generate(
                        model=model,
                        state=state,
                        tool_calls=tool_calls,
                        cache=kwargs.get("cache", False) or NOT_GIVEN,
                        config=generate_config.merge(kwargs),
                    )

                # set generate for fork module
                set_task_generate(generate)

                scanned_per_scanner = scanned_transcripts_for_resume(
                    scanner, scan_id, profile.log_location
                )

                def update_metrics(metrics: list[TaskDisplayMetric]) -> None:
                    td.update_metrics(metrics)
                    logger.update_metrics(metrics)

                update_metrics_display = update_metrics_display_fn(
                    update_metrics,
                    display_metrics=profile.eval_config.score_display is not False,
                    headline_metric=task.headline_metric,
                )

                async def sample_complete(
                    sample_id: int | str,
                    epoch: int,
                    sample_score: ScoresByScorer,
                ) -> None:
                    # Capture the result (a requeued sample's fresh score
                    # replaces its prior entry)
                    progress_results[(sample_id, epoch)] = sample_score

                    # Increment the segment progress
                    td.sample_complete(
                        complete=len(progress_results), total=total_samples
                    )

                    # Update metrics
                    update_metrics_display(
                        len(progress_results),
                        list(progress_results.values()),
                        scorers,
                        scorer_names,
                        task.epochs_reducer,
                        task.metrics,
                    )

                    # call the early stopping hook
                    if options.task.early_stopping is not None:
                        await options.task.early_stopping.complete_sample(
                            sample_id, epoch, sample_score
                        )

                # initial progress
                td.sample_complete(complete=0, total=total_samples)

                # Update metrics to empty state
                update_metrics_display(
                    len(progress_results),
                    list(progress_results.values()),
                    scorers,
                    scorer_names,
                    task.epochs_reducer,
                    task.metrics,
                )

                async def run_sample(
                    sample_index: int,
                    epoch: int,
                    requeue_prior: EvalSample | None = None,
                ) -> SampleRunResult:
                    # the run's terminal bookkeeping, shared by the reuse
                    # short-circuit below and every terminal path inside
                    # task_run_sample
                    reporter = SampleTerminalReporter(
                        task_id=logger.eval.eval_id,
                        progress=progress,
                        sample_complete=sample_complete,
                        # injected samples report how each run ended so their
                        # in-memory slot releases only once every epoch has
                        # completed (see note_injected_terminal)
                        sample_terminal=(
                            (
                                lambda outcome: note_injected_terminal(
                                    sample_index, epoch, outcome
                                )
                            )
                            if sample_index >= store_len
                            else None
                        ),
                    )

                    # check for cached result from previous eval (before
                    # materialization to avoid unnecessary deepcopy + image I/O)
                    sample_id = get_sample(sample_index).id
                    resume_checkpoint: ResumeCheckpoint | None = None
                    # prior task-attempt errors to seed this re-run's
                    # error_retries (empty unless the sample source reports a
                    # PreviousError); kept distinct from the sample-level
                    # retry list so it doesn't suppress sample init/start emits
                    previous_attempt_errors: list[EvalRetryError] = []
                    previous_sample: (
                        EvalSample | ResumeCheckpoint | PreviousError | None
                    ) = None
                    try:
                        if requeue_prior is not None:
                            # requeued re-run (design/ctl/sample-requeue.md):
                            # seeded from the prior terminal record exactly as
                            # a task-level retry would be — resume from a
                            # checkpoint when one exists, else carry the prior
                            # errors (the fresh sample uuid and retry_on_error
                            # budget come with the fresh TaskState below). Drop
                            # the prior attempt's buffered events first, the
                            # same call the retry loop makes; the flushed
                            # (id, epoch) log record is superseded when the
                            # re-run logs.
                            if sample_id is not None:
                                logger.remove_sample(sample_id, epoch)
                                resume_checkpoint = await _resume_if_checkpointed(
                                    requeue_checkpoints_dir, sample_id, epoch
                                )
                            if resume_checkpoint is None:
                                previous_attempt_errors = _seed_error_retries(
                                    requeue_prior
                                )
                        elif sample_source and sample_id is not None:
                            # a presence hit reads a full prior sample body, so
                            # it takes the reuse read throttle; the probe itself
                            # stays outside so true misses — samples absent from
                            # the prior log — proceed immediately rather than
                            # queueing behind reused-sample body reads
                            throttled = await sample_source.prior_exists(
                                sample_id, epoch
                            )
                            if throttled:
                                await reuse_read_throttle.acquire()
                            try:
                                previous_sample = await sample_source.lookup(
                                    sample_id, epoch
                                )
                                if isinstance(previous_sample, EvalSample):
                                    reporter.progress()
                                    if logger and log_samples:
                                        # write_through: the reused set is
                                        # re-logged in bulk before any flush
                                        # trigger, so park each sample in the
                                        # recorder's temp zip rather than
                                        # keeping the whole set resident
                                        await logger.complete_sample(
                                            condense_sample(
                                                previous_sample, log_images
                                            ),
                                            flush=False,
                                            write_through=True,
                                        )
                            finally:
                                if throttled:
                                    reuse_read_throttle.release()
                    finally:
                        # settle before resume_scan_previous_sample (which
                        # acquires the sample semaphore and can block behind
                        # long-running live samples) and sample_complete
                        # (which awaits the early-stopping hook) so they can't
                        # delay the sweep's settle flush; a cancelled
                        # run_sample still settles here. A requeued re-run is
                        # an extra invocation of an already-settled key, so
                        # settling it would corrupt the countdown.
                        if requeue_prior is None:
                            reuse_settle.settle_one()

                    if isinstance(previous_sample, EvalSample):
                        sample_scores = (
                            {
                                key: SampleScore(
                                    score=score,
                                    sample_id=previous_sample.id,
                                    sample_metadata=previous_sample.metadata,
                                    scorer=key,
                                )
                                for key, score in previous_sample.scores.items()
                            }
                            if previous_sample.scores
                            else {}
                        )
                        await resume_scan_previous_sample(
                            previous_sample,
                            scanner,
                            scanned_per_scanner,
                            sample_semaphore,
                            scan_id=scan_id,
                            eval_id=logger.eval.eval_id,
                            log_location=profile.log_location,
                            model=str(model),
                            eval_spec=logger.eval,
                        )
                        # reused sample: accumulate its own logged usage
                        await reporter.completed(
                            previous_sample.id,
                            epoch,
                            sample_scores,
                            usage=_SampleUsage(
                                tokens=sum(
                                    u.total_tokens
                                    for u in previous_sample.model_usage.values()
                                ),
                                messages=len(previous_sample.messages),
                            ),
                        )
                        # notify the task's SampleSource of the reused
                        # sample: a completion-driven source regenerates
                        # its follow-ups on retry from these notifications
                        # (the follow-ups are then themselves reused via
                        # this same prior-attempt lookup)
                        if sample_feed is not None:
                            _enqueue_source_samples(
                                await sample_feed.sample_complete(previous_sample)
                            )
                        return sample_scores
                    elif isinstance(previous_sample, ResumeCheckpoint):
                        # signal intent — agent code can branch on
                        # `cp.attempt`. Hydration runs inside
                        # `_CheckpointerSetup.__aenter__`.
                        resume_checkpoint = previous_sample
                    elif isinstance(previous_sample, PreviousError):
                        previous_attempt_errors = _seed_error_retries(
                            previous_sample.sample
                        )

                    # factory to create sample+state lazily (after semaphore)
                    # so only concurrently executing samples consume memory
                    async def create_sample_state(
                        sample_uuid: str | None = None,
                    ) -> tuple[Sample, TaskState]:
                        sample = deepcopy(get_sample(sample_index))
                        state = deepcopy(
                            TaskState(
                                sample_id=sample.id or 0,
                                epoch=epoch,
                                model=model_name,
                                input=sample.input,
                                target=Target(sample.target),
                                choices=sample.choices,
                                messages=sample_messages(sample),
                                message_limit=config.message_limit,
                                token_limit=config.token_limit,
                                token_limit_type=config.token_limit_type or "all",
                                cost_limit=config.cost_limit,
                                completed=False,
                                metadata=sample.metadata if sample.metadata else {},
                                sample_uuid=sample_uuid,
                            )
                        )
                        return sample, state

                    return await task_run_sample(
                        task=task,
                        task_name=task.name,
                        log_location=profile.log_location,
                        create_sample_state=create_sample_state,
                        input_media_plan=input_media_plan,
                        sandbox=sandbox,
                        checkpoint=checkpoint,
                        eval_checkpoint=eval_checkpoint,
                        resume_checkpoint=resume_checkpoint,
                        max_sandboxes=config.max_sandboxes,
                        sandbox_cleanup=sandbox_cleanup,
                        plan=plan,
                        scorers=scorers,
                        scorer_names=scorer_names,
                        scanner=scanner,
                        cleanup=task.cleanup,
                        generate=generate,
                        logger=logger if log_samples else None,
                        log_images=log_images,
                        log_model_api=log_model_api,
                        sample_error=sample_error_handler,
                        reporter=reporter,
                        early_stopping=options.task.early_stopping,
                        task_cancel=task_cancel,
                        task_source=options.task_source,
                        sample_feed=sample_feed,
                        fails_on_error=(
                            config.fail_on_error is not False
                            and config.continue_on_fail is not True
                            and config.score_on_error is not True
                        ),
                        retry_on_error=config.retry_on_error or 0,
                        score_on_error=config.score_on_error or False,
                        previous_attempt_errors=previous_attempt_errors,
                        turn_limit=config.turn_limit,
                        time_limit=config.time_limit,
                        working_limit=config.working_limit,
                        semaphore=gated_sample_semaphore,
                        eval_set_id=logger.eval.eval_set_id,
                        run_id=logger.eval.run_id,
                        task_id=logger.eval.eval_id,
                        scan_id=options.scan_id,
                    )

                async def run_samples_dynamic(
                    feed: SampleSource,
                    enqueuer: SampleEnqueuer,
                    scheduler: SampleScheduler,
                ) -> dict[SampleIndexEpoch, SampleRunResult]:
                    """Run the seed samples plus every sample the source adds.

                    Spawns through the shared ``SampleScheduler`` — the same
                    fanout the requeue directive injects into — with a feeder
                    coroutine inside the scheduler's task group consuming the
                    source: injected samples start immediately (concurrency is
                    bounded by the sample semaphore inside ``run_sample``), and
                    the blocking ``next_samples()`` is only awaited when
                    nothing is in flight or buffered — so no completion can
                    enqueue while it blocks (no lost wakeup).

                    ``--limit`` caps the total samples (seed + added): once the
                    cap is reached further additions are ignored (with a
                    warning) and the feeder finishes without consulting the
                    source again. ``--sample-id`` filters added samples the
                    same way it filters the seed (the filter and the cap are
                    mutually exclusive, matching ``slice_dataset``).
                    """
                    nonlocal total_samples

                    feeder_wake = Wake()
                    enqueuer.on_enqueue = feeder_wake.set

                    # --sample-id: added samples must also match the filter
                    include_id = (
                        sample_id_filter(config.sample_id).matches
                        if config.sample_id is not None
                        else None
                    )

                    # --limit: cap on total samples (seed + added); the seed
                    # was already sliced above, so the cap's remainder is the
                    # budget for added samples. None when --sample-id is set
                    # (slice_dataset likewise ignores limit then).
                    limit_count = (
                        sample_limit_count(config.limit) if include_id is None else None
                    )
                    remaining = (
                        max(0, limit_count - store_len)
                        if limit_count is not None
                        else None
                    )

                    # injected samples without ids continue the seed's 1-based
                    # numbering, skipping ids already in use; ids are compared
                    # by their str() form (matching ensure_unique_ids, since
                    # log member names and score grouping key on it). the seed
                    # ids come from the complete pre-slice seed set, so a
                    # filtered-out id cannot be reclaimed by a dynamic sample
                    seen_ids = set(seed_ids)
                    auto_id = store_len

                    class AddedSamples(NamedTuple):
                        indexes: list[int]
                        samples: list[Sample]

                    def add_samples(samples: list[Sample]) -> AddedSamples:
                        nonlocal total_samples, auto_id, remaining
                        added = AddedSamples([], [])
                        over_limit = 0
                        for sample in samples:
                            if sample.id is None:
                                auto_id += 1
                                while str(auto_id) in seen_ids:
                                    auto_id += 1
                                sample.id = auto_id
                            if str(sample.id) in seen_ids:
                                raise ValueError(
                                    f"SampleSource added a sample with duplicate "
                                    f"id '{sample.id}'. Please ensure each sample "
                                    "has a unique id."
                                )
                            seen_ids.add(str(sample.id))
                            if include_id is not None and not include_id(sample.id):
                                continue
                            if remaining is not None:
                                if remaining <= 0:
                                    over_limit += 1
                                    continue
                                remaining -= 1
                            sample_ids.append(sample.id)
                            injected_samples.append(sample)
                            added.samples.append(sample)
                            added.indexes.append(store_len + len(injected_samples) - 1)
                            # resolvable by the requeue directive, like a seed
                            sample_indexes[str(sample.id)] = added.indexes[-1]
                        if over_limit:
                            py_logger.warning(
                                f"Sample limit ({limit_count}) reached: ignoring "
                                f"{over_limit} sample(s) added to the task."
                            )
                        if added.indexes:
                            # grow the planned totals (display denominator,
                            # fail_on_error threshold, control-channel counters)
                            # and the reuse-sweep countdown (added samples run
                            # the same prior-attempt lookup)
                            total_samples += len(added.indexes) * epochs
                            reuse_settle.add(len(added.indexes) * epochs)
                            sample_error_handler.total_samples = total_samples
                            record_samples_added(
                                logger.eval.eval_id,
                                len(added.indexes) * epochs,
                                sample_ids=[
                                    sample.id
                                    for sample in added.samples
                                    if sample.id is not None
                                ],
                            )
                            td.sample_complete(
                                complete=len(progress_results), total=total_samples
                            )
                        return added

                    async def add_and_start(samples: list[Sample]) -> bool:
                        """Add samples and start them; True if any started.

                        Added samples get the same run-level sandbox startup
                        as the seed (``task_init`` for configs not seen
                        before: image build/pull, validation, cleanup
                        registration) before they spawn; already-started
                        configs are a cheap no-op. A startup failure
                        propagates and fails the task, matching a seed
                        config failing startup.
                        """
                        added = add_samples(samples)
                        if added.samples and options.startup_sandboxes is not None:
                            await options.startup_sandboxes(added.samples)
                        scheduler.add(
                            [
                                (sample_index, epoch)
                                for sample_index in added.indexes
                                for epoch in range(1, epochs + 1)
                            ]
                        )
                        return bool(added.indexes)

                    async def feed_samples() -> None:
                        while True:
                            # checkpoint so a misbehaving source that never
                            # blocks (e.g. next_samples() returning []) keeps
                            # the loop cancellable instead of spinning hot
                            await anyio.lowlevel.checkpoint()
                            # samples buffered since the last cycle (callbacks
                            # returning samples / enqueue_sample) start first
                            buffered = enqueuer.drain()
                            if buffered:
                                await add_and_start(buffered)
                                continue
                            if scheduler.outstanding > 0:
                                await feeder_wake.wait()
                                continue
                            # fully idle: the task is complete once the sample
                            # limit is exhausted (don't consult the source for
                            # samples that could never run)
                            if remaining is not None and remaining <= 0:
                                break
                            # ask the source for more (may block) and finish
                            # when it is exhausted
                            more = await feed.next_samples()
                            if more is None:
                                # run samples enqueued while next_samples()
                                # was finishing rather than dropping them
                                # (enqueue_sample never drops silently); if
                                # any run, the source may be consulted again
                                if not await add_and_start(enqueuer.drain()):
                                    break
                            elif more:
                                await add_and_start(more)

                    return await scheduler.run(
                        seed_plan,
                        run_sample,
                        feeder=feed_samples,
                        on_settle=feeder_wake.set,
                    )

                # where a requeued sample's checkpoint (if any) lives — this
                # attempt's own checkpoints, unlike the sample source's
                # prior-attempt dir
                requeue_checkpoints_dir = eval_checkpoints_dir_from_config(
                    logger.location, checkpoint, eval_checkpoint
                )

                # the sample fanout: an injectable scheduler rather than a
                # one-shot tg_collect, so the control channel's requeue
                # directive can re-add an errored/cancelled sample to the
                # live run (design/ctl/sample-requeue.md) — including a
                # SampleSource-driven run, whose feeder runs inside the
                # same fanout
                def on_requeue_accept(sample_id: int | str, epoch: int) -> None:
                    # un-tick the prior terminal outcome's progress and drop
                    # its superseded score from the live results so the bar
                    # and metrics reflect the re-opened work (a re-run that
                    # scores re-adds it via sample_complete; a re-run that
                    # ends unscored — e.g. a task cancel — must not leave the
                    # stale score in the metrics display or the cancellation
                    # path's partial eval_results)
                    progress(-SAMPLE_TOTAL_PROGRESS_UNITS)
                    progress_results.pop((sample_id, epoch), None)

                sample_scheduler = SampleScheduler()
                set_sample_requeue(
                    logger.eval.eval_id,
                    SampleRequeue(
                        eval_id=logger.eval.eval_id,
                        scheduler=sample_scheduler,
                        sample_error=sample_error_handler,
                        sample_indexes=sample_indexes,
                        checkpoints_dir=requeue_checkpoints_dir,
                        on_accept=on_requeue_accept,
                    ),
                )
                seed_plan = [
                    (sample_index, epoch)
                    for epoch in range(1, epochs + 1)
                    for sample_index in range(store_len)
                ]
                if sample_feed is not None:
                    # created together with sample_feed's registration above
                    assert sample_enqueuer is not None
                    keyed_results = await run_samples_dynamic(
                        sample_feed, sample_enqueuer, sample_scheduler
                    )
                else:
                    keyed_results = await sample_scheduler.run(seed_plan, run_sample)
                sample_results = list(keyed_results.values())

            # compute and record metrics if we have scores
            completed_scores = [
                score_dict
                for score_dict in sample_results
                if isinstance(score_dict, dict)
            ]

            early_stops = [
                stopped_sample
                for stopped_sample in sample_results
                if isinstance(stopped_sample, EarlyStop)
            ]

            # call early stopping if we have it
            stopping_summary: EarlyStoppingSummary | None = None
            if options.task.early_stopping is not None:
                stopping_metadata = await options.task.early_stopping.complete_task()
                stopping_summary = EarlyStoppingSummary(
                    manager=stopping_manager,
                    early_stops=early_stops,
                    metadata=stopping_metadata,
                )

            if len(completed_scores) > 0:
                results, reductions = eval_results(
                    samples=total_samples,
                    scores=completed_scores,
                    reducers=task.epochs_reducer,
                    scorers=scorers,
                    metrics=task.metrics,
                    scorer_names=scorer_names,
                    early_stopping=stopping_summary,
                    # see eval_results() for why this isn't len(scores)
                    completed_samples=(
                        logger.samples_completed if log_samples else None
                    ),
                    headline_metric=task.headline_metric,
                )

            # collect eval data
            collect_eval_data(stats)

            # use the SampleErrorHandler's authoritative count (incremented in
            # handle_error() exactly once per sample after retries are
            # exhausted). With score_on_error, an errored sample that was still
            # scored returns a populated score dict rather than None, so counting
            # errors via `result is None` would miss them.
            sample_error_count = sample_error_handler.error_count
            mark_log_as_error = _should_eval_fail(
                sample_error_count, total_samples, config.fail_on_error
            )

            # finish
            eval_log = await finish_task_log(
                status="error" if mark_log_as_error else "success",
                stats=stats,
                results=results,
                reductions=reductions,
            )

            await emit_task_end(logger, eval_log)

            # display task summary
            td.complete(
                TaskSuccess(
                    samples_completed=logger.samples_completed,
                    stats=stats,
                    results=results or EvalResults(),
                )
            )

        except anyio.get_cancelled_exc_class():
            with anyio.CancelScope(shield=True):
                # collect eval data
                collect_eval_data(stats)

                # compute partial results from samples that completed
                if len(progress_results) > 0:
                    results, reductions = eval_results(
                        samples=total_samples,
                        scores=list(progress_results.values()),
                        reducers=task.epochs_reducer,
                        scorers=scorers,
                        metrics=task.metrics,
                        scorer_names=scorer_names,
                        # see eval_results() for why this isn't len(scores)
                        completed_samples=(
                            logger.samples_completed if log_samples else None
                        ),
                        headline_metric=task.headline_metric,
                    )

                if task_cancel and task_cancel.cancel_type in ("abort", "retry"):
                    # User-initiated cancel (abort/retry) — log as error so
                    # eval_set doesn't interpret it as external cancellation.
                    # A stamped score/error resolution never fires the task's
                    # cancel scope, so a cancellation arriving with one
                    # pending is external (ctrl+c) and takes the cancelled
                    # path below, preserving its usual semantics.
                    cancel_ex = TerminateTaskError(
                        f"Task cancelled by user ({task_cancel.cancel_type})"
                    )
                    error = eval_error(cancel_ex, TerminateTaskError, cancel_ex, None)
                    eval_log = await finish_task_log(
                        status="error",
                        stats=stats,
                        results=results,
                        reductions=reductions,
                        error=error,
                    )
                    td.complete(
                        TaskError(
                            logger.samples_completed,
                            TerminateTaskError,
                            cancel_ex,
                            None,
                        )
                    )
                else:
                    # External cancellation (ctrl+c)
                    eval_log = await finish_task_log(
                        status="cancelled",
                        stats=stats,
                        results=results,
                        reductions=reductions,
                    )
                    td.complete(TaskCancelled(logger.samples_completed, stats))

        except BaseException as ex:
            if options.debug_errors:
                raise
            else:
                # get exception info
                type, value, traceback = sys.exc_info()
                type = type if type else BaseException
                value = value if value else ex

                # build eval error
                error = eval_error(ex, type, value, traceback)

                # collect eval data
                collect_eval_data(stats)

                # finish with error status
                eval_log = await finish_task_log(
                    status="error",
                    stats=stats,
                    results=results,
                    reductions=reductions,
                    error=error,
                )

                # display it
                td.complete(TaskError(logger.samples_completed, type, value, traceback))

        finally:
            if sample_enqueuer_token is not None:
                clear_sample_enqueuer(sample_enqueuer_token)

            # every sample task has exited by here (the try encloses the task
            # group), so any still-unaccounted samples can no longer record
            finalize_eval(logger.eval.eval_id)

    # cleanup disk sample store if used
    if isinstance(sample_store, DiskSampleStore):
        sample_store.close()

    # notify the view module that an eval just completed
    # (in case we have a view polling for new evals)
    view_notify_eval(logger.location)

    assert eval_log is not None

    try:
        # Log file locations are emitted to the "new" hooks via the "task end" event,
        if (
            await send_telemetry_legacy("eval_log_location", eval_log.location)
            == "not_handled"
        ):
            # Converting the eval log to JSON is expensive. Only do so if
            # eval_log_location was not handled.
            await send_telemetry_legacy("eval_log", eval_log_json_str(eval_log))
    except Exception as ex:
        py_logger.warning(f"Error occurred sending telemetry: {exception_message(ex)}")

    # restore sandbox limits
    reset_sandbox_limits(limit_tokens)

    # notify a TaskSource (if the run has one) that this task is complete
    # (it may return follow-up tasks to add to the run)
    if options.task_source is not None:
        _enqueue_source_tasks(await options.task_source.task_complete(eval_log))

    # return eval log
    return eval_log


def update_metrics_display_fn(
    update_fn: Callable[[list[TaskDisplayMetric]], None],
    initial_interval: float = 0,
    min_interval: float = 0.9,
    display_metrics: bool = True,
    headline_metric: HeadlineMetric | None = None,
) -> Callable[
    [
        int,
        list[ScoresByScorer],
        list[Scorer] | None,
        list[str] | None,
        ScoreReducer | list[ScoreReducer] | None,
        list[Metric | dict[str, list[Metric]]] | dict[str, list[Metric]] | None,
    ],
    None,
]:
    next_compute_time = time.perf_counter() + initial_interval

    def compute(
        sample_count: int,
        sample_scores: list[ScoresByScorer],
        scorers: list[Scorer] | None,
        scorer_names: list[str] | None,
        reducers: ScoreReducer | list[ScoreReducer] | None,
        metrics: list[Metric | dict[str, list[Metric]]]
        | dict[str, list[Metric]]
        | None,
    ) -> None:
        # Don't compute metrics if they are not being displayed
        if not display_metrics:
            return None

        nonlocal next_compute_time
        time_start = time.perf_counter()
        if time_start >= next_compute_time:
            # compute metrics
            results, reductions = eval_results(
                samples=sample_count,
                scores=sample_scores,
                reducers=reducers,
                scorers=scorers,
                metrics=metrics,
                scorer_names=scorer_names,
                headline_metric=headline_metric,
            )

            # Name, reducer, value
            task_metrics: list[TaskDisplayMetric] = []
            if len(results.scores) > 0:
                # the progress line renders metrics[0], so lead with the
                # headline. Marked here, while the originating EvalScore is
                # still in hand and its full identity is available.
                headline_index = -1
                for score in results.scores:
                    for key, metric in score.metrics.items():
                        # first match only: a scorer declaring both plain and
                        # per-key metrics can emit two scores alike in every
                        # field a reference names, and the resolver took the
                        # first of those
                        is_headline = headline_index < 0 and _is_headline(
                            score, key, results.headline
                        )
                        if is_headline:
                            headline_index = len(task_metrics)
                        task_metrics.append(
                            TaskDisplayMetric(
                                scorer=score.name,
                                scorer_name=score.scorer,
                                name=key,
                                value=metric.value,
                                reducer=score.reducer,
                                params=metric.params,
                                headline=is_headline,
                            )
                        )
                if headline_index > 0:
                    task_metrics.insert(0, task_metrics.pop(headline_index))
                update_fn(task_metrics)

            # determine how long to wait before recomputing metrics
            time_end = time.perf_counter()
            elapsed_time = time_end - time_start
            wait = max(min_interval, elapsed_time * 10)
            next_compute_time = time_end + wait

    return compute


def _is_headline(
    score: EvalScore, metric_key: str, headline: HeadlineMetric | None
) -> bool:
    return (
        headline is not None
        and score.scorer == headline.scorer
        and score.name == headline.score
        and score.reducer == headline.reducer
        and metric_key == headline.metric
    )


def _sample_usage(state: TaskState) -> "_SampleUsage":
    """The just-finished sample's ``tokens`` / ``messages`` for the eval totals.

    Model usage is read from the sample-scoped contextvar (still set on this
    coroutine even though the ``active_sample`` context has exited by the
    terminal block). Passed to the `SampleTerminalReporter` terminal methods,
    which accumulate it into the eval totals.
    """
    return _SampleUsage(
        tokens=sum(u.total_tokens for u in sample_model_usage().values()),
        messages=len(state.messages),
    )


def _sample_started() -> float | None:
    """The just-finished sample's start time, for the eval's running-min start.

    Read from the same sample-scoped timing contextvar that backs the logged
    ``started_at`` (set when the sample began, still in scope in the terminal
    block). Passed to ``record_sample_*`` so the eval's reported start pins to
    its first sample even when that sample finished before any control poll
    (see ``EvalState.started_at``). ``None`` for a sample that never started.
    """
    started = sample_start_datetime()
    return started.timestamp() if started is not None else None


async def task_run_sample(
    *,
    task: Task,
    task_name: str,
    log_location: str,
    create_sample_state: Callable[[str | None], Awaitable[tuple[Sample, TaskState]]],
    input_media_plan: TaskInputMediaPlan,
    sandbox: SandboxEnvironmentSpec | None,
    checkpoint: CheckpointConfig | None,
    eval_checkpoint: CheckpointConfig | None,
    resume_checkpoint: ResumeCheckpoint | None,
    max_sandboxes: int | None,
    sandbox_cleanup: bool,
    plan: Plan,
    scorers: list[Scorer] | None,
    scorer_names: list[str] | None,
    scanner: "Scanners | None",
    cleanup: Callable[[TaskState], Awaitable[None]] | None,
    generate: Generate,
    logger: TaskLogger | None,
    log_images: bool,
    log_model_api: bool | None,
    sample_error: SampleErrorHandler,
    reporter: SampleTerminalReporter,
    fails_on_error: bool,
    early_stopping: EarlyStopping | None,
    task_cancel: TaskCancel | None,
    task_source: TaskSource | None,
    sample_feed: SampleSource | None,
    retry_on_error: int,
    score_on_error: bool,
    previous_attempt_errors: list[EvalRetryError],
    turn_limit: int | None,
    time_limit: int | None,
    working_limit: int | None,
    semaphore: contextlib.AbstractAsyncContextManager[Any],
    eval_set_id: str | None,
    run_id: str,
    task_id: str,
    scan_id: str | None = None,
) -> SampleRunResult:
    """Run one sample run as a loop of error-retry attempts.

    An attempt that errors with retries remaining returns a `_SampleRetry`
    (after releasing the sample semaphore), and the loop advances the
    `SampleAttempt` — error history, carried sample uuid — and re-enters;
    the retry re-acquires the semaphore, so it goes to the back of the
    sample queue. Any other attempt outcome is the run's result (terminal
    exceptions — cancellation, fail-on-error — propagate as exceptions).
    See design/sample-lifecycle.md for the run's full state diagram.
    """
    attempt = SampleAttempt(retry_limit=retry_on_error)
    while True:
        result = await _task_run_sample_attempt(
            task=task,
            task_name=task_name,
            log_location=log_location,
            create_sample_state=create_sample_state,
            input_media_plan=input_media_plan,
            sandbox=sandbox,
            checkpoint=checkpoint,
            eval_checkpoint=eval_checkpoint,
            resume_checkpoint=resume_checkpoint,
            max_sandboxes=max_sandboxes,
            sandbox_cleanup=sandbox_cleanup,
            plan=plan,
            scorers=scorers,
            scorer_names=scorer_names,
            scanner=scanner,
            cleanup=cleanup,
            generate=generate,
            logger=logger,
            log_images=log_images,
            log_model_api=log_model_api,
            sample_error=sample_error,
            reporter=reporter,
            fails_on_error=fails_on_error,
            early_stopping=early_stopping,
            task_cancel=task_cancel,
            task_source=task_source,
            sample_feed=sample_feed,
            score_on_error=score_on_error,
            attempt=attempt,
            previous_attempt_errors=previous_attempt_errors,
            turn_limit=turn_limit,
            time_limit=time_limit,
            working_limit=working_limit,
            semaphore=semaphore,
            eval_set_id=eval_set_id,
            run_id=run_id,
            task_id=task_id,
            scan_id=scan_id,
        )
        if isinstance(result, _SampleRetry):
            attempt = attempt.advance(result)
            continue
        return result


async def _task_run_sample_attempt(
    *,
    task: Task,
    task_name: str,
    log_location: str,
    create_sample_state: Callable[[str | None], Awaitable[tuple[Sample, TaskState]]],
    input_media_plan: TaskInputMediaPlan,
    sandbox: SandboxEnvironmentSpec | None,
    checkpoint: CheckpointConfig | None,
    eval_checkpoint: CheckpointConfig | None,
    resume_checkpoint: ResumeCheckpoint | None,
    max_sandboxes: int | None,
    sandbox_cleanup: bool,
    plan: Plan,
    scorers: list[Scorer] | None,
    scorer_names: list[str] | None,
    scanner: "Scanners | None",
    cleanup: Callable[[TaskState], Awaitable[None]] | None,
    generate: Generate,
    logger: TaskLogger | None,
    log_images: bool,
    log_model_api: bool | None,
    sample_error: SampleErrorHandler,
    reporter: SampleTerminalReporter,
    fails_on_error: bool,
    early_stopping: EarlyStopping | None,
    task_cancel: TaskCancel | None,
    task_source: TaskSource | None,
    sample_feed: SampleSource | None,
    score_on_error: bool,
    attempt: SampleAttempt,
    previous_attempt_errors: list[EvalRetryError],
    turn_limit: int | None,
    time_limit: int | None,
    working_limit: int | None,
    semaphore: contextlib.AbstractAsyncContextManager[Any],
    eval_set_id: str | None,
    run_id: str,
    task_id: str,
    scan_id: str | None = None,
) -> SampleRunResult | _SampleRetry:
    from inspect_ai.event import Event
    from inspect_ai.hooks._hooks import (
        drain_sample_events,
        emit_sample_attempt_end,
        emit_sample_attempt_start,
        emit_sample_end,
        emit_sample_event,
        emit_sample_init,
        emit_sample_scoring,
        emit_sample_start,
        start_sample_event_emitter,
    )

    # execute under sample semaphore
    async with semaphore:
        # a task cancel with a graceful sample resolution (score/error) is in
        # flight: this sample never started, so it is abandoned rather than
        # resolved — terminal 'cancelled' for the eval's counters, absent from
        # the log (matching an abort's treatment of still-queued samples)
        if task_cancel is not None and task_cancel.cancel_type in ("score", "error"):
            reporter.cancelled()
            return None

        # materialize sample+state lazily (deferred until semaphore acquired)
        sample, state = await create_sample_state(attempt.sample_uuid)

        # reset at the top of the attempt (not just before the limit scopes
        # open) so that an attempt failing during init doesn't log the prior
        # attempt's snapshot
        reset_sample_limit_data()

        # validate that we have sample_id (mostly for the typechecker)
        sample_id = sample.id
        if sample_id is None:
            raise ValueError("sample must have id to run")

        def on_sample_event(event: Event) -> None:
            if logger:
                logger.log_sample_event(sample_id, state.epoch, event)
            emit_sample_event(
                eval_set_id=eval_set_id,
                run_id=run_id,
                eval_id=task_id,
                sample_id=state.uuid,
                event=event,
            )

        # initialise subtask and scoring context
        init_sample_model_data()
        set_sample_state(state)
        sample_transcript_bounded, history_provider = _sample_transcript_config(
            logger, sample_id, state.epoch
        )
        sample_transcript = Transcript(
            log_model_api=log_model_api,
            bounded=sample_transcript_bounded,
            resident_tail=DEFAULT_RESIDENT_TAIL,
            history_provider=history_provider,
        )
        init_transcript(sample_transcript)
        init_subtask_store(state.store)
        sample_transcript._subscribe(on_sample_event)
        if scorers:
            init_scoring_context(scorers, Target(sample.target))
        init_sample_assistant_internal()

        # use sandbox if provided
        #
        # The sandbox CM's `__aexit__` is wrapped so its teardown runs shielded
        # whenever the sample's own cancel was caught upstream (`cancelled_error`
        # set). Otherwise, the eval-level scope's still-cancelled state would
        # re-cancel the first await inside `cleanup_sandbox_environments_sample`,
        # propagating a fresh CancelledError out past the (already shielded)
        # logging block and dropping the in-flight sample from the eval log.
        sandboxenv_cm = (
            aexit_shielded_when(
                sandboxenv_context(
                    task_name, sandbox, max_sandboxes, sandbox_cleanup, sample
                ),
                lambda: cancelled_error is not None,
            )
            if sandbox or sample.sandbox is not None
            else contextlib.nullcontext()
        )

        # resolve checkpoint config across all three levels with
        # precedence eval > sample > task (per-field merge — see
        # `merge_checkpoint_configs`).
        resolved_checkpoint = merge_checkpoint_configs(
            checkpoint,
            sample.checkpoint,
            eval_checkpoint,
            on_checkpoint=task.on_checkpoint,
            on_resume=task.on_resume,
        )

        # helper to handle exceptions (will throw if we've exceeded the limit)
        def handle_error(ex: BaseException) -> tuple[EvalError, BaseException | None]:
            # helper to log sample error
            def log_sample_error() -> None:
                msg = f"Sample error (id: {sample.id}, epoch: {state.epoch}): {exception_message(ex)})"
                if attempt.retries_remaining > 0:
                    msg = f"{msg}. Sample will be retried."
                elif score_on_error:
                    msg = f"{msg}. Sample will be scored."
                py_logger.warning(msg)

            # if we have retries left then return EvalError
            if attempt.retries_remaining > 0:
                log_sample_error()
                return eval_error(ex, type(ex), ex, ex.__traceback__), None
            else:
                err = sample_error(ex)
                # with score_on_error, suppress the raise so we can score the
                # sample; error_count was still incremented on sample_error()
                # above, so the eval-level fail_on_error threshold continues
                # to apply.
                if score_on_error:
                    log_sample_error()
                    transcript()._event(ErrorEvent(error=err[0]))
                    return err[0], None
                # if we aren't raising the error then print a warning
                if err[1] is None:
                    log_sample_error()
                transcript()._event(ErrorEvent(error=err[0]))
                return err

        # Derive agent name for the ACP picker / TUI meta row.
        agent_name = plan_agent_name(plan)

        async with active_sample(
            task=task_name,
            log_location=log_location,
            model=str(state.model),
            sample=sample,
            epoch=state.epoch,
            message_limit=state.message_limit,
            token_limit=state.token_limit,
            # the metering type is only meaningful when a ceiling is configured
            token_limit_type=state.token_limit_type
            if state.token_limit is not None
            else None,
            cost_limit=state.cost_limit,
            time_limit=time_limit,
            working_limit=working_limit,
            fails_on_error=fails_on_error or (attempt.retries_remaining > 0),
            transcript=sample_transcript,
            checkpoint=resolved_checkpoint,
            resume_checkpoint=resume_checkpoint,
            eval_set_id=eval_set_id,
            run_id=run_id,
            eval_id=task_id,
            agent_name=agent_name,
            # prior failed attempts (task-level seed + sample-level retries),
            # surfaced as the running sample's error history by the control channel
            error_retries=previous_attempt_errors + list(attempt.errors),
            # the uuid the logged EvalSample will carry — lets the control
            # channel keep one event cursor valid across running→terminal
            sample_uuid=state.uuid,
        ) as active:
            # check for early stopping
            if early_stopping is not None and logger is not None:
                early_stop = await early_stopping.schedule_sample(
                    state.sample_id, state.epoch
                )
                if early_stop is not None:
                    # the halt is terminal 'completed' (not an error)
                    await reporter.completed(state.sample_id, state.epoch)
                    return early_stop

            start_time: float | None = None
            error: EvalError | None = None
            raise_error: BaseException | None = None
            cancelled_error: BaseException | None = None
            operator_cancelled = False
            results: ScoresByScorer = {}
            limit: EvalSampleLimit | None = None
            sample_summary: EvalSampleSummary | None = None
            attempt_started = False
            sample_row_started = False
            sample_time_limit: Limit | None = None

            def make_sample_summary() -> EvalSampleSummary:
                return EvalSampleSummary(
                    id=sample_id,
                    epoch=state.epoch,
                    uuid=state.uuid,
                    input=sample.input,
                    choices=sample.choices,
                    target=sample.target,
                    metadata=sample.metadata or {},
                )

            async def emit_attempt_end(will_retry: bool) -> None:
                if sample_summary is None or not attempt_started:
                    return
                await emit_sample_attempt_end(
                    eval_set_id,
                    run_id,
                    task_id,
                    state.uuid,
                    summary=sample_summary,
                    attempt=attempt.number,
                    error=error,
                    will_retry=will_retry,
                )

            # begin init
            init_span = span("init", type="init")
            await init_span.__aenter__()
            cleanup_span: contextlib.AbstractAsyncContextManager[None] | None = (
                init_span
            )

            try:
                # Open the realtime sample row before media I/O so a
                # materialization failure can be logged and retried normally.
                sample_summary = make_sample_summary()
                if logger is not None and sample_id in input_media_plan:
                    await logger.start_sample(sample_summary)
                    sample_row_started = True

                materialized_sample = await materialize_sample_input(
                    sample, input_media_plan
                )
                sample.input = materialized_sample.input
                state = deepcopy(
                    TaskState(
                        sample_id=state.sample_id,
                        epoch=state.epoch,
                        model=state.model,
                        input=sample.input,
                        target=state.target,
                        choices=sample.choices,
                        messages=sample_messages(sample),
                        message_limit=state.message_limit,
                        token_limit=state.token_limit,
                        token_limit_type=state.token_limit_type,
                        cost_limit=state.cost_limit,
                        completed=False,
                        metadata=state.metadata,
                        sample_uuid=state.uuid,
                    )
                )
                set_sample_state(state)
                init_subtask_store(state.store)
                sample_summary = make_sample_summary()

                # sample init event (remove file bodies as they have content or absolute paths)
                event_sample = sample.model_copy(
                    update=dict(files={k: "" for k in sample.files.keys()})
                    if sample.files
                    else None
                )
                transcript()._event(
                    SampleInitEvent(sample=event_sample, state=state_jsonable(state))
                )

                # emit sample init before sandbox creation
                # (only on the first attempt; not re-emitted when the sample is retried after an error)
                if attempt.is_first:
                    await emit_sample_init(
                        eval_set_id,
                        run_id,
                        task_id,
                        state.uuid,
                        sample_summary,
                    )

                async with sandboxenv_cm:
                    try:
                        # update active sample wth sandboxes now that we are initialised
                        # (ensure that we still exit init context in presence of sandbox error)
                        try:
                            # publish the environments (the interim-scoring
                            # pass binds them into its scoring context —
                            # design/ctl/interim-scoring.md) and derive the
                            # VS Code connection info from that same
                            # publication so the two fields can't drift
                            active.sandbox_environments = (
                                sandbox_environments_context_var.get({}) or {}
                            )
                            active.sandboxes = await sandbox_connections(
                                active.sandbox_environments
                            )
                        finally:
                            await init_span.__aexit__(None, None, None)
                            cleanup_span = None

                        # record start time
                        start_time = time.monotonic()
                        init_sample_working_time(start_time)

                        # run sample w/ optional limits. This function's
                        # `task_id` param carries the per-attempt eval id;
                        # the override store wants the stable task id.
                        # Resolved through the eval registry rather than
                        # `logger` — the per-sample logger is None under
                        # --no-log-samples while the control channel stays
                        # fully targetable.
                        override_task_id = stable_task_id_for_eval(task_id)
                        time_limit_node = create_time_limit(time_limit)
                        sample_time_limit = time_limit_node
                        with (
                            sample_limit_override_scope(
                                override_task_id,
                                time=time_limit_node,
                                token=state._token_limit,
                                message=state._message_limit,
                            ),
                            state._token_limit,
                            state._cost_limit,
                            state._message_limit,
                            create_turn_limit(turn_limit),
                            time_limit_node,
                            create_working_limit(working_limit),
                        ):

                            async def run(tg: TaskGroup) -> None:
                                # access to state, limit, and errors
                                nonlocal state, limit, error, raise_error
                                nonlocal cancelled_error, operator_cancelled

                                try:
                                    # start the sample
                                    active.start(tg)

                                    # a task cancel with a graceful sample
                                    # resolution arrived while this sample was
                                    # initializing (after it left the queue,
                                    # before it started — so the control
                                    # layer's interrupt of in-flight samples
                                    # missed it) — resolve it now rather than
                                    # running the plan
                                    resolution = (
                                        task_cancel.cancel_type
                                        if task_cancel is not None
                                        else None
                                    )
                                    if resolution == "score" or resolution == "error":
                                        # an "error" resolution can slip past
                                        # the control layer's fails-on-error
                                        # gate while this sample materializes
                                        # (it is not yet registered in
                                        # active_samples()) — downgrade to
                                        # "score" so the auto-fail the gate
                                        # exists to prevent doesn't fire
                                        if (
                                            resolution == "error"
                                            and active.fails_on_error
                                        ):
                                            resolution = "score"
                                        active.interrupt(resolution)

                                    # monitor working limit in the background
                                    monitor_working_limit()

                                    # start background sample event emitter
                                    start_sample_event_emitter()

                                    # set progress for plan then run it
                                    async with span("solvers"):
                                        state = await plan(state, generate)

                                # some 'cancel' exceptions are actually user interrupts or the
                                # result of monitor_working_limit() - for these exceptions we
                                # want to intercept them and apply the appropriate control flow
                                # so they can continue on and be scored.
                                except anyio.get_cancelled_exc_class() as ex:
                                    if active.interrupt_action:
                                        # record event
                                        interrupt_reason = (
                                            "Sample completed: interrupted by operator"
                                        )
                                        transcript()._event(
                                            SampleLimitEvent(
                                                type="operator",
                                                message=interrupt_reason,
                                            )
                                        )

                                        # handle the action
                                        match active.interrupt_action:
                                            case "score":
                                                # continue to scoring (capture the most recent state)
                                                state = sample_state() or state
                                                limit = EvalSampleLimit(
                                                    type="operator",
                                                    limit=1,
                                                    reason=interrupt_reason,
                                                )
                                            case "error":
                                                # default error handling — but
                                                # with a distinct exception:
                                                # this terminal is counted in
                                                # the *errored* bucket, and
                                                # recording the cancellation
                                                # exception's repr would make
                                                # message-based classification
                                                # (sample show/list, requeue
                                                # reconciliation, retry
                                                # seeding) treat it as
                                                # cancelled
                                                operator_error = RuntimeError(
                                                    "Sample errored: interrupted by operator"
                                                )
                                                operator_error.__cause__ = ex
                                                error, raise_error = handle_error(
                                                    operator_error
                                                )
                                            case "cancel":
                                                # resolve as an external cancel
                                                # would: transcript preserved,
                                                # no scoring, and not counted
                                                # as a genuine error (bypasses
                                                # handle_error / fail_on_error)
                                                operator_cancelled = True
                                                cancelled_error = ex
                                                error = eval_error(
                                                    ex, type(ex), ex, ex.__traceback__
                                                )
                                                transcript()._event(
                                                    ErrorEvent(error=error)
                                                )

                                    elif active.limit_exceeded_error:
                                        err = active.limit_exceeded_error
                                        # Record a SampleLimitEvent ONLY for a working-time
                                        # limit. `sample.limit_exceeded()` (which set
                                        # `limit_exceeded_error` and cancelled us) has two
                                        # callers: monitor_working_limit(), which records no
                                        # event of its own — so here we are its sole recorder
                                        # — and the sandbox service, which surfaces a bridged
                                        # message/token/cost limit that ALREADY recorded its
                                        # own event at its detection point (e.g.
                                        # check_message_limit). Recording the latter here would
                                        # both duplicate that event and mislabel it "working".
                                        if err.type == "working":
                                            transcript()._event(
                                                SampleLimitEvent(
                                                    type=err.type,
                                                    message=err.message,
                                                    limit=err.limit,
                                                )
                                            )

                                        # capture most recent state for scoring
                                        state = sample_state() or state
                                        limit = EvalSampleLimit(
                                            type=err.type,
                                            limit=err.limit
                                            if err.limit is not None
                                            else -1,
                                            reason=err.message,
                                        )

                                    # this was not a user interrupt or working time limit so propagate
                                    else:
                                        raise
                                finally:
                                    # ensures that monitor_working_limit() and any coroutines
                                    # created w/ background() are cancelled
                                    tg.cancel_scope.cancel()

                            try:
                                # emit/log sample start
                                if logger is not None and not sample_row_started:
                                    await logger.start_sample(sample_summary)

                                # only emit the sample start once: not on retries
                                if attempt.is_first:
                                    await emit_sample_start(
                                        eval_set_id,
                                        run_id,
                                        task_id,
                                        state.uuid,
                                        sample_summary,
                                    )

                                await emit_sample_attempt_start(
                                    eval_set_id,
                                    run_id,
                                    task_id,
                                    state.uuid,
                                    sample_summary,
                                    attempt=attempt.number,
                                )
                                attempt_started = True

                                async with anyio.create_task_group() as tg:
                                    tg.start_soon(run, tg)
                            except Exception as ex:
                                raise inner_exception(ex)
                            finally:
                                # capture sample limits
                                record_sample_limit_data(
                                    len((sample_state() or state).messages)
                                )

                    except SandboxTimeoutError as ex:
                        raise RuntimeError(str(ex)) from ex

                    except TimeoutError:
                        # Scoped time limits manifest themselves as LimitExceededError, not
                        # TimeoutError.
                        py_logger.warning(
                            "Unexpected timeout error reached top of sample stack. Are you handling TimeoutError when applying timeouts?"
                        )

                        # capture most recent state for scoring
                        state = sample_state() or state

                    except LimitExceededError as ex:
                        # capture most recent state for scoring
                        state = sample_state() or state
                        limit = EvalSampleLimit(
                            type=ex.type,
                            limit=ex.limit if ex.limit is not None else -1,
                            reason=ex.message,
                        )

                    except TerminateSampleError as ex:
                        # emit event
                        transcript()._event(
                            SampleLimitEvent(
                                type="operator", limit=1, message=ex.reason
                            )
                        )

                        # capture most recent state for scoring
                        state = sample_state() or state
                        limit = EvalSampleLimit(
                            type="operator", limit=1, reason=ex.reason
                        )

                    except anyio.get_cancelled_exc_class() as ex:
                        with anyio.CancelScope(shield=True):
                            cancelled_error = ex
                            # convert to standard error
                            error = eval_error(ex, type(ex), ex, ex.__traceback__)
                            transcript()._event(ErrorEvent(error=error))

                    except Exception as ex:
                        error, raise_error = handle_error(ex)

                    # mark completed
                    state.completed = True

                    # set timeout for scoring. if the original timeout was hit we still
                    # want to provide opportunity for scoring, but we don't necessarily
                    # want to wait the full timeout again (especially in the case where
                    # the cause of the timeout is a hung container and scoring requires
                    # interacting with the container). as a middle ground we use half
                    # of the original timeout value for scoring.
                    scoring_time_limit = time_limit / 2 if time_limit else None

                    set_sample_state(state)
                    if state.scores is None:
                        state.scores = {}
                    solver_score_names = [*state.scores]

                    # scoring
                    with anyio.CancelScope(shield=cancelled_error is not None):
                        await emit_sample_scoring(
                            eval_set_id,
                            run_id,
                            task_id,
                            state.uuid,
                        )
                        try:
                            # timeout during scoring will result in an ordinary sample error
                            with create_time_limit(scoring_time_limit):
                                # score on success, or when score_on_error is on
                                # for the final attempt (no retries left, not cancelled)
                                if error is None or (
                                    score_on_error
                                    and attempt.retries_remaining == 0
                                    and cancelled_error is None
                                ):
                                    async with span(name="scorers"):
                                        for scorer_idx, scorer in enumerate(
                                            scorers or []
                                        ):
                                            scorer_name = (
                                                scorer_names[scorer_idx]
                                                if scorer_names
                                                else unique_scorer_name(
                                                    scorer,
                                                    list(
                                                        {*solver_score_names, *results}
                                                    ),
                                                )
                                            )
                                            async with span(
                                                name=scorer_name, type="scorer"
                                            ):
                                                if not scorer:
                                                    continue
                                                score_result = await scorer(
                                                    state, Target(sample.target)
                                                )
                                                if scorer_name in state.scores:
                                                    raise RuntimeError(
                                                        f"Scorer {scorer_name} has modified state.scores"
                                                    )
                                                if score_result is not None:
                                                    state.scores[scorer_name] = (
                                                        score_result
                                                    )

                                                    transcript()._event(
                                                        ScoreEvent(
                                                            score=score_result,
                                                            target=sample.target,
                                                            scorer=scorer_name,
                                                            scorer_args=registry_params(
                                                                scorer
                                                            )
                                                            if has_registry_params(
                                                                scorer
                                                            )
                                                            else None,
                                                            model_usage=sample_model_usage()
                                                            or None,
                                                            role_usage=sample_role_usage()
                                                            or None,
                                                        )
                                                    )

                                                    results[scorer_name] = SampleScore(
                                                        score=score_result,
                                                        sample_id=sample.id,
                                                        sample_metadata=sample.metadata,
                                                        scorer=registry_unqualified_name(
                                                            scorer
                                                        ),
                                                    )

                                for name in solver_score_names:
                                    score = state.scores[name]
                                    transcript()._event(
                                        ScoreEvent(
                                            score=score,
                                            target=sample.target,
                                            scorer=name,
                                            model_usage=sample_model_usage() or None,
                                            role_usage=sample_role_usage() or None,
                                        )
                                    )
                                    results[name] = SampleScore(
                                        score=score,
                                        sample_id=state.sample_id,
                                        sample_metadata=state.metadata,
                                    )

                        except anyio.get_cancelled_exc_class() as ex:
                            with anyio.CancelScope(shield=True):
                                cancelled_error = ex
                                if active.interrupt_action:
                                    transcript()._event(
                                        SampleLimitEvent(
                                            type="operator",
                                            message="Unable to score sample due to operator interruption",
                                        )
                                    )

                                # convert to standard error
                                error = eval_error(ex, type(ex), ex, ex.__traceback__)
                                transcript()._event(ErrorEvent(error=error))

                        except Exception as ex:
                            if active.interrupt_action is not None:
                                # Operator-interrupted: log to transcript but
                                # don't propagate to error/retry. The operator
                                # EvalSampleLimit is set in the run() handler.
                                scorer_error = eval_error(
                                    ex, type(ex), ex, ex.__traceback__
                                )
                                transcript()._event(ErrorEvent(error=scorer_error))
                            else:
                                error, raise_error = handle_error(ex)
                        finally:
                            # run task cleanup if required (inside sandbox context)
                            if cleanup is not None:
                                with anyio.CancelScope(shield=True):
                                    try:
                                        await cleanup(state)
                                    except Exception as ex:
                                        py_logger.warning(
                                            f"Exception occurred during task cleanup: {ex}",
                                            exc_info=ex,
                                        )

            except Exception as ex:
                error, raise_error = handle_error(ex)
            finally:
                # cleanup the task init span if required
                if cleanup_span is not None:
                    with anyio.CancelScope(shield=cancelled_error is not None):
                        await cleanup_span.__aexit__(None, None, None)

            # complete the sample if there is no error or if there is no retry_on_error in play
            with anyio.CancelScope(shield=cancelled_error is not None):
                # drain sample events for both completion and retry paths
                await drain_sample_events()

                if (
                    not error
                    or (attempt.retries_remaining == 0)
                    or (cancelled_error is not None)
                ):
                    reporter.progress()

                    # ensure there are no base64 images in sample or messages
                    if not log_images:
                        sample = sample_without_base64_content(sample)
                        state = state_without_base64_content(state)

                    # emit/log sample end
                    def make_eval_sample(include_events: bool = True) -> EvalSample:
                        # the effective time limit, read off the sample's root
                        # time node so it resolves a live retune exactly as the
                        # message/token ceilings do through the state's limit
                        # nodes; a sample that failed before its limit scopes
                        # were created stamps the launch value (as the other
                        # ceilings do)
                        if sample_time_limit is not None:
                            effective_time_limit = (
                                round(sample_time_limit.limit)
                                if sample_time_limit.limit is not None
                                else None
                            )
                        else:
                            effective_time_limit = time_limit
                        return create_eval_sample(
                            start_time=start_time,
                            sample=sample,
                            state=state,
                            scores=results,
                            error=error,
                            limit=limit,
                            # the logged sample carries the full retry history:
                            # prior task attempts followed by this eval's
                            # sample-level retries
                            error_retries=previous_attempt_errors
                            + list(attempt.errors),
                            time_limit=effective_time_limit,
                            started_at=sample_start_datetime(),
                            include_events=include_events,
                        )

                    with anyio.CancelScope(
                        shield=error is not None or cancelled_error is not None
                    ):
                        if logger:
                            # When the full event history is still resident in
                            # memory we can log the sample directly from memory
                            # rather than reading every event back out of the
                            # realtime buffer DB and re-validating it. This is the
                            # case whenever realtime logging is off (no buffer DB)
                            # OR the transcript was not bounded-evicted (events
                            # never exceeded the resident tail — the common case for
                            # high-throughput runs). Only fall back to the streaming
                            # read-back when events were actually evicted.
                            log_from_memory = (
                                logger.buffer_db is None
                                or not sample_transcript.history.resident_events_truncated
                            )
                            eval_sample = await log_sample(
                                eval_sample=make_eval_sample(
                                    include_events=log_from_memory
                                ),
                                logger=logger,
                                log_images=log_images,
                                from_memory=log_from_memory,
                            )
                        else:
                            eval_sample = make_eval_sample()
                        await scan_eval_sample(
                            eval_sample,
                            scanner,
                            scan_id=scan_id,
                            eval_id=task_id,
                            log_location=log_location,
                            model=str(state.model),
                            eval_spec=logger.eval if logger else None,
                        )
                        await emit_attempt_end(will_retry=False)
                        await emit_sample_end(
                            eval_set_id, run_id, task_id, state.uuid, eval_sample
                        )
                    # notify the task's SampleSource (if it has one) as each
                    # sample completes, so it can react in real time (and add
                    # samples to the running task). skipped for a cancelled
                    # sample: the task is unwinding (any follow-ups could
                    # never run) and this scope is shielded, so awaiting user
                    # callback code here would be uncancellable
                    if sample_feed is not None and cancelled_error is None:
                        _enqueue_source_samples(
                            await sample_feed.sample_complete(eval_sample)
                        )
                    # notify a TaskSource (if the run has one) as each sample
                    # completes, so it can react in real time (and add tasks)
                    if task_source is not None:
                        _enqueue_source_tasks(
                            await task_source.sample_complete(eval_sample, task)
                        )

    # error that should be retried (we return the retry signal outside of the
    # semaphore scope above so the retry re-acquires the semaphore -- it will
    # therefore go to the back of the sample queue)
    if (
        error
        and attempt.retries_remaining > 0
        and cancelled_error is None
        and active.interrupt_action is None
    ):
        await emit_attempt_end(will_retry=True)

        retry_error = _eval_retry_error(error, logger, state.sample_id, state.epoch)

        # remove any buffered sample events
        if logger is not None:
            logger.remove_sample(state.sample_id, state.epoch)

        # hand the error back to the task_run_sample loop, which advances the
        # attempt (appending the error, carrying the uuid) and re-enters
        return _SampleRetry(error=retry_error, sample_uuid=state.uuid)

    # an interrupt (task-cancel sweep or per-sample cancel) landed in the
    # drain window between this attempt's task-group exit and the retry
    # decision above: its cancel-scope fire was a no-op (the group had
    # already exited), so it only stamped `interrupt_action`, rightly
    # suppressing the retry. The sample was never logged (the logging block
    # skips errored samples with retries remaining), so counting it errored
    # would leave an errored count with no log record and leak its buffered
    # events — resolve it instead exactly as the interrupt landing a moment
    # later (at the retry attempt's queue check) would: abandoned as
    # cancelled, absent from the log, buffered events removed.
    elif error and attempt.retries_remaining > 0 and cancelled_error is None:
        await emit_attempt_end(will_retry=False)

        # remove any buffered sample events
        if logger is not None:
            logger.remove_sample(state.sample_id, state.epoch)

        reporter.cancelled(started=_sample_started(), usage=_sample_usage(state))
        return None

    # re-raise cancellation after logging to preserve structured concurrency
    elif cancelled_error is not None:
        # a cancelled sample is terminal but not a genuine error — count it so
        # the eval can reach `total` and be marked finished (eg. a final-attempt
        # failure that cancels an in-flight sibling)
        reporter.cancelled(started=_sample_started(), usage=_sample_usage(state))
        # an operator 'cancel' interrupt is sample-scoped: the cancellation
        # came from this sample's own task group (already absorbed at its
        # exit), so there is nothing to re-raise — re-raising here would tear
        # down the whole task. Keyed on the disposition captured when the
        # interrupt was handled, not the live `active.interrupt_action`, which
        # a later cancel directive could overwrite while this sample is still
        # inside its (shielded) logging window.
        if operator_cancelled:
            return None
        raise cancelled_error

    # no error
    elif error is None:
        await reporter.completed(
            state.sample_id,
            state.epoch,
            results,
            started=_sample_started(),
            usage=_sample_usage(state),
        )
        return results

    # we have an error and should raise it
    elif raise_error is not None:
        # no scores reported even if the sample was scored: raising fails
        # the whole eval, whose log finishes with results=None (metrics are
        # never computed), so there is nothing for the scores to contribute
        # to — and notifying early stopping/progress for a dying task would
        # mislead. the scores are still in the sample log written above.
        await reporter.errored(
            state.sample_id,
            state.epoch,
            started=_sample_started(),
            usage=_sample_usage(state),
        )
        raise raise_error

    # we have an error and should not raise it
    else:
        # the sample may have scores despite the error: score_on_error scoring
        # of its partial state, scores a solver wrote to state.scores before a
        # later error, or scores from scorers that completed before another
        # raised. those scores are already in the sample log, so surface them
        # here too — the log and metrics should never diverge (mirrors the
        # `error is None` branch above and matches docs/handling-errors.qmd)
        await reporter.errored(
            state.sample_id,
            state.epoch,
            results or None,
            started=_sample_started(),
            usage=_sample_usage(state),
        )
        return results if results else None


def create_eval_sample(
    start_time: float | None,
    sample: Sample,
    state: TaskState,
    scores: ScoresByScorer,
    error: EvalError | None,
    limit: EvalSampleLimit | None,
    error_retries: list[EvalRetryError],
    time_limit: int | None,
    started_at: datetime | None = None,
    include_events: bool = True,
) -> EvalSample:
    # sample must have id to be logged
    id = sample.id
    if id is None:
        raise ValueError(
            f"Samples without IDs cannot be logged: {to_json_str_safe(sample)}"
        )

    # construct sample for logging

    # compute total time if we can
    total_time = time.monotonic() - start_time if start_time is not None else None

    return EvalSample(
        id=id,
        epoch=state.epoch,
        input=sample.input,
        choices=sample.choices,
        target=sample.target,
        metadata=state.metadata or {},
        sandbox=sample.sandbox,
        files=list(sample.files.keys()) if sample.files else None,
        setup=sample.setup,
        messages=state.messages,
        output=state.output,
        scores={k: v.score for k, v in scores.items()},
        store=dict(state.store.items()),
        uuid=state.uuid,
        events=list(transcript().events) if include_events else [],
        timelines=list(transcript().timelines) or None,
        attachments=dict(transcript().attachments),
        model_usage=sample_model_usage(),
        role_usage=sample_role_usage(),
        model_fallbacks=sample_model_fallbacks() or None,
        turn_count=turn_count(),
        token_limit=state.token_limit,
        token_limit_type=state.token_limit_type
        if state.token_limit is not None
        else None,
        token_limit_usage=token_limit_usage(),
        message_limit=state.message_limit,
        time_limit=time_limit,
        started_at=started_at.isoformat() if started_at is not None else None,
        completed_at=datetime.now(timezone.utc).isoformat(),
        total_time=round(total_time, 3) if total_time is not None else None,
        working_time=round(total_time - sample_waiting_time(), 3)
        if total_time is not None
        else None,
        error=error,
        error_retries=error_retries,
        limit=limit,
    )


async def log_sample(
    eval_sample: EvalSample,
    logger: TaskLogger,
    log_images: bool,
    *,
    from_memory: bool,
) -> EvalSample:
    # No realtime buffer DB, or the full history is still resident in memory:
    # log directly from the in-memory sample (which carries its events). This
    # avoids the open_sample_history -> materialize_streaming_sample round-trip
    # (read every event back out of SQLite + re-validate). `complete_sample`
    # still finalizes the buffer DB via `_finalize_sample`, so when a realtime
    # buffer exists it stays consistent for live viewing.
    if logger.buffer_db is None or from_memory:
        await logger.complete_sample(
            condense_sample(eval_sample, log_images), flush=True
        )
        return eval_sample

    # Events were bounded-evicted from memory: stream them back from the buffer
    # DB (the only place the full history still lives) without re-materializing
    # the whole sample in memory at once.
    logging_sample = condense_sample(
        eval_sample.model_copy(update={"events": [], "events_data": None}),
        log_images,
    )
    with logger.buffer_db.open_sample_history(
        eval_sample.id, eval_sample.epoch
    ) as sample_history:
        materialized_sample = materialize_streaming_sample(eval_sample, sample_history)
        await logger.complete_sample_streaming(
            logging_sample, sample_history, flush=True
        )
    return materialized_sample


async def _resume_if_checkpointed(
    eval_checkpoints_dir: str | None, id: int | str, epoch: int
) -> ResumeCheckpoint | None:
    """The sample's on-disk checkpoint resume, or ``None`` when unavailable.

    Shared by the task-retry sample source (`eval_log_sample_source`) and
    the requeue re-run path in `run_sample`, so both seed a re-run from a
    checkpoint the same way.
    """
    if eval_checkpoints_dir is None:
        return None
    if not await has_sample_checkpoint(eval_checkpoints_dir, id, epoch):
        return None
    prior_sample_dir = sample_checkpoints_dir(eval_checkpoints_dir, id, epoch)
    # Latest parseable checkpoint with ``trigger == "agent_complete"`` =
    # agent finished cleanly, scoring is the next thing → retry can
    # skip the agent loop (the ``"resume_for_scoring"`` attempt).
    checkpoint = await scan_latest_committed_checkpoint(prior_sample_dir)
    attempt: Literal["initial", "resume", "resume_for_scoring"] = (
        "resume_for_scoring"
        if checkpoint is not None and checkpoint.trigger == "agent_complete"
        else "resume"
    )
    return ResumeCheckpoint(
        sample_checkpoints_dir=prior_sample_dir,
        attempt=attempt,
    )


# we can reuse samples from a previous eval_log if and only if:
#   - The datasets have not been shuffled OR the samples in the dataset have unique ids
#   - The datasets have the exact same length
def eval_log_sample_source(
    eval_log: EvalLog | None,
    eval_log_info: EvalLogInfo | None,
    dataset: Dataset,
    eval_checkpoints_dir: str | None = None,
) -> EvalSampleSource:
    # return dummy function for no sample source
    async def no_sample_source(id: int | str, epoch: int) -> None:
        return None

    async def no_error_history() -> set[tuple[int | str, int]]:
        return set()

    async def error_history_from_file() -> set[tuple[int | str, int]]:
        """The prior log's errored `(id, epoch)` pairs, from its summaries.

        One bounded read of the summaries index — never per-sample log
        reads. Degrades to "no candidates" on failure: this feeds teardown
        carry-forward, which must not fail (or stall) task shutdown.
        """
        assert eval_log_info is not None
        try:
            summaries = await read_eval_log_sample_summaries_async(eval_log_info)
            return {(s.id, s.epoch) for s in summaries if s.error is not None}
        except Exception as ex:
            py_logger.warning(
                f"Unable to read sample summaries from retry log file: {ex}"
            )
            return set()

    async def _resume_or_seed_retry(
        id: int | str, epoch: int, sample: EvalSample | None
    ) -> ResumeCheckpoint | PreviousError | None:
        """Resolve a non-clean prior sample (errored, invalidated, or absent).

        Prefers resuming from an on-disk checkpoint. Failing that, an
        errored prior sample yields a `PreviousError` so the re-run seeds
        its `error_retries` with the prior attempt's history; an absent or
        invalidated sample yields `None` (re-run fresh).
        """
        resume = await _resume_if_checkpointed(eval_checkpoints_dir, id, epoch)
        if resume is not None:
            return resume
        if (
            sample is not None
            and sample.error is not None
            and _seed_error_retries(sample)
        ):
            return PreviousError(sample=sample)
        return None

    # take care of no log or no samples in log. Note we still proceed when
    # in-memory samples and `eval_log_info` are both absent if a
    # `eval_checkpoints_dir` is available — the prior eval may have been
    # killed before writing any sample, and on-disk checkpoint files
    # can still drive resume detection in `read_from_memory` below.
    if not eval_log:
        return EvalSampleSource(no_sample_source, no_error_history)
    elif not eval_log.samples and not eval_log_info and not eval_checkpoints_dir:
        return EvalSampleSource(no_sample_source, no_error_history)

    # determine whether all samples in the dataset have ids (if not, then we can't
    # provide a sample source in the case where either dataset is shuffled, as the ids
    # will be auto-assigned based on position, and therefore not stable)
    samples_have_ids = (
        next((sample for sample in dataset if sample.id is None), None) is None
    )

    if (eval_log.eval.dataset.shuffled or dataset.shuffled) and not samples_have_ids:
        py_logger.warning(
            "Unable to re-use samples from retry log file because the dataset was shuffled "
            + "and some samples in the dataset do not have an 'id' field."
        )
        return EvalSampleSource(no_sample_source, no_error_history)

    elif eval_log.eval.dataset.samples != len(dataset):
        py_logger.warning(
            "Unable to re-use samples from retry log file because the dataset size changed "
            + f"(log samples {eval_log.eval.dataset.samples}, dataset samples {len(dataset)})"
        )
        return EvalSampleSource(no_sample_source, no_error_history)
    elif eval_log_info:
        reader: AsyncZipReader | None = None
        prior_entry_names: set[str] | None = None
        probe_failures = 0
        # serializes the central-directory fetch across concurrent probes:
        # all run_sample coroutines probe at once, and without this lock each
        # would pass the failure-cap check while the count is still 0, then
        # perform its own fetch attempt (entries() caches only success) —
        # N attempts instead of PRIOR_PROBE_MAX_FAILURES
        probe_lock = anyio.Lock()

        async def read_from_file(
            id: int | str, epoch: int
        ) -> EvalSample | ResumeCheckpoint | PreviousError | None:
            nonlocal reader
            if not reader:
                reader = AsyncZipReader(get_async_filesystem(), eval_log_info.name)
            try:
                sample = await read_eval_log_sample_async(
                    eval_log_info, id, epoch, reader=reader
                )
            except (IndexError, FileNotFoundError):
                # IndexError: sample not present in the log. FileNotFoundError:
                # the log file itself was never written (the prior attempt
                # failed before its first flush, e.g. an errored log_start()).
                # Either way there is no prior sample to reuse.
                return await _resume_if_checkpointed(eval_checkpoints_dir, id, epoch)
            if sample.error is None and sample.invalidation is None:
                return sample
            return await _resume_or_seed_retry(id, epoch, sample)

        async def prior_exists_in_file(id: int | str, epoch: int) -> bool:
            """Presence of the prior sample's zip entry, without a body read.

            Shares `read_from_file`'s reader, whose central directory is
            fetched once and cached — index-only, so it's safe to call for
            every planned sample before deciding to take the throttled body
            read. Presence is broader than "reusable": an errored or
            invalidated prior sample is a presence hit too (error status
            lives in the sample body) — accepted, since errored transcripts
            can be as large as completed ones and equally need bounded
            concurrent residency. A missing prior log (the prior attempt
            failed before its first flush) definitively has no entries, so
            no-presence is cached and the unthrottled lookup surfaces the
            same condition. Any other fetch failure may be transient, so
            it is retried on subsequent probes — up to
            PRIOR_PROBE_MAX_FAILURES, so a persistently unreadable log
            isn't re-fetched per probe — before giving up with a warning
            that the reuse read throttle is disabled for this retry.
            """
            nonlocal reader, prior_entry_names, probe_failures
            if prior_entry_names is None:
                async with probe_lock:
                    # re-check under the lock: another probe may have resolved
                    # (or exhausted the cap for) the fetch while we queued
                    if prior_entry_names is None:
                        if probe_failures >= PRIOR_PROBE_MAX_FAILURES:
                            return False
                        if not reader:
                            reader = AsyncZipReader(
                                get_async_filesystem(), eval_log_info.name
                            )
                        try:
                            cd = await reader.entries()
                            prior_entry_names = {e.filename for e in cd.entries}
                        except FileNotFoundError:
                            prior_entry_names = set()
                        except Exception as ex:
                            probe_failures += 1
                            if probe_failures >= PRIOR_PROBE_MAX_FAILURES:
                                py_logger.warning(
                                    "Unable to read the retry log file's central directory "
                                    + f"after {probe_failures} attempts — reused sample reads "
                                    + f"will not be throttled for this retry: {ex}"
                                )
                            return False
            return _sample_filename(id, epoch) in prior_entry_names

        return EvalSampleSource(
            read_from_file,
            error_history_from_file,
            # presence probing reads the zip central directory, so it only
            # applies to .eval prior logs; a .json prior log keeps the
            # default never-probe (its lookups read the whole file — no
            # index exists to answer presence cheaply)
            prior_exists_in_file
            if EvalRecorder.handles_location(eval_log_info.name)
            else _never_prior_exists,
        )
    else:

        async def read_from_memory(
            id: int | str, epoch: int
        ) -> EvalSample | ResumeCheckpoint | PreviousError | None:
            match = next(
                (
                    sample
                    for sample in (eval_log.samples or [])
                    if sample.id == id and sample.epoch == epoch
                ),
                None,
            )
            if match is not None and match.error is None and match.invalidation is None:
                return match
            return await _resume_or_seed_retry(id, epoch, match)

        memory_error_ids = {
            (sample.id, sample.epoch)
            for sample in (eval_log.samples or [])
            if sample.error is not None
        }

        async def memory_error_history() -> set[tuple[int | str, int]]:
            return memory_error_ids

        return EvalSampleSource(read_from_memory, memory_error_history)


def create_sample_semaphore(
    config: EvalConfig,
    generate_config: GenerateConfig,
    modelapi: ModelAPI | None = None,
    task_id: str | None = None,
) -> contextlib.AbstractAsyncContextManager[Any]:
    """Create (or reuse) the task's sample-concurrency semaphore.

    Bounds how many samples run at once so setup work (sandboxes, state)
    stays proportional to what the model can actually serve: an explicit
    ``max_samples`` is honored as a user setpoint; otherwise the adaptive
    path follows the model's connection controller, and the static path
    defaults from ``max_connections`` (so the connection pool always
    saturates).

    ``generate_config`` must be the model-composed config
    (``model.config.merge(task_config)``, the same composition
    ``Model._resolve_config`` applies) — classifying from the task-level
    config alone would disagree with the generate path when the model
    carries its own ``max_connections`` / ``adaptive_connections``,
    coupling sample concurrency to a controller generates never use (see
    ``ensure_model_controller`` for the same contract on the eager side).

    Semaphores are task-scoped, not attempt-scoped: they're registered under
    ``task_id`` and an in-process retry reuses its predecessor's semaphore,
    so a mid-flight ``ctl config --max-samples`` retune survives the retry
    rather than silently reverting to the config value (see the registry's
    rationale in ``_concurrency.py``). The control channel's modify-limits
    directive reads and retunes ``max_samples`` through this same registry
    entry.
    """
    from inspect_ai.model._model import model_concurrency_key
    from inspect_ai.util._concurrency import (
        DynamicSampleLimiter,
        ResizableLimiter,
        adaptive_active,
        register_task_sample_semaphore,
        resolve_adaptive,
        task_sample_semaphore,
    )

    # sample semaphores are task-scoped, not attempt-scoped: an in-process
    # retry reuses its predecessor's semaphore so a mid-flight `ctl config
    # --max-samples` retune survives the retry rather than silently reverting
    # to the config value (see the registry's rationale in _concurrency.py)
    if task_id is not None:
        existing = task_sample_semaphore(task_id)
        if existing is not None:
            return existing

    semaphore: "ResizableLimiter | DynamicSampleLimiter"
    if config.max_samples is not None:
        # explicit max_samples wins silently — under default-on
        # adaptive_connections, warning when max_samples < adaptive.max
        # would fire for nearly every deliberate max_samples setting.
        # ResizableLimiter (not a fixed Semaphore) so the control channel can
        # retune max_samples mid-eval (see design/ctl/control-channel.md phase 3).
        semaphore = ResizableLimiter(config.max_samples)
    elif adaptive_active(
        generate_config.adaptive_connections,
        generate_config.max_connections,
        generate_config.batch,
    ):
        # adaptive: dynamic limiter that tracks this model's controller —
        # sample concurrency grows with the controller's current limit so setup
        # work (sandboxes etc.) stays proportional to actual model concurrency.
        # The connection-pool key scopes the limiter to the task's own model's
        # controller: controllers for other models in the process (graders,
        # eval-set siblings) must not drive it. Without a ModelAPI (tests) the
        # sentinel key matches no controller and the limiter stays at its
        # initial value.
        # Both explicit max_connections and batch mode silently override
        # adaptive (matches the precedence in Model._connection_concurrency).
        semaphore = DynamicSampleLimiter(
            resolve_adaptive(generate_config.adaptive_connections),
            model_concurrency_key(modelapi) if modelapi else "<no-model>",
        )
    else:
        # static path (default max_samples derived from max_connections).
        # ResizableLimiter so the control channel can retune it mid-eval.
        max_samples = (
            generate_config.max_connections
            if generate_config.max_connections is not None
            else DEFAULT_MAX_CONNECTIONS_BATCH
            if generate_config.batch
            else modelapi.max_connections()
            if modelapi
            else DEFAULT_MAX_CONNECTIONS
        )
        semaphore = ResizableLimiter(max_samples)

    if task_id is not None:
        register_task_sample_semaphore(task_id, semaphore)
    return semaphore


def _eval_retry_error(
    error: EvalError,
    logger: TaskLogger | None = None,
    sample_id: str | int | None = None,
    epoch: int | None = None,
) -> EvalRetryError:
    """Create retry error with events from the most recent ModelEvent onward."""
    from inspect_ai.event._model import ModelEvent

    if logger is not None and logger.buffer_db is not None and sample_id is not None:
        if epoch is None:
            raise ValueError(
                "epoch is required when reading retry events from buffer DB"
            )
        with logger.buffer_db.open_sample_history(sample_id, epoch) as sample_history:
            return eval_retry_error_from_history(error, sample_history)

    sample_transcript = transcript()
    transcript_history = sample_transcript.history
    recent_events = (
        transcript_history.events_since_last(ModelEvent)
        if transcript_history.full_history_available
        else []
    )
    return EvalRetryError(
        message=error.message,
        traceback=error.traceback,
        traceback_ansi=error.traceback_ansi,
        events=recent_events,
    )


def _eval_retry_error_from_sample(sample: EvalSample) -> EvalRetryError:
    """Build an `EvalRetryError` from a prior attempt's errored sample.

    Mirrors `_eval_retry_error` (events back to the last ModelEvent) but
    sources the error and events from a stored sample read via the sample
    source rather than the live transcript.
    """
    from inspect_ai.event._model import ModelEvent

    assert sample.error is not None
    events = sample.events or []
    recent_events = list(events)
    for i in range(len(events) - 1, -1, -1):
        if isinstance(events[i], ModelEvent):
            recent_events = list(events[i:])
            break
    recent_events = resolve_events_attachments(
        recent_events, sample.attachments, "full"
    )
    return EvalRetryError(
        message=sample.error.message,
        traceback=sample.error.traceback,
        traceback_ansi=sample.error.traceback_ansi,
        events=recent_events,
    )


def _is_cancellation_error(error: EvalError) -> bool:
    # A sample cancelled because a sibling errored (the task was torn down
    # for a task-level retry) never genuinely failed, so it must not count
    # as a retry when the task is re-run.
    return is_cancellation_message(error.message)


def _seed_error_retries(sample: EvalSample) -> list[EvalRetryError]:
    """Prior-attempt retry history to seed a re-run's `error_retries`.

    Carries forward the sample's own `error_retries` (genuine failures from
    earlier attempts) and appends the terminal error — but only when that
    error is a genuine failure. A cancellation (sibling failure tore the
    task down) is skipped so it doesn't inflate the retry count.
    """
    seed = list(sample.error_retries or [])
    if sample.error is not None and not _is_cancellation_error(sample.error):
        seed.append(_eval_retry_error_from_sample(sample))
    return seed


async def carry_forward_unlogged_samples(
    logger: TaskLogger,
    sample_source: EvalSampleSource | None,
    sample_ids: list[str | int],
    epochs: int,
    log_images: bool,
) -> None:
    """Re-log carried error history for planned samples this attempt never logged.

    When a task fails and is retried, the next attempt's sample source is
    built from THIS attempt's log. A sample that errored in an earlier
    attempt but was still pending when this attempt was torn down (a sibling
    failed first, cancelling the rest) would otherwise be absent from this
    log — breaking the per-attempt retry-history chain so the eventual
    surviving sample under-reports its retry count.

    Re-logging the prior record for such samples keeps the chain intact.
    Only samples carrying genuine error history (`PreviousError`) need this,
    and only the prior attempt's *errored* samples can yield one — so the
    probe set is ``sample_source.error_history_ids()`` (at most one
    summaries read) rather than the full plan. This runs at teardown,
    inside the cancellation shield on the Ctrl-C path: probing every
    planned ``(id, epoch)`` stalled shutdown of a large remote retry for
    minutes, uninterruptibly.
    """
    if sample_source is None:
        return
    candidates = await sample_source.error_history_ids()
    if not candidates:
        return
    summaries = await logger.sample_summaries()
    logged = {(s.id, s.epoch) for s in (summaries or [])}
    planned = {
        (sample_id, epoch) for sample_id in sample_ids for epoch in range(1, epochs + 1)
    }
    # sorted for a deterministic re-log order
    for sample_id, epoch in sorted(candidates, key=lambda k: (str(k[0]), k[1])):
        if (sample_id, epoch) in logged or (sample_id, epoch) not in planned:
            continue
        previous = await sample_source.lookup(sample_id, epoch)
        if isinstance(previous, PreviousError):
            await logger.complete_sample(
                condense_sample(previous.sample, log_images), flush=True
            )


async def _finish_task_log(
    *,
    logger: TaskLogger,
    sample_source: EvalSampleSource | None,
    sample_ids: list[str | int],
    epochs: int,
    log_images: bool,
    status: EvalStatus,
    stats: EvalStats,
    results: EvalResults | None = None,
    reductions: list[EvalSampleReductions] | None = None,
    error: EvalError | None = None,
) -> EvalLog:
    """Finish the task log, preserving retry history first on non-success.

    The single finish chokepoint for ``task_run``'s terminal branches: any
    non-success finish is (or may be) a teardown that left planned samples
    unlogged this attempt, and this attempt's log seeds the next attempt — so
    unlogged samples' prior-attempt history is carried forward before the
    finish is written. Routing every terminal branch through here means a
    finish path can't forget the carry-forward (the external-cancellation
    branch once did, silently dropping retry history on Ctrl-C — and
    cancelled logs ARE retry seeds: ``retryable_eval_logs`` includes them and
    eval-set treats any non-success log as incomplete).

    Safe to call on fully-logged attempts (eg. an ``error`` status from the
    ``fail_on_error`` threshold with every sample run): the carry-forward
    re-logs only planned samples absent from this attempt's log whose source
    carries genuine prior error history (``PreviousError``), so it degrades
    to a no-op.
    """
    if status != "success":
        await carry_forward_unlogged_samples(
            logger, sample_source, sample_ids, epochs, log_images
        )
    return await logger.log_finish(status, stats, results, reductions, error)
