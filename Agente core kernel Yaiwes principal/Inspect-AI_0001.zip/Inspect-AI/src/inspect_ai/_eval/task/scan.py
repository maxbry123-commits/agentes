"""Per-sample scanner dispatch within `eval_set`.

See `design/eval-set-scanners.md` for the full design.
"""

import contextlib
import hashlib
from collections.abc import Iterator, Sequence
from typing import TYPE_CHECKING, Any, TypeAlias

from pydantic import BaseModel, ConfigDict, Field

from inspect_ai._util._async import run_coroutine
from inspect_ai._util.file import absolute_file_path, dirname, exists
from inspect_ai._util.json import to_json_safe
from inspect_ai.log._log import EvalSample, EvalSpec

# Key used in `ScanSpec.metadata` to track inspect_ai-side scanner config
# that isn't captured by scout's `ScannerSpec`. Compared at scan_init's
# attach branch; mismatch raises `PrerequisiteError` so a config change
# can't silently leave historical transcripts unscanned.
_INSPECT_CONFIG_HASH_KEY = "__inspect_scan_config_hash__"


_REQUIRED_SCOUT_VERSION = "0.4.37"


def verify_scout_prerequisites() -> None:
    """Raise `PrerequisiteError` if `inspect_scout` is missing or outdated.

    Scanner support is an optional feature; called at every user-facing
    entry point that dispatches to scout so the unset / outdated case
    yields a pip-install message instead of an ImportError from a lazy
    import (or a confusing AttributeError from a stale version).
    """
    try:
        import inspect_scout  # noqa: F401
    except ImportError:
        from inspect_ai._util.error import pip_dependency_error

        raise pip_dependency_error("Scanner support", ["inspect-scout"])

    from inspect_ai._util.version import verify_required_version

    verify_required_version("Scanner support", "inspect-scout", _REQUIRED_SCOUT_VERSION)


if TYPE_CHECKING:
    from inspect_scout import Scanner
    from inspect_scout._scanspec import ScanSpec


class ScannerConfig(BaseModel):
    """Configure scanners attached to an `eval_set` run.

    A subset of scout's `ScanJob` / `ScanJobConfig` schema, narrowed to
    the fields that make sense when `eval_set` is generating the
    transcripts.
    """

    # Fields from scout's `ScanJob` / `ScanJobConfig` are intentionally
    # omitted (rather than rejected at runtime) when they don't fit
    # eval_set's per-sample dispatch model:
    # - `transcripts` / `worklist`: would fight per-sample dispatch.
    # - `limit` / `shuffle` / `max_processes` / `max_transcripts`:
    #   sample-selection and concurrency knobs that belong to the eval.
    # - `validation`: needs labelled ground truth, which eval-generated
    #   transcripts don't have.
    # - `log_level`: collides with `eval_set`'s own logging setup.

    model_config = ConfigDict(arbitrary_types_allowed=True, extra="forbid")

    scanners: Any
    """Scanners to run.

    `Sequence[Scanner | tuple[str, Scanner]]` for direct construction,
    `dict[str, Scanner]` for named scanners, or scout `ScannerSpec`
    references when loading from YAML/JSON config.
    """

    name: str | None = Field(default=None)
    """Override the scan name written to `_scan.json` (defaults to
    "eval_set")."""

    scans: str | None = Field(default=None)
    """Override scan output location. Defaults to `<log_dir>/scans/`."""

    tags: list[str] | None = Field(default=None)
    """Tags written to the scan spec."""

    metadata: dict[str, Any] | None = Field(default=None)
    """Metadata written to the scan spec."""

    filter: str | list[str] = Field(default_factory=list)
    """SQL WHERE clause(s) applied per-sample to skip transcripts that
    don't match (e.g. `"error = ''"` to scan only successful samples).
    Mirrors scout's `Transcripts.where(...)` semantics."""

    model: Any = Field(default=None)
    """Model used by scanners' `get_model()`. Overrides the eval's
    active model just for the scanner call. `str | Model | None`."""

    model_base_url: str | None = Field(default=None)
    """Base URL for the scanner-side model API."""

    model_args: dict[str, Any] | None = Field(default=None)
    """Model creation args forwarded to scout."""

    generate_config: Any = Field(default=None)
    """`GenerateConfig` for scanner model calls."""

    model_roles: dict[str, Any] | None = Field(default=None)
    """Named roles available to scanners via `get_model(role=...)`."""

    @classmethod
    def from_file(cls, path: str) -> "ScannerConfig":
        """Load a `ScannerConfig` from a YAML or JSON config file.

        Scanner entries in the file are written as `ScannerSpec` references
        (a registry `name` plus optional `params` and `file`). They are
        resolved to live `Scanner` objects via scout's registry, loading
        any referenced `file` modules. `model_args` may also be a path to
        a separate YAML/JSON file, which is read and inlined.

        Args:
            path: Path or URL (e.g. `s3://...`) to a YAML or JSON file.

        Returns:
            A populated `ScannerConfig` ready to pass as
            `eval_set(scanner=...)`.
        """
        from inspect_ai._util.config import read_config_object, resolve_args
        from inspect_ai._util.error import PrerequisiteError
        from inspect_ai._util.file import file as open_fs_file
        from inspect_ai._util.file import filesystem
        from inspect_ai._util.path import pretty_path

        verify_scout_prerequisites()

        if not filesystem(path).exists(path):
            raise PrerequisiteError(
                f"Scanner config file '{pretty_path(path)}' does not exist."
            )

        with open_fs_file(path, "r") as f:
            raw = read_config_object(f.read())

        config = cls.model_validate(raw)

        # realize scanners from ScannerSpec form (list or dict of dicts)
        config.scanners = _realize_scanner_specs(config.scanners)

        # realize model_args if it points to a file
        if isinstance(config.model_args, str):
            config.model_args = resolve_args(config.model_args)

        return config


def _realize_scanner_specs(scanners: Any) -> Any:
    """Convert `ScannerSpec` entries (file form) to live `Scanner` objects."""
    from inspect_scout._scancontext import (
        scanners_from_spec_dict,
        scanners_from_spec_list,
    )
    from inspect_scout._scanspec import ScannerSpec

    if isinstance(scanners, dict):
        specs = {k: ScannerSpec.model_validate(v) for k, v in scanners.items()}
        return scanners_from_spec_dict(specs)
    if isinstance(scanners, list):
        spec_list = [ScannerSpec.model_validate(v) for v in scanners]
        return scanners_from_spec_list(spec_list)
    return scanners


if TYPE_CHECKING:
    Scanners: TypeAlias = (
        Sequence[Scanner[Any] | tuple[str, Scanner[Any]]]
        | dict[str, Scanner[Any]]
        | ScannerConfig
    )
    """Argument shape accepted by `eval_set(scanner=...)`."""
else:
    # Runtime placeholder so downstream modules can `from ... import Scanners`
    # without forcing `inspect_scout` to be installed (it's an optional dep,
    # imported lazily inside functions). The type checkers see the real alias
    # above; runtime users only reference it inside string annotations.
    Scanners = Any


async def scan_init(
    scanner: "Scanners",
    *,
    scan_id: str,
    log_dir: str,
) -> None:
    """Lay down the scan dir + initial summary for an eval run.

    On second-and-later runs against the same `scan_id` (e.g. eval_set
    resume after a partial failure), the scan dir already exists. Use
    `resume()` so the accumulated `_summary.json` is preserved and
    extended; `init()` would wipe it via `reset=True`.

    Validates that the scanner set passed on resume matches the one in
    the on-disk spec. Scout's `RecorderBuffer.record` looks up scanner
    metadata by name in the spec; any unknown scanner would `KeyError`
    mid-sample, get caught as a sample error, and silently corrupt the
    eval's success/failure result. We refuse upfront with a clear message.
    """
    from inspect_scout._recorder.file import FileRecorder
    from inspect_scout._scancontext import _spec_scanners
    from inspect_scout._scanspec import ScanOptions, ScanSpec

    scanners_dict = _normalize_scanners(scanner)
    scan_dir = _scan_dir(log_dir, scan_id, scanner)
    recorder = FileRecorder()

    from inspect_ai._eval.task.scan_display import reset_state, set_active

    reset_state()

    if exists(scan_dir):
        await recorder.attach(scan_dir)
        _verify_scanner_config_unchanged(
            prior=recorder.scan_spec,
            requested=scanner,
            requested_scanners_dict=scanners_dict,
        )
        await _apply_label_updates(recorder, scanner)
        _invalidate_finalized_flag(scan_dir)
        # don't seed samples_completed — the resume-scan short-circuit
        # path calls `mark_completed` for each reused sample, so the
        # counter naturally reaches `samples_total` over the run
        # without overcounting when re-executions happen (which they
        # do whenever PreviousTask reuse can't match samples)
        set_active(
            scan_dir=scan_dir,
            spec=_display_spec(recorder.scan_spec),
            summary=await recorder.summary(),
        )
        return

    # seed inspect_ai-side config hash into metadata so a future
    # reattach can detect changes to filter / model / model_args /
    # generate_config / model_roles / model_base_url
    metadata = dict(_normalize_metadata(scanner) or {})
    metadata[_INSPECT_CONFIG_HASH_KEY] = _scan_config_hash(scanner)
    spec = ScanSpec(
        scan_id=scan_id,
        scan_name=_normalize_scan_name(scanner),
        scanners=_spec_scanners(scanners_dict),
        options=ScanOptions(),
        tags=_normalize_tags(scanner),
        metadata=metadata,
    )
    await recorder.init(spec, _scans_location(log_dir, scanner))
    set_active(
        scan_dir=scan_dir,
        spec=_display_spec(spec),
        summary=await recorder.summary(),
    )


def _display_spec(spec: "ScanSpec") -> "ScanSpec":
    """Strip fields from `spec` that aren't meaningful for the display.

    `transcripts`: the on-disk snapshot from a prior finalize. Stale
    during a fresh run — `scan_title` would read its length and show
    e.g. "10 transcripts" while actually scanning 20. The progress
    bar's X/N surfaces the live total instead.

    `options.max_transcripts`: scout's worker-pool concurrency knob.
    inspect_ai's eval_set dispatches scanners via `_scan_one` directly
    instead of scout's process pool, so this value has no effect on
    the run — showing it in the panel header is misleading.
    """
    options = spec.options.model_copy(update={"max_transcripts": None})
    return spec.model_copy(update={"transcripts": None, "options": options})


async def scan_eval_sample(
    eval_sample: EvalSample,
    scanner: "Scanners | None",
    *,
    scan_id: str | None,
    eval_id: str,
    log_location: str,
    model: str | None = None,
    eval_spec: EvalSpec | None = None,
) -> None:
    """Run scanners over a completed sample's transcript.

    `log_location` may be relative (the value passed to `task_run_sample`
    is relative-to-eval_wd in the common case); resolved here to absolute
    so the derived scan dir matches the one registered by `scan_init`.

    `eval_spec` carries the eval-level metadata (model, task, tags,
    metadata, etc.) that scout's filter language can reference. The
    caller (`task_run_sample`) has it as `logger.eval`.
    """
    if scanner is None or scan_id is None:
        return
    log_location = absolute_file_path(log_location)
    scan_dir = _scan_dir(dirname(log_location), scan_id, scanner)
    if not exists(scan_dir):
        return

    # honor any SQL filter on a `ScanJobConfig` — samples that don't
    # match are not scanned at all (no parquet row, no entry in the
    # snapshot). Mirrors how scout's direct scan path filters via
    # `Transcripts.where(...)`, applied here per-sample because we
    # dispatch per-sample rather than reading from a query.
    if not _sample_matches_filters(
        eval_sample, _normalize_filters(scanner), eval_spec=eval_spec
    ):
        return

    from inspect_scout._concurrency.common import ScannerJob
    from inspect_scout._recorder.file import FileRecorder
    from inspect_scout._scan import _scan_one
    from inspect_scout._transcript.eval_log import (
        transcript_from_eval_sample,
        transcript_info_from_eval_sample,
    )

    _install_scan_model_context(scanner)
    scanners_dict = _normalize_scanners(scanner)
    info = transcript_info_from_eval_sample(
        eval_sample, eval_id=eval_id, log_location=log_location, model=model
    )
    transcript = transcript_from_eval_sample(
        eval_sample, eval_id=eval_id, log_location=log_location, model=model
    )

    from inspect_ai._eval.task.scan_display import push_results
    from inspect_ai._util.error import PrerequisiteError

    for name, scanner_fn in scanners_dict.items():
        job = ScannerJob(
            union_transcript=transcript,
            scanner=scanner_fn,
            scanner_name=name,
        )
        try:
            reports = await _scan_one(job)
        except PrerequisiteError as e:
            raise _rewrap_no_model_error(name, e) from None
        recorder = FileRecorder()
        await recorder.attach(scan_dir)
        await recorder.record(info, name, reports, metrics=None)
        push_results(summary=await recorder.summary(), scanner=name)


async def resume_scan_previous_sample(
    eval_sample: EvalSample,
    scanner: "Scanners | None",
    scanned_per_scanner: dict[str, set[str]],
    sample_semaphore: contextlib.AbstractAsyncContextManager[Any],
    *,
    scan_id: str | None,
    eval_id: str,
    log_location: str,
    model: str | None,
    eval_spec: EvalSpec | None = None,
) -> None:
    """Dispatch a scan for a reused sample if its row isn't already on disk.

    No-op when no scanner is configured, the snapshot says the prior
    scan finalized cleanly (`scanned_per_scanner` is empty), or every
    scanner already has a row for this transcript_id. Otherwise
    acquires `sample_semaphore` (so resume-scan work shares the same
    parallelism budget as the eval phase) and dispatches
    `scan_eval_sample`.
    """
    from inspect_ai._eval.task.scan_display import mark_completed

    tid = eval_sample.uuid
    if scanner is None or not scanned_per_scanner or tid is None:
        return
    if all(tid in s for s in scanned_per_scanner.values()):
        # every scanner already has this tid — no scan work needed.
        # Bump the progress counter for the (sample, scanner) pairs
        # that this skip represents so the bar reflects the work done
        # in prior runs.
        mark_completed(len(scanned_per_scanner))
        return
    async with sample_semaphore:
        await scan_eval_sample(
            eval_sample,
            scanner,
            scan_id=scan_id,
            eval_id=eval_id,
            log_location=log_location,
            model=model,
            eval_spec=eval_spec,
        )


async def scan_finalize(
    *,
    scan_id: str,
    log_dir: str,
    scanner: "Scanners | None" = None,
    scans: str | None = None,
) -> None:
    """Compact buffer parquets and snapshot the recorded transcripts.

    The transcripts snapshot is what scout's `scan_resume` uses to know
    which transcripts existed in the scan. We sync first — that merges
    this call's buffer with the previously-compacted parquet (via
    `extra_inputs`) into the canonical output. The post-sync compacted
    parquet contains every transcript ever recorded for this scan
    across all calls; we read its `transcript_id` /
    `transcript_source_uri` columns to build the snapshot, then write it
    into `scan.json`. Errored scans show up too: their per-transcript row
    has `scan_error` populated and `is_recorded` will return False on
    resume, marking them for retry.

    The snapshot is written by reading and re-writing `scan.json`
    directly rather than via `recorder.attach() + snapshot_transcripts`,
    because `attach` recreates the buffer dir (which `sync(complete=True)`
    just cleaned up) and would leave the scan looking "in progress".

    `complete` is True only when no scanner errors are present; with
    errors we leave the scan resumable so scout's `scan_resume` can
    re-run just the failed scans.

    An external runner finalizing a record-only scan has no live scanner
    objects; with `scanner=None` the scanner names are read from the
    on-disk `_scan.json` instead (they are the only thing the objects
    were used for), and `scans` supplies the output-location override
    the objects would otherwise carry.
    """
    from inspect_scout._recorder.file import FileRecorder
    from upath import UPath

    scan_dir = (
        f"{scans.rstrip('/')}/scan_id={scan_id}"
        if scans is not None
        else _scan_dir(log_dir, scan_id, scanner)
    )
    if not exists(scan_dir):
        return

    # only mark complete if no scanner errors — otherwise leave the scan
    # in an "incomplete" state so scout's `scan_resume` can pick up the
    # failed scans. status() reads errors from the buffer dir while it
    # still exists (cleanup happens inside sync when complete=True).
    pre_sync_status = await FileRecorder.status(scan_dir)
    complete = not pre_sync_status.errors

    await FileRecorder.sync(scan_dir, complete=complete)

    scanner_names = (
        sorted(_normalize_scanners(scanner))
        if scanner is not None
        else sorted(pre_sync_status.spec.scanners)
    )
    await _cleanup_orphan_scan_rows(scan_dir, log_dir, scanner_names)

    snapshot = _snapshot_from_compacted(UPath(scan_dir), log_dir=log_dir)
    if snapshot is not None:
        _write_snapshot_to_scan_spec(UPath(scan_dir), snapshot)


def _invalidate_finalized_flag(scan_dir: str) -> None:
    """Flip `_summary.json`'s `complete` to `False` in place.

    Called by `scan_init` when attaching to an existing scan_dir, so
    the persisted finalize signal is reset for the current call.
    Stats (model_usage, tokens, per-scanner counts) are preserved;
    only the boolean flag is flipped. `scan_finalize` will rewrite
    the whole file at sync time with the correct flag.
    """
    import json

    from upath import UPath

    summary_path = UPath(scan_dir) / "_summary.json"
    if not summary_path.exists():
        return
    data = json.loads(summary_path.read_text())
    if data.get("complete") is True:
        data["complete"] = False
        summary_path.write_text(json.dumps(data))


def scan_already_clean(scanner: "Scanners | None", scan_id: str, log_dir: str) -> bool:
    """True if the prior scan finalized cleanly and no call has run since.

    Used by `eval_set` to short-circuit the success-logs-as-PreviousTask
    routing when there's nothing for the per-sample resume-scan to find.
    Safe because `scan_init` invalidates `complete=False` on every
    attach, so this only reads `True` when the most recent prior
    call's finalize wrote it AND no subsequent call has started.

    Returns False when no scanner is configured, no scan dir exists,
    or `_summary.json`'s `complete` is False/missing.
    """
    if scanner is None:
        return False
    return _scan_finalized_clean(_scan_dir(log_dir, scan_id, scanner))


def _scan_finalized_clean(scan_dir: str) -> bool:
    """True if the most recent call's `scan_finalize` ran with no errors.

    Reads `_summary.json` at the scan_dir, which is rewritten by
    `_sync_status_files` at every `scan_finalize`. `scan_init`
    invalidates `complete` to `False` when attaching to an existing
    scan_dir, so a `True` value here means "the most recent call's
    finalize wrote this and recorded no errors" — i.e. every logged
    sample has a row, no resume-scan needed.

    A `False` (or absent) summary means either: a prior call crashed
    before finalize (the `complete=False` was written by `scan_init`
    of *this* call, and not yet overwritten), or the prior call had
    scanner errors. In either case the per-sample check has work to
    do — at minimum to confirm there are no missing rows.
    """
    import json

    from upath import UPath

    summary_path = UPath(scan_dir) / "_summary.json"
    if not summary_path.exists():
        return False
    return bool(json.loads(summary_path.read_text()).get("complete"))


def scanned_transcripts_for_resume(
    scanner: "Scanners | None",
    scan_id: str | None,
    log_location: str,
) -> dict[str, set[str]]:
    """Per-scanner set of transcript_ids that already have a parquet row.

    Returned dict gates the per-sample resume-scan check in
    `task_run`: if a reused sample's `transcript_id` is in any
    scanner's set, the dispatch is short-circuited and the display's
    progress counter is bumped via `mark_completed`. If a sample's tid
    isn't in every scanner's set, `scan_eval_sample` is dispatched and
    the display is updated via `push_results`.

    An empty dict means "skip the check entirely" and is returned
    when:

    - no scanner is configured;
    - no `scan_id` is set;
    - the scan dir doesn't exist (no prior scan laid it down — or
      this call's `scan_init` will create it fresh, in which case the
      caller's own per-sample dispatch already handles the work).

    Note: even on a cleanly-finalized prior scan, we return the full
    set — the membership check feeds the display's progress counter
    via `mark_completed`, so we can't elide the read.
    """
    if scanner is None or scan_id is None:
        return {}

    scan_dir = _scan_dir(dirname(absolute_file_path(log_location)), scan_id, scanner)
    if not exists(scan_dir):
        return {}

    return {
        name: _scanned_transcript_ids(scan_dir, name)
        for name in _normalize_scanners(scanner)
    }


async def _cleanup_orphan_scan_rows(
    scan_dir: str, log_dir: str, scanner_names: Sequence[str]
) -> None:
    """Drop scan rows whose transcript_id has no corresponding sample.

    Sample-level retries (`retry_immediate`) and the legacy eval_set
    retry path re-run failed samples with fresh uuids, then
    `retry_cleanup` deletes the older log files. Their transcript_ids
    survive in the scan parquet (and possibly the buffer) but no
    longer match any `EvalSample`. This sweeps those orphans.

    Reads sample uuids from all surviving eval logs (cheap — only
    summaries), filters each scanner's compacted parquet to just
    those uuids, and unlinks any orphan buffer files.
    """
    import pyarrow as pa
    import pyarrow.compute as pc
    import pyarrow.parquet as pq
    from inspect_scout._recorder.buffer import RecorderBuffer, _sanitize_component
    from upath import UPath

    from inspect_ai.log._file import (
        list_eval_logs,
        read_eval_log_sample_summaries_async,
    )

    live_tids: set[str] = set()
    for log_info in list_eval_logs(log_dir):
        for summary in await read_eval_log_sample_summaries_async(log_info.name):
            if summary.uuid is not None:
                live_tids.add(summary.uuid)

    live_array = pa.array(sorted(live_tids), type=pa.string())
    buffer_dir = RecorderBuffer.buffer_dir(scan_dir)

    for name in scanner_names:
        # filter the compacted parquet — read per-row-group to avoid
        # cross-row-group schema merging (scout's writer can produce
        # row groups with differing dictionary states)
        parquet_path = UPath(scan_dir) / f"{name}.parquet"
        if parquet_path.exists():
            pf = pq.ParquetFile(parquet_path.as_posix())
            schema = pf.schema_arrow
            out_buf = pa.BufferOutputStream()
            writer = pq.ParquetWriter(
                out_buf, schema, compression="zstd", use_dictionary=True
            )
            removed = False
            for i in range(pf.num_row_groups):
                rg = pf.read_row_group(i)
                mask = pc.is_in(rg.column("transcript_id"), value_set=live_array)
                filtered = rg.filter(mask)
                if filtered.num_rows < rg.num_rows:
                    removed = True
                if filtered.num_rows > 0:
                    writer.write_table(filtered)
            writer.close()
            if removed:
                # same atomicity discipline as FileRecorder.sync: remote
                # object stores expose a PUT atomically, while a local
                # filesystem exposes partial writes -- so write a sibling
                # .tmp and rename, keeping the file always-complete for a
                # concurrent reader (scan_results_df takes no lock).
                data = out_buf.getvalue().to_pybytes()
                if parquet_path.protocol not in ("", "file"):
                    parquet_path.write_bytes(data)
                else:
                    import os

                    tmp_path = UPath(f"{parquet_path}.tmp")
                    tmp_path.write_bytes(data)
                    os.replace(str(tmp_path), str(parquet_path))

        # clean orphaned buffer files (relevant when complete=False
        # left the buffer in place; complete=True already cleaned it)
        sdir = buffer_dir / f"scanner={_sanitize_component(name)}"
        if sdir.exists():
            for p in sdir.glob("*.parquet"):
                if p.stem not in live_tids:
                    p.unlink()


def _scanned_transcript_ids(scan_dir: str, scanner_name: str) -> set[str]:
    """Transcript ids already recorded for `scanner_name` in `scan_dir`.

    Combines the in-flight buffer's per-transcript file stems with the
    `transcript_id` column of the compacted parquet (if present) so the
    "is this transcript scanned" check works whether or not the most
    recent sync was complete=True (which cleans the buffer).
    """
    import pyarrow.parquet as pq
    from inspect_scout._recorder.buffer import RecorderBuffer, _sanitize_component
    from upath import UPath

    ids: set[str] = set()

    # in-flight buffer: <buffer_dir>/scanner=<sanitized>/<tid>.parquet
    buffer_dir = RecorderBuffer.buffer_dir(scan_dir)
    sdir = buffer_dir / f"scanner={_sanitize_component(scanner_name)}"
    if sdir.exists():
        for p in sdir.glob("*.parquet"):
            ids.add(p.stem)

    # post-sync compacted parquet — read row-group-by-row-group to avoid
    # pyarrow's cross-row-group schema-merge error on scout's dictionary-
    # encoded `scan_id` column. Same pattern as `_cleanup_orphan_scan_rows`.
    parquet_path = UPath(scan_dir) / f"{scanner_name}.parquet"
    if parquet_path.exists():
        pf = pq.ParquetFile(parquet_path.as_posix())
        for i in range(pf.metadata.num_row_groups):
            rg = pf.read_row_group(i, columns=["transcript_id"])
            ids.update(t for t in rg.column("transcript_id").to_pylist() if t)

    return ids


def _write_snapshot_to_scan_spec(scan_dir: Any, snapshot: Any) -> None:
    """Read the on-disk scan spec, attach the snapshot, write it back.

    Bypasses `FileRecorder.attach` so we don't recreate the buffer dir
    that `sync(complete=True)` just removed — keeping the scan in the
    "complete" state for `FileRecorder.status`.
    """
    from inspect_scout._recorder.file import SCAN_JSON
    from inspect_scout._scanspec import ScanSpec

    from inspect_ai._util.file import file
    from inspect_ai._util.json import to_json_str_safe

    scan_json = (scan_dir / SCAN_JSON).as_posix()
    with file(scan_json, "r") as f:
        spec = ScanSpec.model_validate_json(f.read())
    spec.transcripts = snapshot
    with file(scan_json, "w") as f:
        f.write(to_json_str_safe(spec))


def _snapshot_from_compacted(scan_dir: Any, *, log_dir: str) -> Any:
    """Build a `ScanTranscripts` from the post-sync compacted parquet.

    Reads `transcript_id` + `transcript_source_uri` from any scanner's
    compacted output — every scanner sees every transcript, so any one
    is a complete index. Returns None if no scanner parquets exist (e.g.
    scan ran with no samples).
    """
    import io

    import pyarrow.parquet as pq
    from inspect_scout._scanspec import ScanTranscripts

    parquets = sorted(p for p in scan_dir.iterdir() if p.suffix == ".parquet")
    if not parquets:
        return None

    pf = pq.ParquetFile(io.BytesIO(parquets[0].read_bytes()))
    table = pf.read(columns=["transcript_id", "transcript_source_uri"])
    transcript_ids: dict[str, str | None] = {}
    for tid, uri in zip(
        table.column("transcript_id").to_pylist(),
        table.column("transcript_source_uri").to_pylist(),
    ):
        if tid is not None and tid not in transcript_ids:
            transcript_ids[tid] = uri

    if not transcript_ids:
        return None
    return ScanTranscripts(
        type="eval_log",
        location=log_dir,
        transcript_ids=transcript_ids,
    )


@contextlib.contextmanager
def scan_context(
    scanner: "Scanners | None",
    *,
    scan_id: str,
    log_dir: str,
) -> Iterator[None]:
    """Initialize scan state on enter, compact on exit. No-op when scanner is None."""
    if scanner is None:
        yield
        return
    verify_scout_prerequisites()
    run_coroutine(scan_init(scanner, scan_id=scan_id, log_dir=log_dir))
    try:
        yield
    finally:
        run_coroutine(scan_finalize(scan_id=scan_id, log_dir=log_dir, scanner=scanner))


def print_scan_status(log_dir: str, scanner: "Scanners | None" = None) -> None:
    """Print the most recent scan dir's final status as plain text.

    Called from `eval` / `eval_set` after they have rendered their
    final output (the display panel + `Log:` line / "Completed all
    tasks" message), so the message lands at the very end. Mirrors
    `scout scan`'s standalone output (the same
    `scout scan resume <path>` / `scout scan complete <path>` commands
    when there are errors), but rendered plain — no rich markup, no
    color — to keep the trailing summary unobtrusive.

    Picks the scan dir with the most recent `_summary.json` mtime
    when the resolved scans location has multiple, so the message
    reflects the call that just finished. No-op when no scan dir
    exists.

    `scanner` is forwarded so `ScannerConfig.scans` (the override
    that redirects scan output to a different location, e.g. an S3
    bucket) is honored — without it the search would look under
    `<log_dir>/scans/` and miss the redirected dir entirely.

    Callers are responsible for ensuring there's a blank line of
    separation above this output — this function does not emit one.
    """
    import shlex

    from inspect_scout._recorder.file import FileRecorder
    from upath import UPath

    from inspect_ai._util.path import pretty_path

    scans_dir = UPath(_scans_location(log_dir, scanner))
    if not scans_dir.exists():
        return

    scan_dirs = [
        d for d in scans_dir.iterdir() if d.is_dir() and (d / "_summary.json").exists()
    ]
    if not scan_dirs:
        return
    scan_dir = max(scan_dirs, key=lambda d: (d / "_summary.json").stat().st_mtime)

    status = run_coroutine(FileRecorder.status(str(scan_dir)))

    path = shlex.quote(pretty_path(str(scan_dir)))
    if status.complete:
        print(f"scan complete: {path}\n")
    else:
        print(f"{len(status.errors)} scan errors occurred!\n")
        print(f"Resume (retrying errors):   scout scan resume {path}")
        print(f"Complete (ignoring errors): scout scan complete {path}\n")


def _scans_location(log_dir: str, scanner: "Scanners | None" = None) -> str:
    """Where scan outputs land.

    Defaults to `<log_dir>/scans/`. A `ScanJob`/`ScanJobConfig` may
    override via its `scans` field — that gets used as the location
    directly so the user can write scan results to a different
    filesystem (e.g. an S3 bucket) than the eval logs.
    """
    base = _normalize_scans(scanner) or f"{log_dir.rstrip('/')}/scans"
    return base.rstrip("/")


def _scan_dir(log_dir: str, scan_id: str, scanner: "Scanners | None" = None) -> str:
    return f"{_scans_location(log_dir, scanner)}/scan_id={scan_id}"


def _normalize_scanners(
    scanner: "Scanners | None",
) -> "dict[str, Scanner[Any]]":
    from inspect_scout import ScanJob

    if scanner is None:
        return {}
    if isinstance(scanner, ScannerConfig):
        return ScanJob(scanners=scanner.scanners)._scanners
    return ScanJob(scanners=scanner)._scanners


def merged_selection_scanner(
    scanner: "Scanners | None",
    injected: dict[str, dict[str, Any]] | None,
) -> "Scanners | None":
    """Merge runner-injected scanner specs with the definition's own scanners.

    A selection document may carry scanners of the runner's choosing, as
    scout `ScannerSpec` dicts keyed by name (see `eval_set_selection.py`).
    They are realized here and merged with whatever the definition passed —
    which may be nothing, so a worker can scan through injection alone.

    A name collision is refused rather than resolved: either resolution
    silently changes what one of the two parties records, and the runner
    is expected to have refused the collision before any worker started.

    When the definition's `scanner` is a `ScannerConfig`, the merge
    preserves the config wrapper (its filter, scan-side model, and `scans`
    location apply to the injected scanners too), replacing only the
    scanner mapping inside it.
    """
    if not injected:
        return scanner
    verify_scout_prerequisites()

    from inspect_scout._scancontext import scanners_from_spec_dict
    from inspect_scout._scanspec import ScannerSpec
    from pydantic import ValidationError

    from inspect_ai._util.error import PrerequisiteError

    specs: dict[str, ScannerSpec] = {}
    for name, entry in injected.items():
        try:
            specs[name] = ScannerSpec.model_validate(entry)
        except ValidationError as ex:
            raise PrerequisiteError(
                f"Runner-injected scanner '{name}' is not a valid ScannerSpec:\n{ex}"
            ) from ex
    realized = scanners_from_spec_dict(specs)

    definition = _normalize_scanners(scanner)
    collisions = sorted(set(definition) & set(realized))
    if collisions:
        raise PrerequisiteError(
            "Runner-injected scanner name(s) collide with the definition's "
            f"own scanners: {', '.join(collisions)}. Rename the injected "
            "scanner(s) -- a collision cannot be resolved without silently "
            "changing what one of the two records."
        )

    merged = {**definition, **realized}
    if isinstance(scanner, ScannerConfig):
        return scanner.model_copy(update={"scanners": merged})
    return merged


def verify_selection_scan_dir(
    scanner: "Scanners | None", *, scan_id: str, log_dir: str
) -> None:
    """Refuse selection-mode scanning on an absent or disagreeing scan directory.

    In selection (worker) mode scanning is record-only: the runner owns the
    scan directory's lifecycle and must have laid it down (`scan_init`, or
    an equivalent from a serialized spec) before any worker starts. The
    per-sample dispatch (`scan_eval_sample`) silently skips when the
    directory does not exist — the right behavior for the eval-set path,
    where init is always about to run, and exactly the wrong one for a
    worker whose runner claims to own scanning: it would silently not scan.
    Checked once, at worker startup, rather than surfacing per sample.

    The directory's `_scan.json` is then compared against the live merged
    configuration. The runner verified the configuration it *captured*, but
    a worker executes the definition file as it stands at spawn time — which
    may have changed since. A worker recording under a drifted configuration
    would write rows whose recorded meaning (the on-disk spec) is not what
    produced them, so a drifted worker refuses at startup instead: the
    scanner sets must match, matching scanners must have equal specs
    (`package_version` excluded — under a development install it moves with
    every commit while the scanner remains the same scanner), and the
    eval-set-level config hash must match when the spec carries one (a
    runner-synthesized spec for a definition that declared no scanners
    carries none). Inline scanners serialize their defining `file` relative
    to the working directory, so the runner is expected to spawn workers
    with the working directory its capture ran in.
    """
    if scanner is None:
        return
    verify_scout_prerequisites()

    from inspect_ai._util.error import PrerequisiteError

    scan_dir = _scan_dir(log_dir, scan_id, scanner)
    scan_json = f"{scan_dir}/_scan.json"
    if not exists(scan_json):
        raise PrerequisiteError(
            f"Scanning is configured but the scan directory '{scan_dir}' "
            "has not been initialized. In selection (worker) mode the "
            "external runner owns the scan directory's lifecycle and must "
            "initialize it before workers start; a worker that scanned "
            "without it would silently record nothing."
        )

    from inspect_scout._scancontext import _spec_scanners
    from inspect_scout._scanspec import ScannerSpec, ScanSpec

    from inspect_ai._util.file import file

    with file(scan_json, "r") as f:
        prior = ScanSpec.model_validate_json(f.read())

    def identity(spec: ScannerSpec) -> dict[str, Any]:
        return spec.model_dump(
            mode="json", exclude={"package_version"}, exclude_none=True
        )

    live = _spec_scanners(_normalize_scanners(scanner))
    if set(live) != set(prior.scanners):
        raise PrerequisiteError(
            "Scanner set differs from the scan directory's spec "
            f"('{scan_json}').\n"
            f"  Spec: {sorted(prior.scanners)}\n"
            f"  Live: {sorted(live)}\n"
            "The runner initialized the scan from the configuration it "
            "captured, and this worker's definition has changed since. "
            "Re-launch so the runner can verify the change, or revert it."
        )

    changed = sorted(
        name
        for name, spec in live.items()
        if identity(spec) != identity(prior.scanners[name])
    )
    if changed:
        raise PrerequisiteError(
            f"Scanner(s) {', '.join(changed)} differ from the scan "
            f"directory's spec ('{scan_json}'). The runner initialized the "
            "scan from the configuration it captured, and this worker's "
            "definition has changed since — rows recorded under the changed "
            "configuration would carry the spec's meaning without being "
            "produced by it. Re-launch so the runner can verify the change, "
            "or revert it."
        )

    prior_hash = (prior.metadata or {}).get(_INSPECT_CONFIG_HASH_KEY)
    if prior_hash is not None and prior_hash != _scan_config_hash(scanner):
        raise PrerequisiteError(
            "Eval-set-level scanner config (filter, model, model_args, "
            "generate_config, model_roles, model_base_url) differs from the "
            f"scan directory's spec ('{scan_json}'). The runner initialized "
            "the scan from the configuration it captured, and this worker's "
            "definition has changed since. Re-launch so the runner can "
            "verify the change, or revert it."
        )


def serialized_scan(
    scanner: "Scanners | None", *, scan_id: str | None
) -> tuple[dict[str, Any], str | None] | None:
    """Serialize the definition's scanner configuration for a capture manifest.

    Returns `(spec, scans)`, where `spec` is the `ScanSpec` dump a fresh
    `scan_init` would write for this configuration — the material an
    external runner needs to lay the scan directory down *without executing
    the definition* — and `scans` is the definition's output-location
    override (`None` to default under the runner's resolved log directory,
    which capture cannot compute since a definition may name no `log_dir`).
    Returns `None` when the definition declares no scanners.

    `scan_id` may be unknown at capture (`eval_set_id` is optional); it is
    recorded as the empty string then. The runner stamps the authoritative
    id at init time either way, so the field here is informational.
    """
    if scanner is None:
        return None
    verify_scout_prerequisites()

    from inspect_scout._scancontext import _spec_scanners
    from inspect_scout._scanspec import ScanOptions, ScanSpec

    metadata = dict(_normalize_metadata(scanner) or {})
    metadata[_INSPECT_CONFIG_HASH_KEY] = _scan_config_hash(scanner)
    spec = ScanSpec(
        scan_id=scan_id or "",
        scan_name=_normalize_scan_name(scanner),
        scanners=_spec_scanners(_normalize_scanners(scanner)),
        options=ScanOptions(),
        tags=_normalize_tags(scanner),
        metadata=metadata,
    )
    return (
        spec.model_dump(mode="json", exclude_none=True),
        _normalize_scans(scanner),
    )


async def scan_init_from_spec(
    spec: dict[str, Any],
    *,
    scan_id: str,
    log_dir: str,
    scans: str | None = None,
) -> str:
    """Lay down (or re-attach to) a scan directory from a serialized spec.

    The external runner's half of record-only scanning: `spec` is the
    `ScanSpec` dump a capture manifest carries (see `serialized_scan`),
    possibly with runner-injected scanners merged into its `scanners`
    mapping. `scan_id` is stamped over whatever the dump recorded, since
    the runner resolves the authoritative id; `scans` is the definition's
    output-location override (`None` for `<log_dir>/scans`).

    When the directory already exists this attaches rather than resets:
    the finalized flag is invalidated (a new run is starting) and the
    on-disk spec is replaced with the requested one, preserving the prior
    spec's `transcripts` snapshot. No compatibility check happens here —
    the runner is expected to have verified the requested spec against the
    on-disk one (refusing changed scanners, admitting added ones) before
    calling, at a moment a human can act on the refusal.

    Returns the scan directory.
    """
    verify_scout_prerequisites()

    from inspect_scout._recorder.file import FileRecorder
    from inspect_scout._scanspec import ScanSpec
    from upath import UPath

    from inspect_ai._util.file import file
    from inspect_ai._util.json import to_json_str_safe

    requested = ScanSpec.model_validate({**spec, "scan_id": scan_id})
    scans_location = (scans or f"{log_dir.rstrip('/')}/scans").rstrip("/")
    scan_dir = f"{scans_location}/scan_id={scan_id}"

    if exists(scan_dir):
        scan_json = UPath(scan_dir) / "_scan.json"
        with file(scan_json.as_posix(), "r") as f:
            prior = ScanSpec.model_validate_json(f.read())
        requested = requested.model_copy(update={"transcripts": prior.transcripts})
        with file(scan_json.as_posix(), "w") as f:
            f.write(to_json_str_safe(requested))
        _invalidate_finalized_flag(scan_dir)
        return scan_dir

    await FileRecorder().init(requested, scans_location)
    return scan_dir


def _normalize_scans(scanner: "Scanners | None") -> str | None:
    """Extract the scan-output-location override (`scans`), if any."""
    if isinstance(scanner, ScannerConfig):
        return scanner.scans
    return None


def _normalize_tags(scanner: "Scanners | None") -> list[str] | None:
    """Tags carried on `ScannerConfig`, written into the scan spec."""
    if isinstance(scanner, ScannerConfig):
        return scanner.tags
    return None


def _normalize_scan_name(scanner: "Scanners | None") -> str:
    """Scan-name override from `ScannerConfig`, else "eval_set"."""
    if isinstance(scanner, ScannerConfig):
        return scanner.name or "eval_set"
    return "eval_set"


def _normalize_metadata(scanner: "Scanners | None") -> "dict[str, Any] | None":
    """Metadata carried on `ScannerConfig`, written into the scan spec."""
    if isinstance(scanner, ScannerConfig):
        return scanner.metadata
    return None


def _install_scan_model_context(scanner: "Scanners | None") -> None:
    """Install scout's scan-time model context for this sample.

    Always invokes scout's `init_scan_model_context` so scanner model
    usage is accounted separately from the eval's. Scout's resolution
    chain is kwargs > `SCOUT_SCAN_MODEL` env var > `NoModel` sentinel
    (which raises `PrerequisiteError` on use) — and here, where the
    sample's own context is still live around the call, ambient defaults
    slot in ahead of the sentinel: a scanner that names no model of its
    own scans with the model under evaluation, or (for a "none"-model
    eval) the first model role. Only an eval with neither leaves
    `NoModel` to raise, which is the signal that a scan-side model must
    be configured explicitly.

    The eval's model roles pass through ambiently for the same reason
    (`init_model_context` would otherwise clear them): `get_model(role=...)`
    in a scanner resolves the sample's own roles unless
    `ScannerConfig.model_roles` replaces them.

    The override lives on the per-sample async context — each sample
    inherits a fresh copy of the task's context, so setting it here
    does not leak to other samples or back into the eval's solver path.
    (The eval's `model_usage` for this sample is already snapshotted
    into `EvalSample` before `scan_eval_sample` is called.)
    """
    import os

    from inspect_scout._scan import init_scan_model_context

    from inspect_ai._util.constants import MODEL_NONE
    from inspect_ai.model._model import active_model, model_roles

    kwargs: dict[str, Any] = {}
    if isinstance(scanner, ScannerConfig):
        if scanner.model is not None:
            kwargs["model"] = scanner.model
        if scanner.generate_config is not None:
            kwargs["model_config"] = scanner.generate_config
        if scanner.model_base_url is not None:
            kwargs["model_base_url"] = scanner.model_base_url
        if scanner.model_args is not None:
            kwargs["model_args"] = scanner.model_args
        if scanner.model_roles is not None:
            kwargs["model_roles"] = scanner.model_roles

    ambient_roles = model_roles()
    if "model" not in kwargs and not os.environ.get("SCOUT_SCAN_MODEL"):
        ambient = active_model()
        if ambient is not None and str(ambient) != MODEL_NONE:
            kwargs["model"] = ambient
        elif ambient_roles:
            first = next(iter(ambient_roles.values()))
            kwargs["model"] = first[0] if isinstance(first, list) else first
    if "model_roles" not in kwargs and ambient_roles:
        kwargs["model_roles"] = ambient_roles

    init_scan_model_context(**kwargs)


def _rewrap_no_model_error(scanner_name: str, error: Exception) -> Exception:
    """Replace scout's generic `NoModel` error with actionable scan-context guidance.

    `NoModel.generate()` raises a `PrerequisiteError` whose message
    ("No model specified ...") doesn't tell the user that this is about
    the *scan-side* model. Surface a clearer message pointing at the
    knobs they can set; for any other `PrerequisiteError`, return it
    unchanged so the caller re-raises as-is.

    With the ambient defaults `_install_scan_model_context` installs,
    reaching this at all means the eval had no model under evaluation
    and no model roles to inherit — so the message says that a model
    must be configured explicitly.
    """
    from inspect_ai._util.error import PrerequisiteError

    if "No model specified" in str(error):
        return PrerequisiteError(
            f"Scanner '{scanner_name}' tried to use a model, but this "
            "eval has no model or model roles to inherit and no "
            "scan-side model is configured — one must be set "
            "explicitly, via `ScannerConfig(model=...)`, the CLI flag "
            "`--scan-model`, or the `SCOUT_SCAN_MODEL` environment "
            "variable."
        )
    return error


def _verify_scanner_config_unchanged(
    *,
    prior: "ScanSpec",
    requested: "Scanners | None",
    requested_scanners_dict: "dict[str, Scanner[Any]]",
) -> None:
    """Raise `PrerequisiteError` if the scanner config differs from `prior`.

    Three checks, ordered cheapest first:

    1. Scanner names match. Adding or removing a scanner means the new
       run wants different output than the scan dir holds.
    2. Each scanner's `ScannerSpec` matches (params, version, file,
       package_version). Same name + different code/params produces
       different output for the same transcript.
    3. Eval-set-level config hash matches (filter / model /
       model_args / generate_config / model_roles / model_base_url).
       These aren't in scout's `ScannerSpec`; a change to them affects
       which transcripts get scanned or how, but would otherwise
       silently reuse prior parquet rows.

    Each check raises with a message naming the change and pointing
    at the resolution (`log_dir` / `scan_id` swap).
    """
    from inspect_scout._scancontext import _spec_scanners

    from inspect_ai._util.error import PrerequisiteError

    existing_names = set(prior.scanners.keys())
    requested_names = set(requested_scanners_dict.keys())
    if existing_names != requested_names:
        raise PrerequisiteError(
            "Scanner set has changed from the prior run on this "
            "log_dir.\n"
            f"  Prior:     {sorted(existing_names)}\n"
            f"  Requested: {sorted(requested_names)}\n"
            "Either match the prior scanner set or use a different "
            "log_dir / scan_id."
        )

    new_scanners = _spec_scanners(requested_scanners_dict)
    for name in sorted(requested_names):
        if prior.scanners[name] != new_scanners[name]:
            raise PrerequisiteError(
                f"Scanner '{name}' config has changed from the prior "
                "run on this log_dir.\n"
                f"  Prior:     {prior.scanners[name].model_dump(exclude_none=True)}\n"
                f"  Requested: {new_scanners[name].model_dump(exclude_none=True)}\n"
                "Use a different log_dir / scan_id to start fresh, or "
                "revert the change."
            )

    prior_hash = (prior.metadata or {}).get(_INSPECT_CONFIG_HASH_KEY)
    new_hash = _scan_config_hash(requested)
    if prior_hash != new_hash:
        raise PrerequisiteError(
            "Eval-set-level scanner config (filter, model, "
            "model_args, generate_config, model_roles, "
            "model_base_url) has changed from the prior run on "
            "this log_dir.\n"
            "Use a different log_dir / scan_id to start fresh, or "
            "revert the change."
        )


async def _apply_label_updates(recorder: Any, scanner: "Scanners | None") -> None:
    """Refresh `name` / `tags` / `metadata` on the on-disk `_scan.json`.

    Called after `_verify_scanner_config_unchanged` passes. The fields
    are intentionally excluded from the config hash (changing them
    doesn't force a fresh scan), but they're documented as written to
    `_scan.json` — the user expects updated values to land. Without
    this, a relabel succeeds silently but the on-disk spec keeps the
    original values.

    Preserves the inspect_ai-managed config-hash key in metadata.
    Only the recorder's in-memory spec and the on-disk JSON are
    rewritten; prior parquet rows keep the `scan_tags` /
    `scan_metadata` columns recorded at their original write time.
    """
    new_metadata = dict(_normalize_metadata(scanner) or {})
    new_metadata[_INSPECT_CONFIG_HASH_KEY] = _scan_config_hash(scanner)
    new_spec = recorder.scan_spec.model_copy(
        update={
            "scan_name": _normalize_scan_name(scanner),
            "tags": _normalize_tags(scanner),
            "metadata": new_metadata,
        }
    )
    # mutate the recorder's spec so subsequent record() calls see the
    # new labels in scan_tags / scan_metadata columns of new rows;
    # also keep the buffer's view in sync (it's constructed with the
    # spec and reads `tags` / `metadata` per record)
    recorder._scan_spec = new_spec
    if recorder._scan_buffer is not None:
        recorder._scan_buffer._spec = new_spec
    await recorder._write_scan_spec()


def _scan_config_hash(scanner: "Scanners | None") -> str:
    """Hash inspect_ai-side scanner config that isn't in `ScannerSpec`.

    Scout's `ScannerSpec` already captures per-scanner identity
    (name, version, file, package_version, params); equality on those
    is checked separately. This function covers the eval_set-level
    fields that affect what gets scanned and how — filter, model,
    model_args, generate_config, model_roles, model_base_url —
    none of which round-trip through scout's spec.

    Stable across runs of the same config so a no-op reattach doesn't
    invalidate the prior scan. Excludes labels (`name`, `tags`,
    `metadata`, `scans`) — changing those shouldn't force a rescan.

    Non-ScannerConfig inputs (raw scanner list/dict) hash to a
    canonical "no eval-side config" value, identical to passing an
    ScannerConfig with all defaults.

    `Model` instances passed for `model` / `model_roles[*]` are
    coerced via `str()` first because `to_json_safe`'s fallback drops
    non-serializable objects to None — losing the discriminator we
    want to detect. `str(model)` produces "<api>/<name>", stable
    across runs of the same model. A role bound to a *list* of models
    is coerced element-wise — `str()` of the list itself would embed
    each Model's default `repr` (a memory address), making the hash
    unstable across identical runs.
    """
    config = scanner if isinstance(scanner, ScannerConfig) else None
    payload = {
        "filter": _normalize_filters(scanner),
        "model": str(config.model) if (config and config.model is not None) else None,
        "model_base_url": config.model_base_url if config else None,
        "model_args": config.model_args if config else None,
        "generate_config": config.generate_config if config else None,
        "model_roles": (
            {
                k: [str(m) for m in v] if isinstance(v, list) else str(v)
                for k, v in config.model_roles.items()
            }
            if (config and config.model_roles)
            else None
        ),
    }
    return hashlib.sha256(to_json_safe(payload, indent=None)).hexdigest()


def _normalize_filters(scanner: "Scanners | None") -> list[str]:
    """Extract SQL filter clauses from the scanner argument.

    `ScannerConfig.filter` is the user-facing surface — a string
    or list of SQL WHERE clauses applied to the transcripts to scan.
    Scout's direct scan path applies these via `Transcripts.where(...)`;
    we lift them out and apply per-sample in `scan_eval_sample`.
    """
    if not isinstance(scanner, ScannerConfig):
        return []
    raw = scanner.filter
    if isinstance(raw, list):
        return [f for f in raw if f]
    return [raw] if raw else []


def _sample_matches_filters(
    eval_sample: EvalSample,
    filters: list[str],
    *,
    eval_spec: EvalSpec | None = None,
) -> bool:
    """Return True if all SQL filter clauses match this sample.

    Filters are parsed and emitted as parameterized SQLite SQL via
    scout's `condition_from_sql` / `condition_as_sql` so filters valid
    against scout's direct scan path also evaluate correctly here.
    The row that backs the WHERE clause mirrors scout's
    `TranscriptColumns` schema — every column scout exposes is
    populated (eval-level fields from `eval_spec`, sample-level from
    `eval_sample`); JSON columns are stored as JSON strings so
    `json_extract`-based shorthand (e.g. `sample_metadata.group =
    'a'`) works.

    sqlite's "double-quoted string literal" compatibility mode is
    disabled so a typo'd column name surfaces as
    `OperationalError: no such column` rather than silently comparing
    a string literal — that quirk previously hid bugs like
    `model = 'x'` evaluating against a missing column and returning
    False rather than raising.
    """
    if not filters:
        return True

    import re
    import sqlite3
    from contextlib import closing

    from inspect_scout._query import condition_as_sql, condition_from_sql

    row = _filter_row(eval_sample, eval_spec)
    valid_columns = set(row.keys())

    # Column names get interpolated into `CREATE TABLE` (sqlite has no
    # parameter form for identifiers). They mostly come from scout's
    # static `TranscriptColumns`, but `score_*` expands with arbitrary
    # score names from the eval — a name containing `"` would close
    # the identifier and inject SQL. Escape per the SQL standard
    # ("" inside a quoted identifier is a literal quote).
    def _quote_ident(name: str) -> str:
        return '"' + name.replace('"', '""') + '"'

    with closing(sqlite3.connect(":memory:")) as conn:
        cols_def = ", ".join(_quote_ident(k) for k in row.keys())
        conn.execute(f"CREATE TABLE t ({cols_def})")
        placeholders = ", ".join(["?"] * len(row))
        conn.execute(f"INSERT INTO t VALUES ({placeholders})", list(row.values()))
        for clause in filters:
            where_sql, params = condition_as_sql(condition_from_sql(clause), "sqlite")
            # Pre-validate column references: scout's emitted SQL
            # double-quotes identifiers (`"col" = ?` or
            # `json_extract("col", '$.key')`). sqlite's DQS-compat
            # mode would silently turn `"unknown_col"` into the
            # string literal `'unknown_col'` and the comparison
            # always evaluates to False — masking typo'd or
            # unsupported column references. Single-quoted strings
            # inside JSON paths (e.g. `'$.group'`) are unaffected.
            for col in re.findall(r'"([^"]+)"', where_sql):
                if col not in valid_columns:
                    raise sqlite3.OperationalError(
                        f"no such column: {col} (filter: {clause!r})"
                    )
            cursor = conn.execute(f"SELECT 1 FROM t WHERE {where_sql}", params)
            if cursor.fetchone() is None:
                return False
    return True


def _filter_row(eval_sample: EvalSample, eval_spec: EvalSpec | None) -> dict[str, Any]:
    """Build the single sqlite row used to evaluate filter clauses.

    Iterates scout's `TranscriptColumns` and applies each column's
    extractor via inspect_ai's `import_record`. Two passes — eval-level
    columns get the synthesized `EvalLog` as the record (so paths like
    `eval.model` resolve and callable extractors like `_source_type`
    fire), sample-level columns get the `EvalSample`. The merged dict
    is the row we INSERT into our in-memory sqlite table; JSON columns
    are already JSON-encoded strings (handled by the column's `value`
    function), so `json_extract` shorthand like `sample_metadata.group
    = 'a'` works.

    Defining the row this way means new columns added to scout's
    `TranscriptColumns` automatically flow through with no change here.
    """
    from inspect_scout._transcript.eval_log import TranscriptColumns

    from inspect_ai.analysis._dataframe.evals.columns import EvalColumn
    from inspect_ai.analysis._dataframe.record import import_record
    from inspect_ai.analysis._dataframe.samples.columns import SampleColumn
    from inspect_ai.log._log import EvalLog

    log = (
        EvalLog(eval=eval_spec, status="started")
        if eval_spec is not None
        # `import_record`'s eval-level extractors require an EvalLog —
        # callers that omit `eval_spec` get an empty stand-in so
        # sample-level columns still extract; eval-level columns end
        # up as None.
        else EvalLog.model_construct(eval=None, status="started")  # type: ignore[arg-type]
    )

    eval_cols = [c for c in TranscriptColumns if isinstance(c, EvalColumn)]
    sample_cols = [c for c in TranscriptColumns if isinstance(c, SampleColumn)]

    eval_row, _ = import_record(log, log, eval_cols, strict=False)
    sample_row, _ = import_record(log, eval_sample, sample_cols, strict=False)

    return {**eval_row, **sample_row}
