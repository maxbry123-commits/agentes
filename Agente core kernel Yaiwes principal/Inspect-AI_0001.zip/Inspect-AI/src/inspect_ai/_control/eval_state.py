"""Process-level per-eval state aggregate.

Tracks running totals across the samples of each in-flight eval
(``eval_id``-keyed). Consumed by the control-channel ``GET /tasks``
endpoint to surface counts that ``active_samples()`` alone can't
provide.

The eval runner calls :func:`register_eval` at task start (when the
total sample count is known), plus :func:`record_sample_completed` /
:func:`record_sample_errored` at each sample's terminal outcome. States
are not unregistered per-eval — the registry is cleared in one shot at
the outermost run boundary (``eval`` / ``eval_set``) via
:func:`clear_all_eval_states`, which keeps completed evals visible in
``inspect ctl task list`` through the run (and any keep-alive park).

Lives under ``_control/`` because the control channel is currently
the only consumer; if other surfaces (TUI, view server) ever need
process-level eval counters, this can move up.

Why a counter aggregate rather than computing on demand from
``active_samples()``:

- ``active_samples`` carries only currently-registered samples;
  completed ones are removed, so we can't count them.
- The total sample count is known at task start but isn't otherwise
  available from the sample-level state.
- A running counter is cheap and updated at well-defined transition
  points, vs. polling derived state from elsewhere.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from logging import getLogger
from threading import Lock
from typing import TYPE_CHECKING, Literal, NamedTuple, Protocol

logger = getLogger(__name__)

# The LiveEvalData protocol and the deferred-stats alias live under
# TYPE_CHECKING so this module stays dependency-free at runtime (it's imported
# during eval bootstrap, before the log/event packages finish initializing).
# PEP 563 (`from __future__ import annotations`) means every annotation below is
# a string, so nothing here is evaluated at runtime — but note that
# `typing.get_type_hints(EvalState)` would fail outside a type-checking context.
if TYPE_CHECKING:
    from collections.abc import Awaitable, Callable

    from inspect_ai._control.scoring import TaskScoring
    from inspect_ai._display.core.display import TaskCancel
    from inspect_ai._eval.task.scheduler import SampleRequeue
    from inspect_ai.log._config_update import ConfigUpdate
    from inspect_ai.log._log import EvalSample, EvalSampleSummary
    from inspect_ai.log._transcript import TranscriptHistoryProvider

    class LiveEvalData(Protocol):
        """A running eval's live data source — the in-process ``TaskLogger``.

        A live (still-running or keep-alive-parked) eval serves its
        not-yet-on-disk sample data and its buffer directives through these
        methods; the control endpoints prefer them over reading the on-disk log
        so reads are gap-free. The running ``TaskLogger`` satisfies this
        structurally — these are its methods — so the runner hands the logger
        itself to :func:`register_eval` and this module never imports it (the
        layering the ``TYPE_CHECKING`` guard preserves).

        ``EvalState.live`` is ``None`` for reused/synthetic evals (no running
        logger — they fall back to :attr:`~EvalState.log_location` and
        :attr:`~EvalState.deferred_sample_stats`) and is cleared when a retry
        supersedes the attempt the logger was bound to (see
        :func:`detach_eval_live`).
        """

        def sample_summaries(self) -> Awaitable[list[EvalSampleSummary] | None]:
            """Completed-sample summaries (gap-free); ``None`` once torn down."""
            ...

        def read_sample(
            self,
            id: str | int,
            epoch: int,
            *,
            exclude_fields: set[str] | None = None,
        ) -> Awaitable[EvalSample | None]:
            """One full sample by ``(id, epoch)`` — recorder, then on-disk log."""
            ...

        def sample_events_provider(
            self, id: str | int, epoch: int
        ) -> TranscriptHistoryProvider | None:
            """One sample's realtime-buffer history provider; ``None`` once torn down."""
            ...

        def flush_samples(self) -> Awaitable[int]:
            """Flush buffered completed samples to the log; return the count."""
            ...

        def buffer_config(
            self, log_buffer: int | None = None, log_shared: int | None = None
        ) -> "BufferConfig":
            """Read (both args ``None``) or update the sample-buffer parameters."""
            ...

        def log_config_update(self, update: ConfigUpdate) -> Awaitable[bool]:
            """Record a mid-run config change into the log.

            ``False`` means the logger *declined* because its log has already
            finished (its record is complete — not a failure; failures raise).
            """
            ...

    # Async accessor for a reused eval's summaries-derived stats, resolved
    # lazily on first control request (see ``DeferredSampleStats``).
    DeferredStatsProvider = Callable[[], Awaitable["DeferredSampleStats"]]


class BufferConfig(NamedTuple):
    """A running eval's sample-buffer parameters (see ``inspect ctl config``).

    Reported by the buffer directive and, when set values are supplied,
    re-reported after the update.
    """

    log_buffer: int
    """Completed samples buffered before a write to the (possibly remote) log."""

    pending: int
    """Completed samples currently buffered, not yet written to the log."""

    log_shared: int | None
    """Shared-log sync interval in seconds, or ``None`` when realtime logging
    (and thus the shared-log sync) is off."""


class DeferredSampleStats(NamedTuple):
    """Summaries-derived stats for a reused eval, resolved lazily.

    A reused log's header is already parsed (eval-set reads it to decide
    reuse), but these fields require reading the per-sample summaries — a
    full log read that would otherwise run serially per reused log at
    eval-set startup, whether or not a control client ever connects.
    They're deferred behind :attr:`EvalState.deferred_sample_stats` and
    resolved (once, memoized) by the first ``current_eval_summaries`` call.
    """

    total_messages: int
    completed: int
    errored: int


@dataclass
class EvalState:
    """Per-eval terminal-sample counters.

    Only stores ``total`` plus terminal-outcome counters. ``in_flight``
    is intentionally NOT stored here — it's derived from
    :func:`inspect_ai.log._samples.active_samples` at read time so
    retries (which open a fresh ``ActiveSample`` per attempt) can't
    drift the counter. ``queued`` is also derived (everything not
    accounted for elsewhere).
    """

    eval_id: str
    """The eval's id (matches ``ActiveSample.eval_id``). Per-attempt
    on retries — see :attr:`task_id` for the stable across-retry key."""

    total: int
    """Total samples this eval expects to run (``len(dataset) * epochs``)."""

    task_id: str = ""
    """Stable task identifier across retries.

    On task retry, ``eval_id`` is regenerated (see
    :meth:`TaskLogger.reinit`) but ``task_id`` is preserved. Used by
    the control endpoint to fold retry attempts of the same task
    into a single row."""

    completed: int = 0
    """Samples that finished without error (counted once per sample, at the
    final attempt's success — retries don't double-count)."""

    errored: int = 0
    """Samples whose final attempt failed (also counted once per sample)."""

    cancelled: int = 0
    """Samples cancelled at their final attempt — a sibling's failure (or an
    eval cancel) tore the task down while they were in flight. Terminal but
    not a genuine error: counted toward the finish total so the eval isn't
    stuck "running", but kept separate from :attr:`errored` so it doesn't
    render as a failure."""

    task: str = ""
    """Task name. Carried here so consumers (control channel `tasks`) can label
    the eval even after all its samples have exited ``active_samples``
    (typically: under keep-alive, after the eval body completes)."""

    model: str = ""
    """Primary model name. Same rationale as :attr:`task`."""

    solver: str = ""
    """Solver name — the unqualified name of the plan's terminal step
    (an agent name for agentic tasks, e.g. ``react``). Same rationale
    as :attr:`task`."""

    log_location: str = ""
    """This eval's log file location. The per-sample listing reads
    completed samples from here once the live recorder is gone (see
    :attr:`live`)."""

    live: "LiveEvalData | None" = None
    """The running eval's live data source — the in-process ``TaskLogger`` (see
    :class:`LiveEvalData`).

    The gap-free, ahead-of-disk source the control endpoints prefer for this
    eval's sample summaries / full samples / transcript events, and the target
    of its flush / buffer directives. ``None`` for reused/synthetic evals (which
    fall back to :attr:`log_location` and :attr:`deferred_sample_stats`); set to
    ``None`` by :func:`detach_eval_live` when a retry supersedes the
    attempt the logger was bound to (after which reads fall back to
    :attr:`log_location` until the retry sweep removes that log)."""

    task_cancel: "TaskCancel | None" = None
    """The running attempt's cancel handle — the same ``TaskCancel`` the
    in-process task display's cancel dialog drives. The control channel's
    task-cancel directive fires it with ``"abort"`` (see
    :mod:`inspect_ai._control.cancel`). ``None`` for reused/synthetic evals
    (nothing is running, so there is nothing to cancel); each retry attempt
    registers its own handle, and :func:`latest_eval_for_task` resolves the
    current one."""

    sample_requeue: "SampleRequeue | None" = None
    """The running attempt's sample-requeue capability — the handle the
    control channel's requeue directive invokes (see
    :mod:`inspect_ai._control.requeue` and ``design/ctl/sample-requeue.md``).
    Set by :func:`set_sample_requeue` when the attempt's sample fanout
    starts (the scheduler it closes over doesn't exist at
    :func:`register_eval` time); ``None`` for reused/synthetic evals, and
    detached alongside :attr:`live` when a retry supersedes the attempt."""

    task_scoring: "TaskScoring | None" = None
    """The running attempt's interim-scoring capability — the task's scorers
    and scoring inputs as resolved at eval start, published for the control
    channel's ``task score`` directive (see :mod:`inspect_ai._control.scoring`
    and ``design/ctl/interim-scoring.md``). Set by :func:`set_task_scoring`
    from the task runner; ``None`` for reused/synthetic evals (nothing is
    running, so there is nothing to score in-process), and detached alongside
    :attr:`live` when a retry supersedes the attempt."""

    deferred_sample_stats: DeferredStatsProvider | None = None
    """Lazy accessor for a reused eval's summaries-derived stats
    (:class:`DeferredSampleStats`). Resolved once — on the first
    ``current_eval_summaries`` call — by
    :func:`resolve_deferred_sample_stats`, which overwrites
    :attr:`total_messages` / :attr:`completed` / :attr:`errored` and clears
    this field. Until then (and permanently, if the resolution read fails)
    those fields hold the header-derived provisional values set at
    registration. ``None`` for live evals."""

    log_sample_summaries: "list[EvalSampleSummary] | None" = None
    """Memoized on-disk sample summaries for the per-sample listing.

    Once :attr:`live` no longer serves summaries (eval finished and its
    recorder torn down, reused/synthetic eval, superseded retry attempt),
    the log at :attr:`log_location` is finalized and immutable — so the
    listing's fallback read of it is performed once and cached here, and
    every later request is served from memory (a keep-alive-parked process
    is polled indefinitely; re-reading an immutable log — possibly from
    S3 — per poll is pure waste). ``None`` until the first fallback read
    (and always while :attr:`live` serves summaries). Cleared by
    :func:`invalidate_log_sample_summaries` when the retry sweep deletes
    the log, so the memo can't outlive the file it was read from.

    Known limitation: "immutable" holds for every in-process writer (both
    recorders fully write and close the log before the fallback becomes
    reachable), but not for external ones — e.g. ``inspect score
    --overwrite`` from another process rewrites a finished log in place,
    and a parked process keeps serving the pre-rewrite rows for the rest
    of the park. If in-process rewriting of finished logs ever lands
    (e.g. interim scoring), it must call
    :func:`invalidate_log_sample_summaries` after rewriting."""

    sample_ids: list[str | int] = field(default_factory=list)
    """The eval's planned sample ids (after slicing). With :attr:`epochs`,
    the full set of planned ``(sample_id, epoch)`` pairs — which lets the
    per-sample listing surface *pending* (not-yet-started) samples, since
    no live source otherwise holds them. Empty for reused/synthetic evals
    (which have no pending samples)."""

    epochs: int = 1
    """Epoch count, paired with :attr:`sample_ids` to enumerate the
    planned ``(sample_id, epoch)`` pairs."""

    run_id: str | None = None
    """Process-level run id. Same rationale as :attr:`task`."""

    completed_at: float | None = None
    """Unix timestamp when this eval's last sample finished (i.e. when
    ``completed + errored`` first reached ``total``). ``None`` while the
    eval is still running. Used by the control endpoint to surface
    completion to agents without forcing them to derive it from counters.
    For a :attr:`dynamic` eval this is only stamped by :func:`finalize_eval`
    (the task's finish point) — counters reaching ``total`` doesn't mean
    done when the source can still add samples."""

    dynamic: bool = False
    """Whether this eval's planned sample set can grow while it runs (a
    ``SampleSource``-driven task). While set, ``terminal >= total`` is not
    proof of completion — the task may be idle awaiting its source (or have
    an empty seed, ``total == 0``, at registration) — so the provisional
    ``completed_at`` stamp is suppressed and consumers (task cancel, status
    listings) correctly see the eval as running. Cleared by
    :func:`finalize_eval`, the task's single true finish point."""

    started_at: float | None = None
    """Earliest observed sample-start time, tracked as a running minimum.

    Pinned here rather than recomputed from ``active_samples`` on every read
    so the eval's reported start stays fixed at its first sample's start. The
    live set only holds *currently active* samples, so a pure min over it
    creeps forward as early samples finish and leave ``active_samples`` (see
    ``_build_summary``). Fed from two sources via :meth:`observe_started`: the
    per-sample terminal records (``record_sample_*``), which capture a sample's
    start even if it finished and left ``active_samples`` before any control
    poll, and ``_build_summary``'s fold of the still-live samples' starts.
    Together they pin the true first start regardless of poll timing. ``None``
    until the first sample with a known start is observed; stays ``None`` for
    reused/synthetic evals (no live samples)."""

    will_retry: bool = False
    """Whether a failure of this attempt will be retried (task-level).

    Set from ``TaskCancel.can_retry`` at registration. Lets the control
    endpoint render a cancelled sample as ``pending`` (a retry will re-run
    it) rather than ``cancelled`` (terminal — no retry coming)."""

    retry_pending: bool = False
    """Whether this attempt finished with an error and a retry has been queued.

    Stamped by :func:`mark_eval_retry_pending` at the eval-set's retry
    decision point, so directives that would otherwise read a stamped
    :attr:`completed_at` as "task finished" (eg. task cancel) can answer
    honestly during the window between attempts — the retry registers its
    own :class:`EvalState` only when it actually starts, and until then
    this errored attempt is the task's latest. Never cleared: once the
    retry starts, :func:`latest_eval_for_task` resolves to its fresh
    state and this one is no longer consulted."""

    total_tokens: int = 0
    """Cumulative model tokens used by this eval's terminal samples.

    Accumulated once per sample at its final outcome (mirrors
    :attr:`completed` / :attr:`errored`), so it survives samples leaving
    ``active_samples`` — i.e. it's the "usage so far", not a live snapshot.
    The control endpoint adds the in-flight samples' live usage on top."""

    total_messages: int = 0
    """Cumulative message count, accumulated like :attr:`total_tokens`."""

    refusals: int = 0
    """Cumulative model refusals reported by this eval's finished samples.

    Accumulated by :func:`record_sample_event_counts` as each sample leaves
    ``active_samples``; the control endpoint adds the in-flight samples' live
    counts on top, exactly as it does for :attr:`total_tokens`.

    UNLIKE the usage totals, this counts every *attempt*: a sample retried under
    ``retry_on_error`` contributes the refusals of each attempt, because these are
    counts of events that happened rather than a property of the final state. That
    also keeps them consistent with the process-global counters the TUI footer
    shows, which likewise count every occurrence."""

    http_retries: int = 0
    """Cumulative HTTP retries (rate-limit and transient), accumulated like
    :attr:`refusals` — every attempt, not just the final one."""

    def observe_started(self, started: float | None) -> None:
        """Fold a sample's start time into :attr:`started_at` (running minimum).

        Lowers :attr:`started_at` toward the earliest start ever seen and never
        raises it, so the eval's reported start pins to its first sample. A
        ``None`` start (sample that never ran) contributes nothing. Caller must
        hold ``_lock`` (or otherwise serialise writes) — see :attr:`started_at`.
        """
        if started is not None and (
            self.started_at is None or started < self.started_at
        ):
            self.started_at = started

    @property
    def terminal(self) -> int:
        """Samples that reached a terminal outcome (completed/errored/cancelled).

        The single definition of the terminal sum — used by both
        :attr:`is_finished` and :func:`finalize_eval` so a future bucket
        can't be added to one and missed by the other.
        """
        return self.completed + self.errored + self.cancelled

    @property
    def is_finished(self) -> bool:
        """True once every sample has terminated (success, error, or cancel).

        A zero-sample eval is finished immediately: ``--limit`` can slice past
        the dataset (a valid, successful outcome), so ``total == 0`` must read
        as done (``0 >= 0``) rather than "running" forever. There's no spurious
        early-finish risk for ``total > 0`` — ``0 >= total`` is already False
        until enough samples terminate.
        """
        return self.terminal >= self.total


# Module-level registry. Keyed by eval_id. A process can host multiple
# evals concurrently (an eval-set passes all tasks to one ``eval()``
# call), so this is a dict not a single slot.
_eval_states: dict[str, EvalState] = {}
_lock = Lock()


def register_eval(
    eval_id: str,
    total: int,
    *,
    task: str = "",
    task_id: str = "",
    model: str = "",
    solver: str | None = None,
    log_location: str = "",
    live: "LiveEvalData | None" = None,
    sample_ids: list[str | int] | None = None,
    epochs: int = 1,
    run_id: str | None = None,
    will_retry: bool = False,
    task_cancel: "TaskCancel | None" = None,
    dynamic: bool = False,
) -> EvalState:
    """Initialize tracking for a new eval.

    Idempotent on ``eval_id`` — re-registering an existing eval (eg. on
    retry, which mints a fresh ``eval_id`` via ``TaskLogger.reinit``) returns
    the existing state without resetting its counters.
    """
    with _lock:
        existing = _eval_states.get(eval_id)
        if existing is not None:
            return existing
        state = EvalState(
            eval_id=eval_id,
            total=total,
            task=task,
            task_id=task_id,
            model=model,
            solver=solver or "",
            log_location=log_location,
            live=live,
            # copy: a SampleSource-driven task appends to its planned-ids list
            # as samples are injected; the state's list must grow only via
            # record_samples_added, not by aliasing the caller's list
            sample_ids=list(sample_ids or []),
            epochs=epochs,
            run_id=run_id,
            will_retry=will_retry,
            task_cancel=task_cancel,
            dynamic=dynamic,
        )
        _eval_states[eval_id] = state
        # A zero-sample eval (``total == 0``, eg. a limit past the dataset) is
        # already finished — no sample will ever run to fire a terminal counter
        # and stamp ``completed_at`` via record_sample_*, so do it now. A no-op
        # for the normal ``total > 0`` case (not yet finished at registration)
        # and for a dynamic eval (an empty seed just means the source hasn't
        # produced yet — finalize_eval stamps it when the task truly ends).
        _maybe_mark_finished(state)
        return state


def register_completed_eval(
    eval_id: str,
    *,
    total: int,
    completed: int,
    errored: int = 0,
    task: str = "",
    task_id: str = "",
    model: str = "",
    solver: str | None = None,
    log_location: str = "",
    run_id: str | None = None,
    completed_at: float | None = None,
    total_tokens: int = 0,
    total_messages: int = 0,
    deferred_sample_stats: DeferredStatsProvider | None = None,
) -> EvalState:
    """Register an eval that has already finished.

    Used by ``eval_set`` to publish synthetic state for tasks whose
    successful logs were reused from a prior run — those tasks never
    enter ``task_run.py``, so the per-sample counter path that would
    normally maintain the state never fires. This bulk-equivalent
    sets the terminal counters up-front so ``current_eval_summaries``
    surfaces the eval as completed.

    ``completed`` / ``errored`` / ``total_messages`` may be provisional
    (header-derived) values refined later by ``deferred_sample_stats`` —
    see :class:`DeferredSampleStats`.

    If an :class:`EvalState` for ``eval_id`` already exists, its
    fields are overwritten (the reused-log data is authoritative —
    we never reuse an eval that's also actively running).
    ``completed_at`` defaults to "now" when not supplied.
    """
    with _lock:
        state = EvalState(
            eval_id=eval_id,
            total=total,
            completed=completed,
            errored=errored,
            task=task,
            task_id=task_id,
            model=model,
            solver=solver or "",
            log_location=log_location,
            run_id=run_id,
            completed_at=completed_at if completed_at is not None else time.time(),
            total_tokens=total_tokens,
            total_messages=total_messages,
            deferred_sample_stats=deferred_sample_stats,
        )
        _eval_states[eval_id] = state
        return state


async def resolve_deferred_sample_stats(state: EvalState) -> None:
    """Resolve a reused eval's deferred summaries-derived stats (once).

    Claims the provider under the lock first, so concurrent requests perform
    at most one read (a loser briefly sees the provisional header-derived
    values — benign). Failure semantics by class:

    - Any ``Exception`` (unreadable or corrupt log — eg. ``BadZipFile``,
      storage backend errors): the provisional values stand permanently
      (they sum to ``total``, so the row still renders terminal) and the
      provider is not retried. The read must never fail the surrounding
      request, and a caught failure must never cancel sibling resolutions.
    - Cancellation (client disconnect / server teardown mid-read): the
      claim is restored so a later request retries the resolution, rather
      than stranding the row on provisional values forever.
    """
    with _lock:
        provider = state.deferred_sample_stats
        state.deferred_sample_stats = None
    if provider is None:
        return
    try:
        stats = await provider()
    except Exception as ex:
        logger.warning(
            "Could not resolve sample stats for reused eval %s (%s): %s",
            state.eval_id,
            state.log_location,
            ex,
        )
        return
    except BaseException:
        # cancelled mid-read — restore the claim for a later retry
        with _lock:
            if state.deferred_sample_stats is None:
                state.deferred_sample_stats = provider
        raise
    with _lock:
        state.total_messages = stats.total_messages
        state.completed = stats.completed
        state.errored = stats.errored


def record_sample_completed(
    eval_id: str, *, tokens: int = 0, messages: int = 0, started: float | None = None
) -> None:
    """Mark a sample as having finished successfully, accumulating its usage.

    Called once per sample at the final outcome — retries don't increment.
    ``tokens`` / ``messages`` are that sample's model usage, accumulated into
    the eval total so usage survives the sample leaving ``active_samples``
    (the "usage so far"). ``started`` is the sample's start time, folded into
    the eval's running-minimum start (see :attr:`EvalState.started_at`) so a
    sample that finished before any control poll still pins the eval start.
    Silently no-ops if the eval isn't registered.
    """
    with _lock:
        state = _eval_states.get(eval_id)
        if state is not None:
            state.completed += 1
            state.total_tokens += tokens
            state.total_messages += messages
            state.observe_started(started)
            _maybe_mark_finished(state)


def record_sample_errored(
    eval_id: str, *, tokens: int = 0, messages: int = 0, started: float | None = None
) -> None:
    """Mark a sample as having finished with an error, accumulating its usage.

    Called once per sample at the final outcome (after retries are exhausted).
    ``tokens`` / ``messages`` / ``started`` are handled exactly as in
    :func:`record_sample_completed`. Silently no-ops if the eval isn't
    registered.
    """
    with _lock:
        state = _eval_states.get(eval_id)
        if state is not None:
            state.errored += 1
            state.total_tokens += tokens
            state.total_messages += messages
            state.observe_started(started)
            _maybe_mark_finished(state)


def record_sample_cancelled(
    eval_id: str, *, tokens: int = 0, messages: int = 0, started: float | None = None
) -> None:
    """Mark a sample as terminally cancelled (sibling failure / eval cancel).

    Terminal but not a genuine error — counted toward the finish total (so the
    eval isn't stuck "running") in its own bucket, separate from ``errored``.
    Usage and ``started`` accumulate like the other terminal records. No-ops if
    unregistered.
    """
    with _lock:
        state = _eval_states.get(eval_id)
        if state is not None:
            state.cancelled += 1
            state.total_tokens += tokens
            state.total_messages += messages
            state.observe_started(started)
            _maybe_mark_finished(state)


def record_sample_requeued(
    eval_id: str, prior_status: Literal["error", "cancelled"]
) -> None:
    """Re-open a terminal sample's slot when a requeue is accepted.

    Decrements the bucket the prior terminal outcome bumped (``errored`` or
    ``cancelled``, per the prior record's status) — the sample re-occupies
    its planned slot, so ``total`` never changes and the re-run bumps a
    bucket again at its own terminal outcome (``terminal == total`` still
    holds at the end; :func:`finalize_eval`'s shortfall fold reconciles a
    re-run torn down before recording). Cumulative usage
    (``total_tokens`` / ``total_messages``) is *not* rolled back — the
    prior attempt's spend was real. Called synchronously in the requeue
    accept path (see ``design/ctl/sample-requeue.md``). Silently no-ops if
    the eval isn't registered.

    Guarded against decrementing a bucket below zero: that would mean the
    caller's message-based classification of the prior record diverged from
    the bucket its terminal recording actually bumped, so fail loudly (a
    warning naming the divergence) rather than corrupting the counters.
    """
    with _lock:
        state = _eval_states.get(eval_id)
        if state is not None:
            bucket = "errored" if prior_status == "error" else "cancelled"
            count = getattr(state, bucket)
            if count <= 0:
                logger.warning(
                    f"requeue accepted a prior with status '{prior_status}' "
                    f"but the eval's {bucket} count is {count} (eval "
                    f"{eval_id}) — classification/bucket divergence; not "
                    "decremented"
                )
            else:
                setattr(state, bucket, count - 1)


def set_sample_requeue(eval_id: str, handle: "SampleRequeue | None") -> None:
    """Register the running attempt's sample-requeue capability.

    Called by ``task_run`` when the sample fanout starts — later than
    :func:`register_eval`, because the scheduler the handle closes over
    doesn't exist until then. Silently no-ops if the eval isn't registered.
    """
    with _lock:
        state = _eval_states.get(eval_id)
        if state is not None:
            state.sample_requeue = handle


def set_task_scoring(eval_id: str, handle: "TaskScoring | None") -> None:
    """Register the running attempt's interim-scoring capability.

    Called by ``task_run`` alongside registration, with the task's scorers
    and scoring inputs as resolved at eval start (the interim-scoring pass
    uses the task's own scorers — a control-channel non-goal to override
    them mid-flight). Silently no-ops if the eval isn't registered.
    """
    with _lock:
        state = _eval_states.get(eval_id)
        if state is not None:
            state.task_scoring = handle


def record_samples_added(
    eval_id: str, total: int, *, sample_ids: list[str | int] | None = None
) -> None:
    """Grow a running eval's planned totals when samples are added dynamically.

    Called by ``task_run`` when a ``SampleSource`` injects samples mid-run:
    ``total`` is the number of additional planned runs (samples × epochs) and
    ``sample_ids`` the injected ids (so the per-sample listing can surface them
    as pending). The eval is :attr:`EvalState.dynamic`, so no provisional
    finish stamp needs clearing here — ``completed_at`` stays ``None`` until
    :func:`finalize_eval`. No-ops if unregistered.
    """
    with _lock:
        state = _eval_states.get(eval_id)
        if state is not None:
            state.total += total
            if sample_ids:
                state.sample_ids.extend(sample_ids)


def record_sample_event_counts(
    eval_id: str, *, refusals: int = 0, http_retries: int = 0
) -> None:
    """Accumulate a finished sample's refusal / HTTP-retry counts onto the eval.

    Separate from the ``record_sample_*`` family, and called from a different
    place, because it answers a different question. Those fire once per sample at
    its *final* outcome and carry that outcome's usage; this fires as each
    *attempt* leaves ``active_samples``, since a retried attempt's refusals and
    retries really did happen and are usually the very thing being watched (see
    :attr:`EvalState.refusals`).

    Called with the counts rather than the sample so this module keeps no
    dependency on the log package (it is imported during eval bootstrap, before
    the log package finishes initializing). Silently no-ops if the eval isn't
    registered, and short-circuits when there is nothing to add — the common case,
    since most samples neither refuse nor retry.
    """
    if not refusals and not http_retries:
        return
    with _lock:
        state = _eval_states.get(eval_id)
        if state is not None:
            state.refusals += refusals
            state.http_retries += http_retries


def latest_eval_for_task(task_id: str) -> "EvalState | None":
    """The last-registered attempt of ``task_id``, or ``None`` if untracked.

    The same fold rule the summaries use (registration order — a retry
    registers after the attempt it supersedes), so a task-keyed directive
    acts on the attempt the read surface reports as current. A non-``None``
    result doubles as the existence check for task-keyed directives —
    including reused-log tasks registered via :func:`register_completed_eval`,
    which never run here but should get "not adjustable" warnings rather
    than a 404. A falsy ``task_id`` never resolves (states without one are
    addressable only by eval id).
    """
    if not task_id:
        return None
    with _lock:
        latest = None
        for state in _eval_states.values():
            if state.task_id == task_id:
                latest = state
        return latest


def mark_eval_retry_pending(eval_id: str) -> None:
    """Record that a retry of this (errored, finished) attempt has been queued.

    Called by the eval-set runner at the point it decides to re-queue a
    failed task — after the attempt's ``finalize_eval`` (which stamped
    ``completed_at``) and before the retry attempt starts (which registers
    a fresh :class:`EvalState`). See :attr:`EvalState.retry_pending` for
    why the window between those two events needs the flag. No-ops if the
    eval isn't registered.
    """
    with _lock:
        state = _eval_states.get(eval_id)
        if state is not None:
            state.retry_pending = True


def detach_eval_live(eval_id: str) -> None:
    """Detach a superseded attempt's live data source.

    Called by ``TaskLogger.reinit()`` when a task retry re-points the (one,
    shared) logger at a fresh attempt: the superseded attempt's :attr:`live`
    is that same logger, so left attached it would silently serve the *new*
    attempt's recorder/log/buffer data under the old attempt's eval_id.
    Clearing it makes the superseded attempt's reads fall back to its own
    ``log_location`` — its data stays correct until the retry sweep removes
    that log, after which per-sample reads degrade to empty/404 (the counters
    on the state itself are unaffected). :attr:`EvalState.log_sample_summaries`
    is deliberately left alone: it holds data read from this attempt's *own*
    log, which stays correct until that log is deleted —
    :func:`invalidate_log_sample_summaries` handles that moment.

    The attempt-scoped :attr:`sample_requeue` handle is detached here too: a
    requeue aimed at a superseded attempt's ``eval_id`` must be rejected, not
    mutate a dead attempt's scheduler. Likewise :attr:`task_scoring` — a
    scoring pass aimed at a superseded attempt must not run against a dead
    attempt's recorder (the retry attempt registers a fresh handle) — and a
    scoring pass already *running* against this attempt is cancelled: left
    alone it would keep presenting itself as the task's current pass and,
    via the one-pass-per-task guard, block ``ctl task score`` against the
    new attempt until it drained.

    No-ops if the eval isn't registered.
    """
    with _lock:
        state = _eval_states.get(eval_id)
        if state is not None:
            state.live = None
            state.sample_requeue = None
            state.task_scoring = None
    if state is not None and state.task_id:
        from inspect_ai._control.scoring import cancel_score_pass

        cancel_score_pass(state.task_id, eval_id)


def invalidate_log_sample_summaries(eval_id: str) -> None:
    """Drop an eval's memoized on-disk sample summaries.

    Call after deleting (or rewriting) the log the memo was read from, so
    the memo can't outlive it — later listing reads re-attempt the on-disk
    read. Keyed by ``eval_id`` (the log's header carries it) rather than by
    matching ``log_location`` strings, which differ in form between fsspec
    listings and registration (``file://`` prefixes). No-ops if the eval
    isn't registered.
    """
    with _lock:
        state = _eval_states.get(eval_id)
        if state is not None:
            state.log_sample_summaries = None


def finalize_eval(eval_id: str) -> None:
    """Reconcile terminal counters when a task finishes.

    A sample cancelled while still *queued* (eg. parked at the sample
    semaphore when a sibling's failure tears the task group down) never
    reaches a per-sample terminal record — the cancellation propagates
    before its recording code runs, so ``completed + errored + cancelled``
    can fall short of ``total`` and the eval would read "running" forever.
    Called at the task's single finish point, after every sample task has
    exited: any planned sample still unaccounted for can no longer run in
    this attempt, so fold the shortfall into :attr:`EvalState.cancelled`
    (the existing bucket for teardown cancellations) and stamp
    ``completed_at``. A no-op when the counters already reached ``total``,
    and for unregistered evals (eg. ``run_samples=False``, which returns
    before registration).

    Folded samples have no per-sample record, so the samples listing
    intentionally omits them: they never started, so there is nothing to
    show and no value in identifying them individually. The counters, not
    the listing row count, are authoritative for totals.
    """
    with _lock:
        state = _eval_states.get(eval_id)
        if state is not None:
            shortfall = state.total - state.terminal
            if shortfall > 0:
                state.cancelled += shortfall
            # the task has truly finished — no source can add samples now, so
            # the dynamic suppression of the finish stamp no longer applies
            state.dynamic = False
            _maybe_mark_finished(state)


def _maybe_mark_finished(state: EvalState) -> None:
    """Stamp ``completed_at`` when every sample has terminated.

    Fires the first time the terminal sum (``completed + errored +
    cancelled``) reaches ``total``; later updates are no-ops so a late
    counter update from a teardown race doesn't overwrite the original
    finish time. Suppressed for a :attr:`EvalState.dynamic` eval — its
    counters reaching ``total`` doesn't mean done (the source may add more
    samples); ``finalize_eval`` clears the flag at the task's true finish
    point. Also drops
    ``sample_ids`` — a finished eval has no pending samples, so the
    planned-id list is dead weight (it's retained on the state until the
    run boundary clears it). Caller must hold the registry lock.
    """
    if state.completed_at is None and not state.dynamic and state.is_finished:
        state.completed_at = time.time()
        state.sample_ids = []


def get_eval_state(eval_id: str) -> EvalState | None:
    """Look up state for one eval, or None if not tracked."""
    with _lock:
        return _eval_states.get(eval_id)


def stable_task_id_for_eval(eval_id: str) -> str:
    """The stable across-retry task id for ``eval_id``.

    The limit-override store is keyed by the *stable* task id
    (``EvalSpec.task_id`` — the control channel's handle, preserved across
    retry attempts), while callers typically hold a per-attempt eval id.
    An unregistered eval (or a pre-``task_id`` record) falls back to the
    eval id itself, where no directive can write anyway.
    """
    state = get_eval_state(eval_id)
    return (state.task_id if state is not None else "") or eval_id


def get_eval_states() -> list[EvalState]:
    """Snapshot of all currently-tracked eval states."""
    with _lock:
        return list(_eval_states.values())


def clear_all_eval_states() -> None:
    """Remove every tracked eval state.

    Called at the outermost run boundary (``eval`` / ``eval_set``) — after
    any keep-alive park — to clear the registry in one shot, since evals
    are no longer unregistered individually. The terminal-source caches
    (events / messages) are cleared in the same shot: every cached source
    was derived from a registered eval, so none may outlive the registry.
    """
    from inspect_ai._control.terminal_cache import clear_terminal_source_caches

    with _lock:
        _eval_states.clear()
    clear_terminal_source_caches()


def reset_run_registries() -> None:
    """Reset the process-scoped control-channel registries at a run boundary.

    The single reset call for the outermost run boundary (``eval`` /
    ``eval_set``, after any keep-alive park). Both boundaries call this one
    helper so a future process-scoped registry can't get its reset added at
    one boundary and leak stale state through the other — add new resets
    here, not at the call sites.
    """
    from inspect_ai._control.config_record import reset_process_config_updates
    from inspect_ai._control.max_tasks import reset_max_tasks_override
    from inspect_ai._control.pause import (
        reset_process_pause,
        reset_task_pause_gates,
    )
    from inspect_ai._control.scoring import reset_score_passes
    from inspect_ai.model._generate_overrides import (
        reset_generate_config_overrides,
    )
    from inspect_ai.model._throughput import init_model_throughput
    from inspect_ai.util._limit_overrides import reset_sample_limit_overrides

    clear_all_eval_states()
    reset_generate_config_overrides()
    reset_max_tasks_override()
    reset_sample_limit_overrides()
    reset_process_config_updates()
    reset_task_pause_gates()
    init_model_throughput()
    reset_process_pause()
    reset_score_passes()
