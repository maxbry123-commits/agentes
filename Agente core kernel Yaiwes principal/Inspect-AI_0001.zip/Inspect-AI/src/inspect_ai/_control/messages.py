"""One sample's current conversation for the control channel.

Backs ``GET /evals/<id>/sample/messages`` (and ``inspect ctl sample
messages``): a **snapshot** of one sample's ``TaskState.messages`` — the
top-level conversation as it looks right now — read from the live
``TaskState`` while the sample is running, and once terminal from the
recorder's sample (buffer, then on-disk log).

Unlike ``sample events``, this is deliberately *not* cursored. The message
list is rewritable — compaction replaces a prefix with a summary, and solver /
agent code can edit or wholesale-reassign ``state.messages`` — so an index
cursor over it could not deliver the exactly-once resume the event cursor
promises. Each call returns the whole conversation (or a recent tail),
enveloped with ``as_of`` / the sample ``status`` / the total ``count``; a
watcher polls (the moving ``count`` is the cheap staleness signal) or follows
``sample events`` for incremental, event-grain watching.

See ``design/control-channel.md`` ("Sample messages read") for the full
rationale.
"""

from __future__ import annotations

import time
from typing import TYPE_CHECKING, Any, NamedTuple

# The compact message projection shares its truncation helpers with the events
# projection so the two renderings of the same underlying objects can't drift.
from inspect_ai._control.events import _to_text, _truncate
from inspect_ai._control.terminal_cache import (
    TerminalSourceCache,
    resolve_sample_source,
)

if TYPE_CHECKING:
    from inspect_ai.model._chat_message import ChatMessage


class MessagesSource(NamedTuple):
    """One resolvable source of a sample's conversation.

    Produced by :func:`_running_source` (live ``TaskState``) and
    :func:`_resolve_logged_source` (recorder / on-disk log); consumed by
    :func:`sample_messages`.
    """

    messages: list["ChatMessage"]
    """The sample's current conversation (a snapshot copy)."""

    status: str
    """``running`` / ``completed`` / ``error``."""


# Short-TTL cache of resolved terminal sources. A terminal sample's
# conversation is immutable, but `tail` bounds only the *response* — the
# whole-conversation parse and attachment resolution run per request (see
# _resolve_logged_source), re-paid per poll against a source that can never
# change. See terminal_cache for the staleness bounds.
_terminal_sources: TerminalSourceCache[MessagesSource] = TerminalSourceCache()


async def sample_messages(
    eval_id: str,
    sample_id: str,
    epoch: int,
    *,
    tail: int | None = None,
    content: bool = False,
    full: bool = False,
) -> dict[str, Any] | None:
    """A snapshot of one sample's current conversation.

    Returns an ``{as_of, status, count, messages}`` envelope (see the module
    docstring), or ``None`` when the eval/sample isn't found in this process —
    the endpoint turns that into a 404.

    Args:
        eval_id: The eval's id.
        sample_id: The sample's id (string; matched against running + logged).
        epoch: The sample epoch.
        tail: Only the last ``tail`` messages (``None`` = the whole list;
            negative values clamp to 0, an empty window).
        content: Include (truncated) free-text content — message text, tool
            arguments, tool errors — in the compact projection. The default
            is metadata only (see :func:`_project`).
        full: Raw serialized ``ChatMessage`` objects instead of the compact
            projection.
    """
    # `as_of` is stamped before the read so a client comparing successive
    # `count`s can't miss a change that lands mid-read.
    as_of = time.time()

    source = await resolve_sample_source(
        (eval_id, sample_id, epoch),
        running=lambda: _running_source(eval_id, sample_id, epoch),
        cache=_terminal_sources,
        resolve_terminal=lambda: _resolve_logged_source(eval_id, sample_id, epoch),
    )
    if source is None:
        return None

    messages, status = source
    count = len(messages)

    # `tail` selects a recent window; the projection still reports each
    # message's absolute index so a tailed view lines up with the full one.
    # A negative `tail` (raw HTTP callers — the CLI validates) clamps to an
    # empty window rather than overshooting the slice bounds.
    start = max(0, count - max(0, tail)) if tail is not None else 0
    projected = [
        _project(message, index, content=content, full=full)
        for index, message in enumerate(messages[start:], start=start)
    ]

    return {
        "as_of": as_of,
        "status": status,
        "count": count,
        "messages": projected,
    }


# --- sources ---------------------------------------------------------------


def _running_source(eval_id: str, sample_id: str, epoch: int) -> MessagesSource | None:
    """The live source for a sample, or ``None`` if it isn't running here.

    Reads the sample's live ``TaskState.messages`` off ``ActiveSample
    .live_state`` — an in-memory snapshot, no log involved, which is why a
    sample that exists only in the process buffer still has a conversation to
    serve. The control server shares the eval's event loop, so copying the
    list here can never observe a half-applied append or rewrite.
    """
    from inspect_ai._control.state import find_active_sample

    s = find_active_sample(eval_id, sample_id, epoch)
    if s is None or s.live_state is None:
        return None
    return MessagesSource(
        messages=list(s.live_state.messages),
        status="completed" if s.completed is not None else "running",
    )


async def _resolve_logged_source(
    eval_id: str, sample_id: str, epoch: int
) -> MessagesSource | None:
    """The terminal source for a sample (recorder buffer, then on-disk log).

    ``None`` when the eval/sample isn't available here. Reads the
    ``EvalSample`` via :func:`inspect_ai._control.state._full_sample` — the
    same gap-free recorder-then-log source the error-detail and events reads
    use — excluding the heavy fields the response never consumes (``events``
    dwarfs the rest for a long agentic sample), and resolves its content
    attachments in ``core`` mode (which covers ``messages``; ``full`` would
    additionally walk the excluded events/model-calls) so image/large-text
    refs render as real content rather than ``attachment://`` placeholders.
    """
    from inspect_ai._control.state import _full_sample

    sample = await _full_sample(
        eval_id, sample_id, epoch, exclude_fields={"events", "store", "output"}
    )
    if sample is None:
        return None

    from inspect_ai.log._condense import resolve_sample_attachments

    sample = resolve_sample_attachments(sample, "core")
    return MessagesSource(
        messages=list(sample.messages or []),
        status="error" if sample.error is not None else "completed",
    )


# --- projection ------------------------------------------------------------


def _project(
    message: "ChatMessage", index: int, *, content: bool, full: bool
) -> dict[str, Any]:
    """Raw serialized message (``full``) or a compact, context-cheap summary.

    The compact form always carries the message's index / id / role, the
    tool-call function names on assistant messages, and the function / error
    *presence* on tool messages — pure metadata. ``content`` adds the
    truncated free-text fields: the message text (non-text content items
    summarized as ``[image]`` / ``[audio]`` / …), tool-call arguments, and
    tool error messages. The metadata default exists so a monitor that never
    reads agent-controlled text — and so can't be prompt-injected by it — is
    the effortless default consumer (see "Trust boundary for readers" in
    design/ctl/control-channel.md).
    """
    if full:
        out = message.model_dump(mode="json")
        out["index"] = index
        return out

    projected: dict[str, Any] = {
        "index": index,
        "id": message.id,
        "role": message.role,
    }
    if content:
        projected["content"] = _content_summary(message)
    if message.role == "assistant":
        tool_calls = getattr(message, "tool_calls", None)
        if tool_calls:
            projected["tool_calls"] = [
                {
                    "id": call.id,
                    "function": call.function,
                    **(
                        {"arguments": _truncate(_to_text(call.arguments))}
                        if content
                        else {}
                    ),
                }
                for call in tool_calls
            ]
    elif message.role == "tool":
        projected["function"] = getattr(message, "function", None)
        tool_error = getattr(message, "error", None)
        projected["has_error"] = tool_error is not None
        if content:
            projected["error"] = (
                getattr(tool_error, "message", None) if tool_error else None
            )
    return projected


def _content_summary(message: "ChatMessage") -> str:
    """Truncated text of a message, with non-text content items summarized.

    A string content renders (truncated) directly; a list of content items
    renders each text/reasoning item's text and each non-text item as a
    ``[kind]`` placeholder, so an image-bearing message reads as
    ``… [image] …`` rather than a wall of base64.
    """
    content = message.content
    if isinstance(content, str):
        return _truncate(content)

    parts: list[str] = []
    for item in content:
        item_type = getattr(item, "type", None)
        if item_type in ("text", "reasoning"):
            parts.append(getattr(item, item_type, "") or "")
        else:
            parts.append(f"[{item_type or 'content'}]")
    return _truncate(" ".join(p for p in parts if p))
