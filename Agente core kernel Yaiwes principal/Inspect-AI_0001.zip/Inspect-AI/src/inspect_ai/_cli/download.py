"""CLI commands for inspect-managed binary downloads.

Currently exposes a single subcommand, ``restic``, which pre-warms the
restic binary cache (every supported platform) so that a checkpointed
eval starts without waiting for downloads.

Shape is ``inspect download <kind>`` so other downloadable artifacts
can slot in without restructuring the namespace.
"""

import anyio
import click
from rich import box
from rich.console import Console
from rich.table import Table

from inspect_ai._util._async import configured_async_backend
from inspect_ai.util._restic import (
    SUPPORTED_PLATFORMS,
    Platform,
    cache_path,
    resolve_restic,
)


@click.group("download")
def download_command() -> None:
    """Inspect-managed binary downloads."""


@download_command.command("restic")
def restic_command() -> None:
    """Pre-warm the restic binary cache for every supported platform."""
    anyio.run(_download_all_restic, backend=configured_async_backend())


async def _download_all_restic() -> None:
    console = Console()

    for platform in SUPPORTED_PLATFORMS:
        if cache_path(platform).exists():
            console.print(
                f"[dim]○[/dim] {_display_platform(platform)}  [dim]already cached[/dim]"
            )
            continue
        with console.status(f"Downloading {_display_platform(platform)}…"):
            await resolve_restic(platform)
        console.print(f"[green]✓[/green] {_display_platform(platform)}  downloaded")

    console.print()
    table = Table(
        title="Cache state",
        title_justify="left",
        title_style="bold",
        box=box.SQUARE,
    )
    table.add_column("Platform", no_wrap=True)
    table.add_column("Path", overflow="fold")
    for platform in SUPPORTED_PLATFORMS:
        table.add_row(_display_platform(platform), str(cache_path(platform)))
    console.print(table)


def _display_platform(platform: Platform) -> str:
    return platform.replace("_", "/")
