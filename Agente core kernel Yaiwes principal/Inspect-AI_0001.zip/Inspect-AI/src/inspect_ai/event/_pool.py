"""Message and call pool deduplication for eval samples.

Design note — hash-based dedup
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Pool dedup keys on a murmur3 hash of the canonical JSON serialisation of
each ChatMessage (pydantic field order; dict fields keep insertion order
through a serialize/parse round-trip, so rebuild-time hashes match),
excluding the ``id`` field so that messages with identical content but
different UUIDs are treated as duplicates.

``condense_model_event_inputs`` hashes every message and relies on a
per-call ``id(obj)`` cache; that is O(N) only when a single call spans
all events (the final-log and recover paths). ``condense_model_event_calls``
additionally uses prefix-matching against the previous event's wire list
to skip hashing the equal prefix, hashing only the divergent tail per
event; the batch call is O(total unique call messages).

Per-event callers (the sample buffer and the transcript store) must NOT
call these one event at a time — that is O(N²) in conversation length
(each of the N model events carries the full ~N-message history). They
use the incremental indices in ``inspect_ai.event._pool_index`` instead,
which resolve re-sent messages by object identity / id-bucket equality
and hash only genuinely new content.
"""

import dataclasses
import json
from collections.abc import Iterable, Mapping, Sequence
from typing import Final, Literal, NamedTuple, TypeVar, cast

from pydantic import BaseModel, JsonValue
from pydantic_core import to_jsonable_python

from inspect_ai._util.hash import mm3_hash
from inspect_ai.event._validate import validate_events
from inspect_ai.model._chat_message import ChatMessage

from ._event import Event
from ._model import ModelEvent


def materialize_pooled_events(
    events: Iterable[object],
    message_pool: Sequence[ChatMessage] | Mapping[int, ChatMessage],
    call_pool: Sequence[JsonValue] | Mapping[int, JsonValue],
) -> list[Event]:
    materialized = validate_events(list(events))
    materialized = resolve_model_event_inputs(materialized, message_pool)
    return resolve_model_event_calls(materialized, call_pool)


def _strict_eq(a: object, b: object) -> bool:
    """Equality that distinguishes values with different JSON serializations.

    Python ``==`` conflates values the pool hashes distinguish: ``0 == 0.0``
    and ``True == 1``, but ``json.dumps`` emits different bytes for each, so
    ``_msg_hash``/``_call_hash`` differ. An ``==``-based merge of such values
    would reuse a pool entry whose stored bytes round-trip to the *other*
    value — silent data corruption. This comparison requires matching types
    for scalars (recursing into models, dataclasses, dicts, and lists), so a
    merge implies identical serialization.
    """
    if a is b:
        return True
    ta, tb = type(a), type(b)
    if ta is not tb:
        return False
    if isinstance(a, BaseModel):
        return _strict_eq(a.__dict__, b.__dict__)  # type: ignore[attr-defined]
    if dataclasses.is_dataclass(a) and not isinstance(a, type):
        return _strict_eq(vars(a), vars(b))
    if ta is dict:
        assert isinstance(a, dict) and isinstance(b, dict)
        if len(a) != len(b):
            return False
        sentinel = object()
        for k, v in a.items():
            other = b.get(k, sentinel)
            if other is sentinel or not _strict_eq(v, other):
                return False
            # dict lookup matches keys by ==, which conflates 0/0.0 and
            # True/1 on the key axis just like values ({0: x} and {0.0: x}
            # serialize to different JSON); str keys (the JSON-bound common
            # case) cannot ==-collide across types, so only non-str keys
            # need their counterpart's type checked
            if type(k) is not str and not any(
                bk == k and type(bk) is type(k) for bk in b
            ):
                return False
        return True
    if ta is list or ta is tuple:
        assert isinstance(a, (list, tuple)) and isinstance(b, (list, tuple))
        return len(a) == len(b) and all(_strict_eq(x, y) for x, y in zip(a, b))
    return a == b


def _msg_hash(msg: ChatMessage) -> str:
    # Hash pydantic's canonical serialization directly (field order is
    # class-definition order; dict fields keep insertion order through a
    # serialize/parse round-trip, so rebuild-time hashes match). A dict
    # with different key insertion order hashes differently — that only
    # costs a duplicate pool entry, never wrong dedup.
    return mm3_hash(msg.model_dump_json(exclude={"id"}))


def _msg_pool_jsonable(msg: ChatMessage) -> JsonValue:
    """Jsonable form of a message-pool row (serialize with `_msg_pool_json`)."""
    return cast(
        JsonValue, to_jsonable_python(msg, exclude_none=True, fallback=lambda _: None)
    )


def _msg_pool_json(message_jsonable: JsonValue) -> str:
    """Serialize a message-pool row for storage.

    Owns the hash↔storage round-trip invariant: stored bytes must re-parse
    to a message whose `_msg_hash` equals the hash stored beside them.
    `_msg_hash` hashes insertion-order serialization, so storage must
    preserve insertion order too — never ``sort_keys=True``, which would
    reorder dict fields (tool-call arguments, metadata) and make re-seeded
    rows miss their own hash, duplicating pool entries on every resume.
    """
    return json.dumps(message_jsonable)


def _call_hash(call_msg: JsonValue) -> str:
    return mm3_hash(json.dumps(call_msg, sort_keys=True))


def _call_pool_json(call_msg: JsonValue) -> str:
    """Serialize a call-pool row for storage.

    Owns the hash↔storage round-trip invariant for the call pool: stored
    bytes must re-hash (via `_call_hash` after re-parse) to the hash stored
    beside them. `_call_hash` sorts keys, so storage sorts keys too.
    """
    return json.dumps(call_msg, sort_keys=True)


def _build_msg_index(pool: list[ChatMessage]) -> dict[str, int]:
    """Build hash -> pool index mapping, matching condense_model_event_inputs logic."""
    index: dict[str, int] = {}
    for i, msg in enumerate(pool):
        index[_msg_hash(msg)] = i
    return index


def _build_call_index(pool: list[JsonValue]) -> dict[str, int]:
    """Build hash -> pool index mapping, matching condense_model_event_calls logic."""
    index: dict[str, int] = {}
    for i, call_msg in enumerate(pool):
        index[_call_hash(call_msg)] = i
    return index


def condense_model_event_inputs(
    events: Sequence[Event],
    next_index: int,
    msg_index: Mapping[str, int],
) -> tuple[list[Event], dict[str, int], list[tuple[str, ChatMessage]]]:
    """Replace ModelEvent.input with message_pool references.

    Assigns each unique ChatMessage a position starting at ``next_index``
    and replaces ModelEvent inputs with range-encoded input_refs into a
    pool. Callers that need the pool list must rebuild it from
    ``new_entries`` (in order of appearance).

    See module docstring for the hash-based dedup strategy.

    Args:
        events: Events to condense.
        next_index: The pool position assigned to the first new unique
            message, typically the current pool length for callers carrying
            an existing pool.
        msg_index: Existing hash → pool-index map carried forward across
            calls.

    Returns:
        A tuple of (condensed events, updated index, new entries
        appended this call as ``(hash, msg)`` pairs in pool-position
        order).
    """
    index = dict(msg_index)
    obj_id_cache: dict[int, str] = {}
    new_entries: list[tuple[str, ChatMessage]] = []
    result: list[Event] = []
    for event in events:
        if isinstance(event, ModelEvent):
            if event.input_refs is not None and not event.input:
                result.append(event)
                continue
            if event.input:
                raw_indices: list[int] = []
                for msg in event.input:
                    obj_key = id(msg)
                    h = obj_id_cache.get(obj_key) or obj_id_cache.setdefault(
                        obj_key, _msg_hash(msg)
                    )
                    if h not in index:
                        index[h] = next_index + len(new_entries)
                        new_entries.append((h, msg))
                    raw_indices.append(index[h])
                event = event.model_copy(
                    update={"input": [], "input_refs": _compress_refs(raw_indices)}
                )
        result.append(event)
    return result, index, new_entries


# Known keys for messages array in provider wire formats
_CALL_MESSAGE_KEYS: Final = ("messages", "contents", "input", "inputs")


def _compress_refs(indices: list[int]) -> list[tuple[int, int]]:
    """Compress contiguous int indices into range-encoded refs.

    Every element is a ``(start, end_exclusive)`` range pair.

    Examples::

        [0,1,2,3]   -> [(0,4)]
        [0,3,4,5,9] -> [(0,1),(3,6),(9,10)]
        [2,5,8]     -> [(2,3),(5,6),(8,9)]
        [3,4]       -> [(3,5)]
    """
    if not indices:
        return []
    result: list[tuple[int, int]] = []
    start = indices[0]
    end_exclusive = start + 1
    for i in indices[1:]:
        if i == end_exclusive:
            end_exclusive += 1
        else:
            result.append((start, end_exclusive))
            start = i
            end_exclusive = i + 1
    result.append((start, end_exclusive))
    return result


_T = TypeVar("_T")


def _expand_refs(
    refs: list[tuple[int, int]],
    pool: Sequence[_T] | Mapping[int, _T],
) -> list[_T]:
    """Expand range-encoded refs against a pool.

    Each element is ``(start, end_exclusive)``: yields ``pool[start:end_exclusive]``.
    Position-keyed mappings (page-scoped buffer reads carry only the positions
    their events reference) are indexed per position, skipping absent positions
    to mirror slice truncation of out-of-range refs.
    """
    result: list[_T] = []
    if isinstance(pool, Mapping):
        for start, end_exclusive in refs:
            result.extend(pool[i] for i in range(start, end_exclusive) if i in pool)
    else:
        for start, end_exclusive in refs:
            result.extend(pool[start:end_exclusive])
    return result


class PoolRefField(NamedTuple):
    """Location of a range-encoded pool-ref field on a condensed event."""

    pool: Literal["message", "call"]
    """Which pool the refs index into."""

    path: tuple[str, ...]
    """Key path from the event root to the refs list, in raw JSON form."""


POOL_REF_FIELDS: Final[tuple[PoolRefField, ...]] = (
    PoolRefField(pool="message", path=("input_refs",)),
    PoolRefField(pool="call", path=("call", "call_refs")),
)
"""Registry of every event field that carries range-encoded pool refs.

Everything that reads or rewrites pool refs must agree on which event
fields hold them, and this registry is their single source of truth:

- the condense/resolve functions in this module, which write and read the
  typed fields;
- :func:`collect_pool_ref_positions`, which the buffer's page-scoped reads
  use to load only the pool entries a page's events reference;
- :func:`remap_pool_refs`, which export paths use to translate refs after
  pool entries are assigned new positions in a destination store;
- ``test_pool_ref_registry_covers_all_ref_fields`` (in
  ``tests/log/test_sample_history.py``), which introspects the event models
  for ``*_refs`` fields and fails when one is missing here.

A pool-ref field that isn't registered here would make page-scoped reads
silently drop the entries it references (:func:`_expand_refs` skips absent
positions), so any new ``*_refs`` field MUST be added here alongside its
condense/resolve support — the test enforces registration.
"""


class PoolRefPositions(NamedTuple):
    message_positions: set[int]
    call_positions: set[int]


def collect_pool_ref_positions(
    events: Iterable[Mapping[str, JsonValue]],
) -> PoolRefPositions:
    """Pool positions referenced by condensed events in raw JSON form.

    Walks :data:`POOL_REF_FIELDS` so callers that load partial pools (the
    buffer's page-scoped reads) stay in sync with the condense/resolve
    functions in this module.
    """
    positions = PoolRefPositions(message_positions=set(), call_positions=set())
    pool_positions: dict[str, set[int]] = {
        "message": positions.message_positions,
        "call": positions.call_positions,
    }
    for event in events:
        for field in POOL_REF_FIELDS:
            value: object = event
            for key in field.path:
                value = value.get(key) if isinstance(value, Mapping) else None
            _accumulate_ref_positions(value, pool_positions[field.pool])
    return positions


def _accumulate_ref_positions(refs: object, positions: set[int]) -> None:
    """Accumulate positions covered by range-encoded ``(start, end)`` refs."""
    if not isinstance(refs, list):
        return
    for ref in refs:
        if not isinstance(ref, (list, tuple)) or len(ref) != 2:
            continue
        start, end = ref
        if isinstance(start, int) and isinstance(end, int):
            positions.update(range(start, end))


def remap_pool_refs(
    event: Mapping[str, JsonValue],
    message_pos_map: Mapping[int, int],
    call_pos_map: Mapping[int, int],
) -> dict[str, JsonValue]:
    """Rewrite a condensed event's pool refs through position maps.

    Used when a sample's pool entries are exported into another store and
    assigned new positions there. Walks :data:`POOL_REF_FIELDS` so exporters
    stay in sync with the condense/resolve functions in this module.
    """
    pos_maps: dict[str, Mapping[int, int]] = {
        "message": message_pos_map,
        "call": call_pos_map,
    }
    remapped: dict[str, JsonValue] = dict(event)
    for field in POOL_REF_FIELDS:
        remapped = _remap_refs_at_path(remapped, field.path, pos_maps[field.pool])
    return remapped


def _remap_refs_at_path(
    node: dict[str, JsonValue], path: tuple[str, ...], pos_map: Mapping[int, int]
) -> dict[str, JsonValue]:
    """Return ``node`` with the refs at ``path`` remapped, copying dicts on the path."""
    key, rest = path[0], path[1:]
    child = node.get(key)
    if rest:
        if not isinstance(child, dict):
            return node
        new_child = _remap_refs_at_path(child, rest, pos_map)
        return node if new_child is child else {**node, key: new_child}
    if not isinstance(child, list):
        return node
    return {**node, key: cast(JsonValue, _remap_refs(child, pos_map))}


def _remap_refs(
    refs: Sequence[object], pos_map: Mapping[int, int]
) -> list[tuple[int, int]]:
    """Translate range-encoded refs through a position map and re-compress."""
    indices: list[int] = []
    for ref in refs:
        if not isinstance(ref, (list, tuple)) or len(ref) != 2:
            continue
        start, end = ref
        if not isinstance(start, int) or not isinstance(end, int):
            continue
        indices.extend(pos_map[index] for index in range(start, end))
    return _compress_refs(indices)


def condense_model_event_calls(
    events: Sequence[Event],
    next_index: int,
    call_index: Mapping[str, int],
) -> tuple[list[Event], dict[str, int], list[tuple[str, JsonValue]]]:
    """Replace call.request messages with call_pool references.

    Assigns each unique call message a position starting at ``next_index``
    and replaces ``event.call.request[<messages_key>]`` with range-encoded
    ``call_refs``. Callers that need the pool list must rebuild it from
    ``new_entries``.

    Wire requests are append-mostly, so the equal prefix of each event's
    message list is resolved against the previous event's pool indices
    without hashing; only the divergent tail is hashed. Output is identical
    to hashing every message: a prefix element equal to the previous
    element resolves to the index that hash-dedup of equal content would produce.

    Args:
        events: Events to condense.
        next_index: The pool position assigned to the first new unique
            call message, typically the current pool length for callers
            carrying an existing pool.
        call_index: Existing hash → pool-index map.

    Returns:
        A tuple of (condensed events, updated index, new entries
        appended this call as ``(hash, msg)`` pairs in pool-position
        order).
    """
    index = dict(call_index)
    new_entries: list[tuple[str, JsonValue]] = []
    result: list[Event] = []
    prev_msgs: list[JsonValue] = []
    prev_indices: list[int] = []
    for event in events:
        if isinstance(event, ModelEvent) and event.call:
            if event.call.call_refs is not None:
                result.append(event)
                continue
            msg_key = next(
                (k for k in _CALL_MESSAGE_KEYS if k in event.call.request), None
            )
            msgs = event.call.request.get(msg_key) if msg_key else None
            if msgs and isinstance(msgs, list):
                # Reuse the previous event's pool indices for the equal prefix;
                # hash only the tail that diverges.
                # _strict_eq, not ==: a prefix element drifting 0 -> 0.0 or
                # True -> 1 is python-equal but serializes (and hashes)
                # differently; reusing the pool index would round-trip the
                # other value.
                prefix_len = 0
                for msg, prev_msg in zip(msgs, prev_msgs):
                    if not _strict_eq(msg, prev_msg):
                        break
                    prefix_len += 1
                raw_indices = list(prev_indices[:prefix_len])
                for msg in msgs[prefix_len:]:
                    h = _call_hash(msg)
                    if h not in index:
                        index[h] = next_index + len(new_entries)
                        new_entries.append((h, msg))
                    raw_indices.append(index[h])
                prev_msgs = list(msgs)
                prev_indices = raw_indices
                new_request = {
                    k: v for k, v in event.call.request.items() if k != msg_key
                }
                new_call = event.call.model_copy(
                    update={
                        "request": new_request,
                        "call_refs": _compress_refs(raw_indices),
                        "call_key": msg_key,
                    }
                )
                event = event.model_copy(update={"call": new_call})
        result.append(event)
    return result, index, new_entries


def resolve_model_event_calls(
    events: list[Event],
    call_pool: Sequence[JsonValue] | Mapping[int, JsonValue],
) -> list[Event]:
    """Restore call.request messages from call_pool references."""
    if not call_pool:
        return events
    result: list[Event] = []
    for event in events:
        if isinstance(event, ModelEvent) and event.call and event.call.call_refs:
            msgs = _expand_refs(event.call.call_refs, call_pool)
            msg_key = event.call.call_key or "messages"
            new_request = dict(event.call.request)
            new_request[msg_key] = msgs
            new_call = event.call.model_copy(
                update={
                    "request": new_request,
                    "call_refs": None,
                    "call_key": None,
                }
            )
            event = event.model_copy(update={"call": new_call})
        result.append(event)
    return result


def resolve_model_event_inputs(
    events: list[Event],
    message_pool: Sequence[ChatMessage] | Mapping[int, ChatMessage],
) -> list[Event]:
    """Resolve ModelEvent input_refs back to full input lists."""
    if not message_pool:
        return events
    result: list[Event] = []
    for event in events:
        if isinstance(event, ModelEvent) and event.input_refs is not None:
            resolved_input = _expand_refs(event.input_refs, message_pool)
            event = event.model_copy(
                update={"input": resolved_input, "input_refs": None}
            )
        result.append(event)
    return result
