"""Process-wide registry of running samples (and in-flight model events).

Despite living in the ``log`` package, this module is not about log
persistence — it's the runtime observability hub for samples currently
executing in this process. Each running sample has an :class:`ActiveSample`
in the module-global registry (:func:`active_samples`): the executing side
(task runner, model layer, limits, solvers) *pushes* live state onto it via
the ``set_active_sample_*`` functions, and cross-task observers (the TUI,
the control channel, ACP) read it. The pushes exist because most sample
state is context-bound (ContextVars, limit trees) and therefore unreachable
from an observer's task — the registry mirrors it outward. Most such
mirrors are copied scalars (token/turn totals, limits);
:attr:`ActiveSample.live_state` is the exception, a *handle* to the
sample's live ``TaskState`` (copying a conversation per append would be
prohibitive), and the one upward-pointing object edge here.

That role makes this module a cross-layer hub: it's imported from every
layer of the stack, and its own references to higher-layer types
(``TaskState``, ACP transport, hooks) are ``TYPE_CHECKING``-only or
function-local to keep the module import graph acyclic.

The ``_active_model_event`` half of the file is a sibling concern — tracking
the in-flight ``ModelEvent`` so providers can attach call payloads and retry
counts — cohabiting here rather than part of the sample registry.
"""

import contextlib
from contextvars import ContextVar
from datetime import datetime, timezone
from logging import getLogger
from typing import (
    TYPE_CHECKING,
    Any,
    AsyncGenerator,
    Awaitable,
    Callable,
    Iterator,
    Literal,
    NamedTuple,
)

if TYPE_CHECKING:
    from anyio.streams.memory import MemoryObjectReceiveStream, MemoryObjectSendStream

    from inspect_ai.agent._acp.transport import AcpTransport
    from inspect_ai.agent._channel import ExecutionObserver
    from inspect_ai.hooks._hooks import SampleEvent
    from inspect_ai.log._log import EvalRetryError
    from inspect_ai.model._model_call import ModelCall, ModelCallFilter
    from inspect_ai.solver._task_state import TaskState

import anyio
from anyio.abc import TaskGroup
from shortuuid import uuid

from inspect_ai.dataset._dataset import Sample
from inspect_ai.util._checkpoint.checkpointer import CheckpointerSetup, ResumeCheckpoint
from inspect_ai.util._checkpoint.checkpointer_factory import create_checkpointer
from inspect_ai.util._checkpoint.config import ResolvedCheckpointConfig
from inspect_ai.util._limit import LimitExceededError
from inspect_ai.util._sandbox import SandboxConnection, SandboxEnvironment
from inspect_ai.util._sandbox.context import sandbox_connections

from ..event._model import ModelEvent
from ._transcript import Transcript

logger = getLogger(__name__)


SampleCancelAction = Literal["score", "error", "cancel"]
"""How a cancelled sample resolves (see :meth:`ActiveSample.interrupt`)."""


class PendingInteraction(NamedTuple):
    """One in-flight wait on a person, mirrored onto the running sample.

    The same shape of problem as :class:`ActiveSampleRetryWait` and a worse
    case of it: while a sample waits for a human approval there is *no*
    pending event in its transcript — ``call_tool`` records the tool's event
    only once the approval resolves — so without this record the sample reads
    as silently idle for as long as the wait lasts, which for a human decision
    can be overnight. Appended by :meth:`ActiveSample.awaiting_human` from the
    ACP routing shims, removed when the wait resolves.
    """

    kind: Literal["approval", "question"]
    """What is being waited for."""

    subject: str
    """The tool function an approval is gating; empty for a question.

    The one part of a request that is safe to relay onward: a function name is
    structural, where the call's arguments and an ``ask_user`` prompt are
    model-generated text. A question has no structural subject at all — the
    prompt *is* the request — so it carries none.
    """

    started_at: float
    """When the wait began (unix ts).

    Its own stamp rather than the sample's start, because *how long somebody
    has been holding this* is the figure that decides whether to go and find
    them, and the two diverge by however long the sample worked first.
    """


class ActiveSampleRetryWait(NamedTuple):
    """A model call's retry backoff, mirrored onto the running sample.

    During the backoff between retry attempts there is no pending
    ``ModelEvent`` to observe (the failed attempt's event completed in
    place), so without this record the control channel would read the
    sample as silently idle for the whole wait — precisely the
    "looks hung but is healthy" misreading the activity indicator exists
    to fix (design/ctl/generate-progress.md). Stamped by
    :func:`report_active_sample_retry_wait` from the model retry loop's
    before-sleep callback; cleared by :func:`clear_active_sample_retry_wait`
    when the retried call resolves.
    """

    model: str
    """Model whose call is waiting to retry."""

    attempt: int
    """Number of the attempt that just failed (1-based)."""

    started_at: float
    """When the backoff started (unix ts)."""

    deadline: float
    """When the wait elapses and the next attempt begins (unix ts)."""

    qualified_model: str | None = None
    """Qualified `provider/model` name, for the throughput registry's
    active-waits scan (`model` above is the bare display name and stays
    what the ctl activity view shows)."""


class ActiveSample:
    def __init__(
        self,
        *,
        task: str,
        log_location: str,
        model: str,
        sample: Sample,
        epoch: int,
        message_limit: int | None,
        token_limit: int | None,
        token_limit_type: str | None = None,
        cost_limit: float | None,
        time_limit: int | None,
        working_limit: int | None,
        fails_on_error: bool,
        transcript: Transcript,
        sandboxes: dict[str, SandboxConnection],
        checkpointer: CheckpointerSetup,
        eval_id: str,
        eval_set_id: str | None = None,
        run_id: str | None = None,
        agent_name: str | None = None,
        error_retries: "list[EvalRetryError] | None" = None,
        sample_uuid: str,
    ) -> None:
        self.id = uuid()
        # The uuid the logged `EvalSample` will carry (== `TaskState.uuid`).
        # Distinct from `self.id` (this attempt's `ActiveSample` identity):
        # `sample_uuid` is stable across the running→terminal transition, so
        # the control channel uses it as the event-cursor nonce — a cursor
        # handed out while running stays valid once the sample is logged.
        self.sample_uuid = sample_uuid
        self.started: float | None = None
        self.tg: TaskGroup | None = None
        self.completed: float | None = None
        self.task = task
        self.log_location = log_location
        self.model = model
        self.sample = sample
        self.epoch = epoch
        self.message_limit = message_limit
        self.token_limit = token_limit
        # None when no ceiling is configured (metering type is only meaningful
        # alongside a configured limit)
        self.token_limit_type: str | None = token_limit_type
        self.cost_limit = cost_limit
        self.time_limit = time_limit
        self.working_limit = working_limit
        self.fails_on_error = fails_on_error
        self.total_messages = 0
        self.total_tokens = 0
        self.total_turns = 0
        # Counts of events reported from deep inside the model layer, where the
        # only handle on "which sample is this?" is `sample_active()`. Both are
        # also tallied in process-global counters that the TUI footer reads
        # (`log._refusal`, `_util.retry`); these attribute them to a sample so
        # the control channel can report them per eval, which a process-global
        # cannot do — one process runs many evals concurrently.
        self.refusals = 0
        self.http_retries = 0
        # The sample's live `TaskState` — the handle observers read the
        # current conversation from (see the module docstring). Refreshed via
        # `set_sample_state` (sample start, `Chain`/`Plan` step boundaries,
        # pre-scoring) so it survives a solver replacing the state object;
        # step-boundary refreshes are compare-and-swap guarded against
        # capture by `fork()` branches (see `set_active_sample_state`).
        # `None` only in the brief window before the first state is set.
        self.live_state: "TaskState | None" = None
        self.token_limit_usage: int | None = None
        self.total_cost: float | None = None
        self.fallback_models: list[str] = []
        self.transcript = transcript
        self.sandboxes = sandboxes
        # The sample's live sandbox *environments* (the context-bound dict the
        # sample's own coroutine works against), published by the runner after
        # sandbox init. `sandboxes` above carries connection info for the
        # VS Code surface; this carries the environments themselves so the
        # interim-scoring pass can bind them into its scoring context and let
        # sandbox-inspecting scorers work (design/ctl/interim-scoring.md).
        # Empty when the sample has no sandbox.
        self.sandbox_environments: dict[str, "SandboxEnvironment"] = {}
        self.checkpointer = checkpointer
        self.eval_set_id = eval_set_id
        self.run_id = run_id
        self.eval_id = eval_id
        self.agent_name = agent_name
        # Prior failed attempts for this sample (genuine errors only):
        # sample-level `retry_on_error` plus task-level retries seeded via the
        # sample source. Empty on the first attempt. The control channel
        # surfaces these as the running sample's error history.
        self.error_retries: list[EvalRetryError] = error_retries or []
        # In-flight model retry backoff, if any (see ActiveSampleRetryWait).
        # A single slot: concurrent generates within one sample overwrite it
        # last-writer-wins (the control channel shows one activity per row,
        # and pending events always take precedence over this record), and
        # the ownership guard in clear_active_sample_retry_wait keeps a
        # sibling's clear from dropping a live wait.
        self.retry_wait: ActiveSampleRetryWait | None = None
        self._interrupt_action: SampleCancelAction | None = None
        self._limit_exceeded_error: LimitExceededError | None = None
        # One-shot terminal signal (see `terminal` / `wait_terminal`).
        # Created lazily on first wait — anyio.Event() needs a running async
        # context — and set by whichever terminal transition fires first
        # (complete / interrupt / limit_exceeded, all on the eval's loop).
        self._terminal_event: anyio.Event | None = None
        self.event_send: MemoryObjectSendStream[SampleEvent] | None = None
        self.event_receive: MemoryObjectReceiveStream[SampleEvent] | None = None
        self.event_done: anyio.Event | None = None
        # Live ACP session for this sample, if any. Set by
        # `LiveAcpTransport.__aenter__` on entry; cleared at `__aexit__`.
        # The Inspect TUI reads this to decide whether to render the
        # Interrupt button and to dispatch session/cancel + session/prompt.
        self.acp_transport: "AcpTransport | None" = None
        # In-flight human-in-the-loop waits, appended by the ACP routing
        # shims (approval/_human/acp.py, input/acp.py) through
        # `awaiting_human` below. A list (not a single slot) because
        # `parallel=True` tool calls run concurrently within one sample
        # (see `_call_tools.py`); two approvals can be in-flight at once,
        # and a save/restore would clear the picker indicator while the
        # second wait is still pending. The `pending_interaction` and
        # `pending_interactions` properties derive from it.
        self._pending_interactions: list[PendingInteraction] = []
        # In-flight tool/model tracking observer for this sample.
        # Defaults to a no-op singleton; an intervention producer (the
        # ACP transport today, future supervisors) installs itself here
        # to record `InterruptEvent` cross-references when it cancels.
        # The model/tool layers wrap each top-level tool execution and
        # each model generation in the observer's `track_*` context
        # manager, so the producer always has the necessary provenance
        # available at cancel time.
        from inspect_ai.agent._channel import null_execution_observer

        self.execution_observer: "ExecutionObserver" = null_execution_observer()
        # Lifecycle callbacks owned by whoever bound to this sample
        # (in practice, the live ACP session). Kept here rather than
        # in the ACP layer so the eval primitive doesn't have to
        # import or call into ACP — it just fires the registered hook
        # if present. `on_complete` runs after scoring + logging
        # finish; `on_interrupt` runs inside `interrupt()` /
        # `limit_exceeded()` before the task-group cancel propagates,
        # giving the binder a chance to clean up in-flight state that
        # anyio's hard cancel would otherwise bypass (notably the
        # `pending=True` flag on an in-flight `ModelEvent`).
        # `on_interrupt` receives a cause discriminator so the binder
        # records the right provenance — `"user_cancel"` for operator-
        # driven `interrupt()`, `"limit"` for `limit_exceeded()`,
        # `"system"` reserved for eval-shutdown paths. The values
        # mirror :attr:`InterruptEvent.source` so the binder can
        # forward straight through.
        self.on_complete: Callable[[], Awaitable[None]] | None = None
        self.on_interrupt: (
            Callable[[Literal["user_cancel", "limit", "system"]], None] | None
        ) = None

    @property
    def retries(self) -> int:
        """Number of prior failed attempts for this sample (0 on first run)."""
        return len(self.error_retries)

    def start(self, tg: TaskGroup) -> None:
        self.started = datetime.now(timezone.utc).timestamp()
        self.tg = tg

    def complete(self) -> None:
        self.completed = datetime.now(timezone.utc).timestamp()
        self._fire_terminal()

    @property
    def terminal(self) -> bool:
        """Whether the sample has reached a terminal transition.

        True once the sample completed, an interrupt was stamped, or a limit
        fired — the point after which an observer (the interim-scoring pass)
        must stop touching its live state.
        """
        return (
            self.completed is not None
            or self._interrupt_action is not None
            or self._limit_exceeded_error is not None
        )

    async def wait_terminal(self) -> None:
        """Park until the sample reaches a terminal transition.

        The push counterpart to polling :attr:`terminal` — the terminal
        transitions all run on the eval's single event loop, so the flag
        check and the wait have no gap between them, and terminality is
        monotonic (never un-set), so one one-shot event suffices.
        """
        while not self.terminal:
            if self._terminal_event is None:
                self._terminal_event = anyio.Event()
            await self._terminal_event.wait()

    def _fire_terminal(self) -> None:
        if self._terminal_event is not None:
            self._terminal_event.set()

    @property
    def pending_interactions(self) -> tuple[PendingInteraction, ...]:
        """Every wait on a person currently in flight, oldest first.

        Empty when the sample is working. Reported over the control channel,
        which is the only way an external runner can tell "working" from
        "stopped on you": while a sample waits for an approval there is no
        pending event in its transcript at all — the tool's event is recorded
        *after* the approval resolves — so the wait is invisible rather than
        merely unlabelled.
        """
        return tuple(self._pending_interactions)

    @property
    def pending_interaction(self) -> Literal["approval", "question"] | None:
        """Picker-visible pending state.

        Approval wins over question when both are in flight — approvals
        gate tool execution, so they're the more urgent signal. The
        property reads while any matching wait remains, so concurrent
        ``parallel=True`` tool calls (which can fire multiple approvals
        for one sample) don't clear the indicator early.
        """
        kinds = {pending.kind for pending in self._pending_interactions}
        if "approval" in kinds:
            return "approval"
        if "question" in kinds:
            return "question"
        return None

    @contextlib.contextmanager
    def awaiting_human(
        self, kind: Literal["approval", "question"], subject: str = ""
    ) -> Iterator[None]:
        """Record that this sample is parked on a person for the duration.

        Args:
            kind: What is being waited for.
            subject: The tool function an approval is gating. Left empty for a
                question, whose prompt is model-generated text rather than
                anything structural — see :class:`PendingInteraction`.
        """
        pending = PendingInteraction(
            kind=kind,
            subject=subject,
            started_at=datetime.now(timezone.utc).timestamp(),
        )
        self._pending_interactions.append(pending)
        try:
            yield
        finally:
            # by identity rather than by value: two concurrent approvals of the
            # same tool differ only in their timestamp, and removing "one of
            # them" must still remove exactly one
            self._pending_interactions[:] = [
                other for other in self._pending_interactions if other is not pending
            ]

    @property
    def running_time(self) -> float:
        if self.started is not None:
            completed = (
                self.completed
                if self.completed is not None
                else datetime.now(timezone.utc).timestamp()
            )
            return completed - self.started
        else:
            return 0

    def interrupt(self, action: SampleCancelAction) -> None:
        """Terminate this running sample.

        ``action`` selects the outcome: ``"score"`` completes the sample and
        runs the scorer on the work done so far; ``"error"`` marks it errored;
        ``"cancel"`` records it as cancelled (transcript preserved, no
        scoring, not counted as an error).
        """
        self._interrupt_action = action
        self._fire_terminal()
        if self.tg is None:
            raise RuntimeError(
                "Attempted to interrupt sample without enclosing task group."
            )
        self._fire_on_interrupt("user_cancel")
        self.tg.cancel_scope.cancel()

    def limit_exceeded(self, error: LimitExceededError) -> None:
        self._limit_exceeded_error = error
        self._fire_terminal()
        if self.tg is None:
            raise RuntimeError(
                "Attempted to interrupt sample for limit without enclosing task group."
            )
        self._fire_on_interrupt("limit")
        self.tg.cancel_scope.cancel()

    def _fire_on_interrupt(
        self, cause: Literal["user_cancel", "limit", "system"]
    ) -> None:
        """Fire the registered ``on_interrupt`` hook, swallowing failures.

        The hook (set by whoever bound to this sample — in practice the
        live ACP session) cleans up in-flight state that anyio's hard
        cancel would otherwise bypass. ``cause`` lets the binder
        record the right provenance (e.g. an `InterruptEvent` with
        ``source="limit"`` for a token-limit hit, not ``"user_cancel"``).
        A failure inside the hook must not prevent the task-group
        cancel from firing, so we log and keep going. Sync because the
        cancel path is sync.
        """
        if self.on_interrupt is None:
            return
        try:
            self.on_interrupt(cause)
        except Exception:
            logger.warning(
                "ActiveSample on_interrupt hook raised; continuing with cancel",
                exc_info=True,
            )

    @property
    def interrupt_action(self) -> SampleCancelAction | None:
        return self._interrupt_action

    @property
    def limit_exceeded_error(self) -> LimitExceededError | None:
        return self._limit_exceeded_error


def init_active_samples() -> None:
    _active_samples.clear()


@contextlib.asynccontextmanager
async def active_sample(
    *,
    task: str,
    log_location: str,
    model: str,
    sample: Sample,
    epoch: int,
    message_limit: int | None,
    token_limit: int | None,
    token_limit_type: str | None = None,
    cost_limit: float | None,
    time_limit: int | None,
    working_limit: int | None,
    fails_on_error: bool,
    transcript: Transcript,
    eval_id: str,
    checkpoint: ResolvedCheckpointConfig | None = None,
    resume_checkpoint: ResumeCheckpoint | None = None,
    eval_set_id: str | None = None,
    run_id: str | None = None,
    agent_name: str | None = None,
    error_retries: "list[EvalRetryError] | None" = None,
    sample_uuid: str,
) -> AsyncGenerator[ActiveSample, None]:
    if sample.id is None:
        raise ValueError("active_sample requires sample.id to be set")
    # create the sample
    active = ActiveSample(
        task=task,
        log_location=log_location,
        model=model,
        sample=sample,
        epoch=epoch,
        message_limit=message_limit,
        token_limit=token_limit,
        token_limit_type=token_limit_type,
        cost_limit=cost_limit,
        time_limit=time_limit,
        working_limit=working_limit,
        sandboxes=await sandbox_connections(),
        fails_on_error=fails_on_error,
        transcript=transcript,
        checkpointer=create_checkpointer(
            config=checkpoint,
            log_location=log_location,
            sample_id=sample.id,
            epoch=epoch,
            resume_checkpoint=resume_checkpoint,
        ),
        eval_set_id=eval_set_id,
        run_id=run_id,
        eval_id=eval_id,
        agent_name=agent_name,
        error_retries=error_retries,
        sample_uuid=sample_uuid,
    )

    _active_samples.append(active)
    _sample_active.set(active)
    # Capture the state the runner set before entering this context (via
    # `set_sample_state`, which precedes `active_sample`); subsequent solver
    # reassignments refresh it through the `set_sample_state` calls at
    # `Chain` / `Plan` step boundaries.
    from inspect_ai.solver._task_state import sample_state

    active.live_state = sample_state()
    # Open the ACP session for this sample's lifetime. The session is the
    # ACP-specific transport layer (pub/sub, approver registry, transcript
    # snapshot, etc.); it produces into whatever agent_channel() is bound to
    # via maybe_bind/unbind. Local import to avoid a module-load-time cycle
    # (log → agent._acp → … → log).
    from inspect_ai.agent._acp.transport import acp_session

    try:
        async with acp_session():
            yield active
    finally:
        # Single "the sample is fully done" hook for whoever bound to
        # this sample. By the time we get here scoring + logging have
        # run and the task runner's ``emit_sample_end`` has fired, so
        # any registered binder (in practice the live ACP session)
        # can do its deferred teardown safely. Shielded so a
        # cancellation during teardown doesn't skip it.
        if active.on_complete is not None:
            with anyio.CancelScope(shield=True):
                try:
                    await active.on_complete()
                except Exception:
                    logger.warning(
                        "ActiveSample on_complete hook raised",
                        exc_info=True,
                    )
        active.checkpointer.close()
        active.complete()
        # Roll this attempt's refusal / HTTP-retry counts onto the eval as the
        # sample leaves the live list, so the control channel's "so far" total
        # survives it. Adjacent to the `remove` and with no await between them:
        # the endpoint reports `eval total + sum(in-flight)`, so a suspension
        # point here would let a poll see the sample in neither term (or, the
        # other way round, in both). Local import because `_control.eval_state`
        # is loaded during eval bootstrap, before this package finishes
        # initializing.
        from inspect_ai._control.eval_state import record_sample_event_counts

        record_sample_event_counts(
            active.eval_id,
            refusals=active.refusals,
            http_retries=active.http_retries,
        )
        _active_samples.remove(active)
        _sample_active.set(None)


def sample_active() -> ActiveSample | None:
    return _sample_active.get(None)


@contextlib.contextmanager
def awaiting_human(
    kind: Literal["approval", "question"], subject: str = ""
) -> Iterator[None]:
    """Record on the active sample that it is waiting on a person.

    Wrapped around the *dispatch* of a human request rather than around any
    one surface that serves it — an approval is a wait whether it is answered
    in an editor over ACP, in the Textual panel, or at the console, and a
    record that only one of the three kept would report an attended run as
    idle for as long as somebody was looking at the prompt.

    A no-op outside a sample (a scorer, a bare `ask_user` in a script), which
    is why callers can wrap unconditionally.

    Args:
        kind: What is being waited for.
        subject: The tool function an approval is gating; empty for a question.
    """
    sample = sample_active()
    if sample is None:
        yield
        return
    with sample.awaiting_human(kind, subject):
        yield


def set_active_sample_token_limit(token_limit: int | None) -> None:
    active = sample_active()
    if active:
        active.token_limit = token_limit


def set_active_sample_token_limit_type(token_limit_type: str | None) -> None:
    """Surface the sample token limit's metering type on the active sample.

    `None` when no ceiling is configured. Pushed when a solver changes the
    limit dynamically (`TaskState.token_limit` setter) so the control channel
    reports the type consistently with the ceiling.
    """
    active = sample_active()
    if active:
        active.token_limit_type = token_limit_type


def set_active_sample_total_tokens(total_tokens: int) -> None:
    active = sample_active()
    if active:
        active.total_tokens = total_tokens


def set_active_sample_token_limit_usage(token_limit_usage: int | None) -> None:
    """Surface the sample token limit's metered usage on the active sample.

    Pushed on every usage record so the control channel can report live usage
    against the configured ceiling (the limit trees are context-bound and not
    readable from the control channel's task).
    """
    active = sample_active()
    if active:
        active.token_limit_usage = token_limit_usage


def set_active_sample_total_turns(total_turns: int) -> None:
    """Surface the running turn count on the active sample.

    Pushed after each top-level generation so the control channel can report
    turns alongside message count (the limit trees are context-bound and not
    readable from the control channel's task).
    """
    active = sample_active()
    if active:
        active.total_turns = total_turns


def set_active_sample_cost_limit(cost_limit: float | None) -> None:
    active = sample_active()
    if active:
        active.cost_limit = cost_limit


def set_active_sample_total_cost(total_cost: float | None) -> None:
    active = sample_active()
    if active:
        active.total_cost = total_cost


def active_sample_message_limit() -> int | None:
    active = sample_active()
    if active:
        return active.message_limit
    else:
        return None


def set_active_sample_message_limit(message_limit: int | None) -> None:
    active = sample_active()
    if active:
        active.message_limit = message_limit


def set_active_sample_total_messages(total_messages: int) -> None:
    active = sample_active()
    if active:
        active.total_messages = total_messages


def set_active_sample_state(
    state: "TaskState", *, replacing: "TaskState | None" = None
) -> None:
    """Refresh the active sample's live `TaskState` handle.

    Called from `set_sample_state` so the control channel's view of the
    conversation survives a solver replacing the `TaskState` object outright
    (`Chain` / `Plan` call `set_sample_state` after each solver step for
    exactly this reason). In-place mutation between replacements needs no
    hook — the handle already points at the object whose `messages` list is
    being appended to.

    When ``replacing`` is given, the refresh is a compare-and-swap: it lands
    only if the handle currently points at ``replacing``. The handle lives on
    the shared `ActiveSample`, which a `fork()` subtask's copied context still
    reaches through `sample_active()` (the ContextVar isolation protecting
    `sample_state()` doesn't extend to it) — the guard keeps a branch
    `Chain` / `Plan`, threading a deepcopy lineage the handle never pointed
    at, from serving its branch conversation as the sample's main thread.
    """
    active = sample_active()
    if active and (replacing is None or active.live_state is replacing):
        active.live_state = state


def set_active_sample_fallback_models(fallback_models: list[str]) -> None:
    active = sample_active()
    if active:
        active.fallback_models = fallback_models


_active_model_event: ContextVar[ModelEvent | None] = ContextVar(
    "_active_model_event", default=None
)


@contextlib.contextmanager
def track_active_model_event(event: ModelEvent) -> Iterator[None]:
    token = _active_model_event.set(event)
    try:
        yield
    finally:
        _active_model_event.reset(token)


def has_active_model_event() -> bool:
    return _active_model_event.get() is not None


def set_active_model_event_call(
    request: Any,
    filter: "ModelCallFilter | None" = None,
) -> "ModelCall":
    """Create a ModelCall and register it with the active model event."""
    from inspect_ai.log._transcript import transcript
    from inspect_ai.model._model_call import ModelCall

    if request is None:
        request = {}
    model_call = ModelCall.create(request, None, filter)
    event = _active_model_event.get()
    if event is not None:
        event.call = model_call
        transcript()._event_updated(event)
    return model_call


def report_active_sample_retry() -> None:
    model_event = _active_model_event.get()
    if model_event is not None:
        if model_event.retries is None:
            model_event.retries = 0
        model_event.retries = model_event.retries + 1

    # Also tally on the sample itself. The model event's count is per-generation
    # and lands in the transcript; this one is what the control channel can read
    # while the sample is still running, and what rolls up to the eval.
    active = sample_active()
    if active is not None:
        active.http_retries += 1


def report_active_sample_refusal() -> None:
    """Count a model refusal against the active sample, if there is one.

    Called alongside the process-global tally in :mod:`inspect_ai.log._refusal`.
    A refusal reported outside a sample (nothing in ``sample_active()``) is
    counted globally only — it belongs to no eval.
    """
    active = sample_active()
    if active is not None:
        active.refusals += 1


# The retry-wait record stamped by *this* coroutine's model retry loop.
# `ActiveSample.retry_wait` is a single shared slot; this per-context handle
# lets `clear_active_sample_retry_wait` clear only a record its own call
# stamped, so a generate resolving in one task can't drop a concurrent
# sibling's still-live wait.
_active_retry_wait: ContextVar["ActiveSampleRetryWait | None"] = ContextVar(
    "_active_retry_wait", default=None
)


def report_active_sample_retry_wait(
    model: str,
    attempt: int,
    wait_time: float,
    qualified_model: str | None = None,
) -> None:
    """Record that the active sample's model call is waiting to retry.

    Called from the model retry loop's before-sleep callback (once per
    backoff). Between attempts there is no pending ``ModelEvent`` to
    observe, so this record is the only per-sample signal that the sample
    is healthy-but-waiting rather than stalled; the control channel reads
    it as the ``retry_wait`` activity type
    (design/ctl/generate-progress.md).

    Args:
        model: Model whose call is waiting to retry (bare display name).
        attempt: Number of the attempt that just failed (1-based).
        wait_time: Seconds until the next attempt begins.
        qualified_model: Qualified ``provider/model`` name for the
            throughput registry's active-waits scan.
    """
    active = sample_active()
    if active is not None:
        now = datetime.now(timezone.utc).timestamp()
        record = ActiveSampleRetryWait(
            model=model,
            attempt=attempt,
            started_at=now,
            deadline=now + wait_time,
            qualified_model=qualified_model,
        )
        _active_retry_wait.set(record)
        active.retry_wait = record


def clear_active_sample_retry_wait() -> None:
    """Clear the retry-wait record stamped by this coroutine's model call.

    Called when the retried call resolves (success or final failure) so a
    record can't outlive its call and misreport a healthy sample as
    waiting. No-ops when a concurrent sibling call has since overwritten
    the sample's slot — its wait is still live.
    """
    record = _active_retry_wait.get()
    if record is None:
        return
    _active_retry_wait.set(None)
    active = sample_active()
    if active is not None and active.retry_wait is record:
        active.retry_wait = None


@contextlib.contextmanager
def cleared_retry_wait() -> Iterator[None]:
    """Clear this coroutine's retry-wait record when the enclosed call resolves.

    Wrap the await of a tenacity-decorated model call built with
    ``report_retry_wait=True`` (the retry loop's before-sleep callback
    stamps the record; see :func:`report_active_sample_retry_wait`). The
    backoff record must not outlive the call it describes — success, final
    failure, or cancellation during the backoff sleep itself; nothing later
    clears it.
    """
    try:
        yield
    finally:
        clear_active_sample_retry_wait()


_sample_active: ContextVar[ActiveSample | None] = ContextVar(
    "_sample_active", default=None
)


def active_samples() -> list[ActiveSample]:
    return _active_samples


_active_samples: list[ActiveSample] = []
