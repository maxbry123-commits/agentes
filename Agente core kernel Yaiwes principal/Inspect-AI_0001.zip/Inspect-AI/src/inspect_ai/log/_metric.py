"""Score metrics recomputation functionality."""

from inspect_ai._eval.task.results import eval_results
from inspect_ai.scorer._metric import SampleScore

from ._log import EvalLog


def recompute_metrics(log: EvalLog) -> None:
    """Recompute aggregate metrics after score edits.

    Args:
        log: The evaluation log to recompute metrics for

    Raises:
        ValueError: If log is missing required data for recomputation
    """
    # Import here to avoid circular imports
    from inspect_ai._eval.score import (
        metrics_from_log_header,
        reducers_from_log_header,
        resolve_scorers_info,
    )

    if log.samples is None:
        raise ValueError("Log contains no samples")

    # Extract scores from all samples
    scores = []
    for sample in log.samples:
        if sample.scores:
            sample_scores = {}
            for score_name, score in sample.scores.items():
                sample_scores[score_name] = SampleScore(
                    score=score, sample_id=sample.id, sample_metadata=sample.metadata
                )
            scores.append(sample_scores)

    reducers = reducers_from_log_header(log)
    metrics = metrics_from_log_header(log)
    scorers_info = resolve_scorers_info(log)

    # Recompute
    results, reductions = eval_results(
        samples=len(log.samples),
        scores=scores,
        reducers=reducers,
        scorers=scorers_info,
        metrics=metrics,
        early_stopping=log.results.early_stopping if log.results else None,
        metadata=log.results.metadata if log.results else None,
        # the count isn't persisted but the per-sample error state is, so
        # recompute it rather than letting eval_results() fall back to
        # len(scores) (which is scorer-order dependent)
        completed_samples=sum(1 for s in log.samples if s.error is None),
        headline_metric=log.eval.headline_metric,
    )

    # Update the log's results and reductions
    log.results = results
    log.reductions = reductions
