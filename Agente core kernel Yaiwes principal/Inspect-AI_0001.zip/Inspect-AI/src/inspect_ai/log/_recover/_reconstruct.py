"""Reconstruct EvalSample from buffer DB data."""

from __future__ import annotations

import json
from logging import getLogger
from typing import Any, cast, get_args

from pydantic import JsonValue, TypeAdapter
from shortuuid import uuid as _shortuuid

from inspect_ai._util.constants import get_deserializing_context
from inspect_ai._util.error import EvalError
from inspect_ai.event._compaction import CompactionEvent
from inspect_ai.event._event import Event
from inspect_ai.event._model import ModelEvent
from inspect_ai.event._pool import (
    resolve_model_event_calls,
    resolve_model_event_inputs,
)
from inspect_ai.event._sample_init import SampleInitEvent
from inspect_ai.event._sample_limit import SampleLimitEvent
from inspect_ai.event._validate import validate_events
from inspect_ai.log._log import (
    EvalSample,
    EvalSampleLimit,
    EvalSampleLimitType,
    EvalSampleSummary,
)
from inspect_ai.log._recorders.buffer.types import (
    CallPoolData,
    EventData,
    MessagePoolData,
    SampleData,
)
from inspect_ai.model._chat_message import ChatMessage
from inspect_ai.model._model_output import ModelOutput

logger = getLogger(__name__)

_CHAT_MESSAGES_ADAPTER: TypeAdapter[list[ChatMessage]] = TypeAdapter(list[ChatMessage])


def _summary_with_uuid_fallback(summary: EvalSampleSummary) -> EvalSampleSummary:
    """Synthesize a uuid for legacy buffer rows that lack one.

    The original state.uuid wasn't persisted; the crashed sample run had no
    external consumers, so a fresh uuid is safe.
    """
    if summary.uuid is not None:
        return summary
    fallback = _shortuuid()
    logger.warning(
        "Sample summary missing uuid during recovery; synthesizing %s "
        "(sample_id=%s epoch=%s)",
        fallback,
        summary.id,
        summary.epoch,
    )
    return summary.model_copy(update={"uuid": fallback})


def select_limit_event(
    summary: EvalSampleSummary, events: list[Event]
) -> SampleLimitEvent | None:
    """The limit event that best explains how the sample ended.

    The last event isn't necessarily the one that halted the sample: an operator
    interrupt during the scoring phase appends a second event after whatever
    ended the run phase. Where the terminal summary names a limit type, it
    decides; otherwise fall back to the last event seen.
    """
    # limits fire at the end of a sample, so search backwards and stop as soon
    # as the answer can't change
    fallback: SampleLimitEvent | None = None
    for event in reversed(events):
        if not isinstance(event, SampleLimitEvent):
            continue
        if summary.limit is None:
            return event  # nothing to match on; the last event is the answer
        if event.type == summary.limit:
            return event
        if fallback is None:
            fallback = event  # the last event overall, should nothing match
    return fallback


def recovered_sample_limit(
    summary: EvalSampleSummary, limit_event: SampleLimitEvent | None
) -> EvalSampleLimit | None:
    """Rebuild a sample's `EvalSampleLimit` during recovery.

    Shared by both recovery paths (streaming filestore and buffer DB) so a
    recovered log's limit doesn't depend on which one ran. The event supplies
    the numeric value; a terminal summary that names a limit no event recorded
    (a user-raised `LimitExceededError` emits none) still round-trips, with the
    same `-1` sentinel the live path writes for an unknown value.
    """
    if limit_event is None:
        return _limit_from_summary(summary)
    if limit_event.limit is not None:
        return EvalSampleLimit(
            type=limit_event.type,
            limit=limit_event.limit,
            reason=limit_event.message,
        )
    if limit_event.type == "operator" and summary.limit == "operator":
        # the operator interrupt event carries no numeric limit, so the branch
        # above can't rebuild it. Only `interrupt_action == "score"` records an
        # operator limit -- "error"/"cancel" and a scoring-phase interrupt emit
        # the same event but record an error instead -- so trust the terminal
        # summary rather than the event, and use the sentinel the live path
        # writes. The summary's own reason wins for the same reason: a later
        # scoring-phase interrupt leaves a second operator event whose message
        # describes the scoring failure, not what halted the sample.
        return EvalSampleLimit(
            type="operator",
            limit=1,
            reason=(
                summary.limit_reason
                if summary.limit_reason is not None
                else limit_event.message
            ),
        )
    return _limit_from_summary(summary)


def _limit_from_summary(summary: EvalSampleSummary) -> EvalSampleLimit | None:
    """The summary's own limit, with no numeric value to recover."""
    if summary.limit is None or summary.limit not in get_args(EvalSampleLimitType):
        return None
    return EvalSampleLimit(
        type=cast(EvalSampleLimitType, summary.limit),
        limit=-1,
        reason=summary.limit_reason,
    )


def reconstruct_eval_sample(
    summary: EvalSampleSummary,
    sample_data: SampleData,
    *,
    sample_metadata: dict[str, Any] | None = None,
    cancelled: bool = False,
    include_events: bool = True,
) -> EvalSample:
    """Reconstruct an EvalSample from buffer DB data.

    Args:
        summary: Sample summary from the buffer DB samples table.
        sample_data: Events and attachments from buffer.get_sample_data().
        sample_metadata: Full metadata stored separately from the thinned summary.
        cancelled: If True, synthesize a cancellation EvalError
            (for in-progress samples interrupted by a crash).
        include_events: If False, return an empty events list and no
            timelines. Events are still deserialized internally to
            extract messages and output.

    Returns:
        A fully resolved EvalSample (not condensed — condensing happens
        at write time in Step 4).
    """
    summary = _summary_with_uuid_fallback(summary)

    deduped_event_data = collapse_event_versions(sample_data.events)

    events = validate_events([event_data.event for event_data in deduped_event_data])

    if sample_metadata is None:
        sample_init = next(
            (event for event in events if isinstance(event, SampleInitEvent)), None
        )
        if sample_init is not None:
            sample_metadata = sample_init.sample.metadata

    # Buffer-DB rows store events condensed; without resolving here,
    # _extract_messages_from_events sees empty ModelEvent.input and drops
    # every user/tool message from the recovered sample.
    events = resolve_model_event_inputs(
        events, _deserialize_message_pool(sample_data.message_pool)
    )
    events = resolve_model_event_calls(
        events, _deserialize_call_pool(sample_data.call_pool)
    )

    messages, output = _extract_messages_from_events(events)

    attachments = {
        attachment.hash: attachment.content for attachment in sample_data.attachments
    }

    # Set error: synthesize cancellation for in-progress samples,
    # or preserve existing error from completed-but-errored samples
    error: EvalError | None = None
    if cancelled:
        error = EvalError(
            message="CancelledError()",
            traceback="CancelledError: recovered from crashed eval\n",
            traceback_ansi="CancelledError: recovered from crashed eval\n",
        )
    elif summary.error is not None:
        error = EvalError(
            message=summary.error,
            traceback=f"{summary.error}\n",
            traceback_ansi=f"{summary.error}\n",
        )

    return EvalSample(
        id=summary.id,
        epoch=summary.epoch,
        input=summary.input,
        choices=summary.choices,
        target=summary.target,
        metadata=sample_metadata if sample_metadata is not None else summary.metadata,
        messages=messages,
        output=output,
        scores=summary.scores,
        events=events if include_events else [],
        timelines=None,
        attachments=attachments,
        model_usage=summary.model_usage,
        role_usage=summary.role_usage,
        model_fallbacks=summary.model_fallbacks,
        turn_count=summary.turn_count,
        token_limit=summary.token_limit,
        token_limit_type=summary.token_limit_type,
        token_limit_usage=summary.token_limit_usage,
        message_limit=summary.message_limit,
        time_limit=summary.time_limit,
        started_at=summary.started_at,
        completed_at=summary.completed_at,
        total_time=summary.total_time,
        working_time=summary.working_time,
        uuid=summary.uuid,
        error=error,
        # the write path recomputes the summary from this sample
        # (`buffer_sample` -> `sample.summary()`), so omitting the limit here
        # doesn't merely leave it incomplete -- it erases the limit and reason
        # the buffered summary already knew
        limit=recovered_sample_limit(summary, select_limit_event(summary, events)),
    )


def _deserialize_message_pool(
    entries: list[MessagePoolData],
) -> list[ChatMessage]:
    if not entries:
        return []
    return _CHAT_MESSAGES_ADAPTER.validate_python(
        [json.loads(entry.data) for entry in sorted(entries, key=lambda e: e.id)],
        context=get_deserializing_context(),
    )


def _deserialize_call_pool(entries: list[CallPoolData]) -> list[JsonValue]:
    if not entries:
        return []
    return [json.loads(entry.data) for entry in sorted(entries, key=lambda e: e.id)]


class EventVersionCollapser:
    """Incremental collapser for duplicate event_id rows.

    Preserves first-insertion order and substitutes the latest payload
    for each event_id. Rows with a falsy `event_id` are kept as unique
    slots and never replaced.
    """

    def __init__(self) -> None:
        self._latest_by_event_id: dict[str, int] = {}
        self._slots: list[EventData] = []

    def add(self, event_data: EventData) -> None:
        if not event_data.event_id:
            self._slots.append(event_data)
            return
        slot = self._latest_by_event_id.get(event_data.event_id)
        if slot is None:
            self._latest_by_event_id[event_data.event_id] = len(self._slots)
            self._slots.append(event_data)
        else:
            self._slots[slot] = event_data

    def events(self) -> list[EventData]:
        return self._slots


def collapse_event_versions(events: list[EventData]) -> list[EventData]:
    """Collapse duplicate event_id rows to one logical event per UUID.

    The buffer DB events table is insert-only: every `_event_updated()` writes
    a new row with the same `event_id`. This collapses such rows to a single
    entry at the first-insertion position, with the latest payload. Rows
    without an `event_id` are kept as unique logical events.
    """
    collapser = EventVersionCollapser()
    for ev in events:
        collapser.add(ev)
    return collapser.events()


class MessageAccumulator:
    """Incrementally accumulates messages from events across segment batches.

    Extracted from _extract_messages_from_events so that segments can be
    processed one at a time with bounded memory.

    When a solver runs multiple agents concurrently (e.g. an auditor
    driving a target), their ModelEvents interleave in the stream, each
    carrying its own conversation. Accumulation follows the primary role
    only (the role of the first ModelEvent, matching the conversation the
    solver started with) so the reconstructed messages are deterministic
    rather than whichever agent's event happened to fire last.

    CompactionEvent carries its own role since it was added; a compaction
    from an older log without the field falls back to the most recent
    ModelEvent's role.
    """

    def __init__(self) -> None:
        self._merged: list[ChatMessage] = []
        self._last_model_event: ModelEvent | None = None
        self._pending_trim_pre_input: list[ChatMessage] | None = None
        self._output: ModelOutput = ModelOutput()
        self._primary_role: str | None = None
        self._primary_role_set = False
        self._last_event_role: str | None = None

    def process_events(self, events: list[Event]) -> None:
        """Feed a batch of deserialized events (typically one segment)."""
        for event in events:
            if isinstance(event, ModelEvent):
                if not self._primary_role_set:
                    self._primary_role = event.role
                    self._primary_role_set = True
                self._last_event_role = event.role
                if event.role != self._primary_role:
                    continue

                if self._pending_trim_pre_input is not None:
                    prefix = _trim_prefix(
                        self._pending_trim_pre_input, list(event.input)
                    )
                    self._merged.extend(prefix)
                    self._pending_trim_pre_input = None

                self._last_model_event = event
                self._output = event.output

            elif isinstance(event, CompactionEvent):
                # older logs predate CompactionEvent.role; fall back to the
                # most recent ModelEvent's role for those.
                event_role = (
                    event.role if event.role is not None else self._last_event_role
                )
                if event_role != self._primary_role:
                    continue

                if event.type == "summary":
                    if self._last_model_event is not None:
                        self._merged.extend(_segment_messages(self._last_model_event))
                    self._last_model_event = None

                elif event.type == "trim":
                    if self._last_model_event is not None:
                        self._pending_trim_pre_input = list(
                            self._last_model_event.input
                        )
                    self._last_model_event = None

    def result(self) -> tuple[list[ChatMessage], ModelOutput]:
        """Return accumulated (messages, output)."""
        merged = list(self._merged)
        if self._last_model_event is not None:
            merged.extend(_segment_messages(self._last_model_event))
        return merged, self._output


def _extract_messages_from_events(
    events: list[Event],
) -> tuple[list[ChatMessage], ModelOutput]:
    """Extract messages from an event list, handling compaction boundaries."""
    acc = MessageAccumulator()
    acc.process_events(events)
    return acc.result()


def _segment_messages(model_event: ModelEvent) -> list[ChatMessage]:
    """Extract messages from a ModelEvent (input + output message)."""
    messages = list(model_event.input)
    if (
        model_event.output is not None
        and model_event.output.choices
        and model_event.output.choices[0].message is not None
    ):
        messages.append(model_event.output.choices[0].message)
    return messages


def _trim_prefix(
    pre_input: list[ChatMessage],
    post_input: list[ChatMessage],
) -> list[ChatMessage]:
    """Compute messages trimmed by a trim compaction.

    Finds the overlap between pre and post compaction inputs,
    returning the prefix that was dropped.
    """
    if not post_input or not pre_input:
        return []

    # Try matching by message id
    first_post_id = post_input[0].id
    if first_post_id is not None:
        for i, msg in enumerate(pre_input):
            if msg.id == first_post_id:
                return pre_input[:i]

    # Fall back to content equality
    first_post_text = post_input[0].text
    for i, msg in enumerate(pre_input):
        if msg.text == first_post_text and msg.role == post_input[0].role:
            return pre_input[:i]

    return []
