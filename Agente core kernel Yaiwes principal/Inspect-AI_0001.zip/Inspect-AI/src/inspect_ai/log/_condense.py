import json
from collections.abc import Mapping, MutableMapping
from logging import getLogger
from typing import (
    Callable,
    Literal,
    Sequence,
)

from pydantic import JsonValue
from typing_extensions import TypedDict

from inspect_ai._util.constants import BASE_64_DATA_REMOVED
from inspect_ai._util.content import (
    Content,
    ContentAudio,
    ContentData,
    ContentDocument,
    ContentImage,
    ContentReasoning,
    ContentText,
    ContentToolUse,
    ContentVideo,
)
from inspect_ai._util.hash import mm3_hash
from inspect_ai._util.json import JsonChange
from inspect_ai._util.url import is_data_uri
from inspect_ai.dataset._dataset import Sample
from inspect_ai.event._pool import (
    _build_call_index,
    _build_msg_index,
    condense_model_event_calls,
    condense_model_event_inputs,
    resolve_model_event_calls,
    resolve_model_event_inputs,
)
from inspect_ai.event._validate import validate_chat_messages, validate_events_json
from inspect_ai.model._chat_message import ChatMessage, ChatMessageAssistant
from inspect_ai.model._model_call import ModelCall
from inspect_ai.model._model_output import ModelOutput
from inspect_ai.tool._tool_call import ToolCall
from inspect_ai.tool._tool_info import ToolInfo

from ..event._event import (
    Event,
)
from ..event._info import InfoEvent
from ..event._model import ModelEvent
from ..event._sample_init import SampleInitEvent
from ..event._state import StateEvent
from ..event._store import StoreEvent
from ..event._subtask import SubtaskEvent
from ..event._tool import ToolEvent
from ._log import EvalSample, EventsData

logger = getLogger(__name__)


ATTACHMENT_PROTOCOL = "attachment://"


class WalkContext(TypedDict):
    message_cache: dict[str, tuple[ChatMessage, ChatMessage]]
    """Cache of walked messages keyed by message id.

    Each value is ``(pre_walk_message, walked_result)``: lookups verify
    against the *pre-walk* message (by identity first, then equality)
    because the walked result has rewritten content and never compares
    equal to an incoming un-walked message. A message mutated in place
    after first being walked identity-hits and resolves to its
    first-walked form (consistent with ``event/_pool_index.py``;
    first-party code refreshes ``message.id`` on mutation). Entries are
    only valid for one content function — never share a context across
    walks with different content functions.
    """

    only_core: bool


def attachment_refs_from_value(value: object) -> set[str]:
    refs: set[str] = set()

    def collect(value: object) -> None:
        if isinstance(value, str):
            if value.startswith(ATTACHMENT_PROTOCOL):
                refs.add(value.removeprefix(ATTACHMENT_PROTOCOL))
        elif isinstance(value, dict):
            for item in value.values():
                collect(item)
        elif isinstance(value, (list, tuple, set)):
            for item in value:
                collect(item)

    collect(value)
    return refs


def condense_events(
    events: Sequence[Event],
) -> tuple[list[Event], EventsData]:
    """De-duplicate repeated content in a sequence of events.

    Extracts repeated ModelEvent inputs and calls into shared pools,
    replacing inline content with pool index references.

    Args:
        events: Events to condense.

    Returns:
        Tuple of (condensed events, events data containing message and call pools).
    """
    condensed_events, _, new_msgs = condense_model_event_inputs(events, 0, {})
    message_pool: list[ChatMessage] = [msg for _, msg in new_msgs]
    condensed_events, _, new_calls = condense_model_event_calls(condensed_events, 0, {})
    call_pool: list[JsonValue] = [call_msg for _, call_msg in new_calls]
    return condensed_events, EventsData(messages=message_pool, calls=call_pool)


def expand_events(
    events: Sequence[Event] | str,
    data: EventsData | str,
) -> list[Event]:
    """Reverse :func:`condense_events` — restore pooled content into events.

    Args:
        events: Condensed events (with pool index references), or a JSON-serialized
            ``list[Event]``.
        data: Events data returned by :func:`condense_events`, or a JSON-serialized
            ``EventsData``.

    Returns:
        Events with full message inputs and call request messages restored.
    """
    if isinstance(events, str):
        events = validate_events_json(events)
    if isinstance(data, str):
        raw = json.loads(data)
        data = EventsData(
            messages=validate_chat_messages(raw.get("messages", [])),
            calls=raw.get("calls", []),
        )
    result = resolve_model_event_inputs(list(events), data["messages"])
    result = resolve_model_event_calls(result, data["calls"])
    return result


def condense_sample(sample: EvalSample, log_images: bool = True) -> EvalSample:
    """Reduce the storage size of the eval sample.

    Reduce size by:
    1. De-duplicating larger content fields (especially important for images
       but also for message repeated over and over in the event stream)
    2. Removing base64 encoded images if log_images is True

    The de-duplication of content fields can be reversed by calling
    `resolve_attachments()`. Removal of base64 encoded images is a
    one-way operation.

    Args:
       sample (EvalSample): Eval sample to condense.
       log_images (bool): Should base64 images be logged for this sample.

    Returns:
       EvalSample: Eval sample in condensed form.
    """
    existing_attachments = dict(sample.attachments)
    attachments = dict(existing_attachments)
    rewritten_attachments: set[str] = set()
    events_fn = _existing_attachments_content_fn(
        existing_attachments,
        rewritten_attachments,
        events_attachment_fn(attachments, log_images),
    )
    messages_fn = _existing_attachments_content_fn(
        existing_attachments,
        rewritten_attachments,
        messages_attachment_fn(attachments, log_images),
    )
    # The events and messages walks rewrite content differently (events_fn
    # pools long text as attachments; messages_fn leaves it inline), so they
    # must not share a message cache: sample.messages contains the same
    # objects/ids as event inputs and a shared cache would return
    # event-walked results during the messages walk.
    events_context = WalkContext(message_cache={}, only_core=False)
    messages_context = WalkContext(message_cache={}, only_core=False)
    condensed_events = walk_events(sample.events, events_fn, events_context)
    retry_events_context = WalkContext(message_cache={}, only_core=False)
    condensed_error_retries = (
        [
            retry.model_copy(
                update={
                    "events": walk_events(
                        retry.events,
                        events_fn,
                        retry_events_context,
                    )
                    if retry.events is not None
                    else None
                }
            )
            for retry in sample.error_retries
        ]
        if sample.error_retries is not None
        else None
    )

    # condense events
    existing = sample.events_data
    existing_context = WalkContext(message_cache={}, only_core=False)
    existing_msgs = (
        [
            walk_chat_message(message, events_fn, existing_context)
            for message in existing["messages"]
        ]
        if existing
        else []
    )
    existing_calls = (
        [
            walk_json_value(call, events_fn, existing_context)
            for call in existing["calls"]
        ]
        if existing
        else []
    )

    msg_index = _build_msg_index(existing_msgs)
    condensed_events, _, new_msgs = condense_model_event_inputs(
        condensed_events, len(existing_msgs), msg_index
    )
    message_pool: list[ChatMessage] = [
        *existing_msgs,
        *(msg for _, msg in new_msgs),
    ]

    call_index = _build_call_index(existing_calls)
    condensed_events, _, new_calls = condense_model_event_calls(
        condensed_events, len(existing_calls), call_index
    )
    call_pool: list[JsonValue] = [
        *existing_calls,
        *(call_msg for _, call_msg in new_calls),
    ]
    events_data = EventsData(messages=message_pool, calls=call_pool)

    condensed_sample = sample.model_copy(
        update={
            "input": walk_input(sample.input, messages_fn, messages_context),
            "messages": walk_chat_messages(
                sample.messages, messages_fn, messages_context
            ),
            "events": condensed_events,
            "error_retries": condensed_error_retries,
            "attachments": attachments,
            "events_data": events_data,
        }
    )
    # Rewrites can disagree across fields that share one attachment. Determine
    # liveness only after every field is condensed so no surviving reference is
    # orphaned; the full dump is the correctness cost of that final GC pass.
    referenced_attachments = attachment_refs_from_value(
        condensed_sample.model_dump(mode="python", exclude={"attachments"})
    )
    return condensed_sample.model_copy(
        update={
            "attachments": {
                hash: value
                for hash, value in attachments.items()
                if hash not in rewritten_attachments or hash in referenced_attachments
            }
        }
    )


def condense_event(
    event: Event,
    attachments: MutableMapping[str, str],
    log_images: bool = True,
    context: WalkContext | None = None,
) -> Event:
    event_fn = events_attachment_fn(attachments, log_images)
    if context is None:
        context = WalkContext(message_cache={}, only_core=False)
    return walk_event(event, event_fn, context)


def events_attachment_fn(
    attachments: MutableMapping[str, str], log_images: bool = True
) -> Callable[[str], str]:
    create_attachment = attachment_fn(attachments)

    # for events, we want to strip images when requested and
    # create attachments for text > 100
    def fn(text: str) -> str:
        if not log_images and is_data_uri(text):
            return BASE_64_DATA_REMOVED
        elif len(text) > 100:
            return create_attachment(text)
        else:
            return text

    return fn


def messages_attachment_fn(
    attachments: MutableMapping[str, str], log_images: bool = True
) -> Callable[[str], str]:
    create_attachment = attachment_fn(attachments)

    # for messages, we only want to handle images (either stripping
    # them or turning them into attachments as required)
    def fn(text: str) -> str:
        if is_data_uri(text):
            if log_images:
                return create_attachment(text)
            else:
                return BASE_64_DATA_REMOVED
        else:
            return text

    return fn


def _existing_attachments_content_fn(
    existing: Mapping[str, str],
    rewritten_attachments: set[str],
    content_fn: Callable[[str], str],
) -> Callable[[str], str]:
    """Apply a content policy to values referenced by existing attachments."""

    def fn(text: str) -> str:
        if text.startswith(ATTACHMENT_PROTOCOL):
            hash = text.removeprefix(ATTACHMENT_PROTOCOL)
            value = existing.get(hash)
            if value is not None:
                rewritten = content_fn(value)
                if rewritten != text:
                    rewritten_attachments.add(hash)
                return rewritten
        return content_fn(text)

    return fn


def attachment_fn(attachments: MutableMapping[str, str]) -> Callable[[str], str]:
    def create_attachment(text: str) -> str:
        hash = mm3_hash(text)
        attachments[hash] = text
        return f"{ATTACHMENT_PROTOCOL}{hash}"

    return create_attachment


def resolve_sample_attachments(
    sample: EvalSample,
    resolve_attachments: bool | Literal["full", "core"] = "core",
) -> EvalSample:
    """Resolve content attachments (typically images) in sample.

    Take 'attachment://*` references and resolve them to their
    underlying content, then remove the 'attachments' entries that are no
    longer referenced. "core" leaves `ModelEvent.call` condensed, so the
    attachments its references still point at are retained; "full" resolves
    everything and clears the field.

    Args:
       sample (EvalSample): Eval sample with attachments.
       resolve_attachments: Should attachments be resolved. "core" means only resolving attachments in the core fields.

    Returns:
       EvalSample: Sample with attachment content resolved.
    """
    if resolve_attachments is False:
        return sample

    def content_fn(text: str) -> str:
        # migrate previous flavor of content reference
        CONTENT_PROTOCOL = "tc://"
        if text.startswith(CONTENT_PROTOCOL):
            text = text.replace(CONTENT_PROTOCOL, ATTACHMENT_PROTOCOL, 1)
        if text.startswith(ATTACHMENT_PROTOCOL):
            return sample.attachments.get(
                text.replace(ATTACHMENT_PROTOCOL, "", 1), text
            )
        else:
            return text

    context = WalkContext(
        message_cache={},
        only_core=resolve_attachments == "core",
    )

    # Resolve pools before events — pool messages may contain attachment:// refs
    ed = sample.events_data
    msg_pool = ed["messages"] if ed else []
    call_pool = ed["calls"] if ed else []

    resolved_pool: list[ChatMessage] = [
        walk_chat_message(v, content_fn, context) for v in msg_pool
    ]
    resolved_call_pool: list[JsonValue] = (
        call_pool
        if context.get("only_core")
        else [walk_json_value(v, content_fn, context) for v in call_pool]
    )

    resolved_events = walk_events(sample.events, content_fn, context)
    resolved_events = resolve_model_event_inputs(resolved_events, resolved_pool)
    resolved_events = resolve_model_event_calls(resolved_events, resolved_call_pool)
    retry_events_context = WalkContext(
        message_cache={},
        only_core=resolve_attachments == "core",
    )
    resolved_error_retries = (
        [
            retry.model_copy(
                update={
                    "events": walk_events(
                        retry.events,
                        content_fn,
                        retry_events_context,
                    )
                    if retry.events is not None
                    else None
                }
            )
            for retry in sample.error_retries
        ]
        if sample.error_retries is not None
        else None
    )

    resolved_sample = sample.model_copy(
        update={
            "input": walk_input(sample.input, content_fn, context),
            "messages": walk_chat_messages(sample.messages, content_fn, context),
            "events": resolved_events,
            "error_retries": resolved_error_retries,
            "attachments": {},
            "events_data": None,
        }
    )

    # "full" resolves every reference, so nothing can still point at the map.
    if resolve_attachments != "core" or not sample.attachments:
        return resolved_sample

    # "core" leaves ModelEvent.call condensed, so its attachment:// refs
    # survive into the resolved sample. Retain what they point at (the same
    # liveness pass condense_sample runs) or they become unresolvable.
    referenced_attachments = attachment_refs_from_value(
        resolved_sample.model_dump(mode="python", exclude={"attachments"})
    )
    if not referenced_attachments:
        return resolved_sample
    return resolved_sample.model_copy(
        update={
            "attachments": {
                hash: value
                for hash, value in sample.attachments.items()
                if hash in referenced_attachments
            }
        }
    )


def resolve_events_attachments(
    events: list[Event],
    attachments: Mapping[str, str],
    resolve_attachments: bool | Literal["full", "core"] = "core",
) -> list[Event]:
    """Resolve ``attachment://`` references in a list of events.

    The events must already have their message / call *pools* resolved
    (the buffer history provider does this via
    ``materialize_pooled_events``); this only swaps ``attachment://<hash>``
    content references back to their underlying values from
    ``attachments``.

    Args:
       events: Events (pool-resolved) that may carry ``attachment://`` refs.
       attachments: Mapping of attachment hash -> underlying content.
       resolve_attachments: Which fields to resolve. ``"core"`` (default)
           leaves ``ModelEvent.call`` condensed — matching resident
           in-memory events, whose model-call payloads stay condensed
           after ``Transcript._process_event``. ``"full"`` / ``True``
           also resolves the model call. ``False`` is a no-op.

    Returns:
       Events with attachment content resolved (a new list; inputs are
       not mutated). Returns ``events`` unchanged when
       ``resolve_attachments`` is ``False``.
    """
    if resolve_attachments is False:
        return events

    def content_fn(text: str) -> str:
        # migrate previous flavor of content reference
        CONTENT_PROTOCOL = "tc://"
        if text.startswith(CONTENT_PROTOCOL):
            text = text.replace(CONTENT_PROTOCOL, ATTACHMENT_PROTOCOL, 1)
        if text.startswith(ATTACHMENT_PROTOCOL):
            return attachments.get(text.replace(ATTACHMENT_PROTOCOL, "", 1), text)
        else:
            return text

    context = WalkContext(message_cache={}, only_core=resolve_attachments == "core")
    return walk_events(events, content_fn, context)


def attachments_content_fn(
    log_images: bool, max_length: int, attachments: MutableMapping[str, str]
) -> Callable[[str], str]:
    def create_attachment(text: str) -> str:
        hash = mm3_hash(text)
        attachments[hash] = text
        return f"{ATTACHMENT_PROTOCOL}{hash}"

    def content_fn(text: str) -> str:
        if not log_images and is_data_uri(text):
            return BASE_64_DATA_REMOVED
        elif len(text) > max_length:
            return create_attachment(text)
        else:
            return text

    return content_fn


def walk_events(
    events: list[Event], content_fn: Callable[[str], str], context: WalkContext
) -> list[Event]:
    return [walk_event(event, content_fn, context) for event in events]


def walk_event(
    event: Event, content_fn: Callable[[str], str], context: WalkContext
) -> Event:
    if isinstance(event, SampleInitEvent):
        return walk_sample_init_event(event, content_fn, context)
    elif isinstance(event, ModelEvent):
        return walk_model_event(event, content_fn, context)
    elif isinstance(event, StateEvent):
        return walk_state_event(event, content_fn, context)
    elif isinstance(event, StoreEvent):
        return walk_store_event(event, content_fn, context)
    elif isinstance(event, SubtaskEvent):
        return walk_subtask_event(event, content_fn, context)
    elif isinstance(event, ToolEvent):
        return walk_tool_event(event, content_fn, context)
    elif isinstance(event, InfoEvent):
        return walk_info_event(event, content_fn, context)
    else:
        return event


def walk_subtask_event(
    event: SubtaskEvent, content_fn: Callable[[str], str], context: WalkContext
) -> SubtaskEvent:
    return event.model_copy(
        update=dict(events=walk_events(event.events, content_fn, context))
    )


def walk_tool_event(
    event: ToolEvent, content_fn: Callable[[str], str], context: WalkContext
) -> ToolEvent:
    return event.model_copy(
        update=dict(
            arguments=walk_json_dict(event.arguments, content_fn, context),
            events=walk_events(event.events, content_fn, context),
        )
    )


def walk_info_event(
    event: InfoEvent, content_fn: Callable[[str], str], context: WalkContext
) -> InfoEvent:
    return event.model_copy(
        update=dict(data=walk_json_value(event.data, content_fn, context))
    )


def walk_sample_init_event(
    event: SampleInitEvent, content_fn: Callable[[str], str], context: WalkContext
) -> SampleInitEvent:
    return event.model_copy(
        update=dict(
            sample=walk_sample(event.sample, content_fn, context),
            state=walk_json_value(event.state, content_fn, context),
        )
    )


def walk_sample(
    sample: Sample, content_fn: Callable[[str], str], context: WalkContext
) -> Sample:
    if isinstance(sample.input, str):
        return sample.model_copy(
            update=dict(input=walk_json_value(sample.input, content_fn, context))
        )
    else:
        return sample.model_copy(
            update=dict(input=walk_chat_messages(sample.input, content_fn, context))
        )


def walk_model_event(
    event: ModelEvent, content_fn: Callable[[str], str], context: WalkContext
) -> ModelEvent:
    return event.model_copy(
        update=dict(
            tools=walk_tools(event.tools, content_fn, context),
            input=walk_chat_messages(event.input, content_fn, context),
            output=walk_model_output(event.output, content_fn, context),
            call=walk_model_call(event.call, content_fn, context),
        ),
    )


def walk_model_output(
    output: ModelOutput, content_fn: Callable[[str], str], context: WalkContext
) -> ModelOutput:
    return output.model_copy(
        update=dict(
            choices=[
                choice.model_copy(
                    update=dict(
                        message=walk_chat_message(choice.message, content_fn, context)
                    )
                )
                for choice in output.choices
            ]
        )
    )


def walk_model_call(
    call: ModelCall | None, content_fn: Callable[[str], str], context: WalkContext
) -> ModelCall | None:
    if context.get("only_core") is True:
        return call
    if call:
        return call.model_copy(
            update={
                "request": walk_json_dict(call.request, content_fn, context),
                "response": walk_json_dict(call.response, content_fn, context)
                if call.response
                else None,
            }
        )
    else:
        return None


def walk_state_event(
    event: StateEvent, content_fn: Callable[[str], str], context: WalkContext
) -> StateEvent:
    event = event.model_copy(
        update=dict(
            changes=[
                walk_state_json_change(change, content_fn, context)
                for change in event.changes
            ]
        )
    )
    return event


def walk_store_event(
    event: StoreEvent, content_fn: Callable[[str], str], context: WalkContext
) -> StoreEvent:
    event = event.model_copy(
        update=dict(
            changes=[
                walk_state_json_change(change, content_fn, context)
                for change in event.changes
            ]
        )
    )
    return event


def walk_state_json_change(
    change: JsonChange, content_fn: Callable[[str], str], context: WalkContext
) -> JsonChange:
    return change.model_copy(
        update=dict(value=walk_json_value(change.value, content_fn, context))
    )


def walk_json_value(
    value: JsonValue, content_fn: Callable[[str], str], context: WalkContext
) -> JsonValue:
    if isinstance(value, str):
        return content_fn(value)
    elif isinstance(value, list):
        return walk_json_list(value, content_fn, context)
    elif isinstance(value, dict):
        return walk_json_dict(value, content_fn, context)
    else:
        return value


def walk_json_list(
    value: list[JsonValue],
    content_fn: Callable[[str], str],
    context: WalkContext,
) -> list[JsonValue]:
    walked_list: list[JsonValue] | None = None

    for i, v in enumerate(value):
        walked = walk_json_value(v, content_fn, context)
        if walked is not v:
            if walked_list is None:
                walked_list = list(value)
            walked_list[i] = walked

    return walked_list if walked_list is not None else value


def walk_json_dict(
    value: dict[str, JsonValue],
    content_fn: Callable[[str], str],
    context: WalkContext,
) -> dict[str, JsonValue]:
    walked_dict: dict[str, JsonValue] | None = None

    for k, v in value.items():
        walked = walk_json_value(v, content_fn, context)
        if walked is not v:
            if walked_dict is None:
                walked_dict = value.copy()
            walked_dict[k] = walked

    return walked_dict if walked_dict is not None else value


def walk_input(
    input: str | list[ChatMessage],
    content_fn: Callable[[str], str],
    context: WalkContext,
) -> str | list[ChatMessage]:
    if isinstance(input, str):
        return input
    else:
        return walk_chat_messages(input, content_fn, context)


def walk_chat_messages(
    messages: list[ChatMessage],
    content_fn: Callable[[str], str],
    context: WalkContext,
) -> list[ChatMessage]:
    return [walk_chat_message(message, content_fn, context) for message in messages]


def walk_chat_message(
    message: ChatMessage, content_fn: Callable[[str], str], context: WalkContext
) -> ChatMessage:
    cache = context.get("message_cache")
    if cache is not None and message.id is not None:
        hit = cache.get(message.id)
        if hit is not None:
            pre_walk, walked = hit
            if pre_walk is message or pre_walk == message:
                return walked
    if isinstance(message.content, str):
        res = message.model_copy(update=dict(content=content_fn(message.content)))
    else:
        res = message.model_copy(
            update=dict(
                tool_calls=[
                    walk_tool_call(tool_call, content_fn, context)
                    for tool_call in message.tool_calls
                ]
                if isinstance(message, ChatMessageAssistant) and message.tool_calls
                else None,
                content=[
                    walk_content(content, content_fn, context)
                    for content in message.content
                ],
            )
        )
    if cache is not None and message.id is not None:
        cache[message.id] = (message, res)
    return res


def walk_content(
    content: Content, content_fn: Callable[[str], str], context: WalkContext
) -> Content:
    if isinstance(content, ContentText):
        return content.model_copy(update=dict(text=content_fn(content.text)))
    elif isinstance(content, ContentImage):
        return content.model_copy(update=dict(image=content_fn(content.image)))
    elif isinstance(content, ContentAudio):
        return content.model_copy(update=dict(audio=content_fn(content.audio)))
    elif isinstance(content, ContentVideo):
        return content.model_copy(update=dict(video=content_fn(content.video)))
    elif isinstance(content, ContentReasoning):
        return content.model_copy(update=dict(reasoning=content_fn(content.reasoning)))
    elif isinstance(content, ContentToolUse):
        return content.model_copy(
            update=dict(
                arguments=walk_json_value(content.arguments, content_fn, context),
                result=walk_json_value(content.result, content_fn, context),
                error=content_fn(content.error) if content.error else content.error,
            )
        )
    elif isinstance(content, ContentData):
        return content.model_copy(
            update=dict(data=walk_json_value(content.data, content_fn, context))
        )
    elif isinstance(content, ContentDocument):
        return content.model_copy(update=dict(document=content_fn(content.document)))


def walk_tools(
    tools: list[ToolInfo], content_fn: Callable[[str], str], context: WalkContext
) -> list[ToolInfo]:
    return [
        tool.model_copy(
            update=dict(
                description=content_fn(tool.description),
            )
        )
        for tool in tools
    ]


def walk_tool_call(
    tool_call: ToolCall, content_fn: Callable[[str], str], context: WalkContext
) -> ToolCall:
    return ToolCall(
        id=tool_call.id,
        function=tool_call.function,
        arguments=walk_json_dict(tool_call.arguments, content_fn, context),
        parse_error=tool_call.parse_error,
        view=tool_call.view.model_copy(
            update=dict(
                # ToolCallContent.content is a non-optional str (default ""),
                # so preserve an empty content as "" — nulling it here breaks
                # readback validation (e.g. title-only lifecycle-tool views).
                content=content_fn(tool_call.view.content)
                if tool_call.view.content
                else tool_call.view.content,
            )
        )
        if tool_call.view
        else None,
        type=tool_call.type,
    )
