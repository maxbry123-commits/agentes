from __future__ import annotations

import inspect
import sys
from inspect import get_annotations, isclass
from typing import (
    TYPE_CHECKING,
    Any,
    Callable,
    Literal,
    TypeGuard,
    cast,
    get_args,
    overload,
)

from pydantic import BaseModel, Field
from pydantic_core import to_jsonable_python
from typing_extensions import TypedDict

from inspect_ai._util.json import jsonable_python
from inspect_ai._util.package import get_installed_package_name

from .constants import PKG_NAME
from .entrypoints import ensure_entry_points

if TYPE_CHECKING:
    from inspect_ai import Task
    from inspect_ai.agent import Agent
    from inspect_ai.approval import Approver
    from inspect_ai.hooks._hooks import Hooks
    from inspect_ai.model import ModelAPI
    from inspect_ai.scorer import Metric, Scorer, ScoreReducer
    from inspect_ai.solver import Plan, Solver
    from inspect_ai.tool import Tool
    from inspect_ai.util import SandboxEnvironment

obj_type = type

RegistryType = Literal[
    "agent",
    "approver",
    "hooks",
    "metric",
    "modelapi",
    "plan",
    "sandboxenv",
    "score_reducer",
    "scorer",
    "solver",
    "task",
    "task_source",
    "tool",
    "loader",
    "scanner",
    "scanjob",
    "validation_predicate",
]
"""Enumeration of registry object types.

These are the types of objects in this system that can be
registered using a decorator (e.g. `@task`, `@solver`).
Registered objects can in turn be created dynamically using
the `registry_create()` function.
"""

_REGISTRY_TYPE_VALUES: frozenset[str] = frozenset(get_args(RegistryType))


class RegistryInfo(BaseModel):
    """Registry information for registered object (e.g. solver, scorer, etc.)."""

    type: RegistryType
    """Type of registry object."""

    name: str
    """Registered name."""

    metadata: dict[str, Any] = Field(default_factory=dict)
    """Additional registry metadata."""


def set_annotations(wrapper: Callable[..., Any], annotations: dict[str, Any]) -> None:
    """Set `wrapper`'s annotations in both PEP 649 representations.

    On Python 3.14+ a bare `wrapper.__annotations__ = ...` assignment sets the lazy
    `__annotate__` to None, and mutating the dict in place doesn't update
    `__annotate__` at all. Either way, a further `functools.wraps` layer (which
    copies `__annotate__`, not `__annotations__`) then silently drops the
    annotations — e.g. in user decorators that extend @task/@solver/@agent and
    re-register their own wrapper. Setting both representations keeps annotations
    consistent under further wrapping. Always use this instead of assigning
    `__annotations__` directly.
    """
    annotations = dict(annotations)
    wrapper.__annotations__ = annotations
    if sys.version_info >= (3, 14):
        from annotationlib import Format  # type: ignore[import-not-found,unused-ignore]

        def __annotate__(format: Format) -> dict[str, Any]:
            # NotImplementedError is the protocol's "format not supported" signal:
            # PEP 749 requires it for VALUE_WITH_FAKE_GLOBALS (hand-written annotate
            # functions can't run under fake globals), and annotationlib's consumers
            # compute FORWARDREF/STRING themselves by falling back to VALUE. See
            # "Format compatibility" in the annotationlib docs:
            # https://docs.python.org/3.14/library/annotationlib.html
            if format != Format.VALUE:
                raise NotImplementedError(format)
            return dict(annotations)

        wrapper.__annotate__ = __annotate__  # type: ignore[attr-defined,unused-ignore]


def set_return_annotation(wrapper: Callable[..., Any], return_type: type[Any]) -> None:
    """Restore `wrapper`'s return annotation after `functools.wraps` clobbered it.

    Decorators like @task wrap the user's function with `functools.wraps` (so name,
    docstring, and params carry over) but need the wrapper itself to be annotated as
    returning the registry type: `registry_create` consults the return
    annotation to decide whether a registered callable is a factory to invoke.
    """
    set_annotations(wrapper, {**wrapper.__annotations__, "return": return_type})


def registry_add(o: object, info: RegistryInfo) -> None:
    r"""Add an object to the registry.

    Add the passed object to the registry using the RegistryInfo
    to index it for retrieval. The RegistryInfo is also added
    to the object as an attribute, which can retrieved by calling
    registry_info() on an object instance.

    Args:
        o (object): Object to be registered (Metric, Solver, etc.)
        info (RegistryInfo): Metadata (name, etc.) for object.
    """
    # tag the object
    setattr(o, REGISTRY_INFO, info)

    # add to registry
    _registry[registry_key(info.type, info.name)] = o

    # bump version so caches keyed on registry contents (e.g. get_all_hooks)
    # know to invalidate
    global _registry_version
    _registry_version += 1


def registry_tag(
    type: Callable[..., Any],
    o: object,
    info: RegistryInfo,
    /,
    *args: Any,
    **kwargs: Any,
) -> None:
    r"""Tag an object w/ registry info.

    Tag the passed object with RegistryInfo. This function DOES NOT
    add the object to the registry (call registry_add() to both
    tag and add an object to the registry). Call registry_info()
    on a tagged/registered object to retrieve its info

    `type`, `o` and `info` are positional-only so that a creation keyword
    argument sharing one of those names (e.g. a `@solver` that takes a
    `type` **kwarg) lands in `**kwargs` instead of colliding with the
    parameter and raising `TypeError: got multiple values for argument`.

    Args:
        type (T): type of object being tagged
        o (object): Object to be registered (Metric, Solver, etc.)
        info (RegistryInfo): Metadata (name, etc.) for object.
        *args (list[Any]): Creation arguments
        **kwargs (dict[str,Any]): Creation keyword arguments
    """
    # bind arguments to params
    named_params = extract_named_params(type, False, *args, **kwargs)

    # set attribute
    setattr(o, REGISTRY_INFO, info)
    setattr(o, REGISTRY_PARAMS, named_params)


def extract_named_params(
    type: Callable[..., Any], apply_defaults: bool, /, *args: Any, **kwargs: Any
) -> dict[str, Any]:
    # positional-only for the same collision reason documented on
    # registry_tag: a creation keyword argument named `type` must land in
    # **kwargs rather than in these leading parameters.
    named_params: dict[str, Any] = {}

    sig = inspect.signature(type)
    if apply_defaults:
        bound_params = sig.bind_partial(*args, **kwargs)
        bound_params.apply_defaults()
    else:
        bound_params = sig.bind(*args, **kwargs)

    # arguments passed through a **kwargs (VAR_KEYWORD) parameter are collected
    # by inspect under the variadic parameter's own name (e.g. {"kwargs": {...}}).
    # Record them under their original keyword names instead, so that capturing
    # and then replaying a spec is idempotent rather than nesting the kwargs one
    # level deeper on every round-trip (#4374).
    var_keyword = next(
        (
            name
            for name, param in sig.parameters.items()
            if param.kind == inspect.Parameter.VAR_KEYWORD
        ),
        None,
    )

    # limitation: flattening last means a **kwargs key that shares its name with
    # a positional-only parameter (e.g. `def f(x, /, **kw)` called as `f(1, x=2)`)
    # overwrites that parameter's captured value. Such a signature could never
    # replay from a kwargs dict anyway, so we accept the lossy capture.
    for param, value in bound_params.arguments.items():
        if param == var_keyword and isinstance(value, dict):
            for kwarg_name, kwarg_value in value.items():
                named_params[kwarg_name] = registry_value(kwarg_value)
        else:
            named_params[param] = registry_value(value)

    # callables are not serializable so use their names
    for param in named_params.keys():
        if hasattr(named_params[param], "_repr_params_"):
            named_params[param] = named_params[param]._repr_params_()

        if is_registry_object(named_params[param]):
            named_params[param] = registry_info(named_params[param]).name
        elif callable(named_params[param]) and hasattr(named_params[param], "__name__"):
            named_params[param] = getattr(named_params[param], "__name__")
        elif isinstance(named_params[param], dict | list | BaseModel):
            named_params[param] = to_jsonable_python(
                named_params[param], fallback=lambda x: getattr(x, "__name__", None)
            )
        elif isinstance(named_params[param], str | int | float | str | bool | None):
            named_params[param] = named_params[param]
        else:
            named_params[param] = (
                getattr(named_params[param], "name", None)
                or getattr(named_params[param], "__name__", None)
                or getattr(obj_type(named_params[param]), "__name__", None)
                or "<unknown>"
            )

    return named_params


def registry_name(o: object, name: str) -> str:
    r"""Compute the registry name of an object.

    This function checks whether the passed object is in a package,
    and if it is, prepends the package name as a namespace
    """
    package = get_installed_package_name(o)
    return f"{package}/{name}" if package else name


def registry_lookup(type: RegistryType, name: str) -> object | None:
    r"""Lookup an object in the registry by type and name.

    Objects that defined in inspect extension packages (i.e. not
    directly within the core inspect_ai package) must be namespaced
    (e.g. "fancy_prompts/jailbreaker")

    Args:
        type: Type of object to find
        name: Name of object to find

    Returns:
        Object or None if not found.
    """

    def _lookup() -> object | None:
        # first try
        object = _registry.get(registry_key(type, name))
        if object:
            return object
        # unnamespaced objects can also be found in inspect_ai
        elif name.find("/") == -1:
            return _registry.get(registry_key(type, f"{PKG_NAME}/{name}"))
        else:
            return None

    o = _lookup()

    # try to recover
    if o is None:
        # load entry points for this package as required
        if name.find("/") != -1 and name.find(".") == -1:
            package = name.split("/")[0]
            ensure_entry_points(package)

        return _lookup()
    else:
        return o


def registry_package_name(name: str) -> str | None:
    if name.find("/") != -1 and name.find(".") == -1:
        return name.split("/")[0]
    else:
        return None


def registry_find(predicate: Callable[[RegistryInfo], bool]) -> list[object]:
    r"""Find objects in the registry that match the passed predicate.

    Args:
        predicate (Callable[[RegistryInfo], bool]): Predicate to find

    Returns:
        List of registry objects found
    """

    def _find() -> list[object]:
        return [
            object for object in _registry.values() if predicate(registry_info(object))
        ]

    o = _find()
    if len(o) == 0:
        ensure_entry_points()
        return _find()
    else:
        return o


@overload
def registry_create(type: Literal["agent"], name: str, **kwargs: Any) -> Agent: ...


@overload
def registry_create(
    type: Literal["approver"], name: str, **kwargs: Any
) -> Approver: ...


@overload
def registry_create(type: Literal["hooks"], name: str, **kwargs: Any) -> Hooks: ...


@overload
def registry_create(type: Literal["metric"], name: str, **kwargs: Any) -> Metric: ...


@overload
def registry_create(
    type: Literal["modelapi"], name: str, **kwargs: Any
) -> ModelAPI: ...


@overload
def registry_create(type: Literal["plan"], name: str, **kwargs: Any) -> Plan: ...


@overload
def registry_create(
    type: Literal["sandboxenv"], name: str, **kwargs: Any
) -> SandboxEnvironment: ...


@overload
def registry_create(type: Literal["scorer"], name: str, **kwargs: Any) -> Scorer: ...


@overload
def registry_create(
    type: Literal["score_reducer"], name: str, **kwargs: Any
) -> ScoreReducer: ...


@overload
def registry_create(type: Literal["solver"], name: str, **kwargs: Any) -> Solver: ...


@overload
def registry_create(type: Literal["task"], name: str, **kwargs: Any) -> Task: ...


@overload
def registry_create(type: Literal["tool"], name: str, **kwargs: Any) -> Tool: ...


@overload
def registry_create(type: Literal["loader"], name: str, **kwargs: Any) -> Any: ...


@overload
def registry_create(type: Literal["scanner"], name: str, **kwargs: Any) -> Any: ...


@overload
def registry_create(type: Literal["scanjob"], name: str, **kwargs: Any) -> Any: ...


def registry_create(type: RegistryType, name: str, **kwargs: Any) -> object:  # type: ignore[return]
    r"""Create a registry object.

    Creates objects registered via decorator (e.g. `@task`, `@solver`). Note
    that this can also create registered objects within Python packages, in
    which case the name of the package should be used a prefix, e.g.

    ```python
    registry_create("scorer", "mypackage/myscorer", ...)
    ```

    Object within the Inspect package do not require a prefix, nor do
    objects from imported modules that aren't in a package.

    Args:
        type: Type of registry object to create
        name: Name of registry object to create
        **kwargs: Optional creation arguments

    Returns:
        Instance of specified name and type.

    Raises:
        LookupError: If the named object was not found in the registry.
        TypeError: If the specified parameters are not valid for the object.
    """
    obj = registry_lookup(type, name)

    if isclass(obj):
        return _instantiate_registry_object(obj, kwargs)
    elif callable(obj):
        return_type = get_annotations(obj, eval_str=True).get("return")
        # Until we remove the MetricDeprecated symbol we need this extra
        # bit to map the Metric union back to Metric
        if "_metric.Metric" in str(return_type):
            return_type = "Metric"
        else:
            return_type = getattr(return_type, "__name__", None)
        if return_type and return_type.lower() == type:
            return _instantiate_registry_object(obj, kwargs)
        else:
            return obj
    else:
        raise LookupError(f"{name} was not found in the registry")


def create_registry_object(
    type: RegistryType, name: str, args: dict[str, Any]
) -> object:
    """Restore a registry object, passing creation arguments as a dict.

    Serialized registry arguments describe an instance, so registered classes
    and factories are always instantiated. The explicit arguments dictionary
    also avoids collisions with `registry_create()`'s positional parameters
    (e.g. replaying a factory such as `react` that has its own `name` parameter).
    """
    obj = registry_lookup(type, name)

    if isclass(obj) or callable(obj):
        return _instantiate_registry_object(obj, args)
    else:
        raise LookupError(f"{name} was not found in the registry")


def _instantiate_registry_object(
    obj: Callable[..., object], args: dict[str, Any]
) -> object:
    instance = obj(**registry_kwargs(**args))
    info = registry_info(obj)
    # Objects created by self-tagging factories (e.g. @agent / @solver) already
    # carry richer metadata. Preserve it while retaining the factory identity.
    if is_registry_object(instance) and registry_info(instance).metadata:
        info = info.model_copy(update={"metadata": registry_info(instance).metadata})
    return set_registry_info(instance, info)


def registry_info(o: object) -> RegistryInfo:
    r"""Lookup RegistryInfo for an object.

    Args:
        o (object): Object to lookup info for

    Returns:
        RegistryInfo for object.

    Raises:
        ValueError: If the object does not have registry info.
    """
    info = getattr(o, REGISTRY_INFO, None)
    if info is not None:
        return cast(RegistryInfo, info)
    else:
        name = getattr(o, "__name__", "unknown")
        decorator = " @solver " if name == "solve" else " "
        raise ValueError(
            f"Object '{name}' does not have registry info. Did you forget to add a{decorator}decorator somewhere?"
        )


def registry_params(o: object) -> dict[str, Any]:
    r"""Lookup parameters used to instantiate a registry object.

    Args:
        o (object): Object to lookup info for

    Returns:
        Dictionary of parameters used to instantiate object.
    """
    params = getattr(o, REGISTRY_PARAMS, None)
    if params is not None:
        return cast(dict[str, Any], params)
    else:
        raise ValueError("Object does not have registry info")


def registry_log_name(o: str | object) -> str:
    r"""Name of object for logging.

    Registry objects defined by the inspect_ai package have their
    prefix stripped when written to the log (they in turn can also
    be created/referenced without the prefix).

    Args:
        o (str | object): Name or object to get name for

    Returns:
        Name of object for logging.
    """
    name = o if isinstance(o, str) else registry_info(o).name
    return name.replace(f"{PKG_NAME}/", "", 1)


def registry_unqualified_name(o: str | object | RegistryInfo) -> str:
    r"""Unqualified name of object (i.e. without package prefix).

    Args:
        o (str | object | RegistryInfo): string, registry object, or RegistryInfo to get unqualified name for.

    Returns:
        Unqualified name of object
    """
    if isinstance(o, str):
        name = o
    else:
        info = o if isinstance(o, RegistryInfo) else registry_info(o)
        name = info.name
    parts = name.split("/")
    if len(parts) == 1:
        return parts[0]
    else:
        return "/".join(parts[1:])


def is_registry_object(o: object, type: RegistryType | None = None) -> bool:
    r"""Check if an object is a registry object.

    Args:
        o (object): Object to lookup info for
        type: (RegistryType | None): Optional. Check for a specific type

    Returns:
        True if the object is a registry object (optionally of the specified
        type). Otherwise, False
    """
    info = getattr(o, REGISTRY_INFO, None)
    if info:
        reg_info = cast(RegistryInfo, info)
        if type:
            return reg_info.type == type
        else:
            return True
    else:
        return False


def set_registry_info(o: object, info: RegistryInfo) -> object:
    r"""Set the RegistryInfo for an object.

    Args:
        o (object): Object to set the registry info for
        info: (object): Registry info

    Returns:
        Passed object, with RegistryInfo attached
    """
    setattr(o, REGISTRY_INFO, info)
    return o


def set_registry_params(o: object, params: dict[str, Any]) -> object:
    r"""Set the registry params for an object.

    Args:
        o (object): Object to set the registry params for
        params: (dict[str, Any]): Registry params

    Returns:
        Passed object, with registry params attached
    """
    setattr(o, REGISTRY_PARAMS, params)
    return o


def has_registry_params(o: object) -> bool:
    r"""Check if the object has registry params.

    Args:
        o (object): Object to check.

    Returns:
        True if the object has registry params, else False.
    """
    return is_registry_object(o) and hasattr(o, REGISTRY_PARAMS)


def registry_key(type: RegistryType, name: str) -> str:
    return f"{type}:{name}"


REGISTRY_INFO = "__registry_info__"
REGISTRY_PARAMS = "__registry_params__"
_registry: dict[str, object] = {}

# Monotonic counter bumped by `registry_add` on every mutation. Used by
# consumers (e.g. `get_all_hooks`) to cache results derived from the registry
# while invalidating automatically when new entries are added. Module-private
# — read it via `registry_version()` if needed externally.
_registry_version: int = 0


def registry_version() -> int:
    """Current registry version. Bumped on each `registry_add`."""
    return _registry_version


class RegistryDict(TypedDict):
    type: RegistryType
    name: str
    params: dict[str, Any]


def is_registry_dict(o: object) -> TypeGuard[RegistryDict]:
    if not isinstance(o, dict):
        return False
    registry_type = o.get("type")
    if not isinstance(registry_type, str) or registry_type not in _REGISTRY_TYPE_VALUES:
        return False
    if not isinstance(o.get("name"), str):
        return False
    if not isinstance(o.get("params"), dict):
        return False
    return True


def registry_value(o: object) -> Any:
    from inspect_ai.model._model import Model

    # treat tuple as list
    if isinstance(o, tuple):
        o = list(o)

    # recurse through collection types
    if isinstance(o, list):
        return [registry_value(x) for x in o]
    elif isinstance(o, dict):
        return {k: registry_value(v) for k, v in o.items()}
    elif has_registry_params(o):
        return RegistryDict(
            type=registry_info(o).type,
            name=registry_log_name(o),
            params=registry_params(o),
        )
    elif isinstance(o, Model):
        return ModelDict(
            model=str(o),
            config=jsonable_python(o.config),
            base_url=o.api.base_url,
            model_args=o.model_args,
        )
    else:
        return o


def registry_arg(arg: Any) -> Any:
    if isinstance(arg, dict):
        if is_registry_dict(arg):
            return create_registry_object(arg["type"], arg["name"], arg["params"])
        elif is_model_dict(arg):
            return model_create_from_dict(arg)
        else:
            return {k: registry_arg(v) for k, v in arg.items()}
    elif isinstance(arg, (list, tuple)):
        return [registry_arg(item) for item in arg]
    else:
        return arg


# resolve embedded registry objects and models
def registry_kwargs(**kwargs: Any) -> dict[str, Any]:
    """Resolve any registry and model dicts in the given kwargs."""
    return {k: registry_arg(v) for k, v in kwargs.items()}


def registry_create_from_dict(d: RegistryDict) -> object:
    return create_registry_object(d["type"], d["name"], d["params"])


class ModelDict(TypedDict):
    model: str
    config: dict[str, Any]
    base_url: str | None
    model_args: dict[str, Any]


def is_model_dict(o: object) -> TypeGuard[ModelDict]:
    return (
        isinstance(o, dict)
        and "model" in o
        and "config" in o
        and "base_url" in o
        and "model_args" in o
    )


def model_create_from_dict(d: ModelDict) -> object:
    from inspect_ai.model._generate_config import GenerateConfig
    from inspect_ai.model._model import get_model

    return get_model(
        d["model"],
        config=GenerateConfig(**d["config"]),
        base_url=d["base_url"],
        **d["model_args"],
    )
