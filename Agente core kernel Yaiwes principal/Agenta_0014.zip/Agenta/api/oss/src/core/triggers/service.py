import asyncio
import hashlib
import hmac
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Mapping, Optional, Set, Tuple
from uuid import UUID

from croniter import croniter

from oss.src.utils.logging import get_module_logger
from oss.src.utils.env import env
from oss.src.utils.caching import get_cache, set_cache
from oss.src.dbs.redis.shared.engine import get_cache_engine

from oss.src.core.gateway.catalog.service import CatalogService
from oss.src.core.gateway.connections.service import ConnectionsService
from oss.src.core.triggers.dtos import (
    DiscoveredTriggerAlternative,
    DiscoveredTriggerEvent,
    TriggerCapabilitiesResult,
    TriggerCapability,
    TriggerCapabilityConnection,
    TriggerCatalogEvent,
    TriggerCatalogEventDetails,
    TriggerCatalogEventsPage,
    TriggerCatalogEventsSnapshot,
    TriggerCatalogIntegration,
    TriggerCatalogIntegrationsPage,
    TriggerCatalogProvider,
    TriggerProviderKind,
    TriggerConnectAffordance,
    TriggerConnection,
    TriggerConnectionRequirement,
    TriggerConnectionCreate,
    TriggerDiscoveryConnectionState,
    TriggerDiscoveryGuidance,
    TriggerDelivery,
    TriggerDeliveryCreate,
    TriggerDeliveryQuery,
    TriggerSchedule,
    TriggerScheduleCreate,
    TriggerScheduleData,
    TriggerScheduleEdit,
    TriggerScheduleQuery,
    TriggerSubscription,
    TriggerSubscriptionCreate,
    TriggerSubscriptionEdit,
    TriggerSubscriptionQuery,
)
from oss.src.core.triggers.exceptions import (
    AdapterError,
    ConnectionNotFoundError,
    ScheduleNotFoundError,
    SubscriptionNotFoundError,
    TriggerReferenceInvalid,
    TriggerScheduleInvalid,
)
from oss.src.core.triggers.interfaces import TriggersDAOInterface
from oss.src.core.triggers.registry import TriggersGatewayRegistry
from oss.src.core.triggers.utils import WebhookSecretResolver
from oss.src.core.shared.dtos import Reference, Windowing
from oss.src.core.shared.exceptions import EntityCreationConflict
from oss.src.core.workflows.service import WorkflowsService


log = get_module_logger(__name__)

_ENQUEUE_TIMEOUT_SECONDS = 5.0

# Seconds /subscriptions/test long-polls for a captured event before teardown.
_TEST_TIMEOUT_SECONDS = 300

_CATALOG_CACHE_NAMESPACE = "triggers:catalog"
# Minimum distinct use-case terms a candidate must match before it can be promoted to the
# primary (capabilities[0]) result. Discovery scores the whole catalog, so a single shared
# generic term ("issue", "email") is not strong enough evidence to surface an integration
# as the best match; an exact phrase hit also clears this.
_DISCOVERY_MIN_PRIMARY_TERMS = 2
_DISCOVERY_STOPWORDS = {
    "a",
    "an",
    "and",
    "at",
    "for",
    "from",
    "in",
    "is",
    "me",
    "new",
    "of",
    "on",
    "or",
    "the",
    "to",
    "when",
    "whenever",
    "with",
    # Meta-vocabulary ("slack triggers") and question filler ("what can gmail do")
    # add noise — "what" even substring-matches WHATSAPP, "can" matches CANVAS.
    "anyone",
    "can",
    "could",
    "did",
    "do",
    "does",
    "how",
    "my",
    "should",
    "someone",
    "trigger",
    "triggered",
    "triggers",
    "webhook",
    "webhooks",
    "what",
    "whats",
    "which",
    "who",
}
_TRIGGER_DISCOVERY_NO_MATCH_NOTE = (
    "No trigger event matched this use case. Try a more specific integration name "
    "or browse the trigger catalog for available events."
)
_TRIGGER_DISCOVERY_NO_CONFIDENT_MATCH_NOTE = (
    "No confident match for this use case. The closest catalog events are listed in "
    "alternatives, capped by limit_alternatives (raise it to see more); check each "
    "one's integration and description before using it."
)


def _discovery_terms(value: str) -> List[str]:
    terms: List[str] = []
    token = ""
    for char in (value or "").lower():
        if char.isalnum():
            token += char
            continue
        if len(token) > 1 and token not in _DISCOVERY_STOPWORDS:
            terms.append(token)
        token = ""
    if len(token) > 1 and token not in _DISCOVERY_STOPWORDS:
        terms.append(token)

    seen = set()
    deduped: List[str] = []
    for term in terms:
        if term not in seen:
            seen.add(term)
            deduped.append(term)
    return deduped


def _normalize_words(value: Optional[str]) -> str:
    normalized = "".join(
        char if char.isalnum() else " " for char in (value or "").lower()
    )
    return " ".join(normalized.split())


def _named_integrations(
    *,
    terms: List[str],
    integrations: Dict[str, TriggerCatalogIntegration],
) -> Set[str]:
    """Integration slugs the use case names explicitly: a use case that names a platform
    is hard-constrained to it. Equality (not substring) so "dropbox" does not name "box".
    Accepted risk: toolkits named after ordinary words ("linear", "box") restrict any use
    case that mentions the word for another reason.
    """
    term_set = set(terms)
    # Adjacent-term concatenations so "google calendar" names googlecalendar
    # and "one drive" names one_drive.
    joined = {a + b for a, b in zip(terms, terms[1:])}
    named: Set[str] = set()
    for slug, integration in integrations.items():
        key = "".join(c for c in str(integration.key or "").lower() if c.isalnum())
        name = "".join(c for c in str(integration.name or "").lower() if c.isalnum())
        name_words = set(_normalize_words(integration.name).split())
        if (
            key in term_set
            or name in term_set
            or key in joined
            or name in joined
            or (name_words and name_words <= term_set)
        ):
            named.add(slug)
    return named


def _match_signal(
    *,
    use_case: str,
    event: TriggerCatalogEvent,
    integration: TriggerCatalogIntegration,
) -> Tuple[int, int, bool]:
    """Score a candidate plus the evidence behind it.

    Returns ``(score, matched_terms, exact_phrase)`` where ``matched_terms`` is the count of
    distinct use-case terms that hit anywhere in the candidate and ``exact_phrase`` is whether
    the whole use case appears verbatim. Callers gate the primary match on the evidence, not the
    raw score, since one strongly-weighted term can score as high as two weak ones.
    """
    haystack = " ".join(
        str(part or "")
        for part in (
            event.key,
            event.name,
            event.description,
            integration.key,
            integration.name,
            integration.description,
        )
    ).lower()
    needle = (use_case or "").strip().lower()
    exact_phrase = bool(needle and needle in haystack)
    score = 50 if exact_phrase else 0
    matched_terms = 0
    event_key = str(event.key or "").lower()
    integration_key = str(integration.key or "").lower()
    terms = _discovery_terms(use_case)
    for term in terms:
        hit = False
        if term in haystack:
            score += 5
            hit = True
        if term in event_key:
            score += 3
            hit = True
        if term in integration_key:
            score += 2
            hit = True
        if hit:
            matched_terms += 1

    # Adjacency bonus: consecutive CONTENT terms appearing side by side in the event
    # key/name break score ties the paged provider search used to resolve via its own
    # relevance ordering (e.g. "issue created" prefers ISSUE_CREATED over
    # ISSUE_COMMENT_CREATED). Integration-name tokens are excluded before pairing:
    # they prefix every event key of that integration, so a bigram like
    # "slack message" would be a spurious adjacency. Score-only; matched_terms and
    # exact_phrase stay untouched.
    integration_name = str(integration.name or "").lower()
    content_terms = [
        term
        for term in terms
        if term not in integration_key and term not in integration_name
    ]
    normalized_key = _normalize_words(event.key)
    normalized_name = _normalize_words(event.name)
    for first, second in zip(content_terms, content_terms[1:]):
        bigram = f"{first} {second}"
        if bigram in normalized_key or bigram in normalized_name:
            score += 4

    # Deprecated events lose term-level ties to their live replacement. Score-only:
    # matched_terms/exact_phrase untouched, so an exact-phrase ask (+50) can still
    # surface a deprecated event.
    if str(event.description or "").lstrip().lower().startswith("deprecated"):
        score -= 25

    return score, matched_terms, exact_phrase


def _score_trigger_match(
    *,
    use_case: str,
    event: TriggerCatalogEvent,
    integration: TriggerCatalogIntegration,
) -> int:
    return _match_signal(
        use_case=use_case,
        event=event,
        integration=integration,
    )[0]


def _has_primary_evidence(
    *,
    use_case: str,
    event: TriggerCatalogEvent,
    integration: TriggerCatalogIntegration,
) -> bool:
    """Whether a candidate is strong enough to surface as the primary match.

    Requires an exact-phrase hit or at least ``_DISCOVERY_MIN_PRIMARY_TERMS`` distinct matched
    terms, so a single generic term shared with a broad catalog page falls to the no-match path
    instead of promoting an arbitrary integration.
    """
    _score, matched_terms, exact_phrase = _match_signal(
        use_case=use_case,
        event=event,
        integration=integration,
    )
    return exact_phrase or matched_terms >= _DISCOVERY_MIN_PRIMARY_TERMS


class TriggersService:
    """Triggers domain orchestration.

    Covers the read-only events catalog and subscription/delivery CRUD.
    Subscriptions bind a provider event to a workflow on top of a shared gateway
    connection; the provider-side trigger instance (``ti_*``) is minted/managed
    through the adapter, never the catalog routes.
    """

    def __init__(
        self,
        *,
        adapter_registry: TriggersGatewayRegistry,
        catalog_service: CatalogService,
        triggers_dao: TriggersDAOInterface,
        connections_service: ConnectionsService,
        workflows_service: WorkflowsService,
        # Assigned post-construction in the composition root (worker wiring); guarded at use.
        schedule_dispatch_task: Optional[Any] = None,
    ):
        self.adapter_registry = adapter_registry
        self.catalog_service = catalog_service
        self.dao = triggers_dao
        self.connections_service = connections_service
        self.workflows_service = workflows_service
        self.schedule_dispatch_task = schedule_dispatch_task
        self.webhook_secret_resolver = WebhookSecretResolver(
            adapter_registry=adapter_registry,
        )

    # -----------------------------------------------------------------------
    # Catalog browse — providers + integrations come from the SHARED gateway
    # catalog service; this layer narrows them to the triggers subclass DTOs so
    # the router only ever sees triggers-domain types. Events are the
    # triggers-specific leaf (via the triggers adapter).
    # -----------------------------------------------------------------------

    async def list_providers(self) -> List[TriggerCatalogProvider]:
        providers = await self.catalog_service.list_providers()
        return [
            TriggerCatalogProvider.model_validate(p.model_dump()) for p in providers
        ]

    async def get_provider(
        self,
        *,
        provider_key: str,
    ) -> Optional[TriggerCatalogProvider]:
        provider = await self.catalog_service.get_provider(provider_key=provider_key)
        if not provider:
            return None
        return TriggerCatalogProvider.model_validate(provider.model_dump())

    async def list_integrations(
        self,
        *,
        provider_key: str,
        #
        search: Optional[str] = None,
        sort_by: Optional[str] = None,
        limit: Optional[int] = None,
        cursor: Optional[str] = None,
    ) -> TriggerCatalogIntegrationsPage:
        page = await self.catalog_service.list_integrations(
            provider_key=provider_key,
            search=search,
            sort_by=sort_by,
            limit=limit,
            cursor=cursor,
        )
        items = [
            TriggerCatalogIntegration.model_validate(i.model_dump())
            for i in page.integrations
        ]
        return TriggerCatalogIntegrationsPage(
            integrations=items,
            next_cursor=page.next_cursor,
            total=page.total,
        )

    async def get_integration(
        self,
        *,
        provider_key: str,
        integration_key: str,
    ) -> Optional[TriggerCatalogIntegration]:
        integration = await self.catalog_service.get_integration(
            provider_key=provider_key,
            integration_key=integration_key,
        )
        if not integration:
            return None
        return TriggerCatalogIntegration.model_validate(integration.model_dump())

    async def list_events(
        self,
        *,
        provider_key: str,
        integration_key: str,
        #
        query: Optional[str] = None,
        limit: Optional[int] = None,
        cursor: Optional[str] = None,
    ) -> TriggerCatalogEventsPage:
        """List events for an integration with optional search and pagination."""
        adapter = self.adapter_registry.get(provider_key)
        return await adapter.list_events(
            integration_key=integration_key,
            query=query,
            limit=limit,
            cursor=cursor,
        )

    async def get_event(
        self,
        *,
        provider_key: str,
        integration_key: str,
        event_key: str,
    ) -> Optional[TriggerCatalogEventDetails]:
        """Return full event detail including its trigger_config schema, or None."""
        adapter = self.adapter_registry.get(provider_key)
        return await adapter.get_event(
            integration_key=integration_key,
            event_key=event_key,
        )

    async def discover_triggers(
        self,
        *,
        project_id: UUID,
        use_cases: List[str],
        provider_key: str = TriggerProviderKind.COMPOSIO.value,
        limit_alternatives: int = 3,
    ) -> TriggerCapabilitiesResult:
        """Keyword event discovery joined with the project's connection state."""
        capabilities: List[TriggerCapability] = []
        states: Dict[str, TriggerConnectionRequirement] = {}
        state_order: List[str] = []

        snapshot = await self._cached_event_catalog(provider_key=provider_key)

        for use_case in use_cases:
            matches = self._discover_events_for_use_case(
                use_case=use_case,
                snapshot=snapshot,
            )
            surfaced = matches[: 1 + max(limit_alternatives, 0)]

            # Require stronger evidence before promoting a candidate to the primary match:
            # if the top candidate is only a weak/ambiguous hit, fall to the no-match path
            # instead of surfacing an arbitrary integration as the best match.
            if surfaced and not _has_primary_evidence(
                use_case=use_case,
                event=surfaced[0][1],
                integration=surfaced[0][2],
            ):
                surfaced = []

            if not surfaced:
                # Still hand the agent the closest scored events so a weak or
                # browse-shaped ask gets something actionable; alternatives carry
                # no connection info, so no state lookups here.
                alternatives = [
                    DiscoveredTriggerAlternative(
                        integration=alt_event.integration or alt_integration.key,
                        event_key=alt_event.key,
                        description=alt_event.description,
                        provider_event=alt_event.key,
                    )
                    for _alt_score, alt_event, alt_integration in matches[
                        : max(limit_alternatives, 0)
                    ]
                ]
                capabilities.append(
                    TriggerCapability(
                        use_case=use_case,
                        alternatives=alternatives,
                        note=(
                            _TRIGGER_DISCOVERY_NO_CONFIDENT_MATCH_NOTE
                            if alternatives
                            else _TRIGGER_DISCOVERY_NO_MATCH_NOTE
                        ),
                    )
                )
                continue

            for _score, event, integration in surfaced:
                key = event.integration or integration.key
                if key not in states:
                    states[key] = await self._trigger_discovery_connection_state(
                        project_id=project_id,
                        provider_key=provider_key,
                        integration_key=key,
                    )
                    state_order.append(key)

            _score, event, integration = surfaced[0]
            integration_key = event.integration or integration.key
            # Catalog snapshot items already carry trigger_config/payload — no live call.
            detailed_event = (
                event
                if isinstance(event, TriggerCatalogEventDetails)
                else TriggerCatalogEventDetails(**event.model_dump())
            )
            requirement = states.get(integration_key)
            connection = None
            if requirement is not None:
                connection = TriggerCapabilityConnection(
                    state=requirement.state,
                    id=(
                        requirement.id
                        if requirement.state == TriggerDiscoveryConnectionState.READY
                        else None
                    ),
                    slug=(
                        requirement.slug
                        if requirement.state == TriggerDiscoveryConnectionState.READY
                        else None
                    ),
                )

            capabilities.append(
                TriggerCapability(
                    use_case=use_case,
                    integration=integration_key,
                    event=DiscoveredTriggerEvent(
                        provider=detailed_event.provider or provider_key,
                        integration=integration_key,
                        event_key=detailed_event.key,
                        trigger_config=detailed_event.trigger_config,
                        payload=detailed_event.payload,
                        description=detailed_event.description,
                        provider_event=detailed_event.key,
                    ),
                    alternatives=[
                        DiscoveredTriggerAlternative(
                            integration=alt_event.integration or alt_integration.key,
                            event_key=alt_event.key,
                            description=alt_event.description,
                            provider_event=alt_event.key,
                        )
                        for _alt_score, alt_event, alt_integration in surfaced[1:]
                    ],
                    connection=connection,
                )
            )

        ready = bool(capabilities) and all(
            capability.event is not None
            and capability.connection is not None
            and capability.connection.state == TriggerDiscoveryConnectionState.READY
            for capability in capabilities
        )
        notes = [
            capability.note
            for capability in capabilities
            if capability.note is not None
        ]

        return TriggerCapabilitiesResult(
            capabilities=capabilities,
            connections=[states[key] for key in state_order],
            guidance=TriggerDiscoveryGuidance(
                plan_steps=[
                    "Use the returned event_key and trigger_config to build a "
                    "create_subscription request after the connection is ready.",
                    "Map event payload fields into inputs_fields before going live.",
                ],
                pitfalls=[
                    "A ready connection id is required before creating or live-testing "
                    "a subscription.",
                    "Catalog payloads are samples; verify provider-specific fields "
                    "before relying on them in inputs_fields.",
                ],
            ),
            ready=ready,
            notes=notes,
        )

    async def _cached_event_catalog(
        self,
        *,
        provider_key: str,
    ) -> TriggerCatalogEventsSnapshot:
        # Provider-only key: the catalog is identical for every project, so the
        # cache is project-agnostic on purpose (mirrors the tools-discovery cache).
        cache_key = {"provider": provider_key}
        cached = await get_cache(
            namespace=_CATALOG_CACHE_NAMESPACE,
            key=cache_key,
            model=TriggerCatalogEventsSnapshot,
        )
        if cached is not None:
            return cached

        adapter = self.adapter_registry.get(provider_key)
        try:
            snapshot = await asyncio.wait_for(
                adapter.list_all_events(),
                timeout=env.composio.catalog_fetch_deadline_seconds,
            )
        except asyncio.TimeoutError as e:
            raise AdapterError(
                provider_key=provider_key,
                operation="list_all_events",
                detail="catalog fetch deadline exceeded",
            ) from e

        await set_cache(
            namespace=_CATALOG_CACHE_NAMESPACE,
            key=cache_key,
            value=snapshot,
            ttl=env.composio.catalog_cache_ttl_seconds,
        )
        return snapshot

    @staticmethod
    def _discover_events_for_use_case(
        *,
        use_case: str,
        snapshot: TriggerCatalogEventsSnapshot,
    ) -> List[Tuple[int, TriggerCatalogEvent, TriggerCatalogIntegration]]:
        integrations: Dict[str, TriggerCatalogIntegration] = {}
        matches: List[Tuple[int, TriggerCatalogEvent, TriggerCatalogIntegration]] = []
        seen = set()

        for event in snapshot.events:
            slug = event.integration or ""
            key = (slug, event.key)
            if key in seen:
                continue
            seen.add(key)
            integration = integrations.get(slug)
            if integration is None:
                integration = TriggerCatalogIntegration(
                    key=slug,
                    name=snapshot.integration_names.get(slug, slug),
                )
                integrations[slug] = integration
            score = _score_trigger_match(
                use_case=use_case,
                event=event,
                integration=integration,
            )
            if score <= 0:
                continue
            matches.append((score, event, integration))

        # An event from the wrong platform is unusable no matter how well its words
        # match ("discord message received" must never surface Slack).
        named = _named_integrations(
            terms=_discovery_terms(use_case),
            integrations=integrations,
        )
        if named:
            matches = [
                match for match in matches if (match[1].integration or "") in named
            ]

        return sorted(matches, key=lambda item: item[0], reverse=True)

    async def _trigger_discovery_connection_state(
        self,
        *,
        project_id: UUID,
        provider_key: str,
        integration_key: str,
    ) -> TriggerConnectionRequirement:
        connections = await self.query_connections(
            project_id=project_id,
            provider_key=provider_key,
            integration_key=integration_key,
            is_active=None,
        )
        ready = next(
            (
                connection
                for connection in connections
                if connection.is_active
                and connection.is_valid
                and (connection.provider_connection_id or not connection.has_auth)
            ),
            None,
        )
        if ready is not None:
            return TriggerConnectionRequirement(
                integration=integration_key,
                state=TriggerDiscoveryConnectionState.READY,
                id=ready.id,
                slug=ready.slug,
            )

        state = await self._trigger_connection_auth_state(
            provider_key=provider_key,
            integration_key=integration_key,
        )
        existing_slugs = {
            connection.slug for connection in connections if connection.slug
        }
        connect_slug = f"{integration_key}-main"
        suffix = 2
        while connect_slug in existing_slugs:
            connect_slug = f"{integration_key}-main-{suffix}"
            suffix += 1

        return TriggerConnectionRequirement(
            integration=integration_key,
            state=state,
            connect=TriggerConnectAffordance(
                body={
                    "connection": {
                        "provider_key": provider_key,
                        "integration_key": integration_key,
                        "slug": connect_slug,
                    }
                }
            ),
        )

    async def _trigger_connection_auth_state(
        self,
        *,
        provider_key: str,
        integration_key: str,
    ) -> TriggerDiscoveryConnectionState:
        integration = await self.get_integration(
            provider_key=provider_key,
            integration_key=integration_key,
        )
        schemes = {
            scheme.value if hasattr(scheme, "value") else str(scheme)
            for scheme in (integration.auth_schemes if integration else []) or []
        }
        if "api_key" in schemes and "oauth" not in schemes:
            return TriggerDiscoveryConnectionState.NEEDS_INPUT
        return TriggerDiscoveryConnectionState.NEEDS_AUTH

    # -----------------------------------------------------------------------
    # Connections — shared `gateway_connections` rows via the shared
    # ConnectionsService; narrowed to the triggers subclass so the router only
    # ever sees triggers-domain types. Independent surface from tools; both
    # operate over the same rows.
    # -----------------------------------------------------------------------

    @staticmethod
    def _as_trigger_connection(conn) -> Optional[TriggerConnection]:
        return TriggerConnection.model_validate(conn.model_dump()) if conn else None

    async def query_connections(
        self,
        *,
        project_id: UUID,
        provider_key: Optional[str] = None,
        integration_key: Optional[str] = None,
        is_active: Optional[bool] = True,
    ) -> List[TriggerConnection]:
        conns = await self.connections_service.query_connections(
            project_id=project_id,
            provider_key=provider_key,
            integration_key=integration_key,
            is_active=is_active,
        )
        return [TriggerConnection.model_validate(c.model_dump()) for c in conns]

    async def get_connection(
        self,
        *,
        project_id: UUID,
        connection_id: UUID,
    ) -> Optional[TriggerConnection]:
        conn = await self.connections_service.get_connection(
            project_id=project_id,
            connection_id=connection_id,
        )
        return self._as_trigger_connection(conn)

    async def create_connection(
        self,
        *,
        project_id: UUID,
        user_id: UUID,
        #
        connection_create: TriggerConnectionCreate,
    ) -> TriggerConnection:
        conn = await self.connections_service.initiate_connection(
            project_id=project_id,
            user_id=user_id,
            #
            connection_create=connection_create,
        )
        return TriggerConnection.model_validate(conn.model_dump())

    async def delete_connection(
        self,
        *,
        project_id: UUID,
        connection_id: UUID,
    ) -> bool:
        return await self.connections_service.delete_connection(
            project_id=project_id,
            connection_id=connection_id,
        )

    async def refresh_connection(
        self,
        *,
        project_id: UUID,
        connection_id: UUID,
        #
        force: bool = False,
    ) -> TriggerConnection:
        conn = await self.connections_service.refresh_connection(
            project_id=project_id,
            connection_id=connection_id,
            force=force,
        )
        return TriggerConnection.model_validate(conn.model_dump())

    async def revoke_connection(
        self,
        *,
        project_id: UUID,
        connection_id: UUID,
    ) -> TriggerConnection:
        conn = await self.connections_service.revoke_connection(
            project_id=project_id,
            connection_id=connection_id,
        )
        return TriggerConnection.model_validate(conn.model_dump())

    # -----------------------------------------------------------------------
    # Subscriptions
    # -----------------------------------------------------------------------

    async def _require_connection(
        self,
        *,
        project_id: UUID,
        connection_id: UUID,
    ):
        connection = await self.connections_service.get_connection(
            project_id=project_id,
            connection_id=connection_id,
        )
        if not connection:
            raise ConnectionNotFoundError(connection_id=str(connection_id))
        return connection

    async def _validate_references(
        self,
        *,
        project_id: UUID,
        references: Optional[dict],
    ) -> None:
        """Assert the bound reference family resolves — without pinning it.

        The FE sends a partial family under the proper prefix (``application`` /
        ``evaluator``, or ``environment`` + ``application``). We delegate to
        ``WorkflowsService.retrieve_workflow_revision`` to confirm it currently
        resolves to a runnable revision (the graceful-failure guarantee), but we
        deliberately do NOT overwrite the stored references with the resolved
        revision: an environment slug, or an artifact/variant without a revision,
        means "resolve latest at trigger time." Persisting the resolved revision
        here would freeze that binding at save time. The dispatcher re-resolves
        from the raw references on every fire (``invoke_workflow`` ->
        ``_ensure_request_revision``), so latest-tracking is preserved.
        """
        if not references or not self.workflows_service:
            return

        def _ref(value):
            if value is None:
                return None
            return value if isinstance(value, Reference) else Reference(**dict(value))

        prefix = next(
            (
                p
                for p in ("application", "evaluator", "workflow")
                if any(references.get(k) for k in (p, f"{p}_variant", f"{p}_revision"))
            ),
            None,
        )
        environment_ref = _ref(references.get("environment"))
        if prefix is None and environment_ref is None:
            return

        key = None
        if environment_ref is not None:
            artifact = _ref(references.get("application") or references.get("workflow"))
            artifact_slug = getattr(artifact, "slug", None)
            key = f"{artifact_slug}.revision" if artifact_slug else None

        revision, _, _ = await self.workflows_service.retrieve_workflow_revision(
            project_id=project_id,
            environment_ref=environment_ref,
            key=key,
            workflow_ref=_ref(references.get(prefix)) if prefix else None,
            workflow_variant_ref=(
                _ref(references.get(f"{prefix}_variant")) if prefix else None
            ),
            workflow_revision_ref=(
                _ref(references.get(f"{prefix}_revision")) if prefix else None
            ),
        )
        if revision is None:
            raise TriggerReferenceInvalid(
                "Bound workflow reference could not be resolved to a runnable revision."
            )

    async def create_subscription(
        self,
        *,
        project_id: UUID,
        user_id: UUID,
        #
        subscription: TriggerSubscriptionCreate,
    ) -> TriggerSubscription:
        """Mint the provider-side ``ti_*`` on a shared connection, then persist."""
        # A test subscription captures events without a bound workflow, so the
        # reference requirement is relaxed; it is also always "on".
        if subscription.flags.is_test:
            subscription.flags.is_active = True
        else:
            await self._validate_references(
                project_id=project_id,
                references=subscription.data.references,
            )

        connection = await self._require_connection(
            project_id=project_id,
            connection_id=subscription.connection_id,
        )

        # The provider call below is an upsert, so a duplicate create would silently
        # rewrite the live trigger's config before the unique index rejects the row.
        # Conflict on (connection, event) locally first to keep the provider untouched.
        existing = await self.dao.query_subscriptions(
            project_id=project_id,
            subscription=TriggerSubscriptionQuery(
                connection_id=subscription.connection_id,
                event_key=subscription.data.event_key,
            ),
            windowing=Windowing(limit=1),
        )
        if existing:
            raise EntityCreationConflict(
                entity="Trigger subscription",
                message="A subscription for this connection and event already exists.",
                conflict={
                    "subscription_id": str(existing[0].id),
                    "trigger_id": existing[0].trigger_id,
                },
            )

        adapter = self.adapter_registry.get(connection.provider_key.value)

        trigger_id = await adapter.create_subscription(
            project_id=project_id,
            event_key=subscription.data.event_key,
            connected_account_id=connection.provider_connection_id,
            trigger_config=subscription.data.trigger_config or {},
        )

        return await self.dao.create_subscription(
            project_id=project_id,
            user_id=user_id,
            #
            subscription=subscription,
            #
            trigger_id=trigger_id,
        )

    async def fetch_subscription(
        self,
        *,
        project_id: UUID,
        #
        subscription_id: UUID,
    ) -> Optional[TriggerSubscription]:
        return await self.dao.fetch_subscription(
            project_id=project_id,
            subscription_id=subscription_id,
        )

    async def fetch_subscription_including_deleted(
        self,
        *,
        project_id: UUID,
        #
        subscription_id: UUID,
    ) -> Optional[TriggerSubscription]:
        return await self.dao.fetch_subscription_including_deleted(
            project_id=project_id,
            subscription_id=subscription_id,
        )

    async def query_subscriptions(
        self,
        *,
        project_id: UUID,
        #
        subscription: Optional[TriggerSubscriptionQuery] = None,
        #
        windowing: Optional[Windowing] = None,
    ) -> List[TriggerSubscription]:
        return await self.dao.query_subscriptions(
            project_id=project_id,
            subscription=subscription,
            windowing=windowing,
        )

    async def _sync_provider_enabled(
        self,
        *,
        project_id: UUID,
        subscription: TriggerSubscription,
        is_active: bool,
        is_valid: bool,
    ) -> None:
        """Reflect the combined desired state onto the provider ``ti_*``.

        The provider trigger should only fire when the subscription is BOTH
        locally active and provider-valid, so ``enabled = is_active and is_valid``.
        Single source of truth for edit/start/stop/refresh/revoke so they can't
        disagree and re-enable a revoked/paused trigger.
        """
        trigger_id = subscription.trigger_id
        if trigger_id is None:
            return
        connection = await self._require_connection(
            project_id=project_id,
            connection_id=subscription.connection_id,
        )
        adapter = self.adapter_registry.get(connection.provider_key.value)
        await adapter.set_subscription_status(
            trigger_id=trigger_id,
            enabled=is_active and is_valid,
        )

    async def edit_subscription(
        self,
        *,
        project_id: UUID,
        user_id: UUID,
        #
        subscription: TriggerSubscriptionEdit,
    ) -> Optional[TriggerSubscription]:
        """Full-PUT edit. Reflects the combined is_active/is_valid onto ``ti_*``."""
        existing = await self.dao.fetch_subscription(
            project_id=project_id,
            subscription_id=subscription.id,
        )
        if existing is None:
            return None

        # Test subscriptions skip the bound-workflow requirement and stay "on".
        # Turning test OFF (test → prod) re-imposes it: references must resolve,
        # else the edit is rejected and the user must supply a valid binding.
        if subscription.flags.is_test:
            subscription.flags.is_active = True
        else:
            await self._validate_references(
                project_id=project_id,
                references=subscription.data.references,
            )

        if subscription.flags.is_active != existing.flags.is_active:
            await self._sync_provider_enabled(
                project_id=project_id,
                subscription=existing,
                is_active=subscription.flags.is_active,
                is_valid=existing.flags.is_valid,
            )

        return await self.dao.edit_subscription(
            project_id=project_id,
            user_id=user_id,
            subscription=subscription,
        )

    async def delete_subscription(
        self,
        *,
        project_id: UUID,
        user_id: UUID,
        #
        subscription_id: UUID,
    ) -> bool:
        """Soft-delete the local row first, then best-effort delete the provider ``ti_*``.

        Local state must land before the provider call: a degraded provider (a
        rotated key, a timeout, a 5xx) must never leave a user unable to delete a
        firing automation (P0-2) — mirrors `delete_connection`'s existing
        tolerance in the connections domain. A provider failure is logged and
        recorded as a `needs_provider_cleanup` marker for reconciliation instead
        of raised.

        Deleting a subscription must NOT revoke the shared connection (C7): the
        provider call targets only the trigger instance, never the ``ca_*``.
        """
        existing = await self.dao.fetch_subscription(
            project_id=project_id,
            subscription_id=subscription_id,
        )
        if existing is None:
            return False

        deleted = await self.dao.delete_subscription(
            project_id=project_id,
            user_id=user_id,
            subscription_id=subscription_id,
        )

        try:
            await self._delete_provider_subscription(
                project_id=project_id,
                subscription=existing,
            )
        except Exception as e:  # pylint: disable=broad-exception-caught
            log.warning(
                "Failed to delete provider trigger for subscription %s, "
                "local delete already applied: %s",
                subscription_id,
                e,
            )
            await self.dao.mark_subscription_needs_provider_cleanup(
                project_id=project_id,
                subscription_id=subscription_id,
            )

        return deleted

    async def _delete_provider_subscription(
        self,
        *,
        project_id: UUID,
        subscription: TriggerSubscription,
    ) -> None:
        trigger_id = subscription.trigger_id
        if trigger_id is None:
            return
        # The provider delete needs only `trigger_id` — look up the connection just
        # for its provider_key, and fall back to the default provider when the
        # connection row is already gone (P2-5: a soft-deleted subscription whose
        # connection was deleted must still attempt cleanup, or the upstream
        # `ti_*` fires into a 200-ACK void forever).
        connection = await self.connections_service.get_connection(
            project_id=project_id,
            connection_id=subscription.connection_id,
        )
        provider_key = (
            connection.provider_key.value
            if connection is not None
            else TriggerProviderKind.COMPOSIO.value
        )
        adapter = self.adapter_registry.get(provider_key)
        await adapter.delete_subscription(trigger_id=trigger_id)

    async def cleanup_test_subscription(
        self,
        *,
        project_id: UUID,
        subscription_id: UUID,
    ) -> bool:
        """Remove a temporary provider trigger and physically purge its local history."""
        existing = await self.dao.fetch_subscription(
            project_id=project_id,
            subscription_id=subscription_id,
        )
        if existing is None:
            return False

        if not existing.flags.is_test:
            # This is a physical, unrecoverable purge — refuse anything that
            # isn't a short-lived test subscription so a wrong subscription_id
            # can't destroy real automation history.
            raise ValueError("cleanup_test_subscription only purges test subscriptions")

        await self._delete_provider_subscription(
            project_id=project_id,
            subscription=existing,
        )
        return await self.dao.purge_subscription(
            project_id=project_id,
            subscription_id=subscription_id,
        )

    async def refresh_subscription(
        self,
        *,
        project_id: UUID,
        user_id: UUID,
        #
        subscription_id: UUID,
    ) -> TriggerSubscription:
        """Re-sync the provider ``ti_*`` and mark the row valid."""
        return await self._set_valid(
            project_id=project_id,
            user_id=user_id,
            subscription_id=subscription_id,
            is_valid=True,
        )

    async def revoke_subscription(
        self,
        *,
        project_id: UUID,
        user_id: UUID,
        #
        subscription_id: UUID,
    ) -> TriggerSubscription:
        """Disable the provider ``ti_*`` and mark the row invalid.

        Drives the third-party-sync axis (``is_valid``); the user's local
        play/pause (``is_active``) is left untouched, as is the shared
        connection (C7).
        """
        return await self._set_valid(
            project_id=project_id,
            user_id=user_id,
            subscription_id=subscription_id,
            is_valid=False,
        )

    async def set_subscription_active(
        self,
        *,
        project_id: UUID,
        user_id: UUID,
        #
        subscription_id: UUID,
        is_active: bool,
    ) -> TriggerSubscription:
        """Full-PUT play/pause toggle; touches only local is_active (never is_valid).

        Distinct from /revoke, which drives the provider ti_* / is_valid axis.

        Stopping (``is_active=False``) writes local state first, then attempts the
        provider sync best-effort: a degraded provider must never block a user
        from stopping a firing automation (P0-2), mirroring `delete_subscription`.
        Starting keeps the provider-first order — the enable call must actually
        succeed before the subscription can be trusted to run again.
        """
        existing = await self.dao.fetch_subscription(
            project_id=project_id,
            subscription_id=subscription_id,
        )
        if existing is None:
            raise SubscriptionNotFoundError(subscription_id=str(subscription_id))

        edit = TriggerSubscriptionEdit(
            id=existing.id,
            connection_id=existing.connection_id,
            name=existing.name,
            description=existing.description,
            tags=existing.tags,
            meta=existing.meta,
            data=existing.data,
            flags=existing.flags.model_copy(update={"is_active": is_active}),
        )

        if is_active:
            await self._sync_provider_enabled(
                project_id=project_id,
                subscription=existing,
                is_active=is_active,
                is_valid=existing.flags.is_valid,
            )
            updated = await self.dao.edit_subscription(
                project_id=project_id,
                user_id=user_id,
                subscription=edit,
            )
        else:
            updated = await self.dao.edit_subscription(
                project_id=project_id,
                user_id=user_id,
                subscription=edit,
            )
            try:
                await self._sync_provider_enabled(
                    project_id=project_id,
                    subscription=existing,
                    is_active=is_active,
                    is_valid=existing.flags.is_valid,
                )
            except Exception as e:  # pylint: disable=broad-exception-caught
                log.warning(
                    "Failed to sync provider disable for subscription %s, "
                    "local stop already applied: %s",
                    subscription_id,
                    e,
                )
                await self.dao.mark_subscription_needs_provider_cleanup(
                    project_id=project_id,
                    subscription_id=subscription_id,
                )
        if updated is None:
            raise SubscriptionNotFoundError(subscription_id=str(subscription_id))
        return updated

    async def test_subscription(
        self,
        *,
        project_id: UUID,
        user_id: UUID,
        #
        subscription: TriggerSubscriptionCreate,
    ) -> Optional[TriggerDelivery]:
        """One-shot test: capture the first delivery for this (connection, event),
        then tear down.

        Normally mints a short-lived test subscription and deletes it (including on
        timeout and on any error). If a live subscription already owns the provider
        trigger (the partial-unique index forbids a duplicate active row), capture
        against that existing subscription instead and leave it in place.
        """
        subscription.flags.is_test = True

        owns_created = True
        try:
            created = await self.create_subscription(
                project_id=project_id,
                user_id=user_id,
                subscription=subscription,
            )
        except EntityCreationConflict as err:
            # Capture against the exact colliding subscription (project-scoped, non-deleted),
            # not a fuzzy connection+event match that could land on a stale or inactive row.
            trigger_id = (err.conflict or {}).get("trigger_id")
            existing = (
                await self.dao.fetch_subscription_by_trigger_id(
                    project_id=project_id,
                    trigger_id=trigger_id,
                )
                if trigger_id
                else None
            )
            if existing is None:
                raise
            created = existing
            owns_created = False

        # A reused live subscription may already carry past deliveries; capture only
        # a delivery newer than the current latest. A freshly minted test
        # subscription has none, so no baseline is taken and the first delivery wins.
        baseline_id = None
        if not owns_created:
            baseline = await self.dao.query_deliveries(
                project_id=project_id,
                delivery=TriggerDeliveryQuery(subscription_id=created.id),
                windowing=Windowing(limit=1),
            )
            baseline_id = baseline[0].id if baseline else None

        try:
            return await self.dao.poll_delivery_after(
                project_id=project_id,
                subscription_id=created.id,
                baseline_id=baseline_id,
                timeout_seconds=_TEST_TIMEOUT_SECONDS,
            )
        finally:
            if owns_created:
                # A transient provider failure during teardown must not mask a
                # captured result (or a real error from the `try` block) with an
                # unrelated AdapterError raised from `finally`.
                try:
                    await self.cleanup_test_subscription(
                        project_id=project_id,
                        subscription_id=created.id,
                    )
                except AdapterError as e:
                    log.warning(
                        "Failed to clean up test subscription %s: %s",
                        created.id,
                        e,
                    )

    async def _set_valid(
        self,
        *,
        project_id: UUID,
        user_id: UUID,
        subscription_id: UUID,
        is_valid: bool,
    ) -> TriggerSubscription:
        existing = await self.dao.fetch_subscription(
            project_id=project_id,
            subscription_id=subscription_id,
        )
        if existing is None:
            raise SubscriptionNotFoundError(subscription_id=str(subscription_id))

        await self._sync_provider_enabled(
            project_id=project_id,
            subscription=existing,
            is_active=existing.flags.is_active,
            is_valid=is_valid,
        )

        edit = TriggerSubscriptionEdit(
            id=existing.id,
            connection_id=existing.connection_id,
            name=existing.name,
            description=existing.description,
            tags=existing.tags,
            meta=existing.meta,
            data=existing.data,
            flags=existing.flags.model_copy(update={"is_valid": is_valid}),
        )

        updated = await self.dao.edit_subscription(
            project_id=project_id,
            user_id=user_id,
            subscription=edit,
        )
        if updated is None:
            raise SubscriptionNotFoundError(subscription_id=str(subscription_id))
        return updated

    # -----------------------------------------------------------------------
    # Schedules
    # -----------------------------------------------------------------------

    @staticmethod
    def _validate_schedule(expr: str) -> None:
        """Reject anything that is not a valid 5-field cron expression (UTC), or
        that fires more often than ``env.triggers.schedule_min_interval_minutes``."""
        if not isinstance(expr, str) or len(expr.split()) != 5:
            raise TriggerScheduleInvalid(
                schedule=expr if isinstance(expr, str) else None,
                reason="not a 5-field cron expression",
            )
        if not croniter.is_valid(expr):
            raise TriggerScheduleInvalid(
                schedule=expr,
                reason="cron expression is not parseable",
            )

        floor = env.triggers.schedule_min_interval_minutes
        gap = TriggersService._smallest_gap_minutes(expr, stop_below=floor)
        if gap is not None and gap < floor:
            raise TriggerScheduleInvalid(
                f"Schedule may run at most once every {floor} minutes, "
                f"but this one runs every {TriggersService._humanize_gap(gap)}.",
                schedule=expr,
                reason=f"fires every {TriggersService._humanize_gap(gap)}, "
                f"below the {floor}-minute minimum",
            )

    # A cron's tightest gap always appears within two days of its FIRST fire: a
    # sub-daily gap needs a multi-valued minute or hour field, and those repeat on
    # every day the day-fields admit. Anchoring on the first fire rather than on the
    # scan's base keeps that true for day-restricted expressions such as
    # "0,1 0 31 1 *", whose only fires sit a month out.
    _SCHEDULE_SCAN_WINDOW_MINUTES = 2 * 24 * 60
    # Backstop against a pathological expression. Two days of every-minute fires is
    # 2880 samples, and the loop exits early the moment it finds a violating gap.
    _SCHEDULE_SCAN_MAX_SAMPLES = 5000

    @staticmethod
    def _smallest_gap_minutes(expr: str, *, stop_below: int) -> Optional[float]:
        """Smallest gap in minutes between two consecutive fires of ``expr``.

        Returns ``None`` when the expression fires at most once inside the scan
        window, which means it is sparser than the window and clears any floor.
        Stops as soon as a gap below ``stop_below`` is found, so a runaway
        expression costs two samples rather than the full window.
        """
        try:
            iterator = croniter(expr, datetime(2024, 1, 1, tzinfo=timezone.utc))
            previous = iterator.get_next(datetime)
        except Exception:  # pylint: disable=broad-exception-caught
            # croniter validated the expression above; a date it cannot resolve
            # (e.g. "0 0 30 2 *") never fires, so there is no cadence to police.
            return None

        horizon = previous + timedelta(
            minutes=TriggersService._SCHEDULE_SCAN_WINDOW_MINUTES
        )
        smallest: Optional[float] = None

        for _ in range(TriggersService._SCHEDULE_SCAN_MAX_SAMPLES):
            try:
                current = iterator.get_next(datetime)
            except Exception:  # pylint: disable=broad-exception-caught
                break
            if current > horizon:
                break
            gap = (current - previous).total_seconds() / 60
            smallest = gap if smallest is None else min(smallest, gap)
            if smallest < stop_below:
                break
            previous = current

        return smallest

    @staticmethod
    def _humanize_gap(minutes: float) -> str:
        """Render a gap for an error message: "1 minute", "5 minutes", "2 hours"."""
        if minutes >= 60 and minutes % 60 == 0:
            hours = int(minutes // 60)
            return f"{hours} hour" if hours == 1 else f"{hours} hours"
        rounded = int(minutes) if float(minutes).is_integer() else round(minutes, 1)
        return f"{rounded} minute" if rounded == 1 else f"{rounded} minutes"

    @staticmethod
    def _align_to_minute_utc(dt: Optional[datetime]) -> Optional[datetime]:
        if dt is None:
            return None
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt.astimezone(timezone.utc).replace(second=0, microsecond=0)

    @classmethod
    def _normalize_window(cls, data: TriggerScheduleData) -> None:
        data.start_time = cls._align_to_minute_utc(data.start_time)
        data.end_time = cls._align_to_minute_utc(data.end_time)
        if (
            data.start_time is not None
            and data.end_time is not None
            and data.end_time <= data.start_time
        ):
            raise TriggerScheduleInvalid(
                message="Schedule end_time must be after start_time.",
                schedule=data.schedule,
                reason="empty window",
            )

    async def create_schedule(
        self,
        *,
        project_id: UUID,
        user_id: UUID,
        #
        schedule: TriggerScheduleCreate,
    ) -> TriggerSchedule:
        self._validate_schedule(schedule.data.schedule)
        self._normalize_window(schedule.data)

        await self._validate_references(
            project_id=project_id,
            references=schedule.data.references,
        )

        return await self.dao.create_schedule(
            project_id=project_id,
            user_id=user_id,
            #
            schedule=schedule,
        )

    async def fetch_schedule(
        self,
        *,
        project_id: UUID,
        #
        schedule_id: UUID,
    ) -> Optional[TriggerSchedule]:
        return await self.dao.fetch_schedule(
            project_id=project_id,
            schedule_id=schedule_id,
        )

    async def fetch_schedule_including_deleted(
        self,
        *,
        project_id: UUID,
        #
        schedule_id: UUID,
    ) -> Optional[TriggerSchedule]:
        return await self.dao.fetch_schedule_including_deleted(
            project_id=project_id,
            schedule_id=schedule_id,
        )

    async def query_schedules(
        self,
        *,
        project_id: UUID,
        #
        schedule: Optional[TriggerScheduleQuery] = None,
        #
        windowing: Optional[Windowing] = None,
    ) -> List[TriggerSchedule]:
        return await self.dao.query_schedules(
            project_id=project_id,
            schedule=schedule,
            windowing=windowing,
        )

    async def edit_schedule(
        self,
        *,
        project_id: UUID,
        user_id: UUID,
        #
        schedule: TriggerScheduleEdit,
    ) -> Optional[TriggerSchedule]:
        """Full-PUT edit (load the current row, override owned fields)."""
        existing = await self.dao.fetch_schedule(
            project_id=project_id,
            schedule_id=schedule.id,
        )
        if existing is None:
            return None

        self._validate_schedule(schedule.data.schedule)
        self._normalize_window(schedule.data)

        await self._validate_references(
            project_id=project_id,
            references=schedule.data.references,
        )

        return await self.dao.edit_schedule(
            project_id=project_id,
            user_id=user_id,
            schedule=schedule,
        )

    async def delete_schedule(
        self,
        *,
        project_id: UUID,
        user_id: UUID,
        #
        schedule_id: UUID,
    ) -> bool:
        return await self.dao.delete_schedule(
            project_id=project_id,
            user_id=user_id,
            schedule_id=schedule_id,
        )

    async def set_schedule_active(
        self,
        *,
        project_id: UUID,
        user_id: UUID,
        #
        schedule_id: UUID,
        is_active: bool,
    ) -> TriggerSchedule:
        """Full-PUT play/pause toggle; touches only flags.is_active."""
        existing = await self.dao.fetch_schedule(
            project_id=project_id,
            schedule_id=schedule_id,
        )
        if existing is None:
            raise ScheduleNotFoundError(schedule_id=str(schedule_id))

        end = existing.data.end_time
        if is_active and end is not None and datetime.now(timezone.utc) >= end:
            raise TriggerScheduleInvalid(
                message="Cannot start a schedule whose end_time has passed.",
                schedule=existing.data.schedule,
                reason="window ended",
            )

        edit = TriggerScheduleEdit(
            id=existing.id,
            name=existing.name,
            description=existing.description,
            tags=existing.tags,
            meta=existing.meta,
            data=existing.data,
            flags=existing.flags.model_copy(update={"is_active": is_active}),
        )

        updated = await self.dao.edit_schedule(
            project_id=project_id,
            user_id=user_id,
            schedule=edit,
        )
        if updated is None:
            raise ScheduleNotFoundError(schedule_id=str(schedule_id))
        return updated

    async def refresh_schedules(
        self,
        *,
        timestamp: datetime,
        interval: int,
    ) -> bool:
        """Fire every active schedule whose cron matches this tick.

        Mirrors live-eval ``refresh_runs``: point-in-time ``croniter.match`` gate,
        deterministic ``event_id`` per (schedule, tick) for dedup, enqueue onto the
        schedule dispatch task.
        """
        log.info(
            f"[SCHEDULE] Refreshing schedules at {timestamp} every {interval} minute(s)"
        )

        if not timestamp:
            return False

        try:
            schedules = await self.dao.fetch_active_schedules_with_project()
        except Exception as e:  # pylint: disable=broad-exception-caught
            log.error(f"[SCHEDULE] Error fetching active schedules: {e}", exc_info=True)
            return False

        if self.schedule_dispatch_task is None:
            log.warning(
                "[SCHEDULE] Taskiq client is not configured; skipping schedule dispatch"
            )
            return False

        failures = 0
        for project_id, schedule in schedules:
            try:
                end = schedule.data.end_time
                if end is not None and timestamp >= end:
                    await self.set_schedule_active(
                        project_id=project_id,
                        user_id=schedule.created_by_id,
                        schedule_id=schedule.id,
                        is_active=False,
                    )
                    continue

                start = schedule.data.start_time
                if start is not None and timestamp < start:
                    continue

                if not croniter.match(schedule.data.schedule, timestamp):
                    continue

                event_id = f"{schedule.id}:{timestamp.isoformat()}"

                already_seen = await self.dao.dedup_seen_schedule(
                    project_id=project_id,
                    schedule_id=schedule.id,
                    event_id=event_id,
                )
                if already_seen:
                    continue

                event = {
                    "metadata": {
                        "trigger_slug": schedule.data.event_key,
                        "id": event_id,
                    },
                    "payload": {"timestamp": timestamp.isoformat()},
                }

                log.info(
                    "[SCHEDULE] Dispatching...",
                    project_id=project_id,
                    schedule_id=schedule.id,
                    timestamp=timestamp,
                )

                await asyncio.wait_for(
                    self.schedule_dispatch_task.kiq(
                        project_id=str(project_id),
                        event_id=event_id,
                        event=event,
                        schedule_id=str(schedule.id),
                    ),
                    timeout=_ENQUEUE_TIMEOUT_SECONDS,
                )

                log.info(
                    "[SCHEDULE] Dispatched.   ",
                    project_id=project_id,
                    schedule_id=schedule.id,
                )

            except Exception as e:  # pylint: disable=broad-exception-caught
                failures += 1
                log.error(
                    f"[SCHEDULE] Error refreshing schedule {schedule.id}: {e}",
                    exc_info=True,
                )

        # Report failure if any schedule dropped, so the cron/admin caller can
        # surface a non-200 instead of seeing a false success.
        return failures == 0

    # -----------------------------------------------------------------------
    # Deliveries
    # -----------------------------------------------------------------------

    async def fetch_delivery(
        self,
        *,
        project_id: UUID,
        #
        delivery_id: UUID,
    ) -> Optional[TriggerDelivery]:
        return await self.dao.fetch_delivery(
            project_id=project_id,
            delivery_id=delivery_id,
        )

    async def query_deliveries(
        self,
        *,
        project_id: UUID,
        #
        delivery: Optional[TriggerDeliveryQuery] = None,
        #
        windowing: Optional[Windowing] = None,
    ) -> List[TriggerDelivery]:
        return await self.dao.query_deliveries(
            project_id=project_id,
            delivery=delivery,
            windowing=windowing,
        )

    async def write_delivery(
        self,
        *,
        project_id: UUID,
        user_id: Optional[UUID] = None,
        #
        delivery: TriggerDeliveryCreate,
    ) -> Optional[TriggerDelivery]:
        """Write a delivery row.

        A subscription-scoped delivery routes through the liveness-gated DAO path
        (`write_subscription_delivery_if_live`) — this public service method must
        not reopen the hole that one was added to close (P3-6). No production
        caller today; a schedule-scoped delivery has no equivalent gate to bypass,
        so it still goes straight to `write_delivery`.
        """
        if delivery.subscription_id is not None and delivery.schedule_id is None:
            return await self.dao.write_subscription_delivery_if_live(
                project_id=project_id,
                user_id=user_id,
                delivery=delivery,
            )
        return await self.dao.write_delivery(
            project_id=project_id,
            user_id=user_id,
            delivery=delivery,
        )

    # -----------------------------------------------------------------------
    # Inbound webhook — registration + signature verification
    # -----------------------------------------------------------------------

    async def ensure_webhook_registered(self) -> None:
        """Ensure Composio's delivery webhook exists (startup, herd-safe)."""
        await self.webhook_secret_resolver.resolve()

    @staticmethod
    def _is_fresh(timestamp: str) -> bool:
        """Reject a webhook-timestamp outside the bounded replay window."""
        try:
            sent_at = int(timestamp)
        except ValueError:
            return False
        age = abs(datetime.now(timezone.utc).timestamp() - sent_at)
        return age <= env.composio.webhook_replay_window_seconds

    async def _claim_webhook_id(self, webhook_id: str) -> bool:
        """Atomically claim ``webhook_id`` for the replay window; False if already seen."""
        engine = get_cache_engine()
        key = f"triggers:composio:webhook-seen:{webhook_id}"
        claimed = await engine.set(
            key, b"1", nx=True, ex=env.composio.webhook_replay_window_seconds
        )
        return claimed is not None

    async def verify_signature(
        self, *, body: bytes, headers: Mapping[str, str]
    ) -> bool:
        """Verify Composio's HMAC over ``{webhook-id}.{webhook-timestamp}.{body}``.

        Confirmed against live events: Composio sends a lowercase hex digest.

        On mismatch, refresh the secret once (it rotates if the subscription is
        recreated) and retry before rejecting. Beyond the signature, rejects a
        stale ``webhook-timestamp`` and dedups ``webhook-id`` in Redis (both
        against the same bounded window) so a captured valid request cannot
        replay.
        """
        signature = headers.get("webhook-signature") or headers.get(
            "x-composio-signature"
        )
        if not signature:
            return False

        webhook_id = headers.get("webhook-id") or ""
        timestamp = headers.get("webhook-timestamp") or ""
        # webhook_id is untrusted header input; truncate + %r so it can't inject newlines or bloat logs.
        safe_webhook_id = webhook_id[:64]
        if not webhook_id or not self._is_fresh(timestamp):
            log.warning(
                "[TRIGGER SIGNATURE] stale or missing timestamp webhook_id=%r",
                safe_webhook_id,
            )
            return False

        # Byte-exact signing input: avoids the lossy utf-8 decode for non-utf-8 bodies.
        signed_bytes = f"{webhook_id}.{timestamp}.".encode("utf-8") + body
        provided = signature.split(",")[-1].strip()

        verified = False
        for force_refresh in (False, True):
            secret = await self.webhook_secret_resolver.resolve(
                force_refresh=force_refresh,
            )
            if not secret:
                return False
            expected = hmac.new(
                secret.encode("utf-8"), signed_bytes, hashlib.sha256
            ).hexdigest()

            if hmac.compare_digest(expected, provided):
                verified = True
                break

        if not verified:
            log.warning("[TRIGGER SIGNATURE] no match webhook_id=%r", safe_webhook_id)
            return False

        if not await self._claim_webhook_id(webhook_id):
            log.warning(
                "[TRIGGER SIGNATURE] replay rejected webhook_id=%r", safe_webhook_id
            )
            return False

        return True
