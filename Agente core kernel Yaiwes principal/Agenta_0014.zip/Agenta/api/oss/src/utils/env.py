import os
import hashlib
import warnings
from typing import List, Optional
from uuid import getnode
from json import loads
from urllib.parse import urlparse, quote_plus

from pydantic import BaseModel, ConfigDict, Field, model_validator


_TRUTHY = {"true", "1", "t", "y", "yes", "on", "enable", "enabled"}
_LICENSE = "ee" if os.getenv("AGENTA_LICENSE") == "ee" else "oss"
MAC_ADDRESS = ":".join(f"{(getnode() >> ele) & 0xFF:02x}" for ele in range(40, -1, -8))


# ---------------------------------------------------------------------------
# Helper JSON loaders (used by access + billing configs).
# ---------------------------------------------------------------------------


def _load_json_env_raw(name: str) -> object | None:
    raw = os.getenv(name)
    if raw is None:
        return None
    raw = raw.strip()
    if not raw:
        return None
    try:
        return loads(raw)
    except Exception as e:
        raise ValueError(f"{name} is not valid JSON: {e}") from e


def _load_json_env_dict(name: str) -> dict | None:
    """Parse `name` as a JSON object, or return None if unset/empty."""
    value = _load_json_env_raw(name)
    if value is None:
        return None
    if not isinstance(value, dict):
        raise ValueError(f"{name} must be a JSON object, got {type(value).__name__}")
    return value


def _load_json_env_dict_first(*names: str) -> dict | None:
    """Parse the first set JSON object from `names`, or return None."""
    for name in names:
        value = _load_json_env_dict(name)
        if value is not None:
            return value
    return None


def _load_json_env_list(name: str) -> list | None:
    """Parse `name` as a JSON array, or return None if unset/empty."""
    value = _load_json_env_raw(name)
    if value is None:
        return None
    if not isinstance(value, list):
        raise ValueError(f"{name} must be a JSON array, got {type(value).__name__}")
    return value


def _comma_set(name: str, *legacy_names: str) -> set:
    """Parse `name` (or any legacy alias) as comma-separated lowercase set."""
    raw = os.getenv(name)
    if raw is None:
        for legacy in legacy_names:
            raw = os.getenv(legacy)
            if raw is not None:
                break
    if not raw:
        return set()
    return {e.strip().lower() for e in raw.split(",") if e.strip()}


def _comma_set_optional(name: str, *legacy_names: str) -> set | None:
    s = _comma_set(name, *legacy_names)
    return s or None


def _parse_optional_int_env(name: str) -> int | None:
    raw = os.getenv(name)
    if raw is None:
        return None

    value = raw.strip()
    if not value:
        return None
    try:
        return int(value)
    except ValueError as e:
        raise ValueError(f"{name} must be a valid integer, got {raw!r}") from e


def _parse_optional_port_env(name: str) -> int | None:
    port = _parse_optional_int_env(name)
    if port is not None and not 1 <= port <= 65535:
        raise ValueError(f"{name} must be between 1 and 65535, got {port}")
    return port


def _parse_optional_positive_int_env(name: str) -> int | None:
    value = _parse_optional_int_env(name)

    if value is not None and value <= 0:
        raise ValueError(f"{name} must be greater than 0, got {value}")

    return value


def _parse_bool_env(name: str, default: bool) -> bool:
    raw = os.getenv(name)
    if raw is None:
        return default

    value = raw.strip()
    if not value:
        return default

    return value.lower() in _TRUTHY


# ---------------------------------------------------------------------------
# agenta.access — access controls.
# ---------------------------------------------------------------------------


class AccessConfig(BaseModel):
    """Access controls (allow/block lists, plans + roles, default plan).

    JSON env vars are parsed here at startup. The auth/onboarding controls
    (allow/block lists, allowed owner emails, email kill-switch) are OSS and
    consumed in both editions. Plans (`plans`, `default_plan*`) and custom-role
    overrides (`roles`, `roles_overlay`) are EE features: they are parsed here
    but only validated/applied by EE (`ee.src.core.access`). OSS enforces the
    code-default role catalog regardless of `roles`/`roles_overlay`.

    `default_plan` lives here (not under `agenta`) because it's part of the
    access-controls surface: it selects which entry of the effective plan
    map a new organization is onboarded onto, even on Stripe-disabled
    deployments.
    """

    allowed_domains: set = _comma_set(
        "AGENTA_ACCESS_ALLOWED_DOMAINS",
        "AGENTA_ALLOWED_DOMAINS",
    )
    allowed_owner_emails: set | None = _comma_set_optional(
        "AGENTA_ACCESS_ALLOWED_OWNER_EMAILS",
        "AGENTA_ACCESS_ALLOWED_ORGANIZATION_OWNERS",
        "AGENTA_ACCESS_ORG_CREATION_ALLOWLIST",
        "AGENTA_ORG_CREATION_ALLOWLIST",
    )
    blocked_domains: set = _comma_set(
        "AGENTA_ACCESS_BLOCKED_DOMAINS",
        "AGENTA_BLOCKED_DOMAINS",
    )
    blocked_emails: set = _comma_set(
        "AGENTA_ACCESS_BLOCKED_EMAILS",
        "AGENTA_BLOCKED_EMAILS",
    )

    default_plan: str | None = (
        os.getenv("AGENTA_ACCESS_DEFAULT_PLAN")
        or os.getenv("AGENTA_DEFAULT_PLAN")
        or None
    )
    default_plan_overlay: dict | None = _load_json_env_dict(
        "AGENTA_ACCESS_DEFAULT_PLAN_OVERLAY"
    )

    email_disabled: bool = (
        os.getenv("AGENTA_ACCESS_EMAIL_DISABLED")
        or os.getenv("SUPERTOKENS_EMAIL_DISABLED")
        or "false"
    ).lower() in _TRUTHY

    plans: dict | None = _load_json_env_dict("AGENTA_ACCESS_PLANS")
    roles: dict | None = _load_json_env_dict("AGENTA_ACCESS_ROLES")
    roles_overlay: dict | None = _load_json_env_dict("AGENTA_ACCESS_ROLES_OVERLAY")

    model_config = ConfigDict(extra="ignore")


# ---------------------------------------------------------------------------
# agenta.ai_services
# ---------------------------------------------------------------------------


class AIServicesConfig(BaseModel):
    """AI services configuration.

    Feature is enabled only when all required env vars are present.
    """

    api_key: str | None = os.getenv("AGENTA_AI_SERVICES_API_KEY")
    api_url: str | None = os.getenv("AGENTA_AI_SERVICES_API_URL")
    environment_slug: str | None = os.getenv("AGENTA_AI_SERVICES_ENVIRONMENT_SLUG")
    refine_prompt_key: str | None = os.getenv("AGENTA_AI_SERVICES_REFINE_PROMPT_KEY")

    model_config = ConfigDict(extra="ignore")

    @property
    def enabled(self) -> bool:
        required = [
            self.api_key,
            self.api_url,
            self.environment_slug,
            self.refine_prompt_key,
        ]
        return all(isinstance(v, str) and v.strip() for v in required)


# ---------------------------------------------------------------------------
# agenta.billing
# ---------------------------------------------------------------------------


class BillingConfig(BaseModel):
    """Billing settings (catalog + Stripe pricing).

    JSON env vars are parsed here at startup. Schema validation happens in
    ``ee.src.core.subscriptions.settings``. The free-plan marker and
    reverse-trial duration live per-entry inside ``AGENTA_BILLING_PRICING``
    (`{"free": true}` / `{"trial": N}`).
    """

    catalog: list | None = _load_json_env_list("AGENTA_BILLING_CATALOG")
    pricing: dict | None = _load_json_env_dict_first(
        "AGENTA_BILLING_PRICING",
        "AGENTA_PRICING",
        "STRIPE_PRICING",
    )

    model_config = ConfigDict(extra="ignore")


# ---------------------------------------------------------------------------
# agenta.api — API-specific sub-namespace (caching, etc.)
# ---------------------------------------------------------------------------


class ApiCachingConfig(BaseModel):
    """API response caching feature flag."""

    enabled: bool = (
        os.getenv("AGENTA_API_CACHING_ENABLED")
        or os.getenv("AGENTA_CACHING_ENABLED")
        or os.getenv("AGENTA_CACHE_ENABLED")
        or "true"
    ).lower() in _TRUTHY

    model_config = ConfigDict(extra="ignore")


class WorkflowsConfig(BaseModel):
    """Workflow-revision behavior toggles."""

    # The ordered-operations change set (agent-config-editing). ON is the default: the
    # request model carries the ordered arm and the catalog advertises it. The variable
    # is an escape hatch — set it falsy and the deployment falls back to the legacy
    # surface, where only `set`/`remove` exist and a delta carrying `operations` is
    # refused as an unknown field.
    # The SDK reads this SAME variable in `agenta/sdk/agents/flags.py` to decide what to
    # advertise to the model and what the build-an-agent skill teaches, and cannot import
    # this parser. Its default and its accepted spellings must match this one in both
    # directions, or the model is shown one payload shape while the server accepts
    # another. Pinned by `oss/tests/pytest/unit/workflows/test_ordered_operations_flag.py`.
    ordered_operations_enabled: bool = _parse_bool_env(
        "AGENTA_WORKFLOWS_ORDERED_OPERATIONS_ENABLED", True
    )

    model_config = ConfigDict(extra="ignore")


class ApiConfig(BaseModel):
    """Agenta API sub-namespace."""

    caching: ApiCachingConfig = ApiCachingConfig()
    workflows: WorkflowsConfig = WorkflowsConfig()

    model_config = ConfigDict(extra="ignore")


# ---------------------------------------------------------------------------
# agenta.extras
# ---------------------------------------------------------------------------


class ExtrasConfig(BaseModel):
    """Extras and feature toggles (demos, etc.)."""

    demos: str = os.getenv("AGENTA_EXTRAS_DEMOS") or os.getenv("AGENTA_DEMOS") or ""

    model_config = ConfigDict(extra="ignore")


# ---------------------------------------------------------------------------
# agenta.logging
# ---------------------------------------------------------------------------


class LoggingConfig(BaseModel):
    """Logging configuration"""

    console_enabled: bool = (
        os.getenv("AGENTA_LOGGING_CONSOLE_ENABLED")
        or os.getenv("AGENTA_LOG_CONSOLE_ENABLED")
        or "true"
    ).lower() in _TRUTHY
    console_level: str = (
        os.getenv("AGENTA_LOGGING_CONSOLE_LEVEL")
        or os.getenv("AGENTA_LOG_CONSOLE_LEVEL")
        or "TRACE"
    ).upper()

    file_enabled: bool = (
        os.getenv("AGENTA_LOGGING_FILE_ENABLED")
        or os.getenv("AGENTA_LOG_FILE_ENABLED")
        or "true"
    ).lower() in _TRUTHY
    file_level: str = (
        os.getenv("AGENTA_LOGGING_FILE_LEVEL")
        or os.getenv("AGENTA_LOG_FILE_LEVEL")
        or "WARNING"
    ).upper()
    file_path: str = (
        os.getenv("AGENTA_LOGGING_FILE_PATH")
        or os.getenv("AGENTA_LOG_FILE_PATH")
        or "error"
    )

    otlp_enabled: bool = (
        os.getenv("AGENTA_LOGGING_OTLP_ENABLED")
        or os.getenv("AGENTA_LOG_OTLP_ENABLED")
        or "false"
    ).lower() in _TRUTHY
    otlp_level: str = (
        os.getenv("AGENTA_LOGGING_OTLP_LEVEL")
        or os.getenv("AGENTA_LOG_OTLP_LEVEL")
        or "INFO"
    ).upper()

    model_config = ConfigDict(extra="ignore")


# ---------------------------------------------------------------------------
# agenta.otlp
# ---------------------------------------------------------------------------


class OTLPConfig(BaseModel):
    """OpenTelemetry Protocol configuration"""

    max_batch_bytes: int = int(
        os.getenv("AGENTA_OTLP_MAX_BATCH_BYTES") or str(10 * 1024 * 1024)
    )

    model_config = ConfigDict(extra="ignore")


# ---------------------------------------------------------------------------
# agenta.services — code, hook, middleware sub-models.
# ---------------------------------------------------------------------------


_SANDBOX_RUNNER_LOCAL_WARNED = False


class ServicesCodeConfig(BaseModel):
    sandbox_runner: str = (
        os.getenv("AGENTA_SERVICES_CODE_SANDBOX_RUNNER")
        or os.getenv("AGENTA_SERVICES_SANDBOX_RUNNER")
        or "local"
    )

    model_config = ConfigDict(extra="ignore")

    @model_validator(mode="after")
    def _warn_sandbox_runner_mode(self) -> "ServicesCodeConfig":
        global _SANDBOX_RUNNER_LOCAL_WARNED
        if self.sandbox_runner == "local" and not _SANDBOX_RUNNER_LOCAL_WARNED:
            _SANDBOX_RUNNER_LOCAL_WARNED = True
            warnings.warn(
                "AGENTA_SERVICES_CODE_SANDBOX_RUNNER is 'local' (default): code execution "
                "is not sandboxed from the host. Set it to 'restricted' to harden a "
                "shared/multi-tenant deployment.",
                stacklevel=2,
            )
        return self


class ServicesMiddlewareConfig(BaseModel):
    caching_enabled: bool = (
        os.getenv("AGENTA_SERVICES_MIDDLEWARE_CACHING_ENABLED")
        or os.getenv("AGENTA_SERVICES_MIDDLEWARE_CACHE_ENABLED")
        or "true"
    ).lower() in _TRUTHY

    model_config = ConfigDict(extra="ignore")


class ServicesConfig(BaseModel):
    code: ServicesCodeConfig = ServicesCodeConfig()
    middleware: ServicesMiddlewareConfig = ServicesMiddlewareConfig()

    model_config = ConfigDict(extra="ignore")


# ---------------------------------------------------------------------------
# agenta.workers
# ---------------------------------------------------------------------------


def _load_csv_env_list(name: str) -> list[str]:
    """Parse `name` as a comma-separated list, trimming blanks. Empty/unset -> []."""
    raw = os.getenv(name) or ""
    return [item.strip() for item in raw.split(",") if item.strip()]


class WorkersConfig(BaseModel):
    """Topology selectors for the merged `worker-streams`/`worker-queues` entrypoints.

    Empty list means "all loops in that family" — see
    docs/designs/workers-sprawl/specs.md.
    """

    streams: list[str] = _load_csv_env_list("AGENTA_WORKER_STREAMS")
    queues: list[str] = _load_csv_env_list("AGENTA_WORKER_QUEUES")

    model_config = ConfigDict(extra="ignore")


# ---------------------------------------------------------------------------
# agenta.webhooks
# ---------------------------------------------------------------------------


_EGRESS_INSECURE_WARNED = False


class WebhooksConfig(BaseModel):
    # AGENTA_WEBHOOKS_ALLOW_INSECURE / AGENTA_WEBHOOK_ALLOW_INSECURE are deprecated aliases; prefer AGENTA_INSECURE_EGRESS_ALLOWED.
    allow_insecure: bool = (
        os.getenv("AGENTA_INSECURE_EGRESS_ALLOWED")
        or os.getenv("AGENTA_WEBHOOKS_ALLOW_INSECURE")
        or os.getenv("AGENTA_WEBHOOK_ALLOW_INSECURE")
        or "true"
    ).lower() in _TRUTHY

    model_config = ConfigDict(extra="ignore")

    @model_validator(mode="after")
    def _warn_egress_mode(self) -> "WebhooksConfig":
        global _EGRESS_INSECURE_WARNED
        if self.allow_insecure and not _EGRESS_INSECURE_WARNED:
            _EGRESS_INSECURE_WARNED = True
            warnings.warn(
                "AGENTA_INSECURE_EGRESS_ALLOWED is on (default): webhook/egress targets may "
                "include http and private/loopback/metadata hosts. Set it to false to harden "
                "a shared/multi-tenant deployment.",
                stacklevel=2,
            )
        return self


# ---------------------------------------------------------------------------
# agenta.redaction
# ---------------------------------------------------------------------------

_REDACTION_LIVE_MODES = {"off", "known"}
_REDACTION_INERT_MODES = {"pattern", "full"}


class RedactionConfig(BaseModel):
    """Online redaction filter mode. Only `off`/`known` are live in Slice 1; `pattern`/`full`
    are declared-but-inert (Slice 2) and behave as `known` with a warning."""

    mode: str = os.getenv("AGENTA_REDACTION_MODE") or "known"

    # Operator additions to the SDK's name/value matchers; the SDK (seed.py) owns the
    # defaults and the merge-onto-default semantics — these are the raw overrides only.
    prefixes: list[str] = _load_csv_env_list("AGENTA_REDACTED_PREFIXES")
    suffixes: list[str] = _load_csv_env_list("AGENTA_REDACTED_SUFFIXES")
    blocklist: list[str] = _load_csv_env_list("AGENTA_REDACTED_BLOCKLIST")
    allowlist: list[str] = _load_csv_env_list("AGENTA_REDACTED_ALLOWLIST")

    model_config = ConfigDict(extra="ignore")

    @model_validator(mode="after")
    def _validate_mode(self) -> "RedactionConfig":
        mode = (self.mode or "known").strip().lower()
        if mode in _REDACTION_INERT_MODES:
            warnings.warn(
                f"AGENTA_REDACTION_MODE={mode} is declared but inert (Slice 2 not shipped); behaving as 'known'.",
                stacklevel=2,
            )
            mode = "known"
        elif mode not in _REDACTION_LIVE_MODES:
            warnings.warn(
                f"AGENTA_REDACTION_MODE={mode!r} is not recognized; behaving as 'known'.",
                stacklevel=2,
            )
            mode = "known"
        self.mode = mode
        return self


# ---------------------------------------------------------------------------
# agenta.sessions
# ---------------------------------------------------------------------------


class SessionsRecordsConfig(BaseModel):
    """Durable session-record ingest tuning (server-side history reconstruction)."""

    # When a record body exceeds the cap, preserve its structure + partial content (trim only
    # the large field values) instead of replacing the whole body with {"_truncated": True}.
    # Off = legacy whole-body drop, which loses the record's type and id and leaves the
    # replayed tool card unable to settle. Default ON since 2026-08-11.
    smart_truncation: bool = (
        os.getenv("AGENTA_RECORDS_SMART_TRUNCATION") or "true"
    ).lower() in _TRUTHY

    model_config = ConfigDict(extra="ignore")


class SessionAttachmentsConfig(BaseModel):
    max_image_bytes: int = int(
        os.getenv("AGENTA_ATTACHMENTS_MAX_IMAGE_BYTES") or 10_485_760
    )
    max_audio_bytes: int = int(
        os.getenv("AGENTA_ATTACHMENTS_MAX_AUDIO_BYTES") or 15_728_640
    )
    max_document_bytes: int = int(
        os.getenv("AGENTA_ATTACHMENTS_MAX_DOCUMENT_BYTES") or 10_485_760
    )
    max_other_bytes: int = int(
        os.getenv("AGENTA_ATTACHMENTS_MAX_OTHER_BYTES") or 10_485_760
    )
    max_per_session_count: int = int(
        os.getenv("AGENTA_ATTACHMENTS_MAX_PER_SESSION_COUNT") or 1000
    )
    max_per_session_bytes: int = int(
        os.getenv("AGENTA_ATTACHMENTS_MAX_PER_SESSION_BYTES") or 268_435_456
    )
    max_pending_per_session: int = int(
        os.getenv("AGENTA_ATTACHMENTS_MAX_PENDING_PER_SESSION") or 20
    )
    pending_ttl_seconds: int = int(
        os.getenv("AGENTA_ATTACHMENTS_PENDING_TTL_SECONDS") or 900
    )
    unreferenced_ttl_seconds: int = int(
        os.getenv("AGENTA_ATTACHMENTS_UNREFERENCED_TTL_SECONDS") or 86_400
    )
    sweep_interval_seconds: int = int(
        os.getenv("AGENTA_ATTACHMENTS_SWEEP_INTERVAL_SECONDS") or 3_600
    )

    model_config = ConfigDict(extra="ignore")


class SessionsConfig(BaseModel):
    """Agenta sessions sub-namespace."""

    attachments: SessionAttachmentsConfig = SessionAttachmentsConfig()
    records: SessionsRecordsConfig = SessionsRecordsConfig()

    model_config = ConfigDict(extra="ignore")


# ---------------------------------------------------------------------------
# agenta — top-level Agenta core config.
# ---------------------------------------------------------------------------


def _services_internal_key_from_environment() -> str | None:
    """Read the dedicated runtime proof without accepting public placeholders."""
    runtime_key = (os.getenv("AGENTA_SERVICES_INTERNAL_KEY") or "").strip()

    if not runtime_key or runtime_key == "replace-me":
        return None

    return runtime_key


class AgentaConfig(BaseModel):
    """Agenta core configuration"""

    license: str = _LICENSE

    web_url: str = os.getenv("AGENTA_WEB_URL") or "http://localhost"
    services_url: str = os.getenv("AGENTA_SERVICES_URL") or "http://localhost/services"
    api_url: str = os.getenv("AGENTA_API_URL") or "http://localhost/api"
    api_internal_url: str | None = os.getenv("AGENTA_API_INTERNAL_URL")

    auth_key: str = os.getenv("AGENTA_AUTH_KEY") or "replace-me"
    crypt_key: str = os.getenv("AGENTA_CRYPT_KEY") or "replace-me"
    # Shared secret that proves a caller IS the platform runtime (the workflow service),
    # as opposed to a browser or an ApiKey holder reaching the same public route. Only a
    # caller holding it can be issued a credential that reads write-only secret values.
    # This is deliberately separate from the administrator key: deployments must opt in
    # by configuring the same dedicated value on the API and platform services. NEVER
    # sent to the runner or into a sandbox.
    services_internal_key: str | None = _services_internal_key_from_environment()

    access: AccessConfig = AccessConfig()
    ai_services: AIServicesConfig = AIServicesConfig()
    api: ApiConfig = ApiConfig()
    billing: BillingConfig = BillingConfig()
    extras: ExtrasConfig = ExtrasConfig()
    logging: LoggingConfig = LoggingConfig()
    otlp: OTLPConfig = OTLPConfig()
    redaction: RedactionConfig = RedactionConfig()
    services: ServicesConfig = ServicesConfig()
    sessions: SessionsConfig = SessionsConfig()
    webhooks: WebhooksConfig = WebhooksConfig()
    workers: WorkersConfig = WorkersConfig()

    model_config = ConfigDict(extra="ignore")


# ---------------------------------------------------------------------------
# alembic
# ---------------------------------------------------------------------------


class AlembicConfig(BaseModel):
    """Database migration configuration"""

    auto_migrations: bool = (
        os.getenv("ALEMBIC_AUTO_MIGRATIONS")
        or os.getenv("AGENTA_AUTO_MIGRATIONS")
        or "true"
    ).lower() in _TRUTHY

    cfg_path_core: str = os.getenv("ALEMBIC_CFG_PATH_CORE") or (
        f"/app/{_LICENSE}/databases/postgres/migrations/core/alembic.ini"
    )
    cfg_path_tracing: str = os.getenv("ALEMBIC_CFG_PATH_TRACING") or (
        f"/app/{_LICENSE}/databases/postgres/migrations/tracing/alembic.ini"
    )

    model_config = ConfigDict(extra="ignore")


# ---------------------------------------------------------------------------
# cloudflare.turnstile
# ---------------------------------------------------------------------------


class CloudflareTurnstileConfig(BaseModel):
    site_key: str | None = os.getenv("CLOUDFLARE_TURNSTILE_SITE_KEY")
    secret_key: str | None = os.getenv("CLOUDFLARE_TURNSTILE_SECRET_KEY")
    allowed_hostnames_raw: str = (
        os.getenv("CLOUDFLARE_TURNSTILE_ALLOWED_HOSTNAMES") or ""
    )

    model_config = ConfigDict(extra="ignore")

    @property
    def enabled(self) -> bool:
        """Turnstile enabled if both site and secret keys are configured."""
        return bool(self.site_key and self.secret_key)

    @property
    def allowed_hostnames(self) -> set[str]:
        """Expected hostnames for successful Turnstile verifications."""
        configured_hostnames = {
            hostname.strip().lower()
            for hostname in self.allowed_hostnames_raw.split(",")
            if hostname.strip()
        }
        if configured_hostnames:
            return configured_hostnames

        derived_hostnames = set()
        for candidate_url in (env.agenta.web_url, env.agenta.api_url):
            try:
                parsed = urlparse(
                    candidate_url
                    if "://" in candidate_url
                    else f"https://{candidate_url}"
                )
            except Exception:
                continue

            hostname = (parsed.hostname or "").strip().lower()
            if hostname and hostname not in {"localhost", "127.0.0.1", "::1"}:
                derived_hostnames.add(hostname)

        return derived_hostnames


class CloudflareConfig(BaseModel):
    turnstile: CloudflareTurnstileConfig = CloudflareTurnstileConfig()

    model_config = ConfigDict(extra="ignore")


# ---------------------------------------------------------------------------
# composio
# ---------------------------------------------------------------------------


class ComposioConfig(BaseModel):
    """Composio integration configuration"""

    api_key: str | None = os.getenv("COMPOSIO_API_KEY")
    api_url: str = os.getenv(
        "COMPOSIO_API_URL", "https://backend.composio.dev/api/v3.1"
    )
    # Dev: when set, unknown-trigger drops log at WARNING instead of INFO.
    webhook_target: str | None = os.getenv("COMPOSIO_WEBHOOK_TARGET")
    # Override the registered webhook URL. Composio requires public HTTPS; in dev
    # (http://localhost) the tunnel delivers over WebSocket, so this only needs to
    # be a valid public HTTPS placeholder to mint the subscription's secret.
    webhook_url: str | None = os.getenv("COMPOSIO_WEBHOOK_URL")
    # Bounded replay/freshness window (seconds) for inbound webhook-timestamp; also
    # the TTL for the webhook-id dedup entry.
    webhook_replay_window_seconds: int = int(
        os.getenv("COMPOSIO_WEBHOOK_REPLAY_WINDOW_SECONDS") or 300
    )
    # Full trigger-types and tool catalogs: project-agnostic cache TTL + whole-fetch
    # deadline. Both crawl the same Composio catalog surface.
    catalog_cache_ttl_seconds: int = int(
        os.getenv("COMPOSIO_CATALOG_CACHE_TTL_SECONDS") or 24 * 60 * 60
    )
    catalog_fetch_deadline_seconds: float = float(
        os.getenv("COMPOSIO_CATALOG_FETCH_DEADLINE_SECONDS") or 30
    )

    @property
    def enabled(self) -> bool:
        """Composio enabled if API key is present"""
        return bool(self.api_key)

    model_config = ConfigDict(extra="ignore")


# ---------------------------------------------------------------------------
# crisp
# ---------------------------------------------------------------------------


class CrispConfig(BaseModel):
    """Crisp Chat configuration"""

    website_id: str | None = os.getenv("CRISP_WEBSITE_ID")

    model_config = ConfigDict(extra="ignore")

    @property
    def enabled(self) -> bool:
        """Crisp enabled if website ID present"""
        return bool(self.website_id)


# ---------------------------------------------------------------------------
# daytona
# ---------------------------------------------------------------------------


class DaytonaConfig(BaseModel):
    api_key: str | None = os.getenv("DAYTONA_API_KEY")
    api_url: str | None = os.getenv("DAYTONA_API_URL")
    # Code-evaluator override first, then the snapshot shared with the agent runner.
    snapshot: str | None = os.getenv("DAYTONA_SNAPSHOT_CODE") or os.getenv(
        "DAYTONA_SNAPSHOT"
    )
    target: str | None = os.getenv("DAYTONA_TARGET")

    model_config = ConfigDict(extra="ignore")


# ---------------------------------------------------------------------------
# docker
# ---------------------------------------------------------------------------


class DockerConfig(BaseModel):
    """Docker runtime configuration"""

    network_mode: str = os.getenv("DOCKER_NETWORK_MODE") or "bridge"

    model_config = ConfigDict(extra="ignore")


# ---------------------------------------------------------------------------
# identity — OIDC providers grouped by vendor.
# ---------------------------------------------------------------------------


class IdentityAppleConfig(BaseModel):
    client_id: str | None = os.getenv("APPLE_OAUTH_CLIENT_ID")
    client_secret: str | None = os.getenv("APPLE_OAUTH_CLIENT_SECRET")
    key_id: str | None = os.getenv("APPLE_KEY_ID")
    private_key: str | None = os.getenv("APPLE_PRIVATE_KEY")
    team_id: str | None = os.getenv("APPLE_TEAM_ID")

    model_config = ConfigDict(extra="ignore")

    @property
    def enabled(self) -> bool:
        return bool(
            self.client_id
            and (
                self.client_secret
                or (self.key_id and self.team_id and self.private_key)
            )
        )


class IdentityAzureADConfig(BaseModel):
    client_id: str | None = os.getenv("AZURE_AD_OAUTH_CLIENT_ID") or os.getenv(
        "ACTIVE_DIRECTORY_OAUTH_CLIENT_ID"
    )
    client_secret: str | None = os.getenv("AZURE_AD_OAUTH_CLIENT_SECRET") or os.getenv(
        "ACTIVE_DIRECTORY_OAUTH_CLIENT_SECRET"
    )
    directory_id: str | None = os.getenv("AZURE_AD_DIRECTORY_ID") or os.getenv(
        "ACTIVE_DIRECTORY_DIRECTORY_ID"
    )

    model_config = ConfigDict(extra="ignore")

    @property
    def enabled(self) -> bool:
        return bool(self.client_id and self.client_secret and self.directory_id)


class IdentityBitbucketConfig(BaseModel):
    client_id: str | None = os.getenv("BITBUCKET_OAUTH_CLIENT_ID")
    client_secret: str | None = os.getenv("BITBUCKET_OAUTH_CLIENT_SECRET")

    model_config = ConfigDict(extra="ignore")

    @property
    def enabled(self) -> bool:
        return bool(self.client_id and self.client_secret)


class IdentityBoxySamlConfig(BaseModel):
    client_id: str | None = os.getenv("BOXY_SAML_OAUTH_CLIENT_ID")
    client_secret: str | None = os.getenv("BOXY_SAML_OAUTH_CLIENT_SECRET")
    url: str | None = os.getenv("BOXY_SAML_URL")

    model_config = ConfigDict(extra="ignore")

    @property
    def enabled(self) -> bool:
        return bool(self.client_id and self.client_secret and self.url)


class IdentityDiscordConfig(BaseModel):
    client_id: str | None = os.getenv("DISCORD_OAUTH_CLIENT_ID")
    client_secret: str | None = os.getenv("DISCORD_OAUTH_CLIENT_SECRET")

    model_config = ConfigDict(extra="ignore")

    @property
    def enabled(self) -> bool:
        return bool(self.client_id and self.client_secret)


class IdentityFacebookConfig(BaseModel):
    client_id: str | None = os.getenv("FACEBOOK_OAUTH_CLIENT_ID")
    client_secret: str | None = os.getenv("FACEBOOK_OAUTH_CLIENT_SECRET")

    model_config = ConfigDict(extra="ignore")

    @property
    def enabled(self) -> bool:
        return bool(self.client_id and self.client_secret)


class IdentityGithubConfig(BaseModel):
    client_id: str | None = os.getenv("GITHUB_OAUTH_CLIENT_ID")
    client_secret: str | None = os.getenv("GITHUB_OAUTH_CLIENT_SECRET")

    model_config = ConfigDict(extra="ignore")

    @property
    def enabled(self) -> bool:
        return bool(self.client_id and self.client_secret)


class IdentityGitlabConfig(BaseModel):
    base_url: str | None = os.getenv("GITLAB_BASE_URL")
    client_id: str | None = os.getenv("GITLAB_OAUTH_CLIENT_ID")
    client_secret: str | None = os.getenv("GITLAB_OAUTH_CLIENT_SECRET")

    model_config = ConfigDict(extra="ignore")

    @property
    def enabled(self) -> bool:
        return bool(self.client_id and self.client_secret)


class IdentityGoogleConfig(BaseModel):
    client_id: str | None = os.getenv("GOOGLE_OAUTH_CLIENT_ID")
    client_secret: str | None = os.getenv("GOOGLE_OAUTH_CLIENT_SECRET")

    model_config = ConfigDict(extra="ignore")

    @property
    def enabled(self) -> bool:
        return bool(self.client_id and self.client_secret)


class IdentityGoogleWorkspacesConfig(BaseModel):
    client_id: str | None = os.getenv("GOOGLE_WORKSPACES_OAUTH_CLIENT_ID")
    client_secret: str | None = os.getenv("GOOGLE_WORKSPACES_OAUTH_CLIENT_SECRET")
    hd: str | None = os.getenv("GOOGLE_WORKSPACES_HD")

    model_config = ConfigDict(extra="ignore")

    @property
    def enabled(self) -> bool:
        return bool(self.client_id and self.client_secret)


class IdentityLinkedinConfig(BaseModel):
    client_id: str | None = os.getenv("LINKEDIN_OAUTH_CLIENT_ID")
    client_secret: str | None = os.getenv("LINKEDIN_OAUTH_CLIENT_SECRET")

    model_config = ConfigDict(extra="ignore")

    @property
    def enabled(self) -> bool:
        return bool(self.client_id and self.client_secret)


class IdentityOktaConfig(BaseModel):
    client_id: str | None = os.getenv("OKTA_OAUTH_CLIENT_ID")
    client_secret: str | None = os.getenv("OKTA_OAUTH_CLIENT_SECRET")
    domain: str | None = os.getenv("OKTA_DOMAIN")

    model_config = ConfigDict(extra="ignore")

    @property
    def enabled(self) -> bool:
        return bool(self.client_id and self.client_secret and self.domain)


class IdentityTwitterConfig(BaseModel):
    client_id: str | None = os.getenv("TWITTER_OAUTH_CLIENT_ID")
    client_secret: str | None = os.getenv("TWITTER_OAUTH_CLIENT_SECRET")

    model_config = ConfigDict(extra="ignore")

    @property
    def enabled(self) -> bool:
        return bool(self.client_id and self.client_secret)


class IdentityConfig(BaseModel):
    apple: IdentityAppleConfig = IdentityAppleConfig()
    azure_ad: IdentityAzureADConfig = IdentityAzureADConfig()
    bitbucket: IdentityBitbucketConfig = IdentityBitbucketConfig()
    boxy_saml: IdentityBoxySamlConfig = IdentityBoxySamlConfig()
    discord: IdentityDiscordConfig = IdentityDiscordConfig()
    facebook: IdentityFacebookConfig = IdentityFacebookConfig()
    github: IdentityGithubConfig = IdentityGithubConfig()
    gitlab: IdentityGitlabConfig = IdentityGitlabConfig()
    google: IdentityGoogleConfig = IdentityGoogleConfig()
    google_workspaces: IdentityGoogleWorkspacesConfig = IdentityGoogleWorkspacesConfig()
    linkedin: IdentityLinkedinConfig = IdentityLinkedinConfig()
    okta: IdentityOktaConfig = IdentityOktaConfig()
    twitter: IdentityTwitterConfig = IdentityTwitterConfig()

    model_config = ConfigDict(extra="ignore")

    @property
    def any_oidc_enabled(self) -> bool:
        return (
            self.apple.enabled
            or self.azure_ad.enabled
            or self.bitbucket.enabled
            or self.boxy_saml.enabled
            or self.discord.enabled
            or self.facebook.enabled
            or self.github.enabled
            or self.gitlab.enabled
            or self.google.enabled
            or self.google_workspaces.enabled
            or self.linkedin.enabled
            or self.okta.enabled
            or self.twitter.enabled
        )


# ---------------------------------------------------------------------------
# llm — provider API keys (top-level by vendor).
# ---------------------------------------------------------------------------


class LLMConfig(BaseModel):
    """LLM Provider API Keys configuration"""

    alephalpha: str = os.getenv("ALEPHALPHA_API_KEY", "")
    anthropic: str = os.getenv("ANTHROPIC_API_KEY", "")
    anyscale: str = os.getenv("ANYSCALE_API_KEY", "")
    cohere: str = os.getenv("COHERE_API_KEY", "")
    deepinfra: str = os.getenv("DEEPINFRA_API_KEY", "")
    gemini: str = os.getenv("GEMINI_API_KEY", "")
    groq: str = os.getenv("GROQ_API_KEY", "")
    mistral: str = os.getenv("MISTRAL_API_KEY", "")
    openai: str = os.getenv("OPENAI_API_KEY", "")
    openrouter: str = os.getenv("OPENROUTER_API_KEY", "")
    perplexityai: str = os.getenv("PERPLEXITYAI_API_KEY", "")
    togetherai: str = os.getenv("TOGETHERAI_API_KEY", "")
    minimax: str = os.getenv("MINIMAX_API_KEY", "")

    model_config = ConfigDict(extra="ignore")

    @property
    def enabled_providers(self) -> list[str]:
        """Return list of enabled LLM providers"""
        return [
            name
            for name in [
                "alephalpha",
                "anthropic",
                "anyscale",
                "cohere",
                "deepinfra",
                "gemini",
                "groq",
                "mistral",
                "openai",
                "openrouter",
                "perplexityai",
                "togetherai",
                "minimax",
            ]
            if getattr(self, name)
        ]


# ---------------------------------------------------------------------------
# loops
# ---------------------------------------------------------------------------


class LoopsConfig(BaseModel):
    """Loops email marketing configuration"""

    api_key: str | None = os.getenv("LOOPS_API_KEY")

    model_config = ConfigDict(extra="ignore")

    @property
    def enabled(self) -> bool:
        """Loops enabled if API key present"""
        return bool(self.api_key)


# ---------------------------------------------------------------------------
# runner — agent runner sidecar (services/runner). Node-process config; documented
# here for the canonical env-var mapping even though the runner reads process.env
# directly (it is a separate Node process, not this Python process).
# ---------------------------------------------------------------------------


_SANDBOX_LOCAL_WARNED = False

# Sandbox providers this runner can provision. Kept in lockstep with the runner's
# KNOWN_SANDBOX_PROVIDER_IDS and the SDK's KNOWN_SANDBOX_PROVIDERS so all three readers agree.
_KNOWN_SANDBOX_PROVIDERS = ("local", "daytona")


def _parse_enabled_sandbox_providers(raw: Optional[str]) -> List[str]:
    """Parse ``AGENTA_RUNNER_ENABLED_SANDBOX_PROVIDERS`` with the runner's rules.

    Unset -> ``["local"]``; explicit empty invalid; ids normalized lowercase; unknown and
    duplicate ids invalid. Reimplements the TypeScript runner parser so the API's provider
    pre-filter matches the runner's final authority (runner-selfhosting-cleanup/interface.md
    sections 2 and 4).
    """
    if raw is None:
        return ["local"]
    trimmed = raw.strip()
    if trimmed == "":
        raise ValueError(
            "AGENTA_RUNNER_ENABLED_SANDBOX_PROVIDERS is set but empty; unset it for the "
            "default 'local', or list at least one provider."
        )
    ids = [part.strip().lower() for part in trimmed.split(",")]
    seen: set = set()
    for provider_id in ids:
        if provider_id == "":
            raise ValueError(
                f"AGENTA_RUNNER_ENABLED_SANDBOX_PROVIDERS has an empty entry in '{trimmed}'."
            )
        if provider_id not in _KNOWN_SANDBOX_PROVIDERS:
            raise ValueError(
                f"AGENTA_RUNNER_ENABLED_SANDBOX_PROVIDERS lists unknown provider "
                f"'{provider_id}'; known: {', '.join(_KNOWN_SANDBOX_PROVIDERS)}."
            )
        if provider_id in seen:
            raise ValueError(
                f"AGENTA_RUNNER_ENABLED_SANDBOX_PROVIDERS lists provider '{provider_id}' "
                f"more than once."
            )
        seen.add(provider_id)
    return ids


def _parse_default_sandbox_provider(raw: Optional[str], enabled: List[str]) -> str:
    """Parse ``AGENTA_RUNNER_DEFAULT_SANDBOX_PROVIDER``; unset -> ``local``; must be enabled."""
    value = (raw or "").strip().lower() or "local"
    if value not in _KNOWN_SANDBOX_PROVIDERS:
        raise ValueError(
            f"AGENTA_RUNNER_DEFAULT_SANDBOX_PROVIDER is unknown provider '{value}'; "
            f"known: {', '.join(_KNOWN_SANDBOX_PROVIDERS)}."
        )
    if value not in enabled:
        raise ValueError(
            f"AGENTA_RUNNER_DEFAULT_SANDBOX_PROVIDER '{value}' is not in the enabled set "
            f"[{', '.join(enabled)}]."
        )
    return value


def _enabled_sandbox_providers_default() -> List[str]:
    return _parse_enabled_sandbox_providers(
        os.getenv("AGENTA_RUNNER_ENABLED_SANDBOX_PROVIDERS")
    )


def _default_sandbox_provider_default() -> str:
    return _parse_default_sandbox_provider(
        os.getenv("AGENTA_RUNNER_DEFAULT_SANDBOX_PROVIDER"),
        _enabled_sandbox_providers_default(),
    )


class RunnerConfig(BaseModel):
    """Agent runner (services/runner) sidecar configuration."""

    concurrency_limit: int = int(os.getenv("AGENTA_RUNNER_CONCURRENCY_LIMIT") or "1000")

    # The sandbox-provider registry the runner and API share. `local` is unconfined host bash —
    # not a tenant boundary; enabled by default for zero-config self-host. Canonical declaration;
    # services/oss and the SDK read the same variables directly with the same rules.
    enabled_sandbox_providers: List[str] = Field(
        default_factory=_enabled_sandbox_providers_default
    )
    default_sandbox_provider: str = Field(
        default_factory=_default_sandbox_provider_default
    )

    # Direct API -> runner hop for `kill` (W7.3): the same base URL and shared-secret token
    # the Python agent service (services/oss/src/agent/config.py's `runner_url()`) already
    # uses to reach the runner's HTTP surface. None/blank means kill only edits the Redis
    # nest + row (best-effort; the runner's own orphan sweep/TTL expiry still reclaims the
    # sandbox eventually, just not immediately).
    internal_url: Optional[str] = os.getenv("AGENTA_RUNNER_INTERNAL_URL") or None
    token: Optional[str] = os.getenv("AGENTA_RUNNER_TOKEN") or None

    model_config = ConfigDict(extra="ignore")

    @model_validator(mode="after")
    def _warn_local_sandbox(self) -> "RunnerConfig":
        global _SANDBOX_LOCAL_WARNED
        if "local" in self.enabled_sandbox_providers and not _SANDBOX_LOCAL_WARNED:
            _SANDBOX_LOCAL_WARNED = True
            warnings.warn(
                "local sandbox is enabled (default): it is unconfined host bash, not a "
                "tenant boundary. Set AGENTA_RUNNER_ENABLED_SANDBOX_PROVIDERS=daytona to "
                "harden a shared/multi-tenant deployment.",
                stacklevel=2,
            )
        return self


# ---------------------------------------------------------------------------
# store — shared S3-compatible object store
# ---------------------------------------------------------------------------


class StoreConfig(BaseModel):
    """Shared S3-compatible object store credentials.

    Dev points at SeaweedFS; prod points at real S3 / R2 — same code path.
    """

    # Everything except the keys/secrets carries a dev default in code (mirrors RedisConfig):
    # the bundled SeaweedFS store works zero-config, and a self-hosted deploy that uses it
    # inherits the same values; only ACCESS_KEY / SECRET_KEY must be supplied.
    endpoint_url: str | None = (
        os.getenv("AGENTA_STORE_ENDPOINT_URL") or "http://seaweedfs:8333"
    )
    access_key: str | None = os.getenv("AGENTA_STORE_ACCESS_KEY")
    secret_key: str | None = os.getenv("AGENTA_STORE_SECRET_KEY")
    region: str = os.getenv("AGENTA_STORE_REGION") or "us-east-1"
    bucket: str | None = os.getenv("AGENTA_STORE_BUCKET") or "agenta-store"
    namespace: str | None = os.getenv("AGENTA_STORE_NAMESPACE") or None

    # STS endpoint for the GetFederationToken path (non-SeaweedFS stores). Defaults to the S3
    # endpoint (MinIO co-locates STS there); override only when the store splits STS onto
    # another host (AWS: https://sts.<region>.amazonaws.com).
    sts_endpoint_url: str | None = os.getenv("AGENTA_STORE_STS_ENDPOINT_URL") or None

    # Backend selector: SIGNING_KEY present => bundled SeaweedFS (STS via OIDC/web-identity);
    # absent => remote S3-compatible store (STS via GetFederationToken). Also passed to the
    # bundled SeaweedFS as its STS HMAC key; the API only reads it to pick the signing path.
    signing_key: str | None = os.getenv("AGENTA_STORE_SIGNING_KEY") or None

    # AssumeRoleWithWebIdentity issuer (SeaweedFS only): the in-network API URL the store's OIDC
    # IAM uses to fetch our JWKS, and the RSA key signing the web-identity token. The key falls
    # back to a baked-in local-dev key when unset (see core/store/webidentity.py).
    jwt_private_key: str | None = os.getenv("AGENTA_STORE_JWT_PRIVATE_KEY")
    jwt_issuer: str = os.getenv("AGENTA_STORE_JWT_ISSUER") or "http://api:8000"

    model_config = ConfigDict(extra="ignore")

    @property
    def enabled(self) -> bool:
        return bool(self.access_key and self.secret_key)


# ---------------------------------------------------------------------------
# mounts
# ---------------------------------------------------------------------------


class MountsConfig(BaseModel):
    """Mounts-domain config. Store credentials live in StoreConfig."""

    # Lifetime of signed mount credentials, in seconds. The store backends clamp it to their
    # own STS bounds. The default is 43200 (12h) because that is SeaweedFS's maxSessionLength
    # ceiling (AWS GetFederationToken accepts up to 129600), and because it must stay ABOVE the
    # runner's default total run deadline (11h, DEFAULT_TOTAL_DEADLINE_MS in run-limits.ts) plus
    # its 60s lease skew: the runner only reuses a warm sandbox when the lease covers
    # `now + deadline + skew`, so a TTL at or below the deadline forces every mount-backed
    # session to rebuild cold.
    credentials_ttl_seconds: int = Field(
        default_factory=lambda: (
            _parse_optional_positive_int_env("AGENTA_MOUNTS_CREDENTIALS_TTL_SECONDS")
            or 43200
        )
    )

    model_config = ConfigDict(extra="ignore")


# ---------------------------------------------------------------------------
# newrelic
# ---------------------------------------------------------------------------


class NewRelicConfig(BaseModel):
    """New Relic monitoring configuration"""

    license_key: str | None = (
        os.getenv("NEWRELIC_LICENSE_KEY")
        or os.getenv("NEW_RELIC_LICENSE_KEY")
        or os.getenv("NRIA_LICENSE_KEY")
    )

    model_config = ConfigDict(extra="ignore")

    @property
    def enabled(self) -> bool:
        """New Relic enabled if license key present"""
        return bool(self.license_key)


# ---------------------------------------------------------------------------
# postgres
# ---------------------------------------------------------------------------


class PostgresConfig(BaseModel):
    """PostgreSQL database configuration"""

    # Database-name resolution: explicit POSTGRES_URI_* wins; else compose from
    # POSTGRES_DB_PREFIX (e.g. an EE stack adopting an OSS database sets
    # POSTGRES_DB_PREFIX=agenta_oss); else today's default, agenta_{license}.
    db_prefix: str = os.getenv("POSTGRES_DB_PREFIX") or f"agenta_{_LICENSE}"

    user: str = os.getenv("POSTGRES_USER") or "username"
    password: str = os.getenv("POSTGRES_PASSWORD") or "password"
    # The bundled Postgres always listens on 5432 inside the Docker network.
    # POSTGRES_PORT only remaps the host-published port (compose
    # "${POSTGRES_PORT:-5432}:5432") and must NOT feed the in-network URIs below.
    # To point at an external database on a non-default port, set POSTGRES_URI_*.

    # URL-encode credentials so reserved characters (@ : / ? #) in a real
    # password don't corrupt the composed DSN.
    _user_q: str = quote_plus(user)
    _password_q: str = quote_plus(password)

    # How long a checked commit waits for the variant row lock before it gives up. The
    # wait must be bounded, or a stuck holder pins a connection for the whole pool.
    commit_lock_timeout_ms: int = (
        _parse_optional_positive_int_env("POSTGRES_COMMIT_LOCK_TIMEOUT_MS") or 5_000
    )

    uri_core: str = os.getenv("POSTGRES_URI_CORE") or (
        f"postgresql+asyncpg://{_user_q}:{_password_q}@postgres:5432/{db_prefix}_core"
    )
    uri_tracing: str = os.getenv("POSTGRES_URI_TRACING") or (
        f"postgresql+asyncpg://{_user_q}:{_password_q}@postgres:5432/{db_prefix}_tracing"
    )
    uri_supertokens: str = os.getenv("POSTGRES_URI_SUPERTOKENS") or (
        f"postgresql://{_user_q}:{_password_q}@postgres:5432/{db_prefix}_supertokens"
    )

    # Stable signed-64-bit advisory-lock key for this deployment. We mix
    # AGENTA_AUTH_KEY with the core Postgres URI so two deployments that
    # both forget to set AGENTA_AUTH_KEY (and thus share the literal
    # "replace-me" fallback) still get distinct keys as long as they point
    # at different databases.
    advisory_lock: int = int.from_bytes(
        hashlib.blake2b(
            b"|".join(
                (
                    (os.getenv("AGENTA_AUTH_KEY") or "replace-me").encode(),
                    (
                        os.getenv("POSTGRES_URI_CORE")
                        or f"postgresql+asyncpg://username:password@postgres:5432/agenta_{_LICENSE}_core"
                    ).encode(),
                )
            ),
            digest_size=8,
        ).digest(),
        "big",
        signed=True,
    )

    model_config = ConfigDict(extra="ignore")

    # Backwards-compat property for any code reading `username` instead of `user`.
    @property
    def username(self) -> str:
        return self.user


# ---------------------------------------------------------------------------
# posthog
# ---------------------------------------------------------------------------


class PostHogConfig(BaseModel):
    """PostHog Analytics configuration"""

    api_url: str = (
        os.getenv("POSTHOG_API_URL")
        or os.getenv("POSTHOG_HOST")
        or "https://alef.agenta.ai"
    )
    api_key: str | None = (
        os.getenv("POSTHOG_API_KEY")
        or "phc_hmVSxIjTW1REBHXgj2aw4HW9X6CXb6FzerBgP9XenC7"
    )
    # Whether THIS deployment supplied the key, as opposed to falling back to the
    # built-in project key above. `enabled` cannot answer that — the fallback makes it
    # true in every checkout — and a consumer that must tell "this operator runs
    # PostHog" from "this is a stock local stack" needs the difference.
    api_key_configured: bool = bool(os.getenv("POSTHOG_API_KEY"))

    model_config = ConfigDict(extra="ignore")

    @property
    def enabled(self) -> bool:
        """PostHog enabled if API key present"""
        return bool(self.api_key)


# ---------------------------------------------------------------------------
# redis
# ---------------------------------------------------------------------------


class RedisConfig(BaseModel):
    """Redis/Valkey configuration with precedence-based URI resolution"""

    uri: str | None = os.getenv("REDIS_URI")

    uri_volatile: str | None = (
        os.getenv("REDIS_URI_VOLATILE")
        or os.getenv("REDIS_URI")
        or "redis://redis-volatile:6379/0"
    )
    uri_durable: str | None = (
        os.getenv("REDIS_URI_DURABLE")
        or os.getenv("REDIS_URI")
        or "redis://redis-durable:6381/0"
    )

    model_config = ConfigDict(extra="ignore")

    @property
    def enabled(self) -> bool:
        """Redis enabled if URIs are configured"""
        return bool(self.uri_volatile or self.uri_durable)


# ---------------------------------------------------------------------------
# sessions — coordination-plane Redis contract (api/oss/src/dbs/redis/sessions/contract.py)
# ---------------------------------------------------------------------------


class SessionsRedisConfig(BaseModel):
    """TTLs and caps for the session coordination-plane Redis keys.

    Defaults mirror the golden fixture (services/runner/tests/fixtures/sessions/
    redis_contract.json) shared with the TypeScript runner. Do not change a default
    without updating that fixture and the TS side in lockstep.
    """

    alive_ttl_seconds: int = (
        _parse_optional_positive_int_env("AGENTA_SESSIONS_REDIS_ALIVE_TTL_SECONDS")
        or 3600
    )
    running_ttl_seconds: int = (
        _parse_optional_positive_int_env("AGENTA_SESSIONS_REDIS_RUNNING_TTL_SECONDS")
        or 3600
    )
    attached_ttl_seconds: int = (
        _parse_optional_positive_int_env("AGENTA_SESSIONS_REDIS_ATTACHED_TTL_SECONDS")
        or 60
    )
    owner_ttl_seconds: int = (
        _parse_optional_positive_int_env("AGENTA_SESSIONS_REDIS_OWNER_TTL_SECONDS")
        or 120
    )
    heartbeat_interval_seconds: int = (
        _parse_optional_positive_int_env(
            "AGENTA_SESSIONS_REDIS_HEARTBEAT_INTERVAL_SECONDS"
        )
        or 30
    )
    heartbeat_write_threshold_seconds: int = (
        _parse_optional_positive_int_env(
            "AGENTA_SESSIONS_REDIS_HEARTBEAT_WRITE_THRESHOLD_SECONDS"
        )
        or 60
    )
    concurrency_limit: int = (
        _parse_optional_positive_int_env("AGENTA_SESSIONS_REDIS_CONCURRENCY_LIMIT")
        or 1000
    )
    # API-side only (SSE watch endpoint keep-alive cadence) — NOT part of the
    # runner golden fixture; safe to tune without touching the TS side.
    watch_heartbeat_seconds: int = (
        _parse_optional_positive_int_env("AGENTA_SESSIONS_WATCH_HEARTBEAT_SECONDS")
        or 15
    )
    # SSE `retry:` preamble — the browser's OWN auto-reconnect delay after a
    # server-side drop (restart/deploy). Without it the interval is
    # implementation-defined, and a restart reconnect-storms the API.
    watch_retry_milliseconds: int = (
        _parse_optional_positive_int_env("AGENTA_SESSIONS_WATCH_RETRY_MILLISECONDS")
        or 5000
    )
    # API-side only (turn-supersession tombstones) — NOT part of the runner golden
    # fixture; the runner never reads this key, it learns supersession from
    # `is_current_turn`. Defaults to the alive TTL so a tombstone always outlives the
    # lock whose displacement created it.
    superseded_ttl_seconds: int = (
        _parse_optional_positive_int_env("AGENTA_SESSIONS_REDIS_SUPERSEDED_TTL_SECONDS")
        or 3600
    )

    model_config = ConfigDict(extra="ignore")


# ---------------------------------------------------------------------------
# email delivery
# ---------------------------------------------------------------------------


class SmtpConfig(BaseModel):
    """SMTP Email configuration"""

    host: str | None = os.getenv("SMTP_HOST")
    port: int | None = _parse_optional_port_env("SMTP_PORT")
    username: str | None = os.getenv("SMTP_USERNAME")
    password: str | None = os.getenv("SMTP_PASSWORD")
    from_email: str | None = (
        os.getenv("SMTP_FROM_EMAIL")
        or os.getenv("AGENTA_AUTHN_EMAIL_FROM")
        or os.getenv("AGENTA_SEND_EMAIL_FROM_ADDRESS")
    )
    use_tls: bool = _parse_bool_env("SMTP_USE_TLS", default=True)
    use_ssl: bool = _parse_bool_env("SMTP_USE_SSL", default=False)
    timeout: int | None = _parse_optional_positive_int_env("SMTP_TIMEOUT")

    model_config = ConfigDict(extra="ignore")

    @model_validator(mode="after")
    def _validate_security(self) -> "SmtpConfig":
        if self.use_tls and self.use_ssl:
            raise ValueError("SMTP_USE_TLS and SMTP_USE_SSL cannot both be true")

        return self

    @property
    def enabled(self) -> bool:
        """SMTP enabled only if host, port, and sender are present"""
        return bool(self.host and self.port is not None and self.from_email)


class SendgridConfig(BaseModel):
    """SendGrid Email configuration"""

    api_key: str | None = os.getenv("SENDGRID_API_KEY")
    from_email: str | None = (
        os.getenv("SENDGRID_FROM_EMAIL")
        or os.getenv("SENDGRID_FROM_ADDRESS")
        or os.getenv("AGENTA_AUTHN_EMAIL_FROM")
        or os.getenv("AGENTA_SEND_EMAIL_FROM_ADDRESS")
    )

    model_config = ConfigDict(extra="ignore")

    @property
    def enabled(self) -> bool:
        """SendGrid enabled only if API key and sender email are present"""
        return bool(self.api_key and self.from_email)


# ---------------------------------------------------------------------------
# starter_credits_bridge — starter-credit seeding at signup (EE, temporary bridge).
# ---------------------------------------------------------------------------


class StarterCreditsBridgeConfig(BaseModel):
    """Starter-credits bridge (EE): mint a budget-capped proxy key at signup and
    seed it into the new organization's vault as a ready-to-use connection.

    Inert unless `enabled` is true AND `proxy_admin_url` + `proxy_public_url` +
    `master_key` + `team_id` are present (the team's budget ceiling is the
    program's total-exposure bound, so seeding refuses to run without it). The
    redeploy-free runtime switch is the PostHog policy payload: clearing or
    emptying it leaves the policy unresolved, and seeding fails closed.
    """

    enabled: bool = _parse_bool_env("AGENTA_STARTER_CREDITS_BRIDGE_ENABLED", False)

    # Two base URLs for the same proxy, because it is reachable two ways. The
    # public one is what the SEEDED CONNECTION stores, so a sandboxed run can
    # reach the proxy's inference paths from outside; only those paths are
    # publicly routed. The admin routes (/key/generate, /key/block, /team/info)
    # are not, so the master-keyed admin client dials the proxy's internal
    # address instead — and the master key never leaves the private network.
    proxy_public_url: str | None = (
        os.getenv("AGENTA_STARTER_CREDITS_BRIDGE_PROXY_PUBLIC_URL") or None
    )
    proxy_admin_url: str | None = (
        os.getenv("AGENTA_STARTER_CREDITS_BRIDGE_PROXY_ADMIN_URL") or None
    )
    master_key: str | None = (
        os.getenv("AGENTA_STARTER_CREDITS_BRIDGE_MASTER_KEY") or None
    )
    # Every minted key joins this team; its max_budget is the program ceiling.
    team_id: str | None = os.getenv("AGENTA_STARTER_CREDITS_BRIDGE_TEAM_ID") or None

    model_id: str = (
        os.getenv("AGENTA_STARTER_CREDITS_BRIDGE_MODEL_ID")
        or "vertex_ai/gemini-3.7-flash"
    )

    # The mint policy (velocity caps, domain classification, eligibility rules,
    # grant size, per-key limits) ships via the PostHog policy flag's payload:
    # the payload is the only source, so no real value lives in source and no
    # money value can be changed one field at a time on a single deployment.
    # Without a resolvable payload the policy is unresolved and seeding fails
    # closed. Only the flag's NAME is configurable here.
    #
    # One exception, for developer convenience: a deployment with NO PostHog
    # configured at all (local dev, a QA stack) runs on the built-in development
    # policy in `starter_credits_bridge/types.py` instead of being blocked, since
    # it has no way to publish a payload. Cloud always has PostHog, so it always
    # takes the payload path and still fails closed on a missing or bad one.
    policy_flag: str = (
        os.getenv("AGENTA_STARTER_CREDITS_BRIDGE_POLICY_FLAG")
        or "starter-credits-bridge-policy"
    )
    # Optional operator webhook ({"text": ...} POST) for refusals and failures.
    alert_webhook: str | None = (
        os.getenv("AGENTA_STARTER_CREDITS_BRIDGE_ALERT_WEBHOOK") or None
    )

    model_config = ConfigDict(extra="ignore")

    @property
    def armed(self) -> bool:
        """True when the deployment opted in and holds both proxy addresses and
        the proxy credentials, plus the program team whose ceiling bounds total
        exposure. Without the admin address every mint would dial a route that is
        not publicly served, so a missing one keeps the bridge inert."""
        return bool(
            self.enabled
            and self.proxy_public_url
            and self.proxy_admin_url
            and self.master_key
            and self.team_id
        )


# ---------------------------------------------------------------------------
# stripe
# ---------------------------------------------------------------------------


class StripeConfig(BaseModel):
    """Stripe Billing configuration"""

    api_key: str | None = os.getenv("STRIPE_API_KEY")
    webhook_secret: str | None = os.getenv("STRIPE_WEBHOOK_SECRET")
    webhook_target: str | None = (
        os.getenv("STRIPE_WEBHOOK_TARGET") or os.getenv("STRIPE_TARGET") or MAC_ADDRESS
    )

    model_config = ConfigDict(extra="ignore")

    @property
    def enabled(self) -> bool:
        """Stripe enabled if API key present"""
        return bool(self.api_key)


# ---------------------------------------------------------------------------
# supertokens
# ---------------------------------------------------------------------------


class SuperTokensConfig(BaseModel):
    """SuperTokens provider configuration"""

    api_key: str | None = os.getenv("SUPERTOKENS_API_KEY")
    application: str = os.getenv("SUPERTOKENS_APPLICATION") or "default"

    # ---------------------------------------------------------------------------
    # Password policy
    # ---------------------------------------------------------------------------
    password_max_length: int | None = (
        int(os.getenv("SUPERTOKENS_PASSWORD_MAX_LENGTH"))
        if os.getenv("SUPERTOKENS_PASSWORD_MAX_LENGTH")
        else None
    )
    password_min_length: int = int(os.getenv("SUPERTOKENS_PASSWORD_MIN_LENGTH") or "8")
    password_policy: str = os.getenv("SUPERTOKENS_PASSWORD_POLICY") or "strong"
    password_regex: str | None = os.getenv("SUPERTOKENS_PASSWORD_REGEX") or None

    tenant: str = os.getenv("SUPERTOKENS_TENANT") or "tenant"

    uri_core: str = (
        os.getenv("SUPERTOKENS_URI_CORE")
        or os.getenv("SUPERTOKENS_CONNECTION_URI")
        or "http://supertokens:3567"
    )

    model_config = ConfigDict(extra="ignore")

    @property
    def enabled(self) -> bool:
        """SuperTokens enabled if both connection URI and API key present"""
        return bool(self.uri_core and self.api_key)

    def validate_config(self) -> None:
        """Validate SuperTokens configuration"""
        if not self.enabled:
            raise ValueError(
                "SuperTokens configuration required:\n"
                "  - SUPERTOKENS_URI_CORE\n"
                "  - SUPERTOKENS_API_KEY\n"
            )


# ---------------------------------------------------------------------------
# Triggers
# ---------------------------------------------------------------------------


class TriggersConfig(BaseModel):
    """Guardrails for trigger schedules."""

    # The smallest gap allowed between two consecutive fires of a schedule's cron
    # expression. Every fire starts an agent run in its own sandbox, so `* * * * *`
    # bills 1440 runs a day; and because a run routinely outlives one minute, such a
    # schedule also overlaps itself. Enforced on create and edit only, so rows stored
    # before the floor existed keep firing until someone edits them.
    #
    # The web mirrors this default as MIN_CRON_INTERVAL_MINUTES so the drawer can
    # reject a value before submitting. Lowering this below that constant makes the
    # client stricter than the server until the two are changed together.
    schedule_min_interval_minutes: int = (
        _parse_optional_positive_int_env(
            "AGENTA_TRIGGERS_SCHEDULE_MIN_INTERVAL_MINUTES"
        )
        or 15
    )


# ---------------------------------------------------------------------------
# Auth — derived flags. Kept as a convenience facade reading from
# identity.* (OIDC) and agenta.access.email_disabled (email).
# ---------------------------------------------------------------------------


class AuthFacade(BaseModel):
    """Derived auth flags.

    This is a thin facade. The source of truth lives in:
      - `env.agenta.access.email_disabled` (email kill switch)
      - `env.identity.<provider>.enabled` (OIDC providers)
      - `env.cloudflare.turnstile.*` (captcha)
    """

    model_config = ConfigDict(extra="ignore")

    @property
    def email_method(self) -> str:
        """Returns email auth method: 'password', 'otp', or '' (disabled)"""
        if env.agenta.access.email_disabled:
            return ""

        return "otp" if env.smtp.enabled or env.sendgrid.enabled else "password"

    @property
    def email_enabled(self) -> bool:
        return self.email_method != ""

    @property
    def oidc_enabled(self) -> bool:
        return env.identity.any_oidc_enabled

    @property
    def any_enabled(self) -> bool:
        return self.email_enabled or self.oidc_enabled

    def validate_config(self) -> None:
        if not self.any_enabled:
            raise ValueError(
                "At least one authentication method must be configured:\n"
                "  - AGENTA_ACCESS_EMAIL_DISABLED must be false (or unset) for email auth\n"
                "  - Any supported OAuth provider credentials, e.g.\n"
                "    GOOGLE_OAUTH_CLIENT_ID + GOOGLE_OAUTH_CLIENT_SECRET\n"
                "    GITHUB_OAUTH_CLIENT_ID + GITHUB_OAUTH_CLIENT_SECRET\n"
            )


# ---------------------------------------------------------------------------
# EnvironSettings — the singleton container.
# ---------------------------------------------------------------------------


class EnvironSettings(BaseModel):
    """
    Main environment settings container with nested Pydantic models.

    The shape mirrors the canonical mapping documented at
    https://docs.agenta.ai/self-host/configuration — env var name,
    env.py attribute path, and helm values.yaml path all encode the
    same nesting.
    """

    agenta: AgentaConfig = AgentaConfig()
    alembic: AlembicConfig = AlembicConfig()
    auth: AuthFacade = AuthFacade()
    cloudflare: CloudflareConfig = CloudflareConfig()
    composio: ComposioConfig = ComposioConfig()
    crisp: CrispConfig = CrispConfig()
    daytona: DaytonaConfig = DaytonaConfig()
    docker: DockerConfig = DockerConfig()
    identity: IdentityConfig = IdentityConfig()
    llm: LLMConfig = LLMConfig()
    loops: LoopsConfig = LoopsConfig()
    mounts: MountsConfig = MountsConfig()
    newrelic: NewRelicConfig = NewRelicConfig()
    postgres: PostgresConfig = PostgresConfig()
    posthog: PostHogConfig = PostHogConfig()
    redis: RedisConfig = RedisConfig()
    runner: RunnerConfig = RunnerConfig()
    sessions: SessionsRedisConfig = SessionsRedisConfig()
    smtp: SmtpConfig = SmtpConfig()
    sendgrid: SendgridConfig = SendgridConfig()
    starter_credits_bridge: StarterCreditsBridgeConfig = StarterCreditsBridgeConfig()
    store: StoreConfig = StoreConfig()
    stripe: StripeConfig = StripeConfig()
    supertokens: SuperTokensConfig = SuperTokensConfig()
    triggers: TriggersConfig = TriggersConfig()

    model_config = ConfigDict(extra="ignore")


# Create singleton global env instance
env = EnvironSettings()
