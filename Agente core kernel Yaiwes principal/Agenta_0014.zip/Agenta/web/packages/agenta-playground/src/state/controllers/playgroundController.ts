/**
 * Playground Controller
 *
 * Provides a unified API for managing playground nodes, modal state,
 * and related operations.
 *
 * ## Usage
 *
 * ```typescript
 * import { playgroundController } from '@agenta/playground'
 *
 * // Selectors (functions that return atoms)
 * const nodes = useAtomValue(useMemo(() => playgroundController.selectors.nodes(), []))
 *
 * // Dispatch for standard actions
 * const dispatch = useSetAtom(playgroundController.dispatch)
 * dispatch({ type: 'selectNode', nodeId: 'node-123' })
 *
 * // Compound actions for multi-step operations
 * const addPrimary = useSetAtom(playgroundController.actions.addPrimaryNode)
 * addPrimary({ type: 'workflow', id: 'rev-123', label: 'My Revision' })
 * ```
 */

import {loadableStateAtomFamily} from "@agenta/entities/loadable"
import {loadableController, snapshotAdapterRegistry} from "@agenta/entities/runnable"
import {fetchTestcasesPage, testcaseMolecule} from "@agenta/entities/testcase"
import type {TraceSpan, TraceSpanNode} from "@agenta/entities/trace"
import {extractAgData, extractInputs, extractOutputs} from "@agenta/entities/trace"
import {
    workflowMolecule,
    createEphemeralWorkflow,
    buildWorkflowUri,
} from "@agenta/entities/workflow"
import {
    commitWorkflowRevisionAtom,
    archiveWorkflowRevisionAtom,
    createWorkflowVariantAtom,
} from "@agenta/entities/workflow"
import {projectIdAtom} from "@agenta/shared/state"
import {atom} from "jotai"
import type {Getter, Setter} from "jotai"

import type {SnapshotLoadableConnection, SnapshotLocalTestset} from "../../snapshot"
import {outputConnectionsAtom} from "../atoms/connections"
import {
    connectedTestsetAtom,
    editingConnectionIdAtom,
    entityIdsAtom,
    extraColumnsAtom,
    hasMultipleNodesAtom,
    mappingModalOpenAtom,
    playgroundStoreAtom,
    playgroundDispatchAtom,
    playgroundNodesAtom,
    selectedNodeIdAtom,
    testsetModalOpenAtom,
} from "../atoms/playground"
import {executionByMessageIdAtomFamily, messageIdsAtomFamily, messagesByIdAtomFamily} from "../chat"
import type {ChatMessage} from "../chat"
import type {
    AppRevisionCommitPayload,
    AppRevisionCreateVariantPayload,
    AppRevisionCrudResult,
} from "../context"
import {createInitialExecutionState, executionStateAtomFamily} from "../execution"
import type {ExecutionSession, RunResult} from "../execution"
import {
    displayedEntityIdsAtom,
    isComparisonViewAtom,
    playgroundLayoutAtom,
    playgroundRevisionsReadyAtom,
    playgroundStatusAtom,
    resolvedEntityIdsAtom,
    schemaInputKeysAtom,
} from "../execution/displayedEntities"
import {
    derivedLoadableIdAtom,
    hiddenTestcaseCountAtom,
    inputVariableNamesAtom,
    isChatModeAtom,
    newTestcaseCountAtom,
    newTestcaseDataHashAtom,
} from "../execution/selectors"
import {pruneDanglingConnections} from "../helpers/connectionGraph"
import {
    collectDownstreamReferencedColumns,
    collectTestsetServerColumns,
    reconcileRowDataForEntity,
    resolveEntityInputContract,
} from "../helpers/entityInputContract"
import {extractAndLoadChatMessagesAtom} from "../helpers/extractAndLoadChatMessages"
import {normalizeTestcaseRowsForLoad} from "../helpers/testcaseRowNormalization"
import type {EntitySelection, PlaygroundNode, RunnableType} from "../types"

import {extractReferences, resolveTraceRefs} from "./traceRefResolution"
import {getRunnableTypeResolver} from "./urlSnapshotController"

// Import loadable state from entities (stays there due to entity dependencies)

// ============================================================================
// COMPOUND ACTION PAYLOAD TYPES
// ============================================================================

/**
 * Payload for connecting to a testset (load mode)
 */
export interface ConnectToTestsetPayload {
    loadableId: string
    revisionId: string
    testcases: ({id?: string} & Record<string, unknown>)[]
    testsetName?: string
    testsetId?: string | null
    revisionVersion?: number | null
}

/**
 * Payload for importing testcases (import mode - no connection)
 */
interface ImportTestcasesPayload {
    loadableId: string
    testcases: Record<string, unknown>[]
}

/**
 * Payload for adding a row with testset initialization
 */
interface AddRowWithInitPayload {
    loadableId: string
    data?: Record<string, unknown>
    entityLabel?: string
}

/**
 * Payload for adding/removing extra columns
 */
interface ExtraColumnPayload {
    loadableId: string
    key: string
    name?: string
}

/**
 * Payload for adding output mapping columns
 */
interface OutputMappingColumnPayload {
    loadableId: string
    name: string
}

// ============================================================================
// COMPOUND ACTIONS
// ============================================================================

/**
 * Generate a default local testset name from entity label and current date
 */
function generateLocalTestsetName(entityLabel?: string): string {
    const date = new Date()
    const dateStr = date.toLocaleDateString("en-US", {
        month: "short",
        day: "numeric",
    })
    const timeStr = date.toLocaleTimeString("en-US", {
        hour: "numeric",
        minute: "2-digit",
    })
    const baseName = entityLabel || "Local"
    return `${baseName} - ${dateStr}, ${timeStr}`
}

function asNonEmptyString(value: unknown): string | undefined {
    if (typeof value !== "string") return undefined
    const trimmed = value.trim()
    return trimmed.length > 0 ? trimmed : undefined
}

/**
 * Add a primary node (first runnable in the playground)
 *
 * This compound action:
 * 1. Creates the playground node
 * 2. Links the loadable to the runnable (columns are then derived reactively)
 * 3. Creates an initial empty row for testcases
 * 4. Sets up a local testset with a generated name
 */
const addPrimaryNodeAtom = atom(
    null,
    (get, set, entity: EntitySelection, options?: {skipInitialRow?: boolean}) => {
        const nodeId = `node-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`
        const node: PlaygroundNode = {
            id: nodeId,
            entityType: entity.type,
            entityId: entity.id,
            label: entity.label,
            depth: 0,
        }

        // Reset state and add the primary node
        set(playgroundNodesAtom, [node])
        set(selectedNodeIdAtom, nodeId)
        set(outputConnectionsAtom, [])

        // Set up local testset with generated name from entity label
        const localTestsetName = generateLocalTestsetName(entity.label)
        set(connectedTestsetAtom, {
            id: null, // null id indicates it's a local (unsaved) testset
            name: localTestsetName,
        })

        // Link the loadable to the runnable and create initial row
        // This triggers reactive column derivation from runnable's inputSchema
        const loadableId = `testset:${entity.type}:${entity.id}`

        // Clear stale execution results before linking.
        // The loadable ID is entity-scoped, so a previous session with the same
        // entity (e.g. same app selected for a different evaluator) would leave
        // results in the atom family that shouldn't appear in a fresh playground.
        const prevState = get(loadableStateAtomFamily(loadableId))
        if (Object.keys(prevState.executionResults).length > 0) {
            set(loadableStateAtomFamily(loadableId), {
                ...prevState,
                executionResults: {},
            })
        }

        // Use loadableController action which handles row creation via testcaseMolecule
        // skipInitialRow defers row creation when a loadable/localTestset restore will follow
        set(
            loadableController.actions.linkToRunnable,
            loadableId,
            entity.type as RunnableType,
            entity.id,
            options?.skipInitialRow ? {skipInitialRow: true} : undefined,
        )

        return nodeId
    },
)

/**
 * Add a downstream node (receiver of output from another node)
 */
const addDownstreamNodeAtom = atom(
    null,
    (get, set, params: {sourceNodeId: string; entity: EntitySelection}) => {
        const {sourceNodeId, entity} = params
        const nodes = get(playgroundNodesAtom)

        // Find source node to determine depth
        const sourceNode = nodes.find((n) => n.id === sourceNodeId)
        if (!sourceNode) return null

        const nodeId = `node-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`
        const node: PlaygroundNode = {
            id: nodeId,
            entityType: entity.type,
            entityId: entity.id,
            label: entity.label,
            depth: sourceNode.depth + 1,
        }

        set(playgroundNodesAtom, [...nodes, node])
        _onSelectionChange?.(get(entityIdsAtom), [])

        return {
            nodeId,
            sourceNodeId,
        }
    },
)

/**
 * Remove a node and return removed connection IDs
 */
const removeNodeAtom = atom(null, (get, set, nodeId: string): string[] => {
    const nodes = get(playgroundNodesAtom)
    const nodeIndex = nodes.findIndex((n) => n.id === nodeId)

    if (nodeIndex === -1) return []
    const removedEntityId = nodes[nodeIndex]?.entityId

    // If removing primary node, reset everything
    if (nodeIndex === 0) {
        set(playgroundNodesAtom, [])
        set(selectedNodeIdAtom, null)
        set(outputConnectionsAtom, [])
        _onSelectionChange?.([], removedEntityId ? [removedEntityId] : [])
        return ["__clear_all__"]
    }

    // Remove just this node
    set(
        playgroundNodesAtom,
        nodes.filter((n) => n.id !== nodeId),
    )
    set(
        outputConnectionsAtom,
        get(outputConnectionsAtom).filter(
            (connection) =>
                connection.sourceNodeId !== nodeId && connection.targetNodeId !== nodeId,
        ),
    )

    // Update selection if needed
    const currentSelection = get(selectedNodeIdAtom)
    if (currentSelection === nodeId) {
        set(selectedNodeIdAtom, nodes[0]?.id ?? null)
    }

    _onSelectionChange?.(get(entityIdsAtom), removedEntityId ? [removedEntityId] : [])

    return [nodeId]
})

/**
 * Connect a downstream node.
 *
 * This compound action atomically:
 * 1. Adds the new downstream node
 * 2. Creates the output connection
 *
 * Multiple downstream nodes of the same entity type are allowed (e.g. multiple evaluators).
 * If the exact same entity (by ID) is already connected, the call is a no-op.
 *
 * Use this instead of manually calling addDownstreamNode + addConnection
 * to keep the UI decoupled from state management details.
 */
const connectDownstreamNodeAtom = atom(
    null,
    (
        get,
        set,
        params: {sourceNodeId: string; entity: EntitySelection},
    ): {nodeId: string; sourceNodeId: string} | null => {
        const {sourceNodeId, entity} = params
        const nodes = get(playgroundNodesAtom)

        // Skip if this exact entity is already connected as a downstream node
        const alreadyConnected = nodes.some((n) => n.depth > 0 && n.entityId === entity.id)
        if (alreadyConnected) return null

        // Add the new downstream node
        const result = set(addDownstreamNodeAtom, {sourceNodeId, entity})
        if (!result) return null

        // Create the connection
        const connections = get(outputConnectionsAtom)
        const connectionId = `conn-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`
        set(outputConnectionsAtom, [
            ...connections,
            {
                id: connectionId,
                sourceNodeId: result.sourceNodeId,
                targetNodeId: result.nodeId,
                sourceOutputKey: "output",
                inputMappings: [],
                parallel: true,
            },
        ])

        // For downstream entities, eagerly subscribe to the molecule's query atom
        // so the per-ID fetch fires immediately.
        if (entity.type === "workflow") {
            const store = get(playgroundStoreAtom)
            const unsub = store.sub(workflowMolecule.selectors.data(entity.id), () => {})
            // Unsubscribe after a generous window — the query cache keeps the data alive.
            setTimeout(() => unsub(), 60_000)
        }

        return result
    },
)

/**
 * Disconnect all downstream nodes of a given entity type.
 */
const disconnectDownstreamNodeAtom = atom(null, (get, set, entityType: string) => {
    const nodes = get(playgroundNodesAtom)
    const toRemove = nodes.filter((n) => n.depth > 0 && n.entityType === entityType)
    for (const node of toRemove) {
        set(removeNodeAtom, node.id)
    }
})

/**
 * Disconnect a single downstream node by its node ID.
 */
const disconnectSingleDownstreamNodeAtom = atom(null, (get, set, nodeId: string) => {
    const nodes = get(playgroundNodesAtom)
    const node = nodes.find((n) => n.id === nodeId && n.depth > 0)
    if (node) {
        set(removeNodeAtom, node.id)
    }
})

/**
 * Change the primary node (swap the first runnable)
 *
 * This compound action:
 * 1. Updates the playground node
 * 2. Links the loadable to the new runnable
 * 3. Updates the local testset name if not connected to a remote testset
 */
const changePrimaryNodeAtom = atom(null, (get, set, entity: EntitySelection) => {
    const nodes = get(playgroundNodesAtom)

    if (nodes.length === 0) {
        // No nodes, just add as primary
        return set(addPrimaryNodeAtom, entity)
    }

    // Update the primary node in place
    const nodeId = nodes[0].id
    const updatedNode: PlaygroundNode = {
        ...nodes[0],
        entityType: entity.type,
        entityId: entity.id,
        label: entity.label,
    }

    const nextNodes = [updatedNode, ...nodes.slice(1)]
    set(playgroundNodesAtom, nextNodes)

    // Preserve downstream connections instead of clearing them. The primary
    // node is updated in place, so its `id` is unchanged and any chain sourced
    // from it (e.g. app → evaluator) stays valid. Clearing unconditionally
    // orphaned the downstream evaluator on app-revision re-selection:
    // connectDownstreamNode then no-ops because the evaluator node is still
    // present, so the edge was never recreated and the evaluator silently
    // stopped running. Only drop connections whose endpoints no longer exist.
    set(outputConnectionsAtom, pruneDanglingConnections(get(outputConnectionsAtom), nextNodes))

    // Update local testset name if not connected to a remote testset
    const currentTestset = get(connectedTestsetAtom)
    if (!currentTestset?.id) {
        // Local testset - update name based on new entity
        const localTestsetName = generateLocalTestsetName(entity.label)
        set(connectedTestsetAtom, {
            id: null,
            name: localTestsetName,
        })
    }

    // Clear stale execution results before linking to the new runnable.
    // This prevents results from a previous session (e.g. a different evaluator
    // that tested the same app) from leaking into the current playground.
    const loadableId = `testset:${entity.type}:${entity.id}`
    const prevState = get(loadableStateAtomFamily(loadableId))
    if (Object.keys(prevState.executionResults).length > 0) {
        set(loadableStateAtomFamily(loadableId), {
            ...prevState,
            executionResults: {},
        })
    }

    // Link the loadable to the new runnable via controller API
    set(
        loadableController.actions.linkToRunnable,
        loadableId,
        entity.type as RunnableType,
        entity.id,
    )

    return nodeId
})

/**
 * Reset playground state and clear output connections.
 */
const resetAllAtom = atom(null, (_get, set) => {
    set(playgroundDispatchAtom, {type: "reset"})
    set(outputConnectionsAtom, [])
})

/**
 * Disconnect from testset and reset to local mode
 *
 * This compound action:
 * 1. Snapshots current rows when `preserveRows` is true (must happen before disconnect)
 * 2. Calls loadable disconnect (clears connectedSourceId, testcase IDs)
 * 3. Regenerates a local testset name from the primary node's label
 * 4. Re-populates with snapshotted rows or creates an initial empty row
 *
 * When `preserveRows` is false (default), the playground returns to the same
 * state as initial setup. When true (e.g. after "Save & disconnect"), the
 * committed data stays visible as local rows.
 */
const disconnectAndResetToLocalAtom = atom(
    null,
    (get, set, loadableId: string, options?: {preserveRows?: boolean}) => {
        const rootNode = get(playgroundNodesAtom).find((n) => n.depth === 0)
        if (!rootNode) return

        // 1. Snapshot current rows before disconnect wipes testcase IDs
        const rowsSnapshot = options?.preserveRows
            ? get(loadableController.selectors.rows(loadableId))
            : null

        // 2. Call loadable disconnect action
        set(loadableController.actions.disconnect, loadableId)

        // 3. Generate and set local testset name
        const localTestsetName = generateLocalTestsetName(rootNode.label)
        set(connectedTestsetAtom, {
            id: null, // null id indicates it's a local (unsaved) testset
            name: localTestsetName,
        })

        // 4. Re-populate with snapshotted rows or create an initial empty row
        if (rowsSnapshot && rowsSnapshot.length > 0) {
            for (const row of rowsSnapshot) {
                set(loadableController.actions.addRow, loadableId, row.data ?? {})
            }
        } else {
            set(loadableController.actions.addRow, loadableId, {})
        }
    },
)

// ============================================================================
// WP1: TESTSET CONNECTION COMPOUND ACTIONS
// ============================================================================

/**
 * Connect to a testset (load mode)
 *
 * This compound action handles the "load" mode of testset selection:
 * 1. Generates a display name from testset name and version
 * 2. Ensures testcases have IDs
 * 3. Calls loadable.connectToSource
 * 4. Updates connectedTestsetAtom with name and id
 *
 * This encapsulates the logic from handleSelectionConfirm in load mode.
 */
const connectToTestsetAtom = atom(null, (get, set, payload: ConnectToTestsetPayload) => {
    const {loadableId, revisionId, testcases, testsetName, testsetId, revisionVersion} = payload

    // Generate a fallback display name from the available selection info
    const displayName = testsetName
        ? revisionVersion != null
            ? `${testsetName} (v${revisionVersion})`
            : testsetName
        : undefined

    const normalizedRows = normalizeTestcaseRowsForLoad(testcases)

    // Ensure testcases have IDs and store them in nested testcase formatat
    const allTestcasesWithIds = normalizedRows.map((row, index) => {
        const id = row.id ?? `testcase-${Date.now()}-${index}`
        return {id, data: row.data}
    })

    // Chat-mode single-row gate. Per Mahmoud's QA on 2026-06-01
    // (Slack #release-v100), chat playgrounds must load ONE testcase only —
    // multi-row sync concatenates all rows' messages into a single shared
    // thread (see `extractAndLoadChatMessagesAtom` iteration over
    // `datasetMessages`), which produces a nonsensical "row 1 user → row 1
    // assistant → row 2 user → row 2 assistant → …" stream. The legacy OSS
    // `LoadTestsetButton` flow enforced this by construction; the new
    // package-resident path generalised to N rows and lost the gate.
    //
    // Slicing here is the source of truth for the constraint — both
    // `connectToSource` (the loadable row list) and
    // `extractAndLoadChatMessagesAtom` (the chat message seed) receive the
    // narrowed list. The defensive isChat check inside the seed atom is a
    // backup for entrypoints that bypass this controller.
    const isChat = get(isChatModeAtom) ?? false
    const testcasesWithIds = isChat ? allTestcasesWithIds.slice(0, 1) : allTestcasesWithIds
    const flatRows = testcasesWithIds.map(({id, data}) => ({id, ...data}))

    // Connect to source via loadable controller
    set(
        loadableController.actions.connectToSource,
        loadableId,
        revisionId,
        displayName,
        testcasesWithIds,
    )

    // Update playground's connectedTestset state
    set(connectedTestsetAtom, {
        name: displayName ?? null,
        id: testsetId ?? null,
    })

    // Extract chat messages from testcase rows if in chat mode.
    // The entity layer stores `messages` as a regular data column, but the
    // playground chat UI reads from messageIdsAtomFamily/messagesByIdAtomFamily.
    // Without this step, inputPorts load correctly but chat messages are lost.
    if (isChat) {
        set(extractAndLoadChatMessagesAtom, {
            loadableId,
            testcaseRows: flatRows,
            skipBlankMessage: true,
        })
    }
})

/**
 * Import testcases (import mode - no connection)
 *
 * This compound action handles the "import" mode of testset selection:
 * 1. Imports the testcases as local rows
 * 2. Does NOT update connectedTestset (stays in local mode)
 *
 * This encapsulates the logic from handleSelectionConfirm in import mode.
 */
const importTestcasesAtom = atom(null, (get, set, payload: ImportTestcasesPayload) => {
    const {loadableId, testcases} = payload
    const normalizedRows = normalizeTestcaseRowsForLoad(testcases)
    const allFlatRows = normalizedRows.map(({id, data}) => (id ? {id, ...data} : {...data}))

    // Same chat-mode single-row gate as `connectToTestsetAtom` — see that
    // atom's comments for the full rationale. Import mode shares the chat
    // seed pathway, so the gate must mirror.
    const isChat = get(isChatModeAtom) ?? false
    const flatRows = isChat ? allFlatRows.slice(0, 1) : allFlatRows

    // Import rows via loadable controller (stays in local mode)
    set(loadableController.actions.importRows, loadableId, flatRows)

    // Extract chat messages from imported testcase rows if in chat mode.
    // Same reasoning as connectToTestsetAtom — the entity layer stores `messages`
    // as data but the chat UI needs them in the message atom system.
    if (isChat) {
        set(extractAndLoadChatMessagesAtom, {
            loadableId,
            testcaseRows: flatRows,
            skipBlankMessage: true,
        })
    }
})

/**
 * Connect to a testset while keeping the current local draft rows.
 *
 * `connectToSource` clears all local entities, so rows created manually or
 * from a trace are destroyed by a plain connect. This action captures the
 * meaningful local rows first, connects, then re-imports the captured rows
 * as unsaved additions (`newEntityIdsAtom`), which turns on hasLocalChanges
 * and lets the user sync them into the test set via the commit flow.
 *
 * Chat playgrounds load a single testcase (see the gate in
 * `connectToTestsetAtom`), so kept rows cannot be appended there; this
 * action falls back to a plain connect in chat mode. Callers should warn
 * instead of offering "keep" for chat.
 */
const connectToTestsetKeepingLocalRowsAtom = atom(
    null,
    (get, set, payload: ConnectToTestsetPayload) => {
        const isChat = get(isChatModeAtom) ?? false
        const captured = isChat
            ? []
            : get(loadableController.selectors.meaningfulLocalRows(payload.loadableId))

        set(connectToTestsetAtom, payload)

        if (captured.length > 0) {
            // Strip the old local IDs so importRows creates fresh entities
            // instead of dedup-checking against IDs the connect just cleared.
            set(importTestcasesAtom, {
                loadableId: payload.loadableId,
                testcases: captured.map(({data}) => ({...data})),
            })
        }
    },
)

// ============================================================================
// WP2: ROW WITH INIT COMPOUND ACTION
// ============================================================================

/**
 * Add a row with local testset initialization
 *
 * This compound action handles the row addition logic:
 * 1. If first row and not connected to remote testset, generates a local testset name
 * 2. Adds the row via loadable controller
 *
 * This encapsulates the logic from handleAddRow in PlaygroundContent.
 */
const addRowWithInitAtom = atom(null, (get, set, payload: AddRowWithInitPayload) => {
    const {loadableId, data, entityLabel} = payload

    // Check if we need to initialize local testset name
    const connectedTestset = get(connectedTestsetAtom)
    const rowCount = get(loadableController.selectors.rowCount(loadableId))

    if (rowCount === 0 && !connectedTestset?.id) {
        // First row in local mode - generate local testset name
        const localTestsetName = generateLocalTestsetName(entityLabel)
        set(connectedTestsetAtom, {
            id: null,
            name: localTestsetName,
        })
    }

    // Add the row via loadable controller
    set(loadableController.actions.addRow, loadableId, data)
})

// ============================================================================
// WP3: EXTRA COLUMN COMPOUND ACTIONS
// ============================================================================

/**
 * Add an extra column (coordinated across playground and loadable state)
 *
 * This compound action:
 * 1. Validates the column key doesn't already exist
 * 2. Updates playground extraColumns state
 * 3. Updates loadable columns via controller
 *
 * This encapsulates the logic from handleAddExtraColumn in PlaygroundContent.
 */
const addExtraColumnAtom = atom(
    null,
    (get, set, payload: ExtraColumnPayload & {existingColumnKeys?: string[]}) => {
        const {loadableId, key, name, existingColumnKeys = []} = payload

        // Validate key doesn't already exist
        const currentExtraColumns = get(extraColumnsAtom)
        const existingKeys = new Set([
            ...existingColumnKeys,
            ...currentExtraColumns.map((c) => c.key),
        ])

        if (existingKeys.has(key)) return false

        // Update playground extraColumns state
        set(playgroundDispatchAtom, {type: "addExtraColumn", key, name: name ?? key})

        // Update loadable columns via controller
        set(loadableController.actions.addColumn, loadableId, {
            key,
            name: name ?? key,
            type: "string",
        })

        return true
    },
)

/**
 * Remove an extra column (coordinated across playground and loadable state)
 *
 * This compound action:
 * 1. Updates playground extraColumns state
 * 2. Updates loadable columns via controller
 *
 * This encapsulates the logic from handleRemoveExtraColumn in PlaygroundContent.
 */
const removeExtraColumnAtom = atom(null, (get, set, payload: ExtraColumnPayload) => {
    const {loadableId, key} = payload

    // Update playground extraColumns state
    set(playgroundDispatchAtom, {type: "removeExtraColumn", key})

    // Update loadable columns via controller
    set(loadableController.actions.removeColumn, loadableId, key)
})

// ============================================================================
// WP4: OUTPUT MAPPING COLUMN COMPOUND ACTION
// ============================================================================

/**
 * Normalize a column name to a key format
 * Converts to lowercase and replaces whitespace with underscores
 */
function normalizeColumnKey(name: string): string {
    return name.toLowerCase().replace(/\s+/g, "_")
}

/**
 * Add an output mapping column (adds to loadable columns only, not to extraColumns)
 *
 * This compound action:
 * 1. Normalizes the column name to a key
 * 2. Validates the column key doesn't already exist
 * 3. Adds the column to loadable via controller
 *
 * This encapsulates the logic from handleAddOutputMappingColumn in PlaygroundContent,
 * following the playground-compound-actions rule.
 */
const addOutputMappingColumnAtom = atom(
    null,
    (get, set, payload: OutputMappingColumnPayload): boolean => {
        const {loadableId, name} = payload
        const key = normalizeColumnKey(name)

        // Get existing column keys for validation using selector pattern
        const columnsAtom = loadableController.selectors.columns(loadableId)
        const columns = get(columnsAtom)
        const extraColumns = get(extraColumnsAtom)
        const existingKeys = new Set([
            ...columns.map((c) => c.key),
            ...extraColumns.map((c) => c.key),
        ])

        // Validate key doesn't already exist
        if (existingKeys.has(key)) return false

        // Add column via loadable controller (not to extraColumns)
        set(loadableController.actions.addColumn, loadableId, {
            key,
            name,
            type: "string",
        })

        return true
    },
)

// ============================================================================
// TESTSET CONNECTION RESTORE (URL snapshot hydration)
// ============================================================================

/**
 * Restore a testset connection from a URL snapshot.
 *
 * Called after the primary playground node has been set up (nodes are populated),
 * so derivedLoadableIdAtom returns a valid loadable ID.
 *
 * This compound action:
 * 1. Fetches all testcases for the revision (paginated)
 * 2. Reconnects via the loadable layer (populates query cache, sets testcaseIdsAtom)
 * 3. Updates connectedTestsetAtom for the dropdown display
 */
const restoreLoadableConnectionAtom = atom(
    null,
    async (get, set, loadable: SnapshotLoadableConnection) => {
        const loadableId = get(derivedLoadableIdAtom)
        if (!loadableId) return

        const projectId = get(projectIdAtom)
        if (!projectId) return

        // Fetch all testcases for the revision (paginated)
        const allTestcases: ({id: string} & Record<string, unknown>)[] = []
        let cursor: string | null = null
        do {
            const page = await fetchTestcasesPage({
                projectId,
                revisionId: loadable.revisionId,
                cursor,
                limit: 50,
            })
            allTestcases.push(...(page.testcases as ({id: string} & Record<string, unknown>)[]))
            cursor = page.nextCursor
            if (!page.hasMore) break
        } while (cursor)

        // Delegate to the same compound action used for interactive testset connections
        set(connectToTestsetAtom, {
            loadableId,
            revisionId: loadable.revisionId,
            testcases: allTestcases,
            testsetName: loadable.sourceName ?? undefined,
            testsetId: loadable.testsetId ?? undefined,
        })

        // Restore hidden testcase IDs (user's testcase selection filter)
        if (loadable.hiddenTestcaseIds && loadable.hiddenTestcaseIds.length > 0) {
            const state = get(loadableStateAtomFamily(loadableId))
            set(loadableStateAtomFamily(loadableId), {
                ...state,
                hiddenTestcaseIds: new Set(loadable.hiddenTestcaseIds),
            })
        }

        // Restore locally-added draft rows that were captured in the snapshot
        if (loadable.draftRows && loadable.draftRows.length > 0) {
            set(loadableController.actions.importRows, loadableId, loadable.draftRows)
        }
    },
)

/**
 * Restore local testcase data from a URL snapshot.
 *
 * This is a synchronous compound action that:
 * 1. Gets the loadable ID from the primary node
 * 2. Imports the local testcase rows via loadable controller
 * 3. Sets the connected testset atom to local mode with the snapshot's name
 */
const restoreLocalTestsetAtom = atom(null, (get, set, localTestset: SnapshotLocalTestset) => {
    const loadableId = get(derivedLoadableIdAtom)
    if (!loadableId) return

    // Clear existing rows first to make this operation idempotent.
    // Without this, re-hydration (e.g. after HMR) would append duplicate
    // rows because local testcase rows have no stable IDs for dedup.
    set(loadableController.actions.clearRows, loadableId)

    // Import rows via loadable controller (stays in local mode)
    set(loadableController.actions.importRows, loadableId, localTestset.rows)

    // Set connected testset to local mode with the name from the snapshot
    set(connectedTestsetAtom, {
        id: null,
        name: localTestset.name,
    })

    // Extract chat messages from restored testcase rows if in chat mode.
    // The entity layer stores `messages` as a regular data column, but the
    // playground chat UI reads from messageIdsAtomFamily/messagesByIdAtomFamily.
    // Without this step, chat messages are lost after snapshot hydration
    // (e.g. when opening a chat trace span in the playground via URL).
    const isChat = get(isChatModeAtom) ?? false
    if (isChat) {
        // For trace replays (ephemeral local workflow entities), skip appending a blank
        // user message — the loaded messages are the complete conversation.
        const isTraceReplay = loadableId.includes(":workflow:local-")
        set(extractAndLoadChatMessagesAtom, {
            loadableId,
            testcaseRows: localTestset.rows as Record<string, unknown>[],
            skipBlankMessage: isTraceReplay,
        })
    }
})

// ============================================================================
// OPEN FROM TRACE
// ============================================================================

function isRecord(value: unknown): value is Record<string, unknown> {
    return typeof value === "object" && value !== null && !Array.isArray(value)
}

function asString(value: unknown): string | undefined {
    return typeof value === "string" && value.length > 0 ? value : undefined
}

const TRACE_OMIT_KEYS = new Set(["system_prompt", "user_prompt", "input_keys"])

/** Strip omitted keys from each direct child object in parameters */
function stripOmittedKeys(params: Record<string, unknown>): Record<string, unknown> {
    const result: Record<string, unknown> = {}
    for (const [key, value] of Object.entries(params)) {
        if (isRecord(value)) {
            const cleaned: Record<string, unknown> = {}
            for (const [k, v] of Object.entries(value)) {
                if (!TRACE_OMIT_KEYS.has(k)) cleaned[k] = v
            }
            result[key] = cleaned
        } else {
            result[key] = value
        }
    }
    return result
}

/**
 * Detect PromptTemplate-shaped values inside ag.data.inputs.
 *
 * `@ag.instrument()` captures every function argument as an input, so a
 * sub-task like `summarize(prompt: PromptTemplate, blog_post: str)` ends
 * up with the prompt config living under `inputs.prompt`. Those values
 * belong in the variant configuration panel, not as testcase fields —
 * this helper lets us promote them back into parameters.
 *
 * Shape check is structural: a PromptTemplate has a `messages` array or
 * an `llm_config` object. Matching `template_format` is an extra signal
 * to avoid false positives on user dicts that happen to carry messages.
 */
function looksLikePromptConfig(value: unknown): boolean {
    if (!isRecord(value)) return false
    const hasMessages = Array.isArray(value.messages) && value.messages.length > 0
    const hasLlmConfig = isRecord(value.llm_config)
    const hasTemplateFormat = typeof value.template_format === "string"
    return (hasMessages || hasLlmConfig) && (hasTemplateFormat || hasLlmConfig)
}

/**
 * Walk a span's descendants depth-first and return the first non-empty
 * `ag.data.parameters` found.
 *
 * Workflow/task/agent/chain spans are wrappers — the actual prompt/model
 * config typically lives on a child LLM-call span (e.g. `litellm.completion`
 * sub-span carries `parameters: {prompt: {...}}` or `parameters: {model,
 * messages, ...}`). Without walking the tree, the parent ephemeral entity
 * ends up with empty parameters and the playground renders the empty state.
 *
 * Parameters are returned as a parsed Record (handles JSON-encoded strings).
 */
function findDescendantParameters(
    span: TraceSpanNode | TraceSpan | null,
): Record<string, unknown> | null {
    if (!span) return null
    const children = (span as TraceSpanNode).children
    if (!Array.isArray(children) || children.length === 0) return null

    for (const child of children) {
        const childAgData = extractAgData(child)
        let childParams = childAgData?.parameters
        if (typeof childParams === "string") {
            try {
                childParams = JSON.parse(childParams)
            } catch {
                childParams = undefined
            }
        }
        if (isRecord(childParams) && Object.keys(childParams).length > 0) {
            return childParams as Record<string, unknown>
        }
        const deeper = findDescendantParameters(child)
        if (deeper) return deeper
    }
    return null
}

/** Check if inputs look like a chat variant (has messages array with role/content objects) */
function looksLikeChat(inputs: Record<string, unknown>): boolean {
    if (!("messages" in inputs) || !Array.isArray(inputs.messages)) return false
    return inputs.messages.some(
        (m) =>
            m &&
            typeof m === "object" &&
            ("role" in (m as Record<string, unknown>) ||
                "content" in (m as Record<string, unknown>)),
    )
}

/**
 * Split chat messages into config (before first user message) and generation (from first user message).
 * Config messages (typically system prompts) go into ephemeral workflow parameters.
 * Generation messages (user turns onward) go into testcase/loadable data.
 */
function splitChatMessages(messages: {role: string; content: unknown}[]): {
    configMessages: {role: string; content: unknown}[]
    generationMessages: {role: string; content: unknown}[]
} {
    const firstUserIdx = messages.findIndex((m) => m.role === "user")
    if (firstUserIdx <= 0) {
        // No user message or user message is first — nothing to split into config
        return {configMessages: [], generationMessages: messages}
    }
    return {
        configMessages: messages.slice(0, firstUserIdx),
        generationMessages: messages.slice(firstUserIdx),
    }
}

/**
 * Extract model/LLM config from a chat span.
 *
 * Priority:
 * 1. ag.data.parameters (playground-generated traces have model here)
 * 2. attributes.llm.invocation_parameters (observability SDK traces)
 */
function extractModelConfig(span: TraceSpanNode): Record<string, unknown> | null {
    const agData = extractAgData(span)

    // 1. Check ag.data.parameters for direct model or llm_config
    if (isRecord(agData?.parameters)) {
        const params = agData.parameters as Record<string, unknown>
        if (params.model || isRecord(params.llm_config)) {
            return params
        }
    }

    // 2. Fall back to attributes.llm.invocation_parameters
    const attrs = span.attributes as Record<string, unknown> | undefined
    if (attrs) {
        const llm = attrs.llm as Record<string, unknown> | undefined
        if (llm?.invocation_parameters) {
            const raw = llm.invocation_parameters
            if (typeof raw === "string") {
                try {
                    const parsed = JSON.parse(raw)
                    if (isRecord(parsed)) return parsed
                } catch {
                    /* not valid JSON */
                }
            } else if (isRecord(raw)) {
                return raw
            }
        }
    }

    return null
}

/**
 * Extract `ag.flags` from a span's attributes.
 *
 * Flags sit at `attributes.ag.flags` (sibling of `ag.data`), so `extractAgData`
 * does not surface them. This helper reads them independently for identity checks
 * (e.g. `is_evaluator`).
 */
function extractAgFlags(span: TraceSpanNode): Record<string, unknown> {
    const ag = (span.attributes as Record<string, unknown> | undefined)?.ag as
        | Record<string, unknown>
        | undefined
    const flags = ag?.flags
    return flags && typeof flags === "object" && !Array.isArray(flags)
        ? (flags as Record<string, unknown>)
        : {}
}

/**
 * Derive a builtin workflow URI from a span name.
 *
 * Builtin handler function names follow `<key>_v<N>` (e.g. `auto_ai_critique_v0`).
 * The matching URI is `agenta:builtin:<key>:v<N>`. Returns `null` if the span name
 * doesn't match the expected shape.
 */
function deriveBuiltinUriFromSpanName(spanName: string | null | undefined): string | null {
    if (!spanName) return null
    const match = /^(.+?)_v(\d+)$/.exec(spanName)
    if (!match) return null
    const [, key, version] = match
    return buildWorkflowUri(key, "agenta", "builtin", `v${version}`)
}

/**
 * Result from opening a trace in playground.
 *
 * - `type: "revision"` — the trace has (or resolves to) a specific revision
 *   id; the playground opens that revision directly.
 * - `type: "ephemeral"` — a local-only workflow was created from the trace
 *   data; no app or revision linkage. The caller should open it in the
 *   stacked drawer (no app context) or, if `appId` is set, full-page inside
 *   that app (legacy evaluator path).
 */
export interface OpenFromTraceResult {
    type: "revision" | "ephemeral"
    entityId: string
    label: string
    inputs: Record<string, unknown>
    /** For workflow spans with app references — used for navigation to app playground */
    appId?: string
}

/**
 * Open a trace span in the playground.
 *
 * Flow:
 * 1. Extracts inputs, outputs, and parameters from the span's ag.data
 * 2. Checks for application_revision reference - if present, opens that revision directly
 * 3. Otherwise, creates a local ephemeral workflow entity from trace data
 * 4. Adds it as the primary playground node
 * 5. Populates the loadable with trace inputs as a testset row
 * 6. For chat spans, extracts messages into chat message atoms
 *
 * Navigation to the playground page is handled by the calling component.
 */
const openFromTraceAtom = atom(
    null,
    async (get, set, activeSpan: TraceSpanNode): Promise<OpenFromTraceResult> => {
        const spanType = activeSpan.span_type
        const agData = extractAgData(activeSpan)
        const refs = extractReferences(activeSpan)

        // Determine label from references
        const label =
            asString(refs.application_variant?.slug) ??
            asString(refs.application?.slug) ??
            asString(refs.evaluator_variant?.slug) ??
            asString(refs.evaluator?.slug) ??
            asString(agData.variantName) ??
            asString(activeSpan.span_name) ??
            "Trace Replay"

        // Resolve any combination of trace refs to concrete `{appId, revId}`.
        //
        // Third-party instrumentations (n8n, LangChain-style adapters) often
        // emit refs as slugs or versions instead of UUIDs. We fire one
        // round-trip whenever the trace gives us anything identifying
        // (app/variant/revision × id/slug — or version when scoped) and
        // backfill only the ids that aren't already on the refs. The local
        // ids the trace supplied are authoritative and never overwritten.
        //
        // Skipped when we already have both app.id and revision.id (no
        // network call needed) or when the only identifier is a bare
        // revision.version (the backend rejects that as ambiguous).
        const haveBothIds = Boolean(
            asString(refs.application?.id) && asString(refs.application_revision?.id),
        )
        if (!haveBothIds) {
            const projectId = get(projectIdAtom)
            const resolved = await resolveTraceRefs(refs, projectId)
            if (resolved.appId && !asString(refs.application?.id)) {
                refs.application = {...(refs.application ?? {}), id: resolved.appId}
            }
            if (resolved.revisionId && !asString(refs.application_revision?.id)) {
                refs.application_revision = {
                    ...(refs.application_revision ?? {}),
                    id: resolved.revisionId,
                }
            }
        }

        // Extract safe reference IDs (origin's asString guards)
        const applicationId = asString(refs.application?.id)
        const applicationSlug = asString(refs.application?.slug)
        const evaluatorId = asString(refs.evaluator?.id)
        const evaluatorSlug = asString(refs.evaluator?.slug)

        // Evaluator identity — detected from ag.flags or evaluator refs.
        // When true, the ephemeral workflow carries is_evaluator + the builtin URI
        // so downstream selectors (schema nesting, input ports, request payload)
        // take the evaluator branch instead of treating it as a completion app.
        const agFlags = extractAgFlags(activeSpan)
        const isEvaluatorSpan =
            agFlags.is_evaluator === true ||
            !!asString(refs.evaluator_revision?.id) ||
            !!evaluatorId
        const evaluatorUri = isEvaluatorSpan
            ? deriveBuiltinUriFromSpanName(asString(activeSpan.span_name))
            : null

        // ── INVOCATION SPANS ────────────────────────────────────────────
        // Span types whose inputs match the app's root input schema. Matches
        // `INVOCATION_SPAN_TYPES` in TraceTypeHeader; `task` is included
        // because it's the `@ag.instrument()` default type.
        if (
            spanType === "workflow" ||
            spanType === "task" ||
            spanType === "agent" ||
            spanType === "chain"
        ) {
            // Extract data (same as legacy path)
            let rawInputs = extractInputs(activeSpan)
            if (Object.keys(rawInputs).length === 0 && typeof agData?.inputs === "string") {
                try {
                    const parsed = JSON.parse(agData.inputs)
                    if (isRecord(parsed)) rawInputs = parsed
                } catch {
                    /* not valid JSON */
                }
            }

            let outputs = extractOutputs(activeSpan)
            if (typeof outputs === "string") {
                try {
                    outputs = JSON.parse(outputs)
                } catch {
                    /* keep as string */
                }
            }

            const hasNestedInputs = isRecord(rawInputs.inputs)
            const templateInputs = hasNestedInputs
                ? (rawInputs.inputs as Record<string, unknown>)
                : rawInputs
            const chatMessages =
                hasNestedInputs && Array.isArray(rawInputs.messages) ? rawInputs.messages : null
            const actualInputs: Record<string, unknown> = {
                ...templateInputs,
                ...(chatMessages ? {messages: chatMessages} : {}),
            }

            // For evaluator spans, preserve the full envelope (trace + inputs + outputs)
            // so downstream selectors can rebuild the evaluator request. The envelope's
            // inner `inputs` is the graded testcase row; `outputs` is the linked app's
            // output; `trace` carries the upstream trace reference.
            // `rawInputs.outputs` is often a JSON-encoded string on the wire
            // (e.g. `"{\"capital\":\"Baku\"}"`), so parse before storing.
            let envelopeOutputs: unknown = rawInputs.outputs
            if (typeof envelopeOutputs === "string") {
                try {
                    envelopeOutputs = JSON.parse(envelopeOutputs)
                } catch {
                    /* keep as string */
                }
            }
            const envelope = isEvaluatorSpan
                ? ({
                      ...(isRecord(rawInputs.trace) ? {trace: rawInputs.trace} : {}),
                      ...(hasNestedInputs
                          ? {inputs: rawInputs.inputs as Record<string, unknown>}
                          : {}),
                      ...(envelopeOutputs !== undefined ? {outputs: envelopeOutputs} : {}),
                  } as Record<string, unknown>)
                : undefined

            let rawAgParameters = agData?.parameters
            if (typeof rawAgParameters === "string") {
                try {
                    const parsed = JSON.parse(rawAgParameters)
                    if (isRecord(parsed)) rawAgParameters = parsed
                } catch {
                    rawAgParameters = undefined
                }
            }
            const rawParameters = (
                hasNestedInputs && isRecord(rawInputs.parameters)
                    ? rawInputs.parameters
                    : isRecord(rawAgParameters)
                      ? rawAgParameters
                      : {}
            ) as Record<string, unknown>
            let baseParameters = stripOmittedKeys(rawParameters)

            // Workflow/task/agent/chain spans wrap an LLM call whose actual
            // prompt/model config lives on a descendant span. If the active
            // span itself didn't capture parameters (common — only inputs are
            // captured at the wrapper level), walk the tree and use the first
            // non-empty `ag.data.parameters` we find. Without this fallback,
            // the ephemeral entity ends up with no config and the playground
            // shows the empty "No configuration needed" state.
            if (Object.keys(baseParameters).length === 0) {
                const descendantParams = findDescendantParameters(activeSpan)
                if (descendantParams) {
                    baseParameters = stripOmittedKeys(descendantParams)
                }
            }

            // Task/agent/chain spans often capture prompt config as inputs
            // (because `@ag.instrument()` records every function argument).
            // Promote those PromptTemplate-shaped values into parameters so
            // they render in the config panel rather than as testcase fields.
            const promotedConfig: Record<string, unknown> = {}
            const cleanedInputs: Record<string, unknown> = {}
            for (const [key, value] of Object.entries(actualInputs)) {
                if (looksLikePromptConfig(value) && !(key in baseParameters)) {
                    promotedConfig[key] = value
                } else {
                    cleanedInputs[key] = value
                }
            }
            const parameters =
                Object.keys(promotedConfig).length > 0
                    ? {...baseParameters, ...promotedConfig}
                    : baseParameters
            const testcaseInputs =
                Object.keys(promotedConfig).length > 0 ? cleanedInputs : actualInputs

            // If there's an app_revision reference with a resolvable UUID
            // (either from the trace directly or backfilled by the resolver
            // above), open that revision directly.
            const revisionId = asString(refs.application_revision?.id)
            if (revisionId) {
                set(addPrimaryNodeAtom, {
                    type: "workflow",
                    id: revisionId,
                    label,
                })

                if (Object.keys(testcaseInputs).length > 0) {
                    const loadableId = `testset:workflow:${revisionId}`
                    set(loadableController.actions.setRows, loadableId, [
                        {id: "trace-input-0", data: testcaseInputs},
                    ])
                    if (looksLikeChat(testcaseInputs)) {
                        set(extractAndLoadChatMessagesAtom, {
                            loadableId,
                            testcaseRows: [testcaseInputs],
                            skipBlankMessage: true,
                        })
                    }
                }

                return {
                    type: "revision",
                    entityId: revisionId,
                    label,
                    inputs: testcaseInputs,
                    appId: applicationId,
                }
            }

            // Evaluator spans with a resolvable evaluator_revision.id open the
            // existing revision directly — mirrors the application_revision
            // branch above. This lets users edit the actual llm-as-a-judge
            // revision (producing a local draft → "Commit" button) instead of
            // forking a disconnected ephemeral ("Create" button on an orphan).
            // We still ingest the envelope-shaped test row so running replays
            // the trace's graded payload.
            const evaluatorRevisionId = isEvaluatorSpan
                ? asString(refs.evaluator_revision?.id)
                : undefined
            if (evaluatorRevisionId) {
                // `skipInitialRow` prevents linkToRunnable from seeding an empty
                // row — we write the envelope-shaped row ourselves right after
                // so there's no transient empty row that React might observe.
                set(
                    addPrimaryNodeAtom,
                    {
                        type: "workflow",
                        id: evaluatorRevisionId,
                        label,
                    },
                    {skipInitialRow: true},
                )

                const evaluatorRowData: Record<string, unknown> = {
                    inputs: (envelope?.inputs as Record<string, unknown> | undefined) ?? {},
                    outputs: envelope?.outputs ?? {},
                }
                const loadableId = `testset:workflow:${evaluatorRevisionId}`
                set(loadableController.actions.setRows, loadableId, [
                    {id: "trace-input-0", data: evaluatorRowData},
                ])

                return {
                    type: "revision",
                    entityId: evaluatorRevisionId,
                    label,
                    inputs: testcaseInputs,
                }
            }

            // No revision and no app linkage — create ephemeral workflow.
            // Evaluator spans carry is_evaluator + the derived URI so downstream
            // selectors dispatch correctly (schema, ports, request payload).
            const sourceRef = isEvaluatorSpan
                ? evaluatorId
                    ? {type: "evaluator" as const, id: evaluatorId, slug: evaluatorSlug}
                    : undefined
                : applicationId
                  ? {type: "application" as const, id: applicationId, slug: applicationSlug}
                  : undefined
            const {id: entityId} = createEphemeralWorkflow({
                label,
                inputs: testcaseInputs,
                outputs,
                parameters,
                sourceRef,
                ...(isEvaluatorSpan ? {isEvaluator: true} : {}),
                ...(evaluatorUri ? {uri: evaluatorUri} : {}),
                ...(envelope ? {envelope} : {}),
            })
            set(addPrimaryNodeAtom, {type: "workflow", id: entityId, label})

            // Evaluator rows carry the envelope shape {inputs, outputs}; app rows
            // stay flat. `envelope` is only set for evaluator spans above.
            const rowData: Record<string, unknown> = isEvaluatorSpan
                ? {
                      inputs: (envelope?.inputs as Record<string, unknown> | undefined) ?? {},
                      outputs: envelope?.outputs ?? {},
                  }
                : testcaseInputs

            if (Object.keys(rowData).length > 0) {
                const loadableId = `testset:workflow:${entityId}`
                set(loadableController.actions.setRows, loadableId, [
                    {id: "trace-input-0", data: rowData},
                ])
                if (!isEvaluatorSpan && looksLikeChat(testcaseInputs)) {
                    set(extractAndLoadChatMessagesAtom, {
                        loadableId,
                        testcaseRows: [testcaseInputs],
                        skipBlankMessage: true,
                    })
                }
            }

            return {
                type: "ephemeral",
                entityId,
                label,
                inputs: testcaseInputs,
                // Evaluator spans always open in the workflow drawer regardless
                // of the app they grade — mirrors the evaluator-revision branch
                // above and matches the intent in TraceTypeHeader.handleOpenInPlayground.
                appId: isEvaluatorSpan ? undefined : applicationId,
            }
        }

        // ── CHAT SPANS ─────────────────────────────────────────────────
        // Chat spans always create an ephemeral workflow in the project playground.
        // Extract config messages (before first user) vs generation messages.

        // Get raw prompt messages from inputs.prompt
        let rawInputs = extractInputs(activeSpan)
        if (Object.keys(rawInputs).length === 0 && typeof agData?.inputs === "string") {
            try {
                const parsed = JSON.parse(agData.inputs)
                if (isRecord(parsed)) rawInputs = parsed
            } catch {
                /* not valid JSON */
            }
        }

        let outputs = extractOutputs(activeSpan)
        if (typeof outputs === "string") {
            try {
                outputs = JSON.parse(outputs)
            } catch {
                /* keep as string */
            }
        }

        // Chat spans have inputs.prompt as an array of {role, content} messages
        const promptMessages = rawInputs.prompt
        const isChatFormat = Array.isArray(promptMessages) && promptMessages.length > 0

        if (isChatFormat) {
            // Split messages: config (before first user) vs generation (from first user)
            const {configMessages, generationMessages} = splitChatMessages(
                promptMessages as {role: string; content: unknown}[],
            )

            // If the last user message in generationMessages has no response after it,
            // append output completion messages. This handles spans where:
            //   inputs.prompt = [user]
            //   outputs.completion = [assistant+tool_calls, tool]
            // Without this, the assistant response and tool messages are lost.
            // Safe for the working case where prompt already contains the full
            // conversation — there the last user will have responses after it.
            if (isRecord(outputs)) {
                let lastUserIdx = -1
                for (let i = generationMessages.length - 1; i >= 0; i--) {
                    if (generationMessages[i].role === "user") {
                        lastUserIdx = i
                        break
                    }
                }
                const hasResponseToLastUser =
                    lastUserIdx >= 0 &&
                    generationMessages.slice(lastUserIdx + 1).some((m) => m.role !== "user")

                if (lastUserIdx >= 0 && !hasResponseToLastUser) {
                    const completion = (outputs as Record<string, unknown>).completion
                    if (Array.isArray(completion)) {
                        for (const msg of completion) {
                            if (
                                isRecord(msg) &&
                                typeof (msg as Record<string, unknown>).role === "string"
                            ) {
                                generationMessages.push(msg as {role: string; content: unknown})
                            }
                        }
                    }
                }
            }

            // Build model/llm config from span data
            const modelConfig = extractModelConfig(activeSpan)
            const llmConfig: Record<string, unknown> = {}
            if (modelConfig) {
                if (modelConfig.model) {
                    llmConfig.model = modelConfig.model
                } else if (isRecord(modelConfig.llm_config)) {
                    Object.assign(llmConfig, modelConfig.llm_config)
                }
            }

            // Extract tools/functions from span inputs or parameters
            const toolsOrFunctions =
                rawInputs.tools ??
                rawInputs.functions ??
                (isRecord(agData?.parameters)
                    ? ((agData.parameters as Record<string, unknown>).tools ??
                      (agData.parameters as Record<string, unknown>).functions)
                    : undefined)

            // Build parameters with config messages, model config, and tools.
            // Tools must live inside `prompt` for the config UI to render them.
            // When llm_config is present, nest tools inside it; otherwise place
            // them directly in prompt.
            const hasLlmConfig = Object.keys(llmConfig).length > 0
            const hasTools = Array.isArray(toolsOrFunctions) && toolsOrFunctions.length > 0

            const promptValue: Record<string, unknown> = {
                messages: configMessages,
                ...(hasLlmConfig
                    ? {
                          llm_config: {
                              ...llmConfig,
                              ...(hasTools ? {tools: toolsOrFunctions} : {}),
                          },
                      }
                    : hasTools
                      ? {tools: toolsOrFunctions}
                      : {}),
            }

            const parameters: Record<string, unknown> = {
                prompt: promptValue,
            }

            // Generation messages go into testcase as chat messages
            const actualInputs: Record<string, unknown> = {
                messages: generationMessages,
            }

            const {id: entityId} = createEphemeralWorkflow({
                label,
                inputs: actualInputs,
                outputs,
                parameters,
                sourceRef: applicationId
                    ? {
                          type: "application",
                          id: applicationId,
                          slug: applicationSlug,
                      }
                    : undefined,
            })
            set(addPrimaryNodeAtom, {type: "workflow", id: entityId, label})

            const loadableId = `testset:workflow:${entityId}`
            set(loadableController.actions.setRows, loadableId, [
                {id: "trace-input-0", data: actualInputs},
            ])
            set(extractAndLoadChatMessagesAtom, {
                loadableId,
                testcaseRows: [actualInputs],
                skipBlankMessage: true,
            })

            return {
                type: "ephemeral",
                entityId,
                label,
                inputs: actualInputs,
            }
        }

        // Fallback for chat spans without standard prompt format —
        // use the legacy extraction logic
        const hasNestedInputs = isRecord(rawInputs.inputs)
        const templateInputs = hasNestedInputs
            ? (rawInputs.inputs as Record<string, unknown>)
            : rawInputs
        const chatMessages =
            hasNestedInputs && Array.isArray(rawInputs.messages) ? rawInputs.messages : null
        const actualInputs: Record<string, unknown> = {
            ...templateInputs,
            ...(chatMessages ? {messages: chatMessages} : {}),
        }

        let rawAgParameters = agData?.parameters
        if (typeof rawAgParameters === "string") {
            try {
                const parsed = JSON.parse(rawAgParameters)
                if (isRecord(parsed)) rawAgParameters = parsed
            } catch {
                rawAgParameters = undefined
            }
        }
        const rawParameters = (
            hasNestedInputs && isRecord(rawInputs.parameters)
                ? rawInputs.parameters
                : isRecord(rawAgParameters)
                  ? rawAgParameters
                  : {}
        ) as Record<string, unknown>
        const parameters = stripOmittedKeys(rawParameters)

        const {id: entityId} = createEphemeralWorkflow({
            label,
            inputs: actualInputs,
            outputs,
            parameters,
            sourceRef: applicationId
                ? {
                      type: "application",
                      id: applicationId,
                      slug: applicationSlug,
                  }
                : evaluatorId
                  ? {
                        type: "evaluator",
                        id: evaluatorId,
                        slug: evaluatorSlug,
                    }
                  : undefined,
        })
        set(addPrimaryNodeAtom, {type: "workflow", id: entityId, label})

        if (Object.keys(actualInputs).length > 0) {
            const loadableId = `testset:workflow:${entityId}`
            set(loadableController.actions.setRows, loadableId, [
                {id: "trace-input-0", data: actualInputs},
            ])
            if (looksLikeChat(actualInputs)) {
                set(extractAndLoadChatMessagesAtom, {
                    loadableId,
                    testcaseRows: [actualInputs],
                    skipBlankMessage: true,
                })
            }
        }

        return {
            type: "ephemeral",
            entityId,
            label,
            inputs: actualInputs,
        }
    },
)

// ============================================================================
// QUERY INVALIDATION
// ============================================================================

/**
 * Invalidate all playground-related TanStack Query caches and force refetch.
 *
 * This covers both legacy OSS query keys and entity package query keys
 * (used by appRevisionsWithDraftsAtomFamily). Also bumps the entity
 * revision cache version so cache-derived atoms re-evaluate.
 */
const invalidateQueriesAtom = atom(null, async () => {
    const _t0 = performance.now()
    const {getHostQueryClient} = await import("@agenta/shared/api/hostQueryClient")
    const queryClient = getHostQueryClient()

    const queryKeys = [
        ["variants"],
        ["variantRevisions"],
        ["appVariants"],
        ["appVariantRevisions"],
        ["oss-variants-for-selection"],
        ["oss-revisions-for-selection"],
        ["workflows"],
    ]

    // Invalidate to mark as stale
    await Promise.all(
        queryKeys.map((queryKey) => queryClient.invalidateQueries({queryKey, exact: false})),
    )
    console.log(
        `[invalidateQueries] invalidate (mark stale): ${(performance.now() - _t0).toFixed(0)}ms`,
    )

    // Refetch with type: 'all' to bypass cache
    const _t1 = performance.now()
    await Promise.all(
        queryKeys.map((queryKey) =>
            queryClient
                .refetchQueries({queryKey, type: "all", exact: false})
                .then(() =>
                    console.log(
                        `[invalidateQueries] refetch [${queryKey[0]}]: ${(performance.now() - _t1).toFixed(0)}ms`,
                    ),
                ),
        ),
    )

    // Bump the revision cache version so cache-derived atoms re-evaluate
    workflowMolecule.cache.invalidateList()
})

// ============================================================================
// CRUD ACTIONS (delegate to typed entity-level atoms)
// ============================================================================

const controllerCreateVariantAtom = atom(
    null,
    async (get, set, payload: AppRevisionCreateVariantPayload): Promise<AppRevisionCrudResult> => {
        const selectedIds = get(entityIdsAtom)
        const nodes = get(playgroundNodesAtom)

        const baseRevisionId =
            asNonEmptyString(payload.baseRevisionId) ??
            (payload.baseVariantName
                ? nodes.find((node) => node.label === payload.baseVariantName)?.entityId
                : undefined) ??
            selectedIds[0]

        if (!baseRevisionId) {
            return {
                success: false,
                error: "Could not resolve a base revision for variant creation",
            }
        }

        const result = await set(createWorkflowVariantAtom, {
            baseRevisionId,
            newVariantName: payload.newVariantName,
            slug: payload.slug,
            commitMessage: payload.note,
        })

        if (!result.success) {
            return {
                success: false,
                error: result.error.message,
                errorStatus: (result.error as {response?: {status?: number}}).response?.status,
            }
        }

        if (payload.callback) {
            const state = {selected: [...selectedIds]}
            payload.callback({id: result.newRevisionId}, state)
            set(setEntityIdsAtom, state.selected)
        }

        return {
            success: true,
            newRevisionId: result.newRevisionId,
        }
    },
)

const controllerCommitRevisionAtom = atom(
    null,
    async (_get, set, payload: AppRevisionCommitPayload): Promise<AppRevisionCrudResult> => {
        const result = await set(commitWorkflowRevisionAtom, {
            revisionId: payload.revisionId,
            commitMessage: payload.commitMessage ?? payload.note,
        })
        return {
            success: result.success,
            newRevisionId: result.success ? result.newRevisionId : undefined,
            error: result.success ? undefined : result.error.message,
        }
    },
)

const controllerDeleteRevisionAtom = atom(
    null,
    async (_get, set, revisionId: string): Promise<AppRevisionCrudResult> => {
        // Read raw workflow entity data (NOT bridge.data which transforms to RunnableData
        // and strips workflow_id). The archive API expects the artifact-level workflow ID.
        const entityData = workflowMolecule.get.data(revisionId) as
            | ({workflow_id?: unknown; workflow_variant_id?: unknown; id?: unknown} & Record<
                  string,
                  unknown
              >)
            | null
        const workflowId = asNonEmptyString(entityData?.workflow_id)
        if (!workflowId) {
            return {
                success: false,
                error: `Cannot delete workflow: missing workflow_id for revision ${revisionId}`,
            }
        }
        const variantId = asNonEmptyString(entityData?.workflow_variant_id)
        const result = await set(archiveWorkflowRevisionAtom, {
            revisionId,
            workflowId,
            variantId: variantId ?? undefined,
        })
        return {
            success: result.success,
            error: result.success ? undefined : result.error.message,
        }
    },
)

// ============================================================================
// SELECTION CHANGE CALLBACK
// ============================================================================

/**
 * Callback invoked after any controller action mutates the entity selection.
 * OSS registers this to handle URL sync, drawer state, and entity cleanup.
 *
 * @param entityIds - The new set of displayed entity IDs after the mutation
 * @param removed  - Entity IDs that were removed (if any)
 */
type SelectionChangeCallback = (entityIds: string[], removed: string[]) => void

let _onSelectionChange: SelectionChangeCallback | null = null

/**
 * Register a callback for selection change side-effects (URL sync, drawer state, etc.).
 * Call from the OSS/EE layer during initialization.
 */
export function setOnSelectionChangeCallback(cb: SelectionChangeCallback | null): void {
    _onSelectionChange = cb
}

/** @internal */
export function getOnSelectionChangeCallback(): SelectionChangeCallback | null {
    return _onSelectionChange
}

// ============================================================================
// SELECTION ACTIONS
// ============================================================================

/**
 * Set entity IDs directly (replaces the old OSS selectedVariantsAtom bridge).
 * Takes string[] or updater function, creates/reuses PlaygroundNode objects.
 */
const setEntityIdsAtom = atom(null, (get, set, next: string[] | ((prev: string[]) => string[])) => {
    const currentNodes = get(playgroundNodesAtom)
    const currentRootNodes = currentNodes.filter((node) => node.depth === 0)
    const downstreamNodes = currentNodes.filter((node) => node.depth > 0)
    const currentIds = currentRootNodes.map((node) => node.entityId)
    const rawValue = typeof next === "function" ? next(currentIds) : next
    const seen = new Set<string>()
    const newIds = rawValue.filter((id) => {
        if (seen.has(id)) return false
        seen.add(id)
        return true
    })
    const existingByEntityId = new Map(currentRootNodes.map((node) => [node.entityId, node]))
    const resolver = getRunnableTypeResolver()
    const newRootNodes: PlaygroundNode[] = newIds.map((entityId) => {
        const existing = existingByEntityId.get(entityId)
        if (existing) return existing
        const entityType = resolver?.getType(entityId) ?? "workflow"
        return {
            id: `node-${entityId}`,
            entityType,
            entityId,
            label: entityId,
            depth: 0,
        }
    })

    // Re-link loadable-scoped state for any entity that was REPLACED in place
    // (e.g., a revision committed → new revision ID at the same position).
    // Detection is POSITIONAL: only treat index `i` as a swap when both
    // `currentIds[i]` is no longer in the new selection and `newIds[i]` was
    // not in the previous selection. Pure reorders (`[A,B] → [B,A]`),
    // additions, and removals produce no swap pair.
    //
    // Why here (and not in switchEntityAtom)? `setEntityIdsAtom` is the single
    // chokepoint that EVERY entity-change path funnels through — switchEntity,
    // URL hydration, applyPlaygroundSelection, SUB 4 validation, removeEntity.
    // Putting the re-link at this level fixes commit, drawer-mode commit, and
    // any future caller that swaps an entity, with one change.
    if (currentRootNodes.length > 0 && newRootNodes.length > 0) {
        const currentIdSet = new Set(currentIds)
        const newIdSet = new Set(newIds)
        const positionalSwaps = currentIds.flatMap((oldEntityId, index) => {
            const newEntityId = newIds[index]
            if (!newEntityId || oldEntityId === newEntityId) return []
            // Guard against reorders: only a true swap when the old ID is gone
            // from the new selection AND the new ID wasn't already selected.
            if (newIdSet.has(oldEntityId) || currentIdSet.has(newEntityId)) return []
            return [{oldEntityId, newEntityId, isAnchorSwap: index === 0}]
        })

        if (positionalSwaps.length > 0) {
            const oldLoadableId = get(derivedLoadableIdAtom)
            const newAnchorNode = newRootNodes[0]
            const newAnchorLoadableId = `testset:${newAnchorNode.entityType}:${newAnchorNode.entityId}`

            // Process non-anchor swaps first. The anchor swap MOVES data away
            // from `oldLoadableId` and clears it, so any non-anchor rewrites
            // that target `oldLoadableId` must run before that clear.
            for (const swap of positionalSwaps) {
                if (swap.isAnchorSwap) continue
                relinkLoadableSessions(get, set, {
                    oldEntityId: swap.oldEntityId,
                    newEntityId: swap.newEntityId,
                    oldLoadableId,
                    newLoadableId: oldLoadableId,
                })
            }
            const anchorSwap = positionalSwaps.find((swap) => swap.isAnchorSwap)
            if (anchorSwap) {
                relinkLoadableSessions(get, set, {
                    oldEntityId: anchorSwap.oldEntityId,
                    newEntityId: anchorSwap.newEntityId,
                    oldLoadableId,
                    newLoadableId: newAnchorLoadableId,
                })
                // After the loadable re-link, the testcase row store is still
                // carrying every key the *previous* primary populated (chat
                // `messages`, old completion variables, etc.). Reconcile each
                // row against the NEW primary's input schema so the UI shows
                // only the relevant variables and execution doesn't have to
                // strip them later (#4525 / AGE-3793).
                pruneTestcaseRowsForEntity(get, set, anchorSwap.newEntityId)
            }
        }
    }

    // Preserve downstream nodes (e.g. evaluators at depth > 0) when updating root selection.
    // If root selection is cleared entirely, downstream nodes are also removed.
    set(playgroundNodesAtom, newRootNodes.length > 0 ? [...newRootNodes, ...downstreamNodes] : [])

    // Remap connections: if root nodes were removed, any downstream connections
    // that referenced them should be remapped to the new primary root.
    // This prevents evaluators from becoming disconnected when switching from
    // comparison mode back to single mode.
    if (newRootNodes.length > 0 && downstreamNodes.length > 0) {
        const newRootNodeIds = new Set(newRootNodes.map((n) => n.id))
        const newPrimaryNodeId = newRootNodes[0].id
        const connections = get(outputConnectionsAtom)
        const hasStaleSource = connections.some(
            (c) =>
                !newRootNodeIds.has(c.sourceNodeId) &&
                currentRootNodes.some((n) => n.id === c.sourceNodeId),
        )
        if (hasStaleSource) {
            set(
                outputConnectionsAtom,
                connections.map((c) =>
                    !newRootNodeIds.has(c.sourceNodeId) &&
                    currentRootNodes.some((n) => n.id === c.sourceNodeId)
                        ? {...c, sourceNodeId: newPrimaryNodeId}
                        : c,
                ),
            )
        }
    }

    // Ensure primary runnable is linked so loadable-derived columns/rows
    // (including initial variable row) are initialized for the current selection.
    const primary = newRootNodes[0]
    if (primary) {
        const loadableId = `testset:${primary.entityType}:${primary.entityId}`
        set(
            loadableController.actions.linkToRunnable,
            loadableId,
            primary.entityType as RunnableType,
            primary.entityId,
        )
    }
})

/**
 * Remove an entity from the displayed selection.
 * Notifies the registered selection change callback for OSS-specific side-effects
 * (URL sync, drawer state, entity cleanup).
 */
const removeEntityAtom = atom(null, (get, set, entityId: string) => {
    const current = get(entityIdsAtom)
    let updated = current.filter((id) => id !== entityId)

    // Prevent empty playground: if removing the last entity and it's a local draft,
    // fall back to its source revision
    if (updated.length === 0) {
        const resolver = getRunnableTypeResolver()
        const runnableType = resolver?.getType(entityId)
        if (runnableType) {
            const adapter = snapshotAdapterRegistry.get(runnableType)
            if (adapter?.isLocalDraftId(entityId)) {
                const sourceId = adapter.extractSourceId(entityId)
                if (sourceId) {
                    updated = [sourceId]
                }
            }
        }
    }

    set(setEntityIdsAtom, updated)
    _onSelectionChange?.(updated, [entityId])
})

/**
 * Re-link loadable-scoped state from one entity to another.
 *
 * Called when an entity in the playground is replaced (e.g., after committing
 * a workflow revision). The committed revision gets a new ID, so any state
 * keyed by `loadableId` (= `testset:<type>:<entityId>`) and any session-tagged
 * data (`sess:<entityId>` in messages and execution sessions) needs to follow
 * the rename. Without this, chat history and execution sessions get orphaned
 * at the old loadableId and the UI appears to reset.
 *
 * Two cases:
 *  - Anchor commit: the swapped entity is the loadableId anchor → loadableId
 *    changes, so chat + execution state is moved to the new loadableId and
 *    `sess:<old>` references are rewritten to `sess:<new>`.
 *  - Non-anchor commit (compare mode): loadableId stays the same, but the
 *    per-revision session ID still needs rewriting in place so the new
 *    revision's column finds its responses.
 */
function relinkLoadableSessions(
    get: Getter,
    set: Setter,
    {
        oldEntityId,
        newEntityId,
        oldLoadableId,
        newLoadableId,
    }: {
        oldEntityId: string
        newEntityId: string
        oldLoadableId: string
        newLoadableId: string
    },
) {
    const oldSessionId = `sess:${oldEntityId}`
    const newSessionId = `sess:${newEntityId}`
    const moves = oldLoadableId !== newLoadableId

    // --- Chat: rewrite per-revision sessionId in messages; move atom families
    // if the loadableId changed. Shared (user/system) messages are untouched.
    const messageIds = get(messageIdsAtomFamily(oldLoadableId))
    const messagesById = get(messagesByIdAtomFamily(oldLoadableId))
    const executionByMessageId = get(executionByMessageIdAtomFamily(oldLoadableId))

    let chatRewrote = false
    const rewrittenMessagesById: Record<string, ChatMessage> = {}
    for (const [id, msg] of Object.entries(messagesById)) {
        if (msg.sessionId === oldSessionId) {
            rewrittenMessagesById[id] = {...msg, sessionId: newSessionId}
            chatRewrote = true
        } else {
            rewrittenMessagesById[id] = msg
        }
    }

    if (moves) {
        set(messageIdsAtomFamily(newLoadableId), [...messageIds])
        set(messagesByIdAtomFamily(newLoadableId), rewrittenMessagesById)
        set(executionByMessageIdAtomFamily(newLoadableId), {...executionByMessageId})
        set(messageIdsAtomFamily(oldLoadableId), [])
        set(messagesByIdAtomFamily(oldLoadableId), {})
        set(executionByMessageIdAtomFamily(oldLoadableId), {})
    } else if (chatRewrote) {
        set(messagesByIdAtomFamily(oldLoadableId), rewrittenMessagesById)
    }

    // --- Execution state: rewrite the per-revision session in sessionsById,
    // activeSessionIds and resultsByKey (key = `${stepId}:${sessionId}`). Other
    // variants' sessions in compare mode are left untouched.
    const execState = get(executionStateAtomFamily(oldLoadableId))

    let execRewrote = false
    const rewrittenSessionsById: Record<string, ExecutionSession> = {}
    for (const [id, session] of Object.entries(execState.sessionsById)) {
        if (id === oldSessionId) {
            rewrittenSessionsById[newSessionId] = {
                ...session,
                id: newSessionId,
                runnableId: newEntityId,
            }
            execRewrote = true
        } else {
            rewrittenSessionsById[id] = session
        }
    }

    const rewrittenActiveSessionIds = execState.activeSessionIds.map((id) => {
        if (id === oldSessionId) {
            execRewrote = true
            return newSessionId
        }
        return id
    })

    const rewrittenResultsByKey: Record<string, RunResult> = {}
    const oldKeySuffix = `:${oldSessionId}`
    for (const [key, result] of Object.entries(execState.resultsByKey)) {
        if (result.sessionId === oldSessionId) {
            const newKey = key.endsWith(oldKeySuffix)
                ? `${key.slice(0, -oldKeySuffix.length)}:${newSessionId}`
                : key
            rewrittenResultsByKey[newKey] = {...result, sessionId: newSessionId}
            execRewrote = true
        } else {
            rewrittenResultsByKey[key] = result
        }
    }

    const nextExecState = {
        ...execState,
        sessionsById: rewrittenSessionsById,
        activeSessionIds: rewrittenActiveSessionIds,
        resultsByKey: rewrittenResultsByKey,
    }

    if (moves) {
        set(executionStateAtomFamily(newLoadableId), nextExecState)
        set(executionStateAtomFamily(oldLoadableId), createInitialExecutionState())

        // The loadable ID is anchored to the primary revision, so an anchor
        // commit must move the whole loadable context. Migrating only execution
        // results drops connectedSourceId and makes the connected testset appear
        // disconnected under the new revision.
        const oldLoadableStateAtom = loadableStateAtomFamily(oldLoadableId)
        const oldLoadableState = get(oldLoadableStateAtom)
        set(loadableStateAtomFamily(newLoadableId), {
            ...oldLoadableState,
            linkedRunnableId: newEntityId,
            hiddenTestcaseIds: new Set(oldLoadableState.hiddenTestcaseIds),
            disabledOutputMappingRowIds: new Set(oldLoadableState.disabledOutputMappingRowIds),
        })

        // Evict the old family key so future lookups receive fresh default state.
        // Reset the captured atom as well for any subscribers that still hold it.
        loadableStateAtomFamily.remove(oldLoadableId)
        set(oldLoadableStateAtom, get(loadableStateAtomFamily(oldLoadableId)))
    } else if (execRewrote) {
        set(executionStateAtomFamily(oldLoadableId), nextExecState)
    }
}

type PruneStatus = "acted" | "noop" | "unresolved"

/**
 * Reconcile every testcase row against the given entity's input contract.
 *
 * Why this exists: the testcase row store (`testcaseMolecule`) is shared
 * across loadables. When the user swaps the primary app in the LLM-as-a-
 * judge playground, the row data keeps every key the *previous* primary
 * populated — chat `messages`, completion template variables that the new
 * app doesn't declare, etc. Without reconciliation, those stale keys leak
 * into the new app's request body and the downstream evaluator's envelope.
 *
 * Allow-list source is `inputPorts` (via `resolveEntityInputContract`), NOT
 * `inputSchema.properties` — completion apps surface their variables as
 * prompt template placeholders through `inputPorts` and have an EMPTY static
 * input schema, so schema-based filtering keeps everything. Policy:
 *   - App with a resolved contract → strict: keep only declared (or
 *     downstream-evaluator-protected) keys.
 *   - Evaluator → chat-transport only: evaluators spread extra testcase
 *     columns, so we never strict-filter them.
 *   - Unresolved contract (ports mid-hydration) → no-op; returns
 *     `"unresolved"` so the caller can retry once the contract resolves. The
 *     run-time reconciliation in `webWorkerIntegration` is the backstop.
 *
 * Columns referenced by downstream evaluator `<input>_key` settings (e.g.
 * `correct_answer_key → ground_truth`) are protected so a strict clean
 * against the app contract doesn't drop intentional evaluation inputs.
 *
 * Mutations go through `testcaseMolecule.actions.batchUpdate` setting stale
 * keys to `undefined`, which the store's update reducer interprets as a
 * delete. Drafts are created as needed (one per affected row).
 */
function pruneTestcaseRowsForEntity(get: Getter, set: Setter, entityId: string): PruneStatus {
    const contract = resolveEntityInputContract(get, entityId)

    // Unresolved, non-evaluator contract → we can't strict-filter safely yet.
    // The evaluator path is always "resolved enough" (chat-transport strip
    // works without a variable list), so only bail for non-evaluator apps.
    if (!contract.isEvaluator && !contract.resolved) {
        return "unresolved"
    }

    const displayRowIds = get(testcaseMolecule.atoms.displayRowIds)
    if (!Array.isArray(displayRowIds) || displayRowIds.length === 0) return "noop"

    const protectedColumns = collectDownstreamReferencedColumns(get, get(playgroundNodesAtom))
    // The synced test set's own columns are intentional data, not stale
    // leftovers — keep them through the swap clean (#4647). Test-set-scoped
    // (union across all server rows), so rows that joined the test set
    // locally are covered too; same value for every row, hence hoisted.
    for (const column of collectTestsetServerColumns(get)) {
        protectedColumns.add(column)
    }

    const updates: {id: string; updates: {data: Record<string, unknown>}}[] = []

    for (const rowId of displayRowIds) {
        const row = get(testcaseMolecule.data(rowId))
        const data = (row as {data?: Record<string, unknown>} | null)?.data
        if (!data || typeof data !== "object") continue

        const {dropped} = reconcileRowDataForEntity(get, entityId, data, {
            protectedKeys: protectedColumns,
        })
        if (dropped.length === 0) continue

        const undefinedData: Record<string, unknown> = {}
        for (const key of dropped) {
            undefinedData[key] = undefined
        }
        updates.push({id: rowId, updates: {data: undefinedData}})
    }

    if (updates.length === 0) return "noop"

    set(testcaseMolecule.actions.batchUpdate, updates)
    return "acted"
}

/**
 * Reconcile all testcase rows against the CURRENT primary (depth-0) entity's
 * input contract, on demand — call this right after a primary swap so the
 * shared row is cleaned the instant the app changes, without waiting for a
 * run. The run-time reconciliation in `webWorkerIntegration` is the backstop.
 *
 * Hydration handling: the new primary's input ports may not be resolved at
 * call time (the workflow is still loading). When the prune reports
 * `"unresolved"` AND the entity isn't loaded yet, we subscribe to its
 * `inputPorts` and retry once they resolve, then unsubscribe. If the entity
 * is already loaded but has no resolvable variables, there's nothing to wait
 * for, so we don't subscribe (avoids a dangling subscription).
 */
const reconcileRowsToPrimaryAtom = atom(null, (get, set) => {
    const nodes = get(playgroundNodesAtom)
    const primary = nodes.find((node) => node.depth === 0)
    if (!primary) return
    const entityId = primary.entityId

    const status = pruneTestcaseRowsForEntity(get, set, entityId)
    if (status !== "unresolved") return

    // Unresolved: either the workflow is still loading, or it's a genuinely
    // no-variable app. Only wait if it hasn't loaded yet.
    const entityLoaded = get(workflowMolecule.selectors.data(entityId)) != null
    if (entityLoaded) return

    const store = get(playgroundStoreAtom)
    const unsub = store.sub(workflowMolecule.selectors.inputPorts(entityId), () => {
        const retryStatus = pruneTestcaseRowsForEntity(store.get, store.set, entityId)
        const nowLoaded = store.get(workflowMolecule.selectors.data(entityId)) != null
        if (retryStatus !== "unresolved" || nowLoaded) unsub()
    })
})

/**
 * Switch one entity for another in the displayed selection.
 * Handles both single and comparison mode. The loadable-scoped re-link
 * (chat history, execution sessions, results) happens inside setEntityIdsAtom
 * via positional swap detection, so this just computes the updated array
 * and delegates.
 */
const switchEntityAtom = atom(
    null,
    (get, set, {currentEntityId, newEntityId}: {currentEntityId: string; newEntityId: string}) => {
        const current = get(entityIdsAtom)
        const updated =
            current.length > 1
                ? current.map((id) => (id === currentEntityId ? newEntityId : id))
                : [newEntityId]

        set(setEntityIdsAtom, updated)
        _onSelectionChange?.(updated, [currentEntityId])
    },
)

// ============================================================================
// CONTROLLER EXPORT
// ============================================================================

export const playgroundController = {
    /**
     * Selectors - functions that return atoms
     * Usage: useAtomValue(useMemo(() => playgroundController.selectors.nodes(), []))
     */
    selectors: {
        /** All nodes in the playground */
        nodes: () => playgroundNodesAtom,

        /** Currently selected node ID */
        selectedNodeId: () => selectedNodeIdAtom,

        /** Whether there are multiple nodes */
        hasMultipleNodes: () => hasMultipleNodesAtom,

        /** Connected testset info */
        connectedTestset: () => connectedTestsetAtom,

        /** Extra columns added by user */
        extraColumns: () => extraColumnsAtom,

        /** Testset modal open state */
        testsetModalOpen: () => testsetModalOpenAtom,

        /** Mapping modal open state */
        mappingModalOpen: () => mappingModalOpenAtom,

        /** ID of connection being edited */
        editingConnectionId: () => editingConnectionIdAtom,

        /** Entity IDs from all nodes */
        entityIds: () => entityIdsAtom,

        /** Loadable ID for root node */
        loadableId: () => derivedLoadableIdAtom,

        /** Number of hidden (removed) testcase IDs in the current loadable */
        hiddenTestcaseCount: () => hiddenTestcaseCountAtom,

        /** Number of locally-added (new) testcase rows */
        newTestcaseCount: () => newTestcaseCountAtom,

        /** Hash of locally-added (new) testcase data (triggers URL re-encode on content edits) */
        newTestcaseDataHash: () => newTestcaseDataHashAtom,

        /** Displayed entity IDs (validated against revisions) */
        displayedEntityIds: () => displayedEntityIdsAtom,

        /** Resolved entity IDs (ready for render, excludes pending IDs) */
        resolvedEntityIds: () => resolvedEntityIdsAtom,

        /** Whether comparison mode is active (validated) */
        isComparisonView: () => isComparisonViewAtom,

        /** Composite layout state */
        playgroundLayout: () => playgroundLayoutAtom,

        /** Whether playground revisions have finished loading */
        revisionsReady: () => playgroundRevisionsReadyAtom,

        /** Schema-derived input keys */
        schemaInputKeys: () => schemaInputKeysAtom,

        /** High-level playground lifecycle status: "idle" | "loading" | "ready" | "empty" */
        status: () => playgroundStatusAtom,

        /** Variable names derived from entity input ports */
        inputVariableNames: () => inputVariableNamesAtom,
    },

    /**
     * Compound actions for multi-step operations
     * Usage: const addPrimary = useSetAtom(playgroundController.actions.addPrimaryNode)
     */
    actions: {
        /** Add a primary node (first runnable) */
        addPrimaryNode: addPrimaryNodeAtom,

        /** Add a downstream node (output receiver) */
        addDownstreamNode: addDownstreamNodeAtom,

        /** Connect a downstream node, replacing any existing node of the same type */
        connectDownstreamNode: connectDownstreamNodeAtom,

        /** Disconnect all downstream nodes of a given entity type */
        disconnectDownstreamNode: disconnectDownstreamNodeAtom,

        /** Disconnect a single downstream node by its node ID */
        disconnectSingleDownstreamNode: disconnectSingleDownstreamNodeAtom,

        /** Remove a node */
        removeNode: removeNodeAtom,

        /** Change the primary node */
        changePrimaryNode: changePrimaryNodeAtom,

        /**
         * Reconcile all testcase rows against the current primary entity's
         * input contract. Call after a primary swap to clean stale keys from a
         * previous app off the shared row immediately (#4525 / AGE-3793).
         */
        reconcileRowsToPrimary: reconcileRowsToPrimaryAtom,

        /** Disconnect from testset and reset to local mode */
        disconnectAndResetToLocal: disconnectAndResetToLocalAtom,

        // WP1: Testset connection actions
        /** Connect to a testset (load mode) */
        connectToTestset: connectToTestsetAtom,

        /** Import testcases (import mode - no connection) */
        importTestcases: importTestcasesAtom,

        /** Connect to a testset, re-importing local draft rows as unsaved additions */
        connectToTestsetKeepingLocalRows: connectToTestsetKeepingLocalRowsAtom,

        // WP2: Row with init action
        /** Add a row with local testset initialization */
        addRowWithInit: addRowWithInitAtom,

        // WP3: Extra column actions
        /** Add an extra column (coordinated) */
        addExtraColumn: addExtraColumnAtom,

        /** Remove an extra column (coordinated) */
        removeExtraColumn: removeExtraColumnAtom,

        // WP4: Output mapping column action
        /** Add an output mapping column (loadable only, not extraColumns) */
        addOutputMappingColumn: addOutputMappingColumnAtom,

        /** Set entity IDs (replaces OSS selectedVariantsAtom bridge) */
        setEntityIds: setEntityIdsAtom,

        /** Remove an entity from the displayed selection */
        removeEntity: removeEntityAtom,

        /** Switch one entity for another in the displayed selection */
        switchEntity: switchEntityAtom,

        /** Invalidate all playground-related query caches and force refetch */
        invalidateQueries: invalidateQueriesAtom,

        // CRUD actions (delegate to registered provider)
        /** Create a new variant */
        createVariant: controllerCreateVariantAtom,

        /** Commit (save) a revision */
        commitRevision: controllerCommitRevisionAtom,

        /** Delete a revision */
        deleteRevision: controllerDeleteRevisionAtom,

        /** Reset playground state and clear all output connections */
        resetAll: resetAllAtom,

        /** Restore a testset connection from a URL snapshot (call after primary node is set) */
        restoreLoadableConnection: restoreLoadableConnectionAtom,

        /** Restore local testcase data from a URL snapshot (call after primary node is set) */
        restoreLocalTestset: restoreLocalTestsetAtom,

        /** Open a trace span in the playground (extract data, create entity, populate testcase) */
        openFromTrace: openFromTraceAtom,
    },

    /**
     * Dispatch for standard actions
     * Usage: const dispatch = useSetAtom(playgroundController.dispatch)
     */
    dispatch: playgroundDispatchAtom,
}
