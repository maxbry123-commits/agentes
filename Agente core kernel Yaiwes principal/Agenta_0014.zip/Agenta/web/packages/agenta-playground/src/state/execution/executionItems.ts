import {loadableController, type RequestPayloadData} from "@agenta/entities/runnable"
import {isLocalDraftId, isPlaceholderId} from "@agenta/entities/shared"
import {
    stripAgentaMetadataDeep,
    stripEnhancedWrappers,
    transformToRequestBody,
    type TransformMessage,
    type TransformVariantInput,
} from "@agenta/entities/shared/execution"
import type {OpenAPISpec} from "@agenta/entities/shared/openapi"
import {markTraceAsFresh} from "@agenta/entities/trace"
import {workflowMolecule} from "@agenta/entities/workflow"
import {getAgentaApiUrl} from "@agenta/shared/api/env"
import {generateId} from "@agenta/shared/utils"
import {atom, type Getter, type Setter} from "jotai"

import {entityIdsAtom} from "../atoms/playground"
import {messageIdsAtomFamily, messagesByIdAtomFamily} from "../chat/messageAtoms"
import {
    addMessageAtom,
    addMessagesAtom,
    completeMessageExecutionAtom,
    failMessageExecutionAtom,
    generateMessageId,
} from "../chat/messageReducer"
import type {ChatMessage} from "../chat/messageTypes"
import {SHARED_SESSION_ID} from "../chat/messageTypes"
import {buildAssistantMessage} from "../helpers/messageFactory"

import {
    abortRun,
    buildResultKey,
    executionAdapterAtom,
    repetitionCountAtom,
    repetitionIndexAtomFamily,
    resultAtomFamily,
    resultsByKeyAtomFamily,
} from "./atoms"
import {completeRunAtom, failRunAtom} from "./reducer"
import {isChatModeAtom} from "./selectors"
import {extractTraceIdFromPayload} from "./trace"
import type {ExecutionMode, RunResult, RunStatus} from "./types"

// ============================================================================
// TYPES
// ============================================================================

export interface ExecutionItemReference {
    loadableId: string
    rowId: string
    entityId: string
    sessionId: string
    messageId?: string
}

export interface ExecutionItemInvocation {
    runId: string
    invocationUrl: string
    requestBody: Record<string, unknown>
    headers: Record<string, string>
    repetitions: number
}

export interface WorkerRunEntityRowPayload {
    runId: string
    rowId: string
    entityId: string
    messageId?: string
    invocationUrl: string
    requestBody: Record<string, unknown>
    headers: Record<string, string>
    repetitions: number
}

export interface ExecutionItem {
    id: string
    mode: ExecutionMode
    references: ExecutionItemReference
    invocation: ExecutionItemInvocation
    workerPayload: WorkerRunEntityRowPayload
}

export interface CreateExecutionItemParams {
    loadableId: string
    rowId: string
    entityId: string
    /** When provided, scopes bridge selectors to this entity type only.
     *  Without this, the bridge probes all molecule types — which can
     *  match the wrong molecule when entity IDs exist in a shared DB table. */
    entityType?: string
    runId?: string
    messageId?: string
}

export interface ExecutionItemRunParams {
    get: Getter
    headers: Record<string, string>
    repetitions?: number
    runId?: string
    inputValues?: Record<string, unknown>
    references?: RequestPayloadData["references"]
    links?: Record<string, {trace_id: string; span_id: string}>
    projectId?: string | null
    dispatchWorkerRun?: (payload: WorkerRunEntityRowPayload) => void
    /** Pre-built chat history. When provided, skips internal turn-based history building. */
    chatHistory?: TransformMessage[]
}

export interface ExecutionItemCancelParams {
    get: Getter
    set: Setter
    dispatchWorkerCancel?: (runId: string) => void
}

export type ExecutionItemLifecyclePhase = "idle" | "running" | "success" | "failed" | "cancelled"

export interface ExecutionItemLifecycleSnapshot {
    status: RunStatus
    phase: ExecutionItemLifecyclePhase
    runId: string | null
    error: {message: string; code?: string} | null
    isRunning: boolean
    isFailed: boolean
    canRetry: boolean
    startedAt?: number
    completedAt?: number
    resultHash: string | null
    repetitionCount: number
    repetitionIndex: number
    attemptCount: number
    retryCount: number
}

export interface ExecutionItemLifecycleApi {
    snapshot: (get: Getter) => ExecutionItemLifecycleSnapshot
    isRunning: (get: Getter) => boolean
    isFailed: (get: Getter) => boolean
    canRetry: (get: Getter) => boolean
    repetitionCount: (get: Getter) => number
    repetitionIndex: (get: Getter) => number
}

export interface ExecutionItemHandle {
    id: string
    references: ExecutionItemReference
    lifecycle: ExecutionItemLifecycleApi
    run: (params: ExecutionItemRunParams) => ExecutionItem | null
    retry: (params: Omit<ExecutionItemRunParams, "runId">) => ExecutionItem | null
    cancel: (params: ExecutionItemCancelParams) => void
}

export interface AgConfigFallbackCandidate {
    source: string
    value: unknown
}

interface BuildExecutionItemBaseParams {
    loadableId: string
    rowId: string
    entityId: string
    runId: string
    messageId?: string
    headers: Record<string, string>
    repetitions: number
    projectId?: string | null
    entityData?: TransformVariantInput | null
    requestPayload?: RequestPayloadData | null
    invocationUrl?: string | null
    variables?: string[]
    variableValues?: Record<string, unknown>
    agConfigFallbacks?: AgConfigFallbackCandidate[]
    /** Runtime-resolved inputs (e.g. from chain upstream). Merged into rawBody.inputs when __rawBody is true. */
    inputValues?: Record<string, unknown>
    references?: RequestPayloadData["references"]
    links?: Record<string, {trace_id: string; span_id: string}>
}

export interface BuildCompletionExecutionItemParams extends BuildExecutionItemBaseParams {
    inputRow?: Record<string, unknown>
}

export interface BuildChatExecutionItemParams extends BuildExecutionItemBaseParams {
    chatHistory?: TransformMessage[]
}

interface ResolveVariableRowIdParams {
    mode: ExecutionMode
    executionRowId: string
    displayRowIds: string[]
}

interface ResolveVariableValuesParams {
    allowedVariableKeys: string[]
    sourceRowData?: Record<string, unknown> | null
}

interface BuildCompletionInputRowParams {
    rowId: string
    allowedVariableKeys: string[]
    sourceRowData?: Record<string, unknown> | null
}

// ============================================================================
// INTERNAL HELPERS
// ============================================================================

const MODEL_ATTACHMENT_ALLOWLIST = ["gemini"]

function asRecord(value: unknown): Record<string, unknown> | null {
    if (!value || typeof value !== "object" || Array.isArray(value)) return null
    return value as Record<string, unknown>
}

/**
 * Strip reference `id`s that aren't real server UUIDs (local-draft or
 * placeholder ids) from a request body's `references` map.
 *
 * The backend `/invoke` validator rejects a non-UUID reference id with a 422
 * (QA 2026-06-05: an unsaved evaluator opened from the drawer shipped
 * `references.evaluator_revision.id = "local-…"` → "Input should be a valid
 * UUID"). This is the last line of defense, applied to the FINAL merged
 * references regardless of which builder produced them (requestPayload
 * references, executionRunner stage self/upstream references, or
 * trace-span-extracted references). Slugs and versions are plain strings the
 * backend accepts and are kept; a slot left with no fields is dropped.
 */
function sanitizeReferenceIds(references: unknown): Record<string, unknown> | null {
    const refs = asRecord(references)
    if (!refs) return null
    let mutated = false
    const out: Record<string, unknown> = {}
    for (const [slot, value] of Object.entries(refs)) {
        const ref = asRecord(value)
        const id = ref?.id
        if (ref && typeof id === "string" && (isLocalDraftId(id) || isPlaceholderId(id))) {
            const rest = {...ref}
            delete rest.id
            mutated = true
            if (Object.keys(rest).length > 0) out[slot] = rest
        } else {
            out[slot] = value
        }
    }
    return mutated ? out : refs
}

function unwrapValue(value: unknown): unknown {
    const rec = asRecord(value)
    return rec && "value" in rec ? rec.value : value
}

function unwrapArray(value: unknown): unknown[] | undefined {
    if (Array.isArray(value)) return value
    const unwrapped = unwrapValue(value)
    return Array.isArray(unwrapped) ? unwrapped : undefined
}

function readString(value: unknown): string | undefined {
    if (typeof value !== "string") return undefined
    const trimmed = value.trim()
    return trimmed.length > 0 ? trimmed : undefined
}

function readWrappedString(value: unknown): string | undefined {
    return readString(value) ?? readString(unwrapValue(value))
}

function extractLogicalRowId(rowId: string): string {
    const sessionMatch = /^turn-([^-]+)-(lt-.+)$/.exec(String(rowId))
    return sessionMatch?.[2] || rowId
}

function normalizeTransformContent(content: unknown): string | unknown[] {
    const unwrapped = unwrapValue(content)
    if (Array.isArray(unwrapped)) return unwrapped
    if (typeof unwrapped === "string") return unwrapped
    return ""
}

function toTransformMessage(message: ChatMessage): TransformMessage {
    const messageRecord = asRecord(message)
    const toolCalls =
        unwrapArray(messageRecord?.toolCalls) ??
        unwrapArray(messageRecord?.tool_calls) ??
        (Array.isArray(message.tool_calls) ? message.tool_calls : undefined)
    const toolCallId =
        readWrappedString(messageRecord?.toolCallId) ??
        readWrappedString(messageRecord?.tool_call_id) ??
        readWrappedString(messageRecord?.toolCallID) ??
        readWrappedString(message.tool_call_id)

    let content = normalizeTransformContent(message.content)
    if (message.role === "tool" && content === "") {
        content =
            normalizeTransformContent(messageRecord?.response) ||
            normalizeTransformContent(messageRecord?.output)
    }

    const transformed: TransformMessage = {
        role: message.role,
        content,
    }

    const normalizedName = readWrappedString(message.name) ?? readWrappedString(messageRecord?.name)
    if (normalizedName) {
        transformed.name = normalizedName
    }

    if (toolCalls && toolCalls.length > 0) {
        transformed.toolCalls = toolCalls
    }

    if (toolCallId) {
        transformed.toolCallId = toolCallId
    }

    return transformed
}

function mapLifecyclePhase(status: RunStatus): ExecutionItemLifecyclePhase {
    if (status === "running" || status === "pending") return "running"
    if (status === "error") return "failed"
    return status
}

function resolveRunResult(get: Getter, references: ExecutionItemReference): RunResult | null {
    return get(
        resultAtomFamily({
            loadableId: references.loadableId,
            stepId: references.rowId,
            sessionId: references.sessionId,
        }),
    )
}

function resolveRequestedRepetitions(
    get: Getter,
    requestedRepetitions: number | undefined,
): number {
    const compareCount = (get(entityIdsAtom) || []).length
    if (compareCount > 1) return 1

    const globalCount = get(repetitionCountAtom)
    const preferred = Number.isFinite(requestedRepetitions)
        ? Number(requestedRepetitions)
        : globalCount
    return Math.max(1, preferred)
}

function cancelExecutionItemRun(
    get: Getter,
    set: Setter,
    references: ExecutionItemReference,
): string | null {
    const resultsByKey = {
        ...get(resultsByKeyAtomFamily(references.loadableId)),
    }
    const key = buildResultKey(references.rowId, references.sessionId)
    const existing = resultsByKey[key]
    if (!existing || (existing.status !== "running" && existing.status !== "pending")) {
        return null
    }

    if (existing.runId) {
        abortRun(existing.runId)
        const adapter = get(executionAdapterAtom)
        adapter.cancel?.(existing.runId)
    }

    resultsByKey[key] = {
        ...existing,
        status: "cancelled",
        completedAt: Date.now(),
    }
    set(resultsByKeyAtomFamily(references.loadableId), resultsByKey)
    return existing.runId ?? null
}

function resolveVariableRowId(params: ResolveVariableRowIdParams): string | null {
    const {mode, executionRowId, displayRowIds} = params
    if (!Array.isArray(displayRowIds) || displayRowIds.length === 0) return null

    if (mode === "chat") return displayRowIds[0]
    if (displayRowIds.includes(executionRowId)) return executionRowId
    return displayRowIds[0] ?? null
}

/**
 * Resolve testcase values to a dict for transport. Values are passed
 * through NATIVE (object stays object, array stays array, number stays
 * number) so the backend mustache / JSONPath resolver can navigate them
 * (RFC: "native JSON stays native until template rendering").
 *
 * Prior implementation stringified via JSON.stringify for objects/arrays,
 * which made `{{$.geo.region}}` fail at the backend with
 * "Unreplaced variables in mustache template" because the JSONPath
 * resolver can't navigate into a string.
 */
function resolveVariableValues(params: ResolveVariableValuesParams): Record<string, unknown> {
    const {allowedVariableKeys, sourceRowData} = params
    const source = sourceRowData ?? {}

    if (Array.isArray(allowedVariableKeys) && allowedVariableKeys.length > 0) {
        const values: Record<string, unknown> = {}
        for (const key of allowedVariableKeys) {
            values[key] = source[key]
        }
        return values
    }

    const values: Record<string, unknown> = {}
    for (const [key, value] of Object.entries(source)) {
        values[key] = value
    }
    return values
}

function buildCompletionInputRow(
    params: BuildCompletionInputRowParams,
): Record<string, unknown> | undefined {
    const {rowId, allowedVariableKeys, sourceRowData} = params
    if (!sourceRowData) return undefined

    const keys = allowedVariableKeys.length > 0 ? allowedVariableKeys : Object.keys(sourceRowData)
    const enhanced: Record<string, unknown> = {__id: rowId}

    // Pass values through NATIVE (RFC: "native JSON stays native until
    // template rendering"). `extractInputValues` at the request-body layer
    // already handles native object/array values without coercion. Prior
    // `String(value)` wrap turned `{region: "..."}` into `"[object Object]"`
    // which made even mustache `{{geo.region}}` resolve to empty.
    for (const key of keys) {
        const value = sourceRowData[key]
        enhanced[key] = {value: value === undefined || value === null ? "" : value}
    }

    return enhanced
}

/**
 * Build chat history from the flat message model.
 *
 * Walks messageIds in order, includes shared messages and session-owned messages.
 * Strips `sessionId` and `parentId` — returns pure TransformMessage[].
 *
 * Optionally stops before a given messageId (for providing context up to a point).
 */
function buildChatHistoryFromFlatMessages(params: {
    messageIds: string[]
    messagesById: Record<string, ChatMessage>
    sessionId: string
    beforeMessageId?: string
}): TransformMessage[] {
    const {messageIds, messagesById, sessionId, beforeMessageId} = params
    const sharedSessionId = SHARED_SESSION_ID

    const history: TransformMessage[] = []
    for (const msgId of messageIds) {
        if (beforeMessageId && msgId === beforeMessageId) break

        const msg = messagesById[msgId]
        if (!msg) continue

        if (msg.sessionId === sharedSessionId || msg.sessionId === sessionId) {
            history.push(toTransformMessage(msg))
        }
    }

    return history
}

export function createExecutionItemHandle(params: CreateExecutionItemParams): ExecutionItemHandle {
    const references: ExecutionItemReference = {
        loadableId: params.loadableId,
        rowId: params.rowId,
        entityId: params.entityId,
        sessionId: `sess:${params.entityId}`,
        ...(params.messageId ? {messageId: params.messageId} : {}),
    }

    let attemptCount = 0
    let lastRunId: string | null = params.runId ?? null
    let lastRequestedRepetitions = 1

    const buildLifecycleSnapshot = (get: Getter): ExecutionItemLifecycleSnapshot => {
        const result = resolveRunResult(get, references)
        const status: RunStatus = result?.status ?? "idle"
        const repetitionKey = `${references.rowId}:${references.entityId}`
        const repetitionIndexRaw = get(repetitionIndexAtomFamily(repetitionKey))
        const repetitionCountFromResult =
            Array.isArray(result?.repetitions) && result.repetitions.length > 0
                ? result.repetitions.length
                : 1
        const repetitionCount = Math.max(
            resolveRequestedRepetitions(get, undefined),
            lastRequestedRepetitions,
            repetitionCountFromResult,
        )
        const repetitionIndex = Math.min(
            Math.max(0, Number.isFinite(repetitionIndexRaw) ? repetitionIndexRaw : 0),
            Math.max(0, repetitionCount - 1),
        )

        return {
            status,
            phase: mapLifecyclePhase(status),
            runId: result?.runId ?? lastRunId ?? null,
            error: result?.error ?? null,
            isRunning: status === "running" || status === "pending",
            isFailed: status === "error",
            canRetry: status !== "running" && status !== "pending",
            startedAt: result?.startedAt,
            completedAt: result?.completedAt,
            resultHash: result?.resultHash ?? null,
            repetitionCount,
            repetitionIndex,
            attemptCount,
            retryCount: Math.max(0, attemptCount - 1),
        }
    }

    const buildExecutionItemFromRunParams = (
        runParams: ExecutionItemRunParams,
        forceNewRunId: boolean,
    ): ExecutionItem | null => {
        const {
            get,
            headers,
            repetitions,
            runId,
            inputValues,
            references: requestReferences,
            links,
            projectId,
            dispatchWorkerRun,
        } = runParams

        const mode: ExecutionMode =
            get(workflowMolecule.selectors.executionMode(params.entityId)) === "chat"
                ? "chat"
                : "completion"
        const normalizedRepetitions = resolveRequestedRepetitions(get, repetitions)
        const effectiveRunId =
            runId ?? (!forceNewRunId && params.runId ? params.runId : undefined) ?? generateId()

        const requestPayload = get(
            workflowMolecule.selectors.requestPayload(params.entityId),
        ) as RequestPayloadData | null
        const invocationUrl = get(workflowMolecule.selectors.invocationUrl(params.entityId)) as
            | string
            | null
        const configuration = get(workflowMolecule.selectors.configuration(params.entityId))
        const entityData = configuration
            ? ({parameters: configuration} as TransformVariantInput)
            : null

        const inputPorts = (get(workflowMolecule.selectors.inputPorts(params.entityId)) ?? []) as {
            key?: unknown
        }[]
        const variablesFromInputPorts = Array.from(
            new Set(
                inputPorts
                    .map((port) => port?.key)
                    .filter((key): key is string => typeof key === "string" && key.length > 0),
            ),
        )
        // Extract variables: for __rawBody app workflows, variables are in __meta
        const rawPayload = requestPayload as Record<string, unknown> | null
        const rawMeta = rawPayload?.__meta as Record<string, unknown> | undefined
        const variablesFromPayload =
            (rawMeta?.variables as string[]) ?? requestPayload?.variables ?? []
        const variables =
            variablesFromInputPorts.length > 0 ? variablesFromInputPorts : variablesFromPayload

        const displayRowIds = get(loadableController.selectors.displayRowIds(params.loadableId))
        if (!Array.isArray(displayRowIds) || displayRowIds.length === 0) {
            console.warn("[executionItem.run] No displayRowIds for", params.entityId, {
                loadableId: params.loadableId,
            })
            return null
        }

        const variableSourceRowId = resolveVariableRowId({
            mode,
            executionRowId: params.rowId,
            displayRowIds,
        })
        if (!variableSourceRowId) {
            console.warn("[executionItem.run] No variableSourceRowId for", params.entityId, {
                mode,
                rowId: params.rowId,
                displayRowIds: displayRowIds.slice(0, 5),
            })
            return null
        }

        const variableSourceRow = get(
            loadableController.selectors.row(params.loadableId, variableSourceRowId),
        ) as {id: string; data?: Record<string, unknown>} | null
        const variableSourceRowData = variableSourceRow?.data ?? null
        if (mode === "completion" && !variableSourceRowData) {
            console.warn("[executionItem.run] No variableSourceRowData for", params.entityId, {
                mode,
                variableSourceRowId,
                hasRow: !!variableSourceRow,
            })
            return null
        }

        // Use inputValues when provided with actual data (chain downstream nodes).
        // An empty inputValues ({}) from the runner means "no override from upstream"
        // — fall through to the loadable row data which has the user-entered values.
        const hasInputValues = inputValues != null && Object.keys(inputValues).length > 0
        const variableSourceDataForExecution = hasInputValues ? inputValues : variableSourceRowData

        const rawVariableValues = resolveVariableValues({
            allowedVariableKeys: variables,
            sourceRowData: variableSourceDataForExecution,
        })
        // In chat mode, "messages" is handled via chatHistory — never include it
        // as an input variable. This prevents duplicating the normalized chat
        // payload in `data.inputs.messages` with a serialized testcase field.
        if (mode === "chat") {
            delete rawVariableValues.messages
        }
        const variableValues = rawVariableValues

        const completionInputRow =
            mode === "completion"
                ? buildCompletionInputRow({
                      rowId: variableSourceRowId,
                      allowedVariableKeys: variables,
                      sourceRowData: variableSourceDataForExecution,
                  })
                : undefined

        const chatHistory =
            mode === "chat"
                ? (runParams.chatHistory ??
                  (() => {
                      const allMsgIds = get(messageIdsAtomFamily(params.loadableId))
                      const allMsgsById = get(messagesByIdAtomFamily(params.loadableId))
                      const logicalRowId = extractLogicalRowId(params.rowId)

                      // Find the cut point: include messages up to the next shared message after logicalRowId
                      const rowIdx = allMsgIds.indexOf(logicalRowId)
                      let cutIdx = allMsgIds.length
                      if (rowIdx >= 0) {
                          for (let i = rowIdx + 1; i < allMsgIds.length; i++) {
                              const m = allMsgsById[allMsgIds[i]] as ChatMessage | undefined
                              if (m && m.sessionId === SHARED_SESSION_ID) {
                                  cutIdx = i
                                  break
                              }
                          }
                      }
                      const limitedIds = allMsgIds.slice(0, cutIdx)

                      return buildChatHistoryFromFlatMessages({
                          messageIds: limitedIds,
                          messagesById: allMsgsById,
                          sessionId: references.sessionId,
                      })
                  })())
                : undefined

        const agConfigFallbacks: AgConfigFallbackCandidate[] = [
            {source: "requestPayload.ag_config", value: requestPayload?.ag_config},
            {
                source: "workflowMolecule.configuration",
                value: get(workflowMolecule.selectors.configuration(params.entityId)) as unknown,
            },
            {
                source: "entityData.parameters",
                value:
                    (entityData as {parameters?: unknown} | null | undefined)?.parameters ?? null,
            },
        ]

        const executionItem =
            mode === "chat"
                ? buildChatExecutionItem({
                      loadableId: params.loadableId,
                      rowId: params.rowId,
                      entityId: params.entityId,
                      runId: effectiveRunId,
                      messageId: params.messageId,
                      headers,
                      repetitions: normalizedRepetitions,
                      projectId,
                      entityData,
                      requestPayload,
                      invocationUrl,
                      variables,
                      variableValues,
                      chatHistory,
                      agConfigFallbacks,
                      inputValues,
                      references: requestReferences,
                      links,
                  })
                : buildCompletionExecutionItem({
                      loadableId: params.loadableId,
                      rowId: params.rowId,
                      entityId: params.entityId,
                      runId: effectiveRunId,
                      messageId: params.messageId,
                      headers,
                      repetitions: normalizedRepetitions,
                      projectId,
                      entityData,
                      requestPayload,
                      invocationUrl,
                      variables,
                      variableValues,
                      inputRow: completionInputRow,
                      agConfigFallbacks,
                      inputValues,
                      references: requestReferences,
                      links,
                  })

        lastRequestedRepetitions = executionItem.invocation.repetitions
        lastRunId = executionItem.invocation.runId
        attemptCount += 1

        dispatchWorkerRun?.(executionItem.workerPayload)
        return executionItem
    }

    return {
        id: `${params.entityId}:${params.rowId}`,
        references,
        lifecycle: {
            snapshot: buildLifecycleSnapshot,
            isRunning: (get) => buildLifecycleSnapshot(get).isRunning,
            isFailed: (get) => buildLifecycleSnapshot(get).isFailed,
            canRetry: (get) => buildLifecycleSnapshot(get).canRetry,
            repetitionCount: (get) => buildLifecycleSnapshot(get).repetitionCount,
            repetitionIndex: (get) => buildLifecycleSnapshot(get).repetitionIndex,
        },
        run: (runParams) => buildExecutionItemFromRunParams(runParams, false),
        retry: (runParams) => buildExecutionItemFromRunParams(runParams, true),
        cancel: ({get, set, dispatchWorkerCancel}) => {
            const cancelledRunId = cancelExecutionItemRun(get, set, references)
            if (cancelledRunId) dispatchWorkerCancel?.(cancelledRunId)
        },
    }
}

function resolveBaseUrl(): string {
    return getAgentaApiUrl() || (globalThis.location?.origin ?? "")
}

function constructPlaygroundTestPath(runtimePrefix: string, routePath?: string): string {
    return `${runtimePrefix}${routePath ? `/${routePath}` : ""}/test`
}

function isSupportedFetchProtocol(protocol: string): boolean {
    return protocol === "http:" || protocol === "https:"
}

function resolveExplicitInvocationCandidate(candidate: string, baseUrl: string): string | null {
    try {
        const absolute = new URL(candidate)
        return isSupportedFetchProtocol(absolute.protocol) ? absolute.toString() : null
    } catch {
        if (baseUrl) {
            try {
                const resolved = new URL(candidate, baseUrl)
                return isSupportedFetchProtocol(resolved.protocol) ? resolved.toString() : null
            } catch {
                return candidate
            }
        }
        return candidate
    }
}

function resolveInvocationUrl(
    invocationUrl: string | null | undefined,
    requestPayload: RequestPayloadData | null | undefined,
    entityData: TransformVariantInput | null | undefined,
): string {
    const bridgeInvocationUrl = readString(invocationUrl)
    const requestPayloadInvocationUrl = readString(requestPayload?.invocationUrl)
    const entityInvocationUrl = readString(entityData?.invocationUrl)
    const entityUri = readString(
        (entityData as Record<string, unknown> | null | undefined)?.uri as string | undefined,
    )
    const baseUrl = resolveBaseUrl()

    const explicitCandidates = [
        bridgeInvocationUrl,
        requestPayloadInvocationUrl,
        entityInvocationUrl,
        entityUri,
    ].filter((value): value is string => Boolean(value))

    for (const candidate of explicitCandidates) {
        // Guard against non-fetchable schemes (e.g. "agenta:...") while still
        // allowing valid relative URLs like "/api/evaluators/{key}/run".
        const resolved = resolveExplicitInvocationCandidate(candidate, baseUrl)
        if (resolved) {
            return resolved
        }
    }

    // The legacy /test fallback needs a runtime prefix; without one the path
    // resolves to the web app's origin and returns the 404 HTML page.
    const runtimePrefix = readString(requestPayload?.runtimePrefix) || ""
    if (!runtimePrefix) return ""

    const routePath = readString(requestPayload?.routePath)
    const path = constructPlaygroundTestPath(runtimePrefix, routePath)

    if (!baseUrl) return path
    try {
        return new URL(path, baseUrl).toString()
    } catch {
        return path
    }
}

function appendQueryParams(
    invocationUrl: string,
    params: Record<string, string | undefined>,
): string {
    const entries = Object.entries(params).filter(([, value]) => Boolean(value))
    if (entries.length === 0) return invocationUrl

    try {
        const url = new URL(invocationUrl)
        for (const [key, value] of entries) {
            if (!value) continue
            url.searchParams.set(key, value)
        }
        return url.toString()
    } catch {
        const query = new URLSearchParams(
            entries.reduce<Record<string, string>>((acc, [key, value]) => {
                if (value) acc[key] = value
                return acc
            }, {}),
        ).toString()
        if (!query) return invocationUrl
        return invocationUrl.includes("?")
            ? `${invocationUrl}&${query}`
            : `${invocationUrl}?${query}`
    }
}

function resolveApplicationId(
    requestPayload: RequestPayloadData | null,
    entityData: TransformVariantInput | null,
): string | undefined {
    const directAppId = readString(requestPayload?.appId)
    if (directAppId) return directAppId

    const payloadRefs = asRecord((requestPayload as Record<string, unknown> | null)?.references)
    const appRef = asRecord(payloadRefs?.application)
    const appIdFromRefs =
        readString(appRef?.id) || readString(appRef?.app_id) || readString(appRef?.appId)
    if (appIdFromRefs) return appIdFromRefs

    const entity = asRecord(entityData)
    return (
        readString(entity?.appId) ||
        readString(entity?.app_id) ||
        readString(entity?.workflow_id) ||
        undefined
    )
}

export function resolveAgConfigCandidate(value: unknown): Record<string, unknown> {
    const rec = asRecord(value)
    if (!rec) return {}

    const nested = asRecord(rec.ag_config) ?? asRecord(rec.agConfig)
    if (nested) return nested
    return rec
}

function firstNonEmptyAgConfig(
    candidates: AgConfigFallbackCandidate[] | undefined,
): Record<string, unknown> | null {
    for (const candidate of candidates || []) {
        const resolved = resolveAgConfigCandidate(candidate.value)
        if (Object.keys(resolved).length > 0) return resolved
    }
    return null
}

function getPromptModel(
    entityData: TransformVariantInput | null | undefined,
    requestBody: Record<string, unknown>,
): string | undefined {
    const agConfig = asRecord(requestBody.ag_config)
    const promptFromConfig = asRecord(agConfig?.prompt)
    const promptsFromConfig = Array.isArray(agConfig?.prompts) ? agConfig?.prompts : []
    const firstPromptFromConfig =
        promptsFromConfig.length > 0 ? asRecord(promptsFromConfig[0]) : null

    const entityParams = asRecord(entityData?.parameters)
    const entityAgConfig = (() => {
        const fromSnake = resolveAgConfigCandidate(entityParams?.ag_config)
        if (Object.keys(fromSnake).length > 0) return fromSnake
        return resolveAgConfigCandidate(entityParams?.agConfig)
    })()

    const promptFromEntityAgConfig = asRecord(entityAgConfig.prompt)
    const promptFromEntityParams = asRecord(entityParams?.prompt)

    const candidates = [
        promptFromConfig,
        firstPromptFromConfig,
        promptFromEntityAgConfig,
        promptFromEntityParams,
    ]

    for (const prompt of candidates) {
        if (!prompt) continue
        const llmConfig = asRecord(prompt.llm_config) ?? asRecord(prompt.llmConfig)
        const model = readString(llmConfig?.model)
        if (model) return model
    }

    return undefined
}

function isFileReference(value: string): boolean {
    return /^https?:\/\//i.test(value) || value.startsWith("file_") || value.startsWith("file-")
}

function normalizeFileMessageParts(messages: unknown[]): void {
    for (const message of messages) {
        const messageRec = asRecord(message)
        if (!messageRec) continue
        const content = Array.isArray(messageRec.content) ? messageRec.content : null
        if (!content) continue

        for (const part of content) {
            const partRec = asRecord(part)
            if (!partRec) continue
            if (partRec.type !== "file") continue

            const file = asRecord(partRec.file)
            if (!file) continue

            const fileId = readString(file.file_id)
            if (fileId && fileId.startsWith("data:")) {
                file.file_data = fileId
                delete file.file_id
            }

            if ("name" in file && "filename" in file) {
                file.filename = file.filename || file.name
                delete file.name
            } else if ("name" in file) {
                file.filename = file.name
                delete file.name
            }

            if ("mime_type" in file && "format" in file) {
                file.format = file.format || file.mime_type
                delete file.mime_type
            } else if ("mime_type" in file) {
                file.format = file.mime_type
                delete file.mime_type
            }

            for (const key of Object.keys(file)) {
                if (file[key] === "") delete file[key]
            }
        }
    }
}

function stripFileMetadataForUrlAttachments(messages: unknown[]): void {
    for (const message of messages) {
        const messageRec = asRecord(message)
        if (!messageRec) continue
        const content = Array.isArray(messageRec.content) ? messageRec.content : null
        if (!content) continue

        for (const part of content) {
            const partRec = asRecord(part)
            if (!partRec) continue
            if (partRec.type !== "file") continue

            const file = asRecord(partRec.file)
            if (!file) continue

            const fileId = readString(file.file_id) || readString(file.fileId)
            if (!fileId || !isFileReference(fileId)) continue

            delete file.filename
            delete file.format
        }
    }
}

function applyModelAttachmentRules(
    entityData: TransformVariantInput | null | undefined,
    requestBody: Record<string, unknown>,
): void {
    const messages = Array.isArray(requestBody.messages) ? requestBody.messages : null
    if (!messages) return

    const modelName = getPromptModel(entityData, requestBody)
    if (modelName) {
        const allowed = MODEL_ATTACHMENT_ALLOWLIST.some((token) =>
            modelName.toLowerCase().includes(token),
        )
        if (allowed) return
    }

    stripFileMetadataForUrlAttachments(messages)
}

function buildRequestBody(
    mode: ExecutionMode,
    params: {
        entityData: TransformVariantInput | null | undefined
        inputRow?: Record<string, unknown>
        chatHistory?: TransformMessage[]
        requestPayload: RequestPayloadData | null | undefined
        variables: string[]
        variableValues: Record<string, unknown>
        entityId: string
        agConfigFallbacks?: AgConfigFallbackCandidate[]
    },
): Record<string, unknown> {
    const {
        entityData,
        inputRow,
        chatHistory,
        requestPayload,
        variables,
        variableValues,
        agConfigFallbacks,
    } = params

    // Build raw ag_config from requestPayload (already raw parameters)
    const payloadAgConfig = asRecord(requestPayload?.ag_config)
    const rawAgConfig =
        payloadAgConfig && Object.keys(payloadAgConfig).length > 0
            ? payloadAgConfig
            : firstNonEmptyAgConfig(agConfigFallbacks) || undefined

    const requestBody = stripAgentaMetadataDeep(
        transformToRequestBody({
            variant: (entityData || {}) as TransformVariantInput,
            ...(mode === "completion" ? {inputRow} : {}),
            ...(mode === "chat" ? {chatHistory} : {}),
            spec: requestPayload?.spec as OpenAPISpec | undefined,
            routePath: requestPayload?.routePath,
            variables,
            variableValues,
            isChat: mode === "chat",
            isCustom: requestPayload?.isCustom,
            appType: requestPayload?.appType || undefined,
            rawAgConfig: rawAgConfig as Record<string, unknown> | undefined,
        }),
    ) as Record<string, unknown>

    if (Array.isArray(requestBody.messages)) {
        const messages = stripEnhancedWrappers(requestBody.messages)
        requestBody.messages = Array.isArray(messages) ? messages : []
        if (Array.isArray(requestBody.messages)) {
            // Strip internal-only fields that LLM APIs reject (e.g. OpenAI)
            for (const msg of requestBody.messages) {
                const rec = msg as Record<string, unknown>
                delete rec.id
                delete rec.parentId
                delete rec.sessionId

                // Normalize chat-history tool call keys to provider/API format.
                // Some UI paths keep camelCase keys (`toolCalls`, `toolCallId`),
                // but runtime chat payloads must use snake_case.
                const toolCalls = rec.tool_calls ?? rec.toolCalls
                if (Array.isArray(toolCalls)) {
                    rec.tool_calls = toolCalls.map((call) => {
                        const callRec =
                            call && typeof call === "object"
                                ? ({...(call as Record<string, unknown>)} as Record<
                                      string,
                                      unknown
                                  >)
                                : call
                        if (callRec && typeof callRec === "object") {
                            if (!("id" in callRec) && typeof callRec.__id === "string") {
                                callRec.id = callRec.__id
                            }
                            delete callRec.__id
                        }
                        return callRec
                    })
                }
                delete rec.toolCalls

                const toolCallId = rec.tool_call_id ?? rec.toolCallId
                if (toolCallId !== undefined && toolCallId !== null) {
                    rec.tool_call_id = String(toolCallId)
                }
                delete rec.toolCallId
            }
            normalizeFileMessageParts(requestBody.messages)
            applyModelAttachmentRules(entityData, requestBody)
        }
    }

    if ("repetitions" in requestBody) {
        delete requestBody.repetitions
    }

    // Add references from requestPayload for trace attribution
    const payloadRefs = asRecord((requestPayload as Record<string, unknown> | null)?.references)
    if (payloadRefs && Object.keys(payloadRefs).length > 0) {
        requestBody.references = payloadRefs
    }

    return requestBody
}

function buildExecutionItem(
    mode: ExecutionMode,
    params: BuildExecutionItemBaseParams & {
        inputRow?: Record<string, unknown>
        chatHistory?: TransformMessage[]
    },
): ExecutionItem {
    const requestPayload = params.requestPayload || null
    const entityData = params.entityData || null

    // When the entity provides a pre-built request body (e.g. workflow invoke),
    // use it directly instead of building a legacy ag_config body.
    const rawPayloadRecord = asRecord(requestPayload)
    const isRawBody = !!rawPayloadRecord?.__rawBody

    const resolvedInvocationUrl = resolveInvocationUrl(
        params.invocationUrl,
        requestPayload,
        entityData,
    )
    // Keep an empty URL empty so the execution path can report a clear error
    // instead of POSTing to the web app origin and parsing its 404 HTML page.
    const invocationUrlWithQuery = resolvedInvocationUrl
        ? appendQueryParams(resolvedInvocationUrl, {
              // __rawBody payloads (workflow invoke) don't need application_id query param —
              // the backend resolves the handler from the request body interface/URI.
              application_id: isRawBody
                  ? undefined
                  : resolveApplicationId(requestPayload, entityData),
              project_id: params.headers.Authorization
                  ? readString(params.projectId || undefined)
                  : undefined,
          })
        : ""
    const isAppWorkflow = !!rawPayloadRecord?.__appWorkflow
    const requestBody = isRawBody
        ? (() => {
              if (!rawPayloadRecord) return {}

              if (isAppWorkflow) {
                  // App workflow __rawBody: use buildRequestBody to resolve inputs/messages
                  // from the current row, then wrap into the invoke payload format.
                  const meta = rawPayloadRecord.__meta as Record<string, unknown> | undefined
                  const appPayload: RequestPayloadData = {
                      ag_config: (meta?.agConfig as Record<string, unknown>) ?? {},
                      isChat: (meta?.isChat as boolean) ?? false,
                      appType: null,
                      invocationUrl: null,
                      runtimePrefix: (meta?.runtimePrefix as string) ?? null,
                      variables: (meta?.variables as string[]) ?? [],
                      spec: meta?.spec,
                      routePath: meta?.routePath as string | undefined,
                      isCustom: false,
                      appId: (meta?.appId as string) ?? null,
                  }
                  const legacyBody = buildRequestBody(mode, {
                      entityData,
                      inputRow: params.inputRow,
                      chatHistory: params.chatHistory,
                      requestPayload: appPayload,
                      variables: params.variables || [],
                      variableValues: params.variableValues || {},
                      entityId: params.entityId,
                      agConfigFallbacks: params.agConfigFallbacks,
                  })

                  // Extract parts from the legacy body to build the invoke format
                  const {
                      ag_config: legacyAgConfig,
                      inputs: legacyInputs,
                      messages: legacyMessages,
                      references: legacyRefs,
                      ...legacyRest
                  } = legacyBody as Record<string, unknown>

                  // Build workflow inputs from the legacy request shape. For workflow
                  // invoke, the entire testcase/root payload belongs under data.inputs.
                  const dataInputs: Record<string, unknown> = {}
                  if (legacyInputs && typeof legacyInputs === "object") {
                      Object.assign(dataInputs, legacyInputs)
                  }
                  // Preserve any other top-level fields from the legacy body as part
                  // of the same inputs object.
                  for (const [key, value] of Object.entries(legacyRest)) {
                      if (value !== undefined) {
                          dataInputs[key] = value
                      }
                  }
                  if (Array.isArray(legacyMessages) && legacyMessages.length > 0) {
                      dataInputs.messages = legacyMessages
                  }

                  // Build the invoke format — parameters go under data, not configuration
                  const {
                      __rawBody: _,
                      __appWorkflow: _aw,
                      __meta: _m,
                      ...baseBody
                  } = rawPayloadRecord
                  const baseData = asRecord(baseBody.data)
                  const body: Record<string, unknown> = {
                      ...baseBody,
                      data: {
                          ...baseData,
                          inputs: dataInputs,
                          parameters: legacyAgConfig
                              ? (legacyAgConfig as Record<string, unknown>)
                              : baseData?.parameters,
                      },
                  }
                  delete body.configuration

                  // Merge references from legacy body and raw payload
                  const refs = {
                      ...(asRecord(baseBody.references) ?? {}),
                      ...(asRecord(legacyRefs) ?? {}),
                  }
                  if (Object.keys(refs).length > 0) {
                      body.references = refs
                  }

                  return body
              }

              // Evaluator / other __rawBody payloads: pass through as before
              const {__rawBody: _, invocationUrl: _url, ...body} = rawPayloadRecord
              // When inputValues are provided (e.g. from chain execution),
              // merge them into the raw body's inputs field.
              if (params.inputValues && Object.keys(params.inputValues).length > 0) {
                  // For workflow invoke payloads with nested `data` structure
                  // (e.g. POST {serviceUrl}/invoke), populate data.inputs
                  // with all input values and data.outputs with the upstream
                  // model output so the backend template engine can resolve
                  // {{inputs}} and {{outputs}} correctly.
                  if (body.data && typeof body.data === "object") {
                      const dataObj = body.data as Record<string, unknown>
                      const iv = params.inputValues as Record<string, unknown>
                      // Evaluator envelope: when ports expose `inputs` + `outputs`
                      // directly (evaluator runnables), `iv` already has the envelope
                      // shape. `iv.inputs` is the testcase row (object) and
                      // `iv.outputs` is the upstream app output. Values may be
                      // JSON-encoded strings — after the user edits the cell via
                      // the JSON editor, or when the cell is stringified on the
                      // wire — so we attempt to parse them back to their structured
                      // form before unpacking. Unpack so `data.inputs` holds just
                      // the row (not a doubly-nested `{inputs, outputs}` wrapper).
                      const parseIfJsonObject = (value: unknown): unknown => {
                          if (typeof value !== "string") return value
                          const trimmed = value.trim()
                          if (
                              !(trimmed.startsWith("{") && trimmed.endsWith("}")) &&
                              !(trimmed.startsWith("[") && trimmed.endsWith("]"))
                          ) {
                              return value
                          }
                          try {
                              return JSON.parse(trimmed)
                          } catch {
                              return value
                          }
                      }
                      const parsedInputs = parseIfJsonObject(iv.inputs)
                      const isEnvelope =
                          parsedInputs !== undefined &&
                          parsedInputs !== null &&
                          typeof parsedInputs === "object" &&
                          !Array.isArray(parsedInputs)
                      // Field ports extracted from `{{$.inputs.<field>}}` /
                      // `{{<field>}}` references in the evaluator prompt arrive
                      // as siblings of `inputs`/`outputs` in `iv`. Merge them
                      // into `data.inputs` so the SDK's resolver context has
                      // both the catch-all envelope (`inputs` cell) and the
                      // per-field values addressable via the same paths the
                      // prompt uses. Field values win on key collisions —
                      // they're the more-specific user intent.
                      //
                      // `prediction` is preserved as the legacy alias for the
                      // outputs envelope (it maps to `iv.outputs` below) and
                      // also excluded from the merge.
                      const fieldOverrides: Record<string, unknown> = {}
                      for (const [key, value] of Object.entries(iv)) {
                          if (key === "inputs" || key === "outputs" || key === "prediction") {
                              continue
                          }
                          fieldOverrides[key] = parseIfJsonObject(value)
                      }
                      const baseInputs = isEnvelope
                          ? (parsedInputs as Record<string, unknown>)
                          : ({} as Record<string, unknown>)
                      const mergedInputs = {...baseInputs, ...fieldOverrides}
                      // Preserve the legacy "iv as-is" fallback when there's
                      // no envelope cell AND no field ports — happens for
                      // pre-WP-B1 evaluator chains where `iv` was the whole
                      // testcase row.
                      const hasAnyInputContent =
                          isEnvelope || Object.keys(fieldOverrides).length > 0
                      dataObj.inputs = hasAnyInputContent ? mergedInputs : iv
                      // Set data.outputs from the upstream output value.
                      // Schema-driven inputs use "outputs" key; legacy uses "prediction".
                      const upstreamOutputValueRaw = iv.outputs ?? iv.prediction
                      if (upstreamOutputValueRaw !== undefined) {
                          dataObj.outputs = parseIfJsonObject(upstreamOutputValueRaw)
                      }
                  } else {
                      // Fallback for payloads without nested data structure
                      body.inputs = params.inputValues
                  }
              }
              if (params.links && Object.keys(params.links).length > 0) {
                  const existingLinks = asRecord(body.links)
                  body.links = existingLinks ? {...existingLinks, ...params.links} : params.links
              }
              if (params.references && Object.keys(params.references).length > 0) {
                  const existingReferences = asRecord(body.references)
                  body.references = existingReferences
                      ? {...existingReferences, ...params.references}
                      : params.references
              }
              return body
          })()
        : buildRequestBody(mode, {
              entityData,
              inputRow: params.inputRow,
              chatHistory: params.chatHistory,
              requestPayload,
              variables: params.variables || [],
              variableValues: params.variableValues || {},
              entityId: params.entityId,
              agConfigFallbacks: params.agConfigFallbacks,
          })

    if (params.links && Object.keys(params.links).length > 0) {
        const existingLinks = asRecord(requestBody.links)
        requestBody.links = existingLinks ? {...existingLinks, ...params.links} : params.links
    }
    if (params.references && Object.keys(params.references).length > 0) {
        const existingReferences = asRecord(requestBody.references)
        requestBody.references = existingReferences
            ? {...existingReferences, ...params.references}
            : params.references
    }

    // Final guard: never ship a local-draft / placeholder id in a reference —
    // the backend `/invoke` validator 422s on non-UUID reference ids (QA
    // 2026-06-05). Covers every reference source after they're merged above.
    if (requestBody.references !== undefined) {
        const sanitized = sanitizeReferenceIds(requestBody.references)
        if (sanitized && Object.keys(sanitized).length > 0) {
            requestBody.references = sanitized
        } else {
            delete requestBody.references
        }
    }

    const references: ExecutionItemReference = {
        loadableId: params.loadableId,
        rowId: params.rowId,
        entityId: params.entityId,
        sessionId: `sess:${params.entityId}`,
        ...(params.messageId ? {messageId: params.messageId} : {}),
    }

    const invocation: ExecutionItemInvocation = {
        runId: params.runId,
        invocationUrl: invocationUrlWithQuery,
        requestBody,
        headers: params.headers || {},
        repetitions: Math.max(1, params.repetitions),
    }

    const workerPayload: WorkerRunEntityRowPayload = {
        runId: invocation.runId,
        rowId: references.rowId,
        entityId: references.entityId,
        ...(references.messageId ? {messageId: references.messageId} : {}),
        invocationUrl: invocation.invocationUrl,
        requestBody: invocation.requestBody,
        headers: invocation.headers,
        repetitions: invocation.repetitions,
    }

    return {
        id: `${params.runId}:${params.entityId}:${params.rowId}`,
        mode,
        references,
        invocation,
        workerPayload,
    }
}

// ============================================================================
// PUBLIC BUILDERS
// ============================================================================

export function buildCompletionExecutionItem(
    params: BuildCompletionExecutionItemParams,
): ExecutionItem {
    return buildExecutionItem("completion", params)
}

export function buildChatExecutionItem(params: BuildChatExecutionItemParams): ExecutionItem {
    return buildExecutionItem("chat", params)
}

// ============================================================================
// EXECUTION RESULT HANDLER
// ============================================================================

export interface HandleExecutionResultPayload {
    loadableId: string
    sessionId: string
    rowId: string
    result: unknown
}

/**
 * Unified execution result handler.
 *
 * Processes a raw API result into the appropriate state model based on mode:
 * - **Completion**: registers the result in the execution reducer.
 * - **Chat**: builds assistant/tool messages, writes to flat message model,
 *   tracks execution state, and auto-appends a blank user message.
 *
 * This is the single owner of result→state mapping. The web worker integration
 * layer should dispatch here without knowing about chat vs completion internals.
 */
export const handleExecutionResultAtom = atom(
    null,
    (get, set, payload: HandleExecutionResultPayload) => {
        const {loadableId, sessionId, rowId, result: testResult} = payload
        if (!loadableId) return

        const isChat = get(isChatModeAtom) === true

        if (isChat) {
            const results = Array.isArray(testResult) ? testResult : [testResult]

            // Find the parent user message this response belongs to.
            // Use the rowId (which encodes the triggering user message) to
            // determine the correct parent — searching backward for "last
            // shared user message" is racy in comparison mode because the
            // first-to-finish variant auto-appends a blank user message
            // before the second variant's result arrives.
            // rowId format in comparison mode: "turn-<entityUUID>-lt-<msgId>"
            const ltIndex = rowId.indexOf("-lt-")
            const logicalRowId = ltIndex >= 0 ? rowId.slice(ltIndex + 1) : rowId
            const flatIds = get(messageIdsAtomFamily(loadableId))
            const flatById = get(messagesByIdAtomFamily(loadableId))

            let parentUserMsgId: string | undefined
            // First: try to resolve from the rowId (deterministic, race-free)
            if (logicalRowId) {
                const candidate = flatById[logicalRowId]
                if (
                    candidate &&
                    candidate.sessionId === SHARED_SESSION_ID &&
                    candidate.role === "user"
                ) {
                    parentUserMsgId = logicalRowId
                }
            }
            // Fallback: search backward (single-variant mode or unknown rowId format)
            if (!parentUserMsgId) {
                for (let i = flatIds.length - 1; i >= 0; i--) {
                    const m = flatById[flatIds[i]]
                    if (m && m.sessionId === SHARED_SESSION_ID && m.role === "user") {
                        parentUserMsgId = flatIds[i]
                        break
                    }
                }
            }

            const newMessages: ChatMessage[] = []
            for (const res of results) {
                const incoming = buildAssistantMessage(res)
                const msgId = generateMessageId()
                newMessages.push({
                    ...incoming,
                    id: msgId,
                    sessionId,
                    ...(parentUserMsgId ? {parentId: parentUserMsgId} : {}),
                } as ChatMessage)
            }

            if (newMessages.length === 0) return

            const lastMessage = newMessages[newMessages.length - 1]
            const assistantMsgId = lastMessage.id
            if (!assistantMsgId) return
            const hasToolCalls =
                Array.isArray(lastMessage.tool_calls) && lastMessage.tool_calls.length > 0

            // Write messages to flat model
            set(addMessagesAtom, {
                loadableId,
                messages: newMessages,
            })

            // Write execution state on the assistant message
            const traceId = extractTraceIdFromPayload(testResult) ?? undefined
            // Just-finished run: the trace may still be ingesting — keep retries aggressive.
            if (traceId) markTraceAsFresh(traceId)
            const errorMessage =
                lastMessage.role === "Error"
                    ? typeof lastMessage.content === "string"
                        ? lastMessage.content
                        : "Error"
                    : null

            if (errorMessage) {
                set(failMessageExecutionAtom, {
                    loadableId,
                    messageId: assistantMsgId,
                    error: errorMessage,
                })
                set(failRunAtom, {
                    loadableId,
                    stepId: parentUserMsgId ?? rowId,
                    sessionId,
                    error: {message: errorMessage},
                    traceId: traceId ?? null,
                })
            } else {
                set(completeMessageExecutionAtom, {
                    loadableId,
                    messageId: assistantMsgId,
                    result: {output: testResult, traceId},
                })

                // Register completion in execution reducer (for useExecutionCell compatibility)
                set(completeRunAtom, {
                    loadableId,
                    stepId: parentUserMsgId ?? rowId,
                    sessionId,
                    result: {output: testResult, traceId},
                })
            }

            // When the assistant returns tool_calls, create blank tool response
            // messages so the user (or gateway) can fill them in before continuing.
            if (hasToolCalls && lastMessage.tool_calls) {
                const existingToolMsgIds = get(messageIdsAtomFamily(loadableId))
                const existingToolById = get(messagesByIdAtomFamily(loadableId))
                const existingToolCount = existingToolMsgIds.filter((mid) => {
                    const m = existingToolById[mid]
                    return (
                        m &&
                        m.parentId === parentUserMsgId &&
                        m.sessionId === sessionId &&
                        m.role === "tool"
                    )
                }).length

                if (existingToolCount === 0) {
                    const toolMsgs: ChatMessage[] = lastMessage.tool_calls.map((tc, idx) => ({
                        id: generateMessageId(),
                        role: "tool",
                        name: tc.function.name || `tool_${idx + 1}`,
                        tool_call_id: tc.id,
                        content: "",
                        sessionId,
                        ...(parentUserMsgId ? {parentId: parentUserMsgId} : {}),
                    }))
                    set(addMessagesAtom, {loadableId, messages: toolMsgs})
                }
            }

            // Auto-append blank user message so the user can type the next turn.
            // In comparison mode multiple variants complete independently and
            // their assistant messages are appended in arrival order. A blank
            // user message added by the first variant may no longer be at the
            // tail when the second variant's assistant message lands after it.
            // Scan forward from the parent turn to find whether a blank shared
            // user message already exists anywhere after it.
            if (!hasToolCalls) {
                const updatedFlatIds = get(messageIdsAtomFamily(loadableId))
                const updatedFlatById = get(messagesByIdAtomFamily(loadableId))

                // Scan after the parent turn for an existing blank shared user message
                const parentIdx = parentUserMsgId ? updatedFlatIds.indexOf(parentUserMsgId) : -1
                const scanStart = parentIdx >= 0 ? parentIdx + 1 : 0

                let alreadyHasBlank = false
                for (let i = scanStart; i < updatedFlatIds.length; i++) {
                    const m = updatedFlatById[updatedFlatIds[i]]
                    if (m && m.sessionId === SHARED_SESSION_ID && m.role === "user" && !m.content) {
                        alreadyHasBlank = true
                        break
                    }
                }

                if (!alreadyHasBlank) {
                    set(addMessageAtom, {
                        loadableId,
                        message: {
                            id: generateMessageId(),
                            role: "user",
                            content: "",
                            sessionId: SHARED_SESSION_ID,
                        },
                    })
                }
            }

            return
        }

        // Completion mode: register result
        const completionTraceId = extractTraceIdFromPayload(testResult)
        if (completionTraceId) markTraceAsFresh(completionTraceId)
        set(completeRunAtom, {
            loadableId,
            stepId: rowId,
            sessionId,
            result: {
                output: testResult,
                traceId: completionTraceId,
            },
        })
    },
)
