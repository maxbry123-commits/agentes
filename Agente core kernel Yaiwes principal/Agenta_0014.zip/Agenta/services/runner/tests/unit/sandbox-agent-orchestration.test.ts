/**
 * Unit tests for sandbox-agent engine orchestration with fake sandbox/session handles.
 *
 * Run: pnpm test (or: pnpm exec vitest run tests/unit/sandbox-agent-orchestration.test.ts)
 */
import { afterEach, beforeEach, describe, it, vi } from "vitest";
import assert from "node:assert/strict";

import { declinedByUserText } from "../../src/tools/denial-text.ts";
import { tmpdir } from "node:os";
import {
  existsSync,
  lstatSync,
  mkdirSync,
  mkdtempSync,
  readFileSync,
  readlinkSync,
  rmSync,
  writeFileSync,
} from "node:fs";
import { join } from "node:path";

import type { AgentEvent, AgentRunRequest } from "../../src/protocol.ts";
import {
  createSandboxAgentOtel,
  TOOL_NOT_EXECUTED_PAUSED,
} from "../../src/tracing/otel.ts";
import {
  PI_TRACE_CONTROL_FILE,
  piTraceFileName,
} from "../../src/tracing/pi-spool-protocol.ts";
import { PendingApprovalPauseController } from "../../src/engines/sandbox_agent/pause.ts";
import {
  platformCredentialForRequest,
  resolveRunOtlpTarget,
  shouldSuppressPausedToolCallUpdate,
} from "../../src/engines/sandbox_agent/runtime-policy.ts";
import { mountStorage } from "../../src/engines/sandbox_agent/mount.ts";
import { buildPiGateEnvelope } from "../../src/engines/sandbox_agent/pi-gate-envelope.ts";
import { appendPlatformGuidance } from "../../src/engines/sandbox_agent/system-prompt-appendix.ts";
import { platformGuidanceAppendix } from "../../src/engines/sandbox_agent/platform-guidance.ts";
import type { PermissionDecision } from "../../src/responder.ts";
import {
  runSandboxAgent,
  type SandboxAgentDeps,
} from "../../src/engines/sandbox_agent.ts";
import { resetRunnerConfigCache } from "../../src/config/runner-config.ts";
import {
  fakeHarness,
  flushPromises,
  type FakeOptions,
} from "../utils/sandbox-agent-harness.ts";

// Orchestration cases include Daytona runs: enable it (with a provisioning credential) on top of
// the hermetic scrub, then drop the memoized config so the run plan reads the enabled set.
beforeEach(() => {
  process.env.AGENTA_RUNNER_ENABLED_SANDBOX_PROVIDERS = "local,daytona";
  process.env.AGENTA_RUNNER_DAYTONA_API_KEY = "test-key";
  resetRunnerConfigCache();
});

afterEach(() => {
  vi.unstubAllGlobals();
});

describe("PendingApprovalPauseController", () => {
  it("tracks paused tool-call ids", () => {
    const pause = new PendingApprovalPauseController(() => {});

    assert.equal(pause.isPausedToolCall(undefined), false);
    assert.equal(pause.isPausedToolCall("tool-1"), false);

    pause.markPausedToolCall("tool-1");

    assert.equal(pause.isPausedToolCall("tool-1"), true);
    assert.equal(pause.isPausedToolCall("tool-2"), false);
  });

  it("passes through a failed frame for an allowed execution during a pause", () => {
    const pause = new PendingApprovalPauseController(() => {});
    pause.markAllowedExecution("tool-allowed");
    pause.pause();

    assert.equal(
      shouldSuppressPausedToolCallUpdate(
        {
          sessionUpdate: "tool_call_update",
          toolCallId: "tool-allowed",
          status: "failed",
        },
        pause,
      ),
      false,
    );
  });
});

describe("runSandboxAgent orchestration", () => {
  // NOTE: in-band redaction of the LIVE event stream / result / trace-start input was a
  // daytona-secret-materialization concept that was not adopted. Redaction happens at the
  // durable/exported sinks (persisted transcript + exported spans; see redaction-sinks.test.ts),
  // seeded per run from the typed model and MCP credentials.

  it("returns a successful one-shot result and cleans up acquired resources", async () => {
    const { calls, deps } = fakeHarness();

    const result = await runSandboxAgent(
      {
        harness: "claude",
        messages: [{ role: "user", content: "hello" }],
        model: "requested-model",
      },
      undefined,
      undefined,
      deps,
    );

    assert.equal(result.ok, true);
    if (!result.ok) return;
    assert.equal(result.output, "assistant output");
    assert.deepEqual(result.messages, [
      { role: "assistant", content: "assistant output" },
    ]);
    assert.deepEqual(result.usage, {
      input: 6,
      output: 4,
      total: 10,
      cost: 0.25,
    });
    assert.equal(result.stopReason, "complete");
    assert.equal(result.sessionId, "session-1");
    assert.equal(result.model, "requested-model");
    assert.equal(result.traceId, "trace-1");
    assert.equal(result.capabilities?.streamingDeltas, false);
    assert.equal(calls.daemonAgent, "claude");
    assert.equal(calls.createSessionOptions.agent, "claude");
    assert.equal(calls.createSessionOptions.cwd, "/tmp/agenta-fake-cwd");
    assert.deepEqual(calls.promptBlocks, [{ type: "text", text: "hello" }]);
    assert.deepEqual(calls.runStart.messages, [
      { role: "user", content: "hello" },
    ]);
    assert.equal(calls.runFinished, 1);
    assert.equal(calls.runFlushed, 1);
    assert.equal(calls.sandboxDestroyed, 1);
    assert.equal(calls.sandboxDisposed, 1);
    assert.equal(calls.workspaceCleanup, 1);
  });

  it("passes the live turn credential provider to the trace exporter", async () => {
    const { calls, deps } = fakeHarness();
    let authorization = "Secret initial";
    const credential = () => authorization;

    const result = await runSandboxAgent(
      {
        harness: "claude",
        messages: [{ role: "user", content: "hello" }],
      },
      undefined,
      undefined,
      deps,
      { credential },
    );

    assert.equal(result.ok, true);
    assert.equal(typeof calls.otelOptions.authorization, "function");
    authorization = "Secret refreshed";
    assert.equal(calls.otelOptions.authorization(), "Secret refreshed");
  });

  it("refreshes a standalone Agenta credential while a long turn is active", async () => {
    vi.useFakeTimers();
    try {
      vi.stubEnv("AGENTA_API_URL", "https://api.agenta.test/api");
      vi.stubEnv("AGENTA_RUNNER_RUN_TTFB_TIMEOUT_MS", "900000");
      vi.stubEnv("AGENTA_RUNNER_RUN_IDLE_TIMEOUT_MS", "900000");
      vi.stubEnv("AGENTA_RUNNER_RUN_TOTAL_TIMEOUT_MS", "900000");
      resetRunnerConfigCache();
      const refreshRequests: Array<{ url: string; authorization: string }> = [];
      vi.stubGlobal(
        "fetch",
        async (url: string | URL | Request, init?: RequestInit) => {
          const renderedUrl = String(url);
          refreshRequests.push({
            url: renderedUrl,
            authorization: String(
              (init?.headers as Record<string, string> | undefined)
                ?.authorization ?? "",
            ),
          });
          return new Response(
            JSON.stringify({ credentials: "Secret refreshed" }),
            { status: 200 },
          );
        },
      );
      const request: AgentRunRequest = {
        harness: "claude",
        messages: [{ role: "user", content: "hello" }],
        telemetry: {
          exporters: {
            otlp: {
              endpoint: "https://api.agenta.test/api/otlp/v1/traces",
              headers: { authorization: "Secret initial" },
            },
          },
        },
      };
      const { calls, deps } = fakeHarness({
        afterPromptEvents: async () => {
          await vi.advanceTimersByTimeAsync(5 * 60 * 1_000);
        },
      });

      const result = await runSandboxAgent(request, undefined, undefined, deps);

      assert.equal(result.ok, true, JSON.stringify(result));
      assert.equal(platformCredentialForRequest(request), "Secret initial");
      assert.equal(calls.otelOptions.authorization(), "Secret refreshed");
      assert.deepEqual(refreshRequests, [
        {
          url: "https://api.agenta.test/api/sessions/interactions/query",
          authorization: "Secret initial",
        },
        {
          url: "https://api.agenta.test/api/access/permissions/check?action=run_service&resource_type=service",
          authorization: "Secret initial",
        },
      ]);
    } finally {
      vi.useRealTimers();
    }
  });

  it("never treats a third-party collector header as a platform credential", () => {
    assert.equal(
      platformCredentialForRequest({
        harness: "claude",
        messages: [{ role: "user", content: "hello" }],
        telemetry: {
          exporters: {
            otlp: {
              endpoint: "https://collector.example.test/v1/traces",
              headers: { authorization: "Bearer collector-secret" },
            },
          },
        },
      }),
      "",
    );
  });

  it("keeps platform rotation away from third-party collector credentials", () => {
    vi.stubEnv("AGENTA_API_URL", "https://api.agenta.test/api");
    let live = "Secret initial";
    const platform = resolveRunOtlpTarget(
      {
        harness: "claude",
        messages: [{ role: "user", content: "hello" }],
        telemetry: {
          exporters: {
            otlp: {
              endpoint: "https://api.agenta.test/api/otlp/v1/traces",
              headers: { authorization: "Secret initial" },
            },
          },
        },
      },
      () => live,
    );
    const collector = resolveRunOtlpTarget(
      {
        harness: "claude",
        messages: [{ role: "user", content: "hello" }],
        telemetry: {
          exporters: {
            otlp: {
              endpoint: "https://collector.example.test/v1/traces",
              headers: { authorization: "Bearer collector-secret" },
            },
          },
        },
      },
      () => live,
    );

    live = "Secret refreshed";
    assert.equal(platform.authorizationSource, "platform");
    assert.equal(platform.authorization(), "Secret refreshed");
    assert.equal(collector.authorizationSource, "exporter");
    assert.equal(collector.authorization(), "Bearer collector-secret");

    vi.stubEnv("AGENTA_CREDENTIALS", "Secret runner-fallback");
    const headerless = resolveRunOtlpTarget(
      {
        harness: "pi_core",
        messages: [{ role: "user", content: "hello" }],
        telemetry: {
          exporters: {
            otlp: { endpoint: "https://api.agenta.test/api/otlp/v1/traces" },
          },
        },
      },
      () => "",
    );
    assert.equal(headerless.authorizationSource, "platform");
    assert.equal(headerless.authorization(), "Secret runner-fallback");
  });

  it("delivers the current legacy inline image before one text block", async () => {
    const { calls, deps } = fakeHarness({ capabilities: { images: true } });

    const result = await runSandboxAgent(
      {
        harness: "pi_core",
        messages: [
          {
            role: "user",
            content: [
              { type: "image", uri: "data:image/png;base64,AQID" },
              { type: "text", text: "inspect this" },
            ],
          },
        ],
      },
      undefined,
      undefined,
      deps,
    );

    assert.equal(result.ok, true);
    assert.deepEqual(calls.promptBlocks, [
      { type: "image", data: "AQID", mimeType: "image/png" },
      { type: "text", text: "inspect this" },
    ]);
  });

  it("delivers a legacy image-only turn as a non-empty image-only prompt", async () => {
    const { calls, deps, logs } = fakeHarness({
      capabilities: { images: true },
    });

    const result = await runSandboxAgent(
      {
        harness: "pi_core",
        messages: [
          {
            role: "user",
            content: [{ type: "image", uri: "data:image/png;base64,AQID" }],
          },
        ],
      },
      undefined,
      undefined,
      deps,
    );

    assert.equal(result.ok, true);
    assert.deepEqual(calls.promptBlocks, [
      { type: "image", data: "AQID", mimeType: "image/png" },
    ]);
    assert.ok(calls.promptBlocks.length > 0);
    assert.deepEqual(
      logs.filter((message) => message.includes("legacy inline image")),
      [
        "[attachments] legacy inline image delivery=native reason=native_supported",
      ],
    );
  });

  it("keeps a degraded legacy image-only prompt non-empty", async () => {
    const { calls, deps } = fakeHarness({
      capabilities: { images: false },
    });

    const result = await runSandboxAgent(
      {
        harness: "pi_core",
        messages: [
          {
            role: "user",
            content: [{ type: "image", uri: "data:image/png;base64,AQID" }],
          },
        ],
      },
      undefined,
      undefined,
      deps,
    );

    assert.equal(result.ok, true);
    assert.deepEqual(calls.promptBlocks, [
      {
        type: "text",
        text: "[inline image could not be delivered to this harness]",
      },
    ]);
  });
  it.each([
    { mimeType: "image/png", capabilities: { images: false } },
    { mimeType: "image/svg+xml", capabilities: { images: true } },
  ])(
    "a legacy inline $mimeType image degrades rather than throws",
    async (testCase) => {
      const { calls, deps, events, logs } = fakeHarness({
        capabilities: testCase.capabilities,
      });
      const result = await runSandboxAgent(
        {
          harness: "pi_core",
          messages: [
            {
              role: "user",
              content: [
                {
                  type: "image",
                  uri: `data:${testCase.mimeType};base64,AQID`,
                },
                { type: "text", text: "inspect this" },
              ],
            },
          ],
        },
        undefined,
        undefined,
        deps,
      );

      assert.equal(result.ok, true, testCase.mimeType);
      assert.deepEqual(calls.promptBlocks, [
        { type: "text", text: "inspect this" },
      ]);
      assert.equal(
        events.some((event) => event.type === "attachment_delivery"),
        false,
      );
      assert.match(
        logs.find((message) => message.includes("legacy inline image")) ?? "",
        /delivery=degraded reason=[a-z_]+$/,
      );
    },
  );

  it("degrades a legacy inline image when the caller's model declares no image input", async () => {
    const { calls, deps, logs } = fakeHarness({
      capabilities: { images: true },
    });

    const result = await runSandboxAgent(
      {
        harness: "pi_core",
        modelCapabilities: { inputModalities: ["text"] },
        messages: [
          {
            role: "user",
            content: [
              { type: "image", uri: "data:image/png;base64,AQID" },
              { type: "text", text: "inspect this" },
            ],
          },
        ],
      },
      undefined,
      undefined,
      deps,
    );

    assert.equal(result.ok, true);
    assert.deepEqual(calls.promptBlocks, [
      { type: "text", text: "inspect this" },
    ]);
    assert.equal(
      logs.find((message) => message.includes("legacy inline image")),
      "[attachments] legacy inline image delivery=degraded reason=model_modality_unknown",
    );
  });

  it("delivers a legacy inline image natively when the caller declares no capabilities", async () => {
    const { calls, deps, logs } = fakeHarness({
      capabilities: { images: true },
    });

    const result = await runSandboxAgent(
      {
        harness: "pi_core",
        messages: [
          {
            role: "user",
            content: [
              { type: "image", uri: "data:image/png;base64,AQID" },
              { type: "text", text: "inspect this" },
            ],
          },
        ],
      },
      undefined,
      undefined,
      deps,
    );

    assert.equal(result.ok, true);
    assert.deepEqual(calls.promptBlocks, [
      { type: "image", data: "AQID", mimeType: "image/png" },
      { type: "text", text: "inspect this" },
    ]);
    assert.equal(
      logs.find((message) => message.includes("legacy inline image")),
      "[attachments] legacy inline image delivery=native reason=native_supported",
    );
  });

  it("a failed historical restore is survivable through a full cold turn", async () => {
    const deadId = "11111111-1111-4111-8111-111111111111";
    const healthyId = "22222222-2222-4222-8222-222222222222";
    vi.stubGlobal("fetch", async (input: Parameters<typeof fetch>[0]) => {
      if (String(input).includes(deadId)) {
        return new Response("gone", { status: 404 });
      }
      if (String(input).includes(healthyId)) {
        return new Response(new Uint8Array([7, 8]), {
          status: 200,
          headers: {
            "content-type": "text/plain",
            "content-disposition": "attachment; filename=healthy.txt",
          },
        });
      }
      throw new Error(`unexpected URL ${String(input)}`);
    });
    const cwd = join(
      tmpdir(),
      "agenta-attachment-restore-" + process.pid + "-" + Date.now(),
    );
    mkdirSync(cwd, { recursive: true });
    const { calls, deps } = fakeHarness({ cwd });

    try {
      const result = await runSandboxAgent(
        {
          harness: "pi_core",
          sessionId: "session-1",
          messages: [
            {
              role: "user",
              content: [
                {
                  type: "attachment",
                  attachmentId: deadId,
                  filename: "report.pdf",
                },
                {
                  type: "attachment",
                  attachmentId: healthyId,
                  filename: "healthy.txt",
                },
                { type: "text", text: "old request" },
              ],
            },
            { role: "assistant", content: "ready" },
            { role: "user", content: "continue" },
          ],
        },
        undefined,
        undefined,
        deps,
      );

      assert.equal(result.ok, true);
      assert.equal(
        existsSync(join(cwd, "attachments", healthyId, "healthy.txt")),
        true,
      );
      const promptText = calls.promptBlocks.at(-1)?.text ?? "";
      assert.match(
        promptText,
        /\[attached file: report\.pdf - no longer available\]/,
      );
      assert.match(
        promptText,
        new RegExp(`attachments/${healthyId}/healthy\\.txt`),
      );
      assert.match(promptText, /The user now says:\ncontinue$/);
    } finally {
      rmSync(cwd, { recursive: true, force: true });
    }
  });

  it("points local Pi and pi-acp at the conversation workspace transcript directory", async () => {
    const cwd = join(
      tmpdir(),
      "agenta-pi-session-dir-" + process.pid + "-" + Date.now(),
    );
    const { calls, deps } = fakeHarness({ cwd });

    const result = await runSandboxAgent(
      { harness: "pi_core", messages: [{ role: "user", content: "hello" }] },
      undefined,
      undefined,
      deps,
    );

    assert.equal(result.ok, true);
    const expected = join(cwd, "agents", "sessions", "pi");
    assert.equal(
      (calls.providerArgs[1] as Record<string, string>)
        .PI_CODING_AGENT_SESSION_DIR,
      expected,
    );
    assert.equal(
      (calls.providerArgs[3] as Record<string, string>)
        .PI_CODING_AGENT_SESSION_DIR,
      expected,
    );
    assert.equal(existsSync(expected), true);
    rmSync(cwd, { recursive: true, force: true });
  });

  it("creates the configured Pi transcript directory inside a Daytona cwd", async () => {
    const { calls, deps } = fakeHarness();
    deps.prepareDaytonaPiAssets = (async () => true) as any;

    const result = await runSandboxAgent(
      {
        harness: "pi_core",
        sandbox: "daytona",
        messages: [{ role: "user", content: "hello" }],
      },
      undefined,
      undefined,
      deps,
    );

    assert.equal(result.ok, true);
    const expected = "/home/sandbox/agenta-fake-cwd/agents/sessions/pi";
    assert.equal(
      (calls.providerArgs[1] as Record<string, string>)
        .PI_CODING_AGENT_SESSION_DIR,
      expected,
    );
    assert.equal(
      (calls.providerArgs[3] as Record<string, string>)
        .PI_CODING_AGENT_SESSION_DIR,
      expected,
    );
    assert.ok(calls.mkdirFsPaths.includes(expected));
  });

  it("requests the fully qualified <slug>/<model> for a managed OpenAI-compatible custom run", async () => {
    // Design Decision 7 hazard: the vault key rides in as OPENAI_API_KEY, so Pi keeps advertising
    // its built-in `openai/<model>` alongside the custom `my-conn/<model>`. Passing the bare wire
    // id "gpt-4o" would let suffix matching pick the built-in (api.openai.com) over the user's
    // endpoint. The runner must pass the exact `<connection-slug>/<model-id>` so it always wins.
    const { calls, deps } = fakeHarness();
    deps.prepareDaytonaPiAssets = (async () => true) as any;
    // The opaque vault key on a Daytona run requires the process-local Secret gate.
    process.env.AGENTA_RUNNER_DAYTONA_OPAQUE_SECRETS = "process_local";

    const result = await runSandboxAgent(
      {
        harness: "pi_core",
        sandbox: "daytona",
        messages: [{ role: "user", content: "hello" }],
        model: "gpt-4o",
        connection: { mode: "agenta", slug: "my-conn" },
        modelConnection: {
          provider: "openai",
          deployment: "custom",
          endpoint: { baseUrl: "https://proxy.test/v1" },
          credentialMode: "env",
          credentials: [
            {
              binding: { kind: "environment", name: "OPENAI_API_KEY" },
              value: "sk-vault-xyz",
              usage: "opaque_http",
            },
          ],
        },
      },
      undefined,
      undefined,
      deps,
    );

    assert.equal(result.ok, true);
    assert.equal(calls.applyModelArgs.length, 1);
    assert.equal(calls.applyModelArgs[0].model, "my-conn/gpt-4o");
  });

  it("passes the same Pi skill snapshot to local Pi and workspace preparation", async () => {
    const cwd = join(
      tmpdir(),
      `agenta-pi-skill-dir-${process.pid}-${Date.now()}`,
    );
    const skill = join(
      tmpdir(),
      `agenta-pi-skill-source-${process.pid}-${Date.now()}`,
    );
    mkdirSync(skill, { recursive: true });
    writeFileSync(join(skill, "SKILL.md"), "skill", "utf-8");
    const { calls, deps } = fakeHarness({ cwd });
    deps.resolveSkillDirs = () => ({
      skills: [{ name: "release-notes", dir: skill }],
      cleanup: () => {},
    });

    const result = await runSandboxAgent(
      { harness: "pi_core", messages: [{ role: "user", content: "hello" }] },
      undefined,
      undefined,
      deps,
    );

    assert.equal(result.ok, true);
    const selected = calls.workspacePiSkillSnapshot;
    assert.ok(selected);
    assert.match(
      selected.dir,
      new RegExp(`${cwd}/agents/skills/[a-f0-9]{64}$`),
    );
    assert.equal(
      (calls.providerArgs[1] as Record<string, string>)
        .PI_CODING_AGENT_SKILL_DIR,
      selected.dir,
    );
    assert.equal(
      (calls.providerArgs[3] as Record<string, string>)
        .PI_CODING_AGENT_SKILL_DIR,
      selected.dir,
    );
    rmSync(cwd, { recursive: true, force: true });
    rmSync(skill, { recursive: true, force: true });
  });

  it("keeps configured skills out of the Daytona Pi agent directory", async () => {
    const skill = join(
      tmpdir(),
      `agenta-pi-daytona-skill-${process.pid}-${Date.now()}`,
    );
    mkdirSync(skill, { recursive: true });
    writeFileSync(join(skill, "SKILL.md"), "skill", "utf-8");
    const { calls, deps } = fakeHarness();
    deps.resolveSkillDirs = () => ({
      skills: [{ name: "release-notes", dir: skill }],
      cleanup: () => {},
    });
    let agentDirSkillCount = -1;
    deps.prepareDaytonaPiAssets = (async ({ plan }: any) => {
      agentDirSkillCount = plan.workspace.skillDirs.length;
      return true;
    }) as any;

    const result = await runSandboxAgent(
      {
        harness: "pi_core",
        sandbox: "daytona",
        messages: [{ role: "user", content: "hello" }],
      },
      undefined,
      undefined,
      deps,
    );

    assert.equal(result.ok, true);
    assert.equal(agentDirSkillCount, 0);
    assert.match(
      calls.workspacePiSkillSnapshot.dir,
      /^\/home\/sandbox\/agenta-fake-cwd\/agents\/skills\/[a-f0-9]{64}$/,
    );
    rmSync(skill, { recursive: true, force: true });
  });

  it("advertises durable agent storage only after a confirmed local mount", async () => {
    const cwd = join(
      tmpdir(),
      `agenta-agent-mount-success-${process.pid}-${Date.now()}`,
    );
    mkdirSync(cwd, { recursive: true });
    const { calls, deps } = fakeHarness({ cwd });
    deps.signAgentMountCredentials = (async () => ({
      endpoint: "http://seaweedfs:8333",
      region: "us-east-1",
      bucket: "agenta-store",
      prefix: "mounts/proj-1/agent-1",
      accessKey: "AK-1",
      secretKey: "SK-1",
    })) as any;
    deps.mountStorage = (async () => true) as any;
    deps.unmountStorage = (async () => true) as any;

    const result = await runSandboxAgent(
      {
        harness: "claude",
        runContext: { workflow: { artifact: { id: "artifact-1" } } },
        telemetry: {
          exporters: { otlp: { headers: { authorization: "ApiKey run" } } },
        },
        messages: [{ role: "user", content: "hello" }],
      } as AgentRunRequest,
      undefined,
      undefined,
      deps,
    );

    assert.equal(result.ok, true);
    assert.equal(
      (calls.providerArgs[1] as Record<string, string>).AGENTA_AGENT_MOUNT_DIR,
      `${cwd}-agent`,
    );
    assert.match(
      calls.createSessionOptions.sessionInit._meta.systemPrompt.append,
      /agent-files\//,
    );
    rmSync(cwd, { recursive: true, force: true });
  });

  it("removes a safe failed agent mountpoint without advertising it to Pi", async () => {
    const cwd = join(
      tmpdir(),
      `agenta-agent-mount-failure-${process.pid}-${Date.now()}`,
    );
    mkdirSync(cwd, { recursive: true });
    const { calls, deps } = fakeHarness({ cwd });
    deps.signAgentMountCredentials = (async () => ({
      endpoint: "http://seaweedfs:8333",
      region: "us-east-1",
      bucket: "agenta-store",
      prefix: "mounts/proj-1/agent-1",
      accessKey: "AK-1",
      secretKey: "SK-1",
    })) as any;
    deps.mountStorage = (async () => false) as any;

    const result = await runSandboxAgent(
      {
        harness: "pi_core",
        runContext: { workflow: { artifact: { id: "artifact-1" } } },
        telemetry: {
          exporters: { otlp: { headers: { authorization: "ApiKey run" } } },
        },
        messages: [{ role: "user", content: "hello" }],
      } as AgentRunRequest,
      undefined,
      undefined,
      deps,
    );

    assert.equal(result.ok, true);
    assert.equal(
      (calls.providerArgs[1] as Record<string, string>).AGENTA_AGENT_MOUNT_DIR,
      undefined,
    );
    assert.equal(calls.workspacePlan.prompt.appendSystemPrompt, undefined);
    assert.equal(existsSync(`${cwd}-agent`), false);
    rmSync(cwd, { recursive: true, force: true });
  });

  // ============================================================================================
  // PLATFORM GUIDANCE IN THE INSTRUCTIONS FILE
  // ============================================================================================
  //
  // The fourth guidance channel, and the only one Codex has. These assert the WIRING: that the
  // text reaches the file the harness reads, with the mount state that was actually settled by
  // the time the workspace is written. `platform-guidance.test.ts` owns which contributors apply.

  it("renders the platform guidance into the instructions file, after the author's text", async () => {
    const { calls, deps } = fakeHarness();

    const result = await runSandboxAgent(
      {
        harness: "codex",
        customTools: [
          {
            name: "commit_revision",
            kind: "callback",
            callRef: "tools.agenta.commit_revision",
            permission: "ask",
            readOnly: false,
          },
        ] as never,
        agentsMd: "Be terse.",
        messages: [{ role: "user", content: "hello" }],
      } as AgentRunRequest,
      undefined,
      undefined,
      deps,
    );

    assert.equal(result.ok, true);
    const guidance = platformGuidanceAppendix({
      acpAgent: "codex",
      isPi: false,
      agentMountedPath: undefined,
      agentMountSkipped: false,
      toolNames: ["commit_revision"],
    });
    assert.ok(guidance);
    assert.equal(
      calls.workspacePlan.prompt.agentsMd,
      appendPlatformGuidance("Be terse.", guidance),
      "the file is the author's text, one blank line, then the fenced block",
    );
  });

  it("writes the guidance even when the author left the instructions empty", async () => {
    // The agent most likely to guess wrong about where a skill goes is the one with no
    // instructions at all. Before this, an empty configuration produced no file and no guidance.
    const { calls, deps } = fakeHarness();

    const result = await runSandboxAgent(
      {
        harness: "codex",
        customTools: [
          {
            name: "commit_revision",
            kind: "callback",
            callRef: "tools.agenta.commit_revision",
            permission: "ask",
            readOnly: false,
          },
        ] as never,
        messages: [{ role: "user", content: "hello" }],
      } as AgentRunRequest,
      undefined,
      undefined,
      deps,
    );

    assert.equal(result.ok, true);
    assert.match(
      calls.workspacePlan.prompt.agentsMd,
      /^<!-- agenta:platform-guidance:start -->\n/,
    );
    assert.ok(
      calls.workspacePlan.prompt.agentsMd.includes("parameters.agent.skills"),
    );
  });

  it("does not repeat the mount paragraph to Pi, which already has it", async () => {
    // The no-double-delivery property, asserted end to end rather than only on the selector: Pi
    // takes the mount paragraph through its append prompt, so the same text in the instructions
    // file would be the second copy. A live mount is set up here precisely so the paragraph is
    // available to be duplicated.
    const cwd = join(
      tmpdir(),
      `agenta-guidance-pi-${process.pid}-${Date.now()}`,
    );
    mkdirSync(cwd, { recursive: true });
    const { calls, deps } = fakeHarness({ cwd });
    deps.signAgentMountCredentials = (async () => ({
      endpoint: "http://seaweedfs:8333",
      region: "us-east-1",
      bucket: "agenta-store",
      prefix: "mounts/proj-1/agent-1",
      accessKey: "AK-1",
      secretKey: "SK-1",
    })) as any;
    deps.mountStorage = (async () => true) as any;
    deps.unmountStorage = (async () => true) as any;

    const result = await runSandboxAgent(
      {
        harness: "pi_core",
        customTools: [
          {
            name: "commit_revision",
            kind: "callback",
            callRef: "tools.agenta.commit_revision",
            permission: "ask",
            readOnly: false,
          },
        ] as never,
        agentsMd: "Be terse.",
        runContext: { workflow: { artifact: { id: "artifact-1" } } },
        telemetry: {
          exporters: { otlp: { headers: { authorization: "ApiKey run" } } },
        },
        messages: [{ role: "user", content: "hello" }],
      } as AgentRunRequest,
      undefined,
      undefined,
      deps,
    );

    assert.equal(result.ok, true);
    const file: string = calls.workspacePlan.prompt.agentsMd;
    // The append prompt DID get it, which is what makes the file's silence meaningful.
    assert.match(
      calls.workspacePlan.prompt.appendSystemPrompt,
      /agent-files\//,
    );
    assert.ok(
      file.includes("parameters.agent.skills"),
      "the skill sentence still lands",
    );
    assert.ok(
      !file.includes("agent-files/"),
      "the mount paragraph must not appear in the file as well",
    );
    rmSync(cwd, { recursive: true, force: true });
  });

  it("preserves the durable cwd when failed mount detach is unsafe", async () => {
    const prefix = "unsafe-mount-" + process.pid + "-" + Date.now();
    const cwd = join(tmpdir(), "agenta", prefix);
    const sentinel = join(cwd, "must-not-delete.txt");
    mkdirSync(cwd, { recursive: true });
    writeFileSync(sentinel, "durable data");
    const { calls, deps } = fakeHarness();
    deps.signSessionMountCredentials = (async () => ({
      endpoint: "http://seaweedfs:8333",
      region: "us-east-1",
      bucket: "agenta-store",
      prefix,
      accessKey: "AK-1",
      secretKey: "SK-1",
    })) as any;
    let mountpointProbes = 0;
    deps.mountStorage = ((cwd: string, creds: any, options: any) =>
      mountStorage(cwd, creds, {
        ...options,
        checkMounted: async () => false,
        runGeesefs: async () => {
          throw new Error("fuse: device not found");
        },
        unmountDeps: {
          runUnmount: async () => {},
          checkMountpoint: async () => {
            mountpointProbes += 1;
            return mountpointProbes === 1 ? "gone" : "mounted";
          },
        },
      })) as any;

    const result = await runSandboxAgent(
      {
        harness: "claude",
        sessionId: "sess-1",
        telemetry: {
          exporters: { otlp: { headers: { authorization: "ApiKey run" } } },
        },
        messages: [{ role: "user", content: "hello" }],
      } as AgentRunRequest,
      undefined,
      undefined,
      deps,
    );

    assert.equal(result.ok, false);
    if (result.ok) return;
    assert.match(
      result.error ?? "",
      /detach could not be confirmed.*refusing ephemeral cwd fallback/,
    );
    assert.equal(
      calls.workspacePlan,
      undefined,
      "unsafe detach fails before workspace preparation",
    );
    assert.equal(
      calls.workspaceCleanup,
      0,
      "prepareWorkspace cleanup never starts after unsafe mount acquisition",
    );
    assert.equal(
      existsSync(sentinel),
      true,
      "environment teardown must preserve the possibly-live durable cwd",
    );
    rmSync(cwd, { recursive: true, force: true });
  });

  it("re-signs, remounts, and retries local workspace prep on durable cwd ENOTCONN", async () => {
    const { calls, deps } = fakeHarness();
    const seenMountAccessKeys: string[] = [];
    let signCalls = 0;
    let mountCalls = 0;
    let workspaceCalls = 0;
    let mountCallsBeforeFirstWorkspace = 0;
    let cleanupCalls = 0;

    deps.signSessionMountCredentials = (async () => {
      signCalls += 1;
      return {
        endpoint: "http://seaweedfs:8333",
        region: "us-east-1",
        bucket: "agenta-store",
        prefix: "mounts/proj-1/mount-1",
        accessKey: `AK-${signCalls}`,
        secretKey: `SK-${signCalls}`,
        sessionToken: `TOK-${signCalls}`,
      };
    }) as any;
    deps.mountStorage = (async (_cwd: string, creds: any) => {
      mountCalls += 1;
      seenMountAccessKeys.push(creds.accessKey);
      return true;
    }) as any;
    deps.unmountStorage = (async () => true) as any;
    deps.prepareWorkspace = (async ({ plan }: any) => {
      workspaceCalls += 1;
      if (workspaceCalls === 1) {
        mountCallsBeforeFirstWorkspace = mountCalls;
        const err = new Error("ENOTCONN: Transport endpoint is not connected");
        (err as Error & { code?: string }).code = "ENOTCONN";
        throw err;
      }
      calls.workspacePlan = plan;
      return {
        cleanup: async () => {
          cleanupCalls += 1;
        },
      };
    }) as any;

    const result = await runSandboxAgent(
      {
        harness: "claude",
        sessionId: "sess-1",
        telemetry: {
          exporters: {
            otlp: {
              headers: { authorization: "ApiKey run" },
            },
          },
        },
        messages: [{ role: "user", content: "hello" }],
      } as AgentRunRequest,
      undefined,
      undefined,
      deps,
    );

    assert.equal(result.ok, true);
    assert.equal(signCalls, 2, "initial sign + re-sign after ENOTCONN");
    assert.equal(mountCalls, 2, "initial mount + remount after ENOTCONN");
    assert.deepEqual(seenMountAccessKeys, ["AK-1", "AK-2"]);
    assert.equal(
      mountCallsBeforeFirstWorkspace,
      1,
      "local durable cwd is mounted before first workspace write",
    );
    assert.equal(workspaceCalls, 2, "workspace prep is retried once");
    assert.equal(
      calls.createSessionOptions.cwd,
      "/tmp/agenta/mounts/proj-1/mount-1",
    );
    assert.equal(cleanupCalls, 1);
  });

  it("re-signs and remounts when an ACP event reports durable cwd ENOTCONN during prompt", async () => {
    const { deps } = fakeHarness({
      promptEvents: [
        {
          payload: {
            update: {
              kind: "tool_result",
              content:
                "realpath '/tmp/agenta/mounts/proj-1/mount-1/.restore_test': Transport endpoint is not connected",
            },
          },
        },
        {
          payload: {
            update: {
              kind: "tool_result",
              content:
                "realpath '/tmp/agenta/mounts/proj-1/mount-1/README.md': ENOTCONN",
            },
          },
        },
      ],
    });
    const seenMountAccessKeys: string[] = [];
    let signCalls = 0;
    let mountCalls = 0;
    let unmountCalls = 0;

    deps.signSessionMountCredentials = (async () => {
      signCalls += 1;
      return {
        endpoint: "http://seaweedfs:8333",
        region: "us-east-1",
        bucket: "agenta-store",
        prefix: "mounts/proj-1/mount-1",
        accessKey: `AK-${signCalls}`,
        secretKey: `SK-${signCalls}`,
        sessionToken: `TOK-${signCalls}`,
      };
    }) as any;
    deps.mountStorage = (async (_cwd: string, creds: any) => {
      mountCalls += 1;
      seenMountAccessKeys.push(creds.accessKey);
      return true;
    }) as any;
    deps.unmountStorage = (async () => {
      unmountCalls += 1;
    }) as any;

    const result = await runSandboxAgent(
      {
        harness: "claude",
        sessionId: "sess-1",
        telemetry: {
          exporters: {
            otlp: {
              headers: { authorization: "ApiKey run" },
            },
          },
        },
        messages: [{ role: "user", content: "hello" }],
      } as AgentRunRequest,
      undefined,
      undefined,
      deps,
    );

    assert.equal(result.ok, true);
    assert.equal(
      signCalls,
      2,
      "initial sign + one capped runtime re-sign after ENOTCONN",
    );
    assert.equal(
      mountCalls,
      2,
      "initial mount + one capped runtime remount after ENOTCONN",
    );
    assert.deepEqual(seenMountAccessKeys, ["AK-1", "AK-2"]);
    assert.equal(
      unmountCalls,
      1,
      "cleanup waits for runtime remount before unmount",
    );
  });

  it("re-materializes the codex subscription auth link on a mid-session durable cwd remount (#5692)", async () => {
    // The durable cwd is object storage: it has no symlinks, so every remount can hand the link
    // back as a 0-byte file. The link must therefore belong to the mount lifecycle, not only to
    // first acquire — otherwise the rest of the session authenticates from an empty token file.
    const cwd = "/tmp/agenta/mounts/proj-1/mount-1";
    const codexMount = mkdtempSync(join(tmpdir(), "codex-operator-home-"));
    const savedCodexHome = process.env.CODEX_HOME;
    writeFileSync(join(codexMount, "auth.json"), '{"tokens":{"id_token":"t"}}');
    process.env.CODEX_HOME = codexMount;
    const authLink = join(cwd, ".codex", "auth.json");

    try {
      const { deps } = fakeHarness({
        promptEvents: [
          {
            payload: {
              update: {
                kind: "tool_result",
                content: `realpath '${cwd}/README.md': Transport endpoint is not connected`,
              },
            },
          },
        ],
      });
      let signCalls = 0;
      let mountCalls = 0;
      deps.signSessionMountCredentials = (async () => {
        signCalls += 1;
        return {
          endpoint: "http://seaweedfs:8333",
          region: "us-east-1",
          bucket: "agenta-store",
          prefix: "mounts/proj-1/mount-1",
          accessKey: `AK-${signCalls}`,
          secretKey: `SK-${signCalls}`,
          sessionToken: `TOK-${signCalls}`,
        };
      }) as any;
      deps.mountStorage = (async () => {
        mountCalls += 1;
        if (mountCalls > 1) {
          // What geesefs actually serves after a remount: the symlink degraded to an empty object.
          rmSync(authLink, { force: true });
          mkdirSync(join(cwd, ".codex"), { recursive: true });
          writeFileSync(authLink, "");
        }
        return true;
      }) as any;
      deps.unmountStorage = (async () => true) as any;

      const result = await runSandboxAgent(
        {
          harness: "codex",
          modelConnection: {
            provider: "openai",
            deployment: "direct",
            credentialMode: "runtime_provided",
            credentials: [],
          },
          sessionId: "sess-1",
          telemetry: {
            exporters: { otlp: { headers: { authorization: "ApiKey run" } } },
          },
          messages: [{ role: "user", content: "hello" }],
        } as AgentRunRequest,
        undefined,
        undefined,
        deps,
      );

      assert.equal(result.ok, true);
      assert.equal(
        mountCalls,
        2,
        "initial mount + runtime remount after ENOTCONN",
      );
      assert.equal(
        lstatSync(authLink).isSymbolicLink(),
        true,
        "the remount must restore the symlink, not leave the degraded file",
      );
      assert.equal(readlinkSync(authLink), join(codexMount, "auth.json"));
    } finally {
      if (savedCodexHome === undefined) delete process.env.CODEX_HOME;
      else process.env.CODEX_HOME = savedCodexHome;
      rmSync(codexMount, { recursive: true, force: true });
      rmSync(cwd, { recursive: true, force: true });
    }
  });

  it("blames the empty mounted login, not a missing vault key, when a subscription codex run fails auth (#5692)", async () => {
    const cwd = mkdtempSync(join(tmpdir(), "codex-sub-cwd-"));
    const codexMount = mkdtempSync(join(tmpdir(), "codex-operator-home-"));
    const savedCodexHome = process.env.CODEX_HOME;
    // The login the operator mounted is present but empty — the state a geesefs round trip or a
    // half-written login leaves behind. The old message sent them looking for an OpenAI key.
    writeFileSync(join(codexMount, "auth.json"), "");
    process.env.CODEX_HOME = codexMount;

    try {
      const { deps } = fakeHarness({
        cwd,
        promptError: new Error("401 unauthorized"),
      });

      const result = await runSandboxAgent(
        {
          harness: "codex",
          modelConnection: {
            provider: "openai",
            deployment: "direct",
            credentialMode: "runtime_provided",
            credentials: [],
          },
          telemetry: {
            exporters: { otlp: { headers: { authorization: "ApiKey run" } } },
          },
          messages: [{ role: "user", content: "hello" }],
        } as AgentRunRequest,
        undefined,
        undefined,
        deps,
      );

      assert.equal(result.ok, false);
      assert.match(
        result.error ?? "",
        /mounted ChatGPT login is empty or unreadable/,
      );
      assert.equal(/vault/.test(result.error ?? ""), false);
    } finally {
      if (savedCodexHome === undefined) delete process.env.CODEX_HOME;
      else process.env.CODEX_HOME = savedCodexHome;
      rmSync(codexMount, { recursive: true, force: true });
      rmSync(cwd, { recursive: true, force: true });
    }
  });

  it("re-signs and remounts the agent mount when an ACP event reports ENOTCONN", async () => {
    // Sessionless: exercises the agent-mount-only recovery gate.
    const cwd = join(
      tmpdir(),
      `agenta-agent-mount-enotconn-${process.pid}-${Date.now()}`,
    );
    mkdirSync(cwd, { recursive: true });
    const { deps } = fakeHarness({
      cwd,
      promptEvents: [
        {
          payload: {
            update: {
              kind: "tool_result",
              content:
                "cat 'agent-files/notes.md': Transport endpoint is not connected",
            },
          },
        },
      ],
    });
    const seenMountAccessKeys: string[] = [];
    let signAgentCalls = 0;
    let mountCalls = 0;

    deps.signAgentMountCredentials = (async () => {
      signAgentCalls += 1;
      return {
        endpoint: "http://seaweedfs:8333",
        region: "us-east-1",
        bucket: "agenta-store",
        prefix: "mounts/proj-1/agent-1",
        accessKey: `AK-${signAgentCalls}`,
        secretKey: `SK-${signAgentCalls}`,
        sessionToken: `TOK-${signAgentCalls}`,
      };
    }) as any;
    deps.mountStorage = (async (_path: string, creds: any) => {
      mountCalls += 1;
      seenMountAccessKeys.push(creds.accessKey);
      return true;
    }) as any;
    deps.unmountStorage = (async () => true) as any;

    const result = await runSandboxAgent(
      {
        harness: "claude",
        runContext: { workflow: { artifact: { id: "artifact-1" } } },
        telemetry: {
          exporters: { otlp: { headers: { authorization: "ApiKey run" } } },
        },
        messages: [{ role: "user", content: "hello" }],
      } as AgentRunRequest,
      undefined,
      undefined,
      deps,
    );

    assert.equal(result.ok, true);
    assert.equal(
      signAgentCalls,
      2,
      "initial sign + one capped runtime re-sign after ENOTCONN",
    );
    assert.equal(
      mountCalls,
      2,
      "initial agent mount + one capped runtime remount after ENOTCONN",
    );
    assert.deepEqual(seenMountAccessKeys, ["AK-1", "AK-2"]);
    rmSync(cwd, { recursive: true, force: true });
    rmSync(`${cwd}-agent`, { recursive: true, force: true });
  });

  it("skips the durable cwd delete when unmount is not confirmed", async () => {
    // A failed/still-mounted unmount must never be followed by rmSync on the cwd — that would
    // delete through a possibly-live FUSE mount into the durable store.
    const { calls, deps } = fakeHarness();
    deps.signSessionMountCredentials = (async () => ({
      endpoint: "http://seaweedfs:8333",
      region: "us-east-1",
      bucket: "agenta-store",
      prefix: "mounts/proj-1/mount-1",
      accessKey: "AK-1",
      secretKey: "SK-1",
    })) as any;
    deps.mountStorage = (async () => true) as any;
    // Simulate an unconfirmed unmount (still mounted after the detach attempt).
    deps.unmountStorage = (async () => false) as any;

    const result = await runSandboxAgent(
      {
        harness: "claude",
        sessionId: "sess-1",
        telemetry: {
          exporters: { otlp: { headers: { authorization: "ApiKey run" } } },
        },
        messages: [{ role: "user", content: "hello" }],
      } as AgentRunRequest,
      undefined,
      undefined,
      deps,
    );

    assert.equal(result.ok, true);
    assert.equal(
      calls.workspaceCleanup,
      0,
      "cwd delete is skipped when unmount is not confirmed",
    );
  });

  it("still deletes the cwd once unmount is confirmed gone", async () => {
    const { calls, deps } = fakeHarness();
    deps.signSessionMountCredentials = (async () => ({
      endpoint: "http://seaweedfs:8333",
      region: "us-east-1",
      bucket: "agenta-store",
      prefix: "mounts/proj-1/mount-1",
      accessKey: "AK-1",
      secretKey: "SK-1",
    })) as any;
    deps.mountStorage = (async () => true) as any;
    deps.unmountStorage = (async () => true) as any;

    const result = await runSandboxAgent(
      {
        harness: "claude",
        sessionId: "sess-1",
        telemetry: {
          exporters: { otlp: { headers: { authorization: "ApiKey run" } } },
        },
        messages: [{ role: "user", content: "hello" }],
      } as AgentRunRequest,
      undefined,
      undefined,
      deps,
    );

    assert.equal(result.ok, true);
    assert.equal(
      calls.workspaceCleanup,
      1,
      "cwd delete proceeds once unmount is confirmed",
    );
  });

  it("Daytona mounts the durable cwd before workspace materialization", async () => {
    const { calls, deps } = fakeHarness();
    let mountCallsBeforeWorkspace = 0;
    deps.signSessionMountCredentials = (async () => ({
      endpoint: "http://seaweedfs:8333",
      region: "us-east-1",
      bucket: "agenta-store",
      prefix: "mounts/proj-1/mount-1",
      accessKey: "AK-1",
      secretKey: "SK-1",
    })) as any;
    deps.discoverTunnelEndpoint = (async () => "https://tunnel.example") as any;
    let mountCalls = 0;
    deps.mountStorageRemote = (async () => {
      mountCalls += 1;
      return true;
    }) as any;
    deps.prepareWorkspace = (async ({ plan }: any) => {
      mountCallsBeforeWorkspace = mountCalls;
      calls.workspacePlan = plan;
      return { cleanup: async () => {} };
    }) as any;

    const result = await runSandboxAgent(
      {
        harness: "claude",
        sandbox: "daytona",
        sessionId: "sess-1",
        telemetry: {
          exporters: { otlp: { headers: { authorization: "ApiKey run" } } },
        },
        messages: [{ role: "user", content: "hello" }],
      } as AgentRunRequest,
      undefined,
      undefined,
      deps,
    );

    assert.equal(result.ok, true);
    assert.equal(mountCalls, 1, "remote mount is attempted");
    assert.equal(
      mountCallsBeforeWorkspace,
      1,
      "the durable cwd is mounted before workspace materialization writes into it",
    );
  });

  it("keeps terminal events empty on the streaming path", async () => {
    const { deps } = fakeHarness();
    const streamed: AgentEvent[] = [];

    const result = await runSandboxAgent(
      { harness: "claude", messages: [{ role: "user", content: "hello" }] },
      (event) => streamed.push(event),
      undefined,
      deps,
    );

    assert.equal(result.ok, true);
    if (!result.ok) return;
    assert.deepEqual(result.events, []);
    assert.equal(result.capabilities?.streamingDeltas, true);
    assert.deepEqual(streamed, [
      {
        type: "data",
        name: "agent-status",
        data: { phase: "environment_starting" },
        transient: true,
      },
      {
        type: "data",
        name: "agent-status",
        data: { phase: "environment_ready" },
        transient: true,
      },
    ]);
  });

  it("surfaces permission requests and answers them through the responder", async () => {
    const { calls, deps } = fakeHarness({ emitPermission: true });

    const result = await runSandboxAgent(
      {
        harness: "claude",
        messages: [{ role: "user", content: "edit the file" }],
      },
      undefined,
      undefined,
      deps,
    );
    await flushPromises();

    assert.equal(result.ok, true);
    if (!result.ok) return;
    assert.deepEqual(
      result.events?.filter((event) => event.type === "interaction_request"),
      [],
    );
    // allow -> once (per-call grant), never always: a turn-wide grant would skip re-gating.
    assert.deepEqual(calls.permissionReplies, [
      { id: "perm-1", reply: "once" },
    ]);
  });

  it("starts and stops the tool relay only when executable tools are present", async () => {
    const { calls, deps } = fakeHarness();

    // Pi delivers tools through its native extension (not the MCP bridge), so the relay path
    // is exercised on a Pi run. The MCP bridge is disabled in the sidecar (see the dedicated
    // test below), so a non-Pi harness can no longer take custom tools at all.
    const result = await runSandboxAgent(
      {
        harness: "pi_core",
        messages: [{ role: "user", content: "use the tool" }],
        customTools: [{ name: "server_tool", kind: "callback" }],
      } as AgentRunRequest,
      undefined,
      undefined,
      deps,
    );

    assert.equal(result.ok, true);
    assert.deepEqual(calls.toolRelayArgs?.slice(0, 4), [
      "local-relay-host",
      // Relay scratch lives off the geesefs mount: host tmpdir/agenta/relay/<cwd basename>.
      join(tmpdir(), "agenta", "relay", "agenta-fake-cwd"),
      [{ name: "server_tool", kind: "callback" }],
      undefined,
    ]);
    // The relay carries execution only (no permissions argument). The request sent no
    // runContext, but the runner augments its dispatch copy with the live session id so
    // $ctx.session.id bindings resolve (RunContext.session is runner-filled).
    assert.deepEqual(calls.toolRelayArgs?.[4], {
      session: { id: "session-1" },
    });
    // Trailing arg is the relay callbacks object (client-tool + park handlers).
    assert.deepEqual(
      Object.keys((calls.toolRelayArgs?.[5] ?? {}) as object).sort(),
      ["onClientTool", "onPause"],
    );
    // A Pi run passes the execution guard: the relay dir is sandbox-writable, so every execute
    // record is re-checked runner-side (a forged record must not run an ask/deny tool).
    assert.equal(typeof calls.toolRelayArgs?.[6], "function");
    // The 8th argument carries the log sink: without it the relay skips pickup
    // telemetry (and its per-request stat) entirely, so the engine must pass one.
    assert.equal(
      typeof (calls.toolRelayArgs?.[7] as { log?: unknown } | undefined)?.log,
      "function",
    );
    assert.equal(
      calls.toolRelayStops,
      2,
      "stopped after prompt and again in finally",
    );
  });

  it("wires Pi ask grants into the captured relay guard while non-Pi ask passes", async () => {
    const request = {
      messages: [{ role: "user", content: "use the tool" }],
      permissions: { default: "ask" },
      customTools: [
        { name: "server_tool", kind: "callback", permission: "ask" },
      ],
    } as AgentRunRequest;
    const relayRequest = {
      toolName: "server_tool",
      toolCallId: "forged-call",
      args: {},
    };

    const pi = fakeHarness();
    const piResult = await runSandboxAgent(
      { ...request, harness: "pi_core" },
      undefined,
      undefined,
      pi.deps,
    );
    assert.equal(piResult.ok, true);
    const piGuard = pi.calls.toolRelayArgs?.[6] as Function;
    assert.deepEqual(
      piGuard(request.customTools?.[0], relayRequest),
      {
        allow: false,
        reason: declinedByUserText("server_tool"),
      },
      "Pi ask without a grant fails closed",
    );

    const claude = fakeHarness();
    const claudeResult = await runSandboxAgent(
      { ...request, harness: "claude" },
      undefined,
      undefined,
      claude.deps,
    );
    assert.equal(claudeResult.ok, true);
    const claudeGuard = claude.calls.toolRelayArgs?.[6] as Function;
    assert.deepEqual(
      claudeGuard(request.customTools?.[0], relayRequest),
      { allow: true },
      "non-Pi ask remains gated by the harness and passes the relay guard",
    );
  });

  it("delivers a non-Pi run's gateway tools over the internal HTTP MCP channel", async () => {
    // Claude takes tools only over MCP. The INTERNAL gateway-tool channel (distinct from the
    // disabled USER stdio MCP path) is restored over a loopback HTTP MCP server the runner
    // serves, so a Claude run with a gateway tool now SUCCEEDS and the tool is advertised to the
    // harness. This is the #4831 regression fix (project gateway-tool-mcp): the run no longer
    // hard-fails with the user-facing MCP-unsupported error.
    const { calls, deps } = fakeHarness();

    const result = await runSandboxAgent(
      {
        harness: "claude",
        messages: [{ role: "user", content: "use the tool" }],
        customTools: [{ name: "server_tool", kind: "callback" }],
      } as AgentRunRequest,
      undefined,
      undefined,
      deps,
    );

    assert.equal(
      result.ok,
      true,
      "the run succeeds; gateway tools reach Claude",
    );
    // The relay dir is sandbox-writable on every harness, so a Claude run gets the execution
    // guard too — its non-Pi shape enforces the hard deny boundary against forged records
    // while `ask` stays with Claude's own harness dialog (see buildRelayExecutionGuard; the
    // non-Pi semantics are pinned in tool-relay-guard.test.ts).
    assert.equal(typeof calls.toolRelayArgs?.[6], "function");
    const mcpServers =
      calls.createSessionOptions?.sessionInit?.mcpServers ?? [];
    assert.equal(
      mcpServers.length,
      1,
      "one internal MCP server delivered to the session",
    );
    assert.equal(mcpServers[0].name, "agenta-tools");
    assert.equal(
      mcpServers[0].type,
      "http",
      "delivered over http, not a stdio child process",
    );
    assert.match(
      mcpServers[0].url,
      /^http:\/\/127\.0\.0\.1:\d+\/mcp$/,
      "loopback url",
    );
    // WP1 (#5201): the loopback HTTP endpoint carries a per-session bearer guard so another local
    // process cannot reach it. It is a locally minted access token, not a provider credential.
    assert.equal(mcpServers[0].headers.length, 1, "the loopback guard header");
    assert.equal(mcpServers[0].headers[0].name, "Authorization");
    assert.match(
      mcpServers[0].headers[0].value,
      /^Bearer .+/,
      "per-session loopback guard token",
    );
    // The internal server is opened then released, so its port does not leak past the run.
    assert.equal(calls.sandboxDestroyed, 1, "sandbox disposed in finally");
  });

  it("fails loud when a non-Pi harness probes mcpTools:false but the run carries tools", async () => {
    // A7: the capability gate runs BEFORE the MCP bridge, so a harness whose probe reports it
    // cannot receive tools fails with a SPECIFIC capability error (not the generic MCP-disabled
    // line, and never a silent drop). This is the silent-degradation case the staff review
    // flagged: a wrong/missing `mcpTools` flag must error, not change behavior quietly.
    const { calls, deps } = fakeHarness({ capabilities: { mcpTools: false } });

    const result = await runSandboxAgent(
      {
        harness: "claude",
        messages: [{ role: "user", content: "use the tool" }],
        customTools: [{ name: "server_tool", kind: "callback" }],
      } as AgentRunRequest,
      undefined,
      undefined,
      deps,
    );

    assert.equal(result.ok, false);
    if (result.ok) return;
    assert.match(result.error ?? "", /harness 'claude' cannot receive tools/);
    assert.match(result.error ?? "", /mcpTools:false/);
    // The gate fires before the session is created, so no session/prompt happened.
    assert.equal(calls.createSessionOptions, undefined);
    // The acquired sandbox is still disposed in the finally.
    assert.equal(calls.sandboxDestroyed, 1);
  });

  it("does not gate tool delivery for a Pi run even when mcpTools is false", async () => {
    // Pi delivers tools through its native extension, not MCP, so a Pi run with tools and a
    // `mcpTools:false` probe must proceed (the gate exempts Pi).
    const { calls, deps } = fakeHarness({ capabilities: { mcpTools: false } });

    const result = await runSandboxAgent(
      {
        harness: "pi_core",
        messages: [{ role: "user", content: "use the tool" }],
        customTools: [{ name: "server_tool", kind: "callback" }],
      } as AgentRunRequest,
      undefined,
      undefined,
      deps,
    );

    assert.equal(result.ok, true);
    assert.notEqual(calls.createSessionOptions, undefined);
  });

  it("flushes a partial trace and cleans up on prompt errors", async () => {
    const { calls, deps } = fakeHarness({ promptError: new Error("boom") });

    const result = await runSandboxAgent(
      { harness: "claude", messages: [{ role: "user", content: "explode" }] },
      undefined,
      undefined,
      deps,
    );

    assert.deepEqual(result, { ok: false, error: "boom" });
    assert.equal(calls.runFinished, 1);
    assert.equal(calls.runFlushed, 1);
    assert.equal(calls.sandboxDestroyed, 1);
    assert.equal(calls.sandboxDisposed, 1);
    assert.equal(calls.workspaceCleanup, 1);
  });

  // A throw from otel.finish() in the error path must not mask the real run error.
  it("still returns the run error when otel.finish() throws in the error path", async () => {
    const { calls, deps } = fakeHarness({ promptError: new Error("boom") });
    deps.createOtel = ((otelOptions: any) => {
      calls.otelOptions = otelOptions;
      return {
        start() {},
        handleUpdate() {},
        emitEvent(event: AgentEvent) {
          void event;
        },
        usage() {
          return { input: 0, output: 0, total: 0, cost: 0 };
        },
        setUsage() {},
        finish() {
          calls.runFinished += 1;
          throw new Error("tracing finish blew up");
        },
        recordError(message: string, provider?: string) {
          calls.recordedErrors.push({ message, provider });
        },
        output() {
          return "";
        },
        async flush() {
          calls.runFlushed += 1;
        },
        events() {
          return [];
        },
        settleOpenToolCalls() {},
        openToolCallIds() {
          return [];
        },
        traceId() {
          return "trace-1";
        },
      };
    }) as any;

    const result = await runSandboxAgent(
      { harness: "claude", messages: [{ role: "user", content: "explode" }] },
      undefined,
      undefined,
      deps,
    );

    assert.deepEqual(result, { ok: false, error: "boom" });
    assert.equal(calls.runFinished, 1);
    assert.equal(calls.runFlushed, 1);
    assert.equal(calls.sandboxDestroyed, 1);
    assert.equal(calls.sandboxDisposed, 1);
  });

  it("passes the sandbox permission through to buildSandboxProvider", async () => {
    const { calls, deps } = fakeHarness();
    const sandboxPermission = {
      network: { mode: "allowlist" as const, allowlist: ["10.0.0.0/8"] },
      enforcement: "best_effort" as const,
    };

    const result = await runSandboxAgent(
      {
        harness: "claude",
        sandbox: "daytona",
        messages: [{ role: "user", content: "hello" }],
        sandboxPermission,
      },
      undefined,
      undefined,
      deps,
    );

    assert.equal(result.ok, true);
    // sandboxId, env, binaryPath, piExtEnv, secrets, sandboxPermission
    assert.deepEqual(calls.providerArgs[5], sandboxPermission);
  });

  it("passes cancellation signals into SandboxAgent.start", async () => {
    const { calls, deps } = fakeHarness();
    const controller = new AbortController();

    const result = await runSandboxAgent(
      { harness: "claude", messages: [{ role: "user", content: "hello" }] },
      undefined,
      controller.signal,
      deps,
    );

    assert.equal(result.ok, true);
    // The signal handed to the harness is merged with the run-limits deadline signal
    // (AbortSignal.any), so it is no longer the identical object — but aborting the caller's
    // controller must still abort the merged signal the harness observes.
    assert.equal(calls.startOptions.signal.aborted, false);
    controller.abort();
    assert.equal(calls.startOptions.signal.aborted, true);
  });

  it("cancels Pi before draining so agent_end's native batch is exported", async () => {
    const cwd = mkdtempSync(join(tmpdir(), "pi-cancel-trace-"));
    let callsRef: ReturnType<typeof fakeHarness>["calls"] | undefined;
    const exported: number[][] = [];
    const fixture = fakeHarness({
      cwd,
      hangPrompt: true,
      abortSignalCancelsHungPrompt: true,
      afterDestroySession: async () => {
        const telemetryDir = callsRef?.workspacePlan?.workspace.telemetryDir;
        assert.equal(typeof telemetryDir, "string");
        const control = JSON.parse(
          readFileSync(join(telemetryDir, PI_TRACE_CONTROL_FILE), "utf8"),
        ) as {
          channelId: string;
          redaction: { knownValues: string[] };
        };
        assert.equal(
          control.redaction.knownValues.includes("model-env-visible-to-pi"),
          true,
        );
        assert.equal(
          control.redaction.knownValues.includes("Secret current"),
          false,
        );
        writeFileSync(
          join(telemetryDir, piTraceFileName(control.channelId, 0)),
          Buffer.from([10, 0, 255]),
        );
      },
    });
    callsRef = fixture.calls;
    vi.stubGlobal(
      "fetch",
      vi.fn(async (_url: string, init?: RequestInit) => {
        // Exports carry a binary body; other runner traffic (the pre-turn interactions read)
        // sends JSON strings and is not what this test collects.
        if (init?.body && typeof init.body !== "string") {
          exported.push([...(init.body as Buffer)]);
        }
        return new Response(null, { status: 200 });
      }),
    );
    const controller = new AbortController();

    try {
      const running = runSandboxAgent(
        {
          harness: "pi_core",
          messages: [{ role: "user", content: "keep working" }],
          modelConnection: {
            provider: "openai",
            deployment: "custom",
            credentialMode: "none",
            environment: { GATEWAY_AUTH: "model-env-visible-to-pi" },
            credentials: [],
          },
          telemetry: {
            exporters: {
              otlp: { headers: { authorization: "Secret current" } },
            },
          },
        },
        undefined,
        controller.signal,
        fixture.deps,
      );
      await flushPromises();
      controller.abort();
      const result = await running;

      assert.equal(result.ok, true);
      if (!result.ok) return;
      assert.equal(result.stopReason, "cancelled");
      assert.deepEqual(exported, [[10, 0, 255]], fixture.logs.join("\n"));
      assert.equal(fixture.calls.sessionDestroyed, 1);
      assert.deepEqual(fixture.calls.recordedErrors, []);
    } finally {
      rmSync(cwd, { recursive: true, force: true });
    }
  });

  it("keeps a successful Pi turn successful when no native trace batch arrives", async () => {
    const cwd = mkdtempSync(join(tmpdir(), "pi-missing-trace-"));
    const fixture = fakeHarness({ cwd });

    try {
      const result = await runSandboxAgent(
        {
          harness: "pi_core",
          messages: [{ role: "user", content: "hello" }],
        },
        undefined,
        undefined,
        fixture.deps,
      );

      assert.equal(result.ok, true);
      assert.deepEqual(fixture.calls.recordedErrors, [
        {
          message:
            "Pi did not publish a valid trace batch before the turn ended",
          provider: undefined,
        },
      ]);
      assert.equal(fixture.calls.runFlushed, 2);
      assert.match(
        fixture.logs.join("\n"),
        /stage=pi_trace_missing_batch diagnostic=true/,
      );
    } finally {
      rmSync(cwd, { recursive: true, force: true });
    }
  });

  it("preserves a failed Pi turn's agent error when no native trace batch arrives", async () => {
    const cwd = mkdtempSync(join(tmpdir(), "pi-failed-trace-"));
    const fixture = fakeHarness({
      cwd,
      promptError: new Error(
        '429: {"message":"Budget has been exceeded! Key=organization-id (sk-...suffix) Current cost: 5.1, Max budget: 5.0","type":"budget_exceeded","code":"429"}',
      ),
    });
    const message =
      "Your free Agenta credits are used up. Add your own provider key to keep going.";

    try {
      const result = await runSandboxAgent(
        {
          harness: "pi_core",
          messages: [{ role: "user", content: "fail" }],
        },
        undefined,
        undefined,
        fixture.deps,
      );

      assert.deepEqual(result, { ok: false, error: message });
      assert.deepEqual(fixture.calls.recordedErrors, [
        { message, provider: undefined },
      ]);
      assert.deepEqual(
        fixture.events.find((event) => event.type === "error"),
        { type: "error", message, code: "starter_credits_exhausted" },
      );
      assert.match(
        fixture.logs.join("\n"),
        /stage=pi_trace_missing_batch diagnostic=true/,
      );
    } finally {
      rmSync(cwd, { recursive: true, force: true });
    }
  });

  it("clears inherited provider env on a managed run and applies ANTHROPIC_BASE_URL for claude", async () => {
    const { calls, deps } = fakeHarness();

    const result = await runSandboxAgent(
      {
        harness: "claude",
        messages: [{ role: "user", content: "hello" }],
        modelConnection: {
          provider: "anthropic",
          deployment: "custom",
          endpoint: { baseUrl: "https://claude-gw.example/v1" },
          credentialMode: "env",
          credentials: [
            {
              binding: { kind: "environment", name: "ANTHROPIC_API_KEY" },
              value: "resolved",
              usage: "opaque_http",
            },
          ],
        },
      } as AgentRunRequest,
      undefined,
      undefined,
      deps,
    );

    assert.equal(result.ok, true);
    // Managed run -> clear-then-apply: buildDaemonEnv is asked to clear the inherited provider env.
    assert.equal(calls.daemonOptions?.clearProviderEnv, true);
    // The env handed to buildSandboxProvider carries only the resolved key + the custom base url.
    const env = calls.providerArgs[1] as Record<string, string>;
    assert.equal(env.ANTHROPIC_API_KEY, "resolved");
    assert.equal(env.ANTHROPIC_BASE_URL, "https://claude-gw.example/v1");
    assert.equal(env.ANTHROPIC_MODEL, undefined);
    // Tool-Search is disabled for every claude run so the agenta-tools MCP tools keep their
    // inputSchema (deferral would strip it -> empty tool input). The SDK only treats the exact
    // string "false"/"0"/"no"/"off" as off, so it must be the string "false".
    assert.equal(env.ENABLE_TOOL_SEARCH, "false");
  });

  it("does not set ENABLE_TOOL_SEARCH for a non-claude (pi) run", async () => {
    const { calls, deps } = fakeHarness();

    const result = await runSandboxAgent(
      {
        harness: "pi_core",
        messages: [{ role: "user", content: "hello" }],
      } as AgentRunRequest,
      undefined,
      undefined,
      deps,
    );

    assert.equal(result.ok, true);
    const env = calls.providerArgs[1] as Record<string, string>;
    // The Tool-Search toggle is Claude-specific: a Pi run must not carry it.
    assert.equal(env.ENABLE_TOOL_SEARCH, undefined);
  });

  it("never puts the OTLP bearer in the local Pi daemon's env", async () => {
    const { calls, deps } = fakeHarness();

    const result = await runSandboxAgent(
      {
        harness: "pi_core",
        messages: [{ role: "user", content: "hello" }],
        telemetry: {
          exporters: {
            otlp: {
              endpoint: "https://otlp.example.test/v1/traces",
              headers: { authorization: "Bearer reusable-caller-token" },
            },
          },
        },
      } as AgentRunRequest,
      undefined,
      undefined,
      deps,
    );

    assert.equal(result.ok, true);
    const env = calls.providerArgs[1] as Record<string, string>;
    // The harness sees only a stable telemetry-control path; endpoint and bearer stay here.
    assert.equal(env.OTEL_EXPORTER_OTLP_HEADERS, undefined);
    assert.equal(env.OTEL_EXPORTER_OTLP_TRACES_ENDPOINT, undefined);
    assert.equal(typeof env.AGENTA_AGENT_TELEMETRY_CONTROL_PATH, "string");
    assert.equal(JSON.stringify(env).includes("reusable-caller-token"), false);
  });

  it("sets Claude Bedrock env and strict selected model pass-through", async () => {
    const { calls, deps } = fakeHarness();

    const result = await runSandboxAgent(
      {
        harness: "claude",
        messages: [{ role: "user", content: "hello" }],
        model: "anthropic.claude-x",
        modelConnection: {
          provider: "anthropic",
          deployment: "bedrock",
          endpoint: {
            baseUrl: "https://bedrock-runtime.us-east-1.amazonaws.com",
          },
          credentialMode: "env",
          environment: { AWS_REGION: "us-east-1" },
          credentials: [
            {
              binding: { kind: "environment", name: "AWS_ACCESS_KEY_ID" },
              value: "AKIA",
              usage: "local_use",
            },
          ],
        },
      } as AgentRunRequest,
      undefined,
      undefined,
      deps,
    );

    assert.equal(result.ok, true);
    const env = calls.providerArgs[1] as Record<string, string>;
    assert.equal(env.CLAUDE_CODE_USE_BEDROCK, "1");
    assert.equal(env.AWS_ACCESS_KEY_ID, "AKIA");
    assert.equal(env.AWS_REGION, "us-east-1");
    assert.equal(env.ANTHROPIC_MODEL, "anthropic.claude-x");
    assert.equal(env.ANTHROPIC_CUSTOM_MODEL_OPTION, "anthropic.claude-x");
    assert.deepEqual(calls.applyModelArgs.at(-1), {
      model: "anthropic.claude-x",
      options: { strict: true },
    });
  });

  it("sets Claude Vertex env and selected model pass-through", async () => {
    const { calls, deps } = fakeHarness();

    const result = await runSandboxAgent(
      {
        harness: "claude",
        messages: [{ role: "user", content: "hello" }],
        model: "claude-sonnet-4",
        modelConnection: {
          provider: "anthropic",
          deployment: "vertex_ai",
          endpoint: {
            baseUrl: "https://us-central1-aiplatform.googleapis.com",
            region: "us-central1",
          },
          credentialMode: "env",
          environment: {
            GOOGLE_CLOUD_PROJECT: "proj",
            GOOGLE_CLOUD_LOCATION: "us-central1",
          },
          credentials: [
            {
              binding: {
                kind: "environment",
                name: "GOOGLE_APPLICATION_CREDENTIALS",
              },
              value: "/tmp/adc.json",
              usage: "local_use",
            },
          ],
        },
      } as AgentRunRequest,
      undefined,
      undefined,
      deps,
    );

    assert.equal(result.ok, true);
    const env = calls.providerArgs[1] as Record<string, string>;
    assert.equal(env.CLAUDE_CODE_USE_VERTEX, "1");
    assert.equal(env.GOOGLE_CLOUD_PROJECT, "proj");
    assert.equal(env.ANTHROPIC_MODEL, "claude-sonnet-4");
  });

  it("does not clear provider env or set a base url on a runtime_provided run", async () => {
    const { calls, deps } = fakeHarness();

    // A local runtime_provided run authenticates from a mounted subscription, so buildRunPlan
    // requires the harness config var (here CLAUDE_CONFIG_DIR) to name a mount.
    const previousClaudeConfigDir = process.env.CLAUDE_CONFIG_DIR;
    process.env.CLAUDE_CONFIG_DIR = "/agenta/harness/claude";
    let result;
    try {
      result = await runSandboxAgent(
        {
          harness: "claude",
          messages: [{ role: "user", content: "hello" }],
          modelConnection: {
            provider: "anthropic",
            deployment: "direct",
            credentialMode: "runtime_provided",
            credentials: [],
          },
        } as AgentRunRequest,
        undefined,
        undefined,
        deps,
      );
    } finally {
      if (previousClaudeConfigDir === undefined)
        delete process.env.CLAUDE_CONFIG_DIR;
      else process.env.CLAUDE_CONFIG_DIR = previousClaudeConfigDir;
    }

    assert.equal(result.ok, true);
    // runtime_provided -> keep the harness's own inherited env (do not clear).
    assert.equal(calls.daemonOptions?.clearProviderEnv, false);
    const env = calls.providerArgs[1] as Record<string, string>;
    assert.equal(env.ANTHROPIC_BASE_URL, undefined);
  });

  it("passes the run's declared provider/deployment so the inherited keys narrow (RUN-SEC-1)", async () => {
    const { calls, deps } = fakeHarness();

    // A local runtime_provided run authenticates from a mounted subscription, so buildRunPlan
    // requires the harness config var (here CLAUDE_CONFIG_DIR) to name a mount.
    const previousClaudeConfigDir = process.env.CLAUDE_CONFIG_DIR;
    process.env.CLAUDE_CONFIG_DIR = "/agenta/harness/claude";
    let result;
    try {
      result = await runSandboxAgent(
        {
          harness: "claude",
          messages: [{ role: "user", content: "hello" }],
          modelConnection: {
            provider: "anthropic",
            deployment: "bedrock",
            credentialMode: "runtime_provided",
            credentials: [],
          },
        } as AgentRunRequest,
        undefined,
        undefined,
        deps,
      );
    } finally {
      if (previousClaudeConfigDir === undefined)
        delete process.env.CLAUDE_CONFIG_DIR;
      else process.env.CLAUDE_CONFIG_DIR = previousClaudeConfigDir;
    }

    assert.equal(result.ok, true);
    assert.equal(calls.daemonOptions?.provider, "anthropic");
    assert.equal(calls.daemonOptions?.deployment, "bedrock");
  });

  it("clears inherited provider env when the resolved credential mode is none", async () => {
    const { calls, deps } = fakeHarness();
    const result = await runSandboxAgent(
      {
        harness: "claude",
        messages: [{ role: "user", content: "hello" }],
        modelConnection: {
          provider: "anthropic",
          deployment: "direct",
          credentialMode: "none",
          credentials: [],
        },
      },
      undefined,
      undefined,
      deps,
    );
    assert.equal(result.ok, true);
    // "none" means the run declared it uses NO ambient credential: the daemon must not inherit
    // the sidecar's own provider keys either (only runtime_provided keeps them).
    assert.equal(calls.daemonOptions?.clearProviderEnv, true);
  });
});

// These exercise the engine's default ApprovalResponder by dropping the `responderFactory`
// override the fake otherwise installs, so we test the real allow, pause, and resume wiring.
describe("runSandboxAgent default ApprovalResponder wiring", () => {
  function depsWithDefaultResponder() {
    const { calls, deps } = fakeHarness({ emitPermission: true });
    delete deps.responderFactory; // fall through to the engine's ApprovalResponder
    return { calls, deps };
  }

  it("absent permissions use allow_reads and pause an unrated gate", async () => {
    const { calls, deps } = depsWithDefaultResponder();

    const result = await runSandboxAgent(
      {
        harness: "claude",
        messages: [{ role: "user", content: "edit the file" }],
      },
      undefined,
      undefined,
      deps,
    );
    await flushPromises();

    assert.equal(result.ok, true);
    if (!result.ok) return;
    assert.equal(result.stopReason, "paused");
    assert.deepEqual(calls.permissionReplies, []);
  });

  it("effective ask with no decision pauses the tool, no harness reply (F-024)", async () => {
    const { calls, deps } = depsWithDefaultResponder();

    const result = await runSandboxAgent(
      {
        harness: "claude",
        sessionId: "conv-1",
        permissions: { default: "ask" },
        messages: [{ role: "user", content: "edit the file" }],
      },
      undefined,
      undefined,
      deps,
    );
    await flushPromises();

    assert.equal(result.ok, true);
    // Park: the interaction_request IS emitted (the FE prompts the browser) ...
    assert.deepEqual(
      result.events
        ?.filter((e) => e.type === "interaction_request")
        .map((e) => ({
          type: e.type,
          id: (e as any).id,
        })),
      [{ type: "interaction_request", id: "perm-1" }],
    );
    // ... but the harness gets NO reply: a `reject` here would make Claude emit a failed tool
    // call that clobbers the approval prompt on the same tool-call id (F-024). The turn ends
    // with the tool pending; the next turn carrying the decision resolves it.
    assert.deepEqual(calls.permissionReplies, []);
  });

  it("settles serialized write-tool sibling calls before pause teardown", async () => {
    const { deps } = fakeHarness({
      promptEvents: [
        {
          payload: {
            update: {
              sessionUpdate: "tool_call",
              toolCallId: "tool-a",
              title: "commit_revision",
              rawInput: { revision: "r1" },
            },
          },
        },
        {
          payload: {
            update: {
              sessionUpdate: "tool_call",
              toolCallId: "tool-b",
              title: "create_subscription",
              rawInput: { plan: "pro" },
            },
          },
        },
      ],
      emitPermission: true,
      permissionToolCallId: "tool-a",
      permissionToolName: "commit_revision",
      permissionRawInput: { revision: "r1" },
      hangPrompt: true,
    });
    delete deps.responderFactory;
    deps.createOtel = createSandboxAgentOtel as any;

    const result = await runSandboxAgent(
      {
        harness: "claude",
        permissions: { default: "ask" },
        messages: [{ role: "user", content: "commit and subscribe" }],
      } as AgentRunRequest,
      undefined,
      undefined,
      deps,
    );
    await flushPromises();

    assert.equal(result.ok, true);
    if (!result.ok) return;
    assert.equal(result.stopReason, "paused");

    const interactions = result.events?.filter(
      (event) => event.type === "interaction_request",
    );
    assert.equal(interactions?.length, 1);
    assert.equal((interactions?.[0] as any).payload?.toolCallId, "tool-a");

    const toolResults = result.events
      ?.filter((event) => event.type === "tool_result")
      .map((event) => ({
        id: (event as any).id,
        output: (event as any).output,
        isError: (event as any).isError,
      }));
    assert.deepEqual(toolResults, [
      {
        id: "tool-b",
        output: TOOL_NOT_EXECUTED_PAUSED,
        isError: true,
      },
    ]);
    assert.equal(
      toolResults?.some((event) => event.id === "tool-a"),
      false,
    );
  });

  it("emits a card for EACH of two racing ask gates and force-settles neither (cold-path plural approvals)", async () => {
    const readOnlySpec = (name: string) => ({
      name,
      kind: "callback",
      readOnly: true,
      permission: "ask",
    });
    const { deps } = fakeHarness({
      promptEvents: [
        {
          payload: {
            update: {
              sessionUpdate: "tool_call",
              toolCallId: "tool-a",
              title: "read_alpha",
              rawInput: { path: "a" },
            },
          },
        },
        {
          payload: {
            update: {
              sessionUpdate: "tool_call",
              toolCallId: "tool-b",
              title: "read_beta",
              rawInput: { path: "b" },
            },
          },
        },
      ],
      emitPermission: true,
      permissionRequests: [
        {
          id: "perm-a",
          availableReplies: ["once", "always", "reject"],
          toolCall: {
            toolCallId: "tool-a",
            name: "read_alpha",
            title: "read_alpha",
            rawInput: { path: "a" },
            input: { path: "a" },
            spec: readOnlySpec("read_alpha"),
          },
        },
        {
          id: "perm-b",
          availableReplies: ["once", "always", "reject"],
          toolCall: {
            toolCallId: "tool-b",
            name: "read_beta",
            title: "read_beta",
            rawInput: { path: "b" },
            input: { path: "b" },
            spec: readOnlySpec("read_beta"),
          },
        },
      ],
      hangPrompt: true,
    });
    delete deps.responderFactory;
    deps.createOtel = createSandboxAgentOtel as any;

    const result = await runSandboxAgent(
      {
        harness: "claude",
        permissions: { default: "ask" },
        messages: [{ role: "user", content: "read both" }],
      } as AgentRunRequest,
      undefined,
      undefined,
      deps,
    );
    await flushPromises();

    assert.equal(result.ok, true);
    if (!result.ok) return;
    assert.equal(result.stopReason, "paused");

    // No latch: BOTH gated tool calls emit their own approval card in the one paused turn, each
    // keyed by its own tool-call id. This is exactly issue #5373's fix — the human now sees every
    // card at once instead of one, with the rest re-asked across later turns.
    const interactions = result.events?.filter(
      (event) => event.type === "interaction_request",
    );
    assert.equal(interactions?.length, 2);
    assert.deepEqual(
      interactions?.map((e) => (e as any).payload?.toolCallId).sort(),
      ["tool-a", "tool-b"],
    );

    // Neither gate is force-settled as TOOL_NOT_EXECUTED_PAUSED: both are held open for their own
    // approval, so no orphaned paused tool_result is emitted.
    const toolResults = result.events?.filter(
      (event) => event.type === "tool_result",
    );
    assert.deepEqual(toolResults, []);
  });

  it("settles a sibling whose announcement arrives AFTER the pause (teardown race)", async () => {
    // The live incident shape: the sibling's `tool_call` announcement rides the ACP event
    // stream and can arrive at the runner AFTER the gate paused the turn and the pause-time
    // sweep already ran. The event-handler re-sweep must settle it deterministically.
    const { deps } = fakeHarness({
      promptEvents: [
        {
          payload: {
            update: {
              sessionUpdate: "tool_call",
              toolCallId: "tool-a",
              title: "commit_revision",
              rawInput: { revision: "r1" },
            },
          },
        },
      ],
      emitPermission: true,
      permissionToolCallId: "tool-a",
      permissionToolName: "commit_revision",
      permissionRawInput: { revision: "r1" },
      // Announced only after the permission gate fired (and the pause ran its sweep).
      postPermissionEvents: [
        {
          payload: {
            update: {
              sessionUpdate: "tool_call",
              toolCallId: "tool-late",
              title: "request_connection",
              rawInput: {
                integration: "slack",
                token: "marker-late-secret-9a21",
              },
            },
          },
        },
      ],
      hangPrompt: true,
    });
    delete deps.responderFactory;
    deps.createOtel = createSandboxAgentOtel as any;

    const result = await runSandboxAgent(
      {
        harness: "claude",
        permissions: { default: "ask" },
        messages: [{ role: "user", content: "commit and connect" }],
        modelConnection: {
          provider: "openai",
          deployment: "direct",
          endpoint: { baseUrl: "https://api.openai.com/v1" },
          credentialMode: "env",
          credentials: [
            {
              binding: { kind: "environment", name: "OPENAI_API_KEY" },
              value: "marker-late-secret-9a21",
              usage: "opaque_http",
            },
          ],
        },
      } as AgentRunRequest,
      undefined,
      undefined,
      deps,
    );
    await flushPromises();

    assert.equal(result.ok, true);
    if (!result.ok) return;
    assert.equal(result.stopReason, "paused");
    const toolResults = result.events
      ?.filter((event) => event.type === "tool_result")
      .map((event) => ({
        id: (event as any).id,
        output: (event as any).output,
        isError: (event as any).isError,
      }));
    assert.deepEqual(toolResults, [
      {
        id: "tool-late",
        output: TOOL_NOT_EXECUTED_PAUSED,
        isError: true,
      },
    ]);
  });

  it("emits the deferred sibling result before the paused turn is done", async () => {
    const emitted: AgentEvent[] = [];
    const { deps } = fakeHarness({
      promptEvents: [
        {
          payload: {
            update: {
              sessionUpdate: "tool_call",
              toolCallId: "tool-a",
              title: "commit_revision",
              rawInput: { revision: "r1" },
            },
          },
        },
      ],
      emitPermission: true,
      permissionToolCallId: "tool-a",
      permissionToolName: "commit_revision",
      permissionRawInput: { revision: "r1" },
      postPermissionEvents: [
        {
          payload: {
            update: {
              sessionUpdate: "tool_call",
              toolCallId: "tool-b",
              title: "create_subscription",
              rawInput: { plan: "pro", token: "marker-live-secret-42bd" },
            },
          },
        },
      ],
      hangPrompt: true,
    });
    delete deps.responderFactory;
    deps.createOtel = createSandboxAgentOtel as any;

    const result = await runSandboxAgent(
      {
        harness: "claude",
        permissions: { default: "ask" },
        messages: [{ role: "user", content: "commit and subscribe" }],
        modelConnection: {
          provider: "openai",
          deployment: "direct",
          endpoint: { baseUrl: "https://api.openai.com/v1" },
          credentialMode: "env",
          credentials: [
            {
              binding: { kind: "environment", name: "OPENAI_API_KEY" },
              value: "marker-live-secret-42bd",
              usage: "opaque_http",
            },
          ],
        },
      } as AgentRunRequest,
      (event) => emitted.push(event),
      undefined,
      deps,
    );
    await flushPromises();

    assert.equal(result.ok, true);
    const interactionIndex = emitted.findIndex(
      (event) => event.type === "interaction_request",
    );
    const siblingCallIndex = emitted.findIndex(
      (event) => event.type === "tool_call" && (event as any).id === "tool-b",
    );
    const siblingResultIndex = emitted.findIndex(
      (event) => event.type === "tool_result" && (event as any).id === "tool-b",
    );
    const doneIndex = emitted.findIndex((event) => event.type === "done");

    assert.notEqual(interactionIndex, -1, "approval request is emitted");
    assert.notEqual(siblingCallIndex, -1, "late sibling call is emitted");
    assert.notEqual(siblingResultIndex, -1, "sibling result is emitted");
    assert.notEqual(doneIndex, -1, "done is emitted");
    assert.ok(
      interactionIndex < siblingCallIndex &&
        siblingCallIndex < siblingResultIndex,
      "the queued late call is emitted and settled after the approval request",
    );
    assert.ok(
      siblingResultIndex < doneIndex,
      "sibling result reaches the live sink before turn finish",
    );
    assert.equal(
      emitted.filter(
        (event) =>
          event.type === "tool_result" && (event as any).id === "tool-b",
      ).length,
      1,
      "the late sibling is settled exactly once",
    );
    assert.equal(
      emitted.some(
        (event) =>
          event.type === "tool_result" && (event as any).id === "tool-a",
      ),
      false,
      "the gated call remains open for human approval",
    );
    await flushPromises();
    assert.equal(
      emitted.at(-1)?.type,
      "done",
      "done remains terminal after another event-loop turn",
    );
  });

  it("drops teardown tool updates after a Pi approval pause while keeping other ids", async () => {
    // The Pi ask arrives as an ACP permission request carrying the gate envelope (the dialog
    // plane); the pause must suppress the GATED call's teardown updates while the sibling is
    // settled deterministically.
    const { deps } = fakeHarness({
      promptEvents: [
        {
          payload: {
            update: {
              sessionUpdate: "tool_call",
              toolCallId: "tool-1",
              title: "approval_needed",
            },
          },
        },
        {
          payload: {
            update: {
              sessionUpdate: "tool_call",
              toolCallId: "tool-2",
              title: "other_tool",
            },
          },
        },
      ],
      emitPermission: true,
      permissionDecision: "pendingApproval",
      permissionRequests: [
        {
          id: "perm-pi",
          availableReplies: ["once", "reject"],
          toolCall: {
            toolCallId: "pi-ui-synthetic",
            title: "agenta-approval",
            rawInput: {
              method: "confirm",
              title: "agenta-approval",
              message: buildPiGateEnvelope({
                gate: "pi-custom-tool",
                toolName: "approval_needed",
                toolCallId: "tool-1",
                input: { path: "a" },
              }),
            },
          },
        },
      ],
      postPermissionEvents: [
        {
          payload: {
            update: {
              sessionUpdate: "tool_call_update",
              toolCallId: "tool-1",
              status: "failed",
              content: [{ content: { type: "text", text: "aborted" } }],
            },
          },
        },
        {
          payload: {
            update: {
              sessionUpdate: "tool_call_update",
              toolCallId: "tool-2",
              status: "failed",
              content: [{ content: { type: "text", text: "other failed" } }],
            },
          },
        },
      ],
    });
    deps.createOtel = createSandboxAgentOtel as any;

    const result = await runSandboxAgent(
      {
        harness: "pi_core",
        permissions: { default: "ask" },
        messages: [{ role: "user", content: "use the tool" }],
        customTools: [
          { name: "approval_needed", kind: "callback", permission: "ask" },
        ],
      } as AgentRunRequest,
      undefined,
      undefined,
      deps,
    );

    assert.equal(result.ok, true);
    if (!result.ok) return;
    assert.equal(result.stopReason, "paused");
    assert.deepEqual(
      result.events
        ?.filter((event) => event.type === "interaction_request")
        .map((event) => ({
          id: (event as any).id,
          kind: (event as any).kind,
          toolCallId: (event as any).payload?.toolCallId,
        })),
      [{ id: "perm-pi", kind: "user_approval", toolCallId: "tool-1" }],
    );
    assert.deepEqual(
      result.events
        ?.filter((event) => event.type === "tool_result")
        .map((event) => ({
          id: (event as any).id,
          output: (event as any).output,
          isError: (event as any).isError,
        })),
      [{ id: "tool-2", output: TOOL_NOT_EXECUTED_PAUSED, isError: true }],
    );
  });

  it("classifies pause-time completed frames by effective permission", async () => {
    const { deps } = fakeHarness({
      promptEvents: [
        {
          payload: {
            update: {
              sessionUpdate: "tool_call",
              toolCallId: "tool-ask",
              title: "ask_sibling",
            },
          },
        },
        {
          payload: {
            update: {
              sessionUpdate: "tool_call",
              toolCallId: "tool-allow",
              title: "allow_sibling",
            },
          },
        },
        {
          payload: {
            update: {
              sessionUpdate: "tool_call",
              toolCallId: "tool-gate",
              title: "pause_gate",
            },
          },
        },
      ],
      emitPermission: true,
      permissionToolCallId: "tool-gate",
      permissionToolName: "pause_gate",
      postPermissionEvents: [
        {
          payload: {
            update: {
              sessionUpdate: "tool_call_update",
              toolCallId: "tool-ask",
              status: "completed",
              content: "cancellation closure",
            },
          },
        },
        {
          payload: {
            update: {
              sessionUpdate: "tool_call_update",
              toolCallId: "tool-allow",
              status: "completed",
              content: "real allow result",
            },
          },
        },
      ],
      hangPrompt: true,
    });
    delete deps.responderFactory;
    deps.createOtel = createSandboxAgentOtel as any;

    const result = await runSandboxAgent(
      {
        harness: "claude",
        permissions: { default: "ask" },
        customTools: [
          { name: "ask_sibling", permission: "ask" },
          { name: "allow_sibling", permission: "allow" },
          { name: "pause_gate", permission: "ask" },
        ],
        messages: [{ role: "user", content: "run the siblings" }],
      } as AgentRunRequest,
      undefined,
      undefined,
      deps,
    );

    assert.equal(result.ok, true);
    if (!result.ok) return;
    assert.equal(result.stopReason, "paused");
    const toolResults = new Map(
      result.events
        ?.filter((event) => event.type === "tool_result")
        .map((event) => [(event as any).id, event]),
    );
    assert.deepEqual(toolResults.get("tool-ask"), {
      type: "tool_result",
      id: "tool-ask",
      output: TOOL_NOT_EXECUTED_PAUSED,
      isError: true,
    });
    assert.deepEqual(toolResults.get("tool-allow"), {
      type: "tool_result",
      id: "tool-allow",
      output: "real allow result",
      isError: false,
    });
  });

  it("park ENDS the turn even when the prompt hangs: terminal stopReason 'paused', no harness reply (F-040)", async () => {
    // The real regression: Claude does NOT end a turn on an unanswered gate, so without the
    // park->cancel path `session.prompt()` blocks forever and the run never returns. With
    // hangPrompt the fake prompt never resolves on its own; the run must still RETURN, driven
    // by the park signal + the managed cancel.
    const { calls, deps } = (() => {
      const { calls, deps } = fakeHarness({
        emitPermission: true,
        hangPrompt: true,
      });
      delete deps.responderFactory; // engine ApprovalResponder -> pauses (effective ask, no decision)
      return { calls, deps };
    })();

    const result = await runSandboxAgent(
      {
        harness: "claude",
        sessionId: "conv-1",
        permissions: { default: "ask" },
        messages: [{ role: "user", content: "edit the file" }],
      },
      undefined,
      undefined,
      deps,
    );
    await flushPromises();

    assert.equal(result.ok, true);
    if (!result.ok) return;
    // The turn returns terminal-but-incomplete: `paused` tells the egress to emit a clean
    // `finish` so the FE can resume on the user's decision (no immortal-park hang, F-040).
    assert.equal(result.stopReason, "paused");
    // No reply reached the harness (no F-024 clobber).
    assert.deepEqual(calls.permissionReplies, []);
    // The session was cancelled (managed `session/cancel` via destroySession) ...
    assert.equal(calls.sessionDestroyed, 1);
    // ... and the sandbox was disposed in the finally — the parked turn does NOT leak it.
    assert.equal(calls.sandboxDestroyed, 1);
    assert.equal(calls.sandboxDisposed, 1);
    assert.equal(calls.workspaceCleanup, 1);
  });

  it("park terminates even if the managed cancel rejects (local park signal still ends the turn)", async () => {
    // Defense in depth: if destroySession throws (the daemon already tore down, a network
    // blip, etc.) and the prompt never resolves, the local `parkedSignal` must STILL end the
    // turn so the run returns and the `finally` disposes the sandbox (no hang, no leak).
    const { calls, deps } = (() => {
      const { calls, deps } = fakeHarness({
        emitPermission: true,
        hangPrompt: true,
        destroySessionError: new Error("session already gone"),
      });
      delete deps.responderFactory;
      return { calls, deps };
    })();

    const result = await runSandboxAgent(
      {
        harness: "claude",
        sessionId: "conv-1",
        permissions: { default: "ask" },
        messages: [{ role: "user", content: "edit the file" }],
      },
      undefined,
      undefined,
      deps,
    );
    await flushPromises();

    assert.equal(result.ok, true);
    if (!result.ok) return;
    assert.equal(result.stopReason, "paused");
    assert.equal(calls.sessionDestroyed, 1, "cancel was attempted");
    // The turn still ended and the sandbox was disposed despite the failed cancel.
    assert.equal(calls.sandboxDestroyed, 1);
    assert.equal(calls.sandboxDisposed, 1);
  });

  it("human surface with a stored approval resumes the tool (once)", async () => {
    const { calls, deps } = depsWithDefaultResponder();

    const result = await runSandboxAgent(
      {
        harness: "claude",
        sessionId: "conv-1",
        permissions: { default: "ask" },
        messages: [
          { role: "user", content: "edit the file" },
          {
            // The cross-turn approval reply. Cold replay mints a fresh tool-call id "tool-1"
            // each turn, so the anchor is the tool's name + args (here a no-arg edit -> {}).
            role: "tool",
            content: [
              {
                type: "tool_result",
                toolCallId: "tool-1",
                toolName: "edit",
                output: { approved: true },
              },
            ],
          },
          { role: "user", content: "continue" },
        ],
      },
      undefined,
      undefined,
      deps,
    );
    await flushPromises();

    assert.equal(result.ok, true);
    // Resumes via the name+args anchor, then grants ONCE (per call), not always.
    assert.deepEqual(calls.permissionReplies, [
      { id: "perm-1", reply: "once" },
    ]);
  });
});
describe("runTurn run-limits deadline (split path)", () => {
  // Tiny real-ms limits injected through the run-limits DI seam: the integration path exercises
  // the real createRunLimits (timers + trip wiring), so the windows are a few ms and driven by
  // real timers. TTFB (5ms) is the shortest, so a silent harness trips it first.
  const fastLimits = {
    resolveRunLimits: () => ({
      totalMs: 50,
      idleMs: 50,
      ttfbMs: 5,
      toolCallMs: 50,
    }),
  };

  it("ends a wedged never-responding turn as an error so the finally reclaims the sandbox", async () => {
    // The harness comes up but the prompt never resolves on its own — a wedged run. With no
    // deadline it would hold the sandbox forever; the tripped TTFB limit must end the turn.
    const { calls, deps } = fakeHarness({ hangPrompt: true });

    const result = await runSandboxAgent(
      { harness: "claude", messages: [{ role: "user", content: "hello" }] },
      undefined,
      undefined,
      { ...deps, ...fastLimits },
    );

    // The run RETURNED (did not hang) as a failure, and the teardown finally reclaimed the sandbox.
    assert.equal(result.ok, false);
    if (result.ok) return;
    assert.match(result.error ?? "", /first response|deadline|idle|run limit/i);
    assert.equal(calls.sandboxDestroyed, 1);
    assert.equal(calls.sandboxDisposed, 1);
  });

  it("does NOT trip a turn that paused for human input, even past every deadline window", async () => {
    // A gated tool call parks the turn (pause path), which retires the deadlines via notePaused.
    // With tiny limits a wedged turn WOULD trip almost immediately — so a clean `paused` finish
    // (never a deadline error) proves the pause exemption held. The prompt hangs; only the local
    // park signal ends the turn. Setup mirrors the F-040 park test (real ApprovalResponder).
    const { calls, deps } = (() => {
      const { calls, deps } = fakeHarness({
        emitPermission: true,
        hangPrompt: true,
      });
      delete deps.responderFactory; // engine ApprovalResponder -> pauses (ask, no stored decision)
      return { calls, deps };
    })();

    const result = await runSandboxAgent(
      {
        harness: "claude",
        sessionId: "conv-paused",
        permissions: { default: "ask" },
        messages: [{ role: "user", content: "edit the file" }],
      },
      undefined,
      undefined,
      { ...deps, ...fastLimits },
    );
    await flushPromises();

    assert.equal(result.ok, true);
    if (!result.ok) return;
    // Paused, not a deadline error: the pause path — not a tripped limit — ended the turn.
    assert.equal(result.stopReason, "paused");
    assert.equal(calls.sandboxDestroyed, 1);
  });
});
