/**
 * Daytona tool relay — the RUNNER side.
 *
 * Tool child processes do not receive private resolved specs, executable code, scoped env,
 * callback endpoints, or callback auth. They receive only public tool metadata plus this
 * relay directory, then ask the runner to execute each call.
 *
 * The runner CAN reach Agenta (it resolved the tools and holds the callback), and it can
 * reach the sandbox filesystem over the daemon API. So tool calls are relayed through the
 * runner via files in a sandbox dir:
 *
 *   child:  write `<id>.req.json` {toolName, args} ──▶ poll `<id>.res.json`
 *   runner: poll the dir, read `<id>.req.json` ──▶ execute private spec in memory
 *           ──▶ write `<id>.res.json`
 *
 * The same loop supports local filesystem relays and Daytona sandbox filesystem relays.
 *
 * The relay is split across three modules: the bundle-safe wire protocol (suffixes,
 * request/response shapes, serialization, shared timing) lives in `relay-protocol.ts`;
 * the in-sandbox writer client lives in `relay-client.ts`; this module keeps the
 * runner-side consumer/executor loop. The protocol pieces are re-exported below so
 * existing importers keep compiling.
 */
import {
  existsSync,
  mkdirSync,
  readdirSync,
  readFileSync,
  renameSync,
  statSync,
  unlinkSync,
  writeFileSync,
} from "node:fs";

import { callAgentaTool } from "./callback.ts";
import { CODE_TOOL_UNSUPPORTED_MESSAGE } from "./code.ts";
import { specInputSchema } from "./spec-schema.ts";
import { declinedByUserText } from "./denial-text.ts";
import {
  applyContextBindings,
  assembleBody,
  callDirect,
  deepDelete,
  directCallUrl,
  pathParamNames,
  resolveEphemeralArgs,
} from "./direct.ts";
import type {
  GatewayPolicy,
  ResolvedToolSpec,
  RunContext,
  ToolCallbackContext,
} from "../protocol.ts";
import {
  filterGatewaySearchResult,
  gatewayToolUnavailableText,
  normalizeGatewayPolicy,
  planGatewayRun,
  planGatewaySearch,
  sanitizeGatewayRunError,
  GATEWAY_RUN_CALL_REF,
  GATEWAY_SEARCH_CALL_REF,
  TOOL_SEARCH_UNAVAILABLE_ERROR,
  type GatewayCallContext,
  type GatewayToolGate,
  type NormalizedGatewayPolicy,
} from "./gateway-policy.ts";
import type { ClientToolRelay } from "./client-tool-relay.ts";
import {
  RELAY_POLL_MS,
  RELAY_REQ_SUFFIX,
  RELAY_RES_SUFFIX,
  relayTempPath,
  sleep,
  type ExecuteRelayRequest,
  type RelayRequest,
  type RelayResponse,
} from "./relay-protocol.ts";
import {
  RELAY_SAFETY_POLL_MS,
  daytonaRelayActivitySource,
  localRelayActivitySource,
  remoteWatchEnabled,
  type RelayActivitySource,
} from "./relay-watch.ts";
import { assertRequiredArguments } from "./spec-schema.ts";
import { toolSpecsByName } from "./public-spec.ts";

// Compatibility re-export: the type moved to `client-tool-relay.ts` (a pure type module);
// importers that still reach it through this module keep working while they migrate.
export type {
  ClientToolRelay,
  ClientToolRelayRequest,
} from "./client-tool-relay.ts";

// Compatibility re-export: the wire protocol moved to `relay-protocol.ts` (bundle-safe,
// shared with the in-sandbox writer); importers that still reach it through this module
// keep working while they migrate.
export {
  RELAY_POLL_MS,
  RELAY_REQ_SUFFIX,
  RELAY_RES_SUFFIX,
  RELAY_TIMEOUT_MS,
  sanitizeRelayId,
  sleep,
} from "./relay-protocol.ts";
export type {
  ExecuteRelayRequest,
  ExecuteRelayResponse,
  RelayRequest,
  RelayResponse,
} from "./relay-protocol.ts";
/**
 * Idle-backoff cap for the runner relay poll. The loop polls `host.list(relayDir)` every
 * `RELAY_POLL_MS` (300 ms) for the whole turn — on Daytona that `list` is a remote `ls` exec
 * (~3×/s), now also for client-only runs that wait on a browser-fulfilled pause and produce no
 * other tool traffic. After `RELAY_POLL_IDLE_GROW_AFTER` consecutive idle polls the delay grows
 * geometrically up to this cap, so a quiet turn settles to ~1.5 s polls; the moment a request
 * file appears the delay resets to `RELAY_POLL_MS`, so a real tool call is still picked up
 * promptly.
 */
export const RELAY_POLL_MAX_MS = Number(
  process.env.AGENTA_AGENT_TOOLS_RELAY_POLLING_MAX ?? 1500,
);
export const RELAY_POLL_IDLE_GROW_AFTER = Number(
  process.env.AGENTA_AGENT_TOOLS_RELAY_IDLE_GROW_AFTER ?? 5,
);

/** The next poll delay given the count of consecutive idle polls (no new request seen). */
export function relayPollDelayMs(idlePolls: number): number {
  if (idlePolls < RELAY_POLL_IDLE_GROW_AFTER) return RELAY_POLL_MS;
  const factor = 2 ** (idlePolls - RELAY_POLL_IDLE_GROW_AFTER + 1);
  return Math.min(RELAY_POLL_MS * factor, RELAY_POLL_MAX_MS);
}

const PAUSED = Symbol("paused");

/**
 * A call the runner REFUSED, carrying the reason the model must read.
 *
 * Refusals used to travel as an ordinary return string, so the relay wrote `{ok: true, text}` and
 * every transport reported a refused commit as a SUCCESS. On Codex that surfaced as a blank
 * successful tool result: the model saw no error and no text, invented an explanation, and told
 * the user to approve again. A refusal that reads as success is worse than one that reads as a
 * crash, because only the second makes the model stop.
 *
 * The class exists so the reason cannot be confused with output at any layer between here and the
 * harness. The model still gets the text and the loop still continues; only `isError` changes.
 */
export class RelayRefusal {
  constructor(readonly reason: string) {}
}

/**
 * Runner-side authorization for one relay execute record. The relay dir is sandbox-writable,
 * so a record can be forged without ever passing the in-sandbox approval dialog; this re-check
 * is the runner-side enforcement the dialog cannot provide. The deny reason becomes the tool's
 * result text, so the model loop continues (same shape as a dialog deny).
 */
export type RelayExecutionGuard = (
  spec: ResolvedToolSpec,
  req: ExecuteRelayRequest,
) => { allow: true } | { allow: false; reason: string };

/**
 * Second-stage authorization for a call whose arguments reference approved content.
 *
 * Separate from the guard on purpose, and it must stay separate. The guard answers "does the
 * permission policy let this tool run", and on a non-Pi harness it passes every `ask` verdict
 * because the harness raises its own dialog and the runner records no grant for it. That pass
 * is a COMPATIBILITY behavior, not a policy statement — a forged request file can still start
 * an `ask` tool with no dialog on that path.
 *
 * This hook is what makes that harmless for a call carrying approved content: it demands a
 * single-use record the RUNNER minted at the gate, binding the exact tool, the exact arguments,
 * and the exact bytes a human saw. It runs for every harness, it never depends on a dialog, and
 * a missing record fails the call closed. It returns the arguments to execute, so the approved
 * bytes — not a fresh read of the workspace — are what run.
 */
export type RelayExecutionAuthorizer = (
  spec: ResolvedToolSpec,
  req: ExecuteRelayRequest,
) => Promise<{ ok: true; args: unknown } | { ok: false; reason: string }>;

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function cloneJsonish(value: unknown): unknown {
  if (Array.isArray(value)) return value.map((item) => cloneJsonish(item));
  if (!isRecord(value)) return value;
  const out: Record<string, unknown> = {};
  for (const [key, item] of Object.entries(value)) {
    out[key] = cloneJsonish(item);
  }
  return out;
}

function pruneEmptyAncestors(
  target: Record<string, unknown>,
  path: string,
): void {
  const parts = path.split(".");
  const ancestors: Array<{ owner: Record<string, unknown>; key: string }> = [];
  let cursor = target;
  for (const part of parts.slice(0, -1)) {
    const next = cursor[part];
    if (!isRecord(next)) return;
    ancestors.push({ owner: cursor, key: part });
    cursor = next;
  }
  for (const { owner, key } of ancestors.reverse()) {
    const value = owner[key];
    if (!isRecord(value) || Object.keys(value).length > 0) return;
    delete owner[key];
  }
}

/**
 * Strip context-bound argument paths from a tool call's args. Bound paths are overwritten from
 * runContext at execution, so approval display and stored-decision keys must not include the
 * model's values for them: a card would show a value that never executes, and a decision keyed
 * on it would not match the same call re-keyed after redaction. Empty ancestor objects left by
 * a deleted path are pruned so the redacted shape is canonical.
 */
export function redactContextBoundArgs(
  args: unknown,
  contextBindings: Record<string, string> | undefined,
): unknown {
  if (!contextBindings || Object.keys(contextBindings).length === 0)
    return args;
  if (!isRecord(args)) return args;
  const redacted = cloneJsonish(args);
  if (!isRecord(redacted)) return redacted;
  for (const path of Object.keys(contextBindings)) {
    deepDelete(redacted, path);
    pruneEmptyAncestors(redacted, path);
  }
  return redacted;
}

export interface RelayHost {
  list: (dir: string) => Promise<string[]>;
  read: (path: string) => Promise<string>;
  write: (path: string, contents: string) => Promise<void>;
  /**
   * Atomically publish a fully written file under its final name (plan decision 2):
   * the response is written to a `relayTempPath` name first and this rename makes it
   * visible, so the in-sandbox writer can never read partial JSON.
   */
  rename: (from: string, to: string) => Promise<void>;
  /**
   * Delete one relay file. Used for delete-on-pickup: the runner removes a request
   * file as soon as it has read it, so a watch that wakes on ANY `*.req.json` present
   * (the Daytona watch exec) does not insta-complete and rearm for the whole
   * execution. Call sites guard with their own try/catch (pickup removal is
   * best-effort); implementations may throw.
   */
  remove: (path: string) => Promise<void>;
  /**
   * Optional mtime probe for one relay file, in epoch milliseconds; used only for the
   * stage=relay_pickup telemetry line (pickup latency = now − request-file mtime).
   * Undefined (no capability, missing file, or any error) makes the telemetry report
   * pickup_ms=-1 — never an execution failure. Cost: one stat per executed request
   * (local: free; Daytona: +1 daemon call per tool call, small next to the removed
   * polling).
   */
  statMtimeMs?: (path: string) => Promise<number | undefined>;
  /**
   * Optional hop 2 wake source for the relay dir (plan decision 3). Undefined means
   * the loop is byte-for-byte today's poll loop. A source that suspends polling
   * (Daytona watch exec) replaces the remote poll with the 30 s safety poll while
   * healthy; one that does not (local fs.watch) only shortens the poll sleep.
   */
  createActivitySource?: (dir: string) => RelayActivitySource | undefined;
}

/** Relay host for child processes running on the same filesystem as the runner. */
export function localRelayHost(): RelayHost {
  return {
    list: async (dir) => {
      if (!existsSync(dir)) return [];
      return readdirSync(dir);
    },
    read: async (path) => readFileSync(path, "utf-8"),
    write: async (path, contents) => {
      mkdirSync(path.slice(0, path.lastIndexOf("/")), { recursive: true });
      writeFileSync(path, contents, "utf-8");
    },
    rename: async (from, to) => {
      renameSync(from, to);
    },
    remove: async (path) => {
      unlinkSync(path);
    },
    statMtimeMs: async (path) => {
      try {
        return statSync(path).mtimeMs;
      } catch {
        return undefined;
      }
    },
    // Unflagged (plan decision 7, last paragraph): the local watch's failure mode is
    // "fall back to the poll" and the poll cadence is unchanged either way.
    createActivitySource: (dir) => localRelayActivitySource(dir),
  };
}

/** Relay host for child processes running inside a Daytona sandbox. */
export function sandboxRelayHost(
  sandbox: any,
  opts?: { log?: (msg: string) => void },
): RelayHost {
  return {
    list: async (dir) => {
      const ls = await sandbox.runProcess({
        command: "ls",
        args: ["-1", dir],
        timeoutMs: 10_000,
      });
      return String(ls?.stdout ?? "")
        .split("\n")
        .map((s) => s.trim())
        .filter(Boolean);
    },
    read: async (path) => {
      const bytes = await sandbox.readFsFile({ path });
      return typeof bytes === "string"
        ? bytes
        : new TextDecoder().decode(bytes);
    },
    write: async (path, contents) => {
      await sandbox.writeFsFile({ path }, contents);
    },
    rename: async (from, to) => {
      // Verified against the daemon source (v0.4.2 router.rs): /v1/fs/move is Rust
      // std::fs::rename, i.e. rename(2), atomic for a same-directory move (plan open
      // question 2 resolved). `overwrite: true` only guards a pathological duplicate
      // response; the final name never pre-exists in normal operation.
      await sandbox.moveFs({ from, to, overwrite: true });
    },
    remove: async (path) => {
      await sandbox.deleteFsEntry({ path });
    },
    statMtimeMs: async (path) => {
      // FsStat.modified is an RFC3339 string | null (verified against
      // node_modules/sandbox-agent/dist/index.d.ts); absent/null/unparseable -> undefined.
      try {
        const stat = await sandbox.statFs({ path });
        const modified = stat?.modified;
        if (typeof modified !== "string") return undefined;
        const parsed = Date.parse(modified);
        return Number.isFinite(parsed) ? parsed : undefined;
      } catch {
        return undefined;
      }
    },
    // Flagged (plan decision 7): the remote watch changes what the runner asks the
    // daemon to do, so it ships behind AGENTA_AGENT_TOOLS_RELAY_REMOTE_WATCH_ENABLED
    // (default false). Off means today's poll loop, byte for byte.
    createActivitySource: (dir) =>
      remoteWatchEnabled()
        ? daytonaRelayActivitySource(sandbox, dir, { log: opts?.log })
        : undefined,
  };
}

/**
 * One resolved gateway call: what actually goes on the wire once the policy has spoken.
 *
 * The model's outer arguments are NOT what is sent. `gateway.run` forwards the integration
 * tool's own arguments and nothing else, and the routing travels beside them as private
 * context the model can never supply.
 */
type GatewayExecution =
  /** Its SUCCESS body is filtered before the model sees it. */
  | {
      kind: "search";
      args: Record<string, unknown>;
      context: GatewayCallContext;
    }
  /** `integration` names whose catalog the error envelope's suggestions may draw from. */
  | {
      kind: "run";
      args: Record<string, unknown>;
      context: GatewayCallContext;
      integration: string;
    };

/**
 * Turn-scoped memory of what search last offered the model, kept only so the gate's log line can
 * report which rank the model then ran, and whether it ran anything without searching at all.
 * Those two numbers are what say whether search is steering the model or whether it is guessing.
 * Nothing reads this to make a decision.
 */
interface GatewaySearchMemory {
  /** `integration.TOOL` in the order the model saw them, from the most recent search. */
  offered: string[];
  searches: number;
}

/** The gateway wiring the relay loop hands to each execution. */
interface GatewaySeam {
  /** Validated ONCE, when the relay starts. No raw wire policy reaches a decision. */
  policy: NormalizedGatewayPolicy;
  gate: GatewayToolGate | undefined;
  memory: GatewaySearchMemory;
}

// The relay carries EXECUTION only for every OTHER tool. Permission gates never ride these
// files: Claude raises its own ACP gates before a call reaches the relay, and a Pi gate rides
// the extension's `ctx.ui.confirm` dialog onto the ACP permission plane (Pi approval parking),
// decided and parked by the runner's permission responder before the extension writes an
// execute request.
//
// The two gateway tools are the exception, and they have to be. Their specifications carry the
// coarse `permission: "allow"` that opens the harness gate, so no dialog anywhere upstream has
// decided anything about the integration tool the model named — the semantic decision happens
// HERE, at the seam every delivery path passes through, against the runner's private policy.
async function executeRelayedTool(
  spec: ResolvedToolSpec,
  req: ExecuteRelayRequest,
  callback: ToolCallbackContext | undefined,
  runContext: RunContext | undefined,
  clientToolRelay: ClientToolRelay | undefined,
  guard: RelayExecutionGuard | undefined,
  authorizer: RelayExecutionAuthorizer | undefined,
  gateway: GatewaySeam,
  log: ((msg: string) => void) | undefined,
): Promise<string | RelayRefusal | typeof PAUSED> {
  if (spec.kind === "client") {
    assertRequiredArguments(spec, req.args);
    if (!clientToolRelay) {
      throw new Error(
        `client tool '${spec.name}' is browser-fulfilled and cannot be executed`,
      );
    }
    const toolCallId = req.toolCallId;
    const request = {
      id: toolCallId,
      toolCallId,
      toolName: spec.name,
      input: req.args,
      spec,
    };
    const decision = await clientToolRelay.onClientTool(request);
    if (decision === "pendingApproval") {
      clientToolRelay.onPause?.(request);
      return PAUSED;
    }
    if (decision === "deny") {
      return new RelayRefusal(declinedByUserText(spec.name));
    }
    return JSON.stringify(decision.output ?? {});
  }

  // The semantic gateway gate. It runs BEFORE the coarse guard and before any callback, so a
  // denied integration tool never reaches a provider and a forged request file is decided by
  // exactly the same rule as a harness call.
  let resolved: GatewayExecution | undefined;
  if (spec.callRef === GATEWAY_RUN_CALL_REF) {
    const plan = planGatewayRun(req.args, gateway.policy);
    if (!plan.ok) {
      log?.(
        `[gateway] gate tool=${spec.name} outcome=refused reason=malformed_or_unconfigured`,
      );
      return new RelayRefusal(plan.reason);
    }
    if (!gateway.gate) {
      // No gate wired means no way to apply the policy or to ask a human. Fail closed.
      log?.(
        `[gateway] gate target=${plan.display} outcome=deny reason=no_gate`,
      );
      return new RelayRefusal(gatewayToolUnavailableText());
    }
    const verdict = await gateway.gate.onGatewayRun({
      id: req.toolCallId,
      toolCallId: req.toolCallId,
      toolName: spec.name,
      input: req.args,
      plan,
    });
    // rank: where this tool sat in the last filtered search (1-based), or -1 when the model ran
    // it without search offering it. searches=0 with a run attempt is the "guessed a key" case.
    const rank = gateway.memory.offered.indexOf(plan.display) + 1;
    log?.(
      `[gateway] gate integration=${plan.target.integration} tool=${plan.target.tool} ` +
        `permission=${plan.permission} outcome=${verdict.kind} ` +
        `rank=${rank > 0 ? rank : -1} searches=${gateway.memory.searches}`,
    );
    if (verdict.kind === "deny") return new RelayRefusal(verdict.reason);
    if (verdict.kind === "pendingApproval") {
      gateway.gate.onPause?.();
      return PAUSED;
    }
    resolved = {
      kind: "run",
      args: plan.target.arguments,
      context: plan.context,
      integration: plan.target.integration,
    };
  } else if (spec.callRef === GATEWAY_SEARCH_CALL_REF) {
    // Rejected here rather than at the API: only the runner holds the configured set.
    const plan = planGatewaySearch(req.args, gateway.policy);
    if (!plan.ok) {
      log?.(`[gateway] search outcome=refused`);
      return new RelayRefusal(plan.reason);
    }
    resolved = { kind: "search", args: plan.arguments, context: plan.context };
  }

  // Client tools keep their own browser-fulfilled pause semantics above; everything else is
  // re-checked here because the request file is sandbox-writable and proves nothing about the
  // dialog gate having run.
  if (guard) {
    const verdict = guard(spec, req);
    if (!verdict.allow) return new RelayRefusal(verdict.reason);
  }

  // Passing the guard is NOT enough for a call that carries approved content: on a non-Pi
  // harness the guard passes `ask` for compatibility, so the authorization record is the only
  // thing standing between a forged request file and an unapproved execution. The substituted
  // arguments it returns carry the frozen bytes the human saw.
  if (authorizer) {
    const verdict = await authorizer(spec, req);
    if (!verdict.ok) return new RelayRefusal(verdict.reason);
    return executeAllowedRelayedTool(
      spec,
      { ...req, args: verdict.args },
      callback,
      runContext,
      gateway,
      resolved,
      log,
    );
  }

  return executeAllowedRelayedTool(
    spec,
    req,
    callback,
    runContext,
    gateway,
    resolved,
    log,
  );
}

async function executeAllowedRelayedTool(
  spec: ResolvedToolSpec,
  req: ExecuteRelayRequest,
  callback: ToolCallbackContext | undefined,
  runContext: RunContext | undefined,
  gateway: GatewaySeam,
  resolved: GatewayExecution | undefined,
  log?: (msg: string) => void,
): Promise<string | RelayRefusal> {
  assertRequiredArguments(spec, req.args);
  if (spec.kind === "code") {
    // Code execution was removed (F-010). Refused up front in `buildRunPlan`; this inline throw
    // is the defense-in-depth backstop so a code spec reaching the relay fails loud (F-016).
    throw new Error(CODE_TOOL_UNSUPPORTED_MESSAGE);
  }
  if (!callback?.endpoint) {
    throw new Error(`missing toolCallback endpoint for '${spec.name}'`);
  }
  if (resolved) {
    let text: string;
    try {
      text = await callAgentaTool(
        callback.endpoint,
        callback.authorization,
        spec.callRef ?? "",
        req.toolCallId,
        resolved.args,
        {
          timeoutMs: spec.timeoutMs,
          runKind: runContext?.run?.kind,
          context: resolved.context,
          // `gateway.run` only, and only for the error envelope: the API builds close-key
          // suggestions from the whole catalog and cannot know what this agent denied.
          ...(resolved.kind === "run"
            ? {
                sanitizeErrorContent: (content: string) =>
                  sanitizeGatewayRunError(
                    content,
                    resolved.integration,
                    gateway.policy,
                  ),
              }
            : {}),
        },
      );
    } catch (err) {
      // A `gateway.run` failure keeps its provider detail — that detail is what lets the model
      // correct a rejected but well-formed request, and its suggestion list was sanitized above.
      if (resolved.kind === "run") throw err;
      // A `gateway.search` failure does NOT. Every non-result search body becomes the one fixed
      // envelope, whatever the API said: a business-level failure throws out of `callAgentaTool`
      // before the filter can run, and its detail is the API's own text — which can name a
      // toolkit this agent never configured, or carry routing the model must not see. This is
      // the same envelope the unparsable-body path writes, so "search did not work" has exactly
      // one shape.
      gateway.memory.searches += 1;
      gateway.memory.offered = [];
      log?.(
        `[gateway] search outcome=failed reason=callback_error ` +
          `envelope=${TOOL_SEARCH_UNAVAILABLE_ERROR.code}`,
      );
      return new RelayRefusal(JSON.stringify(TOOL_SEARCH_UNAVAILABLE_ERROR));
    }
    // `gateway.run` on success stays a pass-through. Only search results are transformed.
    if (resolved.kind === "run") return text;
    // The filter used to be incapable of throwing on a well-formed body — a bad one became
    // `unparsable` internally. The schema-prose redaction added a recursive walk, so a
    // pathologically nested schema can now raise. A throw here would escape the seam as a raw
    // error, which contradicts this function's own contract that every non-result search body
    // becomes the one fixed envelope. Catch anything the filter grows, not just this.
    let outcome: ReturnType<typeof filterGatewaySearchResult>;
    try {
      outcome = filterGatewaySearchResult(text, gateway.policy);
    } catch (err) {
      gateway.memory.searches += 1;
      gateway.memory.offered = [];
      log?.(
        `[gateway] search outcome=failed reason=filter_error ` +
          `envelope=${TOOL_SEARCH_UNAVAILABLE_ERROR.code} ` +
          `detail=${String(err instanceof Error ? err.message : err).slice(0, 120)}`,
      );
      return new RelayRefusal(JSON.stringify(TOOL_SEARCH_UNAVAILABLE_ERROR));
    }
    gateway.memory.searches += 1;
    gateway.memory.offered = outcome.offered;
    log?.(
      `[gateway] search results=${outcome.total} kept=${outcome.kept} ` +
        `unconfigured=${outcome.drops.unconfigured} unknown=${outcome.drops.unknownTool} ` +
        `denied=${outcome.drops.denied} schema=${outcome.drops.schema} ` +
        `capped=${outcome.drops.capped} unparsable=${outcome.unparsable}`,
    );
    // An unparsable body is a search failure too, and reads as one: same envelope, same
    // `ok: false` framing, so the model never sees a failure dressed as an empty success.
    if (outcome.unparsable) return new RelayRefusal(outcome.payload);
    return outcome.payload;
  }
  // Drop the model-authored arguments that are for the human only (today: the ephemeral per-call
  // `description`, R12). This runs BEFORE the dispatch fork so both modes strip identically, and
  // before `assembleBody` so an `args_into` op cannot deep-set the note inside its payload. The
  // recorded call and the approval card keep the full arguments; only the request loses them.
  //
  // The same pass lifts a note the model wrote one level too deep, inside the payload object,
  // which a closed schema would otherwise reject outright. See `resolveEphemeralArgs`.
  const ephemeral = resolveEphemeralArgs(
    req.args,
    spec.ephemeralArgs,
    specInputSchema(spec) ?? undefined,
  );
  const dispatchArgs = ephemeral.args;
  for (const entry of ephemeral.lifted) {
    log?.(
      `[tool-relay] lifted '${entry.name}' out of '${entry.from}' for ${spec.name}: ` +
        "the model wrote it inside the payload, where the endpoint would refuse it",
    );
  }
  for (const entry of ephemeral.shadowed) {
    log?.(
      `[tool-relay] dropped a second '${entry.name}' from '${entry.from}' for ${spec.name}: ` +
        "the call already carries one at the top level",
    );
  }
  // Direct-call tools (reference / platform): the host makes the call directly so the sandbox
  // child still sends only name + args. The origin is bound to the run's own callback endpoint
  // and the run's authorization is reused (see tools/direct.ts). A spec carries `call` XOR
  // `callRef`, so this is checked before the gateway fallback. `runContext` fills the
  // `call.context` bindings server-side (direct-call tools, Phase 3a), hidden from the model.
  if (spec.call) {
    const body = assembleBody(spec.call, dispatchArgs, runContext, spec.name);
    const url = directCallUrl(callback.endpoint, spec.call, body);
    // Path params were just substituted into the URL from this same body; strip them so a
    // POST handler whose request model expects the identifier only in the route (e.g.
    // `/api/triggers/schedules/{id}/stop`) does not also receive `id` in the JSON payload.
    for (const name of pathParamNames(spec.call.path)) {
      deepDelete(body, name);
    }
    return callDirect(spec.call.method, url, callback.authorization, body, {
      runKind: runContext?.run?.kind,
    });
  }
  // Gateway (Composio) and handler-mode platform ops: POST back through Agenta's /tools/call so
  // the secret stays server-side.
  const args = spec.contextBindings
    ? applyContextBindings(dispatchArgs, spec.contextBindings, runContext)
    : dispatchArgs;
  return callAgentaTool(
    callback.endpoint,
    callback.authorization,
    spec.callRef ?? "",
    req.toolCallId,
    args,
    { timeoutMs: spec.timeoutMs, runKind: runContext?.run?.kind },
  );
}

/** A relay-owned file name: request, response, or either one's atomic-publication temp
 *  name. The sweep below may remove ONLY these — the relay dir also holds non-relay
 *  files (Pi's usage file lives there) that must never be touched. */
function isRelayFileName(name: string): boolean {
  return (
    name.endsWith(RELAY_REQ_SUFFIX) ||
    name.endsWith(RELAY_RES_SUFFIX) ||
    name.includes(`${RELAY_REQ_SUFFIX}.tmp.`) ||
    name.includes(`${RELAY_RES_SUFFIX}.tmp.`)
  );
}

/** Bound one daemon removal so relay startup, polling, and shutdown cannot wedge on it. */
const RELAY_REMOVE_TIMEOUT_MS = 10_000;

async function removeRelayFile(
  host: RelayHost,
  path: string,
): Promise<boolean> {
  let timer: ReturnType<typeof setTimeout> | undefined;
  const timeout = new Promise<false>((resolve) => {
    timer = setTimeout(() => resolve(false), RELAY_REMOVE_TIMEOUT_MS);
  });
  try {
    return await Promise.race([
      Promise.resolve(host.remove(path)).then(
        () => true,
        () => false,
      ),
      timeout,
    ]);
  } catch {
    return false;
  } finally {
    clearTimeout(timer);
  }
}

/**
 * Clear pre-turn relay residue from a reused relay dir (a warm-continued turn skips the
 * cold build's rm -rf, so a crashed prior turn can leave files behind). Every relay
 * file already present is stale — requests would re-execute under this turn's fresh
 * `seen` set, temp names are dead atomic-publication residue, and stale RESPONSES are
 * dangerous too: a resumed approval reuses its original toolCallId, so a crashed prior
 * attempt's `<id>.res.json` would satisfy the new wait instantly with stale bytes.
 * Non-relay names are never touched.
 *
 * The listing is retried up to 3 times (150 ms apart): a missing dir throws on some
 * hosts and holds no stale files anyway, and a transiently unlistable dir accepts the
 * pre-existing-residue risk rather than the swallow-a-live-request risk — the caller
 * (startToolRelay) guarantees no LEGITIMATE request can exist before this sweep
 * settles, so sweeping only what an early list shows is always safe, and giving up
 * after 3 failures is too.
 */
export async function sweepStaleRelayFiles(
  host: RelayHost,
  relayDir: string,
  log: (msg: string) => void,
): Promise<void> {
  for (let attempt = 1; attempt <= 3; attempt += 1) {
    let names: string[];
    try {
      names = await host.list(relayDir);
    } catch {
      if (attempt < 3) {
        await sleep(150);
        continue;
      }
      log("[relay] stale sweep skipped: relay dir unlistable after 3 attempts");
      return;
    }
    const stale = names.filter(isRelayFileName);
    if (stale.length > 0) {
      // Best-effort and concurrent: a failed removal is accepted (a leftover request
      // is only re-armed watch noise once the loop's seen set has it; a leftover
      // response is inert for fresh toolCallIds).
      await Promise.allSettled(
        stale.map((name) => removeRelayFile(host, `${relayDir}/${name}`)),
      );
      log(
        `[relay] cleared ${stale.length} stale relay file(s) predating the turn`,
      );
    }
    return;
  }
}

/** The loop's wait outcome AT DISCOVERY time, for the stage=relay_pickup line. */
type RelayWakeTag = "activity" | "timeout" | "closed" | "poll";

/**
 * Runner-side relay loop. Sweeps pre-turn residue, then polls the sandbox relay dir
 * for request files, executes each against the private spec in memory, and writes the
 * response file the in-sandbox extension is waiting on. Returns `ready` (resolves once
 * the stale sweep settled — the caller must not allow a legitimate request before
 * then) and `stop()` to end the loop and drain any in-flight executions; call it once
 * the prompt resolves.
 */
export function startToolRelay(
  host: RelayHost,
  relayDir: string,
  specs: ResolvedToolSpec[],
  callback: ToolCallbackContext | undefined,
  runContext?: RunContext,
  clientToolRelay?: ClientToolRelay,
  guard?: RelayExecutionGuard,
  opts?: {
    log?: (msg: string) => void;
    writePausedAnswer?: boolean;
    /** Runs after the guard, for every harness. See `RelayExecutionAuthorizer`. */
    authorizer?: RelayExecutionAuthorizer;
    /** The run's private compiled gateway policy. Absent when the agent configures none. */
    gatewayPolicy?: GatewayPolicy;
    /** The pause-capable gateway gate. Absent means a gateway call fails closed. */
    gatewayGate?: GatewayToolGate;
  },
): { ready: Promise<void>; stop: () => Promise<void> } {
  let active = true;
  const log = opts?.log ?? (() => {});
  // Single switch between the two pause outcomes; defaults OFF so an un-flagged caller keeps Pi's
  // write-no-answer behavior.
  const writePausedAnswer = opts?.writePausedAnswer ?? false;
  // Telemetry gate: without a log sink there is nowhere for pickup_ms to go, so the
  // stat (a daemon round-trip on Daytona) is skipped entirely.
  const telemetry = opts?.log !== undefined;
  const seen = new Set<string>();
  // One memory per relay, which is one per turn. Measurement only; see `GatewaySearchMemory`.
  const gatewayMemory: GatewaySearchMemory = { offered: [], searches: 0 };
  // Validate the whole policy once per turn, not once per decision: every consumer takes the
  // normalized value, so an entry with broken routing, or a permission that is not one of the
  // three, cannot be reached from anywhere. See `normalizeGatewayPolicy`.
  const gatewaySeam: GatewaySeam = {
    policy: normalizeGatewayPolicy(opts?.gatewayPolicy),
    gate: opts?.gatewayGate,
    memory: gatewayMemory,
  };
  // Request names whose delete-on-pickup remove rejected: retried (best-effort,
  // concurrently) on each later list pass until the listing no longer shows them, so
  // a lingering picked-up file cannot insta-wake watch windows forever.
  const removeFailed = new Set<string>();
  const inflight: Promise<void>[] = [];
  const specsByName = toolSpecsByName(specs);

  const writeResponse = async (
    id: string,
    res: RelayResponse,
  ): Promise<void> => {
    try {
      // Atomic publication (plan decision 2): full bytes under a temp name, then a
      // same-directory rename to the final name the in-sandbox writer waits on.
      const finalResPath = `${relayDir}/${id}${RELAY_RES_SUFFIX}`;
      const tmpResPath = relayTempPath(finalResPath);
      await host.write(tmpResPath, JSON.stringify(res));
      await host.rename(tmpResPath, finalResPath);
    } catch {
      // The extension will time out and surface a tool error; nothing else to do here.
    }
  };

  // Execute phase: runs in the background (pushed to `inflight`); the loop never
  // waits on it. Parses, executes against the private spec, and publishes the
  // response (or the error) the in-sandbox writer is waiting on.
  const execute = async (id: string, raw: string): Promise<void> => {
    let res: RelayResponse;
    try {
      const req = JSON.parse(raw) as RelayRequest;
      const spec = specsByName.get(req.toolName);
      if (!spec) throw new Error(`unknown tool '${req.toolName}'`);
      const text = await executeRelayedTool(
        spec,
        { ...req, toolCallId: req.toolCallId ?? id },
        callback,
        runContext,
        clientToolRelay,
        guard,
        opts?.authorizer,
        gatewaySeam,
        opts?.log,
      );
      if (text instanceof RelayRefusal) {
        // `ok: false` is what makes every transport call this an error. The in-sandbox client
        // throws on it and the MCP shim turns that into `isError: true` with the reason, so the
        // model reads a refusal as a refusal rather than as an empty success.
        res = { ok: false, error: text.reason };
      } else if (text === PAUSED) {
        // A client tool parked. Pi writes no answer; the non-Pi shim gets a benign paused answer so
        // it ends its blocking `tools/call` at once instead of waiting out the per-tool timeout and
        // emitting a late error frame (see ClientToolPauseDisposition).
        if (!writePausedAnswer) return;
        res = { ok: true, paused: true };
      } else {
        res = { ok: true, text };
      }
    } catch (err) {
      res = {
        ok: false,
        error: err instanceof Error ? err.message : String(err),
      };
    }
    await writeResponse(id, res);
  };

  // Pickup phase: read the request file, then clear it from the dir. The loop AWAITS
  // every pickup before its next wait (fix 3 of the slice-3 review), so a watch exec
  // can never arm while a picked-up request file still exists on disk — the window
  // would insta-complete on it and rearm at network speed for the whole execution.
  // The execute phase above starts as soon as the read returns; only read+stat+remove
  // gate the loop.
  const pickup = async (reqName: string, wake: RelayWakeTag): Promise<void> => {
    const id = reqName.slice(0, -RELAY_REQ_SUFFIX.length);
    const reqPath = `${relayDir}/${reqName}`;
    let raw: string;
    try {
      raw = await host.read(reqPath);
    } catch (err) {
      // Nothing was picked up; surface the read failure as the tool's response so the
      // in-sandbox writer fails fast instead of waiting out its timeout.
      inflight.push(
        writeResponse(id, {
          ok: false,
          error: err instanceof Error ? err.message : String(err),
        }),
      );
      return;
    }
    // stage=relay_pickup telemetry: the stat is STARTED before the remove (afterwards
    // the file is gone and the stat can only miss); both then run concurrently. Clock
    // caveat: on Daytona the mtime is sandbox-clock while `Date.now()` is
    // runner-clock, so pickup_ms is approximate — good for QA latency distributions,
    // not billing. Cost: one stat per executed request, and none at all without a log
    // sink (see `telemetry` above).
    let statPromise: Promise<number | undefined> | undefined;
    if (telemetry && host.statMtimeMs) {
      try {
        statPromise = host.statMtimeMs(reqPath).catch(() => undefined);
      } catch {
        statPromise = undefined;
      }
    }
    // Delete-on-pickup: remove the request file BEFORE the next watch window can arm
    // (the loop awaits this pickup). This deliberately ends
    // crash-redelivery-by-re-listing — a request is executed at most once per
    // publication, consistent with the stale-sweep decision (a restarted turn must
    // not re-execute stale requests; the writer times out and surfaces a tool error
    // instead). A failed removal is recorded for retry on later list passes.
    const removeDone = removeRelayFile(host, reqPath).then((removed) => {
      if (!removed) removeFailed.add(reqName);
    });
    // The execute phase starts NOW (as soon as the read returned) and runs in the
    // background; the pickup itself only awaits stat + remove.
    inflight.push(execute(id, raw));
    const mtimeMs = statPromise ? await statPromise : undefined;
    log(
      `[relay] stage=relay_pickup id=${id} pickup_ms=${
        mtimeMs === undefined ? -1 : Date.now() - mtimeMs
      } wake=${wake}`,
    );
    await removeDone;
  };

  // Loop-owned safety bound (fix 6 of the slice-3 review): the plan's 30 s pickup
  // bound must hold even if a wait() implementation wedges, so every wait races a
  // timer slightly past its own timeout. The timer is cleared as soon as the race
  // settles, so nothing leaks and nothing outlives the loop.
  const boundedWait = async (
    activitySource: RelayActivitySource,
    timeoutMs: number,
  ): Promise<"activity" | "timeout" | "closed"> => {
    let timer: ReturnType<typeof setTimeout> | undefined;
    const bound = new Promise<"timeout">((resolve) => {
      timer = setTimeout(() => resolve("timeout"), timeoutMs + 1_000);
    });
    try {
      return await Promise.race([activitySource.wait({ timeoutMs }), bound]);
    } finally {
      clearTimeout(timer);
    }
  };

  // Hop 2 wake source (plan decision 3). Undefined (no capability, or the remote watch
  // flag is off, or fs.watch failed) leaves the loop below byte-for-byte today's poll.
  const source = host.createActivitySource?.(relayDir);

  // Stale sweep FIRST (fix 1 of the slice-3 review): the old "first successful list
  // is the snapshot" raced the resume flow — on Daytona the snapshot ls exec's READ
  // time is unordered against respondPermission, so a resume's approved request could
  // land first and be swallowed, and a transiently rejecting first list deferred the
  // snapshot behind later, legitimate requests. Now the sweep runs before the
  // discovery loop, and `ready` lets the engine hold respondPermission/prompt until
  // it settles — so nothing legitimate can predate the sweep, and after it EVERY
  // listed request is legitimate.
  const ready = sweepStaleRelayFiles(host, relayDir, log);

  const loop = (async () => {
    // The discovery loop starts only after the sweep settled (see `ready` above).
    await ready.catch(() => {});
    // Idle-poll backoff: a quiet turn (e.g. waiting on a browser-fulfilled client-tool pause)
    // grows the delay up to RELAY_POLL_MAX_MS instead of polling at 300 ms forever; any new
    // request resets it. This cuts the remote `ls` rate on Daytona without delaying a real call.
    let idlePolls = 0;
    let lastWaitOutcome: "activity" | "timeout" | "closed" | undefined;
    try {
      while (active) {
        let sawNew = false;
        // This iteration's pickup phases (and remove retries): all awaited below,
        // BEFORE the next wait, so no watch window arms over a lingering file.
        const pickups: Promise<void>[] = [];
        try {
          const names = await host.list(relayDir);
          // Retry earlier failed delete-on-pickup removals until gone from the listing.
          for (const name of [...removeFailed]) {
            if (!names.includes(name)) {
              removeFailed.delete(name);
              continue;
            }
            pickups.push(
              removeRelayFile(host, `${relayDir}/${name}`).then((removed) => {
                if (removed) removeFailed.delete(name);
              }),
            );
          }
          for (const name of names) {
            if (!name.endsWith(RELAY_REQ_SUFFIX) || seen.has(name)) continue;
            seen.add(name);
            sawNew = true;
            pickups.push(pickup(name, lastWaitOutcome ?? "poll"));
          }
        } catch {
          // Transient (dir not created yet, or a poll raced sandbox teardown): retry.
        }
        if (pickups.length > 0) await Promise.allSettled(pickups);
        // A safety-poll ("timeout") wake that FOUND work while the suspended watch
        // claimed healthy is a watch miss (plan decision 4): it feeds demotion.
        if (
          sawNew &&
          source?.suspendsPolling &&
          source.isHealthy() &&
          lastWaitOutcome === "timeout"
        ) {
          source.noteMiss?.();
        }
        idlePolls = sawNew ? 0 : idlePolls + 1;
        if (source && source.isHealthy() && source.suspendsPolling) {
          // Healthy remote watch: the watch exec's completion is the wake; the remote
          // poll is suspended and only the 30 s safety poll remains (plan decision 6).
          lastWaitOutcome = await boundedWait(source, RELAY_SAFETY_POLL_MS);
        } else if (source && source.isHealthy()) {
          // Local watch: shortens the sleep only; the poll cadence is unchanged.
          lastWaitOutcome = await boundedWait(
            source,
            relayPollDelayMs(idlePolls),
          );
        } else {
          // Classic loop, byte for byte (no source, demoted, or closed).
          await sleep(relayPollDelayMs(idlePolls));
          lastWaitOutcome = undefined;
        }
      }
    } finally {
      // No timer or watcher may outlive the loop, however it exits.
      source?.close();
    }
    await Promise.allSettled(inflight);
  })();

  return {
    ready,
    stop: async () => {
      active = false;
      // Close before awaiting the loop so a held 30 s safety-poll wait resolves
      // ("closed") immediately instead of pinning stop() on its timer.
      source?.close();
      await loop.catch(() => {});
    },
  };
}
