"""The platform-op catalog: existing Agenta endpoints exposed to the agent as tools.

A platform tool (``type:"platform"``) is a thin wrapper over an EXISTING Agenta endpoint. The
agent config names which endpoint to expose (``op``); this catalog owns everything else — the
model-facing description, which endpoint to call (method + relative path), the request input
schema, any self-targeting fields bound from run context, and the default permission/approval.

It mirrors two patterns already in the codebase:

- the reserved ``tools.agenta.*`` namespace: a reserved op id
  under ``tools.agenta.<op>`` with a code-defined description + input schema;
- the evaluators catalog (``api/oss/src/resources/evaluators/evaluators.py``): a code-defined
  table of named ops with metadata, validated at import.

Execution reuses the ``call`` descriptor (direct-call tools): a platform tool resolves to a
:class:`~agenta.sdk.agents.tools.CallbackToolSpec` whose ``call`` points the runner straight at
the existing endpoint, with no ``/tools/call`` hop. The ``PlatformConnection`` (see
``platform/connection.py``) supplies the origin the runner resolves the relative path against and
the caller credential. Input schemas reuse the in-process ``CATALOG_TYPES`` mechanism via
``x-ag-type-ref`` (resolved by :func:`expand_type_refs`); descriptions live here, in the SDK.

Lives under ``platform/`` (not ``tools/``) for the same reason as ``_schema.py``: it imports
``CATALOG_TYPES``, which would be circular from a ``tools`` module but is fine from the lazily
imported platform package.
"""

from __future__ import annotations

from copy import deepcopy
from typing import Any, Dict, List, Literal, Optional

from pydantic import BaseModel, ConfigDict, Field, model_validator

from agenta.sdk.agents.flags import ORDERED_OPERATIONS_ENV, ordered_operations_enabled
from agenta.sdk.agents.tools.errors import UnknownPlatformOpError
from agenta.sdk.agents.tools.models import ToolCall
from agenta.sdk.utils.types import CATALOG_TYPES

from ._schema import expand_type_refs

__all__ = [
    "PLATFORM_OP_NAMESPACE",
    "PlatformOp",
    "PLATFORM_OPS",
    "get_platform_op",
]

# Reserved namespace for a platform op's stable id.
# The model-visible tool name is the bare ``op``; ``reserved_id`` is the stable namespaced id.
PLATFORM_OP_NAMESPACE = "tools.agenta."

# Every ``context_bindings`` value addresses the run-context namespace through this token prefix
# (e.g. ``$ctx.workflow.variant.id``); the runner resolves it at dispatch (see ``RunContext``).
_CTX_TOKEN_PREFIX = "$ctx."

# Exact allowlist of handler call-refs a handler-mode op may target. Must match the
# server's registered handlers (``PLATFORM_TOOL_HANDLERS`` in the API's
# ``core/tools/platform_handlers.py``); an op naming anything else fails at import.
_HANDLER_CALL_REFS = frozenset(
    {
        f"{PLATFORM_OP_NAMESPACE}test_run",
        f"{PLATFORM_OP_NAMESPACE}read_config",
        f"{PLATFORM_OP_NAMESPACE}commit_revision",
    }
)

# The ephemeral per-call description (R12). The model writes it, the frontend shows it beside
# the call, and the runner deletes it before it builds the request. It is NOT the commit message:
# ``message`` describes the change in the revision history and is persisted; this describes the
# call in the conversation and is never persisted. It is also NOT the persisted
# ``RevisionCommit.description``, which the model never sets. See
# ``docs/design/agent-config-editing/contracts/read-config.md`` section 12.
EPHEMERAL_DESCRIPTION_ARG = "description"

# Long enough for one or two sentences of intent, short enough that it can never become a payload
# channel. The frontend truncates for display and shows that it truncated.
EPHEMERAL_DESCRIPTION_MAX_LENGTH = 500

_EPHEMERAL_DESCRIPTION_SCHEMA: Dict[str, Any] = {
    "type": "string",
    "maxLength": EPHEMERAL_DESCRIPTION_MAX_LENGTH,
    "description": (
        "Optional. One or two sentences saying what this call does and why. The user sees it "
        "beside the call. It is not saved with the change; use the commit message for that."
    ),
}


# Marks a property as the ephemeral note wherever it appears. The runner reads the advertised
# schema to decide whether a nested `description` is the endpoint's own field or a misplaced note;
# once the tolerated position is advertised, the name alone can no longer tell those apart. The
# marker keeps that decision machine-readable instead of hard-coding a tool name in the runner.
EPHEMERAL_MARKER = "x-ag-ephemeral"


def _tolerated_description_schema() -> Dict[str, Any]:
    """The ephemeral description in its SECOND position, inside a payload object.

    Models put the note here, the payload objects are closed, and the call is rejected before
    anything runs. Advertising the position costs nothing and removes a whole class of wasted
    turn. The wording says what happens to it, so a model cannot read the tolerance as a place
    to store something.
    """
    return {
        "type": "string",
        "maxLength": EPHEMERAL_DESCRIPTION_MAX_LENGTH,
        EPHEMERAL_MARKER: True,
        "description": (
            "Optional. The same per-call note as the top-level `description`, also accepted "
            "here. It is lifted to the top level and never saved. Prefer the top level."
        ),
    }


def _tolerate_description(payload: Dict[str, Any]) -> None:
    """Advertise the ephemeral note inside one closed payload object.

    A payload that declares a REAL ``description`` of its own is left alone. Four platform ops
    carry one (``create_schedule`` and friends) and none of them accepts the ephemeral note
    today, but that is an accident of the current catalog rather than an invariant, and
    overwriting a real field would delete content the human meant to send.
    """
    if payload.get("type") != "object":
        return
    fields = payload.get("properties")
    if not isinstance(fields, dict) or EPHEMERAL_DESCRIPTION_ARG in fields:
        return
    fields[EPHEMERAL_DESCRIPTION_ARG] = _tolerated_description_schema()


def _ephemeral_description_schema(siblings: List[str]) -> Dict[str, Any]:
    """The ephemeral description field, told where it goes.

    Models nest this field inside the payload object, and the envelope is closed, so the
    call is rejected and the turn is spent recovering. Live QA hit that twice in a row.

    The sentence names the op's OWN top-level keys rather than one hard-coded key, because
    the two ops that take this field have different payloads. It is generated, so renaming
    a payload key cannot leave the placement advice pointing at a key that is gone.
    """
    schema = deepcopy(_EPHEMERAL_DESCRIPTION_SCHEMA)
    if siblings:
        named = ", ".join(f"`{name}`" for name in siblings)
        # It no longer forbids the nested position, because the nested position is now
        # accepted and lifted. Advice the schema contradicts teaches a model nothing.
        schema["description"] = (
            f"{schema['description']} Send it at the top level, beside {named}."
        )
    return schema


class PlatformOp(BaseModel):
    """One catalog entry: an existing Agenta endpoint exposed to the agent as a tool.

    Typed (not a loose dict) so each entry is validated at import: exactly one schema source, a
    relative path, and well-formed ``$ctx`` context-binding tokens.
    """

    model_config = ConfigDict(extra="forbid", frozen=True)

    op: str = Field(
        min_length=1, description="Stable op key; the model-visible tool name."
    )
    description: str = Field(
        min_length=1, description="Model-facing description (SDK-owned)."
    )
    method: Optional[Literal["GET", "POST", "PUT", "DELETE"]] = None
    # An EXISTING Agenta endpoint, as a path relative to the API origin (e.g. ``/api/tools/discover``).
    # The runner binds the origin to the run's own Agenta and confines the path to the API mount.
    path: Optional[str] = Field(default=None, min_length=1)
    # A server-side handler call-ref in the reserved Agenta namespace. Handler-mode ops still go
    # through `/tools/call`, but the business logic lives behind the registered Python handler.
    handler: Optional[str] = Field(default=None, min_length=1)
    # Exactly one of the two below. ``input_schema`` is an inline JSON Schema (SDK-owned); it MAY
    # carry ``x-ag-type-ref`` markers, expanded against ``CATALOG_TYPES`` at resolve time.
    # ``input_schema_ref`` names a whole catalog type by key (the endpoint's request schema).
    input_schema: Optional[Dict[str, Any]] = None
    input_schema_ref: Optional[str] = None
    # Self-targeting fields the runner fills server-side from run context: a dotted body path on the
    # endpoint's request -> a ``$ctx.<key>`` token. These are stripped from the model-visible schema
    # and emitted as ``call.context`` so the model supplies only the payload and can never retarget.
    context_bindings: Dict[str, str] = Field(default_factory=dict)
    # Where the model's args land in the request body (a dotted deep-set path; absent = the root).
    args_into: Optional[str] = None
    # Catalog hint for the runner's ``allow_reads`` policy; no hint counts as a write.
    read_only: bool = False
    # Per-op execution budget for long-running server-side handlers. Emitted as `timeoutMs`.
    timeout_ms: Optional[int] = Field(default=None, gt=0)
    # Builder ops opt in to the ephemeral per-call ``description`` (R12). The model writes one
    # sentence saying what this call does and why; the frontend shows it beside the call. The
    # runner strips it before it builds the request, so no endpoint schema changes. Off by
    # default: an op that does not show its calls to a human gains nothing from it.
    accepts_description: bool = False

    @model_validator(mode="after")
    def _check(self) -> "PlatformOp":
        if (self.input_schema is None) == (self.input_schema_ref is None):
            raise ValueError(
                f"platform op '{self.op}' must set exactly one of "
                "`input_schema` or `input_schema_ref`"
            )
        if (
            self.input_schema_ref is not None
            and self.input_schema_ref not in CATALOG_TYPES
        ):
            raise ValueError(
                f"platform op '{self.op}' input_schema_ref '{self.input_schema_ref}' "
                "is not a known CATALOG_TYPES key"
            )

        has_direct_target = self.method is not None or self.path is not None
        has_handler_target = self.handler is not None
        if has_direct_target == has_handler_target:
            raise ValueError(
                f"platform op '{self.op}' must set exactly one of "
                "`method` + `path` or `handler`"
            )
        if has_direct_target and (self.method is None or self.path is None):
            raise ValueError(
                f"platform op '{self.op}' must set both `method` and `path` "
                "for endpoint mode"
            )
        if self.path is not None and (
            not self.path.startswith("/") or self.path.startswith("//")
        ):
            raise ValueError(
                f"platform op '{self.op}' path '{self.path}' must be a relative path "
                "starting with a single '/'"
            )
        if self.handler is not None and self.handler not in _HANDLER_CALL_REFS:
            raise ValueError(
                f"platform op '{self.op}' handler '{self.handler}' is not allowlisted"
            )

        for field, token in self.context_bindings.items():
            if not field:
                raise ValueError(
                    f"platform op '{self.op}' has an empty context-binding field"
                )
            if not token.startswith(_CTX_TOKEN_PREFIX):
                raise ValueError(
                    f"platform op '{self.op}' context binding '{field}' must map to a "
                    f"'$ctx.<key>' token, got '{token}'"
                )
        return self

    @property
    def reserved_id(self) -> str:
        """The stable reserved id, ``tools.agenta.<op>``."""
        return f"{PLATFORM_OP_NAMESPACE}{self.op}"

    @property
    def ephemeral_args(self) -> Optional[List[str]]:
        """Top-level argument names the runner must delete before it builds the request.

        These are model-authored fields that exist for the human, not for the endpoint. Returning
        them on the spec keeps ONE list: the schema that offers the field and the strip that
        removes it cannot drift apart.
        """
        return [EPHEMERAL_DESCRIPTION_ARG] if self.accepts_description else None

    def resolved_input_schema(self) -> Dict[str, Any]:
        """The concrete, model-visible input schema.

        Catalog schema with every ``x-ag-type-ref`` expanded to concrete JSON Schema, then with the
        server-bound ``context_bindings`` fields stripped (path-aware, including their ``required``
        entries) so the model never sees a field the runner fills from run context. A builder op
        then gains the optional ephemeral ``description`` at the TOP level, beside the op's own
        payload object, because it describes the call and not the payload.
        """
        if self.input_schema_ref is not None:
            schema = expand_type_refs({"x-ag-type-ref": self.input_schema_ref})
        else:
            schema = expand_type_refs(deepcopy(self.input_schema))
        if not isinstance(
            schema, dict
        ):  # defensive; catalog schemas are always objects
            return schema
        for field in self.context_bindings:
            _strip_field(schema, field)
        if self.accepts_description:
            # The catalog schemas are closed (``additionalProperties: false``), so the field must
            # be advertised or the model cannot send it at all. It is never required: an agent
            # that says nothing is quieter, not broken.
            properties = schema.setdefault("properties", {})
            if isinstance(properties, dict):
                payloads = [
                    name
                    for name, field in properties.items()
                    if name != EPHEMERAL_DESCRIPTION_ARG and isinstance(field, dict)
                ]
                # The sibling names are read before the field is added, so the placement
                # sentence lists the payload keys and not itself.
                properties[EPHEMERAL_DESCRIPTION_ARG] = _ephemeral_description_schema(
                    payloads
                )
                for name in payloads:
                    _tolerate_description(properties[name])
        return schema

    def to_call(self) -> ToolCall:
        """The direct ``call`` descriptor for endpoint-mode ops."""
        if self.method is None or self.path is None or self.handler is not None:
            raise ValueError(f"platform op '{self.op}' is not an endpoint-mode op")
        return ToolCall(
            method=self.method,
            path=self.path,
            context=dict(self.context_bindings) or None,
            args_into=self.args_into,
        )

    def to_call_ref(self) -> str:
        """The reserved ``callRef`` for handler-mode ops."""
        if self.handler is None:
            raise ValueError(f"platform op '{self.op}' is not a handler-mode op")
        return self.handler


def _strip_field(schema: Dict[str, Any], dotted_path: str) -> None:
    """Delete the property at ``dotted_path`` from a JSON Schema's ``properties`` tree, in place,
    and drop it from the enclosing ``required`` list. Ancestor objects left empty by the removal
    are pruned too, so the model never sees a hollow required container (e.g. ``target`` once its
    only field is context-bound). A path that does not resolve is a no-op."""
    parts = dotted_path.split(".")
    node: Any = schema
    stack: list[tuple[Dict[str, Any], str]] = []
    for part in parts[:-1]:
        properties = node.get("properties") if isinstance(node, dict) else None
        if not isinstance(properties, dict) or part not in properties:
            return
        stack.append((node, part))
        node = properties[part]
    if not isinstance(node, dict):
        return
    leaf = parts[-1]
    properties = node.get("properties")
    if isinstance(properties, dict):
        properties.pop(leaf, None)
    required = node.get("required")
    if isinstance(required, list) and leaf in required:
        required.remove(leaf)
        if not required:
            node.pop("required", None)

    while stack and _is_empty_object_schema(node):
        parent, part = stack.pop()
        parent_props = parent.get("properties")
        if isinstance(parent_props, dict):
            parent_props.pop(part, None)
        parent_required = parent.get("required")
        if isinstance(parent_required, list) and part in parent_required:
            parent_required.remove(part)
            if not parent_required:
                parent.pop("required", None)
        node = parent


def _is_empty_object_schema(node: Any) -> bool:
    if not isinstance(node, dict):
        return False
    properties = node.get("properties")
    return isinstance(properties, dict) and not properties and not node.get("required")


# ---------------------------------------------------------------------------
# Typed `delta.set` for the agent-template subtree (`parameters.agent`).
# ---------------------------------------------------------------------------
#
# `commit_revision` / `test_run` carry a `delta.set` deep-partial that deep-merges onto the running
# revision. Without a shape the tool schema advertised to the model (Claude via the runner's
# tools/list, Pi via its extension) says nothing about `parameters.agent`. These helpers give it the
# real `agent-template` shape — the same catalog type the playground renders — adapted for a delta.


def _deep_partial_schema(node: Any) -> Any:
    """Return ``node`` with every JSON-Schema ``required`` array recursively removed.

    A delta is a DEEP PARTIAL: ``delta.set`` deep-merges onto the current config, so every field is
    optional in a delta even when the source model marks it required. Embedding the strict
    ``agent-template`` schema verbatim would tell the model that each ``required`` field must appear
    in every delta (e.g. that a `skills` entry must carry ``name``/``description``/``body`` just to
    tweak one field), which is wrong. So we drop the ``required`` constraint everywhere while keeping
    the descriptive shape (``properties``, ``type``, ``enum``, ``additionalProperties``,
    descriptions, ...). A ``required`` array is always a list of property names in JSON Schema; the
    ``isinstance(value, list)`` guard means a property that happens to be *named* ``required`` (a
    dict value) is preserved. Pure: the input is never mutated."""
    if isinstance(node, list):
        return [_deep_partial_schema(item) for item in node]
    if not isinstance(node, dict):
        return node
    return {
        key: _deep_partial_schema(value)
        for key, value in node.items()
        if not (key == "required" and isinstance(value, list))
    }


# One `tools`/`skills`/`mcps` list entry may be an ``@ag.embed`` reference (the default template's
# build-kit embeds) rather than a fully-typed item. Because the model re-sends the WHOLE list when
# editing (wholesale replacement, per the commit_revision description), the item schema must accept
# the embed shape too, or a schema-following harness would drop or mangle the embed on the way back.
_EMBED_ITEM_SCHEMA: Dict[str, Any] = {
    "type": "object",
    "additionalProperties": True,
    "properties": {
        "@ag.embed": {
            "type": "object",
            "additionalProperties": True,
            "description": "The embed reference body (@ag.references / @ag.selector).",
        }
    },
    "description": (
        "an unresolved platform embed — copy it through unchanged when re-sending the list"
    ),
}


def _is_embed_branch(branch: Any) -> bool:
    return (
        isinstance(branch, dict)
        and isinstance(branch.get("properties"), dict)
        and "@ag.embed" in branch["properties"]
    )


def _embed_tolerant_items(items: Any) -> Dict[str, Any]:
    """Return a list-item schema that accepts the typed shape OR an ``@ag.embed`` object.

    Adds the embed alternative to the item schema's ``anyOf`` (flattening rather than nesting when
    the item is already a union), and is a no-op when an embed branch is already present, so the
    tools/skills items — whose source models already include the embed arm — are not duplicated."""
    embed = deepcopy(_EMBED_ITEM_SCHEMA)
    if isinstance(items, dict) and isinstance(items.get("anyOf"), list):
        branches = items["anyOf"]
        if any(_is_embed_branch(branch) for branch in branches):
            return items
        merged = dict(items)
        merged["anyOf"] = [*branches, embed]
        return merged
    return {"anyOf": [items, embed]}


def _build_agent_template_delta_schema() -> Dict[str, Any]:
    """The ``agent-template`` schema shaped for a delta: type-refs expanded, deep-partialed, and
    with embed-tolerant ``tools``/``skills``/``mcps`` list items.

    Type-refs (e.g. the inline ``skill-template`` arm) are expanded FIRST so the deep-partial pass
    also strips the referenced types' ``required`` arrays; expanding again at
    :meth:`PlatformOp.resolved_input_schema` time is then a no-op (idempotent)."""
    schema = _deep_partial_schema(
        expand_type_refs(deepcopy(CATALOG_TYPES["agent-template"]))
    )
    properties = schema.get("properties")
    if isinstance(properties, dict):
        for field in ("tools", "skills", "mcps"):
            field_schema = properties.get(field)
            if isinstance(field_schema, dict) and "items" in field_schema:
                field_schema["items"] = _embed_tolerant_items(field_schema["items"])
    return schema


# Built once at import from the catalog's `agent-template` type (the same source the playground
# renders), so the tool schema and the editor never drift.
_AGENT_TEMPLATE_DELTA_SCHEMA: Dict[str, Any] = _build_agent_template_delta_schema()


def _delta_set_schema(description: str) -> Dict[str, Any]:
    """A `delta.set` object schema: still an open object (other revision-data keys allowed), but
    with a typed `parameters.agent` = the deep-partial, embed-tolerant agent-template shape."""
    return {
        "type": "object",
        "additionalProperties": True,
        "description": description,
        "properties": {
            "parameters": {
                "type": "object",
                "additionalProperties": True,
                "description": (
                    "Workflow revision parameters. Put agent-template edits under `agent`."
                ),
                "properties": {"agent": deepcopy(_AGENT_TEMPLATE_DELTA_SCHEMA)},
            }
        },
    }


# ---------------------------------------------------------------------------
# The catalog — the first, minimal-useful set of ops (more are a data add).
# ---------------------------------------------------------------------------

# Discovery (read). Direct call to ``POST /api/tools/discover``. Description + input schema
# mirror ``api/oss/src/core/tools/discovery.py`` (copied here because the SDK must not import
# from the API).
_DISCOVER_TOOLS_DESCRIPTION = (
    "Discover the Agenta tools that fit a set of plain-language use cases. Returns the "
    "best-match tool per use case (with its input schema), companion/alternative tools, "
    "each integration's connection state, and operating guidance. Use it while wiring tools: "
    "the result tells you which INTEGRATION covers each use case, and you add that whole "
    "integration as ONE gateway_connection tool entry — never one entry per action. At run "
    "time the agent reaches every action of it through search_tools and run_tool. When an "
    "integration's state is ready, the slug it returns IS the connection slug to commit; "
    "otherwise you get a connect affordance whose slug does not exist yet. Only ever commit a "
    "slug that came back ready — an invented or not-yet-created slug commits cleanly and "
    "fails at run time as connection-not-found."
)
_DISCOVER_TOOLS_INPUT_SCHEMA: Dict[str, Any] = {
    "type": "object",
    "properties": {
        "use_cases": {
            "type": "array",
            "items": {"type": "string"},
            "description": "One short fragment per capability the agent needs "
            "(e.g. 'create a github issue').",
        },
        "provider": {
            "type": "string",
            "default": "composio",
            "description": "Tool provider to search.",
        },
        "limit_alternatives": {
            "type": "integer",
            "default": 3,
            "minimum": 0,
            "description": "Max alternative tools to return per use case.",
        },
    },
    "required": ["use_cases"],
}

# Workflows query (read): list the project's workflow artifacts, so an agent building or improving
# agents can find what already exists. Filters mirror ``WorkflowQueryRequest`` (all optional).
_QUERY_WORKFLOWS_DESCRIPTION = (
    "Query the project's workflow artifacts (agents, prompts) with optional filters and "
    "pagination. Use it to find existing workflows before creating or referencing one."
)
_QUERY_WORKFLOWS_INPUT_SCHEMA: Dict[str, Any] = {
    "type": "object",
    "properties": {
        "workflow": {
            "type": "object",
            "description": "Attribute filter on workflow artifacts "
            "(flags, tags, meta, name, description).",
        },
        "workflow_refs": {
            "type": "array",
            "items": {"type": "object"},
            "description": "Restrict results to workflows matching these references (id or slug).",
        },
        "include_archived": {
            "type": "boolean",
            "description": "When true, include archived workflows.",
        },
        "windowing": {
            "type": "object",
            "description": "Cursor-based pagination controls (pass `next` back for the next page).",
        },
    },
}

# Spans query (read): inspect trace/span records for this project. Project scope comes from the
# caller credential on the existing endpoint; there is no model-supplied project id and no $ctx
# target field to bind.
_QUERY_SPANS_DESCRIPTION = (
    "Query span records in this project. Use it to verify a past run or scheduled trigger fire "
    "actually executed its tools. Returns `{count, spans}` with flat spans, including span names, "
    "status, attributes, events, and Agenta metrics. Filter by `trace_id` when you know it, or "
    "bracket the test with `windowing.oldest`/`windowing.newest`; then read the tool-call spans "
    "in order and confirm the terminal span completed without an error status."
)
_QUERY_SPANS_INPUT_SCHEMA: Dict[str, Any] = {
    "type": "object",
    "additionalProperties": False,
    "$defs": {
        "ComparisonOperator": {
            "type": "string",
            "enum": ["is", "is_not"],
        },
        "NumericOperator": {
            "type": "string",
            "enum": ["eq", "neq", "gt", "lt", "gte", "lte", "btwn"],
        },
        "StringOperator": {
            "type": "string",
            "enum": ["startswith", "endswith", "contains", "matches", "like"],
        },
        "DictOperator": {
            "type": "string",
            "enum": ["has", "has_not"],
        },
        "ListOperator": {
            "type": "string",
            "enum": ["in", "not_in"],
        },
        "ExistenceOperator": {
            "type": "string",
            "enum": ["exists", "not_exists"],
        },
        "LogicalOperator": {
            "type": "string",
            "enum": ["and", "or", "not", "nand", "nor"],
        },
        "TextOptions": {
            "type": "object",
            "additionalProperties": False,
            "properties": {
                "case_sensitive": {
                    "anyOf": [{"type": "boolean"}, {"type": "null"}],
                    "default": False,
                },
                "exact_match": {
                    "anyOf": [{"type": "boolean"}, {"type": "null"}],
                    "default": False,
                },
            },
        },
        "ListOptions": {
            "type": "object",
            "additionalProperties": False,
            "properties": {
                "all": {
                    "anyOf": [{"type": "boolean"}, {"type": "null"}],
                    "default": False,
                }
            },
        },
        "Condition": {
            "type": "object",
            "additionalProperties": False,
            "properties": {
                "field": {
                    "type": "string",
                    "description": (
                        "Span field to filter, such as `trace_id`, `span_name`, "
                        "`span_type`, `status_code`, `attributes`, or `content`."
                    ),
                },
                "key": {
                    "anyOf": [{"type": "string"}, {"type": "null"}],
                    "default": None,
                    "description": (
                        "Optional nested key when filtering dictionary fields like "
                        "`attributes`."
                    ),
                },
                "value": {
                    "anyOf": [
                        {"type": "string"},
                        {"type": "integer"},
                        {"type": "number"},
                        {"type": "boolean"},
                        {"type": "array", "items": {}},
                        {"type": "object", "additionalProperties": True},
                        {"type": "null"},
                    ],
                    "default": None,
                    "description": "Comparison value for the condition.",
                },
                "operator": {
                    "anyOf": [
                        {"$ref": "#/$defs/ComparisonOperator"},
                        {"$ref": "#/$defs/NumericOperator"},
                        {"$ref": "#/$defs/StringOperator"},
                        {"$ref": "#/$defs/ListOperator"},
                        {"$ref": "#/$defs/DictOperator"},
                        {"$ref": "#/$defs/ExistenceOperator"},
                        {"type": "null"},
                    ],
                    "default": "is",
                },
                "options": {
                    "anyOf": [
                        {"$ref": "#/$defs/TextOptions"},
                        {"$ref": "#/$defs/ListOptions"},
                        {"type": "null"},
                    ],
                    "default": None,
                },
            },
            "required": ["field"],
        },
        "Filtering": {
            "type": "object",
            "additionalProperties": False,
            "properties": {
                "operator": {
                    "$ref": "#/$defs/LogicalOperator",
                    "default": "and",
                    "description": "How to combine conditions.",
                },
                "conditions": {
                    "type": "array",
                    "items": {
                        "anyOf": [
                            {"$ref": "#/$defs/Condition"},
                            {"$ref": "#/$defs/Filtering"},
                        ]
                    },
                    "default": [],
                    "description": (
                        "Filter objects, for example "
                        '`[{"field": "trace_id", "operator": "is", "value": "..."}]`.'
                    ),
                },
            },
        },
        "Windowing": {
            "type": "object",
            "additionalProperties": False,
            "properties": {
                "newest": {
                    "anyOf": [
                        {"type": "string", "format": "date-time"},
                        {"type": "null"},
                    ],
                    "default": None,
                    "description": "Window end time as an ISO timestamp.",
                },
                "oldest": {
                    "anyOf": [
                        {"type": "string", "format": "date-time"},
                        {"type": "null"},
                    ],
                    "default": None,
                    "description": "Window start time as an ISO timestamp.",
                },
                "next": {
                    "anyOf": [
                        {"type": "string", "format": "uuid"},
                        {"type": "null"},
                    ],
                    "default": None,
                    "description": "Cursor token returned by a prior query page.",
                },
                "limit": {
                    "anyOf": [{"type": "integer"}, {"type": "null"}],
                    "default": None,
                    "description": "Maximum spans to return.",
                },
                "order": {
                    "anyOf": [
                        {"type": "string", "enum": ["ascending", "descending"]},
                        {"type": "null"},
                    ],
                    "default": None,
                    "description": "Sort order for the window.",
                },
                "interval": {
                    "anyOf": [{"type": "integer"}, {"type": "null"}],
                    "default": None,
                    "description": "Positive bucket interval for aggregate query windows.",
                },
                "rate": {
                    "anyOf": [{"type": "number"}, {"type": "null"}],
                    "default": None,
                    "description": "Optional sampling rate between 0.0 and 1.0.",
                },
            },
        },
        "Reference": {
            "type": "object",
            "additionalProperties": False,
            "properties": {
                "version": {
                    "anyOf": [{"type": "string"}, {"type": "null"}],
                    "default": None,
                },
                "slug": {
                    "anyOf": [{"type": "string"}, {"type": "null"}],
                    "default": None,
                },
                "id": {
                    "anyOf": [
                        {"type": "string", "format": "uuid"},
                        {"type": "null"},
                    ],
                    "default": None,
                },
            },
        },
    },
    "properties": {
        "filtering": {
            "anyOf": [{"$ref": "#/$defs/Filtering"}, {"type": "null"}],
            "default": None,
            "description": (
                "Span-level conditions. For verification, filter on "
                '`{"field": "trace_id", "operator": "is", "value": "<trace_id>"}` '
                "when the trace id is known."
            ),
        },
        "windowing": {
            "anyOf": [{"$ref": "#/$defs/Windowing"}, {"type": "null"}],
            "default": None,
            "description": (
                "Cursor pagination and time range. Bracket manual verification with "
                "`oldest`/`newest` and set a sensible `limit`."
            ),
        },
        "query_ref": {
            "anyOf": [{"$ref": "#/$defs/Reference"}, {"type": "null"}],
            "default": None,
            "description": "Resolve filtering/windowing from a saved query.",
        },
        "query_variant_ref": {
            "anyOf": [{"$ref": "#/$defs/Reference"}, {"type": "null"}],
            "default": None,
            "description": "Resolve from the latest revision of a specific query variant.",
        },
        "query_revision_ref": {
            "anyOf": [{"$ref": "#/$defs/Reference"}, {"type": "null"}],
            "default": None,
            "description": (
                "Resolve from a specific query revision. Returns `409` when the stored query "
                "has `formatting.focus=trace`."
            ),
        },
    },
}

# Commit revision (mutating, self-targeting): commit a new revision to the agent's OWN workflow
# variant — "update myself". ``workflow_revision.workflow_variant_id`` is bound from run context
# and stripped from the model-visible schema, so the agent can only ever target itself, never a
# different variant in the project. Defaults to approval.
# One switch for the API and the model-facing catalog: the SDK runs inside the API
# process, so both read the same variable. The ordered shape is the default; the variable
# exists as an escape hatch back to the legacy `set`/`remove` surface.
# The switch itself lives in `agenta.sdk.agents.flags`, a leaf module, because the
# `build-an-agent` skill reads it too and an adapter cannot import this package (it reaches
# the SDK singleton). Re-exported under the private names this module has always used.
_ORDERED_OPERATIONS_ENV = ORDERED_OPERATIONS_ENV
_ordered_operations_enabled = ordered_operations_enabled


# The legacy description, for the flag-off surface. The wholesale-list sentence names the
# build-kit exception because the server REFUSES a commit that carries a platform-kind tool
# entry: telling the model to send its own build-kit tools back would earn that refusal.
_COMMIT_REVISION_DESCRIPTION_LEGACY = (
    "Commit a new revision to your own workflow variant (update yourself). "
    "Editing files in your workspace does not change your configuration. That copy is "
    "rebuilt, and the edits are lost. Change your instructions and configuration only "
    "through this tool. "
    "Send only the "
    "fields you are changing under `workflow_revision.delta.set` (deep-merged onto your "
    "current config) and any field paths to drop under `delta.remove`. Put agent-template "
    "edits under `delta.set.parameters.agent`. Lists such as `tools`, `skills`, and `mcps` "
    "are replaced wholesale, not merged entry-by-entry: send the complete list, meaning "
    "your current entries plus your change, or you wipe the rest. Leave the playground's "
    "own tools (commit_revision, test_run, read_config) OUT of that list: they are not "
    "part of your configuration, and a commit that carries one is refused. "
    "The variant you are running is targeted automatically. The response returns the new "
    "revision id; existing schedules and subscriptions keep pointing at the old revision "
    "until you re-point them. This changes the agent and requires approval."
)

# The normative tool description, contracts/change-set.md section 15. About 1.5 KB and 400
# tokens; the 3.2 KB version measured the same success rate and cost 11-13 percent more.
# It works BECAUSE three things hold: the wrapper normalizes the repeated-list mistake,
# every error names a next step, and the selector key is `list`.
_COMMIT_REVISION_DESCRIPTION_ORDERED = """Commit a change to this agent's own configuration.

Editing files in your workspace does not change your configuration. That copy is rebuilt,
and the edits are lost. Change your instructions and configuration only through this tool.

Send `workflow_revision` with `base_revision_id` (the `base_revision_id` you read) and
`delta`. `delta` holds `operations`; they run in order, and if one fails nothing is
committed.

TARGET: an array of segments from the configuration root. A string segment names an
object field. An object segment {"list": L, "key": K} names one entry of list L and
stands in place of L's name. Keyed lists: skills, mcps, tools (by name — but a
gateway_connection entry has no name and is keyed
gateway_connection:{provider}:{integration}, e.g. "gateway_connection:composio:github"),
files (by path).

    ["parameters","agent",{"list":"skills","key":"release-qa"},
     {"list":"files","key":"checklist.md"},"content"]

OPERATIONS:
- `set` replace one field (needs `value`)
- `merge` deep-merge an object into one field (needs `value`)
- `remove` delete one field
- `edit_text` replace exact substrings in one string field (needs `edits`)
- `add_item` append to a list; target ends with the list name (needs `value`)
- `replace_item` replace one entry; target ends with a selector (needs `value`)
- `remove_item` delete one entry; target ends with a selector

`edits` is a list of {old_text, new_text}. `old_text` must occur exactly once and match
character for character, line breaks included. Copy it from the configuration you read;
never retype it from memory.

For a workspace file's content, write {"@ag.file": "<path>"} where the string would go.
Put the file under `.agenta-imports/` first.

    {"operation":"add_item","target":["parameters","agent","skills"],
     "value":{"name":"pdf-tools","description":"Make PDFs.",
              "body":{"@ag.file":".agenta-imports/pdf-tools/SKILL.md"}}}

Your `tools` list must not contain the playground's own tools (commit_revision,
test_run, read_config). They are not part of your configuration.

If a commit is refused, read `next_step`: it says what to do, and it is there whether or not
the error is retryable. `retryable` only tells you whether sending the SAME call again could
work; it is false for most refusals, and that means correct the call rather than repeat
it."""

_COMMIT_REVISION_DESCRIPTION = (
    _COMMIT_REVISION_DESCRIPTION_ORDERED
    if _ordered_operations_enabled()
    else _COMMIT_REVISION_DESCRIPTION_LEGACY
)

_READ_CONFIG_DESCRIPTION = """Read your own configuration, or one part of it.

Send `target`, an object holding `path`: an array of segments from the configuration
root, the same shape `commit_revision` takes. Omit `path` to read everything you can
change.

    {"target": {"path": ["parameters","agent","llm"]}}
    {"target": {"path": ["parameters","agent",{"list":"skills","key":"release-qa"},"body"]}}

The response carries `base_revision_id`. Copy it into your next commit's `base_revision_id`.
If the head moved in between, the commit answers 409 and you read again.

Text comes back exactly as stored, so an `old_text` you copy from it will match. A value
larger than the limit is refused, never shortened: the answer then lists `children`, and
you read one of those instead."""

_READ_CONFIG_INPUT_SCHEMA: Dict[str, Any] = {
    "type": "object",
    "additionalProperties": False,
    "required": ["target"],
    "properties": {
        "target": {
            "type": "object",
            "additionalProperties": False,
            "properties": {
                # Bound from $ctx.workflow.variant.id and stripped before the model sees it.
                "workflow_variant_id": {
                    "type": "string",
                    "description": "Server-bound to the running variant; do not set.",
                },
                # Bound from $ctx.workflow.is_draft. It always resolves, so the call never
                # fails on an absent binding.
                "run_is_draft": {
                    "type": "boolean",
                    "description": "Server-bound; do not set.",
                },
                "path": {
                    "type": "array",
                    "maxItems": 12,
                    "items": {"$ref": "#/$defs/read_config_segment"},
                    "description": (
                        "Segments from the configuration root. Omit to read everything."
                    ),
                },
            },
        },
        "max_bytes": {
            "type": "integer",
            "minimum": 1024,
            "maximum": 262144,
            "description": "Largest answer to return before refusing. Default 65536.",
        },
    },
    "$defs": {
        "read_config_segment": {
            "oneOf": [
                {"type": "string", "minLength": 1},
                {
                    "type": "object",
                    "additionalProperties": False,
                    "required": ["list", "key"],
                    "properties": {
                        "list": {"type": "string", "minLength": 1},
                        "key": {"type": "string", "minLength": 1},
                    },
                },
            ]
        }
    },
}

_TARGET_SEGMENT_SCHEMA: Dict[str, Any] = {
    "oneOf": [
        {"type": "string", "minLength": 1},
        {
            "type": "object",
            "additionalProperties": False,
            "required": ["list", "key"],
            "properties": {
                "list": {"type": "string", "minLength": 1},
                "key": {"type": "string", "minLength": 1},
            },
        },
    ]
}

_OPERATION_SCHEMA: Dict[str, Any] = {
    "type": "object",
    "additionalProperties": False,
    "required": ["operation", "target"],
    "properties": {
        "operation": {
            "type": "string",
            "enum": [
                "set",
                "merge",
                "remove",
                "edit_text",
                "add_item",
                "replace_item",
                "remove_item",
            ],
        },
        "target": {
            "type": "array",
            "minItems": 1,
            "maxItems": 12,
            "items": _TARGET_SEGMENT_SCHEMA,
        },
        "value": {},
        "match_mode": {"type": "string", "enum": ["auto", "exact"], "default": "auto"},
        "edits": {
            "type": "array",
            "minItems": 1,
            "maxItems": 32,
            "items": {
                "type": "object",
                "additionalProperties": False,
                "required": ["old_text", "new_text"],
                "properties": {
                    "old_text": {"type": "string", "minLength": 1, "maxLength": 20000},
                    "new_text": {"type": "string", "maxLength": 50000},
                },
            },
        },
    },
}
_COMMIT_REVISION_INPUT_SCHEMA: Dict[str, Any] = {
    "type": "object",
    "additionalProperties": False,
    "properties": {
        "workflow_revision": {
            "type": "object",
            "additionalProperties": False,
            "description": "The revision to append to your variant's history.",
            "properties": {
                # Bound from $ctx.workflow.variant.id and stripped before the model sees it.
                "workflow_variant_id": {
                    "type": "string",
                    "description": "Server-bound to the running variant; do not set.",
                },
                # Flag-off only. With ordered operations on, the server derives the
                # message from the operations: free text was the site of every measured
                # argument-corruption failure, and a derived message is always accurate.
                **(
                    {}
                    if _ordered_operations_enabled()
                    else {
                        "message": {
                            "type": "string",
                            "description": "Commit message describing the change.",
                        }
                    }
                ),
                **(
                    {
                        "base_revision_id": {
                            "type": "string",
                            "description": (
                                "The base_revision_id you read. Required for `operations`."
                            ),
                        }
                    }
                    if _ordered_operations_enabled()
                    else {}
                ),
                # ONE delta arm is model-visible per deployment. With ordered operations on,
                # `set` and `remove` leave this schema: a model that sees both picks a
                # different arm from call to call, which is what made the approval cards
                # inconsistent on one stack. The API still accepts the legacy form, so
                # shipped callers are unaffected; this is the catalog surface only.
                "delta": {
                    "type": "object",
                    "additionalProperties": False,
                    "description": (
                        "Ordered operations applied to your current revision, in array "
                        "order. If one fails, nothing is committed."
                        if _ordered_operations_enabled()
                        else "Change set applied to your current revision. `set` is "
                        "deep-merged (omitted fields preserved); `remove` deletes the "
                        "listed paths."
                    ),
                    "properties": (
                        {
                            "operations": {
                                "type": "array",
                                "minItems": 1,
                                "maxItems": 64,
                                "items": _OPERATION_SCHEMA,
                                "description": (
                                    "Ordered operations, applied in array order."
                                ),
                            }
                        }
                        if _ordered_operations_enabled()
                        else {
                            "set": _delta_set_schema(
                                "Partial workflow revision data to merge. For "
                                "agent-template updates, include parameters.agent with "
                                "instructions, llm, tools, mcps, skills, harness, runner, "
                                "or sandbox fields as needed."
                            ),
                            "remove": {
                                "type": "array",
                                "items": {"type": "string"},
                                "description": (
                                    "Dotted field paths to delete, e.g. "
                                    "parameters.agent.tools."
                                ),
                            },
                        }
                    ),
                },
            },
            # `base_revision_id` is required WITH the ordered arm, and the schema has to say
            # so: the server refuses an ordered delta that omits it, and a model reading only
            # a prose sentence sends the call anyway and spends the turn on the refusal.
            # `workflow_variant_id` is bound from run context and stripped from this list
            # along with the property, so the model never sees it required.
            "required": (
                ["workflow_variant_id", "base_revision_id", "delta"]
                if _ordered_operations_enabled()
                else ["workflow_variant_id", "delta"]
            ),
        },
    },
    "required": ["workflow_revision"],
}

# Annotate trace (mutating, self-targeting): record an annotation (evaluation feedback) on the
# agent's OWN current run trace — "grade myself". ``annotation.links.invocation.trace_id`` /
# ``.span_id`` are bound from run context ($ctx.trace.*) so the agent always annotates its own run
# and can never retarget another trace (the same self-targeting guarantee ``commit_revision`` gives
# via $ctx.workflow.variant.id). Unlike ``commit_revision``, this is additive self-metadata (it does
# not mutate the agent's config) — but it IS a write (``read_only=False``), so under the default
# ``allow_reads`` policy it prompts unless the author sets an explicit ``allow``.
_ANNOTATE_TRACE_DESCRIPTION = (
    "Record an annotation (evaluation feedback) on your own current run's trace — grade "
    "yourself. Supply `references.evaluator.slug` naming the annotation category (e.g. "
    "'self_reflection', 'quality') and the `data.outputs` you are recording (scores, "
    "labels, notes). Reuse a stable slug across runs: a new slug auto-creates a simple "
    "evaluator in your project. The trace and span you annotate are your own current run, "
    "filled automatically — you cannot annotate a different trace."
)
_ANNOTATE_TRACE_INPUT_SCHEMA: Dict[str, Any] = {
    "type": "object",
    # Closed so the model cannot smuggle `links` past the self-target binding
    # ($ctx.trace.trace_id / .span_id); only the cataloged fields are accepted.
    "additionalProperties": False,
    "properties": {
        "references": {
            "type": "object",
            "additionalProperties": False,
            "description": "What this annotation evaluates against.",
            "properties": {
                "evaluator": {
                    "type": "object",
                    "additionalProperties": False,
                    "description": (
                        "Names the annotation category. Auto-created as a simple "
                        "evaluator if the slug is new, so reuse a stable slug."
                    ),
                    "properties": {
                        "slug": {
                            "type": "string",
                            "description": "Stable evaluator slug, e.g. 'self_reflection'.",
                        }
                    },
                    "required": ["slug"],
                }
            },
            "required": ["evaluator"],
        },
        "data": {
            "type": "object",
            "additionalProperties": False,
            "description": "The annotation payload.",
            "properties": {
                "outputs": {
                    "type": "object",
                    "additionalProperties": True,
                    "description": (
                        "The annotation content you are recording (scores, labels, notes)."
                    ),
                }
            },
            "required": ["outputs"],
        },
        # links.invocation.{trace_id,span_id} are bound from run context ($ctx.trace.*) and
        # never model-supplied; see context_bindings on the op below.
    },
    "required": ["references", "data"],
}

_DISCOVER_TRIGGERS_DESCRIPTION = (
    "Find trigger events (external happenings that can start this agent) for "
    "plain-language use cases. Returns the best-match event per use case with "
    "event_key, trigger_config schema, sample payload, connection state and "
    "connection instructions, plus close alternatives. Matching is keyword search "
    "over the provider catalog, not semantic: always confirm the returned "
    "integration and event description actually fit the use case before wiring an "
    "event_key. When nothing matches confidently, the closest events are returned "
    "in alternatives with a note; if the integration you asked about never appears, "
    "the provider has no triggers for it. To browse an integration, pass its name "
    "alone as the use case (e.g. 'slack') and raise limit_alternatives (e.g. to 20): "
    "results are always capped by limit_alternatives, so never treat the returned "
    "list as complete."
)
_DISCOVER_TRIGGERS_INPUT_SCHEMA: Dict[str, Any] = {
    "type": "object",
    "properties": {
        "use_cases": {
            "type": "array",
            "items": {"type": "string"},
            "description": "One short fragment per trigger the agent needs, naming "
            "the integration and the event (e.g. 'new github issue created', "
            "'slack channel message received'). An integration name alone returns "
            "its closest events, capped by limit_alternatives.",
        },
        "provider": {
            "type": "string",
            "default": "composio",
            "description": "Trigger provider to search.",
        },
        "limit_alternatives": {
            "type": "integer",
            "default": 3,
            "minimum": 0,
            "description": "Max alternative events to return per use case. Raise it "
            "(e.g. to 20) when browsing an integration's catalog.",
        },
    },
    "required": ["use_cases"],
}

_TRIGGER_INPUTS_FIELDS_SCHEMA: Dict[str, Any] = {
    "description": (
        "Template mapping the fire-time context into run inputs. A leaf string starting "
        "with `$` resolves as a JSON Path against the fire context, one starting with `/` "
        "resolves as a JSON Pointer, and any other leaf passes through literally — "
        "selectors are never interpolated into a larger string, and an unmatched selector "
        "resolves to null. Omit this field to pass the whole fire context through as-is. "
        "Canonical pattern: include an explicit imperative `messages` entry and map the "
        'event payload under a sibling key, e.g. `{"messages": [{"role": "user", '
        '"content": "Handle this event."}], "payload": "$.event.attributes"}`.'
    ),
    "anyOf": [
        {"type": "object", "additionalProperties": True},
        {"type": "string"},
    ],
}

_CREATE_SCHEDULE_DESCRIPTION = (
    "Create a cron schedule that runs this agent. The destination workflow is bound "
    "from the current run context, so only this agent can be scheduled. When no revision "
    "is specified, the schedule binds to the variant's latest revision at creation time "
    "and does not follow later commits. Requires approval."
)
_CREATE_SCHEDULE_INPUT_SCHEMA: Dict[str, Any] = {
    "type": "object",
    # Closed so the model cannot smuggle `references` / `selector` past the self-target
    # binding ($ctx.workflow.variant.id); only the cataloged fields are accepted.
    "additionalProperties": False,
    "properties": {
        "name": {"type": "string", "description": "Human label for the schedule."},
        "description": {"type": "string"},
        "data": {
            "type": "object",
            "additionalProperties": False,
            "properties": {
                "event_key": {
                    "type": "string",
                    "description": "Label recorded on each schedule delivery.",
                },
                "schedule": {
                    "type": "string",
                    "description": "Five-field cron expression in UTC.",
                },
                "start_time": {
                    "type": "string",
                    "format": "date-time",
                    "description": "Optional UTC start of the active window.",
                },
                "end_time": {
                    "type": "string",
                    "format": "date-time",
                    "description": "Optional UTC end of the active window.",
                },
                "inputs_fields": _TRIGGER_INPUTS_FIELDS_SCHEMA,
            },
            "required": ["event_key", "schedule"],
        },
    },
    "required": ["data"],
}

_CREATE_SUBSCRIPTION_DESCRIPTION = (
    "Create an event subscription that runs this agent when a provider event occurs. "
    "The destination workflow is bound from the current run context. When no revision is "
    "specified, the subscription binds to the variant's latest revision at creation time "
    "and does not follow later commits. Requires approval."
)
_CREATE_SUBSCRIPTION_INPUT_SCHEMA: Dict[str, Any] = {
    "type": "object",
    # Closed so the model cannot smuggle `references` / `selector` past the self-target
    # binding ($ctx.workflow.variant.id); only the cataloged fields are accepted.
    "additionalProperties": False,
    "properties": {
        "name": {"type": "string", "description": "Human label for the subscription."},
        "description": {"type": "string"},
        "connection_id": {
            "type": "string",
            "description": "Ready trigger connection id for the event source.",
        },
        "data": {
            "type": "object",
            "additionalProperties": False,
            "properties": {
                "event_key": {
                    "type": "string",
                    "description": "Provider event key returned by discover_triggers.",
                },
                "trigger_config": {
                    "type": "object",
                    "description": "Event parameters shaped by the event trigger_config schema.",
                },
                "inputs_fields": _TRIGGER_INPUTS_FIELDS_SCHEMA,
            },
            "required": ["event_key"],
        },
    },
    "required": ["connection_id", "data"],
}

_TEST_SUBSCRIPTION_DESCRIPTION = (
    "Open a temporary provider watch, wait for one real matching event, record it as a "
    "test delivery, and tear the watch down. It does not run the workflow. Requires approval."
)
_TEST_SUBSCRIPTION_INPUT_SCHEMA: Dict[str, Any] = {
    "type": "object",
    "properties": {
        "name": {"type": "string", "description": "Optional label for the test watch."},
        "connection_id": {
            "type": "string",
            "description": "Ready trigger connection id for the event source.",
        },
        "data": {
            "type": "object",
            "properties": {
                "event_key": {
                    "type": "string",
                    "description": "Provider event key returned by discover_triggers.",
                },
                "trigger_config": {
                    "type": "object",
                    "description": "Event parameters shaped by the event trigger_config schema.",
                },
            },
            "required": ["event_key"],
        },
    },
    "required": ["connection_id", "data"],
}

_TEST_RUN_DESCRIPTION = (
    "Run this agent headlessly once against test messages and return its output, tools, "
    "approval gates, resolved execution metadata, trace id, and verdict. The target workflow "
    "variant is filled automatically from the current run context and cannot be retargeted. "
    "This is a real run: external write tools may perform their action if approved. Verdict "
    "is one of `pass` (the expected terminal tool ran and returned output), `incomplete` "
    "(the run finished without ever invoking the expected terminal tool), `unconfirmed` "
    "(no terminal tool was expected, or the terminal tool was dispatched but never returned "
    "a result — most often a gated call stalled waiting for approval), or `failed` (a tool "
    "returned an error, or the run itself failed to execute). A tool name appearing in the "
    "executed list is not proof it completed."
)
_TEST_RUN_INPUT_SCHEMA: Dict[str, Any] = {
    "type": "object",
    "additionalProperties": False,
    "properties": {
        "target": {
            "type": "object",
            "additionalProperties": False,
            "properties": {
                "workflow_variant_id": {
                    "type": "string",
                    "description": "Server-bound current workflow variant id.",
                }
            },
            "required": ["workflow_variant_id"],
        },
        "inputs": {
            "type": "object",
            "additionalProperties": False,
            "properties": {
                "messages": {
                    "x-ag-type-ref": "messages",
                    "description": "Test conversation messages for the headless run.",
                }
            },
            "required": ["messages"],
        },
        "delta": {
            "type": "object",
            "additionalProperties": False,
            "description": "Optional uncommitted revision delta to apply in memory before the test.",
            "properties": {
                "set": _delta_set_schema(
                    "Partial revision data tree deep-merged onto the committed revision."
                ),
                "remove": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Dotted paths to delete from the revision data tree.",
                },
            },
        },
        "expectations": {
            "type": "object",
            "additionalProperties": False,
            "description": "Optional checks that define a passing test run.",
            "properties": {
                "terminal_tool": {
                    "type": "string",
                    "description": (
                        "Expected final/terminal tool name that must run and return. For "
                        "a gateway integration this is run_tool — the agent reaches every "
                        "action through search_tools/run_tool — never a provider action "
                        "name such as GITHUB_CREATE_AN_ISSUE."
                    ),
                }
            },
        },
    },
    "required": ["target", "inputs"],
}

_RENAME_SESSION_DESCRIPTION = """Name and describe the session you are running in, so a person scanning a long list of sessions can tell what this one is. Call it once you understand what the session is about, which is usually after the first exchange. Call it again later whenever the session has moved on and the name or the recap no longer fits.

`name` is the general subject: what this session is about, as a short label a person can scan in a list. A few words. Not the latest step, and not a sentence.

`description` is the current state: a short recap of what has happened and what is open, one to one and a half sentences, short enough to read inside a table cell.

This renames the session you are in and no other one. It works only inside a session."""

_RENAME_SESSION_INPUT_SCHEMA: Dict[str, Any] = {
    "type": "object",
    "additionalProperties": False,
    "properties": {
        "name": {
            "type": "string",
            "minLength": 1,
            "maxLength": 120,
            "pattern": r"\S",
        },
        "description": {
            "type": "string",
            "maxLength": 300,
        },
    },
    "required": ["name"],
}

_RENAME_AGENT_DESCRIPTION = """Name and describe yourself, so a person browsing the list of agents can tell what you are for. Call it once you understand your own purpose, which is usually right after your first task. Call it again if your purpose changes.

`name` is what you are for, as a short label a person can scan in a list. A few words.

`description` is what you do and where you currently stand, one to one and a half sentences, short enough to read inside a table cell.

This renames the agent you are running as and no other one. It changes only your name and your description, never your configuration."""

_RENAME_AGENT_INPUT_SCHEMA: Dict[str, Any] = {
    "type": "object",
    "additionalProperties": False,
    "properties": {
        "name": {
            "type": "string",
            "minLength": 1,
            "maxLength": 120,
            "pattern": r"\S",
        },
        "description": {
            "type": "string",
            "maxLength": 300,
        },
    },
    "required": ["name"],
}

_EMPTY_INPUT_SCHEMA: Dict[str, Any] = {"type": "object", "properties": {}}
_TRIGGER_ID_INPUT_SCHEMA: Dict[str, Any] = {
    "type": "object",
    "properties": {
        "id": {
            "type": "string",
            "description": "The schedule or subscription id returned by the list tools.",
        }
    },
    "required": ["id"],
}


# `read_config` and ordered operations are one feature: the read-then-edit loop. The flag
# gates both, so a deployment never advertises the read without the write it feeds.
_READ_CONFIG_OPS: tuple = (
    (
        PlatformOp(
            op="read_config",
            description=_READ_CONFIG_DESCRIPTION,
            # Handler mode: the logic runs behind a registered handler in the API process,
            # reached through the generic `/tools/call`. There is no public read-config
            # endpoint any more, because every detail of it was agent-shaped and no second
            # consumer existed.
            handler=f"{PLATFORM_OP_NAMESPACE}read_config",
            input_schema=_READ_CONFIG_INPUT_SCHEMA,
            context_bindings={
                "target.workflow_variant_id": "$ctx.workflow.variant.id",
                "target.run_is_draft": "$ctx.workflow.is_draft",
            },
            read_only=True,
            timeout_ms=15000,
            accepts_description=True,
        ),
    )
    if _ordered_operations_enabled()
    else ()
)


PLATFORM_OPS: Dict[str, PlatformOp] = {
    op.op: op
    for op in _READ_CONFIG_OPS
    + (
        PlatformOp(
            op="discover_tools",
            description=_DISCOVER_TOOLS_DESCRIPTION,
            method="POST",
            path="/api/tools/discover",
            input_schema=_DISCOVER_TOOLS_INPUT_SCHEMA,
            read_only=True,
        ),
        PlatformOp(
            op="query_workflows",
            description=_QUERY_WORKFLOWS_DESCRIPTION,
            method="POST",
            path="/api/workflows/query",
            input_schema=_QUERY_WORKFLOWS_INPUT_SCHEMA,
            read_only=True,
        ),
        PlatformOp(
            op="query_spans",
            description=_QUERY_SPANS_DESCRIPTION,
            method="POST",
            path="/api/spans/query",
            input_schema=_QUERY_SPANS_INPUT_SCHEMA,
            read_only=True,
        ),
        PlatformOp(
            op="rename_session",
            description=_RENAME_SESSION_DESCRIPTION,
            method="POST",
            path="/api/sessions/streams/header?session_id={session_id}",
            input_schema=_RENAME_SESSION_INPUT_SCHEMA,
            context_bindings={"session_id": "$ctx.session.id"},
            read_only=False,
        ),
        PlatformOp(
            op="rename_agent",
            description=_RENAME_AGENT_DESCRIPTION,
            method="PUT",
            path="/api/workflows/{workflow_id}",
            input_schema=_RENAME_AGENT_INPUT_SCHEMA,
            args_into="workflow",
            context_bindings={
                "workflow_id": "$ctx.workflow.artifact.id",
                "workflow.id": "$ctx.workflow.artifact.id",
            },
            read_only=False,
        ),
        PlatformOp(
            op="test_run",
            description=_TEST_RUN_DESCRIPTION,
            handler="tools.agenta.test_run",
            input_schema=_TEST_RUN_INPUT_SCHEMA,
            context_bindings={"target.workflow_variant_id": "$ctx.workflow.variant.id"},
            read_only=False,
            timeout_ms=120000,
            # A builder op: the playground shows every one of its calls to the human who is
            # building the agent, so the agent's own account of the call is worth showing (R12).
            accepts_description=True,
        ),
        PlatformOp(
            op="commit_revision",
            description=_COMMIT_REVISION_DESCRIPTION,
            # Handler mode. The confinement to `parameters.agent` is a property of the
            # HANDLER now rather than of a scoped route, and it is unforgeable for the same
            # reason it was before: the call_ref comes from this catalog, the runner makes
            # the call from outside the sandbox, and the sandbox holds no credential. There
            # is no field an agent can set to reach an unscoped commit.
            handler=f"{PLATFORM_OP_NAMESPACE}commit_revision",
            input_schema=_COMMIT_REVISION_INPUT_SCHEMA,
            context_bindings={
                "workflow_revision.workflow_variant_id": "$ctx.workflow.variant.id"
            },
            read_only=False,
            accepts_description=True,
        ),
        PlatformOp(
            op="annotate_trace",
            description=_ANNOTATE_TRACE_DESCRIPTION,
            method="POST",
            path="/api/annotations/",
            input_schema=_ANNOTATE_TRACE_INPUT_SCHEMA,
            context_bindings={
                "annotation.links.invocation.trace_id": "$ctx.trace.trace_id",
                "annotation.links.invocation.span_id": "$ctx.trace.span_id",
            },
            args_into="annotation",
            read_only=False,
        ),
        PlatformOp(
            op="discover_triggers",
            description=_DISCOVER_TRIGGERS_DESCRIPTION,
            method="POST",
            path="/api/triggers/discover",
            input_schema=_DISCOVER_TRIGGERS_INPUT_SCHEMA,
            read_only=True,
        ),
        PlatformOp(
            op="create_schedule",
            description=_CREATE_SCHEDULE_DESCRIPTION,
            method="POST",
            path="/api/triggers/schedules/",
            input_schema=_CREATE_SCHEDULE_INPUT_SCHEMA,
            context_bindings={
                "schedule.data.references.workflow_variant.id": "$ctx.workflow.variant.id"
            },
            args_into="schedule",
            read_only=False,
        ),
        PlatformOp(
            op="create_subscription",
            description=_CREATE_SUBSCRIPTION_DESCRIPTION,
            method="POST",
            path="/api/triggers/subscriptions/",
            input_schema=_CREATE_SUBSCRIPTION_INPUT_SCHEMA,
            context_bindings={
                "subscription.data.references.workflow_variant.id": "$ctx.workflow.variant.id"
            },
            args_into="subscription",
            read_only=False,
        ),
        PlatformOp(
            op="list_schedules",
            description="List this project's trigger schedules.",
            method="GET",
            path="/api/triggers/schedules/",
            input_schema=_EMPTY_INPUT_SCHEMA,
            read_only=True,
        ),
        PlatformOp(
            op="list_subscriptions",
            description="List this project's trigger subscriptions.",
            method="GET",
            path="/api/triggers/subscriptions/",
            input_schema=_EMPTY_INPUT_SCHEMA,
            read_only=True,
        ),
        PlatformOp(
            op="list_deliveries",
            description="List trigger delivery logs so the agent can inspect recent fires and tests.",
            method="GET",
            path="/api/triggers/deliveries",
            input_schema=_EMPTY_INPUT_SCHEMA,
            read_only=True,
        ),
        PlatformOp(
            op="list_connections",
            description=(
                "List this project's provider connections, with their real slugs. Use it "
                "for a trigger connection_id, and to get the ready connection slug for a "
                "gateway_connection tool entry."
            ),
            method="POST",
            path="/api/triggers/connections/query",
            input_schema=_EMPTY_INPUT_SCHEMA,
            read_only=True,
        ),
        PlatformOp(
            op="test_subscription",
            description=_TEST_SUBSCRIPTION_DESCRIPTION,
            method="POST",
            path="/api/triggers/subscriptions/test",
            input_schema=_TEST_SUBSCRIPTION_INPUT_SCHEMA,
            args_into="subscription",
            read_only=False,
        ),
        PlatformOp(
            op="remove_schedule",
            description="Delete a trigger schedule by id. Requires approval.",
            method="DELETE",
            path="/api/triggers/schedules/{id}",
            input_schema=_TRIGGER_ID_INPUT_SCHEMA,
            read_only=False,
        ),
        PlatformOp(
            op="remove_subscription",
            description="Delete a trigger subscription by id. Requires approval.",
            method="DELETE",
            path="/api/triggers/subscriptions/{id}",
            input_schema=_TRIGGER_ID_INPUT_SCHEMA,
            read_only=False,
        ),
        PlatformOp(
            op="pause_schedule",
            description="Pause a trigger schedule without deleting it. Requires approval.",
            method="POST",
            path="/api/triggers/schedules/{id}/stop",
            input_schema=_TRIGGER_ID_INPUT_SCHEMA,
            read_only=False,
        ),
        PlatformOp(
            op="resume_schedule",
            description="Resume a paused trigger schedule. Requires approval.",
            method="POST",
            path="/api/triggers/schedules/{id}/start",
            input_schema=_TRIGGER_ID_INPUT_SCHEMA,
            read_only=False,
        ),
        PlatformOp(
            op="pause_subscription",
            description="Pause a trigger subscription without deleting it. Requires approval.",
            method="POST",
            path="/api/triggers/subscriptions/{id}/stop",
            input_schema=_TRIGGER_ID_INPUT_SCHEMA,
            read_only=False,
        ),
        PlatformOp(
            op="resume_subscription",
            description="Resume a paused trigger subscription. Requires approval.",
            method="POST",
            path="/api/triggers/subscriptions/{id}/start",
            input_schema=_TRIGGER_ID_INPUT_SCHEMA,
            read_only=False,
        ),
    )
}


def get_platform_op(op: str) -> PlatformOp:
    """Look up a catalog op by key, raising :class:`UnknownPlatformOpError` if it is not defined."""
    try:
        return PLATFORM_OPS[op]
    except KeyError:
        raise UnknownPlatformOpError(op=op, available=sorted(PLATFORM_OPS)) from None
