import type {WorkspaceRole} from "@agenta/entities/organization"
import {updateOrganization} from "@agenta/entities/organization"
import {updateWorkspace, fetchAllWorkspaceRoles} from "@agenta/entities/organization"
import {message} from "@agenta/ui/app-message"
import {atom} from "jotai"
import {atomWithMutation, atomWithQuery} from "jotai-tanstack-query"

import {selectedOrgQueryAtom, orgsQueryAtom} from "../../org/selectors/org"
import {userAtom} from "../../profile/selectors/user"
import {projectIdAtom} from "../../project/selectors/project"

/**
 * Mutation atom for updating workspace name
 * Handles both workspace and organization updates, plus cache invalidation
 */
export const updateWorkspaceNameAtom = atomWithMutation<
    void,
    {organizationId: string; workspaceId: string; name: string}
>((get) => ({
    mutationKey: ["updateWorkspaceName"],
    mutationFn: async ({organizationId, workspaceId, name}) => {
        // Update both workspace and organization in parallel
        await Promise.all([
            updateWorkspace({organizationId, workspaceId, name}),
            // typed as-is (latent bug): sends the bare name string, not {name}, as the PATCH body
            updateOrganization(organizationId, name as unknown as {name: string}),
        ])
    },
    onSuccess: (_, {name, organizationId}) => {
        // Show success message
        message.success("Workspace renamed")

        // Optimistically update the local cache with the new name
        const selectedOrgQuery = get(selectedOrgQueryAtom)

        // Also trigger a refetch to ensure data consistency
        if (selectedOrgQuery.refetch) {
            selectedOrgQuery.refetch()
        }

        // Refetch orgs list to ensure sidebar and org lists reflect the new name
        const orgsQuery = get(orgsQueryAtom)
        if (orgsQuery.refetch) {
            orgsQuery.refetch()
        }
    },
    onError: (error) => {
        console.error("Failed to update workspace name:", error)
        message.error("Failed to rename workspace")
    },
}))

/**
 * Action atom for updating workspace name with UI state management
 * This handles the complete flow including UI state updates
 */
export const updateWorkspaceNameActionAtom = atom(
    null,
    async (
        get,
        _set,
        {
            organizationId,
            workspaceId,
            name,
            onSuccess,
        }: {
            organizationId: string
            workspaceId: string
            name: string
            onSuccess?: () => void
        },
    ) => {
        try {
            // Execute the mutation using mutateAsync from the mutation atom
            const {mutateAsync} = get(updateWorkspaceNameAtom)
            await mutateAsync({organizationId, workspaceId, name})

            // Call success callback if provided
            if (onSuccess) {
                onSuccess()
            }
        } catch (error) {
            // Error handling is already done in the mutation atom
            throw error
        }
    },
)

/**
 * Query atom for fetching workspace roles
 * Fetches all available workspace roles for the application
 */
export const workspaceRolesQueryAtom = atomWithQuery<Omit<WorkspaceRole, "permissions">[]>(
    (get) => {
        const user = get(userAtom)
        const projectId = get(projectIdAtom)

        return {
            queryKey: ["workspaceRoles"],
            queryFn: () => fetchAllWorkspaceRoles(),
            staleTime: 1000 * 60 * 10, // 10 minutes - roles don't change often
            refetchOnWindowFocus: false,
            refetchOnReconnect: false,
            refetchOnMount: false,
            enabled: !!user?.id && !!projectId,
            retry: (failureCount, error) => {
                // Don't retry on client errors (404, etc.)
                if (
                    (error as any)?.response?.status >= 400 &&
                    (error as any)?.response?.status < 500
                ) {
                    return false
                }
                return failureCount < 2
            },
        }
    },
)
