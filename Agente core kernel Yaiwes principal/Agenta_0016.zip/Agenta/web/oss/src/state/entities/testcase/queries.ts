import {keepPreviousData} from "@tanstack/react-query"
import {atom} from "jotai"
import {atomWithQuery} from "jotai-tanstack-query"

import axios from "@/oss/lib/api/assets/axiosConfig"
import {getAgentaApiUrl} from "@/oss/lib/helpers/api"
import {projectIdAtom} from "@/oss/state/project/selectors/project"

// Import from specific testset files (NOT the barrel `../testset`) to avoid a
// circular dep: `testset/index.ts` re-exports `currentRevisionIdAtom` from this
// file (`testcase/queries.ts`). Loading the barrel here would create a cycle
// that surfaces as `Cannot access 'currentRevisionIdAtom' before initialization`
// in any standalone consumer that imports the testcase state graph (e.g. the
// design-mockups app under `web/apps/design-mockups/`).
import {revisionsListQueryAtomFamily} from "../testset/revisionEntity"
import type {Revision, RevisionListItem} from "../testset/revisionSchema"
import {fetchRevision, NEW_TESTSET_ID, testsetEntityAtomFamily} from "../testset/store"

import {flattenTestcase, testcasesResponseSchema, type FlattenedTestcase} from "./schema"

// ============================================================================
// REVISION CONTEXT ATOM
// Single source of truth for current revision ID (from URL)
// ============================================================================

/**
 * Current revision ID from URL - single source of truth
 * This atom is the canonical location for the current revision context.
 * Components set this from URL params, entity atoms read from it.
 */
export const currentRevisionIdAtom = atom<string | null>(null)

// ============================================================================
// QUERY ATOMS
// Uses API functions and context from testset module
// ============================================================================

/**
 * Revision data response type (re-export for backward compatibility)
 */
export type RevisionData = Revision

/**
 * Query atom for fetching revision metadata
 * Uses fetchRevision from testset module
 * For "draft" or "new" revision (new testsets), returns mock data without server query
 */
export const revisionQueryAtom = atomWithQuery<Revision | null>((get) => {
    const projectId = get(projectIdAtom)
    const revisionId = get(currentRevisionIdAtom)

    // For "draft" or "new" revision (new testsets), return mock revision without server query
    const isLocalOnly = revisionId === "draft" || revisionId === "new"

    return {
        queryKey: ["testset-revision", projectId, revisionId],
        queryFn: async () => {
            if (!projectId || !revisionId) return null
            if (isLocalOnly) {
                // Return mock revision for local-only testsets (client-side only)
                return {
                    id: revisionId,
                    testset_id: "",
                    version: 0,
                    name: "",
                    description: null,
                    created_at: new Date().toISOString(),
                    updated_at: new Date().toISOString(),
                } as Revision
            }
            return fetchRevision({id: revisionId, projectId})
        },
        enabled: Boolean(projectId && revisionId),
        // Revisions are immutable - never stale
        staleTime: Infinity,
        gcTime: Infinity,
        placeholderData: keepPreviousData,
    }
})

/**
 * Derived atom for testset ID from revision
 */
export const testsetIdAtom = atom((get) => {
    const revisionQuery = get(revisionQueryAtom)
    return revisionQuery.data?.testset_id ?? null
})

/**
 * Query atom for testset detail
 * Uses testset entity atom family which automatically fetches if not in cache
 * Testsets contain the name and description (updated directly via API)
 * For new testsets (revisionId="new"), uses the special "new" testset ID
 */
export const testsetDetailQueryAtom = atom((get) => {
    const revisionQuery = get(revisionQueryAtom)
    const currentRevisionId = get(currentRevisionIdAtom)
    const testsetId = revisionQuery.data?.testset_id

    // For new testsets, use the special "new" testset ID
    // This allows us to store/retrieve draft metadata for unsaved testsets
    const isNewTestset = currentRevisionId === "new" || currentRevisionId === "draft"
    const effectiveTestsetId = isNewTestset ? NEW_TESTSET_ID : testsetId

    if (!effectiveTestsetId) {
        return null
    }

    // Testset entity handles fetching automatically if not in cache
    // For "new" testsets, returns a mock entity that can be edited via draft
    return get(testsetEntityAtomFamily(effectiveTestsetId))
})

/**
 * Revision list item type (re-export for backward compatibility)
 */
export type {RevisionListItem} from "../testset"

/**
 * Query atom for fetching available revisions
 * Uses revisionsListQueryAtomFamily from testset entity module
 * This ensures revisions are hydrated into the entity cache
 */
export const revisionsListQueryAtom = atom((get) => {
    const testsetId = get(testsetIdAtom)
    if (!testsetId) {
        return {data: [] as RevisionListItem[], isPending: false, isError: false}
    }
    return get(revisionsListQueryAtomFamily(testsetId))
})

/**
 * Page size for testcases pagination
 */
export const PAGE_SIZE = 50

/**
 * Testcases page response type
 */
export interface TestcasesPage {
    testcases: FlattenedTestcase[]
    count: number
    nextCursor: string | null
    hasMore: boolean
}

/**
 * Fetch a page of testcases (used by useInfiniteQuery in hook)
 */
export async function fetchTestcasesPage(
    projectId: string,
    revisionId: string,
    cursor: string | null,
): Promise<TestcasesPage> {
    const response = await axios.post(
        `${getAgentaApiUrl()}/testcases/query`,
        {
            testset_revision_ref: {id: revisionId},
            windowing: {
                limit: PAGE_SIZE,
                ...(cursor && {next: cursor}),
            },
        },
        {params: {project_id: projectId}},
    )

    // Validate response with Zod
    const validated = testcasesResponseSchema.parse(response.data)

    // Flatten testcases for table display
    const flattenedTestcases = validated.testcases.map(flattenTestcase)

    return {
        testcases: flattenedTestcases,
        count: validated.count,
        nextCursor: validated.windowing?.next || null,
        hasMore: Boolean(validated.windowing?.next),
    }
}

// ============================================================================
// DERIVED METADATA ATOM
// Combines data from multiple query atoms into a single metadata object
// ============================================================================

/**
 * Testset metadata interface
 */
export interface TestsetMetadata {
    testsetId: string
    testsetName: string
    testsetSlug?: string
    revisionSlug?: string
    revisionVersion?: number
    description?: string
    commitMessage?: string
    author?: string
    createdAt?: string
    updatedAt?: string
}

/**
 * Derived atom: full metadata object from query atoms
 * Automatically updates when any query data changes
 * Triggers testset fetch to ensure entity is loaded
 *
 * NOTE: Name and description are read directly from the testset entity,
 * which is updated via the updateTestsetMetadata API (not through commits).
 * This ensures metadata changes are reflected immediately without creating new revisions.
 */
export const testsetMetadataAtom = atom((get): TestsetMetadata | null => {
    const revisionQuery = get(revisionQueryAtom)
    const testset = get(testsetDetailQueryAtom)
    const currentRevisionId = get(currentRevisionIdAtom)

    const revisionFromQuery = revisionQuery.data
    // For new testsets, testset_id is empty but we still want to show metadata
    const isNewTestset = currentRevisionId === "new" || currentRevisionId === "draft"
    if (!revisionFromQuery?.testset_id && !isNewTestset) return null

    // Name and description come directly from testset entity (updated via API, not commits)
    const effectiveName = testset?.name || ""
    const effectiveDescription = testset?.description || undefined

    return {
        testsetId: revisionFromQuery?.testset_id ?? "",
        testsetName: effectiveName,
        testsetSlug: undefined, // slug is not in current schema
        revisionSlug: revisionFromQuery?.slug ?? undefined,
        revisionVersion: revisionFromQuery?.version,
        description: effectiveDescription,
        commitMessage: revisionFromQuery?.message ?? undefined,
        author: revisionFromQuery?.author ?? undefined,
        createdAt: revisionFromQuery?.created_at ?? undefined,
        updatedAt: revisionFromQuery?.updated_at ?? undefined,
    }
})

/**
 * Loading state for all metadata queries
 */
export const metadataLoadingAtom = atom((get) => {
    const revisionQuery = get(revisionQueryAtom)
    // Testset entity doesn't have isPending - it's synchronously read from cache or null
    return revisionQuery.isPending
})

/**
 * Error state for metadata queries
 */
export const metadataErrorAtom = atom((get) => {
    const revisionQuery = get(revisionQueryAtom)
    // Testset entity doesn't expose error state directly
    return revisionQuery.error as Error | null
})
