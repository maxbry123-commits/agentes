import {useCallback} from "react"

import {playgroundController} from "@agenta/playground"
import {usePlaygroundLayout} from "@agenta/playground-ui/hooks"
import {DndContext, closestCenter, PointerSensor, useSensor, useSensors} from "@dnd-kit/core"
import {restrictToParentElement} from "@dnd-kit/modifiers"
import {arrayMove, SortableContext, verticalListSortingStrategy} from "@dnd-kit/sortable"
import {Typography} from "antd"
import clsx from "clsx"
import {useSetAtom} from "jotai"

import VariantNavigationCard from "./assets/VariantNavigationCard"
import type {PromptComparisonVariantNavigationProps} from "./types"

const PromptComparisonVariantNavigation = ({
    className,
    handleScroll,
    ...props
}: PromptComparisonVariantNavigationProps) => {
    const {displayedEntities} = usePlaygroundLayout()
    const setSelectedVariants = useSetAtom(playgroundController.actions.setEntityIds)

    const sensors = useSensors(
        useSensor(PointerSensor, {
            activationConstraint: {
                delay: 100,
                tolerance: 5,
                distance: 5,
            },
        }),
    )

    const handleDragEnd = useCallback(
        (event: any) => {
            const {active, over} = event

            if (over?.id && active.id && active.id !== over?.id) {
                // Use displayedEntities for indices since that's what SortableContext uses
                const currentRevisionIds = displayedEntities || []

                const oldIndex = currentRevisionIds.indexOf(active.id as string)
                const newIndex = currentRevisionIds.indexOf(over.id as string)

                if (oldIndex !== -1 && newIndex !== -1) {
                    // Reorder the array and update atom directly
                    // This preserves local drafts (writePlaygroundSelectionToQuery filters them out)
                    const reorderedRevisions = arrayMove(currentRevisionIds, oldIndex, newIndex)
                    setSelectedVariants(reorderedRevisions)
                }
            }
        },
        [displayedEntities, setSelectedVariants],
    )

    return (
        <div {...props} className={clsx([className, "z-[20]"])}>
            <div className="w-full h-[48px] flex items-center px-2 sticky top-0 z-10 bg-[var(--ag-c-FFFFFF)] border-0 border-b border-solid border-[var(--ag-rgba-051729-06)]">
                <Typography.Text>Variants</Typography.Text>
            </div>

            <div className="flex flex-col gap-3 p-3">
                <DndContext
                    sensors={sensors}
                    collisionDetection={closestCenter}
                    onDragEnd={handleDragEnd}
                    modifiers={[restrictToParentElement]}
                >
                    <SortableContext
                        items={displayedEntities || []}
                        strategy={verticalListSortingStrategy}
                    >
                        {displayedEntities?.map((variantId, idx) => (
                            <VariantNavigationCard
                                key={variantId}
                                id={variantId}
                                revisionId={variantId}
                                handleScrollClick={() => handleScroll(idx)}
                            />
                        ))}
                    </SortableContext>
                </DndContext>
            </div>
        </div>
    )
}

export default PromptComparisonVariantNavigation
