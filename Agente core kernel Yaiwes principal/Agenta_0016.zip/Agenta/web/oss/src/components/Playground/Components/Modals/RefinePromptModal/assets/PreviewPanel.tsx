/**
 * PreviewPanel - Right panel for previewing the refined prompt
 *
 * Shows:
 * - Editable message list (same as original prompt format)
 * - Or diff view when diff toggle is on (controlled by parent)
 *
 * The `promptVersion` prop is used as part of editor keys to force
 * remount when a new AI refinement result arrives (SharedEditor uses
 * initialValue and does not update reactively).
 */

import {useCallback, useMemo} from "react"

import {ChatMessageEditor} from "@agenta/ui/chat-message"
import {Typography} from "antd"
import {useAtom, useAtomValue} from "jotai"
import dynamic from "next/dynamic"

import {
    originalPromptSnapshotAtomFamily,
    refineDiffViewAtomFamily,
    workingPromptAtomFamily,
} from "../store/refinePromptStore"

const DiffView = dynamic(() => import("@agenta/ui/editor").then((module) => module.DiffView), {
    ssr: false,
})

interface PreviewPanelProps {
    promptKey: string
    promptVersion: number
}

const PreviewPanel: React.FC<PreviewPanelProps> = ({promptKey, promptVersion}) => {
    const showDiff = useAtomValue(refineDiffViewAtomFamily(promptKey))
    const [workingPrompt, setWorkingPrompt] = useAtom(workingPromptAtomFamily(promptKey))
    const originalPrompt = useAtomValue(originalPromptSnapshotAtomFamily(promptKey))

    const handleMessageChange = useCallback(
        (index: number, field: "role" | "content", value: string) => {
            setWorkingPrompt((prev) => {
                if (!prev) return prev

                const newMessages = [...prev.messages]
                newMessages[index] = {
                    ...newMessages[index],
                    [field]: value,
                }

                return {
                    ...prev,
                    messages: newMessages,
                }
            })
        },
        [setWorkingPrompt],
    )

    // Only diff messages — template_format and other fields are not refined
    const originalJson = useMemo(() => {
        if (!originalPrompt) return "[]"
        return JSON.stringify(originalPrompt.messages, null, 2)
    }, [originalPrompt])

    const workingJson = useMemo(() => {
        if (!workingPrompt) return "[]"
        return JSON.stringify(workingPrompt.messages, null, 2)
    }, [workingPrompt])

    if (!workingPrompt) {
        return (
            <div className="flex h-full items-center justify-center">
                <Typography.Text type="secondary" className="text-xs">
                    No refined prompt yet
                </Typography.Text>
            </div>
        )
    }

    return (
        <div className="p-4">
            {showDiff ? (
                <DiffView
                    language="json"
                    original={originalJson}
                    modified={workingJson}
                    className=""
                    enableFolding
                    foldThreshold={3}
                />
            ) : (
                <div className="flex flex-col gap-3">
                    {workingPrompt.messages.map((message, index) => (
                        <ChatMessageEditor
                            key={`v${promptVersion}-${index}`}
                            id={`refine-preview-${promptKey}-v${promptVersion}-${index}`}
                            role={message.role}
                            text={
                                typeof message.content === "string"
                                    ? message.content
                                    : JSON.stringify(message.content, null, 2)
                            }
                            onChangeRole={(v) => handleMessageChange(index, "role", v)}
                            onChangeText={(v) => handleMessageChange(index, "content", v)}
                            placeholder="Enter message content…"
                        />
                    ))}
                </div>
            )}
        </div>
    )
}

export default PreviewPanel
