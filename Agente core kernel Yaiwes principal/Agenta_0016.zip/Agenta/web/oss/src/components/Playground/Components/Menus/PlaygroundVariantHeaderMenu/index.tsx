import {useCallback, useMemo} from "react"

import {workflowMolecule} from "@agenta/entities/workflow"
import {isAgentModeAtomFamily, playgroundController} from "@agenta/playground"
import {message} from "@agenta/ui/app-message"
import {MoreOutlined} from "@ant-design/icons"
import {ArrowCounterClockwise, Copy, Trash} from "@phosphor-icons/react"
import {Button, Dropdown, MenuProps} from "antd"
import {getDefaultStore, useAtomValue, useSetAtom} from "jotai"

import DeleteVariantButton from "../../Modals/DeleteVariantModal/assets/DeleteVariantButton"

import {PlaygroundVariantHeaderMenuProps} from "./types"

const PlaygroundVariantHeaderMenu: React.FC<PlaygroundVariantHeaderMenuProps> = ({
    variantId,
    ...props
}) => {
    const selectedVariants = useAtomValue(playgroundController.selectors.entityIds())
    const removeVariantFromSelection = useSetAtom(playgroundController.actions.removeEntity)
    const isDirty = useAtomValue(workflowMolecule.selectors.isDirty(variantId || ""))
    // Agent mode is single-panel (no comparison grid), so "Close panel" doesn't apply.
    const isAgent = useAtomValue(isAgentModeAtomFamily(variantId || ""))

    const closePanelDisabled = useMemo(() => {
        return selectedVariants.length === 1 && selectedVariants.includes(variantId)
    }, [selectedVariants, variantId])

    const handleClosePanel = useCallback(() => {
        removeVariantFromSelection(variantId)
    }, [removeVariantFromSelection, variantId])

    const handleDiscardDraft = useCallback<NonNullable<MenuProps["onClick"]>>(
        (e) => {
            e?.domEvent?.stopPropagation()
            if (!variantId) return
            try {
                workflowMolecule.set.discard(variantId)
                message.success("Draft changes discarded")
            } catch (err) {
                message.error("Failed to discard draft changes")
                console.error(err)
            }
        },
        [variantId],
    )

    const handleCopyRawConfig = useCallback<NonNullable<MenuProps["onClick"]>>(
        (e) => {
            e?.domEvent?.stopPropagation()
            if (!variantId) return
            // Read lazily so the menu doesn't re-render on every config edit.
            const config = getDefaultStore().get(
                workflowMolecule.selectors.configuration(variantId),
            )
            if (!config) {
                message.error("No raw configuration available to copy")
                return
            }
            navigator.clipboard
                .writeText(JSON.stringify(config, null, 2))
                .then(() => message.success("Raw configuration copied to clipboard"))
                .catch((err) => {
                    message.error("Failed to copy raw configuration")
                    console.error(err)
                })
        },
        [variantId],
    )

    const items: MenuProps["items"] = useMemo(
        () => [
            {
                key: "copy-raw-config",
                label: "Copy raw config",
                icon: <Copy size={14} />,
                onClick: handleCopyRawConfig,
                disabled: !variantId,
            },
            {type: "divider" as const},
            {
                key: "revert",
                label: "Revert Changes",
                icon: <ArrowCounterClockwise size={14} />,
                onClick: handleDiscardDraft,
                disabled: !variantId || !isDirty,
            },
            {
                key: "delete",
                danger: true,
                label: (
                    <DeleteVariantButton variantId={variantId}>
                        <div className="w-full h-full">Delete</div>
                    </DeleteVariantButton>
                ),
                icon: <Trash size={16} />,
            },
            // Agent mode is single-panel, so there's nothing to close — hide it (and its divider).
            ...(!isAgent
                ? [
                      {type: "divider" as const},
                      {
                          key: "close",
                          label: "Close panel",
                          disabled: closePanelDisabled,
                          onClick: (e: {domEvent: {stopPropagation: () => void}}) => {
                              e.domEvent.stopPropagation()
                              handleClosePanel()
                          },
                      },
                  ]
                : []),
        ],
        [
            handleClosePanel,
            closePanelDisabled,
            variantId,
            handleDiscardDraft,
            handleCopyRawConfig,
            isDirty,
            isAgent,
        ],
    )

    return (
        <Dropdown trigger={["click"]} styles={{root: {width: 170}}} menu={{items}} {...props}>
            <Button icon={<MoreOutlined size={14} />} type="text" />
        </Dropdown>
    )
}

export default PlaygroundVariantHeaderMenu
