import {memo} from "react"

import {SkeletonLine} from "@agenta/ui/table"
import {Typography} from "antd"

import {useRunRowSummary} from "../../context/RunRowDataContext"
import type {EvaluationRunTableRow} from "../../types"

const CELL_CLASS = "flex h-full w-full min-w-0 flex-col justify-center gap-1 px-2"

export const PreviewRunNameCellSkeleton = () => (
    <div className="flex h-full flex-col justify-center gap-1">
        <SkeletonLine width="70%" center={false} />
        <SkeletonLine width="40%" center={false} />
    </div>
)

const PreviewRunNameCellContent = memo(({summary, runId}: {summary: any; runId: string | null}) => {
    const displayName = summary?.name || runId || "Untitled run"

    return (
        <Typography.Text className="font-medium whitespace-nowrap overflow-hidden text-ellipsis">
            {displayName}
        </Typography.Text>
    )
})

const PreviewRunNameCellContentLoader = ({
    record,
    isVisible,
}: {
    record: EvaluationRunTableRow
    isVisible: boolean
}) => {
    const {summary, isLoading} = useRunRowSummary(record, isVisible)
    const runId = record.preview?.id ?? record.runId

    if (isLoading) {
        return <PreviewRunNameCellSkeleton />
    }

    return <PreviewRunNameCellContent summary={summary} runId={runId ?? null} />
}

export const PreviewRunNameCell = ({
    record,
    isVisible = true,
}: {
    record: EvaluationRunTableRow
    isVisible?: boolean
}) => {
    if (record.__isSkeleton) {
        return (
            <div className={CELL_CLASS}>
                <PreviewRunNameCellSkeleton />
            </div>
        )
    }

    if (!isVisible) {
        return null
    }

    return (
        <div className={CELL_CLASS}>
            <PreviewRunNameCellContentLoader record={record} isVisible={isVisible} />
        </div>
    )
}
