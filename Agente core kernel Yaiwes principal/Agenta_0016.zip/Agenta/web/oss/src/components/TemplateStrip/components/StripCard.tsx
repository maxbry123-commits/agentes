import {templateProviderSlugs, type AgentStarterTemplate} from "@agenta/entities/workflow"
import {CircleNotchIcon} from "@phosphor-icons/react"

import IntegrationBadges from "./IntegrationBadges"

/**
 * One template card. Fixed 238px in the scroll strip; `fluid` fills its grid cell on the
 * home 3-up layout. A real button (keyboard focusable); the border is a constant 1.5px so
 * the box never shifts between default/hover/selected states.
 */
const StripCard = ({
    template,
    selected,
    onPick,
    fluid = false,
    loading = false,
    disabled = false,
}: {
    template: AgentStarterTemplate
    selected: boolean
    onPick: (template: AgentStarterTemplate) => void
    fluid?: boolean
    /** This card's agent is being created — spins its monogram and blocks re-clicks. */
    loading?: boolean
    /** Another card's create is in flight. */
    disabled?: boolean
}) => (
    <button
        type="button"
        aria-pressed={selected}
        aria-busy={loading}
        disabled={loading || disabled}
        onClick={() => onPick(template)}
        className={`${fluid ? "w-full" : "w-[238px] flex-none snap-start"} rounded-xl border-[1.5px] border-solid ${fluid ? "p-5" : "p-[15px]"} text-left transition-[border-color,box-shadow] duration-150 ${
            loading || disabled ? "cursor-default" : "cursor-pointer"
        } ${disabled ? "opacity-60" : ""} ${
            selected
                ? "border-[var(--ag-colorPrimary)] bg-[var(--ag-strip-selected-bg)]"
                : // Tint is light-only: its dark step is a different surface, so dark keeps this strip's card token.
                  `border-[var(--ag-strip-card-border)] bg-[var(--ag-surface-paper)] dark:bg-[var(--ag-strip-card-bg)] ${
                      loading || disabled
                          ? ""
                          : "hover:border-[var(--ag-strip-card-border-hover)] hover:shadow-[var(--ag-strip-card-hover-shadow)]"
                  }`
        }`}
    >
        <div className={`${fluid ? "mb-4" : "mb-[11px]"} flex items-start justify-between`}>
            <span
                className={`flex items-center justify-center font-semibold text-white ${
                    fluid ? "size-10 rounded-[10px] text-[14px]" : "size-8 rounded-lg text-[13px]"
                }`}
                style={{background: template.color}}
            >
                {loading ? (
                    <CircleNotchIcon size={fluid ? 18 : 15} className="animate-spin" />
                ) : (
                    template.initials
                )}
            </span>
            <IntegrationBadges slugs={templateProviderSlugs(template)} />
        </div>
        <div
            className={`${fluid ? "mb-1.5 text-base" : "mb-1 text-base"} font-semibold text-[var(--ag-colorText)]`}
        >
            {template.name}
        </div>
        <div className="text-xs leading-[1.5] text-[var(--ag-colorTextSecondary)]">
            {template.description}
        </div>
    </button>
)

export default StripCard
