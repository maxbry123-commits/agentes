import {useCallback, useEffect, useMemo, useState} from "react"

import {SESSIONS_PAGE_SIZE} from "@agenta/observability"
import {useSessions} from "@agenta/observability"
import {AUTO_REFRESH_INTERVAL, SessionStoreProvider} from "@agenta/observability-ui"
import {
    EmptySessions,
    getSessionColumns,
    ObservabilitySessionsTable,
} from "@agenta/observability-ui"
import type {TableScopeConfig} from "@agenta/ui/table"
import {useAtomValue, useSetAtom, useStore} from "jotai"
import dynamic from "next/dynamic"

import {SessionDrawer} from "@/oss/components/SharedDrawers/SessionDrawer"
import {isNewUserAtom} from "@/oss/lib/onboarding"
import {onboardingStorageUserIdAtom} from "@/oss/lib/onboarding/atoms"
import {hasReceivedSessionsAtom} from "@/oss/state/observability"
import {openSessionDrawerWithUrlAtom} from "@/oss/state/url/session"

const ObservabilityHeader = dynamic(() => import("../../components/ObservabilityHeader"), {
    ssr: false,
})

const tableScope: TableScopeConfig = {
    scopeId: "sessions",
    pageSize: SESSIONS_PAGE_SIZE,
    columnVisibilityStorageKey: "observability-sessions-table-columns",
}

/**
 * Next iteration plan:
 * - Add infinite scroll for spans query
 * - For Session drawer add infinite scroll for spans
 */

const SessionsTable: React.FC = () => {
    const {isLoading, sessionIds, sessionCount, autoRefresh, resetSessionPages} = useSessions()

    // The per-session cells (Traces count, First input, metrics, …) read their
    // data from page-level atoms keyed by session id (e.g. `sessionsSpansAtom`).
    // Without this, the table mounts its rows inside an isolated Jotai store
    // (`useIsolatedStore` when no `store` is passed), where those atoms are empty
    // — so every cell renders 0/"-" even though the data is loaded in the page
    // store. Sharing the page store lets the cells resolve the real data.
    const store = useStore()

    // Still needed here: the header's column-visibility menu is built from them.
    const columns = useMemo(() => getSessionColumns(), [])

    const isNewUser = useAtomValue(isNewUserAtom)
    const onboardingStorageUserId = useAtomValue(onboardingStorageUserIdAtom)
    const openDrawer = useSetAtom(openSessionDrawerWithUrlAtom)
    const hasReceivedSessions = useAtomValue(hasReceivedSessionsAtom)
    const setHasReceivedSessions = useSetAtom(hasReceivedSessionsAtom)
    const [refreshTrigger, setRefreshTrigger] = useState(0)
    const showOnboarding = isNewUser && !hasReceivedSessions

    useEffect(() => {
        if (onboardingStorageUserId && sessionCount > 0 && !hasReceivedSessions) {
            setHasReceivedSessions(true)
        }
    }, [onboardingStorageUserId, sessionCount, hasReceivedSessions, setHasReceivedSessions])

    const handleRefresh = useCallback(async () => {
        // Reset to page 1 so only one API call per query on refresh.
        resetSessionPages()
        setRefreshTrigger((prev) => prev + 1)
    }, [resetSessionPages])

    // Auto-refresh logic: refresh every 15 seconds when enabled
    useEffect(() => {
        if (!autoRefresh) return

        const intervalId = setInterval(() => {
            handleRefresh().catch((error) => console.error("Auto-refresh failed", error))
        }, AUTO_REFRESH_INTERVAL)

        return () => clearInterval(intervalId)
    }, [autoRefresh, handleRefresh])

    // Build pagination object expected by InfiniteVirtualTableFeatureShell

    return (
        // Page store == default store (GlobalStateProvider), so this matches the prior fallback.
        <SessionStoreProvider value={store}>
            <div className="flex h-full min-h-0 flex-col gap-2">
                <ObservabilityHeader
                    columns={columns}
                    componentType="sessions"
                    isLoading={isLoading}
                    onRefresh={handleRefresh}
                    refreshTrigger={refreshTrigger}
                />

                {/* Empty state renders inside the table so the header survives it. */}
                {
                    <ObservabilitySessionsTable
                        store={store}
                        tableScope={tableScope}
                        resizableColumns
                        enableExport={false}
                        useSettingsDropdown={false}
                        className="flex-1 min-h-0 [&_.avt-row_.avt-cell]:align-top"
                        tableProps={{
                            locale: {
                                emptyText: <EmptySessions showOnboarding={showOnboarding} />,
                            },
                            loading: isLoading && sessionIds.length === 0,
                            onRow: () => ({style: {cursor: "pointer"}}),
                        }}
                        onRowClick={(record) => openDrawer({sessionId: record.session_id})}
                    />
                }
                <SessionDrawer />
            </div>
        </SessionStoreProvider>
    )
}

export default SessionsTable
