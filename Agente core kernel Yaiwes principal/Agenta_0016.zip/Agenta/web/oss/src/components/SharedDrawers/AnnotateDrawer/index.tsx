import {useCallback, useEffect, useMemo, useState} from "react"

import {AnnotationDto} from "@agenta/entities/annotation/dto"
import {humanEvaluatorsListDataAtom, type Workflow} from "@agenta/entities/workflow"
import {EnhancedDrawer} from "@agenta/ui/drawer"
import {atom, useAtomValue} from "jotai"
import dynamic from "next/dynamic"
import {useLocalStorage} from "usehooks-ts"

import {getProjectValues} from "@/oss/state/project"

import {AnnotateDrawerSteps} from "./assets/enum"
import {useEvaluatorSchemas} from "./assets/hooks/useEvaluatorSchemas"
import {AnnotateDrawerProps, AnnotateDrawerStepsType, UpdatedMetricsType} from "./assets/types"
import {isAnnotationCreatedByCurrentUser} from "./assets/utils"

// `humanEvaluatorsListDataAtom` resolves every evaluator's latest revision (a
// batched per-evaluator fan-out). This drawer is mounted (closed) in shared
// layouts incl. the playground, so reading it unconditionally fired that fan-out
// on every page load. Swap in a stable empty atom while the drawer is closed —
// the list is only needed once it opens.
const EMPTY_EVALUATOR_REFS_ATOM = atom<Workflow[]>([])

const Annotate = dynamic(() => import("./assets/Annotate"), {ssr: false})
const SelectEvaluators = dynamic(() => import("./assets/SelectEvaluators"), {ssr: false})
const CreateEvaluator = dynamic(() => import("./assets/CreateEvaluator"), {ssr: false})
const AnnotateDrawerTitle = dynamic(() => import("./assets/AnnotateDrawerTitle"), {ssr: false})

const AnnotateDrawer = ({
    data,
    traceSpanIds,
    showOnly,
    evalSlugs,
    initialStep = AnnotateDrawerSteps.ANNOTATE,
    createEvaluatorProps,
    queryKey,
    ...props
}: AnnotateDrawerProps) => {
    const {projectId} = getProjectValues()
    const evaluatorRefs = useAtomValue(
        props.open ? humanEvaluatorsListDataAtom : EMPTY_EVALUATOR_REFS_ATOM,
    )
    const evaluators = useEvaluatorSchemas(evaluatorRefs as any)
    const evalLSKey = `${projectId}-evaluator`

    const [annotations, setAnnotations] = useState<AnnotationDto[]>([])
    const [steps, setSteps] = useState<AnnotateDrawerStepsType>(initialStep)
    const [updatedMetrics, setUpdatedMetrics] = useState<UpdatedMetricsType>({})
    const [selectedEvaluators, setSelectedEvaluators] = useLocalStorage<string[]>(evalLSKey, [])
    const [errorMessage, setErrorMessage] = useState<string[]>([])
    // tempSelectedEvaluators is used to store those eval which we have on the annotations but the condition
    // to display annotation are not matched so we pick the eval slug from those ann an generate a new annotation with empty value
    const [tempSelectedEvaluators, setTempSelectedEvaluators] = useState<string[]>([])

    useEffect(() => {
        if (!props.open) return

        // 1. Sort annotations by createdAt (newest first)
        const sortedAnnotations = [...(data || [])].sort((a, b) => {
            const aDate = a.createdAt ? new Date(a.createdAt) : new Date(0)
            const bDate = b.createdAt ? new Date(b.createdAt) : new Date(0)
            return bDate.getTime() - aDate.getTime()
        })

        // 2. Remove duplicate evaluator slugs, keeping only the latest annotation for each slug
        const latestBySlug: Record<string, AnnotationDto> = {}
        for (const ann of sortedAnnotations) {
            const slug = ann.references?.evaluator?.slug
            if (!slug) continue
            // Always overwrite, so the last one (latest by createdAt due to sorting) stays
            latestBySlug[slug] = ann
        }
        const getLatestAnnFromSameEvals = Object.values(latestBySlug)

        // creating evaluator order
        const evaluatorOrder: Record<string, number> = {}
        evaluators?.forEach((ev, idx) => {
            evaluatorOrder[ev.slug] = idx
        })

        // 3. sorting annotations by evaluator order
        const sortAnnotationsByEval = getLatestAnnFromSameEvals.slice().sort((a, b) => {
            const aSlug = a.references?.evaluator?.slug || ""
            const bSlug = b.references?.evaluator?.slug || ""
            return (evaluatorOrder[aSlug] ?? 0) - (evaluatorOrder[bSlug] ?? 0)
        })

        const filteredAnn = sortAnnotationsByEval?.filter((ann) =>
            isAnnotationCreatedByCurrentUser(ann),
        )
        setAnnotations(filteredAnn || [])

        // 4. Get annotations NOT matching the user/web/human condition
        const filteredAnnForEval = sortAnnotationsByEval.filter(
            (ann) => !isAnnotationCreatedByCurrentUser(ann),
        )

        // 5. Get unique slugs - only from HUMAN annotations (not auto evaluations)
        if (filteredAnnForEval.length > 0) {
            const evalSlugs = filteredAnnForEval
                .filter((ann) => ann.origin === "human" || ann.channel === "web") // Only human annotations from other users
                .map((ann) => ann.references?.evaluator?.slug)
                .filter(Boolean) as string[]

            setTempSelectedEvaluators((prev) => [...new Set([...prev, ...evalSlugs])])
        }
    }, [data, props.open])

    useEffect(() => {
        if (props.open) {
            setSteps(initialStep)
        }
    }, [props.open, initialStep])

    const annEvalSlugs = useMemo(() => {
        return (
            (annotations
                .map((ann) => ann.references?.evaluator?.slug)
                .filter(Boolean) as string[]) || []
        )
    }, [annotations])

    const _selectedEvaluators = useMemo(() => {
        if (selectedEvaluators.length > 0) {
            const selectedEval = selectedEvaluators.filter(
                (evaluator) => !annEvalSlugs.includes(evaluator),
            )
            const newSetOfEval = new Set([...selectedEval, ...tempSelectedEvaluators])
            return [...newSetOfEval]
        } else if (tempSelectedEvaluators.length > 0) {
            const newSetOfTempEval = new Set(tempSelectedEvaluators)
            return [...newSetOfTempEval]
        } else if (evalSlugs && evalSlugs.length > 0) {
            const newSetOfEvalSlugs = new Set(evalSlugs)
            return [...newSetOfEvalSlugs]
        } else {
            return []
        }
    }, [selectedEvaluators, tempSelectedEvaluators, annEvalSlugs, evalSlugs, data, annotations])

    const onClose = useCallback(() => {
        props?.onClose?.({} as any)
    }, [])

    const onAfterClose = useCallback(
        (open: boolean) => {
            if (!open) {
                setSteps(initialStep)
                setTempSelectedEvaluators([])
                setAnnotations([])
                setErrorMessage([])
                setUpdatedMetrics({})
            }
        },
        [props.afterOpenChange, initialStep],
    )

    const onCaptureError = useCallback(
        (error: string[], addPrevVal = true) => {
            if (error.length > 0) {
                setErrorMessage((prev) => [...new Set(addPrevVal ? [...prev, ...error] : error)])
            } else {
                setErrorMessage([])
            }
        },
        [setErrorMessage],
    )

    const renderContent = useMemo(() => {
        const {
            setSteps: _ignoredSetSteps,
            setSelectedEvaluators: _ignoredSetSelectedEvaluators,
            ...restCreateEvaluatorProps
        } = createEvaluatorProps || {}

        switch (steps) {
            case AnnotateDrawerSteps.ANNOTATE:
                return (
                    <Annotate
                        annotations={annotations || []}
                        updatedMetrics={updatedMetrics}
                        setUpdatedMetrics={setUpdatedMetrics}
                        selectedEvaluators={_selectedEvaluators}
                        tempSelectedEvaluators={tempSelectedEvaluators}
                        errorMessage={errorMessage}
                        onCaptureError={onCaptureError}
                    />
                )
            case AnnotateDrawerSteps.SELECT_EVALUATORS:
                return (
                    <SelectEvaluators
                        selectedEvaluators={_selectedEvaluators}
                        annEvalSlugs={annEvalSlugs || []}
                        setSelectedEvaluators={setSelectedEvaluators}
                        setTempSelectedEvaluators={setTempSelectedEvaluators}
                    />
                )
            case AnnotateDrawerSteps.CREATE_EVALUATOR:
                return (
                    <CreateEvaluator
                        setSteps={setSteps}
                        setSelectedEvaluators={setSelectedEvaluators}
                        {...restCreateEvaluatorProps}
                    />
                )
            default:
                return null
        }
    }, [
        steps,
        annotations,
        updatedMetrics,
        _selectedEvaluators,
        tempSelectedEvaluators,
        errorMessage,
        createEvaluatorProps,
    ])

    return (
        <EnhancedDrawer
            {...props}
            title={
                <AnnotateDrawerTitle
                    updatedMetrics={updatedMetrics}
                    selectedEvaluators={_selectedEvaluators}
                    annotations={annotations || []}
                    steps={steps}
                    setSteps={setSteps}
                    onClose={onClose}
                    onCaptureError={onCaptureError}
                    traceSpanIds={traceSpanIds}
                    showOnly={showOnly}
                    queryKey={queryKey}
                    createEvaluatorMode={createEvaluatorProps?.mode}
                />
            }
            closable={false}
            width={400}
            onClose={onClose}
            styles={{body: {padding: 0}, header: {padding: 16}}}
            afterOpenChange={onAfterClose}
        >
            {renderContent}
        </EnhancedDrawer>
    )
}

export default AnnotateDrawer
