import {useCallback, useEffect, useMemo, useState} from "react"

import {humanEvaluatorsListDataAtom} from "@agenta/entities/workflow"
import {Collapse, CollapseProps, Typography} from "antd"
import clsx from "clsx"
import {useAtomValue} from "jotai"
import dynamic from "next/dynamic"

import {EvaluatorDto} from "@/oss/services/evaluations/api/evaluatorTypes"

import {useEvaluatorSchemas} from "../hooks/useEvaluatorSchemas"
import {
    getInitialMetricsFromAnnotations,
    getInitialSelectedEvalMetrics,
    transformMetadata,
} from "../transforms"
import {AnnotateProps} from "../types"

import AnnotateCollapseContent from "./assets/AnnotateCollapseContent"

const Alert = dynamic(() => import("antd").then((mod) => mod.Alert), {ssr: false})

const Annotate = ({
    annotations = [],
    updatedMetrics = {},
    selectedEvaluators = [],
    tempSelectedEvaluators = [],
    errorMessage = [],
    disabled = false,
    setUpdatedMetrics,
    onCaptureError,
}: AnnotateProps) => {
    const evaluatorRefs = useAtomValue(humanEvaluatorsListDataAtom)
    const evaluators = useEvaluatorSchemas(evaluatorRefs as any)

    // Stabilize array dependencies to prevent infinite loops
    const selectedEvaluatorsKey = useMemo(
        () => JSON.stringify(selectedEvaluators.slice().sort()),
        [selectedEvaluators],
    )
    const annotationsKey = useMemo(
        () => JSON.stringify(annotations.map((a) => a.references?.evaluator?.slug ?? a.id).sort()),
        [annotations],
    )

    // converting selected evaluator into useable metrics
    useEffect(() => {
        try {
            if (!selectedEvaluators.length || !evaluators?.length) return

            const metrics = getInitialSelectedEvalMetrics({
                evaluators: evaluators as EvaluatorDto[],
                selectedEvaluators,
            })

            setUpdatedMetrics((prev) => {
                // Only update if metrics actually changed to prevent loops
                const hasChanges = Object.keys(metrics).some(
                    (key) => JSON.stringify(prev[key]) !== JSON.stringify(metrics[key]),
                )
                if (!hasChanges) return prev
                return {...prev, ...metrics}
            })
        } catch (error) {
            onCaptureError?.(["Invalid evaluator schema"])
        }
    }, [selectedEvaluatorsKey, evaluators])

    // get metrics data from the selected annotation
    useEffect(() => {
        try {
            const _evaluators = evaluators?.filter(Boolean)
            if (!annotations.length || !_evaluators?.length) return

            const initialMetrics = getInitialMetricsFromAnnotations({
                annotations,
                evaluators: _evaluators as EvaluatorDto[],
            })

            setUpdatedMetrics((prev) => {
                // If prev is empty, initialize with all metrics from annotations
                if (Object.keys(prev).length === 0) {
                    return initialMetrics
                }

                // If prev already has values, only add NEW slugs that don't exist yet.
                // This prevents overwriting user's pending changes during refetch.
                const newMetrics: Record<string, any> = {...prev}
                let hasNewKeys = false

                for (const [slug, metrics] of Object.entries(initialMetrics)) {
                    if (!(slug in prev)) {
                        // This is a completely new evaluator slug, add it
                        newMetrics[slug] = metrics
                        hasNewKeys = true
                    }
                    // If the slug already exists in prev, don't overwrite it
                    // to preserve user's pending changes
                }

                return hasNewKeys ? newMetrics : prev
            })
        } catch (error) {
            onCaptureError?.(["Invalid evaluator schema"])
        }
    }, [annotationsKey, evaluators])

    // active collapse for the first open drawer
    useEffect(() => {
        const annEvalSlugs = annotations
            .map((ann) => ann.references?.evaluator?.slug)
            .filter(Boolean) as string[]

        const slugs = [...new Set([...annEvalSlugs, ...selectedEvaluators])]
        setActiveCollapse((prev) => [...new Set([...prev, ...slugs])])
    }, [annotations, selectedEvaluators])

    const handleCollapseChange = useCallback((keys: string[]) => {
        // Check if any dropdown is open by looking for the dropdown menu with the 'open' class
        // This is for improving micro interactions
        const openDropdowns = document.querySelectorAll(
            ".ant-select-dropdown:not(.ant-select-dropdown-hidden)",
        )
        if (openDropdowns.length > 0) {
            return
        }
        setActiveCollapse(keys)
    }, [])

    const handleMetricChange = useCallback((annSlug: string, metricKey: string, newValue: any) => {
        setUpdatedMetrics((prev) => ({
            ...prev,
            [annSlug]: {
                ...prev[annSlug],
                [metricKey]: {...prev[annSlug][metricKey], value: newValue},
            },
        }))
    }, [])

    const items: CollapseProps["items"] = useMemo(() => {
        const annotationItems = annotations.map((ann) => {
            const metrics = updatedMetrics[ann.references?.evaluator?.slug || ""] || {}
            const metadata = transformMetadata({data: metrics})

            return {
                key: ann.references?.evaluator?.slug || "",
                label: (
                    <div className="flex items-center justify-between">
                        <Typography.Text
                            className="capitalize truncate !w-[50%] text-start"
                            title={ann.meta?.name || ann.references?.evaluator?.slug}
                        >
                            {ann.meta?.name || ann.references?.evaluator?.slug}
                        </Typography.Text>
                        <Typography.Text
                            className="text-[var(--ag-c-758391)] truncate !w-[40%] text-end"
                            title={ann.references?.evaluator?.slug}
                        >
                            {ann.references?.evaluator?.slug}
                        </Typography.Text>
                    </div>
                ),
                children: (
                    <div className="flex flex-col gap-4">
                        {metadata.map((_meta) => {
                            const meta: Record<string, any> = {
                                ..._meta,
                                disabled,
                            }
                            return (
                                <AnnotateCollapseContent
                                    metadata={meta}
                                    key={meta.title}
                                    annSlug={ann.references?.evaluator?.slug || ""}
                                    onChange={handleMetricChange}
                                />
                            )
                        })}
                    </div>
                ),
            }
        })

        // Add evaluator-based items
        const evaluatorItems = ((evaluators || []) as EvaluatorDto[])
            .filter((evaluator) => selectedEvaluators.includes(evaluator.slug))
            .map((eva) => {
                const metrics = updatedMetrics[eva.slug || ""] || {}
                const metadata = transformMetadata({data: metrics})

                return {
                    key: eva.slug,
                    label: (
                        <div className="flex items-center justify-between text-start">
                            <Typography.Text
                                className="capitalize truncate !w-[50%]"
                                title={eva.name}
                            >
                                {eva.name}
                            </Typography.Text>
                            <Typography.Text
                                className="text-[var(--ag-c-758391)] truncate !w-[40%] text-end"
                                title={eva.slug}
                            >
                                {eva.slug}
                            </Typography.Text>
                        </div>
                    ),
                    children: (
                        <div className="flex flex-col gap-4">
                            {metadata.map((_meta) => {
                                const meta = {
                                    ..._meta,
                                    disabled,
                                } as Record<string, any>
                                return (
                                    <AnnotateCollapseContent
                                        metadata={meta}
                                        key={meta.title}
                                        annSlug={eva.slug}
                                        onChange={handleMetricChange}
                                    />
                                )
                            })}
                        </div>
                    ),
                }
            })

        // Combine and sort by evaluator order
        const allItems = [...evaluatorItems, ...annotationItems]
        const evaluatorOrder: Record<string, number> = {}
        evaluators?.forEach((ev: any, idx: number) => {
            evaluatorOrder[ev.slug] = idx
        })
        return allItems.slice().sort((a, b) => {
            const aKey = a.key || ""
            const bKey = b.key || ""
            return (evaluatorOrder[aKey] ?? 0) - (evaluatorOrder[bKey] ?? 0)
        })
    }, [annotations, updatedMetrics, evaluators, selectedEvaluators, disabled])

    const [activeCollapse, setActiveCollapse] = useState<string[]>(
        items.map((item) => item.key).filter(Boolean) as string[],
    )

    if (!annotations.length && !selectedEvaluators.length) {
        return (
            <div className="h-full flex items-center justify-center">
                <Typography.Text type="secondary">
                    There are no available annotations
                </Typography.Text>
            </div>
        )
    }

    return (
        <section className="w-full flex flex-col">
            {tempSelectedEvaluators.length > 0 && (
                <Alert
                    message="You have not added any human annotations from the web yet."
                    type="warning"
                    className="!rounded-none"
                    showIcon
                />
            )}

            {errorMessage && errorMessage?.length > 0
                ? errorMessage?.map((err, idx) => (
                      <Alert
                          showIcon
                          closable
                          key={idx}
                          message={err}
                          type="warning"
                          className="!rounded-none"
                          onClose={() =>
                              onCaptureError?.(
                                  errorMessage?.filter((_, i) => i !== idx) || [],
                                  false,
                              )
                          }
                      />
                  ))
                : null}

            <Collapse
                activeKey={activeCollapse}
                onChange={handleCollapseChange}
                items={items}
                defaultActiveKey={items.map((item) => item.key as string)}
                className={clsx(
                    "rounded-none",
                    "[&_.ant-collapse-content-box]:!p-0",
                    "[&_.ant-collapse-content]:!bg-[var(--ag-c-FFFFFF)] [&_.ant-collapse-content]:p-3",
                    "[&_.playground-property-control]:!mb-0",
                    "[&_.ant-slider]:!mb-0 [&_.ant-slider]:!mt-1",
                    "[&_.ant-collapse-header-text]:w-[95%]",
                )}
                bordered={false}
            />
        </section>
    )
}

export default Annotate
