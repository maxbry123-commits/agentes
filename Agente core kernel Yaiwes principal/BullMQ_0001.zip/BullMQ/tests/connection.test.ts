import {
  getRedisClient,
  getRedisConnection,
  getBlockingRedisConnection,
} from './utils/get-redis-client';
import { default as IORedis, RedisOptions } from 'ioredis';
import { EventEmitter } from 'events';
import {
  describe,
  beforeEach,
  afterEach,
  beforeAll,
  afterAll,
  it,
  expect,
} from 'vitest';

import {
  Queue,
  Job,
  Worker,
  QueueBase,
  FlowProducer,
  RedisConnection,
} from '../src/classes';
import { randomUUID, removeAllQueueData } from '../src/utils';

import * as sinon from 'sinon';

describe('RedisConnection', () => {
  function createMockClusterClient(overrides: Record<string, any> = {}) {
    return {
      // Mark as already-augmented IRedisClient so RedisConnection skips
      // createIORedisClient() and uses the mock directly.
      __bullmq_iredis: true,
      isCluster: true,
      status: 'ready',
      options: { redisOptions: {} },
      on: sinon.stub(),
      once: sinon.stub(),
      off: sinon.stub(),
      removeListener: sinon.stub(),
      getMaxListeners: sinon.stub().returns(10),
      setMaxListeners: sinon.stub(),
      connect: sinon.stub().resolves(),
      disconnect: sinon.stub(),
      duplicate: sinon.stub(),
      quit: sinon.stub().resolves('OK'),
      defineCommand: sinon.stub(),
      info: sinon.stub().resolves('redis_version:7.0.0'),
      nodes: sinon.stub().returns([{}]),
      bzpopmin: sinon.stub().resolves(null),
      pipeline: sinon.stub().returns({
        exec: sinon.stub().resolves([]),
      }),
      multi: sinon.stub().returns({
        exec: sinon.stub().resolves([]),
      }),
      ...overrides,
    };
  }

  describe('constructor', () => {
    it('initializes with default extraOptions when none provided', () => {
      const connection = new RedisConnection({});
      expect((connection as any).extraOptions).toEqual({
        shared: false,
        blocking: true,
        skipVersionCheck: false,
        skipWaitingForReady: false,
        clusterReconnectTimeoutMs: 30_000,
      });
    });

    it('merges provided extraOptions with defaults', () => {
      const options = {
        shared: true,
        blocking: false,
        skipVersionCheck: true,
        skipWaitingForReady: true,
      };
      const connection = new RedisConnection({}, options);
      expect((connection as any).extraOptions).toMatchObject(options);
    });

    describe('when skipVersionCheck is set as true', () => {
      it('initializes version as minimum', async () => {
        const connection = new RedisConnection({
          skipVersionCheck: true,
        });
        await (connection as any).initializing;

        expect((connection as any).redisVersion).toBe('5.0.0');
      });
    });
  });

  describe('blocking option', () => {
    it('sets maxRetriesPerRequest to null when blocking is true', () => {
      const connection = new RedisConnection({}, { blocking: true });
      expect((connection as any).opts.maxRetriesPerRequest).toBeNull();
    });

    it('preserves maxRetriesPerRequest when blocking is false', () => {
      const connection = new RedisConnection(
        { maxRetriesPerRequest: 10 },
        { blocking: false },
      );
      expect((connection as any).opts.maxRetriesPerRequest).toBe(10);
    });

    it('reconnects an ioredis cluster with an empty node pool before bzpopmin', async () => {
      let hasNodes = false;
      const bzpopmin = sinon.stub().resolves(['marker', '0', '1']);
      const cluster = createMockClusterClient({
        connect: sinon.stub().callsFake(async () => {
          hasNodes = true;
        }),
        nodes: sinon.stub().callsFake(() => (hasNodes ? [{}] : [])),
        bzpopmin,
      });
      const connection = new RedisConnection(cluster as any, {
        blocking: true,
        skipVersionCheck: true,
        skipWaitingForReady: true,
      });

      const client = await connection.client;
      const result = await (client as any).bzpopmin('marker', 1);

      expect(cluster.disconnect.calledOnceWith(false)).toBe(true);
      expect(cluster.connect.calledOnce).toBe(true);
      expect(bzpopmin.calledOnceWith('marker', 1)).toBe(true);
      expect(result).toEqual(['marker', '0', '1']);

      await connection.close(true);
    });

    it('restores patched bzpopmin when a shared blocking cluster connection closes', async () => {
      const bzpopmin = sinon.stub().resolves(['marker', '0', '1']);
      const cluster = createMockClusterClient({ bzpopmin });
      const originalBzpopmin = cluster.bzpopmin;
      const connection = new RedisConnection(cluster as any, {
        shared: true,
        blocking: true,
        skipVersionCheck: true,
        skipWaitingForReady: true,
      });

      const client = await connection.client;
      expect((client as any).bzpopmin).not.toBe(originalBzpopmin);

      await connection.close();

      expect(cluster.bzpopmin).toBe(originalBzpopmin);
      await (cluster as any).bzpopmin('marker', 1);
      expect(cluster.disconnect.called).toBe(false);
      expect(cluster.connect.called).toBe(false);
      expect(bzpopmin.calledOnceWith('marker', 1)).toBe(true);
    });

    it('keeps patched bzpopmin until all shared blocking cluster connections close', async () => {
      const bzpopmin = sinon.stub().resolves(['marker', '0', '1']);
      const cluster = createMockClusterClient({ bzpopmin });
      const originalBzpopmin = cluster.bzpopmin;
      const connectionA = new RedisConnection(cluster as any, {
        shared: true,
        blocking: true,
        skipVersionCheck: true,
        skipWaitingForReady: true,
      });

      await connectionA.client;
      const patchedBzpopmin = cluster.bzpopmin;
      expect(patchedBzpopmin).not.toBe(originalBzpopmin);

      const connectionB = new RedisConnection(cluster as any, {
        shared: true,
        blocking: true,
        skipVersionCheck: true,
        skipWaitingForReady: true,
      });

      await connectionB.client;
      expect(cluster.bzpopmin).toBe(patchedBzpopmin);

      await connectionA.close();
      expect(cluster.bzpopmin).toBe(patchedBzpopmin);

      await (cluster as any).bzpopmin('marker', 1);
      expect(bzpopmin.calledOnceWith('marker', 1)).toBe(true);

      await connectionB.close();
      expect(cluster.bzpopmin).toBe(originalBzpopmin);
    });

    it('does not reconnect an empty-node blocking cluster while the client is closing', async () => {
      const bzpopmin = sinon.stub().resolves(['marker', '0', '1']);
      const cluster = createMockClusterClient({
        status: 'closing',
        nodes: sinon.stub().returns([]),
        bzpopmin,
      });
      const connection = new RedisConnection(cluster as any, {
        blocking: true,
        skipVersionCheck: true,
        skipWaitingForReady: true,
      });

      const client = await connection.client;

      const result = await (client as any).bzpopmin('marker', 1);

      expect(cluster.disconnect.called).toBe(false);
      expect(cluster.connect.called).toBe(false);
      expect(bzpopmin.calledOnceWith('marker', 1)).toBe(true);
      expect(result).toEqual(['marker', '0', '1']);

      cluster.status = 'ready';
      await connection.close(true);
    });

    it('reconnects an ioredis cluster after bzpopmin command timeout', async () => {
      const error = new Error('Command timed out');
      const bzpopmin = sinon.stub().rejects(error);
      const cluster = createMockClusterClient({ bzpopmin });
      const connection = new RedisConnection(cluster as any, {
        blocking: true,
        skipVersionCheck: true,
        skipWaitingForReady: true,
      });

      const client = await connection.client;

      await expect((client as any).bzpopmin('marker', 1)).rejects.toThrow(
        'Command timed out',
      );
      expect(cluster.disconnect.calledOnceWith(false)).toBe(true);
      expect(cluster.connect.calledOnce).toBe(true);
      expect(bzpopmin.calledOnceWith('marker', 1)).toBe(true);

      await connection.close(true);
    });

    it('does not reconnect after bzpopmin command timeout while closing', async () => {
      const error = new Error('Command timed out');
      const state: { connection?: RedisConnection } = {};
      const bzpopmin = sinon.stub().callsFake(async () => {
        if (!state.connection) {
          throw new Error('Connection not initialized');
        }

        await state.connection.close(true);
        throw error;
      });
      const cluster = createMockClusterClient({ bzpopmin });
      const connection = new RedisConnection(cluster as any, {
        blocking: true,
        skipVersionCheck: true,
        skipWaitingForReady: true,
      });
      state.connection = connection;

      const client = await connection.client;

      await expect((client as any).bzpopmin('marker', 1)).rejects.toThrow(
        'Command timed out',
      );
      expect(cluster.disconnect.calledOnce).toBe(true);
      expect(cluster.disconnect.calledWith(false)).toBe(false);
      expect(cluster.connect.called).toBe(false);
      expect(bzpopmin.calledOnceWith('marker', 1)).toBe(true);
    });

    it('preserves the bzpopmin error when reconnect after command timeout fails', async () => {
      const commandError = new Error('Command timed out');
      const bzpopmin = sinon.stub().rejects(commandError);
      const cluster = createMockClusterClient({
        bzpopmin,
        connect: sinon.stub().rejects(new Error('Cluster reconnect failed')),
      });
      const connection = new RedisConnection(cluster as any, {
        blocking: true,
        skipVersionCheck: true,
        skipWaitingForReady: true,
      });

      const client = await connection.client;
      let thrownError: unknown;

      try {
        await (client as any).bzpopmin('marker', 1);
      } catch (error) {
        thrownError = error;
      }

      expect(thrownError).toBe(commandError);
      expect(cluster.disconnect.calledOnceWith(false)).toBe(true);
      expect(cluster.connect.calledOnce).toBe(true);
      expect(bzpopmin.calledOnceWith('marker', 1)).toBe(true);

      await connection.close(true);
    });

    it('reconnects an ioredis cluster after slots refresh timeout', async () => {
      const error = Object.assign(new Error('Failed to refresh slots cache.'), {
        lastNodeError: new Error('Command timed out'),
      });
      const bzpopmin = sinon.stub().rejects(error);
      const cluster = createMockClusterClient({ bzpopmin });
      const connection = new RedisConnection(cluster as any, {
        blocking: true,
        skipVersionCheck: true,
        skipWaitingForReady: true,
      });

      const client = await connection.client;

      await expect((client as any).bzpopmin('marker', 1)).rejects.toThrow(
        'Failed to refresh slots cache.',
      );
      expect(cluster.disconnect.calledOnceWith(false)).toBe(true);
      expect(cluster.connect.calledOnce).toBe(true);
      expect(bzpopmin.calledOnceWith('marker', 1)).toBe(true);

      await connection.close(true);
    });

    // Regression for a deadlock observed in production after upgrading to
    // bullmq 5.76.6: when ioredis Cluster cannot recover (slot refresh keeps
    // retrying internally) `client.connect()` never resolves, the cached
    // `clusterReconnectPromise` stays pinned, and every subsequent bzpopmin
    // call awaits the same dead promise — leaving the worker permanently
    // wedged with `isRunning: true`.
    it('throws a timeout error when cluster reconnect hangs longer than clusterReconnectTimeoutMs', async () => {
      const bzpopmin = sinon.stub().resolves(['marker', '0', '1']);
      const cluster = createMockClusterClient({
        // connect() never resolves: simulates ioredis Cluster stuck retrying
        // slot refresh internally.
        connect: sinon.stub().returns(new Promise<void>(() => {})),
        nodes: sinon.stub().returns([]), // empty pool triggers pre-call reconnect
        bzpopmin,
      });
      const connection = new RedisConnection(cluster as any, {
        blocking: true,
        skipVersionCheck: true,
        skipWaitingForReady: true,
        clusterReconnectTimeoutMs: 50,
      });

      const client = await connection.client;

      await expect((client as any).bzpopmin('marker', 1)).rejects.toThrow(
        /cluster reconnect timed out after 50ms/i,
      );
      expect(cluster.disconnect.calledOnceWith(false)).toBe(true);
      expect(cluster.connect.calledOnce).toBe(true);
      // bzpopmin must NOT be invoked when the pre-call reconnect times out;
      // otherwise it would block on the same dead cluster state.
      expect(bzpopmin.called).toBe(false);

      await connection.close(true);
    });

    it('clears the cached reconnect promise after a timeout so subsequent calls can retry', async () => {
      const bzpopmin = sinon.stub().resolves(['marker', '0', '1']);
      const cluster = createMockClusterClient({
        connect: sinon.stub().returns(new Promise<void>(() => {})),
        nodes: sinon.stub().returns([]),
        bzpopmin,
      });
      const connection = new RedisConnection(cluster as any, {
        blocking: true,
        skipVersionCheck: true,
        skipWaitingForReady: true,
        clusterReconnectTimeoutMs: 50,
      });

      const client = await connection.client;

      await expect((client as any).bzpopmin('marker', 1)).rejects.toThrow(
        /cluster reconnect timed out/i,
      );
      await expect((client as any).bzpopmin('marker', 1)).rejects.toThrow(
        /cluster reconnect timed out/i,
      );

      // The second bzpopmin must trigger a fresh disconnect + connect rather
      // than awaiting the dead promise from the first attempt.
      expect(cluster.disconnect.callCount).toBe(2);
      expect(cluster.connect.callCount).toBe(2);

      await connection.close(true);
    });
  });

  describe('connect()', () => {
    let waitUntilReadyStub: sinon.SinonStub;

    beforeEach(() => {
      waitUntilReadyStub = sinon
        .stub(RedisConnection, 'waitUntilReady')
        .resolves();
    });

    afterEach(() => {
      waitUntilReadyStub.restore();
    });

    it('skips waiting for ready when skipWaitingForReady is true', async () => {
      const connection = new RedisConnection({}, { skipWaitingForReady: true });
      const client = await connection.client;
      expect(waitUntilReadyStub.called).toBe(false);
    });

    it('awaits ready state when skipWaitingForReady is false', async () => {
      const connection = new RedisConnection(
        {},
        { skipWaitingForReady: false },
      );
      const client = await connection.client;
      expect(waitUntilReadyStub.calledOnce).toBe(true);
    });
  });

  describe('waitUntilReady()', () => {
    it('returns immediately when standalone client status is "ready"', async () => {
      const fakeClient: any = {
        status: 'ready',
        isCluster: false,
        connect: sinon.stub().resolves(),
        on: sinon.stub(),
        once: sinon.stub(),
        removeListener: sinon.stub(),
        setMaxListeners: sinon.stub(),
        getMaxListeners: sinon.stub().returns(10),
      };

      await expect(
        RedisConnection.waitUntilReady(fakeClient),
      ).resolves.toBeUndefined();
      expect(fakeClient.connect.called).toBe(false);
    });

    // Regression test for https://github.com/taskforcesh/bullmq/issues/2402.
    // ioredis Cluster reports its connected status as 'connect' rather than
    // 'ready', which previously caused waitUntilReady to hang and emit a
    // spurious "Connection is closed" error during disconnect.
    it('returns immediately when cluster client status is "connect"', async () => {
      const fakeCluster: any = {
        status: 'connect',
        isCluster: true,
        connect: sinon.stub().resolves(),
        disconnect: sinon.stub(),
        duplicate: sinon.stub(),
        on: sinon.stub(),
        once: sinon.stub(),
        removeListener: sinon.stub(),
        setMaxListeners: sinon.stub(),
        getMaxListeners: sinon.stub().returns(10),
      };

      await expect(
        RedisConnection.waitUntilReady(fakeCluster),
      ).resolves.toBeUndefined();
      expect(fakeCluster.connect.called).toBe(false);
      expect(fakeCluster.once.called).toBe(false);
    });
  });

  describe('reconnect()', () => {
    function createConnection(client: any) {
      const connection = Object.create(RedisConnection.prototype);
      Object.defineProperty(connection, 'client', {
        get: () => Promise.resolve(client),
      });
      return connection as RedisConnection;
    }

    function createClient(status: string) {
      const client = new EventEmitter() as any;
      client.status = status;
      client.isCluster = false;
      client.connect = sinon.stub().callsFake(async () => {
        client.status = 'ready';
      });
      return client;
    }

    it('does not connect from status ready', async () => {
      const client = createClient('ready');
      const connection = createConnection(client);

      await connection.reconnect();

      expect(client.connect.called).toBe(false);
    });

    it.each(['wait', 'end'])('connects from status %s', async status => {
      const client = createClient(status);
      const connection = createConnection(client);

      await connection.reconnect();

      expect(client.connect.calledOnce).toBe(true);
    });

    it.each(['connecting', 'connect', 'reconnecting'])(
      'waits for status %s to become ready',
      async status => {
        const client = createClient(status);
        const connection = createConnection(client);

        const reconnecting = connection.reconnect();
        await Promise.resolve();
        client.status = 'ready';
        client.emit('ready');
        await reconnecting;

        expect(client.connect.called).toBe(false);
      },
    );

    it.each(['close', 'closing', 'disconnecting'])(
      'connects after status %s becomes terminal',
      async status => {
        const client = createClient(status);
        const connection = createConnection(client);

        const reconnecting = connection.reconnect();
        await Promise.resolve();
        client.status = 'end';
        client.emit('end');
        await reconnecting;

        expect(client.connect.calledOnce).toBe(true);
      },
    );

    it('waits for a concurrent reconnect started from the end event', async () => {
      const client = createClient('closing');
      let resolveConnect!: () => void;
      let concurrentReconnect: Promise<void> | undefined;
      client.connect = sinon.stub().callsFake(() => {
        client.status = 'connecting';
        return new Promise<void>(resolve => {
          resolveConnect = resolve;
        });
      });
      const connection = createConnection(client);
      const waitUntilReady = sinon.spy(RedisConnection, 'waitUntilReady');

      client.once('end', () => {
        concurrentReconnect = client.connect();
      });

      let reconnectResolved = false;
      const reconnecting = connection.reconnect().then(() => {
        reconnectResolved = true;
      });
      await Promise.resolve();

      client.status = 'end';
      client.emit('end');
      await Promise.resolve();
      await Promise.resolve();

      expect(reconnectResolved).toBe(false);
      expect(waitUntilReady.callCount).toBe(2);
      client.status = 'ready';
      client.emit('ready');
      resolveConnect();

      await Promise.all([reconnecting, concurrentReconnect!]);
      expect(client.connect.calledOnce).toBe(true);
      waitUntilReady.restore();
    });
  });

  describe('Queue', () => {
    it('propagates skipWaitingForReady to RedisConnection', () => {
      const queue = new Queue('test', {
        skipWaitingForReady: true,
        connection: {},
      });
      expect(getRedisConnection(queue).extraOptions.skipWaitingForReady).to.be
        .true;
    });

    it('uses non-blocking connection by default', () => {
      const queue = new Queue('test');
      expect(getRedisConnection(queue).extraOptions.blocking).toBe(false);
    });

    it('uses shared connection if provided Redis instance', () => {
      const connection = new IORedis();

      const queue = new Queue('test', {
        connection,
      });
      expect(getRedisConnection(queue).extraOptions.shared).toBe(true);

      connection.disconnect();
    });
  });

  describe('Worker', () => {
    it('initializes blockingConnection with blocking: true', async () => {
      const worker = new Worker('test', async () => {}, { connection: {} });
      expect(getBlockingRedisConnection(worker).extraOptions.blocking).toBe(
        true,
      );
      await worker.close();
    });

    it('sets shared: false for blockingConnection', async () => {
      const connection = new IORedis({ maxRetriesPerRequest: null });

      const worker = new Worker('test', async () => {}, { connection });
      expect(getBlockingRedisConnection(worker).extraOptions.shared).toBe(
        false,
      );

      await worker.close();
      connection.disconnect();
    });

    it('uses blocking connection by default', async () => {
      const connection = new IORedis({ maxRetriesPerRequest: null });

      const worker = new Worker('test', async () => {}, { connection });

      expect(getRedisConnection(worker).extraOptions.blocking).toBe(false);
      expect(getBlockingRedisConnection(worker).extraOptions.blocking).toBe(
        true,
      );

      await worker.close();
      connection.disconnect();
    });
  });

  describe('FlowProducer', () => {
    it('uses non-blocking connection', async () => {
      const flowProducer = new FlowProducer();
      expect(getRedisConnection(flowProducer).extraOptions.blocking).toBe(
        false,
      );
      await flowProducer.close();
    });

    it('shares connection if provided Redis instance', () => {
      const connection = new IORedis();

      const flowProducer = new FlowProducer({
        connection,
      });
      expect(getRedisConnection(flowProducer).extraOptions.shared).toBe(true);

      connection.disconnect();
    });
  });

  describe('when init fails before an error listener is attached', () => {
    // Use a port where nothing is listening so init rejects quickly. A unique
    // port also lets the assertion ignore unrelated connection errors that may
    // be emitted by other tests running against the default Redis port.
    const failingPort = 59999;
    const failingConnection = {
      host: '127.0.0.1',
      port: failingPort,
      maxRetriesPerRequest: null,
      enableOfflineQueue: false,
      // Give up immediately instead of retrying so init() rejects fast.
      retryStrategy: () => null,
    };

    async function expectNoUnhandledError(
      create: () => { close: () => Promise<void> },
    ): Promise<void> {
      const leaked: any[] = [];
      const unexpected: any[] = [];
      // A failed init that is not forwarded to a listener surfaces either as an
      // 'unhandledRejection' (from the RedisConnection init catch) or as an
      // 'uncaughtException' (from the synchronous client 'error' forwarding).
      // Only classify errors from our dedicated failing port as leaked. Any
      // other unhandled error during this window must still fail the test.
      const onUnhandled = (reason: any) => {
        if (reason && reason.port === failingPort) {
          leaked.push(reason);
        } else {
          unexpected.push(reason);
        }
      };
      process.on('unhandledRejection', onUnhandled);
      process.on('uncaughtException', onUnhandled);

      let instance: { close: () => Promise<void> } | undefined;
      try {
        instance = create();
        // Wait long enough for init() to reject during the window before any
        // 'error' listener is attached.
        await new Promise(resolve => setTimeout(resolve, 500));
      } finally {
        if (instance) {
          await instance.close().catch(() => undefined);
        }
        process.removeListener('unhandledRejection', onUnhandled);
        process.removeListener('uncaughtException', onUnhandled);
      }

      expect(leaked).toHaveLength(0);
      expect(unexpected).toHaveLength(0);
    }

    it('does not leak an unhandled error for a Worker', async () => {
      await expectNoUnhandledError(
        () =>
          new Worker('test-connection-init-failure', async () => {}, {
            connection: failingConnection,
            autorun: false,
          }),
      );
    });

    it('does not leak an unhandled error for a Queue', async () => {
      await expectNoUnhandledError(
        () =>
          new Queue('test-connection-init-failure', {
            connection: failingConnection,
          }),
      );
    });

    it('does not leak an unhandled error for a FlowProducer', async () => {
      await expectNoUnhandledError(
        () =>
          new FlowProducer({
            connection: failingConnection,
          }),
      );
    });
  });
});

describe('connection', () => {
  const redisHost = process.env.REDIS_HOST || 'localhost';
  const prefix = process.env.BULLMQ_TEST_PREFIX || 'bull';
  let queue: Queue;
  let queueName: string;

  let connection: IORedis;
  beforeAll(async () => {
    connection = new IORedis(redisHost, { maxRetriesPerRequest: null });
  });

  beforeEach(async () => {
    queueName = `test-${randomUUID()}`;
    queue = new Queue(queueName, { connection, prefix });
  });

  afterEach(async () => {
    await queue.close();
    await removeAllQueueData(new IORedis(redisHost), queueName);
  });

  afterAll(async function () {
    await connection.quit();
  });

  describe('establish ioredis connection', () => {
    it('should connect with host:port', async () => {
      const queue = new Queue('valid-host-port', {
        connection: {
          host: 'localhost',
          port: 6379,
          retryStrategy: () => null,
        },
      });

      const client = await getRedisClient(queue);
      expect(client.status).toEqual('ready');

      await queue.close();
    });

    it('should fail with invalid host:port', async () => {
      const queue = new Queue('invalid-host-port', {
        connection: {
          host: 'localhost',
          port: 9000,
          retryStrategy: () => null,
        },
      });

      try {
        await queue.waitUntilReady();
      } catch (error) {
        expect(error.code).toBe('ECONNREFUSED');
      }
    });

    it('should connect with connection URL', async () => {
      const queue = new Queue('valid-url', {
        connection: {
          url: 'redis://localhost:6379',
          // Make sure defaults are not being used
          host: '1.1.1.1',
          port: 2222,
          retryStrategy: () => null,
        },
      });

      const client = await getRedisClient(queue);
      expect(client.status).toEqual('ready');

      await queue.close();
    });

    it('should fail with invalid connection URL', async () => {
      const queue = new Queue('invalid-url', {
        connection: {
          url: 'redis://localhost:9001',
          // Make sure defaults are not being used
          host: '1.1.1.1',
          port: 2222,
          retryStrategy: () => null,
        },
      });

      try {
        await queue.waitUntilReady();
      } catch (error) {
        expect(error.code).toBe('ECONNREFUSED');
      }
    });
  });

  describe('prefix', () => {
    it('should throw exception if using prefix with ioredis', async () => {
      const connection = new IORedis({
        host: redisHost,
        keyPrefix: 'bullmq',
      });

      expect(() => new QueueBase(queueName, { connection })).toThrow(
        'BullMQ: ioredis does not support ioredis prefixes, use the prefix option instead.',
      );
      await connection.disconnect();
    });

    it('should throw exception if using prefix with ioredis in cluster mode', async () => {
      const connection = new IORedis.Cluster(
        [{ host: '10.0.6.161', port: 7379 }],
        {
          keyPrefix: 'bullmq',
          natMap: {},
        },
      );

      expect(() => new QueueBase(queueName, { connection })).toThrow(
        'BullMQ: ioredis does not support ioredis prefixes, use the prefix option instead.',
      );
      await connection.disconnect();
    });
  });

  describe('blocking', () => {
    it('should override maxRetriesPerRequest: null as redis options', async () => {
      if (redisHost === 'localhost') {
        // We cannot currently test this behaviour for remote redis servers
        const queue = new QueueBase(queueName, {
          connection: { host: 'localhost' },
        });

        const options = connection.options;

        expect(options.maxRetriesPerRequest).toBe(null);

        await queue.close();
      }
    });
  });

  describe('non-blocking', () => {
    it('should not override any redis options', async () => {
      const connection2 = new IORedis(redisHost, { maxRetriesPerRequest: 20 });

      const queue = new Queue(queueName, {
        connection: connection2,
      });

      const options = <RedisOptions>(await getRedisClient(queue)).options;

      expect(options.maxRetriesPerRequest).toBe(20);

      await queue.close();
      await connection2.quit();
    });
  });

  describe('when maxmemory-policy is different than noeviction in Redis', () => {
    it.skip('throws an error', async () => {
      const opts = {
        connection: {
          host: 'localhost',
        },
      };

      const queue = new Queue(queueName, opts);
      const client = await getRedisClient(queue);
      await client.config('SET', 'maxmemory-policy', 'volatile-lru');

      const queue2 = new Queue(`${queueName}2`, opts);

      await expect(getRedisClient(queue2)).to.be.eventually.rejectedWith(
        'Eviction policy is volatile-lru. It should be "noeviction"',
      );
      await client.config('SET', 'maxmemory-policy', 'noeviction');

      await queue.close();
      await queue2.close();
    });
  });

  describe('when instantiating with a clustered ioredis connection', () => {
    it('should not fail when using dsn strings', async () => {
      const connection = new IORedis.Cluster(['redis://10.0.6.161:7379'], {
        natMap: {},
      });
      const queue = new Queue('myqueue', { connection });
      connection.disconnect();
    });
  });

  it('should close worker even if redis is down', async () => {
    const connection = new IORedis('badhost', { maxRetriesPerRequest: null });
    connection.on('error', () => {});

    const worker = new Worker('test', async () => {}, { connection, prefix });

    worker.on('error', err => {});
    await worker.close();
  });

  it('should close underlying redis connection when closing fast', async () => {
    const queue = new Queue('CALLS_JOB_QUEUE_NAME', {
      connection: {
        host: 'localhost',
        port: 6379,
      },
    });

    const client = getRedisConnection(queue)['_client'];
    await queue.close();

    expect(client.status).toEqual('end');
  });

  it('should recover from a connection loss', async () => {
    let processor;

    const processing = new Promise<void>(resolve => {
      processor = async (job: Job) => {
        expect(job.data.foo).toBe('bar');
        resolve();
      };
    });

    const worker = new Worker(queueName, processor, { connection, prefix });

    worker.on('error', err => {
      // error event has to be observed or the exception will bubble up
    });

    queue.on('error', (err: Error) => {
      // error event has to be observed or the exception will bubble up
    });

    const workerClient = await getRedisClient(worker);
    const queueClient = await getRedisClient(queue);

    // Simulate disconnect
    (<any>queueClient).stream.end();
    queueClient.emit('error', new Error('ECONNRESET'));

    (<any>workerClient).stream.end();
    workerClient.emit('error', new Error('ECONNRESET'));

    // add something to the queue
    await queue.add('test', { foo: 'bar' }, { delay: 2000 });

    await processing;
    await worker.close();
  });

  it('should handle jobs added before and after a redis disconnect', async () => {
    let count = 0;
    let processor;

    const processing = new Promise<void>((resolve, reject) => {
      processor = async (job: Job) => {
        try {
          if (count == 0) {
            expect(job.data.foo).toBe('bar');
          } else {
            resolve();
          }
          count++;
        } catch (err) {
          reject(err);
        }
      };
    });

    const worker = new Worker(queueName, processor, { connection, prefix });

    worker.on('error', err => {
      // error event has to be observed or the exception will bubble up
    });

    queue.on('error', (err: Error) => {
      // error event has to be observed or the exception will bubble up
    });

    await worker.waitUntilReady();

    worker.on('completed', async () => {
      if (count === 1) {
        const workerClient = await getRedisClient(worker);
        const queueClient = await getRedisClient(queue);

        (<any>queueClient).stream.end();
        queueClient.emit('error', new Error('ECONNRESET'));

        (<any>workerClient).stream.end();
        workerClient.emit('error', new Error('ECONNRESET'));

        await queue.add('test', { foo: 'bar' });
      }
    });

    await queue.waitUntilReady();
    await queue.add('test', { foo: 'bar' });

    await processing;

    await worker.close();
  });

  /*
  it('should not close external connections', () => {
    const client = new redis();
    const subscriber = new redis();

    const opts = {
      createClient(type) {
        switch (type) {
          case 'client':
            return client;
          case 'subscriber':
            return subscriber;
          default:
            return new redis();
        }
      },
    };

    const testQueue = utils.buildQueue('external connections', opts);

    return testQueue
      .isReady()
      .then(() => {
        return testQueue.add({ foo: 'bar' });
      })
      .then(() => {
        expect(testQueue.client).toEqual(client);
        expect(testQueue.eclient).toEqual(subscriber);

        return testQueue.close();
      })
      .then(() => {
        expect(client.status).toEqual('ready');
        expect(subscriber.status).toEqual('ready');
        return Promise.all([client.quit(), subscriber.quit()]);
      });
  });
  */

  it('should fail if redis connection fails', async () => {
    const queueFail = new Queue('connection fail port', {
      connection: { port: 1234, host: '127.0.0.1', retryStrategy: () => null },
    });

    await expect(queueFail.waitUntilReady()).rejects.toThrow(
      'connect ECONNREFUSED 127.0.0.1:1234',
    );
  });

  it('should emit error if redis connection fails', async () => {
    const queueFail = new Queue('connection fail port', {
      connection: { port: 1234, host: '127.0.0.1', retryStrategy: () => null },
    });

    const waitingErrorEvent = new Promise<void>((resolve, reject) => {
      queueFail.on('error', (err: Error) => {
        try {
          expect(err.message).toBe('connect ECONNREFUSED 127.0.0.1:1234');
          resolve();
        } catch (err) {
          reject(err);
        }
      });
    });

    await waitingErrorEvent;
  });

  it('should close if connection has failed', async () => {
    const queueFail = new Queue('connection fail port', {
      connection: { port: 1234, host: '127.0.0.1', retryStrategy: () => null },
    });

    queueFail.on('error', () => {});

    await expect(queueFail.waitUntilReady()).rejects.toThrow(
      'connect ECONNREFUSED 127.0.0.1:1234',
    );

    await expect(queueFail.close()).resolves.toBeUndefined();
  });

  it('should close if connection is failing', async () => {
    const queueFail = new Queue('connection fail port', {
      connection: {
        port: 1234,
        host: '127.0.0.1',
        retryStrategy: times => (times === 0 ? 10 : null),
      },
    });

    await expect(queueFail.waitUntilReady()).rejects.toThrow(
      'connect ECONNREFUSED 127.0.0.1:1234',
    );

    await expect(queueFail.close()).resolves.toBeUndefined();
  });
});
