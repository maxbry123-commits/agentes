import {
  describe,
  beforeEach,
  afterEach,
  beforeAll,
  afterAll,
  it,
  expect,
} from 'vitest';

import { Queue, QueueEvents, Worker, Job } from '../src/classes';
import { delay, randomUUID } from '../src/utils';
import { createTestConnection } from './utils/connection-factory';
import { cleanupQueue } from './utils/cleanup-queue';
import { IRedisClient } from '../src/interfaces';

/**
 * Backend-agnostic qualified queue name. Derives the qualifier (the `bull:`
 * prefix on Redis, or nothing on PostgreSQL) from a reference queue whose
 * `qualifiedName` is known, so parent key references hold on any backend.
 */
const qualify = (
  ref: { qualifiedName: string; name: string },
  queueName: string,
): string =>
  `${ref.qualifiedName.slice(
    0,
    ref.qualifiedName.length - ref.name.length,
  )}${queueName}`;

describe('bulk jobs', () => {
  const prefix = process.env.BULLMQ_TEST_PREFIX || 'bull';

  let queue: Queue;
  let queueName: string;

  let connection: IRedisClient;
  beforeAll(async () => {
    connection = createTestConnection();
  });

  beforeEach(async () => {
    queueName = `test-${randomUUID()}`;
    queue = new Queue(queueName, { connection, prefix });
  });

  afterEach(async () => {
    await queue.close();
    await cleanupQueue(queueName);
  });

  afterAll(async () => {
    await connection.quit();
  });

  it('should process jobs', async () => {
    const name = 'test';
    let processor;
    const processing = new Promise<void>(
      resolve =>
        (processor = async (job: Job) => {
          if (job.data.idx === 0) {
            expect(job.data.foo).toBe('bar');
          } else {
            expect(job.data.idx).toBe(1);
            expect(job.data.foo).toBe('baz');
            resolve();
          }
        }),
    );
    const worker = new Worker(queueName, processor, { connection, prefix });
    await worker.waitUntilReady();

    const jobs = await queue.addBulk([
      { name, data: { idx: 0, foo: 'bar' } },
      { name, data: { idx: 1, foo: 'baz' } },
    ]);
    expect(jobs).toHaveLength(2);

    expect(jobs[0].id).toBeTruthy();
    expect(jobs[0].data.foo).toEqual('bar');
    expect(jobs[1].id).toBeTruthy();
    expect(jobs[1].data.foo).toEqual('baz');

    await processing;
    await worker.close();
  });

  it('should allow to pass parent option', async () => {
    const name = 'test';
    const parentQueueName = `parent-queue-${randomUUID()}`;
    const parentQueue = new Queue(parentQueueName, { connection, prefix });

    const parentWorker = new Worker(parentQueueName, null, {
      connection,
      prefix,
    });
    const childrenWorker = new Worker(queueName, null, { connection, prefix });
    await parentWorker.waitUntilReady();
    await childrenWorker.waitUntilReady();

    const parent = await parentQueue.add('parent', { some: 'data' });
    const jobs = await queue.addBulk([
      {
        name,
        data: { idx: 0, foo: 'bar' },
        opts: {
          parent: {
            id: parent.id!,
            queue: `${qualify(queue, parentQueueName)}`,
          },
        },
      },
      {
        name,
        data: { idx: 1, foo: 'baz' },
        opts: {
          parent: {
            id: parent.id!,
            queue: `${qualify(queue, parentQueueName)}`,
          },
        },
      },
    ]);
    expect(jobs).toHaveLength(2);

    expect(jobs[0].id).toBeTruthy();
    expect(jobs[0].data.foo).toEqual('bar');
    expect(jobs[1].id).toBeTruthy();
    expect(jobs[1].data.foo).toEqual('baz');

    const { unprocessed } = await parent.getDependenciesCount({
      unprocessed: true,
    });

    expect(unprocessed).toBe(2);

    await childrenWorker.close();
    await parentWorker.close();
    await parentQueue.close();
    await cleanupQueue(parentQueueName);
  });

  it('should keep workers busy', { timeout: 10_000 }, async () => {
    const numJobs = 6;
    const queueEvents = new QueueEvents(queueName, { connection, prefix });
    await queueEvents.waitUntilReady();

    const worker = new Worker(
      queueName,
      async () => {
        await delay(900);
      },
      { connection, prefix },
    );
    const worker2 = new Worker(
      queueName,
      async () => {
        await delay(900);
      },
      { connection, prefix },
    );
    await worker.waitUntilReady();
    await worker2.waitUntilReady();

    let counter = 0;
    const completed = new Promise<void>(resolve => {
      queueEvents.on('completed', () => {
        counter++;
        if (counter === numJobs) {
          resolve();
        }
      });
    });

    const jobs = Array.from(Array(numJobs).keys()).map(index => ({
      name: 'test',
      data: { index },
    }));

    await queue.addBulk(jobs);

    await completed;
    await worker.close();
    await worker2.close();
    await queueEvents.close();
  });

  it('should process jobs with custom ids', async () => {
    const name = 'test';
    let processor;
    const processing = new Promise<void>(
      resolve =>
        (processor = async (job: Job) => {
          if (job.data.idx === 0) {
            expect(job.data.foo).toBe('bar');
          } else {
            expect(job.data.idx).toBe(1);
            expect(job.data.foo).toBe('baz');
            resolve();
          }
        }),
    );
    const worker = new Worker(queueName, processor, { connection, prefix });
    await worker.waitUntilReady();

    const jobs = await queue.addBulk([
      { name, data: { idx: 0, foo: 'bar' }, opts: { jobId: 'test1' } },
      { name, data: { idx: 1, foo: 'baz' }, opts: { jobId: 'test2' } },
    ]);
    expect(jobs).toHaveLength(2);

    expect(jobs[0].id).toEqual('test1');
    expect(jobs[0].data.foo).toEqual('bar');
    expect(jobs[1].id).toEqual('test2');
    expect(jobs[1].data.foo).toEqual('baz');

    await processing;
    await worker.close();
  });
});
