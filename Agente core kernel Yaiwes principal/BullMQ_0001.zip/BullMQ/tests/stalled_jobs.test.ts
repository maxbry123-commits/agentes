import { getRedisClient } from './utils/get-redis-client';
import { FlowProducer, Queue, Worker, QueueEvents } from '../src/classes';
import { delay, randomUUID } from '../src/utils';
import { after } from './utils/lodash';
import {
  describe,
  beforeEach,
  afterEach,
  beforeAll,
  afterAll,
  it,
  expect,
} from 'vitest';
import { createTestConnection } from './utils/connection-factory';
import { cleanupQueue } from './utils/cleanup-queue';
import { IRedisClient } from '../src/interfaces';

const NoopProc = () => Promise.resolve();

/**
 * Backend-agnostic qualified queue name (the `bull:` prefix on Redis, nothing
 * on PostgreSQL), derived from a reference queue's `qualifiedName`.
 */
const qualify = (
  ref: { qualifiedName: string; name: string },
  queueName: string,
): string =>
  `${ref.qualifiedName.slice(
    0,
    ref.qualifiedName.length - ref.name.length,
  )}${queueName}`;

describe('stalled jobs', () => {
  const prefix = process.env.BULLMQ_TEST_PREFIX || 'bull';
  let queue: Queue;
  let queueName: string;

  let connection: IRedisClient;
  beforeAll(async () => {
    connection = createTestConnection();
  });

  beforeEach(async () => {
    queueName = `test-${randomUUID()}`;
    queue = new Queue(queueName, { connection, prefix });
  });

  afterEach(async () => {
    await queue.close();
    await cleanupQueue(queueName);
  });

  afterAll(async function () {
    await connection.quit();
  });

  it('process stalled jobs when starting a queue', async () => {
    // TODO: Move timeout to test options: { timeout: 5000 }

    const queueEvents = new QueueEvents(queueName, { connection, prefix });
    await queueEvents.waitUntilReady();

    const concurrency = 4;

    const worker = new Worker(
      queueName,
      async () => {
        return delay(10000);
      },
      {
        connection,
        prefix,
        lockDuration: 1000,
        stalledInterval: 100,
        concurrency,
      },
    );

    const allActive = new Promise(resolve => {
      worker.on('active', after(concurrency, resolve));
    });

    await worker.waitUntilReady();

    await Promise.all([
      queue.add('test', { bar: 'baz' }),
      queue.add('test', { bar1: 'baz1' }),
      queue.add('test', { bar2: 'baz2' }),
      queue.add('test', { bar3: 'baz3' }),
    ]);

    await allActive;
    await worker.close(true);

    const worker2 = new Worker(queueName, NoopProc, {
      connection,
      prefix,
      stalledInterval: 100,
      concurrency,
    });

    const allStalledGlobalEvent = new Promise(resolve => {
      queueEvents.on('stalled', after(concurrency, resolve));
    });

    const allStalled = new Promise<void>(resolve => {
      worker2.on(
        'stalled',
        after(concurrency, (jobId, prev) => {
          expect(prev).toBe('active');
          resolve();
        }),
      );
    });

    await allStalled;
    await allStalledGlobalEvent;

    const allCompleted = new Promise<void>(resolve => {
      worker2.on(
        'completed',
        after(concurrency, job => {
          expect(job.stalledCounter).toBe(1);
          resolve();
        }),
      );
    });

    await allCompleted;

    await queueEvents.close();
    await worker2.close();
  });

  it("don't process stalled jobs when starting a queue with skipStalledCheck", async function () {
    const concurrency = 4;

    const worker = new Worker(
      queueName,
      async () => {
        return delay(1000);
      },
      {
        connection,
        prefix,
        stalledInterval: 50,
        skipStalledCheck: true,
        concurrency,
      },
    );

    const allCompleted = new Promise(resolve => {
      worker.on('completed', after(concurrency, resolve));
    });

    await Promise.all([
      queue.add('test', { bar: 'baz' }),
      queue.add('test', { bar1: 'baz1' }),
      queue.add('test', { bar2: 'baz2' }),
      queue.add('test', { bar3: 'baz3' }),
    ]);

    await allCompleted;
    await worker.close();
  });

  describe('when stalled jobs stall more than allowable stalled limit', () => {
    it('moves jobs to failed', async () => {
      // TODO: Move timeout to test options: { timeout: 6000 }

      const queueEvents = new QueueEvents(queueName, { connection, prefix });
      await queueEvents.waitUntilReady();

      const concurrency = 4;

      const worker = new Worker(
        queueName,
        async () => {
          return delay(10000);
        },
        {
          connection,
          prefix,
          lockDuration: 1000,
          stalledInterval: 100,
          maxStalledCount: 0,
          concurrency,
        },
      );

      const allActive = new Promise(resolve => {
        worker.on('active', after(concurrency, resolve));
      });

      await worker.waitUntilReady();

      await Promise.all([
        queue.add('test', { bar: 'baz' }),
        queue.add('test', { bar1: 'baz1' }),
        queue.add('test', { bar2: 'baz2' }),
        queue.add('test', { bar3: 'baz3' }),
      ]);

      await allActive;

      await worker.close(true);

      const worker2 = new Worker(queueName, NoopProc, {
        connection,
        prefix,
        stalledInterval: 100,
        maxStalledCount: 0,
        concurrency,
      });

      const errorMessage = 'job stalled more than allowable limit';
      const allFailed = new Promise<void>(resolve => {
        worker2.on(
          'failed',
          after(concurrency, async (job, failedReason, prev) => {
            expect(job?.finishedOn).toBeTypeOf('number');
            expect(job?.attemptsStarted).toBe(2);
            expect(job?.attemptsMade).toBe(1);
            expect(job?.stalledCounter).toBe(1);
            expect(prev).toBe('active');
            expect(failedReason.message).toBe(errorMessage);
            resolve();
          }),
        );
      });

      const globalAllFailed = new Promise<void>(resolve => {
        queueEvents.on('failed', ({ failedReason }) => {
          expect(failedReason).toBe(errorMessage);
          resolve();
        });
      });

      await allFailed;
      await globalAllFailed;

      await queueEvents.close();
      await worker2.close();
    });

    describe('when retrying jobs', () => {
      it('keeps stalledCounter', async () => {
        // TODO: Move timeout to test options: { timeout: 6000 }

        const queueEvents = new QueueEvents(queueName, { connection, prefix });
        await queueEvents.waitUntilReady();

        const concurrency = 4;

        const worker = new Worker(
          queueName,
          async () => {
            return delay(10000);
          },
          {
            connection,
            prefix,
            lockDuration: 1000,
            stalledInterval: 100,
            maxStalledCount: 0,
            concurrency,
          },
        );

        const allActive = new Promise<void>(resolve => {
          worker.on('active', after(concurrency, resolve));
        });

        await worker.waitUntilReady();

        const jobs = await Promise.all([
          queue.add('test', { bar: 'baz' }),
          queue.add('test', { bar1: 'baz1' }),
          queue.add('test', { bar2: 'baz2' }),
          queue.add('test', { bar3: 'baz3' }),
        ]);

        await allActive;

        await worker.close(true);

        const worker2 = new Worker(queueName, NoopProc, {
          connection,
          prefix,
          stalledInterval: 100,
          maxStalledCount: 0,
          concurrency,
        });

        const errorMessage = 'job stalled more than allowable limit';
        const allFailed = new Promise<void>(resolve => {
          worker2.on(
            'failed',
            after(concurrency, async (job, failedReason, prev) => {
              expect(job?.attemptsStarted).toBe(2);
              expect(job?.attemptsMade).toBe(1);
              expect(job?.stalledCounter).toBe(1);
              expect(prev).toBe('active');
              expect(failedReason.message).toBe(errorMessage);
              resolve();
            }),
          );
        });

        const allCompleted = new Promise<void>(resolve => {
          worker2.on(
            'completed',
            after(concurrency, async (job, result) => {
              expect(job?.attemptsStarted).toBe(3);
              expect(job?.attemptsMade).toBe(2);
              expect(job?.stalledCounter).toBe(1);
              resolve();
            }),
          );
        });

        const globalAllFailed = new Promise<void>(resolve => {
          queueEvents.on('failed', ({ failedReason }) => {
            expect(failedReason).toBe(errorMessage);
            resolve();
          });
        });

        await allFailed;
        await globalAllFailed;

        for (const job of jobs) {
          await job.retry();
        }

        await allCompleted;

        await queueEvents.close();
        await worker2.close();
      });
    });

    it('moves jobs to failed with maxStalledCount > 1', async () => {
      // TODO: Move timeout to test options: { timeout: 8000 }

      const queueEvents = new QueueEvents(queueName, { connection, prefix });
      await queueEvents.waitUntilReady();

      const concurrency = 4;
      const maxStalledCount = 2;

      const jobs = await Promise.all([
        queue.add('test', { bar: 'baz' }, { removeOnFail: true }),
        queue.add('test', { bar1: 'baz1' }, { removeOnFail: true }),
        queue.add('test', { bar2: 'baz2' }, { removeOnFail: true }),
        queue.add('test', { bar3: 'baz3' }, { removeOnFail: true }),
      ]);

      for (let i = 0; i <= maxStalledCount + 1; i++) {
        const worker = new Worker(
          queueName,
          async () => {
            return delay(10000);
          },
          {
            connection,
            prefix,
            lockDuration: 1000,
            stalledInterval: 100,
            maxStalledCount,
            concurrency,
          },
        );

        if (i <= maxStalledCount) {
          const allActive = new Promise(resolve => {
            worker.on('active', after(concurrency, resolve));
          });

          await worker.waitUntilReady();
          await allActive;
        } else {
          const errorMessage = 'job stalled more than allowable limit';
          const allFailed = new Promise<void>(resolve => {
            worker.on(
              'failed',
              after(concurrency, async (job, failedReason, prev) => {
                expect(job?.attemptsStarted).toBe(4);
                expect(job?.attemptsMade).toBe(1);
                expect(job?.stalledCounter).toBe(3);
                expect(prev).toBe('active');
                expect(failedReason.message).toBe(errorMessage);
                resolve();
              }),
            );
          });

          const globalAllFailed = new Promise<void>(resolve => {
            queueEvents.on('failed', ({ failedReason }) => {
              expect(failedReason).toBe(errorMessage);
              resolve();
            });
          });

          await allFailed;
          await globalAllFailed;

          for (let i = 0; i < jobs.length; i++) {
            const stored = await queue.getJob(jobs[i].id!);
            expect(stored).toBeUndefined();
          }
        }

        await worker.close(true);
      }

      await queueEvents.close();
    });

    describe('when failParentOnFailure is provided as true', () => {
      it('should move parent to failed when child is moved to failed', async () => {
        // TODO: Move timeout to test options: { timeout: 6000 }
        const concurrency = 4;
        const parentQueueName = `parent-queue-${randomUUID()}`;

        const parentQueue = new Queue(parentQueueName, {
          connection,
          prefix,
        });

        const flow = new FlowProducer({ connection, prefix });

        const worker = new Worker(
          queueName,
          async () => {
            return delay(10000);
          },
          {
            connection,
            prefix,
            lockDuration: 1000,
            stalledInterval: 100,
            maxStalledCount: 0,
            concurrency,
          },
        );
        const parentWorker = new Worker(parentQueueName, async () => {}, {
          connection,
          prefix,
        });

        const allActive = new Promise(resolve => {
          worker.on('active', after(concurrency, resolve));
        });

        await worker.waitUntilReady();
        await parentWorker.waitUntilReady();

        const { children } = await flow.add({
          name: 'parent-job',
          queueName: parentQueueName,
          data: {},
          children: [
            {
              name: 'test',
              data: { foo: 'bar' },
              queueName,
              opts: { failParentOnFailure: true },
            },
          ],
        });

        const jobs = Array.from(Array(3).keys()).map(index => ({
          name: 'test',
          data: { index },
        }));

        await queue.addBulk(jobs);
        await allActive;
        await worker.close(true);

        const worker2 = new Worker(queueName, NoopProc, {
          connection,
          prefix,
          stalledInterval: 100,
          maxStalledCount: 0,
          concurrency,
        });

        const errorMessage = 'job stalled more than allowable limit';
        const allFailed = new Promise<void>(resolve => {
          worker2.on(
            'failed',
            after(concurrency, async (job, failedReason, prev) => {
              expect(prev).toBe('active');
              expect(failedReason.message).toBe(errorMessage);
              resolve();
            }),
          );
        });

        const parentFailure = new Promise<void>(resolve => {
          parentWorker.once('failed', async (job, failedReason, prev) => {
            expect(prev).toBe('active');
            expect(failedReason.message).toBe(
              `child ${qualify(queue, queueName)}:${children[0].job.id!} failed`,
            );
            resolve();
          });
        });
        await allFailed;
        await parentFailure;

        await worker2.close();
        await parentWorker.close();
        await parentQueue.close();
        await flow.close();
        await cleanupQueue(parentQueueName);
      });
    });

    describe('when continueParentOnFailure is provided as true', () => {
      it('should start processing parent when child is moved to failed', async () => {
        // TODO: Move timeout to test options: { timeout: 6000 }
        const concurrency = 4;
        const parentQueueName = `parent-queue-${randomUUID()}`;

        const parentQueue = new Queue(parentQueueName, {
          connection,
          prefix,
        });

        const flow = new FlowProducer({ connection, prefix });

        const worker = new Worker(
          queueName,
          async () => {
            return delay(10000);
          },
          {
            connection,
            prefix,
            lockDuration: 1000,
            stalledInterval: 100,
            maxStalledCount: 0,
            concurrency,
          },
        );

        const allActive = new Promise(resolve => {
          worker.on('active', after(concurrency, resolve));
        });

        await worker.waitUntilReady();

        const { job: parent } = await flow.add({
          name: 'parent-job',
          queueName: parentQueueName,
          data: {},
          children: [
            {
              name: 'test',
              data: { foo: 'bar' },
              queueName,
              opts: { continueParentOnFailure: true },
            },
          ],
        });

        const jobs = Array.from(Array(3).keys()).map(index => ({
          name: 'test',
          data: { index },
        }));

        await queue.addBulk(jobs);
        await allActive;
        await worker.close(true);

        const worker2 = new Worker(queueName, NoopProc, {
          connection,
          prefix,
          stalledInterval: 100,
          maxStalledCount: 0,
          concurrency,
        });

        const errorMessage = 'job stalled more than allowable limit';
        const allFailed = new Promise<void>((resolve, reject) => {
          worker2.on(
            'failed',
            after(concurrency, async (job, failedReason, prev) => {
              try {
                const parentState = await parent.getState();
                expect(parentState).toBe('waiting');
                expect(prev).toBe('active');
                expect(failedReason.message).toBe(errorMessage);
                resolve();
              } catch (err) {
                reject(err);
              }
            }),
          );
        });

        await allFailed;

        await worker2.close();
        await parentQueue.close();
        await flow.close();
        await cleanupQueue(parentQueueName);
      });
    });

    describe('when ignoreDependencyOnFailure is provided as true', () => {
      it('should move parent to waiting when child is moved to failed and save child failedReason', async () => {
        // TODO: Move timeout to test options: { timeout: 6000 }
        const concurrency = 4;
        const parentQueueName = `parent-queue-${randomUUID()}`;

        const parentQueue = new Queue(parentQueueName, {
          connection,
          prefix,
        });

        const flow = new FlowProducer({ connection, prefix });

        const worker = new Worker(
          queueName,
          async () => {
            return delay(10000);
          },
          {
            connection,
            prefix,
            lockDuration: 1000,
            stalledInterval: 100,
            maxStalledCount: 0,
            concurrency,
          },
        );

        const allActive = new Promise(resolve => {
          worker.on('active', after(concurrency, resolve));
        });

        await worker.waitUntilReady();

        const { job: parent, children } = await flow.add({
          name: 'parent-job',
          queueName: parentQueueName,
          data: {},
          children: [
            {
              name: 'test',
              data: { foo: 'bar' },
              queueName,
              opts: { ignoreDependencyOnFailure: true },
            },
          ],
        });

        const jobs = Array.from(Array(3).keys()).map(index => ({
          name: 'test',
          data: { index },
        }));

        await queue.addBulk(jobs);
        await allActive;
        await worker.close(true);

        const worker2 = new Worker(queueName, NoopProc, {
          connection,
          prefix,
          stalledInterval: 100,
          maxStalledCount: 0,
          concurrency,
        });

        const errorMessage = 'job stalled more than allowable limit';
        const allFailed = new Promise<void>(resolve => {
          worker2.on(
            'failed',
            after(concurrency, async (job, failedReason, prev) => {
              const parentState = await parent.getState();

              expect(parentState).toBe('waiting');
              expect(prev).toBe('active');
              expect(failedReason.message).toBe(errorMessage);
              resolve();
            }),
          );
        });

        await allFailed;
        const ignoredChildrenValues = await parent.getIgnoredChildrenFailures();
        expect(ignoredChildrenValues).toEqual({
          [`${queue.qualifiedName}:${children[0].job.id}`]:
            'job stalled more than allowable limit',
        });

        await worker2.close();
        await parentQueue.close();
        await flow.close();
        await cleanupQueue(parentQueueName);
      });
    });

    describe('when removeDependencyOnFailure is provided as true', () => {
      it('should move parent to waiting when child is moved to failed', async () => {
        // TODO: Move timeout to test options: { timeout: 6000 }
        const concurrency = 4;
        const parentQueueName = `parent-queue-${randomUUID()}`;

        const parentQueue = new Queue(parentQueueName, {
          connection,
          prefix,
        });

        const flow = new FlowProducer({ connection, prefix });

        const worker = new Worker(
          queueName,
          async () => {
            return delay(10000);
          },
          {
            connection,
            prefix,
            lockDuration: 1000,
            stalledInterval: 100,
            maxStalledCount: 0,
            concurrency,
          },
        );

        const allActive = new Promise(resolve => {
          worker.on('active', after(concurrency, resolve));
        });

        await worker.waitUntilReady();

        const { job: parent } = await flow.add({
          name: 'parent-job',
          queueName: parentQueueName,
          data: {},
          children: [
            {
              name: 'test',
              data: { foo: 'bar' },
              queueName,
              opts: { removeDependencyOnFailure: true },
            },
          ],
        });

        const jobs = Array.from(Array(3).keys()).map(index => ({
          name: 'test',
          data: { index },
        }));

        await queue.addBulk(jobs);
        await allActive;
        await worker.close(true);

        const worker2 = new Worker(queueName, NoopProc, {
          connection,
          prefix,
          stalledInterval: 100,
          maxStalledCount: 0,
          concurrency,
        });

        const errorMessage = 'job stalled more than allowable limit';
        const allFailed = new Promise<void>(resolve => {
          worker2.on(
            'failed',
            after(concurrency, async (job, failedReason, prev) => {
              const parentState = await parent.getState();

              expect(parentState).toBe('waiting');
              expect(prev).toBe('active');
              expect(failedReason.message).toBe(errorMessage);
              resolve();
            }),
          );
        });

        await allFailed;

        await worker2.close();
        await parentQueue.close();
        await flow.close();
        await cleanupQueue(parentQueueName);
      });
    });

    describe('when removeOnFail is provided as a number', () => {
      it('keeps the specified number of jobs in failed', async () => {
        // TODO: Move timeout to test options: { timeout: 6000 }
        const concurrency = 4;

        const worker = new Worker(
          queueName,
          async () => {
            return delay(10000);
          },
          {
            connection,
            prefix,
            lockDuration: 1000,
            stalledInterval: 100,
            maxStalledCount: 0,
            concurrency,
          },
        );

        const allActive = new Promise(resolve => {
          worker.on('active', after(concurrency, resolve));
        });

        await worker.waitUntilReady();

        const jobs = Array.from(Array(4).keys()).map(index => ({
          name: 'test',
          data: { index },
          opts: {
            removeOnFail: 3,
          },
        }));

        await queue.addBulk(jobs);

        await allActive;

        await worker.close(true);

        const worker2 = new Worker(queueName, NoopProc, {
          connection,
          prefix,
          stalledInterval: 100,
          maxStalledCount: 0,
          concurrency,
        });

        const errorMessage = 'job stalled more than allowable limit';
        // The order in which the four stalled jobs are reprocessed (and hence
        // which one is trimmed by `removeOnFail: 3`) is backend-specific, so we
        // assert order-independently: every job fails as stalled, and the
        // failed set ends up capped at the configured 3.
        const failedIndices: number[] = [];
        const allFailed = new Promise<void>((resolve, reject) => {
          worker2.on('failed', async (job, failedReason, prev) => {
            try {
              expect(prev).toBe('active');
              expect(failedReason.message).toBe(errorMessage);

              failedIndices.push(job.data.index);
              if (failedIndices.length === concurrency) {
                const failedCount = await queue.getFailedCount();
                expect(failedCount).toBe(3);
                resolve();
              }
            } catch (err) {
              reject(err);
            }
          });
        });

        await allFailed;

        await worker2.close();
      });
    });

    describe('when removeOnFail is provided as boolean', () => {
      describe('when removeOnFail is provided as true', () => {
        it('removes all job keys', async () => {
          // TODO: Move timeout to test options: { timeout: 6000 }

          const queueEvents = new QueueEvents(queueName, {
            connection,
            prefix,
          });
          await queueEvents.waitUntilReady();

          const concurrency = 4;

          const worker = new Worker(
            queueName,
            async () => {
              return delay(10000);
            },
            {
              connection,
              prefix,
              lockDuration: 1000,
              stalledInterval: 100,
              maxStalledCount: 0,
              concurrency,
            },
          );

          const allActive = new Promise(resolve => {
            worker.on('active', after(concurrency, resolve));
          });

          await worker.waitUntilReady();

          const jobs = await Promise.all([
            queue.add('test', { bar: 'baz' }, { removeOnFail: true }),
            queue.add('test', { bar1: 'baz1' }, { removeOnFail: true }),
            queue.add('test', { bar2: 'baz2' }, { removeOnFail: true }),
            queue.add('test', { bar3: 'baz3' }, { removeOnFail: true }),
          ]);

          await allActive;

          await worker.close(true);

          const worker2 = new Worker(queueName, NoopProc, {
            connection,
            prefix,
            stalledInterval: 100,
            maxStalledCount: 0,
            concurrency,
          });

          const errorMessage = 'job stalled more than allowable limit';
          const allFailed = new Promise<void>((resolve, reject) => {
            worker2.on(
              'failed',
              after(concurrency, async (job, failedReason, prev) => {
                try {
                  expect(job?.attemptsStarted).toBe(2);
                  expect(job?.attemptsMade).toBe(1);
                  expect(job?.stalledCounter).toBe(1);
                  expect(prev).toBe('active');
                  expect(failedReason.message).toBe(errorMessage);
                  resolve();
                } catch (err) {
                  reject(err);
                }
              }),
            );
          });

          const globalAllFailed = new Promise<void>(resolve => {
            queueEvents.on('failed', ({ failedReason }) => {
              expect(failedReason).toBe(errorMessage);
              resolve();
            });
          });

          await allFailed;
          await globalAllFailed;

          for (let i = 0; i < jobs.length; i++) {
            const stored = await queue.getJob(jobs[i].id!);
            expect(stored).toBeUndefined();
          }

          await queueEvents.close();
          await worker2.close();
        });
      });

      it('keeps the jobs with removeOnFail as false in failed', async () => {
        // TODO: Move timeout to test options: { timeout: 6000 }
        const concurrency = 4;

        const worker = new Worker(
          queueName,
          async () => {
            return delay(10000);
          },
          {
            connection,
            prefix,
            lockDuration: 1000,
            stalledInterval: 100,
            maxStalledCount: 0,
            concurrency,
          },
        );

        const allActive = new Promise(resolve => {
          worker.on('active', after(concurrency, resolve));
        });

        await worker.waitUntilReady();

        const jobs = Array.from(Array(4).keys()).map(index => ({
          name: 'test',
          data: { index },
          opts: {
            removeOnFail: index % 2 == 1,
          },
        }));

        await queue.addBulk(jobs);

        await allActive;

        await worker.close(true);

        const worker2 = new Worker(queueName, NoopProc, {
          connection,
          prefix,
          stalledInterval: 100,
          maxStalledCount: 0,
          concurrency,
        });

        const errorMessage = 'job stalled more than allowable limit';
        const allFailed = new Promise<void>(resolve => {
          worker2.on(
            'failed',
            after(concurrency, async (job, failedReason, prev) => {
              expect(job?.attemptsStarted).toBe(2);
              expect(job?.attemptsMade).toBe(1);
              expect(job?.stalledCounter).toBe(1);
              const failedCount = await queue.getFailedCount();
              expect(failedCount).toBe(2);

              expect(prev).toBe('active');
              expect(failedReason.message).toBe(errorMessage);
              resolve();
            }),
          );
        });

        await allFailed;

        await worker2.close();
      });
    });

    describe('when removeOnFail is provided as a object', () => {
      it('keeps the specified number of jobs in failed respecting the age', async () => {
        // TODO: Move timeout to test options: { timeout: 6000 }
        const concurrency = 4;

        const worker = new Worker(
          queueName,
          async job => {
            if (job.data.index < 2) {
              throw new Error('fail');
            }
            return delay(10000);
          },
          {
            autorun: false,
            connection,
            prefix,
            lockDuration: 1000,
            stalledInterval: 100,
            maxStalledCount: 0,
            concurrency,
          },
        );

        const allActive = new Promise(resolve => {
          worker.on('active', after(concurrency, resolve));
        });

        // Wait for the two intentional failures (jobs with index < 2) so the
        // age-based cleanup we assert later is deterministic. Without this,
        // closing the worker right after `allActive` resolves can race the
        // throw, causing those jobs to fail as stalled instead of via the
        // processor, which changes their finishedOn timestamps.
        const initialFailures = new Promise<void>(resolve => {
          worker.on(
            'failed',
            after(2, () => resolve()),
          );
        });

        await worker.waitUntilReady();

        const jobs = Array.from(Array(4).keys()).map(index => ({
          name: 'test',
          data: { index },
          opts: {
            removeOnFail: {
              count: 4,
              age: 1,
            },
          },
        }));

        await queue.addBulk(jobs);

        worker.run();

        await allActive;
        await initialFailures;

        await worker.close(true);

        const worker2 = new Worker(queueName, NoopProc, {
          connection,
          prefix,
          stalledInterval: 100,
          maxStalledCount: 0,
          concurrency,
        });

        const errorMessage = 'job stalled more than allowable limit';
        // Two jobs (index 2 and 3, ids '3' and '4') were left active when the
        // first worker was closed and will be picked up as stalled by worker2.
        // Wait for both failures so the test is robust to event ordering and
        // does not hang on a specific job id.
        const expectedStalledFailures = 2;
        const stalledFailures = new Promise<
          Array<{ id: string; index: number }>
        >((resolve, reject) => {
          const received: Array<{ id: string; index: number }> = [];
          worker2.on('failed', async (job, failedReason, prev) => {
            try {
              expect(prev).toBe('active');
              expect(failedReason.message).toBe(errorMessage);
            } catch (err) {
              reject(err);
              return;
            }
            received.push({ id: job.id!, index: job.data.index });
            if (received.length === expectedStalledFailures) {
              resolve(received);
            }
          });
        });

        const failures = await stalledFailures;
        const failedCount = await queue.getFailedCount();
        expect(failedCount).toBe(2);
        expect(failures.map(f => f.id).sort()).toEqual(['3', '4']);
        expect(failures.map(f => f.index).sort()).toEqual([2, 3]);

        await worker2.close();
      });
    });
  });

  it('jobs not stalled while lock is extended', async () => {
    // TODO: Move timeout to test options: { timeout: 5000 }
    const numJobs = 4;

    const concurrency = 4;

    const worker = new Worker(
      queueName,
      async () => {
        return delay(4000);
      },
      {
        connection,
        prefix,
        lockDuration: 100, // lockRenewTime would be half of it i.e. 500
        stalledInterval: 50,
        concurrency,
      },
    );

    const allActive = new Promise(resolve => {
      worker.on('active', after(concurrency, resolve));
    });

    const jobs = Array.from(Array(numJobs).keys()).map(index => ({
      name: 'test',
      data: { bar: `baz-${index}` },
    }));

    await queue.addBulk(jobs);

    await allActive;

    const worker2 = new Worker(queueName, NoopProc, {
      connection,
      prefix,
      stalledInterval: 50,
      concurrency,
    });

    const allStalled = new Promise(resolve =>
      worker2.on('stalled', after(concurrency, resolve)),
    );

    await delay(500); // Wait for jobs to become active

    const active = await queue.getActiveCount();
    expect(active).toBe(4);

    await worker.close(true);

    await allStalled;

    await worker2.close();
  });
});
