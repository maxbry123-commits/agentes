'use strict';

import { getRedisClient } from './utils/get-redis-client';
import { after } from './utils/lodash';
import {
  describe,
  beforeEach,
  afterEach,
  beforeAll,
  afterAll,
  it,
  expect,
} from 'vitest';

import { Job, Queue, QueueEvents, Worker } from '../src/classes';
import { JobsOptions } from '../src/types';
import { delay, randomUUID } from '../src/utils';
import { createTestConnection } from './utils/connection-factory';
import { cleanupQueue } from './utils/cleanup-queue';
import { IRedisClient } from '../src/interfaces';

describe('Job', () => {
  const prefix = process.env.BULLMQ_TEST_PREFIX || 'bull';

  let queue: Queue;
  let queueName: string;
  let connection: IRedisClient;
  beforeAll(async () => {
    connection = createTestConnection();
  });

  beforeEach(async () => {
    queueName = `test-${randomUUID()}`;
    queue = new Queue(queueName, { connection, prefix });
  });

  afterEach(async () => {
    await queue.close();
    await cleanupQueue(queueName);
  });

  afterAll(async function () {
    await connection.quit();
  });

  describe('.create', () => {
    const timestamp = 1234567890;
    let job: Job;
    let data: any;
    let opts: JobsOptions;

    beforeEach(async () => {
      data = { foo: 'bar' };
      opts = { timestamp };

      const createdJob = await Job.create(queue, 'test', data, opts);
      job = createdJob;
    });

    it('saves the job in redis', async () => {
      const storedJob = await Job.fromId(queue, job.id!);
      expect(storedJob).toHaveProperty('id');
      expect(storedJob).toHaveProperty('data');

      expect(storedJob!.data.foo).toBe('bar');
      expect(storedJob!.opts).toBeTypeOf('object');
      expect(storedJob!.opts.timestamp).toBe(timestamp);
    });

    it('should use the custom jobId if one is provided', async () => {
      const customJobId = 'customjob';
      const createdJob = await Job.create(queue, 'test', data, {
        jobId: customJobId,
      });
      expect(createdJob.id).toBe(customJobId);
    });

    describe('when custom jobId is provided as empty string', () => {
      it('should ignore the empty custom id and generates a numeric id', async () => {
        const job = await Job.create(queue, 'test', data, {
          jobId: '',
        });
        expect(job.id).toBe('2');
      });
    });

    it('should set default size limit and succeed in creating job', async () => {
      const data = { foo: 'bar' }; // 13 bytes
      const opts = { sizeLimit: 20 };
      const createdJob = await Job.create(queue, 'test', data, opts);
      expect(createdJob).not.toBeNull();
      expect(createdJob).toHaveProperty('opts');
      expect(createdJob.opts.sizeLimit).toBe(20);
    });

    it('should set default size limit and fail due to size limit exception', async () => {
      const data = { foo: 'bar' }; // 13 bytes
      const opts = { sizeLimit: 12 };
      await expect(Job.create(queue, 'test', data, opts)).rejects.toThrow(
        `The size of job test exceeds the limit ${opts.sizeLimit} bytes`,
      );
    });

    it('should set default size limit with non-ascii data and fail due to size limit exception', async () => {
      const data = { foo: 'βÅ®' }; // 16 bytes
      const opts = { sizeLimit: 15 };
      await expect(Job.create(queue, 'test', data, opts)).rejects.toThrow(
        `The size of job test exceeds the limit ${opts.sizeLimit} bytes`,
      );
    });

    it('should set custom job id and default size limit and fail due to size limit exception', async () => {
      const data = { foo: 'bar' }; // 13 bytes
      const opts = { sizeLimit: 12, jobId: 'customJobId' };
      await expect(Job.create(queue, 'test', data, opts)).rejects.toThrow(
        `The size of job test exceeds the limit ${opts.sizeLimit} bytes`,
      );
    });

    describe('when parent key is missing', () => {
      it('throws an error', async () => {
        const data = { foo: 'bar' };
        const parentId = randomUUID();
        const opts: JobsOptions = {
          parent: { id: parentId, queue: `${prefix}:${queueName}` },
        };
        await expect(Job.create(queue, 'test', data, opts)).rejects.toThrow(
          `Missing key for parent job ${prefix}:${queueName}:${parentId}. addJob`,
        );
      });
    });

    describe('when removeDependencyOnFailure and failParentOnFailure options are provided', () => {
      it('throws an error', async () => {
        const data = { foo: 'bar' };
        const opts = {
          removeDependencyOnFailure: true,
          failParentOnFailure: true,
        };
        await expect(Job.create(queue, 'test', data, opts)).rejects.toThrow(
          'The following options cannot be used together: removeDependencyOnFailure, failParentOnFailure',
        );
      });
    });

    describe('when removeDependencyOnFailure and ignoreDependencyOnFailure options are provided', () => {
      it('throws an error', async () => {
        const data = { foo: 'bar' };
        const opts = {
          removeDependencyOnFailure: true,
          ignoreDependencyOnFailure: true,
        };
        await expect(Job.create(queue, 'test', data, opts)).rejects.toThrow(
          'The following options cannot be used together: removeDependencyOnFailure, ignoreDependencyOnFailure',
        );
      });
    });

    describe('when failParentOnFailure and ignoreDependencyOnFailure options are provided', () => {
      it('throws an error', async () => {
        const data = { foo: 'bar' };
        const opts = {
          ignoreDependencyOnFailure: true,
          failParentOnFailure: true,
        };
        await expect(Job.create(queue, 'test', data, opts)).rejects.toThrow(
          'The following options cannot be used together: failParentOnFailure, ignoreDependencyOnFailure',
        );
      });
    });

    describe('when priority option is provided as float', () => {
      it('throws an error', async () => {
        const data = { foo: 'bar' };
        const opts = { priority: 1.1 };
        await expect(Job.create(queue, 'test', data, opts)).rejects.toThrow(
          'Priority should not be float',
        );
      });
    });

    describe('when priority option is provided with a value greater than 2097151', () => {
      it('throws an error', async () => {
        const data = { foo: 'bar' };
        const opts = { priority: 2097152 };
        await expect(Job.create(queue, 'test', data, opts)).rejects.toThrow(
          'Priority should be between 0 and 2097151',
        );
      });
    });

    describe('when deduplication id option is provided as empty string', () => {
      it('throws an error', async () => {
        const data = { foo: 'bar' };
        const opts = { deduplication: { id: '' } };
        await expect(Job.create(queue, 'test', data, opts)).rejects.toThrow(
          'Deduplication id must be provided',
        );
      });
    });

    describe('when removed debounce option is provided', () => {
      it('throws an error', async () => {
        const data = { foo: 'bar' };
        const opts = { debounce: { id: 'legacy' } } as any;
        await expect(Job.create(queue, 'test', data, opts)).rejects.toThrow(
          'Debounce option has been removed. Use deduplication option instead',
        );
      });
    });

    describe('when deduplication and parent options are provided', () => {
      it('throws an error', async () => {
        const data = { foo: 'bar' };
        const parentJob = await Job.create(queue, 'parent', {});
        const opts = {
          deduplication: { id: 'dedup-id' },
          parent: { id: parentJob.id!, queue: `${prefix}:${queueName}` },
        };
        await expect(Job.create(queue, 'test', data, opts)).rejects.toThrow(
          'Deduplication and parent options cannot be used together',
        );
      });
    });

    describe('when jitter backoff option is provided with a value lesser than 0', () => {
      it('throws an error', async () => {
        const data = { foo: 'bar' };
        const opts = { backoff: { type: 'fixed', jitter: -1 } };
        await expect(Job.create(queue, 'test', data, opts)).rejects.toThrow(
          'Jitter should be between 0 and 1',
        );
      });
    });

    describe('when jitter backoff option is provided with a value greater than 1', () => {
      it('throws an error', async () => {
        const data = { foo: 'bar' };
        const opts = { backoff: { type: 'fixed', jitter: 5 } };
        await expect(Job.create(queue, 'test', data, opts)).rejects.toThrow(
          'Jitter should be between 0 and 1',
        );
      });
    });
  });

  describe('JSON.stringify', () => {
    it('retains property types', async () => {
      const data = { foo: 'bar' };
      const job = await Job.create(queue, 'test', data);
      job.returnvalue = 1;
      job.progress = 20;
      const json = JSON.stringify(job);
      const parsed = JSON.parse(json);
      expect(parsed).toHaveProperty('data', data);
      expect(parsed).toHaveProperty('name', 'test');
      expect(parsed).toHaveProperty('returnvalue', 1);
      expect(parsed).toHaveProperty('progress', 20);
    });

    it('omits the queue property to avoid a circular json error on node 8', async () => {
      const data = { foo: 'bar' };
      const job = await Job.create(queue, 'test', data);
      const json = JSON.stringify(job);
      const parsed = JSON.parse(json);
      expect(parsed).not.toHaveProperty('queue');
    });

    it('should correctly handle zero passed as data', async () => {
      const data = 0;
      const job = await Job.create(queue, 'test', data);
      const json = JSON.stringify(job);
      const parsed = JSON.parse(json);
      expect(parsed).toHaveProperty('data', data);

      const newQueue = new Queue(queueName, { connection, prefix });
      let worker: Worker;
      const promise = new Promise<void>(async (resolve, reject) => {
        worker = new Worker(
          queueName,
          async job => {
            try {
              expect(job.data).toBe(0);
            } catch (err) {
              reject(err);
            }
            resolve();
          },
          { connection, prefix },
        );
        const testJob = await newQueue.add('test', 0);
      });

      try {
        await promise;
      } finally {
        await newQueue.close();
        worker && (await worker.close());
      }
    });
  });

  describe('.update', () => {
    it('should allow updating job data', async () => {
      const job = await Job.create<{ foo?: string; baz?: string }>(
        queue,
        'test',
        {
          foo: 'bar',
        },
      );
      await job.updateData({ baz: 'qux' });

      const updatedJob = await Job.fromId(queue, job.id);
      expect(updatedJob.data).toEqual({ baz: 'qux' });
    });

    describe('when job is removed', () => {
      it('throws error', async () => {
        const job = await Job.create(queue, 'test', { foo: 'bar' });
        await job.remove();
        await expect(job.updateData({ foo: 'baz' })).rejects.toThrow(
          `Missing key for job ${job.id}. updateData`,
        );
      });
    });
  });

  describe('.remove', () => {
    it('removes the job from redis', async () => {
      const job = await Job.create(queue, 'test', { foo: 'bar' });
      await job.remove();
      const storedJob = await Job.fromId(queue, job.id);
      expect(storedJob).toBe(undefined);
    });

    it('removes 4000 jobs in time range of 4000ms', async () => {
      // TODO: Move timeout to test options: { timeout: 8000 }
      const numJobs = 4000;

      // Create waiting jobs
      const jobsData = Array.from(Array(numJobs / 2).keys()).map(index => ({
        name: 'test',
        data: { order: numJobs - index },
      }));
      const waitingJobs = await queue.addBulk(jobsData);

      // Creating delayed jobs
      const jobsDataWithDelay = Array.from(Array(numJobs / 2).keys()).map(
        index => ({
          name: 'test',
          data: { order: numJobs - index },
          opts: {
            delay: 500 + (numJobs - index) * 150,
          },
        }),
      );
      const delayedJobs = await queue.addBulk(jobsDataWithDelay);

      const startTime = Date.now();
      // Remove all jobs
      await Promise.all(delayedJobs.map(job => job.remove()));
      await Promise.all(waitingJobs.map(job => job.remove()));

      expect(Date.now() - startTime).toBeLessThan(4000);

      const countJobs = await queue.getJobCountByTypes('waiting', 'delayed');
      expect(countJobs).toBe(0);
    });
  });

  // TODO: Add more remove tests

  describe('.progressProgress', () => {
    it('can set and get progress as number', async () => {
      const job = await Job.create(queue, 'test', { foo: 'bar' });
      await job.updateProgress(42);
      const storedJob = await Job.fromId(queue, job.id!);
      expect(storedJob!.progress).toBe(42);
    });

    it('can set and get progress as object', async () => {
      const job = await Job.create(queue, 'test', { foo: 'bar' });
      await job.updateProgress({ total: 120, completed: 40 });
      const storedJob = await Job.fromId(queue, job.id!);
      expect(storedJob!.progress).toEqual({ total: 120, completed: 40 });
    });

    it('can set and get progress as string', async () => {
      const job = await Job.create(queue, 'test', { foo: 'bar' });
      await job.updateProgress('hello, world!');
      const storedJob = await Job.fromId(queue, job.id!);
      expect(storedJob!.progress).toEqual('hello, world!');
    });

    it('can set and get progress as boolean', async () => {
      const job = await Job.create(queue, 'test', { foo: 'bar' });
      await job.updateProgress(false);
      let storedJob = await Job.fromId(queue, job.id!);
      expect(storedJob!.progress).toEqual(false);
      await job.updateProgress(true);
      storedJob = await Job.fromId(queue, job.id!);
      expect(storedJob!.progress).toEqual(true);
    });

    it('can set progress as number using the Queue instance', async () => {
      const job = await Job.create(queue, 'test', { foo: 'bar' });

      const progress = new Promise<void>(resolve => {
        queue.on(
          'progress',
          (jobId: string, progress: string | boolean | number | object) => {
            expect(jobId).toEqual(job.id);
            expect(progress).toEqual(42);
            resolve();
          },
        );
      });
      queue.updateJobProgress(job.id!, 42);
      await progress;

      const storedJob = await Job.fromId(queue, job.id!);
      expect(storedJob!.progress).toBe(42);
    });

    it('can set progress as object using the Queue instance', async () => {
      const job = await Job.create(queue, 'test', { foo: 'bar' });
      await queue.updateJobProgress(job.id!, { total: 120, completed: 40 });
      const storedJob = await Job.fromId(queue, job.id!);
      expect(storedJob!.progress).toEqual({ total: 120, completed: 40 });
    });

    describe('when job is removed', () => {
      it('throws error', async () => {
        const job = await Job.create(queue, 'test', { foo: 'bar' });
        await job.remove();
        await expect(
          job.updateProgress({ total: 120, completed: 40 }),
        ).rejects.toThrow(`Missing key for job ${job.id}. updateProgress`);
      });
    });
  });

  describe('.log', () => {
    it('can log two rows with text in asc order', async () => {
      const firstLog = 'some log text 1';
      const secondLog = 'some log text 2';

      const job = await Job.create(queue, 'test', { foo: 'bar' });

      await job.log(firstLog);
      await job.log(secondLog);
      const logs = await queue.getJobLogs(job.id);
      expect(logs).toEqual({ logs: [firstLog, secondLog], count: 2 });
      const firstSavedLog = await queue.getJobLogs(job.id, 0, 0, true);
      expect(firstSavedLog).toEqual({ logs: [firstLog], count: 2 });
      const secondSavedLog = await queue.getJobLogs(job.id, 1, 1);
      expect(secondSavedLog).toEqual({ logs: [secondLog], count: 2 });
      await job.remove();

      const logsRemoved = await queue.getJobLogs(job.id);
      expect(logsRemoved).toEqual({ logs: [], count: 0 });
    });

    it('can log two rows with text in desc order', async () => {
      const firstLog = 'some log text 1';
      const secondLog = 'some log text 2';

      const job = await Job.create(queue, 'test', { foo: 'bar' });

      await job.log(firstLog);
      await job.log(secondLog);
      const logs = await queue.getJobLogs(job.id, 0, -1, false);
      expect(logs).toEqual({ logs: [secondLog, firstLog], count: 2 });
      const secondSavedLog = await queue.getJobLogs(job.id, 0, 0, false);
      expect(secondSavedLog).toEqual({ logs: [secondLog], count: 2 });
      const firstSavedLog = await queue.getJobLogs(job.id, 1, 1, false);
      expect(firstSavedLog).toEqual({ logs: [firstLog], count: 2 });
      await job.remove();

      const logsRemoved = await queue.getJobLogs(job.id);
      expect(logsRemoved).toEqual({ logs: [], count: 0 });
    });

    it('should preserve up to keepLogs latest entries', async () => {
      const firstLog = 'some log text 1';
      const secondLog = 'some log text 2';
      const thirdLog = 'some log text 3';

      const job = await Job.create(
        queue,
        'test',
        { foo: 'bar' },
        { keepLogs: 2 },
      );

      const count1 = await job.log(firstLog);
      expect(count1).toBe(1);

      const logs1 = await queue.getJobLogs(job.id!);
      expect(logs1).toEqual({ logs: [firstLog], count: 1 });

      const count2 = await job.log(secondLog);
      expect(count2).toBe(2);

      const logs2 = await queue.getJobLogs(job.id!);
      expect(logs2).toEqual({ logs: [firstLog, secondLog], count: 2 });

      const count3 = await job.log(thirdLog);
      expect(count3).toBe(2);

      const logs3 = await queue.getJobLogs(job.id!);
      expect(logs3).toEqual({ logs: [secondLog, thirdLog], count: 2 });
    });

    it('should allow to add job logs from Queue instance', async () => {
      const firstLog = 'some log text 1';
      const secondLog = 'some log text 2';

      const job = await Job.create(queue, 'test', { foo: 'bar' });

      await queue.addJobLog(job.id!, firstLog);
      await queue.addJobLog(job.id!, secondLog);

      const logs = await queue.getJobLogs(job.id!);

      expect(logs).toEqual({ logs: [firstLog, secondLog], count: 2 });
    });

    it('can log using a queue-like object without shared scripts', async () => {
      const firstLog = 'some log text 1';
      const queueWithoutScripts = Object.create(queue) as Queue;
      (queueWithoutScripts as any).scripts = undefined;

      const job = await Job.create(queueWithoutScripts, 'test', { foo: 'bar' });

      await job.log(firstLog);

      const logs = await queue.getJobLogs(job.id!);

      expect(logs).toEqual({ logs: [firstLog], count: 1 });
    });

    describe('when job is removed', () => {
      it('throws error', async () => {
        const job = await Job.create(queue, 'test', { foo: 'bar' });
        await job.remove();
        await expect(job.log('oneLog')).rejects.toThrow(
          `Missing key for job ${job.id}. addLog`,
        );
      });
    });
  });

  describe('.clearLogs', () => {
    it('can clear the log', async () => {
      const firstLog = 'some log text 1';
      const secondLog = 'some log text 2';

      const job = await Job.create(queue, 'test', { foo: 'bar' });

      await job.log(firstLog);
      await job.log(secondLog);
      const logs = await queue.getJobLogs(job.id);
      expect(logs).toEqual({ logs: [firstLog, secondLog], count: 2 });

      await job.clearLogs();

      const logsRemoved = await queue.getJobLogs(job.id);
      expect(logsRemoved).toEqual({ logs: [], count: 0 });
    });

    it('can preserve up to keepLogs latest entries', async () => {
      const firstLog = 'some log text 1';
      const secondLog = 'some log text 2';
      const thirdLog = 'some log text 3';

      const job = await Job.create(queue, 'test', { foo: 'bar' });

      await job.log(firstLog);
      await job.log(secondLog);
      await job.log(thirdLog);

      const logs1 = await queue.getJobLogs(job.id);
      expect(logs1).toEqual({
        logs: [firstLog, secondLog, thirdLog],
        count: 3,
      });

      await job.clearLogs(4);

      const logs2 = await queue.getJobLogs(job.id);
      expect(logs2).toEqual({
        logs: [firstLog, secondLog, thirdLog],
        count: 3,
      });

      await job.clearLogs(3);

      const logs3 = await queue.getJobLogs(job.id);
      expect(logs3).toEqual({
        logs: [firstLog, secondLog, thirdLog],
        count: 3,
      });

      await job.clearLogs(2);

      const logs4 = await queue.getJobLogs(job.id);
      expect(logs4).toEqual({ logs: [secondLog, thirdLog], count: 2 });

      await job.clearLogs(0);

      const logsRemoved = await queue.getJobLogs(job.id);
      expect(logsRemoved).toEqual({ logs: [], count: 0 });
    });
  });

  describe('.moveToCompleted', () => {
    it('marks the job as completed and returns new job', async () => {
      const worker = new Worker(queueName, null, { connection, prefix });
      const token = 'my-token';
      await Job.create(queue, 'test', { foo: 'bar' });
      const job2 = await Job.create(queue, 'test', { baz: 'qux' });
      const job1 = (await worker.getNextJob(token)) as Job;
      const isCompleted = await job1.isCompleted();
      expect(isCompleted).toBe(false);
      const state = await job1.getState();
      expect(state).toBe('active');
      const job1Id = await job1.moveToCompleted('succeeded', token, true);
      const isJob1Completed = await job1.isCompleted();
      expect(isJob1Completed).toBe(true);
      expect(job1.returnvalue).toBe('succeeded');
      expect(job1Id[1]).toBe(job2.id);
      await worker.close();
    });
  });

  describe('.moveToFailed', () => {
    it('marks the job as failed', async () => {
      const worker = new Worker(queueName, null, { connection, prefix });
      const token = 'my-token';
      await Job.create(queue, 'test', { foo: 'bar' });
      const job = (await worker.getNextJob(token)) as Job;
      const isFailed = await job.isFailed();
      expect(isFailed).toBe(false);
      await job.moveToFailed(new Error('test error'), '0', true);
      const isFailed2 = await job.isFailed();
      expect(isFailed2).toBe(true);
      expect(job.stacktrace).not.toBe(null);
      expect(job.stacktrace.length).toBe(1);
      expect(job.stacktrace[0]).toContain('job.test.ts');
      await worker.close();
    });

    describe('when using a custom error', () => {
      it('marks the job as failed', async () => {
        class CustomError extends Error {}
        const worker = new Worker(queueName, null, { connection, prefix });
        const token = 'my-token';
        await Job.create(queue, 'test', { foo: 'bar' });
        const job = (await worker.getNextJob(token)) as Job;
        const isFailed = await job.isFailed();
        expect(isFailed).toBe(false);
        await job.moveToFailed(new CustomError('test error'), '0', true);
        const isFailed2 = await job.isFailed();
        expect(isFailed2).toBe(true);
        expect(job.stacktrace).not.toBe(null);
        expect(job.stacktrace.length).toBe(1);
        expect(job.stacktrace[0]).toContain('job.test.ts');
        await worker.close();
      });
    });

    it('moves the job to wait for retry if attempts are given', async () => {
      const queueEvents = new QueueEvents(queueName, { connection, prefix });
      await queueEvents.waitUntilReady();
      const worker = new Worker(queueName, null, { connection, prefix });

      await Job.create(queue, 'test', { foo: 'bar' }, { attempts: 3 });
      const token = 'my-token';
      const job = (await worker.getNextJob(token)) as Job;

      const isFailed = await job.isFailed();
      expect(isFailed).toBe(false);

      const waiting = new Promise(resolve => {
        queueEvents.on('waiting', resolve);
      });

      await job.moveToFailed(new Error('test error'), '0', true);

      await waiting;

      const isFailed2 = await job.isFailed();
      expect(isFailed2).toBe(false);
      expect(job.stacktrace).not.toBe(null);
      expect(job.stacktrace.length).toBe(1);
      const isWaiting = await job.isWaiting();
      expect(isWaiting).toBe(true);

      await queueEvents.close();
      await worker.close();
    });

    describe('when job is not in active state', () => {
      it('throws an error', async () => {
        const queueEvents = new QueueEvents(queueName, { connection, prefix });
        await queueEvents.waitUntilReady();

        const job = await Job.create(
          queue,
          'test',
          { foo: 'bar' },
          { attempts: 3 },
        );
        const isFailed = await job.isFailed();
        expect(isFailed).toBe(false);

        await expect(
          job.moveToFailed(new Error('test error'), '0', true),
        ).rejects.toThrow(`Job ${job.id} is not in the active state. retryJob`);

        await queueEvents.close();
      });
    });

    describe('when attempts made equal to attempts given', () => {
      it('marks the job as failed', async () => {
        const worker = new Worker(queueName, null, { connection, prefix });
        const token = 'my-token';
        await Job.create(queue, 'test', { foo: 'bar' }, { attempts: 1 });
        const job = (await worker.getNextJob(token)) as Job;
        const isFailed = await job.isFailed();

        expect(isFailed).toBe(false);

        await job.moveToFailed(new Error('test error'), '0', true);
        const state = await job.getState();
        const isFailed2 = await job.isFailed();

        expect(isFailed2).toBe(true);
        expect(state).toBe('failed');
        expect(job.stacktrace).not.toBe(null);
        expect(job.stacktrace.length).toBe(1);
        await worker.close();
      });
    });

    describe('when attempts are given and backoff is non zero', () => {
      it('moves the job to delayed for retry', async () => {
        const worker = new Worker(queueName, null, { connection, prefix });
        const token = 'my-token';
        await Job.create(
          queue,
          'test',
          { foo: 'bar' },
          { attempts: 3, backoff: 300 },
        );
        const job = (await worker.getNextJob(token)) as Job;
        const isFailed = await job.isFailed();

        expect(isFailed).toBe(false);

        await job.moveToFailed(new Error('test error'), token, true);
        const state = await job.getState();
        const isFailed2 = await job.isFailed();

        expect(isFailed2).toBe(false);
        expect(job.stacktrace).not.toBe(null);
        expect(job.stacktrace.length).toBe(1);
        const isDelayed = await job.isDelayed();
        expect(isDelayed).toBe(true);
        expect(state).toBe('delayed');
        await worker.close();
      });

      describe('when fetchNext is true and', () => {
        describe('when another job is waiting', () => {
          it('returns the next job data after moving the failed job to delayed', async () => {
            const worker = new Worker(queueName, null, { connection, prefix });
            const token = 'my-token';

            await Job.create(
              queue,
              'test',
              { foo: 'bar' },
              { attempts: 3, backoff: 300 },
            );
            const nextJob = await Job.create(queue, 'test2', { baz: 'qux' });

            const job = (await worker.getNextJob(token)) as Job;

            const result = await job.moveToFailed(
              new Error('test error'),
              token,
              true,
            );

            const isDelayed = await job.isDelayed();
            expect(isDelayed).toBe(true);

            // result should contain the next job data: [jobData, jobId, limitUntil, delayUntil]
            expect(result).toBeDefined();
            expect(Array.isArray(result)).toBe(true);
            expect(result![1]).toBe(nextJob.id);
            expect(result![0]).toMatchObject({ name: 'test2' });
            expect(result![2]).toBe(0);
            expect(result![3]).toBe(0);

            await worker.close();
          });
        });

        describe('when no job is waiting', () => {
          it('does not return any job data after moving the failed job to delayed', async () => {
            const worker = new Worker(queueName, null, { connection, prefix });
            const token = 'my-token';

            await Job.create(
              queue,
              'test',
              { foo: 'bar' },
              { attempts: 3, backoff: 300 },
            );

            const job = (await worker.getNextJob(token)) as Job;

            const result = await job.moveToFailed(
              new Error('test error'),
              token,
              true,
            );

            const isDelayed = await job.isDelayed();
            expect(isDelayed).toBe(true);

            expect(result).toEqual([]);
            expect(Array.isArray(result)).toBe(true);

            await worker.close();
          });
        });
      });

      describe('when fetchNext is false and another job is waiting', () => {
        it('does not return next job data', async () => {
          const worker = new Worker(queueName, null, { connection, prefix });
          const token = 'my-token';

          await Job.create(
            queue,
            'test',
            { foo: 'bar' },
            { attempts: 3, backoff: 300 },
          );
          await Job.create(queue, 'test2', { baz: 'qux' });

          const job = (await worker.getNextJob(token)) as Job;

          const result = await job.moveToFailed(
            new Error('test error'),
            token,
            false,
          );

          const isDelayed = await job.isDelayed();
          expect(isDelayed).toBe(true);

          // when fetchNext is false, the result should not include next job data
          // and is expected to be an empty array
          expect(result).toEqual([]);

          await worker.close();
        });
      });
    });

    it('applies stacktrace limit on failure', async () => {
      const worker = new Worker(queueName, null, { connection, prefix });
      const token = 'my-token';
      const stackTraceLimit = 1;
      await Job.create(
        queue,
        'test',
        { foo: 'bar' },
        { stackTraceLimit: stackTraceLimit, attempts: 2 },
      );
      const job = (await worker.getNextJob(token)) as Job;
      const isFailed = await job.isFailed();
      expect(isFailed).toBe(false);
      // first time failed.
      await job.moveToFailed(new Error('failed once'), '0', true);
      const isFailed1 = await job.isFailed();
      const stackTrace1 = job.stacktrace[0];
      expect(isFailed1).toBe(false);
      expect(job.stacktrace).not.toBe(null);
      expect(job.stacktrace.length).toBe(stackTraceLimit);
      // second time failed.
      const again = (await worker.getNextJob(token)) as Job;
      await again.moveToFailed(new Error('failed twice'), '0', true);
      const isFailed2 = await again.isFailed();
      const stackTrace2 = again.stacktrace[0];
      expect(isFailed2).toBe(true);
      expect(again.name).toBe(job.name);
      expect(again.stacktrace.length).toBe(stackTraceLimit);
      expect(stackTrace1).not.toBe(stackTrace2);
      await worker.close();
    });

    describe('when stackTraceLimit is provided as 0', () => {
      it('keep stacktrace empty', async () => {
        const worker = new Worker(queueName, null, { connection, prefix });
        const token = 'my-token';
        const stackTraceLimit = 0;
        await Job.create(
          queue,
          'test',
          { foo: 'bar' },
          { stackTraceLimit: stackTraceLimit, attempts: 2 },
        );
        const job = (await worker.getNextJob(token)) as Job;
        const isFailed = await job.isFailed();
        expect(isFailed).toBe(false);
        // first time failed.
        await job.moveToFailed(new Error('failed once'), '0', true);
        const isFailed1 = await job.isFailed();
        expect(isFailed1).toBe(false);
        expect(job.stacktrace.length).toBe(stackTraceLimit);
        // second time failed.
        const again = (await worker.getNextJob(token)) as Job;
        await again.moveToFailed(new Error('failed twice'), '0', true);
        const isFailed2 = await again.isFailed();
        expect(isFailed2).toBe(true);
        expect(again.name).toBe(job.name);
        expect(again.stacktrace.length).toBe(stackTraceLimit);
        await worker.close();
      });
    });

    it('saves error stacktrace', async () => {
      const worker = new Worker(queueName, null, { connection, prefix });
      const token = 'my-token';
      await Job.create(queue, 'test', { foo: 'bar' });
      const job = (await worker.getNextJob(token)) as Job;
      const id = job.id;
      await job.moveToFailed(new Error('test error'), '0');
      const sameJob = await queue.getJob(id!);
      expect(sameJob).toBeTruthy();
      expect(sameJob.stacktrace.length).toBeGreaterThan(0);
      await worker.close();
    });
  });

  describe('.moveToWait', () => {
    it('moves job to wait from active', async () => {
      const worker = new Worker(queueName, null, { connection, prefix });
      const token = 'my-token';
      await Job.create(queue, 'test', { foo: 'bar' });
      const job = (await worker.getNextJob(token)) as Job;
      const isWaiting = await job.isWaiting();
      expect(isWaiting).toBe(false);
      await job.moveToWait(token);
      const isisWaiting2 = await job.isWaiting();
      expect(isisWaiting2).toBe(true);
      await worker.close();
    });
  });

  describe('.changeDelay', () => {
    it('can change delay of a delayed job', async () => {
      // TODO: Move timeout to test options: { timeout: 8000 }

      const worker = new Worker(queueName, async () => {}, {
        connection,
        prefix,
      });
      await worker.waitUntilReady();

      const startTime = new Date().getTime();

      const completing = new Promise<void>(resolve => {
        worker.on('completed', async () => {
          const timeDiff = new Date().getTime() - startTime;
          expect(timeDiff).toBeGreaterThanOrEqual(2000);
          resolve();
        });
      });

      const job = await Job.create(
        queue,
        'test',
        { foo: 'bar' },
        { delay: 8000 },
      );

      const isDelayed = await job.isDelayed();
      expect(isDelayed).toBe(true);

      await job.changeDelay(2000);

      const isDelayedAfterChangeDelay = await job.isDelayed();
      expect(isDelayedAfterChangeDelay).toBe(true);
      expect(job.delay).toBe(2000);

      await completing;

      await worker.close();
    });

    it('should not change delay if a job is not delayed', async () => {
      const job = await Job.create(queue, 'test', { foo: 'bar' });
      const isDelayed = await job.isDelayed();
      expect(isDelayed).toBe(false);

      await expect(job.changeDelay(2000)).rejects.toThrow(
        `Job ${job.id} is not in the delayed state. changeDelay`,
      );
    });
  });

  describe('.changePriority', () => {
    describe('when job is in wait state', () => {
      describe('when lifo option is provided as true', () => {
        it('moves job to the head of wait list', async () => {
          await queue.pause();
          await Job.create(queue, 'test1', { foo: 'bar' });
          const job = await Job.create(
            queue,
            'test2',
            { foo: 'bar' },
            { priority: 16 },
          );

          expect(job.priority).toEqual(16);

          await job.changePriority({
            priority: 0,
            lifo: true,
          });

          expect(job.priority).toEqual(0);

          const worker = new Worker(
            queueName,
            async () => {
              await delay(20);
            },
            { connection, prefix },
          );
          await worker.waitUntilReady();

          const completing = new Promise<void>(resolve => {
            worker.on(
              'completed',
              after(2, job => {
                expect(job.name).toEqual('test1');
                resolve();
              }),
            );
          });

          await queue.resume();

          await completing;

          await worker.close();
        });
      });

      describe('when lifo option is provided as false', () => {
        it('moves job to the tail of wait list and has more priority', async () => {
          await queue.pause();
          const job = await Job.create(
            queue,
            'test1',
            { foo: 'bar' },
            { priority: 8 },
          );
          await Job.create(queue, 'test2', { foo: 'bar' });

          await job.changePriority({
            priority: 0,
            lifo: false,
          });

          const worker = new Worker(
            queueName,
            async () => {
              await delay(20);
            },
            { connection, prefix },
          );
          await worker.waitUntilReady();

          const completing = new Promise<void>(resolve => {
            worker.on(
              'completed',
              after(2, job => {
                expect(job.name).toEqual('test1');
                resolve();
              }),
            );
          });

          await queue.resume();

          await completing;

          await worker.close();
        });
      });
    });

    describe('when job is in prioritized state', () => {
      it('can change priority of a job', async () => {
        await Job.create(queue, 'test1', { foo: 'bar' }, { priority: 8 });
        const job = await Job.create(
          queue,
          'test2',
          { foo: 'bar' },
          { priority: 16 },
        );

        await job.changePriority({
          priority: 1,
        });

        const worker = new Worker(
          queueName,
          async (job: Job) => {
            if (job.name === 'test1') {
              expect(job.priority).toEqual(8);
            } else {
              expect(job.priority).toEqual(1);
            }
            await delay(20);
          },
          { connection, prefix },
        );
        await worker.waitUntilReady();

        const completing = new Promise<void>(resolve => {
          worker.on(
            'completed',
            after(2, job => {
              expect(job.name).toEqual('test1');
              resolve();
            }),
          );
        });

        await completing;

        await worker.close();
      });

      describe('when lifo option is provided as true', () => {
        it('moves job to the head of prioritized jobs with same priority', async () => {
          await queue.pause();
          await Job.create(queue, 'test1', { foo: 'bar' }, { priority: 16 });
          const job = await Job.create(
            queue,
            'test2',
            { foo: 'bar' },
            { priority: 16 },
          );

          await job.changePriority({
            priority: 16,
            lifo: true,
          });

          const worker = new Worker(
            queueName,
            async () => {
              await delay(20);
            },
            { connection, prefix },
          );
          await worker.waitUntilReady();

          const completing = new Promise<void>(resolve => {
            worker.on(
              'completed',
              after(2, job => {
                expect(job.name).toEqual('test1');
                resolve();
              }),
            );
          });

          await queue.resume();

          await completing;

          await worker.close();
        });
      });
    });

    describe('when queue is paused', () => {
      it('respects new priority', async () => {
        await queue.pause();
        await Job.create(queue, 'test1', { foo: 'bar' }, { priority: 8 });
        const job = await Job.create(
          queue,
          'test2',
          { foo: 'bar' },
          { priority: 16 },
        );

        await job.changePriority({
          priority: 1,
        });

        const worker = new Worker(
          queueName,
          async () => {
            await delay(20);
          },
          { connection, prefix },
        );
        await worker.waitUntilReady();

        const completing = new Promise<void>(resolve => {
          worker.on(
            'completed',
            after(2, job => {
              expect(job.name).toEqual('test1');
              resolve();
            }),
          );
        });

        await queue.resume();

        await completing;

        await worker.close();
      });
    });

    describe('when job is not in wait or prioritized state', () => {
      it('does not add a record in priority zset', async () => {
        const job = await Job.create(
          queue,
          'test1',
          { foo: 'bar' },
          { delay: 500 },
        );

        await job.changePriority({
          priority: 10,
        });

        const prioritizedCount = await queue.getJobCountByTypes('prioritized');
        expect(prioritizedCount).toEqual(0);

        const isDelayed = await job.isDelayed();
        expect(isDelayed).toBe(true);

        const updatedJob = await queue.getJob(job.id!);
        expect(updatedJob!.priority).toEqual(10);
      });
    });

    describe('when job does not exist', () => {
      it('throws an error', async () => {
        const job = await Job.create(queue, 'test', { foo: 'bar' });
        await job.remove();

        await expect(job.changePriority({ priority: 2 })).rejects.toThrow(
          `Missing key for job ${job.id}. changePriority`,
        );
      });
    });
  });

  describe('.promote', () => {
    it('can promote a delayed job to be executed immediately', async () => {
      const job = await Job.create(
        queue,
        'test',
        { foo: 'bar' },
        { delay: 1500 },
      );
      const isDelayed = await job.isDelayed();
      expect(isDelayed).toBe(true);
      await job.promote();
      expect(job.delay).toBe(0);

      const isDelayedAfterPromote = await job.isDelayed();
      expect(isDelayedAfterPromote).toBe(false);
      const isWaiting = await job.isWaiting();
      expect(isWaiting).toBe(true);
    });

    it('should process a promoted job according to its priority', async () => {
      // TODO: Move timeout to test options: { timeout: 5000 }
      const completed: string[] = [];
      const worker = new Worker(
        queueName,
        job => {
          completed.push(job.id!);
          return delay(200);
        },
        { connection, prefix, autorun: false },
      );
      await worker.waitUntilReady();

      const completing = new Promise<void>((resolve, reject) => {
        worker.on(
          'completed',
          after(4, () => {
            try {
              expect(completed).toEqual(['a', 'b', 'c', 'd']);
              resolve();
            } catch (err) {
              reject(err);
            }
          }),
        );
      });

      await queue.add('test', {}, { jobId: 'a', priority: 1 });
      await queue.add('test', {}, { jobId: 'b', priority: 2 });
      await queue.add('test', {}, { jobId: 'd', priority: 4 });
      const job = await queue.add(
        'test',
        {},
        { jobId: 'c', delay: 2000, priority: 3 },
      );
      await job.promote();

      worker.run();

      await completing;
      await worker.close();
    });

    it('should not promote a job that is not delayed', async () => {
      const job = await Job.create(queue, 'test', { foo: 'bar' });
      const isDelayed = await job.isDelayed();
      expect(isDelayed).toBe(false);

      await expect(job.promote()).rejects.toThrow(
        `Job ${job.id} is not in the delayed state. promote`,
      );
    });

    describe('when queue is paused', () => {
      it('should promote delayed job to the right queue', async () => {
        await queue.add('normal', { foo: 'bar' });
        const delayedJob = await queue.add(
          'delayed',
          { foo: 'bar' },
          { delay: 100 },
        );

        await queue.pause();
        await delayedJob.promote();

        const waitingJobsCountWhilePaused = await queue.getWaitingCount();
        expect(waitingJobsCountWhilePaused).toBe(2);
        await queue.resume();

        const waitingJobsCount = await queue.getWaitingCount();
        expect(waitingJobsCount).toBe(2);
        const delayedJobsNewState = await delayedJob.getState();
        expect(delayedJobsNewState).toBe('waiting');
      });
    });

    describe('when queue is empty', () => {
      it('should promote delayed job to the right queue', async () => {
        const delayedJob = await queue.add(
          'delayed',
          { foo: 'bar' },
          { delay: 100 },
        );

        await queue.pause();
        await delayedJob.promote();

        const waitingJobsCountWhilePaused = await queue.getWaitingCount();
        expect(waitingJobsCountWhilePaused).toBe(1);
        await queue.resume();

        const waitingJobsCount = await queue.getWaitingCount();
        expect(waitingJobsCount).toBe(1);
        const delayedJobsNewState = await delayedJob.getState();
        expect(delayedJobsNewState).toBe('waiting');
      });
    });
  });

  describe('.getState', () => {
    it('should get job actual state', async () => {
      const worker = new Worker(queueName, null, { connection, prefix });
      const token = 'my-token';
      const job = await queue.add('job1', { foo: 'bar' }, { delay: 1000 });
      const delayedState = await job.getState();

      expect(delayedState).toBe('delayed');

      await queue.pause();
      await job.promote();
      await queue.resume();
      const waitingState = await job.getState();

      expect(waitingState).toBe('waiting');

      const currentJob1 = (await worker.getNextJob(token)) as Job;
      expect(currentJob1).toBeDefined();

      await currentJob1.moveToFailed(new Error('test error'), token, true);
      const failedState = await currentJob1.getState();
      await queue.add('job2', { foo: 'foo' });
      const job2 = (await worker.getNextJob(token)) as Job;

      expect(failedState).toBe('failed');

      await job2.moveToCompleted('succeeded', token, true);
      const completedState = await job2.getState();

      expect(completedState).toBe('completed');
      await worker.close();
    });
  });

  // TODO:
  // Divide into several tests
  //
  /*
  const scripts = require('../lib/scripts');
  it('get job status', async () => {
    // TODO: Move timeout to test options: { timeout: 12000 }

    const client = new redis();
    return Job.create(queue, { foo: 'baz' })
      .then(job => {
        return job
          .isStuck()
          .then(isStuck => {
            expect(isStuck).toBe(false);
            return job.getState();
          })
          .then(state => {
            expect(state).toBe('waiting');
            return scripts.moveToActive(queue).then(() => {
              return job.moveToCompleted();
            });
          })
          .then(() => {
            return job.isCompleted();
          })
          .then(isCompleted => {
            expect(isCompleted).toBe(true);
            return job.getState();
          })
          .then(state => {
            expect(state).toBe('completed');
            return client.zrem(queue.toKey('completed'), job.id);
          })
          .then(() => {
            return job.moveToDelayed(Date.now() + 10000, true);
          })
          .then(() => {
            return job.isDelayed();
          })
          .then(yes => {
            expect(yes).toBe(true);
            return job.getState();
          })
          .then(state => {
            expect(state).toBe('delayed');
            return client.zrem(queue.toKey('delayed'), job.id);
          })
          .then(() => {
            return job.moveToFailed(new Error('test'), true);
          })
          .then(() => {
            return job.isFailed();
          })
          .then(isFailed => {
            expect(isFailed).toBe(true);
            return job.getState();
          })
          .then(state => {
            expect(state).toBe('failed');
            return client.zrem(queue.toKey('failed'), job.id);
          })
          .then(res => {
            expect(res).toBe(1);
            return job.getState();
          })
          .then(state => {
            expect(state).toBe('stuck');
            return client.rpop(queue.toKey('wait'));
          })
          .then(() => {
            return client.lpush(queue.toKey('paused'), job.id);
          })
          .then(() => {
            return job.isPaused();
          })
          .then(isPaused => {
            expect(isPaused).toBe(true);
            return job.getState();
          })
          .then(state => {
            expect(state).toBe('paused');
            return client.rpop(queue.toKey('paused'));
          })
          .then(() => {
            return client.lpush(queue.toKey('wait'), job.id);
          })
          .then(() => {
            return job.isWaiting();
          })
          .then(isWaiting => {
            expect(isWaiting).toBe(true);
            return job.getState();
          })
          .then(state => {
            expect(state).toBe('waiting');
          });
      })
      .then(() => {
        return client.quit();
      });
  });
  */

  describe('.finished', () => {
    let queueEvents: QueueEvents;

    beforeEach(async () => {
      queueEvents = new QueueEvents(queueName, { connection, prefix });
      await queueEvents.waitUntilReady();
    });

    afterEach(async () => {
      await queueEvents.close();
    });

    it('should resolve when the job has been completed', async () => {
      const worker = new Worker(queueName, async () => 'qux', {
        connection,
        prefix,
      });

      const job = await queue.add('test', { foo: 'bar' });

      const result = await job.waitUntilFinished(queueEvents);

      expect(result).toBe('qux');

      await worker.close();
    });

    describe('when job was added with removeOnComplete', async () => {
      it('rejects with missing key for job message', async () => {
        const worker = new Worker(
          queueName,
          async () => {
            await delay(100);
            return 'qux';
          },
          {
            connection,
            prefix,
          },
        );
        await worker.waitUntilReady();

        const completed = new Promise<void>((resolve, reject) => {
          worker.on('completed', async (job: Job) => {
            try {
              const gotJob = await queue.getJob(job.id!);
              expect(gotJob).toBe(undefined);
              const counts = await queue.getJobCounts('completed');
              expect(counts.completed).toBe(0);
              resolve();
            } catch (err) {
              reject(err);
            }
          });
        });

        const job = await queue.add(
          'test',
          { foo: 'bar' },
          { removeOnComplete: true },
        );

        await completed;

        await expect(job.waitUntilFinished(queueEvents)).rejects.toThrow(
          `Missing key for job ${queue.toKey(job.id!)}. isFinished`,
        );

        await worker.close();
      });
    });

    it('should resolve when the job has been completed and return object', async () => {
      const worker = new Worker(queueName, async () => ({ resultFoo: 'bar' }), {
        connection,
        prefix,
      });

      const job = await queue.add('test', { foo: 'bar' });

      const result = await job.waitUntilFinished(queueEvents);

      expect(result).toBeTypeOf('object');
      expect(result.resultFoo).toBe('bar');

      await worker.close();
    });

    it('should resolve when the job has been delayed and completed and return object', async () => {
      const worker = new Worker(
        queueName,
        async () => {
          await delay(300);
          return { resultFoo: 'bar' };
        },
        { connection, prefix },
      );

      const job = await queue.add('test', { foo: 'bar' });
      await delay(600);

      const result = await job.waitUntilFinished(queueEvents);
      expect(result).toBeTypeOf('object');
      expect(result.resultFoo).toBe('bar');

      await worker.close();
    });

    it('should resolve when the job has been completed and return string', async () => {
      const worker = new Worker(queueName, async () => 'a string', {
        connection,
        prefix,
      });

      const job = await queue.add('test', { foo: 'bar' });

      const result = await job.waitUntilFinished(queueEvents);

      expect(typeof result).toBe('string');
      expect(result).toBe('a string');

      await worker.close();
    });

    it('should reject when the job has been failed', async () => {
      const worker = new Worker(
        queueName,
        async () => {
          await delay(500);
          throw new Error('test error');
        },
        { connection, prefix },
      );

      const job = await queue.add('test', { foo: 'bar' });

      await expect(job.waitUntilFinished(queueEvents)).rejects.toThrow(
        'test error',
      );

      await worker.close();
    });

    it('should resolve directly if already processed', async () => {
      const worker = new Worker(queueName, async () => ({ resultFoo: 'bar' }), {
        connection,
        prefix,
      });

      const job = await queue.add('test', { foo: 'bar' });

      await delay(500);
      const result = await job.waitUntilFinished(queueEvents);

      expect(result).toBeTypeOf('object');
      expect(result.resultFoo).toBe('bar');

      await worker.close();
    });

    it('should reject directly if already processed', async () => {
      const worker = new Worker(
        queueName,
        async () => {
          throw new Error('test error');
        },
        { connection, prefix },
      );

      const job = await queue.add('test', { foo: 'bar' });

      await delay(500);
      try {
        await job.waitUntilFinished(queueEvents);
        throw new Error('should have been rejected');
      } catch (err) {
        expect(err.message).toBe('test error');
      }

      await worker.close();
    });
  });
});
