import {
  getRedisVersion,
  getDatabaseType,
  getRedisClient,
} from './utils/get-redis-client';
import { after, times } from './utils/lodash';
import {
  describe,
  beforeEach,
  afterEach,
  beforeAll,
  afterAll,
  it,
  expect,
} from 'vitest';

import * as sinon from 'sinon';
import { EventEmitter } from 'events';
import {
  Queue,
  QueueEvents,
  Job,
  RedisQueueBackend,
  UnrecoverableError,
  Worker,
  DelayedError,
  WaitingError,
} from '../src/classes';
import { MinimalJob, IRedisClient } from '../src/interfaces';
import { JobsOptions, KeepJobs } from '../src/types';
import { delay, isRedisVersionLowerThan, randomUUID } from '../src/utils';
import { createTestConnection } from './utils/connection-factory';
import { cleanupQueue } from './utils/cleanup-queue';

const NoopProc = () => Promise.resolve();

/**
 * Backend-agnostic qualified queue name. Derives the qualifier (the `bull:`
 * prefix on Redis, or nothing on PostgreSQL) from a reference queue whose
 * `qualifiedName` is known, so parent/child key references hold on any backend.
 */
const qualify = (
  ref: { qualifiedName: string; name: string },
  queueName: string,
): string =>
  `${ref.qualifiedName.slice(
    0,
    ref.qualifiedName.length - ref.name.length,
  )}${queueName}`;

describe('workers', () => {
  const prefix = process.env.BULLMQ_TEST_PREFIX || 'bull';

  const sandbox = sinon.createSandbox();

  let queue: Queue;
  let queueEvents: QueueEvents;
  let queueName: string;

  let connection: IRedisClient;
  beforeAll(async () => {
    connection = createTestConnection();
  });

  beforeEach(async () => {
    queueName = `test-${randomUUID()}`;
    queue = new Queue(queueName, { connection, prefix });
    queueEvents = new QueueEvents(queueName, { connection, prefix });
    await queueEvents.waitUntilReady();
  });

  afterEach(async () => {
    sandbox.restore();
    // Restore any fake clock installed via `sinon.useFakeTimers()` that a timed
    // out / failed test left behind, so it doesn't cascade into the next test
    // as "Can't install fake timers twice on the same global object".
    sinon.restore();
    await queue.close();
    await queueEvents.close();
    await cleanupQueue(queueName);
  });

  afterAll(async function () {
    await connection.quit();
  });

  it('process a lifo queue', async () => {
    // TODO: Move timeout to test options: { timeout: 3000 }
    let currentValue = 0;
    let first = true;

    let processor;
    const processing = new Promise<void>((resolve, reject) => {
      processor = async (job: Job) => {
        try {
          expect(job.data.count).toBe(currentValue--);
        } catch (err) {
          reject(err);
        }

        if (first) {
          first = false;
        } else if (currentValue === 0) {
          resolve();
        }
      };
    });

    const worker = new Worker(queueName, processor, { connection, prefix });
    await worker.waitUntilReady();

    await queue.pause();
    // Add a series of jobs in a predictable order
    const jobs = [
      { count: ++currentValue },
      { count: ++currentValue },
      { count: ++currentValue },
      { count: ++currentValue },
    ];
    await Promise.all(
      jobs.map(jobData => {
        return queue.add('test', jobData, { lifo: true });
      }),
    );
    await queue.resume();

    await processing;

    await worker.close();
  });

  it('process several jobs serially', async () => {
    let counter = 1;
    const maxJobs = 35;

    let processor;
    const processing = new Promise<void>((resolve, reject) => {
      processor = async (job: Job) => {
        try {
          expect(job.data.num).toBe(counter);
          expect(job.data.foo).toBe('bar');
          if (counter === maxJobs) {
            resolve();
          }
          counter++;
        } catch (err) {
          reject(err);
        }
      };
    });

    const worker = new Worker(queueName, processor, { connection, prefix });
    await worker.waitUntilReady();

    for (let i = 1; i <= maxJobs; i++) {
      await queue.add('test', { foo: 'bar', num: i });
    }

    await processing;
    expect(worker.isRunning()).toBe(true);

    await worker.close();
  });

  it('process a job that updates progress as number', async () => {
    let processor;

    const job = await queue.add('test', { foo: 'bar' });
    expect(job.id).toBeTruthy();
    expect(job.data.foo).toEqual('bar');

    const processing = new Promise<void>((resolve, reject) => {
      queueEvents.on('progress', ({ jobId, data }) => {
        expect(jobId).toBeTruthy();
        expect(data).toEqual(42);
        resolve();
      });

      processor = async (job: Job) => {
        try {
          expect(job.data.foo).toBe('bar');
          await job.updateProgress(42);
        } catch (err) {
          reject(err);
        }
      };
    });

    const worker = new Worker(queueName, processor, { connection, prefix });
    await worker.waitUntilReady();

    await processing;

    await worker.close();
  });

  // NOTE: 'should cap progress events' is Redis-specific (it asserts the
  // trimmed event-stream length via `xlen`) and lives in
  // `worker.redis.test.ts`.

  it('process a job that updates progress as object', async () => {
    let processor;

    const job = await queue.add('test', { foo: 'bar' });
    expect(job.id).toBeTruthy();
    expect(job.data.foo).toEqual('bar');

    const processing = new Promise<void>((resolve, reject) => {
      queueEvents.on('progress', ({ jobId, data }) => {
        expect(jobId).toBeTruthy();
        expect(data).toEqual({ percentage: 42 });
        resolve();
      });

      processor = async (job: Job) => {
        try {
          expect(job.data.foo).toBe('bar');
          await job.updateProgress({ percentage: 42 });
        } catch (err) {
          reject(err);
        }
      };
    });

    const worker = new Worker(queueName, processor, { connection, prefix });
    await worker.waitUntilReady();

    await processing;

    await worker.close();
  });

  it('process a job that updates progress as string', async () => {
    let processor;

    const job = await queue.add('test', { foo: 'bar' });
    expect(job.id).toBeTruthy();
    expect(job.data.foo).toEqual('bar');

    const processing = new Promise<void>((resolve, reject) => {
      queueEvents.on('progress', ({ jobId, data }) => {
        expect(jobId).toBeTruthy();
        expect(data).toEqual('progress as string');
        resolve();
      });

      processor = async (job: Job) => {
        try {
          expect(job.data.foo).toBe('bar');
          await job.updateProgress('progress as string');
        } catch (err) {
          reject(err);
        }
      };
    });

    const worker = new Worker(queueName, processor, { connection, prefix });
    await worker.waitUntilReady();

    await processing;

    await worker.close();
  });

  it('process a job that updates progress as boolean', async () => {
    let processor;

    const job = await queue.add('test', { foo: 'bar' });
    expect(job.id).toBeTruthy();
    expect(job.data.foo).toEqual('bar');

    const processing = new Promise<void>((resolve, reject) => {
      queueEvents.on('progress', ({ jobId, data }) => {
        expect(jobId).toBeTruthy();
        expect(data).toEqual(true);
        resolve();
      });

      processor = async (job: Job) => {
        try {
          expect(job.data.foo).toBe('bar');
          await job.updateProgress(true);
        } catch (err) {
          reject(err);
        }
      };
    });

    const worker = new Worker(queueName, processor, { connection, prefix });
    await worker.waitUntilReady();

    await processing;

    await worker.close();
  });

  it('process a job that updates progress with a typed progress generic', async () => {
    type CustomProgress = { percentage: number; message: string };
    const expected: CustomProgress = { percentage: 42, message: 'halfway' };

    const job = await queue.add('test', { foo: 'bar' });
    expect(job.id).toBeTruthy();
    expect(job.data.foo).toEqual('bar');

    const worker = new Worker<
      { foo: string },
      void,
      string,
      RedisQueueBackend,
      CustomProgress
    >(
      queueName,
      async job => {
        expect(job.data.foo).toBe('bar');
        // `progress` is typed as CustomProgress here, not JobProgress.
        await job.updateProgress(expected);
      },
      { autorun: false, connection, prefix },
    );
    await worker.waitUntilReady();

    const processing = new Promise<void>((resolve, reject) => {
      worker.on('progress', (_job, progress) => {
        try {
          expect(progress.percentage).toEqual(42);
          expect(progress.message).toEqual('halfway');
          resolve();
        } catch (err) {
          reject(err);
        }
      });
    });

    worker.run();

    await processing;

    await worker.close();
  });

  it('processes jobs that were added before the worker started', async () => {
    const jobs = [
      queue.add('test', { bar: 'baz' }),
      queue.add('test', { bar1: 'baz1' }),
      queue.add('test', { bar2: 'baz2' }),
      queue.add('test', { bar3: 'baz3' }),
    ];

    await Promise.all(jobs);

    const worker = new Worker(queueName, NoopProc, {
      connection,
      prefix,
    });
    await worker.waitUntilReady();

    await new Promise(resolve => {
      const resolveAfterAllJobs = after(jobs.length, resolve);
      worker.on('completed', resolveAfterAllJobs);
    });

    await worker.close();
  });

  it('process a job that returns data in the process handler', async () => {
    const worker = new Worker(
      queueName,
      async job => {
        expect(job.data.foo).toBe('bar');
        return 37;
      },
      { connection, prefix },
    );
    await worker.waitUntilReady();

    const job = await queue.add('test', { foo: 'bar' });
    expect(job.id).toBeTruthy();
    expect(job.data.foo).toEqual('bar');

    await new Promise<void>((resolve, reject) => {
      worker.on('completed', async (job: Job, data: any) => {
        try {
          expect(job).toBeTruthy();
          expect(data).toEqual(37);

          const gotJob = await queue.getJob(job.id!);
          expect(gotJob!.returnvalue).toEqual(37);
          resolve();
        } catch (err) {
          reject(err);
        }
      });
    });

    await worker.close();
  });

  it('process a job that returns a string in the process handler', async () => {
    const testString = 'a very dignified string';

    const worker = new Worker(
      queueName,
      async () => {
        return testString;
      },
      { connection, prefix },
    );
    await worker.waitUntilReady();

    const waiting = new Promise<void>((resolve, reject) => {
      queueEvents.on('completed', async data => {
        try {
          expect(data).toBeTruthy();
          expect(data.returnvalue).toBe(testString);
          await delay(100);
          const gotJob = await queue.getJob(data.jobId);

          expect(gotJob).toBeTruthy();
          expect(gotJob.returnvalue).toBe(testString);
          resolve();
        } catch (err) {
          reject(err);
        }
      });
    });

    await queue.add('test', { testing: true });
    await waiting;
    await worker.close();
  });

  it('process a job that returning data returnvalue gets stored in the database', async () => {
    const worker = new Worker(
      queueName,
      async job => {
        expect(job.data.foo).toBe('bar');
        return 37;
      },
      { connection, prefix },
    );
    await worker.waitUntilReady();

    const job = await queue.add('test', { foo: 'bar' });
    expect(job.id).toBeTruthy();
    expect(job.data.foo).toEqual('bar');

    await new Promise<void>((resolve, reject) => {
      worker.on('completed', async (job: Job, data: any) => {
        try {
          expect(job).toBeTruthy();
          expect(data).toEqual(37);
          const gotJob = await queue.getJob(job.id);
          expect(gotJob.returnvalue).toEqual(37);
          resolve();
        } catch (err) {
          reject(err);
        }
      });
    });

    await worker.close();
  });

  it('process a job that does some asynchronous operation', async () => {
    const worker = new Worker(
      queueName,
      async job => {
        expect(job.data.foo).toBe('bar');
        await delay(250);
        return 'my data';
      },
      { connection, prefix },
    );
    await worker.waitUntilReady();

    const job = await queue.add('test', { foo: 'bar' });
    expect(job.id).toBeTruthy();
    expect(job.data.foo).toEqual('bar');

    await new Promise<void>(resolve => {
      worker.on('completed', (job: Job, data: any) => {
        expect(job).toBeTruthy();
        expect(data).toEqual('my data');
        resolve();
      });
    });

    await worker.close();
  });

  it('process a synchronous job', async () => {
    const worker = new Worker(
      queueName,
      async job => {
        expect(job.data.foo).toBe('bar');
      },
      { connection, prefix },
    );

    await worker.waitUntilReady();

    const job = await queue.add('test', { foo: 'bar' });
    expect(job.id).toBeTruthy();
    expect(job.data.foo).toEqual('bar');

    await new Promise<void>(resolve => {
      worker.on('completed', job => {
        expect(job).toBeTruthy();
        resolve();
      });
    });

    await worker.close();
  });

  it('process a slow job without waiting previous job to finish', async () => {
    const worker = new Worker(
      queueName,
      async job => {
        expect(job.data.foo).toBe('bar');
        if (job.data.index == 1) {
          await queue.add('test', { foo: 'bar', index: 2 });
          await delay(1000);
        }
        return 'my data';
      },
      { connection, prefix, concurrency: 2 },
    );
    await worker.waitUntilReady();

    const job1 = await queue.add('test', { foo: 'bar', index: 1 });
    expect(job1.id).toBeTruthy();
    expect(job1.data.foo).toEqual('bar');

    let completedIndex;
    await new Promise<void>((resolve, reject) => {
      worker.on('completed', (job: Job, result: any) => {
        try {
          expect(job).toBeTruthy();
          expect(result).toEqual('my data');

          if (!completedIndex) {
            expect(job.data.index).toEqual(2);
            completedIndex = 2;
          }

          if (job.data.index == 1) {
            resolve();
          }
        } catch (err) {
          reject(err);
        }
      });
    });

    await worker.close();
  }); // TODO: Add { timeout: 8000 } to the it() options

  // NOTE: 'do not call moveToActive more than concurrency factor + 1' is
  // Redis-specific (it spies on the blocking client's `bzpopmin`) and lives in
  // NOTE: 'do not call moveToActive more than concurrency factor + 1' and
  // 'do not call moveToActive more than number of jobs + 2' are Redis-specific
  // (they spy on the blocking client's `bzpopmin`) and live in
  // `worker.redis.test.ts`.

  it('does not process a job that is being processed when a new queue starts', async () => {
    // TODO: Move timeout to test options: { timeout: 12000 }
    let err;

    const worker = new Worker(
      queueName,
      async job => {
        expect(job.data.foo).toBe('bar');

        if (addedJob.id !== job.id) {
          err = new Error('Processed job id does not match that of added job');
        }
        await delay(500);
      },
      { connection, prefix },
    );

    await worker.waitUntilReady();

    const addedJob = await queue.add('test', { foo: 'bar' });

    const anotherWorker = new Worker(
      queueName,
      async () => {
        err = new Error(
          'The second queue should not have received a job to process',
        );
      },
      { connection, prefix },
    );

    await anotherWorker.waitUntilReady();

    await new Promise<void>(resolve => {
      worker.on('completed', async () => {
        resolve();
      });
    });

    await worker.close();
    await anotherWorker.close();

    if (err) {
      throw err;
    }
  });

  it('process a job that throws an exception', async () => {
    const jobError = new Error('Job Failed');

    const worker = new Worker(
      queueName,
      async job => {
        expect(job.data.foo).toBe('bar');
        throw jobError;
      },
      { autorun: false, connection, prefix },
    );
    await worker.waitUntilReady();

    const job = await queue.add('test', { foo: 'bar' });
    expect(job.id).toBeTruthy();
    expect(job.data.foo).toEqual('bar');

    const failing = new Promise<void>((resolve, reject) => {
      worker.once('failed', async (job, err) => {
        try {
          expect(job).toBeTruthy();
          expect(job!.finishedOn).toBeTypeOf('number');
          expect(job!.data.foo).toEqual('bar');
          expect(err).toEqual(jobError);
          resolve();
        } catch (err) {
          reject(err);
        }
      });
    });

    worker.run();

    await failing;

    await worker.close();
  });

  it('process a job that returns data with a circular dependency', async () => {
    const worker = new Worker(
      queueName,
      async () => {
        const circular = { x: {} };
        circular.x = circular;
        return circular;
      },
      { connection, prefix },
    );
    await worker.waitUntilReady();

    const waiting = new Promise<void>((resolve, reject) => {
      worker.on('failed', () => {
        resolve();
      });
      worker.on('completed', () => {
        reject(Error('Should not complete'));
      });
    });

    await queue.add('test', { foo: 'bar' });

    await waiting;
    await worker.close();
  });

  it('process a job that returns a rejected promise', async () => {
    const jobError = new Error('Job Failed');

    const worker = new Worker(
      queueName,
      async job => {
        expect(job.data.foo).toBe('bar');
        return Promise.reject(jobError);
      },
      { connection, prefix },
    );
    await worker.waitUntilReady();

    const job = await queue.add('test', { foo: 'bar' });
    expect(job.id).toBeTruthy();
    expect(job.data.foo).toEqual('bar');

    await new Promise<void>((resolve, reject) => {
      worker.once('failed', (job, err) => {
        try {
          expect(job.id).toBeTruthy();
          expect(job.data.foo).toEqual('bar');
          expect(err).toEqual(jobError);
          resolve();
        } catch (err) {
          reject(err);
        }
      });
    });

    await worker.close();
  });

  it('sets the worker name on the job upon processing', async () => {
    let worker;
    const processing = new Promise<void>(async (resolve, reject) => {
      worker = new Worker(
        queueName,
        async job => {
          try {
            await delay(100);
            expect(job).toBeTruthy();
            expect(job!.processedBy).toBe(worker.opts.name);
          } catch (err) {
            reject(err);
          }

          if (job.data.foo === 'baz') {
            resolve();
          }
        },
        { connection, prefix, name: 'foobar' },
      );
      await worker.waitUntilReady();
    });

    await queue.add('test1', { foo: 'bar' });
    await queue.add('test2', { foo: 'baz' });

    await processing;

    await worker.close();
  });

  describe('when job is in failed state', () => {
    it('retries a job that fails', async () => {
      let failedOnce = false;
      const notEvenErr = new Error('Not even!');

      const worker = new Worker(
        queueName,
        async () => {
          if (!failedOnce) {
            throw notEvenErr;
          }
        },
        { connection, prefix },
      );
      await worker.waitUntilReady();

      const failing = new Promise<void>((resolve, reject) => {
        worker.once('failed', async (job, err) => {
          try {
            expect(job).toBeTruthy();
            expect(job?.data.foo).toEqual('bar');
            expect(job?.attemptsStarted).toEqual(1);
            expect(job?.attemptsMade).toEqual(1);
            expect(err).toEqual(notEvenErr);
            failedOnce = true;
          } catch (err) {
            reject(err);
          }
          resolve();
        });
      });

      const completing = new Promise<void>((resolve, reject) => {
        worker.once('completed', job => {
          try {
            expect(failedOnce).toEqual(true);
            expect(job?.attemptsStarted).toEqual(2);
            expect(job?.attemptsMade).toEqual(2);
            resolve();
          } catch (err) {
            reject(err);
          }
        });
      });

      const job = await queue.add('test', { foo: 'bar' });
      expect(job.id).toBeTruthy();
      expect(job.data.foo).toEqual('bar');

      await failing;
      await job.retry();
      await completing;

      await worker.close();
    });

    describe('when passing resetAttemptsMade and resetAttemptsStarted as true', () => {
      it('retries a job that fails and resets attemptsMade and attemptsStarted', async () => {
        let failedOnce = false;
        const notEvenErr = new Error('Not even!');

        const worker = new Worker(
          queueName,
          async () => {
            if (!failedOnce) {
              throw notEvenErr;
            }
          },
          { connection, prefix },
        );
        await worker.waitUntilReady();

        const failing = new Promise<void>((resolve, reject) => {
          worker.once('failed', async (job, err) => {
            try {
              expect(job).toBeTruthy();
              expect(job?.data.foo).toEqual('bar');
              expect(job?.attemptsStarted).toEqual(1);
              expect(job?.attemptsMade).toEqual(1);
              expect(err).toEqual(notEvenErr);
              failedOnce = true;
            } catch (err) {
              reject(err);
            }
            resolve();
          });
        });

        const completing = new Promise<void>((resolve, reject) => {
          worker.once('completed', job => {
            try {
              expect(failedOnce).toEqual(true);
              expect(job?.attemptsStarted).toEqual(1);
              expect(job?.attemptsMade).toEqual(1);
              resolve();
            } catch (err) {
              reject(err);
            }
          });
        });

        const job = await queue.add('test', { foo: 'bar' });
        expect(job.id).toBeTruthy();
        expect(job.data.foo).toEqual('bar');

        await failing;
        await job.retry('failed', {
          resetAttemptsMade: true,
          resetAttemptsStarted: true,
        });
        await completing;

        await worker.close();
      });
    });
  });

  describe('when job is in completed state', () => {
    it('retries a job that completes', async () => {
      let completedOnce = false;

      const worker = new Worker(
        queueName,
        async () => {
          if (!completedOnce) {
            return 1;
          }
          return 2;
        },
        { connection, prefix },
      );
      await worker.waitUntilReady();

      let count = 1;
      const completing = new Promise<void>((resolve, reject) => {
        worker.once('completed', async (job, result) => {
          try {
            expect(job).toBeTruthy();
            expect(job?.data.foo).toEqual('bar');
            expect(job?.attemptsStarted).toEqual(1);
            expect(job?.attemptsMade).toEqual(1);
            expect(result).toEqual(count++);
            completedOnce = true;
          } catch (err) {
            reject(err);
          }
          resolve();
        });
      });

      const job = await queue.add('test', { foo: 'bar' });
      expect(job.id).toBeTruthy();
      expect(job.data.foo).toEqual('bar');

      await completing;
      worker.removeAllListeners('completed');

      const completing2 = new Promise<void>((resolve, reject) => {
        worker.once('completed', async (job, result) => {
          try {
            expect(job).toBeTruthy();
            expect(job?.data.foo).toEqual('bar');
            expect(job?.attemptsStarted).toEqual(2);
            expect(job?.attemptsMade).toEqual(2);
            expect(result).toEqual(count++);
          } catch (err) {
            reject(err);
          }
          resolve();
        });
      });

      await job.retry('completed');
      await completing2;

      await worker.close();
    });

    describe('when passing resetAttemptsMade and resetAttemptsStarted as true', () => {
      it('retries a job that completes and resets attemptsMade and attemptsStarted', async () => {
        let completedOnce = false;

        const worker = new Worker(
          queueName,
          async () => {
            if (!completedOnce) {
              return 1;
            }
            return 2;
          },
          { connection, prefix },
        );
        await worker.waitUntilReady();

        let count = 1;
        const completing = new Promise<void>((resolve, reject) => {
          worker.once('completed', async (job, result) => {
            try {
              expect(job).toBeTruthy();
              expect(job?.data.foo).toEqual('bar');
              expect(job?.attemptsStarted).toEqual(1);
              expect(job?.attemptsMade).toEqual(1);
              expect(result).toEqual(count++);
              completedOnce = true;
            } catch (err) {
              reject(err);
            }
            resolve();
          });
        });

        const job = await queue.add('test', { foo: 'bar' });
        expect(job.id).toBeTruthy();
        expect(job.data.foo).toEqual('bar');

        await completing;
        worker.removeAllListeners('completed');

        const completing2 = new Promise<void>((resolve, reject) => {
          worker.once('completed', async (job, result) => {
            try {
              expect(job).toBeTruthy();
              expect(job?.data.foo).toEqual('bar');
              expect(job?.attemptsStarted).toEqual(1);
              expect(job?.attemptsMade).toEqual(1);
              expect(result).toEqual(count++);
            } catch (err) {
              reject(err);
            }
            resolve();
          });
        });

        await job.retry('completed', {
          resetAttemptsMade: true,
          resetAttemptsStarted: true,
        });
        await completing2;

        await worker.close();
      });
    });
  });

  // NOTE: 'when 0.002 is used as blocktimeout > should not block forever' is
  // Redis-specific (it calls `bzpopmin` on the raw client and inspects the
  // Redis version) and lives in `worker.redis.test.ts`.

  describe('when closing a worker', () => {
    it('process a job that throws an exception after worker close', async () => {
      const jobError = new Error('Job Failed');

      const worker = new Worker(
        queueName,
        async job => {
          expect(job.data.foo).toBe('bar');
          await delay(3000);
          throw jobError;
        },
        { connection, prefix },
      );
      await worker.waitUntilReady();

      const job = await queue.add('test', { foo: 'bar' });

      expect(job.id).toBeTruthy();
      expect(job.data.foo).toEqual('bar');

      await delay(100);
      /* Try to gracefully close while having a job that will be failed running */
      const closing = worker.close();

      await new Promise<void>(resolve => {
        worker.once('failed', async (job, err) => {
          expect(job).toBeTruthy();
          expect(job.data.foo).toEqual('bar');
          expect(err).toEqual(jobError);
          resolve();
        });
      });

      const count = await queue.getJobCounts('active', 'failed');
      expect(count.active).toBe(0);
      expect(count.failed).toBe(1);
      await closing;
    });

    it('process a job that complete after worker close', async () => {
      const worker = new Worker(
        queueName,
        async job => {
          expect(job.data.foo).toBe('bar');
          await delay(3000);
        },
        { connection, prefix },
      );
      await worker.waitUntilReady();

      const job = await queue.add('test', { foo: 'bar' });

      expect(job.id).toBeTruthy();
      expect(job.data.foo).toEqual('bar');

      await delay(100);
      /* Try to gracefully close while having a job that will be completed running */
      const closing = worker.close();

      await new Promise<void>((resolve, reject) => {
        worker.once('completed', async job => {
          try {
            expect(job).toBeTruthy();
            expect(job.finishedOn).toBeTypeOf('number');
            expect(job.data.foo).toEqual('bar');
            resolve();
          } catch (err) {
            reject(err);
          }
        });
      });

      const count = await queue.getJobCounts('active', 'completed');
      expect(count.active).toBe(0);
      expect(count.completed).toBe(1);
      await closing;
    });

    it(
      'resolves close() when an active job throws DelayedError during shutdown',
      { timeout: 10000 },
      async () => {
        let processingStartedResolve: () => void;
        const processingStarted = new Promise<void>(resolve => {
          processingStartedResolve = resolve;
        });

        const worker = new Worker(
          queueName,
          async (job, token) => {
            processingStartedResolve();
            await job.moveToDelayed(Date.now(), token);
            await delay(200);
            throw new DelayedError();
          },
          { connection, prefix, drainDelay: 10 },
        );
        await worker.waitUntilReady();

        const jobs = Array.from(Array(50).keys()).map(index => ({
          name: 'test',
          data: { index },
        }));
        await queue.addBulk(jobs);

        // Wait for the first processing cycle to begin before closing
        await processingStarted;

        const result = await Promise.race([
          worker.close().then(() => 'closed'),
          delay(5000).then(() => 'timeout'),
        ]);

        expect(result).toBe('closed');
      },
    );

    it(
      'resolves close() when a paused worker has an active job that throws DelayedError',
      { timeout: 10000 },
      async () => {
        let processingStartedResolve: () => void;
        const processingStarted = new Promise<void>(resolve => {
          processingStartedResolve = resolve;
        });

        const worker = new Worker(
          queueName,
          async (job, token) => {
            processingStartedResolve();
            await job.moveToDelayed(Date.now(), token);
            await delay(200);
            throw new DelayedError();
          },
          { connection, prefix, drainDelay: 10 },
        );
        await worker.waitUntilReady();

        const jobs = Array.from(Array(50).keys()).map(index => ({
          name: 'test',
          data: { index },
        }));
        await queue.addBulk(jobs);

        // Wait for the first processing cycle to begin, then pause
        await processingStarted;
        await worker.pause();

        const result = await Promise.race([
          worker.close().then(() => 'closed'),
          delay(5000).then(() => 'timeout'),
        ]);

        expect(result).toBe('closed');
      },
    );
  });

  describe('when waiting for a job', () => {
    it('reconnects blocking transport after a connection error (#4378)', async () => {
      const worker = new Worker(queueName, NoopProc, {
        autorun: false,
        connection,
        prefix,
      });
      await worker.waitUntilReady();

      const workerDelay = sandbox.stub(worker, 'delay').resolves();
      const backend = worker.getBackend();
      const reconnectBlocking = sandbox
        .stub(backend, 'reconnectBlocking')
        .resolves();
      sandbox
        .stub(backend, 'waitForJob')
        .rejects(new Error('Connection is closed.'));

      try {
        await expect(worker['waitForJob'](0)).resolves.toBe(Infinity);
        expect(reconnectBlocking.calledOnce).toBe(true);
        expect(workerDelay.calledOnce).toBe(true);
      } finally {
        await worker.close();
      }
    });

    it('retries after reconnecting blocking transport fails', async () => {
      const worker = new Worker(queueName, NoopProc, {
        autorun: false,
        connection,
        prefix,
      });
      await worker.waitUntilReady();

      const backend = worker.getBackend();
      const workerDelay = sandbox.stub(worker, 'delay').resolves();
      const reconnectBlocking = sandbox
        .stub(backend, 'reconnectBlocking')
        .rejects(new Error('Connection is closed.'));
      sandbox
        .stub(backend, 'waitForJob')
        .rejects(new Error('Connection is closed.'));

      try {
        await expect(worker['waitForJob'](0)).resolves.toBe(Infinity);
        expect(reconnectBlocking.calledOnce).toBe(true);
        expect(workerDelay.calledOnce).toBe(true);
      } finally {
        await worker.close();
      }
    });

    it('recovers when the blocking command never settles (#4479)', async () => {
      const worker = new Worker(queueName, NoopProc, {
        autorun: false,
        connection,
        prefix,
      });
      await worker.waitUntilReady();

      const backend = worker.getBackend();
      const bclient = (await backend.blockingClient)!;

      // Reproduce the #4479 wedge: blocking connections must use
      // `maxRetriesPerRequest: null`, and with that setting IORedis silently
      // re-queues and re-sends an interrupted blocking command after a
      // reconnect instead of rejecting it — so the awaited `bzpopmin` never
      // settles. Before the watchdog fix this parked `waitForJob` forever.
      const bzpopmin = sandbox
        .stub(bclient, 'bzpopmin')
        .returns(new Promise(() => {}) as any);
      const reconnectBlocking = sandbox
        .stub(backend, 'reconnectBlocking')
        .resolves();

      try {
        // A tiny block timeout keeps the watchdog window small. The watchdog
        // must conclude the wait as a timeout (null) even though `bzpopmin`
        // never settles, and re-establish the blocking connection.
        const result = await backend.waitForJob(0.001);
        expect(result).toBe(null);
        expect(bzpopmin.calledOnce).toBe(true);
        expect(reconnectBlocking.calledOnce).toBe(true);
      } finally {
        await worker.close();
      }
    });

    it('does not disconnect a reconnecting blocking client (#4585)', async () => {
      const worker = new Worker(queueName, NoopProc, {
        autorun: false,
        connection,
        prefix,
      });
      await worker.waitUntilReady();

      const backend = worker.getBackend();
      const bclient = (await backend.blockingClient)!;

      // Reproduce the #4585 wedge: after an outage longer than the block
      // timeout, IORedis is already in "reconnecting" (it has an armed retry
      // timer but no live socket). Calling `disconnect(false)` here clears that
      // timer without emitting a `close` event, parking the client in
      // "reconnecting" forever. The watchdog must therefore only disconnect a
      // "ready" client and otherwise let IORedis finish its own reconnect.
      sandbox.stub(bclient, 'status').value('reconnecting');
      const disconnect = sandbox.stub(bclient, 'disconnect');
      sandbox.stub(bclient, 'bzpopmin').returns(new Promise(() => {}) as any);
      const reconnectBlocking = sandbox
        .stub(backend, 'reconnectBlocking')
        .resolves();

      try {
        const result = await backend.waitForJob(0.001);
        expect(result).toBe(null);
        expect(disconnect.called).toBe(false);
        expect(reconnectBlocking.calledOnce).toBe(true);
      } finally {
        await worker.close();
      }
    });

    it('drops the abandoned blocking command once the client is live again (#4585)', async () => {
      const worker = new Worker(queueName, NoopProc, {
        autorun: false,
        connection,
        prefix,
      });
      await worker.waitUntilReady();

      const backend = worker.getBackend();
      const bclient = (await backend.blockingClient)!;

      // Waiting for IORedis to finish its own reconnect is not enough: under
      // `maxRetriesPerRequest: null` it re-queues and re-sends the interrupted
      // blocking command, so it would be served ahead of the next
      // `waitForJob`. Once the client is live again the socket must be torn
      // down (and re-established) so the abandoned command is actually gone.
      let status = 'reconnecting';
      sandbox.stub(bclient, 'status').get(() => status);
      sandbox.stub(bclient, 'bzpopmin').returns(new Promise(() => {}) as any);

      const disconnectedWhileLive: boolean[] = [];
      sandbox
        .stub(backend.blockingConnection!, 'disconnect')
        .callsFake(async () => {
          disconnectedWhileLive.push(status === 'ready');
          status = 'end';
        });
      const reconnectBlocking = sandbox
        .stub(backend, 'reconnectBlocking')
        .callsFake(async () => {
          status = 'ready';
        });

      try {
        const result = await backend.waitForJob(0.001);
        expect(result).toBe(null);
        // First the retry timer is left alone until the client is live again,
        // then the live socket is torn down and re-established.
        expect(disconnectedWhileLive).toEqual([true]);
        expect(reconnectBlocking.callCount).toBe(2);
      } finally {
        await worker.close();
      }
    });

    it('reconnects a healthy connection torn down by the watchdog (#4585 ready-path race)', async () => {
      // Models the second #4585 race (reported on 6.0.11): after a brief drop
      // IORedis self-heals back to "ready" *before* the watchdog fires, so the
      // watchdog fires against a live connection with a still-unsettled blocking
      // command. It tears the connection down to abandon that command — but
      // IORedis closes the socket asynchronously, so `status` is still "ready"
      // for the current microtask run. If the reset then calls `reconnect()`
      // (which early-returns on "ready") *before* the close lands, it no-ops and
      // the pending close kills the connection for good.
      //
      // We call `RedisQueueBackend.prototype.waitForJob` with a fake context that
      // faithfully models (a) IORedis' asynchronous socket close and (b) the real
      // `RedisConnection.disconnect(true)` (close, then await "end") and
      // `RedisConnection.reconnect()` (early-return on "ready") contracts.
      const emitter = new EventEmitter();
      let status = 'ready';
      const client = {
        get status() {
          return status;
        },
        bzpopmin: () => new Promise(() => {}), // never settles
        // IORedis closes the socket asynchronously: `status` stays "ready" for
        // the current microtask run and only flips on a later macrotask.
        disconnect: () => {
          setTimeout(() => {
            status = 'end';
            emitter.emit('end');
          }, 0);
        },
        connect: () => {
          status = 'ready';
          return Promise.resolve();
        },
        once: (ev: string, fn: () => void) => emitter.once(ev, fn),
        removeListener: (ev: string, fn: () => void) =>
          emitter.removeListener(ev, fn),
      };

      const connection = {
        capabilities: { canDoubleTimeout: true },
        client: Promise.resolve(client),
        // Mirrors RedisConnection.disconnect(true): close, then await "end".
        disconnect: async (wait = true) => {
          if (status === 'end') {
            return;
          }
          if (!wait) {
            return client.disconnect();
          }
          const ended = new Promise<void>(res => client.once('end', res));
          client.disconnect();
          await ended;
        },
        // Mirrors RedisConnection.reconnect(): early-return on "ready".
        reconnect: async () => {
          for (;;) {
            if (status === 'ready') {
              return;
            }
            if (status === 'wait' || status === 'end') {
              return client.connect();
            }
            await new Promise(r => setTimeout(r, 5));
          }
        },
      };

      const backend = {
        closing: false,
        blockingConnection: connection,
        connection,
        queue: {
          keys: { marker: 'm' },
          blockingClient: Promise.resolve(client),
        },
        reconnectBlocking() {
          return connection.reconnect();
        },
      };

      const result = await (
        RedisQueueBackend.prototype.waitForJob as (
          this: unknown,
          blockTimeout: number,
        ) => Promise<unknown>
      ).call(backend, 0.001);

      expect(result).toBe(null);
      // Let any pending asynchronous close land.
      await new Promise(r => setTimeout(r, 30));
      // The blocking connection must be healthy again — not left dead by a
      // reconnect() that raced the watchdog's disconnect.
      expect(status).toBe('ready');
    }, 10000);
  });

  describe('when calling getBlockTimeout', () => {
    describe('when blockUntil is 0', () => {
      describe('when drainDelay is greater than minimumBlockTimeout', () => {
        it('returns drainDelay', async () => {
          const worker = new Worker(queueName, NoopProc, {
            connection,
            prefix,
            autorun: false,
          });

          expect(worker['getBlockTimeout'](0)).toBe(5);
          await worker.close();
        });
      });

      describe('when drainDelay is lower than minimumBlockTimeout', () => {
        it('returns drainDelay', async () => {
          const worker = new Worker(queueName, NoopProc, {
            connection,
            drainDelay: 0.00001,
            prefix,
            autorun: false,
          });
          await worker.waitUntilReady();

          if (
            isRedisVersionLowerThan(
              getRedisVersion(worker),
              '7.0.8',
              getDatabaseType(worker),
            )
          ) {
            expect(worker['getBlockTimeout'](0)).toBe(0.002);
          } else {
            expect(worker['getBlockTimeout'](0)).toBe(0.001);
          }
          await worker.close();
        });
      });
    });

    describe('when blockUntil is greater than 0', () => {
      describe('when blockUntil is lower than date now value', () => {
        it('returns blockDelay value lower or equal 0', async () => {
          const worker = new Worker(queueName, NoopProc, {
            connection,
            prefix,
            autorun: false,
          });
          await worker.waitUntilReady();

          expect(worker['getBlockTimeout'](Date.now() - 1)).toBeLessThanOrEqual(
            0,
          );
          await worker.close();
        });
      });

      describe('when blockUntil is greater than date now value', () => {
        it('returns delay value greater than minimumBlockTimeout', async () => {
          const worker = new Worker(queueName, NoopProc, {
            connection,
            prefix,
            autorun: false,
          });
          await worker.waitUntilReady();

          if (
            isRedisVersionLowerThan(
              getRedisVersion(worker),
              '7.0.8',
              getDatabaseType(worker),
            )
          ) {
            expect(worker['getBlockTimeout'](Date.now() + 100)).toBeGreaterThan(
              0.002,
            );
          } else {
            expect(worker['getBlockTimeout'](Date.now() + 100)).toBeGreaterThan(
              0.001,
            );
          }

          await worker.close();
        });
      });

      describe('when blockDelay exceeds the backend maximumBlockTimeout', () => {
        it("caps the block timeout at the backend's maximumBlockTimeout", async () => {
          const worker = new Worker(queueName, NoopProc, {
            connection,
            prefix,
            autorun: false,
          });
          await worker.waitUntilReady();

          // A blockUntil far enough in the future that blockDelay clearly
          // exceeds any backend ceiling (100 days). The result must be the
          // backend-delegated maximum: 10s on Redis, larger on Postgres.
          const farFuture = Date.now() + 100 * 24 * 60 * 60 * 1000;
          expect(worker['getBlockTimeout'](farFuture)).toBe(
            worker.maximumBlockTimeout,
          );

          await worker.close();
        });
      });
    });
  });

  describe('when reading maximumBlockTimeout', () => {
    it('delegates to the backend value', async () => {
      const worker = new Worker(queueName, NoopProc, {
        connection,
        prefix,
        autorun: false,
      });
      await worker.waitUntilReady();

      const backend = worker.getBackend();
      sandbox.stub(backend, 'maximumBlockTimeout').get(() => 1234);

      expect(worker.maximumBlockTimeout).toBe(1234);

      await worker.close();
    });

    it('falls back to the default (10s) when the backend does not specify one', async () => {
      const worker = new Worker(queueName, NoopProc, {
        connection,
        prefix,
        autorun: false,
      });
      await worker.waitUntilReady();

      const backend = worker.getBackend();
      sandbox.stub(backend, 'maximumBlockTimeout').get(() => undefined);

      expect(worker.maximumBlockTimeout).toBe(10);

      await worker.close();
    });
  });

  describe('when sharing connection', () => {
    it('should not fail', async () => {
      const queueName2 = `test-${randomUUID()}`;

      const connection = createTestConnection();

      const queue1 = new Queue(queueName2, { connection, prefix });

      let counter = 1;
      const maxJobs = 35;

      let processor;
      const processing = new Promise<void>((resolve, reject) => {
        processor = async (job: Job) => {
          try {
            expect(job.data.num).toBe(counter);
            expect(job.data.foo).toBe('bar');
            if (counter === maxJobs) {
              resolve();
            }
            counter++;
          } catch (err) {
            reject(err);
          }
        };
      });

      const worker = new Worker(queueName2, processor, { connection, prefix });
      await worker.waitUntilReady();

      for (let i = 1; i <= maxJobs; i++) {
        await queue1.add('test', { foo: 'bar', num: i });
      }

      await processing;
      expect(worker.isRunning()).toBe(true);

      await worker.close();
      await queue1.close();
      await connection.quit();
      await cleanupQueue(queueName2);
    });
  });

  describe('auto job removal', () => {
    const timerMethodsForFaking = ['Date', 'setTimeout', 'clearTimeout'];
    async function testRemoveOnFinish(
      opts: boolean | number | KeepJobs,
      expectedCount: number,
      fail?: boolean,
    ) {
      const clock = sinon.useFakeTimers({
        shouldClearNativeTimers: true,
        toFake: timerMethodsForFaking as any,
      });
      clock.reset();

      const worker = new Worker(
        queueName,
        async job => {
          await job.log('test log');
          if (fail) {
            throw new Error('job failed');
          }
        },
        { connection, prefix },
      );
      await worker.waitUntilReady();

      const datas = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14];

      // eslint-disable-next-line prefer-const
      let jobIds: string[];

      const processing = new Promise<void>(resolve => {
        worker.on(fail ? 'failed' : 'completed', async job => {
          clock.tick(1000);

          if (job.data == 14) {
            const counts = await queue.getJobCounts(
              fail ? 'failed' : 'completed',
            );

            if (fail) {
              expect(counts.failed).toBe(expectedCount);
            } else {
              expect(counts.completed).toBe(expectedCount);
            }

            await Promise.all(
              jobIds.map(async (jobId, index) => {
                const job = await queue.getJob(jobId);
                const logs = await queue.getJobLogs(jobId);
                if (index >= datas.length - expectedCount) {
                  expect(job).not.toBe(undefined);
                  expect(logs.logs).not.toHaveLength(0);
                } else {
                  expect(job).toBe(undefined);
                  expect(logs.logs).toHaveLength(0);
                }
              }),
            );
            resolve();
          }
        });
      });

      const jobOpts: JobsOptions = {};
      if (fail) {
        jobOpts.removeOnFail = opts;
      } else {
        jobOpts.removeOnComplete = opts;
      }

      jobIds = (
        await Promise.all(
          datas.map(async data => queue.add('test', data, jobOpts)),
        )
      ).map(job => job.id);

      await processing;
      clock.restore();
      await worker.close();
    }

    async function testWorkerRemoveOnFinish(
      opts: KeepJobs,
      expectedCount: number,
      fail?: boolean,
    ) {
      const clock = sinon.useFakeTimers({
        shouldClearNativeTimers: true,
        toFake: timerMethodsForFaking as any,
      });
      clock.reset();

      const worker = new Worker(
        queueName,
        async job => {
          await job.log('test log');
          if (fail) {
            throw new Error('job failed');
          }
        },
        {
          connection,
          prefix,
          ...(fail ? { removeOnFail: opts } : { removeOnComplete: opts }),
        },
      );
      await worker.waitUntilReady();

      const datas = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14];

      // eslint-disable-next-line prefer-const
      let jobIds: (string | undefined)[];

      const processing = new Promise<void>((resolve, reject) => {
        worker.on(fail ? 'failed' : 'completed', async job => {
          try {
            clock.tick(1000);

            if (job.data == 14) {
              const counts = await queue.getJobCounts(
                fail ? 'failed' : 'completed',
              );

              if (fail) {
                expect(counts.failed).toBe(expectedCount);
              } else {
                expect(counts.completed).toBe(expectedCount);
              }

              await Promise.all(
                jobIds.map(async (jobId, index) => {
                  const job = await queue.getJob(jobId);
                  const logs = await queue.getJobLogs(jobId);
                  if (index >= datas.length - expectedCount) {
                    expect(job).not.toBe(undefined);
                    expect(logs.logs).not.toHaveLength(0);
                  } else {
                    expect(job).toBe(undefined);
                    expect(logs.logs).toHaveLength(0);
                  }
                }),
              );
              resolve();
            }
          } catch (error) {
            console.log(error);
            reject(error);
          }
        });
      });

      jobIds = (
        await Promise.all(datas.map(async data => queue.add('test', data)))
      ).map(job => job.id);

      await processing;
      clock.restore();
      await worker.close();
    }

    it('should remove job after completed if removeOnComplete', async () => {
      const worker = new Worker(
        queueName,
        async (job, token) => {
          expect(token).toBeTypeOf('string');
          expect(job.data.foo).toBe('bar');
        },
        { connection, prefix },
      );
      await worker.waitUntilReady();

      const job = await queue.add(
        'test',
        { foo: 'bar' },
        { removeOnComplete: true },
      );
      expect(job.id).toBeTruthy();
      expect(job.data.foo).toEqual('bar');

      const completed = new Promise<void>((resolve, reject) => {
        worker.on('completed', async (job: Job) => {
          try {
            expect(job.finishedOn).toBeTypeOf('number');
            const gotJob = await queue.getJob(job.id!);
            expect(gotJob).toBe(undefined);
            const counts = await queue.getJobCounts('completed');
            expect(counts.completed).toBe(0);
            resolve();
          } catch (err) {
            reject(err);
          }
        });
      });

      await completed;

      await worker.close();
    });

    it('should remove a job after completed if the default job options specify removeOnComplete', async () => {
      const newQueue = new Queue(queueName, {
        connection,
        prefix,
        defaultJobOptions: {
          removeOnComplete: true,
        },
      });

      const worker = new Worker(
        queueName,
        async job => {
          expect(job.data.foo).toBe('bar');
        },
        { connection, prefix },
      );
      await worker.waitUntilReady();

      const job = await newQueue.add('test', { foo: 'bar' });
      expect(job.id).toBeTruthy();
      expect(job.data.foo).toEqual('bar');

      await new Promise<void>((resolve, reject) => {
        worker.on('completed', async job => {
          try {
            const gotJob = await newQueue.getJob(job.id);
            expect(gotJob).toBe(undefined);
            const counts = await newQueue.getJobCounts('completed');
            expect(counts.completed).toBe(0);
            resolve();
          } catch (err) {
            reject(err);
          }
        });
      });

      await worker.close();
      await newQueue.close();
    });

    it('should keep specified number of jobs after completed with removeOnComplete', async () => {
      const keepJobs = 3;
      await testRemoveOnFinish(keepJobs, keepJobs);
    });

    it('should keep of jobs newer than specified after completed with removeOnComplete', async () => {
      const age = 7;
      await testRemoveOnFinish({ age }, age);
    });

    it('should keep of jobs newer than specified and up to a count completed with removeOnComplete', async () => {
      const age = 7;
      const count = 5;
      await testRemoveOnFinish({ age, count }, count);
    });

    it('should keep of jobs newer than specified and up to a count fail with removeOnFail', async () => {
      const age = 7;
      const count = 5;
      await testRemoveOnFinish({ age, count }, count, true);
    });

    it('should keep specified number of jobs after completed with default job options removeOnComplete', async () => {
      const keepJobs = 3;

      const newQueue = new Queue(queueName, {
        connection,
        prefix,
        defaultJobOptions: {
          removeOnComplete: keepJobs,
        },
      });

      const worker = new Worker(
        queueName,
        async job => {
          await job.log('test log');
        },
        { connection, prefix },
      );
      await worker.waitUntilReady();

      const datas = [0, 1, 2, 3, 4, 5, 6, 7, 8];

      const jobIds = await Promise.all(
        datas.map(async data => (await newQueue.add('test', data)).id),
      );

      return new Promise((resolve, reject) => {
        worker.on('completed', async job => {
          if (job.data == 8) {
            try {
              const counts = await newQueue.getJobCounts('completed');
              expect(counts.completed).toBe(keepJobs);

              await Promise.all(
                jobIds.map(async (jobId, index) => {
                  const job = await newQueue.getJob(jobId);
                  if (index >= datas.length - keepJobs) {
                    expect(job).not.toBe(undefined);
                  } else {
                    expect(job).toBe(undefined);
                  }
                }),
              );
            } catch (err) {
              reject(err);
            } finally {
              await worker.close();
              await newQueue.close();
            }
            resolve();
          }
        });
      });
    });

    it('should remove job after failed if removeOnFail', async () => {
      await testRemoveOnFinish(true, 0, true);
    });

    it('should remove a job after fail if the default job options specify removeOnFail', async () => {
      const worker = new Worker(
        queueName,
        async job => {
          expect(job.data.foo).toBe('bar');
          throw Error('error');
        },
        { connection, prefix },
      );
      await worker.waitUntilReady();

      const newQueue = new Queue(queueName, {
        connection,
        prefix,
        defaultJobOptions: {
          removeOnFail: true,
        },
      });

      const job = await newQueue.add('test', { foo: 'bar' });
      expect(job.id).toBeTruthy();
      expect(job.data.foo).toEqual('bar');

      await new Promise<void>(resolve => {
        worker.on('failed', async job => {
          const currentJob = await newQueue.getJob(job.id);
          expect(currentJob).toBe(undefined);
          const counts = await newQueue.getJobCounts('completed');
          expect(counts.completed).toBe(0);
          resolve();
        });
      });

      await worker.close();
      await newQueue.close();
    });

    it('should keep specified number of jobs after completed with removeOnFail', async () => {
      const keepJobs = 3;
      await testRemoveOnFinish(keepJobs, keepJobs, true);
    });

    it('should keep specified number of jobs after completed with global removeOnFail', async () => {
      const keepJobs = 3;

      const worker = new Worker(
        queueName,
        async job => {
          expect(job.data.foo).toBe('bar');
          throw Error('error');
        },
        { connection, prefix },
      );
      await worker.waitUntilReady();

      const newQueue = new Queue(queueName, {
        connection,
        prefix,
        defaultJobOptions: {
          removeOnFail: keepJobs,
        },
      });

      const datas = [0, 1, 2, 3, 4, 5, 6, 7, 8];

      const jobIds = await Promise.all(
        datas.map(async data => (await newQueue.add('test', data)).id),
      );

      return new Promise<void>((resolve, reject) => {
        worker.on('failed', async job => {
          if (job.data == 8) {
            try {
              const counts = await newQueue.getJobCounts('failed');
              expect(counts.failed).toBe(keepJobs);

              await Promise.all(
                jobIds.map(async (jobId, index) => {
                  const job = await newQueue.getJob(jobId);
                  if (index >= datas.length - keepJobs) {
                    expect(job).not.toBe(undefined);
                  } else {
                    expect(job).toBe(undefined);
                  }
                }),
              );
            } catch (err) {
              reject(err);
            }
            await worker.close();
            await newQueue.close();
            resolve();
          }
        });
      });
    });

    describe('when worker has removeOnFinish options', () => {
      it('should keep of jobs newer than specified after completed with removeOnComplete', async () => {
        const age = 7;
        await testWorkerRemoveOnFinish({ age }, age);
      });

      it('should keep of jobs newer than specified and up to a count completed with removeOnComplete', async () => {
        const age = 7;
        const count = 5;
        await testWorkerRemoveOnFinish({ age, count }, count);
      });

      it('should keep jobs with age 10 and limit 2 with removeOnComplete', async () => {
        const age = 10;
        const limit = 2;
        await testWorkerRemoveOnFinish({ age, limit }, age);
      });

      it('should keep of jobs newer than specified and up to a count fail with removeOnFail', async () => {
        const age = 7;
        const count = 5;
        await testWorkerRemoveOnFinish({ age, count }, count, true);
      });

      it('should remove all jobs when count is 0 with removeOnFail', async () => {
        const count = 0;
        await testWorkerRemoveOnFinish({ count }, count, true);
      });

      // NOTE: 'should not leave orphaned job data when limit is less than
      // removable jobs' is Redis-specific (it inspects orphaned job hashes vs
      // the completed sorted set via `exists`/`zscore`) and lives in
      // `worker.redis.test.ts`.
    });
  });

  describe('when adding delayed job after standard one when worker is drained', () => {
    it('pick standard job without delay', async () => {
      // TODO: Move timeout to test options: { timeout: 6000 }

      const worker = new Worker(
        queueName,
        async job => {
          await delay(1000);
        },
        {
          connection,
          prefix,
        },
      );
      await worker.waitUntilReady();

      let bulkStart = 0;
      let bulkCompletedCount = 0;

      const completing2 = new Promise<void>(resolve => {
        worker.on('completed', job => {
          if (!bulkStart) {
            return;
          }

          bulkCompletedCount += 1;

          if (bulkCompletedCount === 2) {
            const timeDiff = Date.now() - bulkStart;
            expect(timeDiff).toBeGreaterThanOrEqual(4000);
            expect(timeDiff).toBeLessThan(4500);
            expect(job.delay).toBe(0);
            resolve();
          }
        });
      });

      // after this event, worker should be drained
      const completing = new Promise<void>(resolve => {
        worker.once('completed', async () => {
          bulkStart = Date.now();

          await queue.addBulk([
            { name: 'test1', data: { idx: 0, foo: 'bar' } },
            {
              name: 'test2',
              data: { idx: 1, foo: 'baz' },
              opts: { delay: 3000 },
            },
          ]);

          resolve();
        });
      });

      await Job.create(queue, 'test1', { foo: 'bar' });

      await completing;
      await completing2;
      await worker.close();
    });
  });

  describe('when prioritized jobs are added', () => {
    it('should process jobs by priority', async () => {
      let processor;

      // for the current strategy this number should not exceed 8 (2^2*2)
      // this is done to maintain a deterministic output.
      const numJobsPerPriority = 6;

      const jobs: {
        name: string;
        data: { p: number };
        opts: { priority: number };
      }[] = [];
      for (let i = 0; i < numJobsPerPriority; i++) {
        jobs.push({ name: 'test', data: { p: 2 }, opts: { priority: 2 } }); // normal priority
        jobs.push({ name: 'test', data: { p: 3 }, opts: { priority: 3 } }); // medium priority
        jobs.push({ name: 'test', data: { p: 1 }, opts: { priority: 1 } }); // high priority
      }

      let currentPriority = 1;
      let counter = 0;
      let total = 0;

      const processing = new Promise<void>((resolve, reject) => {
        processor = async (job: Job) => {
          try {
            expect(job.id).toBeTruthy();
            expect(job.data.p).toEqual(currentPriority);
          } catch (err) {
            reject(err);
          }

          total++;
          if (++counter === numJobsPerPriority) {
            currentPriority++;
            counter = 0;

            if (currentPriority === 4 && total === numJobsPerPriority * 3) {
              resolve();
            }
          }
        };
      });

      const worker = new Worker(queueName, processor, { connection, prefix });
      await worker.waitUntilReady();

      // wait for all jobs to enter the queue and then start processing
      await queue.addBulk(jobs);

      await processing;

      await worker.close();
    });

    // NOTE: 'when priority counter is having a high number' is Redis-specific
    // (it pre-seeds the `:pc` counter past the 32-bit boundary via `incrby`) and
    // lives in `worker.redis.test.ts`.

    describe('when jobs are added with the maximum allowed priority value', () => {
      it('should process jobs with the same priority in FIFO order', async () => {
        const maxPriority = 2097151;
        const numJobs = 5;

        const jobs = Array.from(Array(numJobs).keys()).map(index => ({
          name: 'test',
          data: { order: index },
          opts: { priority: maxPriority },
        }));
        await queue.addBulk(jobs);

        const processedOrder: number[] = [];
        let processor;
        const processing = new Promise<void>((resolve, reject) => {
          processor = async (job: Job) => {
            try {
              processedOrder.push(job.data.order);
              if (processedOrder.length === numJobs) {
                resolve();
              }
            } catch (err) {
              reject(err);
            }
          };
        });

        const worker = new Worker(queueName, processor, { connection, prefix });
        await worker.waitUntilReady();

        await processing;

        expect(processedOrder).toEqual([0, 1, 2, 3, 4]);

        await worker.close();
      });

      it('should reject jobs above the maximum allowed priority value', async () => {
        await expect(
          queue.add('test', { order: 0 }, { priority: 2097152 }),
        ).rejects.toThrow('Priority should be between 0 and 2097151');

        await expect(
          queue.addBulk([
            {
              name: 'test',
              data: { order: 0 },
              opts: { priority: 2097152 },
            },
          ]),
        ).rejects.toThrow('Priority should be between 0 and 2097151');
      });
    });

    describe('while processing last active job', () => {
      it('should process prioritized job whithout delay', async () => {
        // TODO: Move timeout to test options: { timeout: 1000 }
        await queue.add('test1', { p: 2 }, { priority: 2 });
        let counter = 0;
        let processor;
        const processing = new Promise<void>((resolve, reject) => {
          processor = async (job: Job) => {
            try {
              if (job.name == 'test1') {
                await queue.add('test', { p: 2 }, { priority: 2 });
              }

              expect(job.id).toBeTruthy();
              expect(job.data.p).toEqual(2);
            } catch (err) {
              reject(err);
            }

            if (++counter === 2) {
              resolve();
            }
          };
        });

        const worker = new Worker(queueName, processor, { connection, prefix });
        await worker.waitUntilReady();

        await processing;

        await worker.close();
      });
    });

    describe('when using custom jobId', () => {
      it('should process prioritized jobs', async () => {
        // TODO: Move timeout to test options: { timeout: 1000 }
        await queue.add('test1', { p: 2 }, { priority: 2, jobId: 'custom1' });
        await queue.add('test2', { p: 3 }, { priority: 3, jobId: 'custom2' });
        let counter = 0;
        let processor;
        const processing = new Promise<void>((resolve, reject) => {
          processor = async () => {
            await delay(25);
            if (++counter === 2) {
              resolve();
            }
          };
        });

        const worker = new Worker(queueName, processor, {
          connection,
          autorun: false,
          prefix,
        });
        await worker.waitUntilReady();

        worker.run();
        await processing;

        await worker.close();
      });
    });
  });

  // These assert on the ioredis connection lifecycle (`'ready'`/`'end'` events
  // and `status`) of a raw connection shared between workers/queues — a
  // Redis-client concern with no backend-agnostic meaning. Other backends own
  // their own connection pool, and the PostgreSQL test harness uses a no-op
  // client that never emits these events, so skip them under Postgres.
  const describeSharedConnection =
    process.env.BULLMQ_TEST_BACKEND === 'postgres' ? describe.skip : describe;
  describeSharedConnection(
    'when sharing a redis connection between workers',
    () => {
      it('should not close the connection', async () => {
        const connection = createTestConnection();

        return new Promise<void>((resolve, reject) => {
          connection.on('ready', async () => {
            const worker1 = new Worker('test-shared', null, {
              connection,
              prefix,
            });
            await worker1.waitUntilReady();
            const worker2 = new Worker('test-shared', null, {
              connection,
              prefix,
            });
            await worker2.waitUntilReady();

            try {
              // There is no point into checking the ready status after closing
              // since ioredis will not update it anyway:
              // https://github.com/luin/ioredis/issues/614
              expect(connection.status).toBe('ready');
              await worker1.close();
              await worker2.close();
              await connection.quit();

              connection.on('end', () => {
                resolve();
              });
            } catch (err) {
              reject(err);
            }
          });
        });
      });

      describe('when connection is passed into a queue', () => {
        it('should not close the connection', async () => {
          const connection = createTestConnection();
          const queueName2 = `test-shared-${randomUUID()}`;

          const queue2 = new Queue(queueName2, {
            defaultJobOptions: { removeOnComplete: true },
            connection,
            prefix,
          });

          await new Promise<void>((resolve, reject) => {
            connection.on('ready', async () => {
              const worker1 = new Worker(queueName2, null, {
                connection,
                prefix,
              });
              await worker1.waitUntilReady();
              const worker2 = new Worker(queueName2, null, {
                connection,
                prefix,
              });
              await worker2.waitUntilReady();

              try {
                // There is no point into checking the ready status after closing
                // since ioredis will not update it anyway:
                // https://github.com/luin/ioredis/issues/614
                expect(connection.status).toBe('ready');
                await worker1.close();
                await worker2.close();
                await connection.quit();

                connection.on('end', () => {
                  resolve();
                });
              } catch (err) {
                reject(err);
              }
            });
          });

          await queue2.close();
          await cleanupQueue(queueName2);
        });
      });
    },
  );

  describe('when autorun option is provided as false', () => {
    it('processes several jobs serially using process option as false', async () => {
      let counter = 1;
      const maxJobs = 10;

      let processor;
      const processing = new Promise<void>((resolve, reject) => {
        processor = async (job: Job) => {
          try {
            await delay(20);
            expect(job.data.num).toBe(counter);
            expect(job.data.foo).toBe('bar');
            if (counter === maxJobs) {
              resolve();
            }
            counter++;
          } catch (err) {
            reject(err);
          }
        };
      });

      const worker = new Worker(queueName, processor, {
        autorun: false,
        connection,
        prefix,
      });
      await worker.waitUntilReady();

      for (let i = 1; i <= maxJobs; i++) {
        await queue.add('test', { foo: 'bar', num: i });
      }

      worker.run();

      await processing;
      await worker.close();
    });

    describe('when process function is not defined', () => {
      it('throws error', async () => {
        const worker = new Worker(queueName, undefined, {
          autorun: false,
          connection,
          prefix,
        });
        await worker.waitUntilReady();

        await expect(worker.run()).rejects.toThrow(
          'No process function is defined.',
        );

        await worker.close();
      });
    });

    describe('when run method is called when worker is running', () => {
      it('throws error', async () => {
        const maxJobs = 10;
        const worker = new Worker(queueName, NoopProc, {
          autorun: false,
          connection,
          prefix,
        });
        await worker.waitUntilReady();
        worker.run();

        for (let i = 1; i <= maxJobs; i++) {
          await queue.add('test', { foo: 'bar', num: i });
        }

        await expect(worker.run()).rejects.toThrow(
          'Worker is already running.',
        );

        await worker.close();
      });
    });
  });

  describe('when queue is paused and retry a job', () => {
    it('moves job to wait', async () => {
      const worker = new Worker(
        queueName,
        async () => {
          await delay(100);
        },
        { connection, prefix },
      );
      await worker.waitUntilReady();

      const completing = new Promise<void>((resolve, reject) => {
        worker.once('completed', async job => {
          try {
            expect(job).toBeTruthy();
            expect(job.data.foo).toEqual('bar');
          } catch (err) {
            reject(err);
          }
          resolve();
        });
      });

      const job = await queue.add('test', { foo: 'bar' });
      expect(job.id).toBeTruthy();
      expect(job.data.foo).toEqual('bar');

      await completing;
      await queue.pause();
      await job.retry('completed');

      const waitingJobsCount = await queue.getWaitingCount();
      expect(waitingJobsCount).toBe(1);

      await worker.close();
    });
  });

  it('retry a job that fails using job retry method', async () => {
    let called = 0;
    let failedOnce = false;
    const notEvenErr = new Error('Not even!');

    const worker = new Worker(
      queueName,
      async () => {
        called++;
        if (called % 2 !== 0) {
          throw notEvenErr;
        }
      },
      { connection, prefix },
    );
    await worker.waitUntilReady();

    const job = await queue.add('test', { foo: 'bar' });
    expect(job.id).toBeTruthy();
    expect(job.data.foo).toEqual('bar');

    worker.once('failed', async (job, err) => {
      expect(job).toBeTruthy();
      expect(job.data.foo).toEqual('bar');
      expect(err).toEqual(notEvenErr);
      failedOnce = true;

      await worker.pause(true);

      await job.retry();

      expect(job.failedReason).toBeNull();
      expect(job.processedOn).toBeNull();
      expect(job.finishedOn).toBeNull();
      expect(job.returnvalue).toBeNull();

      const updatedJob = await queue.getJob(job.id);
      expect(updatedJob.failedReason).toBeUndefined();
      expect(updatedJob.processedOn).toBeUndefined();
      expect(updatedJob.finishedOn).toBeUndefined();
      expect(updatedJob.returnvalue).toBeNull();

      await worker.resume();
    });

    await new Promise<void>(resolve => {
      worker.once('completed', () => {
        expect(failedOnce).toEqual(true);
        resolve();
      });
    });

    await worker.close();
  });

  // NOTE: 'keeps locks for all the jobs that are processed concurrently',
  // 'emits error if lock is lost' and 'emits error if lock is "stolen"' are
  // Redis-specific (they inspect/steal raw `:lock` keys and rely on Redis lock
  // TTL semantics) and live in `worker.redis.test.ts`.

  it('emits error and continues running when _getNextJob fails', async () => {
    // TODO: Move timeout to test options: { timeout: 10000 }

    const worker = new Worker(
      queueName,
      async () => {
        return { result: 'success' };
      },
      {
        autorun: false,
        connection,
        prefix,
      },
    );
    await worker.waitUntilReady();

    // Add a job to the queue to ensure there's something to process
    await queue.add('test', { data: 'test' });

    let errorEmitted = false;
    let jobProcessed = false;

    // Listen for error events
    const errorPromise = new Promise<void>(resolve => {
      worker.once('error', error => {
        errorEmitted = true;
        expect(error).toBeInstanceOf(Error);
        resolve();
      });
    });

    // Listen for completed events to verify worker continues processing
    const completedPromise = new Promise<void>(resolve => {
      worker.once('completed', () => {
        jobProcessed = true;
        resolve();
      });
    });

    // Stub the _getNextJob method to throw an error on first call, then restore
    let callCount = 0;
    const originalGetNextJob = (worker as any)._getNextJob;
    const stub = sandbox
      .stub(worker as any, '_getNextJob')
      .callsFake(async function (...args) {
        callCount++;
        if (callCount === 1) {
          // First call throws an error
          throw new Error('Simulated _getNextJob failure');
        } else {
          // Subsequent calls work normally
          return originalGetNextJob.apply(this, args);
        }
      });

    worker.run();

    await errorPromise;
    await completedPromise;

    // Verify that error was emitted and worker continued running
    expect(errorEmitted).toBe(true);
    expect(jobProcessed).toBe(true);
    expect(worker.isRunning()).toBe(true);

    // Clean up
    stub.restore();
    await worker.close();
  });

  it('continues processing after a worker has stalled', async () => {
    let first = true;
    // TODO: Move timeout to test options: { timeout: 10000 }

    const worker = new Worker(
      queueName,
      async () => {
        if (first) {
          first = false;
          return delay(2000);
        }
      },
      {
        connection,
        prefix,
        lockDuration: 1000,
        lockRenewTime: 3000, // The lock will not be updated
        stalledInterval: 100,
      },
    );
    await worker.waitUntilReady();

    await queue.add('test', { bar: 'baz' });

    const completed = new Promise(resolve => {
      worker.on('completed', resolve);
    });

    await completed;

    await worker.close();
  });

  it('max stalled count cannot be less than zero', async () => {
    // TODO: Move timeout to test options: { timeout: 4000 }
    expect(
      () =>
        new Worker(queueName, NoopProc, {
          connection,
          prefix,
          maxStalledCount: -1,
        }),
    ).toThrow('maxStalledCount must be greater or equal than 0');
  });

  it('max started attempts cannot be less than zero', async () => {
    // TODO: Move timeout to test options: { timeout: 4000 }
    expect(
      () =>
        new Worker(queueName, NoopProc, {
          connection,
          prefix,
          maxStartedAttempts: -1,
        }),
    ).toThrow('maxStartedAttempts must be greater or equal than 0');
  });

  it('stalled interval cannot be zero', async () => {
    // TODO: Move timeout to test options: { timeout: 4000 }
    expect(
      () =>
        new Worker(queueName, NoopProc, {
          connection,
          prefix,
          stalledInterval: 0,
        }),
    ).toThrow('stalledInterval must be greater than 0');
  });

  it('drain delay cannot be zero', async () => {
    // TODO: Move timeout to test options: { timeout: 4000 }
    expect(
      () =>
        new Worker(queueName, NoopProc, {
          connection,
          prefix,
          drainDelay: 0,
        }),
    ).toThrow('drainDelay must be greater than 0');
  });

  it('lock extender continues to run until all active jobs are completed when closing a worker', async () => {
    // TODO: Move timeout to test options: { timeout: 4000 }
    let worker: Worker;

    const startProcessing = new Promise<void>(resolve => {
      worker = new Worker(
        queueName,
        async () => {
          resolve();
          return delay(2000);
        },
        {
          connection,
          lockDuration: 1000,
          lockRenewTime: 500,
          stalledInterval: 1000,
          prefix,
        },
      );
    });

    await queue.add('test', { bar: 'baz' });

    const completed = new Promise((resolve, reject) => {
      worker.on('completed', resolve);
      worker.on('failed', reject);
    });

    await startProcessing;
    await worker.close();

    await completed;
  });

  describe('Concurrency process', () => {
    it('should thrown an exception if I specify a concurrency of 0', () => {
      try {
        const worker = new Worker(queueName, NoopProc, {
          connection,
          prefix,
          concurrency: 0,
        });
        throw new Error('Should have thrown an exception');
      } catch (err) {
        expect(err.message).toBe(
          'concurrency must be a finite number greater than 0',
        );
      }
    });

    it('should thrown an exception if I specify a NaN concurrency', () => {
      try {
        const worker = new Worker(queueName, NoopProc, {
          connection,
          prefix,
          concurrency: NaN,
        });
        throw new Error('Should have thrown an exception');
      } catch (err) {
        expect(err.message).toBe(
          'concurrency must be a finite number greater than 0',
        );
      }
    });

    it('should run job in sequence if I specify a concurrency of 1', async () => {
      let processing = false;

      const worker = new Worker(
        queueName,
        async () => {
          expect(processing).toBe(false);
          processing = true;
          await delay(50);
          processing = false;
        },
        {
          autorun: false,
          connection,
          prefix,
          concurrency: 1,
        },
      );
      await worker.waitUntilReady();

      await queue.add('test', {});
      await queue.add('test', {});

      worker.run();
      await new Promise(resolve => {
        worker.on('completed', after(2, resolve));
      });

      await worker.close();
    });

    //This job use delay to check that at any time we have 4 process in parallel.
    //Due to time to get new jobs and call process, false negative can appear.
    it('should process job respecting the concurrency set', async () => {
      // TODO: Move timeout to test options: { timeout: 10000 }
      let nbProcessing = 0;
      let pendingMessageToProcess = 8;
      let wait = 10;
      let worker;

      const processing = new Promise<void>((resolve, reject) => {
        worker = new Worker(
          queueName,
          async () => {
            try {
              nbProcessing++;
              expect(nbProcessing).toBeLessThan(5);

              wait += 100;

              await delay(wait);

              // We should not have 4 more in parallel.
              // At the end, due to empty list, no new job will process, so nbProcessing will decrease.
              expect(nbProcessing).toEqual(
                Math.min(pendingMessageToProcess, 4),
              );
              pendingMessageToProcess--;
              nbProcessing--;

              if (pendingMessageToProcess == 0) {
                resolve();
              }
            } catch (err) {
              reject(err);
            }
          },
          {
            connection,
            prefix,
            concurrency: 4,
          },
        );
      });
      await worker.waitUntilReady();

      await Promise.all(times(8, () => queue.add('test', {})));

      await processing;
      await worker.close();
    });

    describe('when changing concurrency', () => {
      describe('when increasing value', () => {
        it('should process job respecting the current concurrency set', async () => {
          // TODO: Move timeout to test options: { timeout: 10000 }
          let nbProcessing = 0;
          let pendingMessageToProcess = 16;
          let wait = 10;

          const worker = new Worker(
            queueName,
            async job => {
              try {
                nbProcessing++;
                if (job.data.index < 8) {
                  expect(nbProcessing).toBeLessThan(5);
                } else {
                  expect(nbProcessing).toBeLessThan(9);
                }

                wait += 100;

                await delay(wait);
                if (job.data.index < 8) {
                  expect(nbProcessing).toEqual(
                    Math.min(pendingMessageToProcess, 4),
                  );
                } else {
                  expect(nbProcessing).toEqual(
                    Math.min(pendingMessageToProcess, 8),
                  );
                }
                pendingMessageToProcess--;
                nbProcessing--;
              } catch (err) {
                console.error(err);
              }
            },
            {
              connection,
              prefix,
              concurrency: 4,
            },
          );
          await worker.waitUntilReady();

          const waiting1 = new Promise((resolve, reject) => {
            worker.on('completed', after(8, resolve));
            worker.on('failed', reject);
          });

          const jobs = Array.from(Array(16).keys()).map(index => ({
            name: 'test',
            data: { index },
          }));

          await queue.addBulk(jobs);

          await waiting1;

          worker.concurrency = 8;

          const waiting2 = new Promise((resolve, reject) => {
            worker.on('completed', after(8, resolve));
            worker.on('failed', reject);
          });

          await waiting2;

          await worker.close();
        });
      });

      describe('when decreasing value', () => {
        it('should process job respecting the current concurrency set', async () => {
          // TODO: Move timeout to test options: { timeout: 10000 }
          let nbProcessing = 0;
          let pendingMessageToProcess = 20;
          let wait = 100;

          const worker = new Worker(
            queueName,
            async () => {
              nbProcessing++;
              if (pendingMessageToProcess > 7) {
                expect(nbProcessing).toBeLessThan(5);
              } else {
                expect(nbProcessing).toBeLessThan(3);
              }
              wait += 50;

              await delay(wait);
              if (pendingMessageToProcess > 11) {
                expect(nbProcessing).toEqual(
                  Math.min(pendingMessageToProcess, 4),
                );
              } else if (pendingMessageToProcess == 11) {
                expect(nbProcessing).toEqual(3);
              } else {
                expect(nbProcessing).toBeLessThanOrEqual(
                  Math.min(pendingMessageToProcess, 2),
                );
              }
              pendingMessageToProcess--;
              nbProcessing--;
            },
            {
              connection,
              prefix,
              concurrency: 4,
            },
          );
          await worker.waitUntilReady();

          let processed = 0;
          const waiting1 = new Promise<void>((resolve, reject) => {
            worker.on('completed', async () => {
              processed++;
              if (processed === 8) {
                worker.concurrency = 2;
              }

              if (processed === 20) {
                resolve();
              }
            });
            worker.on('failed', reject);
          });

          const jobs = Array.from(Array(20).keys()).map(index => ({
            name: 'test',
            data: { index },
          }));

          await queue.addBulk(jobs);

          await waiting1;

          await worker.close();
        });
      });
    });

    describe('when pausing', () => {
      it('should wait for all concurrent processing', async () => {
        let i = 0;
        let nbJobFinish = 0;
        // eslint-disable-next-line prefer-const
        let runExecution: Promise<void>;

        const worker = new Worker(
          queueName,
          async () => {
            // 100 - i*20 is to force to finish job n°4 before lower jobs that will wait longer
            await delay(100 - i * 10);
            nbJobFinish++;

            // We simulate an error of one processing job.
            if (i % 7 === 0) {
              throw new Error();
            }
          },
          {
            autorun: false,
            connection,
            prefix,
            concurrency: 4,
          },
        );
        await worker.waitUntilReady();

        worker.on('active', async () => {
          if (++i === 4) {
            // Pause when all 4 works are processing
            await worker.pause();
            // Wait for all the active jobs to finalize.
            expect(nbJobFinish).toBeGreaterThanOrEqual(3);
            expect(nbJobFinish).toBeLessThanOrEqual(4);
          }
        });

        const waiting = new Promise((resolve, reject) => {
          const cb = after(8, resolve);
          worker.on('completed', cb);
          worker.on('failed', cb);
          worker.on('error', reject);
        });
        const pausing = new Promise<void>(resolve => {
          worker.on('paused', async () => {
            // test that loop is stopped and worker is actually paused
            await runExecution;
            expect(worker.isRunning()).toBe(false);

            await worker.resume();
            resolve();
          });
        });
        await Promise.all(times(8, () => queue.add('test', {})));

        runExecution = worker.run();

        await pausing;

        await waiting;

        await worker.close();
      });

      it('should not keep active jobs', async () => {
        const worker = new Worker(
          queueName,
          async () => {
            await delay(100);
          },
          {
            autorun: false,
            connection,
            prefix,
            concurrency: 4,
          },
        );
        await worker.waitUntilReady();

        worker.once('completed', async () => {
          await worker.pause();
        });

        const pausing = new Promise<void>((resolve, reject) => {
          worker.on('paused', async () => {
            try {
              expect(worker.isRunning()).toBe(false);
              const activeJobCount = await queue.getActiveCount();
              expect(activeJobCount).toBe(0);
              resolve();
            } catch (error) {
              reject(error);
            }
          });
        });
        await Promise.all(times(8, () => queue.add('test', {})));

        worker.run();

        await pausing;

        await worker.close();
      });

      it('should resume processing after pause with doNotWaitActive', async () => {
        const worker = new Worker(
          queueName,
          async () => {
            await delay(50);
          },
          {
            connection,
            prefix,
          },
        );
        await worker.waitUntilReady();

        const firstCompleted = new Promise<void>(resolve => {
          worker.once('completed', () => resolve());
        });

        // Process first job to ensure the worker is running
        await queue.add('test', { seq: 'first' });

        await firstCompleted;

        expect(worker.isRunning()).toBe(true);
        expect(worker.isPaused()).toBe(false);

        // Pause with doNotWaitActive=true (main loop keeps running)
        await worker.pause(true);
        expect(worker.isPaused()).toBe(true);
        expect(worker.isRunning()).toBe(true);

        // Resume should work even though isRunning() is true
        await worker.resume();
        expect(worker.isPaused()).toBe(false);
        expect(worker.isRunning()).toBe(true);

        const secondCompleted = new Promise<void>(resolve => {
          worker.once('completed', job => {
            expect(job.data.seq).toBe('after-resume');
            resolve();
          });
        });

        // Verify the worker actually processes new jobs after resume
        await queue.add('test', { seq: 'after-resume' });

        await secondCompleted;

        await worker.close();
      });
    });
  });

  describe('Retries and backoffs', () => {
    it("updates job's delay property if it fails and backoff is set", async () => {
      const worker = new Worker(
        queueName,
        async () => {
          throw new Error('error');
        },
        { connection, prefix },
      );
      await worker.waitUntilReady();

      await queue.add('test', { bar: 'baz' }, { attempts: 3, backoff: 300 });

      const failed = new Promise<void>((resolve, reject) => {
        worker.once('failed', async job => {
          try {
            expect(job?.delay).toEqual(300);
            const gotJob = await queue.getJob(job.id!);
            expect(gotJob!.delay).toEqual(300);
            resolve();
          } catch (err) {
            reject(err);
          }
        });
      });

      await failed;

      await worker.close();
    });

    // NOTE: 'deletes token after moving jobs to delayed' is Redis-specific (it
    // reads the raw `:lock` key via `client.get`) and lives in
    // `worker.redis.test.ts`.

    describe('when backoff type is exponential', () => {
      it("updates job's delay property if it fails and backoff is set", async () => {
        const worker = new Worker(
          queueName,
          async () => {
            throw new Error('error');
          },
          { autorun: false, connection, prefix },
        );
        await worker.waitUntilReady();

        await queue.add(
          'test',
          { bar: 'baz' },
          {
            attempts: 3,
            backoff: {
              type: 'exponential',
              delay: 200,
            },
          },
        );

        const failed = new Promise<void>((resolve, reject) => {
          worker.on('failed', async job => {
            try {
              const attemptsMade = job?.attemptsMade;
              if (attemptsMade! > 2) {
                expect(job!.delay).toEqual(0);
                const gotJob = await queue.getJob(job.id!);
                expect(gotJob!.delay).toEqual(0);
                resolve();
              } else {
                expect(job?.delay).toBeGreaterThanOrEqual(
                  2 ** (attemptsMade! - 1) * 200,
                );
              }
            } catch (err) {
              reject(err);
            }
          });
        });

        worker.run();
        await failed;

        await worker.close();
      });

      describe('when jitter option is provided', () => {
        it("updates job's delay property between 0 and max exponential backoff value", async () => {
          const worker = new Worker(
            queueName,
            async () => {
              throw new Error('error');
            },
            { autorun: false, connection, prefix },
          );
          await worker.waitUntilReady();

          await queue.add(
            'test',
            { bar: 'baz' },
            {
              attempts: 3,
              backoff: {
                type: 'exponential',
                delay: 200,
                jitter: 1,
              },
            },
          );

          const failed = new Promise<void>((resolve, reject) => {
            worker.on('failed', async job => {
              try {
                const attemptsMade = job?.attemptsMade;
                if (attemptsMade! > 2) {
                  expect(job!.delay).toEqual(0);
                  resolve();
                } else {
                  expect(job?.delay).toBeLessThanOrEqual(
                    2 ** (attemptsMade! - 1) * 200,
                  );
                }
              } catch (err) {
                reject(err);
              }
            });
          });

          worker.run();
          await failed;

          await worker.close();
        });

        describe('when jitter is provided with lower value than 1', () => {
          it("updates job's delay property only applying jitter in a fixed percentage", async () => {
            const worker = new Worker(
              queueName,
              async () => {
                throw new Error('error');
              },
              { autorun: false, connection, prefix },
            );
            await worker.waitUntilReady();

            await queue.add(
              'test',
              { bar: 'baz' },
              {
                attempts: 3,
                backoff: {
                  type: 'exponential',
                  delay: 200,
                  jitter: 0.5,
                },
              },
            );

            const failed = new Promise<void>((resolve, reject) => {
              worker.on('failed', async job => {
                try {
                  const attemptsMade = job?.attemptsMade;
                  if (attemptsMade! > 2) {
                    expect(job!.delay).toEqual(0);
                    resolve();
                  } else {
                    expect(job?.delay).toBeLessThanOrEqual(
                      2 ** (attemptsMade! - 1) * 200,
                    );
                    expect(job?.delay).toBeGreaterThanOrEqual(
                      2 ** (attemptsMade! - 1) * 200 * 0.5,
                    );
                  }
                } catch (err) {
                  reject(err);
                }
              });
            });

            worker.run();
            await failed;

            await worker.close();
          });
        });
      });
    });

    describe('when backoff type is fixed', () => {
      it("updates job's delay property and respects fixed delay value", async () => {
        const worker = new Worker(
          queueName,
          async () => {
            throw new Error('error');
          },
          { connection, prefix },
        );
        await worker.waitUntilReady();

        await queue.add(
          'test',
          { bar: 'baz' },
          {
            attempts: 4,
            backoff: {
              type: 'fixed',
              delay: 750,
            },
          },
        );

        const now = Date.now();
        const failed = new Promise<void>((resolve, reject) => {
          worker.on('failed', async job => {
            try {
              const attemptsMade = job?.attemptsMade;
              if (attemptsMade! > 3) {
                expect(job!.delay).toEqual(0);
                const gotJob = await queue.getJob(job.id!);
                expect(gotJob!.delay).toEqual(0);
                const timeDiff = Date.now() - now;
                expect(timeDiff).toBeGreaterThanOrEqual(2250);
                expect(timeDiff).toBeLessThanOrEqual(2750);
                resolve();
              }
            } catch (err) {
              reject(err);
            }
          });
        });

        await failed;

        await worker.close();
      });

      describe('when jitter option is provided', () => {
        it("updates job's delay property between 0 and max fixed backoff value", async () => {
          const worker = new Worker(
            queueName,
            async () => {
              throw new Error('error');
            },
            { autorun: false, connection, prefix },
          );
          await worker.waitUntilReady();

          await queue.add(
            'test',
            { bar: 'baz' },
            {
              attempts: 3,
              backoff: {
                type: 'fixed',
                delay: 750,
                jitter: 1,
              },
            },
          );

          const failed = new Promise<void>((resolve, reject) => {
            worker.on('failed', async job => {
              try {
                const attemptsMade = job?.attemptsMade;
                if (attemptsMade! > 2) {
                  expect(job!.delay).toEqual(0);
                  resolve();
                } else {
                  expect(job?.delay).toBeLessThanOrEqual(750);
                }
              } catch (err) {
                reject(err);
              }
            });
          });

          worker.run();
          await failed;

          await worker.close();
        });

        describe('when jitter is provided with lower value than 1', () => {
          it("updates job's delay property only applying jitter in a fixed percentage", async () => {
            const worker = new Worker(
              queueName,
              async () => {
                throw new Error('error');
              },
              { autorun: false, connection, prefix },
            );
            await worker.waitUntilReady();

            await queue.add(
              'test',
              { bar: 'baz' },
              {
                attempts: 3,
                backoff: {
                  type: 'fixed',
                  delay: 750,
                  jitter: 0.5,
                },
              },
            );

            const failed = new Promise<void>((resolve, reject) => {
              worker.on('failed', async job => {
                try {
                  const attemptsMade = job?.attemptsMade;
                  if (attemptsMade! > 2) {
                    expect(job!.delay).toEqual(0);
                    resolve();
                  } else {
                    expect(job?.delay).toBeLessThanOrEqual(750);
                    expect(job?.delay).toBeGreaterThanOrEqual(325);
                  }
                } catch (err) {
                  reject(err);
                }
              });
            });

            worker.run();
            await failed;

            await worker.close();
          });
        });
      });
    });

    describe('when attempts is 1 and job fails', () => {
      it('should execute job only once and emits retries-exhausted event', async () => {
        const worker = new Worker(
          queueName,
          async () => {
            throw new Error('failed');
          },
          { connection, prefix },
        );

        await worker.waitUntilReady();

        const job = await queue.add(
          'test',
          { foo: 'bar' },
          {
            attempts: 1,
          },
        );

        await new Promise<void>(resolve => {
          queueEvents.on(
            'retries-exhausted',
            async ({ jobId, attemptsMade }) => {
              expect(jobId).toEqual(job.id);
              expect(1).toEqual(Number(attemptsMade));
              resolve();
            },
          );
        });

        const state = await job.getState();

        expect(state).toBe('failed');

        await worker.close();
      });
    });

    describe('when jobs do not fail and get the maximum attempts limit', () => {
      it('does not emit retries-exhausted event', async () => {
        const worker = new Worker(queueName, NoopProc, {
          connection,
          prefix,
        });

        await worker.waitUntilReady();

        const completing = new Promise<void>((resolve, reject) => {
          queueEvents.on('retries-exhausted', async () => {
            reject();
          });

          queueEvents.on(
            'completed',
            after(3, async function () {
              resolve();
            }),
          );
        });

        await Promise.all(
          times(3, () =>
            queue.add(
              'test',
              { foo: 'baz' },
              {
                attempts: 1,
              },
            ),
          ),
        );

        await completing;

        await worker.close();
      });
    });

    describe('when job has been failed and moved to wait', () => {
      it('saves failedReason', async () => {
        const worker = new Worker(
          queueName,
          async job => {
            expect(job.attemptsMade).toBe(0);
            await queue.rateLimit(5000);
            throw new Error('error');
          },
          { connection, prefix },
        );

        await worker.waitUntilReady();

        const job = await queue.add(
          'test',
          { foo: 'bar' },
          {
            attempts: 5,
          },
        );

        await new Promise(resolve => {
          worker.on('failed', resolve);
        });

        const updatedJob = await queue.getJob(job.id!);

        expect(updatedJob.failedReason).toBe('error');

        await worker.close();
      });
    });

    it('should automatically retry a failed job if attempts is bigger than 1', async () => {
      let tries = 0;

      const worker = new Worker(
        queueName,
        async job => {
          await delay(10);
          expect(job.attemptsMade).toEqual(tries);
          tries++;
          if (job.attemptsMade < 1) {
            throw new Error('Not yet!');
          }
        },
        { autorun: false, connection, prefix },
      );

      await worker.waitUntilReady();

      await queue.add(
        'test',
        { foo: 'bar' },
        {
          attempts: 3,
        },
      );

      worker.run();

      await new Promise(resolve => {
        worker.on('completed', resolve);
      });

      await worker.close();
    });

    describe('when there are delayed jobs between retries', () => {
      describe('when using retryJob', () => {
        it('promotes delayed jobs first', async () => {
          let id = 0;

          const worker = new Worker(
            queueName,
            async job => {
              id++;
              await delay(200);
              if (job.attemptsMade === 0) {
                expect(job.id).toEqual(`${id}`);
              }
              if (job.id == '1' && job.attemptsMade < 1) {
                throw new Error('Not yet!');
              }
            },
            { autorun: false, connection, prefix },
          );

          await worker.waitUntilReady();

          const completing = new Promise(resolve => {
            worker.on('completed', after(4, resolve));
          });

          await queue.add(
            'test',
            { foo: 'bar' },
            {
              attempts: 2,
            },
          );

          const jobs = Array.from(Array(3).keys()).map(index => ({
            name: 'test',
            data: {},
            opts: {
              delay: 200,
            },
          }));

          await queue.addBulk(jobs);

          worker.run();

          await completing;

          await worker.close();
        });
      });

      describe('when job has more priority than delayed jobs', () => {
        it('executes retried job first', async () => {
          let id = 0;

          const worker = new Worker(
            queueName,
            async job => {
              await delay(200);
              if (job.attemptsMade === 0) {
                id++;
                expect(job.id).toEqual(`${id}`);
              }
              if (job.id == '1' && job.attemptsMade < 1) {
                throw new Error('Not yet!');
              }
            },
            { connection, prefix },
          );

          await worker.waitUntilReady();

          const completing = new Promise(resolve => {
            worker.on('completed', after(4, resolve));
          });

          await queue.add(
            'test',
            { foo: 'bar' },
            {
              attempts: 2,
              priority: 1,
            },
          );

          const jobs = Array.from(Array(3).keys()).map(index => ({
            name: 'test',
            data: {},
            opts: {
              delay: 200,
              priority: 2,
            },
          }));

          await queue.addBulk(jobs);

          await completing;

          await worker.close();
        });
      });
    });

    it('should not retry a failed job more than the number of given attempts times', async () => {
      let tries = 0;

      const worker = new Worker(
        queueName,
        async job => {
          tries++;
          if (job.attemptsMade < 3) {
            throw new Error('Not yet!');
          }
          expect(job.attemptsMade).toEqual(tries);
        },
        { connection, prefix },
      );

      await worker.waitUntilReady();

      const job = await queue.add(
        'test',
        { foo: 'bar' },
        {
          attempts: 3,
        },
      );

      await new Promise<void>((resolve, reject) => {
        worker.on('completed', () => {
          reject(new Error('Failed job was retried more than it should be!'));
        });
        queueEvents.on('waiting', async ({ prev }) => {
          try {
            if (prev) {
              expect(prev).toEqual('active');
            }
          } catch (error) {
            reject(error);
          }
        });
        queueEvents.on('retries-exhausted', async ({ jobId, attemptsMade }) => {
          try {
            expect(jobId).toEqual(job.id);
            expect(3).toEqual(Number(attemptsMade));
            resolve();
          } catch (error) {
            reject(error);
          }
        });
      });

      const state = await job.getState();

      expect(state).toBe('failed');

      await worker.close();
    });

    it('should retry a job after a delay if a fixed backoff is given', async () => {
      // TODO: Move timeout to test options: { timeout: 10000 }

      const worker = new Worker(
        queueName,
        async job => {
          if (job.attemptsMade < 2) {
            throw new Error('Not yet!');
          }
        },
        { connection, prefix },
      );

      await worker.waitUntilReady();

      const start = Date.now();
      await queue.add(
        'test',
        { foo: 'bar' },
        {
          attempts: 3,
          backoff: 1000,
        },
      );

      await new Promise<void>(resolve => {
        worker.on('completed', () => {
          const elapse = Date.now() - start;
          expect(elapse).toBeGreaterThan(2000);
          resolve();
        });
      });

      await worker.close();
    });

    describe('when UnrecoverableError is throw', () => {
      it('moves job to failed', async () => {
        // TODO: Move timeout to test options: { timeout: 8000 }

        const worker = new Worker(
          queueName,
          async job => {
            if (job.attemptsMade < 1) {
              throw new Error('Not yet!');
            }
            if (job.attemptsMade < 2) {
              throw new UnrecoverableError('Unrecoverable');
            }
          },
          { connection, prefix },
        );

        await worker.waitUntilReady();

        const start = Date.now();
        const job = await queue.add(
          'test',
          { foo: 'bar' },
          {
            attempts: 3,
            backoff: 1000,
          },
        );

        await new Promise<void>(resolve => {
          worker.on(
            'failed',
            after(2, (job: Job, error) => {
              const elapse = Date.now() - start;
              expect(error.name).toEqual('UnrecoverableError');
              expect(error.message).toEqual('Unrecoverable');
              expect(elapse).toBeGreaterThan(1000);
              expect(job.attemptsMade).toEqual(2);
              resolve();
            }),
          );
        });

        const state = await job.getState();

        expect(state).toBe('failed');

        await worker.close();
      });
    });

    describe('when providing a way to execute step jobs', () => {
      it('should retry a job after a delay if a fixed backoff is given, keeping the current step', async () => {
        // TODO: Move timeout to test options: { timeout: 8000 }

        enum Step {
          Initial,
          Second,
          Finish,
        }

        const worker = new Worker(
          queueName,
          async job => {
            let step = job.data.step;
            while (step !== Step.Finish) {
              switch (step) {
                case Step.Initial: {
                  await job.updateData({
                    step: Step.Second,
                  });
                  step = Step.Second;
                  break;
                }
                case Step.Second: {
                  if (job.attemptsMade < 2) {
                    throw new Error('Not yet!');
                  }
                  await job.updateData({
                    step: Step.Finish,
                  });
                  step = Step.Finish;
                  return Step.Finish;
                }
                default: {
                  throw new Error('invalid step');
                }
              }
            }
          },
          { connection, prefix },
        );

        await worker.waitUntilReady();

        const start = Date.now();
        await queue.add(
          'test',
          { step: Step.Initial },
          {
            attempts: 3,
            backoff: 1000,
          },
        );

        await new Promise<void>(resolve => {
          worker.on('completed', job => {
            const elapse = Date.now() - start;
            expect(elapse).toBeGreaterThan(2000);
            expect(job.returnvalue).toEqual(Step.Finish);
            expect(job.attemptsMade).toEqual(3);
            resolve();
          });
        });

        await worker.close();
      });

      describe('when timeout is provided', () => {
        it('should check if timeout is reached in each step', async () => {
          enum Step {
            Initial,
            Second,
            Finish,
          }

          const worker = new Worker(
            queueName,
            async job => {
              const { timeout } = job.data;
              let { step } = job.data;
              let timeoutReached = false;

              setTimeout(() => {
                timeoutReached = true;
              }, timeout);
              while (step !== Step.Finish) {
                switch (step) {
                  case Step.Initial: {
                    await delay(1000);
                    if (timeoutReached) {
                      throw new Error('Timeout');
                    }
                    await job.updateData({
                      step: Step.Second,
                      timeout,
                    });
                    step = Step.Second;
                    break;
                  }
                  case Step.Second: {
                    await delay(1000);
                    if (timeoutReached) {
                      throw new Error('Timeout');
                    }
                    await job.updateData({
                      step: Step.Finish,
                      timeout,
                    });
                    step = Step.Finish;
                    return Step.Finish;
                  }
                  default: {
                    throw new Error('invalid step');
                  }
                }
              }
            },
            { connection, prefix },
          );

          await worker.waitUntilReady();

          const start = Date.now();
          await queue.add(
            'test',
            { step: Step.Initial, timeout: 1500 },
            {
              attempts: 3,
              backoff: 500,
            },
          );

          await new Promise<void>(resolve => {
            worker.on('completed', job => {
              const elapse = Date.now() - start;
              expect(elapse).toBeGreaterThan(3000);
              expect(elapse).toBeLessThan(4000);
              expect(job.failedReason).toEqual('Timeout');
              expect(job.returnvalue).toEqual(Step.Finish);
              expect(job.attemptsMade).toEqual(2);
              resolve();
            });
          });

          await worker.close();
        });
      });

      describe('when moving job to delayed in one step', () => {
        it('should retry job after a delay time, keeping the current step', async () => {
          // TODO: Move timeout to test options: { timeout: 8000 }

          enum Step {
            Initial,
            Second,
            Finish,
          }

          const worker = new Worker(
            queueName,
            async (job, token) => {
              let step = job.data.step;
              while (step !== Step.Finish) {
                switch (step) {
                  case Step.Initial: {
                    await job.moveToDelayed(Date.now() + 200, token);
                    await job.updateData({
                      step: Step.Second,
                    });
                    throw new DelayedError();
                  }
                  case Step.Second: {
                    await job.updateData({
                      step: Step.Finish,
                    });
                    step = Step.Finish;
                    return Step.Finish;
                  }
                  default: {
                    throw new Error('invalid step');
                  }
                }
              }
            },
            { connection, prefix },
          );

          await worker.waitUntilReady();

          const start = Date.now();
          await queue.add('test', { step: Step.Initial });

          await new Promise<void>((resolve, reject) => {
            worker.on('completed', job => {
              const elapse = Date.now() - start;
              expect(elapse).toBeGreaterThan(200);
              expect(job.returnvalue).toEqual(Step.Finish);
              expect(job.attemptsMade).toEqual(1);
              expect(job.attemptsStarted).toEqual(2);
              resolve();
            });

            worker.on('error', () => {
              reject();
            });
          });

          await worker.close();
        });

        describe('when passing maxStartedAttempts', () => {
          it('should fail job when consuming the max started attempts', async () => {
            const worker = new Worker(
              queueName,
              async (job, token) => {
                await job.moveToDelayed(Date.now() + 200, token);
                throw new DelayedError();
              },
              { connection, maxStartedAttempts: 1, prefix },
            );

            await worker.waitUntilReady();

            const start = Date.now();
            await queue.add('test', {});

            await new Promise<void>((resolve, reject) => {
              worker.on('failed', job => {
                try {
                  const elapse = Date.now() - start;
                  expect(elapse).toBeGreaterThan(200);
                  expect(job!.failedReason).toEqual(
                    'job started more than allowable limit',
                  );
                  expect(job!.attemptsMade).toEqual(1);
                  expect(job!.attemptsStarted).toEqual(2);
                  resolve();
                } catch (error) {
                  reject(error);
                }
              });

              worker.on('error', error => {
                reject(error);
              });
            });

            await worker.close();
          });

          it('should allow only retry a job once after it has reached the max attemptsStarted', async () => {
            let attempts = 0;
            const failedError = new Error('failed');

            const worker = new Worker(
              queueName,
              async () => {
                if (attempts < 3) {
                  attempts++;
                  throw failedError;
                }
              },
              { connection, maxStartedAttempts: 1, prefix },
            );

            await worker.waitUntilReady();

            const failing = new Promise<void>((resolve, reject) => {
              worker.on('failed', async (job, err) => {
                try {
                  expect(job.data.foo).toBe('bar');
                  if (job.attemptsMade === 2) {
                    expect(err.message).toBe(
                      'job started more than allowable limit',
                    );
                    expect(job?.attemptsStarted).toBe(2);
                    await job.retry();
                    resolve();
                  }
                } catch (error) {
                  reject(error);
                }
              });
            });

            const failedAgain = new Promise<void>((resolve, reject) => {
              worker.on('failed', async (job, err) => {
                try {
                  if (job.attemptsMade === 3) {
                    expect(err.message).toBe(
                      'job started more than allowable limit',
                    );
                    expect(job?.attemptsStarted).toBe(3);
                    resolve();
                  }
                } catch (error) {
                  reject(error);
                }
              });
            });

            await queue.add('test', { foo: 'bar' }, { attempts: 2 });

            await failing;
            await failedAgain;

            const failedCount = await queue.getFailedCount();
            expect(failedCount).toBe(1);

            const completedCount = await queue.getCompletedCount();
            expect(completedCount).toBe(0);

            await worker.close();
          });
        });
      });

      describe('when moving job to waiting in one step', () => {
        it('should retry job right away, keeping the current step', async () => {
          // TODO: Move timeout to test options: { timeout: 1000 }

          enum Step {
            Initial,
            Second,
            Finish,
          }

          const worker = new Worker(
            queueName,
            async (job, token) => {
              let step = job.data.step;
              while (step !== Step.Finish) {
                switch (step) {
                  case Step.Initial: {
                    await job.moveToWait(token);
                    await job.updateData({
                      step: Step.Second,
                    });
                    throw new WaitingError();
                  }
                  case Step.Second: {
                    await job.updateData({
                      step: Step.Finish,
                    });
                    step = Step.Finish;
                    return Step.Finish;
                  }
                  default: {
                    throw new Error('invalid step');
                  }
                }
              }
            },
            { connection, prefix },
          );

          await worker.waitUntilReady();

          const start = Date.now();
          await queue.add('test', { step: Step.Initial });

          await new Promise<void>((resolve, reject) => {
            worker.on('completed', job => {
              expect(job.returnvalue).toEqual(Step.Finish);
              expect(job.attemptsMade).toEqual(1);
              expect(job.attemptsStarted).toEqual(2);
              resolve();
            });

            worker.on('error', () => {
              reject();
            });
          });

          await worker.close();
        });
      });

      // NOTE: 'when creating children at runtime' step-job tests are
      // Redis-coupled (a runtime child sets parent queue to
      // `${prefix}:${parentQueueName}`, which only matches the qualified name on
      // Redis) and live in `worker.redis.test.ts`.
    });

    it('should retry a job after a delay if an exponential backoff is given', async () => {
      // TODO: Move timeout to test options: { timeout: 10000 }

      const worker = new Worker(
        queueName,
        async job => {
          if (job.attemptsMade < 2) {
            throw new Error('Not yet!');
          }
        },
        { connection, prefix },
      );

      await worker.waitUntilReady();

      const start = Date.now();
      await queue.add(
        'test',
        { foo: 'bar' },
        {
          attempts: 3,
          backoff: {
            type: 'exponential',
            delay: 1000,
          },
        },
      );

      await new Promise<void>(resolve => {
        worker.on('completed', () => {
          const elapse = Date.now() - start;
          const expected = 1000 * (Math.pow(2, 2) - 1);
          expect(elapse).toBeGreaterThan(expected);
          resolve();
        });
      });

      await worker.close();
    });

    it('should retry a job after a delay if a custom backoff is given', async () => {
      // TODO: Move timeout to test options: { timeout: 10000 }

      const worker = new Worker(
        queueName,
        async job => {
          if (job.attemptsMade < 2) {
            throw new Error('Not yet!');
          }
        },
        {
          connection,
          prefix,
          settings: {
            backoffStrategy: (attemptsMade: number) => {
              return attemptsMade * 1000;
            },
          },
        },
      );

      await worker.waitUntilReady();

      const start = Date.now();
      await queue.add(
        'test',
        { foo: 'bar' },
        {
          attempts: 3,
          backoff: {
            type: 'custom',
          },
        },
      );

      await new Promise<void>(resolve => {
        worker.on('completed', () => {
          const elapse = Date.now() - start;
          expect(elapse).toBeGreaterThan(3000);
          resolve();
        });
      });

      await worker.close();
    });

    describe('when applying custom backoff by type', () => {
      it('should retry a job after a delay for custom type', async () => {
        // TODO: Move timeout to test options: { timeout: 10000 }

        const worker = new Worker(
          queueName,
          async job => {
            if (job.attemptsMade < 2) {
              throw new Error('Not yet!');
            }
          },
          {
            connection,
            prefix,
            settings: {
              backoffStrategy: (
                attemptsMade: number,
                type: string,
                err: Error,
                job: MinimalJob,
              ) => {
                switch (type) {
                  case 'custom1': {
                    return attemptsMade * 1000;
                  }
                  case 'custom2': {
                    return attemptsMade * 2000;
                  }
                  default: {
                    throw new Error('invalid type');
                  }
                }
              },
            },
          },
        );

        await worker.waitUntilReady();

        const start = Date.now();
        await queue.add(
          'test',
          { foo: 'baz' },
          {
            attempts: 3,
            backoff: {
              type: 'custom1',
            },
          },
        );

        await new Promise<void>(resolve => {
          worker.on('completed', () => {
            const elapse = Date.now() - start;
            expect(elapse).toBeGreaterThan(3000);
            resolve();
          });
        });

        await queue.add(
          'test',
          { foo: 'bar' },
          {
            attempts: 3,
            backoff: {
              type: 'custom2',
            },
          },
        );

        await new Promise<void>(resolve => {
          worker.on('completed', () => {
            const elapse = Date.now() - start;
            expect(elapse).toBeGreaterThan(6000);
            resolve();
          });
        });

        await worker.close();
      });
    });

    it('should not retry a job if the custom backoff returns -1', async () => {
      let tries = 0;

      const worker = new Worker(
        queueName,
        async job => {
          tries++;
          if (job.attemptsMade < 2) {
            throw new Error('Not yet!');
          }
        },
        {
          connection,
          prefix,
          settings: {
            backoffStrategy: () => {
              return -1;
            },
          },
        },
      );

      await queue.add(
        'test',
        { foo: 'bar' },
        {
          attempts: 3,
          backoff: {
            type: 'custom',
          },
        },
      );

      await new Promise<void>((resolve, reject) => {
        worker.on('completed', () => {
          reject(new Error('Failed job was retried more than it should be!'));
        });
        worker.on('failed', () => {
          if (tries === 1) {
            resolve();
          }
        });
      });

      await worker.close();
    });

    it('should retry a job after a delay if a custom backoff is given based on the error thrown', async () => {
      class CustomError extends Error {}

      // TODO: Move timeout to test options: { timeout: 10000 }

      const worker = new Worker(
        queueName,
        async job => {
          if (job.attemptsMade < 2) {
            throw new CustomError('Hey, custom error!');
          }
        },
        {
          connection,
          prefix,
          settings: {
            backoffStrategy: (
              attemptsMade: number,
              type: string,
              err: Error,
            ) => {
              if (err instanceof CustomError) {
                return 1500;
              }
              return 500;
            },
          },
        },
      );

      const start = Date.now();
      await queue.add(
        'test',
        { foo: 'bar' },
        {
          attempts: 3,
          backoff: {
            type: 'custom',
          },
        },
      );

      await new Promise<void>(resolve => {
        worker.on('completed', () => {
          const elapse = Date.now() - start;
          expect(elapse).toBeGreaterThan(3000);
          resolve();
        });
      });

      await worker.close();
    });

    it('should retry a job after a delay if a custom backoff is given based on the job data', async () => {
      class CustomError extends Error {
        failedIds: number[];
      }

      // TODO: Move timeout to test options: { timeout: 5000 }

      const worker = new Worker(
        queueName,
        async job => {
          if (job.data.ids.length > 2) {
            const error = new CustomError('Hey, custom error!');
            error.failedIds = [1, 2];

            throw error;
          }
        },
        {
          connection,
          prefix,
          settings: {
            backoffStrategy: async (
              attemptsMade: number,
              type: string,
              err: Error,
              job: MinimalJob,
            ) => {
              if (err instanceof CustomError) {
                const data = job.data;
                data.ids = err.failedIds;
                await job.updateData(data);
                return 2500;
              }
              return 500;
            },
          },
        },
      );

      const start = Date.now();
      await queue.add(
        'test',
        { ids: [1, 2, 3] },
        {
          attempts: 3,
          backoff: {
            type: 'custom',
          },
        },
      );

      await new Promise<void>(resolve => {
        worker.on('completed', () => {
          const elapse = Date.now() - start;
          expect(elapse).toBeGreaterThan(2500);
          resolve();
        });
      });

      await worker.close();
    });

    it('should be able to handle a custom backoff if it returns a promise', async () => {
      // TODO: Move timeout to test options: { timeout: 10000 }

      const worker = new Worker(
        queueName,
        async (job: Job) => {
          if (job.attemptsMade < 2) {
            throw new Error('some error');
          }
        },
        {
          connection,
          prefix,
          settings: {
            backoffStrategy: async () => {
              await delay(500);

              return 10;
            },
          },
        },
      );
      const start = Date.now();
      await queue.add(
        'test',
        { foo: 'bar' },
        {
          attempts: 3,
          backoff: {
            type: 'custom',
          },
        },
      );

      await new Promise<void>(resolve => {
        worker.on('completed', () => {
          const elapse = Date.now() - start;
          expect(elapse).toBeGreaterThan(1000);
          resolve();
        });
      });

      await worker.close();
    });

    it('should not retry a job that has been removed', async () => {
      const failedError = new Error('failed');
      let attempts = 0;
      const worker = new Worker(
        queueName,
        async () => {
          if (attempts === 0) {
            attempts++;
            throw failedError;
          }
        },
        { connection, prefix },
      );

      await worker.waitUntilReady();

      const failing = new Promise<void>(resolve => {
        worker.on('failed', async (job, err) => {
          expect(job.data.foo).toBe('bar');
          expect(err).toBe(failedError);
          expect(job.failedReason).toBe(failedError.message);
          await job.retry();
          resolve();
        });
      });

      const completing = new Promise<void>(resolve => {
        worker.on('completed', async () => {
          resolve();
        });
      });

      const retriedJob = await queue.add('test', { foo: 'bar' });

      await failing;
      await completing;

      const count = await queue.getCompletedCount();
      expect(count).toBe(1);
      await delay(10);
      await queue.clean(0, 0);

      await expect(retriedJob.retry()).rejects.toThrow(
        `Missing key for job ${retriedJob.id}. reprocessJob`,
      );

      const completedCount = await queue.getCompletedCount();
      expect(completedCount).toBe(0);
      const failedCount = await queue.getFailedCount();
      expect(failedCount).toBe(0);

      await worker.close();
    });

    it('should not retry a job that has been retried already', async () => {
      let attempts = 0;
      const failedError = new Error('failed');

      const worker = new Worker(
        queueName,
        async () => {
          if (attempts === 0) {
            attempts++;
            throw failedError;
          }
        },
        { connection, prefix },
      );

      await worker.waitUntilReady();

      const failing = new Promise<void>(resolve => {
        worker.on('failed', async (job, err) => {
          expect(job.data.foo).toBe('bar');
          expect(err).toBe(failedError);
          await job.retry();
          resolve();
        });
      });

      const completing = new Promise<void>(resolve => {
        worker.on('completed', async () => {
          resolve();
        });
      });

      const retriedJob = await queue.add('test', { foo: 'bar' });

      await failing;
      await completing;

      const completedCount = await queue.getCompletedCount();
      expect(completedCount).toBe(1);

      await expect(retriedJob.retry()).rejects.toThrow(
        `Job ${retriedJob.id} is not in the failed state. reprocessJob`,
      );

      const completedCount2 = await queue.getCompletedCount();
      expect(completedCount2).toBe(1);
      const failedCount = await queue.getFailedCount();
      expect(failedCount).toBe(0);

      await worker.close();
    });

    it('should only retry a job once after it has reached the max attempts', async () => {
      let attempts = 0;
      const failedError = new Error('failed');

      const worker = new Worker(
        queueName,
        async () => {
          if (attempts < 3) {
            attempts++;
            throw failedError;
          }
        },
        { connection, prefix },
      );

      await worker.waitUntilReady();

      const failing = new Promise<void>(resolve => {
        worker.on('failed', async (job, err) => {
          expect(job.data.foo).toBe('bar');
          expect(err).toBe(failedError);
          if (job.attemptsMade === 2) {
            await job.retry();
            resolve();
          }
        });
      });

      const failedAgain = new Promise<void>(resolve => {
        worker.on('failed', async job => {
          if (job.attemptsMade === 3) {
            resolve();
          }
        });
      });

      const retriedJob = await queue.add(
        'test',
        { foo: 'bar' },
        { attempts: 2 },
      );

      await failing;
      await failedAgain;

      const failedCount = await queue.getFailedCount();
      expect(failedCount).toBe(1);

      await expect(retriedJob.retry('completed')).rejects.toThrow(
        `Job ${retriedJob.id} is not in the completed state. reprocessJob`,
      );

      const completedCount = await queue.getCompletedCount();
      expect(completedCount).toBe(0);

      await worker.close();
    });

    it('should not retry a job that is active', async () => {
      const worker = new Worker(
        queueName,
        async () => {
          await delay(500);
        },
        { connection, prefix },
      );

      await worker.waitUntilReady();

      const activating = new Promise(resolve => {
        worker.on('active', resolve);
      });

      const job = await queue.add('test', { foo: 'bar' });

      expect(job.data.foo).toBe('bar');

      await activating;

      await expect(job.retry()).rejects.toThrow(
        `Job ${job.id} is not in the failed state. reprocessJob`,
      );

      await worker.close();
    });

    /*
    it('an unlocked job should not be moved to failed', done => {
      queue = utils.buildQueue('test unlocked failed');

      queue.process((job, callback) => {
        // Release the lock to simulate the event loop stalling (so failure to renew the lock).
        job.releaseLock().then(() => {
          // Once it's failed, it should NOT be moved to failed since this worker lost the lock.
          callback(new Error('retry this job'));
        });
      });

      queue.on('failed', job => {
        job.isFailed().then(isFailed => {
          expect(isFailed).toBe(false);
        });
      });

      queue.on('error', (err) => {
        queue.close().then(done, done);
      });

      // Note that backoff:0 should immediately retry the job upon failure (ie put it in 'waiting')
      queue.add({ foo: 'bar' }, { backoff: 0, attempts: 2 });
    });
    */
  });

  describe('Manually process jobs', () => {
    it('should allow to complete jobs manually', async () => {
      const worker = new Worker(queueName, void 0, { connection, prefix });
      const token = 'my-token';

      await queue.add('test', { foo: 'bar' });

      const job = (await worker.getNextJob(token)) as Job;

      const isActive = await job.isActive();
      expect(isActive).toBe(true);

      await job.moveToCompleted('return value', token);

      const isCompleted = await job.isCompleted();

      expect(isCompleted).toBe(true);
      expect(job.attemptsMade).toBe(1);
      expect(job.finishedOn).toBeTypeOf('number');
      expect(job.returnvalue).toBe('return value');

      await worker.close();
    });

    describe('when move job to waiting-children', () => {
      describe('when job is not in active state', () => {
        it('throws an error', async () => {
          const values = [{ idx: 0, bar: 'something' }];
          const parentToken = 'parent-token';
          const childToken = 'child-token';

          const parentQueueName = `parent-queue-${randomUUID()}`;

          const parentQueue = new Queue(parentQueueName, {
            connection,
            prefix,
          });
          const parentWorker = new Worker(parentQueueName, null, {
            connection,
            prefix,
          });
          const childrenWorker = new Worker(queueName, null, {
            connection,
            prefix,
          });

          const data = { foo: 'bar' };
          await Job.create(parentQueue, 'testDepend', data);

          const parent = (await parentWorker.getNextJob(parentToken)) as Job;
          const currentState = await parent.getState();

          expect(currentState).toBe('active');

          await Job.create(queue, 'testJob1', values[0], {
            parent: {
              id: parent.id,
              queue: `${qualify(queue, parentQueueName)}`,
            },
          });
          const { unprocessed: unprocessed1 } = await parent.getDependencies();

          expect(unprocessed1).toHaveLength(1);

          const child1 = (await childrenWorker.getNextJob(childToken)) as Job;
          const isActive1 = await child1.isActive();

          expect(isActive1).toBe(true);

          await parent.moveToWaitingChildren(parentToken, {
            child: {
              id: child1.id,
              queue: `${qualify(queue, queueName)}`,
            },
          });
          const waitingChildren = await parentQueue.getWaitingChildren();
          const currentState2 = await parent.getState();

          expect(currentState2).toBe('waiting-children');
          expect(waitingChildren.length).toBe(1);

          await expect(
            parent.moveToWaitingChildren(parentToken, {
              child: {
                id: child1.id,
                queue: `${qualify(queue, queueName)}`,
              },
            }),
          ).rejects.toThrow(
            `Missing lock for job ${parent.id}. moveToWaitingChildren`,
          );

          await expect(
            parent.moveToWaitingChildren('0', {
              child: {
                id: child1.id,
                queue: `${qualify(queue, queueName)}`,
              },
            }),
          ).rejects.toThrow(
            `Job ${parent.id} is not in the active state. moveToWaitingChildren`,
          );

          await childrenWorker.close();
          await parentWorker.close();

          await parentQueue.close();
          await cleanupQueue(parentQueueName);
        });
      });
    });

    it('should allow to fail jobs manually', async () => {
      const worker = new Worker(queueName, null, { connection, prefix });
      const token = 'my-token';

      await queue.add('test', { foo: 'bar' });

      const job = (await worker.getNextJob(token)) as Job;

      const isActive = await job.isActive();
      expect(isActive).toBe(true);

      await job.moveToFailed(new Error('job failed for some reason'), token);

      const isCompleted = await job.isCompleted();
      const isFailed = await job.isFailed();

      expect(isCompleted).toBe(false);
      expect(isFailed).toBe(true);
      expect(job.attemptsMade).toBe(1);
      expect(job.finishedOn).toBeTypeOf('number');
      expect(job.failedReason).toBe('job failed for some reason');

      await worker.close();
    });

    describe('when there is a job in waiting', () => {
      it('should emit active event when calling getNextJob', async () => {
        const worker = new Worker(queueName, null, { connection, prefix });
        const token = 'my-token';

        await queue.add('test', { foo: 'bar' });

        const activated = new Promise<Job>(resolve => {
          worker.on('active', resolve);
        });

        const job = (await worker.getNextJob(token)) as Job;

        const activatedJob = await activated;

        expect(activatedJob.id).toBe(job.id);

        const isActive = await job.isActive();
        expect(isActive).toBe(true);

        await job.moveToCompleted('done', token);
        await worker.close();
      });
    });

    describe('when a stalled job has exhausted its max stalled attempts', () => {
      const markJobForDeferredFailure = async (worker: Worker, job: Job) => {
        const client = await getRedisClient(worker);
        await client.del(`${prefix}:${queueName}:${job.id}:lock`);

        const stalled = new Promise<string>(resolve => {
          worker.on('stalled', resolve);
        });

        await (worker as any).moveStalledJobsToWait();
        await client.del(`${prefix}:${queueName}:stalled-check`);
        await (worker as any).moveStalledJobsToWait();

        expect(await stalled).toBe(job.id);
      };

      it(
        'should move the job to failed automatically on the next getNextJob ' +
          'call and return undefined when no other jobs are waiting',
        async () => {
          const worker = new Worker(queueName, null, {
            autorun: false,
            connection,
            prefix,
            lockDuration: 1000,
            stalledInterval: 100,
            maxStalledCount: 0,
          });

          const token = 'my-token';

          await queue.add('test', { foo: 'bar' });

          const firstJob = (await worker.getNextJob(token)) as Job;
          expect(firstJob).toBeDefined();

          await markJobForDeferredFailure(worker, firstJob);

          const deferredJob = (await worker.getNextJob(token, {
            block: false,
          })) as Job;
          expect(deferredJob.id).toBe(firstJob.id);
          expect(deferredJob.deferredFailure).toBe(
            'job stalled more than allowable limit',
          );
          await deferredJob.moveToFailed(
            new UnrecoverableError(deferredJob.deferredFailure),
            token,
          );

          const nextFetched = await worker.getNextJob(token, { block: false });
          expect(nextFetched).toBeUndefined();

          const counts = await queue.getJobCounts('failed', 'wait', 'active');
          expect(counts.failed).toBe(1);
          expect(counts.wait).toBe(0);
          expect(counts.active).toBe(0);

          await worker.close();
        },
      );

      it('should fail the deferred-failure job and return the next waiting job', async () => {
        const worker = new Worker(queueName, null, {
          autorun: false,
          connection,
          prefix,
          lockDuration: 1000,
          stalledInterval: 100,
          maxStalledCount: 0,
        });

        const token = 'my-token';

        await queue.add('stalled-job', { foo: 'bar' });

        const firstJob = (await worker.getNextJob(token)) as Job;
        expect(firstJob).toBeDefined();

        await markJobForDeferredFailure(worker, firstJob);

        const secondAdded = await queue.add('runnable-job', { foo: 'baz' });

        const deferredJob = (await worker.getNextJob(token, {
          block: false,
        })) as Job;
        expect(deferredJob.id).toBe(firstJob.id);
        expect(deferredJob.deferredFailure).toBe(
          'job stalled more than allowable limit',
        );
        await deferredJob.moveToFailed(
          new UnrecoverableError(deferredJob.deferredFailure),
          token,
        );

        const nextFetched = (await worker.getNextJob(token, {
          block: false,
        })) as Job;
        expect(nextFetched).toBeDefined();
        expect(nextFetched.id).toBe(secondAdded.id);

        const counts = await queue.getJobCounts('failed', 'wait', 'active');
        expect(counts.failed).toBe(1);
        expect(counts.wait).toBe(0);
        expect(counts.active).toBe(1);

        await nextFetched.moveToCompleted('done', token);
        await worker.close();
      });
    });
  });

  describe('non-blocking', () => {
    it('should block by default', async () => {
      const worker = new Worker(queueName, null, { connection, prefix });
      const token = 'my-token';

      // make sure worker is in drained state
      await worker.getNextJob(token);

      const [job] = await Promise.all([
        worker.getNextJob(token) as Promise<Job>,
        delay(100).then(() => queue.add('test', { foo: 'bar' })),
      ]);
      expect(job).not.toBe(undefined);
      const isActive = await job.isActive();
      expect(isActive).toBe(true);

      await worker.close();
    });

    it("shouldn't block when disabled", async () => {
      const worker = new Worker(queueName, null, { connection, prefix });
      const token = 'my-token';

      // make sure worker is in drained state
      await worker.getNextJob(token, { block: false });

      const [job1] = await Promise.all([
        worker.getNextJob(token, { block: false }) as Promise<Job>,
        delay(100).then(() => queue.add('test', { foo: 'bar' })),
      ]);
      expect(job1).toBe(undefined);

      const job2 = (await worker.getNextJob(token, { block: false })) as Job;
      const isActive = await job2.isActive();
      expect(isActive).toBe(true);

      await worker.close();
    });

    it("shouldn't block when disabled and paused", async () => {
      const worker = new Worker(queueName, null, { connection, prefix });
      const token = 'my-token';

      // make sure worker is in drained state
      await worker.getNextJob(token, { block: false });
      await queue.add('test', { foo: 'bar' });

      worker.pause();

      const job1 = (await worker.getNextJob(token, { block: false })) as Job;
      expect(job1).toBe(undefined);

      await worker.resume();

      const job2 = (await worker.getNextJob(token, { block: false })) as Job;
      const isActive = await job2.isActive();
      expect(isActive).toBe(true);

      await worker.close();
    });
  });

  // NOTE: 'should clear job from stalled set when job completed' is
  // Redis-specific (it reads the raw `:stalled` set via `scard`) and lives in
  // `worker.redis.test.ts`.

  it('should retrieve concurrency from getter', async () => {
    const worker = new Worker(queueName, NoopProc, {
      connection,
      concurrency: 100,
    });
    worker.concurrency = 10;

    expect(worker.concurrency).toBe(10);

    await worker.close();
  });
});
