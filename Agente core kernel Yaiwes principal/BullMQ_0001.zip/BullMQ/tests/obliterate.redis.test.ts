/**
 * Redis-only tests for `Queue.obliterate`.
 *
 * These verify obliteration by asserting on the raw Redis keyspace
 * (`client.keys('<prefix>:<queue>:*')`), which has no backend-agnostic
 * equivalent, and they exercise the flow-aware parent handling (a child queue
 * being obliterated moving/keeping its parent in another queue) that the
 * PostgreSQL flows slice does not implement yet. The backend-agnostic parts of
 * obliterate (the active-jobs guard, job-log removal) live in
 * `obliterate.test.ts`.
 */
import { getRedisClient } from './utils/get-redis-client';
import { after } from './utils/lodash';
import {
  describe,
  beforeEach,
  afterEach,
  beforeAll,
  afterAll,
  it,
  expect,
} from 'vitest';

import { Queue, QueueEvents, FlowProducer, Worker, Job } from '../src/classes';
import { delay, randomUUID, removeAllQueueData } from '../src/utils';
import { createTestConnection } from './utils/connection-factory';
import { IRedisClient } from '../src/interfaces';

describe('Obliterate (redis-only)', () => {
  const prefix = process.env.BULLMQ_TEST_PREFIX || 'bull';

  let queue: Queue;
  let queueEvents: QueueEvents;
  let queueName: string;

  let connection: IRedisClient;
  beforeAll(async () => {
    connection = createTestConnection();
  });

  beforeEach(async () => {
    queueName = `test-${randomUUID()}`;
    queue = new Queue(queueName, { connection, prefix });
    queueEvents = new QueueEvents(queueName, { connection, prefix });
    await queueEvents.waitUntilReady();
  });

  afterEach(async () => {
    await queue.close();
    await queueEvents.close();
    await removeAllQueueData(createTestConnection(), queueName);
  });

  afterAll(async function () {
    await connection.quit();
  });

  it('should obliterate an empty queue', async () => {
    await queue.waitUntilReady();

    await queue.obliterate();

    const client = await getRedisClient(queue);
    const keys = await client.keys(`${prefix}:${queue.name}:*`);

    expect(keys.length).toEqual(0);
  });

  it('should obliterate a queue which is empty but has had jobs in the past', async () => {
    await queue.waitUntilReady();

    const job = await queue.add('test', { foo: 'bar' });
    await job.remove();

    await queue.obliterate();

    const client = await getRedisClient(queue);
    const keys = await client.keys(`${prefix}:${queue.name}:*`);
    expect(keys.length).toEqual(0);
  });

  it('should obliterate a queue with jobs in different statuses', async () => {
    await queue.waitUntilReady();

    await queue.add('test', { foo: 'bar' });
    await queue.add('test', { foo: 'bar2' });
    await queue.add('test', { foo: 'bar3' }, { delay: 5000 });
    const job = await queue.add('test', { qux: 'baz' });

    let first = true;
    const worker = new Worker(
      queue.name,
      async () => {
        if (first) {
          first = false;
          throw new Error('failed first');
        }
        return delay(250);
      },
      { connection, prefix },
    );
    await worker.waitUntilReady();

    await job.waitUntilFinished(queueEvents);

    await queue.obliterate();
    const client = await getRedisClient(queue);
    const keys = await client.keys(`${prefix}:${queue.name}:*`);
    expect(keys.length).toEqual(0);

    await worker.close();
  });

  describe('when creating a flow', async () => {
    describe('when parent belongs to same queue', async () => {
      describe('when parent has more than 1 pending children in the same queue', async () => {
        it('removes parent record', async () => {
          await queue.waitUntilReady();
          const name = 'child-job';

          const flow = new FlowProducer({ connection, prefix });
          await flow.add({
            name: 'parent-job',
            queueName,
            data: {},
            children: [
              { name, data: { idx: 0, foo: 'bar' }, queueName },
              { name, data: { idx: 1, foo: 'baz' }, queueName },
              { name, data: { idx: 2, foo: 'qux' }, queueName },
            ],
          });

          const count = await queue.count();
          expect(count).toEqual(4);

          await queue.obliterate();

          const client = await getRedisClient(queue);
          const keys = await client.keys(`${prefix}:${queue.name}:*`);

          expect(keys.length).toEqual(0);

          const countAfterEmpty = await queue.count();
          expect(countAfterEmpty).toEqual(0);

          const failedCount = await queue.getJobCountByTypes('failed');
          expect(failedCount).toEqual(0);

          await flow.close();
        });
      });

      describe('when parent has only 1 pending child in the same queue', async () => {
        it('obliterates a queue with jobs and its dependency keys', async () => {
          await queue.waitUntilReady();
          const name = 'child-job';

          let first = true;
          const worker = new Worker(
            queue.name,
            async () => {
              if (first) {
                first = false;
                throw new Error('failed first');
              }
              return delay(10);
            },
            { connection, prefix },
          );
          await worker.waitUntilReady();

          const completing = new Promise(resolve => {
            worker.on('completed', after(2, resolve));
          });

          const failing = new Promise(resolve => {
            worker.on('failed', resolve);
          });

          const flow = new FlowProducer({ connection, prefix });
          await flow.add({
            name: 'parent-job',
            queueName,
            data: {},
            children: [
              { name, data: { idx: 0, foo: 'bar' }, queueName },
              { name, data: { idx: 1, foo: 'baz' }, queueName },
              { name, data: { idx: 2, foo: 'qux' }, queueName },
            ],
          });

          await failing;
          await completing;
          await queue.obliterate();

          const client = await getRedisClient(queue);
          const keys = await client.keys(`${prefix}:${queue.name}:*`);

          expect(keys.length).toEqual(0);

          await worker.close();
          await flow.close();
        });
      });

      describe('when parent has pending children in different queue', async () => {
        it('keeps parent in waiting-children', async () => {
          await queue.waitUntilReady();
          const childrenQueueName = `test-${randomUUID()}`;
          const childrenQueue = new Queue(childrenQueueName, {
            connection,
            prefix,
          });
          await childrenQueue.waitUntilReady();
          const name = 'child-job';

          const flow = new FlowProducer({ connection, prefix });
          await flow.add({
            name: 'parent-job',
            queueName,
            data: {},
            children: [
              {
                name,
                data: { idx: 0, foo: 'bar' },
                queueName: childrenQueueName,
              },
            ],
          });

          const count = await queue.count();
          expect(count).toEqual(1);

          await queue.obliterate();

          const client = await getRedisClient(queue);
          const keys = await client.keys(`${prefix}:${queue.name}:*`);

          expect(keys.length).toEqual(3);

          const countAfterEmpty = await queue.count();
          expect(countAfterEmpty).toEqual(1);
          await childrenQueue.close();
          await flow.close();
        });
      });
    });

    describe('when parent belongs to different queue', async () => {
      describe('when parent has more than 1 pending children', async () => {
        it('deletes each children until trying to move parent to wait', async () => {
          await queue.waitUntilReady();
          const parentQueueName = `test-${randomUUID()}`;
          const parentQueue = new Queue(parentQueueName, {
            connection,
            prefix,
          });
          await parentQueue.waitUntilReady();
          const name = 'child-job';

          const flow = new FlowProducer({ connection, prefix });
          await flow.add({
            name: 'parent-job',
            queueName: parentQueueName,
            data: {},
            children: [
              { name, data: { idx: 0, foo: 'bar' }, queueName },
              { name, data: { idx: 1, foo: 'baz' }, queueName },
              { name, data: { idx: 2, foo: 'qux' }, queueName },
            ],
          });

          const count = await queue.count();
          expect(count).toEqual(3);

          await queue.obliterate();

          const client = await getRedisClient(queue);
          const keys = await client.keys(`${prefix}:${queueName}:*`);

          expect(keys.length).toEqual(0);

          const eventsCount = await client.xlen(
            `${prefix}:${parentQueueName}:events`,
          );

          expect(eventsCount).toEqual(2); // added and waiting-children events

          const countAfterEmpty = await queue.count();
          expect(countAfterEmpty).toEqual(0);

          const childrenFailedCount = await queue.getJobCountByTypes('failed');
          expect(childrenFailedCount).toEqual(0);

          const parentWaitCount = await parentQueue.getJobCountByTypes('wait');
          expect(parentWaitCount).toEqual(1);
          await parentQueue.close();
          await flow.close();
          await removeAllQueueData(createTestConnection(), parentQueueName);
        });
      });

      describe('when parent has only 1 pending children', async () => {
        it('moves parent to wait to try to process it', async () => {
          await queue.waitUntilReady();
          const parentQueueName = `test-${randomUUID()}`;
          const parentQueue = new Queue(parentQueueName, {
            connection,
            prefix,
          });
          await parentQueue.waitUntilReady();
          const name = 'child-job';

          const flow = new FlowProducer({ connection, prefix });
          await flow.add({
            name: 'parent-job',
            queueName: parentQueueName,
            data: {},
            children: [{ name, data: { idx: 0, foo: 'bar' }, queueName }],
          });

          const count = await queue.count();
          expect(count).toEqual(1);

          await queue.obliterate();

          const client = await getRedisClient(queue);
          const keys = await client.keys(`${prefix}:${queue.name}:*`);

          expect(keys.length).toEqual(0);

          const countAfterEmpty = await queue.count();
          expect(countAfterEmpty).toEqual(0);

          const failedCount = await queue.getJobCountByTypes('failed');
          expect(failedCount).toEqual(0);

          const parentWaitCount = await parentQueue.getJobCountByTypes('wait');
          expect(parentWaitCount).toEqual(1);
          await parentQueue.close();
          await flow.close();
          await removeAllQueueData(createTestConnection(), parentQueueName);
        });
      });
    });
  });

  it('should obliterate if queue has active jobs using "force"', async () => {
    await queue.waitUntilReady();

    await queue.add('test', { foo: 'bar' });
    const job = await queue.add('test', { qux: 'baz' });

    await queue.add('test', { foo: 'bar2' });
    await queue.add('test', { foo: 'bar3' }, { delay: 5000 });

    let first = true;
    const worker = new Worker(
      queue.name,
      async () => {
        if (first) {
          first = false;
          throw new Error('failed first');
        }
        return delay(250);
      },
      { connection, prefix },
    );
    await worker.waitUntilReady();

    await job.waitUntilFinished(queueEvents);
    await queue.obliterate({ force: true });
    const client = await getRedisClient(queue);
    const keys = await client.keys(`${prefix}:${queue.name}:*`);
    expect(keys.length).toEqual(0);

    await worker.close();
  });

  it('should remove job schedulers', async () => {
    await queue.waitUntilReady();

    await queue.upsertJobScheduler('test-scheduler', { every: 1000 });

    const jobSchedulers = await queue.getJobSchedulers();
    expect(jobSchedulers).toHaveLength(1);

    await queue.obliterate();
    const client = await getRedisClient(queue);
    const keys = await client.keys(`${prefix}:${queue.name}:*`);
    expect(keys.length).toEqual(0);
  });

  it('should obliterate a queue with high number of jobs in different statuses', async () => {
    // TODO: Move timeout to test options: { timeout: 6000 }
    const arr1: Promise<Job<any, any, string>>[] = [];
    for (let i = 0; i < 300; i++) {
      arr1.push(queue.add('test', { foo: `barLoop${i}` }));
    }

    const [lastCompletedJob] = (await Promise.all(arr1)).splice(-1);

    let fail = false;
    const worker = new Worker(
      queue.name,
      async job => {
        if (fail) {
          throw new Error('failed job');
        }
      },
      { connection, prefix },
    );
    await worker.waitUntilReady();

    await lastCompletedJob.waitUntilFinished(queueEvents);

    fail = true;

    const arr2: Promise<Job<any, any, string>>[] = [];
    for (let i = 0; i < 300; i++) {
      arr2.push(queue.add('test', { foo: `barLoop${i}` }));
    }

    const [lastFailedJob] = (await Promise.all(arr2)).splice(-1);

    await expect(lastFailedJob.waitUntilFinished(queueEvents)).rejects.toThrow(
      'failed job',
    );

    await worker.close();

    const arr3: Promise<Job<any, any, string>>[] = [];
    for (let i = 0; i < 1623; i++) {
      arr3.push(queue.add('test', { foo: `barLoop${i}` }, { delay: 10000 }));
    }
    await Promise.all(arr3);

    await queue.obliterate();
    const client = await getRedisClient(queue);
    const keys = await client.keys(`${prefix}:${queue.name}*`);
    expect(keys.length).toEqual(0);
  });
});
