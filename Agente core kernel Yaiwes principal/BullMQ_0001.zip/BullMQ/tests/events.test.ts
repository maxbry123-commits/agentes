import { getRedisClient } from './utils/get-redis-client';
import {
  describe,
  beforeEach,
  afterEach,
  beforeAll,
  afterAll,
  it,
  expect,
} from 'vitest';

import { after } from './utils/lodash';

import {
  FlowProducer,
  Queue,
  QueueEvents,
  QueueEventsListener,
  QueueEventsProducer,
  Worker,
} from '../src/classes';
import { delay, randomUUID } from '../src/utils';
import { createTestConnection } from './utils/connection-factory';
import { cleanupQueue } from './utils/cleanup-queue';
import { IRedisClient } from '../src/interfaces';

describe('events', () => {
  const prefix = process.env.BULLMQ_TEST_PREFIX || 'bull';

  // TODO: Move timeout to test options: { timeout: 8000 }
  let queue: Queue;
  let queueEvents: QueueEvents;
  let queueName: string;

  let connection: IRedisClient;
  beforeAll(async () => {
    connection = createTestConnection();
  });

  beforeEach(async () => {
    queueName = `test-${randomUUID()}`;
    queue = new Queue(queueName, { connection, prefix });
    queueEvents = new QueueEvents(queueName, {
      connection,
      prefix,
      blockingTimeout: 1000,
    });
    await queue.waitUntilReady();
    await queueEvents.waitUntilReady();
    await delay(50); // allow XREAD to start blocking before emitting events
  });

  afterEach(async () => {
    await queue.close();
    await queueEvents.close();
    await cleanupQueue(queueName);
  });

  afterAll(async function () {
    await connection.quit();
  });

  describe('when autorun option is provided as false', () => {
    it('emits waiting when a job has been added', async () => {
      const queueName2 = `test-${randomUUID()}`;
      const queue2 = new Queue(queueName2, { connection, prefix });
      const queueEvents2 = new QueueEvents(queueName2, {
        autorun: false,
        connection,
        prefix,
      });
      await queueEvents2.waitUntilReady();

      const waiting = new Promise(resolve => {
        queue2.on('waiting', resolve);
      });

      const running = queueEvents2.run();

      await queue2.add('test', { foo: 'bar' });

      await waiting;

      await queue2.close();
      await queueEvents2.close();
      await expect(running).resolves.toBeUndefined();
      await cleanupQueue(queueName2);
    });

    describe('when run method is called when queueEvent is running', () => {
      it('throws error', async () => {
        const queueName2 = `test-${randomUUID()}`;
        const queue2 = new Queue(queueName2, { connection, prefix });
        const queueEvents2 = new QueueEvents(queueName2, {
          autorun: false,
          connection,
          prefix,
        });
        await queueEvents2.waitUntilReady();

        const running = queueEvents2.run();

        await queue2.add('test', { foo: 'bar' });

        await expect(queueEvents2.run()).rejects.toThrow(
          'Queue Events is already running.',
        );

        await queue2.close();
        await queueEvents2.close();
        await expect(running).resolves.toBeUndefined();
        await cleanupQueue(queueName2);
      });
    });
  });

  it('should emit waiting when a job has been added', async () => {
    const waiting = new Promise<void>(resolve => {
      queue.on('waiting', job => {
        expect(job.id).toBeTypeOf('string');
        resolve();
      });
    });

    await queue.add('test', { foo: 'bar' });

    await waiting;
  });

  it('should emit global waiting event when a job has been added', async () => {
    await delay(100);
    const waiting = new Promise(resolve => {
      queueEvents.on('waiting', resolve);

      queue.add('test', { foo: 'bar' });
    });

    await waiting;
  });

  describe('when jobs are cleaned', () => {
    it('emits cleaned global event', async () => {
      const worker = new Worker(
        queueName,
        async () => {
          await delay(10);
        },
        {
          connection,
          prefix,
          autorun: false,
        },
      );
      const numJobs = 50;

      worker.on(
        'completed',
        after(numJobs, async function () {
          await delay(10);
          await queue.clean(0, 0, 'completed');
        }),
      );

      const cleaned = new Promise<void>((resolve, reject) => {
        queueEvents.once('cleaned', async ({ count }) => {
          try {
            expect(count).toEqual('50');
            resolve();
          } catch (error) {
            reject(error);
          }
        });
      });

      const jobs = Array.from(Array(numJobs).keys()).map(() => ({
        name: 'test',
        data: { foo: 'bar' },
      }));
      await queue.addBulk(jobs);

      worker.run();

      await cleaned;

      const actualCount = await queue.count();
      expect(actualCount).toBe(0);

      await worker.close();
    });
  });

  it('emits drained global event when all jobs have been processed', async () => {
    const worker = new Worker(queueName, async () => {}, {
      drainDelay: 1,
      connection,
      prefix,
    });

    const drained = new Promise<void>(resolve => {
      queueEvents.once('drained', id => {
        expect(id).toBeTypeOf('string');
        resolve();
      });
    });

    await queue.addBulk([
      { name: 'test', data: { foo: 'bar' } },
      { name: 'test', data: { foo: 'baz' } },
    ]);

    await drained;

    const jobs = await queue.getJobCountByTypes('completed');
    expect(jobs).toBeGreaterThanOrEqual(1);
    expect(jobs).toBeLessThanOrEqual(2);

    await worker.close();
  });

  describe('when concurrency is greater than 1', () => {
    it('emits drained global event when all jobs have been processed', async () => {
      const worker = new Worker(
        queueName,
        async () => {
          await delay(500);
        },
        {
          concurrency: 4,
          drainDelay: 500,
          connection,
          prefix,
        },
      );

      const drained = new Promise<void>(resolve => {
        queueEvents.once('drained', id => {
          expect(id).toBeTypeOf('string');
          resolve();
        });
      });

      await queue.addBulk([
        { name: 'test', data: { foo: 'bar' } },
        { name: 'test', data: { foo: 'baz' } },
        { name: 'test', data: { foo: 'bax' } },
        { name: 'test', data: { foo: 'bay' } },
      ]);

      await drained;

      const jobs = await queue.getJobCountByTypes('completed');
      expect(jobs).toBe(4);

      await worker.close();
    });
  });

  it('emits drained global event only once when worker is idle', async () => {
    const worker = new Worker(
      queueName,
      async () => {
        await delay(25);
      },
      {
        drainDelay: 1,
        connection,
        prefix,
      },
    );

    let counterDrainedEvents = 0;

    queueEvents.on('drained', () => {
      counterDrainedEvents++;
    });

    await queue.addBulk([
      { name: 'test', data: { foo: 'bar' } },
      { name: 'test', data: { foo: 'baz' } },
    ]);

    await delay(1000);

    await queue.addBulk([
      { name: 'test', data: { foo: 'bar' } },
      { name: 'test', data: { foo: 'baz' } },
    ]);

    await delay(2000);

    const jobs = await queue.getJobCountByTypes('completed');
    expect(jobs).toBe(4);
    expect(counterDrainedEvents).toBe(2);

    await worker.close();
  });

  it('emits drained event in worker when all jobs have been processed', async () => {
    const worker = new Worker(queueName, async () => {}, {
      drainDelay: 1,
      connection,
      prefix,
    });

    const drained = new Promise<void>(resolve => {
      worker.once('drained', () => {
        resolve();
      });
    });

    await queue.addBulk([
      { name: 'test', data: { foo: 'bar' } },
      { name: 'test', data: { foo: 'baz' } },
    ]);

    await drained;

    await delay(10);

    const jobs = await queue.getJobCountByTypes('completed');
    expect(jobs).toBe(2);

    await worker.close();
  });

  it('emits error event when there is an error on other events', async () => {
    const worker = new Worker(queueName, async () => {}, {
      drainDelay: 1,
      connection,
      prefix,
    });

    // Trigger error inside event handler (bar is undefined)
    worker.once('completed', (job: any) => {
      console.log(job.bar.id);
    });

    const error = new Promise<void>(resolve => {
      worker.once('error', () => {
        resolve();
      });
    });

    await queue.add('test', { foo: 'bar' });

    await error;

    const jobs = await queue.getJobCountByTypes('completed');
    expect(jobs).toBe(1);

    await worker.close();
  });

  describe('when one job is added', () => {
    it('emits added event', async () => {
      const worker = new Worker(
        queueName,
        async () => {
          await delay(100);
        },
        {
          drainDelay: 1,
          connection,
          prefix,
        },
      );
      await worker.waitUntilReady();
      const testName = 'test';

      const added = new Promise<void>(resolve => {
        queueEvents.once('added', ({ jobId, name }) => {
          expect(jobId).toBe('1');
          expect(name).toBe(testName);
          resolve();
        });

        queue.add(testName, { foo: 'bar' });
      });

      await added;

      await worker.close();
    });
  });

  describe('when job has been added again', () => {
    it('emits duplicated event', async () => {
      const testName = 'test';
      const worker = new Worker(
        queueName,
        async () => {
          await delay(50);
          await queue.add(testName, { foo: 'bar' }, { jobId: 'a1' });
          await delay(50);
        },
        { autorun: false, connection, prefix },
      );
      await worker.waitUntilReady();

      const completed = new Promise<void>(resolve => {
        worker.on('completed', async function () {
          resolve();
        });
      });

      await queue.add(testName, { foo: 'bar' }, { jobId: 'a1' });

      worker.run();

      await new Promise<void>(resolve => {
        queueEvents.once('duplicated', ({ jobId }) => {
          expect(jobId).toBe('a1');
          resolve();
        });
      });

      await completed;

      await worker.close();
    });
  });

  it('should emit an event when a job becomes active', async () => {
    const worker = new Worker(queueName, async job => {}, {
      connection,
      prefix,
    });

    await queue.add('test', {});

    const completed = new Promise<void>(resolve => {
      worker.once('active', function () {
        worker.once('completed', async function () {
          resolve();
        });
      });
    });

    await completed;
    await worker.close();
  });

  it('should emit an active event for every processed job', async () => {
    const numJobs = 20;

    let activeCount = 0;
    let completedCount = 0;

    const worker = new Worker(queueName, async () => {}, {
      connection,
      prefix,
    });

    worker.on('active', () => {
      activeCount++;
    });

    const completed = new Promise<void>((resolve, reject) => {
      worker.on('completed', () => {
        completedCount++;
        if (completedCount === numJobs) {
          resolve();
        }
      });
      worker.on('error', reject);
    });

    await queue.addBulk(
      Array.from({ length: numJobs }, (_, i) => ({
        name: 'test',
        data: { index: i },
      })),
    );

    await completed;

    // The active event must fire once per processed job, including jobs that
    // are fetched atomically when the previous job is moved to completed.
    expect(activeCount).toBe(numJobs);

    await worker.close();
  });

  describe('when one job is a parent', () => {
    it('emits waiting-children and waiting event', async () => {
      const worker = new Worker(queueName, async () => {}, {
        autorun: false,
        drainDelay: 1,
        connection,
        prefix,
      });
      const name = 'parent-job';
      const childrenQueueName = `children-queue-${randomUUID()}`;

      const childrenWorker = new Worker(
        childrenQueueName,
        async () => {
          await delay(150);
        },
        {
          autorun: false,
          drainDelay: 1,
          connection,
          prefix,
        },
      );
      const waitingChildren = new Promise<void>((resolve, reject) => {
        queueEvents.once('waiting-children', async ({ jobId }) => {
          try {
            const job = await queue.getJob(jobId);
            const state = await job?.getState();
            expect(state).toBe('waiting-children');
            expect(job?.name).toBe(name);
            resolve();
          } catch (err) {
            reject(err);
          }
        });
      });

      const waiting = new Promise<void>((resolve, reject) => {
        queueEvents.on('waiting', async ({ jobId, prev }) => {
          try {
            const job = await queue.getJob(jobId);
            expect(prev).toBe('waiting-children');
            if (job?.name === name) {
              resolve();
            }
          } catch (err) {
            reject(err);
          }
        });
      });

      const flow = new FlowProducer({ connection, prefix });
      await flow.add({
        name,
        queueName,
        data: {},
        children: [
          { name: 'test', data: { foo: 'bar' }, queueName: childrenQueueName },
        ],
      });
      worker.run();
      childrenWorker.run();

      await waitingChildren;
      await waiting;

      await worker.close();
      await childrenWorker.close();
      await flow.close();
      await cleanupQueue(childrenQueueName);
    });
  });

  it('should listen to global events', async () => {
    const worker = new Worker(queueName, async job => {}, {
      connection,
      prefix,
    });

    let state: string;
    queueEvents.on('waiting', function ({ jobId }) {
      expect(jobId).toBe('1');
      expect(state).toBeUndefined();
      state = 'waiting';
    });
    queueEvents.once('active', function ({ jobId, prev }) {
      expect(jobId).toBe('1');
      expect(prev).toBe('waiting');
      expect(state).toBe('waiting');
      state = 'active';
    });

    const completed = new Promise<void>(resolve => {
      queueEvents.once('completed', async function ({ jobId, returnvalue }) {
        expect(jobId).toBe('1');
        expect(returnvalue).toBeNull();
        expect(state).toBe('active');
        resolve();
      });
    });

    await queue.add('test', {});

    await completed;
    await worker.close();
  });

  it('emits completed global event with the deserialized return value', async () => {
    const worker = new Worker(queueName, async () => ({ result: 42 }), {
      connection,
      prefix,
    });

    const completed = new Promise<void>((resolve, reject) => {
      queueEvents.once<QueueEventsListener<{ result: number }>, 'completed'>(
        'completed',
        async function ({ jobId, returnvalue }) {
          try {
            expect(jobId).toBe('1');
            expect(returnvalue).toEqual({ result: 42 });
            resolve();
          } catch (err) {
            reject(err);
          }
        },
      );
    });

    await queue.add('test', {});

    await completed;
    await worker.close();
  });
});
