/* Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.flowable.engine.test.api.mgmt;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.flowable.common.engine.api.FlowableException;
import org.flowable.common.engine.api.FlowableIllegalArgumentException;
import org.flowable.common.engine.impl.interceptor.Command;
import org.flowable.common.engine.impl.interceptor.CommandContext;
import org.flowable.common.engine.impl.interceptor.CommandExecutor;
import org.flowable.engine.impl.test.PluggableFlowableTestCase;
import org.flowable.engine.impl.util.CommandContextUtil;
import org.flowable.engine.repository.ProcessDefinition;
import org.flowable.engine.runtime.ProcessInstance;
import org.flowable.engine.test.Deployment;
import org.flowable.job.api.BaseJobQuery;
import org.flowable.job.api.DeadLetterJobQuery;
import org.flowable.job.api.ExternalWorkerJob;
import org.flowable.job.api.ExternalWorkerJobQuery;
import org.flowable.job.api.HistoryJob;
import org.flowable.job.api.HistoryJobQuery;
import org.flowable.job.api.Job;
import org.flowable.job.api.JobInfo;
import org.flowable.job.api.JobQuery;
import org.flowable.job.api.SuspendedJobQuery;
import org.flowable.job.api.TimerJobQuery;
import org.flowable.job.service.HistoryJobService;
import org.flowable.job.service.JobService;
import org.flowable.job.service.JobServiceConfiguration;
import org.flowable.job.service.impl.DeadLetterJobQueryImpl;
import org.flowable.job.service.impl.ExternalWorkerJobQueryImpl;
import org.flowable.job.service.impl.HistoryJobQueryImpl;
import org.flowable.job.service.impl.SuspendedJobQueryImpl;
import org.flowable.job.service.impl.cmd.CancelJobsCmd;
import org.flowable.job.service.impl.persistence.entity.DeadLetterJobEntity;
import org.flowable.job.service.impl.persistence.entity.DeadLetterJobEntityManager;
import org.flowable.job.service.impl.persistence.entity.ExternalWorkerJobEntity;
import org.flowable.job.service.impl.persistence.entity.ExternalWorkerJobEntityManager;
import org.flowable.job.service.impl.persistence.entity.HistoryJobEntity;
import org.flowable.job.service.impl.persistence.entity.JobEntity;
import org.flowable.job.service.impl.persistence.entity.SuspendedJobEntity;
import org.flowable.job.service.impl.persistence.entity.SuspendedJobEntityManager;
import org.flowable.job.service.impl.persistence.entity.TimerJobEntity;
import org.flowable.job.service.impl.persistence.entity.TimerJobEntityManager;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * @author Joram Barrez
 * @author Falko Menge
 */
public class JobQueryTest extends PluggableFlowableTestCase {

    private static final long ONE_HOUR = 60L * 60L * 1000L;
    private static final long ONE_SECOND = 1000L;
    private static final String EXCEPTION_MESSAGE = "This is an exception thrown from scriptTask";
    private String deploymentId;
    private String messageId;
    private CommandExecutor commandExecutor;
    private JobEntity jobEntity;
    private Date testStartTime;
    private Date timerOneFireTime;
    private Date timerTwoFireTime;
    private Date timerThreeFireTime;
    private String processInstanceIdOne;
    private String processInstanceIdTwo;
    private String processInstanceIdThree;

    /**
     * Setup will create - 3 process instances, each with one timer, each firing at t1/t2/t3 + 1 hour (see process) - 1 message
     */
    @BeforeEach
    protected void setUp() throws Exception {

        this.commandExecutor = processEngineConfiguration.getCommandExecutor();

        deploymentId = repositoryService.createDeployment().addClasspathResource("org/flowable/engine/test/api/mgmt/timerOnTask.bpmn20.xml").deploy().getId();

        // Create proc inst that has timer that will fire on t1 + 1 hour
        Calendar startTime = Calendar.getInstance();
        startTime.set(Calendar.MILLISECOND, 0);

        Date t1 = startTime.getTime();
        processEngineConfiguration.getClock().setCurrentTime(t1);

        processInstanceIdOne = runtimeService.startProcessInstanceByKey("timerOnTask").getId();
        testStartTime = t1;
        timerOneFireTime = new Date(t1.getTime() + ONE_HOUR);

        // Create process instance that has timer that will fire on t2 + 1 hour
        startTime.add(Calendar.HOUR_OF_DAY, 1);
        Date t2 = startTime.getTime(); // t2 = t1 + 1 hour
        processEngineConfiguration.getClock().setCurrentTime(t2);
        processInstanceIdTwo = runtimeService.startProcessInstanceByKey("timerOnTask").getId();
        timerTwoFireTime = new Date(t2.getTime() + ONE_HOUR);

        // Create process instance that has timer that will fire on t3 + 1 hour
        startTime.add(Calendar.HOUR_OF_DAY, 1);
        Date t3 = startTime.getTime(); // t3 = t2 + 1 hour
        processEngineConfiguration.getClock().setCurrentTime(t3);
        processInstanceIdThree = runtimeService.startProcessInstanceByKey("timerOnTask").getId();
        timerThreeFireTime = new Date(t3.getTime() + ONE_HOUR);

        // Create one message
        messageId = commandExecutor.execute(new Command<>() {

            @Override
            public String execute(CommandContext commandContext) {
                JobService jobService = CommandContextUtil.getJobService(commandContext);
                JobEntity message = jobService.createJob();
                message.setJobType(Job.JOB_TYPE_MESSAGE);
                message.setRetries(3);
                jobService.scheduleAsyncJob(message);
                return message.getId();
            }
        });
    }

    @AfterEach
    protected void tearDown() throws Exception {
        repositoryService.deleteDeployment(deploymentId, true);
        commandExecutor.execute(new CancelJobsCmd(messageId, processEngineConfiguration.getJobServiceConfiguration()));
    }

    @Test
    public void testQueryByNoCriteria() {
        JobQuery query = managementService.createJobQuery();
        verifyQueryResults(query, 1);

        TimerJobQuery timerQuery = managementService.createTimerJobQuery();
        verifyQueryResults(timerQuery, 3);
    }

    @Test
    public void testQueryByIds() {
        List<String> jobIds = new ArrayList<>();

        managementService.createJobQuery().list().forEach(job -> jobIds.add(job.getId()));
        JobQuery query = managementService.createJobQuery().jobIds(jobIds);
        verifyQueryResults(query, jobIds.size());

        jobIds.clear();
        managementService.createTimerJobQuery().list().forEach(job -> jobIds.add(job.getId()));
        TimerJobQuery timerQuery = managementService.createTimerJobQuery().jobIds(jobIds);
        verifyQueryResults(timerQuery, jobIds.size());

        query = managementService.createJobQuery().jobIds(new ArrayList<>());
        verifyQueryResults(query, 1);
        timerQuery = managementService.createTimerJobQuery().jobIds(new ArrayList<>());
        verifyQueryResults(timerQuery, 3);

        query = managementService.createJobQuery().jobIds(new ArrayList<>());
        verifyQueryResults(query, (int) managementService.createJobQuery().count());

        timerQuery = managementService.createTimerJobQuery().jobIds(new ArrayList<>());
        verifyQueryResults(timerQuery, (int) managementService.createTimerJobQuery().count());

        ExternalWorkerJobQuery externalWorkerQuery = managementService.createExternalWorkerJobQuery().jobIds(new ArrayList<>());
        verifyQueryResults(externalWorkerQuery, (int) managementService.createExternalWorkerJobQuery().count());

        SuspendedJobQuery suspendedJobQuery = managementService.createSuspendedJobQuery().jobIds(new ArrayList<>());
        verifyQueryResults(suspendedJobQuery, (int) managementService.createSuspendedJobQuery().count());
    }

    @Test
    public void testQueryByNoCriteriaWithPaging() {
        List<Job> jobs = managementService.createJobQuery().listPage(1, 2);
        assertThat(jobs).isEmpty();

        List<Job> timerJobs = managementService.createTimerJobQuery().listPage(1, 2);
        assertThat(timerJobs).hasSize(2);
    }

    @Test
    public void testQueryByProcessInstanceId() {
        TimerJobQuery query = managementService.createTimerJobQuery().processInstanceId(processInstanceIdOne);
        verifyQueryResults(query, 1);
    }

    @Test
    public void testQueryByInvalidProcessInstanceId() {
        TimerJobQuery query = managementService.createTimerJobQuery().processInstanceId("invalid");
        verifyQueryResults(query, 0);

        assertThatThrownBy(() -> managementService.createJobQuery().processInstanceId(null))
                .isExactlyInstanceOf(FlowableIllegalArgumentException.class);
    }

    @Test
    public void testTimerQueryWithoutProcessInstanceId() {
        TimerJobQuery query = managementService.createTimerJobQuery().withoutProcessInstanceId();
        verifyQueryResults(query, 0);
    }

    @Test
    public void testJobQueryWithoutProcessInstanceId() {
        JobQuery query = managementService.createJobQuery().withoutProcessInstanceId();
        verifyQueryResults(query, 1);

        assertThat(query.singleResult().getId()).isEqualTo(messageId);
    }

    @Test
    public void testQueryByExecutionId() {
        Job job = managementService.createTimerJobQuery().processInstanceId(processInstanceIdOne).singleResult();
        TimerJobQuery query = managementService.createTimerJobQuery().executionId(job.getExecutionId());
        assertThat(job.getId()).isEqualTo(query.singleResult().getId());
        verifyQueryResults(query, 1);
    }

    @Test
    public void testQueryByInvalidExecutionId() {
        JobQuery query = managementService.createJobQuery().executionId("invalid");
        verifyQueryResults(query, 0);

        TimerJobQuery timerQuery = managementService.createTimerJobQuery().executionId("invalid");
        verifyQueryResults(timerQuery, 0);

        assertThatThrownBy(() -> managementService.createJobQuery().executionId(null).list())
                .isExactlyInstanceOf(FlowableIllegalArgumentException.class);

        assertThatThrownBy(() -> managementService.createTimerJobQuery().executionId(null).list())
                .isExactlyInstanceOf(FlowableIllegalArgumentException.class);
    }

    @Test
    public void testQueryByElementId() {
        TimerJobQuery query = managementService.createTimerJobQuery().elementId("escalationTimer");
        verifyQueryResults(query, 3);
    }

    @Test
    public void testQueryByInvalidElementId() {
        TimerJobQuery query = managementService.createTimerJobQuery().elementId("unknown");
        verifyQueryResults(query, 0);
    }

    @Test
    public void testQueryByElementName() {
        TimerJobQuery query = managementService.createTimerJobQuery().elementName("Escalation");
        verifyQueryResults(query, 3);
    }

    @Test
    public void testQueryByInvalidElementName() {
        TimerJobQuery query = managementService.createTimerJobQuery().elementName("unknown");
        verifyQueryResults(query, 0);
    }

    @Test
    public void testQueryByHandlerType() {
        final JobEntity job = (JobEntity) managementService.createJobQuery().singleResult();
        job.setJobHandlerType("test");
        managementService.executeCommand(new Command<Void>() {

            @Override
            public Void execute(CommandContext commandContext) {
                JobService jobService = CommandContextUtil.getJobService(commandContext);
                jobService.updateJob(job);
                return null;
            }

        });

        Job handlerTypeJob = managementService.createJobQuery().handlerType("test").singleResult();
        assertThat(handlerTypeJob).isNotNull();
    }

    @Test
    public void testDeadLetterJobQueryByType() {
        assertThat(managementService.createDeadLetterJobQuery().count()).isEqualTo(0);

        createDeadLetterJobWithType(Job.JOB_TYPE_MESSAGE);
        assertThat(managementService.createDeadLetterJobQuery().count()).isEqualTo(1);
        assertThat(managementService.createDeadLetterJobQuery().messages().count()).isEqualTo(1);
        assertThat(managementService.createDeadLetterJobQuery().timers().count()).isEqualTo(0);
        assertThat(managementService.createDeadLetterJobQuery().externalWorkers().count()).isEqualTo(0);

        createDeadLetterJobWithType(Job.JOB_TYPE_TIMER);
        assertThat(managementService.createDeadLetterJobQuery().count()).isEqualTo(2);
        assertThat(managementService.createDeadLetterJobQuery().messages().count()).isEqualTo(1);
        assertThat(managementService.createDeadLetterJobQuery().timers().count()).isEqualTo(1);
        assertThat(managementService.createDeadLetterJobQuery().externalWorkers().count()).isEqualTo(0);

        createDeadLetterJobWithType(Job.JOB_TYPE_EXTERNAL_WORKER);
        assertThat(managementService.createDeadLetterJobQuery().count()).isEqualTo(3);
        assertThat(managementService.createDeadLetterJobQuery().messages().count()).isEqualTo(1);
        assertThat(managementService.createDeadLetterJobQuery().timers().count()).isEqualTo(1);
        assertThat(managementService.createDeadLetterJobQuery().externalWorkers().count()).isEqualTo(1);

        managementService.deleteDeadLetterJob(managementService.createDeadLetterJobQuery().messages().singleResult().getId());
        managementService.deleteDeadLetterJob(managementService.createDeadLetterJobQuery().timers().singleResult().getId());
        managementService.deleteDeadLetterJob(managementService.createDeadLetterJobQuery().externalWorkers().singleResult().getId());
        assertThat(managementService.createDeadLetterJobQuery().count()).isEqualTo(0);
    }

    @Test
    public void testQueryByHandlerTypes() {

        List<String> testTypes = new ArrayList<>();
        createJobWithHandlerType("Type1");
        createJobWithHandlerType("Type2");

        assertThat(managementService.createJobQuery().handlerType("Type1").singleResult()).isNotNull();
        assertThat(managementService.createJobQuery().handlerType("Type2").singleResult()).isNotNull();

        testTypes.add("TestType");
        assertThat(managementService.createJobQuery().handlerTypes(testTypes).singleResult()).isNull();

        testTypes.add("Type1");
        assertThat(managementService.createJobQuery().handlerTypes(testTypes).count()).isEqualTo(1);
        assertThat(managementService.createJobQuery().handlerTypes(testTypes).singleResult().getJobHandlerType()).isEqualTo("Type1");

        testTypes.add("Type2");
        assertThat(managementService.createJobQuery().handlerTypes(testTypes).count()).isEqualTo(2);

        assertThat(managementService.createJobQuery().handlerTypes(testTypes).list())
                .extracting(JobInfo::getJobHandlerType)
                .containsExactlyInAnyOrder("Type1", "Type2");

        managementService.deleteJob(managementService.createJobQuery().handlerType("Type1").singleResult().getId());
        managementService.deleteJob(managementService.createJobQuery().handlerType("Type2").singleResult().getId());
    }

    @Test
    public void testQueryByScopeIdsAndElementIds() {
        // scope1/element1 = content agent job, scope2/element2 = tree agent job, null scope = classify job (elementId only)
        JobEntity job1 = createJobWithScope("agent", "scope1", "element1");
        JobEntity job2 = createJobWithScope("agent", "scope2", "element2");
        JobEntity classifyJob = createJobWithScope("agent", null, "element3");

        // scopeIds
        assertThat(managementService.createJobQuery().scopeIds(List.of("scope1", "scope2")).count()).isEqualTo(2);
        assertThat(managementService.createJobQuery().scopeIds(List.of("scope1")).count()).isEqualTo(1);
        assertThat(managementService.createJobQuery().scopeIds(List.of("unknown")).count()).isZero();

        // elementIds
        assertThat(managementService.createJobQuery().elementIds(List.of("element1", "element2", "element3")).count()).isEqualTo(3);
        assertThat(managementService.createJobQuery().elementIds(List.of("element1")).count()).isEqualTo(1);
        assertThat(managementService.createJobQuery().elementIds(List.of("unknown")).count()).isZero();

        // scopeIds OR elementIds: job1 matches by scope, job2 + classifyJob match by element
        assertThat(managementService.createJobQuery().or()
                .scopeIds(List.of("scope1"))
                .elementIds(List.of("element2", "element3"))
                .endOr().list())
                .extracting(Job::getId)
                .containsExactlyInAnyOrder(job1.getId(), job2.getId(), classifyJob.getId());

        // the AgentJobResolver shape: scopeType = agent AND (scopeId IN ... OR elementId IN ...)
        assertThat(managementService.createJobQuery()
                .scopeType("agent")
                .or()
                    .scopeIds(List.of("scope1", "scope2"))
                    .elementIds(List.of("element3"))
                .endOr()
                .list())
                .extracting(Job::getId)
                .containsExactlyInAnyOrder(job1.getId(), job2.getId(), classifyJob.getId());

        // that same AND narrows the scope type: no jobs for a different scope type
        assertThat(managementService.createJobQuery()
                .scopeType("other")
                .or()
                    .scopeIds(List.of("scope1", "scope2"))
                    .elementIds(List.of("element3"))
                .endOr()
                .count()).isZero();

        // empty collections are ignored (the filter is not applied)
        assertThat(managementService.createJobQuery().scopeIds(new ArrayList<>()).count())
                .isEqualTo(managementService.createJobQuery().count());
        assertThat(managementService.createJobQuery().elementIds(new ArrayList<>()).count())
                .isEqualTo(managementService.createJobQuery().count());

        // null throws
        assertThatThrownBy(() -> managementService.createJobQuery().scopeIds(null))
                .isExactlyInstanceOf(FlowableIllegalArgumentException.class);
        assertThatThrownBy(() -> managementService.createJobQuery().elementIds(null))
                .isExactlyInstanceOf(FlowableIllegalArgumentException.class);

        managementService.deleteJob(job1.getId());
        managementService.deleteJob(job2.getId());
        managementService.deleteJob(classifyJob.getId());
    }

    @Test
    public void testTimerQueryByElementIds() {
        TimerJobQuery query = managementService.createTimerJobQuery().elementIds(List.of("escalationTimer", "unknown"));
        verifyQueryResults(query, 3);

        query = managementService.createTimerJobQuery().elementIds(List.of("unknown"));
        verifyQueryResults(query, 0);

        // empty collection is ignored (the filter is not applied)
        query = managementService.createTimerJobQuery().elementIds(new ArrayList<>());
        verifyQueryResults(query, 3);

        assertThatThrownBy(() -> managementService.createTimerJobQuery().elementIds(null))
                .isExactlyInstanceOf(FlowableIllegalArgumentException.class);
    }

    @Test
    public void testTimerJobQueryByScopeIds() {
        // covers the SCOPE_ID_ block of TimerJob.xml, which the elementIds test does not exercise
        TimerJobEntity job1 = createTimerJobWithScope("agent", "scope1", "element1");
        TimerJobEntity job2 = createTimerJobWithScope("agent", null, "element2");

        assertThat(managementService.createTimerJobQuery().scopeIds(List.of("scope1")).count()).isEqualTo(1);
        assertThat(managementService.createTimerJobQuery().scopeIds(List.of("scope1", "scope2")).count()).isEqualTo(1);
        assertThat(managementService.createTimerJobQuery().scopeIds(List.of("unknown")).count()).isZero();

        // scopeIds OR elementIds inside an or()
        assertThat(managementService.createTimerJobQuery().or()
                .scopeIds(List.of("scope1"))
                .elementIds(List.of("element2"))
                .endOr().list())
                .extracting(Job::getId)
                .containsExactlyInAnyOrder(job1.getId(), job2.getId());

        // empty collection is ignored (the filter is not applied)
        assertThat(managementService.createTimerJobQuery().scopeIds(new ArrayList<>()).count())
                .isEqualTo(managementService.createTimerJobQuery().count());

        assertThatThrownBy(() -> managementService.createTimerJobQuery().scopeIds(null))
                .isExactlyInstanceOf(FlowableIllegalArgumentException.class);

        managementService.executeCommand(commandContext -> {
            JobServiceConfiguration jobServiceConfiguration = CommandContextUtil.getProcessEngineConfiguration(commandContext).getJobServiceConfiguration();
            TimerJobEntityManager timerJobEntityManager = jobServiceConfiguration.getTimerJobEntityManager();
            timerJobEntityManager.delete(job1.getId());
            timerJobEntityManager.delete(job2.getId());
            return null;
        });
    }

    @Test
    public void testSuspendedJobQueryByScopeIdsAndElementIds() {
        SuspendedJobEntity job1 = createSuspendedJobWithScope("agent", "scope1", "element1");
        SuspendedJobEntity job2 = createSuspendedJobWithScope("agent", null, "element2");

        assertThat(managementService.createSuspendedJobQuery().scopeIds(List.of("scope1")).count()).isEqualTo(1);
        assertThat(managementService.createSuspendedJobQuery().elementIds(List.of("element1", "element2")).count()).isEqualTo(2);
        assertThat(managementService.createSuspendedJobQuery().scopeIds(List.of("unknown")).count()).isZero();

        // scopeIds OR elementIds inside an or()
        assertThat(managementService.createSuspendedJobQuery().or()
                .scopeIds(List.of("scope1"))
                .elementIds(List.of("element2"))
                .endOr().list())
                .extracting(Job::getId)
                .containsExactlyInAnyOrder(job1.getId(), job2.getId());

        // empty collections are ignored
        assertThat(managementService.createSuspendedJobQuery().scopeIds(new ArrayList<>()).count())
                .isEqualTo(managementService.createSuspendedJobQuery().count());

        assertThatThrownBy(() -> managementService.createSuspendedJobQuery().scopeIds(null))
                .isExactlyInstanceOf(FlowableIllegalArgumentException.class);
        assertThatThrownBy(() -> managementService.createSuspendedJobQuery().elementIds(null))
                .isExactlyInstanceOf(FlowableIllegalArgumentException.class);

        managementService.executeCommand(commandContext -> {
            JobServiceConfiguration jobServiceConfiguration = CommandContextUtil.getProcessEngineConfiguration(commandContext).getJobServiceConfiguration();
            SuspendedJobEntityManager suspendedJobEntityManager = jobServiceConfiguration.getSuspendedJobEntityManager();
            suspendedJobEntityManager.delete(job1.getId());
            suspendedJobEntityManager.delete(job2.getId());
            return null;
        });
    }

    @Test
    public void testDeadLetterJobQueryByScopeIdsAndElementIds() {
        DeadLetterJobEntity job1 = createDeadLetterJobWithScope("agent", "scope1", "element1");
        DeadLetterJobEntity job2 = createDeadLetterJobWithScope("agent", null, "element2");

        assertThat(managementService.createDeadLetterJobQuery().scopeIds(List.of("scope1")).count()).isEqualTo(1);
        assertThat(managementService.createDeadLetterJobQuery().elementIds(List.of("element1", "element2")).count()).isEqualTo(2);
        assertThat(managementService.createDeadLetterJobQuery().scopeIds(List.of("unknown")).count()).isZero();

        // scopeIds OR elementIds inside an or()
        assertThat(managementService.createDeadLetterJobQuery().or()
                .scopeIds(List.of("scope1"))
                .elementIds(List.of("element2"))
                .endOr().list())
                .extracting(Job::getId)
                .containsExactlyInAnyOrder(job1.getId(), job2.getId());

        // empty collections are ignored
        assertThat(managementService.createDeadLetterJobQuery().elementIds(new ArrayList<>()).count())
                .isEqualTo(managementService.createDeadLetterJobQuery().count());

        assertThatThrownBy(() -> managementService.createDeadLetterJobQuery().scopeIds(null))
                .isExactlyInstanceOf(FlowableIllegalArgumentException.class);
        assertThatThrownBy(() -> managementService.createDeadLetterJobQuery().elementIds(null))
                .isExactlyInstanceOf(FlowableIllegalArgumentException.class);

        managementService.deleteDeadLetterJob(job1.getId());
        managementService.deleteDeadLetterJob(job2.getId());
    }

    @Test
    public void testSuspendedJobQueryByType() {
        String handlerType = "testSuspendedJobType";
        assertThat(managementService.createSuspendedJobQuery().handlerType(handlerType).count()).isEqualTo(0);

        createSuspendedJobWithType(Job.JOB_TYPE_MESSAGE, handlerType);
        assertThat(managementService.createSuspendedJobQuery().handlerType(handlerType).count()).isEqualTo(1);
        assertThat(managementService.createSuspendedJobQuery().handlerType(handlerType).messages().count()).isEqualTo(1);
        assertThat(managementService.createSuspendedJobQuery().handlerType(handlerType).timers().count()).isEqualTo(0);
        assertThat(managementService.createSuspendedJobQuery().handlerType(handlerType).externalWorkers().count()).isEqualTo(0);

        createSuspendedJobWithType(Job.JOB_TYPE_TIMER, handlerType);
        assertThat(managementService.createSuspendedJobQuery().handlerType(handlerType).count()).isEqualTo(2);
        assertThat(managementService.createSuspendedJobQuery().handlerType(handlerType).messages().count()).isEqualTo(1);
        assertThat(managementService.createSuspendedJobQuery().handlerType(handlerType).timers().count()).isEqualTo(1);
        assertThat(managementService.createSuspendedJobQuery().handlerType(handlerType).externalWorkers().count()).isEqualTo(0);

        createSuspendedJobWithType(Job.JOB_TYPE_EXTERNAL_WORKER, handlerType);
        assertThat(managementService.createSuspendedJobQuery().handlerType(handlerType).count()).isEqualTo(3);
        assertThat(managementService.createSuspendedJobQuery().handlerType(handlerType).messages().count()).isEqualTo(1);
        assertThat(managementService.createSuspendedJobQuery().handlerType(handlerType).timers().count()).isEqualTo(1);
        assertThat(managementService.createSuspendedJobQuery().handlerType(handlerType).externalWorkers().count()).isEqualTo(1);

        managementService.deleteSuspendedJob(managementService.createSuspendedJobQuery().handlerType(handlerType).messages().singleResult().getId());
        managementService.deleteSuspendedJob(managementService.createSuspendedJobQuery().handlerType(handlerType).timers().singleResult().getId());
        managementService.deleteSuspendedJob(managementService.createSuspendedJobQuery().handlerType(handlerType).externalWorkers().singleResult().getId());
        assertThat(managementService.createSuspendedJobQuery().handlerType(handlerType).count()).isEqualTo(0);
    }

    @Test
    public void testSuspendedJobQueryByHandlerTypes() {

        List<String> testTypes = new ArrayList<>();
        createSuspendedJobWithHandlerType("Type1");
        createSuspendedJobWithHandlerType("Type2");

        assertThat(managementService.createSuspendedJobQuery().handlerType("Type1").singleResult()).isNotNull();
        assertThat(managementService.createSuspendedJobQuery().handlerType("Type2").singleResult()).isNotNull();

        testTypes.add("TestType");
        assertThat(managementService.createSuspendedJobQuery().handlerTypes(testTypes).singleResult()).isNull();

        testTypes.add("Type1");
        assertThat(managementService.createSuspendedJobQuery().handlerTypes(testTypes).count()).isEqualTo(1);
        assertThat(managementService.createSuspendedJobQuery().handlerTypes(testTypes).singleResult().getJobHandlerType()).isEqualTo("Type1");

        testTypes.add("Type2");
        assertThat(managementService.createSuspendedJobQuery().handlerTypes(testTypes).count()).isEqualTo(2);
        assertThat(managementService.createSuspendedJobQuery().handlerTypes(testTypes).list())
                .extracting(JobInfo::getJobHandlerType)
                .containsExactlyInAnyOrder("Type1", "Type2");

        managementService.deleteSuspendedJob(managementService.createSuspendedJobQuery().handlerType("Type1").singleResult().getId());
        managementService.deleteSuspendedJob(managementService.createSuspendedJobQuery().handlerType("Type2").singleResult().getId());
    }

    @Test
    public void testDeadletterQueryByHandlerTypes() {

        List<String> testTypes = new ArrayList<>();
        createDeadLetterJobWithHandlerType("Type1");
        createDeadLetterJobWithHandlerType("Type2");

        assertThat(managementService.createDeadLetterJobQuery().handlerType("Type1").singleResult()).isNotNull();
        assertThat(managementService.createDeadLetterJobQuery().handlerType("Type2").singleResult()).isNotNull();

        testTypes.add("TestType");
        assertThat(managementService.createDeadLetterJobQuery().handlerTypes(testTypes).singleResult()).isNull();

        testTypes.add("Type1");
        assertThat(managementService.createDeadLetterJobQuery().handlerTypes(testTypes).count()).isEqualTo(1);
        assertThat(managementService.createDeadLetterJobQuery().handlerTypes(testTypes).singleResult().getJobHandlerType()).isEqualTo("Type1");

        testTypes.add("Type2");
        assertThat(managementService.createDeadLetterJobQuery().handlerTypes(testTypes).count()).isEqualTo(2);

        assertThat(managementService.createDeadLetterJobQuery().handlerTypes(testTypes).list())
                .extracting(JobInfo::getJobHandlerType)
                .containsExactlyInAnyOrder("Type1", "Type2");

        managementService.deleteDeadLetterJob(managementService.createDeadLetterJobQuery().handlerType("Type1").singleResult().getId());
        managementService.deleteDeadLetterJob(managementService.createDeadLetterJobQuery().handlerType("Type2").singleResult().getId());
    }

    @Test
    public void testHistoryJobQueryByHandlerTypes() {

        List<String> testTypes = new ArrayList<>();
        createHistoryJobWithHandlerType("Type1");
        createHistoryJobWithHandlerType("Type2");

        assertThat(managementService.createHistoryJobQuery().handlerType("Type1").singleResult()).isNotNull();
        assertThat(managementService.createHistoryJobQuery().handlerType("Type2").singleResult()).isNotNull();

        testTypes.add("TestType");
        assertThat(managementService.createHistoryJobQuery().handlerTypes(testTypes).singleResult()).isNull();

        testTypes.add("Type1");
        assertThat(managementService.createHistoryJobQuery().handlerTypes(testTypes).count()).isEqualTo(1);
        assertThat(managementService.createHistoryJobQuery().handlerTypes(testTypes).singleResult().getJobHandlerType()).isEqualTo("Type1");

        testTypes.add("Type2");
        assertThat(managementService.createHistoryJobQuery().handlerTypes(testTypes).count()).isEqualTo(2);
        assertThat(managementService.createHistoryJobQuery().handlerTypes(testTypes).list())
                .extracting(JobInfo::getJobHandlerType)
                .containsExactlyInAnyOrder("Type1", "Type2");

        managementService.deleteHistoryJob(managementService.createHistoryJobQuery().handlerType("Type1").singleResult().getId());
        managementService.deleteHistoryJob(managementService.createHistoryJobQuery().handlerType("Type2").singleResult().getId());
    }

    @Test
    public void testQueryByCorrelationId() {
        Job messageJob = managementService.createJobQuery().jobId(messageId).singleResult();
        assertThat(messageJob).isNotNull();

        Job job = managementService.createJobQuery().correlationId(messageJob.getCorrelationId()).singleResult();
        assertThat(job).isNotNull();
        assertThat(job.getId()).isEqualTo(messageId);
        assertThat(job.getCorrelationId()).isEqualTo(messageJob.getCorrelationId());
        assertThat(managementService.createJobQuery().correlationId(job.getCorrelationId()).list()).hasSize(1);
        assertThat(managementService.createJobQuery().correlationId(job.getCorrelationId()).count()).isEqualTo(1);
    }

    @Test
    public void testByInvalidCorrelationId() {
        assertThat(managementService.createJobQuery().correlationId("invalid").singleResult()).isNull();
        assertThat(managementService.createJobQuery().correlationId("invalid").list()).isEmpty();
        assertThat(managementService.createJobQuery().correlationId("invalid").count()).isZero();
    }

    @Test
    public void testQueryByInvalidJobType() {
        JobQuery query = managementService.createJobQuery().handlerType("invalid");
        verifyQueryResults(query, 0);

        TimerJobQuery timerQuery = managementService.createTimerJobQuery().executionId("invalid");
        verifyQueryResults(timerQuery, 0);

        assertThatThrownBy(() -> managementService.createJobQuery().executionId(null).list())
                .isExactlyInstanceOf(FlowableIllegalArgumentException.class);

        assertThatThrownBy(() -> managementService.createTimerJobQuery().executionId(null).list())
                .isExactlyInstanceOf(FlowableIllegalArgumentException.class);
    }

    @Test
    public void testQueryByRetriesLeft() {
        JobQuery query = managementService.createJobQuery();
        verifyQueryResults(query, 1);

        TimerJobQuery timerQuery = managementService.createTimerJobQuery();
        verifyQueryResults(timerQuery, 3);

        final Job job = managementService.createTimerJobQuery().processInstanceId(processInstanceIdOne).singleResult();
        managementService.setTimerJobRetries(job.getId(), 0);
        managementService.moveJobToDeadLetterJob(job.getId());

        // Re-running the query should give only 3 jobs now, since one job has retries=0
        verifyQueryResults(query, 1);
        verifyQueryResults(timerQuery, 2);
    }

    @Test
    public void testQueryByExecutable() {
        processEngineConfiguration.getClock()
                .setCurrentTime(new Date(timerThreeFireTime.getTime() + ONE_SECOND)); // all obs should be executable at t3 + 1hour.1second
        JobQuery query = managementService.createJobQuery();
        verifyQueryResults(query, 1);

        TimerJobQuery timerQuery = managementService.createTimerJobQuery().executable();
        verifyQueryResults(timerQuery, 3);

        // Setting retries of one job to 0, makes it non-executable
        final Job job = managementService.createTimerJobQuery().processInstanceId(processInstanceIdOne).singleResult();
        managementService.setTimerJobRetries(job.getId(), 0);
        managementService.moveJobToDeadLetterJob(job.getId());

        verifyQueryResults(query, 1);
        verifyQueryResults(timerQuery, 2);

        // Setting the clock before the start of the process instance, makes
        // none of the timer jobs executable
        processEngineConfiguration.getClock().setCurrentTime(testStartTime);
        verifyQueryResults(query, 1);
        verifyQueryResults(timerQuery, 0);

        // Moving the job back to be executable
        managementService.moveDeadLetterJobToExecutableJob(job.getId(), 5);
        verifyQueryResults(query, 2);
        verifyQueryResults(timerQuery, 0);
    }

    @Test
    public void testQueryByOnlyTimers() {
        JobQuery query = managementService.createJobQuery().timers();
        verifyQueryResults(query, 0);

        TimerJobQuery timerQuery = managementService.createTimerJobQuery().timers();
        verifyQueryResults(timerQuery, 3);
    }

    @Test
    public void testQueryByOnlyMessages() {
        JobQuery query = managementService.createJobQuery().messages();
        verifyQueryResults(query, 1);
    }

    @Test
    public void testInvalidOnlyTimersUsage() {
        assertThatThrownBy(() -> managementService.createJobQuery().timers().messages().list())
                .isExactlyInstanceOf(FlowableIllegalArgumentException.class)
                .hasMessage("Cannot combine onlyTimers() with onlyMessages() in the same query");
    }

    @Test
    public void testQueryByDuedateLowerThan() {
        JobQuery query = managementService.createJobQuery().duedateLowerThan(testStartTime);
        verifyQueryResults(query, 0);

        TimerJobQuery timerQuery = managementService.createTimerJobQuery().duedateLowerThan(testStartTime);
        verifyQueryResults(timerQuery, 0);

        timerQuery = managementService.createTimerJobQuery().duedateLowerThan(new Date(timerOneFireTime.getTime() + ONE_SECOND));
        verifyQueryResults(timerQuery, 1);

        timerQuery = managementService.createTimerJobQuery().duedateLowerThan(new Date(timerTwoFireTime.getTime() + ONE_SECOND));
        verifyQueryResults(timerQuery, 2);

        timerQuery = managementService.createTimerJobQuery().duedateLowerThan(new Date(timerThreeFireTime.getTime() + ONE_SECOND));
        verifyQueryResults(timerQuery, 3);
    }

    @Test
    public void testQueryByDuedateHigherThan() {
        JobQuery query = managementService.createJobQuery().duedateHigherThan(testStartTime);
        verifyQueryResults(query, 0);

        query = managementService.createJobQuery();
        verifyQueryResults(query, 1);

        TimerJobQuery timerQuery = managementService.createTimerJobQuery().duedateHigherThan(testStartTime);
        verifyQueryResults(timerQuery, 3);

        query = managementService.createJobQuery().duedateHigherThan(timerOneFireTime);
        verifyQueryResults(query, 0);

        timerQuery = managementService.createTimerJobQuery().duedateHigherThan(timerOneFireTime);
        verifyQueryResults(timerQuery, 2);

        timerQuery = managementService.createTimerJobQuery().duedateHigherThan(timerTwoFireTime);
        verifyQueryResults(timerQuery, 1);

        timerQuery = managementService.createTimerJobQuery().duedateHigherThan(timerThreeFireTime);
        verifyQueryResults(timerQuery, 0);
    }

    @Test
    @Deployment(resources = { "org/flowable/engine/test/api/mgmt/ManagementServiceTest.testGetJobExceptionStacktrace.bpmn20.xml" })
    public void testQueryByException() {
        TimerJobQuery query = managementService.createTimerJobQuery().withException();
        verifyQueryResults(query, 0);

        ProcessInstance processInstance = startProcessInstanceWithFailingJob();

        query = managementService.createTimerJobQuery().processInstanceId(processInstance.getId()).withException();
        verifyFailedJob(query, processInstance);
    }

    @Test
    @Deployment(resources = { "org/flowable/engine/test/api/mgmt/ManagementServiceTest.testGetJobExceptionStacktrace.bpmn20.xml" })
    public void testQueryByExceptionMessage() {
        ProcessDefinition processDefinition = repositoryService.createProcessDefinitionQuery().processDefinitionKey("exceptionInJobExecution").singleResult();
        TimerJobQuery query = managementService.createTimerJobQuery().exceptionMessage("This is an exception thrown from scriptTask");
        verifyQueryResults(query, 0);

        String exceptionMessage = "groovy script evaluation failed: 'javax.script.ScriptException: java.lang.RuntimeException: "
                + "This is an exception thrown from scriptTask' "
                + "Trace: scopeType=bpmn, scopeDefinitionKey=exceptionInJobExecution, scopeDefinitionId="+processDefinition.getId()+","
                + " subScopeDefinitionKey=theScriptTask, tenantId=<empty>, type=scriptTask";
        ProcessInstance processInstance = startProcessInstanceWithFailingJob();
        query = managementService.createTimerJobQuery().exceptionMessage(exceptionMessage);
        verifyFailedJob(query, processInstance);
    }

    @Test
    @Deployment(resources = { "org/flowable/engine/test/api/mgmt/ManagementServiceTest.testGetJobExceptionStacktrace.bpmn20.xml" })
    public void testQueryByExceptionMessageEmpty() {
        JobQuery query = managementService.createJobQuery().exceptionMessage("");
        verifyQueryResults(query, 0);

        startProcessInstanceWithFailingJob();

        query = managementService.createJobQuery().exceptionMessage("");
        verifyQueryResults(query, 0);
    }

    @Test
    public void testQueryByExceptionMessageNull() {
        assertThatThrownBy(() -> managementService.createJobQuery().exceptionMessage(null))
                .isExactlyInstanceOf(FlowableIllegalArgumentException.class)
                .hasMessage("Provided exception message is null");
    }

    @Test
    public void testJobQueryWithExceptions() throws Throwable {

        createJobWithoutExceptionMsg();

        Job job = managementService.createJobQuery().jobId(jobEntity.getId()).singleResult();

        assertThat(job).isNotNull();

        List<Job> list = managementService.createJobQuery().withException().list();
        assertThat(list).hasSize(1);

        deleteJobInDatabase();

        createJobWithoutExceptionStacktrace();

        job = managementService.createJobQuery().jobId(jobEntity.getId()).singleResult();

        assertThat(job).isNotNull();

        list = managementService.createJobQuery().withException().list();
        assertThat(list).hasSize(1);

        deleteJobInDatabase();

    }

    @Test
    public void testJobQueryByTenantId() {
        createJobWithTenantId("muppets");
        JobQuery query = managementService.createJobQuery().jobTenantId("muppets");
        verifyQueryResults(query, 1);
        deleteJobInDatabase();
    }

    @Test
    public void testTimerJobQueryByTenantId() {
        TimerJobQuery query = managementService.createTimerJobQuery().jobTenantId("muppets");
        verifyQueryResults(query, 0);
    }

    // sorting //////////////////////////////////////////

    @Test
    public void testQuerySorting() {
        // asc
        assertThat(managementService.createJobQuery().orderByJobId().asc().count()).isEqualTo(1);
        assertThat(managementService.createJobQuery().orderByJobDuedate().asc().count()).isEqualTo(1);
        assertThat(managementService.createJobQuery().orderByJobCreateTime().asc().count()).isEqualTo(1);
        assertThat(managementService.createJobQuery().orderByExecutionId().asc().count()).isEqualTo(1);
        assertThat(managementService.createJobQuery().orderByProcessInstanceId().asc().count()).isEqualTo(1);
        assertThat(managementService.createJobQuery().orderByJobRetries().asc().count()).isEqualTo(1);

        assertThat(managementService.createTimerJobQuery().orderByJobId().asc().count()).isEqualTo(3);
        assertThat(managementService.createTimerJobQuery().orderByJobDuedate().asc().count()).isEqualTo(3);
        assertThat(managementService.createTimerJobQuery().orderByJobCreateTime().asc().count()).isEqualTo(3);
        assertThat(managementService.createTimerJobQuery().orderByExecutionId().asc().count()).isEqualTo(3);
        assertThat(managementService.createTimerJobQuery().orderByProcessInstanceId().asc().count()).isEqualTo(3);
        assertThat(managementService.createTimerJobQuery().orderByJobRetries().asc().count()).isEqualTo(3);

        // desc
        assertThat(managementService.createJobQuery().orderByJobId().desc().count()).isEqualTo(1);
        assertThat(managementService.createJobQuery().orderByJobDuedate().desc().count()).isEqualTo(1);
        assertThat(managementService.createJobQuery().orderByJobCreateTime().desc().count()).isEqualTo(1);
        assertThat(managementService.createJobQuery().orderByExecutionId().desc().count()).isEqualTo(1);
        assertThat(managementService.createJobQuery().orderByProcessInstanceId().desc().count()).isEqualTo(1);
        assertThat(managementService.createJobQuery().orderByJobRetries().desc().count()).isEqualTo(1);

        assertThat(managementService.createTimerJobQuery().orderByJobId().desc().count()).isEqualTo(3);
        assertThat(managementService.createTimerJobQuery().orderByJobDuedate().desc().count()).isEqualTo(3);
        assertThat(managementService.createTimerJobQuery().orderByJobCreateTime().desc().count()).isEqualTo(3);
        assertThat(managementService.createTimerJobQuery().orderByExecutionId().desc().count()).isEqualTo(3);
        assertThat(managementService.createTimerJobQuery().orderByProcessInstanceId().desc().count()).isEqualTo(3);
        assertThat(managementService.createTimerJobQuery().orderByJobRetries().desc().count()).isEqualTo(3);

        // sorting on multiple fields
        setRetries(processInstanceIdTwo, 2);
        processEngineConfiguration.getClock().setCurrentTime(new Date(timerThreeFireTime.getTime() + ONE_SECOND)); // make sure all timers can fire

        TimerJobQuery query = managementService.createTimerJobQuery().timers().executable().orderByJobRetries().asc().orderByJobDuedate().desc();

        List<Job> jobs = query.list();
        assertThat(jobs)
                .extracting(Job::getRetries)
                .containsExactly(2, 3, 3);
        assertThat(jobs)
                .extracting(Job::getProcessInstanceId)
                .containsExactly(
                        processInstanceIdTwo,
                        processInstanceIdThree,
                        processInstanceIdOne
                );
    }

    @Test
    public void testQueryInvalidSortingUsage() {
        assertThatThrownBy(() -> managementService.createJobQuery().orderByJobId().list())
                .isExactlyInstanceOf(FlowableIllegalArgumentException.class)
                .hasMessage("Invalid query: call asc() or desc() after using orderByXX()");

        assertThatThrownBy(() -> managementService.createJobQuery().asc())
                .isExactlyInstanceOf(FlowableIllegalArgumentException.class)
                .hasMessage("You should call any of the orderBy methods first before specifying a direction");
    }

    @Test
    public void testQueryWithoutScopeType() {
        JobQuery query = managementService.createJobQuery().withoutScopeType();
        verifyQueryResults(query, 1);
    }

    @Test
    public void testTimerQueryWithoutScopeId() {
        TimerJobQuery query = managementService.createTimerJobQuery().withoutScopeId();
        verifyQueryResults(query, 3);
    }

    @Test
    public void testJobQueryWithoutScopeId() {
        JobQuery query = managementService.createJobQuery().withoutScopeId();
        verifyQueryResults(query, 1);

        assertThat(query.singleResult().getId()).isEqualTo(messageId);
    }

    @Test
    public void testHistoryQueryWithoutScopeType() {
        HistoryJobEntity historyJobEntity = managementService.executeCommand((Command<HistoryJobEntity>) commandContext -> {
            JobServiceConfiguration jobServiceConfiguration = CommandContextUtil.getProcessEngineConfiguration(commandContext).getJobServiceConfiguration();
            HistoryJobService historyJobService = jobServiceConfiguration.getHistoryJobService();
            HistoryJobEntity historyJob = historyJobService.createHistoryJob();
            historyJobService.scheduleHistoryJob(historyJob);
            return historyJob;
        });

        HistoryJobQuery query = managementService.createHistoryJobQuery().jobId(historyJobEntity.getId()).withoutScopeType();
        assertThat(query.singleResult()).isNotNull();

        managementService.executeCommand((Command<Void>) commandContext -> {
            JobServiceConfiguration jobServiceConfiguration = CommandContextUtil.getProcessEngineConfiguration(commandContext).getJobServiceConfiguration();
            HistoryJobService historyJobService = jobServiceConfiguration.getHistoryJobService();
            List<HistoryJob> jobs = historyJobService.findHistoryJobsByQueryCriteria(new HistoryJobQueryImpl(commandContext, jobServiceConfiguration));
            for (HistoryJob historyJob : jobs) {
                historyJobService.deleteHistoryJob((HistoryJobEntity) historyJob);
            }

            return null;
        });
    }

    @Test
    public void testTimerJobQueryWithoutScopeType() {
        TimerJobQuery query = managementService.createTimerJobQuery().withoutScopeType();
        assertThat(query.list().size()).isEqualTo(3);
    }

    @Test
    @Deployment(resources = "org/flowable/engine/test/bpmn/oneTask.bpmn20.xml")
    public void testDeadLetterJobQueryByProcessDefinitionKey() {
        ProcessInstance processInstance = runtimeService.startProcessInstanceByKey("startToEnd");

        DeadLetterJobEntity deadLetterJob = managementService.executeCommand(commandContext -> {
            JobServiceConfiguration jobServiceConfiguration = CommandContextUtil.getProcessEngineConfiguration(commandContext).getJobServiceConfiguration();
            DeadLetterJobEntityManager deadLetterJobEntityManager = jobServiceConfiguration.getDeadLetterJobEntityManager();
            DeadLetterJobEntity job = deadLetterJobEntityManager.create();
            job.setJobType(Job.JOB_TYPE_MESSAGE);
            job.setProcessInstanceId(processInstance.getId());
            job.setProcessDefinitionId(processInstance.getProcessDefinitionId());
            jobServiceConfiguration.getDeadLetterJobDataManager().insert(job);
            return job;
        });

        DeadLetterJobEntity deadLetterJob2 = managementService.executeCommand(commandContext -> {
            JobServiceConfiguration jobServiceConfiguration = CommandContextUtil.getProcessEngineConfiguration(commandContext).getJobServiceConfiguration();
            DeadLetterJobEntityManager deadLetterJobEntityManager = jobServiceConfiguration.getDeadLetterJobEntityManager();
            DeadLetterJobEntity job = deadLetterJobEntityManager.create();
            job.setJobType(Job.JOB_TYPE_MESSAGE);
            job.setScopeId("scope1");
            jobServiceConfiguration.getDeadLetterJobDataManager().insert(job);
            return job;
        });

        DeadLetterJobQuery query = managementService.createDeadLetterJobQuery().processDefinitionKey("startToEnd");
        assertThat(query.count()).isEqualTo(1);
        assertThat(query.list()).extracting(Job::getId).containsExactly(deadLetterJob.getId());
        assertThat(query.singleResult().getId()).isEqualTo(deadLetterJob.getId());

        query = managementService.createDeadLetterJobQuery().processDefinitionKey("invalid");
        assertThat(query.count()).isZero();
        assertThat(query.list()).isEmpty();
        assertThat(query.singleResult()).isNull();

        managementService.executeCommand((Command<Void>) commandContext -> {
            JobServiceConfiguration jobServiceConfiguration = CommandContextUtil.getProcessEngineConfiguration(commandContext).getJobServiceConfiguration();
            DeadLetterJobEntityManager deadLetterJobService = jobServiceConfiguration.getDeadLetterJobEntityManager();
            List<Job> jobs = deadLetterJobService.findJobsByQueryCriteria(new DeadLetterJobQueryImpl(commandContext, jobServiceConfiguration));
            for (Job job : jobs) {
                deadLetterJobService.delete(job.getId());
            }

            return null;
        });


    }
    @Test
    @Deployment(resources = "org/flowable/engine/test/bpmn/oneTask.bpmn20.xml")
    public void testDeadLetterJobQueryWithoutScopeType() {
        ProcessInstance processInstance = runtimeService.startProcessInstanceByKey("startToEnd");
        DeadLetterJobEntity deadLetterJob = managementService.executeCommand((Command<DeadLetterJobEntity>) commandContext -> {
            JobServiceConfiguration jobServiceConfiguration = CommandContextUtil.getProcessEngineConfiguration(commandContext).getJobServiceConfiguration();
            DeadLetterJobEntityManager deadLetterJobEntityManager = jobServiceConfiguration.getDeadLetterJobEntityManager();
            DeadLetterJobEntity job = deadLetterJobEntityManager.create();
            job.setJobType(Job.JOB_TYPE_MESSAGE);
            job.setProcessInstanceId(processInstance.getId());
            jobServiceConfiguration.getDeadLetterJobDataManager().insert(job);
            return job;
        });

        DeadLetterJobEntity deadLetterJob2 = managementService.executeCommand((Command<DeadLetterJobEntity>) commandContext -> {
            JobServiceConfiguration jobServiceConfiguration = CommandContextUtil.getProcessEngineConfiguration(commandContext).getJobServiceConfiguration();
            DeadLetterJobEntityManager deadLetterJobEntityManager = jobServiceConfiguration.getDeadLetterJobEntityManager();
            DeadLetterJobEntity job = deadLetterJobEntityManager.create();
            job.setJobType(Job.JOB_TYPE_MESSAGE);
            job.setScopeId("scope1");
            jobServiceConfiguration.getDeadLetterJobDataManager().insert(job);
            return job;
        });

        DeadLetterJobQuery query = managementService.createDeadLetterJobQuery().withoutScopeType();
        assertThat(query.list().size()).isEqualTo(2);

        query = managementService.createDeadLetterJobQuery().withoutProcessInstanceId();
        assertThat(query.count()).isEqualTo(1);
        assertThat(query.singleResult().getId()).isEqualTo(deadLetterJob2.getId());

        query = managementService.createDeadLetterJobQuery().withoutScopeId();
        assertThat(query.count()).isEqualTo(1);
        assertThat(query.singleResult().getId()).isEqualTo(deadLetterJob.getId());

        managementService.executeCommand((Command<Void>) commandContext -> {
            JobServiceConfiguration jobServiceConfiguration = CommandContextUtil.getProcessEngineConfiguration(commandContext).getJobServiceConfiguration();
            DeadLetterJobEntityManager deadLetterJobService = jobServiceConfiguration.getDeadLetterJobEntityManager();
            List<Job> jobs = deadLetterJobService.findJobsByQueryCriteria(new DeadLetterJobQueryImpl(commandContext, jobServiceConfiguration));
            for (Job job : jobs) {
                deadLetterJobService.delete(job.getId());
            }

            return null;
        });
    }

    @Test
    @Deployment(resources = "org/flowable/engine/test/bpmn/oneTask.bpmn20.xml")
    public void testSuspendedJobQueryByProcessDefinitionKey() {
        ProcessInstance processInstance = runtimeService.startProcessInstanceByKey("startToEnd");
        SuspendedJobEntity suspendedJob = managementService.executeCommand(commandContext -> {
            JobServiceConfiguration jobServiceConfiguration = CommandContextUtil.getProcessEngineConfiguration(commandContext).getJobServiceConfiguration();
            SuspendedJobEntityManager suspendedJobEntityManager = jobServiceConfiguration.getSuspendedJobEntityManager();
            SuspendedJobEntity job = suspendedJobEntityManager.create();
            job.setJobType(Job.JOB_TYPE_MESSAGE);
            job.setProcessInstanceId(processInstance.getId());
            job.setProcessDefinitionId(processInstance.getProcessDefinitionId());
            jobServiceConfiguration.getSuspendedJobEntityManager().insert(job);

            return job;
        });

        SuspendedJobEntity suspendedJob2 = managementService.executeCommand(commandContext -> {
            JobServiceConfiguration jobServiceConfiguration = CommandContextUtil.getProcessEngineConfiguration(commandContext).getJobServiceConfiguration();
            SuspendedJobEntityManager suspendedJobEntityManager = jobServiceConfiguration.getSuspendedJobEntityManager();
            SuspendedJobEntity job = suspendedJobEntityManager.create();
            job.setJobType(Job.JOB_TYPE_MESSAGE);
            job.setScopeId("scope1");
            jobServiceConfiguration.getSuspendedJobEntityManager().insert(job);

            return job;
        });

        SuspendedJobQuery query = managementService.createSuspendedJobQuery().processDefinitionKey("startToEnd");
        assertThat(query.count()).isEqualTo(1);
        assertThat(query.list()).extracting(Job::getId).containsExactly(suspendedJob.getId());
        assertThat(query.singleResult().getId()).isEqualTo(suspendedJob.getId());

        query = managementService.createSuspendedJobQuery().processDefinitionKey("invalid");
        assertThat(query.count()).isZero();
        assertThat(query.list()).isEmpty();
        assertThat(query.singleResult()).isNull();

        managementService.executeCommand((Command<Void>) commandContext -> {
            JobServiceConfiguration jobServiceConfiguration = CommandContextUtil.getProcessEngineConfiguration(commandContext).getJobServiceConfiguration();
            SuspendedJobEntityManager suspendedJobEntityManager = jobServiceConfiguration.getSuspendedJobEntityManager();
            List<Job> jobs = suspendedJobEntityManager.findJobsByQueryCriteria(new SuspendedJobQueryImpl(commandContext, jobServiceConfiguration));
            for (Job job : jobs) {
                suspendedJobEntityManager.delete(job.getId());
            }

            return null;
        });
    }

    @Test
    @Deployment(resources = "org/flowable/engine/test/bpmn/oneTask.bpmn20.xml")
    public void testSuspendedJobQueryWithoutScopeType() {
        ProcessInstance processInstance = runtimeService.startProcessInstanceByKey("startToEnd");
        SuspendedJobEntity suspendedJob = managementService.executeCommand((Command<SuspendedJobEntity>) commandContext -> {
            JobServiceConfiguration jobServiceConfiguration = CommandContextUtil.getProcessEngineConfiguration(commandContext).getJobServiceConfiguration();
            SuspendedJobEntityManager suspendedJobEntityManager = jobServiceConfiguration.getSuspendedJobEntityManager();
            SuspendedJobEntity job = suspendedJobEntityManager.create();
            job.setJobType(Job.JOB_TYPE_MESSAGE);
            job.setProcessInstanceId(processInstance.getId());
            jobServiceConfiguration.getSuspendedJobEntityManager().insert(job);

            return job;
        });

        SuspendedJobEntity suspendedJob2 = managementService.executeCommand((Command<SuspendedJobEntity>) commandContext -> {
            JobServiceConfiguration jobServiceConfiguration = CommandContextUtil.getProcessEngineConfiguration(commandContext).getJobServiceConfiguration();
            SuspendedJobEntityManager suspendedJobEntityManager = jobServiceConfiguration.getSuspendedJobEntityManager();
            SuspendedJobEntity job = suspendedJobEntityManager.create();
            job.setJobType(Job.JOB_TYPE_MESSAGE);
            job.setScopeId("scope1");
            jobServiceConfiguration.getSuspendedJobEntityManager().insert(job);

            return job;
        });

        SuspendedJobQuery query = managementService.createSuspendedJobQuery().withoutScopeType();
        assertThat(query.list().size()).isEqualTo(2);

        query = managementService.createSuspendedJobQuery().withoutProcessInstanceId();
        assertThat(query.count()).isEqualTo(1);
        assertThat(query.singleResult().getId()).isEqualTo(suspendedJob2.getId());

        query = managementService.createSuspendedJobQuery().withoutScopeId();
        assertThat(query.count()).isEqualTo(1);
        assertThat(query.singleResult().getId()).isEqualTo(suspendedJob.getId());

        managementService.executeCommand((Command<Void>) commandContext -> {
            JobServiceConfiguration jobServiceConfiguration = CommandContextUtil.getProcessEngineConfiguration(commandContext).getJobServiceConfiguration();
            SuspendedJobEntityManager suspendedJobEntityManager = jobServiceConfiguration.getSuspendedJobEntityManager();
            List<Job> jobs = suspendedJobEntityManager.findJobsByQueryCriteria(new SuspendedJobQueryImpl(commandContext, jobServiceConfiguration));
            for (Job job : jobs) {
                suspendedJobEntityManager.delete(job.getId());
            }

            return null;
        });
    }

    @Test
    public void testExternalWorkerJobQueryWithoutScopeType() {
        managementService.executeCommand((Command<Void>) commandContext -> {
            JobServiceConfiguration jobServiceConfiguration = CommandContextUtil.getProcessEngineConfiguration(commandContext).getJobServiceConfiguration();
            ExternalWorkerJobEntityManager externalWorkerJobEntityManager = jobServiceConfiguration.getExternalWorkerJobEntityManager();
            ExternalWorkerJobEntity externalWorkerJob = externalWorkerJobEntityManager.create();
            externalWorkerJob.setJobType(JobEntity.JOB_TYPE_EXTERNAL_WORKER);
            jobServiceConfiguration.getExternalWorkerJobEntityManager().insert(externalWorkerJob);
            return null;
        });

        ExternalWorkerJobQuery query = managementService.createExternalWorkerJobQuery().withoutScopeType();
        assertThat(query.list().size()).isEqualTo(1);

        managementService.executeCommand((Command<Void>) commandContext -> {
            JobServiceConfiguration jobServiceConfiguration = CommandContextUtil.getProcessEngineConfiguration(commandContext).getJobServiceConfiguration();
            ExternalWorkerJobEntityManager externalWorkerJobEntityManager = jobServiceConfiguration.getExternalWorkerJobEntityManager();
            List<ExternalWorkerJob> jobs = externalWorkerJobEntityManager.findJobsByQueryCriteria(
                    new ExternalWorkerJobQueryImpl(commandContext, jobServiceConfiguration));
            for (Job externalWorkerJob : jobs) {
                externalWorkerJobEntityManager.delete(externalWorkerJob.getId());
            }

            return null;
        });
    }

    @Test
    public void testJobQueryOrQuery() {
        // The setUp creates 1 message job in ACT_RU_JOB
        JobEntity extraJob = createJobWithHandlerType("testHandler");
        try {
            // OR query: match by id OR handler type
            List<Job> jobs = managementService.createJobQuery()
                    .or()
                        .jobId(messageId)
                        .handlerType("testHandler")
                    .endOr()
                    .list();
            assertThat(jobs).hasSize(2);
            assertThat(jobs).extracting(JobInfo::getId)
                    .containsExactlyInAnyOrder(messageId, extraJob.getId());

            // OR query with no match
            assertThat(managementService.createJobQuery()
                    .or()
                        .processInstanceId("nonexistent")
                        .executionId("nonexistent")
                    .endOr()
                    .count()).isZero();
        } finally {
            managementService.deleteJob(extraJob.getId());
        }
    }

    @Test
    public void testJobQueryOrWithAndQuery() {
        JobEntity extraJob = createJobWithHandlerType("testHandler");
        try {
            // AND + OR: the AND narrows, the OR broadens within its scope
            // jobId(messageId) AND (handlerType=testHandler OR jobId=messageId)
            List<Job> jobs = managementService.createJobQuery()
                    .jobId(messageId)
                    .or()
                        .handlerType("testHandler")
                        .jobId(messageId)
                    .endOr()
                    .list();
            // Only messageId matches the AND + OR
            assertThat(jobs).hasSize(1);
            assertThat(jobs.get(0).getId()).isEqualTo(messageId);
        } finally {
            managementService.deleteJob(extraJob.getId());
        }
    }

    @Test
    public void testJobQueryOrQueryErrors() {
        // or() twice should throw
        assertThatThrownBy(() -> managementService.createJobQuery().or().or())
                .isInstanceOf(FlowableException.class)
                .hasMessageContaining("the query is already in an or statement");

        // endOr() without or() should throw
        assertThatThrownBy(() -> managementService.createJobQuery().endOr())
                .isInstanceOf(FlowableException.class)
                .hasMessageContaining("endOr() can only be called after calling or()");
    }

    @Test
    public void testDeadLetterJobOrQuery() {
        createDeadLetterJobWithHandlerType("dlHandler1");
        createDeadLetterJobWithHandlerType("dlHandler2");
        try {
            Job dl1 = managementService.createDeadLetterJobQuery().handlerType("dlHandler1").singleResult();
            Job dl2 = managementService.createDeadLetterJobQuery().handlerType("dlHandler2").singleResult();
            assertThat(dl1).isNotNull();
            assertThat(dl2).isNotNull();

            // OR query: match by jobId OR handlerType
            List<Job> jobs = managementService.createDeadLetterJobQuery()
                    .or()
                        .jobId(dl1.getId())
                        .handlerType("dlHandler2")
                    .endOr()
                    .list();
            assertThat(jobs).hasSize(2);
            assertThat(jobs).extracting(JobInfo::getId)
                    .containsExactlyInAnyOrder(dl1.getId(), dl2.getId());

            // OR with no match
            assertThat(managementService.createDeadLetterJobQuery()
                    .or()
                        .processInstanceId("nonexistent")
                        .executionId("nonexistent")
                    .endOr()
                    .count()).isZero();
        } finally {
            managementService.deleteDeadLetterJob(managementService.createDeadLetterJobQuery().handlerType("dlHandler1").singleResult().getId());
            managementService.deleteDeadLetterJob(managementService.createDeadLetterJobQuery().handlerType("dlHandler2").singleResult().getId());
        }
    }

    @Test
    public void testDeadLetterJobOrWithAndQuery() {
        createDeadLetterJobWithHandlerType("dlHandler1");
        createDeadLetterJobWithHandlerType("dlHandler2");
        try {
            Job dl1 = managementService.createDeadLetterJobQuery().handlerType("dlHandler1").singleResult();
            Job dl2 = managementService.createDeadLetterJobQuery().handlerType("dlHandler2").singleResult();

            // AND (jobId=dl1) + OR (jobId=dl1 OR handlerType=dlHandler2)
            // dl1 matches the AND and the OR (via jobId), so returns dl1
            List<Job> jobs = managementService.createDeadLetterJobQuery()
                    .jobId(dl1.getId())
                    .or()
                        .jobId(dl1.getId())
                        .handlerType("dlHandler2")
                    .endOr()
                    .list();
            assertThat(jobs).hasSize(1);
            assertThat(jobs.get(0).getId()).isEqualTo(dl1.getId());

            // AND (handlerType=dlHandler1) + OR (jobId=dl1 OR jobId=dl2) - only dl1 matches both
            jobs = managementService.createDeadLetterJobQuery()
                    .handlerType("dlHandler1")
                    .or()
                        .jobId(dl1.getId())
                        .jobId(dl2.getId())
                    .endOr()
                    .list();
            // OR last setter wins: jobId=dl2. AND handlerType=dlHandler1 + OR jobId=dl2 -> dl2 has dlHandler2, no match
            // So this returns 0 - let's use different fields instead
            assertThat(jobs).isEmpty();

            // Better test: AND (handlerType=dlHandler1) + OR (jobId=dl1 OR handlerType=dlHandler2)
            // dl1 matches AND (dlHandler1) and OR (via jobId=dl1)
            jobs = managementService.createDeadLetterJobQuery()
                    .handlerType("dlHandler1")
                    .or()
                        .jobId(dl1.getId())
                        .handlerType("dlHandler2")
                    .endOr()
                    .list();
            assertThat(jobs).hasSize(1);
            assertThat(jobs.get(0).getId()).isEqualTo(dl1.getId());

            // Non-matching AND + valid OR returns nothing
            assertThat(managementService.createDeadLetterJobQuery()
                    .handlerType("nonexistent")
                    .or()
                        .jobId(dl1.getId())
                        .handlerType("dlHandler2")
                    .endOr()
                    .count()).isZero();
        } finally {
            managementService.deleteDeadLetterJob(managementService.createDeadLetterJobQuery().handlerType("dlHandler1").singleResult().getId());
            managementService.deleteDeadLetterJob(managementService.createDeadLetterJobQuery().handlerType("dlHandler2").singleResult().getId());
        }
    }

    @Test
    public void testDeadLetterJobOrQueryErrors() {
        assertThatThrownBy(() -> managementService.createDeadLetterJobQuery().or().or())
                .isInstanceOf(FlowableException.class)
                .hasMessageContaining("the query is already in an or statement");

        assertThatThrownBy(() -> managementService.createDeadLetterJobQuery().endOr())
                .isInstanceOf(FlowableException.class)
                .hasMessageContaining("endOr() can only be called after calling or()");
    }

    @Test
    public void testSuspendedJobOrQuery() {
        createSuspendedJobWithHandlerType("susHandler1");
        createSuspendedJobWithHandlerType("susHandler2");
        try {
            Job sus1 = managementService.createSuspendedJobQuery().handlerType("susHandler1").singleResult();
            Job sus2 = managementService.createSuspendedJobQuery().handlerType("susHandler2").singleResult();
            assertThat(sus1).isNotNull();
            assertThat(sus2).isNotNull();

            List<Job> jobs = managementService.createSuspendedJobQuery()
                    .or()
                        .jobId(sus1.getId())
                        .handlerType("susHandler2")
                    .endOr()
                    .list();
            assertThat(jobs).hasSize(2);
            assertThat(jobs).extracting(JobInfo::getId)
                    .containsExactlyInAnyOrder(sus1.getId(), sus2.getId());

            // OR with no match
            assertThat(managementService.createSuspendedJobQuery()
                    .or()
                        .processInstanceId("nonexistent")
                        .executionId("nonexistent")
                    .endOr()
                    .count()).isZero();
        } finally {
            managementService.deleteSuspendedJob(managementService.createSuspendedJobQuery().handlerType("susHandler1").singleResult().getId());
            managementService.deleteSuspendedJob(managementService.createSuspendedJobQuery().handlerType("susHandler2").singleResult().getId());
        }
    }

    @Test
    public void testSuspendedJobOrWithAndQuery() {
        createSuspendedJobWithHandlerType("susHandler1");
        createSuspendedJobWithHandlerType("susHandler2");
        try {
            Job sus1 = managementService.createSuspendedJobQuery().handlerType("susHandler1").singleResult();
            Job sus2 = managementService.createSuspendedJobQuery().handlerType("susHandler2").singleResult();

            // AND (jobId=sus1) + OR (jobId=sus1 OR handlerType=susHandler2)
            List<Job> jobs = managementService.createSuspendedJobQuery()
                    .jobId(sus1.getId())
                    .or()
                        .jobId(sus1.getId())
                        .handlerType("susHandler2")
                    .endOr()
                    .list();
            assertThat(jobs).hasSize(1);
            assertThat(jobs.get(0).getId()).isEqualTo(sus1.getId());
        } finally {
            managementService.deleteSuspendedJob(managementService.createSuspendedJobQuery().handlerType("susHandler1").singleResult().getId());
            managementService.deleteSuspendedJob(managementService.createSuspendedJobQuery().handlerType("susHandler2").singleResult().getId());
        }
    }

    @Test
    public void testSuspendedJobOrQueryErrors() {
        assertThatThrownBy(() -> managementService.createSuspendedJobQuery().or().or())
                .isInstanceOf(FlowableException.class)
                .hasMessageContaining("the query is already in an or statement");

        assertThatThrownBy(() -> managementService.createSuspendedJobQuery().endOr())
                .isInstanceOf(FlowableException.class)
                .hasMessageContaining("endOr() can only be called after calling or()");
    }

    @Test
    public void testHistoryJobOrQuery() {
        createHistoryJobWithHandlerType("histHandler1");
        createHistoryJobWithHandlerType("histHandler2");
        try {
            HistoryJob hj1 = managementService.createHistoryJobQuery().handlerType("histHandler1").singleResult();
            HistoryJob hj2 = managementService.createHistoryJobQuery().handlerType("histHandler2").singleResult();

            // OR query: match by jobId OR handlerType
            List<HistoryJob> jobs = managementService.createHistoryJobQuery()
                    .or()
                        .jobId(hj1.getId())
                        .handlerType("histHandler2")
                    .endOr()
                    .list();
            assertThat(jobs).hasSize(2);
            assertThat(jobs).extracting(HistoryJob::getId)
                    .containsExactlyInAnyOrder(hj1.getId(), hj2.getId());

            // OR with no match
            assertThat(managementService.createHistoryJobQuery()
                    .or()
                        .jobId("nonexistent")
                        .handlerType("nonexistent")
                    .endOr()
                    .count()).isZero();
        } finally {
            managementService.deleteHistoryJob(managementService.createHistoryJobQuery().handlerType("histHandler1").singleResult().getId());
            managementService.deleteHistoryJob(managementService.createHistoryJobQuery().handlerType("histHandler2").singleResult().getId());
        }
    }

    @Test
    public void testHistoryJobOrWithAndQuery() {
        createHistoryJobWithHandlerType("histHandler1");
        createHistoryJobWithHandlerType("histHandler2");
        try {
            HistoryJob hj1 = managementService.createHistoryJobQuery().handlerType("histHandler1").singleResult();

            // AND (handlerType=histHandler1) + OR (jobId=hj1 OR handlerType=histHandler2)
            // hj1 matches AND and OR (via jobId)
            List<HistoryJob> jobs = managementService.createHistoryJobQuery()
                    .handlerType("histHandler1")
                    .or()
                        .jobId(hj1.getId())
                        .handlerType("histHandler2")
                    .endOr()
                    .list();
            assertThat(jobs).hasSize(1);
            assertThat(jobs.get(0).getId()).isEqualTo(hj1.getId());

            // Non-matching AND + valid OR returns nothing
            assertThat(managementService.createHistoryJobQuery()
                    .handlerType("nonexistent")
                    .or()
                        .jobId(hj1.getId())
                        .handlerType("histHandler2")
                    .endOr()
                    .count()).isZero();
        } finally {
            managementService.deleteHistoryJob(managementService.createHistoryJobQuery().handlerType("histHandler1").singleResult().getId());
            managementService.deleteHistoryJob(managementService.createHistoryJobQuery().handlerType("histHandler2").singleResult().getId());
        }
    }

    @Test
    public void testHistoryJobOrQueryErrors() {
        assertThatThrownBy(() -> managementService.createHistoryJobQuery().or().or())
                .isInstanceOf(FlowableException.class)
                .hasMessageContaining("the query is already in an or statement");

        assertThatThrownBy(() -> managementService.createHistoryJobQuery().endOr())
                .isInstanceOf(FlowableException.class)
                .hasMessageContaining("endOr() can only be called after calling or()");
    }

    @Test
    public void testJobQueryConsecutiveOrQuery() {
        JobEntity jobA = createJobWithHandlerType("consOrA");
        JobEntity jobB = createJobWithHandlerType("consOrB");
        JobEntity jobC = createJobWithHandlerType("consOrC");
        try {
            // First OR group matches {A, B}, second matches {B, C} -> intersection = {B}
            List<Job> jobs = managementService.createJobQuery()
                    .or()
                        .jobId(jobA.getId())
                        .handlerType("consOrB")
                    .endOr()
                    .or()
                        .jobId(jobB.getId())
                        .handlerType("consOrC")
                    .endOr()
                    .list();
            assertThat(jobs).hasSize(1);
            assertThat(jobs.get(0).getId()).isEqualTo(jobB.getId());
        } finally {
            managementService.deleteJob(jobA.getId());
            managementService.deleteJob(jobB.getId());
            managementService.deleteJob(jobC.getId());
        }
    }

    @Test
    public void testDeadLetterJobConsecutiveOrQuery() {
        createDeadLetterJobWithHandlerType("consOrDlA");
        createDeadLetterJobWithHandlerType("consOrDlB");
        createDeadLetterJobWithHandlerType("consOrDlC");
        try {
            Job dlA = managementService.createDeadLetterJobQuery().handlerType("consOrDlA").singleResult();
            Job dlB = managementService.createDeadLetterJobQuery().handlerType("consOrDlB").singleResult();
            Job dlC = managementService.createDeadLetterJobQuery().handlerType("consOrDlC").singleResult();

            // First OR group matches {A, B}, second matches {B, C} -> intersection = {B}
            List<Job> jobs = managementService.createDeadLetterJobQuery()
                    .or()
                        .jobId(dlA.getId())
                        .handlerType("consOrDlB")
                    .endOr()
                    .or()
                        .jobId(dlB.getId())
                        .handlerType("consOrDlC")
                    .endOr()
                    .list();
            assertThat(jobs).hasSize(1);
            assertThat(jobs.get(0).getId()).isEqualTo(dlB.getId());
        } finally {
            managementService.deleteDeadLetterJob(managementService.createDeadLetterJobQuery().handlerType("consOrDlA").singleResult().getId());
            managementService.deleteDeadLetterJob(managementService.createDeadLetterJobQuery().handlerType("consOrDlB").singleResult().getId());
            managementService.deleteDeadLetterJob(managementService.createDeadLetterJobQuery().handlerType("consOrDlC").singleResult().getId());
        }
    }

    @Test
    public void testSuspendedJobConsecutiveOrQuery() {
        createSuspendedJobWithHandlerType("consOrSusA");
        createSuspendedJobWithHandlerType("consOrSusB");
        createSuspendedJobWithHandlerType("consOrSusC");
        try {
            Job susA = managementService.createSuspendedJobQuery().handlerType("consOrSusA").singleResult();
            Job susB = managementService.createSuspendedJobQuery().handlerType("consOrSusB").singleResult();
            Job susC = managementService.createSuspendedJobQuery().handlerType("consOrSusC").singleResult();

            // First OR group matches {A, B}, second matches {B, C} -> intersection = {B}
            List<Job> jobs = managementService.createSuspendedJobQuery()
                    .or()
                        .jobId(susA.getId())
                        .handlerType("consOrSusB")
                    .endOr()
                    .or()
                        .jobId(susB.getId())
                        .handlerType("consOrSusC")
                    .endOr()
                    .list();
            assertThat(jobs).hasSize(1);
            assertThat(jobs.get(0).getId()).isEqualTo(susB.getId());
        } finally {
            managementService.deleteSuspendedJob(managementService.createSuspendedJobQuery().handlerType("consOrSusA").singleResult().getId());
            managementService.deleteSuspendedJob(managementService.createSuspendedJobQuery().handlerType("consOrSusB").singleResult().getId());
            managementService.deleteSuspendedJob(managementService.createSuspendedJobQuery().handlerType("consOrSusC").singleResult().getId());
        }
    }

    @Test
    public void testHistoryJobConsecutiveOrQuery() {
        createHistoryJobWithHandlerType("consOrHistA");
        createHistoryJobWithHandlerType("consOrHistB");
        createHistoryJobWithHandlerType("consOrHistC");
        try {
            HistoryJob hjA = managementService.createHistoryJobQuery().handlerType("consOrHistA").singleResult();
            HistoryJob hjB = managementService.createHistoryJobQuery().handlerType("consOrHistB").singleResult();
            HistoryJob hjC = managementService.createHistoryJobQuery().handlerType("consOrHistC").singleResult();

            // First OR group matches {A, B}, second matches {B, C} -> intersection = {B}
            List<HistoryJob> jobs = managementService.createHistoryJobQuery()
                    .or()
                        .jobId(hjA.getId())
                        .handlerType("consOrHistB")
                    .endOr()
                    .or()
                        .jobId(hjB.getId())
                        .handlerType("consOrHistC")
                    .endOr()
                    .list();
            assertThat(jobs).hasSize(1);
            assertThat(jobs.get(0).getId()).isEqualTo(hjB.getId());
        } finally {
            managementService.deleteHistoryJob(managementService.createHistoryJobQuery().handlerType("consOrHistA").singleResult().getId());
            managementService.deleteHistoryJob(managementService.createHistoryJobQuery().handlerType("consOrHistB").singleResult().getId());
            managementService.deleteHistoryJob(managementService.createHistoryJobQuery().handlerType("consOrHistC").singleResult().getId());
        }
    }

    // helper ////////////////////////////////////////////////////////////

    private void setRetries(final String processInstanceId, final int retries) {
        final Job job = managementService.createTimerJobQuery().processInstanceId(processInstanceId).singleResult();
        managementService.setTimerJobRetries(job.getId(), retries);
    }

    private ProcessInstance startProcessInstanceWithFailingJob() {
        // start a process with a failing job
        ProcessInstance processInstance = runtimeService.startProcessInstanceByKey("exceptionInJobExecution");

        // The execution is waiting in the first usertask. This contains a boundary
        // timer event which we will execute manual for testing purposes.
        Job timerJob = managementService.createTimerJobQuery().processInstanceId(processInstance.getId()).singleResult();

        assertThat(timerJob).as("No job found for process instance").isNotNull();

        assertThatThrownBy(() -> {
            managementService.moveTimerToExecutableJob(timerJob.getId());
            managementService.executeJob(timerJob.getId());
        })
                .isInstanceOf(FlowableException.class)
                .hasMessageContaining(EXCEPTION_MESSAGE);

        return processInstance;
    }

    private void verifyFailedJob(TimerJobQuery query, ProcessInstance processInstance) {
        verifyQueryResults(query, 1);

        Job failedJob = query.singleResult();
        assertThat(failedJob).isNotNull();
        assertThat(failedJob.getProcessInstanceId()).isEqualTo(processInstance.getId());
        assertThat(failedJob.getExceptionMessage()).containsSequence(EXCEPTION_MESSAGE);
    }

    private void verifyQueryResults(BaseJobQuery query, int countExpected) {
        assertThat(query.list()).hasSize(countExpected);
        assertThat(query.count()).isEqualTo(countExpected);

        if (countExpected == 1) {
            assertThat(query.singleResult()).isNotNull();
        } else if (countExpected > 1) {
            verifySingleResultFails(query);
        } else if (countExpected == 0) {
            assertThat(query.singleResult()).isNull();
        }
    }

    private void verifySingleResultFails(BaseJobQuery query) {
        assertThatThrownBy(() -> query.singleResult())
                .isExactlyInstanceOf(FlowableException.class);
    }

    private void createJobWithoutExceptionMsg() {
        CommandExecutor commandExecutor = processEngineConfiguration.getCommandExecutor();
        commandExecutor.execute(new Command<Void>() {

            @Override
            public Void execute(CommandContext commandContext) {
                JobService jobService = CommandContextUtil.getJobService(commandContext);
                jobEntity = jobService.createJob();
                jobEntity.setJobType(Job.JOB_TYPE_MESSAGE);
                jobEntity.setLockOwner(UUID.randomUUID().toString());
                jobEntity.setRetries(0);

                StringWriter stringWriter = new StringWriter();
                NullPointerException exception = new NullPointerException();
                exception.printStackTrace(new PrintWriter(stringWriter));
                jobEntity.setExceptionStacktrace(stringWriter.toString());

                jobService.insertJob(jobEntity);

                assertThat(jobEntity.getId()).isNotNull();

                return null;

            }
        });

    }

    private void createJobWithoutExceptionStacktrace() {
        CommandExecutor commandExecutor = processEngineConfiguration.getCommandExecutor();
        commandExecutor.execute(new Command<Void>() {

            @Override
            public Void execute(CommandContext commandContext) {
                JobService jobService = CommandContextUtil.getJobService(commandContext);
                jobEntity = jobService.createJob();
                jobEntity.setJobType(Job.JOB_TYPE_MESSAGE);
                jobEntity.setLockOwner(UUID.randomUUID().toString());
                jobEntity.setRetries(0);

                jobEntity.setExceptionMessage("I'm supposed to fail");

                jobService.insertJob(jobEntity);

                assertThat(jobEntity.getId()).isNotNull();

                return null;

            }
        });

    }

    private JobEntity createJobWithType(String type) {
        CommandExecutor commandExecutor = processEngineConfiguration.getCommandExecutor();
        return commandExecutor.execute(new Command<>() {

            @Override
            public JobEntity execute(CommandContext commandContext) {
                JobService jobService = CommandContextUtil.getJobService(commandContext);
                JobEntity result = jobService.createJob();
                result.setJobType(type);
                result.setRetries(0);
                jobService.insertJob(result);
                assertThat(result.getId()).isNotNull();
                return result;
            }
        });
    }

    private void createDeadLetterJobWithType(String type) {
        CommandExecutor commandExecutor = processEngineConfiguration.getCommandExecutor();
        commandExecutor.execute(new Command<Void>() {

            @Override
            public Void execute(CommandContext commandContext) {
                JobService jobService = CommandContextUtil.getJobService(commandContext);
                jobService.moveJobToDeadLetterJob(createJobWithType(type));
                return null;
            }
        });
    }

    private void createSuspendedJobWithType(String type, String handlerType) {
        managementService.executeCommand(commandContext -> {
            JobServiceConfiguration jobServiceConfiguration = CommandContextUtil.getProcessEngineConfiguration(commandContext).getJobServiceConfiguration();
            SuspendedJobEntityManager suspendedJobEntityManager = jobServiceConfiguration.getSuspendedJobEntityManager();
            SuspendedJobEntity job = suspendedJobEntityManager.create();
            job.setJobType(type);
            job.setJobHandlerType(handlerType);
            suspendedJobEntityManager.insert(job);
            return null;
        });
    }

    private JobEntity createJobWithHandlerType(String handlerType) {
        CommandExecutor commandExecutor = processEngineConfiguration.getCommandExecutor();
        return commandExecutor.execute(new Command<>() {

            @Override
            public JobEntity execute(CommandContext commandContext) {
                JobService jobService = CommandContextUtil.getJobService(commandContext);
                JobEntity result = jobService.createJob();
                result.setJobType(Job.JOB_TYPE_MESSAGE);
                result.setRetries(0);
                result.setJobHandlerType(handlerType);
                jobService.insertJob(result);
                assertThat(result.getId()).isNotNull();
                return result;
            }
        });
    }

    private JobEntity createJobWithScope(String scopeType, String scopeId, String elementId) {
        CommandExecutor commandExecutor = processEngineConfiguration.getCommandExecutor();
        return commandExecutor.execute(new Command<>() {

            @Override
            public JobEntity execute(CommandContext commandContext) {
                JobService jobService = CommandContextUtil.getJobService(commandContext);
                JobEntity result = jobService.createJob();
                result.setJobType(Job.JOB_TYPE_MESSAGE);
                result.setRetries(0);
                result.setScopeType(scopeType);
                result.setScopeId(scopeId);
                result.setElementId(elementId);
                jobService.insertJob(result);
                assertThat(result.getId()).isNotNull();
                return result;
            }
        });
    }

    private SuspendedJobEntity createSuspendedJobWithScope(String scopeType, String scopeId, String elementId) {
        return managementService.executeCommand(commandContext -> {
            JobServiceConfiguration jobServiceConfiguration = CommandContextUtil.getProcessEngineConfiguration(commandContext).getJobServiceConfiguration();
            SuspendedJobEntityManager suspendedJobEntityManager = jobServiceConfiguration.getSuspendedJobEntityManager();
            SuspendedJobEntity job = suspendedJobEntityManager.create();
            job.setJobType(Job.JOB_TYPE_MESSAGE);
            job.setScopeType(scopeType);
            job.setScopeId(scopeId);
            job.setElementId(elementId);
            suspendedJobEntityManager.insert(job);
            assertThat(job.getId()).isNotNull();
            return job;
        });
    }

    private DeadLetterJobEntity createDeadLetterJobWithScope(String scopeType, String scopeId, String elementId) {
        return managementService.executeCommand(commandContext -> {
            JobServiceConfiguration jobServiceConfiguration = CommandContextUtil.getProcessEngineConfiguration(commandContext).getJobServiceConfiguration();
            DeadLetterJobEntityManager deadLetterJobEntityManager = jobServiceConfiguration.getDeadLetterJobEntityManager();
            DeadLetterJobEntity job = deadLetterJobEntityManager.create();
            job.setJobType(Job.JOB_TYPE_MESSAGE);
            job.setScopeType(scopeType);
            job.setScopeId(scopeId);
            job.setElementId(elementId);
            deadLetterJobEntityManager.insert(job);
            assertThat(job.getId()).isNotNull();
            return job;
        });
    }

    private TimerJobEntity createTimerJobWithScope(String scopeType, String scopeId, String elementId) {
        return managementService.executeCommand(commandContext -> {
            JobServiceConfiguration jobServiceConfiguration = CommandContextUtil.getProcessEngineConfiguration(commandContext).getJobServiceConfiguration();
            TimerJobEntityManager timerJobEntityManager = jobServiceConfiguration.getTimerJobEntityManager();
            TimerJobEntity job = timerJobEntityManager.create();
            job.setJobType(Job.JOB_TYPE_TIMER);
            job.setScopeType(scopeType);
            job.setScopeId(scopeId);
            job.setElementId(elementId);
            timerJobEntityManager.insert(job);
            assertThat(job.getId()).isNotNull();
            return job;
        });
    }

    private void createDeadLetterJobWithHandlerType(String handlerType) {
        CommandExecutor commandExecutor = processEngineConfiguration.getCommandExecutor();
        commandExecutor.execute(new Command<Void>() {

            @Override
            public Void execute(CommandContext commandContext) {
                JobService jobService = CommandContextUtil.getJobService(commandContext);
                jobService.moveJobToDeadLetterJob(createJobWithHandlerType(handlerType));
                return null;
            }
        });
    }

    private void createSuspendedJobWithHandlerType(String handlerType) {
        CommandExecutor commandExecutor = processEngineConfiguration.getCommandExecutor();
        commandExecutor.execute(new Command<Void>() {

            @Override
            public Void execute(CommandContext commandContext) {
                JobService jobService = CommandContextUtil.getJobService(commandContext);
                jobService.moveJobToSuspendedJob(createJobWithHandlerType(handlerType));
                return null;
            }
        });
    }

    private void createHistoryJobWithHandlerType(String handlerType) {
        HistoryJobEntity historyJobEntity = managementService.executeCommand((Command<HistoryJobEntity>) commandContext -> {
            JobServiceConfiguration jobServiceConfiguration = CommandContextUtil.getProcessEngineConfiguration(commandContext).getJobServiceConfiguration();
            HistoryJobService historyJobService = jobServiceConfiguration.getHistoryJobService();
            HistoryJobEntity historyJob = historyJobService.createHistoryJob();
            historyJob.setJobHandlerType(handlerType);
            historyJobService.scheduleHistoryJob(historyJob);
            return historyJob;
        });
    }

    private void createJobWithTenantId(String tenantId) {
        CommandExecutor commandExecutor = processEngineConfiguration.getCommandExecutor();
        commandExecutor.execute(new Command<Void>() {

            @Override
            public Void execute(CommandContext commandContext) {
                JobService jobService = CommandContextUtil.getJobService(commandContext);
                jobEntity = jobService.createJob();
                jobEntity.setJobType(Job.JOB_TYPE_MESSAGE);
                jobEntity.setLockOwner(UUID.randomUUID().toString());
                jobEntity.setRetries(0);
                jobEntity.setTenantId(tenantId);

                StringWriter stringWriter = new StringWriter();
                NullPointerException exception = new NullPointerException();
                exception.printStackTrace(new PrintWriter(stringWriter));
                jobEntity.setExceptionStacktrace(stringWriter.toString());

                jobService.insertJob(jobEntity);

                assertThat(jobEntity.getId()).isNotNull();

                return null;

            }
        });

    }

    private void deleteJobInDatabase() {
        CommandExecutor commandExecutor = processEngineConfiguration.getCommandExecutor();
        commandExecutor.execute(new Command<Void>() {

            @Override
            public Void execute(CommandContext commandContext) {
                JobService jobService = CommandContextUtil.getJobService(commandContext);
                jobService.deleteJob(jobEntity.getId());
                return null;
            }
        });
    }

}
