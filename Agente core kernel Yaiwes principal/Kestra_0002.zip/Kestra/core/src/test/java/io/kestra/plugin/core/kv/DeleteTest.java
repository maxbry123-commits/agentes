package io.kestra.plugin.core.kv;

import java.util.Map;
import java.util.NoSuchElementException;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import io.kestra.core.context.TestRunContextFactory;
import io.kestra.core.junit.annotations.KestraTest;
import io.kestra.core.models.property.Property;
import io.kestra.core.runners.RunContext;
import io.kestra.core.storages.kv.KVStore;
import io.kestra.core.storages.kv.KVValueAndMetadata;
import io.kestra.core.utils.IdUtils;

import jakarta.inject.Inject;

import static org.assertj.core.api.Assertions.assertThat;

@KestraTest
class DeleteTest {
    static final String TEST_KV_KEY = "test-key";

    @Inject
    TestRunContextFactory runContextFactory;

    @Test
    void shouldOutputTrueGivenExistingKey() throws Exception {
        // Given
        String namespaceId = "io.kestra." + IdUtils.create();
        RunContext runContext = this.runContextFactory.of(
            namespaceId, Map.of(
                "inputs", Map.of(
                    "key", TEST_KV_KEY,
                    "namespace", namespaceId
                )
            )
        );

        Delete delete = Delete.builder()
            .id(Delete.class.getSimpleName())
            .type(Delete.class.getName())
            .namespace(Property.ofExpression("{{ inputs.namespace }}"))
            .key(Property.ofExpression("{{ inputs.key }}"))
            .build();

        final KVStore kv = runContext.namespaceKv(namespaceId);
        kv.put(TEST_KV_KEY, new KVValueAndMetadata(null, "value"));

        // When
        Delete.Output run = delete.run(runContext);

        // Then
        assertThat(run.isDeleted()).isTrue();
    }

    @Test
    void shouldOutputFalseGivenNonExistingKey() throws Exception {
        // Given
        String namespaceId = "io.kestra." + IdUtils.create();
        RunContext runContext = this.runContextFactory.of(
            namespaceId, Map.of(
                "inputs", Map.of(
                    "key", TEST_KV_KEY,
                    "namespace", namespaceId
                )
            )
        );

        Delete delete = Delete.builder()
            .id(Delete.class.getSimpleName())
            .type(Delete.class.getName())
            .namespace(Property.ofValue(namespaceId))
            .key(Property.ofValue("my-key"))
            .build();

        // When
        Delete.Output run = delete.run(runContext);

        assertThat(run.isDeleted()).isFalse();

        Delete finalDelete = delete.toBuilder().errorOnMissing(Property.ofValue(true)).build();
        NoSuchElementException noSuchElementException = Assertions.assertThrows(NoSuchElementException.class, () -> finalDelete.run(runContext));
        assertThat(noSuchElementException.getMessage()).isEqualTo("No value found for key 'my-key' in namespace '" + namespaceId + "' and `errorOnMissing` is set to true");
    }
}
