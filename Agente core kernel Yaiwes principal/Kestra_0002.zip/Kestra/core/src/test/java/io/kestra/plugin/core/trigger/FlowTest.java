package io.kestra.plugin.core.trigger;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.junit.jupiter.api.Test;

import io.kestra.core.junit.annotations.KestraTest;
import io.kestra.core.models.Label;
import io.kestra.core.models.executions.Execution;
import io.kestra.core.models.executions.ExecutionTrigger;
import io.kestra.core.models.flows.State;
import io.kestra.core.models.property.Property;
import io.kestra.core.runners.RunContextFactory;
import io.kestra.core.services.LabelService;
import io.kestra.core.utils.IdUtils;
import io.kestra.plugin.core.debug.Return;

import jakarta.inject.Inject;

import static org.assertj.core.api.Assertions.assertThat;

@KestraTest
class FlowTest {
    @Inject
    RunContextFactory runContextFactory;

    @Test
    void success() {
        var flow = io.kestra.core.models.flows.Flow.builder()
            .id("flow-with-flow-trigger")
            .namespace("io.kestra.unittest")
            .revision(1)
            .labels(
                List.of(
                    new Label("flow-label-1", "flow-label-1"),
                    new Label("flow-label-2", "flow-label-2")
                )
            )
            .tasks(
                Collections.singletonList(
                    Return.builder()
                        .id("test")
                        .type(Return.class.getName())
                        .format(Property.ofValue("test"))
                        .build()
                )
            )
            .build();
        var execution = Execution.builder()
            .id(IdUtils.create())
            .namespace("io.kestra.unittest")
            .flowId("flow-with-flow-trigger")
            .flowRevision(1)
            .state(new State().withState(State.Type.RUNNING))
            .labels(
                List.of(
                    new Label("execution-label", "execution"),
                    new Label(Label.CORRELATION_ID, "correlationId")
                )
            )
            .build();
        var flowTrigger = Flow.builder()
            .id("flow")
            .type(Flow.class.getName())
            .build();

        Optional<Execution> evaluate = flowTrigger.evaluate(
            Optional.empty(),
            runContextFactory.of(),
            flow,
            execution,
            Map.of()
        );

        assertThat(evaluate.isPresent()).isTrue();
        assertThat(evaluate.get().getFlowId()).isEqualTo("flow-with-flow-trigger");
        assertThat(evaluate.get().getLabels()).hasSize(3);
        assertThat(evaluate.get().getLabels()).contains(new Label("flow-label-1", "flow-label-1"));
        assertThat(evaluate.get().getLabels()).contains(new Label("flow-label-2", "flow-label-2"));
        assertThat(evaluate.get().getLabels()).contains(new Label(Label.CORRELATION_ID, "correlationId"));
    }

    @Test
    void withTenant() {
        var flow = io.kestra.core.models.flows.Flow.builder()
            .id("flow-with-flow-trigger")
            .tenantId("tenantId")
            .namespace("io.kestra.unittest")
            .revision(1)
            .labels(
                List.of(
                    new Label("flow-label-1", "flow-label-1"),
                    new Label("flow-label-2", "flow-label-2")
                )
            )
            .tasks(
                Collections.singletonList(
                    Return.builder()
                        .id("test")
                        .type(Return.class.getName())
                        .format(Property.ofValue("test"))
                        .build()
                )
            )
            .build();
        var execution = Execution.builder()
            .id(IdUtils.create())
            .tenantId("tenantId")
            .namespace("io.kestra.unittest")
            .flowId("flow-with-flow-trigger")
            .flowRevision(1)
            .state(new State().withState(State.Type.RUNNING))
            .labels(
                List.of(
                    new Label("execution-label", "execution"),
                    new Label(Label.CORRELATION_ID, "correlationId")
                )
            )
            .build();
        var flowTrigger = Flow.builder()
            .id("flow")
            .type(Flow.class.getName())
            .build();

        Optional<Execution> evaluate = flowTrigger.evaluate(
            Optional.empty(),
            runContextFactory.of(),
            flow,
            execution,
            Map.of()
        );

        assertThat(evaluate.isPresent()).isTrue();
        assertThat(evaluate.get().getFlowId()).isEqualTo("flow-with-flow-trigger");
        assertThat(evaluate.get().getTenantId()).isEqualTo("tenantId");
        assertThat(evaluate.get().getLabels()).hasSize(3);
        assertThat(evaluate.get().getLabels()).contains(new Label("flow-label-1", "flow-label-1"));
        assertThat(evaluate.get().getLabels()).contains(new Label("flow-label-2", "flow-label-2"));
        assertThat(evaluate.get().getLabels()).contains(new Label(Label.CORRELATION_ID, "correlationId"));
    }

    @Test
    void success_withLabels() {
        var flow = io.kestra.core.models.flows.Flow.builder()
            .id("flow-with-flow-trigger")
            .namespace("io.kestra.unittest")
            .revision(1)
            .labels(
                List.of(
                    new Label("flow-label-1", "flow-label-1"),
                    new Label("flow-label-2", "flow-label-2")
                )
            )
            .tasks(
                Collections.singletonList(
                    Return.builder()
                        .id("test")
                        .type(Return.class.getName())
                        .format(Property.ofValue("test"))
                        .build()
                )
            )
            .build();
        var execution = Execution.builder()
            .id(IdUtils.create())
            .namespace("io.kestra.unittest")
            .flowId("flow-with-flow-trigger")
            .flowRevision(1)
            .state(new State().withState(State.Type.RUNNING))
            .labels(
                List.of(
                    new Label("execution-label", "execution"),
                    new Label(Label.CORRELATION_ID, "correlationId")
                )
            )
            .build();
        var flowTrigger = Flow.builder()
            .id("flow")
            .type(Flow.class.getName())
            .labels(
                List.of(
                    new Label("trigger-label-1", "trigger-label-1"),
                    new Label("trigger-label-2", "{{ 'trigger-label-2' }}"),
                    new Label("trigger-label-3", "{{ null }}"), // should return an empty string
                    new Label("trigger-label-4", "{{ foobar }}") // should fail
                )
            )
            .build();

        Optional<Execution> evaluate = flowTrigger.evaluate(Optional.empty(), runContextFactory.of(), flow, execution, Map.of());

        assertThat(evaluate.isPresent()).isTrue();
        assertThat(evaluate.get().getLabels()).hasSize(5);
        assertThat(evaluate.get().getLabels()).contains(new Label("flow-label-1", "flow-label-1"));
        assertThat(evaluate.get().getLabels()).contains(new Label("flow-label-2", "flow-label-2"));
        assertThat(evaluate.get().getLabels()).contains(new Label("trigger-label-1", "trigger-label-1"));
        assertThat(evaluate.get().getLabels()).contains(new Label("trigger-label-2", "trigger-label-2"));
        assertThat(evaluate.get().getLabels()).doesNotContain(new Label("trigger-label-3", ""));
        assertThat(evaluate.get().getLabels()).contains(new Label(Label.CORRELATION_ID, "correlationId"));
        assertThat(evaluate.get().getTrigger()).extracting(ExecutionTrigger::getVariables).hasFieldOrProperty("executionLabels");
        assertThat(evaluate.get().getTrigger().getVariables().get("executionLabels")).isEqualTo(Map.of("execution-label", "execution"));
    }

    @Test
    void success_withDynamicLabels() {
        var flow = io.kestra.core.models.flows.Flow.builder()
            .id("flow-with-flow-trigger")
            .namespace("io.kestra.unittest")
            .revision(1)
            .tasks(
                Collections.singletonList(
                    Return.builder()
                        .id("test")
                        .type(Return.class.getName())
                        .format(Property.ofValue("test"))
                        .build()
                )
            )
            .build();
        var triggeringExecution = Execution.builder()
            .id(IdUtils.create())
            .namespace("io.kestra.unittest.upstream")
            .flowId("upstream-flow")
            .flowRevision(1)
            .state(new State().withState(State.Type.RUNNING))
            .build();
        var flowTrigger = Flow.builder()
            .id("flow")
            .type(Flow.class.getName())
            .labels(
                List.of(
                    new Label("triggering-execution-id", "{{ trigger.executionId }}"),
                    new Label("triggering-namespace", "{{ trigger.namespace }}"),
                    new Label("triggering-flow-id", "{{ trigger.flowId }}")
                )
            )
            .build();

        Optional<Execution> evaluate = flowTrigger.evaluate(
            Optional.empty(),
            runContextFactory.of(),
            flow,
            triggeringExecution,
            Map.of()
        );

        assertThat(evaluate.isPresent()).isTrue();
        assertThat(LabelService.labelsExcludingSystem(evaluate.get().getLabels()))
            .containsExactlyInAnyOrder(
                new Label("triggering-execution-id", triggeringExecution.getId()),
                new Label("triggering-namespace", "io.kestra.unittest.upstream"),
                new Label("triggering-flow-id", "upstream-flow")
            );
    }

    @Test
    void success_withInvalidDynamicLabel() {
        var flow = io.kestra.core.models.flows.Flow.builder()
            .id("flow-with-flow-trigger")
            .namespace("io.kestra.unittest")
            .revision(1)
            .tasks(
                Collections.singletonList(
                    Return.builder()
                        .id("test")
                        .type(Return.class.getName())
                        .format(Property.ofValue("test"))
                        .build()
                )
            )
            .build();
        var triggeringExecution = Execution.builder()
            .id(IdUtils.create())
            .namespace("io.kestra.unittest.upstream")
            .flowId("upstream-flow")
            .flowRevision(1)
            .state(new State().withState(State.Type.RUNNING))
            .build();
        var flowTrigger = Flow.builder()
            .id("flow")
            .type(Flow.class.getName())
            .labels(
                List.of(
                    new Label("triggering-execution-id", "{{ trigger.executionId }}"),
                    new Label("unknown-trigger-field", "{{ trigger.doesNotExist }}") // should be omitted, not fail the evaluation
                )
            )
            .build();

        Optional<Execution> evaluate = flowTrigger.evaluate(
            Optional.empty(),
            runContextFactory.of(),
            flow,
            triggeringExecution,
            Map.of()
        );

        assertThat(evaluate.isPresent()).isTrue();
        assertThat(LabelService.labelsExcludingSystem(evaluate.get().getLabels()))
            .containsExactly(new Label("triggering-execution-id", triggeringExecution.getId()));
        assertThat(evaluate.get().getLabels()).noneMatch(label -> label.key().equals("unknown-trigger-field"));
    }
}
