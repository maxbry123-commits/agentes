package forwardedheaders

import (
	"crypto/tls"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestServeHTTP(t *testing.T) {
	testCases := []struct {
		desc              string
		insecure          bool
		trustedIps        []string
		connectionHeaders []string
		addSchemeHeaders  bool
		incomingHeaders   map[string][]string
		remoteAddr        string
		expectedHeaders   map[string]string
		tls               bool
		websocket         bool
		host              string
		absentHeaders     []string
	}{
		{
			desc:            "all Empty",
			insecure:        true,
			trustedIps:      nil,
			remoteAddr:      "",
			incomingHeaders: map[string][]string{},
			expectedHeaders: map[string]string{
				XForwardedFor:               "",
				XForwardedURI:               "",
				XForwardedMethod:            "",
				xForwardedTLSClientCert:     "",
				xForwardedTLSClientCertInfo: "",
			},
		},
		{
			desc:       "insecure true with incoming X-Forwarded headers",
			insecure:   true,
			trustedIps: nil,
			remoteAddr: "",
			incomingHeaders: map[string][]string{
				XForwardedFor:               {"10.0.1.0, 10.0.1.12"},
				XForwardedURI:               {"/bar"},
				XForwardedMethod:            {"GET"},
				xForwardedTLSClientCert:     {"Cert"},
				xForwardedTLSClientCertInfo: {"CertInfo"},
				XForwardedPrefix:            {"/prefix"},
				"X_forwarded_proto":         {"https"},
				"X_forwarded_for":           {"10.0.0.1"},
			},
			expectedHeaders: map[string]string{
				XForwardedFor:               "10.0.1.0, 10.0.1.12",
				XForwardedURI:               "/bar",
				XForwardedMethod:            "GET",
				xForwardedTLSClientCert:     "Cert",
				xForwardedTLSClientCertInfo: "CertInfo",
				XForwardedPrefix:            "/prefix",
				"X_forwarded_proto":         "https",
				"X_forwarded_for":           "10.0.0.1",
			},
		},
		{
			desc:       "insecure false with incoming X-Forwarded headers",
			insecure:   false,
			trustedIps: nil,
			remoteAddr: "",
			incomingHeaders: map[string][]string{
				XForwardedFor:               {"10.0.1.0, 10.0.1.12"},
				XForwardedURI:               {"/bar"},
				XForwardedMethod:            {"GET"},
				xForwardedTLSClientCert:     {"Cert"},
				xForwardedTLSClientCertInfo: {"CertInfo"},
				XForwardedPrefix:            {"/prefix"},
				"X_forwarded_proto":         {"https"},
				"X_forwarded_for":           {"10.0.0.1"},
				"X_forwarded_host":          {"evil.example"},
			},
			expectedHeaders: map[string]string{
				XForwardedFor:               "",
				XForwardedURI:               "",
				XForwardedMethod:            "",
				xForwardedTLSClientCert:     "",
				xForwardedTLSClientCertInfo: "",
				XForwardedPrefix:            "",
				"X_forwarded_proto":         "",
				"X_forwarded_for":           "",
				"X_forwarded_host":          "",
			},
		},
		{
			desc:       "insecure false with incoming X-Forwarded headers and valid Trusted Ips",
			insecure:   false,
			trustedIps: []string{"10.0.1.100"},
			remoteAddr: "10.0.1.100:80",
			incomingHeaders: map[string][]string{
				XForwardedFor:               {"10.0.1.0, 10.0.1.12"},
				XForwardedURI:               {"/bar"},
				XForwardedMethod:            {"GET"},
				xForwardedTLSClientCert:     {"Cert"},
				xForwardedTLSClientCertInfo: {"CertInfo"},
				XForwardedPrefix:            {"/prefix"},
				"X_forwarded_proto":         {"https"},
				"X_forwarded_for":           {"10.0.0.1"},
			},
			expectedHeaders: map[string]string{
				XForwardedFor:               "10.0.1.0, 10.0.1.12",
				XForwardedURI:               "/bar",
				XForwardedMethod:            "GET",
				xForwardedTLSClientCert:     "Cert",
				xForwardedTLSClientCertInfo: "CertInfo",
				XForwardedPrefix:            "/prefix",
				"X_forwarded_proto":         "https",
				"X_forwarded_for":           "10.0.0.1",
			},
		},
		{
			desc:       "insecure false with incoming X-Forwarded headers and invalid Trusted Ips",
			insecure:   false,
			trustedIps: []string{"10.0.1.100"},
			remoteAddr: "10.0.1.101:80",
			incomingHeaders: map[string][]string{
				XForwardedFor:               {"10.0.1.0, 10.0.1.12"},
				XForwardedURI:               {"/bar"},
				XForwardedMethod:            {"GET"},
				xForwardedTLSClientCert:     {"Cert"},
				xForwardedTLSClientCertInfo: {"CertInfo"},
				XForwardedPrefix:            {"/prefix"},
			},
			expectedHeaders: map[string]string{
				XForwardedFor:               "",
				XForwardedURI:               "",
				XForwardedMethod:            "",
				xForwardedTLSClientCert:     "",
				xForwardedTLSClientCertInfo: "",
				XForwardedPrefix:            "",
			},
		},
		{
			desc:       "insecure false with incoming X-Forwarded headers and valid Trusted Ips CIDR",
			insecure:   false,
			trustedIps: []string{"1.2.3.4/24"},
			remoteAddr: "1.2.3.156:80",
			incomingHeaders: map[string][]string{
				XForwardedFor:               {"10.0.1.0, 10.0.1.12"},
				XForwardedURI:               {"/bar"},
				XForwardedMethod:            {"GET"},
				xForwardedTLSClientCert:     {"Cert"},
				xForwardedTLSClientCertInfo: {"CertInfo"},
				XForwardedPrefix:            {"/prefix"},
			},
			expectedHeaders: map[string]string{
				XForwardedFor:               "10.0.1.0, 10.0.1.12",
				XForwardedURI:               "/bar",
				XForwardedMethod:            "GET",
				xForwardedTLSClientCert:     "Cert",
				xForwardedTLSClientCertInfo: "CertInfo",
				XForwardedPrefix:            "/prefix",
			},
		},
		{
			desc:       "insecure false with incoming X-Forwarded headers and invalid Trusted Ips CIDR",
			insecure:   false,
			trustedIps: []string{"1.2.3.4/24"},
			remoteAddr: "10.0.1.101:80",
			incomingHeaders: map[string][]string{
				XForwardedFor:               {"10.0.1.0, 10.0.1.12"},
				XForwardedURI:               {"/bar"},
				XForwardedMethod:            {"GET"},
				xForwardedTLSClientCert:     {"Cert"},
				xForwardedTLSClientCertInfo: {"CertInfo"},
				XForwardedPrefix:            {"/prefix"},
			},
			expectedHeaders: map[string]string{
				XForwardedFor:               "",
				XForwardedURI:               "",
				XForwardedMethod:            "",
				xForwardedTLSClientCert:     "",
				xForwardedTLSClientCertInfo: "",
				XForwardedPrefix:            "",
			},
		},
		{
			desc:     "xForwardedFor with multiple header(s) values",
			insecure: true,
			incomingHeaders: map[string][]string{
				XForwardedFor: {
					"10.0.0.4, 10.0.0.3",
					"10.0.0.2, 10.0.0.1",
					"10.0.0.0",
				},
			},
			expectedHeaders: map[string]string{
				XForwardedFor: "10.0.0.4, 10.0.0.3, 10.0.0.2, 10.0.0.1, 10.0.0.0",
			},
		},
		{
			desc:       "xRealIP populated from remote address",
			remoteAddr: "10.0.1.101:80",
			expectedHeaders: map[string]string{
				xRealIP: "10.0.1.101",
			},
		},
		{
			desc:       "xRealIP was already populated from previous headers",
			insecure:   true,
			remoteAddr: "10.0.1.101:80",
			incomingHeaders: map[string][]string{
				xRealIP: {"10.0.1.12"},
			},
			expectedHeaders: map[string]string{
				xRealIP: "10.0.1.12",
			},
		},
		{
			desc: "xForwardedProto with no tls",
			tls:  false,
			expectedHeaders: map[string]string{
				XForwardedProto: "http",
			},
		},
		{
			desc: "xForwardedProto with tls",
			tls:  true,
			expectedHeaders: map[string]string{
				XForwardedProto: "https",
			},
		},
		{
			desc:             "xForwardedScheme headers with tls",
			tls:              true,
			addSchemeHeaders: true,
			expectedHeaders: map[string]string{
				XForwardedProto:  "https",
				xForwardedScheme: "https",
				xScheme:          "https",
			},
		},
		{
			desc: "xForwardedScheme headers disabled keeps legacy headers absent",
			tls:  true,
			expectedHeaders: map[string]string{
				XForwardedProto: "https",
			},
			absentHeaders: []string{xForwardedScheme, xScheme},
		},
		{
			desc:      "xForwardedProto with websocket",
			tls:       false,
			websocket: true,
			expectedHeaders: map[string]string{
				XForwardedProto: "ws",
			},
		},
		{
			desc:             "xForwardedScheme headers with websocket",
			websocket:        true,
			addSchemeHeaders: true,
			expectedHeaders: map[string]string{
				XForwardedProto:  "ws",
				xForwardedScheme: "ws",
				xScheme:          "ws",
			},
		},
		{
			desc:      "xForwardedProto with websocket and tls",
			tls:       true,
			websocket: true,
			expectedHeaders: map[string]string{
				XForwardedProto: "wss",
			},
		},
		{
			desc:             "xForwardedScheme headers with websocket and tls",
			tls:              true,
			websocket:        true,
			addSchemeHeaders: true,
			expectedHeaders: map[string]string{
				XForwardedProto:  "wss",
				xForwardedScheme: "wss",
				xScheme:          "wss",
			},
		},
		{
			desc:      "xForwardedProto with websocket and tls and already x-forwarded-proto with wss",
			tls:       true,
			websocket: true,
			incomingHeaders: map[string][]string{
				XForwardedProto: {"wss"},
			},
			expectedHeaders: map[string]string{
				XForwardedProto: "wss",
			},
		},
		{
			desc:             "xForwardedScheme headers overwrite in insecure mode",
			insecure:         true,
			addSchemeHeaders: true,
			incomingHeaders: map[string][]string{
				XForwardedProto:  {"https"},
				xForwardedScheme: {"external-https"},
				xScheme:          {"external-https"},
			},
			expectedHeaders: map[string]string{
				XForwardedProto:  "https",
				xForwardedScheme: "https",
				xScheme:          "https",
			},
		},
		{
			desc: "xForwardedPort with explicit port",
			host: "foo.com:8080",
			expectedHeaders: map[string]string{
				XForwardedPort: "8080",
			},
		},
		{
			desc: "xForwardedPort with implicit tls port from proto header",
			// setting insecure just so our initial xForwardedProto does not get cleaned
			insecure: true,
			incomingHeaders: map[string][]string{
				XForwardedProto: {"https"},
			},
			expectedHeaders: map[string]string{
				XForwardedProto: "https",
				XForwardedPort:  "443",
			},
		},
		{
			desc: "xForwardedPort with implicit tls port from TLS in req",
			tls:  true,
			expectedHeaders: map[string]string{
				XForwardedPort: "443",
			},
		},
		{
			desc: "xForwardedHost from req host",
			host: "foo.com:8080",
			expectedHeaders: map[string]string{
				XForwardedHost: "foo.com:8080",
			},
		},
		{
			desc: "xForwardedServer from req XForwarded",
			host: "foo.com:8080",
			expectedHeaders: map[string]string{
				xForwardedServer: "foo.com:8080",
			},
		},
		{
			desc:     "Untrusted: Connection header has no effect on X- forwarded headers",
			insecure: false,
			incomingHeaders: map[string][]string{
				connection: {
					XForwardedProto,
					XForwardedFor,
					XForwardedURI,
					XForwardedMethod,
					XForwardedHost,
					XForwardedPort,
					xForwardedTLSClientCert,
					xForwardedTLSClientCertInfo,
					XForwardedPrefix,
					xRealIP,
					"X_forwarded_proto",
				},
				XForwardedProto:             {"foo"},
				XForwardedFor:               {"foo"},
				XForwardedURI:               {"foo"},
				XForwardedMethod:            {"foo"},
				XForwardedHost:              {"foo"},
				XForwardedPort:              {"foo"},
				xForwardedTLSClientCert:     {"foo"},
				xForwardedTLSClientCertInfo: {"foo"},
				XForwardedPrefix:            {"foo"},
				xRealIP:                     {"foo"},
				"X_forwarded_proto":         {"spoofed"},
			},
			expectedHeaders: map[string]string{
				XForwardedProto:             "http",
				XForwardedFor:               "",
				XForwardedURI:               "",
				XForwardedMethod:            "",
				XForwardedHost:              "",
				XForwardedPort:              "80",
				xForwardedTLSClientCert:     "",
				xForwardedTLSClientCertInfo: "",
				XForwardedPrefix:            "",
				xRealIP:                     "",
				"X_forwarded_proto":         "",
				connection:                  "",
			},
		},
		{
			desc:     "Trusted (insecure): Connection header has no effect on X- forwarded headers",
			insecure: true,
			incomingHeaders: map[string][]string{
				connection: {
					XForwardedProto,
					XForwardedFor,
					XForwardedURI,
					XForwardedMethod,
					XForwardedHost,
					XForwardedPort,
					xForwardedTLSClientCert,
					xForwardedTLSClientCertInfo,
					XForwardedPrefix,
					xRealIP,
				},
				XForwardedProto:             {"foo"},
				XForwardedFor:               {"foo"},
				XForwardedURI:               {"foo"},
				XForwardedMethod:            {"foo"},
				XForwardedHost:              {"foo"},
				XForwardedPort:              {"foo"},
				xForwardedTLSClientCert:     {"foo"},
				xForwardedTLSClientCertInfo: {"foo"},
				XForwardedPrefix:            {"foo"},
				xRealIP:                     {"foo"},
			},
			expectedHeaders: map[string]string{
				XForwardedProto:             "foo",
				XForwardedFor:               "foo",
				XForwardedURI:               "foo",
				XForwardedMethod:            "foo",
				XForwardedHost:              "foo",
				XForwardedPort:              "foo",
				xForwardedTLSClientCert:     "foo",
				xForwardedTLSClientCertInfo: "foo",
				XForwardedPrefix:            "foo",
				xRealIP:                     "foo",
				connection:                  "",
			},
		},
		{
			desc:     "Untrusted and Connection: Connection header has no effect on X- forwarded headers",
			insecure: false,
			connectionHeaders: []string{
				XForwardedProto,
				XForwardedFor,
				XForwardedURI,
				XForwardedMethod,
				XForwardedHost,
				XForwardedPort,
				xForwardedTLSClientCert,
				xForwardedTLSClientCertInfo,
				XForwardedPrefix,
				xRealIP,
			},
			incomingHeaders: map[string][]string{
				connection: {
					XForwardedProto,
					XForwardedFor,
					XForwardedURI,
					XForwardedMethod,
					XForwardedHost,
					XForwardedPort,
					xForwardedTLSClientCert,
					xForwardedTLSClientCertInfo,
					XForwardedPrefix,
					xRealIP,
				},
				XForwardedProto:             {"foo"},
				XForwardedFor:               {"foo"},
				XForwardedURI:               {"foo"},
				XForwardedMethod:            {"foo"},
				XForwardedHost:              {"foo"},
				XForwardedPort:              {"foo"},
				xForwardedTLSClientCert:     {"foo"},
				xForwardedTLSClientCertInfo: {"foo"},
				XForwardedPrefix:            {"foo"},
				xRealIP:                     {"foo"},
			},
			expectedHeaders: map[string]string{
				XForwardedProto:             "http",
				XForwardedFor:               "",
				XForwardedURI:               "",
				XForwardedMethod:            "",
				XForwardedHost:              "",
				XForwardedPort:              "80",
				xForwardedTLSClientCert:     "",
				xForwardedTLSClientCertInfo: "",
				XForwardedPrefix:            "",
				xRealIP:                     "",
				connection:                  "",
			},
		},
		{
			desc:     "Trusted (insecure) and Connection: Connection header has no effect on X- forwarded headers",
			insecure: true,
			connectionHeaders: []string{
				XForwardedProto,
				XForwardedFor,
				XForwardedURI,
				XForwardedMethod,
				XForwardedHost,
				XForwardedPort,
				xForwardedTLSClientCert,
				xForwardedTLSClientCertInfo,
				XForwardedPrefix,
				xRealIP,
			},
			incomingHeaders: map[string][]string{
				connection: {
					XForwardedProto,
					XForwardedFor,
					XForwardedURI,
					XForwardedMethod,
					XForwardedHost,
					XForwardedPort,
					xForwardedTLSClientCert,
					xForwardedTLSClientCertInfo,
					XForwardedPrefix,
					xRealIP,
				},
				XForwardedProto:             {"foo"},
				XForwardedFor:               {"foo"},
				XForwardedURI:               {"foo"},
				XForwardedMethod:            {"foo"},
				XForwardedHost:              {"foo"},
				XForwardedPort:              {"foo"},
				xForwardedTLSClientCert:     {"foo"},
				xForwardedTLSClientCertInfo: {"foo"},
				XForwardedPrefix:            {"foo"},
				xRealIP:                     {"foo"},
			},
			expectedHeaders: map[string]string{
				XForwardedProto:             "foo",
				XForwardedFor:               "foo",
				XForwardedURI:               "foo",
				XForwardedMethod:            "foo",
				XForwardedHost:              "foo",
				XForwardedPort:              "foo",
				xForwardedTLSClientCert:     "foo",
				xForwardedTLSClientCertInfo: "foo",
				XForwardedPrefix:            "foo",
				xRealIP:                     "foo",
				connection:                  "",
			},
		},
		{
			desc:     "Trusted (insecure) and Connection: Testing case sensitivity on connection Headers param",
			insecure: true,
			connectionHeaders: []string{
				strings.ToLower(XForwardedProto),
				strings.ToLower(XForwardedFor),
				strings.ToLower(XForwardedURI),
				strings.ToLower(XForwardedMethod),
				strings.ToLower(XForwardedHost),
				strings.ToLower(XForwardedPort),
				strings.ToLower(xForwardedTLSClientCert),
				strings.ToLower(xForwardedTLSClientCertInfo),
				strings.ToLower(XForwardedPrefix),
				strings.ToLower(xRealIP),
			},
			incomingHeaders: map[string][]string{
				connection: {
					XForwardedProto,
					XForwardedFor,
					XForwardedURI,
					XForwardedMethod,
					XForwardedHost,
					XForwardedPort,
					xForwardedTLSClientCert,
					xForwardedTLSClientCertInfo,
					XForwardedPrefix,
					xRealIP,
				},
				XForwardedProto:             {"foo"},
				XForwardedFor:               {"foo"},
				XForwardedURI:               {"foo"},
				XForwardedMethod:            {"foo"},
				XForwardedHost:              {"foo"},
				XForwardedPort:              {"foo"},
				xForwardedTLSClientCert:     {"foo"},
				xForwardedTLSClientCertInfo: {"foo"},
				XForwardedPrefix:            {"foo"},
				xRealIP:                     {"foo"},
			},
			expectedHeaders: map[string]string{
				XForwardedProto:             "foo",
				XForwardedFor:               "foo",
				XForwardedURI:               "foo",
				XForwardedMethod:            "foo",
				XForwardedHost:              "foo",
				XForwardedPort:              "foo",
				xForwardedTLSClientCert:     "foo",
				xForwardedTLSClientCertInfo: "foo",
				XForwardedPrefix:            "foo",
				xRealIP:                     "foo",
				connection:                  "",
			},
		},
		{
			desc:     "Trusted (insecure) and Connection: Testing case sensitivity on X- forwarded headers",
			insecure: true,
			incomingHeaders: map[string][]string{
				connection: {
					strings.ToLower(XForwardedProto),
					strings.ToLower(XForwardedFor),
					strings.ToLower(XForwardedURI),
					strings.ToLower(XForwardedMethod),
					strings.ToLower(XForwardedHost),
					strings.ToLower(XForwardedPort),
					strings.ToLower(xForwardedTLSClientCert),
					strings.ToLower(xForwardedTLSClientCertInfo),
					strings.ToLower(XForwardedPrefix),
					strings.ToLower(xRealIP),
				},
				XForwardedProto:             {"foo"},
				XForwardedFor:               {"foo"},
				XForwardedURI:               {"foo"},
				XForwardedMethod:            {"foo"},
				XForwardedHost:              {"foo"},
				XForwardedPort:              {"foo"},
				xForwardedTLSClientCert:     {"foo"},
				xForwardedTLSClientCertInfo: {"foo"},
				XForwardedPrefix:            {"foo"},
				xRealIP:                     {"foo"},
			},
			expectedHeaders: map[string]string{
				XForwardedProto:             "foo",
				XForwardedFor:               "foo",
				XForwardedURI:               "foo",
				XForwardedMethod:            "foo",
				XForwardedHost:              "foo",
				XForwardedPort:              "foo",
				xForwardedTLSClientCert:     "foo",
				xForwardedTLSClientCertInfo: "foo",
				XForwardedPrefix:            "foo",
				xRealIP:                     "foo",
				connection:                  "",
			},
		},
		{
			desc: "Connection: one remove, and one passthrough header",
			connectionHeaders: []string{
				"foo",
			},
			incomingHeaders: map[string][]string{
				connection: {
					"foo",
					"bar",
				},
				"Foo": {"bar"},
				"Bar": {"foo"},
			},
			expectedHeaders: map[string]string{
				"Bar": "",
				"Foo": "bar",
			},
		},
		{
			desc:       "insecure false preserves non-matching underscore headers",
			insecure:   false,
			remoteAddr: "10.0.1.101:80",
			incomingHeaders: map[string][]string{
				"X_custom_header":   {"value"},
				"X_forwarded_proto": {"spoofed"},
			},
			expectedHeaders: map[string]string{
				"X_custom_header":   "value",
				"X_forwarded_proto": "",
			},
		},
	}

	for _, test := range testCases {
		t.Run(test.desc, func(t *testing.T) {
			t.Parallel()

			req, err := http.NewRequest(http.MethodGet, "", nil)
			require.NoError(t, err)

			req.RemoteAddr = test.remoteAddr

			if test.tls {
				req.TLS = &tls.ConnectionState{}
			}

			if test.websocket {
				req.Header.Set(connection, "upgrade")
				req.Header.Set(upgrade, "websocket")
			}

			if test.host != "" {
				req.Host = test.host
			}

			for k, values := range test.incomingHeaders {
				for _, value := range values {
					req.Header.Add(k, value)
				}
			}

			m, err := NewXForwarded(test.insecure, test.trustedIps, test.connectionHeaders, false, test.addSchemeHeaders,
				http.HandlerFunc(func(_ http.ResponseWriter, _ *http.Request) {}))
			require.NoError(t, err)

			if test.host != "" {
				m.hostname = test.host
			}

			m.ServeHTTP(nil, req)

			for k, v := range test.expectedHeaders {
				assert.Equal(t, v, req.Header.Get(k))
			}

			for _, header := range test.absentHeaders {
				assert.NotContains(t, req.Header, http.CanonicalHeaderKey(header))
			}
		})
	}
}

func Test_isWebsocketRequest(t *testing.T) {
	testCases := []struct {
		desc             string
		connectionHeader string
		upgradeHeader    string
		assert           assert.BoolAssertionFunc
	}{
		{
			desc:             "connection Header multiple values middle",
			connectionHeader: "foo,upgrade,bar",
			upgradeHeader:    "websocket",
			assert:           assert.True,
		},
		{
			desc:             "connection Header multiple values end",
			connectionHeader: "foo,bar,upgrade",
			upgradeHeader:    "websocket",
			assert:           assert.True,
		},
		{
			desc:             "connection Header multiple values begin",
			connectionHeader: "upgrade,foo,bar",
			upgradeHeader:    "websocket",
			assert:           assert.True,
		},
		{
			desc:             "connection Header no upgrade",
			connectionHeader: "foo,bar",
			upgradeHeader:    "websocket",
			assert:           assert.False,
		},
		{
			desc:             "connection Header empty",
			connectionHeader: "",
			upgradeHeader:    "websocket",
			assert:           assert.False,
		},
		{
			desc:             "no header values",
			connectionHeader: "foo,bar",
			upgradeHeader:    "foo,bar",
			assert:           assert.False,
		},
		{
			desc:             "upgrade header multiple values",
			connectionHeader: "upgrade",
			upgradeHeader:    "foo,bar,websocket",
			assert:           assert.True,
		},
	}

	for _, test := range testCases {
		t.Run(test.desc, func(t *testing.T) {
			t.Parallel()

			req := httptest.NewRequest(http.MethodGet, "http://localhost", nil)

			req.Header.Set(connection, test.connectionHeader)
			req.Header.Set(upgrade, test.upgradeHeader)

			ok := isWebsocketRequest(req)

			test.assert(t, ok)
		})
	}
}

func TestConnection(t *testing.T) {
	testCases := []struct {
		desc              string
		reqHeaders        map[string]string
		connectionHeaders []string
		expected          http.Header
	}{
		{
			desc: "simple remove",
			reqHeaders: map[string]string{
				"Foo":      "bar",
				connection: "foo",
			},
			expected: http.Header{},
		},
		{
			desc: "remove and upgrade",
			reqHeaders: map[string]string{
				upgrade:    "test",
				"Foo":      "bar",
				connection: "upgrade,foo",
			},
			expected: http.Header{
				upgrade:    []string{"test"},
				connection: []string{"Upgrade"},
			},
		},
		{
			desc: "no remove",
			reqHeaders: map[string]string{
				"Foo":      "bar",
				connection: "fii",
			},
			expected: http.Header{
				"Foo": []string{"bar"},
			},
		},
		{
			desc: "no remove because connection header pass through",
			reqHeaders: map[string]string{
				"Foo":      "bar",
				connection: "Foo",
			},
			connectionHeaders: []string{"Foo"},
			expected: http.Header{
				"Foo":      []string{"bar"},
				connection: []string{"Foo"},
			},
		},
	}

	for _, test := range testCases {
		t.Run(test.desc, func(t *testing.T) {
			t.Parallel()

			forwarded, err := NewXForwarded(true, nil, test.connectionHeaders, false, false, nil)
			require.NoError(t, err)

			req := httptest.NewRequest(http.MethodGet, "https://localhost", nil)

			for k, v := range test.reqHeaders {
				req.Header.Set(k, v)
			}

			forwarded.removeConnectionHeaders(req)

			assert.Equal(t, test.expected, req.Header)
		})
	}
}
