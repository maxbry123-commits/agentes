# Changelog

All notable changes to this project will be documented in this file. See [conventional commits](https://www.conventionalcommits.org/) for commit guidelines.

## [0.226.2](https://github.com/boundaryml/baml/compare/0.226.1..0.226.2) - 2026-08-31

### Miscellaneous Chores

- publish a clean follow-up BAML v0 release after a 0.226.1 source archive checksum mismatch was reported between proxy.golang.org and GitHub

## [0.226.1](https://github.com/boundaryml/baml/compare/0.226.0..0.226.1) - 2026-08-18

### Bug Fixes

- **(openai)** accept both Chat Completions and Responses API token-detail fields ([#4503](https://github.com/BoundaryML/baml/pull/4503)) - ([378cdcc](https://github.com/BoundaryML/baml/commit/378cdcce3c60706cef603b2d7c9b23d4e536d52e)) - Sam Lijin

## [0.226.0](https://github.com/boundaryml/baml/compare/0.225.0..0.226.0) - 2026-08-17

### Features

- **(runtime)** make connection pooling configurable ([#3975](https://github.com/BoundaryML/baml/pull/3975)) - ([521919c](https://github.com/BoundaryML/baml/commit/521919c7f58b0b930ae1709df1882651db8ca865)) - Dex Hunter
- **(openai)** add `/v1/audio/transcriptions` endpoint support ([#4202](https://github.com/BoundaryML/baml/pull/4202)) - ([79b8705](https://github.com/BoundaryML/baml/commit/79b87056604730012066633fb0fdcb0f93c07bb7)) - Maceo

## [0.225.0](https://github.com/boundaryml/baml/compare/0.224.0..0.225.0) - 2026-07-31

### Docs

- brand legacy releases as BAML v0 (#4297) - ([5dbd250](https://github.com/boundaryml/baml/commit/5dbd25084b39523854a8967da5f5363b7368f3a6)) - Sam Lijin

## [0.224.0](https://github.com/boundaryml/baml/compare/0.223.0..0.224.0) - 2026-07-30

### Bug Fixes

- **(python)** rebuild generated models so class order cannot break Pydantic (#793, #3819) - ([dce0e79](https://github.com/boundaryml/baml/commit/dce0e798727544293dbca1e7d9466c11700190ee)) - Gourav Singal
- Correct React streaming hook data types for nullable fields (#3905) - ([7ed5f83](https://github.com/boundaryml/baml/commit/7ed5f8395849876bc5e9801f3977ee47d992daef)) - Matt Van Horn
- Prevent `baml test` from hanging on self-referential `.env` variables (#3927) - ([7ac6d80](https://github.com/boundaryml/baml/commit/7ac6d80216a32f6815ca9cfd9a671853bed02463)) - hellovai
- **(zed)** pin the playground version to the Zed extension version (#3853) - ([33a12c0](https://github.com/boundaryml/baml/commit/33a12c013a2a60cd1de7279a45dc976deb1bffb9)) - Sam Lijin
- **(openai)** preserve allowlisted content-block metadata in the Responses API, including `prompt_cache_breakpoint` (#4155) - ([a2aa426](https://github.com/boundaryml/baml/commit/a2aa426f695fbec16d38f924dd783659a8fc8d6b)) - Conrad Scherb

## [0.223.0](https://github.com/boundaryml/baml/compare/0.222.0..0.223.0) - 2026-06-23

- Add render_null_as output format option (#3822) - ([e32d2df](https://github.com/boundaryml/baml/commit/e32d2df278f1b9cca345bcf89e57151a91e19b5e)) - aaronvg
- Bump version to 0.223.0 - ([9c53075](https://github.com/boundaryml/baml/commit/9c530754087f5913d40384055a6eee115991fbed)) - Aaron Villalpando

## [0.222.0](https://github.com/boundaryml/baml/compare/0.221.0..0.222.0) - 2026-04-27

- Bump version to 0.222.0 - ([d3ddbfa](https://github.com/boundaryml/baml/commit/d3ddbfa0d95671c84f120719da193401a08650da)) - Aaron Villalpando

## [0.221.0](https://github.com/boundaryml/baml/compare/0.220.0..0.221.0) - 2026-04-14

### Bug Fixes

- **(jinja)** string formatting should not raise spurious errors (#3263) - ([13112c3](https://github.com/boundaryml/baml/commit/13112c3aabed6d7311b1edf56535adabe3df0b6b)) - Sam Lijin
- **(engine)** fix anthropic on vertex URL building (#3356) - ([973fb19](https://github.com/boundaryml/baml/commit/973fb19046c6f713e5b6ae27e9c56d72c6ec07f0)) - Avery Townsend
- **(engine)** limit markdown parser code block widening (#3359) - ([01ce9e3](https://github.com/boundaryml/baml/commit/01ce9e3d6bd46aee0aeb32b4382a8bbb32e7775f)) - 2kai2kai2
- Fix LSP navigation for class fields, enum variants, and methods (#3298) - ([ccd9110](https://github.com/boundaryml/baml/commit/ccd911085255c4fd7b48e8de3f65cc26433dd72e)) - hellovai
- Fix type checker literal union upcasting issues (#3299) - ([1a2ed81](https://github.com/boundaryml/baml/commit/1a2ed81663f313dfc7fe155146cbcc8af08bbff0)) - hellovai
- Fix VM instanceof crash on null/non-instance values (#3305) - ([ab14b14](https://github.com/boundaryml/baml/commit/ab14b1468eeb93827e0620d55e0082bf6a798769)) - hellovai
- Fix closure-over-loop-variable bug, skip MIR on errors, void test bodies (#3355) - ([41c20a0](https://github.com/boundaryml/baml/commit/41c20a047454077a848c567177b15b2eb42414eb)) - hellovai

### Documentation

- update README editor support section (#3332) - ([fd0f729](https://github.com/boundaryml/baml/commit/fd0f7295b93af5f9650825918fcfaa645fce8473)) - zuyua9

### Features

- **(engine)** allow newlines in union types (#3265) - ([dddd673](https://github.com/boundaryml/baml/commit/dddd67392f1ea0445f4939fa590747be58387ca8)) - 2kai2kai2
- **(engine)** support token caching on AWS bedrock (#3334) - ([438a561](https://github.com/boundaryml/baml/commit/438a56133384ced45e4d5c2ddc9f0d901c134d84)) - 2kai2kai2
- **(engine)** anthropic provider (#3235) - ([11055ed](https://github.com/boundaryml/baml/commit/11055ed4ae3e79c5004a4b50b5c6709e928f24df)) - Avery Townsend
- **(engine)** implement bedrock request builder and generalize request auth (#3242) - ([9672799](https://github.com/boundaryml/baml/commit/96727993d92827b192b467b8be198f7e9643cd83)) - Avery Townsend
- **(rust-sdk)** Add on_tick streaming callback with FunctionLog support (#3333) - ([279db93](https://github.com/boundaryml/baml/commit/279db93d437098fbfc7aeae289ec7123da5d0ebb)) - hellovai
- add lambda expression support to BAML compiler (#3302) - ([7d24545](https://github.com/boundaryml/baml/commit/7d2454594e454adba6284b8bc47206e27d3cb543)) - hellovai
- implement BEP-020 optional chaining (?.) and null coalescing (??) (#3267) - ([9db2347](https://github.com/boundaryml/baml/commit/9db2347b98a3d44d2a1299196a3070ca923ffd40)) - Antonio Sarosi
- add dynamic test/testset expression syntax for BAML (#3317) - ([96a398f](https://github.com/boundaryml/baml/commit/96a398f692d3bf1c88f29fd0ed3b1e187b1bfda8)) - hellovai
- add void return type support to function syntax (#3346) - ([56132e7](https://github.com/boundaryml/baml/commit/56132e71c0c15f01406e4ed435b95c31ce567110)) - hellovai
- Stub nuget package (#3243) - ([c261c17](https://github.com/boundaryml/baml/commit/c261c1738e94ef691fc5ba05696b58cdaa790373)) - 2kai2kai2
- Raise error messages from baml-cli optimize (#3244) - ([69c46f0](https://github.com/boundaryml/baml/commit/69c46f0ab03eaff19e99932c88e2e469e38bd99d)) - Greg Hale
- Implement ns_* folder-based namespace system (#3292) - ([248a49f](https://github.com/boundaryml/baml/commit/248a49fd3ccb8daf6bea61cfcd4befb278605d11)) - hellovai
- Improve reporting of jsonish errors (#3308) - ([fa79810](https://github.com/boundaryml/baml/commit/fa79810d513c867fdc0944bb1ba9b32063deb358)) - Greg Hale
- LLM function output format (#3311) - ([7b5f543](https://github.com/boundaryml/baml/commit/7b5f5434c4c479eb1495c3b5e48a20611dc90771)) - 2kai2kai2
- Add baml-cli generate and integ-tests (#3315) - ([f749248](https://github.com/boundaryml/baml/commit/f7492482e5ee3f8b61eb45fcfca514a842daaf41)) - Greg Hale
- baml grep and baml describe - agent-oriented semantic search tools (#3347) - ([661c525](https://github.com/boundaryml/baml/commit/661c525d57258247d1ffb7068aa0cef4b1375859)) - Greg Hale
- Capture stack traces in thrown errors with source line numbers (#3339) - ([2f99bbc](https://github.com/boundaryml/baml/commit/2f99bbc486f1b5d5205a36019b54555e2bc7bbde)) - Antonio Sarosi

### Miscellaneous Chores

- Bump version to 0.221.0 - ([0104184](https://github.com/boundaryml/baml/commit/0104184b11288047692261343102f0c857b6f2db)) - Aaron Villalpando

## [0.220.0](https://github.com/boundaryml/baml/compare/0.219.0..0.220.0) - 2026-03-11

### Bug Fixes

- **(go-cffi)** fix deadlock and panics under high concurrency (#3185) - ([06ed5c3](https://github.com/boundaryml/baml/commit/06ed5c33b328fa5edf205de9cf14d5f9ddcd7957)) - Tsvetomir Bonev
- **(tracing)** TS tracing now respects process.env.BOUNDARY_API_KEY=... (#3219) - ([1b06fd1](https://github.com/boundaryml/baml/commit/1b06fd15b29ee93cfa6baf4339046da8ebecf76a)) - Sam Lijin

### Documentation

- document the Rust generated client (#3197) - ([86f864d](https://github.com/boundaryml/baml/commit/86f864df75fef06b5589edd96c3e1fb91abe8acd)) - Sam Lijin

### Features
- **(jinja)** add format() support (#3149) - ([9b695bd](https://github.com/boundaryml/baml/commit/9b695bd2b7e0e4c84069fafda6ef85415fabc2e9)) - Sam Lijin


## [0.219.0](https://github.com/boundaryml/baml/compare/0.218.1..0.219.0) - 2026-02-12

### Bug Fixes

- allow 'baml-cli serv' to handle big PDFs (#3046) - ([8cb8016](https://github.com/boundaryml/baml/commit/8cb8016413de3c14955b990b1556225831c654f1)) - Sam Lijin
- fix vercel build, show last known prompt if there's errors (#3077)
- fix template_string rendering in test data (#3091)
- Add cancel_notify support and test for Ctrl+C in test executor (#3074) - ([065e40c](https://github.com/boundaryml/baml/commit/065e40cfe618664594f3cb2e35ed33e661096242)) - hellovai
- Add build_request to CFFI, Go runtime/codegen, and Rust codegen (#3089) - ([a6c3995](https://github.com/boundaryml/baml/commit/a6c3995598bebc534a23f3bc326410b563cb9514)) - hellovai
- Lint jinja templates in baml_language (#3086) - ([0728974](https://github.com/boundaryml/baml/commit/07289746eacc1571cdf905d6c849f27aa6b3d1a6)) - Greg Hale
- Bump version to 0.219.0 - ([8fe1083](https://github.com/boundaryml/baml/commit/8fe10832b61de002293efec577a514ffe5ff7be3)) - Aaron Villalpando

## [0.218.1](https://github.com/boundaryml/baml/compare/0.218.0..0.218.1) - 2026-01-27

### Bug Fixes
- Fix streaming retries not working (#3025) - ([149a9ae](https://github.com/boundaryml/baml/commit/149a9ae5748664659888b4d2d53c3eb8df7c33d3)) - Antonio Sarosi
- **(zed)** get zed extension working again (#3024) - ([95934b7](https://github.com/boundaryml/baml/commit/95934b793455983e5e7d77a2c1d17ef6d5943906)) - Sam Lijin
- proxy toggling error message (#3026) - ([cc2a120](https://github.com/boundaryml/baml/commit/cc2a12044eadb561b15dfca1d6f48d4d66ec5e20)) - Sam Lijin
- make HMR test pass (#3029) - ([03e95d2](https://github.com/boundaryml/baml/commit/03e95d2de94640c55d34a1debdcaa1ffedf63319)) - Sam Lijin
- fix issue with vscode 'unspecified error' where CORS proxy wasnt enabled (#3034)
- Fix Vertex AI credential parsing for double-quoted JSON (#3028) - ([68f4ad6](https://github.com/boundaryml/baml/commit/68f4ad6918c1d68c739718bb5940349575c73bd3)) - Dave Laird

### Features
- support --turbo build for Next.js (#2422) - ([9ef044b](https://github.com/boundaryml/baml/commit/9ef044b6bf8d2414ce959f28865732bd8f444549)) - Chris Watts


## [0.218.0](https://github.com/boundaryml/baml/compare/0.217.0..0.218.0) - 2026-01-22

### Bug Fixes
- Fix Go serde decoding for dynamic types (#2978) - ([f3e48fd](https://github.com/boundaryml/baml/commit/f3e48fdc3f5f686b10ba6fa2638495ca7539fcee)) - hellovai
- Fix Go codegen for pure-dynamic classes (@@dynamic with no static fields) (#2995) - ([dcc2323](https://github.com/boundaryml/baml/commit/dcc2323639ac5b5ad777dd935f2527a3b6b97b41)) - hellovai
- **(cffi)** wrap result and error callbacks in block_in_place (#2989) - ([c31ae86](https://github.com/boundaryml/baml/commit/c31ae8666c3d1a4e26d046cd6aa5b58ffc37ca18)) - Tsvetomir Bonev
- **(go)** handle optional image encoding (*types.Image) (#2996) - ([d3d76dc](https://github.com/boundaryml/baml/commit/d3d76dc7634472d3673ea88a3913b938c7ea99d0)) - hellovai
- **(react)** use NDJSON format for streaming to handle TCP chunk boundaries (#3000) - ([d4edca7](https://github.com/boundaryml/baml/commit/d4edca77c6bf7e9f2e7d898082adc4093ced7e01)) - Antonio Sarosi
- **(ts)** add BamlError base class and improve error hierarchy (#2993) (#3012) - ([807e702](https://github.com/boundaryml/baml/commit/807e702e8dfd8caff3acd23e4865e2b7701ced5d)) - Antonio Sarosi

- fix playground index on test history (#3005)
- Fix API key dialog not showing for new users (#2999) - ([6cb3b60](https://github.com/boundaryml/baml/commit/6cb3b60efe8eb2b2fcb7a37cdf9e0a479ad41b42)) - Paulo Rossi Rodrigues

### Documentation

- Azure AI Foundary -> Foundry typo (#2965) - ([48da42a](https://github.com/boundaryml/baml/commit/48da42ae4ce611df50c38e541a8bd56025b9f014)) - Sam Lijin


## [0.217.0](https://github.com/boundaryml/baml/compare/0.216.0..0.217.0) - 2026-01-10

### Bug Fixes

- **(zed)** Fix version (#2953) - ([a9c4d7b](https://github.com/boundaryml/baml/commit/a9c4d7b14fd8024a373c58768f4eb943ec662838)) - Sam Lijin
- fix TimeoutError and InvalidArgumentError getting raised as BamlError (#2954)
  
### Features

- Add native Rust SDK (#2832) - ([0b4d81a](https://github.com/boundaryml/baml/commit/0b4d81a3861efe49fc41d58c7464c6ae7388ce8c)) - hellovai
- wire @description to pydantic models Field attribute (#2955) - ([ff4970a](https://github.com/boundaryml/baml/commit/ff4970ac911243ef0f8e314d1c5103391c39d278)) - Sam Lijin

### Bugs
- Fix media type matching in unions to use file extension heuristics (#2894) - ([cad717c](https://github.com/boundaryml/baml/commit/cad717cf310678fdad8dea38b708262211c764f6)) - Antonio Sarosi
- [Studio] Dont resend the prompt and raw output via BamlValidationError published events (#2914) - ([85a3b35](https://github.com/boundaryml/baml/commit/85a3b35a0ea99980ac0fc2d29b2a1b616bfb9a41)) - aaronvg
- add abort error details (#2921) - ([9172fbc](https://github.com/boundaryml/baml/commit/9172fbcea6405917fd751f519366ffd180d673c1)) - aaronvg
- Fix backwards type checking in Jinja filter validation (#2942) - ([e903222](https://github.com/boundaryml/baml/commit/e903222a92d5993af33e02fa41b518a50b94b4ab)) - Kelvin
- Add on_tick callback tests and fix CFFI streaming callback handling (#2949) - ([db206db](https://github.com/boundaryml/baml/commit/db206dbb192bd1061438835173f2795a39c67de7)) - hellovai
- Fix @skip attribute panic with @@dynamic and non-dynamic classes (#2952) - ([ae13652](https://github.com/boundaryml/baml/commit/ae136524eff94bb364c0086e89569e3c47bc2e5d)) - Antonio Sarosi


## [0.216.0](https://github.com/boundaryml/baml/compare/0.215.2..0.216.0) - 2025-12-31

### Bug Fixes

- **(aws-bedrock)** Pass region to DefaultCredentialsChain for IRSA support (#2856) - ([30ff957](https://github.com/boundaryml/baml/commit/30ff9577f52f69bc3861f8bdb0cf57180d94352e)) - Benjamin Poile
- Fix PDF viewer CSS preload bug (#2876) - ([fb0257b](https://github.com/boundaryml/baml/commit/fb0257bdf9ec0900be9f131a83d2e05d63c33458)) - Antonio Sarosi
- Fix issue where a request would timeout if there was no finish reason payload (#2881) - ([629c14e](https://github.com/boundaryml/baml/commit/629c14e88171f89240713598a156f0a7712d6b6f)) - aaronvg
- Typescript x86 alpine fix (#2887) - ([5c2c6d8](https://github.com/boundaryml/baml/commit/5c2c6d844aa8a4623601dd60c829b608ede771fe)) - aaronvg
- Fix Typescript arm64 linux issue with vertex credentials parsing (#2892) - ([6a97b69](https://github.com/boundaryml/baml/commit/6a97b69c489053ab0fe5ba84115063d31bd0a0cf)) - aaronvg

### Features
- **(codegen)** add `client` option to BamlCallOptions (#2870) - ([3aa56df](https://github.com/boundaryml/baml/commit/3aa56df16e0f68cba1bcc76ff8cb9a43491e29d1)) - hellovai

### Docs
- Documentation seniority format correction (#2857) - ([3bebb8c](https://github.com/boundaryml/baml/commit/3bebb8cdce0fa7efcf0e69ac3ca995615496de5b)) - hellovai
- Clarify how `ClientRegistry.set_primary` works in the docs (#2875) - ([4afec32](https://github.com/boundaryml/baml/commit/4afec32b95cf8c13ae1f895d64465a8ce3ef7a26)) - Antonio Sarosi


## [0.215.2](https://github.com/boundaryml/baml/compare/0.215.1..0.215.2) - 2025-12-22

### Features
- added openrouter first-class support and updated fern docs (#2861) - ([f6de38e](https://github.com/boundaryml/baml/commit/f6de38e6fe29272cfc863d6466d38c086d93fcd5)) - Paulo Rossi Rodrigues

### Fixes
- 0.215.1 release automation broke

## [0.215.1](https://github.com/boundaryml/baml/compare/0.215.0..0.215.1) - 2025-12-20

WARNING: this release is incomplete. Release automation was broken for 0.215.1 and not all artifacts were correctly uploaded.

### Bug Fixes
- Vertex ai model error (#2836) - ([8482c1d](https://github.com/boundaryml/baml/commit/8482c1d06135b35cbaf3715e7dec5e4a841c3d52)) - aaronvg

### Miscellaneous Chores
- fix win arm64 ts release (#2841) - ([19e7dd6](https://github.com/boundaryml/baml/commit/19e7dd662821635e2a182c8219ef8db13ece4c47)) - Sam Lijin
- fix jetbrains release for 2025.2+ (#2842) - ([1252528](https://github.com/boundaryml/baml/commit/12525286db748432b5b887567050ec118f55ad85)) - Sam Lijin
- make npm releases work with OIDC auth (#2843) - ([20d7bb1](https://github.com/boundaryml/baml/commit/20d7bb15c94548c82b769e1d52dd60b48e810246)) - Sam Lijin

## [0.215.0](https://github.com/boundaryml/baml/compare/0.214.0..0.215.0) - 2025-12-18

### Bug Fixes

- golang type system fixes, CFFI refactor, and testing infrastructure (#2778) - ([1afa7e8](https://github.com/boundaryml/baml/commit/1afa7e8dea1d693034a2e54f239c9378f8e091d1)) - hellovai
- fix index bug (#2742) `merge_messages` previously used `foo.len() - 1`. Since `len` is a `USIZE` (unsigned int), size 0 was wrapping after decrement, cau - ([518dc61](https://github.com/boundaryml/baml/commit/518dc610525c8fb0633fa9f63e5c8e27b6e7a78c)) - Greg Hale
- undocumented null return for OpenAI reasoning content (#2803) - ([0012eb1](https://github.com/boundaryml/baml/commit/0012eb1a7515fc23fe7b7011060738bfaaa7c8df)) - Patrick Wadström
- fix variable shadowing bug in generated python/TS clients (#2810) - ([5ae0010](https://github.com/boundaryml/baml/commit/5ae001011559bc29997f6dd04cbbbf65d970b12d)) - Antonio Sarosi
- Fix `baml-cli test` panic when `BOUNDARY_API_KEY` is set (#2779) - ([220ad19](https://github.com/boundaryml/baml/commit/220ad1901fecab2fbe90d92e2306a42c6a10bb62)) - Antonio Sarosi
- Fix some docs about SSE chunks, anthropic not having SSE events in streams, adding comments in prmopt strings with command + / (#2802) - ([c17c93d](https://github.com/boundaryml/baml/commit/c17c93dbeabc3a61bd3de5a101d7f1b04df89fdb)) - aaronvg

### Features

- ts: add windows arm64 support; target glibc 2.17 on linux arm64 (#2771) - ([23f367f](https://github.com/boundaryml/baml/commit/23f367f23c7538ab73284df9e2d6bda744c2c3c4)) - Sam Lijin
- allow users to optimize BAML startup/footprint by trimming tests from inlined baml files (#2772) - ([fe72ecd](https://github.com/boundaryml/baml/commit/fe72ecd83639c36e2054569b0a2fba786948677e)) - Greg Hale
- add option to output_format for quoting class keys in prompts (#2769) - ([969da89](https://github.com/boundaryml/baml/commit/969da89d38093afffd0abe8d30f14b70b70b9a32)) - Greg Hale
- Add search functionality to prompt (#2804) - ([4f7a46b](https://github.com/boundaryml/baml/commit/4f7a46bda53de992b6d3959779bf497e47f09e83)) - aaronvg
- Prompt optimization visualizer (#2807) - ([9d1bf87](https://github.com/boundaryml/baml/commit/9d1bf8734887c8c0bdd6f501498bd56a6229e8c7)) - Greg Hale
- parser performance improvements (#2806) - ([f44cd28](https://github.com/boundaryml/baml/commit/f44cd289e9347dd77bc06562af7e2ef4139689fa)) - aaronvg

### Docs

- how-to integrate with Microsoft Foundry (#2745) - ([83c85b4](https://github.com/boundaryml/baml/commit/83c85b46c9a8241b97e0f803845fa7ae94d3d5ac)) - aaronvg
- Document baml-cffi docker build caching (#2756) - ([fb4d00c](https://github.com/boundaryml/baml/commit/fb4d00c006f61d37e9f81938d91e79eb181a51d4)) - hellovai
- Add project URLs to Pypi (#2712) - ([9e8d731](https://github.com/boundaryml/baml/commit/9e8d731efcdeac2c43cb09ba7f8188812d7c9936)) - Toundra
- Fix react chatbot documentation and implementation (#2770) - ([d1f1842](https://github.com/boundaryml/baml/commit/d1f184291938cdadccccbc6eae649c41c1938de1)) - hellovai
- update prompt caching docs example as caching is now GA for Anthropic (#2790) - ([1811be6](https://github.com/boundaryml/baml/commit/1811be6a771752b8287eae0836dfa98a13ef9c7a)) - Sanjan Das
- Symbol tuning documentation clarification (#2808) - ([46cda11](https://github.com/boundaryml/baml/commit/46cda11033a1e9cc56a209952268176b8bc2b97c)) - hellovai
- optimization docs (#2809) - ([d2971b7](https://github.com/boundaryml/baml/commit/d2971b7f257ecb9c5bcdac64a76e230965fdf119)) - Greg Hale
- Prompt optimization documentation update (#2821) - ([eb82648](https://github.com/boundaryml/baml/commit/eb82648a1095a719d9c3df14ed257e0573badedc)) - hellovai

### Miscellaneous Chores

- switch npm publishing to use OIDC (#2829) - ([c439d98](https://github.com/boundaryml/baml/commit/c439d98fa734b587cc3790cf6da293e7925fe708)) - mendral-app[bot]
- Simplify how docs are generated. Only changes to fern/** or typescript/sage*/* should trigger it. (#2757) - ([d1f3e3a](https://github.com/boundaryml/baml/commit/d1f3e3a1da475ae5c21e3f1f6ef37320ec7af1e4)) - hellovai
- Remove support for deprecated piece of syntax (#2744) - ([6992bd1](https://github.com/boundaryml/baml/commit/6992bd1d1f8f9e2dfbb07a2d088958b6153b6193)) - Greg Hale
- fix zed release workflow (#2816) - ([6df303c](https://github.com/boundaryml/baml/commit/6df303c4415be283ce3b2611b45e114c6e7c280d)) - Sam Lijin
- Fix setup-tools action with directory existence checks (#2741) - ([70f77c7](https://github.com/boundaryml/baml/commit/70f77c71235898c9b393b66e7b0f464049b2135d)) - mendral-app[bot]
- Upgrade all setup-node usages to Node.js v6 (#2785) - ([8c8eea5](https://github.com/boundaryml/baml/commit/8c8eea56790b3b15df4603fae52edd78d86794f2)) - mendral-app[bot]
- Update react in fiddle apps (#2788) - ([e250a9b](https://github.com/boundaryml/baml/commit/e250a9b15ddd4f5db2db25d0892b5a5089ef34b4)) - aaronvg
- update next (#2793) - ([3ff97b2](https://github.com/boundaryml/baml/commit/3ff97b2080a9f8d2d55331dd181b83b434ee85d9)) - aaronvg
- Patch React CVE (#2801) - ([a3934b9](https://github.com/boundaryml/baml/commit/a3934b9347be689f1542431e3e8418a92764099e)) - aaronvg


## [0.214.0](https://github.com/boundaryml/baml/compare/0.213.0..0.214.0) - 2025-11-24

### Bug Fixes
- Reduce logging in playground to prevent freezes - ([43960d4](https://github.com/boundaryml/baml/commit/43960d472466bd0ae16c73af222043f9424ed63b)) - Aaron Villalpando
- fix ask baaaml (#2711)- ([ef62656](https://github.com/boundaryml/baml/commit/ef6265649d8ab593527d9d7646c5c2eb41fd83fc)) - Greg Hale

### Documentation

- documentation fixups (#2735)
- Fixing doc - invalid options for gpt-4.1 model (#2708) - ([5d45cc9](https://github.com/boundaryml/baml/commit/5d45cc9dccbf334062e60fedde140d8e69c75bd9)) - yasonk
- Add docs for OpenAI region selection via base_url
- Fix docs for media constructor functions
- Add example code and description for `media_url_handler` - ([386a5d9](https://github.com/boundaryml/baml/commit/386a5d915c6ff2c5e15f36aa76a2f9396b85a799)) - Greg Hale

### Features

- **(baml)** implement static control flow visualizer (#2716) - ([4c9d507](https://github.com/boundaryml/baml/commit/4c9d50795563748952263a1ce4423f62460e2923)) - Sam Lijin
- **(cli)** load dotenv in baml-cli dev and baml-cli serve (#2703) - ([e6fff13](https://github.com/boundaryml/baml/commit/e6fff13b7a7685e987c4a68a626984b7495ece33)) - Sam Lijin
- **(cli)** hide internal subcommands by default (#2704) - ([a61d28c](https://github.com/boundaryml/baml/commit/a61d28c7b2e06059875605c3ea30d37aad17a7a2)) - Sam Lijin
- **(engine)** Compress serialized logs for boundary studio (#2729) - ([d75255a](https://github.com/boundaryml/baml/commit/d75255a2212c6662f2512a69e4ad132ebfeff020)) - hellovai
- Add toon Jinja filter for token-efficient data serialization (#2720) - ([c2f31a4](https://github.com/boundaryml/baml/commit/c2f31a4c1d2264c9caca610a5f326dc3e547f8d1)) - hellovai

### Miscellaneous Chores

- fix zed release infra (#2705) - ([8aae697](https://github.com/boundaryml/baml/commit/8aae69735617fd9d95e95fe8e543671358d8eb68)) - Sam Lijin


## [0.213.0](https://github.com/boundaryml/baml/compare/0.212.0..0.213.0) - 2025-11-05

### Bug Fixes

- fix bug in baml-cli init not working with claude code (#2697) ([0333467](https://github.com/boundaryml/baml/commit/03334676728ba27704a4e53be062807fb39b2854)) - aaronvg
- select earliest successful LLM call by lexicographic request_id order (#2692) - ([516ef6f](https://github.com/boundaryml/baml/commit/516ef6f76f97774734f4d0a86fc33aae01fa550d)) - Shawn McDonald
- default request timeout is too low (#2698) - ([50c7026](https://github.com/boundaryml/baml/commit/50c7026dc338dedd3b64d3d03129493d40099259)) - aaronvg
- Fix timeout exceptions for streaming LLM calls (#2699) - ([2b751db](https://github.com/boundaryml/baml/commit/2b751db4f97e15dc7afa6b5670b0e4b380eece2c)) - Greg Hale
- [Python] expose BamlAbortError (#2674) - ([1b6efb3](https://github.com/boundaryml/baml/commit/1b6efb3931cd9d5b68de4949f8fff16e3d007a40)) - hellovai

### Features
- expose better error messages out of the runtime so folks can better understand isseus (i/e can plumb cancel messages more correctly) (#2679) - ([af2d872](https://github.com/boundaryml/baml/commit/af2d872cd93ccd4123a79fdcef61a4f5e9989172)) - hellovai
- bedrock video support (#2681) - ([38cfe9b](https://github.com/boundaryml/baml/commit/38cfe9b2eb9196c90558e4461947d270e894f2e0)) - Sam Lijin

### Miscellaneous Chores

- add apache-2 license to engine/zed (#2670) - ([c1ec923](https://github.com/boundaryml/baml/commit/c1ec923b9be2e1f3ac2b3dddb7f7c0acc27d5132)) - Sam Lijin


## [0.212.0](https://github.com/boundaryml/baml/compare/0.211.2..0.212.0) - 2025-10-27

### Bug Fixes

- Fix issue where a test would stay stuck in running if there was a wasm panic (#2601) - ([ac0ede8](https://github.com/boundaryml/baml/commit/ac0ede85306c6dada5423faeb651aa0288497410)) - aaronvg
- Move class descriptions inside braces for better formatting (#2646) - ([71cc0fa](https://github.com/boundaryml/baml/commit/71cc0fa7c7db0f9243dc248ac847835652f44c57)) - hellovai
- fix literal return values (#2663)
- actually emit the version when opening baml file to make LSP switch versions (#2612) - ([700bd39](https://github.com/boundaryml/baml/commit/700bd39b22c7265905b8385e09fed595a9735e19)) - aaronvg

Fixes several typechecker subsumption bugs - ([716b7b1](https://github.com/boundaryml/baml/commit/716b7b120e91c9735bdd68bc7a6580318c3d7000)) - Greg Hale

### Features
- Configurable timeouts (#2628) - ([276f878](https://github.com/boundaryml/baml/commit/276f878e9517037580ca5b6a9306a2189295795d)) - Greg Hale
- Add configurable media URL resolution via media_url_resolver (#2578) - ([8530e7f](https://github.com/boundaryml/baml/commit/8530e7fb39cfe36647bf7a61ccaee0591e4efb28)) - hellovai
- Add Windows support for Go BAML client (#2619) - ([5430aa6](https://github.com/boundaryml/baml/commit/5430aa61c22727a6f43d392e30fd9e75d905c18c)) - hellovai
- Add placeholder API keys for new VSCode playground users (#2640) - ([cc995c2](https://github.com/boundaryml/baml/commit/cc995c21a903dab74581efee8ee78976a13e287d)) - hellovai
- Add block-level @@description for BAML classes (#2643) - ([bbe489a](https://github.com/boundaryml/baml/commit/bbe489a7623c31077320e9fa5d4c54d8e1b803e9)) - hellovai
- Add type narrowing for instanceof checks in BAML (#2656) - ([46c3266](https://github.com/boundaryml/baml/commit/46c32663fe42d40ef96402b298b2f05c75c696fc)) - hellovai

### Miscellaneous Chores
- **(zed)** get zed release working again (#2625) - ([5be2647](https://github.com/boundaryml/baml/commit/5be2647c08782d1e411a56aa22b675dee4d89568)) - Sam Lijin
- set up sync path for engine/zed to zed-industries/extensions (#2626) - ([8f85ba7](https://github.com/boundaryml/baml/commit/8f85ba70c001196e01c6c683dbe247119113e132)) - Sam Lijin
- ban println to prevent lsp crashes, since it uses stdio to communicate (#2659) - ([7f9e749](https://github.com/boundaryml/baml/commit/7f9e749f7f990a8f49b9ffd8e78f175ee834b5e5)) - aaronvg
- Evaluation tests suite (#2660) - ([ce250d4](https://github.com/boundaryml/baml/commit/ce250d468cf2eadb023293412d887318f471e138)) - Greg Hale
- Bump version to 0.212.0 - ([d6975ea](https://github.com/boundaryml/baml/commit/d6975eafdf74fec1de68ce9e1813a95a9607ed5c)) - Aaron Villalpando

## [0.211.2](https://github.com/boundaryml/baml/compare/0.211.1..0.211.2) - 2025-10-12

### Bug Fixes
- Fix emit ts codegen bug (#2603) - ([39b1cf6](https://github.com/boundaryml/baml/commit/39b1cf6299b5080234e282367fdec238864c9df4)) - Greg Hale

## [0.211.1](https://github.com/boundaryml/baml/compare/0.211.0..0.211.1) - 2025-10-10

### Docs

- fix TypeScript tool call example (#2550) - ([73bc201](https://github.com/boundaryml/baml/commit/73bc201230fddc410ddcf9547b41d11039eebce1)) - Eric Winer
- Fix variable name of LLM response in modular-api.mdx docs (#2579) - ([8074499](https://github.com/boundaryml/baml/commit/8074499cc1413e36d37318f00936d4997922b06e)) - Caio Lang

### Features

- added endpoint_url to amazon bedrock (#2555) - ([10fd013](https://github.com/boundaryml/baml/commit/10fd0132bbac6a57f1b9540ac38262286356a744)) - Roey Ben Chaim

## [0.211.0](https://github.com/boundaryml/baml/compare/0.210.0..0.211.0) - 2025-10-07

### Bug Fixes

- **(compiler)** duplicate diagnostics when typechecking (#2535) - ([5a8de50](https://github.com/boundaryml/baml/commit/5a8de50aaf42dc9cdac77e02374c8ad1396b3765)) - José Rafael Oses
- Properly leave the secondary screen after non-erroring baml-cli init (#2565) - ([b911a19](https://github.com/boundaryml/baml/commit/b911a1927046b7a36d43fdaee1b25ebbfbc37f31)) - Greg Hale
- Fix json parser in cases where it would output intermediate representations (#2572) - ([c1a0b0e](https://github.com/boundaryml/baml/commit/c1a0b0e15fa36745a4a59d6a322f182cef034a6e)) - aaronvg
- **(python)** export set_log_max_message_length config for baml logs (#2553) - ([2c689dc](https://github.com/boundaryml/baml/commit/2c689dc3341b1f8ef4030b397b5e93f46cb25b2e)) - Samuel Lijin
- Add specific error for missing required env vars in clients (#2570) - ([5ea6adb](https://github.com/boundaryml/baml/commit/5ea6adb02f6e4246dd53cd626189ec1578d69b69)) - Antonio Sarosi
- [Promptfiddle] fix play button disappearing (#2571) - ([7d31c37](https://github.com/boundaryml/baml/commit/7d31c37142d89758ccff805853db0855af2bd318)) - aaronvg
- Lots of tracing improvements for Boundary Studio [#2576](https://github.com/BoundaryML/baml/pull/2576)

### Documentation

- fix @description documentation (#2544) - ([32aec21](https://github.com/boundaryml/baml/commit/32aec21f10840d28e837216f14ffed116e9bc377)) - Samuel Lijin
- Document Next.js version 15 requirement (#2540) - ([c1ce2ab](https://github.com/boundaryml/baml/commit/c1ce2abab0bddb42a84e492ef300a4dc14129a0a)) - Greg Hale


## [0.210.0](https://github.com/boundaryml/baml/compare/0.209.0..0.210.0) - 2025-09-30

### Bug Fixes
- Fix document name for PDF inference on Bedrock (#2545) - ([109612a](https://github.com/BoundaryML/baml/commit/109612ace4d5a1d4a37a8b392e55dc6bfb74997b)) - Greg Hale
- Fix regression in union streaming codegen (#2533) - ([0a7b396](https://github.com/BoundaryML/baml/commit/0a7b39652a940de679025c6044bc4ed51812b5a3)) - Greg Hale
- Jetbrains: avoid using deprecated java 18 api (#2541) - ([ec4f339](https://github.com/BoundaryML/baml/commit/ec4f339b628e34d2e6d0dd04df685929149830ed)) - Sam Lijin

### Features
- Enable "Citations" PDF analysis model for Claude on Bedrock (#2547) - ([219e53f](https://github.com/BoundaryML/baml/commit/219e53f9b3d9f538350c433b26ff68d95ae8324e)) - Greg Hale
- Add type narrowing for discriminated unions in Jinja (#2539) - ([7a395a9](https://github.com/BoundaryML/baml/commit/87e95fe818b596ab2580cd87fd4a26a32a058dd8)) - Antonio Sarosi

### Docs
- Document BAML tag setting and retrieval (#2534) - ([d90e7a3](https://github.com/BoundaryML/baml/commit/d90e7a35c6e43e308ab841b24e69b635ef514f8f)) - aaronvg

## [0.209.0](https://github.com/boundaryml/baml/compare/0.208.5..0.209.0) - 2025-09-28


### Bug Fixes
- Make Studio trace uploads 6x more efficient, and fix flushing logic (#2531)
- Fix an issue where we wouldn't parse a stream until the end of the stream, fix openai responses pdf input, and vertex-anthropic streaming. (#2530) - ([4bb2f33](https://github.com/boundaryml/baml/commit/4bb2f33ff908ff6a2f97fca222bc7afb5a12e8f3)) - aaronvg
- **(language-server)** handle non-baml-src baml files gracefully (#2506) - ([613df6b](https://github.com/boundaryml/baml/commit/613df6b9398d2921b5551be4f54db4cb285ba32f)) - Samuel Lijin
- **(playground)** make vertex work in the vscode playground (#2525) - ([6a5fa73](https://github.com/boundaryml/baml/commit/6a5fa73253da89952d698cac16514d1673d84a48)) - Samuel Lijin

### Features
- Bedrock modular api support (#2526) - ([42dfef3](https://github.com/boundaryml/baml/commit/42dfef3a1e66b265858b42600fc759e330ea0f56)) - Greg Hale
- Expose tags in the collector. Allow passing tags via baml function baml_options (#2528) - ([27f0694](https://github.com/boundaryml/baml/commit/27f06945727cd5354421516f9fe7183e86a6e298)) - aaronvg


### Docs
- Update vertex ai provider docs with api key info (#2519) - ([f146914](https://github.com/boundaryml/baml/commit/f1469143472c041521b6c8774a01e2670397977b)) - aaronvg
- Bump version to 0.209.0 - ([ca4cf4d](https://github.com/boundaryml/baml/commit/ca4cf4d2091be8f7561a80ca1dbc3c21ada35011)) - Aaron Villalpando


## [0.208.5](https://github.com/boundaryml/baml/compare/0.208.4..0.208.5) - 2025-09-24

### Bugfix

- Allow using clients using vertex api keys in the playground (#2516) - ([0ae357e](https://github.com/boundaryml/baml/commit/0ae357ed295b8f2f4f9ec17fad9ce17d3775bc12)) - aaronvg
- Bump version to 0.208.5 - ([9bb4778](https://github.com/boundaryml/baml/commit/9bb4778c6e45d95d33e0156c6a9fa4de4234ef4f)) - Aaron Villalpando

## [0.208.4](https://github.com/boundaryml/baml/compare/0.208.3..0.208.4) - 2025-09-24

### Features

- baml-cli check command (#2508) - ([a4afaed](https://github.com/boundaryml/baml/commit/a4afaed88265d0029c7ee0a5b91c1681424e16d2)) - José Rafael Oses
- add vertex api key auth (#2512) - ([a0a83fe](https://github.com/boundaryml/baml/commit/a0a83fe40c407b139ad62f2c431012470c750dcf)) - aaronvg


## [0.208.3](https://github.com/boundaryml/baml/compare/0.208.2..0.208.3) - 2025-09-23

### Bug Fixes

- **(lang-server)** handle non-baml-src baml files (#2486) - ([6bf3299](https://github.com/boundaryml/baml/commit/6bf32994d9411eddd2384552822a3e50a84f790f)) - Samuel Lijin
- Fix wasm integ tests, fix playground not streaming (#2504) - ([f892440](https://github.com/boundaryml/baml/commit/f892440721dca21c53b57e3521176bb8dc03bb38)) - aaronvg

- Bump version to 0.208.3 - ([f983b84](https://github.com/boundaryml/baml/commit/f983b8463db412ff469944acc16a031aa027f89d)) - Aaron Villalpando

## [0.208.2](https://github.com/boundaryml/baml/compare/0.208.0..0.208.2) - 2025-09-23


### Bugfixes
- Add mcp types (#2500) - ([0501d6d](https://github.com/boundaryml/baml/commit/0501d6db3c66cd21b02f88e2316d0bda167d56a5)) - aaronvg
- Bump version to 0.208.2 - ([1624f6c](https://github.com/boundaryml/baml/commit/1624f6c60c1874ff92ae6b02366f19769c0cb9df)) - Aaron Villalpando

## [0.208.1](https://github.com/boundaryml/baml/compare/0.208.0..0.208.1) - 2025-09-22


### Bugfixes
- Autosave changes on Import .env click (#2488) - ([11d8a69](https://github.com/boundaryml/baml/commit/11d8a69bd40fda20d73d3031c7acc7e88d18bf50)) - Antonio Sarosi
- Slightly more lenient set of keywords (#2495) - ([9a98c3f](https://github.com/boundaryml/baml/commit/9a98c3ffeedf8147e72ef8c66e841ea847e6de90)) - Greg Hale
- Bump version to 0.208.1 - ([8def010](https://github.com/boundaryml/baml/commit/8def0105d257952233ed62f8cefef31c2d199335)) - Aaron Villalpando

## [0.208.0](https://github.com/boundaryml/baml/compare/0.207.1..0.208.0) - 2025-09-21

### Features

- **(jetbrains)** get closer to feature parity with vscode (#2447) - ([0efb169](https://github.com/boundaryml/baml/commit/0efb169a13b5bc14d20438e960ba3dfa530a0f29)) - Samuel Lijin
- **(sdk)** errors now expose fallback history in detailed_message (#2449) - ([11a131f](https://github.com/boundaryml/baml/commit/11a131fae96ad05f49a429bc4ca845863a61f9c6)) - Samuel Lijin
- Improve streaming latencies in case parsing ever takes too long (#2467) - ([84bd606](https://github.com/boundaryml/baml/commit/84bd60622bc74ba5452c24c7046b6fb8704af76b)) - aaronvg
- BAML warns you if you use a template string without '()' (#2476) - ([a3b8c57](https://github.com/boundaryml/baml/commit/a3b8c576a594774bf3b47e68d4efa042b1ee567c)) - aaronvg
- Implement collector clear() and update docs (#2478) - ([13e7e13](https://github.com/boundaryml/baml/commit/13e7e1361fc0f99c08876c9b24cc6d783b2458d3)) - aaronvg


### Bugs
- Fix vertical scroll on `PromptView` component (#2462) - ([5eb3381](https://github.com/boundaryml/baml/commit/5eb3381b2c715d70538ebaf129a010e90ae40215)) - Antonio Sarosi
- Fix pdf input as base64url in openai-responses (#2464) - ([2fad7cd](https://github.com/boundaryml/baml/commit/2fad7cd57b432ff3f70c46ef3b137039b987c15e)) - aaronvg
- Fix colons in config maps (#2475) - ([9736532](https://github.com/boundaryml/baml/commit/9736532b2f07eec2a4b87e3975bb83624452f4e2)) - Greg Hale
- Fix deep config object parsing and env var redaction (#2485) - ([9e35412](https://github.com/boundaryml/baml/commit/9e35412a4c2a942d9c301553575dd61b47a4359c)) - Greg Hale


### Docs
- Add vercel ai gateway to docs (#2453) - ([a2e98a5](https://github.com/boundaryml/baml/commit/a2e98a584cf5601ea07c3abf777257de4953bf61)) - aaronvg
- Update pdf testing documentation in playground (#2457) - ([66e449c](https://github.com/boundaryml/baml/commit/66e449c64aef2356a6ee6de627429e9952172233)) - aaronvg
- Fix LLM Parse Fixup recipe in docs (#2459) - ([80db51a](https://github.com/boundaryml/baml/commit/80db51a3bda096f90c48f033e321fdf7835d9145)) - Greg Hale
- Update documentation and examples to use latest 2025 AI models (#2460) - ([0b1bc44](https://github.com/boundaryml/baml/commit/0b1bc44131aad61199cf5b583eb0ef9f2b113ef2)) - hellovai
- Add `on_generate` option to other languages (#2461) - ([d7853bd](https://github.com/boundaryml/baml/commit/d7853bded81f034a8d3dadb0bb9acd3180c436b9)) - Antonio Sarosi
- remove fn keyword (#2468) - ([8557ab4](https://github.com/boundaryml/baml/commit/8557ab466c878d7515e952fb062455b8e3bc2b86)) - Greg Hale
- Bump version to 0.208.0 - ([c1630f5](https://github.com/boundaryml/baml/commit/c1630f556a8bc90c17dc1f97229884714a6937b1)) - Aaron Villalpando

## [0.207.1](https://github.com/boundaryml/baml/compare/0.207.0..0.207.1) - 2025-09-13

### Bug Fixes

- **(jetbrains)** implement dynamic versioning (#2439) - ([d352f02](https://github.com/boundaryml/baml/commit/d352f02883c5c01200ae4aacfe095396c6ef272b)) - Samuel Lijin
- **(openai)** openai-responses had a bug in the assistant request format (#2440) - ([aca1c53](https://github.com/boundaryml/baml/commit/aca1c5314d29d7f91d02c29356d5e2a2dbb87319)) - Samuel Lijin
- make baml-cli in go also work if you type 'baml' (#2445) - ([5f2df4b](https://github.com/boundaryml/baml/commit/5f2df4b323231d9d9b1a21cf4f4fb7d8ee92fac4)) - aaronvg
- [Playground] Dont animate sidebar to improve performance - ([80ff10a](https://github.com/boundaryml/baml/commit/80ff10a7ff3432a94b17b2982c3ad1a01c4c59e2)) - Aaron Villalpando

### Docs
- Document fixing parsing issues with LLMs (#2448) - ([137ee7e](https://github.com/boundaryml/baml/commit/137ee7e303cd009f41504e15c2a7ed4aa3132eb0)) - Greg Hale

## [0.207.0](https://github.com/boundaryml/baml/compare/0.206.1..0.207.0) - 2025-09-10

### Bug Fixes

- **(python)** Update internal runtime type annotations (#2400) - ([992acaa](https://github.com/boundaryml/baml/commit/992acaa5afcdb8e52f1315f4d9c7260906b38eb0)) - Samuel Lijin
- **(vscode)** make "Run test" codelenses appear in the correct place and run the correct test (#2395) - ([b9c3fea](https://github.com/boundaryml/baml/commit/b9c3fea18603f611fae3d616b6082a29004701f9)) - Samuel Lijin
- **(vscode)** Fix Jetbrains and VScode test selection (#2427) - ([e4d3529](https://github.com/boundaryml/baml/commit/e4d35296da2a9b39f9b56039d774f2c1871b9269)) - Samuel Lijin
- use roles correctly with openai-responses (#2392) - ([d976c55](https://github.com/boundaryml/baml/commit/d976c55a7048f5a025f941a7bfae545d2bc94a54)) - Samuel Lijin
- Emit notification to check CLI version against client (#2404) - ([6ea5617](https://github.com/boundaryml/baml/commit/6ea5617c99c82e4e4fd4296b82a5a44b50264e95)) - Jesús Lapastora
- Fix media file path resolution on Windows (#2391) - ([3950a49](https://github.com/boundaryml/baml/commit/3950a495a3f91ec9bf274ace91df9c05837a3e9f)) - Greg Hale
- syntax highlighting for pdf type (#2414) - ([21f7d62](https://github.com/boundaryml/baml/commit/21f7d62ba0ba8488cc1acc88557b459f859c1d46)) - Greg Hale
- Fix TS double 'export declare' in baml_client by migrating to napiv3 (#2228) - ([a5294fa](https://github.com/boundaryml/baml/commit/a5294fabbb4f9d6806fe81ba99b9d436acb3f9c8)) - Ethan Lijin
- [Python] Pass `abort_controller` to `Runtime::stream_function` (#2416) - ([8100bc2](https://github.com/boundaryml/baml/commit/8100bc2ecb36d1cf0338f9d2a61738a641d7ef13)) - Antonio Sarosi
- Improve the samples and error messages for test blocks (#2418) - ([e1a8fd5](https://github.com/boundaryml/baml/commit/e1a8fd5541ed9e1401a66194aea32bd9c5e83289)) - Greg Hale

### Docs
- Fix tabs not syncing correctly in docs (#2420) - ([134fac0](https://github.com/boundaryml/baml/commit/134fac0aacd7ab49f77edf2648b0fd640bf9e08b)) - aaronvg
- Enhance OpenAPI Docs (#2399) - ([964bc40](https://github.com/boundaryml/baml/commit/964bc408bca71279af676ff0b2ed6dc618dba0c4)) - Antonio Sarosi

### Features
- Add cached input token tracking to Usage reporting (#2394) - ([7e460e6](https://github.com/boundaryml/baml/commit/7e460e68dae52d203a7a0bb8e9906a7acff359c3)) - Luke Ramsden

### BAML Agents / Workflows (WIP)
- Improve expr-fn parsing (#2408) - ([eca5142](https://github.com/boundaryml/baml/commit/eca5142b7cef94b29e9a07aec7ddb567fcc8b71b)) - Greg Hale
- Merge Mermaid diagram visualizer (#2381) - ([df6ee12](https://github.com/boundaryml/baml/commit/df6ee1250107ff989f704df942004ba46a2d9fbf)) - Greg Hale
- Update syntax highlighting (#2412) - ([5c3c412](https://github.com/boundaryml/baml/commit/5c3c412e7ab99d582d202c10d9933bd29d163c7f)) - Greg Hale
- VM Errors & Type Convertions & Missing Types (#2403) - ([51fc365](https://github.com/boundaryml/baml/commit/51fc365510577f3a271fb088f1b3df522be9f983)) - Antonio Sarosi
- Add string concatenation: `"a" + "b"` (#2426) - ([41d53ea](https://github.com/boundaryml/baml/commit/41d53eaf12a689edab4a876b738c91d053932805)) - Antonio Sarosi


### Boundary Studio
- More improvements to studio2 publishing (#2333) - ([39e731a](https://github.com/boundaryml/baml/commit/39e731a23d88faaa750519fd402f85281b46f1cb)) - aaronvg



## [0.206.1](https://github.com/boundaryml/baml/compare/0.206.0..0.206.1) - 2025-08-28

### Bugfix

- vscode extension is broken (#2387) - ([i43e4f72](https://github.com/BoundaryML/baml/commit/43e4f72effeb8ec48c40681dc129ba3ce9124288)) - hellovai
- media types in jinja should evaluate to true in jinja bool conversions (#2384) - ([d25d3eb](https://github.com/boundaryml/baml/commit/d25d3ebce21ab6157dd760dfcde217e711229191)) - hellovai

## [0.206.0](https://github.com/boundaryml/baml/compare/0.205.0..0.206.0) - 2025-08-27

### Bug Fixes

- package the baml-py license correctly (#2325) - ([eb70206](https://github.com/boundaryml/baml/commit/eb7020639ef4d79ff9f5c513d1102c5ded9b2ed1)) - Samuel Lijin
- teach PromptRenderer to render enum values as their alias, not the value literal (#2326) - ([5366299](https://github.com/boundaryml/baml/commit/5366299334fb0320245f5fb5d44bdc22f87996d2)) - Samuel Lijin
- Make the Jetbrains extension work (#2358) - ([09aeb12](https://github.com/boundaryml/baml/commit/09aeb1256c2ba3d6f9074040c89dbce24ef239b4)) - Samuel Lijin
- Fix ERR_MODULE_NOT_FOUND for ESM users (#2299) - ([1bd1021](https://github.com/boundaryml/baml/commit/1bd10214c700b83a118ee16ca7b74ab53727dcea)) - Luke Ramsden
- Do not generate code when generator/LSP versions do not match (#2367) - ([e8c9859](https://github.com/boundaryml/baml/commit/e8c98595c3b9048ee40b8a99d2f735ce9610cf74)) - Jesús Lapastora
- fix roles and multi-modality on openai-responses provider (#2327) - ([01595b2](https://github.com/boundaryml/baml/commit/01595b20433af529bd2be128a6e6a385252f075f)) - hellovai
- Fix `Pdf.from_base64` in Python to expose a logical API (#2366) - ([76fcd70](https://github.com/boundaryml/baml/commit/76fcd70ecc0df59226f6cda3a5b54b84e6ab9261)) - Antonio Sarosi


### Features

- Implement `onTick` which will allow users to get callbacks and access thinking tokens (#2362) - ([915ae27](https://github.com/boundaryml/baml/commit/915ae27118821e499b607185bb34c06f138035a9)) - hellovai
- Implement AbortController in py, ts, go, wasm (also cancel buttons) (#2357) - ([fb4dd72](https://github.com/boundaryml/baml/commit/fb4dd72136dae70257a49f66c8707343ee7bb191)) - Samuel Lijin
- Use AbortSignal in typescript, add a native timeout capability in python. (#2373) - ([a12ba5a](https://github.com/boundaryml/baml/commit/a12ba5a61792a2c59b23bf63f96d25f3b6457ea5)) - hellovai
- render raw curl for aws-bedrock (#2319) - ([2bbb267](https://github.com/boundaryml/baml/commit/2bbb267e7c91bb089bc35089f4d878eddeeaa6c6)) - Ethan Lijin

### Documentation

- add env var docs for studio v2 (#2347) - ([146f4b4](https://github.com/boundaryml/baml/commit/146f4b4659dbefeff669ef2fa58c1ddd6513aab5)) - Chris Watts
- Add official docs for go (#2253) - ([16d3612](https://github.com/boundaryml/baml/commit/16d3612c79bf89e8f1e0da440f48c749a0cba91f)) - hellovai

### Miscellaneous Chores

- claude code permissions should not be checked in (#2269) - ([99204c8](https://github.com/boundaryml/baml/commit/99204c8c00a559eb3c29961faf960b795e583828)) - Trenton Lawrence

## [0.205.0](https://github.com/boundaryml/baml/compare/0.204.0..0.205.0) - 2025-08-14

### Bug Fixes

- **(jetbrains)** Fix installer logic (#2275) - ([a89ceb6](https://github.com/boundaryml/baml/commit/a89ceb6d1022b95e8842bcdb056d22816e3e4680)) - Samuel Lijin
- handle missing `parts` field in gemini flash responses (#2272) - ([5aa9995](https://github.com/boundaryml/baml/commit/5aa9995699533d90136c508b01ac09ef9d8df4d3)) - Juan Manuel Verges
- issue with some ids for embed prompt fiddle (#2279) - ([66f6566](https://github.com/boundaryml/baml/commit/66f65666f546c5e9b00b09c746203eb90e463850)) - Chris Watts
- Fix cases where BAML extension would deadlock -- not loading playground (#2311) - ([d9a2a3d](https://github.com/boundaryml/baml/commit/d9a2a3d51f7b103a626d77f8503e4b78882b4a85)) - Samuel Lijin
- [Python] Allow Baml PDF, Image, Audio types to serialize correctly (#2274) - ([d017bfe](https://github.com/boundaryml/baml/commit/d017bfea1441ac8bfb6602d94299a69c91b60f55)) - Egor Lukiyanov
- Allow openapi generator to remove unknown files from output dir (#2281) - ([cba26f9](https://github.com/boundaryml/baml/commit/cba26f963eaac4c6506a19d483e89e81a63db5cf)) - Antonio Sarosi
- add version number on generations (#2282) - ([5e995ef](https://github.com/boundaryml/baml/commit/5e995ef6b05c233525de4dd7a07fe0a815adcf98)) - aaronvg
- Set token usage for gemini streaming (#2302) - ([2f6be15](https://github.com/boundaryml/baml/commit/2f6be15d05bf7ff7b3a96d46092584e4ad5184d4)) - masonk


### Features
- [feature] Allow users to remap common roles -> model specific roles. (#2288) - ([279051d](https://github.com/boundaryml/baml/commit/279051db754913b8087a1ad99be9fb3f64cabd35)) - hellovai
- Make `baml-cli test` run expression functions (#2294) - ([e163ce1](https://github.com/boundaryml/baml/commit/e163ce10aa090fca7ac7a9775dc78c369f94756d)) - Greg Hale


### BAML VM (WIP)
- Baml VM (#2089) - ([5e4b946](https://github.com/boundaryml/baml/commit/5e4b9467723e3371140dfa6f97d691f83c2dec9d)) - Antonio Sarosi
- Bitwise operators (`&`, `|`, `^`, `>>`, `<<`) (#2300) - ([9bd9552](https://github.com/boundaryml/baml/commit/9bd955237c629f306287fa7bd168f5a103a63378)) - Antonio Sarosi
- Assignment operators (`&=`, `|=`, `+=`, `-=`, `*=`, `/=`, `%=`, `>>=`, `<<=`) (#2301) - ([934ad56](https://github.com/boundaryml/baml/commit/934ad56a4ab64b99e58b3d50eb871511746c4c50)) - Antonio Sarosi
- While loops (#2297) - ([781846b](https://github.com/boundaryml/baml/commit/781846b4941318dfa64ad38039777ce633ddc0f7)) - Jesús Lapastora
- Bump version to 0.205.0 - ([e416f81](https://github.com/boundaryml/baml/commit/e416f81315749ddf0db32ad6049c7755a4c67ddc)) - Aaron Villalpando

## [0.204.0](https://github.com/boundaryml/baml/compare/0.203.1..0.204.0) - 2025-08-06

### Features
- Enhance Type Builder API with listProperties() and reset() (#2177) - ([b4ddb6f](https://github.com/boundaryml/baml/commit/b4ddb6f6bae1c5bbd30ac3548103a5e997c6b695)) - Antonio Sarosi
- implement ai assistant for docs (#2189) - ([d326da7](https://github.com/boundaryml/baml/commit/d326da73ebba405362016bc09fd271ef16248d50)) - Egor Lukiyanov
- Implement caching for VertexAuth instances. (#2250) - ([66dba18](https://github.com/boundaryml/baml/commit/66dba1845c237b774c2ec29630dd8c5bcf251607)) - hellovai


### Bug Fixes

- **(jetbrains)** rename baml extension and publish to stable (#2260) - ([76e4e1b](https://github.com/boundaryml/baml/commit/76e4e1b463358c1c5465366d84f60fd80691fad5)) - Samuel Lijin
- issue with Promptfiddle.com/embeded not working correctly (#2245) - ([b8e78f9](https://github.com/boundaryml/baml/commit/b8e78f991d3bd9767a59bad78511e538a3ddf60a)) - Chris Watts
- issue with vscode colors (#2261) - ([85707b7](https://github.com/boundaryml/baml/commit/85707b7904c38ff9fb05e4b7a93db1cae1972909)) - Chris Watts
- make api key dialog scrollable (#2251) - ([b22f29c](https://github.com/boundaryml/baml/commit/b22f29c2dec7146af8d156d23b46180437c13b9d)) - aaronvg
- Make sure to update cli version of generator (#2256) - ([63f45d4](https://github.com/boundaryml/baml/commit/63f45d4b34b4682b297e024e5ac96b15030a2fcf)) - Egor Lukiyanov
- Fix validation to reject field-level assertions in test blocks (#2259) ([f741e43](https://github.com/boundaryml/baml/commit/f741e4319b4f95657a08e46f4404d258a1d91e5a)) - Dex



## [0.203.1](https://github.com/boundaryml/baml/compare/0.203.0..0.203.1) - 2025-08-01

### Bug Fixes

- fix baml-cli init,  and playground state when selecting and running tests (#2242)


## [0.203.0](https://github.com/boundaryml/baml/compare/0.202.1..0.203.0) - 2025-08-01

### Bug Fixes

- [Go] fix panic when downloading baml cli (#2201) - ([c8fd18b](https://github.com/boundaryml/baml/commit/c8fd18b143d19b235f44e707c2d4037e9895f4ad)) - Rahul Tiwari
- [Go] Support go mod vendor (#2203) - ([c62cf63](https://github.com/boundaryml/baml/commit/c62cf63e400072292649c6ae59fb9f107ee4fc73)) - Rahul Tiwari
- [Python] fix typebuilder type imports (#2209) - ([c104174](https://github.com/boundaryml/baml/commit/c10417488b0b4dd2667bf860e6e5a036d1960137)) - Rahul Tiwari
- Dont parse thinking blocks from Gemini (#2215) - ([c5a9cbc](https://github.com/boundaryml/baml/commit/c5a9cbc24488561c934b946749122d0a7e4f1a84)) - Rahul Tiwari
- Fix Issue with cross-origin policy on playground (#2217) - ([a82f682](https://github.com/boundaryml/baml/commit/a82f6829806e0502a4c30804b34cc97744d17027)) - Chris Watts
- Fix missing types for some llm responses like computer use (#2226)
- fix union type warning (#2225)
- Improve BAML SAP parser performance by 100x in many scenarios (#2233) - ([28b092e](https://github.com/boundaryml/baml/commit/28b092efb78f0d2758f03b6f06dc07fff7dd9f90)) - Rahul Tiwari
- Fix issue with BAML_LOG env var not being respected (#2235) - ([65c8c66](https://github.com/boundaryml/baml/commit/65c8c663e43bea9b8b9cc3e11631546c6b0be525)) - Rahul Tiwari
- [Breaking] Remove Pdf media type specification (#2167) - ([fcbcb55](https://github.com/boundaryml/baml/commit/fcbcb55ae5d27d122903c8aaa92e961b55569a68)) - egol
- Add a pool timeout to try to fix open File descriptor issue like deno (#2205) - ([2a031b6](https://github.com/boundaryml/baml/commit/2a031b608af6de79534960ebbf9f186ffe09cb10)) - aaronvg
- Fix parser during streaming so that we correctly parse string[] from "["foo", (#2213) - ([5838036](https://github.com/boundaryml/baml/commit/583803634c98dfdb2eed2faff43306d2dab7250b)) - hellovai
- [Playground] Fix issue with test selection, and improve performance when selecting another function (#2224) - ([dd00956](https://github.com/boundaryml/baml/commit/dd00956f7ade26e6e09a865191802b8b4a840367)) - aaronvg



### Features
- Finalize Zed Extension (#2169) - ([ec170db](https://github.com/boundaryml/baml/commit/ec170dbc0bb01598715ef8e220828c0dc52777c7)) - egol
- Re-add playground tests sidebar to 'run all' tests (#2214) - ([96e9d64](https://github.com/boundaryml/baml/commit/96e9d648411d24df5eaac796e6b5d69e91df5559)) - Chris Watts
- Add ClientRegistry, BamlPdf and BamlVideo in openapi generator (#2170) - ([0bc450f](https://github.com/boundaryml/baml/commit/0bc450facd2a9b2fdae9d7ed34341a8bfbf7c56c)) - Greg Hale
- [feature] add multimodal support for go (#2192) - ([f49c25c](https://github.com/boundaryml/baml/commit/f49c25c8d356a00695b287f07e05c55f4878e47a)) - hellovai
- [feat] Add internationalization to SAP parser (#2210) - ([dce9074](https://github.com/boundaryml/baml/commit/dce9074f5910b43c8a7197edd614bd8ca7585fb1)) - hellovai
- Refreshed playground look (#2227) - ([e514d53](https://github.com/boundaryml/baml/commit/e514d53c775ef6b305b6a1ff85d97f5288c2f1a7)) - Chris Watts


### Cli

- add IDE/terminal auto-detect from baml-cli init (#2178) - ([34a0428](https://github.com/boundaryml/baml/commit/34a0428d6b755226110f891327aa8ec7d6f0cf0b)) - Rahul Tiwari


## [0.202.1](https://github.com/boundaryml/baml/compare/0.202.0..0.202.1) - 2025-07-18


### Bug fixes
- apply suggestions by cargo fix to reduce warnings (#2158) - ([4a851dc](https://github.com/boundaryml/baml/commit/4a851dca4f7fb3161602589bc6214d11fd845aee)) - Rahul Tiwari
- [feat] merge union types in go whenever possible (#2160) - ([73f0c36](https://github.com/boundaryml/baml/commit/73f0c36dbe9d087acc2213374e3d14bd4ea750af)) - hellovai
- Bump version to 0.202.1 - ([4ff6a02](https://github.com/boundaryml/baml/commit/4ff6a02148d516cf3af9505a8aaa168b88ca2168)) - Aaron Villalpando

## [0.202.0](https://github.com/boundaryml/baml/compare/0.201.0..0.202.0) - 2025-07-16

### Bug Fixes

- issues with setup-dev.sh (#2133) - ([059b7c3](https://github.com/boundaryml/baml/commit/059b7c304482444c5e6b58330ed31bcf528375b3)) - Chris Watts
- Fix baml-cli generate panic (#2142) - ([8884e20](https://github.com/boundaryml/baml/commit/8884e2040660782d52f2b63a0049f44bfbd05bc4)) - aaronvg
- Fix generation of ignore files in openapi (#2112) - ([7eb1450](https://github.com/boundaryml/baml/commit/7eb145080d95f6f8f407e849ff338ff6f8fa9cfb)) - Greg Hale
- In go, fix issue with top level strings / primitiive types being returned (#2110) - ([0a1aa60](https://github.com/boundaryml/baml/commit/0a1aa60d38efa2129e39b2578df1a18a211c5516)) - hellovai
- Support moving / renaming baml files and directories and remove language server crash (#2131) - ([9d6a3db](https://github.com/boundaryml/baml/commit/9d6a3dbb4cce7a04c9c156e298196c810a74b36b)) - Antonio Sarosi
- Propertly escape env vars from VSCode -> BAML runtime to handle JSON strings (credentials for vertex) (#2135) - ([d81a0a7](https://github.com/boundaryml/baml/commit/d81a0a7225dbd17b32e6bf4d515380b97539f850)) - hellovai

### Documentation

- Update playground UI references and screenshots (#2122) - ([a7974fb](https://github.com/boundaryml/baml/commit/a7974fb8294f17d1d496adc9e4cef2ec9e31a5bc)) - George
- Improved documentation for baml versioning (#2124) - ([083ccb7](https://github.com/boundaryml/baml/commit/083ccb785e6ce9164cbef9e75a525ab3c36b9d48)) - egol
- Docs for using anthropic models on vertex (#2123) - ([0db53c1](https://github.com/boundaryml/baml/commit/0db53c1fd93d9683fcb9ad2a6fea970161d16730)) - Gabe Villasana
- Make baml directory structure and set up easier (./scripts/setup-dev.sh && pnpm build) (#2087) - ([6b7c178](https://github.com/boundaryml/baml/commit/6b7c1782ce73c19891a08b81e1291c2295500daf)) - Chris Watts

### Features

- Add new provider "openai-responses" for OpenAI Responses API support  (#2103) - ([18ef4e4](https://github.com/boundaryml/baml/commit/18ef4e4a59f6fd5c15e8eeca275ce579745603cf)) - Rahul Tiwari
- Add SSE stream to the collector (#2118) - ([d389451](https://github.com/boundaryml/baml/commit/d389451fd1dd2dc114eedf1c158339b74ef67455)) - hellovai
- Add Pdf and Video support (#2121) - ([f33bd71](https://github.com/boundaryml/baml/commit/f33bd718ff29315e8fc6cd67f596cba922409c38)) - egol
- Add collector capability to Go (#2119) - ([de024cf](https://github.com/boundaryml/baml/commit/de024cf5324640b85358312a42c1e9f9d3405cd5)) - hellovai
- [feat] Add experiemental support for accessing collector prior to first streamed value in go (#2146) - ([786c303](https://github.com/boundaryml/baml/commit/786c303ea29207036f8570006e3ca38d0185244f)) - hellovai


## [0.201.0](https://github.com/boundaryml/baml/compare/0.200.0..0.201.0) - 2025-07-03


### Bug Fixes
- Add complete type validation for Go (#2101) - ([8b35440](https://github.com/boundaryml/baml/commit/8b354407746dc3c26120369edb05dab2e3cd6e45)) - hellovai


## [0.200.0](https://github.com/boundaryml/baml/compare/0.90.2..0.200.0) - 2025-07-01

### Bug Fixes

- Fix issue with baml-cli test where env vars wouldnt work (#2060) - ([344fb8a](https://github.com/boundaryml/baml/commit/344fb8a55ab46df8672904cf89bc5a814161d9c4)) - Rahul Tiwari
- fix VSCode Proxy Handling due to v2 -> v3 for npm:http-proxy-middleware (#2065)
- [Python] Fix issue where Baml wouldn't be pickleable
- Render `none` as `null` for jinja inputs (#2037) - ([bfa98e8](https://github.com/boundaryml/baml/commit/bfa98e8ec7f272a888bb581a75c71469c21dfef7)) - Antonio Sarosi
- Add linter warnings for experimental expr features (#2053) - ([9fbc9ee](https://github.com/boundaryml/baml/commit/9fbc9ee38336bf08a0c67c02f237a6886e931cd5)) - Greg Hale
- Fix prompt-fiddle highlighting (#2082) - ([350914c](https://github.com/boundaryml/baml/commit/350914cf4f2ca7244951eb62f7e1570248ee2482)) - Greg Hale
- Fix performance issue on promptfiddle codemirror editor (#2083) - ([a64848c](https://github.com/boundaryml/baml/commit/a64848c9e5f29adad89a558a8ae9c0f3092e1545)) - aaronvg
- Fix env vars in promptfiddle (#2084) - ([52b5329](https://github.com/boundaryml/baml/commit/52b532906506dc684d683242ccea871747ec458c)) - Antonio Sarosi
- Add fixes for typesystem to deal with semantic streaming (#2086) - ([d2c26f2](https://github.com/boundaryml/baml/commit/d2c26f2c43fd7384a99343248e09b83454f0ae4d)) - hellovai
- Parsing fix for streaming lists of objects (#2092) - ([cca8863](https://github.com/boundaryml/baml/commit/cca8863cbad3430f59e1e6dd40077f5a94aa036b)) - aaronvg


### Features
- Zed Extension support (#2044) - ([f07d944](https://github.com/boundaryml/baml/commit/f07d944a357506b14cdd6549ccf435289ed5ab47)) - egol
- Boundary studio v2 alpha release - ([843dfde](https://github.com/boundaryml/baml/commit/843dfdeb7e00acb6a464aa26654bc7f94fc382ce)) - aaronvg
- Jetbrains Extension support (#2001) - ([984e800](https://github.com/boundaryml/baml/commit/984e800ffe26236963de080820cb43d7f410c826)) - Samuel Lijin


### Miscellaneous
- Adding more docs for llama api (#2077) - ([412eaff](https://github.com/boundaryml/baml/commit/412eaff86895d4c163510651e912b8c5bcd550c9)) - hellovai
- Bump version to 0.200.0 - ([c153d4a](https://github.com/boundaryml/baml/commit/c153d4ae1835aa9e8bd33c341b1126b16f1a219d)) - Aaron Villalpando

## [0.90.1](https://github.com/boundaryml/baml/compare/0.90.0..0.90.1) - 2025-06-16


### Bugfixes
- Fix fatal log line showing up with publisher not started (#2038) - ([e02c30a](https://github.com/boundaryml/baml/commit/e02c30abf8aecfdccbd28386d0bc4049d017bc8c)) - aaronvg

## [0.90.0](https://github.com/boundaryml/baml/compare/0.89.0..0.90.0) - 2025-06-14

### Bug Fixes
- Fix bug where BAML_LOG wouldnt be printed in python due to a tracing bug (#2030) - ([7736f22](https://github.com/boundaryml/baml/commit/7736f22cc98916e7e24fcec7dfbaa406c5aa3a65)) - aaronvg
- Fix parsing issue when there was a newline before object field (#1985) - ([ad92d3e](https://github.com/boundaryml/baml/commit/ad92d3ee847125a7a8537f3d3873e9689a0a1ce9)) - Greg Hale
- implement handling of Media under coerce_arg (#1996) - ([929ee97](https://github.com/boundaryml/baml/commit/929ee97c716e0932f1dce4af54dcdf073c8659f5)) - Greg Hale
- Fix inconsistent class hoisting bug (#1998) - ([779450d](https://github.com/boundaryml/baml/commit/779450daa8f35542d6bd86563b01dbe685389e91)) - Antonio Sarosi
- Fix prompt rendering highlight regex (#1997) - ([0363df7](https://github.com/boundaryml/baml/commit/0363df7e5f3a92756e8966a386255d4b390b9f08)) - Antonio Sarosi
- Correctly infer Vertex AI base URL for location 'global' (#2014) (#2015) - ([149b742](https://github.com/boundaryml/baml/commit/149b7420f32fc391701f69425777b59ea5370075)) - Luke Ramsden
- Reduce namespace pollution in codegen (#2016) - ([505a9e9](https://github.com/boundaryml/baml/commit/505a9e976e097a3ba3a6f941dec62cd4f257a2e6)) - Antonio Sarosi
- Fix bug where LSP crashed when a baml file not in a baml_src was opened (#2019) - ([e9303ae](https://github.com/boundaryml/baml/commit/e9303aebdc5c79d86b1c2a59aa43e46250693d28)) - aaronvg


### Features

- Release jetbrains extension (alpha) (#1983) - ([18b57dd](https://github.com/boundaryml/baml/commit/18b57ddcc264720f3ba016319e61147d30f12f5f)) - Samuel Lijin
- lazy load env vars to not rely on baml client import order (#1949) - ([4397cf1](https://github.com/boundaryml/baml/commit/4397cf100f6a6d164bd46820aaafc46615f5b918)) - Rahul Tiwari
- deeply typecheck class constructors (#2000) - ([8d66b80](https://github.com/boundaryml/baml/commit/8d66b8071301b9b7ed7cb999a6aa692c3b8503e4)) - Greg Hale
- Fetch API (#1916) - ([67b3f4f](https://github.com/boundaryml/baml/commit/67b3f4fe06652749809aeee64aacfb7bef57cc1f)) - Antonio Sarosi
- Migrate jinja to minijinja2, enabling latest fixes on jinja templating (#2025) - ([230c51c](https://github.com/boundaryml/baml/commit/230c51cbc879c073cbe225d03f8bbc86e80bd55c)) - aaronvg


### Other
- improve error message for asserts and checks (#1975) - ([070ad26](https://github.com/boundaryml/baml/commit/070ad26131f73afb2630d2559c19cbaa26a63abc)) - Greg Hale
- Reduce Vscode Extension bundle size by removing old LSP code (#2031) - ([c92bcf6](https://github.com/boundaryml/baml/commit/c92bcf64dd1e50c40781c57a82405a428debe56a)) - aaronvg


### Docs
- Fix dynamic enum spelling in docs (#1986) - ([9212af2](https://github.com/boundaryml/baml/commit/9212af236c997d0a46167de2b7eefc57dbf01d93)) - ngirard
- update docs for env vars (#1987) - ([8405ee5](https://github.com/boundaryml/baml/commit/8405ee5bb9b96d4a99a5f4b326f61a39e4336d5b)) - Rahul Tiwari
- Add baml-cli test documentation (#2021) - ([854cdbd](https://github.com/boundaryml/baml/commit/854cdbdd259398e24311fa958e647b30dc2c8b73)) - aaronvg
- add docs for `selected_call` (#2028) - ([97b2408](https://github.com/boundaryml/baml/commit/97b2408b5dd5d5555272cca24b3569ff1c9d5164)) - Ben Epstein



## [0.89.0](https://github.com/boundaryml/baml/compare/0.88.0..0.89.0) - 2025-05-21

### Features
- Add `hoist_classes` parameter in `ctx.output_format` (#1957) - ([42ee507](https://github.com/boundaryml/baml/commit/42ee507e21422ea6d7267172c22d534a65f700ac)) - Antonio Sarosi
- [feat] Adding support for pydantic v1 (#1968) - ([3fdbfd0](https://github.com/boundaryml/baml/commit/3fdbfd05207f44a92d48d952c2ccbfeec9104850)) - hellovai
- [Go] Add ClientRegistry (#1967) - ([1cb4648](https://github.com/boundaryml/baml/commit/1cb464826d8cbc21b555b725fd6594239605cf01)) - Todd Berman


### Bug Fixes

- enum validation to disallow reserved names as enum values (#1955) - ([ae13c4d](https://github.com/boundaryml/baml/commit/ae13c4dfde7cd2f51d17934d564980662cfb9e3b)) - Rahul Tiwari
- [Go] Maps are being returned not as pointers as they are already pointers (#1956) - ([3d83f99](https://github.com/boundaryml/baml/commit/3d83f9975eb38d0cf0820ff634c7cafd91044be9)) - Todd Berman
- [go] JSON deserialize Union fix (#1954) - ([f748439](https://github.com/boundaryml/baml/commit/f7484395bf349231ffa626fdd7222f6929e79be6)) - Todd Berman
- Fix height rendering issue on playground (#1963) - ([bb39c3d](https://github.com/boundaryml/baml/commit/bb39c3d1d0914d6c8b724b471f21023cd519aab2)) - aaronvg
- Fix nested assert typechecking (#1966) - ([113966f](https://github.com/boundaryml/baml/commit/113966f6f43c2cf2fbcc6c0796ebe353d5f2d3f6)) - Greg Hale
- Fix issue where tracing logs would not be sent if you had an empty BOUNDARY_BASE_URL env var (#1971) - ([9203f6a](https://github.com/boundaryml/baml/commit/9203f6aa81dd6ca0d4160d82392bbf1183bf8c82)) - aaronvg


### Miscellaneous
- [docs] adding docs for cerebras (#1952) - ([e9d699b](https://github.com/boundaryml/baml/commit/e9d699bd8f7a47b462ad6289991b9231f4e1517f)) - hellovai
- [docs] adding support for tinfoil models (#1958) - ([9255eb0](https://github.com/boundaryml/baml/commit/9255eb01fecbfdf6dd45ebba7c81274484786887)) - hellovai
- [MVP] add conditional expressions (#1959) - ([ee15d0f](https://github.com/boundaryml/baml/commit/ee15d0f379f53a93f2d80b39909c74495b19930b)) - Greg Hale
- use regex_match in constraint docs (#1953) - ([fbba5cc](https://github.com/boundaryml/baml/commit/fbba5cc43066ca719ca7f8a003e5ffba4cfbdb6c)) - Greg Hale

## [0.88.0](https://github.com/boundaryml/baml/compare/0.87.2..0.88.0) - 2025-05-14

### Documentation

- **(tools)** add string literal examples (#1939) - ([b037124](https://github.com/boundaryml/baml/commit/b037124a64d5951b5d96ae8b237006fa3c780151)) - Elijas Dapšauskas

### Features
- Support openai audio input (#1940) - ([87ed2b1](https://github.com/boundaryml/baml/commit/87ed2b1454ddf02d9e4950d0c72b12a2b04f848e)) - aaronvg
- add HookData for baml react hooks, as a utility to get nonnullable types (#1925) - ([6501ad2](https://github.com/boundaryml/baml/commit/6501ad20985a426d1ae3952a24062595e935de53)) - Chris Watts
- [Python] Support windows arm64 (#1944) - ([ef9e8be](https://github.com/boundaryml/baml/commit/ef9e8be2f59b0b1280842ff53963ba57f9c86275)) - aaronvg

### Bugs
- Maintain field order when rendering class in Python (#1931) - ([46921b7](https://github.com/boundaryml/baml/commit/46921b7ad9e0a5766f02828b267e08ec6b48ef8b)) - Antonio Sarosi
- [Go] Fix Union JSON serialization (#1936) - ([6d4eb2b](https://github.com/boundaryml/baml/commit/6d4eb2b14451137c950e931d39d072b1f79ba254)) - Todd Berman

## [0.87.2](https://github.com/boundaryml/baml/compare/0.87.1..0.87.2) - 2025-05-08

### Bugfixes
- [Go] Fix build of baml-cli for Go in linux (#1921) - ([d234dc9](https://github.com/boundaryml/baml/commit/d234dc922d6f01487a5e680ee52f1d8b28ef7ebb)) - Todd Berman
- Bump version to 0.87.2 - ([77d6502](https://github.com/boundaryml/baml/commit/77d650219af58debc33d2544a2704197645ced32)) - Aaron Villalpando

## [0.87.1](https://github.com/boundaryml/baml/compare/0.87.0..0.87.1) - 2025-05-07

### Bugfixes
- [bug] Correctly parse enums when other json elements may exist in the string (#1913) - ([da202d1](https://github.com/boundaryml/baml/commit/da202d1e2c9147bf72b993e7ad1d0f203487b284)) - hellovai
- [Go] Switch bool to int in CFFI layer (#1915) - ([4b7075a](https://github.com/boundaryml/baml/commit/4b7075affc8f24d07d8aa3a1695266d5864e1771)) - Todd Berman
- Disable completions due to issues with non-ascii chars (#1917) - ([c0f3fa1](https://github.com/boundaryml/baml/commit/c0f3fa1e484d1fce4f519447065f61783d128ab3)) - aaronvg
- Bump version to 0.87.1 - ([d5a1d3f](https://github.com/boundaryml/baml/commit/d5a1d3fb99a4a9fa82f193b47be1db20782a0eeb)) - Aaron Villalpando

## [0.87.0](https://github.com/boundaryml/baml/compare/0.86.1..0.87.0) - 2025-05-06

### Miscellaneous Chores

- run integ tests during the release workflow (#1897) - ([9645621](https://github.com/boundaryml/baml/commit/964562186583d399ce7f6fe7984d71cce92d1a5a)) - Samuel Lijin
- fix concurrency groups (#1902) - ([8104859](https://github.com/boundaryml/baml/commit/8104859fb2b99cf9f5701581300f6e4b99c30612)) - Samuel Lijin

### Bugfixes
- [Go] Fix optional struct fields (#1889) - ([7105b13](https://github.com/boundaryml/baml/commit/7105b13cb991e70be0cfaf338321aee6a3effbe9)) - Todd Berman
- [Go] Fix go enum encoding (#1892) - ([f198ba3](https://github.com/boundaryml/baml/commit/f198ba33eea9666406fefc3da6a08c152fd63b3a)) - Todd Berman
- [Go] Fix union encoding/decoding (#1898) - ([6a7dc25](https://github.com/boundaryml/baml/commit/6a7dc25e0baf61ab095b6c21a214f2f75e15b247)) - Todd Berman
- [Python] Export BamlClientFinishReason (#1907) - ([3c08e83](https://github.com/boundaryml/baml/commit/3c08e8307ca1c801d0acc15951df43f59048fb01)) - aaronvg
- make vertex http resonse parsing more lenient (#1909) - ([dd26a2d](https://github.com/boundaryml/baml/commit/dd26a2dbc4e860c9b2d97832cfc43e93c1b9f099)) - aaronvg

### Features
- [feature] Expose all types via type-builder (not just dynamic) (#1893) - ([a635a06](https://github.com/boundaryml/baml/commit/a635a06efb859b9d4fa246c89b45739c95f5eb22)) - hellovai
- Enable LSP Downloading to keep versions in sync (all platforms except windows) (#1910) - ([2a4771b](https://github.com/boundaryml/baml/commit/2a4771b8d9b41e2903f7a0f42ae36b6a46afbe95)) - aaronvg

## [0.86.1](https://github.com/boundaryml/baml/compare/0.86.0..0.86.1) - 2025-04-30


### Bugs
- Fix arguments for functions from go (#1884) - ([b83557c](https://github.com/boundaryml/baml/commit/b83557c2c2ff279e49a7e589f5d6f06e1bd59fba)) - Todd Berman
- Bump version to 0.86.1 - ([af4c366](https://github.com/boundaryml/baml/commit/af4c366c2633b6049dbdb87b8a8e0fb4ad08c286)) - Aaron Villalpando

## [0.86.0](https://github.com/boundaryml/baml/compare/0.85.0..0.86.0) - 2025-04-30

### Bug Fixes

- fix union streaming bug where unions wouldn't stream until they were done (#1858)
- Fix codegen when streaming done types (#1861) - ([d6c4ff3](https://github.com/boundaryml/baml/commit/d6c4ff30ebdaa4b90440b92b2d2045eca0205775)) - Greg Hale
- Go Encode/Decode fixes (#1865) - ([8ecb065](https://github.com/boundaryml/baml/commit/8ecb065d89cc10b9e306c6155146122ee3427a0f)) - Todd Berman
- Fix bedrock stalled stream protection not working with custom http client, and support additional_model_request_fields (#1877) - ([da15434](https://github.com/boundaryml/baml/commit/da1543470ff2a3601808e6ebc04548c1a56a445f)) - aaronvg
- Remove run command from CLI (#1879) - ([7684d71](https://github.com/boundaryml/baml/commit/7684d71c615c0dc4d093a2316cf06054292c74ae)) - hellovai
- [Rust LSP] Support generateCodeOnSave setting, clean up error messages (#1881) - ([784f1b1](https://github.com/boundaryml/baml/commit/784f1b1ccbb2361254020a2a389f8b2633c8a39a)) - aaronvg


### Features
- Download the right LSP and CLI depending on the project version (#1738) - ([429936d](https://github.com/boundaryml/baml/commit/429936dcfa802db5a51b9c250ce52ca5657fd3de)) - Antonio Sarosi
- make gcp auth work seamlessly from vscode (#1860) - ([484c449](https://github.com/boundaryml/baml/commit/484c44987dcf5b87512d333cc71bc2f2717c58a7)) - Samuel Lijin


## [0.85.0](https://github.com/boundaryml/baml/compare/0.84.4..0.85.0) - 2025-04-23

### Bug Fixes

- make playground env var reveal toggle visibility on the correct row (#1816) - ([5c3794a](https://github.com/boundaryml/baml/commit/5c3794a10b2257b8f3ef9c4cc8bc49429359dbe3)) - Samuel Lijin
- Fix issue where playground proxy wasn't actually used which caused CORS issues (#1841) - ([1657e35](https://github.com/boundaryml/baml/commit/1657e3529476ec1aa9ccdd2059e50795a3a5a0b9)) - aaronvg
- add support for plumbing through some errors for go (#1844) - ([766ba08](https://github.com/boundaryml/baml/commit/766ba08f4fb7062d977cc834e3016211d06ac27f)) - hellovai

### Features

- move REST API out of preview and add docs on streaming (#1818) - ([55e9d9d](https://github.com/boundaryml/baml/commit/55e9d9da7055b3ad708890d769128c9d1a1be403)) - Samuel Lijin
- Support claude models via vertex apis (#1820) - ([c8378bc](https://github.com/boundaryml/baml/commit/c8378bc4d049d6c254cb30b4fc4c3eaa95af1ff2)) - Samuel Lijin
- Support HTTPS_PROXY and HTTP_PROXY system proxies in AWS client by delegating to the reqwest client (#1827) - ([c5c7fc6](https://github.com/boundaryml/baml/commit/c5c7fc63138a391f16c432ba3cc84376189ef6b8)) - aaronvg
- Make Typescript generator have a `outputFormat "esm"` field to use ES Module-friendly imports (#1831) - ([d27e729](https://github.com/boundaryml/baml/commit/d27e729b9bb6d50fac0059401c4a8ca1269d8168)) - aaronvg
- Support ruby 3.4 (#1830) - ([960c7d8](https://github.com/boundaryml/baml/commit/960c7d8bc2adde79c1f62b1ed6887fde212ececb)) - aaronvg


### Miscellaneous
- Test collector using openai-generic client (groq) (#1813) - ([430e428](https://github.com/boundaryml/baml/commit/430e4288b3a8b17166832bd61beda1a36fa4d1c6)) - aaronvg
- Document jinja in checks and asserts (#1826) - ([b27c980](https://github.com/boundaryml/baml/commit/b27c98073519120914ad29fae0ca627fc1757b57)) - Greg Hale
- only print out vertex auth errors if it failed to auth completely (#1843) - ([e42a594](https://github.com/boundaryml/baml/commit/e42a594475557c75c04f2aeeafc77ffae7fdb0d9)) - aaronvg
- Bump version to 0.85.0 - ([654fec2](https://github.com/boundaryml/baml/commit/654fec219d88ff90fa64fdf77aa49a124cbd0d45)) - Aaron Villalpando

## [0.84.4](https://github.com/boundaryml/baml/compare/0.84.3..0.84.4) - 2025-04-17

### Bug Fixes

- make vscode proxy work again (#1806) - ([667851d](https://github.com/boundaryml/baml/commit/667851d2902c2eec26db3db7e98855ec3657ff8f)) - Samuel Lijin
- BAML gem supports ruby 3.4 (#1804) - ([eae1cec](https://github.com/boundaryml/baml/commit/eae1cec03c5993ee6aff3dfe50a0202483b26412)) - Dimitri Roche


## [0.84.3](https://github.com/boundaryml/baml/compare/0.84.2..0.84.3) - 2025-04-16

### Miscellaneous Chores

- reduce warnings when compiling non-wasm (#1796) - ([1cf28bb](https://github.com/boundaryml/baml/commit/1cf28bb080256734e6dcdcce8e4e61acab80b85f)) - Samuel Lijin


### Bugfixes
- [bug] fix downloader for go binary (#1797) - ([f5654c8](https://github.com/boundaryml/baml/commit/f5654c83b3ef13c5ed864be70f8f9bb502094efd)) - hellovai
- Support multiroot workspaces in the new Rust LSP (#1798) - ([691dece](https://github.com/boundaryml/baml/commit/691dece5783170d67db666290a85e1a20351fbeb)) - aaronvg
- Bump version to 0.84.3 - ([bdacb0c](https://github.com/boundaryml/baml/commit/bdacb0c51fd25b0aa2890752cd63f61e46d043dc)) - Aaron Villalpando

## [0.84.2](https://github.com/boundaryml/baml/compare/0.84.1..0.84.2) - 2025-04-16


### Bugfixes
- Disable formatting in LSP due to incorrect behavior (#1793) - ([36f0fe4](https://github.com/boundaryml/baml/commit/36f0fe4593dca119b7e346b02e23dba1142b61a6)) - aaronvg
- Bump version to 0.84.2 - ([f5c484d](https://github.com/boundaryml/baml/commit/f5c484d408b1657c0a06fcc4108f9a3bbe1e668a)) - Aaron Villalpando

## [0.84.1](https://github.com/boundaryml/baml/compare/0.84.0..0.84.1) - 2025-04-16


### Bugfixes
- [LSP] Fix issue where vscode-generated baml_client would have stale data (#1791) - ([93eb192](https://github.com/boundaryml/baml/commit/93eb192aa5ef1ed821393606c2f9b97dff552fbb)) - aaronvg
- Bump version to 0.84.1 - ([074a517](https://github.com/boundaryml/baml/commit/074a5171c2bd350133abe047766dbd057bc00d0b)) - Aaron Villalpando

## [0.84.0](https://github.com/boundaryml/baml/compare/0.83.0..0.84.0) - 2025-04-16

### Documentation

- document `aws sso login` support (#1753) - ([ea0ddd1](https://github.com/boundaryml/baml/commit/ea0ddd1f800ca445de0be2a250fe0d37863d4ac7)) - Samuel Lijin

### Features
- New LSP Rust server (#1465) - ([bab6cc9](https://github.com/boundaryml/baml/commit/bab6cc9a8c692c0e02ecfaab6a1b983795d51875)) - Greg Hale
- Add BETA support for go (#1744) - ([b623e76](https://github.com/boundaryml/baml/commit/b623e76973a2788fcf2930408ad399975d46db0c)) - hellovai
- add stripe and propel webhook types (#1762) - ([e018d10](https://github.com/boundaryml/baml/commit/e018d10c6d821a3e937adae3ef295f63eb5960f0)) - Samuel Lijin
- allow copy-pasting a .env file into vscode (#1770) - ([bd449f0](https://github.com/boundaryml/baml/commit/bd449f096bc3c30281544716cf9fd1cb606e0e94)) - Samuel Lijin
- add explicit handling for newlines in env vars (#1775) - ([b2dc8d0](https://github.com/boundaryml/baml/commit/b2dc8d054429ad4663648dd72561793264e36cc0)) - Samuel Lijin
- handle edge cases in env var rendering (#1786) - ([427a6db](https://github.com/boundaryml/baml/commit/427a6db3ee63f4d9a9e2cfce5f171bda32e6d19e)) - Samuel Lijin
- LLM function composition (#1722) - ([63b4e44](https://github.com/boundaryml/baml/commit/63b4e44695d51b14d3cf18218d2815bca49c73c9)) - Greg Hale

### Bugfixes
- Use `AnyValue: {}` for the `any` type in OpenAPI (#1773) - ([145e887](https://github.com/boundaryml/baml/commit/145e88708eafe0437b58305d85ff6cb9fb6be42d)) - Antonio Sarosi
- [bug-fix] Fixed issue with enums not rendering in the prompt for some types (#1769) - ([857de40](https://github.com/boundaryml/baml/commit/857de4008186101bcd87d50f8776075455b22f9d)) - hellovai
- Parser for openai must have `created` as an optional field (#1778) - ([db2a0dc](https://github.com/boundaryml/baml/commit/db2a0dc02b1bb73aaf81ab9f16e522a6dbfe578b)) - hellovai
- Fix issue where shorthand clients always had missing api keys (#1787) - ([39b7959](https://github.com/boundaryml/baml/commit/39b7959f4223cbea26f6dbfb461697dcac43771b)) - aaronvg


## [0.83.0](https://github.com/boundaryml/baml/compare/0.82.0..0.83.0) - 2025-04-09


### Documentation

- **(dynamic-types.mdx)** Fix unstable_features.add_json_schema section (#1734) - ([5ab2c3e](https://github.com/boundaryml/baml/commit/5ab2c3ec453c112689ba3460432b1823afb38827)) - Elijas Dapšauskas
- **(fallbacks)** fix typos (#1735) - ([463ad96](https://github.com/boundaryml/baml/commit/463ad96ca4bfa816a4497d549980960a2e8eaab2)) - Elijas Dapšauskas
- update all docs with bun and deno (#1736) - ([44346ae](https://github.com/boundaryml/baml/commit/44346aefe22bfde052a9cd5a30d427e2573254ee)) - Chris Watts

### Features

- Playground now supports your aws profiles (no need to copy aws access key ids) (#1493) - ([53d3343](https://github.com/boundaryml/baml/commit/53d3343a304d6607460ca6ae25517577b22c6b1c)) - Samuel Lijin
- Playground Tests can now be run in parallel (#1717) - ([b944438](https://github.com/boundaryml/baml/commit/b94443886931572572d4ba3a928c65a8e8db71d3)) - Rahul Tiwari

### Bug-fix

- Fix self-loop cycle detections in type-system (#1725) - ([ad5da5d](https://github.com/boundaryml/baml/commit/ad5da5dc289bbf527badc6207de8d613c81f7572)) - hellovai
- Fix issue where setting baml_log would be overwritten (#1732) - ([412d7f8](https://github.com/boundaryml/baml/commit/412d7f8fec2b046098b65258d32cf8f213a4e5a2)) - aaronvg
- Don't allow parameters with checks/asserts (#1689) - ([e66a462](https://github.com/boundaryml/baml/commit/e66a462bad18e33404a3c4c1c966fef22d6883ca)) - Antonio Sarosi
- Fix whitespace in JSON keys by trimming during parsing (#1727) - ([5a93b0d](https://github.com/boundaryml/baml/commit/5a93b0d0e8a2011e58b42df94bc6fb09a26bff16)) - mentatbot[bot]
- Fix python codgen use `Literal` directly instead of `types.Literal`. (#1697) - ([b0e79a2](https://github.com/boundaryml/baml/commit/b0e79a271203e5af6878d3f5827124995fb48852)) - hellovai
- Support OpenSamba by parsing floats into ints (#1746) - ([28e3d0a](https://github.com/boundaryml/baml/commit/28e3d0a5e18796b8fb71ed57c7c2adad50a0d266)) - Greg Hale

## [0.82.0](https://github.com/boundaryml/baml/compare/0.81.3..0.82.0) - 2025-04-01


### Breaking changes

- HTTPResponses have a HTTPBody object. You must now call `.json()` or `.text()` to access the http response message.

```python
    response = call.http_response
    assert response is not None
    response_body = response.body.json()
    assert isinstance(response_body, dict)
    assert "candidates" in response_body
```

### Features
- Support AWS Bedrock in the Collector API (#1703) - ([e7c45c2](https://github.com/boundaryml/baml/commit/e7c45c27a63aba273151f246834d9a049c763168)) - aaronvg


### Bugfixes
- Allow multiple unique block-level attributes (#1686) - ([f945204](https://github.com/boundaryml/baml/commit/f94520489bd597b7dc69fdaf7617c5a9edcf9079)) - Greg Hale

## [0.81.3](https://github.com/boundaryml/baml/compare/0.81.2..0.81.3) - 2025-03-26


### Bug fixes
- Fix ts build arguments (#1682) - ([83db889](https://github.com/boundaryml/baml/commit/83db889fa3c7e594f2e6133ba1c736afc332e710)) - aaronvg
- Bump version to 0.81.3 - ([6a65cfa](https://github.com/boundaryml/baml/commit/6a65cfaed212e0df1f99cf4a0697e2e141533bbb)) - Aaron Villalpando

## [0.81.2](https://github.com/boundaryml/baml/compare/0.81.1..0.81.2) - 2025-03-26

## Bug fixes
- lower glibc for 2 more platforms (#1677) - ([516b125](https://github.com/boundaryml/baml/commit/516b125eb6b61932ed91a1ccdbd795d1bf236879)) - aaronvg
- Bump version to 0.81.2 - ([c70ed33](https://github.com/boundaryml/baml/commit/c70ed33282a33913784f0180a335204785d94d55)) - Aaron Villalpando

## [0.81.1](https://github.com/boundaryml/baml/compare/0.81.0..0.81.1) - 2025-03-25

## Bug fixes
- [docs] Fix broken links + add more docs for openai generic (#1667) - ([1d53ed8](https://github.com/boundaryml/baml/commit/1d53ed85a2e2419be24d141ccf45665bff18fdac)) - hellovai
- Make TS compatible with glibc 2.31+ (#1670) - ([a37cdb7](https://github.com/boundaryml/baml/commit/a37cdb762b4cf5c9bec5af760dbed0d9853e9165)) - aaronvg

## [0.81.0](https://github.com/boundaryml/baml/compare/0.80.2..0.81.0) - 2025-03-24

### Bug Fixes

- make vertex work in vscode playground again (#1645) - ([7d6b4cb](https://github.com/boundaryml/baml/commit/7d6b4cb94660672d833972c50b69b3d0c7c6308a)) - Samuel Lijin
- improve error quality when vertex oauth exchange fails (#1647) - ([c96fdb4](https://github.com/boundaryml/baml/commit/c96fdb4420f84a964498535e636708a3df668a17)) - Samuel Lijin
- Playground should persist tests and functions across code errors (#1644) - ([8e8cdc3](https://github.com/boundaryml/baml/commit/8e8cdc3f269836f82d4c28e4b7efd5d978670d13)) - Greg Hale
- [bug] In BAML tests, functions with typebuilder wouldnt stream (#1660) - ([ffe81a3](https://github.com/boundaryml/baml/commit/ffe81a33289b2884b842c2073863778361057998)) - hellovai
- [bug] Fix log level prints (#1661) - ([cf8823e](https://github.com/boundaryml/baml/commit/cf8823e3ad4a1d023bd9da86fa971cb55dfac7d5)) - hellovai
- Fix add file button, drag and rename in fiddle frontend (#1656) - ([4e476dc](https://github.com/boundaryml/baml/commit/4e476dc0c436a582c18ed588fb079282e2c8890f)) - Antonio Sarosi
- Dont use require() for imports in TS files (#1665) - ([b628def](https://github.com/boundaryml/baml/commit/b628def1ba58e288caf8ae452d1f4889d0431f66)) - aaronvg


### Features

- add media (image/audio) support for React/Next.js (#1646) - ([c3b9011](https://github.com/boundaryml/baml/commit/c3b9011cc00f45d5b3381248bdf35107fb831739)) - Chris Watts
- move browser baml Image from @boundaryml/baml to generated code (#1663) - ([f503cdc](https://github.com/boundaryml/baml/commit/f503cdc97821f4177368977f2f45ad9c0fff4ae5)) - Chris Watts

### Docs
- [docs] improve documentation for llm clients and highlight openai-generic compatability (#1655) - ([a760f84](https://github.com/boundaryml/baml/commit/a760f84c045e3d4ab7a3779959a5fa954f23c4b5)) - hellovai



## [0.80.2](https://github.com/boundaryml/baml/compare/0.80.1..0.80.2) - 2025-03-20

## Bug Fixes
- Fix cases where collector failed in an unrecoverable way (#1633) - ([03a11d5](https://github.com/boundaryml/baml/commit/03a11d5b56bae986405adfbf97bafc604bbd4f41)) - hellovai
- Fix exit codes and error logging for baml cli (#1636) - ([6c3c6d5](https://github.com/boundaryml/baml/commit/6c3c6d5d1d11a8c036659d9c9eba87b65e179ac8)) - aaronvg
- Added `from __future__ import annotations` to support python 3.9 (#1642) - ([daf2b34](https://github.com/boundaryml/baml/commit/daf2b34cbe70700477301c712a0a17cd69eb0f17)) - hellovai
- Bump version to 0.80.2 - ([0e72137](https://github.com/boundaryml/baml/commit/0e721378008fd900554e98a005a9a01a9f3e7a84)) - Aaron Villalpando

## [0.80.1](https://github.com/boundaryml/baml/compare/0.80.0..0.80.1) - 2025-03-19


### Bug Fixes
- Fix streaming for dynamic types (#1606) - ([eac4bbf](https://github.com/boundaryml/baml/commit/eac4bbfd99c0b6f54cd3ab5962eb7d52d6e72216)) - hellovai


## [0.80.0](https://github.com/boundaryml/baml/compare/0.79.0..0.80.0) - 2025-03-18


### Bug Fixes
- Removed default params from python code gen (#1627) - ([ff613ce](https://github.com/boundaryml/baml/commit/ff613ce9df7f7d1c4e036ca8f92c1bd3c38ad4a4)) - hellovai

### Documentation
- Add docs for with_options, and for the Collector (#1601) - ([b19d1ee](https://github.com/boundaryml/baml/commit/b19d1ee3031a35b8afa9e6b74240fa0a67429a77)) - aaronvg

## [0.79.0](https://github.com/boundaryml/baml/compare/0.78.0..0.79.0) - 2025-03-18

### Features
- Add a way to create a `b` baml_client with a default set of options (#1595) - ([0f2c730](https://github.com/boundaryml/baml/commit/0f2c730ef4da47f1bd78632d5831c05d1d2d2765)) - aaronvg
- Expose Prompt and Parser separately so people can use their own http clients or use Batch APIs (#1505) - ([8e48147](https://github.com/boundaryml/baml/commit/8e4814705fbffb87d0afa4b107e6f2509f3f82d9)) - Antonio Sarosi
- Add support for manually configuring log level via code (#1600) - ([d036c4f](https://github.com/boundaryml/baml/commit/d036c4f9f68e84df1c2777d1ea708eb2adc5510c)) - hellovai
- implement baml-cli test to run BAML-defined tests via terminal (#1458) - ([1ecde1c](https://github.com/boundaryml/baml/commit/1ecde1c1c5ccd93eae4e38ae1e9f2f6c5de799ab)) - Samuel Lijin
- Add typescript collector to expose tokens (#1573) - ([90b7434](https://github.com/boundaryml/baml/commit/90b74345270492fe606977f1aa24bc0ccb54a6b6)) - aaronvg
- Add ruby collector to expose tokens (#1587) - ([ab7a269](https://github.com/boundaryml/baml/commit/ab7a269e78ba645044dd6156afba2979bfd1f972)) - aaronvg
- support lazily loading env vars in python (#1558) - ([12ab33f](https://github.com/boundaryml/baml/commit/12ab33f6a81479ec0aec977d9f1a93b654a1119f)) - hellovai
- Add version checking and safe import mechanism for Python generators (#1591) - ([f681243](https://github.com/boundaryml/baml/commit/f6812435622cdedbac9072852f3c71c72047ad4e)) - hellovai

### Bug Fixes

- propagate finish reason correctly, add tests to ensure correct deserialization (#1566) - ([b80a2ef](https://github.com/boundaryml/baml/commit/b80a2efac5ff9663522b10304a1b381ce60c35b7)) - hellovai
- google-vertex docs (#1571) - ([2a3c865](https://github.com/boundaryml/baml/commit/2a3c8652e4a1604624f669a4cae0bd835167bd83)) - Ben Epstein
- fix docs for assert and deno (#1609)
- fix wasm build, and add playground to docs (#1616)
- vertex auth should log when a given strategy fails (#1577) - ([23c857d](https://github.com/boundaryml/baml/commit/23c857dc3d710123055f2e44f1fd73305925c271)) - Samuel Lijin
- Add default values to function parameters in python clients (#1579) - ([14eba7e](https://github.com/boundaryml/baml/commit/14eba7e58ae3ba627143b028cf51f8840bf283ab)) - Greg Hale
- Maintain attribute information when combining fields (#1585) - ([4153bd3](https://github.com/boundaryml/baml/commit/4153bd379223c422168067060f49dad4cac14407)) - Antonio Sarosi
- [BUGFIX] Fix a "null"-rendering issue (#1575) - ([09db83e](https://github.com/boundaryml/baml/commit/09db83e2acc7cb6c02f08e045904ac8d2ee10158)) - Greg Hale
- Fix event handling in BamlStream to use non-blocking queue retrieval (#1596) - ([05460cd](https://github.com/boundaryml/baml/commit/05460cd90d51f8dd9e7bcb5d90d993688184d1eb)) - hellovai
- Fix partial recursive aliases and broken Python integ test (#1598) - ([4a9d451](https://github.com/boundaryml/baml/commit/4a9d45145322df41dc1e2e36f46779a718b3041e)) - Antonio Sarosi
- Fix partial recursive aliases codegen (#1611) - ([1839acf](https://github.com/boundaryml/baml/commit/1839acf3a11ca5e278e027d38f284c724b5c066c)) - Antonio Sarosi
- Fix ambiguous literal string parsing (#1623) - ([c0cac50](https://github.com/boundaryml/baml/commit/c0cac50f786bcda5e05dfb204c8974e82d377947)) - Antonio Sarosi

### Miscellaneous Chores

- speed up ruby dev builds (#1597) - ([73eb09c](https://github.com/boundaryml/baml/commit/73eb09c9d432edd4ad98a49b66cdf0b10c7a459e)) - Samuel Lijin

### Docs

- RAG example (#1581) - ([56a8c75](https://github.com/boundaryml/baml/commit/56a8c75f0c82a7db6f68064c8981972422458240)) - Prashanth Rao
- baml tool calling control flow image (#1563) - ([754171a](https://github.com/boundaryml/baml/commit/754171ac409f168c09cc5ac5681724356d71d681)) - Ben Epstein
- Update README.md - Align Chat Agent Example with ReplyTool Model (#1570) - ([166cdaa](https://github.com/boundaryml/baml/commit/166cdaa250011e8cb21615c13b7d417af7a4592b)) - Andriy Tkach
- Fix tutorial icon (#1594) - ([3500413](https://github.com/boundaryml/baml/commit/35004137abff0ac84914bf665008ea69524f521e)) - Michael Yen
- Update BAML documentation to clarify recursive class definitions and map type in TypeBuilder (#1605) - ([c5fb371](https://github.com/boundaryml/baml/commit/c5fb37165ccfa376f77f46b2ea387a90748808cb)) - hellovai
- Remove redundant model for RAG example (#1583) - ([6c6c5c2](https://github.com/boundaryml/baml/commit/6c6c5c29f8d1689f6e3fc9b6056b28faacbf746c)) - Prashanth Rao


## [0.78.0](https://github.com/boundaryml/baml/compare/0.77.0..0.78.0) - 2025-03-05

### Bug Fixes

- **(docs)** fix broken links (/ref/baml-client -> /ref/baml_client) and broken code (missing comma) (#1522) - ([a881571](https://github.com/boundaryml/baml/commit/a88157159a660b50d09e88ff107c18f698bea6ee)) - Elijas Dapšauskas
- Fix broken Next JS Guide Link
- Allow types to have multiple block-level constraints (#1545) - ([e4dc633](https://github.com/boundaryml/baml/commit/e4dc633807fb9430a414a77d0fed9d43b0361422)) - Greg Hale
- Resolve all non-google file uris when calling gemini Fixes #1548 (#1553) - ([0fe8e10](https://github.com/boundaryml/baml/commit/0fe8e105593ba233eafcd6f8fadad77c318a2e99)) - hellovai


### Features

- **(runtime)** claude now supports image URLs in requests (#1542) - ([c2d35d4](https://github.com/boundaryml/baml/commit/c2d35d4e4b9de908ae1c56a56edbc3f21139f36d)) - Samuel Lijin
- (Python) Expose tokens / prompt / http response etc through the Collector interface - (pre-alpha release) (#1512) - ([9b21ace](https://github.com/boundaryml/baml/commit/9b21ace306dee4cdcc0c24960da8794bc9cd9028)) - aaronvg
- Support thinking models from anthropic. (#1555) - ([be1119f](https://github.com/boundaryml/baml/commit/be1119f89ca46cd147c51589dc8c47c1e5f6f3ea)) - hellovai
- Support VSCode Rename for enums & type aliases (#1552) - ([80ba612](https://github.com/boundaryml/baml/commit/80ba6121c079c82e61dbaec74012f0c0a50c088c)) - Antonio Sarosi
- Parser improvements (#1536) - ([8f758ef](https://github.com/boundaryml/baml/commit/8f758ef29cee811c124c234304d65bca281ee8d6)) - hellovai

## [0.77.0](https://github.com/boundaryml/baml/compare/0.76.2..0.77.0) - 2025-02-25

### Bug fixes

- Fix truthy bug in jinja and improve static analysis (#1503) - ([b8e3423](https://github.com/boundaryml/baml/commit/b8e34231ef10f80dc2aaaba6bcd84618381f933c)) - Greg Hale
- Rename Null to None in jinja (#1504) - ([f42567d](https://github.com/boundaryml/baml/commit/f42567d40195841527b9193be154dc517155907a)) - Greg Hale
- Fixed React Codegen in VSCode (#1490) - ([74b3dbf](https://github.com/boundaryml/baml/commit/74b3dbf35875078e7e4b5be542c2d73702ff82b8)) - Chris Watts
- Release python GIL more liberally in baml_client.sync_client (#1501) - ([4d7f3d3](https://github.com/boundaryml/baml/commit/4d7f3d361a72cb82839730fcafdbd3915969cfcb)) - hellovai


### Features

- VSCode Proxy can now be configured via API Keys UX (#1489) - ([8671527](https://github.com/boundaryml/baml/commit/867152734405c9cf24ecd836e85dadae9315950d)) - hellovai
- Support renaming of BAML class via LSP (#1518) - ([339068a](https://github.com/boundaryml/baml/commit/339068ac8165f6766f8efbba4e1417745fcc95a3)) - Antonio Sarosi

### Docs / Improvements

- update python installation instruction to use correct package name (#1508) - ([cd1a21b](https://github.com/boundaryml/baml/commit/cd1a21bebc1e7b2c6a94109f7457812ae889b92c)) - Elijas Dapšauskas
- fix typo (mutliplier -> multiplier) (#1510) - ([c6d4126](https://github.com/boundaryml/baml/commit/c6d41264f8405da0312b00f0a845d18a270ea79f)) - Elijas Dapšauskas
- Update ruby.mdx (#1506) - ([22b35a4](https://github.com/boundaryml/baml/commit/22b35a43518217d75b0050ec03da138991b53e48)) - aaronvg
- Update overview.mdx (#1507) - ([2b19892](https://github.com/boundaryml/baml/commit/2b1989238b8bced47e08dbff58b5f856a337e139)) - aaronvg
- remove await in python snippet in typebuilder.mdx (#1495) - ([d30220d](https://github.com/boundaryml/baml/commit/d30220d980cc3a06a0bb8f7a873c4f9229bbbd50)) - hellovai



## [0.76.2](https://github.com/boundaryml/baml/compare/0.76.1..0.76.2) - 2025-02-18

### Bug Fixes

- fix openapi parser for baml_options (#1484) - ([c8d2e13](https://github.com/boundaryml/baml/commit/c8d2e1375aa7162e22e4a32133c0f768dd46623b)) - hellovai, invakid404


## [0.76.1](https://github.com/boundaryml/baml/compare/0.76.0..0.76.1) - 2025-02-18


### Bugs
- Attempt to fix release script for TS (#1479) - ([e048080](https://github.com/boundaryml/baml/commit/e0480801552f21fb818f904531727d9397628935)) - aaronvg

## [0.76.0](https://github.com/boundaryml/baml/compare/0.75.0..0.76.0) - 2025-02-18

We added a new NextJS generator and deep support for Typebuilder!! Read the docs to learn more about it!

### Bug Fixes

- Default max_tokens to null for openai providers (azure defaults to 4069 still) (#1438) - ([1ee0124](https://github.com/boundaryml/baml/commit/1ee01242ceca4bd39eed110deeabb30888d35ba1)) - Chris Watts
- Rest/OpenAPI: Fix the way we parse providers for during reading client-registry (#1428) - ([9ec9927](https://github.com/boundaryml/baml/commit/9ec992746beb0e54772bfe92586d47079643f6a2)) - hellovai
- Fix typescript partial types codegen (#1437) - ([078eef7](https://github.com/boundaryml/baml/commit/078eef7d046bab7816bd6c105bf996962fdfe97f)) - Greg Hale
- import typealias correctly for python 3.8+ from typing_extensions Fixes #1448 (#1451) - ([2b1d51d](https://github.com/boundaryml/baml/commit/2b1d51d12b95cc2fb21c8f73658441b530fbcc07)) - hellovai
- Enhance error handling and validation for duplicate definitions (#1462) - ([9f6443c](https://github.com/boundaryml/baml/commit/9f6443c51324e8323c50d186c1c10afe39ad6861)) - hellovai
- Fix default None and Optional Nesting in python partial types (#1459) - ([06a311b](https://github.com/boundaryml/baml/commit/06a311bd159082d8a9925b7283953b4754340387)) - Greg Hale
- Show nicer error message when VSCode extension crashes (#1467) - ([d14a913](https://github.com/boundaryml/baml/commit/d14a913401930a185df4df4c7fe0bce6f4ecc1e2)) - Antonio Sarosi

### Documentation

- Improve docs for Chain-of-thought prompting Fixes #1412 (#1445) - ([79083b1](https://github.com/boundaryml/baml/commit/79083b13a37c42d603f24b44e27a02993acc2ac3)) - hellovai
- Update README.md (#1430) - ([f5f9291](https://github.com/boundaryml/baml/commit/f5f92911e637028627641c12ac30123d0607e2e3)) - Yasser Shalabi

### Features

- NextJS Generator (read the docs!)  (#1346) - ([0b792de](https://github.com/boundaryml/baml/commit/0b792decf96ebd2c84e6b9388b996612910e52f8)) - Chris Watts
- Implement `TypeBuilder::add_baml` (#1449) - ([da76b96](https://github.com/boundaryml/baml/commit/da76b963f98a916cefdc5a763f7e97f1333e9283)) - Antonio Sarosi
- Add a TypeBuilder string representation! (#1260) - ([fca8b91](https://github.com/boundaryml/baml/commit/fca8b91eede7ebe26393e332497b64c7e6edf0e6)) - afyef
- Add ClientHttpError support across language clients (#1443) - ([1d481f1](https://github.com/boundaryml/baml/commit/1d481f1994ba90bb135aa4340d646f7768692b6a)) - hellovai
- Add duration display option to test panel tabular view (#1463) - ([4d5c993](https://github.com/boundaryml/baml/commit/4d5c9931a7f1f6d07f597309ef5ca6260bf5e5c9)) - hellovai
- Hide API credentials from frontend rendering for raw curl (#1431) - ([03735fe](https://github.com/boundaryml/baml/commit/03735feb5b9e70ad6a872e1c5d0837eea43034df)) - Greg Hale
- Support overriding `media_type` when using from_url() Fixes #1436 (#1444) - ([c913f09](https://github.com/boundaryml/baml/commit/c913f09389ce0d63498e1aede6d61008b6b3f3f0)) - hellovai
- Adding support for Azure AI Foundary (#1469) - ([92e139a](https://github.com/boundaryml/baml/commit/92e139aa61dc85e79de9bc9d3d5305f61e34854d)) - hellovai
- Add client response type validation and support for LLM clients (#1473) - ([2987d59](https://github.com/boundaryml/baml/commit/2987d591718440a77cea77b0f30768904b06e0bb)) - hellovai


## [0.75.0](https://github.com/boundaryml/baml/compare/0.74.0..0.75.0) - 2025-02-06

### Features

- Implement tests for dynamic types (#1343) - ([7f852d0](https://github.com/boundaryml/baml/commit/7f852d02892637b3a6e9637e59b26c2ec822e626)) - Antonio Sarosi

### Bug Fixes

- issue with o1 models not accepting max_tokens (#1410) - ([3831243](https://github.com/boundaryml/baml/commit/383124339dd71a5097f61a75b2e5c7121f5e9a8d)) - Chris Watts
- Fix panic when recursive type alias is used as class field (#1399) - ([f36f80c](https://github.com/boundaryml/baml/commit/f36f80c7d1f8fa4d5b4f52baaac3772cd054f8cf)) - Antonio Sarosi
- Fix infinite cycles in client fallbacks (#1401) - ([7b7eec0](https://github.com/boundaryml/baml/commit/7b7eec01412e52429f447c7edebfead7f96e2601)) - Antonio Sarosi
- Fix panic when using type alias that points to enum (#1407) - ([8994ba6](https://github.com/boundaryml/baml/commit/8994ba6011c70d22e5d9852c0e15b54b683addbb)) - Antonio Sarosi
- Track Pending fields in Semantic Streaming (#1411) - ([026bc21](https://github.com/boundaryml/baml/commit/026bc21c4b9d5c687c413342a202b6b09f5504b0)) - Greg Hale
- In prompt rendering, recurse into recursive type alias unions (#1416) - ([a648559](https://github.com/boundaryml/baml/commit/a6485597c0e44c9b44ba9fc89dbe423b3dd9b61e)) - Antonio Sarosi

### Documentation

- Fix typos in README.md (#1402) - ([cc132ad](https://github.com/boundaryml/baml/commit/cc132ad2d035df42b67ef37f1c696b496e08a4ca)) - Prashanth Rao


## [0.74.0](https://github.com/boundaryml/baml/compare/0.73.5..0.74.0) - 2025-01-30

### Features

- Add dark mode to docs (#1382) - ([c684e2d](https://github.com/boundaryml/baml/commit/c684e2d2d35fd9d62e2aae01b4025e5302c3740b)) - Chris Watts
- dedent strings parsed within triple quote blocks (#1395) - ([8ce04a9](https://github.com/boundaryml/baml/commit/8ce04a951ef9ac7dc2eab934c8163af2440b52bb)) - hellovai
- Update README with better details (#1380) - ([02d1950](https://github.com/boundaryml/baml/commit/02d19503759986c0dba3b022afb03f45a52c31ad)) - hellovai
- Semantic Streaming (#1293) - ([e30bdd5](https://github.com/boundaryml/baml/commit/e30bdd526910f11a6a9057cc4df90cf302939666)) - Greg Hale


### Bugfixes
- Drop unnecessary jsonwebtoken dep in wasm build (#1381) - ([7b85c71](https://github.com/boundaryml/baml/commit/7b85c715e07be8f908ee114c50b85bd784cf567b)) - Greg Hale
- Removing broken links (#1388) - ([e4b0b5b](https://github.com/boundaryml/baml/commit/e4b0b5ba390d3449247bfebb1f24013df69b6068)) - hellovai
- Reduce JS client memory usage considerably during streaming (#1390) - ([3165e0f](https://github.com/boundaryml/baml/commit/3165e0f3126d94691bdd1e0a1411ee6de8ed0dea)) - aaronvg
- Fix issue with semantic-streaming on unions of classes (#1393) - ([39b499d](https://github.com/boundaryml/baml/commit/39b499de396973bc1d1da991079a8d587cb29d75)) - Greg Hale
- Fix issue where output panel pops open in cursor (#1394) - ([5fd5c46](https://github.com/boundaryml/baml/commit/5fd5c4672887050db533bda4c6f0f46b7ef18644)) - hellovai


## [0.73.5](https://github.com/boundaryml/baml/compare/0.73.4..0.73.5) - 2025-01-27


### Bugfixes
- Fix Google AI system prompt JSON (#1374) - ([fe366fe](https://github.com/boundaryml/baml/commit/fe366fe4036b2c9d6863a0d3246df2526bdcb3a4)) - Antonio Sarosi
- show token usage in the playground card view (#1376) - ([0500a87](https://github.com/boundaryml/baml/commit/0500a87d98c6198807a04268f23a436fb260bec3)) - aaronvg
- Bump version to 0.73.5 - ([a32aebf](https://github.com/boundaryml/baml/commit/a32aebf51d0f6b5471fe884fa8a0da21aa45c753)) - Aaron Villalpando

## [0.73.4](https://github.com/boundaryml/baml/compare/0.73.3..0.73.4) - 2025-01-22
Fix another issue where playground could rerender over and over

## [0.73.3](https://github.com/boundaryml/baml/compare/0.73.2..0.73.3) - 2025-01-22
Fix issue where playground could rerender over and over

### Bug Fixes

- fix rerendering of component causing performance issue in the playground (#1368)

## [0.73.2](https://github.com/boundaryml/baml/compare/0.73.1..0.73.2) - 2025-01-22


### Bugfixes
- Gemini should use system message (#1364) - ([b29fb18](https://github.com/boundaryml/baml/commit/b29fb18386634e6e75cc9149b09592889619ba22)) - hellovai
- Add more explanations to the tool use doc (#1324) - ([bf048a6](https://github.com/boundaryml/baml/commit/bf048a6871f4073807ce1acbe39a411ace42406e)) - Ben Epstein
- Improve playground performance in vscode (#1366) - ([ba2b0f1](https://github.com/boundaryml/baml/commit/ba2b0f17f8db321705f8c037c6ede5e6a34e2590)) - aaronvg
- Bump version to 0.73.2 - ([a877ca9](https://github.com/boundaryml/baml/commit/a877ca9b35ec7d643f80c1225d8de4b1b244486f)) - Aaron Villalpando

## [0.73.1](https://github.com/boundaryml/baml/compare/0.73.0..0.73.1) - 2025-01-22

## High-level Overview
This release includes V2 of our VSCode Playground!
It includes
- dark mode
- test history
- better rendering of errors, including markdown output renderer
- cleaner UI
- highlighting of inputs in prompts
- Condensed table view to see results
- Test navigation sidebar, to more quickly jump to different tests
- many bugfixes and stability issues!

See below for what we fixed and improved across all parts of BAML

### Documentation

- gemini generationConfig (#1348) - ([d3c7e1c](https://github.com/boundaryml/baml/commit/d3c7e1ca272ec191c60eb0a17e46c654db438217)) - Abhishek Tripathi
- add baml-cli fmt docs (#1299) - ([a25e2bc](https://github.com/boundaryml/baml/commit/a25e2bc9389dffce633a8c1cdfa77456998d82fa)) - hellovai
- Add more info on what forwarded options vs nonforwarded means (#1321) - ([9f39cb7](https://github.com/boundaryml/baml/commit/9f39cb7b3c6d9d9d7a53c73ac374458a0f56e7d8)) - aaronvg
- Update cursor IDE instructions (#1331) - ([98b7783](https://github.com/boundaryml/baml/commit/98b778397feb6bfeca9fd88a808546469c9f173b)) - aaronvg

### Features
- New Playground V2 (#1304) - ([fa22c4f](https://github.com/boundaryml/baml/commit/fa22c4f741dd939bc5b2122a6625f998c8071625)) - aaronvg
- update aws provider docs with credentials information (#1298) - ([aee52a3](https://github.com/boundaryml/baml/commit/aee52a3dc8417a32bc68cfdd43208ae1a5e3fd6e)) - Chris Watts
- implement a gcp auth chain for vertex-ai clients (#1328) - ([6dfa23b](https://github.com/boundaryml/baml/commit/6dfa23b1005fce7ba662cfe8efd666cf0b0a8d0b)) - Samuel Lijin

### Miscellaneous Chores

- (dx) split out integ tests into provider specific  (#1296) - ([2c6279c](https://github.com/boundaryml/baml/commit/2c6279c53a5d9baea5317d5c25d8a9d3b4899c02)) - Samuel Lijin
- add readmes for all relevant folders (#1302) - ([7165331](https://github.com/boundaryml/baml/commit/7165331fed459d2d3d2618774c2a6f9ec01d7fab)) - Chris Watts
- remove ai generated readme (#1306) - ([e0bf112](https://github.com/boundaryml/baml/commit/e0bf11278761777284c6e157fdd0bbf3354e8b98)) - Chris Watts
- fix elided-named-lifetimes and ban it (#1341) - ([ba303f0](https://github.com/boundaryml/baml/commit/ba303f0b44ecfcea248e17f3b9dedf558b28f63c)) - Samuel Lijin

### Bug
- update 404 link on docs (#1309) - ([65e2a1a](https://github.com/boundaryml/baml/commit/65e2a1ac2b2a158ea6f42193634dd21ff77d35b5)) - hellovai
- finish_reason_allow_list and finish_reason_deny_list should be case insensitive (#1333) - ([1cbb268](https://github.com/boundaryml/baml/commit/1cbb268be01b5f46e59e696cc83424ffe814c81c)) - hellovai
- windows generator bugfix (#1311) - ([ab64540](https://github.com/boundaryml/baml/commit/ab64540327f38a5bb8ca3452ad2c5a52d481bb9b)) - aaronvg
- Type-narrowing for `if` blocks (#1313) - ([546f58f](https://github.com/boundaryml/baml/commit/546f58f1bde022501e32e353ba432026bc4b7423)) - Greg Hale
- Enable ALPN feature in `reqwest` crate (#1318) - ([1ea1d8b](https://github.com/boundaryml/baml/commit/1ea1d8b37f20d0b1b63c14a24be10df1f00f1830)) - Antonio Sarosi
- Fix Vertex system prompt (#1319) - ([4b7db0f](https://github.com/boundaryml/baml/commit/4b7db0f2f4c7e829455f8f695be912db08a4cb74)) - Antonio Sarosi
- Add error boundary around posthog, add react-error-boundary dependency (#1327) - ([5c4acb4](https://github.com/boundaryml/baml/commit/5c4acb4e71d08386633c1c1a3149f6c779fd4aa2)) - aaronvg
- Make literals nullable in generated python (#1334) - ([68745d0](https://github.com/boundaryml/baml/commit/68745d0ae9ab4c3c59097e6930ae984fea9283ab)) - Greg Hale
- Fix type alias highlighting in promptfiddle (#1344) - ([81ab2ba](https://github.com/boundaryml/baml/commit/81ab2ba3dfe3679987572e4ce97170da0e06d767)) - Antonio Sarosi
- Fix field type parsing (#1349) - ([d08445f](https://github.com/boundaryml/baml/commit/d08445f6ffcafcdf0758cff398c14ffa4f14d311)) - hellovai
- Fix syntax highlighting for @@assert expressions with commas (#1357) - ([e5d595e](https://github.com/boundaryml/baml/commit/e5d595e311088574f4bbf94ddf95feb9abf727c9)) - aaronvg


## [0.72.0](https://github.com/boundaryml/baml/compare/0.71.1..0.71.2) - 2025-01-07

### Bug Fixes

- Update gemini 2 flash thinking model name check (#1283) - ([76ceeff](https://github.com/boundaryml/baml/commit/76ceeff0f780c0ddc9b6baaa2dc786e63c5c7377)) - Gasser-Aly

### Features

- get baml-fmt ready for beta (#1278) - ([abb0958](https://github.com/boundaryml/baml/commit/abb0958b8ee1c5d5000a3781677ee32da03daba4)) - Samuel Lijin
- provide saner semantics around aws_session_token (#1295) - ([98c6b99](https://github.com/boundaryml/baml/commit/98c6b999f5232c4bb6192183151ee52ce5416a0e)) - Samuel Lijin
- Include type aliases in Jinja (#1286) - ([207eab8](https://github.com/boundaryml/baml/commit/207eab8e2591577ecc863ff57c3572f268b41773)) - Antonio Sarosi
- Implement jump to definition for type aliases (#1287) - ([6cb5009](https://github.com/boundaryml/baml/commit/6cb50096e102f5c01f1371b616ca5bd2537610d9)) - Antonio Sarosi
- Improved 'o1' model detection in OpenAI client and updated documentation for error handling and client setup (#1290) - ([479d06e](https://github.com/boundaryml/baml/commit/479d06e4546538b3908422801b21a50f22a3fc3f)) - hellovai
- Add docs for recursive type aliases (#1294) - ([43a0007](https://github.com/boundaryml/baml/commit/43a0007876a04c3e71c808e377662a30a7c062b6)) - Antonio Sarosi

## [0.71.1](https://github.com/boundaryml/baml/compare/0.71.0..0.71.1) - 2024-12-31

- Bump version to 0.71.1 - ([4ff76e8](https://github.com/boundaryml/baml/commit/4ff76e8bbd697bd48b0f9b08044b3f2d98df476c)) - Aaron Villalpando

## [0.71.0](https://github.com/boundaryml/baml/compare/0.70.5..0.71.0) - 2024-12-31

### Bug Fixes

- fix concurrency docs (#1269)
- issue with aws credentials not being passed in correctly (#1266) - ([7b79ac4](https://github.com/boundaryml/baml/commit/7b79ac4c28620ca09e72139ee8cd8fc0dc23cec1)) - Chris Watts
- Fix windows generation through vscode always outputting to the root workspace directory if the path was ../ (#1247) - ([cdc1838](https://github.com/boundaryml/baml/commit/cdc1838c114fd4d13e032da9cf7312aa55a8a889)) - aaronvg
- Fix VSCode link (#1264) - ([14342cd](https://github.com/boundaryml/baml/commit/14342cd2b9cdf53d9c2cbdc16a800fc88ff1cdf1)) - Greg Hale
- Special-case handling of Flash Thinking Mode for Gemini (#1276) - ([039b45a](https://github.com/boundaryml/baml/commit/039b45a965b56dd415f6ec104a8d44343d144e79)) - Greg Hale
- Fix typescript trace bugs (#1275) - ([e41b5aa](https://github.com/boundaryml/baml/commit/e41b5aa8a52fad9f9a5f833b2d1cecd2cc195868)) - Edward Zhang
- Add token counts to raw.**str**() (#1277) - ([b57bd30](https://github.com/boundaryml/baml/commit/b57bd30747dae563cf40b560cd5da3e50b783c5d)) - aaronvg

### Features

- **(serve)** Add graceful Ctrl+C handling with exit message (#1238) - ([83e68f2](https://github.com/boundaryml/baml/commit/83e68f2aadd6638e767eacfbb6087ef2483dd361)) - revidious
- implement format-on-save in vscode and baml-cli fmt (#1246) - ([66af7c5](https://github.com/boundaryml/baml/commit/66af7c57d22098b8d4c42f0d49ead84090b16407)) - Samuel Lijin
- allow optional lists and maps (#1251) - ([9170b89](https://github.com/boundaryml/baml/commit/9170b899b799302a4fc0781d99a493bf9fc13095)) - revidious
- Implement Type Aliases (#1163) - ([6310c41](https://github.com/boundaryml/baml/commit/6310c41e7fbe838026180071e881242d79789a2a)) - Antonio Sarosi

### Miscellaneous Chores

- add approval reqs to release workflows (#1243) - ([d3b9596](https://github.com/boundaryml/baml/commit/d3b959674957bfd07fd44817022c64e5b4d248c7)) - Samuel Lijin
- "Switching LLMs" Docs Fixes (#1244) - ([c62cef4](https://github.com/boundaryml/baml/commit/c62cef4949e1326c8da88dc46df762165c8f7b87)) - Ethan
- Add tests for azure and failure scenarios (#1250) - ([20ec134](https://github.com/boundaryml/baml/commit/20ec1345d3b8e26cddea9eccacc1420bdb3be804)) - aaronvg
- clarified readme (#1263) - ([8cac1ef](https://github.com/boundaryml/baml/commit/8cac1ef24e78b7f537b1aabf393d1b2a0e400ca2)) - MoofSoup

## [0.70.5](https://github.com/boundaryml/baml/compare/0.70.1..0.70.5) - 2024-12-13

### Bug Fixes

- Remove log statements (#1230) - ([4bcdd19](https://github.com/boundaryml/baml/commit/4bcdd198f219cd016ee64cc6444dd62e69f796fb)) - hellovai
- Fix playground proxy related issues (#1228, #1229, #1237) - ([7384ba8](https://github.com/boundaryml/baml/commit/7384ba8cb5d1f012c50ddfb2a44a142ec9654397)) ([7bb6df4](https://github.com/boundaryml/baml/commit/7bb6df40fe37753b946ceeec6b30c4d9cdcc4ce7)) ([16054f5](https://github.com/boundaryml/baml/commit/16054f5f858dcaf80f013d466ceb9354c6a160b7)) - aaronvg

### DOCS

- deno run instead of dpx (#1225) - ([7c64299](https://github.com/boundaryml/baml/commit/7c642992cd7d52b7e7cd718542dfa68c41b5aab3)) - Jeffrey Konowitch
- Fix broken links (#1235) - ([859c699](https://github.com/boundaryml/baml/commit/859c6998cef7950d52cc3287f51d74106a58d89d)) - Samuel Lijin

### Features

- Support parsing primitive values from single-key objects (#1224) - ([935a190](https://github.com/boundaryml/baml/commit/935a190556d12077f961ce083723e7c1f816f387)) - revidious

## [0.70.1](https://github.com/boundaryml/baml/compare/0.70.0..0.70.1) - 2024-12-05

### Bug Fixes

- Make baml_py work with playwright/inspect (#1214) - ([6741999](https://github.com/boundaryml/baml/commit/674199992e21fb439a5c972c5868b6b3f106d267)) - Samuel Lijin
- Fix Python release pipeline (#1218) - ([bde634c](https://github.com/boundaryml/baml/commit/bde634cd6064784e77620f26f52202494fb659ec)) - Samuel Lijin

### Documentation

- Docs for LLM Clients paramaters updated (#1216) - ([6f99a28](https://github.com/boundaryml/baml/commit/6f99a28a918e557a75e2d763ac21ca587350adf4)) - hellovai

## [0.70.0](https://github.com/boundaryml/baml/compare/0.69.0..0.70.0) - 2024-12-04

### Bug Fixes

- Improvements for promptfiddle (#1201) - ([c6fb306](https://github.com/boundaryml/baml/commit/c6fb3067ce74f7864c8e071ed9ea3b3b1f69d00a)) - aaronvg
- Add vscode config to disable proxying (#1197) - ([c593284](https://github.com/boundaryml/baml/commit/c59328479a60847147d7141f0053fb208821d49a)) - aaronvg
- update lezer syntax for tests (#1199) - ([269ad9d](https://github.com/boundaryml/baml/commit/269ad9da5ca1dede5bf3d6a42f11f158cfe57dda)) - aaronvg
- Various playground fixes (#1202) - ([ce4f397](https://github.com/boundaryml/baml/commit/ce4f39737b88d2fcf27851ff8b230eda5a1e714b)) - aaronvg

### Documentation

- Add test-block constraints docs (#1198) - ([b566d4c](https://github.com/boundaryml/baml/commit/b566d4ceadab2bff0ae77765be63aadb4d3660d2)) - Greg Hale

### Features

- Fix azure client - ([9b57395](https://github.com/boundaryml/baml/commit/9b5739565b684c2179ac2ab24cabaa441a6269a7)) - hellovai
- Add new client paramters: allowed_roles, default_role, finish_reason_allow_list, finish_reason_deny_list (#1209) - ([9b57395](https://github.com/boundaryml/baml/commit/9b5739565b684c2179ac2ab24cabaa441a6269a7)) - hellovai

### Miscellaneous Chores

- cargo clippy (#1206) - ([c17e0da](https://github.com/boundaryml/baml/commit/c17e0da45db4188e0b0618d9e69f21220dc2fcff)) - Antonio Sarosi
- add colors to the CLI by default (#1208) - ([eba73c7](https://github.com/boundaryml/baml/commit/eba73c783c7f4e0013c0f128b0f2a7c20af330f0)) - Samuel Lijin
- simplify string formatting for readability (#1072) - ([3ebf08f](https://github.com/boundaryml/baml/commit/3ebf08fe54bcfcc384188296f32efa6a878416ec)) - Hamir Mahal

## [0.69.0](https://github.com/boundaryml/baml/compare/0.68.0..0.69.0) - 2024-11-26

### Documentation

- Move documentation link higher in README.md for better visibility (#1190) - ([aaa1149](https://github.com/boundaryml/baml/commit/aaa1149acca0b4552b2d84aba6e6ee933a3a6d6b)) - Dex
- Update Vertex docs for different publishers (#1191) - ([66b2274](https://github.com/boundaryml/baml/commit/66b2274f895615f15b5a6edba51444b7d98dcaa5)) - Antonio Sarosi
- Update TypeScript installation docs to use `pnpm exec` instead of deprecated `pnpx` (#1144) - ([56194b8](https://github.com/boundaryml/baml/commit/56194b8084a08447dfb6ca5bf537289cd36022c4)) - Manav Bokinala
- Update LM Studio documentation (#1176) - ([7689ce7](https://github.com/boundaryml/baml/commit/7689ce7c3c42d49a020b81e0bdca16ef8e0209c7)) - Jeff Winkler

### Features

- Support enums & literals as map keys (#1178) - ([39e0271](https://github.com/boundaryml/baml/commit/39e0271f605234535cc53470a6aedff07aaa0c6c)) - Antonio Sarosi
- Parse triple backtick strings, discarding the info header (#1162) - ([353b21e](https://github.com/boundaryml/baml/commit/353b21e0ba3689420dfea6ff50a9454cf87fa199)) - Samuel Lijin
- Add ability to validate types for template strings (#1161) - ([a578cc2](https://github.com/boundaryml/baml/commit/a578cc287abbd9c23697adc4c83bcf0979916fcf)) - hellovai
- Support single line quoteless JSON parsing (#1170) - ([b1b9cab](https://github.com/boundaryml/baml/commit/b1b9cabcd51f87afef0ef54c7ecd0e2349d97f83)) - hellovai
- Generated code includes docstrings from BAML source docstrings (#1177) - ([170ece9](https://github.com/boundaryml/baml/commit/170ece9e8d72e235a7f5d628739899cd564ee995)) - Greg Hale
- Add ability to parse clients statically whenever possible (#1193) - ([03d9475](https://github.com/boundaryml/baml/commit/03d947581ceb56a3c3498f2746f697ce06a55077)) - hellovai
- Support setting all env vars for AWS-bedrock (#1179) - ([fcdbdfb](https://github.com/boundaryml/baml/commit/fcdbdfbb80e5e7d09411b0e55aa0039b0be998bc)) - hellovai
- Add constraints to test blocks (#1185) - ([cafd2ea](https://github.com/boundaryml/baml/commit/cafd2ea35ac0d3129ddddb7c4fc81561a7316657)) - Greg Hale
- Add sum jinja filter (#1174) - ([2353862](https://github.com/boundaryml/baml/commit/2353862730ed3be9b354a9f6a6c20c4c75a6058f)) - Greg Hale
- Add openrouter key (#1186) - ([28d58c0](https://github.com/boundaryml/baml/commit/28d58c060320154bddfef03bdd6de67d27e26c0f)) - aaronvg

### Bug Fixes

- Fix image path in README.md (#1190) - ([aaa1149](https://github.com/boundaryml/baml/commit/aaa1149acca0b4552b2d84aba6e6ee933a3a6d6b)) - Dex
- Fix template string highlights (#1182) - ([60c823a](https://github.com/boundaryml/baml/commit/60c823a000507e6667670f96f1607ba2ea160c57)) - aaronvg
- Fix nextjs and TS server hot-reload (#1183) - ([22e6bbb](https://github.com/boundaryml/baml/commit/22e6bbb7dbe125b40f72d37e6fb8a73e603aade8)) - aaronvg
- Fix lang name (#1188) - ([8c3d536](https://github.com/boundaryml/baml/commit/8c3d5363dd36c32a512430f970da8c76788335e3)) - aaronvg
- Make id optional as gemini doesn't include it in openai generic (#1187) - ([97d1cd4](https://github.com/boundaryml/baml/commit/97d1cd48dc80bdfaeb08bf8a27b65c21a48145bd)) - aaronvg
- Correctly compute required_env_vars even for shorthand clients (#1164) - ([8b51b6e](https://github.com/boundaryml/baml/commit/8b51b6eb186b8c2853139e37e87a69a87e893059)) - hellovai
- Report wrong keyword errors in type defs (#1166) - ([3b1d152](https://github.com/boundaryml/baml/commit/3b1d15230c9ba6dae3cb8d9f0f7f7e9b75f8f00e)) - Antonio Sarosi
- Remove win32-arm64 support for now to fix yarn and deno builds (#1173) - ([c0234d7](https://github.com/boundaryml/baml/commit/c0234d730915506097ff17b54afd7316fdc850cd)) - aaronvg
- Validate fieldnames and types when using pydantic codegen (#1189) - ([93b393d](https://github.com/boundaryml/baml/commit/93b393ded048817fdb7ffef65cb698f9edb14764)) - Greg Hale

## [0.68.0](https://github.com/boundaryml/baml/compare/0.67.0..0.68.0) - 2024-11-11

### Documentation

### Features

- Recursive types! (#1065) - ([8100df9](https://github.com/boundaryml/baml/commit/8100df999e67690458e8bc6adc50575e855bd242)) - Antonio Sarosi
- Support specifying "region" for aws-bedrock (#1150) - ([cbe3c92](https://github.com/boundaryml/baml/commit/cbe3c9261b3fa5cd026b9492a2858c1822e354df)) - Samuel Lijin
- Add `hoisted_class_prefix` option in docs (#1154) - ([cf2298e](https://github.com/boundaryml/baml/commit/cf2298ec53c74c317c495c7b84e1a56a97193b4f)) - Antonio Sarosi
- Make render messages dynamic and use `hoisted_class_prefix` instead of `"schema"` (#1155) - ([873751b](https://github.com/boundaryml/baml/commit/873751ba84f736dfbcbd9cbb0b6debfe7081cc1f)) - Antonio Sarosi
- Support o1 in playground (allow certain models to disable streaming) (#1157) - ([09c6549](https://github.com/boundaryml/baml/commit/09c65497c3218387756775827ba22bcad16f0362)) - hellovai
- Add basic grammar for `a` vs `an` articles in ctx.output_format (#1158) - ([e084130](https://github.com/boundaryml/baml/commit/e0841307d4da809754d995a4524b39b87040f2d0)) - Antonio Sarosi

### Bug Fixes

- Improved syntax highlighting for template_strings (#1151) - ([8c43e37](https://github.com/boundaryml/baml/commit/8c43e37fdaa05d9f3626fde7ad56614610727348)) - Greg Hale
- Improved error detection for client&lt;llm&gt; parsing (#1026) - ([c6b1167](https://github.com/boundaryml/baml/commit/c6b116744f55f831352209c04cd6bce7b028eda9)) - hellovai
- Fix BAML_LOG_JSON logs for py, ruby, and TS (#1153) - ([9e08642](https://github.com/boundaryml/baml/commit/9e08642470435fbefca20b163de010dd805560b8)) - aaronvg

## [0.67.0](https://github.com/boundaryml/baml/compare/0.66.0..0.67.0) - 2024-11-05

### Bug Fixes

- URGENT: fix generated typescript code (#1147) - ([bd9da16](https://github.com/boundaryml/baml/commit/bd9da1683112d849595580866382cba2c6bed8be)) - hellovai

### Features

- Parser improvement: handle code within backticks (`) (#1146) - ([3d8ef34](https://github.com/boundaryml/baml/commit/3d8ef34af15a7f2b957876ffa71314ce38da2a01)) - hellovai

## [0.66.0](https://github.com/boundaryml/baml/compare/0.65.0..0.66.0) - 2024-11-04

### Features

- BAML_LOG supports JSON mode (#1137) - ([f140767](https://github.com/boundaryml/baml/commit/f1407674fc0d91c079fd93b655ff097a05475740)) - aaronvg
- Block-level constraints (#1124) - ([e931acb](https://github.com/boundaryml/baml/commit/e931acb7f765e86a70cb33cd86728aabe058024b)) - Greg Hale
- Parser improvement! Streaming arrays is much more stable and parsing file paths improved (#1134) - ([56570f0](https://github.com/boundaryml/baml/commit/56570f0fe6c4c09594eb757c8a78158cf0e73fcd)) - hellovai

### Documentation

- Improvements to Reference Documentation (#1125) - ([12c8fa7](https://github.com/boundaryml/baml/commit/12c8fa7ec5aea8571f27fb65b8f2a327a1a5e0ce)) - hellovai
- README.md: typo/readability fixes (#1092) - ([cb67e31](https://github.com/boundaryml/baml/commit/cb67e316dce2c4ee29b6fd625316f5df4409335f)) - Prathamesh Pawar
- README.md: Correct Promptfiddle link (#1108) - ([b296c4c](https://github.com/boundaryml/baml/commit/b296c4cf6104513e40ef89f17d534d6d8858f223)) - Sagar Sharma
- Fix broken links (#1133) - ([e0bfc94](https://github.com/boundaryml/baml/commit/e0bfc94f453f35971e871a4b121a1f35fa0b17cc)) - aaronvg

### Bug-fix

- Improve syntax highlighting for template strings (#1130) - ([54de4b6](https://github.com/boundaryml/baml/commit/54de4b6ed9144a68fe0a84d916679f9aec46fe28)) - hellovai
- Improved static analysis for literals in jinja (#1132) - ([b8a221f](https://github.com/boundaryml/baml/commit/b8a221ff44668e2b1d9fa75100c270ce5a227ed4)) - Greg Hale
- Adds missing imports to the sync_client template (#1131) - ([823f74c](https://github.com/boundaryml/baml/commit/823f74c88df3cc7b9ebb4b19b74b5ee6edbafd9c)) - Jesus Lizama
- Add `Checked` in baml client typescript (#1135) - ([ad759cd](https://github.com/boundaryml/baml/commit/ad759cdb67cb0b6a6d2bd0d16575e3e1bc847a68)) - Greg Hale
- Produce syntax error when user misses return type on functions (#1129) - ([034d6eb](https://github.com/boundaryml/baml/commit/034d6ebda38aded1c6a93321d363575156b0ecc6)) - hellovai

## [0.65.0](https://github.com/boundaryml/baml/compare/0.64.0..0.65.0) - 2024-10-31

### Documentation

- **New Documentation Structure**: Introduced version 3 of the documentation, enhancing clarity and organization. ([#1118](https://github.com/boundaryml/baml/commit/bab2767414172dd632437a57631c4cee04910518))

### Bug Fixes

- **Python Type Handling**: Moved Python Checked and Check types into `baml_client` for better type management. ([#1122](https://github.com/boundaryml/baml/commit/0ccf473fd821d25d431bbf4341c4e837967104bf))
- **Literal Input Type Checking**: Fixed an issue where literal inputs were not being type-checked correctly. ([#1121](https://github.com/boundaryml/baml/commit/aa5dc85026a175216b5caae6320d09a1fcd35752))

## [0.64.0](https://github.com/boundaryml/baml/compare/0.63.0..0.64.0) - 2024-10-29

### Bug Fixes

- **Playground Stability:** Prevented crashes in the playground due to malformed vertex credentials ([#1107](https://github.com/boundaryml/baml/commit/e665346fbc84a9b969a979cfdf1c70d530201e93)) - _Samuel Lijin_
- **Union Handling:** Addressed an issue with union types in the schema ([#1096](https://github.com/boundaryml/baml/commit/cb5ce7623d3e95464fb5e5152c4d2339458caa26)) - _Greg Hale_
- **WASM Function Signatures:** Resolved stack overflow when computing WASM function signatures ([#1100](https://github.com/boundaryml/baml/commit/aa736ed2d7386cae78421c22d5669c73d8921085)) - _aaronvg_
- **VSCode Extension:** Fixed crashes in the VSCode extension that caused the output panel to open unexpectedly ([#1103](https://github.com/boundaryml/baml/commit/cb5a266bc68f15483f3ec3fa0f4edbc8d176287a)) - _hellovai_
- **Static Analysis Improvements:** Enhanced static analysis on Jinja expressions and `regex_match` functions ([#1102](https://github.com/boundaryml/baml/commit/7ca8136ffbc690877091627415941674f6f14b2f), [#1104](https://github.com/boundaryml/baml/commit/83ddb1cfe81c9b5f6ae620c331c4eefe512c78bd)) - _hellovai_
- **Codegen Enhancements:** Fixed code generation for Python boolean literals and updated integration tests ([#1099](https://github.com/boundaryml/baml/commit/635976238fd9246bfb8764875358a36b4ec6a7f5)) - _Antonio Sarosi_
- **Enum Handling:** Improved substring alias handling for enums ([#1098](https://github.com/boundaryml/baml/commit/0c5cbd4ae03d2bc836ee4b61a7df638855bb72ca)) - _Miguel Cárdenas_
- **Syntax Highlighting:** Refined span calculations for Jinja expressions and improved VSCode syntax highlighting with Lezer ([#1110](https://github.com/boundaryml/baml/commit/a53072f5fe9fe83a0accb36e43a06550602a3c65)) - _hellovai_
- **Ruby Support:** Fixed literal boolean tests for Ruby ([#1109](https://github.com/boundaryml/baml/commit/23e590b0b2fdb51f80e7eced769baabd12b3be22)) - _Antonio Sarosi_

### Features

- **Constraint Support:** Added the ability to define constraints using Jinja expressions ([#1006](https://github.com/boundaryml/baml/commit/d794f28b4f8830b1a40cd08043ecdc562938d36e)) - _Greg Hale_
- **VSCode & Fiddle UI:** Introduced a new "Intro to Checks" UI for easier onboarding ([#1106](https://github.com/boundaryml/baml/commit/11efa5e97f8e9b8f385b7fb0e823f5ff2bc4c314)) - _Samuel Lijin_
- **Dev Container Configurations:** Added Dev Container configurations for streamlined development environments ([#1112](https://github.com/boundaryml/baml/commit/5790393d7ad320e9e257c09e461c9bc39310a834)) - _Antonio Sarosi_

### Documentation

- **Constraints Documentation:** Published new documentation for defining constraints in BAML ([#1113](https://github.com/boundaryml/baml/commit/6332021a59661d3931934adc2afbf4f99f6f4bee)) - _Greg Hale_
- **Dynamic Types Linking:** Added cross-links to dynamic types documentation for easier navigation ([#1116](https://github.com/boundaryml/baml/commit/8ce0a539d74d05438e8047e4e02022ddd7121e21)) - _Greg Hale_

### Miscellaneous

- **Code Quality:** Improved style and fixed typos in the codebase ([#1115](https://github.com/boundaryml/baml/commit/4c3970a6e6ce998a784e682f4c218ba2a69cf86a)) - _Greg Hale_
- **Parsing Stability:** Added logic to prevent assertions from parsing errors and ensured checks no longer affect parsing ([#1101](https://github.com/boundaryml/baml/commit/5ec89c92ab14622afddc3ce348c5b981b4840492)) - _hellovai_
- **Version Bump:** Bumped version to 0.64.0 ([#1114](https://github.com/boundaryml/baml/commit/90d3c17ba67bc1467ee5973ff6cf257069e265b9), [#ff7e152](https://github.com/boundaryml/baml/commit/ff7e152510395bab1d38afa60211226070d12cc2)) - _Vaibhav Gupta_

## [0.63.0](https://github.com/boundaryml/baml/compare/0.62.0..0.63.0) - 2024-10-23

### Bug Fixes

- Fix dynamic enums which already are defined in BAML (#1080) - ([22d0f1c](https://github.com/boundaryml/baml/commit/22d0f1cff3428c2cd58ea78c50c4fc7ea39c8d0c)) - hellovai

### Features

- Updated clients.baml to use the latest sonnet model (#1081) - ([71df0b7](https://github.com/boundaryml/baml/commit/71df0b7b627ba218d581d2c21be01fea4e4993c1)) - aaronvg
- Improved clients.baml generated via baml init (#1089) - ([682dd66](https://github.com/boundaryml/baml/commit/682dd66f4adab8c4fad13bfe32a3fc0268d8b511)) - hellovai

## [0.62.0](https://github.com/boundaryml/baml/compare/0.61.1..0.62.0) - 2024-10-21

### Features

- Support serializing/deserializing `baml_py.Image`, `baml_py.Audio` for pydantic (#1062) - ([11cb699](https://github.com/boundaryml/baml/commit/11cb69903dce1ae348c68f88a82b4731da3977a7)) - Samuel Lijin
- Support rendering input classes with aliases (#1045) - ([3824cda](https://github.com/boundaryml/baml/commit/3824cda75524105f3401e5c7e4c21e604d639f76)) - aaronvg
- Add unstable_internal_repr on FunctionResult in python (#1068) - ([00082e8](https://github.com/boundaryml/baml/commit/00082e8b941d3648ec499215d2c38091f36db944)) - hellovai
- Add literal support for type_builder (#1069) - ([c0085d9](https://github.com/boundaryml/baml/commit/c0085d908cbf8696623fd70f49de5ca8325de06c)) - hellovai

### Bug Fixes

- Surface errors in fallbacks containing only erroneous clients (#1061) - ([b69ef79](https://github.com/boundaryml/baml/commit/b69ef79542ec818b8779f9710dad65d33166c862)) - Greg Hale
- Fix parser so that we are able to correctly detect sequences of empty strings. (#1048) - ([977e277](https://github.com/boundaryml/baml/commit/977e2776119a6f1e79f29cbe596b1c31697becb5)) - hellovai
- Make substring match algorithm case insensitive (#1056) - ([fa2c477](https://github.com/boundaryml/baml/commit/fa2c4770791297a7a37a3f0c837ede4bb709f0ef)) - Antonio Sarosi
- Fix vertex-ai citation data being optional (#1058) - ([5eae0a7](https://github.com/boundaryml/baml/commit/5eae0a73be6cc8286ce045185537aeed0b9feb7d)) - aaronvg
- Fix bug to correctly cast to pydantic types in ambiguous scenarios where BAML knows better (#1059) - ([830b0cb](https://github.com/boundaryml/baml/commit/830b0cb194b99fa6f019928e7466dcf3e3992596)) - hellovai
- Parser: Prefer case sensitive match over case insensitive (#1063) - ([cd6b141](https://github.com/boundaryml/baml/commit/cd6b141020ec8dfd2514c82ffffaebc5678a025b)) - Antonio Sarosi
- Only popup the vscode env var dialog once (#1066) - ([1951474](https://github.com/boundaryml/baml/commit/19514745cfc8efeb8bda0be655e0fa2f216e4b29)) - aaronvg

### Documentation

- Docs for literal types (#1030) - ([55e5964](https://github.com/boundaryml/baml/commit/55e596419055c8da52b841b9ecbf16e328bc1033)) - Antonio Sarosi
- Contribution guide (#1055) - ([f09d943](https://github.com/boundaryml/baml/commit/f09d9432d95c876f5e63f3abdb47a40417c5c45a)) - aaronvg

### Misc

- Fix VSCode metrics (#1044) - ([a131336](https://github.com/boundaryml/baml/commit/a13133656e1610cac9a92aa4b4459c78340c7304)) - hellovai
- Add more test cases for unquoted strings in objects (#1054) - ([2d1b700](https://github.com/boundaryml/baml/commit/2d1b700e82604e444d904cfeb67f46ced97153a5)) - hellovai

## [0.61.1](https://github.com/boundaryml/baml/compare/0.61.0..0.61.1) - 2024-10-15

### Bug Fixes

- add musl to the ts release artifacts (#1042) - ([e74f3e9](https://github.com/boundaryml/baml/commit/e74f3e90489a403e38b39cc694d30d038ad38b8d)) - Samuel Lijin

## [0.61.0](https://github.com/boundaryml/baml/compare/0.60.0..0.61.0) - 2024-10-14

### Features

- Implement literal types (#978) - ([9e7431f](https://github.com/boundaryml/baml/commit/9e7431f43b74d4428e6a20b9aa3a1e93768ff905)) - Antonio Sarosi
- allow installing the TS library on node-alpine (#1029) - ([1c37a0d](https://github.com/boundaryml/baml/commit/1c37a0d71d921d13f05340ff6727255ba6074152)) - Samuel Lijin
- Add WYSIWYG UI (Swagger UI) to baml-cli dev (#1019) - ([0c73cab](https://github.com/boundaryml/baml/commit/0c73cab3d6ac3bbb04cc898ac102900ca9b17f86)) - Greg Hale
- Suppress streaming for Numbers (#1032) - ([3f4621b](https://github.com/boundaryml/baml/commit/3f4621b36555062312aabd9ba8435b965ba8fd92)) - Greg Hale

### Bug Fixes

- Add limit on connection pool to prevent stalling issues in pyo3 and other ffi boundaries (#1027) - ([eb90e62](https://github.com/boundaryml/baml/commit/eb90e62ffe21109e0da1bd74439d36bb37246ec3)) - hellovai
- Update docs (#1025) - ([2dd1bb6](https://github.com/boundaryml/baml/commit/2dd1bb6cf743c20af53d7147db8a4573de9cdbe0)) - Farookh Zaheer Siddiqui
- Fix parsing for streaming of objects more stable (#1031) - ([8aa9c00](https://github.com/boundaryml/baml/commit/8aa9c00b8f26a8c30178ff25aecc1c3b47b6696e)) - hellovai
- Fix python BamlValidationError type (#1036) - ([59a9510](https://github.com/boundaryml/baml/commit/59a9510c9d2c1216df01b0701cc23afb02e3f700)) - aaronvg

### Miscellaneous

- Popup settings dialog when no env vars set (#1033) - ([b9fa52a](https://github.com/boundaryml/baml/commit/b9fa52aea8686f8095878e7f210c2d937b533c63)) - aaronvg
- Bump version to 0.61.0 - ([ca2242b](https://github.com/boundaryml/baml/commit/ca2242b26214699268fda9e9ac07338c6491026d)) - Aaron Villalpando

## [0.60.0](https://github.com/boundaryml/baml/compare/0.59.0..0.60.0) - 2024-10-09

### Miscellaneous Chores

- update Dockerfile (#1017) - ([51539b7](https://github.com/boundaryml/baml/commit/51539b7b5778d6a3e6619698d2033d4f66f15d27)) - Ikko Eltociear Ashimine
- Revert "feat: add a WYSIWYG UI (Swagger UI) to `baml-cli dev` (#1011)" (#1018) - ([f235050](https://github.com/boundaryml/baml/commit/f235050a57916116aff8359236b819ac69011a21)) - Greg Hale

### Bug fixes

- Fix python types for BamlValidationError (#1020) - ([520a09c](https://github.com/boundaryml/baml/commit/520a09c478ea8c5eb811447ce9b36689692aa01d)) - aaronvg
- coerce floats and ints with commas and other special cases (#1023) - ([904492e](https://github.com/boundaryml/baml/commit/904492ee298727085e00a391beb628c8d999083e)) - aaronvg

### Docs

- Add Docs for Jupyter notebook usage (#1008) - ([c51d918](https://github.com/boundaryml/baml/commit/c51d918f76f63ce55b353661459ba3b27b9a0ea7)) - aaronvg

## [0.59.0](https://github.com/boundaryml/baml/compare/0.58.0..0.59.0) - 2024-10-04

### Features

- **(vertex)** allow specifying creds as JSON object (#1009) - ([98868da](https://github.com/boundaryml/baml/commit/98868da4e75dde3a00178cbf60afebc501d37b0c)) - Samuel Lijin
- Add prompt, raw_output and error message to BamlValidationError in TS and Python (#1005) - ([447dbf4](https://github.com/boundaryml/baml/commit/447dbf4e0d0cf0744307ef50f89050752334d982)) - aaronvg
- Add BamlValidationError to `baml-cli serve` (#1007) - ([3b8cf16](https://github.com/boundaryml/baml/commit/3b8cf1636594c1a7245a733556efa690da40e139)) - aaronvg
- Include a WYSIWYG UI (Swagger UI) to `baml-cli dev` (#1011) - ([fe9dde4](https://github.com/BoundaryML/baml/commit/fe9dde4f3a7ff0503fd13087da50e4da9d97c3a0)) - imalsogreg

## [0.58.0](https://github.com/boundaryml/baml/compare/0.57.1..0.58.0) - 2024-10-02

### Features

- Add client registry support for BAML over Rest (OpenAPI) (#1000) - ([abe70bf](https://github.com/boundaryml/baml/commit/abe70bf368c9361a3ab32643735f68e0fafd8425)) - Lorenz Ohly

### Bug Fixes

- Improve performance of parsing escaped characters in strings during streaming. (#1002) - ([b35ae2c](https://github.com/boundaryml/baml/commit/b35ae2c4777572206a79af5c2943f5bdd6ada081)) - hellovai

### Documentation

- Add Docs for Document Extraction API (#996) - ([da1a5e8](https://github.com/boundaryml/baml/commit/da1a5e876368074235f4474673a1ebfe632e11ed)) - aaronvg

## [0.57.1](https://github.com/boundaryml/baml/compare/0.57.0..0.57.1) - 2024-09-29

### Bug Fixes

- [BUGFIX] Parser should require a space between class keyword and class name (#990) - ([7528247](https://github.com/boundaryml/baml/commit/752824723404a4ed4c4b1e31c43d140e9346dca2)) - Greg Hale
- Remove dynamic string attributes (#991) - ([0960ab2](https://github.com/boundaryml/baml/commit/0960ab2e0d16c50fef58772336b91297ddac6919)) - Greg Hale
- ts fixes (#992) - ([36af43f](https://github.com/boundaryml/baml/commit/36af43f4f773e1565527916eff7d7837d9f8a983)) - aaronvg
- Bump version to 0.57.1 - ([0aa71dd](https://github.com/boundaryml/baml/commit/0aa71dd4d3aa7082db6a19f0a3a976ff55789d83)) - Aaron Villalpando

## [0.57.0](https://github.com/boundaryml/baml/compare/0.56.1..0.57.0) - 2024-09-27

### Documentation

- Fix Python dynamic types example (#979) - ([eade116](https://github.com/boundaryml/baml/commit/eade116de14bcc15d738fec911d8653685c13706)) - lorenzoh

### Features

- teach vscode/fiddle to explain when we drop information (#897) - ([93e2b9b](https://github.com/boundaryml/baml/commit/93e2b9b8d54a4ced0853ce72596d0b0a9896a0da)) - Samuel Lijin
- Add ability for users to reset env vars to their desire. (#984) - ([69e6c29](https://github.com/boundaryml/baml/commit/69e6c29c82ccc06f8939b9ece75dd7797c8f6b98)) - hellovai

### Bug Fixes

- Fixed panic during logging for splitting on UTF-8 strings. (#987) - ([c27a64f](https://github.com/boundaryml/baml/commit/c27a64f6320515cd5ab6385ab93013d3d7ba88b8)) - hellovai
- Improve SAP for triple quoted strings along with unions (#977) - ([44202ab](https://github.com/boundaryml/baml/commit/44202ab63aa3d2881485b9b32fa744797c908e33)) - hellovai
- Add more unit tests for parsing logic inspired by user (#980) - ([48dd09f](https://github.com/boundaryml/baml/commit/48dd09f89b6447cbc1a539ecade66ab4da87b8dc)) - hellovai
- Improve syntax errors e.g. class / enum parsing and also update pestmodel to handle traling comments (#981) - ([adbb6ae](https://github.com/boundaryml/baml/commit/adbb6ae38833d700bfe0123ac712cd90d7e4d970)) - hellovai
- Updating docs for env vars (#985) - ([305d6b3](https://github.com/boundaryml/baml/commit/305d6b3e5a57513adc43c8ab9068c523dfc2e69c)) - hellovai
- When using openai-generic, use a string as the content type in the api request if theres no media (#988) - ([e8fa739](https://github.com/boundaryml/baml/commit/e8fa739838cc124a8eed49103871b1b971063821)) - aaronvg

## [0.56.1](https://github.com/boundaryml/baml/compare/0.56.0..0.56.1) - 2024-09-21

### Bug Fixes

- Improved parser for unions (#975) - ([b390521](https://github.com/boundaryml/baml/commit/b39052111529f217762b3271846006bec4a604de)) - hellovai
- [syntax] Allow lists to contain trailing comma (#974) - ([9e3dc6c](https://github.com/boundaryml/baml/commit/9e3dc6c90954905a96b599ef28c40094fe48a43e)) - Greg Hale

## [0.56.0](https://github.com/boundaryml/baml/compare/0.55.3..0.56.0) - 2024-09-20

Shout outs to Nico for fixing some internal Rust dependencies, and to Lorenz for correcting our documentation! We really appreciate it :)

### Features

- use better default for openapi/rust client (#958) - ([b74ef15](https://github.com/boundaryml/baml/commit/b74ef15fd4dc09ecc7d1ac8284e7f22cd6d5864c)) - Samuel Lijin

### Bug Fixes

- push optional-list and optional-map validation to post-parse (#959) - ([c0480d5](https://github.com/boundaryml/baml/commit/c0480d5cfd46ce979e957223dc7b5fa744778552)) - Samuel Lijin
- improve OpenAPI instructions for windows/java (#962) - ([6010efb](https://github.com/boundaryml/baml/commit/6010efbb7990fda966640c3af267de41362d3fa4)) - Samuel Lijin
- assorted fixes: unquoted strings, openai-generic add api_key for bearer auth, support escape characters in quoted strings (#965) - ([847f3a9](https://github.com/boundaryml/baml/commit/847f3a9bb0f00303eae7e410663efc63e54c38b6)) - hellovai
- serde-serialize can cause a package dependency cycle (#967) - ([109ae09](https://github.com/boundaryml/baml/commit/109ae0914852f2ee4a771d27103e4e46ad672647)) - Nico
- make anthropic work in fiddle/vscode (#970) - ([32eccae](https://github.com/boundaryml/baml/commit/32eccae44b27c3fec5fbc3270b6657819d75a426)) - Samuel Lijin
- make dynamic enums work as outputs in Ruby (#972) - ([7530402](https://github.com/boundaryml/baml/commit/7530402f0dc063f10f57cf7aa7f06790574de705)) - Samuel Lijin

### Documentation

- suggest correct python init command in vscode readme (#954) - ([e99c5dd](https://github.com/boundaryml/baml/commit/e99c5dd1903078d08aef451e4addc6110d7ca279)) - Samuel Lijin
- add more vscode debugging instructions (#955) - ([342b657](https://github.com/boundaryml/baml/commit/342b657da69441306fa7711d7d14893cf8036f84)) - Samuel Lijin
- NextJS hook needs to be bound to the correct context (#957) - ([ee80451](https://github.com/boundaryml/baml/commit/ee80451de85063b37e658ba58571c791e8514273)) - aaronvg
- update nextjs hooks and docs (#952) - ([01cf855](https://github.com/boundaryml/baml/commit/01cf855500159066fdcd162dc2e2087768d5ba28)) - aaronvg
- Fix some documentation typos (#966) - ([5193cd7](https://github.com/boundaryml/baml/commit/5193cd70686173c863af5ce40fd6bb3792406951)) - Greg Hale
- Keywords AI router (#953) - ([1c6f975](https://github.com/boundaryml/baml/commit/1c6f975d8cc793841745da0db82ee1e2f1908e56)) - aaronvg
- Fix `post_generate` comment (#968) - ([919c79f](https://github.com/boundaryml/baml/commit/919c79fa8cd85a96e6559055b2bb436d925dcb2a)) - lorenzoh

### Bug Fixes

- show actionable errors for string[]? and map&gt;...>? type validation (#946) - ([48879c0](https://github.com/boundaryml/baml/commit/48879c0744f79b482ef0d2b0624464053558ada4)) - Samuel Lijin

### Documentation

- add reference docs about env vars (#945) - ([dd43bc5](https://github.com/boundaryml/baml/commit/dd43bc59087e809e09ca7d3caf628e179a28fc3e)) - Samuel Lijin

## [0.55.2](https://github.com/boundaryml/baml/compare/0.55.1..0.55.2) - 2024-09-11

### Bug Fixes

- use correct locking strategy inside baml-cli serve (#943) - ([fcb694d](https://github.com/boundaryml/baml/commit/fcb694d033317d8538cc7b2c61aaa94f772778db)) - Samuel Lijin

### Features

- allow using DANGER_ACCEPT_INVALID_CERTS to disable https verification (#901) - ([8873fe7](https://github.com/boundaryml/baml/commit/8873fe7577bc879cf0d550063252c4532dcdfced)) - Samuel Lijin

## [0.55.1](https://github.com/boundaryml/baml/compare/0.55.0..0.55.1) - 2024-09-10

### Bug Fixes

- in generated TS code, put eslint-disable before ts-nocheck - ([16d04c6](https://github.com/BoundaryML/baml/commit/16d04c6e360eefca10b4e0d008b03c34de279491)) - Sam Lijin
- baml-cli in python works again - ([b57ca0f](https://github.com/boundaryml/baml/commit/b57ca0f529c80f59b79b19132a8f1339a6b7bfe2)) - Sam Lijin

### Documentation

- update java install instructions (#933) - ([b497003](https://github.com/boundaryml/baml/commit/b49700356f2f69c4acbdc953a66a95224656ffaf)) - Samuel Lijin

### Miscellaneous Chores

- add version headers to the openapi docs (#931) - ([21545f2](https://github.com/boundaryml/baml/commit/21545f2a4d9b3987134d98ac720705dde2045290)) - Samuel Lijin

## [0.55.0](https://github.com/boundaryml/baml/compare/0.54.2..0.55.0) - 2024-09-09

With this release, we're announcing support for BAML in all languages: we now
allow you to call your functions over an HTTP interface, and will generate an
OpenAPI specification for your BAML functions, so you can now generate a client
in any language of your choice, be it Golang, Java, PHP, Ruby, Rust, or any of
the other languages which OpenAPI supports.

Start here to learn more: https://docs.boundaryml.com/docs/get-started/quickstart/openapi

### Features

- implement BAML-over-HTTP (#908) - ([484fa93](https://github.com/boundaryml/baml/commit/484fa93a5a4b4677f531e6ef03bb88d144925c12)) - Samuel Lijin
- Add anonymous telemetry about playground actions (#925) - ([6f58c9e](https://github.com/boundaryml/baml/commit/6f58c9e3e464a8e774771706c2b0d76adb9e6cda)) - hellovai

## [0.54.2](https://github.com/boundaryml/baml/compare/0.54.1..0.54.2) - 2024-09-05

### Features

- Add a setting to disable restarting TS server in VSCode (#920) - ([628f236](https://github.com/boundaryml/baml/commit/628f2360c415fa8a7b0cd90d7249733ff06acaa9)) - aaronvg
- Add prompt prefix for map types in ctx.output_format and add more type validation for map params (#919) - ([4d304c5](https://github.com/boundaryml/baml/commit/4d304c583b9188c1963a34e2a153baaf003e36ac)) - hellovai

### Bug fixes

- Fix glibC issues for python linux-x86_64 (#922) - ([9161bec](https://github.com/boundaryml/baml/commit/9161becccf626f8d13a15626481720f29e0f992c)) - Samuel Lijin

### Documentation

- Add nextjs hooks (#921) - ([fe14f5a](https://github.com/boundaryml/baml/commit/fe14f5a4ef95c9ccda916ff80ce852d3855554a3)) - aaronvg

## [0.54.1](https://github.com/boundaryml/baml/compare/0.54.0..0.54.1) - 2024-09-03

### BREAKING CHANGE

- Fix escape characters in quoted strings (#905) - ([9ba6eb8](https://github.com/boundaryml/baml/commit/9ba6eb834e0145f4c57e582b63730d3d0ac9b2e9)) - hellovai

Prior `"\n"` was interpreted as `"\\n"` in quoted strings. This has been fixed to interpret `"\n"` as newline characters and true for other escape characters.

### Documentation

- updated dead vs-code-extension link (#914) - ([b12f164](https://github.com/boundaryml/baml/commit/b12f1649cf5bfd0d457c5d6d117fd3a21ba5dc6b)) - Christian Warmuth
- Update docs for setting env vars (#904) - ([ec1ca94](https://github.com/boundaryml/baml/commit/ec1ca94c91af2a51b4190a0bad0e0bc1c052f2a3)) - hellovai
- Add docs for LMStudio (#906) - ([ea4c187](https://github.com/boundaryml/baml/commit/ea4c18782de1f713e8d69d473f9e1818c97024c6)) - hellovai
- Fix docs for anthropic (#910) - ([aba2764](https://github.com/boundaryml/baml/commit/aba2764e5b04820d00b08bf52bda603ee27631f1)) - hellovai
- Update discord links on docs (#911) - ([927357d](https://github.com/boundaryml/baml/commit/927357dd64b36c25513352ed4968ebc62dad6132)) - hellovai

### Features

- BAML_LOG will truncate messages to 1000 characters (modify using env var BOUNDARY_MAX_LOG_CHUNK_SIZE) (#907) - ([d266e5c](https://github.com/boundaryml/baml/commit/d266e5c4157f3b28d2f6454a7ea265dda7296bb2)) - hellovai

### Bug Fixes

- Improve parsing parsing when there are initial closing `]` or `}` (#903) - ([46b0cde](https://github.com/boundaryml/baml/commit/46b0cdeffb15bbab20a43728f52ad2a05623e6f7)) - hellovai
- Update build script for ruby to build all platforms (#915) - ([df2f51e](https://github.com/boundaryml/baml/commit/df2f51e52615451b3643cc124e7262f11965f3ef)) - hellovai
- Add unit-test for openai-generic provider and ensure it compiles (#916) - ([fde7c50](https://github.com/boundaryml/baml/commit/fde7c50c939c505906417596d16c7c4607173339)) - hellovai

## [0.54.0](https://github.com/boundaryml/baml/compare/0.53.1..0.54.0) - 2024-08-27

### BREAKING CHANGE

- Update Default Gemini Base URL to v1beta (#891) - ([a5d8c58](https://github.com/boundaryml/baml/commit/a5d8c588e0fd0b7e186d7c71f1f6171334250629)) - gleed

The default base URL for the Gemini provider has been updated to v1beta. This change is should have no impact on existing users as v1beta is the default version for the Gemini python library, we are mirroring this change in BAML.

### Bug Fixes

- Allow promptfiddle to talk to localhost ollama (#886) - ([5f02b2a](https://github.com/boundaryml/baml/commit/5f02b2ac688ceeb5a34e848a8ff87fd43a6b093a)) - Samuel Lijin
- Update Parser for unions so they handle nested objects better (#900) - ([c5b9a75](https://github.com/boundaryml/baml/commit/c5b9a75ea6da7c45da1999032e2b256bec97d922)) - hellovai

### Documentation

- Add ollama to default prompt fiddle example (#888) - ([49146c0](https://github.com/boundaryml/baml/commit/49146c0e50c88615e4cc97adb595849c23bad8ae)) - Samuel Lijin
- Adding improved docs + unit tests for caching (#895) - ([ff7be44](https://github.com/boundaryml/baml/commit/ff7be4478b706da049085d432b2ec98627b5da1f)) - hellovai

### Features

- Allow local filepaths to be used in tests in BAML files (image and audio) (#871) - ([fa6dc03](https://github.com/boundaryml/baml/commit/fa6dc03fcdd3255dd83e25d0bfb3b0e740991408)) - Samuel Lijin
- Add support for absolute file paths in the file specifier (#881) - ([fcd189e](https://github.com/boundaryml/baml/commit/fcd189ed7eb81712bf3b641eb3dde158fc6a62af)) - hellovai
- Implement shorthand clients (You can now use "openai/gpt-4o" as short for creating a complete client.) (#879) - ([ddd15c9](https://github.com/boundaryml/baml/commit/ddd15c92c3e8d81c24cb7305c9fcbb36b819900f)) - Samuel Lijin
- Add support for arbritrary metadata (e.g. cache_policy for anthropic) (#893) - ([0d63a70](https://github.com/boundaryml/baml/commit/0d63a70332477761a97783e203c98fd0bf67f151)) - hellovai
- Expose Exceptions to user code: BamlError, BamlInvalidArgumentError, BamlClientError, BamlClientHttpError, BamlValidationError (#770) - ([7da14c4](https://github.com/boundaryml/baml/commit/7da14c480506e9791b3f4ce52ac73836a042d38a)) - hellovai

### Internal

- AST Restructuring (#857) - ([75b51cb](https://github.com/boundaryml/baml/commit/75b51cbf80a0c8ba19ae05b021ef3c94dacb4e30)) - Anish Palakurthi

## [0.53.1](https://github.com/boundaryml/baml/compare/0.53.0..0.53.1) - 2024-08-11

### Bug Fixes

- fix github release not passing params to napi script causing issues in x86_64 (#872)

- ([06b962b](https://github.com/boundaryml/baml/commit/06b962b945f958bf0637d13fec22bd2d59c64c5f)) - aaronvg

### Features

- Add Client orchestration graph in playground (#801) - ([24b5895](https://github.com/boundaryml/baml/commit/24b5895a1f45ac04cba0f19e6da727b5ee766186)) - Anish Palakurthi
- increase range of python FFI support (#870) - ([ec9b66c](https://github.com/boundaryml/baml/commit/ec9b66c31faf97a58c81c264c7fa1b32e0e9f0ae)) - Samuel Lijin

### Misc

- Bump version to 0.53.1 - ([e4301e3](https://github.com/boundaryml/baml/commit/e4301e37835483f51edf1cad6478e46ff67508fc)) - Aaron Villalpando

## [0.53.0](https://github.com/boundaryml/baml/compare/0.52.1..0.53.0) - 2024-08-05

### Bug Fixes

- make image[] render correctly in prompts (#855) - ([4a17dce](https://github.com/boundaryml/baml/commit/4a17dce43c05efd5f4ea304f2609fe140de1dd8c)) - Samuel Lijin

### Features

- **(ruby)** implement dynamic types, dynamic clients, images, and audio (#842) - ([4a21eed](https://github.com/boundaryml/baml/commit/4a21eed668f32b042fba61f24c9efb8b3794a420)) - Samuel Lijin
- Codelenses for test cases (#812) - ([7cd8794](https://github.com/boundaryml/baml/commit/7cd87942bf50a72de0ad46154f164fb2c174f25b)) - Anish Palakurthi

### Issue

- removed vertex auth token printing (#846) - ([b839316](https://github.com/boundaryml/baml/commit/b83931665a2c3b840eb6c6d31cf3d01c7926e52e)) - Anish Palakurthi
- Fix google type deserialization issue - ([a55b9a1](https://github.com/boundaryml/baml/commit/a55b9a106176ed1ce34bb63397610c2640b37f16)) - Aaron Villalpando

### Miscellaneous Chores

- clean up release stuff (#836) - ([eed41b7](https://github.com/boundaryml/baml/commit/eed41b7474417d2e65b2c5d742234cc20fc5644e)) - Samuel Lijin
- Add bfcl results to readme, fix links icons (#856) - ([5ef7f3d](https://github.com/boundaryml/baml/commit/5ef7f3db99d8d23ff97f1e8372ee71ab7aa127aa)) - aaronvg
- Fix prompt fiddle and playground styles, add more logging, and add stop-reason to playground (#858) - ([38e3153](https://github.com/boundaryml/baml/commit/38e3153843a17ae1e87ae9879ab4374b083d77d0)) - aaronvg
- Bump version to 0.53.0 - ([fd16839](https://github.com/boundaryml/baml/commit/fd16839a2c0b9d92bd5bdcb57f950e22d0a29959)) - Aaron Villalpando

## [0.52.1](https://github.com/boundaryml/baml/compare/0.52.0..0.52.1) - 2024-07-24

### Bug Fixes

- build python x86_64-linux with an older glibc (#834) - ([db12540](https://github.com/boundaryml/baml/commit/db12540a92abf055e286c60864299f53c246b62a)) - Samuel Lijin

## [0.52.0](https://github.com/boundaryml/baml/compare/0.51.3..0.52.0) - 2024-07-24

### Features

- Add official support for ruby (#823) - ([e81cc79](https://github.com/boundaryml/baml/commit/e81cc79498809a79f427864704b140967a41277a)) - Samuel Lijin

### Bug Fixes

- Fix ClientRegistry for Typescript code-gen (#828) - ([b69921f](https://github.com/boundaryml/baml/commit/b69921f45df0182072b09ab28fe6231ccfaa5767)) - hellovai

## [0.51.2](https://github.com/boundaryml/baml/compare/0.51.1..0.51.2) - 2024-07-24

### Features

- Add support for unions / maps / null in TypeBuilder. (#820) - ([8d9e92d](https://github.com/boundaryml/baml/commit/8d9e92d3050a67edbec5ee6056397becbcdb754b)) - hellovai

### Bug Fixes

- [Playground] Add a feedback button (#818) - ([f749f2b](https://github.com/boundaryml/baml/commit/f749f2b19b247de2f050beccd1fe8e50b7625757)) - Samuel Lijin

### Documentation

- Improvements across docs (#807) - ([bc0c176](https://github.com/boundaryml/baml/commit/bc0c1761699ee2485a0a8ee61cf4fda6b579f974)) - Anish Palakurthi

## [0.51.1](https://github.com/boundaryml/baml/compare/0.51.0..0.51.1) - 2024-07-21

### Features

- Add a feedback button to VSCode Extension (#811) - ([f371912](https://github.com/boundaryml/baml/commit/f3719127174d8f998579747f14fae8675dafba4c)) - Samuel Lijin

### Bug

- Allow default_client_mode in the generator #813 (#815) - ([6df7fca](https://github.com/boundaryml/baml/commit/6df7fcabc1eb55b08a50741f2346440f631abd63)) - hellovai

## [0.51.0](https://github.com/boundaryml/baml/compare/0.50.0..0.51.0) - 2024-07-19

### Bug Fixes

- Improve BAML Parser for numbers and single-key objects (#785) - ([c5af7b0](https://github.com/boundaryml/baml/commit/c5af7b0d0e881c3046171ca17f317d820e8882e3)) - hellovai
- Add docs for VLLM (#792) - ([79e8773](https://github.com/boundaryml/baml/commit/79e8773e38da524795dda606b9fae09a274118e1)) - hellovai
- LLVM install and rebuild script (#794) - ([9ee66ed](https://github.com/boundaryml/baml/commit/9ee66ed2dd14bc0ee12a788f41eae64377e7f2b0)) - Anish Palakurthi
- Prevent version mismatches when generating baml_client (#791) - ([d793603](https://github.com/boundaryml/baml/commit/d7936036e6afa4a0e738242cfb3feaa9e15b3657)) - aaronvg
- fiddle build fix (#800) - ([d304203](https://github.com/boundaryml/baml/commit/d304203241726ac0ba8781db7ac5693339189eb4)) - aaronvg
- Dont drop extra fields in dynamic classes when passing them as inputs to a function (#802) - ([4264c9b](https://github.com/boundaryml/baml/commit/4264c9b143edda0239af197d110357b1969bf12c)) - aaronvg
- Adding support for a sync client for Python + Typescript (#803) - ([62085e7](https://github.com/boundaryml/baml/commit/62085e79d4d86f580ce189bc60f36bd1414893c4)) - hellovai
- Fix WASM-related issues introduced in #803 (#804) - ([0a950e0](https://github.com/boundaryml/baml/commit/0a950e084748837ee2e269504d22dba66f339ca4)) - hellovai
- Adding various fixes (#806) - ([e8c1a61](https://github.com/boundaryml/baml/commit/e8c1a61a96051160566b6458dac5c89d5ddfb86e)) - hellovai

### Features

- implement maps in BAML (#797) - ([97d7e62](https://github.com/boundaryml/baml/commit/97d7e6223c68e9c338fe7110554f1f26b966f7e3)) - Samuel Lijin
- Support Vertex AI (Google Cloud SDK) (#790) - ([d98ee81](https://github.com/boundaryml/baml/commit/d98ee81a9440de0aaa6de05b33b8d3f709003a00)) - Anish Palakurthi
- Add copy buttons to test results in playground (#799) - ([b5eee3d](https://github.com/boundaryml/baml/commit/b5eee3d15a1be4373e25cc8ef1cf6e70d5dd39c9)) - aaronvg

### Miscellaneous Chores

- in fern config, defer to installed version (#789) - ([479f1b2](https://github.com/boundaryml/baml/commit/479f1b2b0b52faf47bc529e4c06c533a9467269a)) - fern
- publish docs on every push to the default branch (#796) - ([180824a](https://github.com/boundaryml/baml/commit/180824a3857a32eae679e4df5704abba3aa6246c)) - Samuel Lijin
- 🌿 introducing fern docs (#779) - ([46f06a9](https://github.com/boundaryml/baml/commit/46f06a95a1e262e62476768b812b372b696da1be)) - fern
- Add test for dynamic list input (#798) - ([7528d6a](https://github.com/boundaryml/baml/commit/7528d6ae10427c1304e356cf5b3c664e4fb2b1b1)) - aaronvg

## [0.50.0](https://github.com/boundaryml/baml/compare/0.49.0..0.50.0) - 2024-07-11

### Bug Fixes

- [Playground] Environment variable button is now visible on all themes (#762) - ([adc4da1](https://github.com/boundaryml/baml/commit/adc4da1fa36cc9c30ea36e25de1a6cefcce0bc97)) - aaronvg
- [Playground] Fix to cURL rendering and mime_type overriding (#763) - ([67f9c6a](https://github.com/boundaryml/baml/commit/67f9c6add5ea8bbbd5ee82c28476fe0ebbefe344)) - Anish Palakurthi

### Features

- [Runtime] Add support for clients that change at runtime using ClientRegistry (#683) - ([c0fb454](https://github.com/boundaryml/baml/commit/c0fb4540d9193194fcafd7fcef71468442d9e6fa)) - hellovai
  https://docs.boundaryml.com/docs/calling-baml/client-registry

### Documentation

- Add more documentation for TypeBuilder (#767) - ([85dc8ab](https://github.com/boundaryml/baml/commit/85dc8ab41e0df3267249a1efc4a95f010e52cc73)) - Samuel Lijin

## [0.49.0](https://github.com/boundaryml/baml/compare/0.46.0..0.49.0) - 2024-07-08

### Bug Fixes

- Fixed Azure / Ollama clients. Removing stream_options from azure and ollama clients (#760) - ([30bf88f](https://github.com/boundaryml/baml/commit/30bf88f65c8583ab02db6a7b7db40c1e9f3b05b6)) - hellovai

### Features

- Add support for arm64-linux (#751) - ([adb8ee3](https://github.com/boundaryml/baml/commit/adb8ee3097fd386370f75b3ba179d18b952e9678)) - Samuel Lijin

## [0.48.0](https://github.com/boundaryml/baml/compare/0.47.0..0.48.0) - 2024-07-04

### Bug Fixes

- Fix env variables dialoge on VSCode (#750)
- Playground selects correct function after loading (#757) - ([09963a0](https://github.com/boundaryml/baml/commit/09963a02e581da9eb8f7bafd3ba812058c97f672)) - aaronvg

### Miscellaneous Chores

- Better error messages on logging failures to Boundary Studio (#754) - ([49c768f](https://github.com/boundaryml/baml/commit/49c768fbe8eb8023cba28b8dc68c2553d8b2318a)) - aaronvg

## [0.47.0](https://github.com/boundaryml/baml/compare/0.46.0..0.47.0) - 2024-07-03

### Bug Fixes

- make settings dialog work in vscode again (#750) ([c94e355](https://github.com/boundaryml/baml/commit/c94e35551872f65404136b60f800fb1688902c11)) - aaronvg
- restore releases on arm64-linux (#751) - ([adb8ee3](https://github.com/boundaryml/baml/commit/adb8ee3097fd386370f75b3ba179d18b952e9678)) - Samuel Lijin

## [0.46.0](https://github.com/boundaryml/baml/compare/0.45.0..0.46.0) - 2024-07-03

### Bug Fixes

- Fixed tracing issues for Boundary Studio (#740) - ([77a4db7](https://github.com/boundaryml/baml/commit/77a4db7ef4b939636472ad4975d74e9d1a577cbf)) - Samuel Lijin
- Fixed flush() to be more reliable (#744) - ([9dd5fda](https://github.com/boundaryml/baml/commit/9dd5fdad5c2897b49a5a536df2e9ef775857a39d)) - Samuel Lijin
- Remove error when user passes in extra fields in a class (#746) - ([2755b43](https://github.com/boundaryml/baml/commit/2755b43257f9405ae66a30982d9711fc3f2c0854)) - aaronvg

### Features

- Add support for base_url for the google-ai provider (#747) - ([005b1d9](https://github.com/boundaryml/baml/commit/005b1d93b7f7d2aa12a1487911766cccd9c25e98)) - hellovai
- Playground UX improvements (#742) - ([5cb56fd](https://github.com/boundaryml/baml/commit/5cb56fdc39496f0aedacd79766c0e93cb0e401b8)) - hellovai
- Prompt Fiddle now auto-switches functions when to change files (#745)

### Documentation

- Added a large example project on promptfiddle.com (#741) - ([f80da1e](https://github.com/boundaryml/baml/commit/f80da1e1dd11f0457b5789bc9ce6923a8ed88b51)) - aaronvg
- Mark ruby as in beta (#743) - ([901109d](https://github.com/boundaryml/baml/commit/901109dbb327e6e3e1b65fda37100fcd45f97e07)) - Samuel Lijin

## [0.45.0](https://github.com/boundaryml/baml/compare/0.44.0..0.45.0) - 2024-06-29

### Bug Fixes

- Fixed streaming in Python Client which didn't show result until later (#726) - ([e4f2daa](https://github.com/boundaryml/baml/commit/e4f2daa9e85bb1711d112fb0c87c0d769be0bb2d)) - Anish Palakurthi
- Improve playground stability on first load (#732) - ([2ac7b32](https://github.com/boundaryml/baml/commit/2ac7b328e89400cba0d9eb4f6d09c6a03feb71a5)) - Anish Palakurthi
- Add improved static analysis for jinja (#734) - ([423faa1](https://github.com/boundaryml/baml/commit/423faa1af5a594b7f78f7bb5620e3146a8989da5)) - hellovai

### Documentation

- Docs for Dynamic Types (#722) [https://docs.boundaryml.com/docs/calling-baml/dynamic-types](https://docs.boundaryml.com/docs/calling-baml/dynamic-types)

### Features

- Show raw cURL request in Playground (#723) - ([57928e1](https://github.com/boundaryml/baml/commit/57928e178549cb3e5118ce374aab5d0fbad7038b)) - Anish Palakurthi
- Support bedrock as a provider (#725) - ([c64c665](https://github.com/boundaryml/baml/commit/c64c66522a1d496493a30f593103209acd201364)) - Samuel Lijin

## [0.44.0](https://github.com/boundaryml/baml/compare/0.43.0..0.44.0) - 2024-06-26

### Bug Fixes

- Fix typebuilder for random enums (#721)

## [0.43.0](https://github.com/boundaryml/baml/compare/0.42.0..0.43.0) - 2024-06-26

### Bug Fixes

- fix pnpm lockfile issue (#720)

## [0.42.0](https://github.com/boundaryml/baml/compare/0.41.0..0.42.0) - 2024-06-26

### Bug Fixes

- correctly propagate LICENSE to baml-py (#695) - ([3fda880](https://github.com/boundaryml/baml/commit/3fda880bf39b32191b425ae75e8b491d10884cf6)) - Samuel Lijin

### Miscellaneous Chores

- update jsonish readme (#685) - ([b19f04a](https://github.com/boundaryml/baml/commit/b19f04a059ba18d54544cb278b6990b95170d3f3)) - Samuel Lijin

### Vscode

- add link to tracing, show token counts (#703) - ([64aa18a](https://github.com/boundaryml/baml/commit/64aa18a9cc34071655141c8f6e2ad04ac90e7be1)) - Samuel Lijin

## [0.41.0] - 2024-06-20

### Bug Fixes

- rollback git lfs, images broken in docs rn (#534) - ([6945506](https://github.com/boundaryml/baml/commit/694550664fa45b5f76987e2663c9d7e7a9a6a2d2)) - Samuel Lijin
- search for markdown blocks correctly (#641) - ([6b8abf1](https://github.com/boundaryml/baml/commit/6b8abf1ccf55bbe7c3bc1046c78081126e01f134)) - Samuel Lijin
- restore one-workspace-per-folder (#656) - ([a464bde](https://github.com/boundaryml/baml/commit/a464bde566199ace45285a78a7f542cd7217fb65)) - Samuel Lijin
- ruby generator should be ruby/sorbet (#661) - ([0019f39](https://github.com/boundaryml/baml/commit/0019f3951b8fe2b49e62eb11d869516b8088e9cb)) - Samuel Lijin
- ruby compile error snuck in (#663) - ([0cb2583](https://github.com/boundaryml/baml/commit/0cb25831788eb8b3eb0a38383917f6d1ffb5633a)) - Samuel Lijin

### Documentation

- add typescript examples (#477) - ([532481c](https://github.com/boundaryml/baml/commit/532481c3df4063b37a8834a5fe2bbce3bb37d2f5)) - Samuel Lijin
- add titles to code blocks for all CodeGroup elems (#483) - ([76c6b68](https://github.com/boundaryml/baml/commit/76c6b68b27ee37972fa226be0b4dfe31f7b4b5ec)) - Samuel Lijin
- add docs for round-robin clients (#500) - ([221f902](https://github.com/boundaryml/baml/commit/221f9020d850e6d24fe2fd8a684081726a0659af)) - Samuel Lijin
- add ruby example (#689) - ([16e187f](https://github.com/boundaryml/baml/commit/16e187f6698a1cc86a37eedf2447648d810370ad)) - Samuel Lijin

### Features

- implement `baml version --check --output json` (#444) - ([5f076ac](https://github.com/boundaryml/baml/commit/5f076ace1f92dc2141b231c9e62f4dc23f7fef18)) - Samuel Lijin
- show update prompts in vscode (#451) - ([b66da3e](https://github.com/boundaryml/baml/commit/b66da3ee355fcd6a8677d834ecb05af44cbf8f20)) - Samuel Lijin
- add tests to check that baml version --check works (#454) - ([be1499d](https://github.com/boundaryml/baml/commit/be1499dfa82ff8ab923a16d45290758120d95015)) - Samuel Lijin
- parse typescript versions in version --check (#473) - ([b4b2250](https://github.com/boundaryml/baml/commit/b4b2250c37b900db899256159bbfc3aa2ec819cb)) - Samuel Lijin
- implement round robin client strategies (#494) - ([599fcdd](https://github.com/boundaryml/baml/commit/599fcdd2a45c5b1e935f36769784ca944566b88c)) - Samuel Lijin
- add integ-tests support to build (#542) - ([f59cf2e](https://github.com/boundaryml/baml/commit/f59cf2e1a9ec7edbe174f4bc7ff9391f2cff3208)) - Samuel Lijin
- make ruby work again (#650) - ([6472bec](https://github.com/boundaryml/baml/commit/6472bec231b581076ee7edefaab2e7979b2bf336)) - Samuel Lijin
- Add RB2B tracking script (#682) - ([54547a3](https://github.com/boundaryml/baml/commit/54547a34d40cd40a43767919dbc9faa68a82faea)) - hellovai

### Miscellaneous Chores

- add nodemon config to typescript/ (#435) - ([231b396](https://github.com/boundaryml/baml/commit/231b3967bc947c4651156bc55fd66552782824c9)) - Samuel Lijin
- finish gloo to BoundaryML renames (#452) - ([88a7fda](https://github.com/boundaryml/baml/commit/88a7fdacc826e78ef21c6b24745ee469d9d02e6a)) - Samuel Lijin
- set up lfs (#511) - ([3a43143](https://github.com/boundaryml/baml/commit/3a431431e8e38dfc68763f15ccdcd1d131f23984)) - Samuel Lijin
- add internal build tooling for sam (#512) - ([9ebacca](https://github.com/boundaryml/baml/commit/9ebaccaa542760cb96382ae2a91d780f1ade613b)) - Samuel Lijin
- delete clients dir, this is now dead code (#652) - ([ec2627f](https://github.com/boundaryml/baml/commit/ec2627f59c7fe9edfff46fcdb65f9b9f0e2e072c)) - Samuel Lijin
- consolidate vscode workspace, bump a bunch of deps (#654) - ([82bf6ab](https://github.com/boundaryml/baml/commit/82bf6ab1ad839f84782a7ef0441f21124c368757)) - Samuel Lijin
- Add RB2B tracking script to propmt fiddle (#681) - ([4cf806b](https://github.com/boundaryml/baml/commit/4cf806bba26563fd8b6ddbd68296ab8bdfac21c4)) - hellovai
- Adding better release script (#688) - ([5bec282](https://github.com/boundaryml/baml/commit/5bec282d39d2250b39ef4aba5d6bba9830a35988)) - hellovai

### [AUTO

- patch] Version bump for nightly release [NIGHTLY:cli] [NIGHTLY:vscode_ext] [NIGHTLY:client-python] - ([d05a22c](https://github.com/boundaryml/baml/commit/d05a22ca4135887738adbce638193d71abca42ec)) - GitHub Action

### Build

- fix baml-core-ffi script (#521) - ([b1b7f4a](https://github.com/boundaryml/baml/commit/b1b7f4af0991ef6453f888f27930f3faaae337f5)) - Samuel Lijin
- fix engine/ (#522) - ([154f646](https://github.com/boundaryml/baml/commit/154f6468ec0aa6de1b033ee1cbc76e60acc363ea)) - Samuel Lijin

### Integ-tests

- add ruby test - ([c0bc101](https://github.com/boundaryml/baml/commit/c0bc10126ea32d099f1398f2c5faa08b111554ba)) - Sam Lijin

### Readme

- add function calling, collapse the table (#505) - ([2f9024c](https://github.com/boundaryml/baml/commit/2f9024c28ba438267de37ac43c6570a2f0398b5a)) - Samuel Lijin

### Release

- bump versions for everything (#662) - ([c0254ae](https://github.com/boundaryml/baml/commit/c0254ae680365854c51c7a4e58ea68d1901ea033)) - Samuel Lijin

### Vscode

- check for updates on the hour (#434) - ([c70a3b3](https://github.com/boundaryml/baml/commit/c70a3b373cb2346a0df9a1eba0ebacb74d59b53e)) - Samuel Lijin
