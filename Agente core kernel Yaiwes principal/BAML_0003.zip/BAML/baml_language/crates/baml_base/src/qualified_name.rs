//! Qualified Names for unambiguous item identification.
//!
//! `QualifiedName` provides a way to uniquely identify items in the BAML project,
//! distinguishing between builtins, standard library items, user-defined items,
//! and (future) other modules and external packages.
//!
//! This is the canonical name type used across all compiler phases from TIR
//! through to runtime.

use crate::Name;

/// Prefix used for standard library items in qualified names.
///
/// All `Namespace::BamlStd` and standard `Namespace::Builtin` items
/// are displayed with this prefix (e.g., `baml.media.Image`).
pub const BAML_STD_PREFIX: &str = "baml.";

/// FQN (as a display string) of the recursive `json` type alias defined in
/// `baml_builtins2/baml_std/baml/ns_json/json.baml`.
///
/// Used as a sentinel across Phases 3 and 6 to short-circuit alias-body
/// recursion for output-format rendering, SAP streaming, and Python codegen.
pub const BAML_JSON_JSON: &str = "baml.json.json";

/// Canonical host-facing typed AI stream. Compiler synthesis, engine handle
/// lifting, and SDK generators must share this identity rather than carrying
/// independent string literals.
pub const AI_STREAM_STREAM: &str = "ai.stream.Stream";

/// Canonical bound LLM function specification capability.
pub const AI_FUNCTION_SPEC: &str = "ai.FunctionSpec";

/// Canonical nominal end-of-stream marker used by AI streams.
pub const AI_STREAM_DONE: &str = "ai.stream.Done";

/// A qualified name that unambiguously identifies an item.
///
/// Combines a namespace (where the item lives) with a name (what the item
/// is called). This allows distinguishing between items with the same name
/// in different contexts.
///
/// # Why `QualifiedName` and not `FullyQualifiedName`?
///
/// BAML doesn't have partially qualified names - every name is either:
/// - A simple identifier resolved in the current scope, or
/// - A complete path that unambiguously identifies an item
///
/// Since there's no partial qualification, the "fully" prefix is redundant.
/// We use `QualifiedName` for brevity.
///
/// # Examples
///
/// ```ignore
/// // User-defined class "User"
/// QualifiedName { namespace: Namespace::Local, name: "User" }
///
/// // Builtin "env" (has property "get")
/// QualifiedName { namespace: Namespace::Builtin { path: [] }, name: "env" }
///
/// // Builtin method "Array.length"
/// QualifiedName { namespace: Namespace::Builtin { path: ["Array"] }, name: "length" }
/// ```
#[derive(Debug, Clone, PartialEq, Eq, Hash, salsa::Update)]
pub struct QualifiedName {
    /// The namespace this item belongs to.
    pub namespace: Namespace,
    /// The item's name within its namespace.
    pub name: Name,
}

/// The namespace an item belongs to.
///
/// Namespaces organize items by their origin and resolution rules.
#[derive(Debug, Clone, PartialEq, Eq, Hash, salsa::Update)]
pub enum Namespace {
    /// Compiler builtins that are "magic" - the compiler knows about them specially.
    ///
    /// Examples:
    /// - `env` -> `Builtin { path: [] }` with name "env"
    /// - `baml.Array.length` -> `Builtin { path: ["Array"] }` with name "length"
    Builtin {
        /// Path segments leading to the item.
        /// e.g., `["Array"]` for `baml.Array.length`
        /// e.g., `[]` for top-level builtins like `env`
        path: Vec<Name>,
    },

    /// Standard library items that require `baml.` prefix.
    ///
    /// Example: `baml.http.get` (future feature)
    BamlStd {
        /// Path segments after `baml.`
        /// e.g., `["http"]` for `baml.http.get`
        path: Vec<Name>,
    },

    /// User-defined items in the current project.
    ///
    /// This is the most common namespace. Items defined in `.baml` files
    /// without any module system or imports are all in this namespace.
    Local,

    /// Items from explicit user modules (future feature).
    ///
    /// When we add module support, items like `users.User` would have:
    /// `UserModule { module_path: ["users"] }`
    UserModule {
        /// The module path.
        /// e.g., `["users"]` for `users.User`
        module_path: Vec<Name>,
    },

    /// Items from external packages (future feature).
    ///
    /// When we add package support, items from dependencies would be
    /// in this namespace.
    Package {
        /// The package name.
        package_name: Name,
        /// The module path within the package.
        module_path: Vec<Name>,
    },
}

impl QualifiedName {
    /// Create a [`QualifiedName`] for a local (project-level) item.
    ///
    /// This is the most common constructor - use it for user-defined
    /// classes, enums, functions, etc.
    pub fn local(name: Name) -> Self {
        Self {
            namespace: Namespace::Local,
            name,
        }
    }

    /// Create a [`QualifiedName`] for a builtin item.
    ///
    /// # Arguments
    /// * `path` - The path segments leading to the item (e.g., `["Array"]`)
    /// * `name` - The item name (e.g., `"length"`)
    pub fn builtin(path: Vec<Name>, name: Name) -> Self {
        Self {
            namespace: Namespace::Builtin { path },
            name,
        }
    }

    /// Create a [`QualifiedName`] for a standard library item.
    pub fn baml_std(path: Vec<Name>, name: Name) -> Self {
        Self {
            namespace: Namespace::BamlStd { path },
            name,
        }
    }

    /// Create a [`QualifiedName`] for a user module item.
    pub fn user_module(module_path: Vec<Name>, name: Name) -> Self {
        Self {
            namespace: Namespace::UserModule { module_path },
            name,
        }
    }

    /// Create a [`QualifiedName`] for an external package item.
    pub fn package(package_name: Name, module_path: Vec<Name>, name: Name) -> Self {
        Self {
            namespace: Namespace::Package {
                package_name,
                module_path,
            },
            name,
        }
    }

    /// Check if this [`QualifiedName`] refers to a local item.
    pub fn is_local(&self) -> bool {
        matches!(self.namespace, Namespace::Local)
    }

    /// Check if this [`QualifiedName`] refers to a builtin.
    pub fn is_builtin(&self) -> bool {
        matches!(self.namespace, Namespace::Builtin { .. })
    }

    /// Check if this [`QualifiedName`] refers to a standard library item.
    pub fn is_baml_std(&self) -> bool {
        matches!(self.namespace, Namespace::BamlStd { .. })
    }

    /// Create a [`QualifiedName`] from module path segments and an item name.
    ///
    /// Used when resolving module item paths like `baml.http.Response`.
    pub fn from_module_path(module_path: &[Name], item_name: Name) -> Self {
        if module_path.is_empty() {
            Self::local(item_name)
        } else if module_path[0].as_str() == "baml" {
            // Path starts with "baml" - it's a builtin or baml_std item
            Self::builtin(module_path[1..].to_vec(), item_name)
        } else {
            // User module path
            Self::user_module(module_path.to_vec(), item_name)
        }
    }

    /// Create a [`QualifiedName`] for a builtin primitive type (int, float, string, bool, etc.).
    ///
    /// These are simple builtins at the root level with no path.
    pub fn builtin_primitive(name: Name) -> Self {
        Self {
            namespace: Namespace::Builtin { path: vec![] },
            name,
        }
    }

    /// Get a display string for this [`QualifiedName`].
    ///
    /// Returns a human-readable representation like:
    /// - `"User"` for local items
    /// - `"baml.Array.length"` for builtins
    pub fn display(&self) -> String {
        match &self.namespace {
            Namespace::Local => self.name.to_string(),
            Namespace::Builtin { path } => {
                let mut parts: Vec<&str> = vec!["baml"];
                parts.extend(path.iter().map(smol_str::SmolStr::as_str));
                parts.push(self.name.as_str());
                parts.join(".")
            }
            Namespace::BamlStd { path } => {
                let mut parts: Vec<&str> = vec!["baml"];
                parts.extend(path.iter().map(smol_str::SmolStr::as_str));
                parts.push(self.name.as_str());
                parts.join(".")
            }
            Namespace::UserModule { module_path } => {
                let mut parts: Vec<&str> =
                    module_path.iter().map(smol_str::SmolStr::as_str).collect();
                parts.push(self.name.as_str());
                parts.join(".")
            }
            Namespace::Package {
                package_name,
                module_path,
            } => {
                let mut parts: Vec<&str> = vec![package_name.as_str()];
                parts.extend(module_path.iter().map(smol_str::SmolStr::as_str));
                parts.push(self.name.as_str());
                parts.join(".")
            }
        }
    }

    /// Convert to a runtime string for VM function lookup.
    ///
    /// This is the canonical string representation used by the VM to look up
    /// native functions. It should match the paths generated by `baml_builtins`.
    ///
    /// For builtins, this produces strings like:
    /// - `"baml.Array.length"`
    /// - `"baml.String.to_lower_case"`
    /// - `"baml.env.get"`
    ///
    /// For local items, this is just the name.
    pub fn to_runtime_string(&self) -> String {
        self.display()
    }

    /// Parse a builtin path string into a [`QualifiedName`].
    ///
    /// Builtin paths follow the format:
    /// - `"baml.Array.length"` -> Builtin with path `["Array"]`, name: `"length"`
    /// - `"baml.http.Response.text"` -> Builtin with path `["http", "Response"]`, name: `"text"`
    /// - `"baml.env.get"` -> Builtin with path `["env"]`, name: `"get"`
    /// - `"baml.deep_copy"` -> Builtin with path `[]`, name: `"deep_copy"`
    ///
    /// Legacy non-prefixed inputs such as `"env.get"` are canonicalized to
    /// `"baml.env.get"`.
    ///
    /// # Panics
    /// Panics if the path is empty.
    pub fn from_builtin_path(path: &str) -> Self {
        let segments: Vec<&str> = path.split('.').collect();
        assert!(!segments.is_empty(), "builtin path cannot be empty");

        if segments[0] != "baml" {
            if segments.len() == 1 {
                return Self {
                    namespace: Namespace::Builtin { path: vec![] },
                    name: Name::new(segments[0]),
                };
            }
            let path_segments: Vec<Name> = segments[..segments.len() - 1]
                .iter()
                .map(|s| Name::new(*s))
                .collect();
            let name = Name::new(segments[segments.len() - 1]);
            return Self {
                namespace: Namespace::Builtin {
                    path: path_segments,
                },
                name,
            };
        }

        // Handle "baml.*" paths
        if segments.len() == 1 {
            // Just "baml" - shouldn't happen but handle it
            return Self::builtin(vec![], Name::new("baml"));
        }

        // "baml.deep_copy" -> Builtin { path: [] }, name: "deep_copy"
        // "baml.Array.length" -> Builtin { path: ["Array"] }, name: "length"
        let path: Vec<Name> = segments[1..segments.len() - 1]
            .iter()
            .map(|s| Name::new(*s))
            .collect();
        let name = Name::new(segments[segments.len() - 1]);
        Self::builtin(path, name)
    }
}

impl std::fmt::Display for QualifiedName {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "{}", self.display())
    }
}

impl std::fmt::Display for Namespace {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Namespace::Local => write!(f, "local"),
            Namespace::Builtin { path } => {
                write!(f, "builtin")?;
                if !path.is_empty() {
                    write!(
                        f,
                        ".{}",
                        path.iter()
                            .map(smol_str::SmolStr::as_str)
                            .collect::<Vec<_>>()
                            .join(".")
                    )?;
                }
                Ok(())
            }
            Namespace::BamlStd { path } => {
                write!(f, "baml")?;
                if !path.is_empty() {
                    write!(
                        f,
                        ".{}",
                        path.iter()
                            .map(smol_str::SmolStr::as_str)
                            .collect::<Vec<_>>()
                            .join(".")
                    )?;
                }
                Ok(())
            }
            Namespace::UserModule { module_path } => {
                write!(
                    f,
                    "mod.{}",
                    module_path
                        .iter()
                        .map(smol_str::SmolStr::as_str)
                        .collect::<Vec<_>>()
                        .join(".")
                )
            }
            Namespace::Package {
                package_name,
                module_path,
            } => {
                write!(f, "pkg.{package_name}")?;
                if !module_path.is_empty() {
                    write!(
                        f,
                        ".{}",
                        module_path
                            .iter()
                            .map(smol_str::SmolStr::as_str)
                            .collect::<Vec<_>>()
                            .join(".")
                    )?;
                }
                Ok(())
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_local_qn() {
        let qn = QualifiedName::local(Name::new("User"));
        assert!(qn.is_local());
        assert!(!qn.is_builtin());
        assert_eq!(qn.display(), "User");
        assert_eq!(qn.to_runtime_string(), "User");
    }

    #[test]
    fn test_builtin_qn() {
        let qn = QualifiedName::builtin(vec![Name::new("Array")], Name::new("length"));
        assert!(!qn.is_local());
        assert!(qn.is_builtin());
        assert_eq!(qn.display(), "baml.Array.length");
        assert_eq!(qn.to_runtime_string(), "baml.Array.length");
    }

    #[test]
    fn test_builtin_primitive() {
        let qn = QualifiedName::builtin_primitive(Name::new("int"));
        assert!(qn.is_builtin());
        assert_eq!(qn.display(), "baml.int");
    }

    #[test]
    fn test_baml_std() {
        let qn = QualifiedName::baml_std(vec![Name::new("http")], Name::new("get"));
        assert!(qn.is_baml_std());
        assert_eq!(qn.display(), "baml.http.get");
    }

    #[test]
    fn test_baml_std_prefix_matches_display() {
        assert_eq!(BAML_STD_PREFIX, "baml.");

        let builtin = QualifiedName::builtin(vec![Name::new("Array")], Name::new("length"));
        assert!(builtin.display().starts_with(BAML_STD_PREFIX));

        let std_item = QualifiedName::baml_std(vec![Name::new("http")], Name::new("get"));
        assert!(std_item.display().starts_with(BAML_STD_PREFIX));

        let env = QualifiedName::from_builtin_path("baml.env.get");
        assert!(env.display().starts_with(BAML_STD_PREFIX));
    }

    #[test]
    fn test_user_module() {
        let qn = QualifiedName::user_module(vec![Name::new("users")], Name::new("User"));
        assert!(!qn.is_local());
        assert_eq!(qn.display(), "users.User");
    }

    #[test]
    fn test_package() {
        let qn = QualifiedName::package(
            Name::new("external_pkg"),
            vec![Name::new("auth")],
            Name::new("Token"),
        );
        assert_eq!(qn.display(), "external_pkg.auth.Token");
    }

    #[test]
    fn test_qn_equality() {
        let qn1 = QualifiedName::local(Name::new("User"));
        let qn2 = QualifiedName::local(Name::new("User"));
        let qn3 = QualifiedName::local(Name::new("Admin"));

        assert_eq!(qn1, qn2);
        assert_ne!(qn1, qn3);
    }

    #[test]
    fn test_builtin_deep_path() {
        let qn = QualifiedName::builtin(
            vec![Name::new("http"), Name::new("Response")],
            Name::new("text"),
        );
        assert_eq!(qn.display(), "baml.http.Response.text");
        assert_eq!(qn.to_runtime_string(), "baml.http.Response.text");
    }

    #[test]
    fn test_from_builtin_path_array_method() {
        let qn = QualifiedName::from_builtin_path("baml.Array.length");
        assert!(qn.is_builtin());
        assert_eq!(qn.name.as_str(), "length");
        assert_eq!(qn.display(), "baml.Array.length");
    }

    #[test]
    fn test_from_builtin_path_deep() {
        let qn = QualifiedName::from_builtin_path("baml.http.Response.text");
        assert!(qn.is_builtin());
        assert_eq!(qn.name.as_str(), "text");
        assert_eq!(qn.display(), "baml.http.Response.text");
    }

    #[test]
    fn test_from_builtin_path_free_function() {
        let qn = QualifiedName::from_builtin_path("baml.deep_copy");
        assert!(qn.is_builtin());
        assert_eq!(qn.name.as_str(), "deep_copy");
        assert_eq!(qn.display(), "baml.deep_copy");
    }

    #[test]
    fn test_from_builtin_path_env() {
        let qn = QualifiedName::from_builtin_path("baml.env.get");
        assert!(qn.is_builtin());
        assert_eq!(qn.name.as_str(), "get");
        assert_eq!(qn.display(), "baml.env.get");
    }

    #[test]
    fn test_from_module_path_env() {
        // Bare env.* is not a builtin path; only baml.env.* is.
        let qn = QualifiedName::from_module_path(&[Name::new("env")], Name::new("get"));
        assert!(!qn.is_builtin());
        assert_eq!(qn.display(), "env.get");
    }

    #[test]
    fn test_roundtrip_builtin_path() {
        // Ensure from_builtin_path and to_runtime_string roundtrip correctly
        let paths = [
            "baml.Array.length",
            "baml.String.to_lower_case",
            "baml.Map.keys",
            "baml.deep_copy",
            "baml.http.Response.text",
            "baml.env.get",
        ];
        for path in paths {
            let qn = QualifiedName::from_builtin_path(path);
            assert_eq!(qn.to_runtime_string(), path, "roundtrip failed for {path}");
        }
    }
}
