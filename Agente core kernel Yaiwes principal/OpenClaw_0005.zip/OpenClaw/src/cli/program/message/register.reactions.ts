// Reaction command registration for adding/removing and listing message reactions.
import type { Command } from "commander";
import type { MessageCliHelpers } from "./helpers.js";

/** Register reaction mutation/list commands. */
export function registerMessageReactionsCommands(message: Command, helpers: MessageCliHelpers) {
  helpers
    .withMessageBase(
      helpers.withRequiredMessageTarget(
        message.command("react").description("Add or remove a reaction"),
      ),
    )
    .requiredOption("--message-id <id>", "Message id")
    .option("--emoji <emoji>", "Emoji for reactions")
    .option("--remove", "Remove reaction", false)
    .option("--participant <id>", "WhatsApp reaction participant")
    .option("--from-me", "WhatsApp reaction fromMe", false)
    .option("--target-author <id>", "Signal reaction target author (uuid or phone)")
    .option("--target-author-uuid <uuid>", "Signal reaction target author uuid")
    .action((opts) => helpers.runMessageAction("react", opts));

  helpers
    .withMessageBase(
      helpers.withRequiredMessageTarget(
        message.command("reactions").description("List reactions on a message"),
      ),
    )
    .requiredOption("--message-id <id>", "Message id")
    .option("--limit <n>", "Result limit")
    .action((opts) => helpers.runMessageAction("reactions", opts));
}
