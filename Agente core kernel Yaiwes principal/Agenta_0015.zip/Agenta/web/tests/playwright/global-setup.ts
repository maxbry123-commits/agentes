import {existsSync, mkdirSync, writeFileSync} from "fs"
import {dirname} from "path"

import {chromium, type BrowserContext, type Page} from "@playwright/test"

import {waitForApiResponse} from "../tests/fixtures/base.fixture/apiHelpers"
import {clickButton, typeWithDelay} from "../tests/fixtures/base.fixture/uiHelpers/helpers"
import {AuthResponse} from "../tests/fixtures/user.fixture/authHelpers/types"
import {pollLocatorState} from "../utils"
import {generateRuntimeTestEmail, getTestmailClient, isTestmailInboxEmail} from "../utils/testmail"

import {
    getChromiumLaunchOptions,
    getOutputDir,
    getProjectMetadataPath,
    getStorageStatePath,
} from "./config/runtime.ts"

type AuthMode = "auto" | "password" | "otp"
type TestmailClient = ReturnType<typeof getTestmailClient>

/**
 * Read the auth method the backend serves from the `/auth/discover` response.
 * The payload is `{exists, methods: {"email:password"?: true, "email:otp"?: true, ...}}`
 * — only available methods are present. Prefer password (local dev / no SMTP does a
 * direct signup with no email verification); fall back to otp only when password is
 * absent. Returns null when discovery was missing/unparseable so the caller keeps `auto`.
 */
function resolveDiscoveredAuthMode(discovery: unknown): AuthMode | null {
    const methods = (discovery as {methods?: Record<string, unknown>} | null)?.methods
    if (!methods || typeof methods !== "object") return null
    if (methods["email:password"]) return "password"
    if (methods["email:otp"]) return "otp"
    return null
}

function getApiURL(webURL: string): string {
    if (process.env.AGENTA_API_URL) return process.env.AGENTA_API_URL
    try {
        const u = new URL(webURL)
        return `${u.origin}/api`
    } catch {
        return `${webURL}/api`
    }
}

// AGENTA_WEB_URL may carry a deployment-specific path (e.g. Railway previews
// publish it as ".../w", the workspace picker), but top-level routes like
// /auth live at the origin root. Strip any path before composing them.
function getOriginURL(webURL: string): string {
    try {
        return new URL(webURL).origin
    } catch {
        return webURL
    }
}

function createTestEmail(scope: string): string {
    return generateRuntimeTestEmail({
        scope,
        branch: process.env.BRANCH_NAME,
    })
}

function logAuthEmail(event: string, email: string): void {
    console.log(`[global-setup] ${event}: ${email}`)
}

function getConfiguredTestEmail(): string | null {
    // Optional fixed account (persistent CI deployments). When unset, a fresh
    // user signs up directly; multi-org OSS needs no owner bootstrap or invite.
    return process.env.AGENTA_TEST_OSS_OWNER_EMAIL?.trim().toLowerCase() || null
}

async function fillOTPDigits(page: Page, otp: string, delay: number): Promise<void> {
    // Ant Design 5.x Input.OTP renders: <div class="ant-otp"><input class="ant-otp-input"/>...</div>
    // Click the first cell to ensure focus (autoFocus may have been lost), then type sequentially.
    const firstInput = page.locator(".ant-otp input").first()
    await firstInput.waitFor({state: "visible", timeout: 10000})
    await firstInput.click()
    await page.keyboard.type(otp, {delay})
}

async function clickVisibleSurveyChoice(page: Page, choice: string): Promise<boolean> {
    const radio = page.getByRole("radio", {name: choice, exact: true}).first()
    if (await pollLocatorState(() => radio.isVisible())) {
        await radio.check().catch(async () => {
            await radio.click({force: true})
        })
        return true
    }

    const checkbox = page.getByRole("checkbox", {name: choice, exact: true}).first()
    if (await pollLocatorState(() => checkbox.isVisible())) {
        await checkbox.check().catch(async () => {
            await checkbox.click({force: true})
        })
        return true
    }

    const text = page.getByText(choice, {exact: true}).first()
    if (await pollLocatorState(() => text.isVisible())) {
        await text.click({force: true})
        return true
    }

    return false
}

async function fillVisiblePostSignupFields(page: Page): Promise<void> {
    const preferredChoices = [
        "2-10",
        "Hobbyist",
        "Just exploring",
        "Evaluating LLM Applications",
        "Github",
    ]

    for (const choice of preferredChoices) {
        await clickVisibleSurveyChoice(page, choice)
    }

    const formItems = page.locator(".ant-form-item")
    const formItemCount = await formItems.count()

    for (let index = 0; index < formItemCount; index++) {
        const item = formItems.nth(index)
        if (!(await pollLocatorState(() => item.isVisible()))) {
            continue
        }

        const checkedRadio = item.getByRole("radio", {checked: true}).first()
        if (!(await pollLocatorState(() => checkedRadio.isVisible()))) {
            const radio = item.getByRole("radio").first()
            if (await pollLocatorState(() => radio.isVisible())) {
                await radio.check().catch(async () => {
                    await radio.click({force: true})
                })
                continue
            }
        }

        const checkedCheckbox = item.getByRole("checkbox", {checked: true}).first()
        if (!(await pollLocatorState(() => checkedCheckbox.isVisible()))) {
            const checkbox = item.getByRole("checkbox").first()
            if (await pollLocatorState(() => checkbox.isVisible())) {
                await checkbox.check().catch(async () => {
                    await checkbox.click({force: true})
                })
                continue
            }
        }

        const textArea = item.locator("textarea").first()
        if (await pollLocatorState(() => textArea.isVisible())) {
            const value = await textArea.inputValue().catch(() => "")
            if (!value.trim()) {
                await textArea.fill("E2E signup bootstrap")
            }
            continue
        }

        const textInput = item
            .locator('input:not([type="hidden"]):not([type="radio"]):not([type="checkbox"])')
            .first()
        if (await pollLocatorState(() => textInput.isVisible())) {
            const value = await textInput.inputValue().catch(() => "")
            if (!value.trim()) {
                await textInput.fill("E2E signup bootstrap")
            }
            continue
        }
    }
}

async function advanceVisiblePostSignupStep(page: Page): Promise<boolean> {
    const submitButton = page.getByRole("button", {name: "Submit", exact: true}).first()
    if (await pollLocatorState(() => submitButton.isVisible())) {
        if (await submitButton.isDisabled().catch(() => true)) {
            return false
        }
        await submitButton.click()
        return true
    }

    const continueButton = page.getByRole("button", {name: "Continue", exact: true}).first()
    if (await pollLocatorState(() => continueButton.isVisible())) {
        if (await continueButton.isDisabled().catch(() => true)) {
            return false
        }
        await continueButton.click()
        return true
    }

    return false
}

async function handlePostSignup(page: Page): Promise<void> {
    try {
        await page.waitForURL("**/post-signup", {
            waitUntil: "domcontentloaded",
            timeout: 10000,
        })
    } catch {
        console.log("[global-setup] No post-signup redirect detected, continuing")
        return
    }

    console.log("[global-setup] New user detected, on post-signup page")

    const settleTimeoutMs = 15_000
    const deadline = Date.now() + settleTimeoutMs
    let completedSurveyStep = false

    while (Date.now() < deadline) {
        const pathname = await getCurrentPathname(page)
        if (!pathname.endsWith("/post-signup")) {
            console.log("[global-setup] Post-signup redirected, continuing")
            return
        }

        const surveyTitle = page
            .getByRole("heading", {name: /Tell us about yourself|Almost done/i})
            .first()
        const surveyVisible = await pollLocatorState(() => surveyTitle.isVisible())
        const hasActionButton = await pollLocatorState(() =>
            page
                .getByRole("button", {name: /Continue|Submit/})
                .first()
                .isVisible(),
        )

        if (!surveyVisible && !hasActionButton) {
            await page.waitForTimeout(500)
            continue
        }

        await fillVisiblePostSignupFields(page)
        const advanced = await advanceVisiblePostSignupStep(page)
        completedSurveyStep = completedSurveyStep || advanced

        if (!advanced) {
            await page.waitForTimeout(500)
            continue
        }

        await page.waitForTimeout(1000)
    }

    const finalPathname = await getCurrentPathname(page).catch(() => "unknown")
    if (!finalPathname.endsWith("/post-signup")) {
        console.log("[global-setup] Post-signup left after final check, continuing")
        return
    }

    const fallbackUrl = new URL("/get-started", page.url()).toString()
    console.log(`[global-setup] Post-signup is still stuck, forcing fallback to ${fallbackUrl}`)
    await page.goto(fallbackUrl, {
        waitUntil: "domcontentloaded",
        timeout: 15000,
    })

    if (completedSurveyStep) {
        console.log("[global-setup] Continued after forced get-started fallback")
        return
    }

    console.log(
        "[global-setup] Post-signup did not render an actionable survey; continued with get-started fallback",
    )
}

async function getCurrentPathname(page: Page): Promise<string> {
    try {
        return await page.evaluate(() => {
            const browserContext = globalThis as {location?: {pathname?: string}}
            return browserContext.location?.pathname ?? "/"
        })
    } catch {
        return new URL(page.url()).pathname
    }
}

async function waitForPathname(
    page: Page,
    predicate: (pathname: string) => boolean,
    timeout: number,
    description: string,
): Promise<string> {
    const startedAt = Date.now()

    while (Date.now() - startedAt < timeout) {
        const pathname = await getCurrentPathname(page)
        if (predicate(pathname)) {
            return pathname
        }

        await page.waitForTimeout(250)
    }

    const lastPathname = await getCurrentPathname(page).catch(() => "unknown")
    throw new Error(
        `[global-setup] Timed out waiting for ${description}. Last pathname: ${lastPathname}`,
    )
}

async function handleGetStarted(page: Page, timeout: number): Promise<boolean> {
    const pathname = await getCurrentPathname(page)
    if (!pathname.startsWith("/get-started")) {
        return false
    }

    console.log("[global-setup] New user detected, on get-started page")

    const skipButton = page.getByRole("button", {name: "Skip", exact: true})
    await skipButton.waitFor({state: "visible", timeout: Math.min(timeout, 15000)})
    await skipButton.click()

    await waitForPathname(
        page,
        (nextPathname) => !nextPathname.startsWith("/get-started"),
        timeout,
        "get-started redirect",
    )

    console.log(`[global-setup] Get-started skipped, now on: ${page.url()}`)
    return true
}

async function waitForSettledAuthenticatedPage(page: Page, timeout: number): Promise<void> {
    const startedAt = Date.now()

    while (Date.now() - startedAt < timeout) {
        const pathname = await getCurrentPathname(page)
        const remainingTimeout = Math.max(timeout - (Date.now() - startedAt), 1000)

        if (pathname.endsWith("/post-signup")) {
            await handlePostSignup(page)
            continue
        }

        if (pathname.startsWith("/get-started")) {
            await handleGetStarted(page, remainingTimeout)
            continue
        }

        if (pathname.includes("/auth")) {
            await waitForPathname(
                page,
                (nextPathname) => !nextPathname.includes("/auth"),
                remainingTimeout,
                "authentication redirect",
            )
            continue
        }

        if (pathname.startsWith("/workspaces/accept")) {
            await waitForPathname(
                page,
                (nextPathname) => !nextPathname.startsWith("/workspaces/accept"),
                remainingTimeout,
                "workspace acceptance redirect",
            ).catch(() => {})
            continue
        }

        console.log(`[global-setup] Settled on: ${page.url()}`)
        return
    }

    const pathname = await getCurrentPathname(page).catch(() => "unknown")
    throw new Error(
        `[global-setup] Timed out waiting for authenticated page to settle. Last pathname: ${pathname}`,
    )
}

async function logAuthApiResponse(
    response: Awaited<ReturnType<Page["waitForResponse"]>> | null,
    label: string,
): Promise<unknown> {
    if (!response) {
        console.log(`[global-setup] ${label}: no response captured`)
        return null
    }

    const text = await response.text().catch(() => "")
    let body: unknown = text

    try {
        body = text ? JSON.parse(text) : null
    } catch {
        // Keep raw text when the response is not JSON.
    }

    console.log(
        `[global-setup] ${label}: ${response.request().method()} ${response.url()} -> ${response.status()} ${JSON.stringify(body)}`,
    )

    return body
}

async function getVisibleAuthFeedback(page: Page): Promise<string | null> {
    const candidateTexts = [
        "Invalid email or password",
        "You need to be invited by the organization owner to gain access.",
        "Please complete the security check.",
        "Please complete the security check again to continue.",
        "Unable to connect to the authentication service",
        "Oops, something went wrong. Please try again",
        "Verification successful",
    ]

    for (const candidate of candidateTexts) {
        const locator = page.getByText(candidate, {exact: false}).first()
        if (await pollLocatorState(() => locator.isVisible())) {
            const text = (await locator.textContent().catch(() => candidate))?.trim()
            if (text) {
                return text
            }
        }
    }

    return null
}

async function captureAuthFailure(page: Page, label: string, err: unknown): Promise<void> {
    const ts = new Date().toISOString().replace(/[:.]/g, "-")
    const baseName = `auth-failure-${label}-${ts}`
    const outDir = getOutputDir()
    try {
        if (!existsSync(outDir)) mkdirSync(outDir, {recursive: true})
    } catch {}

    console.log(`[global-setup] ===== AUTH FAILURE DEBUG (${label}) =====`)
    try {
        console.log(
            `[global-setup] error: ${err instanceof Error ? err.stack || err.message : String(err)}`,
        )
    } catch {}
    try {
        console.log(`[global-setup] url: ${page.url()}`)
    } catch (e) {
        console.log(`[global-setup] url: <unavailable> (${e})`)
    }
    try {
        console.log(`[global-setup] title: ${await page.title()}`)
    } catch (e) {
        console.log(`[global-setup] title: <unavailable> (${e})`)
    }
    try {
        const screenshotPath = `${outDir}/${baseName}.png`
        await page.screenshot({path: screenshotPath, fullPage: true})
        console.log(`[global-setup] screenshot: ${screenshotPath}`)
    } catch (e) {
        console.log(`[global-setup] screenshot failed: ${e}`)
    }
    try {
        const html = await page.content()
        const htmlPath = `${outDir}/${baseName}.html`
        writeFileSync(htmlPath, html)
        console.log(`[global-setup] html: ${htmlPath}`)
    } catch (e) {
        console.log(`[global-setup] html capture failed: ${e}`)
    }
    try {
        const text = await page.locator("body").innerText({timeout: 5000})
        console.log(`[global-setup] visible text:\n${text}`)
    } catch (e) {
        console.log(`[global-setup] text capture failed: ${e}`)
    }
    console.log(`[global-setup] ===== END AUTH FAILURE DEBUG =====`)
}

async function authenticateUser({
    page,
    entryUrl,
    email,
    password,
    authMode,
    timeout,
    inputDelay,
    testmail,
}: {
    page: Page
    entryUrl: string
    email: string
    password: string
    authMode: AuthMode
    timeout: number
    inputDelay: number
    testmail: TestmailClient | null
}): Promise<void> {
    const consoleLogs: string[] = []
    page.on("console", (msg) => {
        consoleLogs.push(`[${msg.type()}] ${msg.text()}`)
    })
    page.on("pageerror", (err) => {
        consoleLogs.push(`[pageerror] ${err.message}`)
    })
    page.on("requestfailed", (req) => {
        consoleLogs.push(
            `[requestfailed] ${req.method()} ${req.url()} — ${req.failure()?.errorText}`,
        )
    })

    try {
        await authenticateUserImpl({
            page,
            entryUrl,
            email,
            password,
            authMode,
            timeout,
            inputDelay,
            testmail,
        })
    } catch (err) {
        console.log(`[global-setup] page console log dump (${consoleLogs.length} entries):`)
        for (const line of consoleLogs) console.log(`  ${line}`)
        await captureAuthFailure(page, "authenticateUser", err)
        throw err
    }
}

async function authenticateUserImpl({
    page,
    entryUrl,
    email,
    password,
    authMode,
    timeout,
    inputDelay,
    testmail,
}: {
    page: Page
    entryUrl: string
    email: string
    password: string
    authMode: AuthMode
    timeout: number
    inputDelay: number
    testmail: TestmailClient | null
}): Promise<void> {
    let otpRequestedAt = Date.now()
    const namespace = process.env.TESTMAIL_NAMESPACE

    // Each auth flow uses a fresh browser context. Clear cookies up front, but do
    // not wipe storage after loading the entry URL because invite flows persist
    // token/context from the URL into storage during initial page load.
    await page.context().clearCookies()

    console.log(`[global-setup] Navigating to auth entry: ${entryUrl}`)
    await page.goto(entryUrl, {timeout, waitUntil: "domcontentloaded"})

    const emailInput = page.locator('input[type="email"]').first()
    await emailInput.waitFor({state: "visible", timeout})

    const emailInputIsEditable = await pollLocatorState(() => emailInput.isEditable())
    if (emailInputIsEditable) {
        await typeWithDelay(page, 'input[type="email"]', email)

        const continueWithEmail = page.getByRole("button", {name: "Continue with email"})
        const continueWithOtp = page.getByRole("button", {name: "Continue with OTP"})
        const continueButton = page.getByRole("button", {name: "Continue", exact: true})

        // Wait for and intercept the discovery API call when clicking Continue
        const discoveryTimeout = new Promise<null>((resolve) =>
            setTimeout(() => resolve(null), 15000),
        )
        const discoveryPromise = Promise.race([
            waitForApiResponse(page, {
                route: /\/api\/auth\/discover(?:\?|$)/,
                validateStatus: false,
            }).catch(() => null),
            discoveryTimeout,
        ])

        if (await pollLocatorState(() => continueWithEmail.isVisible())) {
            await continueWithEmail.click()
        } else if (await pollLocatorState(() => continueWithOtp.isVisible())) {
            await continueWithOtp.click()
        } else if (await pollLocatorState(() => continueButton.isVisible())) {
            await continueButton.click()
        }

        // Wait for discovery to complete so the auth method UI is fully rendered
        console.log("[global-setup] Waiting for auth discovery to complete")
        const discovery = await discoveryPromise
        console.log("[global-setup] Auth discovery completed")

        // The backend authoritatively tells us which email method it serves:
        // `email:password` (local dev / no SMTP — direct signup, no verification)
        // vs `email:otp` (SMTP/SendGrid enabled). Promote `auto` to the concrete
        // method the deployment actually offers so we don't demand Testmail/OTP on
        // a stack that only does password.
        const discovered = resolveDiscoveredAuthMode(discovery)
        if (authMode === "auto" && discovered) {
            authMode = discovered
            console.log(`[global-setup] Discovery resolved auth mode: ${authMode}`)
        }
    }

    const verifyEmailLocator = page.getByText("Verify your email")
    const continueWithOtpButton = page.getByRole("button", {name: "Continue with OTP"})
    const resendOtpLink = page.getByText("Resend one-time password")
    const passwordInput = page.locator("input[type='password']").first()

    if (authMode === "password") {
        await passwordInput.waitFor({state: "visible", timeout})
    } else if (authMode === "otp") {
        console.log("[global-setup] Waiting for OTP flow controls")
        await Promise.race([
            verifyEmailLocator.waitFor({state: "visible", timeout}),
            continueWithOtpButton.waitFor({state: "visible", timeout}),
            resendOtpLink.waitFor({state: "visible", timeout}),
        ])
    } else {
        console.log("[global-setup] Auto-detecting password vs OTP flow")
        await Promise.race([
            verifyEmailLocator.waitFor({state: "visible", timeout}),
            continueWithOtpButton.waitFor({state: "visible", timeout}),
            resendOtpLink.waitFor({state: "visible", timeout}),
            passwordInput.waitFor({state: "visible", timeout}),
        ])
    }

    if (await pollLocatorState(() => passwordInput.isVisible())) {
        console.log("[global-setup] Email + password flow detected")
        logAuthEmail("Password sign-in attempt", email)
        await typeWithDelay(page, "input[type='password']", password)

        const signInResponsePromise = Promise.race([
            page
                .waitForResponse(
                    (response) =>
                        /\/api\/auth\/signin(?:\?|$)/.test(response.url()) &&
                        response.request().method() === "POST",
                    {timeout: 15000},
                )
                .catch(() => null),
            new Promise<null>((resolve) => setTimeout(() => resolve(null), 15000)),
        ])

        try {
            await clickButton(page, "Continue with password")
        } catch {
            await page.keyboard.press("Enter")
        }

        const signInResponse = await signInResponsePromise
        const signInPayload = await logAuthApiResponse(signInResponse, "password sign-in response")

        if (
            signInResponse &&
            signInResponse.url().includes("/api/auth/signin") &&
            signInResponse.ok() &&
            signInPayload &&
            typeof signInPayload === "object" &&
            "status" in signInPayload &&
            signInPayload.status === "WRONG_CREDENTIALS_ERROR"
        ) {
            logAuthEmail("Password signup fallback attempt", email)
            const signUpFallbackResponse = await Promise.race([
                page
                    .waitForResponse(
                        (response) =>
                            /\/api\/auth\/signup(?:\?|$)/.test(response.url()) &&
                            response.request().method() === "POST",
                        {timeout: 10000},
                    )
                    .catch(() => null),
                new Promise<null>((resolve) => setTimeout(() => resolve(null), 10000)),
            ])

            await logAuthApiResponse(signUpFallbackResponse, "password signup fallback response")
        }

        await handlePostSignup(page)
        try {
            await waitForSettledAuthenticatedPage(page, timeout)
        } catch (error) {
            const authFeedback = await getVisibleAuthFeedback(page)
            console.error("[global-setup] Password auth did not settle", {
                currentUrl: page.url(),
                authFeedback,
            })
            throw error
        }
        return
    }

    const otpAlreadyRequested = await pollLocatorState(() => resendOtpLink.isVisible())
    const canSendOtp =
        (await pollLocatorState(() => continueWithOtpButton.isVisible())) ||
        (await pollLocatorState(() =>
            continueWithOtpButton.waitFor({state: "visible", timeout: 5000}).then(() => true),
        ))

    if (!otpAlreadyRequested && canSendOtp) {
        console.log("[global-setup] Sending OTP email")
        logAuthEmail("OTP request attempt", email)

        // Turnstile may block the form submission until its token arrives.
        // Depending on the site key, Turnstile can be:
        //   - invisible/auto: solves automatically, just needs time to load
        //   - managed/visible: shows a checkbox the user must click
        //   - interactive: shows a full challenge
        // We handle all modes by:
        //   1. Trying to click the Turnstile iframe checkbox (for visible challenges)
        //   2. Retrying "Continue with OTP" until the createCode API fires
        const MAX_OTP_SEND_ATTEMPTS = 15
        const OTP_SEND_RETRY_DELAY = 3000
        let otpSent = false
        let turnstileSolved = false

        for (let attempt = 1; attempt <= MAX_OTP_SEND_ATTEMPTS; attempt++) {
            otpRequestedAt = Date.now()

            // Try to solve Turnstile challenge if a visible widget is present.
            // The Turnstile iframe src follows the pattern:
            //   https://challenges.cloudflare.com/cdn-cgi/challenge-platform/.../turnstile/...
            // We try a direct CSS selector first, then fall back to page.frames().
            if (!turnstileSolved) {
                try {
                    // Approach 1: Direct CSS selector for the Turnstile iframe
                    const turnstileIframe = page
                        .locator(
                            'iframe[src*="challenges.cloudflare.com/cdn-cgi/challenge-platform"]',
                        )
                        .first()
                    if (await pollLocatorState(() => turnstileIframe.isVisible())) {
                        console.log(
                            `[global-setup] Turnstile iframe found via CSS selector (attempt ${attempt})`,
                        )
                        await turnstileIframe.click()
                        await page.waitForTimeout(2000)
                        turnstileSolved = true
                    } else {
                        // Approach 2: Enumerate page.frames() for Cloudflare URLs
                        const frames = page.frames()
                        const turnstileFrame = frames.find(
                            (f) =>
                                f !== page.mainFrame() &&
                                /cloudflare|turnstile|challenges/i.test(f.url()),
                        )
                        if (turnstileFrame) {
                            console.log(
                                `[global-setup] Found Turnstile frame via page.frames(): ${turnstileFrame.url()} (attempt ${attempt})`,
                            )
                            const body = turnstileFrame.locator("body")
                            await body.click({timeout: 3000})
                            await page.waitForTimeout(2000)
                            turnstileSolved = true
                        } else if (attempt <= 3) {
                            // Approach 3: Click any visible iframe (auth page only has Turnstile)
                            const iframes = page.locator("iframe")
                            const iframeCount = await iframes.count()
                            if (iframeCount > 0) {
                                for (let i = 0; i < iframeCount; i++) {
                                    const iframe = iframes.nth(i)
                                    if (await pollLocatorState(() => iframe.isVisible())) {
                                        const src = await iframe
                                            .getAttribute("src")
                                            .catch(() => "unknown")
                                        console.log(
                                            `[global-setup] Clicking iframe[${i}] src=${src} (attempt ${attempt})`,
                                        )
                                        await iframe.click().catch(() => {})
                                        await page.waitForTimeout(2000)
                                        turnstileSolved = true
                                        break
                                    }
                                }
                            }
                        }
                    }
                } catch (e) {
                    console.log(`[global-setup] Turnstile interaction failed: ${e}`)
                }
            }

            // Set up a short-lived listener for the createCode response
            const createCodeRace = Promise.race([
                page
                    .waitForResponse((response) => {
                        const url = response.url()
                        return (
                            /\/api\/auth\/signinup\/code(?:\?|$)/.test(url) &&
                            response.request().method() === "POST"
                        )
                    })
                    .then((r) => ({fired: true as const, response: r})),
                new Promise<{fired: false}>((resolve) =>
                    setTimeout(() => resolve({fired: false}), OTP_SEND_RETRY_DELAY),
                ),
            ])

            await continueWithOtpButton.click()
            const result = await createCodeRace

            if (result.fired) {
                console.log(`[global-setup] createCode API responded on attempt ${attempt}`)
                otpSent = true
                break
            }

            // Check if a "security check" error appeared (Turnstile not ready yet)
            const securityCheckError = page.getByText("Please complete the security check")
            if (await pollLocatorState(() => securityCheckError.isVisible())) {
                console.log(
                    `[global-setup] Turnstile not ready yet (attempt ${attempt}/${MAX_OTP_SEND_ATTEMPTS}), retrying...`,
                )
                // Reset solved flag — maybe the click didn't actually produce a token
                turnstileSolved = false
            } else {
                console.log(
                    `[global-setup] createCode did not fire on attempt ${attempt}, retrying...`,
                )
            }
        }

        if (!otpSent) {
            throw new Error(
                "Failed to send OTP: createCode API never fired after " +
                    MAX_OTP_SEND_ATTEMPTS +
                    " attempts. Turnstile may not have solved.",
            )
        }

        await resendOtpLink.waitFor({state: "visible", timeout})
    }

    if (authMode === "password") {
        throw new Error("Password auth was forced but OTP flow was rendered")
    }

    if (!testmail) {
        throw new Error(
            "OTP auth was rendered, but TESTMAIL_API_KEY and TESTMAIL_NAMESPACE are not configured",
        )
    }

    if (!isTestmailInboxEmail(email, namespace)) {
        throw new Error(`OTP auth requires a Testmail inbox email, got '${email}'`)
    }

    if (await pollLocatorState(() => resendOtpLink.isVisible())) {
        console.log("[global-setup] OTP entry screen already active, requesting a fresh OTP email")
        otpRequestedAt = Date.now()
        const resendCodeResponsePromise = waitForApiResponse(page, {
            route: /\/api\/auth\/signinup\/code\/resend(?:\?|$)/,
            validateStatus: true,
        })
        await resendOtpLink.click()
        await resendCodeResponsePromise
    }

    console.log("[global-setup] OTP flow detected")
    logAuthEmail("Waiting for OTP email", email)
    const otp = await testmail.waitForOTP(email, {
        timeout,
        timestamp_from: otpRequestedAt,
    })
    console.log("[global-setup] OTP email received")
    const responsePromise = waitForApiResponse<AuthResponse>(page, {
        route: "/api/auth/signinup/code/consume",
        validateStatus: true,
    })

    console.log("[global-setup] Filling OTP input")
    await fillOTPDigits(page, otp, inputDelay)
    logAuthEmail("OTP submit attempt", email)
    await clickButton(page, "Continue with OTP")
    const responseData = await responsePromise
    console.log("[global-setup] OTP submit response received")

    if (responseData.createdNewRecipeUser) {
        await handlePostSignup(page)
    }

    await waitForSettledAuthenticatedPage(page, timeout)
}

async function globalSetup() {
    console.log("[global-setup] Starting global setup for authentication")

    const baseURL = process.env.AGENTA_WEB_URL || "http://localhost:3000"
    const rootURL = getOriginURL(baseURL)
    const license = process.env.AGENTA_LICENSE || "oss"
    const storageState = getStorageStatePath()
    console.log(`[global-setup] Base URL: ${baseURL}, License: ${license}`)

    const timeout = 60000
    const inputDelay = 100
    const authMode: AuthMode = "auto"
    const hasTestmailConfig = Boolean(
        process.env.TESTMAIL_API_KEY && process.env.TESTMAIL_NAMESPACE,
    )
    const testmail = hasTestmailConfig ? getTestmailClient() : null
    const configuredEmail = getConfiguredTestEmail()
    const userEmail = configuredEmail || createTestEmail(`${license}-user`)
    const configuredPassword =
        process.env.AGENTA_TEST_OSS_OWNER_PASSWORD ||
        process.env.AGENTA_ADMIN_PASSWORD ||
        process.env.AGENTA_TEST_PASSWORD ||
        "TestPass123!"
    const userPassword = configuredEmail
        ? configuredPassword
        : process.env.AGENTA_TEST_PASSWORD || configuredPassword

    console.log("[global-setup] Launching browser")
    const browser = await chromium.launch(getChromiumLaunchOptions())
    console.log("[global-setup] Browser launched OK")
    let authenticatedContext: BrowserContext | null = null
    let authenticatedPage: Page | null = null

    try {
        // Same flow for OSS and EE: sign up (or sign in) directly. Each new
        // user gets their own organization, so no owner-invite bootstrap.
        authenticatedContext = await browser.newContext()
        authenticatedPage = await authenticatedContext.newPage()

        console.log(`[global-setup] Authenticating ${license} user: ${userEmail}`)
        await authenticateUser({
            page: authenticatedPage,
            entryUrl: `${rootURL}/auth`,
            email: userEmail,
            password: userPassword,
            authMode,
            timeout,
            inputDelay,
            testmail,
        })

        mkdirSync(dirname(storageState), {recursive: true})
        await authenticatedPage.context().storageState({path: storageState})
        await maybeCreateEphemeralProject(authenticatedPage, baseURL)
    } catch (error) {
        if (existsSync(storageState)) {
            console.warn(
                "[global-setup] Auth bootstrap failed, reusing existing storage state for this license",
            )
            const cachedContext = await browser.newContext({storageState})
            const cachedPage = await cachedContext.newPage()
            await cachedPage.goto(`${rootURL}/apps`, {timeout, waitUntil: "domcontentloaded"})
            await maybeCreateEphemeralProject(cachedPage, baseURL)
            await cachedContext.close()
            return
        }

        console.error("[global-setup] Error in login flow:", error)
        throw error
    } finally {
        await authenticatedContext?.close()
        await browser.close()
    }
}

async function maybeCreateEphemeralProject(page: Page, baseURL: string): Promise<void> {
    const ephemeralEnabled =
        String(process.env.AGENTA_TEST_EPHEMERAL_PROJECT ?? "true").toLowerCase() !== "false"

    console.log("[global-setup] Setting up test project metadata...")

    try {
        const apiURL = getApiURL(baseURL)
        const projectMetadataPath = getProjectMetadataPath()

        // The page.request context inherits cookies from the page, but the
        // SuperTokens session cookie may not have propagated yet if the
        // sign-in network response wasn't observed before the page settled.
        // Poll GET /projects/ for up to 10s; 401 here just means the cookie
        // hasn't been written to the request context yet.
        const sessionReadyDeadline = Date.now() + 10_000
        let sessionReady = false
        while (Date.now() < sessionReadyDeadline) {
            const probe = await page.request.get(`${apiURL}/projects/`).catch(() => null)
            if (probe && probe.ok()) {
                sessionReady = true
                break
            }
            await page.waitForTimeout(500)
        }
        if (!sessionReady) {
            console.warn(
                "[global-setup] Session probe never returned 2xx within 10s; ephemeral project creation will likely 401",
            )
        }

        const projectsResponse = await page.request.get(`${apiURL}/projects/`)
        let defaultProject: any = null
        let originalDefaultProjectId: string | null = null

        if (projectsResponse.ok()) {
            const projects = await projectsResponse.json()
            defaultProject = projects.find((project: any) => project.is_default_project)
            if (defaultProject) {
                originalDefaultProjectId = defaultProject.project_id
                console.log(
                    `[global-setup] Original default project: ${defaultProject.project_name} (${originalDefaultProjectId})`,
                )
            }
        }

        if (!ephemeralEnabled) {
            console.log(
                "[global-setup] Ephemeral project disabled (AGENTA_TEST_EPHEMERAL_PROJECT=false)",
            )
            writeProjectMetadata(projectMetadataPath, defaultProject, page, null)
            return
        }

        console.log("[global-setup] Creating ephemeral project for test isolation...")

        const projectName = `e2e-${Date.now()}`
        const response = await page.request.post(`${apiURL}/projects/`, {
            data: {name: projectName, make_default: true},
        })

        if (!response.ok()) {
            const text = await response.text()
            console.warn(
                `[global-setup] Failed to create ephemeral project (${response.status()}): ${text}`,
            )
            writeProjectMetadata(projectMetadataPath, defaultProject, page, null)
            return
        }

        const project = await response.json()
        console.log(
            `[global-setup] Created ephemeral project: ${projectName} (${project.project_id})`,
        )

        writeProjectMetadata(projectMetadataPath, project, page, originalDefaultProjectId)
    } catch (error) {
        console.warn("[global-setup] Failed to create ephemeral project, using default:", error)
        try {
            const projectMetadataPath = getProjectMetadataPath()
            writeProjectMetadata(projectMetadataPath, null, page, null)
        } catch (writeError) {
            console.warn("[global-setup] Could not write fallback project metadata:", writeError)
        }
    }
}

function writeProjectMetadata(
    projectMetadataPath: string,
    project: any,
    page: Page,
    originalDefaultProjectId: string | null,
): void {
    let metadata: Record<string, unknown> | null = null

    if (project?.project_id && project?.workspace_id) {
        metadata = {
            project_id: project.project_id,
            project_name: project.project_name ?? null,
            workspace_id: project.workspace_id,
            ...(originalDefaultProjectId !== null
                ? {original_default_project_id: originalDefaultProjectId}
                : {}),
            created_at: new Date().toISOString(),
        }
    } else {
        // Last resort: extract workspace_id and project_id from the current page URL
        const pageUrl = page.url()
        if (pageUrl && pageUrl !== "about:blank") {
            const match = new URL(pageUrl).pathname.match(/\/w\/([^/]+)\/p\/([^/]+)/)
            if (match) {
                metadata = {
                    workspace_id: match[1],
                    project_id: match[2],
                    created_at: new Date().toISOString(),
                }
                console.log("[global-setup] Derived project metadata from page URL")
            }
        }
    }

    if (!metadata) {
        console.warn("[global-setup] No project metadata available to write; skipping")
        return
    }

    mkdirSync(dirname(projectMetadataPath), {recursive: true})
    writeFileSync(projectMetadataPath, JSON.stringify(metadata, null, 2))
    console.log(
        `[global-setup] Wrote project metadata: workspace=${metadata.workspace_id} project=${metadata.project_id}`,
    )
}

export default globalSetup
