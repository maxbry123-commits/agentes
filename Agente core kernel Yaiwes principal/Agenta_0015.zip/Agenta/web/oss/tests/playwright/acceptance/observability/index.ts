import {
    TestCoverage,
    TestcaseType,
    TestPath,
    TestScope,
    TestLensType,
    TestCostType,
    TestLicenseType,
    TestRoleType,
    TestSpeedType,
} from "@agenta/web-tests/playwright/config/testTags"
import {test} from "@agenta/web-tests/tests/fixtures/base.fixture"
import type {ApiHelpers} from "@agenta/web-tests/tests/fixtures/base.fixture/apiHelpers/types"
import {expect, pollLocatorState} from "@agenta/web-tests/utils"

import {expectAuthenticatedSession} from "../utils/auth"
import {createScenarios} from "../utils/scenarios"
import {buildAcceptanceTags} from "../utils/tags"

const scenarios = createScenarios(test)

const smokeTags = buildAcceptanceTags({
    scope: [TestScope.OBSERVABILITY],
    coverage: [TestCoverage.SMOKE, TestCoverage.LIGHT, TestCoverage.FULL],
    path: TestPath.HAPPY,
    lens: TestLensType.FUNCTIONAL,
    cost: TestCostType.Free,
    license: TestLicenseType.OSS,
    role: TestRoleType.Owner,
    caseType: TestcaseType.TYPICAL,
    speed: TestSpeedType.SLOW,
})

const lightSlowTags = buildAcceptanceTags({
    scope: [TestScope.OBSERVABILITY],
    coverage: [TestCoverage.LIGHT],
    path: TestPath.HAPPY,
    lens: TestLensType.FUNCTIONAL,
    cost: TestCostType.Free,
    license: TestLicenseType.OSS,
    role: TestRoleType.Owner,
    caseType: TestcaseType.TYPICAL,
    speed: TestSpeedType.SLOW,
})

const getFirstTraceRow = (page: any) => page.locator('[data-tour="trace-row"]').first()

const clickFirstTraceRow = async (page: any) => {
    const firstDataRow = getFirstTraceRow(page)
    await expect(firstDataRow).toBeVisible({timeout: 10000})
    await firstDataRow.scrollIntoViewIfNeeded()
    await firstDataRow.click({position: {x: 80, y: 12}})
}

/**
 * Runs a completion variant in the Playground to generate a trace, then navigates
 * to the Observability page and waits for the trace row to appear.
 *
 * Traces are indexed asynchronously. The first trace in an ephemeral project can
 * take up to ~150 s to appear. Setup (provider check + app creation + playground run)
 * adds another 60-90 s on top. The function enables auto-refresh (15 s interval)
 * so the page re-fetches automatically, and also performs periodic manual refreshes
 * every 15 s for up to 240 s total while waiting for [data-tour="trace-row"].
 *
 * Tests using this function must set test.setTimeout to at least 420000 (7 min).
 */
const runPlaygroundAndGoToObservability = async (
    page: any,
    apiHelpers: ApiHelpers,
    uiHelpers: any,
    testProviderHelpers: any,
): Promise<void> => {
    // Ensure the test LLM provider (mock) is configured
    await testProviderHelpers.ensureTestProvider()

    const app = await apiHelpers.createApp("completion")
    const appId = app.id
    const basePath = apiHelpers.getProjectScopedBasePath()

    await page.goto(`${basePath}/apps/${appId}/playground`, {waitUntil: "domcontentloaded"})
    await uiHelpers.expectPath(`/apps/${appId}/playground`)
    await expect(page.getByRole("button", {name: "Refine prompt with AI"}).first()).toBeVisible({
        timeout: 30000,
    })

    // Select the mock test model
    await testProviderHelpers.selectTestModel()

    // Fill in the completion input and run.
    // VariableCard renders antd TextArea (<textarea>), not SharedEditor.
    const textbox = page.locator(".agenta-variable-card textarea:placeholder-shown").first()
    await expect(textbox).toBeVisible({timeout: 15000})
    await textbox.click({force: true})
    await textbox.pressSequentially("Say hello", {delay: 50})

    const runButton = page.getByRole("button", {name: "Run", exact: true}).first()
    await expect(runButton).toBeVisible({timeout: 10000})

    const invokeResponsePromise = apiHelpers.waitForApiResponse<Record<string, any>>({
        route: /\/invoke(\?|$)/,
        method: "POST",
        validateStatus: false,
    })
    await runButton.click({force: true})
    await invokeResponsePromise

    // Navigate to Observability
    await page.goto(`${basePath}/observability`, {waitUntil: "domcontentloaded"})

    // Wait for the Refresh button — it is always in the header regardless of trace state.
    const refreshButton = page.getByRole("button", {name: "Refresh data"})
    await expect(refreshButton).toBeVisible({timeout: 15000})

    // Enable auto-refresh (the Switch next to "auto-refresh" label). This makes
    // the page re-fetch traces every 15 s without any manual Refresh clicks.
    const autoRefreshSwitch = page.getByRole("switch").first()
    const isSwitchVisible = await pollLocatorState(() => autoRefreshSwitch.isVisible())
    if (isSwitchVisible) {
        const isChecked = await pollLocatorState(() => autoRefreshSwitch.isChecked())
        if (!isChecked) {
            await autoRefreshSwitch.click()
        }
    }

    // Use the data-tour attribute set by ObservabilityTable on the first trace row.
    // This is more reliable than getByRole("table").last().getByRole("row").nth(1)
    // because the <Table> element is removed from the DOM when EmptyObservability
    // renders (traces.length === 0 && !isLoading), making table-based locators
    // find the wrong element or nothing at all.
    const firstDataRow = getFirstTraceRow(page)

    // Poll every 15 s for up to 240 s. On each iteration we trigger a manual
    // refresh so the page re-fetches even if auto-refresh is slower than expected.
    // Backend trace indexing can take 60-150 s; 240 s gives comfortable headroom.
    const POLL_INTERVAL_MS = 15000
    const MAX_POLLS = 16
    for (let attempt = 0; attempt < MAX_POLLS; attempt++) {
        if (await pollLocatorState(() => firstDataRow.isVisible())) return

        if (await pollLocatorState(() => refreshButton.isVisible())) {
            await refreshButton.click()
        }
        await page.waitForTimeout(POLL_INTERVAL_MS)
    }

    // Final assertion — surfaces a clear failure message if trace never arrived.
    await expect(firstDataRow).toBeVisible({timeout: 15000})
}

const observabilityTests = () => {
    // WEB-ACC-OBS-001
    // Retry-eligible (Mahmoud, see AGENTS.md/session notes): read-only flow (views traces),
    // no state mutation. Trace indexing can lag past the polling window, a stack-timing
    // issue rather than a stale selector, so a retry is safe here. Narrowest scope: this
    // one test only.
    test.describe("View traces (retry-eligible)", () => {
        test.describe.configure({retries: 2})

        // Skipped per release-gate decision (Mahmoud, 2026-08-10): eternity-class runtime
        // (7-minute budget, up to 21 minutes with retries) dominates the CI wall clock.
        test.skip(
            "view traces",
            {tag: smokeTags},
            async ({page, uiHelpers, apiHelpers, testProviderHelpers}) => {
                // 7 minutes: setup (provider + app creation + playground run) ~60-90 s,
                // trace indexing up to ~150 s, polling 16×15 s = 240 s; total ≈ 390 s.
                test.setTimeout(420000)

                await scenarios.given("the user is authenticated", async () => {
                    await expectAuthenticatedSession(page)
                })

                await scenarios.and(
                    "a completion app with a configured test provider exists",
                    async () => {
                        // Run a playground variant to seed a trace, then navigate to observability
                        // and wait for the trace row to appear (with Refresh retries for async indexing).
                        await runPlaygroundAndGoToObservability(
                            page,
                            apiHelpers,
                            uiHelpers,
                            testProviderHelpers,
                        )
                    },
                )

                await scenarios.when("the user opens the traces table", async () => {
                    // runPlaygroundAndGoToObservability already confirmed this row is visible;
                    // click the row itself because virtualized Ant tables do not guarantee
                    // stable cell tags or ARIA roles in the body.
                    await clickFirstTraceRow(page)
                })

                await scenarios.then("the trace detail drawer opens", async () => {
                    // TraceDrawer renders through EnhancedDrawer, a facade over the @agenta/ui
                    // (Radix) Sheet, so the panel is `[data-slot="sheet-content"]`, not an antd
                    // `.ant-drawer-content-wrapper`.
                    const drawer = page.locator('[data-slot="sheet-content"]')
                    await expect(drawer).toBeVisible({timeout: 10000})
                })
            },
        )
    })

    // WEB-ACC-OBS-002
    test(
        "should filter traces by date range and by app",
        {tag: lightSlowTags},
        async ({page, apiHelpers, uiHelpers, testProviderHelpers}) => {
            test.setTimeout(420000)
            await runPlaygroundAndGoToObservability(
                page,
                apiHelpers,
                uiHelpers,
                testProviderHelpers,
            )

            // Apply a date range filter via the Sort popover.
            // The Sort button shows the current range label (default "24 hours").
            const sortButton = page
                .getByRole("button", {name: /24 hours|7 days|1 hour|3 days|30 mins/})
                .first()
            await expect(sortButton).toBeVisible({timeout: 10000})
            await sortButton.click()

            const sevenDaysOption = page.getByText("7 days", {exact: true})
            await expect(sevenDaysOption).toBeVisible({timeout: 5000})
            await sevenDaysOption.click()

            // The Sort button label updates to reflect the new range
            await expect(page.getByRole("button", {name: "7 days"}).first()).toBeVisible({
                timeout: 10000,
            })

            // The virtual table row is still visible (filter applied successfully).
            // getByRole("table") is unreliable with rc-virtual-list; use data-tour attribute.
            await expect(page.locator('[data-tour="trace-row"]').first()).toBeVisible({
                timeout: 10000,
            })
        },
    )

    // WEB-ACC-OBS-003
    test(
        "should filter traces by span name or attribute",
        {tag: lightSlowTags},
        async ({page, apiHelpers, uiHelpers, testProviderHelpers}) => {
            test.setTimeout(420000)
            await runPlaygroundAndGoToObservability(
                page,
                apiHelpers,
                uiHelpers,
                testProviderHelpers,
            )

            // Use the search input to filter by content
            const searchInput = page.getByRole("searchbox").first()
            await expect(searchInput).toBeVisible({timeout: 10000})

            // Typing a search term narrows the table; press Enter to apply
            await searchInput.fill("agenta")
            await searchInput.press("Enter")

            await expect(searchInput).toHaveValue("agenta")

            // The filter may legitimately narrow the table to zero traces depending on
            // what the generated trace contains. Wait for either a filtered row or the
            // filtered empty state so the assertion checks that filtering completed.
            await expect(
                getFirstTraceRow(page).or(page.getByText("No traces found")).first(),
            ).toBeVisible({timeout: 10000})
            await expect(page.getByRole("button", {name: "Refresh data"})).toBeVisible({
                timeout: 10000,
            })

            // Clear the filter to restore the full list
            await searchInput.clear()
            await searchInput.press("Enter")
            await expect(getFirstTraceRow(page)).toBeVisible({timeout: 20000})
        },
    )

    // WEB-ACC-OBS-004
    // Retry-eligible (Mahmoud, see AGENTS.md/session notes): read-only flow (drills into a
    // trace's attributes), no state mutation. Same trace-indexing lag as "view traces", a
    // stack-timing issue rather than a stale selector. Narrowest scope: this one test only.
    test.describe("Should open a span and drill into its attributes (retry-eligible)", () => {
        test.describe.configure({retries: 2})

        test(
            "should open a span and drill into its attributes",
            {tag: lightSlowTags},
            async ({page, apiHelpers, uiHelpers, testProviderHelpers}) => {
                test.setTimeout(420000)
                await runPlaygroundAndGoToObservability(
                    page,
                    apiHelpers,
                    uiHelpers,
                    testProviderHelpers,
                )

                // Click the first data row to open the trace drawer. The virtual table body
                // does not expose stable cell tags, but the row click handler is the behavior
                // users rely on.
                await clickFirstTraceRow(page)

                // TraceDrawer renders through EnhancedDrawer, a facade over the @agenta/ui
                // (Radix) Sheet, so the panel is `[data-slot="sheet-content"]`, not an antd
                // `.ant-drawer-content-wrapper`.
                const drawer = page.locator('[data-slot="sheet-content"]')
                await expect(drawer).toBeVisible({timeout: 10000})

                // The trace tree panel (CustomTreeComponent, not AntD Tree) renders a
                // "Search in tree" input when loaded. Verify the panel mounted with content.
                const treeSearchInput = drawer.getByPlaceholder("Search in tree")
                await expect(treeSearchInput).toBeVisible({timeout: 10000})

                // Each span in the tree renders a square avatar (AvatarTreeContent → antd Avatar
                // shape="square"). At least one confirms the tree has nodes.
                const spanAvatar = drawer.locator(".ant-avatar-square").first()
                await expect(spanAvatar).toBeVisible({timeout: 10000})
            },
        )
    })

    // WEB-ACC-OBS-005
    test(
        "should switch between trace tabs and see filtered rows",
        {tag: lightSlowTags},
        async ({page, apiHelpers, uiHelpers, testProviderHelpers}) => {
            test.setTimeout(420000)
            await runPlaygroundAndGoToObservability(
                page,
                apiHelpers,
                uiHelpers,
                testProviderHelpers,
            )

            // The three trace-type tabs are AntD Radio.Buttons: Root | LLM | All
            const rootTab = page
                .locator(".ant-radio-button-wrapper")
                .filter({hasText: "Root"})
                .first()
            const llmTab = page
                .locator(".ant-radio-button-wrapper")
                .filter({hasText: "LLM"})
                .first()
            const allTab = page
                .locator(".ant-radio-button-wrapper")
                .filter({hasText: "All"})
                .first()

            await expect(rootTab).toBeVisible({timeout: 10000})

            // Switch to LLM
            await llmTab.click()
            await expect(llmTab).toHaveClass(/ant-radio-button-wrapper-checked/, {timeout: 5000})

            // Switch to All
            await allTab.click()
            await expect(allTab).toHaveClass(/ant-radio-button-wrapper-checked/, {timeout: 5000})

            // Switch back to Root
            await rootTab.click()
            await expect(rootTab).toHaveClass(/ant-radio-button-wrapper-checked/, {timeout: 5000})
        },
    )

    // WEB-ACC-OBS-006
    // Skipped per release-gate decision (Mahmoud, 2026-08-10): rotating environment-sensitive
    // failure in CI (gate run 31401605372). Tracked for repair, not deleted.
    test.skip(
        "should create a trace after a Playground run",
        {tag: lightSlowTags},
        async ({page, apiHelpers, uiHelpers, testProviderHelpers}) => {
            test.setTimeout(420000)

            // runPlaygroundAndGoToObservability handles the full flow:
            // run a variant → navigate to observability → wait for trace row (with Refresh).
            await runPlaygroundAndGoToObservability(
                page,
                apiHelpers,
                uiHelpers,
                testProviderHelpers,
            )

            // Verify the trace created by the playground run is visible.
            // The virtual table uses rc-virtual-list, so getByRole("table/row") is
            // unreliable. Use the data-tour attribute set on the first row instead.
            await expect(page.locator('[data-tour="trace-row"]')).toBeVisible({timeout: 10000})
        },
    )
}

export default observabilityTests
