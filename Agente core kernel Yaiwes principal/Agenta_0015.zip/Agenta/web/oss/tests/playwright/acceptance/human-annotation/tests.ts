import {randomUUID} from "crypto"

import {test as baseTest} from "@agenta/web-tests/tests/fixtures/base.fixture"
import {getProjectScopedBasePath} from "@agenta/web-tests/tests/fixtures/base.fixture/apiHelpers"
import {expect, pollLocatorState} from "@agenta/web-tests/utils"
import type {EvaluationRunForKindDetection} from "@agenta/web-tests/utils/evaluationKind"
import type {Locator, Page} from "@playwright/test"

import type {HumanEvaluationConfig, HumanEvaluationFixtures} from "./assets/types"

interface EvaluationRunsResponse {
    runs: EvaluationRunForKindDetection[]
    count: number
}

interface EvaluationRunStep {
    key?: string
    step_key?: string
    type?: string
    kind?: string
    references?: Record<string, unknown>
}

interface EvaluationRunPayload {
    id?: string
    data?: {
        steps?: EvaluationRunStep[]
    }
}

interface EvaluationRunResponse {
    runs?: (EvaluationRunPayload & {run?: EvaluationRunPayload})[]
}

interface EvaluationResultsResponse {
    results?: {
        id?: string
        step_key?: string
        stepKey?: string
    }[]
    steps?: {
        id?: string
        step_key?: string
        stepKey?: string
    }[]
}

const DEFAULT_HUMAN_EVALUATOR_METRIC_NAME = "isTestWorking"
const DEFAULT_HUMAN_ANNOTATION_VALUE_LABEL = "True"

const HUMAN_EVALUATION_TAB_LABEL = "Human Evals"
const HUMAN_EVALUATION_MODAL_TITLE = "New Human Evaluation"
const HUMAN_EVALUATION_SUBMIT_BUTTON_LABEL = "Start Evaluation"
const HUMAN_RESULTS_TAB_LABELS = ["Overview", "Scenarios", "Configuration", "Annotate"] as const
const EVALUATION_RESULTS_TOUR_ID = "evaluation-results-intro"
const WIDGET_CLOSED_TOUR_ID = "onboarding-widget-closed-tour"
const ONBOARDING_ACTIVE_USER_ID_KEY = "agenta:onboarding:active-user-id"
const ONBOARDING_IS_NEW_USER_KEY_SUFFIX = "is-new-user"
const ONBOARDING_WIDGET_STATUS_KEY_SUFFIX = "widget-status"
const ONBOARDING_WIDGET_UI_KEY_SUFFIX = "widget-ui"
const ONBOARDING_WIDGET_SEEN_CLOSE_TOOLTIP_KEY_SUFFIX = "widget-seen-close-tooltip"
const ONBOARDING_WIDGET_DISMISSED_STATUS = "dismissed"

const HUMAN_EVALUATION_CREATE_BUTTON_LABELS = [
    /Create Evaluation/i,
    /New evaluation/i,
    /Start new evaluation/i,
] as const

const getHumanEvaluationsPath = (page: Page, appId: string) =>
    `${getProjectScopedBasePath(page)}/apps/${appId}/evaluations`

const getHumanEvaluationsUrl = (page: Page, appId: string) =>
    `${getHumanEvaluationsPath(page, appId)}?kind=human`

const getHumanResultsPathPrefix = (page: Page, appId: string) =>
    `${getHumanEvaluationsPath(page, appId)}/results/`

const getApiURL = (page: Page): string => {
    if (process.env.AGENTA_API_URL) {
        return process.env.AGENTA_API_URL
    }

    const currentUrl = page.url() || process.env.AGENTA_WEB_URL || "http://localhost:3000"
    const parsed = new URL(currentUrl)
    return `${parsed.origin}/api`
}

const getProjectId = (page: Page): string => {
    const currentUrl = page.url()
    const configuredUrl = process.env.AGENTA_WEB_URL

    for (const url of [currentUrl, configuredUrl].filter(Boolean) as string[]) {
        const match = new URL(url).pathname.match(/\/p\/([^/]+)/)
        if (match?.[1]) {
            return match[1]
        }
    }

    throw new Error(`Could not derive project ID from current URL: ${page.url()}`)
}

const getHumanResultsContext = (page: Page) => {
    const url = new URL(page.url())
    const runId = url.pathname.match(/\/evaluations\/results\/([^/]+)/)?.[1]
    const scenarioId = url.searchParams.get("scenarioId")

    if (!runId || !scenarioId) {
        throw new Error(`Could not derive human results context from URL: ${url.toString()}`)
    }

    return {runId, scenarioId}
}

const getStepKey = (step: EvaluationRunStep) => step.key ?? step.step_key ?? ""

const seedHumanInvocationResult = async (
    page: Page,
    overrides?: {runId?: string; scenarioId?: string},
) => {
    let contextRunId: string | undefined
    let contextScenarioId: string | undefined
    try {
        const ctx = getHumanResultsContext(page)
        contextRunId = ctx.runId
        contextScenarioId = ctx.scenarioId
    } catch {
        // URL doesn't have scenario context — overrides must supply it
    }
    const runId = overrides?.runId ?? contextRunId
    const scenarioId = overrides?.scenarioId ?? contextScenarioId
    if (!runId || !scenarioId) {
        throw new Error(
            `seedHumanInvocationResult: could not resolve runId or scenarioId from URL or overrides`,
        )
    }
    const projectId = getProjectId(page)
    const apiURL = getApiURL(page)

    const runResponse = await page.request.post(
        `${apiURL}/evaluations/runs/query?project_id=${projectId}`,
        {
            data: {
                run: {
                    ids: [runId],
                },
            },
        },
    )
    expect(runResponse.ok()).toBe(true)

    const runData = (await runResponse.json()) as EvaluationRunResponse
    const runEntry = runData.runs?.[0]
    const run = runEntry?.run ?? runEntry
    const invocationStep = run?.data?.steps?.find((step) => {
        const stepType = (step.type ?? step.kind ?? "").toLowerCase()
        return stepType === "invocation"
    })
    const stepKey = invocationStep ? getStepKey(invocationStep) : ""

    if (!stepKey) {
        throw new Error(`Could not find invocation step for human evaluation run ${runId}`)
    }

    const resultsQueryResponse = await page.request.post(
        `${apiURL}/evaluations/results/query?project_id=${projectId}`,
        {
            data: {
                result: {
                    run_id: runId,
                    run_ids: [runId],
                    scenario_ids: [scenarioId],
                },
                windowing: {},
            },
        },
    )
    expect(resultsQueryResponse.ok()).toBe(true)

    const resultsData = (await resultsQueryResponse.json()) as EvaluationResultsResponse
    const existingResults = resultsData.results ?? resultsData.steps ?? []
    const existingResult = existingResults.find(
        (result) => (result.step_key ?? result.stepKey) === stepKey,
    )
    const seededResult = {
        status: "success",
        trace_id: randomUUID(),
    }

    if (existingResult?.id) {
        const updateResponse = await page.request.patch(
            `${apiURL}/evaluations/results/?project_id=${projectId}`,
            {
                data: {
                    results: [
                        {
                            id: existingResult.id,
                            ...seededResult,
                        },
                    ],
                },
            },
        )
        expect(updateResponse.ok()).toBe(true)
        return
    }

    const createResponse = await page.request.post(
        `${apiURL}/evaluations/results/?project_id=${projectId}`,
        {
            data: {
                results: [
                    {
                        run_id: runId,
                        scenario_id: scenarioId,
                        step_key: stepKey,
                        ...seededResult,
                    },
                ],
            },
        },
    )
    expect(createResponse.ok()).toBe(true)
}

const getHumanAppIdFromEvaluationsPage = (page: Page) => {
    const match = new URL(page.url()).pathname.match(/\/apps\/([^/]+)\/evaluations\/?$/)
    expect(match).toBeTruthy()
    return match?.[1] as string
}

const typeIntoLocator = async (locator: Locator, text: string) => {
    await expect(locator).toBeVisible()
    await locator.click()
    await locator.fill("")
    await locator.pressSequentially(text, {delay: 20})
}

const waitForEvaluationRuns = async (page: Page, appId: string) => {
    const response = await page.waitForResponse((response) => {
        if (
            !response.url().includes("/api/evaluations/runs/query") ||
            response.request().method() !== "POST"
        ) {
            return false
        }

        return new URL(response.url()).searchParams.get("app_id") === appId
    })

    expect(response.ok()).toBe(true)

    try {
        return (await response.json()) as EvaluationRunsResponse
    } catch (error) {
        console.warn("[Human Evaluation E2E] Failed to parse evaluation runs response:", error)
        return {runs: [], count: 0}
    }
}

const getHumanEvaluationRuns = (evaluationRuns: EvaluationRunsResponse) => {
    // The page navigates to ?kind=human so the API response is already filtered to human runs
    return Array.isArray(evaluationRuns.runs) ? evaluationRuns.runs : []
}

const getVisibleButtonByLabels = async (page: Page, labels: readonly (string | RegExp)[]) => {
    for (const label of labels) {
        const buttons = page.getByRole("button", {name: label})
        const buttonCount = await buttons.count()

        for (let index = 0; index < buttonCount; index += 1) {
            const button = buttons.nth(index)
            if (await pollLocatorState(() => button.isVisible())) {
                return button
            }
        }
    }

    return null
}

const getHumanEvaluationCreateButton = async (page: Page, timeout = 10000) => {
    // Cache the button inside the poll to avoid a TOCTOU race where the poll
    // succeeds but a subsequent call finds the button gone (e.g. mid re-render).
    let foundButton: Awaited<ReturnType<typeof getVisibleButtonByLabels>> = null

    await expect
        .poll(
            async () => {
                foundButton = await getVisibleButtonByLabels(
                    page,
                    HUMAN_EVALUATION_CREATE_BUTTON_LABELS,
                )
                return Boolean(foundButton)
            },
            {timeout},
        )
        .toBe(true)

    if (foundButton) {
        return foundButton
    }

    throw new Error("Could not find a human evaluation create button.")
}

const disableEvaluationResultsOnboardingState = async (page: Page) => {
    await page.evaluate(
        ({
            activeUserIdKey,
            evaluationResultsTourId,
            widgetClosedTourId,
            isNewUserKeySuffix,
            widgetStatusKeySuffix,
            widgetUiKeySuffix,
            widgetSeenCloseTooltipKeySuffix,
            dismissedWidgetStatus,
        }: {
            activeUserIdKey: string
            evaluationResultsTourId: string
            widgetClosedTourId: string
            isNewUserKeySuffix: string
            widgetStatusKeySuffix: string
            widgetUiKeySuffix: string
            widgetSeenCloseTooltipKeySuffix: string
            dismissedWidgetStatus: string
        }) => {
            const userId = window.localStorage.getItem(activeUserIdKey)
            if (!userId) {
                return
            }

            const seenToursKey = `agenta:onboarding:${userId}:seen-tours`
            const isNewUserKey = `agenta:onboarding:${userId}:${isNewUserKeySuffix}`
            const widgetStatusKey = `agenta:onboarding:${userId}:${widgetStatusKeySuffix}`
            const widgetUiKey = `agenta:onboarding:${userId}:${widgetUiKeySuffix}`
            const widgetSeenCloseTooltipKey = `agenta:onboarding:${userId}:${widgetSeenCloseTooltipKeySuffix}`

            const currentSeenTours = window.localStorage.getItem(seenToursKey)
            let parsedSeenTours: Record<string, number | boolean> = {}

            if (currentSeenTours) {
                try {
                    parsedSeenTours = JSON.parse(currentSeenTours) as Record<
                        string,
                        number | boolean
                    >
                } catch {
                    parsedSeenTours = {}
                }
            }

            window.localStorage.setItem(
                seenToursKey,
                JSON.stringify({
                    ...parsedSeenTours,
                    [evaluationResultsTourId]: Date.now(),
                    [widgetClosedTourId]: Date.now(),
                }),
            )
            window.localStorage.setItem(isNewUserKey, JSON.stringify(false))
            window.localStorage.setItem(widgetStatusKey, JSON.stringify(dismissedWidgetStatus))
            window.localStorage.setItem(
                widgetUiKey,
                JSON.stringify({
                    isOpen: false,
                    isMinimized: false,
                }),
            )
            window.localStorage.setItem(widgetSeenCloseTooltipKey, JSON.stringify(true))
        },
        {
            activeUserIdKey: ONBOARDING_ACTIVE_USER_ID_KEY,
            evaluationResultsTourId: EVALUATION_RESULTS_TOUR_ID,
            widgetClosedTourId: WIDGET_CLOSED_TOUR_ID,
            isNewUserKeySuffix: ONBOARDING_IS_NEW_USER_KEY_SUFFIX,
            widgetStatusKeySuffix: ONBOARDING_WIDGET_STATUS_KEY_SUFFIX,
            widgetUiKeySuffix: ONBOARDING_WIDGET_UI_KEY_SUFFIX,
            widgetSeenCloseTooltipKeySuffix: ONBOARDING_WIDGET_SEEN_CLOSE_TOOLTIP_KEY_SUFFIX,
            dismissedWidgetStatus: ONBOARDING_WIDGET_DISMISSED_STATUS,
        },
    )
}

const dismissEvaluationResultsOnboarding = async (page: Page) => {
    await disableEvaluationResultsOnboardingState(page)

    for (let attempt = 0; attempt < 3; attempt += 1) {
        const skipButton = page.getByRole("button", {name: "Skip"}).last()
        if (await pollLocatorState(() => skipButton.isVisible())) {
            await skipButton.click()
            await expect(skipButton).toBeHidden({timeout: 10000})
        }

        const widgetClosedTourButton = page.getByRole("button", {name: "Got it!"}).last()
        if (await pollLocatorState(() => widgetClosedTourButton.isVisible())) {
            await widgetClosedTourButton.click()
            await expect(widgetClosedTourButton).toBeHidden({timeout: 10000})
        }

        const onboardingWidget = page
            .locator("section")
            .filter({hasText: "Get started guide"})
            .first()
        if (await pollLocatorState(() => onboardingWidget.isVisible())) {
            const widgetCloseButton = onboardingWidget.locator("button.ant-btn").last()
            if (await pollLocatorState(() => widgetCloseButton.isVisible())) {
                await widgetCloseButton.click({force: true})
                await page.waitForTimeout(400)
            }
        }

        const hasSkipButton = await pollLocatorState(() => skipButton.isVisible())
        const hasWidgetClosedTourButton = await pollLocatorState(() =>
            widgetClosedTourButton.isVisible(),
        )
        const hasOnboardingWidget = await pollLocatorState(() => onboardingWidget.isVisible())
        if (!hasSkipButton && !hasWidgetClosedTourButton && !hasOnboardingWidget) {
            break
        }
    }
}

const goToHumanEvaluations = async (page: Page, appId: string) => {
    const evaluationRunsPromise = waitForEvaluationRuns(page, appId)

    await page.goto(getHumanEvaluationsUrl(page, appId), {waitUntil: "domcontentloaded"})

    await expect.poll(() => new URL(page.url()).pathname).toBe(getHumanEvaluationsPath(page, appId))
    await expect.poll(() => new URL(page.url()).searchParams.get("kind")).toBe("human")
    await expect(page.getByTitle("Evaluations").first()).toBeVisible({timeout: 10000})

    const evaluationRuns = await evaluationRunsPromise

    expect(Array.isArray(evaluationRuns.runs)).toBe(true)

    return getHumanEvaluationRuns(evaluationRuns)
}

const navigateToHumanRunResults = async (page: Page, appId: string, runId: string) => {
    const url = `${getHumanResultsPathPrefix(page, appId)}${runId}?type=human`
    await page.goto(url, {waitUntil: "domcontentloaded"})
    await expect
        .poll(() => new URL(page.url()).pathname)
        .toContain(getHumanResultsPathPrefix(page, appId))
}

const waitForHumanResultsPage = async (page: Page, appId: string) => {
    await expect
        .poll(() => new URL(page.url()).pathname)
        .toContain(getHumanResultsPathPrefix(page, appId))
    await expect.poll(() => new URL(page.url()).searchParams.get("type")).toBe("human")
    await expect.poll(() => Boolean(new URL(page.url()).searchParams.get("scenarioId"))).toBe(true)

    for (const tabLabel of HUMAN_RESULTS_TAB_LABELS) {
        await expect(page.getByRole("tab", {name: tabLabel}).first()).toBeVisible()
    }

    await dismissEvaluationResultsOnboarding(page)
}

const ensureHumanEvaluationsContext = async (page: Page) => {
    await expect.poll(() => new URL(page.url()).searchParams.get("kind")).toBe("human")

    const humanTab = page.getByRole("tab", {name: HUMAN_EVALUATION_TAB_LABEL}).first()
    await expect(humanTab).toBeVisible()

    if ((await humanTab.getAttribute("aria-selected")) !== "true") {
        await humanTab.click()
    }

    await expect(humanTab).toHaveAttribute("aria-selected", "true")
}

const openHumanAnnotateView = async (page: Page) => {
    await dismissEvaluationResultsOnboarding(page)

    const annotateTab = page.getByRole("tab", {name: "Annotate"}).first()
    await expect(annotateTab).toBeVisible()

    if ((await annotateTab.getAttribute("aria-selected")) !== "true") {
        await annotateTab.click()

        const switchedToAnnotate = await pollLocatorState(() =>
            annotateTab
                .getAttribute("aria-selected", {timeout: 5000})
                .then((value) => value === "true"),
        )

        if (!switchedToAnnotate) {
            const annotateUrl = new URL(page.url())
            annotateUrl.searchParams.set("view", "focus")
            await page.goto(annotateUrl.toString(), {waitUntil: "domcontentloaded"})
        }
    }

    await expect(annotateTab).toHaveAttribute("aria-selected", "true")
    await expect(page.locator("#focus-section-inputs")).toBeVisible()
    await expect(page.locator("#focus-section-outputs")).toBeVisible()
    await expect(page.locator("#focus-section-annotations")).toBeVisible()
}

/**
 * The "New Human Evaluation" modal, scoped by its title.
 *
 * Callers assert this has closed. Do not use a bare `getByRole("dialog")` for that:
 * drawers are Radix `Sheet`s and also carry `role="dialog"`, so an unscoped count
 * fails whenever any drawer happens to be open.
 */
const humanEvaluationModal = (page: Page) =>
    page.getByRole("dialog").filter({hasText: HUMAN_EVALUATION_MODAL_TITLE})

const openHumanEvaluationModal = async (page: Page) => {
    await ensureHumanEvaluationsContext(page)
    await (await getHumanEvaluationCreateButton(page, 60000)).click()

    // Matched by role: this modal renders through `EnhancedModal`, a facade over the
    // @agenta/ui (Radix) `Dialog`, so there is no `.ant-modal`.
    const modal = page.getByRole("dialog").first()
    await expect(modal).toBeVisible()
    await expect(modal.getByText(HUMAN_EVALUATION_MODAL_TITLE).first()).toBeVisible()
    await expect(
        modal.getByRole("button", {name: HUMAN_EVALUATION_SUBMIT_BUTTON_LABEL}).last(),
    ).toBeVisible()

    return modal
}

const goToHumanEvaluationStep = async (modal: Locator, step: string) => {
    const stepTab = modal.getByRole("tab", {name: step})
    await expect(stepTab).toBeVisible()
    await stepTab.click()
    await expect(stepTab).toHaveAttribute("aria-selected", "true")
    await expect(modal.locator(".ant-tabs-tabpane-active").last()).toBeVisible()
}

const getActiveHumanEvaluationPane = (modal: Locator) =>
    modal.locator(".ant-tabs-tabpane-active").last()

const selectHumanEvaluationModalTableInput = async ({
    modal,
    rowText,
    inputType: _inputType,
}: {
    modal: Locator
    rowText?: string | RegExp
    inputType: "checkbox" | "radio"
}) => {
    const activePane = getActiveHumanEvaluationPane(modal)
    const searchInput = activePane.locator('input[placeholder="Search"]').first()
    const inputSelector =
        'input[type="checkbox"], input[type="radio"], .ant-checkbox-input, .ant-radio-input'
    const controlSelector =
        '.ant-checkbox, .ant-checkbox-wrapper, .ant-radio, .ant-radio-wrapper, [role="checkbox"], [role="radio"]'
    const selectedTags = modal.locator(".ant-tabs-tab .ant-tag")

    if (typeof rowText === "string" && (await pollLocatorState(() => searchInput.isVisible()))) {
        await typeIntoLocator(searchInput, rowText)
        await expect(searchInput).toHaveValue(rowText)
        await expect
            .poll(
                async () =>
                    await activePane.locator("[data-row-key]").filter({hasText: rowText}).count(),
                {timeout: 30000},
            )
            .toBeGreaterThan(0)
    }

    const targetRow = rowText
        ? activePane.locator("[data-row-key]").filter({hasText: rowText}).first()
        : activePane.locator("[data-row-key]").first()
    await expect(targetRow).toBeVisible({timeout: 30000})
    const targetRowKey = await targetRow.getAttribute("data-row-key")
    const stableSelectionInput = targetRowKey
        ? modal.locator(`[data-row-key="${targetRowKey}"]`).locator(inputSelector).first()
        : targetRow.locator(inputSelector).first()
    const stableRow = targetRowKey
        ? modal.locator(`[data-row-key="${targetRowKey}"]`).first()
        : targetRow
    await expect(stableRow).toBeVisible({timeout: 30000})

    const isSelected = async () => {
        const rowClassName = await stableRow.getAttribute("class").catch(() => null)
        if (rowClassName?.includes("ant-table-row-selected")) {
            return true
        }

        const ariaSelected = await stableRow.getAttribute("aria-selected").catch(() => null)
        if (ariaSelected === "true") {
            return true
        }

        if ((await stableSelectionInput.count().catch(() => 0)) > 0) {
            return await pollLocatorState(() => stableSelectionInput.isChecked())
        }

        if (typeof rowText === "string") {
            return (await selectedTags.filter({hasText: rowText}).count()) > 0
        }

        return false
    }

    if (!(await isSelected())) {
        const selectionControl = stableRow.locator(controlSelector).first()
        if ((await selectionControl.count().catch(() => 0)) > 0) {
            await selectionControl.click({force: true})
        } else {
            await stableRow.click({force: true})
        }
    }

    if (_inputType === "radio" && typeof rowText === "string") {
        await expect
            .poll(
                async () => {
                    if (await isSelected()) {
                        return true
                    }

                    return (await selectedTags.filter({hasText: rowText}).count()) > 0
                },
                {timeout: 30000},
            )
            .toBe(true)
        return
    }

    await expect.poll(isSelected, {timeout: 30000}).toBe(true)
}

const waitForHumanEvaluatorPane = async (modal: Locator) => {
    const activePane = getActiveHumanEvaluationPane(modal)
    const searchInput = activePane.locator('input[placeholder="Search"]').first()

    await expect(searchInput).toBeVisible({timeout: 30000})
    await expect
        .poll(
            async () => {
                const rowCount = await activePane.locator("[data-row-key]").count()
                if (rowCount > 0) return true

                const hasEmptyState = await pollLocatorState(() =>
                    activePane.getByText("No evaluators yet").first().isVisible(),
                )
                const hasNoSearchResults = await pollLocatorState(() =>
                    activePane.getByText("No evaluators match your search").first().isVisible(),
                )

                return hasEmptyState || hasNoSearchResults
            },
            {timeout: 30000},
        )
        .toBe(true)

    return activePane
}

const ensureSingleHumanEvaluatorSelection = async ({
    modal,
    evaluatorName,
}: {
    modal: Locator
    evaluatorName?: string
}) => {
    const activePane = await waitForHumanEvaluatorPane(modal)

    if (!evaluatorName) {
        const firstEvaluatorRow = activePane.locator("[data-row-key]").first()
        const hasSelectedEvaluator = async () => {
            // evaluateAll runs over every matched row regardless of count, so it can never
            // throw a strict-mode violation — pollLocatorState would add nothing here.
            const selectedRows = await activePane
                .locator("[data-row-key]")
                .evaluateAll((rows) =>
                    rows.some(
                        (row) =>
                            row.className.includes("ant-table-row-selected") ||
                            row.getAttribute("aria-selected") === "true",
                    ),
                )
                .catch(() => false)

            if (selectedRows) {
                return true
            }

            return (
                (await activePane
                    .locator('input[type="checkbox"]:checked, input[type="radio"]:checked')
                    .count()) > 0
            )
        }

        await expect(firstEvaluatorRow).toBeVisible({timeout: 30000})

        await expect
            .poll(
                async () => {
                    if (await hasSelectedEvaluator()) return true

                    const checkboxes = activePane.getByRole("checkbox")
                    if ((await checkboxes.count()) > 1) {
                        await checkboxes
                            .nth(1)
                            .click({force: true})
                            .catch(() => null)
                    } else {
                        await firstEvaluatorRow.click({force: true}).catch(() => null)
                    }

                    return hasSelectedEvaluator()
                },
                {timeout: 30000},
            )
            .toBe(true)
        return
    }

    await selectHumanEvaluationModalTableInput({
        modal,
        rowText: evaluatorName,
        inputType: "checkbox",
    })
}

const waitForHumanAnnotationForm = async ({
    page,
    annotationsCard,
    metricLabel,
    timeout = 90000,
}: {
    page: Page
    annotationsCard: Locator
    metricLabel: string | RegExp
    timeout?: number
}) => {
    const metricField = annotationsCard
        .locator(".playground-property-control")
        .filter({hasText: metricLabel})
        .first()
    const runButton = annotationsCard.getByRole("button", {name: /^Run$/}).first()
    const outputRequiredMessage = annotationsCard
        .getByText(
            /Generate output to annotate|Generating output|Run the invocation to generate output/i,
        )
        .first()
    // Separate locator for the auto-run "currently generating" state. We must NOT
    // interrupt with a reload while auto-run is actively calling the LLM — doing so
    // restarts the cycle and causes a 90 s timeout. Wait it out instead.
    const isGeneratingMessage = annotationsCard.getByText(/Generating output/i).first()
    let seededInvocationOutput = false

    await expect
        .poll(
            async () => {
                const overlayVisible = await pollLocatorState(() =>
                    outputRequiredMessage.isVisible(),
                )
                if ((await pollLocatorState(() => metricField.isVisible())) && !overlayVisible) {
                    return true
                }

                // Auto-run is actively generating — wait for it to finish so the component
                // can invalidate the steps query and reveal the annotation form naturally.
                // Interrupting with a reload would restart the auto-run cycle.
                if (await pollLocatorState(() => isGeneratingMessage.isVisible())) {
                    return false
                }

                // Seed the invocation result and re-navigate to the annotate view so that
                // TanStack Query fetches fresh data with the seeded success status.
                // Use an explicit URL with view=focus so the annotate tab is always active.
                // page.reload() is avoided here because it can re-trigger auto-run and loop.
                // Only seed once — on subsequent iterations just wait for the form to appear.
                if (!seededInvocationOutput && overlayVisible) {
                    seededInvocationOutput = true
                    try {
                        await seedHumanInvocationResult(page)
                    } catch {
                        // seed failed transiently — wait for natural form appearance
                    }
                    const annotateUrl = new URL(page.url())
                    annotateUrl.searchParams.set("view", "focus")
                    await page.goto(annotateUrl.toString(), {waitUntil: "domcontentloaded"})
                    await dismissEvaluationResultsOnboarding(page)
                    return false
                }

                if (overlayVisible) {
                    return false
                }

                await dismissEvaluationResultsOnboarding(page)
                return await pollLocatorState(() => metricField.isVisible())
            },
            {timeout},
        )
        .toBe(true)

    return metricField
}

const testWithHumanFixtures = baseTest.extend<HumanEvaluationFixtures>({
    navigateToHumanEvaluation: async ({page}, use) => {
        await use(async (appId: string) => {
            await page.goto(getHumanEvaluationsUrl(page, appId), {waitUntil: "domcontentloaded"})
            await expect
                .poll(() => new URL(page.url()).pathname)
                .toBe(getHumanEvaluationsPath(page, appId))
            await expect.poll(() => new URL(page.url()).searchParams.get("kind")).toBe("human")
            await expect(page.getByTitle("Evaluations").first()).toBeVisible({timeout: 30000})

            await ensureHumanEvaluationsContext(page)
            await getHumanEvaluationCreateButton(page, 60000)
        })
    },

    createHumanEvaluationRun: async ({page}, use) => {
        await use(async (config: HumanEvaluationConfig) => {
            const modal = await openHumanEvaluationModal(page)
            const appId = getHumanAppIdFromEvaluationsPage(page)

            await typeIntoLocator(
                modal.locator('input[placeholder="Enter a name"]').first(),
                config.name,
            )

            await goToHumanEvaluationStep(modal, "Revision")
            await selectHumanEvaluationModalTableInput({
                modal,
                rowText: config.variants,
                inputType: "radio",
            })

            await goToHumanEvaluationStep(modal, "Test set")
            await selectHumanEvaluationModalTableInput({
                modal,
                rowText: config.testset,
                inputType: "radio",
            })

            await goToHumanEvaluationStep(modal, "Evaluators")

            let evaluatorName: string | null = null
            const evaluatorMetricName =
                config.evaluatorMetricName ?? DEFAULT_HUMAN_EVALUATOR_METRIC_NAME
            const evaluatorPane = await waitForHumanEvaluatorPane(modal)
            const hasExistingEvaluator = (await evaluatorPane.locator("[data-row-key]").count()) > 0

            if (!config.skipEvaluatorCreation || !hasExistingEvaluator) {
                evaluatorName = `evaluator-${Date.now()}`

                const createEvaluatorButton = modal
                    .getByRole("button", {
                        name: /Create (new|your first) evaluator/i,
                    })
                    .first()
                await expect(createEvaluatorButton).toBeVisible()
                await createEvaluatorButton.click()

                // Matched by role: this drawer renders through `EnhancedDrawer`, a facade
                // over the @agenta/ui (Radix) `Sheet`.
                const evaluatorDrawer = page
                    .getByRole("dialog")
                    .filter({
                        has: page.locator('input[placeholder="Enter a unique slug"]'),
                    })
                    .last()
                const evaluatorNameInput = evaluatorDrawer
                    .locator('input[placeholder="Enter a name"]')
                    .first()
                const evaluatorSlugInput = evaluatorDrawer
                    .locator('input[placeholder="Enter a unique slug"]')
                    .first()
                const feedbackNameInput = evaluatorDrawer
                    .locator('input[placeholder="Enter a feedback name"]')
                    .first()

                await expect(evaluatorDrawer).toBeVisible()
                await expect(evaluatorSlugInput).toBeVisible()

                await typeIntoLocator(evaluatorNameInput, evaluatorName)
                await expect(evaluatorSlugInput).toHaveValue(evaluatorName)
                await typeIntoLocator(feedbackNameInput, evaluatorMetricName)

                await evaluatorDrawer.locator(".ant-select").last().click()
                const dropdownOption = page.getByText("Boolean (True/False)", {exact: true}).last()
                await expect(dropdownOption).toBeVisible()
                await dropdownOption.click()

                const createEvaluatorSubmitButton = evaluatorDrawer
                    .getByRole("button", {name: "Create"})
                    .last()
                await expect(createEvaluatorSubmitButton).toBeEnabled()
                await createEvaluatorSubmitButton.click()

                await expect(evaluatorSlugInput).toHaveCount(0)
                await expect(
                    page.getByRole("status").getByText("Evaluator created successfully"),
                ).toBeVisible()
            }

            await ensureSingleHumanEvaluatorSelection({
                modal,
                evaluatorName: evaluatorName ?? undefined,
            })

            await disableEvaluationResultsOnboardingState(page)

            const createButton = modal
                .getByRole("button", {name: HUMAN_EVALUATION_SUBMIT_BUTTON_LABEL})
                .last()
            await expect(createButton).toBeEnabled()
            await createButton.click()

            await waitForHumanResultsPage(page, appId)
        })
    },

    annotateCurrentHumanScenario: async ({page}, use) => {
        await use(
            async ({
                metricLabel = DEFAULT_HUMAN_EVALUATOR_METRIC_NAME,
                valueLabel = DEFAULT_HUMAN_ANNOTATION_VALUE_LABEL,
            }: {
                metricLabel?: string | RegExp
                valueLabel?: string | RegExp
            } = {}) => {
                await openHumanAnnotateView(page)
                await dismissEvaluationResultsOnboarding(page)

                const annotationsCard = page.locator("#focus-section-annotations")
                const metricField = await waitForHumanAnnotationForm({
                    page,
                    annotationsCard,
                    metricLabel,
                })

                await dismissEvaluationResultsOnboarding(page)

                const booleanOption = metricField.getByRole("radio", {name: valueLabel}).first()
                const booleanOptionWrapper = metricField
                    .locator(".ant-radio-button-wrapper")
                    .filter({hasText: valueLabel})
                    .first()
                await expect(booleanOption).toBeAttached()
                await expect(booleanOptionWrapper).toBeVisible()
                await booleanOptionWrapper.click({force: true})
                await expect(booleanOption).toBeChecked()

                const annotateButton = annotationsCard
                    .getByRole("button", {name: "Annotate"})
                    .first()
                await expect(annotateButton).toBeEnabled()
                await annotateButton.click()

                await expect(
                    page.getByRole("status").getByText("Annotations saved successfully"),
                ).toBeVisible()

                await expect(
                    page
                        .locator(".ant-tag")
                        .filter({hasText: /^success$/i})
                        .first(),
                ).toBeVisible({
                    timeout: 60000,
                })
            },
        )
    },
})

export {
    testWithHumanFixtures as test,
    expect,
    humanEvaluationModal,
    openHumanEvaluationModal,
    goToHumanEvaluationStep,
    selectHumanEvaluationModalTableInput,
    goToHumanEvaluations,
    navigateToHumanRunResults,
    seedHumanInvocationResult,
}
