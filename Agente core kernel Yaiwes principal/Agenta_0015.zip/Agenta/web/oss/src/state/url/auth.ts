import {atom, getDefaultStore} from "jotai"
import Router from "next/router"
import {signOut} from "supertokens-auth-react/recipe/session"

import {
    appIdentifiersAtom,
    appStateSnapshotAtom,
    navigationRequestAtom,
    requestNavigationAtom,
} from "@/oss/state/appState"
import {orgsAtom, resolvePreferredWorkspaceId} from "@/oss/state/org"
import {profileQueryAtom, userAtom} from "@/oss/state/profile/selectors/user"
import {sessionExistsAtom, sessionLoadingAtom} from "@/oss/state/session"
import {urlAtom} from "@/oss/state/url"

import {captureTemplateFromUrl} from "./template"

const isBrowser = typeof window !== "undefined"

export interface InvitePayload {
    token: string
    email?: string
    organization_id?: string
    workspace_id?: string
    project_id?: string
    survey?: string
}

const INVITE_STORAGE_KEY = "invite"
const POST_SIGNUP_PENDING_KEY = "postSignupPending"
const POST_SIGNUP_TTL_MS = 2 * 60 * 1000

const baseProtectedRouteReadyAtom = atom(false)
// Sticky once-ready flag so mid-session auth re-resolution flips don't unmount the page (T1.3)
const protectedRouteReadyLatchAtom = atom(false)
export const protectedRouteReadyAtom = atom(
    (get) => get(baseProtectedRouteReadyAtom),
    (_get, set, next: boolean) => {
        set(baseProtectedRouteReadyAtom, next)
        if (next) set(protectedRouteReadyLatchAtom, true)
    },
)
// Gate ProtectedRoute reads: raw readiness, or a still-live session that was ready before
export const protectedRouteLatchedReadyAtom = atom(
    (get) =>
        get(baseProtectedRouteReadyAtom) ||
        (get(protectedRouteReadyLatchAtom) && get(sessionExistsAtom)),
)
export const activeInviteAtom = atom<InvitePayload | null>(null)

export const parseInviteFromUrl = (url: URL): InvitePayload | null => {
    const token = url.searchParams.get("token")?.trim()
    if (!token) return null

    const invite: InvitePayload = {token}
    const fields: (keyof InvitePayload)[] = [
        "email",
        "organization_id",
        "workspace_id",
        "project_id",
        "survey",
    ]

    fields.forEach((field) => {
        const value = url.searchParams.get(field)?.trim()
        if (value) {
            invite[field] = field === "email" ? value.toLowerCase() : value
        }
    })

    return invite
}

export const readInviteFromStorage = (): InvitePayload | null => {
    if (!isBrowser) return null
    try {
        const raw = window.localStorage.getItem(INVITE_STORAGE_KEY)
        if (!raw) return null
        const parsed = JSON.parse(raw)
        if (parsed && typeof parsed.token === "string" && parsed.token.trim()) {
            return {
                token: parsed.token.trim(),
                email: typeof parsed.email === "string" ? parsed.email.toLowerCase() : undefined,
                organization_id:
                    typeof parsed.organization_id === "string" ? parsed.organization_id : undefined,
                workspace_id:
                    typeof parsed.workspace_id === "string" ? parsed.workspace_id : undefined,
                project_id: typeof parsed.project_id === "string" ? parsed.project_id : undefined,
                survey: typeof parsed.survey === "string" ? parsed.survey : undefined,
            }
        }
    } catch (error) {
        console.error("Failed to read invite from storage:", error)
    }
    return null
}

export const persistInviteToStorage = (invite: InvitePayload | null) => {
    if (!isBrowser) return
    try {
        if (invite && invite.token) {
            window.localStorage.setItem(INVITE_STORAGE_KEY, JSON.stringify(invite))
        } else {
            window.localStorage.removeItem(INVITE_STORAGE_KEY)
        }
    } catch (error) {
        console.error("Failed to persist invite to storage:", error)
    }
}

const INVITE_URL_PARAMS = [
    "token",
    "email",
    "organization_id",
    "workspace_id",
    "project_id",
    "survey",
]

/**
 * Fully forget a pending invite: clear the atom, storage, and the invite query
 * params from the URL. Stripping the URL params matters — `syncAuthStateFromUrl`
 * re-seeds storage from the URL, so clearing storage alone would let the invite
 * resurrect and bounce the user back to /workspaces/accept.
 */
export const clearInvite = () => {
    const store = getDefaultStore()
    store.set(activeInviteAtom, null)
    persistInviteToStorage(null)

    if (!isBrowser) return
    try {
        const url = new URL(window.location.href)
        let changed = false
        INVITE_URL_PARAMS.forEach((param) => {
            if (url.searchParams.has(param)) {
                url.searchParams.delete(param)
                changed = true
            }
        })
        if (changed) {
            window.history.replaceState(
                window.history.state,
                "",
                `${url.pathname}${url.search}${url.hash}`,
            )
        }
    } catch (error) {
        console.error("Failed to clear invite params from URL:", error)
    }
}

export const isCurrentAcceptRouteForInvite = (appState: any, invite: InvitePayload) => {
    if (!appState.pathname?.startsWith("/workspaces/accept")) return false
    const tokenParam = appState.query?.token
    const currentToken = Array.isArray(tokenParam) ? tokenParam[0] : tokenParam
    return currentToken === invite.token
}

export const writePostSignupPending = () => {
    if (!isBrowser) return
    try {
        window.sessionStorage.setItem(POST_SIGNUP_PENDING_KEY, JSON.stringify({ts: Date.now()}))
    } catch {
        // ignore storage failures
    }
}

const readPostSignupPending = (): boolean => {
    if (!isBrowser) return false
    try {
        const raw = window.sessionStorage.getItem(POST_SIGNUP_PENDING_KEY)
        if (!raw) return false
        const parsed = JSON.parse(raw) as {ts?: number}
        if (!parsed?.ts) return false
        if (Date.now() - parsed.ts > POST_SIGNUP_TTL_MS) return false
        return true
    } catch {
        return false
    }
}

const clearPostSignupPending = () => {
    if (!isBrowser) return
    try {
        window.sessionStorage.removeItem(POST_SIGNUP_PENDING_KEY)
    } catch {
        // ignore storage failures
    }
}

export const syncAuthStateFromUrl = (nextUrl?: string) => {
    if (!isBrowser) return

    try {
        const store = getDefaultStore()
        const url = new URL(nextUrl ?? window.location.href, window.location.origin)
        const appState = store.get(appStateSnapshotAtom)
        const sessionLoading = store.get(sessionLoadingAtom)
        const isSignedIn = store.get(sessionExistsAtom)
        const user = store.get(userAtom)
        const urlState = store.get(urlAtom)

        const resolvedPath = nextUrl ? url.pathname : (appState.pathname ?? url.pathname)
        const resolvedAsPath = nextUrl
            ? `${url.pathname}${url.search}${url.hash}`
            : (appState.asPath ?? `${url.pathname}${url.search}${url.hash}`)
        const path = resolvedPath
        const asPath = resolvedAsPath
        const isAuthRoute = path.startsWith("/auth")
        // Next's matched route: the parsed snapshot holds the literal URL, never "/404".
        const isNotFoundRoute = Router.pathname === "/404"
        const isAuthCallbackRoute = path.startsWith("/auth/callback")
        const isAcceptRoute = path.startsWith("/workspaces/accept")
        const isPostSignupRoute = path.startsWith("/post-signup")
        const authError =
            typeof appState.query?.auth_error === "string" ? appState.query.auth_error : null
        const baseAppURL = urlState.baseAppURL || "/w"

        let invite = parseInviteFromUrl(url)
        if (invite) {
            persistInviteToStorage(invite)
        } else {
            const storedInvite = readInviteFromStorage()
            if (storedInvite) {
                invite = storedInvite
            }
        }
        store.set(activeInviteAtom, invite ?? null)

        // Capture a website template deep-link alongside the invite, from the same URL read. Runs
        // again on a regional host after a region redirect, since the query string survives the
        // switch but the stored key does not.
        captureTemplateFromUrl(url)

        if (sessionLoading) {
            store.set(protectedRouteReadyAtom, false)
            return
        }

        if (isSignedIn) {
            if (isPostSignupRoute) {
                console.log("[auth-sync] signed in on /post-signup", {
                    path,
                    asPath,
                    baseAppURL,
                })
                clearPostSignupPending()
            }
            if (isAuthCallbackRoute) {
                store.set(protectedRouteReadyAtom, false)
                return
            }
            if (isAuthRoute) {
                if (readPostSignupPending()) {
                    clearPostSignupPending()
                    void Router.replace("/post-signup").catch((error) => {
                        console.error("Failed to redirect to post-signup:", error)
                    })
                    store.set(protectedRouteReadyAtom, false)
                    return
                }
            }
            if (typeof window !== "undefined") {
                const upgradeOrgId = window.localStorage.getItem("authUpgradeOrgId")
                const identifiers = store.get(appIdentifiersAtom)
                const currentWorkspaceId = identifiers.workspaceId
                const upgradePath = upgradeOrgId ? `/w/${encodeURIComponent(upgradeOrgId)}` : null
                const alreadyOnUpgradePath =
                    Boolean(upgradePath) && path.startsWith(upgradePath as string)

                if (upgradeOrgId && alreadyOnUpgradePath) {
                    window.localStorage.removeItem("authUpgradeOrgId")
                    window.localStorage.removeItem("authUpgradeSessionIdentities")
                } else if (upgradeOrgId && upgradeOrgId !== currentWorkspaceId) {
                    void Router.replace(`/w/${encodeURIComponent(upgradeOrgId)}`).catch((error) => {
                        console.error(
                            "Failed to redirect authenticated user to upgrade org:",
                            error,
                        )
                    })
                    store.set(protectedRouteReadyAtom, false)
                    return
                }
            }

            if (invite && !isAcceptRoute) {
                const inviteEmail = invite.email?.toLowerCase() ?? undefined
                const userEmail = user?.email?.toLowerCase()
                const profileQuery = store.get(profileQueryAtom)
                const profileLoading = profileQuery.isPending || profileQuery.isFetching

                // If invite has an email but user profile is still loading, wait
                // This prevents race conditions where we redirect to accept before
                // we can check if the emails match
                if (inviteEmail && !userEmail && profileLoading) {
                    store.set(protectedRouteReadyAtom, false)
                    return
                }

                if (!inviteEmail || !userEmail || inviteEmail === userEmail) {
                    if (!isCurrentAcceptRouteForInvite(appState, invite)) {
                        // Spread into a fresh object literal so it satisfies ParsedUrlQueryInput
                        void Router.replace({
                            pathname: "/workspaces/accept",
                            query: {...invite},
                        }).catch((error) => {
                            console.error("Failed to redirect to invite acceptance:", error)
                        })
                    }
                    store.set(protectedRouteReadyAtom, false)
                    return
                }
                // Invite exists but emails don't match - if on auth route, show the page
                // so user can sign out and sign in with the correct account
                if (isAuthRoute && inviteEmail && userEmail && inviteEmail !== userEmail) {
                    store.set(protectedRouteReadyAtom, true)
                    return
                }
            }

            if (isPostSignupRoute) {
                store.set(protectedRouteReadyAtom, true)
                return
            }

            if (isAuthRoute) {
                if (authError === "sso_denied") {
                    if (typeof window !== "undefined") {
                        signOut().catch(() => null)
                    }
                    store.set(protectedRouteReadyAtom, true)
                    return
                }
                // When auth upgrade is required, stay on auth page to show the upgrade message
                // The user needs to re-authenticate with the correct method
                if (authError === "upgrade_required") {
                    store.set(protectedRouteReadyAtom, true)
                    return
                }
                if (typeof window !== "undefined") {
                    const upgradeOrgId = window.localStorage.getItem("authUpgradeOrgId")
                    if (upgradeOrgId) {
                        void Router.replace(`/w/${encodeURIComponent(upgradeOrgId)}`).catch(
                            (error) => {
                                console.error(
                                    "Failed to redirect authenticated user to upgrade org:",
                                    error,
                                )
                            },
                        )
                        store.set(protectedRouteReadyAtom, false)
                        return
                    }
                }

                // IMPORTANT: Don't redirect from /auth here - let usePostAuthRedirect.handleAuthSuccess
                // handle the redirect with proper auth method filtering. The auth sync can't filter
                // synchronously, so redirecting here would use unfiltered orgs and cause auth upgrade errors.
                // The auth components will call handleAuthSuccess which does proper filtering.
                console.log(
                    "[auth-sync] Signed in user on /auth - letting usePostAuthRedirect handle redirect",
                )
                store.set(protectedRouteReadyAtom, true)
                return
            }

            if (isAcceptRoute) {
                if (!invite) {
                    if (!path.startsWith(baseAppURL)) {
                        void Router.replace(baseAppURL).catch((error) => {
                            console.error("Failed to redirect from empty invite route:", error)
                        })
                    }
                    store.set(protectedRouteReadyAtom, false)
                } else {
                    // On a wrong-account invite, do NOT redirect away. Let the accept
                    // page render its "this invitation is not for you" card with the
                    // sign-in-as-different-account action. Redirecting here would bounce
                    // the user to their own workspace and hide the explanation.
                    store.set(protectedRouteReadyAtom, true)
                }
            }

            if (path === "/w") {
                const identifiers = store.get(appIdentifiersAtom)
                if (!identifiers.workspaceId) {
                    const orgs = store.get(orgsAtom)
                    const targetWorkspaceId = resolvePreferredWorkspaceId(user?.id ?? null, orgs)

                    if (targetWorkspaceId) {
                        const pendingCommand = store.get(navigationRequestAtom)
                        if (!pendingCommand) {
                            store.set(requestNavigationAtom, {
                                type: "href",
                                href: `/w/${encodeURIComponent(targetWorkspaceId)}`,
                                method: "replace",
                            })
                        }
                        store.set(protectedRouteReadyAtom, false)
                        return
                    }
                }
            }

            store.set(protectedRouteReadyAtom, true)
            return
        }

        // Signed out: drop the latch so a dead session can never keep the page visible.
        // /404 joins the auth screens: bouncing a bad link to sign-in hides the explanation.
        if (isAuthRoute || isNotFoundRoute) {
            store.set(protectedRouteReadyAtom, true)
            store.set(protectedRouteReadyLatchAtom, false)
            return
        }

        const redirectToPath = `/auth?redirectToPath=${encodeURIComponent(asPath)}`
        if (asPath !== redirectToPath) {
            void Router.replace(redirectToPath).catch((error) => {
                console.error("Failed to redirect unauthenticated user to auth:", error)
            })
        }
        store.set(protectedRouteReadyAtom, false)
        store.set(protectedRouteReadyLatchAtom, false)
    } catch (err) {
        console.error("Failed to sync auth state from URL:", nextUrl, err)
    }
}
