import {memo, useCallback, useEffect, useMemo, useRef, useState, type ReactNode} from "react"

import {workflowLatestRevisionQueryAtomFamily} from "@agenta/entities/workflow"
import {SETTINGS_SIDEBAR_SCOPE_ID} from "@agenta/navigation"
import {ProjectWatch} from "@agenta/sessions/watch"
import AppMessageContext from "@agenta/ui/app-message"
import {useVisualViewportHeight} from "@agenta/ui/hooks"
import {ConfigProvider, Layout, Modal, theme} from "antd"
import clsx from "clsx"
import {atom} from "jotai"
import {useAtom, useAtomValue, useSetAtom, useStore} from "jotai"
import {selectAtom} from "jotai/utils"
import {eagerAtom} from "jotai-eager"
import {useRouter} from "next/router"
import {ErrorBoundary} from "react-error-boundary"

import useIsomorphicLayoutEffect from "@/oss/hooks/useIsomorphicLayoutEffect"
import {refreshSession} from "@/oss/lib/helpers/auth/refreshSession"
import {routerAppIdAtom} from "@/oss/state/app/atoms/fetcher"
import {appStateSnapshotAtom, requestNavigationAtom} from "@/oss/state/appState"
import {layoutFullHeightRequestAtom} from "@/oss/state/layout/fullHeight"
import {cacheWorkspaceOrgPair} from "@/oss/state/org/selectors/org"
import {getProjectValues, useProjectData} from "@/oss/state/project"
import {
    cacheLastUsedProjectId,
    demoReturnHintDismissedAtom,
    demoReturnHintPendingAtom,
    lastNonDemoProjectAtom,
} from "@/oss/state/project/selectors/project"
import {urlAtom} from "@/oss/state/url"
import {playgroundEarlyAgentStateAtom} from "@/oss/state/workflow"

import CustomWorkflowBanner from "../CustomWorkflow/CustomWorkflowBanner"
import ProtectedRoute from "../ProtectedRoute/ProtectedRoute"
import {resolveSidebarLastPath} from "../Sidebar/scopes/sidebarLastPath"
import {resolveSidebarView} from "../Sidebar/scopes/viewRegistry"
import type {SidebarView} from "../Sidebar/types"

import {useStyles} from "./assets/styles"
import AuthUpgradeHost from "./AuthUpgradeHost"
import ErrorFallback from "./ErrorFallback"
import PostHogThemeCapture from "./PostHogThemeCapture"
import {SidebarIsland} from "./SidebarIsland"
import {useAppTheme} from "./ThemeContextProvider"

interface LayoutRouteFlags {
    isAuthRoute: boolean
    isAppRoute: boolean
    isPlayground: boolean
    isHumanEval: boolean
    isEvaluator: boolean
    /** isFullHeight — full-height constrained layout */
    isFullHeight: boolean
}

const layoutRouteFlagsAtom = atom<LayoutRouteFlags>((get) => {
    const snapshot = get(appStateSnapshotAtom)
    const {pathname, query, routeLayer} = snapshot

    const selectedEvaluation = Array.isArray(query.selectedEvaluation)
        ? query.selectedEvaluation[0]
        : query.selectedEvaluation

    const isHumanEval =
        pathname.includes("/evaluations") || selectedEvaluation === "human_annotation"
    const isEvaluator = pathname.includes("/evaluators")
    const isTestsets = pathname.includes("/testsets") || pathname.includes("/prompts")
    const isAnnotations = pathname.includes("/annotations")
    const isRegistry = pathname.includes("/variants")
    const isObservability = pathname.includes("/observability") || pathname.includes("/traces")
    // The agent-templates gallery has its own fixed header + rail with an
    // internally-scrolling card grid, so it needs the bounded full-height frame.
    const isAgentTemplates = pathname.includes("/agent-templates")
    // Covers /agents and /agents/archived, both full-height InfiniteVirtualTable pages.
    const isAgents = pathname.includes("/agents")
    const isSessions = pathname.includes("/sessions")

    return {
        isAuthRoute:
            pathname.includes("/auth") ||
            pathname.includes("/post-signup") ||
            pathname.startsWith("/workspaces/accept"),
        isAppRoute: routeLayer === "app",
        isPlayground: pathname.includes("/playground"),
        isHumanEval,
        isEvaluator,
        isFullHeight:
            isHumanEval ||
            isEvaluator ||
            isTestsets ||
            isAnnotations ||
            isRegistry ||
            isObservability ||
            isAgentTemplates ||
            isAgents ||
            isSessions ||
            // Asked for by the page — see `layoutFullHeightRequestAtom`. Home is one of these:
            // its returning branch scrolls with the page, its first-run branch asks for the frame.
            get(layoutFullHeightRequestAtom),
    }
})

const selectedLayoutRouteFlagsAtom = selectAtom(
    layoutRouteFlagsAtom,
    (flags) => flags,
    (a, b) =>
        a.isAuthRoute === b.isAuthRoute &&
        a.isAppRoute === b.isAppRoute &&
        a.isPlayground === b.isPlayground &&
        a.isHumanEval === b.isHumanEval &&
        a.isEvaluator === b.isEvaluator &&
        a.isFullHeight === b.isFullHeight,
)

/**
 * The layout flags are derived from the in-flight pathname, which Next flips at
 * `routeChangeStart` — before the destination page mounts. During that window the
 * *outgoing* page is still in the DOM, so leaving a full-height table page for a
 * content-flow page would briefly strip the table's `overflow-hidden` bound and
 * make it reflow/jump until the new page took over.
 *
 * This hook keeps the flags pinned to the *committed* route: while a navigation is
 * in flight we freeze the last value and only adopt the new flags on
 * `routeChangeComplete` (when Next swaps the page in). Same-route updates (e.g. the
 * settings `?tab=audit-log` toggle) aren't page swaps, so they're adopted
 * immediately when idle.
 */
const useCommittedLayoutFlags = (): LayoutRouteFlags => {
    const store = useStore()
    const router = useRouter()
    const liveFlags = useAtomValue(selectedLayoutRouteFlagsAtom)
    const [committedFlags, setCommittedFlags] = useState(liveFlags)
    const navigatingRef = useRef(false)

    useEffect(() => {
        const onStart = () => {
            navigatingRef.current = true
        }
        const onComplete = () => {
            navigatingRef.current = false
            setCommittedFlags(store.get(selectedLayoutRouteFlagsAtom))
        }
        router.events.on("routeChangeStart", onStart)
        router.events.on("routeChangeComplete", onComplete)
        router.events.on("routeChangeError", onComplete)
        return () => {
            router.events.off("routeChangeStart", onStart)
            router.events.off("routeChangeComplete", onComplete)
            router.events.off("routeChangeError", onComplete)
        }
    }, [router, store])

    useEffect(() => {
        // Adopt live flags immediately when no navigation is in flight (initial
        // mount, same-route query changes, and as a self-heal if the snapshot
        // settles after routeChangeComplete).
        if (!navigatingRef.current) setCommittedFlags(liveFlags)
    }, [liveFlags])

    return committedFlags
}

// Narrow slice of the app-state snapshot: exactly what AppWithVariants renders from
const appRouteSliceAtom = selectAtom(
    appStateSnapshotAtom,
    (snapshot) => ({
        pathname: snapshot.pathname,
        asPath: snapshot.asPath,
        routeLayer: snapshot.routeLayer,
    }),
    (a, b) => a.pathname === b.pathname && a.asPath === b.asPath && a.routeLayer === b.routeLayer,
)

// String-valued so org/app churn inside urlAtom doesn't re-render AppWithVariants
const baseAppURLAtom = eagerAtom((get) => get(urlAtom).baseAppURL)

// True once the type lookup has given its final answer, even when that answer is nothing.
const agentTypeSettledAtom = atom((get) => {
    const appId = get(routerAppIdAtom)
    if (!appId) return true
    return !get(workflowLatestRevisionQueryAtomFamily(appId)).isPending
})

type StyleClasses = ReturnType<typeof useStyles>

const {Content} = Layout

interface LayoutProps {
    children: React.ReactNode
}

const AppWithVariants = memo(
    ({
        children,
        isAppRoute,
        classes,
        isPlayground,
        isHumanEval,
        isEvaluator,
        isFullHeight,
        appTheme,
    }: {
        children: ReactNode
        isAppRoute: boolean
        isHumanEval: boolean
        isEvaluator: boolean
        isFullHeight: boolean
        classes: StyleClasses
        appTheme: string
        isPlayground?: boolean
    }) => {
        const baseAppURL = useAtomValue(baseAppURLAtom)
        const appState = useAtomValue(appRouteSliceAtom)
        const isAnnotations = appState.pathname.includes("/annotations")
        const lastBasePathRef = useRef<string | null>(null)
        const lastNonSettingsPathRef = useRef<string | null>(null)
        // Same signal the playground shell reads, so sidebar and content commit together.
        const agentState = useAtomValue(playgroundEarlyAgentStateAtom)
        const agentTypeSettled = useAtomValue(agentTypeSettledAtom)
        const currentSidebarViewIdRef = useRef<string | undefined>(undefined)
        const activeSidebarView = resolveSidebarView({
            pathname: appState.pathname,
            routeLayer: appState.routeLayer,
            agentState,
            agentTypeSettled,
            currentViewId: currentSidebarViewIdRef.current,
        })
        // Update only after commit so abandoned renders cannot change the visible view.
        useIsomorphicLayoutEffect(() => {
            currentSidebarViewIdRef.current = activeSidebarView.id
        }, [activeSidebarView.id])

        useEffect(() => {
            if (activeSidebarView.isBase) {
                lastBasePathRef.current = appState.asPath
            }
            if (activeSidebarView.id !== SETTINGS_SIDEBAR_SCOPE_ID) {
                lastNonSettingsPathRef.current = appState.asPath
            }
        }, [activeSidebarView.id, activeSidebarView.isBase, appState.asPath])

        const sidebarLastPath = resolveSidebarLastPath({
            view: activeSidebarView,
            lastBasePath: lastBasePathRef.current,
            lastNonSettingsPath: lastNonSettingsPathRef.current,
            fallbackPath: baseAppURL,
        })

        const sidebarView = useMemo<SidebarView>(() => {
            return {
                id: activeSidebarView.id,
                lastPath: sidebarLastPath,
            }
        }, [activeSidebarView.id, sidebarLastPath])

        const {project} = useProjectData()
        const lastNonDemoProject = useAtomValue(lastNonDemoProjectAtom)
        const [demoReturnHintPending, setDemoReturnHintPending] = useAtom(demoReturnHintPendingAtom)
        const [demoReturnHintDismissed, setDemoReturnHintDismissed] = useAtom(
            demoReturnHintDismissedAtom,
        )
        const [isDemoReturnModalOpen, setDemoReturnModalOpen] = useState(false)
        const navigate = useSetAtom(requestNavigationAtom)

        useEffect(() => {
            if (project?.is_demo) return
            if (!demoReturnHintPending) return
            if (demoReturnHintDismissed) {
                setDemoReturnHintPending(false)
                return
            }
            setDemoReturnHintPending(false)
            setDemoReturnModalOpen(true)
        }, [
            demoReturnHintDismissed,
            demoReturnHintPending,
            project?.is_demo,
            setDemoReturnHintPending,
        ])

        const closeDemoReturnModal = useCallback(() => {
            setDemoReturnModalOpen(false)
            setDemoReturnHintDismissed(true)
        }, [setDemoReturnHintDismissed])

        // Stable theme object so antd cssinjs doesn't re-evaluate per parent render
        const contentThemeConfig = useMemo(
            () => ({
                algorithm: appTheme === "dark" ? theme.darkAlgorithm : theme.defaultAlgorithm,
            }),
            [appTheme],
        )

        const handleBackToWorkspaceSwitch = useCallback(() => {
            if (!lastNonDemoProject?.workspaceId || !lastNonDemoProject?.projectId) {
                navigate({type: "href", href: "/w", method: "push"})
                return
            }

            cacheLastUsedProjectId(lastNonDemoProject.workspaceId, lastNonDemoProject.projectId)

            if (lastNonDemoProject.organizationId) {
                cacheWorkspaceOrgPair(
                    lastNonDemoProject.workspaceId,
                    lastNonDemoProject.organizationId,
                )
            }

            if (!demoReturnHintDismissed) {
                setDemoReturnHintPending(true)
            }
            const href = `/w/${encodeURIComponent(
                lastNonDemoProject.workspaceId,
            )}/p/${encodeURIComponent(lastNonDemoProject.projectId)}/apps`
            navigate({type: "href", href, method: "push"})
        }, [demoReturnHintDismissed, lastNonDemoProject, navigate, setDemoReturnHintPending])

        return (
            <div
                className={clsx([
                    {"flex flex-col grow min-h-0": isFullHeight},
                    // The demo banner is `fixed`, so it covers anything the page pins to the
                    // viewport top. Sticky content reads this var to offset itself past it.
                    project?.is_demo && "[--ag-demo-banner-h:38px]",
                ])}
            >
                <Modal
                    title="Want to revisit the demo?"
                    open={isDemoReturnModalOpen}
                    onOk={closeDemoReturnModal}
                    onCancel={closeDemoReturnModal}
                    okText="Got it"
                    cancelText="Do not show again"
                >
                    <p className="m-0">
                        Open the org switcher in the sidebar. Select the organization tagged demo to
                        return.
                    </p>
                </Modal>
                <AuthUpgradeHost />
                {project?.is_demo && (
                    <>
                        <div className="fixed top-0 left-0 right-0 z-[9999] flex items-center justify-center gap-1.5 h-[38px] bg-[var(--ag-c-1C2C3D)] text-white text-sm font-medium">
                            You're viewing the demo workspace.
                            <button
                                type="button"
                                className="bg-transparent border-none p-0 text-white text-sm font-medium underline underline-offset-2 hover:opacity-80 transition-opacity cursor-pointer"
                                onClick={handleBackToWorkspaceSwitch}
                            >
                                Return to your workspace
                            </button>
                        </div>
                        <div className="h-[38px] shrink-0" />
                    </>
                )}
                <Layout hasSider className={classes.layout}>
                    <SidebarIsland view={sidebarView} />

                    <Layout className={classes.layout}>
                        <div
                            className={clsx([
                                {
                                    "grow flex flex-col min-h-0": isFullHeight,
                                },
                            ])}
                        >
                            {/* ONE stable tree for both app and non-app routes: the layout flags
                                (committed at routeChangeComplete, AFTER the destination page has
                                rendered) may flip a beat after a client-side nav — as CLASSNAME
                                changes only. The previous per-flag branches reparented {children},
                                so that late flip unmounted and remounted the ENTIRE page (the
                                warm re-entry "flash"). Never fork the element tree on these flags. */}
                            {isAppRoute && !getProjectValues().projectId ? null : (
                                <>
                                    {isAppRoute ? <CustomWorkflowBanner /> : null}
                                    <Content
                                        key="layout-content"
                                        className={clsx(
                                            "flex gap-4",
                                            isAppRoute && "flex-col w-full",
                                            {
                                                // Non-full-height pages keep the 30px bottom
                                                // breathing room (h-calc only off app routes);
                                                // full-height pages (playground/evaluator) must
                                                // fill the content area.
                                                "pb-0 mb-8": !isFullHeight,
                                                "h-[calc(100%-30px)]": !isFullHeight && !isAppRoute,
                                                "flex flex-col min-h-0 grow": isFullHeight,
                                                // The shared content style carries a 2rem bottom
                                                // margin for flowing pages. A full-height page
                                                // fills the frame, so that margin is pure dead
                                                // space under it.
                                                "[&.ant-layout-content]:!mb-0": isFullHeight,
                                                "h-full": isFullHeight && !isAppRoute,
                                                "[&.ant-layout-content]:p-0 [&.ant-layout-content]:m-0":
                                                    isPlayground ||
                                                    (isAppRoute ? isAnnotations : isEvaluator),
                                            },
                                        )}
                                    >
                                        <ErrorBoundary FallbackComponent={ErrorFallback}>
                                            <ConfigProvider theme={contentThemeConfig}>
                                                <div
                                                    className={clsx("w-full", {
                                                        "flex min-h-0 flex-col gap-6 h-[calc(var(--ag-viewport-height,100dvh)-29px)] overflow-hidden":
                                                            isFullHeight,
                                                        "flex flex-col":
                                                            !isFullHeight && !isAppRoute,
                                                    })}
                                                >
                                                    {children}
                                                </div>
                                            </ConfigProvider>
                                        </ErrorBoundary>
                                    </Content>
                                </>
                            )}
                        </div>
                    </Layout>
                </Layout>
            </div>
        )
    },
)

const App: React.FC<LayoutProps> = ({children}) => {
    const {appTheme} = useAppTheme()
    const classes = useStyles({themeMode: appTheme})
    const {isHumanEval, isPlayground, isAppRoute, isAuthRoute, isEvaluator, isFullHeight} =
        useCommittedLayoutFlags()
    // From the router, not the flags atom: that atom is keyed on the parsed URL and goes
    // stale on the hop off a 404. /404 renders bare like the auth screens.
    const router = useRouter()
    const isBareRoute = isAuthRoute || router.pathname === "/404"

    // One owner for the whole app. A phone keyboard opens over the page, so every frame sized
    // against the layout viewport hides its bottom edge behind it. This publishes the visible
    // height as `--ag-viewport-height`, and each full-height frame reads it with a `100dvh`
    // fallback. Mounting it here rather than per page means the playground, the agent overview,
    // sessions, annotations and the auth screens are all covered by one call. Idle on desktop.
    useVisualViewportHeight()

    const [, contextHolder] = Modal.useModal()

    return (
        <>
            <PostHogThemeCapture />
            <AppMessageContext />
            {typeof window === "undefined" ? null : isBareRoute ? (
                <Layout className={classes.layout}>
                    <ErrorBoundary FallbackComponent={ErrorFallback}>
                        {children}
                        {contextHolder}
                    </ErrorBoundary>
                </Layout>
            ) : (
                <ProtectedRoute shell="app">
                    <ProjectWatch refreshSession={refreshSession} />
                    <AppWithVariants
                        isAppRoute={isAppRoute}
                        classes={classes}
                        appTheme={appTheme}
                        isPlayground={isPlayground}
                        isHumanEval={isHumanEval}
                        isEvaluator={isEvaluator}
                        isFullHeight={isFullHeight}
                    >
                        {children}
                        {contextHolder}
                    </AppWithVariants>
                </ProtectedRoute>
            )}
        </>
    )
}

export default App
