import {extractMetrics} from "@agenta/entities/workflow"
import {atom} from "jotai"
import {atomFamily} from "jotai/utils"

import type {StepMeta} from "@/oss/lib/evaluations/buildRunIndex"
import {canonicalizeMetricKey} from "@/oss/lib/metricUtils"

import {GeneralAutoEvalMetricColumns, GeneralHumanEvalMetricColumns} from "../../constants/table"
import {previewEvalTypeAtom} from "../../state/evalType"
import {titleize, formatReferenceLabel, humanizeStepKey} from "../../utils/labelHelpers"

import {evaluationEvaluatorsByRunQueryAtomFamily} from "./evaluators"
import {evaluationRunQueryAtomFamily} from "./run"
import type {
    EvaluationColumnKind,
    EvaluationTableColumn,
    EvaluationTableColumnGroup,
    EvaluationTableColumnsResult,
} from "./types"

interface RawMapping {
    step?: {
        key?: unknown
        path?: unknown
    }
    column?: {
        kind?: unknown
        name?: unknown
    }
}

const isMappingPayload = (
    mapping: RawMapping,
): mapping is {
    step: {
        key: string
        path: string
    }
    column: {
        kind: EvaluationColumnKind
        name: string
    }
} => {
    const stepKey = typeof mapping?.step?.key === "string"
    const stepPath = typeof mapping?.step?.path === "string"
    const columnName = typeof mapping?.column?.name === "string"
    const columnKind =
        mapping?.column?.kind === "testset" ||
        mapping?.column?.kind === "query" ||
        mapping?.column?.kind === "invocation" ||
        mapping?.column?.kind === "annotation" ||
        mapping?.column?.kind === "evaluator"

    return Boolean(stepKey && stepPath && columnName && columnKind)
}

const splitPath = (path: string) => path.split(".").filter(Boolean)

const METRIC_TYPE_FALLBACK = "string"

const metricColumnsSignature = (columns: typeof GeneralAutoEvalMetricColumns) =>
    columns
        .map(
            (column) =>
                `${column.path}|${column.stepKey ?? ""}|${column.metricType ?? ""}|${column.name}`,
        )
        .sort()
        .join("::")

const createMetaColumns = (options?: {
    includeAction?: boolean
    includeTimestamp?: boolean
}): EvaluationTableColumn[] => {
    const columns: EvaluationTableColumn[] = [
        {
            id: "meta:scenario-index-status",
            label: "#",
            displayLabel: "#",
            kind: "meta",
            path: "scenarioIndex",
            pathSegments: ["scenarioIndex"],
            stepType: "meta",
            order: 0,
            width: 72,
            minWidth: 72,
            sticky: "left",
            visibleFor: ["auto", "human"],
            metaRole: "scenarioIndexStatus",
            isSortable: false,
        },
    ]

    // Add timestamp column for online evaluations
    if (options?.includeTimestamp) {
        columns.push({
            id: "meta:timestamp",
            label: "Timestamp",
            displayLabel: "Timestamp",
            kind: "meta",
            path: "timestamp",
            pathSegments: ["timestamp"],
            stepType: "meta",
            order: 1,
            width: 140,
            minWidth: 140,
            visibleFor: ["online"],
            metaRole: "timestamp",
            isSortable: true,
        })
    }

    if (options?.includeAction ?? true) {
        columns.push({
            id: "meta:action",
            label: "Actions",
            displayLabel: "Actions",
            kind: "meta",
            path: "action",
            pathSegments: ["action"],
            stepType: "meta",
            order: 10_000,
            width: 140,
            minWidth: 140,
            sticky: "right",
            visibleFor: ["auto", "human"],
            metaRole: "action",
            isSortable: false,
        })
    }

    return columns
}

const widthByStepType: Record<string, number> = {
    input: 400,
    invocation: 400,
    annotation: 160,
}

type StepRole = "input" | "invocation" | "query"

interface StepGroupInfo {
    id: string
    label: string
    kind: "input" | "invocation"
    columns: EvaluationTableColumn[]
    order: number
    meta?: {
        stepRole: StepRole
        stepKey?: string
        refs?: Record<string, any>
    }
}

const deriveStepGroupLabel = (role: StepRole, stepMeta?: StepMeta): string => {
    const refs = stepMeta?.refs ?? {}

    if (role === "input") {
        if (refs.testset) {
            const label = formatReferenceLabel(refs.testset)
            return label ? `Testset ${label}` : "Test set"
        }

        if (refs.query) {
            const baseLabel =
                formatReferenceLabel(refs.query) ?? humanizeStepKey(stepMeta?.key, "Query")
            const variantLabel = formatReferenceLabel(refs.query_variant)
            const revisionVersion = refs.query_revision?.version
            const revisionLabel =
                revisionVersion !== undefined && revisionVersion !== null
                    ? `Rev ${revisionVersion}`
                    : formatReferenceLabel(refs.query_revision)

            const parts: string[] = [`Query ${baseLabel}`]
            if (variantLabel && variantLabel !== baseLabel) {
                parts.push(`Variant ${variantLabel}`)
            }
            if (revisionLabel) {
                parts.push(revisionLabel.startsWith("Rev") ? revisionLabel : `Rev ${revisionLabel}`)
            }
            return parts.join(" · ")
        }
    } else if (role === "invocation") {
        const applicationLabel =
            formatReferenceLabel(refs.application) ??
            formatReferenceLabel(refs.agent) ??
            formatReferenceLabel(refs.tool)
        const variantLabel = formatReferenceLabel(refs.application_variant)
        const revisionVersion = refs.application_revision?.version
        const revisionLabel =
            revisionVersion !== undefined && revisionVersion !== null
                ? `Rev ${revisionVersion}`
                : formatReferenceLabel(refs.application_revision)

        const parts: string[] = []
        if (applicationLabel) {
            parts.push(`Application ${applicationLabel}`)
        }
        if (variantLabel && variantLabel !== applicationLabel) {
            parts.push(`Variant ${variantLabel}`)
        }
        if (revisionLabel) {
            parts.push(revisionLabel.startsWith("Rev") ? revisionLabel : `Rev ${revisionLabel}`)
        }
        if (parts.length) {
            return parts.join(" · ")
        }
    } else if (role === "query") {
        const baseLabel =
            formatReferenceLabel(refs.query) ??
            formatReferenceLabel(refs.query_revision) ??
            humanizeStepKey(
                refs.query?.slug ?? refs.query_revision?.slug ?? refs.query?.id,
                "Query",
            )
        if (baseLabel) {
            const variantLabel = formatReferenceLabel(refs.query_variant)
            const revisionVersion = refs.query_revision?.version
            const revisionLabel =
                revisionVersion !== undefined && revisionVersion !== null
                    ? `Rev ${revisionVersion}`
                    : formatReferenceLabel(refs.query_revision)

            const parts: string[] = [`Query ${baseLabel}`]
            if (variantLabel && variantLabel !== baseLabel) {
                parts.push(`Variant ${variantLabel}`)
            }
            if (revisionLabel && revisionLabel !== baseLabel) {
                parts.push(revisionLabel.startsWith("Rev") ? revisionLabel : `Rev ${revisionLabel}`)
            }
            return parts.join(" · ")
        }
    }

    return humanizeStepKey(stepMeta?.key, role)
}

const registerStepGroup = ({
    column,
    stepMeta,
    role,
    registry,
    groupIdOverride,
    groupKindOverride,
    labelOverride,
}: {
    column: EvaluationTableColumn
    stepMeta?: StepMeta
    role: StepRole
    registry: Map<string, StepGroupInfo>
    groupIdOverride?: string
    groupKindOverride?: StepGroupInfo["kind"]
    labelOverride?: string
}) => {
    const key = stepMeta?.key ?? column.stepKey ?? `${role}:unknown`
    const groupId = groupIdOverride ?? `${role}:${key}`
    column.groupId = groupId

    const order = column.order ?? (role === "invocation" ? 200 : 100)
    const existing = registry.get(groupId)
    if (existing) {
        existing.columns.push(column)
        existing.order = Math.min(existing.order, order)
        return
    }

    registry.set(groupId, {
        id: groupId,
        label: labelOverride ?? deriveStepGroupLabel(role, stepMeta),
        kind: groupKindOverride ?? (role === "invocation" ? "invocation" : "input"),
        columns: [column],
        order,
        meta: {
            stepRole: role,
            stepKey: stepMeta?.key ?? column.stepKey,
            refs: stepMeta?.refs ?? {},
        },
    })
}

const buildDefaultResult = (
    metaColumns: EvaluationTableColumn[],
): EvaluationTableColumnsResult => ({
    columns: metaColumns,
    groups: [],
    staticMetricColumns: {
        auto: GeneralAutoEvalMetricColumns,
        human: GeneralHumanEvalMetricColumns,
    },
    evaluators: [],
    ungroupedColumns: metaColumns,
})

const tableColumnsBaseAtomFamily = atomFamily((runId: string | null) =>
    atom((get) => {
        const fallbackMetaColumns = createMetaColumns({includeAction: true})
        if (!runId) {
            return buildDefaultResult(fallbackMetaColumns)
        }

        const runQuery = get(evaluationRunQueryAtomFamily(runId))
        const runData = runQuery.data
        if (!runData) {
            return buildDefaultResult(fallbackMetaColumns)
        }

        const stepMetas = Object.values(runData.runIndex.steps ?? {})
        const hasHumanInvocation = stepMetas.some(
            (meta) => meta.kind === "invocation" && meta.origin === "human",
        )
        const hasHumanAnnotation = stepMetas.some(
            (meta) => meta.kind === "annotation" && meta.origin === "human",
        )
        const includeActionColumn = hasHumanInvocation || hasHumanAnnotation

        // Include timestamp column only for online evaluations
        // Use the evaluation type from the atom (set by the page component)
        const evaluationType = get(previewEvalTypeAtom)
        const isOnlineEvaluation = evaluationType === "online"

        const metaColumns = createMetaColumns({
            includeAction: includeActionColumn,
            includeTimestamp: isOnlineEvaluation,
        })

        const evaluatorQuery = get(evaluationEvaluatorsByRunQueryAtomFamily(runId))
        const evaluators = evaluatorQuery?.data ?? []

        const mappings: RawMapping[] = Array.isArray(runData.camelRun?.data?.mappings)
            ? runData.camelRun.data.mappings
            : []

        // Per-step metric definitions derived from the outputs schema the
        // backend inferred from traces and stored on the run step. This is the
        // type source for schema-less evaluators, whose immutable revision
        // carries no schema. Keyed by step key.
        const stepSchemaMetricsByStepKey = new Map<string, ReturnType<typeof extractMetrics>>()
        const runSteps = Array.isArray(runData.camelRun?.data?.steps)
            ? runData.camelRun.data.steps
            : []
        for (const step of runSteps) {
            const outputs = (step as {schemas?: {outputs?: unknown}})?.schemas?.outputs
            const stepKey = (step as {key?: string})?.key
            if (!outputs || !stepKey) continue
            stepSchemaMetricsByStepKey.set(
                stepKey,
                extractMetrics({id: stepKey, slug: stepKey, data: {schemas: {outputs}}}),
            )
        }

        const counters: Record<"input" | "invocation" | "annotation", number> = {
            input: 0,
            invocation: 0,
            annotation: 0,
        }

        const stepGroups = new Map<string, StepGroupInfo>()

        const dynamicColumns: EvaluationTableColumn[] = mappings
            .filter(isMappingPayload)
            .filter((mapping) => !mapping.column.name.includes("_dedup_id"))
            .flatMap((mapping) => {
                const stepMeta = runData.runIndex.steps[mapping.step.key]
                const stepType = stepMeta?.kind ?? "annotation"
                const pathSegments = splitPath(mapping.step.path)
                const valueKey = pathSegments[pathSegments.length - 1] ?? mapping.column.name
                if (mapping.column.kind === "query") {
                    const buildQueryColumn = ({
                        suffix,
                        path,
                        stepRole,
                    }: {
                        suffix: string
                        path: string
                        stepRole: "input" | "invocation"
                    }): EvaluationTableColumn => {
                        const queryOrderBase = stepRole === "input" ? 100 : 200
                        const queryOrder =
                            queryOrderBase + counters[stepRole as keyof typeof counters]++
                        const resolvedPath = path
                        const resolvedPathSegments = splitPath(resolvedPath)
                        const resolvedValueKey =
                            resolvedPathSegments[resolvedPathSegments.length - 1] ?? valueKey
                        const columnLabel = titleize(suffix)
                        return {
                            id: `${mapping.step.key}:query:${suffix}`,
                            label: columnLabel,
                            displayLabel: columnLabel,
                            kind: mapping.column.kind as EvaluationColumnKind,
                            stepKey: mapping.step.key,
                            path: resolvedPath,
                            pathSegments: resolvedPathSegments,
                            stepType: stepRole,
                            valueKey: resolvedValueKey,
                            order: queryOrder,
                            width: widthByStepType[stepRole] ?? widthByStepType.input,
                            minWidth: widthByStepType[stepRole] ?? widthByStepType.input,
                        }
                    }

                    const basePath = mapping.step.path
                    const inputPath = basePath.endsWith(".inputs") ? basePath : `${basePath}.inputs`
                    const outputPath = basePath.endsWith(".outputs")
                        ? basePath
                        : `${basePath}.outputs`

                    const queryColumns = [
                        buildQueryColumn({
                            suffix: "inputs",
                            path: inputPath,
                            stepRole: "input",
                        }),
                        buildQueryColumn({
                            suffix: "outputs",
                            path: outputPath,
                            stepRole: "invocation",
                        }),
                    ]

                    const queryGroupId = `query:${mapping.step.key}`
                    queryColumns.forEach((column) =>
                        registerStepGroup({
                            column,
                            stepMeta,
                            role: "query",
                            registry: stepGroups,
                            groupIdOverride: queryGroupId,
                            groupKindOverride: "input",
                        }),
                    )

                    return queryColumns
                }

                const canonicalMetricKey =
                    stepType === "annotation" ? canonicalizeMetricKey(mapping.step.path) : undefined
                const orderBase = stepType === "input" ? 100 : stepType === "invocation" ? 200 : 300
                const order = orderBase + counters[stepType as keyof typeof counters]++
                const columnId = `${mapping.column.kind}:${mapping.column.name}:${order}`
                const width = widthByStepType[stepType] ?? undefined
                const evaluatorRefs = stepMeta?.refs ?? {}
                const evaluatorRef =
                    evaluatorRefs.evaluator ??
                    evaluatorRefs.evaluator_ref ??
                    evaluatorRefs.evaluatorRef ??
                    evaluatorRefs.evaluatorRevision ??
                    evaluatorRefs.evaluator_revision ??
                    evaluatorRefs.evaluator_revision_ref

                const evaluatorIdRaw =
                    typeof evaluatorRef?.id === "string" && evaluatorRef.id.trim()
                        ? evaluatorRef.id.trim()
                        : typeof evaluatorRefs.evaluator_id === "string" &&
                            evaluatorRefs.evaluator_id.trim()
                          ? evaluatorRefs.evaluator_id.trim()
                          : undefined
                const evaluatorSlug =
                    typeof evaluatorRef?.slug === "string" && evaluatorRef.slug.trim()
                        ? evaluatorRef.slug.trim()
                        : typeof evaluatorRefs.evaluator_slug === "string" &&
                            evaluatorRefs.evaluator_slug.trim()
                          ? evaluatorRefs.evaluator_slug.trim()
                          : undefined
                const evaluatorId = evaluatorIdRaw ?? evaluatorSlug

                const baseColumn: EvaluationTableColumn = {
                    id: columnId,
                    label: mapping.column.name,
                    displayLabel: titleize(mapping.column.name),
                    kind: mapping.column.kind as EvaluationColumnKind,
                    stepKey: mapping.step.key,
                    path: mapping.step.path,
                    pathSegments,
                    stepType,
                    valueKey,
                    metricKey:
                        canonicalMetricKey ?? (stepType === "annotation" ? valueKey : undefined),
                    evaluatorId,
                    evaluatorSlug,
                    order,
                    width,
                    minWidth: width,
                    groupId:
                        stepType === "annotation"
                            ? evaluatorId
                                ? `annotation:${evaluatorId}`
                                : "annotations"
                            : undefined,
                }

                if (baseColumn.stepType === "input" || baseColumn.stepType === "invocation") {
                    registerStepGroup({
                        column: baseColumn,
                        stepMeta,
                        role: baseColumn.stepType,
                        registry: stepGroups,
                    })
                }

                return [baseColumn]
            })

        const evaluatorById = new Map(evaluators.map((definition) => [definition.id, definition]))
        evaluators.forEach((definition) => {
            if (definition.slug && !evaluatorById.has(definition.slug)) {
                evaluatorById.set(definition.slug, definition)
            }
        })

        const annotationGroups = new Map<
            string,
            {label: string; columns: EvaluationTableColumn[]}
        >()

        const enrichedDynamicColumns = dynamicColumns.map((column) => {
            if (column.stepType !== "annotation") {
                return column
            }

            const evaluator = column.evaluatorId ? evaluatorById.get(column.evaluatorId) : undefined
            // Match the evaluator's metric definition by the canonical
            // metric key (e.g. "attributes.ag.data.outputs.score") OR the
            // bare value key (e.g. "score"). `extractMetrics` keys metrics
            // by the output-schema property name — the bare key — so a
            // canonical-key-only match misses and `metricType` falls back
            // to "string", mis-typing the column (e.g. a boolean output).
            const metricKey = column.metricKey || column.valueKey
            const matchMetric = (metrics: ReturnType<typeof extractMetrics> | undefined) =>
                metrics?.find(
                    (metric) =>
                        metric.name === metricKey ||
                        metric.path === metricKey ||
                        metric.name === column.valueKey ||
                        metric.path === column.valueKey,
                )
            // Schema-declared evaluator metrics first; else fall back to the
            // outputs schema the backend inferred from traces and stored on the
            // run step — the only type source for schema-less evaluators, whose
            // immutable revision carries no schema. "string" is the cold-start
            // fallback before any type is known.
            const metricDefinition =
                matchMetric(evaluator?.metrics) ??
                matchMetric(stepSchemaMetricsByStepKey.get(column.stepKey ?? ""))
            const metricType =
                metricDefinition?.metricType || column.metricType || METRIC_TYPE_FALLBACK
            const evaluatorLabel = evaluator?.name || column.evaluatorSlug || "Annotations"
            const groupKey = column.evaluatorId ? `annotation:${column.evaluatorId}` : "annotations"

            // Use the evaluator name as-is when available (don't titleize
            // proper names like "LLM-as-a-judge"). Only titleize fallbacks
            // (slugs, IDs) that aren't human-readable.
            const groupLabel = evaluator?.name || titleize(String(evaluatorLabel))
            if (!annotationGroups.has(groupKey)) {
                annotationGroups.set(groupKey, {label: groupLabel, columns: []})
            }

            const enrichedColumn: EvaluationTableColumn = {
                ...column,
                metricKey,
                metricType,
                evaluatorName: evaluator?.name,
                displayLabel: metricDefinition?.displayLabel || column.displayLabel || column.label,
                description: metricDefinition?.description || column.description,
                groupId: groupKey,
            }

            annotationGroups.get(groupKey)?.columns.push(enrichedColumn)
            return enrichedColumn
        })

        const combinedColumns = [...metaColumns, ...enrichedDynamicColumns]

        const groups: EvaluationTableColumnGroup[] = []
        const pushGroup = (
            id: string,
            label: string,
            kind: EvaluationTableColumnGroup["kind"],
            columns: EvaluationTableColumn[],
            order: number,
            extra?: Partial<EvaluationTableColumnGroup>,
        ) => {
            if (!columns.length) return
            groups.push({
                id,
                label,
                kind,
                columnIds: columns.map((column) => column.id),
                order,
                ...extra,
            })
        }
        const stepGroupEntries = Array.from(stepGroups.values()).sort(
            (a, b) => (a.order ?? 0) - (b.order ?? 0),
        )
        stepGroupEntries.forEach((groupInfo) => {
            pushGroup(
                groupInfo.id,
                groupInfo.label,
                groupInfo.kind,
                groupInfo.columns,
                groupInfo.order,
                groupInfo.meta ? {meta: groupInfo.meta} : undefined,
            )
        })

        const maxStepOrder = stepGroupEntries.length
            ? Math.max(...stepGroupEntries.map((entry) => entry.order ?? 0))
            : 200
        let annotationOrder = maxStepOrder + 100

        annotationGroups.forEach((group, key) => {
            pushGroup(key, group.label, "annotation", group.columns, annotationOrder)
            annotationOrder += 1
        })

        if (GeneralAutoEvalMetricColumns.length) {
            groups.push({
                id: "metrics:auto",
                // label: "Metrics (Auto)",
                label: "Metrics",
                kind: "metric",
                columnIds: [],
                order: annotationOrder,
                staticMetricColumns: GeneralAutoEvalMetricColumns,
            })
            annotationOrder += 1
        }

        const humanMetricsDuplicateGeneric =
            metricColumnsSignature(GeneralHumanEvalMetricColumns) ===
            metricColumnsSignature(GeneralAutoEvalMetricColumns)

        // Only show a separate "Metrics (Human)" group when it carries distinct columns.
        if (
            GeneralHumanEvalMetricColumns.length &&
            evaluationType === "human" &&
            !humanMetricsDuplicateGeneric
        ) {
            groups.push({
                id: "metrics:human",
                label: "Metrics (Human)",
                kind: "metric",
                columnIds: [],
                order: annotationOrder,
                staticMetricColumns: GeneralHumanEvalMetricColumns,
            })
            annotationOrder += 1
        }

        groups.sort((a, b) => (a.order ?? 0) - (b.order ?? 0))

        const sortedColumns = [...combinedColumns].sort((a, b) => (a.order ?? 0) - (b.order ?? 0))

        const groupedIds = new Set<string>()
        groups.forEach((group) => group.columnIds.forEach((id) => groupedIds.add(id)))
        const ungroupedColumns = sortedColumns.filter((column) => !groupedIds.has(column.id))

        return {
            columns: sortedColumns,
            groups,
            staticMetricColumns: {
                auto: GeneralAutoEvalMetricColumns,
                human: GeneralHumanEvalMetricColumns,
            },
            evaluators,
            ungroupedColumns,
        }
    }),
)

export const tableColumnsAtomFamily = atomFamily((runId: string | null) =>
    atom((get) => get(tableColumnsBaseAtomFamily(runId))),
)
