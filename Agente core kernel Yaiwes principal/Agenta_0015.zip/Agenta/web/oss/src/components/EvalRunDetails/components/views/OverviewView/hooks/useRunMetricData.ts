import {useMemo} from "react"

import {atom, useAtomValue, type ExtractAtomValue} from "jotai"
import {LOW_PRIORITY, useAtomValueWithSchedule} from "jotai-scheduler"

import {evaluationEvaluatorsByRunQueryAtomFamily} from "@/oss/components/EvalRunDetails/atoms/table/evaluators"
import {evaluationRunIndexAtomFamily} from "@/oss/components/EvalRunDetails/atoms/table/run"
import {
    previewRunMetricStatsLoadableFamily,
    previewRunMetricStatsSelectorFamily,
    runTemporalMetricKeysAtomFamily,
    runTemporalMetricSeriesAtomFamily,
    TemporalMetricPoint,
    type RunLevelMetricSelection,
} from "@/oss/components/Evaluations/atoms/runMetrics"
import {humanizeMetricPath} from "@/oss/lib/evaluations/utils/metrics"
import {useChartSeries} from "@/oss/lib/hooks/useChartSeries"
import type {BasicStats} from "@/oss/lib/metricUtils"

import {runDisplayNameAtomFamily, runStatusAtomFamily} from "../../../../atoms/runDerived"
import {INVOCATION_METRIC_KEYS, INVOCATION_METRIC_LABELS} from "../constants"
import {
    buildEvaluatorFallbackMetricsByStep,
    buildEvaluatorMetricEntries,
    extractEvaluatorRef,
} from "../utils/evaluatorMetrics"

const emptyEvaluatorsAtom = atom({data: [], isPending: false, isFetching: false} as const)
const emptyLoadableAtom = atom({state: "loading"} as const)
// Typed as the family atom's unwrapped VALUE (RunIndex | null), not the atom itself.
const emptyRunIndexAtom = atom(
    null as ExtractAtomValue<ReturnType<typeof evaluationRunIndexAtomFamily>>,
)
const falseAtom = atom(false)
const emptyTemporalSeriesAtom = atom<Record<string, TemporalMetricPoint[]>>({})
const emptyMetricSelectionsAtom = atom<RunMetricSelectionEntry[]>([])

/**
 * Metric types that can be meaningfully aggregated (mean, distribution, etc.)
 * These come from the backend stats.type field.
 */
const AGGREGATABLE_METRIC_TYPES = new Set([
    "numeric/continuous",
    "numeric/discrete",
    "binary",
    "categorical/single",
    "categorical/multiple",
])

/**
 * Metric types that should NOT be aggregated (text, JSON objects)
 */
const NON_AGGREGATABLE_METRIC_TYPES = new Set(["string", "json"])

/**
 * Determines if a metric should be included in aggregation views (overview, histograms, spider chart).
 *
 * Uses stats.type when available (backend-inferred). Falls back to shape heuristics for legacy data.
 *
 * @returns true if the metric can be aggregated, false otherwise
 */
const isAggregatableMetric = (stats: BasicStats | undefined): boolean => {
    if (!stats) return false

    // Check explicit type from backend (most reliable)
    const statsType = stats.type as string | undefined
    if (statsType) {
        if (NON_AGGREGATABLE_METRIC_TYPES.has(statsType)) return false
        if (AGGREGATABLE_METRIC_TYPES.has(statsType)) return true
    }

    // Fallback: infer from shape when type is missing (legacy data)
    // Numeric metrics have statistical moments
    if (
        typeof stats.mean === "number" ||
        typeof stats.median === "number" ||
        typeof stats.sum === "number" ||
        typeof stats.max === "number"
    ) {
        return true
    }

    // Boolean/categorical metrics have frequency distribution
    const freq = stats.freq ?? stats.frequency
    if (Array.isArray(freq) && freq.length > 0) {
        return true
    }

    // Count-only metrics are typically text fields (like reason)
    return false
}

export interface RunDescriptor {
    runId: string
    displayName: string
    status: string | null
}

export interface EvaluatorRef {
    id?: string | null
    slug?: string | null
}

export interface RunMetricSelectionEntry {
    metric: {
        id: string
        evaluatorLabel: string
        evaluatorRef?: EvaluatorRef | null
        fallbackEvaluatorLabel: string
        stepKey: string
        canonicalKey: string
        rawKey: string
        fullKey: string
        displayLabel: string
        metricType?: string
    }
    selections: {
        runId: string
        index: number
        runKey: string
        selection: RunLevelMetricSelection
    }[]
}

export interface RunMetricData {
    baseRunId: string | null
    runDescriptors: RunDescriptor[]
    metricSelections: RunMetricSelectionEntry[]
    runColorMap: Map<string, string>
    isLoading: boolean
    hasResolvedMetrics: boolean
    hasTemporalMetrics: boolean
    temporalSeriesByMetric: Record<string, TemporalMetricPoint[]>
}

export const useRunMetricData = (runIds: string[]): RunMetricData => {
    const orderedRunIds = useMemo(() => runIds.filter((id): id is string => Boolean(id)), [runIds])
    const baseRunId = orderedRunIds[0] ?? null

    const runDescriptorsAtom = useMemo(
        () =>
            atom((get) =>
                orderedRunIds.map((runId) => ({
                    runId,
                    displayName: get(runDisplayNameAtomFamily(runId)),
                    status: get(runStatusAtomFamily(runId)),
                })),
            ),
        [orderedRunIds],
    )
    const runDescriptors = useAtomValue(runDescriptorsAtom)

    const hasTemporalMetrics = useAtomValue(
        useMemo(
            () => (baseRunId ? runTemporalMetricKeysAtomFamily(baseRunId) : falseAtom),
            [baseRunId],
        ),
    )

    const temporalSeriesAtom = useMemo(
        () => (baseRunId ? runTemporalMetricSeriesAtomFamily(baseRunId) : emptyTemporalSeriesAtom),
        [baseRunId],
    )
    const temporalSeriesRaw = useAtomValue(temporalSeriesAtom)

    const temporalSeriesByMetric = useMemo(() => temporalSeriesRaw ?? {}, [temporalSeriesRaw])

    // Resolved here rather than in a module const: these are plain hex on SVG fill/stroke, so the
    // active theme has to pick the set. Every run color in the overview flows from this map.
    const seriesColors = useChartSeries()
    const runColorMap = useMemo(() => {
        const map = new Map<string, string>()
        orderedRunIds.forEach((runId, index) => {
            map.set(runId, seriesColors[index % seriesColors.length] ?? seriesColors[0])
        })
        return map
    }, [orderedRunIds, seriesColors])

    const evaluatorQueryAtom = useMemo(
        () =>
            baseRunId ? evaluationEvaluatorsByRunQueryAtomFamily(baseRunId) : emptyEvaluatorsAtom,
        [baseRunId],
    )
    const evaluatorDefinitions = useAtomValue(evaluatorQueryAtom)?.data ?? []

    const runIndex = useAtomValue(
        useMemo(
            () => (baseRunId ? evaluationRunIndexAtomFamily(baseRunId) : emptyRunIndexAtom),
            [baseRunId],
        ),
    )

    const metricsAtom = useMemo(
        () =>
            baseRunId ? previewRunMetricStatsLoadableFamily({runId: baseRunId}) : emptyLoadableAtom,
        [baseRunId],
    )
    const metricsLoadable = useAtomValueWithSchedule(metricsAtom, {priority: LOW_PRIORITY})

    const baseStatsMap = useMemo(() => {
        if (metricsLoadable.state !== "hasData") return {}

        const rawData = metricsLoadable.data as
            | Record<string, BasicStats>
            | {data?: Record<string, BasicStats>}
            | undefined
        if (!rawData) return {}
        if ("data" in rawData && rawData.data && typeof rawData.data === "object") {
            return rawData.data as Record<string, BasicStats>
        }
        return rawData as Record<string, BasicStats>
    }, [metricsLoadable])

    const evaluatorByKey = useMemo(() => {
        const map = new Map<string, any>()
        evaluatorDefinitions.forEach((def) => {
            if (def.id) map.set(def.id, def)
            if (def.slug) map.set(def.slug, def)
        })
        return map
    }, [evaluatorDefinitions])

    const evaluatorSteps = useMemo(() => {
        if (!runIndex) return []
        return Array.from(runIndex.annotationKeys ?? []).map((stepKey) => {
            const meta = runIndex.steps?.[stepKey]
            const evaluatorRefMeta = extractEvaluatorRef(meta?.refs)
            const evaluator =
                (evaluatorRefMeta.id && evaluatorByKey.get(evaluatorRefMeta.id)) ||
                (evaluatorRefMeta.slug && evaluatorByKey.get(evaluatorRefMeta.slug)) ||
                null
            const fallbackLabel =
                evaluatorRefMeta.slug || evaluatorRefMeta.id || (meta?.refs as any)?.evaluator?.name
            const label = evaluator?.name || evaluator?.slug || fallbackLabel || stepKey
            const evaluatorRef: EvaluatorRef | null =
                evaluator || evaluatorRefMeta.id || evaluatorRefMeta.slug
                    ? {
                          id: evaluator?.id ?? evaluatorRefMeta.id ?? null,
                          slug: evaluator?.slug ?? evaluatorRefMeta.slug ?? null,
                      }
                    : null
            return {stepKey, label, evaluatorRef}
        })
    }, [evaluatorByKey, runIndex])

    const fallbackMetricMap = useMemo(
        () => buildEvaluatorFallbackMetricsByStep(runIndex ?? null, evaluatorDefinitions),
        [evaluatorDefinitions, runIndex],
    )

    const evaluatorMetricEntries = useMemo(
        () =>
            buildEvaluatorMetricEntries(
                baseStatsMap,
                evaluatorSteps,
                fallbackMetricMap,
                evaluatorDefinitions,
            ),
        [evaluatorDefinitions, baseStatsMap, evaluatorSteps, fallbackMetricMap],
    )

    const metricCatalog = useMemo(() => {
        const evaluatorMetrics = evaluatorMetricEntries.flatMap((entry) =>
            entry.metrics
                .filter((metric) => {
                    // Filter out non-aggregatable metrics (e.g., text fields like "reason")
                    const stats = baseStatsMap[metric.fullKey] as BasicStats | undefined
                    return isAggregatableMetric(stats)
                })
                .map((metric) => {
                    const metricKey = metric.canonicalKey || metric.rawKey
                    const displayLabel =
                        humanizeMetricPath(metric.canonicalKey) ||
                        humanizeMetricPath(metric.rawKey) ||
                        metric.rawKey.replace(/[_\.]/g, " ")
                    return {
                        id: `${entry.stepKey}:${metricKey}`,
                        evaluatorLabel: entry.label,
                        evaluatorRef: entry.evaluatorRef ?? null,
                        fallbackEvaluatorLabel: entry.label,
                        stepKey: entry.stepKey,
                        canonicalKey: metric.canonicalKey,
                        rawKey: metric.rawKey,
                        fullKey: metric.fullKey,
                        displayLabel,
                        metricType: metric.metricType,
                    }
                }),
        )

        const invocationMetrics = INVOCATION_METRIC_KEYS.map((key) => ({
            id: `invocation:${key}`,
            evaluatorLabel: "Invocation",
            evaluatorRef: null,
            fallbackEvaluatorLabel: "Invocation",
            stepKey: "",
            canonicalKey: key,
            rawKey: key,
            fullKey: key,
            displayLabel: INVOCATION_METRIC_LABELS[key] ?? key,
        }))

        return [...evaluatorMetrics, ...invocationMetrics]
    }, [baseStatsMap, evaluatorMetricEntries])

    const selectionSignature = useMemo(() => {
        const metricSig = metricCatalog.map((metric) => metric.id).join("|")
        const runSig = orderedRunIds.join("|")
        return `${metricSig}__${runSig}`
    }, [metricCatalog, orderedRunIds])

    const shouldBuildSelections =
        evaluatorDefinitions?.length > 0 &&
        metricCatalog.length > 0 &&
        orderedRunIds.length > 0 &&
        metricsLoadable.state !== "loading"

    const metricSelectionsAtom = useMemo(() => {
        if (!shouldBuildSelections) return emptyMetricSelectionsAtom

        const perMetricAtoms = metricCatalog.map((metric) =>
            atom((get) => ({
                metric,
                selections: orderedRunIds.map((runId, index) => ({
                    runId,
                    index,
                    runKey: index === 0 ? "run_base" : `run_${index}`,
                    selection: get(
                        previewRunMetricStatsSelectorFamily({
                            runId,
                            stepKey: metric.stepKey,
                            metricPath: metric.fullKey,
                            metricKey: metric.rawKey,
                        }),
                    ),
                })),
            })),
        )

        return atom((get) => perMetricAtoms.map((metricAtom) => get(metricAtom)))
    }, [metricCatalog, orderedRunIds, selectionSignature, shouldBuildSelections])

    const metricSelections = useAtomValue(metricSelectionsAtom)

    const selectorLoading = metricSelections.some(({selections}) =>
        selections.some(({selection}) => selection.state === "loading"),
    )
    const hasResolvedMetrics = metricSelections.some(({selections}) =>
        selections.some(({selection}) => selection.state === "hasData" && Boolean(selection.stats)),
    )

    const isLoading = metricsLoadable.state === "loading" || selectorLoading

    return {
        baseRunId,
        runDescriptors,
        metricSelections,
        runColorMap,
        isLoading,
        hasResolvedMetrics,
        hasTemporalMetrics,
        temporalSeriesByMetric,
    }
}
