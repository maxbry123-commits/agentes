import {memo, useCallback, useState, type ReactNode} from "react"

import {message} from "@agenta/ui/app-message"
import {
    CaretDown,
    CaretRight,
    Check,
    Code,
    Copy,
    MapPin,
    MarkdownLogoIcon,
    TextAa,
    Trash,
    X,
} from "@phosphor-icons/react"
import {Button, Dropdown, Input, Popover, Tooltip} from "antd"
import type {MenuProps} from "antd"

export interface DrillInFieldHeaderProps {
    /** Field name to display */
    name: string
    /** Field value (for copy functionality) */
    value: unknown
    /** Whether the field is collapsed */
    isCollapsed: boolean
    /** Callback when collapse toggle is clicked */
    onToggleCollapse: () => void
    /** Item count string (e.g., "5 items" or "3 properties") */
    itemCount?: string
    /** Whether the field can be drilled into */
    expandable?: boolean
    /** Callback when drill in is clicked */
    onDrillIn?: () => void
    /** Whether raw mode toggle should be shown */
    showRawToggle?: boolean
    /** Whether raw mode is active */
    isRawMode?: boolean
    /** Callback when raw mode is toggled */
    onToggleRawMode?: () => void
    /** Whether delete button should be shown */
    showDelete?: boolean
    /** Callback when delete is clicked */
    onDelete?: () => void
    /** Whether to always show copy button (vs only when collapsed/expandable) */
    alwaysShowCopy?: boolean
    /** Column options for mapping dropdown */
    columnOptions?: {value: string; label: string}[]
    /** Callback when user selects a column to map to */
    onMapToColumn?: (column: string) => void
    /** Callback when user wants to remove the mapping */
    onUnmap?: () => void
    /** Whether the field is already mapped */
    isMapped?: boolean
    /** The column name this field is mapped to (for display) */
    mappedColumn?: string
    /** Number of nested paths that are mapped (for parent objects) */
    nestedMappingCount?: number
    /** Whether markdown toggle should be shown */
    showMarkdownToggle?: boolean
    /** Whether markdown view is active */
    isMarkdownView?: boolean
    /** Callback when markdown view is toggled */
    onToggleMarkdownView?: () => void
    /** Available content view modes for this field */
    viewModeOptions?: {value: string; label: string}[]
    /** Current content view mode */
    viewMode?: string
    /** Callback when content view mode changes */
    onViewModeChange?: (mode: string) => void
    /** Show collapse toggle in the header (default: true) */
    showCollapseToggle?: boolean
    /** Optional chip rendered after the field name. */
    typeChip?: ReactNode
    /** Show drill-in action button in the header (default: true) */
    showDrillInButton?: boolean
}

/**
 * Popover component for mapping a field to a column
 */
const MappingPopover = memo(
    ({
        columnOptions,
        onMapToColumn,
        onUnmap,
        isMapped,
    }: {
        columnOptions?: {value: string; label: string}[]
        onMapToColumn: (column: string) => void
        onUnmap?: () => void
        isMapped: boolean
    }) => {
        const [open, setOpen] = useState(false)
        const [newColumnName, setNewColumnName] = useState("")
        const [showNewColumnInput, setShowNewColumnInput] = useState(false)

        const handleSelectColumn = useCallback(
            (column: string) => {
                onMapToColumn(column)
                setOpen(false)
            },
            [onMapToColumn],
        )

        const handleCreateColumn = useCallback(() => {
            if (newColumnName.trim()) {
                onMapToColumn(newColumnName.trim())
                setNewColumnName("")
                setShowNewColumnInput(false)
                setOpen(false)
            }
        }, [newColumnName, onMapToColumn])

        const handleUnmap = useCallback(() => {
            onUnmap?.()
            setOpen(false)
        }, [onUnmap])

        const content = (
            <div className="flex flex-col gap-1 min-w-[180px]">
                {isMapped ? (
                    <Button
                        type="text"
                        danger
                        size="small"
                        className="justify-start"
                        icon={<X size={14} />}
                        onClick={handleUnmap}
                    >
                        Remove mapping
                    </Button>
                ) : (
                    <>
                        {showNewColumnInput ? (
                            <div className="flex gap-1">
                                <Input
                                    size="small"
                                    placeholder="Column name"
                                    value={newColumnName}
                                    onChange={(e) => setNewColumnName(e.target.value)}
                                    onPressEnter={handleCreateColumn}
                                    autoFocus
                                />
                                <Button size="small" type="primary" onClick={handleCreateColumn}>
                                    Add
                                </Button>
                            </div>
                        ) : (
                            <Button
                                type="text"
                                size="small"
                                className="justify-start text-[var(--ag-btn-link)]"
                                onClick={() => setShowNewColumnInput(true)}
                            >
                                + Create new column
                            </Button>
                        )}
                        {columnOptions && columnOptions.length > 0 && (
                            <>
                                <div className="border-t border-gray-200 my-1" />
                                {columnOptions.map((opt) => (
                                    <Button
                                        key={opt.value}
                                        type="text"
                                        size="small"
                                        className="justify-start"
                                        onClick={() => handleSelectColumn(opt.value)}
                                    >
                                        {opt.label}
                                    </Button>
                                ))}
                            </>
                        )}
                    </>
                )}
            </div>
        )

        return (
            <Popover
                content={content}
                trigger="click"
                open={open}
                onOpenChange={(visible) => {
                    setOpen(visible)
                    if (!visible) {
                        setShowNewColumnInput(false)
                        setNewColumnName("")
                    }
                }}
                placement="bottomRight"
            >
                <Tooltip title={isMapped ? "Mapping options" : "Map to column"}>
                    <Button
                        type="text"
                        size="small"
                        className={`!px-1 !h-6 text-xs ${isMapped ? "text-green-500" : "text-gray-500"}`}
                        icon={<MapPin size={12} weight={isMapped ? "fill" : "regular"} />}
                    />
                </Tooltip>
            </Popover>
        )
    },
)

MappingPopover.displayName = "MappingPopover"

function ViewModeDropdown({
    value,
    options,
    onChange,
}: {
    value: string
    options: {value: string; label: string}[]
    onChange: (mode: string) => void
}) {
    const selectedOption = options.find((option) => option.value === value)
    const items: MenuProps["items"] = options.map((option) => ({
        key: option.value,
        className: "!p-0 !rounded-lg !bg-transparent",
        label: (
            <div
                className={`flex min-h-[34px] items-center justify-between gap-4 rounded-lg px-3.5 py-1.5 ${
                    option.value === value ? "bg-[var(--ag-rgba-051729-04)]" : ""
                }`}
            >
                <span className="text-[13px] font-medium text-[var(--ag-c-051729)]">
                    {option.label}
                </span>
                {option.value === value ? (
                    <span className="text-xs text-[var(--ag-rgba-051729-55)]">default</span>
                ) : null}
            </div>
        ),
        onClick: () => onChange(option.value),
    }))

    return (
        <Dropdown
            menu={{items, selectedKeys: [value]}}
            trigger={["click"]}
            placement="bottomRight"
            overlayClassName="[&_.ant-dropdown-menu]:min-w-[220px] [&_.ant-dropdown-menu]:rounded-xl [&_.ant-dropdown-menu]:p-2.5 [&_.ant-dropdown-menu]:shadow-[0_12px_32px_rgba(5,23,41,0.16)]"
        >
            <Button type="text" size="small" className="inline-flex items-center gap-1 px-2 h-6">
                <span className="text-[12px] text-[var(--ag-rgba-051729-55)]">
                    View as{" "}
                    <span className="font-semibold text-[var(--ag-c-051729)]">
                        {selectedOption?.label ?? value}
                    </span>
                </span>
                <CaretDown size={12} className="text-[var(--ag-rgba-051729-55)]" />
            </Button>
        </Dropdown>
    )
}

/**
 * Reusable field header component for drill-in views
 * Used by TestcaseEditDrawer and TraceDataDrillIn
 */
const DrillInFieldHeader = memo(
    ({
        name,
        value,
        isCollapsed,
        onToggleCollapse,
        expandable = false,
        onDrillIn,
        showRawToggle = false,
        isRawMode = false,
        onToggleRawMode,
        showDelete = false,
        onDelete,
        alwaysShowCopy = false,
        columnOptions,
        onMapToColumn,
        onUnmap,
        isMapped = false,
        mappedColumn,
        nestedMappingCount = 0,
        showMarkdownToggle = false,
        isMarkdownView = false,
        onToggleMarkdownView,
        viewModeOptions,
        viewMode,
        onViewModeChange,
        showCollapseToggle = true,
        typeChip,
        showDrillInButton = true,
    }: DrillInFieldHeaderProps) => {
        const [copiedField, setCopiedField] = useState<string | null>(null)

        const handleCopy = useCallback(() => {
            const valueToCopy = typeof value === "string" ? value : JSON.stringify(value, null, 2)
            navigator.clipboard.writeText(valueToCopy)
            setCopiedField(name)
            message.success("Copied to clipboard")
            setTimeout(() => setCopiedField(null), 1000)
        }, [value, name])

        const showCopyButton = alwaysShowCopy || isCollapsed || expandable

        return (
            <div className="drill-in-field-header flex items-center justify-between py-2 px-3 bg-[var(--ag-c-FAFAFA)] rounded-md border-solid border-[1px] border-[var(--ag-rgba-051729-06)]">
                <div className="flex items-center gap-2">
                    {showCollapseToggle ? (
                        <>
                            <button
                                type="button"
                                onClick={onToggleCollapse}
                                className="flex items-center hover:text-gray-700 transition-colors bg-transparent border-none p-0 cursor-pointer"
                            >
                                {isCollapsed ? <CaretRight size={14} /> : <CaretDown size={14} />}
                            </button>
                            <span className="text-gray-700 font-medium">{name}</span>
                            {typeChip}
                        </>
                    ) : (
                        <>
                            <span className="text-gray-700 font-medium">{name}</span>
                            {typeChip}
                        </>
                    )}
                    {mappedColumn ? (
                        <span className="text-xs text-green-600 dark:text-green-400 font-medium">
                            mapped to {mappedColumn}
                        </span>
                    ) : nestedMappingCount > 0 ? (
                        <span className="text-xs text-green-600 dark:text-green-400 font-medium">
                            contains {nestedMappingCount} mapping
                            {nestedMappingCount > 1 ? "s" : ""}
                        </span>
                    ) : null}
                    {/* itemCount && <span className="text-xs text-gray-400">[{itemCount}]</span> */}
                </div>
                <div className="flex items-center gap-2">
                    {viewModeOptions &&
                        viewModeOptions.length > 1 &&
                        viewMode &&
                        onViewModeChange && (
                            <ViewModeDropdown
                                value={viewMode}
                                options={viewModeOptions}
                                onChange={onViewModeChange}
                            />
                        )}
                    {showCopyButton && (
                        <Tooltip title={copiedField === name ? "Copied" : "Copy"}>
                            <Button
                                type="text"
                                size="small"
                                className="!px-1 !h-6 text-xs text-gray-500"
                                icon={
                                    copiedField === name ? <Check size={12} /> : <Copy size={12} />
                                }
                                onClick={handleCopy}
                            />
                        </Tooltip>
                    )}
                    {showRawToggle && onToggleRawMode && (
                        <Tooltip title={isRawMode ? "Show formatted" : "Show raw"}>
                            <Button
                                type="text"
                                size="small"
                                className={`!px-1 !h-6 text-xs ${isRawMode ? "text-[var(--ag-btn-link)]" : "text-gray-500"}`}
                                icon={<Code size={12} />}
                                onClick={onToggleRawMode}
                            />
                        </Tooltip>
                    )}
                    {showMarkdownToggle && onToggleMarkdownView && (
                        <Tooltip title={isMarkdownView ? "Preview text" : "Preview markdown"}>
                            <Button
                                type="text"
                                size="small"
                                className={`!px-1 !h-6 text-xs ${isMarkdownView ? "text-[var(--ag-btn-link)]" : "text-gray-500"}`}
                                icon={
                                    isMarkdownView ? (
                                        <TextAa size={12} />
                                    ) : (
                                        <MarkdownLogoIcon size={12} />
                                    )
                                }
                                onClick={onToggleMarkdownView}
                            />
                        </Tooltip>
                    )}
                    {showDrillInButton && expandable && onDrillIn && (
                        <Button
                            type="text"
                            size="small"
                            onClick={onDrillIn}
                            className="!px-2 !h-6 text-xs text-gray-500"
                        >
                            <CaretRight size={12} className="mr-1" />
                            Drill In
                        </Button>
                    )}
                    {onMapToColumn && (
                        <MappingPopover
                            columnOptions={columnOptions}
                            onMapToColumn={onMapToColumn}
                            onUnmap={onUnmap}
                            isMapped={isMapped}
                        />
                    )}
                    {showDelete && onDelete && (
                        <Button
                            type="text"
                            size="small"
                            danger
                            icon={<Trash size={12} />}
                            onClick={onDelete}
                        />
                    )}
                </div>
            </div>
        )
    },
)

DrillInFieldHeader.displayName = "DrillInFieldHeader"

export default DrillInFieldHeader
