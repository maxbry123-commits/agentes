import {useCallback, useMemo, useState} from "react"

import {
    ColumnVisibilityMenuTrigger,
    defaultHeaderVariant,
    detectColumnTypes,
    InfiniteVirtualTableFeatureShell,
    type TableScopeConfig,
    type TypeChipConfig,
    useTypeChipFeature,
    type ExtendedColumn,
} from "@agenta/ui/table"
import type {ColumnDef, ColumnDefs, TableMenuItem} from "@agenta/ui/table"
import {TypeChip, type ChipVariant} from "@agenta/ui/type-chip"
import {PlusOutlined} from "@ant-design/icons"
import {Button, Input, Skeleton, Tooltip} from "antd"
import clsx from "clsx"
import {useAtomValue} from "jotai"
import {getDefaultStore} from "jotai/vanilla"

import {extractTestcaseUserData, testcaseEntityAtomFamily} from "@/oss/state/entities/testcase"
import type {Column} from "@/oss/state/entities/testcase/columnState"
import {objectColumnSubKeysAtom} from "@/oss/state/entities/testcase/columnState"

import {testcasesDatasetStore, type TestcaseTableRow} from "../atoms/tableStore"
import type {UseTestcasesTableResult} from "../hooks/types"
import {groupColumns} from "../utils/groupColumns"

import EditableColumnHeader from "./EditableColumnHeader"
import {TestcaseCell} from "./TestcaseCell"
import TestcaseCellContent from "./TestcaseCellContent"
import TestcaseRowActionsDropdown from "./TestcaseRowActionsDropdown"
import TestcaseSelectionCell from "./TestcaseSelectionCell"

function getNativeColumnValue(
    record: Record<string, unknown> | null | undefined,
    columnKey: string,
): unknown {
    if (!record) return undefined

    const directValue = record[columnKey]
    if (directValue !== undefined) return directValue

    const parts = columnKey.split(".")
    if (parts.length === 1) return undefined

    let current: unknown = record

    for (const part of parts) {
        if (current === null || current === undefined) return undefined

        if (Array.isArray(current)) {
            const index = Number(part)
            if (!Number.isInteger(index) || String(index) !== part) return undefined
            current = current[index]
            continue
        }

        if (typeof current !== "object") return undefined

        current = (current as Record<string, unknown>)[part]
    }

    return current
}

function GroupToggleButton({
    isCollapsed,
    groupPath,
    onToggle,
}: {
    isCollapsed: boolean
    groupPath: string
    onToggle: () => void
}) {
    return (
        <button
            type="button"
            onClick={(e) => {
                e.stopPropagation()
                e.preventDefault()
                onToggle()
            }}
            aria-label={isCollapsed ? `Expand ${groupPath} group` : `Collapse ${groupPath} group`}
            className="inline-flex h-5 w-5 shrink-0 select-none items-center justify-center rounded border border-[var(--ag-rgba-051729-18)] bg-[var(--ag-c-F5F5F5)] p-0 text-[14px] font-bold leading-none text-[var(--ag-c-051729)] transition-colors hover:border-[var(--ag-c-1677FF)] hover:bg-[var(--ag-c-E6F4FF)] hover:text-[var(--ag-c-1677FF)]"
        >
            {isCollapsed ? "+" : "−"}
        </button>
    )
}

/**
 * Props for TestcasesTableShell component
 */
export interface TestcasesTableShellProps {
    mode: "edit" | "view"
    revisionIdParam: string | undefined
    table: UseTestcasesTableResult
    rowHeight: {
        size: "small" | "medium" | "large"
        heightPx: number
        maxLines: number
        menuItems: TableMenuItem[]
    }
    selectedRowKeys: React.Key[]
    onSelectedRowKeysChange: (keys: React.Key[]) => void
    onRowClick: (record: TestcaseTableRow) => void
    onDeleteSelected: () => void
    searchTerm: string
    onSearchChange: (term: string) => void
    header: React.ReactNode
    actions: React.ReactNode
    /** Checkbox (default) or radio selection */
    selectionType?: "checkbox" | "radio"
    hideControls?: boolean
    enableSelection?: boolean
    autoHeight?: boolean
    disableDeleteAction?: boolean
    /** Show row index instead of checkboxes (still shows dirty indicator) */
    showRowIndex?: boolean
    /** Prefix for scopeId to avoid conflicts when multiple tables use same revisionId */
    scopeIdPrefix?: string
    /** Maximum number of rows to display (for preview mode) */
    maxRows?: number
    /** Optional row refs override for capped previews */
    dataSource?: TestcaseTableRow[]
    /** Callback when add column button is clicked (shown in actions column header) */
    onAddColumn?: () => void
    typeChips?: TypeChipConfig<TestcaseTableRow>
}

/**
 * TestcasesTableShell - Table wrapper with InfiniteVirtualTable configuration
 *
 * Handles:
 * - Table scope configuration
 * - Row selection with dirty state indicators
 * - Column definitions with editable headers
 * - Export configuration
 * - Delete action
 * - Search filter
 * - All table-specific rendering logic
 *
 * @component
 */
export function TestcasesTableShell(props: TestcasesTableShellProps) {
    const {
        mode,
        revisionIdParam,
        table,
        rowHeight,
        selectedRowKeys,
        onSelectedRowKeysChange,
        onRowClick,
        onDeleteSelected,
        searchTerm,
        onSearchChange,
        header,
        actions,
        selectionType = "checkbox",
        hideControls = false,
        enableSelection = mode !== "view",
        autoHeight = true,
        disableDeleteAction = false,
        showRowIndex = false,
        scopeIdPrefix = "testcases",
        maxRows,
        dataSource,
        onAddColumn,
        typeChips,
    } = props

    // Collapsed groups state (using useState for simplicity - persists only during session)
    const [collapsedGroups, setCollapsedGroups] = useState<string[]>([])
    const collapsedGroupsSet = useMemo(() => new Set(collapsedGroups), [collapsedGroups])

    // Toggle collapse state for a group
    const toggleGroupCollapse = useCallback((groupName: string) => {
        setCollapsedGroups((prev) => {
            if (prev.includes(groupName)) {
                return prev.filter((g) => g !== groupName)
            }
            return [...prev, groupName]
        })
    }, [])

    // Table scope configuration
    const tableScope = useMemo<TableScopeConfig>(
        () => ({
            scopeId: `${scopeIdPrefix}-${revisionIdParam}`,
            pageSize: maxRows ?? 50, // Use maxRows if provided, otherwise default to 50
            enableInfiniteScroll: !maxRows, // Disable infinite scroll when maxRows is set
            columnVisibilityStorageKey: "testcases:columns",
            viewportTrackingEnabled: true,
        }),
        [scopeIdPrefix, revisionIdParam, maxRows],
    )

    // Get the global Jotai store so entity atoms are accessible inside the table
    const globalStore = useMemo(() => getDefaultStore(), [])

    // Subscribe to object sub-keys so groupHeaderTypeVariants recomputes when
    // entity data changes (e.g., a column changes from string to native object).
    const entityObjectSubKeys = useAtomValue(objectColumnSubKeysAtom)

    const parentColumnKeys = useMemo(() => {
        const parents = new Set<string>()

        for (const col of table.columns) {
            const parts = col.key.split(".")
            for (let depth = 1; depth < parts.length; depth += 1) {
                parents.add(parts.slice(0, depth).join("."))
            }
        }

        return parents
    }, [table.columns])
    const parentColumnKeysList = useMemo(() => Array.from(parentColumnKeys), [parentColumnKeys])

    // Default `getRowValue` reads native values from the testcase entity layer.
    // Lives in the shell so every consumer (testsets page, modal preview,
    // add-to-testset drawer preview) gets type chips out of the box, instead
    // of each call site having to duplicate the wiring.
    //
    // Keep chip sampling on the runtime value as-is: stringified JSON is still
    // a string and must not be treated as a nested object.
    const defaultGetRowValue = useCallback(
        (record: TestcaseTableRow, columnKey: string): unknown => {
            const rowId = record.id ?? String(record.key)
            const entity = globalStore.get(testcaseEntityAtomFamily(rowId))
            return getNativeColumnValue(extractTestcaseUserData(entity), columnKey)
        },
        [globalStore],
    )

    const defaultTypeChips = useMemo<TypeChipConfig<TestcaseTableRow>>(
        () => ({
            defaultEnabled: true,
            storageKey: "agenta:testcase-table:type-chips-enabled",
            getRowValue: defaultGetRowValue,
        }),
        [defaultGetRowValue],
    )

    const effectiveTypeChips = typeChips ?? defaultTypeChips

    const tableTypeChipsConfig = useMemo<TypeChipConfig<TestcaseTableRow>>(
        () => ({
            ...effectiveTypeChips,
            resolveHeaderVariant: (columnKey, typeInfo) => {
                if (parentColumnKeys.has(columnKey)) return undefined
                return effectiveTypeChips.resolveHeaderVariant
                    ? effectiveTypeChips.resolveHeaderVariant(columnKey, typeInfo)
                    : defaultHeaderVariant(columnKey, typeInfo)
            },
        }),
        [parentColumnKeys, effectiveTypeChips],
    )

    const typeChipFeature = useTypeChipFeature(tableTypeChipsConfig)
    const showTypeChips = typeChipFeature.enabled

    const rowsForTypeChips = dataSource ?? table.rowRefs

    const groupHeaderTypeVariants = useMemo(() => {
        const variants = new Map<string, ChipVariant>()
        const resolvedTypeChips = typeChipFeature.typeChips

        if (!showTypeChips || !resolvedTypeChips || parentColumnKeysList.length === 0) {
            return variants
        }

        const sample = rowsForTypeChips
            .filter((record) => !record.__isSkeleton)
            .slice(0, 30) as TestcaseTableRow[]
        if (sample.length === 0) return variants

        const rows = sample.map((record) => {
            const row: Record<string, unknown> = {}
            for (const key of parentColumnKeysList) {
                row[key] = resolvedTypeChips.getRowValue(record, key)
            }
            return row
        })
        const columnTypes = detectColumnTypes(rows, parentColumnKeysList)

        for (const key of parentColumnKeysList) {
            const typeInfo = columnTypes.get(key)
            const variant = effectiveTypeChips.resolveHeaderVariant
                ? effectiveTypeChips.resolveHeaderVariant(key, typeInfo)
                : defaultHeaderVariant(key, typeInfo)
            if (variant) variants.set(key, variant)
        }

        return variants
    }, [
        effectiveTypeChips,
        parentColumnKeysList,
        rowsForTypeChips,
        showTypeChips,
        typeChipFeature.typeChips,
        entityObjectSubKeys,
    ])

    const settingsMenuItems = useMemo<TableMenuItem[]>(
        () => rowHeight.menuItems,
        [rowHeight.menuItems],
    )

    // Row selection configuration with dirty indicator
    const rowSelection = useMemo(
        () =>
            enableSelection
                ? {
                      selectedRowKeys: showRowIndex ? [] : selectedRowKeys,
                      onChange: showRowIndex ? undefined : onSelectedRowKeysChange,
                      type: selectionType,
                      hideSelectAll: selectionType === "radio",
                      columnWidth: 48,
                      fixed: "left" as const,
                      columnTitle: showRowIndex ? (
                          <span className="text-xs text-gray-500">#</span>
                      ) : undefined,
                      // Dirty indicator background is now handled reactively in TestcaseSelectionCell
                      renderCell: (
                          _value: boolean,
                          record: TestcaseTableRow,
                          index: number,
                          originNode: React.ReactNode,
                      ) =>
                          showRowIndex ? (
                              <TestcaseSelectionCell
                                  testcaseId={record.id}
                                  rowIndex={index}
                                  mode={mode}
                                  originNode={
                                      <span className="text-xs text-gray-500">{index + 1}</span>
                                  }
                              />
                          ) : (
                              <TestcaseSelectionCell
                                  testcaseId={record.id}
                                  rowIndex={index}
                                  mode={mode}
                                  originNode={originNode}
                              />
                          ),
                  }
                : undefined,
        [
            enableSelection,
            selectedRowKeys,
            onSelectedRowKeysChange,
            globalStore,
            showRowIndex,
            mode,
        ],
    )

    // Max lines from row height config (already computed by useRowHeight)
    const maxLinesForRowHeight = rowHeight.maxLines

    // Skeleton columns to show while loading (when actual columns are empty)
    const skeletonColumns = useMemo(
        () => [
            {key: "__skeleton_1", name: "--"},
            {key: "__skeleton_2", name: "--"},
            {key: "__skeleton_3", name: "--"},
        ],
        [],
    )

    // Empty state columns - shown when user has no data (not loading)
    const emptyStateColumns = useMemo(() => [{key: "__empty", name: "No columns yet"}], [])

    // Handle group column rename - renames all nested columns
    const handleGroupRename = useCallback(
        (groupPath: string, newName: string): boolean => {
            const trimmedName = newName.trim()
            if (!trimmedName) return false

            const parentPath = groupPath.includes(".")
                ? groupPath.substring(0, groupPath.lastIndexOf("."))
                : ""
            const targetGroupPath =
                trimmedName.includes(".") || !parentPath
                    ? trimmedName
                    : `${parentPath}.${trimmedName}`

            const columnsInGroup = table.columns.filter((col) =>
                col.key.startsWith(groupPath + "."),
            )

            if (columnsInGroup.length === 0) return false

            const renames = columnsInGroup.map((col) => {
                const relativePath = col.key.substring(groupPath.length)
                return {
                    oldKey: col.key,
                    newKey: `${targetGroupPath}${relativePath}`,
                }
            })

            const targetKeys = new Set<string>()
            for (const {newKey} of renames) {
                if (targetKeys.has(newKey)) return false
                targetKeys.add(newKey)
            }

            const sourceKeys = new Set(renames.map(({oldKey}) => oldKey))
            const hasConflict = table.columns.some(
                (col) => targetKeys.has(col.key) && !sourceKeys.has(col.key),
            )
            if (hasConflict) return false

            // Rename each nested column
            let allSucceeded = true
            renames.forEach(({oldKey, newKey}) => {
                const success = table.renameColumn(oldKey, newKey)
                if (!success) allSucceeded = false
            })

            return allSucceeded
        },
        [table],
    )

    // Handle group column delete - deletes all nested columns
    const handleGroupDelete = useCallback(
        (groupPath: string) => {
            // Get all columns that belong to this group
            const columnsInGroup = table.columns.filter((col) =>
                col.key.startsWith(groupPath + "."),
            )

            // Delete each nested column
            columnsInGroup.forEach((col) => {
                table.deleteColumn(col.key)
            })
        },
        [table],
    )

    // Columns definition
    // Use TestcaseCell for entity-aware rendering (reads from entity atoms in global store)
    // Supports grouped columns (e.g., "group.column" renders under "group" header)
    const columns = useMemo<ColumnDefs<TestcaseTableRow>>(() => {
        const isEditable = mode === "edit"

        const getRenamedColumnKey = (col: Column, newName: string) => {
            const trimmedName = newName.trim()

            if (!trimmedName) {
                return trimmedName
            }

            if (
                "parentKey" in col &&
                typeof col.parentKey === "string" &&
                !trimmedName.includes(".")
            ) {
                return `${col.parentKey}.${trimmedName}`
            }

            return trimmedName
        }

        // Differentiate between loading state and empty state
        const hasNoColumns = table.columns.length === 0
        const isActuallyLoading = table.isLoading

        // Use skeleton columns only when loading, empty state columns when truly empty
        const columnsToRender = hasNoColumns
            ? isActuallyLoading
                ? skeletonColumns
                : emptyStateColumns
            : table.columns

        const isShowingSkeleton = hasNoColumns && isActuallyLoading
        const isShowingEmpty = hasNoColumns && !isActuallyLoading

        // Create column definition for a single column
        // Wrap title with ColumnVisibilityHeader to enable viewport tracking
        const createColumnDef = (
            col: Column,
            displayName: string,
        ): ColumnDef<TestcaseTableRow> => ({
            key: col.key,
            dataIndex: col.key,
            title:
                isEditable && !isShowingSkeleton && !isShowingEmpty ? (
                    <EditableColumnHeader
                        columnKey={col.key}
                        columnName={displayName}
                        onRename={(_oldName, newName) =>
                            table.renameColumn(col.key, getRenamedColumnKey(col, newName))
                        }
                        onDelete={table.deleteColumn}
                    />
                ) : (
                    <span className="truncate" title={col.key}>
                        {displayName}
                    </span>
                ),
            width: 200,
            render: (value: unknown, record: TestcaseTableRow) => {
                // Show skeleton for skeleton rows or when showing skeleton columns
                if (record.__isSkeleton || isShowingSkeleton) {
                    // Use row height to determine skeleton height (subtract padding)
                    const skeletonHeight = Math.max(24, rowHeight.heightPx - 32)
                    return (
                        <Skeleton.Input
                            active
                            size="small"
                            className="w-full"
                            style={{height: skeletonHeight, minHeight: skeletonHeight}}
                        />
                    )
                }
                // Show empty state message when no columns exist (not loading)
                if (isShowingEmpty) {
                    return (
                        <div className="flex items-center justify-center h-full text-gray-400 text-sm">
                            Add a column to get started
                        </div>
                    )
                }
                // For rows with id (both new and server rows), use entity-aware cell
                // This ensures column renames are reflected correctly
                const rowId = record.id || String(record.key)
                if (rowId) {
                    return (
                        <TestcaseCell
                            key={`${rowId}-${col.key}`}
                            testcaseId={rowId}
                            columnKey={col.key}
                            maxLines={maxLinesForRowHeight}
                        />
                    )
                }
                // Fallback for rows without id
                return (
                    <TestcaseCellContent
                        value={value}
                        columnKey={col.key}
                        maxLines={maxLinesForRowHeight}
                    />
                )
            },
        })

        // Create collapsed column definition (shows full JSON when group is collapsed)
        // groupPath is the full path (e.g., "current_rfp.event"), display only the last segment
        const createCollapsedColumnDef = (
            groupPath: string,
            _childColumns: Column[],
        ): ColumnDef<TestcaseTableRow> => {
            const displayName = groupPath.includes(".")
                ? groupPath.substring(groupPath.lastIndexOf(".") + 1)
                : groupPath
            const typeChipVariant = groupHeaderTypeVariants.get(groupPath)

            return {
                key: groupPath,
                dataIndex: groupPath,
                title: (
                    <div className="flex items-center gap-1.5 w-full max-w-full overflow-hidden">
                        <GroupToggleButton
                            isCollapsed
                            groupPath={groupPath}
                            onToggle={() => toggleGroupCollapse(groupPath)}
                        />
                        <div className="flex-1 min-w-0">
                            <EditableColumnHeader
                                columnKey={groupPath}
                                columnName={displayName}
                                onRename={(oldName, newName) => handleGroupRename(groupPath, newName)} // prettier-ignore
                                onDelete={() => handleGroupDelete(groupPath)}
                                disabled={!isEditable}
                                inlineActionsMinWidth={80}
                            />
                        </div>
                        {showTypeChips && typeChipVariant && <TypeChip variant={typeChipVariant} />}
                    </div>
                ),
                width: 200,
                render: (_value: unknown, record: TestcaseTableRow) => {
                    if (record.__isSkeleton || isShowingSkeleton) {
                        const skeletonHeight = Math.max(24, rowHeight.heightPx - 32)
                        return (
                            <Skeleton.Input
                                active
                                size="small"
                                className="w-full"
                                style={{height: skeletonHeight, minHeight: skeletonHeight}}
                            />
                        )
                    }
                    if (isShowingEmpty) {
                        return (
                            <div className="flex items-center justify-center h-full text-gray-400 text-sm">
                                Add a column to get started
                            </div>
                        )
                    }
                    const rowId = record.id || String(record.key)
                    if (rowId) {
                        // Show the parent column value.
                        return (
                            <TestcaseCell
                                key={`${rowId}-${groupPath}`}
                                testcaseId={rowId}
                                columnKey={groupPath}
                                maxLines={maxLinesForRowHeight}
                            />
                        )
                    }
                    return null
                },
            }
        }

        // Render group header with collapse/expand icon and editable controls
        // groupPath is the full path (e.g., "current_rfp.event"), display only the last segment
        // Wrapped with ColumnVisibilityHeader for viewport tracking
        const renderGroupHeader = (groupPath: string, isCollapsed: boolean, childCount: number) => {
            // Get just the last segment for display (e.g., "event" from "current_rfp.event")
            const displayName = groupPath.includes(".")
                ? groupPath.substring(groupPath.lastIndexOf(".") + 1)
                : groupPath
            const typeChipVariant = groupHeaderTypeVariants.get(groupPath)

            return (
                <div className="flex items-center gap-1.5 w-full max-w-full overflow-hidden">
                    <GroupToggleButton
                        isCollapsed={isCollapsed}
                        groupPath={groupPath}
                        onToggle={() => toggleGroupCollapse(groupPath)}
                    />
                    <div className="flex-1 min-w-0">
                        <EditableColumnHeader
                            columnKey={groupPath}
                            columnName={displayName}
                            onRename={(oldName, newName) => handleGroupRename(groupPath, newName)} // prettier-ignore
                            onDelete={() => handleGroupDelete(groupPath)}
                            disabled={!isEditable}
                            inlineActionsMinWidth={80}
                        />
                    </div>
                    {showTypeChips && typeChipVariant && <TypeChip variant={typeChipVariant} />}
                    <span className="text-gray-400 text-xs flex-shrink-0">({childCount})</span>
                </div>
            )
        }

        // Group columns that have "." in their key (e.g., "inputs.country" groups under "inputs")
        const dataColumns = groupColumns<TestcaseTableRow>(columnsToRender, createColumnDef, {
            collapsedGroups: collapsedGroupsSet,
            onGroupHeaderClick: toggleGroupCollapse,
            renderGroupHeader,
            createCollapsedColumnDef,
        })

        if (mode === "view") {
            return [...dataColumns]
        }

        if (hideControls) {
            return [...dataColumns]
        }

        // Custom actions column with Add Column button in header
        const actionsColumn: ExtendedColumn<TestcaseTableRow>[] = [
            {
                title: (
                    <div className="flex items-center gap-1 justify-end">
                        {onAddColumn && mode === "edit" && (
                            <Tooltip title="Add column">
                                <Button
                                    type="text"
                                    size="small"
                                    icon={<PlusOutlined />}
                                    onClick={(e) => {
                                        e.stopPropagation()
                                        onAddColumn()
                                    }}
                                />
                            </Tooltip>
                        )}
                        <ColumnVisibilityMenuTrigger variant="icon" />
                    </div>
                ),
                key: "__ui_actions__", // Use reserved key to avoid conflict with user data columns
                width: 56,
                fixed: "right",
                align: "center",
                columnVisibilityLocked: true,
                exportEnabled: false, // Exclude from client-side CSV export
                onCell: () => ({className: "ag-table-actions-cell"}),
                render: (_, record) => {
                    if (record.__isSkeleton || isShowingSkeleton) return null

                    return (
                        <div
                            className="w-full h-full flex items-center justify-center"
                            onClick={(e) => e.stopPropagation()}
                        >
                            <TestcaseRowActionsDropdown
                                testcaseId={record.id ? String(record.id) : String(record.key)}
                                onEdit={() => {
                                    if (record.id) onRowClick(record)
                                }}
                                onDelete={() => {
                                    if (record.key) {
                                        table.deleteTestcases([String(record.key)])
                                    }
                                }}
                            />
                        </div>
                    )
                },
            },
        ]

        return [...dataColumns, ...actionsColumn]
    }, [
        table.columns,
        table.isLoading,
        table.renameColumn,
        table.deleteColumn,
        table.deleteTestcases,
        mode,
        maxLinesForRowHeight,
        rowHeight.heightPx,
        skeletonColumns,
        emptyStateColumns,
        onRowClick,
        hideControls,
        collapsedGroupsSet,
        toggleGroupCollapse,
        onAddColumn,
        handleGroupRename,
        handleGroupDelete,
        showTypeChips,
        groupHeaderTypeVariants,
    ])

    // Delete action
    const deleteAction = useMemo(
        () =>
            disableDeleteAction
                ? undefined
                : {
                      onDelete: onDeleteSelected,
                      disabled: selectedRowKeys.length === 0 || mode === "view",
                      disabledTooltip: "Select testcases to delete",
                  },
        [disableDeleteAction, onDeleteSelected, selectedRowKeys.length, mode],
    )

    // Table props
    const tableProps = useMemo(
        () => ({
            size: "small" as const,
            bordered: true,
            onRow: (record: TestcaseTableRow) => ({
                onClick: () => onRowClick(record),
                className: "cursor-pointer hover:bg-gray-50",
            }),
        }),
        [onRowClick],
    )

    // Filters
    const filters = useMemo(
        () =>
            hideControls ? null : (
                <Input
                    allowClear
                    placeholder="Search testcases..."
                    className="w-64"
                    value={searchTerm}
                    onChange={(e) => onSearchChange(e.target.value)}
                />
            ),
        [hideControls, searchTerm, onSearchChange],
    )

    return (
        <InfiniteVirtualTableFeatureShell<TestcaseTableRow>
            datasetStore={testcasesDatasetStore}
            tableScope={tableScope}
            columns={columns}
            rowKey="key"
            title={header}
            filters={filters || undefined}
            primaryActions={hideControls ? undefined : actions}
            deleteAction={hideControls ? undefined : deleteAction}
            enableExport={false}
            autoHeight={autoHeight}
            rowHeight={rowHeight.heightPx}
            fallbackControlsHeight={96}
            fallbackHeaderHeight={48}
            tableClassName={clsx(
                "agenta-testcase-table",
                `agenta-testcase-table--row-${rowHeight.size}`,
            )}
            tableProps={tableProps}
            rowSelection={rowSelection}
            useSettingsDropdown={!hideControls}
            settingsDropdownMenuItems={hideControls ? undefined : settingsMenuItems}
            dataSource={dataSource}
            store={globalStore}
            typeChips={typeChipFeature.typeChips}
        />
    )
}
