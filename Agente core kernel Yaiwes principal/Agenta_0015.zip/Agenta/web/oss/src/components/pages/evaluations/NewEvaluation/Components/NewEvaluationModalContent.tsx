import {type FC, memo, useCallback, useMemo} from "react"

import {workflowMolecule} from "@agenta/entities/workflow"
import {createEvaluatorFromTemplate, type EvaluatorCatalogTemplate} from "@agenta/entities/workflow"
import {message} from "@agenta/ui/app-message"
import {CloseCircleOutlined} from "@ant-design/icons"
import {Input, Tabs, Tag, Typography} from "antd"
import clsx from "clsx"
import {useAtomValue, useSetAtom} from "jotai"
import dynamic from "next/dynamic"

import {openHumanEvaluatorDrawerAtom} from "@/oss/components/Evaluators/Drawers/HumanEvaluatorDrawer/store"
import useFocusInput from "@/oss/hooks/useFocusInput"
import {openEvaluatorDrawerAtom} from "@/oss/state/evaluator/evaluatorDrawerStore"

import TabLabel from "../assets/TabLabel"
import {NewEvaluationModalContentProps} from "../types"

const tabsContainerClass =
    "h-full flex [&_.ant-tabs-content-holder]:pl-4 [&_.ant-tabs-content-holder]:flex-1 " +
    "[&_.ant-tabs-content-holder]:overflow-auto [&_.ant-tabs-tab]:text-colorTextSecondary " +
    // hover must sit INSIDE the arbitrary variant: `[&_x]:hover:` compiles to `.cls:hover x`
    "[&_.ant-tabs-tab:hover]:bg-colorInfoBg [&_.ant-tabs-ink-bar]:hidden " +
    "[&_.ant-tabs-tab-active]:bg-controlItemBgActive " +
    "[&_.ant-tabs-tab-active]:[border-right:2px_solid_var(--ag-colorPrimary)] " +
    "[&_.ant-tabs-tab-active]:text-colorPrimary [&_.ant-tabs-tab-active]:!font-medium"

const SelectWorkflowSection = dynamic(() => import("./SelectWorkflowSection"), {ssr: false})

const SelectEvaluatorSection = dynamic(
    () => import("./SelectEvaluatorSection/SelectEvaluatorSection"),
    {ssr: false},
)

const SelectTestsetSection = dynamic(() => import("./SelectTestsetSection"), {
    ssr: false,
})

const SelectVariantSection = dynamic(() => import("./SelectVariantSection"), {
    ssr: false,
})

const AdvancedSettings = dynamic(() => import("./AdvancedSettings"), {
    ssr: false,
})

interface SelectedRevisionLike {
    id?: string | null
    name?: string | null
    version?: number | null
}

/**
 * Variant tag label. The display name lives on the VARIANT (fall back to its
 * slug): SDK-created variants and revisions may carry no `name` at all, and
 * UI-created revisions are named after the variant.
 */
const RevisionTagLabel = memo(({revision}: {revision: SelectedRevisionLike}) => {
    const variantLabel = useAtomValue(workflowMolecule.selectors.variantLabel(revision.id ?? ""))
    const label = variantLabel ?? revision.name ?? "-"
    return <>{`${label} - v${revision.version ?? 0}`}</>
})

/**
 * Evaluator tag label. The entity display name lives on the workflow artifact;
 * the revision's own `name` carries the variant name ("default").
 */
const EvaluatorTagLabel = memo(
    ({cfg}: {cfg: {id: string; name?: string | null; version?: number | null}}) => {
        const artifactName = useAtomValue(workflowMolecule.selectors.artifactName(cfg.id))
        return <>{`${artifactName ?? cfg.name ?? "-"} - v${cfg.version ?? 0}`}</>
    },
)

const NewEvaluationModalContent: FC<NewEvaluationModalContentProps> = ({
    onSuccess,
    handlePanelChange,
    activePanel,
    selectedTestsetId,
    selectedTestsetRevisionId,
    selectedTestsetName,
    selectedTestsetVersion,
    setSelectedTestsetId,
    setSelectedTestsetRevisionId,
    setSelectedTestsetName,
    setSelectedTestsetVersion,
    selectedVariantRevisionIds,
    setSelectedVariantRevisionIds,
    selectedEvalConfigs,
    setSelectedEvalConfigs,
    evaluationName,
    setEvaluationName,
    preview,
    evaluationType,
    testsets,
    evaluators,
    evaluatorConfigs,
    advanceSettings,
    setAdvanceSettings,
    appOptions,
    selectedAppId,
    onSelectApp,
    appSelectionDisabled,
    allowTestsetAutoAdvance,
    onSelectTemplate,
    onEvaluatorCreated,
    ...props
}) => {
    const {inputRef} = useFocusInput({isOpen: props.isOpen || false})
    const appSelectionComplete = Boolean(selectedAppId)

    const openEvaluatorDrawer = useSetAtom(openEvaluatorDrawerAtom)
    const openHumanDrawer = useSetAtom(openHumanEvaluatorDrawerAtom)

    // Handler for opening the human evaluator creation drawer (preview mode)
    const handleCreateHumanEvaluator = useCallback(() => {
        openHumanDrawer({mode: "create", onSuccess: onEvaluatorCreated})
    }, [openHumanDrawer, onEvaluatorCreated])

    // Handler for opening the evaluator creation drawer with embedded playground
    const handleSelectTemplate = useCallback(
        // EvaluatorTemplateDropdown (via SelectEvaluatorSection) emits catalog templates
        async (evaluator: EvaluatorCatalogTemplate) => {
            const templateKey = evaluator.key
            if (!templateKey) {
                message.error("Unable to open evaluator template")
                return
            }

            const localId = await createEvaluatorFromTemplate(templateKey)
            if (!localId) {
                message.error("Unable to create evaluator from template")
                return
            }

            openEvaluatorDrawer({
                entityId: localId,
                mode: "create",
                onEvaluatorCreated,
            })
            onSelectTemplate?.(evaluator)
        },
        [openEvaluatorDrawer, onSelectTemplate, onEvaluatorCreated],
    )

    const selectedVariants = useMemo(
        () =>
            selectedVariantRevisionIds
                .map((id) => workflowMolecule.get.data(id))
                .filter((w): w is NonNullable<typeof w> => Boolean(w)),
        [selectedVariantRevisionIds],
    )

    const selectedEvalConfig = useMemo(
        () =>
            selectedEvalConfigs
                .map((id) => workflowMolecule.get.data(id))
                .filter((w): w is NonNullable<typeof w> => Boolean(w)),
        [selectedEvalConfigs],
    )

    const items = useMemo(() => {
        const requireAppMessage = (
            <Typography.Text type="secondary">
                Select an application first to load this section.
            </Typography.Text>
        )

        return [
            {
                key: "appPanel",
                label: (
                    <TabLabel tabTitle="Application" completed={appSelectionComplete}>
                        {appSelectionComplete && (
                            <Tag
                                closeIcon={<CloseCircleOutlined />}
                                onClose={() => {
                                    if (!appSelectionDisabled) onSelectApp("")
                                }}
                            >
                                {appOptions.find((opt) => opt.value === selectedAppId)?.label ??
                                    selectedAppId}
                            </Tag>
                        )}
                    </TabLabel>
                ),
                children: (
                    <div className="flex flex-col gap-2">
                        <SelectWorkflowSection
                            selectedWorkflowId={selectedAppId}
                            onSelectWorkflow={onSelectApp}
                            disabled={appSelectionDisabled}
                        />
                        {!appSelectionComplete && !appSelectionDisabled ? (
                            <Typography.Text type="secondary">
                                Please select an application to continue configuring the evaluation.
                            </Typography.Text>
                        ) : null}
                    </div>
                ),
            },
            {
                key: "variantPanel",
                label: (
                    <TabLabel tabTitle="Revision" completed={selectedVariants.length > 0}>
                        {selectedVariants.map((v) => (
                            <Tag
                                key={v.id}
                                closeIcon={<CloseCircleOutlined />}
                                onClose={() => {
                                    setSelectedVariantRevisionIds(
                                        selectedVariantRevisionIds.filter((id) => id !== v.id),
                                    )
                                }}
                            >
                                <RevisionTagLabel revision={v} />
                            </Tag>
                        ))}
                    </TabLabel>
                ),
                children: appSelectionComplete ? (
                    <SelectVariantSection
                        handlePanelChange={handlePanelChange}
                        selectedVariantRevisionIds={selectedVariantRevisionIds}
                        setSelectedVariantRevisionIds={setSelectedVariantRevisionIds}
                        evaluationType={evaluationType}
                        className="pt-2"
                    />
                ) : (
                    requireAppMessage
                ),
            },
            {
                key: "testsetPanel",
                label: (
                    <TabLabel tabTitle="Test set" completed={Boolean(selectedTestsetName)}>
                        {selectedTestsetName ? (
                            <Tag
                                closeIcon={<CloseCircleOutlined />}
                                onClose={() => {
                                    setSelectedTestsetId("")
                                    setSelectedTestsetRevisionId("")
                                    setSelectedTestsetName("")
                                    setSelectedTestsetVersion(null)
                                }}
                            >
                                <span>{selectedTestsetName} -</span>
                                {typeof selectedTestsetVersion === "number" && (
                                    <span className="ml-1 text-xs text-gray-500">
                                        v{selectedTestsetVersion}
                                    </span>
                                )}
                            </Tag>
                        ) : null}
                    </TabLabel>
                ),
                children: appSelectionComplete ? (
                    <SelectTestsetSection
                        handlePanelChange={handlePanelChange}
                        selectedTestsetId={selectedTestsetId}
                        selectedTestsetRevisionId={selectedTestsetRevisionId}
                        selectedTestsetName={selectedTestsetName}
                        selectedTestsetVersion={selectedTestsetVersion}
                        setSelectedTestsetId={setSelectedTestsetId}
                        setSelectedTestsetRevisionId={setSelectedTestsetRevisionId}
                        setSelectedTestsetName={setSelectedTestsetName}
                        setSelectedTestsetVersion={setSelectedTestsetVersion}
                        testsets={testsets}
                        selectedVariantRevisionIds={selectedVariantRevisionIds}
                        selectedVariants={selectedVariants}
                        className="pt-2"
                        allowAutoAdvance={allowTestsetAutoAdvance}
                    />
                ) : (
                    requireAppMessage
                ),
            },
            {
                key: "evaluatorPanel",
                label: (
                    <TabLabel tabTitle="Evaluators" completed={selectedEvalConfig.length > 0}>
                        {selectedEvalConfig.map((cfg) => {
                            return (
                                <Tag
                                    key={cfg.id}
                                    closeIcon={<CloseCircleOutlined />}
                                    onClose={() => {
                                        setSelectedEvalConfigs(
                                            selectedEvalConfigs.filter((id) => id !== cfg.id),
                                        )
                                    }}
                                >
                                    <EvaluatorTagLabel cfg={cfg} />
                                </Tag>
                            )
                        })}
                    </TabLabel>
                ),
                children: appSelectionComplete ? (
                    <SelectEvaluatorSection
                        selectedEvalConfigs={selectedEvalConfigs}
                        setSelectedEvalConfigs={setSelectedEvalConfigs}
                        preview={preview}
                        selectedAppId={selectedAppId}
                        onSelectTemplate={handleSelectTemplate}
                        onCreateHumanEvaluator={handleCreateHumanEvaluator}
                        className="pt-2"
                    />
                ) : (
                    requireAppMessage
                ),
            },
            ...(evaluationType === "auto"
                ? [
                      {
                          key: "advancedSettingsPanel",
                          label: (
                              <TabLabel tabTitle="Advanced Settings" completed={true}>
                                  {Object.entries(advanceSettings).map(([key, value]) => (
                                      <Tag key={key} className="max-w-[200px] truncate">
                                          {key}: {value}
                                      </Tag>
                                  ))}
                              </TabLabel>
                          ),
                          children: appSelectionComplete ? (
                              <AdvancedSettings
                                  advanceSettings={advanceSettings}
                                  setAdvanceSettings={setAdvanceSettings}
                              />
                          ) : (
                              requireAppMessage
                          ),
                      },
                  ]
                : []),
        ]
    }, [
        selectedTestsetName,
        selectedVariants,
        selectedEvalConfig,
        handlePanelChange,
        selectedTestsetId,
        selectedVariantRevisionIds,
        selectedEvalConfigs,
        preview,
        evaluationType,
        testsets,
        evaluators,
        evaluatorConfigs,
        advanceSettings,
        appSelectionComplete,
        appOptions,
        selectedAppId,
        onSelectApp,
        appSelectionDisabled,
        handleSelectTemplate,
        handleCreateHumanEvaluator,
        allowTestsetAutoAdvance,
    ])

    return (
        <div className="flex flex-col w-full gap-4 h-full max-h-full overflow-hidden [&_.ant-tabs]:!flex [&_.ant-tabs]:!w-full [&_.ant-tabs]:!grow [&_.ant-tabs]:!min-h-0">
            <div className="flex flex-col gap-2">
                <Typography.Text className="font-medium">Evaluation name</Typography.Text>
                <Input
                    ref={inputRef}
                    placeholder="Enter a name"
                    value={evaluationName}
                    onChange={(e) => {
                        setEvaluationName(e.target.value)
                    }}
                    data-tour="evaluation-name-input"
                />
            </div>

            <Tabs
                activeKey={activePanel || "appPanel"}
                onChange={handlePanelChange as any}
                items={items}
                tabPlacement="start" // antd 6 logical value; "start" === "left" (app is LTR-only)
                className={clsx([
                    tabsContainerClass,
                    "[&_.ant-tabs-tab]:!p-2 [&_.ant-tabs-tab]:!mt-1",
                    "[&_.ant-tabs-nav]:!w-[240px]",
                    "[&_.ant-tabs-content]:!h-full [&_.ant-tabs-content]:!w-full",
                    "[&_.ant-tabs-tabpane]:!h-full [&_.ant-tabs-tabpane]:!max-h-full [&_.ant-tabs-tabpane]:!w-full",
                ])}
            />
        </div>
    )
}

export default memo(NewEvaluationModalContent)
