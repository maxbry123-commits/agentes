import {useCallback, memo, useEffect, useLayoutEffect, useMemo, useRef, useState} from "react"

import {useVaultSecret} from "@agenta/entities/secret"
import {extractSourceIdFromDraft, isLocalDraftId, isValidUUID} from "@agenta/entities/shared"
import {
    workflowMolecule,
    workflowRevisionsByWorkflowListDataAtomFamily,
} from "@agenta/entities/workflow"
import {
    evaluatorConfigsListDataAtom,
    evaluatorConfigsQueryStateAtom,
    evaluatorTemplatesDataAtom,
    evaluatorTemplatesQueryAtom,
    evaluatorsListDataAtom,
    evaluatorsListQueryAtom,
    humanEvaluatorsListDataAtom,
    invalidateWorkflowsListCache,
    invalidateEvaluatorsListCache,
} from "@agenta/entities/workflow"
import {message} from "@agenta/ui/app-message"
import {useAtom, useAtomValue, useSetAtom} from "jotai"
import dynamic from "next/dynamic"
import {useRouter} from "next/router"

import {
    clearEvaluatorWorkflowCache,
    evaluatorsPaginatedStore,
} from "@/oss/components/Evaluators/store/evaluatorsPaginatedStore"
import {FIRST_EVALUATION_TOUR_ID} from "@/oss/components/Onboarding/tours/firstEvaluationTour"
import {registryWorkflowIdOverrideAtom} from "@/oss/components/VariantsComponents/store/registryStore"
import useURL from "@/oss/hooks/useURL"
import {resolveEvaluatorKey} from "@/oss/lib/evaluators/utils"
import {redirectIfNoLLMKeys} from "@/oss/lib/helpers/utils"
import usePreviewEvaluations from "@/oss/lib/hooks/usePreviewEvaluations"
import {activeTourIdAtom, currentStepStateAtom} from "@/oss/lib/onboarding"
import {createEvaluation} from "@/oss/services/evaluations/api"
import {useAppsData} from "@/oss/state/app/hooks"
import {appIdentifiersAtom} from "@/oss/state/appState"
import {testsetsListQueryAtomFamily} from "@/oss/state/entities/testset"

import {buildEvaluationNavigationUrl} from "../../utils"
import {DEFAULT_ADVANCE_SETTINGS} from "../assets/constants"
import {newEvaluationActivePanelAtom} from "../state/panel"
import {
    selectedEvalConfigsAtom,
    selectedTestsetIdAtom,
    selectedTestsetNameAtom,
    selectedTestsetRevisionIdAtom,
    selectedTestsetVersionAtom,
} from "../state/selection"
import type {EvaluationConcurrencySettings, NewEvaluationModalInnerProps} from "../types"

const NewEvaluationModalContent = dynamic(() => import("./NewEvaluationModalContent"), {
    ssr: false,
})

/**
 * Inner component that contains all the heavy logic for the NewEvaluationModal.
 * This component only mounts when the modal is open, preventing unnecessary
 * data fetching and state initialization when the modal is closed.
 */
/** Determines which panel to show initially based on preselection and app scope */
const getInitialPanel = (hasPreSelected: boolean, isAppScoped: boolean): string =>
    hasPreSelected ? "testsetPanel" : isAppScoped ? "variantPanel" : "appPanel"

const NewEvaluationModalInner = ({
    onSuccess,
    preview,
    evaluationType,
    onSubmitStateChange,
    preSelectedVariantIds,
    preSelectedAppId,
}: NewEvaluationModalInnerProps) => {
    // Use appIdentifiersAtom directly to get the URL-derived appId without fallback to stale values
    const {appId} = useAtomValue(appIdentifiersAtom)
    // Phase 6.1.3 defensive guard: if a preselect ID matches an evaluator
    // workflow, ignore it. Belt-and-suspenders with the Phase 6.1.2 fix that
    // hides RunEvaluationButton for evaluators — but covers any other call site
    // (e.g., a stale cache or programmatic open) that might still pass an
    // evaluator ID. Without this, the modal silently defaults to "no app
    // selected" which is confusing.
    const evaluatorWorkflows = useAtomValue(evaluatorsListDataAtom)
    const sanitizedPreSelectedAppId = useMemo(() => {
        if (!preSelectedAppId) return undefined
        const isEvaluator = evaluatorWorkflows.some((e) => e.id === preSelectedAppId)
        if (isEvaluator) {
            if (process.env.NODE_ENV !== "production") {
                console.warn(
                    `[NewEvaluationModal] preSelectedAppId resolves to an evaluator workflow (${preSelectedAppId}) — ignoring.`,
                )
            }
            return undefined
        }
        return preSelectedAppId
    }, [preSelectedAppId, evaluatorWorkflows])
    // Consider pre-selected app ID from playground, fallback to URL-derived appId
    const effectiveAppId = sanitizedPreSelectedAppId || appId || ""
    const isAppScoped = Boolean(effectiveAppId)
    const {apps: availableApps = []} = useAppsData()
    const [selectedAppId, setSelectedAppId] = useState<string>(effectiveAppId)
    // Name/kind captured when the user picks a workflow from the table so the
    // panel tag stays readable even for evaluators (not present in `availableApps`).
    const [selectedWorkflowMeta, setSelectedWorkflowMeta] = useState<{
        label?: string
        isEvaluator?: boolean
    } | null>(null)
    const setRegistryWorkflowIdOverride = useSetAtom(registryWorkflowIdOverrideAtom)

    // Sync the registry store's workflow ID override with the modal's selected app.
    // This allows the variant table to work on project-level pages where routerAppIdAtom is null.
    useEffect(() => {
        setRegistryWorkflowIdOverride(selectedAppId || null)
        return () => {
            setRegistryWorkflowIdOverride(null)
        }
    }, [selectedAppId, setRegistryWorkflowIdOverride])
    const appOptions = useMemo(() => {
        const options = availableApps.map((app) => ({
            label: app.name ?? app.slug ?? "",
            value: app.id,
            type: app.flags?.is_custom
                ? "custom"
                : app.flags?.is_chat
                  ? "chat"
                  : ("completion" as string | null),
            createdAt: app.created_at ?? null,
            updatedAt: app.updated_at ?? null,
        }))
        if (selectedAppId && !options.some((opt) => opt.value === selectedAppId)) {
            // Evaluators (and locally-picked workflows) aren't in useAppsData.
            // When the user picked a row we have `selectedWorkflowMeta`; for an
            // app-scoped EVALUATOR route there's no meta, so resolve the name
            // (and kind) from the evaluators list — otherwise the Application
            // panel renders the raw workflow id instead of its name.
            const evaluatorWorkflow = evaluatorWorkflows.find((e) => e.id === selectedAppId)
            const isEvaluator = selectedWorkflowMeta?.isEvaluator ?? Boolean(evaluatorWorkflow)
            options.push({
                label:
                    selectedWorkflowMeta?.label ??
                    evaluatorWorkflow?.name ??
                    evaluatorWorkflow?.slug ??
                    selectedAppId,
                value: selectedAppId,
                type: isEvaluator ? "evaluator" : null,
                createdAt: null,
                updatedAt: null,
            })
        }
        return options
    }, [availableApps, selectedAppId, selectedWorkflowMeta, evaluatorWorkflows])
    const router = useRouter()
    const {baseAppURL, projectURL} = useURL()

    // Workflow-based evaluator data
    const templatesData = useAtomValue(evaluatorTemplatesDataAtom)
    const templatesQuery = useAtomValue(evaluatorTemplatesQueryAtom)
    const configsData = useAtomValue(evaluatorConfigsListDataAtom)
    const configsQueryState = useAtomValue(evaluatorConfigsQueryStateAtom)

    // Workflow-based evaluator list atoms (replace legacy useEvaluators hook).
    // The `humanEvaluatorsListDataAtom` subscription already drives the human
    // evaluators query; we don't separately read its query-state object (doing
    // so only churned the derived-evaluators memo above), so it's not read here.
    const humanEvaluatorsList = useAtomValue(humanEvaluatorsListDataAtom)
    const evaluatorsList = useAtomValue(evaluatorsListDataAtom)
    const evaluatorsQuery = useAtomValue(evaluatorsListQueryAtom)

    // Derive evaluators, evaluatorConfigs, and loading flags based on preview flag
    const {evaluators, evaluatorConfigs, loadingEvaluators, loadingEvaluatorConfigs} =
        useMemo(() => {
            if (preview) {
                const data = evaluationType === "human" ? humanEvaluatorsList : evaluatorsList
                return {
                    evaluators: data || [],
                    evaluatorConfigs: [],
                    loadingEvaluators: evaluatorsQuery.isPending ?? false,
                    loadingEvaluatorConfigs: false,
                }
            } else {
                return {
                    evaluators: templatesData || [],
                    evaluatorConfigs: configsData || [],
                    loadingEvaluators: templatesQuery.isPending ?? false,
                    loadingEvaluatorConfigs: configsQueryState.isPending ?? false,
                }
            }
            // Depend on the *values* the body reads, not the query result
            // objects — `evaluatorsQuery`/`humanEvaluatorsQuery` change identity
            // on every query tick (and `humanEvaluatorsQuery` isn't read at all),
            // which recomputed this memo every render and churned the derived
            // `evaluators`/`evaluatorConfigs` → `appOptions`/Tabs items downstream.
        }, [
            preview,
            evaluationType,
            humanEvaluatorsList,
            evaluatorsList,
            evaluatorsQuery.isPending,
            templatesData,
            configsData,
            templatesQuery.isPending,
            configsQueryState.isPending,
        ])

    const [selectedTestsetId, setSelectedTestsetId] = useAtom(selectedTestsetIdAtom)
    const [selectedTestsetRevisionId, setSelectedTestsetRevisionId] = useAtom(
        selectedTestsetRevisionIdAtom,
    )
    const [selectedTestsetName, setSelectedTestsetName] = useAtom(selectedTestsetNameAtom)
    const [selectedTestsetVersion, setSelectedTestsetVersion] = useAtom(selectedTestsetVersionAtom)
    const [selectedEvalConfigs, setSelectedEvalConfigs] = useAtom(selectedEvalConfigsAtom)

    // Read evaluator rows from the paginated store for revision ID → {id, slug} lookup
    const evaluatorStoreState = useAtomValue(
        evaluatorsPaginatedStore.selectors.state({
            scopeId: "evaluation-evaluator-selector",
            pageSize: 50,
        }),
    )
    const evaluatorRowsByRevisionId = useMemo(() => {
        const map = new Map<
            string,
            {id: string; workflow_id: string; slug?: string; name?: string}
        >()
        for (const row of evaluatorStoreState.rows) {
            if (!row.__isSkeleton && row.revisionId) {
                map.set(row.revisionId, {
                    id: row.revisionId,
                    workflow_id: row.workflowId,
                    // Latent: store rows carry IDs only (display data lives in molecules), so slug/name are always undefined
                    slug: row.slug as string | undefined,
                    name: row.name as string | undefined,
                })
            }
        }
        return map
    }, [evaluatorStoreState.rows])

    // Reset testset selection on mount to match previous local state behavior
    useEffect(() => {
        setSelectedTestsetId("")
        setSelectedTestsetRevisionId("")
        setSelectedTestsetName("")
        setSelectedTestsetVersion(null)
        setSelectedEvalConfigs([])
    }, [
        setSelectedEvalConfigs,
        setSelectedTestsetId,
        setSelectedTestsetName,
        setSelectedTestsetRevisionId,
        setSelectedTestsetVersion,
    ])
    // Initialize with pre-selected variants (e.g., from playground comparison mode)
    const [selectedVariantRevisionIds, setSelectedVariantRevisionIds] = useState<string[]>(() =>
        preSelectedVariantIds?.length ? [...preSelectedVariantIds] : [],
    )
    const activeTourId = useAtomValue(activeTourIdAtom)
    const currentStepState = useAtomValue(currentStepStateAtom)
    // If variants are pre-selected, start on testset panel; otherwise follow normal flow
    const hasPreSelectedVariants = Boolean(preSelectedVariantIds?.length)
    const [activePanel, setActivePanel] = useAtom(newEvaluationActivePanelAtom)
    const [evaluationName, setEvaluationName] = useState("")
    const [nameFocused, setNameFocused] = useState(false)
    const [advanceSettings, setAdvanceSettings] =
        useState<EvaluationConcurrencySettings>(DEFAULT_ADVANCE_SETTINGS)

    const allowTestsetAutoAdvance = !(
        activeTourId === FIRST_EVALUATION_TOUR_ID &&
        currentStepState.step?.panelKey === "testsetPanel"
    )

    useLayoutEffect(() => {
        if (activeTourId !== FIRST_EVALUATION_TOUR_ID) return
        const panelKey = currentStepState.step?.panelKey
        if (!panelKey || panelKey === activePanel) return
        setActivePanel(panelKey)
    }, [activePanel, activeTourId, currentStepState.step?.panelKey, setActivePanel])

    useEffect(() => {
        if (isAppScoped) {
            setSelectedAppId(effectiveAppId)
        }
    }, [effectiveAppId, isAppScoped])

    useEffect(() => {
        const initialPanel = getInitialPanel(hasPreSelectedVariants, isAppScoped)
        setActivePanel(initialPanel)
        return () => {
            setActivePanel(null)
        }
    }, [hasPreSelectedVariants, isAppScoped, setActivePanel])

    useEffect(() => {
        if (!isAppScoped) return
        if (!selectedAppId) return
        if (activePanel !== "appPanel") return
        setActivePanel("variantPanel")
    }, [isAppScoped, selectedAppId, activePanel, setActivePanel])

    const handleAppSelection = useCallback(
        (value: string, meta?: {label?: string; isEvaluator?: boolean}) => {
            if (value === selectedAppId) {
                // Same workflow re-selected — refresh the meta so label/kind
                // fallbacks stay current without resetting the rest of the
                // wizard state.
                if (value && meta) setSelectedWorkflowMeta(meta)
                return
            }
            setSelectedAppId(value)
            setSelectedWorkflowMeta(value ? (meta ?? null) : null)
            setSelectedTestsetId("")
            setSelectedTestsetRevisionId("")
            setSelectedTestsetName("")
            setSelectedTestsetVersion(null)
            setSelectedVariantRevisionIds([])
            setSelectedEvalConfigs([])
            setEvaluationName("")
            setActivePanel(value ? "variantPanel" : "appPanel")
            setAdvanceSettings(DEFAULT_ADVANCE_SETTINGS)
        },
        [selectedAppId],
    )

    const workflowRevisions = useAtomValue(
        useMemo(
            () => workflowRevisionsByWorkflowListDataAtomFamily(selectedAppId || ""),
            [selectedAppId],
        ),
    )
    const filteredVariants = useMemo(() => {
        if (!selectedAppId) return []
        return workflowRevisions || []
    }, [workflowRevisions, selectedAppId])

    const {createNewRun: createPreviewEvaluationRun} = usePreviewEvaluations({
        appId: selectedAppId || appId,
        skip: false,
    })
    const testsetsQuery = useAtomValue(testsetsListQueryAtomFamily(null))
    const testsets = testsetsQuery.data?.testsets ?? []
    const testsetsLoading = testsetsQuery.isPending

    const {secrets} = useVaultSecret()

    const handlePanelChange = useCallback((key: string | string[]) => {
        setActivePanel(key as string)
    }, [])

    // Handler for when a new evaluator config is created via the inline drawer
    const handleEvaluatorCreated = useCallback(async (configId?: string) => {
        // Refetch evaluator configs to get the newly created one
        invalidateWorkflowsListCache()
        invalidateEvaluatorsListCache()
        clearEvaluatorWorkflowCache()

        // Auto-select the newly created evaluator config
        if (configId) {
            setSelectedEvalConfigs((prev) => [...prev, configId])
        }
    }, [])

    // Track focus on any input within modal to avoid overriding user typing
    useEffect(() => {
        function handleFocusIn(e: FocusEvent) {
            if ((e.target as HTMLElement).tagName === "INPUT") {
                setNameFocused(true)
            }
        }
        function handleFocusOut(e: FocusEvent) {
            if ((e.target as HTMLElement).tagName === "INPUT") {
                setNameFocused(false)
            }
        }
        document.addEventListener("focusin", handleFocusIn)
        document.addEventListener("focusout", handleFocusOut)
        return () => {
            document.removeEventListener("focusin", handleFocusIn)
            document.removeEventListener("focusout", handleFocusOut)
        }
    }, [])

    // Variant display names live on the VARIANT (name, then slug): SDK-created
    // variants and revisions may carry no `name` at all, and UI-created
    // revisions are named after the variant.
    const selectedSingleRevisionId =
        selectedVariantRevisionIds.length === 1 ? selectedVariantRevisionIds[0] : ""
    const selectedVariantLabel = useAtomValue(
        useMemo(
            () => workflowMolecule.selectors.variantLabel(selectedSingleRevisionId),
            [selectedSingleRevisionId],
        ),
    )

    // Memoised base (deterministic) part of generated name (without random suffix)
    const generatedNameBase = useMemo(() => {
        if (!selectedVariantRevisionIds.length || !selectedTestsetName) return ""
        if (selectedVariantRevisionIds.length > 1) {
            return `${selectedVariantRevisionIds.length}-variants-${selectedTestsetName}`
        }
        const revision = filteredVariants?.find((v) => selectedVariantRevisionIds.includes(v.id))
        if (!revision) return ""
        const label = selectedVariantLabel ?? revision.name ?? "-"
        return `${label}-v${revision.version ?? 0}-${selectedTestsetName}`
    }, [selectedVariantRevisionIds, selectedTestsetName, filteredVariants, selectedVariantLabel])

    // Auto-generate / update evaluation name intelligently to avoid loops
    const lastAutoNameRef = useRef<string>("")
    const lastBaseRef = useRef<string>("")
    const randomWordRef = useRef<string>("")

    // Generate a short, readable random suffix (stable per modal open)
    const genRandomWord = () => {
        // Prefer Web Crypto for better entropy
        const n = globalThis.crypto?.getRandomValues?.(new Uint32Array(1))?.[0] ?? 0
        if (n) return n.toString(36).slice(0, 5)
        // Fallback to Math.random
        return Math.random().toString(36).slice(2, 7)
    }

    useEffect(() => {
        // New random suffix on mount
        randomWordRef.current = genRandomWord()
        lastAutoNameRef.current = ""
        lastBaseRef.current = ""
        return () => {
            randomWordRef.current = ""
        }
    }, [])

    useEffect(() => {
        if (!generatedNameBase) return
        if (nameFocused) return // user typing

        // When base (variant/testset) changed → generate new suggestion
        if (generatedNameBase !== lastBaseRef.current) {
            // Ensure we have a random word for this session
            if (!randomWordRef.current) randomWordRef.current = genRandomWord()
            const randomWord = randomWordRef.current
            const newName = `${generatedNameBase}-${randomWord}`
            const shouldUpdate = !evaluationName || evaluationName === lastAutoNameRef.current
            lastBaseRef.current = generatedNameBase
            lastAutoNameRef.current = newName
            if (shouldUpdate) {
                setEvaluationName(newName)
            }
            return
        }

        // If user cleared the field (blur) → restore auto-name
        if (!evaluationName) {
            setEvaluationName(lastAutoNameRef.current)
        }
    }, [generatedNameBase, evaluationName, nameFocused, evaluationType])

    const validateSubmission = useCallback(async () => {
        if (!evaluationName) {
            message.error("Please enter evaluation name")
            return false
        }
        if (!selectedTestsetId || !selectedTestsetRevisionId) {
            message.error("Please select a testset revision")
            return false
        }
        if (selectedVariantRevisionIds.length === 0) {
            message.error("Please select a revision")
            return false
        }

        const selectedRevisions = filteredVariants.filter((revision) =>
            selectedVariantRevisionIds.includes(revision.id),
        )
        const hasUnresolvableLocalDraft = selectedRevisions.some((revision) => {
            if (!isLocalDraftId(revision.id)) return false
            const sourceRevisionId =
                (revision as {sourceRevisionId?: string | null}).sourceRevisionId ??
                extractSourceIdFromDraft(revision.id)
            return !(sourceRevisionId && isValidUUID(sourceRevisionId))
        })

        if (hasUnresolvableLocalDraft) {
            message.error(
                "Please commit selected local draft revisions before starting an evaluation.",
            )
            return false
        }

        if (selectedEvalConfigs.length === 0) {
            message.error("Please select evaluator configuration")
            return false
        }
        if (
            !preview &&
            selectedEvalConfigs.some(
                (id) =>
                    resolveEvaluatorKey(workflowMolecule.get.data(id) as any) ===
                    "auto_ai_critique",
            ) &&
            (await redirectIfNoLLMKeys({secrets}))
        ) {
            message.error("LLM keys are required for AI Critique configuration")
            return false
        }

        // Variant / column validation is temporarily disabled
        return true
    }, [
        evaluationName,
        selectedTestsetId,
        selectedTestsetRevisionId,
        selectedVariantRevisionIds,
        filteredVariants,
        selectedEvalConfigs,
        evaluatorConfigs,
        preview,
        secrets,
    ])

    const onSubmit = useCallback(async () => {
        onSubmitStateChange?.(true)
        try {
            if (!(await validateSubmission())) {
                onSubmitStateChange?.(false)
                return
            }

            const targetAppId = selectedAppId || appId
            if (!targetAppId) {
                message.error("Please select an application")
                onSubmitStateChange?.(false)
                return
            }

            const revisions = filteredVariants

            if (preview) {
                const selectedRevisions = revisions
                    ?.filter((rev) => selectedVariantRevisionIds.includes(rev.id))
                    .filter(Boolean)
                    .map((revision) => {
                        if (isValidUUID(revision.id)) return revision

                        const sourceRevisionId =
                            (revision as {sourceRevisionId?: string | null}).sourceRevisionId ??
                            (isLocalDraftId(revision.id)
                                ? extractSourceIdFromDraft(revision.id)
                                : null)

                        if (sourceRevisionId && isValidUUID(sourceRevisionId)) {
                            return {
                                ...revision,
                                id: sourceRevisionId,
                            }
                        }

                        return revision
                    })

                const selectionTestset = selectedTestsetId
                    ? ({
                          _id: selectedTestsetId,
                          revisionId: selectedTestsetRevisionId || undefined,
                      } as any)
                    : undefined

                const selectionData = {
                    name: evaluationName,
                    revisions: selectedRevisions,
                    testset: selectionTestset,
                    evaluators: selectedEvalConfigs
                        .map((id) => evaluatorRowsByRevisionId.get(id))
                        .filter(Boolean),
                    concurrency: advanceSettings,
                }

                if (
                    !selectionData.revisions?.length ||
                    !selectionData.testset ||
                    !selectionData.evaluators?.length ||
                    (evaluationType === "human" && !evaluationName)
                ) {
                    message.error(
                        `Please select a testset, revision, ${
                            evaluationType === "human" ? "evaluation name, and" : " and"
                        } evaluator configuration. Missing: ${
                            !selectionData.revisions?.length ? "revision" : ""
                        } ${!selectionData.testset ? "testset" : ""} ${
                            !selectionData.evaluators?.length
                                ? "evaluators"
                                : evaluationType === "human" && !evaluationName
                                  ? "evaluation name"
                                  : ""
                        }`,
                    )
                    onSubmitStateChange?.(false)
                    return
                }

                const data = await createPreviewEvaluationRun(structuredClone(selectionData) as any)

                const runId = data.run.runs[0].id
                const scope = isAppScoped ? "app" : "project"
                const targetPath = buildEvaluationNavigationUrl({
                    scope,
                    baseAppURL,
                    projectURL,
                    appId: targetAppId,
                    path: `/evaluations/results/${runId}`,
                })

                onSuccess?.()

                router.push({
                    pathname: targetPath,
                    query: {type: "human", view: "focus"},
                })
            } else {
                try {
                    const response = await createEvaluation(targetAppId, {
                        testset_id: selectedTestsetId,
                        testset_revision_id: selectedTestsetRevisionId,
                        revisions_ids: selectedVariantRevisionIds,
                        evaluator_revision_ids: selectedEvalConfigs,
                        concurrency: advanceSettings,
                        name: evaluationName,
                    })

                    // One run is created per selected variant; link to the first.
                    const runCount = response.runs?.length ?? 1
                    const runId = response.data?.evaluation?.id
                    if (runId) {
                        const scope = isAppScoped ? "app" : "project"
                        const resultsUrl = buildEvaluationNavigationUrl({
                            scope,
                            baseAppURL,
                            projectURL,
                            appId: targetAppId,
                            path: `/evaluations/results/${runId}`,
                        })

                        message.success(
                            <span>
                                {runCount > 1
                                    ? `${runCount} evaluations started.`
                                    : "Evaluation started."}{" "}
                                <a
                                    href={resultsUrl}
                                    onClick={(e) => {
                                        e.preventDefault()
                                        router.push(resultsUrl)
                                    }}
                                    className="underline font-medium"
                                >
                                    View progress
                                </a>
                            </span>,
                        )
                    } else {
                        message.success(
                            runCount > 1 ? `${runCount} evaluations started` : "Evaluation started",
                        )
                    }

                    // Trigger revalidation and close modal after successful creation
                    onSuccess?.()
                } catch (error) {
                    console.error("[NewEvaluationModal] Error creating auto evaluation:", error)
                }
            }
        } catch (error) {
            console.error(error)
        } finally {
            onSubmitStateChange?.(false)
        }
    }, [
        appId,
        selectedAppId,
        selectedTestsetId,
        selectedTestsetRevisionId,
        selectedVariantRevisionIds,
        selectedEvalConfigs,
        advanceSettings,
        evaluators,
        evaluationName,
        filteredVariants,
        preview,
        validateSubmission,
        createPreviewEvaluationRun,
        baseAppURL,
        projectURL,
        onSuccess,
        onSubmitStateChange,
        isAppScoped,
        evaluationType,
        router,
    ])

    // Expose submit handler to parent via a temporary window property
    useEffect(() => {
        if (typeof window !== "undefined") {
            ;(window as any).__newEvalModalSubmit = onSubmit
        }
        return () => {
            if (typeof window !== "undefined") {
                delete (window as any).__newEvalModalSubmit
            }
        }
    }, [onSubmit])

    return (
        <NewEvaluationModalContent
            evaluationType={evaluationType}
            onSuccess={onSuccess}
            handlePanelChange={handlePanelChange}
            activePanel={activePanel}
            selectedTestsetId={selectedTestsetId}
            selectedTestsetRevisionId={selectedTestsetRevisionId}
            selectedTestsetName={selectedTestsetName}
            selectedTestsetVersion={selectedTestsetVersion}
            setSelectedTestsetId={setSelectedTestsetId}
            setSelectedTestsetRevisionId={setSelectedTestsetRevisionId}
            setSelectedTestsetName={setSelectedTestsetName}
            setSelectedTestsetVersion={setSelectedTestsetVersion}
            selectedVariantRevisionIds={selectedVariantRevisionIds}
            setSelectedVariantRevisionIds={setSelectedVariantRevisionIds}
            selectedEvalConfigs={selectedEvalConfigs}
            setSelectedEvalConfigs={setSelectedEvalConfigs}
            evaluationName={evaluationName}
            setEvaluationName={setEvaluationName}
            preview={preview}
            isLoading={loadingEvaluators || loadingEvaluatorConfigs || testsetsLoading}
            isOpen={true} // Always true since this component only renders when modal is open
            testsets={selectedAppId ? testsets || [] : []}
            evaluators={evaluators}
            evaluatorConfigs={evaluatorConfigs}
            advanceSettings={advanceSettings}
            setAdvanceSettings={setAdvanceSettings}
            appOptions={appOptions}
            selectedAppId={selectedAppId}
            onSelectApp={handleAppSelection}
            appSelectionDisabled={isAppScoped}
            onEvaluatorCreated={handleEvaluatorCreated}
            allowTestsetAutoAdvance={allowTestsetAutoAdvance}
        />
    )
}

export default memo(NewEvaluationModalInner)
