import {extractSourceIdFromDraft, isLocalDraftId, isValidUUID} from "@agenta/entities/shared"
import {
    extractAllEndpointSchemas,
    extractInputKeysFromSchema,
} from "@agenta/entities/shared/openapi"
import type {Workflow} from "@agenta/entities/workflow"
import {
    workflowMolecule,
    appOpenApiSchemaAtomFamily,
    appRoutePathAtomFamily,
} from "@agenta/entities/workflow"
import {getDefaultStore} from "jotai"

import {getMetricsFromEvaluator} from "@/oss/components/SharedDrawers/AnnotateDrawer/assets/transforms"
import {slugify} from "@/oss/lib/utils/slugify"
import {currentAppContextAtom} from "@/oss/state/app/selectors/app"

import {CreateEvaluationRunInput, Testset} from "./types"

const extractColumnsFromTestset = (testset?: Testset): string[] => {
    if (!testset) return []

    const columns = new Set<string>()

    const addColumnsFromObject = (obj?: Record<string, any>) => {
        if (!obj || typeof obj !== "object") return
        Object.keys(obj).forEach((key) => {
            if (!key || typeof key !== "string") return
            if (key.startsWith("__")) return
            columns.add(key)
        })
    }

    const csvRows = (testset as any)?.csvdata
    if (Array.isArray(csvRows) && csvRows.length > 0) {
        addColumnsFromObject(csvRows[0] as Record<string, any>)
    }

    const data = (testset as any)?.data
    if (data) {
        const testcases = data.testcases || data.testcases
        if (Array.isArray(testcases) && testcases.length > 0) {
            addColumnsFromObject(
                (testcases[0] && (testcases[0].data || testcases[0])) as Record<string, any>,
            )
        }

        const columnsList = data.columns || data.columnNames
        if (Array.isArray(columnsList)) {
            columnsList.forEach((col: any) => {
                if (typeof col === "string" && col && !col.startsWith("__")) {
                    columns.add(col)
                }
            })
        }
    }

    return Array.from(columns)
}

/**
 * Resolve a server revision ID for invocation references.
 * Local drafts use non-UUID IDs, so we fall back to their source revision.
 */
const resolveWorkflowRevisionId = (workflow: Workflow): string | undefined => {
    if (isValidUUID(workflow.id)) return workflow.id

    const sourceRevisionId = isLocalDraftId(workflow.id)
        ? extractSourceIdFromDraft(workflow.id)
        : null

    if (sourceRevisionId && isValidUUID(sourceRevisionId)) {
        return sourceRevisionId
    }

    return undefined
}

/**
 * Constructs the input step for a given testset, pulling variantId and revisionId
 * directly from the testset object. Any undefined reference keys are omitted.
 */

const buildInputStep = (testset?: Testset) => {
    if (!testset) return
    const inputKey = slugify(testset.name ?? (testset as any).slug ?? "testset", testset.id)
    if (!testset) {
        return
    }

    const references: Record<string, {id: string}> = {
        testset: {id: testset.id},
    }

    if (testset.revisionId) {
        references.testset_revision = {id: testset.revisionId}
    }

    // TODO: after new testsets
    // if (testset.variantId) {
    //     references.testset_variant = {id: testset.variantId}
    // }

    return {
        key: inputKey,
        type: "input",
        origin: "auto",
        references,
    }
}

/**
 * Constructs the invocation step for a given revision.
 * Only includes reference keys if their IDs are defined.
 */
const buildInvocationStep = (revision: Workflow, inputKey: string) => {
    const invocationKey = slugify(revision.name ?? "invocation", revision.id)
    const references: Record<string, {id: string}> = {}

    const appId = revision.workflow_id
    if (appId && isValidUUID(appId)) {
        references.application = {id: appId}
    }

    const variantId = revision.workflow_variant_id
    if (variantId && isValidUUID(variantId)) {
        references.application_variant = {id: variantId}
    }
    const invocationRevisionId = resolveWorkflowRevisionId(revision)
    if (invocationRevisionId) {
        references.application_revision = {id: invocationRevisionId}
    }
    return {
        key: invocationKey,
        type: "invocation",
        origin: "human",
        references,
        inputs: [{key: inputKey}],
    }
}

/**
 * Constructs annotation steps for evaluator revisions.
 */
const buildAnnotationStepsFromEvaluators = (
    evaluators: Workflow[] | undefined,
    inputKey: string,
    invocationKey: string,
) => {
    if (!evaluators) return []
    return evaluators.map((evaluator) => {
        const references: Record<string, {id: string}> = {}

        if (evaluator.workflow_id && isValidUUID(evaluator.workflow_id)) {
            references.evaluator = {id: evaluator.workflow_id}
        }

        if (evaluator.workflow_variant_id && isValidUUID(evaluator.workflow_variant_id)) {
            references.evaluator_variant = {id: evaluator.workflow_variant_id}
        }

        const evaluatorRevisionId = resolveWorkflowRevisionId(evaluator)
        if (evaluatorRevisionId) {
            references.evaluator_revision = {id: evaluatorRevisionId}
        }

        return {
            key: `${invocationKey}.${evaluator.slug}`,
            references,
            type: "annotation",
            origin: "human",
            inputs: [{key: inputKey}, {key: invocationKey}],
        }
    })
}

/**
 * Constructs the array of mappings for extracting data from steps.
 * Uses the revision's inputParams to generate "input" mappings automatically.
 *
 * @param revision - The Workflow revision object.
 * @param correctAnswerColumn - The property name in the input step for ground truth.
 * @param evaluators - Optional list of evaluators to generate evaluator mappings.
 * @param testset - The testset object to conditionally add mappings based on variantId and revisionId.
 * @returns An array of mapping objects.
 */
const buildMappings = (
    revision: Workflow,
    correctAnswerColumn: string,
    evaluators: Workflow[] | undefined,
    testset?: Testset,
) => {
    const testsetKey = testset
        ? slugify(testset.name ?? (testset as any).slug ?? "testset", testset.id)
        : "input"
    const invocationKey = slugify(revision.name ?? "invocation", revision.id)
    const mappings: {
        column: {kind: "testset" | "invocation" | "evaluator"; name: string}
        step: {key: string; path: string}
    }[] = []
    const pushedTestsetColumns = new Set<string>()

    // First, extract actual columns from the testset to validate against
    const testsetColumns = testset ? new Set(extractColumnsFromTestset(testset)) : new Set<string>()

    // Generate input mappings aligned with Playground (schema + initial prompt vars for custom; prompt tokens for non-custom)
    {
        const store = getDefaultStore()
        const appContextValue = store.get(currentAppContextAtom)
        // the eager atom can still hold a pending Promise; a Promise has no appType, so isCustom stays false
        const appContext = appContextValue instanceof Promise ? null : appContextValue
        const isCustom = appContext?.appType === "custom"
        const spec = store.get(appOpenApiSchemaAtomFamily(revision.id))
        const routePath = store.get(appRoutePathAtomFamily(revision.id)) || ""

        let variableNames: string[] = []
        if (isCustom) {
            // Custom workflows: strictly use schema-defined input keys
            variableNames = spec ? extractInputKeysFromSchema(spec as any, routePath) : []
        } else {
            // Non-custom: use stable variables from saved parameters (ignore live prompt edits)
            const inputSchema = store.get(workflowMolecule.selectors.inputSchema(revision.id))
            const props = (inputSchema as any)?.properties
            variableNames = props && typeof props === "object" ? Object.keys(props) : []
        }

        // Only add schema-derived columns if they actually exist in the testset
        variableNames.forEach((name) => {
            if (!name || typeof name !== "string") return
            // Only add if the testset actually has this column
            if (testsetColumns.size > 0 && !testsetColumns.has(name)) return
            pushedTestsetColumns.add(name)
            mappings.push({
                column: {kind: "testset", name},
                step: {key: testsetKey, path: `data.${name}`},
            })
        })

        const {primaryEndpoint} = spec
            ? extractAllEndpointSchemas(spec as any, routePath)
            : {primaryEndpoint: null}
        // Only add messages column if the testset actually has it
        if (
            primaryEndpoint?.messagesSchema &&
            !pushedTestsetColumns.has("messages") &&
            testsetColumns.has("messages")
        ) {
            pushedTestsetColumns.add("messages")
            mappings.push({
                column: {kind: "testset", name: "messages"},
                step: {key: testsetKey, path: "data.inputs.messages"},
            })
        }
    }

    // Always add testset columns that weren't already added from schema
    if (testset) {
        const normalizedCorrectAnswer = (correctAnswerColumn || "")
            .replace(/[\W_]/g, "")
            .toLowerCase()
        testsetColumns.forEach((name) => {
            if (!name || typeof name !== "string") return
            const normalized = name.trim()
            if (!normalized || normalized.startsWith("__")) return
            const normalizedSafe = normalized.replace(/[\W_]/g, "").toLowerCase()
            if (normalizedSafe === normalizedCorrectAnswer) return
            if (normalizedSafe.includes("correctanswer")) return
            if (normalizedSafe.startsWith("testcase") || normalizedSafe.includes("dedup")) return
            if (pushedTestsetColumns.has(name) || pushedTestsetColumns.has(normalizedSafe)) return
            pushedTestsetColumns.add(name)
            pushedTestsetColumns.add(normalizedSafe)
            mappings.push({
                column: {kind: "testset", name},
                step: {key: testsetKey, path: `data.${name}`},
            })
        })
    }

    // Application output mapping should use canonical column name "outputs" to align with backend
    mappings.push({
        column: {kind: "invocation", name: "outputs"},
        step: {key: invocationKey, path: "attributes.ag.data.outputs"},
    })

    // Add mappings for testset variantId and revisionId if available
    // Additional metadata mappings if available
    if (testset?.variantId !== undefined) {
        mappings.push({
            column: {kind: "testset", name: "testset_variant_id"},
            step: {key: testsetKey, path: "data.variantId"},
        })
    }
    // if (testset?.revisionId !== undefined) {
    //     mappings.push({
    //         column: {kind: "testset", name: "testset_revision_id"},
    //         step: {key: testsetKey, path: "data.revisionId"},
    //     })
    // }

    // Evaluator output mappings generated dynamically per evaluator
    if (evaluators && evaluators.length > 0) {
        evaluators?.forEach((evaluator) => {
            // typed as-is: a Workflow is passed where an EvaluatorDto is expected; only `.data` is read
            const metrics = getMetricsFromEvaluator(
                evaluator as unknown as Parameters<typeof getMetricsFromEvaluator>[0],
            )
            Object.keys(metrics).forEach((key) => {
                mappings.push({
                    column: {kind: "evaluator", name: `${evaluator.slug}.${key}`},
                    step: {key: `${invocationKey}.${evaluator.slug}`, path: `data.outputs.${key}`},
                })
            })
        })
    }

    return mappings
}

/**
 * Builds the payload required for submitting multiple evaluation runs to the backend.
 * Each revision will be wrapped in its own run configuration.
 * This function returns an object with a `runs` array that can be sent to
 * the POST `/evaluations/runs/` endpoint.
 *
 * @param name - Base name used in each run
 * @param testset - The testset being used in this evaluation (must include variantId & revisionId).
 * @param revisions - List of workflow revisions; one run will be generated per revision.
 * @param evaluators - List of available evaluators used in annotation.
 * @param correctAnswerColumn - The property name in the input step that holds the ground truth value.
 * @param meta - Optional metadata object to attach to each run.
 * @returns Object containing `runs` array, ready to be POSTed to the backend.
 */
export const createEvaluationRunConfig = ({
    name,
    testset,
    revisions,
    evaluators,
    correctAnswerColumn,
    meta = undefined, // Default to empty object if not provided
}: CreateEvaluationRunInput) => {
    // Pre-build the input step (which now includes variantId & revisionId) and mappings
    const inputStep = buildInputStep(testset)
    const inputKey = slugify(testset?.name ?? (testset as any)?.slug ?? "testset", testset!.id)
    const invocationKeysCache: Record<string, string> = {}

    // Create one run configuration per revision
    const runs = revisions.map((revision) => {
        const invocationKey =
            invocationKeysCache[revision.id] ?? slugify(revision.name ?? "invocation", revision.id)

        invocationKeysCache[revision.id] = invocationKey

        const steps = [
            inputStep,
            buildInvocationStep(revision, inputKey),
            ...buildAnnotationStepsFromEvaluators(evaluators, inputKey, invocationKey),
        ]
        // Build mappings for this revision, passing testset as well
        const mappings = buildMappings(revision, correctAnswerColumn, evaluators, testset)
        return {
            key: `evaluation-${revision.workflow_variant_id ?? revision.id}`,
            name: `${name}`,
            // description: "auto-generated evaluation run",
            meta, // Include the passed-in meta object
            data: {steps, mappings},
        }
    })

    return {runs}
}
