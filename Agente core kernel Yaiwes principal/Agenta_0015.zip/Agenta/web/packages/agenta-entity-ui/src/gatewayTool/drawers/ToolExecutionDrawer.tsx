import React, {useCallback, useMemo, useRef, useState} from "react"

import {
    toolActionsSearchAtom,
    toolExecutionDrawerAtom,
    useToolActionDetail,
    useToolCatalogActions,
    useToolExecution,
    useToolIntegrationDetail,
    type ToolCatalogAction,
    type ToolCatalogActionDetails,
} from "@agenta/entities/gatewayTool"
import {useDebouncedAtomSearch} from "@agenta/shared/hooks"
import {ScrollSentinel, ScrollToTopButton, message} from "@agenta/ui"
import {Tag} from "@agenta/ui/components/presentational"
import {EnhancedDrawer} from "@agenta/ui/drawer"
import {
    Button,
    Divider,
    EmptyState,
    InputAffix,
    LoadingButton,
    Segmented,
    Spinner,
} from "@agenta/ui/ui"
import {
    ArrowLeft,
    BracketsRound,
    CopySimple,
    ListDashes,
    MagnifyingGlass,
    Play,
} from "@phosphor-icons/react"
import {useAtom, useSetAtom} from "jotai"
import Image from "next/image"

import {CatalogCard} from "../components/catalogPrimitives"
import ResultViewer from "../components/ResultViewer"
import type {SchemaFormHandle} from "../components/SchemaForm"
import SchemaForm from "../components/SchemaForm"

type CatalogActionItem = ToolCatalogAction | ToolCatalogActionDetails

const DEFAULT_PROVIDER = "composio"

// ---------------------------------------------------------------------------
// ToolExecutionDrawer (root)
// ---------------------------------------------------------------------------

export default function ToolExecutionDrawer() {
    const [state, setState] = useAtom(toolExecutionDrawerAtom)
    const open = !!state
    const [selectedAction, setSelectedAction] = useState<CatalogActionItem | null>(null)
    const setActionsSearch = useSetAtom(toolActionsSearchAtom)

    // Fetch integration info as fallback when name/logo not in state
    const {integration} = useToolIntegrationDetail(state?.integrationKey ?? "")
    const integrationName = state?.integrationName ?? integration?.name
    const integrationLogo = state?.integrationLogo ?? integration?.logo

    // If actionKey is pre-set in state, start at step 2
    const step = state?.actionKey || selectedAction ? 2 : 1
    const activeActionKey = state?.actionKey ?? selectedAction?.key ?? ""

    const handleClose = useCallback(() => {
        setState(null)
        setSelectedAction(null)
        setActionsSearch("")
    }, [setState, setActionsSearch])

    const handleBack = useCallback(() => {
        setSelectedAction(null)
        setActionsSearch("")
    }, [setActionsSearch])

    const handleSelectAction = useCallback((action: CatalogActionItem) => {
        setSelectedAction(action)
    }, [])

    const drawerTitle = step === 2 ? "Test Action" : "Select Action"

    return (
        <EnhancedDrawer
            open={open}
            onClose={handleClose}
            title={drawerTitle}
            width={640}
            destroyOnClose
            styles={{
                body: {
                    padding: 0,
                    display: "flex",
                    flexDirection: "column",
                    overflow: "hidden",
                },
            }}
        >
            {state &&
                (step === 1 ? (
                    <ActionPickerStep
                        integrationKey={state.integrationKey || ""}
                        integrationName={integrationName || ""}
                        integrationLogo={integrationLogo ?? undefined}
                        connectionSlug={state.connectionSlug || ""}
                        onSelectAction={handleSelectAction}
                    />
                ) : (
                    <ActionDetailStep
                        integrationKey={state.integrationKey || ""}
                        integrationName={integrationName || ""}
                        integrationLogo={integrationLogo ?? undefined}
                        connectionSlug={state.connectionSlug || ""}
                        actionKey={activeActionKey}
                        actionName={selectedAction?.name}
                        canGoBack={!state.actionKey}
                        onBack={handleBack}
                    />
                ))}
        </EnhancedDrawer>
    )
}

// ---------------------------------------------------------------------------
// Step 1: Action Picker (infinite scroll)
// ---------------------------------------------------------------------------

function ActionPickerStep({
    integrationKey,
    integrationName,
    integrationLogo,
    connectionSlug,
    onSelectAction,
}: {
    integrationKey: string
    integrationName?: string
    integrationLogo?: string
    connectionSlug: string
    onSelectAction: (action: CatalogActionItem) => void
}) {
    const setAtom = useSetAtom(toolActionsSearchAtom)
    const search = useDebouncedAtomSearch(setAtom)
    const scrollRef = useRef<HTMLDivElement>(null)

    const {
        actions,
        total,
        prefetchThreshold,
        isLoading,
        hasNextPage,
        isFetchingNextPage,
        requestMore,
    } = useToolCatalogActions(integrationKey)

    const sentinelIndex = useMemo(
        () => Math.max(0, actions.length - prefetchThreshold),
        [actions.length, prefetchThreshold],
    )

    return (
        <div className="flex flex-col h-full overflow-hidden">
            {/* Sticky header */}
            <div className="flex flex-col gap-3 px-6 pt-4 pb-3 shrink-0">
                <div className="flex items-center gap-3">
                    {integrationLogo && (
                        <Image
                            src={integrationLogo}
                            alt={integrationName ?? ""}
                            width={32}
                            height={32}
                            className="w-8 h-8 rounded object-contain shrink-0"
                            unoptimized
                        />
                    )}
                    <div className="flex flex-col min-w-0 flex-1">
                        <span className="truncate font-medium">
                            {integrationName || integrationKey}
                        </span>
                        <span className="text-xs truncate text-colorTextDescription">
                            Connection: {connectionSlug}
                        </span>
                    </div>
                </div>

                <InputAffix
                    placeholder="Search actions…"
                    prefix={<MagnifyingGlass size={16} />}
                    value={search.value}
                    onValueChange={(value) => search.onChange(value)}
                    allowClear
                />

                <span className="text-xs text-colorTextDescription">
                    {total} action{total !== 1 ? "s" : ""}
                </span>
            </div>

            <Divider className="!m-0" />

            {/* Scrollable content */}
            <div
                ref={scrollRef}
                className="flex-1 overflow-y-auto overscroll-contain px-6 py-3 relative"
            >
                {isLoading && actions.length === 0 ? (
                    <div className="flex items-center justify-center py-8">
                        <Spinner />
                    </div>
                ) : actions.length === 0 ? (
                    <EmptyState description="No actions found" />
                ) : (
                    <div className="flex flex-col gap-2">
                        {actions.map((action, i) => (
                            <React.Fragment key={action.key}>
                                {i === sentinelIndex && (
                                    <ScrollSentinel
                                        onVisible={requestMore}
                                        hasMore={hasNextPage}
                                        isFetching={isFetchingNextPage}
                                    />
                                )}
                                <CatalogCard
                                    className="cursor-pointer"
                                    onClick={() => onSelectAction(action)}
                                >
                                    <div className="flex flex-col gap-0.5">
                                        <div className="flex items-center gap-2">
                                            <span className="truncate font-medium">
                                                {action.name}
                                            </span>
                                            {action.categories?.slice(0, 2).map((c) => (
                                                <Tag key={c} tone="default" className="text-xs">
                                                    {c}
                                                </Tag>
                                            ))}
                                        </div>
                                        {action.description && (
                                            <span className="text-xs line-clamp-2 text-colorTextDescription">
                                                {action.description}
                                            </span>
                                        )}
                                    </div>
                                </CatalogCard>
                            </React.Fragment>
                        ))}

                        <ScrollSentinel
                            onVisible={requestMore}
                            hasMore={hasNextPage}
                            isFetching={isFetchingNextPage}
                        />

                        {isFetchingNextPage && (
                            <div className="flex items-center justify-center py-4">
                                <Spinner size="small" />
                            </div>
                        )}
                    </div>
                )}

                <ScrollToTopButton scrollRef={scrollRef} />
            </div>
        </div>
    )
}

// ---------------------------------------------------------------------------
// Step 2: Action Detail (inputs + execute + outputs)
// ---------------------------------------------------------------------------

function ActionDetailStep({
    integrationKey,
    integrationName,
    integrationLogo,
    connectionSlug,
    actionKey,
    actionName,
    canGoBack,
    onBack,
}: {
    integrationKey: string
    integrationName?: string
    integrationLogo?: string
    connectionSlug: string
    actionKey: string
    actionName?: string
    canGoBack: boolean
    onBack: () => void
}) {
    const schemaFormRef = useRef<SchemaFormHandle>(null)
    const scrollRef = useRef<HTMLDivElement>(null)
    const {action, isLoading: detailLoading} = useToolActionDetail(integrationKey, actionKey)
    const {execute, isExecuting, result, error} = useToolExecution()
    const [viewMode, setViewMode] = useState<"form" | "json">("form")

    // The fetch endpoint always returns the detailed variant; narrow so we
    // can reach `schemas`. The wider union exists because Fern reuses the
    // response wrapper between list/detail endpoints.
    const detailedAction =
        action && "schemas" in action ? (action as ToolCatalogActionDetails) : null
    const inputSchema = detailedAction?.schemas?.inputs ?? null
    const outputSchema = detailedAction?.schemas?.outputs ?? null
    const displayName = action?.name ?? actionName ?? actionKey
    const jsonMode = viewMode === "json"

    const handleCopyInputs = useCallback(() => {
        try {
            // Raw, unvalidated snapshot — was `form.getFieldsValue(true)` on the antd
            // form instance this drawer used to own; the handle exposes it now.
            const values = schemaFormRef.current?.getRawValues() ?? {}
            navigator.clipboard.writeText(JSON.stringify(values, null, 2))
            message.success("Copied to clipboard")
        } catch {
            message.error("Failed to copy")
        }
    }, [])

    const handleExecute = useCallback(async () => {
        try {
            const values = await schemaFormRef.current?.getValues()
            if (!values) return

            await execute({
                provider: DEFAULT_PROVIDER,
                integrationKey,
                actionKey,
                connectionSlug,
                arguments: values,
            })
        } catch (e) {
            if (e instanceof SyntaxError) {
                message.error("Invalid JSON input")
            }
            // form validation failed
        }
    }, [execute, integrationKey, actionKey, connectionSlug])

    return (
        <div className="flex flex-col h-full overflow-hidden">
            {/* Sticky header */}
            <div className="flex flex-col gap-2 px-6 pt-4 pb-3 shrink-0">
                <div className="flex items-center gap-3">
                    {canGoBack && (
                        <Button
                            variant="ghost"
                            size="icon"
                            aria-label="Go back"
                            onClick={onBack}
                            className="shrink-0"
                        >
                            <ArrowLeft size={16} />
                        </Button>
                    )}
                    {integrationLogo && (
                        <Image
                            src={integrationLogo}
                            alt={integrationName ?? ""}
                            width={24}
                            height={24}
                            className="w-6 h-6 rounded object-contain shrink-0"
                            unoptimized
                        />
                    )}
                    {integrationName && (
                        <span className="shrink-0 text-colorTextDescription">
                            {integrationName}
                        </span>
                    )}
                    {integrationName && (
                        <span className="shrink-0 text-colorTextDescription">/</span>
                    )}
                    <span className="truncate flex-1 font-medium">
                        {detailLoading ? "Loading…" : displayName}
                    </span>
                    <Segmented
                        size="sm"
                        value={viewMode}
                        onChange={(v) => setViewMode(v as "form" | "json")}
                        options={[
                            {
                                value: "form",
                                icon: <ListDashes size={14} />,
                                "aria-label": "Form view",
                            },
                            {
                                value: "json",
                                icon: <BracketsRound size={14} />,
                                "aria-label": "JSON view",
                            },
                        ]}
                    />
                </div>
                {action?.description && (
                    <span className="text-xs text-colorTextDescription">{action.description}</span>
                )}
                <span className="text-xs text-colorTextDescription">
                    Connection: {connectionSlug}
                </span>
            </div>

            <Divider className="!m-0" />

            {/* Scrollable content */}
            <div
                ref={scrollRef}
                className="flex-1 overflow-y-auto overscroll-contain px-6 py-3 relative"
            >
                {detailLoading ? (
                    <div className="flex items-center justify-center py-8">
                        <Spinner />
                    </div>
                ) : (
                    <div className="flex flex-col gap-3">
                        {/* Inputs section */}
                        <div className="flex flex-col gap-2">
                            <div className="flex items-center justify-between">
                                <span className="text-sm font-medium">Inputs</span>
                                {!jsonMode && (
                                    <Button
                                        variant="ghost"
                                        size="icon-sm"
                                        aria-label="Copy inputs"
                                        onClick={handleCopyInputs}
                                        className="opacity-60 hover:opacity-100"
                                    >
                                        <CopySimple size={14} />
                                    </Button>
                                )}
                            </div>
                            <SchemaForm
                                ref={schemaFormRef}
                                schema={inputSchema as Record<string, unknown> | null}
                                disabled={isExecuting}
                                jsonMode={jsonMode}
                            />
                            <LoadingButton
                                size="sm"
                                loading={isExecuting}
                                onClick={handleExecute}
                                className="self-start"
                            >
                                {!isExecuting && <Play size={14} />}
                                Run
                            </LoadingButton>
                        </div>

                        <Divider className="!my-1" />

                        {/* Outputs section */}
                        <div className="flex flex-col gap-2">
                            <span className="text-sm font-medium">Outputs</span>
                            {result || error ? (
                                <ResultViewer
                                    result={result}
                                    error={error}
                                    outputSchema={outputSchema as Record<string, unknown> | null}
                                    jsonMode={jsonMode}
                                />
                            ) : (
                                <div className="rounded-lg border border-dashed border-gray-300 p-4 text-center">
                                    <span className="text-xs text-colorTextDescription">
                                        Run the action to see results
                                    </span>
                                </div>
                            )}
                        </div>
                    </div>
                )}

                <ScrollToTopButton scrollRef={scrollRef} />
            </div>
        </div>
    )
}
