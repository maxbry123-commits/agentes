import {humanSize} from "@agenta/entities/drive"
import {type DriveId} from "@agenta/entities/drive"
import {fileOrigin} from "@agenta/entities/drive"
import {type Mount} from "@agenta/entities/session"
import {shortcutAria} from "@agenta/shared/utils"
import {CopyButton} from "@agenta/ui/components/presentational"
import {Tag, EnhancedButton as Button} from "@agenta/ui/components/presentational"
import {ShortcutKeys} from "@agenta/ui/shortcuts"
import {
    DropdownMenu,
    DropdownMenuContent,
    DropdownMenuItem,
    DropdownMenuSeparator,
    DropdownMenuTrigger,
    SimpleTooltip as Tooltip,
} from "@agenta/ui/ui"
import {
    ArrowsIn,
    ArrowsOut,
    CaretDoubleRight,
    DotsThree,
    DownloadSimple,
    GitBranch,
    Info,
    UploadSimple,
    WarningCircle,
    X,
} from "@phosphor-icons/react"

import {DriveBreadcrumb} from "./DriveBreadcrumb"
import {DriveFileDownloadButton} from "./DriveFileContentViewer"
import {DriveRetryButton} from "./DriveFileRow"

/**
 * DriveHeader — the drawer's ONE header. The breadcrumb IS the header (its last crumb the current
 * node), a count/size chip beside it; contextual actions on the right (copy path, a details toggle,
 * download the file), with drive-level bits (raw ids, Download all) folded into the overflow menu.
 * The right/content pane then renders with no header of its own.
 */
export const DriveHeader = ({
    selectedPath,
    isFolder,
    rootLabel,
    itemCount,
    fileSize,
    showOrigin,
    isRepo,
    detailsOpen,
    onToggleDetails,
    onNavigate,
    onClose,
    closeVariant = "close",
    copyText,
    ids,
    downloadMount,
    downloadPath,
    onDownloadAll,
    downloadingAll,
    expanded,
    onToggleExpand,
    partialErrored,
    onRetry,
    retrying,
    onUpload,
    stagedCount = 0,
    onUploadStaged,
}: {
    selectedPath: string | null
    isFolder: boolean
    rootLabel: string
    /** Pick files to upload into the current folder — shown only for a writable mount. */
    onUpload?: () => void
    /** Count of files staged (dropped on a recents peek) awaiting a destination. >0 → show the
     * primary "Upload here" action that commits them into the current folder. */
    stagedCount?: number
    onUploadStaged?: () => void
    /** Immediate-child count for a non-root folder (null when unknown / at root). */
    itemCount: number | null
    fileSize?: number
    showOrigin: boolean
    /** This folder is a git repo → the details toggle reveals repo facts (else file details). */
    isRepo: boolean
    detailsOpen: boolean
    onToggleDetails: () => void
    onNavigate: (path: string) => void
    onClose: () => void
    /** How `onClose` reads: an "×" (overlay drawer) or a "»" that collapses the docked pane. */
    closeVariant?: "close" | "collapse"
    copyText: (text: string, successMessage?: string) => void
    ids: DriveId[]
    downloadMount: Mount | null
    downloadPath: string
    /** Download the whole drive as a zip (the overflow "Download all"); omitted → item disabled. */
    onDownloadAll?: () => void
    downloadingAll?: boolean
    /** Drawer at expanded (near-full) width — the header's expand toggle reflects/flips this. Omit to
     * hide the toggle (embedded/non-drawer hosts that don't own the drawer width). */
    expanded?: boolean
    onToggleExpand?: () => void
    /** A mount failed but the drive still browses — surface a compact warning + retry INLINE in this
     * header (using its existing slack), never a new row. `retrying` drives the spinner. */
    partialErrored?: boolean
    onRetry?: () => void
    retrying?: boolean
}) => {
    // A file always has details (size/modified); a folder only when it's a repo. Nothing selected
    // (transient null before the root auto-selects) → no toggle.
    const hasDetails = isFolder ? isRepo : selectedPath != null
    return (
        // Docked-pane variant: pin the header to the session bar's exact height + border token so
        // its bottom border CONTINUES the bar's line across the divider (offset heights read as
        // two stacked lines at the junction).
        <div
            className={`flex shrink-0 items-center gap-2 border-0 border-b border-solid px-3 ${
                closeVariant === "collapse"
                    ? "h-[48px] border-[var(--ag-surface-card-border)]"
                    : "border-colorBorderSecondary py-2"
            }`}
        >
            <Tooltip
                title={
                    closeVariant === "collapse" ? (
                        <span className="flex items-center gap-1.5">
                            Collapse files <ShortcutKeys id="panel.files" tone="inverse" />
                        </span>
                    ) : (
                        "Close"
                    )
                }
            >
                <Button
                    type="text"
                    aria-keyshortcuts={
                        closeVariant === "collapse" ? shortcutAria("panel.files") : undefined
                    }
                    aria-label={closeVariant === "collapse" ? "Collapse files pane" : "Close"}
                    icon={
                        closeVariant === "collapse" ? (
                            <CaretDoubleRight size={16} />
                        ) : (
                            <X size={16} />
                        )
                    }
                    onClick={onClose}
                    className="!h-7 !w-7 !p-0 !text-colorTextSecondary hover:!text-colorText"
                />
            </Tooltip>
            {onToggleExpand ? (
                <Tooltip title={expanded ? "Collapse" : "Expand"}>
                    <Button
                        type="text"
                        aria-label={expanded ? "Collapse drawer" : "Expand drawer"}
                        aria-pressed={expanded}
                        icon={expanded ? <ArrowsIn size={16} /> : <ArrowsOut size={16} />}
                        onClick={onToggleExpand}
                        className="!h-7 !w-7 !p-0 !text-colorTextSecondary hover:!text-colorText"
                    />
                </Tooltip>
            ) : null}
            {/* Breadcrumb takes the slack and scrolls when the path is long; the chip stays pinned. */}
            <div className="flex min-w-0 flex-1 items-center gap-2">
                <DriveBreadcrumb
                    shown={selectedPath ?? ""}
                    rootLabel={rootLabel}
                    onNavigate={onNavigate}
                />
                {/* A folder's child count / a file's size. The root gets no chip — a whole-drive
                    file count says nothing about what you're looking at. */}
                <span className="shrink-0 text-xs text-colorTextTertiary">
                    {isFolder
                        ? itemCount != null
                            ? `${itemCount} item${itemCount === 1 ? "" : "s"}`
                            : null
                        : fileSize != null
                          ? humanSize(fileSize)
                          : null}
                </span>
                {!isFolder && showOrigin && selectedPath ? (
                    <Tag className="m-0 shrink-0 text-[12px] font-normal">
                        {fileOrigin(selectedPath) === "agent" ? "Agent" : "Session"}
                    </Tag>
                ) : null}
            </div>
            {/* A mount failed but the drive still browses — a compact warning + retry that lives in
                the header's existing slack (never a new row). Tooltip carries the full message so the
                inline footprint stays "⚠ Try again". */}
            {partialErrored && onRetry ? (
                <Tooltip title="Some files couldn’t be loaded">
                    <span className="flex shrink-0 items-center gap-1.5 whitespace-nowrap">
                        <WarningCircle
                            size={14}
                            weight="fill"
                            className="shrink-0 text-colorWarning"
                        />
                        <DriveRetryButton onRetry={onRetry} busy={retrying} />
                    </span>
                </Tooltip>
            ) : null}
            <div className="flex shrink-0 items-center gap-1">
                {/* ONE upload button, context-dependent: with files staged it commits them into this
                    folder (primary-tinted); otherwise it opens the file picker (neutral). */}
                {stagedCount > 0 && onUploadStaged ? (
                    <Tooltip
                        title={`Upload ${stagedCount} file${stagedCount === 1 ? "" : "s"} here`}
                    >
                        <Button
                            type="text"
                            aria-label={`Upload ${stagedCount} staged file${stagedCount === 1 ? "" : "s"} to this folder`}
                            icon={<UploadSimple size={16} weight="bold" />}
                            onClick={onUploadStaged}
                            className="!h-7 !w-7 !p-0 !bg-[var(--ant-color-primary-bg)] !text-colorPrimary hover:!text-colorPrimary"
                        />
                    </Tooltip>
                ) : onUpload ? (
                    <Tooltip title="Upload to this folder">
                        <Button
                            type="text"
                            aria-label="Upload files"
                            icon={<UploadSimple size={16} />}
                            onClick={onUpload}
                            className="!h-7 !w-7 !p-0 !text-colorTextSecondary hover:!text-colorText"
                        />
                    </Tooltip>
                ) : null}
                {selectedPath ? (
                    <Tooltip title="Copy path">
                        <CopyButton
                            text={selectedPath}
                            buttonText={null}
                            icon
                            size="icon-sm"
                            aria-label="Copy path"
                            successMessage=""
                            className="!h-7 !w-7 !p-0 !text-colorTextTertiary hover:!text-colorText"
                        />
                    </Tooltip>
                ) : null}
                {hasDetails ? (
                    <Tooltip title={isFolder ? "Repository details" : "File details"}>
                        <Button
                            type="text"
                            aria-label={isFolder ? "Repository details" : "File details"}
                            aria-pressed={detailsOpen}
                            onClick={onToggleDetails}
                            icon={
                                isFolder ? (
                                    <GitBranch
                                        size={16}
                                        weight={detailsOpen ? "fill" : "regular"}
                                    />
                                ) : (
                                    <Info size={16} weight={detailsOpen ? "fill" : "regular"} />
                                )
                            }
                            className={`!h-7 !w-7 !p-0 ${detailsOpen ? "!text-colorPrimary" : "!text-colorTextTertiary hover:!text-colorText"}`}
                        />
                    </Tooltip>
                ) : null}
                {!isFolder && selectedPath ? (
                    <DriveFileDownloadButton mount={downloadMount} path={downloadPath} />
                ) : null}
                <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                        <Button
                            type="text"
                            aria-label="More actions"
                            icon={<DotsThree size={18} weight="bold" />}
                            className="!h-7 !w-7 !p-0 !text-colorTextTertiary hover:!text-colorText"
                        />
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                        {ids.map((id) => (
                            <DropdownMenuItem
                                key={id.key}
                                onSelect={() => copyText(id.value, `${id.label} copied`)}
                            >
                                <span className="flex flex-col gap-0.5 py-0.5">
                                    <span className="text-xs font-medium">Copy {id.label}</span>
                                    <span className="font-mono text-[12px] text-colorTextTertiary">
                                        {id.value}
                                    </span>
                                </span>
                            </DropdownMenuItem>
                        ))}
                        {/* Only a separator when there IS something above it — a host without
                            drive ids (they resolve async, and the local-file drive never has any)
                            otherwise opens on a stray rule. */}
                        {ids.length ? <DropdownMenuSeparator /> : null}
                        <DropdownMenuItem
                            disabled={!onDownloadAll || downloadingAll}
                            onSelect={() => onDownloadAll?.()}
                        >
                            <DownloadSimple size={14} />
                            {downloadingAll ? "Preparing download…" : "Download all"}
                        </DropdownMenuItem>
                    </DropdownMenuContent>
                </DropdownMenu>
            </div>
        </div>
    )
}
