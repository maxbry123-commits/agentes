/**
 * SchemaPropertyRenderer
 *
 * Universal schema-driven field renderer that routes to appropriate controls
 * based on JSON Schema metadata. This is the primary component for rendering
 * configuration fields in a schema-driven UI.
 *
 * Unlike PlaygroundVariantPropertyControl, this component:
 * - Has no dependency on legacy playground atoms
 * - Accepts schema as a prop (not from global metadata)
 * - Uses simple value/onChange props (not atom-based mutations)
 * - Works with any entity controller pattern
 */

import {lazy, memo, Suspense, useMemo} from "react"

import type {SchemaProperty} from "@agenta/entities/shared"
import {formatLabel} from "@agenta/ui/drill-in"
import clsx from "clsx"

import AgentConfigSkeleton from "./agentTemplate/AgentConfigSkeleton"
import {BooleanToggleControl} from "./BooleanToggleControl"
import {CodeEditorControl} from "./CodeEditorControl"
import {EnumSelectControl} from "./EnumSelectControl"
import {FeedbackConfigurationControl} from "./FeedbackConfigurationControl"
import {FieldsTagsEditorControl} from "./FieldsTagsEditorControl"
import {GroupedChoiceControl} from "./GroupedChoiceControl"
import {MessagesSchemaControl, isMessagesSchema} from "./MessagesSchemaControl"
import {NumberSliderControl} from "./NumberSliderControl"
import {ObjectSchemaControl} from "./ObjectSchemaControl"
import {PromptSchemaControl, isPromptSchema, isPromptValue} from "./PromptSchemaControl"
import {hasGroupedChoices, resolveAnyOfSchema, shouldRenderObjectInline} from "./schemaUtils"
import {TextInputControl} from "./TextInputControl"

// The agent config composite (sections + item drawers + markdown editor) is the heaviest
// control in the registry and only renders for agent-template schemas — code-split it so
// non-agent config panels never load it and agent panels load it behind its skeleton.
const AgentTemplateControl = lazy(() =>
    import("./AgentTemplateControl").then((m) => ({default: m.AgentTemplateControl})),
)

/** Warm the agent-template chunk during idle time (e.g. as soon as the playground knows the
 * app is an agent), so its download + execution doesn't coincide with the revision/schema
 * resolving — that combination is a main-thread burst right as the panel paints. */
export const preloadAgentTemplateControl = () => import("./AgentTemplateControl")

export interface SchemaPropertyRendererProps {
    /** The schema property defining the field */
    schema: SchemaProperty | null | undefined
    /** Display label for the field */
    label: string
    /** Current value */
    value: unknown
    /** Change handler */
    onChange: (value: unknown) => void
    /** Optional description override */
    description?: string
    /** Whether to show tooltip */
    withTooltip?: boolean
    /** Disable the control */
    disabled?: boolean
    /** Placeholder text (for text/select fields) */
    placeholder?: string
    /** Additional CSS classes */
    className?: string
    /** Path to this property (for debugging) */
    path?: string[]
    /**
     * Force a specific control type.
     * Useful when schema type is ambiguous or for custom rendering.
     */
    as?: "number" | "text" | "enum" | "boolean" | "textarea"
    /** Hide the model selector in prompt controls (when shown elsewhere) */
    hideModelSelector?: boolean
    /** Optional renderer for provider icons in tool headers */
    renderProviderIcon?: (providerKey: string) => React.ReactNode
    /** Entity ID for scoping modal state per variant (e.g., response format modal) */
    entityId?: string
    /**
     * Original server value for preserving custom descriptions.
     * Used by FeedbackConfigurationControl to maintain custom descriptions
     * when regenerating schemas from UI changes.
     */
    originalValue?: unknown
}

/**
 * Determine the best control type for a schema property.
 * Falls back to value-based detection when schema is not available.
 */
function getControlType(
    schema: SchemaProperty | null | undefined,
    value: unknown,
    forceType?: SchemaPropertyRendererProps["as"],
):
    | "number"
    | "text"
    | "enum"
    | "boolean"
    | "textarea"
    | "code"
    | "object"
    | "object_inline"
    | "array"
    | "messages"
    | "prompt"
    | "grouped_choice"
    | "feedback_config"
    | "fields_tags_editor"
    | "agent-template"
    | "hidden"
    | "unknown" {
    if (forceType) return forceType

    // Resolve semantic type markers using priority: x-ag-type-ref → x-ag-type → x-parameter
    const xAgTypeRef = (schema as Record<string, unknown>)?.["x-ag-type-ref"] as string | undefined
    const xAgType = (schema as Record<string, unknown>)?.["x-ag-type"] as string | undefined
    const xParam = schema?.["x-parameter"] as string | undefined

    // Check semantic type hints in priority order
    if (xAgTypeRef === "hidden" || xAgType === "hidden") {
        return "hidden"
    }
    if (
        xAgTypeRef === "feedback_config" ||
        xAgType === "feedback_config" ||
        xParam === "feedback_config"
    ) {
        return "feedback_config"
    }
    if (
        xAgTypeRef === "fields_tags_editor" ||
        xAgType === "fields_tags_editor" ||
        xParam === "fields_tags_editor"
    ) {
        return "fields_tags_editor"
    }
    if (xAgTypeRef === "code" || xAgType === "code") {
        return "code"
    }
    if (xAgTypeRef === "agent-template" || xAgType === "agent-template") {
        return "agent-template"
    }

    // When schema is null, fall back to value-based detection
    if (!schema) {
        // Check for prompt object by value
        if (isPromptValue(value)) {
            return "prompt"
        }
        // For other objects without schema, render as object
        if (value && typeof value === "object" && !Array.isArray(value)) {
            return "object"
        }
        // For arrays without schema
        if (Array.isArray(value)) {
            return "array"
        }
        return "text"
    }

    // Resolve anyOf/oneOf schemas to get the actual type (handles nullable types)
    const resolvedSchema = resolveAnyOfSchema(schema)
    if (!resolvedSchema) return "text"

    // Check for prompt objects (with messages array) - must be first
    // isPromptSchema already checks x-ag-type-ref: "prompt-template"
    if (isPromptSchema(resolvedSchema)) {
        return "prompt"
    }

    // Check for grouped choices (e.g., model selection) - must be before enum check
    // hasGroupedChoices already checks x-ag-type: "grouped_choice"
    if (hasGroupedChoices(resolvedSchema)) {
        return "grouped_choice"
    }

    // Check for messages array (chat messages) - must be before generic array check
    // isMessagesSchema already checks x-ag-type: "messages"
    if (isMessagesSchema(resolvedSchema)) {
        return "messages"
    }

    // Check for enum - show as select regardless of base type
    if (
        resolvedSchema.enum &&
        Array.isArray(resolvedSchema.enum) &&
        resolvedSchema.enum.length > 0
    ) {
        return "enum"
    }

    // Fall back to JSON Schema type
    switch (resolvedSchema.type) {
        case "boolean":
            return "boolean"

        case "number":
        case "integer":
            return "number"

        case "string": {
            // Check for code editor hint (legacy x-parameters.code)
            const xParams = schema?.["x-parameters"] as SchemaProperty["x-parameters"]
            if (xParams?.code === true) {
                return "code"
            }
            // Check for multiline hint
            if (xParams?.multiline === true) {
                return "textarea"
            }
            return "text"
        }

        case "object":
            // Check if object should be rendered inline (e.g., llm_config)
            if (shouldRenderObjectInline(schema)) {
                return "object_inline"
            }
            return "object"

        case "array":
            return "array"

        default:
            return "unknown"
    }
}

/**
 * Universal schema-driven field renderer.
 *
 * Routes to appropriate control based on schema type:
 * - number/integer → NumberSliderControl
 * - string (with grouped choices) → GroupedChoiceControl (e.g., model selection)
 * - string (with enum) → EnumSelectControl
 * - string → TextInputControl
 * - string (multiline) → TextInputControl with multiline
 * - boolean → BooleanToggleControl
 * - object (llm_config-like) → ObjectSchemaControl (inline properties)
 * - object → Shows nested object indicator (drill-in)
 * - array (messages) → MessagesSchemaControl (chat message UI)
 * - array → Shows array indicator (drill-in)
 *
 * Detects grouped choices via:
 * - x-parameter: "grouped_choice" or "choice" with choices object
 * - choices property as { provider: [models] } structure
 *
 * Detects messages arrays via:
 * - x-parameter: "messages"
 * - Array items with role/content properties
 *
 * @example
 * ```tsx
 * // Basic usage with schema
 * <SchemaPropertyRenderer
 *   schema={{ type: "number", minimum: 0, maximum: 1 }}
 *   label="Temperature"
 *   value={0.7}
 *   onChange={(v) => setTemperature(v as number)}
 * />
 *
 * // With entity controller
 * const schema = useAtomValue(appRevision.selectors.schemaAtPath({ revisionId, path }))
 * const value = entity.drillIn.getValueAtPath(data, path)
 * <SchemaPropertyRenderer
 *   schema={schema}
 *   label={formatLabel(path[path.length - 1])}
 *   value={value}
 *   onChange={(v) => dispatch({ type: 'setAtPath', path, value: v })}
 * />
 * ```
 */
export const SchemaPropertyRenderer = memo(function SchemaPropertyRenderer({
    schema,
    label,
    value,
    onChange,
    description,
    withTooltip = true,
    disabled = false,
    placeholder,
    className,
    path,
    as,
    hideModelSelector = false,
    renderProviderIcon,
    originalValue,
    entityId,
}: SchemaPropertyRendererProps) {
    // Resolve anyOf/oneOf schemas for rendering
    const resolvedSchema = useMemo(() => resolveAnyOfSchema(schema), [schema])
    const controlType = useMemo(() => getControlType(schema, value, as), [schema, value, as])

    // Format label from path if not provided
    // Use ?? to respect empty string (label="") vs undefined/null
    const displayLabel = label ?? (path?.length ? formatLabel(path[path.length - 1]) : "Value")

    // Get description from schema or prop
    const tooltipDesc = description ?? (schema?.description as string | undefined)

    // Render based on control type (use resolvedSchema for type info like min/max)
    switch (controlType) {
        case "number":
            return (
                <NumberSliderControl
                    schema={resolvedSchema}
                    label={displayLabel}
                    value={value as number | null}
                    onChange={(v) => onChange(v)}
                    description={tooltipDesc}
                    withTooltip={withTooltip}
                    disabled={disabled}
                    placeholder={placeholder}
                    className={className}
                />
            )

        case "grouped_choice":
            return (
                <GroupedChoiceControl
                    schema={resolvedSchema}
                    label={displayLabel}
                    value={value as string | null}
                    onChange={(v) => onChange(v)}
                    description={tooltipDesc}
                    withTooltip={withTooltip}
                    disabled={disabled}
                    placeholder={placeholder}
                    className={className}
                />
            )

        case "enum":
            return (
                <EnumSelectControl
                    schema={resolvedSchema}
                    label={displayLabel}
                    value={value as string | null}
                    onChange={(v) => onChange(v)}
                    description={tooltipDesc}
                    withTooltip={withTooltip}
                    disabled={disabled}
                    placeholder={placeholder}
                    className={className}
                />
            )

        case "boolean":
            return (
                <BooleanToggleControl
                    schema={resolvedSchema}
                    label={displayLabel}
                    value={value as boolean | null}
                    onChange={(v) => onChange(v)}
                    description={tooltipDesc}
                    withTooltip={withTooltip}
                    disabled={disabled}
                    className={className}
                />
            )

        case "code":
            return (
                <CodeEditorControl
                    schema={resolvedSchema}
                    label={displayLabel}
                    value={value as string | null}
                    onChange={(v) => onChange(v)}
                    description={tooltipDesc}
                    withTooltip={withTooltip}
                    disabled={disabled}
                    className={className}
                />
            )

        case "textarea":
            return (
                <TextInputControl
                    schema={resolvedSchema}
                    label={displayLabel}
                    value={value as string | null}
                    onChange={(v) => onChange(v)}
                    description={tooltipDesc}
                    withTooltip={withTooltip}
                    disabled={disabled}
                    placeholder={placeholder}
                    multiline
                    className={className}
                />
            )

        case "text":
            return (
                <TextInputControl
                    schema={resolvedSchema}
                    label={displayLabel}
                    value={value as string | null}
                    onChange={(v) => onChange(v)}
                    description={tooltipDesc}
                    withTooltip={withTooltip}
                    disabled={disabled}
                    placeholder={placeholder}
                    className={className}
                />
            )

        case "object_inline":
            // Render object properties inline (e.g., llm_config, advanced_config)
            // Hide header for top-level fields (path.length === 1) since they already have a section header
            return (
                <ObjectSchemaControl
                    schema={resolvedSchema}
                    label={displayLabel}
                    value={value as Record<string, unknown> | null}
                    onChange={(v) => onChange(v)}
                    description={tooltipDesc}
                    withTooltip={withTooltip}
                    disabled={disabled}
                    path={path}
                    className={className}
                    showHeader={path && path.length > 1}
                    SchemaPropertyRenderer={SchemaPropertyRenderer}
                />
            )

        case "messages":
            // Render chat messages array with specialized UI
            return (
                <MessagesSchemaControl
                    schema={resolvedSchema}
                    label={displayLabel}
                    value={value as unknown[] | null}
                    onChange={(v) => onChange(v)}
                    description={tooltipDesc}
                    disabled={disabled}
                    className={className}
                />
            )

        case "agent-template":
            // Render the whole agent config (instructions, model, tools, runtime) as one
            // composite control that reuses the model selector, tool picker, and enums.
            // The Suspense fallback is the SAME skeleton the schema-loading gate shows,
            // so the two gates read as one continuous frame while the chunk loads.
            return (
                <Suspense fallback={<AgentConfigSkeleton />}>
                    <AgentTemplateControl
                        schema={resolvedSchema}
                        label={displayLabel}
                        value={value as Record<string, unknown> | null}
                        onChange={(v) => onChange(v)}
                        description={tooltipDesc}
                        withTooltip={withTooltip}
                        disabled={disabled}
                        className={className}
                    />
                </Suspense>
            )

        case "prompt":
            // Render prompt object with message cards and LLM config
            return (
                <PromptSchemaControl
                    schema={resolvedSchema}
                    label={displayLabel}
                    value={value as Record<string, unknown> | null}
                    onChange={(v) => onChange(v)}
                    description={tooltipDesc}
                    disabled={disabled}
                    className={className}
                    hideModelSelector={hideModelSelector}
                    renderProviderIcon={renderProviderIcon}
                    entityId={entityId}
                />
            )

        case "feedback_config":
            // Render feedback configuration control directly (outer collapse is handled by PlaygroundConfigSection)
            return (
                <FeedbackConfigurationControl
                    value={(value as Record<string, unknown>)?.json_schema ?? value}
                    originalValue={
                        (originalValue as Record<string, unknown>)?.json_schema ?? originalValue
                    }
                    onChange={(schema: unknown) => {
                        // Update the response_format object with the new json_schema
                        const currentValue = (value as Record<string, unknown>) ?? {}
                        onChange({
                            ...currentValue,
                            type: "json_schema",
                            json_schema: schema,
                        })
                    }}
                    disabled={disabled}
                    className={className}
                    entityId={entityId}
                />
            )

        case "object":
            // For objects, show indicator that user should navigate into it
            return (
                <div className={clsx("flex flex-col gap-1", className)}>
                    <span className="text-sm font-medium text-colorText">{displayLabel}</span>
                    <span className="text-xs text-colorTextDescription">
                        Object with{" "}
                        {resolvedSchema?.properties
                            ? Object.keys(resolvedSchema.properties).length
                            : 0}{" "}
                        properties (click to expand)
                    </span>
                </div>
            )

        case "fields_tags_editor":
            return (
                <FieldsTagsEditorControl
                    schema={resolvedSchema}
                    label={displayLabel}
                    value={Array.isArray(value) ? (value as string[]) : []}
                    onChange={(v) => onChange(v)}
                    description={tooltipDesc}
                    withTooltip={withTooltip}
                    disabled={disabled}
                    className={className}
                />
            )

        case "array":
            // For arrays, show indicator that user should navigate into it
            return (
                <div className={clsx("flex flex-col gap-1", className)}>
                    <span className="text-sm font-medium text-colorText">{displayLabel}</span>
                    <span className="text-xs text-colorTextDescription">
                        Array with {Array.isArray(value) ? value.length : 0} items (click to expand)
                    </span>
                </div>
            )

        case "hidden":
            return null

        case "unknown":
        default:
            // Fallback to text input for unknown types
            return (
                <TextInputControl
                    schema={resolvedSchema}
                    label={displayLabel}
                    value={typeof value === "string" ? value : JSON.stringify(value ?? "")}
                    onChange={(v) => {
                        // Try to parse as JSON for complex types
                        try {
                            onChange(JSON.parse(v))
                        } catch {
                            onChange(v)
                        }
                    }}
                    description={tooltipDesc}
                    withTooltip={withTooltip}
                    disabled={disabled}
                    placeholder={placeholder}
                    className={className}
                />
            )
    }
})
