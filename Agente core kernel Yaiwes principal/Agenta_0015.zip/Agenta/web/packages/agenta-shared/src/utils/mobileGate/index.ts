/**
 * Mobile device gate — pure decision core (agenta-mobile WP5).
 *
 * Framework-free: the Next middlewares (desktop forward gate in web/oss +
 * web/ee, mobile reverse gate in web/mobile) adapt NextRequest into a
 * `GateInput` and apply the returned `GateDecision`. Keeping the logic pure
 * means detection, the deep-link map, cookie semantics, and the documented
 * exceptions are all unit-tested here without NextRequest mocks.
 *
 * web/mobile carries a DECLARED VERBATIM COPY of the reverse-gate subset
 * (it has no workspace deps until WP2 wires @agenta/* into its compose
 * service and Dockerfile) — see the copy header in web/mobile/src/middleware.ts.
 * Behavior changes must land here first, then be mirrored there.
 */

export const MOBILE_OPTOUT_COOKIE = "agenta-mobile-optout"
export const MOBILE_OPTIN_COOKIE = "agenta-mobile-optin"
/**
 * Set by the mobile app right before it sends the browser to an OIDC provider,
 * and cleared by /m/auth/callback. Providers only ever redirect to the ONE
 * registered URI (the desktop `/auth/callback/<providerId>`), so this cookie is
 * how the desktop gate knows a landing callback belongs to the mobile app and
 * must be handed to /m — where the OAuth state lives in the same-origin
 * sessionStorage. Short-lived (see MOBILE_AUTH_CALLBACK_MAX_AGE).
 */
export const MOBILE_AUTH_CALLBACK_COOKIE = "agenta-mobile-auth-callback"
/** 10 minutes — matches SuperTokens' own OAuth state expiry. */
export const MOBILE_AUTH_CALLBACK_MAX_AGE = 60 * 10
/** Reserved query param: `view=desktop` | `view=mobile` set the escape cookies. */
export const VIEW_PARAM = "view"
/** 180 days, in seconds. */
export const GATE_COOKIE_MAX_AGE = 60 * 60 * 24 * 180

export interface GateInput {
    /** `nextUrl.pathname`, WITHOUT the app basePath (`/m` already stripped). */
    pathname: string
    /** `nextUrl.search` including the leading `?`, or "". */
    search: string
    method: string
    /** Case-insensitive header getter (NextRequest headers already are). */
    header: (name: string) => string | null
    cookie: (name: string) => string | undefined
    /**
     * AGENTA_MOBILE_GATE, resolved by the adapter at request time with
     * `resolveGateEnabled`. DEFAULT ON: a deployment opts out with
     * `AGENTA_MOBILE_GATE=false`.
     */
    gateEnabled: boolean
    /**
     * AGENTA_MOBILE_REVERSE_GATE, mobile-app only. `false` keeps the forward gate (mobile
     * devices → /m) while letting anything reach /m: tablets and desktop-UA browsers report
     * as non-mobile, so the bounce blocks deliberate visits. Defaults to on.
     */
    reverseGateEnabled?: boolean
}

/**
 * Env → flag, for both gates. DEFAULT ON: only the exact string "false" turns a
 * gate off, so an unset, empty, or misspelled value keeps the mobile app
 * reachable. Both gates ship on so that no deployment (cloud, self-hosted
 * compose, Railway, local dev) needs an env key to give phones /m; the keys are
 * an opt-OUT.
 *
 * The adapters read process.env INSIDE the request handler, never at module
 * scope: on the self-hosted standalone Node server, non-NEXT_PUBLIC env is
 * resolved at runtime, so flipping the key and recreating the container is
 * enough — no rebuild.
 */
export function resolveGateEnabled(raw: string | undefined | null): boolean {
    return raw !== "false"
}

export type GateDecision =
    | {kind: "pass"}
    | {kind: "redirect"; location: string}
    | {kind: "set-cookie-redirect"; cookie: string; clearCookie: string; location: string}

/** UA fallback for browsers that send no client hints (Safari, Firefox). */
const MOBILE_UA_RE = /Android|iPhone|iPod|iPad|webOS|BlackBerry|IEMobile|Opera Mini|Mobile/i

export function isMobileDevice(header: GateInput["header"]): boolean {
    const hint = header("sec-ch-ua-mobile")
    if (hint === "?1") return true
    if (hint === "?0") return false
    return MOBILE_UA_RE.test(header("user-agent") ?? "")
}

/** Only gate top-level document navigations — never assets, fetches, or POSTs. */
export function isDocumentNavigation(input: Pick<GateInput, "method" | "header">): boolean {
    if (input.method !== "GET" && input.method !== "HEAD") return false
    const dest = input.header("sec-fetch-dest")
    if (dest) return dest === "document"
    return (input.header("accept") ?? "").includes("text/html")
}

/**
 * Desktop routes that must never redirect to /m (design.md documented
 * exceptions). /auth now maps to the mobile sign-in (→ /m/auth), EXCEPT
 * /auth/callback: an OAuth/SSO redirect landing must never be bounced mid-flow,
 * because the redirect URI is fixed at the provider. When the mobile app started
 * the flow (MOBILE_AUTH_CALLBACK_COOKIE) the landing is forwarded to the mirror
 * page under /m instead — see decideDesktopGate. /post-signup and
 * /workspaces/accept are permanently desktop-only.
 */
const AUTH_CALLBACK_RE = /^\/auth\/callback(\/|$)/

const AUTH_RE = /^\/auth(\/|$)/

/**
 * An `/auth` link carrying a one-time `token` (SuperTokens password reset, invite acceptance —
 * `web/oss/src/pages/auth/[[...path]].tsx` reads `router.query.token`) completes on desktop.
 *
 * Redirecting it would drop the token twice over: `mapDesktopToMobile` returns a bare `/m/auth`,
 * and the mobile app has no screen that consumes one. Same reasoning as the OAuth callback
 * exception — a single-use credential must not be bounced.
 */
export function isTokenBearingAuthLink(pathname: string, search: string): boolean {
    if (!AUTH_RE.test(pathname)) return false
    return Boolean(new URLSearchParams(search).get("token"))
}

/**
 * An `/auth` link carrying `auth_error` completes on desktop, for the same reason as a token: the
 * param IS the payload. `web/oss/src/lib/api/assets/axiosConfig.ts` redirects a 403 here so the
 * user can finish required SSO or social re-authentication, and the desktop auth page reads it.
 * `mapDesktopToMobile` returns a bare `/m/auth`, so redirecting would drop the reason and leave
 * the user on a sign-in screen that cannot explain why it appeared.
 */
export function isPolicyAuthLink(pathname: string, search: string): boolean {
    if (!AUTH_RE.test(pathname)) return false
    return Boolean(new URLSearchParams(search).get("auth_error"))
}

const DESKTOP_EXCEPTIONS = [AUTH_CALLBACK_RE, /^\/post-signup(\/|$)/, /^\/workspaces\/accept(\/|$)/]

const PROJECT_PATH_RE = /^\/w\/([^/]+)\/p\/([^/]+)(\/|$)/

/** Desktop URL → mobile equivalent (design.md "Gate and routing"). */
export function mapDesktopToMobile(pathname: string, search: string): string {
    // Mobile sign-in: /auth/callback never reaches here (handled as an exception).
    if (/^\/auth(\/|$)/.test(pathname)) return "/m/auth"
    const m = pathname.match(PROJECT_PATH_RE)
    if (m) {
        const [, ws, proj] = m
        // /observability?session={id} is the desktop session deep link today
        // (web/oss/src/state/url/session.ts) — land in that session's chat.
        const sessionId = new URLSearchParams(search).get("session")
        if (sessionId && /\/observability(\/|$)/.test(pathname)) {
            return `/m/w/${ws}/p/${proj}/sessions/${encodeURIComponent(sessionId)}`
        }
        return `/m/w/${ws}/p/${proj}/sessions`
    }
    // No project context: the mobile root resolves last-used workspace/project
    // (same resolution as post-login) and forwards to the sessions list.
    return "/m/"
}

/** Mobile URL (basePath already stripped) → desktop equivalent. */
export function mapMobileToDesktop(pathname: string): string {
    const m = pathname.match(/^\/w\/([^/]+)\/p\/([^/]+)\/sessions(?:\/([^/]+))?\/?$/)
    if (m) {
        const [, ws, proj, sessionId] = m
        const base = `/w/${ws}/p/${proj}/observability`
        // Desktop opens sessions via the observability SessionDrawer today.
        // TODO(post-WP5): retarget to the agent playground once it adopts
        // sessions from the URL (adoptSessionAtomFamily has no URL caller yet).
        return sessionId ? `${base}?session=${encodeURIComponent(sessionId)}` : base
    }
    if (/^\/auth(\/|$)/.test(pathname)) return "/auth"
    return "/w"
}

function stripViewParam(pathname: string, search: string): string {
    const params = new URLSearchParams(search)
    params.delete(VIEW_PARAM)
    const qs = params.toString()
    return qs ? `${pathname}?${qs}` : pathname
}

/** Forward gate: runs in the DESKTOP apps. Sees no /m traffic behind Traefik. */
export function decideDesktopGate(input: GateInput): GateDecision {
    try {
        // `?view=desktop` outranks everything below, including the callback handback: it is the
        // user saying "keep me here", and it must still win now that the callback check runs
        // before the flag.
        const wantsDesktop = new URLSearchParams(input.search).get(VIEW_PARAM) === "desktop"

        // BEFORE the flag: a provider redirect the MOBILE app started has to reach /m whether or
        // not the device gate is on. The cookie is an explicit intent set by /m moments earlier,
        // not a device heuristic, and the OAuth state lives in /m's same-origin sessionStorage.
        // A deployment that opts out with AGENTA_MOBILE_GATE=false still runs /m, so gating this
        // strands every mobile SSO sign-in on the desktop route, where the state it needs does
        // not exist.
        if (
            !wantsDesktop &&
            isDocumentNavigation(input) &&
            AUTH_CALLBACK_RE.test(input.pathname) &&
            input.cookie(MOBILE_AUTH_CALLBACK_COOKIE)
        ) {
            return {kind: "redirect", location: `/m${input.pathname}${input.search}`}
        }

        if (!input.gateEnabled) return {kind: "pass"}
        if (!isDocumentNavigation(input)) return {kind: "pass"}

        // Escape hatch: "View desktop site" links carry ?view=desktop.
        if (wantsDesktop) {
            return {
                kind: "set-cookie-redirect",
                cookie: MOBILE_OPTOUT_COOKIE,
                clearCookie: MOBILE_OPTIN_COOKIE,
                location: stripViewParam(input.pathname, input.search),
            }
        }

        // The mobile-started callback is handled above, before the flag.
        if (DESKTOP_EXCEPTIONS.some((re) => re.test(input.pathname))) return {kind: "pass"}
        // A one-time token completes where it landed; see isTokenBearingAuthLink.
        if (isTokenBearingAuthLink(input.pathname, input.search)) return {kind: "pass"}
        // Same reasoning for a policy error; see isPolicyAuthLink.
        if (isPolicyAuthLink(input.pathname, input.search)) return {kind: "pass"}
        if (input.cookie(MOBILE_OPTOUT_COOKIE)) return {kind: "pass"}
        if (!isMobileDevice(input.header)) return {kind: "pass"}

        return {kind: "redirect", location: mapDesktopToMobile(input.pathname, input.search)}
    } catch {
        // Design rule: the gate never hard-fails — ambiguity falls through.
        return {kind: "pass"}
    }
}

/** Reverse gate: runs in the MOBILE app. Sees only /m traffic behind Traefik. */
export function decideMobileGate(input: GateInput): GateDecision {
    try {
        if (!input.gateEnabled) return {kind: "pass"}
        if (!isDocumentNavigation(input)) return {kind: "pass"}

        // Escape hatch: "Open mobile version" links carry ?view=mobile.
        if (new URLSearchParams(input.search).get(VIEW_PARAM) === "mobile") {
            return {
                kind: "set-cookie-redirect",
                cookie: MOBILE_OPTIN_COOKIE,
                clearCookie: MOBILE_OPTOUT_COOKIE,
                location: stripViewParam(input.pathname, input.search),
            }
        }

        // An OAuth landing completes wherever it lands — bouncing it drops the
        // one-time code and strands the flow.
        if (AUTH_CALLBACK_RE.test(input.pathname)) return {kind: "pass"}
        if (input.cookie(MOBILE_OPTIN_COOKIE)) return {kind: "pass"}
        // Checked after ?view=mobile so the opt-in cookie is still set if the bounce is re-enabled.
        if (input.reverseGateEnabled === false) return {kind: "pass"}
        if (isMobileDevice(input.header)) return {kind: "pass"}

        return {kind: "redirect", location: mapMobileToDesktop(input.pathname)}
    } catch {
        return {kind: "pass"}
    }
}
