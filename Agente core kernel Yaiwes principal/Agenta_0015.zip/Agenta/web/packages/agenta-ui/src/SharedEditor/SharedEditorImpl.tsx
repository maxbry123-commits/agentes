import {
    ChangeEvent,
    ClipboardEvent,
    startTransition,
    useCallback,
    useEffect,
    useMemo,
    useRef,
    useState,
} from "react"

import {useDebounceInput} from "@agenta/shared/hooks"
import clsx from "clsx"
import {v4 as uuidv4} from "uuid"

import {Input} from "../components/ui/input"
import {AutosizeTextarea} from "../components/ui/input-composed"
import {Spinner} from "../components/ui/spinner"
import {Editor, isLargeRichTextDocument} from "../Editor"

import {isSharedAntdTextareaProps, type SharedAntdTextareaProps} from "./types"
import type {SharedEditorProps} from "./types"

const LARGE_INPUT_EXTERNAL_COMMIT_DELAY_MS = 180
const DEFAULT_MAX_TEXT_PASTE_CHARS = 50_000

function looksLikePlainTextContent(value: string): boolean {
    if (!value) {
        return true
    }

    return !/(^|\n)\s{0,3}[#>*-]|\[[^\]]+\]\([^)]+\)|`{1,3}|\*\*|__/.test(value)
}

function getSelectionOffsets(rootElement: HTMLElement): {start: number; end: number} | null {
    if (typeof window === "undefined") {
        return null
    }

    const selection = window.getSelection()
    if (!selection || selection.rangeCount === 0) {
        return null
    }

    const range = selection.getRangeAt(0)
    if (!rootElement.contains(range.startContainer) || !rootElement.contains(range.endContainer)) {
        return null
    }

    const prefixRange = range.cloneRange()
    prefixRange.selectNodeContents(rootElement)
    prefixRange.setEnd(range.startContainer, range.startOffset)

    const start = prefixRange.toString().length
    const end = start + range.toString().length
    return {start, end}
}

function getInputSelectionOffsets(
    element: HTMLInputElement | HTMLTextAreaElement,
): {start: number; end: number} | null {
    const start = element.selectionStart
    const end = element.selectionEnd

    if (typeof start !== "number" || typeof end !== "number") {
        return null
    }

    return {start, end}
}

function getTargetSelectionOffsets(
    target: EventTarget | null,
): {start: number; end: number} | null {
    if (!(target instanceof HTMLElement)) {
        return null
    }

    if (target instanceof HTMLInputElement || target instanceof HTMLTextAreaElement) {
        return getInputSelectionOffsets(target)
    }

    const contentEditable = target.closest(".editor-input") as HTMLElement | null
    if (!contentEditable) {
        return null
    }

    return getSelectionOffsets(contentEditable)
}

function formatCharacterCount(value: number): string {
    return value.toLocaleString()
}

function buildPasteLimitErrorMessage(nextLength: number, maxPasteChars: number): string {
    const overBy = nextLength - maxPasteChars

    return `Paste blocked. This would exceed the ${formatCharacterCount(maxPasteChars)}-character limit by ${formatCharacterCount(overBy)} characters (${formatCharacterCount(nextLength)} total). Reduce the pasted content and try again.`
}

function applyPasteToValue(
    currentValue: string,
    pastedValue: string,
    selectionOffsets: {start: number; end: number} | null,
): string {
    if (!selectionOffsets) {
        return `${currentValue}${pastedValue}`
    }

    const start = Math.max(0, Math.min(selectionOffsets.start, currentValue.length))
    const end = Math.max(start, Math.min(selectionOffsets.end, currentValue.length))
    return `${currentValue.slice(0, start)}${pastedValue}${currentValue.slice(end)}`
}

/**
 * SharedEditor - A flexible editor wrapper with support for both rich text and code editing.
 *
 * Features:
 * - Borderless or bordered styling
 * - Debounced input handling
 * - Optional header/footer slots
 * - Support for antd Input as fallback
 * - Code-only mode with syntax highlighting
 *
 * @example
 * ```tsx
 * <SharedEditor
 *   initialValue="Hello World"
 *   handleChange={(value) => console.log(value)}
 *   placeholder="Enter text..."
 * />
 * ```
 *
 * @example Code editor mode
 * ```tsx
 * <SharedEditor
 *   initialValue='{"key": "value"}'
 *   editorProps={{ codeOnly: true, language: "json" }}
 *   handleChange={(value) => console.log(value)}
 * />
 * ```
 */
const SharedEditor = ({
    id,
    header,
    footer,
    editorType = "borderless",
    state = "filled",
    placeholder,
    initialValue,
    value,
    editorClassName,
    disabled,
    handleChange,
    editorProps,
    className,
    autoFocus,
    error,
    useAntdInput = false,
    optimizeLargeInput = false,
    maxPasteChars,
    onPasteLimitExceeded,
    disableContainerTransition = false,
    noProvider = false,
    debug = false,
    isTool,
    propertyId,
    baseProperty,
    variantId,
    syncWithInitialValueChanges = false,
    disableDebounce = false,
    antdInputProps,
    onPropertyClick,
    onFocusChange,
    ...props
}: SharedEditorProps) => {
    const normalizedInitialValue = initialValue ?? ""
    const controlledValue = value !== undefined ? value : normalizedInitialValue
    const shouldOptimizeLargeInput = optimizeLargeInput && !editorProps?.codeOnly
    const effectiveMaxPasteChars =
        typeof maxPasteChars === "number"
            ? maxPasteChars
            : !editorProps?.codeOnly
              ? DEFAULT_MAX_TEXT_PASTE_CHARS
              : undefined

    const [isEditorFocused, setIsEditorFocused] = useState(false)
    const [forcePlainTextFallback, setForcePlainTextFallback] = useState(
        shouldOptimizeLargeInput && isLargeRichTextDocument(controlledValue),
    )
    const [isHandlingLargePaste, setIsHandlingLargePaste] = useState(false)
    const [pasteLimitError, setPasteLimitError] = useState<string | null>(null)

    const [localValue, setLocalValue] = useDebounceInput<string>(
        controlledValue,
        disableDebounce ? () => {} : handleChange || (() => {}),
        disableDebounce ? 0 : 300,
        "",
    )

    const deferredLargeCommitRef = useRef<ReturnType<typeof setTimeout> | null>(null)

    useEffect(() => {
        if (shouldOptimizeLargeInput && isLargeRichTextDocument(controlledValue)) {
            setForcePlainTextFallback(true)
        }
    }, [controlledValue, shouldOptimizeLargeInput])

    useEffect(
        () => () => {
            if (deferredLargeCommitRef.current != null) {
                clearTimeout(deferredLargeCommitRef.current)
                deferredLargeCommitRef.current = null
            }
        },
        [],
    )

    const commitExternalChange = useCallback(
        (nextValue: string) => {
            if (!disableDebounce || !handleChange) {
                return
            }

            if (shouldOptimizeLargeInput && isLargeRichTextDocument(nextValue)) {
                if (deferredLargeCommitRef.current != null) {
                    clearTimeout(deferredLargeCommitRef.current)
                }

                deferredLargeCommitRef.current = setTimeout(() => {
                    deferredLargeCommitRef.current = null
                    handleChange(nextValue)
                }, LARGE_INPUT_EXTERNAL_COMMIT_DELAY_MS)
                return
            }

            handleChange(nextValue)
        },
        [disableDebounce, handleChange, shouldOptimizeLargeInput],
    )

    const handleLocalValueChange = useCallback(
        (nextValue: string) => {
            setPasteLimitError(null)
            setLocalValue(nextValue)
            commitExternalChange(nextValue)
        },
        [commitExternalChange, setLocalValue],
    )

    const editorIdRef = useRef<string>(
        id || `${uuidv4()}-${editorProps?.codeOnly ? "code" : "text"}`,
    )
    const editorId = editorIdRef.current

    const mountInitialValueRef = useRef<string>(normalizedInitialValue)

    if (syncWithInitialValueChanges) {
        mountInitialValueRef.current = normalizedInitialValue
    }

    const handleAntdInputChange = useCallback(
        (event: ChangeEvent<HTMLInputElement>) => {
            handleLocalValueChange(event.target.value)
        },
        [handleLocalValueChange],
    )

    const handleAntdTextAreaChange = useCallback(
        (event: ChangeEvent<HTMLTextAreaElement>) => {
            handleLocalValueChange(event.target.value)
        },
        [handleLocalValueChange],
    )

    const usesPlainTextInput = useAntdInput || forcePlainTextFallback

    const handlePasteCapture = useCallback(
        (event: ClipboardEvent<HTMLDivElement>) => {
            if (disabled) {
                return
            }

            const pastedText = event.clipboardData?.getData("text/plain") ?? ""
            if (!pastedText) {
                return
            }

            const nextValue = applyPasteToValue(
                localValue,
                pastedText,
                getTargetSelectionOffsets(event.target),
            )

            if (
                typeof effectiveMaxPasteChars === "number" &&
                nextValue.length > effectiveMaxPasteChars
            ) {
                event.preventDefault()
                event.stopPropagation()
                const handled = onPasteLimitExceeded?.({
                    pastedText,
                    currentValue: localValue,
                    nextValue,
                    nextLength: nextValue.length,
                    maxPasteChars: effectiveMaxPasteChars,
                    overBy: nextValue.length - effectiveMaxPasteChars,
                })
                if (handled === true) {
                    setPasteLimitError(null)
                    return
                }
                setPasteLimitError(
                    buildPasteLimitErrorMessage(nextValue.length, effectiveMaxPasteChars),
                )
                return
            }

            setPasteLimitError(null)

            if (!shouldOptimizeLargeInput || usesPlainTextInput) {
                return
            }

            if (!isLargeRichTextDocument(pastedText)) {
                return
            }

            const target = event.target as HTMLElement | null
            const contentEditable = target?.closest(".editor-input") as HTMLElement | null
            if (!contentEditable) {
                return
            }

            const isMarkdownSource = contentEditable.classList.contains("markdown-view")
            if (!isMarkdownSource && localValue && !looksLikePlainTextContent(localValue)) {
                return
            }

            event.preventDefault()
            event.stopPropagation()

            setIsHandlingLargePaste(true)

            const commitLargePaste = () => {
                startTransition(() => {
                    setForcePlainTextFallback(true)
                    handleLocalValueChange(nextValue)
                })

                if (
                    typeof window !== "undefined" &&
                    typeof window.requestAnimationFrame === "function"
                ) {
                    window.requestAnimationFrame(() => {
                        setIsHandlingLargePaste(false)
                    })
                    return
                }

                setIsHandlingLargePaste(false)
            }

            if (
                typeof window !== "undefined" &&
                typeof window.requestAnimationFrame === "function"
            ) {
                window.requestAnimationFrame(() => {
                    window.requestAnimationFrame(commitLargePaste)
                })
                return
            }

            setTimeout(commitLargePaste, 0)
        },
        [
            disabled,
            effectiveMaxPasteChars,
            handleLocalValueChange,
            localValue,
            onPasteLimitExceeded,
            shouldOptimizeLargeInput,
            usesPlainTextInput,
        ],
    )

    const mergedContainerClassName = useMemo(
        () =>
            clsx(
                "agenta-shared-editor",
                "w-auto flex flex-col items-start relative group/item border border-solid rounded-lg",
                {"transition-all duration-300 ease-in-out": !disableContainerTransition},
                "[&_.agenta-rich-text-editor]:w-full",
                "[&_.agenta-editor-wrapper]:w-full",
                // This container is the single source of truth for the border (incl. its
                // hover/focus/disabled states below) — Editor's own `.editor-inner` border
                // exists for standalone use and must not double up when nested here.
                "[&_.editor-inner]:border-0",
                "p-[11px]",
                {
                    // Default border + hover/focus parity for `border` mode.
                    // Focus uses the SAME darker color as hover so the user
                    // gets visible feedback when typing into the input
                    // (Kaosiso QA 2026-06-02 follow-up). The CSS `focus:`
                    // pseudo only matches when the OUTER div is focused;
                    // typing happens in a descendant <ContentEditable>, so
                    // the `isEditorFocused` rule below carries the styling
                    // through to descendant-focus.
                    "border-[var(--ag-c-BDC7D1)]": editorType === "border",
                    "hover:border-[var(--ag-c-394857)] focus:border-[var(--ag-c-394857)]":
                        editorType === "border",
                    "cursor-not-allowed bg-[var(--ag-rgba-051729-04)] border-none":
                        ["readOnly", "disabled"].includes(state) && editorType === "border",
                    // Removed: `"hover:border-[394857] focus:border-[394857]"`
                    // override for `state === "filled" && editorType === "border"`.
                    // The bare `[394857]` literal had no `#` or `var()`
                    // wrapping, so Tailwind read it as a class name and
                    // silently dropped the colour. The default rule above
                    // applies the correct hover/focus colors via the codemod
                    // var, so this branch is redundant.
                },
                {
                    "border-[transparent] hover:!border-[var(--ag-c-BDC7D1)] focus:border-[var(--ag-c-BDC7D1)]":
                        editorType === "borderless",
                    "cursor-not-allowed bg-[var(--ag-rgba-051729-04)] border-none":
                        ["readOnly", "disabled"].includes(state) && editorType === "borderless",
                    "hover:border-[transparent] focus:border-[transparent]":
                        state === "filled" && editorType === "borderless",
                },
                {
                    "[&_.agenta-rich-text-editor_*]:!text-[red] [&_.message-user-select]:text-[red]":
                        error,
                    "pt-0 [&_.editor-code]:!pr-2 [&_.editor-code]:!bg-[transparent] [&_.editor-code]:!m-0 [&_.editor-code]:!pt-2 [&_.editor-code]:!pb-1 [&_.agenta-editor-wrapper]:!-ml-[12px] [&_.agenta-editor-wrapper]:!w-[calc(100%+24px)] [&_.agenta-editor-wrapper]:mb-1 overflow-hidden":
                        editorProps?.codeOnly,
                },
                // JS-tracked descendant-focus → applies the hover color
                // border whenever a child element (the ContentEditable) is
                // focused. Previously this reverted the border to the
                // default light colour with `!important` — the visible
                // bug Kaosiso reported.
                isEditorFocused && "!border-[var(--ag-c-394857)]",
                className,
            ),
        [
            className,
            disableContainerTransition,
            editorProps?.codeOnly,
            editorType,
            error,
            isEditorFocused,
            state,
        ],
    )

    return (
        <div
            className={mergedContainerClassName}
            {...props}
            style={
                {
                    ...props.style,
                    height: "var(--editor-h, auto)",
                    overflow: "hidden",
                    // The height transition exists only to animate the collapse
                    // toggle (which sets `--editor-h` to a fixed px ↔ auto). Code
                    // editors never use that toggle, so `--editor-h` stays `auto`
                    // and `interpolate-size: allow-keywords` would instead animate
                    // EVERY content-height change while typing/pasting — making the
                    // editor grow over 300ms and lurching the surrounding drawer's
                    // scroll. Disable the animation for codeOnly so growth is
                    // instant; keep it for the collapsible rich-text/prompt editors.
                    ...(editorProps?.codeOnly
                        ? {}
                        : {
                              interpolateSize: "allow-keywords",
                              transitionProperty: "height",
                              transitionDuration: "300ms",
                              transitionTimingFunction: "cubic-bezier(0.4, 0, 0.2, 1)",
                          }),
                } as React.CSSProperties
            }
            onPasteCapture={handlePasteCapture}
            onFocus={() => {
                setIsEditorFocused(true)
                onFocusChange?.(true)
            }}
            onBlur={() => {
                setIsEditorFocused(false)
                onFocusChange?.(false)
            }}
        >
            {header}

            {isHandlingLargePaste ? (
                <div className="absolute inset-0 z-10 flex items-center justify-center gap-3 bg-[var(--ag-rgba-fff-78)] backdrop-blur-[1px]">
                    <Spinner size="small" />
                    <span className="text-[13px] text-[var(--ag-rgba-051729-72)]">
                        Pasting large content…
                    </span>
                </div>
            ) : null}

            {usesPlainTextInput ? (
                (() => {
                    const inputProps = antdInputProps ?? {}
                    const isTextarea = isSharedAntdTextareaProps(inputProps)
                    const shouldRenderTextarea = forcePlainTextFallback || isTextarea

                    if (shouldRenderTextarea) {
                        const textAreaProps: SharedAntdTextareaProps = isTextarea
                            ? inputProps
                            : {textarea: true}
                        const {textarea: _, className: __, ...textAreaRest} = textAreaProps
                        return (
                            <AutosizeTextarea
                                placeholder={placeholder}
                                value={localValue}
                                onChange={handleAntdTextAreaChange}
                                className={clsx(
                                    "!bg-transparent",
                                    "!text-inherit",
                                    editorClassName,
                                    textAreaProps.className,
                                )}
                                disabled={disabled}
                                autoSize={textAreaRest.autoSize ?? {minRows: 6, maxRows: 18}}
                                {...textAreaRest}
                            />
                        )
                    }

                    const {textarea: _, className: __, ...inputRest} = inputProps
                    return (
                        <Input
                            placeholder={placeholder}
                            value={localValue}
                            onChange={handleAntdInputChange}
                            className={clsx(
                                "!bg-transparent",
                                "!text-inherit",
                                editorClassName,
                                inputProps.className,
                            )}
                            disabled={disabled}
                            {...inputRest}
                        />
                    )
                })()
            ) : (
                <Editor
                    placeholder={placeholder}
                    showToolbar={false}
                    enableTokens={!editorProps?.codeOnly}
                    initialValue={mountInitialValueRef.current}
                    value={localValue}
                    className={editorClassName}
                    onChange={(val) => {
                        handleLocalValueChange(val.textContent)
                    }}
                    debug={debug}
                    autoFocus={autoFocus}
                    disabled={disabled}
                    showBorder={false}
                    id={editorId}
                    noProvider={noProvider}
                    {...editorProps}
                    onPropertyClick={onPropertyClick}
                />
            )}

            {pasteLimitError ? (
                <div className="mt-2 text-[13px] leading-5 text-[var(--ag-c-D61010)]">
                    {pasteLimitError}
                </div>
            ) : null}

            {footer}
        </div>
    )
}

export default SharedEditor
