import type {CSSProperties, Key, ReactNode} from "react"
import {useCallback, useEffect, useMemo, useState} from "react"

import {Export, Trash} from "@phosphor-icons/react"

import {Button} from "../../components/ui/button"
import {LoadingButton} from "../../components/ui/button-composed"
import {Pagination} from "../../components/ui/pagination"
import {Tabs, TabsList, TabsTrigger} from "../../components/ui/tabs"
import {SimpleTooltip} from "../../components/ui/tooltip-composed"
import {useIsNarrowScreen} from "../../hooks/useMediaQuery"
import {cn} from "../../utils/styles"
import ColumnVisibilityPopoverContent from "../components/columnVisibility/ColumnVisibilityPopoverContent"
import TableSettingsDropdown from "../components/columnVisibility/TableSettingsDropdown"
import TableShell from "../components/TableShell"
import {RowHeightContext} from "../context/RowHeightContext"
import type {InfiniteDatasetStore} from "../createInfiniteDatasetStore"
import {useRowHeightFeature, type RowHeightFeatureConfig} from "../hooks/useRowHeightFeature"
import useTableExport, {type TableExportOptions} from "../hooks/useTableExport"
import {useTypeChipFeature} from "../hooks/useTypeChipFeature"
import InfiniteVirtualTable from "../InfiniteVirtualTable"
import type {TableMenuItem} from "../tableMenu"
import type {
    ColumnVisibilityMenuRenderer,
    ColumnVisibilityState,
    InfiniteTableRowBase,
    InfiniteVirtualTableProps,
    InfiniteVirtualTableRowSelection,
} from "../types"

type ColumnVisibilityRenderer<Row extends InfiniteTableRowBase> = (
    controls: ColumnVisibilityState<Row>,
    close: () => void,
    context: {scopeId: string | null},
) => ReactNode

export interface TableScopeConfig {
    scopeId: string | null
    pageSize: number
    enableInfiniteScroll?: boolean
    columnVisibilityStorageKey?: string | null
    columnVisibilityDefaults?: Key[]
    viewportTrackingEnabled?: boolean
    /** Margin around viewport for preloading columns (e.g., "0px 200px" to preload 200px on left/right) */
    viewportMargin?: string
    /** Debounce time in ms before marking a column as hidden after it exits viewport (default: 150) */
    viewportExitDebounceMs?: number
}

export interface TableFeaturePagination<Row extends InfiniteTableRowBase> {
    rows: Row[]
    loadNextPage: () => void
    resetPages: () => void
    paginationInfo?: {
        hasMore: boolean
        nextCursor: string | null
        nextOffset: number | null
        isFetching: boolean
        totalCount: number | null
    }
}

export type TableFeatureExportOptions<Row extends InfiniteTableRowBase> = TableExportOptions<Row>

export interface TableTabItem {
    key: string
    label: string
}

export interface TableTabsConfig {
    /** Tab items to render */
    items: TableTabItem[]
    /** Currently active tab key */
    activeKey: string
    /** Callback when tab changes */
    onChange: (key: string) => void
    /** Optional CSS variable for tab indicator color */
    indicatorColor?: string
    /** Optional className for the tabs container */
    className?: string
}

/** Configuration for the built-in delete action */
export interface TableDeleteConfig {
    /** Callback when delete is triggered */
    onDelete: () => void
    /** Whether the delete action is disabled */
    disabled?: boolean
    /** Tooltip to show when disabled */
    disabledTooltip?: string
    /** Button label (default: "Delete") */
    label?: string
}

/** Configuration for the built-in export action */
export interface TableExportConfig {
    /** Whether the export action is disabled */
    disabled?: boolean
    /** Tooltip to show when disabled */
    disabledTooltip?: string
    /** Button label (default: "Export CSV") */
    label?: string
}

// Re-export RowHeightFeatureConfig for convenience
export type {RowHeightFeatureConfig} from "../hooks/useRowHeightFeature"

export interface InfiniteVirtualTableFeatureProps<Row extends InfiniteTableRowBase> {
    /**
     * Dataset store for pagination. Required when pagination prop is not provided.
     * When pagination is provided directly, datasetStore is optional (not used for pagination).
     */
    // Only `hooks` is consumed here, so ApiRow/Meta stay free for callers (invariant otherwise)
    datasetStore?: Pick<InfiniteDatasetStore<Row, unknown, unknown>, "hooks"> | null
    tableScope: TableScopeConfig
    columns: InfiniteVirtualTableProps<Row>["columns"]
    rowKey: InfiniteVirtualTableProps<Row>["rowKey"]
    title?: ReactNode
    /** Tabs configuration for the header */
    tabs?: TableTabsConfig
    /** @deprecated Use tabs prop instead. Additional content to render in the header row */
    headerExtra?: ReactNode
    filters?: ReactNode
    primaryActions?: ReactNode
    /**
     * Built-in delete action configuration.
     * When provided, the shell renders a standard delete button.
     * On narrow screens, this moves to the settings dropdown.
     */
    deleteAction?: TableDeleteConfig
    /**
     * Built-in export action configuration.
     * When provided along with enableExport, the shell renders a standard export button.
     * On narrow screens, export moves to the settings dropdown.
     */
    exportAction?: TableExportConfig
    /** @deprecated Use deleteAction instead. Custom secondary actions to render */
    secondaryActions?: ReactNode
    className?: string
    containerClassName?: string
    tableClassName?: string
    autoHeight?: boolean
    /**
     * When autoHeight is false and the table is empty, floor the body to this height so the
     * empty state has room to render. Defaults to 240px.
     */
    emptyMinHeight?: number
    rowHeight?: number
    fallbackControlsHeight?: number
    fallbackHeaderHeight?: number
    resizableColumns?: InfiniteVirtualTableProps<Row>["resizableColumns"]
    /**
     * NOTE (typed as-is): accepted for compatibility but NOT forwarded to the inner
     * table — custom empty text passed here never renders today. Flagged for follow-up.
     */
    locale?: {emptyText?: ReactNode}
    tableProps?: InfiniteVirtualTableProps<Row>["tableProps"]
    beforeTable?: ReactNode
    afterTable?: ReactNode
    columnVisibilityMenuRenderer?: ColumnVisibilityMenuRenderer<Row> | ColumnVisibilityRenderer<Row>
    columnVisibility?: InfiniteVirtualTableProps<Row>["columnVisibility"]
    rowSelection?: InfiniteVirtualTableRowSelection<Row>
    onPaginationStateChange?: (payload: {resetPages: () => void; loadNextPage: () => void}) => void
    onRowsChange?: (rows: Row[]) => void
    pagination?: TableFeaturePagination<Row>
    enableExport?: boolean
    exportFilename?: string
    /** @deprecated Use exportAction instead for button customization */
    renderExportButton?: (props: {onExport: () => void; loading: boolean}) => ReactNode
    exportOptions?: TableFeatureExportOptions<Row>
    /**
     * When true, the gear icon opens a dropdown menu with actions (Export, Column Visibility)
     * instead of directly opening the column visibility popover.
     * Default: false (gear icon opens column visibility popover directly)
     */
    useSettingsDropdown?: boolean
    /**
     * @deprecated Use deleteAction instead.
     * Delete action configuration for the settings dropdown.
     * Only used when useSettingsDropdown is true.
     */
    settingsDropdownDelete?: {
        onDelete: () => void
        disabled?: boolean
        label?: string
    }
    /**
     * Additional menu items for the settings dropdown.
     * Only used when useSettingsDropdown is true.
     */
    settingsDropdownMenuItems?: TableMenuItem[]
    keyboardShortcuts?: InfiniteVirtualTableProps<Row>["keyboardShortcuts"]
    /**
     * Configuration for expandable rows.
     * When provided, rows can be expanded to show child content (e.g., variants, revisions).
     */
    expandable?: InfiniteVirtualTableProps<Row>["expandable"]
    /**
     * Override the dataSource from pagination.
     * Useful when you need to transform rows (e.g., add children for tree data).
     */
    dataSource?: Row[]
    /**
     * Jotai store to use for the table. When provided, the table will use this store
     * instead of creating an isolated one. Useful when cells need to read from
     * atoms in a shared store (e.g., entity atoms).
     */
    store?: InfiniteVirtualTableProps<Row>["store"]
    /**
     * Ref to access the underlying Ant Design Table instance.
     * Useful for programmatic scrolling via `tableRef.current?.scrollTo({ index })`.
     */
    tableRef?: InfiniteVirtualTableProps<Row>["tableRef"]
    typeChips?: InfiniteVirtualTableProps<Row>["typeChips"]
    /**
     * Built-in row height feature configuration.
     * When provided, the shell manages row height state internally and:
     * - Persists the preference to localStorage using the storageKey
     * - Adds row height menu items to the settings dropdown
     * - Provides RowHeightContext for cells to access maxLines
     *
     * @example
     * ```tsx
     * <InfiniteVirtualTableFeatureShell
     *     rowHeightConfig={{
     *         storageKey: "agenta:my-table:row-height",
     *         defaultSize: "medium", // optional
     *     }}
     * />
     * ```
     */
    rowHeightConfig?: RowHeightFeatureConfig
    /**
     * Pagination display mode:
     * - `"infinite"` (default): Rows load progressively via infinite scroll.
     * - `"paginated"`: Renders antd `Pagination` below the table with page numbers.
     *    Rows are sliced client-side by page. Works with both all-in-memory data
     *    and cursor-paginated server data.
     */
    paginationMode?: "infinite" | "paginated"
    /**
     * Page size for the UI pagination component when `paginationMode="paginated"`.
     * Defaults to `tableScope.pageSize`. Use this when the store's pageSize
     * (which controls fetch batch size / skeleton slots) differs from the
     * desired number of rows per UI page.
     */
    paginatedPageSize?: number
    /**
     * Total item count for the paginated UI when the server's windowed response
     * doesn't include a global total. When provided, this overrides the count
     * derived from loaded rows or the store's totalCount.
     */
    paginatedTotalCount?: number
}

const DEFAULT_ROW_HEIGHT = 48
const DEFAULT_CONTROLS_HEIGHT = 72
const DEFAULT_TABLE_HEADER_HEIGHT = 48
// Fixed-height tables collapse to one row when empty; give the empty state room to render.
const DEFAULT_EMPTY_BODY_HEIGHT = 300

interface ColumnVisibilityRendererContext {
    scopeId: string | null
    onExport?: () => void
    isExporting?: boolean
}

const resolveColumnVisibilityRenderer = <Row extends InfiniteTableRowBase>(
    renderer: InfiniteVirtualTableFeatureProps<Row>["columnVisibilityMenuRenderer"],
    config: InfiniteVirtualTableProps<Row>["columnVisibility"] | undefined,
    context: ColumnVisibilityRendererContext,
): ColumnVisibilityMenuRenderer<Row> => {
    const {scopeId, onExport, isExporting} = context
    if (!renderer) {
        return (controls, close) => (
            <ColumnVisibilityPopoverContent
                controls={controls}
                onClose={close}
                scopeId={scopeId}
                resolveNodeMeta={config?.resolveNodeMeta}
                onExport={onExport}
                isExporting={isExporting}
            />
        )
    }
    return (controls, close) => renderer(controls, close, {scopeId, onExport, isExporting})
}

function InfiniteVirtualTableFeatureShellBase<Row extends InfiniteTableRowBase>(
    props: InfiniteVirtualTableFeatureProps<Row> & {pagination: TableFeaturePagination<Row>},
) {
    const {
        tableScope,
        columns,
        rowKey,
        title,
        tabs,
        headerExtra,
        filters,
        primaryActions,
        deleteAction,
        exportAction,
        secondaryActions,
        className,
        containerClassName,
        tableClassName,
        autoHeight = true,
        emptyMinHeight = DEFAULT_EMPTY_BODY_HEIGHT,
        rowHeight: rowHeightProp = DEFAULT_ROW_HEIGHT,
        fallbackControlsHeight = DEFAULT_CONTROLS_HEIGHT,
        fallbackHeaderHeight = DEFAULT_TABLE_HEADER_HEIGHT,
        resizableColumns = true,
        tableProps,
        beforeTable,
        afterTable,
        columnVisibilityMenuRenderer,
        columnVisibility,
        rowSelection,
        onPaginationStateChange,
        onRowsChange,
        pagination,
        enableExport = true,
        exportFilename,
        renderExportButton,
        exportOptions,
        useSettingsDropdown = false,
        settingsDropdownDelete,
        settingsDropdownMenuItems,
        keyboardShortcuts,
        expandable,
        dataSource,
        tableRef,
        typeChips,
        store,
        rowHeightConfig,
        paginationMode = "infinite",
        paginatedPageSize: paginatedPageSizeProp,
        paginatedTotalCount,
    } = props
    const {scopeId, pageSize, enableInfiniteScroll = true} = tableScope
    const uiPageSize = paginatedPageSizeProp ?? pageSize

    // Built-in row height feature (when rowHeightConfig is provided)
    const rowHeightFeature = rowHeightConfig ? useRowHeightFeature(rowHeightConfig) : null
    const typeChipFeature = useTypeChipFeature(typeChips)

    // Resolve row height: use feature if configured, otherwise use prop
    const rowHeight = rowHeightFeature?.heightPx ?? rowHeightProp

    // Combine settings dropdown menu items with built-in table feature items
    const combinedSettingsDropdownMenuItems = useMemo<TableMenuItem[] | undefined>(() => {
        const menuGroups = [
            typeChipFeature.menuItems,
            rowHeightFeature?.menuItems,
            settingsDropdownMenuItems,
        ].filter((items): items is TableMenuItem[] => Boolean(items?.length))

        if (!menuGroups.length) return undefined

        return menuGroups.flatMap((items, index) =>
            index === 0 ? items : [{type: "divider" as const}, ...items],
        )
    }, [rowHeightFeature?.menuItems, settingsDropdownMenuItems, typeChipFeature.menuItems])

    // Responsive breakpoints for built-in action buttons
    const isNarrowScreen = useIsNarrowScreen()

    // Hide built-in export/delete buttons when settings dropdown is active
    // (either forced via prop or responsive narrow screen)
    const hideBuiltInButtons = useSettingsDropdown || isNarrowScreen

    useEffect(() => {
        onPaginationStateChange?.({
            resetPages: pagination.resetPages,
            loadNextPage: pagination.loadNextPage,
        })
    }, [onPaginationStateChange, pagination.loadNextPage, pagination.resetPages])

    useEffect(() => {
        onRowsChange?.(pagination.rows)
    }, [onRowsChange, pagination.rows])

    const handleLoadMore = useCallback(() => {
        if (!enableInfiniteScroll || paginationMode === "paginated") return
        pagination.loadNextPage()
    }, [enableInfiniteScroll, paginationMode, pagination.loadNextPage])

    // Paginated mode: track current page and slice rows
    const isPaginated = paginationMode === "paginated"
    const [currentPage, setCurrentPage] = useState(1)

    // Reset to page 1 when scope changes (e.g., different entity context)
    useEffect(() => {
        if (isPaginated) setCurrentPage(1)
    }, [isPaginated, scopeId])

    const paginatedSlice = useMemo(() => {
        if (!isPaginated) return null
        const realRows = pagination.rows.filter((r) => !r.__isSkeleton)
        const start = (currentPage - 1) * uiPageSize
        const total =
            paginatedTotalCount ?? pagination.paginationInfo?.totalCount ?? realRows.length
        return {
            rows: realRows.slice(start, start + uiPageSize) as Row[],
            total,
        }
    }, [
        isPaginated,
        pagination.rows,
        pagination.paginationInfo?.totalCount,
        paginatedTotalCount,
        currentPage,
        uiPageSize,
    ])

    // In paginated mode, proactively load next pages when user navigates beyond loaded rows
    useEffect(() => {
        if (!isPaginated) return
        const realRows = pagination.rows.filter((r) => !r.__isSkeleton)
        const neededRows = currentPage * uiPageSize
        const {hasMore} = pagination.paginationInfo ?? {}
        if (neededRows > realRows.length && hasMore) {
            pagination.loadNextPage()
        }
    }, [isPaginated, currentPage, uiPageSize, pagination])

    const handlePageChange = useCallback((page: number) => {
        setCurrentPage(page)
    }, [])

    const [controlsHeight, setControlsHeight] = useState(0)
    const [tableHeaderHeight, setTableHeaderHeight] = useState<number | null>(null)

    const resolvedControlsHeight = controlsHeight || fallbackControlsHeight
    const resolvedTableHeaderHeight = tableHeaderHeight ?? fallbackHeaderHeight
    // In paginated mode, always use fixed height to prevent collapse during page transitions
    const effectiveAutoHeight = isPaginated ? false : autoHeight
    // In paginated mode, use the current page's row count for height calculation
    const visibleRowCount = isPaginated
        ? paginatedSlice?.rows.length || uiPageSize
        : pagination.rows.length || pageSize
    const rowCount = isPaginated ? (paginatedSlice?.rows.length ?? 0) : pagination.rows.length
    const bodyHeight = effectiveAutoHeight
        ? null
        : rowCount === 0
          ? Math.max(rowHeight * Math.max(visibleRowCount, 1), emptyMinHeight)
          : rowHeight * Math.max(visibleRowCount, 1)
    const headerHeight = resolvedControlsHeight + resolvedTableHeaderHeight + 32
    // Pagination bar: py-2 (16px) + antd Pagination (~32px) = ~48px
    const paginationBarHeight = isPaginated ? 48 : 0
    const fixedHeight =
        !effectiveAutoHeight && bodyHeight !== null
            ? bodyHeight + headerHeight + paginationBarHeight
            : undefined
    const resolvedContainerClassName =
        containerClassName ??
        (effectiveAutoHeight ? "w-full grow min-h-0 overflow-hidden" : "w-full overflow-hidden")

    const tableExport = useTableExport<Row>()
    const [isExporting, setIsExporting] = useState(false)
    const {
        filename: exportOptionsFilename,
        isColumnExportable,
        getValue: getExportValue,
        formatValue: formatExportValue,
        includeSkeletonRows,
        beforeExport,
        resolveValue,
        resolveColumnLabel,
    } = exportOptions ?? {}
    const resolvedExportFilename = exportOptionsFilename ?? exportFilename ?? "table-export.csv"
    const exportHandler = useCallback(async () => {
        if (isExporting) return
        setIsExporting(true)
        try {
            // If rows are selected, export only selected rows; otherwise export all rows
            const selectedKeys = rowSelection?.selectedRowKeys
            const rowsToExport =
                selectedKeys && selectedKeys.length > 0
                    ? pagination.rows.filter((row) => {
                          const key =
                              typeof rowKey === "function" ? rowKey(row) : row[rowKey as keyof Row]
                          return selectedKeys.includes(key as Key)
                      })
                    : pagination.rows
            await tableExport({
                columns,
                rows: rowsToExport,
                filename: resolvedExportFilename,
                isColumnExportable,
                getValue: getExportValue,
                formatValue: formatExportValue,
                includeSkeletonRows,
                beforeExport,
                resolveValue,
                resolveColumnLabel,
            })
        } catch (error) {
            console.error("[InfiniteVirtualTable] Failed to export table", error)
        } finally {
            setIsExporting(false)
        }
    }, [
        beforeExport,
        columns,
        getExportValue,
        formatExportValue,
        includeSkeletonRows,
        isExporting,
        isColumnExportable,
        pagination.rows,
        resolveValue,
        resolveColumnLabel,
        resolvedExportFilename,
        rowKey,
        rowSelection?.selectedRowKeys,
        tableExport,
    ])

    const exportButtonNode = useMemo(() => {
        if (!enableExport) return null
        if (renderExportButton) {
            return renderExportButton({onExport: exportHandler, loading: isExporting})
        }
        // Export button is now rendered inside the column visibility popover
        return null
    }, [enableExport, exportHandler, isExporting, renderExportButton])

    // Built-in delete button (wide screens only)
    const builtInDeleteButton = useMemo(() => {
        if (!deleteAction || hideBuiltInButtons) return null
        const {onDelete, disabled, disabledTooltip, label = "Delete"} = deleteAction
        const button = (
            <Button
                variant="destructive-outline"
                className="flex items-center"
                disabled={disabled}
                onClick={onDelete}
            >
                {<Trash size={14} className="mt-0.5" />}
                {label}
            </Button>
        )
        if (disabled && disabledTooltip) {
            // A disabled button swallows pointer events, so the tooltip needs a wrapper.
            return (
                <SimpleTooltip title={disabledTooltip}>
                    <span>{button}</span>
                </SimpleTooltip>
            )
        }
        return button
    }, [deleteAction, hideBuiltInButtons])

    // Built-in export button (wide screens only, when exportAction is provided)
    const builtInExportButton = useMemo(() => {
        if (!enableExport || !exportAction || hideBuiltInButtons) return null
        const {disabled, disabledTooltip, label = "Export CSV"} = exportAction
        const button = (
            <LoadingButton
                disabled={disabled}
                onClick={exportHandler}
                loading={isExporting}
                variant="ghost"
            >
                <Export size={14} />
                {label}
            </LoadingButton>
        )
        if (disabled && disabledTooltip) {
            return (
                <SimpleTooltip title={disabledTooltip}>
                    <span>{button}</span>
                </SimpleTooltip>
            )
        }
        return button
    }, [enableExport, exportAction, exportHandler, isExporting, hideBuiltInButtons])

    // Resolve settings dropdown delete config (prefer deleteAction over legacy prop)
    const resolvedSettingsDropdownDelete = useMemo(() => {
        if (deleteAction && hideBuiltInButtons) {
            return {
                onDelete: deleteAction.onDelete,
                disabled: deleteAction.disabled,
                label: deleteAction.label ? `${deleteAction.label} selected` : "Delete selected",
            }
        }
        return settingsDropdownDelete
    }, [deleteAction, hideBuiltInButtons, settingsDropdownDelete])

    // Combine secondary actions: built-in buttons + custom secondaryActions + export button
    const resolvedSecondaryActions = useMemo(() => {
        const actions = [
            builtInDeleteButton,
            builtInExportButton,
            secondaryActions,
            exportButtonNode,
        ]
        const filtered = actions.filter(Boolean)
        if (filtered.length === 0) return undefined
        if (filtered.length === 1) return filtered[0]
        return (
            <div className="flex items-center gap-2">
                {filtered.map((action, i) => (
                    <span key={i}>{action}</span>
                ))}
            </div>
        )
    }, [builtInDeleteButton, builtInExportButton, secondaryActions, exportButtonNode])

    // Only show export in settings when enableExport is true AND no custom renderExportButton is provided
    const showExportInSettings = enableExport && !renderExportButton

    const columnVisibilityRenderer = useMemo(
        () =>
            resolveColumnVisibilityRenderer(columnVisibilityMenuRenderer, columnVisibility, {
                scopeId,
                onExport: showExportInSettings ? exportHandler : undefined,
                isExporting,
            }),
        [
            columnVisibilityMenuRenderer,
            columnVisibility,
            scopeId,
            showExportInSettings,
            exportHandler,
            isExporting,
        ],
    )

    const viewportTrackingEnabled = useMemo(
        () =>
            tableScope.viewportTrackingEnabled ?? pagination.rows.some((row) => !row.__isSkeleton),
        [pagination.rows, tableScope.viewportTrackingEnabled],
    )

    const settingsDropdownRenderer = useCallback(
        (controls: ColumnVisibilityState<Row>) => (
            <TableSettingsDropdown
                controls={controls}
                onExport={showExportInSettings ? exportHandler : undefined}
                isExporting={isExporting}
                onDelete={resolvedSettingsDropdownDelete?.onDelete}
                deleteDisabled={resolvedSettingsDropdownDelete?.disabled}
                deleteLabel={resolvedSettingsDropdownDelete?.label}
                additionalMenuItems={combinedSettingsDropdownMenuItems}
                renderColumnVisibilityContent={(ctrls, close) =>
                    columnVisibilityRenderer(ctrls, close, {
                        scopeId,
                        onExport: showExportInSettings ? exportHandler : undefined,
                        isExporting,
                    })
                }
            />
        ),
        [
            columnVisibilityRenderer,
            showExportInSettings,
            exportHandler,
            isExporting,
            scopeId,
            resolvedSettingsDropdownDelete,
            combinedSettingsDropdownMenuItems,
        ],
    )

    const columnVisibilityConfig = useMemo(
        () => ({
            storageKey: tableScope.columnVisibilityStorageKey ?? undefined,
            defaultHiddenKeys: tableScope.columnVisibilityDefaults,
            viewportTrackingEnabled,
            viewportMargin: tableScope.viewportMargin,
            viewportExitDebounceMs: tableScope.viewportExitDebounceMs,
            renderMenuContent: columnVisibilityRenderer,
            renderMenuTrigger: useSettingsDropdown ? settingsDropdownRenderer : undefined,
        }),
        [
            columnVisibilityRenderer,
            settingsDropdownRenderer,
            tableScope.columnVisibilityDefaults,
            tableScope.columnVisibilityStorageKey,
            tableScope.viewportExitDebounceMs,
            tableScope.viewportMargin,
            useSettingsDropdown,
            viewportTrackingEnabled,
        ],
    )

    // Render tabs if configured
    const tabsNode = useMemo(() => {
        if (!tabs) return headerExtra // Fall back to headerExtra for backwards compatibility
        return (
            <div
                className={cn(
                    "infinite-table-tabs min-w-[320px] [&_.ant-tabs-nav]:mb-0",
                    tabs.className,
                )}
                style={
                    tabs.indicatorColor
                        ? ({"--tab-indicator-color": tabs.indicatorColor} as CSSProperties)
                        : undefined
                }
            >
                {/* Tab bar only: the table below is the panel, so there is no TabsContent. */}
                <Tabs
                    className="min-w-[320px]"
                    value={tabs.activeKey}
                    onValueChange={tabs.onChange}
                >
                    <TabsList>
                        {tabs.items.map((item) => (
                            <TabsTrigger key={item.key} value={item.key}>
                                {item.label}
                            </TabsTrigger>
                        ))}
                    </TabsList>
                </Tabs>
            </div>
        )
    }, [tabs, headerExtra])

    const effectiveDataSource = dataSource ?? paginatedSlice?.rows ?? pagination.rows

    // Content to render (may be wrapped with RowHeightContext.Provider)
    const tableContent = (
        <div
            className={cn(
                "flex flex-col",
                effectiveAutoHeight ? "h-full min-h-0" : "min-h-0",
                className,
            )}
            style={fixedHeight ? {height: fixedHeight} : undefined}
        >
            <TableShell
                title={title}
                headerExtra={tabsNode}
                filters={filters}
                primaryActions={primaryActions}
                secondaryActions={resolvedSecondaryActions}
                onHeaderHeightChange={setControlsHeight}
                className="flex flex-1 min-h-0 flex-col"
            >
                {beforeTable}
                <InfiniteVirtualTable<Row>
                    useIsolatedStore={!store}
                    store={store}
                    columns={columns}
                    dataSource={effectiveDataSource}
                    loadMore={handleLoadMore}
                    rowKey={rowKey}
                    rowSelection={rowSelection}
                    resizableColumns={resizableColumns}
                    columnVisibility={columnVisibilityConfig}
                    bodyHeight={bodyHeight}
                    scopeId={scopeId}
                    containerClassName={resolvedContainerClassName}
                    tableClassName={tableClassName}
                    tableProps={tableProps}
                    keyboardShortcuts={keyboardShortcuts}
                    expandable={expandable}
                    onHeaderHeightChange={setTableHeaderHeight}
                    tableRef={tableRef}
                    typeChips={typeChipFeature.typeChips}
                />
                {isPaginated && paginatedSlice && (
                    <div className="flex justify-end px-4 py-2">
                        <Pagination
                            total={paginatedSlice.total}
                            showTotal={(total) => `Total ${total} items`}
                            pageSize={uiPageSize}
                            current={currentPage}
                            onChange={handlePageChange}
                            size="small"
                        />
                    </div>
                )}
                {afterTable}
            </TableShell>
        </div>
    )

    // Wrap with RowHeightContext.Provider if row height feature is enabled
    if (rowHeightFeature) {
        return (
            <RowHeightContext.Provider value={rowHeightFeature.contextValue}>
                {tableContent}
            </RowHeightContext.Provider>
        )
    }

    return tableContent
}

const InfiniteVirtualTableFeatureShellWithStore = <Row extends InfiniteTableRowBase>(
    props: InfiniteVirtualTableFeatureProps<Row>,
) => {
    const {datasetStore, tableScope} = props
    if (!datasetStore) {
        throw new Error(
            "InfiniteVirtualTableFeatureShell: datasetStore is required when pagination is not provided",
        )
    }
    const pagination = datasetStore.hooks.usePagination({
        scopeId: tableScope.scopeId,
        pageSize: tableScope.pageSize,
        resetOnScopeChange: true,
    })
    return <InfiniteVirtualTableFeatureShellBase {...props} pagination={pagination} />
}

const InfiniteVirtualTableFeatureShell = <Row extends InfiniteTableRowBase>(
    props: InfiniteVirtualTableFeatureProps<Row>,
) => {
    if (props.pagination) {
        return <InfiniteVirtualTableFeatureShellBase {...props} pagination={props.pagination} />
    }
    return <InfiniteVirtualTableFeatureShellWithStore {...props} />
}

export default InfiniteVirtualTableFeatureShell
