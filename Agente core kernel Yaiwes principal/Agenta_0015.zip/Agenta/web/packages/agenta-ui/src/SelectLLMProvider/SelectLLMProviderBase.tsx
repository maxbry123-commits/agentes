import React, {useCallback, useEffect, useId, useMemo, useRef, useState} from "react"

import {CaretRight, Check, X} from "@phosphor-icons/react"
import clsx from "clsx"
import {ChevronDown} from "lucide-react"

import {Input} from "../components/ui/input"
import {Popover, PopoverAnchor, PopoverContent, PopoverTrigger} from "../components/ui/popover"
import {selectTriggerVariants} from "../components/ui/select"
import {Tooltip, TooltipContent, TooltipProvider, TooltipTrigger} from "../components/ui/tooltip"
import {LLMIconMap} from "../LLMIcons"

import type {
    SelectLLMProviderBaseProps,
    ProviderGroup,
    ProviderOption,
    ProviderSection,
    SelectSize,
} from "./types"
import {getHarnessIcon, getProviderIcon, getProviderDisplayName} from "./utils"

const DEFAULT_PROVIDER_DROPDOWN_WIDTH = 400

const toCssSize = (value: number | string) => (typeof value === "number" ? `${value}px` : value)

/** antd size → the shared control scale used by Select/Combobox triggers. */
const TRIGGER_SIZE: Record<SelectSize, "sm" | "default" | "lg"> = {
    small: "sm",
    middle: "default",
    large: "lg",
}

/** antd dropdown item geometry, identical to the Combobox rows so the two read as one system. */
const ROW_CLASS =
    "box-border flex w-full min-h-control cursor-pointer select-none items-center gap-2 rounded-control-sm px-3 py-1 text-field-md"

/** A group's hover/selection identity: its own `key` when it has one, else its display label. */
const groupKeyOf = (group: ProviderGroup): string | null => group.key ?? group.label ?? null

/**
 * Base LLM provider select component.
 *
 * A popover-hosted picker rather than a `Combobox`: the search box lives INSIDE the panel
 * (Combobox searches from the trigger), the grouped mode is a two-column provider → model
 * cascade, and the panel width is decoupled from the trigger width. The trigger still reuses
 * `selectTriggerVariants`, so it stays dimensionally identical to Select/Combobox.
 *
 * This is a presentational component that can be extended in OSS with
 * vault integration and other features.
 *
 * @example Basic Usage
 * ```tsx
 * <SelectLLMProviderBase
 *   value={provider}
 *   onChange={setProvider}
 *   options={providerOptions}
 *   showSearch
 *   showGroup
 * />
 * ```
 */
const SelectLLMProviderBase: React.FC<SelectLLMProviderBaseProps> = ({
    showGroup = false,
    showSearch = true,
    searchPlaceholder = "Search",
    connectionColumnWidth,
    sectionTooltip,
    options,
    className,
    footerContent,
    onSelectValue,
    providerDropdownWidth,
    modelListWidth,
    emptyText = "No data",
    container,
    value,
    onChange,
    placeholder = "Select a provider",
    disabled = false,
    invalid = false,
    size = "middle",
    style,
    id,
    "aria-label": ariaLabel,
    "aria-labelledby": ariaLabelledby,
    open: controlledOpen,
    onOpenChange,
    onDismissOutside,
    onStepBack,
    anchorRef,
    hideTrigger = false,
    searchSuffix,
    panelHeader,
    panelFooter,
    selectedKey,
}) => {
    const [uncontrolledOpen, setUncontrolledOpen] = useState(false)
    const isControlled = controlledOpen !== undefined
    const open = isControlled ? controlledOpen : uncontrolledOpen
    // One writer for both modes: the internal callers (`closeDropdown`, the trigger) keep calling
    // `setOpen`, and a controlled parent hears about it through `onOpenChange`.
    const setOpen = useCallback(
        (next: boolean) => {
            if (!isControlled) setUncontrolledOpen(next)
            onOpenChange?.(next)
        },
        [isControlled, onOpenChange],
    )
    const [searchTerm, setSearchTerm] = useState("")
    const [hoveredProvider, setHoveredProvider] = useState<string | null>(null)
    // null = focus sits in the provider column; a number = the highlighted model row.
    const [activeModelIndex, setActiveModelIndex] = useState<number | null>(null)
    const [activeIndex, setActiveIndex] = useState(0)
    const inputRef = useRef<HTMLInputElement>(null)
    const panelRef = useRef<HTMLDivElement>(null)

    // Stable ids so the search field can point at the listbox and its highlighted row.
    const rid = useId()
    const listId = `${rid}-listbox`
    const optionId = (index: number) => `${rid}-opt-${index}`
    // The grouped view is TWO listboxes side by side and the keyboard moves between them, so each
    // column needs its own id space for `aria-activedescendant` to name a row in either.
    const providerListId = `${rid}-providers`
    const providerOptionId = (index: number) => `${rid}-prov-${index}`
    const modelListId = `${rid}-models`
    const modelOptionId = (index: number) => `${rid}-model-${index}`

    // Normalize the loose incoming option shapes ONCE, before filtering, so the trigger can
    // still resolve the selected label while a search is narrowing the list.
    const normalizedGroups = useMemo<ProviderGroup[]>(() => {
        if (!options) return []

        return options.map((group) => ({
            label: group?.label as string | undefined,
            key: group?.key,
            iconKey: group?.iconKey,
            caption: group?.caption,
            // Carried, not rebuilt: the group's own marks (the subscription tag) and its flyout
            // sections are authored by the caller and have no loose shapes to normalize.
            tag: group?.tag,
            tagTone: group?.tagTone,
            sections: group?.sections,
            options:
                (group.options
                    ?.map((option: unknown) => {
                        const opt = option as Record<string, unknown> | string | null
                        if (!opt) return undefined
                        if (typeof opt === "string") {
                            return {
                                label: opt,
                                value: opt,
                                key: opt,
                            }
                        }
                        const optionLabel = (opt.label ?? opt.value) as string | undefined
                        const optionValue = (opt.value ?? opt.label) as string | undefined

                        if (!optionLabel && !optionValue) return undefined
                        const resolvedLabel = optionLabel || optionValue
                        const resolvedValue = optionValue || optionLabel

                        return {
                            label: resolvedLabel,
                            value: resolvedValue,
                            key: (opt.key as string | undefined) ?? resolvedValue,
                            metadata: opt.metadata as Record<string, unknown> | undefined,
                            tag: opt.tag as string | undefined,
                            caption: opt.caption as string | undefined,
                            searchCaption: opt.searchCaption as string | undefined,
                            hint: opt.hint as string | undefined,
                        }
                    })
                    .filter(Boolean) as ProviderOption[]) ?? [],
        }))
    }, [options])

    // Check if we have model options (for cascading menu mode)
    const hasModelOptions = Boolean(
        options && options.length > 0 && options.some((g) => g.options?.length > 0),
    )

    const filteredProviders = useMemo(() => {
        const normalizedSearchTerm = searchTerm.trim().toLowerCase()

        const filterGroupOptions = (group: ProviderGroup): ProviderGroup => ({
            ...group,
            options: group.options.filter(
                (option) =>
                    option.label.toLowerCase().includes(normalizedSearchTerm) ||
                    option.value.toLowerCase().includes(normalizedSearchTerm) ||
                    group.label?.toLowerCase().includes(normalizedSearchTerm),
            ),
        })

        return normalizedGroups.map(filterGroupOptions).filter((group) => group.options.length)
    }, [normalizedGroups, searchTerm])

    const isSearching = searchTerm.trim().length > 0
    const shouldUseProviderPanels = hasModelOptions && showGroup
    // The panel cascade only renders when there is nothing to search through.
    const showPanels = shouldUseProviderPanels && !isSearching
    const hoveredGroup = useMemo(
        () => filteredProviders.find((group) => groupKeyOf(group) === hoveredProvider) ?? null,
        [filteredProviders, hoveredProvider],
    )
    /** Where the provider cursor sits, so the search field can name that row to a screen reader. */
    const activeProviderIndex = useMemo(
        () => filteredProviders.findIndex((group) => groupKeyOf(group) === hoveredProvider),
        [filteredProviders, hoveredProvider],
    )
    // Anchored to a caller's element (the composer's `/model`), the panel spans that element —
    // a fixed 400px hanging off a full-width composer reads as a stray dropdown. Radix publishes
    // the anchor's width as `--radix-popover-trigger-width`.
    const resolvedDropdownWidth =
        providerDropdownWidth ??
        (anchorRef
            ? // Minus PopoverContent's own `p-1` on both sides, so the outer panel lands flush
              // with the anchor rather than overhanging it by 8px.
              "calc(var(--radix-popover-trigger-width) - 0.5rem)"
            : DEFAULT_PROVIDER_DROPDOWN_WIDTH)
    const providerDropdownWidthCss = toCssSize(resolvedDropdownWidth)
    // Sized from the LEFT column when the caller pins one: the connection list holds names, so it
    // is the column with a width worth stating, and the flyout takes the rest.
    const connectionColumnCss = connectionColumnWidth ? toCssSize(connectionColumnWidth) : null
    const resolvedModelListWidth =
        modelListWidth ??
        (connectionColumnCss
            ? `calc(100% - ${connectionColumnCss})`
            : typeof resolvedDropdownWidth === "number"
              ? resolvedDropdownWidth / 2
              : "50%")
    const modelListWidthCss = toCssSize(resolvedModelListWidth)
    const providerPanelWidth = hoveredGroup
        ? (connectionColumnCss ?? `calc(100% - ${modelListWidthCss})`)
        : "100%"

    /** Rows of the non-cascading list (search results, or the flat/ungrouped mode). */
    const flatItems = useMemo(
        () => filteredProviders.flatMap((group) => group.options),
        [filteredProviders],
    )

    /**
     * The flyout's sections. A group that authored none is one unlabelled section holding its
     * options, so rendering and the keyboard walk one shape whether or not harnesses split it.
     */
    const flyoutSections = useMemo<ProviderSection[]>(() => {
        if (!hoveredGroup) return []
        if (hoveredGroup.sections?.length) return hoveredGroup.sections
        return [{key: "__all__", label: "", options: hoveredGroup.options}]
    }, [hoveredGroup])

    /** The flyout's rows in visual order — what `activeModelIndex` indexes into. */
    const flyoutOptions = useMemo(
        () => flyoutSections.flatMap((section) => section.options),
        [flyoutSections],
    )

    // One option, not one per group offering the value: `selectedKey` names the exact row when the
    // caller resolved it, and the value match stands in when it did not.
    const isSelected = useCallback(
        (option: ProviderOption) =>
            selectedKey ? (option.key ?? option.value) === selectedKey : option.value === value,
        [selectedKey, value],
    )

    // `optionLabelProp="label"`: the trigger renders the option's own label node, resolved
    // against the FULL option set so a live search never blanks the current selection.
    const selectedOption = useMemo(
        () =>
            value
                ? normalizedGroups.flatMap((g) => g.options).find((o) => isSelected(o))
                : undefined,
        [normalizedGroups, value, isSelected],
    )

    const closeDropdown = useCallback(() => setOpen(false), [setOpen])

    // Reset on EVERY close, not just the ones routed through `closeDropdown`. A controlled parent
    // can drop `open` on its own — the composer's `←` step-back and "Open config →" do — and that
    // fires no `onOpenChange`, so the panel would reopen holding a stale search term and an
    // expanded provider column.
    useEffect(() => {
        if (open) return
        setSearchTerm("")
        setHoveredProvider(null)
        setActiveModelIndex(null)
    }, [open])

    const handleSelect = useCallback(
        (optionValue: string, metadata?: Record<string, unknown>) => {
            onSelectValue?.(optionValue)
            onChange?.(optionValue, {value: optionValue, metadata})
            closeDropdown()
        },
        [closeDropdown, onChange, onSelectValue],
    )

    // On open (and whenever the result set changes) highlight the selected row, else the first.
    useEffect(() => {
        if (!open) return
        const selectedIdx = flatItems.findIndex((o) => isSelected(o))
        setActiveIndex(!isSearching && selectedIdx >= 0 ? selectedIdx : 0)
    }, [open, flatItems, isSearching, isSelected])

    useEffect(() => {
        if (!open) return
        panelRef.current?.querySelector("[data-active=true]")?.scrollIntoView({block: "nearest"})
    }, [open, activeIndex, activeModelIndex, hoveredProvider])

    const providerIndex = filteredProviders.findIndex((g) => groupKeyOf(g) === hoveredProvider)

    // The enclosing drawer (a modal Radix Sheet) locks page scroll via react-remove-scroll,
    // which intercepts wheel events globally and doesn't recognize this popover's own list —
    // a separate portal — as a scrollable region, so the native wheel gesture never reaches
    // it (keyboard nav still works since that's JS-driven, not a browser scroll). Apply the
    // scroll ourselves so it doesn't depend on the browser's default wheel handling at all.
    const handleWheelScroll = useCallback((e: React.WheelEvent<HTMLDivElement>) => {
        e.currentTarget.scrollTop += e.deltaY
    }, [])

    const handleKeyDown = (e: React.KeyboardEvent<HTMLDivElement>) => {
        const move = (list: unknown[], from: number, dir: 1 | -1) =>
            list.length ? (from + dir + list.length) % list.length : 0

        if (showPanels) {
            const models = flyoutOptions
            if (e.key === "ArrowDown" || e.key === "ArrowUp") {
                e.preventDefault()
                const dir = e.key === "ArrowDown" ? 1 : -1
                if (activeModelIndex !== null) {
                    setActiveModelIndex(move(models, activeModelIndex, dir))
                } else {
                    const next = move(
                        filteredProviders,
                        providerIndex < 0 ? -1 : providerIndex,
                        dir,
                    )
                    setHoveredProvider(
                        filteredProviders[next] ? groupKeyOf(filteredProviders[next]) : null,
                    )
                }
            } else if (e.key === "ArrowRight" && models.length) {
                e.preventDefault()
                setActiveModelIndex(0)
            } else if (e.key === "ArrowLeft") {
                e.preventDefault()
                // Already at the leftmost column, so ← has nothing more to collapse: step out of
                // the picker entirely rather than dead-end.
                if (activeModelIndex === null) onStepBack?.()
                else setActiveModelIndex(null)
            } else if (e.key === "Enter") {
                e.preventDefault()
                if (activeModelIndex !== null) {
                    const option = models[activeModelIndex]
                    if (option) handleSelect(option.value, option.metadata)
                } else if (models.length) {
                    setActiveModelIndex(0)
                }
            }
            return
        }

        if (e.key === "ArrowDown" || e.key === "ArrowUp") {
            e.preventDefault()
            setActiveIndex((i) => move(flatItems, i, e.key === "ArrowDown" ? 1 : -1))
        } else if (e.key === "Home") {
            e.preventDefault()
            setActiveIndex(0)
        } else if (e.key === "End") {
            e.preventDefault()
            setActiveIndex(Math.max(flatItems.length - 1, 0))
        } else if (e.key === "ArrowLeft" && onStepBack && !searchTerm) {
            e.preventDefault()
            onStepBack()
        } else if (e.key === "Enter") {
            e.preventDefault()
            const option = flatItems[activeIndex]
            if (option) handleSelect(option.value, option.metadata)
        }
    }

    const formatCost = (cost: number) => {
        const value = Number(cost)
        if (isNaN(value)) return "N/A"
        return value < 0.01 ? value.toFixed(4) : value.toFixed(2)
    }

    const renderTooltipContent = (metadata: Record<string, unknown>) => (
        <div className="flex flex-col gap-0.5">
            {typeof metadata.description === "string" && metadata.description && (
                <span className="mb-0.5 inline-block max-w-[220px] text-[12px]">
                    {metadata.description}
                </span>
            )}
            {(metadata.input !== undefined || metadata.output !== undefined) && (
                <>
                    <div className="flex justify-between gap-4">
                        <span className="text-nowrap text-[12px]">Input:</span>
                        <span className="text-nowrap text-[12px]">
                            ${formatCost(metadata.input as number)} / 1M
                        </span>
                    </div>
                    <div className="flex justify-between gap-4">
                        <span className="text-nowrap text-[12px]">Output: </span>
                        <span className="text-nowrap text-[12px]">
                            ${formatCost(metadata.output as number)} / 1M
                        </span>
                    </div>
                </>
            )}
        </div>
    )

    /**
     * The label node — shown BOTH in the list row and (for the selected option) in the trigger.
     * `caption` is the option's own second line; in the flat/search view `searchCaption` replaces
     * it, because there is no group column there to say where the row came from. The trigger takes
     * neither: it renders one line.
     */
    const renderOptionContent = (option: ProviderOption, view?: "cascade" | "flat") => {
        const Icon = getProviderIcon(option.value) || LLMIconMap[option.label]
        const caption = view === "flat" ? (option.searchCaption ?? option.caption) : option.caption
        return (
            <span className="flex w-full min-w-0 items-center gap-2 overflow-hidden">
                {Icon && <Icon className="w-4 h-4 flex-shrink-0" />}
                <span className="flex min-w-0 flex-1 flex-col">
                    <span className="flex min-w-0 items-center gap-1.5">
                        <span className="truncate">{option.label}</span>
                        {view && option.tag ? (
                            <span className="shrink-0 rounded-control-sm bg-muted px-1.5 text-field-sm text-colorTextSecondary">
                                {option.tag}
                            </span>
                        ) : null}
                    </span>
                    {view && caption ? (
                        <span className="truncate text-field-sm text-colorTextTertiary">
                            {caption}
                        </span>
                    ) : null}
                </span>
            </span>
        )
    }

    const renderOption = (option: ProviderOption, view: "cascade" | "flat" = "cascade") => {
        const content = renderOptionContent(option, view)

        // Metadata is also how an option carries routing (connection slug, harness); only the
        // descriptive fields are worth a tooltip, and an empty one must never open.
        const describable =
            option.metadata &&
            (option.metadata.description !== undefined ||
                option.metadata.input !== undefined ||
                option.metadata.output !== undefined)

        if (describable) {
            return (
                <TooltipProvider delayDuration={300}>
                    <Tooltip>
                        <TooltipTrigger asChild>{content}</TooltipTrigger>
                        <TooltipContent
                            side="right"
                            container={container ?? undefined}
                            className="bg-colorBgElevated text-colorText [&_svg]:fill-colorBgElevated"
                        >
                            {renderTooltipContent(option.metadata ?? {})}
                        </TooltipContent>
                    </Tooltip>
                </TooltipProvider>
            )
        }

        return content
    }

    /**
     * A section's harness label. Alone it reads as `via <logo> <name>` — a lead-in to rows that
     * need no further marking; several read as the labels of the runs they head.
     */
    const renderSectionLabel = (section: ProviderSection, single: boolean) => {
        const Icon = section.iconKey ? getHarnessIcon(section.iconKey) : null
        const name = sectionTooltip ? (
            <TooltipProvider delayDuration={300}>
                <Tooltip>
                    <TooltipTrigger asChild>
                        <span className="cursor-help underline decoration-dotted underline-offset-2">
                            {section.label}
                        </span>
                    </TooltipTrigger>
                    <TooltipContent
                        side="top"
                        container={container ?? undefined}
                        className="rounded-control-sm text-[11px]"
                    >
                        {sectionTooltip}
                    </TooltipContent>
                </Tooltip>
            </TooltipProvider>
        ) : (
            <span>{section.label}</span>
        )

        return (
            <div
                role="presentation"
                className="flex items-center gap-1.5 px-3 py-1 text-[11px] text-colorTextTertiary"
            >
                {single ? <span>via</span> : null}
                {Icon && <Icon className="w-3 h-3 shrink-0" />}
                {name}
            </div>
        )
    }

    /**
     * One flyout row: the check column marks the current pick (no bolding — the check IS the
     * mark), then the model name and its quiet aside.
     */
    const renderModelRow = (option: ProviderOption, index: number) => (
        <div
            key={option.key ?? option.value}
            id={modelOptionId(index)}
            role="option"
            aria-selected={isSelected(option)}
            data-active={index === activeModelIndex}
            onMouseEnter={() => setActiveModelIndex(index)}
            className={clsx(ROW_CLASS, "hover:bg-muted data-[active=true]:bg-muted")}
            onMouseDown={(e) => {
                e.preventDefault()
                e.stopPropagation()
                handleSelect(option.value, option.metadata)
            }}
        >
            <span className="flex w-3 shrink-0 items-center justify-center">
                {isSelected(option) ? <Check size={12} className="text-colorText" /> : null}
            </span>
            <span className="flex min-w-0 flex-1 items-baseline gap-1.5 overflow-hidden">
                <span className="truncate text-xs">{option.label}</span>
                {option.hint ? (
                    <span className="shrink-0 text-field-sm text-colorTextTertiary">
                        {option.hint}
                    </span>
                ) : null}
            </span>
        </div>
    )

    const renderListRow = (option: ProviderOption, index: number) => (
        <div
            key={option.key ?? option.value}
            id={optionId(index)}
            role="option"
            aria-selected={isSelected(option)}
            data-active={index === activeIndex}
            onMouseEnter={() => setActiveIndex(index)}
            onMouseDown={(e) => e.preventDefault()}
            onClick={() => handleSelect(option.value, option.metadata)}
            className={clsx(
                ROW_CLASS,
                isSelected(option)
                    ? "bg-controlItemBgActive font-semibold"
                    : "data-[active=true]:bg-muted",
            )}
        >
            {renderOption(option, "flat")}
        </div>
    )

    let flatRowIndex = -1

    // antd greys only the placeholder/arrow, and turns the whole control red on error.
    const adornmentColor = invalid ? "text-error" : "text-placeholder"

    return (
        <Popover
            open={open}
            onOpenChange={(next) => {
                if (next) setOpen(true)
                else closeDropdown()
            }}
        >
            {/* Anchored mode: the panel positions against the caller's element and renders no
                trigger of its own (the composer's `/model` opens it with nothing to click). */}
            {anchorRef ? <PopoverAnchor virtualRef={anchorRef} /> : null}

            {hideTrigger ? null : (
                <PopoverTrigger asChild>
                    <button
                        type="button"
                        id={id}
                        // Not `role=combobox`: the search field inside the panel owns the
                        // combobox/listbox relationship, this is the disclosure button.
                        // Radix supplies aria-expanded / aria-controls.
                        aria-haspopup="listbox"
                        aria-label={ariaLabel}
                        aria-labelledby={ariaLabelledby}
                        aria-invalid={invalid || undefined}
                        disabled={disabled}
                        data-placeholder={selectedOption || value ? undefined : ""}
                        className={clsx(
                            selectTriggerVariants({size: TRIGGER_SIZE[size]}),
                            "text-left",
                            className,
                        )}
                        style={{width: "100%", ...style}}
                    >
                        <span className="flex min-w-0 flex-1 items-center gap-2 overflow-hidden">
                            {selectedOption ? (
                                renderOptionContent(selectedOption)
                            ) : value ? (
                                <span className="truncate">{value}</span>
                            ) : (
                                <span className={clsx("truncate", adornmentColor)}>
                                    {placeholder}
                                </span>
                            )}
                        </span>
                        <ChevronDown className={clsx("size-3 shrink-0", adornmentColor)} />
                    </button>
                </PopoverTrigger>
            )}

            <PopoverContent
                align="start"
                container={container}
                onOpenAutoFocus={(e) => {
                    if (!showSearch) return
                    e.preventDefault()
                    inputRef.current?.focus()
                }}
                // Anchored mode has no trigger to restore focus to, so Radix would drop it on
                // <body> — and it runs after the caller's own focus(), undoing it. The caller
                // decides where focus goes once the panel is gone.
                onCloseAutoFocus={anchorRef ? (e) => e.preventDefault() : undefined}
                onPointerDownOutside={onDismissOutside ? () => onDismissOutside() : undefined}
                onKeyDown={handleKeyDown}
                className={clsx(
                    "p-1",
                    // antd's `popupMatchSelectWidth`: the cascade sizes itself, everything else
                    // tracks the trigger.
                    shouldUseProviderPanels ? "w-auto" : "w-[var(--radix-popover-trigger-width)]",
                    // Anchored mode only. A triggered dropdown has the click that opened it to
                    // explain where it came from; this one has none, so it grows out of its
                    // anchor edge (Radix's own origin) instead of appearing there.
                    anchorRef &&
                        "origin-[var(--radix-popover-content-transform-origin)] animate-command-panel-in motion-reduce:animate-command-panel-fade",
                )}
            >
                <div
                    ref={panelRef}
                    className="flex flex-col gap-1"
                    style={shouldUseProviderPanels ? {width: providerDropdownWidthCss} : undefined}
                >
                    {panelHeader ? (
                        <div className="-mx-1 -mt-1 mb-1 border-0 border-b border-solid border-border bg-muted/40 px-3 py-1.5">
                            {panelHeader}
                        </div>
                    ) : null}

                    {showSearch && (
                        <div className="relative border-0 border-b border-solid border-border">
                            <Input
                                ref={inputRef}
                                placeholder={searchPlaceholder}
                                aria-label={searchPlaceholder}
                                // Focus stays here in BOTH views, so this field is what names the
                                // active row. In the grouped view that row lives in the provider
                                // column until you step right into the models column.
                                aria-controls={
                                    showPanels
                                        ? activeModelIndex === null
                                            ? providerListId
                                            : modelListId
                                        : listId
                                }
                                aria-activedescendant={
                                    showPanels
                                        ? activeModelIndex === null
                                            ? activeProviderIndex >= 0
                                                ? providerOptionId(activeProviderIndex)
                                                : undefined
                                            : modelOptionId(activeModelIndex)
                                        : flatItems[activeIndex]
                                          ? optionId(activeIndex)
                                          : undefined
                                }
                                value={searchTerm}
                                onChange={(e) => setSearchTerm(e.target.value)}
                                variant="ghost"
                                className={clsx(
                                    "rounded-none py-1.5",
                                    searchSuffix ? "pr-20" : "pr-8",
                                )}
                            />
                            {searchTerm && (
                                <button
                                    type="button"
                                    aria-label="Clear search"
                                    onClick={() => {
                                        setSearchTerm("")
                                        inputRef.current?.focus()
                                    }}
                                    className={clsx(
                                        "absolute top-1/2 -translate-y-1/2 cursor-pointer rounded border-none bg-transparent p-1 hover:bg-muted",
                                        searchSuffix ? "right-14" : "right-2",
                                    )}
                                >
                                    <X size={12} className="text-placeholder" />
                                </button>
                            )}
                            {searchSuffix ? (
                                <span className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-field-sm text-placeholder">
                                    {searchSuffix}
                                </span>
                            ) : null}
                        </div>
                    )}

                    {/* When searching or no model options: show the standard list */}
                    {!showPanels && (
                        <>
                            <div
                                id={listId}
                                role="listbox"
                                aria-label={ariaLabel ?? "Options"}
                                className="max-h-[256px] overflow-y-auto"
                                onWheel={handleWheelScroll}
                            >
                                {flatItems.length === 0 ? (
                                    <div className="py-4 text-center text-field-sm text-placeholder">
                                        {emptyText}
                                    </div>
                                ) : (
                                    filteredProviders.map((group, idx) => {
                                        const GroupIcon = getProviderIcon(
                                            group.iconKey || group.label || "",
                                        )
                                        const rows = group.options.map((option) => {
                                            flatRowIndex += 1
                                            return renderListRow(option, flatRowIndex)
                                        })

                                        return showGroup ? (
                                            <div
                                                key={`group-${group.label}-${idx}`}
                                                role="group"
                                                aria-label={group.label ?? undefined}
                                            >
                                                <div
                                                    role="presentation"
                                                    className="flex items-center gap-1 px-3 py-[5px] text-field-sm text-placeholder"
                                                >
                                                    {GroupIcon && <GroupIcon className="w-3 h-3" />}
                                                    <span>{group.label}</span>
                                                </div>
                                                {rows}
                                            </div>
                                        ) : (
                                            <React.Fragment key={`group-${group.label}-${idx}`}>
                                                {rows}
                                            </React.Fragment>
                                        )
                                    })
                                )}
                            </div>
                            {footerContent}
                        </>
                    )}

                    {/* When not searching and has model options with showGroup: provider/model panels */}
                    {showPanels && (
                        <div className="relative flex min-h-[220px] min-w-0">
                            <div
                                className="flex min-w-0 flex-col"
                                style={{width: providerPanelWidth}}
                            >
                                <div
                                    className="py-1"
                                    role="listbox"
                                    id={providerListId}
                                    aria-label="Providers"
                                >
                                    {filteredProviders.map((group, idx) => {
                                        const Icon = getProviderIcon(
                                            group.iconKey || group.label || "",
                                        )
                                        const isHovered = hoveredProvider === groupKeyOf(group)
                                        // A group naming itself (a connection) is shown verbatim;
                                        // a provider-family label still gets its display name.
                                        const displayName = group.iconKey
                                            ? (group.label ?? "")
                                            : getProviderDisplayName(group.label || "")

                                        return (
                                            <div
                                                key={`provider-${groupKeyOf(group)}-${idx}`}
                                                id={providerOptionId(idx)}
                                                role="option"
                                                // The open column IS this listbox's chosen row —
                                                // there is no other provider value to mark.
                                                aria-selected={isHovered}
                                                data-active={isHovered && activeModelIndex === null}
                                                onMouseEnter={() => {
                                                    setHoveredProvider(groupKeyOf(group))
                                                    setActiveModelIndex(null)
                                                }}
                                                onClick={() => {
                                                    setHoveredProvider(groupKeyOf(group))
                                                    setActiveModelIndex(0)
                                                }}
                                                className={clsx(
                                                    ROW_CLASS,
                                                    "hover:bg-muted",
                                                    isHovered && "bg-muted",
                                                )}
                                            >
                                                {Icon && <Icon className="w-4 h-4 flex-shrink-0" />}
                                                <span className="flex min-w-0 flex-1 flex-col">
                                                    <span className="flex min-w-0 items-center gap-1.5">
                                                        <span className="truncate text-xs">
                                                            {displayName}
                                                        </span>
                                                        {group.tag ? (
                                                            <span
                                                                className={clsx(
                                                                    "shrink-0 rounded-control-sm px-1.5 text-[11px]",
                                                                    group.tagTone === "olive"
                                                                        ? "bg-[var(--ag-ref-environment-bg)] text-[var(--ag-ref-environment-text)]"
                                                                        : "bg-muted text-colorTextSecondary",
                                                                )}
                                                            >
                                                                {group.tag}
                                                            </span>
                                                        ) : null}
                                                    </span>
                                                    {group.caption ? (
                                                        <span className="truncate text-[11px] text-colorTextTertiary">
                                                            {group.caption}
                                                        </span>
                                                    ) : null}
                                                </span>
                                                <span className="text-field-sm tabular-nums text-colorTextTertiary">
                                                    {group.options.length}
                                                </span>
                                                <CaretRight
                                                    size={12}
                                                    className="flex-shrink-0 text-colorTextTertiary"
                                                />
                                            </div>
                                        )
                                    })}
                                </div>

                                {footerContent && (
                                    <div className="mt-auto w-full">{footerContent}</div>
                                )}
                            </div>

                            {hoveredGroup && (
                                <div
                                    role="listbox"
                                    id={modelListId}
                                    aria-label={hoveredGroup.label ?? "Models"}
                                    className="absolute inset-y-0 right-0 overflow-y-auto border-0 border-l border-solid border-border py-1"
                                    style={{width: modelListWidthCss}}
                                    onWheel={handleWheelScroll}
                                >
                                    {(() => {
                                        // One running index across the sections: the keyboard walks
                                        // the flyout as one list, so the rows must number as one.
                                        let rowIndex = -1
                                        const single = flyoutSections.length === 1
                                        return flyoutSections.map((section) => (
                                            <div
                                                key={section.key}
                                                role="group"
                                                aria-label={section.label || undefined}
                                            >
                                                {section.label
                                                    ? renderSectionLabel(section, single)
                                                    : null}
                                                {section.options.map((option) => {
                                                    rowIndex += 1
                                                    return renderModelRow(option, rowIndex)
                                                })}
                                            </div>
                                        ))
                                    })()}
                                </div>
                            )}
                        </div>
                    )}

                    {panelFooter ? (
                        <div className="-mx-1 -mb-1 mt-1 border-0 border-t border-solid border-border bg-muted/40 px-3 py-1.5">
                            {panelFooter}
                        </div>
                    ) : null}
                </div>
            </PopoverContent>
        </Popover>
    )
}

export default SelectLLMProviderBase
