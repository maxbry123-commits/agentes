/**
 * DrillInUIContext
 *
 * Context for injecting OSS-specific UI components into the DrillInView system.
 * This allows the package to remain dependency-free while still supporting
 * rich editors and chat message components when provided.
 *
 * Usage:
 * 1. OSS wraps the app with DrillInUIProvider, passing OSS components
 * 2. Package components use useDrillInUI() to get the injected components
 * 3. If components are not provided, fallbacks are used
 */

import {
    createContext,
    useContext,
    type ComponentType,
    type ReactNode,
    type ReactElement,
} from "react"

import type {EditorProps} from "../../Editor"
import type {SharedEditorProps} from "../../SharedEditor"

/**
 * Inline provider option/group types to avoid importing from @agenta/ui.
 * These mirror the canonical types in @agenta/ui/select-llm-provider.
 */
interface LLMProviderOption {
    label: string
    value: string
    key?: string
    metadata?: Record<string, unknown>
}

interface LLMProviderGroup {
    label?: string | null
    options: LLMProviderOption[]
}

export interface GatewayToolConnectionUI {
    id: string
    slug: string
    name?: string
    integration_key: string
    provider_key: string
    flags?: {is_active?: boolean; is_valid?: boolean}
}

export interface GatewayToolActionUI {
    key: string
    name: string
}

export interface GatewayToolsBridge {
    enabled: boolean
    connections: GatewayToolConnectionUI[]
    connectionsLoading: boolean
    /** The connections fetch failed — an empty list then means "unknown", not "none". */
    connectionsErrored?: boolean
    onOpenCatalog: () => void
    renderIntegrationInfo?: (integrationKey: string) => {name?: string; logo?: string} | null
    useIntegrationInfo?: (integrationKey: string) => {
        name?: string
        logo?: string
        isLoading?: boolean
    }
    useActions: (integrationKey: string) => {
        actions: GatewayToolActionUI[]
        total: number
        isLoading: boolean
        isFetchingNextPage: boolean
        hasNextPage: boolean
        requestMore: () => void
        setSearch: (search: string) => void
        prefetchThreshold: number
    }
    buildToolSlug: (
        provider: string,
        integration: string,
        action: string,
        connectionSlug: string,
    ) => string
    fetchActionDetail: (
        provider: string,
        integration: string,
        action: string,
    ) => Promise<{
        action: {description?: string; schemas?: {inputs?: unknown}}
    }>
}

/** Coarse workflow kind for the reference list's badge + filter chips. Derived by the provider from
 * the workflow's role/capability flags. `evaluator` covers all evaluator workflows (code/match/llm/…)
 * so they read as evaluators rather than falling through to `custom`. */
export type WorkflowReferenceType = "agent" | "chat" | "completion" | "custom" | "evaluator"

export interface WorkflowReferenceUI {
    id: string
    slug: string
    name?: string
    description?: string
    /** Workflow kind for badge/filter display; omitted when the provider can't classify it. */
    type?: WorkflowReferenceType
    /** Finer-grained badge text overriding the generic type label (e.g. an evaluator's kind
     * "Exact Match" instead of "evaluator"). `type` still drives the badge color + filter chip. */
    typeLabel?: string
}

/** One workflow, resolved far enough for the picker to display it and bind to it. Both come from
 *  the same revision: splitting them let a row show one revision while the reference bound another. */
export interface WorkflowReferenceCatalogEntry {
    /** Agent, chat, completion, custom or evaluator. Only agents belong in the Subagents section. */
    type?: WorkflowReferenceType
    /** The workflow this slug belongs to. A row's icon is keyed by workflow id. */
    workflowId?: string
    /** The model the agent runs on, for the row's meta line. */
    model?: string
    /** Provider display name, for the model's mark. */
    provider?: string
    /** Integration keys this agent has connected. */
    integrations: string[]
}

/** One subagent's configuration for the detail panel. Read-only there: it is managed on the
 *  agent itself, and the calling agent only chooses to call it. */
export interface SubagentDetail {
    /** The workflow, so the detail can link to the agent's own page. */
    workflowId?: string
    /** The agent's own description, used as the seed for the calling agent's copy. */
    description?: string
    model?: string
    /** Provider display key for the model's mark. */
    provider?: string
    /** One row per connected app, with the permission the agent granted it. */
    integrations: {key: string; name?: string; logo?: string | null; permission?: string}[]
    /** Skill names, shown as pills. */
    skills: string[]
    /** The agent's instruction file, when it has one. */
    instructions?: {fileName: string; text: string; wordCount: number}
}

/** What the picker emits when the author adds a subagent. The reference always follows the
 *  target's latest revision, so the payload carries no version and no environment. */
export interface WorkflowReferencePayload {
    slug: string
    /** Tool description the model sees (defaults to the workflow's own description). */
    description?: string
}

/** A single role-tagged prompt message (for a `messages`-kind config part). */
export interface WorkflowConfigMessage {
    role: string
    content: string
}

/** One part of a referenced workflow's configuration, shown in the Configuration section's rail
 * (e.g. the prompt "Messages", a "Model", a custom workflow's "handler.py", an agent's "Instructions"). */
export interface WorkflowConfigPart {
    key: string
    label: string
    /** How to render: "code" (read-only editor), "text" (plain), "json" (pretty JSON), "messages"
     * (role-tagged message list from `messages`). */
    kind: "code" | "text" | "json" | "messages"
    content: string
    /** Highlighting language when `kind` is "code" (e.g. "python", "typescript"). */
    language?: string
    /** Role-tagged messages when `kind` is "messages". */
    messages?: WorkflowConfigMessage[]
}

/** A referenced workflow's type-specific configuration for the Configuration section. */
export interface WorkflowConfigPayload {
    parts: WorkflowConfigPart[]
}

/**
 * Bridge for the "reference a workflow as a tool" source in the tool selector (#4860).
 * OSS supplies the project's workflows plus resolvers for a workflow's input schema, its
 * revisions (variant axis), and its environments (environment axis); the selector emits a
 * `type:"reference"` tools[] entry that the backend runs server-side as a callback tool.
 * Parallels {@link GatewayToolsBridge}.
 */
export interface WorkflowReferenceBridge {
    enabled: boolean
    workflows: WorkflowReferenceUI[]
    workflowsLoading: boolean
    /** Activate the workflow list + evaluator catalog behind this bridge. Lazy: the underlying
     * project-wide list/catalog queries stay dormant (`workflows` empty) until a consumer that
     * actually needs them calls this — on reference-picker open or when displaying an existing
     * reference. One-way; stays warm after the first call. */
    activate?: () => void
    /** Resolve the referenced workflow's input JSON-schema to pre-fill the tool's `input_schema`.
     * Returns null when unavailable; the caller falls back to an empty object schema. */
    resolveInputSchema: (workflow: WorkflowReferenceUI) => Promise<Record<string, unknown> | null>
    /** Resolve the workflow's output JSON-schema for the Schema section's Outputs tab.
     * Optional; when absent or resolving null, the Outputs tab is hidden. */
    resolveOutputSchema?: (workflow: WorkflowReferenceUI) => Promise<Record<string, unknown> | null>
    /** Resolve the workflow's type-specific configuration (code / prompt / agent) for the
     * Configuration section. Optional; when absent or resolving null, the section is hidden. */
    resolveConfigPayload?: (workflow: WorkflowReferenceUI) => Promise<WorkflowConfigPayload | null>
    /** Everything a reference surface needs for a batch of SLUGS, in one cached pass. Slugs, not
     *  workflows: the project-wide list is lazily activated and stays empty until the picker opens. */
    useWorkflowReferenceCatalog: (slugs: string[]) => {
        bySlug: Record<string, WorkflowReferenceCatalogEntry | undefined>
        /** Slugs whose revision fetch failed, so a caller can say so instead of showing nothing. */
        failedSlugs: string[]
        loading: boolean
        retry: () => void
    }
    /** One subagent's configuration for the detail panel, cached so the header and the body share it.
     *  Required, not optional: a hook that may be absent cannot be called without breaking hook order. */
    useSubagentDetail: (slug: string) => {detail: SubagentDetail | null; loading: boolean}
    /** A link to an agent's own page. Only the host knows its routes; without it the button hides. */
    agentHref?: (workflowId: string) => string | null
}

/**
 * Interface for injectable UI components
 */
export interface DrillInUIComponents {
    /**
     * Editor provider component (wraps rich text editor)
     * Used by: TextField, JsonEditorWithLocalState
     */
    EditorProvider?: ComponentType<EditorProps & {children: ReactNode}>

    /**
     * Shared editor component (rich text/JSON editor)
     * Used by: TextField, JsonEditorWithLocalState
     */
    SharedEditor?: ComponentType<SharedEditorProps>

    /**
     * Chat message list component
     * Used by: MessagesField, MessagesSchemaControl, PromptSchemaControl
     */
    ChatMessageList?: ComponentType<{
        messages: unknown[]

        onChange?: (messages: unknown[]) => void
        editable?: boolean
        showControls?: boolean
        enableTokens?: boolean
        templateFormat?: string
        [key: string]: unknown
    }>

    /**
     * Single chat message editor component
     * Used by: JsonObjectField for editing single message objects
     */
    ChatMessageEditor?: ComponentType<{
        id: string
        role: string
        text: string
        disabled?: boolean
        enableTokens?: boolean
        templateFormat?: string
        onChangeRole?: (role: string) => void
        onChangeText?: (text: string) => void
        headerRight?: ReactNode
        [key: string]: unknown
    }>

    /**
     * Markdown toggle button component
     * Used by: JsonObjectField, TextField for toggling markdown preview
     */
    MarkdownToggleButton?: ComponentType<{
        id: string
        [key: string]: unknown
    }>

    /**
     * Message display function (for notifications like "Copied to clipboard")
     * Used by: DrillInFieldHeader
     */
    showMessage?: (content: string, type?: "success" | "error" | "info") => void

    /**
     * Drill-in context provider (for Editor integration)
     * Used by: DrillInContent, JsonEditorWithLocalState
     */
    DrillInContextProvider?: ComponentType<{
        value: {enabled: boolean}
        children: ReactNode
    }>

    /**
     * LLM provider configuration data for model selection.
     * Used by: GroupedChoiceControl, ConfigurationSection, LegacyPlaygroundConfigSection
     *
     * Instead of injecting a whole component, OSS provides:
     * - extraOptionGroups: vault/custom secret options to merge into the dropdown
     * - footerContent: "Add provider" button + drawer rendered in the dropdown footer
     */
    llmProviderConfig?: {
        /**
         * One option group per stored provider connection, each option stamped with the
         * connection slug in `metadata.connectionSlug`. Takes the caller's static model catalog
         * (provider family -> model ids, i.e. the schema's `choices`) because a standard
         * connection that saved no model list of its own offers its provider's catalog models.
         * Prefer this over `extraOptionGroups` wherever a schema catalog is in hand.
         */
        connectionGroupsFor?: (catalog?: Record<string, string[]>) => LLMProviderGroup[]
        /** Extra option groups from vault/custom secrets */
        extraOptionGroups?: LLMProviderGroup[]
        /** Footer content (the "Manage model providers" row) rendered below the dropdown */
        footerContent?: ReactElement | null
        /**
         * Shown in place of the model picker when nothing is connected and nothing is stored —
         * the host's "Set up model providers" affordance, which opens its provider drawer. Null
         * while the vault has not answered yet, so no host claims "nothing connected" early.
         */
        emptyStateContent?: ReactElement | null
        /** Opens the host's "Configure provider" drawer for a NEW custom provider, pre-selecting
         * `kind` (e.g. "azure", "bedrock", "vertex_ai", "custom"). Absent on hosts with no drawer
         * wired up — callers hide the affordance in that case. */
        openConfigureProvider?: (kind: string) => void
    }

    /**
     * Deployment (host app) facts the package can't determine itself. Today: whether this
     * deployment is Agenta cloud, which gates the Provider credentials section's self-managed
     * card badge (design.md D6, docs/design/connect-model-drawer) — the "Use subscription" mode
     * itself stays clickable regardless. Absent (older hosts) reads as not-cloud, i.e. ungated.
     */
    deployment?: {
        /** Policy: gates the self-managed card's "Not on cloud" badge, NOT the connection mode's
         * clickability (the toggle is always clickable when capability-allowed). Never changes at
         * runtime. */
        isCloud: boolean
        /** Link target for the self-managed info card's "Read the self-hosting guide" pill. */
        selfHostingGuideUrl?: string
    }

    /** Gateway tools integration for the tool selector */
    gatewayTools?: GatewayToolsBridge

    /** Workflow-as-tool reference integration for the tool selector (#4860) */
    workflowReference?: WorkflowReferenceBridge

    /** Open a trace in the host application. */
    openTrace?: (params: {traceId: string; spanId?: string | null}) => void

    /**
     * Lexical editor context hook
     * Used by: ResponseFormatControl for reading editor content
     */
    useLexicalComposerContext?: () => [unknown]

    /**
     * Get editor code as string function
     * Used by: ResponseFormatControl for extracting JSON from editor
     */
    getEditorCodeAsString?: (editor: unknown) => string

    /**
     * Try parse partial JSON function
     * Used by: ResponseFormatControl for parsing JSON with relaxed syntax
     */
    tryParsePartialJson?: (jsonString: string) => Record<string, unknown>

    /**
     * Feature flags for opt-in drill-in behaviours.
     * Injected via DrillInUIProvider so any component in the tree
     * can read them via useDrillInUI() without prop drilling.
     */
    featureFlags?: {
        /**
         * When true, Form is available as a view-mode option for object fields.
         * Default false - ships hidden until the rail renderer is validated.
         */
        enableFormView?: boolean
    }
}

/**
 * Default context value - empty components
 */
const defaultContext: DrillInUIComponents = {}

/**
 * Context for UI component injection
 */
const DrillInUIContext = createContext<DrillInUIComponents>(defaultContext)

/**
 * Provider props
 */
export interface DrillInUIProviderProps {
    children: ReactNode
    components: DrillInUIComponents
}

/**
 * Provider component for injecting UI components
 *
 * @example
 * ```tsx
 * // In OSS app wrapper
 * <DrillInUIProvider
 *   components={{
 *     EditorProvider,
 *     SharedEditor,
 *     ChatMessageList,
 *     showMessage: (content) => message.success(content),
 *   }}
 * >
 *   <App />
 * </DrillInUIProvider>
 * ```
 */
export function DrillInUIProvider({children, components}: DrillInUIProviderProps) {
    return <DrillInUIContext.Provider value={components}>{children}</DrillInUIContext.Provider>
}

/**
 * Hook to access injected UI components
 *
 * @example
 * ```tsx
 * function TextField() {
 *   const { EditorProvider, SharedEditor } = useDrillInUI()
 *
 *   if (!EditorProvider || !SharedEditor) {
 *     return <textarea ... /> // Fallback
 *   }
 *
 *   return (
 *     <EditorProvider>
 *       <SharedEditor ... />
 *     </EditorProvider>
 *   )
 * }
 * ```
 */
export function useDrillInUI(): DrillInUIComponents {
    return useContext(DrillInUIContext)
}

/**
 * Default message handler (console.log fallback)
 */
export const defaultShowMessage = (content: string, type?: "success" | "error" | "info") => {
    const prefix = type ? `[${type.toUpperCase()}]` : "[INFO]"
    console.log(`${prefix} ${content}`)
}
