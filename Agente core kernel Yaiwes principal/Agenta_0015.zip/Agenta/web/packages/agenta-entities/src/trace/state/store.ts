/**
 * Trace Entity Store
 *
 * This module provides Jotai atoms and batch fetchers for trace and span entities.
 * Uses @agenta/shared for common utilities and @agenta/entities/shared for draft state.
 *
 * @example
 * ```typescript
 * import {
 *   spanQueryAtomFamily,
 *   traceSpanEntityAtomFamily,
 *   invalidateTraceEntityCache,
 * } from '@agenta/entities/trace'
 *
 * // In components
 * const spanQuery = useAtomValue(spanQueryAtomFamily(spanId))
 * const span = useAtomValue(traceSpanEntityAtomFamily(spanId))
 * ```
 */

import {immutablePersister} from "@agenta/shared/api/persist"
import {projectIdAtom, sessionAtom} from "@agenta/shared/state"
import {createBatchFetcher} from "@agenta/shared/utils"
import type {QueryKey} from "@tanstack/react-query"
import {atom, getDefaultStore} from "jotai"
import {atomWithQuery, queryClientAtom} from "jotai-tanstack-query"

// Deep imports — the shared/index barrel re-exports React components
// (UserAuthorLabel) and CSS-coupled paginated table helpers, which break
// Node-side execution. Pure molecule utilities are Node-safe.
// instrumentedAtomFamily wraps jotai-family's atomFamily with size/clear
// visibility — see ../../shared/molecule/instrumentedAtomFamily.
import {
    createEntityDraftState,
    normalizeValueForComparison,
} from "../../shared/molecule/createEntityDraftState"
import {instrumentedAtomFamily} from "../../shared/molecule/instrumentedAtomFamily"
import {fetchAllPreviewTraces} from "../api"
import {isSpansResponse} from "../api/helpers"
import type {SpanRequest, TraceRequest, TracesApiResponse} from "../core"
import {traceSpanSchema, type TraceSpan} from "../core"
import {extractAgData, extractInputs, extractOutputs} from "../utils"

// ============================================================================
// CACHE INVALIDATION
// ============================================================================

/**
 * Invalidate the trace entity cache.
 * Call this after running an invocation to force a fresh fetch of trace data.
 */
export const invalidateTraceEntityCache = () => {
    const store = getDefaultStore()
    const queryClient = store.get(queryClientAtom)
    queryClient.invalidateQueries({queryKey: ["trace-entity"]})
    queryClient.invalidateQueries({queryKey: ["trace-summary"]})
}

// ============================================================================
// TRACE FRESHNESS
// Traces are immutable once ingested; only a trace whose run JUST finished in
// this session may legitimately 404 (ingestion lag) and earn the full retry
// ladder. Historical traces that 404 are gone — retrying hammers the API.
// ============================================================================

const FRESH_TRACE_WINDOW_MS = 2 * 60_000
const freshTraceMarks = new Map<string, number>()

const canonicalTraceKey = (traceId: string) => traceId.replace(/-/g, "")

/** Call at run completion (stream finish / invocation success) with the run's trace id. */
export const markTraceAsFresh = (traceId: string | null | undefined) => {
    if (!traceId) return
    freshTraceMarks.set(canonicalTraceKey(traceId), Date.now())
}

const isTraceFresh = (traceId: string) => {
    const markedAt = freshTraceMarks.get(canonicalTraceKey(traceId))
    return markedAt !== undefined && Date.now() - markedAt < FRESH_TRACE_WINDOW_MS
}

/** Retry not-found aggressively only for fresh traces; once for everything else. */
const traceNotFoundRetry =
    (traceId: string | null) =>
    (failureCount: number, error: Error): boolean => {
        if (!(error instanceof TraceNotFoundError) || !traceId) return false
        return failureCount < (isTraceFresh(traceId) ? 5 : 1)
    }

// ============================================================================
// BATCH FETCHER FOR SPANS
// Collects concurrent single-span requests and batches them
// ============================================================================

/**
 * Batch fetcher that combines concurrent span requests into a single API call
 * Groups by projectId and fetches all spans in a single query
 */
const spanBatchFetcher = createBatchFetcher<
    SpanRequest,
    TraceSpan | null,
    Map<string, TraceSpan | null>
>({
    serializeKey: ({projectId, spanId}) => `${projectId}:${spanId}`,
    batchFn: async (requests, serializedKeys) => {
        const results = new Map<string, TraceSpan | null>()
        serializedKeys.forEach((key) => results.set(key, null))

        // Exactly one project is in scope at a time in the web app.
        const projectId = requests[0]?.projectId
        if (!projectId) return results
        if (requests.some((req) => req.projectId !== projectId)) {
            throw new Error("spanBatchFetcher: requests span multiple projects")
        }

        const spanIds = [...new Set(requests.map((req) => req.spanId).filter(Boolean))]
        if (spanIds.length === 0) return results

        try {
            const filter = {
                conditions: [
                    {
                        field: "span_id",
                        operator: "in",
                        value: spanIds,
                    },
                ],
            }

            const data = await fetchAllPreviewTraces(
                {
                    size: spanIds.length,
                    focus: "span",
                    filter: JSON.stringify(filter),
                },
                "", // appId not needed for span lookup
                projectId,
            )

            const spans: TraceSpan[] = []
            if (isSpansResponse(data)) {
                spans.push(...data.spans.map((s) => traceSpanSchema.parse(s)))
            }

            const byId = new Map<string, TraceSpan>()
            spans.forEach((span) => {
                byId.set(span.span_id, span)
            })

            requests.forEach((req, idx) => {
                results.set(serializedKeys[idx], byId.get(req.spanId) ?? null)
            })
        } catch (error) {
            console.error(
                `[spanBatchFetcher] Failed to fetch spans for project ${projectId}:`,
                error instanceof Error ? error.message : String(error),
                {projectId, spanIds, error},
            )
        }

        return results
    },
    resolveResult: (response, _request, serializedKey) => {
        return response.get(serializedKey) ?? null
    },
    maxBatchSize: 100,
})

// ============================================================================
// BATCH FETCHER FOR TRACES
// Collects concurrent single-trace requests and batches them
// ============================================================================

/**
 * Batch fetcher that combines concurrent trace requests into a single API call
 * Uses the /spans/query endpoint with trace_id IN filter.
 *
 * Exported for use by `trace/state/prefetch.ts` and other entity-layer
 * prefetch helpers. Consumers should prefer the higher-level
 * `prefetchTracesByIds()` action which adds TanStack cache integration on
 * top of the per-id coalescing this fetcher already does.
 */
export const traceBatchFetcher = createBatchFetcher<
    TraceRequest,
    TracesApiResponse | null,
    Map<string, TracesApiResponse | null>
>({
    serializeKey: ({projectId, traceId}) => `${projectId}:${traceId}`,
    batchFn: async (requests, serializedKeys) => {
        const results = new Map<string, TracesApiResponse | null>()
        serializedKeys.forEach((key) => results.set(key, null))

        // Exactly one project is in scope at a time in the web app.
        const projectId = requests[0]?.projectId
        if (!projectId) return results
        if (requests.some((req) => req.projectId !== projectId)) {
            throw new Error("traceBatchFetcher: requests span multiple projects")
        }

        const traceIds = requests.map((req) => req.traceId).filter(Boolean)
        if (traceIds.length === 0) return results

        // Normalize trace IDs (remove dashes) for the query
        const canonicalIds = [...new Set(traceIds.map((id) => id.replace(/-/g, "")))]

        try {
            const data = (await fetchAllPreviewTraces(
                {
                    focus: "trace",
                    format: "agenta",
                    filter: JSON.stringify({
                        conditions: [
                            {
                                field: "trace_id",
                                operator: "in",
                                value: canonicalIds,
                            },
                        ],
                    }),
                },
                "",
                projectId,
            )) as TracesApiResponse

            // The response has format: { traces: { [traceIdNoDashes]: { spans: {...} } } }
            const tracesObj = data?.traces ?? {}

            requests.forEach((req, idx) => {
                if (!req.traceId) return
                const traceIdNoDashes = req.traceId.replace(/-/g, "")
                const traceData = tracesObj[traceIdNoDashes]

                if (traceData) {
                    // Return a response that looks like fetchPreviewTrace output
                    results.set(serializedKeys[idx], {
                        count: 1,
                        traces: {[traceIdNoDashes]: traceData},
                    })
                }
            })
        } catch (error) {
            console.error(
                `[traceBatchFetcher] Failed to fetch traces:`,
                error instanceof Error ? error.message : String(error),
                error,
            )
        }

        return results
    },
    resolveResult: (response, _request, serializedKey) => {
        return response.get(serializedKey) ?? null
    },
    maxBatchSize: 50,
})

// ============================================================================
// BATCH FETCHER FOR TRACE SUMMARIES (root span + errored spans, flat)
// The chat transcript / result chips only need the root span (timing,
// cumulative metrics, ag.data) plus any errored span for the failure message.
// Fetching full trace trees for that pulled megabytes per transcript; this
// flat /spans/query fetches orders of magnitude less.
// ============================================================================

/** The flat spans a trace summary needs: the root span + errored spans. */
export interface TraceSummarySpans {
    rootSpan: TraceSpan | null
    errorSpans: TraceSpan[]
}

const traceSummaryBatchFetcher = createBatchFetcher<
    TraceRequest,
    TraceSummarySpans | null,
    Map<string, TraceSummarySpans | null>
>({
    serializeKey: ({projectId, traceId}) => `${projectId}:${canonicalTraceKey(traceId)}`,
    batchFn: async (requests, serializedKeys) => {
        const results = new Map<string, TraceSummarySpans | null>()
        serializedKeys.forEach((key) => results.set(key, null))

        // Exactly one project is in scope at a time in the web app.
        const projectId = requests[0]?.projectId
        if (!projectId) return results
        if (requests.some((req) => req.projectId !== projectId)) {
            throw new Error("traceSummaryBatchFetcher: requests span multiple projects")
        }

        const canonicalIds = [
            ...new Set(requests.map((req) => canonicalTraceKey(req.traceId)).filter(Boolean)),
        ]
        if (canonicalIds.length === 0) return results

        try {
            const filter = {
                operator: "and",
                conditions: [
                    {field: "trace_id", operator: "in", value: canonicalIds},
                    {
                        operator: "or",
                        conditions: [
                            // parent_id rejects existence operators; `is` + null → IS NULL.
                            {field: "parent_id", operator: "is", value: null},
                            {field: "status_code", operator: "is", value: "STATUS_CODE_ERROR"},
                        ],
                    },
                ],
            }

            const data = await fetchAllPreviewTraces(
                // Roots = one per trace; errored spans are rare. 500 leaves headroom
                // for pathological runs without approaching a full-tree payload.
                {size: 500, focus: "span", filter: JSON.stringify(filter)},
                "",
                projectId,
                // Transcript chrome, not user-initiated — yield to critical traffic.
                {lowPriority: true},
            )

            const byTrace = new Map<string, TraceSummarySpans>()
            if (isSpansResponse(data)) {
                // Spans are already schema-validated by fetchAllPreviewTraces.
                data.spans.forEach((span) => {
                    const key = canonicalTraceKey(span.trace_id)
                    let entry = byTrace.get(key)
                    if (!entry) {
                        entry = {rootSpan: null, errorSpans: []}
                        byTrace.set(key, entry)
                    }
                    if (!span.parent_id && !entry.rootSpan) entry.rootSpan = span
                    if (span.status_code === "STATUS_CODE_ERROR") entry.errorSpans.push(span)
                })
            }

            requests.forEach((req, idx) => {
                results.set(
                    serializedKeys[idx],
                    byTrace.get(canonicalTraceKey(req.traceId)) ?? null,
                )
            })
        } catch (error) {
            console.error(
                `[traceSummaryBatchFetcher] Failed to fetch trace summaries:`,
                error instanceof Error ? error.message : String(error),
                error,
            )
        }

        return results
    },
    resolveResult: (response, _request, serializedKey) => {
        return response.get(serializedKey) ?? null
    },
    maxBatchSize: 50,
    // Background hydration: wait for main-thread idle so boot-critical queries
    // win the race, and more concurrent turns coalesce into one batch.
    flushScheduling: "idle",
})

// ============================================================================
// CACHE REDIRECT - Check if span exists in cached data
// ============================================================================

/**
 * Recursively search for a span in nested trace data structures
 */
const findSpanInTraceData = (data: unknown, spanId: string): unknown | undefined => {
    if (!data || typeof data !== "object") return undefined

    const dataObj = data as Record<string, unknown>

    // Check if this object is the span we're looking for
    if (dataObj?.span_id === spanId) return data

    // Check traces object (from trace-entity responses)
    if (dataObj?.traces) {
        const traces = dataObj.traces as Record<string, Record<string, unknown>>
        for (const traceData of Object.values(traces)) {
            if (traceData?.spans) {
                const spans = traceData.spans as Record<string, unknown>
                for (const span of Object.values(spans)) {
                    const spanObj = span as Record<string, unknown>
                    if (spanObj?.span_id === spanId) return span
                }
            }
        }
    }

    // Check response.tree structure (from trace-drawer agenta format)
    if (dataObj?.response) {
        const response = dataObj.response as Record<string, unknown>
        if (response?.tree) {
            const found = findSpanInTree(response.tree, spanId)
            if (found) return found
        }
    }

    // Check spans array (from traces-list)
    if (Array.isArray(dataObj?.spans)) {
        const spans = dataObj.spans as Record<string, unknown>[]
        const found = spans.find((s) => s?.span_id === spanId)
        if (found) return found
    }

    return undefined
}

/**
 * Recursively search a tree structure for a span
 */
const findSpanInTree = (node: unknown, spanId: string): unknown | undefined => {
    if (!node) return undefined

    // Check array of nodes
    if (Array.isArray(node)) {
        for (const child of node) {
            const found = findSpanInTree(child, spanId)
            if (found) return found
        }
        return undefined
    }

    const nodeObj = node as Record<string, unknown>

    // Check if this node is the span
    if (nodeObj?.span_id === spanId) return node

    // Check children
    if (nodeObj?.children) {
        return findSpanInTree(nodeObj.children, spanId)
    }

    // Check nodes (for tree structures)
    if (nodeObj?.nodes) {
        return findSpanInTree(nodeObj.nodes, spanId)
    }

    return undefined
}

/**
 * Look up a span in various caches
 * Checks: traces-list, trace-drawer, trace-entity caches
 */
const findSpanInCache = (
    queryClient: import("@tanstack/react-query").QueryClient,
    spanId: string,
): TraceSpan | undefined => {
    // Check all potentially relevant TanStack Query caches
    const cacheKeys = [["traces-list"], ["trace-drawer"], ["trace-entity"]]

    for (const keyPrefix of cacheKeys) {
        const queries = queryClient.getQueriesData({queryKey: keyPrefix})

        for (const [_queryKey, data] of queries) {
            const found = findSpanInTraceData(data, spanId)
            if (found) {
                try {
                    return traceSpanSchema.parse(found)
                } catch {
                    // Invalid span data, continue searching
                    continue
                }
            }
        }
    }

    return undefined
}

// ============================================================================
// CUSTOM ERROR CLASSES
// ============================================================================

/**
 * Custom error for span not found - triggers retry
 */
export class SpanNotFoundError extends Error {
    constructor(spanId: string) {
        super(`Span ${spanId} not found - may not be ingested yet`)
        this.name = "SpanNotFoundError"
    }
}

/**
 * Custom error for trace not found - triggers retry
 */
export class TraceNotFoundError extends Error {
    constructor(traceId: string) {
        super(`Trace ${traceId} not found - may not be ingested yet`)
        this.name = "TraceNotFoundError"
    }
}

// ============================================================================
// SPAN QUERY ATOM FAMILY
// Fetches a single span by ID - uses batch fetcher + cache redirect
// ============================================================================

/**
 * Query atom family for fetching a single span
 *
 * Cache redirect strategy:
 * 1. Check various query caches (traces-list, trace-drawer, trace-entity)
 * 2. If found, use as initialData (no fetch needed)
 * 3. If not found, use batch fetcher to combine concurrent requests
 *
 * Retry strategy:
 * - If span is not found (null result), throws SpanNotFoundError to trigger retry
 * - Retries up to 3 times with exponential backoff (1s, 2s, 4s)
 * - This handles the case where span hasn't been ingested yet
 *
 * This provides the "server state" for each span entity.
 */
export const spanQueryAtomFamily = instrumentedAtomFamily(
    (spanId: string) =>
        atomWithQuery((get) => {
            const projectId = get(projectIdAtom)
            const queryClient = get(queryClientAtom)

            // Try to find in any cached trace data
            const cachedData = spanId ? findSpanInCache(queryClient, spanId) : undefined

            return {
                queryKey: ["span", projectId, spanId],
                queryFn: async (): Promise<TraceSpan | null> => {
                    if (!projectId || !spanId) return null
                    const result = await spanBatchFetcher({projectId, spanId})
                    // Throw if not found - triggers retry (span may not be ingested yet)
                    if (!result) {
                        throw new SpanNotFoundError(spanId)
                    }
                    return result
                },
                // Use cached data as initial data - prevents fetch if already in cache
                initialData: cachedData ?? undefined,
                // Always fetch if we have projectId and spanId (cache redirect handles deduplication)
                enabled: Boolean(get(sessionAtom) && projectId && spanId),
                staleTime: 60_000, // 1 minute
                gcTime: 5 * 60_000, // 5 minutes
                // Retry configuration for spans not yet ingested
                retry: (failureCount, error) => {
                    // Only retry SpanNotFoundError, not other errors
                    if (error instanceof SpanNotFoundError && failureCount < 3) {
                        return true
                    }
                    return false
                },
                retryDelay: (attemptIndex) => Math.min(1000 * 2 ** attemptIndex, 8000), // 1s, 2s, 4s
            }
        }),
    {name: "trace.spanQueryAtomFamily"},
)

// ============================================================================
// DRAFT STATE MANAGEMENT
// Uses shared factory for draft state with trace-specific configuration
// ============================================================================

/**
 * Type for trace span attributes (the draftable portion)
 */
type TraceSpanAttributes = TraceSpan["attributes"]

/**
 * Create draft state management for trace spans
 * Uses shared factory with trace-specific configuration
 */
const traceSpanDraftState = createEntityDraftState<TraceSpan, TraceSpanAttributes>({
    // Extract server data from query atom (single source of truth)
    entityAtomFamily: (spanId: string) => {
        const queryAtom = spanQueryAtomFamily(spanId)
        return atom((get) => get(queryAtom).data ?? null)
    },

    // Only attributes are draftable (rest of span metadata is read-only)
    getDraftableData: (span) => span.attributes || {},

    // Merge draft attributes back into span
    mergeDraft: (span, draftAttrs) => ({
        ...span,
        attributes: {...span.attributes, ...draftAttrs},
    }),

    // Custom dirty detection: compare normalized attributes
    isDirty: (currentAttrs, originalAttrs) => {
        const normalizedCurrent = normalizeValueForComparison(currentAttrs)
        const normalizedOriginal = normalizeValueForComparison(originalAttrs)
        return normalizedCurrent !== normalizedOriginal
    },
})

// Export draft atoms
export const traceSpanDraftAtomFamily = traceSpanDraftState.draftAtomFamily
export const traceSpanHasDraftAtomFamily = traceSpanDraftState.hasDraftAtomFamily
export const traceSpanIsDirtyAtomFamily = traceSpanDraftState.isDirtyAtomFamily
export const discardTraceSpanDraftAtom = traceSpanDraftState.discardDraftAtom
export const updateTraceSpanAtom = traceSpanDraftState.updateAtom

// ============================================================================
// COMBINED ENTITY ATOM FAMILY
// Returns draft if exists, otherwise server state
// This is the primary atom for UI rendering
// ============================================================================

/**
 * Combined entity atom: returns draft if exists, otherwise server data
 * This is the main read atom for trace span data in UI components
 *
 * Equivalent to testcaseEntityAtomFamily pattern
 */
export const traceSpanEntityAtomFamily = instrumentedAtomFamily(
    (spanId: string) =>
        atom((get): TraceSpan | null => {
            // Use query atom directly as single source of truth for server data
            const queryState = get(spanQueryAtomFamily(spanId))
            const serverState = queryState.data ?? null
            const draftAttrs = get(traceSpanDraftAtomFamily(spanId))

            if (draftAttrs && serverState) {
                // Merge draft attributes into server state
                return {
                    ...serverState,
                    attributes: {...serverState.attributes, ...draftAttrs},
                }
            }

            // Return server state (or null if not loaded)
            return serverState
        }),
    {name: "trace.traceSpanEntityAtomFamily"},
)

// ============================================================================
// DERIVED ATOM FAMILIES FOR SPAN DATA EXTRACTION
// ============================================================================

/**
 * Atom family to extract inputs from a span by ID
 * Usage: const inputs = useAtomValue(spanInputsAtomFamily(spanId))
 */
export const spanInputsAtomFamily = instrumentedAtomFamily(
    (spanId: string) =>
        atom((get) => {
            const span = get(traceSpanEntityAtomFamily(spanId))
            return extractInputs(span)
        }),
    {name: "trace.spanInputsAtomFamily"},
)

/**
 * Atom family to extract outputs from a span by ID
 * Usage: const outputs = useAtomValue(spanOutputsAtomFamily(spanId))
 */
export const spanOutputsAtomFamily = instrumentedAtomFamily(
    (spanId: string) =>
        atom((get) => {
            const span = get(traceSpanEntityAtomFamily(spanId))
            return extractOutputs(span)
        }),
    {name: "trace.spanOutputsAtomFamily"},
)

/**
 * Atom family to extract all ag.data from a span by ID
 * Usage: const agData = useAtomValue(spanAgDataAtomFamily(spanId))
 */
export const spanAgDataAtomFamily = instrumentedAtomFamily(
    (spanId: string) =>
        atom((get) => {
            const span = get(traceSpanEntityAtomFamily(spanId))
            return extractAgData(span)
        }),
    {name: "trace.spanAgDataAtomFamily"},
)

// ============================================================================
// TRACE ENTITY ATOM FAMILY (fetches and caches trace by traceId)
// ============================================================================

/**
 * Atom family that fetches trace data by traceId
 *
 * Cache population strategy:
 * 1. Fetches the trace tree from the server (batched with other concurrent requests)
 * 2. Extracts all spans from the response
 * 3. Populates the span query cache for each span (for O(1) lookup later)
 * 4. Returns the trace response for rendering
 *
 * This provides entity-based access to trace data with automatic span cache population.
 * Uses batch fetching to combine multiple concurrent trace requests into a single API call.
 * Usage: const traceQuery = useAtomValue(traceEntityAtomFamily(traceId))
 */
export const traceEntityAtomFamily = instrumentedAtomFamily(
    (traceId: string | null) =>
        atomWithQuery((get) => {
            const projectId = get(projectIdAtom)
            const queryClient = get(queryClientAtom)

            return {
                queryKey: ["trace-entity", projectId, traceId ?? "none"],
                enabled: Boolean(get(sessionAtom) && traceId && projectId),
                // Traces are immutable once ingested — never refetch a found one.
                // invalidateTraceEntityCache still forces a refresh after runs.
                staleTime: Infinity,
                gcTime: 5 * 60_000,
                refetchOnWindowFocus: false,
                retryOnMount: false,
                structuralSharing: true,
                queryFn: async () => {
                    if (!traceId || !projectId) return null

                    // Use batch fetcher to combine concurrent trace requests
                    // Returns the same format as fetchPreviewTrace: { traces: { [traceId]: { spans: {...} } } }
                    const response = await traceBatchFetcher({projectId, traceId})

                    // Throw if not found - triggers retry (trace may not be ingested yet)
                    if (
                        !response ||
                        !response.traces ||
                        Object.keys(response.traces).length === 0
                    ) {
                        throw new TraceNotFoundError(traceId)
                    }

                    // Extract all spans from the trace response and populate query cache
                    Object.values(response.traces).forEach((traceEntry) => {
                        if (traceEntry?.spans) {
                            Object.values(traceEntry.spans).forEach((spanData) => {
                                const span = traceSpanSchema.safeParse(spanData)
                                if (span.success) {
                                    const queryKey = ["span", projectId, span.data.span_id]
                                    queryClient.setQueryData(queryKey, span.data)
                                }
                            })
                        }
                    })

                    return response
                },
                // Retry configuration for traces not yet ingested
                retry: traceNotFoundRetry(traceId),
                retryDelay: (attemptIndex) => Math.min(1000 * 2 ** attemptIndex, 10000), // 1s, 2s, 4s, 8s, 10s
            }
        }),
    {name: "trace.traceEntityAtomFamily"},
)

// ============================================================================
// TRACE SUMMARY QUERY ATOM FAMILY (root span + errored spans, flat)
// ============================================================================

/**
 * Lightweight per-trace summary query: the root span (timing, cumulative
 * metrics, ag.data) plus errored spans (run-failure message). Backed by a
 * flat /spans/query, batched across concurrent traces — use this instead of
 * `traceEntityAtomFamily` when the full span tree isn't needed (transcript
 * rows, result chips). The full tree stays an on-demand fetch (trace drawer).
 *
 * Usage: const summary = useAtomValue(traceSummaryQueryAtomFamily(traceId))
 */
export const traceSummaryQueryAtomFamily = instrumentedAtomFamily(
    (traceId: string | null) =>
        atomWithQuery<TraceSummarySpans | null>((get) => {
            const projectId = get(projectIdAtom)

            return {
                queryKey: ["trace-summary", projectId, traceId ?? "none"],
                enabled: Boolean(get(sessionAtom) && traceId && projectId),
                // Class A persistence: reloads restore summaries from IDB, no refetch.
                persister: immutablePersister.persisterFn<TraceSummarySpans | null, QueryKey>,
                // Immutable once ingested; invalidateTraceEntityCache covers reruns.
                staleTime: Infinity,
                gcTime: 5 * 60_000,
                refetchOnWindowFocus: false,
                retryOnMount: false,
                queryFn: async (): Promise<TraceSummarySpans | null> => {
                    if (!traceId || !projectId) return null
                    const result = await traceSummaryBatchFetcher({projectId, traceId})
                    // Throw if not found - triggers retry (trace may not be ingested yet)
                    if (!result || (!result.rootSpan && result.errorSpans.length === 0)) {
                        throw new TraceNotFoundError(traceId)
                    }
                    return result
                },
                retry: traceNotFoundRetry(traceId),
                retryDelay: (attemptIndex: number) => Math.min(1000 * 2 ** attemptIndex, 10000),
            }
        }),
    {name: "trace.traceSummaryQueryAtomFamily"},
)

// ============================================================================
// DERIVED ATOM FAMILIES FOR TRACE-LEVEL DATA EXTRACTION
// Convenience selectors: traceId → rootSpan / inputs / outputs
// ============================================================================

/**
 * Find the root span (no parent) from a TracesApiResponse.
 * Handles both dash and no-dash trace ID formats.
 */
const findRootSpanFromResponse = (
    data: TracesApiResponse | null | undefined,
    traceId: string,
): TraceSpan | null => {
    if (!data?.traces) return null

    const traceIdNoDashes = traceId.replace(/-/g, "")
    const traceEntry = data.traces[traceIdNoDashes] ?? data.traces[traceId]
    if (!traceEntry?.spans) return null

    const spans = Object.values(traceEntry.spans)
    // Root span: no parent_span_id
    const root = spans.find((s) => {
        const parsed = traceSpanSchema.safeParse(s)
        return parsed.success && !parsed.data.parent_id
    })

    if (root) {
        const parsed = traceSpanSchema.safeParse(root)
        return parsed.success ? parsed.data : null
    }

    // Fallback: first span if no explicit root found
    if (spans.length > 0) {
        const parsed = traceSpanSchema.safeParse(spans[0])
        return parsed.success ? parsed.data : null
    }

    return null
}

/**
 * Atom family to get the root span of a trace by traceId.
 * Derives from traceEntityAtomFamily — no extra fetch.
 *
 * Usage: const rootSpan = useAtomValue(traceRootSpanAtomFamily(traceId))
 */
export const traceRootSpanAtomFamily = instrumentedAtomFamily(
    (traceId: string | null) =>
        atom((get): TraceSpan | null => {
            if (!traceId) return null
            const traceQuery = get(traceEntityAtomFamily(traceId))
            return findRootSpanFromResponse(traceQuery.data, traceId)
        }),
    {name: "trace.traceRootSpanAtomFamily"},
)

/**
 * Atom family to extract inputs from the root span of a trace.
 *
 * Usage: const inputs = useAtomValue(traceInputsAtomFamily(traceId))
 */
export const traceInputsAtomFamily = instrumentedAtomFamily(
    (traceId: string | null) =>
        atom((get) => {
            const rootSpan = get(traceRootSpanAtomFamily(traceId))
            return extractInputs(rootSpan)
        }),
    {name: "trace.traceInputsAtomFamily"},
)

/**
 * Atom family to extract outputs from the root span of a trace.
 *
 * Usage: const outputs = useAtomValue(traceOutputsAtomFamily(traceId))
 */
export const traceOutputsAtomFamily = instrumentedAtomFamily(
    (traceId: string | null) =>
        atom((get) => {
            const rootSpan = get(traceRootSpanAtomFamily(traceId))
            return extractOutputs(rootSpan)
        }),
    {name: "trace.traceOutputsAtomFamily"},
)
