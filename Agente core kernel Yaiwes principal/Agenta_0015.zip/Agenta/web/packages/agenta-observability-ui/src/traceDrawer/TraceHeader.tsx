import {useCallback, useEffect, useMemo, useState} from "react"

import {
    fetchAllPreviewTraces,
    isSpansResponse,
    isTracesResponse,
    transformTracesResponseToTree,
    transformTracingResponse,
} from "@agenta/entities/trace"
import type {TraceSpanNode} from "@agenta/observability"
import {buildTraceUrlParams as buildTraceQueryParams} from "@agenta/observability"
import {observabilityScopeAtom, useObservability} from "@agenta/observability"
import {
    setTraceDrawerTraceAtom,
    traceDrawerBackTargetAtom,
    traceDrawerIsLinkedViewAtom,
} from "@agenta/observability/traceDrawer"
import {
    getNodeTimestamp,
    getSpanIdFromNode,
    getTraceIdFromNode,
    toISOString,
} from "@agenta/observability/traceDrawer"
import {projectIdAtom} from "@agenta/shared/state"
import {EnhancedButton, Tag} from "@agenta/ui/components/presentational"
import {CopyTooltip as TooltipWithCopyAction} from "@agenta/ui/copy-tooltip"
import {ArrowLeft, CaretDown, CaretUp} from "@phosphor-icons/react"
import {useAtomValue, useSetAtom} from "jotai"
import dynamic from "next/dynamic"

import type {NavSource, NavState, TraceHeaderProps} from "./traceHeaderTypes"

const AddToQueuePopover = dynamic(
    () => import("@agenta/annotation-ui/add-to-queue").then((m) => m.default),
    {ssr: false},
)

const TraceHeader = ({
    activeTrace: propActiveTrace,
    traces: drawerTraces,
    activeTraceId,
    traceId,
    traceTabs,
    filters,
    sort,
    limit,
    setSelectedTraceId,
    setSelectedNode,
    setTraceParam,
    setSpanParam,
    setTraceDrawerTrace,
    activeTraceIndex: _activeTraceIndex,
    setSelected,
}: TraceHeaderProps) => {
    const {traces: tableTracesRaw, hasMoreTraces, fetchMoreTraces} = useObservability()
    // `selectedAppIdAtom` in the app; the package reads the same value through its host seam.
    const appId = useAtomValue(observabilityScopeAtom).appId
    const projectId = useAtomValue(projectIdAtom)
    const backTarget = useAtomValue(traceDrawerBackTargetAtom)
    const isLinkedView = useAtomValue(traceDrawerIsLinkedViewAtom)
    const internalSetTraceDrawerTrace = useSetAtom(setTraceDrawerTraceAtom)

    const tableTraces = useMemo(() => tableTracesRaw as TraceSpanNode[], [tableTracesRaw])

    const focusMode: "trace" | "span" = traceTabs === "trace" ? "trace" : "span"

    const activeTrace = useMemo(() => {
        if (propActiveTrace) return propActiveTrace
        if (!Array.isArray(drawerTraces)) return undefined
        return (drawerTraces as TraceSpanNode[]).find(
            (node) => getSpanIdFromNode(node) === activeTraceId,
        )
    }, [propActiveTrace, drawerTraces, activeTraceId])

    const activeSpanKey = useMemo(() => {
        return getSpanIdFromNode(activeTrace) || activeTraceId || null
    }, [activeTrace, activeTraceId])

    const activeTraceKey = useMemo(() => {
        return getTraceIdFromNode(activeTrace) || traceId || null
    }, [activeTrace, traceId])

    const activeFocusKey = focusMode === "span" ? activeSpanKey : activeTraceKey

    const activeTimestampIso = useMemo(
        () => toISOString(getNodeTimestamp(activeTrace)),
        [activeTrace],
    )

    const filtersKey = useMemo(() => JSON.stringify(filters ?? []), [filters])
    const sortKey = useMemo(() => JSON.stringify(sort ?? {}), [sort])

    const baseParams = useMemo(
        () =>
            buildTraceQueryParams({
                focus: traceTabs,
                filters,
                sort,
                limit,
            }),
        [traceTabs, filtersKey, sortKey, limit],
    )

    const requestSize = useMemo(() => {
        if (!limit || Number.isNaN(limit)) return 5
        return Math.max(1, Math.min(limit, 10))
    }, [limit])

    const tableSpanKeySet = useMemo(() => {
        const set = new Set<string>()
        tableTraces.forEach((item) => {
            const key = getSpanIdFromNode(item)
            if (key) set.add(key)
        })
        return set
    }, [tableTraces])

    const tableTraceKeySet = useMemo(() => {
        const set = new Set<string>()
        tableTraces.forEach((item) => {
            const key = getTraceIdFromNode(item)
            if (key) set.add(key)
        })
        return set
    }, [tableTraces])

    const tableIndex = useMemo(() => {
        if (!activeFocusKey) return -1
        return tableTraces.findIndex((item) => {
            const key = focusMode === "span" ? getSpanIdFromNode(item) : getTraceIdFromNode(item)
            return key === activeFocusKey
        })
    }, [tableTraces, focusMode, activeFocusKey])

    const prevFromTable =
        tableIndex > 0 && tableIndex < tableTraces.length
            ? (tableTraces[tableIndex - 1] as TraceSpanNode)
            : null

    const nextFromTable =
        tableIndex >= 0 && tableIndex < tableTraces.length - 1
            ? (tableTraces[tableIndex + 1] as TraceSpanNode)
            : null

    const [prevNav, setPrevNav] = useState<NavState>({
        candidate: null,
        loading: false,
        source: null,
    })
    const [nextNav, setNextNav] = useState<NavState>({
        candidate: null,
        loading: false,
        source: null,
    })

    const fetchRelativeTrace = useCallback(
        async (direction: "prev" | "next"): Promise<TraceSpanNode | null> => {
            if (!appId || !activeTimestampIso || !activeFocusKey) {
                console.debug("[TraceNav] skip fetch – missing context", {
                    direction,
                    appId,
                    activeTimestampIso,
                    activeFocusKey,
                })
                return null
            }

            console.debug("[TraceNav] fetchRelative:start", {
                direction,
                focusMode,
                activeTimestampIso,
                activeFocusKey,
            })

            const params: Record<string, unknown> = {...baseParams, size: requestSize}

            if (direction === "next") {
                params.newest = activeTimestampIso
                if (baseParams.oldest) params.oldest = baseParams.oldest
            } else {
                params.oldest = activeTimestampIso
                if (baseParams.newest) params.newest = baseParams.newest
            }

            try {
                const response = (await fetchAllPreviewTraces(params, appId, projectId ?? "")) as {
                    traces?: unknown
                    spans?: unknown
                }

                console.debug("[TraceNav] fetchRelative:response", {
                    direction,
                    hasTraces: Boolean(response?.traces),
                    hasSpans: Boolean(response?.spans),
                })
                let candidates: TraceSpanNode[] = []

                // entities-package TraceSpanNode is the same backend span shape as the
                // OSS type; align the annotation at the boundary, no data is converted.
                if (isTracesResponse(response)) {
                    candidates = transformTracingResponse(
                        transformTracesResponseToTree(response),
                    ) as unknown as TraceSpanNode[]
                } else if (isSpansResponse(response)) {
                    candidates = transformTracingResponse(
                        response.spans,
                    ) as unknown as TraceSpanNode[]
                } else if (Array.isArray(response?.spans)) {
                    candidates = transformTracingResponse(
                        response.spans,
                    ) as unknown as TraceSpanNode[]
                }

                if (!candidates.length) return null

                const focusKeyGetter =
                    focusMode === "trace" ? getTraceIdFromNode : getSpanIdFromNode

                const filtered = candidates.filter((item) => {
                    const candidateKey = focusKeyGetter(item)
                    if (!candidateKey || candidateKey === activeFocusKey) return false
                    if (focusMode === "trace") {
                        if (tableTraceKeySet.has(candidateKey)) return false
                    } else if (tableSpanKeySet.has(candidateKey)) {
                        return false
                    }
                    return true
                })

                console.debug("[TraceNav] fetchRelative:filtered", {
                    direction,
                    total: candidates.length,
                    filtered: filtered.length,
                    firstSpan: filtered[0]?.span_id,
                    firstTrace: filtered[0]?.trace_id,
                })

                if (!filtered.length) {
                    console.debug("[TraceNav] no filtered candidates", {direction})
                    return null
                }

                return filtered[0]
            } catch (error) {
                console.error("Trace navigation fetch failed", error)
                return null
            }
        },
        [
            appId,
            activeTimestampIso,
            activeFocusKey,
            baseParams,
            focusMode,
            requestSize,
            tableSpanKeySet,
            tableTraceKeySet,
        ],
    )

    useEffect(() => {
        if (prevFromTable) {
            console.debug("[TraceNav] prev candidate from table", {
                spanId: getSpanIdFromNode(prevFromTable),
                traceId: getTraceIdFromNode(prevFromTable),
            })
            setPrevNav({candidate: prevFromTable, loading: false, source: "table"})
            return
        }

        if (!activeTimestampIso || !appId || !activeFocusKey) {
            console.debug("[TraceNav] prev disabled – missing context")
            setPrevNav({candidate: null, loading: false, source: null})
            return
        }

        let cancelled = false
        setPrevNav({candidate: null, loading: true, source: null})

        fetchRelativeTrace("prev").then((result) => {
            if (cancelled) return
            console.debug("[TraceNav] prev fetch result", {
                spanId: getSpanIdFromNode(result),
                traceId: getTraceIdFromNode(result),
            })
            setPrevNav({candidate: result, loading: false, source: result ? "remote" : null})
        })

        return () => {
            cancelled = true
        }
    }, [prevFromTable, fetchRelativeTrace, activeTimestampIso, appId, activeFocusKey])

    useEffect(() => {
        if (nextFromTable) {
            console.debug("[TraceNav] next candidate from table", {
                spanId: getSpanIdFromNode(nextFromTable),
                traceId: getTraceIdFromNode(nextFromTable),
            })
            setNextNav({candidate: nextFromTable, loading: false, source: "table"})
            return
        }

        if (!activeTimestampIso || !appId || !activeFocusKey) {
            console.debug("[TraceNav] next disabled – missing context")
            setNextNav({candidate: null, loading: false, source: null})
            return
        }

        if (tableIndex >= 0 && !hasMoreTraces) {
            console.debug("[TraceNav] next disabled – end of results")
            setNextNav({candidate: null, loading: false, source: null})
            return
        }

        let cancelled = false
        setNextNav({candidate: null, loading: true, source: null})

        fetchRelativeTrace("next").then((result) => {
            if (cancelled) return
            console.debug("[TraceNav] next fetch result", {
                spanId: getSpanIdFromNode(result),
                traceId: getTraceIdFromNode(result),
            })
            setNextNav({candidate: result, loading: false, source: result ? "remote" : null})
        })

        return () => {
            cancelled = true
        }
    }, [
        nextFromTable,
        fetchRelativeTrace,
        activeTimestampIso,
        appId,
        activeFocusKey,
        hasMoreTraces,
        tableIndex,
    ])

    const navigateToTarget = useCallback(
        (target: TraceSpanNode | null, source: NavSource | null) => {
            if (!target) return

            const targetTraceId = getTraceIdFromNode(target)
            const targetSpanId = getSpanIdFromNode(target)

            console.debug("[TraceNav] navigate", {
                source,
                focusMode,
                targetTraceId,
                targetSpanId,
            })

            setTraceParam(targetTraceId ?? undefined)

            if (targetTraceId) {
                setTraceDrawerTrace({traceId: targetTraceId, activeSpanId: targetSpanId ?? null})
            }

            if (source === "table") {
                const selectionKey =
                    focusMode === "span"
                        ? (targetSpanId ?? targetTraceId ?? undefined)
                        : (targetTraceId ?? targetSpanId ?? undefined)

                if (selectionKey) {
                    console.debug("[TraceNav] setSelectedTraceId", selectionKey)
                    setSelectedTraceId(selectionKey)
                }
            }

            if (targetSpanId) {
                console.debug("[TraceNav] setSelectedNode", targetSpanId)
                setSelectedNode?.(targetSpanId)
                setSelected?.(targetSpanId)
            } else {
                console.debug("[TraceNav] clear SelectedNode")
                setSelectedNode?.("")
                setSelected?.("")
            }

            if (focusMode === "span") {
                console.debug("[TraceNav] setSpanParam", targetSpanId)
                setSpanParam(targetSpanId ?? undefined)
            } else {
                console.debug("[TraceNav] clear span param")
                setSpanParam(undefined)
            }
        },
        [
            focusMode,
            setSelectedTraceId,
            setSelectedNode,
            setSelected,
            setTraceParam,
            setSpanParam,
            setTraceDrawerTrace,
        ],
    )

    const handlePrevTrace = useCallback(() => {
        if (prevNav.loading || !prevNav.candidate) return
        console.debug("[TraceNav] handlePrev", {
            source: prevNav.source,
            spanId: getSpanIdFromNode(prevNav.candidate),
            traceId: getTraceIdFromNode(prevNav.candidate),
        })
        navigateToTarget(prevNav.candidate, prevNav.source)
    }, [prevNav, navigateToTarget])

    const handleNextTrace = useCallback(async () => {
        if (nextNav.loading || !nextNav.candidate) return

        console.debug("[TraceNav] handleNext", {
            source: nextNav.source,
            spanId: getSpanIdFromNode(nextNav.candidate),
            traceId: getTraceIdFromNode(nextNav.candidate),
        })

        if (nextNav.source === "remote" && hasMoreTraces) {
            try {
                console.debug("[TraceNav] fetchMoreTraces before navigating")
                await fetchMoreTraces()
            } catch (error) {
                console.error("Failed to fetch additional traces", error)
            }
        }

        navigateToTarget(nextNav.candidate, nextNav.source)
    }, [nextNav, hasMoreTraces, fetchMoreTraces, navigateToTarget])

    const isPrevDisabled = prevNav.loading || !prevNav.candidate || !activeFocusKey
    const isNextDisabled = nextNav.loading || !nextNav.candidate || !activeFocusKey

    const handleBackToOrigin = useCallback(() => {
        if (!backTarget) return

        internalSetTraceDrawerTrace({source: "back"})

        setTraceParam(backTarget.traceId ?? undefined)
        setSelectedTraceId(backTarget.traceId)

        if (backTarget.spanId) {
            setSelectedNode?.(backTarget.spanId)
            setSelected?.(backTarget.spanId)
        } else {
            setSelectedNode?.("")
            setSelected?.("")
        }

        if (traceTabs === "span") {
            setSpanParam(backTarget.spanId ?? undefined)
        } else {
            setSpanParam(undefined)
        }
    }, [
        backTarget,
        internalSetTraceDrawerTrace,
        setSelectedTraceId,
        setSelectedNode,
        setSelected,
        setTraceParam,
        setSpanParam,
        traceTabs,
    ])

    const displayTrace = propActiveTrace || drawerTraces?.[0]
    const displayTraceId = getTraceIdFromNode(displayTrace) || ""

    return (
        <>
            <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                    {backTarget && (
                        <EnhancedButton
                            type="default"
                            size="small"
                            onClick={handleBackToOrigin}
                            icon={<ArrowLeft size={14} />}
                        />
                    )}
                    {!isLinkedView && (
                        <div>
                            <EnhancedButton
                                onClick={handlePrevTrace}
                                type="text"
                                disabled={isPrevDisabled}
                                icon={<CaretUp size={16} />}
                            />
                            <EnhancedButton
                                onClick={handleNextTrace}
                                type="text"
                                disabled={isNextDisabled}
                                icon={<CaretDown size={16} />}
                            />
                        </div>
                    )}

                    <span className="text-sm font-medium">Trace</span>
                    <TooltipWithCopyAction copyText={displayTraceId} title="Copy trace id">
                        <Tag
                            className="font-mono bg-[var(--ag-c-0517290F)]"
                            label={`# ${displayTraceId || "-"}`}
                        />
                    </TooltipWithCopyAction>
                </div>
                <AddToQueuePopover
                    itemType="traces"
                    itemIds={activeTraceKey ? [activeTraceKey] : []}
                    disabled={!activeTraceKey}
                >
                    <EnhancedButton size="small" disabled={!activeTraceKey}>
                        Add annotation queue
                    </EnhancedButton>
                </AddToQueuePopover>
            </div>
        </>
    )
}

export default TraceHeader
