/* Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.flowable.spring.test.executionListener;

import org.flowable.common.engine.api.FlowableException;
import org.flowable.common.engine.api.delegate.Expression;
import org.flowable.engine.delegate.DelegateExecution;
import org.flowable.engine.delegate.JavaDelegate;

/**
 * @author Yvo Swillens
 */
public class ConditionalThrowExceptionDelegate implements JavaDelegate {

    private Expression injectedVar;

    @Override
    public void execute(DelegateExecution execution) {
        Object throwException = execution.getVariable(execution.getCurrentActivityId());

        if (throwException != null && (boolean) throwException) {
            throw new FlowableException("throwException was true");
        }

        if (injectedVar != null && injectedVar.getValue(execution) != null) {
            execution.setVariable("injectedExecutionVariable", injectedVar.getValue(execution));
        }
    }
}
