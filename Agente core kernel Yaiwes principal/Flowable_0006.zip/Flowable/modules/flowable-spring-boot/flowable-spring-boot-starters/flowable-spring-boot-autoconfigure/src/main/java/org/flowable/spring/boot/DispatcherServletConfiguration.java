/* Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.flowable.spring.boot;

import org.flowable.common.rest.exception.BaseExceptionHandlerAdvice;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.converter.HttpMessageConverters;
import org.springframework.http.converter.json.JacksonJsonHttpMessageConverter;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurationSupport;

import tools.jackson.databind.json.JsonMapper;

/**
 * Base dispatcher configuration that can be used to configure context for the REST API.
 */
@Configuration(proxyBeanMethods = false)
@ComponentScan(basePackageClasses = BaseExceptionHandlerAdvice.class)
@ConditionalOnClass(WebMvcConfigurationSupport.class)
@EnableAsync
public class DispatcherServletConfiguration extends WebMvcConfigurationSupport {

    @Autowired
    protected JsonMapper jsonMapper;

    @Override
    protected void configureMessageConverters(HttpMessageConverters.ServerBuilder builder) {
        builder.withJsonConverter(new JacksonJsonHttpMessageConverter(jsonMapper));
    }
}
