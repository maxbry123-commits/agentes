import { BindLogic, BuiltLogic, LogicWrapper, useActions, useValues } from 'kea'
import { useMemo } from 'react'

import { useOnMountEffect } from 'lib/hooks/useOnMountEffect'
import { useAttachedLogic } from 'lib/logic/scenes/useAttachedLogic'
import { eventUsageLogic } from 'lib/utils/eventUsageLogic'
import { Notebook } from 'scenes/notebooks/Notebook/Notebook'
import { NotebookLogicProps, notebookLogic } from 'scenes/notebooks/Notebook/notebookLogic'

import { AnyPropertyFilter, CustomerProfileScope, PersonType, PropertyFilterType, PropertyOperator } from '~/types'

import { CustomerProfileMenu } from 'products/customer_analytics/frontend/components/CustomerProfileMenu'
import { customerProfileLogic } from 'products/customer_analytics/frontend/customerProfileLogic'

type PersonProfileCanvasProps = {
    person: PersonType
    attachTo: BuiltLogic | LogicWrapper
}

const PersonProfileCanvas = ({ person, attachTo }: PersonProfileCanvasProps): JSX.Element | null => {
    const id = person.id
    const shortId = `canvas-${id}`
    const mode = 'canvas'
    const { reportPersonProfileViewed } = useActions(eventUsageLogic)

    const attrs = useMemo(
        () => ({
            personId: id,
            distinctIds: person.distinct_ids,
        }),
        [id, person.distinct_ids]
    )
    const customerProfileLogicProps = useMemo(
        () => ({
            attrs,
            scope: CustomerProfileScope.PERSON,
            key: `person-${id}`,
            canvasShortId: shortId,
        }),
        [attrs, id, shortId]
    )
    const { content } = useValues(customerProfileLogic(customerProfileLogicProps))

    useOnMountEffect(() => {
        reportPersonProfileViewed()
    })
    const notebookLogicProps: NotebookLogicProps = useMemo(() => {
        const personFilter: AnyPropertyFilter[] = [
            {
                type: PropertyFilterType.EventMetadata,
                key: 'person_id',
                value: id,
                operator: PropertyOperator.Exact,
            },
        ]
        return {
            shortId,
            mode,
            canvasFiltersOverride: personFilter,
        }
    }, [id, shortId, mode])
    const mountedNotebookLogic = notebookLogic(notebookLogicProps)
    useAttachedLogic(mountedNotebookLogic, attachTo)

    return (
        <BindLogic logic={notebookLogic} props={notebookLogicProps}>
            <BindLogic logic={customerProfileLogic} props={customerProfileLogicProps}>
                <CustomerProfileMenu />
                <Notebook
                    editable={false}
                    shortId={shortId}
                    mode={mode}
                    className="NotebookProfileCanvas"
                    initialContent={{
                        type: 'doc',
                        content,
                    }}
                />
            </BindLogic>
        </BindLogic>
    )
}

export default PersonProfileCanvas
