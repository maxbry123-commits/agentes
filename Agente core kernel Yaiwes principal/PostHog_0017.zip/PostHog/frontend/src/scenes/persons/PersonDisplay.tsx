import './PersonDisplay.scss'

import clsx from 'clsx'
import { useValues } from 'kea'
import { router } from 'kea-router'
import React, { useMemo, useState } from 'react'

import { IconCopy } from '@posthog/icons'
import { LemonButton } from '@posthog/lemon-ui'

import { FEATURE_FLAGS } from 'lib/constants'
import { Link } from 'lib/lemon-ui/Link'
import { Popover } from 'lib/lemon-ui/Popover'
import { ProfilePicture, ProfilePictureProps } from 'lib/lemon-ui/ProfilePicture'
import { featureFlagLogic } from 'lib/logic/featureFlagLogic'
import { copyToClipboard } from 'lib/utils/copyToClipboard'
import { useNotebookNode } from 'scenes/notebooks/Nodes/NotebookNodeContext'

import { ComposeTicketButton } from 'products/conversations/frontend/components/ComposeTicket'

import { PersonPropType, asDisplay, asLink, getPersonColorIndex } from './person-utils'
import { PersonPreview } from './PersonPreview'

export interface PersonDisplayProps {
    person?: PersonPropType | null
    displayName?: string
    /** Max display name length before mid-ellipsis truncation. Passed to `asDisplay`. */
    maxLength?: number
    withIcon?: boolean | ProfilePictureProps['size']
    href?: string
    noLink?: boolean
    noEllipsis?: boolean
    noPopover?: boolean
    isCentered?: boolean
    children?: React.ReactChild
    withCopyButton?: boolean
    withCopyEmailButton?: boolean
    withComposeTicketButton?: boolean
    placement?: 'top' | 'bottom' | 'left' | 'right'
    inline?: boolean
    className?: string
    /** Use muted/secondary text color instead of default */
    muted?: boolean
}

export function PersonIcon({
    person,
    displayName,
    index,
    ...props
}: Pick<PersonDisplayProps, 'person'> &
    Omit<ProfilePictureProps, 'user' | 'name' | 'email'> & { displayName?: string }): JSX.Element {
    const display = displayName || asDisplay(person)

    const email: string | undefined = useMemo(() => {
        // The email property could be correct but it could also be set strangely such as an array or not even a string
        const possibleEmail = Array.isArray(person?.properties?.email)
            ? person?.properties?.email[0]
            : person?.properties?.email
        return typeof possibleEmail === 'string' ? possibleEmail : undefined
    }, [person?.properties?.email])

    // Generate a stable color index from the person's distinct_id (or display name) if not explicitly provided
    const identifier = person?.distinct_id || person?.distinct_ids?.[0] || displayName
    const colorIndex = useMemo(() => index ?? getPersonColorIndex(identifier), [index, identifier])

    return (
        <ProfilePicture
            {...props}
            index={colorIndex}
            user={{
                first_name: display,
                email,
            }}
        />
    )
}

export function PersonDisplay({
    person,
    displayName,
    maxLength,
    withIcon,
    noEllipsis,
    noPopover,
    noLink,
    isCentered,
    href = asLink(person),
    children,
    withCopyButton,
    withCopyEmailButton,
    withComposeTicketButton,
    placement,
    inline,
    className,
    muted,
}: PersonDisplayProps): JSX.Element {
    const display = displayName || asDisplay(person, maxLength)
    const [visible, setVisible] = useState(false)
    const { featureFlags } = useValues(featureFlagLogic)

    const notebookNode = useNotebookNode()

    const showComposeButton = !!withComposeTicketButton && !!featureFlags[FEATURE_FLAGS.PRODUCT_SUPPORT_CREATE_TICKET]
    const personDistinctId = person?.distinct_id || person?.distinct_ids?.[0]
    const personEmail = typeof person?.properties?.email === 'string' ? person.properties.email : undefined

    const handleClick = (e: React.MouseEvent): void => {
        if (visible && href && !noLink && person?.properties) {
            router.actions.push(href)
        } else if (visible && !person?.properties) {
            e.preventDefault()
        } else {
            setVisible(true)
        }
        return
    }

    let content = children || (
        <span className={clsx(!inline && 'flex items-center', isCentered && 'justify-center', 'group/person')}>
            {withIcon && (
                <PersonIcon
                    displayName={displayName}
                    person={person}
                    size={typeof withIcon === 'string' ? withIcon : 'md'}
                />
            )}
            <span className={clsx('ph-no-capture', !noEllipsis && 'truncate')}>{display}</span>
            {withCopyEmailButton && personEmail && (
                <span
                    className="ml-1 shrink-0"
                    onClick={(e) => {
                        e.stopPropagation()
                        e.preventDefault()
                        setVisible(false)
                    }}
                >
                    <LemonButton
                        size="xsmall"
                        type="tertiary"
                        icon={<IconCopy />}
                        tooltip="Copy email"
                        onClick={() => void copyToClipboard(personEmail, 'email')}
                        data-attr="copy-person-email-button"
                    />
                </span>
            )}
            {showComposeButton && personDistinctId && (
                <span
                    className="ml-1 shrink-0"
                    onClick={(e) => {
                        e.stopPropagation()
                        e.preventDefault()
                        setVisible(false)
                    }}
                >
                    <ComposeTicketButton
                        size="xsmall"
                        type="tertiary"
                        iconOnly
                        distinctId={personDistinctId}
                        email={personEmail}
                    />
                </span>
            )}
        </span>
    )

    content = (
        <span
            className={clsx('PersonDisplay', muted && 'PersonDisplay--muted', className)}
            onClick={!noPopover ? handleClick : undefined}
        >
            {noLink || !href || !person?.properties ? (
                content
            ) : (
                <Link
                    to={href}
                    onClick={(e: React.MouseEvent): void => {
                        if (!noPopover && !notebookNode) {
                            e.preventDefault()
                            return
                        }
                    }}
                    subtle
                    data-attr={`goto-person-email-${person?.distinct_id || person?.distinct_ids?.[0]}`}
                >
                    {content}
                </Link>
            )}
        </span>
    )

    if (noPopover || notebookNode) {
        return content
    }

    return (
        <Popover
            overlay={
                person?.distinct_id || person?.distinct_ids?.[0] || person?.id ? (
                    <PersonPreview
                        distinctId={person?.distinct_id || person?.distinct_ids?.[0]}
                        personId={person?.id}
                        onClose={() => setVisible(false)}
                    />
                ) : null
            }
            visible={visible}
            onClickOutside={() => setVisible(false)}
            placement={placement || 'top'}
            fallbackPlacements={['bottom', 'right']}
            showArrow
        >
            {withCopyButton ? (
                <div className="flex flex-row items-center gap-1 min-w-0">
                    <span className="min-w-0 truncate">{content}</span>
                    <IconCopy
                        className="text-lg cursor-pointer shrink-0"
                        onClick={() => void copyToClipboard(display)}
                    />
                </div>
            ) : (
                <span>{content}</span>
            )}
        </Popover>
    )
}
