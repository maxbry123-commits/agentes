import type { FeatureFlagKey } from 'lib/constants'

import {
    AttributionMode,
    ConversionGoalFilter,
    DataWarehouseNode,
    ExternalDataSourceType,
    MARKETING_INTEGRATION_CONFIGS,
    MarketingAnalyticsColumnsSchemaNames,
    MarketingAnalyticsConstants,
    MarketingAnalyticsOrderBy,
    MarketingAnalyticsTableQuery,
    NativeMarketingSource,
    NodeKind,
    VALID_NATIVE_MARKETING_SOURCES,
} from '~/queries/schema/schema-general'
import { HogQLMathType, ManualLinkSourceType, PropertyMathType } from '~/types'

import { NativeSource } from './marketingAnalyticsLogic'

export type NonNativeMarketingSource = Extract<ExternalDataSourceType, 'BigQuery'>

export const VALID_NON_NATIVE_MARKETING_SOURCES: NonNativeMarketingSource[] = ['BigQuery']
export const VALID_SELF_MANAGED_MARKETING_SOURCES: ManualLinkSourceType[] = [
    'aws',
    'google-cloud',
    'cloudflare-r2',
    'azure',
]

// Map of native sources that require a feature flag to be enabled. Empty today
// (all current sources are fully rolled out), but kept so a new source can be
// gated behind a flag while it's being rolled out.
export const NATIVE_SOURCE_FEATURE_FLAGS: Partial<Record<NativeMarketingSource, FeatureFlagKey>> = {}

/**
 * Filter native marketing sources based on feature flags
 * @param featureFlags - The feature flags object from featureFlagLogic
 * @returns Filtered list of native marketing sources that are enabled
 */
export function getEnabledNativeMarketingSources(
    featureFlags: Partial<Record<FeatureFlagKey, boolean | string>>
): readonly NativeMarketingSource[] {
    return VALID_NATIVE_MARKETING_SOURCES.filter((source) => {
        const featureFlagKey = NATIVE_SOURCE_FEATURE_FLAGS[source]
        if (featureFlagKey) {
            return !!featureFlags[featureFlagKey]
        }
        return true
    })
}

export const MAX_ITEMS_TO_SHOW = 3

// Derive table names from centralized config
export const NEEDED_FIELDS_FOR_NATIVE_MARKETING_ANALYTICS: Record<NativeMarketingSource, string[]> = Object.fromEntries(
    VALID_NATIVE_MARKETING_SOURCES.map((source) => [
        source,
        [MARKETING_INTEGRATION_CONFIGS[source].campaignTableName, MARKETING_INTEGRATION_CONFIGS[source].statsTableName],
    ])
) as Record<NativeMarketingSource, string[]>

const NATIVE_SOURCE_DISPLAY_LABELS: Record<NativeMarketingSource, string> = {
    GoogleAds: 'Google Ads',
    MetaAds: 'Meta Ads',
    LinkedinAds: 'LinkedIn Ads',
    TikTokAds: 'TikTok Ads',
    RedditAds: 'Reddit Ads',
    BingAds: 'Bing Ads',
    SnapchatAds: 'Snapchat Ads',
    PinterestAds: 'Pinterest Ads',
}
export function nativeSourceDisplayLabel(sourceType: string): string {
    return NATIVE_SOURCE_DISPLAY_LABELS[sourceType as NativeMarketingSource] ?? sourceType
}

// Mirrors the backend `NATIVE_SOURCE_HIERARCHY_SCHEMA_NAMES` derivation (constants.py).
export type NativeSourceHierarchySchemaNames = {
    adset?: string
    adsetStats?: string
    ad?: string
    adStats?: string
}
/** Hierarchy fields are optional on MARKETING_INTEGRATION_CONFIGS. The `as unknown`
 * cast widens the narrow per-source literal types so we can read them uniformly. */
type HierarchyFieldsView = {
    adsetTableName?: string
    adsetStatsTableName?: string
    adTableName?: string
    adStatsTableName?: string
}
export const NATIVE_SOURCE_HIERARCHY_SCHEMA_NAMES: Partial<
    Record<NativeMarketingSource, NativeSourceHierarchySchemaNames>
> = Object.fromEntries(
    VALID_NATIVE_MARKETING_SOURCES.map((source): [NativeMarketingSource, NativeSourceHierarchySchemaNames] | null => {
        const config = MARKETING_INTEGRATION_CONFIGS[source] as unknown as HierarchyFieldsView
        const entry: NativeSourceHierarchySchemaNames = {}
        if (config.adsetTableName && config.adsetStatsTableName) {
            entry.adset = config.adsetTableName
            entry.adsetStats = config.adsetStatsTableName
        }
        if (config.adTableName && config.adStatsTableName) {
            entry.ad = config.adTableName
            entry.adStats = config.adStatsTableName
        }
        return Object.keys(entry).length > 0 ? [source, entry] : null
    }).filter((entry): entry is [NativeMarketingSource, NativeSourceHierarchySchemaNames] => entry !== null)
)

/** Mirrors the backend `_extract_schema_name` (factory.py). Warehouse tables are named
 * `{user_prefix}{source_type}_{schema_name}`, and the prefix is free text, so it can
 * repeat the marker — take the last occurrence, which is always the real boundary. */
export function extractSchemaName(tableName: string, sourceType: string): string {
    const suffix = tableName.split('.').pop()?.toLowerCase() || ''
    const marker = `${sourceType.toLowerCase()}_`
    const index = suffix.lastIndexOf(marker)
    return index === -1 ? suffix : suffix.slice(index + marker.length)
}

// Old syncs may still use a stats table's pre-rename name — mirrors the backend
// fallback in factory.py.
const LEGACY_TABLE_NAME_FALLBACKS: Partial<Record<NativeMarketingSource, Record<string, string[]>>> = {
    GoogleAds: {
        campaign_overview_stats: ['campaign_stats'],
    },
}

/** Find a schema by field name, falling back to legacy table names if needed */
export function findSchemaByFieldName<T extends { name: string }>(
    schemas: T[] | undefined,
    fieldName: string,
    sourceType: string
): T | null {
    const schema = schemas?.find((s) => s.name === fieldName)
    if (schema) {
        return schema
    }

    const fallbacks = LEGACY_TABLE_NAME_FALLBACKS[sourceType as NativeMarketingSource]?.[fieldName]
    if (fallbacks) {
        for (const fallbackName of fallbacks) {
            const fallbackSchema = schemas?.find((s) => s.name === fallbackName)
            if (fallbackSchema) {
                return fallbackSchema
            }
        }
    }
    return null
}

export const MAX_ATTRIBUTION_WINDOW_DAYS = 90
export const MIN_ATTRIBUTION_WINDOW_DAYS = 1
export const DEFAULT_ATTRIBUTION_WINDOW_DAYS = 90
export const DEFAULT_ATTRIBUTION_MODE = AttributionMode.LastTouch

export const ATTRIBUTION_WINDOW_OPTIONS = [
    { value: 1, label: '1 day' },
    { value: 7, label: '1 week (7 days)' },
    { value: 14, label: '2 weeks (14 days)' },
    { value: 30, label: '1 month (30 days)' },
    { value: 90, label: '3 months (90 days)' },
    { value: 'custom', label: 'Custom' },
]

export function MarketingDashboardMapper(
    source: NativeSource,
    tileColumnSelection: validColumnsForTiles,
    baseCurrency: string
): DataWarehouseNode | null {
    return createMarketingTile(source, tileColumnSelection, baseCurrency)
}

export const COST_MICROS_MULTIPLIER = 1 / 1000000

/**
 * Generates a unique name by adding a numeric suffix if the base name already exists in the given list.
 * @param baseName The desired base name
 * @param existingNames Array of names that already exist
 * @returns A unique name, either the original or with a numeric suffix like "(1)", "(2)", etc.
 */
export function generateUniqueName(baseName: string, existingNames: string[]): string {
    if (!existingNames.includes(baseName)) {
        return baseName
    }

    // Find the next available number suffix
    let counter = 1
    let newName = `${baseName} (${counter})`

    while (existingNames.includes(newName)) {
        counter++
        newName = `${baseName} (${counter})`
    }

    return newName
}

/**
 * Mirrors the backend `goal_sums_a_property` (conversion_goal_processor.py): whether a goal's
 * column holds a summed property value rather than a conversion count. The backend builds ROAS
 * only from summing revenue goals and CAC only from counting customer goals, so the column gates
 * here must apply the same test — otherwise the table requests a ratio column the backend leaves
 * out, and it silently disappears.
 */
export function goalSumsAProperty(goal: ConversionGoalFilter): boolean {
    const math = goal.math
    return math === PropertyMathType.Sum || (typeof math === 'string' && math.endsWith('_sum'))
}

export function isDraftConversionGoalColumn(column: string, draftConversionGoal: ConversionGoalFilter | null): boolean {
    if (!draftConversionGoal) {
        return false
    }
    return (
        column === draftConversionGoal.conversion_goal_name ||
        column === `${MarketingAnalyticsConstants.CostPer} ${draftConversionGoal.conversion_goal_name}`
    )
}

/**
 * Get the order by for the query and ensure that the order by is in the columns
 * @param query - The query to get the order by for
 * @param columns - The columns to include in the order by
 * @returns The order by for the query
 */
export function getOrderBy(
    query: MarketingAnalyticsTableQuery | undefined,
    columns: string[]
): MarketingAnalyticsOrderBy[] {
    const orderBy = (query?.orderBy || []).filter((column) => {
        const columnName = column[0]
        return columns.includes(columnName)
    })
    return orderBy
}

/**
 * Order the array by the preference
 * @param array - The array to order
 * @param preference - The preference to order the array by
 * @returns The ordered array preserving the order of the items in the original array
 * This is used to prioritize pinned columns over the rest of the columns but preserving
 * the order of the items in the original array.
 * example:
 * orderArrayByPreference(['a', 'b', 'c'], ['c', 'b']) -> ['b', 'c', 'a']
 */
export function orderArrayByPreference(array: string[], preference: string[]): string[] {
    return [
        ...array.filter((column) => preference.includes(column)),
        ...array.filter((column) => !preference.includes(column)),
    ]
}

/**
 * Get the sorted columns by the array
 * @param array - The array to get the sorted columns for
 * @param sortedArray - The array to sort the columns by
 * @returns The sorted columns by the sorted array preference. This is used
 * to sort the columns by the default order of the columns.
 * example:
 * getSortedColumnsByArray(['a', 'b', 'c', 'c'], ['c', 'b', 'c']) -> ['c', 'c', 'b', 'a']
 */
export function getSortedColumnsByArray(array: string[], sortedArray: string[]): string[] {
    const amountPerItem = new Map<string, number>()
    for (const column of array) {
        amountPerItem.set(column, (amountPerItem.get(column) ?? 0) + 1)
    }

    const newArray: string[] = []
    const added = new Set<string>()

    for (const column of sortedArray) {
        if (amountPerItem.has(column) && !added.has(column)) {
            const count = amountPerItem.get(column)!
            newArray.push(...Array(count).fill(column))
            added.add(column)
        }
    }

    for (const column of array) {
        if (!sortedArray.includes(column)) {
            newArray.push(column)
        }
    }

    return newArray
}

export function createMarketingAnalyticsOrderBy(
    column: string,
    direction: 'ASC' | 'DESC'
): MarketingAnalyticsOrderBy[] {
    return [[column, direction]]
}
export type validColumnsForTiles =
    | Extract<
          MarketingAnalyticsColumnsSchemaNames,
          'cost' | 'impressions' | 'clicks' | 'reported_conversion' | 'reported_conversion_value'
      >
    | 'roas'
    | 'cost_per_reported_conversion'

// Raw column types that have actual column mappings (excludes calculated fields like ROAS)
export type rawColumnsForTiles = Exclude<validColumnsForTiles, 'roas' | 'cost_per_reported_conversion'>

interface ColumnConfig {
    name: string
    type: string
    needsDivision: boolean
}

interface SourceColumnMappings {
    cost: string
    impressions: string
    clicks: string
    reportedConversion: string
    reportedConversionValue: string
    costNeedsDivision?: boolean
    currencyColumn?: string
    fallbackCurrency?: string
}

interface ConversionExprResult extends Partial<DataWarehouseNode> {
    perRowValueExpr?: string
}

interface SourceTileConfig {
    idField: string
    timestampField: string
    columnMappings: SourceColumnMappings
    specialConversionLogic?: (_table: any, tileColumnSelection: validColumnsForTiles) => ConversionExprResult | null
}

export function safeFloat(field: string): string {
    return `ifNull(toFloat(${field}), 0)`
}

export function sumSafeFloat(field: string): string {
    return `SUM(${safeFloat(field)})`
}

function buildConversionExpr(
    fields: string | readonly string[],
    table: any,
    buildExpr?: (availableFields: string[]) => string,
    buildPerRowExpr?: (availableFields: string[]) => string
): ConversionExprResult {
    const fieldList = typeof fields === 'string' ? [fields] : [...fields]
    const availableFields = fieldList.filter((field) => table.fields && field in table.fields)
    if (availableFields.length === 0) {
        return { math: HogQLMathType.HogQL, math_hogql: '0' }
    }
    const defaultPerRow = availableFields.map((field) => safeFloat(field)).join(' + ')
    const perRowValueExpr = buildPerRowExpr ? buildPerRowExpr(availableFields) : defaultPerRow
    const mathHogql = buildExpr ? buildExpr(availableFields) : `SUM(${defaultPerRow})`
    return { math: HogQLMathType.HogQL, math_hogql: mathHogql, perRowValueExpr }
}

const sourceTileConfigs: Record<NativeMarketingSource, SourceTileConfig> = {
    GoogleAds: {
        // idField is a column on the stats table, which flattens `campaign.id` to
        // `campaign_id` and has no bare `id`.
        idField: 'campaign_id',
        timestampField: 'segments_date',
        columnMappings: {
            cost: 'metrics_cost_micros',
            impressions: 'metrics_impressions',
            clicks: 'metrics_clicks',
            reportedConversion: 'metrics_conversions',
            reportedConversionValue: 'metrics_conversions_value',
            costNeedsDivision: true,
            currencyColumn: 'customer_currency_code',
            fallbackCurrency: 'USD',
        },
    },
    RedditAds: {
        idField: 'campaign_id',
        timestampField: 'date',
        columnMappings: {
            cost: 'spend',
            impressions: 'impressions',
            clicks: 'clicks',
            reportedConversion: 'conversion_purchase_total_items',
            reportedConversionValue: 'conversion_purchase_total_value',
            costNeedsDivision: true,
            currencyColumn: 'currency',
        },
        specialConversionLogic: (_table, tileColumnSelection) => {
            if (tileColumnSelection === MarketingAnalyticsColumnsSchemaNames.ReportedConversion) {
                return buildConversionExpr(['conversion_signup_total_value', 'conversion_purchase_total_items'], _table)
            }
            if (tileColumnSelection === MarketingAnalyticsColumnsSchemaNames.ReportedConversionValue) {
                // Reddit Ads API: "Divide by 100: CONVERSION*TOTAL_VALUE"
                // See: https://ads-api.reddit.com/docs/v3/operations/Get%20A%20Report
                return buildConversionExpr(
                    ['conversion_purchase_total_value', 'conversion_signup_total_value'],
                    _table,
                    (fields) => `SUM(${fields.map((f) => `ifNull(toFloat(${f}), 0) / 100`).join(' + ')})`,
                    (fields) => fields.map((f) => `ifNull(toFloat(${f}), 0) / 100`).join(' + ')
                )
            }
            return null
        },
    },
    LinkedinAds: {
        // campaign_group_stats keys rows by `campaign_group_id`, it has no `id`.
        idField: 'campaign_group_id',
        timestampField: 'date_start',
        columnMappings: {
            cost: 'cost_in_usd',
            impressions: 'impressions',
            clicks: 'clicks',
            reportedConversion: 'external_website_conversions',
            reportedConversionValue: 'conversion_value_in_local_currency',
            fallbackCurrency: 'USD',
        },
        specialConversionLogic: (table, tileColumnSelection) => {
            if (tileColumnSelection === MarketingAnalyticsColumnsSchemaNames.ReportedConversionValue) {
                return buildConversionExpr(['conversion_value_in_local_currency'], table)
            }
            return null
        },
    },
    MetaAds: {
        idField: 'campaign_id',
        timestampField: 'date_stop',
        columnMappings: {
            cost: 'spend',
            impressions: 'impressions',
            clicks: 'clicks',
            reportedConversion: 'actions',
            reportedConversionValue: 'action_values',
            currencyColumn: 'account_currency',
        },
        specialConversionLogic: (table, tileColumnSelection) => {
            const { omni: omniActionTypes, fallback: fallbackActionTypes } =
                MARKETING_INTEGRATION_CONFIGS.MetaAds.conversionActionTypes

            const buildArraySumExpr = (field: string, actionTypes: readonly string[]): string => {
                const actionTypesStr = actionTypes
                    .map((t) => {
                        const escaped = t.replace(/\\/g, '\\\\').replace(/'/g, "\\'")
                        return `'${escaped}'`
                    })
                    .join(', ')
                return `arraySum(x -> JSONExtractFloat(x, 'value'), arrayFilter(x -> JSONExtractString(x, 'action_type') IN (${actionTypesStr}), JSONExtractArrayRaw(coalesce(${field}, '[]'))))`
            }

            if (tileColumnSelection === MarketingAnalyticsColumnsSchemaNames.ReportedConversion) {
                return buildConversionExpr('actions', table, ([field]) => {
                    const omniSum = buildArraySumExpr(field, omniActionTypes)
                    const fallbackSum = buildArraySumExpr(field, fallbackActionTypes)
                    return `SUM(if(${omniSum} > 0, ${omniSum}, ${fallbackSum}))`
                })
            }
            if (tileColumnSelection === MarketingAnalyticsColumnsSchemaNames.ReportedConversionValue) {
                return buildConversionExpr(
                    'action_values',
                    table,
                    ([field]) => {
                        const omniSum = buildArraySumExpr(field, omniActionTypes)
                        const fallbackSum = buildArraySumExpr(field, fallbackActionTypes)
                        return `SUM(if(${omniSum} > 0, ${omniSum}, ${fallbackSum}))`
                    },
                    ([field]) => {
                        const omniSum = buildArraySumExpr(field, omniActionTypes)
                        const fallbackSum = buildArraySumExpr(field, fallbackActionTypes)
                        return `if(${omniSum} > 0, ${omniSum}, ${fallbackSum})`
                    }
                )
            }
            return null
        },
    },
    TikTokAds: {
        idField: 'campaign_id',
        timestampField: 'stat_time_day',
        columnMappings: {
            cost: 'spend',
            impressions: 'impressions',
            clicks: 'clicks',
            reportedConversion: 'conversion',
            reportedConversionValue: 'total_complete_payment_value',
            currencyColumn: 'currency',
        },
        specialConversionLogic: (table, tileColumnSelection) => {
            if (tileColumnSelection === MarketingAnalyticsColumnsSchemaNames.ReportedConversion) {
                return buildConversionExpr('conversion', table)
            }
            if (tileColumnSelection === MarketingAnalyticsColumnsSchemaNames.ReportedConversionValue) {
                return buildConversionExpr(['total_complete_payment_value'], table)
            }
            return null
        },
    },
    BingAds: {
        idField: 'campaign_id',
        timestampField: 'time_period',
        columnMappings: {
            cost: 'spend',
            impressions: 'impressions',
            clicks: 'clicks',
            reportedConversion: 'conversions',
            reportedConversionValue: 'revenue',
            currencyColumn: 'currency_code',
        },
        specialConversionLogic: (table, tileColumnSelection) => {
            if (tileColumnSelection === MarketingAnalyticsColumnsSchemaNames.ReportedConversion) {
                return buildConversionExpr('conversions', table)
            }
            if (tileColumnSelection === MarketingAnalyticsColumnsSchemaNames.ReportedConversionValue) {
                return buildConversionExpr(['revenue'], table)
            }
            return null
        },
    },
    SnapchatAds: {
        idField: 'id',
        timestampField: 'start_time',
        columnMappings: {
            cost: 'spend',
            impressions: 'impressions',
            clicks: 'swipes',
            reportedConversion: 'conversion_purchases',
            reportedConversionValue: 'conversion_purchases_value',
            costNeedsDivision: true,
            currencyColumn: 'currency',
        },
        specialConversionLogic: (table, tileColumnSelection) => {
            const { conversionFields, conversionValueFields } = MARKETING_INTEGRATION_CONFIGS.SnapchatAds

            if (tileColumnSelection === MarketingAnalyticsColumnsSchemaNames.ReportedConversion) {
                return buildConversionExpr(conversionFields, table)
            }
            if (tileColumnSelection === MarketingAnalyticsColumnsSchemaNames.ReportedConversionValue) {
                return buildConversionExpr(conversionValueFields, table)
            }
            return null
        },
    },
    PinterestAds: {
        idField: 'campaign_id',
        timestampField: 'date',
        columnMappings: {
            cost: 'spend_in_dollar',
            impressions: 'total_impression',
            clicks: 'total_clickthrough',
            reportedConversion: 'total_conversions',
            reportedConversionValue: 'total_checkout_value_in_micro_dollar',
            costNeedsDivision: false,
            currencyColumn: 'currency',
            fallbackCurrency: 'USD',
        },
        specialConversionLogic: (table, tileColumnSelection) => {
            if (tileColumnSelection === MarketingAnalyticsColumnsSchemaNames.ReportedConversion) {
                return buildConversionExpr('total_conversions', table)
            }
            if (tileColumnSelection === MarketingAnalyticsColumnsSchemaNames.ReportedConversionValue) {
                return buildConversionExpr(
                    ['total_checkout_value_in_micro_dollar'],
                    table,
                    ([field]) => `SUM(ifNull(toFloat(${field}), 0) / 1000000)`,
                    ([field]) => `ifNull(toFloat(${field}), 0) / 1000000`
                )
            }
            return null
        },
    },
}

function createColumnConfig(columnName: string, type: 'float' | 'integer', needsDivision = false): ColumnConfig {
    return { name: columnName, type, needsDivision }
}

function buildSourceConfig(mappings: SourceColumnMappings): {
    columns: { [key in rawColumnsForTiles]: ColumnConfig }
} {
    return {
        columns: {
            [MarketingAnalyticsColumnsSchemaNames.Cost]: createColumnConfig(
                mappings.cost,
                'float',
                mappings.costNeedsDivision ?? false
            ),
            [MarketingAnalyticsColumnsSchemaNames.Impressions]: createColumnConfig(mappings.impressions, 'integer'),
            [MarketingAnalyticsColumnsSchemaNames.Clicks]: createColumnConfig(mappings.clicks, 'integer'),
            [MarketingAnalyticsColumnsSchemaNames.ReportedConversion]: createColumnConfig(
                mappings.reportedConversion,
                'integer'
            ),
            [MarketingAnalyticsColumnsSchemaNames.ReportedConversionValue]: createColumnConfig(
                mappings.reportedConversionValue,
                'float'
            ),
        },
    }
}

export const columnTileConfig: {
    [key in NativeMarketingSource]: {
        columns: {
            [key in rawColumnsForTiles]: ColumnConfig
        }
    }
} = Object.fromEntries(
    VALID_NATIVE_MARKETING_SOURCES.map((source) => [
        source,
        buildSourceConfig(sourceTileConfigs[source].columnMappings),
    ])
) as any

function buildNativeCostExpr(mappings: SourceColumnMappings): string {
    return mappings.costNeedsDivision ? `toFloat(${mappings.cost} / 1000000)` : `toFloat(${mappings.cost})`
}

function buildNativeTileNode(
    table: any,
    integrationConfig: (typeof MARKETING_INTEGRATION_CONFIGS)[NativeMarketingSource],
    tileConfig: SourceTileConfig,
    tileColumnSelection: validColumnsForTiles,
    mathHogql: string
): DataWarehouseNode {
    return {
        kind: NodeKind.DataWarehouseNode,
        id: table.id,
        name: integrationConfig.primarySource,
        custom_name: `${table.name} ${tileColumnSelection}`,
        id_field: tileConfig.idField,
        distinct_id_field: tileConfig.idField,
        timestamp_field: tileConfig.timestampField,
        table_name: table.name,
        math: HogQLMathType.HogQL,
        math_hogql: mathHogql,
    }
}

function wrapWithCurrencyConversion(
    valueExpr: string,
    mappings: SourceColumnMappings,
    table: any,
    baseCurrency: string
): string {
    const currencyColumn = mappings.currencyColumn
    const fallbackCurrency = mappings.fallbackCurrency
    const hasCurrencyColumn = currencyColumn && table.fields && currencyColumn in table.fields

    if (hasCurrencyColumn) {
        return `SUM(toFloat(convertCurrency(coalesce(${currencyColumn}, '${baseCurrency}'), '${baseCurrency}', ${valueExpr})))`
    }
    if (fallbackCurrency) {
        return `toFloat(convertCurrency('${fallbackCurrency}', '${baseCurrency}', SUM(${valueExpr})))`
    }
    return `SUM(${valueExpr})`
}

function wrapAggregatedWithCurrencyConversion(
    aggregatedExpr: string,
    mappings: SourceColumnMappings,
    table: any,
    baseCurrency: string
): string {
    const currencyColumn = mappings.currencyColumn
    const fallbackCurrency = mappings.fallbackCurrency
    const hasCurrencyColumn = currencyColumn && table.fields && currencyColumn in table.fields

    if (hasCurrencyColumn) {
        return `toFloat(convertCurrency(any(coalesce(${currencyColumn}, '${baseCurrency}')), '${baseCurrency}', ${aggregatedExpr}))`
    }
    if (fallbackCurrency) {
        return `toFloat(convertCurrency('${fallbackCurrency}', '${baseCurrency}', ${aggregatedExpr}))`
    }
    return aggregatedExpr
}

function resolveConversionExpr(
    tileConfig: SourceTileConfig,
    table: any,
    columnType: validColumnsForTiles,
    fallbackColumn: string
): string {
    const specialResult = tileConfig.specialConversionLogic?.(table, columnType)
    if (specialResult?.math_hogql) {
        return specialResult.math_hogql
    }
    return table.fields && fallbackColumn in table.fields ? sumSafeFloat(fallbackColumn) : '0'
}

export function createMarketingTile(
    source: NativeSource,
    tileColumnSelection: validColumnsForTiles,
    baseCurrency: string
): DataWarehouseNode | null {
    const sourceType = source.source.source_type as NativeMarketingSource
    const tileConfig = sourceTileConfigs[sourceType]
    const integrationConfig = MARKETING_INTEGRATION_CONFIGS[sourceType]

    if (!tileConfig || !integrationConfig) {
        return null
    }

    const table = source.tables.find((t) => t.name.split('.').pop() === integrationConfig.statsTableName)
    if (!table) {
        return null
    }

    // Handle ROAS (Return on Ad Spend) - calculated as conversion_value / cost
    if (tileColumnSelection === 'roas') {
        const costExpr = buildNativeCostExpr(tileConfig.columnMappings)
        const conversionValueExpr = resolveConversionExpr(
            tileConfig,
            table,
            MarketingAnalyticsColumnsSchemaNames.ReportedConversionValue,
            tileConfig.columnMappings.reportedConversionValue
        )
        const mathHogql = conversionValueExpr === '0' ? '0' : `${conversionValueExpr} / nullIf(SUM(${costExpr}), 0)`
        return buildNativeTileNode(table, integrationConfig, tileConfig, tileColumnSelection, mathHogql)
    }

    // Handle Cost per Reported Conversion - calculated as cost / reported_conversions
    if (tileColumnSelection === 'cost_per_reported_conversion') {
        const costExpr = buildNativeCostExpr(tileConfig.columnMappings)
        const conversionExpr = resolveConversionExpr(
            tileConfig,
            table,
            MarketingAnalyticsColumnsSchemaNames.ReportedConversion,
            tileConfig.columnMappings.reportedConversion
        )
        const mathHogql = conversionExpr === '0' ? '0' : `SUM(${costExpr}) / nullIf(${conversionExpr}, 0)`
        return buildNativeTileNode(table, integrationConfig, tileConfig, tileColumnSelection, mathHogql)
    }

    const column = columnTileConfig[sourceType].columns[tileColumnSelection as rawColumnsForTiles]
    if (!column) {
        return null
    }

    // Check for special conversion logic first
    if (tileConfig.specialConversionLogic) {
        const specialLogic = tileConfig.specialConversionLogic(table, tileColumnSelection)
        if (specialLogic) {
            let finalMathHogql = specialLogic.math_hogql

            if (
                tileColumnSelection === MarketingAnalyticsColumnsSchemaNames.ReportedConversionValue &&
                finalMathHogql &&
                finalMathHogql !== '0'
            ) {
                if (specialLogic.perRowValueExpr) {
                    finalMathHogql = wrapWithCurrencyConversion(
                        specialLogic.perRowValueExpr,
                        tileConfig.columnMappings,
                        table,
                        baseCurrency
                    )
                } else {
                    finalMathHogql = wrapAggregatedWithCurrencyConversion(
                        finalMathHogql,
                        tileConfig.columnMappings,
                        table,
                        baseCurrency
                    )
                }
            }

            const { perRowValueExpr: _, ...specialLogicRest } = specialLogic
            return {
                ...buildNativeTileNode(
                    table,
                    integrationConfig,
                    tileConfig,
                    tileColumnSelection,
                    finalMathHogql ?? '0'
                ),
                ...specialLogicRest,
                math_hogql: finalMathHogql,
            }
        }
    }

    if (tileColumnSelection === MarketingAnalyticsColumnsSchemaNames.Cost) {
        const costExpr = buildNativeCostExpr(tileConfig.columnMappings)
        const mathHogql = wrapWithCurrencyConversion(costExpr, tileConfig.columnMappings, table, baseCurrency)
        return buildNativeTileNode(table, integrationConfig, tileConfig, tileColumnSelection, mathHogql)
    }

    if (tileColumnSelection === MarketingAnalyticsColumnsSchemaNames.ReportedConversionValue) {
        const valueExpr = safeFloat(column.name)
        const mathHogql = wrapWithCurrencyConversion(valueExpr, tileConfig.columnMappings, table, baseCurrency)
        return buildNativeTileNode(table, integrationConfig, tileConfig, tileColumnSelection, mathHogql)
    }

    // Default tile configuration for non-monetary columns
    return buildNativeTileNode(table, integrationConfig, tileConfig, tileColumnSelection, sumSafeFloat(column.name))
}

export function rowMatchesSearch(record: unknown, searchTerm: string): boolean {
    if (!searchTerm.trim()) {
        return true
    }

    const normalizedSearch = searchTerm.toLowerCase().trim()

    if (!record || typeof record !== 'object') {
        return false
    }

    const row = record as { result?: unknown[]; label?: string }

    if (row.label) {
        return true
    }

    if (!row.result || !Array.isArray(row.result)) {
        return false
    }

    return row.result.some((item) => {
        if (typeof item === 'string') {
            return item.toLowerCase().includes(normalizedSearch)
        }
        if (typeof item === 'object' && item !== null) {
            const itemValue = (item as Record<string, unknown>).value
            if (typeof itemValue === 'string') {
                return itemValue.toLowerCase().includes(normalizedSearch)
            }
        }
        return false
    })
}
