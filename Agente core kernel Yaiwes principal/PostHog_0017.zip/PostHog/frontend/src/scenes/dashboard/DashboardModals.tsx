import { useActions, useValues } from 'kea'
import { router } from 'kea-router'

import { AddWidgetModal } from '@posthog/products-dashboards/frontend/widgets/AddWidgetModal'

import { ButtonTileCardModal } from 'lib/components/Cards/ButtonTileCard/ButtonTileCardModal'
import { TextCardModal } from 'lib/components/Cards/TextCard/TextCardModal'
import { SharingModal } from 'lib/components/Sharing/SharingModal'
import { TerraformExportModal } from 'lib/components/TerraformExporter/TerraformExportModal'
import { urls } from 'scenes/urls'
import { userLogic } from 'scenes/userLogic'

import { dashboardsModel } from '~/models/dashboardsModel'
import { DashboardMode, DashboardType, QueryBasedInsightModel } from '~/types'

import { SubscriptionsModal } from 'products/subscriptions/frontend/components/Subscriptions/SubscriptionsModal'

import { DashboardInsightColorsModal } from './DashboardInsightColorsModal'
import { dashboardLogic } from './dashboardLogic'
import { DashboardTemplateEditor } from './DashboardTemplateEditor'
import { DeleteDashboardModal } from './DeleteDashboardModal'
import { DuplicateDashboardModal } from './DuplicateDashboardModal'

export function DashboardModals({ dashboard }: { dashboard: DashboardType<QueryBasedInsightModel> }): JSX.Element {
    const {
        dashboardMode,
        canEditDashboard,
        showSubscriptions,
        subscriptionId,
        showTextTileModal,
        textTileId,
        showButtonTileModal,
        buttonTileId,
        terraformModalOpen,
        addWidgetModalOpen,
        dashboardWidgetsEnabled,
        addWidgetTileLoading,
    } = useValues(dashboardLogic)
    const { setTerraformModalOpen, setAddWidgetModalOpen, addWidgetTiles } = useActions(dashboardLogic)
    const { updateDashboardSuccess } = useActions(dashboardsModel)
    const { push } = useActions(router)
    const { user } = useValues(userLogic)

    return (
        <>
            <SubscriptionsModal
                isOpen={showSubscriptions}
                closeModal={() => push(urls.dashboard(dashboard.id))}
                dashboard={dashboard}
                isCreating={subscriptionId === 'new'}
                subscriptionId={subscriptionId === 'new' ? null : subscriptionId}
            />
            <SharingModal
                title="Dashboard permissions & sharing"
                isOpen={dashboardMode === DashboardMode.Sharing}
                closeModal={() => push(urls.dashboard(dashboard.id))}
                dashboardId={dashboard.id}
                userAccessLevel={dashboard.user_access_level}
                onSharingEnabledChange={(enabled) => updateDashboardSuccess({ ...dashboard, is_shared: enabled })}
            />
            {canEditDashboard && (
                <>
                    <TextCardModal
                        isOpen={showTextTileModal}
                        onClose={() => push(urls.dashboard(dashboard.id))}
                        dashboard={dashboard}
                        textTileId={textTileId}
                    />
                    <ButtonTileCardModal
                        isOpen={showButtonTileModal}
                        onClose={() => push(urls.dashboard(dashboard.id))}
                        dashboard={dashboard}
                        buttonTileId={buttonTileId}
                    />
                    {dashboardWidgetsEnabled && (
                        <AddWidgetModal
                            isOpen={addWidgetModalOpen}
                            onClose={() => setAddWidgetModalOpen(false)}
                            loading={addWidgetTileLoading}
                            onAdd={async (widgets) => {
                                await addWidgetTiles({
                                    dashboardId: dashboard.id,
                                    widgets,
                                })
                            }}
                        />
                    )}
                    <DeleteDashboardModal />
                    <DuplicateDashboardModal />
                    <DashboardInsightColorsModal />
                </>
            )}
            {user?.is_staff && <DashboardTemplateEditor />}
            <TerraformExportModal
                isOpen={terraformModalOpen}
                onClose={() => setTerraformModalOpen(false)}
                resource={{ type: 'dashboard', data: dashboard }}
            />
        </>
    )
}
