import './DashboardItems.scss'

import clsx from 'clsx'
import { useActions, useAsyncActions, useValues } from 'kea'
import { router } from 'kea-router'
import { RefObject, memo, useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { Responsive as ReactGridLayout, useContainerWidth } from 'react-grid-layout'
import type { Layout, LayoutItem } from 'react-grid-layout'
import { GridBackground } from 'react-grid-layout/extras'

import { DashboardWidgetItem } from '@posthog/products-dashboards/frontend/components/DashboardWidgetItem/DashboardWidgetItem'
import { getDashboardWidgetFetchDisplayError } from '@posthog/products-dashboards/frontend/widgets/constants'

import { ApiError } from 'lib/api'
import { InsightCard } from 'lib/components/Cards/InsightCard'
import { EditModeEdge, useResizeHandleScrollbarPassThrough } from 'lib/components/Cards/InsightCard/EditModeEdgeOverlay'
import { LemonBanner } from 'lib/lemon-ui/LemonBanner'
import { LemonMenuItems } from 'lib/lemon-ui/LemonMenu'
import { DashboardEventSource, eventUsageLogic } from 'lib/utils/eventUsageLogic'
import { objectsEqual } from 'lib/utils/objects'
import { addInsightToDashboardLogic } from 'scenes/dashboard/addInsightToDashboardModalLogic'
import { getAddTileMenuItems } from 'scenes/dashboard/DashboardHeaderActions'
import { DashboardLoadAction, dashboardLogic } from 'scenes/dashboard/dashboardLogic'
import {
    BREAKPOINTS,
    BREAKPOINT_COLUMN_COUNTS,
    getInsightQueryError,
    isWidgetTileVisibleOnPlacement,
} from 'scenes/dashboard/dashboardUtils'
import { continueDragGestureInEditMode, continueResizeGestureInEditMode } from 'scenes/dashboard/editLayoutGesture'
import { InsertTileOverlay } from 'scenes/dashboard/InsertTileOverlay'
import { useDashboardLayoutInteraction } from 'scenes/dashboard/useDashboardLayoutInteraction'
import { useSurveyLinkedInsights } from 'scenes/surveys/hooks/useSurveyLinkedInsights'
import { getBestSurveyOpportunityFunnel } from 'scenes/surveys/utils/opportunityDetection'
import { urls } from 'scenes/urls'

import { getCurrentExporterData, isSharedView } from '~/exporter/exporterViewLogic'
import { insightsModel } from '~/models/insightsModel'
import { DashboardLayoutSize, DashboardMode, DashboardPlacement, DashboardType } from '~/types'

import { getDashboardTileSpacingGap } from 'products/dashboards/frontend/dashboardCustomization'

import { DashboardButtonTileItem } from './items/DashboardButtonTileItem'
import { DashboardErrorTileItem } from './items/DashboardErrorTileItem'
import { DashboardTextItem } from './items/DashboardTextItem'

const DRAG_AUTO_SCROLL_THRESHOLD = 100
const DRAG_AUTO_SCROLL_SPEED = 50

const BASE_ROW_HEIGHT = 80
const BASE_MARGIN: [number, number] = [16, 16]
const CONTAINER_PADDING: [number, number] = [0, 0]

interface DashboardItemsProps {
    showCreateAnomalyAlertButton?: boolean
}

/**
 * Shallow prop compare, except: `style` by value (react-grid-layout rebuilds it every drag/resize mousemove even
 * for tiles that haven't moved) and `children` ignored (the RGL-injected resize handles, recreated each render
 * with identical content). Lets untouched tiles skip re-rendering during gestures.
 */
function gridTilePropsEqual(prevProps: Record<string, any>, nextProps: Record<string, any>): boolean {
    return [...new Set([...Object.keys(prevProps), ...Object.keys(nextProps)])].every(
        (key) =>
            key === 'children' ||
            (key === 'style'
                ? objectsEqual(prevProps.style, nextProps.style)
                : Object.is(prevProps[key], nextProps[key]))
    )
}

const MemoizedInsightCard = memo(InsightCard, gridTilePropsEqual) as typeof InsightCard
const MemoizedDashboardTextItem = memo(DashboardTextItem, gridTilePropsEqual) as typeof DashboardTextItem
const MemoizedDashboardButtonTileItem = memo(
    DashboardButtonTileItem,
    gridTilePropsEqual
) as typeof DashboardButtonTileItem
const MemoizedDashboardErrorTileItem = memo(DashboardErrorTileItem, gridTilePropsEqual) as typeof DashboardErrorTileItem
const MemoizedDashboardWidgetItem = memo(DashboardWidgetItem, gridTilePropsEqual) as typeof DashboardWidgetItem

export function DashboardItems({ showCreateAnomalyAlertButton }: DashboardItemsProps = {}): JSX.Element {
    const {
        dashboard,
        tiles,
        layouts,
        dashboardMode,
        layoutEditMode,
        placement,
        isRefreshingQueued,
        isRefreshing,
        highlightedInsightId,
        refreshStatus,
        dashboardStreaming,
        dashboardLoading,
        effectiveEditBarFilters,
        effectiveDashboardVariableOverrides,
        effectiveBreakdownColors,
        dataColorThemeId,
        canEditDashboard,
        dashboardWidgetsEnabled,
        widgetResultsByTileId,
        widgetRefreshStatus,
        scrollToBottomSignal,
    } = useValues(dashboardLogic)
    const { layoutZoom = 1 } = useValues(dashboardLogic)
    const {
        updateLayouts,
        updateContainerWidth,
        updateTileColor,
        toggleTileDescription,
        removeTile,
        duplicateTile,
        refreshDashboardItem,
        loadDashboard,
        refreshDashboardWidgets,
        scheduleRefreshDashboardWidgets,
        applyWidgetIssueMetadataChange,
        moveToDashboard,
        copyToDashboard,
        setTileOverride,
        setDashboardMode,
        setAddWidgetModalOpen,
        setPendingInsertion,
    } = useActions(dashboardLogic)
    const { showAddInsightToDashboardModal } = useActions(addInsightToDashboardLogic)
    const { updateWidgetTile } = useAsyncActions(dashboardLogic)
    const { renameInsight } = useActions(insightsModel)
    const { reportDashboardAddMenuOpened, reportDashboardTileRepositioned } = useActions(eventUsageLogic)
    const { push } = useActions(router)
    const { data: surveyLinkedInsights, loading: surveyLinkedInsightsLoading } = useSurveyLinkedInsights({})

    const bestSurveyOpportunityFunnel = surveyLinkedInsightsLoading
        ? null
        : getBestSurveyOpportunityFunnel(tiles || [], surveyLinkedInsights)
    const retryFailedDashboardTile = isSharedView()
        ? undefined
        : () => loadDashboard({ action: DashboardLoadAction.Update })
    const refreshDashboardTile = isSharedView() ? undefined : refreshDashboardItem

    // Tile currently being resized. Its viz is unmounted for the duration of the gesture so the chart doesn't
    // redraw on every frame as the tile's dimensions change — the dominant cost that makes resizing feel laggy.
    const [resizingTileId, setResizingTileId] = useState<string | null>(null)
    const [containerHeight, setContainerHeight] = useState<number | undefined>(undefined)

    // cannot click links when dragging and 250ms after
    const isDragging = useRef(false)
    // While a drag/resize is in progress the grid drives itself from its own internal state and ignores the
    // `layouts` prop, so pushing layout updates to the store mid-gesture only triggers expensive full re-renders
    // (every InsightCard) that make the dragged tile lag the cursor. Stash the latest layout and commit once on stop.
    const dragEndTimeout = useRef<number | null>(null)
    const scrollAnimationRef = useRef<number | null>(null)
    const scrollContainerRef = useRef<HTMLElement | null>(null)
    const scrollContainerRectRef = useRef<DOMRect | null>(null)
    const lastScrollSignalRef = useRef(scrollToBottomSignal)

    useEffect(() => {
        return () => {
            if (scrollAnimationRef.current) {
                cancelAnimationFrame(scrollAnimationRef.current)
            }
            if (dragEndTimeout.current) {
                window.clearTimeout(dragEndTimeout.current)
            }
            scrollContainerRef.current = null
            scrollContainerRectRef.current = null
        }
    }, [])

    // Scroll the dashboard to the bottom when the logic requests it (e.g. after adding tiles).
    // Two animation frames let React commit and react-grid-layout grow the container before we measure.
    useEffect(() => {
        if (scrollToBottomSignal === lastScrollSignalRef.current) {
            return
        }
        lastScrollSignalRef.current = scrollToBottomSignal

        let secondFrame = 0
        const firstFrame = requestAnimationFrame(() => {
            secondFrame = requestAnimationFrame(() => {
                const scrollContainer = document.getElementById('main-content')
                scrollContainer?.scrollTo({ top: scrollContainer.scrollHeight, behavior: 'smooth' })
            })
        })
        return () => {
            cancelAnimationFrame(firstFrame)
            cancelAnimationFrame(secondFrame)
        }
    }, [scrollToBottomSignal])
    const className = clsx({
        'dashboard-view-mode mb-8': !layoutEditMode,
        // In edit mode, dragging is bounded to the grid's own clientHeight, which is exactly the
        // content height — so there's nowhere to drag a tile into to create a new bottom row.
        // box-content + padding-bottom grows clientHeight (padding only counts under content-box,
        // since preflight defaults everything to border-box), opening up draggable space below the
        // last tile that scales with content. A margin wouldn't work — it sits outside clientHeight.
        'dashboard-edit-mode box-content pb-[40vh]': layoutEditMode,
    })

    const { width, containerRef, mounted } = useContainerWidth()
    const { gridCompactor, handleLayoutChange, interactionInProgress, startInteraction, finishInteraction } =
        useDashboardLayoutInteraction({
            layoutEditMode,
            layoutCompaction: dashboard?.customization?.layout_compaction,
            updateLayouts,
        })

    // Debounce width changes to the grid. Rapidly crossing the width causes tiles to stay squashed at 1-column
    // width. Debouncing avoids this and reduces unnecessary re-layouts during resize.
    const [gridWidth, setGridWidth] = useState(width)
    useEffect(() => {
        const timer = setTimeout(() => setGridWidth(width), 100)
        return () => clearTimeout(timer)
    }, [width])

    useEffect(() => {
        if (!mounted || !containerRef.current) {
            return
        }

        const element = containerRef.current
        const observer = new ResizeObserver((entries) => {
            // Skip per-frame height commits during a gesture — they re-render every tile just for GridBackground,
            // lagging the cursor. flushPendingLayouts remeasures on stop.
            if (interactionInProgress.current) {
                return
            }
            for (const entry of entries) {
                if (entry.target === element) {
                    setContainerHeight(entry.contentRect.height)
                }
            }
        })

        // Set initial height
        setContainerHeight(element.clientHeight)
        observer.observe(element)

        return () => {
            observer.disconnect()
        }
    }, [mounted, containerRef])
    const isMobileView = !!width && width <= BREAKPOINTS['sm']
    const isEditablePlacement = [
        DashboardPlacement.Dashboard,
        DashboardPlacement.ProjectHomepage,
        DashboardPlacement.Builtin,
    ].includes(placement)

    const canEnterEditModeFromEdge =
        !!dashboard && canEditDashboard && !layoutEditMode && !isMobileView && isEditablePlacement

    const isLayoutZoomToggled = layoutEditMode && layoutZoom !== 1

    const effectiveZoom = layoutEditMode ? layoutZoom : 1
    const rowHeight = BASE_ROW_HEIGHT * effectiveZoom
    const spacingFactor = effectiveZoom < 1 ? 0.9 : 1
    const gridGap = getDashboardTileSpacingGap(dashboard?.customization?.tile_spacing)
    const margin = useMemo(
        () => BASE_MARGIN.map(() => gridGap * spacingFactor) as [number, number],
        [gridGap, spacingFactor]
    )

    const getInsertMenuItems = useCallback(
        (targetX: number, targetY: number, targetW?: number): LemonMenuItems =>
            dashboard
                ? getAddTileMenuItems({
                      dashboardId: dashboard.id,
                      dashboardWidgetsEnabled,
                      onAddInsight: showAddInsightToDashboardModal,
                      push,
                      setAddWidgetModalOpen,
                      onBeforeSelect: () => setPendingInsertion({ x: targetX, y: targetY, w: targetW ?? null }),
                  })
                : [],
        [
            dashboard,
            dashboardWidgetsEnabled,
            showAddInsightToDashboardModal,
            push,
            setAddWidgetModalOpen,
            setPendingInsertion,
        ]
    )

    const showResizeHandles = layoutEditMode && !isMobileView && isEditablePlacement && !isLayoutZoomToggled
    const showEditingControls = isEditablePlacement || layoutEditMode
    const showDetailsControls =
        placement !== DashboardPlacement.Export &&
        placement !== DashboardPlacement.Public &&
        !getCurrentExporterData()?.hideExtraDetails

    const dragConfig = useMemo(
        () => ({
            enabled: layoutEditMode && !isMobileView,
            handle: '.CardMeta,.TextCard__body,.ButtonTileCard__body,.WidgetCard__header,.drag-handle',
            cancel: 'a,table,button,input,.Popover',
            bounded: true,
        }),
        [layoutEditMode, isMobileView]
    )

    const resizeConfig = useMemo(
        () => ({
            enabled: layoutEditMode && !isMobileView && !isLayoutZoomToggled,
            handles: ['s', 'e', 'se', 'n', 'w', 'nw', 'ne', 'sw'] as const,
        }),
        [layoutEditMode, isMobileView, isLayoutZoomToggled]
    )

    useResizeHandleScrollbarPassThrough(layoutEditMode && !isMobileView)

    const onEnterEditModeFromEdge = useMemo(
        () =>
            canEnterEditModeFromEdge
                ? (e: React.MouseEvent<HTMLDivElement>, edge: EditModeEdge) => {
                      setDashboardMode(DashboardMode.Edit, DashboardEventSource.CardEdgeHover)
                      // continue the press into a live resize so the user doesn't have to release and grab again
                      continueResizeGestureInEditMode(e, edge)
                  }
                : undefined,
        [canEnterEditModeFromEdge, setDashboardMode]
    )

    const onDragHandleMouseDown = useMemo(
        () =>
            canEnterEditModeFromEdge
                ? (e: React.MouseEvent) => {
                      const target = e.target as Element | null
                      if (!target) {
                          return
                      }

                      const gridItem = target.closest('.react-grid-item')
                      if (!gridItem) {
                          return
                      }

                      // Don't trigger when clicking obvious interactive controls or readonly rich text (TipTap/LemonMarkdown).
                      if (
                          target.closest(
                              'input,textarea,button,select,a,p,h4,[contenteditable="true"],[role="textbox"],.ProseMirror,.LemonMarkdown'
                          )
                      ) {
                          return
                      }
                      e.preventDefault()
                      e.stopPropagation()
                      setDashboardMode(DashboardMode.Edit, DashboardEventSource.CardDragHandle)
                      // continue the press into a live drag so the user doesn't have to release and grab again
                      continueDragGestureInEditMode(e)
                  }
                : undefined,
        [canEnterEditModeFromEdge, setDashboardMode]
    )

    const requireDashboardId = useCallback(
        (action: string): number => {
            if (!dashboard) {
                throw new Error(`must be on a dashboard to ${action}`)
            }
            return dashboard.id
        },
        [dashboard]
    )

    const flushPendingLayouts = useCallback(() => {
        finishInteraction()
        // Remeasure once the gesture settles, since height updates were suppressed during it.
        requestAnimationFrame(() => {
            if (containerRef.current) {
                setContainerHeight(containerRef.current.clientHeight)
            }
        })
        // oxlint-disable-next-line react-hooks/exhaustive-deps -- ref reads inside requestAnimationFrame aren't valid deps
    }, [finishInteraction])

    const handleWidthChange = useCallback(
        (containerWidth: number, _: unknown, newCols: number) => {
            updateContainerWidth(containerWidth, newCols)
        },
        [updateContainerWidth]
    )

    const handleResizeStart = useCallback(
        (layout: Layout, _oldItem: LayoutItem | null, newItem: LayoutItem | null) => {
            if (!newItem) {
                return
            }
            startInteraction(layout, newItem, 'resize')
        },
        [startInteraction]
    )

    const handleResize = useCallback((_layout: any, _oldItem: any, newItem: any) => {
        // Setting state to the same id bails out of re-rendering, so this only re-renders once per gesture.
        setResizingTileId(newItem.i)
    }, [])

    const handleResizeStop = useCallback(() => {
        setResizingTileId(null)
        flushPendingLayouts()
        if (dashboard?.id) {
            reportDashboardTileRepositioned(dashboard.id, 'resized', effectiveZoom)
        }
    }, [dashboard?.id, reportDashboardTileRepositioned, effectiveZoom, flushPendingLayouts])

    const handleDragStart = useCallback(
        (layout: Layout, _oldItem: LayoutItem | null, newItem: LayoutItem | null) => {
            if (!newItem) {
                return
            }
            startInteraction(layout, newItem, 'drag')
            scrollContainerRef.current = document.getElementById('main-content')
            scrollContainerRectRef.current = scrollContainerRef.current?.getBoundingClientRect() ?? null
        },
        [startInteraction]
    )

    const handleDrag = useCallback(
        (_layout: unknown, _oldItem: unknown, _newItem: unknown, _placeholder: unknown, e: unknown) => {
            isDragging.current = true
            if (dragEndTimeout.current) {
                window.clearTimeout(dragEndTimeout.current)
            }
            if (scrollAnimationRef.current) {
                cancelAnimationFrame(scrollAnimationRef.current)
                scrollAnimationRef.current = null
            }

            const scrollContainer = scrollContainerRef.current
            const containerRect = scrollContainerRectRef.current
            if (!scrollContainer || !containerRect) {
                return
            }

            const mouseY = (e as MouseEvent).clientY

            let scrollSpeed = 0
            if (mouseY < containerRect.top + DRAG_AUTO_SCROLL_THRESHOLD) {
                scrollSpeed = -DRAG_AUTO_SCROLL_SPEED
            } else if (mouseY > containerRect.bottom - DRAG_AUTO_SCROLL_THRESHOLD) {
                scrollSpeed = DRAG_AUTO_SCROLL_SPEED
            }

            if (scrollSpeed !== 0) {
                const scroll = (): void => {
                    const atTop = scrollSpeed < 0 && scrollContainer.scrollTop === 0
                    const atBottom =
                        scrollSpeed > 0 &&
                        scrollContainer.scrollTop + scrollContainer.clientHeight >= scrollContainer.scrollHeight
                    if (atTop || atBottom) {
                        return
                    }
                    scrollContainer.scrollBy(0, scrollSpeed)
                    scrollAnimationRef.current = requestAnimationFrame(scroll)
                }
                scrollAnimationRef.current = requestAnimationFrame(scroll)
            }
        },
        []
    )

    const handleDragStop = useCallback(() => {
        if (scrollAnimationRef.current) {
            cancelAnimationFrame(scrollAnimationRef.current)
            scrollAnimationRef.current = null
        }
        scrollContainerRef.current = null
        scrollContainerRectRef.current = null
        if (dragEndTimeout.current) {
            window.clearTimeout(dragEndTimeout.current)
        }
        dragEndTimeout.current = window.setTimeout(() => {
            isDragging.current = false
        }, 250)
        flushPendingLayouts()
        if (dashboard?.id) {
            reportDashboardTileRepositioned(dashboard.id, 'moved', effectiveZoom)
        }
    }, [dashboard?.id, reportDashboardTileRepositioned, effectiveZoom, flushPendingLayouts])

    return (
        <div className="dashboard-items-wrapper" ref={containerRef as RefObject<HTMLDivElement>}>
            {layoutEditMode && isMobileView && (
                <LemonBanner type="warning" className="mb-4">
                    Layout editing is disabled on smaller screens. Please zoom out or use a larger screen to move or
                    resize tiles.
                </LemonBanner>
            )}
            {mounted && (
                <div className="relative">
                    {layoutEditMode && !isMobileView && (
                        <GridBackground
                            width={gridWidth}
                            cols={BREAKPOINT_COLUMN_COUNTS.sm}
                            rowHeight={rowHeight}
                            margin={margin}
                            containerPadding={CONTAINER_PADDING}
                            rows="auto"
                            height={containerHeight} // kept in sync via ResizeObserver
                            color="var(--color-bg-surface-secondary)"
                        />
                    )}

                    <ReactGridLayout
                        width={gridWidth}
                        className={className}
                        dragConfig={dragConfig}
                        resizeConfig={resizeConfig}
                        layouts={layouts as Partial<Record<DashboardLayoutSize, Layout>>}
                        compactor={gridCompactor}
                        rowHeight={rowHeight}
                        margin={margin}
                        containerPadding={CONTAINER_PADDING}
                        onLayoutChange={handleLayoutChange}
                        onWidthChange={handleWidthChange}
                        breakpoints={BREAKPOINTS}
                        cols={BREAKPOINT_COLUMN_COUNTS}
                        onResizeStart={handleResizeStart}
                        onResize={handleResize}
                        onResizeStop={handleResizeStop}
                        onDragStart={handleDragStart}
                        onDrag={handleDrag}
                        onDragStop={handleDragStop}
                    >
                        {tiles?.map((tile) => {
                            const { insight, text, button_tile, widget } = tile
                            const smLayout = layouts['sm']?.find((l) => {
                                return l.i == tile.id.toString()
                            })

                            const commonTileProps = {
                                dashboardId: dashboard?.id,
                                showResizeHandles,
                                canEnterEditModeFromEdge,
                                onEnterEditModeFromEdge,
                                onDragHandleMouseDown,
                                showEditingControls,
                                moveToDashboard: ({ id, name }: Pick<DashboardType, 'id' | 'name'>) => {
                                    moveToDashboard(tile, requireDashboardId('move this tile'), id, name)
                                },
                                copyToDashboard: ({ id, name }: Pick<DashboardType, 'id' | 'name'>) => {
                                    copyToDashboard(tile, requireDashboardId('copy this tile'), id, name)
                                },
                                removeFromDashboard: () => removeTile(tile),
                            }

                            if (tile.error && !insight) {
                                return (
                                    <MemoizedDashboardErrorTileItem
                                        key={tile.id}
                                        tile={tile}
                                        onRetry={retryFailedDashboardTile}
                                        retryLoading={dashboardLoading}
                                        placement={placement}
                                        onRemove={commonTileProps.removeFromDashboard}
                                        showResizeHandles={showResizeHandles}
                                        canEnterEditModeFromEdge={canEnterEditModeFromEdge}
                                        onEnterEditModeFromEdge={onEnterEditModeFromEdge}
                                        onDragHandleMouseDown={onDragHandleMouseDown}
                                        showEditingControls={showEditingControls}
                                    />
                                )
                            }

                            if (insight) {
                                // Check if this insight has an error from the server
                                const isErrorTile = !!tile.error
                                const queryError = getInsightQueryError(insight)
                                const apiErrored =
                                    isErrorTile || !!queryError || refreshStatus[insight.short_id]?.errored || false
                                const refreshError = refreshStatus[insight.short_id]?.error
                                const apiError = isErrorTile
                                    ? new ApiError(undefined, 500, undefined, {
                                          detail: tile.error!.message,
                                          code: 'dashboard_tile_error',
                                      })
                                    : refreshError || queryError || undefined
                                const loadingQueued = isErrorTile ? false : isRefreshingQueued(insight.short_id)
                                const loading = isErrorTile ? false : isRefreshing(insight.short_id)

                                return (
                                    <MemoizedInsightCard
                                        key={tile.id}
                                        tile={tile}
                                        insight={insight}
                                        loadingQueued={loadingQueued}
                                        loading={loading}
                                        apiErrored={apiErrored}
                                        apiError={apiError}
                                        queryId={insight.query_status?.id}
                                        highlighted={highlightedInsightId && insight.short_id === highlightedInsightId}
                                        updateColor={(color) => updateTileColor(tile.id, color)}
                                        toggleShowDescription={() => toggleTileDescription(tile.id)}
                                        ribbonColor={tile.color}
                                        refresh={
                                            refreshDashboardTile ? () => refreshDashboardTile({ tile }) : undefined
                                        }
                                        rename={() => renameInsight(insight)}
                                        duplicate={() => duplicateTile(tile)}
                                        setOverride={() => setTileOverride(tile)}
                                        showDetailsControls={showDetailsControls}
                                        placement={placement}
                                        loadPriority={smLayout ? smLayout.y * 1000 + smLayout.x : undefined}
                                        isResizing={resizingTileId === tile.id.toString()}
                                        filtersOverride={effectiveEditBarFilters}
                                        variablesOverride={effectiveDashboardVariableOverrides}
                                        // :HACKY: The two props below aren't actually used in the component, but are needed to trigger a re-render
                                        breakdownColorOverride={effectiveBreakdownColors}
                                        dataColorThemeId={dataColorThemeId}
                                        surveyOpportunity={tile.id === bestSurveyOpportunityFunnel?.id}
                                        showCreateAnomalyAlertButton={showCreateAnomalyAlertButton}
                                        {...commonTileProps}
                                    />
                                )
                            }

                            if (text) {
                                return (
                                    <MemoizedDashboardTextItem
                                        key={tile.id}
                                        tile={tile}
                                        placement={placement}
                                        dashboardId={dashboard?.id}
                                        onEdit={() => {
                                            if (dashboard?.id) {
                                                push(urls.dashboardTextTile(dashboard.id, tile.id))
                                            }
                                        }}
                                        onMoveToDashboard={commonTileProps.moveToDashboard}
                                        onCopyToDashboard={commonTileProps.copyToDashboard}
                                        onDuplicate={() => duplicateTile(tile)}
                                        onRemove={commonTileProps.removeFromDashboard}
                                        showResizeHandles={commonTileProps.showResizeHandles}
                                        showEditingControls={commonTileProps.showEditingControls}
                                        canEnterEditModeFromEdge={commonTileProps.canEnterEditModeFromEdge}
                                        onEnterEditModeFromEdge={commonTileProps.onEnterEditModeFromEdge}
                                        onDragHandleMouseDown={commonTileProps.onDragHandleMouseDown}
                                    />
                                )
                            }

                            if (button_tile) {
                                return (
                                    <MemoizedDashboardButtonTileItem
                                        key={tile.id}
                                        tile={tile}
                                        placement={placement}
                                        dashboardId={dashboard?.id}
                                        isDraggingRef={isDragging}
                                        onEdit={() => {
                                            if (dashboard?.id) {
                                                push(urls.dashboardButtonTile(dashboard.id, tile.id))
                                            }
                                        }}
                                        onMoveToDashboard={commonTileProps.moveToDashboard}
                                        onDuplicate={() => duplicateTile(tile)}
                                        onRemove={commonTileProps.removeFromDashboard}
                                        showResizeHandles={commonTileProps.showResizeHandles}
                                        showEditingControls={commonTileProps.showEditingControls}
                                        canEnterEditModeFromEdge={commonTileProps.canEnterEditModeFromEdge}
                                        onEnterEditModeFromEdge={commonTileProps.onEnterEditModeFromEdge}
                                        onDragHandleMouseDown={commonTileProps.onDragHandleMouseDown}
                                    />
                                )
                            }

                            if (widget && dashboardWidgetsEnabled && isWidgetTileVisibleOnPlacement(placement)) {
                                const runResult = widgetResultsByTileId[tile.id]
                                const refreshState = widgetRefreshStatus[tile.id]

                                return (
                                    <MemoizedDashboardWidgetItem
                                        key={tile.id}
                                        tile={tile}
                                        placement={placement}
                                        dashboardId={dashboard?.id}
                                        canEditDashboard={canEditDashboard}
                                        isDashboardEditMode={dashboardMode === DashboardMode.Edit}
                                        result={runResult?.result}
                                        error={getDashboardWidgetFetchDisplayError(
                                            runResult?.error ?? refreshState?.error
                                        )}
                                        loading={!!refreshState?.loading}
                                        lastFetchedAt={refreshState?.fetchedAt}
                                        onRefresh={() =>
                                            refreshDashboardWidgets({ tileIds: [tile.id], forceRefresh: true })
                                        }
                                        onRefreshWidgetData={scheduleRefreshDashboardWidgets}
                                        onApplyWidgetIssueMetadataChange={(tileId, issueId, delta, context) => {
                                            applyWidgetIssueMetadataChange({
                                                tileId,
                                                issueId,
                                                delta,
                                                context,
                                            })
                                        }}
                                        onUpdateWidgetTile={async (patch) => {
                                            await updateWidgetTile({ tile, ...patch })
                                        }}
                                        toggleShowDescription={() => toggleTileDescription(tile.id)}
                                        onDuplicate={() => duplicateTile(tile)}
                                        onRemove={commonTileProps.removeFromDashboard}
                                        onMoveToDashboard={commonTileProps.moveToDashboard}
                                        onCopyToDashboard={commonTileProps.copyToDashboard}
                                        showResizeHandles={commonTileProps.showResizeHandles}
                                        showEditingControls={commonTileProps.showEditingControls}
                                        canEnterEditModeFromEdge={commonTileProps.canEnterEditModeFromEdge}
                                        onEnterEditModeFromEdge={commonTileProps.onEnterEditModeFromEdge}
                                        onDragHandleMouseDown={commonTileProps.onDragHandleMouseDown}
                                    />
                                )
                            }
                        })}
                    </ReactGridLayout>
                    {isEditablePlacement && (
                        <InsertTileOverlay
                            layout={layouts['sm']}
                            gridWidth={gridWidth}
                            cols={BREAKPOINT_COLUMN_COUNTS.sm}
                            rowHeight={rowHeight}
                            marginX={margin[0]}
                            marginY={margin[1]}
                            canEditDashboard={canEditDashboard}
                            isMobileView={isMobileView}
                            disabled={resizingTileId !== null}
                            getMenuItems={getInsertMenuItems}
                            onMenuOpen={() => {
                                if (dashboard?.id) {
                                    reportDashboardAddMenuOpened('inline', dashboard.id)
                                }
                            }}
                        />
                    )}
                </div>
            )}
            {dashboardStreaming && (
                <div className="mt-4 flex items-center justify-center">
                    <div className="flex items-center gap-2 text-muted">
                        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-blue-600" />
                        <span>Loading tiles...</span>
                    </div>
                </div>
            )}
        </div>
    )
}
