module github.com/dapr/dapr/tests/apps/service_invocation_grpc_proxy_client

go 1.26.6

require (
	github.com/dapr/dapr v0.0.0-00010101000000-000000000000
	github.com/gorilla/mux v1.8.1
	google.golang.org/grpc v1.82.1
	google.golang.org/grpc/examples v0.0.0-20250407062114-b368379ef8f6
)

require (
	github.com/cespare/xxhash/v2 v2.3.0 // indirect
	github.com/google/uuid v1.6.0 // indirect
	go.opentelemetry.io/otel v1.44.0 // indirect
	golang.org/x/net v0.58.0 // indirect
	golang.org/x/sys v0.47.0 // indirect
	golang.org/x/text v0.41.0 // indirect
	google.golang.org/genproto/googleapis/rpc v0.0.0-20260727163830-6c54dddc4772 // indirect
	google.golang.org/protobuf v1.36.11 // indirect
)

replace github.com/dapr/dapr => ../../../
