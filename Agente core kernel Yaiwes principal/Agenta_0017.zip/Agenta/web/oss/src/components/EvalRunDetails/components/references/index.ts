/**
 * Evaluation-specific reference components.
 * These wrap the generic Reference components and provide projectId from evaluation context.
 *
 * Use these components within EvalRunDetails2 context.
 * For generic usage outside evaluation context, use @/oss/components/References directly.
 */
export {
    ApplicationReferenceLabel,
    QueryReferenceLabel,
    TestsetTag,
    TestsetTagList,
    VariantReferenceLabel,
    VariantReferenceText,
    VariantRevisionLabel,
} from "./EvalReferenceLabels"
