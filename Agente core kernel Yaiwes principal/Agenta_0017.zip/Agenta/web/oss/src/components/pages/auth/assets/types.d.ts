import {AuthErrorMsgType} from "@/oss/lib/Types"

export interface EmailPasswordAuthProps {
    message: AuthErrorMsgType
    setMessage: React.Dispatch<React.SetStateAction<AuthErrorMsgType>>
    authErrorMsg: (error: any) => void
    initialEmail?: string
    lockEmail?: boolean
}

export interface SendOTPProps {
    message: AuthErrorMsgType
    email: string
    setMessage: React.Dispatch<React.SetStateAction<AuthErrorMsgType>>
    authErrorMsg: (error: any) => void
    setIsLoginCodeVisible: React.Dispatch<React.SetStateAction<boolean>>
    isInvitedUser: boolean
}

export interface PasswordlessAuthProps {
    message: AuthErrorMsgType
    email: string
    setEmail: React.Dispatch<React.SetStateAction<string>>
    setMessage: React.Dispatch<React.SetStateAction<AuthErrorMsgType>>
    authErrorMsg: (error: any) => void
    setIsLoginCodeVisible: React.Dispatch<React.SetStateAction<boolean>>
    disabled: boolean
    lockEmail?: boolean
}

export interface SocialAuthProps {
    isLoading: boolean
    authErrorMsg: (error: any) => void
    setIsLoading: React.Dispatch<React.SetStateAction<boolean>>
    disabled: boolean
    providers: {
        id: string
        label: string
        icon?: React.ReactNode
    }[]
    // "promoted" = taller, stronger ring (returning last-used slot).
    variant?: "default" | "promoted"
    // Yellow keycap treatment (the one primary action on the screen).
    yellow?: boolean
    // Tags exactly one provider with the inline "Last used" badge.
    lastUsedProviderId?: string
}
