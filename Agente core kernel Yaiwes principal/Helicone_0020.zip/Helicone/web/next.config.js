const withBundleAnalyzer = require("@next/bundle-analyzer")({
  enabled: process.env.ANALYZE === "true",
});

const { configureRuntimeEnv } = require("next-runtime-env/build/configure");

configureRuntimeEnv();

/** @type {import('next').NextConfig} */
const nextConfig = {
  eslint: {
    ignoreDuringBuilds: true,
  },
  images: {
    remotePatterns: [
      {
        protocol: "https",
        hostname: "**.helicone.ai",
      },
      {
        protocol: "https",
        hostname: "**.vercel.app",
      },
      {
        protocol: "https",
        hostname: "**.amazonaws.com",
      },
      {
        protocol: "https",
        hostname: "img.shields.io",
      },
      {
        protocol: "https",
        hostname: "avatars.githubusercontent.com",
      },
      {
        protocol: "https",
        hostname: "lh3.googleusercontent.com",
      },
    ],
  },
  reactStrictMode: false,
  swcMinify: true,
  transpilePackages: ["@helicone-package/cost", "@helicone-package/llm-mapper"],
  async redirects() {
    return [
      {
        source: "/api/graphql/download-schema",
        destination: "/api-public-schema.graphql",
        permanent: true,
      },
      {
        source: "/open-stats",
        destination: "https://helicone.ai",
        permanent: true,
      },
    ];
  },
  async rewrites() {
    return [
      {
        source: "/ingest/:path*",
        destination: "https://app.posthog.com/:path*",
      },
    ];
  },
  experimental: {
    // appDir and runtime options have been removed as they're no longer needed in Next.js 14
  },
};

module.exports = withBundleAnalyzer(nextConfig);

// Injected content via Sentry wizard below
if (process.env.REGION === "us") {
  // const { withSentryConfig } = require("@sentry/nextjs");
  // module.exports = withSentryConfig(module.exports, {
  //   // For all available options, see:
  //   // https://github.com/getsentry/sentry-webpack-plugin#options
  //   org: "helicone-ai",
  //   project: "javascript-nextjs",
  //   authToken: process.env.SENTRY_AUTH_TOKEN,
  //   // Only print logs for uploading source maps in CI
  //   silent: !process.env.CI,
  //   // For all available options, see:
  //   // https://docs.sentry.io/platforms/javascript/guides/nextjs/manual-setup/
  //   // Upload a larger set of source maps for prettier stack traces (increases build time)
  //   widenClientFileUpload: true,
  //   // Automatically annotate React components to show their full name in breadcrumbs and session replay
  //   reactComponentAnnotation: {
  //     enabled: true,
  //   },
  //   // Route browser requests to Sentry through a Next.js rewrite to circumvent ad-blockers.
  //   // This can increase your server load as well as your hosting bill.
  //   // Note: Check that the configured route will not match with your Next.js middleware, otherwise reporting of client-
  //   // side errors will fail.
  //   tunnelRoute: "/monitoring",
  //   // Hides source maps from generated client bundles
  //   hideSourceMaps: true,
  //   // Automatically tree-shake Sentry logger statements to reduce bundle size
  //   disableLogger: true,
  //   // Enables automatic instrumentation of Vercel Cron Monitors. (Does not yet work with App Router route handlers.)
  //   // See the following for more information:
  //   // https://docs.sentry.io/product/crons/
  //   // https://vercel.com/docs/cron-jobs
  //   automaticVercelMonitors: true,
  // });
}
