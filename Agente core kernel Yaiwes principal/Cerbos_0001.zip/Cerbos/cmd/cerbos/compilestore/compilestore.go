// Copyright 2021-2026 Zenauth Ltd.
// SPDX-License-Identifier: Apache-2.0

package compilestore

import (
	"context"
	"errors"
	"fmt"
	"maps"
	"os"
	"os/signal"
	"slices"
	"strings"

	"github.com/alecthomas/kong"
	"github.com/fatih/color"
	"github.com/pterm/pterm"
	"helm.sh/helm/v3/pkg/strvals"

	internalcompile "github.com/cerbos/cerbos/cmd/cerbos/internal/compilation"
	"github.com/cerbos/cerbos/cmd/cerbos/internal/flagset"
	"github.com/cerbos/cerbos/cmd/cerbos/internal/lint"
	"github.com/cerbos/cerbos/internal/compile"
	"github.com/cerbos/cerbos/internal/config"
	"github.com/cerbos/cerbos/internal/outputcolor"
	"github.com/cerbos/cerbos/internal/printer"
	"github.com/cerbos/cerbos/internal/printer/colored"
	"github.com/cerbos/cerbos/internal/storage"
	"github.com/cerbos/cerbos/internal/storage/db"
	"github.com/cerbos/cerbos/internal/storage/index"
)

const (
	help = `
Examples:

# Compile store

cerbos compile-store /path/to/cerbos/config.yaml
cerbos compile-store --output=json /path/to/cerbos/config.yaml

# Compile database store and disable invalid policies

cerbos compile-store --disable-invalid /path/to/cerbos/config.yaml
cerbos compile-store --disable-invalid --output=json /path/to/cerbos/config.yaml
`
)

//nolint:govet
type Cmd struct { //betteralign:ignore
	Config         string   `help:"Path to config file" arg:"" required:"" type:"existingfile" placeholder:".cerbos.yaml" env:"CERBOS_CONFIG"`
	Set            []string `help:"Config overrides" placeholder:"server.adminAPI.enabled=true"`
	DisableInvalid bool     `help:"Disable invalid policies if database store" placeholder:"false"`
	AssumeYes      bool     `help:"Answer yes to all confirmation questions" placeholder:"false"`
	flagset.Format
	flagset.Color
}

func (c *Cmd) Run(k *kong.Kong) error {
	if err := c.loadConfig(); err != nil {
		return err
	}

	ctx, stopFunc := signal.NotifyContext(context.Background(), os.Interrupt)
	defer stopFunc()

	colorLevel := c.Level.Resolve(c.Disable)
	color.NoColor = !colorLevel.Enabled()
	if colorLevel.Enabled() {
		pterm.EnableColor()
	} else {
		pterm.DisableColor()
	}

	p := printer.New(k.Stdout, k.Stderr)
	cm, disable, err := c.compileManager(ctx)
	if err != nil {
		if idxErr, ok := errors.AsType[*index.BuildError](err); ok {
			return lint.Display(p, idxErr, c.Format, colorLevel)
		}

		return err
	}

	var compErr *compile.ErrorSet
	if err := cm.CompileAll(ctx); err != nil && !errors.As(err, &compErr) {
		return fmt.Errorf("failed to compile policies: %w", err)
	} else if err == nil {
		return nil
	}

	if !c.DisableInvalid {
		return internalcompile.Display(p, *compErr, c.Format, colorLevel)
	}

	policyKeys := make(map[string][]errWithDesc)
	for _, err := range compErr.Errors().GetErrors() {
		key := err.GetFile()
		policyKeys[key] = append(policyKeys[key], errWithDesc{Err: err.GetError(), Description: err.GetDescription()})
	}

	if len(policyKeys) == 0 {
		return nil
	}

	return c.disableInvalidPolicies(ctx, p, colorLevel, disable, policyKeys)
}

type errWithDesc struct {
	Err         string `json:"error"`
	Description string `json:"description"`
}

func (c *Cmd) loadConfig() error {
	confOverrides := map[string]any{}
	for _, override := range c.Set {
		if err := strvals.ParseInto(override, confOverrides); err != nil {
			return fmt.Errorf("failed to parse config override [%s]: %w", override, err)
		}
	}

	if err := config.Load(c.Config, confOverrides); err != nil {
		return fmt.Errorf("failed to load configuration: %w", err)
	}

	return nil
}

type disableFn func(ctx context.Context, policyKey ...string) (disabledPolicies uint32, err error)

func (c *Cmd) compileManager(ctx context.Context) (*compile.Manager, disableFn, error) {
	store, err := storage.New(ctx)
	if err != nil {
		return nil, nil, fmt.Errorf("failed to create store: %w", err)
	}

	var fn disableFn
	ss, ok := store.(storage.SourceStore)
	if !ok {
		return nil, nil, fmt.Errorf("the configured store is not a source store")
	}

	if ms, ok := store.(storage.MutableStore); ok {
		fn = ms.Disable
	} else if c.DisableInvalid {
		return nil, nil, errors.New("--disable-invalid flag is only supported by mutable stores")
	}

	cm, err := compile.NewManager(ctx, ss)
	if err != nil {
		return nil, nil, fmt.Errorf("failed to create compile manager: %w", err)
	}

	return cm, fn, nil
}

func (c *Cmd) disableInvalidPolicies(ctx context.Context, p *printer.Printer, colorLevel outputcolor.Level, disable disableFn, policyKeys map[string][]errWithDesc) error {
	var confirmed bool
	if c.AssumeYes {
		confirmed = true
	} else {
		confirmed = confirm(ctx, p, policyKeys, "The following policies will be disabled")
	}

	if !confirmed {
		return nil
	}

	for {
		_, err := disable(ctx, slices.Collect(maps.Keys(policyKeys))...)
		if err == nil {
			return display(p, c.Format, colorLevel, policyKeys)
		}

		integrityErr, ok := errors.AsType[*db.IntegrityErr](err)
		if !ok {
			return fmt.Errorf("failed to disable policies: %w", err)
		}

		for invalidPolicyKey, ierr := range integrityErr.Errors {
			if ierr.GetBreaksScopeChain() != nil {
				for _, descendant := range ierr.GetBreaksScopeChain().GetDescendants() {
					policyKeys[descendant] = append(policyKeys[descendant], errWithDesc{
						Err:         "descendant of invalid scope policy",
						Description: fmt.Sprintf("Policy %s is invalid and all of its descendants should be disabled to avoid breaking the scope chain", invalidPolicyKey),
					})
				}
			}

			if ierr.GetRequiredByOtherPolicies() != nil {
				for _, dependents := range ierr.GetRequiredByOtherPolicies().GetDependents() {
					policyKeys[dependents] = append(policyKeys[dependents], errWithDesc{
						Err:         "dependant of invalid policy",
						Description: fmt.Sprintf("This policy depends on %s which is invalid", invalidPolicyKey),
					})
				}
			}
		}

		if c.AssumeYes {
			confirmed = true
		} else {
			confirmed = confirm(ctx, p, policyKeys, "The following additional policies will be disabled")
		}

		if !confirmed {
			return nil
		}
	}
}

func (c *Cmd) Help() string {
	return help
}

func confirm(ctx context.Context, p *printer.Printer, policyKeys map[string][]errWithDesc, title string) bool {
	policies := slices.Collect(maps.Keys(policyKeys))
	slices.Sort(policies)

	p.Println(colored.Header(title))
	for _, policyKey := range policies {
		p.Println(colored.PolicyKey(policyKey))
		for _, err := range policyKeys[policyKey] {
			p.Printf(" - %s: %s\n", err.Err, colored.ErrorMsg(err.Description))
		}
	}
	p.Printf("\nDo you want to continue [y/n]?: ")

	ch := make(chan string, 1)
	go func() {
		defer close(ch)

		var input string
		if _, err := fmt.Fscan(os.Stdin, &input); err != nil {
			input = "no"
		}
		ch <- input
	}()

	var input string
	select {
	case input = <-ch:
		input = strings.ToLower(input)
	case <-ctx.Done():
		return false
	}

	if input == "y" || input == "yes" {
		return true
	}

	return false
}
