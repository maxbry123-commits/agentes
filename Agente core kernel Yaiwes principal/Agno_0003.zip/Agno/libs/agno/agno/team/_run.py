"""Run lifecycle and sync/async execution trait for Team."""

from __future__ import annotations

import asyncio
import contextlib
import time
from collections import deque
from time import time as unix_time
from typing import (
    TYPE_CHECKING,
    Any,
    AsyncIterator,
    Dict,
    Iterator,
    List,
    Literal,
    Optional,
    Sequence,
    Set,
    Tuple,
    Type,
    Union,
    cast,
)
from uuid import uuid4

from pydantic import BaseModel

from agno.agent._tools import result_store_kwargs
from agno.exceptions import (
    InputCheckError,
    OutputCheckError,
    RunCancelledException,
    RunNotContinuableError,
    RunNotFoundError,
)
from agno.filters import FilterExpr
from agno.media import Audio, File, Image, Video
from agno.metrics import RunMetrics, merge_background_metrics
from agno.models.base import Model
from agno.models.fallback import acall_model_with_fallback, call_model_with_fallback
from agno.models.message import Message
from agno.models.response import ModelResponse, ToolExecution
from agno.run import RunContext, RunStatus
from agno.run.agent import (
    RunCancelledEvent as AgentRunCancelledEvent,
)
from agno.run.agent import (
    RunCompletedEvent as AgentRunCompletedEvent,
)
from agno.run.agent import (
    RunOutput,
    RunOutputEvent,
)
from agno.run.cancel import (
    acancel_run as acancel_run_global,
)
from agno.run.cancel import (
    acleanup_member_runs,
    acleanup_run,
    adrain_member_tasks,
    aget_member_run_ids,
    araise_if_cancelled,
    aregister_member_run,
    aregister_run,
    cleanup_member_runs,
    cleanup_run,
    get_member_run_ids,
    raise_if_cancelled,
    register_member_run,
    register_run,
)
from agno.run.cancel import (
    cancel_run as cancel_run_global,
)
from agno.run.concurrency import SSE_KEEPALIVE_INTERVAL_SECONDS, background_run_slot
from agno.run.messages import RunMessages
from agno.run.status_persist import apersist_run_transition
from agno.run.team import (
    RunCancelledEvent as TeamRunCancelledEvent,
)
from agno.run.team import (
    RunCompletedEvent as TeamRunCompletedEvent,
)
from agno.run.team import (
    TaskData,
    TeamRunInput,
    TeamRunOutput,
    TeamRunOutputEvent,
)
from agno.session import TeamSession
from agno.session._utils import resolve_run_index
from agno.tools.function import Function
from agno.utils.agent import (
    abuild_full_run_storage_copy,
    abuild_offloaded_storage_copy,
    await_for_open_threads,
    await_for_thread_tasks_stream,
    build_offloaded_storage_copy,
    collect_background_metrics,
    store_media_util,
    validate_input,
    validate_media_object_id,
    wait_for_open_threads,
    wait_for_thread_tasks_stream,
)
from agno.utils.events import (
    add_team_error_event,
    create_team_run_cancelled_event,
    create_team_run_completed_event,
    create_team_run_content_completed_event,
    create_team_run_error_event,
    create_team_run_started_event,
    create_team_session_summary_completed_event,
    create_team_session_summary_started_event,
    error_type_of,
    handle_event,
)
from agno.utils.hooks import (
    normalize_post_hooks,
    normalize_pre_hooks,
)
from agno.utils.log import (
    log_debug,
    log_error,
    log_info,
    log_warning,
)

# Strong references to background tasks so they aren't garbage-collected mid-execution.
# See: https://docs.python.org/3/library/asyncio-task.html#asyncio.create_task
_background_tasks: set[asyncio.Task[None]] = set()

# Cancel raises immediately on every event. Only terminal events bypass so the
# member's own cancel handler can yield them to the stream. RunError is excluded —
# in a cancel race the team's cancel wins.
_MEMBER_CANCEL_BYPASS_EVENT_TYPES = (
    AgentRunCancelledEvent,
    AgentRunCompletedEvent,
    TeamRunCancelledEvent,
    TeamRunCompletedEvent,
)

if TYPE_CHECKING:
    from agno.agent import Agent
    from agno.run.requirement import RunRequirement
    from agno.team._run_options import ResolvedRunOptions
    from agno.team.team import Team


def cancel_run(run_id: str) -> bool:
    """Cancel a running team execution.

    Also cancels any in-flight member runs spawned by this team run.

    Args:
        run_id (str): The run_id to cancel.

    Returns:
        bool: True if the run was found and marked for cancellation, False otherwise.
    """
    result = cancel_run_global(run_id)
    for member_run_id in get_member_run_ids(run_id):
        cancel_run(member_run_id)
    return result


async def acancel_run(run_id: str) -> bool:
    """Cancel a running team execution (async version).

    Also cancels any in-flight member runs spawned by this team run.

    Args:
        run_id (str): The run_id to cancel.

    Returns:
        bool: True if the run was found and marked for cancellation, False otherwise.
    """
    result = await acancel_run_global(run_id)
    for member_run_id in await aget_member_run_ids(run_id):
        await acancel_run(member_run_id)
    return result


async def _asetup_session(
    team: "Team",
    run_context: RunContext,
    session_id: str,
    user_id: Optional[str],
    run_id: Optional[str],
) -> TeamSession:
    """Read/create session, load state from DB, and resolve callable dependencies.

    Shared setup for _arun() and _arun_stream(). Mirrors what the sync
    run_dispatch() does inline before calling _run()/_run_stream().
    """
    # Read or create session
    from agno.team._init import _has_async_db, _initialize_session_state
    from agno.team._storage import (
        _aread_or_create_session,
        _load_session_state,
        _read_or_create_session,
        _update_metadata,
    )

    if _has_async_db(team):
        team_session = await _aread_or_create_session(team, session_id=session_id, user_id=user_id)
    else:
        team_session = _read_or_create_session(team, session_id=session_id, user_id=user_id)

    # Update metadata
    _update_metadata(team, session=team_session)

    # Initialize and load session state from DB
    run_context.session_state = _initialize_session_state(
        team,
        session_state=run_context.session_state if run_context.session_state is not None else {},
        user_id=user_id,
        session_id=session_id,
        run_id=run_id,
    )
    if run_context.session_state is not None:
        run_context.session_state = _load_session_state(
            team, session=team_session, session_state=run_context.session_state
        )

    # Resolve callable dependencies AFTER state is loaded
    if run_context.dependencies is not None:
        await _aresolve_run_dependencies(team, run_context=run_context)

    return team_session


def _run_tasks(
    team: "Team",
    run_response: TeamRunOutput,
    session: TeamSession,
    run_context: RunContext,
    user_id: Optional[str] = None,
    add_history_to_context: Optional[bool] = None,
    add_dependencies_to_context: Optional[bool] = None,
    add_session_state_to_context: Optional[bool] = None,
    response_format: Optional[Union[Dict, Type[BaseModel]]] = None,
    debug_mode: Optional[bool] = None,
    background_tasks: Optional[Any] = None,
    **kwargs: Any,
) -> TeamRunOutput:
    """Run the Team in autonomous task mode.

    The team leader iteratively plans and delegates tasks to members until
    the goal is complete or max_iterations is reached.
    """
    from agno.team._hooks import _execute_post_hooks, _execute_pre_hooks
    from agno.team._init import _disconnect_connectable_tools
    from agno.team._managers import _start_learning_future, _start_memory_future
    from agno.team._messages import _get_run_messages
    from agno.team._response import (
        _convert_response_to_structured_format,
        _update_run_response,
        handle_reasoning,
    )
    from agno.team._telemetry import log_team_telemetry
    from agno.team._tools import _determine_tools_for_model
    from agno.team.task import TaskStatus, load_task_list

    log_debug(f"Team Task Run Start: {run_response.run_id}", center=True)
    memory_future = None
    learning_future = None

    # Bind run_messages early so the cancellation handler can read it
    # if cancel fires before the message list is built.
    run_messages: Optional[RunMessages] = None
    try:
        run_input = cast(TeamRunInput, run_response.input)
        team.model = cast(Model, team.model)
        raise_if_cancelled(run_response.run_id)  # type: ignore

        # 1. Execute pre-hooks
        if team.pre_hooks is not None:
            pre_hook_iterator = _execute_pre_hooks(
                team,
                hooks=team.pre_hooks,  # type: ignore
                run_response=run_response,
                run_input=run_input,
                run_context=run_context,
                session=session,
                user_id=user_id,
                debug_mode=debug_mode,
                background_tasks=background_tasks,
                **kwargs,
            )
            deque(pre_hook_iterator, maxlen=0)

        # 2. Determine tools for model (includes task management tools)
        team_run_context: Dict[str, Any] = {}
        _tools = _determine_tools_for_model(
            team,
            model=team.model,
            run_response=run_response,
            run_context=run_context,
            team_run_context=team_run_context,
            session=session,
            user_id=user_id,
            async_mode=False,
            input_message=run_input.input_content,
            images=run_input.images,
            videos=run_input.videos,
            audio=run_input.audios,
            files=run_input.files,
            debug_mode=debug_mode,
            add_history_to_context=add_history_to_context,
            add_dependencies_to_context=add_dependencies_to_context,
            add_session_state_to_context=add_session_state_to_context,
            stream=False,
            stream_events=False,
        )

        # 3. Prepare initial run messages
        run_messages = _get_run_messages(
            team,
            run_response=run_response,
            session=session,
            run_context=run_context,
            user_id=user_id,
            input_message=run_input.input_content,
            audio=run_input.audios,
            images=run_input.images,
            videos=run_input.videos,
            files=run_input.files,
            add_history_to_context=add_history_to_context,
            add_dependencies_to_context=add_dependencies_to_context,
            add_session_state_to_context=add_session_state_to_context,
            tools=_tools,
            **kwargs,
        )
        if len(run_messages.messages) == 0:
            log_error("No messages to be sent to the model.")

        # 4. Start memory and learning creation in background
        memory_future = _start_memory_future(
            team,
            run_messages=run_messages,
            user_id=user_id,
            existing_future=memory_future,
        )
        learning_future = _start_learning_future(
            team,
            run_messages=run_messages,
            session=session,
            user_id=user_id,
            existing_future=learning_future,
        )

        raise_if_cancelled(run_response.run_id)  # type: ignore

        # 5. Reason about the task if reasoning is enabled
        handle_reasoning(team, run_response=run_response, run_messages=run_messages, run_context=run_context)

        raise_if_cancelled(run_response.run_id)  # type: ignore

        # Use accumulated messages for the iterative loop
        accumulated_messages = run_messages.messages

        model_response: Optional[ModelResponse] = None

        # === Iterative task loop ===
        idle_answer_turns = 0
        for iteration in range(team.max_iterations):
            n_tools_before_iteration = len(run_response.tools or [])
            log_debug(f"Task iteration {iteration + 1}/{team.max_iterations}")

            # On subsequent iterations, inject current task state as a user message
            if iteration > 0:
                task_list = load_task_list(run_context.session_state)
                task_summary = task_list.get_summary_string()
                state_message = Message(
                    role="user",
                    content=f"<current_task_state>\n{task_summary}\n</current_task_state>\n\n"
                    "Continue working on the tasks. Create, execute, or update tasks as needed. "
                    "When the goal is met, write your answer and call `mark_all_complete`.",
                )
                accumulated_messages.append(state_message)

            # Get model response
            model_response = call_model_with_fallback(
                team.model,
                team.fallback_config,
                messages=accumulated_messages,
                response_format=response_format,
                tools=_tools,
                tool_choice=team.tool_choice,
                tool_call_limit=team.tool_call_limit,
                run_response=run_response,
                send_media_to_model=team.send_media_to_model,
                compression_manager=team.compression_manager if team.compress_tool_results else None,
                **result_store_kwargs(team),
                after_tool_results=build_team_after_tool_results_callback(
                    team, run_response, session, run_messages, run_context
                ),
            )

            raise_if_cancelled(run_response.run_id)  # type: ignore

            # Update run response
            _update_run_response(
                team,
                model_response=model_response,
                run_response=run_response,
                run_messages=run_messages,
                run_context=run_context,
            )

            # Check if delegation propagated member HITL requirements
            if run_response.requirements and any(not req.is_resolved() for req in run_response.requirements):
                from agno.team import _hooks

                return _hooks.handle_team_run_paused(
                    team, run_response=run_response, session=session, run_context=run_context
                )

            # Check termination conditions
            task_list = load_task_list(run_context.session_state)
            if task_list.goal_complete:
                log_debug("Task goal marked complete, finishing task loop.")
                break

            if task_list.all_terminal():
                # All tasks done but some may have failed
                has_failures = any(t.status == TaskStatus.failed for t in task_list.tasks)
                if not has_failures:
                    log_debug("All tasks completed successfully, finishing task loop.")
                    break
                # If there are failures, continue to let model handle them
                log_debug("All tasks terminal but some failed, continuing to let model handle.")

            # A run that needs no tasks ends by answering: with an empty list, one reminder still
            # goes out, and a second turn that writes text but calls no tool is final. Without this,
            # an empty list never satisfies all_terminal and a greeting burns max_iterations.
            if not task_list.tasks:
                if len(run_response.tools or []) == n_tools_before_iteration:
                    idle_answer_turns += 1
                    if idle_answer_turns >= 2:
                        log_debug("No tasks and no tool calls for a second turn; treating the written answer as final.")
                        break
                else:
                    idle_answer_turns = 0
            else:
                idle_answer_turns = 0
        else:
            # Loop exhausted without completing
            task_list = load_task_list(run_context.session_state)
            if not task_list.goal_complete:
                log_warning(f"Reached max_iterations ({team.max_iterations}) without completing all tasks.")

        # === Post-loop ===

        # Always add media to run_response for caller availability
        if model_response is not None:
            store_media_util(run_response, model_response)

        # Convert response to structured format
        _convert_response_to_structured_format(team, run_response=run_response, run_context=run_context)

        # Execute post-hooks
        if team.post_hooks is not None:
            iterator = _execute_post_hooks(
                team,
                hooks=team.post_hooks,  # type: ignore
                run_output=run_response,
                run_context=run_context,
                session=session,
                user_id=user_id,
                debug_mode=debug_mode,
                background_tasks=background_tasks,
                **kwargs,
            )
            deque(iterator, maxlen=0)

        raise_if_cancelled(run_response.run_id)  # type: ignore

        # Wait for background memory and learning creation
        wait_for_open_threads(memory_future=memory_future, learning_future=learning_future)  # type: ignore
        merge_background_metrics(run_response.metrics, collect_background_metrics(memory_future, learning_future))

        raise_if_cancelled(run_response.run_id)  # type: ignore

        # Create session summary
        if team.session_summary_manager is not None:
            session.upsert_run(run_response=run_response)
            try:
                team.session_summary_manager.create_session_summary(session=session, run_metrics=run_response.metrics)
            except Exception as e:
                log_warning(f"Error in session summary creation: {str(e)}")

        raise_if_cancelled(run_response.run_id)  # type: ignore

        # Generate followups if enabled
        from agno.team._response import generate_team_followups

        generate_team_followups(team, run_response=run_response)

        # Set the run status to completed
        run_response.status = RunStatus.completed

        # Cleanup and store
        _cleanup_and_store(team, run_response=run_response, session=session)

        log_team_telemetry(team, session_id=session.session_id, run_id=run_response.run_id)

        log_debug(f"Team Task Run End: {run_response.run_id}", center=True, symbol="*")

        return run_response

    except RunCancelledException as e:
        run_response = _handle_team_run_cancellation(run_response, e, run_messages, session=session)
        try:
            _cleanup_and_store(team, run_response=run_response, session=session, run_context=run_context)
        except Exception as store_err:
            log_warning(f"Failed to persist cancelled run: {store_err}")
        return run_response

    except (InputCheckError, OutputCheckError) as e:
        run_response.status = RunStatus.error
        flush_in_flight_messages_on_error_team(run_response, locals().get("run_messages"))
        run_error = create_team_run_error_event(
            run_response,
            error=str(e),
            error_id=e.error_id,
            error_type=e.type,
            additional_data=e.additional_data,
        )
        run_response.events = add_team_error_event(error=run_error, events=run_response.events)
        if run_response.content is None:
            run_response.content = str(e)
        log_error(f"Validation failed: {str(e)} | Check: {e.check_trigger}")
        _cleanup_and_store(team, run_response=run_response, session=session)
        return run_response

    except KeyboardInterrupt:
        run_response = _handle_team_run_cancellation(run_response, KeyboardInterrupt(), run_messages, session=session)
        try:
            _cleanup_and_store(team, run_response=run_response, session=session, run_context=run_context)
        except Exception as store_err:
            log_warning(f"Failed to persist cancelled run: {store_err}")
        return run_response

    except Exception as e:
        run_response.status = RunStatus.error
        flush_in_flight_messages_on_error_team(run_response, locals().get("run_messages"))
        run_error = create_team_run_error_event(run_response, error=str(e), error_type=error_type_of(e))
        run_response.events = add_team_error_event(error=run_error, events=run_response.events)
        if run_response.content is None:
            run_response.content = str(e)
        log_error(f"Error in Team task run: {str(e)}")
        _cleanup_and_store(team, run_response=run_response, session=session)
        return run_response

    finally:
        # Cancel background futures on error
        for future in (memory_future, learning_future):
            if future is not None and not future.done():
                future.cancel()
                try:
                    future.result(timeout=0)
                except Exception:
                    pass
        _disconnect_connectable_tools(team)
        cleanup_run(run_response.run_id)  # type: ignore

    return run_response


def _run_tasks_stream(
    team: "Team",
    run_response: TeamRunOutput,
    session: TeamSession,
    run_context: RunContext,
    user_id: Optional[str] = None,
    add_history_to_context: Optional[bool] = None,
    add_dependencies_to_context: Optional[bool] = None,
    add_session_state_to_context: Optional[bool] = None,
    response_format: Optional[Union[Dict, Type[BaseModel]]] = None,
    stream_events: bool = False,
    yield_run_output: bool = False,
    debug_mode: Optional[bool] = None,
    background_tasks: Optional[Any] = None,
    **kwargs: Any,
) -> Iterator[Union[TeamRunOutputEvent, RunOutputEvent, TeamRunOutput]]:
    """Run the Team in autonomous task mode with streaming support.

    The team leader iteratively plans and delegates tasks to members until
    the goal is complete or max_iterations is reached. Events are yielded
    for each iteration.
    """
    from agno.team._hooks import _execute_post_hooks, _execute_pre_hooks
    from agno.team._init import _disconnect_connectable_tools
    from agno.team._managers import _start_learning_future, _start_memory_future
    from agno.team._messages import _get_run_messages
    from agno.team._response import (
        _convert_response_to_structured_format,
        _handle_model_response_stream,
        generate_response_with_output_model_stream,
        handle_reasoning_stream,
    )
    from agno.team._telemetry import log_team_telemetry
    from agno.team._tools import _determine_tools_for_model
    from agno.team.task import TaskStatus, load_task_list
    from agno.utils.events import (
        create_team_task_iteration_completed_event,
        create_team_task_iteration_started_event,
        create_team_task_state_updated_event,
    )

    log_debug(f"Team Task Run (Stream) Start: {run_response.run_id}", center=True)
    memory_future = None
    learning_future = None

    # Bind run_messages early so the cancellation handler can read it
    # if cancel fires before the message list is built.
    run_messages: Optional[RunMessages] = None
    try:
        run_input = cast(TeamRunInput, run_response.input)
        team.model = cast(Model, team.model)
        raise_if_cancelled(run_response.run_id)  # type: ignore

        # 1. Execute pre-hooks
        if team.pre_hooks is not None:
            pre_hook_iterator = _execute_pre_hooks(
                team,
                hooks=team.pre_hooks,  # type: ignore
                run_response=run_response,
                run_input=run_input,
                run_context=run_context,
                session=session,
                user_id=user_id,
                debug_mode=debug_mode,
                stream_events=stream_events,
                background_tasks=background_tasks,
                **kwargs,
            )
            for pre_hook_event in pre_hook_iterator:
                yield pre_hook_event

        # 2. Determine tools for model (includes task management tools)
        team_run_context: Dict[str, Any] = {}
        _tools = _determine_tools_for_model(
            team,
            model=team.model,
            run_response=run_response,
            run_context=run_context,
            team_run_context=team_run_context,
            session=session,
            user_id=user_id,
            async_mode=False,
            input_message=run_input.input_content,
            images=run_input.images,
            videos=run_input.videos,
            audio=run_input.audios,
            files=run_input.files,
            debug_mode=debug_mode,
            add_history_to_context=add_history_to_context,
            add_dependencies_to_context=add_dependencies_to_context,
            add_session_state_to_context=add_session_state_to_context,
            stream=True,
            stream_events=stream_events,
        )

        # 3. Prepare initial run messages
        run_messages = _get_run_messages(
            team,
            run_response=run_response,
            session=session,
            run_context=run_context,
            user_id=user_id,
            input_message=run_input.input_content,
            audio=run_input.audios,
            images=run_input.images,
            videos=run_input.videos,
            files=run_input.files,
            add_history_to_context=add_history_to_context,
            add_dependencies_to_context=add_dependencies_to_context,
            add_session_state_to_context=add_session_state_to_context,
            tools=_tools,
            **kwargs,
        )
        if len(run_messages.messages) == 0:
            log_error("No messages to be sent to the model.")

        # 4. Start memory creation in background
        memory_future = _start_memory_future(
            team,
            run_messages=run_messages,
            user_id=user_id,
            existing_future=memory_future,
        )
        learning_future = _start_learning_future(
            team,
            run_messages=run_messages,
            session=session,
            user_id=user_id,
            existing_future=learning_future,
        )

        # Yield run started event
        if stream_events:
            yield handle_event(  # type: ignore
                create_team_run_started_event(run_response),
                run_response,
                events_to_skip=team.events_to_skip,
                store_events=team.store_events,
            )

        raise_if_cancelled(run_response.run_id)  # type: ignore

        # 5. Reason about the task if reasoning is enabled
        yield from handle_reasoning_stream(
            team,
            run_response=run_response,
            run_messages=run_messages,
            run_context=run_context,
            stream_events=stream_events,
        )

        raise_if_cancelled(run_response.run_id)  # type: ignore

        # Use accumulated messages for the iterative loop
        accumulated_messages = run_messages.messages

        # === Iterative task loop ===
        idle_answer_turns = 0
        for iteration in range(team.max_iterations):
            n_tools_before_iteration = len(run_response.tools or [])
            log_debug(f"Task iteration {iteration + 1}/{team.max_iterations}")

            # Yield task iteration started event
            if stream_events:
                yield handle_event(  # type: ignore
                    create_team_task_iteration_started_event(
                        from_run_response=run_response,
                        iteration=iteration + 1,
                        max_iterations=team.max_iterations,
                    ),
                    run_response,
                    events_to_skip=team.events_to_skip,
                    store_events=team.store_events,
                )

            # On subsequent iterations, inject current task state as a user message
            if iteration > 0:
                task_list = load_task_list(run_context.session_state)
                task_summary = task_list.get_summary_string()
                state_message = Message(
                    role="user",
                    content=f"<current_task_state>\n{task_summary}\n</current_task_state>\n\n"
                    "Continue working on the tasks. Create, execute, or update tasks as needed. "
                    "When the goal is met, write your answer and call `mark_all_complete`.",
                )
                accumulated_messages.append(state_message)

            # Get model response with streaming
            # Update run_messages with accumulated messages for streaming
            run_messages.messages = accumulated_messages

            if team.output_model is None:
                for event in _handle_model_response_stream(
                    team,
                    session=session,
                    run_response=run_response,
                    run_messages=run_messages,
                    tools=_tools,
                    response_format=response_format,
                    stream_events=stream_events,
                    session_state=run_context.session_state,
                    run_context=run_context,
                ):
                    if not isinstance(event, _MEMBER_CANCEL_BYPASS_EVENT_TYPES):
                        raise_if_cancelled(run_response.run_id)  # type: ignore
                    yield event
            else:
                for event in _handle_model_response_stream(
                    team,
                    session=session,
                    run_response=run_response,
                    run_messages=run_messages,
                    tools=_tools,
                    response_format=response_format,
                    stream_events=stream_events,
                    session_state=run_context.session_state,
                    run_context=run_context,
                ):
                    if not isinstance(event, _MEMBER_CANCEL_BYPASS_EVENT_TYPES):
                        raise_if_cancelled(run_response.run_id)  # type: ignore
                    from agno.run.team import IntermediateRunContentEvent, RunContentEvent

                    if isinstance(event, RunContentEvent):
                        if stream_events:
                            yield IntermediateRunContentEvent(
                                content=event.content,
                                content_type=event.content_type,
                            )
                    else:
                        yield event

                for event in generate_response_with_output_model_stream(
                    team,
                    session=session,
                    run_response=run_response,
                    run_messages=run_messages,
                    stream_events=stream_events,
                ):
                    raise_if_cancelled(run_response.run_id)  # type: ignore
                    yield event

            raise_if_cancelled(run_response.run_id)  # type: ignore

            # Check if delegation propagated member HITL requirements
            if run_response.requirements and any(not req.is_resolved() for req in run_response.requirements):
                from agno.team import _hooks

                yield from _hooks.handle_team_run_paused_stream(
                    team, run_response=run_response, session=session, run_context=run_context
                )
                if yield_run_output:
                    yield run_response
                return

            # Check termination conditions
            task_list = load_task_list(run_context.session_state)

            # Yield task state updated event
            if stream_events:
                # Convert task list to TaskData for frontend
                task_data_list = [
                    TaskData(
                        id=t.id,
                        title=t.title,
                        description=t.description,
                        status=t.status.value,
                        assignee=t.assignee,
                        dependencies=t.dependencies,
                        result=t.result,
                    )
                    for t in task_list.tasks
                ]
                yield handle_event(  # type: ignore
                    create_team_task_state_updated_event(
                        from_run_response=run_response,
                        task_summary=task_list.get_summary_string(),
                        goal_complete=task_list.goal_complete,
                        tasks=task_data_list,
                        completion_summary=task_list.completion_summary,
                    ),
                    run_response,
                    events_to_skip=team.events_to_skip,
                    store_events=team.store_events,
                )

            # Yield task iteration completed event
            if stream_events:
                yield handle_event(  # type: ignore
                    create_team_task_iteration_completed_event(
                        from_run_response=run_response,
                        iteration=iteration + 1,
                        max_iterations=team.max_iterations,
                        task_summary=task_list.get_summary_string(),
                    ),
                    run_response,
                    events_to_skip=team.events_to_skip,
                    store_events=team.store_events,
                )

            if task_list.goal_complete:
                log_debug("Task goal marked complete, finishing task loop.")
                break

            if task_list.all_terminal():
                # All tasks done but some may have failed
                has_failures = any(t.status == TaskStatus.failed for t in task_list.tasks)
                if not has_failures:
                    log_debug("All tasks completed successfully, finishing task loop.")
                    break
                # If there are failures, continue to let model handle them
                log_debug("All tasks terminal but some failed, continuing to let model handle.")

            # A run that needs no tasks ends by answering: with an empty list, one reminder still
            # goes out, and a second turn that writes text but calls no tool is final. Without this,
            # an empty list never satisfies all_terminal and a greeting burns max_iterations.
            if not task_list.tasks:
                if len(run_response.tools or []) == n_tools_before_iteration:
                    idle_answer_turns += 1
                    if idle_answer_turns >= 2:
                        log_debug("No tasks and no tool calls for a second turn; treating the written answer as final.")
                        break
                else:
                    idle_answer_turns = 0
            else:
                idle_answer_turns = 0
        else:
            # Loop exhausted without completing
            task_list = load_task_list(run_context.session_state)
            if not task_list.goal_complete:
                log_warning(f"Reached max_iterations ({team.max_iterations}) without completing all tasks.")

        # === Post-loop ===

        # Convert response to structured format
        _convert_response_to_structured_format(team, run_response=run_response, run_context=run_context)

        # Yield RunContentCompletedEvent
        if stream_events:
            yield handle_event(  # type: ignore
                create_team_run_content_completed_event(from_run_response=run_response),
                run_response,
                events_to_skip=team.events_to_skip,
                store_events=team.store_events,
            )

        # Execute post-hooks
        if team.post_hooks is not None:
            yield from _execute_post_hooks(
                team,
                hooks=team.post_hooks,  # type: ignore
                run_output=run_response,
                run_context=run_context,
                session=session,
                user_id=user_id,
                debug_mode=debug_mode,
                stream_events=stream_events,
                background_tasks=background_tasks,
                **kwargs,
            )

        raise_if_cancelled(run_response.run_id)  # type: ignore

        # Wait for background memory creation
        yield from wait_for_thread_tasks_stream(
            run_response=run_response,
            memory_future=memory_future,  # type: ignore
            learning_future=learning_future,  # type: ignore
            stream_events=stream_events,
            events_to_skip=team.events_to_skip,  # type: ignore
            store_events=team.store_events,
            get_memories_callback=lambda: team.get_user_memories(user_id=user_id),
        )

        raise_if_cancelled(run_response.run_id)  # type: ignore

        # Create session summary
        if team.session_summary_manager is not None:
            session.upsert_run(run_response=run_response)

            if stream_events:
                yield handle_event(  # type: ignore
                    create_team_session_summary_started_event(from_run_response=run_response),
                    run_response,
                    events_to_skip=team.events_to_skip,
                    store_events=team.store_events,
                )
            try:
                team.session_summary_manager.create_session_summary(session=session)
            except Exception as e:
                log_warning(f"Error in session summary creation: {str(e)}")
            if stream_events:
                yield handle_event(  # type: ignore
                    create_team_session_summary_completed_event(
                        from_run_response=run_response, session_summary=session.summary
                    ),
                    run_response,
                    events_to_skip=team.events_to_skip,
                    store_events=team.store_events,
                )

        raise_if_cancelled(run_response.run_id)  # type: ignore

        # Create the run completed event
        completed_event = handle_event(
            create_team_run_completed_event(from_run_response=run_response),
            run_response,
            events_to_skip=team.events_to_skip,
            store_events=team.store_events,
        )

        # Generate followups if enabled
        from agno.team._response import generate_team_followups_stream

        yield from generate_team_followups_stream(team, run_response=run_response, stream_events=stream_events)

        # Set the run status to completed
        run_response.status = RunStatus.completed

        # Cleanup and store
        _cleanup_and_store(team, run_response=run_response, session=session)

        if stream_events:
            yield completed_event

        if yield_run_output:
            yield run_response

        log_team_telemetry(team, session_id=session.session_id, run_id=run_response.run_id)

        log_debug(f"Team Task Run (Stream) End: {run_response.run_id}", center=True, symbol="*")

    except RunCancelledException as e:
        run_response = _handle_team_run_cancellation(run_response, e, run_messages, session=session)
        cancelled_event, completed_event = _build_team_cancel_terminal_events(
            team,
            run_response,
            error=e,
            run_context=run_context,
        )
        try:
            _cleanup_and_store(team, run_response=run_response, session=session, run_context=run_context)
        except Exception as store_err:
            log_warning(f"Failed to persist cancelled run: {store_err}")
        yield cancelled_event  # type: ignore
        yield completed_event  # type: ignore
        if yield_run_output:
            yield run_response

    except (InputCheckError, OutputCheckError) as e:
        run_response.status = RunStatus.error
        flush_in_flight_messages_on_error_team(run_response, locals().get("run_messages"))
        run_error = create_team_run_error_event(
            run_response,
            error=str(e),
            error_id=e.error_id,
            error_type=e.type,
            additional_data=e.additional_data,
        )
        run_response.events = add_team_error_event(error=run_error, events=run_response.events)
        if run_response.content is None:
            run_response.content = str(e)
        log_error(f"Validation failed: {str(e)} | Check: {e.check_trigger}")
        _cleanup_and_store(team, run_response=run_response, session=session)
        yield run_error

    except KeyboardInterrupt:
        run_response = _handle_team_run_cancellation(run_response, KeyboardInterrupt(), run_messages, session=session)
        cancelled_event, completed_event = _build_team_cancel_terminal_events(
            team,
            run_response,
            error=KeyboardInterrupt(),
            run_context=run_context,
        )
        try:
            _cleanup_and_store(team, run_response=run_response, session=session, run_context=run_context)
        except Exception as store_err:
            log_warning(f"Failed to persist cancelled run: {store_err}")
        yield cancelled_event  # type: ignore
        yield completed_event  # type: ignore
        if yield_run_output:
            yield run_response

    except Exception as e:
        run_response.status = RunStatus.error
        flush_in_flight_messages_on_error_team(run_response, locals().get("run_messages"))
        run_error = create_team_run_error_event(run_response, error=str(e), error_type=error_type_of(e))
        run_response.events = add_team_error_event(error=run_error, events=run_response.events)
        if run_response.content is None:
            run_response.content = str(e)
        log_error(f"Error in Team task run (stream): {str(e)}")
        _cleanup_and_store(team, run_response=run_response, session=session)
        yield run_error

    finally:
        # Cancel background futures on error
        for future in (memory_future, learning_future):
            if future is not None and not future.done():
                future.cancel()
                try:
                    future.result(timeout=0)
                except Exception:
                    pass

        _disconnect_connectable_tools(team)
        cleanup_run(run_response.run_id)  # type: ignore


def _run(
    team: "Team",
    run_response: TeamRunOutput,
    session: TeamSession,
    run_context: RunContext,
    user_id: Optional[str] = None,
    add_history_to_context: Optional[bool] = None,
    add_dependencies_to_context: Optional[bool] = None,
    add_session_state_to_context: Optional[bool] = None,
    response_format: Optional[Union[Dict, Type[BaseModel]]] = None,
    debug_mode: Optional[bool] = None,
    background_tasks: Optional[Any] = None,
    **kwargs: Any,
) -> TeamRunOutput:
    """Run the Team and return the response.
    Steps:
    1. Execute pre-hooks
    2. Determine tools for model
    3. Prepare run messages
    4. Start memory creation in background thread
    5. Reason about the task if reasoning is enabled
    6. Get a response from the model
    7. Update TeamRunOutput with the model response
    8. Store media if enabled
    9. Convert response to structured format
    10. Execute post-hooks
    11. Wait for background memory creation
    12. Create session summary
    13. Cleanup and store (scrub, stop timer, add to session, calculate metrics, save session)
    """
    from agno.team._hooks import _execute_post_hooks, _execute_pre_hooks
    from agno.team._init import _disconnect_connectable_tools
    from agno.team._managers import _start_learning_future, _start_memory_future
    from agno.team._messages import _get_run_messages
    from agno.team._response import (
        _convert_response_to_structured_format,
        _update_run_response,
        handle_reasoning,
        parse_response_with_output_model,
        parse_response_with_parser_model,
    )
    from agno.team._telemetry import log_team_telemetry
    from agno.team._tools import _determine_tools_for_model

    # Dispatch to task mode if applicable
    from agno.team.mode import TeamMode

    if team.mode == TeamMode.tasks:
        return _run_tasks(
            team,
            run_response=run_response,
            session=session,
            run_context=run_context,
            user_id=user_id,
            add_history_to_context=add_history_to_context,
            add_dependencies_to_context=add_dependencies_to_context,
            add_session_state_to_context=add_session_state_to_context,
            response_format=response_format,
            debug_mode=debug_mode,
            background_tasks=background_tasks,
            **kwargs,
        )

    log_debug(f"Team Run Start: {run_response.run_id}", center=True)

    memory_future = None
    learning_future = None
    try:
        # Set up retry logic
        num_attempts = team.retries + 1
        for attempt in range(num_attempts):
            if attempt > 0:
                log_debug(f"Retrying Team run {run_response.run_id}. Attempt {attempt + 1} of {num_attempts}...")

            # Bind run_messages early — pre-hook iteration checks cancellation
            # before run_messages is built, and the cancellation handler reads it.
            run_messages: Optional[RunMessages] = None
            try:
                raise_if_cancelled(run_response.run_id)  # type: ignore
                # 1. Execute pre-hooks
                run_input = cast(TeamRunInput, run_response.input)
                team.model = cast(Model, team.model)
                if team.pre_hooks is not None:
                    # Can modify the run input
                    pre_hook_iterator = _execute_pre_hooks(
                        team,
                        hooks=team.pre_hooks,  # type: ignore
                        run_response=run_response,
                        run_input=run_input,
                        run_context=run_context,
                        session=session,
                        user_id=user_id,
                        debug_mode=debug_mode,
                        background_tasks=background_tasks,
                        **kwargs,
                    )
                    # Consume the generator without yielding
                    deque(pre_hook_iterator, maxlen=0)

                # 2. Determine tools for model
                # Initialize team run context
                team_run_context: Dict[str, Any] = {}
                # Note: MCP tool refresh is async-only by design (_check_and_refresh_mcp_tools
                # is called in _arun/_arun_stream). Sync paths do not support MCP tools.

                _tools = _determine_tools_for_model(
                    team,
                    model=team.model,
                    run_response=run_response,
                    run_context=run_context,
                    team_run_context=team_run_context,
                    session=session,
                    user_id=user_id,
                    async_mode=False,
                    input_message=run_input.input_content,
                    images=run_input.images,
                    videos=run_input.videos,
                    audio=run_input.audios,
                    files=run_input.files,
                    debug_mode=debug_mode,
                    add_history_to_context=add_history_to_context,
                    add_session_state_to_context=add_session_state_to_context,
                    add_dependencies_to_context=add_dependencies_to_context,
                    stream=False,
                    stream_events=False,
                )

                # 3. Prepare run messages
                run_messages = _get_run_messages(
                    team,
                    run_response=run_response,
                    session=session,
                    run_context=run_context,
                    user_id=user_id,
                    input_message=run_input.input_content,
                    audio=run_input.audios,
                    images=run_input.images,
                    videos=run_input.videos,
                    files=run_input.files,
                    add_history_to_context=add_history_to_context,
                    add_dependencies_to_context=add_dependencies_to_context,
                    add_session_state_to_context=add_session_state_to_context,
                    tools=_tools,
                    **kwargs,
                )
                if len(run_messages.messages) == 0:
                    log_error("No messages to be sent to the model.")

                # 4. Start memory creation in background thread
                memory_future = _start_memory_future(
                    team,
                    run_messages=run_messages,
                    user_id=user_id,
                    existing_future=memory_future,
                )
                learning_future = _start_learning_future(
                    team,
                    run_messages=run_messages,
                    session=session,
                    user_id=user_id,
                    existing_future=learning_future,
                )

                raise_if_cancelled(run_response.run_id)  # type: ignore

                # 5. Reason about the task if reasoning is enabled
                handle_reasoning(team, run_response=run_response, run_messages=run_messages, run_context=run_context)

                # Check for cancellation before model call
                raise_if_cancelled(run_response.run_id)  # type: ignore

                # 6. Get the model response for the team leader
                team.model = cast(Model, team.model)
                model_response: ModelResponse = call_model_with_fallback(
                    team.model,
                    team.fallback_config,
                    messages=run_messages.messages,
                    response_format=response_format,
                    tools=_tools,
                    tool_choice=team.tool_choice,
                    tool_call_limit=team.tool_call_limit,
                    run_response=run_response,
                    send_media_to_model=team.send_media_to_model,
                    compression_manager=team.compression_manager if team.compress_tool_results else None,
                    **result_store_kwargs(team),
                    after_tool_results=build_team_after_tool_results_callback(
                        team, run_response, session, run_messages, run_context
                    ),
                )

                # Check for cancellation after model call
                raise_if_cancelled(run_response.run_id)  # type: ignore

                # If an output model is provided, generate output using the output model
                parse_response_with_output_model(team, model_response, run_messages, run_response=run_response)

                # If a parser model is provided, structure the response separately
                parse_response_with_parser_model(
                    team, model_response, run_messages, run_context=run_context, run_response=run_response
                )

                # 7. Update TeamRunOutput with the model response
                _update_run_response(
                    team,
                    model_response=model_response,
                    run_response=run_response,
                    run_messages=run_messages,
                    run_context=run_context,
                )

                # 7b. Check if delegation propagated member HITL requirements
                if run_response.requirements and any(not req.is_resolved() for req in run_response.requirements):
                    from agno.team import _hooks

                    return _hooks.handle_team_run_paused(
                        team, run_response=run_response, session=session, run_context=run_context
                    )

                # 8. Always add media to run_response for caller availability
                store_media_util(run_response, model_response)

                # 9. Convert response to structured format
                _convert_response_to_structured_format(team, run_response=run_response, run_context=run_context)

                # 10. Execute post-hooks after output is generated but before response is returned
                if team.post_hooks is not None:
                    iterator = _execute_post_hooks(
                        team,
                        hooks=team.post_hooks,  # type: ignore
                        run_output=run_response,
                        run_context=run_context,
                        session=session,
                        user_id=user_id,
                        debug_mode=debug_mode,
                        background_tasks=background_tasks,
                        **kwargs,
                    )
                    deque(iterator, maxlen=0)
                raise_if_cancelled(run_response.run_id)  # type: ignore

                # 11. Wait for background memory creation
                wait_for_open_threads(memory_future=memory_future, learning_future=learning_future)  # type: ignore
                merge_background_metrics(
                    run_response.metrics, collect_background_metrics(memory_future, learning_future)
                )

                raise_if_cancelled(run_response.run_id)  # type: ignore

                # 12. Create session summary
                if team.session_summary_manager is not None:
                    # Upsert the RunOutput to Team Session before creating the session summary
                    session.upsert_run(run_response=run_response)
                    try:
                        team.session_summary_manager.create_session_summary(
                            session=session, run_metrics=run_response.metrics
                        )
                    except Exception as e:
                        log_warning(f"Error in session summary creation: {str(e)}")

                raise_if_cancelled(run_response.run_id)  # type: ignore

                # Generate followups if enabled
                from agno.team._response import generate_team_followups

                generate_team_followups(team, run_response=run_response)

                # Set the run status to completed
                run_response.status = RunStatus.completed

                # 13. Cleanup and store the run response
                _cleanup_and_store(team, run_response=run_response, session=session)

                # Log Team Telemetry
                log_team_telemetry(team, session_id=session.session_id, run_id=run_response.run_id)

                log_debug(f"Team Run End: {run_response.run_id}", center=True, symbol="*")

                return run_response
            except RunCancelledException as e:
                run_response = _handle_team_run_cancellation(run_response, e, run_messages, session=session)
                try:
                    _cleanup_and_store(team, run_response=run_response, session=session, run_context=run_context)
                except Exception as store_err:
                    log_warning(f"Failed to persist cancelled run: {store_err}")
                return run_response
            except (InputCheckError, OutputCheckError) as e:
                run_response.status = RunStatus.error
                flush_in_flight_messages_on_error_team(run_response, locals().get("run_messages"))

                # Add error event to list of events
                run_error = create_team_run_error_event(
                    run_response,
                    error=str(e),
                    error_id=e.error_id,
                    error_type=e.type,
                    additional_data=e.additional_data,
                )
                run_response.events = add_team_error_event(error=run_error, events=run_response.events)

                if run_response.content is None:
                    run_response.content = str(e)

                log_error(f"Validation failed: {str(e)} | Check: {e.check_trigger}")

                _cleanup_and_store(team, run_response=run_response, session=session)

                return run_response
            except KeyboardInterrupt:
                run_response = _handle_team_run_cancellation(
                    run_response, KeyboardInterrupt(), run_messages, session=session
                )
                try:
                    _cleanup_and_store(team, run_response=run_response, session=session, run_context=run_context)
                except Exception as store_err:
                    log_warning(f"Failed to persist cancelled run: {store_err}")
                return run_response
            except Exception as e:
                if attempt < num_attempts - 1:
                    # Calculate delay with exponential backoff if enabled
                    if team.exponential_backoff:
                        delay = team.delay_between_retries * (2**attempt)
                    else:
                        delay = team.delay_between_retries

                    log_warning(f"Attempt {attempt + 1}/{num_attempts} failed. Retrying in {delay}s...: {str(e)}")
                    time.sleep(delay)
                    continue

                run_response.status = RunStatus.error
                flush_in_flight_messages_on_error_team(run_response, locals().get("run_messages"))
                run_error = create_team_run_error_event(run_response, error=str(e), error_type=error_type_of(e))
                run_response.events = add_team_error_event(error=run_error, events=run_response.events)

                # If the content is None, set it to the error message
                if run_response.content is None:
                    run_response.content = str(e)

                log_error(f"Error in Team run: {str(e)}")

                # Cleanup and store the run response and session
                _cleanup_and_store(team, run_response=run_response, session=session)

                return run_response
    finally:
        # Cancel background futures on error (wait_for_open_threads handles waiting on success)
        for future in (memory_future, learning_future):
            if future is not None and not future.done():
                future.cancel()
                try:
                    future.result(timeout=0)
                except Exception:
                    pass

        # Always disconnect connectable tools
        _disconnect_connectable_tools(team)
        # Always clean up the run tracking
        cleanup_run(run_response.run_id)  # type: ignore
    return run_response  # Defensive fallback for type-checker; all paths return inside the loop


def _run_stream(
    team: "Team",
    run_response: TeamRunOutput,
    run_context: RunContext,
    session: TeamSession,
    user_id: Optional[str] = None,
    add_history_to_context: Optional[bool] = None,
    add_dependencies_to_context: Optional[bool] = None,
    add_session_state_to_context: Optional[bool] = None,
    response_format: Optional[Union[Dict, Type[BaseModel]]] = None,
    stream_events: bool = False,
    yield_run_output: bool = False,
    debug_mode: Optional[bool] = None,
    background_tasks: Optional[Any] = None,
    **kwargs: Any,
) -> Iterator[Union[TeamRunOutputEvent, RunOutputEvent, TeamRunOutput]]:
    """Run the Team and return the response iterator.
    Steps:
    1. Execute pre-hooks
    2. Determine tools for model
    3. Prepare run messages
    4. Start memory creation in background thread
    5. Reason about the task if reasoning is enabled
    6. Get a response from the model
    7. Parse response with parser model if provided
    8. Wait for background memory creation
    9. Create session summary
    10. Cleanup and store (scrub, add to session, calculate metrics, save session)
    """
    from agno.team._hooks import _execute_post_hooks, _execute_pre_hooks
    from agno.team._init import _disconnect_connectable_tools
    from agno.team._managers import _start_learning_future, _start_memory_future
    from agno.team._messages import _get_run_messages
    from agno.team._response import (
        _handle_model_response_stream,
        generate_response_with_output_model_stream,
        handle_reasoning_stream,
        parse_response_with_parser_model_stream,
    )
    from agno.team._telemetry import log_team_telemetry
    from agno.team._tools import _determine_tools_for_model

    # Fallback for tasks mode (streaming not yet supported)
    # Dispatch to task mode streaming if applicable
    from agno.team.mode import TeamMode

    if team.mode == TeamMode.tasks:
        yield from _run_tasks_stream(
            team,
            run_response=run_response,
            session=session,
            run_context=run_context,
            user_id=user_id,
            add_history_to_context=add_history_to_context,
            add_dependencies_to_context=add_dependencies_to_context,
            add_session_state_to_context=add_session_state_to_context,
            response_format=response_format,
            stream_events=stream_events,
            yield_run_output=yield_run_output,
            debug_mode=debug_mode,
            background_tasks=background_tasks,
            **kwargs,
        )
        return

    log_debug(f"Team Run Start: {run_response.run_id}", center=True)

    memory_future = None
    learning_future = None
    try:
        # Set up retry logic
        num_attempts = team.retries + 1
        for attempt in range(num_attempts):
            if attempt > 0:
                log_debug(f"Retrying Team run {run_response.run_id}. Attempt {attempt + 1} of {num_attempts}...")

            # Bind run_messages early — pre-hook iteration checks cancellation
            # before run_messages is built, and the cancellation handler reads it.
            run_messages: Optional[RunMessages] = None
            try:
                raise_if_cancelled(run_response.run_id)  # type: ignore
                # 1. Execute pre-hooks
                run_input = cast(TeamRunInput, run_response.input)
                team.model = cast(Model, team.model)
                if team.pre_hooks is not None:
                    # Can modify the run input
                    pre_hook_iterator = _execute_pre_hooks(
                        team,
                        hooks=team.pre_hooks,  # type: ignore
                        run_response=run_response,
                        run_context=run_context,
                        run_input=run_input,
                        session=session,
                        user_id=user_id,
                        debug_mode=debug_mode,
                        stream_events=stream_events,
                        background_tasks=background_tasks,
                        **kwargs,
                    )
                    for pre_hook_event in pre_hook_iterator:
                        yield pre_hook_event

                # 2. Determine tools for model
                # Initialize team run context
                team_run_context: Dict[str, Any] = {}
                # Note: MCP tool refresh is async-only by design (_check_and_refresh_mcp_tools
                # is called in _arun/_arun_stream). Sync paths do not support MCP tools.

                _tools = _determine_tools_for_model(
                    team,
                    model=team.model,
                    run_response=run_response,
                    run_context=run_context,
                    team_run_context=team_run_context,
                    session=session,
                    user_id=user_id,
                    async_mode=False,
                    input_message=run_input.input_content,
                    images=run_input.images,
                    videos=run_input.videos,
                    audio=run_input.audios,
                    files=run_input.files,
                    debug_mode=debug_mode,
                    add_history_to_context=add_history_to_context,
                    add_session_state_to_context=add_session_state_to_context,
                    add_dependencies_to_context=add_dependencies_to_context,
                    stream=True,
                    stream_events=stream_events,
                )

                # 3. Prepare run messages
                run_messages = _get_run_messages(
                    team,
                    run_response=run_response,
                    run_context=run_context,
                    session=session,
                    user_id=user_id,
                    input_message=run_input.input_content,
                    audio=run_input.audios,
                    images=run_input.images,
                    videos=run_input.videos,
                    files=run_input.files,
                    add_history_to_context=add_history_to_context,
                    add_dependencies_to_context=add_dependencies_to_context,
                    add_session_state_to_context=add_session_state_to_context,
                    tools=_tools,
                    **kwargs,
                )
                if len(run_messages.messages) == 0:
                    log_error("No messages to be sent to the model.")

                # 4. Start memory creation in background thread
                memory_future = _start_memory_future(
                    team,
                    run_messages=run_messages,
                    user_id=user_id,
                    existing_future=memory_future,
                )
                learning_future = _start_learning_future(
                    team,
                    run_messages=run_messages,
                    session=session,
                    user_id=user_id,
                    existing_future=learning_future,
                )

                # Start the Run by yielding a RunStarted event
                if stream_events:
                    yield handle_event(  # type: ignore
                        create_team_run_started_event(run_response),
                        run_response,
                        events_to_skip=team.events_to_skip,
                        store_events=team.store_events,
                    )

                raise_if_cancelled(run_response.run_id)  # type: ignore

                # 5. Reason about the task if reasoning is enabled
                yield from handle_reasoning_stream(
                    team,
                    run_response=run_response,
                    run_messages=run_messages,
                    run_context=run_context,
                    stream_events=stream_events,
                )

                # Check for cancellation before model processing
                raise_if_cancelled(run_response.run_id)  # type: ignore

                # 6. Get a response from the model
                if team.output_model is None:
                    for event in _handle_model_response_stream(
                        team,
                        session=session,
                        run_response=run_response,
                        run_messages=run_messages,
                        tools=_tools,
                        response_format=response_format,
                        stream_events=stream_events,
                        session_state=run_context.session_state,
                        run_context=run_context,
                    ):
                        if not isinstance(event, _MEMBER_CANCEL_BYPASS_EVENT_TYPES):
                            raise_if_cancelled(run_response.run_id)  # type: ignore
                        yield event
                else:
                    for event in _handle_model_response_stream(
                        team,
                        session=session,
                        run_response=run_response,
                        run_messages=run_messages,
                        tools=_tools,
                        response_format=response_format,
                        stream_events=stream_events,
                        session_state=run_context.session_state,
                        run_context=run_context,
                    ):
                        if not isinstance(event, _MEMBER_CANCEL_BYPASS_EVENT_TYPES):
                            raise_if_cancelled(run_response.run_id)  # type: ignore
                        from agno.run.team import IntermediateRunContentEvent, RunContentEvent

                        if isinstance(event, RunContentEvent):
                            if stream_events:
                                yield IntermediateRunContentEvent(
                                    content=event.content,
                                    content_type=event.content_type,
                                )
                        else:
                            yield event

                    for event in generate_response_with_output_model_stream(
                        team,
                        session=session,
                        run_response=run_response,
                        run_messages=run_messages,
                        stream_events=stream_events,
                    ):
                        raise_if_cancelled(run_response.run_id)  # type: ignore
                        yield event

                # Check for cancellation after model processing
                raise_if_cancelled(run_response.run_id)  # type: ignore

                # 6b. Check if delegation propagated member HITL requirements
                if run_response.requirements and any(not req.is_resolved() for req in run_response.requirements):
                    from agno.team import _hooks

                    yield from _hooks.handle_team_run_paused_stream(
                        team, run_response=run_response, session=session, run_context=run_context
                    )
                    if yield_run_output:
                        yield run_response
                    return

                # 7. Parse response with parser model if provided
                yield from parse_response_with_parser_model_stream(
                    team,
                    session=session,
                    run_response=run_response,
                    stream_events=stream_events,
                    run_context=run_context,
                )

                # Yield RunContentCompletedEvent
                if stream_events:
                    yield handle_event(  # type: ignore
                        create_team_run_content_completed_event(from_run_response=run_response),
                        run_response,
                        events_to_skip=team.events_to_skip,
                        store_events=team.store_events,
                    )
                # Execute post-hooks after output is generated but before response is returned
                if team.post_hooks is not None:
                    yield from _execute_post_hooks(
                        team,
                        hooks=team.post_hooks,  # type: ignore
                        run_output=run_response,
                        run_context=run_context,
                        session=session,
                        user_id=user_id,
                        debug_mode=debug_mode,
                        stream_events=stream_events,
                        background_tasks=background_tasks,
                        **kwargs,
                    )
                raise_if_cancelled(run_response.run_id)  # type: ignore

                # 8. Wait for background memory creation
                yield from wait_for_thread_tasks_stream(
                    run_response=run_response,
                    memory_future=memory_future,  # type: ignore
                    learning_future=learning_future,  # type: ignore
                    stream_events=stream_events,
                    events_to_skip=team.events_to_skip,  # type: ignore
                    store_events=team.store_events,
                    get_memories_callback=lambda: team.get_user_memories(user_id=user_id),
                )
                merge_background_metrics(
                    run_response.metrics, collect_background_metrics(memory_future, learning_future)
                )

                raise_if_cancelled(run_response.run_id)  # type: ignore
                # 9. Create session summary
                if team.session_summary_manager is not None:
                    # Upsert the RunOutput to Team Session before creating the session summary
                    session.upsert_run(run_response=run_response)

                    if stream_events:
                        yield handle_event(  # type: ignore
                            create_team_session_summary_started_event(from_run_response=run_response),
                            run_response,
                            events_to_skip=team.events_to_skip,
                            store_events=team.store_events,
                        )
                    try:
                        team.session_summary_manager.create_session_summary(
                            session=session, run_metrics=run_response.metrics
                        )
                    except Exception as e:
                        log_warning(f"Error in session summary creation: {str(e)}")
                    if stream_events:
                        yield handle_event(  # type: ignore
                            create_team_session_summary_completed_event(
                                from_run_response=run_response, session_summary=session.summary
                            ),
                            run_response,
                            events_to_skip=team.events_to_skip,
                            store_events=team.store_events,
                        )

                raise_if_cancelled(run_response.run_id)  # type: ignore
                # Create the run completed event
                completed_event = handle_event(
                    create_team_run_completed_event(
                        from_run_response=run_response,
                    ),
                    run_response,
                    events_to_skip=team.events_to_skip,
                    store_events=team.store_events,
                )

                # Generate followups if enabled
                from agno.team._response import generate_team_followups_stream

                yield from generate_team_followups_stream(team, run_response=run_response, stream_events=stream_events)

                # Set the run status to completed
                run_response.status = RunStatus.completed

                # 10. Cleanup and store the run response
                _cleanup_and_store(team, run_response=run_response, session=session)

                if stream_events:
                    yield completed_event

                if yield_run_output:
                    yield run_response

                # Log Team Telemetry
                log_team_telemetry(team, session_id=session.session_id, run_id=run_response.run_id)

                log_debug(f"Team Run End: {run_response.run_id}", center=True, symbol="*")

                break
            except RunCancelledException as e:
                run_response = _handle_team_run_cancellation(run_response, e, run_messages, session=session)
                cancelled_event, completed_event = _build_team_cancel_terminal_events(
                    team,
                    run_response,
                    error=e,
                    run_context=run_context,
                )
                try:
                    _cleanup_and_store(team, run_response=run_response, session=session, run_context=run_context)
                except Exception as store_err:
                    log_warning(f"Failed to persist cancelled run: {store_err}")
                yield cancelled_event  # type: ignore
                yield completed_event  # type: ignore
                if yield_run_output:
                    yield run_response
                break
            except (InputCheckError, OutputCheckError) as e:
                run_response.status = RunStatus.error
                flush_in_flight_messages_on_error_team(run_response, locals().get("run_messages"))

                # Add error event to list of events
                run_error = create_team_run_error_event(
                    run_response,
                    error=str(e),
                    error_id=e.error_id,
                    error_type=e.type,
                    additional_data=e.additional_data,
                )
                run_response.events = add_team_error_event(error=run_error, events=run_response.events)

                if run_response.content is None:
                    run_response.content = str(e)
                _cleanup_and_store(team, run_response=run_response, session=session)
                yield run_error
                break

            except KeyboardInterrupt:
                run_response = _handle_team_run_cancellation(
                    run_response, KeyboardInterrupt(), run_messages, session=session
                )
                cancelled_event, completed_event = _build_team_cancel_terminal_events(
                    team,
                    run_response,
                    error=KeyboardInterrupt(),
                    run_context=run_context,
                )
                try:
                    _cleanup_and_store(team, run_response=run_response, session=session, run_context=run_context)
                except Exception as store_err:
                    log_warning(f"Failed to persist cancelled run: {store_err}")
                yield cancelled_event  # type: ignore
                yield completed_event  # type: ignore
                if yield_run_output:
                    yield run_response
                break
            except Exception as e:
                if attempt < num_attempts - 1:
                    # Calculate delay with exponential backoff if enabled
                    if team.exponential_backoff:
                        delay = team.delay_between_retries * (2**attempt)
                    else:
                        delay = team.delay_between_retries

                    log_warning(f"Attempt {attempt + 1}/{num_attempts} failed. Retrying in {delay}s...: {str(e)}")
                    time.sleep(delay)
                    continue

                run_response.status = RunStatus.error
                flush_in_flight_messages_on_error_team(run_response, locals().get("run_messages"))
                run_error = create_team_run_error_event(run_response, error=str(e), error_type=error_type_of(e))
                run_response.events = add_team_error_event(error=run_error, events=run_response.events)
                if run_response.content is None:
                    run_response.content = str(e)

                log_error(f"Error in Team run: {str(e)}")

                _cleanup_and_store(team, run_response=run_response, session=session)
                yield run_error
    finally:
        # Cancel background futures on error (wait_for_thread_tasks_stream handles waiting on success)
        for future in (memory_future, learning_future):
            if future is not None and not future.done():
                future.cancel()
                try:
                    future.result(timeout=0)
                except Exception:
                    pass

        # Always disconnect connectable tools
        _disconnect_connectable_tools(team)
        # Always clean up the run tracking
        cleanup_run(run_response.run_id)  # type: ignore


def run_dispatch(
    team: "Team",
    input: Union[str, List, Dict, Message, BaseModel, List[Message]],
    *,
    stream: Optional[bool] = None,
    stream_events: Optional[bool] = None,
    session_id: Optional[str] = None,
    session_state: Optional[Dict[str, Any]] = None,
    run_context: Optional[RunContext] = None,
    run_id: Optional[str] = None,
    user_id: Optional[str] = None,
    audio: Optional[Sequence[Audio]] = None,
    images: Optional[Sequence[Image]] = None,
    videos: Optional[Sequence[Video]] = None,
    files: Optional[Sequence[File]] = None,
    knowledge_filters: Optional[Union[Dict[str, Any], List[FilterExpr]]] = None,
    add_history_to_context: Optional[bool] = None,
    add_dependencies_to_context: Optional[bool] = None,
    add_session_state_to_context: Optional[bool] = None,
    dependencies: Optional[Dict[str, Any]] = None,
    metadata: Optional[Dict[str, Any]] = None,
    debug_mode: Optional[bool] = None,
    yield_run_output: bool = False,
    output_schema: Optional[Union[Type[BaseModel], Dict[str, Any]]] = None,
    **kwargs: Any,
) -> Union[TeamRunOutput, Iterator[Union[RunOutputEvent, TeamRunOutputEvent]]]:
    """Run the Team and return the response."""
    from agno.media.storage.base import AsyncMediaStorage
    from agno.team._init import _has_async_db, _initialize_session, _initialize_session_state
    from agno.team._response import get_response_format
    from agno.team._run_options import resolve_run_options
    from agno.team._storage import _load_session_state, _read_or_create_session, _update_metadata

    if _has_async_db(team):
        raise Exception("run() is not supported with an async DB. Please use arun() instead.")

    # Refused here rather than at the persist below, which runs after the model call.
    if isinstance(team.media_storage, AsyncMediaStorage):
        raise ValueError("Cannot use sync run() with an AsyncMediaStorage. Use arun() instead.")

    # Set the id for the run
    run_id = run_id or str(uuid4())

    # Initialize Team
    team.initialize_team(debug_mode=debug_mode)

    if (add_history_to_context or team.add_history_to_context) and not team.db and not team.parent_team_id:
        log_warning(
            "add_history_to_context is True, but no database has been assigned to the team. History will not be added to the context."
        )

    background_tasks = kwargs.pop("background_tasks", None)
    if background_tasks is not None:
        from fastapi import BackgroundTasks

        background_tasks: BackgroundTasks = background_tasks  # type: ignore

    # Validate input against input_schema if provided
    validated_input = validate_input(input, team.input_schema)

    try:
        # Register run for cancellation tracking (after validation succeeds)
        register_run(run_id)  # type: ignore

        # Normalise hook & guardrails
        if not team._hooks_normalised:
            if team.pre_hooks:
                team.pre_hooks = normalize_pre_hooks(team.pre_hooks)  # type: ignore
            if team.post_hooks:
                team.post_hooks = normalize_post_hooks(team.post_hooks)  # type: ignore
            team._hooks_normalised = True

        session_id, user_id = _initialize_session(team, session_id=session_id, user_id=user_id)

        image_artifacts, video_artifacts, audio_artifacts, file_artifacts = validate_media_object_id(
            images=images, videos=videos, audios=audio, files=files
        )

        # Create RunInput to capture the original user input
        run_input = TeamRunInput(
            input_content=validated_input,
            images=image_artifacts,
            videos=video_artifacts,
            audios=audio_artifacts,
            files=file_artifacts,
        )

        # Read existing session from database
        from copy import deepcopy

        team_session = _read_or_create_session(team, session_id=session_id, user_id=user_id)
        # Snapshot BEFORE _update_metadata merges team.metadata into the session dict,
        # so the session layer keeps the session's own values (team < session < call-site).
        session_metadata = deepcopy(team_session.metadata)
        _update_metadata(team, session=team_session)

        # Resolve run options with session-stored metadata as the middle layer
        opts = resolve_run_options(
            team,
            stream=stream,
            stream_events=stream_events,
            yield_run_output=yield_run_output,
            add_history_to_context=add_history_to_context,
            add_dependencies_to_context=add_dependencies_to_context,
            add_session_state_to_context=add_session_state_to_context,
            dependencies=dependencies,
            knowledge_filters=knowledge_filters,
            metadata=metadata,
            session_metadata=session_metadata,
            output_schema=output_schema,
        )

        # Initialize session state
        session_state = _initialize_session_state(
            team,
            session_state=session_state if session_state is not None else {},
            user_id=user_id,
            session_id=session_id,
            run_id=run_id,
        )
        # Update session state from DB
        session_state = _load_session_state(team, session=team_session, session_state=session_state)

        # Track which options were explicitly provided for run_context precedence
        dependencies_provided = dependencies is not None
        knowledge_filters_provided = knowledge_filters is not None
        metadata_provided = metadata is not None

        team.model = cast(Model, team.model)

        # Initialize run context
        run_context = run_context or RunContext(
            run_id=run_id,
            session_id=session_id,
            user_id=user_id,
            session_state=session_state,
            dependencies=opts.dependencies,
            knowledge_filters=opts.knowledge_filters,
            metadata=opts.metadata,
            output_schema=opts.output_schema,
        )
        # Apply options with precedence: explicit args > existing run_context > resolved defaults.
        opts.apply_to_context(
            run_context,
            dependencies_provided=dependencies_provided,
            knowledge_filters_provided=knowledge_filters_provided,
            metadata_provided=metadata_provided,
            user_id=user_id,
        )

        # Resolve callable dependencies once before retry loop
        if run_context.dependencies is not None:
            _resolve_run_dependencies(team, run_context=run_context)

        # Configure the model for runs
        response_format: Optional[Union[Dict, Type[BaseModel]]] = (
            get_response_format(team, run_context=run_context) if team.parser_model is None else None
        )

        # Create a new run_response for this attempt
        run_response = TeamRunOutput(
            run_id=run_id,
            session_id=session_id,
            user_id=user_id,
            team_id=team.id,
            team_name=team.name,
            metadata=run_context.metadata,
            session_state=run_context.session_state,
            input=run_input,
        )

        run_response.model = team.model.id if team.model is not None else None
        run_response.model_provider = team.model.provider if team.model is not None else None

        # Start the run metrics timer, to calculate the run duration
        run_response.metrics = RunMetrics()
        run_response.metrics.start_timer()
    except Exception:
        cleanup_run(run_id)
        raise

    if opts.stream:
        return _run_stream(
            team,
            run_response=run_response,
            run_context=run_context,
            session=team_session,
            user_id=user_id,
            add_history_to_context=opts.add_history_to_context,
            add_dependencies_to_context=opts.add_dependencies_to_context,
            add_session_state_to_context=opts.add_session_state_to_context,
            response_format=response_format,
            stream_events=opts.stream_events,
            yield_run_output=opts.yield_run_output,
            debug_mode=debug_mode,
            background_tasks=background_tasks,
            **kwargs,
        )  # type: ignore

    else:
        return _run(
            team,
            run_response=run_response,
            run_context=run_context,
            session=team_session,
            user_id=user_id,
            add_history_to_context=opts.add_history_to_context,
            add_dependencies_to_context=opts.add_dependencies_to_context,
            add_session_state_to_context=opts.add_session_state_to_context,
            response_format=response_format,
            debug_mode=debug_mode,
            background_tasks=background_tasks,
            **kwargs,
        )


async def _arun_tasks(
    team: "Team",
    run_response: TeamRunOutput,
    run_context: RunContext,
    session_id: str,
    user_id: Optional[str] = None,
    response_format: Optional[Union[Dict, Type[BaseModel]]] = None,
    add_dependencies_to_context: Optional[bool] = None,
    add_session_state_to_context: Optional[bool] = None,
    add_history_to_context: Optional[bool] = None,
    debug_mode: Optional[bool] = None,
    background_tasks: Optional[Any] = None,
    **kwargs: Any,
) -> TeamRunOutput:
    """Run the Team in autonomous task mode (async).

    The team leader iteratively plans and delegates tasks to members until
    the goal is complete or max_iterations is reached.
    """
    from agno.team._hooks import _aexecute_post_hooks, _aexecute_pre_hooks
    from agno.team._init import _disconnect_connectable_tools, _disconnect_mcp_tools
    from agno.team._managers import _astart_learning_task, _astart_memory_task
    from agno.team._messages import _aget_run_messages
    from agno.team._response import (
        _convert_response_to_structured_format,
        _update_run_response,
        ahandle_reasoning,
    )
    from agno.team._telemetry import alog_team_telemetry
    from agno.team._tools import _aget_learning_tools, _check_and_refresh_mcp_tools, _determine_tools_for_model
    from agno.team.task import TaskStatus, load_task_list

    log_debug(f"Team Task Run Start: {run_response.run_id}", center=True)
    memory_task = None
    learning_task = None
    team_session: Optional[TeamSession] = None

    # Bind run_messages early so the cancellation handler can read it
    # if cancel fires before the message list is built.
    run_messages: Optional[RunMessages] = None

    try:
        # Register run for cancellation tracking
        await aregister_run(run_context.run_id)

        # Setup session
        team_session = await _asetup_session(
            team=team,
            run_context=run_context,
            session_id=session_id,
            user_id=user_id,
            run_id=run_response.run_id,
        )

        run_input = cast(TeamRunInput, run_response.input)
        team.model = cast(Model, team.model)
        await araise_if_cancelled(run_response.run_id)  # type: ignore

        # 1. Execute pre-hooks
        if team.pre_hooks is not None:
            pre_hook_iterator = _aexecute_pre_hooks(
                team,
                hooks=team.pre_hooks,  # type: ignore
                run_response=run_response,
                run_context=run_context,
                run_input=run_input,
                session=team_session,
                user_id=user_id,
                debug_mode=debug_mode,
                background_tasks=background_tasks,
                **kwargs,
            )
            async for _ in pre_hook_iterator:
                pass

        # 2. Determine tools for model (includes task management tools)
        team_run_context: Dict[str, Any] = {}
        await _check_and_refresh_mcp_tools(team)
        learning_tools = await _aget_learning_tools(team, user_id, team_session)
        _tools = _determine_tools_for_model(
            team,
            model=team.model,
            run_response=run_response,
            run_context=run_context,
            team_run_context=team_run_context,
            session=team_session,
            user_id=user_id,
            async_mode=True,
            input_message=run_input.input_content,
            images=run_input.images,
            videos=run_input.videos,
            audio=run_input.audios,
            files=run_input.files,
            debug_mode=debug_mode,
            add_history_to_context=add_history_to_context,
            add_dependencies_to_context=add_dependencies_to_context,
            add_session_state_to_context=add_session_state_to_context,
            stream=False,
            stream_events=False,
            learning_tools=learning_tools,
        )

        # 3. Prepare initial run messages
        run_messages = await _aget_run_messages(
            team,
            run_response=run_response,
            run_context=run_context,
            session=team_session,  # type: ignore
            user_id=user_id,
            input_message=run_input.input_content,
            audio=run_input.audios,
            images=run_input.images,
            videos=run_input.videos,
            files=run_input.files,
            add_history_to_context=add_history_to_context,
            add_dependencies_to_context=add_dependencies_to_context,
            add_session_state_to_context=add_session_state_to_context,
            tools=_tools,
            **kwargs,
        )

        # 4. Start memory and learning creation in background
        memory_task = await _astart_memory_task(
            team,
            run_messages=run_messages,
            user_id=user_id,
            existing_task=memory_task,
        )
        learning_task = await _astart_learning_task(
            team,
            run_messages=run_messages,
            session=team_session,
            user_id=user_id,
            existing_task=learning_task,
        )

        await araise_if_cancelled(run_response.run_id)  # type: ignore

        # 5. Reason about the task if reasoning is enabled
        await ahandle_reasoning(team, run_response=run_response, run_messages=run_messages, run_context=run_context)

        await araise_if_cancelled(run_response.run_id)  # type: ignore

        # Use accumulated messages for the iterative loop
        accumulated_messages = run_messages.messages

        model_response: Optional[ModelResponse] = None

        # === Iterative task loop ===
        idle_answer_turns = 0
        for iteration in range(team.max_iterations):
            n_tools_before_iteration = len(run_response.tools or [])
            log_debug(f"Task iteration {iteration + 1}/{team.max_iterations}")

            # On subsequent iterations, inject current task state as a user message
            if iteration > 0:
                task_list = load_task_list(run_context.session_state)
                task_summary = task_list.get_summary_string()
                state_message = Message(
                    role="user",
                    content=f"<current_task_state>\n{task_summary}\n</current_task_state>\n\n"
                    "Continue working on the tasks. Create, execute, or update tasks as needed. "
                    "When the goal is met, write your answer and call `mark_all_complete`.",
                )
                accumulated_messages.append(state_message)

            # Get model response
            model_response = await acall_model_with_fallback(
                team.model,
                team.fallback_config,
                messages=accumulated_messages,
                response_format=response_format,
                tools=_tools,
                tool_choice=team.tool_choice,
                tool_call_limit=team.tool_call_limit,
                run_response=run_response,
                send_media_to_model=team.send_media_to_model,
                compression_manager=team.compression_manager if team.compress_tool_results else None,
                **result_store_kwargs(team),
                after_tool_results=abuild_team_after_tool_results_callback(
                    team, run_response, team_session, run_messages, run_context
                ),
            )  # type: ignore

            await araise_if_cancelled(run_response.run_id)  # type: ignore

            # Update run response
            _update_run_response(
                team,
                model_response=model_response,
                run_response=run_response,
                run_messages=run_messages,
                run_context=run_context,
            )

            # Check if delegation propagated member HITL requirements
            if run_response.requirements and any(not req.is_resolved() for req in run_response.requirements):
                from agno.team import _hooks

                return await _hooks.ahandle_team_run_paused(
                    team, run_response=run_response, session=team_session, run_context=run_context
                )

            # Check termination conditions
            task_list = load_task_list(run_context.session_state)
            if task_list.goal_complete:
                log_debug("Task goal marked complete, finishing task loop.")
                break

            if task_list.all_terminal():
                has_failures = any(t.status == TaskStatus.failed for t in task_list.tasks)
                if not has_failures:
                    log_debug("All tasks completed successfully, finishing task loop.")
                    break
                log_debug("All tasks terminal but some failed, continuing to let model handle.")

            # A run that needs no tasks ends by answering: with an empty list, one reminder still
            # goes out, and a second turn that writes text but calls no tool is final. Without this,
            # an empty list never satisfies all_terminal and a greeting burns max_iterations.
            if not task_list.tasks:
                if len(run_response.tools or []) == n_tools_before_iteration:
                    idle_answer_turns += 1
                    if idle_answer_turns >= 2:
                        log_debug("No tasks and no tool calls for a second turn; treating the written answer as final.")
                        break
                else:
                    idle_answer_turns = 0
            else:
                idle_answer_turns = 0
        else:
            # Loop exhausted without completing
            task_list = load_task_list(run_context.session_state)
            if not task_list.goal_complete:
                log_warning(f"Reached max_iterations ({team.max_iterations}) without completing all tasks.")

        # === Post-loop ===

        # Always add media to run_response for caller availability
        if model_response is not None:
            store_media_util(run_response, model_response)

        # Convert response to structured format
        _convert_response_to_structured_format(team, run_response=run_response, run_context=run_context)

        # Execute post-hooks
        if team.post_hooks is not None:
            async for _ in _aexecute_post_hooks(
                team,
                hooks=team.post_hooks,  # type: ignore
                run_output=run_response,
                run_context=run_context,
                session=team_session,
                user_id=user_id,
                debug_mode=debug_mode,
                background_tasks=background_tasks,
                **kwargs,
            ):
                pass

        await araise_if_cancelled(run_response.run_id)  # type: ignore

        # Wait for background memory and learning creation
        await await_for_open_threads(memory_task=memory_task, learning_task=learning_task)  # type: ignore
        merge_background_metrics(run_response.metrics, collect_background_metrics(memory_task, learning_task))

        await araise_if_cancelled(run_response.run_id)  # type: ignore

        # Create session summary
        if team.session_summary_manager is not None:
            team_session.upsert_run(run_response=run_response)
            try:
                await team.session_summary_manager.acreate_session_summary(
                    session=team_session, run_metrics=run_response.metrics
                )
            except Exception as e:
                log_warning(f"Error in session summary creation: {str(e)}")

        await araise_if_cancelled(run_response.run_id)  # type: ignore

        # Generate followups if enabled
        from agno.team._response import agenerate_team_followups

        await agenerate_team_followups(team, run_response=run_response)

        # Set the run status to completed
        run_response.status = RunStatus.completed

        # Cleanup and store
        await _acleanup_and_store(team, run_response=run_response, session=team_session)

        await alog_team_telemetry(team, session_id=team_session.session_id, run_id=run_response.run_id)

        log_debug(f"Team Task Run End: {run_response.run_id}", center=True, symbol="*")

        return run_response

    except RunCancelledException as e:
        run_response = _handle_team_run_cancellation(run_response, e, run_messages, session=team_session)
        if run_response.run_id:
            await adrain_member_tasks(run_response.run_id)
        try:
            if team_session is not None:
                await _acleanup_and_store(team, run_response=run_response, session=team_session)
        except Exception as store_err:
            log_warning(f"Failed to persist cancelled run: {store_err}")
        return run_response

    except (InputCheckError, OutputCheckError) as e:
        run_response.status = RunStatus.error
        flush_in_flight_messages_on_error_team(run_response, locals().get("run_messages"))
        run_error = create_team_run_error_event(
            run_response,
            error=str(e),
            error_id=e.error_id,
            error_type=e.type,
            additional_data=e.additional_data,
        )
        run_response.events = add_team_error_event(error=run_error, events=run_response.events)
        if run_response.content is None:
            run_response.content = str(e)
        log_error(f"Validation failed: {str(e)} | Check: {e.check_trigger}")
        if team_session is not None:
            await _acleanup_and_store(team, run_response=run_response, session=team_session)
        return run_response

    except (KeyboardInterrupt, asyncio.CancelledError) as cancel_exc:
        run_response = _handle_team_run_cancellation(
            run_response, KeyboardInterrupt(), run_messages, session=team_session
        )
        if team_session is not None:
            if isinstance(cancel_exc, asyncio.CancelledError):
                # Client disconnect: persist on a detached task so the cancel scope can't abort the write
                _persist_cancelled_team_run_in_background(
                    team, run_response=run_response, session=team_session, run_context=run_context
                )
            else:
                # Ctrl-C under asyncio.run: persist inline; a detached task would not run before the loop exits
                await _acleanup_and_store(
                    team, run_response=run_response, session=team_session, run_context=run_context
                )
        # Re-raise on disconnect to propagate it; return the partial on Ctrl-C
        if isinstance(cancel_exc, asyncio.CancelledError):
            raise
        return run_response

    except Exception as e:
        run_response.status = RunStatus.error
        flush_in_flight_messages_on_error_team(run_response, locals().get("run_messages"))
        run_error = create_team_run_error_event(run_response, error=str(e), error_type=error_type_of(e))
        run_response.events = add_team_error_event(error=run_error, events=run_response.events)
        if run_response.content is None:
            run_response.content = str(e)
        log_error(f"Error in Team task run: {str(e)}")
        if team_session is not None:
            await _acleanup_and_store(team, run_response=run_response, session=team_session)
        return run_response

    finally:
        _disconnect_connectable_tools(team)
        await _disconnect_mcp_tools(team)
        # Cancel background tasks on error
        for task in (memory_task, learning_task):
            if task is not None and not task.done():
                task.cancel()
                try:
                    await task
                except asyncio.CancelledError:
                    pass
        await acleanup_run(run_response.run_id)  # type: ignore

    return run_response


async def _arun_tasks_stream(
    team: "Team",
    run_response: TeamRunOutput,
    run_context: RunContext,
    session_id: str,
    user_id: Optional[str] = None,
    response_format: Optional[Union[Dict, Type[BaseModel]]] = None,
    stream_events: bool = False,
    yield_run_output: bool = False,
    add_dependencies_to_context: Optional[bool] = None,
    add_session_state_to_context: Optional[bool] = None,
    add_history_to_context: Optional[bool] = None,
    debug_mode: Optional[bool] = None,
    background_tasks: Optional[Any] = None,
    **kwargs: Any,
) -> AsyncIterator[Union[TeamRunOutputEvent, RunOutputEvent, TeamRunOutput]]:
    """Run the Team in autonomous task mode with async streaming support.

    The team leader iteratively plans and delegates tasks to members until
    the goal is complete or max_iterations is reached. Events are yielded
    for each iteration.
    """
    from agno.team._hooks import _aexecute_post_hooks, _aexecute_pre_hooks
    from agno.team._init import _disconnect_connectable_tools, _disconnect_mcp_tools
    from agno.team._managers import _astart_learning_task, _astart_memory_task
    from agno.team._messages import _aget_run_messages
    from agno.team._response import (
        _ahandle_model_response_stream,
        _convert_response_to_structured_format,
        agenerate_response_with_output_model_stream,
        ahandle_reasoning_stream,
    )
    from agno.team._telemetry import alog_team_telemetry
    from agno.team._tools import _aget_learning_tools, _check_and_refresh_mcp_tools, _determine_tools_for_model
    from agno.team.task import TaskStatus, load_task_list
    from agno.utils.events import (
        create_team_task_iteration_completed_event,
        create_team_task_iteration_started_event,
        create_team_task_state_updated_event,
    )

    log_debug(f"Team Task Run (Async Stream) Start: {run_response.run_id}", center=True)
    memory_task = None
    learning_task = None
    team_session: Optional[TeamSession] = None

    # Bind run_messages early so the cancellation handler can read it
    # if cancel fires before the message list is built.
    run_messages: Optional[RunMessages] = None

    try:
        # Register run for cancellation tracking
        await aregister_run(run_context.run_id)

        # Setup session
        team_session = await _asetup_session(
            team=team,
            run_context=run_context,
            session_id=session_id,
            user_id=user_id,
            run_id=run_response.run_id,
        )

        run_input = cast(TeamRunInput, run_response.input)
        team.model = cast(Model, team.model)
        await araise_if_cancelled(run_response.run_id)  # type: ignore

        # 1. Execute pre-hooks
        if team.pre_hooks is not None:
            pre_hook_iterator = _aexecute_pre_hooks(
                team,
                hooks=team.pre_hooks,  # type: ignore
                run_response=run_response,
                run_context=run_context,
                run_input=run_input,
                session=team_session,
                user_id=user_id,
                debug_mode=debug_mode,
                stream_events=stream_events,
                background_tasks=background_tasks,
                **kwargs,
            )
            async for pre_hook_event in pre_hook_iterator:
                yield pre_hook_event

        # 2. Determine tools for model (includes task management tools)
        team_run_context: Dict[str, Any] = {}
        await _check_and_refresh_mcp_tools(team)
        learning_tools = await _aget_learning_tools(team, user_id, team_session)
        _tools = _determine_tools_for_model(
            team,
            model=team.model,
            run_response=run_response,
            run_context=run_context,
            team_run_context=team_run_context,
            session=team_session,
            user_id=user_id,
            async_mode=True,
            input_message=run_input.input_content,
            images=run_input.images,
            videos=run_input.videos,
            audio=run_input.audios,
            files=run_input.files,
            debug_mode=debug_mode,
            add_history_to_context=add_history_to_context,
            add_dependencies_to_context=add_dependencies_to_context,
            add_session_state_to_context=add_session_state_to_context,
            stream=True,
            stream_events=stream_events,
            learning_tools=learning_tools,
        )

        # 3. Prepare initial run messages
        run_messages = await _aget_run_messages(
            team,
            run_response=run_response,
            run_context=run_context,
            session=team_session,  # type: ignore
            user_id=user_id,
            input_message=run_input.input_content,
            audio=run_input.audios,
            images=run_input.images,
            videos=run_input.videos,
            files=run_input.files,
            add_history_to_context=add_history_to_context,
            add_dependencies_to_context=add_dependencies_to_context,
            add_session_state_to_context=add_session_state_to_context,
            tools=_tools,
            **kwargs,
        )

        # 4. Start memory creation in background
        memory_task = await _astart_memory_task(
            team,
            run_messages=run_messages,
            user_id=user_id,
            existing_task=memory_task,
        )
        learning_task = await _astart_learning_task(
            team,
            run_messages=run_messages,
            session=team_session,
            user_id=user_id,
            existing_task=learning_task,
        )

        # Yield run started event
        if stream_events:
            yield handle_event(  # type: ignore
                create_team_run_started_event(run_response),
                run_response,
                events_to_skip=team.events_to_skip,
                store_events=team.store_events,
            )

        await araise_if_cancelled(run_response.run_id)  # type: ignore

        # 5. Reason about the task if reasoning is enabled
        async for item in ahandle_reasoning_stream(
            team,
            run_response=run_response,
            run_messages=run_messages,
            run_context=run_context,
            stream_events=stream_events,
        ):
            await araise_if_cancelled(run_response.run_id)  # type: ignore
            yield item

        await araise_if_cancelled(run_response.run_id)  # type: ignore

        # Use accumulated messages for the iterative loop
        accumulated_messages = run_messages.messages

        # === Iterative task loop ===
        idle_answer_turns = 0
        for iteration in range(team.max_iterations):
            n_tools_before_iteration = len(run_response.tools or [])
            log_debug(f"Task iteration {iteration + 1}/{team.max_iterations}")

            # Yield task iteration started event
            if stream_events:
                yield handle_event(  # type: ignore
                    create_team_task_iteration_started_event(
                        from_run_response=run_response,
                        iteration=iteration + 1,
                        max_iterations=team.max_iterations,
                    ),
                    run_response,
                    events_to_skip=team.events_to_skip,
                    store_events=team.store_events,
                )

            # On subsequent iterations, inject current task state as a user message
            if iteration > 0:
                task_list = load_task_list(run_context.session_state)
                task_summary = task_list.get_summary_string()
                state_message = Message(
                    role="user",
                    content=f"<current_task_state>\n{task_summary}\n</current_task_state>\n\n"
                    "Continue working on the tasks. Create, execute, or update tasks as needed. "
                    "When the goal is met, write your answer and call `mark_all_complete`.",
                )
                accumulated_messages.append(state_message)

            # Get model response with streaming
            # Update run_messages with accumulated messages for streaming
            run_messages.messages = accumulated_messages

            if team.output_model is None:
                async for event in _ahandle_model_response_stream(
                    team,
                    session=team_session,
                    run_response=run_response,
                    run_messages=run_messages,
                    tools=_tools,
                    response_format=response_format,
                    stream_events=stream_events,
                    session_state=run_context.session_state,
                    run_context=run_context,
                ):
                    if not isinstance(event, _MEMBER_CANCEL_BYPASS_EVENT_TYPES):
                        await araise_if_cancelled(run_response.run_id)  # type: ignore
                    yield event
            else:
                async for event in _ahandle_model_response_stream(
                    team,
                    session=team_session,
                    run_response=run_response,
                    run_messages=run_messages,
                    tools=_tools,
                    response_format=response_format,
                    stream_events=stream_events,
                    session_state=run_context.session_state,
                    run_context=run_context,
                ):
                    if not isinstance(event, _MEMBER_CANCEL_BYPASS_EVENT_TYPES):
                        await araise_if_cancelled(run_response.run_id)  # type: ignore
                    from agno.run.team import IntermediateRunContentEvent, RunContentEvent

                    if isinstance(event, RunContentEvent):
                        if stream_events:
                            yield IntermediateRunContentEvent(
                                content=event.content,
                                content_type=event.content_type,
                            )
                    else:
                        yield event

                async for event in agenerate_response_with_output_model_stream(
                    team,
                    session=team_session,
                    run_response=run_response,
                    run_messages=run_messages,
                    stream_events=stream_events,
                ):
                    await araise_if_cancelled(run_response.run_id)  # type: ignore
                    yield event

            await araise_if_cancelled(run_response.run_id)  # type: ignore

            # Check if delegation propagated member HITL requirements
            if run_response.requirements and any(not req.is_resolved() for req in run_response.requirements):
                from agno.team import _hooks

                async for item in _hooks.ahandle_team_run_paused_stream(  # type: ignore[assignment]
                    team, run_response=run_response, session=team_session, run_context=run_context
                ):
                    yield item
                if yield_run_output:
                    yield run_response
                return

            # Check termination conditions
            task_list = load_task_list(run_context.session_state)

            # Yield task state updated event
            if stream_events:
                # Convert task list to TaskData for creating detailed events
                task_data_list = [
                    TaskData(
                        id=t.id,
                        title=t.title,
                        description=t.description,
                        status=t.status.value,
                        assignee=t.assignee,
                        dependencies=t.dependencies,
                        result=t.result,
                    )
                    for t in task_list.tasks
                ]
                yield handle_event(  # type: ignore
                    create_team_task_state_updated_event(
                        from_run_response=run_response,
                        task_summary=task_list.get_summary_string(),
                        goal_complete=task_list.goal_complete,
                        tasks=task_data_list,
                        completion_summary=task_list.completion_summary,
                    ),
                    run_response,
                    events_to_skip=team.events_to_skip,
                    store_events=team.store_events,
                )

            # Yield task iteration completed event
            if stream_events:
                yield handle_event(  # type: ignore
                    create_team_task_iteration_completed_event(
                        from_run_response=run_response,
                        iteration=iteration + 1,
                        max_iterations=team.max_iterations,
                        task_summary=task_list.get_summary_string(),
                    ),
                    run_response,
                    events_to_skip=team.events_to_skip,
                    store_events=team.store_events,
                )

            if task_list.goal_complete:
                log_debug("Task goal marked complete, finishing task loop.")
                break

            if task_list.all_terminal():
                has_failures = any(t.status == TaskStatus.failed for t in task_list.tasks)
                if not has_failures:
                    log_debug("All tasks completed successfully, finishing task loop.")
                    break
                log_debug("All tasks terminal but some failed, continuing to let model handle.")

            # A run that needs no tasks ends by answering: with an empty list, one reminder still
            # goes out, and a second turn that writes text but calls no tool is final. Without this,
            # an empty list never satisfies all_terminal and a greeting burns max_iterations.
            if not task_list.tasks:
                if len(run_response.tools or []) == n_tools_before_iteration:
                    idle_answer_turns += 1
                    if idle_answer_turns >= 2:
                        log_debug("No tasks and no tool calls for a second turn; treating the written answer as final.")
                        break
                else:
                    idle_answer_turns = 0
            else:
                idle_answer_turns = 0
        else:
            # Loop exhausted without completing
            task_list = load_task_list(run_context.session_state)
            if not task_list.goal_complete:
                log_warning(f"Reached max_iterations ({team.max_iterations}) without completing all tasks.")

        # === Post-loop ===

        # Convert response to structured format
        _convert_response_to_structured_format(team, run_response=run_response, run_context=run_context)

        # Yield RunContentCompletedEvent
        if stream_events:
            yield handle_event(  # type: ignore
                create_team_run_content_completed_event(from_run_response=run_response),
                run_response,
                events_to_skip=team.events_to_skip,
                store_events=team.store_events,
            )

        # Execute post-hooks
        if team.post_hooks is not None:
            async for event in _aexecute_post_hooks(
                team,
                hooks=team.post_hooks,  # type: ignore
                run_output=run_response,
                run_context=run_context,
                session=team_session,
                user_id=user_id,
                debug_mode=debug_mode,
                stream_events=stream_events,
                background_tasks=background_tasks,
                **kwargs,
            ):
                yield event

        await araise_if_cancelled(run_response.run_id)  # type: ignore

        # Wait for background memory creation
        async for event in await_for_thread_tasks_stream(
            run_response=run_response,
            memory_task=memory_task,
            learning_task=learning_task,
            stream_events=stream_events,
            events_to_skip=team.events_to_skip,  # type: ignore
            store_events=team.store_events,
            get_memories_callback=lambda: team.aget_user_memories(user_id=user_id),
        ):
            yield event

        await araise_if_cancelled(run_response.run_id)  # type: ignore

        # Create session summary
        if team.session_summary_manager is not None:
            team_session.upsert_run(run_response=run_response)

            if stream_events:
                yield handle_event(  # type: ignore
                    create_team_session_summary_started_event(from_run_response=run_response),
                    run_response,
                    events_to_skip=team.events_to_skip,
                    store_events=team.store_events,
                )
            try:
                await team.session_summary_manager.acreate_session_summary(session=team_session)
            except Exception as e:
                log_warning(f"Error in session summary creation: {str(e)}")
            if stream_events:
                yield handle_event(  # type: ignore
                    create_team_session_summary_completed_event(
                        from_run_response=run_response, session_summary=team_session.summary
                    ),
                    run_response,
                    events_to_skip=team.events_to_skip,
                    store_events=team.store_events,
                )

        await araise_if_cancelled(run_response.run_id)  # type: ignore

        # Create the run completed event
        completed_event = handle_event(
            create_team_run_completed_event(from_run_response=run_response),
            run_response,
            events_to_skip=team.events_to_skip,
            store_events=team.store_events,
        )

        # Generate followups if enabled
        from agno.team._response import agenerate_team_followups_stream

        async for event in agenerate_team_followups_stream(
            team, run_response=run_response, stream_events=stream_events
        ):
            yield event

        # Set the run status to completed
        run_response.status = RunStatus.completed

        # Cleanup and store
        await _acleanup_and_store(team, run_response=run_response, session=team_session)

        if stream_events:
            yield completed_event

        if yield_run_output:
            yield run_response

        await alog_team_telemetry(team, session_id=team_session.session_id, run_id=run_response.run_id)

        log_debug(f"Team Task Run (Async Stream) End: {run_response.run_id}", center=True, symbol="*")

    except RunCancelledException as e:
        run_response = _handle_team_run_cancellation(run_response, e, run_messages, session=team_session)
        cancelled_event, completed_event = _build_team_cancel_terminal_events(
            team,
            run_response,
            error=e,
            run_context=run_context,
        )
        if run_response.run_id:
            await adrain_member_tasks(run_response.run_id)
        try:
            if team_session is not None:
                await _acleanup_and_store(team, run_response=run_response, session=team_session)
        except Exception as store_err:
            log_warning(f"Failed to persist cancelled run: {store_err}")
        yield cancelled_event  # type: ignore
        yield completed_event  # type: ignore
        if yield_run_output:
            yield run_response

    except (InputCheckError, OutputCheckError) as e:
        run_response.status = RunStatus.error
        flush_in_flight_messages_on_error_team(run_response, locals().get("run_messages"))
        run_error = create_team_run_error_event(
            run_response,
            error=str(e),
            error_id=e.error_id,
            error_type=e.type,
            additional_data=e.additional_data,
        )
        run_response.events = add_team_error_event(error=run_error, events=run_response.events)
        if run_response.content is None:
            run_response.content = str(e)
        log_error(f"Validation failed: {str(e)} | Check: {e.check_trigger}")
        if team_session is not None:
            await _acleanup_and_store(team, run_response=run_response, session=team_session)
        yield run_error

    except (KeyboardInterrupt, asyncio.CancelledError, GeneratorExit) as cancel_exc:
        run_response = _handle_team_run_cancellation(
            run_response, KeyboardInterrupt(), run_messages, session=team_session
        )
        # Build terminal events first so they are stored on the run
        cancelled_event, completed_event = _build_team_cancel_terminal_events(
            team,
            run_response,
            error=KeyboardInterrupt(),
            run_context=run_context,
        )
        if team_session is not None:
            if isinstance(cancel_exc, (asyncio.CancelledError, GeneratorExit)):
                # Client disconnect: persist on a detached task so the cancel scope can't abort the write.
                # GeneratorExit is raised when the SSE StreamingResponse closes the generator on disconnect.
                _persist_cancelled_team_run_in_background(
                    team, run_response=run_response, session=team_session, run_context=run_context
                )
            else:
                # Ctrl-C under asyncio.run: persist inline; a detached task would not run before the loop exits
                await _acleanup_and_store(
                    team, run_response=run_response, session=team_session, run_context=run_context
                )
        # Re-raise on disconnect (client gone); yield the terminal events on Ctrl-C
        if isinstance(cancel_exc, (asyncio.CancelledError, GeneratorExit)):
            raise
        yield cancelled_event  # type: ignore
        yield completed_event  # type: ignore
        if yield_run_output:
            yield run_response

    except Exception as e:
        run_response.status = RunStatus.error
        flush_in_flight_messages_on_error_team(run_response, locals().get("run_messages"))
        run_error = create_team_run_error_event(run_response, error=str(e), error_type=error_type_of(e))
        run_response.events = add_team_error_event(error=run_error, events=run_response.events)
        if run_response.content is None:
            run_response.content = str(e)
        log_error(f"Error in Team task run (async stream): {str(e)}")
        if team_session is not None:
            await _acleanup_and_store(team, run_response=run_response, session=team_session)
        yield run_error

    finally:
        _disconnect_connectable_tools(team)
        await _disconnect_mcp_tools(team)

        # Cancel background tasks on error
        if memory_task is not None and not memory_task.done():
            memory_task.cancel()
            try:
                await memory_task
            except asyncio.CancelledError:
                pass
        if learning_task is not None and not learning_task.done():
            learning_task.cancel()
            try:
                await learning_task
            except asyncio.CancelledError:
                pass

        await acleanup_run(run_response.run_id)  # type: ignore


async def _arun(
    team: "Team",
    run_response: TeamRunOutput,
    run_context: RunContext,
    session_id: str,
    user_id: Optional[str] = None,
    response_format: Optional[Union[Dict, Type[BaseModel]]] = None,
    add_dependencies_to_context: Optional[bool] = None,
    add_session_state_to_context: Optional[bool] = None,
    add_history_to_context: Optional[bool] = None,
    debug_mode: Optional[bool] = None,
    background_tasks: Optional[Any] = None,
    **kwargs: Any,
) -> TeamRunOutput:
    """Run the Team and return the response.

    Pre-loop setup:
    1. Setup session via _asetup_session (read/create, load state, resolve dependencies)

    Steps (inside retry loop):
    1. Execute pre-hooks
    2. Determine tools for model
    3. Prepare run messages
    4. Start memory creation in background task
    5. Reason about the task if reasoning is enabled
    6. Get a response from the Model
    7. Update TeamRunOutput with the model response
    8. Store media if enabled
    9. Convert response to structured format
    10. Execute post-hooks
    11. Wait for background memory creation
    12. Create session summary
    13. Cleanup and store (scrub, add to session, calculate metrics, save session)
    """
    from agno.team._hooks import _aexecute_post_hooks, _aexecute_pre_hooks
    from agno.team._init import _disconnect_connectable_tools, _disconnect_mcp_tools
    from agno.team._managers import _astart_learning_task, _astart_memory_task
    from agno.team._messages import _aget_run_messages
    from agno.team._response import (
        _convert_response_to_structured_format,
        _update_run_response,
        agenerate_response_with_output_model,
        ahandle_reasoning,
        aparse_response_with_parser_model,
    )
    from agno.team._telemetry import alog_team_telemetry
    from agno.team._tools import _aget_learning_tools, _check_and_refresh_mcp_tools, _determine_tools_for_model

    # Dispatch to task mode if applicable
    from agno.team.mode import TeamMode

    if team.mode == TeamMode.tasks:
        return await _arun_tasks(
            team,
            run_response=run_response,
            run_context=run_context,
            session_id=session_id,
            user_id=user_id,
            response_format=response_format,
            add_dependencies_to_context=add_dependencies_to_context,
            add_session_state_to_context=add_session_state_to_context,
            add_history_to_context=add_history_to_context,
            debug_mode=debug_mode,
            background_tasks=background_tasks,
            **kwargs,
        )

    log_debug(f"Team Run Start: {run_response.run_id}", center=True)
    memory_task = None
    learning_task = None

    try:
        # Register run for cancellation tracking
        await aregister_run(run_context.run_id)

        # Setup session: read/create, load state, resolve dependencies
        team_session = await _asetup_session(
            team=team,
            run_context=run_context,
            session_id=session_id,
            user_id=user_id,
            run_id=run_response.run_id,
        )

        # Set up retry logic
        num_attempts = team.retries + 1
        for attempt in range(num_attempts):
            if attempt > 0:
                log_debug(f"Retrying Team run {run_response.run_id}. Attempt {attempt + 1} of {num_attempts}...")

            # Bind run_messages early — pre-hook iteration checks cancellation
            # before run_messages is built, and the cancellation handler reads it.
            run_messages: Optional[RunMessages] = None
            try:
                await araise_if_cancelled(run_response.run_id)  # type: ignore
                run_input = cast(TeamRunInput, run_response.input)

                # 1. Execute pre-hooks after session is loaded but before processing starts
                if team.pre_hooks is not None:
                    pre_hook_iterator = _aexecute_pre_hooks(
                        team,
                        hooks=team.pre_hooks,  # type: ignore
                        run_response=run_response,
                        run_context=run_context,
                        run_input=run_input,
                        session=team_session,
                        user_id=user_id,
                        debug_mode=debug_mode,
                        background_tasks=background_tasks,
                        **kwargs,
                    )

                    # Consume the async iterator without yielding
                    async for _ in pre_hook_iterator:
                        pass

                # 2. Resolve callable factories and determine tools for model
                team_run_context: Dict[str, Any] = {}
                team.model = cast(Model, team.model)

                # Resolve callable factories (tools, knowledge, members) before tool determination
                from agno.team._tools import _aresolve_callable_resources

                await _aresolve_callable_resources(team, run_context=run_context)

                await _check_and_refresh_mcp_tools(
                    team,
                )
                learning_tools = await _aget_learning_tools(team, user_id, team_session)
                _tools = _determine_tools_for_model(
                    team,
                    model=team.model,
                    run_response=run_response,
                    run_context=run_context,
                    team_run_context=team_run_context,
                    session=team_session,
                    user_id=user_id,
                    async_mode=True,
                    input_message=run_input.input_content,
                    images=run_input.images,
                    videos=run_input.videos,
                    audio=run_input.audios,
                    files=run_input.files,
                    debug_mode=debug_mode,
                    add_history_to_context=add_history_to_context,
                    add_dependencies_to_context=add_dependencies_to_context,
                    add_session_state_to_context=add_session_state_to_context,
                    stream=False,
                    stream_events=False,
                    learning_tools=learning_tools,
                )

                # 3. Prepare run messages
                run_messages = await _aget_run_messages(
                    team,
                    run_response=run_response,
                    run_context=run_context,
                    session=team_session,  # type: ignore
                    user_id=user_id,
                    input_message=run_input.input_content,
                    audio=run_input.audios,
                    images=run_input.images,
                    videos=run_input.videos,
                    files=run_input.files,
                    add_history_to_context=add_history_to_context,
                    add_dependencies_to_context=add_dependencies_to_context,
                    add_session_state_to_context=add_session_state_to_context,
                    tools=_tools,
                    **kwargs,
                )

                team.model = cast(Model, team.model)

                # 4. Start memory creation in background task
                memory_task = await _astart_memory_task(
                    team,
                    run_messages=run_messages,
                    user_id=user_id,
                    existing_task=memory_task,
                )
                learning_task = await _astart_learning_task(
                    team,
                    run_messages=run_messages,
                    session=team_session,
                    user_id=user_id,
                    existing_task=learning_task,
                )

                await araise_if_cancelled(run_response.run_id)  # type: ignore
                # 5. Reason about the task if reasoning is enabled
                await ahandle_reasoning(
                    team, run_response=run_response, run_messages=run_messages, run_context=run_context
                )

                # Check for cancellation before model call
                await araise_if_cancelled(run_response.run_id)  # type: ignore

                # 6. Get the model response for the team leader
                model_response = await acall_model_with_fallback(
                    team.model,
                    team.fallback_config,
                    messages=run_messages.messages,
                    tools=_tools,
                    tool_choice=team.tool_choice,
                    tool_call_limit=team.tool_call_limit,
                    response_format=response_format,
                    send_media_to_model=team.send_media_to_model,
                    run_response=run_response,
                    compression_manager=team.compression_manager if team.compress_tool_results else None,
                    **result_store_kwargs(team),
                    after_tool_results=abuild_team_after_tool_results_callback(
                        team, run_response, team_session, run_messages, run_context
                    ),
                )  # type: ignore

                # Check for cancellation after model call
                await araise_if_cancelled(run_response.run_id)  # type: ignore

                # If an output model is provided, generate output using the output model
                await agenerate_response_with_output_model(
                    team, model_response=model_response, run_messages=run_messages, run_response=run_response
                )

                # If a parser model is provided, structure the response separately
                await aparse_response_with_parser_model(
                    team,
                    model_response=model_response,
                    run_messages=run_messages,
                    run_context=run_context,
                    run_response=run_response,
                )

                # 7. Update TeamRunOutput with the model response
                _update_run_response(
                    team,
                    model_response=model_response,
                    run_response=run_response,
                    run_messages=run_messages,
                    run_context=run_context,
                )

                # 7b. Check if delegation propagated member HITL requirements
                if run_response.requirements and any(not req.is_resolved() for req in run_response.requirements):
                    from agno.team import _hooks

                    return await _hooks.ahandle_team_run_paused(
                        team, run_response=run_response, session=team_session, run_context=run_context
                    )

                # 8. Always add media to run_response for caller availability
                store_media_util(run_response, model_response)

                # 9. Convert response to structured format
                _convert_response_to_structured_format(team, run_response=run_response, run_context=run_context)

                # 10. Execute post-hooks after output is generated but before response is returned
                if team.post_hooks is not None:
                    async for _ in _aexecute_post_hooks(
                        team,
                        hooks=team.post_hooks,  # type: ignore
                        run_output=run_response,
                        run_context=run_context,
                        session=team_session,
                        user_id=user_id,
                        debug_mode=debug_mode,
                        background_tasks=background_tasks,
                        **kwargs,
                    ):
                        pass

                await araise_if_cancelled(run_response.run_id)  # type: ignore

                # 11. Wait for background memory creation
                await await_for_open_threads(memory_task=memory_task, learning_task=learning_task)
                merge_background_metrics(run_response.metrics, collect_background_metrics(memory_task, learning_task))

                await araise_if_cancelled(run_response.run_id)  # type: ignore
                # 12. Create session summary
                if team.session_summary_manager is not None:
                    # Upsert the RunOutput to Team Session before creating the session summary
                    team_session.upsert_run(run_response=run_response)
                    try:
                        await team.session_summary_manager.acreate_session_summary(
                            session=team_session, run_metrics=run_response.metrics
                        )
                    except Exception as e:
                        log_warning(f"Error in session summary creation: {str(e)}")

                await araise_if_cancelled(run_response.run_id)  # type: ignore

                # Generate followups if enabled
                from agno.team._response import agenerate_team_followups

                await agenerate_team_followups(team, run_response=run_response)

                run_response.status = RunStatus.completed

                # 13. Cleanup and store the run response and session
                await _acleanup_and_store(team, run_response=run_response, session=team_session)

                # Log Team Telemetry
                await alog_team_telemetry(team, session_id=team_session.session_id, run_id=run_response.run_id)

                log_debug(f"Team Run End: {run_response.run_id}", center=True, symbol="*")

                return run_response

            except RunCancelledException as e:
                run_response = _handle_team_run_cancellation(run_response, e, run_messages, session=team_session)
                if run_response.run_id:
                    await adrain_member_tasks(run_response.run_id)
                try:
                    await _acleanup_and_store(team, run_response=run_response, session=team_session)
                except Exception as store_err:
                    log_warning(f"Failed to persist cancelled run: {store_err}")
                return run_response

            except (InputCheckError, OutputCheckError) as e:
                run_response.status = RunStatus.error
                flush_in_flight_messages_on_error_team(run_response, locals().get("run_messages"))
                run_error = create_team_run_error_event(
                    run_response,
                    error=str(e),
                    error_id=e.error_id,
                    error_type=e.type,
                    additional_data=e.additional_data,
                )
                run_response.events = add_team_error_event(error=run_error, events=run_response.events)
                if run_response.content is None:
                    run_response.content = str(e)

                log_error(f"Validation failed: {str(e)} | Check: {e.check_trigger}")

                await _acleanup_and_store(team, run_response=run_response, session=team_session)

                return run_response

            except (KeyboardInterrupt, asyncio.CancelledError) as cancel_exc:
                run_response = _handle_team_run_cancellation(
                    run_response, KeyboardInterrupt(), run_messages, session=team_session
                )
                if team_session is not None:
                    if isinstance(cancel_exc, asyncio.CancelledError):
                        # Client disconnect: persist on a detached task so the cancel scope can't abort the write
                        _persist_cancelled_team_run_in_background(
                            team, run_response=run_response, session=team_session, run_context=run_context
                        )
                    else:
                        # Ctrl-C under asyncio.run: persist inline; a detached task would not run before the loop exits
                        await _acleanup_and_store(
                            team, run_response=run_response, session=team_session, run_context=run_context
                        )
                # Re-raise on disconnect to propagate it; return the partial on Ctrl-C
                if isinstance(cancel_exc, asyncio.CancelledError):
                    raise
                return run_response

            except Exception as e:
                if attempt < num_attempts - 1:
                    # Calculate delay with exponential backoff if enabled
                    if team.exponential_backoff:
                        delay = team.delay_between_retries * (2**attempt)
                    else:
                        delay = team.delay_between_retries

                    log_warning(f"Attempt {attempt + 1}/{num_attempts} failed. Retrying in {delay}s...: {str(e)}")
                    await asyncio.sleep(delay)
                    continue

                run_response.status = RunStatus.error
                flush_in_flight_messages_on_error_team(run_response, locals().get("run_messages"))
                run_error = create_team_run_error_event(run_response, error=str(e), error_type=error_type_of(e))
                run_response.events = add_team_error_event(error=run_error, events=run_response.events)

                if run_response.content is None:
                    run_response.content = str(e)

                log_error(f"Error in Team run: {str(e)}")

                # Cleanup and store the run response and session
                await _acleanup_and_store(team, run_response=run_response, session=team_session)

                return run_response
    finally:
        # Always disconnect connectable tools
        _disconnect_connectable_tools(team)
        await _disconnect_mcp_tools(team)

        # Cancel background task on error (await_for_open_threads handles waiting on success)
        if memory_task is not None and not memory_task.done():
            memory_task.cancel()
            try:
                await memory_task
            except asyncio.CancelledError:
                pass
        if learning_task is not None and not learning_task.done():
            learning_task.cancel()
            try:
                await learning_task
            except asyncio.CancelledError:
                pass

        # Always clean up the run tracking
        await acleanup_run(run_response.run_id)  # type: ignore

    return run_response


async def _arun_background(
    team: "Team",
    run_response: TeamRunOutput,
    run_context: RunContext,
    session_id: str,
    user_id: Optional[str] = None,
    add_history_to_context: Optional[bool] = None,
    add_dependencies_to_context: Optional[bool] = None,
    add_session_state_to_context: Optional[bool] = None,
    response_format: Optional[Union[Dict, Type[BaseModel]]] = None,
    debug_mode: Optional[bool] = None,
    background_tasks: Optional[Any] = None,
    **kwargs: Any,
) -> TeamRunOutput:
    """Start a team run in the background and return immediately with PENDING status.

    The run is persisted with PENDING status, then an asyncio task is spawned
    to execute the actual run. The task transitions through RUNNING -> COMPLETED/ERROR.

    Callers can poll for results via team.aget_run_output(run_id, session_id).
    """
    from agno.team._session import asave_run, asave_session
    from agno.team._storage import _aread_or_create_session, _update_metadata

    # 1. Register the run for cancellation tracking (before spawning the task)
    await aregister_run(run_context.run_id)

    # 2. Set status to PENDING
    run_response.status = RunStatus.pending

    # 3. Persist the PENDING run so polling can find it immediately. The row stands until the
    # terminal write, so its media is offloaded first.
    team_session = await _aread_or_create_session(team, session_id=session_id, user_id=user_id)
    _update_metadata(team, session=team_session)
    storage_run = await abuild_offloaded_storage_copy(team, run_response, session_id) or run_response
    team_session.upsert_run(run_response=storage_run)
    run_index = resolve_run_index(team_session, storage_run)
    await asave_session(team, session=team_session)
    await asave_run(team, run=storage_run, session_id=session_id, user_id=user_id, run_index=run_index)

    log_info(f"Background run {run_response.run_id} created with PENDING status")

    # 4. Spawn the background task. Execution waits for a concurrency slot
    # (background_run_slot); the run stays PENDING while waiting in line and
    # can be cancelled without consuming a slot.
    async def _background_task() -> None:
        try:
            async with background_run_slot(run_id=run_response.run_id):
                # Transition to RUNNING via the atomic helper (row-locked
                # patch when the DB supports it, fresh-read + save otherwise).
                run_response.status = RunStatus.running
                await apersist_run_transition(team, "team", session_id, run_response, user_id=user_id)

                # Execute the actual run — _arun handles everything including
                # session persistence and cleanup
                await _arun(
                    team,
                    run_response=run_response,
                    run_context=run_context,
                    session_id=session_id,
                    user_id=user_id,
                    add_history_to_context=add_history_to_context,
                    add_dependencies_to_context=add_dependencies_to_context,
                    add_session_state_to_context=add_session_state_to_context,
                    response_format=response_format,
                    debug_mode=debug_mode,
                    background_tasks=background_tasks,
                    **kwargs,
                )
        except RunCancelledException:
            # Cancelled while waiting for a slot — _arun never started, so
            # persist CANCELLED and deregister the run here.
            log_info(f"Background run {run_response.run_id} cancelled while waiting for a slot")
            try:
                run_response.status = RunStatus.cancelled
                await apersist_run_transition(team, "team", session_id, run_response, user_id=user_id)
            except Exception as e:
                log_error(f"Failed to persist cancelled state for background run {run_response.run_id}: {str(e)}")
            await acleanup_run(run_context.run_id)
        except asyncio.CancelledError:
            # Task-level shutdown (event loop stopping), not run-cancellation:
            # best-effort persist so pollers are not left with a run stuck at
            # PENDING/RUNNING forever. The durable queue's drain handles this
            # properly; this is the non-durable path's honest fallback.
            from agno.run.concurrency import is_worker_managed

            if is_worker_managed(getattr(run_response, "run_id", None) or ""):
                raise  # worker-claimed: the QueueWorker owns this terminal
            if run_response.status == RunStatus.paused:
                # The leg already PAUSED and parked valid, continuable HITL
                # state (persisted by the leg itself) - a routine deploy's
                # shutdown must not stamp CANCELLED over it. This in-memory
                # check is the ONLY protection off-Postgres: adapters without
                # the atomic primitive reach the whole-session fallback, which
                # no DB-side guard covers.
                raise
            with contextlib.suppress(Exception):
                run_response.status = RunStatus.cancelled
                await apersist_run_transition(team, "team", session_id, run_response, user_id=user_id)
            raise
        except Exception as e:
            log_error(f"Background run {run_response.run_id} failed: {str(e)}")
            # Persist ERROR status — only the changed run (O(1))
            try:
                run_response.status = RunStatus.error
                error_run = await abuild_full_run_storage_copy(team, run_response, session_id)
                await apersist_run_transition(team, "team", session_id, error_run, user_id=user_id, full_run=True)
            except Exception as e:
                log_error(f"Failed to persist error state for background run {run_response.run_id}: {str(e)}")
            # Note: acleanup_run is already called by _arun's finally block

    task = asyncio.create_task(_background_task())
    _background_tasks.add(task)
    task.add_done_callback(_background_tasks.discard)

    # 5. Return immediately with the PENDING response
    return run_response


async def _arun_background_stream(
    team: "Team",
    run_response: TeamRunOutput,
    run_context: RunContext,
    session_id: str,
    user_id: Optional[str] = None,
    add_history_to_context: Optional[bool] = None,
    add_dependencies_to_context: Optional[bool] = None,
    add_session_state_to_context: Optional[bool] = None,
    response_format: Optional[Union[Dict, Type[BaseModel]]] = None,
    stream_events: bool = False,
    yield_run_output: Optional[bool] = None,
    debug_mode: Optional[bool] = None,
    background_tasks: Optional[Any] = None,
    **kwargs: Any,
) -> AsyncIterator[str]:
    """Background streaming team run that survives client disconnections.

    1. Persists RUNNING status in DB
    2. Spawns a detached asyncio.Task that runs _arun_stream
    3. Buffers events and publishes to live tails (via the event stream)
    4. Yields SSE-formatted strings via an asyncio.Queue

    The detached task keeps running even if the client disconnects.
    The caller (router) just yields the SSE strings to the client.
    """
    from agno.os.event_streams import get_event_stream
    from agno.team._session import asave_run, asave_session
    from agno.team._storage import _aread_or_create_session, _update_metadata

    run_id = run_response.run_id
    if not run_id:
        raise ValueError("run_id is required for background streaming")

    # 1. Persist PENDING status so the run is visible in the DB immediately.
    # Execution (and the RUNNING transition) waits for a concurrency slot. The row stands
    # until the terminal write, so its media is offloaded first.
    run_response.status = RunStatus.pending

    team_session = await _aread_or_create_session(team, session_id=session_id, user_id=user_id)
    _update_metadata(team, session=team_session)
    storage_run = await abuild_offloaded_storage_copy(team, run_response, session_id) or run_response
    team_session.upsert_run(run_response=storage_run)
    run_index = resolve_run_index(team_session, storage_run)
    await asave_session(team, session=team_session)
    await asave_run(team, run=storage_run, session_id=session_id, user_id=user_id, run_index=run_index)

    # Pre-register with the event buffer so reconnecting clients can attach and
    # wait while the run is still queued (no events buffered yet).
    with contextlib.suppress(Exception):
        # Fail-open: a Redis blip must not strand an accepted run
        await get_event_stream().register_run(run_id, RunStatus.pending)

    log_info(f"Background stream run {run_id} persisted with PENDING status")

    # 2. Create queue for forwarding SSE strings to the caller
    sse_queue: asyncio.Queue[Optional[str]] = asyncio.Queue()

    # 3. Spawn detached background task. Execution waits for a concurrency slot
    # (background_run_slot); the run stays PENDING while waiting in line and
    # can be cancelled without consuming a slot.
    async def _background_producer() -> None:
        event_stream = get_event_stream()
        from agno.os.utils import format_sse_event_with_index

        slot_cm = background_run_slot(run_id=run_id)
        slot_held = False
        try:
            await slot_cm.__aenter__()
            slot_held = True

            # Transition to RUNNING now that a slot is held (atomic helper)
            run_response.status = RunStatus.running
            await apersist_run_transition(team, "team", session_id, run_response, user_id=user_id)
            with contextlib.suppress(Exception):
                # Fail-open: coordination writes must not kill the run
                await event_stream.set_run_status(run_id, RunStatus.running)

            async for event in _arun_stream(
                team,
                run_response=run_response,
                run_context=run_context,
                user_id=user_id,
                response_format=response_format,
                stream_events=stream_events,
                yield_run_output=yield_run_output or False,
                session_id=session_id,
                add_history_to_context=add_history_to_context,
                add_dependencies_to_context=add_dependencies_to_context,
                add_session_state_to_context=add_session_state_to_context,
                debug_mode=debug_mode,
                background_tasks=background_tasks,
                **kwargs,
            ):
                if isinstance(event, TeamRunOutput):
                    continue

                # Buffer + publish to live tails (the event stream owns the index)
                event_index: Optional[int] = None
                try:
                    event_index = await event_stream.add_event(run_id, event)
                except Exception:
                    log_warning(f"Failed to buffer event for run {run_id}")

                # Format as SSE for the primary queue (original client)
                sse_data = format_sse_event_with_index(event, event_index=event_index, run_id=run_id)
                try:
                    await sse_queue.put(sse_data)
                except Exception:
                    log_warning(f"Failed to push SSE data to queue for run {run_id}")

        except asyncio.CancelledError:
            # Task-level shutdown (event loop stopping), not run-cancellation:
            # best-effort persist so pollers are not left with a run stuck at
            # PENDING/RUNNING forever (parity with the non-stream producer)
            from agno.run.concurrency import is_worker_managed

            if is_worker_managed(getattr(run_response, "run_id", None) or ""):
                raise  # worker-claimed: the QueueWorker owns this terminal
            if run_response.status == RunStatus.paused:
                # The leg already PAUSED and parked valid, continuable HITL
                # state (persisted by the leg itself) - a routine deploy's
                # shutdown must not stamp CANCELLED over it. This in-memory
                # check is the ONLY protection off-Postgres: adapters without
                # the atomic primitive reach the whole-session fallback, which
                # no DB-side guard covers.
                raise
            with contextlib.suppress(Exception):
                run_response.status = RunStatus.cancelled
                await apersist_run_transition(team, "team", session_id, run_response, user_id=user_id)
            raise
        except RunCancelledException:
            # Cancelled while waiting for a slot — execution never started, so
            # persist CANCELLED and deregister the run here.
            log_info(f"Background stream run {run_id} cancelled while waiting for a slot")
            try:
                run_response.status = RunStatus.cancelled
                await apersist_run_transition(team, "team", session_id, run_response, user_id=user_id)
            except Exception:
                log_error(f"Failed to persist cancelled state for background stream run {run_id}", exc_info=True)
            await acleanup_run(run_id)
        except Exception:
            log_error(f"Background stream run {run_id} failed", exc_info=True)
            # Persist ERROR status — only the changed run (O(1))
            try:
                run_response.status = RunStatus.error
                error_run = await abuild_full_run_storage_copy(team, run_response, session_id)
                await apersist_run_transition(team, "team", session_id, error_run, user_id=user_id, full_run=True)
            except Exception:
                log_error(f"Failed to persist error state for background stream run {run_id}", exc_info=True)

        finally:
            if slot_held:
                await slot_cm.__aexit__(None, None, None)

            # Signal primary queue FIRST — unblocks the original client
            try:
                await sse_queue.put(None)
            except Exception:
                log_warning(f"Failed to signal primary queue for run {run_id} completion")

            # Mark run terminal in the event stream and wake all tails
            # (shielded to survive task cancellation)
            try:
                await asyncio.shield(event_stream.complete_run(run_id, run_response.status or RunStatus.completed))
            except (Exception, asyncio.CancelledError):
                log_warning(f"Failed to mark run {run_id} as completed in event stream")

    task = asyncio.create_task(_background_producer())
    _background_tasks.add(task)
    task.add_done_callback(_background_tasks.discard)

    # 4. Yield SSE strings from the queue. Emit SSE keepalive comments on idle
    # so proxies do not kill the connection while the run waits for a slot (or
    # during long silent stretches of execution).
    while True:
        try:
            sse_data = await asyncio.wait_for(sse_queue.get(), timeout=SSE_KEEPALIVE_INTERVAL_SECONDS)
        except asyncio.TimeoutError:
            yield ": keepalive\n\n"
            continue
        if sse_data is None:
            break
        yield sse_data


async def _arun_stream(
    team: "Team",
    run_response: TeamRunOutput,
    run_context: RunContext,
    session_id: str,
    user_id: Optional[str] = None,
    response_format: Optional[Union[Dict, Type[BaseModel]]] = None,
    stream_events: bool = False,
    yield_run_output: bool = False,
    add_dependencies_to_context: Optional[bool] = None,
    add_session_state_to_context: Optional[bool] = None,
    add_history_to_context: Optional[bool] = None,
    debug_mode: Optional[bool] = None,
    background_tasks: Optional[Any] = None,
    **kwargs: Any,
) -> AsyncIterator[Union[TeamRunOutputEvent, RunOutputEvent, TeamRunOutput]]:
    """Run the Team and return the response as a stream.

    Pre-loop setup:
    1. Setup session via _asetup_session (read/create, load state, resolve dependencies)

    Steps (inside retry loop):
    1. Execute pre-hooks
    2. Determine tools for model
    3. Prepare run messages
    4. Start memory creation in background task
    5. Reason about the task if reasoning is enabled
    6. Get a response from the model
    7. Parse response with parser model if provided
    8. Wait for background memory creation
    9. Create session summary
    10. Cleanup and store (scrub, add to session, calculate metrics, save session)
    """
    from agno.team._hooks import _aexecute_post_hooks, _aexecute_pre_hooks
    from agno.team._init import _disconnect_connectable_tools, _disconnect_mcp_tools
    from agno.team._managers import _astart_learning_task, _astart_memory_task
    from agno.team._messages import _aget_run_messages
    from agno.team._response import (
        _ahandle_model_response_stream,
        agenerate_response_with_output_model_stream,
        ahandle_reasoning_stream,
        aparse_response_with_parser_model_stream,
    )
    from agno.team._telemetry import alog_team_telemetry
    from agno.team._tools import _aget_learning_tools, _check_and_refresh_mcp_tools, _determine_tools_for_model

    # Fallback for tasks mode (streaming not yet supported)
    # Dispatch to task mode streaming if applicable
    from agno.team.mode import TeamMode

    if team.mode == TeamMode.tasks:
        async for event in _arun_tasks_stream(
            team,
            run_response=run_response,
            run_context=run_context,
            session_id=session_id,
            user_id=user_id,
            response_format=response_format,
            stream_events=stream_events,
            yield_run_output=yield_run_output,
            add_dependencies_to_context=add_dependencies_to_context,
            add_session_state_to_context=add_session_state_to_context,
            add_history_to_context=add_history_to_context,
            debug_mode=debug_mode,
            background_tasks=background_tasks,
            **kwargs,
        ):
            yield event
        return

    log_debug(f"Team Run Start: {run_response.run_id}", center=True)

    memory_task = None
    learning_task = None

    try:
        # Register run for cancellation tracking
        await aregister_run(run_context.run_id)

        # Setup session: read/create, load state, resolve dependencies
        team_session = await _asetup_session(
            team=team,
            run_context=run_context,
            session_id=session_id,
            user_id=user_id,
            run_id=run_response.run_id,
        )

        # Set up retry logic
        num_attempts = team.retries + 1
        for attempt in range(num_attempts):
            if attempt > 0:
                log_debug(f"Retrying Team run {run_response.run_id}. Attempt {attempt + 1} of {num_attempts}...")

            # Bind run_messages early — pre-hook iteration checks cancellation
            # before run_messages is built, and the cancellation handler reads it.
            run_messages: Optional[RunMessages] = None
            try:
                await araise_if_cancelled(run_response.run_id)  # type: ignore
                # 1. Execute pre-hooks
                run_input = cast(TeamRunInput, run_response.input)
                team.model = cast(Model, team.model)
                if team.pre_hooks is not None:
                    pre_hook_iterator = _aexecute_pre_hooks(
                        team,
                        hooks=team.pre_hooks,  # type: ignore
                        run_response=run_response,
                        run_context=run_context,
                        run_input=run_input,
                        session=team_session,
                        user_id=user_id,
                        debug_mode=debug_mode,
                        stream_events=stream_events,
                        background_tasks=background_tasks,
                        **kwargs,
                    )
                    async for pre_hook_event in pre_hook_iterator:
                        yield pre_hook_event

                # 2. Resolve callable factories and determine tools for model
                team_run_context: Dict[str, Any] = {}
                team.model = cast(Model, team.model)

                # Resolve callable factories (tools, knowledge, members) before tool determination
                from agno.team._tools import _aresolve_callable_resources

                await _aresolve_callable_resources(team, run_context=run_context)

                await _check_and_refresh_mcp_tools(
                    team,
                )
                learning_tools = await _aget_learning_tools(team, user_id, team_session)
                _tools = _determine_tools_for_model(
                    team,
                    model=team.model,
                    run_response=run_response,
                    run_context=run_context,
                    team_run_context=team_run_context,
                    session=team_session,  # type: ignore
                    user_id=user_id,
                    async_mode=True,
                    input_message=run_input.input_content,
                    images=run_input.images,
                    videos=run_input.videos,
                    audio=run_input.audios,
                    files=run_input.files,
                    debug_mode=debug_mode,
                    add_history_to_context=add_history_to_context,
                    add_dependencies_to_context=add_dependencies_to_context,
                    add_session_state_to_context=add_session_state_to_context,
                    stream=True,
                    stream_events=stream_events,
                    learning_tools=learning_tools,
                )

                # 3. Prepare run messages
                run_messages = await _aget_run_messages(
                    team,
                    run_response=run_response,
                    run_context=run_context,
                    session=team_session,  # type: ignore
                    user_id=user_id,
                    input_message=run_input.input_content,
                    audio=run_input.audios,
                    images=run_input.images,
                    videos=run_input.videos,
                    files=run_input.files,
                    add_history_to_context=add_history_to_context,
                    add_dependencies_to_context=add_dependencies_to_context,
                    add_session_state_to_context=add_session_state_to_context,
                    tools=_tools,
                    **kwargs,
                )

                # 4. Start memory creation in background task
                memory_task = await _astart_memory_task(
                    team,
                    run_messages=run_messages,
                    user_id=user_id,
                    existing_task=memory_task,
                )
                learning_task = await _astart_learning_task(
                    team,
                    run_messages=run_messages,
                    session=team_session,
                    user_id=user_id,
                    existing_task=learning_task,
                )

                # Yield the run started event
                if stream_events:
                    yield handle_event(  # type: ignore
                        create_team_run_started_event(from_run_response=run_response),
                        run_response,
                        events_to_skip=team.events_to_skip,
                        store_events=team.store_events,
                    )

                # 5. Reason about the task if reasoning is enabled
                async for item in ahandle_reasoning_stream(
                    team,
                    run_response=run_response,
                    run_messages=run_messages,
                    run_context=run_context,
                    stream_events=stream_events,
                ):
                    await araise_if_cancelled(run_response.run_id)  # type: ignore
                    yield item

                # Check for cancellation before model processing
                await araise_if_cancelled(run_response.run_id)  # type: ignore

                # 6. Get a response from the model
                if team.output_model is None:
                    async for event in _ahandle_model_response_stream(
                        team,
                        session=team_session,
                        run_response=run_response,
                        run_messages=run_messages,
                        tools=_tools,
                        response_format=response_format,
                        stream_events=stream_events,
                        session_state=run_context.session_state,
                        run_context=run_context,
                    ):
                        if not isinstance(event, _MEMBER_CANCEL_BYPASS_EVENT_TYPES):
                            await araise_if_cancelled(run_response.run_id)  # type: ignore
                        yield event
                else:
                    async for event in _ahandle_model_response_stream(
                        team,
                        session=team_session,
                        run_response=run_response,
                        run_messages=run_messages,
                        tools=_tools,
                        response_format=response_format,
                        stream_events=stream_events,
                        session_state=run_context.session_state,
                        run_context=run_context,
                    ):
                        if not isinstance(event, _MEMBER_CANCEL_BYPASS_EVENT_TYPES):
                            await araise_if_cancelled(run_response.run_id)  # type: ignore
                        from agno.run.team import IntermediateRunContentEvent, RunContentEvent

                        if isinstance(event, RunContentEvent):
                            if stream_events:
                                yield IntermediateRunContentEvent(
                                    content=event.content,
                                    content_type=event.content_type,
                                )
                        else:
                            yield event

                    async for event in agenerate_response_with_output_model_stream(
                        team,
                        session=team_session,
                        run_response=run_response,
                        run_messages=run_messages,
                        stream_events=stream_events,
                    ):
                        await araise_if_cancelled(run_response.run_id)  # type: ignore
                        yield event

                # Check for cancellation after model processing
                await araise_if_cancelled(run_response.run_id)  # type: ignore

                # 6b. Check if delegation propagated member HITL requirements
                if run_response.requirements and any(not req.is_resolved() for req in run_response.requirements):
                    from agno.team import _hooks

                    async for item in _hooks.ahandle_team_run_paused_stream(  # type: ignore[assignment]
                        team, run_response=run_response, session=team_session, run_context=run_context
                    ):
                        yield item
                    if yield_run_output:
                        yield run_response
                    return

                # 7. Parse response with parser model if provided
                async for event in aparse_response_with_parser_model_stream(
                    team,
                    session=team_session,
                    run_response=run_response,
                    stream_events=stream_events,
                    run_context=run_context,
                ):
                    yield event

                # Yield RunContentCompletedEvent
                if stream_events:
                    yield handle_event(  # type: ignore
                        create_team_run_content_completed_event(from_run_response=run_response),
                        run_response,
                        events_to_skip=team.events_to_skip,
                        store_events=team.store_events,
                    )

                # Execute post-hooks after output is generated but before response is returned
                if team.post_hooks is not None:
                    async for event in _aexecute_post_hooks(
                        team,
                        hooks=team.post_hooks,  # type: ignore
                        run_output=run_response,
                        run_context=run_context,
                        session=team_session,
                        user_id=user_id,
                        debug_mode=debug_mode,
                        stream_events=stream_events,
                        background_tasks=background_tasks,
                        **kwargs,
                    ):
                        yield event

                await araise_if_cancelled(run_response.run_id)  # type: ignore
                # 8. Wait for background memory creation
                async for event in await_for_thread_tasks_stream(
                    run_response=run_response,
                    memory_task=memory_task,
                    learning_task=learning_task,
                    stream_events=stream_events,
                    events_to_skip=team.events_to_skip,  # type: ignore
                    store_events=team.store_events,
                    get_memories_callback=lambda: team.aget_user_memories(user_id=user_id),
                ):
                    yield event
                merge_background_metrics(run_response.metrics, collect_background_metrics(memory_task, learning_task))

                await araise_if_cancelled(run_response.run_id)  # type: ignore

                # 9. Create session summary
                if team.session_summary_manager is not None:
                    # Upsert the RunOutput to Team Session before creating the session summary
                    team_session.upsert_run(run_response=run_response)

                    if stream_events:
                        yield handle_event(  # type: ignore
                            create_team_session_summary_started_event(from_run_response=run_response),
                            run_response,
                            events_to_skip=team.events_to_skip,
                            store_events=team.store_events,
                        )
                    try:
                        await team.session_summary_manager.acreate_session_summary(
                            session=team_session, run_metrics=run_response.metrics
                        )
                    except Exception as e:
                        log_warning(f"Error in session summary creation: {str(e)}")
                    if stream_events:
                        yield handle_event(  # type: ignore
                            create_team_session_summary_completed_event(
                                from_run_response=run_response, session_summary=team_session.summary
                            ),
                            run_response,
                            events_to_skip=team.events_to_skip,
                            store_events=team.store_events,
                        )

                await araise_if_cancelled(run_response.run_id)  # type: ignore

                # Create the run completed event
                completed_event = handle_event(
                    create_team_run_completed_event(from_run_response=run_response),
                    run_response,
                    events_to_skip=team.events_to_skip,
                    store_events=team.store_events,
                )

                # Generate followups if enabled
                from agno.team._response import agenerate_team_followups_stream

                async for event in agenerate_team_followups_stream(
                    team, run_response=run_response, stream_events=stream_events
                ):
                    yield event

                # Set the run status to completed
                run_response.status = RunStatus.completed

                # 10. Cleanup and store the run response and session
                await _acleanup_and_store(team, run_response=run_response, session=team_session)

                if stream_events:
                    yield completed_event

                if yield_run_output:
                    yield run_response

                # Log Team Telemetry
                await alog_team_telemetry(team, session_id=team_session.session_id, run_id=run_response.run_id)

                log_debug(f"Team Run End: {run_response.run_id}", center=True, symbol="*")
                break
            except RunCancelledException as e:
                run_response = _handle_team_run_cancellation(run_response, e, run_messages, session=team_session)
                cancelled_event, completed_event = _build_team_cancel_terminal_events(
                    team,
                    run_response,
                    error=e,
                    run_context=run_context,
                )
                if run_response.run_id:
                    await adrain_member_tasks(run_response.run_id)
                try:
                    await _acleanup_and_store(team, run_response=run_response, session=team_session)
                except Exception as store_err:
                    log_warning(f"Failed to persist cancelled run: {store_err}")
                yield cancelled_event  # type: ignore
                yield completed_event  # type: ignore
                if yield_run_output:
                    yield run_response
                break

            except (InputCheckError, OutputCheckError) as e:
                run_response.status = RunStatus.error
                flush_in_flight_messages_on_error_team(run_response, locals().get("run_messages"))
                run_error = create_team_run_error_event(
                    run_response,
                    error=str(e),
                    error_id=e.error_id,
                    error_type=e.type,
                    additional_data=e.additional_data,
                )
                run_response.events = add_team_error_event(error=run_error, events=run_response.events)
                if run_response.content is None:
                    run_response.content = str(e)

                log_error(f"Validation failed: {str(e)} | Check: {e.check_trigger}")

                await _acleanup_and_store(team, run_response=run_response, session=team_session)

                yield run_error

                break

            except (KeyboardInterrupt, asyncio.CancelledError, GeneratorExit) as cancel_exc:
                run_response = _handle_team_run_cancellation(
                    run_response, KeyboardInterrupt(), run_messages, session=team_session
                )
                # Build terminal events first so they are stored on the run
                cancelled_event, completed_event = _build_team_cancel_terminal_events(
                    team,
                    run_response,
                    error=KeyboardInterrupt(),
                    run_context=run_context,
                )
                if team_session is not None:
                    if isinstance(cancel_exc, (asyncio.CancelledError, GeneratorExit)):
                        # Client disconnect: persist on a detached task so the cancel scope can't abort the write.
                        # GeneratorExit is raised when the SSE StreamingResponse closes the generator on disconnect.
                        _persist_cancelled_team_run_in_background(
                            team, run_response=run_response, session=team_session, run_context=run_context
                        )
                    else:
                        # Ctrl-C under asyncio.run: persist inline; a detached task would not run before the loop exits
                        await _acleanup_and_store(
                            team, run_response=run_response, session=team_session, run_context=run_context
                        )
                # Re-raise on disconnect (client gone); yield the terminal events on Ctrl-C
                if isinstance(cancel_exc, (asyncio.CancelledError, GeneratorExit)):
                    raise
                yield cancelled_event  # type: ignore
                yield completed_event  # type: ignore
                if yield_run_output:
                    yield run_response
                break

            except Exception as e:
                if attempt < num_attempts - 1:
                    # Calculate delay with exponential backoff if enabled
                    if team.exponential_backoff:
                        delay = team.delay_between_retries * (2**attempt)
                    else:
                        delay = team.delay_between_retries

                    log_warning(f"Attempt {attempt + 1}/{num_attempts} failed. Retrying in {delay}s...: {str(e)}")
                    await asyncio.sleep(delay)
                    continue

                run_response.status = RunStatus.error
                flush_in_flight_messages_on_error_team(run_response, locals().get("run_messages"))
                run_error = create_team_run_error_event(run_response, error=str(e), error_type=error_type_of(e))
                run_response.events = add_team_error_event(error=run_error, events=run_response.events)
                if run_response.content is None:
                    run_response.content = str(e)

                log_error(f"Error in Team run: {str(e)}")

                # Cleanup and store the run response and session
                await _acleanup_and_store(team, run_response=run_response, session=team_session)

                yield run_error

    finally:
        # Always disconnect connectable tools
        _disconnect_connectable_tools(team)
        await _disconnect_mcp_tools(team)

        # Cancel background task on error (await_for_thread_tasks_stream handles waiting on success)
        if memory_task is not None and not memory_task.done():
            memory_task.cancel()
            try:
                await memory_task
            except asyncio.CancelledError:
                pass
        if learning_task is not None and not learning_task.done():
            learning_task.cancel()
            try:
                await learning_task
            except asyncio.CancelledError:
                pass

        # Always clean up the run tracking
        await acleanup_run(run_response.run_id)  # type: ignore


def arun_dispatch(  # type: ignore
    team: "Team",
    input: Union[str, List, Dict, Message, BaseModel, List[Message]],
    *,
    stream: Optional[bool] = None,
    stream_events: Optional[bool] = None,
    session_id: Optional[str] = None,
    session_state: Optional[Dict[str, Any]] = None,
    run_id: Optional[str] = None,
    run_context: Optional[RunContext] = None,
    user_id: Optional[str] = None,
    audio: Optional[Sequence[Audio]] = None,
    images: Optional[Sequence[Image]] = None,
    videos: Optional[Sequence[Video]] = None,
    files: Optional[Sequence[File]] = None,
    knowledge_filters: Optional[Union[Dict[str, Any], List[FilterExpr]]] = None,
    add_history_to_context: Optional[bool] = None,
    add_dependencies_to_context: Optional[bool] = None,
    add_session_state_to_context: Optional[bool] = None,
    dependencies: Optional[Dict[str, Any]] = None,
    metadata: Optional[Dict[str, Any]] = None,
    debug_mode: Optional[bool] = None,
    yield_run_output: bool = False,
    output_schema: Optional[Union[Type[BaseModel], Dict[str, Any]]] = None,
    background: bool = False,
    **kwargs: Any,
) -> Union[TeamRunOutput, AsyncIterator[Union[RunOutputEvent, TeamRunOutputEvent]]]:
    """Run the Team asynchronously and return the response."""

    # Set the id for the run and register it immediately for cancellation tracking
    from agno.team._init import _initialize_session
    from agno.team._response import get_response_format
    from agno.team._run_options import resolve_run_options

    run_id = run_id or str(uuid4())

    # Initialize Team
    team.initialize_team(debug_mode=debug_mode)

    # Resolve run options centrally. No session pre-read happens here: the session
    # is read inside _arun/_arun_stream AFTER options are resolved, so session-stored
    # metadata does not reach this run's resolved options (matches the agent async-DB path).
    opts = resolve_run_options(
        team,
        stream=stream,
        stream_events=stream_events,
        yield_run_output=yield_run_output,
        add_history_to_context=add_history_to_context,
        add_dependencies_to_context=add_dependencies_to_context,
        add_session_state_to_context=add_session_state_to_context,
        dependencies=dependencies,
        knowledge_filters=knowledge_filters,
        metadata=metadata,
        output_schema=output_schema,
    )

    if (opts.add_history_to_context) and not team.db and not team.parent_team_id:
        log_warning(
            "add_history_to_context is True, but no database has been assigned to the team. History will not be added to the context."
        )

    background_tasks = kwargs.pop("background_tasks", None)
    if background_tasks is not None:
        from fastapi import BackgroundTasks

        background_tasks: BackgroundTasks = background_tasks  # type: ignore

    # Validate input against input_schema if provided
    validated_input = validate_input(input, team.input_schema)

    # Normalise hook & guardrails
    if not team._hooks_normalised:
        if team.pre_hooks:
            team.pre_hooks = normalize_pre_hooks(team.pre_hooks, async_mode=True)  # type: ignore
        if team.post_hooks:
            team.post_hooks = normalize_post_hooks(team.post_hooks, async_mode=True)  # type: ignore
        team._hooks_normalised = True

    session_id, user_id = _initialize_session(team, session_id=session_id, user_id=user_id)

    image_artifacts, video_artifacts, audio_artifacts, file_artifacts = validate_media_object_id(
        images=images, videos=videos, audios=audio, files=files
    )

    # Track which options were explicitly provided for run_context precedence
    dependencies_provided = dependencies is not None
    knowledge_filters_provided = knowledge_filters is not None
    metadata_provided = metadata is not None

    # Create RunInput to capture the original user input
    run_input = TeamRunInput(
        input_content=validated_input,
        images=image_artifacts,
        videos=video_artifacts,
        audios=audio_artifacts,
        files=file_artifacts,
    )

    team.model = cast(Model, team.model)

    # Initialize run context
    run_context = run_context or RunContext(
        run_id=run_id,
        session_id=session_id,
        user_id=user_id,
        session_state=session_state,
        dependencies=opts.dependencies,
        knowledge_filters=opts.knowledge_filters,
        metadata=opts.metadata,
        output_schema=opts.output_schema,
    )
    # Apply options with precedence: explicit args > existing run_context > resolved defaults.
    opts.apply_to_context(
        run_context,
        dependencies_provided=dependencies_provided,
        knowledge_filters_provided=knowledge_filters_provided,
        metadata_provided=metadata_provided,
        user_id=user_id,
    )

    # Configure the model for runs
    response_format: Optional[Union[Dict, Type[BaseModel]]] = (
        get_response_format(team, run_context=run_context) if team.parser_model is None else None
    )

    # Create a new run_response for this attempt
    run_response = TeamRunOutput(
        run_id=run_id,
        user_id=user_id,
        session_id=session_id,
        team_id=team.id,
        team_name=team.name,
        metadata=run_context.metadata,
        session_state=run_context.session_state,
        input=run_input,
    )

    run_response.model = team.model.id if team.model is not None else None
    run_response.model_provider = team.model.provider if team.model is not None else None

    # Start the run metrics timer, to calculate the run duration
    run_response.metrics = RunMetrics()
    run_response.metrics.start_timer()

    # Background execution: return immediately with PENDING status
    if background:
        if not team.db:
            raise ValueError(
                "Background execution requires a database to be configured on the team for run persistence."
            )
        if opts.stream:
            # background=True, stream=True: run in background task, stream events via queue
            return _arun_background_stream(  # type: ignore[return-value]
                team,  # type: ignore
                run_response=run_response,
                run_context=run_context,
                session_id=session_id,
                user_id=user_id,
                add_history_to_context=opts.add_history_to_context,
                add_dependencies_to_context=opts.add_dependencies_to_context,
                add_session_state_to_context=opts.add_session_state_to_context,
                response_format=response_format,
                stream_events=opts.stream_events,
                yield_run_output=opts.yield_run_output,
                debug_mode=debug_mode,
                background_tasks=background_tasks,
                **kwargs,
            )
        return _arun_background(  # type: ignore[return-value]
            team,  # type: ignore
            run_response=run_response,
            run_context=run_context,
            session_id=session_id,
            user_id=user_id,
            add_history_to_context=opts.add_history_to_context,
            add_dependencies_to_context=opts.add_dependencies_to_context,
            add_session_state_to_context=opts.add_session_state_to_context,
            response_format=response_format,
            debug_mode=debug_mode,
            background_tasks=background_tasks,
            **kwargs,
        )

    if opts.stream:
        return _arun_stream(
            team,  # type: ignore
            run_response=run_response,
            run_context=run_context,
            session_id=session_id,
            user_id=user_id,
            add_history_to_context=opts.add_history_to_context,
            add_dependencies_to_context=opts.add_dependencies_to_context,
            add_session_state_to_context=opts.add_session_state_to_context,
            response_format=response_format,
            stream_events=opts.stream_events,
            yield_run_output=opts.yield_run_output,
            debug_mode=debug_mode,
            background_tasks=background_tasks,
            **kwargs,
        )
    else:
        return _arun(
            team,  # type: ignore
            run_response=run_response,
            run_context=run_context,
            session_id=session_id,
            user_id=user_id,
            add_history_to_context=opts.add_history_to_context,
            add_dependencies_to_context=opts.add_dependencies_to_context,
            add_session_state_to_context=opts.add_session_state_to_context,
            response_format=response_format,
            debug_mode=debug_mode,
            background_tasks=background_tasks,
            **kwargs,
        )


def _record_opted_out_media(
    team_run_response: TeamRunOutput, member_run_response: Union[TeamRunOutput, RunOutput]
) -> None:
    """Remember the media ids of a member that stores none, before its own scrub drops them.

    A delegated member's media reaches the team's row through the tool result, which carries no
    member identity, so the ids have to be taken while the member run still holds them.
    """
    from agno.utils.media_offload import opted_out_media_ids_for

    opted_out = opted_out_media_ids_for(team_run_response)
    for field_name in ("images", "videos", "audio", "files"):
        for media in getattr(member_run_response, field_name, None) or []:
            if media.id:
                opted_out.add(media.id)


def _update_team_media(team: "Team", run_response: Union[TeamRunOutput, RunOutput]) -> None:
    """Update the team state with the run response."""
    if run_response.images is not None:
        if team.images is None:
            team.images = []
        team.images.extend(run_response.images)
    if run_response.videos is not None:
        if team.videos is None:
            team.videos = []
        team.videos.extend(run_response.videos)
    if run_response.audio is not None:
        if team.audio is None:
            team.audio = []
        team.audio.extend(run_response.audio)


def _normalize_team_cancellation_reason(
    run_response: TeamRunOutput,
    error: Union[RunCancelledException, KeyboardInterrupt],
) -> str:
    """Return a non-empty, human-readable reason for a team-run cancellation."""
    if isinstance(error, RunCancelledException):
        return str(error) or f"Run {run_response.run_id} was cancelled"
    return "Operation cancelled by user"


def _handle_team_run_cancellation(
    run_response: TeamRunOutput,
    error: Union[RunCancelledException, KeyboardInterrupt],
    run_messages: Optional["RunMessages"] = None,
    session: Optional[TeamSession] = None,
) -> TeamRunOutput:
    """Prepare a team run response for cancellation: set status, preserve content and messages."""
    reason = _normalize_team_cancellation_reason(run_response, error)
    log_debug(f"Team run {run_response.run_id} was cancelled")
    run_response.status = RunStatus.cancelled
    has_partial_content = bool(run_response.content)
    if not run_response.content:
        run_response.content = reason
    if run_response.messages is None and run_messages is not None:
        messages_for_run_response = [msg for msg in run_messages.messages if msg.add_to_agent_memory]
        # Preserve partial streamed content as the assistant message, filling an empty trailing one if present
        if has_partial_content:
            partial_content = str(run_response.content)
            trailing_assistant = next(
                (msg for msg in reversed(messages_for_run_response) if msg.role == "assistant"),
                None,
            )
            if trailing_assistant is None:
                messages_for_run_response.append(Message(role="assistant", content=partial_content))
            elif not trailing_assistant.content:
                trailing_assistant.content = partial_content
        if messages_for_run_response:
            run_response.messages = messages_for_run_response
    # Cancel can interrupt the team's outer add_member_run; re-link any member runs that the
    # delegate-task cancel branch already upserted into session.runs (intent-based cancel path)
    if session is not None:
        existing_member_run_ids = {member_response.run_id for member_response in (run_response.member_responses or [])}
        for session_run in session.runs or []:
            if (
                getattr(session_run, "parent_run_id", None) == run_response.run_id
                and session_run.run_id not in existing_member_run_ids
            ):
                run_response.add_member_run(session_run)
    # Stop the timer for the Run duration
    if run_response.metrics:
        run_response.metrics.stop_timer()
    # Clear pause state so cancel wins over a paused HITL run
    if run_response.requirements:
        run_response.requirements = [req for req in run_response.requirements if req.is_resolved()]
    if run_response.tools:
        for tool in run_response.tools:
            if tool.is_paused:
                tool.requires_confirmation = False
                tool.requires_user_input = False
                tool.external_execution_required = False
    return run_response


def _build_team_cancel_terminal_events(
    team: "Team",
    run_response: TeamRunOutput,
    error: Union[RunCancelledException, KeyboardInterrupt],
    run_context: Optional[RunContext] = None,
) -> Tuple[TeamRunCancelledEvent, TeamRunCompletedEvent]:
    """Return the (cancelled, completed) terminal event pair for a cancelled team run."""
    # Update run_response.session_state before creating the events
    if run_context is not None and run_context.session_state is not None:
        run_response.session_state = run_context.session_state
    cancelled_event = cast(
        TeamRunCancelledEvent,
        handle_event(
            create_team_run_cancelled_event(
                from_run_response=run_response,
                reason=_normalize_team_cancellation_reason(run_response, error),
            ),
            run_response,
            events_to_skip=team.events_to_skip,
            store_events=team.store_events,
        ),
    )
    completed_event = cast(
        TeamRunCompletedEvent,
        handle_event(
            create_team_run_completed_event(from_run_response=run_response),
            run_response,
            events_to_skip=team.events_to_skip,
            store_events=team.store_events,
        ),
    )
    return cancelled_event, completed_event


# ---------------------------------------------------------------------------
# Post-run cleanup (moved from _storage.py)
# ---------------------------------------------------------------------------


def _iter_member_runs_for_team_run(session: TeamSession, team_run_id: Optional[str]):
    """Yield entries in session.runs that belong to the given team run.

    Pre-3.0 stored member runs flat in the runs blob alongside the team run;
    v3's runs table preserves that shape by writing each member run as its
    own row. Delegation tools push member RunOutputs into ``session.runs``
    with ``parent_run_id`` set to the parent team run (see
    ``_default_tools.py``), so we identify them by parent link.

    Yields (index_in_session_runs, member_run).
    """
    if not team_run_id or not session.runs:
        return
    for idx, entry in enumerate(session.runs):
        parent_id = getattr(entry, "parent_run_id", None)
        if parent_id == team_run_id:
            yield idx, entry


def _media_offloaded(team: "Team", session: TeamSession, member_run: Any, cache: Any) -> Any:
    """The member run with its media offloaded, or the run itself when there is nothing to offload."""
    return build_offloaded_storage_copy(team, member_run, session.session_id, cache=cache) or member_run


async def _amedia_offloaded(team: "Team", session: TeamSession, member_run: Any, cache: Any) -> Any:
    """Async variant of :func:`_media_offloaded`."""
    return await abuild_offloaded_storage_copy(team, member_run, session.session_id, cache=cache) or member_run


def _member_opted_out_of_the_store(team: "Team", member_run: Any) -> bool:
    """True when the member that produced ``member_run`` set offload_tool_results=False.

    That member has no read-back tools and no instruction about envelopes, so
    its stored run, the history it replays, must keep the whole text. A member
    this seam cannot resolve (a callable member factory needs a run context
    that storage does not carry, or the member left the team) is treated the
    same way: storing the whole text is always safe, an envelope a member
    cannot read never is.
    """
    member_id = getattr(member_run, "agent_id", None) or getattr(member_run, "team_id", None)
    if not member_id:
        return True
    found = team._find_member_by_id(str(member_id))
    if found is None:
        return True
    return getattr(found[1], "offload_tool_results", None) is False


def _member_run_for_storage(team: "Team", session: TeamSession, member_run: Any) -> Any:
    """The member run as it should be stored, with big messages offloaded.

    The live object is returned unchanged when offloading is off, so callers
    reading ``RunOutput.member_responses`` always see the whole answer. A
    sub-team offloads too: its member runs are written by the parent through
    the session copy. A workflow step's member runs are never written, so no
    storage copy is made for them.
    """
    store = getattr(team, "_result_store", None)
    if store is None or not store.member_responses:
        return member_run
    if getattr(team, "workflow_id", None) is not None or _member_opted_out_of_the_store(team, member_run):
        return member_run
    from agno.offload.runs import offload_run_for_storage

    return offload_run_for_storage(store, member_run, session_id=session.session_id, user_id=session.user_id)


async def _amember_run_for_storage(team: "Team", session: TeamSession, member_run: Any) -> Any:
    """Async variant of ``_member_run_for_storage``."""
    store = getattr(team, "_result_store", None)
    if store is None or not store.member_responses:
        return member_run
    if getattr(team, "workflow_id", None) is not None or _member_opted_out_of_the_store(team, member_run):
        return member_run
    from agno.offload.runs import aoffload_run_for_storage

    return await aoffload_run_for_storage(store, member_run, session_id=session.session_id, user_id=session.user_id)


def _persist_member_runs_for_team_run(
    team: "Team", session: TeamSession, team_run_id: Optional[str], team_run: Optional[TeamRunOutput] = None
) -> None:
    from agno.team._session import save_run
    from agno.utils.media_offload import offload_cache_for

    cache = offload_cache_for(team_run) if team_run is not None else None

    for idx, member_run in _iter_member_runs_for_team_run(session, team_run_id):
        try:
            # The team owns this write, so the team's media_storage offloads the member rows too;
            # sharing the team run's cache keeps the same bytes from being uploaded twice.
            save_run(
                team,
                run=_media_offloaded(team, session, _member_run_for_storage(team, session, member_run), cache),
                session_id=session.session_id,
                user_id=session.user_id,
                run_index=idx,
            )
        except Exception as e:
            log_debug(f"Failed to persist member run {getattr(member_run, 'run_id', None)}: {e}")


async def _apersist_member_runs_for_team_run(
    team: "Team", session: TeamSession, team_run_id: Optional[str], team_run: Optional[TeamRunOutput] = None
) -> None:
    from agno.team._session import asave_run
    from agno.utils.media_offload import offload_cache_for

    cache = offload_cache_for(team_run) if team_run is not None else None

    for idx, member_run in _iter_member_runs_for_team_run(session, team_run_id):
        try:
            await asave_run(
                team,
                run=await _amedia_offloaded(
                    team, session, await _amember_run_for_storage(team, session, member_run), cache
                ),
                session_id=session.session_id,
                user_id=session.user_id,
                run_index=idx,
            )
        except Exception as e:
            log_debug(f"Failed to persist member run {getattr(member_run, 'run_id', None)}: {e}")


def _cleanup_and_store(
    team: "Team",
    run_response: TeamRunOutput,
    session: TeamSession,
    run_context: Optional[RunContext] = None,
) -> None:
    import copy

    from agno.run.approval import update_approval_run_status
    from agno.team._session import update_session_metrics

    # Stop the timer for the Run duration, before the storage copy is taken.
    if run_response.metrics:
        run_response.metrics.stop_timer()

    # Scrub a copy for storage so the caller always sees full media. The offload helper returns
    # None when there is nothing to offload, and a shallow copy is enough for that case.
    storage_copy = build_offloaded_storage_copy(team, run_response, session.session_id) or copy.copy(run_response)

    if run_response.run_id:
        cleanup_member_runs(run_response.run_id)

    if storage_copy.member_responses and team.store_member_responses:
        # The embedded member copies hold envelopes like the session's member rows; the live
        # member runs the caller reads stay whole.
        storage_copy.member_responses = [
            _member_run_for_storage(team, session, member_run)
            for member_run in copy.deepcopy(storage_copy.member_responses)
        ]

    # Isolate member_responses: the scrub recurses into the same objects the member rows are written from.
    if not team.store_media:
        from agno.utils.agent import isolate_media_scrub_targets

        isolate_media_scrub_targets(storage_copy)

    scrub_run_output_for_storage(team, storage_copy)

    # Update run_response.session_state before saving
    if run_context is not None and run_context.session_state is not None:
        run_response.session_state = run_context.session_state
        storage_copy.session_state = run_context.session_state

    # Add scrubbed RunOutput to Team Session
    session.upsert_run(run_response=storage_copy)
    run_index = resolve_run_index(session, storage_copy)

    # Calculate session metrics
    update_session_metrics(team, session=session, run_response=run_response)

    # Update session state before saving the session
    if run_context is not None and run_context.session_state is not None:
        if session.session_data is not None:
            session.session_data["session_state"] = run_context.session_state
        else:
            session.session_data = {"session_state": run_context.session_state}

    # Persist the session row and this single run (both O(1))
    from agno.team._session import save_run

    team.save_session(session=session)
    # v3: member runs are always persisted as separate rows in the runs table
    # (source of truth for member history after reload). The store_member_responses
    # flag only controls whether the team row ALSO carries an embedded nested
    # copy in run_data.member_responses.
    _persist_member_runs_for_team_run(
        team=team, session=session, team_run_id=storage_copy.run_id, team_run=run_response
    )
    save_run(
        team,
        run=storage_copy,
        session_id=session.session_id,
        user_id=session.user_id,
        run_index=run_index,
    )

    # Update approval run_status if this run has an associated approval.
    if run_response.status is not None and run_response.run_id is not None:
        update_approval_run_status(team.db, run_response.run_id, run_response.status)


async def _acleanup_and_store(
    team: "Team",
    run_response: TeamRunOutput,
    session: TeamSession,
    run_context: Optional[RunContext] = None,
) -> None:
    import copy

    from agno.run.approval import aupdate_approval_run_status
    from agno.team._session import update_session_metrics

    # Stop the timer for the Run duration, before the storage copy is taken.
    if run_response.metrics:
        run_response.metrics.stop_timer()

    # Scrub a copy for storage so the caller always sees full media. The offload helper returns
    # None when there is nothing to offload, and a shallow copy is enough for that case.
    storage_copy = await abuild_offloaded_storage_copy(team, run_response, session.session_id) or copy.copy(
        run_response
    )

    if run_response.run_id:
        await acleanup_member_runs(run_response.run_id)

    if storage_copy.member_responses and team.store_member_responses:
        # The embedded member copies hold envelopes like the session's member rows; the live
        # member runs the caller reads stay whole.
        storage_copy.member_responses = [
            await _amember_run_for_storage(team, session, member_run)
            for member_run in copy.deepcopy(storage_copy.member_responses)
        ]

    # Isolate member_responses: the scrub recurses into the same objects the member rows are written from.
    if not team.store_media:
        from agno.utils.agent import isolate_media_scrub_targets

        isolate_media_scrub_targets(storage_copy)

    scrub_run_output_for_storage(team, storage_copy)

    # Update run_response.session_state before saving
    if run_context is not None and run_context.session_state is not None:
        run_response.session_state = run_context.session_state
        storage_copy.session_state = run_context.session_state

    # Add scrubbed RunOutput to Team Session
    session.upsert_run(run_response=storage_copy)
    run_index = resolve_run_index(session, storage_copy)

    # Calculate session metrics
    update_session_metrics(team, session=session, run_response=run_response)

    # Update session state before saving the session
    if run_context is not None and run_context.session_state is not None:
        if session.session_data is not None:
            session.session_data["session_state"] = run_context.session_state
        else:
            session.session_data = {"session_state": run_context.session_state}

    # Persist the session row and this single run (both O(1))
    from agno.team._session import asave_run

    await team.asave_session(session=session)
    # v3: member runs are always persisted as separate rows in the runs table
    # (source of truth for member history after reload). The store_member_responses
    # flag only controls whether the team row ALSO carries an embedded nested
    # copy in run_data.member_responses.
    await _apersist_member_runs_for_team_run(
        team=team, session=session, team_run_id=storage_copy.run_id, team_run=run_response
    )
    await asave_run(
        team,
        run=storage_copy,
        session_id=session.session_id,
        user_id=session.user_id,
        run_index=run_index,
    )

    # Update approval run_status if this run has an associated approval.
    if run_response.status is not None and run_response.run_id is not None:
        await aupdate_approval_run_status(team.db, run_response.run_id, run_response.status)


def _persist_cancelled_team_run_in_background(
    team: "Team",
    run_response: TeamRunOutput,
    session: TeamSession,
    run_context: Optional[RunContext] = None,
) -> None:
    """Persist a cancelled team run on a detached background task.

    On a client disconnect the request runs inside an anyio cancel scope; awaiting
    _acleanup_and_store inline lets the DB write be re-cancelled mid-flight, losing the
    run. Scheduling it on _background_tasks runs to completion outside that scope. Completed
    members' content is already on run_response; in-flight member tasks are not drained here
    since on a cancel/disconnect they are themselves cancelled and would never complete.
    """
    from agno.run.concurrency import is_worker_managed

    if run_response.run_id and is_worker_managed(run_response.run_id):
        # Worker-claimed durable run: the cancellation reaching this helper is
        # the QueueWorker's wait_for timeout or shutdown drain, not a client
        # disconnect. The worker owns the terminal write (fenced, true cause);
        # an unfenced CANCELLED here lands first and splits run row vs ticket.
        return

    async def _persist() -> None:
        try:
            await _acleanup_and_store(team, run_response=run_response, session=session, run_context=run_context)
            # The _arun finally also cleans up, but on a disconnect that await can be
            # re-cancelled; clean up here too so the run is never left tracked.
            if run_response.run_id:
                await acleanup_run(run_response.run_id)
        except Exception as store_err:
            log_warning(f"Failed to persist cancelled run: {store_err}")

    task = asyncio.create_task(_persist())
    _background_tasks.add(task)
    task.add_done_callback(_background_tasks.discard)


# ---------------------------------------------------------------------------
# Mid-run checkpointing (checkpoint="tool-batch") for Team
# Mirrors the agent-side helpers in agno/agent/_run.py.
# ---------------------------------------------------------------------------


def flush_in_flight_messages_on_error_team(
    run_response: TeamRunOutput,
    run_messages: Optional["RunMessages"],  # noqa: F821
) -> None:
    """Copy in-flight conversation into ``run_response.messages`` for the
    terminal ERROR write. Mirrors agent's ``flush_in_flight_messages_on_error``.

    Same scenario: model API call fails before any tool batch fires, so the
    mid-run checkpoint hook never ran and ``_update_run_response`` never
    populated ``run_response.messages``. Without this flush, the ERROR row
    persists with empty messages and the conversation that led to the
    failure is lost.

    Only sets ``run_response.messages`` when empty — preserves anything a
    mid-run hook captured.

    KNOWN GAP (tombstone): see the agent twin - the detached background
    wrappers never had run_messages in scope, their locals().get calls were
    no-ops and are deleted; wrapper-level errors persist without in-flight
    conversation. Threading the real flush out is a known follow-up.
    """
    if run_messages is None:
        return
    if run_response.messages:
        return
    if not run_messages.messages:
        return
    run_response.messages = [m for m in run_messages.messages if m.add_to_agent_memory]


def _persist_team_run_in_session(
    team: "Team",
    run_response: TeamRunOutput,
    session: TeamSession,
    run_context: Optional[RunContext] = None,
) -> None:
    """Persist mid-run state for a team without the terminal-only steps
    (timer stop, approval update). Same write path as ``_cleanup_and_store``
    minus those finalization side effects.
    """
    import copy

    from agno.team._session import update_session_metrics
    from agno.utils.agent import isolate_media_scrub_targets

    # Mid-run checkpoint: offload its media like the terminal write, so the row carries references.
    storage_copy = build_offloaded_storage_copy(team, run_response, session.session_id) or copy.copy(run_response)
    # Scrubbing mutates shared objects in place and a shallow copy aliases the live run, so
    # isolate what the scrubs touch.
    if not team.store_media:
        isolate_media_scrub_targets(storage_copy)
    if storage_copy.member_responses and team.store_member_responses:
        # save_session -> _scrub_member_responses scrubs each member in place;
        # deep-copy so it operates on the storage copy, not the live member runs.
        # The embedded copies hold envelopes like the session's member rows.
        storage_copy.member_responses = [
            _member_run_for_storage(team, session, member_run)
            for member_run in copy.deepcopy(storage_copy.member_responses)
        ]
    scrub_run_output_for_storage(team, storage_copy)

    if run_context is not None and run_context.session_state is not None:
        run_response.session_state = run_context.session_state
        storage_copy.session_state = run_context.session_state

    session.upsert_run(run_response=storage_copy)
    run_index = resolve_run_index(session, storage_copy)
    update_session_metrics(team, session=session, run_response=run_response)

    if run_context is not None and run_context.session_state is not None:
        if session.session_data is not None:
            session.session_data["session_state"] = run_context.session_state
        else:
            session.session_data = {"session_state": run_context.session_state}

    # Persist the session row and this single run (both O(1))
    from agno.team._session import save_run

    team.save_session(session=session)
    _persist_member_runs_for_team_run(
        team=team, session=session, team_run_id=storage_copy.run_id, team_run=run_response
    )
    save_run(
        team,
        run=storage_copy,
        session_id=session.session_id,
        user_id=session.user_id,
        run_index=run_index,
    )


async def _apersist_team_run_in_session(
    team: "Team",
    run_response: TeamRunOutput,
    session: TeamSession,
    run_context: Optional[RunContext] = None,
) -> None:
    """Async variant of :func:`_persist_team_run_in_session`."""
    import copy

    from agno.team._session import update_session_metrics
    from agno.utils.agent import isolate_media_scrub_targets

    # Mid-run checkpoint: offload its media like the terminal write, so the row carries references.
    storage_copy = await abuild_offloaded_storage_copy(team, run_response, session.session_id) or copy.copy(
        run_response
    )
    # Scrubbing mutates shared objects in place and a shallow copy aliases the live run, so
    # isolate what the scrubs touch.
    if not team.store_media:
        isolate_media_scrub_targets(storage_copy)
    if storage_copy.member_responses and team.store_member_responses:
        # save_session -> _scrub_member_responses scrubs each member in place;
        # deep-copy so it operates on the storage copy, not the live member runs.
        # The embedded copies hold envelopes like the session's member rows.
        storage_copy.member_responses = [
            await _amember_run_for_storage(team, session, member_run)
            for member_run in copy.deepcopy(storage_copy.member_responses)
        ]
    scrub_run_output_for_storage(team, storage_copy)

    if run_context is not None and run_context.session_state is not None:
        run_response.session_state = run_context.session_state
        storage_copy.session_state = run_context.session_state

    session.upsert_run(run_response=storage_copy)
    run_index = resolve_run_index(session, storage_copy)
    update_session_metrics(team, session=session, run_response=run_response)

    if run_context is not None and run_context.session_state is not None:
        if session.session_data is not None:
            session.session_data["session_state"] = run_context.session_state
        else:
            session.session_data = {"session_state": run_context.session_state}

    # Persist the session row and this single run (both O(1))
    from agno.team._session import asave_run

    await team.asave_session(session=session)
    await _apersist_member_runs_for_team_run(
        team=team, session=session, team_run_id=storage_copy.run_id, team_run=run_response
    )
    await asave_run(
        team,
        run=storage_copy,
        session_id=session.session_id,
        user_id=session.user_id,
        run_index=run_index,
    )


def _sync_team_run_response_with_model_response(
    run_response: TeamRunOutput,
    run_messages: "RunMessages",  # noqa: F821
    model_response: "ModelResponse",  # noqa: F821
) -> None:
    """Mirror the in-flight model_response state onto run_response for a team.

    Same shape as the agent helper, with one team-specific concern: ``child_run_id``
    (the delegation -> member-run link) is patched onto the existing
    ``run_response.tools`` entries during tool execution, NOT onto
    ``model_response.tool_executions``. A naive ``run_response.tools = list(...)``
    would therefore drop the linkage on every mid-run checkpoint taken after a
    delegation. Carry it over by ``tool_call_id``, mirroring the streaming merge
    in :mod:`agno.team._response`.
    """
    if model_response.tool_executions is not None:
        existing_child_run_ids = {
            tool.tool_call_id: tool.child_run_id
            for tool in (run_response.tools or [])
            if tool.tool_call_id is not None and tool.child_run_id is not None
        }
        new_tools = list(model_response.tool_executions)
        if existing_child_run_ids:
            for tool in new_tools:
                if tool.child_run_id is None and tool.tool_call_id in existing_child_run_ids:
                    tool.child_run_id = existing_child_run_ids[tool.tool_call_id]
        run_response.tools = new_tools
    run_response.messages = [m for m in run_messages.messages if m.add_to_agent_memory]


def _mark_team_checkpoint_message(run_response: TeamRunOutput) -> None:
    """Mark the current message boundary as checkpointed for client timelines."""
    if not run_response.messages:
        return
    message = run_response.messages[-1]
    message.checkpoint_status = run_response.status.value if run_response.status else None
    message.checkpoint_created_at = int(unix_time())


def checkpoint_team_run(
    team: "Team",
    run_response: TeamRunOutput,
    session: TeamSession,
    run_context: Optional[RunContext] = None,
) -> None:
    """Persist a mid-run team checkpoint. No-op unless ``team.checkpoint == "tool-batch"``."""
    if team.checkpoint != "tool-batch":
        return
    run_response.status = RunStatus.running
    run_response.last_checkpoint_at_message_index = len(run_response.messages or [])
    _mark_team_checkpoint_message(run_response)
    _persist_team_run_in_session(team, run_response, session, run_context)


async def acheckpoint_team_run(
    team: "Team",
    run_response: TeamRunOutput,
    session: TeamSession,
    run_context: Optional[RunContext] = None,
) -> None:
    """Async variant of :func:`checkpoint_team_run`."""
    if team.checkpoint != "tool-batch":
        return
    run_response.status = RunStatus.running
    run_response.last_checkpoint_at_message_index = len(run_response.messages or [])
    _mark_team_checkpoint_message(run_response)
    await _apersist_team_run_in_session(team, run_response, session, run_context)


def build_team_after_tool_results_callback(
    team: "Team",
    run_response: TeamRunOutput,
    session: TeamSession,
    run_messages: "RunMessages",  # noqa: F821
    run_context: Optional[RunContext] = None,
) -> Optional[Any]:
    """Build the sync ``after_tool_results`` callback for ``team.checkpoint='tool-batch'``.

    Returns ``None`` (the zero-cost path) when checkpointing is not enabled.
    Otherwise returns a callback that syncs run_response with the in-flight
    model_response and writes a checkpoint to the session.
    """
    if team.checkpoint != "tool-batch":
        return None

    def _callback(model_response):
        _sync_team_run_response_with_model_response(run_response, run_messages, model_response)
        checkpoint_team_run(team, run_response, session, run_context)

    return _callback


def abuild_team_after_tool_results_callback(
    team: "Team",
    run_response: TeamRunOutput,
    session: TeamSession,
    run_messages: "RunMessages",  # noqa: F821
    run_context: Optional[RunContext] = None,
) -> Optional[Any]:
    """Async variant of :func:`build_team_after_tool_results_callback`."""
    if team.checkpoint != "tool-batch":
        return None

    async def _callback(model_response):
        _sync_team_run_response_with_model_response(run_response, run_messages, model_response)
        await acheckpoint_team_run(team, run_response, session, run_context)

    return _callback


def scrub_run_output_for_storage(team: "Team", run_response: TeamRunOutput) -> bool:
    """
    Scrub run output based on storage flags before persisting to database.
    Returns True if any scrubbing was done, False otherwise.
    """
    from agno.utils.agent import (
        scrub_history_messages_from_run_output,
        scrub_media_from_run_output,
        scrub_tool_results_from_run_output,
    )

    scrubbed = False

    if not team.store_media:
        # store_media is off, so the media was never offloaded — the run keeps no pointer to it.
        scrub_media_from_run_output(run_response, keep_references=False)
        scrubbed = True

    if not team.store_tool_messages:
        scrub_tool_results_from_run_output(run_response)
        scrubbed = True

    if not team.store_history_messages:
        scrub_history_messages_from_run_output(run_response)
        scrubbed = True

    return scrubbed


def drop_opted_out_member_media(team: "Team", run_response: TeamRunOutput) -> None:
    """Remove media from member runs whose own store_media is off, before the team uploads it.

    The team offloads the whole run, member responses included, so without this a member that
    refused media persistence has its bytes written to the team's bucket anyway.
    """
    from agno.team._tools import _find_member_by_id
    from agno.team.team import Team
    from agno.utils.agent import scrub_media_from_run_output

    # Media a member surfaced as the team's own answer: by here nothing else knows which member
    # produced it. Nested runs are folded in, since a leaf's opt-out is recorded on its sub-team.
    from agno.utils.media_offload import collect_opted_out_media_ids

    opted_out = collect_opted_out_media_ids(run_response)
    if opted_out:
        for field_name in ("images", "videos", "audio", "files"):
            current = getattr(run_response, field_name, None)
            if current:
                setattr(
                    run_response,
                    field_name,
                    [m for m in current if m.id not in opted_out] or None,
                )

    for member_response in getattr(run_response, "member_responses", None) or []:
        member_id = None
        if isinstance(member_response, RunOutput):
            member_id = member_response.agent_id
        elif isinstance(member_response, TeamRunOutput):
            member_id = member_response.team_id

        if not member_id:
            continue

        member_result = _find_member_by_id(team, member_id)
        if not member_result:
            continue

        _, member = member_result
        if not member.store_media:
            scrub_media_from_run_output(member_response, keep_references=False)
        elif isinstance(member, Team) and getattr(member_response, "member_responses", None):
            drop_opted_out_member_media(member, member_response)  # type: ignore[arg-type]


def _scrub_member_responses(team: "Team", member_responses: List[Union[TeamRunOutput, RunOutput]]) -> None:
    """
    Scrub member responses based on each member's storage flags.
    This is called when saving the team session to ensure member data is scrubbed per member settings.
    Recursively handles nested team's member responses.
    """
    from agno.team._tools import _find_member_by_id
    from agno.team.team import Team

    for member_response in member_responses:
        member_id = None
        if isinstance(member_response, RunOutput):
            member_id = member_response.agent_id
        elif isinstance(member_response, TeamRunOutput):
            member_id = member_response.team_id

        if not member_id:
            log_info("Skipping member response with no ID")
            continue

        member_result = _find_member_by_id(team, member_id)
        if not member_result:
            log_debug(f"Could not find member with ID: {member_id}")
            continue

        _, member = member_result

        if not member.store_media or not member.store_tool_messages or not member.store_history_messages:
            from agno.agent._run import scrub_run_output_for_storage

            scrub_run_output_for_storage(member, run_response=member_response)  # type: ignore[arg-type]

        # If this is a nested team, recursively scrub its member responses
        if isinstance(member, Team) and isinstance(member_response, TeamRunOutput) and member_response.member_responses:
            member._scrub_member_responses(member_response.member_responses)  # type: ignore


# ---------------------------------------------------------------------------
# Run dependency resolution (moved from _tools.py)
# ---------------------------------------------------------------------------


def _resolve_run_dependencies(team: "Team", run_context: RunContext) -> None:
    from inspect import signature

    log_debug("Resolving dependencies")
    if not isinstance(run_context.dependencies, dict):
        log_warning("Dependencies is not a dict")
        return

    for key, value in run_context.dependencies.items():
        if not callable(value):
            run_context.dependencies[key] = value
            continue

        try:
            sig = signature(value)

            # Build kwargs for the function
            kwargs: Dict[str, Any] = {}
            if "agent" in sig.parameters:
                kwargs["agent"] = team
            if "team" in sig.parameters:
                kwargs["team"] = team
            if "run_context" in sig.parameters:
                kwargs["run_context"] = run_context

            resolved_value = value(**kwargs) if kwargs else value()

            run_context.dependencies[key] = resolved_value
        except Exception as e:
            log_warning(f"Failed to resolve dependencies for {key}: {str(e)}")


async def _aresolve_run_dependencies(team: "Team", run_context: RunContext) -> None:
    from inspect import iscoroutine, signature

    log_debug("Resolving context (async)")
    if not isinstance(run_context.dependencies, dict):
        log_warning("Dependencies is not a dict")
        return

    for key, value in run_context.dependencies.items():
        if not callable(value):
            run_context.dependencies[key] = value
            continue

        try:
            sig = signature(value)

            # Build kwargs for the function
            kwargs: Dict[str, Any] = {}
            if "agent" in sig.parameters:
                kwargs["agent"] = team
            if "team" in sig.parameters:
                kwargs["team"] = team
            if "run_context" in sig.parameters:
                kwargs["run_context"] = run_context

            resolved_value = value(**kwargs) if kwargs else value()

            if iscoroutine(resolved_value):
                resolved_value = await resolved_value

            run_context.dependencies[key] = resolved_value
        except Exception as e:
            log_warning(f"Failed to resolve context for '{key}': {str(e)}")


# ---------------------------------------------------------------------------
# continue_run infrastructure
# ---------------------------------------------------------------------------


def _build_continue_run_messages(
    team: "Team",
    input: List[Message],
    session: Optional[TeamSession] = None,
    add_history_to_context: Optional[bool] = None,
    run_context: Optional[RunContext] = None,
) -> RunMessages:
    """Build a RunMessages object from the existing conversation messages.

    Similar to agent's get_continue_run_messages - extracts system and user messages
    from the existing message list for the continuation run.
    """
    run_messages = RunMessages()

    if add_history_to_context is None:
        add_history_to_context = team.add_history_to_context

    # Extract most recent user message
    user_message = None
    for msg in reversed(input):
        if msg.role == "user":
            user_message = msg
            break

    # Extract system message
    system_message = None
    system_role = team.system_message_role or "system"
    for msg in input:
        if msg.role == system_role:
            system_message = msg
            break

    run_messages.system_message = system_message
    run_messages.user_message = user_message

    # Skip re-fetching history if input already contains it (run_response path).
    input_has_history = any(msg.from_history for msg in input)

    # Build messages: system first, then history (if needed), then remaining input
    if system_message is not None:
        run_messages.messages.append(system_message)

    if add_history_to_context and session is not None and not input_has_history:
        from agno.utils.message import copy_history_message, filter_tool_calls

        skip_role = team.system_message_role if team.system_message_role not in ["user", "assistant", "tool"] else None

        history: List[Message] = session.get_messages(
            last_n_runs=team.num_history_runs,
            limit=team.num_history_messages,
            skip_roles=[skip_role] if skip_role else None,
            team_id=team.id if team.parent_team_id is not None else None,
        )

        if len(history) > 0:
            history_copy = [copy_history_message(msg) for msg in history]
            if team.max_tool_calls_from_history is not None:
                filter_tool_calls(history_copy, team.max_tool_calls_from_history)
            log_debug(f"Adding {len(history_copy)} messages from history")
            run_messages.messages += history_copy

    # Add remaining input messages (skip system to avoid duplication)
    for msg in input:
        if msg is not system_message:
            run_messages.messages.append(msg)

    # Set messages on run_context so tool hooks can access the current message history
    if run_context is not None:
        run_context.messages = run_messages.messages

    return run_messages


def _get_continue_run_messages(
    team: "Team",
    input: List[Message],
    session: Optional[TeamSession] = None,
    add_history_to_context: Optional[bool] = None,
    run_context: Optional[RunContext] = None,
) -> RunMessages:
    """Build the messages that resume a paused run, reading offloaded media back first.

    The paused run's own messages come off the database carrying a reference and no bytes.
    """
    run_messages = _build_continue_run_messages(team, input, session, add_history_to_context, run_context)
    if team.media_storage is not None:
        from agno.utils.media_offload import refresh_messages_media

        refresh_messages_media(run_messages.messages, team.media_storage)
    return run_messages


async def _aget_continue_run_messages(
    team: "Team",
    input: List[Message],
    session: Optional[TeamSession] = None,
    add_history_to_context: Optional[bool] = None,
    run_context: Optional[RunContext] = None,
) -> RunMessages:
    """Async variant of :func:`_get_continue_run_messages`."""
    run_messages = _build_continue_run_messages(team, input, session, add_history_to_context, run_context)
    if team.media_storage is not None:
        from agno.utils.media_offload import arefresh_messages_media

        await arefresh_messages_media(run_messages.messages, team.media_storage)
    return run_messages


def _handle_team_tool_call_updates(
    team: "Team",
    run_response: TeamRunOutput,
    run_messages: RunMessages,
    tools: List[Union[Function, dict]],
) -> None:
    """Handle tool call updates for team-level tools.

    Mirrors agent's handle_tool_call_updates but operates on team-level tools.
    The agent-level functions (run_tool, reject_tool_call, etc.) accept ``Agent``
    in their type hints but only access duck-typed attributes (``model``, ``name``,
    etc.) that ``Team`` also provides, so passing a ``Team`` is safe at runtime.
    """
    from agno.agent._tools import (
        handle_ask_user_tool_update,
        handle_external_execution_update,
        handle_get_user_input_tool_update,
        handle_user_input_update,
        reject_tool_call,
        run_tool,
    )

    team.model = cast(Model, team.model)
    _functions = {tool.name: tool for tool in tools if isinstance(tool, Function)}

    for _t in run_response.tools or []:
        # Case 1: Handle confirmed tools and execute them
        if _t.requires_confirmation is not None and _t.requires_confirmation is True and _functions:
            if _t.confirmed is not None and _t.confirmed is True and _t.result is None:
                deque(run_tool(team, run_response, run_messages, _t, functions=_functions, team_mode=True), maxlen=0)  # type: ignore
            else:
                reject_tool_call(team, run_messages, _t, functions=_functions)  # type: ignore
                _t.confirmed = False
                _t.confirmation_note = _t.confirmation_note or "Tool call was rejected"
                _t.tool_call_error = True
            _t.requires_confirmation = False

        # Case 2: Handle external execution required tools
        elif _t.external_execution_required is not None and _t.external_execution_required is True:
            handle_external_execution_update(team, run_messages=run_messages, tool=_t, run_response=run_response)  # type: ignore

        # Case 3a: Agentic user input required
        elif _t.tool_name == "get_user_input" and _t.requires_user_input is not None and _t.requires_user_input is True:
            handle_get_user_input_tool_update(team, run_messages=run_messages, tool=_t, run_response=run_response)  # type: ignore
            _t.requires_user_input = False
            _t.answered = True

        # Case 3b: User feedback (ask_user) required
        elif _t.tool_name == "ask_user" and _t.requires_user_input is not None and _t.requires_user_input is True:
            handle_ask_user_tool_update(team, run_messages=run_messages, tool=_t, run_response=run_response)  # type: ignore
            _t.requires_user_input = False
            _t.answered = True

        # Case 4: Handle user input required tools
        elif _t.requires_user_input is not None and _t.requires_user_input is True:
            handle_user_input_update(team, tool=_t)  # type: ignore
            _t.requires_user_input = False
            _t.answered = True
            deque(run_tool(team, run_response, run_messages, _t, functions=_functions, team_mode=True), maxlen=0)  # type: ignore


def _handle_team_tool_call_updates_stream(
    team: "Team",
    run_response: TeamRunOutput,
    run_messages: RunMessages,
    tools: List[Union[Function, dict]],
    stream_events: bool = False,
) -> Iterator[Union[TeamRunOutputEvent, RunOutputEvent]]:
    """Handle tool call updates for team-level tools (sync streaming).

    Mirrors agent's handle_tool_call_updates_stream but operates on team-level tools.
    Yields events during tool execution for streaming responses.
    """
    from agno.agent._tools import (
        handle_ask_user_tool_update,
        handle_external_execution_update,
        handle_get_user_input_tool_update,
        handle_user_input_update,
        reject_tool_call,
        run_tool,
    )

    team.model = cast(Model, team.model)
    _functions = {tool.name: tool for tool in tools if isinstance(tool, Function)}

    for _t in run_response.tools or []:
        # Case 1: Handle confirmed tools and execute them
        if _t.requires_confirmation is not None and _t.requires_confirmation is True and _functions:
            if _t.confirmed is not None and _t.confirmed is True and _t.result is None:
                yield from run_tool(
                    team,  # type: ignore[arg-type]
                    run_response,  # type: ignore[arg-type]
                    run_messages,
                    _t,
                    functions=_functions,
                    stream_events=stream_events,  # type: ignore
                    team_mode=True,
                )
            else:
                reject_tool_call(team, run_messages, _t, functions=_functions)  # type: ignore
                _t.confirmed = False
                _t.confirmation_note = _t.confirmation_note or "Tool call was rejected"
                _t.tool_call_error = True
            _t.requires_confirmation = False

        # Case 2: Handle external execution required tools
        elif _t.external_execution_required is not None and _t.external_execution_required is True:
            handle_external_execution_update(team, run_messages=run_messages, tool=_t, run_response=run_response)  # type: ignore

        # Case 3a: Agentic user input required
        elif _t.tool_name == "get_user_input" and _t.requires_user_input is not None and _t.requires_user_input is True:
            handle_get_user_input_tool_update(team, run_messages=run_messages, tool=_t, run_response=run_response)  # type: ignore
            _t.requires_user_input = False
            _t.answered = True

        # Case 3b: User feedback (ask_user) required
        elif _t.tool_name == "ask_user" and _t.requires_user_input is not None and _t.requires_user_input is True:
            handle_ask_user_tool_update(team, run_messages=run_messages, tool=_t, run_response=run_response)  # type: ignore
            _t.requires_user_input = False
            _t.answered = True

        # Case 4: Handle user input required tools
        elif _t.requires_user_input is not None and _t.requires_user_input is True:
            handle_user_input_update(team, tool=_t)  # type: ignore
            yield from run_tool(
                team,  # type: ignore[arg-type]
                run_response,  # type: ignore[arg-type]
                run_messages,
                _t,
                functions=_functions,
                stream_events=stream_events,  # type: ignore
                team_mode=True,
            )
            _t.requires_user_input = False
            _t.answered = True


async def _ahandle_team_tool_call_updates(
    team: "Team",
    run_response: TeamRunOutput,
    run_messages: RunMessages,
    tools: List[Union[Function, dict]],
) -> None:
    """Async version of _handle_team_tool_call_updates.

    See _handle_team_tool_call_updates docstring for the Team/Agent duck-typing note.
    """
    from agno.agent._tools import (
        arun_tool,
        handle_ask_user_tool_update,
        handle_external_execution_update,
        handle_get_user_input_tool_update,
        handle_user_input_update,
        reject_tool_call,
    )

    team.model = cast(Model, team.model)
    _functions = {tool.name: tool for tool in tools if isinstance(tool, Function)}

    for _t in run_response.tools or []:
        if _t.requires_confirmation is not None and _t.requires_confirmation is True and _functions:
            if _t.confirmed is not None and _t.confirmed is True and _t.result is None:
                async for _ in arun_tool(team, run_response, run_messages, _t, functions=_functions, team_mode=True):  # type: ignore
                    pass
            else:
                reject_tool_call(team, run_messages, _t, functions=_functions)  # type: ignore
                _t.confirmed = False
                _t.confirmation_note = _t.confirmation_note or "Tool call was rejected"
                _t.tool_call_error = True
            _t.requires_confirmation = False

        elif _t.external_execution_required is not None and _t.external_execution_required is True:
            # The handler may offload an oversized result; the write must not run on the event loop.
            await asyncio.to_thread(
                handle_external_execution_update,
                team,  # type: ignore[arg-type]
                run_messages=run_messages,
                tool=_t,
                run_response=run_response,  # type: ignore[arg-type]
            )

        # Case 3a: Agentic user input required
        elif _t.tool_name == "get_user_input" and _t.requires_user_input is not None and _t.requires_user_input is True:
            # The handler may offload an oversized result; the write must not run on the event loop.
            await asyncio.to_thread(
                handle_get_user_input_tool_update,
                team,  # type: ignore[arg-type]
                run_messages=run_messages,
                tool=_t,
                run_response=run_response,  # type: ignore[arg-type]
            )
            _t.requires_user_input = False
            _t.answered = True

        # Case 3b: User feedback (ask_user) required
        elif _t.tool_name == "ask_user" and _t.requires_user_input is not None and _t.requires_user_input is True:
            # The handler may offload an oversized result; the write must not run on the event loop.
            await asyncio.to_thread(
                handle_ask_user_tool_update,
                team,  # type: ignore[arg-type]
                run_messages=run_messages,
                tool=_t,
                run_response=run_response,  # type: ignore[arg-type]
            )
            _t.requires_user_input = False
            _t.answered = True

        elif _t.requires_user_input is not None and _t.requires_user_input is True:
            handle_user_input_update(team, tool=_t)  # type: ignore
            _t.requires_user_input = False
            _t.answered = True
            async for _ in arun_tool(team, run_response, run_messages, _t, functions=_functions, team_mode=True):  # type: ignore
                pass


async def _ahandle_team_tool_call_updates_stream(
    team: "Team",
    run_response: TeamRunOutput,
    run_messages: RunMessages,
    tools: List[Union[Function, dict]],
    stream_events: bool = False,
) -> AsyncIterator[Union[TeamRunOutputEvent, RunOutputEvent]]:
    """Async streaming version of _handle_team_tool_call_updates.

    Mirrors agent's ahandle_tool_call_updates_stream but operates on team-level tools.
    Yields events during tool execution for async streaming responses.
    """
    from agno.agent._tools import (
        arun_tool,
        handle_ask_user_tool_update,
        handle_external_execution_update,
        handle_get_user_input_tool_update,
        handle_user_input_update,
        reject_tool_call,
    )

    team.model = cast(Model, team.model)
    _functions = {tool.name: tool for tool in tools if isinstance(tool, Function)}

    for _t in run_response.tools or []:
        # Case 1: Handle confirmed tools and execute them
        if _t.requires_confirmation is not None and _t.requires_confirmation is True and _functions:
            if _t.confirmed is not None and _t.confirmed is True and _t.result is None:
                async for event in arun_tool(
                    team,  # type: ignore[arg-type]
                    run_response,  # type: ignore[arg-type]
                    run_messages,
                    _t,
                    functions=_functions,
                    stream_events=stream_events,  # type: ignore
                    team_mode=True,
                ):
                    yield event  # type: ignore
            else:
                reject_tool_call(team, run_messages, _t, functions=_functions)  # type: ignore
                _t.confirmed = False
                _t.confirmation_note = _t.confirmation_note or "Tool call was rejected"
                _t.tool_call_error = True
            _t.requires_confirmation = False

        # Case 2: Handle external execution required tools
        elif _t.external_execution_required is not None and _t.external_execution_required is True:
            # The handler may offload an oversized result; the write must not run on the event loop.
            await asyncio.to_thread(
                handle_external_execution_update,
                team,  # type: ignore[arg-type]
                run_messages=run_messages,
                tool=_t,
                run_response=run_response,  # type: ignore[arg-type]
            )

        # Case 3a: Agentic user input required
        elif _t.tool_name == "get_user_input" and _t.requires_user_input is not None and _t.requires_user_input is True:
            # The handler may offload an oversized result; the write must not run on the event loop.
            await asyncio.to_thread(
                handle_get_user_input_tool_update,
                team,  # type: ignore[arg-type]
                run_messages=run_messages,
                tool=_t,
                run_response=run_response,  # type: ignore[arg-type]
            )
            _t.requires_user_input = False
            _t.answered = True

        # Case 3b: User feedback (ask_user) required
        elif _t.tool_name == "ask_user" and _t.requires_user_input is not None and _t.requires_user_input is True:
            # The handler may offload an oversized result; the write must not run on the event loop.
            await asyncio.to_thread(
                handle_ask_user_tool_update,
                team,  # type: ignore[arg-type]
                run_messages=run_messages,
                tool=_t,
                run_response=run_response,  # type: ignore[arg-type]
            )
            _t.requires_user_input = False
            _t.answered = True

        # Case 4: Handle user input required tools
        elif _t.requires_user_input is not None and _t.requires_user_input is True:
            handle_user_input_update(team, tool=_t)  # type: ignore
            async for event in arun_tool(
                team,  # type: ignore[arg-type]
                run_response,  # type: ignore[arg-type]
                run_messages,
                _t,
                functions=_functions,
                stream_events=stream_events,  # type: ignore
                team_mode=True,
            ):
                yield event  # type: ignore
            _t.requires_user_input = False
            _t.answered = True


def _normalize_requirements_payload(
    requirements: List[Any],
) -> List[Any]:
    """Convert dicts in the requirements list to RunRequirement objects."""
    from agno.run.requirement import RunRequirement

    result = []
    for req in requirements:
        if isinstance(req, dict):
            result.append(RunRequirement.from_dict(req))
        else:
            result.append(req)
    return result


def _merge_tools_preserving_approval(
    original_tools: List[Any],
    updated_tools_map: Dict[str, Any],
) -> List[Any]:
    """Merge updated tool executions from the continue payload with the original session tools.

    When a client sends tool updates during continue_run, the payload typically
    only includes HITL-relevant fields (confirmed, answered, user_input_schema, etc.)
    and omits approval metadata (approval_type, approval_id). A naive replacement
    would lose these fields, preventing the approval resolution gate from finding
    and applying the admin's decision to the correct tools.

    This function preserves approval_type and approval_id from the session originals
    whenever the incoming tool does not carry them.
    """
    merged: List[Any] = []
    for orig in original_tools:
        updated = updated_tools_map.get(orig.tool_call_id)
        if updated is not None:
            for attr in ("approval_type", "approval_id"):
                if getattr(updated, attr, None) is None and getattr(orig, attr, None) is not None:
                    setattr(updated, attr, getattr(orig, attr))
            merged.append(updated)
        else:
            merged.append(orig)
    return merged


def _fill_user_input_answers(stored_schema: Optional[List[Any]], wire_schema: Optional[List[Any]]) -> bool:
    """Fill the stored schema's open fields from the wire copy, keyed by field name.

    Returns True if a field the model had left open was filled.
    """
    if not stored_schema or not wire_schema:
        return False
    answers = {field.name: field.value for field in wire_schema if getattr(field, "value", None) is not None}
    filled = False
    for field in stored_schema:
        if field.value is None and field.name in answers:
            field.value = answers[field.name]
            filled = True
    return filled


def _fill_user_feedback_answers(stored_schema: Optional[List[Any]], wire_schema: Optional[List[Any]]) -> bool:
    """Fill the stored schema's unanswered questions from the wire copy, keyed by question.

    Returns True if a question the model had left open was answered.
    """
    if not stored_schema or not wire_schema:
        return False
    selections = {
        question.question: question.selected_options
        for question in wire_schema
        if getattr(question, "selected_options", None) is not None
    }
    filled = False
    for question in stored_schema:
        if question.selected_options is None and question.question in selections:
            question.selected_options = selections[question.question]
            if question.options:
                for option in question.options:
                    option.selected = option.label in question.selected_options
            filled = True
    return filled


def _merge_requirement_decision(stored: Any, wire: Any) -> None:
    """Copy the client's decision state onto the canonical stored requirement.

    Only decision fields cross over: confirmation, user input and feedback
    answers, and — solely for external-execution tools — the result. Identity
    and routing (tool_execution, tool_args, member provenance) stay the
    stored requirement's own; a result on a non-external tool is dropped
    because honoring it would suppress the confirmed tool's execution.

    The schemas are filled field by field, never rebound. The wire copy is a
    client document: rebinding it would put client-chosen field NAMES into the
    schema that ``handle_user_input_update`` writes into ``tool_args``
    immediately before the call, so a renamed field overwrites an argument the
    model fixed at pause time. Answers therefore land by stored field name, and
    only in fields the model left open.

    ``answered`` is inferred from the stored schema — when this merge fills
    the last open field — and never copied off the wire while a field is
    still open, which would otherwise run the gated tool with its fields
    still empty. Once nothing is open (the schema was answered here, was
    fully prefilled by the model at pause time, or never existed) the wire's
    explicit flag stands: a prefilled pause has no open field to fill, so
    the flag is its only accept gesture.
    """
    stored_te = getattr(stored, "tool_execution", None)
    wire_te = getattr(wire, "tool_execution", None)

    # Whether the model left anything open, read before any answer lands. The
    # requirement-level schema and tool_execution's are often the same list
    # object, so "did this call fill something" cannot carry the signal — the
    # first fill would consume it and the run would never read as answered.
    stored_input_schema = getattr(stored_te, "user_input_schema", None) if stored_te is not None else None
    stored_feedback_schema = getattr(stored_te, "user_feedback_schema", None) if stored_te is not None else None
    input_was_open = any(field.value is None for field in stored_input_schema or [])
    feedback_was_open = any(question.selected_options is None for question in stored_feedback_schema or [])

    for attr in ("confirmation", "confirmation_note"):
        if getattr(wire, attr, None) is not None:
            setattr(stored, attr, getattr(wire, attr))
    _fill_user_input_answers(getattr(stored, "user_input_schema", None), getattr(wire, "user_input_schema", None))
    _fill_user_feedback_answers(
        getattr(stored, "user_feedback_schema", None), getattr(wire, "user_feedback_schema", None)
    )
    if stored_te is not None and wire_te is not None:
        for attr in ("confirmed", "confirmation_note"):
            if getattr(wire_te, attr, None) is not None:
                setattr(stored_te, attr, getattr(wire_te, attr))
        # Dispatch reads only tool_execution's schema, so answers sent at either
        # level have to reach it.
        _fill_user_input_answers(stored_input_schema, wire_te.user_input_schema)
        _fill_user_input_answers(stored_input_schema, getattr(wire, "user_input_schema", None))
        _fill_user_feedback_answers(stored_feedback_schema, wire_te.user_feedback_schema)
        _fill_user_feedback_answers(stored_feedback_schema, getattr(wire, "user_feedback_schema", None))
        if stored_te.answered is None:
            input_open_now = any(field.value is None for field in stored_input_schema or [])
            feedback_open_now = any(question.selected_options is None for question in stored_feedback_schema or [])
            if input_was_open and not input_open_now:
                stored_te.answered = True
            elif feedback_was_open and not feedback_open_now:
                stored_te.answered = True
            elif getattr(wire_te, "answered", None) is True and not input_open_now and not feedback_open_now:
                # A schema the model prefilled completely was never open, so
                # the fill-based inference above can never fire for it. The
                # client's explicit flag is the accept gesture for such a
                # pause; without honoring it the run could never resume. A
                # still-open field keeps the flag ignored — answering is the
                # schema's job, not the flag's.
                #
                # Only True is a gesture. Writing a wire False would close the
                # `answered is None` guard above for good, and nothing ever
                # re-opens it: the pause would stay unresumable for the rest of
                # the session, with no way for the client to recover.
                stored_te.answered = wire_te.answered
        if getattr(stored_te, "external_execution_required", None):
            if getattr(wire_te, "result", None) is not None:
                stored_te.result = wire_te.result
            # The result and the flag that says it is a failure travel together:
            # binding the result alone rebinds a frontend's reported error as a
            # success, and the tool message renders it as one.
            if getattr(wire_te, "tool_call_error", None) is not None:
                stored_te.tool_call_error = wire_te.tool_call_error
    if (
        stored_te is not None
        and getattr(stored_te, "external_execution_required", None)
        and getattr(wire, "external_execution_result", None) is not None
    ):
        stored.external_execution_result = wire.external_execution_result


def _backfill_approval_to_requirements(
    run_response: Any,
    old_requirements: Optional[List[Any]] = None,
) -> None:
    """Bind the continue payload's requirements to the stored originals.

    Requirements arrive from the wire (to_dict() strips None values, raw
    dicts are accepted), so every field on them is unverified client input.
    When the pre-overwrite stored requirements are available, each payload
    entry must bind one-to-one to a stored requirement — matched by
    requirement id, falling back to tool_call_id only when the supplied id
    matches no stored requirement (ids are client-optional and regenerate on
    deserialization, so an unknown id is indistinguishable from an absent
    one) and exactly one stored requirement carries that tool call — and
    the STORED requirement becomes the object routing sees, with only the
    client's decision state merged onto it (_merge_requirement_decision).
    Trusting the wire copy instead mis-executes: a swapped or duplicated id
    binds one member's approved arguments to another member's tool.

    Raises RunNotContinuableError — with the run left paused — for a payload
    entry whose matched id names a different tool call than the entry carries
    (a conflicting identity must not fall back to the tool call), that is
    ambiguous (several stored requirements share its tool_call_id and no id
    matches), matches no stored requirement, or maps a stored requirement
    that another entry already claimed.

    Without stored requirements (a caller-supplied bare run object), the
    payload is kept as-is and only approval metadata is backfilled from
    run_response.tools, whose approval fields _merge_tools_preserving_approval
    already preserved.
    """
    reqs = getattr(run_response, "requirements", None)
    if not reqs:
        return

    # Build lookups from both sources
    by_id: Dict[str, Any] = {}
    old_by_req_id: Dict[str, Any] = {}
    old_by_tool_call_id: Dict[str, List[Any]] = {}
    # Old requirements first (lower priority)
    if old_requirements:
        for old_req in old_requirements:
            old_req_id = getattr(old_req, "id", None)
            if old_req_id:
                old_by_req_id[old_req_id] = old_req
            old_te = getattr(old_req, "tool_execution", None)
            if old_te and old_te.tool_call_id:
                by_id[old_te.tool_call_id] = old_te
                old_by_tool_call_id.setdefault(old_te.tool_call_id, []).append(old_req)
    # run_response.tools second (higher priority, overwrites)
    for t in getattr(run_response, "tools", None) or []:
        if t.tool_call_id and getattr(t, "approval_type", None) is not None:
            by_id[t.tool_call_id] = t

    for req in reqs:
        te = getattr(req, "tool_execution", None)
        if te and te.tool_call_id and te.tool_call_id in by_id:
            src = by_id[te.tool_call_id]
            for attr in ("approval_type", "approval_id"):
                if getattr(te, attr, None) is None and getattr(src, attr, None) is not None:
                    setattr(te, attr, getattr(src, attr))

    if not old_requirements:
        return

    run_id = getattr(run_response, "run_id", None)
    matched: Set[int] = set()
    bindings: List[Tuple[Any, Any]] = []
    for req in reqs:
        te = getattr(req, "tool_execution", None)
        tool_call_id = te.tool_call_id if te is not None else None
        old_req = old_by_req_id.get(getattr(req, "id", None) or "")
        if old_req is not None and tool_call_id:
            old_te = getattr(old_req, "tool_execution", None)
            if old_te is not None and old_te.tool_call_id and old_te.tool_call_id != tool_call_id:
                # A matched id whose tool call disagrees is a conflicting
                # identity, not a fallback case: dropping the id match here
                # would bind the client's decision to whichever requirement
                # owns the payload's tool call — another member's tool.
                raise RunNotContinuableError(
                    f"Cannot continue run {run_id}: the requirement with id '{getattr(req, 'id', None)}' "
                    f"names tool call '{tool_call_id}', but the stored requirement with that id belongs "
                    f"to tool call '{old_te.tool_call_id}'. Resend the requirements exactly as issued. "
                    "The run remains paused."
                )
        if old_req is None and tool_call_id:
            candidates = old_by_tool_call_id.get(tool_call_id, [])
            if len(candidates) == 1:
                old_req = candidates[0]
            elif len(candidates) > 1:
                raise RunNotContinuableError(
                    f"Cannot continue run {run_id}: the requirement for tool call '{tool_call_id}' "
                    f"matches {len(candidates)} stored requirements and carries no matching "
                    "requirement id. Resend the requirements with their original 'id' values. "
                    "The run remains paused."
                )
        if old_req is None:
            raise RunNotContinuableError(
                f"Cannot continue run {run_id}: the requirement with id '{getattr(req, 'id', None)}' "
                f"and tool call '{tool_call_id}' matches no stored requirement of this run. "
                "The run remains paused."
            )
        if id(old_req) in matched:
            raise RunNotContinuableError(
                f"Cannot continue run {run_id}: two payload requirements both resolve to the stored "
                f"requirement '{getattr(old_req, 'id', None)}'. The run remains paused."
            )
        matched.add(id(old_req))
        bindings.append((old_req, req))

    # Nothing is written until the whole payload has bound. Merging inside the
    # loop above would leave the entries before a refusal holding the client's
    # decision, and the refusal restores list references, not field values — so
    # a bare retry of a rejected request would execute the tools that bound
    # before the bad entry.
    for old_req, req in bindings:
        _merge_requirement_decision(old_req, req)
    run_response.requirements = [old_req for old_req, _ in bindings]


_REQUIREMENT_DECISION_FIELDS = ("confirmation", "confirmation_note", "external_execution_result")
_TOOL_EXECUTION_DECISION_FIELDS = ("confirmed", "confirmation_note", "answered", "result", "tool_call_error")


def _requirement_decision_slots(requirements: Optional[List[Any]]) -> Iterator[Tuple[Any, str]]:
    """Yield every (object, attribute) pair _merge_requirement_decision writes.

    The merge fills schemas in place and never rebinds a list, so the objects
    reached here before the merge are the same ones it writes to.
    """
    for req in requirements or []:
        for attr in _REQUIREMENT_DECISION_FIELDS:
            yield req, attr
        for holder in (req, getattr(req, "tool_execution", None)):
            if holder is None:
                continue
            if holder is not req:
                for attr in _TOOL_EXECUTION_DECISION_FIELDS:
                    yield holder, attr
            for field in getattr(holder, "user_input_schema", None) or []:
                yield field, "value"
            for question in getattr(holder, "user_feedback_schema", None) or []:
                yield question, "selected_options"
                for option in getattr(question, "options", None) or []:
                    yield option, "selected"


def _snapshot_requirement_decisions(requirements: Optional[List[Any]]) -> List[Tuple[Any, str, Any]]:
    """Record the stored requirements' decision state before a payload is merged."""
    return [(obj, attr, getattr(obj, attr, None)) for obj, attr in _requirement_decision_slots(requirements)]


def _restore_requirement_decisions(snapshot: List[Tuple[Any, str, Any]]) -> None:
    """Put the decision state recorded by _snapshot_requirement_decisions back.

    Restoring the requirements list alone is not enough for a gate that refuses
    a continue after the payload has bound: the entries on that list are the
    stored requirements the merge wrote into, so the client's decision would
    survive a refusal the caller was told left the run untouched.
    """
    for obj, attr, value in snapshot:
        setattr(obj, attr, value)


def _apply_requirements_payload(
    run_response: TeamRunOutput,
    requirements: List[Any],
) -> Tuple[Optional[List["RunRequirement"]], Optional[List[Any]], List[Tuple[Any, str, Any]]]:
    """Apply a continue payload to the run object, keeping it intact on refusal.

    Normalizes the payload, binds it to the stored requirements
    (_backfill_approval_to_requirements), and merges the bound tool
    executions into run_response.tools. On a refusal the run object gets its
    requirements, tools, and decision fields back before the raise: the
    refusal asks the client to resend the stored ids, which a caller-supplied
    live run object only still has if nothing was overwritten — and a merge
    that raised mid-payload has already banked the earlier entries' decisions
    onto the stored requirements.

    Returns (old_requirements, old_tools, decisions) so the caller can restore
    all three if a later step of its payload apply raises.
    """
    old_requirements = run_response.requirements
    old_tools = run_response.tools
    decisions = _snapshot_requirement_decisions(old_requirements)
    run_response.requirements = _normalize_requirements_payload(requirements)
    try:
        _backfill_approval_to_requirements(run_response, old_requirements=old_requirements)
    except Exception:
        run_response.requirements = old_requirements
        run_response.tools = old_tools
        # The merge loop can raise on a malformed entry after earlier entries
        # already wrote their decisions onto the stored requirements; the list
        # references alone leave those banked.
        _restore_requirement_decisions(decisions)
        raise
    # Merge the bound tool executions into the run's tools, preserving
    # approval fields the FE omits. After binding these are the stored
    # requirements' own tool executions carrying the client's decisions.
    updated_tools = [req.tool_execution for req in run_response.requirements or [] if req.tool_execution is not None]
    if updated_tools and run_response.tools:
        updated_tools_map = {tool.tool_call_id: tool for tool in updated_tools if tool.tool_call_id}
        run_response.tools = _merge_tools_preserving_approval(run_response.tools, updated_tools_map)
    elif updated_tools:
        run_response.tools = updated_tools
    return old_requirements, old_tools, decisions


def _reclaim_own_requirements(
    team: "Team", requirements: Optional[List[Any]], continuing_run_id: Optional[str]
) -> Optional[List[Any]]:
    """Clear the member stamp from requirements that belong to this team itself.

    When a sub-team's OWN tool pauses, _propagate_member_pause stamps the
    sub-team's member id on the lifted requirement so the parent can route it
    back down. Once the requirement arrives at the team it names, the stamp's
    job is done: the requirement is this team's own, team-level requirement.
    Without reclaiming it, member routing looks the team's own id up among
    its members, finds nothing, and refuses the continue.

    A matching id alone does not prove ownership: a member may share the
    team's id, or its url-safe name (get_member_id falls back to the name).
    The requirement is the team's own only if it also points at the run being
    continued at this dispatch level — _propagate_member_pause stamps
    member_run_id alongside member_agent_id, and for a member's requirement
    that is the member's run id, never this team's. A requirement without
    member_run_id is never reclaimed: to_dict() strips None values, so a wire
    payload may omit the field, and _backfill_approval_to_requirements
    restores it from the stored session requirements before dispatch reaches
    this function.

    Returns the list to route with. A reclaimed requirement is de-stamped on a
    COPY: when a parent team routes a sub-team's lifted requirement down, the
    objects on the sub-team's run are the parent's own, and the parent still
    lists them. De-stamping in place would leave the parent holding what looks
    like a team-level requirement of its own, so if anything below this
    dispatch refuses, the caller's run object comes back mis-routed — the very
    retry the refusal promises would then skip the approved tool."""
    from copy import copy

    from agno.utils.team import get_member_id

    if not requirements:
        return requirements
    if not any(getattr(req, "member_agent_id", None) is not None for req in requirements):
        return requirements
    own_id = get_member_id(team)
    if not own_id:
        return requirements
    reclaimed: List[Any] = []
    for req in requirements:
        member_run_id = getattr(req, "member_run_id", None)
        if (
            getattr(req, "member_agent_id", None) == own_id
            and member_run_id is not None
            and member_run_id == continuing_run_id
        ):
            req = copy(req)
            req.member_agent_id = None
            req.member_agent_name = None
        reclaimed.append(req)
    return reclaimed


def _has_member_requirements(requirements: List[Any]) -> bool:
    """Check if any requirements are for member agents (have member_agent_id set)."""
    return any(getattr(req, "member_agent_id", None) is not None for req in requirements)


def _has_team_level_requirements(requirements: List[Any]) -> bool:
    """Check if any requirements are for team-level tools (no member_agent_id)."""
    return any(getattr(req, "member_agent_id", None) is None for req in requirements)


def _member_continue_kwargs_from_run_context(run_context: Optional[RunContext]) -> Dict[str, Any]:
    """Build kwargs to forward team run_context state to a member's continue_run call.

    Without this, member tools resumed via continue_run would lose access to the
    dependencies/metadata/knowledge_filters the team carried at pause time
    (see https://github.com/agno-agi/agno/issues/8135). The member's session_state
    is rehydrated from the shared DB session, so it does not need to be forwarded
    here (and `Agent.acontinue_run` does not accept a `session_state` parameter).
    """
    if run_context is None:
        return {}

    kwargs: Dict[str, Any] = {}
    if run_context.user_id is not None:
        kwargs["user_id"] = run_context.user_id
    if run_context.dependencies is not None:
        kwargs["dependencies"] = run_context.dependencies
    if run_context.metadata is not None:
        kwargs["metadata"] = run_context.metadata
    if run_context.knowledge_filters is not None:
        kwargs["knowledge_filters"] = run_context.knowledge_filters
    return kwargs


def _team_run_references_member_run(team_run: TeamRunOutput, member_run_id: str) -> bool:
    """True if the team run owns member_run_id — as a run in its
    member-response subtree or as a requirement it carries."""
    stack: List[Union[TeamRunOutput, RunOutput]] = list(team_run.member_responses or [])
    while stack:
        candidate = stack.pop()
        if getattr(candidate, "run_id", None) == member_run_id:
            return True
        stack.extend(getattr(candidate, "member_responses", None) or [])
    for req in team_run.requirements or []:
        if getattr(req, "member_run_id", None) == member_run_id:
            return True
    return False


def _resolve_member_run_output_for_continue(
    member: Union["Agent", "Team"],
    reqs: List["RunRequirement"],
    run_response: TeamRunOutput,
    session: TeamSession,
) -> Optional[Union[RunOutput, TeamRunOutput]]:
    """Resolve the paused run output to hand to the routed member's continue_run.

    For an agent member this is its paused RunOutput; for a sub-team member it
    is the sub-team's paused TeamRunOutput (the sub-team's own continue_run
    routes deeper from there). Sources, in order:

    1. The ``_member_run_response`` reference stored by _propagate_member_pause,
       which resolves without a session or DB lookup. The reference is validated
       by IDENTITY against the routed member: each propagation level points it
       at the run that surfaced the pause AT that level, so below the top level
       it references an ancestor team run, not the routed member's run. An
       invalid reference falls through to the lookups below, which resolve
       level by level.
    2. Same-process resume: the paused member output still held on the live
       team run's member_responses.
    3. After process restart: the team session's sibling runs persisted in the
       DB (member_responses is only assembled at runtime).
    4. Sub-team members only: the direct child team run that owns the
       requirement — the deep member's paused run lives inside it, persisted
       there by save_session's paused-run exemption.
    """
    from agno.team.team import Team
    from agno.utils.team import get_member_id

    member_run_output = getattr(reqs[0], "_member_run_response", None) if reqs else None
    member_run_id = reqs[0].member_run_id if reqs else None
    routed_to_team = isinstance(member, Team)

    if member_run_output is not None and member_run_id is not None:
        if routed_to_team:
            valid = (
                isinstance(member_run_output, TeamRunOutput)
                and member_run_output.run_id != run_response.run_id
                and (
                    member_run_output.run_id == member_run_id
                    or (member_run_output.team_id is not None and member_run_output.team_id == get_member_id(member))
                )
            )
        else:
            valid = getattr(member_run_output, "run_id", None) == member_run_id
        if not valid:
            member_run_output = None

    if member_run_output is None and member_run_id:
        if run_response.member_responses:
            for sibling_response in run_response.member_responses:
                if getattr(sibling_response, "run_id", None) == member_run_id:
                    member_run_output = sibling_response
                    break
        if member_run_output is None and session is not None and session.runs:
            for session_run in session.runs:
                if getattr(session_run, "run_id", None) == member_run_id:
                    member_run_output = session_run  # type: ignore[assignment]
                    break
        if member_run_output is None and routed_to_team:
            candidates: List[Union[TeamRunOutput, RunOutput]] = list(run_response.member_responses or [])
            if session is not None and session.runs:
                candidates.extend(r for r in session.runs if getattr(r, "parent_run_id", None) == run_response.run_id)
            for candidate in candidates:
                if not isinstance(candidate, TeamRunOutput) or candidate.run_id == run_response.run_id:
                    continue
                if _team_run_references_member_run(candidate, member_run_id):
                    member_run_output = candidate
                    break

    return member_run_output


def _group_requirements_for_continue(
    team: "Team",
    run_response: TeamRunOutput,
    session: TeamSession,
    run_context: Optional[RunContext],
    _depth: int = 0,
) -> List[Tuple[Union["Agent", "Team"], Optional[Union[RunOutput, TeamRunOutput]], List["RunRequirement"]]]:
    """Group HITL requirements by the paused run that will continue them.

    Requirements are keyed by (deep member agent id, deep member run id) and
    resolved to their target run up front. Groups whose requirements resolve
    to the SAME sub-team run are merged into one continue_run call — that
    run's own dispatch routes them deeper; a second call on the same run
    would hit an already-completed run and drop its confirmations. Groups
    that resolve to DIFFERENT runs of the same sub-team (the leader delegated
    to it more than once in one turn) stay separate — merging them would
    strand every run but the first.

    Raises RunNotContinuableError if a requirement routes to a member id
    that is not in the team: the run stays paused and resumable instead of
    completing with the approved tool silently skipped.

    The leaf-id route and run ownership can disagree: sibling sub-teams may
    contain members with the same leaf id, and _find_member_route_by_id picks
    the first match in member order while the paused run lives under another
    sibling. The resolved run's owner is authoritative for where the continue
    dispatches — following the leaf-id pick would hand one sibling's paused
    run to the other and execute the wrong tool implementation. When the
    owner cannot be resolved to exactly one direct member (it was removed
    from the team, or several direct members share its id), the continue is
    refused and the run stays paused.

    Returns entries of (routed_member, resolved_target_run_or_None, requirements).
    """
    from agno.team._tools import _find_member_route_by_id
    from agno.utils.callables import get_resolved_members
    from agno.utils.team import get_member_id

    member_reqs: Dict[Tuple[str, Optional[str]], List["RunRequirement"]] = {}
    for req in run_response.requirements or []:
        mid = getattr(req, "member_agent_id", None)
        if mid is not None:
            member_reqs.setdefault((mid, getattr(req, "member_run_id", None)), []).append(req)

    entries: List[Tuple[Union["Agent", "Team"], Optional[Union[RunOutput, TeamRunOutput]], List["RunRequirement"]]] = []
    for (member_id, _), reqs in member_reqs.items():
        route_result = _find_member_route_by_id(team, member_id, run_context=run_context)
        if route_result is None:
            raise RunNotContinuableError(
                f"Cannot continue run {run_response.run_id}: requirement routes to member "
                f"'{member_id}', which is not a member of team '{team.name or team.id}'. "
                "The run remains paused."
            )
        _, member = route_result
        target = _resolve_member_run_output_for_continue(member, reqs, run_response, session)
        owner_id: Optional[str] = None
        if isinstance(target, TeamRunOutput):
            owner_id = target.team_id
        elif isinstance(target, RunOutput):
            owner_id = target.agent_id
        if owner_id is not None:
            owners = [m for m in get_resolved_members(team, run_context) or [] if get_member_id(m) == owner_id]
            if len(owners) == 1:
                member = owners[0]
            elif not owners:
                raise RunNotContinuableError(
                    f"Cannot continue run {run_response.run_id}: the paused run for requirement "
                    f"'{member_id}' belongs to member '{owner_id}', which is not a member of "
                    f"team '{team.name or team.id}'. The run remains paused."
                )
            else:
                raise RunNotContinuableError(
                    f"Cannot continue run {run_response.run_id}: the paused run for requirement "
                    f"'{member_id}' belongs to member id '{owner_id}', which matches "
                    f"{len(owners)} members of team '{team.name or team.id}'. The run remains paused."
                )
        merged = False
        if target is not None:
            for existing_member, existing_target, existing_reqs in entries:
                if (
                    existing_member is member
                    and existing_target is not None
                    and (existing_target is target or existing_target.run_id == target.run_id)
                ):
                    existing_reqs.extend(reqs)
                    merged = True
                    break
        if not merged:
            entries.append((member, target, list(reqs)))

    if _depth < _MAX_CONTINUE_PREFLIGHT_DEPTH:
        _preflight_subteam_routes(entries, session, _depth)
    return entries


_MAX_CONTINUE_PREFLIGHT_DEPTH = 12


def _preflight_subteam_routes(
    entries: List[Tuple[Union["Agent", "Team"], Optional[Union[RunOutput, TeamRunOutput]], List["RunRequirement"]]],
    session: TeamSession,
    depth: int,
) -> None:
    """Raise now if any sub-team in these entries could not route its own share.

    Refusals at this level are all-or-nothing: nothing has run when they fire.
    A sub-team's refusal is not, because the sub-team only reaches its own
    grouping once its continue_run is already under way — by then the members
    scheduled alongside it have executed their approved tools. The caller is
    then told the run is still paused, which is false for those members, and
    the retry it invites runs them again.

    Descending here moves that refusal back to where it is still free. The
    sub-team's grouping is a pure resolution pass over stored state — it
    executes nothing — so running it early costs a lookup and buys the
    all-or-nothing guarantee the refusal message claims.

    This closes resolution drift, which is what a reload can introduce: a
    member renamed or removed while the run sat paused. It cannot close a
    failure that strikes mid-execution, so routing stays best-effort past this
    point.
    """
    from agno.team.team import Team

    for member, target, _reqs in entries:
        if not isinstance(member, Team) or not isinstance(target, TeamRunOutput):
            continue
        if not _has_member_requirements(target.requirements or []):
            continue
        _group_requirements_for_continue(member, target, session, None, _depth=depth + 1)


def _route_requirements_to_members(
    team: "Team",
    run_response: TeamRunOutput,
    session: TeamSession,
    run_context: Optional[RunContext] = None,
) -> List[str]:
    """Route member requirements back to the appropriate member agents (sync, non-streaming).

    Groups requirements by member_agent_id, calls member.continue_run() for each,
    and returns a list of result descriptions for building a continuation message.

    Returns:
        List of member result strings.
    """
    from agno.utils.team import get_member_id

    groups = _group_requirements_for_continue(team, run_response, session, run_context)
    member_results: List[str] = []

    for member, member_run_output, reqs in groups:
        member_id = get_member_id(member) or ""
        member_run_id = reqs[0].member_run_id if reqs else None

        member_run_id = getattr(member_run_output, "run_id", None) if member_run_output is not None else member_run_id
        if member_run_id and run_response.run_id is not None:
            register_member_run(run_response.run_id, member_run_id)

        # Forward team's run_context state to the member so dependencies and
        # session_state remain accessible to member tools after continue_run.
        member_continue_kwargs = _member_continue_kwargs_from_run_context(run_context)

        if member_run_output is not None:
            # Update requirements and tool executions on the member's run output
            member_run_output.requirements = reqs
            updated_tools = [req.tool_execution for req in reqs if req.tool_execution is not None]
            if updated_tools and member_run_output.tools:
                updated_map = {t.tool_call_id: t for t in updated_tools}
                member_run_output.tools = [updated_map.get(t.tool_call_id, t) for t in member_run_output.tools]

            member_response = member.continue_run(
                run_response=member_run_output,  # type: ignore[arg-type]
                session_id=session.session_id,
                **member_continue_kwargs,
            )
        else:
            # Fallback: use run_id (requires DB or cached session)
            member_response = member.continue_run(  # type: ignore[arg-type]
                run_id=member_run_id,
                requirements=reqs,
                session_id=session.session_id,
                **member_continue_kwargs,
            )

        # Check if member is still paused (chained HITL)
        if getattr(member_response, "is_paused", False):
            from agno.team._tools import _propagate_member_pause

            _propagate_member_pause(run_response, member, member_response)
            # Persist paused member run so continue_run can find it after session reload
            session.upsert_run(_member_run_for_storage(team, session, member_response))
        else:
            # Update the member's run in the team session so its status is persisted
            # (member agents skip save_session when team_id is set)
            session.upsert_run(_member_run_for_storage(team, session, member_response))

            content = getattr(member_response, "content", None) or "Task completed"
            member_results.append(f"[{member.name or member_id}]: {content}")

        # Clear _member_run_response references to allow GC of the member RunOutput
        for req in reqs:
            req._member_run_response = None

    return member_results


def _route_requirements_to_members_stream(
    team: "Team",
    run_response: TeamRunOutput,
    session: TeamSession,
    member_results: List[str],
    run_context: Optional[RunContext] = None,
    stream_events: bool = False,
) -> Iterator[Union[TeamRunOutputEvent, RunOutputEvent]]:
    """Route member requirements back to the appropriate member agents (sync, streaming).

    Yields member streaming events (RunContent, etc.) to the caller, and appends
    result descriptions to the provided member_results list.

    Following the same pattern as delegate_task_to_member: iterate the member's
    streaming response, yield intermediate events, capture the final RunOutput.

    Args:
        member_results: Mutable list to collect member result strings.

    Yields:
        Member streaming events (RunOutputEvent, TeamRunOutputEvent).
    """
    from agno.utils.team import get_member_id

    groups = _group_requirements_for_continue(team, run_response, session, run_context)

    for member, member_run_output, reqs in groups:
        member_id = get_member_id(member) or ""
        member_run_id = reqs[0].member_run_id if reqs else None

        member_run_id = getattr(member_run_output, "run_id", None) if member_run_output is not None else member_run_id
        if member_run_id and run_response.run_id is not None:
            register_member_run(run_response.run_id, member_run_id)

        # Forward team's run_context state to the member so dependencies and
        # session_state remain accessible to member tools after continue_run.
        member_continue_kwargs = _member_continue_kwargs_from_run_context(run_context)

        if member_run_output is not None:
            member_run_output.requirements = reqs
            updated_tools = [req.tool_execution for req in reqs if req.tool_execution is not None]
            if updated_tools and member_run_output.tools:
                updated_map = {t.tool_call_id: t for t in updated_tools}
                member_run_output.tools = [updated_map.get(t.tool_call_id, t) for t in member_run_output.tools]

            member_response_stream = member.continue_run(  # type: ignore[call-overload]
                run_response=member_run_output,  # type: ignore[arg-type]
                session_id=session.session_id,
                stream=True,
                stream_events=stream_events or team.stream_member_events,
                yield_run_output=True,
                **member_continue_kwargs,
            )
        else:
            member_response_stream = member.continue_run(  # type: ignore[call-overload]
                run_id=member_run_id,
                requirements=reqs,
                session_id=session.session_id,
                stream=True,
                stream_events=stream_events or team.stream_member_events,
                yield_run_output=True,
                **member_continue_kwargs,
            )

        # Iterate the member's streaming response — yield intermediate events,
        member_response: Optional[Union[RunOutput, TeamRunOutput]] = None
        for event in member_response_stream:  # type: ignore[union-attr]
            if isinstance(event, (RunOutput, TeamRunOutput)):
                member_response = event
                continue  # Don't yield the final RunOutput

            if not isinstance(event, _MEMBER_CANCEL_BYPASS_EVENT_TYPES):
                raise_if_cancelled(run_response.run_id)  # type: ignore

            # Set parent_run_id on member events (same as delegate_task_to_member)
            event.parent_run_id = getattr(event, "parent_run_id", None) or run_response.run_id

            # Forward member terminals regardless of stream_events so the wire always sees a terminal.
            if isinstance(event, _MEMBER_CANCEL_BYPASS_EVENT_TYPES) or stream_events or team.stream_member_events:
                yield handle_event(
                    event,
                    run_response,
                    events_to_skip=team.events_to_skip,
                    store_events=team.store_events,
                )

        if member_response is None:
            log_warning(f"Member {member_id} streaming did not yield a final RunOutput")
            member_results.append(f"[{member.name or member_id}]: Task completed (no final output)")
        elif getattr(member_response, "is_paused", False):
            from agno.team._tools import _propagate_member_pause

            _propagate_member_pause(run_response, member, member_response)
            # Persist paused member run so continue_run can find it after session reload
            session.upsert_run(_member_run_for_storage(team, session, member_response))
        else:
            session.upsert_run(_member_run_for_storage(team, session, member_response))
            content = getattr(member_response, "content", None) or "Task completed"
            member_results.append(f"[{member.name or member_id}]: {content}")

        # Clear _member_run_response references to allow GC of the member RunOutput
        for req in reqs:
            req._member_run_response = None


async def _aroute_requirements_to_members(
    team: "Team",
    run_response: TeamRunOutput,
    session: TeamSession,
    run_context: Optional[RunContext] = None,
) -> List[str]:
    """Route member requirements back to the appropriate member agents (async, non-streaming).

    Runs member continue_run() calls concurrently with asyncio.gather.

    Returns:
        List of member result strings.
    """
    from agno.utils.team import get_member_id

    groups = _group_requirements_for_continue(team, run_response, session, run_context)

    if not groups:
        return []

    async def _continue_member(
        member: Union["Agent", "Team"],
        member_run_output: Optional[Union[RunOutput, TeamRunOutput]],
        reqs: List["RunRequirement"],
    ) -> Optional[str]:
        member_id = get_member_id(member) or ""
        member_run_id = reqs[0].member_run_id if reqs else None

        member_run_id = getattr(member_run_output, "run_id", None) if member_run_output is not None else member_run_id
        if member_run_id and run_response.run_id is not None:
            await aregister_member_run(run_response.run_id, member_run_id)

        # Forward team's run_context state to the member so dependencies and
        # session_state remain accessible to member tools after continue_run.
        member_continue_kwargs = _member_continue_kwargs_from_run_context(run_context)

        if member_run_output is not None:
            member_run_output.requirements = reqs
            updated_tools = [req.tool_execution for req in reqs if req.tool_execution is not None]
            if updated_tools and member_run_output.tools:
                updated_map = {t.tool_call_id: t for t in updated_tools}
                member_run_output.tools = [updated_map.get(t.tool_call_id, t) for t in member_run_output.tools]

            member_response = await member.acontinue_run(  # type: ignore[misc]
                run_response=member_run_output,  # type: ignore[arg-type]
                session_id=session.session_id,
                **member_continue_kwargs,
            )
        else:
            member_response = await member.acontinue_run(  # type: ignore[misc]
                run_id=member_run_id,
                requirements=reqs,
                session_id=session.session_id,
                **member_continue_kwargs,
            )

        # Clear _member_run_response references to allow GC of the member RunOutput
        for req in reqs:
            req._member_run_response = None

        if getattr(member_response, "is_paused", False):
            from agno.team._tools import _propagate_member_pause

            _propagate_member_pause(run_response, member, member_response)
            # Persist paused member run so continue_run can find it after session reload
            session.upsert_run(await _amember_run_for_storage(team, session, member_response))
            return None
        else:
            # Update the member's run in the team session so its status is persisted
            # (member agents skip save_session when team_id is set, so we do it here)
            session.upsert_run(await _amember_run_for_storage(team, session, member_response))

            content = getattr(member_response, "content", None) or "Task completed"
            return f"[{member.name or member_id}]: {content}"

    tasks = [_continue_member(member, member_run_output, reqs) for member, member_run_output, reqs in groups]
    results = await asyncio.gather(*tasks, return_exceptions=True)

    member_results: List[str] = []
    for r in results:
        if isinstance(r, RunNotContinuableError):
            # A member (e.g. a sub-team) refused the continue outright; the
            # paused state is intact, so surface it instead of completing
            # the team run without the approved tool.
            raise r
        if isinstance(r, BaseException):
            log_warning(f"Member continue_run failed: {r}")
        elif isinstance(r, str):
            member_results.append(r)
    return member_results


async def _aroute_requirements_to_members_stream(
    team: "Team",
    run_response: TeamRunOutput,
    session: TeamSession,
    member_results: List[str],
    run_context: Optional[RunContext] = None,
    stream_events: bool = False,
) -> AsyncIterator[Union[TeamRunOutputEvent, RunOutputEvent]]:
    """Route member requirements back to the appropriate member agents (async, streaming).

    Yields member streaming events (RunContent, etc.) to the caller, and appends
    result descriptions to the provided member_results list.

    Following the same pattern as adelegate_task_to_member: iterate the member's
    async streaming response, yield intermediate events, capture the final RunOutput.

    Note: When streaming, members are processed sequentially (not with asyncio.gather)
    because we need to yield events as they arrive.

    Args:
        member_results: Mutable list to collect member result strings.

    Yields:
        Member streaming events (RunOutputEvent, TeamRunOutputEvent).
    """
    from agno.utils.team import get_member_id

    groups = _group_requirements_for_continue(team, run_response, session, run_context)

    for member, member_run_output, reqs in groups:
        member_id = get_member_id(member) or ""
        member_run_id = reqs[0].member_run_id if reqs else None

        member_run_id = getattr(member_run_output, "run_id", None) if member_run_output is not None else member_run_id
        if member_run_id and run_response.run_id is not None:
            await aregister_member_run(run_response.run_id, member_run_id)

        # Forward team's run_context state to the member so dependencies and
        # session_state remain accessible to member tools after continue_run.
        member_continue_kwargs = _member_continue_kwargs_from_run_context(run_context)

        if member_run_output is not None:
            member_run_output.requirements = reqs
            updated_tools = [req.tool_execution for req in reqs if req.tool_execution is not None]
            if updated_tools and member_run_output.tools:
                updated_map = {t.tool_call_id: t for t in updated_tools}
                member_run_output.tools = [updated_map.get(t.tool_call_id, t) for t in member_run_output.tools]

            member_response_stream = member.acontinue_run(  # type: ignore[call-overload]
                run_response=member_run_output,  # type: ignore[arg-type]
                session_id=session.session_id,
                stream=True,
                stream_events=stream_events or team.stream_member_events,
                yield_run_output=True,
                **member_continue_kwargs,
            )
        else:
            member_response_stream = member.acontinue_run(  # type: ignore[call-overload]
                run_id=member_run_id,
                requirements=reqs,
                session_id=session.session_id,
                stream=True,
                stream_events=stream_events or team.stream_member_events,
                yield_run_output=True,
                **member_continue_kwargs,
            )

        # Iterate the member's async streaming response — yield intermediate events,
        member_response: Optional[Union[RunOutput, TeamRunOutput]] = None
        async for event in member_response_stream:  # type: ignore[union-attr]
            if isinstance(event, (RunOutput, TeamRunOutput)):
                member_response = event
                continue  # Don't yield the final RunOutput

            if not isinstance(event, _MEMBER_CANCEL_BYPASS_EVENT_TYPES):
                await araise_if_cancelled(run_response.run_id)  # type: ignore

            # Set parent_run_id on member events (same as adelegate_task_to_member)
            event.parent_run_id = getattr(event, "parent_run_id", None) or run_response.run_id

            # Forward member terminals regardless of stream_events so the wire always sees a terminal.
            if isinstance(event, _MEMBER_CANCEL_BYPASS_EVENT_TYPES) or stream_events or team.stream_member_events:
                yield handle_event(
                    event,
                    run_response,
                    events_to_skip=team.events_to_skip,
                    store_events=team.store_events,
                )

        if member_response is None:
            log_warning(f"Member {member_id} streaming did not yield a final RunOutput")
            member_results.append(f"[{member.name or member_id}]: Task completed (no final output)")
        elif getattr(member_response, "is_paused", False):
            from agno.team._tools import _propagate_member_pause

            _propagate_member_pause(run_response, member, member_response)
            # Persist paused member run so continue_run can find it after session reload
            session.upsert_run(await _amember_run_for_storage(team, session, member_response))
        else:
            session.upsert_run(await _amember_run_for_storage(team, session, member_response))
            content = getattr(member_response, "content", None) or "Task completed"
            member_results.append(f"[{member.name or member_id}]: {content}")

        # Clear _member_run_response references to allow GC of the member RunOutput
        for req in reqs:
            req._member_run_response = None


def _build_continuation_message(member_results: List[str]) -> str:
    """Build a user message from member results to feed back into the team model."""
    if not member_results:
        return "The delegated task has been completed."
    parts = ["Member results after human-in-the-loop resolution:"]
    parts.extend(member_results)
    return "\n".join(parts)


def _tool_result_requires_human_input(tool: ToolExecution) -> bool:
    result = tool.result or ""
    return isinstance(result, str) and "requires human input" in result.lower()


def _prepare_member_hitl_continuation(
    run_response: TeamRunOutput,
    run_messages: RunMessages,
    member_results: List[str],
) -> None:
    """Prepare run_response and run_messages for member HITL continuation.

    Updates the delegate_task_to_member/delegate_task_to_members tool result in both
    run_response.tools and the corresponding message in run_messages. Also resets run
    state for continuation.

    This is called after the member agent's HITL has been resolved and we need to
    continue the team run with the member's results.
    """

    continuation_message = _build_continuation_message(member_results)

    target_tool_call_ids: set[str] = set()
    for tool in run_response.tools or []:
        if tool.tool_name in {
            "delegate_task_to_member",
            "delegate_task_to_members",
        } and _tool_result_requires_human_input(tool):
            tool.result = continuation_message
            if tool.tool_call_id is not None:
                target_tool_call_ids.add(tool.tool_call_id)

    if not target_tool_call_ids:
        for tool in run_response.tools or []:
            if _tool_result_requires_human_input(tool):
                tool.result = continuation_message
                if tool.tool_call_id is not None:
                    target_tool_call_ids.add(tool.tool_call_id)

    # Update the existing tool result messages in run_messages
    if target_tool_call_ids:
        for msg in run_messages.messages:
            if msg.role == "tool" and msg.tool_call_id in target_tool_call_ids:
                msg.content = continuation_message

    # Reset run state for continuation
    run_response.status = RunStatus.running
    run_response.content = None


async def _ahandle_model_response_for_continue(
    team: "Team",
    run_response: TeamRunOutput,
    run_messages: RunMessages,
    run_context: RunContext,
    tools: List[Any],
    team_session: "TeamSession",
    response_format: Optional[Any] = None,
) -> Optional[TeamRunOutput]:
    """Handle async model response for team continue_run (non-streaming).

    Shared logic for both team-level and member HITL continuation.
    Returns the run_response if paused (needs to return early), otherwise None.
    """
    from agno.team._response import (
        _convert_response_to_structured_format,
        _update_run_response,
        agenerate_response_with_output_model,
        aparse_response_with_parser_model,
    )

    team.model = cast(Model, team.model)
    model_response: ModelResponse = await acall_model_with_fallback(
        team.model,
        team.fallback_config,
        messages=run_messages.messages,
        response_format=response_format,
        tools=tools,
        tool_choice=team.tool_choice,
        tool_call_limit=team.tool_call_limit,
        run_response=run_response,
        send_media_to_model=team.send_media_to_model,
        compression_manager=team.compression_manager if team.compress_tool_results else None,
        **result_store_kwargs(team),
        after_tool_results=abuild_team_after_tool_results_callback(
            team, run_response, team_session, run_messages, run_context
        ),
    )

    await araise_if_cancelled(run_response.run_id)  # type: ignore

    await agenerate_response_with_output_model(team, model_response, run_messages, run_response=run_response)
    await aparse_response_with_parser_model(
        team, model_response, run_messages, run_context=run_context, run_response=run_response
    )

    _update_run_response(
        team,
        model_response=model_response,
        run_response=run_response,
        run_messages=run_messages,
        run_context=run_context,
    )

    # Check for new pauses
    if run_response.requirements and any(not req.is_resolved() for req in run_response.requirements):
        from agno.team import _hooks

        return await _hooks.ahandle_team_run_paused(
            team, run_response=run_response, session=team_session, run_context=run_context
        )

    _convert_response_to_structured_format(team, run_response=run_response, run_context=run_context)
    store_media_util(run_response, model_response)

    return None  # Continue with post-hooks


# ---------------------------------------------------------------------------
# Continue / fork / truncate helpers
# Mirrors the agent-side helpers in agno/agent/_run.py with one additional
# concern: team runs have member RunOutput rows in session.runs (linked via
# parent_run_id). On fork, these get deep-copied with fresh run_ids so the
# forked team owns its own member rows (per design decision).
# ---------------------------------------------------------------------------


def _truncate_team_run_to_checkpoint(run_response: "TeamRunOutput", message_index: int) -> None:
    """Truncate the team run's messages to length ``message_index`` and
    prune tools / requirements that referenced removed messages.

    Time-travel for teams. Mirrors :func:`agno.agent._run._truncate_run_to_checkpoint`
    in shape; the only team-specific consideration is that ``member_responses``
    survives truncation untouched — a member completed delegation is a
    permanent fact in the team's history regardless of where we rewind to.
    """
    if run_response.messages is None or message_index < 0:
        return
    if message_index >= len(run_response.messages):
        return

    # Snap the boundary down so we never cut between an assistant tool_call and
    # its result (an orphaned call is rejected by most providers).
    from agno.utils.message import safe_truncation_index

    safe_index = safe_truncation_index(run_response.messages, message_index)
    if safe_index != message_index:
        log_warning(
            f"Truncation index {message_index} would orphan a tool call; "
            f"snapped to {safe_index} to keep the transcript valid."
        )
    message_index = safe_index

    run_response.messages = run_response.messages[:message_index]

    valid_tool_call_ids: set = set()
    for msg in run_response.messages:
        tool_call_id = getattr(msg, "tool_call_id", None)
        if tool_call_id:
            valid_tool_call_ids.add(tool_call_id)
        tool_calls = getattr(msg, "tool_calls", None) or []
        for tc in tool_calls:
            tc_id = tc.get("id") if isinstance(tc, dict) else getattr(tc, "id", None)
            if tc_id:
                valid_tool_call_ids.add(tc_id)

    if run_response.tools:
        run_response.tools = [t for t in run_response.tools if t.tool_call_id in valid_tool_call_ids]
    if run_response.requirements:
        run_response.requirements = [
            req
            for req in run_response.requirements
            if req.tool_execution and req.tool_execution.tool_call_id in valid_tool_call_ids
        ]

    run_response.last_checkpoint_at_message_index = message_index


def _fork_team_run(run_response: "TeamRunOutput", message_index: int) -> "TeamRunOutput":
    """Deep-clone a team run with a new ``run_id``, set fork metadata, and
    truncate to ``message_index``.

    Scope is the team's own state (messages, tools, requirements, metrics).
    Member runs that the original team produced stay where they are — they
    are durable records of delegation work attached to the **original** team
    via ``parent_run_id``. The forked team's ``member_responses`` field
    points at those same member objects (deep-copied so mutating the fork
    can't corrupt them), but no new member rows are written to the session.

    Rationale: from the team's perspective a member is just a tool the team
    delegated to — its output is already baked into the team's messages.
    Forking the team is parity with agent forking; member state is out of
    scope, same as fallback models / parser models / followups.

    Resets ``metrics`` and ``created_at`` so the fork reports only its own
    work — same invariant as agent's :func:`_fork_run`.
    """
    import copy
    from time import time as _time

    from agno.utils.message import safe_truncation_index

    # Snap to a pair-safe boundary so fork metadata matches the truncation that
    # _truncate_team_run_to_checkpoint will actually perform.
    message_index = safe_truncation_index(run_response.messages or [], message_index)

    forked = copy.deepcopy(run_response)
    forked.run_id = str(uuid4())
    forked.forked_from_run_id = run_response.run_id
    forked.forked_from_message_index = message_index
    forked.metrics = RunMetrics()
    # Start the fork's duration timer now (dispatch-level, same granularity as
    # the run path). The fresh RunMetrics has no timer and the continue path
    # never starts one, so without this the fork's RunCompleted event has no
    # duration (stop_timer only sets duration when a timer was started).
    forked.metrics.start_timer()
    forked.created_at = int(_time())
    # Fork is a new run — don't inherit the parent's events. With
    # store_events=True the new run's events would otherwise be the parent's
    # events with this run's events appended onto them.
    forked.events = None

    _truncate_team_run_to_checkpoint(forked, message_index)
    return forked


def _apply_continue_modifiers_team(
    run_response: "TeamRunOutput",
    fork: bool,
    message_index: Optional[int],
) -> "TeamRunOutput":
    """Apply ``fork`` and/or ``message_index`` to a loaded team run_response.

    Mirrors agent's :func:`_apply_continue_modifiers`. Returns the same
    instance when only truncating, a new instance (with cloned members)
    when forking.
    """
    if fork:
        idx = message_index if message_index is not None else len(run_response.messages or [])
        return _fork_team_run(run_response, idx)
    if message_index is not None:
        _truncate_team_run_to_checkpoint(run_response, message_index)
    return run_response


def _will_truncate_team_run(run_response: "TeamRunOutput", message_index: Optional[int]) -> bool:
    if message_index is None:
        return False
    return 0 <= message_index < len(run_response.messages or [])


def _find_regenerate_checkpoint_team(run_response: "TeamRunOutput") -> int:
    """For ``regenerate=True``, compute the message index to truncate to.

    Mirrors agent's :func:`_find_regenerate_checkpoint` (parity with PR
    #7157's ``_strip_final_assistant_messages``): drop ONLY the trailing
    assistant messages without ``tool_calls`` — i.e. the final response.
    Intermediate tool-calling assistant messages and their tool results
    are preserved, so regeneration produces a fresh summary of the same
    tool outputs without re-running tools.
    """
    messages = run_response.messages or []
    i = len(messages)
    while i > 0 and messages[i - 1].role == "assistant" and not messages[i - 1].tool_calls:
        i -= 1
    if i == 0:
        raise ValueError("Cannot regenerate: team run has no non-assistant messages to regenerate from.")
    return i


def _find_last_user_message_index_team(run_response: "TeamRunOutput") -> int:
    """For ``continue_from="last_user"``: walk backwards to the last user
    message and return its index + 1. Drops everything past it (including
    intermediate tool exchanges) — distinct from regenerate, which keeps
    intermediate tool calls.
    """
    messages = run_response.messages or []
    for i in range(len(messages) - 1, -1, -1):
        if messages[i].role == "user":
            return i + 1
    raise ValueError("Cannot resolve `continue_from='last_user'`: team run has no user messages.")


def _resolve_continue_from_team(
    run_response: "TeamRunOutput",
    *,
    continue_from: Union[int, Literal["end", "last_user"]],
    regenerate: bool = False,
) -> int:
    """Resolve the public continuation selector into a message boundary index.

    See :func:`agno.agent._run._resolve_continue_from` for the agent equivalent;
    ``"last_user"`` and ``regenerate=True`` have intentionally different
    semantics (the latter preserves intermediate tool exchanges).
    """
    if regenerate:
        if continue_from in ("end", "last_user"):
            return _find_regenerate_checkpoint_team(run_response)
        raise ValueError("`regenerate=True` derives the continuation boundary automatically.")

    messages = run_response.messages or []
    if isinstance(continue_from, int):
        return continue_from
    if continue_from == "end":
        return len(messages)
    if continue_from == "last_user":
        return _find_last_user_message_index_team(run_response)

    raise ValueError("`continue_from` must be an integer message index, 'end', or 'last_user'.")


def _restore_continue_context_metadata_team(
    run_context: RunContext,
    run_response: Optional["TeamRunOutput"],
    run_id: Optional[str],
    session: Optional[TeamSession],
) -> None:
    """Reserved run-metadata for a resume comes from the paused run row, never
    from caller input: a rebuilt lineage presents a nested run as top-level and
    resets the dispatch guard one approval at a time. Safe at every continue
    entry point -- restoring the same stored values twice is a no-op."""
    from agno.db.schemas.scheduler import restore_reserved_run_metadata

    stored_run = (
        run_response
        if run_response is not None
        else next((r for r in getattr(session, "runs", None) or [] if getattr(r, "run_id", None) == run_id), None)
    )
    run_context.metadata = restore_reserved_run_metadata(run_context.metadata, getattr(stored_run, "metadata", None))


def _resolve_continue_owner_team(
    run_response: Optional["TeamRunOutput"],
    *,
    run_id: Optional[str],
    session: Optional[TeamSession],
) -> Optional[str]:
    """Owner stored on the team run being continued."""
    if run_response is not None:
        return run_response.user_id
    if session is not None:
        return next((run.user_id for run in session.runs or [] if run.run_id == run_id), None)
    return None


def _normalize_regenerate_params_team(
    run_response: Optional["TeamRunOutput"],
    *,
    regenerate: bool,
    replace_original: Optional[bool],
    additional_instructions: Optional[str],
    fork: bool,
    continue_index: Optional[int],
    input: Optional[str],
) -> Tuple[bool, Optional[int], Optional[str]]:
    """Normalize regenerate-sugar params for teams. Mirrors agent helper.

    ``regenerate=True`` ALWAYS forks (1-run-1-loop invariant); the source run is
    always retained in storage. ``replace_original`` controls history visibility
    of the source only. It defaults to True: the source is marked ``REGENERATED``
    so history-builders skip it and the new run replaces it. Pass False to keep
    both runs visible. Only meaningful with ``regenerate=True``.
    """
    if additional_instructions is not None and input is not None:
        raise ValueError("Provide either `additional_instructions` or `input`, not both.")
    if replace_original is not None and not regenerate:
        raise ValueError("`replace_original` only makes sense with `regenerate=True`.")

    if not regenerate:
        return fork, continue_index, input

    if fork:
        raise ValueError(
            "`regenerate=True` derives the destructive/preserving choice from "
            "`replace_original`; do not pass `fork=True` directly."
        )
    if run_response is None:
        raise ValueError("`regenerate=True` requires a loaded run_response to compute the checkpoint.")

    resolved_input = additional_instructions if additional_instructions is not None else input
    return (True, _find_regenerate_checkpoint_team(run_response), resolved_input)


def _maybe_append_input_message_team(
    run_response: "TeamRunOutput",
    new_input: Optional[str],
    team: "Team",
) -> None:
    """Append a new user-role message to the team run's ``messages`` so the
    model loop sees it. Used when the caller passes ``input=`` or
    ``additional_instructions=`` to /continue.
    """
    if not new_input:
        return
    new_message = Message(role="user", content=new_input)
    if run_response.messages is None:
        run_response.messages = [new_message]
    else:
        run_response.messages.append(new_message)


# ---------------------------------------------------------------------------
# Session forking — mirrors agent's fork_session_dispatch
# ---------------------------------------------------------------------------


def _build_forked_team_session(source_session: TeamSession, new_user_id: Optional[str]) -> TeamSession:
    """Deep-copy ``source_session`` into a brand-new ``TeamSession`` with a
    fresh ``session_id`` and fresh ``run_id``s for every copied run.

    Lineage shape mirrors the agent:
    - ``session.session_data["forked_from_session_id"]``: the immediate parent
      session_id (overwritten on each re-fork).
    - ``run.forked_from_session_id``: each run's **original** session_id, set
      only-if-empty so nested forks keep pointing at the root.
    """
    import copy
    import time as _time

    now = int(_time.time())
    new_session_id = str(uuid4())
    forked_runs = copy.deepcopy(source_session.runs or [])

    for run in forked_runs:
        run.run_id = str(uuid4())
        run.session_id = new_session_id
        if not getattr(run, "forked_from_session_id", None):
            run.forked_from_session_id = source_session.session_id

    new_session_data = copy.deepcopy(source_session.session_data) or {}
    new_session_data["forked_from_session_id"] = source_session.session_id

    return TeamSession(
        session_id=new_session_id,
        team_id=source_session.team_id,
        user_id=new_user_id or source_session.user_id,
        workflow_id=source_session.workflow_id,
        team_data=copy.deepcopy(source_session.team_data),
        session_data=new_session_data,
        metadata=copy.deepcopy(source_session.metadata),
        runs=forked_runs,
        summary=copy.deepcopy(source_session.summary),
        created_at=now,
        updated_at=now,
    )


def _mark_team_run_regenerated(
    team: "Team",
    session: TeamSession,
    original_run_id: str,
) -> None:
    """Flip the parent team run's status to ``REGENERATED`` and persist that
    single row. Under v3 storage, mutating ``session.runs[i].status`` in memory
    is not enough: ``save_session`` writes only the session row, so without an
    explicit ``save_run`` here the DB row keeps its old status and history
    builders still surface the parent — producing duplicate content after
    regenerate."""
    from agno.team._session import save_run

    for r in session.runs or []:
        if r.run_id == original_run_id:
            r.status = RunStatus.regenerated
            save_run(
                team,
                run=r,
                session_id=session.session_id,
                user_id=session.user_id,
                run_index=resolve_run_index(session, r),
            )
            return


async def _amark_team_run_regenerated(
    team: "Team",
    session: TeamSession,
    original_run_id: str,
) -> None:
    """Async variant of :func:`_mark_team_run_regenerated`."""
    from agno.team._session import asave_run

    for r in session.runs or []:
        if r.run_id == original_run_id:
            r.status = RunStatus.regenerated
            await asave_run(
                team,
                run=r,
                session_id=session.session_id,
                user_id=session.user_id,
                run_index=resolve_run_index(session, r),
            )
            return


def fork_session_dispatch(
    team: "Team",
    *,
    source_session_id: Optional[str] = None,
    user_id: Optional[str] = None,
) -> str:
    """Branch a team session into a new independent session (sync)."""
    from agno.team._init import _has_async_db
    from agno.team._storage import _read_or_create_session

    if _has_async_db(team):
        raise RuntimeError("`fork_session` is not supported with an async database. Use `afork_session` instead.")

    source_session_id = source_session_id or team.session_id
    if source_session_id is None:
        raise ValueError("source_session_id is required to fork a session.")

    team.initialize_team()
    source_session = _read_or_create_session(team, session_id=source_session_id, user_id=user_id)
    if not source_session.runs:
        raise ValueError("Source session has no runs to fork.")

    new_session = _build_forked_team_session(source_session, new_user_id=user_id)
    team.save_session(session=new_session)

    # Under v3 storage, save_session no longer writes runs — persist each
    # forked run individually so the new session isn't observably empty.
    from agno.team._session import save_run

    for idx, run in enumerate(new_session.runs or []):
        # Offload gives the fork its own objects; a cached source session still holds them inline.
        storage_run = build_offloaded_storage_copy(team, cast(TeamRunOutput, run), new_session.session_id) or run
        save_run(
            team,
            run=storage_run,
            session_id=new_session.session_id,
            user_id=new_session.user_id,
            run_index=idx,
        )
    return new_session.session_id


async def afork_session_dispatch(
    team: "Team",
    *,
    source_session_id: Optional[str] = None,
    user_id: Optional[str] = None,
) -> str:
    """Async variant of :func:`fork_session_dispatch`."""
    from agno.team._init import _has_async_db
    from agno.team._storage import _aread_or_create_session, _read_or_create_session

    source_session_id = source_session_id or team.session_id
    if source_session_id is None:
        raise ValueError("source_session_id is required to fork a session.")

    team.initialize_team()

    if _has_async_db(team):
        source_session = await _aread_or_create_session(team, session_id=source_session_id, user_id=user_id)
    else:
        source_session = _read_or_create_session(team, session_id=source_session_id, user_id=user_id)

    if not source_session.runs:
        raise ValueError("Source session has no runs to fork.")

    new_session = _build_forked_team_session(source_session, new_user_id=user_id)
    if _has_async_db(team):
        await team.asave_session(session=new_session)
    else:
        team.save_session(session=new_session)

    # Under v3 storage, [a]save_session no longer writes runs — persist each
    # forked run individually so the new session isn't observably empty.
    from agno.team._session import asave_run, save_run

    for idx, run in enumerate(new_session.runs or []):
        # Offload gives the fork its own objects; a cached source session still holds them inline.
        storage_run = await abuild_offloaded_storage_copy(team, cast(TeamRunOutput, run), new_session.session_id) or run
        if _has_async_db(team):
            await asave_run(
                team,
                run=storage_run,
                session_id=new_session.session_id,
                user_id=new_session.user_id,
                run_index=idx,
            )
        else:
            save_run(
                team,
                run=storage_run,
                session_id=new_session.session_id,
                user_id=new_session.user_id,
                run_index=idx,
            )
    return new_session.session_id


def continue_run_dispatch(
    team: "Team",
    run_response: Optional[TeamRunOutput] = None,
    *,
    run_id: Optional[str] = None,
    requirements: Optional[List[Any]] = None,
    # --- Continue sugar (mirrors agent dispatch) ---
    input: Optional[str] = None,
    continue_from: Union[int, Literal["end", "last_user"]] = "end",
    fork: bool = False,
    regenerate: bool = False,
    replace_original: Optional[bool] = None,
    additional_instructions: Optional[str] = None,
    # --- Stream/control ---
    stream: Optional[bool] = None,
    stream_events: Optional[bool] = False,
    user_id: Optional[str] = None,
    session_id: Optional[str] = None,
    run_context: Optional[RunContext] = None,
    knowledge_filters: Optional[Union[Dict[str, Any], List[FilterExpr]]] = None,
    dependencies: Optional[Dict[str, Any]] = None,
    metadata: Optional[Dict[str, Any]] = None,
    debug_mode: Optional[bool] = None,
    yield_run_output: bool = False,
    **kwargs: Any,
) -> Union[TeamRunOutput, Iterator[Union[TeamRunOutputEvent, RunOutputEvent, TeamRunOutput]]]:
    """Continue a paused team run (sync).

    Handles both team-level tool pauses and member-agent tool pauses, plus
    the snapshot dispatch (regenerate / fork / time-travel) — see the
    corresponding agent docstring in ``agno/agent/_run.py`` for the full
    variant table. Auto-fork-on-COMPLETED is enforced: continuing a
    COMPLETED team run produces a new ``run_id`` with the member rows
    cloned (per ADR — forked teams own their member rows).
    """
    from agno.media.storage.base import AsyncMediaStorage
    from agno.team._init import _has_async_db, _initialize_session
    from agno.team._response import get_response_format
    from agno.team._run_options import resolve_run_options
    from agno.team._storage import _load_session_state, _read_or_create_session, _update_metadata
    from agno.team._tools import _determine_tools_for_model

    if run_response is None and run_id is None:
        raise ValueError("Either run_response or run_id must be provided.")

    if run_response is None and (run_id is not None and (session_id is None and team.session_id is None)):
        raise ValueError("Session ID is required to continue a run from a run_id.")

    if _has_async_db(team):
        raise Exception("continue_run() is not supported with an async DB. Please use acontinue_run() instead.")

    # Refused here rather than at the persist below, which runs after the model call.
    if isinstance(team.media_storage, AsyncMediaStorage):
        raise ValueError("Cannot use sync continue_run() with an AsyncMediaStorage. Use acontinue_run() instead.")

    background_tasks = kwargs.pop("background_tasks", None)
    if background_tasks is not None:
        from fastapi import BackgroundTasks

        background_tasks: BackgroundTasks = background_tasks  # type: ignore

    session_id = run_response.session_id if run_response else session_id
    run_id_resolved: str = run_response.run_id if run_response else run_id  # type: ignore

    session_id, user_id = _initialize_session(team, session_id=session_id, user_id=user_id)

    # Initialize the Team
    team.initialize_team(debug_mode=debug_mode)

    # Read existing session from storage
    from copy import deepcopy

    team_session = _read_or_create_session(team, session_id=session_id, user_id=user_id)
    # Snapshot BEFORE _update_metadata merges team.metadata into the session dict,
    # so the session layer keeps the session's own values (team < session < call-site).
    session_metadata = deepcopy(team_session.metadata)
    _update_metadata(team, session=team_session)

    # Fall back to the owner the run paused with, so the resume retrieves under the same scope
    if user_id is None:
        user_id = _resolve_continue_owner_team(run_response, run_id=run_id_resolved, session=team_session)

    # Load session state
    session_state = _load_session_state(team, session=team_session, session_state={})

    # A resumed run keeps its runtime-owned metadata: the dispatch lineage,
    # hop count and version stamp live on the paused run row, and rebuilding
    # them from caller input would present a nested run as top-level --
    # resetting the dispatch guard one human approval at a time. The stored
    # values win, and caller-supplied reserved keys are dropped the way every
    # other seam drops them.
    from agno.db.schemas.scheduler import restore_reserved_run_metadata

    _stored_run = (
        run_response
        if run_response is not None
        else next((r for r in team_session.runs or [] if r.run_id == run_id_resolved), None)
    )
    metadata = restore_reserved_run_metadata(metadata, getattr(_stored_run, "metadata", None))

    # Resolve run options
    opts = resolve_run_options(
        team,
        stream=stream,
        stream_events=stream_events,
        yield_run_output=yield_run_output,
        dependencies=dependencies,
        knowledge_filters=knowledge_filters,
        metadata=metadata,
        session_metadata=session_metadata,
    )

    # Initialize run context
    run_context = run_context or RunContext(
        run_id=run_id_resolved,
        session_id=session_id,
        user_id=user_id,
        session_state=session_state,
        dependencies=opts.dependencies,
        knowledge_filters=opts.knowledge_filters,
        metadata=opts.metadata,
    )
    if user_id is not None and run_context.user_id is None:
        run_context.user_id = user_id
    if dependencies is not None:
        run_context.dependencies = opts.dependencies
    elif run_context.dependencies is None:
        run_context.dependencies = opts.dependencies
    if knowledge_filters is not None:
        run_context.knowledge_filters = opts.knowledge_filters
    elif run_context.knowledge_filters is None:
        run_context.knowledge_filters = opts.knowledge_filters
    if metadata is not None:
        run_context.metadata = opts.metadata
    elif run_context.metadata is None:
        run_context.metadata = opts.metadata

    # Resolve dependencies
    if run_context.dependencies is not None:
        _resolve_run_dependencies(team, run_context=run_context)

    # Resolve run_response from run_id if needed
    if run_response is None and run_id is not None:
        runs = team_session.runs or []
        run_response = next((r for r in runs if r.run_id == run_id), None)  # type: ignore
        if run_response is None:
            raise RunNotFoundError(f"No runs found for run ID {run_id}")

    run_response = cast(TeamRunOutput, run_response)

    if run_response.status == RunStatus.cancelled:
        raise RunNotContinuableError(f"Cannot continue run {run_response.run_id}: run is cancelled")

    # --- Snapshot dispatch (regenerate / fork / time-travel) ----------------
    continue_index: Optional[int] = _resolve_continue_from_team(
        run_response,
        continue_from=continue_from,
        regenerate=regenerate,
    )
    # Normalize sugar params into canonical (fork, continue_index, input)
    # form. Mirrors the agent dispatch — see agno/agent/_run.py.
    fork, continue_index, input = _normalize_regenerate_params_team(
        run_response,
        regenerate=regenerate,
        replace_original=replace_original,
        additional_instructions=additional_instructions,
        fork=fork,
        continue_index=continue_index,
        input=input,
    )
    original_run_id_for_lineage = run_response.run_id if regenerate else None

    # Auto-fork on COMPLETED — preserves the "1 run = 1 model loop" invariant.
    # A COMPLETED loop ran end-to-end; any further model call is a NEW loop
    # and must get a new run_id. Mid-flight states (RUNNING / PAUSED) resume
    # in place because their loop never finished. ERROR / CANCELLED are NOT
    # auto-forked (retry semantics) — same call as agent.
    if not fork and run_response.status == RunStatus.completed:
        fork = True

    # Apply modifiers BEFORE the requirements machinery. If we forked, the
    # rest of the dispatch operates on the new run with cloned members.
    _did_snapshot_dispatch = fork or _will_truncate_team_run(run_response, continue_index)
    run_response = _apply_continue_modifiers_team(run_response, fork, continue_index)
    if regenerate and original_run_id_for_lineage:
        run_response.regenerated_from = original_run_id_for_lineage
        if replace_original is not False and run_response.forked_from_run_id:
            # Mark the original run REGENERATED so history builders skip it.
            _mark_team_run_regenerated(team, team_session, original_run_id_for_lineage)

    # Append the new user-message (from input / additional_instructions) so
    # the model loop picks it up.
    if input:
        _maybe_append_input_message_team(run_response, input, team)

    # A freshly-forked run has no PAUSED requirements contract — skip the
    # HITL machinery and route straight to the model loop. Member-level
    # tool resolution for HITL is a property of the SOURCE run; the fork
    # is a new attempt and its tools/messages are seeded from the
    # snapshot.
    if _did_snapshot_dispatch:
        # Reset run state for a fresh model loop on the forked run.
        run_response.status = RunStatus.running
        run_response.content = None

        response_format = get_response_format(team, run_context=run_context) if team.parser_model is None else None
        team.model = cast(Model, team.model)

        team_run_context_local: Dict[str, Any] = {}
        _tools_fork = _determine_tools_for_model(
            team,
            model=team.model,
            run_response=run_response,
            run_context=run_context,
            team_run_context=team_run_context_local,
            session=team_session,
            user_id=user_id,
            async_mode=False,
            stream=opts.stream or False,
            stream_events=opts.stream_events or False,
        )

        input_messages = run_response.messages or []
        run_messages = _get_continue_run_messages(
            team,
            input=input_messages,
            session=team_session,
            add_history_to_context=team.add_history_to_context,
            run_context=run_context,
        )

        log_debug(f"Team Continue Run (forked): {run_response.run_id}", center=True)

        if opts.stream:
            return _continue_run_stream(
                team,
                run_response=run_response,
                run_messages=run_messages,
                run_context=run_context,
                tools=_tools_fork,
                session=team_session,
                user_id=user_id,
                response_format=response_format,
                stream_events=opts.stream_events,
                yield_run_output=opts.yield_run_output,
                debug_mode=debug_mode,
                background_tasks=background_tasks,
                **kwargs,
            )
        else:
            return _continue_run(
                team,
                run_response=run_response,
                run_messages=run_messages,
                run_context=run_context,
                tools=_tools_fork,
                session=team_session,
                user_id=user_id,
                response_format=response_format,
                debug_mode=debug_mode,
                background_tasks=background_tasks,
                **kwargs,
            )
    # --- End snapshot dispatch ----------------------------------------------

    # Normalize and apply requirements
    if requirements:
        old_requirements, old_tools, decisions = _apply_requirements_payload(run_response, requirements)

        # Also apply any resolved approval
        if run_response.tools:
            from agno.run.approval import check_and_apply_approval_resolution

            try:
                check_and_apply_approval_resolution(team.db, run_id_resolved, run_response)
            except RuntimeError as e:
                run_response.requirements = old_requirements
                run_response.tools = old_tools
                _restore_requirement_decisions(decisions)
                # The payload was supplied; the approval gate is what refused.
                # Surface its reason instead of asking for a payload again.
                raise ValueError(str(e))
    elif run_response.tools:
        from agno.run.approval import check_and_apply_approval_resolution

        try:
            check_and_apply_approval_resolution(team.db, run_id_resolved, run_response)
        except RuntimeError:
            # No resolved approval found — fall through to bare-resume.
            pass
        # A RUNNING/ERROR run with already-executed tools (e.g. crash recovery
        # after a delegation, or an ERROR retry) is NOT a HITL pause: resume via
        # the team-leader model regardless of whether an approval was applied.
        # Without this, such a run falls through to terminal cleanup with no
        # final turn (content=None). Unresolved requirements are re-paused
        # downstream, so this does not bypass HITL.
        #
        # Guard: a PAUSED run with requirements is a real HITL pause (the user
        # called continue_run(response) after mutating req.confirm() in place).
        # Don't bypass — fall through to member-routing / team-level resolution
        # below. The team-leader bypass is only for non-HITL crash recovery.
        if run_response.status != RunStatus.paused or not run_response.requirements:
            _did_snapshot_dispatch = True  # route to team-leader model call
    else:
        # No requirements AND no tools — this is a bare resume of a mid-flight
        # run (RUNNING / ERROR / CANCELLED that crashed before any tool batch).
        # Don't raise; let the team-leader model loop run with whatever
        # messages survived in run_response.
        _did_snapshot_dispatch = True

    # Determine what kind of pause we're continuing from
    run_response.requirements = _reclaim_own_requirements(team, run_response.requirements, run_response.run_id)
    has_member = _has_member_requirements(run_response.requirements or [])
    has_team_level = _has_team_level_requirements(run_response.requirements or [])

    # Guard: a member requirement the client left unresolved has to re-pause,
    # not dispatch. Routing hands it to the member's continue_run, which reads
    # the pause as settled and runs the gated tool with whatever the schema
    # holds -- for a requested field left untouched, with None. The team-level
    # lane already re-pauses on its own unresolved requirements; a requirement
    # addressed to a member is no less unresolved for being addressed to one.
    unresolved_member = [
        r
        for r in (run_response.requirements or [])
        if getattr(r, "member_agent_id", None) is not None and not r.is_resolved()
    ]
    if unresolved_member:
        from agno.team import _hooks

        if opts.stream:

            def _member_paused_stream_with_final() -> Iterator[
                Union[TeamRunOutputEvent, RunOutputEvent, TeamRunOutput]
            ]:
                yield from _hooks.handle_team_run_paused_stream(
                    team, run_response=run_response, session=team_session, run_context=run_context
                )
                if opts.yield_run_output:
                    yield run_response

            return _member_paused_stream_with_final()
        else:
            return _hooks.handle_team_run_paused(
                team, run_response=run_response, session=team_session, run_context=run_context
            )

    # Route member requirements to member agents
    member_results: List[str] = []
    if has_member:
        member_reqs = [r for r in (run_response.requirements or []) if getattr(r, "member_agent_id", None) is not None]
        team_level_reqs = [r for r in (run_response.requirements or []) if getattr(r, "member_agent_id", None) is None]
        # Set only member reqs for routing; _route_requirements_to_members
        # may append newly propagated reqs via _propagate_member_pause (chained HITL).
        original_member_req_ids = {id(r) for r in member_reqs}
        run_response.requirements = member_reqs

        if opts.stream:
            # Streaming: use the generator variant that yields member events.
            # We collect member_results via a mutable list and chain with the
            # team continuation stream below.
            member_event_stream = _route_requirements_to_members_stream(
                team,
                run_response=run_response,
                session=team_session,
                member_results=member_results,
                run_context=run_context,
                stream_events=opts.stream_events or False,
            )
        else:
            member_event_stream = None
            try:
                member_results = _route_requirements_to_members(
                    team,
                    run_response=run_response,
                    session=team_session,
                    run_context=run_context,
                )
            except Exception:
                # Routing failed mid-flight; put the team-level requirements
                # back so the caller's run object stays complete for a retry.
                run_response.requirements = team_level_reqs + (run_response.requirements or [])
                raise

        # For non-streaming, member routing is done eagerly above.
        # For streaming, we must consume member events lazily inside a returned generator.
        # But first we need to check for chained pauses AFTER member routing completes.
        # So for streaming, we defer everything to a wrapper generator.
        if opts.stream and member_event_stream is not None:
            return _continue_run_dispatch_stream_with_member_events(
                team=team,
                run_response=run_response,
                member_event_stream=member_event_stream,
                member_results=member_results,
                original_member_req_ids=original_member_req_ids,
                team_level_reqs=team_level_reqs,
                has_team_level=has_team_level,
                team_session=team_session,
                run_context=run_context,
                opts=opts,
                user_id=user_id,
                debug_mode=debug_mode,
                background_tasks=background_tasks,
                **kwargs,
            )

        # Non-streaming: merge and check for chained pauses
        newly_propagated = [r for r in (run_response.requirements or []) if id(r) not in original_member_req_ids]
        run_response.requirements = team_level_reqs + newly_propagated

        # Check if any members are still paused
        if run_response.requirements and any(not req.is_resolved() for req in run_response.requirements):
            from agno.team import _hooks

            return _hooks.handle_team_run_paused(
                team, run_response=run_response, session=team_session, run_context=run_context
            )

    # Handle team-level tool resolution
    if has_team_level or _did_snapshot_dispatch:
        # Includes _did_snapshot_dispatch: bare-resume of a crashed run (no
        # requirements, no tools) still needs the team-leader model call to
        # produce a response. Without this, those runs would fall through
        # with no model invocation.
        # Guard: if team-level requirements are unresolved, re-pause instead of auto-rejecting
        unresolved_team = [
            r
            for r in (run_response.requirements or [])
            if getattr(r, "member_agent_id", None) is None and not r.is_resolved()
        ]
        if unresolved_team:
            from agno.team import _hooks

            if opts.stream:

                def _paused_stream_with_final() -> Iterator[Union[TeamRunOutputEvent, RunOutputEvent, TeamRunOutput]]:
                    yield from _hooks.handle_team_run_paused_stream(
                        team, run_response=run_response, session=team_session, run_context=run_context
                    )
                    if opts.yield_run_output:
                        yield run_response

                return _paused_stream_with_final()
            else:
                return _hooks.handle_team_run_paused(
                    team, run_response=run_response, session=team_session, run_context=run_context
                )

        response_format = get_response_format(team, run_context=run_context) if team.parser_model is None else None
        team.model = cast(Model, team.model)

        # Prepare tools
        team_run_context: Dict[str, Any] = {}
        _tools = _determine_tools_for_model(
            team,
            model=team.model,
            run_response=run_response,
            run_context=run_context,
            team_run_context=team_run_context,
            session=team_session,
            user_id=user_id,
            async_mode=False,
            stream=opts.stream or False,
            stream_events=opts.stream_events or False,
        )

        # Get continue run messages from existing conversation
        input_messages = run_response.messages or []
        run_messages = _get_continue_run_messages(
            team,
            input=input_messages,
            session=team_session,
            add_history_to_context=team.add_history_to_context,
            run_context=run_context,
        )

        # Handle tool call updates (execute confirmed tools, etc.)
        _handle_team_tool_call_updates(team, run_response=run_response, run_messages=run_messages, tools=_tools)

        # Reset run state for continuation
        run_response.status = RunStatus.running
        # Reset content before re-running the model; _update_run_response appends
        # to existing content, so stale content from the paused run must be cleared.
        run_response.content = None

        log_debug(f"Team Continue Run Start: {run_response.run_id}", center=True)

        if opts.stream:
            return _continue_run_stream(
                team,
                run_response=run_response,
                run_messages=run_messages,
                run_context=run_context,
                tools=_tools,
                session=team_session,
                user_id=user_id,
                response_format=response_format,
                stream_events=opts.stream_events,
                yield_run_output=opts.yield_run_output,
                debug_mode=debug_mode,
                background_tasks=background_tasks,
                **kwargs,
            )
        else:
            return _continue_run(
                team,
                run_response=run_response,
                run_messages=run_messages,
                run_context=run_context,
                tools=_tools,
                session=team_session,
                user_id=user_id,
                response_format=response_format,
                debug_mode=debug_mode,
                background_tasks=background_tasks,
                **kwargs,
            )

    # Member-only case: continue the same run with member results
    if member_results and not has_team_level:
        response_format = get_response_format(team, run_context=run_context) if team.parser_model is None else None
        team.model = cast(Model, team.model)

        # Prepare tools for the continuation
        team_run_context: Dict[str, Any] = {}  # type: ignore[no-redef]
        _tools = _determine_tools_for_model(
            team,
            model=team.model,
            run_response=run_response,
            run_context=run_context,
            team_run_context=team_run_context,
            session=team_session,
            user_id=user_id,
            async_mode=False,
            stream=opts.stream or False,
            stream_events=opts.stream_events or False,
        )

        # Get existing messages
        input_messages = run_response.messages or []
        run_messages = _get_continue_run_messages(
            team,
            input=input_messages,
            session=team_session,
            add_history_to_context=team.add_history_to_context,
            run_context=run_context,
        )

        # Prepare for member HITL continuation
        _prepare_member_hitl_continuation(run_response, run_messages, member_results)

        log_debug(f"Team Continue Run (Member HITL): {run_response.run_id}", center=True)

        if opts.stream:
            return _continue_run_stream(
                team,
                run_response=run_response,
                run_messages=run_messages,
                run_context=run_context,
                tools=_tools,
                session=team_session,
                user_id=user_id,
                response_format=response_format,
                stream_events=opts.stream_events,
                yield_run_output=opts.yield_run_output,
                debug_mode=debug_mode,
                background_tasks=background_tasks,
                **kwargs,
            )
        else:
            return _continue_run(
                team,
                run_response=run_response,
                run_messages=run_messages,
                run_context=run_context,
                tools=_tools,
                session=team_session,
                user_id=user_id,
                response_format=response_format,
                debug_mode=debug_mode,
                background_tasks=background_tasks,
                **kwargs,
            )

    # Fallback: nothing to do
    run_response.status = RunStatus.completed
    _cleanup_and_store(team, run_response=run_response, session=team_session)
    return run_response


def _continue_run_dispatch_stream_with_member_events(
    team: "Team",
    run_response: TeamRunOutput,
    member_event_stream: Iterator[Union[TeamRunOutputEvent, RunOutputEvent]],
    member_results: List[str],
    original_member_req_ids: set,
    team_level_reqs: list,
    has_team_level: bool,
    team_session: TeamSession,
    run_context: RunContext,
    opts: "ResolvedRunOptions",
    user_id: Optional[str] = None,
    debug_mode: Optional[bool] = None,
    background_tasks: Optional[Any] = None,
    **kwargs: Any,
) -> Iterator[Union[TeamRunOutputEvent, RunOutputEvent, TeamRunOutput]]:
    """Sync streaming wrapper that yields member events then continues the team run.

    This generator first yields all member streaming events from the member routing,
    then proceeds with the normal team continuation (model call, etc.).
    """
    from agno.team._response import get_response_format
    from agno.team._tools import _determine_tools_for_model

    # Phase 1: Yield member streaming events
    try:
        try:
            yield from member_event_stream
        except BaseException:
            # Phase 1 runs with the team-level requirements stripped off the
            # run object; every non-normal exit puts them back before anything
            # persists or returns it.
            run_response.requirements = team_level_reqs + (run_response.requirements or [])
            raise
    except RunCancelledException as e:
        run_response = _handle_team_run_cancellation(run_response, e, session=team_session)
        cancelled_event, completed_event = _build_team_cancel_terminal_events(
            team, run_response, error=e, run_context=run_context
        )
        try:
            _cleanup_and_store(team, run_response=run_response, session=team_session, run_context=run_context)
        except Exception as store_err:
            log_warning(f"Failed to persist cancelled run: {store_err}")
        yield cancelled_event
        yield completed_event
        if opts.yield_run_output:
            yield run_response
        return
    except KeyboardInterrupt:
        run_response = _handle_team_run_cancellation(run_response, KeyboardInterrupt(), session=team_session)
        cancelled_event, completed_event = _build_team_cancel_terminal_events(
            team, run_response, error=KeyboardInterrupt(), run_context=run_context
        )
        try:
            _cleanup_and_store(team, run_response=run_response, session=team_session, run_context=run_context)
        except Exception as store_err:
            log_warning(f"Failed to persist cancelled run: {store_err}")
        yield cancelled_event
        yield completed_event
        if opts.yield_run_output:
            yield run_response
        return

    # Phase 2: After member routing completes, check for chained pauses
    newly_propagated = [r for r in (run_response.requirements or []) if id(r) not in original_member_req_ids]
    run_response.requirements = team_level_reqs + newly_propagated

    if run_response.requirements and any(not req.is_resolved() for req in run_response.requirements):
        from agno.team import _hooks

        yield from _hooks.handle_team_run_paused_stream(
            team, run_response=run_response, session=team_session, run_context=run_context
        )
        if opts.yield_run_output:
            yield run_response
        return

    # Phase 3: Continue the team run with member results
    if has_team_level:
        unresolved_team = [
            r
            for r in (run_response.requirements or [])
            if getattr(r, "member_agent_id", None) is None and not r.is_resolved()
        ]
        if unresolved_team:
            from agno.team import _hooks

            yield from _hooks.handle_team_run_paused_stream(
                team, run_response=run_response, session=team_session, run_context=run_context
            )
            if opts.yield_run_output:
                yield run_response
            return

        response_format = get_response_format(team, run_context=run_context) if team.parser_model is None else None
        team.model = cast(Model, team.model)

        team_run_context: Dict[str, Any] = {}
        _tools = _determine_tools_for_model(
            team,
            model=team.model,
            run_response=run_response,
            run_context=run_context,
            team_run_context=team_run_context,
            session=team_session,
            user_id=user_id,
            async_mode=False,
            stream=True,
            stream_events=opts.stream_events or False,
        )

        input_messages = run_response.messages or []
        run_messages = _get_continue_run_messages(
            team,
            input=input_messages,
            session=team_session,
            add_history_to_context=team.add_history_to_context,
            run_context=run_context,
        )

        _handle_team_tool_call_updates(team, run_response=run_response, run_messages=run_messages, tools=_tools)

        run_response.status = RunStatus.running
        run_response.content = None

        log_debug(f"Team Continue Run Start: {run_response.run_id}", center=True)

        yield from _continue_run_stream(
            team,
            run_response=run_response,
            run_messages=run_messages,
            run_context=run_context,
            tools=_tools,
            session=team_session,
            user_id=user_id,
            response_format=response_format,
            stream_events=opts.stream_events,
            yield_run_output=opts.yield_run_output,
            debug_mode=debug_mode,
            background_tasks=background_tasks,
            **kwargs,
        )
        return

    if member_results:
        response_format = get_response_format(team, run_context=run_context) if team.parser_model is None else None
        team.model = cast(Model, team.model)

        team_run_context_2: Dict[str, Any] = {}
        _tools = _determine_tools_for_model(
            team,
            model=team.model,
            run_response=run_response,
            run_context=run_context,
            team_run_context=team_run_context_2,
            session=team_session,
            user_id=user_id,
            async_mode=False,
            stream=True,
            stream_events=opts.stream_events or False,
        )

        input_messages = run_response.messages or []
        run_messages = _get_continue_run_messages(
            team,
            input=input_messages,
            session=team_session,
            add_history_to_context=team.add_history_to_context,
            run_context=run_context,
        )

        _prepare_member_hitl_continuation(run_response, run_messages, member_results)

        log_debug(f"Team Continue Run (Member HITL): {run_response.run_id}", center=True)

        yield from _continue_run_stream(
            team,
            run_response=run_response,
            run_messages=run_messages,
            run_context=run_context,
            tools=_tools,
            session=team_session,
            user_id=user_id,
            response_format=response_format,
            stream_events=opts.stream_events,
            yield_run_output=opts.yield_run_output,
            debug_mode=debug_mode,
            background_tasks=background_tasks,
            **kwargs,
        )
        return

    # Fallback: nothing more to do
    run_response.status = RunStatus.completed
    _cleanup_and_store(team, run_response=run_response, session=team_session)
    if opts.yield_run_output:
        yield run_response


def _continue_run(
    team: "Team",
    run_response: TeamRunOutput,
    run_messages: RunMessages,
    run_context: RunContext,
    tools: List[Union[Function, dict]],
    session: TeamSession,
    user_id: Optional[str] = None,
    response_format: Optional[Union[Dict, Type[BaseModel]]] = None,
    debug_mode: Optional[bool] = None,
    background_tasks: Optional[Any] = None,
    **kwargs: Any,
) -> TeamRunOutput:
    """Continue a paused team run (sync, non-streaming).

    Steps:
    1. Generate response from model (includes running tool calls)
    2. Update TeamRunOutput with model response
    3. Check for new pauses
    4. Convert response to structured format
    5. Create session summary
    6. Cleanup and store
    """
    from agno.team._hooks import _execute_post_hooks
    from agno.team._init import _disconnect_connectable_tools
    from agno.team._response import (
        _convert_response_to_structured_format,
        _update_run_response,
        parse_response_with_output_model,
        parse_response_with_parser_model,
    )
    from agno.team._telemetry import log_team_telemetry
    from agno.utils.events import create_team_run_continued_event

    register_run(run_response.run_id)  # type: ignore

    # Emit RunContinued event (matching streaming variant behaviour)
    handle_event(
        create_team_run_continued_event(run_response),
        run_response,
        events_to_skip=team.events_to_skip,
        store_events=team.store_events,
    )

    team.model = cast(Model, team.model)

    try:
        num_attempts = team.retries + 1
        for attempt in range(num_attempts):
            try:
                raise_if_cancelled(run_response.run_id)  # type: ignore

                # Generate model response
                model_response: ModelResponse = call_model_with_fallback(
                    team.model,
                    team.fallback_config,
                    messages=run_messages.messages,
                    response_format=response_format,
                    tools=tools,
                    tool_choice=team.tool_choice,
                    tool_call_limit=team.tool_call_limit,
                    run_response=run_response,
                    send_media_to_model=team.send_media_to_model,
                    compression_manager=team.compression_manager if team.compress_tool_results else None,
                    **result_store_kwargs(team),
                    after_tool_results=build_team_after_tool_results_callback(
                        team, run_response, session, run_messages, run_context
                    ),
                )

                raise_if_cancelled(run_response.run_id)  # type: ignore

                # Parse with output/parser models if needed
                parse_response_with_output_model(team, model_response, run_messages, run_response=run_response)
                parse_response_with_parser_model(
                    team, model_response, run_messages, run_context=run_context, run_response=run_response
                )

                # Update run response
                _update_run_response(
                    team,
                    model_response=model_response,
                    run_response=run_response,
                    run_messages=run_messages,
                    run_context=run_context,
                )

                # Check for new pauses (team-level tools or member propagation)
                if run_response.requirements and any(not req.is_resolved() for req in run_response.requirements):
                    from agno.team import _hooks

                    return _hooks.handle_team_run_paused(
                        team, run_response=run_response, session=session, run_context=run_context
                    )

                # Convert to structured format
                _convert_response_to_structured_format(team, run_response=run_response, run_context=run_context)

                # Always add media to run_response for caller availability
                store_media_util(run_response, model_response)

                # Execute post-hooks
                if team.post_hooks is not None:
                    iterator = _execute_post_hooks(
                        team,
                        hooks=team.post_hooks,  # type: ignore
                        run_output=run_response,
                        run_context=run_context,
                        session=session,
                        user_id=user_id,
                        debug_mode=debug_mode,
                        background_tasks=background_tasks,
                        **kwargs,
                    )
                    deque(iterator, maxlen=0)

                # Create session summary
                if team.session_summary_manager is not None:
                    session.upsert_run(run_response=run_response)
                    try:
                        team.session_summary_manager.create_session_summary(
                            session=session, run_metrics=run_response.metrics
                        )
                    except Exception as e:
                        log_warning(f"Error in session summary creation: {str(e)}")

                # Complete
                run_response.status = RunStatus.completed
                _cleanup_and_store(team, run_response=run_response, session=session)

                log_team_telemetry(team, session_id=session.session_id, run_id=run_response.run_id)
                log_debug(f"Team Continue Run End: {run_response.run_id}", center=True, symbol="*")

                return run_response

            except RunCancelledException as e:
                run_response = _handle_team_run_cancellation(run_response, e, run_messages, session=session)
                try:
                    _cleanup_and_store(team, run_response=run_response, session=session, run_context=run_context)
                except Exception as store_err:
                    log_warning(f"Failed to persist cancelled run: {store_err}")
                return run_response

            except (InputCheckError, OutputCheckError) as e:
                run_response.status = RunStatus.error
                flush_in_flight_messages_on_error_team(run_response, locals().get("run_messages"))
                run_error = create_team_run_error_event(
                    run_response,
                    error=str(e),
                    error_id=e.error_id,
                    error_type=e.type,
                    additional_data=e.additional_data,
                )
                run_response.events = add_team_error_event(error=run_error, events=run_response.events)
                if run_response.content is None:
                    run_response.content = str(e)
                log_error(f"Validation failed: {str(e)} | Check: {e.check_trigger}")
                _cleanup_and_store(team, run_response=run_response, session=session)
                return run_response

            except KeyboardInterrupt:
                run_response = _handle_team_run_cancellation(
                    run_response, KeyboardInterrupt(), run_messages, session=session
                )
                try:
                    _cleanup_and_store(team, run_response=run_response, session=session, run_context=run_context)
                except Exception as store_err:
                    log_warning(f"Failed to persist cancelled run: {store_err}")
                return run_response

            except Exception as e:
                if attempt < num_attempts - 1:
                    import time as _time

                    if team.exponential_backoff:
                        delay = team.delay_between_retries * (2**attempt)
                    else:
                        delay = team.delay_between_retries
                    log_warning(f"Attempt {attempt + 1}/{num_attempts} failed. Retrying in {delay}s...: {str(e)}")
                    _time.sleep(delay)
                    continue

                run_response.status = RunStatus.error
                flush_in_flight_messages_on_error_team(run_response, locals().get("run_messages"))
                run_error = create_team_run_error_event(run_response, error=str(e), error_type=error_type_of(e))
                run_response.events = add_team_error_event(error=run_error, events=run_response.events)
                if run_response.content is None:
                    run_response.content = str(e)
                log_error(f"Error in Team continue_run: {str(e)}")
                _cleanup_and_store(team, run_response=run_response, session=session)
                return run_response
    finally:
        _disconnect_connectable_tools(team)
        cleanup_run(run_response.run_id)  # type: ignore
    return run_response


def _continue_run_stream(
    team: "Team",
    run_response: TeamRunOutput,
    run_messages: RunMessages,
    run_context: RunContext,
    tools: List[Union[Function, dict]],
    session: TeamSession,
    user_id: Optional[str] = None,
    response_format: Optional[Union[Dict, Type[BaseModel]]] = None,
    stream_events: bool = False,
    yield_run_output: bool = False,
    debug_mode: Optional[bool] = None,
    background_tasks: Optional[Any] = None,
    **kwargs: Any,
) -> Iterator[Union[TeamRunOutputEvent, RunOutputEvent, TeamRunOutput]]:
    """Continue a paused team run (sync, streaming)."""
    from agno.team._hooks import _execute_post_hooks
    from agno.team._init import _disconnect_connectable_tools
    from agno.team._response import (
        _handle_model_response_stream,
        generate_response_with_output_model_stream,
        parse_response_with_parser_model_stream,
    )
    from agno.team._telemetry import log_team_telemetry
    from agno.utils.events import create_team_run_continued_event

    register_run(run_response.run_id)  # type: ignore

    try:
        num_attempts = team.retries + 1
        for attempt in range(num_attempts):
            try:
                # Yield RunContinued event
                if stream_events:
                    yield handle_event(
                        create_team_run_continued_event(run_response),
                        run_response,
                        events_to_skip=team.events_to_skip,
                        store_events=team.store_events,
                    )

                raise_if_cancelled(run_response.run_id)  # type: ignore

                # Handle the updated tools (execute confirmed tools, etc.) with streaming
                yield from _handle_team_tool_call_updates_stream(
                    team,
                    run_response=run_response,
                    run_messages=run_messages,
                    tools=tools,
                    stream_events=stream_events,
                )

                # Stream model response
                if team.output_model is None:
                    for event in _handle_model_response_stream(
                        team,
                        session=session,
                        run_response=run_response,
                        run_messages=run_messages,
                        tools=tools,
                        response_format=response_format,
                        stream_events=stream_events,
                        session_state=run_context.session_state,
                        run_context=run_context,
                    ):
                        if not isinstance(event, _MEMBER_CANCEL_BYPASS_EVENT_TYPES):
                            raise_if_cancelled(run_response.run_id)  # type: ignore
                        yield event
                else:
                    from agno.run.team import IntermediateRunContentEvent, RunContentEvent

                    for event in _handle_model_response_stream(
                        team,
                        session=session,
                        run_response=run_response,
                        run_messages=run_messages,
                        tools=tools,
                        response_format=response_format,
                        stream_events=stream_events,
                        session_state=run_context.session_state,
                        run_context=run_context,
                    ):
                        if not isinstance(event, _MEMBER_CANCEL_BYPASS_EVENT_TYPES):
                            raise_if_cancelled(run_response.run_id)  # type: ignore
                        if isinstance(event, RunContentEvent):
                            if stream_events:
                                yield IntermediateRunContentEvent(
                                    content=event.content,
                                    content_type=event.content_type,
                                )
                        else:
                            yield event

                    for event in generate_response_with_output_model_stream(
                        team,
                        session=session,
                        run_response=run_response,
                        run_messages=run_messages,
                        stream_events=stream_events,
                    ):
                        raise_if_cancelled(run_response.run_id)  # type: ignore
                        yield event

                raise_if_cancelled(run_response.run_id)  # type: ignore

                # Check for new pauses
                if run_response.requirements and any(not req.is_resolved() for req in run_response.requirements):
                    from agno.team import _hooks

                    yield from _hooks.handle_team_run_paused_stream(
                        team, run_response=run_response, session=session, run_context=run_context
                    )
                    if yield_run_output:
                        yield run_response
                    return

                # Parse response with parser model
                yield from parse_response_with_parser_model_stream(
                    team,
                    session=session,
                    run_response=run_response,
                    stream_events=stream_events,
                    run_context=run_context,
                )

                # Content completed event
                if stream_events:
                    yield handle_event(
                        create_team_run_content_completed_event(from_run_response=run_response),
                        run_response,
                        events_to_skip=team.events_to_skip,
                        store_events=team.store_events,
                    )

                # Post-hooks
                if team.post_hooks is not None:
                    iterator = _execute_post_hooks(
                        team,
                        hooks=team.post_hooks,  # type: ignore
                        run_output=run_response,
                        run_context=run_context,
                        session=session,
                        user_id=user_id,
                        debug_mode=debug_mode,
                        background_tasks=background_tasks,
                        **kwargs,
                    )
                    for hook_event in iterator:
                        yield hook_event

                # Session summary
                if team.session_summary_manager is not None:
                    session.upsert_run(run_response=run_response)
                    if stream_events:
                        yield handle_event(
                            create_team_session_summary_started_event(from_run_response=run_response),
                            run_response,
                            events_to_skip=team.events_to_skip,
                            store_events=team.store_events,
                        )
                    try:
                        team.session_summary_manager.create_session_summary(
                            session=session, run_metrics=run_response.metrics
                        )
                    except Exception as e:
                        log_warning(f"Error in session summary creation: {str(e)}")
                    if stream_events:
                        yield handle_event(
                            create_team_session_summary_completed_event(
                                from_run_response=run_response, session_summary=session.summary
                            ),
                            run_response,
                            events_to_skip=team.events_to_skip,
                            store_events=team.store_events,
                        )

                # Completed event
                completed_event = handle_event(
                    create_team_run_completed_event(run_response),
                    run_response,
                    events_to_skip=team.events_to_skip,
                    store_events=team.store_events,
                )

                run_response.status = RunStatus.completed
                _cleanup_and_store(team, run_response=run_response, session=session)

                if stream_events:
                    yield completed_event

                if yield_run_output:
                    yield run_response

                log_team_telemetry(team, session_id=session.session_id, run_id=run_response.run_id)
                log_debug(f"Team Continue Run End: {run_response.run_id}", center=True, symbol="*")
                break

            except RunCancelledException as e:
                run_response = _handle_team_run_cancellation(run_response, e, run_messages, session=session)
                cancelled_event, completed_event = _build_team_cancel_terminal_events(
                    team,
                    run_response,
                    error=e,
                    run_context=run_context,
                )
                try:
                    _cleanup_and_store(team, run_response=run_response, session=session, run_context=run_context)
                except Exception as store_err:
                    log_warning(f"Failed to persist cancelled run: {store_err}")
                yield cancelled_event  # type: ignore
                yield completed_event  # type: ignore
                if yield_run_output:
                    yield run_response
                break

            except (InputCheckError, OutputCheckError) as e:
                run_response.status = RunStatus.error
                flush_in_flight_messages_on_error_team(run_response, locals().get("run_messages"))
                run_error = create_team_run_error_event(
                    run_response,
                    error=str(e),
                    error_id=e.error_id,
                    error_type=e.type,
                    additional_data=e.additional_data,
                )
                run_response.events = add_team_error_event(error=run_error, events=run_response.events)
                if run_response.content is None:
                    run_response.content = str(e)
                log_error(f"Validation failed: {str(e)} | Check: {e.check_trigger}")
                _cleanup_and_store(team, run_response=run_response, session=session)
                yield run_error
                if yield_run_output:
                    yield run_response
                break

            except KeyboardInterrupt:
                run_response = _handle_team_run_cancellation(
                    run_response, KeyboardInterrupt(), run_messages, session=session
                )
                cancelled_event, completed_event = _build_team_cancel_terminal_events(
                    team,
                    run_response,
                    error=KeyboardInterrupt(),
                    run_context=run_context,
                )
                try:
                    _cleanup_and_store(team, run_response=run_response, session=session, run_context=run_context)
                except Exception as store_err:
                    log_warning(f"Failed to persist cancelled run: {store_err}")
                yield cancelled_event  # type: ignore
                yield completed_event  # type: ignore
                if yield_run_output:
                    yield run_response
                break

            except Exception as e:
                if attempt < num_attempts - 1:
                    import time as _time

                    if team.exponential_backoff:
                        delay = team.delay_between_retries * (2**attempt)
                    else:
                        delay = team.delay_between_retries
                    log_warning(f"Attempt {attempt + 1}/{num_attempts} failed. Retrying in {delay}s...: {str(e)}")
                    _time.sleep(delay)
                    continue

                run_response.status = RunStatus.error
                flush_in_flight_messages_on_error_team(run_response, locals().get("run_messages"))
                run_error = create_team_run_error_event(run_response, error=str(e), error_type=error_type_of(e))
                run_response.events = add_team_error_event(error=run_error, events=run_response.events)
                if run_response.content is None:
                    run_response.content = str(e)
                log_error(f"Error in Team continue_run stream: {str(e)}")
                _cleanup_and_store(team, run_response=run_response, session=session)
                yield run_error
                if yield_run_output:
                    yield run_response
    finally:
        _disconnect_connectable_tools(team)
        cleanup_run(run_response.run_id)  # type: ignore


def _as_run_status(value: Union[RunStatus, str, None]) -> Union[RunStatus, str, None]:
    """Coerce a stored status to RunStatus. A run loaded from the DB carries its
    status as a plain string; an unrecognized value is returned unchanged."""
    if value is None or isinstance(value, RunStatus):
        return value
    try:
        return RunStatus(value)
    except ValueError:
        return value


async def _acontinue_run_background_stream(
    team: Team,
    run_context: RunContext,
    session_id: str,
    run_response: Optional[TeamRunOutput] = None,
    run_id: Optional[str] = None,
    requirements: Optional[List[Any]] = None,
    input: Optional[str] = None,
    continue_from: Union[int, Literal["end", "last_user"]] = "end",
    fork: bool = False,
    regenerate: bool = False,
    replace_original: Optional[bool] = None,
    additional_instructions: Optional[str] = None,
    user_id: Optional[str] = None,
    response_format: Optional[Union[Dict, Type[BaseModel]]] = None,
    stream_events: bool = False,
    yield_run_output: Optional[bool] = None,
    debug_mode: Optional[bool] = None,
    background_tasks: Optional[Any] = None,
    **kwargs: Any,
) -> AsyncIterator[str]:
    """Background streaming continue-run that survives client disconnections.

    Mirrors _arun_background_stream but drives _acontinue_run_stream instead of
    _arun_stream. Used for HITL scenarios where a paused run resumes and the
    client needs reconnection support.

    Without this, team.acontinue_run(background=True, stream=True) would route
    to _acontinue_run_stream and yield raw TeamRunOutputEvent objects directly
    into FastAPI's StreamingResponse, which calls .encode() per chunk and
    raises::

        AttributeError: 'RunContinuedEvent' object has no attribute 'encode'

    1. Persists RUNNING status in DB
    2. Spawns a detached asyncio.Task that runs _acontinue_run_stream
    3. Buffers events and publishes to live tails (via the event stream)
    4. Yields SSE-formatted strings via an asyncio.Queue
    """
    from agno.team._session import asave_run, asave_session
    from agno.team._storage import _aread_or_create_session, _aread_session, _update_metadata

    _run_id = run_id or (run_response.run_id if run_response else None)
    if not _run_id:
        raise ValueError("run_id is required for background streaming continue-run")

    from agno.os.event_streams import get_event_stream

    # 1. Persist PENDING status so the run is visible in the DB immediately.
    # Execution (and the RUNNING transition) waits for a concurrency slot.
    team_session = await _aread_or_create_session(team, session_id=session_id, user_id=user_id)

    # Fall back to the owner the run paused with, so the resume retrieves under
    # the same scope.
    if user_id is None:
        user_id = _resolve_continue_owner_team(run_response, run_id=_run_id, session=team_session)
        if user_id is not None:
            run_context.user_id = user_id

    # Same restore as the executors: the background wrapper persists and
    # schedules with this run_context, so it must carry the stored lineage.
    _restore_continue_context_metadata_team(
        run_context, run_response=run_response, run_id=_run_id, session=team_session
    )

    _update_metadata(team, session=team_session)

    def _get_session_run(session: TeamSession) -> Optional[TeamRunOutput]:
        # Prefer the concrete run list: mocked or third-party session objects
        # do not always implement get_run with the same fidelity.
        for candidate in getattr(session, "runs", None) or []:
            if getattr(candidate, "run_id", None) == _run_id:
                return cast(TeamRunOutput, candidate)
        return cast(Optional[TeamRunOutput], session.get_run(_run_id))

    stored_run = _get_session_run(team_session)
    status_before_takeover = _as_run_status(getattr(stored_run, "status", None))
    # The status the caller's object carries at entry; the write below replaces
    # it with RUNNING. When the session has no stored entry for this run, this
    # is the only record of the pre-continue state.
    prior_object_status = _as_run_status(getattr(run_response, "status", None)) if run_response is not None else None

    if run_response is not None:
        # Continuability is decided from the STORED run, never from the caller's
        # object: a stale paused object over a finished run would republish it
        # as a pending approval, and a gated tool could then be approved a
        # second time. fork and regenerate branch off a finished run and stay
        # allowed. The run_id-only shape resolves the stored run downstream and
        # has its own cancelled refusal.
        if (
            isinstance(status_before_takeover, RunStatus)
            and status_before_takeover in (RunStatus.completed, RunStatus.cancelled)
            and not (fork or regenerate)
        ):
            raise RunNotContinuableError(
                f"Cannot continue run {_run_id}: the stored run has status {status_before_takeover.value} "
                "and cannot be continued in place. Use acontinue_run(run_id=..., fork=True) to branch off a "
                "finished run. The stored run is unchanged."
            )

    # HITL continues may arrive with run_response=None (the router passes only
    # run_id). Keep a loaded object for status persistence, but leave the
    # caller shape passed to _acontinue_run_stream unchanged.
    persist_run = run_response if run_response is not None else stored_run

    # A fork/regenerate executes under a new run id. A run-id-only continue of
    # a completed run auto-forks downstream, while a cancelled run is refused.
    # None of those paths may stamp PENDING/RUNNING over the source run.
    take_over_in_place = not (fork or regenerate) and status_before_takeover not in (
        RunStatus.completed,
        RunStatus.cancelled,
    )
    if persist_run is not None and take_over_in_place:
        persist_run.status = RunStatus.pending
        storage_run = await abuild_offloaded_storage_copy(team, persist_run, session_id) or persist_run
        team_session.upsert_run(run_response=storage_run)
        # v3 substrate: persist the changed run through the O(1) per-run save.
        await asave_run(team, run=storage_run, session_id=session_id, user_id=user_id)
    await asave_session(team, session=team_session)

    # Pre-register only an in-place takeover. Forks and auto-forks are keyed by
    # a new run id downstream; fabricating PENDING under the source key would
    # corrupt the original run's reconnect state.
    if take_over_in_place:
        with contextlib.suppress(Exception):
            # Fail-open: a Redis blip must not strand an accepted run.
            await get_event_stream().register_run(_run_id, RunStatus.pending)

    if take_over_in_place:
        log_info(f"Background continue-run stream {_run_id} persisted with PENDING status")

    # 2. Create queue for forwarding SSE strings to the caller
    sse_queue: asyncio.Queue[Optional[str]] = asyncio.Queue()

    # 3. Spawn detached background task. Execution waits for a concurrency slot
    # (background_run_slot); the run stays PENDING while waiting in line and
    # can be cancelled without consuming a slot.
    async def _background_producer() -> None:
        event_stream = get_event_stream()
        from agno.os.utils import amark_continue_stream_running, format_sse_event_with_index

        slot_cm = background_run_slot(run_id=_run_id)
        slot_held = False
        producer_terminal: Optional[RunStatus] = None
        producer_error: Optional[BaseException] = None
        # The run object the continue actually produced. The caller-supplied
        # run_response is not updated on the run_id-only path, so the terminal
        # buffer status below reads this instead.
        final_output: Optional[TeamRunOutput] = None

        async def _dispatch_sse(event: Any) -> None:
            """Buffer and fan out an event, then hand it to the original client."""
            event_index: Optional[int] = None
            try:
                event_index = await event_stream.add_event(_run_id, event)
            except Exception:
                log_warning(f"Failed to buffer event for continue-run {_run_id}")

            sse_data = format_sse_event_with_index(event, event_index=event_index, run_id=_run_id)

            try:
                await sse_queue.put(sse_data)
            except Exception:
                log_warning(f"Failed to push SSE data to queue for continue-run {_run_id}")

        try:
            await slot_cm.__aenter__()
            slot_held = True

            # Transition to RUNNING now that a slot is held (atomic helper).
            # persist_run covers the run-ID-only continue (loaded above).
            if persist_run is not None and take_over_in_place:
                persist_run.status = RunStatus.running
                await apersist_run_transition(team, "team", session_id, persist_run, user_id=user_id)
            if take_over_in_place:
                # Reopen a prior PAUSED stream atomically, seed any expired
                # event index from durable history, and then mark it RUNNING.
                await amark_continue_stream_running(_run_id, component=team, session_id=session_id, user_id=user_id)

            async for event in _acontinue_run_stream(
                team,
                run_response=run_response,
                run_context=run_context,
                requirements=requirements,
                input=input,
                continue_from=continue_from,
                fork=fork,
                regenerate=regenerate,
                replace_original=replace_original,
                additional_instructions=additional_instructions,
                run_id=_run_id,
                user_id=user_id,
                session_id=session_id,
                response_format=response_format,
                stream_events=stream_events,
                # Always request the final run object; it is captured below and
                # never forwarded to the client.
                yield_run_output=True,
                debug_mode=debug_mode,
                background_tasks=background_tasks,
                **kwargs,
            ):
                if isinstance(event, TeamRunOutput):
                    final_output = event
                    continue

                await _dispatch_sse(event)

        except asyncio.CancelledError:
            # Task-level shutdown (event loop stopping), not run-cancellation:
            # best-effort persist so pollers are not left with a run stuck at
            # PENDING/RUNNING forever (parity with the primary stream
            # producer). producer_terminal makes the finally's sentinel say
            # CANCELLED - without it, complete_run's non-terminal coercion
            # turned an interrupted continue into a FALSE COMPLETED.
            producer_terminal = RunStatus.cancelled if take_over_in_place else None
            from agno.run.concurrency import is_worker_managed

            if is_worker_managed(_run_id or ""):
                raise  # worker-claimed: the QueueWorker owns this terminal
            if not take_over_in_place:
                # A fork/regenerate owns a new run id downstream. Task
                # shutdown must not cancel the source run or its stream key.
                raise
            with contextlib.suppress(Exception):
                interrupted_run = run_response
                if interrupted_run is None:
                    lookup_session = await _aread_or_create_session(team, session_id=session_id, user_id=user_id)
                    interrupted_run = _get_session_run(lookup_session)
                if interrupted_run is not None:
                    if interrupted_run.status == RunStatus.paused:
                        # The leg already RE-PAUSED and parked a valid,
                        # continuable HITL state - shutdown while draining
                        # trailing events must not destroy it. Re-park the
                        # stream sentinel instead of stamping CANCELLED.
                        producer_terminal = RunStatus.paused
                    else:
                        interrupted_run.status = RunStatus.cancelled
                        await apersist_run_transition(team, "team", session_id, interrupted_run, user_id=user_id)
            raise
        except RunCancelledException:
            # Cancelled while waiting for a slot — execution never started, so
            # persist CANCELLED and deregister the run here. HITL continues may
            # arrive with run_response=None (router passes only run_id): load
            # the run from the session so the cancel is never silently skipped.
            log_info(f"Background continue-run stream {_run_id} cancelled while waiting for a slot")
            producer_terminal = RunStatus.cancelled if take_over_in_place else None
            try:
                cancelled_run: Optional[TeamRunOutput] = None
                if take_over_in_place:
                    cancelled_run = run_response
                if take_over_in_place and cancelled_run is None:
                    # HITL continues arrive with run_response=None: load the
                    # run so the terminal persist is never silently skipped
                    lookup_session = await _aread_or_create_session(team, session_id=session_id, user_id=user_id)
                    cancelled_run = _get_session_run(lookup_session)
                if cancelled_run is not None:
                    cancelled_run.status = RunStatus.cancelled
                    await apersist_run_transition(team, "team", session_id, cancelled_run, user_id=user_id)
            except Exception:
                log_error(
                    f"Failed to persist cancelled state for background continue-run stream {_run_id}",
                    exc_info=True,
                )
            await acleanup_run(_run_id)
        except Exception as e:
            producer_error = e
            refused = isinstance(e, RunNotContinuableError)
            if refused:
                # A refusal is an answer, not a crash: restore the status this
                # producer replaced, but only while it still owns the run's
                # PENDING/RUNNING marker. A concurrent terminal writer wins.
                log_info(f"Background continue-run stream {_run_id} refused the continue: {e}")
                try:
                    restore_status = (
                        status_before_takeover if status_before_takeover is not None else prior_object_status
                    )
                    if take_over_in_place and persist_run is not None and restore_status is not None:
                        # Read before mutating: with cache_session, persist_run
                        # can be the same object as the cached session entry.
                        fresh_session = cast(
                            Optional[TeamSession],
                            await _aread_session(team, session_id=session_id, user_id=user_id),
                        )
                        if fresh_session is None:
                            # A read failure must not strand a resumable run.
                            if _as_run_status(getattr(persist_run, "status", None)) in (
                                RunStatus.pending,
                                RunStatus.running,
                            ):
                                persist_run.status = cast(RunStatus, restore_status)
                                # Offloaded like the takeover write above: persist_run still holds its media inline.
                                storage_run = (
                                    await abuild_offloaded_storage_copy(team, persist_run, session_id) or persist_run
                                )
                                team_session.upsert_run(run_response=storage_run)
                                await asave_run(team, run=storage_run, session_id=session_id, user_id=user_id)
                                await asave_session(team, session=team_session)
                        else:
                            fresh_run = _get_session_run(fresh_session)
                            if fresh_run is not None and _as_run_status(fresh_run.status) in (
                                RunStatus.pending,
                                RunStatus.running,
                            ):
                                fresh_run.status = cast(RunStatus, restore_status)
                                await apersist_run_transition(team, "team", session_id, fresh_run, user_id=user_id)
                                persist_run.status = cast(RunStatus, restore_status)
                                if team.cache_session:
                                    team._set_cached_session(fresh_session)
                except Exception:
                    log_error(
                        f"Failed to restore the pre-continue state for background continue-run stream {_run_id}",
                        exc_info=True,
                    )
            else:
                log_error(f"Background continue-run stream {_run_id} failed", exc_info=True)
                producer_terminal = RunStatus.error
                # Persist ERROR only while this in-place producer still owns
                # PENDING/RUNNING. Forks and concurrent terminal writers keep
                # the source run unchanged.
                try:
                    if take_over_in_place and persist_run is not None:
                        fresh_session = cast(
                            Optional[TeamSession],
                            await _aread_session(team, session_id=session_id, user_id=user_id),
                        )
                        if fresh_session is None:
                            if _as_run_status(getattr(persist_run, "status", None)) in (
                                RunStatus.pending,
                                RunStatus.running,
                            ):
                                persist_run.status = RunStatus.error
                                await apersist_run_transition(team, "team", session_id, persist_run, user_id=user_id)
                        else:
                            fresh_run = _get_session_run(fresh_session)
                            if fresh_run is not None and _as_run_status(fresh_run.status) in (
                                RunStatus.pending,
                                RunStatus.running,
                            ):
                                fresh_run.status = RunStatus.error
                                await apersist_run_transition(team, "team", session_id, fresh_run, user_id=user_id)
                                persist_run.status = RunStatus.error
                                if team.cache_session:
                                    team._set_cached_session(fresh_session)
                except Exception:
                    log_error(
                        f"Failed to persist error state for background continue-run stream {_run_id}",
                        exc_info=True,
                    )

            # Tell the client. Without this the producer dies inside its detached
            # task and the caller is left holding a 200 with an empty body — for a
            # refusal, the single most misleading outcome available, since the
            # request it refused looks like the one that worked.
            try:
                error_source = run_response
                if error_source is None:
                    error_source = TeamRunOutput(
                        run_id=_run_id, session_id=session_id, team_id=team.id, team_name=team.name
                    )
                await _dispatch_sse(
                    create_team_run_error_event(error_source, error=str(e), error_type=error_type_of(e))
                )
            except Exception:
                log_warning(f"Failed to emit error event for continue-run {_run_id}")

        finally:
            if slot_held:
                await slot_cm.__aexit__(None, None, None)

            # Signal primary queue FIRST — unblocks the original client
            try:
                await sse_queue.put(None)
            except Exception:
                log_warning(f"Failed to signal primary queue for continue-run {_run_id} completion")

            # Mark the run terminal in the distributed event stream and wake
            # all tails. The source key must keep the source run's status when
            # the continue produced a fork with a different run id.
            try:
                if isinstance(producer_error, RunNotContinuableError):
                    refused_status = _as_run_status(
                        status_before_takeover if status_before_takeover is not None else prior_object_status
                    )
                    if isinstance(refused_status, RunStatus) and refused_status not in (
                        RunStatus.running,
                        RunStatus.pending,
                    ):
                        final_status = refused_status
                    else:
                        final_status = RunStatus.paused
                elif producer_terminal is not None:
                    final_status = producer_terminal
                elif producer_error is not None:
                    final_status = RunStatus.error
                elif not take_over_in_place:
                    # Explicit fork/regenerate and run-id auto-fork execute
                    # under a different id. Use stored authority, never the
                    # stale caller object or the fork output.
                    source_status = _as_run_status(
                        status_before_takeover if status_before_takeover is not None else prior_object_status
                    )
                    if isinstance(source_status, RunStatus) and source_status in (
                        RunStatus.completed,
                        RunStatus.paused,
                        RunStatus.cancelled,
                        RunStatus.error,
                    ):
                        final_status = source_status
                    else:
                        final_status = RunStatus.completed
                else:
                    # final_output covers run-id-only calls. Fall back to the
                    # in-memory persisted object, then the exact durable row,
                    # so a chained HITL pause is never advertised COMPLETED.
                    produced_status: Union[RunStatus, str, None] = None
                    if final_output is not None and getattr(final_output, "run_id", None) == _run_id:
                        produced_status = final_output.status
                    if produced_status is None and run_response is not None:
                        produced_status = run_response.status
                    if produced_status is None and persist_run is not None:
                        produced_status = persist_run.status
                    produced_status = _as_run_status(produced_status)
                    if not isinstance(produced_status, RunStatus) or produced_status in (
                        RunStatus.pending,
                        RunStatus.running,
                    ):
                        with contextlib.suppress(Exception):
                            lookup_session = await _aread_or_create_session(
                                team, session_id=session_id, user_id=user_id
                            )
                            produced_status = _as_run_status(getattr(_get_session_run(lookup_session), "status", None))
                    if isinstance(produced_status, RunStatus) and produced_status in (
                        RunStatus.completed,
                        RunStatus.paused,
                        RunStatus.cancelled,
                        RunStatus.error,
                    ):
                        final_status = produced_status
                    else:
                        final_status = RunStatus.completed

                await asyncio.shield(event_stream.complete_run(_run_id, final_status))
            except (Exception, asyncio.CancelledError):
                log_warning(f"Failed to mark continue-run {_run_id} as completed in event stream")

    task = asyncio.create_task(_background_producer())
    _background_tasks.add(task)
    task.add_done_callback(_background_tasks.discard)

    # 4. Yield SSE strings from the queue. Emit SSE keepalive comments on idle
    # so proxies do not kill the connection while the run waits for a slot (or
    # during long silent stretches of execution).
    while True:
        try:
            sse_data = await asyncio.wait_for(sse_queue.get(), timeout=SSE_KEEPALIVE_INTERVAL_SECONDS)
        except asyncio.TimeoutError:
            yield ": keepalive\n\n"
            continue
        if sse_data is None:
            break
        yield sse_data


def acontinue_run_dispatch(  # type: ignore
    team: "Team",
    run_response: Optional[TeamRunOutput] = None,
    *,
    run_id: Optional[str] = None,
    requirements: Optional[List[Any]] = None,
    # --- Continue sugar (mirrors agent dispatch) ---
    input: Optional[str] = None,
    continue_from: Union[int, Literal["end", "last_user"]] = "end",
    fork: bool = False,
    regenerate: bool = False,
    replace_original: Optional[bool] = None,
    additional_instructions: Optional[str] = None,
    # --- Stream/control ---
    stream: Optional[bool] = None,
    stream_events: Optional[bool] = False,
    user_id: Optional[str] = None,
    session_id: Optional[str] = None,
    run_context: Optional[RunContext] = None,
    knowledge_filters: Optional[Union[Dict[str, Any], List[FilterExpr]]] = None,
    dependencies: Optional[Dict[str, Any]] = None,
    metadata: Optional[Dict[str, Any]] = None,
    debug_mode: Optional[bool] = None,
    yield_run_output: bool = False,
    background: bool = False,
    **kwargs: Any,
) -> Union[TeamRunOutput, AsyncIterator[Union[TeamRunOutputEvent, RunOutputEvent, TeamRunOutput]]]:
    """Continue a paused team run (async entry point).

    Routes between _acontinue_run, _acontinue_run_stream, and
    _acontinue_run_background_stream based on the stream and background options.
    Snapshot dispatch parameters (``regenerate``, ``fork``, ``continue_from``,
    ``replace_original``, ``additional_instructions``, ``input``) flow
    through to the inner functions which apply them after loading the run.
    """
    from agno.team._init import _initialize_session
    from agno.team._response import get_response_format
    from agno.team._run_options import resolve_run_options

    if run_response is None and run_id is None:
        raise ValueError("Either run_response or run_id must be provided.")

    if run_response is None and (run_id is not None and (session_id is None and team.session_id is None)):
        raise ValueError("Session ID is required to continue a run from a run_id.")

    background_tasks = kwargs.pop("background_tasks", None)
    if background_tasks is not None:
        from fastapi import BackgroundTasks

        background_tasks: BackgroundTasks = background_tasks  # type: ignore

    session_id_resolved = run_response.session_id if run_response else session_id
    run_id_resolved: str = run_response.run_id if run_response else run_id  # type: ignore

    session_id_resolved, user_id = _initialize_session(team, session_id=session_id_resolved, user_id=user_id)

    # Fall back to the owner the run paused with, so the resume retrieves under the same scope.
    # This dispatch reads no session, so a run_id-only resume has nothing to fall back to.
    if user_id is None:
        user_id = _resolve_continue_owner_team(run_response, run_id=run_id_resolved, session=None)

    # Initialize the Team
    team.initialize_team(debug_mode=debug_mode)

    # Pre-read the session so session-stored metadata is visible to
    # resolve_run_options via session_metadata. Only possible with a sync DB:
    # with an async DB the session is read inside _acontinue_run AFTER options are
    # resolved, so session metadata does not reach this run's resolved options.
    from agno.team._init import _has_async_db

    session_metadata: Optional[Dict[str, Any]] = None
    if team.db is not None and not _has_async_db(team):
        from copy import deepcopy

        from agno.team._storage import _read_or_create_session, _update_metadata

        _pre_session = _read_or_create_session(team, session_id=session_id_resolved, user_id=user_id)
        # Snapshot BEFORE _update_metadata merges team.metadata into the session dict,
        # so the session layer keeps the session's own values (team < session < call-site).
        session_metadata = deepcopy(_pre_session.metadata)
        _update_metadata(team, session=_pre_session)

    # Resolve run options
    opts = resolve_run_options(
        team,
        stream=stream,
        stream_events=stream_events,
        yield_run_output=yield_run_output,
        dependencies=dependencies,
        knowledge_filters=knowledge_filters,
        metadata=metadata,
        session_metadata=session_metadata,
    )

    # Initialize run context
    run_context = run_context or RunContext(
        run_id=run_id_resolved,
        session_id=session_id_resolved,
        user_id=user_id,
        session_state={},
        dependencies=opts.dependencies,
        knowledge_filters=opts.knowledge_filters,
        metadata=opts.metadata,
    )
    if user_id is not None and run_context.user_id is None:
        run_context.user_id = user_id
    if dependencies is not None:
        run_context.dependencies = opts.dependencies
    elif run_context.dependencies is None:
        run_context.dependencies = opts.dependencies
    if knowledge_filters is not None:
        run_context.knowledge_filters = opts.knowledge_filters
    elif run_context.knowledge_filters is None:
        run_context.knowledge_filters = opts.knowledge_filters
    if metadata is not None:
        run_context.metadata = opts.metadata
    elif run_context.metadata is None:
        run_context.metadata = opts.metadata

    response_format = get_response_format(team, run_context=run_context) if team.parser_model is None else None

    if background:
        if not team.db:
            raise ValueError(
                "Background execution requires a database to be configured on the team for run persistence."
            )
        if opts.stream:
            # background=True, stream=True: run in background task, yield SSE strings via queue
            return _acontinue_run_background_stream(  # type: ignore[return-value]
                team,
                run_response=run_response,
                run_context=run_context,
                requirements=requirements,
                input=input,
                continue_from=continue_from,
                fork=fork,
                regenerate=regenerate,
                replace_original=replace_original,
                additional_instructions=additional_instructions,
                run_id=run_id_resolved,
                user_id=user_id,
                session_id=session_id_resolved,
                response_format=response_format,
                stream_events=opts.stream_events,
                yield_run_output=opts.yield_run_output,
                debug_mode=debug_mode,
                background_tasks=background_tasks,
                **kwargs,
            )
        # background=True, stream=False is not supported for continue_run yet —
        # fall through to the regular non-streaming path to preserve prior behavior.

    if opts.stream:
        return _acontinue_run_stream(
            team,
            run_response=run_response,
            run_context=run_context,
            requirements=requirements,
            input=input,
            continue_from=continue_from,
            fork=fork,
            regenerate=regenerate,
            replace_original=replace_original,
            additional_instructions=additional_instructions,
            run_id=run_id_resolved,
            user_id=user_id,
            session_id=session_id_resolved,
            response_format=response_format,
            stream_events=opts.stream_events,
            yield_run_output=opts.yield_run_output,
            debug_mode=debug_mode,
            background_tasks=background_tasks,
            **kwargs,
        )
    else:
        return _acontinue_run(  # type: ignore
            team,
            run_response=run_response,
            run_context=run_context,
            requirements=requirements,
            input=input,
            continue_from=continue_from,
            fork=fork,
            regenerate=regenerate,
            replace_original=replace_original,
            additional_instructions=additional_instructions,
            run_id=run_id_resolved,
            user_id=user_id,
            session_id=session_id_resolved,
            response_format=response_format,
            debug_mode=debug_mode,
            background_tasks=background_tasks,
            **kwargs,
        )


async def _acontinue_run(
    team: "Team",
    session_id: str,
    run_context: RunContext,
    run_response: Optional[TeamRunOutput] = None,
    requirements: Optional[List[Any]] = None,
    # --- Snapshot dispatch sugar (mirrors sync continue_run_dispatch) ---
    input: Optional[str] = None,
    continue_from: Union[int, Literal["end", "last_user"]] = "end",
    fork: bool = False,
    regenerate: bool = False,
    replace_original: Optional[bool] = None,
    additional_instructions: Optional[str] = None,
    run_id: Optional[str] = None,
    user_id: Optional[str] = None,
    response_format: Optional[Union[Dict, Type[BaseModel]]] = None,
    debug_mode: Optional[bool] = None,
    background_tasks: Optional[Any] = None,
    **kwargs: Any,
) -> TeamRunOutput:
    """Continue a paused team run (async, non-streaming)."""
    from agno.team._hooks import _aexecute_post_hooks
    from agno.team._init import _disconnect_connectable_tools, _disconnect_mcp_tools
    from agno.team._telemetry import alog_team_telemetry
    from agno.team._tools import _aget_learning_tools, _check_and_refresh_mcp_tools, _determine_tools_for_model

    log_debug(f"Team Continue Run: {run_response.run_id if run_response else run_id}", center=True)

    team_session: Optional[TeamSession] = None
    # The payload binds to the stored requirements exactly once. A retry after a
    # transient failure re-enters the loop with the run already carrying the
    # bound requirements, and the member-level ones consumed by the dispatch —
    # re-binding the same payload against what is left refuses a run the retry
    # was meant to rescue.
    requirements_applied = False
    # Member results survive retries for the same reason: routing consumed the
    # member requirements, so a retry after a transient leader failure re-enters
    # with nothing to route. Without the banked results every dispatch branch is
    # skipped and the run would complete without the leader ever being called.
    routed_member_results: List[str] = []

    try:
        num_attempts = team.retries + 1
        for attempt in range(num_attempts):
            try:
                # Bind run_messages early — cancellation can fire before run_messages
                # is built, and the cancellation handler reads it.
                run_messages: Optional[RunMessages] = None
                # Setup session
                team_session = await _asetup_session(
                    team=team,
                    run_context=run_context,
                    session_id=session_id,
                    user_id=user_id,
                    run_id=run_id,
                )

                # Fall back to the owner the run paused with, so the resume retrieves under
                # the same scope.
                if user_id is None:
                    user_id = _resolve_continue_owner_team(run_response, run_id=run_id, session=team_session)
                    if user_id is not None:
                        run_context.user_id = user_id

                # A resumed run keeps its runtime-owned metadata (dispatch
                # lineage, hop count, version stamp); on the async path the
                # session may only be readable here, so the restore happens at
                # the load point. Idempotent with the dispatch-time restore.
                _restore_continue_context_metadata_team(
                    run_context, run_response=run_response, run_id=run_id, session=team_session
                )

                # Resolve run_response from run_id if needed
                if run_response is None and run_id is not None:
                    runs = team_session.runs or []
                    run_response = next((r for r in runs if r.run_id == run_id), None)  # type: ignore
                    if run_response is None:
                        raise RunNotFoundError(f"No runs found for run ID {run_id}")

                run_response = cast(TeamRunOutput, run_response)

                if run_response.status == RunStatus.cancelled:
                    raise RunNotContinuableError(f"Cannot continue run {run_response.run_id}: run is cancelled")

                # --- Snapshot dispatch (regenerate / fork / time-travel) ---
                continue_index: Optional[int] = _resolve_continue_from_team(
                    run_response,
                    continue_from=continue_from,
                    regenerate=regenerate,
                )
                # Mirrors the sync continue_run_dispatch.
                fork, continue_index, input = _normalize_regenerate_params_team(
                    run_response,
                    regenerate=regenerate,
                    replace_original=replace_original,
                    additional_instructions=additional_instructions,
                    fork=fork,
                    continue_index=continue_index,
                    input=input,
                )
                original_run_id_for_lineage = run_response.run_id if regenerate else None

                # Auto-fork on COMPLETED — preserves 1-run-1-loop invariant.
                if not fork and run_response.status == RunStatus.completed:
                    fork = True

                _did_snapshot_dispatch = fork or _will_truncate_team_run(run_response, continue_index)
                run_response = _apply_continue_modifiers_team(run_response, fork, continue_index)
                if regenerate and original_run_id_for_lineage:
                    run_response.regenerated_from = original_run_id_for_lineage
                    if replace_original is not False and run_response.forked_from_run_id:
                        await _amark_team_run_regenerated(team, team_session, original_run_id_for_lineage)

                # Append input/additional_instructions as a user message.
                if input:
                    _maybe_append_input_message_team(run_response, input, team)
                # --- End snapshot dispatch ---

                # A freshly-forked run has no PAUSED requirements contract;
                # skip the HITL machinery entirely. The fork is a fresh
                # attempt seeded from the snapshot — no tools/approvals to
                # resolve. Without this gate, the dispatch raises "requirements
                # parameter must be provided" for forked runs that have no
                # surviving requirements.
                if _did_snapshot_dispatch:
                    # Reset content so update_run_response doesn't append to
                    # stale content from the source run.
                    run_response.content = None
                # Normalize and apply requirements
                elif requirements:
                    if not requirements_applied:
                        old_requirements, old_tools, decisions = _apply_requirements_payload(run_response, requirements)
                        requirements_applied = True

                        # Also apply any resolved approval
                        if run_response.tools:
                            from agno.run.approval import acheck_and_apply_approval_resolution

                            try:
                                await acheck_and_apply_approval_resolution(
                                    team.db, run_response.run_id or run_id or "", run_response
                                )
                            except RuntimeError as e:
                                run_response.requirements = old_requirements
                                run_response.tools = old_tools
                                _restore_requirement_decisions(decisions)
                                # The payload was supplied; the approval gate is
                                # what refused. Surface its reason.
                                raise ValueError(str(e))
                elif run_response.tools:
                    from agno.run.approval import acheck_and_apply_approval_resolution

                    try:
                        await acheck_and_apply_approval_resolution(
                            team.db, run_response.run_id or run_id or "", run_response
                        )
                    except RuntimeError:
                        # No resolved approval found — fall through to bare-resume.
                        pass
                    # A RUNNING/ERROR run with already-executed tools (e.g. crash
                    # recovery after a delegation) is NOT a HITL pause: resume via
                    # the team-leader model regardless of whether an approval was
                    # applied. Without this it falls through to terminal cleanup
                    # with content=None. Unresolved requirements re-pause downstream.
                    #
                    # Guard: a PAUSED run with requirements is a real HITL pause
                    # (acontinue_run(response) after mutating req.confirm() in
                    # place). Don't bypass — fall through to member-routing /
                    # team-level resolution below.
                    if run_response.status != RunStatus.paused or not run_response.requirements:
                        _did_snapshot_dispatch = True  # route to team-leader model call
                else:
                    # Bare resume of a mid-flight run (RUNNING/ERROR/CANCELLED)
                    # — no requirements, no tools. Let the team-leader model
                    # loop run with whatever messages survived. Same as sync.
                    _did_snapshot_dispatch = True

                await aregister_run(run_response.run_id)  # type: ignore

                # Emit RunContinued event (matching streaming variant behaviour)
                from agno.utils.events import create_team_run_continued_event

                handle_event(
                    create_team_run_continued_event(run_response),
                    run_response,
                    events_to_skip=team.events_to_skip,
                    store_events=team.store_events,
                )

                run_response.requirements = _reclaim_own_requirements(
                    team, run_response.requirements, run_response.run_id
                )
                has_member = _has_member_requirements(run_response.requirements or [])
                has_team_level = _has_team_level_requirements(run_response.requirements or [])

                # Guard: a member requirement the client left unresolved has to re-pause,
                # not dispatch. Routing hands it to the member's continue_run, which reads
                # the pause as settled and runs the gated tool with whatever the schema
                # holds -- for a requested field left untouched, with None. The team-level
                # lane already re-pauses on its own unresolved requirements; a requirement
                # addressed to a member is no less unresolved for being addressed to one.
                unresolved_member = [
                    r
                    for r in (run_response.requirements or [])
                    if getattr(r, "member_agent_id", None) is not None and not r.is_resolved()
                ]
                if unresolved_member:
                    from agno.team import _hooks

                    return await _hooks.ahandle_team_run_paused(
                        team, run_response=run_response, session=team_session, run_context=run_context
                    )

                # Route member requirements
                member_results: List[str] = list(routed_member_results)
                if has_member:
                    member_reqs = [
                        r for r in (run_response.requirements or []) if getattr(r, "member_agent_id", None) is not None
                    ]
                    team_level_reqs = [
                        r for r in (run_response.requirements or []) if getattr(r, "member_agent_id", None) is None
                    ]
                    original_member_req_ids = {id(r) for r in member_reqs}
                    run_response.requirements = member_reqs
                    try:
                        member_results = await _aroute_requirements_to_members(
                            team,
                            run_response=run_response,
                            session=team_session,
                            run_context=run_context,
                        )
                    except Exception:
                        # Routing failed mid-flight; put the team-level requirements
                        # back so the caller's run object stays complete for a retry.
                        run_response.requirements = team_level_reqs + (run_response.requirements or [])
                        raise
                    # Merge: keep team-level reqs + any newly propagated member reqs (chained HITL)
                    newly_propagated = [
                        r for r in (run_response.requirements or []) if id(r) not in original_member_req_ids
                    ]
                    run_response.requirements = team_level_reqs + newly_propagated
                    # This attempt's routing succeeded; bank its results so a
                    # transient leader failure below retries the leader with
                    # them instead of completing a leaderless run.
                    member_results = routed_member_results + member_results
                    routed_member_results = member_results

                    # Check if still paused
                    if run_response.requirements and any(not req.is_resolved() for req in run_response.requirements):
                        from agno.team import _hooks

                        return await _hooks.ahandle_team_run_paused(
                            team, run_response=run_response, session=team_session, run_context=run_context
                        )

                # Handle team-level tool resolution
                if has_team_level or _did_snapshot_dispatch:
                    # Includes _did_snapshot_dispatch: a freshly-forked team run has no
                    # requirements but still needs the team-leader model call
                    # to produce a response. Without this, forked runs would
                    # fall through to terminal cleanup with content=None.
                    # Guard: if team-level requirements are unresolved, re-pause instead of auto-rejecting
                    unresolved_team = [
                        r
                        for r in (run_response.requirements or [])
                        if getattr(r, "member_agent_id", None) is None and not r.is_resolved()
                    ]
                    if unresolved_team:
                        from agno.team import _hooks

                        return await _hooks.ahandle_team_run_paused(
                            team, run_response=run_response, session=team_session, run_context=run_context
                        )

                    team.model = cast(Model, team.model)
                    await _check_and_refresh_mcp_tools(team)

                    team_run_context: Dict[str, Any] = {}
                    learning_tools = await _aget_learning_tools(team, user_id, team_session)
                    _tools = _determine_tools_for_model(
                        team,
                        model=team.model,
                        run_response=run_response,
                        run_context=run_context,
                        team_run_context=team_run_context,
                        session=team_session,
                        user_id=user_id,
                        async_mode=True,
                        learning_tools=learning_tools,
                    )

                    input_messages = run_response.messages or []
                    run_messages = await _aget_continue_run_messages(
                        team,
                        input=input_messages,
                        session=team_session,
                        add_history_to_context=team.add_history_to_context,
                        run_context=run_context,
                    )

                    await _ahandle_team_tool_call_updates(
                        team, run_response=run_response, run_messages=run_messages, tools=_tools
                    )

                    run_response.status = RunStatus.running
                    run_response.content = None

                    # Handle model response using shared helper
                    paused_result = await _ahandle_model_response_for_continue(
                        team,
                        run_response=run_response,
                        run_messages=run_messages,
                        run_context=run_context,
                        tools=_tools,
                        team_session=team_session,
                        response_format=response_format,
                    )
                    if paused_result is not None:
                        return paused_result

                elif member_results:
                    # Member-only: continue the same run with results
                    team.model = cast(Model, team.model)
                    await _check_and_refresh_mcp_tools(team)

                    team_run_context: Dict[str, Any] = {}  # type: ignore[no-redef]
                    learning_tools = await _aget_learning_tools(team, user_id, team_session)
                    _tools = _determine_tools_for_model(
                        team,
                        model=team.model,
                        run_response=run_response,
                        run_context=run_context,
                        team_run_context=team_run_context,
                        session=team_session,
                        user_id=user_id,
                        async_mode=True,
                        learning_tools=learning_tools,
                    )

                    input_messages = run_response.messages or []
                    run_messages = await _aget_continue_run_messages(
                        team,
                        input=input_messages,
                        session=team_session,
                        add_history_to_context=team.add_history_to_context,
                        run_context=run_context,
                    )

                    # Prepare for member HITL continuation
                    _prepare_member_hitl_continuation(run_response, run_messages, member_results)

                    log_debug(f"Team Continue Run (Member HITL): {run_response.run_id}", center=True)

                    # Handle model response using shared helper
                    paused_result = await _ahandle_model_response_for_continue(
                        team,
                        run_response=run_response,
                        run_messages=run_messages,
                        run_context=run_context,
                        tools=_tools,
                        team_session=team_session,
                        response_format=response_format,
                    )
                    if paused_result is not None:
                        return paused_result

                # Post-hooks
                if team.post_hooks is not None:
                    async for _ in _aexecute_post_hooks(
                        team,
                        hooks=team.post_hooks,  # type: ignore
                        run_output=run_response,
                        run_context=run_context,
                        session=team_session,
                        user_id=user_id,
                        debug_mode=debug_mode,
                        background_tasks=background_tasks,
                        **kwargs,
                    ):
                        pass

                # Session summary
                if team.session_summary_manager is not None:
                    team_session.upsert_run(run_response=run_response)
                    try:
                        await team.session_summary_manager.acreate_session_summary(
                            session=team_session, run_metrics=run_response.metrics
                        )
                    except Exception as e:
                        log_warning(f"Error in session summary creation: {str(e)}")

                run_response.status = RunStatus.completed
                await _acleanup_and_store(team, run_response=run_response, session=team_session)
                await alog_team_telemetry(team, session_id=team_session.session_id, run_id=run_response.run_id)
                log_debug(f"Team Continue Run End: {run_response.run_id}", center=True, symbol="*")

                return run_response

            except RunCancelledException as e:
                if run_response is None:
                    run_response = TeamRunOutput(run_id=run_id)
                run_response = cast(TeamRunOutput, run_response)
                run_response = _handle_team_run_cancellation(run_response, e, run_messages, session=team_session)
                if run_response.run_id:
                    await adrain_member_tasks(run_response.run_id)
                if team_session is not None:
                    await _acleanup_and_store(team, run_response=run_response, session=team_session)
                return run_response

            except (InputCheckError, OutputCheckError) as e:
                run_response = cast(TeamRunOutput, run_response)
                run_response.status = RunStatus.error
                flush_in_flight_messages_on_error_team(run_response, locals().get("run_messages"))
                if run_response.content is None:
                    run_response.content = str(e)
                log_error(f"Validation failed: {str(e)} | Check: {e.check_trigger}")

                if team_session is not None:
                    await _acleanup_and_store(team, run_response=run_response, session=team_session)
                return run_response

            except (KeyboardInterrupt, asyncio.CancelledError) as cancel_exc:
                if run_response is None:
                    run_response = TeamRunOutput(run_id=run_id)
                run_response = cast(TeamRunOutput, run_response)
                run_response = _handle_team_run_cancellation(
                    run_response, KeyboardInterrupt(), run_messages, session=team_session
                )
                if team_session is not None:
                    if isinstance(cancel_exc, asyncio.CancelledError):
                        # Client disconnect: persist on a detached task so the cancel scope can't abort the write
                        _persist_cancelled_team_run_in_background(
                            team, run_response=run_response, session=team_session, run_context=run_context
                        )
                    else:
                        # Ctrl-C under asyncio.run: persist inline; a detached task would not run before the loop exits
                        await _acleanup_and_store(
                            team, run_response=run_response, session=team_session, run_context=run_context
                        )
                # Re-raise on disconnect to propagate it; return the partial on Ctrl-C
                if isinstance(cancel_exc, asyncio.CancelledError):
                    raise
                return run_response

            except (ValueError, RunNotFoundError):
                # Validation errors (e.g. cancelled run, unknown run id, missing
                # args) propagate to the caller
                raise
            except Exception as e:
                run_response = cast(TeamRunOutput, run_response)
                if attempt < num_attempts - 1:
                    if team.exponential_backoff:
                        delay = team.delay_between_retries * (2**attempt)
                    else:
                        delay = team.delay_between_retries
                    log_warning(f"Attempt {attempt + 1}/{num_attempts} failed. Retrying in {delay}s...: {str(e)}")
                    await asyncio.sleep(delay)
                    continue

                run_response.status = RunStatus.error
                flush_in_flight_messages_on_error_team(run_response, locals().get("run_messages"))
                run_error = create_team_run_error_event(run_response, error=str(e), error_type=error_type_of(e))
                run_response.events = add_team_error_event(error=run_error, events=run_response.events)
                if run_response.content is None:
                    run_response.content = str(e)
                log_error(f"Error in Team acontinue_run: {str(e)}")
                if team_session is not None:
                    await _acleanup_and_store(team, run_response=run_response, session=team_session)
                return run_response

    finally:
        _disconnect_connectable_tools(team)
        await _disconnect_mcp_tools(team)  # type: ignore
        if run_response and run_response.run_id:
            await acleanup_run(run_response.run_id)
    return run_response  # type: ignore


async def _acontinue_run_stream(
    team: "Team",
    session_id: str,
    run_context: RunContext,
    run_response: Optional[TeamRunOutput] = None,
    requirements: Optional[List[Any]] = None,
    # --- Snapshot dispatch sugar (mirrors sync continue_run_dispatch) ---
    input: Optional[str] = None,
    continue_from: Union[int, Literal["end", "last_user"]] = "end",
    fork: bool = False,
    regenerate: bool = False,
    replace_original: Optional[bool] = None,
    additional_instructions: Optional[str] = None,
    run_id: Optional[str] = None,
    user_id: Optional[str] = None,
    response_format: Optional[Union[Dict, Type[BaseModel]]] = None,
    stream_events: bool = False,
    yield_run_output: bool = False,
    debug_mode: Optional[bool] = None,
    background_tasks: Optional[Any] = None,
    **kwargs: Any,
) -> AsyncIterator[Union[TeamRunOutputEvent, RunOutputEvent, TeamRunOutput]]:
    """Continue a paused team run (async, streaming)."""
    from agno.team._hooks import _aexecute_post_hooks
    from agno.team._init import _disconnect_connectable_tools, _disconnect_mcp_tools
    from agno.team._response import (
        _ahandle_model_response_stream,
        agenerate_response_with_output_model_stream,
        aparse_response_with_parser_model_stream,
    )
    from agno.team._telemetry import alog_team_telemetry
    from agno.team._tools import _aget_learning_tools, _check_and_refresh_mcp_tools, _determine_tools_for_model
    from agno.utils.events import create_team_run_continued_event

    log_debug(f"Team Continue Run Stream: {run_response.run_id if run_response else run_id}", center=True)

    team_session: Optional[TeamSession] = None
    # See _acontinue_run: the payload binds once, not once per retry, and
    # member results from a routing pass that succeeded are banked so a
    # transient leader failure retries the leader instead of completing a
    # run that skipped it.
    requirements_applied = False
    routed_member_results: List[str] = []

    try:
        num_attempts = team.retries + 1
        for attempt in range(num_attempts):
            try:
                # Bind run_messages early — cancellation can fire before run_messages
                # is built, and the cancellation handler reads it.
                run_messages: Optional[RunMessages] = None
                # Setup session
                team_session = await _asetup_session(
                    team=team,
                    run_context=run_context,
                    session_id=session_id,
                    user_id=user_id,
                    run_id=run_id,
                )

                # Fall back to the owner the run paused with, so the resume retrieves under
                # the same scope.
                if user_id is None:
                    user_id = _resolve_continue_owner_team(run_response, run_id=run_id, session=team_session)
                    if user_id is not None:
                        run_context.user_id = user_id

                # A resumed run keeps its runtime-owned metadata (dispatch
                # lineage, hop count, version stamp); on the async path the
                # session may only be readable here, so the restore happens at
                # the load point. Idempotent with the dispatch-time restore.
                _restore_continue_context_metadata_team(
                    run_context, run_response=run_response, run_id=run_id, session=team_session
                )

                # Resolve run_response from run_id if needed
                if run_response is None and run_id is not None:
                    runs = team_session.runs or []
                    run_response = next((r for r in runs if r.run_id == run_id), None)  # type: ignore
                    if run_response is None:
                        raise RunNotFoundError(f"No runs found for run ID {run_id}")

                run_response = cast(TeamRunOutput, run_response)

                if run_response.status == RunStatus.cancelled:
                    raise RunNotContinuableError(f"Cannot continue run {run_response.run_id}: run is cancelled")

                # --- Snapshot dispatch (regenerate / fork / time-travel) ---
                continue_index: Optional[int] = _resolve_continue_from_team(
                    run_response,
                    continue_from=continue_from,
                    regenerate=regenerate,
                )
                # Mirrors the sync continue_run_dispatch.
                fork, continue_index, input = _normalize_regenerate_params_team(
                    run_response,
                    regenerate=regenerate,
                    replace_original=replace_original,
                    additional_instructions=additional_instructions,
                    fork=fork,
                    continue_index=continue_index,
                    input=input,
                )
                original_run_id_for_lineage = run_response.run_id if regenerate else None

                # Auto-fork on COMPLETED — preserves 1-run-1-loop invariant.
                if not fork and run_response.status == RunStatus.completed:
                    fork = True

                _did_snapshot_dispatch = fork or _will_truncate_team_run(run_response, continue_index)
                run_response = _apply_continue_modifiers_team(run_response, fork, continue_index)
                if regenerate and original_run_id_for_lineage:
                    run_response.regenerated_from = original_run_id_for_lineage
                    if replace_original is not False and run_response.forked_from_run_id:
                        await _amark_team_run_regenerated(team, team_session, original_run_id_for_lineage)

                # Append input/additional_instructions as a user message.
                if input:
                    _maybe_append_input_message_team(run_response, input, team)
                # --- End snapshot dispatch ---

                # A freshly-forked run has no PAUSED requirements contract;
                # skip the HITL machinery entirely. The fork is a fresh
                # attempt seeded from the snapshot — no tools/approvals to
                # resolve. Without this gate, the dispatch raises "requirements
                # parameter must be provided" for forked runs that have no
                # surviving requirements.
                if _did_snapshot_dispatch:
                    # Reset content so update_run_response doesn't append to
                    # stale content from the source run.
                    run_response.content = None
                # Normalize and apply requirements
                elif requirements:
                    if not requirements_applied:
                        old_requirements, old_tools, decisions = _apply_requirements_payload(run_response, requirements)
                        requirements_applied = True

                        # Also apply any resolved approval
                        if run_response.tools:
                            from agno.run.approval import acheck_and_apply_approval_resolution

                            try:
                                await acheck_and_apply_approval_resolution(
                                    team.db, run_response.run_id or run_id or "", run_response
                                )
                            except RuntimeError as e:
                                run_response.requirements = old_requirements
                                run_response.tools = old_tools
                                _restore_requirement_decisions(decisions)
                                # The payload was supplied; the approval gate is
                                # what refused. Surface its reason.
                                raise ValueError(str(e))
                elif run_response.tools:
                    from agno.run.approval import acheck_and_apply_approval_resolution

                    try:
                        await acheck_and_apply_approval_resolution(
                            team.db, run_response.run_id or run_id or "", run_response
                        )
                    except RuntimeError:
                        # No resolved approval found — fall through to bare-resume.
                        pass
                    # A RUNNING/ERROR run with already-executed tools (e.g. crash
                    # recovery after a delegation) is NOT a HITL pause: resume via
                    # the team-leader model regardless of whether an approval was
                    # applied. Without this it falls through to terminal cleanup
                    # with content=None. Unresolved requirements re-pause downstream.
                    #
                    # Guard: a PAUSED run with requirements is a real HITL pause
                    # (acontinue_run(response) after mutating req.confirm() in
                    # place). Don't bypass — fall through to member-routing /
                    # team-level resolution below.
                    if run_response.status != RunStatus.paused or not run_response.requirements:
                        _did_snapshot_dispatch = True  # route to team-leader model call
                else:
                    # Bare resume of a mid-flight run (RUNNING/ERROR/CANCELLED)
                    # — no requirements, no tools. Let the team-leader model
                    # loop run with whatever messages survived. Same as sync.
                    _did_snapshot_dispatch = True

                await aregister_run(run_response.run_id)  # type: ignore

                run_response.requirements = _reclaim_own_requirements(
                    team, run_response.requirements, run_response.run_id
                )
                has_member = _has_member_requirements(run_response.requirements or [])
                has_team_level = _has_team_level_requirements(run_response.requirements or [])

                # Guard: a member requirement the client left unresolved has to re-pause,
                # not dispatch. Routing hands it to the member's continue_run, which reads
                # the pause as settled and runs the gated tool with whatever the schema
                # holds -- for a requested field left untouched, with None. The team-level
                # lane already re-pauses on its own unresolved requirements; a requirement
                # addressed to a member is no less unresolved for being addressed to one.
                unresolved_member = [
                    r
                    for r in (run_response.requirements or [])
                    if getattr(r, "member_agent_id", None) is not None and not r.is_resolved()
                ]
                if unresolved_member:
                    from agno.team import _hooks

                    async for item in _hooks.ahandle_team_run_paused_stream(
                        team, run_response=run_response, session=team_session, run_context=run_context
                    ):
                        yield item
                    if yield_run_output:
                        yield run_response
                    return

                # Route member requirements. The routing generator appends into
                # this list in place, so seeding it with the banked results
                # keeps earlier attempts' routing and this attempt's together.
                member_results: List[str] = list(routed_member_results)
                if has_member:
                    member_reqs = [
                        r for r in (run_response.requirements or []) if getattr(r, "member_agent_id", None) is not None
                    ]
                    team_level_reqs = [
                        r for r in (run_response.requirements or []) if getattr(r, "member_agent_id", None) is None
                    ]
                    original_member_req_ids = {id(r) for r in member_reqs}
                    run_response.requirements = member_reqs
                    try:
                        # Streaming: use the async generator variant that yields member events
                        async for event in _aroute_requirements_to_members_stream(
                            team,
                            run_response=run_response,
                            session=team_session,
                            member_results=member_results,
                            run_context=run_context,
                            stream_events=stream_events,
                        ):
                            yield event
                    except Exception:
                        # Routing failed mid-flight; put the team-level requirements
                        # back so the caller's run object stays complete for a retry.
                        run_response.requirements = team_level_reqs + (run_response.requirements or [])
                        raise
                    # Merge: keep team-level reqs + any newly propagated member reqs (chained HITL)
                    newly_propagated = [
                        r for r in (run_response.requirements or []) if id(r) not in original_member_req_ids
                    ]
                    run_response.requirements = team_level_reqs + newly_propagated
                    # Routing succeeded; bank the accumulated results for a retry.
                    routed_member_results = member_results

                    if run_response.requirements and any(not req.is_resolved() for req in run_response.requirements):
                        from agno.team import _hooks

                        async for item in _hooks.ahandle_team_run_paused_stream(
                            team, run_response=run_response, session=team_session, run_context=run_context
                        ):
                            yield item
                        if yield_run_output:
                            yield run_response
                        return

                if has_team_level or _did_snapshot_dispatch:
                    # Includes _did_snapshot_dispatch: a freshly-forked team run has no
                    # requirements but still needs the team-leader model call
                    # to produce a response. Without this, forked runs would
                    # fall through to terminal cleanup with content=None.
                    # Guard: if team-level requirements are unresolved, re-pause instead of auto-rejecting
                    unresolved_team = [
                        r
                        for r in (run_response.requirements or [])
                        if getattr(r, "member_agent_id", None) is None and not r.is_resolved()
                    ]
                    if unresolved_team:
                        from agno.team import _hooks

                        async for item in _hooks.ahandle_team_run_paused_stream(
                            team, run_response=run_response, session=team_session, run_context=run_context
                        ):
                            yield item
                        if yield_run_output:
                            yield run_response
                        return

                    team.model = cast(Model, team.model)
                    await _check_and_refresh_mcp_tools(team)

                    team_run_context: Dict[str, Any] = {}
                    learning_tools = await _aget_learning_tools(team, user_id, team_session)
                    _tools = _determine_tools_for_model(
                        team,
                        model=team.model,
                        run_response=run_response,
                        run_context=run_context,
                        team_run_context=team_run_context,
                        session=team_session,
                        user_id=user_id,
                        async_mode=True,
                        stream=True,
                        stream_events=stream_events,
                        learning_tools=learning_tools,
                    )

                    input_messages = run_response.messages or []
                    run_messages = await _aget_continue_run_messages(
                        team,
                        input=input_messages,
                        session=team_session,
                        add_history_to_context=team.add_history_to_context,
                        run_context=run_context,
                    )

                    run_response.status = RunStatus.running
                    run_response.content = None

                    # Yield RunContinued event
                    if stream_events:
                        yield handle_event(
                            create_team_run_continued_event(run_response),
                            run_response,
                            events_to_skip=team.events_to_skip,
                            store_events=team.store_events,
                        )

                    # Handle the updated tools (execute confirmed tools, etc.) with streaming
                    async for event in _ahandle_team_tool_call_updates_stream(
                        team,
                        run_response=run_response,
                        run_messages=run_messages,
                        tools=_tools,
                        stream_events=stream_events,
                    ):
                        await araise_if_cancelled(run_response.run_id)  # type: ignore
                        yield event

                    # Stream model response
                    if team.output_model is None:
                        async for event in _ahandle_model_response_stream(
                            team,
                            session=team_session,
                            run_response=run_response,
                            run_messages=run_messages,
                            tools=_tools,
                            response_format=response_format,
                            stream_events=stream_events,
                            session_state=run_context.session_state,
                            run_context=run_context,
                        ):
                            if not isinstance(event, _MEMBER_CANCEL_BYPASS_EVENT_TYPES):
                                await araise_if_cancelled(run_response.run_id)  # type: ignore
                            yield event
                    else:
                        from agno.run.team import IntermediateRunContentEvent, RunContentEvent

                        async for event in _ahandle_model_response_stream(
                            team,
                            session=team_session,
                            run_response=run_response,
                            run_messages=run_messages,
                            tools=_tools,
                            response_format=response_format,
                            stream_events=stream_events,
                            session_state=run_context.session_state,
                            run_context=run_context,
                        ):
                            if not isinstance(event, _MEMBER_CANCEL_BYPASS_EVENT_TYPES):
                                await araise_if_cancelled(run_response.run_id)  # type: ignore
                            if isinstance(event, RunContentEvent):
                                if stream_events:
                                    yield IntermediateRunContentEvent(
                                        content=event.content,
                                        content_type=event.content_type,
                                    )
                            else:
                                yield event

                        async for event in agenerate_response_with_output_model_stream(
                            team,
                            session=team_session,
                            run_response=run_response,
                            run_messages=run_messages,
                            stream_events=stream_events,
                        ):
                            await araise_if_cancelled(run_response.run_id)  # type: ignore
                            yield event

                    await araise_if_cancelled(run_response.run_id)  # type: ignore

                    # Check for new pauses
                    if run_response.requirements and any(not req.is_resolved() for req in run_response.requirements):
                        from agno.team import _hooks

                        async for item in _hooks.ahandle_team_run_paused_stream(
                            team, run_response=run_response, session=team_session, run_context=run_context
                        ):
                            yield item
                        if yield_run_output:
                            yield run_response
                        return

                    # Parse response with parser model
                    async for event in aparse_response_with_parser_model_stream(
                        team,
                        session=team_session,
                        run_response=run_response,
                        stream_events=stream_events,
                        run_context=run_context,
                    ):
                        yield event

                elif member_results:
                    # Member-only: continue the same run with member results
                    team.model = cast(Model, team.model)
                    await _check_and_refresh_mcp_tools(team)

                    team_run_context: Dict[str, Any] = {}  # type: ignore[no-redef]
                    learning_tools = await _aget_learning_tools(team, user_id, team_session)
                    _tools = _determine_tools_for_model(
                        team,
                        model=team.model,
                        run_response=run_response,
                        run_context=run_context,
                        team_run_context=team_run_context,
                        session=team_session,
                        user_id=user_id,
                        async_mode=True,
                        stream=True,
                        stream_events=stream_events,
                        learning_tools=learning_tools,
                    )

                    input_messages = run_response.messages or []
                    run_messages = await _aget_continue_run_messages(
                        team,
                        input=input_messages,
                        session=team_session,
                        add_history_to_context=team.add_history_to_context,
                        run_context=run_context,
                    )

                    # Prepare for member HITL continuation
                    _prepare_member_hitl_continuation(run_response, run_messages, member_results)

                    log_debug(f"Team Continue Run Stream (Member HITL): {run_response.run_id}", center=True)

                    # Yield RunContinued event
                    if stream_events:
                        yield handle_event(
                            create_team_run_continued_event(run_response),
                            run_response,
                            events_to_skip=team.events_to_skip,
                            store_events=team.store_events,
                        )

                    # Stream model response
                    if team.output_model is None:
                        async for event in _ahandle_model_response_stream(
                            team,
                            session=team_session,
                            run_response=run_response,
                            run_messages=run_messages,
                            tools=_tools,
                            response_format=response_format,
                            stream_events=stream_events,
                            session_state=run_context.session_state,
                            run_context=run_context,
                        ):
                            if not isinstance(event, _MEMBER_CANCEL_BYPASS_EVENT_TYPES):
                                await araise_if_cancelled(run_response.run_id)  # type: ignore
                            yield event
                    else:
                        from agno.run.team import IntermediateRunContentEvent, RunContentEvent

                        async for event in _ahandle_model_response_stream(
                            team,
                            session=team_session,
                            run_response=run_response,
                            run_messages=run_messages,
                            tools=_tools,
                            response_format=response_format,
                            stream_events=stream_events,
                            session_state=run_context.session_state,
                            run_context=run_context,
                        ):
                            if not isinstance(event, _MEMBER_CANCEL_BYPASS_EVENT_TYPES):
                                await araise_if_cancelled(run_response.run_id)  # type: ignore
                            if isinstance(event, RunContentEvent):
                                if stream_events:
                                    yield IntermediateRunContentEvent(
                                        content=event.content,
                                        content_type=event.content_type,
                                    )
                            else:
                                yield event

                        async for event in agenerate_response_with_output_model_stream(
                            team,
                            session=team_session,
                            run_response=run_response,
                            run_messages=run_messages,
                            stream_events=stream_events,
                        ):
                            await araise_if_cancelled(run_response.run_id)  # type: ignore
                            yield event

                    # Check for new pauses
                    if run_response.requirements and any(not req.is_resolved() for req in run_response.requirements):
                        from agno.team import _hooks

                        async for item in _hooks.ahandle_team_run_paused_stream(
                            team, run_response=run_response, session=team_session, run_context=run_context
                        ):
                            yield item
                        if yield_run_output:
                            yield run_response
                        return

                    # Parse response with parser model
                    async for event in aparse_response_with_parser_model_stream(
                        team,
                        session=team_session,
                        run_response=run_response,
                        stream_events=stream_events,
                        run_context=run_context,
                    ):
                        yield event

                # Content completed
                if stream_events:
                    yield handle_event(
                        create_team_run_content_completed_event(from_run_response=run_response),
                        run_response,
                        events_to_skip=team.events_to_skip,
                        store_events=team.store_events,
                    )

                # Post-hooks
                if team.post_hooks is not None:
                    async for event in _aexecute_post_hooks(
                        team,
                        hooks=team.post_hooks,  # type: ignore
                        run_output=run_response,
                        run_context=run_context,
                        session=team_session,
                        user_id=user_id,
                        debug_mode=debug_mode,
                        stream_events=stream_events,
                        background_tasks=background_tasks,
                        **kwargs,
                    ):
                        yield event

                # Session summary
                if team.session_summary_manager is not None:
                    team_session.upsert_run(run_response=run_response)
                    if stream_events:
                        yield handle_event(
                            create_team_session_summary_started_event(from_run_response=run_response),
                            run_response,
                            events_to_skip=team.events_to_skip,
                            store_events=team.store_events,
                        )
                    try:
                        await team.session_summary_manager.acreate_session_summary(
                            session=team_session, run_metrics=run_response.metrics
                        )
                    except Exception as e:
                        log_warning(f"Error in session summary creation: {str(e)}")
                    if stream_events:
                        yield handle_event(
                            create_team_session_summary_completed_event(
                                from_run_response=run_response, session_summary=team_session.summary
                            ),
                            run_response,
                            events_to_skip=team.events_to_skip,
                            store_events=team.store_events,
                        )

                # Completed
                completed_event = handle_event(
                    create_team_run_completed_event(run_response),
                    run_response,
                    events_to_skip=team.events_to_skip,
                    store_events=team.store_events,
                )

                run_response.status = RunStatus.completed
                await _acleanup_and_store(team, run_response=run_response, session=team_session)

                if stream_events:
                    yield completed_event

                if yield_run_output:
                    yield run_response

                await alog_team_telemetry(team, session_id=team_session.session_id, run_id=run_response.run_id)
                log_debug(f"Team Continue Run End: {run_response.run_id}", center=True, symbol="*")
                break

            except RunCancelledException as e:
                if run_response is None:
                    run_response = TeamRunOutput(run_id=run_id)
                run_response = cast(TeamRunOutput, run_response)
                run_response = _handle_team_run_cancellation(run_response, e, run_messages, session=team_session)
                cancelled_event, completed_event = _build_team_cancel_terminal_events(
                    team,
                    run_response,
                    error=e,
                    run_context=run_context,
                )
                if run_response.run_id:
                    await adrain_member_tasks(run_response.run_id)
                try:
                    if team_session is not None:
                        await _acleanup_and_store(team, run_response=run_response, session=team_session)
                except Exception as store_err:
                    log_warning(f"Failed to persist cancelled run: {store_err}")
                yield cancelled_event  # type: ignore
                yield completed_event  # type: ignore
                if yield_run_output:
                    yield run_response
                break

            except (InputCheckError, OutputCheckError) as e:
                run_response = cast(TeamRunOutput, run_response)
                run_response.status = RunStatus.error
                flush_in_flight_messages_on_error_team(run_response, locals().get("run_messages"))
                run_error = create_team_run_error_event(
                    run_response,
                    error=str(e),
                    error_id=e.error_id,
                    error_type=e.type,
                    additional_data=e.additional_data,
                )
                run_response.events = add_team_error_event(error=run_error, events=run_response.events)
                if run_response.content is None:
                    run_response.content = str(e)
                log_error(f"Validation failed: {str(e)} | Check: {e.check_trigger}")
                if team_session is not None:
                    await _acleanup_and_store(team, run_response=run_response, session=team_session)
                yield run_error
                if yield_run_output:
                    yield run_response
                break

            except (KeyboardInterrupt, asyncio.CancelledError, GeneratorExit) as cancel_exc:
                if run_response is None:
                    run_response = TeamRunOutput(run_id=run_id)
                run_response = cast(TeamRunOutput, run_response)
                run_response = _handle_team_run_cancellation(
                    run_response, KeyboardInterrupt(), run_messages, session=team_session
                )
                # Build terminal events first so they are stored on the run
                cancelled_event, completed_event = _build_team_cancel_terminal_events(
                    team,
                    run_response,
                    error=KeyboardInterrupt(),
                    run_context=run_context,
                )
                if team_session is not None:
                    if isinstance(cancel_exc, (asyncio.CancelledError, GeneratorExit)):
                        # Client disconnect: persist on a detached task so the cancel scope can't abort the write.
                        # GeneratorExit is raised when the SSE StreamingResponse closes the generator on disconnect.
                        _persist_cancelled_team_run_in_background(
                            team, run_response=run_response, session=team_session, run_context=run_context
                        )
                    else:
                        # Ctrl-C under asyncio.run: persist inline; a detached task would not run before the loop exits
                        await _acleanup_and_store(
                            team, run_response=run_response, session=team_session, run_context=run_context
                        )
                # Re-raise on disconnect (client gone); yield the terminal events on Ctrl-C
                if isinstance(cancel_exc, (asyncio.CancelledError, GeneratorExit)):
                    raise
                yield cancelled_event  # type: ignore
                yield completed_event  # type: ignore
                if yield_run_output:
                    yield run_response
                break

            except (ValueError, RunNotFoundError):
                # Validation errors (e.g. cancelled run, unknown run id, missing
                # args) propagate to the caller. RunNotFoundError must NOT fall
                # through to the generic handler below: that one stamps a terminal
                # ERROR run row over the target run.
                raise
            except Exception as e:
                if run_response is None:
                    run_response = TeamRunOutput(run_id=run_id)
                run_response = cast(TeamRunOutput, run_response)
                if attempt < num_attempts - 1:
                    if team.exponential_backoff:
                        delay = team.delay_between_retries * (2**attempt)
                    else:
                        delay = team.delay_between_retries
                    log_warning(f"Attempt {attempt + 1}/{num_attempts} failed. Retrying in {delay}s...: {str(e)}")
                    await asyncio.sleep(delay)
                    continue

                run_response.status = RunStatus.error
                flush_in_flight_messages_on_error_team(run_response, locals().get("run_messages"))
                run_error = create_team_run_error_event(run_response, error=str(e), error_type=error_type_of(e))
                run_response.events = add_team_error_event(error=run_error, events=run_response.events)
                if run_response.content is None:
                    run_response.content = str(e)
                log_error(f"Error in Team acontinue_run stream: {str(e)}")
                if team_session is not None:
                    await _acleanup_and_store(team, run_response=run_response, session=team_session)
                yield run_error
                if yield_run_output:
                    yield run_response

    finally:
        _disconnect_connectable_tools(team)
        await _disconnect_mcp_tools(team)  # type: ignore
        if run_response and run_response.run_id:
            await acleanup_run(run_response.run_id)
