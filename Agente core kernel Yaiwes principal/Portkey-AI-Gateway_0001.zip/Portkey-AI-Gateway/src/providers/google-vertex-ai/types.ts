import { Params } from '../../types/requestBody';
import { ChatCompletionResponse, GroundingMetadata } from '../types';

export interface GoogleErrorResponse {
  error: {
    code: number;
    message: string;
    status: string;
    details: Array<Record<string, any>>;
  };
}

export interface GoogleGenerateFunctionCall {
  name: string;
  args: Record<string, any>;
}

export interface GoogleResponseCandidate {
  content: {
    parts: {
      text?: string;
      thought?: string; // for models like gemini-2.0-flash-thinking-exp refer: https://ai.google.dev/gemini-api/docs/thinking-mode#streaming_model_thinking
      functionCall?: GoogleGenerateFunctionCall;
      inlineData?: {
        mimeType: string;
        data: string;
      };
      thoughtSignature?: string;
    }[];
  };
  logprobsResult?: {
    topCandidates: [
      {
        candidates: [
          {
            token: string;
            logProbability: number;
          },
        ];
      },
    ];
    chosenCandidates: [
      {
        token: string;
        logProbability: number;
      },
    ];
  };
  finishReason: string;
  index: 0;
  safetyRatings: {
    category: string;
    probability: string;
  }[];
  groundingMetadata?: GroundingMetadata;
}

export interface GoogleGenerateContentResponse {
  modelVersion: string;
  candidates: GoogleResponseCandidate[];
  promptFeedback: {
    safetyRatings: {
      category: string;
      probability: string;
      probabilityScore: number;
      severity: string;
      severityScore: number;
    }[];
  };
  usageMetadata: {
    promptTokenCount: number;
    candidatesTokenCount: number;
    totalTokenCount: number;
    thoughtsTokenCount?: number;
    cachedContentTokenCount?: number;
    promptTokensDetails: {
      modality: VERTEX_MODALITY;
      tokenCount: number;
    }[];
    candidatesTokensDetails: {
      modality: VERTEX_MODALITY;
      tokenCount: number;
    }[];
  };
}

export interface VertexLLamaChatCompleteResponse
  extends Omit<ChatCompletionResponse, 'id' | 'created'> {}

export interface VertexLlamaChatCompleteStreamChunk {
  choices: {
    delta: {
      content: string;
      role: string;
    };
    finish_reason?: string;
    index: 0;
  }[];
  model: string;
  object: string;
  usage?: {
    completion_tokens: number;
    prompt_tokens: number;
    total_tokens: number;
  };
  id?: string;
  created?: number;
  provider?: string;
}

export type EmbedInstancesData = TextEmbedInstance | MultimodalEmbedInstance;

export interface TextEmbedInstance {
  task_type: string;
  content: string;
}
export interface MultimodalEmbedInstance {
  image?: {
    gcsUri?: string;
    bytesBase64Encoded?: string;
  };
  text?: string;
  video?: {
    gcsUri?: string;
    bytesBase64Encoded?: string;
    videoSegmentConfig?: {
      startOffsetSec?: number;
      endOffsetSec?: number;
      intervalSec?: number;
    };
  };
}

interface EmbedPredictionsResponse {
  embeddings: {
    values: number[];
    statistics: {
      truncated: string;
      token_count: number;
    };
  };
  imageEmbedding?: number[];
  textEmbedding?: number[];
  videoEmbeddings?: {
    embedding: number[];
    endOffsetSec: number;
    startOffsetSec: number;
  }[];
}

export interface GoogleEmbedResponse {
  predictions: EmbedPredictionsResponse[];
  metadata: {
    billableCharacterCount: number;
  };
}

export interface GoogleSearchRetrievalTool {
  googleSearchRetrieval: {
    dynamicRetrievalConfig?: {
      mode: string;
      dynamicThreshold?: string;
    };
  };
}

type GoogleBatchJobStatus =
  | 'JOB_STATE_UNSPECIFIED'
  | 'JOB_STATE_QUEUED'
  | 'JOB_STATE_PENDING'
  | 'JOB_STATE_RUNNING'
  | 'JOB_STATE_SUCCEEDED'
  | 'JOB_STATE_FAILED'
  | 'JOB_STATE_CANCELLING'
  | 'JOB_STATE_CANCELLED'
  | 'JOB_STATE_PAUSED'
  | 'JOB_STATE_EXPIRED'
  | 'JOB_STATE_UPDATING'
  | 'JOB_STATE_PARTIALLY_SUCCEEDED';

export interface GoogleBatchRecord {
  /**
   * @example projects/562188160088/locations/us-east4/batchPredictionJobs/{id}
   */
  name: string;
  displayName: string;
  /**
   * @example projects/562188160088/locations/us-east4/models/{model}
   */
  model: string;
  inputConfig: {
    instancesFormat: 'jsonl';
    gcsSource: {
      uris: string;
    };
  };
  outputConfig: {
    predictionsFormat: 'jsonl';
    gcsDestination: {
      outputUriPrefix: string;
    };
  };
  outputInfo?: {
    gcsOutputDirectory: string;
  };
  state: GoogleBatchJobStatus;
  createTime: string;
  updateTime: string;
  modelVersionId: string;
  error?: {
    code: string;
    message: string;
  };
  startTime: string;
  endTime: string;
  completionStats?: {
    successfulCount: string;
    failedCount: string;
    incompleteCount: string;
    successfulForecastPointCount: string;
  };
}

export interface GoogleFinetuneRecord {
  name: string;
  state: GoogleBatchJobStatus;
  tunedModelDisplayName: string;
  description: string;
  createTime: string;
  startTime: string;
  endTime: string;
  updateTime: string;
  error: string;
  tunedModel?: {
    model: string;
    endpoint: string;
  };
  tuningDataStats?: {
    supervisedTuningDataStats: {
      tuningDatasetExampleCount: number;
      totalTuningCharacterCount: number;
      totalBillableTokenCount: number;
      tuningStepCount: number;
      userInputTokenDistribution: number;
    };
  };
  baseModel: string;
  source_model?: {
    baseModel: string;
  };
  supervisedTuningSpec: {
    trainingDatasetUri: string;
    validationDatasetUri: string;
    hyperParameters: {
      learningRateMultiplier: number;
      epochCount: number;
      adapterSize: number;
    };
  };
}

export enum VERTEX_GEMINI_GENERATE_CONTENT_FINISH_REASON {
  FINISH_REASON_UNSPECIFIED = 'FINISH_REASON_UNSPECIFIED',
  STOP = 'STOP',
  MAX_TOKENS = 'MAX_TOKENS',
  SAFETY = 'SAFETY',
  RECITATION = 'RECITATION',
  OTHER = 'OTHER',
  BLOCKLIST = 'BLOCKLIST',
  PROHIBITED_CONTENT = 'PROHIBITED_CONTENT',
  SPII = 'SPII',
}

export enum VERTEX_MODALITY {
  MODALITY_UNSPECIFIED = 'MODALITY_UNSPECIFIED',
  TEXT = 'TEXT',
  IMAGE = 'IMAGE',
  AUDIO = 'AUDIO',
}
export interface PortkeyGeminiParams extends Params {
  image_config?: {
    aspect_ratio: string; // '16:9', '4:3', '1:1'
    image_size: string; // '2K', '4K', '8K'
  };
}
