import { AZURE_OPEN_AI } from '../../globals';
import { Options } from '../../types/requestBody';
import { OpenAIErrorResponseTransform } from '../openai/utils';
import { ErrorResponse } from '../types';

export async function getAccessTokenFromEntraId(
  tenantId: string,
  clientId: string,
  clientSecret: string,
  scope = 'https://cognitiveservices.azure.com/.default'
) {
  try {
    const url = `https://login.microsoftonline.com/${tenantId}/oauth2/v2.0/token`;
    const params = new URLSearchParams({
      client_id: clientId,
      client_secret: clientSecret,
      scope: scope,
      grant_type: 'client_credentials',
    });

    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: params,
    });

    if (!response.ok) {
      const errorMessage = await response.text();
      console.error('getAccessTokenFromEntraId error: ', {
        message: `Error from Entra ${errorMessage}`,
      });
      return undefined;
    }
    const data: { access_token: string } = await response.json();
    return data.access_token;
  } catch (error) {
    console.error('getAccessTokenFromEntraId error: ', error);
  }
}

export async function getAzureManagedIdentityToken(
  resource: string,
  clientId?: string
) {
  try {
    const response = await fetch(
      `http://169.254.169.254/metadata/identity/oauth2/token?api-version=2018-02-01&resource=${encodeURIComponent(resource)}${clientId ? `&client_id=${encodeURIComponent(clientId)}` : ''}`,
      {
        method: 'GET',
        headers: {
          Metadata: 'true',
        },
      }
    );
    if (!response.ok) {
      const errorMessage = await response.text();
      console.error('getAzureManagedIdentityToken error: ', {
        message: `Error from Managed ${errorMessage}`,
      });
      return undefined;
    }
    const data: { access_token: string } = await response.json();
    return data.access_token;
  } catch (error) {
    console.error('getAzureManagedIdentityToken error: ', error);
  }
}

export async function getAzureWorkloadIdentityToken(
  authorityHost: string,
  tenantId: string,
  clientId: string,
  federatedToken: string,
  scope = 'https://cognitiveservices.azure.com/.default'
) {
  try {
    const url = `${authorityHost}/${tenantId}/oauth2/v2.0/token`;
    const params = new URLSearchParams({
      client_id: clientId,
      client_assertion: federatedToken,
      client_assertion_type:
        'urn:ietf:params:oauth:client-assertion-type:jwt-bearer',
      scope: scope,
      grant_type: 'client_credentials',
    });

    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: params,
    });

    if (!response.ok) {
      const errorMessage = await response.text();
      console.error({ message: `Error from Entra ${errorMessage}` });
      return undefined;
    }
    const data: { access_token: string } = await response.json();
    return data.access_token;
  } catch (error) {
    console.error(error);
  }
}

export const AzureOpenAIFinetuneResponseTransform = (
  response: Response | ErrorResponse,
  responseStatus: number
): Response | ErrorResponse => {
  if (responseStatus !== 200 && 'error' in response) {
    return OpenAIErrorResponseTransform(response, AZURE_OPEN_AI);
  }

  const _response = { ...response } as any;

  if (['created', 'pending'].includes(_response.status)) {
    _response.status = 'queued';
  }

  return _response;
};

export const getAzureModelValue = (
  params: Params,
  providerOptions?: Options
) => {
  const { apiVersion: azureApiVersion, deploymentId: azureDeploymentName } =
    providerOptions ?? {};
  if (azureApiVersion && azureApiVersion.trim() === 'v1') {
    return azureDeploymentName;
  }
  return params.model || '';
};
