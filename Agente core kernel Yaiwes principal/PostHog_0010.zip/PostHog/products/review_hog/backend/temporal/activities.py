"""Temporal activities for the single-turn ReviewHog PR review.

Each activity wraps one stage of the former `run.py main()` pipeline. Inputs carry only small,
serializable values — `(team_id, user_id, report_id, head_sha, repository, branch)` plus unit keys
or JSON-encoded issue slices — and every activity that needs the PR's metadata / comments / files
reloads them from the `pr_snapshot` artefact by `(report_id, head_sha)`. Nothing big (pr_files, the
diff, perspective results) ever crosses the workflow boundary, so the Temporal ~2 MiB payload cap is
respected and the sandbox fan-out stays by-reference.

Sandbox-turn activities (chunk / review / dedup) call `run_sandbox_review`, which spins a single-turn
agent (minutes); `validate_chunk_activity` instead drives one warm multi-turn session per chunk. Both
take minutes, so they declare a `heartbeat_timeout` on dispatch and heartbeat via `Heartbeater()`. ORM
access goes through `database_sync_to_async(..., thread_sensitive=False)`; `@scoped_temporal()` +
`@close_db_connections` mirror the Signals report activities.
"""

import uuid
import logging
import datetime
from collections import Counter
from dataclasses import dataclass, field

import posthoganalytics
from temporalio import activity
from temporalio.exceptions import ApplicationError

from posthog.event_usage import groups
from posthog.models.integration import GitHubIntegration, Integration
from posthog.models.team.team import Team
from posthog.sync import database_sync_to_async
from posthog.temporal.common.heartbeat import Heartbeater
from posthog.temporal.common.scoped import scoped_temporal
from posthog.temporal.common.utils import close_db_connections

from products.review_hog.backend.models import ReviewReport, ReviewUserSettings
from products.review_hog.backend.reviewer.constants import (
    CHUNKING_MODEL,
    CHUNKING_ONESHOT_MAX_ADDITIONS,
    CHUNKING_REASONING_EFFORT,
    CHUNKING_RUNTIME_ADAPTER,
    DEFAULT_URGENCY_THRESHOLD,
    VALIDATION_INITIAL_PERMISSION_MODE,
    VALIDATION_MAX_ATTEMPTS,
    VALIDATION_MODEL,
    VALIDATION_REASONING_EFFORT,
    VALIDATION_RUNTIME_ADAPTER,
    effective_priority,
    published_priorities_for,
    resolve_review_arm,
)
from products.review_hog.backend.reviewer.lazy_seed import (
    sync_canonical_authoring,
    sync_canonical_blind_spots,
    sync_canonical_perspectives,
    sync_canonical_resolution,
    sync_canonical_validation,
)
from products.review_hog.backend.reviewer.models import generate_all_schemas
from products.review_hog.backend.reviewer.models.github_meta import PRFile, PRMetadata
from products.review_hog.backend.reviewer.models.issue_validation import IssueValidation
from products.review_hog.backend.reviewer.models.issues_review import Issue, IssuePriority, IssuesReview
from products.review_hog.backend.reviewer.models.perspective_selection import PerspectiveSelection
from products.review_hog.backend.reviewer.models.split_pr_into_chunks import Chunk, ChunksList
from products.review_hog.backend.reviewer.persistence import (
    finalize_review_report,
    load_chunk_set,
    load_perspective_results,
    load_perspective_selection,
    load_pr_snapshot,
    load_prior_findings,
    load_prior_findings_with_verdicts,
    load_review_arm,
    load_run_issues,
    load_run_validations,
    load_turn_findings,
    load_valid_findings,
    persist_chunk_set,
    persist_commit_snapshot,
    persist_findings,
    persist_perspective_results,
    persist_perspective_selection,
    persist_pr_snapshot,
    persist_verdict,
    upsert_review_report,
)
from products.review_hog.backend.reviewer.sandbox.direct_llm import run_oneshot_review
from products.review_hog.backend.reviewer.sandbox.executor import (
    MultiTurnSession,
    continue_sandbox_session,
    end_sandbox_session,
    run_sandbox_review,
    start_sandbox_session,
)
from products.review_hog.backend.reviewer.skill_loader import (
    load_blind_spots_skill_for_run,
    load_perspectives_for_run,
    load_validation_skill_for_run,
)
from products.review_hog.backend.reviewer.status_comment import (
    FinalizeStatusCommentInput,
    ensure_status_comment,
    fail_status_comment,
    finalize_status_comment,
    maybe_refresh_status_comment,
)
from products.review_hog.backend.reviewer.tools.github_client import GitHubAPIError, github_api_request
from products.review_hog.backend.reviewer.tools.github_meta import (
    PRFetcher,
    fetch_branch_compare,
    find_open_pr_for_branch,
)
from products.review_hog.backend.reviewer.tools.issue_cleaner import clean_issues
from products.review_hog.backend.reviewer.tools.issue_combination import combine_issues
from products.review_hog.backend.reviewer.tools.issue_deduplicator import deduplicate_issues
from products.review_hog.backend.reviewer.tools.issue_validation import (
    VALIDATION_SYSTEM_PROMPT,
    build_validation_followup_prompt,
    build_validation_prompt,
)
from products.review_hog.backend.reviewer.tools.issues_review import REVIEW_SYSTEM_PROMPT, build_review_prompt
from products.review_hog.backend.reviewer.tools.prepare_validation_markdown import build_review_body
from products.review_hog.backend.reviewer.tools.publish_review import publish_persisted_review
from products.review_hog.backend.reviewer.tools.select_perspectives import (
    SELECTION_SYSTEM_PROMPT,
    PerspectiveSelectionDTO,
    generate_selection_prompt,
    normalize_selection,
    prunable_perspectives,
)
from products.review_hog.backend.reviewer.tools.split_pr_into_chunks import (
    CHUNKING_SYSTEM_PROMPT,
    count_reviewable_additions,
    generate_chunking_prompt,
    plan_deterministic_chunks,
    reconcile_chunks,
)
from products.review_hog.backend.temporal.types import TRIGGER_LABEL, TRIGGER_MANUAL
from products.signals.backend.artefact_attribution import ArtefactAttribution
from products.signals.backend.artefact_schemas import CodeReview, CodeReviewCounts
from products.signals.backend.models import SignalReport, SignalReportArtefact
from products.signals.backend.report_generation.resolve_reviewers import resolve_org_github_login_to_users

logger = logging.getLogger(__name__)


# --- Inputs / outputs ------------------------------------------------------------------------------


@dataclass
class ValidateIntegrationInput:
    team_id: int


@dataclass
class FetchPRDataInput:
    team_id: int
    user_id: int
    repository: str
    owner: str
    repo: str
    # PR target when set; branch target (`head_branch`) when None. Defaults keep old payloads deserializing.
    pr_number: int | None = None
    pr_url: str | None = None
    head_branch: str | None = None
    # Provenance stamped onto the ReviewReport at upsert (see `upsert_review_report`).
    signal_report_id: str | None = None
    trigger_source: str = TRIGGER_MANUAL


@dataclass
class ReviewMeta:
    """Small fetch result the parent threads through the rest of the run (no big payloads)."""

    report_id: str
    head_sha: str
    branch: str
    repository: str
    # This turn's 1-based index; stamped on each finding so publishing scopes to one turn.
    run_index: int
    snapshotted: bool
    # Already reviewed AND posted this exact head (published_head_sha == head_sha): the parent's
    # early-exit gate skips a dead re-trigger turn. Distinct from `snapshotted` (head moved) because a
    # head can be unchanged yet not-yet-published (a prior no-publish turn) and must still publish.
    already_published: bool
    # New inline comments since the last turn's watermark — logged only for now; they don't force a
    # turn yet (see DECISIONS.md, Stage 5b). Will gate the early-exit once ReviewHog reacts to comments.
    new_comment_count: int
    # The PR author's GitHub login (`pr_metadata.author`), so the parent can resolve the acting user
    # whose enabled perspectives this review applies.
    author_login: str
    # The resolved publish destination: the input PR, or the open PR the fetch discovered for a
    # branch target. None = branch target with no PR yet → the turn stores instead of publishing.
    pr_number: int | None = None
    pr_url: str | None = None
    # A branch target whose compare diff has no reviewable files ("pushed nothing"): the parent
    # self-skips the turn before any sandbox spend.
    empty_diff: bool = False


@dataclass
class ResolveActingUserInput:
    team_id: int
    author_login: str
    # CLI/eval override: when set, perspective selection uses this user directly instead of resolving
    # the PR author — the local eval tests a specific user's perspectives against any PR.
    override_user_id: int | None
    # When set, the resolved acting user is stamped onto this report (powers "your recent reviews").
    # Defaulted so payloads serialized before the field existed still deserialize.
    report_id: str | None = None
    # Which trigger runs: the label trigger falls back to `default_user_id` on an unmapped author —
    # the run user the trigger already resolved (`inputs.user_id`), so the acting identity can never
    # drift from the identity the sandboxes execute under. Defaulted for old in-flight payloads.
    trigger_source: str = TRIGGER_MANUAL
    default_user_id: int | None = None


@dataclass
class ResolveActingUserResult:
    # The user whose enabled perspectives drive this review; None when nothing in the resolution
    # chain maps to a PostHog org user — the parent then skips the review.
    acting_user_id: int | None
    # The acting user's `ReviewUserSettings`, snapshotted here so mid-run edits don't flip gates
    # between stages. Defaults match the model's (and cover payloads serialized before these existed).
    # `review_labeled_prs` is the AUTHOR's opt-out: when the acting user is the default-user
    # fallback, it is forced True — a borrowed user's personal switch never governs someone else's PR.
    review_labeled_prs: bool = True
    urgency_threshold: str = IssuePriority.CONSIDER.value
    review_inbox_prs: bool = False
    # Which chain link resolved: "author" | "default" | "override" (observability + tests).
    resolved_from: str = "author"
    # Whether a published review of this user's PRs chains into the resolution stage. Defaults False
    # — the SKIP value — so pre-field histories replay deterministically (the chained dispatch is a
    # new workflow command; old runs must never reach it on replay). The model default is True.
    resolve_comments: bool = False


@dataclass
class LoadPerspectivesInput:
    team_id: int
    acting_user_id: int


@dataclass
class LoadValidationInput:
    team_id: int
    acting_user_id: int


@dataclass
class LoadBlindSpotsInput:
    team_id: int
    acting_user_id: int


@dataclass
class SyncReviewSkillsInput:
    team_id: int


@dataclass
class GenerateSchemasInput:
    pass


@dataclass
class SandboxStageInput:
    """Shared identity + turn scope for a sandbox-turn activity."""

    team_id: int
    user_id: int
    report_id: str
    head_sha: str
    repository: str
    branch: str
    run_index: int


@dataclass
class LoadedPerspectiveDTO:
    pass_number: int
    skill_name: str
    version: int
    # Injected into the blind-spot check's prompt ("these lenses already ran"). Defaulted so payloads
    # serialized before the field existed still deserialize.
    description: str = ""


@dataclass
class SelectPerspectivesInput(SandboxStageInput):
    # The run's enabled perspectives (the selector's menu); descriptions are what it judges by.
    perspectives: list[LoadedPerspectiveDTO] = field(default_factory=list)


@dataclass
class ReviewChunkInput(SandboxStageInput):
    chunk_id: int
    pass_number: int
    skill_name: str
    skill_version: int
    # Blind-spot check: the broad "what did everyone miss?" sweep run per chunk after the perspective
    # wave — fed every wave finding for the chunk, and told (below) which lenses ran on THIS chunk.
    blind_spot_check: bool = False
    wave_perspectives: list[LoadedPerspectiveDTO] = field(default_factory=list)


@dataclass
class ValidateChunkInput(SandboxStageInput):
    chunk_id: int
    # This chunk's post-dedup issue ids, grouped by the parent; the activity reloads the issue
    # content from the persisted finding rows (`load_run_issues`) instead of shipping it by value.
    issue_ids: list[str]
    skill_name: str
    skill_version: int


@dataclass
class ValidateChunkResult:
    chunk_id: int
    # How many of the chunk's issues now have a persisted verdict (skipped-as-done + freshly judged).
    validated_count: int


@dataclass
class LoadedValidationSkillDTO:
    skill_name: str
    version: int


@dataclass
class LoadedBlindSpotsSkillDTO:
    skill_name: str
    version: int


@dataclass
class DedupResult:
    # The persisted survivors' issue ids — the by-reference handle validate and body-build use to
    # reload issue content from the finding rows (unbounded issue JSON would foreseeably hit
    # Temporal's ~2 MiB payload cap on large PRs).
    issue_ids: list[str]


@dataclass
class BuildBodyInput:
    team_id: int
    report_id: str
    head_sha: str
    run_index: int
    # This turn's survivor ids (`DedupResult.issue_ids`); content reloads from the finding rows.
    issue_ids: list[str]
    # The acting user's threshold, snapshotted at resolve time. Defaulted so pre-field payloads
    # still deserialize — a missing field takes the current default, not the run's original gate.
    urgency_threshold: str = IssuePriority.CONSIDER.value
    # Whether this run dispatches the publish stage after finalizing. Publishing runs defer the
    # idle write to publish so the report never reads at-rest with the post still in flight.
    # Defaulted False so pre-field payloads keep the finalize-goes-idle behavior.
    will_publish: bool = False


@dataclass
class PublishInput:
    team_id: int
    report_id: str
    head_sha: str
    run_index: int
    owner: str
    repo: str
    pr_number: int
    # Same snapshot as `BuildBodyInput.urgency_threshold`, so body counts and comments agree.
    urgency_threshold: str = IssuePriority.CONSIDER.value


@dataclass
class PublishResult:
    # Whether a review was actually posted this turn (False on the already-published / nothing-
    # publishable no-ops), and its GitHub permalink when known — feeds the code_review artefact.
    posted: bool = False
    review_url: str | None = None


@dataclass(frozen=True)
class RemoveTriggerLabelInput:
    team_id: int
    owner: str
    repo: str
    pr_number: int


@dataclass
class AppendCodeReviewArtefactInput:
    """One `code_review` receipt on the signals report's artefact log, per executed turn."""

    team_id: int
    signal_report_id: str
    review_report_id: str
    run_index: int
    outcome: str  # "published" / "stored" / "failed"
    review_url: str | None = None


@dataclass
class TrackReviewCompletedInput:
    """One `reviewhog_review_completed` analytics event per finalized review turn."""

    team_id: int
    report_id: str
    head_sha: str
    run_index: int
    published: bool
    # The workflow's start_time (ISO 8601) — one turn is one workflow execution, so this anchors
    # the event's turn duration.
    workflow_started_at: str


@dataclass
class TrackReviewFailedInput:
    """One `reviewhog_review_failed` analytics event per failed review turn."""

    team_id: int
    report_id: str
    run_index: int


@dataclass
class StatusCommentInput:
    """Kickoff / failure edits of the PR's status comment; owner/repo/pr come off the report row."""

    team_id: int
    report_id: str


# --- Setup activities ------------------------------------------------------------------------------


def _sandbox_workflow_id_prefix(step_name: str) -> str:
    """Brand a sandbox run's Temporal workflow id with the review it belongs to.

    `{review workflow id}:{step}` (lowercased), so one Temporal UI search by PR number surfaces the
    review, its children, and every sandbox run; a failed sandbox workflow is self-describing.
    """
    return f"{activity.info().workflow_id}:{step_name}".lower()


async def _refresh_status_comment(team_id: int, report_id: str) -> None:
    """Refresh the PR's status comment after this activity persisted progress (debounced, best-effort)."""
    await database_sync_to_async(maybe_refresh_status_comment, thread_sensitive=False)(team_id, report_id)


def _github_integration_exists(team_id: int) -> bool:
    return Integration.objects.filter(team_id=team_id, kind="github").exists()


def _installation_auth(team_id: int, repository: str) -> tuple[str, str | None]:
    """Resolve the team's GitHub App installation token (and installation id) for `repository`
    (`owner/repo`).

    Picks the installation that can actually access the repo and auto-refreshes an expired token.
    This replaces the worker's old `GITHUB_TOKEN` env dependency — the credential is the team's
    integration, resolved server-side. The installation id rides along so every GitHub call is
    metered against that installation's shared egress budget.

    `first_for_team_repository` probes the GitHub API, so a transient 5xx/rate-limit looks the same
    as "no installation". The error is therefore left **retryable** (the activity's retry rides out
    the blip); the genuinely-missing-integration case is already caught non-retryably up front by
    `validate_github_integration_activity`, so a real misconfig still fails fast there.
    """
    github = _installation_for(team_id, repository)
    return github.get_access_token(), github.github_installation_id


def _installation_for(team_id: int, repository: str) -> GitHubIntegration:
    """The team's GitHub App installation that can access `repository` — a live API probe.

    Callers that make many writes in one run should select once and re-mint tokens from the
    returned integration row (`GitHubIntegration(Integration.objects.get(...)).get_access_token()`)
    instead of re-probing per write: the probe answers *which* installation, not *may we write* —
    GitHub enforces access server-side on every call anyway.
    """
    github = GitHubIntegration.first_for_team_repository(team_id, repository)
    if github is None:
        raise ApplicationError(
            f"Could not resolve a GitHub App installation for team {team_id} that can access {repository} "
            "(no installation, or a transient GitHub API failure)."
        )
    return github


@activity.defn
@scoped_temporal()
@close_db_connections
async def validate_github_integration_activity(input: ValidateIntegrationInput) -> None:
    """Fail fast (non-retryably) if the team has no GitHub integration the sandbox tasks need."""
    exists = await database_sync_to_async(_github_integration_exists, thread_sensitive=False)(input.team_id)
    if not exists:
        raise ApplicationError(
            f"No GitHub integration found for team {input.team_id}. "
            "Set up a GitHub App installation first (Settings → Integrations).",
            non_retryable=True,
        )


def _fetch_and_persist(input: FetchPRDataInput) -> ReviewMeta:
    """Fetch the review target from GitHub, open/refresh the report, and snapshot this turn's inputs + diff.

    A branch target first resolves an open PR for its head branch (one API call): found → the turn
    continues exactly as the PR path (comments feed dedup, publish becomes possible, the report row
    upgrades from branch-keyed to PR-keyed); not found → the compare diff against the default branch
    is reviewed store-only, and an empty compare marks the turn as a self-skip ("pushed nothing → do
    nothing", enforced here like fork rejection).
    """
    token, installation_id = _installation_auth(input.team_id, input.repository)
    pr_number, pr_url = input.pr_number, input.pr_url
    if pr_number is None and input.head_branch:
        discovered = find_open_pr_for_branch(
            token=token,
            repository=input.repository,
            owner=input.owner,
            head_branch=input.head_branch,
            installation_id=installation_id,
        )
        if discovered is not None:
            pr_number, pr_url = discovered
            logger.info("Branch %s has open PR #%s; reviewing via the PR path", input.head_branch, pr_number)
    if pr_number is not None:
        pr_metadata, pr_comments, pr_files, diff = PRFetcher(
            owner=input.owner, repo=input.repo, pr_number=pr_number, token=token, installation_id=installation_id
        ).fetch_pr_data()
        if pr_metadata.is_fork:
            raise ApplicationError(
                f"Refusing to review fork PR #{pr_number} in {input.repository}: a fork's head ref is "
                "attacker-influenced and its branch isn't on the base origin (the sandbox checkout would fail).",
                non_retryable=True,
            )
    else:
        pr_metadata, pr_comments, pr_files, diff = fetch_branch_compare(
            token=token,
            repository=input.repository,
            head_branch=input.head_branch or "",
            installation_id=installation_id,
        )
    head_sha = pr_metadata.head_sha or ""
    report_id = upsert_review_report(
        team_id=input.team_id,
        repository=input.repository,
        pr_url=pr_url or "",
        pr_metadata=pr_metadata,
        signal_report_id=input.signal_report_id,
        trigger_source=input.trigger_source,
    )
    # Read the report's watermark BEFORE persist_commit_snapshot advances it, so the parent can decide
    # whether this turn has anything to do. `published_head_sha == head_sha` means we already reviewed
    # and posted this exact head; new comments are surfaced for visibility but don't gate yet.
    report = ReviewReport.objects.for_team(input.team_id).get(id=report_id)
    already_published = bool(head_sha) and report.published_head_sha == head_sha
    # This turn's index. run_count (completed turns) only bumps at finalize, so a turn that fails and
    # resumes reuses the same index while a fresh turn gets a new one.
    run_index = report.run_count + 1
    max_comment_id = max((c.id for c in pr_comments if c.id is not None), default=None)
    new_comment_count = sum(
        1
        for c in pr_comments
        if c.id is not None and (report.last_seen_comment_id is None or c.id > report.last_seen_comment_id)
    )
    if new_comment_count:
        logger.info(
            "PR #%s: %s new inline comment(s) since the last turn (watermark %s, latest %s)",
            pr_metadata.number,
            new_comment_count,
            report.last_seen_comment_id,
            max_comment_id,
        )
    snapshotted = persist_commit_snapshot(
        team_id=input.team_id,
        report_id=report_id,
        repository=input.repository,
        pr_metadata=pr_metadata,
        pr_comments=pr_comments,
        diff=diff,
    )
    persist_pr_snapshot(
        team_id=input.team_id,
        report_id=report_id,
        head_sha=head_sha,
        pr_metadata=pr_metadata,
        pr_comments=pr_comments,
        pr_files=pr_files,
    )
    return ReviewMeta(
        report_id=report_id,
        head_sha=head_sha,
        # Sandboxes check out this branch by name. The Tasks checkout only resolves refs/heads/<name>;
        # a pull ref like `pull/N/head` falls through to a fresh branch on the base tip, so every
        # sandbox would review the base branch instead of the PR.
        branch=pr_metadata.head_branch,
        repository=input.repository,
        run_index=run_index,
        snapshotted=snapshotted,
        already_published=already_published,
        new_comment_count=new_comment_count,
        author_login=pr_metadata.author,
        pr_number=pr_number,
        pr_url=pr_url,
        empty_diff=pr_number is None and not pr_files,
    )


@activity.defn
@scoped_temporal()
@close_db_connections
async def fetch_pr_data_activity(input: FetchPRDataInput) -> ReviewMeta:
    """Fetch PR data and persist the per-turn `commit` + `pr_snapshot` artefacts; return a small meta.

    The big `pr_files` payload stays in the DB (`pr_snapshot`); downstream stages reload it by
    `(report_id, head_sha)` so it never crosses the workflow boundary.
    """
    return await database_sync_to_async(_fetch_and_persist, thread_sensitive=False)(input)


def _login_to_user_id(team_id: int, login: str | None) -> int | None:
    if not login:
        return None
    matches = resolve_org_github_login_to_users(team_id, [login])
    user = matches.get(login.strip().lower())
    return user.id if user is not None else None


def _resolve_acting_user(input: ResolveActingUserInput) -> ResolveActingUserResult:
    acting_user_id: int | None
    if input.override_user_id is not None:
        acting_user_id, resolved_from = input.override_user_id, "override"
    else:
        acting_user_id, resolved_from = _login_to_user_id(input.team_id, input.author_login), "author"
        # Label-trigger fallback — someone explicitly asked for this review, so borrow the run user
        # the trigger already resolved. Other triggers keep the author-only contract and skip.
        if acting_user_id is None and input.trigger_source == TRIGGER_LABEL:
            acting_user_id, resolved_from = input.default_user_id, "default"
    if acting_user_id is None:
        return ResolveActingUserResult(acting_user_id=None)
    if resolved_from == "default":
        logger.info(
            "PR author %r has no PostHog user; acting as the default user %s", input.author_login, acting_user_id
        )
    if input.report_id is not None:
        ReviewReport.objects.for_team(input.team_id).filter(id=input.report_id).update(acting_user_id=acting_user_id)
    settings = ReviewUserSettings.load(input.team_id, acting_user_id)
    return ResolveActingUserResult(
        acting_user_id=acting_user_id,
        # The labeled-PR opt-out protects authors ("don't review my PRs") — the borrowed default
        # user never imports their personal switch into someone else's PR.
        review_labeled_prs=settings.review_labeled_prs if resolved_from in ("author", "override") else True,
        # str() unwraps the TextChoices member an unsaved defaults instance carries — the payload
        # must hold the plain value. A default-resolved run gates at the built-in default, never the
        # borrowed run user's saved threshold — the same "borrowed settings must not leak into
        # someone else's PR" rule that forces review_labeled_prs above.
        urgency_threshold=(
            str(settings.urgency_threshold)
            if resolved_from in ("author", "override")
            else DEFAULT_URGENCY_THRESHOLD.value
        ),
        review_inbox_prs=settings.review_inbox_prs,
        resolved_from=resolved_from,
        # Same author-protection shape as `review_labeled_prs`: the borrowed default user's personal
        # switch never governs someone else's PR — an unmapped author gets the default posture (on).
        resolve_comments=settings.resolve_comments if resolved_from in ("author", "override") else True,
    )


@activity.defn
@scoped_temporal()
@close_db_connections
async def resolve_acting_user_activity(input: ResolveActingUserInput) -> ResolveActingUserResult:
    """Resolve the user whose enabled perspectives drive this review, plus their settings snapshot.

    Production: the PR author, mapped GitHub-login → PostHog org user (`resolve_org_github_login_to_users`).
    The label trigger falls back to the default run user (someone explicitly asked for the review);
    other triggers return None on an unmapped author and the parent skips the review.
    The CLI/eval passes an explicit `override_user_id` to test a known user's perspectives on any PR.
    """
    return await database_sync_to_async(_resolve_acting_user, thread_sensitive=False)(input)


def _sync_review_skills(team_id: int) -> None:
    # prune=True: the run path is the only recurring sync moment (scout-style reconciliation), so
    # disk-removed canonicals tombstone here — otherwise they'd linger live on every team forever.
    team = Team.objects.get(id=team_id)
    sync_canonical_perspectives(team, prune=True)
    sync_canonical_validation(team, prune=True)
    sync_canonical_blind_spots(team, prune=True)
    sync_canonical_resolution(team, prune=True)
    sync_canonical_authoring(team, prune=True)


@activity.defn
@scoped_temporal()
@close_db_connections
async def sync_review_skills_activity(input: SyncReviewSkillsInput) -> None:
    """Reconcile the team's canonical review skills with disk (perspectives + validation + blind spots
    + the authoring companion).

    Best-effort: a sync failure shouldn't crash the run — the review proceeds with the team's
    existing skills, and the loaders raise a clear error later if one is genuinely missing.
    """
    try:
        await database_sync_to_async(_sync_review_skills, thread_sensitive=False)(input.team_id)
    except Exception:
        logger.exception("Review skill sync failed; continuing with the team's existing review skills")


@activity.defn
@scoped_temporal()
async def generate_schemas_activity(input: GenerateSchemasInput) -> None:
    """Regenerate the prompt output schemas (committed static assets the templates embed).

    Best-effort: on a read-only worker FS the committed schemas are already correct, so a failed
    rewrite shouldn't fail the review.
    """
    try:
        generate_all_schemas()
    except OSError:
        logger.exception("Schema generation failed; using the committed schemas")


# --- Chunking --------------------------------------------------------------------------------------


@activity.defn
@scoped_temporal()
@close_db_connections
async def split_chunks_activity(input: SandboxStageInput) -> list[int]:
    """Split the PR into reviewable chunks (resume-aware); return the chunk ids."""
    existing = await database_sync_to_async(load_chunk_set, thread_sensitive=False)(
        team_id=input.team_id, report_id=input.report_id, head_sha=input.head_sha
    )
    if existing is not None:
        logger.info("Reusing persisted chunk set for this turn")
        await _refresh_status_comment(input.team_id, input.report_id)
        return [chunk.chunk_id for chunk in existing.chunks]

    snapshot = await database_sync_to_async(load_pr_snapshot, thread_sensitive=False)(
        team_id=input.team_id, report_id=input.report_id, head_sha=input.head_sha
    )
    if snapshot is None:
        raise ApplicationError("PR snapshot missing for chunking", non_retryable=True)

    # Small PRs are one coherent review unit: skip the chunking LLM turn (and the per-chunk fan-out it
    # would multiply) and use a single deterministic chunk. Only larger PRs reach the semantic chunker.
    planned = plan_deterministic_chunks(snapshot.pr_files)
    if planned is not None:
        logger.info("PR within the single-chunk size; one deterministic chunk, skipping the chunking LLM turn")
        await database_sync_to_async(persist_chunk_set, thread_sensitive=False)(
            team_id=input.team_id, report_id=input.report_id, head_sha=input.head_sha, chunks=planned
        )
        await _refresh_status_comment(input.team_id, input.report_id)
        return [chunk.chunk_id for chunk in planned.chunks]

    prompt = generate_chunking_prompt(snapshot.pr_metadata, snapshot.pr_comments, snapshot.pr_files)
    # The chunking prompt is fully self-contained (metadata + comments + patches inline), so within
    # the one-shot gate a direct gateway call replaces the sandbox; a PR too large to chunk in one
    # shot keeps the agentic sandbox, which can navigate the repo instead of holding it all at once.
    additions = count_reviewable_additions(snapshot.pr_files)
    use_oneshot = bool(CHUNKING_ONESHOT_MAX_ADDITIONS) and additions <= CHUNKING_ONESHOT_MAX_ADDITIONS
    async with Heartbeater():
        if use_oneshot:
            chunks = await run_oneshot_review(
                team_id=input.team_id,
                user_id=input.user_id,
                prompt=prompt,
                system_prompt=CHUNKING_SYSTEM_PROMPT,
                model_to_validate=ChunksList,
                step_name="chunking",
            )
        else:
            chunks = await run_sandbox_review(
                team_id=input.team_id,
                user_id=input.user_id,
                repository=input.repository,
                branch=input.branch,
                prompt=prompt,
                system_prompt=CHUNKING_SYSTEM_PROMPT,
                model_to_validate=ChunksList,
                step_name="chunking",
                workflow_id_prefix=_sandbox_workflow_id_prefix("chunking"),
                runtime_adapter=CHUNKING_RUNTIME_ADAPTER,
                model=CHUNKING_MODEL,
                reasoning_effort=CHUNKING_REASONING_EFFORT,
            )
    # The LLM's "every file in exactly one chunk" instruction is enforced in code, not trusted:
    # an omitted file would silently skip review in every downstream pass.
    chunks = reconcile_chunks(chunks, snapshot.pr_files)
    await database_sync_to_async(persist_chunk_set, thread_sensitive=False)(
        team_id=input.team_id, report_id=input.report_id, head_sha=input.head_sha, chunks=chunks
    )
    await _refresh_status_comment(input.team_id, input.report_id)
    return [chunk.chunk_id for chunk in chunks.chunks]


# --- Review (perspective × chunk fan-out) ----------------------------------------------------------


def _load_perspectives(team_id: int, acting_user_id: int) -> list[LoadedPerspectiveDTO]:
    return [
        LoadedPerspectiveDTO(
            pass_number=p.pass_number, skill_name=p.skill_name, version=p.version, description=p.description
        )
        for p in load_perspectives_for_run(team_id, acting_user_id)
    ]


@activity.defn
@scoped_temporal()
@close_db_connections
async def load_perspectives_activity(input: LoadPerspectivesInput) -> list[LoadedPerspectiveDTO]:
    """Resolve the acting user's enabled perspectives, pinned to their current versions, for this run."""
    return await database_sync_to_async(_load_perspectives, thread_sensitive=False)(input.team_id, input.acting_user_id)


@activity.defn
@scoped_temporal()
@close_db_connections
async def select_perspectives_activity(input: SelectPerspectivesInput) -> PerspectiveSelectionDTO | None:
    """Pick which perspectives to run per chunk via a one-shot call (resume-aware); None means run everything.

    The selector only judges perspectives whose description it can read (`prunable_perspectives`), so
    a roster with nothing prunable skips the LLM spend entirely. The workflow treats any failure of
    this activity as None too — selection is an optimization and must never cost a review.
    """
    if not prunable_perspectives(input.perspectives):
        return None
    existing = await database_sync_to_async(load_perspective_selection, thread_sensitive=False)(
        team_id=input.team_id, report_id=input.report_id, head_sha=input.head_sha
    )
    if existing is not None:
        logger.info("Reusing persisted perspective selection for this turn")
        return PerspectiveSelectionDTO.from_model(existing)
    snapshot = await database_sync_to_async(load_pr_snapshot, thread_sensitive=False)(
        team_id=input.team_id, report_id=input.report_id, head_sha=input.head_sha
    )
    chunks = await database_sync_to_async(load_chunk_set, thread_sensitive=False)(
        team_id=input.team_id, report_id=input.report_id, head_sha=input.head_sha
    )
    if snapshot is None or chunks is None:
        raise ApplicationError("PR snapshot or chunk set missing for perspective selection", non_retryable=True)
    if not chunks.chunks:
        return None
    prompt = generate_selection_prompt(snapshot.pr_metadata, chunks.chunks, snapshot.pr_files, input.perspectives)
    async with Heartbeater():
        raw = await run_oneshot_review(
            team_id=input.team_id,
            user_id=input.user_id,
            prompt=prompt,
            system_prompt=SELECTION_SYSTEM_PROMPT,
            model_to_validate=PerspectiveSelection,
            step_name="perspective_selection",
        )
    # Persist the normalized plan (exactly what the fan-out runs), not the model's raw output — the
    # progress estimate and the skipped-perspective UI read this artefact as ground truth.
    selection = normalize_selection(input.perspectives, [c.chunk_id for c in chunks.chunks], raw)
    await database_sync_to_async(persist_perspective_selection, thread_sensitive=False)(
        team_id=input.team_id,
        report_id=input.report_id,
        head_sha=input.head_sha,
        roster=[p.skill_name for p in input.perspectives],
        selection=selection,
    )
    await _refresh_status_comment(input.team_id, input.report_id)
    return PerspectiveSelectionDTO.from_model(selection)


def _load_blind_spots_skill(team_id: int, acting_user_id: int) -> LoadedBlindSpotsSkillDTO:
    loaded = load_blind_spots_skill_for_run(team_id, acting_user_id)
    return LoadedBlindSpotsSkillDTO(skill_name=loaded.skill_name, version=loaded.version)


@activity.defn
@scoped_temporal()
@close_db_connections
async def load_blind_spots_skill_activity(input: LoadBlindSpotsInput) -> LoadedBlindSpotsSkillDTO:
    """Resolve the acting user's selected blind-spots skill, pinned to its current version, for this run."""
    return await database_sync_to_async(_load_blind_spots_skill, thread_sensitive=False)(
        input.team_id, input.acting_user_id
    )


def _prepare_review_prompt(
    team_id: int,
    report_id: str,
    head_sha: str,
    chunk_id: int,
    pass_number: int,
    skill_name: str,
    skill_version: int,
    run_index: int,
    blind_spot_check: bool,
    wave_perspectives: list[LoadedPerspectiveDTO],
) -> str | None:
    """Build the review prompt for one (perspective, chunk), or None if already reviewed this turn."""
    done = load_perspective_results(team_id=team_id, report_id=report_id, head_sha=head_sha)
    if (pass_number, chunk_id) in done:
        return None
    snapshot = load_pr_snapshot(team_id=team_id, report_id=report_id, head_sha=head_sha)
    chunks = load_chunk_set(team_id=team_id, report_id=report_id, head_sha=head_sha)
    if snapshot is None or chunks is None:
        raise ApplicationError("PR snapshot or chunk set missing for review", non_retryable=True)
    chunk = next((c for c in chunks.chunks if c.chunk_id == chunk_id), None)
    if chunk is None:
        raise ApplicationError(f"Chunk {chunk_id} not found in chunk set", non_retryable=True)
    prior_findings = load_prior_findings(team_id=team_id, report_id=report_id, before_run_index=run_index)
    # The blind-spot check reads its own chunk's lower-pass wave findings; regular perspective units
    # stay blind to each other (overlap is dedup's job).
    same_turn_findings: list[Issue] = []
    if blind_spot_check:
        for (prior_pass, prior_chunk), review in done.items():
            if prior_chunk == chunk_id and prior_pass < pass_number:
                same_turn_findings.extend(review.issues)
    return build_review_prompt(
        skill_name=skill_name,
        skill_version=skill_version,
        chunk=chunk,
        pr_metadata=snapshot.pr_metadata,
        pr_comments=snapshot.pr_comments,
        pr_files=snapshot.pr_files,
        prior_findings=prior_findings,
        same_turn_findings=same_turn_findings,
        dig_deeper=bool(same_turn_findings),
        blind_spot_check=blind_spot_check,
        wave_perspectives={p.skill_name: p.description for p in wave_perspectives} if blind_spot_check else None,
    )


@activity.defn
@scoped_temporal()
@close_db_connections
async def review_chunk_activity(input: ReviewChunkInput) -> bool:
    """Review one chunk through one perspective (or the blind-spot check) and persist it (idempotent)."""
    prompt = await database_sync_to_async(_prepare_review_prompt, thread_sensitive=False)(
        input.team_id,
        input.report_id,
        input.head_sha,
        input.chunk_id,
        input.pass_number,
        input.skill_name,
        input.skill_version,
        input.run_index,
        input.blind_spot_check,
        input.wave_perspectives,
    )
    if prompt is None:
        return True
    step_name = (
        f"blind-spots-c{input.chunk_id}"
        if input.blind_spot_check
        else f"issues-review-p{input.pass_number}-c{input.chunk_id}"
    )
    # The report's persisted experiment arm, not the module pins. Each unit resolves it against the
    # live registry, so all units of a turn agree unless a deploy deregisters the model mid-turn —
    # which is why experiment teardown drops arms from REVIEW_EXPERIMENT_ARMS, never the registry.
    arm = await database_sync_to_async(load_review_arm, thread_sensitive=False)(
        team_id=input.team_id, report_id=input.report_id
    )
    async with Heartbeater():
        review = await run_sandbox_review(
            team_id=input.team_id,
            user_id=input.user_id,
            repository=input.repository,
            branch=input.branch,
            prompt=prompt,
            system_prompt=REVIEW_SYSTEM_PROMPT,
            model_to_validate=IssuesReview,
            step_name=step_name,
            workflow_id_prefix=_sandbox_workflow_id_prefix(step_name),
            runtime_adapter=arm.runtime_adapter,
            model=arm.model,
            reasoning_effort=arm.reasoning_effort,
            initial_permission_mode=arm.initial_permission_mode,
        )
    # Stamp each issue's perspective (the skill that ran) here, not in combine — it survives the
    # persisted result + resume, and keeps `source_perspective` = skill_name, decoupled from the enum.
    for issue in review.issues:
        issue.source_perspective = input.skill_name
    await database_sync_to_async(persist_perspective_results, thread_sensitive=False)(
        team_id=input.team_id,
        report_id=input.report_id,
        head_sha=input.head_sha,
        results={(input.pass_number, input.chunk_id): review},
    )
    await _refresh_status_comment(input.team_id, input.report_id)
    return True


# --- Combine + scope-clean + dedup -----------------------------------------------------------------


def _combine_and_clean(team_id: int, report_id: str, head_sha: str) -> list[Issue]:
    perspective_results = load_perspective_results(team_id=team_id, report_id=report_id, head_sha=head_sha)
    snapshot = load_pr_snapshot(team_id=team_id, report_id=report_id, head_sha=head_sha)
    pr_files = snapshot.pr_files if snapshot is not None else []
    raw_issues = combine_issues(perspective_results)
    return clean_issues(raw_issues, pr_files)


@activity.defn
@scoped_temporal()
@close_db_connections
async def dedup_activity(input: SandboxStageInput) -> DedupResult:
    """Combine + scope-clean every perspective's issues, deduplicate them, and persist the findings.

    Combine/clean is a local flatten over the persisted perspective results; dedup is a conditional
    single LLM call (one-shot within the gate). Returns only the persisted survivors' ids — later
    stages reload the issue content from the finding rows, so the unbounded issue list never crosses
    a Temporal payload boundary by value.
    """
    issues = await database_sync_to_async(_combine_and_clean, thread_sensitive=False)(
        input.team_id, input.report_id, input.head_sha
    )
    snapshot = await database_sync_to_async(load_pr_snapshot, thread_sensitive=False)(
        team_id=input.team_id, report_id=input.report_id, head_sha=input.head_sha
    )
    if snapshot is None:
        raise ApplicationError("PR snapshot missing for deduplication", non_retryable=True)
    # Prior turns' findings (with rulings) join the dedup gate: a re-found dismissed/below-threshold
    # problem dies here instead of burning another validation turn. Discovery already gets the same
    # set as COVERED_FINDINGS; this is the enforcement backstop when a perspective re-raises anyway.
    prior_findings = await database_sync_to_async(load_prior_findings_with_verdicts, thread_sensitive=False)(
        team_id=input.team_id, report_id=input.report_id, before_run_index=input.run_index
    )
    async with Heartbeater():
        survivors = await deduplicate_issues(
            team_id=input.team_id,
            user_id=input.user_id,
            issues=issues,
            pr_metadata=snapshot.pr_metadata,
            pr_comments=snapshot.pr_comments,
            prior_findings=prior_findings,
            branch=input.branch,
            repository=input.repository,
            workflow_id_prefix=_sandbox_workflow_id_prefix("dedup"),
        )
    issue_ids = await database_sync_to_async(persist_findings, thread_sensitive=False)(
        team_id=input.team_id, report_id=input.report_id, issues=survivors, run_index=input.run_index
    )
    await _refresh_status_comment(input.team_id, input.report_id)
    return DedupResult(issue_ids=issue_ids)


# --- Validate (per-chunk warm-session fan-out) -----------------------------------------------------


def _load_validation_skill(team_id: int, acting_user_id: int) -> LoadedValidationSkillDTO:
    skill = load_validation_skill_for_run(team_id, acting_user_id)
    return LoadedValidationSkillDTO(skill_name=skill.skill_name, version=skill.version)


@activity.defn
@scoped_temporal()
@close_db_connections
async def load_validation_skill_activity(input: LoadValidationInput) -> LoadedValidationSkillDTO:
    """Resolve the acting user's selected validator, pinned to its current version, for this run."""
    return await database_sync_to_async(_load_validation_skill, thread_sensitive=False)(
        input.team_id, input.acting_user_id
    )


def _load_validation_context(
    team_id: int, report_id: str, head_sha: str, chunk_id: int
) -> tuple[Chunk, PRMetadata, list[PRFile]] | None:
    """The chunk + PR metadata + files a chunk's issues are validated against, or None if missing."""
    chunks = load_chunk_set(team_id=team_id, report_id=report_id, head_sha=head_sha)
    snapshot = load_pr_snapshot(team_id=team_id, report_id=report_id, head_sha=head_sha)
    if chunks is None or snapshot is None:
        return None
    chunk = next((c for c in chunks.chunks if c.chunk_id == chunk_id), None)
    if chunk is None:
        return None
    return chunk, snapshot.pr_metadata, snapshot.pr_files


@activity.defn
@scoped_temporal()
@close_db_connections
async def validate_chunk_activity(input: ValidateChunkInput) -> ValidateChunkResult:
    """Validate one chunk's issues in a single warm sandbox session — one verdict per turn.

    The warm session shares the chunk context across turns while each issue keeps its own independent
    verdict (one per turn, never a single batched output). Resume-aware: issues already judged this
    turn are skipped, so a retry re-researches only what's left. A failed turn therefore fails the
    activity to get that cheap retry; only the final attempt skips the issue (continuing on a fresh
    session) so one bad issue can't sink the chunk. Verdicts are the durable output — body + publish
    read them from the DB, not this return value.
    """
    issues = await database_sync_to_async(load_run_issues, thread_sensitive=False)(
        team_id=input.team_id, report_id=input.report_id, run_index=input.run_index, issue_ids=input.issue_ids
    )
    done = await database_sync_to_async(load_run_validations, thread_sensitive=False)(
        team_id=input.team_id, report_id=input.report_id, run_index=input.run_index, issues=issues
    )
    pending = [issue for issue in issues if issue.id not in done]
    if not pending:
        return ValidateChunkResult(chunk_id=input.chunk_id, validated_count=len(done))

    context = await database_sync_to_async(_load_validation_context, thread_sensitive=False)(
        input.team_id, input.report_id, input.head_sha, input.chunk_id
    )
    if context is None:
        raise ApplicationError("PR snapshot or chunk set missing for validation", non_retryable=True)
    chunk, pr_metadata, pr_files = context

    validated = len(done)
    final_attempt = activity.info().attempt >= VALIDATION_MAX_ATTEMPTS
    session: MultiTurnSession | None = None
    chunk_ok = False
    try:
        async with Heartbeater():
            for issue in pending:
                issue_files = [f for f in pr_files if f.filename == issue.file]
                try:
                    if session is None:
                        session, validation = await start_sandbox_session(
                            team_id=input.team_id,
                            user_id=input.user_id,
                            repository=input.repository,
                            branch=input.branch,
                            prompt=build_validation_prompt(
                                issue=issue,
                                chunk=chunk,
                                skill_name=input.skill_name,
                                skill_version=input.skill_version,
                                pr_metadata=pr_metadata,
                                pr_files=issue_files,
                            ),
                            system_prompt=VALIDATION_SYSTEM_PROMPT,
                            model_to_validate=IssueValidation,
                            step_name=f"validation-c{input.chunk_id}",
                            workflow_id_prefix=_sandbox_workflow_id_prefix(f"validation-c{input.chunk_id}"),
                            runtime_adapter=VALIDATION_RUNTIME_ADAPTER,
                            model=VALIDATION_MODEL,
                            reasoning_effort=VALIDATION_REASONING_EFFORT,
                            initial_permission_mode=VALIDATION_INITIAL_PERMISSION_MODE,
                        )
                    else:
                        validation = await continue_sandbox_session(
                            session,
                            prompt=build_validation_followup_prompt(issue=issue, pr_files=issue_files),
                            model_to_validate=IssueValidation,
                            label=issue.id,
                        )
                except Exception:
                    if session is None:
                        # Session never opened (sandbox-level) — raise so Temporal retries the chunk
                        # and the failure floor catches a real outage, not just one bad issue.
                        raise
                    if not final_attempt:
                        # Fail the chunk so Temporal retries it; skip-resume keeps the retry cheap.
                        logger.exception("Validation turn failed for issue %s; failing the chunk to retry it", issue.id)
                        raise
                    # Out of retries — skip this issue (no verdict → not posted) and give the rest
                    # a fresh session; this one may be wedged after the failed turn.
                    logger.exception("Validation turn failed for issue %s on the final attempt; skipping it", issue.id)
                    await end_sandbox_session(
                        session, status="failed", error=f"validation turn failed for issue {issue.id}"
                    )
                    session = None
                    continue
                wrote = await database_sync_to_async(persist_verdict, thread_sensitive=False)(
                    team_id=input.team_id,
                    report_id=input.report_id,
                    issue=issue,
                    validation=validation,
                    run_index=input.run_index,
                )
                if wrote:
                    validated += 1
        chunk_ok = True
    finally:
        # On an exception in flight (turn failure → chunk retry), record the session as failed so
        # the TaskRun isn't counted as completed; only a cleanly finished loop ends as completed.
        if session is not None:
            await end_sandbox_session(
                session,
                status="completed" if chunk_ok else "failed",
                error=None if chunk_ok else "validation chunk failed mid-session",
            )
    await _refresh_status_comment(input.team_id, input.report_id)
    return ValidateChunkResult(chunk_id=input.chunk_id, validated_count=validated)


# --- Build body + finalize + publish ---------------------------------------------------------------


def _build_and_finalize(input: BuildBodyInput) -> None:
    issues = load_run_issues(
        team_id=input.team_id, report_id=input.report_id, run_index=input.run_index, issue_ids=input.issue_ids
    )
    # Verdicts come from the DB (the same rows publish reads), so a partially-failed chunk shows the
    # same findings in the body and the posted comments.
    validations = load_run_validations(
        team_id=input.team_id, report_id=input.report_id, run_index=input.run_index, issues=issues
    )
    # The reviewed diff decides which valid findings can't be anchored inline — the body surfaces those
    # in an "Other findings" section (the same snapshot publish positions inline comments against).
    snapshot = load_pr_snapshot(team_id=input.team_id, report_id=input.report_id, head_sha=input.head_sha)
    pr_files = snapshot.pr_files if snapshot is not None else []
    body = build_review_body(
        issues=issues,
        validations=validations,
        pr_files=pr_files,
        published_priorities=published_priorities_for(IssuePriority(input.urgency_threshold)),
    )
    finalize_review_report(
        team_id=input.team_id,
        report_id=input.report_id,
        body_markdown=body,
        run_index=input.run_index,
        head_sha=input.head_sha,
        # The same snapshot the body above and the publish gate consume — stamped so the detail view
        # buckets this turn's findings by the gate that actually ran.
        urgency_threshold=input.urgency_threshold,
        will_publish=input.will_publish,
    )


@activity.defn
@scoped_temporal()
@close_db_connections
async def build_body_activity(input: BuildBodyInput) -> None:
    """Render the review body and finalize the turn (store the body, bump the run watermark)."""
    await database_sync_to_async(_build_and_finalize, thread_sensitive=False)(input)


def _publish(input: PublishInput) -> PublishResult:
    token, installation_id = _installation_auth(input.team_id, f"{input.owner}/{input.repo}")
    outcome = publish_persisted_review(
        team_id=input.team_id,
        report_id=input.report_id,
        head_sha=input.head_sha,
        run_index=input.run_index,
        owner=input.owner,
        repo=input.repo,
        pr_number=input.pr_number,
        token=token,
        urgency_threshold=IssuePriority(input.urgency_threshold),
        installation_id=installation_id,
    )
    return PublishResult(posted=outcome.posted, review_url=outcome.review_url)


@activity.defn
@scoped_temporal()
@close_db_connections
async def publish_review_activity(input: PublishInput) -> PublishResult:
    """Publish the review to GitHub (DB-driven).

    The per-run publish gate lives in the workflow (`inputs.publish`): this activity is dispatched
    only when publishing is enabled and the turn has a PR to post to.
    """
    return await database_sync_to_async(_publish, thread_sensitive=False)(input)


def _remove_trigger_label(input: RemoveTriggerLabelInput) -> None:
    token, installation_id = _installation_auth(input.team_id, f"{input.owner}/{input.repo}")
    try:
        github_api_request(
            "DELETE",
            f"/repos/{input.owner}/{input.repo}/issues/{input.pr_number}/labels/reviewhog",
            token=token,
            endpoint="/repos/{owner}/{repo}/issues/{issue_number}/labels/{name}",
            installation_id=installation_id,
        )
    except GitHubAPIError as error:
        if error.status != 404:
            raise


@activity.defn
@scoped_temporal()
@close_db_connections
async def remove_trigger_label_activity(input: RemoveTriggerLabelInput) -> None:
    """Remove the label that started a label-triggered review, if it is still present."""
    await database_sync_to_async(_remove_trigger_label, thread_sensitive=False)(input)


def _review_event_identity(report: ReviewReport) -> str:
    # Acting user when resolved and carrying a distinct_id, else the team — the same attribution
    # the TaskRun analytics use.
    acting_distinct_id = report.acting_user.distinct_id if report.acting_user is not None else None
    return str(acting_distinct_id) if acting_distinct_id else str(report.team.uuid)


def _review_arm_properties(report: ReviewReport) -> dict[str, str | bool]:
    """The model-experiment labels on every review analytics event (the model name is the arm).

    Resolved, not raw: pre-experiment rows carry NULLs but their reviews run on the default pins,
    and the event must say what actually ran.
    """
    persisted = (
        report.review_runtime_adapter,
        report.review_model,
        report.review_reasoning_effort,
        report.review_initial_permission_mode,
    )
    arm = resolve_review_arm(*persisted)
    resolved = (arm.runtime_adapter.value, arm.model, arm.reasoning_effort.value, arm.initial_permission_mode)
    return {
        "review_runtime_adapter": arm.runtime_adapter.value,
        "review_model": arm.model,
        "review_reasoning_effort": arm.reasoning_effort.value,
        # True when a persisted assignment failed resolution and the turn ran the fallback pins
        # instead of its drawn arm; per-arm dashboards must exclude these contaminated turns.
        # The whole bundle is compared because a failed assignment can share the default arm's model
        # string while differing on adapter or effort. Pre-experiment rows (all NULL) stay False.
        "review_arm_fallback": any(persisted) and resolved != persisted,
    }


def _track_review_completed(input: TrackReviewCompletedInput) -> None:
    report = ReviewReport.objects.for_team(input.team_id).select_related("acting_user", "team").get(id=input.report_id)
    findings = load_turn_findings(team_id=input.team_id, report_id=input.report_id, run_index=input.run_index)
    snapshot = load_pr_snapshot(team_id=input.team_id, report_id=input.report_id, head_sha=input.head_sha)
    pr_meta = snapshot.pr_metadata if snapshot is not None else None
    duration_seconds = round(
        (
            datetime.datetime.now(tz=datetime.UTC) - datetime.datetime.fromisoformat(input.workflow_started_at)
        ).total_seconds(),
        1,
    )
    # Validator-wins severity mix of the valid findings, the same fold the review body renders with.
    valid_by_priority = Counter(
        effective_priority(finding.priority, verdict.adjusted_priority)
        for finding, verdict in findings
        if verdict is not None and verdict.is_valid
    )
    posthoganalytics.capture(
        distinct_id=_review_event_identity(report),
        event="reviewhog_review_completed",
        # Deterministic per turn: an activity retry that re-captures after a worker crash emits the
        # same event uuid, so ingestion dedupes it instead of double-counting the review.
        uuid=str(uuid.uuid5(uuid.NAMESPACE_URL, f"reviewhog_review_completed:{input.report_id}:{input.run_index}")),
        properties={
            "report_id": str(report.id),
            "team_id": report.team_id,
            "repository": report.repository,
            "pr_number": report.pr_number,
            "run_index": input.run_index,
            "trigger_source": report.trigger_source,
            "author_login": report.author_login,
            "published": input.published,
            "findings_total": len(findings),
            "findings_valid": sum(1 for _, verdict in findings if verdict is not None and verdict.is_valid),
            "findings_must_fix": valid_by_priority.get(IssuePriority.MUST_FIX, 0),
            "findings_should_fix": valid_by_priority.get(IssuePriority.SHOULD_FIX, 0),
            "findings_consider": valid_by_priority.get(IssuePriority.CONSIDER, 0),
            **_review_arm_properties(report),
            # PR size as fetched for this turn; None when the turn's snapshot is unavailable.
            "pr_additions": pr_meta.additions if pr_meta is not None else None,
            "pr_deletions": pr_meta.deletions if pr_meta is not None else None,
            "pr_changed_files": pr_meta.changed_files if pr_meta is not None else None,
            "pr_commits": pr_meta.commits if pr_meta is not None else None,
            # Added lines ReviewHog actually reviews (lockfiles/tests/generated filtered out) —
            # the honest denominator for per-line cost.
            "pr_reviewable_additions": count_reviewable_additions(snapshot.pr_files) if snapshot is not None else None,
            "duration_seconds": duration_seconds,
        },
        groups=groups(team=report.team),
        send_feature_flags=True,
    )


def _track_review_completed_safe(input: TrackReviewCompletedInput) -> None:
    # Analytics must never fail a review: any load/capture failure is logged, not raised.
    try:
        _track_review_completed(input)
    except Exception:
        logger.exception("Failed to capture reviewhog_review_completed for report %s; continuing", input.report_id)


@activity.defn
@scoped_temporal()
@close_db_connections
async def track_review_completed_activity(input: TrackReviewCompletedInput) -> None:
    """Capture the turn's `reviewhog_review_completed` product-analytics event.

    One event per finalized turn (published or stored), across every trigger and repo — the
    per-review count product dashboards aggregate, which the step-level `task_*` events can't
    provide (one review fans out into many sandbox tasks). Best-effort: analytics must never fail
    a review, so any failure is logged, not raised.
    """
    await database_sync_to_async(_track_review_completed_safe, thread_sensitive=False)(input)


def _track_review_failed(input: TrackReviewFailedInput) -> None:
    report = ReviewReport.objects.for_team(input.team_id).select_related("acting_user", "team").get(id=input.report_id)
    posthoganalytics.capture(
        distinct_id=_review_event_identity(report),
        event="reviewhog_review_failed",
        # Deterministic per turn, like the completed event: repeated failures of the same turn (a
        # re-trigger that dies again before finalize bumps run_count) dedupe to one event, so
        # completion rate counts turns, not attempts.
        uuid=str(uuid.uuid5(uuid.NAMESPACE_URL, f"reviewhog_review_failed:{input.report_id}:{input.run_index}")),
        properties={
            "report_id": str(report.id),
            "team_id": report.team_id,
            "repository": report.repository,
            "pr_number": report.pr_number,
            "run_index": input.run_index,
            "trigger_source": report.trigger_source,
            "author_login": report.author_login,
            **_review_arm_properties(report),
        },
        groups=groups(team=report.team),
        send_feature_flags=True,
    )


def _track_review_failed_safe(input: TrackReviewFailedInput) -> None:
    # Analytics must never mask the review's original error: any load/capture failure is logged.
    try:
        _track_review_failed(input)
    except Exception:
        logger.exception("Failed to capture reviewhog_review_failed for report %s; continuing", input.report_id)


@activity.defn
@scoped_temporal()
@close_db_connections
async def track_review_failed_activity(input: TrackReviewFailedInput) -> None:
    """Capture the turn's `reviewhog_review_failed` product-analytics event.

    The completed event alone hides failures: a run that dies never emits it, so an arm of the
    reviewer-model experiment that crashes on its hardest PRs would silently shed them from every
    per-review metric. This event is the denominator's other half, but do NOT naively sum event
    counts: the parent workflow retry makes fail-then-complete at the same (report_id, run_index)
    common, so a turn counts as failed only when it has a failed event and NO completed event
    (anti-join on report_id + run_index). Best-effort, like the completed event.
    """
    await database_sync_to_async(_track_review_failed_safe, thread_sensitive=False)(input)


# --- The PR's live status comment -------------------------------------------------------------------


@activity.defn
@scoped_temporal()
@close_db_connections
async def post_status_comment_activity(input: StatusCommentInput) -> None:
    """Post (or reset) the PR's "review in progress" status comment at run kickoff.

    Dispatched only on the publish path once every gate has passed. Best-effort inside
    (`ensure_status_comment` swallows failures), so it can't fail the review.
    """
    await database_sync_to_async(ensure_status_comment, thread_sensitive=False)(input.team_id, input.report_id)


@activity.defn
@scoped_temporal()
@close_db_connections
async def finalize_status_comment_activity(input: FinalizeStatusCommentInput) -> None:
    """Rewrite the status comment with the turn's outcome: full found counts vs. what was published."""
    await database_sync_to_async(finalize_status_comment, thread_sensitive=False)(input)


def _fail_run(team_id: int, report_id: str) -> None:
    # The idle write comes first so a GitHub failure below can't skip it: on publishing runs
    # finalize defers going idle to the publish stage, so a run dying between finalize and publish
    # would otherwise sit ACTIVE (reading as in-progress in the UI) until the staleness cutoff.
    ReviewReport.objects.for_team(team_id).filter(id=report_id).update(status=ReviewReport.Status.IDLE)
    fail_status_comment(team_id, report_id)


@activity.defn
@scoped_temporal()
@close_db_connections
async def fail_status_comment_activity(input: StatusCommentInput) -> None:
    """Return the dead run's report to rest and rewrite the status comment as failed.

    The idle write lives in this activity rather than as its own workflow command so in-flight
    histories replay unchanged (new unconditional commands break replay determinism).
    """
    await database_sync_to_async(_fail_run, thread_sensitive=False)(input.team_id, input.report_id)


# --- The signals report's code_review receipt --------------------------------------------------------

# `IssuePriority` values map 1:1 onto the CodeReviewCounts fields (the enum mirrors the threshold choices).
_COUNT_FIELD_BY_PRIORITY = {
    IssuePriority.MUST_FIX: "must_fix",
    IssuePriority.SHOULD_FIX: "should_fix",
    IssuePriority.CONSIDER: "consider",
}


def _append_code_review_artefact(input: AppendCodeReviewArtefactInput) -> None:
    report = ReviewReport.objects.for_team(input.team_id).filter(id=input.review_report_id).first()
    if report is None:
        logger.warning("ReviewReport %s missing; skipping the code_review artefact", input.review_report_id)
        return
    # The signals report may be gone by now (deleted/reingested) — the review must not fail over its
    # own receipt, and the plain-UUID provenance on the ReviewReport row keeps the durable link.
    if not SignalReport.objects.filter(team_id=input.team_id, id=input.signal_report_id).exists():
        logger.warning("Signal report %s missing; skipping the code_review artefact", input.signal_report_id)
        return
    counts = CodeReviewCounts()
    for finding, verdict in load_valid_findings(
        team_id=input.team_id, report_id=input.review_report_id, run_index=input.run_index
    ):
        field_name = _COUNT_FIELD_BY_PRIORITY.get(effective_priority(finding.priority, verdict.adjusted_priority))
        if field_name is not None:
            setattr(counts, field_name, getattr(counts, field_name) + 1)
    content = CodeReview(
        review_report_id=str(report.id),
        repository=report.repository,
        head_sha=report.head_sha or "",
        head_branch=report.head_branch,
        base_branch=report.base_branch,
        pr_number=report.pr_number,
        pr_url=report.pr_url or None,
        review_url=input.review_url,
        outcome=input.outcome,
        counts=counts,
    )
    SignalReportArtefact.add_log(
        team_id=input.team_id,
        report_id=input.signal_report_id,
        content=content,
        attribution=ArtefactAttribution.system(),
    )


@activity.defn
@scoped_temporal()
@close_db_connections
async def append_code_review_artefact_activity(input: AppendCodeReviewArtefactInput) -> None:
    """Append this turn's `code_review` receipt to the signals report's artefact log.

    Pointer-first (counts + links + `review_report_id`); the full body stays on
    `ReviewReport.report_markdown`. Best-effort: the signals report may have been deleted/reingested
    since the run started, and a review must never fail over its own receipt — so any failure is
    logged, not raised.
    """
    try:
        await database_sync_to_async(_append_code_review_artefact, thread_sensitive=False)(input)
    except Exception:
        logger.exception(
            "Failed to append the code_review artefact to signal report %s; continuing", input.signal_report_id
        )
