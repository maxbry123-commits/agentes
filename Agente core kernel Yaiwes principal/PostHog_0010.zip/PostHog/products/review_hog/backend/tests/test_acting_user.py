from posthog.test.base import BaseTest

from parameterized import parameterized
from social_django.models import UserSocialAuth

from products.review_hog.backend.models import ReviewReport, ReviewUserSettings
from products.review_hog.backend.temporal.activities import ResolveActingUserInput, _resolve_acting_user
from products.review_hog.backend.temporal.types import TRIGGER_LABEL, TRIGGER_MANUAL

_SELF = "SELF"


class TestResolveActingUser(BaseTest):
    def setUp(self) -> None:
        super().setUp()
        UserSocialAuth.objects.create(user=self.user, provider="github", uid="gh-1", extra_data={"login": "OctoCat"})

    @parameterized.expand(
        [
            # An explicit override (CLI/eval) wins regardless of the author — resolution is skipped.
            ("override_wins", "nobody", 4321, 4321),
            # The PR author maps to the org user, case-insensitively.
            ("maps_author", "octocat", None, _SELF),
            ("maps_author_mixed_case", "OCTOCAT", None, _SELF),
            # No PostHog org user for the author (or no author) → None, so the parent skips the review.
            ("unmapped_author", "ghost", None, None),
            ("empty_author", "", None, None),
        ]
    )
    def test_resolve_acting_user(self, _name: str, author: str, override: int | None, expected: object) -> None:
        result = _resolve_acting_user(
            ResolveActingUserInput(team_id=self.team.id, author_login=author, override_user_id=override)
        )
        assert result.acting_user_id == (self.user.id if expected == _SELF else expected)

    def test_settings_default_when_user_has_no_row(self) -> None:
        # No settings row → the resolve result carries the MODEL defaults (labeled reviews on, inbox
        # reviews off, consider, resolution on), so every validated finding publishes — and reviews
        # chain resolution — for users who never opened the UI. resolve_comments is the opposite of
        # its DATACLASS default (False, the replay-safe skip value), so dropping its passthrough
        # line would silently disable the resolution stage for everyone with the suite still green.
        result = _resolve_acting_user(
            ResolveActingUserInput(team_id=self.team.id, author_login="octocat", override_user_id=None)
        )
        assert result.review_labeled_prs is True
        assert result.review_inbox_prs is False
        assert result.urgency_threshold == "consider"
        assert result.resolve_comments is True

    def test_settings_row_flows_into_the_result(self) -> None:
        # The user's saved settings must reach the workflow — if resolve stops loading any of them,
        # the gates and publish silently revert to defaults. review_inbox_prs is set to the OPPOSITE
        # of its dataclass default: dropping its one passthrough line would silently disable the
        # entire inbox trigger for every opted-in user with the whole suite still green.
        ReviewUserSettings.objects.for_team(self.team.id).create(
            team_id=self.team.id,
            user_id=self.user.id,
            review_labeled_prs=False,
            review_inbox_prs=True,
            urgency_threshold=ReviewUserSettings.UrgencyThreshold.MUST_FIX,
            resolve_comments=False,
        )
        result = _resolve_acting_user(
            ResolveActingUserInput(team_id=self.team.id, author_login="octocat", override_user_id=None)
        )
        assert result.review_labeled_prs is False
        assert result.review_inbox_prs is True
        assert result.urgency_threshold == "must_fix"
        # The opt-out must reach the workflow — hardwiring the snapshot on would strip users of the
        # only lever that stops reviews from writing to their PRs.
        assert result.resolve_comments is False

    def test_label_trigger_falls_back_to_the_run_user(self) -> None:
        # Unmapped author on a labeled PR → the run user the trigger already resolved, passed
        # through as default_user_id so acting and sandbox identity can never drift.
        result = _resolve_acting_user(
            ResolveActingUserInput(
                team_id=self.team.id,
                author_login="ghost",
                override_user_id=None,
                trigger_source=TRIGGER_LABEL,
                default_user_id=self.user.id,
            )
        )
        assert (result.acting_user_id, result.resolved_from) == (self.user.id, "default")

    def test_non_label_triggers_keep_the_author_only_contract(self) -> None:
        result = _resolve_acting_user(
            ResolveActingUserInput(
                team_id=self.team.id,
                author_login="ghost",
                override_user_id=None,
                trigger_source=TRIGGER_MANUAL,
                default_user_id=self.user.id,
            )
        )
        assert result.acting_user_id is None

    def test_labeled_opt_out_protects_authors_but_never_travels_with_a_borrowed_user(self) -> None:
        # self.user is both the mapped author (octocat) and the run-user fallback.
        ReviewUserSettings.objects.for_team(self.team.id).create(
            team_id=self.team.id, user_id=self.user.id, review_labeled_prs=False, resolve_comments=False
        )
        # Acting as the author: their own opt-outs apply (the workflow will skip / stop at publish).
        as_author = _resolve_acting_user(
            ResolveActingUserInput(
                team_id=self.team.id, author_login="octocat", override_user_id=None, trigger_source=TRIGGER_LABEL
            )
        )
        assert (as_author.resolved_from, as_author.review_labeled_prs) == ("author", False)
        assert as_author.resolve_comments is False
        # Acting as the borrowed run user on someone else's PR: the same row must NOT kill the
        # review, nor switch off resolution for a PR that isn't theirs (the default posture applies).
        as_default = _resolve_acting_user(
            ResolveActingUserInput(
                team_id=self.team.id,
                author_login="ghost",
                override_user_id=None,
                trigger_source=TRIGGER_LABEL,
                default_user_id=self.user.id,
            )
        )
        assert (as_default.acting_user_id, as_default.resolved_from) == (self.user.id, "default")
        assert as_default.review_labeled_prs is True
        assert as_default.resolve_comments is True

    def test_urgency_threshold_follows_personal_sources_but_never_a_borrowed_default_user(self) -> None:
        # The publish-gate twin of the opt-out rule above: the run user's saved must_fix threshold
        # must not decide what lands on someone ELSE's PR — a default-resolved run gates at the
        # built-in default. Personal resolutions (author, requester override) keep the saved value.
        ReviewUserSettings.objects.for_team(self.team.id).create(
            team_id=self.team.id, user_id=self.user.id, urgency_threshold=ReviewUserSettings.UrgencyThreshold.MUST_FIX
        )
        as_author = _resolve_acting_user(
            ResolveActingUserInput(
                team_id=self.team.id, author_login="octocat", override_user_id=None, trigger_source=TRIGGER_LABEL
            )
        )
        assert (as_author.resolved_from, as_author.urgency_threshold) == ("author", "must_fix")
        as_override = _resolve_acting_user(
            ResolveActingUserInput(
                team_id=self.team.id, author_login="ghost", override_user_id=self.user.id, trigger_source=TRIGGER_LABEL
            )
        )
        assert (as_override.resolved_from, as_override.urgency_threshold) == ("override", "must_fix")
        as_default = _resolve_acting_user(
            ResolveActingUserInput(
                team_id=self.team.id,
                author_login="ghost",
                override_user_id=None,
                trigger_source=TRIGGER_LABEL,
                default_user_id=self.user.id,
            )
        )
        assert (as_default.resolved_from, as_default.urgency_threshold) == ("default", "consider")

    def test_resolve_stamps_the_acting_user_onto_the_report(self) -> None:
        # "Your recent reviews" filters on this stamp — if resolve stops writing it, the list goes empty.
        report = ReviewReport.objects.for_team(self.team.id).create(
            team_id=self.team.id,
            repository="PostHog/posthog",
            pr_number=7,
            pr_url="https://github.com/PostHog/posthog/pull/7",
            head_branch="feat",
            base_branch="main",
        )
        _resolve_acting_user(
            ResolveActingUserInput(
                team_id=self.team.id, author_login="octocat", override_user_id=None, report_id=str(report.id)
            )
        )
        report.refresh_from_db()
        assert report.acting_user_id == self.user.id
