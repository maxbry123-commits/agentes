# ReviewHog Architecture

## Overview

**ReviewHog** (`products/review_hog`) is an automated GitHub PR code reviewer. It is a Django app
(`backend/apps.py`, label `review_hog`, module `products.review_hog.backend`). A run fetches a PR from
GitHub, splits it into logically reviewable **chunks**, picks which perspectives each chunk actually needs
(**perspective selection**, a cheap one-shot), runs the selected **perspective reviews in parallel** on each
chunk inside **sandbox agents**, then combines → scope-cleans → deduplicates → validates the findings, renders
a markdown report, and posts inline review comments back to the PR. Each review **perspective** (Logic &
Correctness, Contracts & Security, Performance & Reliability) is a DB-synced **LLMA skill** the sandbox agent
pulls over MCP — the same canonical-skill pattern the Signals scouts use.

The repo-access LLM steps (perspective review, blind-spot check, validation) run inside **sandbox agents**
spawned through the shared `products/tasks` infrastructure (`Task`/`TaskRun` → Temporal
`ProcessTaskWorkflow` → Modal/Docker sandbox → agent-server) — ReviewHog composes a prompt, hands it to the
Tasks runner, and gets back the validated model, owning no sandbox/Temporal code. The pure-text steps
(**chunking, perspective selection, dedup**) run within size gates as **one-shot direct LLM-gateway calls**
(`reviewer/sandbox/direct_llm.py`, structured outputs against the same pydantic models; chunking/dedup fall
back to the sandbox above their gates, selection falls back to running everything). Run state is persisted to
Postgres (`ReviewReport` + `ReviewReportArtefact`) — there is **no on-disk store**; the only external side
effect is the GitHub review it posts.

This document is the present-tense architecture reference — what ReviewHog _is today_. Its companion
**[DECISIONS.md](./DECISIONS.md)** is the full record of _why_ it got there: the staged build history, the
design decisions (with the alternatives weighed and rejected), the gotchas, the grounded implementation maps,
and the roadmap — including the designed-but-unbuilt loop. Nothing is summarized away; go there to check the
reasoning behind any part of this reference. [Status & next](#status--next) below is a short summary of what's
in flight, with the detail in DECISIONS.md.

> **Keep the docs in sync, each in its lane.** This reference is the source of truth for ReviewHog's
> architecture — the pipeline shape, the sandbox/contract surface it binds to in `products/tasks`, the data
> models, the prompts, the artefact layout. A merge or refactor that moves or renames what ReviewHog depends on
> is exactly such a change: re-point the affected sections here, don't leave them stale. Land the reasoning,
> build history, and roadmap updates in [DECISIONS.md](./DECISIONS.md) — that's the record that grows over time,
> so this reference stays lean and present-tense. Don't let the build log grow back into this file.

---

## Status & next

ReviewHog runs end-to-end: label / UI / inbox triggers → the Temporal pipeline → published PR review. The
current focus is productionizing the reviewer-topology eval and tightening the finder/validator balance
(validator strictness, fewer junk candidates, the coverage gap); the **loop** — a living, multi-turn review that
re-checks on new commits/comments and implements fixes — is designed but not built. The single-turn pipeline
below is its per-turn body. The **resolution stage** — a post-review, standalone-capable stage that triages every
unresolved review thread and implements the worth-and-safe ones directly on the PR branch — is **built and
live-qualified** (e2e on its own PR #72074, 2026-07-18 — verdicts, findings, and the GO call in
`eval/experiments/2026-07-resolution-e2e/FINAL_REPORT.md`): `ResolvePRWorkflow` (`backend/temporal/resolution.py`) drives one warm writable sandbox
session per PR (one thread per turn, humans → ReviewHog → other bots), persists per-thread `thread_verdict`
artefacts on the living report, replies/resolves server-side from verdicts (bot threads only; humans keep the
final word). A FIXED verdict's echoed commit SHA is verified server-side before delivery (`commit_on_branch`);
an unproven SHA posts the reply without the commit link and never auto-resolves. A real commit is then checked
against the hard-floor **path backstop** (`commit_restricted_paths`): one touching `.github/`, CODEOWNERS, or
dependency manifests delivers a human-review warning instead of the link and never auto-resolves either.

**TODO (BLOCKING — before any rollout beyond the dogfood team / public release) — the three remaining
injection-surface hardening items from the July e2e GO conditions.** The path backstop above is built; these
are deliberately deferred (maintainer decisions 2026-08-06 and 2026-08-10, recorded in DECISIONS.md Stage 7)
and MUST land before the resolution stage runs on PRs the team does not own:

1. **Structural comment rendering** — thread comments still render as flat text in the resolution prompt, so a
   commenter can forge an "OWNER" header or a fake "SAFE TO FIX" verdict inside their own comment
   (`tools/thread_resolution.py::render_thread`). Fix: JSON-encode the conversation like the review stage's
   `PR_COMMENTS` (and decide whether to expose the real comment `databaseId` as ground truth). Prompt-content
   change → validate with a live e2e run.
2. **Author-permission gate** — no code rule restricts whose comment may drive a write turn; the policy is the
   hard part (review bots and external contributors both carry `author_association: NONE`, so a naive filter
   drops exactly the bot threads the stage exists to resolve). Decide which associations may drive write turns
   and how trusted bots stay in scope. The same policy must cover **standing-verdict overrides**: today a
   "SAFE TO FIX" reply from any non-bot account substitutes for the worth judgment with no association gate,
   so the thread's own low-trust asker can wave their own ask through the worth bar (safety bar and hard
   floors still apply).
3. **Pre-push restricted-paths enforcement** — the path backstop is detection, not prevention: GitHub's
   `createCommitOnBranch` makes commit and push one atomic act, so a fix commit touching `.github/`, CODEOWNERS,
   or dependency manifests is already on the PR branch (and CI is already running it) before
   `commit_restricted_paths` looks. The guard must move into the signed-commit tooling itself, before the
   mutation fires — a cross-product change (desktop agent package `signed-git-tool` / `signed-commit.ts` plus
   the Tasks facade threading the policy in, plus a sandbox image rebuild), which is why it is a gate rather
   than a fix in this repo.

**Reviewing includes resolving**: a published review chains into the stage when the acting user's
`resolve_comments` setting is on (default on; the toggle sits with the trigger opt-outs on the Code review scene,
which also carries a single-active resolution-criteria skill block and a split Review button with
review-without-resolving / resolve-only side actions). Standalone entry: `POST /api/review_hog/resolve`, the
`run_resolution` command, or the UI's resolve-only action. Standalone runs without a pinned acting user apply
the PR author's resolution criteria (canonical for unmapped authors). Design + decision record: DECISIONS.md
Stage 7; vocabulary: CONTEXT.md; the live-e2e qualification plan (the resolver fixes its own PR):
`eval/experiments/2026-07-resolution-e2e/PLAN.md`.

**Resolution visibility & the busy-guard** (grilled 2026-08-13, DECISIONS.md "Resolution-stage visibility & cycle guard"; ADR `adr/0001`):
a run opens with a `resolution_run` work-list artefact (queued thread ids + counts) written by `_prepare_run`,
and `reviewer/progress.py::resolution_states` derives the run's state from artefacts alone —
resolving (delivered verdicts — `reply_posted` — counted against the queue, fresh activity), completed (a closing run note, author `RESOLUTION_RUN_NOTE_AUTHOR`), or died-partway (no note, stale).
The PR-comment counters likewise count only threads whose GitHub writes landed (`delivered_outcomes`); judged-but-undelivered threads join the closing tally's "couldn't handle" count instead.
The reviews API exposes it as the row's `resolution` field ("Resolving comments · 6/10" / "Resolution didn't finish · stopped at 6/10" in the scene),
the PR status comment carries a marker-delimited resolution section (`update_resolution_status_comment` — spliced into the review's comment, created on demand for standalone runs, failure-edited on the final attempt),
with a patched workflow-level backstop (`fail_resolution_activity`, fired from `ResolvePRWorkflow`'s except) covering the deaths the activity handler can't see — prepare failures, timeouts, cancellation, worker death — by idling the report and writing the failed section from the persisted work-list,
and each queued thread's opening comment gets a best-effort 👀 reaction (queue marker; never removed).
The **busy-guard** (`temporal/client.py::workflow_running`, fail-open describe on the deterministic ids) refuses a review start while the PR's `resolve-pr` runs and a standalone resolution while `review-pr` runs —
Temporal's same-id joining can't see across the two workflows; the chained post-publish dispatch is exempt by construction.

**TODO (SOON) — react to thread replies: answer and act when a human responds to an escalated (or any settled) thread.**
The per-thread mechanics already exist and are e2e-proven: a new human comment beats the verdict watermark and
re-opens triage for exactly that thread, standing verdicts ("SAFE TO FIX" / "E2E REQUIRED") steer the re-judged
outcome, and everything else skips at zero cost. What's missing is the **trigger**: nothing starts a resolution
run when the reply lands, so today the conversation only advances when someone runs `run_resolution` / the
resolve-only action. Build the comment trigger — a `pull_request_review_comment` (created) event → the existing
trigger API → `start_resolution_workflow` for that PR (debounced; skip when the commenter is ReviewHog itself,
mirroring the label-trigger Action) — so replying to an escalation gets an actual answer: implement on a go-ahead,
decline-and-say-why on a disagreement, re-escalate with the new context otherwise. Mind the known blind spot: the
work-list only fetches **unresolved** threads, so replies on already-resolved (FIXED) threads are invisible —
the trigger should either unresolve-on-human-reply or the fetch must include threads with comments newer than
their verdict watermark (see the resolution e2e's F-findings).

**TODO — make resolution replies concise.** The e2e's escalation replies are three-paragraph walls no human
will read (see the `/resolve` acting-user thread on #72074). The prompt asks for "a self-contained answer the
author can act on without opening the code" and the model over-delivers; the deep detail already has a home in
`reasoning` (the work log). Add a hard reply shape to `thread_resolution.py`'s prompt: verdict first in one
sentence, then at most 2–3 short supporting lines (for an escalation: exactly what a human must decide);
everything else stays in `reasoning`.

**TODO (later thoughts, cost) — let the resolver lean on the validator's work.** For ReviewHog's own threads the
report already holds a researched `validation_verdict` per finding (argumentation, category, adjusted priority) —
yet the resolution turn starts from just the thread text and re-investigates the same code cold in an
opus-xhigh sandbox (~$1/turn in the e2e). No clear task yet; directions when this gets picked up: join a bot
thread back to its finding + verdict and put that argumentation in the turn prompt as a head start, and see
whether that shortens turns or lets bot-thread turns run a cheaper tier while human threads keep the full
treatment.

**TODO — check whether the reviewers sweep too wide, and how to move them closer to the validation bar.**
The resolution e2e's review leg found 55 raw issues, dedup kept 48, and the validator kept **12** — a 75% kill
rate, with every raw `must_fix` downgraded on the way through. Either the finders are paying for breadth the
validator just throws away (wasted sandbox spend + validation load), or wide-then-strict is the correct division
of labor and the funnel is healthy. Decide with data, not taste: measure per-perspective precision (share of a
perspective's finds that survive validation — the e2e run splits 12 survivors as security 4 / logic 3 /
blind-spot 3 / performance 2), then try pulling the validation-criteria bar into the perspective skills
themselves (the reviewer reads the same skill the validator applies, so it self-filters before emitting) and
compare survivor count, coverage, and cost against the wide baseline. Ties into the topology-experiment
conclusion that skill content + validator strictness — not topology — is the binding constraint.

The full roadmap — every open thread with its reasoning, the loop design, the grounded implementation maps, and
the experiment backlog — is in [DECISIONS.md](./DECISIONS.md) (start at its "🎯 NEXT" section) and `eval/`
(`RUN_LOG.md`, `POTENTIAL_EXPERIMENTS.md`, `experiments/`).

**Before real users:** settle the "ReviewHog Alpha" published-comment wording (see
[Known issues](#known-issues--tech-debt)), and land the three BLOCKING resolution-stage hardening TODOs above
(structural comment rendering + author-permission gate + pre-push restricted-paths enforcement) — they gate any
rollout beyond the dogfood team.

---

## Preflight — is everything ready for a local review?

Check these four things before a local `run_review`; don't re-derive them from code each time.

1. **Temporal worker up** — the dev-stack (phrocs) process `temporal-worker` must be `running`
   (phrocs MCP `get_process_status`, or the `hogli` TUI). It hot-reloads via nodemon on any
   `products/**/*.py` edit — **never start a second worker** (it dies on port 8001 already-in-use).
   The `backend` process must be running too.
2. **ngrok tunnels up** (only the user can start ngrok): `curl -s http://localhost:4040/api/tunnels`
   must list all three — `django` → :8010, `gateway` → :3308 (LLM gateway), `mcp` → :8787.
   Without them the Modal sandboxes can't reach the local backend / gateway / MCP.
   A tunnel can be up while its local service is down: the `llm-gateway` process can crash at stack
   boot (exit 127), which shows as HTTP 502 on the gateway tunnel while django/mcp answer 200.
   Probe all three from Modal's network, and on a 502 check the process in phrocs and restart it —
   the tunnel itself is fine.
3. **Target PR is reviewable** — non-fork (fork PRs are rejected at fetch) and open. Drafts ARE
   reviewed and published (there is no draft gate) — warn the user before publishing on someone's
   draft. Private repos outside PostHog work: fetch, clone, and publish all resolve the team's
   GitHub App installation token per repo server-side, so any repo the integration's installation
   can access is reviewable. The PR's reviewable additions count picks the chunking path: ≤400 single chunk (no
   chunking LLM), ≤5000 one-shot LLM chunking, above that sandbox chunking (slowest).
4. **Prior state** — check for an existing report so you know whether this is a fresh r1 or a
   re-review (same-SHA re-runs no-op at publish via the marker + `published_head_sha`):

   ```bash
   PGPASSWORD=posthog psql -h localhost -p 5432 -d posthog -U posthog -c \
     "SELECT pr_number, status, run_count, head_sha, published_head_sha \
      FROM review_hog_reviewreport WHERE repository='PostHog/posthog' AND pr_number=<N> AND team_id=1;"
   ```

Run it (no `GITHUB_TOKEN` env — fetch and publish resolve the team's GitHub App installation token
server-side; publishing is opt-in per run via `--publish`):

```bash
flox activate -- bash -c "DJANGO_SETTINGS_MODULE=posthog.settings python manage.py \
  run_review --pr-url https://github.com/PostHog/posthog/pull/<N> --team-id 1 --user-id 1 [--publish]"
```

Verify a run: `review_hog_reviewreport.run_count` bumps once per finalized turn (status returns to
`idle`), or inspect activity-level progress in Temporal:

```bash
docker exec posthog-temporal-1 tctl --address temporal:7233 --ns default workflow show \
  --workflow_id "review-pr:<team>:<owner>/<repo>:<pr>"
```

**Stall check — confirm the sandboxes are alive after the fan-out.** Within ~15–20 minutes of the
perspective wave starting, the ngrok request log (`curl -s "http://localhost:4040/api/requests/http?limit=5"`,
or the ngrok terminal dashboard) must show task fetches from the sandboxes. Open `issues-review`
process-task workflows with **zero** tunnel traffic means the sandboxes never started — the worker
can wedge before sandbox provisioning while its heartbeat signals keep flowing, so Temporal looks
alive and artefact-count polling can't tell "slow agents" from "nothing running" (perspective units
normally finish in ~8–15 min). A run in that state does not recover on its own: restart the
temporal worker (via phrocs). The fresh worker retries the stuck activities, and the
head_sha-scoped DB resume makes the redo cheap.

---

## Pipeline

The orchestration is a Temporal workflow: `ReviewPRWorkflow` (`backend/temporal/workflow.py`) drives the setup
activities → two fan-out **child workflows** (perspective review / validate) → finishing activities, each stage an
activity in `backend/temporal/activities.py`. Only small values cross boundaries (`report_id` + `head_sha` + unit
keys / JSON issue slices); every activity reloads its inputs from the per-turn `pr_snapshot` artefact, so no big
payload hits Temporal's ~2 MiB cap. State persists to Postgres (`ReviewReport` + `ReviewReportArtefact`); there is
**no on-disk store**. Each fan-out child bounds its per-unit sandbox activities with a fresh
`asyncio.Semaphore(MAX_CONCURRENT_SANDBOXES)` (`constants.py`) + `gather(return_exceptions=True)` — there is no
module-level semaphore. The expensive, turn-stable sandbox stages (chunk / perspective review) are **idempotent via
a head_sha-scoped DB resume** — a re-run reuses their rows instead of re-calling the sandbox; dedup recomputes,
while validation resumes per issue off its persisted verdicts (`load_run_validations`). The validator runs one warm
multi-turn session per chunk (one verdict per turn); there is **no separate analyze stage** (the reviewer
self-investigates from the diff + the PR intent).

Visual flow (this compact diagram is the only one — a full-detail `ARCHITECTURE_DIAGRAM.mmd` existed and was
deleted deliberately; every attempt to keep it readable and current failed, so don't recreate it):

```mermaid
flowchart TD
    PR["PR URL"] --> FETCH["1. Fetch PR data (GitHub API)"]
    FETCH --> SCHEMA["2. Generate JSON schemas from Pydantic models"]
    SCHEMA --> CHUNK{{"3. Chunk PR (single chunk ≤400 adds; one-shot ≤5k, else sandbox)"}}
    CHUNK --> SELECT{{"4. Select perspectives per chunk (one-shot, fail-open → dense)"}}
    SELECT --> L1{{"5a. Perspective — Logic & Correctness"}}
    SELECT --> L2{{"5b. Perspective — Contracts & Security"}}
    SELECT --> L3{{"5c. Perspective — Performance & Reliability"}}
    L1 --> BLIND{{"6. Blind-spot sweep (1/chunk, told which lenses succeeded)"}}
    L2 --> BLIND
    L3 --> BLIND
    BLIND --> DEDUP{{"7. Dedup (combine + scope-clean local; pre-filter + one-shot ≤50 candidates, else sandbox; drops prior comments' and prior turns' re-finds)"}}
    DEDUP --> VALIDATE{{"8. Per-chunk validation (warm session, parallel)"}}
    VALIDATE --> MD["9. Build review body + finalize (DB)"]
    MD --> PUBLISH["10. Publish PR review (GitHub API, DB-driven)"]
```

### Step-by-step (as orchestrated by `ReviewPRWorkflow`)

1. **Parse PR URL** — `PRParser.parse_github_pr_url` regex-extracts `owner/repo/pr_number`; raises on a
   malformed URL.
2. **Fetch PR data** — `PRFetcher(owner, repo, pr_number, token, installation_id).fetch_pr_data()`
   (`tools/github_meta.py`, GitHub REST via the gated egress transport — see `tools/github_client.py`;
   `token` is the team's GitHub App installation token, resolved server-side in the activity — no env `GITHUB_TOKEN`)
   returns `(pr_metadata, pr_comments, pr_files, diff)` **in-process** — no files. The fetch activity rejects fork PRs
   (`PRMetadata.is_fork`) non-retryably before opening the report. The
   `diff` is the reviewed files' raw unified patch (the point-in-time snapshot). Lockfiles, minified assets,
   snapshots, `*.schema.py`, `*.txt`, build dirs, and test files are filtered out. `branch =
pr_metadata.head_branch` is threaded (as explicit kwargs, alongside `team_id` / `user_id`) into every sandbox
   activity — there is no ContextVar identity. The team's GitHub integration is validated up front by
   `validate_github_integration_activity`; `upsert_review_report` opens the living `ReviewReport`, and
   `persist_commit_snapshot(…, diff=…)` records this turn's snapshot (gated on the `head_sha` watermark).
3. **Generate schemas** — `generate_all_schemas()` materializes `Model.model_json_schema()` for the five
   LLM-facing models into `prompts/<stage>/schema.json` (static package assets, **not** per-run state); the
   prompt templates embed these. Must run before any prompt rendering.
4. **Chunk the PR** — `split_pr_into_chunks` (1 LLM call, validates `ChunksList`) groups changed files
   into logically reviewable chunks ordered by review priority. Within
   `CHUNKING_ONESHOT_MAX_ADDITIONS` (5000 reviewable added lines) the call is a **one-shot gateway call**
   (`run_oneshot_review`, Sonnet 5 @ xhigh, structured outputs — the prompt embeds metadata + comments +
   patches inline, so no repo access is needed); above the gate it stays a sandbox call, pinned to the
   same Sonnet 5 @ xhigh via the `CHUNKING_*` constants (identical prompt — the sandbox only adds repo
   access the agent may not use). Returns the
   `ChunksList`; persists a `chunk_set` row (and resumes from it on a re-run of the same head).
5. **Parallel perspective review** — `review_chunks` runs **three independent specialist perspectives
   concurrently** per chunk (one sandbox activity per `(perspective × chunk)`, bounded by the child workflow's `asyncio.Semaphore`),
   each with **no cross-perspective context** — overlap is left to dedup (7):
   - **Logic & Correctness** (`PerspectiveType.LOGIC_CORRECTNESS`)
   - **Contracts & Security** (`PerspectiveType.CONTRACTS_SECURITY`)
   - **Performance & Reliability** (`PerspectiveType.PERFORMANCE_RELIABILITY`)

   The three perspectives come from the ordered `PERSPECTIVES` registry (`reviewer/skill_loader.py`);
   `load_perspectives_for_run(team_id)` pins each one's current `LLMSkill` version for the run. Delivery is
   **pull** — the prompt instructs the sandbox agent to `skill-get(review-hog-perspective-…, version=N)` over
   MCP and apply that perspective's focus, rather than splicing the focus text into the prompt. Each
   perspective×chunk is one sandbox call validating `IssuesReview` (step name `issues-review-p{pass}-c{chunk}`);
   the reviewer self-investigates the chunk from the diff + `<pr_intent>` (no separate analysis pass is fed in).
   Returns `dict[(pass, chunk), IssuesReview]`; persists/resumes per-pair `perspective_result` rows. (The `pass`
   ordinal = the perspective's 1-based position in `PERSPECTIVES`.) A **blind-spot sweep** then runs once per
   chunk under a reserved pass number, told which lenses already ran, to catch what none of them surfaced.

6. **Combine + scope-clean** — `combine_issues(perspective_results)` flattens every perspective×chunk `Issue`
   (stamping `source_perspective` from the ordinal), then `clean_issues(issues, pr_files)` drops issues whose
   file/lines don't overlap the PR diff. Both pure, in-process.
7. **Deduplicate** — `deduplicate_issues(issues, pr_metadata, pr_comments, …)` first runs a **deterministic
   positional pre-filter** (`_select_dedup_candidates`): only issues sharing a file + overlapping lines with
   another issue or **any prior inline comment** can be duplicates, so isolated issues survive **without** an LLM
   call (and a zero-candidate run skips the LLM entirely). Colliding candidates go to the single LLM dedupe call
   (`IssueDeduplication`) — a **one-shot gateway call** within `DEDUP_ONESHOT_MAX_FINDINGS` (50 issues entering
   dedup; the prompt is pure text), the sandbox path above it pinned to the same Sonnet 5 @ xhigh via the
   `DEDUP_*` constants — which also drops findings any prior inline
   comment already raised — every reviewer (bot
   or human, ReviewHog's own included) treated uniformly, the author handle passed through for context.
   Returns the canonical post-dedup `list[Issue]`; `persist_findings` mirrors them to
   `issue_finding` rows.
8. **Validate** — the `ValidateIssuesWorkflow` child groups the survivors by chunk and fans out **one warm
   multi-turn session per chunk** (concurrent across chunks, bounded by its `asyncio.Semaphore`):
   `validate_chunk_activity` opens one sandbox, validates the chunk's issues as **sequential turns (one verdict per
   turn)**, and persists each `validation_verdict` row via `persist_verdict` (paired to findings by `issue_key`).
   **Resume-aware:** `load_run_validations` splits the chunk's issues into already-judged / pending, so a retry
   re-researches only the pending ones. The keep/drop **criteria are pulled, not baked**: the prompt instructs the
   agent to `skill-get` the team's `review-hog-validation-criteria` skill (version pinned by
   `load_validation_skill_for_run`), so the bar for "this issue matters" is team-owned, like the perspectives.
9. **Build report + finalize** — `build_review_body(issues, validations, pr_files)` renders the public body
   in-process (verdicts sourced from the DB via `load_run_validations`, the same rows publish reads). The body is
   **one line: how many findings this turn publishes, by severity** ("Found **2 must fix**, **1 consider**.") —
   no chunk walk, no file inventory, no summary of the diff, because nobody reads one. Valid `MUST_FIX`/`SHOULD_FIX`
   findings whose line isn't on the diff are still appended as an **"Other findings (outside the changed lines)"**
   section so they aren't silently dropped at publish.
   `finalize_review_report` stores it as `ReviewReport.report_markdown` and bumps the run watermark. On
   publishing runs it **defers the idle write** to the publish stage — the report stays `active` through
   stage 10, `publish_persisted_review` returns it to `idle` on every outcome, and the failure activity
   restores rest on a dead run — so the reviews API never reports a completed-but-unpublished turn as at
   rest (the UI's poll would stop on that snapshot and freeze a wrong "Not published"). Non-publishing
   runs go `idle` at finalize; `progress_payload` labels the deferred window "finalizing".
10. **Publish** — `publish_review` (GitHub REST via the gated egress transport, **DB-driven**) reads the body from
    `ReviewReport.report_markdown` and the inline comments from the valid finding/verdict rows (`load_valid_findings`),
    posts a standalone "ReviewHog Alpha 🦔" feedback comment, then a PR review (`event="COMMENT"`, **pinned to the
    reviewed `head_sha`** via `commit_id`) with inline comments for `is_valid` `MUST_FIX`/`SHOULD_FIX` findings that
    land on a line present in the current diff (`CONSIDER` dropped). It posts whenever there's ≥1 valid publishable
    finding — if all are off-diff (no inline comments resolve) the body still posts, carrying them in the
    Other-findings section, so a review is never dropped wholesale. Falls back to a body-only review when
    posting with inline comments fails. Authenticates with the team's installation token. Gated **per run** by `inputs.publish` (the workflow only dispatches this stage
    when publishing is on); the eval CLI defaults it off, the label trigger sets it on. Both publish-idempotency
    marker scans (`_review_already_posted` here, `_find_marker_comment` on the status comment) trust the marker
    only in **app-bot** comments/reviews — on a public repo anyone can paste it, and a spoofed match would
    suppress the publish or clobber a stranger's comment. On the publish path a live **status comment**
    (`reviewer/status_comment.py`) is posted at kickoff, edited with stage progress, and rewritten with the
    outcome: the full found counts, what was published, and — when the urgency threshold held findings back —
    whose threshold it was (the author's / the requester's / the default, from `resolved_from`) plus a
    "View them in PostHog" deep link to the exact report (`/project/<team>/code-review?review=<report id>`,
    a **permanent public contract** — the frontend URL sync and `report_deep_link` must keep agreeing on it).
    After the publish stage the workflow captures a **`reviewhog_review_completed`** product-analytics event —
    one per finalized turn (published or stored), carrying repository / PR / trigger / finding-count / PR-size
    properties (`track_review_completed_activity`). Best-effort: telemetry can never fail a review.

---

## Sandbox execution layer

Most LLM work funnels through one helper, `run_sandbox_review(...)`, in `backend/reviewer/sandbox/executor.py`.
The single-turn steps (issues review, plus chunking/deduplication above their one-shot gates) call it with a
prompt, the Pydantic model to validate against, and a `step_name`. Validation instead drives a **warm multi-turn
session** per chunk via the sibling helpers `start_sandbox_session` / `continue_sandbox_session` /
`end_sandbox_session` (one verdict per turn). The sandbox-free counterpart for the gated chunking/dedup calls is
`run_oneshot_review(...)` in `backend/reviewer/sandbox/direct_llm.py` (same call shape minus
`repository`/`branch`; one gateway Messages call, structured outputs, no sandbox).

Every sandbox opened here lands in the `posthog-sandbox-self-driving` Modal app rather than the default one,
because its tasks carry `origin_product=REVIEW_HOG` (see `SELF_DRIVING_ORIGIN_PRODUCTS` in
`products/tasks/backend/logic/services/sandbox.py`). ReviewHog owns no sandbox code, so this needs nothing here:
the app is resolved inside the Tasks provisioning activity. Same image and resources as any other run — the split
only separates the fleet's Modal cost from user-driven runs.

`run_sandbox_review(team_id, user_id, repository, branch, prompt, system_prompt, model_to_validate, step_name) -> Model | None`:

1. Does **not** own concurrency — the caller bounds it: each fan-out child workflow wraps its per-unit sandbox
   activities in a fresh `asyncio.Semaphore(MAX_CONCURRENT_SANDBOXES)` (`constants.py`). The old module-level
   `_sandbox_semaphore` was removed in the Temporal migration.
2. Concatenates `full_prompt = f"{system_prompt}\n\n{prompt}"` — there is no separate system role; the agent
   receives one combined prompt.
3. Builds a `CustomPromptSandboxContext` **inline** from the explicit `team_id` / `user_id` / `repository` it
   receives — there is no ContextVar identity (the migration deleted `bind_sandbox_identity` /
   `_sandbox_context_for`). `team_id` / `user_id` are threaded as explicit activity inputs from the entry point —
   the `run_review` `--team-id` / `--user-id` CLI args, or the production trigger (the PR's author + their team).
   The team's `kind="github"` `Integration` is validated up front by a separate
   `validate_github_integration_activity`, not here.
4. Spawns the agent via `_run_prompt(...)` → **`MultiTurnSession.start(prompt, context, model=…, branch, step_name)`**
   (imported from the Tasks facade `products.tasks.backend.facade.agents`; impl at
   `products.tasks.backend.logic.services.custom_prompt_multi_turn_runner`). `start` runs the agent **and
   validates its end-of-turn JSON against `model_to_validate` internally**, returning `(session, model)`. On
   success the caller **`session.end()`s** (the runner keeps the workflow/sandbox alive between turns, so a
   single-turn caller must end it) and returns the validated model; on a sandbox error or a parse/validation
   failure `start` ends its own session and raises, so the helper logs and returns **`None`**. There is no
   `output_path` / `_error.txt` and no manual JSON extraction — persistence is the caller's job. The runner
   persists the full agent log at `task_run.log_url` (S3 / Tasks UI), so the executor never copies it locally.

The perspective review (the blind-spot sweep rides the same activity) runs on a different model family than the
rest — **OpenAI Codex `gpt-5.6-sol` @ `xhigh`**, with `initial_permission_mode="full-access"`. The pins are per
**report**, not per process: each `ReviewReport` persists a **review arm** (adapter / model / effort / permission
mode), drawn once at report creation from the weighted `REVIEW_EXPERIMENT_ARMS` (`constants.py`; currently the
single default arm above) and kept for the report's life, so a model A/B never mixes arms within one report.
`load_review_arm` → `resolve_review_arm` honors a persisted assignment only while it stays a registry-supported
combo — anything else falls back to the default pins and stamps `review_arm_fallback` on the run's analytics
events — so reports assigned an arm that later left the lineup keep running it while its combo stays registered.
Chunking, dedup, and the validator stay on Claude. See [DECISIONS.md](./DECISIONS.md) for the Sonnet-vs-Sol
production A/B that picked this default (and the `full-access` permission-mode gotcha headless Codex needs), and
[Selecting the sandbox model & reasoning effort](#selecting-the-sandbox-model--reasoning-effort) below for the
two-repo path that applies these knobs.

`backend/reviewer/sandbox/code_context.py` is pure-local: `prepare_code_context(chunk_filenames, pr_files)`
emits Claude-Code-style `@path#Lstart-end` references for the changed line ranges of each file (merging
adjacent ranges), so the agent reads exactly the changed lines. These are embedded into the prompts.

### Downstream chain (owned by `products/tasks`, current `master`)

```python
run_sandbox_review (executor.py)
  → imports MultiTurnSession / CustomPromptSandboxContext
      from products.tasks.backend.facade.agents   (facade re-export; impl under logic/services/)
  → MultiTurnSession.start(model=…)       (logic/services/custom_prompt_multi_turn_runner.py)
    → create_task_and_trigger             (logic/services/custom_prompt_internals.py)
      → Task.create_and_run(..., create_pr=False, mode="background", branch=…)
        → Temporal ProcessTaskWorkflow
          → get_sandbox_for_repository activity
            → Sandbox.create() (Modal default; Docker when SANDBOX_PROVIDER=docker)
            → clone_repository(...)  +  git fetch --depth 1 origin <branch> && git checkout -B <branch> FETCH_HEAD
          → agent-server runs the prompt, streams JSONL (ACP session/update) to S3 (TaskRun.log_url)
  → start() polls S3 for the end-of-turn message, parses + validates against the model internally
  → returns (session, model); caller ends the session and returns the model (None on failure)
```

The PR-branch checkout that ReviewHog depends on is performed by master's
`get_sandbox_for_repository.py` block (driven by `ctx.branch`, which originates from `TaskRun.branch`), **not**
by ReviewHog. The contract surface ReviewHog binds to — **imported only through the Tasks facade
`products.tasks.backend.facade.agents`** (Tasks is an isolated product; `tach` enforces the boundary) and
that any future merge must preserve: `MultiTurnSession.start(prompt, context, model, *, branch, step_name)
-> (session, model)`, `CustomPromptSandboxContext(team_id, user_id, repository)`, and `session.end()`.

### Selecting the sandbox model & reasoning effort

Read this before testing another model (Sonnet, a new Codex model, a different effort). It is a **two-repo path**:
`posthog/posthog` _sets_ the knobs and the `@posthog/agent` package _applies_ them. A pinned run is three values —
`runtime_adapter` + `model` + `reasoning_effort`; `provider` is _derived_ from the adapter (`claude → anthropic`,
`codex → openai`), never set by hand.

**`posthog/posthog` — where the knobs are set + validated.**

- **Pick the values (ReviewHog):** `reviewer/constants.py` `REVIEW_{RUNTIME_ADAPTER,MODEL,REASONING_EFFORT,INITIAL_PERMISSION_MODE}`
  feed `DEFAULT_REVIEW_ARM`; `review_chunk_activity` loads the report's persisted arm (`load_review_arm` →
  `resolve_review_arm`) and passes it as kwargs to `run_sandbox_review` (`reviewer/sandbox/executor.py`), which
  threads them onto the `CustomPromptSandboxContext`. To change the reviewer fleet-wide, change the pins; to A/B
  another model, add a weighted arm to `REVIEW_EXPERIMENT_ARMS` (the executor kwargs exist for every single-turn stage).
- **The registry (source of truth for what's allowed)** — `products/tasks/backend/temporal/process_task/utils.py`,
  re-exported framework-free from the facade `products/tasks/backend/facade/run_config.py` (import from the facade):
  `RuntimeAdapter` (`claude|codex`), `LLMProvider`, `ReasoningEffort`, `RUNTIME_PROVIDER_BY_ADAPTER`,
  `CLAUDE_REASONING_EFFORTS_BY_MODEL`, `CODEX_MODELS` + `CODEX_REASONING_EFFORTS` + the
  `CODEX_XHIGH/MAX_REASONING_MODELS` tiers (`gpt-5.5` caps at `xhigh`; the `gpt-5.6-*` models allow up to
  `max`), and the pure checks `get_provider_for_runtime_adapter` /
  `get_supported_reasoning_efforts` / `get_reasoning_effort_error`. A new model/effort must be added here or the combo
  is rejected. `test_constants.py` locks the ReviewHog combo to this registry at unit time.
- **Transport into the sandbox:** `Task._build_task` writes `extra_state[{runtime_adapter, provider, model,
reasoning_effort}]` → `get_task_processing_context` reads it back → `start_agent_server` →
  `build_agent_runtime_env_prefix` (`logic/services/sandbox.py`) emits
  `POSTHOG_CODE_{RUNTIME_ADAPTER,PROVIDER,MODEL,REASONING_EFFORT}` env prefixed onto the agent launch command.

**`@posthog/agent` — where they are consumed + applied** (the PostHog Desktop monorepo, _not_ this repo; clone via
`LOCAL_POSTHOG_CODE_MONOREPO_ROOT`, package `packages/agent`, baked into `Dockerfile.sandbox-base`).

- **Entry `src/server/bin.ts`** reads + zod-validates `POSTHOG_CODE_{RUNTIME_ADAPTER,MODEL,REASONING_EFFORT}`, guards
  with `isSupportedReasoningEffort` (`src/adapters/reasoning-effort.ts` — the agent-side mirror of the Python
  registry; hard-errors server startup on an unsupported combo), then constructs the `AgentServer`.
- **Adapter split `src/server/agent-server.ts`:** Codex → `src/adapters/codex/spawn.ts::buildConfigArgs` pushes
  `-c model="…"` **and** `-c model_reasoning_effort="…"` onto the Codex CLI (this is the line that applies `xhigh` to
  `gpt-5.6-sol`); Claude → `buildClaudeCodeSessionMeta` sets `options.model` + `options.effort` (effort only for the
  claude adapter). `agent.ts` fetches the gateway model allow-list and **silently drops the model if it isn't served**
  (`sanitizedModel` / `allowedModelIds`), so a typo'd/unavailable model falls back to a default rather than erroring —
  verify `$ai_model` on every run when switching.

**Recipe — testing e.g. Sonnet.** Set `runtime_adapter = "claude"`, `model` a key in `CLAUDE_REASONING_EFFORTS_BY_MODEL`,
and an effort that model supports; provider auto-derives to `anthropic`. For a new Codex model: `runtime_adapter =
"codex"`, `model` in `CODEX_MODELS`, effort in `CODEX_REASONING_EFFORTS` (`xhigh`/`max` only for models in the
`CODEX_XHIGH/MAX_REASONING_MODELS` tiers). A brand-new model/effort must be added to the registry in **both** repos (`utils.py`
here + `reasoning-effort.ts` / the gateway model list in `@posthog/agent`) or startup validation rejects it on one side.

---

## Data models

All Pydantic. `models/__init__.py` is the authoritative registry that generates the five LLM-facing
`schema.json` files from `Model.model_json_schema()` — **`schema.json` files are generated artifacts; edit
the model and regenerate, never hand-edit.**

| Model                                                                        | File                             | Schema-backed?                    | Role                                                                                                                                       |
| ---------------------------------------------------------------------------- | -------------------------------- | --------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------ |
| `ChunksList` / `Chunk` / `FileInfo`                                          | `models/split_pr_into_chunks.py` | ✅ chunking                       | PR → reviewable chunks (`chunk_type`, `key_changes`)                                                                                       |
| `Issue` / `IssuesReview` / `LineRange` / `IssuePriority` / `PerspectiveType` | `models/issues_review.py`        | ✅ issues_review (`IssuesReview`) | **`Issue` is the shared currency** of the dedup → validate → publish stages; `Issue.source_perspective` records which perspective found it |
| `IssueDeduplication` / `DuplicateIssue`                                      | `models/issue_deduplicator.py`   | ✅ issue_deduplicator             | ids of issues to drop                                                                                                                      |
| `IssueValidation`                                                            | `models/issue_validation.py`     | ✅ issue_validation               | `is_valid` + `category` (+ optional `adjusted_priority`) per issue                                                                         |
| `PRMetadata` / `PRComment` / `PRFile` / `PRFileUpdate`                       | `models/github_meta.py`          | — internal                        | raw GitHub ingestion                                                                                                                       |

`Issue.id` encodes provenance as `"{pass_number}-{chunk_id}-{issue_number}"` and is parsed back throughout
the pipeline to route validations. `IssuePriority` is `MUST_FIX` / `SHOULD_FIX` /
`CONSIDER`. The validator may override a finding's priority via `adjusted_priority` (validator-wins, resolved at
read time by `effective_priority`); see [DECISIONS.md](./DECISIONS.md).

---

## Prompts

Under `backend/reviewer/prompts/`, one directory per LLM stage, each with `prompt.jinja` + (generated)
`schema.json`. All prompts embed their schema via `{{ ... | safe }}` and demand "Return ONLY the JSON
content". Most begin with `{{ CLAUDE_CODE_CONTEXT | safe }}` (the `@path#L…` references).

- `chunking/prompt.jinja` — group changed files into logical, independently reviewable chunks by cohesion /
  imports / layer boundaries; order by review priority. → `ChunksList`.
- `issues_review/prompt.jinja` — the core review prompt, run once per perspective per chunk; 10-step process
  with mandatory codebase investigation. The per-perspective focus is **no longer spliced in** — the
  `<your_review_perspective>` block instructs the agent to `skill-get(PERSPECTIVE_SKILL_NAME, version=N)` over
  MCP and apply that perspective's focus (pull delivery). → `IssuesReview`. The perspective focuses themselves
  live as **DB-synced LLMA skills** at
  `products/review_hog/skills/review-hog-perspective-{logic-correctness,contracts-security,performance-reliability}/SKILL.md`.
- `issue_deduplicator/prompt.jinja` — mark duplicates (same file + overlapping lines + similar root cause)
  and issues matching prior review comments; keep the single most comprehensive representative. →
  `IssueDeduplication`.
- `issue_validation/prompt.jinja` — validate one issue against the live codebase; "DO NOT implement fixes,
  ONLY assess." **Criteria-agnostic**: a `<your_validation_criteria>` block tells the agent to
  `skill-get(review-hog-validation-criteria, version=N)` over MCP and apply that team-owned bar for the keep/drop
  (`is_valid`) decision — default bar: keep real user-affecting correctness / security / data-loss / contract /
  performance issues; drop overengineering, speculation, defensive paranoia, never-gonna-happen edges, and style.
  The criteria live as a DB-synced LLMA skill at
  `products/review_hog/skills/review-hog-validation-criteria/SKILL.md`. → `IssueValidation`.

A separate **blind-spots** skill (`skills/review-hog-blind-spots-general/SKILL.md`) drives the per-chunk sweep;
it is pull-delivered the same way. The perspective / validation / blind-spot skills are all team-owned and
customizable — see [DECISIONS.md](./DECISIONS.md) (the customizable-perspectives / per-user-enablement sections).
The invariant that keeps this safe: **the output schema is fixed (code), only the skill body (logic) is editable**,
so editing a skill can never change the output format the downstream pipeline depends on. Customs arrive two
ways from the Code review scene: "Create your own" (an authoring agent task guided by the `review-hog-authoring`
skill) and "Use an existing skill" — an **adopted skill**, a verbatim copy of any team skill duplicated under the
kind's prefix and activated in one flow (copy-not-reference; see `adr/0002`).

---

## Persistence (Postgres — no on-disk store)

There is **no `reviews/<pr>/` tree**. A run's state is in-process within the workflow and
mirrored to Postgres on `ReviewReport` / `ReviewReportArtefact`.
Per-run state by kind:

- **Fetch outputs** (`pr_metadata`, `pr_comments`, `pr_files`) — in-process return values, never persisted
  (re-fetchable from GitHub). The reviewed unified `diff` rides back as a string and becomes the per-turn
  **`commit`** artefact (the durable point-in-time snapshot).
- **Working state** (the resume substrate, head_sha-scoped): `chunk_set`, `perspective_result`, and the
  `pr_snapshot` artefacts. The raw/cleaned/combined issue sets are in-process values down the
  combine→clean→dedup chain.
- **Outputs:** `issue_finding` + `validation_verdict` artefacts (the canonical findings/verdicts) and
  `ReviewReport.report_markdown` (the rendered review body) + the `head_sha` / `last_seen_comment_id`
  watermark.
- **Prompts / agent logs:** rendered in-process and sent to the sandbox; the full prompt + conversation is in
  the S3 agent log at `task_run.log_url` (the executor never copies it locally). Generated `prompts/<stage>/schema.json`
  are static package assets in the source tree, not per-run state.

**Data model** (`products/review_hog/backend/models.py`). Both models are **fail-closed team-scoped** (CLAUDE.md
IDOR rule) via `class X(UUIDModel, TeamScopedRootMixin)`:

- **`ReviewReport`** — the living per-PR document, unique on `(team, repository, pr_number)` (the idempotency
  key, so re-runs append turns rather than create a new report; branch-only targets key on
  `(team, repository, head_branch) WHERE pr_number IS NULL`). Carries `status` (`active`/`idle`/`closed`),
  `run_count`, `last_run_at`, the `head_sha` + `last_seen_comment_id` watermark, `published_head_sha`, the
  rendered `report_markdown`, `acting_user`, `author_login` (the PR author's GitHub login, refreshed from the
  fetched metadata every turn — powers the "For you" scope's authored-PRs match), `run_urgency_threshold` (the
  gate the last **completed** turn's body/publish ran under, stamped at finalize alongside `run_count` — what
  the drawer buckets findings by; null for pre-column turns), the persisted review arm
  (`review_runtime_adapter` / `review_model` / `review_reasoning_effort` / `review_initial_permission_mode`,
  drawn once at creation — see [Sandbox execution layer](#sandbox-execution-layer)), and the
  `signal_report_id` / `trigger_source` provenance.
- **`ReviewReportArtefact`** — the append-only work log mirroring `SignalReportArtefact`, with a funnel that
  derives `type` from the content-model class and maps `ArtefactAttribution` → `created_by_id` / `task_id`.
  `ArtefactType`: `issue_finding`, `validation_verdict`, `task_run`, `commit`, `code_reference`, `note`, plus
  the working-state types `chunk_set`, `perspective_result`, `perspective_selection`, `pr_snapshot`.

Content schemas (`reviewer/artefact_content.py`, pydantic): `ReviewIssueFinding` and `ValidationVerdict` are
ReviewHog-owned; `Commit` / `CodeReference` / `TaskRunArtefact` / `NoteArtefact` are reused from the Signals leaf.
See [DECISIONS.md](./DECISIONS.md) for the "reuse the leaf, own the model" boundary and why a PR review is not a
`SignalReport`.

---

## Entry point, commands & configuration

- **Run a review:** `python manage.py run_review --pr-url <github_pr_url> --team-id <id> --user-id <id>`
  (`backend/management/commands/run_review.py`, blocking `execute_review_pr_workflow`, default no-publish, with an
  optional `--publish`). All three args are required.
  - **Default local-testing PR:** an **origin-branch** PR — its head branch must live on `PostHog/posthog`,
    because the sandbox clones the **base** repo and checks out the head branch **by name**
    (`get_sandbox_for_repository`, owned by `products/tasks`), so a **fork** PR fails at the checkout step. Until
    the sandbox learns to fetch `refs/pull/N/head`, test against origin-branch PRs.
- **Publish a computed review without recomputing:** `python manage.py publish_review --pr-url <url> --team-id <id>`
  publishes the latest completed turn at its reviewed `head_sha` (DB-driven; no Temporal, no sandbox).
- **Reset local state:** `DEBUG=1 python manage.py reset_review_hog [--dry-run] [--yes]` wipes all ReviewHog rows
  across every team (DEBUG-only; GitHub comments untouched).
- **Enable inbox reviews for a whole team:** `python manage.py enable_inbox_reviews --team-id <id> [--dry-run]`
  upserts every active org member's `ReviewUserSettings` with `review_inbox_prs` + `stamphog_review_inbox_prs` on.
  A deliberate operator action because the per-user default stays off (the budget gate); members who join later
  keep the default until a re-run.
- **Lint:** `ruff check products/review_hog/ --fix && ruff format products/review_hog/`
- **Tests:** the product's `backend:test` script covers **both** `backend/tests` and `backend/reviewer/tests`
  (sandbox calls mocked, fixtures under `reviewer/tests/fixtures/`; persistence/model tests hit the test DB). Verify
  against that script, not a hand-picked path — `backend/reviewer/tests/` is easy to forget.

**Configuration read at runtime:**

- **GitHub auth** — the team's **GitHub App installation token**, resolved server-side per activity via
  `GitHubIntegration.first_for_team_repository(team_id, repo)` (`_installation_auth` returns
  `(get_access_token(), github_installation_id)`, auto-refreshing); resolution-thread deliveries re-resolve it
  per thread, since a warm session can outlive the ~1h token TTL. No `GITHUB_TOKEN` env var; the worker no longer
  needs one. All calls route through `posthog.egress.github.transport.github_request` (via
  `reviewer/tools/github_client.py`), metered against the installation's shared egress budget.
- `--team-id` / `--user-id` (CLI, required) — the team the review runs and persists under, and the user the
  sandbox tasks run as. They are threaded as **explicit activity inputs** (no ContextVar identity); the team's
  `kind="github"` `Integration` is validated up front by `validate_github_integration_activity`.
  The sandbox `repository` is the PR's own `owner/repo`, derived from the PR URL.
- **Prod label trigger** (settings, `posthog/settings/access.py`) — `REVIEWHOG_TRIGGER_TOKEN` (shared secret),
  `REVIEWHOG_TEAM_ID` (the run team), `REVIEWHOG_RUN_USER_ID` (optional; falls back to the integration creator).

**Triggers.** Five entry points drive the same `ReviewPRWorkflow`: the `run_review` CLI (manual / eval), the
`reviewhog` **label** on a `PostHog/posthog` PR (a thin GitHub Action → `POST /api/review_hog/trigger`), a **UI**
"Review this PR" field in the Code review scene (any installation-accessible PR), an **inbox** trigger (a
`TaskRun` receiver auto-reviews self-driving Signals implementations), and **MCP tools**
(`review-hog-reviews-{trigger,list,get}`, defined in `products/review_hog/mcp/tools.yaml` and gated on the
`review-hog` feature flag) that drive the same reviews viewset with a personal API key or OAuth token. The UI and
MCP paths are one surface: the viewset carries the grantable `review_hog` scope (`review_hog:read` for list /
retrieve / perspective_stats, `review_hog:write` for trigger) rather than INTERNAL, and the trigger action keeps
the `REVIEWHOG_TEAM_ID` dogfood gate and its synchronous URL / App-access / fork / open-state checks regardless of
caller. See [DECISIONS.md](./DECISIONS.md) for each trigger's auth / scope / identity rules.

**Review surfaces (Code review scene).** The reviews API's `scope=mine` ("For you") matches reports where the
viewer is the **acting user OR the PR's author** — `author_login` compared case-insensitively against the
viewer's linked GitHub login (`User.get_github_login()`, the reverse of the author→user mapping the reviewer
runs under; no linked login → acting-user match only). `scope=everyone` is the whole project; `retrieve` is
project-wide so any listed review opens. A specific report is linkable at `/code-review?review=<report id>`
(mirrored to/from the drawer by `reviewHogSettingsLogic`'s URL sync; the status comment's held-back link
targets it, so the param is a permanent contract). The drawer buckets a review's findings into published vs
below-threshold by the detail's stored `run_urgency_threshold` — the viewer's current setting is only the
fallback for pre-column rows — and its first tab reads "Published" only when the review actually posted
(`published_head_sha` set), "Kept" otherwise. The scene keeps itself current by polling the reviews
list — every 10s while a run is in progress or freshly triggered, every 30s otherwise, paused on hidden
tabs with an immediate refresh on tab return — and a poll response that shows a run finishing also
refreshes the perspective stats and an open drawer's detail (`reviewHogSettingsLogic`).

---

## Known issues & tech debt

- **✅ RESOLVED — transient sandbox timeout silently drops a review.** Superseded by the Temporal migration
  and later hardening: every review unit is an activity with `RetryPolicy(maximum_attempts=2)`, failed units
  are counted and logged per stage (never silent), and a fan-out stage losing more than
  `FAN_OUT_FAILURE_FLOOR = 0.70` of its units fails the run loudly (`_enforce_failure_floor`,
  `temporal/workflow.py`). Validation turn failures additionally retry with skip-resume.
- **TODO — perspective fan-out back-loads the last perspective.** `ReviewPerspectivesWorkflow.run` builds the
  wave gather in perspective order (`units = [(p, c) for p in ordered for c in inputs.chunk_ids]`,
  `temporal/workflow.py`); with a FIFO semaphore the last perspective queues at the back, so the Performance
  reviews tend to finish last. It is genuinely parallel, but not balanced per-chunk. Fix: interleave the task
  list by chunk (`P1c1, P2c1, P3c1, P1c2, …`) so a chunk's perspectives co-schedule. (Raising
  `MAX_CONCURRENT_SANDBOXES` partly mitigates by leaving fewer tasks queued.)
- **Per-stage failure policy (deliberate).** Chunking, selection, and dedup run under `_ONESHOT_RETRY`
  (5 spaced, escalating attempts — provider-overload spells last minutes, so back-to-back retries all land inside
  the same spell); chunking and dedup fail the run once retries exhaust (single-unit stages, nothing to degrade
  to), while selection fails open to the dense product. The perspective wave and blind-spot sweep are best-effort
  under the 70% failure floor; validation retries per chunk, and only the final attempt degrades to skipping the
  failing issue. Every best-effort stage is floor-bounded and logs its losses.
- **Resume identity residual — working-state cache is roster-blind.** The per-head `perspective_result` /
  `perspective_selection` rows resume on positional `(pass_number, chunk_id)` keys, so if a different acting user
  (different enabled-perspective roster) resumes a turn that persisted working state **without** stamping
  `published_head_sha` (a zero-findings or crashed turn), slots can silently mis-map. Identical rosters are always
  safe. Fix belongs with cross-turn finding identity: key results by `skill_name`(+version) instead of slot, and
  drop persisted selection/results whose recorded roster differs from the run's.
- **TODO — the drawer's "Published" flag trusts the report-lifetime watermark, not the shown turn.** The
  reviews API computes `published` as `published_head_sha IS NOT NULL`, while the drawer shows the _latest
  completed turn_'s findings. A report that published once and later finalizes a turn that never posts
  (store-only re-run, or `publish_review` failing past retries) shows that turn's findings under
  "Published" with no not-published banner. Fix: `retrieve` already loads the completed head — expose
  per-turn truth (`published_head_sha == completed_head_sha`) on the detail payload and gate the drawer's
  published flag on it.
- **TODO — no resolution-stage progress label.** A resolution run holds the report `active` at a
  published head, where `progress_payload` falls through to a review-stage label ("deduplicating"; the
  pre-publish window reads "finalizing"). A dedicated `resolving` stage needs the serializer enum, the
  frontend stage labels, and regenerated types — deliberately left out of the staleness fix.
- **Accepted gap — a stopped standalone resolution on a never-reviewed PR never shows in the scene list.** Such
  a report has no `last_run_at` (only review turns stamp it), and the list admits it only while its activity is
  fresh — mutually exclusive with the stale-based "stopped" state, so the row drops out exactly when it would
  say "didn't finish" (the detail endpoint excludes it too). Accepted because the PR status comment now carries
  the failure notice reliably (the workflow-level `fail_resolution_activity` backstop) and the flow is rare
  (`/resolve` / inbox handoffs on PRs ReviewHog never reviewed). Fixing it means a new list slice for reports
  with a recent `resolution_run` plus an aging-out bound for stopped rows.
- **Accepted gap — a resolution turn longer than the 30-minute staleness window shows a false "didn't finish".**
  Resolution writes once per settled thread, so a single long turn (worst: the first, which carries sandbox boot
  - clone) can outlast `IN_PROGRESS_STALE_AFTER` with the run healthy — the row reads "stopped" while a
    retrigger correctly 409s. Accepted: typical turns run a few minutes, the label self-corrects on the next
    verdict, and the busy-guard still prevents double runs. If turns ever grow, add a periodic DB liveness beat
    inside `resolve_threads_activity` (Temporal's Heartbeater pings Temporal only, never the DB the UI reads).
- **Alpha maturity** — the published comment still says "ReviewHog Alpha" and asks users to reply
  "valid"/"invalid" (`reviewer/tools/publish_review.py`, the `post_promo` block). Publish is now live
  per-run (the trigger endpoint posts with `publish=true`), so settle the prod wording before real users
  see it.
- **TODO (BLOCKING public release) — resolution-stage injection hardening, deferred by decision.** Structural
  (JSON) comment rendering in the resolution prompt, the author-permission gate, and pre-push restricted-paths
  enforcement in the signed-commit tooling are NOT built; only the prompt floors + the post-push delivery
  backstop stand between a hostile PR comment and a write turn (and the backstop cannot un-push — the commit is
  on the branch, and CI has seen it, before the check runs). Do not widen `REVIEWHOG_TEAM_IDS` or ship the
  resolution stage publicly before all three land — see the BLOCKING TODO in
  [Status & next](#status--next) and DECISIONS.md Stage 7.
