import pytest

from django.core.management.base import CommandError

from parameterized import parameterized

from products.warehouse_sources.backend.management.commands.run_warehouse_sources_load import (
    Command,
    build_consumer_config,
    parse_sync_types,
)


def _parse_options(argv: list[str]) -> dict:
    parser = Command().create_parser("manage.py", "run_warehouse_sources_load")
    return vars(parser.parse_args(argv))


class TestBuildConsumerConfig:
    def test_defaults_come_from_the_config_dataclass(self):
        config = build_consumer_config(_parse_options([]))

        assert config.poll_timeout_seconds == 180.0
        assert config.sweep_timeout_seconds == 300.0
        assert config.connect_timeout_seconds == 10
        assert config.recovery_grace_seconds == 300
        assert config.lease_ttl_seconds == config.recovery_grace_seconds
        assert config.poll_failure_liveness_threshold == 10

    @parameterized.expand(
        [
            (["--poll-timeout", "600"], "poll_timeout_seconds", 600.0),
            (["--poll-timeout", "0"], "poll_timeout_seconds", None),
            (["--sweep-timeout", "900"], "sweep_timeout_seconds", 900.0),
            (["--sweep-timeout", "0"], "sweep_timeout_seconds", None),
            (["--connect-timeout", "30"], "connect_timeout_seconds", 30),
            (["--lease-ttl", "600"], "lease_ttl_seconds", 600),
            (["--recovery-grace", "900"], "recovery_grace_seconds", 900),
            (["--poll-failure-liveness-threshold", "5"], "poll_failure_liveness_threshold", 5),
            (["--poll-failure-liveness-threshold", "0"], "poll_failure_liveness_threshold", None),
        ]
    )
    def test_flag_overrides_reach_the_config(self, argv: list[str], field: str, expected):
        config = build_consumer_config(_parse_options(argv))

        assert getattr(config, field) == expected

    @parameterized.expand([(["--claim-path", "state"],), (["--claim-path", "legacy"],)])
    def test_deprecated_claim_path_flag_is_still_accepted(self, argv: list[str]):
        # Deployed pods still pass --claim-path; dropping the arg would crash
        # the whole fleet at startup with "unrecognized arguments".
        config = build_consumer_config(_parse_options(argv))

        assert not hasattr(config, "claim_path")

    def test_lease_ttl_follows_recovery_grace_when_not_set(self):
        config = build_consumer_config(_parse_options(["--recovery-grace", "900"]))

        assert config.lease_ttl_seconds == 900


class TestParseSyncTypes:
    @parameterized.expand(
        [
            (None, None),
            ("", None),
            (" , ", None),
            ("cdc", ["cdc"]),
            ("cdc, append", ["cdc", "append"]),
        ]
    )
    def test_parses_comma_separated_values(self, raw: str | None, expected: list[str] | None):
        assert parse_sync_types(raw, "--claim-sync-types") == expected

    def test_unknown_sync_type_fails_startup(self):
        # A typo'd Helm value (e.g. 'CDC') must crash the pod at startup — accepted
        # silently, it would build a filter matching nothing and the fleet would idle
        # while its classes pile up in the queue.
        with pytest.raises(CommandError, match="unknown sync type"):
            parse_sync_types("CDC", "--claim-sync-types")
