import uuid
import decimal
import hashlib
import datetime
from ipaddress import IPv4Address, IPv6Address
from typing import Any, Literal, cast

import pytest
from unittest.mock import AsyncMock, MagicMock, patch

import orjson
import pyarrow as pa
import deltalake
import structlog
from dateutil import parser
from structlog.types import FilteringBoundLogger

from posthog.temporal.common.errors import NonReportableError

from products.warehouse_sources.backend.temporal.data_imports.external_data_job import Any_Source_Errors
from products.warehouse_sources.backend.temporal.data_imports.pipelines.core.arrow_utils import (
    BillingLimitsWillBeReachedException,
    BinaryColumnReporter,
    SchemaColumnTypeChangedException,
    _get_max_decimal_type,
    _to_list_array,
    align_incoming_decimals_to_delta,
    apply_enabled_columns_projection,
    conditional_lru_cache_async,
    evolve_pyarrow_schema,
    hex_encode_id_binary_columns,
    is_safe_numeric_widening,
    merge_observed_columns_into_schema_metadata,
    normalize_table_column_names,
    observe_and_project_table,
    observed_schema_metadata_columns,
    raise_on_nullability_drift,
    reconcile_batch_to_accumulated_schema,
    relax_batch_nullability,
    restrict_schema_to_columns,
    source_uses_delta_write_column_selection,
    table_from_py_list,
    unify_schemas_with_text_fallback,
)
from products.warehouse_sources.backend.temporal.data_imports.pipelines.core.consts import PARTITION_KEY
from products.warehouse_sources.backend.temporal.data_imports.pipelines.core.partitioning import (
    NULL_NUMERICAL_PARTITION,
    append_partition_key_to_table,
    setup_partitioning,
)
from products.warehouse_sources.backend.temporal.data_imports.pipelines.test_mocks import mock_delta_table


def test_table_from_py_list_uuid():
    uuid_ = uuid.uuid4()
    table = table_from_py_list([{"column": uuid_}])

    assert table.equals(pa.table({"column": [str(uuid_)]}))
    assert table.schema.equals(
        pa.schema(
            [
                ("column", pa.string()),
            ]
        )
    )


def test_table_from_py_list_schema_missing_uuid_column():
    # A UUID column present in the batch but absent from the provided schema has its Arrow field
    # inferred by `_python_type_to_pyarrow_type`, which must map UUID to string rather than raising.
    uuid_ = uuid.uuid4()
    schema = pa.schema(cast(Any, [pa.field("id", pa.int64())]))
    table = table_from_py_list([{"id": 1, "uid": uuid_}], schema)

    assert table.schema.field("uid").type == pa.string()
    assert table.column("uid").to_pylist() == [str(uuid_)]


def test_table_from_py_list_inconsistent_list():
    table = table_from_py_list([{"column": "hello"}, {"column": ["hi"]}])

    assert table.equals(pa.table({"column": ['["hello"]', '["hi"]']}))
    assert table.schema.equals(
        pa.schema(
            [
                ("column", pa.string()),
            ]
        )
    )


def test_table_from_py_list_inconsistent_other_types():
    table = table_from_py_list([{"column": "hello"}, {"column": 12}])

    assert table.equals(pa.table({"column": ['"hello"', "12"]}))
    assert table.schema.equals(
        pa.schema(
            [
                ("column", pa.string()),
            ]
        )
    )


def test_table_from_py_list_numeric_column_with_non_numeric_value_raises_named_error():
    with pytest.raises(TypeError) as exc_info:
        table_from_py_list([{"revenue": 1.5}, {"revenue": "N/A"}, {"revenue": ""}])

    message = str(exc_info.value)
    # Preserves the original phrase so source non-retryable matching still fires
    assert "must be real number, not str" in message
    # Names the column and shows the offending text and blank cells
    assert "revenue" in message
    assert "N/A" in message
    assert "<blank>" in message
    # The message must stay matched by an Any_Source_Errors entry so the schema is paused with
    # guidance instead of retrying the same non-numeric cells forever, on every source.
    assert [key for key in Any_Source_Errors if key in message]


def test_table_from_py_list_numeric_column_coerces_numeric_string_values():
    # Numeric columns whose cells arrive as numeric strings (common with JSON-based sources
    # such as Mixpanel, where a property flips between 570 and "570") must coerce, not fail
    # the whole sync. Blank cells become null; genuinely non-numeric text still raises.
    table = table_from_py_list(
        [{"column": 1.5}, {"column": "570"}, {"column": "  42  "}, {"column": ""}, {"column": None}]
    )

    assert pa.types.is_decimal(table.schema.field("column").type)
    assert table.column("column").to_pylist() == [
        decimal.Decimal("1.5"),
        decimal.Decimal("570"),
        decimal.Decimal("42"),
        None,
        None,
    ]


@pytest.mark.parametrize(
    "values,expected,type_check",
    [
        # Single float type -> float path
        ([1.5, None, 2.5, None], [1.5, None, 2.5, None], pa.types.is_floating),
        # Mixed numeric types -> decimal conversion path (len(unique_types_in_column) > 1)
        (
            [1.5, None, decimal.Decimal("2.5"), None],
            [decimal.Decimal("1.5"), None, decimal.Decimal("2.5"), None],
            pa.types.is_decimal,
        ),
    ],
)
def test_table_from_py_list_numeric_column_with_none_gaps(values, expected, type_check):
    table = table_from_py_list([{"column": value} for value in values])

    assert table.column("column").to_pylist() == expected
    assert type_check(table.schema.field("column").type)


def test_table_from_py_list_inconsistent_types_with_none():
    table = table_from_py_list([{"column": None}, {"column": "hello"}, {"column": 12}, {"column": None}])

    assert table.equals(pa.table({"column": [None, '"hello"', "12", None]}))
    assert table.schema.equals(
        pa.schema(
            [
                ("column", pa.string()),
            ]
        )
    )


@pytest.mark.parametrize(
    "rows,expected",
    [
        ([{"column": "hello"}, {"column": {"field": 1}}], ["hello", '{"field":1}']),
        # A third scalar type (e.g. int) alongside str and dict used to reach pa.array()
        # unconverted and raise "ArrowTypeError: Expected bytes, got a 'int' object" — a free-form
        # field that's sometimes a plain number is a real shape (e.g. an execution's JSON output).
        ([{"column": "hello"}, {"column": {"field": 1}}, {"column": 5}], ["hello", '{"field":1}', "5"]),
    ],
)
def test_table_from_py_list_inconsistent_types_with_str_and_dict(rows, expected):
    table = table_from_py_list(rows)

    assert table.equals(pa.table({"column": expected}))
    assert table.schema.equals(
        pa.schema(
            [
                ("column", pa.string()),
            ]
        )
    )


# A source may declare a non-string type for a column that arrives as dicts; the serialized
# column must coerce the schema field to string or from_pydict fails.
_STRING_DATA_FIELDS: list[pa.Field] = [pa.field("id", pa.int64()), pa.field("data", pa.string())]
_STRUCT_DATA_FIELDS: list[pa.Field] = [
    pa.field("id", pa.int64()),
    pa.field("data", pa.struct([pa.field("a", pa.int64())])),
]


@pytest.mark.parametrize(
    "schema",
    [
        None,
        pa.schema(_STRING_DATA_FIELDS),
        pa.schema(_STRUCT_DATA_FIELDS),
    ],
)
def test_table_from_py_list_dict_column_preserves_original_documents(schema):
    # Heterogeneous nested documents (each row's structure differs, as in a MongoDB collection).
    # Routing these through a unified pyarrow struct made conversion superlinear in batch size
    # and injected null-filled union fields from other rows into every serialized document.
    docs = [
        {"a": 1, "nested": {"x": [{"k": 1, "verbs": ["led"]}]}},
        {"b": "two", "nested": {"y": {"deep": True}}, "extra": [1, 2]},
        None,
        {"c": [{"only": "here"}]},
    ]
    table = table_from_py_list([{"id": i, "data": doc} for i, doc in enumerate(docs)], schema)

    assert table.schema.field("data").type == pa.string()
    stored = [None if v is None else orjson.loads(v) for v in table.column("data").to_pylist()]
    assert stored == docs


@pytest.mark.parametrize(
    "rows,expected",
    [
        # bool in one row, list in another: wrapping to a list yields [true]/["x"], whose element
        # types differ, so an intermediate pyarrow list array would raise "tried to convert to boolean".
        ([{"column": True}, {"column": ["x"]}], ["[true]", '["x"]']),
        # dict in one row, list in another: would raise "cannot mix struct and non-struct values".
        ([{"column": {"a": 1}}, {"column": ["x"]}], ['[{"a":1}]', '["x"]']),
    ],
)
def test_table_from_py_list_list_mixed_with_incompatible_element_types(rows, expected):
    table = table_from_py_list(rows)

    assert table.equals(pa.table({"column": expected}))
    assert table.schema.equals(pa.schema([("column", pa.string())]))


def test_table_from_py_list_with_lists():
    table = table_from_py_list([{"column": ["hello"]}, {"column": ["hi"]}])

    assert table.equals(pa.table({"column": ['["hello"]', '["hi"]']}))
    assert table.schema.equals(
        pa.schema(
            [
                ("column", pa.string()),
            ]
        )
    )


def test_table_from_py_list_with_nan():
    table = table_from_py_list([{"column": 1.0}, {"column": float("NaN")}])

    assert table.equals(pa.table({"column": [1.0, None]}))
    assert table.schema.equals(
        pa.schema(
            [
                ("column", pa.float64()),
            ]
        )
    )


def test_table_from_py_list_with_inf():
    table = table_from_py_list([{"column": 1.0}, {"column": float("Inf")}])

    assert table.equals(pa.table({"column": [1.0, None]}))
    assert table.schema.equals(
        pa.schema(
            [
                ("column", pa.float64()),
            ]
        )
    )


def test_table_from_py_list_with_negative_inf():
    table = table_from_py_list([{"column": 1.0}, {"column": -float("Inf")}])

    assert table.equals(pa.table({"column": [1.0, None]}))
    assert table.schema.equals(
        pa.schema(
            [
                ("column", pa.float64()),
            ]
        )
    )


def test_table_from_py_list_with_decimal_inf():
    table = table_from_py_list([{"column": decimal.Decimal(1)}, {"column": decimal.Decimal("Infinity")}])

    assert table.equals(pa.table({"column": [decimal.Decimal("1.0"), None]}))
    assert table.schema.equals(
        pa.schema(
            [
                ("column", pa.decimal128(2, 1)),
            ]
        )
    )


def test_table_from_py_list_with_negative_decimal_inf():
    table = table_from_py_list([{"column": decimal.Decimal(1)}, {"column": decimal.Decimal("-Infinity")}])

    assert table.equals(pa.table({"column": [decimal.Decimal("1.0"), None]}))
    assert table.schema.equals(
        pa.schema(
            [
                ("column", pa.decimal128(2, 1)),
            ]
        )
    )


def test_table_from_py_list_with_binary_column():
    table = table_from_py_list([{"column": 1.0, "some_bytes": b"hello"}])

    assert table.equals(pa.table({"column": [1.0]}))
    assert table.schema.equals(
        pa.schema(
            [
                ("column", pa.float64()),
            ]
        )
    )


def test_table_from_py_list_with_null_filled_binary_column():
    schema = pa.schema(cast(Any, [pa.field("column", pa.string()), pa.field("some_bytes", pa.binary())]))
    table = table_from_py_list([{"column": "hello", "some_bytes": None}], schema)

    assert table.equals(pa.table({"column": ["hello"]}))
    assert table.schema.equals(
        pa.schema(
            [
                ("column", pa.string()),
            ]
        )
    )


@pytest.mark.parametrize(
    "column_name,primary_keys,expect_kept",
    [
        ("id", None, True),
        ("ID", None, True),
        ("order_id", None, True),
        ("uuid", None, True),
        ("guid", None, True),
        ("token", ["token"], True),
        ("token", None, False),
        ("payload", None, False),
    ],
)
def test_table_from_py_list_keeps_id_like_binary_columns_as_hex(
    column_name: str, primary_keys: list[str] | None, expect_kept: bool
):
    table = table_from_py_list([{column_name: b"\xbd\xd6\x40", "other": 1.0}], primary_keys=primary_keys)

    if expect_kept:
        assert table.column(column_name).to_pylist() == ["bdd640"]
        assert table.schema.field(column_name).type == pa.string()
    else:
        assert column_name not in table.schema.names


def test_table_from_py_list_keeps_binary_id_column_with_schema():
    schema = pa.schema(cast(Any, [pa.field("id", pa.binary()), pa.field("column", pa.string())]))
    table = table_from_py_list([{"id": b"\x01\xff", "column": "hello"}, {"id": None, "column": "world"}], schema)

    assert table.column("id").to_pylist() == ["01ff", None]
    assert table.schema.field("id").type == pa.string()
    assert table.column("column").to_pylist() == ["hello", "world"]


@pytest.mark.parametrize(
    "column_name,column_type,primary_keys,expected_values,expected_type",
    [
        ("id", pa.binary(), None, ["bdd640", None], pa.string()),
        ("order_id", pa.binary(), None, ["bdd640", None], pa.string()),
        ("sk_load", pa.binary(), ["sk_load"], ["bdd640", None], pa.string()),
        ("sk_load", pa.large_binary(), ["sk_load"], ["bdd640", None], pa.large_string()),
        ("sk_load", pa.binary(), None, [b"\xbd\xd6\x40", None], pa.binary()),
        ("payload", pa.binary(), None, [b"\xbd\xd6\x40", None], pa.binary()),
    ],
)
def test_hex_encode_id_binary_columns(
    column_name: str,
    column_type: pa.DataType,
    primary_keys: list[str] | None,
    expected_values: list[Any],
    expected_type: pa.DataType,
):
    table = pa.table({column_name: pa.array([b"\xbd\xd6\x40", None], type=column_type), "other": [1.0, 2.0]})

    converted = hex_encode_id_binary_columns(table, primary_keys)

    assert converted.column(column_name).to_pylist() == expected_values
    assert converted.column("other").to_pylist() == [1.0, 2.0]
    assert converted.schema.field(column_name).type == expected_type


def test_hex_encode_id_binary_columns_keeps_chunk_order_and_nulls():
    chunked = pa.chunked_array(
        [
            pa.array([b"\xbd\xd6\x40", None], type=pa.binary()),
            pa.array([None, b"\x01\xff"], type=pa.binary()),
        ]
    )
    table = pa.table({"id": chunked})

    converted = hex_encode_id_binary_columns(table)

    assert converted.column("id").to_pylist() == ["bdd640", None, None, "01ff"]
    assert converted.schema.field("id").type == pa.string()


def test_binary_column_reporter_logs_each_column_once_across_batches():
    logger = MagicMock()
    reporter = BinaryColumnReporter(logger)

    for _ in range(2):
        table_from_py_list([{"id": b"\x01", "payload": b"\x02"}], binary_reporter=reporter)

    assert logger.info.call_count == 1
    assert "id" in logger.info.call_args[0][0]
    assert logger.warning.call_count == 1
    assert "payload" in logger.warning.call_args[0][0]


@pytest.mark.parametrize(
    "value, expected_type",
    [
        (datetime.datetime(2024, 1, 2, 3, 4, 5), pa.timestamp("us")),
        (datetime.datetime(2024, 1, 2, 3, 4, 5, tzinfo=datetime.UTC), pa.timestamp("us", tz="UTC")),
        (datetime.date(2024, 1, 2), pa.date32()),
        (datetime.time(3, 4, 5), pa.time64("us")),
    ],
)
def test_table_from_py_list_schema_missing_temporal_column(value, expected_type):
    # A column present in the batch but absent from the provided schema has its Arrow field
    # inferred by `_python_type_to_pyarrow_type`, which must handle temporal values.
    schema = pa.schema(cast(Any, [pa.field("id", pa.int64())]))
    table = table_from_py_list([{"id": 1, "ts": value}], schema)

    assert table.schema.field("ts").type == expected_type
    assert table.column("ts").to_pylist() == [value]


def test_restrict_schema_to_columns_drops_fields_absent_from_the_read():
    # A SQL source's discovered schema can declare a column the streaming read no longer returns
    # (dropped at the source, or the table recreated with a narrower shape, between discovery and
    # the read). `from_pydict` crashes with an opaque KeyError in that case, so the read path first
    # restricts the schema to the columns it actually got back.
    schema = pa.schema(
        cast(Any, [pa.field("id", pa.int64()), pa.field("name", pa.string()), pa.field("dropped", pa.string())])
    )
    rows = [{"id": 1, "name": "a"}, {"id": 2, "name": "b"}]

    with pytest.raises(KeyError):
        table_from_py_list(rows, schema)

    restricted = restrict_schema_to_columns(schema, ["id", "name"])
    assert restricted.names == ["id", "name"]
    assert restricted.field("id").type == pa.int64()

    table = table_from_py_list(rows, restricted)
    assert table.schema.names == ["id", "name"]
    assert table.column("id").to_pylist() == [1, 2]

    # When every schema field is present the schema is returned unchanged (common case).
    assert restrict_schema_to_columns(restricted, ["id", "name"]) is restricted


@pytest.mark.parametrize(
    "error_msg, large_type, values",
    [
        (
            "offset overflow while concatenating arrays, consider casting input from `binary` to `large_binary` first.",
            pa.large_binary(),
            [b"a", b"b", b"c"],
        ),
        (
            "offset overflow while concatenating arrays, consider casting input from `string` to `large_string` first.",
            pa.large_string(),
            ["a", "b"],
        ),
    ],
)
def test_to_list_array_offset_overflow_falls_back_to_large_type(error_msg, large_type, values):
    # A column whose chunk exceeds 2GB makes `combine_chunks()` overflow the int32 offset;
    # the helper must recover by casting to the large-offset variant instead of raising.
    overflowing = MagicMock(spec=pa.ChunkedArray)
    overflowing.combine_chunks.side_effect = pa.ArrowInvalid(error_msg)
    overflowing.cast.return_value = pa.chunked_array([pa.array(values, type=large_type)])

    assert _to_list_array(overflowing) == values
    overflowing.cast.assert_called_once_with(large_type)


def test_to_list_array_reraises_unrelated_arrow_invalid():
    failing = MagicMock(spec=pa.ChunkedArray)
    failing.combine_chunks.side_effect = pa.ArrowInvalid("some other arrow problem")

    with pytest.raises(pa.ArrowInvalid, match="some other arrow problem"):
        _to_list_array(failing)


def test_table_from_py_list_with_mixed_decimal_float_sizes():
    table = table_from_py_list([{"column": decimal.Decimal(1.0)}, {"column": 1000.01}])

    expected_schema = pa.schema({"column": pa.decimal128(6, 2)})
    assert table.equals(
        pa.table(
            {"column": pa.array([decimal.Decimal("1.0"), decimal.Decimal(str(1000.01))], type=pa.decimal128(6, 2))},
            schema=expected_schema,
        )
    )
    assert table.schema.equals(
        pa.schema(
            [
                ("column", pa.decimal128(6, 2)),
            ]
        )
    )


def test_table_from_py_list_with_schema_and_mixed_decimals():
    schema = pa.schema({"column": pa.decimal128(1, 0)})
    table = table_from_py_list([{"column": 1}, {"column": 1.0}], schema)

    assert table.equals(pa.table({"column": [decimal.Decimal(1), decimal.Decimal(1)]}))
    assert table.schema.equals(
        pa.schema(
            [
                ("column", pa.decimal128(1, 0)),
            ]
        )
    )


def test_table_from_py_list_with_schema_and_str_timestamp():
    schema = pa.schema({"column": pa.timestamp("us")})
    table = table_from_py_list([{"column": "2024-01-01T00:00:00"}], schema)

    expected_schema = pa.schema([pa.field("column", pa.timestamp("us"), nullable=False)])
    assert table.equals(
        pa.table(
            {"column": pa.array([parser.parse("2024-01-01T00:00:00")], type=pa.timestamp("us"))}, schema=expected_schema
        )
    )
    assert table.schema.equals(expected_schema)


def test_table_from_py_list_with_schema_and_too_small_decimal_type():
    schema = pa.schema({"column": pa.decimal128(3, 3)})
    table = table_from_py_list([{"column": decimal.Decimal("1.001")}], schema)

    expected_schema = pa.schema([pa.field("column", pa.decimal128(4, 3))])
    assert table.equals(pa.table({"column": pa.array([decimal.Decimal("1.001")], type=pa.decimal128(4, 3))}))
    assert table.schema.equals(expected_schema)


@pytest.mark.parametrize(
    "decimals,expected",
    [
        ([decimal.Decimal("1")], pa.decimal128(2, 1)),
        ([decimal.Decimal("1.001112")], pa.decimal128(7, 6)),
        ([decimal.Decimal("0.001112")], pa.decimal128(6, 6)),
        ([decimal.Decimal("1.0100000")], pa.decimal128(8, 7)),
        # That is 1 followed by 37 zeroes to go over the pa.Decimal128 precision limit of 38.
        ([decimal.Decimal("10000000000000000000000000000000000000.1")], pa.decimal256(39, 1)),
        # The big integer and the high-scale fraction live in different rows: precision must reserve
        # room for both (7 integer digits + 4 scale), not take max-precision and max-scale
        # independently (which would infer decimal128(7, 4), too narrow for 1000000).
        ([decimal.Decimal("1000000"), decimal.Decimal("0.0001")], pa.decimal128(11, 4)),
    ],
)
def test_get_max_decimal_type_returns_correct_decimal_type(
    decimals: list[decimal.Decimal],
    expected: pa.Decimal128Type | pa.Decimal256Type,
):
    result = _get_max_decimal_type(decimals)
    assert result == expected


def test_table_from_py_list_with_ipv4_address():
    table = table_from_py_list([{"column": IPv4Address("127.0.0.1")}])

    assert table.equals(pa.table({"column": ["127.0.0.1"]}))
    assert table.schema.equals(
        pa.schema(
            [
                ("column", pa.string()),
            ]
        )
    )


def test_table_from_py_list_with_ipv6_address():
    table = table_from_py_list([{"column": IPv6Address("::1")}])

    assert table.equals(pa.table({"column": ["::1"]}))
    assert table.schema.equals(
        pa.schema(
            [
                ("column", pa.string()),
            ]
        )
    )


def test_normalize_table_column_names_prevents_collisions():
    # Create a table with columns that would collide when normalized
    table = pa.table({"foo___bar": ["value1"], "foo_bar": ["value2"], "another___field": ["value3"]})

    normalized_table = normalize_table_column_names(table)

    # First column gets normalized
    assert "foo_bar" in normalized_table.column_names
    # Second column that would collide gets underscore prefix
    assert "_foo_bar" in normalized_table.column_names
    # Non-colliding column gets normalized
    assert "another_field" in normalized_table.column_names

    # Verify the data is preserved
    assert normalized_table.column("foo_bar").to_pylist() == ["value2"]
    assert normalized_table.column("_foo_bar").to_pylist() == ["value1"]
    assert normalized_table.column("another_field").to_pylist() == ["value3"]


def test_table_from_py_list_with_rescaling_decimal_data_loss_error():
    # Very restrictive type, and the large_decimal value is too large for the schema
    schema = pa.schema({"column": pa.decimal128(5, 1)})
    large_decimal = decimal.Decimal("12345.6789")

    table = table_from_py_list([{"column": large_decimal}], schema)

    expected_schema = pa.schema([pa.field("column", pa.decimal128(9, 4))])
    assert table.equals(pa.table({"column": pa.array([decimal.Decimal("12345.6789")], type=pa.decimal128(9, 4))}))
    assert table.schema.equals(expected_schema)


def test_table_from_py_list_int_column_exceeding_int64_promoted_to_decimal():
    # Python ints are unbounded; a value past int64 overflows pyarrow's inferred int64 type with
    # "Python int too large to convert to C long". It should be promoted to decimal instead.
    over_int64 = 2**63 + 1

    table = table_from_py_list([{"column": over_int64}, {"column": 1}, {"column": None}])

    assert pa.types.is_decimal(table.schema.field("column").type)
    assert table.column("column").to_pylist() == [decimal.Decimal(over_int64), decimal.Decimal(1), None]


def test_table_from_py_list_huge_int_column_falls_back_to_string():
    # A value too large even for decimal256 (76 digits) must not crash the sync — keep it as text.
    enormous = int("1" * 340)

    table = table_from_py_list([{"column": enormous}, {"column": 5}])

    assert table.schema.field("column").type == pa.string()
    assert table.column("column").to_pylist() == [str(enormous), "5"]


def test_table_from_py_list_decimal_exceeding_max_scale_is_rounded():
    # An unconstrained Postgres `numeric` can carry more decimal places than Delta Lake's max
    # scale (32). pyarrow refuses to rescale it ("Rescaling Decimal256 value would cause data
    # loss"); the value must be rounded to the max scale rather than crashing the whole sync.
    # A None is mixed in to exercise the null-passthrough in the quantize retry path.
    value = decimal.Decimal("1." + "1" * 80)

    table = table_from_py_list([{"column": value}, {"column": None}])

    col_type = table.schema.field("column").type
    assert pa.types.is_decimal256(col_type)
    assert col_type.scale == 32
    assert table.column("column").to_pylist() == [decimal.Decimal("1." + "1" * 32), None]


def test_table_from_py_list_decimal_too_large_for_decimal256_falls_back_to_string():
    # A value whose integer part can't fit decimal256(76, 32) even after rounding to the max scale
    # is genuinely unrepresentable as a decimal. It must fall back to text rather than crash the
    # sync, mirroring the huge-int fallback. A normal value is mixed in to confirm the whole column
    # stringifies consistently.
    huge = decimal.Decimal("9" * 247)

    table = table_from_py_list([{"column": huge}, {"column": decimal.Decimal("1.5")}, {"column": None}])

    assert table.schema.field("column").type == pa.string()
    assert table.column("column").to_pylist() == [str(huge), "1.5", None]


def test_table_from_py_list_normal_int_column_stays_int64():
    # Values within int64 are unaffected by the overflow handling.
    table = table_from_py_list([{"column": 1}, {"column": 2}, {"column": None}])

    assert table.schema.field("column").type == pa.int64()
    assert table.column("column").to_pylist() == [1, 2, None]


@pytest.mark.parametrize(
    "data, schema, expected_type",
    [
        ([{"column": decimal.Decimal("1234567.5")}], pa.schema({"column": pa.decimal128(38, 32)}), pa.decimal128(8, 1)),
        (
            [{"column": decimal.Decimal("999999.99")}],
            pa.schema({"column": pa.decimal128(38, 32)}),
            pa.decimal128(38, 32),
        ),
        ([{"column": decimal.Decimal("1" * 39 + ".1")}], pa.schema({"column": pa.decimal128(5, 1)}), None),
        (
            [{"column": decimal.Decimal("1234567.5")}, {"column": None}],
            pa.schema({"column": pa.decimal128(38, 32)}),
            pa.decimal128(8, 1),
        ),
    ],
)
def test_table_from_py_list_decimal_fallback_optimal_type(data, schema, expected_type):
    """table_from_py_list picks minimal decimal type from values; decimal256 only when precision > 38."""
    table = table_from_py_list(data, schema)
    col_type = table.schema.field("column").type
    if expected_type is not None:
        assert col_type == expected_type
    else:
        assert pa.types.is_decimal256(col_type)


@pytest.mark.parametrize(
    "batch_type, batch_values, delta_type, expected_type, expect_string",
    [
        (
            pa.decimal128(10, 2),
            [decimal.Decimal("12.5"), decimal.Decimal("89.0")],
            pa.decimal128(38, 2),
            pa.decimal128(38, 2),
            False,
        ),
        (
            pa.decimal256(76, 32),
            [decimal.Decimal("1234567.5"), decimal.Decimal("89.0")],
            pa.decimal128(38, 32),
            None,
            True,
        ),
        (
            pa.decimal128(10, 2),
            [decimal.Decimal("12345678.01"), decimal.Decimal("1.00")],
            pa.decimal128(38, 32),
            pa.decimal128(38, 30),
            False,
        ),
        (pa.decimal128(5, 2), [decimal.Decimal("123.45")], pa.decimal128(38, 32), pa.decimal128(38, 32), False),
        (pa.decimal256(76, 0), [decimal.Decimal("1" * 39)], pa.decimal128(38, 32), None, True),
        (pa.decimal128(5, 2), [decimal.Decimal("123.45"), None], pa.decimal128(38, 32), pa.decimal128(38, 32), False),
        (
            pa.decimal128(38, 5),
            [decimal.Decimal("123456789012345678901234567890123")],
            pa.decimal128(38, 10),
            pa.decimal128(38, 5),
            False,
        ),
    ],
)
def test_evolve_pyarrow_schema_decimal_reconciliation(
    batch_type, batch_values, delta_type, expected_type, expect_string
):
    """Decimal reconciliation: merge to decimal128(38, scale) when fits, else decimal256→string."""
    arrow_table = pa.table(
        {"id": pa.array([1] * len(batch_values), type=pa.int64()), "amount": pa.array(batch_values, type=batch_type)}
    )
    delta_schema = deltalake.Schema.from_arrow(
        pa.schema([pa.field("id", pa.int64(), nullable=False), pa.field("amount", delta_type, nullable=True)])
    )
    evolved = evolve_pyarrow_schema(arrow_table, delta_schema)
    result_type = evolved.schema.field("amount").type
    result_vals = evolved.column("amount").to_pylist()
    if expect_string:
        assert pa.types.is_string(result_type)
        for orig, got in zip(batch_values, result_vals):
            if orig is not None:
                assert got is not None and decimal.Decimal(str(got)) == orig
    else:
        assert result_type == expected_type
        for orig, got in zip(batch_values, result_vals):
            if orig is not None and got is not None:
                assert abs(got - orig) < decimal.Decimal("0.001")


def test_evolve_pyarrow_schema_arrow_invalid_fallback_to_decimal256_then_string():
    """ArrowInvalid on decimal128 cast (e.g. rescale data loss) → column becomes decimal256 then string."""
    value = decimal.Decimal("0.12345678901234567890123456789012")
    arrow_table = pa.table(
        {
            "id": pa.array([1], type=pa.int64()),
            "amount": pa.array([value], type=pa.decimal128(38, 32)),
        }
    )
    delta_fields: list[pa.Field] = [
        pa.field("id", pa.int64(), nullable=False),
        pa.field("amount", pa.decimal128(38, 18), nullable=True),
    ]
    delta_schema = deltalake.Schema.from_arrow(pa.schema(delta_fields))
    evolved_table = evolve_pyarrow_schema(arrow_table, delta_schema)
    result_type = evolved_table.schema.field("amount").type
    assert pa.types.is_string(result_type)
    result_val = evolved_table.column("amount").to_pylist()[0]
    assert result_val is not None
    assert decimal.Decimal(result_val) == value


def test_evolve_pyarrow_schema_decimal_integration_table_from_py_list():
    """table_from_py_list + evolve_pyarrow_schema: 7 int digits → decimal128(38, 31)."""
    schema = pa.schema({"amount": pa.decimal128(38, 32)})
    table = table_from_py_list([{"amount": decimal.Decimal("1234567.5")}], schema)
    delta_fields: list[pa.Field] = [
        pa.field("amount", pa.decimal128(38, 32), nullable=True),
    ]
    delta_schema = deltalake.Schema.from_arrow(pa.schema(delta_fields))
    evolved_table = evolve_pyarrow_schema(table, delta_schema)
    assert evolved_table.schema.field("amount").type == pa.decimal128(38, 31)


@pytest.mark.parametrize(
    "incoming_type, incoming_values, expected_type",
    [
        (
            pa.decimal128(10, 2),
            [decimal.Decimal("12.50"), decimal.Decimal("89.00")],
            pa.decimal128(10, 2),
        ),
        (
            pa.decimal128(38, 2),
            [decimal.Decimal("12.50"), decimal.Decimal("89.00")],
            pa.decimal128(10, 2),
        ),
        (
            pa.decimal128(38, 2),
            [decimal.Decimal("12345678901.23"), decimal.Decimal("89.00")],
            pa.decimal128(38, 2),
        ),
        (
            pa.decimal128(10, 3),
            [decimal.Decimal("1234567.123"), decimal.Decimal("89.00")],
            pa.decimal128(11, 3),
        ),
    ],
)
def test_evolve_pyarrow_schema_decimal_does_not_widen_unnecessarily_and_can_widen_when_needed(
    incoming_type: pa.Decimal128Type, incoming_values: list[decimal.Decimal], expected_type: pa.Decimal128Type
):
    arrow_table = pa.table(
        {
            "id": pa.array([1, 2], type=pa.int64()),
            "amount": pa.array(incoming_values, type=incoming_type),
        }
    )
    delta_schema = deltalake.Schema.from_arrow(
        pa.schema([pa.field("id", pa.int64(), nullable=False), pa.field("amount", pa.decimal128(10, 2), nullable=True)])  # type: ignore[arg-type]
    )

    evolved_table = evolve_pyarrow_schema(arrow_table, delta_schema)

    assert evolved_table.schema.field("amount").type == expected_type


@pytest.mark.parametrize(
    "delta_type, incoming_type, overflowing_value",
    [
        (pa.int32(), pa.int64(), 6178466636),  # > int32 max (2147483647)
        (pa.int16(), pa.int64(), 6178466636),  # > int16 max, fits int64
        (pa.int16(), pa.int32(), 100000),  # > int16 max (32767), fits int32
        (pa.int64(), pa.float64(), 19.99),  # fractional float into an int column
        (pa.int64(), pa.decimal128(4, 2), decimal.Decimal("19.99")),  # fractional decimal into an int column
    ],
)
def test_evolve_pyarrow_schema_integer_overflow_raises_actionable_error(
    delta_type: pa.DataType, incoming_type: pa.DataType, overflowing_value: int | float | decimal.Decimal
):
    """An incoming value that doesn't fit the stored integer Delta type — a wider integer
    that overflows, or a fractional float/decimal that would be truncated — raises a clear,
    actionable error instructing the user to reset and re-sync, rather than a raw pyarrow
    ArrowInvalid."""
    arrow_table = pa.table(
        {
            "id": pa.array([1, 2], type=pa.int64()),
            "val": pa.array([10, overflowing_value], type=incoming_type),
        }
    )
    delta_schema = deltalake.Schema.from_arrow(
        pa.schema([pa.field("id", pa.int64(), nullable=False), pa.field("val", delta_type, nullable=True)])
    )

    with pytest.raises(SchemaColumnTypeChangedException, match="Source column type changed") as excinfo:
        evolve_pyarrow_schema(arrow_table, delta_schema)

    # The structured fields drive automatic widening recovery (auto_widen_resync); dropping them
    # silently disables it.
    assert excinfo.value.column_name == "val"
    assert excinfo.value.stored_type == delta_type
    assert excinfo.value.incoming_type == incoming_type


@pytest.mark.parametrize(
    "stored_type, incoming_type, expected",
    [
        (pa.int32(), pa.int64(), True),
        (pa.int16(), pa.int64(), True),
        (pa.int64(), pa.float64(), True),
        (pa.int8(), pa.uint8(), True),
        (pa.uint8(), pa.int16(), True),
        (pa.uint32(), pa.uint64(), True),
        (pa.float32(), pa.float64(), True),
        (pa.float64(), pa.int64(), True),
        (pa.int64(), pa.int64(), False),
        (pa.float64(), pa.float64(), False),
        (pa.int64(), pa.string(), False),
        (pa.float64(), pa.string(), False),
        (pa.string(), pa.int64(), False),
        (pa.int64(), pa.decimal128(10, 2), False),
        (pa.decimal128(10, 2), pa.float64(), False),
        (pa.bool_(), pa.int64(), False),
        (pa.int64(), pa.bool_(), False),
        (pa.timestamp("us"), pa.int64(), False),
        (pa.int64(), pa.binary(), False),
    ],
)
def test_is_safe_numeric_widening(stored_type: pa.DataType, incoming_type: pa.DataType, expected: bool):
    assert is_safe_numeric_widening(stored_type, incoming_type) is expected


def test_evolve_pyarrow_schema_integer_narrowing_within_range_is_preserved():
    """A wider incoming integer column whose values still fit the stored narrower type is
    narrowed without error (existing behaviour must not regress)."""
    arrow_table = pa.table(
        {
            "id": pa.array([1, 2], type=pa.int64()),
            "val": pa.array([10, 20], type=pa.int64()),
        }
    )
    delta_schema = deltalake.Schema.from_arrow(
        pa.schema([pa.field("id", pa.int64(), nullable=False), pa.field("val", pa.int32(), nullable=True)])
    )

    evolved_table = evolve_pyarrow_schema(arrow_table, delta_schema)

    assert evolved_table.schema.field("val").type == pa.int32()
    assert evolved_table.column("val").to_pylist() == [10, 20]


def test_evolve_pyarrow_schema_whole_valued_floats_cast_into_stored_integer_column():
    # The type-changed error must only fire on genuine truncation: a float column whose
    # values are all whole numbers still casts losslessly into a stored integer column.
    arrow_table = pa.table(
        {
            "id": pa.array([1, 2], type=pa.int64()),
            "val": pa.array([10.0, 20.0], type=pa.float64()),
        }
    )
    delta_schema = deltalake.Schema.from_arrow(
        pa.schema([pa.field("id", pa.int64(), nullable=False), pa.field("val", pa.int64(), nullable=True)])
    )

    evolved_table = evolve_pyarrow_schema(arrow_table, delta_schema)

    assert evolved_table.schema.field("val").type == pa.int64()
    assert evolved_table.column("val").to_pylist() == [10, 20]


@pytest.mark.parametrize(
    "merge_key_columns,raises",
    [
        (["val"], True),
        (None, False),
    ],
)
def test_evolve_pyarrow_schema_guards_only_merge_keys_against_hex_text(
    merge_key_columns: list[str] | None, raises: bool
):
    arrow_table = pa.table(
        {
            "id": pa.array([1, 2], type=pa.int64()),
            "val": pa.array(["01ff", "02ff"], type=pa.string()),
        }
    )
    delta_schema = deltalake.Schema.from_arrow(
        pa.schema(cast(Any, [pa.field("id", pa.int64(), nullable=False), pa.field("val", pa.binary(), nullable=True)]))
    )

    if raises:
        with pytest.raises(SchemaColumnTypeChangedException, match="merge key"):
            evolve_pyarrow_schema(arrow_table, delta_schema, merge_key_columns=merge_key_columns)
    else:
        evolved = evolve_pyarrow_schema(arrow_table, delta_schema, merge_key_columns=merge_key_columns)
        assert evolved.column("val").to_pylist() == [b"01ff", b"02ff"]


@pytest.mark.parametrize(
    "delta_type, incoming_column",
    [
        # Non-numeric text arriving for a column stored as int (Failed to parse string).
        (pa.int32(), pa.array(["80", "80-150"], type=pa.string())),
        # Non-boolean text arriving for a column stored as bool (Failed to parse value).
        (pa.bool_(), pa.array(["true", "processed"], type=pa.string())),
        # A value that overflows the stored decimal precision (Cannot convert ... overflow).
        (pa.decimal128(3, 1), pa.array([1.0, 999999999.0], type=pa.float64())),
        # A cast pyarrow has no kernel for at all — raised as ArrowNotImplementedError, not
        # ArrowInvalid (a binary column now arriving where a numeric one is stored).
        (pa.float64(), pa.array([b"\x01", b"\x02"], type=pa.binary())),
    ],
)
def test_evolve_pyarrow_schema_incompatible_cast_raises_actionable_error(
    delta_type: pa.DataType, incoming_column: pa.Array
):
    """Incoming data that can't be cast into the stored Delta type — non-numeric text into a
    numeric/boolean column, or a value that overflows the stored decimal precision — raises the
    actionable reset-and-re-sync error rather than a raw pyarrow ArrowInvalid that gets retried."""
    arrow_table = pa.table(
        {
            "id": pa.array([1, 2], type=pa.int64()),
            "val": incoming_column,
        }
    )
    delta_schema = deltalake.Schema.from_arrow(
        pa.schema([pa.field("id", pa.int64(), nullable=False), pa.field("val", delta_type, nullable=True)])
    )

    with pytest.raises(SchemaColumnTypeChangedException, match="Source column type changed"):
        evolve_pyarrow_schema(arrow_table, delta_schema)


@pytest.mark.parametrize(
    "incoming_column, expected_values",
    [
        # Batch with values: a SQL TIME arrives as a Python timedelta and infers as duration.
        (
            pa.array([datetime.timedelta(hours=1), datetime.timedelta(hours=2, minutes=30)], type=pa.duration("us")),
            [3600.0, 9000.0],
        ),
        # All-null batch: keeps the source's declared time64, which used to fail to reconcile.
        (pa.array([None, None], type=pa.time64("us")), [None, None]),
        # Batch whose TIME values arrive typed as time64 rather than duration.
        (pa.array([datetime.time(1, 0, 0), datetime.time(2, 30, 0)], type=pa.time64("us")), [3600.0, 9000.0]),
    ],
)
def test_evolve_pyarrow_schema_time_columns_reconcile_to_stored_seconds(
    incoming_column: pa.Array, expected_values: list[float | None]
):
    """A SQL TIME column oscillates between time64 (all-null batch) and duration (batch with
    values, arriving as Python timedelta) across syncs. Both must normalize to the same float
    seconds so they reconcile against a column already stored as double, instead of raising an
    unretryable type-changed error on every all-null batch."""
    arrow_table = pa.table(
        {
            "id": pa.array([1, 2], type=pa.int64()),
            "redeem_time": incoming_column,
        }
    )
    fields: list[pa.Field] = [
        pa.field("id", pa.int64(), nullable=False),
        pa.field("redeem_time", pa.float64(), nullable=True),
    ]
    delta_schema = deltalake.Schema.from_arrow(pa.schema(fields))

    evolved_table = evolve_pyarrow_schema(arrow_table, delta_schema)

    assert evolved_table.schema.field("redeem_time").type == pa.float64()
    assert evolved_table.column("redeem_time").to_pylist() == expected_values


def test_raise_on_nullability_drift_null_in_non_nullable_column_raises():
    """A batch with a null in a column the table declares non-nullable raises the reset signal,
    because neither deltalite nor delta-rs can relax an existing column to nullable in place."""
    pa_table = pa.table(
        {
            "id": pa.array([1, 2], type=pa.int64()),
            "name": pa.array(["a", None], type=pa.string()),
        }
    )
    delta_fields: list[pa.Field] = [
        pa.field("id", pa.int64(), nullable=False),
        pa.field("name", pa.string(), nullable=False),
    ]
    delta_schema = deltalake.Schema.from_arrow(pa.schema(delta_fields))

    with pytest.raises(SchemaColumnTypeChangedException, match="now contains nulls") as excinfo:
        raise_on_nullability_drift(pa_table, delta_schema)

    # Nullability drift must stay a manual reset: leaving the structured fields unset keeps it out
    # of automatic widening recovery (auto_widen_resync) by construction.
    assert excinfo.value.column_name is None
    assert excinfo.value.stored_type is None
    assert excinfo.value.incoming_type is None


@pytest.mark.parametrize(
    "delta_fields, batch_columns",
    [
        # Null lands in a column the table already marks nullable — the writer accepts it.
        (
            [pa.field("id", pa.int64(), nullable=False), pa.field("name", pa.string(), nullable=True)],
            {"id": pa.array([1, 2], type=pa.int64()), "name": pa.array(["a", None], type=pa.string())},
        ),
        # No nulls arrive in the non-nullable column — nothing drifts.
        (
            [pa.field("id", pa.int64(), nullable=False), pa.field("name", pa.string(), nullable=False)],
            {"id": pa.array([1, 2], type=pa.int64()), "name": pa.array(["a", "b"], type=pa.string())},
        ),
        # The non-nullable column is absent from the batch — no null to check.
        (
            [pa.field("id", pa.int64(), nullable=False), pa.field("name", pa.string(), nullable=False)],
            {"id": pa.array([1, 2], type=pa.int64())},
        ),
    ],
)
def test_raise_on_nullability_drift_permits_valid_batches(
    delta_fields: list[pa.Field], batch_columns: dict[str, pa.Array]
):
    """No drift is raised when the null lands in a nullable column, when the non-nullable column
    carries no nulls, or when it is absent from the batch entirely."""
    pa_table = pa.table(batch_columns)
    delta_schema = deltalake.Schema.from_arrow(pa.schema(delta_fields))

    raise_on_nullability_drift(pa_table, delta_schema)


@pytest.mark.parametrize(
    "fields, columns, expected_nullable",
    [
        # The source declared the column NOT NULL but sent a null in it, so the claim is corrected.
        (
            [pa.field("id", pa.int64(), nullable=False), pa.field("v", pa.int64(), nullable=False)],
            {"id": [1, 2], "v": [None, 5]},
            {"id": False, "v": True},
        ),
        # No nulls arrived, so the source's NOT NULL claim is true and stands.
        (
            [pa.field("id", pa.int64(), nullable=False), pa.field("v", pa.int64(), nullable=False)],
            {"id": [1, 2], "v": [4, 5]},
            {"id": False, "v": False},
        ),
        # The column is already nullable, so there is nothing to correct.
        (
            [pa.field("id", pa.int64(), nullable=False), pa.field("v", pa.int64(), nullable=True)],
            {"id": [1, 2], "v": [None, 5]},
            {"id": False, "v": True},
        ),
        # Only the column that holds nulls is relaxed; its neighbours keep their declared nullability.
        (
            [
                pa.field("id", pa.int64(), nullable=False),
                pa.field("v", pa.int64(), nullable=False),
                pa.field("name", pa.string(), nullable=False),
            ],
            {"id": [1, 2], "v": [None, 5], "name": ["a", "b"]},
            {"id": False, "v": True, "name": False},
        ),
    ],
)
def test_relax_batch_nullability_corrects_only_columns_that_hold_nulls(
    fields: list[pa.Field], columns: dict[str, list], expected_nullable: dict[str, bool]
):
    pa_table = pa.table(columns, schema=pa.schema(fields))

    relaxed = relax_batch_nullability(pa_table)

    assert {field.name: field.nullable for field in relaxed.schema} == expected_nullable
    assert relaxed.to_pydict() == pa_table.to_pydict()
    assert relaxed.schema.types == pa_table.schema.types


def test_relax_batch_nullability_keeps_schema_metadata():
    # The observed-column metadata rides on the schema, so rebuilding the schema must carry it over
    # or the batch loses the column observations the sync persists.
    metadata: dict[bytes | str, bytes | str] = {b"ph_observed_columns": b"[]"}
    pa_table = pa.table(
        {"v": [None, 5]},
        schema=pa.schema([pa.field("v", pa.int64(), nullable=False)], metadata=metadata),
    )

    relaxed = relax_batch_nullability(pa_table)

    assert relaxed.schema.field("v").nullable is True
    assert relaxed.schema.metadata == metadata


def test_evolve_pyarrow_schema_with_struct_containing_datetime_and_decimal():
    metadata_struct_type = pa.struct(
        [
            ("role", pa.string()),
            ("hire_date", pa.timestamp("us")),
            ("salary", pa.decimal128(10, 2)),
        ]
    )

    metadata_data = [
        {
            "role": "admin",
            "hire_date": datetime.datetime(2020, 1, 15, 10, 30, 0),
            "salary": decimal.Decimal("75000.50"),
        },
        {"role": "user", "hire_date": datetime.datetime(2021, 3, 20, 9, 0, 0), "salary": decimal.Decimal("65000.00")},
    ]

    arrow_table = pa.table(
        {
            "id": pa.array([1, 2], type=pa.int64()),
            "metadata": pa.array(metadata_data, type=metadata_struct_type),
        }
    )

    delta_fields: list[pa.Field] = [
        pa.field("id", pa.int64(), nullable=False),
        pa.field("metadata", pa.string(), nullable=True),
    ]
    delta_schema = deltalake.Schema.from_arrow(pa.schema(delta_fields))
    evolved_table = evolve_pyarrow_schema(arrow_table, delta_schema)

    assert evolved_table.schema.field("metadata").type == pa.string()
    metadata_values = evolved_table.column("metadata").to_pylist()
    assert len(metadata_values) == 2
    assert all(isinstance(val, str) for val in metadata_values)


def test_evolve_pyarrow_schema_with_list_containing_datetime():
    arrow_table = pa.table(
        {
            "id": pa.array([1, 2], type=pa.int64()),
            "tags": pa.array([["python", "data"], ["sales", "crm"]], type=pa.list_(pa.string())),
        }
    )

    delta_fields: list[pa.Field] = [
        pa.field("id", pa.int64(), nullable=False),
        pa.field("tags", pa.string(), nullable=True),
    ]
    delta_schema = deltalake.Schema.from_arrow(pa.schema(delta_fields))

    evolved_table = evolve_pyarrow_schema(arrow_table, delta_schema)

    assert evolved_table.schema.field("tags").type == pa.string()
    tags_values = evolved_table.column("tags").to_pylist()
    assert len(tags_values) == 2
    assert all(isinstance(val, str) for val in tags_values)


class TestEvolveSchemaFirstPass:
    """First pass: normalize incoming table types before delta alignment."""

    def test_no_delta_schema_returns_delta_compatible_table(self):
        arrow_table = pa.table({"id": pa.array([1], type=pa.int64()), "name": pa.array(["a"])})
        result = evolve_pyarrow_schema(arrow_table, None)
        assert result.schema.field("id").type == pa.int64()
        assert result.schema.field("name").type in (pa.string(), pa.large_string())

    def test_duration_column_converted_to_seconds(self):
        durations = pa.array([datetime.timedelta(seconds=90), datetime.timedelta(seconds=3661), None])
        arrow_table = pa.table({"elapsed": durations})
        result = evolve_pyarrow_schema(arrow_table, None)
        values = result.column("elapsed").to_pylist()
        assert values[0] == 90.0
        assert values[1] == 3661.0
        assert values[2] is None

    @pytest.mark.parametrize("unit", ["ns", "ms", "s"])
    def test_non_microsecond_timestamp_normalized_to_microseconds(self, unit: Literal["ns", "ms", "s"]):
        # Delta only accepts microsecond-precision timestamps. "s"/"ms" reach here e.g. when
        # a Snowflake batch returns zero rows: the connector's empty-table path ignores
        # `force_microsecond_precision` and falls back to a second-precision schema.
        ts = pa.array([1_000_000_000, 2_000_000_000], type=pa.timestamp(unit))
        arrow_table = pa.table({"ts": ts})
        result = evolve_pyarrow_schema(arrow_table, None)
        assert result.schema.field("ts").type == pa.timestamp("us")

    def test_tz_timestamp_stripped_to_utc_microseconds(self):
        tz_ts = pa.array([1_000_000, 2_000_000], type=pa.timestamp("us", tz="America/New_York"))
        arrow_table = pa.table({"ts": tz_ts})
        result = evolve_pyarrow_schema(arrow_table, None)
        assert result.schema.field("ts").type == pa.timestamp("us")
        assert result.schema.field("ts").type.tz is None


class TestEvolveSchemaSecondPassMissingColumns:
    """Second pass: columns present in delta but missing from incoming table."""

    def test_missing_nullable_column_appended_with_nulls(self):
        arrow_table = pa.table({"id": pa.array([1, 2], type=pa.int64())})
        delta_schema = deltalake.Schema.from_arrow(
            pa.schema([pa.field("id", pa.int64()), pa.field("name", pa.string(), nullable=True)])  # type: ignore[arg-type]
        )
        result = evolve_pyarrow_schema(arrow_table, delta_schema)
        assert "name" in result.column_names
        assert result.column("name").to_pylist() == [None, None]

    def test_missing_non_nullable_column_appended_with_defaults(self):
        arrow_table = pa.table({"id": pa.array([1, 2], type=pa.int64())})
        delta_schema = deltalake.Schema.from_arrow(
            pa.schema([pa.field("id", pa.int64()), pa.field("count", pa.int64(), nullable=False)])
        )
        result = evolve_pyarrow_schema(arrow_table, delta_schema)
        assert "count" in result.column_names
        assert result.column("count").to_pylist() == [0, 0]


class TestEvolveSchemaSecondPassDecimal:
    """Second pass: decimal reconciliation between incoming and delta types."""

    def test_downcast_skipped_when_scales_differ(self):
        arrow_table = pa.table({"amount": pa.array([decimal.Decimal("1.50")], type=pa.decimal128(38, 4))})
        delta_schema = deltalake.Schema.from_arrow(pa.schema([pa.field("amount", pa.decimal128(10, 2), nullable=True)]))
        result = evolve_pyarrow_schema(arrow_table, delta_schema)
        result_type = result.schema.field("amount").type
        assert pa.types.is_decimal128(result_type)
        # max_int_digits = max(8, 34) = 34, merged_scale = min(max(2,4), 38-34) = 4, precision = 38
        assert result_type == pa.decimal128(38, 4)


class TestEvolveSchemaSecondPassTimestamp:
    """Second pass: timestamp alignment between incoming and delta types."""

    def test_timestamp_tz_mismatch_casted(self):
        utc_ts = pa.array([datetime.datetime(2024, 1, 1, 0, 0, 0)], type=pa.timestamp("us", tz="UTC"))
        arrow_table = pa.table({"ts": utc_ts})
        delta_schema = deltalake.Schema.from_arrow(pa.schema([pa.field("ts", pa.timestamp("us"), nullable=True)]))
        result = evolve_pyarrow_schema(arrow_table, delta_schema)
        assert result.schema.field("ts").type == pa.timestamp("us")
        assert result.schema.field("ts").type.tz is None

    def test_string_column_parsed_to_delta_timestamp(self):
        arrow_table = pa.table({"ts": pa.array(["2024-01-01T12:00:00", "2024-06-15T08:30:00"])})
        delta_schema = deltalake.Schema.from_arrow(pa.schema([pa.field("ts", pa.timestamp("us"), nullable=True)]))
        result = evolve_pyarrow_schema(arrow_table, delta_schema)
        assert result.schema.field("ts").type == pa.timestamp("us")
        values = result.column("ts").to_pylist()
        assert values[0] == datetime.datetime(2024, 1, 1, 12, 0, 0)
        assert values[1] == datetime.datetime(2024, 6, 15, 8, 30, 0)


class TestEvolveSchemaSecondPassGenericCast:
    """Second pass: non-decimal, non-timestamp type mismatches."""

    def test_int32_casted_to_int64(self):
        arrow_table = pa.table({"count": pa.array([1, 2, 3], type=pa.int32())})
        delta_schema = deltalake.Schema.from_arrow(pa.schema([pa.field("count", pa.int64(), nullable=True)]))
        result = evolve_pyarrow_schema(arrow_table, delta_schema)
        assert result.schema.field("count").type == pa.int64()
        assert result.column("count").to_pylist() == [1, 2, 3]


class TestEvolveSchemaSecondPassNullability:
    """Second pass: nullable incoming column aligned to non-nullable delta field."""

    def test_nullable_incoming_backfilled_for_non_nullable_delta(self):
        arrow_table = pa.table({"name": pa.array(["hello", None, "world"])})
        delta_schema = deltalake.Schema.from_arrow(pa.schema([pa.field("name", pa.large_string(), nullable=False)]))
        result = evolve_pyarrow_schema(arrow_table, delta_schema)
        values = result.column("name").to_pylist()
        assert values == ["hello", "", "world"]


@pytest.mark.parametrize(
    "name, data",
    [
        ("incrementing_ints_dense", [1, 2, 3, 4, 5]),
        ("incrementing_ints_sparse", [1, 100]),
        ("all_nulls", [None, None, None]),
    ],
)
def test_append_partition_key_to_table_does_not_type_error(name: str, data: list[Any]):
    partition_key = "id"
    table = pa.table({partition_key: data})

    logger: FilteringBoundLogger = structlog.get_logger()

    try:
        append_partition_key_to_table(
            table,
            partition_keys=[partition_key],
            partition_mode=None,
            partition_count=None,
            partition_size=None,
            partition_format=None,
            logger=logger,
        )
    except TypeError:
        pytest.fail(f"raised TypeError for case {name} with data: {data}")


def test_append_partition_key_numerical_handles_null_key():
    # Numerical partitioning is only selected when partition_size is set, so the general
    # does-not-type-error test (partition_size=None) never reaches the `key // partition_size`
    # path. Pipedrive *_fields endpoints partition by `id` with partition_size=1 and can emit
    # rows with a null id, which used to crash with `NoneType // int`.
    partition_key = "id"
    table = pa.table({partition_key: [1, 2, None, 4]})
    logger: FilteringBoundLogger = structlog.get_logger()

    result = append_partition_key_to_table(
        table,
        partition_keys=[partition_key],
        partition_mode=None,
        partition_count=None,
        partition_size=1,
        partition_format=None,
        logger=logger,
    )

    assert result is not None
    assert result.partition_mode == "numerical"
    assert result.table.column(PARTITION_KEY).to_pylist() == ["1", "2", "null", "4"]


def test_append_partition_key_numerical_handles_non_int_key():
    # Numerical mode is persisted per source and passed back in on later batches, skipping the
    # detection guard that requires an integer key column. If the source's key column has since
    # changed type, the values arrive as strings and used to crash the batch on `str // int`.
    # Numeric strings must keep their original bucket; non-numeric ones fall into the null bucket.
    table = pa.table({"id": pa.array(["250", "10", "not-a-number"], type=pa.string())})

    result = append_partition_key_to_table(
        table=table,
        partition_count=None,
        partition_size=100,
        partition_keys=["id"],
        partition_mode="numerical",
        partition_format=None,
        logger=cast(FilteringBoundLogger, structlog.get_logger()),
    )

    assert result is not None
    assert result.partition_mode == "numerical"
    assert result.table.column(PARTITION_KEY).to_pylist() == ["2", "0", "null"]


def _mock_schema(**overrides: Any) -> MagicMock:
    schema = MagicMock()
    schema.partition_count = overrides.get("partition_count")
    schema.partition_size = overrides.get("partition_size")
    schema.partitioning_keys = overrides.get("partitioning_keys")
    schema.partition_format = overrides.get("partition_format")
    schema.partition_mode = overrides.get("partition_mode")
    # Operator-pinned overrides default to None (as on the real model). Without setting these
    # explicitly the MagicMock would auto-create truthy attributes that win the `*_override or ...`
    # precedence in setup_partitioning.
    schema.partition_count_override = overrides.get("partition_count_override")
    schema.partition_size_override = overrides.get("partition_size_override")
    schema.partition_mode_override = overrides.get("partition_mode_override")
    schema.partitioning_keys_override = overrides.get("partitioning_keys_override")
    schema.partitioning_enabled = overrides.get("partitioning_enabled", True)
    schema.set_partitioning_enabled = MagicMock()
    return schema


def _mock_resource(**overrides: Any) -> MagicMock:
    resource = MagicMock()
    resource.partition_count = overrides.get("partition_count")
    resource.partition_size = overrides.get("partition_size")
    resource.partition_keys = overrides.get("partition_keys")
    resource.primary_keys = overrides.get("primary_keys")
    resource.partition_format = overrides.get("partition_format")
    resource.partition_mode = overrides.get("partition_mode")
    return resource


# Regression coverage for the `DeltaError: Specified table partitioning does not match` bug.
#
# When an existing delta table contains `_ph_partition_key` in its *schema columns*
# but not in its *partition columns* (e.g. left over from a write committed with
# `partition_by=None`), subsequent writes with `partition_by=PARTITION_KEY` raise:
#
#     DeltaError: Generic error: Specified table partitioning does not match
#     table partitioning: expected: [], got: ["_ph_partition_key"]
#
# The fix checks `delta_table.metadata().partition_columns` rather than the
# table's schema columns when deciding whether to add the partition key.
_COL_ID = pa.field("id", pa.int64())
_COL_PARTITION = pa.field(PARTITION_KEY, pa.string())


@pytest.mark.parametrize(
    "case,schema_fields,partition_columns,expect_key",
    [
        # Column in schema but NOT in partition_columns → skip (the exact bug scenario).
        ("column_in_schema_not_partitioned", [_COL_ID, _COL_PARTITION], [], False),
        # `metadata().partition_columns` returning None → skip defensively.
        ("partition_columns_is_none", [_COL_ID, _COL_PARTITION], None, False),
        # Truly partitioned by `_ph_partition_key` → happy path, partitioning applies.
        ("table_partitioned_by_key", [_COL_ID, _COL_PARTITION], [PARTITION_KEY], True),
        # Legacy unpartitioned table without the column at all → skip.
        ("column_missing_entirely", [_COL_ID], [], False),
    ],
)
@pytest.mark.asyncio
async def test_setup_partitioning_respects_existing_delta_partition_columns(
    case: str,
    schema_fields: list[pa.Field],
    partition_columns: list[str] | None,
    expect_key: bool,
):
    logger: FilteringBoundLogger = structlog.get_logger()
    pa_table = pa.table({"id": [1, 2, 3]})
    delta_table = mock_delta_table(schema_fields=schema_fields, partition_columns=partition_columns)

    # For the happy-path case we need the schema mock to look "already aligned" so that
    # `set_partitioning_enabled` isn't invoked (which would require DB integration).
    schema_kwargs: dict[str, Any] = {"partitioning_keys": ["id"]}
    if expect_key:
        schema_kwargs.update(partition_mode="md5", partition_format=None)
    resource_kwargs: dict[str, Any] = {"partition_keys": ["id"]}
    if expect_key:
        resource_kwargs["partition_count"] = 10

    result = await setup_partitioning(
        pa_table=pa_table,
        existing_delta_table=delta_table,
        schema=_mock_schema(**schema_kwargs),
        resource=_mock_resource(**resource_kwargs),
        logger=logger,
    )

    if expect_key:
        assert PARTITION_KEY in result.column_names, case
    else:
        assert PARTITION_KEY not in result.column_names, case
        assert result.equals(pa_table), case


@pytest.mark.asyncio
async def test_setup_partitioning_no_delta_table_no_partition_keys_returns_unchanged():
    logger: FilteringBoundLogger = structlog.get_logger()
    pa_table = pa.table({"id": [1, 2, 3]})

    result = await setup_partitioning(
        pa_table=pa_table,
        existing_delta_table=None,
        schema=_mock_schema(),
        resource=_mock_resource(),
        logger=logger,
    )

    assert result.equals(pa_table)
    assert PARTITION_KEY not in result.column_names


@pytest.mark.asyncio
async def test_setup_partitioning_mode_override_forces_datetime_on_non_standard_column():
    # An operator switches a md5 table to datetime on a date column that isn't one of the
    # auto-detected names (created_at/inserted_at/...). The mode + keys overrides must win, so the
    # rows bucket by the date column rather than being md5-hashed by the composite primary key.
    logger: FilteringBoundLogger = structlog.get_logger()
    pa_table = pa.table(
        {
            "record_id": ["a", "b", "c"],
            "action_date": [
                datetime.datetime(2026, 1, 15),
                datetime.datetime(2026, 1, 20),
                datetime.datetime(2026, 2, 3),
            ],
        }
    )
    schema = _mock_schema(
        partition_mode="md5",
        partition_count=30,
        partitioning_keys=["record_id", "action_date"],
        partition_mode_override="datetime",
        partitioning_keys_override=["action_date"],
        partition_format="month",
        partitioning_enabled=False,
    )

    result = await setup_partitioning(
        pa_table=pa_table,
        existing_delta_table=None,
        schema=schema,
        resource=_mock_resource(primary_keys=["record_id", "action_date"]),
        logger=logger,
    )

    assert PARTITION_KEY in result.column_names
    # datetime/month bucketing, not md5 hashing of the composite key.
    assert result.column(PARTITION_KEY).to_pylist() == ["2026-01", "2026-01", "2026-02"]
    schema.set_partitioning_enabled.assert_called_once()
    applied_keys, _count, _size, applied_mode, applied_format = schema.set_partitioning_enabled.call_args.args
    assert applied_mode == "datetime"
    assert applied_keys == ["action_date"]
    assert applied_format == "month"


def _projection_input_table() -> pa.Table:
    return pa.table(
        {
            "id": [1, 2],
            "name": ["a", "b"],
            "amount": [10, 20],
            "updated_at": ["2026-01-01", "2026-01-02"],
            "_ph_debug": ["{}", "{}"],
        }
    )


@pytest.mark.parametrize(
    "enabled_columns,primary_keys,incremental_field,partition_keys,expected_columns",
    [
        # None syncs everything untouched
        (None, ["id"], "updated_at", None, ["id", "name", "amount", "updated_at", "_ph_debug"]),
        # plain selection drops the rest, internals survive
        (["name"], None, None, None, ["name", "_ph_debug"]),
        # PK + incremental field retained even when not selected
        (["name"], ["id"], "updated_at", None, ["id", "name", "updated_at", "_ph_debug"]),
        # source-namespace names (e.g. Snowflake uppercase) fold onto normalized table columns
        (["NAME"], ["ID"], None, None, ["id", "name", "_ph_debug"]),
        # stale enabled names are ignored, not fatal
        (["name", "dropped_upstream"], None, None, None, ["name", "_ph_debug"]),
        # a projection that would empty the table falls back to all columns
        (["dropped_upstream"], None, None, None, ["id", "name", "amount", "updated_at", "_ph_debug"]),
        # [] keeps only the always-retained set
        ([], ["id"], "updated_at", None, ["id", "updated_at", "_ph_debug"]),
        # partition-key source columns retained
        (["name"], None, None, ["amount"], ["name", "amount", "_ph_debug"]),
    ],
)
def test_apply_enabled_columns_projection(
    enabled_columns, primary_keys, incremental_field, partition_keys, expected_columns
):
    table, dropped = apply_enabled_columns_projection(
        _projection_input_table(), enabled_columns, primary_keys, incremental_field, partition_keys
    )

    assert table.column_names == expected_columns
    assert sorted(dropped) == sorted(set(_projection_input_table().column_names) - set(expected_columns))


def test_apply_enabled_columns_projection_drops_spoofed_internal_lookalikes():
    # A source can't smuggle a deselected column past the projection by giving it a name that
    # merely looks internal (_ph_*/_dlt_*) — only the pipeline's own exact internal columns survive.
    table = pa.table(
        {
            "name": ["a", "b"],
            "_ph_debug": ["{}", "{}"],
            "_ph_secret": ["s1", "s2"],
            "_dlt_secret": ["d1", "d2"],
        }
    )

    result, dropped = apply_enabled_columns_projection(table, ["name"], None, None, None)

    assert result.column_names == ["name", "_ph_debug"]
    assert sorted(dropped) == ["_dlt_secret", "_ph_secret"]


@pytest.mark.asyncio
async def test_observe_and_project_table_observes_then_projects_and_logs():
    logger: FilteringBoundLogger = structlog.get_logger()
    observed_columns: dict[str, Any] = {}
    table = _projection_input_table()

    with patch.object(logger, "adebug", new=AsyncMock()) as mock_adebug:
        result = await observe_and_project_table(
            table,
            ["name"],
            None,
            None,
            None,
            observed_columns,
            logger,
            "Dropped non-enabled columns",
        )

    assert result.column_names == ["name", "_ph_debug"]
    # Observed before projection, so deselected columns stay visible to the column picker.
    assert set(observed_columns) == {"id", "name", "amount", "updated_at"}
    mock_adebug.assert_called_once()
    assert "Dropped non-enabled columns" in mock_adebug.call_args.args[0]


def test_observed_schema_metadata_columns_excludes_internal_columns():
    fields: list[pa.Field] = [
        pa.field("id", pa.int64(), nullable=False),
        pa.field("name", pa.string()),
        pa.field("_ph_debug", pa.string()),
        pa.field("_dlt_id", pa.string()),
    ]
    schema = pa.schema(fields)

    assert observed_schema_metadata_columns(schema) == [
        {"name": "id", "data_type": "int64", "is_nullable": False},
        {"name": "name", "data_type": "string", "is_nullable": True},
    ]


def test_merge_observed_columns_creates_schema_metadata_from_empty_config():
    config: dict[str, Any] = {}

    merge_observed_columns_into_schema_metadata(config, [{"name": "id", "data_type": "int64", "is_nullable": False}])

    assert config["schema_metadata"]["columns"] == [{"name": "id", "data_type": "int64", "is_nullable": False}]


def test_merge_observed_columns_unions_and_refreshes():
    # Deselected columns must stay listed (union) or the picker could never re-enable them,
    # while re-observed columns pick up type changes.
    config: dict[str, Any] = {
        "schema_metadata": {
            "columns": [
                {"name": "id", "data_type": "int32", "is_nullable": False},
                {"name": "deselected", "data_type": "string", "is_nullable": True},
            ],
            "source_table_name": "customers",
        }
    }

    merge_observed_columns_into_schema_metadata(
        config,
        [
            {"name": "id", "data_type": "int64", "is_nullable": False},
            {"name": "brand_new", "data_type": "string", "is_nullable": True},
        ],
    )

    assert config["schema_metadata"]["columns"] == [
        {"name": "id", "data_type": "int64", "is_nullable": False},
        {"name": "deselected", "data_type": "string", "is_nullable": True},
        {"name": "brand_new", "data_type": "string", "is_nullable": True},
    ]
    assert config["schema_metadata"]["source_table_name"] == "customers"


@pytest.mark.parametrize(
    "source_type,expected",
    [
        # SQL sources project enabled_columns in their SELECT — no Delta-write drop.
        ("Postgres", False),
        # Managed-schema sources must never drop columns (canonical HogQL schema needs them all),
        # even if a stale enabled_columns is still persisted.
        ("Stripe", False),
        ("Zendesk", False),
        # Generic API sources get the generic Delta-write drop.
        ("Hubspot", True),
        # Unknown source types fail closed.
        ("NotARealSource", False),
    ],
)
def test_source_uses_delta_write_column_selection(source_type, expected):
    assert source_uses_delta_write_column_selection(source_type) is expected


@pytest.mark.parametrize(
    "value,expected",
    [
        # Parseable date strings bucket by their actual date.
        ("2024-03-15", "2024-03"),
        ("2024-06-01T12:00:00", "2024-06"),
        # Non-date-like strings (e.g. a UUIDv7 primary key) must not crash the repartition —
        # they fall back to the unknown-date sentinel.
        ("0198d26d-134b-713a-84f7-24d78a416d9c", "1970-01"),
        ("not a date at all", "1970-01"),
        # Empty / whitespace-only strings also fall back to the sentinel.
        ("", "1970-01"),
        ("   ", "1970-01"),
    ],
)
def test_append_partition_key_datetime_string_column(value, expected):
    table = pa.table({"id": pa.array([value], type=pa.string())})

    result = append_partition_key_to_table(
        table=table,
        partition_count=None,
        partition_size=None,
        partition_keys=["id"],
        partition_mode="datetime",
        partition_format="month",
        logger=cast(FilteringBoundLogger, structlog.get_logger()),
    )

    assert result is not None
    assert result.partition_mode == "datetime"
    assert result.table.column(PARTITION_KEY).to_pylist() == [expected]


@pytest.mark.parametrize(
    "batch_type, batch_values, delta_type",
    [
        # A value that fits the stored column's integer capacity is rounded to its scale so the
        # subsequent merge cast is a no-op instead of overflowing.
        (pa.decimal128(10, 2), [decimal.Decimal("123.45")], pa.decimal128(38, 32)),
        (pa.decimal128(38, 18), [decimal.Decimal("0.0000000416000606")], pa.decimal128(38, 32)),
        (pa.decimal128(38, 30), [decimal.Decimal("999999.99"), None], pa.decimal128(38, 32)),
        # A decimal widened past decimal128 arrives as text (decimal256 → string); it must be
        # parsed back and fitted rather than failing the merge with "Cannot cast string '0E-19'".
        (pa.string(), ["0E-19", None], pa.decimal128(38, 10)),
    ],
)
def test_align_incoming_decimals_to_delta_fits(batch_type, batch_values, delta_type):
    arrow_table = pa.table(
        {
            "id": pa.array([1] * len(batch_values), type=pa.int64()),
            "amount": pa.array(batch_values, type=batch_type),
        }
    )
    delta_fields: list[pa.Field] = [pa.field("id", pa.int64()), pa.field("amount", delta_type)]
    delta_schema = deltalake.Schema.from_arrow(pa.schema(delta_fields))

    aligned = align_incoming_decimals_to_delta(arrow_table, delta_schema)

    assert aligned.schema.field("amount").type == delta_type
    for original, got in zip(batch_values, aligned.column("amount").to_pylist()):
        expected = None if original is None else decimal.Decimal(str(original))
        assert got == expected


def test_align_incoming_decimals_to_delta_raises_when_integer_overflows():
    # 1234567.5 has 7 integer digits; a decimal128(38, 32) column holds only 6, so it can't be
    # stored no matter the rounding. delta-rs can't widen the column in place, so this must surface
    # as the non-retryable reset signal rather than an opaque merge overflow.
    arrow_table = pa.table(
        {
            "id": pa.array([1], type=pa.int64()),
            "amount": pa.array([decimal.Decimal("1234567.5")], type=pa.decimal128(10, 2)),
        }
    )
    delta_fields: list[pa.Field] = [pa.field("id", pa.int64()), pa.field("amount", pa.decimal128(38, 32))]
    delta_schema = deltalake.Schema.from_arrow(pa.schema(delta_fields))

    with pytest.raises(SchemaColumnTypeChangedException) as excinfo:
        align_incoming_decimals_to_delta(arrow_table, delta_schema)

    # Decimal overflow must stay a manual reset: leaving the structured fields unset keeps it out
    # of automatic widening recovery (auto_widen_resync) by construction.
    assert excinfo.value.column_name is None
    assert excinfo.value.stored_type is None
    assert excinfo.value.incoming_type is None


@pytest.mark.parametrize(
    "mode,partition_count,partition_size,partition_format,expected",
    [
        # datetime is the reported crash: a persisted `hs_timestamp`/`_creation_time` key that the
        # source stopped returning fell into `row[key]` and raised a raw KeyError, failing every sync.
        ("datetime", None, None, "month", "1970-01"),
        ("numerical", None, 100, None, NULL_NUMERICAL_PARTITION),
        ("md5", 4, None, None, str(int(hashlib.md5(b"None").hexdigest(), 16) % 4)),
    ],
)
def test_append_partition_key_missing_column_buckets_into_fallback(
    mode, partition_count, partition_size, partition_format, expected
):
    # A persisted partition mode is reused on later batches without re-running detection, so a source
    # schema drift that drops the partition key column must bucket rows into a catch-all partition
    # rather than raise a raw KeyError.
    table = pa.table({"id": pa.array([1, 2, 3], type=pa.int64())})

    result = append_partition_key_to_table(
        table=table,
        partition_count=partition_count,
        partition_size=partition_size,
        partition_keys=["dropped_field"],
        partition_mode=mode,
        partition_format=partition_format,
        logger=cast(FilteringBoundLogger, structlog.get_logger()),
    )

    assert result is not None
    assert result.partition_mode == mode
    assert result.table.column(PARTITION_KEY).to_pylist() == [expected, expected, expected]


def test_billing_limit_exception_is_non_reportable_error():
    # Subclassing NonReportableError is what keeps the intentional billing-limit halt out of
    # error tracking (the activity interceptor re-raises these without capturing them).
    assert issubclass(BillingLimitsWillBeReachedException, NonReportableError)


class TestConditionalLruCacheAsyncCachePop:
    @pytest.mark.asyncio
    async def test_pop_on_cache_miss_returns_none_without_calling_func(self):
        # A best-effort cleanup path (e.g. releasing an already-fetched delta table) must be able
        # to check the cache without ever triggering the wrapped function's own I/O — a miss here
        # used to mean "call the real function", which made cleanup do an unrelated object-storage
        # call and risk masking the real error with a fresh, spurious one.
        calls = []

        @conditional_lru_cache_async(maxsize=1)
        async def fetch(key: str) -> str:
            calls.append(key)
            return f"value-{key}"

        assert fetch.cache_pop("a") is None
        assert calls == []

    @pytest.mark.asyncio
    async def test_pop_on_cache_hit_returns_and_removes_cached_value(self):
        @conditional_lru_cache_async(maxsize=1)
        async def fetch(key: str) -> str:
            return f"value-{key}"

        assert await fetch("a") == "value-a"

        assert fetch.cache_pop("a") == "value-a"
        # Popped, not just read — a second pop finds nothing left to remove.
        assert fetch.cache_pop("a") is None


class TestReconcileBatchToAccumulatedSchema:
    def test_first_batch_seeds_the_accumulated_schema(self):
        batch = pa.table({"owner_id": [1, 2]})

        result, accumulated = reconcile_batch_to_accumulated_schema(batch, None)

        assert result.equals(batch)
        assert accumulated == batch.schema

    @pytest.mark.parametrize(
        "first,second,expected_type,expected_values",
        [
            # An epoch field arriving as numeric text after a numeric batch — the shape that
            # kept breaking Intercom syncs — folds back into the type already written.
            (pa.table({"f": [1700000000]}), pa.table({"f": ["1700000001"]}), pa.int64(), [1700000001]),
            (pa.table({"f": ["a"]}), pa.table({"f": [7]}), pa.string(), ["7"]),
            # Arrow's own promotion wins over stringifying when the types are compatible.
            (pa.table({"f": [1]}), pa.table({"f": [1.5]}), pa.float64(), [1.5]),
            # A column that was all-null in the first batch adopts the real type later.
            (pa.table({"f": [None]}), pa.table({"f": [3]}), pa.int64(), [3]),
            # Nothing else holds both, so text does.
            (pa.table({"f": [1]}), pa.table({"f": ["nope"]}), pa.string(), ["nope"]),
            # Pairs Arrow would "cast" by reinterpretation must degrade to text instead: ints
            # read as the accumulated timestamp's epoch unit would turn 2023 data into 1970
            # dates, and numeric ↔ bool casts truthify.
            (
                pa.table({"f": pa.array([datetime.datetime(2023, 11, 14)], type=pa.timestamp("us"))}),
                pa.table({"f": [1700000000]}),
                pa.string(),
                ["1700000000"],
            ),
            (pa.table({"f": [True]}), pa.table({"f": [7]}), pa.string(), ["7"]),
            (pa.table({"f": [1]}), pa.table({"f": [True]}), pa.string(), ["true"]),
        ],
    )
    def test_conflicting_column_types_converge(
        self, first: pa.Table, second: pa.Table, expected_type: pa.DataType, expected_values: list[Any]
    ):
        _, accumulated = reconcile_batch_to_accumulated_schema(first, None)

        result, accumulated = reconcile_batch_to_accumulated_schema(second, accumulated)

        assert result.schema.field("f").type == expected_type
        assert accumulated.field("f").type == expected_type
        assert result.column("f").to_pylist() == expected_values

    def test_columns_missing_from_a_batch_are_backfilled(self):
        _, accumulated = reconcile_batch_to_accumulated_schema(pa.table({"a": [1], "b": ["x"]}), None)

        result, accumulated = reconcile_batch_to_accumulated_schema(pa.table({"a": [2]}), accumulated)

        assert result.column("b").to_pylist() == [None]
        assert result.schema.field("b").type == pa.string()

    def test_columns_new_to_a_batch_join_the_accumulated_schema(self):
        _, accumulated = reconcile_batch_to_accumulated_schema(pa.table({"a": [1]}), None)

        _, accumulated = reconcile_batch_to_accumulated_schema(pa.table({"a": [2], "b": ["x"]}), accumulated)

        assert accumulated.names == ["a", "b"]

    def test_nested_shapes_degrade_to_json_text_not_reshaped_structs(self):
        # pc.cast(struct → struct) "succeeds" by dropping unmatched fields and null-filling the
        # rest, silently emptying the column. A nested column whose shape changes between
        # batches must render as JSON text instead — with nulls staying null, not becoming text.
        _, accumulated = reconcile_batch_to_accumulated_schema(pa.table({"f": [{"a": 1}]}), None)

        result, accumulated = reconcile_batch_to_accumulated_schema(pa.table({"f": [{"b": "x"}, None]}), accumulated)

        assert result.schema.field("f").type == pa.string()
        rendered, null_value = result.column("f").to_pylist()
        assert rendered is not None
        assert orjson.loads(rendered) == {"b": "x"}
        assert null_value is None
        assert accumulated.field("f").type == pa.string()

    def test_stringified_bytes_decode_as_text_and_nulls_stay_null(self):
        # A binary flip against a non-string accumulated type has no Arrow promotion, so it
        # degrades to text through the per-value renderer: bytes must decode (replacing invalid
        # sequences) rather than render as Python reprs, and nulls must stay null.
        _, accumulated = reconcile_batch_to_accumulated_schema(pa.table({"f": [1]}), None)

        result, _ = reconcile_batch_to_accumulated_schema(
            pa.table({"f": pa.array([b"caf\xc3\xa9", b"\xff", None], type=pa.binary())}), accumulated
        )

        assert result.schema.field("f").type == pa.string()
        assert result.column("f").to_pylist() == ["café", "�", None]

    def test_protected_cursor_column_still_converges_castable_flips(self):
        # The known Intercom shape on the cursor itself: numeric text parses back to the
        # accumulated numeric type, so incremental syncs keep working.
        _, accumulated = reconcile_batch_to_accumulated_schema(pa.table({"updated_at": [1700000000]}), None)

        result, _ = reconcile_batch_to_accumulated_schema(
            pa.table({"updated_at": ["1700000001"]}), accumulated, protected_columns={"updated_at"}
        )

        assert result.column("updated_at").to_pylist() == [1700000001]

    def test_protected_cursor_column_widens_numerically_instead_of_raising(self):
        # A cursor that outgrows the narrow integer type its first batch inferred must widen
        # via Arrow's own promotion — and log the coercion — rather than fail the run.
        logger = MagicMock()
        _, accumulated = reconcile_batch_to_accumulated_schema(
            pa.table({"updated_at": pa.array([1000], type=pa.int32())}), None
        )

        result, accumulated = reconcile_batch_to_accumulated_schema(
            pa.table({"updated_at": pa.array([2**40], type=pa.int64())}),
            accumulated,
            logger=logger,
            protected_columns={"updated_at"},
        )

        assert result.schema.field("updated_at").type == pa.int64()
        assert result.column("updated_at").to_pylist() == [2**40]
        assert accumulated.field("updated_at").type == pa.int64()
        assert logger.warning.call_args.kwargs["resolution"] == "promoted"

    @pytest.mark.parametrize(
        "first,second",
        [
            # True text in the cursor: a string watermark would compare lexicographically and
            # silently corrupt incremental progress, so refuse loudly.
            (pa.table({"updated_at": [1700000000]}), pa.table({"updated_at": ["not-a-number"]})),
            # A cursor that accumulated as text must not quietly absorb numbers either.
            (pa.table({"updated_at": ["2024-01-01T00:00:00"]}), pa.table({"updated_at": [1700000000]})),
        ],
    )
    def test_protected_cursor_column_refuses_text_convergence(self, first: pa.Table, second: pa.Table):
        _, accumulated = reconcile_batch_to_accumulated_schema(first, None)

        with pytest.raises(ValueError, match="cursor column"):
            reconcile_batch_to_accumulated_schema(second, accumulated, protected_columns={"updated_at"})

    def test_batches_of_source_rows_that_flip_type_stay_mergeable(self):
        # The prod failure: a source returns the same field as an int on some rows and a string
        # on others, each batch infers its own type, and merging the run's parquet schemas dies
        # with "Unable to merge: Field ... has incompatible types: int64 vs string".
        accumulated = None
        schemas = []
        for row in ({"id": "1", "waiting_since": 1700000000}, {"id": "2", "waiting_since": "1700000001"}):
            batch = evolve_pyarrow_schema(table_from_py_list([row]), None)
            batch, accumulated = reconcile_batch_to_accumulated_schema(batch, accumulated)
            schemas.append(batch.schema)

        assert unify_schemas_with_text_fallback(schemas).field("waiting_since").type == pa.int64()


class TestUnifySchemasWithTextFallback:
    def test_unmergeable_field_resolves_to_text(self):
        # Batches written before a conflict keep their original type on disk, so the run's
        # merged schema still sees both. Describing it as text beats failing the extraction —
        # while columns the schemas agree on pass through untouched, with only the conflict
        # resolved and logged.
        logger = MagicMock()
        struct = pa.struct([pa.field("x", pa.int64())])
        merged = unify_schemas_with_text_fallback(
            [
                pa.schema([pa.field("f", pa.int64()), pa.field("s", struct)]),
                pa.schema([pa.field("f", pa.string()), pa.field("s", struct)]),
            ],
            logger=logger,
        )

        assert merged.field("f").type == pa.string()
        assert merged.field("s").type == struct
        assert logger.warning.call_count == 1

    def test_mergeable_schemas_are_unchanged(self):
        merged = unify_schemas_with_text_fallback(
            [pa.schema([pa.field("a", pa.int64())]), pa.schema([pa.field("b", pa.string())])]
        )

        assert merged.names == ["a", "b"]
