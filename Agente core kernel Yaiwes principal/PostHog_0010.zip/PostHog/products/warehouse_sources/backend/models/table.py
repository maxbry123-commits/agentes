import csv
import sys
import time
import subprocess
from collections.abc import Iterable
from io import StringIO
from typing import TYPE_CHECKING, Any, NotRequired, Optional, TypedDict, cast
from uuid import UUID

from django.core.exceptions import ValidationError
from django.db import models
from django.db.models import Q
from django.utils import timezone

import structlog
from clickhouse_driver.errors import ServerException as ClickHouseServerException

from posthog.hogql import ast
from posthog.hogql.constants import HogQLQuerySettings
from posthog.hogql.context import HogQLContext
from posthog.hogql.database.direct_clickhouse_table import DirectClickHouseTable
from posthog.hogql.database.direct_motherduck_table import DirectMotherDuckTable
from posthog.hogql.database.direct_mysql_table import DirectMySQLTable
from posthog.hogql.database.direct_postgres_table import DirectPostgresTable
from posthog.hogql.database.direct_redshift_table import DirectRedshiftTable
from posthog.hogql.database.direct_snowflake_table import DirectSnowflakeTable
from posthog.hogql.database.direct_trino_table import DirectTrinoTable
from posthog.hogql.database.models import DatabaseField, FieldOrTable, StructDatabaseField
from posthog.hogql.database.s3_table import (
    DataWarehouseTable as HogQLDataWarehouseTable,
    build_function_call,
)
from posthog.hogql.escape_sql import (
    backquote_clickhouse_identifier,
    escape_clickhouse_identifier,
    escape_param_clickhouse,
)

from posthog.clickhouse.client import sync_execute
from posthog.clickhouse.query_tagging import Feature, Product, tag_queries
from posthog.errors import (
    CORRUPTED_PARQUET_METADATA_MESSAGE,
    QueryErrorCategory,
    classify_query_error,
    wrap_clickhouse_query_error,
)
from posthog.exceptions_capture import capture_exception
from posthog.models.utils import CreatedMetaFields, DeletedMetaFields, UpdatedMetaFields, UUIDTModel, sane_repr
from posthog.schema_enums import DatabaseSerializedFieldType
from posthog.settings import TEST
from posthog.sync import database_sync_to_async

from products.warehouse_sources.backend.models.external_data_schema import ExternalDataSchema
from products.warehouse_sources.backend.models.util import (
    CLICKHOUSE_HOGQL_MAPPING,
    LEGACY_CLICKHOUSE_HOGQL_MAPPING,
    STR_TO_HOGQL_MAPPING,
    clean_type,
    reconstruct_ordered_columns,
    remove_named_tuples,
)
from products.warehouse_sources.backend.temporal.data_imports.pipelines.core.consts import PARTITION_KEY
from products.warehouse_sources.backend.types import DataWarehouseTableCreatedVia, DataWarehouseTableFormat

from .credential import DataWarehouseCredential
from .external_table_definitions import external_tables, get_hogql_column_name_mapping

if TYPE_CHECKING:
    from posthog.schema import HogQLQueryModifiers

    from posthog.models import User

SERIALIZED_FIELD_TO_CLICKHOUSE_MAPPING: dict[DatabaseSerializedFieldType, str] = {
    DatabaseSerializedFieldType.INTEGER: "Int64",
    DatabaseSerializedFieldType.FLOAT: "Float64",
    DatabaseSerializedFieldType.DECIMAL: "Decimal",
    DatabaseSerializedFieldType.STRING: "String",
    DatabaseSerializedFieldType.DATETIME: "DateTime64",
    DatabaseSerializedFieldType.DATE: "Date",
    DatabaseSerializedFieldType.BOOLEAN: "Bool",
    DatabaseSerializedFieldType.ARRAY: "Array",
    DatabaseSerializedFieldType.JSON: "Map",
}

ExtractErrors = {
    "The AWS Access Key Id you provided does not exist": "The Access Key you provided does not exist",
    "Access Denied: while reading key:": "Access was denied when reading a file from the bucket. Check that the provided credentials can read objects in this bucket (s3:GetObject), then try again.",
    # DeltaLake-kernel object_store errors (Delta-format tables, e.g. all warehouse_sources synced
    # tables) use a different vocabulary than ClickHouse's native S3 errors above.
    "The operation lacked the necessary privileges to complete": "Access was denied when reading the provided file",
    "Could not list objects in bucket": "Access was denied to the provided bucket. Check that the provided credentials can list this bucket (s3:ListBucket), then try again.",
    "file is empty": "The provided file contains no data",
    "The specified key does not exist": "The provided file doesn't exist in the bucket",
    "Cannot extract table structure from CSV format file, because there are no files with provided path in S3 or all files are empty": "The provided file doesn't exist in the bucket",
    "Cannot extract table structure from Parquet format file, because there are no files with provided path in S3 or all files are empty": "The provided file doesn't exist in the bucket",
    "Cannot extract table structure from JSONEachRow format file, because there are no files with provided path in S3 or all files are empty": "The provided file doesn't exist in the bucket",
    "Bucket or key name are invalid in S3 URI": "The provided file or bucket doesn't exist",
    "S3 exception: `NoSuchBucket`, message: 'The specified bucket does not exist.'": "The provided bucket doesn't exist",
    "Either the file is corrupted or this is not a parquet file": "The provided file is not in Parquet format",
    "deserialize thrift": CORRUPTED_PARQUET_METADATA_MESSAGE,
    "Rows have different amount of values": "The provided file has rows with different amount of values",
    "The operation is not valid for the object's storage class": "Some files in the bucket are archived (e.g. Glacier or S3 Intelligent-Tiering archive). Restore them to Standard storage or narrow the URL pattern to exclude archived files.",
}

type DataWarehouseTableColumn = str | dict[str, Any]
type DataWarehouseTableColumns = dict[str, DataWarehouseTableColumn]


class DataWarehouseTableIntrospectedColumn(TypedDict):
    hogql: str
    clickhouse: str
    valid: NotRequired[bool]


type DataWarehouseTableIntrospectedColumns = dict[str, DataWarehouseTableIntrospectedColumn]

# Internal plumbing columns added during sync, hidden from the HogQL catalog (see hogql_definition)
# and never user-facing.
HIDDEN_COLUMNS: frozenset[str] = frozenset({"_dlt_id", "_dlt_load_id", "_ph_debug", PARTITION_KEY})

# Characters that carry quoting meaning once a column name is written into SQL. The structure
# builder escapes them already, so this is a second layer: it keeps such a name out of the other
# sinks that read this column store, not all of which escape as thoroughly (for example
# _quote_identifier in the ClickHouse source connector doubles backticks but not backslashes).
# These names are addressable from HogQL, which escapes them correctly, so this rejects on the
# storage risk rather than on usability.
REJECTED_COLUMN_NAME_CHARACTERS: frozenset[str] = frozenset("`\\\r\n\0")

# chdb has no query timeout, and a stalled S3 read can wedge a web worker indefinitely
# (each request also pins ~300MB of RSS for the embedded ClickHouse). Running it in a
# subprocess lets us kill it and degrade to the ClickHouse-cluster fallback.
CHDB_QUERY_TIMEOUT_SECONDS = 30.0

# ClickHouse's Hive-style partition inference guesses a type per partition-folder value it
# samples (e.g. our internal `_ph_partition_key`), independently of the physical column type.
# A table whose partition granularity changed over time (see repartition.py's tiering from
# week -> hour) mixes value shapes across folders — e.g. an hour-tier "2017-06-30T05" next to
# older week-tier folders — and CH can misclassify the column as Date, then fail to parse it.
# HogQLGlobalSettings.use_hive_partitioning disables this for the normal HogQL query path; the
# raw ClickHouse queries below bypass that path and must opt out the same way.
DISABLE_HIVE_PARTITIONING_SETTINGS: dict[str, int] = {"use_hive_partitioning": 0}

_CHDB_SUBPROCESS_SCRIPT = """
import sys

try:
    import chdb

    result = chdb.query(sys.stdin.read(), output_format="CSV")
except Exception as e:
    sys.stderr.write(str(e))
    sys.exit(1)

sys.stdout.write(str(result))
"""


def run_chdb_query(query: str, timeout: float = CHDB_QUERY_TIMEOUT_SECONDS) -> str:
    # The query is passed over stdin because it embeds S3 credentials — argv is world-readable.
    # Errors are re-raised as RuntimeError with chdb's message preserved so callers'
    # error classification (e.g. _is_suppressed_chdb_error) behaves as if chdb ran in-process.
    try:
        process = subprocess.run(
            [sys.executable, "-c", _CHDB_SUBPROCESS_SCRIPT],
            input=query,
            capture_output=True,
            text=True,
            timeout=timeout,
        )
    except subprocess.TimeoutExpired:
        raise RuntimeError(f"chdb query timed out after {timeout}s")

    if process.returncode != 0:
        raise RuntimeError(process.stderr.strip() or f"chdb subprocess exited with code {process.returncode}")

    return process.stdout


class DataWarehouseTableQuerySet(models.QuerySet["DataWarehouseTable"]):
    def queryable(self) -> "DataWarehouseTableQuerySet":
        # A table you can actually query: not soft-deleted, and not orphaned by a soft-deleted source.
        return self.exclude(deleted=True).exclude(external_data_source__deleted=True)


# `Manager.from_queryset(...)` can't be used as a base class here because it also overrides
# `get_queryset()` — mypy/django-stubs can't model that dynamic base. Wire the queryset class in
# manually instead so `objects.queryable()` and the eager-loading `get_queryset()` both work.
class DataWarehouseTableManager(models.Manager["DataWarehouseTable"]):
    _queryset_class = DataWarehouseTableQuerySet

    def get_queryset(self) -> DataWarehouseTableQuerySet:
        return cast(
            DataWarehouseTableQuerySet,
            super()
            .get_queryset()
            .select_related("created_by", "external_data_source")
            .prefetch_related("externaldataschema_set"),
        )

    def queryable(self) -> DataWarehouseTableQuerySet:
        return self.get_queryset().queryable()


def get_hogql_field_for_column(
    column_name: str,
    column_definition: dict[str, Any] | str,
    clickhouse_type: str,
    is_nullable: bool,
) -> DatabaseField:
    if isinstance(column_definition, dict) and column_definition.get("hogql") == "StructDatabaseField":
        child_fields: dict[str, DatabaseField] = {}
        nested_definitions = column_definition.get("fields")
        if isinstance(nested_definitions, dict):
            for nested_name, nested_definition in nested_definitions.items():
                if not isinstance(nested_definition, dict):
                    continue

                nested_clickhouse_type = str(nested_definition.get("clickhouse", "String"))
                nested_is_nullable = False
                if nested_clickhouse_type.startswith("Nullable("):
                    nested_clickhouse_type = nested_clickhouse_type.replace("Nullable(", "")[:-1]
                    nested_is_nullable = True

                child_fields[nested_name] = get_hogql_field_for_column(
                    nested_name,
                    nested_definition,
                    nested_clickhouse_type,
                    nested_is_nullable,
                )

        return StructDatabaseField(name=column_name, nullable=is_nullable, fields=child_fields)

    # Support for 'old' style columns
    if isinstance(column_definition, str):
        hogql_type_str = clickhouse_type.partition("(")[0]
        return LEGACY_CLICKHOUSE_HOGQL_MAPPING[hogql_type_str](name=column_name, nullable=is_nullable)

    return STR_TO_HOGQL_MAPPING.get(
        str(column_definition.get("hogql", "UnknownDatabaseField")),
        STR_TO_HOGQL_MAPPING["UnknownDatabaseField"],
    )(name=column_name, nullable=is_nullable)


def hogql_fields_and_structure_for_columns(
    columns: dict[str, Any],
    modifiers: Optional["HogQLQueryModifiers"] = None,
    column_order: list[str] | None = None,
) -> tuple[dict[str, FieldOrTable], list[str]]:
    """Shared columns → HogQL fields mapping for warehouse and direct virtual tables.

    Structure entries (the S3 table-function column spec) are only meaningful for S3-backed
    tables; direct virtual tables ignore them. ``column_order`` restores the SELECT order the
    jsonb column store drops (see ``reconstruct_ordered_columns``); omit it for column dicts
    whose insertion order is already meaningful.
    """
    fields: dict[str, FieldOrTable] = {}
    structure = []
    for column, type in reconstruct_ordered_columns(columns, column_order):
        # Support for 'old' style columns
        if isinstance(type, str):
            clickhouse_type = type
        else:
            clickhouse_type = type["clickhouse"]

        is_nullable = False

        if clickhouse_type.startswith("Nullable("):
            clickhouse_type = clickhouse_type.replace("Nullable(", "")[:-1]
            is_nullable = True

        # TODO: remove when addressed https://github.com/ClickHouse/ClickHouse/issues/37594
        if clickhouse_type.startswith("Array("):
            clickhouse_type = remove_named_tuples(clickhouse_type)

        if isinstance(type, dict):
            column_invalid = not type.get("valid", True)
        else:
            column_invalid = False

        if not column_invalid or (modifiers is not None and modifiers.s3TableUseInvalidColumns):
            # ClickHouse re-parses this string with its column-declaration parser, so an unescaped
            # backtick closes the identifier and the rest of the name is read as more declaration
            # syntax, up to DEFAULT expressions that run server-side.
            quoted_column = backquote_clickhouse_identifier(column)
            if is_nullable:
                structure.append(f"{quoted_column} Nullable({clickhouse_type})")
            else:
                structure.append(f"{quoted_column} {clickhouse_type}")

        fields[column] = get_hogql_field_for_column(column, type, clickhouse_type, is_nullable)

    return fields, structure


class DataWarehouseTable(CreatedMetaFields, UpdatedMetaFields, UUIDTModel, DeletedMetaFields):
    # loading external_data_source and credentials is easily N+1,
    # so we have a custom object manager meaning people can't forget to load them
    # this also means we _always_ have two joins whenever we load tables
    objects = DataWarehouseTableManager()

    # Use if it's certain externaldataschemas aren't needed
    raw_objects = DataWarehouseTableQuerySet.as_manager()

    # Kept on the model so the nested names and the `choices=` below stay unchanged.
    TableFormat = DataWarehouseTableFormat
    CreatedVia = DataWarehouseTableCreatedVia

    name = models.CharField(max_length=128)
    format = models.CharField(max_length=128, choices=TableFormat)
    team = models.ForeignKey("posthog.Team", on_delete=models.CASCADE)

    url_pattern = models.CharField(max_length=500)
    queryable_folder = models.CharField(max_length=500, null=True, blank=True)
    credential = models.ForeignKey(DataWarehouseCredential, on_delete=models.CASCADE, null=True, blank=True)

    external_data_source = models.ForeignKey("ExternalDataSource", on_delete=models.CASCADE, null=True, blank=True)

    # Where this table came from — the request surface for user-created tables, or the internal
    # path that built it. Derived server-side (never taken from the request body) so a client can't
    # self-label. NULL on rows created before this field existed.
    created_via = models.CharField(max_length=20, choices=CreatedVia, null=True, blank=True)

    columns = models.JSONField(
        default=dict,
        null=True,
        blank=True,
        help_text="Dict of all columns with Clickhouse type (including Nullable())",
    )
    # Postgres jsonb does not preserve `columns` key order, so this records the physical column
    # order captured at write time (for materialized-view backing tables, the view's SELECT order).
    # Null on rows saved before this field existed and on non-materialized tables (they fall back
    # to jsonb key order). Internal only, not exposed through the API.
    column_order = models.JSONField(
        default=None,
        null=True,
        blank=True,
        help_text="Ordered column names capturing physical/SELECT order (columns jsonb loses key order). Not user-facing.",
    )

    options = models.JSONField(default=dict, blank=True)

    row_count = models.IntegerField(null=True, help_text="How many rows are currently synced in this table")
    size_in_s3_mib = models.FloatField(null=True, help_text="The object size in S3 for this table in MiB")

    __repr__ = sane_repr("name")

    class Meta:
        db_table = "posthog_datawarehousetable"

    def save(self, *args: Any, internally_computed_url_pattern: bool = False, **kwargs: Any) -> None:
        if not internally_computed_url_pattern:
            self._reject_client_supplied_url_pattern_change(kwargs.get("update_fields"))
        super().save(*args, **kwargs)

    def clean(self) -> None:
        # Django admin's changeform validates via full_clean() (form.is_valid() -> clean()) before
        # ModelAdmin.save_model() ever calls save() - and unlike DRF's perform_update, save_model
        # doesn't translate a save()-raised ValidationError into a form error, so it would surface
        # as an unhandled 500. Running the same check here lets admin catch it as a normal field
        # error. save()'s check stays the enforcement of record for every other caller (DRF, a
        # management command, a future endpoint), since nothing but ModelForm calls full_clean().
        super().clean()
        self._reject_client_supplied_url_pattern_change(update_fields=None)

    def _reject_client_supplied_url_pattern_change(self, update_fields: Iterable[str] | None) -> None:
        """Block a url_pattern change on a table with no credential, unless the caller declares the
        new value was computed by PostHog's own code rather than taken from request input.

        A table with no credential is read by ClickHouse under the cluster's own S3 role rather than
        a key the team supplied, so its url_pattern is only safe because PostHog chose it. Pipeline
        syncs, saved-query materialization, and the direct-connection upsert helpers all legitimately
        rewrite this field on such tables using values they compute themselves; those call
        ``save(internally_computed_url_pattern=True)`` to say so. Every other caller, present or
        future, is refused by default rather than trusted to have remembered a check elsewhere.
        """
        if self._state.adding:
            return
        if update_fields is not None and "url_pattern" not in update_fields:
            return
        prior = type(self).raw_objects.filter(pk=self.pk).values_list("credential_id", "url_pattern").first()
        if prior is None:
            return
        prior_credential_id, prior_url_pattern = prior
        if prior_credential_id is None and prior_url_pattern != self.url_pattern:
            raise ValidationError(
                "This table has no credential, so its URL is only safe because PostHog set it. "
                "Add an access key and secret before pointing it at a different location."
            )

    @property
    def name_chain(self) -> list[str]:
        return self.name.split(".")

    @property
    def csv_allow_double_quotes(self) -> bool | None:
        return self.options.get("csv_allow_double_quotes")

    def soft_delete(self):
        from products.data_tools.backend.models.join import DataWarehouseJoin

        for join in DataWarehouseJoin.objects.filter(
            Q(team_id=self.team.pk) & (Q(source_table_name=self.name) | Q(joining_table_name=self.name))
        ).exclude(deleted=True):
            join.soft_delete()

        self.deleted = True
        self.deleted_at = timezone.now()
        self.save()

    def table_name_without_prefix(self) -> str:
        if self.external_data_source is not None and self.external_data_source.prefix is not None:
            prefix = self.external_data_source.prefix
        else:
            prefix = ""
        return self.name[len(prefix) :]

    def get_user_facing_columns(self) -> list[dict[str, Any]]:
        """Synced columns as `[{name, data_type, is_nullable}]`, skipping internal plumbing columns.

        Reads the universal `columns` store (populated after every sync for every source type), so it
        works for REST sources (Stripe, Hubspot, …) too — unlike the SQL-only
        `ExternalDataSchema.schema_metadata`. Handles both the dict (`{"clickhouse": ...}`) and the
        legacy plain-string column shapes.

        Curated sources (Stripe, etc.) rename or wrap some raw columns when exposing them via HogQL
        (`created` -> `created_at`, `customer` -> `customer_id`), so `name` is the HogQL-visible name
        callers surface to users and the AI agent — not the raw synced column. To recover the raw ->
        visible mapping (e.g. to match canonical descriptions keyed by raw name), call
        `get_hogql_column_name_mapping(self.table_name_without_prefix())` directly.
        """
        hogql_by_raw = get_hogql_column_name_mapping(self.table_name_without_prefix())
        result: list[dict[str, Any]] = []
        for name, definition in (self.columns or {}).items():
            if name in HIDDEN_COLUMNS:
                continue
            if isinstance(definition, dict):
                clickhouse_type = definition.get("clickhouse") or definition.get("hogql") or ""
            else:
                clickhouse_type = definition or ""
            result.append(
                {
                    "name": hogql_by_raw.get(name, name),
                    "data_type": clean_type(clickhouse_type) if clickhouse_type else "unknown",
                    "is_nullable": "Nullable(" in clickhouse_type,
                }
            )
        return result

    def validate_column_type(
        self,
        column_key: str,
        *,
        user: Optional["User"] = None,
        bypass_warehouse_access_control: bool = False,
    ) -> bool:
        from posthog.hogql.query import execute_hogql_query

        columns = self.columns or {}
        if column_key not in columns:
            raise Exception(f"Column {column_key} does not exist on table: {self.name}")

        try:
            query = ast.SelectQuery(
                select=[ast.Call(name="count", args=[ast.Field(chain=[column_key])])],
                select_from=ast.JoinExpr(table=ast.Field(chain=[self.name])),
            )

            # Deferred: posthog.schema (the pydantic models) stays off django.setup(),
            # where this model loads in every process.
            from posthog.schema import HogQLQueryModifiers  # noqa: PLC0415

            tag_queries(product=Product.WAREHOUSE, feature=Feature.QUERY)
            execute_hogql_query(
                query,
                self.team,
                modifiers=HogQLQueryModifiers(s3TableUseInvalidColumns=True),
                user=user,
                bypass_warehouse_access_control=bypass_warehouse_access_control,
            )
            return True
        except:
            return False

    def _is_suppressed_chdb_error(self, err: Exception) -> bool:
        return isinstance(err, RuntimeError) and "unsupported deltalake type: timestamp_ntz" in str(err).lower()

    def set_columns(self, columns: dict[str, Any]) -> None:
        """Assign ``columns`` and record its order together.

        The single chokepoint for persisting columns: the caller passes an ordered dict (DESCRIBE /
        SELECT order), and both the jsonb payload and the ordered names are set here so they can
        never drift. Never assign ``self.columns`` directly at a persist site.
        """
        self.columns = columns
        self.column_order = list(columns.keys())

    def get_columns(
        self,
        safe_expose_ch_error: bool = True,
    ) -> DataWarehouseTableIntrospectedColumns:
        result: list[tuple[str, ...]] | None = None
        placeholder_context = HogQLContext(team_id=self.team.pk)
        s3_table_func = build_function_call(
            url=self.url_pattern,
            queryable_folder=self.queryable_folder,
            format="Delta"  # Use deltaLake() to get table schema for evolved tables
            if self.format == "DeltaS3Wrapper"
            else self.format,
            access_key=self.credential.access_key if self.credential else None,
            access_secret=self.credential.access_secret if self.credential else None,
            context=placeholder_context,
            table_size_mib=0,  # Use the non-cluster s3 table function for chdb
        )
        logger = structlog.get_logger(__name__)
        try:
            # chdb hangs in CI during tests
            if TEST:
                raise Exception()

            quoted_placeholders = {k: escape_param_clickhouse(v) for k, v in placeholder_context.values.items()}
            # chdb doesn't support parameterized queries
            chdb_query = f"SET use_hive_partitioning = 0; DESCRIBE TABLE {s3_table_func}" % quoted_placeholders

            # Workaround for chdb not honouring the CSV double-quote setting. The upstream fix
            # (https://github.com/chdb-io/chdb/pull/374) is merged but is not in the pinned 3.3.0,
            # so this SET stays until chdb is upgraded past that release.
            if self._is_csv_format() and self.csv_allow_double_quotes is not None:
                chdb_query = (
                    f"SET format_csv_allow_double_quotes = {1 if self.csv_allow_double_quotes else 0}; {chdb_query}"
                )
            chdb_result = run_chdb_query(chdb_query)
            reader = csv.reader(StringIO(chdb_result))
            result = [tuple(row) for row in reader]
        except Exception as chdb_error:
            if self._is_suppressed_chdb_error(chdb_error):
                logger.debug(chdb_error)
            else:
                capture_exception(chdb_error)

            tag_queries(
                team_id=self.team.pk,
                table_id=self.id,
                warehouse_query=True,
                name="get_columns",
                product=Product.WAREHOUSE,
                feature=Feature.QUERY,
            )

            # The cluster is a little broken right now, and so this can intermittently fail.
            # See https://posthog.slack.com/archives/C076R4753Q8/p1756901693184169 for context
            attempts = 5
            for i in range(attempts):
                try:
                    get_columns_settings: dict[str, int] = dict(DISABLE_HIVE_PARTITIONING_SETTINGS)
                    if self._is_csv_format() and self.csv_allow_double_quotes is not None:
                        get_columns_settings["format_csv_allow_double_quotes"] = (
                            1 if self.csv_allow_double_quotes else 0
                        )
                    result = sync_execute(
                        f"""DESCRIBE TABLE {s3_table_func}""",
                        args=placeholder_context.values,
                        settings=get_columns_settings,
                    )
                    break
                except Exception as err:
                    if i >= attempts - 1:
                        capture_exception(err)
                        if safe_expose_ch_error:
                            self._safe_expose_ch_error(err)
                        else:
                            raise

                    # Pause execution slightly to not overload clickhouse
                    time.sleep(2**i)

        if result is None:
            raise Exception("No columns types provided by clickhouse in get_columns")

        columns: DataWarehouseTableIntrospectedColumns = {}
        for item in result:
            column_name = str(item[0])
            if REJECTED_COLUMN_NAME_CHARACTERS.intersection(column_name):
                raise Exception(
                    f"PostHog can't use the column name {column_name!r}. Column names can't contain "
                    "backticks, backslashes, line breaks, or null bytes. Rename the column, then try again."
                )
            columns[column_name] = DataWarehouseTableIntrospectedColumn(
                hogql=CLICKHOUSE_HOGQL_MAPPING[clean_type(str(item[1]))].__name__,
                clickhouse=item[1],
                valid=True,
            )

        return columns

    def get_max_value_for_column(self, column: str) -> Any | None:
        try:
            placeholder_context = HogQLContext(team_id=self.team.pk)
            s3_table_func = build_function_call(
                url=self.url_pattern,
                queryable_folder=self.queryable_folder,
                format=self.format,
                access_key=self.credential.access_key if self.credential else None,
                access_secret=self.credential.access_secret if self.credential else None,
                context=placeholder_context,
                table_size_mib=self.size_in_s3_mib,
            )

            tag_queries(
                team_id=self.team.pk,
                table_id=self.id,
                warehouse_query=True,
                name="get_max_value_for_column",
                product=Product.WAREHOUSE,
                feature=Feature.QUERY,
            )
            result = sync_execute(
                f"SELECT max({escape_clickhouse_identifier(column)}) FROM {s3_table_func}",
                args=placeholder_context.values,
                settings=DISABLE_HIVE_PARTITIONING_SETTINGS,
            )

            return result[0][0]
        except ClickHouseServerException as err:
            # CANNOT_EXTRACT_TABLE_STRUCTURE (636) is expected when the provided S3 path
            # has no non-empty/readable files for the configured format (e.g. before the
            # first successful sync). The caller handles a None return by resetting and
            # triggering a refresh.
            if err.code != 636:
                capture_exception(err)
            return None
        except Exception as err:
            capture_exception(err)
            return None

    def get_count(self, safe_expose_ch_error=True) -> int:
        placeholder_context = HogQLContext(team_id=self.team.pk)
        s3_table_func = build_function_call(
            url=self.url_pattern,
            queryable_folder=self.queryable_folder,
            format=self.format,
            access_key=self.credential.access_key if self.credential else None,
            access_secret=self.credential.access_secret if self.credential else None,
            context=placeholder_context,
            table_size_mib=0,  # Use the non-cluster s3 table function for chdb
        )
        try:
            # chdb hangs in CI during tests
            if TEST:
                raise Exception()

            quoted_placeholders = {k: escape_param_clickhouse(v) for k, v in placeholder_context.values.items()}
            # chdb doesn't support parameterized queries
            chdb_query = f"SET use_hive_partitioning = 0; SELECT count() FROM {s3_table_func}" % quoted_placeholders

            chdb_result = run_chdb_query(chdb_query)
            reader = csv.reader(StringIO(chdb_result))
            result = [tuple(row) for row in reader]
        except Exception as chdb_error:
            capture_exception(chdb_error)

            try:
                tag_queries(
                    team_id=self.team.pk,
                    table_id=self.id,
                    warehouse_query=True,
                    name="get_count",
                    product=Product.WAREHOUSE,
                    feature=Feature.QUERY,
                )

                result = sync_execute(
                    f"SELECT count() FROM {s3_table_func}",
                    args=placeholder_context.values,
                    settings=DISABLE_HIVE_PARTITIONING_SETTINGS,
                )
            except Exception as err:
                capture_exception(err)
                if safe_expose_ch_error:
                    self._safe_expose_ch_error(err)
                else:
                    raise

        return int(result[0][0])

    def get_function_call(self) -> tuple[str, HogQLContext]:
        try:
            placeholder_context = HogQLContext(team_id=self.team.pk)
            s3_table_func = build_function_call(
                url=self.url_pattern,
                queryable_folder=self.queryable_folder,
                format=self.format,
                access_key=self.credential.access_key if self.credential else None,
                access_secret=self.credential.access_secret if self.credential else None,
                context=placeholder_context,
                table_size_mib=self.size_in_s3_mib,
            )

        except Exception as err:
            capture_exception(err)
            raise
        return s3_table_func, placeholder_context

    def _direct_columns_are_complete(self) -> bool:
        """Whether this direct table's stored columns are the complete physical schema — i.e. no
        column-picker restriction (`ExternalDataSchema.enabled_columns`) is in effect. Only then may
        a direct `SELECT *` pass through literally; otherwise the fields are a subset and the star
        must expand from them. Reads the schema rows preloaded onto this instance by
        `_preload_active_external_data_schemas` (every direct-query DB build path calls it before
        `hogql_definition`); if they aren't preloaded, returns False (safe: expand) rather than issue
        a query on this hot table-build path."""
        schema_rows = self.__dict__.get("_active_external_data_schemas")
        if schema_rows is None:
            return False
        return len(schema_rows) > 0 and all(row.enabled_columns is None for row in schema_rows)

    def hogql_definition(
        self, modifiers: Optional["HogQLQueryModifiers"] = None
    ) -> (
        HogQLDataWarehouseTable
        | DirectPostgresTable
        | DirectMySQLTable
        | DirectSnowflakeTable
        | DirectRedshiftTable
        | DirectClickHouseTable
        | DirectMotherDuckTable
        | DirectTrinoTable
    ):
        # Deferred: importing data_warehouse's facade at module scope creates an import cycle
        # (data_warehouse models -> this model package -> data_warehouse.facade.sources -> ...).
        # These direct-query option keys are only needed here, at query-build time.
        from products.data_warehouse.backend.facade.sources import (  # noqa: PLC0415 — breaks an import cycle
            DIRECT_CLICKHOUSE_DATABASE_OPTION,
            DIRECT_CLICKHOUSE_TABLE_OPTION,
            DIRECT_MOTHERDUCK_CATALOG_OPTION,
            DIRECT_MOTHERDUCK_SCHEMA_OPTION,
            DIRECT_MOTHERDUCK_TABLE_OPTION,
            DIRECT_MYSQL_SCHEMA_OPTION,
            DIRECT_MYSQL_TABLE_OPTION,
            DIRECT_POSTGRES_CATALOG_OPTION,
            DIRECT_POSTGRES_SCHEMA_OPTION,
            DIRECT_POSTGRES_TABLE_OPTION,
            DIRECT_REDSHIFT_CATALOG_OPTION,
            DIRECT_REDSHIFT_SCHEMA_OPTION,
            DIRECT_REDSHIFT_TABLE_OPTION,
            DIRECT_SNOWFLAKE_CATALOG_OPTION,
            DIRECT_SNOWFLAKE_SCHEMA_OPTION,
            DIRECT_SNOWFLAKE_TABLE_OPTION,
            DIRECT_TRINO_CATALOG_OPTION,
            DIRECT_TRINO_SCHEMA_OPTION,
            DIRECT_TRINO_TABLE_OPTION,
        )

        columns = self.columns or {}

        fields, structure = hogql_fields_and_structure_for_columns(columns, modifiers, column_order=self.column_order)

        if self.external_data_source and self.external_data_source.is_direct_postgres:
            postgres_catalog = (
                self.options.get(DIRECT_POSTGRES_CATALOG_OPTION)
                if isinstance(self.options.get(DIRECT_POSTGRES_CATALOG_OPTION), str)
                else None
            )
            postgres_schema = (
                self.options.get(DIRECT_POSTGRES_SCHEMA_OPTION)
                if isinstance(self.options.get(DIRECT_POSTGRES_SCHEMA_OPTION), str)
                else (self.external_data_source.job_inputs or {}).get("schema", "public")
            )
            postgres_table_name = (
                self.options.get(DIRECT_POSTGRES_TABLE_OPTION)
                if isinstance(self.options.get(DIRECT_POSTGRES_TABLE_OPTION), str)
                else self.name
            )
            return DirectPostgresTable(
                name=self.name,
                fields=fields,
                postgres_catalog=postgres_catalog,
                postgres_schema=postgres_schema,
                postgres_table_name=postgres_table_name,
                external_data_source_id=str(self.external_data_source_id),
                source_type=self.external_data_source.source_type,
                connection_metadata=self.external_data_source.connection_metadata,
            )

        if self.external_data_source and self.external_data_source.is_direct_mysql:
            job_inputs = self.external_data_source.job_inputs or {}
            mysql_schema = (
                self.options.get(DIRECT_MYSQL_SCHEMA_OPTION)
                if isinstance(self.options.get(DIRECT_MYSQL_SCHEMA_OPTION), str)
                else job_inputs.get("schema") or job_inputs.get("database", "")
            )
            mysql_table_name = (
                self.options.get(DIRECT_MYSQL_TABLE_OPTION)
                if isinstance(self.options.get(DIRECT_MYSQL_TABLE_OPTION), str)
                else self.name
            )
            return DirectMySQLTable(
                name=self.name,
                fields=fields,
                mysql_schema=mysql_schema,
                mysql_table_name=mysql_table_name,
                external_data_source_id=str(self.external_data_source_id),
                connection_metadata=self.external_data_source.connection_metadata,
            )

        if self.external_data_source and self.external_data_source.is_direct_snowflake:
            job_inputs = self.external_data_source.job_inputs or {}
            snowflake_catalog = (
                self.options.get(DIRECT_SNOWFLAKE_CATALOG_OPTION)
                if isinstance(self.options.get(DIRECT_SNOWFLAKE_CATALOG_OPTION), str)
                else job_inputs.get("database")
            )
            snowflake_schema = (
                self.options.get(DIRECT_SNOWFLAKE_SCHEMA_OPTION)
                if isinstance(self.options.get(DIRECT_SNOWFLAKE_SCHEMA_OPTION), str)
                else job_inputs.get("schema", "")
            )
            snowflake_table_name = (
                self.options.get(DIRECT_SNOWFLAKE_TABLE_OPTION)
                if isinstance(self.options.get(DIRECT_SNOWFLAKE_TABLE_OPTION), str)
                else self.name
            )
            return DirectSnowflakeTable(
                name=self.name,
                fields=fields,
                snowflake_catalog=snowflake_catalog,
                snowflake_schema=snowflake_schema,
                snowflake_table_name=snowflake_table_name,
                external_data_source_id=str(self.external_data_source_id),
                connection_metadata=self.external_data_source.connection_metadata,
            )

        if self.external_data_source and self.external_data_source.is_direct_redshift:
            # Redshift is a Postgres fork and reuses DirectPostgresTable's schema-qualified,
            # double-quoted table-reference rendering (see DirectRedshiftTable).
            job_inputs = self.external_data_source.job_inputs or {}
            redshift_catalog = (
                self.options.get(DIRECT_REDSHIFT_CATALOG_OPTION)
                if isinstance(self.options.get(DIRECT_REDSHIFT_CATALOG_OPTION), str)
                else job_inputs.get("database")
            )
            redshift_schema = (
                self.options.get(DIRECT_REDSHIFT_SCHEMA_OPTION)
                if isinstance(self.options.get(DIRECT_REDSHIFT_SCHEMA_OPTION), str)
                else job_inputs.get("schema", "public")
            )
            redshift_table_name = (
                self.options.get(DIRECT_REDSHIFT_TABLE_OPTION)
                if isinstance(self.options.get(DIRECT_REDSHIFT_TABLE_OPTION), str)
                else self.name
            )
            return DirectRedshiftTable(
                name=self.name,
                fields=fields,
                postgres_catalog=redshift_catalog,
                postgres_schema=redshift_schema,
                postgres_table_name=redshift_table_name,
                external_data_source_id=str(self.external_data_source_id),
                connection_metadata=self.external_data_source.connection_metadata,
            )

        # Engine-keyed like ClickHouse (no is_direct_motherduck) to satisfy the source-agnostic
        # guard; the is_direct_query check keeps synced sources' tables S3-backed.
        if (
            self.external_data_source
            and self.external_data_source.is_direct_query
            and self.external_data_source.direct_engine == "motherduck"
        ):
            job_inputs = self.external_data_source.job_inputs or {}
            motherduck_database = (
                self.options.get(DIRECT_MOTHERDUCK_CATALOG_OPTION)
                if isinstance(self.options.get(DIRECT_MOTHERDUCK_CATALOG_OPTION), str)
                else job_inputs.get("database", "")
            )
            motherduck_schema = (
                self.options.get(DIRECT_MOTHERDUCK_SCHEMA_OPTION)
                if isinstance(self.options.get(DIRECT_MOTHERDUCK_SCHEMA_OPTION), str)
                else "main"
            )
            motherduck_table_name = (
                self.options.get(DIRECT_MOTHERDUCK_TABLE_OPTION)
                if isinstance(self.options.get(DIRECT_MOTHERDUCK_TABLE_OPTION), str)
                else self.name
            )
            return DirectMotherDuckTable(
                name=self.name,
                fields=fields,
                motherduck_database=motherduck_database,
                motherduck_schema=motherduck_schema,
                motherduck_table_name=motherduck_table_name,
                external_data_source_id=str(self.external_data_source_id),
                connection_metadata=self.external_data_source.connection_metadata,
                has_complete_columns=self._direct_columns_are_complete(),
            )

        if (
            self.external_data_source
            and self.external_data_source.is_direct_query
            and self.external_data_source.direct_engine == "trino"
        ):
            job_inputs = self.external_data_source.job_inputs or {}
            trino_catalog = (
                self.options.get(DIRECT_TRINO_CATALOG_OPTION)
                if isinstance(self.options.get(DIRECT_TRINO_CATALOG_OPTION), str)
                else job_inputs.get("catalog", "")
            )
            trino_schema = (
                self.options.get(DIRECT_TRINO_SCHEMA_OPTION)
                if isinstance(self.options.get(DIRECT_TRINO_SCHEMA_OPTION), str)
                else job_inputs.get("schema", "")
            )
            trino_table_name = (
                self.options.get(DIRECT_TRINO_TABLE_OPTION)
                if isinstance(self.options.get(DIRECT_TRINO_TABLE_OPTION), str)
                else self.name
            )
            return DirectTrinoTable(
                name=self.name,
                fields=fields,
                trino_catalog=trino_catalog,
                trino_schema=trino_schema,
                trino_table_name=trino_table_name,
                external_data_source_id=str(self.external_data_source_id),
                connection_metadata=self.external_data_source.connection_metadata,
                has_complete_columns=self._direct_columns_are_complete(),
            )

        # Engine-keyed (no is_direct_clickhouse) to satisfy the source-agnostic guard. The
        # is_direct_query check is load-bearing: direct_engine ignores access_method, and a synced
        # source's tables must stay S3-backed — as a direct table, every ordinary query against
        # them fails (the printer's team_id guard doesn't skip DirectSQLTable).
        if (
            self.external_data_source
            and self.external_data_source.is_direct_query
            and self.external_data_source.direct_engine == "clickhouse"
        ):
            job_inputs = self.external_data_source.job_inputs or {}
            # Every direct-ClickHouse table is discovered from the source's single configured
            # database, so the live source config is authoritative. Prefer it over the per-table
            # option, which can be stale — e.g. stored as "default" when the source was first synced
            # before a database was set — and would otherwise resolve to a database that doesn't
            # exist on the server. Fall back to the stored option only when no database is configured.
            configured_database = job_inputs.get("database")
            if isinstance(configured_database, str) and configured_database.strip():
                clickhouse_database = configured_database
            else:
                stored_database = self.options.get(DIRECT_CLICKHOUSE_DATABASE_OPTION)
                clickhouse_database = stored_database if isinstance(stored_database, str) else "default"
            clickhouse_table_name = (
                self.options.get(DIRECT_CLICKHOUSE_TABLE_OPTION)
                if isinstance(self.options.get(DIRECT_CLICKHOUSE_TABLE_OPTION), str)
                else self.name
            )
            return DirectClickHouseTable(
                name=self.name,
                fields=fields,
                clickhouse_database=clickhouse_database,
                clickhouse_table_name=clickhouse_table_name,
                external_data_source_id=str(self.external_data_source_id),
                connection_metadata=self.external_data_source.connection_metadata,
                has_complete_columns=self._direct_columns_are_complete(),
            )

        # Replace fields with any redefined fields if they exist
        external_table_fields = external_tables.get(self.table_name_without_prefix())
        default_fields = external_tables.get("*", {})
        if external_table_fields is not None:
            fields = {**external_table_fields, **default_fields}
        else:
            # Hide the `_dlt` fields from tables
            if fields.get("_dlt_id") and fields.get("_dlt_load_id"):
                del fields["_dlt_id"]
                del fields["_dlt_load_id"]
                fields = {**fields, **default_fields}
            if fields.get("_ph_debug"):
                del fields["_ph_debug"]
                fields = {**fields, **default_fields}
            if fields.get(PARTITION_KEY):
                del fields[PARTITION_KEY]
                fields = {**fields, **default_fields}

        table_def = HogQLDataWarehouseTable(
            name=self.name,
            url=self.url_pattern,
            queryable_folder=self.queryable_folder,
            format=self.format,
            access_key=self.credential.access_key if self.credential else None,
            access_secret=self.credential.access_secret if self.credential else None,
            fields=fields,
            structure=", ".join(structure),
            table_id=str(self.id),
            external_data_source_id=str(self.external_data_source_id) if self.external_data_source_id else None,
            source_type=self.external_data_source.source_type if self.external_data_source else None,
        )

        if self._is_csv_format():
            effective = self.csv_allow_double_quotes if self.csv_allow_double_quotes is not None else False
            table_def.top_level_settings = HogQLQuerySettings(
                format_csv_allow_double_quotes=effective,
            )

        return table_def

    def get_clickhouse_column_type(self, column_name: str) -> Optional[str]:
        columns = self.columns or {}
        clickhouse_type = columns.get(column_name, None)

        if isinstance(clickhouse_type, dict) and columns[column_name].get("clickhouse"):
            clickhouse_type = columns[column_name].get("clickhouse")

            if clickhouse_type.startswith("Nullable("):
                clickhouse_type = clickhouse_type.replace("Nullable(", "")[:-1]

        return clickhouse_type

    def _is_csv_format(self) -> bool:
        return self.format in (
            DataWarehouseTable.TableFormat.CSV,
            DataWarehouseTable.TableFormat.CSVWithNames,
        )

    # ClickHouse error codes from CSV double-quote parse mismatches.
    # Wrong quoting causes ClickHouse to mis-split fields, producing
    # type errors on the mangled values.
    _CSV_PARSE_ERROR_CODES = frozenset(
        {
            27,  # CANNOT_PARSE_INPUT ("expected ',' at end of stream")
            117,  # INCORRECT_DATA ("Expected end of line")
            636,  # CANNOT_EXTRACT_TABLE_STRUCTURE (wraps inner parse errors like 117)
        }
    )

    def _validate_csv_double_quotes_setting(self) -> None:
        """Validate the user-chosen csv_allow_double_quotes setting by trying to parse data rows.
        Raises Exception with a helpful message if parsing fails."""
        setting = self.csv_allow_double_quotes
        tag_queries(
            team_id=self.team.pk,
            table_id=self.id,
            warehouse_query=True,
            name="validate_csv_double_quotes",
            product=Product.WAREHOUSE,
            feature=Feature.QUERY,
        )
        try:
            ctx = HogQLContext(team_id=self.team.pk)
            func = build_function_call(
                url=self.url_pattern,
                queryable_folder=self.queryable_folder,
                format=self.format,
                access_key=self.credential.access_key if self.credential else None,
                access_secret=self.credential.access_secret if self.credential else None,
                context=ctx,
                table_size_mib=0,
            )
            sync_execute(
                f"SELECT 1 FROM {func} LIMIT 100",
                args=ctx.values,
                settings={**DISABLE_HIVE_PARTITIONING_SETTINGS, "format_csv_allow_double_quotes": 1 if setting else 0},
            )
        except ClickHouseServerException as e:
            if e.code in self._CSV_PARSE_ERROR_CODES:
                other_label = "Literal quotes" if setting else "RFC 4180 double quotes"
                raise Exception(
                    f"CSV parsing failed with the selected quote setting. Try selecting '{other_label}' instead."
                )
            raise

    def _safe_expose_ch_error(self, err):
        # Match ExtractErrors against the raw ClickHouse message: wrap_clickhouse_query_error may
        # rewrite the message for some codes (e.g. STD_EXCEPTION), which would hide the substrings
        # we key on here.
        raw_message = err.message if isinstance(err, ClickHouseServerException) else str(err)
        err = wrap_clickhouse_query_error(err)

        # Only ClickHouse ServerException-derived errors carry a `.message`. Everything else —
        # transient connection/read errors (e.g. an EOFError from a dropped ClickHouse socket) and
        # already-translated APIExceptions like ClickHouseAtCapacity — has no `.message`, so re-raise
        # it untouched. Masking these as a storage-bucket misconfiguration would hide a retryable
        # error (or an already user-safe one) behind a misleading user-facing message.
        if not hasattr(err, "message"):
            raise err

        # A cancelled query here means our own client timed out reading, not a bad file or bucket.
        if classify_query_error(err) == QueryErrorCategory.CANCELLED:
            raise Exception(
                "Reading the files from your storage bucket took too long and the query was cancelled. "
                "This is usually temporary - try again, or narrow the URL pattern if the dataset is very large."
            )

        # ClickHouse's own deltaLake() S3 table function hits the same transient object-store
        # blips as delta-rs (see TRANSIENT_OBJECT_STORE_ERRORS), just wrapped in a ClickHouse
        # exception instead of an OSError/DeltaError. Recognize it here too, before the generic
        # bucket-misconfiguration fallback below, so it's classified as retryable instead of
        # blamed on the customer's credentials or URL pattern.
        # Deferred: pipelines.core.delta.errors pulls in posthog.temporal.common.errors ->
        # temporalio, which must stay off django.setup(), where this model loads in every process.
        from products.warehouse_sources.backend.temporal.data_imports.pipelines.core.delta.errors import (  # noqa: PLC0415
            TRANSIENT_OBJECT_STORE_ERRORS,
            TransientObjectStoreError,
        )

        if any(needle in raw_message for needle in TRANSIENT_OBJECT_STORE_ERRORS):
            raise TransientObjectStoreError(raw_message)

        for key, value in ExtractErrors.items():
            if key in raw_message:
                raise Exception(value)

        raise Exception(
            "Could not read the files from your storage bucket. Check that the files URL pattern, file format, "
            "and credentials are correct, then try again."
        )


@database_sync_to_async
def get_table_by_url_pattern_and_source(url_pattern: str, source_id: UUID, team_id: int) -> DataWarehouseTable:
    return DataWarehouseTable.objects.filter(Q(deleted=False) | Q(deleted__isnull=True)).get(
        team_id=team_id, external_data_source_id=source_id, url_pattern=url_pattern
    )


@database_sync_to_async
def get_table_by_schema_id(schema_id: str, team_id: int):
    return ExternalDataSchema.objects.get(id=schema_id, team_id=team_id).table


def create_datawarehousetable(**kwargs: Any) -> DataWarehouseTable:
    return DataWarehouseTable.objects.create(**kwargs)


@database_sync_to_async
def acreate_datawarehousetable(**kwargs: Any) -> DataWarehouseTable:
    return create_datawarehousetable(**kwargs)


@database_sync_to_async
def asave_datawarehousetable(table: DataWarehouseTable) -> None:
    # Saved-query materialization is the only caller: it computes url_pattern itself from the
    # backing DataWarehouseSavedQuery rather than taking it from request input.
    table.save(internally_computed_url_pattern=True)
