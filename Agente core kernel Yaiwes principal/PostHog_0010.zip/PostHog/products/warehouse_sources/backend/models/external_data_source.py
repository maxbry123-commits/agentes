from uuid import UUID

from django.db import models
from django.utils import timezone

import structlog

from posthog.helpers.encrypted_fields import EncryptedJSONField
from posthog.models.activity_logging.model_activity import ModelActivityMixin
from posthog.models.utils import CreatedMetaFields, DeletedMetaFields, UpdatedMetaFields, UUIDTModel, sane_repr
from posthog.sync import database_sync_to_async

from products.warehouse_sources.backend.types import (
    DIRECT_ENGINE_BY_SOURCE_TYPE,
    ExternalDataSchemaSyncFrequency,
    ExternalDataSourceAccessMethod,
    ExternalDataSourceCreatedVia,
    ExternalDataSourceStatus,
    ExternalDataSourceType,
    ManagedWarehouseSQLMode,
    external_data_source_type_choices,
)

logger = structlog.get_logger(__name__)

MANAGED_WAREHOUSE_SOURCE_PREFIX = "managed_warehouse"
MANAGED_WAREHOUSE_PROJECT_READER_CREDENTIAL_KIND = "project_reader"
MANAGED_WAREHOUSE_SERVICE_CREDENTIAL_KIND = "duckgres_service"
MANAGED_WAREHOUSE_LEGACY_CREDENTIAL_KINDS = frozenset({"org_root", "stored_server_login"})
SYSTEM_MANAGED_SOURCE_PREFIXES = frozenset({MANAGED_WAREHOUSE_SOURCE_PREFIX})


class ExternalDataSourceManager(models.Manager):
    def get_queryset(self):
        return super().get_queryset().select_related("revenue_analytics_config")


class ExternalDataSource(ModelActivityMixin, CreatedMetaFields, UpdatedMetaFields, UUIDTModel, DeletedMetaFields):
    # Kept on the model so the nested names and the `choices=` below stay unchanged.
    AccessMethod = ExternalDataSourceAccessMethod
    CreatedVia = ExternalDataSourceCreatedVia
    Status = ExternalDataSourceStatus

    # Deprecated, use `ExternalDataSchema.SyncFrequency`
    SyncFrequency = ExternalDataSchemaSyncFrequency

    source_id = models.CharField(max_length=400)
    connection_id = models.CharField(max_length=400)
    destination_id = models.CharField(max_length=400, null=True, blank=True)
    team = models.ForeignKey("posthog.Team", on_delete=models.CASCADE)

    # Deprecated, use `ExternalDataSchema.sync_frequency_interval`
    sync_frequency = models.CharField(max_length=128, choices=SyncFrequency, default=SyncFrequency.DAILY, blank=True)

    # `status` is deprecated in favour of external_data_schema.status
    status = models.CharField(max_length=400)
    source_type = models.CharField(max_length=128, choices=external_data_source_type_choices)
    # Pinned vendor API version (opaque vendor label, e.g. a Stripe date version). NULL resolves
    # to the source's `default_version` at sync time. A dedicated column (not `job_inputs`) so the
    # pin is queryable via the `data_warehouse_sources` HogQL system table — `job_inputs` is
    # encrypted at rest.
    api_version = models.CharField(max_length=128, null=True, blank=True)
    job_inputs = EncryptedJSONField(null=True, blank=True)
    connection_metadata = models.JSONField(default=dict, blank=True, null=True)
    are_tables_created = models.BooleanField(default=False)
    prefix = models.CharField(max_length=100, null=True, blank=True)
    description = models.CharField(max_length=400, null=True, blank=True)
    # How this source was created — e.g. web UI, direct API call, or MCP tool. Required for new rows
    # via the serializer; NULL on historical rows created before this field existed.
    created_via = models.CharField(max_length=20, choices=CreatedVia, null=True, blank=True)
    access_method = models.CharField(max_length=32, choices=AccessMethod, default=AccessMethod.WAREHOUSE)
    # Lets a synced (warehouse) source also be live-queryable via direct connection; ignored for pure direct sources.
    # Off by default — a user opts a synced source in explicitly before it becomes live-queryable.
    direct_query_enabled = models.BooleanField(default=False)
    # Auto-enable syncing for schemas discovered after source creation (both the scheduled
    # discovery pass and manual "Pull new schemas"). Off by default — per-source opt-in.
    auto_sync_new_schemas = models.BooleanField(default=False)
    # Optional list of fnmatch-style globs (e.g. ["raw_*"]) restricting which newly discovered
    # schema names auto-sync; matched case-insensitively against both the qualified and bare
    # table name. Null/empty means every new schema qualifies.
    auto_sync_schema_patterns = models.JSONField(null=True, blank=True)

    # DEPRECATED: Check inside `revenue_analytics_config` instead
    revenue_analytics_enabled = models.BooleanField(default=False, blank=True, null=True)

    objects = ExternalDataSourceManager()

    __repr__ = sane_repr("id", "source_id", "connection_id", "destination_id", "team_id")

    class Meta:
        db_table = "posthog_externaldatasource"

    @property
    def is_direct_query(self) -> bool:
        return self.access_method == self.AccessMethod.DIRECT

    @property
    def is_direct_postgres(self) -> bool:
        return self.is_direct_query and self.source_type == ExternalDataSourceType.POSTGRES

    @property
    def is_direct_mysql(self) -> bool:
        return self.is_direct_query and self.source_type == ExternalDataSourceType.MYSQL

    @property
    def is_direct_snowflake(self) -> bool:
        return self.is_direct_query and self.source_type == ExternalDataSourceType.SNOWFLAKE

    @property
    def is_direct_redshift(self) -> bool:
        return self.is_direct_query and self.source_type == ExternalDataSourceType.REDSHIFT

    @property
    def is_system_managed(self) -> bool:
        metadata = self.connection_metadata
        return isinstance(metadata, dict) and metadata.get("system_managed") is True

    @property
    def has_managed_warehouse_prefix(self) -> bool:
        return self.prefix == MANAGED_WAREHOUSE_SOURCE_PREFIX

    @property
    def is_managed_warehouse(self) -> bool:
        metadata = self.connection_metadata
        return (
            self.source_type == ExternalDataSourceType.POSTGRES
            and self.access_method == self.AccessMethod.DIRECT
            and self.has_managed_warehouse_prefix
            and self.is_system_managed
            and isinstance(metadata, dict)
            and metadata.get("engine") == "duckdb"
        )

    @classmethod
    def managed_warehouse_identity_q(cls) -> models.Q:
        return models.Q(
            source_type=ExternalDataSourceType.POSTGRES,
            access_method=cls.AccessMethod.DIRECT,
            prefix=MANAGED_WAREHOUSE_SOURCE_PREFIX,
            connection_metadata__engine="duckdb",
            connection_metadata__system_managed=True,
        )

    @classmethod
    def legacy_managed_warehouse_q(cls) -> models.Q:
        return cls.managed_warehouse_identity_q() & models.Q(
            direct_query_enabled=True,
            connection_metadata__credential_kind__in=MANAGED_WAREHOUSE_LEGACY_CREDENTIAL_KINDS,
        )

    @classmethod
    def ready_managed_warehouse_q(cls) -> models.Q:
        return (
            cls.managed_warehouse_identity_q()
            & models.Q(direct_query_enabled=True)
            & (
                models.Q(connection_metadata__credential_kind=MANAGED_WAREHOUSE_SERVICE_CREDENTIAL_KIND)
                | models.Q(
                    connection_metadata__credential_kind=MANAGED_WAREHOUSE_PROJECT_READER_CREDENTIAL_KIND,
                    connection_metadata__reader_configured=True,
                )
            )
        )

    @classmethod
    def dynamic_managed_warehouse_q(cls) -> models.Q:
        return cls.managed_warehouse_identity_q() & models.Q(
            direct_query_enabled=True,
            connection_metadata__credential_kind=MANAGED_WAREHOUSE_SERVICE_CREDENTIAL_KIND,
        )

    def _has_valid_managed_warehouse_connection_inputs(self, *, expected_user: str | None = None) -> bool:
        job_inputs = self.job_inputs
        if not isinstance(job_inputs, dict):
            return False

        port = job_inputs.get("port")
        if isinstance(port, bool):
            return False
        if isinstance(port, int):
            port_number = port
        elif isinstance(port, str) and port.isdigit():
            port_number = int(port)
        else:
            return False

        user = job_inputs.get("user")
        return (
            isinstance(user, str)
            and bool(user)
            and (expected_user is None or user == expected_user)
            and isinstance(job_inputs.get("host"), str)
            and bool(job_inputs["host"].strip())
            and isinstance(job_inputs.get("database"), str)
            and bool(job_inputs["database"].strip())
            and isinstance(job_inputs.get("password"), str)
            and bool(job_inputs["password"])
            and 1 <= port_number <= 65535
        )

    @property
    def is_legacy_managed_warehouse(self) -> bool:
        metadata = self.connection_metadata
        return (
            self.is_managed_warehouse
            and isinstance(metadata, dict)
            and metadata.get("credential_kind") in MANAGED_WAREHOUSE_LEGACY_CREDENTIAL_KINDS
        )

    @property
    def is_managed_warehouse_ready(self) -> bool:
        metadata = self.connection_metadata
        if (
            not self.is_managed_warehouse
            or not self.direct_query_enabled
            or not isinstance(metadata, dict)
            or metadata.get("credential_kind") != MANAGED_WAREHOUSE_PROJECT_READER_CREDENTIAL_KIND
            or metadata.get("reader_configured") is not True
        ):
            return False

        return self._has_valid_managed_warehouse_connection_inputs(expected_user=f"posthog_team_{self.team_id}")

    @property
    def is_dynamic_managed_warehouse(self) -> bool:
        metadata = self.connection_metadata
        return (
            self.is_managed_warehouse
            and self.direct_query_enabled
            and isinstance(metadata, dict)
            and metadata.get("credential_kind") == MANAGED_WAREHOUSE_SERVICE_CREDENTIAL_KIND
            and isinstance(metadata.get("lifecycle_generation"), int)
            and not isinstance(metadata.get("lifecycle_generation"), bool)
            and metadata["lifecycle_generation"] >= 0
            and self.job_inputs == {}
        )

    @property
    def managed_warehouse_sql_mode(self) -> ManagedWarehouseSQLMode:
        # Accepted interim contract for the default-off rollout: provisioning already exposes organization-root
        # access, so duckgres_service is intentionally the built-in organization connection. Project-scoped grants
        # require future Duckgres authorization support.
        if self.is_dynamic_managed_warehouse or self.is_managed_warehouse_ready:
            return ManagedWarehouseSQLMode.BUILT_IN
        if (
            self.is_legacy_managed_warehouse
            and self.direct_query_enabled
            and self._has_valid_managed_warehouse_connection_inputs()
        ):
            return ManagedWarehouseSQLMode.EXTERNAL
        return ManagedWarehouseSQLMode.UNAVAILABLE

    @classmethod
    def is_system_managed_prefix(cls, prefix: str | None) -> bool:
        return isinstance(prefix, str) and prefix.strip() in SYSTEM_MANAGED_SOURCE_PREFIXES

    @property
    def direct_engine(self) -> str | None:
        """The direct-SQL engine for this source's type, or None if no engine maps to it.

        This keys off ``source_type`` only and ignores ``access_method``/toggles — a non-None
        result means "an engine exists for this type", not "this source is queryable". Whether a
        source may actually be queried live is decided by ``is_direct_capable`` and the adapters.
        """
        return DIRECT_ENGINE_BY_SOURCE_TYPE.get(self.source_type)

    @property
    def supports_scheduled_sync(self) -> bool:
        return not self.is_direct_query

    @property
    def revenue_analytics_config_safe(self):
        """
        Safely access revenue_analytics_config with automatic creation fallback.
        Use this instead of direct access when you need to guarantee the config exists.
        """
        from products.data_warehouse.backend.facade.models import ExternalDataSourceRevenueAnalyticsConfig

        try:
            return self.revenue_analytics_config
        except ExternalDataSourceRevenueAnalyticsConfig.DoesNotExist:
            config, _ = ExternalDataSourceRevenueAnalyticsConfig.objects.get_or_create(
                external_data_source=self,
                defaults={
                    "enabled": self.source_type == ExternalDataSourceType.STRIPE,
                },
            )
            return config

    def soft_delete(self):
        self.deleted = True
        self.deleted_at = timezone.now()
        self.save()

        # Lazy import to avoid circular: SourceRegistry → helpers.py → this module.
        from products.warehouse_sources.backend.temporal.data_imports.sources.common.registry import SourceRegistry

        SourceRegistry.get_source(ExternalDataSourceType(self.source_type)).cleanup_cdc_resources_on_deletion(self)

    def reload_schemas(self):
        # temporalio at module scope would put the Temporal client on the django.setup() path —
        # this is a models module; the service import below pulls it anyway, but only at call time
        import temporalio.service  # noqa: PLC0415

        from products.data_warehouse.backend.facade.api import (
            sync_external_data_job_workflow,
            trigger_external_data_workflow,
        )
        from products.warehouse_sources.backend.models.external_data_schema import ExternalDataSchema

        if not self.supports_scheduled_sync:
            return

        for schema in (
            ExternalDataSchema.objects.filter(team_id=self.team.pk, source_id=self.id, should_sync=True)
            .exclude(deleted=True)
            .all()
        ):
            try:
                trigger_external_data_workflow(schema)
            except temporalio.service.RPCError as e:
                if e.status == temporalio.service.RPCStatusCode.NOT_FOUND:
                    sync_external_data_job_workflow(schema, create=True, should_sync=True)

            except Exception as e:
                logger.exception(f"Could not trigger external data job for schema {schema.name}", exc_info=e)


@database_sync_to_async
def get_external_data_source(source_id: UUID) -> ExternalDataSource:
    return ExternalDataSource.objects.get(pk=source_id)


def get_direct_external_data_source_for_connection(
    team_id: int, connection_id: str | None
) -> ExternalDataSource | None:
    if not connection_id:
        return None

    try:
        source_uuid = UUID(connection_id)
    except ValueError:
        return None

    # Function-local: capability imports this module (circular); also keeps direct-SQL drivers off django.setup().
    from posthog.hogql.direct_sql.capability import is_direct_capable  # noqa: PLC0415

    source = (
        ExternalDataSource.objects.filter(
            team_id=team_id,
            id=source_uuid,
        )
        .exclude(deleted=True)
        .defer("job_inputs")
        .first()
    )
    if source is None or not is_direct_capable(source):
        return None

    if source.has_managed_warehouse_prefix and source.managed_warehouse_sql_mode == ManagedWarehouseSQLMode.UNAVAILABLE:
        return None
    return source


def is_managed_warehouse_connection_ready(team_id: int, connection_id: str | None) -> bool:
    if not connection_id:
        return False

    try:
        source_uuid = UUID(connection_id)
    except ValueError:
        return False

    source = (
        ExternalDataSource.objects.filter(
            team_id=team_id,
            id=source_uuid,
            prefix=MANAGED_WAREHOUSE_SOURCE_PREFIX,
        )
        .exclude(deleted=True)
        .first()
    )
    return source is not None and source.managed_warehouse_sql_mode == ManagedWarehouseSQLMode.BUILT_IN
