import os
import logging
from typing import Any, Optional

from django.core.management.base import BaseCommand

from structlog import get_logger

from posthog.schema import (
    SourceConfig,
    SourceFieldFileUploadConfig,
    SourceFieldInputConfig,
    SourceFieldInputConfigType,
    SourceFieldOauthAccountSelectConfig,
    SourceFieldOauthConfig,
    SourceFieldSelectConfig,
    SourceFieldSelectConfigConverter,
    SourceFieldSSHTunnelConfig,
    SourceFieldSwitchGroupConfig,
)

from products.warehouse_sources.backend.temporal.data_imports.sources import SourceRegistry
from products.warehouse_sources.backend.types import ExternalDataSourceType

logger = get_logger(__name__)
logger.setLevel(logging.INFO)


# Generates `@config.Config` dataclasses to be used by sources to parse inputs from the frontend.
# The source of the configs come from the sources `get_source_config()` method (inherited from `BaseSource`).
# For an example, look at products/warehouse_sources/backend/temporal/data_imports/sources/stripe/source.py

# This file shouldn't often need to be updated unless if we extend what fields sources can have.
# There exists a test file here: products/warehouse_sources/backend/temporal/data_imports/sources/common/test/test_source_config_generator.py

# To start SourceConfigGenerator, run `pnpm generate:source-configs`

# Leftover TODO:
# - allow custom converter options (see meta ads and google ads source)
# - define metadata to add fields onto the config that come from settings, e.g:
#       field: str = config.value(default_factory=config.default_from_settings("ENV_VAR"))
# - Allow types to be given in `SourceFieldFileUploadJsonFormatConfig`


class SourceConfigGenerator:
    def __init__(self):
        self.generated_classes: dict[str, str] = {}
        self.imports: set[str] = set()
        self.typing_import: set[str] = set()
        self.nested_configs: dict[str, str] = {}

    def generate_all_modules(self) -> dict[str, str]:
        """One generated module per source, keyed by module name (`ExternalDataSourceType.<MEMBER>.name.lower()`).

        The module-name rule is shared with `generated_configs/__init__.py`'s
        `get_config_for_source`, which resolves configs by deriving the same name at runtime —
        neither side needs regenerating when a source is added."""
        try:
            sources = SourceRegistry.get_all_sources()
            configs = {name: source.get_source_config for name, source in sources.items()}

            modules: dict[str, str] = {}
            for source_type, source_config in configs.items():
                logger.info(f"Generating config for {source_type}")
                module_name = source_type.name.lower()
                if not module_name.isidentifier():
                    raise ValueError(f"{source_type.name} does not lower() to a valid module name")
                if module_name in modules:
                    raise ValueError(f"Module name collision for {source_type.name}: {module_name}")
                modules[module_name] = self._generate_module(source_type, source_config)
        except Exception as e:
            logger.exception(f"Error generating config: {e}")
            raise

        return modules

    def _generate_module(self, source_type: ExternalDataSourceType, source_config: SourceConfig) -> str:
        self.generated_classes = {}
        self.imports = set()
        self.typing_import = set()
        self.nested_configs = {}
        self.generate_source_config(source_type, source_config)
        return self._build_module()

    def generate_source_config(self, source_type: ExternalDataSourceType, source_config: SourceConfig) -> None:
        self.imports.add("from products.warehouse_sources.backend.temporal.data_imports.sources.common import config")

        class_name = self._get_config_class_name(source_type)
        fields = []
        nested_classes = []

        for field in source_config.fields:
            field_defs, nested = self._process_field(field, class_name, source_config)
            if field_defs:
                fields.extend(field_defs)
            if nested:
                nested_classes.extend(nested)

        config_class = self._generate_config_class(class_name, fields)

        for nested_class in nested_classes:
            nested_name = self._extract_class_name(nested_class)
            self.nested_configs[nested_name] = nested_class

        self.generated_classes[class_name] = config_class

    def _process_field(self, field: Any, parent_class: str, source_config: SourceConfig) -> tuple[list[str], list[str]]:
        """Process a single field and return field definitions and any nested classes."""

        if isinstance(field, SourceFieldInputConfig):
            field_def = self._process_input_field(field)
            return [field_def] if field_def else [], []

        elif isinstance(field, SourceFieldSelectConfig):
            return self._process_select_field(field, parent_class, source_config)

        elif isinstance(field, SourceFieldSwitchGroupConfig):
            field_def, nested_classes = self._process_switch_group_field(field, parent_class, source_config)
            return [field_def] if field_def else [], nested_classes

        elif isinstance(field, SourceFieldOauthConfig):
            field_def = self._process_oauth_field(field)
            return [field_def] if field_def else [], []

        elif isinstance(field, SourceFieldOauthAccountSelectConfig):
            field_def = self._process_oauth_account_select_field(field)
            return [field_def] if field_def else [], []

        elif isinstance(field, SourceFieldFileUploadConfig):
            field_def, nested_class = self._process_file_upload_field(field, parent_class)
            return [field_def] if field_def else [], [nested_class]

        elif isinstance(field, SourceFieldSSHTunnelConfig):
            field_def = self._process_ssh_tunnel_field(field)
            return [field_def] if field_def else [], []

        else:
            logger.info(f"Unknown field type: {type(field)}")
            return [], []

    def _process_input_field(self, field: SourceFieldInputConfig) -> str:
        python_type = self._get_python_type(field.type)

        is_optional = not field.required
        if is_optional:
            python_type = f"{python_type} | None"

        field_parts = []

        converter = self._get_input_converter(field.type, is_optional=is_optional)
        if converter:
            field_parts.append(f"converter={converter}")

        python_field_name, should_alias = self._make_python_identifier(field.name)

        if should_alias:
            field_parts.append(f'alias="{field.name}"')

        if not field.required:
            if field_parts:
                field_parts.append("default_factory=lambda: None")
            else:
                field_def = f"    {python_field_name}: {python_type} = None"
                return field_def

        if field_parts:
            config_value = f"config.value({', '.join(field_parts)})"
            field_def = f"    {python_field_name}: {python_type} = {config_value}"
        else:
            field_def = f"    {python_field_name}: {python_type}"

        return field_def

    def _process_select_field(
        self, field: SourceFieldSelectConfig, parent_class: str, source_config: SourceConfig
    ) -> tuple[list[str], list[str]]:
        has_option_fields = any(option.fields for option in field.options if option.fields)

        if field.multiple:
            if field.converter:
                raise ValueError(f"Select field '{field.name}' cannot combine `multiple` with a converter")
            if has_option_fields:
                raise ValueError(f"Select field '{field.name}' cannot combine `multiple` with per-option fields")

            python_field_name, should_alias = self._make_python_identifier(field.name)
            # Always optional on the dataclass, even when the form field is required: configs
            # stored before the field existed must keep parsing. "At least one value" is the
            # source's job (validate_credentials / effective_* helpers).
            field_parts = ["converter=config.str_to_optional_list"]
            if should_alias:
                field_parts.append(f'alias="{field.name}"')
            field_parts.append("default_factory=lambda: None")
            return [f"    {python_field_name}: list[str] | None = config.value({', '.join(field_parts)})"], []

        field_parts = []

        if not field.required and not field.defaultValue:
            field_parts.append("default_factory=lambda: None")

        if field.defaultValue:
            if field.converter:
                field_parts.append(f'default=config.{field.converter.value}("{field.defaultValue}")')
            else:
                field_parts.append(f'default="{field.defaultValue}"')

        if field.converter:
            field_parts.append(f"converter=config.{field.converter.value}")

        if not has_option_fields:
            literal_type = self._get_select_literal_type(field)

            python_field_name, should_alias = self._make_python_identifier(field.name)

            if should_alias:
                field_parts.append(f'alias="{field.name}"')

            if not field.required:
                literal_type = f"{literal_type} | None"

            if field_parts:
                config_value = f"config.value({', '.join(field_parts)})"
                field_def = f"    {python_field_name}: {literal_type} = {config_value}"
            else:
                field_def = f"    {python_field_name}: {literal_type}"

            return [field_def], []

        nested_classes = []

        # Nested behavior - create nested structure
        nested_class_name = self._get_nested_class_name(field.name, parent_class)

        nested_field_defs = []

        literal_type = self._get_select_literal_type(field)

        if field.defaultValue:
            nested_field_defs.append(f'    selection: {literal_type} = "{field.defaultValue}"')
        else:
            nested_field_defs.append(f"    selection: {literal_type}")

        seen_field_names = set()

        for option in field.options:
            if not option.fields:
                continue

            for option_field in option.fields:
                field_defs, nested = self._process_field(option_field, nested_class_name, source_config)
                if field_defs:
                    for field_def in field_defs:
                        field_name = field_def.split(":")[0].strip()
                        if field_name not in seen_field_names:
                            nested_field_defs.extend(field_defs)
                            seen_field_names.add(field_name)
                if nested:
                    nested_classes.extend(nested)

        nested_config = self._generate_config_class(nested_class_name, nested_field_defs)
        nested_classes.append(nested_config)

        python_field_name, should_alias = self._make_python_identifier(field.name)

        if should_alias:
            if field.required:
                parent_field = f'    {python_field_name}: {nested_class_name} = config.value(alias="{field.name}")'
            else:
                parent_field = f'    {python_field_name}: {nested_class_name} | None = config.value(alias="{field.name}", default_factory=lambda: None)'
        else:
            if field.required:
                parent_field = f"    {python_field_name}: {nested_class_name}"
            else:
                parent_field = f"    {python_field_name}: {nested_class_name} | None = None"

        return [parent_field], nested_classes

    def _process_switch_group_field(
        self, field: SourceFieldSwitchGroupConfig, parent_class: str, source_config: SourceConfig
    ) -> tuple[str, list[str]]:
        """Process a switch group field (like SSH tunnel)."""

        nested_class_name = self._get_nested_class_name(field.name, parent_class)

        nested_fields = ["    enabled: bool = config.value(converter=config.str_to_bool, default=False)"]

        nested_classes = []
        for sub_field in field.fields:
            field_defs, sub_nested = self._process_field(sub_field, nested_class_name, source_config)
            if field_defs:
                nested_fields.extend(field_defs)
            if sub_nested:
                nested_classes.extend(sub_nested)

        nested_config = self._generate_config_class(nested_class_name, nested_fields)
        nested_classes.append(nested_config)

        # Convert dashes to underscores for valid Python field names
        python_field_name, should_alias = self._make_python_identifier(field.name)

        if should_alias:
            # Use alias to map back to original field name with dashes
            field_def = f'    {python_field_name}: {nested_class_name} | None = config.value(alias="{field.name}", default_factory=lambda: None)'
        else:
            field_def = f"    {python_field_name}: {nested_class_name} | None = None"

        return field_def, nested_classes

    def _process_oauth_field(self, field: SourceFieldOauthConfig) -> str:
        python_field_name, should_alias = self._make_python_identifier(field.name)

        if field.required:
            if should_alias:
                return f'    {python_field_name}: int = config.value(alias="{field.name}", converter=config.str_to_int)'
            else:
                return f"    {python_field_name}: int = config.value(converter=config.str_to_int)"
        else:
            if should_alias:
                return f'    {python_field_name}: int | None = config.value(alias="{field.name}", converter=config.str_to_optional_int, default_factory=lambda: None)'
            else:
                return f"    {python_field_name}: int | None = config.value(converter=config.str_to_optional_int, default_factory=lambda: None)"

    def _process_oauth_account_select_field(self, field: SourceFieldOauthAccountSelectConfig) -> str:
        # The selected account/property is persisted as a plain string on the config (e.g. Bing Ads
        # account_id, GSC site_url); the OAuth integration it's scoped to lives in its own field.
        # With `multiple=True` the selection is a list of strings instead (e.g. GitHub repositories).
        python_field_name, should_alias = self._make_python_identifier(field.name)

        if field.multiple:
            # Always optional on the dataclass, even when the form field is required: configs
            # stored before the field existed (e.g. single-repo GitHub sources) must keep parsing.
            # "At least one value" is the source's job (validate_credentials / effective_* helpers).
            field_parts = ["converter=config.str_to_optional_list"]
            if should_alias:
                field_parts.append(f'alias="{field.name}"')
            field_parts.append("default_factory=lambda: None")
            return f"    {python_field_name}: list[str] | None = config.value({', '.join(field_parts)})"

        if field.required:
            if should_alias:
                return f'    {python_field_name}: str = config.value(alias="{field.name}")'
            return f"    {python_field_name}: str"

        if should_alias:
            return f'    {python_field_name}: str | None = config.value(alias="{field.name}", default_factory=lambda: None)'
        return f"    {python_field_name}: str | None = None"

    def _process_file_upload_field(self, field: SourceFieldFileUploadConfig, parent_class: str) -> tuple[str, str]:
        python_field_name, should_alias = self._make_python_identifier(field.name)

        nested_config: str = ""
        literal_type = "dict[str, Any]"

        if isinstance(field.fileFormat.keys, list):
            nested_class_name = self._get_nested_class_name(field.name, parent_class)
            nested_field_defs = []
            for key in field.fileFormat.keys:
                nested_field_defs.append(f"    {key}: str")
            nested_config = self._generate_config_class(nested_class_name, nested_field_defs)
            literal_type = nested_class_name
        else:
            self.typing_import.add("Any")

        if field.required:
            if should_alias:
                return f'    {python_field_name}: {literal_type} = config.value(alias="{field.name}")', nested_config
            else:
                return f"    {python_field_name}: {literal_type}", nested_config
        else:
            if should_alias:
                return (
                    f'    {python_field_name}: {literal_type} | None = config.value(alias="{field.name}", default_factory=lambda: None)',
                    nested_config,
                )
            else:
                return f"    {python_field_name}: {literal_type} | None = None", nested_config

    def _process_ssh_tunnel_field(self, field: SourceFieldSSHTunnelConfig) -> str:
        """Process a SSH tunnel field by referencing the existing SSHTunnelConfig."""

        self.imports.add("from products.warehouse_sources.backend.models.ssh_tunnel import SSHTunnelConfig")

        python_field_name, should_alias = self._make_python_identifier(field.name)

        if should_alias:
            # Use alias to map back to original field name with dashes
            return f'    {python_field_name}: SSHTunnelConfig | None = config.value(alias="{field.name}", default_factory=lambda: None)'
        else:
            return f"    {python_field_name}: SSHTunnelConfig | None = None"

    def _get_python_type(self, field_type: SourceFieldInputConfigType) -> str:
        type_mapping = {
            SourceFieldInputConfigType.TEXT: "str",
            SourceFieldInputConfigType.PASSWORD: "str",
            SourceFieldInputConfigType.EMAIL: "str",
            SourceFieldInputConfigType.NUMBER: "int",
            SourceFieldInputConfigType.TEXTAREA: "str",
        }

        return type_mapping.get(field_type, "str")

    def _get_input_converter(self, field_type: SourceFieldInputConfigType, is_optional: bool = False) -> Optional[str]:
        if field_type == SourceFieldInputConfigType.NUMBER:
            # Use str_to_optional_int for optional NUMBER fields to handle empty strings from the frontend
            return "config.str_to_optional_int" if is_optional else "int"

        return None

    def _get_select_literal_type(self, field: SourceFieldSelectConfig) -> str:
        if not field.converter:
            option_values = [f'"{option.value}"' for option in field.options]
            self.typing_import.add("Literal")
            return f"Literal[{', '.join(option_values)}]"

        if field.converter == SourceFieldSelectConfigConverter.STR_TO_BOOL:
            return "bool"

        if field.converter == SourceFieldSelectConfigConverter.STR_TO_INT:
            return "int"

        if field.converter == SourceFieldSelectConfigConverter.STR_TO_OPTIONAL_INT:
            return "int | None"

        raise ValueError(f"Converter value {field.converter} not recognized")

    def _get_config_class_name(self, source_type: ExternalDataSourceType) -> str:
        return f"{source_type.value}SourceConfig"

    def _get_nested_class_name(self, field_name: str, parent_class: str) -> str:
        parent_prefix = parent_class.replace("SourceConfig", "")

        class_name_part = "".join(word.title() for word in field_name.replace("-", "_").split("_"))

        return f"{parent_prefix}{class_name_part}Config"

    def _sort_fields_by_defaults(self, fields: list[str]) -> list[str]:
        """Sort fields so that fields without defaults come before fields with defaults."""

        fields_without_defaults = []
        fields_with_config_annotations = []
        fields_with_none_default = []
        fields_with_defaults = []

        for field in fields:
            field_content = field.strip()
            if field_content == "pass" or not field_content:
                continue

            has_assignment = " = " in field_content
            has_default = has_assignment and (
                "default=" in field_content or "default_factory=" in field_content or field_content.endswith(" = None")
            )

            if not has_assignment:
                fields_without_defaults.append(field)
            elif has_default and "default_factory=lambda: None" in field_content:
                fields_with_none_default.append(field)
            elif has_default:
                fields_with_defaults.append(field)
            elif "config." in field_content:
                fields_with_config_annotations.append(field)
            else:
                fields_with_defaults.append(field)

        return (
            fields_without_defaults + fields_with_config_annotations + fields_with_none_default + fields_with_defaults
        )

    def _generate_config_class(self, class_name: str, fields: list[str]) -> str:
        if fields:
            sorted_fields = self._sort_fields_by_defaults(fields)
            fields_str = "\n".join(sorted_fields)
        else:
            fields_str = "    pass"

        return f"""@config.config
class {class_name}(config.Config):
{fields_str}"""

    def _make_python_identifier(self, field_name: str) -> tuple[str, bool]:
        if "-" in field_name:
            return field_name.replace("-", "_"), True

        return field_name, False

    def _extract_class_name(self, class_definition: str) -> str:
        lines = class_definition.split("\n")
        for line in lines:
            if line.startswith("class "):
                return line.split("class ")[1].split("(")[0]
        return ""

    def _build_module(self) -> str:
        parts = []

        parts.append("# This file is automatically generated from `SourceRegistry.get_all_sources()`")
        parts.append("# Do not edit manually - run `pnpm generate:source-configs` to regenerate.")
        parts.append("")

        # Match ruff/isort grouping: stdlib (`typing`) first, then a blank line, then first-party.
        stdlib_imports = []
        if self.typing_import:
            stdlib_imports.append(f"from typing import {', '.join(sorted(self.typing_import))}")
        first_party_imports = sorted(self.imports)

        import_groups = [group for group in (stdlib_imports, first_party_imports) if group]
        for group_index, group in enumerate(import_groups):
            if group_index > 0:
                parts.append("")
            parts.extend(group)
        parts.append("")
        parts.append("")

        for class_name in sorted(self.nested_configs.keys()):
            parts.append(self.nested_configs[class_name])
            parts.append("")
            parts.append("")

        for class_name in sorted(self.generated_classes.keys()):
            parts.append(self.generated_classes[class_name])
            parts.append("")
            parts.append("")

        # One trailing newline: drop the final blank separator line
        return "\n".join(parts[:-1])


class Command(BaseCommand):
    help = "Generate @config.config classes from data warehouse source definitions"

    def handle(self, *args, **options):
        logger.info("Generating source configs from SourceRegistry...")

        generator = SourceConfigGenerator()
        modules = generator.generate_all_modules()

        output_dir = os.path.join(
            os.path.dirname(__file__), "..", "..", "temporal", "data_imports", "sources", "generated_configs"
        )
        os.makedirs(output_dir, exist_ok=True)

        for module_name, module_source in modules.items():
            with open(os.path.join(output_dir, f"{module_name}.py"), "w") as f:
                f.write(module_source)

        # __init__.py is hand-written (the runtime resolver); never write it. Remove modules for
        # sources no longer in the registry so a deleted source can't leave stale config classes.
        expected = {f"{name}.py" for name in modules} | {"__init__.py"}
        for stale in set(os.listdir(output_dir)) - expected:
            if stale.endswith(".py"):
                os.remove(os.path.join(output_dir, stale))
                self._remove_pycache(output_dir, stale.removesuffix(".py"))
                logger.info(f"Removed stale generated module: {stale}")

        logger.info(f"Generated {len(modules)} source config modules in: {output_dir}")

    @staticmethod
    def _remove_pycache(output_dir: str, module_name: str) -> None:
        # Drop the removed module's compiled bytecode so a stale `.pyc` can't keep importing.
        pycache_dir = os.path.join(output_dir, "__pycache__")
        if not os.path.isdir(pycache_dir):
            return
        for cached in os.listdir(pycache_dir):
            if cached.startswith(f"{module_name}.") and cached.endswith(".pyc"):
                os.remove(os.path.join(pycache_dir, cached))
