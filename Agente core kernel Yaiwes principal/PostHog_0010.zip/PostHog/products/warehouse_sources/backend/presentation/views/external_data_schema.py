import datetime as dt
from collections.abc import Callable
from typing import Any, Optional, cast

from django.db import transaction

import structlog
import temporalio
from asgiref.sync import async_to_sync
from drf_spectacular.utils import OpenApiResponse, extend_schema, extend_schema_field
from rest_framework import filters, serializers, status, viewsets
from rest_framework.exceptions import MethodNotAllowed, PermissionDenied, ValidationError
from rest_framework.request import Request
from rest_framework.response import Response

from posthog.hogql.database.database import Database

from posthog.api.log_entries import LogEntryRequestSerializer, LogEntrySerializer, fetch_log_entries
from posthog.api.routing import TeamAndOrgViewSetMixin
from posthog.api.utils import action
from posthog.exceptions_capture import capture_exception
from posthog.models.user import User
from posthog.permissions import AccessControlPermission, is_service_auth
from posthog.utils import str_to_bool

from products.access_control.backend.facade.user_access_control import access_level_satisfied_for_resource
from products.access_control.backend.presentation.access_control import UserAccessControlSerializerMixin
from products.data_warehouse.backend.facade.api import (
    cancel_external_data_workflow,
    create_and_register_webhook,
    external_data_workflow_exists,
    get_direct_query_engine,
    get_or_create_webhook_hog_function,
    get_postgres_source_location,
    is_any_external_data_schema_paused,
    is_cdc_enabled_for_team,
    pause_external_data_schedule,
    reconcile_webhook_events,
    sync_cdc_extraction_schedule,
    sync_external_data_job_workflow,
    trigger_external_data_workflow,
    unpause_external_data_schedule,
    update_external_job_status,
)
from products.warehouse_sources.backend.facade.models import (
    ExternalDataJob,
    ExternalDataSchema,
    ExternalDataSource,
    sync_frequency_interval_to_sync_frequency,
    sync_frequency_to_sync_frequency_interval,
    update_sync_type_config_keys,
)
from products.warehouse_sources.backend.facade.pipelines import finish_row_tracking
from products.warehouse_sources.backend.facade.source_management import (
    AnySource,
    RowFilterValidationError,
    SourceRegistry,
    WebhookSource,
    filter_dwh_columns_by_enabled_columns as _filter_dwh_columns_by_enabled_columns,
    get_cdc_adapter,
    purge_buffer_prefix,
    source_type_supports_cdc,
    validate_and_coerce_row_filters,
)
from products.warehouse_sources.backend.facade.types import ExternalDataSourceType, IncrementalFieldType
from products.warehouse_sources.backend.presentation.views.source_api_versions import (
    ExternalDataSourceApiVersionDeprecationSerializer,
    api_version_deprecation_payload,
)

logger = structlog.get_logger(__name__)


def source_supports_column_selection(source_type: str) -> bool:
    """Column selection is available for every registered source: SQL sources project the
    selection into their SELECT, everything else is projected generically just before the
    Delta write. Unknown source types stay False so the UI fails closed.

    Excludes managed-schema sources (Stripe, Paddle, Zendesk): their HogQL tables expose a
    fixed canonical schema, so dropping a referenced column breaks the query."""
    try:
        source = SourceRegistry.get_source(ExternalDataSourceType(source_type))
    except Exception as e:
        capture_exception(e)
        return False
    return not source.has_managed_hogql_schema


def source_supports_row_filters(source_type: str) -> bool:
    try:
        source = SourceRegistry.get_source(ExternalDataSourceType(source_type))
    except Exception as e:
        capture_exception(e)
        return False
    # `bool()` guards against test mocks whose attribute access returns a Mock — orjson can't serialize.
    return bool(source.supports_row_filters)


def source_requires_exact_column_metadata(source_type: str) -> bool:
    """Whether enabled column names are interpolated into a source-side query.

    These sources require exact source identifiers. Warehouse table columns have already
    passed through dlt normalization, so they are not a safe fallback for configuration.

    This is intentionally narrower than ``source_supports_column_selection``: the latter
    also includes sources whose columns are projected generically after extraction.
    """
    try:
        source = SourceRegistry.get_source(ExternalDataSourceType(source_type))
    except Exception as e:
        capture_exception(e)
        # Unknown source types already fail the broader column-selection check. Keep the
        # read path available so a registry failure does not also blank column descriptions.
        return False
    return bool(source.supports_column_selection)


_CDC_WRITE_TARGETS_BY_TABLE_MODE: dict[str, frozenset[str]] = {
    "consolidated": frozenset({"consolidated"}),
    "cdc_only": frozenset({"cdc_history"}),
    "both": frozenset({"consolidated", "cdc_history"}),
}


def _cdc_table_mode_change_needs_resnapshot(old_mode: str | None, new_mode: str | None) -> bool:
    """True when the new mode adds a physical write target (consolidated and/or cdc history table)."""
    if old_mode == new_mode:
        return False
    old_targets = _CDC_WRITE_TARGETS_BY_TABLE_MODE.get(old_mode or "", frozenset())
    new_targets = _CDC_WRITE_TARGETS_BY_TABLE_MODE.get(new_mode or "", frozenset())
    return bool(new_targets - old_targets)


def _reset_cdc_for_full_resnapshot(instance: ExternalDataSchema) -> None:
    """Cancel any running workflow and reset schema state so the next run does a full snapshot.

    Must save before triggering: the workflow reloads the schema and bails via
    `CDCHandledExternally` if it sees `cdc_mode='streaming'`.
    """
    latest_running_job = (
        ExternalDataJob.objects.filter(schema_id=instance.pk, team_id=instance.team_id).order_by("-created_at").first()
    )
    if latest_running_job and latest_running_job.workflow_id and latest_running_job.status == "Running":
        try:
            cancel_external_data_workflow(latest_running_job.workflow_id)
        except temporalio.service.RPCError as e:
            logger.exception(
                "Could not cancel running workflow before re-snapshot",
                schema_id=str(instance.id),
                exc_info=e,
            )

    # Merge under a row lock so the reset can't clobber a concurrent CDC extract activity's
    # sync_type_config writes (and the status/initial_sync_complete save below skips the JSON
    # column, leaving no second window for the merged config to be overwritten).
    instance.sync_type_config = update_sync_type_config_keys(
        instance.id,
        instance.team_id,
        updates={"reset_pipeline": True, "cdc_mode": "snapshot"},
        removes=["cdc_last_log_position", "cdc_deferred_runs"],
    )
    instance.initial_sync_complete = False
    instance.save(update_fields=["initial_sync_complete", "updated_at"])

    try:
        trigger_external_data_workflow(instance)
    except temporalio.service.RPCError as e:
        # Leave the status untouched so the Syncs UI doesn't show RUNNING for a workflow that never
        # started. The sync_type_config mutations stay; the schema's intent is still "do a
        # re-snapshot next run".
        logger.exception(
            "Could not trigger external data workflow after re-snapshot reset",
            schema_id=str(instance.id),
            exc_info=e,
        )
        return

    instance.status = ExternalDataSchema.Status.RUNNING
    instance.save(update_fields=["status", "updated_at"])


# Sync frequencies below the 5-minute floor. No longer accepted as input (dropped from the
# serializer's choices), but rows written before the floor may still carry one until the
# migrate_sub_5min_sync_frequencies command bumps them — so the interval mappings keep parsing
# "1min" and the update path clamps instead of erroring.
LEGACY_SUB_FLOOR_SYNC_FREQUENCIES = {"1min"}
FLOOR_SYNC_FREQUENCY = "5min"


@extend_schema_field(
    {
        "type": "array",
        "nullable": True,
        "items": {
            "type": "object",
            "properties": {
                "column": {"type": "string"},
                # Not an OpenAPI `enum`: the operators are punctuation with no nameable identifier,
                # so orval collapses the enum to duplicate empty-string keys (`'': '>'`, …) in the
                # generated clients. Keep it a plain string and list the allowed values in the
                # description; validation is enforced server-side regardless.
                "operator": {
                    "type": "string",
                    "description": 'One of: > >= < <= = != IN "NOT IN".',
                },
                "value": {
                    "description": (
                        "Comparison value; must match the column's type. For `IN` / `NOT IN`, a "
                        "comma-separated list (e.g. `1, 2, 3` or `'a','b'`)."
                    )
                },
            },
            "required": ["column", "operator", "value"],
        },
    }
)
class RowFiltersField(serializers.JSONField):
    """Typed JSON field for the list of `{column, operator, value}` row-filter predicates."""


def unsupported_row_filter_reason(*, is_direct_query: bool, is_cdc: bool) -> str | None:
    """Row filters are only enforced on snapshot-style syncs, which apply them as a `WHERE`
    clause. Direct-query sources read tables live and CDC streams WAL changes — both bypass that
    query, so a saved filter would silently leave excluded rows visible. Reject those up front.

    This covers every direct engine (Postgres, MySQL, Snowflake): none of the live-query executors
    apply the predicates, so accepting a filter would be a silent data-restriction bypass.
    """
    if is_direct_query:
        return (
            "Row filters are not supported for direct-query sources — "
            "tables are queried live and filters cannot be enforced at the source."
        )
    if is_cdc:
        return (
            "Row filters are not supported for CDC schemas — change-stream rows are "
            "replicated without these predicates, so filtered rows would still sync."
        )
    return None


def _apply_primary_key_columns(
    data: dict[str, Any],
    payload: dict[str, Any],
    instance: Any,
    label: str,
) -> None:
    """Apply primary_key_columns from request data to the sync_type_config payload.

    Raises ValidationError if the PK changed after data has been synced, or if no PK is set.
    """
    new_pk = data.get("primary_key_columns")
    if new_pk:
        old_pk = payload.get("primary_key_columns")
        if new_pk != old_pk and instance.table is not None:
            raise ValidationError(
                "Primary key cannot be changed after data has been synced. "
                "Delete the synced data first, then change the primary key."
            )
        payload["primary_key_columns"] = new_pk
    elif not payload.get("primary_key_columns"):
        raise ValidationError(
            f"{label} requires a primary key on table '{instance.name}'. "
            "Provide primary_key_columns or refresh schema discovery to pick one up."
        )


def schema_display_status(schema: ExternalDataSchema) -> str | None:
    """The user-facing sync status, mapping the two billing-limit statuses to friendly labels.
    Shared by the full and list schema serializers so the labels stay identical."""
    if schema.status == ExternalDataSchema.Status.BILLING_LIMIT_REACHED:
        return "Billing limits"
    if schema.status == ExternalDataSchema.Status.BILLING_LIMIT_TOO_LOW:
        return "Billing limits too low"
    return schema.status


class ExternalDataSchemaSerializer(UserAccessControlSerializerMixin, serializers.ModelSerializer):
    """A schema of an external data source: its sync configuration and the warehouse table it syncs into."""

    table = serializers.SerializerMethodField(read_only=True)
    incremental = serializers.SerializerMethodField(read_only=True)
    status = serializers.SerializerMethodField(read_only=True)
    sync_type = serializers.ChoiceField(
        choices=ExternalDataSchema.SyncType.choices,
        required=False,
        allow_null=True,
        help_text="Sync strategy: incremental, full_refresh, append, cdc, or xmin.",
    )
    incremental_field = serializers.CharField(
        required=False, allow_null=True, help_text="Column name used to track sync progress."
    )
    incremental_field_type = serializers.ChoiceField(
        choices=[(e.value, e.value) for e in IncrementalFieldType],
        required=False,
        allow_null=True,
        help_text="Data type of the incremental field.",
    )
    incremental_field_lookback_seconds = serializers.IntegerField(
        required=False,
        allow_null=True,
        min_value=0,
        max_value=5_184_000,  # 60 days — larger windows defeat incremental efficiency
        help_text=(
            "Seconds to subtract from the stored incremental watermark at sync time, so each "
            "incremental run re-reads a rolling overlap window and catches late or backdated rows. "
            "Applies to timestamp/date incremental fields only. The stored watermark is unchanged. "
            "Maximum 5184000 (60 days)."
        ),
    )
    sync_frequency = serializers.ChoiceField(
        choices=[
            ("never", "never"),
            ("5min", "5min"),
            ("15min", "15min"),
            ("30min", "30min"),
            ("1hour", "1hour"),
            ("6hour", "6hour"),
            ("12hour", "12hour"),
            ("24hour", "24hour"),
            ("7day", "7day"),
            ("30day", "30day"),
        ],
        required=False,
        allow_null=True,
        help_text="How often to sync. The fastest sync frequency is 5 minutes.",
        error_messages={
            "invalid_choice": '"{input}" is not a valid sync frequency. The fastest sync frequency is 5 minutes.'
        },
    )
    sync_time_of_day = serializers.TimeField(
        required=False, allow_null=True, help_text="UTC time of day to run the sync (HH:MM:SS)."
    )
    primary_key_columns = serializers.ListField(
        child=serializers.CharField(),
        required=False,
        allow_null=True,
        help_text="Column names for primary key deduplication.",
    )
    cdc_table_mode = serializers.ChoiceField(
        choices=["consolidated", "cdc_only", "both"],
        required=False,
        allow_null=True,
        help_text="For CDC syncs: consolidated, cdc_only, or both.",
    )
    enabled_columns = serializers.ListField(
        child=serializers.CharField(),
        required=False,
        allow_null=True,
        help_text=(
            "Names of source columns to sync. `null` (default) syncs all columns. "
            "Primary-key columns and the active incremental field are always retained, "
            "even if not listed here."
        ),
    )
    row_filters = RowFiltersField(
        required=False,
        allow_null=True,
        help_text=(
            "Predicates ANDed onto the source query so only matching rows sync. Each is "
            "`{column, operator, value}`; `null`/empty (default) syncs all rows. The operator "
            'must be one of `> >= < <= = != IN "NOT IN"` and the value must match the column\'s '
            "type (for `IN`/`NOT IN`, a comma-separated list like `1, 2, 3` or `'a','b'`). "
            "Applied on the next sync — not retroactive to already-synced rows."
        ),
    )
    api_version = serializers.CharField(
        required=False,
        allow_null=True,
        max_length=128,
        help_text=(
            "Vendor API version override for this schema. `null` (default) syncs on the source's "
            "pinned version. Must be one of the source type's supported versions. User-managed: "
            "version-migration tooling never changes it. Not available for webhook-sync schemas."
        ),
    )
    api_version_deprecation = serializers.SerializerMethodField(
        read_only=True,
        help_text=(
            "Set when this schema's version override is deprecated by the vendor; null when there "
            "is no override or it is not deprecated. The source-level field covers the source pin."
        ),
    )
    available_columns = serializers.SerializerMethodField(
        read_only=True,
        help_text="Column metadata (name, data type, nullable) for this schema. For SQL sources this is the "
        "source-side schema discovered via `refresh_schemas`; for other sources (and once synced) it falls back "
        "to the synced table's columns. Empty only before the first successful sync/refresh.",
    )
    source_column_metadata_available = serializers.SerializerMethodField(
        read_only=True,
        help_text="Whether exact source-side column metadata is available for safe source-query projection.",
    )
    # `source` shadows DRF's reserved `Field.source` attribute, so mypy flags the assignment;
    # the runtime behaviour (a read-only SerializerMethodField backed by get_source) is correct.
    source = serializers.SerializerMethodField(  # type: ignore[assignment]
        read_only=True,
        help_text="Lightweight parent-source summary (id, source_type, access_method, column-selection support, "
        "the requesting user's access level). Only populated on the single-schema retrieve endpoint — `null` "
        "elsewhere — so read-only views can render without fetching the full source and all its schemas.",
    )

    class Meta:
        model = ExternalDataSchema

        fields = [
            "id",
            "name",
            "label",
            "table",
            "should_sync",
            "last_synced_at",
            "latest_error",
            "incremental",
            "status",
            "sync_type",
            "incremental_field",
            "incremental_field_type",
            "incremental_field_lookback_seconds",
            "sync_frequency",
            "sync_time_of_day",
            "description",
            "primary_key_columns",
            "cdc_table_mode",
            "enabled_columns",
            "row_filters",
            "available_columns",
            "source_column_metadata_available",
            "source",
            "api_version",
            "api_version_deprecation",
            "user_access_level",
        ]

        read_only_fields = [
            "id",
            "name",
            "label",
            "table",
            "last_synced_at",
            "latest_error",
            "status",
            "description",
            "available_columns",
            "source_column_metadata_available",
            "source",
            "api_version_deprecation",
            "user_access_level",
        ]

    @extend_schema_field(
        {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "name": {"type": "string"},
                    "data_type": {"type": "string"},
                    "is_nullable": {"type": "boolean"},
                },
                "required": ["name"],
            },
        }
    )
    def get_available_columns(self, schema: ExternalDataSchema) -> list[dict[str, Any]]:
        metadata = schema.schema_metadata or {}
        columns = metadata.get("columns") if isinstance(metadata, dict) else None
        if isinstance(columns, list):
            sql_columns = [
                {
                    "name": column.get("name"),
                    "data_type": column.get("data_type"),
                    "is_nullable": column.get("is_nullable"),
                }
                for column in columns
                if isinstance(column, dict) and isinstance(column.get("name"), str)
            ]
            if sql_columns:
                return sql_columns
        # `schema_metadata` is only written on source creation and explicit schema reload
        # (`refresh_schemas`) — never by background schema discovery or the data sync, and never for
        # non-SQL sources. So it's empty for non-SQL sources and for SQL schemas discovered/added later
        # or not yet reloaded. Fall back to the synced table's universal column store so the Descriptions
        # UI can still list columns (and surface their existing annotations) and let users edit them.
        table = schema.table
        return table.get_user_facing_columns() if table is not None else []

    def get_source_column_metadata_available(self, schema: ExternalDataSchema) -> bool:
        metadata = schema.schema_metadata or {}
        return isinstance(metadata.get("columns"), list) if isinstance(metadata, dict) else False

    @extend_schema_field(
        {
            "type": "object",
            "nullable": True,
            "properties": {
                "id": {"type": "string"},
                "source_type": {"type": "string"},
                "access_method": {"type": "string"},
                "supports_column_selection": {"type": "boolean"},
                "supports_row_filters": {"type": "boolean"},
                "requires_exact_column_metadata": {"type": "boolean"},
                "user_access_level": {"type": "string", "nullable": True},
                "api_version": {"type": "string", "nullable": True},
                "supported_api_versions": {"type": "array", "items": {"type": "string"}},
            },
        }
    )
    def get_source(self, schema: ExternalDataSchema) -> dict[str, Any] | None:
        # Gated to the retrieve action (via `include_source` context) so the source endpoint's
        # nested schema serialization and the schema `list` don't pay for the SourceRegistry lookup.
        if not self.context.get("include_source"):
            return None
        source = schema.source
        user_access_level = None
        view = self.context.get("view")
        user_access_control = getattr(view, "user_access_control", None)
        if user_access_control is not None:
            user_access_level = user_access_control.get_user_access_level(source)
        try:
            source_impl = SourceRegistry.get_source(ExternalDataSourceType(source.source_type))
            # The version the schema falls back to without an override, and the picker's options.
            source_api_version: str | None = source_impl.resolve_api_version(source.api_version)
            supported_api_versions = list(source_impl.supported_versions)
        except ValueError:
            source_api_version = None
            supported_api_versions = []
        return {
            "id": str(source.id),
            "source_type": source.source_type,
            # The schema page hides sync-history UI for direct-query sources, which have no jobs.
            "access_method": source.access_method,
            "supports_column_selection": source_supports_column_selection(source.source_type),
            "supports_row_filters": source_supports_row_filters(source.source_type),
            "requires_exact_column_metadata": source_requires_exact_column_metadata(source.source_type),
            "user_access_level": user_access_level,
            "api_version": source_api_version,
            "supported_api_versions": supported_api_versions,
        }

    def get_user_access_level(self, schema: ExternalDataSchema) -> str | None:  # type: ignore[override]  # narrows the mixin's Model — DRF always dispatches with this serializer's instance
        # The synced table's access, which itself falls back to the source via RESOURCE_FALLBACK_MAP.
        # Drives the row's sync/delete gating in the UI.
        uac = self.user_access_control
        if uac is None:
            return None
        return uac.get_user_access_level(schema.table or schema.source)

    @extend_schema_field(ExternalDataSourceApiVersionDeprecationSerializer(allow_null=True))
    def get_api_version_deprecation(self, schema: ExternalDataSchema) -> dict[str, Any] | None:
        # Only the schema-level override is judged here; a deprecated source pin surfaces on the
        # source, not on every schema that follows it.
        if not schema.api_version:
            return None
        return api_version_deprecation_payload(schema.source.source_type, schema.api_version)

    def validate(self, attrs: dict[str, Any]) -> dict[str, Any]:
        instance = cast(Optional[ExternalDataSchema], self.instance)
        override = attrs["api_version"] if "api_version" in attrs else (instance.api_version if instance else None)
        if override:
            sync_type = attrs.get("sync_type", instance.sync_type if instance else None)
            if sync_type == ExternalDataSchema.SyncType.WEBHOOK:
                raise ValidationError(
                    {
                        "api_version": "API version overrides are not available for webhook-sync schemas — "
                        "webhook payload versions are configured on the source at the vendor."
                    }
                )
            # Membership is enforced only when the override actually changes: existing pins are
            # honored verbatim even if the vendor version was later retired from
            # supported_versions, so full-payload PATCHes (the sources list spreads the GET
            # response back) never 400 on unrelated edits. The viewset 405s POST, so there is
            # no create path to validate.
            if "api_version" in attrs and instance is not None and override != instance.api_version:
                try:
                    source_impl = SourceRegistry.get_source(ExternalDataSourceType(instance.source.source_type))
                except ValueError:
                    raise ValidationError(
                        {"api_version": "API version overrides are not supported for this source type."}
                    )
                if override not in source_impl.supported_versions:
                    raise ValidationError(
                        {
                            "api_version": f"'{override}' is not a supported {instance.source.source_type} API version. "
                            f"Supported versions: {', '.join(source_impl.supported_versions)}"
                        }
                    )
        return attrs

    def get_status(self, schema: ExternalDataSchema) -> str | None:
        return schema_display_status(schema)

    def get_incremental(self, schema: ExternalDataSchema) -> bool:
        return schema.is_incremental

    def get_table(self, schema: ExternalDataSchema) -> Optional[dict]:
        from products.data_warehouse.backend.presentation.views.table import SimpleTableSerializer

        if schema.table and schema.table.deleted:
            return None

        # Serializing table columns requires the full HogQL Database, which is expensive to build.
        # Callers that don't need columns (e.g. the source list) set include_columns=False so we skip it.
        include_columns = self.context.get("include_columns", True)
        table_context: dict[str, Any] = {"include_columns": include_columns, "team_id": self.context.get("team_id")}
        if include_columns:
            hogql_context = self.context.get("database", None)
            if not hogql_context:
                hogql_context = Database.create_for(
                    team_id=self.context["team_id"],
                    user=cast(User, self.context["request"].user),
                )
            table_context["database"] = hogql_context

        return SimpleTableSerializer(schema.table, context=table_context).data or None

    def to_representation(self, instance: ExternalDataSchema) -> dict:
        ret = super().to_representation(instance)
        ret["sync_type"] = ExternalDataSchema.SyncType(instance.sync_type) if instance.sync_type is not None else None
        ret["sync_frequency"] = sync_frequency_interval_to_sync_frequency(instance.sync_frequency_interval)
        ret["sync_time_of_day"] = (
            self.fields["sync_time_of_day"].to_representation(instance.sync_time_of_day)
            if instance.sync_time_of_day
            else None
        )
        ret["incremental_field"] = (
            instance.sync_type_config.get("incremental_field") if instance.sync_type_config else None
        )
        ret["incremental_field_type"] = (
            instance.sync_type_config.get("incremental_field_type") if instance.sync_type_config else None
        )
        ret["incremental_field_lookback_seconds"] = instance.incremental_field_lookback_seconds
        ret["primary_key_columns"] = instance.primary_key_columns
        ret["cdc_table_mode"] = instance.cdc_table_mode
        return ret

    def _run_temporal_side_effect(self, callback: Callable[[], None]) -> None:
        post_commit_actions = self.context.get("post_commit_actions")
        if isinstance(post_commit_actions, list):
            post_commit_actions.append(callback)
            return

        callback()

    def _save_merging_sync_type_config(
        self,
        instance: ExternalDataSchema,
        validated_data: dict[str, Any],
        original_sync_type_config: dict[str, Any],
    ) -> ExternalDataSchema:
        """Persist the update, replaying only the sync_type_config keys this request changed onto a
        freshly-locked copy of the row.

        super().update() does a full-instance save that rewrites sync_type_config wholesale from the
        copy loaded at the start of the request, so without this it would revert any key a concurrent
        CDC extract activity (cdc_last_log_position, cdc_deferred_runs, cdc_mode) committed in between.
        The lock is held across the save so nothing interleaves.
        """
        intended = instance.sync_type_config or {}
        changed = {
            key: value
            for key, value in intended.items()
            if key not in original_sync_type_config or original_sync_type_config[key] != value
        }
        removed = [key for key in original_sync_type_config if key not in intended]
        with transaction.atomic():
            locked = ExternalDataSchema.objects.select_for_update().get(pk=instance.pk)
            merged = locked.sync_type_config or {}
            merged.update(changed)
            for key in removed:
                merged.pop(key, None)
            instance.sync_type_config = merged
            validated_data["sync_type_config"] = merged
            return super().update(instance, validated_data)

    def update(self, instance: ExternalDataSchema, validated_data: dict[str, Any]) -> ExternalDataSchema:
        data = self.initial_data if isinstance(self.initial_data, dict) else {}

        # Capture the previous cdc_table_mode before any mutation so the post-save hook below can decide
        # whether the change adds a new physical write target (and therefore needs a re-snapshot).
        previous_cdc_table_mode = instance.cdc_table_mode

        api_version_changed = "api_version" in validated_data and validated_data["api_version"] != instance.api_version

        # Snapshot sync_type_config before the branches below mutate it in place. The terminal save
        # diffs against this to persist only the keys this request changed. Shallow is enough: the
        # branches replace top-level keys (they never mutate a nested value in place), so a key is
        # "changed" iff its top-level value differs.
        original_sync_type_config = dict(instance.sync_type_config or {})

        # Refuse cdc_table_mode transitions that would kick a re-snapshot when the team is over its
        # monthly sync billing limit. Checked here (pre-save) so we don't end up with the new mode
        # persisted but no resnapshot triggered. Mirrors the gate in `resync` / `reload`.
        if (
            instance.sync_type == ExternalDataSchema.SyncType.CDC
            and "cdc_table_mode" in data
            and _cdc_table_mode_change_needs_resnapshot(previous_cdc_table_mode, data.get("cdc_table_mode"))
            and is_any_external_data_schema_paused(instance.team_id)
        ):
            raise ValidationError(
                "Monthly sync limit reached. Please increase your billing limit before changing "
                "the CDC table mode — a full re-snapshot would be required."
            )

        # Pop non-model fields from validated_data so super().update() doesn't try to set them
        validated_data.pop("sync_type", None)
        validated_data.pop("sync_frequency", None)
        validated_data.pop("sync_time_of_day", None)
        validated_data.pop("incremental_field", None)
        validated_data.pop("incremental_field_type", None)
        validated_data.pop("incremental_field_lookback_seconds", None)
        validated_data.pop("primary_key_columns", None)
        validated_data.pop("cdc_table_mode", None)

        enabled_columns_changed = "enabled_columns" in validated_data and (
            validated_data["enabled_columns"] != instance.enabled_columns
        )

        if "enabled_columns" in validated_data:
            enabled_columns = validated_data["enabled_columns"]
            if enabled_columns is not None:
                # Managed-schema sources expose a fixed canonical HogQL schema; dropping a
                # referenced column breaks the query, so column selection isn't offered for them.
                if not source_supports_column_selection(instance.source.source_type):
                    raise ValidationError("Column selection is not supported for this source type.")
                if not isinstance(enabled_columns, list) or not all(isinstance(c, str) for c in enabled_columns):
                    raise ValidationError("enabled_columns must be a list of column-name strings or null.")
                metadata = instance.schema_metadata or {}
                metadata_columns = metadata.get("columns") if isinstance(metadata, dict) else None
                known = (
                    {col.get("name") for col in metadata_columns if isinstance(col, dict)}
                    if isinstance(metadata_columns, list)
                    else set()
                )
                if known:
                    unknown = [c for c in enabled_columns if c not in known]
                    if unknown:
                        raise ValidationError(
                            f"Unknown columns in enabled_columns: {sorted(unknown)}. "
                            "Run `Pull new schemas` to refresh available columns."
                        )
                elif (
                    enabled_columns_changed
                    and enabled_columns
                    and source_requires_exact_column_metadata(instance.source.source_type)
                ):
                    raise ValidationError(
                        "Column metadata is unavailable. Run `Pull new schemas` before selecting source columns."
                    )

        # Validate against the schema's columns; raw filters are persisted as-is and re-coerced at sync time.
        if "row_filters" in validated_data and validated_data["row_filters"] is not None:
            # Only sources that push filters into their query (SQL WHERE) can honor them — a
            # saved-but-ignored filter would silently sync unfiltered rows.
            if not source_supports_row_filters(instance.source.source_type):
                raise ValidationError("Row filters are not supported for this source type.")
            incoming_sync_type = data.get("sync_type")
            target_is_cdc = (
                incoming_sync_type == ExternalDataSchema.SyncType.CDC if "sync_type" in data else instance.is_cdc
            )
            if reason := unsupported_row_filter_reason(
                is_direct_query=instance.source.is_direct_query, is_cdc=target_is_cdc
            ):
                raise ValidationError(reason)
            try:
                validate_and_coerce_row_filters(validated_data["row_filters"], instance.schema_metadata)
            except RowFilterValidationError as e:
                raise ValidationError(f"Invalid row filter: {e}")

        sync_type = data.get("sync_type")

        if sync_type == ExternalDataSchema.SyncType.CDC:
            from posthog.models import Team

            team = Team.objects.get(id=self.context["team_id"])
            if not is_cdc_enabled_for_team(team):
                raise ValidationError("CDC is not enabled for this team")

        # Close the enum-exposure window: `XMIN` is a valid `SyncType` choice, so the field accepts
        # "xmin" the moment the foundation lands. Reject it unless the source is Postgres and the table
        # actually advertises xmin support — otherwise a raw PATCH would persist an xmin schema that
        # silently degrades to full_refresh.
        if sync_type == ExternalDataSchema.SyncType.XMIN:
            if not SourceRegistry.get_source(ExternalDataSourceType(instance.source.source_type)).supports_xmin:
                raise ValidationError("xmin replication is only available for Postgres sources.")
            if not self._xmin_available_for_schema(instance):
                raise ValidationError(
                    f"xmin replication is not available for table '{instance.name}'. "
                    "It requires a Postgres heap table or materialized view on PostgreSQL 13+."
                )

        # Reject non-webhook sync types for webhook-only schemas (e.g. Stripe Discount —
        # no API list endpoint, so anything other than webhook produces an empty sync).
        if self._webhook_only_check_applies():
            if self._is_webhook_only_schema_cached(instance):
                raise ValidationError(
                    f"{instance.name} can only be synced via webhooks — pick the Webhook sync method."
                )

        # Only update sync_type if it was explicitly provided in the request
        if "sync_type" in data:
            validated_data["sync_type"] = sync_type

        # The sync type the schema will end up with: the new one if the request changes it, else the
        # existing one. Incremental-style config (incremental_field, incremental_field_type,
        # primary_key_columns, lookback) is keyed off this so a PATCH that edits only those fields —
        # without re-sending sync_type — still persists. Previously the whole block below was gated on
        # `sync_type` being in the request, so a bare `{"incremental_field": ...}` PATCH was silently
        # dropped while the 200 response still echoed the submitted value from the in-memory config.
        resulting_sync_type = sync_type if "sync_type" in data else instance.sync_type
        incremental_style_types = (
            ExternalDataSchema.SyncType.INCREMENTAL,
            ExternalDataSchema.SyncType.APPEND,
            ExternalDataSchema.SyncType.WEBHOOK,
        )

        # A bare edit (no sync_type in the request) of sync-config fields on a schema whose sync type
        # can't apply them would otherwise be an unpersisted no-op that still returns 200 — only the
        # incremental-style branch below writes these, and a non-incremental schema falls through it.
        # Reject it so the caller gets a clear error instead of a response that looks applied but isn't.
        # (primary_key_columns is included: CDC/xmin do use it, but only when sync_type is sent, so a
        # bare PK edit on those is dropped just like on full_refresh.)
        if "sync_type" not in data and resulting_sync_type not in incremental_style_types:
            unappliable_fields = [
                field
                for field in (
                    "incremental_field",
                    "incremental_field_type",
                    "incremental_field_lookback_seconds",
                    "primary_key_columns",
                )
                if field in data and data.get(field) is not None
            ]
            if unappliable_fields:
                raise ValidationError(
                    f"{', '.join(unappliable_fields)} cannot be applied to a schema with sync type "
                    f"{resulting_sync_type or 'not set'} on its own. "
                    "Include sync_type in the same request to change the sync type."
                )

        trigger_refresh = False
        # Update the validated_data with incremental fields
        if resulting_sync_type in incremental_style_types:
            payload = instance.sync_type_config

            if "primary_key_columns" in data:
                new_pk = data.get("primary_key_columns")
                old_pk = instance.sync_type_config.get("primary_key_columns")
                # Only swapping an established key breaks merge identity against already-synced
                # rows. A keyless incremental table can't merge at all, and picking its first key
                # is the fix we tell the user to apply, so don't block that.
                if (
                    resulting_sync_type == ExternalDataSchema.SyncType.INCREMENTAL
                    and old_pk
                    and new_pk != old_pk
                    and instance.table is not None
                ):
                    raise ValidationError(
                        "Primary key cannot be changed after data has been synced. "
                        "Delete the synced data first, then change the primary key."
                    )
                payload["primary_key_columns"] = new_pk

            # Detect incremental field changes before mutating payload
            incremental_field_changed = False
            incremental_field = data.get("incremental_field")
            if resulting_sync_type in (ExternalDataSchema.SyncType.INCREMENTAL, ExternalDataSchema.SyncType.APPEND):
                if "incremental_field" in data:
                    incremental_field_changed = (
                        payload.get("incremental_field") != incremental_field
                        or payload.get("incremental_field_last_value") is None
                    )

            # Webhook schemas derive their incremental field from the source, so a null here is the
            # client's "not applicable", not an intentional clear. Writing it would wipe the cursor
            # config a previous append/incremental sync built up, turning the webhook initial sync
            # into an unbounded full-history scan with no durable watermark progress.
            is_webhook_target = resulting_sync_type == ExternalDataSchema.SyncType.WEBHOOK
            if "incremental_field" in data and not (is_webhook_target and incremental_field is None):
                payload["incremental_field"] = incremental_field
            if "incremental_field_type" in data and not (
                is_webhook_target and data.get("incremental_field_type") is None
            ):
                payload["incremental_field_type"] = data.get("incremental_field_type")

            # Lookback only applies to incremental — merge-by-PK makes re-reading the overlap window
            # idempotent. `null` clears it.
            if (
                resulting_sync_type == ExternalDataSchema.SyncType.INCREMENTAL
                and "incremental_field_lookback_seconds" in data
            ):
                payload["incremental_field_lookback_seconds"] = data.get("incremental_field_lookback_seconds")

            if incremental_field_changed:
                if instance.table is not None and isinstance(incremental_field, str):
                    max_value = instance.table.get_max_value_for_column(incremental_field)
                    if max_value:
                        instance.update_incremental_field_value(max_value, save=False)
                    else:
                        # if we can't get the max value, reset the table
                        payload["incremental_field_last_value"] = None
                        trigger_refresh = True

            validated_data["sync_type_config"] = payload
        elif sync_type == ExternalDataSchema.SyncType.CDC:
            payload = instance.sync_type_config
            if payload.get("cdc_mode") is None:
                payload["cdc_mode"] = "snapshot"
            cdc_table_mode = data.get("cdc_table_mode")
            if cdc_table_mode in ("consolidated", "cdc_only", "both"):
                payload["cdc_table_mode"] = cdc_table_mode

            # CDC needs a PK for UPDATE/DELETE merges. Accept the caller's PK or reuse what
            # discovery already stored; refuse the switch when neither is set.
            _apply_primary_key_columns(data, payload, instance, "CDC")

            validated_data["sync_type_config"] = payload
        elif sync_type == ExternalDataSchema.SyncType.XMIN:
            payload = instance.sync_type_config

            # xmin requires a primary key for clean upsert dedup, mirroring CDC. Accept the caller's
            # PK or reuse what discovery already stored; refuse the switch when neither is set.
            _apply_primary_key_columns(data, payload, instance, "xmin replication")

            validated_data["sync_type_config"] = payload
        else:
            # For CDC schemas where sync_type isn't being changed, still allow cdc_table_mode updates
            if instance.sync_type == ExternalDataSchema.SyncType.CDC and "cdc_table_mode" in data:
                cdc_table_mode = data.get("cdc_table_mode")
                if cdc_table_mode in ("consolidated", "cdc_only", "both"):
                    payload = instance.sync_type_config
                    payload["cdc_table_mode"] = cdc_table_mode
                    validated_data["sync_type_config"] = payload

        should_sync = validated_data.get("should_sync", None)
        sync_frequency = data.get("sync_frequency", None)
        sync_time_of_day_in_payload = "sync_time_of_day" in data
        sync_time_of_day = data.get("sync_time_of_day", None)
        was_sync_frequency_updated = False
        was_sync_time_of_day_updated = False
        source = instance.source

        # "1min" is rejected at the field level, but a schema whose stored interval predates the
        # 5-minute floor keeps working until migrated. When such a schema stops being CDC (the only
        # type that ever allowed 1min), clamp the inherited cadence to the floor so the switch
        # doesn't dead-end. The clamp flows through the sync_frequency handling below.
        resulting_sync_type = sync_type if "sync_type" in data else instance.sync_type
        resulting_frequency = sync_frequency
        if not resulting_frequency and instance.sync_frequency_interval is not None:
            resulting_frequency = sync_frequency_interval_to_sync_frequency(instance.sync_frequency_interval)
        if (
            resulting_frequency in LEGACY_SUB_FLOOR_SYNC_FREQUENCIES
            and resulting_sync_type != ExternalDataSchema.SyncType.CDC
        ):
            sync_frequency = FLOOR_SYNC_FREQUENCY

        if sync_frequency:
            sync_frequency_interval = sync_frequency_to_sync_frequency_interval(sync_frequency)

            if sync_frequency_interval != instance.sync_frequency_interval:
                was_sync_frequency_updated = True
                validated_data["sync_frequency_interval"] = sync_frequency_interval
                instance.sync_frequency_interval = sync_frequency_interval

        if sync_time_of_day is not None:
            try:
                new_time = dt.datetime.strptime(str(sync_time_of_day), "%H:%M:%S").time()
            except ValueError:
                raise ValidationError("Invalid sync time of day")

            if new_time != instance.sync_time_of_day:
                was_sync_time_of_day_updated = True
                validated_data["sync_time_of_day"] = sync_time_of_day
                instance.sync_time_of_day = sync_time_of_day
        else:
            if sync_time_of_day_in_payload and sync_time_of_day != instance.sync_time_of_day:
                was_sync_time_of_day_updated = True
                validated_data["sync_time_of_day"] = None
                instance.sync_time_of_day = None

        if source.supports_scheduled_sync and should_sync is True and sync_type is None and instance.sync_type is None:
            raise ValidationError("Sync type must be set up first before enabling schema")

        # Catches a CDC schema being flipped on later when sync_type isn't changing — the
        # sync_type branch above doesn't run, so PK presence isn't enforced there.
        effective_sync_type = sync_type or instance.sync_type
        if (
            should_sync is True
            and not instance.should_sync
            and effective_sync_type == ExternalDataSchema.SyncType.CDC
            and not instance.primary_key_columns
        ):
            raise ValidationError(
                f"CDC requires a primary key on table '{instance.name}'. "
                "Add a primary key on the source table and retry."
            )

        # Switching sync type across the xmin boundary changes the physical Delta schema: xmin
        # force-projects a non-nullable `_ph_xmin` control column that no other sync type writes.
        # Reusing the existing Delta table fails the write — the column is missing on the way in, or
        # lingers on the way out — so force a full resync to rebuild the table from scratch.
        if (
            "sync_type" in data
            and sync_type != instance.sync_type
            and ExternalDataSchema.SyncType.XMIN in (sync_type, instance.sync_type)
        ):
            if is_any_external_data_schema_paused(instance.team_id):
                raise ValidationError(
                    "Monthly sync limit reached. Please increase your billing limit before changing "
                    "the sync type — a full re-sync would be required."
                )
            validated_data.setdefault("sync_type_config", instance.sync_type_config)
            validated_data["sync_type_config"]["reset_pipeline"] = True
            if should_sync if should_sync is not None else instance.should_sync:
                trigger_refresh = True

        # When re-enabling a webhook schema, request a pipeline reset so a gap from the
        # off-window gets filled. Poll-backfillable sources honor it as a wipe plus full
        # re-crawl; webhook-only sources (no poll backfill) resume webhook ingestion over
        # the existing table instead of wiping it — see handle_reset_or_full_refresh.
        if (
            should_sync is True
            and instance.should_sync is False
            and instance.is_webhook
            and instance.initial_sync_complete
        ):
            validated_data.setdefault("sync_type_config", instance.sync_type_config)
            validated_data["sync_type_config"]["reset_pipeline"] = True
            trigger_refresh = True

        if source.is_direct_query:
            direct_engine_adapter = get_direct_query_engine(source.direct_engine)
            # Direct-mode lifecycle hooks that need a fresh DataWarehouseTable projection:
            # (1) row is being re-exposed (should_sync flipping False → True);
            # (2) the column-picker selection changed on an already-exposed row.
            newly_exposed = should_sync is True and instance.should_sync is False
            projection_needs_refresh = enabled_columns_changed and instance.table is not None and instance.should_sync
            if direct_engine_adapter is not None and (newly_exposed or projection_needs_refresh):
                validated_data["table"] = direct_engine_adapter.reproject_table(
                    instance,
                    source=source,
                    enabled_columns=validated_data.get("enabled_columns", instance.enabled_columns),
                )

            if direct_engine_adapter is not None and should_sync is False and instance.should_sync is True:
                direct_engine_adapter.hide_table(instance.table)
        elif enabled_columns_changed and instance.table is not None and instance.should_sync:
            # Warehouse mode: hide newly-disabled columns from HogQL immediately. Restoration
            # (reset to None or re-enabling a column) is deferred to the next sync — Delta may
            # not contain the column yet, so exposing it now would surface all-NULL queries.
            current_columns = instance.table.columns or {}
            projected_columns = _filter_dwh_columns_by_enabled_columns(
                current_columns,
                validated_data["enabled_columns"],
                instance.primary_key_columns,
                instance.incremental_field,
            )
            if projected_columns != current_columns:
                instance.table.columns = projected_columns
                instance.table.save(update_fields=["columns"])

        # CDC publication management: add/remove table when toggling should_sync
        is_cdc = (sync_type == ExternalDataSchema.SyncType.CDC) or (
            sync_type is None and instance.sync_type == ExternalDataSchema.SyncType.CDC
        )
        if is_cdc and source_type_supports_cdc(source.source_type):
            self._handle_cdc_publication_change(instance, source, should_sync, sync_type)

        if trigger_refresh:
            instance.sync_type_config.update({"reset_pipeline": True})
            validated_data["sync_type_config"].update({"reset_pipeline": True})

        # Persist under a row lock, replaying only the sync_type_config keys this request changed
        # so a concurrent CDC extract activity's writes aren't reverted by the full-instance save.
        updated_instance = self._save_merging_sync_type_config(instance, validated_data, original_sync_type_config)

        # A version repin invalidates any in-flight import: retried/resumed activities re-resolve
        # the version from the DB, so letting the run finish would mix two vendor API versions in
        # one table. Cancel it; the user decides when to sync again.
        if api_version_changed:
            running_job = (
                ExternalDataJob.objects.filter(schema_id=instance.pk, team_id=instance.team_id)
                .order_by("-created_at")
                .first()
            )
            if running_job and running_job.workflow_id and running_job.status == "Running":

                def cancel_running_import() -> None:
                    try:
                        cancel_external_data_workflow(running_job.workflow_id)
                    except temporalio.service.RPCError as e:
                        logger.exception(
                            "Could not cancel running workflow after api_version change",
                            schema_id=str(instance.id),
                            exc_info=e,
                        )

                self._run_temporal_side_effect(cancel_running_import)

        if source.supports_scheduled_sync and (
            should_sync is not None or was_sync_frequency_updated or was_sync_time_of_day_updated
        ):

            def update_schedule() -> None:
                should_sync_value = should_sync if should_sync is not None else updated_instance.should_sync
                schedule_exists = external_data_workflow_exists(str(updated_instance.id))

                if schedule_exists:
                    if should_sync is False:
                        pause_external_data_schedule(str(updated_instance.id))
                    elif should_sync is True:
                        unpause_external_data_schedule(str(updated_instance.id))
                elif should_sync_value:
                    # No schedule yet but the schema should be syncing — create (or recover) it. The
                    # schedule is built from the current frequency, so a cadence-only edit on an
                    # enabled-but-unscheduled schema still takes effect.
                    sync_external_data_job_workflow(updated_instance, create=True, should_sync=should_sync_value)

                # Re-issue an existing schedule when the cadence changed. A disabled schema with no
                # schedule has nothing to update — updating a missing schedule raises "workflow not
                # found" — so its new cadence is just saved and applies if/when it is enabled.
                if (was_sync_frequency_updated or was_sync_time_of_day_updated) and schedule_exists:
                    sync_external_data_job_workflow(updated_instance, create=False, should_sync=should_sync_value)

            self._run_temporal_side_effect(update_schedule)

        if trigger_refresh:
            self._run_temporal_side_effect(lambda: trigger_external_data_workflow(updated_instance))

        if sync_type == ExternalDataSchema.SyncType.WEBHOOK:
            self._maybe_create_webhook(updated_instance)

        # Sync CDC extraction schedule after any CDC schema change
        if is_cdc:

            def sync_cdc_schedule() -> None:
                try:
                    sync_cdc_extraction_schedule(source)
                except Exception as e:
                    logger.exception("Failed to sync CDC extraction schedule", exc_info=e)

            self._run_temporal_side_effect(sync_cdc_schedule)

        # If the cdc_table_mode change added a new physical write target, kick a full re-snapshot so the
        # new table is seeded from the current source state. `_seed_cdc_companion_from_snapshot` runs
        # automatically once the snapshot completes via `run_post_load_operations`.
        if is_cdc and "cdc_table_mode" in data:
            new_cdc_table_mode = data.get("cdc_table_mode")
            if _cdc_table_mode_change_needs_resnapshot(previous_cdc_table_mode, new_cdc_table_mode):
                logger.info(
                    "cdc_table_mode_changed_resnapshot_triggered",
                    schema_id=str(updated_instance.id),
                    old_cdc_table_mode=previous_cdc_table_mode,
                    new_cdc_table_mode=new_cdc_table_mode,
                )
                self._run_temporal_side_effect(lambda: _reset_cdc_for_full_resnapshot(updated_instance))

        return updated_instance

    def _effective_probe_api_version(self, schema: ExternalDataSchema, source_impl: AnySource) -> str | None:
        """Version the schema will sync with after this request saves.

        An `api_version` in the incoming payload wins over the stored override — a PATCH can change
        version and sync_type together, and gating capabilities under the old version would approve
        a sync method the new version doesn't support. Unvalidated payload values fall through to
        the stored chain (the request 400s in validate() anyway, and the probe must never send an
        unvetted label to the vendor)."""
        data = self.initial_data if isinstance(self.initial_data, dict) else {}
        incoming = data.get("api_version")
        if "api_version" in data and (incoming is None or incoming in source_impl.supported_versions):
            return incoming or schema.source.api_version
        return schema.api_version or schema.source.api_version

    def _is_webhook_only_schema(self, schema: ExternalDataSchema) -> bool:
        source = schema.source
        if not source.job_inputs:
            return False
        try:
            source_type = ExternalDataSourceType(source.source_type)
            source_impl = SourceRegistry.get_source(source_type)
        except Exception:
            return False
        try:
            config = source_impl.parse_config(source.job_inputs)
            source_schemas = source_impl.get_schemas(
                config,
                schema.team_id,
                names=[schema.name],
                api_version=source_impl.resolve_api_version(self._effective_probe_api_version(schema, source_impl)),
            )
        except Exception:
            return False
        return any(s.name == schema.name and s.webhook_only for s in source_schemas)

    def _xmin_available_for_schema(self, schema: ExternalDataSchema) -> bool:
        """True when the source advertises xmin support for this table (Postgres heap table or
        materialized view, PG13+). Runs discovery so a raw PATCH can't enable xmin on a table that
        has no physical `xmin` (plain views, foreign tables, partitioned parents)."""
        source = schema.source
        if not source.job_inputs:
            return False
        try:
            source_type = ExternalDataSourceType(source.source_type)
            source_impl = SourceRegistry.get_source(source_type)
            config = source_impl.parse_config(source.job_inputs)
            source_schemas = source_impl.get_schemas(
                config,
                schema.team_id,
                names=[schema.name],
                api_version=source_impl.resolve_api_version(self._effective_probe_api_version(schema, source_impl)),
            )
        except Exception:
            return False
        return any(s.name == schema.name and s.supports_xmin for s in source_schemas)

    def warm_webhook_only_check(self, instance: ExternalDataSchema) -> None:
        """Pre-run the webhook-only validation that reaches the external source, caching the result.

        `_is_webhook_only_schema` calls the source's `get_schemas`, which is a network round-trip (e.g.
        Google Ads OAuth refresh + field query). update() runs this same check, but bulk_update_schemas
        wraps each update() in a transaction — making the call there held the DB connection idle-in-
        transaction long enough for the server to close it ("the connection is closed"). Calling this
        first (outside the transaction) does the network work up front; update() then reads the cached
        result and still raises per-schema, so failures stay isolated to one schema.
        """
        if self._webhook_only_check_applies():
            self._is_webhook_only_schema_cached(instance)

    def seed_webhook_only_check(self, webhook_only: bool) -> None:
        """Pre-fill the webhook-only cache when the caller already discovered this table (e.g.
        bulk sync-defaults filling), so warm_webhook_only_check doesn't re-probe the source."""
        self.__dict__["_webhook_only_result"] = webhook_only

    def _webhook_only_check_applies(self) -> bool:
        # Single source of truth for when the webhook-only check runs, so update() and the
        # pre-transaction warm step can't drift apart and push the network call back into the
        # transaction. Reads `initial_data` (the raw request payload), like update() does.
        data = self.initial_data if isinstance(self.initial_data, dict) else {}
        return "sync_type" in data and data.get("sync_type") != ExternalDataSchema.SyncType.WEBHOOK

    def _is_webhook_only_schema_cached(self, schema: ExternalDataSchema) -> bool:
        if "_webhook_only_result" not in self.__dict__:
            self.__dict__["_webhook_only_result"] = self._is_webhook_only_schema(schema)
        return self.__dict__["_webhook_only_result"]

    def _maybe_create_webhook(self, schema: ExternalDataSchema) -> None:
        source = schema.source
        if not source.job_inputs:
            return

        try:
            source_type = ExternalDataSourceType(source.source_type)
            source_impl = SourceRegistry.get_source(source_type)
        except Exception as e:
            capture_exception(e)
            return

        if not isinstance(source_impl, WebhookSource):
            return

        config = source_impl.parse_config(source.job_inputs)
        # Source pin only: webhook-sync schemas cannot carry a schema-level override (validate()
        # rejects it), so there is no per-schema precedence to honor here.
        effective_api_version = source_impl.resolve_api_version(source.api_version)
        source_schemas = source_impl.get_schemas(config, schema.team_id, api_version=effective_api_version)
        webhook_source_schemas = {s.name for s in source_schemas if s.supports_webhooks}

        if schema.name not in webhook_source_schemas:
            return

        try:
            hog_fn_result = get_or_create_webhook_hog_function(
                team=schema.team,
                source=source_impl,
                source_id=str(source.pk),
                eligible_schemas=[schema],
                config=config,
            )

            if hog_fn_result.error or hog_fn_result.hog_function_id is None:
                raise ValidationError(
                    f"Failed to set up webhook: {hog_fn_result.error or 'Unknown error'}. "
                    "You can set up the webhook manually from the Webhook tab."
                )

            if hog_fn_result.hog_function_created:
                # Only register the webhook if we're creating the hog function when it didn't exist previously
                result = create_and_register_webhook(
                    source_impl, config, hog_fn_result, schema.team_id, api_version=effective_api_version
                )
                if not result.success:
                    raise ValidationError(
                        f"Failed to register webhook on your source: {result.error or 'Unknown error'}. "
                        "You can set up the webhook manually from the Webhook tab."
                    )
            else:
                # Deferred to keep the provider call out of the surrounding transaction.
                # Fully non-fatal: the table is already enabled by the time this runs, so any
                # failure (bad creds, provider 403, network) must never propagate — it would
                # otherwise 500 the post-commit hook on the bulk path, or roll back the enable
                # on the single-update path. Data still flows once the user fixes provider events.
                def reconcile() -> None:
                    try:
                        reconcile_result = reconcile_webhook_events(
                            source_impl,
                            config,
                            hog_fn_result,
                            schema.team_id,
                            [schema.name],
                            api_version=effective_api_version,
                        )
                        if not reconcile_result.success:
                            logger.warning(
                                "Failed to reconcile webhook events on schema enable",
                                error=reconcile_result.error,
                                schema_id=str(schema.id),
                            )
                    except Exception as e:
                        logger.warning(
                            "Error reconciling webhook events on schema enable",
                            error=str(e),
                            schema_id=str(schema.id),
                        )

                self._run_temporal_side_effect(reconcile)
        except ValidationError:
            raise
        except Exception as e:
            logger.exception("Failed to create webhook during schema update", error=str(e))
            raise ValidationError(
                "Failed to create webhook. You can set up the webhook manually from the Webhook tab."
            ) from e

    def _handle_cdc_publication_change(
        self,
        instance: ExternalDataSchema,
        source: ExternalDataSource,
        should_sync: bool | None,
        sync_type: str | None,
    ) -> None:
        """Add/remove the table from the CDC capture set when a schema is toggled or set to CDC."""
        adapter = get_cdc_adapter(source)
        cdc_config = adapter.parse_cdc_config(source)
        if cdc_config.management_mode != "posthog" or not cdc_config.publication_name:
            return

        _, db_schema, source_table_name = get_postgres_source_location(
            schema_name=instance.name,
            schema_metadata=instance.schema_metadata,
            default_schema=(source.job_inputs or {}).get("schema"),
        )

        newly_set_to_cdc = (
            sync_type == ExternalDataSchema.SyncType.CDC and instance.sync_type != ExternalDataSchema.SyncType.CDC
        )

        # Add table to capture set when enabling CDC or toggling sync on
        if newly_set_to_cdc or (should_sync is True and not instance.should_sync):
            adapter.add_table(source, db_schema, source_table_name)

            # Always force a full re-snapshot on re-enable: while removed from the
            # publication the replication slot kept advancing, so any changes made
            # during that window are permanently lost regardless of how short it was.
            # reset_pipeline wipes the warehouse table first — otherwise the snapshot
            # merges current rows over the stale pre-disable ones and never drops deletes.
            if should_sync is True and not newly_set_to_cdc:
                # Mutate in memory only — the locked terminal save in `update()` (which calls this)
                # persists both fields, merging cdc_mode onto the freshly-read config so a concurrent
                # CDC extract activity's writes survive. A separate save here would clobber them.
                instance.sync_type_config["cdc_mode"] = "snapshot"
                instance.sync_type_config["reset_pipeline"] = True
                instance.initial_sync_complete = False

        # Remove table from capture set when toggling sync off
        elif should_sync is False and instance.should_sync:
            adapter.remove_table(source, db_schema, source_table_name)


class ExternalDataSchemaListSerializer(serializers.ModelSerializer):
    """Trimmed schema representation for the source LIST endpoint.

    The sources list embeds every schema of every source, and a large project can have tens of
    thousands of schemas. This serializer emits only the fields the list consumers read: sync status,
    the sync toggle, sync type, last sync, the latest error, and the synced table's name and row count.
    It skips column metadata, the rest of the sync configuration, and the per-schema SourceRegistry/HogQL
    work that the full `ExternalDataSchemaSerializer` computes, which otherwise dominates the request.
    `sync_type` is kept as a plain stored field (no per-row recompute) because the PostHog Desktop app
    reads it from this list to decide whether a schema needs an update.
    """

    table = serializers.SerializerMethodField(
        read_only=True, help_text="The synced warehouse table (id, name, row_count), or null if not yet synced."
    )
    status = serializers.SerializerMethodField(read_only=True, help_text="Current sync status for this schema.")

    class Meta:
        model = ExternalDataSchema
        fields = [
            "id",
            "name",
            "label",
            "should_sync",
            "status",
            "sync_type",
            "last_synced_at",
            "latest_error",
            "table",
        ]
        read_only_fields = fields

    @extend_schema_field(
        {
            "type": "object",
            "nullable": True,
            "properties": {
                "id": {"type": "string"},
                "name": {"type": "string"},
                "row_count": {"type": "integer", "nullable": True},
            },
        }
    )
    def get_table(self, schema: ExternalDataSchema) -> dict[str, Any] | None:
        table = schema.table
        if table is None or table.deleted:
            return None
        return {"id": str(table.id), "name": table.name, "row_count": table.row_count}

    @extend_schema_field(serializers.CharField(allow_null=True))
    def get_status(self, schema: ExternalDataSchema) -> str | None:
        return schema_display_status(schema)


class SimpleExternalDataSchemaSerializer(serializers.ModelSerializer):
    class Meta:
        model = ExternalDataSchema
        fields = ["id", "name", "label", "should_sync", "last_synced_at", "sync_type"]


class WarehouseTableAccessPermission(AccessControlPermission):
    """Resolves a schema's access through the table it syncs.

    No access control rules are written against a schema, so the base class - which looks for rules
    keyed to the object's own id - finds none and lets everything through. Resolve through the table
    instead (whose access falls back to the source via RESOURCE_FALLBACK_MAP), or the source directly
    before the first sync. The required level still comes from the base class: viewer to read, editor
    to write."""

    def has_object_permission(self, request: Request, view, obj: ExternalDataSchema) -> bool:
        # Service credentials (PSAK/TST) are synthetic users UserAccessControl can't evaluate; they're
        # gated by API scope + project membership. Mirror AccessControlPermission.
        if is_service_auth(request):
            return True
        required_level = self._get_required_access_level(request, view)
        if not required_level:
            return True
        level = view.user_access_control.get_user_access_level(obj.table or obj.source)
        if level is None or not access_level_satisfied_for_resource("warehouse_table", level, required_level):
            self.message = f"You do not have {required_level} access to this table."
            return False
        return True


@extend_schema(extensions={"x-product": "warehouse_sources"})
class ExternalDataSchemaViewset(TeamAndOrgViewSetMixin, viewsets.ModelViewSet):
    scope_object = "external_data_source"
    permission_classes = [WarehouseTableAccessPermission]
    scope_object_write_actions = [
        "update",
        "partial_update",
        "patch",
        "destroy",
        "reload",
        "resync",
        "cancel",
        "incremental_fields",
        "delete_data",
    ]
    scope_object_read_actions = ["list", "retrieve", "logs"]
    queryset = ExternalDataSchema.objects.all()
    serializer_class = ExternalDataSchemaSerializer
    filter_backends = [filters.SearchFilter]
    search_fields = ["name"]
    ordering = "-created_at"

    def check_object_permissions(self, request: Request, obj: Any) -> None:
        super().check_object_permissions(request, obj)
        if request.method not in ("GET", "HEAD", "OPTIONS") and isinstance(obj, ExternalDataSchema):
            if obj.source.is_system_managed:
                raise PermissionDenied("This schema is managed by PostHog and cannot be changed through this API.")

    @extend_schema(exclude=True)
    def create(self, request: Request, *args: Any, **kwargs: Any) -> Response:
        # Schemas are created by source schema discovery, never via the API. ModelViewSet would
        # otherwise route POST here, whose serializer create path skips the api_version guards.
        raise MethodNotAllowed("POST")

    def get_serializer_context(self) -> dict[str, Any]:
        context = super().get_serializer_context()
        context["database"] = Database.create_for(team_id=self.team_id, user=cast(User, self.request.user))
        # Only the single-schema retrieve embeds the parent-source summary (see ExternalDataSchemaSerializer.get_source).
        context["include_source"] = self.action == "retrieve"
        return context

    def safely_get_queryset(self, queryset):
        # `table__external_data_source` is read on every schema serialization (SimpleTableSerializer
        # derives the dotted HogQL name from it), and `source` by `get_api_version_deprecation` for
        # any schema carrying a version override — join both for all actions to avoid per-row queries.
        queryset = (
            queryset.exclude(deleted=True)
            .prefetch_related("created_by")
            .select_related("source", "table__external_data_source")
        )
        if self.action == "retrieve":
            # retrieve additionally embeds the table credential.
            queryset = queryset.select_related("table__credential")
        return queryset.order_by(self.ordering)

    def filter_queryset(self, queryset):
        queryset = super().filter_queryset(queryset)
        if self.action != "list" or is_service_auth(self.request):
            return queryset
        # A schema has no rules of its own, so the generic queryset filtering can't see its access.
        # Resolve each row the way retrieve does and drop the ones the user can't view - otherwise
        # the list serves names and sync metadata for tables and sources they're denied on.
        schemas = list(queryset)
        uac = self.user_access_control
        uac.preload_object_access_controls([schema.table or schema.source for schema in schemas])
        visible = [
            schema.id
            for schema in schemas
            if (level := uac.get_user_access_level(schema.table or schema.source)) is not None
            and access_level_satisfied_for_resource("warehouse_table", level, "viewer")
        ]
        if len(visible) == len(schemas):
            return queryset
        return queryset.filter(id__in=visible)

    def destroy(self, request: Request, *args: Any, **kwargs: Any) -> Response:
        instance: ExternalDataSchema = self.get_object()

        if instance.table:
            instance.table.soft_delete()
        instance.soft_delete()

        # CDC teardown, both best-effort: leaving the table in the publication makes the
        # customer's WAL carry its changes forever, and the buffer files are raw change data
        # nothing will consume — otherwise they sit until the 14-day lifecycle expiry.
        if instance.sync_type == ExternalDataSchema.SyncType.CDC:
            try:
                source = instance.source
                adapter = get_cdc_adapter(source)
                _, db_schema, source_table_name = get_postgres_source_location(
                    schema_name=instance.name,
                    schema_metadata=instance.schema_metadata,
                    default_schema=(source.job_inputs or {}).get("schema"),
                )
                adapter.remove_table(source, db_schema, source_table_name)
            except Exception:
                logger.exception("Failed to remove deleted CDC schema from publication", schema_id=str(instance.id))
            purge_buffer_prefix(self.team_id, str(instance.id), logger)

        return Response(status=status.HTTP_204_NO_CONTENT)

    @extend_schema(parameters=[LogEntryRequestSerializer])
    @action(methods=["GET"], detail=True, filter_backends=[])
    def logs(self, request: Request, *args: Any, **kwargs: Any) -> Response:
        instance: ExternalDataSchema = self.get_object()
        param_serializer = LogEntryRequestSerializer(data=request.query_params)
        if not param_serializer.is_valid():
            raise ValidationError(param_serializer.errors)
        params = param_serializer.validated_data
        data = fetch_log_entries(
            team_id=self.team_id,
            log_source="external_data_jobs",
            log_source_id=str(instance.id),
            limit=params["limit"],
            instance_id=params.get("instance_id"),
            after=params.get("after"),
            before=params.get("before"),
            search=params.get("search"),
            level=params["level"].split(",") if params.get("level") else None,
        )
        page = self.paginate_queryset(data)
        if page is not None:
            return self.get_paginated_response(LogEntrySerializer(page, many=True).data)
        return Response(LogEntrySerializer(data, many=True).data)

    @extend_schema(
        request=None,
        responses={
            200: OpenApiResponse(description="The sync was triggered."),
            400: OpenApiResponse(
                response={
                    "type": "object",
                    "properties": {"detail": {"type": "string"}},
                },
                description="The sync could not be started.",
            ),
        },
    )
    @action(methods=["POST"], detail=True)
    def reload(self, request: Request, *args: Any, **kwargs: Any):
        instance: ExternalDataSchema = self.get_object()

        if is_any_external_data_schema_paused(self.team_id):
            return Response(
                status=status.HTTP_400_BAD_REQUEST,
                data={"message": "Monthly sync limit reached. Please increase your billing limit to resume syncing."},
            )

        try:
            trigger_external_data_workflow(instance)
        except temporalio.service.RPCError as e:
            # Only mark the schema Running once the trigger succeeded: a Running status with no
            # workflow behind it sticks forever (nothing finalizes it) and blocks cancel.
            logger.exception(f"Could not trigger external data job for schema {instance.id}", exc_info=e)
            return Response(
                data={"detail": "Couldn't start the sync. Please try again."},
                status=status.HTTP_400_BAD_REQUEST,
            )
        except Exception as e:
            logger.exception(f"Could not trigger external data job for schema {instance.id}", exc_info=e)
            raise

        instance.status = ExternalDataSchema.Status.RUNNING
        instance.save()
        return Response(status=status.HTTP_200_OK)

    @extend_schema(
        request=None,
        responses={
            200: OpenApiResponse(description="The full resync was triggered."),
            400: OpenApiResponse(
                response={
                    "type": "object",
                    "properties": {"detail": {"type": "string"}},
                },
                description="The resync could not be started.",
            ),
        },
    )
    @action(methods=["POST"], detail=True)
    def resync(self, request: Request, *args: Any, **kwargs: Any):
        instance: ExternalDataSchema = self.get_object()

        if is_any_external_data_schema_paused(self.team_id):
            return Response(
                status=status.HTTP_400_BAD_REQUEST,
                data={"message": "Monthly sync limit reached. Please increase your billing limit to resume syncing."},
            )

        latest_running_job = (
            ExternalDataJob.objects.filter(schema_id=instance.pk, team_id=instance.team_id)
            .order_by("-created_at")
            .first()
        )

        if latest_running_job and latest_running_job.workflow_id and latest_running_job.status == "Running":
            cancel_external_data_workflow(latest_running_job.workflow_id)

        cdc_resync = instance.is_cdc
        updates: dict[str, Any] = {"reset_pipeline": True}
        removes: list[str] = []
        if cdc_resync:
            # Reset CDC state so the next run does a full re-snapshot
            updates["cdc_mode"] = "snapshot"
            removes = ["cdc_last_log_position", "cdc_deferred_runs"]

        # Merge under a row lock so this reset can't clobber a concurrent CDC extract activity's
        # sync_type_config writes. Persist BEFORE triggering the workflow so the Postgres source
        # sees cdc_mode="snapshot" when it reloads the schema from DB — otherwise a race: the
        # workflow starts, loads stale "streaming" mode, raises CDCHandledExternally, and the
        # full-refresh never runs.
        # initial_sync_complete is saved in the same transaction as cdc_mode via extra_model_fields
        # so no reader can observe cdc_mode="snapshot" with initial_sync_complete=True.
        extra: dict[str, Any] = {"initial_sync_complete": False} if cdc_resync else {}
        instance.sync_type_config = update_sync_type_config_keys(
            instance.id, instance.team_id, updates=updates, removes=removes, extra_model_fields=extra
        )
        if cdc_resync:
            instance.initial_sync_complete = False

        try:
            trigger_external_data_workflow(instance)
        except temporalio.service.RPCError as e:
            # Only mark the schema Running once the trigger succeeded: a Running status with no
            # workflow behind it sticks forever (nothing finalizes it) and blocks cancel. The
            # sync_type_config reset above stays; the schema's intent is still "resync next run".
            logger.exception(f"Could not trigger external data job for schema {instance.id}", exc_info=e)
            return Response(
                data={"detail": "Couldn't start the sync. Please try again."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        instance.status = ExternalDataSchema.Status.RUNNING
        instance.save(update_fields=["status", "updated_at"])

        return Response(status=status.HTTP_200_OK)

    @extend_schema(
        request=None,
        responses={
            200: OpenApiResponse(
                response={
                    "type": "object",
                    "properties": {"detail": {"type": "string"}},
                },
                description="The running sync was cancelled. v3 pipeline jobs are marked Failed immediately; "
                "for older pipeline versions the cancelled workflow records the final status. When no sync "
                "was actually running but the schema was stuck reporting Running, the schema status is "
                "corrected instead and the response says so.",
            ),
            400: OpenApiResponse(
                response={
                    "type": "object",
                    "properties": {"detail": {"type": "string"}},
                },
                description="No running sync to cancel, or the sync already finished.",
            ),
        },
    )
    @action(methods=["POST"], detail=True)
    def cancel(self, request: Request, *args: Any, **kwargs: Any):
        instance: ExternalDataSchema = self.get_object()

        latest_running_job = (
            ExternalDataJob.objects.filter(schema_id=instance.pk, team_id=instance.team_id)
            .order_by("-created_at")
            .first()
        )

        if not latest_running_job or latest_running_job.status != "Running" or not latest_running_job.workflow_id:
            job_is_running = latest_running_job is not None and latest_running_job.status == "Running"
            # A schema reporting Running with no running job is stale (e.g. a trigger that never
            # started a run): nothing will ever repaint it, so the stop button is the user's only
            # way out. Mirror the latest job's terminal status. CDC halted markers absorb status
            # updates (see update_external_job_status), so honor them here too.
            if instance.status == ExternalDataSchema.Status.RUNNING and not job_is_running and not instance.cdc_halted:
                if latest_running_job is not None:
                    instance.status = ExternalDataSchema.Status(latest_running_job.status)
                    instance.latest_error = latest_running_job.latest_error
                else:
                    instance.status = ExternalDataSchema.Status.FAILED
                instance.save(update_fields=["status", "latest_error", "updated_at"])
                return Response(
                    data={"detail": "No sync was running. The sync status has been updated."},
                    status=status.HTTP_200_OK,
                )
            return Response(
                status=status.HTTP_400_BAD_REQUEST,
                data={"detail": "No running sync to cancel."},
            )

        if latest_running_job.pipeline_version != ExternalDataJob.PipelineVersion.V3:
            # v1/v2: normally the workflow handles the cancellation and writes the job's
            # terminal status itself, so the cancel RPC is the whole operation.
            try:
                cancel_external_data_workflow(latest_running_job.workflow_id)
            except temporalio.service.RPCError as e:
                if e.status != temporalio.service.RPCStatusCode.NOT_FOUND:
                    # Transient RPC failure against a possibly-live workflow. The workflow still
                    # owns the terminal status, so leave the job Running and surface the failure.
                    logger.exception(f"Could not cancel external data workflow for schema {instance.id}", exc_info=e)
                    return Response(
                        status=status.HTTP_400_BAD_REQUEST,
                        data={"detail": "Could not cancel the running sync. Please try again."},
                    )
                # The workflow is already gone (e.g. it was terminated rather than cancelled), so it
                # will never run the cleanup that writes the terminal status - the job and schema
                # would stay stuck on Running forever. Write the Failed status ourselves so the
                # schema unsticks and can be synced again.
                logger.info("cancel_sync_v2_workflow_already_gone", schema_id=str(instance.id))
                update_external_job_status(
                    job_id=str(latest_running_job.id),
                    team_id=instance.team_id,
                    status=ExternalDataJob.Status.FAILED,
                    logger=logger,
                    latest_error="Sync cancelled by user",
                )
            return Response(status=status.HTTP_200_OK)

        # v3: durable marker FIRST. Failed is terminal/absorbing, so the loader's later
        # Completed write and the workflow finally-block write become no-ops.
        model = update_external_job_status(
            job_id=str(latest_running_job.id),
            team_id=instance.team_id,
            status=ExternalDataJob.Status.FAILED,
            logger=logger,
            latest_error="Sync cancelled by user",
        )
        if model.status != ExternalDataJob.Status.FAILED:
            # The job reached a different terminal state concurrently (e.g. Completed).
            return Response(
                status=status.HTTP_400_BAD_REQUEST,
                data={"detail": "The sync already finished."},
            )

        try:
            cancel_external_data_workflow(latest_running_job.workflow_id)
        except temporalio.service.RPCError as e:
            if e.status == temporalio.service.RPCStatusCode.NOT_FOUND:
                # v3 loading phase: the extraction workflow already completed while the loader
                # drains batches. The Failed marker above makes the loader skip and clean up.
                logger.info("cancel_sync_workflow_already_finished", schema_id=str(instance.id))
            else:
                # Transient RPC failure against a possibly-live workflow. The Failed marker is
                # already durable (terminal statuses absorb the workflow's later writes, and the
                # v3 loader cleans up off the marker), so the cancel stands - but the workflow
                # may keep running until it finishes on its own, so surface the failure.
                logger.exception("cancel_sync_workflow_cancel_rpc_failed", schema_id=str(instance.id))

        try:
            # Clear the schema's in-flight row counter; nothing will finish it once the job is Failed.
            async_to_sync(finish_row_tracking)(instance.team_id, str(instance.id))
        except Exception as e:
            # Best-effort: the counter is rebuilt from scratch by the next sync.
            logger.exception("cancel_sync_row_tracking_cleanup_failed", schema_id=str(instance.id))
            capture_exception(e)

        return Response(status=status.HTTP_200_OK)

    @action(methods=["DELETE"], detail=True)
    def delete_data(self, request: Request, *args: Any, **kwargs: Any):
        instance: ExternalDataSchema = self.get_object()

        if instance.source.is_direct_query:
            direct_engine_adapter = get_direct_query_engine(instance.source.direct_engine)
            if direct_engine_adapter is not None:
                direct_engine_adapter.hide_table(instance.table)
            instance.should_sync = False
            instance.save(update_fields=["should_sync", "updated_at"])
            return Response(status=status.HTTP_200_OK)

        instance.delete_table()

        return Response(status=status.HTTP_200_OK)

    @action(methods=["POST"], detail=True)
    def incremental_fields(self, request: Request, *args: Any, **kwargs: Any):
        instance: ExternalDataSchema = self.get_object()
        source: ExternalDataSource = instance.source

        if not source.job_inputs:
            return Response(status=status.HTTP_400_BAD_REQUEST, data={"message": "Missing job inputs"})

        if not source.source_type:
            return Response(status=status.HTTP_400_BAD_REQUEST, data={"message": "Missing source type"})

        source_type_enum = ExternalDataSourceType(source.source_type)

        new_source = SourceRegistry.get_source(source_type_enum)
        config = new_source.parse_config(source.job_inputs)

        effective_api_version = new_source.resolve_api_version(instance.api_version or source.api_version)
        credentials_valid, credentials_error = new_source.validate_credentials(
            config, self.team_id, instance.name, api_version=effective_api_version
        )
        if not credentials_valid:
            return Response(
                status=status.HTTP_400_BAD_REQUEST,
                data={"message": credentials_error or "Invalid credentials"},
            )

        try:
            schemas = new_source.get_schemas(
                config, self.team_id, names=[instance.name], api_version=effective_api_version
            )
        except Exception as e:
            # `validate_credentials` above just probed the same connection successfully, so a
            # failure here that the source itself classifies as non-retryable (e.g. a connect-time
            # timeout, which usually means an unreachable host or unconfigured firewall) is an
            # expected customer/upstream condition, not a bug — don't flood error tracking with it.
            # Mirrors `refresh_schemas`'s `_classify_refresh_schemas_error`.
            error_text = str(e)
            if not any(pattern and pattern in error_text for pattern in new_source.get_non_retryable_errors()):
                capture_exception(e)
            return Response(
                status=status.HTTP_400_BAD_REQUEST,
                data={"message": str(e)},
            )

        # Not every source honors the `names` filter (e.g. Slack returns all schemas regardless), so
        # `schemas` may contain unrelated tables in any order. Pick the one that matches this schema
        # instead of trusting `schemas[0]`, whose metadata could belong to a different table.
        schema = next((s for s in schemas if s.name == instance.name), None)
        if schema is None:
            return Response(
                status=status.HTTP_400_BAD_REQUEST, data={"message": f"Schema with name {instance.name} not found"}
            )

        # job_inputs is an EncryptedJSONField: booleans round-trip as "True"/"False"
        # strings, so bool(...) would treat "False" as truthy. str_to_bool decodes both.
        source_cdc_enabled = str_to_bool(source.job_inputs.get("cdc_enabled"))
        cdc_available = schema.supports_cdc if is_cdc_enabled_for_team(self.team) and source_cdc_enabled else None
        # xmin is source-capability-gated, mirroring the database_schema endpoint.
        xmin_available = (
            schema.supports_xmin
            if SourceRegistry.get_source(ExternalDataSourceType(source.source_type)).supports_xmin
            else None
        )

        data = {
            "incremental_fields": schema.incremental_fields,
            "incremental_available": schema.supports_incremental,
            "append_available": schema.supports_append,
            "cdc_available": cdc_available,
            "xmin_available": xmin_available,
            "full_refresh_available": not schema.webhook_only,
            "supports_webhooks": schema.supports_webhooks,
            "webhook_only": schema.webhook_only,
            "available_columns": [
                {"field": col_name, "label": col_name, "type": col_type, "nullable": nullable}
                for col_name, col_type, nullable in schema.columns
            ],
            "detected_primary_keys": schema.detected_primary_keys,
        }

        return Response(status=status.HTTP_200_OK, data=data)
