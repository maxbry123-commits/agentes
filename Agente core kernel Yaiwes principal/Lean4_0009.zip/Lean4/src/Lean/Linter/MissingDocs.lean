/-
Copyright (c) 2022 Mario Carneiro. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Mario Carneiro
-/
module

prelude
public import Lean.Parser.Syntax
public import Lean.Meta.Tactic.Simp.RegisterCommand
public import Lean.Elab.Command
public import Lean.Linter.Util

public section

namespace Lean.Linter
open Elab.Command Parser Command
open Parser.Term hiding «set_option»

register_builtin_option linter.missingDocs : Bool := {
  defValue := false
  descr := "enable the 'missing documentation' linter"
}

def getLinterMissingDocs (o : LinterOptions) : Bool := getLinterValue linter.missingDocs o


namespace MissingDocs

abbrev SimpleHandler := Syntax → CommandElabM Unit
abbrev Handler := Bool → SimpleHandler

def SimpleHandler.toHandler (h : SimpleHandler) : Handler :=
  fun enabled stx => if enabled then h stx else pure ()

unsafe def mkHandlerUnsafe (constName : Name) : ImportM Handler := do
  let env  := (← read).env
  let opts := (← read).opts
  match env.find? constName with
  | none      => throw ↑s!"Unknown constant `{constName}`"
  | some info => match info.type with
    | Expr.const ``SimpleHandler _ => do
      let h ← IO.ofExcept $ env.evalConst SimpleHandler opts constName
      pure h.toHandler
    | Expr.const ``Handler _ =>
      IO.ofExcept $ env.evalConst Handler opts constName
    | _ => throw ↑s!"unexpected missing docs handler at '{constName}', `MissingDocs.Handler` or `MissingDocs.SimpleHandler` expected"

@[implemented_by mkHandlerUnsafe]
opaque mkHandler (constName : Name) : ImportM Handler

builtin_initialize builtinHandlersRef : IO.Ref (NameMap Handler) ← IO.mkRef {}

builtin_initialize missingDocsExt :
  PersistentEnvExtension (Name × Name) (Name × Name × Handler) (List (Name × Name) × NameMap Handler) ←
  registerPersistentEnvExtension {
    mkInitial       := return ([], ← builtinHandlersRef.get)
    addImportedFn   := fun as => do
      ([], ·) <$> as.foldlM (init := ← builtinHandlersRef.get) fun s as =>
        as.foldlM (init := s) fun s (n, k) => s.insert k <$> mkHandler n
    addEntryFn      := fun (entries, s) (n, k, h) => ((n, k)::entries, s.insert k h)
    exportEntriesFn := fun s => s.1.reverse.toArray
    statsFn := fun s => format "number of local entries: " ++ format s.1.length
  }

def addHandler (env : Environment) (declName key : Name) (h : Handler) : Environment :=
  missingDocsExt.addEntry env (declName, key, h)

def getHandlers (env : Environment) : NameMap Handler := (missingDocsExt.getState env).2

partial def missingDocs : Linter where
  run stx := do
    if let some h := (getHandlers (← getEnv)).find? stx.getKind then
      h (getLinterMissingDocs (← getLinterOptions)) stx

builtin_initialize addLinter missingDocs

def addBuiltinHandler (key : Name) (h : Handler) : IO Unit :=
  builtinHandlersRef.modify (·.insert key h)

builtin_initialize
  let mkAttr (builtin : Bool) (name : Name) := registerBuiltinAttribute {
    name
    descr           := (if builtin then "(builtin) " else "") ++
      "adds a syntax traversal for the missing docs linter"
    applicationTime := .afterCompilation
    add             := fun declName stx kind => do
      unless kind == AttributeKind.global do throwAttrMustBeGlobal name kind
      if !builtin then
        ensureAttrDeclIsMeta name declName kind
      let env ← getEnv
      unless builtin || (env.getModuleIdxFor? declName).isNone do
        throwAttrDeclInImportedModule name declName
      let decl ← getConstInfo declName
      let fnNameStx ← Attribute.Builtin.getIdent stx
      let key ← Elab.realizeGlobalConstNoOverloadWithInfo fnNameStx
      recordExtraModUseFromDecl (isMeta := false) key
      unless decl.levelParams.isEmpty && (decl.type == .const ``Handler [] || decl.type == .const ``SimpleHandler []) do
        throwError m!"Unexpected type for missing docs handler: Expected `{.ofConstName ``Handler}` or \
          `{.ofConstName ``SimpleHandler}`, but `{declName}` has type{indentExpr decl.type}"
      if builtin then
        let h := if decl.type == .const ``SimpleHandler [] then
          mkApp (mkConst ``SimpleHandler.toHandler) (mkConst declName)
        else mkConst declName
        declareBuiltin declName <| mkApp2 (mkConst ``addBuiltinHandler) (toExpr key) h
      else
        setEnv <| missingDocsExt.addEntry env (declName, key, ← mkHandler declName)
  }
  mkAttr true `builtin_missing_docs_handler
  mkAttr false `missing_docs_handler

def lint (stx : Syntax) (msg : String) : CommandElabM Unit :=
  logLint linter.missingDocs stx m!"missing doc string for {msg}"

def lintEmpty (stx : Syntax) (msg : String) : CommandElabM Unit :=
  logLint linter.missingDocs stx m!"empty doc string for {msg}"

def lintNamed (stx : Syntax) (msg : String) : CommandElabM Unit :=
  lint stx s!"{msg} {stx.getId}"

def lintEmptyNamed (stx : Syntax) (msg : String) : CommandElabM Unit :=
  lintEmpty stx s!"{msg} {stx.getId}"

def lintField (parent stx : Syntax) (msg : String) : CommandElabM Unit :=
  lint stx s!"{msg} {parent.getId}.{stx.getId}"

def lintEmptyField (parent stx : Syntax) (msg : String) : CommandElabM Unit :=
  lintEmpty stx s!"{msg} {parent.getId}.{stx.getId}"

def lintStructField (parent stx : Syntax) (msg : String) : CommandElabM Unit :=
  lint stx s!"{msg} {parent.getId}.{stx.getId}"

private def isEmptyDocString (docOpt : Syntax) : CommandElabM Bool := do
  if docOpt.isNone then return false
  let docStx : TSyntax `Lean.Parser.Command.docComment := ⟨docOpt[0]⟩
  -- Verso doc comments with interpolated content cannot be extracted as plain text,
  -- but they are clearly not empty.
  if let .node _ `Lean.Parser.Command.versoCommentBody _ := docStx.raw[1] then
    if !docStx.raw[1][0].isAtom then return false
  let text ← getDocStringText docStx
  return text.trimAscii.isEmpty

def isMissingDoc (docOpt : Syntax) : CommandElabM Bool := do
  return docOpt.isNone || (← isEmptyDocString docOpt)

def hasInheritDoc (attrs : Syntax) : Bool :=
  attrs[0][1].getSepArgs.any fun attr =>
    attr[1].isOfKind ``Parser.Attr.simple &&
    attr[1][0].getId.eraseMacroScopes == `inherit_doc

def hasTacticAlt (attrs : Syntax) : Bool :=
  attrs[0][1].getSepArgs.any fun attr =>
    attr[1].isOfKind ``Parser.Attr.tactic_alt

def declModifiersDocStatus (mods : Syntax) : CommandElabM (Option Bool) := do
  let isPublic := if (← getEnv).header.isModule && !(← getScope).isPublic then
    mods[2][0].getKind == ``Command.public else
    mods[2][0].getKind != ``Command.private
  if !isPublic || hasInheritDoc mods[1] then return none
  if mods[0].isNone then return some false
  if (← isEmptyDocString mods[0]) then return some true
  return none

def declModifiersPubNoDoc (mods : Syntax) : CommandElabM Bool := do
  return (← declModifiersDocStatus mods).isSome

private def lintDocStatus (isEmpty : Bool) (stx : Syntax) (msg : String) : CommandElabM Unit :=
  if isEmpty then lintEmpty stx msg else lint stx msg

private def lintDocStatusNamed (isEmpty : Bool) (stx : Syntax) (msg : String) : CommandElabM Unit :=
  if isEmpty then lintEmptyNamed stx msg else lintNamed stx msg

private def lintDocStatusField (isEmpty : Bool) (parent stx : Syntax) (msg : String) :
    CommandElabM Unit :=
  if isEmpty then lintEmptyField parent stx msg else lintField parent stx msg

def lintDeclHead (k : SyntaxNodeKind) (id : Syntax) (isEmpty : Bool := false) :
    CommandElabM Unit := do
  if k == ``«abbrev» then lintDocStatusNamed isEmpty id "public abbrev"
  else if k == ``definition then lintDocStatusNamed isEmpty id "public def"
  else if k == ``«opaque» then lintDocStatusNamed isEmpty id "public opaque"
  else if k == ``«axiom» then lintDocStatusNamed isEmpty id "public axiom"
  else if k == ``«inductive» then lintDocStatusNamed isEmpty id "public inductive"
  else if k == ``classInductive then lintDocStatusNamed isEmpty id "public inductive"
  else if k == ``«structure» then lintDocStatusNamed isEmpty id "public structure"

private def docOptStatus (docOpt attrs : Syntax) (checkTacticAlt := false) :
    CommandElabM (Option Bool) := do
  if hasInheritDoc attrs then return none
  if checkTacticAlt && hasTacticAlt attrs then return none
  if docOpt.isNone then return some false
  if (← isEmptyDocString docOpt) then return some true
  return none

@[builtin_missing_docs_handler declaration]
def checkDecl : SimpleHandler := fun stx => do
  let head := stx[0]; let rest := stx[1]
  if head[2][0].getKind == ``Command.private then return -- not private
  let k := rest.getKind
  if let some isEmpty ← declModifiersDocStatus head then
    lintDeclHead k rest[1][0] isEmpty
  if k == ``«inductive» || k == ``classInductive then
    for stx in rest[4].getArgs do
      let head := stx[2]
      -- Constructor has two doc comment positions: the leading one before `|` (stx[0])
      -- and the one inside declModifiers (head[0]). If either is non-empty, skip.
      let leadingEmpty ← isEmptyDocString stx[0]
      if !stx[0].isNone && !leadingEmpty then
        pure () -- constructor has a non-empty leading doc comment
      else if let some modsEmpty ← declModifiersDocStatus head then
        lintDocStatusField (leadingEmpty || modsEmpty) rest[1][0] stx[3] "public constructor"
    unless rest[5].isNone do
      for stx in rest[5][0][1].getArgs do
        let head := stx[0]
        if let some isEmpty ← declModifiersDocStatus head then
          lintDocStatusField isEmpty rest[1][0] stx[1] "computed field"
  else if rest.getKind == ``«structure» then
    unless rest[4][2].isNone do
      let redecls : Std.HashSet String.Pos.Raw :=
        (← get).infoState.trees.foldl (init := {}) fun s tree =>
          tree.foldInfo (init := s) fun _ info s =>
            if let .ofFieldRedeclInfo info := info then
              if let some range := info.stx.getRange? then
                s.insert range.start
              else s
            else s
      let parent := rest[1][0]
      let lint1 isEmpty stx := do
        if let some range := stx.getRange? then
          if redecls.contains range.start then return
        lintDocStatusField isEmpty parent stx "public field"
      for stx in rest[4][2][0].getArgs do
        let head := stx[0]
        if let some isEmpty ← declModifiersDocStatus head then
          if stx.getKind == ``structSimpleBinder then
            lint1 isEmpty stx[1]
          else
            for stx in stx[2].getArgs do
              lint1 isEmpty stx

@[builtin_missing_docs_handler «initialize»]
def checkInit : SimpleHandler := fun stx => do
  if !stx[2].isNone then
    if let some isEmpty ← declModifiersDocStatus stx[0] then
      lintDocStatusNamed isEmpty stx[2][0] "initializer"

@[builtin_missing_docs_handler «notation»]
def checkNotation : SimpleHandler := fun stx => do
  if stx[2][0][0].getKind != ``«local» then
    if let some isEmpty ← docOptStatus stx[0] stx[1] then
      if stx[5].isNone then lintDocStatus isEmpty stx[3] "notation"
      else lintDocStatusNamed isEmpty stx[5][0][3] "notation"

@[builtin_missing_docs_handler «mixfix»]
def checkMixfix : SimpleHandler := fun stx => do
  if stx[2][0][0].getKind != ``«local» then
    if let some isEmpty ← docOptStatus stx[0] stx[1] then
      if stx[5].isNone then lintDocStatus isEmpty stx[3] stx[3][0].getAtomVal
      else lintDocStatusNamed isEmpty stx[5][0][3] stx[3][0].getAtomVal

@[builtin_missing_docs_handler «syntax»]
def checkSyntax : SimpleHandler := fun stx => do
  if stx[2][0][0].getKind != ``«local» then
    if let some isEmpty ← docOptStatus stx[0] stx[1] (checkTacticAlt := true) then
      if stx[5].isNone then lintDocStatus isEmpty stx[3] "syntax"
      else lintDocStatusNamed isEmpty stx[5][0][3] "syntax"

def mkSimpleHandler (name : String) (declNameStxIdx := 2) : SimpleHandler := fun stx => do
  if (← isMissingDoc stx[0]) then
    if (← isEmptyDocString stx[0]) then
      lintEmptyNamed stx[declNameStxIdx] name
    else
      lintNamed stx[declNameStxIdx] name

@[builtin_missing_docs_handler syntaxAbbrev]
def checkSyntaxAbbrev : SimpleHandler := mkSimpleHandler "syntax"

@[builtin_missing_docs_handler syntaxCat]
def checkSyntaxCat : SimpleHandler := mkSimpleHandler "syntax category"

@[builtin_missing_docs_handler «macro»]
def checkMacro : SimpleHandler := fun stx => do
  if stx[2][0][0].getKind != ``«local» then
    if let some isEmpty ← docOptStatus stx[0] stx[1] (checkTacticAlt := true) then
      if stx[5].isNone then lintDocStatus isEmpty stx[3] "macro"
      else lintDocStatusNamed isEmpty stx[5][0][3] "macro"

@[builtin_missing_docs_handler «elab»]
def checkElab : SimpleHandler := fun stx => do
  if stx[2][0][0].getKind != ``«local» then
    if let some isEmpty ← docOptStatus stx[0] stx[1] (checkTacticAlt := true) then
      if stx[5].isNone then lintDocStatus isEmpty stx[3] "elab"
      else lintDocStatusNamed isEmpty stx[5][0][3] "elab"

@[builtin_missing_docs_handler classAbbrev]
def checkClassAbbrev : SimpleHandler := fun stx => do
  if let some isEmpty ← declModifiersDocStatus stx[0] then
    lintDocStatusNamed isEmpty stx[3] "class abbrev"

@[builtin_missing_docs_handler Parser.Tactic.declareSimpLikeTactic]
def checkSimpLike : SimpleHandler := mkSimpleHandler "simp-like tactic"

@[builtin_missing_docs_handler Option.registerBuiltinOption]
def checkRegisterBuiltinOption : SimpleHandler := mkSimpleHandler (declNameStxIdx := 3) "option"

@[builtin_missing_docs_handler Option.registerOption]
def checkRegisterOption : SimpleHandler := fun stx => do
  if let some isEmpty ← declModifiersDocStatus stx[0] then
    lintDocStatusNamed isEmpty stx[2] "option"

@[builtin_missing_docs_handler registerSimpAttr]
def checkRegisterSimpAttr : SimpleHandler := mkSimpleHandler "simp attr"

@[builtin_missing_docs_handler «in»]
def handleIn : Handler := fun _ stx => do
  -- Note: the missing docs linter must descend into `in`s which are not of the form
  -- `set_option ... in`. This is unlike `withSetOptionIn`, which stops at the first `in` not of
  -- the form `set_option ... in`; as such, we must inline the functionality.
  if stx[0].getKind == ``«set_option» then
    let opts ← Elab.withEnableInfoTree false try
        (·.1) <$> Elab.elabSetOption stx[0][1] stx[0][3]
      catch _ => getOptions
    withScope ({ · with opts }) do missingDocs.run stx[2]
  else
    missingDocs.run stx[2]

@[builtin_missing_docs_handler «mutual»]
def handleMutual : Handler := fun _ stx => do
  stx[1].getArgs.forM missingDocs.run
