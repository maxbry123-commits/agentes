/-
Copyright (c) 2026 Lean FRO LLC. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Sebastian Graf, Vladimir Gladshtein
-/
module

prelude
public import Lean.Elab.Tactic.VCGen.Context
public import Lean.Elab.Tactic.VCGen.RuleCache
public import Lean.Elab.Tactic.VCGen.Entails
public import Lean.Elab.Tactic.VCGen.BinderName
public import Lean.Meta.Sym.InstantiateS
public import Lean.Meta.Sym.Simp.App
import Lean.Meta.Sym.InferType
import Lean.Meta.Sym.InstantiateMVarsS
import Init.Data.Prod

open Lean Meta Elab Tactic Sym Sym.Internal
open Lean.Elab.Tactic.VCGen.SpecAttr
open Lean.Elab.Tactic.VCGen
open Std.WP Lean.Order

namespace Lean.Elab.Tactic.VCGen

/-!
The main `solve` step. Runs once per worklist iteration and either fully
decomposes the current goal into subgoals, or reports why no further
progress is possible (`SolveResult`).
-/


/-- The reason why no further VC generation progress is possible on the current goal. -/
public inductive SolveResult.StopReason where
  /-- Out of fuel. -/
  | outOfFuel
  /-- `until <pat>` matched. -/
  | untilPatternMatched (m : Expr)
  /-- The target was not of the form `pre ⊑ rhs`. -/
  | noEntailment (target : Expr)
  /-- The target was of the form `pre ⊑ rhs`, but we couldn't make further progress. -/
  | noProgress (pre rhs : Expr)
  /-- No spec applicable to the program `e` in `pre ⊑ wp e post epost s₁ ... sₙ` was found; `thms`
  are the candidates that were tried. Reached only when `errorOnMissingSpec` is `false`. -/
  | noSpecFound (e : Expr) (monad : Expr) (thms : Array SpecTheorem)

/-- The result of one `solve` step of VC generation. -/
public inductive SolveResult where
  /-- Successfully decomposed the goal. These are the subgoals, sharing `scope`. -/
  | goals (scope : Scope) (subgoals : List MVarId)
  /-- No further progress possible; emit the current goal as a VC. -/
  | stop (reason : SolveResult.StopReason)

private def isDuplicable (e : Expr) : Bool := match e with
  | .bvar .. | .mvar .. | .fvar .. | .const .. | .lit .. | .sort .. => true
  | .mdata _ e | .proj _ _ e => isDuplicable e
  | .lam .. | .forallE .. | .letE .. => false
  | .app .. => e.isAppOf ``OfNat.ofNat

/-- Strip an annotation, such as the `noImplicitLambda` metadata a tactic `have`/`let`/`suffices`
leaves on the goal, so later strategies and the backward rules they invoke see the bare target. -/
private def consumeMData? (goal : MVarId) (target : Expr) : VCGenM (Option MVarId) := do
  unless target.isMData do return none
  return some (← goal.replaceTargetDefEqFast target.consumeMData)

/-- Split `∀ p : Nat × Nat, P p` into `∀ a b, P (a, b)`. -/
private def splitProdBinder (goal : MVarId) (target : Expr) : VCGenM MVarId :=
  goal.withContext do
  let .forallE _ dom body _ := target | return goal
  let dom ← instantiateMVarsIfMVarAppS dom
  let_expr c@Prod α β := dom | return goal
  let us := c.constLevels!
  let mk ← mkAppNS (← mkConstS ``Prod.mk us) #[α, β, .bvar 1, .bvar 0]
  let newTarget := Expr.forallE `a α (.forallE `b β (body.instantiate1 mk) .default) .default
  let g ← liftMetaM <| mkFreshExprSyntheticOpaqueMVar (← shareCommon newTarget)
  let motive := Expr.lam `p dom body .default
  let prodForall ← mkAppNS (← mkConstS ``Prod.forall us) #[α, β, motive]
  goal.assign <| mkApp4 (.const ``Iff.mpr []) target newTarget prodForall g
  return g.mvarId!

/-- Strategy 1: simp the target, then introduce binders if the target is a `∀`. -/
private def forallIntro? (oldGoal : MVarId) (target : Expr) : VCGenM (Option (List MVarId)) := do
  unless target.isForall do return none
  let mut goal ← match ← simpGoalTelescope oldGoal with
    | .closed => return some []
    | .goal goal => pure goal
    | .noProgress => pure oldGoal
  let mut target ← goal.getType
  while target.isForall do
    let n := numBindersToIntro target
    let goal' ← if n == 0 then splitProdBinder goal target else introsHygienicN goal n
    if goal' == goal then break
    goal := goal'
    target ← goal.getType
  if goal == oldGoal then
    throwError "Failed to intro forall target {goal}"
  return some [goal]

private def throwIfUnsupportedJP (name : Name) (val : Expr) : VCGenM Unit := do
  if (← read).useJP && Lean.Elab.Tactic.Do.isJP name && val.isLambda then
    throwError "vcgen: shared-continuation handling for `__do_jp` is not yet \
      implemented. Detection point reached at {name}; the upstream \
      `Lean.Elab.Tactic.Do.onJoinPoint` (`src/Lean/Elab/Tactic/Do/VCGen.lean:215`) \
      needs to be ported to the worklist style. Drop `(jp := true)` to fall back \
      to the default zeta-unfold behaviour."

/-- Strategy 2: zeta-substitute a duplicable top-level `let` in the target, otherwise
introduce it into the local context. -/
private def targetLetIntro? (goal : MVarId) (target : Expr) : VCGenM (Option MVarId) := do
  let .letE name _ val body _ := target | return none
  throwIfUnsupportedJP name val
  if isDuplicable val then
    trace[Elab.Tactic.Do.vcgen] "let-zeta-dup: {name}"
    return some (← goal.replaceTargetDefEqFast (← Sym.instantiateRevBetaS body #[val]))
  else
    trace[Elab.Tactic.Do.vcgen] "let-intro: {name}"
    return some (← introsHygienic goal)

/-- Strategy 3: unfold a `Triple` target into the underlying lattice entailment. -/
private def tripleUnfold? (goal : MVarId) (target : Expr) : VCGenM (Option MVarId) := do
  unless target.isAppOf ``Triple do return none
  return some (← unfoldTriple goal)

/-- Strategy 3b: turn a bare `wp` application target (a `Prop`) into `⊤ ⊑ wp …`. Entry-point
goals produced by the `of_run_eq_wp` lemmas have this shape. -/
private def bareWPToLe? (goal : MVarId) (target : Expr) : VCGenM (Option MVarId) := do
  let some _ := isWPApp? target | return none
  let newTarget ← mkAppM ``PartialOrder.rel #[← mkAppOptM ``Lean.Order.top #[mkSort 0, none], target]
  let newTarget ← shareCommon newTarget
  let g ← liftMetaM <| mkFreshExprSyntheticOpaqueMVar newTarget
  goal.assign (mkApp2 (mkConst ``Lean.Order.of_top_le_prop) target g)
  return some g.mvarId!

/-- Strategy 4: close a reflexive entailment `pre ⊑ pre` by applying `PartialOrder.rel_refl`.
Runs before the precondition lift so a spec handoff `pre ⊑ specPre` closes by unification rather
than an assumption search. The pattern matcher keeps synthetic-opaque invariant holes rigid, so
`⊤ ⊑ ?inv args` is left untouched. -/
private def rfl? (goal : MVarId) : VCGenM (Option (List MVarId)) := do
  let .goals gs ← (← read).backwardRules.refl.apply goal | return none
  trace[Elab.Tactic.Do.vcgen] "Solved by rfl {goal}"
  return some gs

/-- The most recently lifted pure precondition (cached in `Scope.lastLiftedPre?`) whose type is
the same hash-consed expression as `e`, or `none`. Must run in `goal`'s context. -/
private def liftedPreFor? (scope : Scope) (e : Expr) : VCGenM (Option LocalDecl) := do
  let some fvarId := scope.lastLiftedPre? | return none
  let some hyp := (← getLCtx).find? fvarId | return none
  unless isSameExpr e hyp.type do return none
  trace[Elab.Tactic.Do.vcgen] "Solved by lifted hypothesis {hyp.userName}"
  return some hyp

/-- Strategy 10: close `pre ⊑ φ` on the `Prop` lattice against the most recently lifted pure
precondition. Runs after lattice decomposition, so `φ` is an opaque proposition rather than a
lattice connective. This is one comparison against one hypothesis, not an assumption search. -/
private def liftedHyp? (scope : Scope) (goal : MVarId) (α pre rhs : Expr) :
    VCGenM (Option (List MVarId)) :=
  goal.withContext do
    unless α.isProp do return none
    let some hyp ← liftedPreFor? scope rhs | return none
    goal.assign (← mkAppM ``Lean.Order.le_of_right #[pre, rhs, hyp.toExpr])
    return some []

/-- Close a bare `Prop` residual, such as the subgoal of the `⌜φ⌝` lattice rule, against the
most recently lifted pure precondition. Runs when the target is not a lattice entailment,
just before it would be classified as a VC. -/
private def liftedHypBare? (scope : Scope) (goal : MVarId) (target : Expr) :
    VCGenM (Option (List MVarId)) :=
  goal.withContext do
    let some hyp ← liftedPreFor? scope target | return none
    goal.assign hyp.toExpr
    return some []

/-- Replace the `i`-th argument of the application `e`, which has `n` arguments. -/
private def setAppArg (e : Expr) (i n : Nat) (v : Expr) : Expr :=
  match e with
  | .app f a => if n == i + 1 then e.updateApp! f v else e.updateApp! (setAppArg f i (n-1) v) a
  | _ => e

/-- Instantiate an assigned metavariable in the program of the `wp` application `rhs`. -/
private def instantiateWPProg? (rhs : Expr) : VCGenM (Option Expr) := do
  unless rhs.hasMVar do return none
  let n := rhs.getAppNumArgs
  unless n > 7 && rhs.getAppFn.isConstOf ``Std.WP.wp do return none
  let prog := rhs.getArg! 7 n
  let prog' ← instantiateMVarsIfMVarAppS prog
  if isSameExpr prog prog' then return none
  return some (← shareCommon (setAppArg rhs 7 n prog'))

/-- Instantiate assigned head metavariables in the goal's entailment, so the shape tests in the
following steps see the assigned form. -/
private def instantiateGoal? (goal : MVarId) (target : Expr) : VCGenM (Option MVarId) := do
  let_expr c@PartialOrder.rel α inst pre rhs := target | return none
  let α' ← instantiateMVarsIfMVarAppS α
  let pre' ← instantiateMVarsIfMVarAppS pre
  let rhs' ← instantiateMVarsIfMVarAppS rhs
  let rhs' := (← instantiateWPProg? rhs').getD rhs'
  if isSameExpr α α' && isSameExpr pre pre' && isSameExpr rhs rhs' then return none
  return some (← goal.replaceTargetDefEqFast (← mkAppNS c #[α', inst, pre', rhs']))

/-- Strategy 5: cancel a redundant `P ⊓ ⊤` precondition via `meet_top_le_of_le`, leaving `P ⊑ rhs`.
Such a precondition arises when `himp_complete` splits `⊤ ⊑ a ⇨ b` into `a ⊓ ⊤ ⊑ b`. -/
private def stripMeetTopPre? (goal : MVarId) (pre : Expr) : VCGenM (Option MVarId) := do
  let_expr Lean.Order.meet _l _inst _P top := pre | return none
  unless top.isAppOf ``Lean.Order.top do return none
  let .goals [g] ← (← read).backwardRules.meetTop.applyChecked goal
    | throwError "Failed to cancel the `⊓ ⊤` precondition of {goal}"
  return some g

/-- Strategy 5: lift an embedded pure precondition `⌜φ⌝` into the local context, leaving `⊤`
as the residual precondition. Runs before state-argument introduction, which would otherwise
leave `⌜φ⌝` applied to the introduced arguments. Returns the new goal and the hypothesis. -/
private def ofPropPreIntro? (goal : MVarId) (pre : Expr) : VCGenM (Option (MVarId × FVarId)) := do
  let_expr CompleteLattice.ofProp _l _inst φ := pre | return none
  if φ.isTrue then return none
  return some (← introPre (← read).backwardRules.ofPropPreIntro goal)

/-- Strategy 5: lift the pure `φ` of a `⌜φ⌝ ⊓ P` precondition into the local context, leaving
`P ⊑ rhs`. -/
private def ofPropMeetPreIntro? (goal : MVarId) (pre : Expr) : VCGenM (Option (MVarId × FVarId)) := do
  let_expr Lean.Order.meet _l _inst lhs _rest := pre | return none
  let_expr CompleteLattice.ofProp _l' _inst' _φ := lhs | return none
  return some (← introPre (← read).backwardRules.ofPropMeetPreIntro goal)

/-- Strategy 5: eliminate an `iSup` precondition via `iSup_le`, leaving the pointwise entailment
`∀ i, P i ⊑ rhs` for `∀`-introduction. -/
private def iSupPreIntro? (goal : MVarId) (pre : Expr) : VCGenM (Option MVarId) := do
  unless pre.isAppOfArity ``Lean.Order.iSup 4 do return none
  let .goals [g] ← (← read).backwardRules.iSupPreIntro.applyChecked goal
    | throwError "Failed to eliminate the `iSup` precondition of {goal}"
  return some g

/-- Strategy 7: move a bare `Prop` precondition `φ ⊑ rhs` into the local context via
`le_of_imp_top_le`, leaving `⊤ ⊑ rhs`. Runs after `True` and `⊤` preconditions are handled, so
`φ` carries information worth keeping. Returns the new goal and the introduced hypothesis. -/
private def barePreIntro? (goal : MVarId) (α pre : Expr) : VCGenM (Option (MVarId × FVarId)) := do
  unless α.isProp do return none
  if pre.isAppOf ``Lean.Order.top then return none
  return some (← introPre (← read).backwardRules.propPreIntro goal)

/-- Strategy 7: replace a `True` precondition by `⊤` via `true_le_of_top_le`, or reduce a lifted
`⊤ s₁ … sₙ` precondition (the bare top applied to the state arguments introduced by
`le_of_forall_le`) to the bare `⊤` via a `top_apply` rewrite. Either way the goal follows the `⊤`
path instead of lifting into the local context, and a `⊤`-precondition VC reaches `elimTopPre` in the
bare form that `top_le_prop` can strip. -/
private def normalizePreToTop? (goal : MVarId) (pre target : Expr) : VCGenM (Option (List MVarId)) := do
  if pre.isTrue then
    let .goals [g] ← (← read).backwardRules.truePreIntro.applyChecked goal
      | throwError "Failed to apply {.ofConstName ``Lean.Order.true_le_of_top_le} to{indentExpr target}"
    return some [g]
  if let some g ← reduceTopAppliedPre? goal target pre then
    return some [g]
  return none

/-- Phase 2: drive the precondition of `pre ⊑ rhs` toward `⊤`, lifting any pure content into the
local context so a later spec application sees a `⊤` precondition. In order: cancel a redundant
`⊓ ⊤`; lift an embedded `⌜φ⌝` (before state-argument introduction, which would otherwise leave
`⌜φ⌝` applied to the introduced state); lift the guard of a `⌜φ⌝ ⊓ P`; eliminate an `iSup`;
introduce excess state arguments; drop a `True` precondition; lift a bare `Prop` precondition.
Returns the updated scope, recording any lifted hypothesis. -/
private def normalizePre? (scope : Scope) (goal : MVarId) (α pre target : Expr) :
    VCGenM (Option (Scope × List MVarId)) := do
  if let some g ← stripMeetTopPre? goal pre then
    return some (scope, [g])
  if let some (g, h) ← ofPropPreIntro? goal pre then
    return some ({ scope with lastLiftedPre? := some h }, [g])
  if let some (g, h) ← ofPropMeetPreIntro? goal pre then
    return some ({ scope with lastLiftedPre? := some h }, [g])
  if let some g ← iSupPreIntro? goal pre then
    return some (scope, [g])
  if let some goal' ← introsExcessArgs goal then return some (scope, [goal'])
  if let some gs ← normalizePreToTop? goal pre target then
    return some (scope, gs)
  if let some (g, h) ← barePreIntro? goal α pre then
    return some ({ scope with lastLiftedPre? := some h }, [g])
  return none

/-- Replace the program in `goal`'s target with `prog` (which must be definitionally equal). -/
private def replaceProgDefEq (goal : MVarId) (info : WPApp) (prog : Expr) :
    VCGenM MVarId := do
  let wp ← mkAppNS info.head <| info.args.set! 7 prog
  let rhs ← mkAppNS wp info.excessArgs
  let target ← goal.getType
  let relArgs := target.getAppArgs
  let newTarget ← mkAppNS target.getAppFn (relArgs.set! (relArgs.size - 1) rhs)
  goal.replaceTargetDefEqFast newTarget

/-- Strip an `mdata` wrapper (such as the `save_info` annotation left by spec elaboration)
from the program in `goal`'s target, so the remaining strategies see the bare term. -/
private def wpConsumeMData? (goal : MVarId) (info : WPApp) : VCGenM (Option MVarId) := do
  let .mdata .. := info.prog | return none
  return some (← replaceProgDefEq goal info info.prog.consumeMData)

/-- Strategy 11a: hoist or zeta-substitute a `let` from the program head. -/
private def wpLet? (goal : MVarId) (info : WPApp) : VCGenM (Option MVarId) := do
  let .letE name type val body nondep := info.prog.getAppFn | return none
  let appArgs := info.prog.getAppRevArgs
  throwIfUnsupportedJP name val
  let val ← reduceHead val
  if isDuplicable val then
    trace[Elab.Tactic.Do.vcgen] "let-zeta-dup: {name}"
    let body' ← Sym.instantiateRevBetaS body #[val]
    let prog ← mkAppRevS body' appArgs
    return some (← replaceProgDefEq goal info prog)
  else
    trace[Elab.Tactic.Do.vcgen] "let-hoist: {name}"
    let prog ← mkAppRevS body appArgs
    let wp ← mkAppNS info.head <| info.args.set! 7 prog
    let rhs ← mkAppNS wp info.excessArgs
    let target ← goal.getType
    let relArgs := target.getAppArgs
    let target ← mkAppNS target.getAppFn (relArgs.set! (relArgs.size - 1) rhs)
    let target := Expr.letE name type val target nondep
    let goal ← goal.replaceTargetDefEqFast target
    let name ← if isProgramName name then pure name else Meta.mkFreshBinderNameForTactic name
    let .goal _ goal ← Sym.intros goal #[name]
      | throwError "Failed to intro the `let` of{indentExpr info.prog}"
    return some goal

/-- Strategy 11b: fold the state arguments of the program's `wp` application, so the symbolic
state a spec application threads through the goal is normalized as it is produced rather than left
to the discharging tactic. Runs the `simplifying_assumptions` rewrite set when one is configured
and the plain `Sym.Simp` methods otherwise; the program, the postcondition and the precondition are
left untouched. -/
private def wpSimpStateArgs? (goal : MVarId) (info : WPApp) :
    VCGenM (Option (List MVarId)) := goal.withContext do
  if info.excessArgs.isEmpty then return none
  let some methods := (← read).hypSimpMethods | return none
  let start := info.args.size
  let target ← goal.getType
  match h : target with
  | .app f rhs =>
    let (result, simpState') ← Sym.Simp.SimpM.run
      (do
        let ar ← Sym.Simp.simpAppArgRange rhs start (start + info.excessArgs.size)
        Sym.Simp.mkCongr target f rhs .rfl ar h)
      methods {} (← get).simpState
    modify fun st => { st with simpState := simpState' }
    match ← result.toSimpGoalResult goal with
    | .closed => return some []
    | .goal g => return some [g]
    | .noProgress => return none
  | _ => return none

/-- Strategy 11b: split an `ite`/`dite`/`cond`/match program, or iota-reduce a matcher with a
concrete discriminant. -/
private def wpMatch? (goal : MVarId) (info : WPApp) :
    VCGenM (Option (List MVarId)) := do
  let some splitInfo ← liftMetaM <| Lean.Elab.Tactic.Do.getSplitInfo? info.prog | return none
  if splitInfo matches .matcher .. then
    if let some prog ← liftMetaM <| withReducible <| reduceRecMatcher? info.prog then
      return some [← replaceProgDefEq goal info (← shareCommonInc prog)]
  let rule ← mkBackwardRuleForSplitCached splitInfo info
  let .goals goals ← rule.applyChecked goal m!"split rule for{indentExpr info.prog}"
    | throwError "Failed to apply split rule for {indentExpr info.prog}"
  let mut simpGoals := #[]
  for g in goals do
    match ← simpGoalTelescope g with
    | .goal g' => simpGoals := simpGoals.push g'
    | .noProgress => simpGoals := simpGoals.push g
    | .closed => continue
  return some simpGoals.toList

/-- Strategy 11c: zeta-unfold a local let-bound fvar used as the program head. -/
private def wpFVarZeta? (goal : MVarId) (info : WPApp) :
    VCGenM (Option MVarId) := do
  let f := info.prog.getAppFn
  let some fvarId := f.fvarId? | return none
  let some val ← fvarId.getValue? | return none
  trace[Elab.Tactic.Do.vcgen] "fvar-zeta: {(← fvarId.getUserName)}"
  let prog ← shareCommonInc (val.betaRev info.prog.getAppRevArgs)
  return some (← replaceProgDefEq goal info prog)

/-- Strategy 11d: reduce a projection head in the program. -/
private def wpHeadReduce? (goal : MVarId) (info : WPApp) :
    VCGenM (Option MVarId) := do
  let f := info.prog.getAppFn
  unless f matches .proj .. do return none
  let some f' ← withReducibleAndInstances (reduceProj? f) | return none
  let f' ← shareCommon (← liftMetaM <| unfoldReducible f')
  let prog ← betaRevS f' info.prog.getAppRevArgs
  return some (← replaceProgDefEq goal info prog)

/-- Stop or raise on a program with no applicable spec. With `errorOnMissingSpec` (default), raise a
hard error naming the program and the candidate specs; otherwise stop and emit the goal as a VC. -/
private def stopOrErrorOnMissingSpec (prog monad : Expr) (thms : Array SpecTheorem) :
    VCGenM SolveResult := do
  unless (← read).errorOnMissingSpec do
    return .stop (.noSpecFound prog monad thms)
  if thms.isEmpty then
    throwError "No spec found for program {prog}."
  else
    throwError "No spec applicable to program {prog} in monad {monad}. \
      Candidates were {thms.map (·.proof)}."

/-- True iff the program matches the `until` pattern, in which case VC generation stops at this
goal. -/
private def matchesUntilPattern (prog : Expr) : VCGenM Bool := do
  let some pat := (← read).untilPat? | return false
  if (← pat.match? prog).isSome then
    trace[Elab.Tactic.Do.vcgen] "`until` pattern matched program {prog}; stopping"
    return true
  return false

/-- `let`-declaration analogue of `withLocalDeclsDND`: brings each `name : type := value` into scope
(types and values mutually independent), then runs `k` with the new free variables. -/
@[inline]
private def withLetDeclsDND (declInfos : Array (Name × Expr × Expr))
    (k : Array Expr → VCGenM Expr) : VCGenM Expr :=
  loop #[]
where
  loop (acc : Array Expr) : VCGenM Expr := do
    if h : acc.size < declInfos.size then
      let (name, type, value) := declInfos[acc.size]
      Meta.withLetDecl name type value fun fv => loop (acc.push fv)
    else
      k acc
  termination_by declInfos.size - acc.size

/-- Elaborate a matched `frames` alternative's frame term at the resource type `resourceTy` of the
applicable frame operator, with each named pattern variable bound to the subterm the pattern matched.
The bindings are introduced as `let`-declarations carrying the matched value, so the resulting frame
records the pattern-variable assignments and the user sees them in the side goals. -/
private def elabFrame (resourceTy : Expr) (entry : FrameEntry) (res : Sym.MatchUnifyResult) :
    VCGenM Expr := do
  let mut decls : Array (Name × Expr × Expr) := #[]
  for nm? in entry.varNames, arg in res.args do
    if let some nm := nm? then
      decls := decls.push (nm, ← Meta.inferType arg, arg)
  Meta.withDefault <| withLetDeclsDND decls fun fvs => do
    let frameExpr ← Lean.Elab.Term.TermElabM.run' do
      let e ← Lean.Elab.Term.elabTermEnsuringType entry.frameStx (some resourceTy)
      Lean.Elab.Term.synthesizeSyntheticMVarsNoPostponing
      mkLetFVars fvs e
    instantiateMVarsS frameExpr

/-- Find an unretired `frames` alternative matching the program (earliest source order wins),
elaborate its frame at the resource type of `fp`'s operator, and retire it so it applies at most
once. -/
public def matchFrame? (fp : FrameProc) (info : WPApp) : VCGenM (Option Expr) := do
  let db := (← get).frameDB
  if db.entries.isEmpty then return none
  let mut best : Option (FrameEntry × Sym.MatchUnifyResult) := none
  for srcIdx in Sym.getMatch (← getMCtx) db.tree info.prog do
    let entry := db.entries[srcIdx]!
    if entry.retired then continue
    if let some res ← entry.pat.match? info.prog then
      match best with
      | none => best := some (entry, res)
      | some (b, _) => if entry.srcIdx < b.srcIdx then best := some (entry, res)
  let some (entry, res) := best | return none
  modify fun s =>
    let entries := s.frameDB.entries.set! entry.srcIdx { entry with retired := true }
    { s with frameDB := { s.frameDB with entries } }
  let frame ← elabFrame (← fp.mkResourceTy info) entry res
  trace[Elab.Tactic.Do.vcgen] "`frames` matched {info.prog}; frame:{indentExpr frame}"
  return some frame

/-- Apply `specRule` to a fresh target `?fp ⊑ wp prog ?Q E ?s⃗`.
Return the completed `FrameGoal` to pass to the frameproc. -/
private def applySpecToFootprint (info : WPApp) (specRule : Sym.BackwardRule)
    (le W : Expr) (excessStates : Array Expr) (frame : MVarId)
    (splitLatticeOp? : MVarId → Grind.GrindM (Option (List MVarId))) :
    Grind.GrindM (Option (FrameGoal × List MVarId)) := do
  let fp ← mkFreshExprMVar le.appFn!.appArg!
  let rhs ← mkAppNS W excessStates
  let target ← mkFreshExprSyntheticOpaqueMVar (← mkAppNS le #[fp, rhs])
  let .goals sgs ← specRule.apply target.mvarId! | return none
  let some preVC ← sgs.findM? fun g => return (← g.getType).isAppOf ``Lean.Order.PartialOrder.rel
    | throwError "frame: spec rule left no precondition VC for{indentExpr info.prog}"
  let some framedApp := isWPApp? rhs
    | throwError "frame: the weakest footprint is not a `wp` application for{indentExpr info.prog}"
  let goal : FrameGoal :=
    { frame, footprint := fp.mvarId!, framedApp, specPre := (← preVC.getType).appArg!, preVC,
      specProof := target, splitLatticeOp? }
  return some (goal, sgs)

/-- Apply the frame rule to a copy of `goal`, and read the weakest footprint `W` off its split VC
`pre ⊑ (op ?F W) s⃗`. The copy keeps candidate fall-through possible: committing to the frame rule
has no undo, so a spec that turns out not to apply leaves the copy orphaned and the goal untouched. -/
private def commitFrameRule (goal : MVarId) (info : WPApp) (fp : FrameProc) :
    VCGenM (Expr × FrameBackwardRule × Array MVarId × Expr) := do
  let frule ← mkFrameBackwardRuleCached fp info
  let copy ← mkFreshExprSyntheticOpaqueMVar (← goal.getType)
  let .goals goals ← frule.rule.applyChecked copy.mvarId! m!"frame rule for{indentExpr info.prog}"
    | throwError "frame: failed to apply rule for{indentExpr info.prog}"
  let goals := goals.toArray
  let vcType ← goals[frule.splitVCIdx]!.getType
  let_expr Lean.Order.PartialOrder.rel _ _ _ rhs := vcType
    | throwError "frame: split VC is not an entailment{indentExpr vcType}"
  return (copy, frule, goals, (rhs.stripArgsN info.excessArgs.size).appArg!)

/-- `splitLatticeOp?` as a `GrindM` callback for `FrameGoal`, closed over the rule cache. -/
private def splitLatticeOpCallback : VCGenM (MVarId → Grind.GrindM (Option (List MVarId))) :=
  liftWith (m := Grind.GrindM) fun run => pure fun m => run do
    let ty ← m.getType
    let_expr Lean.Order.PartialOrder.rel _ _ _ rhs := ty | return none
    splitLatticeOp? m rhs

/--
Apply the selected `@[spec]` theorem `thm` to a spec-ready program `info.prog`. `none` when no
backward rule fits the goal's monad, or when the rule does not apply.

A spec with a conjunctive precondition applies directly. Otherwise the frame procedure `fp` runs,
with `providedFrame?` carrying the frame a `frames` clause pinned (both selected once per goal in
`applySpecs`). On `decline` the spec applies directly as well. On `commit` the solver applies the
frame rule to a copy of the goal, applies the spec at the weakest footprint, and runs the commit
continuation; see `FrameProc.lean`. When the spec does not apply to the footprint, the copy is
dropped and the candidate falls through.
-/
private def applySpec (scope : Scope) (goal : MVarId) (info : WPApp) (thm : SpecTheorem)
    (fp : FrameProc) (providedFrame? : Option Expr) : VCGenM (Option SolveResult) := do
  let some specRule ←
    try
      mkBackwardRuleFromSpecCached thm info |>.run
    catch ex =>
      throwError "Failed to construct rule {thm.proof} for {indentExpr info.prog}\n\
        error: {ex.toMessageData}\n\
        target:{indentExpr (← goal.getType)}\n\
        Pred:{indentExpr info.Pred}\n\
        excessArgs: {info.excessArgs}"
    | return none
  unless thm.conjunctivePre do
    let target ← goal.getType
    let inferInfo : FrameInferenceInfo :=
      { pre := target.appFn!.appArg!, le := target.stripArgsN 2
        unframedApp := info, providedFrame?, spec? := thm.global?,
        mkOpApp := do shareCommon (← fp.mkOpAppM info) }
    match ← fp.proc inferInfo with
    | .decline => pure ()
    | .commit excessStates k =>
      unless excessStates.size == info.excessArgs.size do
        throwError "frameproc: the spec must run at {info.excessArgs.size} state arguments \
          for now, got {excessStates.size}"
      let (copy, frule, goals, W) ← commitFrameRule goal info fp
      let some (fgoal, sgs) ←
          applySpecToFootprint info specRule inferInfo.le W excessStates goals[frule.frameIdx]!
            (← splitLatticeOpCallback)
        | return none
      let split ← k fgoal
      trace[Elab.Tactic.Do.vcgen] "`@[frameproc]` framed {info.prog}"
      goals[frule.splitVCIdx]!.assign split.splitVCProof
      goal.assign copy
      return some (.goals scope (goals.toList ++ fgoal.preVC :: sgs ++ split.subgoals))
  trace[Elab.Tactic.Do.vcgen] "Applying spec {thm.proof} for {info.prog}. Excess args: {info.excessArgs}"
  let .goals goals ← specRule.applyChecked goal m!"spec rule for{indentExpr info.prog}"
    | return none
  return some (.goals scope goals)

/--
Handle a spec-ready program `info.prog`: apply the highest-priority `@[spec]` theorem whose backward
rule applies to the goal.

A candidate is passed over when no rule fits the goal's monad or when the rule does not apply, so a
spec guarded by an instance the call site does not provide gives way to a less general one, as does a
spurious candidate of the over-approximating discrimination tree.
-/
private def applySpecs (scope : Scope) (goal : MVarId) (info : WPApp) :
    VCGenM SolveResult := goal.withContext do
  let candidates ← SpecTheorems.findSpecs scope.specs info.prog
  let procs := (← read).frameProcs.byProg
  let fp := info.M.getAppFn.constName?.bind (procs[·]?) |>.getD meetFrameProc
  let providedFrame? ←
    if candidates.isEmpty then pure none else matchFrame? fp info
  for thm in candidates do
    if let some res ← applySpec scope goal info thm fp providedFrame? then
      return res
    trace[Elab.Tactic.Do.vcgen] "Failed to apply spec {thm.proof} for {info.prog}"
  stopOrErrorOnMissingSpec info.prog info.M candidates

/--
The main VC generation step. Operates on a plain `MVarId` with no knowledge of grind.
Returns `.goals subgoals` when the goal was decomposed, or a classification result
(`.noEntailment`, `.noProgramOrLatticeFoundInTarget`, etc.) when no further decomposition is
possible.

The function performs the following steps in order:

1. **Forall introduction**: If the target is a `∀`, simp it and introduce binders.
2. **Target-let handling**: zeta-substitute duplicable top-level lets, otherwise introduce them.
3. **Triple unfolding**: If the target is `⦃P⦄ x ⦃Q; E⦄`, unfold into `P ⊑ wp x Q E`.
4. **Syntactic rfl**: close `pre ⊑ rhs` by `PartialOrder.rel_refl` when both sides unify.
5. **Embedded pure precondition introduction**: lift a `⌜φ⌝` precondition into the local
   context, before state-argument introduction would apply it to the introduced arguments.
6. **State-argument introduction**: If the lattice carrier is a function type
   `σ₁ → ... → σₙ → Base`, introduce all excess state arguments.
7. **Bare pure precondition introduction**: on the `Prop` lattice, replace a `True`
   precondition by `⊤` and lift any other precondition into the local context.
8. **Component projection reduction**: reduce a `Prod.fst` RHS to the projected component.
9. **Lattice decomposition**: decompose `⊓`, `⇨`, `⌜p⌝` and `⊤` RHS connectives.
10. **Lifted-hypothesis discharge**: close a residual `pre ⊑ ⌜φ⌝` entailment against the most
    recently lifted precondition `h : φ` in the local context, cached in `Scope.lastLiftedPre?`.
11. **WP decomposition**: when the RHS is `wp e post epost s₁ ... sₙ`, in order:
    hoist/zeta program-head lets, split `ite`/`dite`/match, zeta-unfold fvar program heads,
    reduce projection heads, and finally apply a registered `@[spec]` theorem.
-/
public def solve (scope : Scope) (goal : MVarId) : VCGenM SolveResult := goal.withContext do
  if ← outOfFuel then return .stop .outOfFuel
  let target ← goal.getType
  trace[Elab.Tactic.Do.vcgen] "🎯 Target: {target}"

  -- Phase 1: simplify `target` until it is of the form `pre ⊑ rhs`.
  if let some g ← consumeMData? goal target then return .goals scope [g]
  if let some g ← consumeBinderNameHint? goal target then return .goals scope [g]
  if let some gs ← forallIntro? goal target then return .goals scope gs
  if let some g ← targetLetIntro? goal target then return .goals scope [g]
  if let some g ← tripleUnfold? goal target then return .goals scope [g]
  if let some g ← bareWPToLe? goal target then return .goals scope [g]
  if let some gs ← liftedHypBare? scope goal target then return .goals scope gs
  if let some g ← instantiateGoal? goal target then return .goals scope [g]

  let_expr PartialOrder.rel α inst pre rhs := target
    | return .stop (.noEntailment target)

  -- Phase 2: close reflexive goals, then drive `pre` toward `⊤`, lifting any pure content so a
  -- later spec application sees a `⊤` precondition.
  if let some gs ← rfl? goal then return .goals scope gs
  if let some (scope, gs) ← normalizePre? scope goal α pre target then return .goals scope gs

  -- Collect new local specs before any strategy that may emit multiple subgoals
  -- (`wpMatch?`, `splitLatticeOp?`) or apply a registered spec (`applySpec`).
  let scope ← scope.collectLocalSpecs goal

  -- Phase 3: shape the `rhs` (reduce a component projection, decompose a lattice connective or a
  -- forall, then discharge a residual entailment against the lifted hypothesis).
  if let some g ← headReduceFstRhs? goal target α inst pre rhs then return .goals scope [g]
  if let some gs ← splitLatticeOp? goal rhs then return .goals scope gs
  if let some gs ← splitForallLe? goal rhs then return .goals scope gs
  if let some gs ← liftedHyp? scope goal α pre rhs then return .goals scope gs

  -- Phase 4: wp decomposition. The program-shape steps below all consume one unit of fuel
  -- (the `stepLimit` config option) when they make progress.
  if let some info := isWPApp? rhs then
    trace[Elab.Tactic.Do.vcgen] "📜 Program: {info.prog}"
    -- Stop if the program matches the `until` pattern.
    if ← matchesUntilPattern info.prog then
      return .stop (.untilPatternMatched info.M)
    if let some g ← wpConsumeMData? goal info then
      return .goals scope [g]
    if let some g ← wpLet? goal info then
      burnOne
      return .goals scope [g]
    if let some gs ← wpSimpStateArgs? goal info then
      return .goals scope gs
    if let some gs ← wpMatch? goal info then
      burnOne
      return .goals scope gs
    if let some g ← wpFVarZeta? goal info then
      burnOne
      return .goals scope [g]
    if let some g ← wpHeadReduce? goal info then
      burnOne
      return .goals scope [g]
    let f := info.prog.getAppFn
    if f.isConst || f.isFVar then
      burnOne
      return ← applySpecs scope goal info
    throwError "Failed to decompose weakest precondition for {info.prog}. This should not happen."

  return .stop (.noProgress pre rhs)


end Lean.Elab.Tactic.VCGen
