// Lean compiler output
// Module: Lean.Server.Test.Refs
// Imports: import Init.Prelude
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
LEAN_EXPORT lean_object* l_Lean_Server_Test_Refs_test7;
LEAN_EXPORT lean_object* l_Lean_Server_Test_Refs_test8;
LEAN_EXPORT lean_object* l_Lean_Server_Test_Refs_test9;
LEAN_EXPORT lean_object* l_Lean_Server_Test_Refs_test10;
static lean_object* _init_l_Lean_Server_Test_Refs_test7(void){
_start:
{
lean_object* v___x_1_; 
v___x_1_ = lean_box(0);
return v___x_1_;
}
}
static lean_object* _init_l_Lean_Server_Test_Refs_test8(void){
_start:
{
lean_object* v___x_2_; 
v___x_2_ = lean_box(0);
return v___x_2_;
}
}
static lean_object* _init_l_Lean_Server_Test_Refs_test9(void){
_start:
{
lean_object* v___x_3_; 
v___x_3_ = lean_box(0);
return v___x_3_;
}
}
static lean_object* _init_l_Lean_Server_Test_Refs_test10(void){
_start:
{
lean_object* v___x_4_; 
v___x_4_ = lean_box(0);
return v___x_4_;
}
}
lean_object* runtime_initialize_Init_Prelude(uint8_t builtin);
void lean_initialize_runtime_module();
static bool _G_runtime_initialized = false;
LEAN_EXPORT lean_object* runtime_initialize_Lean_Server_Test_Refs(uint8_t builtin) {
lean_object * res;
if (_G_runtime_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_runtime_initialized = true;
lean_initialize_runtime_module();
res = runtime_initialize_Init_Prelude(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
l_Lean_Server_Test_Refs_test7 = _init_l_Lean_Server_Test_Refs_test7();
lean_mark_persistent(l_Lean_Server_Test_Refs_test7);
l_Lean_Server_Test_Refs_test8 = _init_l_Lean_Server_Test_Refs_test8();
lean_mark_persistent(l_Lean_Server_Test_Refs_test8);
l_Lean_Server_Test_Refs_test9 = _init_l_Lean_Server_Test_Refs_test9();
lean_mark_persistent(l_Lean_Server_Test_Refs_test9);
l_Lean_Server_Test_Refs_test10 = _init_l_Lean_Server_Test_Refs_test10();
lean_mark_persistent(l_Lean_Server_Test_Refs_test10);
return lean_io_result_mk_ok(lean_box(0));
}
static bool _G_meta_initialized = false;
LEAN_EXPORT lean_object* meta_initialize_Lean_Server_Test_Refs(uint8_t builtin) {
lean_object * res;
if (_G_meta_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_meta_initialized = true;
return lean_io_result_mk_ok(lean_box(0));
}
lean_object* initialize_Init_Prelude(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_Lean_Server_Test_Refs(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init_Prelude(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = runtime_initialize_Lean_Server_Test_Refs(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = meta_initialize_Lean_Server_Test_Refs(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return initialize_Lean_Server_Test_Refs(builtin);
}
#ifdef __cplusplus
}
#endif
