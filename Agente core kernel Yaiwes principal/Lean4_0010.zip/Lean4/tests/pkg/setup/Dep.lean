def hello := "hello"
