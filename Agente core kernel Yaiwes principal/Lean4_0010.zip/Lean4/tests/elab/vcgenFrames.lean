/-
Copyright (c) 2026 Lean FRO LLC. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Sebastian Graf
-/
import Lean
import Std.WP
import Std.Tactic.Do

set_option experimental.vcgen true
set_option grind.warning false

/-!
# Tests for the `vcgen … frames` clause

A `frames` alternative attaches a state assertion `F` to a matched program whose registered spec is
*lossy* (drops a fact about state it does not touch). `vcgen` applies the framed spec, emits the
frame precondition and the `Frames` side goal, and recovers `F` in the postcondition.

The `Frames` side goal is established by `frames_mkFreshNat`, which reduces it through
`WP.Frames.of_conjunctive` to a preservation triple `F ⊑ wp x (fun _ => F)` (using `WPConjunctive`
for the monad); `mkFreshNat` writes only `fst`, so it preserves any `snd`-fact.

The `recovers_*` proofs run at the `Id` base monad and register the `_Id` specializations of these
lemmas with `grind`. With the monad ground, `grind` derives a usable E-matching pattern, so the
discharge step `with finish` closes every VC, including the `Frames` side goal.
-/

open Lean Order Meta Elab Tactic Sym Std WP

abbrev AppState := Nat × Nat

@[irreducible] def mkFreshNat [Monad m] [MonadStateOf AppState m] : m Nat := do
  let n ← Prod.fst <$> get
  modify (fun s => (s.1 + 1, s.2))
  pure n

def mkFreshPair [Monad m] [MonadStateOf AppState m] : m (Nat × Nat) := do
  let a ← mkFreshNat
  let b ← mkFreshNat
  pure (a, b)

/-- Lossy spec: says nothing about `s.2`. -/
@[spec]
theorem mkFreshNat_spec_lossy [Monad m] [Assertion Pred] [Assertion EPred] [WPMonad m Pred EPred] :
    ⦃ fun s => ⌜s.1 = n⌝ ⦄ (mkFreshNat : StateT AppState m Nat)
    ⦃ fun r s => ⌜r = n ∧ s.1 = n + 1⌝ ⦄ := by
  unfold mkFreshNat
  vcgen <;> simp_all

/-- `mkFreshNat` frames any `P` outside its `fst` footprint. The frame condition reduces through
`of_conjunctive` to the preservation triple, which holds since `mkFreshNat` overwrites only `fst`. -/
theorem frames_mkFreshNat [Monad m] [Assertion Pred] [Assertion EPred]
    [WPMonad m Pred EPred] [∀ β (y : m β), WPConjunctive y] {P : AppState → Pred}
    (h : ∀ s a, P { s with fst := a } = P s) :
    WP.Frames (· ⊓ ·) (mkFreshNat : StateT AppState m Nat) P := by
  refine .of_conjunctive (fun E => ?_)
  vcgen [mkFreshNat] with finish

/-- `Id`-specialized `frames_mkFreshNat`. With the base monad ground, `grind` can derive a
usable pattern, so registering it lets `finish` discharge the preservation VC. -/
@[grind .]
theorem frames_mkFreshNat_Id {P : AppState → Prop}
    (h : ∀ s a, P { s with fst := a } = P s) :
    WP.Frames (· ⊓ ·) (mkFreshNat : StateT AppState Id Nat) P :=
  frames_mkFreshNat h

/-- The frame recovers `s.2`, which the lossy spec dropped. The `fail_if_success` confirms the frame
is doing the work: without it, `grind` cannot close the lost `s.2 = 7`. -/
theorem recovers_snd :
    ⦃ fun s => ⌜s.1 = 0 ∧ s.2 = 7⌝ ⦄ (mkFreshNat : StateT AppState Id Nat)
    ⦃ fun r s => ⌜r = 0 ∧ s.2 = 7⌝ ⦄ := by
  fail_if_success (vcgen <;> grind)
  vcgen frames | mkFreshNat => fun s => ⌜s.2 = 7⌝ with finish

/-- Two calls, two alternatives: consume-once frames each `mkFreshNat` exactly once. -/
theorem recovers_snd_pair :
    ⦃ fun s => ⌜s.1 = 0 ∧ s.2 = 7⌝ ⦄ (mkFreshPair : StateT AppState Id (Nat × Nat))
    ⦃ fun p s => ⌜p.1 = 0 ∧ s.2 = 7⌝ ⦄ := by
  vcgen [mkFreshPair] frames
  | mkFreshNat => fun s => ⌜s.2 = 7⌝
  | mkFreshNat => fun s => ⌜s.2 = 7⌝
  with finish

/-! ## Complementary footprint: an operation that writes `snd` -/

@[irreducible] def mkFreshSnd [Monad m] [MonadStateOf AppState m] : m Nat := do
  let n ← Prod.snd <$> get
  modify (fun s => (s.1, s.2 + 1))
  pure n

/-- Lossy spec: says nothing about `s.1`. -/
@[spec]
theorem mkFreshSnd_spec_lossy [Monad m] [Assertion Pred] [Assertion EPred] [WPMonad m Pred EPred] :
    ⦃ fun s => ⌜s.2 = o⌝ ⦄ (mkFreshSnd : StateT AppState m Nat)
    ⦃ fun r s => ⌜r = o ∧ s.2 = o + 1⌝ ⦄ := by
  unfold mkFreshSnd
  vcgen <;> simp_all

/-- `mkFreshSnd` frames any `P` outside its `snd` footprint. -/
theorem frames_mkFreshSnd [Monad m] [Assertion Pred] [Assertion EPred]
    [WPMonad m Pred EPred] [∀ β (y : m β), WPConjunctive y] {P : AppState → Pred}
    (h : ∀ s a, P { s with snd := a } = P s) :
    WP.Frames (· ⊓ ·) (mkFreshSnd : StateT AppState m Nat) P := by
  refine .of_conjunctive (fun E => ?_)
  vcgen [mkFreshSnd] with finish

/-- `Id`-specialized `frames_mkFreshSnd`, registered so `finish` discharges the preservation VC. -/
@[grind .]
theorem frames_mkFreshSnd_Id {P : AppState → Prop}
    (h : ∀ s a, P { s with snd := a } = P s) :
    WP.Frames (· ⊓ ·) (mkFreshSnd : StateT AppState Id Nat) P :=
  frames_mkFreshSnd h

/-- Mirror of `recovers_snd`: frame the complementary (`fst`) footprint. -/
theorem recovers_fst :
    ⦃ fun s => ⌜s.1 = 5 ∧ s.2 = 0⌝ ⦄ (mkFreshSnd : StateT AppState Id Nat)
    ⦃ fun r s => ⌜r = 0 ∧ s.1 = 5⌝ ⦄ := by
  fail_if_success (vcgen <;> grind)
  vcgen frames | mkFreshSnd => fun s => ⌜s.1 = 5⌝ with finish

/-! ## Two distinct framed operations in one program -/

def mkFreshMixed [Monad m] [MonadStateOf AppState m] : m (Nat × Nat) := do
  let a ← mkFreshNat
  let b ← mkFreshSnd
  pure (a, b)

/-- `mkFreshNat` (writes `fst`) and `mkFreshSnd` (writes `snd`) are framed by different alternatives:
each recovers the component the other op's lossy spec would drop. -/
theorem recovers_both :
    ⦃ fun s => ⌜s.1 = 0 ∧ s.2 = 7⌝ ⦄ (mkFreshMixed : StateT AppState Id (Nat × Nat))
    ⦃ fun p s => ⌜s.1 = 1 ∧ s.2 = 8⌝ ⦄ := by
  vcgen [mkFreshMixed] frames
  | mkFreshNat => fun s => ⌜s.2 = 7⌝
  | mkFreshSnd => fun s => ⌜s.1 = 1⌝
  with finish

/-! ## Named pattern variable referenced by the frame -/

/-- `addFst k` writes `fst`, leaving `snd` untouched, and takes an explicit argument. -/
@[irreducible] def addFst (k : Nat) [Monad m] [MonadStateOf AppState m] : m Nat := do
  let n ← Prod.fst <$> get
  modify (fun s => (s.1 + k, s.2))
  pure n

/-- Lossy spec: says nothing about `s.2`. -/
@[spec]
theorem addFst_spec_lossy [Monad m] [Assertion Pred] [Assertion EPred] [WPMonad m Pred EPred] :
    ⦃ fun s => ⌜s.1 = n⌝ ⦄ (addFst k : StateT AppState m Nat)
    ⦃ fun r s => ⌜r = n ∧ s.1 = n + k⌝ ⦄ := by
  unfold addFst
  vcgen <;> simp_all

/-- `addFst k` frames any `P` outside its `fst` footprint. -/
theorem frames_addFst [Monad m] [Assertion Pred] [Assertion EPred]
    [WPMonad m Pred EPred] [∀ β (y : m β), WPConjunctive y] {P : AppState → Pred} {k : Nat}
    (h : ∀ s a, P { s with fst := a } = P s) :
    WP.Frames (· ⊓ ·) (addFst k : StateT AppState m Nat) P := by
  refine .of_conjunctive (fun E => ?_)
  vcgen [addFst] with finish

/-- `Id`-specialized `frames_addFst`, registered so `finish` discharges the preservation VC. -/
@[grind .]
theorem frames_addFst_Id {P : AppState → Prop} {k : Nat}
    (h : ∀ s a, P { s with fst := a } = P s) :
    WP.Frames (· ⊓ ·) (addFst k : StateT AppState Id Nat) P :=
  frames_addFst h

/-- The frame `fun s => ⌜s.2 = j⌝` references the matched argument `j`, so `elabFrame` introduces
`let j := k` and the assignment is recovered in the postcondition. -/
theorem recovers_with_arg :
    ⦃ fun s => ⌜s.1 = 0 ∧ s.2 = k⌝ ⦄ (addFst k : StateT AppState Id Nat)
    ⦃ fun r s => ⌜r = 0 ∧ s.2 = k⌝ ⦄ := by
  fail_if_success (vcgen <;> grind)
  vcgen frames | addFst j => fun s => ⌜s.2 = j⌝ with finish

/-! ## Polymorphic state type at a fixed universe -/

/-- Writes the `Nat` component of a `σ × Nat` state, for an abstract `σ : Type`. -/
@[irreducible] def bumpSnd {σ : Type} [Monad m] : StateT (σ × Nat) m Nat := do
  let n ← Prod.snd <$> get
  modify (fun s => (s.1, s.2 + 1))
  pure n

/-- Lossy spec: says nothing about `s.1`. -/
@[spec]
theorem bumpSnd_spec_lossy {σ : Type} [Monad m] [Assertion Pred] [Assertion EPred]
    [WPMonad m Pred EPred] :
    ⦃ fun s => ⌜s.2 = o⌝ ⦄ (bumpSnd : StateT (σ × Nat) m Nat)
    ⦃ fun r s => ⌜r = o ∧ s.2 = o + 1⌝ ⦄ := by
  unfold bumpSnd
  vcgen <;> simp_all

/-- `bumpSnd` frames any `P` outside its `snd` footprint, over an abstract state `σ`. -/
theorem frames_bumpSnd {σ : Type} [Monad m] [Assertion Pred] [Assertion EPred]
    [WPMonad m Pred EPred] [∀ β (y : m β), WPConjunctive y] {P : σ × Nat → Pred}
    (h : ∀ s a, P { s with snd := a } = P s) :
    WP.Frames (· ⊓ ·) (bumpSnd : StateT (σ × Nat) m Nat) P := by
  refine .of_conjunctive (fun E => ?_)
  vcgen [bumpSnd] with finish

/-- `Id`-specialized `frames_bumpSnd` over an abstract state `σ`, registered so `finish`
discharges the preservation VC. -/
@[grind .]
theorem frames_bumpSnd_Id {σ : Type} {P : σ × Nat → Prop}
    (h : ∀ s a, P { s with snd := a } = P s) :
    WP.Frames (· ⊓ ·) (bumpSnd : StateT (σ × Nat) Id Nat) P :=
  frames_bumpSnd h

/-- The frame recovers `s.1 = a` for an abstract `a : σ`, which the lossy spec dropped. -/
theorem recovers_fst_poly {σ : Type} {a : σ} :
    ⦃ fun s => ⌜s.1 = a ∧ s.2 = 0⌝ ⦄ (bumpSnd : StateT (σ × Nat) Id Nat)
    ⦃ fun r s => ⌜r = 0 ∧ s.1 = a⌝ ⦄ := by
  fail_if_success (vcgen <;> grind)
  vcgen frames | bumpSnd => fun s => ⌜s.1 = a⌝ with finish

/-! ## Unmatched frame alternatives are rejected -/

-- A `frames` alternative whose program pattern matches no program in the goal is an error
-- (`mkFreshSnd` does not occur in the program).
/--
error: `frames` alternative matched no program in the goal
-/
#guard_msgs in
example [Monad m] [Assertion Pred] [Assertion EPred] [WPMonad m Pred EPred]
    [∀ β (y : m β), WPConjunctive y] [∀ a : Pred, PreservesSup (meet a)] :
    ⦃ fun s => ⌜s.1 = 0 ∧ s.2 = 7⌝ ⦄ (mkFreshNat : StateT AppState m Nat)
    ⦃ fun r s => ⌜r = 0 ∧ s.2 = 7⌝ ⦄ := by
  vcgen frames | mkFreshSnd => fun s => ⌜s.2 = 7⌝

/-! ## The lemmas apply at the `StateM` alias -/

example : ⦃ fun s => ⌜s.1 = 0 ∧ s.2 = 7⌝ ⦄ (mkFreshNat : StateM AppState Nat)
    ⦃ fun r s => ⌜r = 0 ∧ s.2 = 7⌝ ⦄ := recovers_snd

/-! ## Assertion universe independent of the value universe

`Pred` and `EPred` are quantified at their own universes `w`/`w'`, independent of the value type
`Nat : Type 0`. `Triple`'s four independent universes admit such a spec, and `vcgen` reasons over
the abstract assertion universe. -/

/-- Only `get` and state-introduction, exercising `Spec.get_StateT` at an abstract assertion
universe. -/
example {m : Type → Type v} {Pred : Type w} {EPred : Type w'} [Monad m] [Assertion Pred]
    [Assertion EPred] [WPMonad m Pred EPred] (P : Nat → Pred) :
    ⦃P⦄ (get : StateT Nat m Nat) ⦃fun _ => P⦄ := by
  vcgen

/-- The lossy spec of `mkFreshNat` at an abstract assertion universe: `vcgen` threads
`pure`/`bind`/`map`/`modifyGet`/`get` over `Pred : Type w`. -/
example {m : Type → Type v} {Pred : Type w} {EPred : Type w'} [Monad m] [Assertion Pred]
    [Assertion EPred] [WPMonad m Pred EPred] (n : Nat) :
    ⦃ fun s => ⌜s.1 = n⌝ ⦄ (mkFreshNat : StateT AppState m Nat)
    ⦃ fun r s => ⌜r = n ∧ s.1 = n + 1⌝ ⦄ := by
  unfold mkFreshNat
  vcgen <;> simp_all

/-! ## A pinned frame survives a passed-over spec candidate

`mkFreshNat_spec_guarded` is the highest-priority candidate, but its `Never γ` instance is never
synthesizable, so its rule fails to apply and the next candidate runs. `selectiveFP` frames only
`mkFreshNat_spec_lossy`, so the `frames` clause must still pin the frame when that next candidate
applies: the clause is matched once per goal, not once per candidate. -/

/-- An unsatisfiable instance guard: a spec rule with a `Never γ` premise never applies. -/
class Never (α : Type) : Prop where
  absurd : False

/-- The lossy spec, guarded by an instance on a `γ` that nothing determines. -/
@[spec high]
theorem mkFreshNat_spec_guarded {γ : Type} [Never γ] [Monad m] [Assertion Pred] [Assertion EPred]
    [WPMonad m Pred EPred] :
    ⦃ fun s => ⌜s.1 = n⌝ ⦄ (mkFreshNat : StateT AppState m Nat)
    ⦃ fun r s => ⌜r = n ∧ s.1 = n + 1⌝ ⦄ :=
  (Never.absurd (α := γ)).elim

open Lean.Elab.Tactic.VCGen

/-- Frames the pinned resource for `mkFreshNat_spec_lossy` and declines every other spec. -/
def selectiveFrameProc : FrameInferenceProc := fun i => do
  let some frame := i.providedFrame? | return .decline
  unless i.spec? == some ``mkFreshNat_spec_lossy do return .decline
  return .ofFrame i frame

/-- The meet frame operator with `selectiveFrameProc` as inference procedure. -/
@[frameproc] def selectiveFP : FrameProc where
  prog := ``StateT
  mkOpAppM := fun info => Lean.Meta.mkAppOptM ``Lean.Order.meet #[info.Pred, none]
  mkResourceTy := fun info => pure info.Pred
  opHead := ``Lean.Order.meet
  proc := selectiveFrameProc

/-- `mkFreshNat_spec_guarded` is passed over; the clause still frames `s.2 = 7` when
`mkFreshNat_spec_lossy` applies. -/
theorem recovers_snd_second_candidate :
    ⦃ fun s => ⌜s.1 = 0 ∧ s.2 = 7⌝ ⦄ (mkFreshNat : StateT AppState Id Nat)
    ⦃ fun r s => ⌜r = 0 ∧ s.2 = 7⌝ ⦄ := by
  vcgen frames | mkFreshNat => fun s => ⌜s.2 = 7⌝ with finish
