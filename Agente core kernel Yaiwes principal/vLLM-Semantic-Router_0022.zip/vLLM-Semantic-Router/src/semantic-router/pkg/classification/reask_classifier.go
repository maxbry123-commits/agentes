package classification

import (
	"context"
	"fmt"
	"strings"

	"github.com/vllm-project/semantic-router/src/semantic-router/pkg/config"
	"github.com/vllm-project/semantic-router/src/semantic-router/pkg/embedding"
)

type ReaskMatch struct {
	RuleName      string
	MinSimilarity float64
	MatchedTurns  int
	LookbackTurns int
}

type ReaskClassifier struct {
	rules     []config.ReaskRule
	modelType string
	provider  embedding.Provider
}

func NewReaskClassifier(rules []config.ReaskRule, modelType string) (*ReaskClassifier, error) {
	return NewReaskClassifierWithProvider(rules, modelType, nil)
}

func NewReaskClassifierWithProvider(rules []config.ReaskRule, modelType string, provider embedding.Provider) (*ReaskClassifier, error) {
	if len(rules) == 0 {
		return nil, fmt.Errorf("reask rules cannot be empty")
	}
	if strings.TrimSpace(modelType) == "" {
		modelType = "qwen3"
	}
	return &ReaskClassifier{
		rules:     append([]config.ReaskRule(nil), rules...),
		modelType: strings.TrimSpace(modelType),
		provider:  provider,
	}, nil
}

func (c *ReaskClassifier) Classify(currentUserTurn string, priorUserTurns []string) ([]ReaskMatch, error) {
	currentUserTurn = strings.TrimSpace(currentUserTurn)
	if currentUserTurn == "" || len(c.rules) == 0 || len(priorUserTurns) == 0 {
		return nil, nil
	}

	currentEmbedding, err := c.embedText(currentUserTurn)
	if err != nil {
		return nil, fmt.Errorf("failed to compute current user turn embedding: %w", err)
	}

	similarities, err := c.computeSimilarities(currentEmbedding, priorUserTurns, minimumReaskThreshold(c.rules))
	if err != nil {
		return nil, err
	}

	matches := make([]ReaskMatch, 0, len(c.rules))
	for _, rawRule := range c.rules {
		rule := rawRule.WithDefaults()
		if len(similarities) < rule.LookbackTurns {
			continue
		}

		requiredMin, streak := evaluateReaskStreak(similarities, float64(rule.Threshold), rule.LookbackTurns)
		if streak < rule.LookbackTurns {
			continue
		}

		matches = append(matches, ReaskMatch{
			RuleName:      rule.Name,
			MinSimilarity: requiredMin,
			MatchedTurns:  streak,
			LookbackTurns: rule.LookbackTurns,
		})
	}

	return retainMaxLookbackReaskMatches(matches), nil
}

func (c *ReaskClassifier) computeSimilarities(currentEmbedding []float32, priorUserTurns []string, minimumThreshold float64) ([]float64, error) {
	cache := make(map[string][]float32, len(priorUserTurns))
	similarities := make([]float64, 0, len(priorUserTurns))

	for index := len(priorUserTurns) - 1; index >= 0; index-- {
		priorTurn := strings.TrimSpace(priorUserTurns[index])
		if priorTurn == "" {
			continue
		}

		priorEmbedding, ok := cache[priorTurn]
		if !ok {
			embedding, err := c.embedText(priorTurn)
			if err != nil {
				return nil, fmt.Errorf("failed to compute prior user turn embedding: %w", err)
			}
			priorEmbedding = embedding
			cache[priorTurn] = priorEmbedding
		}

		similarity := float64(cosineSimilarity(currentEmbedding, priorEmbedding))
		similarities = append(similarities, similarity)
		if similarity < minimumThreshold {
			break
		}
	}

	return similarities, nil
}

func minimumReaskThreshold(rules []config.ReaskRule) float64 {
	minimumThreshold := float64(rules[0].WithDefaults().Threshold)
	for _, rawRule := range rules[1:] {
		threshold := float64(rawRule.WithDefaults().Threshold)
		if threshold < minimumThreshold {
			minimumThreshold = threshold
		}
	}
	return minimumThreshold
}

func (c *ReaskClassifier) embedText(text string) ([]float32, error) {
	if c.provider != nil {
		return c.provider.Embed(context.Background(), text)
	}
	output, err := getEmbeddingWithModelType(text, c.modelType, 0)
	if err != nil {
		return nil, err
	}
	return output.Embedding, nil
}

func evaluateReaskStreak(similarities []float64, threshold float64, lookbackTurns int) (float64, int) {
	requiredMin := 1.0
	streak := 0

	for index, similarity := range similarities {
		if similarity < threshold {
			break
		}
		streak++
		if index < lookbackTurns && similarity < requiredMin {
			requiredMin = similarity
		}
	}

	return requiredMin, streak
}

func retainMaxLookbackReaskMatches(matches []ReaskMatch) []ReaskMatch {
	if len(matches) <= 1 {
		return matches
	}

	maxLookback := 0
	for _, match := range matches {
		if match.LookbackTurns > maxLookback {
			maxLookback = match.LookbackTurns
		}
	}

	filtered := make([]ReaskMatch, 0, len(matches))
	for _, match := range matches {
		if match.LookbackTurns == maxLookback {
			filtered = append(filtered, match)
		}
	}
	return filtered
}
