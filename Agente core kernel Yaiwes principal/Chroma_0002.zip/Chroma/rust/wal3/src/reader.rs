// NOTE(rescrv):  All caches align to storage.  For now, implement without caching.  Caching
// should/could literally be a layer over storage, so add it later once correctness without caching
// is ensured by adequate testing.

use std::sync::Arc;

use setsum::Setsum;

use chroma_storage::Storage;

use crate::interfaces::s3;
use crate::interfaces::{
    FragmentConsumer, FragmentManagerFactory, FragmentPointer, ManifestConsumer,
    ManifestManagerFactory,
};
use crate::{
    CursorWitness, Error, Fragment, FragmentSeqNo, LogPosition, LogReaderOptions, Manifest,
    ManifestAndWitness, ManifestBoundsAndWitness, ScrubError, ScrubSuccess, SnapshotCache,
};

fn ranges_overlap(lhs: (LogPosition, LogPosition), rhs: (LogPosition, LogPosition)) -> bool {
    lhs.0 < rhs.1 && rhs.0 < lhs.1
}

/// Limits allows encoding things like offset, timestamp, and byte size limits for the read.
#[derive(Copy, Clone, Debug, Default, serde::Deserialize, serde::Serialize)]
pub struct Limits {
    pub max_files: Option<u64>,
    pub max_bytes: Option<u64>,
    pub max_records: Option<u64>,
}

impl Limits {
    pub const UNLIMITED: Limits = Limits {
        max_files: None,
        max_bytes: None,
        max_records: None,
    };
}

/// Do a consistent stale read of the manifest.  If the read can be returned without I/O,
/// return Some(Vec<Fragment>).  If the read would require reading from the future or
/// snapshots, return None.  Scan is more appropriate for that.
///
/// 1. Up to, but not including, the offset of the log position.  This makes it a half-open
///    interval.
/// 2. Up to, and including, the number of files to return.
/// 3. Up to, and including, the total number of bytes to return.
pub fn scan_from_manifest(
    manifest: &Manifest,
    from: LogPosition,
    limits: Limits,
) -> Option<Vec<Fragment>> {
    let log_position_range = if let Some(max_records) = limits.max_records {
        if from.offset().saturating_add(max_records) == u64::MAX {
            return None;
        }
        (from, from + max_records)
    } else {
        (from, LogPosition::MAX)
    };
    // If no there is no fragment with a start earlier than the from LogPosition, that means
    // we'd need to load snapshots.  Since this is an in-memory only function, we return "None"
    // to indicate that it's not satisfiable and do no I/O.
    if !manifest
        .fragments
        .iter()
        .any(|f| f.start <= log_position_range.0)
    {
        return None;
    }
    // If no there is no fragment with a limit later-equal than the upper-bound LogPosition, that
    // means we have a stale manifest.  Since this is an in-memory only function, we return
    // "None" to indicate that it's not satisfiable and do no I/O.
    if !manifest
        .fragments
        .iter()
        .any(|f| f.limit >= log_position_range.1)
    {
        return None;
    }
    let mut fragments = manifest
        .fragments
        .iter()
        .filter(|f| ranges_overlap(log_position_range, (f.start, f.limit)))
        .cloned()
        .collect::<Vec<_>>();
    fragments.sort_by_key(|f| f.start.offset());
    let mut covered_until = from;
    for fragment in &fragments {
        if fragment.start > covered_until {
            return None;
        }
        if fragment.limit > covered_until {
            covered_until = fragment.limit;
        }
        if covered_until > log_position_range.1 {
            break;
        }
    }
    if covered_until < log_position_range.1 {
        return None;
    }
    let mut short_read = false;
    Some(post_process_fragments(
        fragments,
        from,
        limits,
        &mut short_read,
    ))
}

/// Post process the fragments such that only records starting at from and not exceeding limits
/// will be processed.  Sets *short_read=true when the limits truncate the log.
pub(crate) fn post_process_fragments(
    mut fragments: Vec<Fragment>,
    from: LogPosition,
    limits: Limits,
    short_read: &mut bool,
) -> Vec<Fragment> {
    fragments.sort_by_key(|f| f.start.offset());
    if let Some(max_files) = limits.max_files {
        if fragments.len() as u64 > max_files {
            *short_read = true;
            fragments.truncate(max_files as usize);
        }
    }
    while fragments.len() > 1
        // NOTE(rescrv):  We take the start of the last fragment, because if there are enough
        // records without it we can pop.
        && fragments[fragments.len() - 1].start - from
            > limits.max_records.unwrap_or(u64::MAX)
    {
        fragments.pop();
        *short_read = true;
    }
    while fragments.len() > 1
        && fragments
            .iter()
            .map(|f| f.num_bytes)
            .fold(0, u64::saturating_add)
            > limits.max_bytes.unwrap_or(u64::MAX)
    {
        fragments.pop();
        *short_read = true;
    }
    fragments
}

/// LogReader is a reader for the log.
pub struct LogReader<
    P: FragmentPointer = (FragmentSeqNo, LogPosition),
    FC: FragmentConsumer = s3::S3FragmentPuller,
    MC: ManifestConsumer<P> = s3::ManifestReader,
> {
    _options: LogReaderOptions,
    fragment_consumer: FC,
    manifest_consumer: MC,
    cache: Option<Arc<dyn SnapshotCache>>,
    _phantom_p: std::marker::PhantomData<P>,
}

impl<P: FragmentPointer, FC: FragmentConsumer, MC: ManifestConsumer<P>> std::fmt::Debug
    for LogReader<P, FC, MC>
{
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("LogReader")
            .field("_options", &self._options)
            .finish_non_exhaustive()
    }
}

impl<P: FragmentPointer, FC: FragmentConsumer, MC: ManifestConsumer<P>> LogReader<P, FC, MC> {
    pub fn new(options: LogReaderOptions, fragment_consumer: FC, manifest_consumer: MC) -> Self {
        let cache = None;
        Self {
            _options: options,
            fragment_consumer,
            manifest_consumer,
            cache,
            _phantom_p: std::marker::PhantomData,
        }
    }

    pub async fn open(
        options: LogReaderOptions,
        fragment_consumer: FC,
        manifest_consumer: MC,
    ) -> Result<Self, Error> {
        let cache = None;
        Ok(Self {
            _options: options,
            fragment_consumer,
            manifest_consumer,
            cache,
            _phantom_p: std::marker::PhantomData,
        })
    }

    pub fn with_cache(&mut self, cache: Arc<dyn SnapshotCache>) {
        self.cache = Some(cache);
    }

    /// Verify that the reader would read the same manifest as the one provided in
    /// manifest_and_witness, but do it in a way that doesn't load the whole manifest.
    pub async fn verify(&self, manifest_and_witness: &ManifestAndWitness) -> Result<bool, Error> {
        self.manifest_consumer
            .manifest_head(&manifest_and_witness.witness)
            .await
    }

    pub async fn manifest(&self) -> Result<Option<Manifest>, Error> {
        Ok(self
            .manifest_consumer
            .manifest_load()
            .await?
            .map(|(m, _)| m))
    }

    pub async fn manifest_and_witness(&self) -> Result<Option<ManifestAndWitness>, Error> {
        match self.manifest_consumer.manifest_load().await {
            Ok(Some((manifest, witness))) => Ok(Some(ManifestAndWitness { manifest, witness })),
            Ok(None) => Ok(None),
            Err(err) => Err(err),
        }
    }

    pub async fn manifest_bounds_and_witness(
        &self,
    ) -> Result<Option<ManifestBoundsAndWitness>, Error> {
        self.manifest_consumer.manifest_bounds_and_witness().await
    }

    pub async fn oldest_timestamp(&self) -> Result<LogPosition, Error> {
        let Some((manifest, _)) = self.manifest_consumer.manifest_load().await? else {
            return Err(Error::UninitializedLog);
        };
        Ok(manifest.oldest_timestamp())
    }

    pub async fn next_write_timestamp(&self) -> Result<LogPosition, Error> {
        let Some((manifest, _)) = self.manifest_consumer.manifest_load().await? else {
            return Err(Error::UninitializedLog);
        };
        Ok(manifest.next_write_timestamp())
    }

    /// Scan up to:
    /// 1. Up to, but not including, the offset of the log position.  This makes it a half-open
    ///    interval.
    /// 2. Up to, and including, the number of files to return.
    /// 3. Up to, and including, the total number of bytes to return.
    pub async fn scan(&self, from: LogPosition, limits: Limits) -> Result<Vec<Fragment>, Error> {
        let Some((manifest, _)) = self.manifest_consumer.manifest_load().await? else {
            return Err(Error::UninitializedLog);
        };
        let mut short_read = false;
        self.scan_with_cache(&manifest, from, limits, &mut short_read)
            .await
    }

    pub async fn scan_partial(
        &self,
        from: LogPosition,
        limits: Limits,
    ) -> Result<Option<Vec<Fragment>>, Error> {
        self.manifest_consumer.scan_partial(from, limits).await
    }

    /// Scan up to:
    /// 1. Up to, but not including, the offset of the log position.  This makes it a half-open
    ///    interval.
    /// 2. Up to, and including, the number of files to return.
    ///
    /// This differs from scan in that it takes a loaded manifest.
    /// This differs from scan_from_manifest because it will load snapshots.
    pub async fn scan_with_cache(
        &self,
        manifest: &Manifest,
        from: LogPosition,
        limits: Limits,
        short_read: &mut bool,
    ) -> Result<Vec<Fragment>, Error> {
        let log_position_range = if let Some(max_records) = limits.max_records {
            (from, from + max_records)
        } else {
            (from, LogPosition::MAX)
        };
        let mut snapshots = manifest
            .snapshots
            .iter()
            .filter(|s| ranges_overlap(log_position_range, (s.start, s.limit)))
            .cloned()
            .collect::<Vec<_>>();
        let mut fragments = manifest
            .fragments
            .iter()
            .filter(|f| ranges_overlap(log_position_range, (f.start, f.limit)))
            .cloned()
            .collect::<Vec<_>>();
        while !snapshots.is_empty() {
            // In parallel resolve this level of the tree.
            let futures = snapshots
                .iter()
                .map(|s| {
                    let cache = self.cache.as_ref().map(Arc::clone);
                    async move {
                        if let Some(cache) = cache {
                            if let Some(snapshot) = cache.get(s).await? {
                                return Ok(Some(snapshot));
                            }
                            let snap = self.manifest_consumer.snapshot_load(s).await?;
                            if let Some(snap) = snap.as_ref() {
                                cache.put(s, snap).await?;
                            }
                            Ok(snap)
                        } else {
                            self.manifest_consumer.snapshot_load(s).await
                        }
                    }
                })
                .collect::<Vec<_>>();
            let resolved = futures::future::try_join_all(futures).await?;
            // NOTE(rescrv):  This empties snapshots before the first loop so we can fill it
            // incrementally as we find snapshots that reference snapshots.
            for (r, s) in std::iter::zip(resolved.iter(), std::mem::take(&mut snapshots)) {
                if let Some(r) = r {
                    snapshots.extend(r.snapshots.iter().cloned());
                    fragments.extend(r.fragments.iter().cloned());
                } else {
                    return Err(Error::CorruptManifest(format!(
                        "snapshot {} is missing",
                        s.path_to_snapshot
                    )));
                }
            }
        }
        fragments.retain(|f| f.limit > from);
        fragments.sort_by_key(|f| f.start.offset());
        Ok(post_process_fragments(fragments, from, limits, short_read))
    }

    #[allow(clippy::type_complexity)]
    pub async fn read_parquet(
        &self,
        fragment: &Fragment,
    ) -> Result<(Setsum, Vec<(LogPosition, Vec<u8>)>, u64, u64), Error> {
        self.fragment_consumer
            .read_parquet(&fragment.path, fragment.start)
            .await
    }

    pub async fn read_bytes(&self, fragment: &Fragment) -> Result<Arc<Vec<u8>>, Error> {
        self.fragment_consumer.read_bytes(&fragment.path).await
    }

    /// Parse parquet previously returned by read_bytes.
    #[allow(clippy::type_complexity)]
    pub async fn parse_parquet(
        &self,
        parquet: &[u8],
        starting_log_position: LogPosition,
    ) -> Result<(Setsum, Vec<(LogPosition, Vec<u8>)>, u64, u64), Error> {
        self.fragment_consumer
            .parse_parquet(parquet, starting_log_position)
            .await
    }

    /// Parse parquet previously returned by read_bytes, skipping setsum computation.
    #[allow(clippy::type_complexity)]
    pub async fn parse_parquet_fast(
        &self,
        parquet: &[u8],
        starting_log_position: LogPosition,
    ) -> Result<(Vec<(LogPosition, Vec<u8>)>, u64, u64), Error> {
        self.fragment_consumer
            .parse_parquet_fast(parquet, starting_log_position)
            .await
    }

    /// Load the intrinsic cursor position, proxying to the manifest consumer.
    pub async fn load_intrinsic_cursor(&self) -> Result<Option<LogPosition>, Error> {
        self.manifest_consumer.load_intrinsic_cursor().await
    }

    /// Update the intrinsic cursor using an init-or-swap pattern, proxying to the manifest
    /// consumer.
    pub async fn update_intrinsic_cursor(
        &self,
        position: LogPosition,
        epoch_us: u64,
        writer: &str,
        allow_rollback: bool,
    ) -> Result<Option<CursorWitness>, Error> {
        self.manifest_consumer
            .update_intrinsic_cursor(position, epoch_us, writer, allow_rollback)
            .await
    }

    #[tracing::instrument(skip(self), ret)]
    pub async fn scrub(&self, limits: Limits) -> Result<ScrubSuccess, Vec<Error>> {
        let Some((manifest, _)) = self
            .manifest_consumer
            .manifest_load()
            .await
            .map_err(|x| vec![x])?
        else {
            return Err(vec![Error::UninitializedLog]);
        };
        let manifest_scrub_success = manifest.scrub().map_err(|x| vec![x.into()])?;
        let from = manifest.oldest_timestamp();
        let mut short_read = false;
        let fragments = self
            .scan_with_cache(&manifest, from, limits, &mut short_read)
            .await
            .map_err(|x| vec![x])?;
        let futures = fragments
            .iter()
            .map(|reference| async {
                if let Some(empirical) = self
                    .fragment_consumer
                    .read_fragment(&reference.path, reference.start)
                    .await
                    .map_err(|x| vec![x])?
                {
                    if reference.path != empirical.path {
                        return Err(vec![Error::ScrubError(
                            ScrubError::MismatchedPath {
                                reference: reference.clone(),
                                empirical,
                            }
                            .into(),
                        )]);
                    }
                    if reference.seq_no != empirical.seq_no {
                        return Err(vec![Error::ScrubError(
                            ScrubError::MismatchedSeqNo {
                                reference: reference.clone(),
                                empirical,
                            }
                            .into(),
                        )]);
                    }
                    if reference.num_bytes != empirical.num_bytes {
                        return Err(vec![Error::ScrubError(
                            ScrubError::MismatchedNumBytes {
                                reference: reference.clone(),
                                empirical,
                            }
                            .into(),
                        )]);
                    }
                    if reference.start != empirical.start {
                        return Err(vec![Error::ScrubError(
                            ScrubError::MismatchedStart {
                                reference: reference.clone(),
                                empirical,
                            }
                            .into(),
                        )]);
                    }
                    if reference.limit != empirical.limit {
                        return Err(vec![Error::ScrubError(
                            ScrubError::MismatchedLimit {
                                reference: reference.clone(),
                                empirical,
                            }
                            .into(),
                        )]);
                    }
                    if reference.setsum != empirical.setsum {
                        return Err(vec![Error::ScrubError(
                            ScrubError::MismatchedFragmentSetsum {
                                reference: reference.clone(),
                                empirical,
                            }
                            .into(),
                        )]);
                    }
                    Ok(reference.clone())
                } else {
                    Err(vec![Error::ScrubError(
                        ScrubError::MissingFragment {
                            reference: reference.clone(),
                        }
                        .into(),
                    )])
                }
            })
            .collect::<Vec<_>>();
        if futures.is_empty() {
            return Ok(ScrubSuccess {
                calculated_setsum: manifest_scrub_success.calculated_setsum,
                bytes_read: 0,
                short_read: manifest_scrub_success.short_read,
            });
        }
        let mut calculated_setsum = Setsum::default();
        let mut bytes_read = 0u64;
        let mut errors = vec![];
        for result in futures::future::join_all(futures).await {
            match result {
                Ok(frag) => {
                    calculated_setsum += frag.setsum;
                    bytes_read += frag.num_bytes;
                }
                Err(errs) => errors.extend(errs),
            }
        }
        let observed_scrub_success = ScrubSuccess {
            calculated_setsum,
            bytes_read,
            short_read,
        };
        if !short_read && manifest_scrub_success != observed_scrub_success {
            let mut ret = vec![Error::ScrubError(
                ScrubError::OverallMismatch {
                    manifest: manifest_scrub_success,
                    observed: observed_scrub_success,
                }
                .into(),
            )];
            ret.extend(errors);
            Err(ret)
        } else if short_read {
            Err(vec![Error::Success])
        } else {
            Ok(observed_scrub_success)
        }
    }
}

impl LogReader<(FragmentSeqNo, LogPosition), s3::S3FragmentPuller, s3::ManifestReader> {
    /// Open a LogReader with the classic S3-backed BatchManager and ManifestManager bindings.
    ///
    /// This is a convenience method that creates placeholder publishers since the LogReader
    /// primarily uses storage directly for reading operations.
    pub async fn open_classic(
        options: LogReaderOptions,
        storage: Arc<Storage>,
        prefix: String,
    ) -> Result<Self, Error> {
        let write = crate::LogWriterOptions::default();
        let (fragment_factory, manifest_factory) = s3::create_s3_factories(
            write,
            options.clone(),
            Arc::clone(&storage),
            prefix.clone(),
            "classic-reader".to_string(),
            Arc::new(()),
            Arc::new(()),
        );
        let fragment_consumer = fragment_factory.make_consumer().await?;
        let manifest_consumer = manifest_factory.make_consumer().await?;
        Self::open(options, fragment_consumer, manifest_consumer).await
    }
}

#[cfg(test)]
mod tests {
    use std::sync::atomic::{AtomicUsize, Ordering};
    use std::sync::Arc;

    use chroma_storage::ETag;
    use setsum::Setsum;

    use crate::interfaces::s3::{ManifestManager, ManifestReader};
    use crate::interfaces::{
        FragmentConsumer, FragmentManagerFactory, ManifestConsumer, ManifestManagerFactory,
    };
    use crate::{
        CursorWitness, Fragment, FragmentIdentifier, FragmentSeqNo, ManifestBounds,
        ManifestBoundsAndWitness, ManifestWitness, Snapshot, SnapshotPointer,
    };

    use super::*;

    struct TestFragmentConsumer;

    #[async_trait::async_trait]
    impl FragmentConsumer for TestFragmentConsumer {
        async fn read_bytes(&self, _path: &str) -> Result<Arc<Vec<u8>>, Error> {
            unreachable!("read_bytes is not used in this test")
        }

        async fn parse_parquet(
            &self,
            _parquet: &[u8],
            _fragment_first_log_position: LogPosition,
        ) -> Result<(Setsum, Vec<(LogPosition, Vec<u8>)>, u64, u64), Error> {
            unreachable!("parse_parquet is not used in this test")
        }

        async fn parse_parquet_fast(
            &self,
            _parquet: &[u8],
            _fragment_first_log_position: LogPosition,
        ) -> Result<(Vec<(LogPosition, Vec<u8>)>, u64, u64), Error> {
            unreachable!("parse_parquet_fast is not used in this test")
        }

        async fn read_fragment(
            &self,
            _path: &str,
            _fragment_first_log_position: LogPosition,
        ) -> Result<Option<Fragment>, Error> {
            unreachable!("read_fragment is not used in this test")
        }
    }

    struct TrackingManifestConsumer {
        bounds: Option<ManifestBoundsAndWitness>,
        fragments: Option<Vec<Fragment>>,
        manifest_load_calls: Arc<AtomicUsize>,
        bounds_calls: Arc<AtomicUsize>,
        partial_calls: Arc<AtomicUsize>,
    }

    #[async_trait::async_trait]
    impl ManifestConsumer<(FragmentSeqNo, LogPosition)> for TrackingManifestConsumer {
        async fn snapshot_load(
            &self,
            _pointer: &SnapshotPointer,
        ) -> Result<Option<Snapshot>, Error> {
            unreachable!("snapshot_load is not used in this test")
        }

        async fn manifest_head(&self, _witness: &ManifestWitness) -> Result<bool, Error> {
            unreachable!("manifest_head is not used in this test")
        }

        async fn manifest_load(&self) -> Result<Option<(Manifest, ManifestWitness)>, Error> {
            self.manifest_load_calls.fetch_add(1, Ordering::Relaxed);
            unreachable!("manifest_load should not be called")
        }

        async fn manifest_bounds_and_witness(
            &self,
        ) -> Result<Option<ManifestBoundsAndWitness>, Error> {
            self.bounds_calls.fetch_add(1, Ordering::Relaxed);
            Ok(self.bounds.clone())
        }

        async fn scan_partial(
            &self,
            _from: LogPosition,
            _limits: Limits,
        ) -> Result<Option<Vec<Fragment>>, Error> {
            self.partial_calls.fetch_add(1, Ordering::Relaxed);
            Ok(self.fragments.clone())
        }

        async fn update_intrinsic_cursor(
            &self,
            _position: LogPosition,
            _epoch_us: u64,
            _writer: &str,
            _allow_rollback: bool,
        ) -> Result<Option<CursorWitness>, Error> {
            unreachable!("update_intrinsic_cursor is not used in this test")
        }

        async fn load_intrinsic_cursor(&self) -> Result<Option<LogPosition>, Error> {
            unreachable!("load_intrinsic_cursor is not used in this test")
        }
    }

    #[test]
    fn post_process_fragments_uses_from_position_for_record_limits() {
        let fragments = vec![
            Fragment {
                path: "fragment1".to_string(),
                seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(1)),
                start: LogPosition::from_offset(100),
                limit: LogPosition::from_offset(150),
                num_bytes: 1000,
                setsum: Setsum::default(),
            },
            Fragment {
                path: "fragment2".to_string(),
                seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(2)),
                start: LogPosition::from_offset(150),
                limit: LogPosition::from_offset(200),
                num_bytes: 1000,
                setsum: Setsum::default(),
            },
            Fragment {
                path: "fragment3".to_string(),
                seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(3)),
                start: LogPosition::from_offset(200),
                limit: LogPosition::from_offset(250),
                num_bytes: 1000,
                setsum: Setsum::default(),
            },
        ];

        // Test case: from position is later than the first fragment's start
        // This tests the bug fix where we use 'from' instead of fragments[0].start
        let from = LogPosition::from_offset(125);
        let limits = Limits {
            max_files: None,
            max_bytes: None,
            max_records: Some(100), // Set a limit that should trigger the record check
        };

        let mut short_read = false;
        let result = post_process_fragments(fragments.clone(), from, limits, &mut short_read);

        // With the fix: last fragment start (200) - from (125) = 75 records
        // This should be under the 100 record limit, so all fragments should remain
        assert_eq!(result.len(), 3);
        assert!(!short_read);

        // Test case that would fail with the old bug:
        // If we were using fragments[0].start (100) instead of from (125),
        // then: last fragment start (200) - fragments[0].start (100) = 100 records
        // This would equal the limit, but the actual span from 'from' is only 75
        let limits_strict = Limits {
            max_files: None,
            max_bytes: None,
            max_records: Some(74), // Just under the actual span from 'from'
        };

        let mut short_read = false;
        let result_strict =
            post_process_fragments(fragments.clone(), from, limits_strict, &mut short_read);

        // With the fix: 200 - 125 = 75 > 74, so last fragment should be removed
        assert_eq!(result_strict.len(), 2);
        assert_eq!(
            result_strict[0].seq_no,
            FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(1))
        );
        assert_eq!(
            result_strict[1].seq_no,
            FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(2))
        );
        assert!(short_read);
    }

    #[test]
    fn records_based_pruning_bug_from_commit_message() {
        // Test the exact scenario from the commit message:
        // - Fragments with LogPosition ranges [1, 101), [101, 201).
        // - Query for 75 records at offset 50 should fetch both fragments.
        // - Prior to this change only the first fragment was fetched.

        let fragments = vec![
            Fragment {
                path: "fragment1".to_string(),
                seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(1)),
                start: LogPosition::from_offset(1),
                limit: LogPosition::from_offset(101),
                num_bytes: 1000,
                setsum: Setsum::default(),
            },
            Fragment {
                path: "fragment2".to_string(),
                seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(2)),
                start: LogPosition::from_offset(101),
                limit: LogPosition::from_offset(201),
                num_bytes: 1000,
                setsum: Setsum::default(),
            },
        ];

        // Query for 75 records at offset 50
        let from = LogPosition::from_offset(50);
        let limits = Limits {
            max_files: None,
            max_bytes: None,
            max_records: Some(75),
        };

        let mut short_read = false;
        let result = post_process_fragments(fragments.clone(), from, limits, &mut short_read);

        // With the fix: both fragments should be returned
        // The calculation is: last fragment start (101) - from (50) = 51 records
        // Since 51 < 75, both fragments should remain
        assert_eq!(
            result.len(),
            2,
            "Both fragments should be returned for 75 records from offset 50"
        );
        assert_eq!(
            result[0].seq_no,
            FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(1))
        );
        assert_eq!(
            result[1].seq_no,
            FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(2))
        );
        assert!(!short_read);

        // Test the edge case where the old bug would have incorrectly calculated:
        // Old bug would use: fragments[1].start (101) - fragments[0].start (1) = 100 records
        // If max_records was 99, old code would incorrectly remove the second fragment
        let limits_edge_case = Limits {
            max_files: None,
            max_bytes: None,
            max_records: Some(50), // Just under the actual span from 'from' (51)
        };

        let mut short_read = false;
        let result_edge =
            post_process_fragments(fragments.clone(), from, limits_edge_case, &mut short_read);

        // With the fix: 101 - 50 = 51 > 50, so the second fragment should be removed
        assert_eq!(
            result_edge.len(),
            1,
            "Only first fragment should remain with 50 record limit"
        );
        assert_eq!(
            result_edge[0].seq_no,
            FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(1))
        );
        assert!(short_read);
    }

    #[tokio::test]
    async fn manifest_bounds_and_witness_uses_consumer_override() {
        let manifest_load_calls = Arc::new(AtomicUsize::new(0));
        let bounds_calls = Arc::new(AtomicUsize::new(0));
        let partial_calls = Arc::new(AtomicUsize::new(0));
        let expected = ManifestBoundsAndWitness {
            bounds: ManifestBounds {
                oldest_timestamp: LogPosition::from_offset(5),
                next_write_timestamp: LogPosition::from_offset(42),
            },
            witness: ManifestWitness::ETag(ETag("test-etag".to_string())),
        };
        let reader = LogReader::new(
            LogReaderOptions::default(),
            TestFragmentConsumer,
            TrackingManifestConsumer {
                bounds: Some(expected.clone()),
                fragments: None,
                manifest_load_calls: Arc::clone(&manifest_load_calls),
                bounds_calls: Arc::clone(&bounds_calls),
                partial_calls: Arc::clone(&partial_calls),
            },
        );

        let observed = reader
            .manifest_bounds_and_witness()
            .await
            .expect("bounds load should succeed")
            .expect("bounds should be present");
        assert_eq!(expected, observed);
        assert_eq!(0, manifest_load_calls.load(Ordering::Relaxed));
        assert_eq!(1, bounds_calls.load(Ordering::Relaxed));
        assert_eq!(0, partial_calls.load(Ordering::Relaxed));
    }

    #[tokio::test]
    async fn scan_partial_uses_consumer_override() {
        let manifest_load_calls = Arc::new(AtomicUsize::new(0));
        let bounds_calls = Arc::new(AtomicUsize::new(0));
        let partial_calls = Arc::new(AtomicUsize::new(0));
        let expected = vec![Fragment {
            path: "fragment1".to_string(),
            seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(1)),
            start: LogPosition::from_offset(10),
            limit: LogPosition::from_offset(20),
            num_bytes: 128,
            setsum: Setsum::default(),
        }];
        let reader = LogReader::new(
            LogReaderOptions::default(),
            TestFragmentConsumer,
            TrackingManifestConsumer {
                bounds: None,
                fragments: Some(expected.clone()),
                manifest_load_calls: Arc::clone(&manifest_load_calls),
                bounds_calls: Arc::clone(&bounds_calls),
                partial_calls: Arc::clone(&partial_calls),
            },
        );

        let observed = reader
            .scan_partial(
                LogPosition::from_offset(10),
                Limits {
                    max_files: Some(2),
                    max_bytes: Some(1024),
                    max_records: Some(10),
                },
            )
            .await
            .expect("partial scan should succeed")
            .expect("partial scan should be present");
        assert_eq!(expected, observed);
        assert_eq!(0, manifest_load_calls.load(Ordering::Relaxed));
        assert_eq!(0, bounds_calls.load(Ordering::Relaxed));
        assert_eq!(1, partial_calls.load(Ordering::Relaxed));
    }

    #[test]
    fn test_ranges_overlap() {
        use crate::LogPosition;

        // Test cases that should return true (overlapping ranges)

        // Case 1: Complete overlap - one range is entirely within another
        assert!(
            ranges_overlap(
                (LogPosition::from_offset(10), LogPosition::from_offset(20)),
                (LogPosition::from_offset(12), LogPosition::from_offset(18))
            ),
            "Range (12,18) is entirely within (10,20)"
        );
        assert!(
            ranges_overlap(
                (LogPosition::from_offset(12), LogPosition::from_offset(18)),
                (LogPosition::from_offset(10), LogPosition::from_offset(20))
            ),
            "Range (12,18) is entirely within (10,20) - reversed"
        );

        // Case 2: Partial overlap - ranges overlap partially
        assert!(
            ranges_overlap(
                (LogPosition::from_offset(10), LogPosition::from_offset(20)),
                (LogPosition::from_offset(15), LogPosition::from_offset(25))
            ),
            "Ranges (10,20) and (15,25) overlap partially"
        );
        assert!(
            ranges_overlap(
                (LogPosition::from_offset(15), LogPosition::from_offset(25)),
                (LogPosition::from_offset(10), LogPosition::from_offset(20))
            ),
            "Ranges (15,25) and (10,20) overlap partially - reversed"
        );

        // Case 3: Identical ranges
        assert!(
            ranges_overlap(
                (LogPosition::from_offset(10), LogPosition::from_offset(20)),
                (LogPosition::from_offset(10), LogPosition::from_offset(20))
            ),
            "Identical ranges should overlap"
        );

        // Test cases that should return false (non-overlapping ranges)

        // Case 4: Completely separate ranges
        assert!(
            !ranges_overlap(
                (LogPosition::from_offset(10), LogPosition::from_offset(20)),
                (LogPosition::from_offset(25), LogPosition::from_offset(35))
            ),
            "Ranges (10,20) and (25,35) are completely separate"
        );
        assert!(
            !ranges_overlap(
                (LogPosition::from_offset(25), LogPosition::from_offset(35)),
                (LogPosition::from_offset(10), LogPosition::from_offset(20))
            ),
            "Ranges (25,35) and (10,20) are completely separate - reversed"
        );

        // Case 5: Adjacent but not touching ranges (gap between them)
        assert!(
            !ranges_overlap(
                (LogPosition::from_offset(10), LogPosition::from_offset(20)),
                (LogPosition::from_offset(21), LogPosition::from_offset(30))
            ),
            "Ranges (10,20) and (21,30) have a gap"
        );
        assert!(
            !ranges_overlap(
                (LogPosition::from_offset(21), LogPosition::from_offset(30)),
                (LogPosition::from_offset(10), LogPosition::from_offset(20))
            ),
            "Ranges (21,30) and (10,20) have a gap - reversed"
        );

        // Case 6: Adjacent ranges that just touch at boundaries (should NOT overlap for exclusive ranges)
        assert!(
            !ranges_overlap(
                (LogPosition::from_offset(10), LogPosition::from_offset(20)),
                (LogPosition::from_offset(20), LogPosition::from_offset(30))
            ),
            "Ranges (10,20) and (20,30) just touch - should not overlap"
        );
        assert!(
            !ranges_overlap(
                (LogPosition::from_offset(20), LogPosition::from_offset(30)),
                (LogPosition::from_offset(10), LogPosition::from_offset(20))
            ),
            "Ranges (20,30) and (10,20) just touch - should not overlap"
        );
    }

    #[test]
    fn scan_from_manifest_cached_manifest_boundary_conditions() {
        use crate::Manifest;

        // Test boundary conditions for the cached manifest bug fix
        // This tests the logic that checks if a cached manifest can satisfy a pull-logs request

        let fragments = vec![
            Fragment {
                path: "fragment1".to_string(),
                seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(1)),
                start: LogPosition::from_offset(1),
                limit: LogPosition::from_offset(101),
                num_bytes: 1000,
                setsum: Setsum::default(),
            },
            Fragment {
                path: "fragment2".to_string(),
                seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(2)),
                start: LogPosition::from_offset(101),
                limit: LogPosition::from_offset(201), // Manifest max is 201
                num_bytes: 1000,
                setsum: Setsum::default(),
            },
        ];

        let manifest = Manifest {
            setsum: Setsum::default(),
            collected: Setsum::default(),
            acc_bytes: 2000,
            writer: "test-writer".to_string(),
            snapshots: vec![],
            fragments: fragments.clone(),
            initial_offset: Some(LogPosition::from_offset(1)),
            initial_seq_no: Some(FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(1))),
        };

        println!("scan_from_manifest 1");

        // Boundary case 1: Request exactly at the manifest limit
        let from = LogPosition::from_offset(100);
        let limits = Limits {
            max_files: None,
            max_bytes: None,
            max_records: Some(100), // Would need data up to exactly offset 200
        };
        let result = scan_from_manifest(&manifest, from, limits);
        assert!(
            result.is_some(),
            "Should succeed when request stays within manifest coverage"
        );

        println!("scan_from_manifest 2");

        // Boundary case 2: Request exactly to the manifest limit
        let limits_at_limit = Limits {
            max_files: None,
            max_bytes: None,
            max_records: Some(101), // Would need data up to offset 201, manifest limit is 201
        };
        let result_at_limit = scan_from_manifest(&manifest, from, limits_at_limit);
        assert!(
            result_at_limit.is_some(),
            "Should succeed when request exactly matches manifest limit"
        );

        println!("scan_from_manifest 3");

        // Boundary case 3: Request one beyond the manifest limit
        let limits_beyond = Limits {
            max_files: None,
            max_bytes: None,
            max_records: Some(102), // Would need data up to offset 202, beyond manifest limit of 201
        };
        let result_beyond = scan_from_manifest(&manifest, from, limits_beyond);
        assert!(
            result_beyond.is_none(),
            "Should return None when request exceeds manifest coverage"
        );

        println!("scan_from_manifest 4");

        // Boundary case 4: Request from the very end of the manifest
        let from_end = LogPosition::from_offset(200);
        let limits_at_end = Limits {
            max_files: None,
            max_bytes: None,
            max_records: Some(1), // Would need data up to offset 201, exactly at manifest limit
        };
        let result_at_end = scan_from_manifest(&manifest, from_end, limits_at_end);
        assert!(
            result_at_end.is_some(),
            "Should succeed when request exactly matches manifest limit"
        );

        // Boundary case 5: Request from beyond the manifest
        let from_beyond = LogPosition::from_offset(201);
        let limits_beyond = Limits {
            max_files: None,
            max_bytes: None,
            max_records: Some(1),
        };
        let result_beyond = scan_from_manifest(&manifest, from_beyond, limits_beyond);
        assert!(
            result_beyond.is_none(),
            "Should return None when starting beyond manifest coverage"
        );

        // Boundary case 6: No max_records limit (LogPosition::MAX)
        let from_middle = LogPosition::from_offset(50);
        let limits_unlimited = Limits {
            max_files: None,
            max_bytes: None,
            max_records: None, // This creates a range to LogPosition::MAX
        };
        let result_unlimited = scan_from_manifest(&manifest, from_middle, limits_unlimited);
        assert!(
            result_unlimited.is_none(),
            "Should return None when unlimited range extends beyond manifest"
        );

        // Boundary case 7: Empty manifest
        let empty_manifest = Manifest {
            setsum: Setsum::default(),
            collected: Setsum::default(),
            acc_bytes: 0,
            writer: "test-writer".to_string(),
            snapshots: vec![],
            fragments: vec![],
            initial_offset: None,
            initial_seq_no: None,
        };
        let result_empty = scan_from_manifest(&empty_manifest, LogPosition::from_offset(0), limits);
        assert!(
            result_empty.is_none(),
            "Should return None for empty manifest"
        );

        // Boundary case 8: Integer overflow conditions (i64::MAX scenario from the bug fix)
        let from_overflow_test = LogPosition::from_offset(u64::MAX - 10);
        let limits_overflow = Limits {
            max_files: None,
            max_bytes: None,
            max_records: Some(20), // This would overflow if not handled properly
        };
        let result_overflow = scan_from_manifest(&manifest, from_overflow_test, limits_overflow);
        assert!(
            result_overflow.is_none(),
            "Should handle potential overflow gracefully"
        );
    }

    #[test]
    fn scan_from_manifest_rejects_non_contiguous_fragments() {
        let manifest = Manifest {
            setsum: Setsum::default(),
            collected: Setsum::default(),
            acc_bytes: 3000,
            writer: "test-writer".to_string(),
            snapshots: vec![],
            fragments: vec![
                Fragment {
                    path: "fragment1".to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(1)),
                    start: LogPosition::from_offset(1),
                    limit: LogPosition::from_offset(101),
                    num_bytes: 1000,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "fragment3".to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(3)),
                    start: LogPosition::from_offset(201),
                    limit: LogPosition::from_offset(301),
                    num_bytes: 1000,
                    setsum: Setsum::default(),
                },
            ],
            initial_offset: Some(LogPosition::from_offset(1)),
            initial_seq_no: Some(FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(1))),
        };

        let result = scan_from_manifest(
            &manifest,
            LogPosition::from_offset(50),
            Limits {
                max_files: None,
                max_bytes: None,
                max_records: Some(200),
            },
        );

        assert!(
            result.is_none(),
            "scan_from_manifest must reject fragment selections with interior gaps"
        );
    }

    #[test]
    fn scan_from_manifest_accepts_overlapping_contiguous_fragments() {
        let manifest = Manifest {
            setsum: Setsum::default(),
            collected: Setsum::default(),
            acc_bytes: 3000,
            writer: "test-writer".to_string(),
            snapshots: vec![],
            fragments: vec![
                Fragment {
                    path: "fragment1".to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(1)),
                    start: LogPosition::from_offset(1),
                    limit: LogPosition::from_offset(101),
                    num_bytes: 1000,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "fragment2".to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(2)),
                    start: LogPosition::from_offset(90),
                    limit: LogPosition::from_offset(201),
                    num_bytes: 1000,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "fragment3".to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(3)),
                    start: LogPosition::from_offset(201),
                    limit: LogPosition::from_offset(301),
                    num_bytes: 1000,
                    setsum: Setsum::default(),
                },
            ],
            initial_offset: Some(LogPosition::from_offset(1)),
            initial_seq_no: Some(FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(1))),
        };

        let result = scan_from_manifest(
            &manifest,
            LogPosition::from_offset(50),
            Limits {
                max_files: None,
                max_bytes: None,
                max_records: Some(200),
            },
        )
        .expect("overlapping fragments that cover the full range should be accepted");

        assert_eq!(
            result.len(),
            3,
            "all covering fragments should be preserved"
        );
    }

    #[test]
    fn obo_in_manifest_code() {
        let manifest = Manifest {
            setsum: Setsum::default(),
            collected: Setsum::default(),
            acc_bytes: 35837467,
            writer: "log writer".to_string(),
            snapshots: vec![],
            fragments: vec![
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000001.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(1)),
                    start: LogPosition { offset: 1 },
                    limit: LogPosition { offset: 101 },
                    num_bytes: 140461,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000002.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(2)),
                    start: LogPosition { offset: 101 },
                    limit: LogPosition { offset: 201 },
                    num_bytes: 139431,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000003.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(3)),
                    start: LogPosition { offset: 201 },
                    limit: LogPosition { offset: 301 },
                    num_bytes: 152250,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000004.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(4)),
                    start: LogPosition { offset: 301 },
                    limit: LogPosition { offset: 401 },
                    num_bytes: 141502,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000005.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(5)),
                    start: LogPosition { offset: 401 },
                    limit: LogPosition { offset: 501 },
                    num_bytes: 139784,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000006.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(6)),
                    start: LogPosition { offset: 501 },
                    limit: LogPosition { offset: 601 },
                    num_bytes: 133366,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000007.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(7)),
                    start: LogPosition { offset: 601 },
                    limit: LogPosition { offset: 701 },
                    num_bytes: 135825,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000008.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(8)),
                    start: LogPosition { offset: 701 },
                    limit: LogPosition { offset: 801 },
                    num_bytes: 133677,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000009.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(9)),
                    start: LogPosition { offset: 801 },
                    limit: LogPosition { offset: 901 },
                    num_bytes: 131341,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=000000000000000a.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(10)),
                    start: LogPosition { offset: 901 },
                    limit: LogPosition { offset: 1001 },
                    num_bytes: 139558,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=000000000000000b.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(11)),
                    start: LogPosition { offset: 1001 },
                    limit: LogPosition { offset: 1101 },
                    num_bytes: 139566,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=000000000000000c.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(12)),
                    start: LogPosition { offset: 1101 },
                    limit: LogPosition { offset: 1201 },
                    num_bytes: 138893,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=000000000000000d.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(13)),
                    start: LogPosition { offset: 1201 },
                    limit: LogPosition { offset: 1301 },
                    num_bytes: 144141,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=000000000000000e.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(14)),
                    start: LogPosition { offset: 1301 },
                    limit: LogPosition { offset: 1401 },
                    num_bytes: 136472,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=000000000000000f.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(15)),
                    start: LogPosition { offset: 1401 },
                    limit: LogPosition { offset: 1501 },
                    num_bytes: 136962,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000010.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(16)),
                    start: LogPosition { offset: 1501 },
                    limit: LogPosition { offset: 1601 },
                    num_bytes: 135440,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000011.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(17)),
                    start: LogPosition { offset: 1601 },
                    limit: LogPosition { offset: 1701 },
                    num_bytes: 136610,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000012.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(18)),
                    start: LogPosition { offset: 1701 },
                    limit: LogPosition { offset: 1801 },
                    num_bytes: 138079,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000013.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(19)),
                    start: LogPosition { offset: 1801 },
                    limit: LogPosition { offset: 1901 },
                    num_bytes: 132739,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000014.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(20)),
                    start: LogPosition { offset: 1901 },
                    limit: LogPosition { offset: 2001 },
                    num_bytes: 155167,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000015.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(21)),
                    start: LogPosition { offset: 2001 },
                    limit: LogPosition { offset: 2101 },
                    num_bytes: 133472,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000016.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(22)),
                    start: LogPosition { offset: 2101 },
                    limit: LogPosition { offset: 2201 },
                    num_bytes: 137153,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000017.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(23)),
                    start: LogPosition { offset: 2201 },
                    limit: LogPosition { offset: 2301 },
                    num_bytes: 133490,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000018.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(24)),
                    start: LogPosition { offset: 2301 },
                    limit: LogPosition { offset: 2401 },
                    num_bytes: 136554,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000019.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(25)),
                    start: LogPosition { offset: 2401 },
                    limit: LogPosition { offset: 2501 },
                    num_bytes: 138884,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=000000000000001a.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(26)),
                    start: LogPosition { offset: 2501 },
                    limit: LogPosition { offset: 2601 },
                    num_bytes: 137372,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=000000000000001b.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(27)),
                    start: LogPosition { offset: 2601 },
                    limit: LogPosition { offset: 2701 },
                    num_bytes: 138278,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=000000000000001c.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(28)),
                    start: LogPosition { offset: 2701 },
                    limit: LogPosition { offset: 2801 },
                    num_bytes: 134956,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=000000000000001d.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(29)),
                    start: LogPosition { offset: 2801 },
                    limit: LogPosition { offset: 2901 },
                    num_bytes: 140997,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=000000000000001e.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(30)),
                    start: LogPosition { offset: 2901 },
                    limit: LogPosition { offset: 3001 },
                    num_bytes: 138062,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=000000000000001f.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(31)),
                    start: LogPosition { offset: 3001 },
                    limit: LogPosition { offset: 3101 },
                    num_bytes: 134711,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000020.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(32)),
                    start: LogPosition { offset: 3101 },
                    limit: LogPosition { offset: 3201 },
                    num_bytes: 144809,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000021.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(33)),
                    start: LogPosition { offset: 3201 },
                    limit: LogPosition { offset: 3301 },
                    num_bytes: 138345,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000022.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(34)),
                    start: LogPosition { offset: 3301 },
                    limit: LogPosition { offset: 3401 },
                    num_bytes: 136250,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000023.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(35)),
                    start: LogPosition { offset: 3401 },
                    limit: LogPosition { offset: 3501 },
                    num_bytes: 146369,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000024.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(36)),
                    start: LogPosition { offset: 3501 },
                    limit: LogPosition { offset: 3601 },
                    num_bytes: 138827,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000025.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(37)),
                    start: LogPosition { offset: 3601 },
                    limit: LogPosition { offset: 3701 },
                    num_bytes: 133829,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000026.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(38)),
                    start: LogPosition { offset: 3701 },
                    limit: LogPosition { offset: 3801 },
                    num_bytes: 140918,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000027.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(39)),
                    start: LogPosition { offset: 3801 },
                    limit: LogPosition { offset: 3901 },
                    num_bytes: 141103,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000028.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(40)),
                    start: LogPosition { offset: 3901 },
                    limit: LogPosition { offset: 4001 },
                    num_bytes: 141949,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000029.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(41)),
                    start: LogPosition { offset: 4001 },
                    limit: LogPosition { offset: 4101 },
                    num_bytes: 139094,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=000000000000002a.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(42)),
                    start: LogPosition { offset: 4101 },
                    limit: LogPosition { offset: 4201 },
                    num_bytes: 139944,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=000000000000002b.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(43)),
                    start: LogPosition { offset: 4201 },
                    limit: LogPosition { offset: 4301 },
                    num_bytes: 140248,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=000000000000002c.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(44)),
                    start: LogPosition { offset: 4301 },
                    limit: LogPosition { offset: 4401 },
                    num_bytes: 140256,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=000000000000002d.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(45)),
                    start: LogPosition { offset: 4401 },
                    limit: LogPosition { offset: 4501 },
                    num_bytes: 141742,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=000000000000002e.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(46)),
                    start: LogPosition { offset: 4501 },
                    limit: LogPosition { offset: 4601 },
                    num_bytes: 142404,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=000000000000002f.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(47)),
                    start: LogPosition { offset: 4601 },
                    limit: LogPosition { offset: 4701 },
                    num_bytes: 137577,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000030.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(48)),
                    start: LogPosition { offset: 4701 },
                    limit: LogPosition { offset: 4801 },
                    num_bytes: 134633,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000031.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(49)),
                    start: LogPosition { offset: 4801 },
                    limit: LogPosition { offset: 4901 },
                    num_bytes: 141037,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000032.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(50)),
                    start: LogPosition { offset: 4901 },
                    limit: LogPosition { offset: 5001 },
                    num_bytes: 131669,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000033.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(51)),
                    start: LogPosition { offset: 5001 },
                    limit: LogPosition { offset: 5101 },
                    num_bytes: 138795,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000034.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(52)),
                    start: LogPosition { offset: 5101 },
                    limit: LogPosition { offset: 5201 },
                    num_bytes: 133732,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000035.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(53)),
                    start: LogPosition { offset: 5201 },
                    limit: LogPosition { offset: 5301 },
                    num_bytes: 135872,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000036.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(54)),
                    start: LogPosition { offset: 5301 },
                    limit: LogPosition { offset: 5401 },
                    num_bytes: 139780,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000037.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(55)),
                    start: LogPosition { offset: 5401 },
                    limit: LogPosition { offset: 5501 },
                    num_bytes: 139217,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000038.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(56)),
                    start: LogPosition { offset: 5501 },
                    limit: LogPosition { offset: 5601 },
                    num_bytes: 136125,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000039.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(57)),
                    start: LogPosition { offset: 5601 },
                    limit: LogPosition { offset: 5701 },
                    num_bytes: 139423,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=000000000000003a.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(58)),
                    start: LogPosition { offset: 5701 },
                    limit: LogPosition { offset: 5801 },
                    num_bytes: 142812,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=000000000000003b.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(59)),
                    start: LogPosition { offset: 5801 },
                    limit: LogPosition { offset: 5901 },
                    num_bytes: 141047,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=000000000000003c.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(60)),
                    start: LogPosition { offset: 5901 },
                    limit: LogPosition { offset: 6001 },
                    num_bytes: 142000,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=000000000000003d.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(61)),
                    start: LogPosition { offset: 6001 },
                    limit: LogPosition { offset: 6101 },
                    num_bytes: 136870,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=000000000000003e.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(62)),
                    start: LogPosition { offset: 6101 },
                    limit: LogPosition { offset: 6201 },
                    num_bytes: 134251,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=000000000000003f.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(63)),
                    start: LogPosition { offset: 6201 },
                    limit: LogPosition { offset: 6301 },
                    num_bytes: 158023,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000040.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(64)),
                    start: LogPosition { offset: 6301 },
                    limit: LogPosition { offset: 6401 },
                    num_bytes: 136371,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000041.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(65)),
                    start: LogPosition { offset: 6401 },
                    limit: LogPosition { offset: 6501 },
                    num_bytes: 145348,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000042.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(66)),
                    start: LogPosition { offset: 6501 },
                    limit: LogPosition { offset: 6601 },
                    num_bytes: 138702,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000043.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(67)),
                    start: LogPosition { offset: 6601 },
                    limit: LogPosition { offset: 6701 },
                    num_bytes: 152525,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000044.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(68)),
                    start: LogPosition { offset: 6701 },
                    limit: LogPosition { offset: 6801 },
                    num_bytes: 139994,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000045.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(69)),
                    start: LogPosition { offset: 6801 },
                    limit: LogPosition { offset: 6901 },
                    num_bytes: 136266,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000046.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(70)),
                    start: LogPosition { offset: 6901 },
                    limit: LogPosition { offset: 7001 },
                    num_bytes: 138243,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000047.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(71)),
                    start: LogPosition { offset: 7001 },
                    limit: LogPosition { offset: 7101 },
                    num_bytes: 139202,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000048.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(72)),
                    start: LogPosition { offset: 7101 },
                    limit: LogPosition { offset: 7201 },
                    num_bytes: 138727,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000049.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(73)),
                    start: LogPosition { offset: 7201 },
                    limit: LogPosition { offset: 7301 },
                    num_bytes: 136865,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=000000000000004a.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(74)),
                    start: LogPosition { offset: 7301 },
                    limit: LogPosition { offset: 7401 },
                    num_bytes: 138886,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=000000000000004b.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(75)),
                    start: LogPosition { offset: 7401 },
                    limit: LogPosition { offset: 7501 },
                    num_bytes: 137304,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=000000000000004c.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(76)),
                    start: LogPosition { offset: 7501 },
                    limit: LogPosition { offset: 7601 },
                    num_bytes: 136574,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=000000000000004d.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(77)),
                    start: LogPosition { offset: 7601 },
                    limit: LogPosition { offset: 7701 },
                    num_bytes: 140747,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=000000000000004e.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(78)),
                    start: LogPosition { offset: 7701 },
                    limit: LogPosition { offset: 7801 },
                    num_bytes: 144560,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=000000000000004f.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(79)),
                    start: LogPosition { offset: 7801 },
                    limit: LogPosition { offset: 7901 },
                    num_bytes: 137682,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000050.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(80)),
                    start: LogPosition { offset: 7901 },
                    limit: LogPosition { offset: 8001 },
                    num_bytes: 141263,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000051.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(81)),
                    start: LogPosition { offset: 8001 },
                    limit: LogPosition { offset: 8101 },
                    num_bytes: 136293,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000052.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(82)),
                    start: LogPosition { offset: 8101 },
                    limit: LogPosition { offset: 8201 },
                    num_bytes: 134459,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000053.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(83)),
                    start: LogPosition { offset: 8201 },
                    limit: LogPosition { offset: 8301 },
                    num_bytes: 137102,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000054.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(84)),
                    start: LogPosition { offset: 8301 },
                    limit: LogPosition { offset: 8401 },
                    num_bytes: 140636,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000055.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(85)),
                    start: LogPosition { offset: 8401 },
                    limit: LogPosition { offset: 8501 },
                    num_bytes: 137111,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000056.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(86)),
                    start: LogPosition { offset: 8501 },
                    limit: LogPosition { offset: 8601 },
                    num_bytes: 135579,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000057.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(87)),
                    start: LogPosition { offset: 8601 },
                    limit: LogPosition { offset: 8701 },
                    num_bytes: 137219,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000058.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(88)),
                    start: LogPosition { offset: 8701 },
                    limit: LogPosition { offset: 8801 },
                    num_bytes: 141777,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000059.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(89)),
                    start: LogPosition { offset: 8801 },
                    limit: LogPosition { offset: 8901 },
                    num_bytes: 133803,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=000000000000005a.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(90)),
                    start: LogPosition { offset: 8901 },
                    limit: LogPosition { offset: 9001 },
                    num_bytes: 135483,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=000000000000005b.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(91)),
                    start: LogPosition { offset: 9001 },
                    limit: LogPosition { offset: 9101 },
                    num_bytes: 140399,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=000000000000005c.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(92)),
                    start: LogPosition { offset: 9101 },
                    limit: LogPosition { offset: 9201 },
                    num_bytes: 143820,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=000000000000005d.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(93)),
                    start: LogPosition { offset: 9201 },
                    limit: LogPosition { offset: 9301 },
                    num_bytes: 139460,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=000000000000005e.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(94)),
                    start: LogPosition { offset: 9301 },
                    limit: LogPosition { offset: 9401 },
                    num_bytes: 137437,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=000000000000005f.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(95)),
                    start: LogPosition { offset: 9401 },
                    limit: LogPosition { offset: 9501 },
                    num_bytes: 142969,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000060.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(96)),
                    start: LogPosition { offset: 9501 },
                    limit: LogPosition { offset: 9601 },
                    num_bytes: 141351,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000061.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(97)),
                    start: LogPosition { offset: 9601 },
                    limit: LogPosition { offset: 9701 },
                    num_bytes: 138392,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000062.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(98)),
                    start: LogPosition { offset: 9701 },
                    limit: LogPosition { offset: 9801 },
                    num_bytes: 142135,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000063.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(99)),
                    start: LogPosition { offset: 9801 },
                    limit: LogPosition { offset: 9901 },
                    num_bytes: 135380,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000064.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(100)),
                    start: LogPosition { offset: 9901 },
                    limit: LogPosition { offset: 10001 },
                    num_bytes: 141166,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000065.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(101)),
                    start: LogPosition { offset: 10001 },
                    limit: LogPosition { offset: 10101 },
                    num_bytes: 145075,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000066.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(102)),
                    start: LogPosition { offset: 10101 },
                    limit: LogPosition { offset: 10201 },
                    num_bytes: 139179,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000067.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(103)),
                    start: LogPosition { offset: 10201 },
                    limit: LogPosition { offset: 10301 },
                    num_bytes: 141121,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000068.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(104)),
                    start: LogPosition { offset: 10301 },
                    limit: LogPosition { offset: 10401 },
                    num_bytes: 133021,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000069.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(105)),
                    start: LogPosition { offset: 10401 },
                    limit: LogPosition { offset: 10501 },
                    num_bytes: 133919,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=000000000000006a.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(106)),
                    start: LogPosition { offset: 10501 },
                    limit: LogPosition { offset: 10601 },
                    num_bytes: 145022,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=000000000000006b.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(107)),
                    start: LogPosition { offset: 10601 },
                    limit: LogPosition { offset: 10701 },
                    num_bytes: 141337,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=000000000000006c.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(108)),
                    start: LogPosition { offset: 10701 },
                    limit: LogPosition { offset: 10801 },
                    num_bytes: 150894,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=000000000000006d.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(109)),
                    start: LogPosition { offset: 10801 },
                    limit: LogPosition { offset: 10901 },
                    num_bytes: 146528,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=000000000000006e.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(110)),
                    start: LogPosition { offset: 10901 },
                    limit: LogPosition { offset: 11001 },
                    num_bytes: 136972,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=000000000000006f.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(111)),
                    start: LogPosition { offset: 11001 },
                    limit: LogPosition { offset: 11101 },
                    num_bytes: 137727,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000070.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(112)),
                    start: LogPosition { offset: 11101 },
                    limit: LogPosition { offset: 11201 },
                    num_bytes: 140892,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000071.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(113)),
                    start: LogPosition { offset: 11201 },
                    limit: LogPosition { offset: 11301 },
                    num_bytes: 141376,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000072.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(114)),
                    start: LogPosition { offset: 11301 },
                    limit: LogPosition { offset: 11401 },
                    num_bytes: 139071,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000073.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(115)),
                    start: LogPosition { offset: 11401 },
                    limit: LogPosition { offset: 11501 },
                    num_bytes: 132369,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000074.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(116)),
                    start: LogPosition { offset: 11501 },
                    limit: LogPosition { offset: 11601 },
                    num_bytes: 136670,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000075.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(117)),
                    start: LogPosition { offset: 11601 },
                    limit: LogPosition { offset: 11701 },
                    num_bytes: 143230,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000076.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(118)),
                    start: LogPosition { offset: 11701 },
                    limit: LogPosition { offset: 11801 },
                    num_bytes: 147801,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000077.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(119)),
                    start: LogPosition { offset: 11801 },
                    limit: LogPosition { offset: 11901 },
                    num_bytes: 139923,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000078.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(120)),
                    start: LogPosition { offset: 11901 },
                    limit: LogPosition { offset: 12001 },
                    num_bytes: 139459,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000079.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(121)),
                    start: LogPosition { offset: 12001 },
                    limit: LogPosition { offset: 12101 },
                    num_bytes: 138578,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=000000000000007a.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(122)),
                    start: LogPosition { offset: 12101 },
                    limit: LogPosition { offset: 12201 },
                    num_bytes: 138652,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=000000000000007b.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(123)),
                    start: LogPosition { offset: 12201 },
                    limit: LogPosition { offset: 12301 },
                    num_bytes: 141800,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=000000000000007c.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(124)),
                    start: LogPosition { offset: 12301 },
                    limit: LogPosition { offset: 12401 },
                    num_bytes: 137535,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=000000000000007d.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(125)),
                    start: LogPosition { offset: 12401 },
                    limit: LogPosition { offset: 12501 },
                    num_bytes: 137534,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=000000000000007e.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(126)),
                    start: LogPosition { offset: 12501 },
                    limit: LogPosition { offset: 12601 },
                    num_bytes: 139740,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=000000000000007f.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(127)),
                    start: LogPosition { offset: 12601 },
                    limit: LogPosition { offset: 12701 },
                    num_bytes: 139313,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000080.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(128)),
                    start: LogPosition { offset: 12701 },
                    limit: LogPosition { offset: 12801 },
                    num_bytes: 141420,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000081.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(129)),
                    start: LogPosition { offset: 12801 },
                    limit: LogPosition { offset: 12901 },
                    num_bytes: 144742,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000082.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(130)),
                    start: LogPosition { offset: 12901 },
                    limit: LogPosition { offset: 13001 },
                    num_bytes: 140023,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000083.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(131)),
                    start: LogPosition { offset: 13001 },
                    limit: LogPosition { offset: 13101 },
                    num_bytes: 141135,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000084.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(132)),
                    start: LogPosition { offset: 13101 },
                    limit: LogPosition { offset: 13201 },
                    num_bytes: 139778,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000085.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(133)),
                    start: LogPosition { offset: 13201 },
                    limit: LogPosition { offset: 13301 },
                    num_bytes: 141698,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000086.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(134)),
                    start: LogPosition { offset: 13301 },
                    limit: LogPosition { offset: 13401 },
                    num_bytes: 149539,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000087.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(135)),
                    start: LogPosition { offset: 13401 },
                    limit: LogPosition { offset: 13501 },
                    num_bytes: 137223,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000088.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(136)),
                    start: LogPosition { offset: 13501 },
                    limit: LogPosition { offset: 13601 },
                    num_bytes: 138479,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000089.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(137)),
                    start: LogPosition { offset: 13601 },
                    limit: LogPosition { offset: 13701 },
                    num_bytes: 138107,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=000000000000008a.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(138)),
                    start: LogPosition { offset: 13701 },
                    limit: LogPosition { offset: 13801 },
                    num_bytes: 132080,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=000000000000008b.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(139)),
                    start: LogPosition { offset: 13801 },
                    limit: LogPosition { offset: 13901 },
                    num_bytes: 132956,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=000000000000008c.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(140)),
                    start: LogPosition { offset: 13901 },
                    limit: LogPosition { offset: 14001 },
                    num_bytes: 137782,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=000000000000008d.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(141)),
                    start: LogPosition { offset: 14001 },
                    limit: LogPosition { offset: 14101 },
                    num_bytes: 135937,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=000000000000008e.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(142)),
                    start: LogPosition { offset: 14101 },
                    limit: LogPosition { offset: 14201 },
                    num_bytes: 135979,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=000000000000008f.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(143)),
                    start: LogPosition { offset: 14201 },
                    limit: LogPosition { offset: 14301 },
                    num_bytes: 137787,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000090.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(144)),
                    start: LogPosition { offset: 14301 },
                    limit: LogPosition { offset: 14401 },
                    num_bytes: 136146,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000091.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(145)),
                    start: LogPosition { offset: 14401 },
                    limit: LogPosition { offset: 14501 },
                    num_bytes: 135798,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000092.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(146)),
                    start: LogPosition { offset: 14501 },
                    limit: LogPosition { offset: 14601 },
                    num_bytes: 140262,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000093.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(147)),
                    start: LogPosition { offset: 14601 },
                    limit: LogPosition { offset: 14701 },
                    num_bytes: 140513,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000094.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(148)),
                    start: LogPosition { offset: 14701 },
                    limit: LogPosition { offset: 14801 },
                    num_bytes: 143028,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000095.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(149)),
                    start: LogPosition { offset: 14801 },
                    limit: LogPosition { offset: 14901 },
                    num_bytes: 141584,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000096.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(150)),
                    start: LogPosition { offset: 14901 },
                    limit: LogPosition { offset: 15001 },
                    num_bytes: 134143,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000097.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(151)),
                    start: LogPosition { offset: 15001 },
                    limit: LogPosition { offset: 15101 },
                    num_bytes: 134158,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000098.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(152)),
                    start: LogPosition { offset: 15101 },
                    limit: LogPosition { offset: 15201 },
                    num_bytes: 131993,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000099.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(153)),
                    start: LogPosition { offset: 15201 },
                    limit: LogPosition { offset: 15301 },
                    num_bytes: 143121,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=000000000000009a.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(154)),
                    start: LogPosition { offset: 15301 },
                    limit: LogPosition { offset: 15401 },
                    num_bytes: 140176,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=000000000000009b.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(155)),
                    start: LogPosition { offset: 15401 },
                    limit: LogPosition { offset: 15501 },
                    num_bytes: 129247,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=000000000000009c.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(156)),
                    start: LogPosition { offset: 15501 },
                    limit: LogPosition { offset: 15601 },
                    num_bytes: 135408,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=000000000000009d.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(157)),
                    start: LogPosition { offset: 15601 },
                    limit: LogPosition { offset: 15701 },
                    num_bytes: 140057,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=000000000000009e.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(158)),
                    start: LogPosition { offset: 15701 },
                    limit: LogPosition { offset: 15801 },
                    num_bytes: 142579,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=000000000000009f.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(159)),
                    start: LogPosition { offset: 15801 },
                    limit: LogPosition { offset: 15901 },
                    num_bytes: 132968,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=00000000000000a0.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(160)),
                    start: LogPosition { offset: 15901 },
                    limit: LogPosition { offset: 16001 },
                    num_bytes: 144536,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=00000000000000a1.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(161)),
                    start: LogPosition { offset: 16001 },
                    limit: LogPosition { offset: 16101 },
                    num_bytes: 135808,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=00000000000000a2.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(162)),
                    start: LogPosition { offset: 16101 },
                    limit: LogPosition { offset: 16201 },
                    num_bytes: 142077,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=00000000000000a3.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(163)),
                    start: LogPosition { offset: 16201 },
                    limit: LogPosition { offset: 16301 },
                    num_bytes: 128320,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=00000000000000a4.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(164)),
                    start: LogPosition { offset: 16301 },
                    limit: LogPosition { offset: 16401 },
                    num_bytes: 141075,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=00000000000000a5.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(165)),
                    start: LogPosition { offset: 16401 },
                    limit: LogPosition { offset: 16501 },
                    num_bytes: 147777,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=00000000000000a6.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(166)),
                    start: LogPosition { offset: 16501 },
                    limit: LogPosition { offset: 16601 },
                    num_bytes: 142136,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=00000000000000a7.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(167)),
                    start: LogPosition { offset: 16601 },
                    limit: LogPosition { offset: 16701 },
                    num_bytes: 139917,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=00000000000000a8.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(168)),
                    start: LogPosition { offset: 16701 },
                    limit: LogPosition { offset: 16801 },
                    num_bytes: 135551,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=00000000000000a9.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(169)),
                    start: LogPosition { offset: 16801 },
                    limit: LogPosition { offset: 16901 },
                    num_bytes: 138513,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=00000000000000aa.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(170)),
                    start: LogPosition { offset: 16901 },
                    limit: LogPosition { offset: 16998 },
                    num_bytes: 128558,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=00000000000000ab.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(171)),
                    start: LogPosition { offset: 16998 },
                    limit: LogPosition { offset: 17098 },
                    num_bytes: 140852,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=00000000000000ac.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(172)),
                    start: LogPosition { offset: 17098 },
                    limit: LogPosition { offset: 17198 },
                    num_bytes: 137489,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=00000000000000ad.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(173)),
                    start: LogPosition { offset: 17198 },
                    limit: LogPosition { offset: 17230 },
                    num_bytes: 58889,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=00000000000000ae.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(174)),
                    start: LogPosition { offset: 17230 },
                    limit: LogPosition { offset: 17330 },
                    num_bytes: 132866,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=00000000000000af.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(175)),
                    start: LogPosition { offset: 17330 },
                    limit: LogPosition { offset: 17430 },
                    num_bytes: 136424,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=00000000000000b0.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(176)),
                    start: LogPosition { offset: 17430 },
                    limit: LogPosition { offset: 17462 },
                    num_bytes: 65028,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=00000000000000b1.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(177)),
                    start: LogPosition { offset: 17462 },
                    limit: LogPosition { offset: 17562 },
                    num_bytes: 143723,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=00000000000000b2.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(178)),
                    start: LogPosition { offset: 17562 },
                    limit: LogPosition { offset: 17662 },
                    num_bytes: 141430,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=00000000000000b3.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(179)),
                    start: LogPosition { offset: 17662 },
                    limit: LogPosition { offset: 17747 },
                    num_bytes: 117091,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=00000000000000b4.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(180)),
                    start: LogPosition { offset: 17747 },
                    limit: LogPosition { offset: 17847 },
                    num_bytes: 136364,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=00000000000000b5.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(181)),
                    start: LogPosition { offset: 17847 },
                    limit: LogPosition { offset: 17947 },
                    num_bytes: 143624,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=00000000000000b6.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(182)),
                    start: LogPosition { offset: 17947 },
                    limit: LogPosition { offset: 17960 },
                    num_bytes: 40448,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=00000000000000b7.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(183)),
                    start: LogPosition { offset: 17960 },
                    limit: LogPosition { offset: 18060 },
                    num_bytes: 132795,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=00000000000000b8.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(184)),
                    start: LogPosition { offset: 18060 },
                    limit: LogPosition { offset: 18103 },
                    num_bytes: 82080,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=00000000000000b9.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(185)),
                    start: LogPosition { offset: 18103 },
                    limit: LogPosition { offset: 18203 },
                    num_bytes: 135489,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=00000000000000ba.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(186)),
                    start: LogPosition { offset: 18203 },
                    limit: LogPosition { offset: 18281 },
                    num_bytes: 119440,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=00000000000000bb.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(187)),
                    start: LogPosition { offset: 18281 },
                    limit: LogPosition { offset: 18381 },
                    num_bytes: 137393,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=00000000000000bc.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(188)),
                    start: LogPosition { offset: 18381 },
                    limit: LogPosition { offset: 18481 },
                    num_bytes: 143793,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=00000000000000bd.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(189)),
                    start: LogPosition { offset: 18481 },
                    limit: LogPosition { offset: 18495 },
                    num_bytes: 40225,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=00000000000000be.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(190)),
                    start: LogPosition { offset: 18495 },
                    limit: LogPosition { offset: 18595 },
                    num_bytes: 135172,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=00000000000000bf.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(191)),
                    start: LogPosition { offset: 18595 },
                    limit: LogPosition { offset: 18673 },
                    num_bytes: 114019,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=00000000000000c0.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(192)),
                    start: LogPosition { offset: 18673 },
                    limit: LogPosition { offset: 18773 },
                    num_bytes: 134766,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=00000000000000c1.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(193)),
                    start: LogPosition { offset: 18773 },
                    limit: LogPosition { offset: 18833 },
                    num_bytes: 93267,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=00000000000000c2.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(194)),
                    start: LogPosition { offset: 18833 },
                    limit: LogPosition { offset: 18933 },
                    num_bytes: 135209,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=00000000000000c3.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(195)),
                    start: LogPosition { offset: 18933 },
                    limit: LogPosition { offset: 18958 },
                    num_bytes: 56317,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=00000000000000c4.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(196)),
                    start: LogPosition { offset: 18958 },
                    limit: LogPosition { offset: 19058 },
                    num_bytes: 138040,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=00000000000000c5.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(197)),
                    start: LogPosition { offset: 19058 },
                    limit: LogPosition { offset: 19136 },
                    num_bytes: 116094,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=00000000000000c6.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(198)),
                    start: LogPosition { offset: 19136 },
                    limit: LogPosition { offset: 19236 },
                    num_bytes: 146527,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=00000000000000c7.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(199)),
                    start: LogPosition { offset: 19236 },
                    limit: LogPosition { offset: 19336 },
                    num_bytes: 138535,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=00000000000000c8.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(200)),
                    start: LogPosition { offset: 19336 },
                    limit: LogPosition { offset: 19368 },
                    num_bytes: 59758,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=00000000000000c9.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(201)),
                    start: LogPosition { offset: 19368 },
                    limit: LogPosition { offset: 19468 },
                    num_bytes: 136268,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=00000000000000ca.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(202)),
                    start: LogPosition { offset: 19468 },
                    limit: LogPosition { offset: 19511 },
                    num_bytes: 74216,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=00000000000000cb.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(203)),
                    start: LogPosition { offset: 19511 },
                    limit: LogPosition { offset: 19600 },
                    num_bytes: 122984,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=00000000000000cc.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(204)),
                    start: LogPosition { offset: 19600 },
                    limit: LogPosition { offset: 19700 },
                    num_bytes: 135231,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=00000000000000cd.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(205)),
                    start: LogPosition { offset: 19700 },
                    limit: LogPosition { offset: 19800 },
                    num_bytes: 146693,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=00000000000000ce.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(206)),
                    start: LogPosition { offset: 19800 },
                    limit: LogPosition { offset: 19831 },
                    num_bytes: 62674,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=00000000000000cf.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(207)),
                    start: LogPosition { offset: 19831 },
                    limit: LogPosition { offset: 19931 },
                    num_bytes: 141046,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=00000000000000d0.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(208)),
                    start: LogPosition { offset: 19931 },
                    limit: LogPosition { offset: 20031 },
                    num_bytes: 142907,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=00000000000000d1.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(209)),
                    start: LogPosition { offset: 20031 },
                    limit: LogPosition { offset: 20045 },
                    num_bytes: 41411,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=00000000000000d2.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(210)),
                    start: LogPosition { offset: 20045 },
                    limit: LogPosition { offset: 20145 },
                    num_bytes: 144353,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=00000000000000d3.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(211)),
                    start: LogPosition { offset: 20145 },
                    limit: LogPosition { offset: 20223 },
                    num_bytes: 119791,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=00000000000000d4.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(212)),
                    start: LogPosition { offset: 20223 },
                    limit: LogPosition { offset: 20323 },
                    num_bytes: 140264,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=00000000000000d5.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(213)),
                    start: LogPosition { offset: 20323 },
                    limit: LogPosition { offset: 20401 },
                    num_bytes: 117603,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=00000000000000d6.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(214)),
                    start: LogPosition { offset: 20401 },
                    limit: LogPosition { offset: 20501 },
                    num_bytes: 137419,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=00000000000000d7.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(215)),
                    start: LogPosition { offset: 20501 },
                    limit: LogPosition { offset: 20601 },
                    num_bytes: 134816,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=00000000000000d8.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(216)),
                    start: LogPosition { offset: 20601 },
                    limit: LogPosition { offset: 20615 },
                    num_bytes: 44611,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=00000000000000d9.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(217)),
                    start: LogPosition { offset: 20615 },
                    limit: LogPosition { offset: 20715 },
                    num_bytes: 147000,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=00000000000000da.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(218)),
                    start: LogPosition { offset: 20715 },
                    limit: LogPosition { offset: 20776 },
                    num_bytes: 100711,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=00000000000000db.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(219)),
                    start: LogPosition { offset: 20776 },
                    limit: LogPosition { offset: 20876 },
                    num_bytes: 130467,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=00000000000000dc.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(220)),
                    start: LogPosition { offset: 20876 },
                    limit: LogPosition { offset: 20918 },
                    num_bytes: 78680,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=00000000000000dd.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(221)),
                    start: LogPosition { offset: 20918 },
                    limit: LogPosition { offset: 21018 },
                    num_bytes: 141027,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=00000000000000de.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(222)),
                    start: LogPosition { offset: 21018 },
                    limit: LogPosition { offset: 21118 },
                    num_bytes: 137172,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=00000000000000df.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(223)),
                    start: LogPosition { offset: 21118 },
                    limit: LogPosition { offset: 21120 },
                    num_bytes: 28577,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=00000000000000e0.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(224)),
                    start: LogPosition { offset: 21120 },
                    limit: LogPosition { offset: 21220 },
                    num_bytes: 142801,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=00000000000000e1.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(225)),
                    start: LogPosition { offset: 21220 },
                    limit: LogPosition { offset: 21317 },
                    num_bytes: 132718,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=00000000000000e2.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(226)),
                    start: LogPosition { offset: 21317 },
                    limit: LogPosition { offset: 21417 },
                    num_bytes: 141569,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=00000000000000e3.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(227)),
                    start: LogPosition { offset: 21417 },
                    limit: LogPosition { offset: 21517 },
                    num_bytes: 135554,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=00000000000000e4.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(228)),
                    start: LogPosition { offset: 21517 },
                    limit: LogPosition { offset: 21617 },
                    num_bytes: 139003,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=00000000000000e5.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(229)),
                    start: LogPosition { offset: 21617 },
                    limit: LogPosition { offset: 21717 },
                    num_bytes: 138216,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=00000000000000e6.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(230)),
                    start: LogPosition { offset: 21717 },
                    limit: LogPosition { offset: 21723 },
                    num_bytes: 37598,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=00000000000000e7.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(231)),
                    start: LogPosition { offset: 21723 },
                    limit: LogPosition { offset: 21823 },
                    num_bytes: 141600,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=00000000000000e8.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(232)),
                    start: LogPosition { offset: 21823 },
                    limit: LogPosition { offset: 21923 },
                    num_bytes: 143969,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=00000000000000e9.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(233)),
                    start: LogPosition { offset: 21923 },
                    limit: LogPosition { offset: 21971 },
                    num_bytes: 80795,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=00000000000000ea.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(234)),
                    start: LogPosition { offset: 21971 },
                    limit: LogPosition { offset: 22071 },
                    num_bytes: 137429,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=00000000000000eb.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(235)),
                    start: LogPosition { offset: 22071 },
                    limit: LogPosition { offset: 22171 },
                    num_bytes: 138327,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=00000000000000ec.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(236)),
                    start: LogPosition { offset: 22171 },
                    limit: LogPosition { offset: 22213 },
                    num_bytes: 72307,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=00000000000000ed.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(237)),
                    start: LogPosition { offset: 22213 },
                    limit: LogPosition { offset: 22313 },
                    num_bytes: 134711,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=00000000000000ee.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(238)),
                    start: LogPosition { offset: 22313 },
                    limit: LogPosition { offset: 22413 },
                    num_bytes: 143139,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=00000000000000ef.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(239)),
                    start: LogPosition { offset: 22413 },
                    limit: LogPosition { offset: 22432 },
                    num_bytes: 49336,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=00000000000000f0.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(240)),
                    start: LogPosition { offset: 22432 },
                    limit: LogPosition { offset: 22532 },
                    num_bytes: 139229,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=00000000000000f1.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(241)),
                    start: LogPosition { offset: 22532 },
                    limit: LogPosition { offset: 22609 },
                    num_bytes: 113924,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=00000000000000f2.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(242)),
                    start: LogPosition { offset: 22609 },
                    limit: LogPosition { offset: 22709 },
                    num_bytes: 142130,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=00000000000000f3.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(243)),
                    start: LogPosition { offset: 22709 },
                    limit: LogPosition { offset: 22809 },
                    num_bytes: 133268,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=00000000000000f4.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(244)),
                    start: LogPosition { offset: 22809 },
                    limit: LogPosition { offset: 22891 },
                    num_bytes: 113712,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=00000000000000f5.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(245)),
                    start: LogPosition { offset: 22891 },
                    limit: LogPosition { offset: 22991 },
                    num_bytes: 135405,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=00000000000000f6.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(246)),
                    start: LogPosition { offset: 22991 },
                    limit: LogPosition { offset: 23091 },
                    num_bytes: 134463,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=00000000000000f7.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(247)),
                    start: LogPosition { offset: 23091 },
                    limit: LogPosition { offset: 23146 },
                    num_bytes: 86577,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=00000000000000f8.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(248)),
                    start: LogPosition { offset: 23146 },
                    limit: LogPosition { offset: 23246 },
                    num_bytes: 133988,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=00000000000000f9.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(249)),
                    start: LogPosition { offset: 23246 },
                    limit: LogPosition { offset: 23346 },
                    num_bytes: 140277,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=00000000000000fa.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(250)),
                    start: LogPosition { offset: 23346 },
                    limit: LogPosition { offset: 23446 },
                    num_bytes: 136722,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=00000000000000fb.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(251)),
                    start: LogPosition { offset: 23446 },
                    limit: LogPosition { offset: 23475 },
                    num_bytes: 58492,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=00000000000000fc.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(252)),
                    start: LogPosition { offset: 23475 },
                    limit: LogPosition { offset: 23575 },
                    num_bytes: 141272,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=00000000000000fd.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(253)),
                    start: LogPosition { offset: 23575 },
                    limit: LogPosition { offset: 23675 },
                    num_bytes: 137722,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=00000000000000fe.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(254)),
                    start: LogPosition { offset: 23675 },
                    limit: LogPosition { offset: 23742 },
                    num_bytes: 100808,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=00000000000000ff.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(255)),
                    start: LogPosition { offset: 23742 },
                    limit: LogPosition { offset: 23842 },
                    num_bytes: 134240,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000100.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(256)),
                    start: LogPosition { offset: 23842 },
                    limit: LogPosition { offset: 23942 },
                    num_bytes: 135368,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000101.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(257)),
                    start: LogPosition { offset: 23942 },
                    limit: LogPosition { offset: 24029 },
                    num_bytes: 121177,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000102.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(258)),
                    start: LogPosition { offset: 24029 },
                    limit: LogPosition { offset: 24129 },
                    num_bytes: 131830,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000103.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(259)),
                    start: LogPosition { offset: 24129 },
                    limit: LogPosition { offset: 24229 },
                    num_bytes: 137812,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000104.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(260)),
                    start: LogPosition { offset: 24229 },
                    limit: LogPosition { offset: 24301 },
                    num_bytes: 104740,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000105.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(261)),
                    start: LogPosition { offset: 24301 },
                    limit: LogPosition { offset: 24401 },
                    num_bytes: 136602,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000106.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(262)),
                    start: LogPosition { offset: 24401 },
                    limit: LogPosition { offset: 24485 },
                    num_bytes: 115053,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000107.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(263)),
                    start: LogPosition { offset: 24485 },
                    limit: LogPosition { offset: 24585 },
                    num_bytes: 141135,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000108.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(264)),
                    start: LogPosition { offset: 24585 },
                    limit: LogPosition { offset: 24685 },
                    num_bytes: 136246,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000109.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(265)),
                    start: LogPosition { offset: 24685 },
                    limit: LogPosition { offset: 24785 },
                    num_bytes: 136663,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=000000000000010a.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(266)),
                    start: LogPosition { offset: 24785 },
                    limit: LogPosition { offset: 24790 },
                    num_bytes: 35690,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=000000000000010b.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(267)),
                    start: LogPosition { offset: 24790 },
                    limit: LogPosition { offset: 24890 },
                    num_bytes: 138674,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=000000000000010c.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(268)),
                    start: LogPosition { offset: 24890 },
                    limit: LogPosition { offset: 24990 },
                    num_bytes: 140703,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=000000000000010d.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(269)),
                    start: LogPosition { offset: 24990 },
                    limit: LogPosition { offset: 25045 },
                    num_bytes: 85851,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=000000000000010e.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(270)),
                    start: LogPosition { offset: 25045 },
                    limit: LogPosition { offset: 25145 },
                    num_bytes: 141113,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=000000000000010f.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(271)),
                    start: LogPosition { offset: 25145 },
                    limit: LogPosition { offset: 25245 },
                    num_bytes: 135896,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000110.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(272)),
                    start: LogPosition { offset: 25245 },
                    limit: LogPosition { offset: 25345 },
                    num_bytes: 137036,
                    setsum: Setsum::default(),
                },
                Fragment {
                    path: "log/Bucket=0000000000000000/FragmentSeqNo=0000000000000111.parquet"
                        .to_string(),
                    seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(273)),
                    start: LogPosition { offset: 25345 },
                    limit: LogPosition { offset: 25445 },
                    num_bytes: 135284,
                    setsum: Setsum::default(),
                },
            ],
            initial_offset: Some(LogPosition { offset: 1 }),
            initial_seq_no: Some(FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(1))),
        };
        let Some(fragments) = scan_from_manifest(
            &manifest,
            LogPosition::from_offset(20776),
            Limits {
                max_files: None,
                max_bytes: None,
                max_records: Some(142),
            },
        ) else {
            panic!("failed to get fragments");
        };
        assert_eq!(fragments.len(), 2);
        assert_eq!(
            fragments[0],
            Fragment {
                path: "log/Bucket=0000000000000000/FragmentSeqNo=00000000000000db.parquet"
                    .to_string(),
                seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(219)),
                start: LogPosition { offset: 20776 },
                limit: LogPosition { offset: 20876 },
                num_bytes: 130467,
                setsum: Setsum::default(),
            }
        );
        assert_eq!(
            fragments[1],
            Fragment {
                path: "log/Bucket=0000000000000000/FragmentSeqNo=00000000000000dc.parquet"
                    .to_string(),
                seq_no: FragmentIdentifier::SeqNo(FragmentSeqNo::from_u64(220)),
                start: LogPosition { offset: 20876 },
                limit: LogPosition { offset: 20918 },
                num_bytes: 78680,
                setsum: Setsum::default(),
            }
        );
    }

    #[tokio::test]
    async fn test_k8s_integration_verify_returns_true_when_manifest_etag_matches() {
        let storage = Arc::new(chroma_storage::s3::s3_client_for_test_with_new_bucket().await);
        let prefix = "test-prefix".to_string();
        let options = LogReaderOptions::default();
        let writer_options = crate::LogWriterOptions::default();

        let manifest = Manifest::new_empty("test-writer");
        ManifestManager::initialize_from_manifest(
            &writer_options,
            &storage,
            &prefix,
            manifest.clone(),
        )
        .await
        .unwrap();

        let (fragment_factory, manifest_factory) = s3::create_s3_factories(
            writer_options,
            LogReaderOptions::default(),
            Arc::clone(&storage),
            prefix.clone(),
            "test-writer".to_string(),
            Arc::new(()),
            Arc::new(()),
        );
        let batch_manager = fragment_factory.make_consumer().await.unwrap();
        let manifest_manager = manifest_factory.make_consumer().await.unwrap();

        let reader = LogReader::new(options.clone(), batch_manager, manifest_manager);

        let (loaded_manifest, etag) = ManifestReader::load(&options.throttle, &storage, &prefix)
            .await
            .unwrap()
            .unwrap();

        let manifest_and_witness = ManifestAndWitness {
            manifest: loaded_manifest,
            witness: crate::ManifestWitness::ETag(etag),
        };

        let result = reader.verify(&manifest_and_witness).await.unwrap();
        assert!(result, "verify should return true for matching etag");
    }

    #[tokio::test]
    async fn test_k8s_integration_verify_returns_false_when_manifest_etag_does_not_match() {
        let storage = Arc::new(chroma_storage::s3::s3_client_for_test_with_new_bucket().await);
        let prefix = "test-prefix".to_string();
        let options = LogReaderOptions::default();
        let writer_options = crate::LogWriterOptions::default();

        let manifest = Manifest::new_empty("test-writer");
        ManifestManager::initialize_from_manifest(
            &writer_options,
            &storage,
            &prefix,
            manifest.clone(),
        )
        .await
        .unwrap();

        let (fragment_factory, manifest_factory) = s3::create_s3_factories(
            writer_options,
            LogReaderOptions::default(),
            Arc::clone(&storage),
            prefix.clone(),
            "test-writer".to_string(),
            Arc::new(()),
            Arc::new(()),
        );
        let batch_manager = fragment_factory.make_consumer().await.unwrap();
        let manifest_manager = manifest_factory.make_consumer().await.unwrap();

        let reader = LogReader::new(options, batch_manager, manifest_manager);

        let fake_etag = chroma_storage::ETag("fake-etag-that-wont-match".to_string());
        let manifest_and_witness = ManifestAndWitness {
            manifest,
            witness: crate::ManifestWitness::ETag(fake_etag),
        };

        let result = reader.verify(&manifest_and_witness).await.unwrap();
        assert!(!result, "verify should return false for non-matching etag");
    }

    #[tokio::test]
    async fn test_k8s_integration_verify_handles_storage_errors_gracefully() {
        use chroma_storage::local::LocalStorage;

        let storage = Arc::new(chroma_storage::Storage::Local(LocalStorage::new(
            "./test-local",
        )));
        let prefix = "test-prefix".to_string();
        let options = LogReaderOptions::default();
        let writer_options = crate::LogWriterOptions::default();

        // Initialize a manifest first so we can create the managers
        // but we'll point the reader at a nonexistent prefix
        let manifest = Manifest::new_empty("test-writer");
        ManifestManager::initialize_from_manifest(
            &writer_options,
            &storage,
            &prefix,
            manifest.clone(),
        )
        .await
        .unwrap();

        let (fragment_factory, manifest_factory) = s3::create_s3_factories(
            writer_options,
            LogReaderOptions::default(),
            Arc::clone(&storage),
            prefix.clone(),
            "test-writer".to_string(),
            Arc::new(()),
            Arc::new(()),
        );
        let batch_manager = fragment_factory.make_consumer().await.unwrap();
        let manifest_manager = manifest_factory.make_consumer().await.unwrap();

        let reader = LogReader::new(options, batch_manager, manifest_manager);

        let fake_etag = chroma_storage::ETag("fake-etag".to_string());
        let manifest_and_witness = ManifestAndWitness {
            manifest,
            witness: crate::ManifestWitness::ETag(fake_etag),
        };

        let result = reader.verify(&manifest_and_witness).await;
        match result {
            Err(crate::Error::StorageError(storage_error)) => {
                match storage_error.as_ref() {
                    chroma_storage::StorageError::NotImplemented => {
                        // This is expected for local storage
                    }
                    _ => panic!("Unexpected storage error: {:?}", storage_error),
                }
            }
            _ => panic!("Expected storage error for local storage verify"),
        }
    }

    #[tokio::test]
    async fn test_k8s_integration_manifest_and_witness_returns_both_manifest_and_witness() {
        let storage = Arc::new(chroma_storage::s3::s3_client_for_test_with_new_bucket().await);
        let prefix = "test-prefix".to_string();
        let options = LogReaderOptions::default();
        let writer_options = crate::LogWriterOptions::default();

        let manifest = Manifest::new_empty("test-writer");
        ManifestManager::initialize_from_manifest(
            &writer_options,
            &storage,
            &prefix,
            manifest.clone(),
        )
        .await
        .unwrap();

        let (fragment_factory, manifest_factory) = s3::create_s3_factories(
            writer_options,
            LogReaderOptions::default(),
            Arc::clone(&storage),
            prefix.clone(),
            "test-writer".to_string(),
            Arc::new(()),
            Arc::new(()),
        );
        let batch_manager = fragment_factory.make_consumer().await.unwrap();
        let manifest_manager = manifest_factory.make_consumer().await.unwrap();

        let reader = LogReader::new(options, batch_manager, manifest_manager);

        let result = reader.manifest_and_witness().await.unwrap();
        assert!(
            result.is_some(),
            "manifest_and_witness should return Some when manifest exists"
        );

        let manifest_and_witness = result.unwrap();
        assert_eq!(manifest_and_witness.manifest.writer, "test-writer");
        match manifest_and_witness.witness {
            crate::ManifestWitness::ETag(e_tag) => {
                assert!(!e_tag.0.is_empty(), "etag should not be empty");
            }
            crate::ManifestWitness::Position(_) => {
                panic!("Expected ETag witness, got Position");
            }
        }
    }

    #[tokio::test]
    async fn test_k8s_integration_manifest_and_witness_returns_none_when_no_manifest() {
        let storage = chroma_storage::s3::s3_client_for_test_with_new_bucket().await;
        let prefix = "nonexistent-prefix".to_string();
        let options = LogReaderOptions::default();
        let writer_options = crate::LogWriterOptions::default();

        // Create factories pointing to a prefix with no manifest.
        let fragment_factory = crate::S3FragmentManagerFactory {
            write: writer_options.clone(),
            read: LogReaderOptions::default(),
            storage: storage.clone(),
            prefix: prefix.clone(),
            mark_dirty: Arc::new(()),
        };
        let manifest_factory = crate::S3ManifestManagerFactory {
            write: writer_options.clone(),
            read: LogReaderOptions::default(),
            storage: Arc::new(storage),
            prefix: prefix.clone(),
            writer: "test-writer".to_string(),
            mark_dirty: Arc::new(()),
            snapshot_cache: Arc::new(()),
        };
        let batch_manager = fragment_factory.make_consumer().await.unwrap();
        let manifest_manager = manifest_factory.make_consumer().await.unwrap();

        let reader = LogReader::new(options, batch_manager, manifest_manager);

        let result = reader.manifest_and_witness().await.unwrap();
        assert!(
            result.is_none(),
            "manifest_and_witness should return None when no manifest exists"
        );
    }
}
