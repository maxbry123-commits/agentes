# Copyright (c) 2026, AG2ai, Inc., AG2ai open-source projects maintainers and core contributors
#
# SPDX-License-Identifier: Apache-2.0

import pytest
from fast_depends.use import SerializerCls
from google.genai import types

from ag2 import ToolResult
from ag2.compact import CompactionSummary
from ag2.config.gemini.events import (
    GeminiServerToolCallEvent,
    GeminiServerToolResultEvent,
)
from ag2.config.gemini.mappers import convert_messages
from ag2.events import (
    AudioInput,
    BinaryInput,
    DocumentInput,
    FileIdInput,
    ImageInput,
    ModelRequest,
    ModelResponse,
    TextInput,
    ToolCallEvent,
    ToolCallsEvent,
    ToolNotFoundEvent,
    ToolResultEvent,
    ToolResultsEvent,
    VideoInput,
)
from ag2.exceptions import ToolNotFoundError, UnsupportedInputError


def _model_response_with_tool_call(arguments: str | None) -> ModelResponse:
    return ModelResponse(
        message=None,
        tool_calls=ToolCallsEvent(
            calls=[ToolCallEvent(id="tc_1", name="list_items", arguments=arguments)],
        ),
    )


class TestConvertMessagesEmptyArguments:
    """json.loads must not crash on empty or None tool call arguments."""

    @pytest.mark.parametrize("arguments", ["", None])
    def test_empty_arguments_produce_empty_dict(self, arguments: str | None) -> None:
        [content] = convert_messages([_model_response_with_tool_call(arguments)], SerializerCls)

        assert content.model_dump(exclude_none=True) == {
            "role": "model",
            "parts": [{"function_call": {"name": "list_items", "args": {}}}],
        }

    def test_valid_arguments_are_preserved(self) -> None:
        [content] = convert_messages([_model_response_with_tool_call('{"category": "books"}')], SerializerCls)

        assert content.model_dump(exclude_none=True) == {
            "role": "model",
            "parts": [{"function_call": {"name": "list_items", "args": {"category": "books"}}}],
        }


def test_image_url() -> None:
    img_url = "https://example.com/image.png"
    [content] = convert_messages([ModelRequest([ImageInput(url=img_url)])], SerializerCls)

    assert content.model_dump(exclude_none=True) == {
        "role": "user",
        "parts": [{"file_data": {"file_uri": img_url, "mime_type": "image/png"}}],
    }


def test_image_binary() -> None:
    png = b"\x89PNG\r\n\x1a\nfake"
    [content] = convert_messages([ModelRequest([ImageInput(data=png, media_type="image/png")])], SerializerCls)

    assert content.model_dump(exclude_none=True) == {
        "role": "user",
        "parts": [{"inline_data": {"data": png, "mime_type": "image/png"}}],
    }


def test_audio_url() -> None:
    audio_url = "https://example.com/audio.wav"
    [content] = convert_messages([ModelRequest([AudioInput(url=audio_url)])], SerializerCls)

    assert content.model_dump(exclude_none=True) == {
        "role": "user",
        "parts": [{"file_data": {"file_uri": audio_url, "mime_type": "audio/wav"}}],
    }


def test_audio_binary() -> None:
    audio = b"\x00\x01\x02audio"
    [content] = convert_messages([ModelRequest([AudioInput(data=audio, media_type="audio/wav")])], SerializerCls)

    assert content.model_dump(exclude_none=True) == {
        "role": "user",
        "parts": [{"inline_data": {"data": audio, "mime_type": "audio/wav"}}],
    }


def test_document_url() -> None:
    doc_url = "https://example.com/doc.pdf"
    [content] = convert_messages([ModelRequest([DocumentInput(url=doc_url)])], SerializerCls)

    assert content.model_dump(exclude_none=True) == {
        "role": "user",
        "parts": [{"file_data": {"file_uri": doc_url, "mime_type": "application/pdf"}}],
    }


def test_document_binary() -> None:
    pdf = b"%PDF-1.4"
    [content] = convert_messages([ModelRequest([DocumentInput(data=pdf, media_type="application/pdf")])], SerializerCls)

    assert content.model_dump(exclude_none=True) == {
        "role": "user",
        "parts": [{"inline_data": {"data": pdf, "mime_type": "application/pdf"}}],
    }


class TestVideoUrl:
    def test_known_extension(self) -> None:
        url = "https://example.com/clip.mp4"
        [content] = convert_messages([ModelRequest([VideoInput(url=url)])], SerializerCls)

        assert content.model_dump(exclude_none=True) == {
            "role": "user",
            "parts": [{"file_data": {"file_uri": url, "mime_type": "video/mp4"}}],
        }

    def test_youtube_url_has_no_mime_type(self) -> None:
        url = "https://www.youtube.com/watch?v=dQw4w9WgXcQ"
        [content] = convert_messages([ModelRequest([VideoInput(url=url)])], SerializerCls)

        assert content.model_dump(exclude_none=True) == {
            "role": "user",
            "parts": [{"file_data": {"file_uri": url}}],
        }


def test_video_binary() -> None:
    video = b"\x00\x00\x00\x1cftypisom"
    [content] = convert_messages([ModelRequest([VideoInput(data=video, media_type="video/mp4")])], SerializerCls)

    assert content.model_dump(exclude_none=True) == {
        "role": "user",
        "parts": [{"inline_data": {"data": video, "mime_type": "video/mp4"}}],
    }


class TestVendorMetadata:
    PNG = b"\x89PNG\r\n\x1a\nfake"

    def test_media_resolution(self) -> None:
        inp = BinaryInput(
            data=self.PNG,
            media_type="image/png",
            vendor_metadata={"media_resolution": "MEDIA_RESOLUTION_LOW"},
        )
        [content] = convert_messages([ModelRequest([inp])], SerializerCls)

        assert content.model_dump(exclude_none=True) == {
            "role": "user",
            "parts": [
                {
                    "media_resolution": {"level": "MEDIA_RESOLUTION_LOW"},
                    "inline_data": {"data": self.PNG, "mime_type": "image/png"},
                }
            ],
        }

    def test_media_resolution_dict(self) -> None:
        # `level` and `num_tokens` are a oneof — `num_tokens` is only reachable
        # through the dict form, and sending both is rejected by the API.
        inp = BinaryInput(
            data=self.PNG,
            media_type="image/png",
            vendor_metadata={"media_resolution": {"num_tokens": 64}},
        )
        [content] = convert_messages([ModelRequest([inp])], SerializerCls)

        assert content.model_dump(exclude_none=True) == {
            "role": "user",
            "parts": [
                {
                    "media_resolution": {"num_tokens": 64},
                    "inline_data": {"data": self.PNG, "mime_type": "image/png"},
                }
            ],
        }

    def test_video_metadata_dict(self) -> None:
        inp = BinaryInput(
            data=b"\x00\x00video",
            media_type="video/mp4",
            vendor_metadata={"video_metadata": {"fps": 5, "start_offset": "10s", "end_offset": "30s"}},
        )
        [content] = convert_messages([ModelRequest([inp])], SerializerCls)

        assert content.model_dump(exclude_none=True) == {
            "role": "user",
            "parts": [
                {
                    "inline_data": {"data": b"\x00\x00video", "mime_type": "video/mp4"},
                    "video_metadata": {"fps": 5.0, "start_offset": "10s", "end_offset": "30s"},
                }
            ],
        }

    def test_display_name(self) -> None:
        inp = BinaryInput(
            data=self.PNG,
            media_type="image/png",
            vendor_metadata={"display_name": "my_photo.png"},
        )
        [content] = convert_messages([ModelRequest([inp])], SerializerCls)

        assert content.model_dump(exclude_none=True) == {
            "role": "user",
            "parts": [{"inline_data": {"data": self.PNG, "mime_type": "image/png", "display_name": "my_photo.png"}}],
        }

    def test_empty_metadata_is_noop(self) -> None:
        inp = BinaryInput(data=self.PNG, media_type="image/png")
        [content] = convert_messages([ModelRequest([inp])], SerializerCls)

        assert content.model_dump(exclude_none=True) == {
            "role": "user",
            "parts": [{"inline_data": {"data": self.PNG, "mime_type": "image/png"}}],
        }


class TestAudioFormatVariants:
    AUDIO = b"\x00\x01\x02audio"

    @pytest.mark.parametrize("media_type", ["audio/wav", "audio/mpeg", "audio/ogg"])
    def test_inline_audio_preserves_media_type(self, media_type: str) -> None:
        [content] = convert_messages(
            [ModelRequest([AudioInput(data=self.AUDIO, media_type=media_type)])], SerializerCls
        )

        assert content.model_dump(exclude_none=True) == {
            "role": "user",
            "parts": [{"inline_data": {"data": self.AUDIO, "mime_type": media_type}}],
        }


class TestMultipleInputs:
    def test_multiple_inputs_grouped_into_one_content(self) -> None:
        a_url = "https://example.com/a.png"
        b_url = "https://example.com/b.jpg"
        [content] = convert_messages(
            [
                ModelRequest([
                    TextInput("Describe these images."),
                    ImageInput(url=a_url),
                    ImageInput(url=b_url),
                ])
            ],
            SerializerCls,
        )

        assert content.model_dump(exclude_none=True) == {
            "role": "user",
            "parts": [
                {"text": "Describe these images."},
                {"file_data": {"file_uri": a_url, "mime_type": "image/png"}},
                {"file_data": {"file_uri": b_url, "mime_type": "image/jpeg"}},
            ],
        }

    def test_mixed_text_and_binary(self) -> None:
        png = b"\x89PNG"
        [content] = convert_messages(
            [
                ModelRequest([
                    TextInput("What is in this image?"),
                    ImageInput(data=png, media_type="image/png"),
                ])
            ],
            SerializerCls,
        )

        assert content.model_dump(exclude_none=True) == {
            "role": "user",
            "parts": [
                {"text": "What is in this image?"},
                {"inline_data": {"data": png, "mime_type": "image/png"}},
            ],
        }


class TestToolResult:
    """Tool results: text via response={'result': ...}, media via parts=[FunctionResponsePart...]."""

    PNG = b"\x89PNG\r\n"
    PDF = b"%PDF-1.4"
    IMG_URL = "https://example.com/image.png"
    PDF_URL = "https://example.com/doc.pdf"

    def test_text_only_goes_into_response(self) -> None:
        event = ToolResultsEvent(results=[ToolResultEvent(parent_id="tc_1", name="t", result=ToolResult("hello"))])
        [content] = convert_messages([event], SerializerCls)

        assert content.model_dump(exclude_none=True) == {
            "role": "user",
            "parts": [{"function_response": {"name": "t", "response": {"result": "hello"}}}],
        }

    def test_multiple_text_chunks_become_list(self) -> None:
        event = ToolResultsEvent(results=[ToolResultEvent(parent_id="tc_1", name="t", result=ToolResult("a", "b"))])
        [content] = convert_messages([event], SerializerCls)

        assert content.model_dump(exclude_none=True) == {
            "role": "user",
            "parts": [{"function_response": {"name": "t", "response": {"result": ["a", "b"]}}}],
        }

    def test_url_image(self) -> None:
        event = ToolResultsEvent(
            results=[ToolResultEvent(parent_id="tc_1", name="t", result=ToolResult(ImageInput(url=self.IMG_URL)))]
        )
        [content] = convert_messages([event], SerializerCls)

        assert content.model_dump(exclude_none=True) == {
            "role": "user",
            "parts": [
                {
                    "function_response": {
                        "name": "t",
                        "response": {},
                        "parts": [{"file_data": {"file_uri": self.IMG_URL, "mime_type": "image/png"}}],
                    }
                }
            ],
        }

    def test_binary_image(self) -> None:
        event = ToolResultsEvent(
            results=[
                ToolResultEvent(
                    parent_id="tc_1",
                    name="t",
                    result=ToolResult(ImageInput(data=self.PNG, media_type="image/png")),
                )
            ]
        )
        [content] = convert_messages([event], SerializerCls)

        assert content.model_dump(exclude_none=True) == {
            "role": "user",
            "parts": [
                {
                    "function_response": {
                        "name": "t",
                        "response": {},
                        "parts": [{"inline_data": {"data": self.PNG, "mime_type": "image/png"}}],
                    }
                }
            ],
        }

    def test_url_document(self) -> None:
        event = ToolResultsEvent(
            results=[ToolResultEvent(parent_id="tc_1", name="t", result=ToolResult(DocumentInput(url=self.PDF_URL)))]
        )
        [content] = convert_messages([event], SerializerCls)

        assert content.model_dump(exclude_none=True) == {
            "role": "user",
            "parts": [
                {
                    "function_response": {
                        "name": "t",
                        "response": {},
                        "parts": [{"file_data": {"file_uri": self.PDF_URL, "mime_type": "application/pdf"}}],
                    }
                }
            ],
        }

    def test_binary_document(self) -> None:
        event = ToolResultsEvent(
            results=[
                ToolResultEvent(
                    parent_id="tc_1",
                    name="t",
                    result=ToolResult(DocumentInput(data=self.PDF, media_type="application/pdf")),
                )
            ]
        )
        [content] = convert_messages([event], SerializerCls)

        assert content.model_dump(exclude_none=True) == {
            "role": "user",
            "parts": [
                {
                    "function_response": {
                        "name": "t",
                        "response": {},
                        "parts": [{"inline_data": {"data": self.PDF, "mime_type": "application/pdf"}}],
                    }
                }
            ],
        }

    def test_mixed_text_and_image(self) -> None:
        event = ToolResultsEvent(
            results=[
                ToolResultEvent(
                    parent_id="tc_1",
                    name="t",
                    result=ToolResult("caption", ImageInput(url=self.IMG_URL)),
                )
            ]
        )
        [content] = convert_messages([event], SerializerCls)

        assert content.model_dump(exclude_none=True) == {
            "role": "user",
            "parts": [
                {
                    "function_response": {
                        "name": "t",
                        "response": {"result": "caption"},
                        "parts": [{"file_data": {"file_uri": self.IMG_URL, "mime_type": "image/png"}}],
                    }
                }
            ],
        }

    def test_url_audio_raises(self) -> None:
        event = ToolResultsEvent(
            results=[ToolResultEvent(parent_id="tc_1", name="t", result=ToolResult(AudioInput(url="https://x/a.wav")))]
        )
        with pytest.raises(UnsupportedInputError, match="UrlInput.*gemini"):
            convert_messages([event], SerializerCls)

    def test_url_video_raises(self) -> None:
        event = ToolResultsEvent(
            results=[ToolResultEvent(parent_id="tc_1", name="t", result=ToolResult(VideoInput(url="https://x/v.mp4")))]
        )
        with pytest.raises(UnsupportedInputError, match="UrlInput.*gemini"):
            convert_messages([event], SerializerCls)

    def test_binary_audio_raises(self) -> None:
        event = ToolResultsEvent(
            results=[
                ToolResultEvent(
                    parent_id="tc_1",
                    name="t",
                    result=ToolResult(AudioInput(data=b"\x00", media_type="audio/wav")),
                )
            ]
        )
        with pytest.raises(UnsupportedInputError, match="BinaryInput.*gemini"):
            convert_messages([event], SerializerCls)

    def test_file_id_raises(self) -> None:
        event = ToolResultsEvent(
            results=[ToolResultEvent(parent_id="tc_1", name="t", result=ToolResult(FileIdInput(file_id="file-abc")))]
        )
        with pytest.raises(UnsupportedInputError, match="FileIdInput.*gemini"):
            convert_messages([event], SerializerCls)


class TestBuiltinToolEventReplay:
    def test_executable_code_part_appended_to_existing_model_content(self) -> None:
        code_part = types.Part(executable_code=types.ExecutableCode(code="print(1)", language="PYTHON"))
        events = [
            ModelResponse(message=None, tool_calls=ToolCallsEvent(calls=[])),
            GeminiServerToolCallEvent(name="code_execution", arguments="{}", part=code_part),
        ]
        result = convert_messages(events, SerializerCls)

        assert result == [types.Content(role="model", parts=[code_part])]

    def test_code_execution_pair_stacks_into_one_model_content(self) -> None:
        code_part = types.Part(executable_code=types.ExecutableCode(code="print(2)", language="PYTHON"))
        result_part = types.Part(code_execution_result=types.CodeExecutionResult(outcome="OUTCOME_OK", output="2\n"))

        result = convert_messages(
            [
                GeminiServerToolCallEvent(name="code_execution", arguments="{}", part=code_part),
                GeminiServerToolResultEvent(
                    parent_id="x", name="code_execution", result=ToolResult(), part=result_part
                ),
            ],
            SerializerCls,
        )

        assert result == [types.Content(role="model", parts=[code_part, result_part])]

    def test_grounding_only_events_are_skipped(self) -> None:
        gm = types.GroundingMetadata(web_search_queries=["bitcoin"])
        result = convert_messages(
            [
                GeminiServerToolCallEvent(name="web_search", arguments="{}", grounding_metadata=gm),
                GeminiServerToolResultEvent(
                    parent_id="x", name="web_search", result=ToolResult(), grounding_metadata=gm
                ),
            ],
            SerializerCls,
        )

        assert result == []


def test_hallucinated_tool_call_maps_with_error_text() -> None:
    # Regression: a not-found tool call used to leave result=None and crash on r.result.parts.
    call = ToolCallEvent(id="tc_1", name="ghost_tool")
    event = ToolResultsEvent(results=[ToolNotFoundEvent.from_call(call, ToolNotFoundError("ghost_tool"))])

    [content] = convert_messages([event], SerializerCls)

    assert content.model_dump(exclude_none=True) == {
        "role": "user",
        "parts": [
            {
                "function_response": {
                    "name": "ghost_tool",
                    "response": {"result": "ag2.exceptions.ToolNotFoundError: Tool `ghost_tool` not found\n"},
                }
            }
        ],
    }


class TestConvertMessagesCompactionSummary:
    """A CompactionSummary must render as a user turn so the summary stays visible
    and gives a valid opening turn (Gemini rejects a non-user first turn)."""

    def test_summary_renders_as_user_text(self) -> None:
        summary = CompactionSummary(summary="Earlier the user configured the project.", event_count=12)

        [content] = convert_messages([summary], SerializerCls)

        assert content.model_dump(exclude_none=True) == {
            "role": "user",
            "parts": [{"text": "[Summary of earlier conversation]\nEarlier the user configured the project."}],
        }

    def test_summary_leads_a_tool_cycle_with_a_user_turn(self) -> None:
        summary = CompactionSummary(summary="Looked up Paris and Tokyo.", event_count=6)
        call = ToolCallEvent(id="c9", name="get_weather", arguments='{"city": "NYC"}')
        events = [
            summary,
            ModelResponse(tool_calls=ToolCallsEvent(calls=[call])),
            ToolResultsEvent(results=[ToolResultEvent(parent_id="c9", name="get_weather", result=ToolResult("21C"))]),
        ]

        contents = convert_messages(events, SerializerCls)

        assert contents[0].role == "user"
