import logging
from typing import Any

import anthropic  # ty:ignore[unresolved-import]
import instructor
from instructor.core.patch import AsyncInstructorChatCompletionCreate
from pydantic import BaseModel
from tenacity import (
    before_sleep_log,
    retry,
    wait_exponential_jitter,
)

from cognee.infrastructure.llm.retry_config import (
    llm_retry_condition,
    llm_retry_stop_condition,
)

from cognee.infrastructure.llm.config import get_llm_config
from cognee.infrastructure.llm.structured_output_framework.litellm_instructor.llm.instructor_modes import (
    get_instructor_mode,
)
from cognee.infrastructure.llm.exceptions import LLMPaymentRequiredError, is_budget_exhausted_error
from cognee.infrastructure.llm.structured_output_framework.litellm_instructor.llm.generic_llm_api.adapter import (
    GenericAPIAdapter,
)
from cognee.modules.observability.get_observe import get_observe
from cognee.shared.logging_utils import get_logger
from cognee.shared.rate_limiting import llm_rate_limiter_context_manager

logger = get_logger()
observe = get_observe()


class AnthropicAdapter(GenericAPIAdapter):
    """
    Adapter for interfacing with the Anthropic API, enabling structured output generation
    and prompt display.
    """

    default_instructor_mode = get_instructor_mode("anthropic")

    def __init__(
        self,
        api_key: str,
        model: str,
        max_completion_tokens: int,
        instructor_mode: str | None = None,
        llm_args: dict[str, Any] | None = None,
    ) -> None:
        # Support both "model" and "anthropic/model" formats for model names, stripping the "anthropic/" prefix
        model = model.removeprefix("anthropic/") if model.startswith("anthropic/") else model
        super().__init__(
            api_key=api_key,
            model=model,
            max_completion_tokens=max_completion_tokens,
            name="Anthropic",
            llm_args=llm_args,
        )
        self.llm_args: dict[str, Any] = llm_args or {}
        # Anthropic's messages.create requires max_tokens. Unlike the litellm path used by
        # GenericAPIAdapter, instructor.patch around the raw Anthropic SDK does not auto-inject
        # it, so we surface max_completion_tokens here.
        self.llm_args.setdefault("max_tokens", max_completion_tokens)
        self.instructor_mode = instructor_mode if instructor_mode else self.default_instructor_mode

        self.aclient: AsyncInstructorChatCompletionCreate = instructor.patch(
            create=anthropic.AsyncAnthropic(
                api_key=self.api_key,
                http_client=anthropic.DefaultAsyncHttpxClient(http2=False),
            ).messages.create,
            mode=instructor.Mode(self.instructor_mode),
        )

    @observe(as_type="generation")
    @retry(
        stop=llm_retry_stop_condition,
        wait=wait_exponential_jitter(8, 128),
        retry=llm_retry_condition,
        before_sleep=before_sleep_log(logger, logging.WARNING),
        reraise=True,
    )
    async def acreate_structured_output(
        self, text_input: str, system_prompt: str, response_model: type[BaseModel], **kwargs: Any
    ) -> BaseModel:
        """
        Generate a response from a user query.

        Parameters:
        -----------

            - text_input (str): The input text from the user to be processed.
            - system_prompt (str): A prompt that sets the context for the query.
            - response_model (Type[BaseModel]): The model to structure the response according to
              its format.

        Returns:
        --------

            - BaseModel: An instance of BaseModel containing the structured response.
        """
        merged_kwargs = {**self.llm_args, **kwargs}
        try:
            async with llm_rate_limiter_context_manager():
                return await self.aclient(
                    model=self.model,
                    max_retries=2,
                    messages=[
                        {
                            "role": "user",
                            "content": f"""Use the given format to extract information
                    from the following input: {text_input}. {system_prompt}""",
                        }
                    ],
                    response_model=response_model,
                    **merged_kwargs,
                )
        except Exception as e:
            if is_budget_exhausted_error(e):
                raise LLMPaymentRequiredError() from e
            raise
