"""
Custom exceptions for the Cognee API.

This module defines a set of exceptions for handling various database errors
"""

from .exceptions import (
    EntityNotFoundError,
    EntityAlreadyExistsError,
    UnsupportedProvenanceCapability,
    DatabaseNotCreatedError,
    EmbeddingContextWindowTooSmallError,
    EmbeddingException,
    MissingQueryParameterError,
    MutuallyExclusiveQueryParametersError,
    CacheConnectionError,
    SessionQAEntryValidationError,
    SessionParameterValidationError,
    DatabaseCredentialsError,
    Neo4jMultiDatabaseSupportError,
)
